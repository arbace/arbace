//line a2g_strings.ae:1
package aot_arbace_box

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("exclude")

var Lit_4 *jrt.String = jrt.Intern("get")

var Lit_5 *jrt.String = jrt.Intern("load")

var Lit_6 *jrt.String = jrt.Intern("ref")

var Lit_7 *jrt.String = jrt.Intern("arbace.box.host")

var Lit_8 *jrt.String = jrt.Intern("as")

var Lit_9 *jrt.String = jrt.Intern("host")

var Lit_10 *jrt.String = jrt.Intern("arbace.edn")

var Lit_11 *jrt.String = jrt.Intern("edn")

var Lit_12 *jrt.String = jrt.Intern("commute")

var Lit_13 *jrt.String = jrt.Intern("deref")

var Lit_14 *jrt.String = jrt.Intern("conj")

var Lit_15 *jrt.String = jrt.Intern("arbace.box")

var Lit_16 *jrt.String = jrt.Intern("doc")

var Lit_17 *jrt.String = jrt.Intern("The store: blobs, immutable byte strings named by their SHA-256 (a hash: 64 lowercase\n  hexadecimal digits), and refs, names pointing at blobs, the store's only mutable state, changed\n  by compare-and-set. In the box the monitor keeps it, in the directory the launcher is given\n  (ARBACE_BOX_STORE=DIR, or arbace-box --store DIR); in the native executable the program keeps\n  it in the directory ARBACE_BOX_STORE names, in the same format, so that the same programs run\n  on both and one directory serves them, in turn or at once. A ref's name is 1 to 64 of [A-Za-z0-9._-], not beginning with a dot.\n\n    (put x)              store x (a string, as UTF-8, or a byte array): its hash\n    (get h)              blob h as a string (UTF-8), nil when there is none\n    (get-bytes h)        blob h as a byte array, nil when there is none\n    (size h)             its size, nil when there is none\n    (ref name)           the hash ref name points at, nil when none\n    (ref! name h)        point name at blob h: true\n    (ref! name h old)    only if it points at old (nil: if there is no such ref): true, or false\n                         when it does not (another write came first)\n    (put! name x)        (ref! name (put x)), x's hash\n    (load name)          the string ref name's blob holds, nil when there is no such ref\n    (load-ref name)      evaluate the source ref name's blob holds, as load-file a file\n    (save-fs! ref)       the in-memory file system (the box's) as a tar, stored, ref pointed at it;\n    (save-fs! ref dir)   or dir's files (natively a directory must be named): the tar's hash\n    (load-fs! ref)       the tar ref points at written into the file system (the box's), or\n    (load-fs! ref dir)   under dir\n    (store?)             is there a store?\n\n  Scripts and namespaces load from refs: arbace.main takes ref:NAME as a script or an -i file, and\n  an ARBACE_PATH entry store:PREFIX makes require and load find namespace a.b-c in ref\n  PREFIXa.b_c.ae (its path's '/'s made '.'s). ARBACE_BOX_FS=REF seeds the box's in-memory file\n  system from the snapshot REF at its start.\n\n  What the store refuses throws an ex-info whose data's :arbace.box/error is :no-store (none\n  configured), :bad-name, :bad-hash, :too-large (beyond ARBACE_BOX_STORE_MAX, by default 256 MiB),\n  :no-blob (a ref to a blob the store has not), :no-ref (load-ref, load-fs!) or :refused (the\n  host's error).")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("ex-info")

var Lit_20 *jrt.String = jrt.Intern("assoc")

var Lit_21 *jrt.String = jrt.Intern("error")

var Lit_22 *jrt.String = jrt.Intern("fail")

var Lit_23 *jrt.String = jrt.Intern("bad-name")

var Lit_24 *jrt.String = jrt.Intern("pr-str")

var Lit_25 *jrt.String = jrt.Intern("name")

var Lit_26 *jrt.String = jrt.Intern("too-large")

var Lit_27 *jrt.String = jrt.Intern("no-store")

var Lit_28 *jrt.String = jrt.Intern("refused")

var Lit_29 *jrt.String = jrt.Intern("string?")

var Lit_30 *jrt.String = jrt.Intern("re-matches")

var Lit_31 *jrt.String = jrt.Intern("[0-9a-f]{64}")

var Lit_32 *jrt.String = jrt.Intern("bad-hash")

var Lit_33 *jrt.String = jrt.Intern("hash")

var Lit_34 *jrt.String = jrt.Intern("subs")

var Lit_35 *jrt.String = jrt.Intern("str")

var Lit_36 *jrt.String = jrt.Intern("status")

var Lit_37 *jrt.String = jrt.Intern("bytes?")

var Lit_38 *jrt.String = jrt.Intern("else")

var Lit_39 *jrt.String = jrt.Intern("class")

var Lit_40 *jrt.String = jrt.Intern("put")

var Lit_41 *jrt.String = jrt.Intern("hex")

var Lit_42 *jrt.String = jrt.Intern("answer")

var Lit_43 *jrt.String = jrt.Intern("size")

var Lit_44 *jrt.String = jrt.Intern("hash-bytes")

var Lit_45 *jrt.String = jrt.Intern("read")

var Lit_46 *jrt.String = jrt.Intern("get-bytes")

var Lit_47 *jrt.String = jrt.Intern("no-blob")

var Lit_48 *jrt.String = jrt.Intern("set-ref")

var Lit_49 *jrt.String = jrt.Intern("ref!-answer")

var Lit_50 *jrt.String = jrt.Intern("ref!")

var Lit_51 *jrt.String = jrt.Intern("no-ref")

var Lit_52 *jrt.String = jrt.Intern("some?")

var Lit_53 *jrt.String = jrt.Intern("boxed?")

var Lit_54 *jrt.String = jrt.Intern("fs-dir")

var Lit_55 *jrt.String = jrt.Intern("make-array")

var Lit_56 *jrt.String = jrt.Intern("tar")

var Lit_57 *jrt.String = jrt.Intern("put!")

var Lit_58 *jrt.String = jrt.Intern("java.lang.String")

var Lit_59 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_60 *jrt.String = jrt.Intern("dir")

var Lit_61 *jrt.String = jrt.Intern("save-fs!")

var Lit_62 *jrt.String = jrt.Intern("untar")

var Lit_63 *jrt.String = jrt.Intern("load-fs!")

var Lit_64 *jrt.String = jrt.Intern("not")

var Lit_65 *jrt.String = jrt.Intern("every?")

var Lit_66 *jrt.String = jrt.Intern("contains?")

var Lit_67 *jrt.String = jrt.Intern("")

var Lit_68 *jrt.String = jrt.Intern("..")

var Lit_69 *jrt.String = jrt.Intern(".")

var Lit_70 *jrt.String = jrt.Intern("not=")

var Lit_71 *jrt.String = jrt.Intern("apply")

var Lit_72 *jrt.String = jrt.Intern("interpose")

var Lit_73 *jrt.String = jrt.Intern("map")

var Lit_74 *jrt.String = jrt.Intern("quote-str")

var Lit_75 *jrt.String = jrt.Intern("exec")

var Lit_76 *jrt.String = jrt.Intern("file")

var Lit_77 *jrt.String = jrt.Intern("tree-name?")

var Lit_78 *jrt.String = jrt.Intern("bad-tree")

var Lit_79 *jrt.String = jrt.Intern("sort-by")

var Lit_80 *jrt.String = jrt.Intern("key")

var Lit_81 *jrt.String = jrt.Intern("utf8-compare")

var Lit_82 *jrt.String = jrt.Intern("tree-text")

var Lit_83 *jrt.String = jrt.Intern("read-string")

var Lit_84 *jrt.String = jrt.Intern("put-file")

var Lit_85 *jrt.String = jrt.Intern("put-tree")

var Lit_86 *jrt.String = jrt.Intern("into")

var Lit_87 *jrt.String = jrt.Intern("seq")

var Lit_88 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_89 *jrt.String = jrt.Intern("chunk-first")

var Lit_90 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_91 *jrt.String = jrt.Intern("chunk-append")

var Lit_92 *jrt.String = jrt.Intern("put-dir")

var Lit_93 *jrt.String = jrt.Intern("chunk-cons")

var Lit_94 *jrt.String = jrt.Intern("first")

var Lit_95 *jrt.String = jrt.Intern("cons")

var Lit_96 *jrt.String = jrt.Intern("chunk")

var Lit_97 *jrt.String = jrt.Intern("chunk-rest")

var Lit_98 *jrt.String = jrt.Intern("rest")

var Lit_99 *jrt.String = jrt.Intern("tree")

var Lit_100 *jrt.String = jrt.Intern("get-tree")

var Lit_101 *jrt.String = jrt.Intern("next")

var Lit_102 *jrt.String = jrt.Intern("reduce")

var Lit_103 *jrt.String = jrt.Intern("reduced")

var Lit_104 *jrt.String = jrt.Intern("second")

var Lit_105 *jrt.String = jrt.Intern("remove")

var Lit_106 *jrt.String = jrt.Intern("empty?")

var Lit_107 *jrt.String = jrt.Intern("to-array")

var Lit_108 *jrt.String = jrt.Intern("image")

var Lit_109 *jrt.String = jrt.Intern("args")

var Lit_110 *jrt.String = jrt.Intern("env")

var Lit_111 *jrt.String = jrt.Intern("trees")

var Lit_112 *jrt.String = jrt.Intern("out")

var Lit_113 *jrt.String = jrt.Intern("cwd")

var Lit_114 *jrt.String = jrt.Intern("ram")

var Lit_115 *jrt.String = jrt.Intern("cpus")

var Lit_116 *jrt.String = jrt.Intern("map?")

var Lit_117 *jrt.String = jrt.Intern("spawn")

var Lit_118 *jrt.String = jrt.Intern("request-text")

var Lit_119 *jrt.String = jrt.Intern("request")

var Lit_120 *jrt.String = jrt.Intern("result")

var Lit_121 *jrt.String = jrt.Intern("spawn-await")

var Lit_122 *jrt.String = jrt.Intern("spawn-wait")

var Lit_123 *jrt.String = jrt.Intern("arbace.box$answer")

var Lit_124 *jrt.String = jrt.Intern(": not a name the store takes (1 to 64 of [A-Za-z0-9._-], not beginning with a dot): ")

var Lit_125 *jrt.String = jrt.Intern(": larger than the store takes (ARBACE_BOX_STORE_MAX)")

var Lit_126 *jrt.String = jrt.Intern(": no store (ARBACE_BOX_STORE names none, or the launcher's --store)")

var Lit_127 *jrt.String = jrt.Intern(": the store refused")

var Lit_128 *jrt.String = jrt.Intern("arbace.box$boxed_QMARK_")

var Lit_129 *jrt.String = jrt.Intern("Tamago")

var Lit_130 *jrt.String = jrt.Intern("os.name")

var Lit_131 *jrt.String = jrt.Intern("arbace.box$eval533000004$loading__1927001464__auto____533000005")

var Lit_132 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_133 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_134 *jrt.String = jrt.Intern("arbace.box$eval533000008$fn__533000009")

var Lit_135 *jrt.String = jrt.Intern("arbace.box$fail")

var Lit_136 *jrt.String = jrt.Intern("arbace.box$fs_dir")

var Lit_137 *jrt.String = jrt.Intern("/")

var Lit_138 *jrt.String = jrt.Intern(": natively, a directory must be named (the box's file system is its memory)")

var Lit_139 *jrt.String = jrt.Intern("arbace.box$get")

var Lit_140 *jrt.String = jrt.Intern("arbace.box$get_bytes")

var Lit_141 *jrt.String = jrt.Intern("arbace.box/get-bytes")

var Lit_142 *jrt.String = jrt.Intern("arbace.box$get_tree")

var Lit_143 *jrt.String = jrt.Intern("arbace.box/get-tree: no tree ")

var Lit_144 *jrt.String = jrt.Intern("arbace.box$get_tree$fn__533000077")

var Lit_145 *jrt.String = jrt.Intern("write")

var Lit_146 *jrt.String = jrt.Intern("arbace.box/get-tree: no blob ")

var Lit_147 *jrt.String = jrt.Intern("arbace.box$get_tree$fn__533000085")

var Lit_148 *jrt.String = jrt.Intern("arbace.box$hash_bytes")

var Lit_149 *jrt.String = jrt.Intern(": not a hash (64 lowercase hexadecimal digits): ")

var Lit_150 *jrt.String = jrt.Intern("arbace.box$hex")

var Lit_151 *jrt.String = jrt.Intern("arbace.box$load")

var Lit_152 *jrt.String = jrt.Intern("arbace.box$load_fs_BANG_")

var Lit_153 *jrt.String = jrt.Intern("arbace.box/load-fs!")

var Lit_154 *jrt.String = jrt.Intern("arbace.box/load-fs!: no ref ")

var Lit_155 *jrt.String = jrt.Intern("arbace.box/load-fs!: ")

var Lit_156 *jrt.String = jrt.Intern(": ")

var Lit_157 *jrt.String = jrt.Intern("arbace.box$load_ref")

var Lit_158 *jrt.String = jrt.Intern("arbace.box/load-ref: no ref ")

var Lit_159 *jrt.String = jrt.Intern("ref:")

var Lit_160 *jrt.String = jrt.Intern("arbace.box$put")

var Lit_161 *jrt.String = jrt.Intern("arbace.box/put: a string or a byte array, not ")

var Lit_162 *jrt.String = jrt.Intern("arbace.box/put")

var Lit_163 *jrt.String = jrt.Intern("arbace.box$put_BANG_")

var Lit_164 *jrt.String = jrt.Intern("arbace.box$put_dir")

var Lit_165 *jrt.String = jrt.Intern("arbace.box/put-dir: not a directory: ")

var Lit_166 *jrt.String = jrt.Intern("arbace.box$put_dir$iter__533000056__533000060")

var Lit_167 *jrt.String = jrt.Intern("arbace.box$put_dir$iter__533000056__533000060$fn__533000061")

var Lit_168 *jrt.String = jrt.Intern("arbace.box$put_dir$iter__533000056__533000060$fn__533000061$fn__533000062")

var Lit_169 *jrt.String = jrt.Intern("arbace.box$put_file")

var Lit_170 *jrt.String = jrt.Intern("arbace.box$put_tree")

var Lit_171 *jrt.String = jrt.Intern("arbace.box$quote_str")

var Lit_172 *jrt.String = jrt.Intern("\"")

var Lit_173 *jrt.String = jrt.Intern("\\")

var Lit_174 *jrt.String = jrt.Intern("\\\\")

var Lit_175 *jrt.String = jrt.Intern("\\\"")

var Lit_176 *jrt.String = jrt.Intern("arbace.box$ref")

var Lit_177 *jrt.String = jrt.Intern("arbace.box/ref")

var Lit_178 *jrt.String = jrt.Intern("arbace.box$ref_BANG_")

var Lit_179 *jrt.String = jrt.Intern("arbace.box/ref!")

var Lit_180 *jrt.String = jrt.Intern("arbace.box$ref_BANG__answer")

var Lit_181 *jrt.String = jrt.Intern("arbace.box/ref!: no blob ")

var Lit_182 *jrt.String = jrt.Intern("arbace.box$request_text")

var Lit_183 *jrt.String = jrt.Intern("arbace.box/request-text")

var Lit_184 *jrt.String = jrt.Intern("{:image \"")

var Lit_185 *jrt.String = jrt.Intern("\"\n :args ")

var Lit_186 *jrt.String = jrt.Intern("}\n")

var Lit_187 *jrt.String = jrt.Intern("\n :env ")

var Lit_188 *jrt.String = jrt.Intern("\n :trees [")

var Lit_189 *jrt.String = jrt.Intern("]")

var Lit_190 *jrt.String = jrt.Intern("\n         ")

var Lit_191 *jrt.String = jrt.Intern("\n :out ")

var Lit_192 *jrt.String = jrt.Intern("\n :cwd ")

var Lit_193 *jrt.String = jrt.Intern("\n :ram ")

var Lit_194 *jrt.String = jrt.Intern("\n :cpus ")

var Lit_195 *jrt.String = jrt.Intern("arbace.box$request_text$iter__533000096__533000100")

var Lit_196 *jrt.String = jrt.Intern("arbace.box$request_text$iter__533000096__533000100$fn__533000101")

var Lit_197 *jrt.String = jrt.Intern("[")

var Lit_198 *jrt.String = jrt.Intern(" \"")

var Lit_199 *jrt.String = jrt.Intern("\"]")

var Lit_200 *jrt.String = jrt.Intern("arbace.box$request_text$iter__533000096__533000100$fn__533000101$fn__533000102")

var Lit_201 *jrt.String = jrt.Intern("arbace.box$request_text$v__533000094")

var Lit_202 *jrt.String = jrt.Intern(" ")

var Lit_203 *jrt.String = jrt.Intern("arbace.box$result")

var Lit_204 *jrt.String = jrt.Intern("arbace.box/result: no blob ")

var Lit_205 *jrt.String = jrt.Intern("arbace.box$run")

var Lit_206 *jrt.String = jrt.Intern("arbace.box$save_fs_BANG_")

var Lit_207 *jrt.String = jrt.Intern("arbace.box/save-fs!")

var Lit_208 *jrt.String = jrt.Intern("arbace.box/save-fs!: ")

var Lit_209 *jrt.String = jrt.Intern("aget")

var Lit_210 *jrt.String = jrt.Intern("arbace.box$size")

var Lit_211 *jrt.String = jrt.Intern("arbace.box/size")

var Lit_212 *jrt.String = jrt.Intern("arbace.box$spawn")

var Lit_213 *jrt.String = jrt.Intern("arbace.box/spawn")

var Lit_214 *jrt.String = jrt.Intern("arbace.box/spawn: refused: ")

var Lit_215 *jrt.String = jrt.Intern("arbace.box$spawn_wait")

var Lit_216 *jrt.String = jrt.Intern("arbace.box/spawn-wait: the guest could not run (spawn ")

var Lit_217 *jrt.String = jrt.Intern(")")

var Lit_218 *jrt.String = jrt.Intern("arbace.box$store_QMARK_")

var Lit_219 *jrt.String = jrt.Intern("arbace.box$tree")

var Lit_220 *jrt.String = jrt.Intern("arbace.box$tree_get")

var Lit_221 *jrt.String = jrt.Intern("split")

var Lit_222 *jrt.String = jrt.Intern("arbace.box$tree_get$fn__533000088")

var Lit_223 *jrt.String = jrt.Intern("arbace.box$tree_name_QMARK_")

var Lit_224 *jrt.String = jrt.Intern("arbace.box$tree_name_QMARK_$fn__533000038")

var Lit_225 *jrt.String = jrt.Intern("arbace.box$tree_text")

var Lit_226 *jrt.String = jrt.Intern("{")

var Lit_227 *jrt.String = jrt.Intern("\n ")

var Lit_228 *jrt.String = jrt.Intern("arbace.box$tree_text$fn__533000042")

var Lit_229 *jrt.String = jrt.Intern("arbace.box/tree-text: a name a tree does not take: ")

var Lit_230 *jrt.String = jrt.Intern("arbace.box/tree-text")

var Lit_231 *jrt.String = jrt.Intern("[:dir \"")

var Lit_232 *jrt.String = jrt.Intern("arbace.box/tree-text: not an entry: ")

var Lit_233 *jrt.String = jrt.Intern("arbace.box$utf8_compare")

var Lit_234 *jrt.String = jrt.Intern("in-ns")

var Lit_235 *jrt.String = jrt.Intern("private")

var Lit_236 *jrt.String = jrt.Intern("arglists")

var Lit_237 *jrt.String = jrt.Intern("kind")

var Lit_238 *jrt.String = jrt.Intern("msg")

var Lit_239 *jrt.String = jrt.Intern("tag")

var Lit_240 *jrt.String = jrt.Intern("String")

var Lit_241 *jrt.String = jrt.Intern("data")

var Lit_242 *jrt.String = jrt.Intern("line")

var Lit_243 *jrt.String = jrt.Intern("column")

var Lit_244 *jrt.String = jrt.Intern("arbace/box.ae")

var Lit_245 *jrt.String = jrt.Intern("code")

var Lit_246 *jrt.String = jrt.Intern("long")

var Lit_247 *jrt.String = jrt.Intern("what")

var Lit_248 *jrt.String = jrt.Intern("Throws for a negative answer of the host (what, the operation; data, its arguments).")

var Lit_249 *jrt.String = jrt.Intern("h")

var Lit_250 *jrt.String = jrt.Intern("bytes")

var Lit_251 *jrt.String = jrt.Intern("The 32 bytes of hash h.")

var Lit_252 *jrt.String = jrt.Intern("b")

var Lit_253 *jrt.String = jrt.Intern("Hash bytes b as its 64 hexadecimal digits.")

var Lit_254 *jrt.String = jrt.Intern("store?")

var Lit_255 *jrt.String = jrt.Intern("Is there a store (ARBACE_BOX_STORE, or the launcher's --store)?")

var Lit_256 *jrt.String = jrt.Intern("x")

var Lit_257 *jrt.String = jrt.Intern("Stores x, a string (its UTF-8) or a byte array: its hash.")

var Lit_258 *jrt.String = jrt.Intern("Blob h as a byte array, nil when the store has none.")

var Lit_259 *jrt.String = jrt.Intern("Blob h as a string (its bytes as UTF-8), nil when the store has none.")

var Lit_260 *jrt.String = jrt.Intern("The size of blob h, nil when the store has none.")

var Lit_261 *jrt.String = jrt.Intern("The hash ref name points at, nil when there is no such ref.")

var Lit_262 *jrt.String = jrt.Intern("old")

var Lit_263 *jrt.String = jrt.Intern("Points ref name at blob h: true. With old, only if the ref points at old now (old nil: if\n  there is no such ref): true, or false when it does not.")

var Lit_264 *jrt.String = jrt.Intern("Stores x and points ref name at it: its hash.")

var Lit_265 *jrt.String = jrt.Intern("The string ref name's blob holds, nil when there is no such ref.")

var Lit_266 *jrt.String = jrt.Intern("load-ref")

var Lit_267 *jrt.String = jrt.Intern("Evaluates the source ref name's blob holds, as load-file a file: the last form's value. Its\n  source path is ref:NAME.")

var Lit_268 *jrt.String = jrt.Intern("Stores a snapshot of the files under dir (by default, in the box, its whole in-memory file\n  system) as a tar (directories and regular files, the times the epoch: the same files are the\n  same blob) and points ref at it: the tar's hash.")

var Lit_269 *jrt.String = jrt.Intern("Writes the tar ref points at (save-fs!'s, or any tar's directories and regular files) under\n  dir (by default, in the box, /): nil.")

var Lit_270 *jrt.String = jrt.Intern("s")

var Lit_271 *jrt.String = jrt.Intern("s as a string the reader reads back: \" and \\ escaped, nothing else.")

var Lit_272 *jrt.String = jrt.Intern("a")

var Lit_273 *jrt.String = jrt.Intern("Compares strings a and b by their UTF-8 bytes, unsigned.")

var Lit_274 *jrt.String = jrt.Intern("n")

var Lit_275 *jrt.String = jrt.Intern("m")

var Lit_276 *jrt.String = jrt.Intern("Tree m ({name [:file HASH SIZE] | [:exec HASH SIZE] | [:dir HASH]}) printed canonically.")

var Lit_277 *jrt.String = jrt.Intern("Stores tree m (tree-text): its hash.")

var Lit_278 *jrt.String = jrt.Intern("Tree h as its map, nil when the store has no such blob.")

var Lit_279 *jrt.String = jrt.Intern("Stores the bytes of x (put) as the entry of a tree: [:file HASH SIZE], or [:exec ...] with\n  exec.")

var Lit_280 *jrt.String = jrt.Intern("Stores the directory dir (a path), its files and directories under it, as a tree: its hash. A\n  file is :exec when it can be executed.")

var Lit_281 *jrt.String = jrt.Intern("Writes tree h into the directory dir (made when missing): nil.")

var Lit_282 *jrt.String = jrt.Intern("tree-get")

var Lit_283 *jrt.String = jrt.Intern("p")

var Lit_284 *jrt.String = jrt.Intern("The entry at path p (\"a/b.go\") of tree h, nil when there is none.")

var Lit_285 *jrt.String = jrt.Intern("keys")

var Lit_286 *jrt.String = jrt.Intern("Request req printed canonically: the keys in the order above, those with nothing left out\n  (:cwd \"/\", :ram 0, :cpus 0 too).")

var Lit_287 *jrt.String = jrt.Intern("req")

var Lit_288 *jrt.String = jrt.Intern("Starts the guest request req asks for (a map, stored first, or a request blob's hash): a\n  handle. Refused (no spawning: the launcher's ARBACE_BOX_SPAWN; natively ARBACE_BOX_LAUNCHER):\n  an ex-info :refused.")

var Lit_289 *jrt.String = jrt.Intern("Result blob h as a map, its :hash added.")

var Lit_290 *jrt.String = jrt.Intern("Waits for spawn n's end: its result (result).")

var Lit_291 *jrt.String = jrt.Intern("run")

var Lit_292 *jrt.String = jrt.Intern("Spawns req and waits for it: its result.")
