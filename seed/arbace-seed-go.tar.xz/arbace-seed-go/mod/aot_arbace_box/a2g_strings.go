//line a2g_strings.ae:1
package aot_arbace_box

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn3,getyn4,loadyn3,refyn15,arbace.box.hostkn2,asyn4,hostyn10,arbace.ednyn3,ednkn3,docks10,arbace.box5,errorkn8,bad-namekn4,namekn9,too-largekn8,no-storekn7,refusedkn8,bad-hashkn4,hashkn4,elsekn4,sizekn7,no-blobkn6,no-refkn3,dirkn4,execkn4,filekn8,bad-treekn5,imagekn4,argskn3,envkn5,treeskn3,outkn3,cwdkn3,ramkn4,cpuskn7,requestkn5,spawnv11,arbace.core5,referv11,arbace.core7,requireR0,R1,V3,R2,R3,R4,V3,R5,R6,R7,V3,R8,R6,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn10,arbace.boxm2,R10,s2399,The store: blobs, immutable byte strings named by their SHA-256 (a hash: 64 lowercase\n  hexadecimal digits), and refs, names pointing at blobs, the store's only mutable state, changed\n  by compare-and-set. In the box the monitor keeps it, in the directory the launcher is given\n  (ARBACE_BOX_STORE=DIR, or arbace-box --store DIR); in the native executable the program keeps\n  it in the directory ARBACE_BOX_STORE names, in the same format, so that the same programs run\n  on both and one directory serves them, in turn or at once. A ref's name is 1 to 64 of [A-Za-z0-9._-], not beginning with a dot.\n\n    (put x)              store x (a string, as UTF-8, or a byte array): its hash\n    (get h)              blob h as a string (UTF-8), nil when there is none\n    (get-bytes h)        blob h as a byte array, nil when there is none\n    (size h)             its size, nil when there is none\n    (ref name)           the hash ref name points at, nil when none\n    (ref! name h)        point name at blob h: true\n    (ref! name h old)    only if it points at old (nil: if there is no such ref): true, or false\n                         when it does not (another write came first)\n    (put! name x)        (ref! name (put x)), x's hash\n    (load name)          the string ref name's blob holds, nil when there is no such ref\n    (load-ref name)      evaluate the source ref name's blob holds, as load-file a file\n    (save-fs! ref)       the in-memory file system (the box's) as a tar, stored, ref pointed at it;\n    (save-fs! ref dir)   or dir's files (natively a directory must be named): the tar's hash\n    (load-fs! ref)       the tar ref points at written into the file system (the box's), or\n    (load-fs! ref dir)   under dir\n    (store?)             is there a store?\n\n  Scripts and namespaces load from refs: arbace.main takes ref:NAME as a script or an -i file, and\n  an ARBACE_PATH entry store:PREFIX makes require and load find namespace a.b-c in ref\n  PREFIXa.b_c.ae (its path's '/'s made '.'s). ARBACE_BOX_FS=REF seeds the box's in-memory file\n  system from the snapshot REF at its start.\n\n  What the store refuses throws an ex-info whose data's :arbace.box/error is :no-store (none\n  configured), :bad-name, :bad-hash, :too-large (beyond ARBACE_BOX_STORE_MAX, by default 256 MiB),\n  :no-blob (a ref to a blob the store has not), :no-ref (load-ref, load-fs!) or :refused (the\n  host's error).v11,arbace.core13,*loaded-libs*v11,arbace.core7,ex-infov11,arbace.core5,assocR11,v10,arbace.box4,failR12,v11,arbace.core6,pr-strR13,R14,R15,R16,l32,v11,arbace.core7,string?v11,arbace.core10,re-matchesp12,[0-9a-f]{64}R17,R18,v11,arbace.core4,subsv11,arbace.core3,strv15,arbace.box.host6,statusv11,arbace.core6,bytes?R19,v11,arbace.core5,classv15,arbace.box.host3,putv10,arbace.box3,hexv10,arbace.box6,answerR20,v10,arbace.box10,hash-bytesv15,arbace.box.host4,sizev15,arbace.box.host4,readv10,arbace.box9,get-bytesv15,arbace.box.host3,refi-1,i0,v10,arbace.box4,sizeR21,v15,arbace.box.host7,set-refv10,arbace.box11,ref!-answerv10,arbace.box3,putv10,arbace.box4,ref!v10,arbace.box3,refv10,arbace.box3,getv10,arbace.box4,loadR22,v11,arbace.core5,some?v10,arbace.box6,boxed?v10,arbace.box6,fs-dirv11,arbace.core10,make-arrayv15,arbace.box.host3,tarv10,arbace.box4,put!C16,java.lang.Stringl1,C14,arbace.lang.RTR23,v10,arbace.box8,save-fs!v15,arbace.box.host5,untarv10,arbace.box8,load-fs!v11,arbace.core3,notv11,arbace.core6,every?v11,arbace.core9,contains?S3,s0,s2,..s1,.v11,arbace.core4,not=c47,l127,v11,arbace.core5,applyv11,arbace.core9,interposev11,arbace.core3,mapv10,arbace.box9,quote-strR24,R25,v10,arbace.box10,tree-name?R26,v11,arbace.core7,sort-byv11,arbace.core3,keyv10,arbace.box12,utf8-comparev10,arbace.box9,tree-textv10,arbace.edn11,read-stringv10,arbace.box8,put-filev10,arbace.box8,put-treev11,arbace.core4,intov11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv10,arbace.box7,put-dirv11,arbace.core10,chunk-consv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv10,arbace.box4,treev10,arbace.box8,get-treev11,arbace.core4,nextv11,arbace.core6,reducev11,arbace.core7,reducedv11,arbace.core6,secondv11,arbace.core6,removev11,arbace.core6,empty?v11,arbace.core8,to-arrayR27,R28,R29,R30,R31,R32,R33,R34,v11,arbace.core4,map?v15,arbace.box.host5,spawnv10,arbace.box12,request-textR35,v10,arbace.box6,resultv15,arbace.box.host11,spawn-awaitR36,v10,arbace.box10,spawn-waitv10,arbace.box5,spawn")

var Lit_1 *jrt.String = jrt.Intern(": not a name the store takes (1 to 64 of [A-Za-z0-9._-], not beginning with a dot): ")

var Lit_2 *jrt.String = jrt.Intern(": larger than the store takes (ARBACE_BOX_STORE_MAX)")

var Lit_3 *jrt.String = jrt.Intern(": no store (ARBACE_BOX_STORE names none, or the launcher's --store)")

var Lit_4 *jrt.String = jrt.Intern(": the store refused")

var Lit_5 *jrt.String = jrt.Intern("Tamago")

var Lit_6 *jrt.String = jrt.Intern("os.name")

var Lit_7 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_8 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_9 *jrt.String = jrt.Intern("/")

var Lit_10 *jrt.String = jrt.Intern(": natively, a directory must be named (the box's file system is its memory)")

var Lit_11 *jrt.String = jrt.Intern("arbace.box/get-bytes")

var Lit_12 *jrt.String = jrt.Intern("arbace.box/get-tree: no tree ")

var Lit_13 *jrt.String = jrt.Intern("arbace.box$get_tree$fn__533000077")

var Lit_14 *jrt.String = jrt.Intern("arbace.box$get_tree$fn__533000085")

var Lit_15 *jrt.String = jrt.Intern("write")

var Lit_16 *jrt.String = jrt.Intern("arbace.box/get-tree: no blob ")

var Lit_17 *jrt.String = jrt.Intern(": not a hash (64 lowercase hexadecimal digits): ")

var Lit_18 *jrt.String = jrt.Intern("arbace.box/load-fs!")

var Lit_19 *jrt.String = jrt.Intern("arbace.box/load-fs!: no ref ")

var Lit_20 *jrt.String = jrt.Intern("arbace.box/load-fs!: ")

var Lit_21 *jrt.String = jrt.Intern(": ")

var Lit_22 *jrt.String = jrt.Intern("arbace.box/load-ref: no ref ")

var Lit_23 *jrt.String = jrt.Intern("ref:")

var Lit_24 *jrt.String = jrt.Intern("arbace.box/put: a string or a byte array, not ")

var Lit_25 *jrt.String = jrt.Intern("arbace.box/put")

var Lit_26 *jrt.String = jrt.Intern("arbace.box/put-dir: not a directory: ")

var Lit_27 *jrt.String = jrt.Intern("arbace.box$put_dir$iter__533000056__533000060")

var Lit_28 *jrt.String = jrt.Intern("arbace.box$put_dir$iter__533000056__533000060$fn__533000061")

var Lit_29 *jrt.String = jrt.Intern("arbace.box$put_dir$iter__533000056__533000060$fn__533000061$fn__533000062")

var Lit_30 *jrt.String = jrt.Intern("\"")

var Lit_31 *jrt.String = jrt.Intern("\\")

var Lit_32 *jrt.String = jrt.Intern("\\\\")

var Lit_33 *jrt.String = jrt.Intern("\\\"")

var Lit_34 *jrt.String = jrt.Intern("arbace.box/ref")

var Lit_35 *jrt.String = jrt.Intern("arbace.box/ref!")

var Lit_36 *jrt.String = jrt.Intern("arbace.box/ref!: no blob ")

var Lit_37 *jrt.String = jrt.Intern("arbace.box$request_text$v__533000094")

var Lit_38 *jrt.String = jrt.Intern("arbace.box/request-text")

var Lit_39 *jrt.String = jrt.Intern("{:image \"")

var Lit_40 *jrt.String = jrt.Intern("\"\n :args ")

var Lit_41 *jrt.String = jrt.Intern("}\n")

var Lit_42 *jrt.String = jrt.Intern("\n :env ")

var Lit_43 *jrt.String = jrt.Intern("\n :trees [")

var Lit_44 *jrt.String = jrt.Intern("]")

var Lit_45 *jrt.String = jrt.Intern("\n         ")

var Lit_46 *jrt.String = jrt.Intern("arbace.box$request_text$iter__533000096__533000100")

var Lit_47 *jrt.String = jrt.Intern("\n :out ")

var Lit_48 *jrt.String = jrt.Intern("\n :cwd ")

var Lit_49 *jrt.String = jrt.Intern("\n :ram ")

var Lit_50 *jrt.String = jrt.Intern("\n :cpus ")

var Lit_51 *jrt.String = jrt.Intern("arbace.box$request_text$iter__533000096__533000100$fn__533000101")

var Lit_52 *jrt.String = jrt.Intern("arbace.box$request_text$iter__533000096__533000100$fn__533000101$fn__533000102")

var Lit_53 *jrt.String = jrt.Intern("[")

var Lit_54 *jrt.String = jrt.Intern(" \"")

var Lit_55 *jrt.String = jrt.Intern("\"]")

var Lit_56 *jrt.String = jrt.Intern(" ")

var Lit_57 *jrt.String = jrt.Intern("arbace.box/result: no blob ")

var Lit_58 *jrt.String = jrt.Intern("arbace.box/save-fs!")

var Lit_59 *jrt.String = jrt.Intern("arbace.box/save-fs!: ")

var Lit_60 *jrt.String = jrt.Intern("aget")

var Lit_61 *jrt.String = jrt.Intern("arbace.box/size")

var Lit_62 *jrt.String = jrt.Intern("arbace.box/spawn")

var Lit_63 *jrt.String = jrt.Intern("arbace.box/spawn: refused: ")

var Lit_64 *jrt.String = jrt.Intern("arbace.box/spawn-wait: the guest could not run (spawn ")

var Lit_65 *jrt.String = jrt.Intern(")")

var Lit_66 *jrt.String = jrt.Intern("arbace.box$tree_get$fn__533000088")

var Lit_67 *jrt.String = jrt.Intern("split")

var Lit_68 *jrt.String = jrt.Intern("arbace.box$tree_name_QMARK_$fn__533000038")

var Lit_69 *jrt.String = jrt.Intern("{")

var Lit_70 *jrt.String = jrt.Intern("\n ")

var Lit_71 *jrt.String = jrt.Intern("arbace.box$tree_text$fn__533000042")

var Lit_72 *jrt.String = jrt.Intern("arbace.box/tree-text: a name a tree does not take: ")

var Lit_73 *jrt.String = jrt.Intern("arbace.box/tree-text")

var Lit_74 *jrt.String = jrt.Intern("[:dir \"")

var Lit_75 *jrt.String = jrt.Intern("arbace.box/tree-text: not an entry: ")

var Lit_76 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn4,kindkn3,tagyn6,Stringyn4,datakn4,linekn6,columnkn4,fileyn4,longyn4,whatyn1,hyn5,bytesyn1,xyn4,codeyn4,nameyn3,oldyn3,diryn3,refyn1,myn4,execkn4,keysyn5,imageyn4,argsyn3,envyn5,treesyn3,outyn3,cwdyn3,ramyn4,cpusyn3,reqyn1,nv11,arbace.core5,in-nsMyn10,arbace.boxm2,R0,s2399,The store: blobs, immutable byte strings named by their SHA-256 (a hash: 64 lowercase\n  hexadecimal digits), and refs, names pointing at blobs, the store's only mutable state, changed\n  by compare-and-set. In the box the monitor keeps it, in the directory the launcher is given\n  (ARBACE_BOX_STORE=DIR, or arbace-box --store DIR); in the native executable the program keeps\n  it in the directory ARBACE_BOX_STORE names, in the same format, so that the same programs run\n  on both and one directory serves them, in turn or at once. A ref's name is 1 to 64 of [A-Za-z0-9._-], not beginning with a dot.\n\n    (put x)              store x (a string, as UTF-8, or a byte array): its hash\n    (get h)              blob h as a string (UTF-8), nil when there is none\n    (get-bytes h)        blob h as a byte array, nil when there is none\n    (size h)             its size, nil when there is none\n    (ref name)           the hash ref name points at, nil when none\n    (ref! name h)        point name at blob h: true\n    (ref! name h old)    only if it points at old (nil: if there is no such ref): true, or false\n                         when it does not (another write came first)\n    (put! name x)        (ref! name (put x)), x's hash\n    (load name)          the string ref name's blob holds, nil when there is no such ref\n    (load-ref name)      evaluate the source ref name's blob holds, as load-file a file\n    (save-fs! ref)       the in-memory file system (the box's) as a tar, stored, ref pointed at it;\n    (save-fs! ref dir)   or dir's files (natively a directory must be named): the tar's hash\n    (load-fs! ref)       the tar ref points at written into the file system (the box's), or\n    (load-fs! ref dir)   under dir\n    (store?)             is there a store?\n\n  Scripts and namespaces load from refs: arbace.main takes ref:NAME as a script or an -i file, and\n  an ARBACE_PATH entry store:PREFIX makes require and load find namespace a.b-c in ref\n  PREFIXa.b_c.ae (its path's '/'s made '.'s). ARBACE_BOX_FS=REF seeds the box's in-memory file\n  system from the snapshot REF at its start.\n\n  What the store refuses throws an ex-info whose data's :arbace.box/error is :no-store (none\n  configured), :bad-name, :bad-hash, :too-large (beyond ARBACE_BOX_STORE_MAX, by default 256 MiB),\n  :no-blob (a ref to a blob the store has not), :no-ref (load-ref, load-fs!) or :refused (the\n  host's error).m2,R0,s2399,The store: blobs, immutable byte strings named by their SHA-256 (a hash: 64 lowercase\n  hexadecimal digits), and refs, names pointing at blobs, the store's only mutable state, changed\n  by compare-and-set. In the box the monitor keeps it, in the directory the launcher is given\n  (ARBACE_BOX_STORE=DIR, or arbace-box --store DIR); in the native executable the program keeps\n  it in the directory ARBACE_BOX_STORE names, in the same format, so that the same programs run\n  on both and one directory serves them, in turn or at once. A ref's name is 1 to 64 of [A-Za-z0-9._-], not beginning with a dot.\n\n    (put x)              store x (a string, as UTF-8, or a byte array): its hash\n    (get h)              blob h as a string (UTF-8), nil when there is none\n    (get-bytes h)        blob h as a byte array, nil when there is none\n    (size h)             its size, nil when there is none\n    (ref name)           the hash ref name points at, nil when none\n    (ref! name h)        point name at blob h: true\n    (ref! name h old)    only if it points at old (nil: if there is no such ref): true, or false\n                         when it does not (another write came first)\n    (put! name x)        (ref! name (put x)), x's hash\n    (load name)          the string ref name's blob holds, nil when there is no such ref\n    (load-ref name)      evaluate the source ref name's blob holds, as load-file a file\n    (save-fs! ref)       the in-memory file system (the box's) as a tar, stored, ref pointed at it;\n    (save-fs! ref dir)   or dir's files (natively a directory must be named): the tar's hash\n    (load-fs! ref)       the tar ref points at written into the file system (the box's), or\n    (load-fs! ref dir)   under dir\n    (store?)             is there a store?\n\n  Scripts and namespaces load from refs: arbace.main takes ref:NAME as a script or an -i file, and\n  an ARBACE_PATH entry store:PREFIX makes require and load find namespace a.b-c in ref\n  PREFIXa.b_c.ae (its path's '/'s made '.'s). ARBACE_BOX_FS=REF seeds the box's in-memory file\n  system from the snapshot REF at its start.\n\n  What the store refuses throws an ex-info whose data's :arbace.box/error is :no-store (none\n  configured), :bad-name, :bad-hash, :too-large (beyond ARBACE_BOX_STORE_MAX, by default 256 MiB),\n  :no-blob (a ref to a blob the store has not), :no-ref (load-ref, load-fs!) or :refused (the\n  host's error).R1,v10,arbace.box4,failm10,R2,TR3,L1,V3,R4,Myn3,msgm2,R5,R6,R7,R8,i44,R9,i1,R10,s13,arbace/box.aev10,arbace.box6,answerm12,R2,TR3,L1,V3,Myn4,codem2,R5,R11,R12,R7,R0,s84,Throws for a negative answer of the host (what, the operation; data, its arguments).R8,i47,R9,i1,R10,s13,arbace/box.aev10,arbace.box10,hash-bytesm12,R2,TR3,L1,MV2,R13,R12,m2,R5,R14,R0,s23,The 32 bytes of hash h.R8,i57,R9,i1,R10,s13,arbace/box.aev10,arbace.box3,hexm12,R2,TR3,L1,V1,Myn1,bm2,R5,R14,R0,s42,Hash bytes b as its 64 hexadecimal digits.R8,i67,R9,i1,R10,s13,arbace/box.aev10,arbace.box6,store?m10,R3,L1,V0,R0,s63,Is there a store (ARBACE_BOX_STORE, or the launcher's --store)?R8,i77,R9,i1,R10,s13,arbace/box.aev10,arbace.box3,putm10,R3,L1,V1,R15,R0,s57,Stores x, a string (its UTF-8) or a byte array: its hash.R8,i82,R9,i1,R10,s13,arbace/box.aev10,arbace.box9,get-bytesm10,R3,L1,V1,R13,R0,s52,Blob h as a byte array, nil when the store has none.R8,i95,R9,i1,R10,s13,arbace/box.aev10,arbace.box3,getm10,R3,L1,V1,R13,R0,s69,Blob h as a string (its bytes as UTF-8), nil when the store has none.R8,i105,R9,i1,R10,s13,arbace/box.aev10,arbace.box4,sizem10,R3,L1,V1,R13,R0,s48,The size of blob h, nil when the store has none.R8,i111,R9,i1,R10,s13,arbace/box.aev10,arbace.box3,refm10,R3,L1,V1,Myn4,namem2,R5,R6,R0,s59,The hash ref name points at, nil when there is no such ref.R8,i120,R9,i1,R10,s13,arbace/box.aev10,arbace.box11,ref!-answerm10,R2,TR3,L1,V3,R16,R17,R13,R8,i130,R9,i1,R10,s13,arbace/box.aev10,arbace.box4,ref!m10,R3,L2,V2,R17,R13,V3,R17,R13,R18,R0,s147,Points ref name at blob h: true. With old, only if the ref points at old now (old nil: if\n  there is no such ref): true, or false when it does not.R8,i137,R9,i1,R10,s13,arbace/box.aev10,arbace.box4,put!m10,R3,L1,V2,R17,R15,R0,s45,Stores x and points ref name at it: its hash.R8,i148,R9,i1,R10,s13,arbace/box.aev10,arbace.box4,loadm10,R3,L1,V1,R17,R0,s64,The string ref name's blob holds, nil when there is no such ref.R8,i155,R9,i1,R10,s13,arbace/box.aev10,arbace.box8,load-refm10,R3,L1,V1,R17,R0,s118,Evaluates the source ref name's blob holds, as load-file a file: the last form's value. Its\n  source path is ref:NAME.R8,i160,R9,i1,R10,s13,arbace/box.aev10,arbace.box6,boxed?m10,R2,TR3,L1,V0,R8,i169,R9,i1,R10,s13,arbace/box.aev10,arbace.box6,fs-dirm10,R2,TR3,L1,V2,R19,R12,R8,i172,R9,i1,R10,s13,arbace/box.aev10,arbace.box8,save-fs!m10,R3,L2,V1,R20,V2,R20,R19,R0,s236,Stores a snapshot of the files under dir (by default, in the box, its whole in-memory file\n  system) as a tar (directories and regular files, the times the epoch: the same files are the\n  same blob) and points ref at it: the tar's hash.R8,i179,R9,i1,R10,s13,arbace/box.aev10,arbace.box8,load-fs!m10,R3,L2,V1,R20,V2,R20,R19,R0,s131,Writes the tar ref points at (save-fs!'s, or any tar's directories and regular files) under\n  dir (by default, in the box, /): nil.R8,i192,R9,i1,R10,s13,arbace/box.aev10,arbace.box9,quote-strm12,R2,TR3,L1,V1,Myn1,sm2,R5,R6,R0,s67,s as a string the reader reads back: \" and \\ escaped, nothing else.R8,i211,R9,i1,R10,s13,arbace/box.aev10,arbace.box12,utf8-comparem12,R2,TR3,L1,V2,Myn1,am2,R5,R6,Myn1,bm2,R5,R6,R0,s56,Compares strings a and b by their UTF-8 bytes, unsigned.R8,i216,R9,i1,R10,s13,arbace/box.aev10,arbace.box10,tree-name?m10,R2,TR3,L1,V1,Myn1,nm2,R5,R6,R8,i228,R9,i1,R10,s13,arbace/box.aev10,arbace.box9,tree-textm10,R3,L1,V1,R21,R0,s88,Tree m ({name [:file HASH SIZE] | [:exec HASH SIZE] | [:dir HASH]}) printed canonically.R8,i232,R9,i1,R10,s13,arbace/box.aev10,arbace.box8,put-treem10,R3,L1,V1,R21,R0,s36,Stores tree m (tree-text): its hash.R8,i250,R9,i1,R10,s13,arbace/box.aev10,arbace.box4,treem10,R3,L1,V1,R13,R0,s55,Tree h as its map, nil when the store has no such blob.R8,i255,R9,i1,R10,s13,arbace/box.aev10,arbace.box8,put-filem10,R3,L2,V1,R15,V2,R15,R22,R0,s98,Stores the bytes of x (put) as the entry of a tree: [:file HASH SIZE], or [:exec ...] with\n  exec.R8,i260,R9,i1,R10,s13,arbace/box.aev10,arbace.box7,put-dirm10,R3,L1,V1,R19,R0,s134,Stores the directory dir (a path), its files and directories under it, as a tree: its hash. A\n  file is :exec when it can be executed.R8,i268,R9,i1,R10,s13,arbace/box.aev10,arbace.box8,get-treem10,R3,L1,V2,R13,R19,R0,s62,Writes tree h into the directory dir (made when missing): nil.R8,i284,R9,i1,R10,s13,arbace/box.aev10,arbace.box8,tree-getm10,R3,L1,V2,R13,Myn1,pm2,R5,R6,R0,s65,The entry at path p (\"a/b.go\") of tree h, nil when there is none.R8,i301,R9,i1,R10,s13,arbace/box.aev10,arbace.box12,request-textm10,R3,L1,V1,m2,R23,V8,R24,R25,R26,R27,R28,R29,R30,R31,R0,s124,Request req printed canonically: the keys in the order above, those with nothing left out\n  (:cwd \"/\", :ram 0, :cpus 0 too).R8,i318,R9,i1,R10,s13,arbace/box.aev10,arbace.box5,spawnm10,R3,L1,V1,R32,R0,s207,Starts the guest request req asks for (a map, stored first, or a request blob's hash): a\n  handle. Refused (no spawning: the launcher's ARBACE_BOX_SPAWN; natively ARBACE_BOX_LAUNCHER):\n  an ex-info :refused.R8,i336,R9,i1,R10,s13,arbace/box.aev10,arbace.box6,resultm10,R3,L1,V1,R13,R0,s40,Result blob h as a map, its :hash added.R8,i347,R9,i1,R10,s13,arbace/box.aev10,arbace.box10,spawn-waitm10,R3,L1,V1,R33,R0,s45,Waits for spawn n's end: its result (result).R8,i355,R9,i1,R10,s13,arbace/box.aev10,arbace.box3,runm10,R3,L1,V1,R32,R0,s40,Spawns req and waits for it: its result.R8,i363,R9,i1,R10,s13,arbace/box.ae")

var Lit_77 *jrt.String = jrt.Intern("arbace.box$eval533000004$loading__1927001464__auto____533000005")

var Lit_78 *jrt.String = jrt.Intern("arbace.box$eval533000008$fn__533000009")

var Lit_79 *jrt.String = jrt.Intern("arbace.box$fail")

var Lit_80 *jrt.String = jrt.Intern("arbace.box$answer")

var Lit_81 *jrt.String = jrt.Intern("arbace.box$hash_bytes")

var Lit_82 *jrt.String = jrt.Intern("arbace.box$hex")

var Lit_83 *jrt.String = jrt.Intern("arbace.box$store_QMARK_")

var Lit_84 *jrt.String = jrt.Intern("arbace.box$put")

var Lit_85 *jrt.String = jrt.Intern("arbace.box$get_bytes")

var Lit_86 *jrt.String = jrt.Intern("arbace.box$get")

var Lit_87 *jrt.String = jrt.Intern("arbace.box$size")

var Lit_88 *jrt.String = jrt.Intern("arbace.box$ref")

var Lit_89 *jrt.String = jrt.Intern("arbace.box$ref_BANG__answer")

var Lit_90 *jrt.String = jrt.Intern("arbace.box$ref_BANG_")

var Lit_91 *jrt.String = jrt.Intern("arbace.box$put_BANG_")

var Lit_92 *jrt.String = jrt.Intern("arbace.box$load")

var Lit_93 *jrt.String = jrt.Intern("arbace.box$load_ref")

var Lit_94 *jrt.String = jrt.Intern("arbace.box$boxed_QMARK_")

var Lit_95 *jrt.String = jrt.Intern("arbace.box$fs_dir")

var Lit_96 *jrt.String = jrt.Intern("arbace.box$save_fs_BANG_")

var Lit_97 *jrt.String = jrt.Intern("arbace.box$load_fs_BANG_")

var Lit_98 *jrt.String = jrt.Intern("arbace.box$quote_str")

var Lit_99 *jrt.String = jrt.Intern("arbace.box$utf8_compare")

var Lit_100 *jrt.String = jrt.Intern("arbace.box$tree_name_QMARK_")

var Lit_101 *jrt.String = jrt.Intern("arbace.box$tree_text")

var Lit_102 *jrt.String = jrt.Intern("arbace.box$put_tree")

var Lit_103 *jrt.String = jrt.Intern("arbace.box$tree")

var Lit_104 *jrt.String = jrt.Intern("arbace.box$put_file")

var Lit_105 *jrt.String = jrt.Intern("arbace.box$put_dir")

var Lit_106 *jrt.String = jrt.Intern("arbace.box$get_tree")

var Lit_107 *jrt.String = jrt.Intern("arbace.box$tree_get")

var Lit_108 *jrt.String = jrt.Intern("arbace.box$request_text")

var Lit_109 *jrt.String = jrt.Intern("arbace.box$spawn")

var Lit_110 *jrt.String = jrt.Intern("arbace.box$result")

var Lit_111 *jrt.String = jrt.Intern("arbace.box$spawn_wait")

var Lit_112 *jrt.String = jrt.Intern("arbace.box$run")
