//line aot_arbace_box__init.ae:1
package aot_arbace_box

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box__init_A_Unit0__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return lang.IFn_Cast(jrt.NN(A_arbace_box__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_box__init_A_const_1) }
//line :4:1
func A_arbace_box__init_A_Unit1__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_box__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_2)) }
//line :4:1
func A_arbace_box__init_A_Unit2__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); var tmp1 any = A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_New(); var tmp2 *jrt.Class; A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_Init(); tmp2 = A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :4:1
func A_arbace_box__init_A_Unit3__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box__init_A_const_1)).Equals_O__Z(A_arbace_box__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_eval533000008_fn__533000009_A_New(); var tmp2 *jrt.Class; A_arbace_box_eval533000008_fn__533000009_A_Init(); tmp2 = A_arbace_box_eval533000008_fn__533000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
func A_arbace_box__init_A_Load__O() any { A_arbace_box__init_A_Init(); A_arbace_box__init_A_Unit0__O(); A_arbace_box__init_A_Unit1__O(); A_arbace_box__init_A_Unit2__O(); A_arbace_box__init_A_Unit3__O(); A_arbace_box__init_A_Unit4__O(); A_arbace_box__init_A_Unit5__O(); A_arbace_box__init_A_Unit6__O(); A_arbace_box__init_A_Unit7__O(); A_arbace_box__init_A_Unit8__O(); A_arbace_box__init_A_Unit9__O(); A_arbace_box__init_A_Unit10__O(); A_arbace_box__init_A_Unit11__O(); A_arbace_box__init_A_Unit12__O(); A_arbace_box__init_A_Unit13__O(); A_arbace_box__init_A_Unit14__O(); A_arbace_box__init_A_Unit15__O(); A_arbace_box__init_A_Unit16__O(); A_arbace_box__init_A_Unit17__O(); A_arbace_box__init_A_Unit18__O(); A_arbace_box__init_A_Unit19__O(); A_arbace_box__init_A_Unit20__O(); A_arbace_box__init_A_Unit21__O(); A_arbace_box__init_A_Unit22__O(); A_arbace_box__init_A_Unit23__O(); A_arbace_box__init_A_Unit24__O(); A_arbace_box__init_A_Unit25__O(); A_arbace_box__init_A_Unit26__O(); A_arbace_box__init_A_Unit27__O(); A_arbace_box__init_A_Unit28__O(); A_arbace_box__init_A_Unit29__O(); A_arbace_box__init_A_Unit30__O(); A_arbace_box__init_A_Unit31__O(); A_arbace_box__init_A_Unit32__O(); A_arbace_box__init_A_Unit33__O(); A_arbace_box__init_A_Unit34__O(); A_arbace_box__init_A_Unit35__O(); A_arbace_box__init_A_Unit36__O(); A_arbace_box__init_A_Unit37__O(); return nil }






































func A_arbace_box__init_A_Unit4__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_4; var tmp2 any = A_arbace_box_fail_A_New(); var tmp3 *jrt.Class; A_arbace_box_fail_A_Init(); tmp3 = A_arbace_box_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_5)); return A_arbace_box__init_A_const_4.Ref() }


func A_arbace_box__init_A_Unit5__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_6; var tmp2 any = A_arbace_box_answer_A_New(); var tmp3 *jrt.Class; A_arbace_box_answer_A_Init(); tmp3 = A_arbace_box_answer_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_7)); return A_arbace_box__init_A_const_6.Ref() }









func A_arbace_box__init_A_Unit6__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(57, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_8; var tmp2 any = A_arbace_box_hash_bytes_A_New(); var tmp3 *jrt.Class; A_arbace_box_hash_bytes_A_Init(); tmp3 = A_arbace_box_hash_bytes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_9)); return A_arbace_box__init_A_const_8.Ref() }









func A_arbace_box__init_A_Unit7__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_10; var tmp2 any = A_arbace_box_hex_A_New(); var tmp3 *jrt.Class; A_arbace_box_hex_A_Init(); tmp3 = A_arbace_box_hex_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_11)); return A_arbace_box__init_A_const_10.Ref() }









func A_arbace_box__init_A_Unit8__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_12; var tmp2 any = A_arbace_box_store_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_box_store_QMARK__A_Init(); tmp3 = A_arbace_box_store_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_13)); return A_arbace_box__init_A_const_12.Ref() }




func A_arbace_box__init_A_Unit9__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_14; var tmp2 any = A_arbace_box_put_A_New(); var tmp3 *jrt.Class; A_arbace_box_put_A_Init(); tmp3 = A_arbace_box_put_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_15)); return A_arbace_box__init_A_const_14.Ref() }












func A_arbace_box__init_A_Unit10__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_16; var tmp2 any = A_arbace_box_get_bytes_A_New(); var tmp3 *jrt.Class; A_arbace_box_get_bytes_A_Init(); tmp3 = A_arbace_box_get_bytes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_17)); return A_arbace_box__init_A_const_16.Ref() }









func A_arbace_box__init_A_Unit11__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(105, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_18; var tmp2 any = A_arbace_box_get_A_New(); var tmp3 *jrt.Class; A_arbace_box_get_A_Init(); tmp3 = A_arbace_box_get_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_19)); return A_arbace_box__init_A_const_18.Ref() }





func A_arbace_box__init_A_Unit12__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_20; var tmp2 any = A_arbace_box_size_A_New(); var tmp3 *jrt.Class; A_arbace_box_size_A_Init(); tmp3 = A_arbace_box_size_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_21)); return A_arbace_box__init_A_const_20.Ref() }








func A_arbace_box__init_A_Unit13__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(120, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_22; var tmp2 any = A_arbace_box_ref_A_New(); var tmp3 *jrt.Class; A_arbace_box_ref_A_Init(); tmp3 = A_arbace_box_ref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_23)); return A_arbace_box__init_A_const_22.Ref() }









func A_arbace_box__init_A_Unit14__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_24; var tmp2 any = A_arbace_box_ref_BANG__answer_A_New(); var tmp3 *jrt.Class; A_arbace_box_ref_BANG__answer_A_Init(); tmp3 = A_arbace_box_ref_BANG__answer_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_25)); return A_arbace_box__init_A_const_24.Ref() }






func A_arbace_box__init_A_Unit15__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(137, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_26; var tmp2 any = A_arbace_box_ref_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_box_ref_BANG__A_Init(); tmp3 = A_arbace_box_ref_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_27)); return A_arbace_box__init_A_const_26.Ref() }










func A_arbace_box__init_A_Unit16__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_28; var tmp2 any = A_arbace_box_put_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_box_put_BANG__A_Init(); tmp3 = A_arbace_box_put_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_29)); return A_arbace_box__init_A_const_28.Ref() }






func A_arbace_box__init_A_Unit17__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_30; var tmp2 any = A_arbace_box_load_A_New(); var tmp3 *jrt.Class; A_arbace_box_load_A_Init(); tmp3 = A_arbace_box_load_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_31)); return A_arbace_box__init_A_const_30.Ref() }




func A_arbace_box__init_A_Unit18__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_32; var tmp2 any = A_arbace_box_load_ref_A_New(); var tmp3 *jrt.Class; A_arbace_box_load_ref_A_Init(); tmp3 = A_arbace_box_load_ref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_33)); return A_arbace_box__init_A_const_32.Ref() }








func A_arbace_box__init_A_Unit19__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(169, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_34; var tmp2 any = A_arbace_box_boxed_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_box_boxed_QMARK__A_Init(); tmp3 = A_arbace_box_boxed_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_35)); return A_arbace_box__init_A_const_34.Ref() }


func A_arbace_box__init_A_Unit20__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_36; var tmp2 any = A_arbace_box_fs_dir_A_New(); var tmp3 *jrt.Class; A_arbace_box_fs_dir_A_Init(); tmp3 = A_arbace_box_fs_dir_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_37)); return A_arbace_box__init_A_const_36.Ref() }






func A_arbace_box__init_A_Unit21__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(179, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_38; var tmp2 any = A_arbace_box_save_fs_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_box_save_fs_BANG__A_Init(); tmp3 = A_arbace_box_save_fs_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_39)); return A_arbace_box__init_A_const_38.Ref() }












func A_arbace_box__init_A_Unit22__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(192, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_40; var tmp2 any = A_arbace_box_load_fs_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_box_load_fs_BANG__A_Init(); tmp3 = A_arbace_box_load_fs_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_41)); return A_arbace_box__init_A_const_40.Ref() }


















func A_arbace_box__init_A_Unit23__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(211, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_42; var tmp2 any = A_arbace_box_quote_str_A_New(); var tmp3 *jrt.Class; A_arbace_box_quote_str_A_Init(); tmp3 = A_arbace_box_quote_str_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_43)); return A_arbace_box__init_A_const_42.Ref() }




func A_arbace_box__init_A_Unit24__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(216, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_44; var tmp2 any = A_arbace_box_utf8_compare_A_New(); var tmp3 *jrt.Class; A_arbace_box_utf8_compare_A_Init(); tmp3 = A_arbace_box_utf8_compare_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_45)); return A_arbace_box__init_A_const_44.Ref() }











func A_arbace_box__init_A_Unit25__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(228, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_46; var tmp2 any = A_arbace_box_tree_name_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_box_tree_name_QMARK__A_Init(); tmp3 = A_arbace_box_tree_name_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_47)); return A_arbace_box__init_A_const_46.Ref() }



func A_arbace_box__init_A_Unit26__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(232, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_48; var tmp2 any = A_arbace_box_tree_text_A_New(); var tmp3 *jrt.Class; A_arbace_box_tree_text_A_Init(); tmp3 = A_arbace_box_tree_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_49)); return A_arbace_box__init_A_const_48.Ref() }

















func A_arbace_box__init_A_Unit27__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(250, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_50; var tmp2 any = A_arbace_box_put_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_put_tree_A_Init(); tmp3 = A_arbace_box_put_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_51)); return A_arbace_box__init_A_const_50.Ref() }




func A_arbace_box__init_A_Unit28__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_52; var tmp2 any = A_arbace_box_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_tree_A_Init(); tmp3 = A_arbace_box_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_53)); return A_arbace_box__init_A_const_52.Ref() }




func A_arbace_box__init_A_Unit29__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(260, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_54; var tmp2 any = A_arbace_box_put_file_A_New(); var tmp3 *jrt.Class; A_arbace_box_put_file_A_Init(); tmp3 = A_arbace_box_put_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_55)); return A_arbace_box__init_A_const_54.Ref() }







func A_arbace_box__init_A_Unit30__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(268, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_56; var tmp2 any = A_arbace_box_put_dir_A_New(); var tmp3 *jrt.Class; A_arbace_box_put_dir_A_Init(); tmp3 = A_arbace_box_put_dir_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_57)); return A_arbace_box__init_A_const_56.Ref() }















func A_arbace_box__init_A_Unit31__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(284, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_58; var tmp2 any = A_arbace_box_get_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_get_tree_A_Init(); tmp3 = A_arbace_box_get_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_59)); return A_arbace_box__init_A_const_58.Ref() }
















func A_arbace_box__init_A_Unit32__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(301, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_60; var tmp2 any = A_arbace_box_tree_get_A_New(); var tmp3 *jrt.Class; A_arbace_box_tree_get_A_Init(); tmp3 = A_arbace_box_tree_get_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_61)); return A_arbace_box__init_A_const_60.Ref() }
















func A_arbace_box__init_A_Unit33__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(318, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_62; var tmp2 any = A_arbace_box_request_text_A_New(); var tmp3 *jrt.Class; A_arbace_box_request_text_A_Init(); tmp3 = A_arbace_box_request_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_63)); return A_arbace_box__init_A_const_62.Ref() }

















func A_arbace_box__init_A_Unit34__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(336, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_64; var tmp2 any = A_arbace_box_spawn_A_New(); var tmp3 *jrt.Class; A_arbace_box_spawn_A_Init(); tmp3 = A_arbace_box_spawn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_65)); return A_arbace_box__init_A_const_64.Ref() }










func A_arbace_box__init_A_Unit35__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(347, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_66; var tmp2 any = A_arbace_box_result_A_New(); var tmp3 *jrt.Class; A_arbace_box_result_A_Init(); tmp3 = A_arbace_box_result_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_67)); return A_arbace_box__init_A_const_66.Ref() }







func A_arbace_box__init_A_Unit36__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(355, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_68; var tmp2 any = A_arbace_box_spawn_wait_A_New(); var tmp3 *jrt.Class; A_arbace_box_spawn_wait_A_Init(); tmp3 = A_arbace_box_spawn_wait_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_69)); return A_arbace_box__init_A_const_68.Ref() }







func A_arbace_box__init_A_Unit37__O() any { A_arbace_box__init_A_Init(); lang.Compiler_AOT_At_I_I__V(363, 1); var tmp1 *lang.Var = A_arbace_box__init_A_const_70; var tmp2 any = A_arbace_box_run_A_New(); var tmp3 *jrt.Class; A_arbace_box_run_A_Init(); tmp3 = A_arbace_box_run_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box__init_A_const_71)); return A_arbace_box__init_A_const_70.Ref() }



type A_arbace_box__init_A struct{ jrt.Object }

var A_arbace_box__init_A_const_0 *lang.Var

var A_arbace_box__init_A_const_1 any

var A_arbace_box__init_A_const_2 any

var A_arbace_box__init_A_const_3 any

var A_arbace_box__init_A_const_4 *lang.Var

var A_arbace_box__init_A_const_5 any

var A_arbace_box__init_A_const_6 *lang.Var

var A_arbace_box__init_A_const_7 any

var A_arbace_box__init_A_const_8 *lang.Var

var A_arbace_box__init_A_const_9 any

var A_arbace_box__init_A_const_10 *lang.Var

var A_arbace_box__init_A_const_11 any

var A_arbace_box__init_A_const_12 *lang.Var

var A_arbace_box__init_A_const_13 any

var A_arbace_box__init_A_const_14 *lang.Var

var A_arbace_box__init_A_const_15 any

var A_arbace_box__init_A_const_16 *lang.Var

var A_arbace_box__init_A_const_17 any

var A_arbace_box__init_A_const_18 *lang.Var

var A_arbace_box__init_A_const_19 any

var A_arbace_box__init_A_const_20 *lang.Var

var A_arbace_box__init_A_const_21 any

var A_arbace_box__init_A_const_22 *lang.Var

var A_arbace_box__init_A_const_23 any

var A_arbace_box__init_A_const_24 *lang.Var

var A_arbace_box__init_A_const_25 any

var A_arbace_box__init_A_const_26 *lang.Var

var A_arbace_box__init_A_const_27 any

var A_arbace_box__init_A_const_28 *lang.Var

var A_arbace_box__init_A_const_29 any

var A_arbace_box__init_A_const_30 *lang.Var

var A_arbace_box__init_A_const_31 any

var A_arbace_box__init_A_const_32 *lang.Var

var A_arbace_box__init_A_const_33 any

var A_arbace_box__init_A_const_34 *lang.Var

var A_arbace_box__init_A_const_35 any

var A_arbace_box__init_A_const_36 *lang.Var

var A_arbace_box__init_A_const_37 any

var A_arbace_box__init_A_const_38 *lang.Var

var A_arbace_box__init_A_const_39 any

var A_arbace_box__init_A_const_40 *lang.Var

var A_arbace_box__init_A_const_41 any

var A_arbace_box__init_A_const_42 *lang.Var

var A_arbace_box__init_A_const_43 any

var A_arbace_box__init_A_const_44 *lang.Var

var A_arbace_box__init_A_const_45 any

var A_arbace_box__init_A_const_46 *lang.Var

var A_arbace_box__init_A_const_47 any

var A_arbace_box__init_A_const_48 *lang.Var

var A_arbace_box__init_A_const_49 any

var A_arbace_box__init_A_const_50 *lang.Var

var A_arbace_box__init_A_const_51 any

var A_arbace_box__init_A_const_52 *lang.Var

var A_arbace_box__init_A_const_53 any

var A_arbace_box__init_A_const_54 *lang.Var

var A_arbace_box__init_A_const_55 any

var A_arbace_box__init_A_const_56 *lang.Var

var A_arbace_box__init_A_const_57 any

var A_arbace_box__init_A_const_58 *lang.Var

var A_arbace_box__init_A_const_59 any

var A_arbace_box__init_A_const_60 *lang.Var

var A_arbace_box__init_A_const_61 any

var A_arbace_box__init_A_const_62 *lang.Var

var A_arbace_box__init_A_const_63 any

var A_arbace_box__init_A_const_64 *lang.Var

var A_arbace_box__init_A_const_65 any

var A_arbace_box__init_A_const_66 *lang.Var

var A_arbace_box__init_A_const_67 any

var A_arbace_box__init_A_const_68 *lang.Var

var A_arbace_box__init_A_const_69 any

var A_arbace_box__init_A_const_70 *lang.Var

var A_arbace_box__init_A_const_71 any

var A_arbace_box__init_A_init jrt.ClassInit

func A_arbace_box__init_A_Init() { if !A_arbace_box__init_A_init.Done() { A_arbace_box__init_A_init.Run(A_arbace_box__init_A_clinit) } }

func A_arbace_box__init_A_clinit() { A_arbace_box__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_234); A_arbace_box__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_box__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_box__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_15, Lit_22); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_box__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_237).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_241).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_15, Lit_42); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_box__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_245)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_246).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_247).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_241).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_248, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_15, Lit_44); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_box__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_247).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_250).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_251, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(57).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_15, Lit_41); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_box__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_252)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_250).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_253, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(67).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_15, Lit_254); A_arbace_box__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_15, Lit_40); A_arbace_box__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_256).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_257, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_15, Lit_46); A_arbace_box__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_258, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_15, Lit_4); A_arbace_box__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_259, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(105).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_15, Lit_43); A_arbace_box__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_260, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_15, Lit_6); A_arbace_box__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_261, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(120).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_15, Lit_49); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_box__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_245).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_15, Lit_50); A_arbace_box__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_263, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(137).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_15, Lit_57); A_arbace_box__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_256).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_264, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(148).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_15, Lit_5); A_arbace_box__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_265, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(155).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_15, Lit_266); A_arbace_box__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_267, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(160).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_15, Lit_53); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_box__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(169).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_15, Lit_54); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_box__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_247).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(172).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_15, Lit_61); A_arbace_box__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_268, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(179).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_15, Lit_63); A_arbace_box__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_269, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(192).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_15, Lit_74); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_box__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_270)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_271, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(211).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_15, Lit_81); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_box__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_272)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_252)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_273, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(216).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_15, Lit_77); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_box__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_274)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(228).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_15, Lit_82); A_arbace_box__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_275).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_276, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(232).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_15, Lit_85); A_arbace_box__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_275).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_277, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(250).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_15, Lit_99); A_arbace_box__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_278, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(255).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_15, Lit_84); A_arbace_box__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_256).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_256).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_75).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_279, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(260).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_15, Lit_92); A_arbace_box__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_280, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(268).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_15, Lit_100); A_arbace_box__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_281, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(284).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_15, Lit_282); A_arbace_box__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_283)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_284, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(301).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_15, Lit_118); A_arbace_box__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_285).Ref(), lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_113).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_286, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(318).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_15, Lit_117); A_arbace_box__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_287).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_288, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(336).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_15, Lit_120); A_arbace_box__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_289, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(347).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_15, Lit_122); A_arbace_box__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_274).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_290, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)); A_arbace_box__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_15, Lit_291); A_arbace_box__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_236).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_287).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_292, lang.RT_Keyword_String_String__Keyword(nil, Lit_242).Ref(), jrt.Integer_ValueOf_I__Integer(363).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_243).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_244)) }

func A_arbace_box__init_A_New() *A_arbace_box__init_A { A_arbace_box__init_A_Init(); t := &A_arbace_box__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box__init_A) Ctor() {}

func (t *A_arbace_box__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box__init_A) GetClass__Class() *jrt.Class { return A_arbace_box__init_A_class }

func (t *A_arbace_box__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box__init_A); return ok }

func A_arbace_box__init_A_Cast(x any) *A_arbace_box__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box__init_A_class)) }; return v }
