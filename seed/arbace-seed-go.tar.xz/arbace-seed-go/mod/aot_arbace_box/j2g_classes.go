//line j2g_classes.ae:1
package aot_arbace_box

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_box_answer_A_class, Name: "arbace.box$answer", Modifiers: 25, Simple: "answer", Go: "arbace/aot_arbace_box.A_arbace_box_answer_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_boxed_QMARK__A_class, Name: "arbace.box$boxed_QMARK_", Modifiers: 25, Simple: "boxed_QMARK_", Go: "arbace/aot_arbace_box.A_arbace_box_boxed_QMARK__A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_class, Name: "arbace.box$eval533000004$loading__1927001464__auto____533000005", Modifiers: 25, Simple: "loading__1927001464__auto____533000005", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A", Source: "box.ae", Declaring: &A_arbace_box_eval533000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_eval533000008_fn__533000009_A_class, Name: "arbace.box$eval533000008$fn__533000009", Modifiers: 25, Simple: "fn__533000009", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000008_fn__533000009_A", Source: "box.ae", Declaring: &A_arbace_box_eval533000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_fail_A_class, Name: "arbace.box$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_box.A_arbace_box_fail_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_fs_dir_A_class, Name: "arbace.box$fs_dir", Modifiers: 25, Simple: "fs_dir", Go: "arbace/aot_arbace_box.A_arbace_box_fs_dir_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_get_A_class, Name: "arbace.box$get", Modifiers: 25, Simple: "get", Go: "arbace/aot_arbace_box.A_arbace_box_get_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_get_bytes_A_class, Name: "arbace.box$get_bytes", Modifiers: 25, Simple: "get_bytes", Go: "arbace/aot_arbace_box.A_arbace_box_get_bytes_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_get_tree_A_class, Name: "arbace.box$get_tree", Modifiers: 25, Simple: "get_tree", Go: "arbace/aot_arbace_box.A_arbace_box_get_tree_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_get_tree_fn__533000077_A_class, Name: "arbace.box$get_tree$fn__533000077", Modifiers: 25, Simple: "fn__533000077", Go: "arbace/aot_arbace_box.A_arbace_box_get_tree_fn__533000077_A", Source: "box.ae", Declaring: &A_arbace_box_get_tree_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_get_tree_fn__533000085_A_class, Name: "arbace.box$get_tree$fn__533000085", Modifiers: 25, Simple: "fn__533000085", Go: "arbace/aot_arbace_box.A_arbace_box_get_tree_fn__533000085_A", Source: "box.ae", Declaring: &A_arbace_box_get_tree_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_hash_bytes_A_class, Name: "arbace.box$hash_bytes", Modifiers: 25, Simple: "hash_bytes", Go: "arbace/aot_arbace_box.A_arbace_box_hash_bytes_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_hex_A_class, Name: "arbace.box$hex", Modifiers: 25, Simple: "hex", Go: "arbace/aot_arbace_box.A_arbace_box_hex_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_load_A_class, Name: "arbace.box$load", Modifiers: 25, Simple: "load", Go: "arbace/aot_arbace_box.A_arbace_box_load_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_load_fs_BANG__A_class, Name: "arbace.box$load_fs_BANG_", Modifiers: 25, Simple: "load_fs_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_load_fs_BANG__A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_load_ref_A_class, Name: "arbace.box$load_ref", Modifiers: 25, Simple: "load_ref", Go: "arbace/aot_arbace_box.A_arbace_box_load_ref_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_A_class, Name: "arbace.box$put", Modifiers: 25, Simple: "put", Go: "arbace/aot_arbace_box.A_arbace_box_put_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_BANG__A_class, Name: "arbace.box$put_BANG_", Modifiers: 25, Simple: "put_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_put_BANG__A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_dir_A_class, Name: "arbace.box$put_dir", Modifiers: 25, Simple: "put_dir", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_dir_iter__533000056__533000060_A_class, Name: "arbace.box$put_dir$iter__533000056__533000060", Modifiers: 25, Simple: "iter__533000056__533000060", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_iter__533000056__533000060_A", Source: "box.ae", Declaring: &A_arbace_box_put_dir_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class, Name: "arbace.box$put_dir$iter__533000056__533000060$fn__533000061", Modifiers: 25, Simple: "fn__533000061", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A", Source: "box.ae", Declaring: &A_arbace_box_put_dir_iter__533000056__533000060_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_class, Name: "arbace.box$put_dir$iter__533000056__533000060$fn__533000061$fn__533000062", Modifiers: 25, Simple: "fn__533000062", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A", Source: "box.ae", Declaring: &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_file_A_class, Name: "arbace.box$put_file", Modifiers: 25, Simple: "put_file", Go: "arbace/aot_arbace_box.A_arbace_box_put_file_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_put_tree_A_class, Name: "arbace.box$put_tree", Modifiers: 25, Simple: "put_tree", Go: "arbace/aot_arbace_box.A_arbace_box_put_tree_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_quote_str_A_class, Name: "arbace.box$quote_str", Modifiers: 25, Simple: "quote_str", Go: "arbace/aot_arbace_box.A_arbace_box_quote_str_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_ref_A_class, Name: "arbace.box$ref", Modifiers: 25, Simple: "ref", Go: "arbace/aot_arbace_box.A_arbace_box_ref_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_ref_BANG__A_class, Name: "arbace.box$ref_BANG_", Modifiers: 25, Simple: "ref_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_ref_BANG__A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_ref_BANG__answer_A_class, Name: "arbace.box$ref_BANG__answer", Modifiers: 25, Simple: "ref_BANG__answer", Go: "arbace/aot_arbace_box.A_arbace_box_ref_BANG__answer_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_request_text_A_class, Name: "arbace.box$request_text", Modifiers: 25, Simple: "request_text", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_request_text_iter__533000096__533000100_A_class, Name: "arbace.box$request_text$iter__533000096__533000100", Modifiers: 25, Simple: "iter__533000096__533000100", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_iter__533000096__533000100_A", Source: "box.ae", Declaring: &A_arbace_box_request_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class, Name: "arbace.box$request_text$iter__533000096__533000100$fn__533000101", Modifiers: 25, Simple: "fn__533000101", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A", Source: "box.ae", Declaring: &A_arbace_box_request_text_iter__533000096__533000100_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_class, Name: "arbace.box$request_text$iter__533000096__533000100$fn__533000101$fn__533000102", Modifiers: 25, Simple: "fn__533000102", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A", Source: "box.ae", Declaring: &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_request_text_v__533000094_A_class, Name: "arbace.box$request_text$v__533000094", Modifiers: 25, Simple: "v__533000094", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_v__533000094_A", Source: "box.ae", Declaring: &A_arbace_box_request_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_result_A_class, Name: "arbace.box$result", Modifiers: 25, Simple: "result", Go: "arbace/aot_arbace_box.A_arbace_box_result_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_run_A_class, Name: "arbace.box$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_box.A_arbace_box_run_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_save_fs_BANG__A_class, Name: "arbace.box$save_fs_BANG_", Modifiers: 25, Simple: "save_fs_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_save_fs_BANG__A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_size_A_class, Name: "arbace.box$size", Modifiers: 25, Simple: "size", Go: "arbace/aot_arbace_box.A_arbace_box_size_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_spawn_A_class, Name: "arbace.box$spawn", Modifiers: 25, Simple: "spawn", Go: "arbace/aot_arbace_box.A_arbace_box_spawn_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_spawn_wait_A_class, Name: "arbace.box$spawn_wait", Modifiers: 25, Simple: "spawn_wait", Go: "arbace/aot_arbace_box.A_arbace_box_spawn_wait_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_store_QMARK__A_class, Name: "arbace.box$store_QMARK_", Modifiers: 25, Simple: "store_QMARK_", Go: "arbace/aot_arbace_box.A_arbace_box_store_QMARK__A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_tree_A_class, Name: "arbace.box$tree", Modifiers: 25, Simple: "tree", Go: "arbace/aot_arbace_box.A_arbace_box_tree_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_tree_get_A_class, Name: "arbace.box$tree_get", Modifiers: 25, Simple: "tree_get", Go: "arbace/aot_arbace_box.A_arbace_box_tree_get_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_tree_get_fn__533000088_A_class, Name: "arbace.box$tree_get$fn__533000088", Modifiers: 25, Simple: "fn__533000088", Go: "arbace/aot_arbace_box.A_arbace_box_tree_get_fn__533000088_A", Source: "box.ae", Declaring: &A_arbace_box_tree_get_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_tree_name_QMARK__A_class, Name: "arbace.box$tree_name_QMARK_", Modifiers: 25, Simple: "tree_name_QMARK_", Go: "arbace/aot_arbace_box.A_arbace_box_tree_name_QMARK__A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_tree_name_QMARK__fn__533000038_A_class, Name: "arbace.box$tree_name_QMARK_$fn__533000038", Modifiers: 25, Simple: "fn__533000038", Go: "arbace/aot_arbace_box.A_arbace_box_tree_name_QMARK__fn__533000038_A", Source: "box.ae", Declaring: &A_arbace_box_tree_name_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_tree_text_A_class, Name: "arbace.box$tree_text", Modifiers: 25, Simple: "tree_text", Go: "arbace/aot_arbace_box.A_arbace_box_tree_text_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_tree_text_fn__533000042_A_class, Name: "arbace.box$tree_text$fn__533000042", Modifiers: 25, Simple: "fn__533000042", Go: "arbace/aot_arbace_box.A_arbace_box_tree_text_fn__533000042_A", Source: "box.ae", Declaring: &A_arbace_box_tree_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_utf8_compare_A_class, Name: "arbace.box$utf8_compare", Modifiers: 25, Simple: "utf8_compare", Go: "arbace/aot_arbace_box.A_arbace_box_utf8_compare_A", Source: "box.ae", Declaring: &A_arbace_box_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_box_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_A_New()}; return nil }

var A_arbace_box_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_A_new}

var A_arbace_box_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box.A_arbace_box_A"})

func init() { i := A_arbace_box_A_class.Info(); i.IsInstance = A_arbace_box_A_InstanceOf; i.Init = A_arbace_box_A_Init; i.Table = A_arbace_box_A_members }

var A_arbace_box_answer_A_class *jrt.Class

var A_arbace_box_boxed_QMARK__A_class *jrt.Class

func A_arbace_box_eval533000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_eval533000004_A_New()}; return nil }

var A_arbace_box_eval533000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_eval533000004_A_new}

var A_arbace_box_eval533000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$eval533000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_A_class, Simple: "eval533000004", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000004_A"})

func init() { i := A_arbace_box_eval533000004_A_class.Info(); i.IsInstance = A_arbace_box_eval533000004_A_InstanceOf; i.Table = A_arbace_box_eval533000004_A_members }

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_class *jrt.Class

func A_arbace_box_eval533000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_eval533000008_A_New()}; return nil }

var A_arbace_box_eval533000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_eval533000008_A_new}

var A_arbace_box_eval533000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$eval533000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_A_class, Simple: "eval533000008", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000008_A"})

func init() { i := A_arbace_box_eval533000008_A_class.Info(); i.IsInstance = A_arbace_box_eval533000008_A_InstanceOf; i.Table = A_arbace_box_eval533000008_A_members }

var A_arbace_box_eval533000008_fn__533000009_A_class *jrt.Class

var A_arbace_box_fail_A_class *jrt.Class

var A_arbace_box_fs_dir_A_class *jrt.Class

var A_arbace_box_get_A_class *jrt.Class

var A_arbace_box_get_bytes_A_class *jrt.Class

var A_arbace_box_get_tree_A_class *jrt.Class

var A_arbace_box_get_tree_fn__533000077_A_class *jrt.Class

var A_arbace_box_get_tree_fn__533000085_A_class *jrt.Class

var A_arbace_box_hash_bytes_A_class *jrt.Class

var A_arbace_box_hex_A_class *jrt.Class

var A_arbace_box_load_A_class *jrt.Class

var A_arbace_box_load_fs_BANG__A_class *jrt.Class

var A_arbace_box_load_ref_A_class *jrt.Class

var A_arbace_box_put_A_class *jrt.Class

var A_arbace_box_put_BANG__A_class *jrt.Class

var A_arbace_box_put_dir_A_class *jrt.Class

var A_arbace_box_put_dir_iter__533000056__533000060_A_class *jrt.Class

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class *jrt.Class

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_class *jrt.Class

var A_arbace_box_put_file_A_class *jrt.Class

var A_arbace_box_put_tree_A_class *jrt.Class

var A_arbace_box_quote_str_A_class *jrt.Class

var A_arbace_box_ref_A_class *jrt.Class

var A_arbace_box_ref_BANG__A_class *jrt.Class

var A_arbace_box_ref_BANG__answer_A_class *jrt.Class

var A_arbace_box_request_text_A_class *jrt.Class

var A_arbace_box_request_text_iter__533000096__533000100_A_class *jrt.Class

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class *jrt.Class

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_class *jrt.Class

var A_arbace_box_request_text_v__533000094_A_class *jrt.Class

var A_arbace_box_result_A_class *jrt.Class

var A_arbace_box_run_A_class *jrt.Class

var A_arbace_box_save_fs_BANG__A_class *jrt.Class

var A_arbace_box_size_A_class *jrt.Class

var A_arbace_box_spawn_A_class *jrt.Class

var A_arbace_box_spawn_wait_A_class *jrt.Class

var A_arbace_box_store_QMARK__A_class *jrt.Class

var A_arbace_box_tree_A_class *jrt.Class

var A_arbace_box_tree_get_A_class *jrt.Class

var A_arbace_box_tree_get_fn__533000088_A_class *jrt.Class

var A_arbace_box_tree_name_QMARK__A_class *jrt.Class

var A_arbace_box_tree_name_QMARK__fn__533000038_A_class *jrt.Class

var A_arbace_box_tree_text_A_class *jrt.Class

var A_arbace_box_tree_text_fn__533000042_A_class *jrt.Class

var A_arbace_box_utf8_compare_A_class *jrt.Class

func A_arbace_box__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box__init_A_Load__O()}; return nil }

func A_arbace_box__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box__init_A_New()}; return nil }

var A_arbace_box__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box__init_A_invoke, New: A_arbace_box__init_A_new}

var A_arbace_box__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box.A_arbace_box__init_A", Source: "box.ae"})

func init() { i := A_arbace_box__init_A_class.Info(); i.IsInstance = A_arbace_box__init_A_InstanceOf; i.Init = A_arbace_box__init_A_Init; i.Table = A_arbace_box__init_A_members }
