//line aot_arbace_box.ae:1
package aot_arbace_box

import (
	"arbace/aot_arbace_box_host"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_edn"
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_New() *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A { A_arbace_box_A_Init(); t := &A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_A_const_1, A_arbace_box_A_const_2, A_arbace_box_A_const_3); lang.IFn_Cast(A_arbace_box_A_const_4.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_5, A_arbace_box_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :4:1
func A_arbace_box_eval533000008_fn__533000009_A_New() *A_arbace_box_eval533000008_fn__533000009_A { A_arbace_box_A_Init(); t := &A_arbace_box_eval533000008_fn__533000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_box_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_box_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_A_const_10.GetRawRoot__O(), A_arbace_box_A_const_11) }







































func A_arbace_box_fail_A_New() *A_arbace_box_fail_A { A_arbace_box_A_Init(); t := &A_arbace_box_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_fail_A) Invoke_O_O_O_O__O(self, kind__0, msg__1, data__2 any) any { var tmp1 any; var root_22 any = A_arbace_box_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_24 lang.IFn; if
											linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = msg__1; var arg_26 any; var root_27 any = A_arbace_box_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = data__2; var arg_31 any = A_arbace_box_A_const_14; var arg_32 any = kind__0; if linked_28 == nil { arg_26 = ifn_29.Invoke_O_O_O__O(arg_30, arg_31, arg_32) } else { arg_26 = linked_28.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_27, arg_30, arg_31, arg_32) }; if linked_23 == nil { tmp1 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; /*line :44:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_box_answer_A_New() *A_arbace_box_answer_A { A_arbace_box_A_Init(); t := &A_arbace_box_answer_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_answer_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_answer_A) InvokePrim_O_J_O_O__O(self any, code__0 int64, what__1, data__2 any) any { var G__533000013__4_ int64 = code__0; switch


	int32(G__533000013__4_) { case -5: if -5 == G__533000013__4_ {


		var root_34 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, A_arbace_box_fail_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = A_arbace_box_A_const_16; var arg_38 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, what__1, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_box_A_const_18.Invoke_O__O(data__2)))).Ref(); var arg_39 any = data__2; if linked_35 == nil { return ifn_36.Invoke_O_O_O__O(arg_37, arg_38, arg_39) } else { return linked_35.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_34, arg_37, arg_38, arg_39) } }
//line :50:1
	case -4: if -4 == G__533000013__4_ {

		var root_44 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, A_arbace_box_fail_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_box_A_const_19; var arg_48 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(); var arg_49 any = data__2; if linked_45 == nil { return ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { return linked_45.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) } }
//line :50:1
	case -3: if -3 == G__533000013__4_ {
		var root_50 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_box_fail_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = A_arbace_box_A_const_20; var arg_54 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(); var arg_55 any = data__2; if linked_51 == nil { return ifn_52.Invoke_O_O_O__O(arg_53, arg_54, arg_55) } else { return linked_51.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_50, arg_53, arg_54, arg_55) } }
//line :50:1
	default:}; var root_56 any =




	A_arbace_box_A_const_15.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, A_arbace_box_fail_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = A_arbace_box_A_const_21; var arg_60 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(); var arg_61 any = data__2; if linked_57 == nil { return ifn_58.Invoke_O_O_O__O(arg_59, arg_60, arg_61) } else { return linked_57.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_56, arg_59, arg_60, arg_61) } }
//line :47:1
func (t *A_arbace_box_answer_A) Invoke_O_O_O_O__O(self, p_code__0, what__1, data__2 any) any { return t.InvokePrim_O_J_O_O__O(self, lang.RT_LongCast_O__J_NoInit(p_code__0), what__1, data__2) }









func A_arbace_box_hash_bytes_A_New() *A_arbace_box_hash_bytes_A { A_arbace_box_A_Init(); t := &A_arbace_box_hash_bytes_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Ctor() {}
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Invoke_O_O_O__O(self, h__0, what__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any; var root_62 any = A_arbace_box_A_const_23.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = h__0; if linked_63 == nil { and__1927000168__auto____3 = ifn_64.Invoke_O__O(arg_65) } else { and__1927000168__auto____3 = linked_63.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_66 any = A_arbace_box_A_const_24.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = A_arbace_box_A_const_25; var arg_70 any = h__0; if linked_67 == nil { tmp1 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { tmp1 = linked_67.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { } else {
		var root_71 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_box_fail_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_box_A_const_26; var arg_75 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, what__1, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(h__0))).Ref(); var arg_76 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_72 == nil { ifn_73.Invoke_O_O_O__O(arg_74, arg_75, arg_76) } else { linked_72.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_71, arg_74, arg_75, arg_76) } }
//line :57:1
	var b__3 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J_NoInit(32); var i__5 int64 = 0; L1: for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, n__1927000701__auto____4) {
			var tmp2 *jrt.ByteArray = jrt.ByteArray_Cast(b__3); var tmp3 int32 = lang.RT_IntCast_J__I_NoInit(i__5); var tmp4 any; var root_81 any = A_arbace_box_A_const_28.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = h__0; var arg_85 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, i__5)).Ref(); var arg_86 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(2, lang.Numbers_Multiply_J_J__J_NoInit(2, i__5))).Ref(); if linked_82 == nil { tmp4 = ifn_83.Invoke_O_O_O__O(arg_84, arg_85, arg_86) } else { tmp4 = linked_82.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_81, arg_84, arg_85, arg_86) }; jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aset_B1_I_B__B_NoInit(tmp2, tmp3, lang.RT_UncheckedByteCast_I__B_NoInit(jrt.Integer_ParseInt_String_I__I_NoInit(jrt.String_Cast(tmp4), lang.RT_IntCast_J__I_NoInit(16)))))
//line :63:1
			i__5 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__5); continue L1 }
//line :57:1
		break L1 }; return b__3
}








func A_arbace_box_hex_A_New() *A_arbace_box_hex_A { A_arbace_box_A_Init(); t := &A_arbace_box_hex_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_box_hex_A) Ctor() {}
//line :67:1
func (t *A_arbace_box_hex_A) Invoke_O_O__O(self, b__0 any) any { var sb__2 any = jrt.StringBuilder_New_I(lang.RT_IntCast_J__I_NoInit(64)); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0))); var i__4 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var x__5 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__4))).Ref()), 255)

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__5, 4)), lang.RT_IntCast_J__I_NoInit(16)))
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__5, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :71:1
		i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :67:1
	break L1 }; var root_87 any =







	A_arbace_box_A_const_29.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = sb__2; if linked_88 == nil { return ifn_89.Invoke_O__O(arg_90) } else { return linked_88.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_87, arg_90) } }

func A_arbace_box_store_QMARK__A_New() *A_arbace_box_store_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_store_QMARK__A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Ctor() {}
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Invoke_O__O(self any) any {


	var tmp1 bool; var na_91 any; var root_92 any = A_arbace_box_A_const_30.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_box_host.A_arbace_box_host_status_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; if linked_93 == nil { na_91 = ifn_94.Invoke__O() } else { na_91 = linked_93.(*aot_arbace_box_host.A_arbace_box_host_status_A).Invoke_O__O(root_92) }; if jrt.Long_InstanceOf(na_91) { var n0_95 int64 = jrt.NN(jrt.Long_Cast(na_91)).LongValue__J(); tmp1 = n0_95 == 0 } else { if jrt.Double_InstanceOf(na_91) { var n0_95_2 float64 = jrt.NN(jrt.Double_Cast(na_91)).DoubleValue__D(); tmp1 = n0_95_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_91) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref()
}
func A_arbace_box_put_A_New() *A_arbace_box_put_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_put_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_put_A) Invoke_O_O__O(self, x__0 any) any { var b__2 any; var tmp1 any; var root_96 any = A_arbace_box_A_const_23.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_98 lang.IFn; if


	linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = x__0; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(tmp1) { b__2 = jrt.NN(jrt.String_Cast(x__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else { var tmp2 any; var root_100 any = A_arbace_box_A_const_31.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_bytes_QMARK__A_fn_class); var ifn_102 lang.IFn
		if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = x__0; if linked_101 == nil { tmp2 = ifn_102.Invoke_O__O(arg_103) } else { tmp2 = linked_101.(*aot_arbace_core.A_arbace_core_bytes_QMARK__A).Invoke_O_O__O(root_100, arg_103) }
//line :85:1
		if jrt.J2g_Truth(tmp2) { b__2 = x__0 } else { if A_arbace_box_A_const_32 != nil { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_24, nil); var tmp4 any; var root_104 any = A_arbace_box_A_const_33.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_106 lang.IFn


			if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = x__0; if linked_105 == nil { tmp4 = ifn_106.Invoke_O__O(arg_107) } else { tmp4 = linked_105.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_104, arg_107) }
//line :85:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4))))) } else { b__2 = nil } } }; var h__3 any = /*line :82:1*/lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var code__4 any; var root_108 any = A_arbace_box_A_const_34.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_box_host.A_arbace_box_host_put_A_fn_class); var ifn_110 lang.IFn; if







	linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = b__2; var arg_112 any = h__3; if linked_109 == nil { code__4 = ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { code__4 = linked_109.(*aot_arbace_box_host.A_arbace_box_host_put_A).Invoke_O_O_O__O(root_108, arg_111, arg_112) }; var tmp5 bool; var na_117 any = code__4; if
	jrt.Long_InstanceOf(na_117) { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_117)).LongValue__J(); tmp5 = n0_118 == 0 } else { if jrt.Double_InstanceOf(na_117) { var n0_118_2 float64 = jrt.NN(jrt.Double_Cast(na_117)).DoubleValue__D(); tmp5 = n0_118_2 == 0.0 } else { tmp5 = lang.Numbers_IsZero_O__Z_NoInit(na_117) } }; if tmp5 { } else {
		var root_119 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_119, A_arbace_box_answer_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = code__4; var arg_123 any = Lit_25; var tmp6 any = A_arbace_box_A_const_37; var arg_124 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__2))).Ref())); if linked_120 == nil { ifn_121.Invoke_O_O_O__O(arg_122, arg_123, arg_124) } else { linked_120.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_119, lang.RT_LongCast_O__J_NoInit(arg_122), arg_123, arg_124) } }; var root_113 any =
	A_arbace_box_A_const_35.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_box_hex_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = h__3; if linked_114 == nil { return ifn_115.Invoke_O__O(arg_116) } else { return linked_114.(*A_arbace_box_hex_A).Invoke_O_O__O(root_113, arg_116) } }

func A_arbace_box_get_bytes_A_New() *A_arbace_box_get_bytes_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_bytes_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_box_get_bytes_A) Ctor() {}
//line :95:1
func (t *A_arbace_box_get_bytes_A) Invoke_O_O__O(self, h__0 any) any { var hb__2 any; var root_125 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_box_hash_bytes_A_fn_class); var ifn_127 lang.IFn; if


	linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = h__0; var arg_129 any = Lit_11; if linked_126 == nil { hb__2 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { hb__2 = linked_126.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; var n__3 any; var root_130 any = /*line :95:1*/A_arbace_box_A_const_39.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_box_host.A_arbace_box_host_size_A_fn_class); var ifn_132 lang.IFn; if



	linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = hb__2; if linked_131 == nil { n__3 = ifn_132.Invoke_O__O(arg_133) } else { n__3 = linked_131.(*aot_arbace_box_host.A_arbace_box_host_size_A).Invoke_O_O__O(root_130, arg_133) }; if
	lang.Util_Equiv_O_J__Z_NoInit(n__3, -1) { return nil } else { var tmp1 bool
		var na_134 any = n__3
		if jrt.Long_InstanceOf(na_134) { var n0_135 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); tmp1 = n0_135 < 0 } else { if jrt.Double_InstanceOf(na_134) { var n0_135_2 float64 = jrt.NN(jrt.Double_Cast(na_134)).DoubleValue__D(); tmp1 = n0_135_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_134) } }
//line :100:1
		if tmp1 {

			var root_136 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_136, A_arbace_box_answer_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = n__3; var arg_140 any = Lit_11; var arg_141 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_136, lang.RT_LongCast_O__J_NoInit(arg_139), arg_140, arg_141) } } else {
//line :100:1
				if A_arbace_box_A_const_32 != nil {


					var root_142 any = A_arbace_box_A_const_40.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_box_host.A_arbace_box_host_read_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = hb__2; if linked_143 == nil { return ifn_144.Invoke_O__O(arg_145) } else { return linked_143.(*aot_arbace_box_host.A_arbace_box_host_read_A).Invoke_O_O__O(root_142, arg_145) } } else {
//line :100:1
						return nil } } } }




func A_arbace_box_get_A_New() *A_arbace_box_get_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_box_get_A) Ctor() {}
//line :105:1
func (t *A_arbace_box_get_A) Invoke_O_O__O(self, h__0 any) any { var temp__1927000414__auto____2 any; var root_146 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_box_get_bytes_A_fn_class); var ifn_148 lang.IFn; if


	linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = h__0; if linked_147 == nil { temp__1927000414__auto____2 = ifn_148.Invoke_O__O(arg_149) } else { temp__1927000414__auto____2 = linked_147.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var b__3 any = temp__1927000414__auto____2; return jrt.String_New_B1_Charset(jrt.ByteArray_Cast(b__3), jrt.StandardCharsets_UTF_8) } else { return nil } }


func A_arbace_box_size_A_New() *A_arbace_box_size_A { A_arbace_box_A_Init(); t := &A_arbace_box_size_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_box_size_A) Ctor() {}
//line :111:1
func (t *A_arbace_box_size_A) Invoke_O_O__O(self, h__0 any) any { var n__2 any; var root_150 any = A_arbace_box_A_const_39.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_box_host.A_arbace_box_host_size_A_fn_class); var ifn_152 lang.IFn; if


	linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_154 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, A_arbace_box_hash_bytes_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = h__0; var arg_158 any = Lit_61; if linked_155 == nil { arg_153 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { arg_153 = linked_155.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }; if linked_151 == nil { n__2 = ifn_152.Invoke_O__O(arg_153) } else { n__2 = linked_151.(*aot_arbace_box_host.A_arbace_box_host_size_A).Invoke_O_O__O(root_150, arg_153) }; if
	lang.Util_Equiv_O_J__Z_NoInit(n__2, -1) { return nil } else { var tmp1 bool
		var na_159 any = n__2
		if jrt.Long_InstanceOf(na_159) { var n0_160 int64 = jrt.NN(jrt.Long_Cast(na_159)).LongValue__J(); tmp1 = n0_160 < 0 } else { if jrt.Double_InstanceOf(na_159) { var n0_160_2 float64 = jrt.NN(jrt.Double_Cast(na_159)).DoubleValue__D(); tmp1 = n0_160_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_159) } }
//line :115:1
		if tmp1 {

			var root_161 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_161, A_arbace_box_answer_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = n__2; var arg_165 any = Lit_61; var arg_166 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_162 == nil { return ifn_163.Invoke_O_O_O__O(arg_164, arg_165, arg_166) } else { return linked_162.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_161, lang.RT_LongCast_O__J_NoInit(arg_164), arg_165, arg_166) } } else {
//line :115:1
				if A_arbace_box_A_const_32 != nil { return n__2 } else { return nil } } } }




func A_arbace_box_ref_A_New() *A_arbace_box_ref_A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_box_ref_A) Ctor() {}
//line :120:1
func (t *A_arbace_box_ref_A) Invoke_O_O__O(self, name__0 any) any { var h__2 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var code__3 any; var root_167 any = A_arbace_box_A_const_42.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_box_host.A_arbace_box_host_ref_A_fn_class); var ifn_169 lang.IFn; if



	linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any; var root_172 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = name__0; if linked_173 == nil { arg_170 = ifn_174.Invoke_O__O(arg_175) } else { arg_170 = linked_173.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_172, arg_175) }; var arg_171 any = h__2; if linked_168 == nil { code__3 = ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { code__3 = linked_168.(*aot_arbace_box_host.A_arbace_box_host_ref_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) }; var G__533000022__4_ any = code__3; if
	jrt.Number_InstanceOf(G__533000022__4_) { switch jrt.Number_Cast(G__533000022__4_).IntValue__I() { case -1: if lang.Util_Equiv_O_O__Z_NoInit(G__533000022__4_, A_arbace_box_A_const_43) { return nil }; case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__533000022__4_, A_arbace_box_A_const_44) {
		var root_177 any = A_arbace_box_A_const_35.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_box_hex_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = h__2; if linked_178 == nil { return ifn_179.Invoke_O__O(arg_180) } else { return linked_178.(*A_arbace_box_hex_A).Invoke_O_O__O(root_177, arg_180) } }
//line :125:1
	default:} }; var root_181 any =


	A_arbace_box_A_const_36.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_181, A_arbace_box_answer_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = code__3; var arg_185 any = Lit_34; var arg_186 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__0)); if linked_182 == nil { return ifn_183.Invoke_O_O_O__O(arg_184, arg_185, arg_186) } else { return linked_182.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_181, lang.RT_LongCast_O__J_NoInit(arg_184), arg_185, arg_186) } }

func A_arbace_box_ref_BANG__answer_A_New() *A_arbace_box_ref_BANG__answer_A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_BANG__answer_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Ctor() {}
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Invoke_O_O_O_O__O(self, code__0, name__1, h__2 any) any {
	if lang.Util_Equiv_O_J__Z_NoInit(code__0, -2) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 bool; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_J__Z_NoInit(code__0, -1)

		if and__1927000168__auto____4 { var tmp2 any; var root_187 any = A_arbace_box_A_const_45.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_box_size_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = h__2; if linked_188 == nil { tmp2 = ifn_189.Invoke_O__O(arg_190) } else { tmp2 = linked_188.(*A_arbace_box_size_A).Invoke_O_O__O(root_187, arg_190) }; tmp1 = lang.Util_Identical_O_O__Z_NoInit(tmp2, nil) } else { tmp1 = and__1927000168__auto____4 }
//line :131:1
		if tmp1 {


			var root_191 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, A_arbace_box_fail_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = A_arbace_box_A_const_46; var arg_195 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(); var arg_196 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__1, A_arbace_box_A_const_27, h__2)); if linked_192 == nil { return ifn_193.Invoke_O_O_O__O(arg_194, arg_195, arg_196) } else { return linked_192.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_191, arg_194, arg_195, arg_196) } } else {
//line :131:1
				if A_arbace_box_A_const_32 != nil {



					var root_197 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_197, A_arbace_box_answer_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = code__0; var arg_201 any = Lit_35; var arg_202 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__1, A_arbace_box_A_const_27, h__2)); if linked_198 == nil { return ifn_199.Invoke_O_O_O__O(arg_200, arg_201, arg_202) } else { return linked_198.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_197, lang.RT_LongCast_O__J_NoInit(arg_200), arg_201, arg_202) } } else {
//line :131:1
						return nil
					}
			}
	}
}

func A_arbace_box_ref_BANG__A_New() *A_arbace_box_ref_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_BANG__A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Ctor() {}
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O_O__O(self, name__0, h__1, old__2 any) any { var ob__4 any; if






	lang.Util_Identical_O_O__Z_NoInit(old__2, nil) { ob__4 = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref() } else { var root_203 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, A_arbace_box_hash_bytes_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = old__2; var arg_207 any = Lit_35; if linked_204 == nil { ob__4 = ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { ob__4 = linked_204.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } }; var code__5 any; var root_208 any = /*line :137:1*/A_arbace_box_A_const_47.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_box_host.A_arbace_box_host_set_ref_A_fn_class); var ifn_210 lang.IFn; if







	linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var root_214 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = name__0; if linked_215 == nil { arg_211 = ifn_216.Invoke_O__O(arg_217) } else { arg_211 = linked_215.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_214, arg_217) }; var arg_212 any; var root_218 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, A_arbace_box_hash_bytes_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = h__1; var arg_222 any = Lit_35; if linked_219 == nil { arg_212 = ifn_220.Invoke_O_O__O(arg_221, arg_222) } else { arg_212 = linked_219.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_218, arg_221, arg_222) }; var arg_213 any = ob__4; if linked_209 == nil { code__5 = ifn_210.Invoke_O_O_O__O(arg_211, arg_212, arg_213) } else { code__5 = linked_209.(*aot_arbace_box_host.A_arbace_box_host_set_ref_A).Invoke_O_O_O_O__O(root_208, arg_211, arg_212, arg_213) }; var or__1927000174__auto____6 bool; var na_223 any = code__5; if
	jrt.Long_InstanceOf(na_223) { var n0_224 int64 = jrt.NN(jrt.Long_Cast(na_223)).LongValue__J(); or__1927000174__auto____6 = n0_224 == 0 } else { if jrt.Double_InstanceOf(na_223) { var n0_224_2 float64 = jrt.NN(jrt.Double_Cast(na_223)).DoubleValue__D(); or__1927000174__auto____6 = n0_224_2 == 0.0 } else { or__1927000174__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_223) } }; if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var root_225 any = A_arbace_box_A_const_48.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, A_arbace_box_ref_BANG__answer_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = code__5; var arg_229 any = name__0; var arg_230 any = h__1; if linked_226 == nil { return ifn_227.Invoke_O_O_O__O(arg_228, arg_229, arg_230) } else { return linked_226.(*A_arbace_box_ref_BANG__answer_A).Invoke_O_O_O_O__O(root_225, arg_228, arg_229, arg_230) } } }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O__O(self, name__0, h__1 any) any { var code__3 any; var root_231 any = A_arbace_box_A_const_47.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_box_host.A_arbace_box_host_set_ref_A_fn_class); var ifn_233 lang.IFn; if



	linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var root_237 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = name__0; if linked_238 == nil { arg_234 = ifn_239.Invoke_O__O(arg_240) } else { arg_234 = linked_238.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_237, arg_240) }; var arg_235 any; var root_241 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_box_hash_bytes_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = h__1; var arg_245 any = Lit_35; if linked_242 == nil { arg_235 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { arg_235 = linked_242.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }; var arg_236 any; if linked_232 == nil { code__3 = ifn_233.Invoke_O_O_O__O(arg_234, arg_235, arg_236) } else { code__3 = linked_232.(*aot_arbace_box_host.A_arbace_box_host_set_ref_A).Invoke_O_O_O_O__O(root_231, arg_234, arg_235, arg_236) }; var or__1927000174__auto____4 bool; var na_246 any = code__3; if
	jrt.Long_InstanceOf(na_246) { var n0_247 int64 = jrt.NN(jrt.Long_Cast(na_246)).LongValue__J(); or__1927000174__auto____4 = n0_247 == 0 } else { if jrt.Double_InstanceOf(na_246) { var n0_247_2 float64 = jrt.NN(jrt.Double_Cast(na_246)).DoubleValue__D(); or__1927000174__auto____4 = n0_247_2 == 0.0 } else { or__1927000174__auto____4 = lang.Numbers_IsZero_O__Z_NoInit(na_246) } }; if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var root_248 any = A_arbace_box_A_const_48.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, A_arbace_box_ref_BANG__answer_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = code__3; var arg_252 any = name__0; var arg_253 any = h__1; if linked_249 == nil { return ifn_250.Invoke_O_O_O__O(arg_251, arg_252, arg_253) } else { return linked_249.(*A_arbace_box_ref_BANG__answer_A).Invoke_O_O_O_O__O(root_248, arg_251, arg_252, arg_253) } } }





func A_arbace_box_put_BANG__A_New() *A_arbace_box_put_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_put_BANG__A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_box_put_BANG__A) Ctor() {}
//line :148:1
func (t *A_arbace_box_put_BANG__A) Invoke_O_O_O__O(self, name__0, x__1 any) any { var h__3 any; var root_254 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, A_arbace_box_put_A_fn_class); var ifn_256 lang.IFn; if


	linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = x__1; if linked_255 == nil { h__3 = ifn_256.Invoke_O__O(arg_257) } else { h__3 = linked_255.(*A_arbace_box_put_A).Invoke_O_O__O(root_254, arg_257) }; var root_258 any =
	A_arbace_box_A_const_50.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_box_ref_BANG__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = name__0; var arg_262 any = h__3; if linked_259 == nil { ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { linked_259.(*A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_258, arg_261, arg_262) }; return h__3 }


func A_arbace_box_load_A_New() *A_arbace_box_load_A { A_arbace_box_A_Init(); t := &A_arbace_box_load_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_box_load_A) Ctor() {}
//line :155:1
func (t *A_arbace_box_load_A) Invoke_O_O__O(self, name__0 any) any { var G__533000027__2_ any; var root_263 any = A_arbace_box_A_const_51.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, A_arbace_box_ref_A_fn_class); var ifn_265 lang.IFn; if


	linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = name__0; if linked_264 == nil { G__533000027__2_ = ifn_265.Invoke_O__O(arg_266) } else { G__533000027__2_ = linked_264.(*A_arbace_box_ref_A).Invoke_O_O__O(root_263, arg_266) }; if lang.Util_Identical_O_O__Z_NoInit(G__533000027__2_, nil) { return nil } else { var root_267 any = A_arbace_box_A_const_52.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, A_arbace_box_get_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = G__533000027__2_; if linked_268 == nil { return ifn_269.Invoke_O__O(arg_270) } else { return linked_268.(*A_arbace_box_get_A).Invoke_O_O__O(root_267, arg_270) } } }

func A_arbace_box_load_ref_A_New() *A_arbace_box_load_ref_A { A_arbace_box_A_Init(); t := &A_arbace_box_load_ref_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_box_load_ref_A) Ctor() {}
//line :160:1
func (t *A_arbace_box_load_ref_A) Invoke_O_O__O(self, name__0 any) any { var src__2 any; var root_271 any = A_arbace_box_A_const_53.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_box_load_A_fn_class); var ifn_273 lang.IFn; if



	linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = name__0; if linked_272 == nil { src__2 = ifn_273.Invoke_O__O(arg_274) } else { src__2 = linked_272.(*A_arbace_box_load_A).Invoke_O_O__O(root_271, arg_274) }; if
	lang.Util_Identical_O_O__Z_NoInit(src__2, nil) {
		var root_279 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, A_arbace_box_fail_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_box_A_const_54; var arg_283 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)).Ref(); var arg_284 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__0)); if linked_280 == nil { ifn_281.Invoke_O_O_O__O(arg_282, arg_283, arg_284) } else { linked_280.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_279, arg_282, arg_283, arg_284) } }; var tmp1 jrt.Reader_I =
	jrt.StringReader_New_String(jrt.String_Cast(src__2)); var tmp2 *jrt.String = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)); var tmp3 any; var root_275 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = name__0; if linked_276 == nil { tmp3 = ifn_277.Invoke_O__O(arg_278) } else { tmp3 = linked_276.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_275, arg_278) }; return lang.Compiler_Load_Reader_String_String__O_NoInit(tmp1, tmp2, jrt.String_Cast(tmp3)) }

func A_arbace_box_boxed_QMARK__A_New() *A_arbace_box_boxed_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_boxed_QMARK__A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Ctor() {}
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Invoke_O__O(self any) any {
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_5, jrt.System_GetProperty_String__String(Lit_6).Ref())).Ref()
}
func A_arbace_box_fs_dir_A_New() *A_arbace_box_fs_dir_A { A_arbace_box_A_Init(); t := &A_arbace_box_fs_dir_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_box_fs_dir_A) Ctor() {}
//line :172:1
func (t *A_arbace_box_fs_dir_A) Invoke_O_O_O__O(self, dir__0, what__1 any) any {
	var tmp1 any; var root_285 any = A_arbace_box_A_const_55.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_287 lang.IFn
	if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = dir__0; if linked_286 == nil { tmp1 = ifn_287.Invoke_O__O(arg_288) } else { tmp1 = linked_286.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_285, arg_288) }
//line :173:1
	if jrt.J2g_Truth(tmp1) {
		var root_289 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = dir__0; if linked_290 == nil { return ifn_291.Invoke_O__O(arg_292) } else { return linked_290.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_289, arg_292) } } else {
//line :173:1
			var tmp2 any; var root_293 any = A_arbace_box_A_const_56.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, A_arbace_box_boxed_QMARK__A_fn_class); var ifn_295 lang.IFn

			if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; if linked_294 == nil { tmp2 = ifn_295.Invoke__O() } else { tmp2 = linked_294.(*A_arbace_box_boxed_QMARK__A).Invoke_O__O(root_293) }
//line :173:1
			if jrt.J2g_Truth(tmp2) { return Lit_9 } else { if A_arbace_box_A_const_32 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, what__1, nil))))) } else { return nil
			}
			}
		}
}

func A_arbace_box_save_fs_BANG__A_New() *A_arbace_box_save_fs_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_save_fs_BANG__A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Ctor() {}
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any; var root_296 any = A_arbace_box_A_const_57.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_box_fs_dir_A_fn_class); var ifn_298 lang.IFn; if





	linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = dir__1; var arg_300 any = Lit_58; if linked_297 == nil { d__3 = ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { d__3 = linked_297.(*A_arbace_box_fs_dir_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) }; var err__4 any; var root_301 any = /*line :179:1*/A_arbace_box_A_const_58.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_303 lang.IFn; if






	linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = A_arbace_box_A_const_59; var arg_305 any = A_arbace_box_A_const_60; if linked_302 == nil { err__4 = ifn_303.Invoke_O_O__O(arg_304, arg_305) } else { err__4 = linked_302.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_301, arg_304, arg_305) }; var tar__5 any; var root_306 any = /*line :179:1*/A_arbace_box_A_const_61.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_box_host.A_arbace_box_host_tar_A_fn_class); var ifn_308 lang.IFn; if







	linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = d__3; var arg_310 any = err__4; if linked_307 == nil { tar__5 = ifn_308.Invoke_O_O__O(arg_309, arg_310) } else { tar__5 = linked_307.(*aot_arbace_box_host.A_arbace_box_host_tar_A).Invoke_O_O_O__O(root_306, arg_309, arg_310) }; if
	lang.Util_Identical_O_O__Z_NoInit(tar__5, nil) {
		var root_316 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_box_fail_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_box_A_const_21; var tmp1 *jrt.Class = A_arbace_box_A_const_63; var arg_320 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_60, jrt.RefArrayOf(jrt.Object_class, err__4, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_J__I_NoInit(0)).Ref())))).Ref(); var arg_321 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0, A_arbace_box_A_const_64, d__3)); if linked_317 == nil { ifn_318.Invoke_O_O_O__O(arg_319, arg_320, arg_321) } else { linked_317.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_316, arg_319, arg_320, arg_321) } }; var root_311 any =
	A_arbace_box_A_const_62.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, A_arbace_box_put_BANG__A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = ref__0; var arg_315 any = tar__5; if linked_312 == nil { return ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { return linked_312.(*A_arbace_box_put_BANG__A).Invoke_O_O_O__O(root_311, arg_314, arg_315) } }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {



	var root_322 any = A_arbace_box_A_const_65.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_box_save_fs_BANG__A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = ref__0; var arg_326 any; if linked_323 == nil { return ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { return linked_323.(*A_arbace_box_save_fs_BANG__A).Invoke_O_O_O__O(root_322, arg_325, arg_326)
	}
}






func A_arbace_box_load_fs_BANG__A_New() *A_arbace_box_load_fs_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_load_fs_BANG__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Ctor() {}
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any; var root_327 any = A_arbace_box_A_const_57.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, A_arbace_box_fs_dir_A_fn_class); var ifn_329 lang.IFn; if




	linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = dir__1; var arg_331 any = Lit_18; if linked_328 == nil { d__3 = ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { d__3 = linked_328.(*A_arbace_box_fs_dir_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }; var tar__4 any; var G__533000033__4_ any; var root_332 any = /*line :192:1*/A_arbace_box_A_const_51.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, A_arbace_box_ref_A_fn_class); var ifn_334 lang.IFn; if





	linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = ref__0; if linked_333 == nil { G__533000033__4_ = ifn_334.Invoke_O__O(arg_335) } else { G__533000033__4_ = linked_333.(*A_arbace_box_ref_A).Invoke_O_O__O(root_332, arg_335) }; if lang.Util_Identical_O_O__Z_NoInit(G__533000033__4_, nil) { tar__4 = nil } else { var root_336 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, A_arbace_box_get_bytes_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = G__533000033__4_; if linked_337 == nil { tar__4 = ifn_338.Invoke_O__O(arg_339) } else { tar__4 = linked_337.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_336, arg_339) } }; if
	lang.Util_Identical_O_O__Z_NoInit(tar__4, nil) {
		var root_340 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, A_arbace_box_fail_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = A_arbace_box_A_const_54; var arg_344 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, ref__0)).Ref(); var arg_345 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0)); if linked_341 == nil { ifn_342.Invoke_O_O_O__O(arg_343, arg_344, arg_345) } else { linked_341.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_340, arg_343, arg_344, arg_345) } }; var temp__1927000414__auto____5 any; var root_346 any = /*line :192:1*/A_arbace_box_A_const_66.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_box_host.A_arbace_box_host_untar_A_fn_class); var ifn_348 lang.IFn; if








	linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = tar__4; var arg_350 any = d__3; if linked_347 == nil { temp__1927000414__auto____5 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { temp__1927000414__auto____5 = linked_347.(*aot_arbace_box_host.A_arbace_box_host_untar_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var e__6 any = temp__1927000414__auto____5; var root_351 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_box_fail_A_fn_class); var ifn_353 lang.IFn
		if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = A_arbace_box_A_const_21; var arg_355 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, e__6)).Ref(); var arg_356 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0, A_arbace_box_A_const_64, d__3)); if linked_352 == nil { ifn_353.Invoke_O_O_O__O(arg_354, arg_355, arg_356) } else { linked_352.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_351, arg_354, arg_355, arg_356) } }; return nil }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {


	var root_357 any = A_arbace_box_A_const_67.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, A_arbace_box_load_fs_BANG__A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = ref__0; var arg_361 any; if linked_358 == nil { return ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { return linked_358.(*A_arbace_box_load_fs_BANG__A).Invoke_O_O_O__O(root_357, arg_360, arg_361)
	}
}













func A_arbace_box_quote_str_A_New() *A_arbace_box_quote_str_A { A_arbace_box_A_Init(); t := &A_arbace_box_quote_str_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_quote_str_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_quote_str_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_CharSequence_CharSequence__String(Lit_31, Lit_32)).Replace_CharSequence_CharSequence__String(Lit_30, Lit_33).Ref(), nil)).Ref()
}
func A_arbace_box_utf8_compare_A_New() *A_arbace_box_utf8_compare_A { A_arbace_box_A_Init(); t := &A_arbace_box_utf8_compare_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Ctor() {}
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { { var x__3 any = jrt.NN(jrt.String_Cast(a__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var y__4 any = jrt.NN(jrt.String_Cast(b__1)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var n__5 int64 = lang.Numbers_Min_J_J__J_NoInit(int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(x__3))), int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(y__4)))); var i__6 int64 = 0; L1: for {






	if lang.Numbers_Lt_J_J__Z_NoInit(i__6, n__5) { var c__7 int32 = lang.Util_Compare_O_O__I_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(x__3), lang.RT_IntCast_J__I_NoInit(i__6))).Ref()), 255)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(y__4), lang.RT_IntCast_J__I_NoInit(i__6))).Ref()), 255)).Ref())

		if lang.Numbers_IsZero_J__Z_NoInit(int64(c__7)) { i__6 = lang.Numbers_Inc_J__J_NoInit(i__6); continue L1 } else { return jrt.Integer_ValueOf_I__Integer_NoInit(c__7).Ref() } } else {
			return jrt.Integer_ValueOf_I__Integer_NoInit(lang.Util_Compare_O_O__I_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(x__3))).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(y__4))).Ref())).Ref() } } }; /*line :216:1*/panic("j2g: unreachable") }











func A_arbace_box_tree_name_QMARK__A_New() *A_arbace_box_tree_name_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_name_QMARK__A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Ctor() {}
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_362 any = A_arbace_box_A_const_23.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_364 lang.IFn; if
										linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = n__0; if linked_363 == nil { and__1927000168__auto____2 = ifn_364.Invoke_O__O(arg_365) } else { and__1927000168__auto____2 = linked_363.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_362, arg_365) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_366 any = A_arbace_box_A_const_68.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any; var root_370 any = A_arbace_box_A_const_69.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_box_A_const_70; var arg_374 any = n__0; if linked_371 == nil { arg_369 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { arg_369 = linked_371.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; if linked_367 == nil { and__1927000168__auto____3 = ifn_368.Invoke_O__O(arg_369) } else { and__1927000168__auto____3 = linked_367.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_366, arg_369) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
											var root_375 any = A_arbace_box_A_const_71.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var fnbody__391 any = A_arbace_box_tree_name_QMARK__fn__533000038_A_New(); var tmp1 *jrt.Class; var fncls__390 *jrt.Class = A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class; if fncls__390 == nil { var fncls__390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class = fncls__390d; tmp1 = fncls__390d } else { tmp1 = fncls__390 }; arg_378 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__391, tmp1, nil); var arg_379 any = n__0; if linked_376 == nil { return ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { return linked_376.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_375, arg_378, arg_379) } } else {
//line :229:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }
func A_arbace_box_tree_name_QMARK__fn__533000038_A_New() *A_arbace_box_tree_name_QMARK__fn__533000038_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_name_QMARK__fn__533000038_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Ctor() {}
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Invoke_O_O__O(self, p1__533000037_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_380 any = A_arbace_box_A_const_72.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = p1__533000037_SHARP___1; var arg_384 any = A_arbace_box_A_const_73; if linked_381 == nil { and__1927000168__auto____2 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { and__1927000168__auto____2 = linked_381.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_IntCast_O__I_NoInit(p1__533000037_SHARP___1)), 32); if and__1927000168__auto____3 { var root_385 any = A_arbace_box_A_const_72.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(p1__533000037_SHARP___1)).Ref(); var arg_389 any = A_arbace_box_A_const_74; if linked_386 == nil { return ifn_387.Invoke_O_O__O(arg_388, arg_389) } else { return linked_386.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_385, arg_388, arg_389) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_box_tree_text_A_New() *A_arbace_box_tree_text_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_text_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_box_tree_text_A) Ctor() {}
//line :232:1
func (t *A_arbace_box_tree_text_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_69, nil, Lit_41); var tmp2 any; var root_392 any = A_arbace_box_A_const_75.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_394 lang.IFn











	if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_box_A_const_29.GetRawRoot__O(); var arg_396 any; var root_397 any = A_arbace_box_A_const_76.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_399 lang.IFn
//line :246:1
	if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = Lit_70; var arg_401 any; var root_402 any = A_arbace_box_A_const_77.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_404 lang.IFn
//line :237:1
	if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var fnbody__442 any = A_arbace_box_tree_text_fn__533000042_A_New(); var tmp3 *jrt.Class; var fncls__441 *jrt.Class = A_arbace_box_tree_text_fn__533000042_A_fn_class; if fncls__441 == nil { var fncls__441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_box_tree_text_fn__533000042_A_fn_class = fncls__441d; tmp3 = fncls__441d } else { tmp3 = fncls__441 }; arg_405 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__442, tmp3, nil); var arg_406 any; var root_443 any = A_arbace_box_A_const_83.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_445 lang.IFn
//line :236:1
	if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_box_A_const_84.GetRawRoot__O(); var arg_447 any = A_arbace_box_A_const_85.GetRawRoot__O(); var arg_448 any = m__0; if linked_444 == nil { arg_406 = ifn_445.Invoke_O_O_O__O(arg_446, arg_447, arg_448) } else { arg_406 = linked_444.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O_O__O(root_443, arg_446, arg_447, arg_448) }
	if linked_403 == nil { arg_401 = ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { arg_401 = linked_403.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_402, arg_405, arg_406)
	}







	if linked_398 == nil { arg_396 = ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { arg_396 = linked_398.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) }
	if linked_393 == nil { tmp2 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { tmp2 = linked_393.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }
//line :235:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref()
}
func A_arbace_box_tree_text_fn__533000042_A_New() *A_arbace_box_tree_text_fn__533000042_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_text_fn__533000042_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Ctor() {}
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Invoke_O_O__O(self, p__533000041__1 any) any { var vec__533000043__2 any = p__533000041__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000043__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__533000046__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000043__2, lang.RT_IntCast_J__I_NoInit(1), nil); var kind__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000046__4, lang.RT_IntCast_J__I_NoInit(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000046__4, lang.RT_IntCast_J__I_NoInit(1), nil); var size__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000046__4, lang.RT_IntCast_J__I_NoInit(2), nil); var e__8 any = vec__533000046__4; var tmp1 any; var root_422 any = A_arbace_box_A_const_82.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, A_arbace_box_tree_name_QMARK__A_fn_class); var ifn_424 lang.IFn; if
												linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = n__3; if linked_423 == nil { tmp1 = ifn_424.Invoke_O__O(arg_425) } else { tmp1 = linked_423.(*A_arbace_box_tree_name_QMARK__A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(tmp1) { } else {
													var root_426 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, A_arbace_box_fail_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = A_arbace_box_A_const_81; var arg_430 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(n__3))).Ref(); var arg_431 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, n__3)); if linked_427 == nil { ifn_428.Invoke_O_O_O__O(arg_429, arg_430, arg_431) } else { linked_427.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_426, arg_429, arg_430, arg_431) } }; var root_436 any =
												A_arbace_box_A_const_38.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_box_hash_bytes_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = h__6; var arg_440 any = Lit_73; if linked_437 == nil { ifn_438.Invoke_O_O__O(arg_439, arg_440) } else { linked_437.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_436, arg_439, arg_440) }; var tmp2 /*line :241:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_56, nil); var tmp3 any; var root_407 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_box_quote_str_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = n__3; if linked_408 == nil { tmp3 = ifn_409.Invoke_O__O(arg_410) } else { tmp3 = linked_408.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_407, arg_410) }; var tmp4 any = tmp3; var tmp5 any; var G__533000049__12_ any = kind__5; L1:
												switch { default: switch lang.Util_Hash_O__I_NoInit(G__533000049__12_) >> 2 & 3 { case 1: if any(G__533000049__12_) == any(A_arbace_box_A_const_79) {
													tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(size__7)).Ref(), nil)).Ref()
//line :242:1
		break L1 }; case 2: if any(G__533000049__12_) == any(A_arbace_box_A_const_64) {

			tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, h__6, nil)).Ref()
//line :242:1
			break L1 }; case 3: if any(G__533000049__12_) == any(A_arbace_box_A_const_80) {
				tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(size__7)).Ref(), nil)).Ref()
//line :242:1
				break L1 }; default:
	}

		var root_412 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, A_arbace_box_fail_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_box_A_const_81; var arg_416 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(e__8))).Ref(); var arg_417 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, n__3)); if linked_413 == nil { tmp5 = ifn_414.Invoke_O_O_O__O(arg_415, arg_416, arg_417) } else { tmp5 = linked_413.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_412, arg_415, arg_416, arg_417) }}; return /*line :241:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref() }








func A_arbace_box_put_tree_A_New() *A_arbace_box_put_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_tree_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_box_put_tree_A) Ctor() {}
//line :250:1
func (t *A_arbace_box_put_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var root_449 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, A_arbace_box_put_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_453 any = A_arbace_box_A_const_86.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, A_arbace_box_tree_text_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = m__0; if linked_454 == nil { arg_452 = ifn_455.Invoke_O__O(arg_456) } else { arg_452 = linked_454.(*A_arbace_box_tree_text_A).Invoke_O_O__O(root_453, arg_456) }; if linked_450 == nil { return ifn_451.Invoke_O__O(arg_452) } else { return linked_450.(*A_arbace_box_put_A).Invoke_O_O__O(root_449, arg_452)
	} }
func A_arbace_box_tree_A_New() *A_arbace_box_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_box_tree_A) Ctor() {}
//line :255:1
func (t *A_arbace_box_tree_A) Invoke_O_O__O(self, h__0 any) any { var G__533000053__2_ any; var root_457 any = A_arbace_box_A_const_52.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, A_arbace_box_get_A_fn_class); var ifn_459 lang.IFn; if


	linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = h__0; if linked_458 == nil { G__533000053__2_ = ifn_459.Invoke_O__O(arg_460) } else { G__533000053__2_ = linked_458.(*A_arbace_box_get_A).Invoke_O_O__O(root_457, arg_460) }; if lang.Util_Identical_O_O__Z_NoInit(G__533000053__2_, nil) { return nil } else { var root_461 any = A_arbace_box_A_const_87.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = G__533000053__2_; if linked_462 == nil { return ifn_463.Invoke_O__O(arg_464) } else { return linked_462.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_461, arg_464) } } }

func A_arbace_box_put_file_A_New() *A_arbace_box_put_file_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_file_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_box_put_file_A) Ctor() {}
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O_O__O(self, x__0, exec__1 any) any { var h__3 any; var root_465 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, A_arbace_box_put_A_fn_class); var ifn_467 lang.IFn; if




	linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = x__0; if linked_466 == nil { h__3 = ifn_467.Invoke_O__O(arg_468) } else { h__3 = linked_466.(*A_arbace_box_put_A).Invoke_O_O__O(root_465, arg_468) }; var tmp1 /*line :260:1*/*lang.Keyword; if





	jrt.J2g_Truth(exec__1) { tmp1 = A_arbace_box_A_const_79 } else { tmp1 = A_arbace_box_A_const_80 }; var tmp2 any = /*line :260:1*/tmp1.Ref(); var tmp3 any; var root_469 any = A_arbace_box_A_const_45.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, A_arbace_box_size_A_fn_class); var ifn_471 lang.IFn; if





	linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = h__3; if linked_470 == nil { tmp3 = ifn_471.Invoke_O__O(arg_472) } else { tmp3 = linked_470.(*A_arbace_box_size_A).Invoke_O_O__O(root_469, arg_472) }; return /*line :260:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, h__3, tmp3) }
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O__O(self, x__0 any) any {


	var root_473 any = A_arbace_box_A_const_88.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, A_arbace_box_put_file_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = x__0; var arg_477 any = jrt.Boolean_FALSE.Ref(); if linked_474 == nil { return ifn_475.Invoke_O_O__O(arg_476, arg_477) } else { return linked_474.(*A_arbace_box_put_file_A).Invoke_O_O_O__O(root_473, arg_476, arg_477)
	}
}


func A_arbace_box_put_dir_A_New() *A_arbace_box_put_dir_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_box_put_dir_A) Ctor() {}
//line :268:1
func (t *A_arbace_box_put_dir_A) Invoke_O_O__O(self, dir__0 any) any { var d__2 any; var tmp1 any; var root_478 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_480 lang.IFn; if



	linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = dir__0; if linked_479 == nil { tmp1 = ifn_480.Invoke_O__O(arg_481) } else { tmp1 = linked_479.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_478, arg_481) }; d__2 = /*line :268:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); var fs__3 any = jrt.File_Cast(d__2).ListFiles__File1().Ref(); if





	lang.Util_Identical_O_O__Z_NoInit(fs__3, nil) {
		var root_571 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, A_arbace_box_fail_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = A_arbace_box_A_const_21; var arg_575 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, dir__0)).Ref(); var arg_576 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_64, dir__0)); if linked_572 == nil { ifn_573.Invoke_O_O_O__O(arg_574, arg_575, arg_576) } else { linked_572.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_571, arg_574, arg_575, arg_576) } }; var root_482 any =
	A_arbace_box_A_const_89.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_box_put_tree_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any; var root_486 any = A_arbace_box_A_const_90.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_488 lang.IFn; if
	linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_490 any; var iter__1927001039__auto____4 any; var fnbody__570 any = A_arbace_box_put_dir_iter__533000056__533000060_A_New(); var tmp2 *jrt.Class; var fncls__569 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class; if
	fncls__569 == nil { var fncls__569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class = fncls__569d; tmp2 = fncls__569d } else { tmp2 = fncls__569 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__570, tmp2, nil); arg_490 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__3); if /*line :277:1*/ linked_487 == nil { arg_485 = ifn_488.Invoke_O_O__O(arg_489, arg_490) } else { arg_485 = linked_487.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_486, arg_489, arg_490) }; if /*line :276:1*/ linked_483 == nil { return ifn_484.Invoke_O__O(arg_485) } else { return linked_483.(*A_arbace_box_put_tree_A).Invoke_O_O__O(root_482, arg_485) } }

func A_arbace_box_put_dir_iter__533000056__533000060_A_New() *A_arbace_box_put_dir_iter__533000056__533000060_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Ctor() {}
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Invoke_O_O__O(self, s__533000057__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__568 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(s__533000057__1, self); var tmp2 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__568); A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class = fncls__567d; tmp2 = fncls__567d } else { tmp2 = fncls__567 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__568, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(p0, p1 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A{}; t.Ctor_O_O(p0, p1); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Ctor_O_O(c__s__533000057, c__iter__533000056 any) { t.F_s__533000057 = c__s__533000057; t.F_iter__533000056 = c__iter__533000056 }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Invoke_O__O(self any) any { { var s__533000057__1 any; var t_ any = t.F_s__533000057; t.F_s__533000057 = nil; s__533000057__1 = t_; for { var temp__1927000414__auto____2 any; var root_491 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = s__533000057__1; if linked_492 == nil { temp__1927000414__auto____2 = ifn_493.Invoke_O__O(arg_494) } else { temp__1927000414__auto____2 = linked_492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_491, arg_494) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__533000057__3 any = temp__1927000414__auto____2; var tmp1 any; var root_495 any = A_arbace_box_A_const_92.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = s__533000057__3; if linked_496 == nil { tmp1 = ifn_497.Invoke_O__O(arg_498) } else { tmp1 = linked_496.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_495, arg_498) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_499 any = A_arbace_box_A_const_93.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = s__533000057__3; if linked_500 == nil { c__1927001037__auto____4 = ifn_501.Invoke_O__O(arg_502) } else { c__1927001037__auto____4 = linked_500.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_499, arg_502) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__533000059__6 any; var root_503 any = A_arbace_box_A_const_94.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_504 == nil { b__533000059__6 = ifn_505.Invoke_O__O(arg_506) } else { b__533000059__6 = linked_504.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_503, arg_506) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__522 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(b__533000059__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__521 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class; if fncls__521 == nil { var fncls__521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__522); A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class = fncls__521d; tmp3 = fncls__521d } else { tmp3 = fncls__521 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__522, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_523 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_528 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = b__533000059__6; if linked_529 == nil { arg_526 = ifn_530.Invoke_O__O(arg_531) } else { arg_526 = linked_529.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_528, arg_531) }; var arg_527 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); var tmp5 any; var root_532 any = A_arbace_box_A_const_99.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = s__533000057__3; if linked_533 == nil { tmp5 = ifn_534.Invoke_O__O(arg_535) } else { tmp5 = linked_533.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_532, arg_535) }; arg_527 = tmp4.Invoke_O__O(tmp5); if linked_524 == nil { return ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { return linked_524.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) } } else { var root_536 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any; var root_541 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = b__533000059__6; if linked_542 == nil { arg_539 = ifn_543.Invoke_O__O(arg_544) } else { arg_539 = linked_542.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_541, arg_544) }; var arg_540 any; if linked_537 == nil { return ifn_538.Invoke_O_O__O(arg_539, arg_540) } else { return linked_537.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_536, arg_539, arg_540) } } } else { var f__4 any; var root_545 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = s__533000057__3; if linked_546 == nil { f__4 = ifn_547.Invoke_O__O(arg_548) } else { f__4 = linked_546.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_545, arg_548) }; var root_549 any = A_arbace_box_A_const_101.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any; var tmp6 any = jrt.File_Cast(f__4).GetName__String().Ref(); var tmp7 any

	if jrt.File_Cast(f__4).IsDirectory__Z() { var tmp8 any = A_arbace_box_A_const_64; var tmp9 any; var root_559 any = A_arbace_box_A_const_96.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, A_arbace_box_put_dir_A_fn_class); var ifn_561 lang.IFn
		if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = f__4; if linked_560 == nil { tmp9 = ifn_561.Invoke_O__O(arg_562) } else { tmp9 = linked_560.(*A_arbace_box_put_dir_A).Invoke_O_O__O(root_559, arg_562) }
//line :280:1
		tmp7 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) } else {

			var root_554 any = A_arbace_box_A_const_88.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, A_arbace_box_put_file_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__4).ToPath__Path()).Ref(); var arg_558 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__4).CanExecute__Z()).Ref(); if linked_555 == nil { tmp7 = ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { tmp7 = linked_555.(*A_arbace_box_put_file_A).Invoke_O_O_O__O(root_554, arg_557, arg_558) } }
//line :278:1
	arg_552 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_553 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); var tmp11 any; var root_563 any = A_arbace_box_A_const_102.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = s__533000057__3; if linked_564 == nil { tmp11 = ifn_565.Invoke_O__O(arg_566) } else { tmp11 = linked_564.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_563, arg_566) }; arg_553 = tmp10.Invoke_O__O(tmp11); if linked_550 == nil { return ifn_551.Invoke_O_O__O(arg_552, arg_553) } else { return linked_550.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_549, arg_552, arg_553) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Ctor_O_I_O(c__b__533000059 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000059 = c__b__533000059; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Invoke_O__O(self any) any { { var i__533000058__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__533000058__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__533000058__1)); var root_507 any = A_arbace_box_A_const_95.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = t.F_b__533000059; var arg_511 any; var tmp2 any = jrt.File_Cast(f__2).GetName__String().Ref(); var tmp3 any

	if jrt.File_Cast(f__2).IsDirectory__Z() { var tmp4 any = A_arbace_box_A_const_64; var tmp5 any; var root_517 any = A_arbace_box_A_const_96.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, A_arbace_box_put_dir_A_fn_class); var ifn_519 lang.IFn
		if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = f__2; if linked_518 == nil { tmp5 = ifn_519.Invoke_O__O(arg_520) } else { tmp5 = linked_518.(*A_arbace_box_put_dir_A).Invoke_O_O__O(root_517, arg_520) }
//line :280:1
		tmp3 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) } else {

			var root_512 any = A_arbace_box_A_const_88.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_box_put_file_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__2).ToPath__Path()).Ref(); var arg_516 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__2).CanExecute__Z()).Ref(); if linked_513 == nil { tmp3 = ifn_514.Invoke_O_O__O(arg_515, arg_516) } else { tmp3 = linked_513.(*A_arbace_box_put_file_A).Invoke_O_O_O__O(root_512, arg_515, arg_516) } }
//line :278:1
	arg_511 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_508 == nil { ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { linked_508.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; i__533000058__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__533000058__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_box_get_tree_A_New() *A_arbace_box_get_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_box_get_tree_A) Ctor() {}
//line :284:1
func (t *A_arbace_box_get_tree_A) Invoke_O_O_O__O(self, h__0, dir__1 any) any { var m__3 any; var root_577 any = A_arbace_box_A_const_103.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, A_arbace_box_tree_A_fn_class); var ifn_579 lang.IFn; if


	linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = h__0; if linked_578 == nil { m__3 = ifn_579.Invoke_O__O(arg_580) } else { m__3 = linked_578.(*A_arbace_box_tree_A).Invoke_O_O__O(root_577, arg_580) }; var d__4 any; var tmp1 any; var root_581 any = /*line :284:1*/A_arbace_box_A_const_29.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_583 lang.IFn; if



	linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = dir__1; if linked_582 == nil { tmp1 = ifn_583.Invoke_O__O(arg_584) } else { tmp1 = linked_582.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_581, arg_584) }; d__4 = /*line :284:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); if




	lang.Util_Identical_O_O__Z_NoInit(m__3, nil) {
		var root_585 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, A_arbace_box_fail_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = A_arbace_box_A_const_46; var arg_589 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(); var arg_590 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_586 == nil { ifn_587.Invoke_O_O_O__O(arg_588, arg_589, arg_590) } else { linked_586.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_585, arg_588, arg_589, arg_590) } };
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(d__4).Mkdirs__Z()); var seq_533000067__5 any; var root_591 any = /*line :284:1*/A_arbace_box_A_const_91.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_593 lang.IFn; if







	linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = m__3; if linked_592 == nil { seq_533000067__5 = ifn_593.Invoke_O__O(arg_594) } else { seq_533000067__5 = linked_592.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_591, arg_594) }; var chunk_533000068__6 any; var count_533000069__7 int64 = 0; var i_533000070__8 int64 = 0; L1:
//line :284:1
	for {







		if lang.Numbers_Lt_J_J__Z_NoInit(i_533000070__8, count_533000069__7) { var vec__533000071__9 any = lang.Indexed_Cast(chunk_533000068__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_533000070__8)); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000071__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__533000074__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000071__9, lang.RT_IntCast_J__I_NoInit(1), nil); var kind__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000074__11, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000074__11, lang.RT_IntCast_J__I_NoInit(1), nil); var f__14 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__10))

			if lang.Util_Equiv_O_O__Z_NoInit(kind__12, A_arbace_box_A_const_64) {
				var root_611 any = A_arbace_box_A_const_104.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, A_arbace_box_get_tree_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = eh__13; var arg_615 any = f__14; if linked_612 == nil { ifn_613.Invoke_O_O__O(arg_614, arg_615) } else { linked_612.(*A_arbace_box_get_tree_A).Invoke_O_O_O__O(root_611, arg_614, arg_615) } } else {
//line :294:1
					var o__15 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__14)); var tmp2 *lang.Compiler_AOTFn; var fnbody__627 any = A_arbace_box_get_tree_fn__533000077_A_New_O_O(o__15, eh__13); var tmp3 *jrt.Class
					var fncls__626 /*line :294:1*/*jrt.Class = A_arbace_box_get_tree_fn__533000077_A_fn_class

					if fncls__626 == nil { var fncls__626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__627); A_arbace_box_get_tree_fn__533000077_A_fn_class = fncls__626d; tmp3 = fncls__626d } else { tmp3 = fncls__626 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__627, tmp3, nil); Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()

					if lang.Util_Equiv_O_O__Z_NoInit(kind__12, A_arbace_box_A_const_79) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__14).SetExecutable_Z__Z(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())) } }
//line :292:1
			seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = seq_533000067__5, chunk_533000068__6, count_533000069__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_533000070__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_595 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = seq_533000067__5; if linked_596 == nil { temp__1927000414__auto____9 = ifn_597.Invoke_O__O(arg_598) } else { temp__1927000414__auto____9 = linked_596.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_595, arg_598) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_533000067__10 any = temp__1927000414__auto____9; var tmp4 any; var root_599 any = A_arbace_box_A_const_92.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = seq_533000067__10; if linked_600 == nil { tmp4 = ifn_601.Invoke_O__O(arg_602) } else { tmp4 = linked_600.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_599, arg_602) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____11 any; var root_603 any = A_arbace_box_A_const_93.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = seq_533000067__10; if linked_604 == nil { c__1927000678__auto____11 = ifn_605.Invoke_O__O(arg_606) } else { c__1927000678__auto____11 = linked_604.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_603, arg_606) }; var tmp5 any; var root_628 any = A_arbace_box_A_const_99.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = seq_533000067__10; if linked_629 == nil { tmp5 = ifn_630.Invoke_O__O(arg_631) } else { tmp5 = linked_629.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_628, arg_631) }; seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = tmp5, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__533000079__11 any; var root_607 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = seq_533000067__10; if linked_608 == nil { vec__533000079__11 = ifn_609.Invoke_O__O(arg_610) } else { vec__533000079__11 = linked_608.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_607, arg_610) }; var n__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000079__11, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__533000082__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000079__11, lang.RT_IntCast_J__I_NoInit(1), nil); var kind__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000082__13, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000082__13, lang.RT_IntCast_J__I_NoInit(1), nil); var f__16 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__12))

				if lang.Util_Equiv_O_O__Z_NoInit(kind__14, A_arbace_box_A_const_64) {
					var root_632 any = A_arbace_box_A_const_104.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, A_arbace_box_get_tree_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = eh__15; var arg_636 any = f__16; if linked_633 == nil { ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { linked_633.(*A_arbace_box_get_tree_A).Invoke_O_O_O__O(root_632, arg_635, arg_636) } } else {
//line :294:1
						var o__17 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__16)); var tmp6 *lang.Compiler_AOTFn; var fnbody__648 any = A_arbace_box_get_tree_fn__533000085_A_New_O_O(eh__15, o__17); var tmp7 *jrt.Class
						var fncls__647 /*line :294:1*/*jrt.Class = A_arbace_box_get_tree_fn__533000085_A_fn_class

						if fncls__647 == nil { var fncls__647d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__648); A_arbace_box_get_tree_fn__533000085_A_fn_class = fncls__647d; tmp7 = fncls__647d } else { tmp7 = fncls__647 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__648, tmp7, nil); Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()

						if lang.Util_Equiv_O_O__Z_NoInit(kind__14, A_arbace_box_A_const_79) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__16).SetExecutable_Z__Z(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())) } }
//line :292:1
				var tmp8 any; var root_649 any = A_arbace_box_A_const_105.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = seq_533000067__10; if linked_650 == nil { tmp8 = ifn_651.Invoke_O__O(arg_652) } else { tmp8 = linked_650.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_649, arg_652) }; seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = tmp8, nil, 0, 0; continue L1 } } }
//line :284:1
		break L1 }; return nil }











func A_arbace_box_get_tree_fn__533000077_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000077_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_fn__533000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Ctor_O_O(c__o, c__eh any) { t.F_o = c__o; t.F_eh = c__eh }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any; var root_616 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, A_arbace_box_get_bytes_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = t.F_eh; if linked_617 == nil { or__1927000174__auto____3 = ifn_618.Invoke_O__O(arg_619) } else { or__1927000174__auto____3 = linked_617.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_616, arg_619) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var root_620 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, A_arbace_box_fail_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = A_arbace_box_A_const_46; var arg_624 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var arg_625 any; var tmp4 any = A_arbace_box_A_const_27; var tmp5 any; var t_ any = t.F_eh; t.F_eh = nil; tmp5 = t_; arg_625 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)); if linked_621 == nil { tmp3 = ifn_622.Invoke_O_O_O__O(arg_623, arg_624, arg_625) } else { tmp3 = linked_621.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_620, arg_623, arg_624, arg_625) } }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_15, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp7 any; var t__2 any = t.F_o; t.F_o = nil; tmp7 = t__2; jrt.FileOutputStream_Cast(tmp7).Close__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :296:1
func A_arbace_box_get_tree_fn__533000085_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000085_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_fn__533000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Ctor_O_O(c__eh, c__o any) { t.F_eh = c__eh; t.F_o = c__o }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any; var root_637 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, A_arbace_box_get_bytes_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = t.F_eh; if linked_638 == nil { or__1927000174__auto____3 = ifn_639.Invoke_O__O(arg_640) } else { or__1927000174__auto____3 = linked_638.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_637, arg_640) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var root_641 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, A_arbace_box_fail_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = A_arbace_box_A_const_46; var arg_645 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var arg_646 any; var tmp4 any = A_arbace_box_A_const_27; var tmp5 any; var t_ any = t.F_eh; t.F_eh = nil; tmp5 = t_; arg_646 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)); if linked_642 == nil { tmp3 = ifn_643.Invoke_O_O_O__O(arg_644, arg_645, arg_646) } else { tmp3 = linked_642.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_641, arg_644, arg_645, arg_646) } }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_15, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp7 any; var t__2 any = t.F_o; t.F_o = nil; tmp7 = t__2; jrt.FileOutputStream_Cast(tmp7).Close__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }




func A_arbace_box_tree_get_A_New() *A_arbace_box_tree_get_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_get_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_box_tree_get_A) Ctor() {}
//line :301:1
func (t *A_arbace_box_tree_get_A) Invoke_O_O_O__O(self, h__0, p__1 any) any {


	var root_653 any = A_arbace_box_A_const_106.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any; var fnbody__676 any = A_arbace_box_tree_get_fn__533000088_A_New(); var tmp1 *jrt.Class; var fncls__675 *jrt.Class = A_arbace_box_tree_get_fn__533000088_A_fn_class; if fncls__675 == nil { var fncls__675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_box_tree_get_fn__533000088_A_fn_class = fncls__675d; tmp1 = fncls__675d } else { tmp1 = fncls__675 }; arg_656 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__676, tmp1, nil); var arg_657 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_A_const_64, h__0); var arg_658 any; var root_677 any = A_arbace_box_A_const_109.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_679 lang.IFn




	if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = A_arbace_box_A_const_110.GetRawRoot__O(); var tmp2 *jrt.Class = A_arbace_box_A_const_59; var arg_681 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__1, tmp2, Lit_67, jrt.RefArrayOf(jrt.Object_class, Lit_9)); if linked_678 == nil { arg_658 = ifn_679.Invoke_O_O__O(arg_680, arg_681) } else { arg_658 = linked_678.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_677, arg_680, arg_681) }
//line :304:1
	if linked_654 == nil { return ifn_655.Invoke_O_O_O__O(arg_656, arg_657, arg_658) } else { return linked_654.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_653, arg_656, arg_657, arg_658) } }
//line :304:1
func A_arbace_box_tree_get_fn__533000088_A_New() *A_arbace_box_tree_get_fn__533000088_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_get_fn__533000088_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Ctor() {}
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Invoke_O_O_O__O(self, e__1, n__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = e__1; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any = A_arbace_box_A_const_64; var tmp3 any; var root_659 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = e__1; if linked_660 == nil { tmp3 = ifn_661.Invoke_O__O(arg_662) } else { tmp3 = linked_660.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_659, arg_662) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 any; var root_663 any = A_arbace_box_A_const_103.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, A_arbace_box_tree_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any; var root_667 any = A_arbace_box_A_const_107.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = e__1; if linked_668 == nil { arg_666 = ifn_669.Invoke_O__O(arg_670) } else { arg_666 = linked_668.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_667, arg_670) }; if linked_664 == nil { tmp4 = ifn_665.Invoke_O__O(arg_666) } else { tmp4 = linked_664.(*A_arbace_box_tree_A).Invoke_O_O__O(root_663, arg_666) }; return lang.RT_Get_O_O__O_NoInit(tmp4, n__2) } else {
			var root_671 any = A_arbace_box_A_const_108.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any; if linked_672 == nil { return ifn_673.Invoke_O__O(arg_674) } else { return linked_672.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_671, arg_674)
			}
		}
}







func A_arbace_box_request_text_A_New() *A_arbace_box_request_text_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_box_request_text_A) Ctor() {}
//line :318:1
func (t *A_arbace_box_request_text_A) Invoke_O_O__O(self, p__533000091__0 any) any { var map__533000092__2 any = p__533000091__0; var map__533000092__3 any; if lang.ISeq_InstanceOf(map__533000092__2) { var tmp1 any; var root_682 any = A_arbace_box_A_const_105.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = map__533000092__2; if linked_683 == nil { tmp1 = ifn_684.Invoke_O__O(arg_685) } else { tmp1 = linked_683.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_686 any = A_arbace_box_A_const_111.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = map__533000092__2; if linked_687 == nil { tmp2 = ifn_688.Invoke_O__O(arg_689) } else { tmp2 = linked_687.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_686, arg_689) }; map__533000092__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_690 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = map__533000092__2; if linked_691 == nil { tmp3 = ifn_692.Invoke_O__O(arg_693) } else { tmp3 = linked_691.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_690, arg_693) }; if jrt.J2g_Truth(tmp3) { var root_694 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = map__533000092__2; if linked_695 == nil { map__533000092__3 = ifn_696.Invoke_O__O(arg_697) } else { map__533000092__3 = linked_695.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_694, arg_697) } } else { map__533000092__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__533000092__3 = map__533000092__2 }; var image__4 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_112); var args__5 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_113); var env__6 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_114); var trees__7 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_115); var out__8 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_116); var cwd__9 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_117); var ram__10 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_118); var cpus__11 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_119); var v__12 any; var fnbody__714 any = A_arbace_box_request_text_v__533000094_A_New(); var tmp4 *jrt.Class; var fncls__713 *jrt.Class = A_arbace_box_request_text_v__533000094_A_fn_class; if



	fncls__713 == nil { var fncls__713d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_box_request_text_v__533000094_A_fn_class = fncls__713d; tmp4 = fncls__713d } else { tmp4 = fncls__713 }; v__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__714, tmp4, nil); var root_828 any =
	A_arbace_box_A_const_38.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, A_arbace_box_hash_bytes_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = image__4; var arg_832 any = Lit_38; if linked_829 == nil { ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { linked_829.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) }; var tmp5 /*line :324:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_39, nil, Lit_40, nil, nil, nil, nil, nil, nil, nil, Lit_41); var tmp6 any = lang.IFn_Cast(v__12).Invoke_O__O(args__5); var tmp7 *jrt.String; var tmp8 any; var root_715 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_717 lang.IFn; if
	linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = env__6; if linked_716 == nil { tmp8 = ifn_717.Invoke_O__O(arg_718) } else { tmp8 = linked_716.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_715, arg_718) }; if jrt.J2g_Truth(tmp8) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(v__12).Invoke_O__O(env__6))) } else { tmp7 = nil }; var tmp9 any = /*line :324:1*/tmp7.Ref(); var tmp10 *jrt.String; var tmp11 any; var root_719 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_721 lang.IFn; if

	linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = trees__7; if linked_720 == nil { tmp11 = ifn_721.Invoke_O__O(arg_722) } else { tmp11 = linked_720.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_719, arg_722) }; if jrt.J2g_Truth(tmp11) {
		var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp13 any; var root_723 any = A_arbace_box_A_const_75.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_725 lang.IFn
		if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = A_arbace_box_A_const_29.GetRawRoot__O(); var arg_727 any; var root_728 any = A_arbace_box_A_const_76.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = Lit_45; var arg_732 any; var iter__1927001039__auto____27 any; var fnbody__802 any = A_arbace_box_request_text_iter__533000096__533000100_A_New(); var tmp14 *jrt.Class; var fncls__801 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_A_fn_class; if fncls__801 == nil { var fncls__801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_box_request_text_iter__533000096__533000100_A_fn_class = fncls__801d; tmp14 = fncls__801d } else { tmp14 = fncls__801 }; iter__1927001039__auto____27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__802, tmp14, nil); arg_732 = lang.IFn_Cast(iter__1927001039__auto____27).Invoke_O__O(trees__7); if linked_729 == nil { arg_727 = ifn_730.Invoke_O_O__O(arg_731, arg_732) } else { arg_727 = linked_729.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_728, arg_731, arg_732) }; if linked_724 == nil { tmp13 = ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { tmp13 = linked_724.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_723, arg_726, arg_727) }
//line :327:1
		tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil)) } else {
//line :326:1
			tmp10 = nil }; var tmp15 any = /*line :324:1*/tmp10.Ref(); var tmp16 *jrt.String; var tmp17 any; var root_803 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_805 lang.IFn; if





	linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = out__8; if linked_804 == nil { tmp17 = ifn_805.Invoke_O__O(arg_806) } else { tmp17 = linked_804.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_803, arg_806) }; if jrt.J2g_Truth(tmp17) { var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil); var tmp19 any; var root_807 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, A_arbace_box_quote_str_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = out__8; if linked_808 == nil { tmp19 = ifn_809.Invoke_O__O(arg_810) } else { tmp19 = linked_808.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_807, arg_810) }; tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19)) } else { tmp16 = nil }; var tmp20 any = /*line :324:1*/tmp16.Ref(); var tmp21 *jrt.String; var tmp22 any; var and__1927000168__auto____24 any; var root_811 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_813 lang.IFn; if






	linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = cwd__9; if linked_812 == nil { and__1927000168__auto____24 = ifn_813.Invoke_O__O(arg_814) } else { and__1927000168__auto____24 = linked_812.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_811, arg_814) }; if jrt.J2g_Truth(and__1927000168__auto____24) { var root_815 any = A_arbace_box_A_const_72.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = cwd__9; var arg_819 any = Lit_9; if linked_816 == nil { tmp22 = ifn_817.Invoke_O_O__O(arg_818, arg_819) } else { tmp22 = linked_816.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_815, arg_818, arg_819) } } else { tmp22 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp22) { var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil); var tmp24 any; var root_820 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, A_arbace_box_quote_str_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = cwd__9; if linked_821 == nil { tmp24 = ifn_822.Invoke_O__O(arg_823) } else { tmp24 = linked_821.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_820, arg_823) }; tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24)) } else { tmp21 = nil }; var tmp25 any = /*line :324:1*/tmp21.Ref(); var tmp26 *jrt.String; var tmp27 any; var and__1927000168__auto____24_2 any = ram__10; if







	jrt.J2g_Truth(and__1927000168__auto____24_2) { var tmp28 bool; var na_824 any = ram__10; if jrt.Long_InstanceOf(na_824) { var n0_825 int64 = jrt.NN(jrt.Long_Cast(na_824)).LongValue__J(); tmp28 = n0_825 > 0 } else { if jrt.Double_InstanceOf(na_824) { var n0_825_2 float64 = jrt.NN(jrt.Double_Cast(na_824)).DoubleValue__D(); tmp28 = n0_825_2 > 0.0 } else { tmp28 = lang.Numbers_IsPos_O__Z_NoInit(na_824) } }; tmp27 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp28).Ref() } else { tmp27 = and__1927000168__auto____24_2 }; if jrt.J2g_Truth(tmp27) { tmp26 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_49, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(ram__10)).Ref())) } else { tmp26 = nil }; var tmp29 any = /*line :324:1*/tmp26.Ref(); var tmp30 *jrt.String; var tmp31 any; var and__1927000168__auto____24_3 any = cpus__11; if








	jrt.J2g_Truth(and__1927000168__auto____24_3) { var tmp32 bool; var na_826 any = cpus__11; if jrt.Long_InstanceOf(na_826) { var n0_827 int64 = jrt.NN(jrt.Long_Cast(na_826)).LongValue__J(); tmp32 = n0_827 > 0 } else { if jrt.Double_InstanceOf(na_826) { var n0_827_2 float64 = jrt.NN(jrt.Double_Cast(na_826)).DoubleValue__D(); tmp32 = n0_827_2 > 0.0 } else { tmp32 = lang.Numbers_IsPos_O__Z_NoInit(na_826) } }; tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp32).Ref() } else { tmp31 = and__1927000168__auto____24_3 }; if jrt.J2g_Truth(tmp31) { tmp30 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_50, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(cpus__11)).Ref())) } else { tmp30 = nil }; return /*line :324:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, image__4, nil, tmp6, tmp9, tmp15, tmp20, tmp25, tmp29, tmp30.Ref(), nil)).Ref() }
//line :322:1
func A_arbace_box_request_text_v__533000094_A_New() *A_arbace_box_request_text_v__533000094_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_v__533000094_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Invoke_O_O__O(self, xs__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_44); var tmp2 any; var root_698 any = A_arbace_box_A_const_75.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = A_arbace_box_A_const_29.GetRawRoot__O(); var arg_702 any; var root_703 any = A_arbace_box_A_const_76.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = Lit_56; var arg_707 any; var root_708 any = A_arbace_box_A_const_77.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = A_arbace_box_A_const_78.GetRawRoot__O(); var arg_712 any = xs__1; if linked_709 == nil { arg_707 = ifn_710.Invoke_O_O__O(arg_711, arg_712) } else { arg_707 = linked_709.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_708, arg_711, arg_712) }; if linked_704 == nil { arg_702 = ifn_705.Invoke_O_O__O(arg_706, arg_707) } else { arg_702 = linked_704.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_703, arg_706, arg_707) }; if linked_699 == nil { tmp2 = ifn_700.Invoke_O_O__O(arg_701, arg_702) } else { tmp2 = linked_699.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_698, arg_701, arg_702) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }





func A_arbace_box_request_text_iter__533000096__533000100_A_New() *A_arbace_box_request_text_iter__533000096__533000100_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Ctor() {}
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Invoke_O_O__O(self, s__533000097__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__800 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(self, s__533000097__1); var tmp2 *jrt.Class; var fncls__799 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class; if fncls__799 == nil { var fncls__799d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__800); A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class = fncls__799d; tmp2 = fncls__799d } else { tmp2 = fncls__799 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__800, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(p0, p1 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A{}; t.Ctor_O_O(p0, p1); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Ctor_O_O(c__iter__533000096, c__s__533000097 any) { t.F_iter__533000096 = c__iter__533000096; t.F_s__533000097 = c__s__533000097 }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Invoke_O__O(self any) any { { var s__533000097__1 any; var t_ any = t.F_s__533000097; t.F_s__533000097 = nil; s__533000097__1 = t_; for { var temp__1927000414__auto____2 any; var root_733 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = s__533000097__1; if linked_734 == nil { temp__1927000414__auto____2 = ifn_735.Invoke_O__O(arg_736) } else { temp__1927000414__auto____2 = linked_734.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_733, arg_736) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__533000097__3 any = temp__1927000414__auto____2; var tmp1 any; var root_737 any = A_arbace_box_A_const_92.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = s__533000097__3; if linked_738 == nil { tmp1 = ifn_739.Invoke_O__O(arg_740) } else { tmp1 = linked_738.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_737, arg_740) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_741 any = A_arbace_box_A_const_93.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = s__533000097__3; if linked_742 == nil { c__1927001037__auto____4 = ifn_743.Invoke_O__O(arg_744) } else { c__1927001037__auto____4 = linked_742.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_741, arg_744) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__533000099__6 any; var root_745 any = A_arbace_box_A_const_94.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_746 == nil { b__533000099__6 = ifn_747.Invoke_O__O(arg_748) } else { b__533000099__6 = linked_746.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_745, arg_748) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__759 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(b__533000099__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__758 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class; if fncls__758 == nil { var fncls__758d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__759); A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class = fncls__758d; tmp3 = fncls__758d } else { tmp3 = fncls__758 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__759, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_760 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var root_765 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = b__533000099__6; if linked_766 == nil { arg_763 = ifn_767.Invoke_O__O(arg_768) } else { arg_763 = linked_766.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_765, arg_768) }; var arg_764 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); var tmp5 any; var root_769 any = A_arbace_box_A_const_99.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = s__533000097__3; if linked_770 == nil { tmp5 = ifn_771.Invoke_O__O(arg_772) } else { tmp5 = linked_770.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_769, arg_772) }; arg_764 = tmp4.Invoke_O__O(tmp5); if linked_761 == nil { return ifn_762.Invoke_O_O__O(arg_763, arg_764) } else { return linked_761.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_760, arg_763, arg_764) } } else { var root_773 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any; var root_778 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = b__533000099__6; if linked_779 == nil { arg_776 = ifn_780.Invoke_O__O(arg_781) } else { arg_776 = linked_779.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_778, arg_781) }; var arg_777 any; if linked_774 == nil { return ifn_775.Invoke_O_O__O(arg_776, arg_777) } else { return linked_774.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_773, arg_776, arg_777) } } } else { var vec__533000107__4 any; var root_782 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = s__533000097__3; if linked_783 == nil { vec__533000107__4 = ifn_784.Invoke_O__O(arg_785) } else { vec__533000107__4 = linked_783.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_782, arg_785) }; var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000107__4, lang.RT_IntCast_J__I_NoInit(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000107__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_786 any = A_arbace_box_A_const_101.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_54, nil, Lit_55); var tmp7 any; var root_791 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, A_arbace_box_quote_str_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = p__5; if linked_792 == nil { tmp7 = ifn_793.Invoke_O__O(arg_794) } else { tmp7 = linked_792.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_791, arg_794) }; arg_789 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, h__6, nil)).Ref(); var arg_790 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); var tmp9 any; var root_795 any = A_arbace_box_A_const_102.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = s__533000097__3; if linked_796 == nil { tmp9 = ifn_797.Invoke_O__O(arg_798) } else { tmp9 = linked_796.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_795, arg_798) }; arg_790 = tmp8.Invoke_O__O(tmp9); if linked_787 == nil { return ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { return linked_787.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Ctor_O_I_O(c__b__533000099 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000099 = c__b__533000099; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Invoke_O__O(self any) any { { var i__533000098__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__533000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__533000103__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__533000098__1)); var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000103__2, lang.RT_IntCast_J__I_NoInit(0), nil); var h__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000103__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_749 any = A_arbace_box_A_const_95.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = t.F_b__533000099; var arg_753 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_54, nil, Lit_55); var tmp3 any; var root_754 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_box_quote_str_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = p__3; if linked_755 == nil { tmp3 = ifn_756.Invoke_O__O(arg_757) } else { tmp3 = linked_755.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_754, arg_757) }; arg_753 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, h__4, nil)).Ref(); if linked_750 == nil { ifn_751.Invoke_O_O__O(arg_752, arg_753) } else { linked_750.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_749, arg_752, arg_753) }; i__533000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__533000098__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_box_spawn_A_New() *A_arbace_box_spawn_A { A_arbace_box_A_Init(); t := &A_arbace_box_spawn_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_box_spawn_A) Ctor() {}
//line :336:1
func (t *A_arbace_box_spawn_A) Invoke_O_O__O(self, req__0 any) any { var h__2 any; var tmp1 any; var root_833 any = A_arbace_box_A_const_120.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_835 lang.IFn; if




	linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = req__0; if linked_834 == nil { tmp1 = ifn_835.Invoke_O__O(arg_836) } else { tmp1 = linked_834.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_833, arg_836) }; if jrt.J2g_Truth(tmp1) { var root_837 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, A_arbace_box_put_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var root_841 any = A_arbace_box_A_const_121.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, A_arbace_box_request_text_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = req__0; if linked_842 == nil { arg_840 = ifn_843.Invoke_O__O(arg_844) } else { arg_840 = linked_842.(*A_arbace_box_request_text_A).Invoke_O_O__O(root_841, arg_844) }; if linked_838 == nil { h__2 = ifn_839.Invoke_O__O(arg_840) } else { h__2 = linked_838.(*A_arbace_box_put_A).Invoke_O_O__O(root_837, arg_840) } } else { h__2 = req__0 }; var n__3 any; var root_845 any = /*line :336:1*/A_arbace_box_A_const_122.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_845, aot_arbace_box_host.A_arbace_box_host_spawn_A_fn_class); var ifn_847 lang.IFn; if





	linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any; var root_849 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, A_arbace_box_hash_bytes_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = h__2; var arg_853 any = Lit_62; if linked_850 == nil { arg_848 = ifn_851.Invoke_O_O__O(arg_852, arg_853) } else { arg_848 = linked_850.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_849, arg_852, arg_853) }; if linked_846 == nil { n__3 = ifn_847.Invoke_O__O(arg_848) } else { n__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_846.(*aot_arbace_box_host.A_arbace_box_host_spawn_A).InvokePrim_O_O__J(root_845, arg_848)).Ref() }; var tmp2 bool; var na_854 any = n__3; if
	jrt.Long_InstanceOf(na_854) { var n0_855 int64 = jrt.NN(jrt.Long_Cast(na_854)).LongValue__J(); tmp2 = n0_855 < 0 } else { if jrt.Double_InstanceOf(na_854) { var n0_855_2 float64 = jrt.NN(jrt.Double_Cast(na_854)).DoubleValue__D(); tmp2 = n0_855_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_854) } }; if tmp2 {
		var root_856 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, A_arbace_box_fail_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = A_arbace_box_A_const_21; var arg_860 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(); var arg_861 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_123, h__2)); if linked_857 == nil { ifn_858.Invoke_O_O_O__O(arg_859, arg_860, arg_861) } else { linked_857.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_856, arg_859, arg_860, arg_861) } }; return n__3 }


func A_arbace_box_result_A_New() *A_arbace_box_result_A { A_arbace_box_A_Init(); t := &A_arbace_box_result_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_box_result_A) Ctor() {}
//line :347:1
func (t *A_arbace_box_result_A) Invoke_O_O__O(self, h__0 any) any { var s__2 any; var root_862 any = A_arbace_box_A_const_52.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, A_arbace_box_get_A_fn_class); var ifn_864 lang.IFn; if


	linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = h__0; if linked_863 == nil { s__2 = ifn_864.Invoke_O__O(arg_865) } else { s__2 = linked_863.(*A_arbace_box_get_A).Invoke_O_O__O(root_862, arg_865) }; if
	lang.Util_Identical_O_O__Z_NoInit(s__2, nil) {
		var root_876 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, A_arbace_box_fail_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = A_arbace_box_A_const_46; var arg_880 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(); var arg_881 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_877 == nil { ifn_878.Invoke_O_O_O__O(arg_879, arg_880, arg_881) } else { linked_877.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_876, arg_879, arg_880, arg_881) } }; var root_866 any =
	A_arbace_box_A_const_13.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var root_872 any = A_arbace_box_A_const_87.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = s__2; if linked_873 == nil { arg_869 = ifn_874.Invoke_O__O(arg_875) } else { arg_869 = linked_873.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_872, arg_875) }; var arg_870 any = A_arbace_box_A_const_27; var arg_871 any = h__0; if linked_867 == nil { return ifn_868.Invoke_O_O_O__O(arg_869, arg_870, arg_871) } else { return linked_867.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_866, arg_869, arg_870, arg_871) } }

func A_arbace_box_spawn_wait_A_New() *A_arbace_box_spawn_wait_A { A_arbace_box_A_Init(); t := &A_arbace_box_spawn_wait_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Ctor() {}
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Invoke_O_O__O(self, n__0 any) any { var h__2 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var tmp1 int64; var root_890 any = A_arbace_box_A_const_125.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_890, aot_arbace_box_host.A_arbace_box_host_spawn_await_A_fn_class); var ifn_892 lang.IFn; if



	linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = n__0; var arg_894 any = h__2; if linked_891 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_892.Invoke_O_O__O(arg_893, arg_894)) } else { tmp1 = linked_891.(*aot_arbace_box_host.A_arbace_box_host_spawn_await_A).InvokePrim_O_J_O__J(root_890, lang.RT_LongCast_O__J_NoInit(arg_893), arg_894) }; if lang.Numbers_IsZero_J__Z_NoInit(tmp1) { } else {
		var root_895 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, A_arbace_box_fail_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = A_arbace_box_A_const_21; var arg_899 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_64, nil, Lit_65), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var arg_900 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_126, n__0)); if linked_896 == nil { ifn_897.Invoke_O_O_O__O(arg_898, arg_899, arg_900) } else { linked_896.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_895, arg_898, arg_899, arg_900) } }; var root_882 any =
	A_arbace_box_A_const_124.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, A_arbace_box_result_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var root_886 any = A_arbace_box_A_const_35.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_box_hex_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = h__2; if linked_887 == nil { arg_885 = ifn_888.Invoke_O__O(arg_889) } else { arg_885 = linked_887.(*A_arbace_box_hex_A).Invoke_O_O__O(root_886, arg_889) }; if linked_883 == nil { return ifn_884.Invoke_O__O(arg_885) } else { return linked_883.(*A_arbace_box_result_A).Invoke_O_O__O(root_882, arg_885) } }

func A_arbace_box_run_A_New() *A_arbace_box_run_A { A_arbace_box_A_Init(); t := &A_arbace_box_run_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_box_run_A) Ctor() {}
//line :363:1
func (t *A_arbace_box_run_A) Invoke_O_O__O(self, req__0 any) any {


	var root_901 any = A_arbace_box_A_const_127.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, A_arbace_box_spawn_wait_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var root_905 any = A_arbace_box_A_const_128.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_box_spawn_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = req__0; if linked_906 == nil { arg_904 = ifn_907.Invoke_O__O(arg_908) } else { arg_904 = linked_906.(*A_arbace_box_spawn_A).Invoke_O_O__O(root_905, arg_908) }; if linked_902 == nil { return ifn_903.Invoke_O__O(arg_904) } else { return linked_902.(*A_arbace_box_spawn_wait_A).Invoke_O_O__O(root_901, arg_904)
	}
}













type A_arbace_box_A struct{ jrt.Object }

var A_arbace_box_A_const_pool *jrt.RefArray

var A_arbace_box_A_const_0 *lang.Var

var A_arbace_box_A_const_1 any

var A_arbace_box_A_const_2 *lang.Keyword

var A_arbace_box_A_const_3 any

var A_arbace_box_A_const_4 *lang.Var

var A_arbace_box_A_const_5 any

var A_arbace_box_A_const_6 any

var A_arbace_box_A_const_7 *lang.Var

var A_arbace_box_A_const_8 *lang.Var

var A_arbace_box_A_const_9 *lang.Var

var A_arbace_box_A_const_10 *lang.Var

var A_arbace_box_A_const_11 any

var A_arbace_box_A_const_12 *lang.Var

var A_arbace_box_A_const_13 *lang.Var

var A_arbace_box_A_const_14 *lang.Keyword

var A_arbace_box_A_const_15 *lang.Var

var A_arbace_box_A_const_16 *lang.Keyword

var A_arbace_box_A_const_17 *lang.Var

var A_arbace_box_A_const_18 *lang.Keyword

var A_arbace_box_A_const_19 *lang.Keyword

var A_arbace_box_A_const_20 *lang.Keyword

var A_arbace_box_A_const_21 *lang.Keyword

var A_arbace_box_A_const_22 any

var A_arbace_box_A_const_23 *lang.Var

var A_arbace_box_A_const_24 *lang.Var

var A_arbace_box_A_const_25 any

var A_arbace_box_A_const_26 *lang.Keyword

var A_arbace_box_A_const_27 *lang.Keyword

var A_arbace_box_A_const_28 *lang.Var

var A_arbace_box_A_const_29 *lang.Var

var A_arbace_box_A_const_30 *lang.Var

var A_arbace_box_A_const_31 *lang.Var

var A_arbace_box_A_const_32 *lang.Keyword

var A_arbace_box_A_const_33 *lang.Var

var A_arbace_box_A_const_34 *lang.Var

var A_arbace_box_A_const_35 *lang.Var

var A_arbace_box_A_const_36 *lang.Var

var A_arbace_box_A_const_37 *lang.Keyword

var A_arbace_box_A_const_38 *lang.Var

var A_arbace_box_A_const_39 *lang.Var

var A_arbace_box_A_const_40 *lang.Var

var A_arbace_box_A_const_41 *lang.Var

var A_arbace_box_A_const_42 *lang.Var

var A_arbace_box_A_const_43 any

var A_arbace_box_A_const_44 any

var A_arbace_box_A_const_45 *lang.Var

var A_arbace_box_A_const_46 *lang.Keyword

var A_arbace_box_A_const_47 *lang.Var

var A_arbace_box_A_const_48 *lang.Var

var A_arbace_box_A_const_49 *lang.Var

var A_arbace_box_A_const_50 *lang.Var

var A_arbace_box_A_const_51 *lang.Var

var A_arbace_box_A_const_52 *lang.Var

var A_arbace_box_A_const_53 *lang.Var

var A_arbace_box_A_const_54 *lang.Keyword

var A_arbace_box_A_const_55 *lang.Var

var A_arbace_box_A_const_56 *lang.Var

var A_arbace_box_A_const_57 *lang.Var

var A_arbace_box_A_const_58 *lang.Var

var A_arbace_box_A_const_59 *jrt.Class

var A_arbace_box_A_const_60 any

var A_arbace_box_A_const_61 *lang.Var

var A_arbace_box_A_const_62 *lang.Var

var A_arbace_box_A_const_63 *jrt.Class

var A_arbace_box_A_const_64 *lang.Keyword

var A_arbace_box_A_const_65 *lang.Var

var A_arbace_box_A_const_66 *lang.Var

var A_arbace_box_A_const_67 *lang.Var

var A_arbace_box_A_const_68 *lang.Var

var A_arbace_box_A_const_69 *lang.Var

var A_arbace_box_A_const_70 any

var A_arbace_box_A_const_71 *lang.Var

var A_arbace_box_A_const_72 *lang.Var

var A_arbace_box_A_const_73 any

var A_arbace_box_A_const_74 any

var A_arbace_box_A_const_75 *lang.Var

var A_arbace_box_A_const_76 *lang.Var

var A_arbace_box_A_const_77 *lang.Var

var A_arbace_box_A_const_78 *lang.Var

var A_arbace_box_A_const_79 *lang.Keyword

var A_arbace_box_A_const_80 *lang.Keyword

var A_arbace_box_A_const_81 *lang.Keyword

var A_arbace_box_A_const_82 *lang.Var

var A_arbace_box_A_const_83 *lang.Var

var A_arbace_box_A_const_84 *lang.Var

var A_arbace_box_A_const_85 *lang.Var

var A_arbace_box_A_const_86 *lang.Var

var A_arbace_box_A_const_87 *lang.Var

var A_arbace_box_A_const_88 *lang.Var

var A_arbace_box_A_const_89 *lang.Var

var A_arbace_box_A_const_90 *lang.Var

var A_arbace_box_A_const_91 *lang.Var

var A_arbace_box_A_const_92 *lang.Var

var A_arbace_box_A_const_93 *lang.Var

var A_arbace_box_A_const_94 *lang.Var

var A_arbace_box_A_const_95 *lang.Var

var A_arbace_box_A_const_96 *lang.Var

var A_arbace_box_A_const_97 *lang.Var

var A_arbace_box_A_const_98 *lang.Var

var A_arbace_box_A_const_99 *lang.Var

var A_arbace_box_A_const_100 *lang.Var

var A_arbace_box_A_const_101 *lang.Var

var A_arbace_box_A_const_102 *lang.Var

var A_arbace_box_A_const_103 *lang.Var

var A_arbace_box_A_const_104 *lang.Var

var A_arbace_box_A_const_105 *lang.Var

var A_arbace_box_A_const_106 *lang.Var

var A_arbace_box_A_const_107 *lang.Var

var A_arbace_box_A_const_108 *lang.Var

var A_arbace_box_A_const_109 *lang.Var

var A_arbace_box_A_const_110 *lang.Var

var A_arbace_box_A_const_111 *lang.Var

var A_arbace_box_A_const_112 *lang.Keyword

var A_arbace_box_A_const_113 *lang.Keyword

var A_arbace_box_A_const_114 *lang.Keyword

var A_arbace_box_A_const_115 *lang.Keyword

var A_arbace_box_A_const_116 *lang.Keyword

var A_arbace_box_A_const_117 *lang.Keyword

var A_arbace_box_A_const_118 *lang.Keyword

var A_arbace_box_A_const_119 *lang.Keyword

var A_arbace_box_A_const_120 *lang.Var

var A_arbace_box_A_const_121 *lang.Var

var A_arbace_box_A_const_122 *lang.Var

var A_arbace_box_A_const_123 *lang.Keyword

var A_arbace_box_A_const_124 *lang.Var

var A_arbace_box_A_const_125 *lang.Var

var A_arbace_box_A_const_126 *lang.Keyword

var A_arbace_box_A_const_127 *lang.Var

var A_arbace_box_A_const_128 *lang.Var

var A_arbace_box_A_init jrt.ClassInit

func A_arbace_box_A_Init() { if !A_arbace_box_A_init.Done() { A_arbace_box_A_init.Run(A_arbace_box_A_clinit) } }

func A_arbace_box_A_clinit() { A_arbace_box_A_clinit_p0(); A_arbace_box_A_clinit_p1(); A_arbace_box_A_clinit_p2(); A_arbace_box_A_clinit_p3(); A_arbace_box_A_clinit_p4(); A_arbace_box_A_clinit_p5(); A_arbace_box_A_clinit_p6(); A_arbace_box_A_clinit_p7(); A_arbace_box_A_clinit_p8(); A_arbace_box_A_clinit_p9(); A_arbace_box_A_clinit_p10() }

func A_arbace_box_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 166); A_arbace_box_A_const_0 = lang.Var_Cast(A_arbace_box_A_const_pool.A[37]); A_arbace_box_A_const_1 = A_arbace_box_A_const_pool.A[38]; A_arbace_box_A_const_2 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[39]); A_arbace_box_A_const_3 = A_arbace_box_A_const_pool.A[40]; A_arbace_box_A_const_4 = lang.Var_Cast(A_arbace_box_A_const_pool.A[41]); A_arbace_box_A_const_5 = A_arbace_box_A_const_pool.A[42]; A_arbace_box_A_const_6 = A_arbace_box_A_const_pool.A[43]; A_arbace_box_A_const_7 = lang.Var_Cast(A_arbace_box_A_const_pool.A[44]); A_arbace_box_A_const_8 = lang.Var_Cast(A_arbace_box_A_const_pool.A[45]); A_arbace_box_A_const_9 = lang.Var_Cast(A_arbace_box_A_const_pool.A[46]); A_arbace_box_A_const_10 = lang.Var_Cast(A_arbace_box_A_const_pool.A[47]); A_arbace_box_A_const_11 = A_arbace_box_A_const_pool.A[48] }

func A_arbace_box_A_clinit_p1() { A_arbace_box_A_const_12 = lang.Var_Cast(A_arbace_box_A_const_pool.A[49]); A_arbace_box_A_const_13 = lang.Var_Cast(A_arbace_box_A_const_pool.A[50]); A_arbace_box_A_const_14 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[51]); A_arbace_box_A_const_15 = lang.Var_Cast(A_arbace_box_A_const_pool.A[52]); A_arbace_box_A_const_16 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[53]); A_arbace_box_A_const_17 = lang.Var_Cast(A_arbace_box_A_const_pool.A[54]); A_arbace_box_A_const_18 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[55]); A_arbace_box_A_const_19 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[56]); A_arbace_box_A_const_20 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[57]); A_arbace_box_A_const_21 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[58]); A_arbace_box_A_const_22 = A_arbace_box_A_const_pool.A[59]; A_arbace_box_A_const_23 = lang.Var_Cast(A_arbace_box_A_const_pool.A[60]) }

func A_arbace_box_A_clinit_p2() { A_arbace_box_A_const_24 = lang.Var_Cast(A_arbace_box_A_const_pool.A[61]); A_arbace_box_A_const_25 = A_arbace_box_A_const_pool.A[62]; A_arbace_box_A_const_26 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[63]); A_arbace_box_A_const_27 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[64]); A_arbace_box_A_const_28 = lang.Var_Cast(A_arbace_box_A_const_pool.A[65]); A_arbace_box_A_const_29 = lang.Var_Cast(A_arbace_box_A_const_pool.A[66]); A_arbace_box_A_const_30 = lang.Var_Cast(A_arbace_box_A_const_pool.A[67]); A_arbace_box_A_const_31 = lang.Var_Cast(A_arbace_box_A_const_pool.A[68]); A_arbace_box_A_const_32 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[69]); A_arbace_box_A_const_33 = lang.Var_Cast(A_arbace_box_A_const_pool.A[70]); A_arbace_box_A_const_34 = lang.Var_Cast(A_arbace_box_A_const_pool.A[71]); A_arbace_box_A_const_35 = lang.Var_Cast(A_arbace_box_A_const_pool.A[72]) }

func A_arbace_box_A_clinit_p3() { A_arbace_box_A_const_36 = lang.Var_Cast(A_arbace_box_A_const_pool.A[73]); A_arbace_box_A_const_37 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[74]); A_arbace_box_A_const_38 = lang.Var_Cast(A_arbace_box_A_const_pool.A[75]); A_arbace_box_A_const_39 = lang.Var_Cast(A_arbace_box_A_const_pool.A[76]); A_arbace_box_A_const_40 = lang.Var_Cast(A_arbace_box_A_const_pool.A[77]); A_arbace_box_A_const_41 = lang.Var_Cast(A_arbace_box_A_const_pool.A[78]); A_arbace_box_A_const_42 = lang.Var_Cast(A_arbace_box_A_const_pool.A[79]); A_arbace_box_A_const_43 = A_arbace_box_A_const_pool.A[80]; A_arbace_box_A_const_44 = A_arbace_box_A_const_pool.A[81]; A_arbace_box_A_const_45 = lang.Var_Cast(A_arbace_box_A_const_pool.A[82]); A_arbace_box_A_const_46 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[83]); A_arbace_box_A_const_47 = lang.Var_Cast(A_arbace_box_A_const_pool.A[84]) }

func A_arbace_box_A_clinit_p4() { A_arbace_box_A_const_48 = lang.Var_Cast(A_arbace_box_A_const_pool.A[85]); A_arbace_box_A_const_49 = lang.Var_Cast(A_arbace_box_A_const_pool.A[86]); A_arbace_box_A_const_50 = lang.Var_Cast(A_arbace_box_A_const_pool.A[87]); A_arbace_box_A_const_51 = lang.Var_Cast(A_arbace_box_A_const_pool.A[88]); A_arbace_box_A_const_52 = lang.Var_Cast(A_arbace_box_A_const_pool.A[89]); A_arbace_box_A_const_53 = lang.Var_Cast(A_arbace_box_A_const_pool.A[90]); A_arbace_box_A_const_54 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[91]); A_arbace_box_A_const_55 = lang.Var_Cast(A_arbace_box_A_const_pool.A[92]); A_arbace_box_A_const_56 = lang.Var_Cast(A_arbace_box_A_const_pool.A[93]); A_arbace_box_A_const_57 = lang.Var_Cast(A_arbace_box_A_const_pool.A[94]); A_arbace_box_A_const_58 = lang.Var_Cast(A_arbace_box_A_const_pool.A[95]); A_arbace_box_A_const_59 = jrt.Class_Cast(A_arbace_box_A_const_pool.A[96]) }

func A_arbace_box_A_clinit_p5() { A_arbace_box_A_const_60 = A_arbace_box_A_const_pool.A[97]; A_arbace_box_A_const_61 = lang.Var_Cast(A_arbace_box_A_const_pool.A[98]); A_arbace_box_A_const_62 = lang.Var_Cast(A_arbace_box_A_const_pool.A[99]); A_arbace_box_A_const_63 = jrt.Class_Cast(A_arbace_box_A_const_pool.A[100]); A_arbace_box_A_const_64 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[101]); A_arbace_box_A_const_65 = lang.Var_Cast(A_arbace_box_A_const_pool.A[102]); A_arbace_box_A_const_66 = lang.Var_Cast(A_arbace_box_A_const_pool.A[103]); A_arbace_box_A_const_67 = lang.Var_Cast(A_arbace_box_A_const_pool.A[104]); A_arbace_box_A_const_68 = lang.Var_Cast(A_arbace_box_A_const_pool.A[105]); A_arbace_box_A_const_69 = lang.Var_Cast(A_arbace_box_A_const_pool.A[106]); A_arbace_box_A_const_70 = A_arbace_box_A_const_pool.A[107]; A_arbace_box_A_const_71 = lang.Var_Cast(A_arbace_box_A_const_pool.A[108]) }

func A_arbace_box_A_clinit_p6() { A_arbace_box_A_const_72 = lang.Var_Cast(A_arbace_box_A_const_pool.A[109]); A_arbace_box_A_const_73 = A_arbace_box_A_const_pool.A[110]; A_arbace_box_A_const_74 = A_arbace_box_A_const_pool.A[111]; A_arbace_box_A_const_75 = lang.Var_Cast(A_arbace_box_A_const_pool.A[112]); A_arbace_box_A_const_76 = lang.Var_Cast(A_arbace_box_A_const_pool.A[113]); A_arbace_box_A_const_77 = lang.Var_Cast(A_arbace_box_A_const_pool.A[114]); A_arbace_box_A_const_78 = lang.Var_Cast(A_arbace_box_A_const_pool.A[115]); A_arbace_box_A_const_79 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[116]); A_arbace_box_A_const_80 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[117]); A_arbace_box_A_const_81 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[118]); A_arbace_box_A_const_82 = lang.Var_Cast(A_arbace_box_A_const_pool.A[119]); A_arbace_box_A_const_83 = lang.Var_Cast(A_arbace_box_A_const_pool.A[120]) }

func A_arbace_box_A_clinit_p7() { A_arbace_box_A_const_84 = lang.Var_Cast(A_arbace_box_A_const_pool.A[121]); A_arbace_box_A_const_85 = lang.Var_Cast(A_arbace_box_A_const_pool.A[122]); A_arbace_box_A_const_86 = lang.Var_Cast(A_arbace_box_A_const_pool.A[123]); A_arbace_box_A_const_87 = lang.Var_Cast(A_arbace_box_A_const_pool.A[124]); A_arbace_box_A_const_88 = lang.Var_Cast(A_arbace_box_A_const_pool.A[125]); A_arbace_box_A_const_89 = lang.Var_Cast(A_arbace_box_A_const_pool.A[126]); A_arbace_box_A_const_90 = lang.Var_Cast(A_arbace_box_A_const_pool.A[127]); A_arbace_box_A_const_91 = lang.Var_Cast(A_arbace_box_A_const_pool.A[128]); A_arbace_box_A_const_92 = lang.Var_Cast(A_arbace_box_A_const_pool.A[129]); A_arbace_box_A_const_93 = lang.Var_Cast(A_arbace_box_A_const_pool.A[130]); A_arbace_box_A_const_94 = lang.Var_Cast(A_arbace_box_A_const_pool.A[131]); A_arbace_box_A_const_95 = lang.Var_Cast(A_arbace_box_A_const_pool.A[132]) }

func A_arbace_box_A_clinit_p8() { A_arbace_box_A_const_96 = lang.Var_Cast(A_arbace_box_A_const_pool.A[133]); A_arbace_box_A_const_97 = lang.Var_Cast(A_arbace_box_A_const_pool.A[134]); A_arbace_box_A_const_98 = lang.Var_Cast(A_arbace_box_A_const_pool.A[135]); A_arbace_box_A_const_99 = lang.Var_Cast(A_arbace_box_A_const_pool.A[136]); A_arbace_box_A_const_100 = lang.Var_Cast(A_arbace_box_A_const_pool.A[137]); A_arbace_box_A_const_101 = lang.Var_Cast(A_arbace_box_A_const_pool.A[138]); A_arbace_box_A_const_102 = lang.Var_Cast(A_arbace_box_A_const_pool.A[139]); A_arbace_box_A_const_103 = lang.Var_Cast(A_arbace_box_A_const_pool.A[140]); A_arbace_box_A_const_104 = lang.Var_Cast(A_arbace_box_A_const_pool.A[141]); A_arbace_box_A_const_105 = lang.Var_Cast(A_arbace_box_A_const_pool.A[142]); A_arbace_box_A_const_106 = lang.Var_Cast(A_arbace_box_A_const_pool.A[143]); A_arbace_box_A_const_107 = lang.Var_Cast(A_arbace_box_A_const_pool.A[144]) }

func A_arbace_box_A_clinit_p9() { A_arbace_box_A_const_108 = lang.Var_Cast(A_arbace_box_A_const_pool.A[145]); A_arbace_box_A_const_109 = lang.Var_Cast(A_arbace_box_A_const_pool.A[146]); A_arbace_box_A_const_110 = lang.Var_Cast(A_arbace_box_A_const_pool.A[147]); A_arbace_box_A_const_111 = lang.Var_Cast(A_arbace_box_A_const_pool.A[148]); A_arbace_box_A_const_112 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[149]); A_arbace_box_A_const_113 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[150]); A_arbace_box_A_const_114 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[151]); A_arbace_box_A_const_115 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[152]); A_arbace_box_A_const_116 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[153]); A_arbace_box_A_const_117 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[154]); A_arbace_box_A_const_118 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[155]); A_arbace_box_A_const_119 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[156]) }

func A_arbace_box_A_clinit_p10() { A_arbace_box_A_const_120 = lang.Var_Cast(A_arbace_box_A_const_pool.A[157]); A_arbace_box_A_const_121 = lang.Var_Cast(A_arbace_box_A_const_pool.A[158]); A_arbace_box_A_const_122 = lang.Var_Cast(A_arbace_box_A_const_pool.A[159]); A_arbace_box_A_const_123 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[160]); A_arbace_box_A_const_124 = lang.Var_Cast(A_arbace_box_A_const_pool.A[161]); A_arbace_box_A_const_125 = lang.Var_Cast(A_arbace_box_A_const_pool.A[162]); A_arbace_box_A_const_126 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[163]); A_arbace_box_A_const_127 = lang.Var_Cast(A_arbace_box_A_const_pool.A[164]); A_arbace_box_A_const_128 = lang.Var_Cast(A_arbace_box_A_const_pool.A[165]) }

func A_arbace_box_A_New() *A_arbace_box_A { A_arbace_box_A_Init(); t := &A_arbace_box_A{}; t.Ctor(); return t }

func (t *A_arbace_box_A) Ctor() {}

func (t *A_arbace_box_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_A) GetClass__Class() *jrt.Class { return A_arbace_box_A_class }

func (t *A_arbace_box_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_A); return ok }

func A_arbace_box_A_Cast(x any) *A_arbace_box_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_A_class)) }; return v }



type A_arbace_box_answer_A struct{ j2g_header uint64 }

var A_arbace_box_answer_A_fn_class *jrt.Class



type A_arbace_box_boxed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_boxed_QMARK__A_fn_class *jrt.Class



type A_arbace_box_eval533000004_A struct{ jrt.Object }

func A_arbace_box_eval533000004_A_New() *A_arbace_box_eval533000004_A { t := &A_arbace_box_eval533000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000004_A) Ctor() {}

func (t *A_arbace_box_eval533000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000004_A_class }

func (t *A_arbace_box_eval533000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000004_A); return ok }

func A_arbace_box_eval533000004_A_Cast(x any) *A_arbace_box_eval533000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000004_A_class)) }; return v }



type A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A struct{ j2g_header uint64 }

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_fn_class *jrt.Class



type A_arbace_box_eval533000008_A struct{ jrt.Object }

func A_arbace_box_eval533000008_A_New() *A_arbace_box_eval533000008_A { t := &A_arbace_box_eval533000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000008_A) Ctor() {}

func (t *A_arbace_box_eval533000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000008_A_class }

func (t *A_arbace_box_eval533000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000008_A); return ok }

func A_arbace_box_eval533000008_A_Cast(x any) *A_arbace_box_eval533000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000008_A_class)) }; return v }



type A_arbace_box_eval533000008_fn__533000009_A struct{ j2g_header uint64 }

var A_arbace_box_eval533000008_fn__533000009_A_fn_class *jrt.Class



type A_arbace_box_fail_A struct{ j2g_header uint64 }

var A_arbace_box_fail_A_fn_class *jrt.Class



type A_arbace_box_fs_dir_A struct{ j2g_header uint64 }

var A_arbace_box_fs_dir_A_fn_class *jrt.Class



type A_arbace_box_get_A struct{ j2g_header uint64 }

var A_arbace_box_get_A_fn_class *jrt.Class



type A_arbace_box_get_bytes_A struct{ j2g_header uint64 }

var A_arbace_box_get_bytes_A_fn_class *jrt.Class



type A_arbace_box_get_tree_A struct{ j2g_header uint64 }

var A_arbace_box_get_tree_A_fn_class *jrt.Class



type A_arbace_box_get_tree_fn__533000077_A struct{ j2g_header uint64; F_o, F_eh any }

var A_arbace_box_get_tree_fn__533000077_A_fn_class *jrt.Class



type A_arbace_box_get_tree_fn__533000085_A struct{ j2g_header uint64; F_eh, F_o any }

var A_arbace_box_get_tree_fn__533000085_A_fn_class *jrt.Class



type A_arbace_box_hash_bytes_A struct{ j2g_header uint64 }

var A_arbace_box_hash_bytes_A_fn_class *jrt.Class



type A_arbace_box_hex_A struct{ j2g_header uint64 }

var A_arbace_box_hex_A_fn_class *jrt.Class



type A_arbace_box_load_A struct{ j2g_header uint64 }

var A_arbace_box_load_A_fn_class *jrt.Class



type A_arbace_box_load_fs_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_load_fs_BANG__A_fn_class *jrt.Class



type A_arbace_box_load_ref_A struct{ j2g_header uint64 }

var A_arbace_box_load_ref_A_fn_class *jrt.Class



type A_arbace_box_put_A struct{ j2g_header uint64 }

var A_arbace_box_put_A_fn_class *jrt.Class



type A_arbace_box_put_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_put_BANG__A_fn_class *jrt.Class



type A_arbace_box_put_dir_A struct{ j2g_header uint64 }

var A_arbace_box_put_dir_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_A struct{ j2g_header uint64 }

var A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A struct{ j2g_header uint64; F_s__533000057, F_iter__533000056 any }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A struct{ j2g_header uint64; F_b__533000059 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class *jrt.Class



type A_arbace_box_put_file_A struct{ j2g_header uint64 }

var A_arbace_box_put_file_A_fn_class *jrt.Class



type A_arbace_box_put_tree_A struct{ j2g_header uint64 }

var A_arbace_box_put_tree_A_fn_class *jrt.Class



type A_arbace_box_quote_str_A struct{ j2g_header uint64 }

var A_arbace_box_quote_str_A_fn_class *jrt.Class



type A_arbace_box_ref_A struct{ j2g_header uint64 }

var A_arbace_box_ref_A_fn_class *jrt.Class



type A_arbace_box_ref_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_ref_BANG__A_fn_class *jrt.Class



type A_arbace_box_ref_BANG__answer_A struct{ j2g_header uint64 }

var A_arbace_box_ref_BANG__answer_A_fn_class *jrt.Class



type A_arbace_box_request_text_A struct{ j2g_header uint64 }

var A_arbace_box_request_text_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_A struct{ j2g_header uint64 }

var A_arbace_box_request_text_iter__533000096__533000100_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A struct{ j2g_header uint64; F_iter__533000096, F_s__533000097 any }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A struct{ j2g_header uint64; F_b__533000099 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class *jrt.Class



type A_arbace_box_request_text_v__533000094_A struct{ j2g_header uint64 }

var A_arbace_box_request_text_v__533000094_A_fn_class *jrt.Class



type A_arbace_box_result_A struct{ j2g_header uint64 }

var A_arbace_box_result_A_fn_class *jrt.Class



type A_arbace_box_run_A struct{ j2g_header uint64 }

var A_arbace_box_run_A_fn_class *jrt.Class



type A_arbace_box_save_fs_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_save_fs_BANG__A_fn_class *jrt.Class



type A_arbace_box_size_A struct{ j2g_header uint64 }

var A_arbace_box_size_A_fn_class *jrt.Class



type A_arbace_box_spawn_A struct{ j2g_header uint64 }

var A_arbace_box_spawn_A_fn_class *jrt.Class



type A_arbace_box_spawn_wait_A struct{ j2g_header uint64 }

var A_arbace_box_spawn_wait_A_fn_class *jrt.Class



type A_arbace_box_store_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_store_QMARK__A_fn_class *jrt.Class



type A_arbace_box_tree_A struct{ j2g_header uint64 }

var A_arbace_box_tree_A_fn_class *jrt.Class



type A_arbace_box_tree_get_A struct{ j2g_header uint64 }

var A_arbace_box_tree_get_A_fn_class *jrt.Class



type A_arbace_box_tree_get_fn__533000088_A struct{ j2g_header uint64 }

var A_arbace_box_tree_get_fn__533000088_A_fn_class *jrt.Class



type A_arbace_box_tree_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_tree_name_QMARK__A_fn_class *jrt.Class



type A_arbace_box_tree_name_QMARK__fn__533000038_A struct{ j2g_header uint64 }

var A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class *jrt.Class



type A_arbace_box_tree_text_A struct{ j2g_header uint64 }

var A_arbace_box_tree_text_A_fn_class *jrt.Class



type A_arbace_box_tree_text_fn__533000042_A struct{ j2g_header uint64 }

var A_arbace_box_tree_text_fn__533000042_A_fn_class *jrt.Class



type A_arbace_box_utf8_compare_A struct{ j2g_header uint64 }

var A_arbace_box_utf8_compare_A_fn_class *jrt.Class
