//line aot_arbace_box.ae:1
package aot_arbace_box

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_New() *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A { A_arbace_box_A_Init(); t := &A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_A_const_2, A_arbace_box_A_const_3, A_arbace_box_A_const_4); lang.IFn_Cast(A_arbace_box_A_const_1.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_5, A_arbace_box_A_const_6); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_7)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_8)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp6 != nil { panic(tmp6) }; return tmp3 }
//line :4:1
func A_arbace_box_eval533000008_fn__533000009_A_New() *A_arbace_box_eval533000008_fn__533000009_A { A_arbace_box_A_Init(); t := &A_arbace_box_eval533000008_fn__533000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_box_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_box_A_const_11), A_arbace_box_A_const_9.GetRawRoot__O(), A_arbace_box_A_const_10) }







































func A_arbace_box_fail_A_New() *A_arbace_box_fail_A { A_arbace_box_A_Init(); t := &A_arbace_box_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_fail_A) Invoke_O_O_O_O__O(self, kind__0, msg__1, data__2 any) any { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_box_A_const_12.GetRawRoot__O()).Invoke_O_O__O(msg__1, lang.IFn_Cast(A_arbace_box_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(data__2, A_arbace_box_A_const_14, kind__0))))) }


func A_arbace_box_answer_A_New() *A_arbace_box_answer_A { A_arbace_box_A_Init(); t := &A_arbace_box_answer_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_answer_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_answer_A) Invoke_O_O_O_O__O(self, p_code__0, what__1, data__2 any) any { var code__0 int64 = lang.RT_LongCast_O__J(p_code__0); var G__533000013__4_ int64 = code__0; switch


	int32(G__533000013__4_) { case -5: if -5 == G__533000013__4_ {


		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_16; return tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, what__1, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_box_A_const_18.Invoke_O__O(data__2)))).Ref(), data__2) }
//line :50:1
	case -4: if -4 == G__533000013__4_ {

		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp4 any = A_arbace_box_A_const_19; return tmp3.Invoke_O_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(), data__2) }
//line :50:1
	case -3: if -3 == G__533000013__4_ {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp6 any = A_arbace_box_A_const_20; return tmp5.Invoke_O_O_O__O(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(), data__2) }
//line :50:1
	default:}; var tmp7 lang.IFn =




	lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp8 any = A_arbace_box_A_const_21; return tmp7.Invoke_O_O_O__O(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(), data__2) }

func A_arbace_box_hash_bytes_A_New() *A_arbace_box_hash_bytes_A { A_arbace_box_A_Init(); t := &A_arbace_box_hash_bytes_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Ctor() {}
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Invoke_O_O_O__O(self, h__0, what__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_box_A_const_23.GetRawRoot__O()).Invoke_O__O(h__0); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_box_A_const_24.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_25, h__0) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { } else {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_box_A_const_26; tmp2.Invoke_O_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, what__1, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(h__0))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0))) }
//line :57:1
	var b__3 any = lang.Numbers_Byte_array_O__B1(A_arbace_box_A_const_22).Ref(); var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J(32); var i__5 int64 = 0; L1: for {





		if lang.Numbers_Lt_J_J__Z(i__5, n__1927000701__auto____4) {
			jrt.Byte_ValueOf_B__Byte(lang.RT_Aset_B1_I_B__B(jrt.A2g_CastArray[*jrt.ByteArray](b__3, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__5), lang.RT_UncheckedByteCast_I__B(jrt.Integer_ParseInt_String_I__I(jrt.String_Cast(lang.IFn_Cast(A_arbace_box_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(h__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Multiply_J_J__J(2, i__5)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(2, lang.Numbers_Multiply_J_J__J(2, i__5))).Ref())), lang.RT_IntCast_J__I(16)))))
//line :63:1
			i__5 = lang.Numbers_Unchecked_inc_J__J(i__5); continue L1 }
//line :57:1
		break L1 }; return b__3
}








func A_arbace_box_hex_A_New() *A_arbace_box_hex_A { A_arbace_box_A_Init(); t := &A_arbace_box_hex_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_box_hex_A) Ctor() {}
//line :67:1
func (t *A_arbace_box_hex_A) Invoke_O_O__O(self, b__0 any) any { var sb__2 any = jrt.StringBuilder_New_I(lang.RT_IntCast_J__I(64)); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()))); var i__4 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z(i__4, n__1927000701__auto____3) { var x__5 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__4))).Ref()), 255)

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_ShiftRight_J_J__J(x__5, 4)), lang.RT_IntCast_J__I(16)))
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(x__5, 15)), lang.RT_IntCast_J__I(16)))
//line :71:1
		i__4 = lang.Numbers_Unchecked_inc_J__J(i__4); continue L1 }
//line :67:1
	break L1 }; return /*line :75:1*/ lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(sb__2) }

func A_arbace_box_store_QMARK__A_New() *A_arbace_box_store_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_store_QMARK__A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Ctor() {}
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Invoke_O__O(self any) any {


	return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(lang.IFn_Cast(A_arbace_box_A_const_30.GetRawRoot__O()).Invoke__O())).Ref()
}
func A_arbace_box_put_A_New() *A_arbace_box_put_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_put_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_put_A) Invoke_O_O__O(self, x__0 any) any { var b__2 any; if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_23.GetRawRoot__O()).Invoke_O__O(x__0)) { b__2 = jrt.NN(jrt.String_Cast(x__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_31.GetRawRoot__O()).Invoke_O__O(x__0)) { b__2 = x__0 } else { if A_arbace_box_A_const_32 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_33.GetRawRoot__O()).Invoke_O__O(x__0)))))) } else { b__2 = nil } } }; var h__3 any = /*line :82:1*/lang.Numbers_Byte_array_O__B1(A_arbace_box_A_const_22).Ref(); var code__4 any = lang.IFn_Cast(A_arbace_box_A_const_34.GetRawRoot__O()).Invoke_O_O__O(b__2, h__3); if








	lang.Numbers_IsZero_O__Z(code__4) { } else {
		var tmp1 any = A_arbace_box_A_const_37; lang.IFn_Cast(A_arbace_box_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(code__4, Lit_25, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__2, jrt.Prim_byte.ArrayClass()))).Ref()))) }; return /*line :93:1*/ lang.IFn_Cast(A_arbace_box_A_const_35.GetRawRoot__O()).Invoke_O__O(h__3) }

func A_arbace_box_get_bytes_A_New() *A_arbace_box_get_bytes_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_bytes_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_box_get_bytes_A) Ctor() {}
//line :95:1
func (t *A_arbace_box_get_bytes_A) Invoke_O_O__O(self, h__0 any) any { var hb__2 any = lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(h__0, Lit_11); var n__3 any = lang.IFn_Cast(A_arbace_box_A_const_39.GetRawRoot__O()).Invoke_O__O(hb__2); if




	lang.Util_Equiv_O_J__Z(n__3, -1) { return nil } else { if lang.Numbers_IsNeg_O__Z(n__3) {

		return lang.IFn_Cast(A_arbace_box_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(n__3, Lit_11, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0))) } else {
//line :100:1
			if A_arbace_box_A_const_32 != nil {


				return lang.IFn_Cast(A_arbace_box_A_const_40.GetRawRoot__O()).Invoke_O__O(hb__2) } else {
//line :100:1
					return nil } } } }




func A_arbace_box_get_A_New() *A_arbace_box_get_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_box_get_A) Ctor() {}
//line :105:1
func (t *A_arbace_box_get_A) Invoke_O_O__O(self, h__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_A_const_41.GetRawRoot__O()).Invoke_O__O(h__0); if


	jrt.A2g_Truth(temp__1927000414__auto____2) { var b__3 any = temp__1927000414__auto____2; return jrt.String_New_B1_Charset(jrt.A2g_CastArray[*jrt.ByteArray](b__3, jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_UTF_8) } else { return nil } }


func A_arbace_box_size_A_New() *A_arbace_box_size_A { A_arbace_box_A_Init(); t := &A_arbace_box_size_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_box_size_A) Ctor() {}
//line :111:1
func (t *A_arbace_box_size_A) Invoke_O_O__O(self, h__0 any) any { var n__2 any = lang.IFn_Cast(A_arbace_box_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(h__0, Lit_61)); if



	lang.Util_Equiv_O_J__Z(n__2, -1) { return nil } else { if lang.Numbers_IsNeg_O__Z(n__2) {

		return lang.IFn_Cast(A_arbace_box_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(n__2, Lit_61, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0))) } else {
//line :115:1
			if A_arbace_box_A_const_32 != nil { return n__2 } else { return nil } } } }




func A_arbace_box_ref_A_New() *A_arbace_box_ref_A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_box_ref_A) Ctor() {}
//line :120:1
func (t *A_arbace_box_ref_A) Invoke_O_O__O(self, name__0 any) any { var h__2 any = lang.Numbers_Byte_array_O__B1(A_arbace_box_A_const_22).Ref(); var code__3 any = lang.IFn_Cast(A_arbace_box_A_const_42.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(name__0), h__2); var G__533000022__4_ any = code__3; if




	jrt.Number_InstanceOf(G__533000022__4_) { switch jrt.Number_Cast(G__533000022__4_).IntValue__I() { case -1: if lang.Util_Equiv_O_O__Z(G__533000022__4_, A_arbace_box_A_const_43) { return nil }; case 0: if lang.Util_Equiv_O_O__Z(G__533000022__4_, A_arbace_box_A_const_44) {
		return lang.IFn_Cast(A_arbace_box_A_const_35.GetRawRoot__O()).Invoke_O__O(h__2) }
//line :125:1
	default:} }; return /*line :128:1*/ lang.IFn_Cast(A_arbace_box_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(code__3, Lit_34, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__0))) }

func A_arbace_box_ref_BANG__answer_A_New() *A_arbace_box_ref_BANG__answer_A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_BANG__answer_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Ctor() {}
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Invoke_O_O_O_O__O(self, code__0, name__1, h__2 any) any {
	if lang.Util_Equiv_O_J__Z(code__0, -2) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp1 bool; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_J__Z(code__0, -1)

		if and__1927000168__auto____4 { tmp1 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_box_A_const_45.GetRawRoot__O()).Invoke_O__O(h__2), nil) } else { tmp1 = and__1927000168__auto____4 }
//line :131:1
		if tmp1 {


			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_box_A_const_46; return tmp2.Invoke_O_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__1, A_arbace_box_A_const_27, h__2))) } else {
//line :131:1
				if A_arbace_box_A_const_32 != nil {



					return lang.IFn_Cast(A_arbace_box_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(code__0, Lit_35, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__1, A_arbace_box_A_const_27, h__2))) } else {
//line :131:1
						return nil
					}
			}
	}
}

func A_arbace_box_ref_BANG__A_New() *A_arbace_box_ref_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_BANG__A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Ctor() {}
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O_O__O(self, name__0, h__1, old__2 any) any { var ob__4 any; if






	lang.Util_Identical_O_O__Z(old__2, nil) { ob__4 = lang.Numbers_Byte_array_O__B1(A_arbace_box_A_const_22).Ref() } else { ob__4 = lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(old__2, Lit_35) }; var code__5 any = /*line :137:1*/lang.IFn_Cast(A_arbace_box_A_const_47.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(name__0), lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(h__1, Lit_35), ob__4); var or__1927000174__auto____6 bool = lang.Numbers_IsZero_O__Z(code__5); if or__1927000174__auto____6 {








		return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { return lang.IFn_Cast(A_arbace_box_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(code__5, name__0, h__1) } }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O__O(self, name__0, h__1 any) any { var code__3 any = lang.IFn_Cast(A_arbace_box_A_const_47.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(name__0), lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(h__1, Lit_35), nil); var or__1927000174__auto____4 bool = lang.Numbers_IsZero_O__Z(code__3); if or__1927000174__auto____4 {




	return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { return lang.IFn_Cast(A_arbace_box_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(code__3, name__0, h__1) } }





func A_arbace_box_put_BANG__A_New() *A_arbace_box_put_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_put_BANG__A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_box_put_BANG__A) Ctor() {}
//line :148:1
func (t *A_arbace_box_put_BANG__A) Invoke_O_O_O__O(self, name__0, x__1 any) any { var h__3 any = lang.IFn_Cast(A_arbace_box_A_const_49.GetRawRoot__O()).Invoke_O__O(x__1);



	lang.IFn_Cast(A_arbace_box_A_const_50.GetRawRoot__O()).Invoke_O_O__O(name__0, h__3); return h__3 }


func A_arbace_box_load_A_New() *A_arbace_box_load_A { A_arbace_box_A_Init(); t := &A_arbace_box_load_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_box_load_A) Ctor() {}
//line :155:1
func (t *A_arbace_box_load_A) Invoke_O_O__O(self, name__0 any) any { var G__533000027__2_ any = lang.IFn_Cast(A_arbace_box_A_const_51.GetRawRoot__O()).Invoke_O__O(name__0); if


	lang.Util_Identical_O_O__Z(G__533000027__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_box_A_const_52.GetRawRoot__O()).Invoke_O__O(G__533000027__2_) } }

func A_arbace_box_load_ref_A_New() *A_arbace_box_load_ref_A { A_arbace_box_A_Init(); t := &A_arbace_box_load_ref_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_box_load_ref_A) Ctor() {}
//line :160:1
func (t *A_arbace_box_load_ref_A) Invoke_O_O__O(self, name__0 any) any { var src__2 any = lang.IFn_Cast(A_arbace_box_A_const_53.GetRawRoot__O()).Invoke_O__O(name__0); if




	lang.Util_Identical_O_O__Z(src__2, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_54; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__0))) }; return /*line :167:1*/ lang.Compiler_Load_Reader_String_String__O(jrt.StringReader_New_String(jrt.String_Cast(src__2)), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)), jrt.String_Cast(lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(name__0))) }

func A_arbace_box_boxed_QMARK__A_New() *A_arbace_box_boxed_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_boxed_QMARK__A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Ctor() {}
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Invoke_O__O(self any) any {
	return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_5, jrt.System_GetProperty_String__String(Lit_6).Ref())).Ref()
}
func A_arbace_box_fs_dir_A_New() *A_arbace_box_fs_dir_A { A_arbace_box_A_Init(); t := &A_arbace_box_fs_dir_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_box_fs_dir_A) Ctor() {}
//line :172:1
func (t *A_arbace_box_fs_dir_A) Invoke_O_O_O__O(self, dir__0, what__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_55.GetRawRoot__O()).Invoke_O__O(dir__0)) {
		return lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(dir__0) } else {
//line :173:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_56.GetRawRoot__O()).Invoke__O()) { return Lit_9 } else { if A_arbace_box_A_const_32 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, what__1, nil))))) } else { return nil
			}
			}
		}
}

func A_arbace_box_save_fs_BANG__A_New() *A_arbace_box_save_fs_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_save_fs_BANG__A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Ctor() {}
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any = lang.IFn_Cast(A_arbace_box_A_const_57.GetRawRoot__O()).Invoke_O_O__O(dir__1, Lit_58); var err__4 any = lang.IFn_Cast(A_arbace_box_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_61, A_arbace_box_A_const_62); var tar__5 any = lang.IFn_Cast(A_arbace_box_A_const_59.GetRawRoot__O()).Invoke_O_O__O(d__3, err__4); if








	lang.Util_Identical_O_O__Z(tar__5, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_21; var tmp3 *jrt.Class = A_arbace_box_A_const_63; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp3, Lit_60, jrt.RefArrayOf(jrt.Object_class, err__4, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(0)).Ref())))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0, A_arbace_box_A_const_64, d__3))) }; return /*line :190:1*/ lang.IFn_Cast(A_arbace_box_A_const_60.GetRawRoot__O()).Invoke_O_O__O(ref__0, tar__5) }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {



	return lang.IFn_Cast(A_arbace_box_A_const_65.GetRawRoot__O()).Invoke_O_O__O(ref__0, nil)
}







func A_arbace_box_load_fs_BANG__A_New() *A_arbace_box_load_fs_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_load_fs_BANG__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Ctor() {}
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any = lang.IFn_Cast(A_arbace_box_A_const_57.GetRawRoot__O()).Invoke_O_O__O(dir__1, Lit_18); var tar__4 any; var G__533000033__4_ any = lang.IFn_Cast(A_arbace_box_A_const_51.GetRawRoot__O()).Invoke_O__O(ref__0); if





	lang.Util_Identical_O_O__Z(G__533000033__4_, nil) { tar__4 = nil } else { tar__4 = lang.IFn_Cast(A_arbace_box_A_const_41.GetRawRoot__O()).Invoke_O__O(G__533000033__4_) }; if
	lang.Util_Identical_O_O__Z(tar__4, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_54; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, ref__0)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0))) }; var temp__1927000414__auto____5 any = /*line :192:1*/lang.IFn_Cast(A_arbace_box_A_const_66.GetRawRoot__O()).Invoke_O_O__O(tar__4, d__3); if








	jrt.A2g_Truth(temp__1927000414__auto____5) { var e__6 any = temp__1927000414__auto____5; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp4 any = A_arbace_box_A_const_21
		tmp3.Invoke_O_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, e__6)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0, A_arbace_box_A_const_64, d__3))) }; return nil }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {


	return lang.IFn_Cast(A_arbace_box_A_const_67.GetRawRoot__O()).Invoke_O_O__O(ref__0, nil)
}














func A_arbace_box_quote_str_A_New() *A_arbace_box_quote_str_A { A_arbace_box_A_Init(); t := &A_arbace_box_quote_str_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_quote_str_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_quote_str_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_CharSequence_CharSequence__String(Lit_31, Lit_32)).Replace_CharSequence_CharSequence__String(Lit_30, Lit_33).Ref(), nil)).Ref()
}
func A_arbace_box_utf8_compare_A_New() *A_arbace_box_utf8_compare_A { A_arbace_box_A_Init(); t := &A_arbace_box_utf8_compare_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Ctor() {}
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { { var x__3 any = jrt.NN(jrt.String_Cast(a__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var y__4 any = jrt.NN(jrt.String_Cast(b__1)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var n__5 int64 = lang.Numbers_Min_J_J__J(int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](x__3, jrt.Prim_byte.ArrayClass()))), int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](y__4, jrt.Prim_byte.ArrayClass())))); var i__6 int64 = 0; L1: for {






	if lang.Numbers_Lt_J_J__Z(i__6, n__5) { var c__7 int32 = lang.Util_Compare_O_O__I(jrt.Long_ValueOf_J__Long(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](x__3, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__6))).Ref()), 255)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](y__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__6))).Ref()), 255)).Ref())

		if lang.Numbers_IsZero_J__Z(int64(c__7)) { i__6 = lang.Numbers_Inc_J__J(i__6); continue L1 } else { return jrt.Integer_ValueOf_I__Integer(c__7).Ref() } } else {
			return jrt.Integer_ValueOf_I__Integer(lang.Util_Compare_O_O__I(jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](x__3, jrt.Prim_byte.ArrayClass()))).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](y__4, jrt.Prim_byte.ArrayClass()))).Ref())).Ref() } } }; /*line :216:1*/panic("a2g: unreachable") }











func A_arbace_box_tree_name_QMARK__A_New() *A_arbace_box_tree_name_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_name_QMARK__A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Ctor() {}
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_box_A_const_23.GetRawRoot__O()).Invoke_O__O(n__0); if
										jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_box_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_71, n__0)); if jrt.A2g_Truth(and__1927000168__auto____3) {
											var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_69.GetRawRoot__O()); var tmp2 any = A_arbace_box_tree_name_QMARK__fn__533000038_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), n__0) } else {
//line :229:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }
func A_arbace_box_tree_name_QMARK__fn__533000038_A_New() *A_arbace_box_tree_name_QMARK__fn__533000038_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_name_QMARK__fn__533000038_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Ctor() {}
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Invoke_O_O__O(self, p1__533000037_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_box_A_const_72.GetRawRoot__O()).Invoke_O_O__O(p1__533000037_SHARP___1, A_arbace_box_A_const_73); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z(int64(lang.RT_IntCast_O__I(p1__533000037_SHARP___1)), 32); if and__1927000168__auto____3 { return lang.IFn_Cast(A_arbace_box_A_const_72.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(p1__533000037_SHARP___1)).Ref(), A_arbace_box_A_const_74) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_box_tree_text_A_New() *A_arbace_box_tree_text_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_text_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_box_tree_text_A) Ctor() {}
//line :232:1
func (t *A_arbace_box_tree_text_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_69, nil, Lit_41); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_75.GetRawRoot__O()); var tmp3 any = A_arbace_box_A_const_29.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_76.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_77.GetRawRoot__O()); var tmp6 any = A_arbace_box_tree_text_fn__533000042_A_New(); var tmp7 *jrt.Class
	var fncls__5 /*line :235:1*/*jrt.Class = A_arbace_box_tree_text_fn__533000042_A_fn_class

	if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_box_tree_text_fn__533000042_A_fn_class = fncls__5d; tmp7 = fncls__5d } else { tmp7 = fncls__5 }
//line :235:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(Lit_70, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_box_A_const_83.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_A_const_84.GetRawRoot__O(), A_arbace_box_A_const_85.GetRawRoot__O(), m__0)))), nil)).Ref()
}
func A_arbace_box_tree_text_fn__533000042_A_New() *A_arbace_box_tree_text_fn__533000042_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_text_fn__533000042_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Ctor() {}
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Invoke_O_O__O(self, p__533000041__1 any) any { var vec__533000043__2 any = p__533000041__1; var n__3 any = lang.RT_Nth_O_I_O__O(vec__533000043__2, lang.RT_IntCast_J__I(0), nil); var vec__533000046__4 any = lang.RT_Nth_O_I_O__O(vec__533000043__2, lang.RT_IntCast_J__I(1), nil); var kind__5 any = lang.RT_Nth_O_I_O__O(vec__533000046__4, lang.RT_IntCast_J__I(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O(vec__533000046__4, lang.RT_IntCast_J__I(1), nil); var size__7 any = lang.RT_Nth_O_I_O__O(vec__533000046__4, lang.RT_IntCast_J__I(2), nil); var e__8 any = vec__533000046__4; if
												jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_81.GetRawRoot__O()).Invoke_O__O(n__3)) { } else {
													var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_82; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(n__3))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, n__3))) };
												lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(h__6, Lit_73); var tmp3 /*line :241:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_56, nil); var tmp4 any = lang.IFn_Cast(A_arbace_box_A_const_78.GetRawRoot__O()).Invoke_O__O(n__3); var tmp5 any; var G__533000049__12_ any = kind__5; L1:
												switch { default: switch lang.Util_Hash_O__I(G__533000049__12_) >> 2 & 3 { case 1: if any(G__533000049__12_) == any(A_arbace_box_A_const_79) {
													tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(size__7)).Ref(), nil)).Ref()
//line :242:1
		break L1 }; case 2: if any(G__533000049__12_) == any(A_arbace_box_A_const_64) {

			tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, h__6, nil)).Ref()
//line :242:1
			break L1 }; case 3: if any(G__533000049__12_) == any(A_arbace_box_A_const_80) {
				tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(size__7)).Ref(), nil)).Ref()
//line :242:1
				break L1 }; default:
	}

		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp7 any = A_arbace_box_A_const_82; tmp5 = tmp6.Invoke_O_O_O__O(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_75, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(e__8))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, n__3)))}; return /*line :241:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref() }








func A_arbace_box_put_tree_A_New() *A_arbace_box_put_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_tree_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_box_put_tree_A) Ctor() {}
//line :250:1
func (t *A_arbace_box_put_tree_A) Invoke_O_O__O(self, m__0 any) any {


	return lang.IFn_Cast(A_arbace_box_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_86.GetRawRoot__O()).Invoke_O__O(m__0))
}
func A_arbace_box_tree_A_New() *A_arbace_box_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_box_tree_A) Ctor() {}
//line :255:1
func (t *A_arbace_box_tree_A) Invoke_O_O__O(self, h__0 any) any { var G__533000053__2_ any = lang.IFn_Cast(A_arbace_box_A_const_52.GetRawRoot__O()).Invoke_O__O(h__0); if


	lang.Util_Identical_O_O__Z(G__533000053__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_box_A_const_87.GetRawRoot__O()).Invoke_O__O(G__533000053__2_) } }

func A_arbace_box_put_file_A_New() *A_arbace_box_put_file_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_file_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_box_put_file_A) Ctor() {}
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O_O__O(self, x__0, exec__1 any) any { var h__3 any = lang.IFn_Cast(A_arbace_box_A_const_49.GetRawRoot__O()).Invoke_O__O(x__0); var tmp1 *lang.Keyword; if





	jrt.A2g_Truth(exec__1) { tmp1 = A_arbace_box_A_const_79 } else { tmp1 = A_arbace_box_A_const_80 }; return /*line :260:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp1.Ref(), h__3, lang.IFn_Cast(A_arbace_box_A_const_45.GetRawRoot__O()).Invoke_O__O(h__3)) }
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_88.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(x__0, tmp2.Ref())
}



func A_arbace_box_put_dir_A_New() *A_arbace_box_put_dir_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_box_put_dir_A) Ctor() {}
//line :268:1
func (t *A_arbace_box_put_dir_A) Invoke_O_O__O(self, dir__0 any) any { var d__2 any = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(dir__0))); var fs__3 any = jrt.NN(jrt.File_Cast(d__2)).ListFiles__File1().Ref(); if





	lang.Util_Identical_O_O__Z(fs__3, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_21; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, dir__0)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_64, dir__0))) }; var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_box_A_const_89.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_90.GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 any; var iter__1927001039__auto____4 any; var tmp8 any = A_arbace_box_put_dir_iter__533000056__533000060_A_New(); var tmp9 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class; if

	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class = fncls__8d; tmp9 = fncls__8d } else { tmp9 = fncls__8 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__3); return /*line :276:1*/ tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7)) }

func A_arbace_box_put_dir_iter__533000056__533000060_A_New() *A_arbace_box_put_dir_iter__533000056__533000060_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Ctor() {}
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Invoke_O_O__O(self, s__533000057__1 any) any { var tmp1 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(s__533000057__1, self); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(p0, p1 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A{}; t.Ctor_O_O(p0, p1); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Ctor_O_O(c__s__533000057, c__iter__533000056 any) { t.F_s__533000057 = c__s__533000057; t.F_iter__533000056 = c__iter__533000056 }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Invoke_O__O(self any) any { { var s__533000057__1 any; var t_ any = t.F_s__533000057; t.F_s__533000057 = nil; s__533000057__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(s__533000057__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__533000057__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_92.GetRawRoot__O()).Invoke_O__O(s__533000057__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_A_const_93.GetRawRoot__O()).Invoke_O__O(s__533000057__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__533000059__6 any = lang.IFn_Cast(A_arbace_box_A_const_94.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(b__533000059__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); return lang.IFn_Cast(A_arbace_box_A_const_97.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_100.GetRawRoot__O()).Invoke_O__O(b__533000059__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_101.GetRawRoot__O()).Invoke_O__O(s__533000057__3))) } else { return lang.IFn_Cast(A_arbace_box_A_const_97.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_100.GetRawRoot__O()).Invoke_O__O(b__533000059__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_box_A_const_98.GetRawRoot__O()).Invoke_O__O(s__533000057__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_99.GetRawRoot__O()); var tmp5 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var tmp6 any

	if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var tmp7 any = A_arbace_box_A_const_64; tmp6 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_box_A_const_96.GetRawRoot__O()).Invoke_O__O(f__4)) } else {

		tmp6 = lang.IFn_Cast(A_arbace_box_A_const_88.GetRawRoot__O()).Invoke_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref(), jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(f__4)).CanExecute__Z()).Ref()) }
//line :278:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_102.GetRawRoot__O()).Invoke_O__O(s__533000057__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Ctor_O_I_O(c__b__533000059 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000059 = c__b__533000059; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Invoke_O__O(self any) any { { var i__533000058__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__533000058__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__533000058__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_95.GetRawRoot__O()); var tmp3 any = t.F_b__533000059; var tmp4 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp5 any

	if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var tmp6 any = A_arbace_box_A_const_64; tmp5 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.IFn_Cast(A_arbace_box_A_const_96.GetRawRoot__O()).Invoke_O__O(f__2)) } else {

		tmp5 = lang.IFn_Cast(A_arbace_box_A_const_88.GetRawRoot__O()).Invoke_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref(), jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(f__2)).CanExecute__Z()).Ref()) }
//line :278:1
	tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5)); i__533000058__1 = lang.Numbers_Unchecked_inc_J__J(i__533000058__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_box_get_tree_A_New() *A_arbace_box_get_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_box_get_tree_A) Ctor() {}
//line :284:1
func (t *A_arbace_box_get_tree_A) Invoke_O_O_O__O(self, h__0, dir__1 any) any { var m__3 any = lang.IFn_Cast(A_arbace_box_A_const_103.GetRawRoot__O()).Invoke_O__O(h__0); var d__4 any = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_box_A_const_29.GetRawRoot__O()).Invoke_O__O(dir__1))); if




	lang.Util_Identical_O_O__Z(m__3, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_46; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0))) };
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(d__4)).Mkdirs__Z()); var seq_533000067__5 any = /*line :284:1*/lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(m__3); var chunk_533000068__6 any; var count_533000069__7 int64 = 0; var i_533000070__8 int64 = 0; L1: for {







		if lang.Numbers_Lt_J_J__Z(i_533000070__8, count_533000069__7) { var vec__533000071__9 any = lang.Indexed_Cast(chunk_533000068__6).Nth_I__O(lang.RT_IntCast_J__I(i_533000070__8)); var n__10 any = lang.RT_Nth_O_I_O__O(vec__533000071__9, lang.RT_IntCast_J__I(0), nil); var vec__533000074__11 any = lang.RT_Nth_O_I_O__O(vec__533000071__9, lang.RT_IntCast_J__I(1), nil); var kind__12 any = lang.RT_Nth_O_I_O__O(vec__533000074__11, lang.RT_IntCast_J__I(0), nil); var eh__13 any = lang.RT_Nth_O_I_O__O(vec__533000074__11, lang.RT_IntCast_J__I(1), nil); var f__14 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__10))

			if lang.Util_Equiv_O_O__Z(kind__12, A_arbace_box_A_const_64) {
				lang.IFn_Cast(A_arbace_box_A_const_104.GetRawRoot__O()).Invoke_O_O__O(eh__13, f__14) } else {
//line :294:1
					var o__15 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__14)); var tmp3 any = A_arbace_box_get_tree_fn__533000077_A_New_O_O(o__15, eh__13); var tmp4 *jrt.Class
					var fncls__9 /*line :294:1*/*jrt.Class = A_arbace_box_get_tree_fn__533000077_A_fn_class

					if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_box_get_tree_fn__533000077_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()

					if lang.Util_Equiv_O_O__Z(kind__12, A_arbace_box_A_const_79) { var tmp5 *jrt.File = jrt.File_Cast(f__14); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(tmp5).SetExecutable_Z__Z(jrt.NN(tmp6).BooleanValue__Z())) } }
//line :292:1
			seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = seq_533000067__5, chunk_533000068__6, count_533000069__7, lang.Numbers_Unchecked_inc_J__J(i_533000070__8); continue L1 } else { var temp__1927000414__auto____9 any = lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(seq_533000067__5); if jrt.A2g_Truth(temp__1927000414__auto____9) { var seq_533000067__10 any = temp__1927000414__auto____9; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_92.GetRawRoot__O()).Invoke_O__O(seq_533000067__10)) { var c__1927000678__auto____11 any = lang.IFn_Cast(A_arbace_box_A_const_93.GetRawRoot__O()).Invoke_O__O(seq_533000067__10); seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = lang.IFn_Cast(A_arbace_box_A_const_101.GetRawRoot__O()).Invoke_O__O(seq_533000067__10), c__1927000678__auto____11, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__533000079__11 any = lang.IFn_Cast(A_arbace_box_A_const_98.GetRawRoot__O()).Invoke_O__O(seq_533000067__10); var n__12 any = lang.RT_Nth_O_I_O__O(vec__533000079__11, lang.RT_IntCast_J__I(0), nil); var vec__533000082__13 any = lang.RT_Nth_O_I_O__O(vec__533000079__11, lang.RT_IntCast_J__I(1), nil); var kind__14 any = lang.RT_Nth_O_I_O__O(vec__533000082__13, lang.RT_IntCast_J__I(0), nil); var eh__15 any = lang.RT_Nth_O_I_O__O(vec__533000082__13, lang.RT_IntCast_J__I(1), nil); var f__16 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__12))

				if lang.Util_Equiv_O_O__Z(kind__14, A_arbace_box_A_const_64) {
					lang.IFn_Cast(A_arbace_box_A_const_104.GetRawRoot__O()).Invoke_O_O__O(eh__15, f__16) } else {
//line :294:1
						var o__17 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__16)); var tmp7 any = A_arbace_box_get_tree_fn__533000085_A_New_O_O(eh__15, o__17); var tmp8 *jrt.Class
						var fncls__10 /*line :294:1*/*jrt.Class = A_arbace_box_get_tree_fn__533000085_A_fn_class

						if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_box_get_tree_fn__533000085_A_fn_class = fncls__10d; tmp8 = fncls__10d } else { tmp8 = fncls__10 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()

						if lang.Util_Equiv_O_O__Z(kind__14, A_arbace_box_A_const_79) { var tmp9 *jrt.File = jrt.File_Cast(f__16); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(tmp9).SetExecutable_Z__Z(jrt.NN(tmp10).BooleanValue__Z())) } }
//line :292:1
				seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = lang.IFn_Cast(A_arbace_box_A_const_105.GetRawRoot__O()).Invoke_O__O(seq_533000067__10), nil, 0, 0; continue L1 } } }
//line :284:1
		break L1 }; return nil }











func A_arbace_box_get_tree_fn__533000077_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000077_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_fn__533000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Ctor_O_O(c__o, c__eh any) { t.F_o = c__o; t.F_eh = c__eh }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_box_A_const_41.GetRawRoot__O()).Invoke_O__O(t.F_eh); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp5 any = A_arbace_box_A_const_46; var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var tmp7 any = A_arbace_box_A_const_27; var tmp8 any; var t_ any = t.F_eh; t.F_eh = nil; tmp8 = t_; tmp3 = tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8))) }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_15, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp10 any; var t__2 any = t.F_o; t.F_o = nil; tmp10 = t__2; jrt.FileOutputStream_Cast(tmp10).Close__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }
//line :296:1
func A_arbace_box_get_tree_fn__533000085_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000085_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_fn__533000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Ctor_O_O(c__eh, c__o any) { t.F_eh = c__eh; t.F_o = c__o }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_box_A_const_41.GetRawRoot__O()).Invoke_O__O(t.F_eh); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp5 any = A_arbace_box_A_const_46; var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var tmp7 any = A_arbace_box_A_const_27; var tmp8 any; var t_ any = t.F_eh; t.F_eh = nil; tmp8 = t_; tmp3 = tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8))) }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_15, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp10 any; var t__2 any = t.F_o; t.F_o = nil; tmp10 = t__2; jrt.FileOutputStream_Cast(tmp10).Close__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }




func A_arbace_box_tree_get_A_New() *A_arbace_box_tree_get_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_get_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_box_tree_get_A) Ctor() {}
//line :301:1
func (t *A_arbace_box_tree_get_A) Invoke_O_O_O__O(self, h__0, p__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_106.GetRawRoot__O()); var tmp2 any = A_arbace_box_tree_get_fn__533000088_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_box_tree_get_fn__533000088_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_box_tree_get_fn__533000088_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; var tmp4 *jrt.Class = A_arbace_box_A_const_61; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_A_const_64, h__0), lang.IFn_Cast(A_arbace_box_A_const_109.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_110.GetRawRoot__O(), lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__1, tmp4, Lit_67, jrt.RefArrayOf(jrt.Object_class, Lit_9)))) }
//line :304:1
func A_arbace_box_tree_get_fn__533000088_A_New() *A_arbace_box_tree_get_fn__533000088_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_get_fn__533000088_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Ctor() {}
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Invoke_O_O_O__O(self, e__1, n__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = e__1; if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp2 any = A_arbace_box_A_const_64; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_box_A_const_98.GetRawRoot__O()).Invoke_O__O(e__1))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		return lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_103.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_108.GetRawRoot__O()).Invoke_O__O(e__1)), n__2) } else {
			return lang.IFn_Cast(A_arbace_box_A_const_107.GetRawRoot__O()).Invoke_O__O(nil)
		}
}








func A_arbace_box_request_text_A_New() *A_arbace_box_request_text_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_box_request_text_A) Ctor() {}
//line :318:1
func (t *A_arbace_box_request_text_A) Invoke_O_O__O(self, p__533000091__0 any) any { var map__533000092__2 any = p__533000091__0; var map__533000092__3 any; if lang.ISeq_InstanceOf(map__533000092__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_105.GetRawRoot__O()).Invoke_O__O(map__533000092__2)) { map__533000092__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_A_const_111.GetRawRoot__O()).Invoke_O__O(map__533000092__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(map__533000092__2)) { map__533000092__3 = lang.IFn_Cast(A_arbace_box_A_const_98.GetRawRoot__O()).Invoke_O__O(map__533000092__2) } else { lang.PersistentArrayMap_Init(); map__533000092__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__533000092__3 = map__533000092__2 }; var image__4 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_112); var args__5 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_113); var env__6 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_114); var trees__7 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_115); var out__8 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_116); var cwd__9 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_117); var ram__10 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_118); var cpus__11 any = lang.RT_Get_O_O__O(map__533000092__3, A_arbace_box_A_const_119); var v__12 any; var tmp1 any = A_arbace_box_request_text_v__533000094_A_New(); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_box_request_text_v__533000094_A_fn_class; if



	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_box_request_text_v__533000094_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; v__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);
	lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(image__4, Lit_38); var tmp3 /*line :324:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_39, nil, Lit_40, nil, nil, nil, nil, nil, nil, nil, Lit_41); var tmp4 any = lang.IFn_Cast(v__12).Invoke_O__O(args__5); var tmp5 *jrt.String; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(env__6)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(v__12).Invoke_O__O(env__6))) } else { tmp5 = nil }; var tmp6 any = /*line :324:1*/tmp5.Ref(); var tmp7 *jrt.String; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(trees__7)) {
		var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_75.GetRawRoot__O()); var tmp10 any = A_arbace_box_A_const_29.GetRawRoot__O(); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_76.GetRawRoot__O()); var tmp12 any; var iter__1927001039__auto____27 any; var tmp13 any = A_arbace_box_request_text_iter__533000096__533000100_A_New(); var tmp14 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_A_fn_class
		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_box_request_text_iter__533000096__533000100_A_fn_class = fncls__15d; tmp14 = fncls__15d } else { tmp14 = fncls__15 }; iter__1927001039__auto____27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); tmp12 = lang.IFn_Cast(iter__1927001039__auto____27).Invoke_O__O(trees__7)
//line :327:1
		tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(Lit_45, tmp12)), nil)) } else {
//line :326:1
			tmp7 = nil }; var tmp15 any = /*line :324:1*/tmp7.Ref(); var tmp16 *jrt.String; if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(out__8)) { tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_78.GetRawRoot__O()).Invoke_O__O(out__8))) } else { tmp16 = nil }; var tmp17 any = /*line :324:1*/tmp16.Ref(); var tmp18 *jrt.String; var tmp19 any; var and__1927000168__auto____24 any = lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(cwd__9); if






	jrt.A2g_Truth(and__1927000168__auto____24) { tmp19 = lang.IFn_Cast(A_arbace_box_A_const_72.GetRawRoot__O()).Invoke_O_O__O(cwd__9, Lit_9) } else { tmp19 = and__1927000168__auto____24 }; if jrt.A2g_Truth(tmp19) { tmp18 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_78.GetRawRoot__O()).Invoke_O__O(cwd__9))) } else { tmp18 = nil }; var tmp20 any = /*line :324:1*/tmp18.Ref(); var tmp21 *jrt.String; var tmp22 any; var and__1927000168__auto____24_2 any = ram__10; if







	jrt.A2g_Truth(and__1927000168__auto____24_2) { tmp22 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(ram__10)).Ref() } else { tmp22 = and__1927000168__auto____24_2 }; if jrt.A2g_Truth(tmp22) { tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_49, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(ram__10)).Ref())) } else { tmp21 = nil }; var tmp23 any = /*line :324:1*/tmp21.Ref(); var tmp24 *jrt.String; var tmp25 any; var and__1927000168__auto____24_3 any = cpus__11; if








	jrt.A2g_Truth(and__1927000168__auto____24_3) { tmp25 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(cpus__11)).Ref() } else { tmp25 = and__1927000168__auto____24_3 }; if jrt.A2g_Truth(tmp25) { tmp24 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_50, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(cpus__11)).Ref())) } else { tmp24 = nil }; return /*line :324:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, image__4, nil, tmp4, tmp6, tmp15, tmp17, tmp20, tmp23, tmp24.Ref(), nil)).Ref() }
//line :322:1
func A_arbace_box_request_text_v__533000094_A_New() *A_arbace_box_request_text_v__533000094_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_v__533000094_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Invoke_O_O__O(self, xs__1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_29.GetRawRoot__O(), lang.IFn_Cast(A_arbace_box_A_const_76.GetRawRoot__O()).Invoke_O_O__O(Lit_56, lang.IFn_Cast(A_arbace_box_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_78.GetRawRoot__O(), xs__1))), nil)).Ref() }





func A_arbace_box_request_text_iter__533000096__533000100_A_New() *A_arbace_box_request_text_iter__533000096__533000100_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Ctor() {}
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Invoke_O_O__O(self, s__533000097__1 any) any { var tmp1 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(self, s__533000097__1); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(p0, p1 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A{}; t.Ctor_O_O(p0, p1); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Ctor_O_O(c__iter__533000096, c__s__533000097 any) { t.F_iter__533000096 = c__iter__533000096; t.F_s__533000097 = c__s__533000097 }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Invoke_O__O(self any) any { { var s__533000097__1 any; var t_ any = t.F_s__533000097; t.F_s__533000097 = nil; s__533000097__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_A_const_91.GetRawRoot__O()).Invoke_O__O(s__533000097__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__533000097__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_92.GetRawRoot__O()).Invoke_O__O(s__533000097__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_A_const_93.GetRawRoot__O()).Invoke_O__O(s__533000097__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__533000099__6 any = lang.IFn_Cast(A_arbace_box_A_const_94.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(b__533000099__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); return lang.IFn_Cast(A_arbace_box_A_const_97.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_100.GetRawRoot__O()).Invoke_O__O(b__533000099__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_101.GetRawRoot__O()).Invoke_O__O(s__533000097__3))) } else { return lang.IFn_Cast(A_arbace_box_A_const_97.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_100.GetRawRoot__O()).Invoke_O__O(b__533000099__6), nil) } } else { var vec__533000107__4 any = lang.IFn_Cast(A_arbace_box_A_const_98.GetRawRoot__O()).Invoke_O__O(s__533000097__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__533000107__4, lang.RT_IntCast_J__I(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O(vec__533000107__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); return lang.IFn_Cast(A_arbace_box_A_const_99.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_54, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_78.GetRawRoot__O()).Invoke_O__O(p__5), nil, h__6, nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_102.GetRawRoot__O()).Invoke_O__O(s__533000097__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Ctor_O_I_O(c__b__533000099 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000099 = c__b__533000099; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Invoke_O__O(self any) any { { var i__533000098__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__533000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__533000103__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__533000098__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__533000103__2, lang.RT_IntCast_J__I(0), nil); var h__4 any = lang.RT_Nth_O_I_O__O(vec__533000103__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_95.GetRawRoot__O()); var tmp3 any = t.F_b__533000099; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_54, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_78.GetRawRoot__O()).Invoke_O__O(p__3), nil, h__4, nil)).Ref()); i__533000098__1 = lang.Numbers_Unchecked_inc_J__J(i__533000098__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }







func A_arbace_box_spawn_A_New() *A_arbace_box_spawn_A { A_arbace_box_A_Init(); t := &A_arbace_box_spawn_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_box_spawn_A) Ctor() {}
//line :336:1
func (t *A_arbace_box_spawn_A) Invoke_O_O__O(self, req__0 any) any { var h__2 any; if




	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_A_const_120.GetRawRoot__O()).Invoke_O__O(req__0)) { h__2 = lang.IFn_Cast(A_arbace_box_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_122.GetRawRoot__O()).Invoke_O__O(req__0)) } else { h__2 = req__0 }; var n__3 any = /*line :336:1*/lang.IFn_Cast(A_arbace_box_A_const_121.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_38.GetRawRoot__O()).Invoke_O_O__O(h__2, Lit_62)); if






	lang.Numbers_IsNeg_O__Z(n__3) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_21; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_123, h__2))) }; return n__3 }


func A_arbace_box_result_A_New() *A_arbace_box_result_A { A_arbace_box_A_Init(); t := &A_arbace_box_result_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_box_result_A) Ctor() {}
//line :347:1
func (t *A_arbace_box_result_A) Invoke_O_O__O(self, h__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_box_A_const_52.GetRawRoot__O()).Invoke_O__O(h__0); if



	lang.Util_Identical_O_O__Z(s__2, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_46; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0))) }; return /*line :353:1*/ lang.IFn_Cast(A_arbace_box_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_A_const_87.GetRawRoot__O()).Invoke_O__O(s__2), A_arbace_box_A_const_27, h__0) }

func A_arbace_box_spawn_wait_A_New() *A_arbace_box_spawn_wait_A { A_arbace_box_A_Init(); t := &A_arbace_box_spawn_wait_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Ctor() {}
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Invoke_O_O__O(self, n__0 any) any { var h__2 any = lang.Numbers_Byte_array_O__B1(A_arbace_box_A_const_22).Ref(); if



	lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_box_A_const_125.GetRawRoot__O()).Invoke_O_O__O(n__0, h__2))) { } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_box_A_const_21; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_64, nil, Lit_65), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_126, n__0))) }; return /*line :361:1*/ lang.IFn_Cast(A_arbace_box_A_const_124.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_35.GetRawRoot__O()).Invoke_O__O(h__2)) }

func A_arbace_box_run_A_New() *A_arbace_box_run_A { A_arbace_box_A_Init(); t := &A_arbace_box_run_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_box_run_A) Ctor() {}
//line :363:1
func (t *A_arbace_box_run_A) Invoke_O_O__O(self, req__0 any) any {


	return lang.IFn_Cast(A_arbace_box_A_const_127.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_A_const_128.GetRawRoot__O()).Invoke_O__O(req__0))
}














type A_arbace_box_A struct{ jrt.Object }

var A_arbace_box_A_const_pool *jrt.RefArray

var A_arbace_box_A_const_0 *lang.Var

var A_arbace_box_A_const_1 *lang.Var

var A_arbace_box_A_const_2 any

var A_arbace_box_A_const_3 *lang.Keyword

var A_arbace_box_A_const_4 any

var A_arbace_box_A_const_5 any

var A_arbace_box_A_const_6 any

var A_arbace_box_A_const_7 *lang.Var

var A_arbace_box_A_const_8 *lang.Var

var A_arbace_box_A_const_9 *lang.Var

var A_arbace_box_A_const_10 any

var A_arbace_box_A_const_11 *lang.Var

var A_arbace_box_A_const_12 *lang.Var

var A_arbace_box_A_const_13 *lang.Var

var A_arbace_box_A_const_14 *lang.Keyword

var A_arbace_box_A_const_15 *lang.Var

var A_arbace_box_A_const_16 *lang.Keyword

var A_arbace_box_A_const_17 *lang.Var

var A_arbace_box_A_const_18 *lang.Keyword

var A_arbace_box_A_const_19 *lang.Keyword

var A_arbace_box_A_const_20 *lang.Keyword

var A_arbace_box_A_const_21 *lang.Keyword

var A_arbace_box_A_const_22 any

var A_arbace_box_A_const_23 *lang.Var

var A_arbace_box_A_const_24 *lang.Var

var A_arbace_box_A_const_25 any

var A_arbace_box_A_const_26 *lang.Keyword

var A_arbace_box_A_const_27 *lang.Keyword

var A_arbace_box_A_const_28 *lang.Var

var A_arbace_box_A_const_29 *lang.Var

var A_arbace_box_A_const_30 *lang.Var

var A_arbace_box_A_const_31 *lang.Var

var A_arbace_box_A_const_32 *lang.Keyword

var A_arbace_box_A_const_33 *lang.Var

var A_arbace_box_A_const_34 *lang.Var

var A_arbace_box_A_const_35 *lang.Var

var A_arbace_box_A_const_36 *lang.Var

var A_arbace_box_A_const_37 *lang.Keyword

var A_arbace_box_A_const_38 *lang.Var

var A_arbace_box_A_const_39 *lang.Var

var A_arbace_box_A_const_40 *lang.Var

var A_arbace_box_A_const_41 *lang.Var

var A_arbace_box_A_const_42 *lang.Var

var A_arbace_box_A_const_43 any

var A_arbace_box_A_const_44 any

var A_arbace_box_A_const_45 *lang.Var

var A_arbace_box_A_const_46 *lang.Keyword

var A_arbace_box_A_const_47 *lang.Var

var A_arbace_box_A_const_48 *lang.Var

var A_arbace_box_A_const_49 *lang.Var

var A_arbace_box_A_const_50 *lang.Var

var A_arbace_box_A_const_51 *lang.Var

var A_arbace_box_A_const_52 *lang.Var

var A_arbace_box_A_const_53 *lang.Var

var A_arbace_box_A_const_54 *lang.Keyword

var A_arbace_box_A_const_55 *lang.Var

var A_arbace_box_A_const_56 *lang.Var

var A_arbace_box_A_const_57 *lang.Var

var A_arbace_box_A_const_58 *lang.Var

var A_arbace_box_A_const_59 *lang.Var

var A_arbace_box_A_const_60 *lang.Var

var A_arbace_box_A_const_61 *jrt.Class

var A_arbace_box_A_const_62 any

var A_arbace_box_A_const_63 *jrt.Class

var A_arbace_box_A_const_64 *lang.Keyword

var A_arbace_box_A_const_65 *lang.Var

var A_arbace_box_A_const_66 *lang.Var

var A_arbace_box_A_const_67 *lang.Var

var A_arbace_box_A_const_68 *lang.Var

var A_arbace_box_A_const_69 *lang.Var

var A_arbace_box_A_const_70 *lang.Var

var A_arbace_box_A_const_71 any

var A_arbace_box_A_const_72 *lang.Var

var A_arbace_box_A_const_73 any

var A_arbace_box_A_const_74 any

var A_arbace_box_A_const_75 *lang.Var

var A_arbace_box_A_const_76 *lang.Var

var A_arbace_box_A_const_77 *lang.Var

var A_arbace_box_A_const_78 *lang.Var

var A_arbace_box_A_const_79 *lang.Keyword

var A_arbace_box_A_const_80 *lang.Keyword

var A_arbace_box_A_const_81 *lang.Var

var A_arbace_box_A_const_82 *lang.Keyword

var A_arbace_box_A_const_83 *lang.Var

var A_arbace_box_A_const_84 *lang.Var

var A_arbace_box_A_const_85 *lang.Var

var A_arbace_box_A_const_86 *lang.Var

var A_arbace_box_A_const_87 *lang.Var

var A_arbace_box_A_const_88 *lang.Var

var A_arbace_box_A_const_89 *lang.Var

var A_arbace_box_A_const_90 *lang.Var

var A_arbace_box_A_const_91 *lang.Var

var A_arbace_box_A_const_92 *lang.Var

var A_arbace_box_A_const_93 *lang.Var

var A_arbace_box_A_const_94 *lang.Var

var A_arbace_box_A_const_95 *lang.Var

var A_arbace_box_A_const_96 *lang.Var

var A_arbace_box_A_const_97 *lang.Var

var A_arbace_box_A_const_98 *lang.Var

var A_arbace_box_A_const_99 *lang.Var

var A_arbace_box_A_const_100 *lang.Var

var A_arbace_box_A_const_101 *lang.Var

var A_arbace_box_A_const_102 *lang.Var

var A_arbace_box_A_const_103 *lang.Var

var A_arbace_box_A_const_104 *lang.Var

var A_arbace_box_A_const_105 *lang.Var

var A_arbace_box_A_const_106 *lang.Var

var A_arbace_box_A_const_107 *lang.Var

var A_arbace_box_A_const_108 *lang.Var

var A_arbace_box_A_const_109 *lang.Var

var A_arbace_box_A_const_110 *lang.Var

var A_arbace_box_A_const_111 *lang.Var

var A_arbace_box_A_const_112 *lang.Keyword

var A_arbace_box_A_const_113 *lang.Keyword

var A_arbace_box_A_const_114 *lang.Keyword

var A_arbace_box_A_const_115 *lang.Keyword

var A_arbace_box_A_const_116 *lang.Keyword

var A_arbace_box_A_const_117 *lang.Keyword

var A_arbace_box_A_const_118 *lang.Keyword

var A_arbace_box_A_const_119 *lang.Keyword

var A_arbace_box_A_const_120 *lang.Var

var A_arbace_box_A_const_121 *lang.Var

var A_arbace_box_A_const_122 *lang.Var

var A_arbace_box_A_const_123 *lang.Keyword

var A_arbace_box_A_const_124 *lang.Var

var A_arbace_box_A_const_125 *lang.Var

var A_arbace_box_A_const_126 *lang.Keyword

var A_arbace_box_A_const_127 *lang.Var

var A_arbace_box_A_const_128 *lang.Var

var A_arbace_box_A_init jrt.ClassInit

func A_arbace_box_A_Init() { if !A_arbace_box_A_init.Done() { A_arbace_box_A_init.Run(A_arbace_box_A_clinit) } }

func A_arbace_box_A_clinit() { A_arbace_box_A_clinit_p0(); A_arbace_box_A_clinit_p1(); A_arbace_box_A_clinit_p2(); A_arbace_box_A_clinit_p3(); A_arbace_box_A_clinit_p4(); A_arbace_box_A_clinit_p5(); A_arbace_box_A_clinit_p6(); A_arbace_box_A_clinit_p7(); A_arbace_box_A_clinit_p8(); A_arbace_box_A_clinit_p9(); A_arbace_box_A_clinit_p10() }

func A_arbace_box_A_clinit_p0() { A_arbace_box_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 166); A_arbace_box_A_const_0 = lang.Var_Cast(A_arbace_box_A_const_pool.A[37]); A_arbace_box_A_const_1 = lang.Var_Cast(A_arbace_box_A_const_pool.A[38]); A_arbace_box_A_const_2 = A_arbace_box_A_const_pool.A[39]; A_arbace_box_A_const_3 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[40]); A_arbace_box_A_const_4 = A_arbace_box_A_const_pool.A[41]; A_arbace_box_A_const_5 = A_arbace_box_A_const_pool.A[42]; A_arbace_box_A_const_6 = A_arbace_box_A_const_pool.A[43]; A_arbace_box_A_const_7 = lang.Var_Cast(A_arbace_box_A_const_pool.A[44]); A_arbace_box_A_const_8 = lang.Var_Cast(A_arbace_box_A_const_pool.A[45]); A_arbace_box_A_const_9 = lang.Var_Cast(A_arbace_box_A_const_pool.A[46]); A_arbace_box_A_const_10 = A_arbace_box_A_const_pool.A[47]; A_arbace_box_A_const_11 = lang.Var_Cast(A_arbace_box_A_const_pool.A[48]) }

func A_arbace_box_A_clinit_p1() { A_arbace_box_A_const_12 = lang.Var_Cast(A_arbace_box_A_const_pool.A[49]); A_arbace_box_A_const_13 = lang.Var_Cast(A_arbace_box_A_const_pool.A[50]); A_arbace_box_A_const_14 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[51]); A_arbace_box_A_const_15 = lang.Var_Cast(A_arbace_box_A_const_pool.A[52]); A_arbace_box_A_const_16 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[53]); A_arbace_box_A_const_17 = lang.Var_Cast(A_arbace_box_A_const_pool.A[54]); A_arbace_box_A_const_18 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[55]); A_arbace_box_A_const_19 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[56]); A_arbace_box_A_const_20 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[57]); A_arbace_box_A_const_21 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[58]); A_arbace_box_A_const_22 = A_arbace_box_A_const_pool.A[59]; A_arbace_box_A_const_23 = lang.Var_Cast(A_arbace_box_A_const_pool.A[60]) }

func A_arbace_box_A_clinit_p2() { A_arbace_box_A_const_24 = lang.Var_Cast(A_arbace_box_A_const_pool.A[61]); A_arbace_box_A_const_25 = A_arbace_box_A_const_pool.A[62]; A_arbace_box_A_const_26 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[63]); A_arbace_box_A_const_27 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[64]); A_arbace_box_A_const_28 = lang.Var_Cast(A_arbace_box_A_const_pool.A[65]); A_arbace_box_A_const_29 = lang.Var_Cast(A_arbace_box_A_const_pool.A[66]); A_arbace_box_A_const_30 = lang.Var_Cast(A_arbace_box_A_const_pool.A[67]); A_arbace_box_A_const_31 = lang.Var_Cast(A_arbace_box_A_const_pool.A[68]); A_arbace_box_A_const_32 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[69]); A_arbace_box_A_const_33 = lang.Var_Cast(A_arbace_box_A_const_pool.A[70]); A_arbace_box_A_const_34 = lang.Var_Cast(A_arbace_box_A_const_pool.A[71]); A_arbace_box_A_const_35 = lang.Var_Cast(A_arbace_box_A_const_pool.A[72]) }

func A_arbace_box_A_clinit_p3() { A_arbace_box_A_const_36 = lang.Var_Cast(A_arbace_box_A_const_pool.A[73]); A_arbace_box_A_const_37 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[74]); A_arbace_box_A_const_38 = lang.Var_Cast(A_arbace_box_A_const_pool.A[75]); A_arbace_box_A_const_39 = lang.Var_Cast(A_arbace_box_A_const_pool.A[76]); A_arbace_box_A_const_40 = lang.Var_Cast(A_arbace_box_A_const_pool.A[77]); A_arbace_box_A_const_41 = lang.Var_Cast(A_arbace_box_A_const_pool.A[78]); A_arbace_box_A_const_42 = lang.Var_Cast(A_arbace_box_A_const_pool.A[79]); A_arbace_box_A_const_43 = A_arbace_box_A_const_pool.A[80]; A_arbace_box_A_const_44 = A_arbace_box_A_const_pool.A[81]; A_arbace_box_A_const_45 = lang.Var_Cast(A_arbace_box_A_const_pool.A[82]); A_arbace_box_A_const_46 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[83]); A_arbace_box_A_const_47 = lang.Var_Cast(A_arbace_box_A_const_pool.A[84]) }

func A_arbace_box_A_clinit_p4() { A_arbace_box_A_const_48 = lang.Var_Cast(A_arbace_box_A_const_pool.A[85]); A_arbace_box_A_const_49 = lang.Var_Cast(A_arbace_box_A_const_pool.A[86]); A_arbace_box_A_const_50 = lang.Var_Cast(A_arbace_box_A_const_pool.A[87]); A_arbace_box_A_const_51 = lang.Var_Cast(A_arbace_box_A_const_pool.A[88]); A_arbace_box_A_const_52 = lang.Var_Cast(A_arbace_box_A_const_pool.A[89]); A_arbace_box_A_const_53 = lang.Var_Cast(A_arbace_box_A_const_pool.A[90]); A_arbace_box_A_const_54 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[91]); A_arbace_box_A_const_55 = lang.Var_Cast(A_arbace_box_A_const_pool.A[92]); A_arbace_box_A_const_56 = lang.Var_Cast(A_arbace_box_A_const_pool.A[93]); A_arbace_box_A_const_57 = lang.Var_Cast(A_arbace_box_A_const_pool.A[94]); A_arbace_box_A_const_58 = lang.Var_Cast(A_arbace_box_A_const_pool.A[95]); A_arbace_box_A_const_59 = lang.Var_Cast(A_arbace_box_A_const_pool.A[96]) }

func A_arbace_box_A_clinit_p5() { A_arbace_box_A_const_60 = lang.Var_Cast(A_arbace_box_A_const_pool.A[97]); A_arbace_box_A_const_61 = jrt.Class_Cast(A_arbace_box_A_const_pool.A[98]); A_arbace_box_A_const_62 = A_arbace_box_A_const_pool.A[99]; A_arbace_box_A_const_63 = jrt.Class_Cast(A_arbace_box_A_const_pool.A[100]); A_arbace_box_A_const_64 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[101]); A_arbace_box_A_const_65 = lang.Var_Cast(A_arbace_box_A_const_pool.A[102]); A_arbace_box_A_const_66 = lang.Var_Cast(A_arbace_box_A_const_pool.A[103]); A_arbace_box_A_const_67 = lang.Var_Cast(A_arbace_box_A_const_pool.A[104]); A_arbace_box_A_const_68 = lang.Var_Cast(A_arbace_box_A_const_pool.A[105]); A_arbace_box_A_const_69 = lang.Var_Cast(A_arbace_box_A_const_pool.A[106]); A_arbace_box_A_const_70 = lang.Var_Cast(A_arbace_box_A_const_pool.A[107]); A_arbace_box_A_const_71 = A_arbace_box_A_const_pool.A[108] }

func A_arbace_box_A_clinit_p6() { A_arbace_box_A_const_72 = lang.Var_Cast(A_arbace_box_A_const_pool.A[109]); A_arbace_box_A_const_73 = A_arbace_box_A_const_pool.A[110]; A_arbace_box_A_const_74 = A_arbace_box_A_const_pool.A[111]; A_arbace_box_A_const_75 = lang.Var_Cast(A_arbace_box_A_const_pool.A[112]); A_arbace_box_A_const_76 = lang.Var_Cast(A_arbace_box_A_const_pool.A[113]); A_arbace_box_A_const_77 = lang.Var_Cast(A_arbace_box_A_const_pool.A[114]); A_arbace_box_A_const_78 = lang.Var_Cast(A_arbace_box_A_const_pool.A[115]); A_arbace_box_A_const_79 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[116]); A_arbace_box_A_const_80 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[117]); A_arbace_box_A_const_81 = lang.Var_Cast(A_arbace_box_A_const_pool.A[118]); A_arbace_box_A_const_82 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[119]); A_arbace_box_A_const_83 = lang.Var_Cast(A_arbace_box_A_const_pool.A[120]) }

func A_arbace_box_A_clinit_p7() { A_arbace_box_A_const_84 = lang.Var_Cast(A_arbace_box_A_const_pool.A[121]); A_arbace_box_A_const_85 = lang.Var_Cast(A_arbace_box_A_const_pool.A[122]); A_arbace_box_A_const_86 = lang.Var_Cast(A_arbace_box_A_const_pool.A[123]); A_arbace_box_A_const_87 = lang.Var_Cast(A_arbace_box_A_const_pool.A[124]); A_arbace_box_A_const_88 = lang.Var_Cast(A_arbace_box_A_const_pool.A[125]); A_arbace_box_A_const_89 = lang.Var_Cast(A_arbace_box_A_const_pool.A[126]); A_arbace_box_A_const_90 = lang.Var_Cast(A_arbace_box_A_const_pool.A[127]); A_arbace_box_A_const_91 = lang.Var_Cast(A_arbace_box_A_const_pool.A[128]); A_arbace_box_A_const_92 = lang.Var_Cast(A_arbace_box_A_const_pool.A[129]); A_arbace_box_A_const_93 = lang.Var_Cast(A_arbace_box_A_const_pool.A[130]); A_arbace_box_A_const_94 = lang.Var_Cast(A_arbace_box_A_const_pool.A[131]); A_arbace_box_A_const_95 = lang.Var_Cast(A_arbace_box_A_const_pool.A[132]) }

func A_arbace_box_A_clinit_p8() { A_arbace_box_A_const_96 = lang.Var_Cast(A_arbace_box_A_const_pool.A[133]); A_arbace_box_A_const_97 = lang.Var_Cast(A_arbace_box_A_const_pool.A[134]); A_arbace_box_A_const_98 = lang.Var_Cast(A_arbace_box_A_const_pool.A[135]); A_arbace_box_A_const_99 = lang.Var_Cast(A_arbace_box_A_const_pool.A[136]); A_arbace_box_A_const_100 = lang.Var_Cast(A_arbace_box_A_const_pool.A[137]); A_arbace_box_A_const_101 = lang.Var_Cast(A_arbace_box_A_const_pool.A[138]); A_arbace_box_A_const_102 = lang.Var_Cast(A_arbace_box_A_const_pool.A[139]); A_arbace_box_A_const_103 = lang.Var_Cast(A_arbace_box_A_const_pool.A[140]); A_arbace_box_A_const_104 = lang.Var_Cast(A_arbace_box_A_const_pool.A[141]); A_arbace_box_A_const_105 = lang.Var_Cast(A_arbace_box_A_const_pool.A[142]); A_arbace_box_A_const_106 = lang.Var_Cast(A_arbace_box_A_const_pool.A[143]); A_arbace_box_A_const_107 = lang.Var_Cast(A_arbace_box_A_const_pool.A[144]) }

func A_arbace_box_A_clinit_p9() { A_arbace_box_A_const_108 = lang.Var_Cast(A_arbace_box_A_const_pool.A[145]); A_arbace_box_A_const_109 = lang.Var_Cast(A_arbace_box_A_const_pool.A[146]); A_arbace_box_A_const_110 = lang.Var_Cast(A_arbace_box_A_const_pool.A[147]); A_arbace_box_A_const_111 = lang.Var_Cast(A_arbace_box_A_const_pool.A[148]); A_arbace_box_A_const_112 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[149]); A_arbace_box_A_const_113 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[150]); A_arbace_box_A_const_114 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[151]); A_arbace_box_A_const_115 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[152]); A_arbace_box_A_const_116 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[153]); A_arbace_box_A_const_117 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[154]); A_arbace_box_A_const_118 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[155]); A_arbace_box_A_const_119 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[156]) }

func A_arbace_box_A_clinit_p10() { A_arbace_box_A_const_120 = lang.Var_Cast(A_arbace_box_A_const_pool.A[157]); A_arbace_box_A_const_121 = lang.Var_Cast(A_arbace_box_A_const_pool.A[158]); A_arbace_box_A_const_122 = lang.Var_Cast(A_arbace_box_A_const_pool.A[159]); A_arbace_box_A_const_123 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[160]); A_arbace_box_A_const_124 = lang.Var_Cast(A_arbace_box_A_const_pool.A[161]); A_arbace_box_A_const_125 = lang.Var_Cast(A_arbace_box_A_const_pool.A[162]); A_arbace_box_A_const_126 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[163]); A_arbace_box_A_const_127 = lang.Var_Cast(A_arbace_box_A_const_pool.A[164]); A_arbace_box_A_const_128 = lang.Var_Cast(A_arbace_box_A_const_pool.A[165]) }

func A_arbace_box_A_New() *A_arbace_box_A { A_arbace_box_A_Init(); t := &A_arbace_box_A{}; t.Ctor(); return t }

func (t *A_arbace_box_A) Ctor() {}

func (t *A_arbace_box_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_A) GetClass__Class() *jrt.Class { return A_arbace_box_A_class }

func (t *A_arbace_box_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_A); return ok }

func A_arbace_box_A_Cast(x any) *A_arbace_box_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_A_class)) }; return v }



type A_arbace_box_answer_A struct{ a2g_header uint64 }

var A_arbace_box_answer_A_fn_class *jrt.Class



type A_arbace_box_boxed_QMARK__A struct{ a2g_header uint64 }

var A_arbace_box_boxed_QMARK__A_fn_class *jrt.Class



type A_arbace_box_eval533000004_A struct{ jrt.Object }

func A_arbace_box_eval533000004_A_New() *A_arbace_box_eval533000004_A { t := &A_arbace_box_eval533000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000004_A) Ctor() {}

func (t *A_arbace_box_eval533000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000004_A_class }

func (t *A_arbace_box_eval533000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000004_A); return ok }

func A_arbace_box_eval533000004_A_Cast(x any) *A_arbace_box_eval533000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000004_A_class)) }; return v }



type A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A struct{ a2g_header uint64 }

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_fn_class *jrt.Class



type A_arbace_box_eval533000008_A struct{ jrt.Object }

func A_arbace_box_eval533000008_A_New() *A_arbace_box_eval533000008_A { t := &A_arbace_box_eval533000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000008_A) Ctor() {}

func (t *A_arbace_box_eval533000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000008_A_class }

func (t *A_arbace_box_eval533000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000008_A); return ok }

func A_arbace_box_eval533000008_A_Cast(x any) *A_arbace_box_eval533000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000008_A_class)) }; return v }



type A_arbace_box_eval533000008_fn__533000009_A struct{ a2g_header uint64 }

var A_arbace_box_eval533000008_fn__533000009_A_fn_class *jrt.Class



type A_arbace_box_fail_A struct{ a2g_header uint64 }

var A_arbace_box_fail_A_fn_class *jrt.Class



type A_arbace_box_fs_dir_A struct{ a2g_header uint64 }

var A_arbace_box_fs_dir_A_fn_class *jrt.Class



type A_arbace_box_get_A struct{ a2g_header uint64 }

var A_arbace_box_get_A_fn_class *jrt.Class



type A_arbace_box_get_bytes_A struct{ a2g_header uint64 }

var A_arbace_box_get_bytes_A_fn_class *jrt.Class



type A_arbace_box_get_tree_A struct{ a2g_header uint64 }

var A_arbace_box_get_tree_A_fn_class *jrt.Class



type A_arbace_box_get_tree_fn__533000077_A struct{ a2g_header uint64; F_o, F_eh any }

var A_arbace_box_get_tree_fn__533000077_A_fn_class *jrt.Class



type A_arbace_box_get_tree_fn__533000085_A struct{ a2g_header uint64; F_eh, F_o any }

var A_arbace_box_get_tree_fn__533000085_A_fn_class *jrt.Class



type A_arbace_box_hash_bytes_A struct{ a2g_header uint64 }

var A_arbace_box_hash_bytes_A_fn_class *jrt.Class



type A_arbace_box_hex_A struct{ a2g_header uint64 }

var A_arbace_box_hex_A_fn_class *jrt.Class



type A_arbace_box_load_A struct{ a2g_header uint64 }

var A_arbace_box_load_A_fn_class *jrt.Class



type A_arbace_box_load_fs_BANG__A struct{ a2g_header uint64 }

var A_arbace_box_load_fs_BANG__A_fn_class *jrt.Class



type A_arbace_box_load_ref_A struct{ a2g_header uint64 }

var A_arbace_box_load_ref_A_fn_class *jrt.Class



type A_arbace_box_put_A struct{ a2g_header uint64 }

var A_arbace_box_put_A_fn_class *jrt.Class



type A_arbace_box_put_BANG__A struct{ a2g_header uint64 }

var A_arbace_box_put_BANG__A_fn_class *jrt.Class



type A_arbace_box_put_dir_A struct{ a2g_header uint64 }

var A_arbace_box_put_dir_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_A struct{ a2g_header uint64 }

var A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A struct{ a2g_header uint64; F_s__533000057, F_iter__533000056 any }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A struct{ a2g_header uint64; F_b__533000059 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class *jrt.Class



type A_arbace_box_put_file_A struct{ a2g_header uint64 }

var A_arbace_box_put_file_A_fn_class *jrt.Class



type A_arbace_box_put_tree_A struct{ a2g_header uint64 }

var A_arbace_box_put_tree_A_fn_class *jrt.Class



type A_arbace_box_quote_str_A struct{ a2g_header uint64 }

var A_arbace_box_quote_str_A_fn_class *jrt.Class



type A_arbace_box_ref_A struct{ a2g_header uint64 }

var A_arbace_box_ref_A_fn_class *jrt.Class



type A_arbace_box_ref_BANG__A struct{ a2g_header uint64 }

var A_arbace_box_ref_BANG__A_fn_class *jrt.Class



type A_arbace_box_ref_BANG__answer_A struct{ a2g_header uint64 }

var A_arbace_box_ref_BANG__answer_A_fn_class *jrt.Class



type A_arbace_box_request_text_A struct{ a2g_header uint64 }

var A_arbace_box_request_text_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_A struct{ a2g_header uint64 }

var A_arbace_box_request_text_iter__533000096__533000100_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A struct{ a2g_header uint64; F_iter__533000096, F_s__533000097 any }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A struct{ a2g_header uint64; F_b__533000099 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class *jrt.Class



type A_arbace_box_request_text_v__533000094_A struct{ a2g_header uint64 }

var A_arbace_box_request_text_v__533000094_A_fn_class *jrt.Class



type A_arbace_box_result_A struct{ a2g_header uint64 }

var A_arbace_box_result_A_fn_class *jrt.Class



type A_arbace_box_run_A struct{ a2g_header uint64 }

var A_arbace_box_run_A_fn_class *jrt.Class



type A_arbace_box_save_fs_BANG__A struct{ a2g_header uint64 }

var A_arbace_box_save_fs_BANG__A_fn_class *jrt.Class



type A_arbace_box_size_A struct{ a2g_header uint64 }

var A_arbace_box_size_A_fn_class *jrt.Class



type A_arbace_box_spawn_A struct{ a2g_header uint64 }

var A_arbace_box_spawn_A_fn_class *jrt.Class



type A_arbace_box_spawn_wait_A struct{ a2g_header uint64 }

var A_arbace_box_spawn_wait_A_fn_class *jrt.Class



type A_arbace_box_store_QMARK__A struct{ a2g_header uint64 }

var A_arbace_box_store_QMARK__A_fn_class *jrt.Class



type A_arbace_box_tree_A struct{ a2g_header uint64 }

var A_arbace_box_tree_A_fn_class *jrt.Class



type A_arbace_box_tree_get_A struct{ a2g_header uint64 }

var A_arbace_box_tree_get_A_fn_class *jrt.Class



type A_arbace_box_tree_get_fn__533000088_A struct{ a2g_header uint64 }

var A_arbace_box_tree_get_fn__533000088_A_fn_class *jrt.Class



type A_arbace_box_tree_name_QMARK__A struct{ a2g_header uint64 }

var A_arbace_box_tree_name_QMARK__A_fn_class *jrt.Class



type A_arbace_box_tree_name_QMARK__fn__533000038_A struct{ a2g_header uint64 }

var A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class *jrt.Class



type A_arbace_box_tree_text_A struct{ a2g_header uint64 }

var A_arbace_box_tree_text_A_fn_class *jrt.Class



type A_arbace_box_tree_text_fn__533000042_A struct{ a2g_header uint64 }

var A_arbace_box_tree_text_fn__533000042_A_fn_class *jrt.Class



type A_arbace_box_utf8_compare_A struct{ a2g_header uint64 }

var A_arbace_box_utf8_compare_A_fn_class *jrt.Class
