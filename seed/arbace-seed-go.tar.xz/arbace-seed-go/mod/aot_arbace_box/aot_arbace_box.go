//line aot_arbace_box.ae:1
package aot_arbace_box

import (
	"arbace/aot_arbace_box_host"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_edn"
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_New() *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A { A_arbace_box_A_Init(); t := &A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_A_const_1, A_arbace_box_A_const_2, A_arbace_box_A_const_3); lang.IFn_Cast(A_arbace_box_A_const_4.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_A_const_5, A_arbace_box_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :4:1
func A_arbace_box_eval533000008_fn__533000009_A_New() *A_arbace_box_eval533000008_fn__533000009_A { A_arbace_box_A_Init(); t := &A_arbace_box_eval533000008_fn__533000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_box_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_box_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_A_const_10.GetRawRoot__O(), A_arbace_box_A_const_11) }







































func A_arbace_box_fail_A_New() *A_arbace_box_fail_A { A_arbace_box_A_Init(); t := &A_arbace_box_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_fail_A) Invoke_O_O_O_O__O(self, kind__0, msg__1, data__2 any) any { var tmp1 any; var root_22 any = A_arbace_box_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_24 lang.IFn; if
											linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = msg__1; var arg_26 any; var root_27 any = A_arbace_box_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = data__2; var arg_31 any = A_arbace_box_A_const_14; var arg_32 any = kind__0; if linked_28 == nil { arg_26 = ifn_29.Invoke_O_O_O__O(arg_30, arg_31, arg_32) } else { arg_26 = linked_28.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_27, arg_30, arg_31, arg_32) }; if linked_23 == nil { tmp1 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; /*line :44:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_box_answer_A_New() *A_arbace_box_answer_A { A_arbace_box_A_Init(); t := &A_arbace_box_answer_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_answer_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_answer_A) InvokePrim_O_J_O_O__O(self any, code__0 int64, what__1, data__2 any) any { var G__533000013__4_ int64 = code__0; switch


	int32(G__533000013__4_) { case -5: if -5 == G__533000013__4_ {


		var root_34 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, A_arbace_box_fail_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = A_arbace_box_A_const_16; var arg_38 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, what__1, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_box_A_const_18.Invoke_O__O(data__2)))).Ref(); var arg_39 any = data__2; if linked_35 == nil { return ifn_36.Invoke_O_O_O__O(arg_37, arg_38, arg_39) } else { return linked_35.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_34, arg_37, arg_38, arg_39) } }
//line :50:1
	case -4: if -4 == G__533000013__4_ {

		var root_44 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, A_arbace_box_fail_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_box_A_const_19; var arg_48 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(); var arg_49 any = data__2; if linked_45 == nil { return ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { return linked_45.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) } }
//line :50:1
	case -3: if -3 == G__533000013__4_ {
		var root_50 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_box_fail_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = A_arbace_box_A_const_20; var arg_54 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(); var arg_55 any = data__2; if linked_51 == nil { return ifn_52.Invoke_O_O_O__O(arg_53, arg_54, arg_55) } else { return linked_51.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_50, arg_53, arg_54, arg_55) } }
//line :50:1
	default:}; var root_56 any =




	A_arbace_box_A_const_15.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, A_arbace_box_fail_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = A_arbace_box_A_const_21; var arg_60 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(); var arg_61 any = data__2; if linked_57 == nil { return ifn_58.Invoke_O_O_O__O(arg_59, arg_60, arg_61) } else { return linked_57.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_56, arg_59, arg_60, arg_61) } }
//line :47:1
func (t *A_arbace_box_answer_A) Invoke_O_O_O_O__O(self, p_code__0, what__1, data__2 any) any { return t.InvokePrim_O_J_O_O__O(self, lang.RT_LongCast_O__J_NoInit(p_code__0), what__1, data__2) }









func A_arbace_box_hash_bytes_A_New() *A_arbace_box_hash_bytes_A { A_arbace_box_A_Init(); t := &A_arbace_box_hash_bytes_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Ctor() {}
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Invoke_O_O_O__O(self, h__0, what__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any; var root_62 any = A_arbace_box_A_const_23.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = h__0; if linked_63 == nil { and__1927000168__auto____3 = ifn_64.Invoke_O__O(arg_65) } else { and__1927000168__auto____3 = linked_63.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_66 any = A_arbace_box_A_const_24.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = A_arbace_box_A_const_25; var arg_70 any = h__0; if linked_67 == nil { tmp1 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { tmp1 = linked_67.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { } else {
		var root_71 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_box_fail_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_box_A_const_26; var arg_75 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, what__1, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(h__0))).Ref(); var arg_76 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_72 == nil { ifn_73.Invoke_O_O_O__O(arg_74, arg_75, arg_76) } else { linked_72.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_71, arg_74, arg_75, arg_76) } }
//line :57:1
	var b__3 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J_NoInit(32); var i__5 int64 = 0; L1: for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, n__1927000701__auto____4) {
			var tmp2 *jrt.ByteArray = jrt.ByteArray_Cast(b__3); var tmp3 int32 = lang.RT_IntCast_J__I_NoInit(i__5); var tmp4 any; var root_81 any = A_arbace_box_A_const_28.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = h__0; var arg_85 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, i__5)).Ref(); var arg_86 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(2, lang.Numbers_Multiply_J_J__J_NoInit(2, i__5))).Ref(); if linked_82 == nil { tmp4 = ifn_83.Invoke_O_O_O__O(arg_84, arg_85, arg_86) } else { tmp4 = linked_82.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_81, arg_84, arg_85, arg_86) }; jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aset_B1_I_B__B_NoInit(tmp2, tmp3, lang.RT_UncheckedByteCast_I__B_NoInit(jrt.Integer_ParseInt_String_I__I_NoInit(jrt.String_Cast(tmp4), lang.RT_IntCast_J__I_NoInit(16)))))
//line :63:1
			i__5 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__5); continue L1 }
//line :57:1
		break L1 }; return b__3
}








func A_arbace_box_hex_A_New() *A_arbace_box_hex_A { A_arbace_box_A_Init(); t := &A_arbace_box_hex_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_box_hex_A) Ctor() {}
//line :67:1
func (t *A_arbace_box_hex_A) Invoke_O_O__O(self, b__0 any) any { var sb__2 any = jrt.StringBuilder_New_I(lang.RT_IntCast_J__I_NoInit(64)); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0))); var i__4 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var x__5 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__4))).Ref()), 255)

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__5, 4)), lang.RT_IntCast_J__I_NoInit(16)))
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__5, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :71:1
		i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :67:1
	break L1 }; var root_87 any =







	A_arbace_box_A_const_29.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = sb__2; if linked_88 == nil { return ifn_89.Invoke_O__O(arg_90) } else { return linked_88.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_87, arg_90) } }

func A_arbace_box_store_QMARK__A_New() *A_arbace_box_store_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_store_QMARK__A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Ctor() {}
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Invoke_O__O(self any) any {


	var tmp1 bool; var na_91 any; var root_92 any = A_arbace_box_A_const_30.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_box_host.A_arbace_box_host_status_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; if linked_93 == nil { na_91 = ifn_94.Invoke__O() } else { na_91 = linked_93.(*aot_arbace_box_host.A_arbace_box_host_status_A).Invoke_O__O(root_92) }; if jrt.Long_InstanceOf(na_91) { var n0_95 int64 = jrt.NN(jrt.Long_Cast(na_91)).LongValue__J(); tmp1 = n0_95 == 0 } else { if jrt.Double_InstanceOf(na_91) { var n0_95_2 float64 = jrt.NN(jrt.Double_Cast(na_91)).DoubleValue__D(); tmp1 = n0_95_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_91) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref()
}
func A_arbace_box_put_A_New() *A_arbace_box_put_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_put_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_put_A) Invoke_O_O__O(self, x__0 any) any { var b__2 any; var tmp1 any; var root_96 any = A_arbace_box_A_const_23.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_98 lang.IFn; if


	linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = x__0; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(tmp1) { b__2 = jrt.NN(jrt.String_Cast(x__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else { var tmp2 any; var root_100 any = A_arbace_box_A_const_31.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_bytes_QMARK__A_fn_class); var ifn_102 lang.IFn
		if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = x__0; if linked_101 == nil { tmp2 = ifn_102.Invoke_O__O(arg_103) } else { tmp2 = linked_101.(*aot_arbace_core.A_arbace_core_bytes_QMARK__A).Invoke_O_O__O(root_100, arg_103) }
//line :85:1
		if jrt.J2g_Truth(tmp2) { b__2 = x__0 } else { if A_arbace_box_A_const_32 != nil { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_24, nil); var tmp4 any; var root_104 any = A_arbace_box_A_const_33.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_106 lang.IFn


			if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = x__0; if linked_105 == nil { tmp4 = ifn_106.Invoke_O__O(arg_107) } else { tmp4 = linked_105.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_104, arg_107) }
//line :85:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4))))) } else { b__2 = nil } } }; var h__3 any = /*line :82:1*/lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var code__4 any; var root_108 any = A_arbace_box_A_const_34.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_box_host.A_arbace_box_host_put_A_fn_class); var ifn_110 lang.IFn; if







	linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = b__2; var arg_112 any = h__3; if linked_109 == nil { code__4 = ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { code__4 = linked_109.(*aot_arbace_box_host.A_arbace_box_host_put_A).Invoke_O_O_O__O(root_108, arg_111, arg_112) }; var tmp5 bool; var na_117 any = code__4; if
	jrt.Long_InstanceOf(na_117) { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_117)).LongValue__J(); tmp5 = n0_118 == 0 } else { if jrt.Double_InstanceOf(na_117) { var n0_118_2 float64 = jrt.NN(jrt.Double_Cast(na_117)).DoubleValue__D(); tmp5 = n0_118_2 == 0.0 } else { tmp5 = lang.Numbers_IsZero_O__Z_NoInit(na_117) } }; if tmp5 { } else {
		var root_119 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_119, A_arbace_box_answer_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = code__4; var arg_123 any = Lit_25; var tmp6 any = A_arbace_box_A_const_37; var arg_124 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__2))).Ref())); if linked_120 == nil { ifn_121.Invoke_O_O_O__O(arg_122, arg_123, arg_124) } else { linked_120.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_119, lang.RT_LongCast_O__J_NoInit(arg_122), arg_123, arg_124) } }; var root_113 any =
	A_arbace_box_A_const_35.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_box_hex_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = h__3; if linked_114 == nil { return ifn_115.Invoke_O__O(arg_116) } else { return linked_114.(*A_arbace_box_hex_A).Invoke_O_O__O(root_113, arg_116) } }

func A_arbace_box_get_bytes_A_New() *A_arbace_box_get_bytes_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_bytes_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_box_get_bytes_A) Ctor() {}
//line :95:1
func (t *A_arbace_box_get_bytes_A) Invoke_O_O__O(self, h__0 any) any { var hb__2 any; var root_125 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_box_hash_bytes_A_fn_class); var ifn_127 lang.IFn; if


	linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = h__0; var arg_129 any = Lit_11; if linked_126 == nil { hb__2 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { hb__2 = linked_126.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; var n__3 any; var root_130 any = /*line :95:1*/A_arbace_box_A_const_39.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_box_host.A_arbace_box_host_size_A_fn_class); var ifn_132 lang.IFn; if



	linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = hb__2; if linked_131 == nil { n__3 = ifn_132.Invoke_O__O(arg_133) } else { n__3 = linked_131.(*aot_arbace_box_host.A_arbace_box_host_size_A).Invoke_O_O__O(root_130, arg_133) }; if
	lang.Util_Equiv_O_J__Z_NoInit(n__3, -1) { return nil } else { var tmp1 bool
		var na_134 any = n__3
		if jrt.Long_InstanceOf(na_134) { var n0_135 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); tmp1 = n0_135 < 0 } else { if jrt.Double_InstanceOf(na_134) { var n0_135_2 float64 = jrt.NN(jrt.Double_Cast(na_134)).DoubleValue__D(); tmp1 = n0_135_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_134) } }
//line :100:1
		if tmp1 {

			var root_136 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_136, A_arbace_box_answer_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = n__3; var arg_140 any = Lit_11; var arg_141 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_136, lang.RT_LongCast_O__J_NoInit(arg_139), arg_140, arg_141) } } else {
//line :100:1
				if A_arbace_box_A_const_32 != nil {


					var root_142 any = A_arbace_box_A_const_40.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_box_host.A_arbace_box_host_read_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = hb__2; if linked_143 == nil { return ifn_144.Invoke_O__O(arg_145) } else { return linked_143.(*aot_arbace_box_host.A_arbace_box_host_read_A).Invoke_O_O__O(root_142, arg_145) } } else {
//line :100:1
						return nil } } } }




func A_arbace_box_get_A_New() *A_arbace_box_get_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_box_get_A) Ctor() {}
//line :105:1
func (t *A_arbace_box_get_A) Invoke_O_O__O(self, h__0 any) any { var temp__1927000414__auto____2 any; var root_146 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_box_get_bytes_A_fn_class); var ifn_148 lang.IFn; if


	linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = h__0; if linked_147 == nil { temp__1927000414__auto____2 = ifn_148.Invoke_O__O(arg_149) } else { temp__1927000414__auto____2 = linked_147.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var b__3 any = temp__1927000414__auto____2; return jrt.String_New_B1_Charset(jrt.ByteArray_Cast(b__3), jrt.StandardCharsets_UTF_8) } else { return nil } }


func A_arbace_box_size_A_New() *A_arbace_box_size_A { A_arbace_box_A_Init(); t := &A_arbace_box_size_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_box_size_A) Ctor() {}
//line :111:1
func (t *A_arbace_box_size_A) Invoke_O_O__O(self, h__0 any) any { var n__2 any; var root_150 any = A_arbace_box_A_const_39.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_box_host.A_arbace_box_host_size_A_fn_class); var ifn_152 lang.IFn; if


	linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_154 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, A_arbace_box_hash_bytes_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = h__0; var arg_158 any = Lit_61; if linked_155 == nil { arg_153 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { arg_153 = linked_155.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }; if linked_151 == nil { n__2 = ifn_152.Invoke_O__O(arg_153) } else { n__2 = linked_151.(*aot_arbace_box_host.A_arbace_box_host_size_A).Invoke_O_O__O(root_150, arg_153) }; if
	lang.Util_Equiv_O_J__Z_NoInit(n__2, -1) { return nil } else { var tmp1 bool
		var na_159 any = n__2
		if jrt.Long_InstanceOf(na_159) { var n0_160 int64 = jrt.NN(jrt.Long_Cast(na_159)).LongValue__J(); tmp1 = n0_160 < 0 } else { if jrt.Double_InstanceOf(na_159) { var n0_160_2 float64 = jrt.NN(jrt.Double_Cast(na_159)).DoubleValue__D(); tmp1 = n0_160_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_159) } }
//line :115:1
		if tmp1 {

			var root_161 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_161, A_arbace_box_answer_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = n__2; var arg_165 any = Lit_61; var arg_166 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_162 == nil { return ifn_163.Invoke_O_O_O__O(arg_164, arg_165, arg_166) } else { return linked_162.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_161, lang.RT_LongCast_O__J_NoInit(arg_164), arg_165, arg_166) } } else {
//line :115:1
				if A_arbace_box_A_const_32 != nil { return n__2 } else { return nil } } } }




func A_arbace_box_ref_A_New() *A_arbace_box_ref_A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_box_ref_A) Ctor() {}
//line :120:1
func (t *A_arbace_box_ref_A) Invoke_O_O__O(self, name__0 any) any { var h__2 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var code__3 any; var root_167 any = A_arbace_box_A_const_42.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_box_host.A_arbace_box_host_ref_A_fn_class); var ifn_169 lang.IFn; if



	linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any; var root_172 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = name__0; if linked_173 == nil { arg_170 = ifn_174.Invoke_O__O(arg_175) } else { arg_170 = linked_173.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_172, arg_175) }; var arg_171 any = h__2; if linked_168 == nil { code__3 = ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { code__3 = linked_168.(*aot_arbace_box_host.A_arbace_box_host_ref_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) }; var G__533000022__4_ any = code__3; if
	jrt.Number_InstanceOf(G__533000022__4_) { switch jrt.Number_Cast(G__533000022__4_).IntValue__I() { case -1: if lang.Util_Equiv_O_O__Z_NoInit(G__533000022__4_, A_arbace_box_A_const_43) { return nil }; case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__533000022__4_, A_arbace_box_A_const_44) {
		var root_177 any = A_arbace_box_A_const_35.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_box_hex_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = h__2; if linked_178 == nil { return ifn_179.Invoke_O__O(arg_180) } else { return linked_178.(*A_arbace_box_hex_A).Invoke_O_O__O(root_177, arg_180) } }
//line :125:1
	default:} }; var root_181 any =


	A_arbace_box_A_const_36.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_181, A_arbace_box_answer_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = code__3; var arg_185 any = Lit_34; var arg_186 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__0)); if linked_182 == nil { return ifn_183.Invoke_O_O_O__O(arg_184, arg_185, arg_186) } else { return linked_182.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_181, lang.RT_LongCast_O__J_NoInit(arg_184), arg_185, arg_186) } }

func A_arbace_box_ref_BANG__answer_A_New() *A_arbace_box_ref_BANG__answer_A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_BANG__answer_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Ctor() {}
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Invoke_O_O_O_O__O(self, code__0, name__1, h__2 any) any {
	if lang.Util_Equiv_O_J__Z_NoInit(code__0, -2) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 bool; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_J__Z_NoInit(code__0, -1)

		if and__1927000168__auto____4 { var tmp2 any; var root_187 any = A_arbace_box_A_const_45.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_box_size_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = h__2; if linked_188 == nil { tmp2 = ifn_189.Invoke_O__O(arg_190) } else { tmp2 = linked_188.(*A_arbace_box_size_A).Invoke_O_O__O(root_187, arg_190) }; tmp1 = lang.Util_Identical_O_O__Z_NoInit(tmp2, nil) } else { tmp1 = and__1927000168__auto____4 }
//line :131:1
		if tmp1 {


			var root_191 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, A_arbace_box_fail_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = A_arbace_box_A_const_46; var arg_195 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(); var arg_196 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__1, A_arbace_box_A_const_27, h__2)); if linked_192 == nil { return ifn_193.Invoke_O_O_O__O(arg_194, arg_195, arg_196) } else { return linked_192.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_191, arg_194, arg_195, arg_196) } } else {
//line :131:1
				if A_arbace_box_A_const_32 != nil {



					var root_197 any = A_arbace_box_A_const_36.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_197, A_arbace_box_answer_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = code__0; var arg_201 any = Lit_35; var arg_202 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__1, A_arbace_box_A_const_27, h__2)); if linked_198 == nil { return ifn_199.Invoke_O_O_O__O(arg_200, arg_201, arg_202) } else { return linked_198.(*A_arbace_box_answer_A).InvokePrim_O_J_O_O__O(root_197, lang.RT_LongCast_O__J_NoInit(arg_200), arg_201, arg_202) } } else {
//line :131:1
						return nil
					}
			}
	}
}

func A_arbace_box_ref_BANG__A_New() *A_arbace_box_ref_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_ref_BANG__A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Ctor() {}
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O_O__O(self, name__0, h__1, old__2 any) any { var ob__4 any; if






	lang.Util_Identical_O_O__Z_NoInit(old__2, nil) { ob__4 = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref() } else { var root_203 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, A_arbace_box_hash_bytes_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = old__2; var arg_207 any = Lit_35; if linked_204 == nil { ob__4 = ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { ob__4 = linked_204.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } }; var code__5 any; var root_208 any = /*line :137:1*/A_arbace_box_A_const_47.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_box_host.A_arbace_box_host_set_ref_A_fn_class); var ifn_210 lang.IFn; if







	linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var root_214 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = name__0; if linked_215 == nil { arg_211 = ifn_216.Invoke_O__O(arg_217) } else { arg_211 = linked_215.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_214, arg_217) }; var arg_212 any; var root_218 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, A_arbace_box_hash_bytes_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = h__1; var arg_222 any = Lit_35; if linked_219 == nil { arg_212 = ifn_220.Invoke_O_O__O(arg_221, arg_222) } else { arg_212 = linked_219.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_218, arg_221, arg_222) }; var arg_213 any = ob__4; if linked_209 == nil { code__5 = ifn_210.Invoke_O_O_O__O(arg_211, arg_212, arg_213) } else { code__5 = linked_209.(*aot_arbace_box_host.A_arbace_box_host_set_ref_A).Invoke_O_O_O_O__O(root_208, arg_211, arg_212, arg_213) }; var or__1927000174__auto____6 bool; var na_223 any = code__5; if
	jrt.Long_InstanceOf(na_223) { var n0_224 int64 = jrt.NN(jrt.Long_Cast(na_223)).LongValue__J(); or__1927000174__auto____6 = n0_224 == 0 } else { if jrt.Double_InstanceOf(na_223) { var n0_224_2 float64 = jrt.NN(jrt.Double_Cast(na_223)).DoubleValue__D(); or__1927000174__auto____6 = n0_224_2 == 0.0 } else { or__1927000174__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_223) } }; if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var root_225 any = A_arbace_box_A_const_48.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, A_arbace_box_ref_BANG__answer_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = code__5; var arg_229 any = name__0; var arg_230 any = h__1; if linked_226 == nil { return ifn_227.Invoke_O_O_O__O(arg_228, arg_229, arg_230) } else { return linked_226.(*A_arbace_box_ref_BANG__answer_A).Invoke_O_O_O_O__O(root_225, arg_228, arg_229, arg_230) } } }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O__O(self, name__0, h__1 any) any { var code__3 any; var root_231 any = A_arbace_box_A_const_47.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_box_host.A_arbace_box_host_set_ref_A_fn_class); var ifn_233 lang.IFn; if



	linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var root_237 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = name__0; if linked_238 == nil { arg_234 = ifn_239.Invoke_O__O(arg_240) } else { arg_234 = linked_238.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_237, arg_240) }; var arg_235 any; var root_241 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_box_hash_bytes_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = h__1; var arg_245 any = Lit_35; if linked_242 == nil { arg_235 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { arg_235 = linked_242.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }; var arg_236 any; if linked_232 == nil { code__3 = ifn_233.Invoke_O_O_O__O(arg_234, arg_235, arg_236) } else { code__3 = linked_232.(*aot_arbace_box_host.A_arbace_box_host_set_ref_A).Invoke_O_O_O_O__O(root_231, arg_234, arg_235, arg_236) }; var or__1927000174__auto____4 bool; var na_246 any = code__3; if
	jrt.Long_InstanceOf(na_246) { var n0_247 int64 = jrt.NN(jrt.Long_Cast(na_246)).LongValue__J(); or__1927000174__auto____4 = n0_247 == 0 } else { if jrt.Double_InstanceOf(na_246) { var n0_247_2 float64 = jrt.NN(jrt.Double_Cast(na_246)).DoubleValue__D(); or__1927000174__auto____4 = n0_247_2 == 0.0 } else { or__1927000174__auto____4 = lang.Numbers_IsZero_O__Z_NoInit(na_246) } }; if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var root_248 any = A_arbace_box_A_const_48.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, A_arbace_box_ref_BANG__answer_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = code__3; var arg_252 any = name__0; var arg_253 any = h__1; if linked_249 == nil { return ifn_250.Invoke_O_O_O__O(arg_251, arg_252, arg_253) } else { return linked_249.(*A_arbace_box_ref_BANG__answer_A).Invoke_O_O_O_O__O(root_248, arg_251, arg_252, arg_253) } } }





func A_arbace_box_put_BANG__A_New() *A_arbace_box_put_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_put_BANG__A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_box_put_BANG__A) Ctor() {}
//line :148:1
func (t *A_arbace_box_put_BANG__A) Invoke_O_O_O__O(self, name__0, x__1 any) any { var h__3 any; var root_254 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, A_arbace_box_put_A_fn_class); var ifn_256 lang.IFn; if


	linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = x__1; if linked_255 == nil { h__3 = ifn_256.Invoke_O__O(arg_257) } else { h__3 = linked_255.(*A_arbace_box_put_A).Invoke_O_O__O(root_254, arg_257) }; var root_258 any =
	A_arbace_box_A_const_50.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_box_ref_BANG__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = name__0; var arg_262 any = h__3; if linked_259 == nil { ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { linked_259.(*A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_258, arg_261, arg_262) }; return h__3 }


func A_arbace_box_load_A_New() *A_arbace_box_load_A { A_arbace_box_A_Init(); t := &A_arbace_box_load_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_box_load_A) Ctor() {}
//line :155:1
func (t *A_arbace_box_load_A) Invoke_O_O__O(self, name__0 any) any { var G__533000027__2_ any; var root_263 any = A_arbace_box_A_const_51.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, A_arbace_box_ref_A_fn_class); var ifn_265 lang.IFn; if


	linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = name__0; if linked_264 == nil { G__533000027__2_ = ifn_265.Invoke_O__O(arg_266) } else { G__533000027__2_ = linked_264.(*A_arbace_box_ref_A).Invoke_O_O__O(root_263, arg_266) }; if lang.Util_Identical_O_O__Z_NoInit(G__533000027__2_, nil) { return nil } else { var root_267 any = A_arbace_box_A_const_52.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, A_arbace_box_get_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = G__533000027__2_; if linked_268 == nil { return ifn_269.Invoke_O__O(arg_270) } else { return linked_268.(*A_arbace_box_get_A).Invoke_O_O__O(root_267, arg_270) } } }

func A_arbace_box_load_ref_A_New() *A_arbace_box_load_ref_A { A_arbace_box_A_Init(); t := &A_arbace_box_load_ref_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_box_load_ref_A) Ctor() {}
//line :160:1
func (t *A_arbace_box_load_ref_A) Invoke_O_O__O(self, name__0 any) any { var src__2 any; var root_271 any = A_arbace_box_A_const_53.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_box_load_A_fn_class); var ifn_273 lang.IFn; if



	linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = name__0; if linked_272 == nil { src__2 = ifn_273.Invoke_O__O(arg_274) } else { src__2 = linked_272.(*A_arbace_box_load_A).Invoke_O_O__O(root_271, arg_274) }; if
	lang.Util_Identical_O_O__Z_NoInit(src__2, nil) {
		var root_279 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, A_arbace_box_fail_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_box_A_const_54; var arg_283 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)).Ref(); var arg_284 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, name__0)); if linked_280 == nil { ifn_281.Invoke_O_O_O__O(arg_282, arg_283, arg_284) } else { linked_280.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_279, arg_282, arg_283, arg_284) } }; var tmp1 jrt.Reader_I =
	jrt.StringReader_New_String(jrt.String_Cast(src__2)); var tmp2 *jrt.String = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)); var tmp3 any; var root_275 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = name__0; if linked_276 == nil { tmp3 = ifn_277.Invoke_O__O(arg_278) } else { tmp3 = linked_276.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_275, arg_278) }; return lang.Compiler_Load_Reader_String_String__O_NoInit(tmp1, tmp2, jrt.String_Cast(tmp3)) }

func A_arbace_box_boxed_QMARK__A_New() *A_arbace_box_boxed_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_boxed_QMARK__A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Ctor() {}
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Invoke_O__O(self any) any {
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_5, jrt.System_GetProperty_String__String(Lit_6).Ref())).Ref()
}
func A_arbace_box_fs_dir_A_New() *A_arbace_box_fs_dir_A { A_arbace_box_A_Init(); t := &A_arbace_box_fs_dir_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_box_fs_dir_A) Ctor() {}
//line :172:1
func (t *A_arbace_box_fs_dir_A) Invoke_O_O_O__O(self, dir__0, what__1 any) any {
	var tmp1 any; var root_285 any = A_arbace_box_A_const_55.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_287 lang.IFn
	if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = dir__0; if linked_286 == nil { tmp1 = ifn_287.Invoke_O__O(arg_288) } else { tmp1 = linked_286.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_285, arg_288) }
//line :173:1
	if jrt.J2g_Truth(tmp1) {
		var root_289 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = dir__0; if linked_290 == nil { return ifn_291.Invoke_O__O(arg_292) } else { return linked_290.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_289, arg_292) } } else {
//line :173:1
			var tmp2 any; var root_293 any = A_arbace_box_A_const_56.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, A_arbace_box_boxed_QMARK__A_fn_class); var ifn_295 lang.IFn

			if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; if linked_294 == nil { tmp2 = ifn_295.Invoke__O() } else { tmp2 = linked_294.(*A_arbace_box_boxed_QMARK__A).Invoke_O__O(root_293) }
//line :173:1
			if jrt.J2g_Truth(tmp2) { return Lit_9 } else { if A_arbace_box_A_const_32 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, what__1, nil))))) } else { return nil
			}
			}
		}
}

func A_arbace_box_save_fs_BANG__A_New() *A_arbace_box_save_fs_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_save_fs_BANG__A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Ctor() {}
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any; var root_296 any = A_arbace_box_A_const_57.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_box_fs_dir_A_fn_class); var ifn_298 lang.IFn; if





	linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = dir__1; var arg_300 any = Lit_58; if linked_297 == nil { d__3 = ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { d__3 = linked_297.(*A_arbace_box_fs_dir_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) }; var err__4 any; var root_301 any = /*line :179:1*/A_arbace_box_A_const_58.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_303 lang.IFn; if






	linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = A_arbace_box_A_const_59; var arg_305 any = A_arbace_box_A_const_60; if linked_302 == nil { err__4 = ifn_303.Invoke_O_O__O(arg_304, arg_305) } else { err__4 = linked_302.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_301, arg_304, arg_305) }; var tar__5 any; var root_306 any = /*line :179:1*/A_arbace_box_A_const_61.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_box_host.A_arbace_box_host_tar_A_fn_class); var ifn_308 lang.IFn; if







	linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = d__3; var arg_310 any = err__4; if linked_307 == nil { tar__5 = ifn_308.Invoke_O_O__O(arg_309, arg_310) } else { tar__5 = linked_307.(*aot_arbace_box_host.A_arbace_box_host_tar_A).Invoke_O_O_O__O(root_306, arg_309, arg_310) }; if
	lang.Util_Identical_O_O__Z_NoInit(tar__5, nil) {
		var root_316 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_box_fail_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_box_A_const_21; var tmp1 *jrt.Class = A_arbace_box_A_const_63; var arg_320 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_60, jrt.RefArrayOf(jrt.Object_class, err__4, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_J__I_NoInit(0)).Ref())))).Ref(); var arg_321 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0, A_arbace_box_A_const_64, d__3)); if linked_317 == nil { ifn_318.Invoke_O_O_O__O(arg_319, arg_320, arg_321) } else { linked_317.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_316, arg_319, arg_320, arg_321) } }; var root_311 any =
	A_arbace_box_A_const_62.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, A_arbace_box_put_BANG__A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = ref__0; var arg_315 any = tar__5; if linked_312 == nil { return ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { return linked_312.(*A_arbace_box_put_BANG__A).Invoke_O_O_O__O(root_311, arg_314, arg_315) } }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {



	var root_322 any = A_arbace_box_A_const_65.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_box_save_fs_BANG__A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = ref__0; var arg_326 any; if linked_323 == nil { return ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { return linked_323.(*A_arbace_box_save_fs_BANG__A).Invoke_O_O_O__O(root_322, arg_325, arg_326)
	}
}






func A_arbace_box_load_fs_BANG__A_New() *A_arbace_box_load_fs_BANG__A { A_arbace_box_A_Init(); t := &A_arbace_box_load_fs_BANG__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Ctor() {}
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any; var root_327 any = A_arbace_box_A_const_57.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, A_arbace_box_fs_dir_A_fn_class); var ifn_329 lang.IFn; if




	linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = dir__1; var arg_331 any = Lit_18; if linked_328 == nil { d__3 = ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { d__3 = linked_328.(*A_arbace_box_fs_dir_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }; var tar__4 any; var G__533000033__4_ any; var root_332 any = /*line :192:1*/A_arbace_box_A_const_51.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, A_arbace_box_ref_A_fn_class); var ifn_334 lang.IFn; if





	linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = ref__0; if linked_333 == nil { G__533000033__4_ = ifn_334.Invoke_O__O(arg_335) } else { G__533000033__4_ = linked_333.(*A_arbace_box_ref_A).Invoke_O_O__O(root_332, arg_335) }; if lang.Util_Identical_O_O__Z_NoInit(G__533000033__4_, nil) { tar__4 = nil } else { var root_336 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, A_arbace_box_get_bytes_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = G__533000033__4_; if linked_337 == nil { tar__4 = ifn_338.Invoke_O__O(arg_339) } else { tar__4 = linked_337.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_336, arg_339) } }; if
	lang.Util_Identical_O_O__Z_NoInit(tar__4, nil) {
		var root_340 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, A_arbace_box_fail_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = A_arbace_box_A_const_54; var arg_344 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, ref__0)).Ref(); var arg_345 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0)); if linked_341 == nil { ifn_342.Invoke_O_O_O__O(arg_343, arg_344, arg_345) } else { linked_341.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_340, arg_343, arg_344, arg_345) } }; var temp__1927000414__auto____5 any; var root_346 any = /*line :192:1*/A_arbace_box_A_const_66.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_box_host.A_arbace_box_host_untar_A_fn_class); var ifn_348 lang.IFn; if








	linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = tar__4; var arg_350 any = d__3; if linked_347 == nil { temp__1927000414__auto____5 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { temp__1927000414__auto____5 = linked_347.(*aot_arbace_box_host.A_arbace_box_host_untar_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var e__6 any = temp__1927000414__auto____5; var root_351 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_box_fail_A_fn_class); var ifn_353 lang.IFn
		if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = A_arbace_box_A_const_21; var arg_355 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, e__6)).Ref(); var arg_356 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, ref__0, A_arbace_box_A_const_64, d__3)); if linked_352 == nil { ifn_353.Invoke_O_O_O__O(arg_354, arg_355, arg_356) } else { linked_352.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_351, arg_354, arg_355, arg_356) } }; return nil }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {


	var root_357 any = A_arbace_box_A_const_67.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, A_arbace_box_load_fs_BANG__A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = ref__0; var arg_361 any; if linked_358 == nil { return ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { return linked_358.(*A_arbace_box_load_fs_BANG__A).Invoke_O_O_O__O(root_357, arg_360, arg_361)
	}
}













func A_arbace_box_quote_str_A_New() *A_arbace_box_quote_str_A { A_arbace_box_A_Init(); t := &A_arbace_box_quote_str_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_quote_str_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_quote_str_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_CharSequence_CharSequence__String(Lit_31, Lit_32)).Replace_CharSequence_CharSequence__String(Lit_30, Lit_33).Ref(), nil)).Ref()
}
func A_arbace_box_utf8_compare_A_New() *A_arbace_box_utf8_compare_A { A_arbace_box_A_Init(); t := &A_arbace_box_utf8_compare_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Ctor() {}
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { { var x__3 any = jrt.NN(jrt.String_Cast(a__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var y__4 any = jrt.NN(jrt.String_Cast(b__1)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var n__5 int64 = lang.Numbers_Min_J_J__J_NoInit(int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(x__3))), int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(y__4)))); var i__6 int64 = 0; L1: for {






	if lang.Numbers_Lt_J_J__Z_NoInit(i__6, n__5) { var c__7 int32 = lang.Util_Compare_O_O__I_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(x__3), lang.RT_IntCast_J__I_NoInit(i__6))).Ref()), 255)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(y__4), lang.RT_IntCast_J__I_NoInit(i__6))).Ref()), 255)).Ref())

		if lang.Numbers_IsZero_J__Z_NoInit(int64(c__7)) { i__6 = lang.Numbers_Inc_J__J_NoInit(i__6); continue L1 } else { return jrt.Integer_ValueOf_I__Integer_NoInit(c__7).Ref() } } else {
			return jrt.Integer_ValueOf_I__Integer_NoInit(lang.Util_Compare_O_O__I_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(x__3))).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(y__4))).Ref())).Ref() } } }; /*line :216:1*/panic("j2g: unreachable") }











func A_arbace_box_tree_name_QMARK__A_New() *A_arbace_box_tree_name_QMARK__A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_name_QMARK__A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Ctor() {}
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_362 any = A_arbace_box_A_const_23.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_364 lang.IFn; if
										linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = n__0; if linked_363 == nil { and__1927000168__auto____2 = ifn_364.Invoke_O__O(arg_365) } else { and__1927000168__auto____2 = linked_363.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_362, arg_365) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_366 any = A_arbace_box_A_const_68.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any; var root_370 any = A_arbace_box_A_const_69.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_box_A_const_70; var arg_374 any = n__0; if linked_371 == nil { arg_369 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { arg_369 = linked_371.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; if linked_367 == nil { and__1927000168__auto____3 = ifn_368.Invoke_O__O(arg_369) } else { and__1927000168__auto____3 = linked_367.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_366, arg_369) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
											var root_375 any = A_arbace_box_A_const_71.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var tmp1 any = A_arbace_box_tree_name_QMARK__fn__533000038_A_New(); var tmp2 *jrt.Class; var fncls__390 *jrt.Class = A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class; if fncls__390 == nil { var fncls__390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class = fncls__390d; tmp2 = fncls__390d } else { tmp2 = fncls__390 }; arg_378 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_379 any = n__0; if linked_376 == nil { return ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { return linked_376.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_375, arg_378, arg_379) } } else {
//line :229:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }
func A_arbace_box_tree_name_QMARK__fn__533000038_A_New() *A_arbace_box_tree_name_QMARK__fn__533000038_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_name_QMARK__fn__533000038_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Ctor() {}
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Invoke_O_O__O(self, p1__533000037_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_380 any = A_arbace_box_A_const_72.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = p1__533000037_SHARP___1; var arg_384 any = A_arbace_box_A_const_73; if linked_381 == nil { and__1927000168__auto____2 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { and__1927000168__auto____2 = linked_381.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_IntCast_O__I_NoInit(p1__533000037_SHARP___1)), 32); if and__1927000168__auto____3 { var root_385 any = A_arbace_box_A_const_72.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(p1__533000037_SHARP___1)).Ref(); var arg_389 any = A_arbace_box_A_const_74; if linked_386 == nil { return ifn_387.Invoke_O_O__O(arg_388, arg_389) } else { return linked_386.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_385, arg_388, arg_389) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_box_tree_text_A_New() *A_arbace_box_tree_text_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_text_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_box_tree_text_A) Ctor() {}
//line :232:1
func (t *A_arbace_box_tree_text_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_69, nil, Lit_41); var tmp2 any; var root_391 any = A_arbace_box_A_const_75.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_393 lang.IFn











	if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = A_arbace_box_A_const_29.GetRawRoot__O(); var arg_395 any; var root_396 any = A_arbace_box_A_const_76.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_398 lang.IFn
//line :246:1
	if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = Lit_70; var arg_400 any; var root_401 any = A_arbace_box_A_const_77.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_403 lang.IFn
//line :237:1
	if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any; var tmp3 any = A_arbace_box_tree_text_fn__533000042_A_New(); var tmp4 *jrt.Class; var fncls__440 *jrt.Class = A_arbace_box_tree_text_fn__533000042_A_fn_class; if fncls__440 == nil { var fncls__440d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_box_tree_text_fn__533000042_A_fn_class = fncls__440d; tmp4 = fncls__440d } else { tmp4 = fncls__440 }; arg_404 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_405 any; var root_441 any = A_arbace_box_A_const_83.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_443 lang.IFn
//line :236:1
	if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = A_arbace_box_A_const_84.GetRawRoot__O(); var arg_445 any = A_arbace_box_A_const_85.GetRawRoot__O(); var arg_446 any = m__0; if linked_442 == nil { arg_405 = ifn_443.Invoke_O_O_O__O(arg_444, arg_445, arg_446) } else { arg_405 = linked_442.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O_O__O(root_441, arg_444, arg_445, arg_446) }
	if linked_402 == nil { arg_400 = ifn_403.Invoke_O_O__O(arg_404, arg_405) } else { arg_400 = linked_402.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_401, arg_404, arg_405)
	}







	if linked_397 == nil { arg_395 = ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { arg_395 = linked_397.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) }
	if linked_392 == nil { tmp2 = ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { tmp2 = linked_392.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) }
//line :235:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref()
}
func A_arbace_box_tree_text_fn__533000042_A_New() *A_arbace_box_tree_text_fn__533000042_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_text_fn__533000042_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Ctor() {}
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Invoke_O_O__O(self, p__533000041__1 any) any { var vec__533000043__2 any = p__533000041__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000043__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__533000046__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000043__2, lang.RT_IntCast_J__I_NoInit(1), nil); var kind__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000046__4, lang.RT_IntCast_J__I_NoInit(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000046__4, lang.RT_IntCast_J__I_NoInit(1), nil); var size__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000046__4, lang.RT_IntCast_J__I_NoInit(2), nil); var e__8 any = vec__533000046__4; var tmp1 any; var root_421 any = A_arbace_box_A_const_82.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_box_tree_name_QMARK__A_fn_class); var ifn_423 lang.IFn; if
												linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = n__3; if linked_422 == nil { tmp1 = ifn_423.Invoke_O__O(arg_424) } else { tmp1 = linked_422.(*A_arbace_box_tree_name_QMARK__A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(tmp1) { } else {
													var root_425 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, A_arbace_box_fail_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = A_arbace_box_A_const_81; var arg_429 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(n__3))).Ref(); var arg_430 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, n__3)); if linked_426 == nil { ifn_427.Invoke_O_O_O__O(arg_428, arg_429, arg_430) } else { linked_426.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_425, arg_428, arg_429, arg_430) } }; var root_435 any =
												A_arbace_box_A_const_38.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, A_arbace_box_hash_bytes_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = h__6; var arg_439 any = Lit_73; if linked_436 == nil { ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { linked_436.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; var tmp2 /*line :241:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_56, nil); var tmp3 any; var root_406 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_box_quote_str_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = n__3; if linked_407 == nil { tmp3 = ifn_408.Invoke_O__O(arg_409) } else { tmp3 = linked_407.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_406, arg_409) }; var tmp4 any = tmp3; var tmp5 any; var G__533000049__12_ any = kind__5; L1:
												switch { default: switch lang.Util_Hash_O__I_NoInit(G__533000049__12_) >> 2 & 3 { case 1: if any(G__533000049__12_) == any(A_arbace_box_A_const_79) {
													tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(size__7)).Ref(), nil)).Ref()
//line :242:1
		break L1 }; case 2: if any(G__533000049__12_) == any(A_arbace_box_A_const_64) {

			tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, h__6, nil)).Ref()
//line :242:1
			break L1 }; case 3: if any(G__533000049__12_) == any(A_arbace_box_A_const_80) {
				tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(size__7)).Ref(), nil)).Ref()
//line :242:1
				break L1 }; default:
	}

		var root_411 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, A_arbace_box_fail_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = A_arbace_box_A_const_81; var arg_415 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_A_const_17.GetRawRoot__O()).Invoke_O__O(e__8))).Ref(); var arg_416 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_18, n__3)); if linked_412 == nil { tmp5 = ifn_413.Invoke_O_O_O__O(arg_414, arg_415, arg_416) } else { tmp5 = linked_412.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_411, arg_414, arg_415, arg_416) }}; return /*line :241:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref() }








func A_arbace_box_put_tree_A_New() *A_arbace_box_put_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_tree_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_box_put_tree_A) Ctor() {}
//line :250:1
func (t *A_arbace_box_put_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var root_447 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, A_arbace_box_put_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any; var root_451 any = A_arbace_box_A_const_86.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, A_arbace_box_tree_text_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = m__0; if linked_452 == nil { arg_450 = ifn_453.Invoke_O__O(arg_454) } else { arg_450 = linked_452.(*A_arbace_box_tree_text_A).Invoke_O_O__O(root_451, arg_454) }; if linked_448 == nil { return ifn_449.Invoke_O__O(arg_450) } else { return linked_448.(*A_arbace_box_put_A).Invoke_O_O__O(root_447, arg_450)
	} }
func A_arbace_box_tree_A_New() *A_arbace_box_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_box_tree_A) Ctor() {}
//line :255:1
func (t *A_arbace_box_tree_A) Invoke_O_O__O(self, h__0 any) any { var G__533000053__2_ any; var root_455 any = A_arbace_box_A_const_52.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, A_arbace_box_get_A_fn_class); var ifn_457 lang.IFn; if


	linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = h__0; if linked_456 == nil { G__533000053__2_ = ifn_457.Invoke_O__O(arg_458) } else { G__533000053__2_ = linked_456.(*A_arbace_box_get_A).Invoke_O_O__O(root_455, arg_458) }; if lang.Util_Identical_O_O__Z_NoInit(G__533000053__2_, nil) { return nil } else { var root_459 any = A_arbace_box_A_const_87.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = G__533000053__2_; if linked_460 == nil { return ifn_461.Invoke_O__O(arg_462) } else { return linked_460.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_459, arg_462) } } }

func A_arbace_box_put_file_A_New() *A_arbace_box_put_file_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_file_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_box_put_file_A) Ctor() {}
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O_O__O(self, x__0, exec__1 any) any { var h__3 any; var root_463 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, A_arbace_box_put_A_fn_class); var ifn_465 lang.IFn; if




	linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = x__0; if linked_464 == nil { h__3 = ifn_465.Invoke_O__O(arg_466) } else { h__3 = linked_464.(*A_arbace_box_put_A).Invoke_O_O__O(root_463, arg_466) }; var tmp1 /*line :260:1*/*lang.Keyword; if





	jrt.J2g_Truth(exec__1) { tmp1 = A_arbace_box_A_const_79 } else { tmp1 = A_arbace_box_A_const_80 }; var tmp2 any = /*line :260:1*/tmp1.Ref(); var tmp3 any; var root_467 any = A_arbace_box_A_const_45.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, A_arbace_box_size_A_fn_class); var ifn_469 lang.IFn; if





	linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = h__3; if linked_468 == nil { tmp3 = ifn_469.Invoke_O__O(arg_470) } else { tmp3 = linked_468.(*A_arbace_box_size_A).Invoke_O_O__O(root_467, arg_470) }; return /*line :260:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, h__3, tmp3) }
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O__O(self, x__0 any) any {


	var root_471 any = A_arbace_box_A_const_88.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_box_put_file_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = x__0; var arg_475 any = jrt.Boolean_FALSE.Ref(); if linked_472 == nil { return ifn_473.Invoke_O_O__O(arg_474, arg_475) } else { return linked_472.(*A_arbace_box_put_file_A).Invoke_O_O_O__O(root_471, arg_474, arg_475)
	}
}


func A_arbace_box_put_dir_A_New() *A_arbace_box_put_dir_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_box_put_dir_A) Ctor() {}
//line :268:1
func (t *A_arbace_box_put_dir_A) Invoke_O_O__O(self, dir__0 any) any { var d__2 any; var tmp1 any; var root_476 any = A_arbace_box_A_const_29.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_478 lang.IFn; if



	linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = dir__0; if linked_477 == nil { tmp1 = ifn_478.Invoke_O__O(arg_479) } else { tmp1 = linked_477.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_476, arg_479) }; d__2 = /*line :268:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); var fs__3 any = jrt.NN(jrt.File_Cast(d__2)).ListFiles__File1().Ref(); if





	lang.Util_Identical_O_O__Z_NoInit(fs__3, nil) {
		var root_566 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, A_arbace_box_fail_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = A_arbace_box_A_const_21; var arg_570 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, dir__0)).Ref(); var arg_571 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_64, dir__0)); if linked_567 == nil { ifn_568.Invoke_O_O_O__O(arg_569, arg_570, arg_571) } else { linked_567.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_566, arg_569, arg_570, arg_571) } }; var root_480 any =
	A_arbace_box_A_const_89.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, A_arbace_box_put_tree_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any; var root_484 any = A_arbace_box_A_const_90.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_486 lang.IFn; if
	linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_488 any; var iter__1927001039__auto____4 any; var tmp2 any = A_arbace_box_put_dir_iter__533000056__533000060_A_New(); var tmp3 *jrt.Class; var fncls__565 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class; if
	fncls__565 == nil { var fncls__565d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class = fncls__565d; tmp3 = fncls__565d } else { tmp3 = fncls__565 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_488 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__3); if /*line :277:1*/ linked_485 == nil { arg_483 = ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { arg_483 = linked_485.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) }; if /*line :276:1*/ linked_481 == nil { return ifn_482.Invoke_O__O(arg_483) } else { return linked_481.(*A_arbace_box_put_tree_A).Invoke_O_O__O(root_480, arg_483) } }

func A_arbace_box_put_dir_iter__533000056__533000060_A_New() *A_arbace_box_put_dir_iter__533000056__533000060_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Ctor() {}
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Invoke_O_O__O(self, s__533000057__1 any) any { var tmp1 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(s__533000057__1, self); var tmp2 *jrt.Class; var fncls__564 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class; if fncls__564 == nil { var fncls__564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class = fncls__564d; tmp2 = fncls__564d } else { tmp2 = fncls__564 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(p0, p1 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A{}; t.Ctor_O_O(p0, p1); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Ctor_O_O(c__s__533000057, c__iter__533000056 any) { t.F_s__533000057 = c__s__533000057; t.F_iter__533000056 = c__iter__533000056 }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Invoke_O__O(self any) any { { var s__533000057__1 any; var t_ any = t.F_s__533000057; t.F_s__533000057 = nil; s__533000057__1 = t_; for { var temp__1927000414__auto____2 any; var root_489 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = s__533000057__1; if linked_490 == nil { temp__1927000414__auto____2 = ifn_491.Invoke_O__O(arg_492) } else { temp__1927000414__auto____2 = linked_490.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_489, arg_492) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__533000057__3 any = temp__1927000414__auto____2; var tmp1 any; var root_493 any = A_arbace_box_A_const_92.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = s__533000057__3; if linked_494 == nil { tmp1 = ifn_495.Invoke_O__O(arg_496) } else { tmp1 = linked_494.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_493, arg_496) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_497 any = A_arbace_box_A_const_93.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = s__533000057__3; if linked_498 == nil { c__1927001037__auto____4 = ifn_499.Invoke_O__O(arg_500) } else { c__1927001037__auto____4 = linked_498.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_497, arg_500) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__533000059__6 any; var root_501 any = A_arbace_box_A_const_94.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_502 == nil { b__533000059__6 = ifn_503.Invoke_O__O(arg_504) } else { b__533000059__6 = linked_502.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_501, arg_504) }; var tmp2 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(b__533000059__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__519 *jrt.Class = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class; if fncls__519 == nil { var fncls__519d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class = fncls__519d; tmp3 = fncls__519d } else { tmp3 = fncls__519 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_520 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var root_525 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = b__533000059__6; if linked_526 == nil { arg_523 = ifn_527.Invoke_O__O(arg_528) } else { arg_523 = linked_526.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_525, arg_528) }; var arg_524 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); var tmp5 any; var root_529 any = A_arbace_box_A_const_99.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = s__533000057__3; if linked_530 == nil { tmp5 = ifn_531.Invoke_O__O(arg_532) } else { tmp5 = linked_530.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_529, arg_532) }; arg_524 = tmp4.Invoke_O__O(tmp5); if linked_521 == nil { return ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { return linked_521.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) } } else { var root_533 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any; var root_538 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = b__533000059__6; if linked_539 == nil { arg_536 = ifn_540.Invoke_O__O(arg_541) } else { arg_536 = linked_539.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_538, arg_541) }; var arg_537 any; if linked_534 == nil { return ifn_535.Invoke_O_O__O(arg_536, arg_537) } else { return linked_534.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_533, arg_536, arg_537) } } } else { var f__4 any; var root_542 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = s__533000057__3; if linked_543 == nil { f__4 = ifn_544.Invoke_O__O(arg_545) } else { f__4 = linked_543.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_542, arg_545) }; var root_546 any = A_arbace_box_A_const_101.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any; var tmp6 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var tmp7 any

	if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var tmp8 any = A_arbace_box_A_const_64; var tmp9 any; var root_556 any = A_arbace_box_A_const_96.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, A_arbace_box_put_dir_A_fn_class); var ifn_558 lang.IFn
		if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = f__4; if linked_557 == nil { tmp9 = ifn_558.Invoke_O__O(arg_559) } else { tmp9 = linked_557.(*A_arbace_box_put_dir_A).Invoke_O_O__O(root_556, arg_559) }
//line :280:1
		tmp7 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) } else {

			var root_551 any = A_arbace_box_A_const_88.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_box_put_file_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref(); var arg_555 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__4)).CanExecute__Z()).Ref(); if linked_552 == nil { tmp7 = ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { tmp7 = linked_552.(*A_arbace_box_put_file_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) } }
//line :278:1
	arg_549 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_550 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); var tmp11 any; var root_560 any = A_arbace_box_A_const_102.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = s__533000057__3; if linked_561 == nil { tmp11 = ifn_562.Invoke_O__O(arg_563) } else { tmp11 = linked_561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_560, arg_563) }; arg_550 = tmp10.Invoke_O__O(tmp11); if linked_547 == nil { return ifn_548.Invoke_O_O__O(arg_549, arg_550) } else { return linked_547.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_546, arg_549, arg_550) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A { A_arbace_box_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Ctor_O_I_O(c__b__533000059 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000059 = c__b__533000059; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Invoke_O__O(self any) any { { var i__533000058__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__533000058__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__533000058__1)); var root_505 any = A_arbace_box_A_const_95.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = t.F_b__533000059; var arg_509 any; var tmp2 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp3 any

	if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var tmp4 any = A_arbace_box_A_const_64; var tmp5 any; var root_515 any = A_arbace_box_A_const_96.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, A_arbace_box_put_dir_A_fn_class); var ifn_517 lang.IFn
		if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = f__2; if linked_516 == nil { tmp5 = ifn_517.Invoke_O__O(arg_518) } else { tmp5 = linked_516.(*A_arbace_box_put_dir_A).Invoke_O_O__O(root_515, arg_518) }
//line :280:1
		tmp3 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) } else {

			var root_510 any = A_arbace_box_A_const_88.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_box_put_file_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref(); var arg_514 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__2)).CanExecute__Z()).Ref(); if linked_511 == nil { tmp3 = ifn_512.Invoke_O_O__O(arg_513, arg_514) } else { tmp3 = linked_511.(*A_arbace_box_put_file_A).Invoke_O_O_O__O(root_510, arg_513, arg_514) } }
//line :278:1
	arg_509 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_506 == nil { ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { linked_506.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) }; i__533000058__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__533000058__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_box_get_tree_A_New() *A_arbace_box_get_tree_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_box_get_tree_A) Ctor() {}
//line :284:1
func (t *A_arbace_box_get_tree_A) Invoke_O_O_O__O(self, h__0, dir__1 any) any { var m__3 any; var root_572 any = A_arbace_box_A_const_103.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, A_arbace_box_tree_A_fn_class); var ifn_574 lang.IFn; if


	linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = h__0; if linked_573 == nil { m__3 = ifn_574.Invoke_O__O(arg_575) } else { m__3 = linked_573.(*A_arbace_box_tree_A).Invoke_O_O__O(root_572, arg_575) }; var d__4 any; var tmp1 any; var root_576 any = /*line :284:1*/A_arbace_box_A_const_29.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_578 lang.IFn; if



	linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = dir__1; if linked_577 == nil { tmp1 = ifn_578.Invoke_O__O(arg_579) } else { tmp1 = linked_577.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_576, arg_579) }; d__4 = /*line :284:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); if




	lang.Util_Identical_O_O__Z_NoInit(m__3, nil) {
		var root_580 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, A_arbace_box_fail_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = A_arbace_box_A_const_46; var arg_584 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(); var arg_585 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_581 == nil { ifn_582.Invoke_O_O_O__O(arg_583, arg_584, arg_585) } else { linked_581.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_580, arg_583, arg_584, arg_585) } };
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(d__4)).Mkdirs__Z()); var seq_533000067__5 any; var root_586 any = /*line :284:1*/A_arbace_box_A_const_91.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_588 lang.IFn; if







	linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = m__3; if linked_587 == nil { seq_533000067__5 = ifn_588.Invoke_O__O(arg_589) } else { seq_533000067__5 = linked_587.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_586, arg_589) }; var chunk_533000068__6 any; var count_533000069__7 int64 = 0; var i_533000070__8 int64 = 0; L1:
//line :284:1
	for {







		if lang.Numbers_Lt_J_J__Z_NoInit(i_533000070__8, count_533000069__7) { var vec__533000071__9 any = lang.Indexed_Cast(chunk_533000068__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_533000070__8)); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000071__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__533000074__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000071__9, lang.RT_IntCast_J__I_NoInit(1), nil); var kind__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000074__11, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000074__11, lang.RT_IntCast_J__I_NoInit(1), nil); var f__14 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__10))

			if lang.Util_Equiv_O_O__Z_NoInit(kind__12, A_arbace_box_A_const_64) {
				var root_606 any = A_arbace_box_A_const_104.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, A_arbace_box_get_tree_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = eh__13; var arg_610 any = f__14; if linked_607 == nil { ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { linked_607.(*A_arbace_box_get_tree_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) } } else {
//line :294:1
					var o__15 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__14)); var tmp2 any = A_arbace_box_get_tree_fn__533000077_A_New_O_O(o__15, eh__13); var tmp3 *jrt.Class
					var fncls__621 /*line :294:1*/*jrt.Class = A_arbace_box_get_tree_fn__533000077_A_fn_class

					if fncls__621 == nil { var fncls__621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_box_get_tree_fn__533000077_A_fn_class = fncls__621d; tmp3 = fncls__621d } else { tmp3 = fncls__621 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()

					if lang.Util_Equiv_O_O__Z_NoInit(kind__12, A_arbace_box_A_const_79) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__14)).SetExecutable_Z__Z(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())) } }
//line :292:1
			seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = seq_533000067__5, chunk_533000068__6, count_533000069__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_533000070__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_590 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = seq_533000067__5; if linked_591 == nil { temp__1927000414__auto____9 = ifn_592.Invoke_O__O(arg_593) } else { temp__1927000414__auto____9 = linked_591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_590, arg_593) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_533000067__10 any = temp__1927000414__auto____9; var tmp4 any; var root_594 any = A_arbace_box_A_const_92.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = seq_533000067__10; if linked_595 == nil { tmp4 = ifn_596.Invoke_O__O(arg_597) } else { tmp4 = linked_595.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____11 any; var root_598 any = A_arbace_box_A_const_93.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_533000067__10; if linked_599 == nil { c__1927000678__auto____11 = ifn_600.Invoke_O__O(arg_601) } else { c__1927000678__auto____11 = linked_599.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_598, arg_601) }; var tmp5 any; var root_622 any = A_arbace_box_A_const_99.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = seq_533000067__10; if linked_623 == nil { tmp5 = ifn_624.Invoke_O__O(arg_625) } else { tmp5 = linked_623.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_622, arg_625) }; seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = tmp5, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__533000079__11 any; var root_602 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_533000067__10; if linked_603 == nil { vec__533000079__11 = ifn_604.Invoke_O__O(arg_605) } else { vec__533000079__11 = linked_603.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_602, arg_605) }; var n__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000079__11, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__533000082__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000079__11, lang.RT_IntCast_J__I_NoInit(1), nil); var kind__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000082__13, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000082__13, lang.RT_IntCast_J__I_NoInit(1), nil); var f__16 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__12))

				if lang.Util_Equiv_O_O__Z_NoInit(kind__14, A_arbace_box_A_const_64) {
					var root_626 any = A_arbace_box_A_const_104.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, A_arbace_box_get_tree_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = eh__15; var arg_630 any = f__16; if linked_627 == nil { ifn_628.Invoke_O_O__O(arg_629, arg_630) } else { linked_627.(*A_arbace_box_get_tree_A).Invoke_O_O_O__O(root_626, arg_629, arg_630) } } else {
//line :294:1
						var o__17 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__16)); var tmp6 any = A_arbace_box_get_tree_fn__533000085_A_New_O_O(eh__15, o__17); var tmp7 *jrt.Class
						var fncls__641 /*line :294:1*/*jrt.Class = A_arbace_box_get_tree_fn__533000085_A_fn_class

						if fncls__641 == nil { var fncls__641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_box_get_tree_fn__533000085_A_fn_class = fncls__641d; tmp7 = fncls__641d } else { tmp7 = fncls__641 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()

						if lang.Util_Equiv_O_O__Z_NoInit(kind__14, A_arbace_box_A_const_79) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__16)).SetExecutable_Z__Z(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())) } }
//line :292:1
				var tmp8 any; var root_642 any = A_arbace_box_A_const_105.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = seq_533000067__10; if linked_643 == nil { tmp8 = ifn_644.Invoke_O__O(arg_645) } else { tmp8 = linked_643.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_642, arg_645) }; seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = tmp8, nil, 0, 0; continue L1 } } }
//line :284:1
		break L1 }; return nil }











func A_arbace_box_get_tree_fn__533000077_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000077_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_fn__533000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Ctor_O_O(c__o, c__eh any) { t.F_o = c__o; t.F_eh = c__eh }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any; var root_611 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, A_arbace_box_get_bytes_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = t.F_eh; if linked_612 == nil { or__1927000174__auto____3 = ifn_613.Invoke_O__O(arg_614) } else { or__1927000174__auto____3 = linked_612.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_611, arg_614) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var root_615 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, A_arbace_box_fail_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = A_arbace_box_A_const_46; var arg_619 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var arg_620 any; var tmp4 any = A_arbace_box_A_const_27; var tmp5 any; var t_ any = t.F_eh; t.F_eh = nil; tmp5 = t_; arg_620 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)); if linked_616 == nil { tmp3 = ifn_617.Invoke_O_O_O__O(arg_618, arg_619, arg_620) } else { tmp3 = linked_616.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_615, arg_618, arg_619, arg_620) } }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_15, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp7 any; var t__2 any = t.F_o; t.F_o = nil; tmp7 = t__2; jrt.FileOutputStream_Cast(tmp7).Close__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :296:1
func A_arbace_box_get_tree_fn__533000085_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000085_A { A_arbace_box_A_Init(); t := &A_arbace_box_get_tree_fn__533000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Ctor_O_O(c__eh, c__o any) { t.F_eh = c__eh; t.F_o = c__o }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any; var root_631 any = A_arbace_box_A_const_41.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, A_arbace_box_get_bytes_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = t.F_eh; if linked_632 == nil { or__1927000174__auto____3 = ifn_633.Invoke_O__O(arg_634) } else { or__1927000174__auto____3 = linked_632.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(root_631, arg_634) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var root_635 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, A_arbace_box_fail_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = A_arbace_box_A_const_46; var arg_639 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var arg_640 any; var tmp4 any = A_arbace_box_A_const_27; var tmp5 any; var t_ any = t.F_eh; t.F_eh = nil; tmp5 = t_; arg_640 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)); if linked_636 == nil { tmp3 = ifn_637.Invoke_O_O_O__O(arg_638, arg_639, arg_640) } else { tmp3 = linked_636.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_635, arg_638, arg_639, arg_640) } }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_15, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp7 any; var t__2 any = t.F_o; t.F_o = nil; tmp7 = t__2; jrt.FileOutputStream_Cast(tmp7).Close__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }




func A_arbace_box_tree_get_A_New() *A_arbace_box_tree_get_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_get_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_box_tree_get_A) Ctor() {}
//line :301:1
func (t *A_arbace_box_tree_get_A) Invoke_O_O_O__O(self, h__0, p__1 any) any {


	var root_646 any = A_arbace_box_A_const_106.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any; var tmp1 any = A_arbace_box_tree_get_fn__533000088_A_New(); var tmp2 *jrt.Class; var fncls__668 *jrt.Class = A_arbace_box_tree_get_fn__533000088_A_fn_class; if fncls__668 == nil { var fncls__668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_box_tree_get_fn__533000088_A_fn_class = fncls__668d; tmp2 = fncls__668d } else { tmp2 = fncls__668 }; arg_649 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_650 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_A_const_64, h__0); var arg_651 any; var root_669 any = A_arbace_box_A_const_109.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_671 lang.IFn




	if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = A_arbace_box_A_const_110.GetRawRoot__O(); var tmp3 *jrt.Class = A_arbace_box_A_const_59; var arg_673 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__1, tmp3, Lit_67, jrt.RefArrayOf(jrt.Object_class, Lit_9)); if linked_670 == nil { arg_651 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { arg_651 = linked_670.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }
//line :304:1
	if linked_647 == nil { return ifn_648.Invoke_O_O_O__O(arg_649, arg_650, arg_651) } else { return linked_647.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_646, arg_649, arg_650, arg_651) } }
//line :304:1
func A_arbace_box_tree_get_fn__533000088_A_New() *A_arbace_box_tree_get_fn__533000088_A { A_arbace_box_A_Init(); t := &A_arbace_box_tree_get_fn__533000088_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Ctor() {}
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Invoke_O_O_O__O(self, e__1, n__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = e__1; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any = A_arbace_box_A_const_64; var tmp3 any; var root_652 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = e__1; if linked_653 == nil { tmp3 = ifn_654.Invoke_O__O(arg_655) } else { tmp3 = linked_653.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_652, arg_655) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 any; var root_656 any = A_arbace_box_A_const_103.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_box_tree_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any; var root_660 any = A_arbace_box_A_const_107.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = e__1; if linked_661 == nil { arg_659 = ifn_662.Invoke_O__O(arg_663) } else { arg_659 = linked_661.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_660, arg_663) }; if linked_657 == nil { tmp4 = ifn_658.Invoke_O__O(arg_659) } else { tmp4 = linked_657.(*A_arbace_box_tree_A).Invoke_O_O__O(root_656, arg_659) }; return lang.RT_Get_O_O__O_NoInit(tmp4, n__2) } else {
			var root_664 any = A_arbace_box_A_const_108.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any; if linked_665 == nil { return ifn_666.Invoke_O__O(arg_667) } else { return linked_665.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_664, arg_667)
			}
		}
}







func A_arbace_box_request_text_A_New() *A_arbace_box_request_text_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_box_request_text_A) Ctor() {}
//line :318:1
func (t *A_arbace_box_request_text_A) Invoke_O_O__O(self, p__533000091__0 any) any { var map__533000092__2 any = p__533000091__0; var map__533000092__3 any; if lang.ISeq_InstanceOf(map__533000092__2) { var tmp1 any; var root_674 any = A_arbace_box_A_const_105.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = map__533000092__2; if linked_675 == nil { tmp1 = ifn_676.Invoke_O__O(arg_677) } else { tmp1 = linked_675.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_674, arg_677) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_678 any = A_arbace_box_A_const_111.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = map__533000092__2; if linked_679 == nil { tmp2 = ifn_680.Invoke_O__O(arg_681) } else { tmp2 = linked_679.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_678, arg_681) }; map__533000092__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_682 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = map__533000092__2; if linked_683 == nil { tmp3 = ifn_684.Invoke_O__O(arg_685) } else { tmp3 = linked_683.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp3) { var root_686 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = map__533000092__2; if linked_687 == nil { map__533000092__3 = ifn_688.Invoke_O__O(arg_689) } else { map__533000092__3 = linked_687.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_686, arg_689) } } else { map__533000092__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__533000092__3 = map__533000092__2 }; var image__4 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_112); var args__5 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_113); var env__6 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_114); var trees__7 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_115); var out__8 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_116); var cwd__9 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_117); var ram__10 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_118); var cpus__11 any = lang.RT_Get_O_O__O_NoInit(map__533000092__3, A_arbace_box_A_const_119); var v__12 any; var tmp4 any = A_arbace_box_request_text_v__533000094_A_New(); var tmp5 *jrt.Class; var fncls__705 *jrt.Class = A_arbace_box_request_text_v__533000094_A_fn_class; if



	fncls__705 == nil { var fncls__705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_box_request_text_v__533000094_A_fn_class = fncls__705d; tmp5 = fncls__705d } else { tmp5 = fncls__705 }; v__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var root_816 any =
	A_arbace_box_A_const_38.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_box_hash_bytes_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = image__4; var arg_820 any = Lit_38; if linked_817 == nil { ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { linked_817.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) }; var tmp6 /*line :324:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_39, nil, Lit_40, nil, nil, nil, nil, nil, nil, nil, Lit_41); var tmp7 any = lang.IFn_Cast(v__12).Invoke_O__O(args__5); var tmp8 *jrt.String; var tmp9 any; var root_706 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_708 lang.IFn; if
	linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = env__6; if linked_707 == nil { tmp9 = ifn_708.Invoke_O__O(arg_709) } else { tmp9 = linked_707.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_706, arg_709) }; if jrt.J2g_Truth(tmp9) { tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(v__12).Invoke_O__O(env__6))) } else { tmp8 = nil }; var tmp10 any = /*line :324:1*/tmp8.Ref(); var tmp11 *jrt.String; var tmp12 any; var root_710 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_712 lang.IFn; if

	linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = trees__7; if linked_711 == nil { tmp12 = ifn_712.Invoke_O__O(arg_713) } else { tmp12 = linked_711.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_710, arg_713) }; if jrt.J2g_Truth(tmp12) {
		var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp14 any; var root_714 any = A_arbace_box_A_const_75.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_716 lang.IFn
		if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_box_A_const_29.GetRawRoot__O(); var arg_718 any; var root_719 any = A_arbace_box_A_const_76.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = Lit_45; var arg_723 any; var iter__1927001039__auto____27 any; var tmp15 any = A_arbace_box_request_text_iter__533000096__533000100_A_New(); var tmp16 *jrt.Class; var fncls__790 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_A_fn_class; if fncls__790 == nil { var fncls__790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_box_request_text_iter__533000096__533000100_A_fn_class = fncls__790d; tmp16 = fncls__790d } else { tmp16 = fncls__790 }; iter__1927001039__auto____27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); arg_723 = lang.IFn_Cast(iter__1927001039__auto____27).Invoke_O__O(trees__7); if linked_720 == nil { arg_718 = ifn_721.Invoke_O_O__O(arg_722, arg_723) } else { arg_718 = linked_720.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_719, arg_722, arg_723) }; if linked_715 == nil { tmp14 = ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { tmp14 = linked_715.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) }
//line :327:1
		tmp11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14, nil)) } else {
//line :326:1
			tmp11 = nil }; var tmp17 any = /*line :324:1*/tmp11.Ref(); var tmp18 *jrt.String; var tmp19 any; var root_791 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_793 lang.IFn; if





	linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = out__8; if linked_792 == nil { tmp19 = ifn_793.Invoke_O__O(arg_794) } else { tmp19 = linked_792.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_791, arg_794) }; if jrt.J2g_Truth(tmp19) { var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil); var tmp21 any; var root_795 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, A_arbace_box_quote_str_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = out__8; if linked_796 == nil { tmp21 = ifn_797.Invoke_O__O(arg_798) } else { tmp21 = linked_796.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_795, arg_798) }; tmp18 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21)) } else { tmp18 = nil }; var tmp22 any = /*line :324:1*/tmp18.Ref(); var tmp23 *jrt.String; var tmp24 any; var and__1927000168__auto____24 any; var root_799 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_801 lang.IFn; if






	linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = cwd__9; if linked_800 == nil { and__1927000168__auto____24 = ifn_801.Invoke_O__O(arg_802) } else { and__1927000168__auto____24 = linked_800.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_799, arg_802) }; if jrt.J2g_Truth(and__1927000168__auto____24) { var root_803 any = A_arbace_box_A_const_72.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = cwd__9; var arg_807 any = Lit_9; if linked_804 == nil { tmp24 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { tmp24 = linked_804.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_803, arg_806, arg_807) } } else { tmp24 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp24) { var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil); var tmp26 any; var root_808 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, A_arbace_box_quote_str_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = cwd__9; if linked_809 == nil { tmp26 = ifn_810.Invoke_O__O(arg_811) } else { tmp26 = linked_809.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_808, arg_811) }; tmp23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26)) } else { tmp23 = nil }; var tmp27 any = /*line :324:1*/tmp23.Ref(); var tmp28 *jrt.String; var tmp29 any; var and__1927000168__auto____24_2 any = ram__10; if







	jrt.J2g_Truth(and__1927000168__auto____24_2) { var tmp30 bool; var na_812 any = ram__10; if jrt.Long_InstanceOf(na_812) { var n0_813 int64 = jrt.NN(jrt.Long_Cast(na_812)).LongValue__J(); tmp30 = n0_813 > 0 } else { if jrt.Double_InstanceOf(na_812) { var n0_813_2 float64 = jrt.NN(jrt.Double_Cast(na_812)).DoubleValue__D(); tmp30 = n0_813_2 > 0.0 } else { tmp30 = lang.Numbers_IsPos_O__Z_NoInit(na_812) } }; tmp29 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp30).Ref() } else { tmp29 = and__1927000168__auto____24_2 }; if jrt.J2g_Truth(tmp29) { tmp28 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_49, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(ram__10)).Ref())) } else { tmp28 = nil }; var tmp31 any = /*line :324:1*/tmp28.Ref(); var tmp32 *jrt.String; var tmp33 any; var and__1927000168__auto____24_3 any = cpus__11; if








	jrt.J2g_Truth(and__1927000168__auto____24_3) { var tmp34 bool; var na_814 any = cpus__11; if jrt.Long_InstanceOf(na_814) { var n0_815 int64 = jrt.NN(jrt.Long_Cast(na_814)).LongValue__J(); tmp34 = n0_815 > 0 } else { if jrt.Double_InstanceOf(na_814) { var n0_815_2 float64 = jrt.NN(jrt.Double_Cast(na_814)).DoubleValue__D(); tmp34 = n0_815_2 > 0.0 } else { tmp34 = lang.Numbers_IsPos_O__Z_NoInit(na_814) } }; tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp34).Ref() } else { tmp33 = and__1927000168__auto____24_3 }; if jrt.J2g_Truth(tmp33) { tmp32 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_50, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(cpus__11)).Ref())) } else { tmp32 = nil }; return /*line :324:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, image__4, nil, tmp7, tmp10, tmp17, tmp22, tmp27, tmp31, tmp32.Ref(), nil)).Ref() }
//line :322:1
func A_arbace_box_request_text_v__533000094_A_New() *A_arbace_box_request_text_v__533000094_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_v__533000094_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Invoke_O_O__O(self, xs__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_44); var tmp2 any; var root_690 any = A_arbace_box_A_const_75.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = A_arbace_box_A_const_29.GetRawRoot__O(); var arg_694 any; var root_695 any = A_arbace_box_A_const_76.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = Lit_56; var arg_699 any; var root_700 any = A_arbace_box_A_const_77.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_box_A_const_78.GetRawRoot__O(); var arg_704 any = xs__1; if linked_701 == nil { arg_699 = ifn_702.Invoke_O_O__O(arg_703, arg_704) } else { arg_699 = linked_701.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_700, arg_703, arg_704) }; if linked_696 == nil { arg_694 = ifn_697.Invoke_O_O__O(arg_698, arg_699) } else { arg_694 = linked_696.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_695, arg_698, arg_699) }; if linked_691 == nil { tmp2 = ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { tmp2 = linked_691.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }





func A_arbace_box_request_text_iter__533000096__533000100_A_New() *A_arbace_box_request_text_iter__533000096__533000100_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Ctor() {}
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Invoke_O_O__O(self, s__533000097__1 any) any { var tmp1 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(self, s__533000097__1); var tmp2 *jrt.Class; var fncls__789 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class; if fncls__789 == nil { var fncls__789d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class = fncls__789d; tmp2 = fncls__789d } else { tmp2 = fncls__789 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(p0, p1 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A{}; t.Ctor_O_O(p0, p1); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Ctor_O_O(c__iter__533000096, c__s__533000097 any) { t.F_iter__533000096 = c__iter__533000096; t.F_s__533000097 = c__s__533000097 }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Invoke_O__O(self any) any { { var s__533000097__1 any; var t_ any = t.F_s__533000097; t.F_s__533000097 = nil; s__533000097__1 = t_; for { var temp__1927000414__auto____2 any; var root_724 any = A_arbace_box_A_const_91.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = s__533000097__1; if linked_725 == nil { temp__1927000414__auto____2 = ifn_726.Invoke_O__O(arg_727) } else { temp__1927000414__auto____2 = linked_725.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_724, arg_727) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__533000097__3 any = temp__1927000414__auto____2; var tmp1 any; var root_728 any = A_arbace_box_A_const_92.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = s__533000097__3; if linked_729 == nil { tmp1 = ifn_730.Invoke_O__O(arg_731) } else { tmp1 = linked_729.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_728, arg_731) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_732 any = A_arbace_box_A_const_93.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = s__533000097__3; if linked_733 == nil { c__1927001037__auto____4 = ifn_734.Invoke_O__O(arg_735) } else { c__1927001037__auto____4 = linked_733.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_732, arg_735) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__533000099__6 any; var root_736 any = A_arbace_box_A_const_94.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_737 == nil { b__533000099__6 = ifn_738.Invoke_O__O(arg_739) } else { b__533000099__6 = linked_737.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_736, arg_739) }; var tmp2 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(b__533000099__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__749 *jrt.Class = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class; if fncls__749 == nil { var fncls__749d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class = fncls__749d; tmp3 = fncls__749d } else { tmp3 = fncls__749 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_750 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any; var root_755 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = b__533000099__6; if linked_756 == nil { arg_753 = ifn_757.Invoke_O__O(arg_758) } else { arg_753 = linked_756.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_755, arg_758) }; var arg_754 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); var tmp5 any; var root_759 any = A_arbace_box_A_const_99.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = s__533000097__3; if linked_760 == nil { tmp5 = ifn_761.Invoke_O__O(arg_762) } else { tmp5 = linked_760.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_759, arg_762) }; arg_754 = tmp4.Invoke_O__O(tmp5); if linked_751 == nil { return ifn_752.Invoke_O_O__O(arg_753, arg_754) } else { return linked_751.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_750, arg_753, arg_754) } } else { var root_763 any = A_arbace_box_A_const_97.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any; var root_768 any = A_arbace_box_A_const_98.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = b__533000099__6; if linked_769 == nil { arg_766 = ifn_770.Invoke_O__O(arg_771) } else { arg_766 = linked_769.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_768, arg_771) }; var arg_767 any; if linked_764 == nil { return ifn_765.Invoke_O_O__O(arg_766, arg_767) } else { return linked_764.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_763, arg_766, arg_767) } } } else { var vec__533000107__4 any; var root_772 any = A_arbace_box_A_const_100.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = s__533000097__3; if linked_773 == nil { vec__533000107__4 = ifn_774.Invoke_O__O(arg_775) } else { vec__533000107__4 = linked_773.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_772, arg_775) }; var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000107__4, lang.RT_IntCast_J__I_NoInit(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000107__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_776 any = A_arbace_box_A_const_101.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_54, nil, Lit_55); var tmp7 any; var root_781 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, A_arbace_box_quote_str_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = p__5; if linked_782 == nil { tmp7 = ifn_783.Invoke_O__O(arg_784) } else { tmp7 = linked_782.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_781, arg_784) }; arg_779 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, h__6, nil)).Ref(); var arg_780 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); var tmp9 any; var root_785 any = A_arbace_box_A_const_102.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = s__533000097__3; if linked_786 == nil { tmp9 = ifn_787.Invoke_O__O(arg_788) } else { tmp9 = linked_786.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_785, arg_788) }; arg_780 = tmp8.Invoke_O__O(tmp9); if linked_777 == nil { return ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { return linked_777.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A { A_arbace_box_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Ctor_O_I_O(c__b__533000099 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000099 = c__b__533000099; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Invoke_O__O(self any) any { { var i__533000098__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__533000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__533000103__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__533000098__1)); var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000103__2, lang.RT_IntCast_J__I_NoInit(0), nil); var h__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__533000103__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_740 any = A_arbace_box_A_const_95.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = t.F_b__533000099; var arg_744 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_54, nil, Lit_55); var tmp3 any; var root_745 any = A_arbace_box_A_const_78.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, A_arbace_box_quote_str_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = p__3; if linked_746 == nil { tmp3 = ifn_747.Invoke_O__O(arg_748) } else { tmp3 = linked_746.(*A_arbace_box_quote_str_A).Invoke_O_O__O(root_745, arg_748) }; arg_744 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, h__4, nil)).Ref(); if linked_741 == nil { ifn_742.Invoke_O_O__O(arg_743, arg_744) } else { linked_741.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_740, arg_743, arg_744) }; i__533000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__533000098__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_box_spawn_A_New() *A_arbace_box_spawn_A { A_arbace_box_A_Init(); t := &A_arbace_box_spawn_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_box_spawn_A) Ctor() {}
//line :336:1
func (t *A_arbace_box_spawn_A) Invoke_O_O__O(self, req__0 any) any { var h__2 any; var tmp1 any; var root_821 any = A_arbace_box_A_const_120.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_823 lang.IFn; if




	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = req__0; if linked_822 == nil { tmp1 = ifn_823.Invoke_O__O(arg_824) } else { tmp1 = linked_822.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_821, arg_824) }; if jrt.J2g_Truth(tmp1) { var root_825 any = A_arbace_box_A_const_49.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, A_arbace_box_put_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any; var root_829 any = A_arbace_box_A_const_121.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_box_request_text_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = req__0; if linked_830 == nil { arg_828 = ifn_831.Invoke_O__O(arg_832) } else { arg_828 = linked_830.(*A_arbace_box_request_text_A).Invoke_O_O__O(root_829, arg_832) }; if linked_826 == nil { h__2 = ifn_827.Invoke_O__O(arg_828) } else { h__2 = linked_826.(*A_arbace_box_put_A).Invoke_O_O__O(root_825, arg_828) } } else { h__2 = req__0 }; var n__3 any; var root_833 any = /*line :336:1*/A_arbace_box_A_const_122.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_833, aot_arbace_box_host.A_arbace_box_host_spawn_A_fn_class); var ifn_835 lang.IFn; if





	linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any; var root_837 any = A_arbace_box_A_const_38.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, A_arbace_box_hash_bytes_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = h__2; var arg_841 any = Lit_62; if linked_838 == nil { arg_836 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { arg_836 = linked_838.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) }; if linked_834 == nil { n__3 = ifn_835.Invoke_O__O(arg_836) } else { n__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_834.(*aot_arbace_box_host.A_arbace_box_host_spawn_A).InvokePrim_O_O__J(root_833, arg_836)).Ref() }; var tmp2 bool; var na_842 any = n__3; if
	jrt.Long_InstanceOf(na_842) { var n0_843 int64 = jrt.NN(jrt.Long_Cast(na_842)).LongValue__J(); tmp2 = n0_843 < 0 } else { if jrt.Double_InstanceOf(na_842) { var n0_843_2 float64 = jrt.NN(jrt.Double_Cast(na_842)).DoubleValue__D(); tmp2 = n0_843_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_842) } }; if tmp2 {
		var root_844 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_box_fail_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = A_arbace_box_A_const_21; var arg_848 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(); var arg_849 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_123, h__2)); if linked_845 == nil { ifn_846.Invoke_O_O_O__O(arg_847, arg_848, arg_849) } else { linked_845.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_844, arg_847, arg_848, arg_849) } }; return n__3 }


func A_arbace_box_result_A_New() *A_arbace_box_result_A { A_arbace_box_A_Init(); t := &A_arbace_box_result_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_box_result_A) Ctor() {}
//line :347:1
func (t *A_arbace_box_result_A) Invoke_O_O__O(self, h__0 any) any { var s__2 any; var root_850 any = A_arbace_box_A_const_52.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, A_arbace_box_get_A_fn_class); var ifn_852 lang.IFn; if


	linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = h__0; if linked_851 == nil { s__2 = ifn_852.Invoke_O__O(arg_853) } else { s__2 = linked_851.(*A_arbace_box_get_A).Invoke_O_O__O(root_850, arg_853) }; if
	lang.Util_Identical_O_O__Z_NoInit(s__2, nil) {
		var root_864 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_box_fail_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = A_arbace_box_A_const_46; var arg_868 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(); var arg_869 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_27, h__0)); if linked_865 == nil { ifn_866.Invoke_O_O_O__O(arg_867, arg_868, arg_869) } else { linked_865.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_864, arg_867, arg_868, arg_869) } }; var root_854 any =
	A_arbace_box_A_const_13.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any; var root_860 any = A_arbace_box_A_const_87.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = s__2; if linked_861 == nil { arg_857 = ifn_862.Invoke_O__O(arg_863) } else { arg_857 = linked_861.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_860, arg_863) }; var arg_858 any = A_arbace_box_A_const_27; var arg_859 any = h__0; if linked_855 == nil { return ifn_856.Invoke_O_O_O__O(arg_857, arg_858, arg_859) } else { return linked_855.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_854, arg_857, arg_858, arg_859) } }

func A_arbace_box_spawn_wait_A_New() *A_arbace_box_spawn_wait_A { A_arbace_box_A_Init(); t := &A_arbace_box_spawn_wait_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Ctor() {}
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Invoke_O_O__O(self, n__0 any) any { var h__2 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_A_const_22).Ref(); var tmp1 int64; var root_878 any = A_arbace_box_A_const_125.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_878, aot_arbace_box_host.A_arbace_box_host_spawn_await_A_fn_class); var ifn_880 lang.IFn; if



	linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = n__0; var arg_882 any = h__2; if linked_879 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_880.Invoke_O_O__O(arg_881, arg_882)) } else { tmp1 = linked_879.(*aot_arbace_box_host.A_arbace_box_host_spawn_await_A).InvokePrim_O_J_O__J(root_878, lang.RT_LongCast_O__J_NoInit(arg_881), arg_882) }; if lang.Numbers_IsZero_J__Z_NoInit(tmp1) { } else {
		var root_883 any = A_arbace_box_A_const_15.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, A_arbace_box_fail_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = A_arbace_box_A_const_21; var arg_887 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_64, nil, Lit_65), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var arg_888 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_A_const_126, n__0)); if linked_884 == nil { ifn_885.Invoke_O_O_O__O(arg_886, arg_887, arg_888) } else { linked_884.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(root_883, arg_886, arg_887, arg_888) } }; var root_870 any =
	A_arbace_box_A_const_124.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, A_arbace_box_result_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var root_874 any = A_arbace_box_A_const_35.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, A_arbace_box_hex_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = h__2; if linked_875 == nil { arg_873 = ifn_876.Invoke_O__O(arg_877) } else { arg_873 = linked_875.(*A_arbace_box_hex_A).Invoke_O_O__O(root_874, arg_877) }; if linked_871 == nil { return ifn_872.Invoke_O__O(arg_873) } else { return linked_871.(*A_arbace_box_result_A).Invoke_O_O__O(root_870, arg_873) } }

func A_arbace_box_run_A_New() *A_arbace_box_run_A { A_arbace_box_A_Init(); t := &A_arbace_box_run_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_box_run_A) Ctor() {}
//line :363:1
func (t *A_arbace_box_run_A) Invoke_O_O__O(self, req__0 any) any {


	var root_889 any = A_arbace_box_A_const_127.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, A_arbace_box_spawn_wait_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var root_893 any = A_arbace_box_A_const_128.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, A_arbace_box_spawn_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = req__0; if linked_894 == nil { arg_892 = ifn_895.Invoke_O__O(arg_896) } else { arg_892 = linked_894.(*A_arbace_box_spawn_A).Invoke_O_O__O(root_893, arg_896) }; if linked_890 == nil { return ifn_891.Invoke_O__O(arg_892) } else { return linked_890.(*A_arbace_box_spawn_wait_A).Invoke_O_O__O(root_889, arg_892)
	}
}













type A_arbace_box_A struct{ jrt.Object }

var A_arbace_box_A_const_pool *jrt.RefArray

var A_arbace_box_A_const_0 *lang.Var

var A_arbace_box_A_const_1 any

var A_arbace_box_A_const_2 *lang.Keyword

var A_arbace_box_A_const_3 any

var A_arbace_box_A_const_4 *lang.Var

var A_arbace_box_A_const_5 any

var A_arbace_box_A_const_6 any

var A_arbace_box_A_const_7 *lang.Var

var A_arbace_box_A_const_8 *lang.Var

var A_arbace_box_A_const_9 *lang.Var

var A_arbace_box_A_const_10 *lang.Var

var A_arbace_box_A_const_11 any

var A_arbace_box_A_const_12 *lang.Var

var A_arbace_box_A_const_13 *lang.Var

var A_arbace_box_A_const_14 *lang.Keyword

var A_arbace_box_A_const_15 *lang.Var

var A_arbace_box_A_const_16 *lang.Keyword

var A_arbace_box_A_const_17 *lang.Var

var A_arbace_box_A_const_18 *lang.Keyword

var A_arbace_box_A_const_19 *lang.Keyword

var A_arbace_box_A_const_20 *lang.Keyword

var A_arbace_box_A_const_21 *lang.Keyword

var A_arbace_box_A_const_22 any

var A_arbace_box_A_const_23 *lang.Var

var A_arbace_box_A_const_24 *lang.Var

var A_arbace_box_A_const_25 any

var A_arbace_box_A_const_26 *lang.Keyword

var A_arbace_box_A_const_27 *lang.Keyword

var A_arbace_box_A_const_28 *lang.Var

var A_arbace_box_A_const_29 *lang.Var

var A_arbace_box_A_const_30 *lang.Var

var A_arbace_box_A_const_31 *lang.Var

var A_arbace_box_A_const_32 *lang.Keyword

var A_arbace_box_A_const_33 *lang.Var

var A_arbace_box_A_const_34 *lang.Var

var A_arbace_box_A_const_35 *lang.Var

var A_arbace_box_A_const_36 *lang.Var

var A_arbace_box_A_const_37 *lang.Keyword

var A_arbace_box_A_const_38 *lang.Var

var A_arbace_box_A_const_39 *lang.Var

var A_arbace_box_A_const_40 *lang.Var

var A_arbace_box_A_const_41 *lang.Var

var A_arbace_box_A_const_42 *lang.Var

var A_arbace_box_A_const_43 any

var A_arbace_box_A_const_44 any

var A_arbace_box_A_const_45 *lang.Var

var A_arbace_box_A_const_46 *lang.Keyword

var A_arbace_box_A_const_47 *lang.Var

var A_arbace_box_A_const_48 *lang.Var

var A_arbace_box_A_const_49 *lang.Var

var A_arbace_box_A_const_50 *lang.Var

var A_arbace_box_A_const_51 *lang.Var

var A_arbace_box_A_const_52 *lang.Var

var A_arbace_box_A_const_53 *lang.Var

var A_arbace_box_A_const_54 *lang.Keyword

var A_arbace_box_A_const_55 *lang.Var

var A_arbace_box_A_const_56 *lang.Var

var A_arbace_box_A_const_57 *lang.Var

var A_arbace_box_A_const_58 *lang.Var

var A_arbace_box_A_const_59 *jrt.Class

var A_arbace_box_A_const_60 any

var A_arbace_box_A_const_61 *lang.Var

var A_arbace_box_A_const_62 *lang.Var

var A_arbace_box_A_const_63 *jrt.Class

var A_arbace_box_A_const_64 *lang.Keyword

var A_arbace_box_A_const_65 *lang.Var

var A_arbace_box_A_const_66 *lang.Var

var A_arbace_box_A_const_67 *lang.Var

var A_arbace_box_A_const_68 *lang.Var

var A_arbace_box_A_const_69 *lang.Var

var A_arbace_box_A_const_70 any

var A_arbace_box_A_const_71 *lang.Var

var A_arbace_box_A_const_72 *lang.Var

var A_arbace_box_A_const_73 any

var A_arbace_box_A_const_74 any

var A_arbace_box_A_const_75 *lang.Var

var A_arbace_box_A_const_76 *lang.Var

var A_arbace_box_A_const_77 *lang.Var

var A_arbace_box_A_const_78 *lang.Var

var A_arbace_box_A_const_79 *lang.Keyword

var A_arbace_box_A_const_80 *lang.Keyword

var A_arbace_box_A_const_81 *lang.Keyword

var A_arbace_box_A_const_82 *lang.Var

var A_arbace_box_A_const_83 *lang.Var

var A_arbace_box_A_const_84 *lang.Var

var A_arbace_box_A_const_85 *lang.Var

var A_arbace_box_A_const_86 *lang.Var

var A_arbace_box_A_const_87 *lang.Var

var A_arbace_box_A_const_88 *lang.Var

var A_arbace_box_A_const_89 *lang.Var

var A_arbace_box_A_const_90 *lang.Var

var A_arbace_box_A_const_91 *lang.Var

var A_arbace_box_A_const_92 *lang.Var

var A_arbace_box_A_const_93 *lang.Var

var A_arbace_box_A_const_94 *lang.Var

var A_arbace_box_A_const_95 *lang.Var

var A_arbace_box_A_const_96 *lang.Var

var A_arbace_box_A_const_97 *lang.Var

var A_arbace_box_A_const_98 *lang.Var

var A_arbace_box_A_const_99 *lang.Var

var A_arbace_box_A_const_100 *lang.Var

var A_arbace_box_A_const_101 *lang.Var

var A_arbace_box_A_const_102 *lang.Var

var A_arbace_box_A_const_103 *lang.Var

var A_arbace_box_A_const_104 *lang.Var

var A_arbace_box_A_const_105 *lang.Var

var A_arbace_box_A_const_106 *lang.Var

var A_arbace_box_A_const_107 *lang.Var

var A_arbace_box_A_const_108 *lang.Var

var A_arbace_box_A_const_109 *lang.Var

var A_arbace_box_A_const_110 *lang.Var

var A_arbace_box_A_const_111 *lang.Var

var A_arbace_box_A_const_112 *lang.Keyword

var A_arbace_box_A_const_113 *lang.Keyword

var A_arbace_box_A_const_114 *lang.Keyword

var A_arbace_box_A_const_115 *lang.Keyword

var A_arbace_box_A_const_116 *lang.Keyword

var A_arbace_box_A_const_117 *lang.Keyword

var A_arbace_box_A_const_118 *lang.Keyword

var A_arbace_box_A_const_119 *lang.Keyword

var A_arbace_box_A_const_120 *lang.Var

var A_arbace_box_A_const_121 *lang.Var

var A_arbace_box_A_const_122 *lang.Var

var A_arbace_box_A_const_123 *lang.Keyword

var A_arbace_box_A_const_124 *lang.Var

var A_arbace_box_A_const_125 *lang.Var

var A_arbace_box_A_const_126 *lang.Keyword

var A_arbace_box_A_const_127 *lang.Var

var A_arbace_box_A_const_128 *lang.Var

var A_arbace_box_A_init jrt.ClassInit

func A_arbace_box_A_Init() { if !A_arbace_box_A_init.Done() { A_arbace_box_A_init.Run(A_arbace_box_A_clinit) } }

func A_arbace_box_A_clinit() { A_arbace_box_A_clinit_p0(); A_arbace_box_A_clinit_p1(); A_arbace_box_A_clinit_p2(); A_arbace_box_A_clinit_p3(); A_arbace_box_A_clinit_p4(); A_arbace_box_A_clinit_p5(); A_arbace_box_A_clinit_p6(); A_arbace_box_A_clinit_p7(); A_arbace_box_A_clinit_p8(); A_arbace_box_A_clinit_p9(); A_arbace_box_A_clinit_p10() }

func A_arbace_box_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 166); A_arbace_box_A_const_0 = lang.Var_Cast(A_arbace_box_A_const_pool.A[37]); A_arbace_box_A_const_1 = A_arbace_box_A_const_pool.A[38]; A_arbace_box_A_const_2 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[39]); A_arbace_box_A_const_3 = A_arbace_box_A_const_pool.A[40]; A_arbace_box_A_const_4 = lang.Var_Cast(A_arbace_box_A_const_pool.A[41]); A_arbace_box_A_const_5 = A_arbace_box_A_const_pool.A[42]; A_arbace_box_A_const_6 = A_arbace_box_A_const_pool.A[43]; A_arbace_box_A_const_7 = lang.Var_Cast(A_arbace_box_A_const_pool.A[44]); A_arbace_box_A_const_8 = lang.Var_Cast(A_arbace_box_A_const_pool.A[45]); A_arbace_box_A_const_9 = lang.Var_Cast(A_arbace_box_A_const_pool.A[46]); A_arbace_box_A_const_10 = lang.Var_Cast(A_arbace_box_A_const_pool.A[47]); A_arbace_box_A_const_11 = A_arbace_box_A_const_pool.A[48] }

func A_arbace_box_A_clinit_p1() { A_arbace_box_A_const_12 = lang.Var_Cast(A_arbace_box_A_const_pool.A[49]); A_arbace_box_A_const_13 = lang.Var_Cast(A_arbace_box_A_const_pool.A[50]); A_arbace_box_A_const_14 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[51]); A_arbace_box_A_const_15 = lang.Var_Cast(A_arbace_box_A_const_pool.A[52]); A_arbace_box_A_const_16 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[53]); A_arbace_box_A_const_17 = lang.Var_Cast(A_arbace_box_A_const_pool.A[54]); A_arbace_box_A_const_18 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[55]); A_arbace_box_A_const_19 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[56]); A_arbace_box_A_const_20 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[57]); A_arbace_box_A_const_21 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[58]); A_arbace_box_A_const_22 = A_arbace_box_A_const_pool.A[59]; A_arbace_box_A_const_23 = lang.Var_Cast(A_arbace_box_A_const_pool.A[60]) }

func A_arbace_box_A_clinit_p2() { A_arbace_box_A_const_24 = lang.Var_Cast(A_arbace_box_A_const_pool.A[61]); A_arbace_box_A_const_25 = A_arbace_box_A_const_pool.A[62]; A_arbace_box_A_const_26 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[63]); A_arbace_box_A_const_27 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[64]); A_arbace_box_A_const_28 = lang.Var_Cast(A_arbace_box_A_const_pool.A[65]); A_arbace_box_A_const_29 = lang.Var_Cast(A_arbace_box_A_const_pool.A[66]); A_arbace_box_A_const_30 = lang.Var_Cast(A_arbace_box_A_const_pool.A[67]); A_arbace_box_A_const_31 = lang.Var_Cast(A_arbace_box_A_const_pool.A[68]); A_arbace_box_A_const_32 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[69]); A_arbace_box_A_const_33 = lang.Var_Cast(A_arbace_box_A_const_pool.A[70]); A_arbace_box_A_const_34 = lang.Var_Cast(A_arbace_box_A_const_pool.A[71]); A_arbace_box_A_const_35 = lang.Var_Cast(A_arbace_box_A_const_pool.A[72]) }

func A_arbace_box_A_clinit_p3() { A_arbace_box_A_const_36 = lang.Var_Cast(A_arbace_box_A_const_pool.A[73]); A_arbace_box_A_const_37 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[74]); A_arbace_box_A_const_38 = lang.Var_Cast(A_arbace_box_A_const_pool.A[75]); A_arbace_box_A_const_39 = lang.Var_Cast(A_arbace_box_A_const_pool.A[76]); A_arbace_box_A_const_40 = lang.Var_Cast(A_arbace_box_A_const_pool.A[77]); A_arbace_box_A_const_41 = lang.Var_Cast(A_arbace_box_A_const_pool.A[78]); A_arbace_box_A_const_42 = lang.Var_Cast(A_arbace_box_A_const_pool.A[79]); A_arbace_box_A_const_43 = A_arbace_box_A_const_pool.A[80]; A_arbace_box_A_const_44 = A_arbace_box_A_const_pool.A[81]; A_arbace_box_A_const_45 = lang.Var_Cast(A_arbace_box_A_const_pool.A[82]); A_arbace_box_A_const_46 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[83]); A_arbace_box_A_const_47 = lang.Var_Cast(A_arbace_box_A_const_pool.A[84]) }

func A_arbace_box_A_clinit_p4() { A_arbace_box_A_const_48 = lang.Var_Cast(A_arbace_box_A_const_pool.A[85]); A_arbace_box_A_const_49 = lang.Var_Cast(A_arbace_box_A_const_pool.A[86]); A_arbace_box_A_const_50 = lang.Var_Cast(A_arbace_box_A_const_pool.A[87]); A_arbace_box_A_const_51 = lang.Var_Cast(A_arbace_box_A_const_pool.A[88]); A_arbace_box_A_const_52 = lang.Var_Cast(A_arbace_box_A_const_pool.A[89]); A_arbace_box_A_const_53 = lang.Var_Cast(A_arbace_box_A_const_pool.A[90]); A_arbace_box_A_const_54 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[91]); A_arbace_box_A_const_55 = lang.Var_Cast(A_arbace_box_A_const_pool.A[92]); A_arbace_box_A_const_56 = lang.Var_Cast(A_arbace_box_A_const_pool.A[93]); A_arbace_box_A_const_57 = lang.Var_Cast(A_arbace_box_A_const_pool.A[94]); A_arbace_box_A_const_58 = lang.Var_Cast(A_arbace_box_A_const_pool.A[95]); A_arbace_box_A_const_59 = jrt.Class_Cast(A_arbace_box_A_const_pool.A[96]) }

func A_arbace_box_A_clinit_p5() { A_arbace_box_A_const_60 = A_arbace_box_A_const_pool.A[97]; A_arbace_box_A_const_61 = lang.Var_Cast(A_arbace_box_A_const_pool.A[98]); A_arbace_box_A_const_62 = lang.Var_Cast(A_arbace_box_A_const_pool.A[99]); A_arbace_box_A_const_63 = jrt.Class_Cast(A_arbace_box_A_const_pool.A[100]); A_arbace_box_A_const_64 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[101]); A_arbace_box_A_const_65 = lang.Var_Cast(A_arbace_box_A_const_pool.A[102]); A_arbace_box_A_const_66 = lang.Var_Cast(A_arbace_box_A_const_pool.A[103]); A_arbace_box_A_const_67 = lang.Var_Cast(A_arbace_box_A_const_pool.A[104]); A_arbace_box_A_const_68 = lang.Var_Cast(A_arbace_box_A_const_pool.A[105]); A_arbace_box_A_const_69 = lang.Var_Cast(A_arbace_box_A_const_pool.A[106]); A_arbace_box_A_const_70 = A_arbace_box_A_const_pool.A[107]; A_arbace_box_A_const_71 = lang.Var_Cast(A_arbace_box_A_const_pool.A[108]) }

func A_arbace_box_A_clinit_p6() { A_arbace_box_A_const_72 = lang.Var_Cast(A_arbace_box_A_const_pool.A[109]); A_arbace_box_A_const_73 = A_arbace_box_A_const_pool.A[110]; A_arbace_box_A_const_74 = A_arbace_box_A_const_pool.A[111]; A_arbace_box_A_const_75 = lang.Var_Cast(A_arbace_box_A_const_pool.A[112]); A_arbace_box_A_const_76 = lang.Var_Cast(A_arbace_box_A_const_pool.A[113]); A_arbace_box_A_const_77 = lang.Var_Cast(A_arbace_box_A_const_pool.A[114]); A_arbace_box_A_const_78 = lang.Var_Cast(A_arbace_box_A_const_pool.A[115]); A_arbace_box_A_const_79 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[116]); A_arbace_box_A_const_80 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[117]); A_arbace_box_A_const_81 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[118]); A_arbace_box_A_const_82 = lang.Var_Cast(A_arbace_box_A_const_pool.A[119]); A_arbace_box_A_const_83 = lang.Var_Cast(A_arbace_box_A_const_pool.A[120]) }

func A_arbace_box_A_clinit_p7() { A_arbace_box_A_const_84 = lang.Var_Cast(A_arbace_box_A_const_pool.A[121]); A_arbace_box_A_const_85 = lang.Var_Cast(A_arbace_box_A_const_pool.A[122]); A_arbace_box_A_const_86 = lang.Var_Cast(A_arbace_box_A_const_pool.A[123]); A_arbace_box_A_const_87 = lang.Var_Cast(A_arbace_box_A_const_pool.A[124]); A_arbace_box_A_const_88 = lang.Var_Cast(A_arbace_box_A_const_pool.A[125]); A_arbace_box_A_const_89 = lang.Var_Cast(A_arbace_box_A_const_pool.A[126]); A_arbace_box_A_const_90 = lang.Var_Cast(A_arbace_box_A_const_pool.A[127]); A_arbace_box_A_const_91 = lang.Var_Cast(A_arbace_box_A_const_pool.A[128]); A_arbace_box_A_const_92 = lang.Var_Cast(A_arbace_box_A_const_pool.A[129]); A_arbace_box_A_const_93 = lang.Var_Cast(A_arbace_box_A_const_pool.A[130]); A_arbace_box_A_const_94 = lang.Var_Cast(A_arbace_box_A_const_pool.A[131]); A_arbace_box_A_const_95 = lang.Var_Cast(A_arbace_box_A_const_pool.A[132]) }

func A_arbace_box_A_clinit_p8() { A_arbace_box_A_const_96 = lang.Var_Cast(A_arbace_box_A_const_pool.A[133]); A_arbace_box_A_const_97 = lang.Var_Cast(A_arbace_box_A_const_pool.A[134]); A_arbace_box_A_const_98 = lang.Var_Cast(A_arbace_box_A_const_pool.A[135]); A_arbace_box_A_const_99 = lang.Var_Cast(A_arbace_box_A_const_pool.A[136]); A_arbace_box_A_const_100 = lang.Var_Cast(A_arbace_box_A_const_pool.A[137]); A_arbace_box_A_const_101 = lang.Var_Cast(A_arbace_box_A_const_pool.A[138]); A_arbace_box_A_const_102 = lang.Var_Cast(A_arbace_box_A_const_pool.A[139]); A_arbace_box_A_const_103 = lang.Var_Cast(A_arbace_box_A_const_pool.A[140]); A_arbace_box_A_const_104 = lang.Var_Cast(A_arbace_box_A_const_pool.A[141]); A_arbace_box_A_const_105 = lang.Var_Cast(A_arbace_box_A_const_pool.A[142]); A_arbace_box_A_const_106 = lang.Var_Cast(A_arbace_box_A_const_pool.A[143]); A_arbace_box_A_const_107 = lang.Var_Cast(A_arbace_box_A_const_pool.A[144]) }

func A_arbace_box_A_clinit_p9() { A_arbace_box_A_const_108 = lang.Var_Cast(A_arbace_box_A_const_pool.A[145]); A_arbace_box_A_const_109 = lang.Var_Cast(A_arbace_box_A_const_pool.A[146]); A_arbace_box_A_const_110 = lang.Var_Cast(A_arbace_box_A_const_pool.A[147]); A_arbace_box_A_const_111 = lang.Var_Cast(A_arbace_box_A_const_pool.A[148]); A_arbace_box_A_const_112 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[149]); A_arbace_box_A_const_113 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[150]); A_arbace_box_A_const_114 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[151]); A_arbace_box_A_const_115 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[152]); A_arbace_box_A_const_116 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[153]); A_arbace_box_A_const_117 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[154]); A_arbace_box_A_const_118 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[155]); A_arbace_box_A_const_119 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[156]) }

func A_arbace_box_A_clinit_p10() { A_arbace_box_A_const_120 = lang.Var_Cast(A_arbace_box_A_const_pool.A[157]); A_arbace_box_A_const_121 = lang.Var_Cast(A_arbace_box_A_const_pool.A[158]); A_arbace_box_A_const_122 = lang.Var_Cast(A_arbace_box_A_const_pool.A[159]); A_arbace_box_A_const_123 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[160]); A_arbace_box_A_const_124 = lang.Var_Cast(A_arbace_box_A_const_pool.A[161]); A_arbace_box_A_const_125 = lang.Var_Cast(A_arbace_box_A_const_pool.A[162]); A_arbace_box_A_const_126 = lang.Keyword_Cast(A_arbace_box_A_const_pool.A[163]); A_arbace_box_A_const_127 = lang.Var_Cast(A_arbace_box_A_const_pool.A[164]); A_arbace_box_A_const_128 = lang.Var_Cast(A_arbace_box_A_const_pool.A[165]) }

func A_arbace_box_A_New() *A_arbace_box_A { A_arbace_box_A_Init(); t := &A_arbace_box_A{}; t.Ctor(); return t }

func (t *A_arbace_box_A) Ctor() {}

func (t *A_arbace_box_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_A) GetClass__Class() *jrt.Class { return A_arbace_box_A_class }

func (t *A_arbace_box_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_A); return ok }

func A_arbace_box_A_Cast(x any) *A_arbace_box_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_A_class)) }; return v }



type A_arbace_box_answer_A struct{ j2g_header uint64 }

var A_arbace_box_answer_A_fn_class *jrt.Class



type A_arbace_box_boxed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_boxed_QMARK__A_fn_class *jrt.Class



type A_arbace_box_eval533000004_A struct{ jrt.Object }

func A_arbace_box_eval533000004_A_New() *A_arbace_box_eval533000004_A { t := &A_arbace_box_eval533000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000004_A) Ctor() {}

func (t *A_arbace_box_eval533000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000004_A_class }

func (t *A_arbace_box_eval533000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000004_A); return ok }

func A_arbace_box_eval533000004_A_Cast(x any) *A_arbace_box_eval533000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000004_A_class)) }; return v }



type A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A struct{ j2g_header uint64 }

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_fn_class *jrt.Class



type A_arbace_box_eval533000008_A struct{ jrt.Object }

func A_arbace_box_eval533000008_A_New() *A_arbace_box_eval533000008_A { t := &A_arbace_box_eval533000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000008_A) Ctor() {}

func (t *A_arbace_box_eval533000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000008_A_class }

func (t *A_arbace_box_eval533000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000008_A); return ok }

func A_arbace_box_eval533000008_A_Cast(x any) *A_arbace_box_eval533000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000008_A_class)) }; return v }



type A_arbace_box_eval533000008_fn__533000009_A struct{ j2g_header uint64 }

var A_arbace_box_eval533000008_fn__533000009_A_fn_class *jrt.Class



type A_arbace_box_fail_A struct{ j2g_header uint64 }

var A_arbace_box_fail_A_fn_class *jrt.Class



type A_arbace_box_fs_dir_A struct{ j2g_header uint64 }

var A_arbace_box_fs_dir_A_fn_class *jrt.Class



type A_arbace_box_get_A struct{ j2g_header uint64 }

var A_arbace_box_get_A_fn_class *jrt.Class



type A_arbace_box_get_bytes_A struct{ j2g_header uint64 }

var A_arbace_box_get_bytes_A_fn_class *jrt.Class



type A_arbace_box_get_tree_A struct{ j2g_header uint64 }

var A_arbace_box_get_tree_A_fn_class *jrt.Class



type A_arbace_box_get_tree_fn__533000077_A struct{ j2g_header uint64; F_o, F_eh any }

var A_arbace_box_get_tree_fn__533000077_A_fn_class *jrt.Class



type A_arbace_box_get_tree_fn__533000085_A struct{ j2g_header uint64; F_eh, F_o any }

var A_arbace_box_get_tree_fn__533000085_A_fn_class *jrt.Class



type A_arbace_box_hash_bytes_A struct{ j2g_header uint64 }

var A_arbace_box_hash_bytes_A_fn_class *jrt.Class



type A_arbace_box_hex_A struct{ j2g_header uint64 }

var A_arbace_box_hex_A_fn_class *jrt.Class



type A_arbace_box_load_A struct{ j2g_header uint64 }

var A_arbace_box_load_A_fn_class *jrt.Class



type A_arbace_box_load_fs_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_load_fs_BANG__A_fn_class *jrt.Class



type A_arbace_box_load_ref_A struct{ j2g_header uint64 }

var A_arbace_box_load_ref_A_fn_class *jrt.Class



type A_arbace_box_put_A struct{ j2g_header uint64 }

var A_arbace_box_put_A_fn_class *jrt.Class



type A_arbace_box_put_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_put_BANG__A_fn_class *jrt.Class



type A_arbace_box_put_dir_A struct{ j2g_header uint64 }

var A_arbace_box_put_dir_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_A struct{ j2g_header uint64 }

var A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A struct{ j2g_header uint64; F_s__533000057, F_iter__533000056 any }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class *jrt.Class



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A struct{ j2g_header uint64; F_b__533000059 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class *jrt.Class



type A_arbace_box_put_file_A struct{ j2g_header uint64 }

var A_arbace_box_put_file_A_fn_class *jrt.Class



type A_arbace_box_put_tree_A struct{ j2g_header uint64 }

var A_arbace_box_put_tree_A_fn_class *jrt.Class



type A_arbace_box_quote_str_A struct{ j2g_header uint64 }

var A_arbace_box_quote_str_A_fn_class *jrt.Class



type A_arbace_box_ref_A struct{ j2g_header uint64 }

var A_arbace_box_ref_A_fn_class *jrt.Class



type A_arbace_box_ref_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_ref_BANG__A_fn_class *jrt.Class



type A_arbace_box_ref_BANG__answer_A struct{ j2g_header uint64 }

var A_arbace_box_ref_BANG__answer_A_fn_class *jrt.Class



type A_arbace_box_request_text_A struct{ j2g_header uint64 }

var A_arbace_box_request_text_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_A struct{ j2g_header uint64 }

var A_arbace_box_request_text_iter__533000096__533000100_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A struct{ j2g_header uint64; F_iter__533000096, F_s__533000097 any }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class *jrt.Class



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A struct{ j2g_header uint64; F_b__533000099 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class *jrt.Class



type A_arbace_box_request_text_v__533000094_A struct{ j2g_header uint64 }

var A_arbace_box_request_text_v__533000094_A_fn_class *jrt.Class



type A_arbace_box_result_A struct{ j2g_header uint64 }

var A_arbace_box_result_A_fn_class *jrt.Class



type A_arbace_box_run_A struct{ j2g_header uint64 }

var A_arbace_box_run_A_fn_class *jrt.Class



type A_arbace_box_save_fs_BANG__A struct{ j2g_header uint64 }

var A_arbace_box_save_fs_BANG__A_fn_class *jrt.Class



type A_arbace_box_size_A struct{ j2g_header uint64 }

var A_arbace_box_size_A_fn_class *jrt.Class



type A_arbace_box_spawn_A struct{ j2g_header uint64 }

var A_arbace_box_spawn_A_fn_class *jrt.Class



type A_arbace_box_spawn_wait_A struct{ j2g_header uint64 }

var A_arbace_box_spawn_wait_A_fn_class *jrt.Class



type A_arbace_box_store_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_store_QMARK__A_fn_class *jrt.Class



type A_arbace_box_tree_A struct{ j2g_header uint64 }

var A_arbace_box_tree_A_fn_class *jrt.Class



type A_arbace_box_tree_get_A struct{ j2g_header uint64 }

var A_arbace_box_tree_get_A_fn_class *jrt.Class



type A_arbace_box_tree_get_fn__533000088_A struct{ j2g_header uint64 }

var A_arbace_box_tree_get_fn__533000088_A_fn_class *jrt.Class



type A_arbace_box_tree_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_tree_name_QMARK__A_fn_class *jrt.Class



type A_arbace_box_tree_name_QMARK__fn__533000038_A struct{ j2g_header uint64 }

var A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class *jrt.Class



type A_arbace_box_tree_text_A struct{ j2g_header uint64 }

var A_arbace_box_tree_text_A_fn_class *jrt.Class



type A_arbace_box_tree_text_fn__533000042_A struct{ j2g_header uint64 }

var A_arbace_box_tree_text_fn__533000042_A_fn_class *jrt.Class



type A_arbace_box_utf8_compare_A struct{ j2g_header uint64 }

var A_arbace_box_utf8_compare_A_fn_class *jrt.Class
