//line aot_arbace_box.ae:1
package aot_arbace_box

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_New() *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A { A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_Init(); t := &A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_2; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_3; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_4; tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10); var tmp11 *lang.Var; A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_1; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_box_A_Init(); tmp15 = A_arbace_box_A_const_6; tmp12.Invoke_O_O__O(tmp14, tmp15); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_132)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_133)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp18 != nil { panic(tmp18) }; return tmp3 }
//line :4:1
func A_arbace_box_eval533000008_fn__533000009_A_New() *A_arbace_box_eval533000008_fn__533000009_A { A_arbace_box_eval533000008_fn__533000009_A_Init(); t := &A_arbace_box_eval533000008_fn__533000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_eval533000008_fn__533000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }







































func A_arbace_box_fail_A_New() *A_arbace_box_fail_A { A_arbace_box_fail_A_Init(); t := &A_arbace_box_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_fail_A) Invoke_O_O_O_O__O(self, kind__0, msg__1, data__2 any) any { var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_14; panic(jrt.Thrown(jrt.Throwable_Cast(tmp2.Invoke_O_O__O(msg__1, tmp4.Invoke_O_O_O__O(data__2, tmp5.Ref(), kind__0))))) }


func A_arbace_box_answer_A_New() *A_arbace_box_answer_A { A_arbace_box_answer_A_Init(); t := &A_arbace_box_answer_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_answer_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_answer_A) Invoke_O_O_O_O__O(self, p_code__0, what__1, data__2 any) any { var code__0 int64 = lang.RT_LongCast_O__J(p_code__0); var G__533000013__4_ int64 = code__0; switch


	int32(G__533000013__4_) { case -5: if -5 == G__533000013__4_ {


		var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_16; var tmp4 any = tmp3.Ref(); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_124, nil); var tmp6 *lang.Var; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_17; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_18; return tmp2.Invoke_O_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, what__1, nil, tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(data__2)))).Ref(), data__2) }
//line :50:1
	case -4: if -4 == G__533000013__4_ {

		var tmp9 *lang.Var; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_15; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_19; var tmp12 any = tmp11.Ref(); return tmp10.Invoke_O_O_O__O(tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_125), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(), data__2) }
//line :50:1
	case -3: if -3 == G__533000013__4_ {
		var tmp13 *lang.Var; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_15; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_box_A_Init(); tmp15 = A_arbace_box_A_const_20; var tmp16 any = tmp15.Ref(); return tmp14.Invoke_O_O_O__O(tmp16, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_126), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(), data__2) }
//line :50:1
	default:}; var tmp17 /*line :55:1*/*lang.Var; A_arbace_box_A_Init(); tmp17 = A_arbace_box_A_const_15; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_box_A_Init(); tmp19 = A_arbace_box_A_const_21; var tmp20 any = tmp19.Ref(); return tmp18.Invoke_O_O_O__O(tmp20, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_127), jrt.RefArrayOf(jrt.Object_class, what__1, nil)).Ref(), data__2) }

func A_arbace_box_hash_bytes_A_New() *A_arbace_box_hash_bytes_A { A_arbace_box_hash_bytes_A_Init(); t := &A_arbace_box_hash_bytes_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Ctor() {}
//line :57:1
func (t *A_arbace_box_hash_bytes_A) Invoke_O_O_O__O(self, h__0, what__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_23; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(h__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_24; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_25; tmp1 = tmp4.Invoke_O_O__O(tmp5, h__0) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { } else {
		var tmp6 *lang.Var; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_15; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_26; var tmp9 any = tmp8.Ref(); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_149, nil); var tmp11 *lang.Var; A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_17; var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, what__1, nil, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(h__0))).Ref(); var tmp13 *lang.Keyword; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_27; tmp7.Invoke_O_O_O__O(tmp9, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13.Ref(), h__0))) }
//line :57:1
	var b__3 any; var tmp14 any




	A_arbace_box_A_Init(); tmp14 = A_arbace_box_A_const_22; b__3 = lang.Numbers_Byte_array_O__B1(tmp14).Ref()
//line :57:1
	var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J(32); var i__5 int64 = 0; L1: for {





		if lang.Numbers_Lt_J_J__Z(i__5, n__1927000701__auto____4) {
			var tmp15 *jrt.ByteArray = jrt.A2g_CastArray[*jrt.ByteArray](b__3, jrt.Prim_byte.ArrayClass()); var tmp16 int32 = lang.RT_IntCast_J__I(i__5); var tmp17 *lang.Var; A_arbace_box_A_Init(); tmp17 = A_arbace_box_A_const_28; jrt.Byte_ValueOf_B__Byte(lang.RT_Aset_B1_I_B__B(tmp15, tmp16, lang.RT_UncheckedByteCast_I__B(jrt.Integer_ParseInt_String_I__I(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O_O__O(h__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Multiply_J_J__J(2, i__5)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(2, lang.Numbers_Multiply_J_J__J(2, i__5))).Ref())), lang.RT_IntCast_J__I(16)))))
//line :63:1
			i__5 = lang.Numbers_Unchecked_inc_J__J(i__5); continue L1 }
//line :57:1
		break L1 }; return b__3
}








func A_arbace_box_hex_A_New() *A_arbace_box_hex_A { A_arbace_box_hex_A_Init(); t := &A_arbace_box_hex_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_box_hex_A) Ctor() {}
//line :67:1
func (t *A_arbace_box_hex_A) Invoke_O_O__O(self, b__0 any) any { var sb__2 any = jrt.StringBuilder_New_I(lang.RT_IntCast_J__I(64)); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()))); var i__4 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z(i__4, n__1927000701__auto____3) { var x__5 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__4))).Ref()), 255)

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_ShiftRight_J_J__J(x__5, 4)), lang.RT_IntCast_J__I(16)))
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(x__5, 15)), lang.RT_IntCast_J__I(16)))
//line :71:1
		i__4 = lang.Numbers_Unchecked_inc_J__J(i__4); continue L1 }
//line :67:1
	break L1 }; var tmp1 /*line :75:1*/*lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_29; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(sb__2) }

func A_arbace_box_store_QMARK__A_New() *A_arbace_box_store_QMARK__A { A_arbace_box_store_QMARK__A_Init(); t := &A_arbace_box_store_QMARK__A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Ctor() {}
//line :77:1
func (t *A_arbace_box_store_QMARK__A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_30; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O())).Ref()
}
func A_arbace_box_put_A_New() *A_arbace_box_put_A { A_arbace_box_put_A_Init(); t := &A_arbace_box_put_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_put_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_put_A) Invoke_O_O__O(self, x__0 any) any { var b__2 any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) { b__2 = jrt.NN(jrt.String_Cast(x__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else { var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0)) { b__2 = x__0 } else { var tmp3 *lang.Keyword; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_32; if tmp3 != nil { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_161, nil); var tmp5 *lang.Var; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_33; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__0)))))) } else { b__2 = nil } } }; var h__3 any; var tmp6 any;



	A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_22; h__3 = lang.Numbers_Byte_array_O__B1(tmp6).Ref(); var code__4 any; var tmp7 /*line :82:1*/*lang.Var;







	A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_34; code__4 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(b__2, h__3); if
	lang.Numbers_IsZero_O__Z(code__4) { } else {
		var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_36; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_37; var tmp11 any = tmp10.Ref(); tmp9.Invoke_O_O_O__O(code__4, Lit_162, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__2, jrt.Prim_byte.ArrayClass()))).Ref()))) }; var tmp12 /*line :93:1*/*lang.Var; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_35; return lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(h__3) }

func A_arbace_box_get_bytes_A_New() *A_arbace_box_get_bytes_A { A_arbace_box_get_bytes_A_Init(); t := &A_arbace_box_get_bytes_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_box_get_bytes_A) Ctor() {}
//line :95:1
func (t *A_arbace_box_get_bytes_A) Invoke_O_O__O(self, h__0 any) any { var hb__2 any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_38; hb__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(h__0, Lit_141); var n__3 any; var tmp2 /*line :95:1*/*lang.Var;



	A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_39; n__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(hb__2); if
	lang.Util_Equiv_O_J__Z(n__3, -1) { return nil } else { if lang.Numbers_IsNeg_O__Z(n__3) {

		var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_36; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_27; return tmp4.Invoke_O_O_O__O(n__3, Lit_141, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5.Ref(), h__0))) } else {
//line :100:1
			var tmp6 *lang.Keyword; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_32; if tmp6 != nil {


				var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_40; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(hb__2) } else {
//line :100:1
					return nil } } } }




func A_arbace_box_get_A_New() *A_arbace_box_get_A { A_arbace_box_get_A_Init(); t := &A_arbace_box_get_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_box_get_A) Ctor() {}
//line :105:1
func (t *A_arbace_box_get_A) Invoke_O_O__O(self, h__0 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_41; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(h__0); if jrt.A2g_Truth(temp__1927000414__auto____2) { var b__3 any = temp__1927000414__auto____2; return jrt.String_New_B1_Charset(jrt.A2g_CastArray[*jrt.ByteArray](b__3, jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_UTF_8) } else { return nil } }


func A_arbace_box_size_A_New() *A_arbace_box_size_A { A_arbace_box_size_A_Init(); t := &A_arbace_box_size_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_box_size_A) Ctor() {}
//line :111:1
func (t *A_arbace_box_size_A) Invoke_O_O__O(self, h__0 any) any { var n__2 any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_38; n__2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(h__0, Lit_211)); if
	lang.Util_Equiv_O_J__Z(n__2, -1) { return nil } else { if lang.Numbers_IsNeg_O__Z(n__2) {

		var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_36; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_27; return tmp5.Invoke_O_O_O__O(n__2, Lit_211, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6.Ref(), h__0))) } else {
//line :115:1
			var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_32; if tmp7 != nil { return n__2 } else { return nil } } } }




func A_arbace_box_ref_A_New() *A_arbace_box_ref_A { A_arbace_box_ref_A_Init(); t := &A_arbace_box_ref_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_box_ref_A) Ctor() {}
//line :120:1
func (t *A_arbace_box_ref_A) Invoke_O_O__O(self, name__0 any) any { var h__2 any; var tmp1 any;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_22; h__2 = lang.Numbers_Byte_array_O__B1(tmp1).Ref(); var code__3 any; var tmp2 /*line :120:1*/*lang.Var;



	A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_42; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_29; code__3 = tmp3.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(name__0), h__2); var G__533000022__4_ any = code__3; if
	jrt.Number_InstanceOf(G__533000022__4_) { switch jrt.Number_Cast(G__533000022__4_).IntValue__I() { case -1: var tmp5 any; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_43; if lang.Util_Equiv_O_O__Z(G__533000022__4_, tmp5) { return nil }; case 0: var tmp6 any; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_44; if lang.Util_Equiv_O_O__Z(G__533000022__4_, tmp6) {
		var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_35; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(h__2) }
//line :125:1
	default:} }; var tmp8 /*line :128:1*/*lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_36; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_18; return tmp9.Invoke_O_O_O__O(code__3, Lit_177, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10.Ref(), name__0))) }

func A_arbace_box_ref_BANG__answer_A_New() *A_arbace_box_ref_BANG__answer_A { A_arbace_box_ref_BANG__answer_A_Init(); t := &A_arbace_box_ref_BANG__answer_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Ctor() {}
//line :130:1
func (t *A_arbace_box_ref_BANG__answer_A) Invoke_O_O_O_O__O(self, code__0, name__1, h__2 any) any {
	if lang.Util_Equiv_O_J__Z(code__0, -2) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp1 bool; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_J__Z(code__0, -1)

		if and__1927000168__auto____4 { var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_45; tmp1 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(h__2), nil) } else { tmp1 = and__1927000168__auto____4 }
//line :131:1
		if tmp1 {


			var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_15; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_46; var tmp6 any = tmp5.Ref(); var tmp7 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_181, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(); var tmp8 *lang.Keyword; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_18; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_27; return tmp4.Invoke_O_O_O__O(tmp6, tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, name__1, tmp10.Ref(), h__2))) } else {
//line :131:1
				var tmp11 *lang.Keyword; A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_32; if tmp11 != nil {



					var tmp12 *lang.Var; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_36; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_box_A_Init(); tmp14 = A_arbace_box_A_const_18; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_box_A_Init(); tmp16 = A_arbace_box_A_const_27; return tmp13.Invoke_O_O_O__O(code__0, Lit_179, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, name__1, tmp16.Ref(), h__2))) } else {
//line :131:1
						return nil
					}
			}
	}
}

func A_arbace_box_ref_BANG__A_New() *A_arbace_box_ref_BANG__A { A_arbace_box_ref_BANG__A_Init(); t := &A_arbace_box_ref_BANG__A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Ctor() {}
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O_O__O(self, name__0, h__1, old__2 any) any { var ob__4 any; if






	lang.Util_Identical_O_O__Z(old__2, nil) { var tmp1 any; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_22; ob__4 = lang.Numbers_Byte_array_O__B1(tmp1).Ref() } else { var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_38; ob__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(old__2, Lit_179) }; var code__5 any; var tmp3 /*line :137:1*/*lang.Var;







	A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_47; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_29; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(name__0); var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_38; code__5 = tmp4.Invoke_O_O_O__O(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(h__1, Lit_179), ob__4); var or__1927000174__auto____6 bool = /*line :137:1*/lang.Numbers_IsZero_O__Z(code__5); if or__1927000174__auto____6 {








		return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_48; return lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O_O__O(code__5, name__0, h__1) } }
//line :137:1
func (t *A_arbace_box_ref_BANG__A) Invoke_O_O_O__O(self, name__0, h__1 any) any { var code__3 any; var tmp1 *lang.Var;



	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_47; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_29; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(name__0); var tmp5 *lang.Var; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_38; code__3 = tmp2.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(h__1, Lit_179), nil); var or__1927000174__auto____4 bool = /*line :137:1*/lang.Numbers_IsZero_O__Z(code__3); if or__1927000174__auto____4 {




		return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var tmp6 *lang.Var; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_48; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(code__3, name__0, h__1) } }





func A_arbace_box_put_BANG__A_New() *A_arbace_box_put_BANG__A { A_arbace_box_put_BANG__A_Init(); t := &A_arbace_box_put_BANG__A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_box_put_BANG__A) Ctor() {}
//line :148:1
func (t *A_arbace_box_put_BANG__A) Invoke_O_O_O__O(self, name__0, x__1 any) any { var h__3 any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_49; h__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__1); var tmp2 /*line :152:1*/*lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_50; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(name__0, h__3); return h__3 }


func A_arbace_box_load_A_New() *A_arbace_box_load_A { A_arbace_box_load_A_Init(); t := &A_arbace_box_load_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_box_load_A) Ctor() {}
//line :155:1
func (t *A_arbace_box_load_A) Invoke_O_O__O(self, name__0 any) any { var G__533000027__2_ any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_51; G__533000027__2_ = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(name__0); if lang.Util_Identical_O_O__Z(G__533000027__2_, nil) { return nil } else { var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_52; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(G__533000027__2_) } }

func A_arbace_box_load_ref_A_New() *A_arbace_box_load_ref_A { A_arbace_box_load_ref_A_Init(); t := &A_arbace_box_load_ref_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_box_load_ref_A) Ctor() {}
//line :160:1
func (t *A_arbace_box_load_ref_A) Invoke_O_O__O(self, name__0 any) any { var src__2 any; var tmp1 *lang.Var;



	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_53; src__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(name__0); if
	lang.Util_Identical_O_O__Z(src__2, nil) {
		var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_15; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_54; var tmp5 any = tmp4.Ref(); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_158, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)).Ref(); var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_18; tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), name__0))) }; var tmp8 jrt.Reader_I =
	jrt.StringReader_New_String(jrt.String_Cast(src__2)); var tmp9 *jrt.String = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_159, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__0)); var tmp10 *lang.Var; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_29; return lang.Compiler_Load_Reader_String_String__O(tmp8, tmp9, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(name__0))) }

func A_arbace_box_boxed_QMARK__A_New() *A_arbace_box_boxed_QMARK__A { A_arbace_box_boxed_QMARK__A_Init(); t := &A_arbace_box_boxed_QMARK__A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Ctor() {}
//line :169:1
func (t *A_arbace_box_boxed_QMARK__A) Invoke_O__O(self any) any {
	return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_129, jrt.System_GetProperty_String__String(Lit_130).Ref())).Ref()
}
func A_arbace_box_fs_dir_A_New() *A_arbace_box_fs_dir_A { A_arbace_box_fs_dir_A_Init(); t := &A_arbace_box_fs_dir_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_box_fs_dir_A) Ctor() {}
//line :172:1
func (t *A_arbace_box_fs_dir_A) Invoke_O_O_O__O(self, dir__0, what__1 any) any {
	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(dir__0)) {
		var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_29; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(dir__0) } else {
//line :173:1
			var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_56; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O()) { return Lit_137 } else { var tmp4 *lang.Keyword; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_32; if tmp4 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_138), jrt.RefArrayOf(jrt.Object_class, what__1, nil))))) } else { return nil
			}
			}
		}
}

func A_arbace_box_save_fs_BANG__A_New() *A_arbace_box_save_fs_BANG__A { A_arbace_box_save_fs_BANG__A_Init(); t := &A_arbace_box_save_fs_BANG__A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Ctor() {}
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any; var tmp1 *lang.Var;





	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_57; d__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(dir__1, Lit_207); var err__4 any; var tmp2 /*line :179:1*/*lang.Var;






	A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_58; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.Class; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_61; var tmp5 any = tmp4.Ref(); var tmp6 any; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_62; err__4 = tmp3.Invoke_O_O__O(tmp5, tmp6); var tar__5 any; var tmp7 /*line :179:1*/*lang.Var;







	A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_59; tar__5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(d__3, err__4); if
	lang.Util_Identical_O_O__Z(tar__5, nil) {
		var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_15; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_21; var tmp11 any = tmp10.Ref(); var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_208, nil, Lit_156, nil); var tmp13 *jrt.Class; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_63; var tmp14 *jrt.Class = tmp13; var tmp15 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp14, Lit_209, jrt.RefArrayOf(jrt.Object_class, err__4, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(0)).Ref())))).Ref(); var tmp16 *lang.Keyword; A_arbace_box_A_Init(); tmp16 = A_arbace_box_A_const_18; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_box_A_Init(); tmp18 = A_arbace_box_A_const_64; tmp9.Invoke_O_O_O__O(tmp11, tmp15, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, ref__0, tmp18.Ref(), d__3))) }; var tmp19 /*line :190:1*/*lang.Var; A_arbace_box_A_Init(); tmp19 = A_arbace_box_A_const_60; return lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O_O__O(ref__0, tar__5) }
//line :179:1
func (t *A_arbace_box_save_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {



	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_65; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(ref__0, nil)
}







func A_arbace_box_load_fs_BANG__A_New() *A_arbace_box_load_fs_BANG__A { A_arbace_box_load_fs_BANG__A_Init(); t := &A_arbace_box_load_fs_BANG__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Ctor() {}
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O_O__O(self, ref__0, dir__1 any) any { var d__3 any; var tmp1 *lang.Var;




	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_57; d__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(dir__1, Lit_153); var tar__4 any; var G__533000033__4_ any; var tmp2 /*line :192:1*/*lang.Var;





	A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_51; G__533000033__4_ = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(ref__0); if lang.Util_Identical_O_O__Z(G__533000033__4_, nil) { tar__4 = nil } else { var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_41; tar__4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(G__533000033__4_) }; if
	lang.Util_Identical_O_O__Z(tar__4, nil) {
		var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_15; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_54; var tmp7 any = tmp6.Ref(); var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_154, nil), jrt.RefArrayOf(jrt.Object_class, nil, ref__0)).Ref(); var tmp9 *lang.Keyword; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_18; tmp5.Invoke_O_O_O__O(tmp7, tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9.Ref(), ref__0))) }; var temp__1927000414__auto____5 any; var tmp10 /*line :192:1*/*lang.Var;








	A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_66; temp__1927000414__auto____5 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(tar__4, d__3); if jrt.A2g_Truth(temp__1927000414__auto____5) { var e__6 any = temp__1927000414__auto____5; var tmp11 *lang.Var
		A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_21; var tmp14 any = tmp13.Ref(); var tmp15 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_155, nil, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3, nil, e__6)).Ref(); var tmp16 *lang.Keyword; A_arbace_box_A_Init(); tmp16 = A_arbace_box_A_const_18; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_box_A_Init(); tmp18 = A_arbace_box_A_const_64; tmp12.Invoke_O_O_O__O(tmp14, tmp15, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, ref__0, tmp18.Ref(), d__3))) }; return nil }
//line :192:1
func (t *A_arbace_box_load_fs_BANG__A) Invoke_O_O__O(self, ref__0 any) any {


	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_67; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(ref__0, nil)
}














func A_arbace_box_quote_str_A_New() *A_arbace_box_quote_str_A { A_arbace_box_quote_str_A_Init(); t := &A_arbace_box_quote_str_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_quote_str_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_quote_str_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_172, nil, Lit_172), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_CharSequence_CharSequence__String(Lit_173, Lit_174)).Replace_CharSequence_CharSequence__String(Lit_172, Lit_175).Ref(), nil)).Ref()
}
func A_arbace_box_utf8_compare_A_New() *A_arbace_box_utf8_compare_A { A_arbace_box_utf8_compare_A_Init(); t := &A_arbace_box_utf8_compare_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Ctor() {}
//line :216:1
func (t *A_arbace_box_utf8_compare_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { { var x__3 any = jrt.NN(jrt.String_Cast(a__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var y__4 any = jrt.NN(jrt.String_Cast(b__1)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var n__5 int64 = lang.Numbers_Min_J_J__J(int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](x__3, jrt.Prim_byte.ArrayClass()))), int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](y__4, jrt.Prim_byte.ArrayClass())))); var i__6 int64 = 0; L1: for {






	if lang.Numbers_Lt_J_J__Z(i__6, n__5) { var c__7 int32 = lang.Util_Compare_O_O__I(jrt.Long_ValueOf_J__Long(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](x__3, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__6))).Ref()), 255)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](y__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__6))).Ref()), 255)).Ref())

		if lang.Numbers_IsZero_J__Z(int64(c__7)) { i__6 = lang.Numbers_Inc_J__J(i__6); continue L1 } else { return jrt.Integer_ValueOf_I__Integer(c__7).Ref() } } else {
			return jrt.Integer_ValueOf_I__Integer(lang.Util_Compare_O_O__I(jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](x__3, jrt.Prim_byte.ArrayClass()))).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](y__4, jrt.Prim_byte.ArrayClass()))).Ref())).Ref() } } }; /*line :216:1*/panic("a2g: unreachable") }











func A_arbace_box_tree_name_QMARK__A_New() *A_arbace_box_tree_name_QMARK__A { A_arbace_box_tree_name_QMARK__A_Init(); t := &A_arbace_box_tree_name_QMARK__A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Ctor() {}
//line :228:1
func (t *A_arbace_box_tree_name_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;
										A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_23; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_68; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_70; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_71; and__1927000168__auto____3 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, n__0)); if jrt.A2g_Truth(and__1927000168__auto____3) {
											var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_69; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_box_tree_name_QMARK__fn__533000038_A_New(); var tmp10 *jrt.Class; A_arbace_box_tree_name_QMARK__fn__533000038_A_Init(); tmp10 = A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class; return tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), n__0) } else {
//line :229:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }
func A_arbace_box_tree_name_QMARK__fn__533000038_A_New() *A_arbace_box_tree_name_QMARK__fn__533000038_A { A_arbace_box_tree_name_QMARK__fn__533000038_A_Init(); t := &A_arbace_box_tree_name_QMARK__fn__533000038_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Ctor() {}
//line :230:1
func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Invoke_O_O__O(self, p1__533000037_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_72; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_73; and__1927000168__auto____2 = tmp2.Invoke_O_O__O(p1__533000037_SHARP___1, tmp3); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z(int64(lang.RT_IntCast_O__I(p1__533000037_SHARP___1)), 32); if and__1927000168__auto____3 { var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_72; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(p1__533000037_SHARP___1)).Ref(); var tmp7 any; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_74; return tmp5.Invoke_O_O__O(tmp6, tmp7) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_box_tree_text_A_New() *A_arbace_box_tree_text_A { A_arbace_box_tree_text_A_Init(); t := &A_arbace_box_tree_text_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_box_tree_text_A) Ctor() {}
//line :232:1
func (t *A_arbace_box_tree_text_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_226, nil, Lit_186); var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_75; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_29; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_76; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_77; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_box_tree_text_fn__533000042_A_New(); var tmp11 *jrt.Class; A_arbace_box_tree_text_fn__533000042_A_Init(); tmp11 = A_arbace_box_tree_text_fn__533000042_A_fn_class; var tmp12 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp13 *lang.Var; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_83; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_A_Init(); tmp15 = A_arbace_box_A_const_84; var tmp16 any = jrt.NN(tmp15).GetRawRoot__O(); var tmp17 *lang.Var; A_arbace_box_A_Init(); tmp17 = A_arbace_box_A_const_85; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(Lit_227, tmp9.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O_O__O(tmp16, jrt.NN(tmp17).GetRawRoot__O(), m__0)))), nil)).Ref()
}
func A_arbace_box_tree_text_fn__533000042_A_New() *A_arbace_box_tree_text_fn__533000042_A { A_arbace_box_tree_text_fn__533000042_A_Init(); t := &A_arbace_box_tree_text_fn__533000042_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Ctor() {}
//line :237:1
func (t *A_arbace_box_tree_text_fn__533000042_A) Invoke_O_O__O(self, p__533000041__1 any) any { var vec__533000043__2 any = p__533000041__1; var n__3 any = lang.RT_Nth_O_I_O__O(vec__533000043__2, lang.RT_IntCast_J__I(0), nil); var vec__533000046__4 any = lang.RT_Nth_O_I_O__O(vec__533000043__2, lang.RT_IntCast_J__I(1), nil); var kind__5 any = lang.RT_Nth_O_I_O__O(vec__533000046__4, lang.RT_IntCast_J__I(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O(vec__533000046__4, lang.RT_IntCast_J__I(1), nil); var size__7 any = lang.RT_Nth_O_I_O__O(vec__533000046__4, lang.RT_IntCast_J__I(2), nil); var e__8 any = vec__533000046__4; var tmp1 *lang.Var;
												A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_81; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__3)) { } else {
													var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_15; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_82; var tmp5 any = tmp4.Ref(); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_229, nil); var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_17; var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(n__3))).Ref(); var tmp9 *lang.Keyword; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_18; tmp3.Invoke_O_O_O__O(tmp5, tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9.Ref(), n__3))) }; var tmp10 /*line :240:1*/*lang.Var; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_38; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(h__6, Lit_230); var tmp11 /*line :241:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_202, nil); var tmp12 *lang.Var; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_78; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(n__3); var tmp14 any; var G__533000049__12_ any = kind__5; L1:
													switch { default: switch lang.Util_Hash_O__I(G__533000049__12_) >> 2 & 3 { case 1: var tmp15 *lang.Keyword; A_arbace_box_A_Init(); tmp15 = A_arbace_box_A_const_79; if any(G__533000049__12_) == any(tmp15.Ref()) {
														tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(size__7)).Ref(), nil)).Ref()
//line :242:1
			break L1 }; case 2: var tmp16 *lang.Keyword; A_arbace_box_A_Init(); tmp16 = A_arbace_box_A_const_64; if any(G__533000049__12_) == any(tmp16.Ref()) {

				tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_231, nil, Lit_199), jrt.RefArrayOf(jrt.Object_class, nil, h__6, nil)).Ref()
//line :242:1
				break L1 }; case 3: var tmp17 *lang.Keyword; A_arbace_box_A_Init(); tmp17 = A_arbace_box_A_const_80; if any(G__533000049__12_) == any(tmp17.Ref()) {
					tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s1:[ns2: \"ns2:\" ns1:]", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, kind__5, nil, h__6, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(size__7)).Ref(), nil)).Ref()
//line :242:1
					break L1 }; default:
		}

			var tmp18 *lang.Var; A_arbace_box_A_Init(); tmp18 = A_arbace_box_A_const_15; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_box_A_Init(); tmp20 = A_arbace_box_A_const_82; var tmp21 any = tmp20.Ref(); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_232, nil); var tmp23 *lang.Var; A_arbace_box_A_Init(); tmp23 = A_arbace_box_A_const_17; var tmp24 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(e__8))).Ref(); var tmp25 *lang.Keyword; A_arbace_box_A_Init(); tmp25 = A_arbace_box_A_const_18; tmp14 = tmp19.Invoke_O_O_O__O(tmp21, tmp24, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25.Ref(), n__3)))}; return /*line :241:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, tmp14)).Ref() }








func A_arbace_box_put_tree_A_New() *A_arbace_box_put_tree_A { A_arbace_box_put_tree_A_Init(); t := &A_arbace_box_put_tree_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_box_put_tree_A) Ctor() {}
//line :250:1
func (t *A_arbace_box_put_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_86; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(m__0))
}
func A_arbace_box_tree_A_New() *A_arbace_box_tree_A { A_arbace_box_tree_A_Init(); t := &A_arbace_box_tree_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_box_tree_A) Ctor() {}
//line :255:1
func (t *A_arbace_box_tree_A) Invoke_O_O__O(self, h__0 any) any { var G__533000053__2_ any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_52; G__533000053__2_ = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(h__0); if lang.Util_Identical_O_O__Z(G__533000053__2_, nil) { return nil } else { var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_87; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(G__533000053__2_) } }

func A_arbace_box_put_file_A_New() *A_arbace_box_put_file_A { A_arbace_box_put_file_A_Init(); t := &A_arbace_box_put_file_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_box_put_file_A) Ctor() {}
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O_O__O(self, x__0, exec__1 any) any { var h__3 any; var tmp1 *lang.Var;




	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_49; h__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0); var tmp2 /*line :260:1*/*lang.Keyword; if





	jrt.A2g_Truth(exec__1) { A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_79 } else { A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_80 }; var tmp3 any = /*line :260:1*/tmp2.Ref(); var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_45; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, h__3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(h__3)) }
//line :260:1
func (t *A_arbace_box_put_file_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_88; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return tmp2.Invoke_O_O__O(x__0, tmp3.Ref())
}



func A_arbace_box_put_dir_A_New() *A_arbace_box_put_dir_A { A_arbace_box_put_dir_A_Init(); t := &A_arbace_box_put_dir_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_box_put_dir_A) Ctor() {}
//line :268:1
func (t *A_arbace_box_put_dir_A) Invoke_O_O__O(self, dir__0 any) any { var d__2 any; var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_29; d__2 = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(dir__0))); var fs__3 any = jrt.NN(jrt.File_Cast(d__2)).ListFiles__File1().Ref(); if





	lang.Util_Identical_O_O__Z(fs__3, nil) {
		var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_15; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_21; var tmp5 any = tmp4.Ref(); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_165, nil), jrt.RefArrayOf(jrt.Object_class, nil, dir__0)).Ref(); var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_64; tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), dir__0))) }; var tmp8 /*line :276:1*/*lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_89; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_90; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; var tmp13 any = tmp12.Ref(); var tmp14 any; var iter__1927001039__auto____4 any; var tmp15 any = A_arbace_box_put_dir_iter__533000056__533000060_A_New(); var tmp16 *jrt.Class;

	A_arbace_box_put_dir_iter__533000056__533000060_A_Init(); tmp16 = A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__3); return /*line :276:1*/ tmp9.Invoke_O__O(tmp11.Invoke_O_O__O(tmp13, tmp14)) }

func A_arbace_box_put_dir_iter__533000056__533000060_A_New() *A_arbace_box_put_dir_iter__533000056__533000060_A { A_arbace_box_put_dir_iter__533000056__533000060_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Ctor() {}
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Invoke_O_O__O(self, s__533000057__1 any) any { var tmp1 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(s__533000057__1, self); var tmp2 *jrt.Class; A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_Init(); tmp2 = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(p0, p1 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A { A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A{}; t.Ctor_O_O(p0, p1); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Ctor_O_O(c__s__533000057, c__iter__533000056 any) { t.F_s__533000057 = c__s__533000057; t.F_iter__533000056 = c__iter__533000056 }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Invoke_O__O(self any) any { { var s__533000057__1 any; var t_ any = t.F_s__533000057; t.F_s__533000057 = nil; s__533000057__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_91; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__533000057__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__533000057__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_92; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__533000057__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_93; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__533000057__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__533000059__6 any; var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_94; b__533000059__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(b__533000059__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_Init(); tmp6 = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_97; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_100; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__533000059__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); var tmp12 *lang.Var; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_101; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__533000057__3))) } else { var tmp13 *lang.Var; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_97; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_A_Init(); tmp15 = A_arbace_box_A_const_100; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__533000059__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_box_A_Init(); tmp16 = A_arbace_box_A_const_98; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__533000057__3); var tmp17 *lang.Var; A_arbace_box_A_Init(); tmp17 = A_arbace_box_A_const_99; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var tmp20 any

	if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var tmp21 *lang.Keyword; A_arbace_box_A_Init(); tmp21 = A_arbace_box_A_const_64; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_box_A_Init(); tmp23 = A_arbace_box_A_const_96; tmp20 = lang.Tuple_Create_O_O__IPersistentVector(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(f__4)) } else {

		var tmp24 *lang.Var; A_arbace_box_A_Init(); tmp24 = A_arbace_box_A_const_88; tmp20 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref(), jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(f__4)).CanExecute__Z()).Ref()) }
//line :278:1
	var tmp25 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, tmp20); var tmp26 lang.IFn = lang.IFn_Cast(t.F_iter__533000056); var tmp27 *lang.Var; A_arbace_box_A_Init(); tmp27 = A_arbace_box_A_const_102; return tmp18.Invoke_O_O__O(tmp25, tmp26.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__533000057__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :278:1
func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A { A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_Init(); t := &A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Ctor_O_I_O(c__b__533000059 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000059 = c__b__533000059; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :278:1
func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Invoke_O__O(self any) any { { var i__533000058__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__533000058__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__533000058__1)); var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_95; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__533000059; var tmp5 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp6 any

	if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_64; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_96; tmp6 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(f__2)) } else {

		var tmp10 *lang.Var; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_88; tmp6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref(), jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(f__2)).CanExecute__Z()).Ref()) }
//line :278:1
	tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6)); i__533000058__1 = lang.Numbers_Unchecked_inc_J__J(i__533000058__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_box_get_tree_A_New() *A_arbace_box_get_tree_A { A_arbace_box_get_tree_A_Init(); t := &A_arbace_box_get_tree_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_box_get_tree_A) Ctor() {}
//line :284:1
func (t *A_arbace_box_get_tree_A) Invoke_O_O_O__O(self, h__0, dir__1 any) any { var m__3 any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_103; m__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(h__0); var d__4 any; var tmp2 /*line :284:1*/*lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_29; d__4 = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(dir__1))); if




	lang.Util_Identical_O_O__Z(m__3, nil) {
		var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_15; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_46; var tmp6 any = tmp5.Ref(); var tmp7 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(); var tmp8 *lang.Keyword; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_27; tmp4.Invoke_O_O_O__O(tmp6, tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8.Ref(), h__0))) };
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(d__4)).Mkdirs__Z()); var seq_533000067__5 any; var tmp9 /*line :284:1*/*lang.Var;







	A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_91; seq_533000067__5 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(m__3); var chunk_533000068__6 any; var count_533000069__7 int64 = 0; var i_533000070__8 int64 = 0; L1:
//line :284:1
	for {







		if lang.Numbers_Lt_J_J__Z(i_533000070__8, count_533000069__7) { var vec__533000071__9 any = lang.Indexed_Cast(chunk_533000068__6).Nth_I__O(lang.RT_IntCast_J__I(i_533000070__8)); var n__10 any = lang.RT_Nth_O_I_O__O(vec__533000071__9, lang.RT_IntCast_J__I(0), nil); var vec__533000074__11 any = lang.RT_Nth_O_I_O__O(vec__533000071__9, lang.RT_IntCast_J__I(1), nil); var kind__12 any = lang.RT_Nth_O_I_O__O(vec__533000074__11, lang.RT_IntCast_J__I(0), nil); var eh__13 any = lang.RT_Nth_O_I_O__O(vec__533000074__11, lang.RT_IntCast_J__I(1), nil); var f__14 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__10)); var tmp10 *lang.Keyword

			A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_64; if lang.Util_Equiv_O_O__Z(kind__12, tmp10.Ref()) {
				var tmp11 *lang.Var; A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_104; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(eh__13, f__14) } else {
//line :294:1
					var o__15 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__14)); var tmp12 any = A_arbace_box_get_tree_fn__533000077_A_New_O_O(o__15, eh__13); var tmp13 *jrt.Class

					A_arbace_box_get_tree_fn__533000077_A_Init(); tmp13 = A_arbace_box_get_tree_fn__533000077_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O()

					var tmp14 *lang.Keyword; A_arbace_box_A_Init(); tmp14 = A_arbace_box_A_const_79; if lang.Util_Equiv_O_O__Z(kind__12, tmp14.Ref()) { var tmp15 *jrt.File = jrt.File_Cast(f__14); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(tmp15).SetExecutable_Z__Z(jrt.NN(tmp16).BooleanValue__Z())) } }
//line :292:1
			seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = seq_533000067__5, chunk_533000068__6, count_533000069__7, lang.Numbers_Unchecked_inc_J__J(i_533000070__8); continue L1 } else { var temp__1927000414__auto____9 any; var tmp17 *lang.Var; A_arbace_box_A_Init(); tmp17 = A_arbace_box_A_const_91; temp__1927000414__auto____9 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_533000067__5); if jrt.A2g_Truth(temp__1927000414__auto____9) { var seq_533000067__10 any = temp__1927000414__auto____9; var tmp18 *lang.Var; A_arbace_box_A_Init(); tmp18 = A_arbace_box_A_const_92; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_533000067__10)) { var c__1927000678__auto____11 any; var tmp19 *lang.Var; A_arbace_box_A_Init(); tmp19 = A_arbace_box_A_const_93; c__1927000678__auto____11 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_533000067__10); var tmp20 *lang.Var; A_arbace_box_A_Init(); tmp20 = A_arbace_box_A_const_101; seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_533000067__10), c__1927000678__auto____11, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__533000079__11 any; var tmp21 *lang.Var; A_arbace_box_A_Init(); tmp21 = A_arbace_box_A_const_98; vec__533000079__11 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_533000067__10); var n__12 any = lang.RT_Nth_O_I_O__O(vec__533000079__11, lang.RT_IntCast_J__I(0), nil); var vec__533000082__13 any = lang.RT_Nth_O_I_O__O(vec__533000079__11, lang.RT_IntCast_J__I(1), nil); var kind__14 any = lang.RT_Nth_O_I_O__O(vec__533000082__13, lang.RT_IntCast_J__I(0), nil); var eh__15 any = lang.RT_Nth_O_I_O__O(vec__533000082__13, lang.RT_IntCast_J__I(1), nil); var f__16 any = jrt.File_New_File_String(jrt.File_Cast(d__4), jrt.String_Cast(n__12)); var tmp22 *lang.Keyword

				A_arbace_box_A_Init(); tmp22 = A_arbace_box_A_const_64; if lang.Util_Equiv_O_O__Z(kind__14, tmp22.Ref()) {
					var tmp23 *lang.Var; A_arbace_box_A_Init(); tmp23 = A_arbace_box_A_const_104; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O_O__O(eh__15, f__16) } else {
//line :294:1
						var o__17 any = jrt.FileOutputStream_New_File(jrt.File_Cast(f__16)); var tmp24 any = A_arbace_box_get_tree_fn__533000085_A_New_O_O(eh__15, o__17); var tmp25 *jrt.Class

						A_arbace_box_get_tree_fn__533000085_A_Init(); tmp25 = A_arbace_box_get_tree_fn__533000085_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil).Invoke__O()

						var tmp26 *lang.Keyword; A_arbace_box_A_Init(); tmp26 = A_arbace_box_A_const_79; if lang.Util_Equiv_O_O__Z(kind__14, tmp26.Ref()) { var tmp27 *jrt.File = jrt.File_Cast(f__16); var tmp28 *jrt.Boolean; jrt.Boolean_Init(); tmp28 = jrt.Boolean_TRUE; jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(tmp27).SetExecutable_Z__Z(jrt.NN(tmp28).BooleanValue__Z())) } }
//line :292:1
				var tmp29 *lang.Var; A_arbace_box_A_Init(); tmp29 = A_arbace_box_A_const_105; seq_533000067__5, chunk_533000068__6, count_533000069__7, i_533000070__8 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_533000067__10), nil, 0, 0; continue L1 } } }
//line :284:1
		break L1 }; return nil }











func A_arbace_box_get_tree_fn__533000077_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000077_A { A_arbace_box_get_tree_fn__533000077_A_Init(); t := &A_arbace_box_get_tree_fn__533000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Ctor_O_O(c__o, c__eh any) { t.F_o = c__o; t.F_eh = c__eh }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000077_A) Invoke_O__O(self any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any; var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_41; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t.F_eh); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp5 *lang.Var; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_15; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_46; var tmp8 any = tmp7.Ref(); var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_146, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_27; var tmp11 any = tmp10.Ref(); var tmp12 any; var t_ any = t.F_eh; t.F_eh = nil; tmp12 = t_; tmp3 = tmp6.Invoke_O_O_O__O(tmp8, tmp9, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12))) }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_145, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp14 any; var t__2 any = t.F_o; t.F_o = nil; tmp14 = t__2; jrt.FileOutputStream_Cast(tmp14).Close__V(); if tmp13 != nil { panic(tmp13) }; return tmp1 }
//line :296:1
func A_arbace_box_get_tree_fn__533000085_A_New_O_O(p0, p1 any) *A_arbace_box_get_tree_fn__533000085_A { A_arbace_box_get_tree_fn__533000085_A_Init(); t := &A_arbace_box_get_tree_fn__533000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Ctor_O_O(c__eh, c__o any) { t.F_eh = c__eh; t.F_o = c__o }
//line :296:1
func (t *A_arbace_box_get_tree_fn__533000085_A) Invoke_O__O(self any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 any = t.F_o; var tmp3 any; var or__1927000174__auto____3 any; var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_41; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t.F_eh); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp5 *lang.Var; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_15; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_46; var tmp8 any = tmp7.Ref(); var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_146, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_eh)).Ref(); var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_27; var tmp11 any = tmp10.Ref(); var tmp12 any; var t_ any = t.F_eh; t.F_eh = nil; tmp12 = t_; tmp3 = tmp6.Invoke_O_O_O__O(tmp8, tmp9, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12))) }; tmp1 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp2, Lit_145, jrt.RefArrayOf(jrt.Object_class, tmp3)) }
//line :296:1
	return nil }(); var tmp14 any; var t__2 any = t.F_o; t.F_o = nil; tmp14 = t__2; jrt.FileOutputStream_Cast(tmp14).Close__V(); if tmp13 != nil { panic(tmp13) }; return tmp1 }




func A_arbace_box_tree_get_A_New() *A_arbace_box_tree_get_A { A_arbace_box_tree_get_A_Init(); t := &A_arbace_box_tree_get_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_box_tree_get_A) Ctor() {}
//line :301:1
func (t *A_arbace_box_tree_get_A) Invoke_O_O_O__O(self, h__0, p__1 any) any {


	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_106; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_box_tree_get_fn__533000088_A_New(); var tmp4 *jrt.Class; A_arbace_box_tree_get_fn__533000088_A_Init(); tmp4 = A_arbace_box_tree_get_fn__533000088_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Keyword; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_64; var tmp7 any = lang.Tuple_Create_O_O__IPersistentVector(tmp6.Ref(), h__0); var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_109; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_110; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 *jrt.Class; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_61; var tmp13 *jrt.Class = tmp12; return tmp2.Invoke_O_O_O__O(tmp5, tmp7, tmp9.Invoke_O_O__O(tmp11, lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__1, tmp13, Lit_221, jrt.RefArrayOf(jrt.Object_class, Lit_137)))) }
//line :304:1
func A_arbace_box_tree_get_fn__533000088_A_New() *A_arbace_box_tree_get_fn__533000088_A { A_arbace_box_tree_get_fn__533000088_A_Init(); t := &A_arbace_box_tree_get_fn__533000088_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Ctor() {}
//line :304:1
func (t *A_arbace_box_tree_get_fn__533000088_A) Invoke_O_O_O__O(self, e__1, n__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = e__1; if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_64; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_98; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(e__1))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		var tmp5 *lang.Var; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_103; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_108; return lang.RT_Get_O_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(e__1)), n__2) } else {
			var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_107; return lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(nil)
		}
}








func A_arbace_box_request_text_A_New() *A_arbace_box_request_text_A { A_arbace_box_request_text_A_Init(); t := &A_arbace_box_request_text_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_box_request_text_A) Ctor() {}
//line :318:1
func (t *A_arbace_box_request_text_A) Invoke_O_O__O(self, p__533000091__0 any) any { var map__533000092__2 any = p__533000091__0; var map__533000092__3 any; if lang.ISeq_InstanceOf(map__533000092__2) { var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_105; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__533000092__2)) { var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_111; map__533000092__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__533000092__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_91; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__533000092__2)) { var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_98; map__533000092__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__533000092__2) } else { lang.PersistentArrayMap_Init(); map__533000092__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__533000092__3 = map__533000092__2 }; var image__4 any; var tmp5 *lang.Keyword; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_112; image__4 = lang.RT_Get_O_O__O(map__533000092__3, tmp5.Ref()); var args__5 any; var tmp6 *lang.Keyword; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_113; args__5 = lang.RT_Get_O_O__O(map__533000092__3, tmp6.Ref()); var env__6 any; var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_114; env__6 = lang.RT_Get_O_O__O(map__533000092__3, tmp7.Ref()); var trees__7 any; var tmp8 *lang.Keyword; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_115; trees__7 = lang.RT_Get_O_O__O(map__533000092__3, tmp8.Ref()); var out__8 any; var tmp9 *lang.Keyword; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_116; out__8 = lang.RT_Get_O_O__O(map__533000092__3, tmp9.Ref()); var cwd__9 any; var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_117; cwd__9 = lang.RT_Get_O_O__O(map__533000092__3, tmp10.Ref()); var ram__10 any; var tmp11 *lang.Keyword; A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_118; ram__10 = lang.RT_Get_O_O__O(map__533000092__3, tmp11.Ref()); var cpus__11 any; var tmp12 *lang.Keyword; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_119; cpus__11 = lang.RT_Get_O_O__O(map__533000092__3, tmp12.Ref()); var v__12 any; var tmp13 any = A_arbace_box_request_text_v__533000094_A_New(); var tmp14 *jrt.Class;



	A_arbace_box_request_text_v__533000094_A_Init(); tmp14 = A_arbace_box_request_text_v__533000094_A_fn_class; v__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp15 /*line :323:1*/*lang.Var; A_arbace_box_A_Init(); tmp15 = A_arbace_box_A_const_38; lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(image__4, Lit_183); var tmp16 /*line :324:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_184, nil, Lit_185, nil, nil, nil, nil, nil, nil, nil, Lit_186); var tmp17 any = lang.IFn_Cast(v__12).Invoke_O__O(args__5); var tmp18 *jrt.String; var tmp19 *lang.Var;
	A_arbace_box_A_Init(); tmp19 = A_arbace_box_A_const_91; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(env__6)) { tmp18 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_187, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(v__12).Invoke_O__O(env__6))) } else { tmp18 = nil }; var tmp20 any = /*line :324:1*/tmp18.Ref(); var tmp21 *jrt.String; var tmp22 *lang.Var;

	A_arbace_box_A_Init(); tmp22 = A_arbace_box_A_const_91; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(trees__7)) {
		var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_188, nil, Lit_189); var tmp24 *lang.Var; A_arbace_box_A_Init(); tmp24 = A_arbace_box_A_const_75; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_box_A_Init(); tmp26 = A_arbace_box_A_const_29; var tmp27 any = jrt.NN(tmp26).GetRawRoot__O(); var tmp28 *lang.Var; A_arbace_box_A_Init(); tmp28 = A_arbace_box_A_const_76; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; var iter__1927001039__auto____27 any; var tmp31 any = A_arbace_box_request_text_iter__533000096__533000100_A_New(); var tmp32 *jrt.Class
		A_arbace_box_request_text_iter__533000096__533000100_A_Init(); tmp32 = A_arbace_box_request_text_iter__533000096__533000100_A_fn_class; iter__1927001039__auto____27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); tmp30 = lang.IFn_Cast(iter__1927001039__auto____27).Invoke_O__O(trees__7)
//line :327:1
		tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp25.Invoke_O_O__O(tmp27, tmp29.Invoke_O_O__O(Lit_190, tmp30)), nil)) } else {
//line :326:1
			tmp21 = nil }; var tmp33 any = /*line :324:1*/tmp21.Ref(); var tmp34 *jrt.String; var tmp35 *lang.Var;





	A_arbace_box_A_Init(); tmp35 = A_arbace_box_A_const_91; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(out__8)) { var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_191, nil); var tmp37 *lang.Var; A_arbace_box_A_Init(); tmp37 = A_arbace_box_A_const_78; tmp34 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp36, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(out__8))) } else { tmp34 = nil }; var tmp38 any = /*line :324:1*/tmp34.Ref(); var tmp39 *jrt.String; var tmp40 any; var and__1927000168__auto____24 any; var tmp41 *lang.Var;






	A_arbace_box_A_Init(); tmp41 = A_arbace_box_A_const_91; and__1927000168__auto____24 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(cwd__9); if jrt.A2g_Truth(and__1927000168__auto____24) { var tmp42 *lang.Var; A_arbace_box_A_Init(); tmp42 = A_arbace_box_A_const_72; tmp40 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O_O__O(cwd__9, Lit_137) } else { tmp40 = and__1927000168__auto____24 }; if jrt.A2g_Truth(tmp40) { var tmp43 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_192, nil); var tmp44 *lang.Var; A_arbace_box_A_Init(); tmp44 = A_arbace_box_A_const_78; tmp39 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp43, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(cwd__9))) } else { tmp39 = nil }; var tmp45 any = /*line :324:1*/tmp39.Ref(); var tmp46 *jrt.String; var tmp47 any; var and__1927000168__auto____24_2 any = ram__10; if







	jrt.A2g_Truth(and__1927000168__auto____24_2) { tmp47 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(ram__10)).Ref() } else { tmp47 = and__1927000168__auto____24_2 }; if jrt.A2g_Truth(tmp47) { tmp46 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_193, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(ram__10)).Ref())) } else { tmp46 = nil }; var tmp48 any = /*line :324:1*/tmp46.Ref(); var tmp49 *jrt.String; var tmp50 any; var and__1927000168__auto____24_3 any = cpus__11; if








	jrt.A2g_Truth(and__1927000168__auto____24_3) { tmp50 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(cpus__11)).Ref() } else { tmp50 = and__1927000168__auto____24_3 }; if jrt.A2g_Truth(tmp50) { tmp49 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_194, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(cpus__11)).Ref())) } else { tmp49 = nil }; return /*line :324:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, image__4, nil, tmp17, tmp20, tmp33, tmp38, tmp45, tmp48, tmp49.Ref(), nil)).Ref() }
//line :322:1
func A_arbace_box_request_text_v__533000094_A_New() *A_arbace_box_request_text_v__533000094_A { A_arbace_box_request_text_v__533000094_A_Init(); t := &A_arbace_box_request_text_v__533000094_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_request_text_v__533000094_A) Invoke_O_O__O(self, xs__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_197, nil, Lit_189); var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_75; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_29; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_76; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_77; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_78; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(Lit_202, tmp9.Invoke_O_O__O(jrt.NN(tmp10).GetRawRoot__O(), xs__1))), nil)).Ref() }





func A_arbace_box_request_text_iter__533000096__533000100_A_New() *A_arbace_box_request_text_iter__533000096__533000100_A { A_arbace_box_request_text_iter__533000096__533000100_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Ctor() {}
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Invoke_O_O__O(self, s__533000097__1 any) any { var tmp1 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(self, s__533000097__1); var tmp2 *jrt.Class; A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_Init(); tmp2 = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(p0, p1 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A { A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A{}; t.Ctor_O_O(p0, p1); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Ctor_O_O(c__iter__533000096, c__s__533000097 any) { t.F_iter__533000096 = c__iter__533000096; t.F_s__533000097 = c__s__533000097 }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Invoke_O__O(self any) any { { var s__533000097__1 any; var t_ any = t.F_s__533000097; t.F_s__533000097 = nil; s__533000097__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_91; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__533000097__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__533000097__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_92; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__533000097__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_93; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__533000097__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__533000099__6 any; var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_94; b__533000099__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(b__533000099__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_Init(); tmp6 = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_97; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_100; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__533000099__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); var tmp12 *lang.Var; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_101; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__533000097__3))) } else { var tmp13 *lang.Var; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_97; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_A_Init(); tmp15 = A_arbace_box_A_const_100; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__533000099__6), nil) } } else { var vec__533000107__4 any; var tmp16 *lang.Var; A_arbace_box_A_Init(); tmp16 = A_arbace_box_A_const_98; vec__533000107__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__533000097__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__533000107__4, lang.RT_IntCast_J__I(0), nil); var h__6 any = lang.RT_Nth_O_I_O__O(vec__533000107__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_box_A_Init(); tmp17 = A_arbace_box_A_const_99; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_197, nil, Lit_198, nil, Lit_199); var tmp20 *lang.Var; A_arbace_box_A_Init(); tmp20 = A_arbace_box_A_const_78; var tmp21 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(p__5), nil, h__6, nil)).Ref(); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__533000096); var tmp23 *lang.Var; A_arbace_box_A_Init(); tmp23 = A_arbace_box_A_const_102; return tmp18.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__533000097__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :328:1
func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A { A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_Init(); t := &A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Ctor_O_I_O(c__b__533000099 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__533000099 = c__b__533000099; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :328:1
func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Invoke_O__O(self any) any { { var i__533000098__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__533000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__533000103__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__533000098__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__533000103__2, lang.RT_IntCast_J__I(0), nil); var h__4 any = lang.RT_Nth_O_I_O__O(vec__533000103__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_95; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__533000099; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_197, nil, Lit_198, nil, Lit_199); var tmp6 *lang.Var; A_arbace_box_A_Init(); tmp6 = A_arbace_box_A_const_78; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(p__3), nil, h__4, nil)).Ref()); i__533000098__1 = lang.Numbers_Unchecked_inc_J__J(i__533000098__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }







func A_arbace_box_spawn_A_New() *A_arbace_box_spawn_A { A_arbace_box_spawn_A_Init(); t := &A_arbace_box_spawn_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_box_spawn_A) Ctor() {}
//line :336:1
func (t *A_arbace_box_spawn_A) Invoke_O_O__O(self, req__0 any) any { var h__2 any; var tmp1 *lang.Var;




	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_120; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(req__0)) { var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_49; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_122; h__2 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(req__0)) } else { h__2 = req__0 }; var n__3 any; var tmp5 /*line :336:1*/*lang.Var;





	A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_121; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_38; n__3 = tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(h__2, Lit_213)); if
	lang.Numbers_IsNeg_O__Z(n__3) {
		var tmp8 *lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_15; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_21; var tmp11 any = tmp10.Ref(); var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_214, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2)).Ref(); var tmp13 *lang.Keyword; A_arbace_box_A_Init(); tmp13 = A_arbace_box_A_const_123; tmp9.Invoke_O_O_O__O(tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13.Ref(), h__2))) }; return n__3 }


func A_arbace_box_result_A_New() *A_arbace_box_result_A { A_arbace_box_result_A_Init(); t := &A_arbace_box_result_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_box_result_A) Ctor() {}
//line :347:1
func (t *A_arbace_box_result_A) Invoke_O_O__O(self, h__0 any) any { var s__2 any; var tmp1 *lang.Var;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_52; s__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(h__0); if
	lang.Util_Identical_O_O__Z(s__2, nil) {
		var tmp2 *lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_15; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_box_A_Init(); tmp4 = A_arbace_box_A_const_46; var tmp5 any = tmp4.Ref(); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_204, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(); var tmp7 *lang.Keyword; A_arbace_box_A_Init(); tmp7 = A_arbace_box_A_const_27; tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), h__0))) }; var tmp8 /*line :353:1*/*lang.Var; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_13; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_box_A_Init(); tmp10 = A_arbace_box_A_const_87; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(s__2); var tmp12 *lang.Keyword; A_arbace_box_A_Init(); tmp12 = A_arbace_box_A_const_27; return tmp9.Invoke_O_O_O__O(tmp11, tmp12.Ref(), h__0) }

func A_arbace_box_spawn_wait_A_New() *A_arbace_box_spawn_wait_A { A_arbace_box_spawn_wait_A_Init(); t := &A_arbace_box_spawn_wait_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Ctor() {}
//line :355:1
func (t *A_arbace_box_spawn_wait_A) Invoke_O_O__O(self, n__0 any) any { var h__2 any; var tmp1 any;


	A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_22; h__2 = lang.Numbers_Byte_array_O__B1(tmp1).Ref(); var tmp2 /*line :359:1*/*lang.Var; A_arbace_box_A_Init(); tmp2 = A_arbace_box_A_const_125; if lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(n__0, h__2))) { } else {
		var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_15; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_A_Init(); tmp5 = A_arbace_box_A_const_21; var tmp6 any = tmp5.Ref(); var tmp7 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_216, nil, Lit_217), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var tmp8 *lang.Keyword; A_arbace_box_A_Init(); tmp8 = A_arbace_box_A_const_126; tmp4.Invoke_O_O_O__O(tmp6, tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8.Ref(), n__0))) }; var tmp9 /*line :361:1*/*lang.Var; A_arbace_box_A_Init(); tmp9 = A_arbace_box_A_const_124; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_box_A_Init(); tmp11 = A_arbace_box_A_const_35; return tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(h__2)) }

func A_arbace_box_run_A_New() *A_arbace_box_run_A { A_arbace_box_run_A_Init(); t := &A_arbace_box_run_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_box_run_A) Ctor() {}
//line :363:1
func (t *A_arbace_box_run_A) Invoke_O_O__O(self, req__0 any) any {


	var tmp1 *lang.Var; A_arbace_box_A_Init(); tmp1 = A_arbace_box_A_const_127; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_A_Init(); tmp3 = A_arbace_box_A_const_128; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(req__0))
}














type A_arbace_box_A struct{ jrt.Object }

var A_arbace_box_A_const_0 *lang.Var

var A_arbace_box_A_const_1 *lang.Var

var A_arbace_box_A_const_2 any

var A_arbace_box_A_const_3 *lang.Keyword

var A_arbace_box_A_const_4 any

var A_arbace_box_A_const_5 any

var A_arbace_box_A_const_6 any

var A_arbace_box_A_const_7 *lang.Var

var A_arbace_box_A_const_8 *lang.Var

var A_arbace_box_A_const_9 *lang.Var

var A_arbace_box_A_const_10 any

var A_arbace_box_A_const_11 *lang.Var

var A_arbace_box_A_const_12 *lang.Var

var A_arbace_box_A_const_13 *lang.Var

var A_arbace_box_A_const_14 *lang.Keyword

var A_arbace_box_A_const_15 *lang.Var

var A_arbace_box_A_const_16 *lang.Keyword

var A_arbace_box_A_const_17 *lang.Var

var A_arbace_box_A_const_18 *lang.Keyword

var A_arbace_box_A_const_19 *lang.Keyword

var A_arbace_box_A_const_20 *lang.Keyword

var A_arbace_box_A_const_21 *lang.Keyword

var A_arbace_box_A_const_22 any

var A_arbace_box_A_const_23 *lang.Var

var A_arbace_box_A_const_24 *lang.Var

var A_arbace_box_A_const_25 any

var A_arbace_box_A_const_26 *lang.Keyword

var A_arbace_box_A_const_27 *lang.Keyword

var A_arbace_box_A_const_28 *lang.Var

var A_arbace_box_A_const_29 *lang.Var

var A_arbace_box_A_const_30 *lang.Var

var A_arbace_box_A_const_31 *lang.Var

var A_arbace_box_A_const_32 *lang.Keyword

var A_arbace_box_A_const_33 *lang.Var

var A_arbace_box_A_const_34 *lang.Var

var A_arbace_box_A_const_35 *lang.Var

var A_arbace_box_A_const_36 *lang.Var

var A_arbace_box_A_const_37 *lang.Keyword

var A_arbace_box_A_const_38 *lang.Var

var A_arbace_box_A_const_39 *lang.Var

var A_arbace_box_A_const_40 *lang.Var

var A_arbace_box_A_const_41 *lang.Var

var A_arbace_box_A_const_42 *lang.Var

var A_arbace_box_A_const_43 any

var A_arbace_box_A_const_44 any

var A_arbace_box_A_const_45 *lang.Var

var A_arbace_box_A_const_46 *lang.Keyword

var A_arbace_box_A_const_47 *lang.Var

var A_arbace_box_A_const_48 *lang.Var

var A_arbace_box_A_const_49 *lang.Var

var A_arbace_box_A_const_50 *lang.Var

var A_arbace_box_A_const_51 *lang.Var

var A_arbace_box_A_const_52 *lang.Var

var A_arbace_box_A_const_53 *lang.Var

var A_arbace_box_A_const_54 *lang.Keyword

var A_arbace_box_A_const_55 *lang.Var

var A_arbace_box_A_const_56 *lang.Var

var A_arbace_box_A_const_57 *lang.Var

var A_arbace_box_A_const_58 *lang.Var

var A_arbace_box_A_const_59 *lang.Var

var A_arbace_box_A_const_60 *lang.Var

var A_arbace_box_A_const_61 *jrt.Class

var A_arbace_box_A_const_62 any

var A_arbace_box_A_const_63 *jrt.Class

var A_arbace_box_A_const_64 *lang.Keyword

var A_arbace_box_A_const_65 *lang.Var

var A_arbace_box_A_const_66 *lang.Var

var A_arbace_box_A_const_67 *lang.Var

var A_arbace_box_A_const_68 *lang.Var

var A_arbace_box_A_const_69 *lang.Var

var A_arbace_box_A_const_70 *lang.Var

var A_arbace_box_A_const_71 any

var A_arbace_box_A_const_72 *lang.Var

var A_arbace_box_A_const_73 any

var A_arbace_box_A_const_74 any

var A_arbace_box_A_const_75 *lang.Var

var A_arbace_box_A_const_76 *lang.Var

var A_arbace_box_A_const_77 *lang.Var

var A_arbace_box_A_const_78 *lang.Var

var A_arbace_box_A_const_79 *lang.Keyword

var A_arbace_box_A_const_80 *lang.Keyword

var A_arbace_box_A_const_81 *lang.Var

var A_arbace_box_A_const_82 *lang.Keyword

var A_arbace_box_A_const_83 *lang.Var

var A_arbace_box_A_const_84 *lang.Var

var A_arbace_box_A_const_85 *lang.Var

var A_arbace_box_A_const_86 *lang.Var

var A_arbace_box_A_const_87 *lang.Var

var A_arbace_box_A_const_88 *lang.Var

var A_arbace_box_A_const_89 *lang.Var

var A_arbace_box_A_const_90 *lang.Var

var A_arbace_box_A_const_91 *lang.Var

var A_arbace_box_A_const_92 *lang.Var

var A_arbace_box_A_const_93 *lang.Var

var A_arbace_box_A_const_94 *lang.Var

var A_arbace_box_A_const_95 *lang.Var

var A_arbace_box_A_const_96 *lang.Var

var A_arbace_box_A_const_97 *lang.Var

var A_arbace_box_A_const_98 *lang.Var

var A_arbace_box_A_const_99 *lang.Var

var A_arbace_box_A_const_100 *lang.Var

var A_arbace_box_A_const_101 *lang.Var

var A_arbace_box_A_const_102 *lang.Var

var A_arbace_box_A_const_103 *lang.Var

var A_arbace_box_A_const_104 *lang.Var

var A_arbace_box_A_const_105 *lang.Var

var A_arbace_box_A_const_106 *lang.Var

var A_arbace_box_A_const_107 *lang.Var

var A_arbace_box_A_const_108 *lang.Var

var A_arbace_box_A_const_109 *lang.Var

var A_arbace_box_A_const_110 *lang.Var

var A_arbace_box_A_const_111 *lang.Var

var A_arbace_box_A_const_112 *lang.Keyword

var A_arbace_box_A_const_113 *lang.Keyword

var A_arbace_box_A_const_114 *lang.Keyword

var A_arbace_box_A_const_115 *lang.Keyword

var A_arbace_box_A_const_116 *lang.Keyword

var A_arbace_box_A_const_117 *lang.Keyword

var A_arbace_box_A_const_118 *lang.Keyword

var A_arbace_box_A_const_119 *lang.Keyword

var A_arbace_box_A_const_120 *lang.Var

var A_arbace_box_A_const_121 *lang.Var

var A_arbace_box_A_const_122 *lang.Var

var A_arbace_box_A_const_123 *lang.Keyword

var A_arbace_box_A_const_124 *lang.Var

var A_arbace_box_A_const_125 *lang.Var

var A_arbace_box_A_const_126 *lang.Keyword

var A_arbace_box_A_const_127 *lang.Var

var A_arbace_box_A_const_128 *lang.Var

var A_arbace_box_A_init jrt.ClassInit

func A_arbace_box_A_Init() { if !A_arbace_box_A_init.Done() { A_arbace_box_A_init.Run(A_arbace_box_A_clinit) } }

func A_arbace_box_A_clinit() { A_arbace_box_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_box_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_box_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_A_const_3 = lang.RT_Keyword_String_String__Keyword(nil, Lit_3); A_arbace_box_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()); A_arbace_box_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_box_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_box_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_box_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_box_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_box_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_box_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_box_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_box_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_box_A_const_14 = lang.RT_Keyword_String_String__Keyword(Lit_15, Lit_21); A_arbace_box_A_const_15 = lang.RT_Var_String_String__Var(Lit_15, Lit_22); A_arbace_box_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_23); A_arbace_box_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_box_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_box_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_box_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_box_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_box_A_const_22 = jrt.Long_ValueOf_J__Long(32).Ref(); A_arbace_box_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_box_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_box_A_const_25 = jrt.Pattern_Compile_String__Pattern(Lit_31).Ref(); A_arbace_box_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_box_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_box_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_box_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_box_A_const_30 = lang.RT_Var_String_String__Var(Lit_7, Lit_36); A_arbace_box_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_box_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_box_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_box_A_const_34 = lang.RT_Var_String_String__Var(Lit_7, Lit_40); A_arbace_box_A_const_35 = lang.RT_Var_String_String__Var(Lit_15, Lit_41); A_arbace_box_A_const_36 = lang.RT_Var_String_String__Var(Lit_15, Lit_42); A_arbace_box_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_box_A_const_38 = lang.RT_Var_String_String__Var(Lit_15, Lit_44); A_arbace_box_A_const_39 = lang.RT_Var_String_String__Var(Lit_7, Lit_43); A_arbace_box_A_const_40 = lang.RT_Var_String_String__Var(Lit_7, Lit_45); A_arbace_box_A_const_41 = lang.RT_Var_String_String__Var(Lit_15, Lit_46); A_arbace_box_A_const_42 = lang.RT_Var_String_String__Var(Lit_7, Lit_6); A_arbace_box_A_const_43 = jrt.Integer_ValueOf_I__Integer(-1).Ref(); A_arbace_box_A_const_44 = jrt.Integer_ValueOf_I__Integer(0).Ref(); A_arbace_box_A_const_45 = lang.RT_Var_String_String__Var(Lit_15, Lit_43); A_arbace_box_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_box_A_const_47 = lang.RT_Var_String_String__Var(Lit_7, Lit_48); A_arbace_box_A_const_48 = lang.RT_Var_String_String__Var(Lit_15, Lit_49); A_arbace_box_A_const_49 = lang.RT_Var_String_String__Var(Lit_15, Lit_40); A_arbace_box_A_const_50 = lang.RT_Var_String_String__Var(Lit_15, Lit_50); A_arbace_box_A_const_51 = lang.RT_Var_String_String__Var(Lit_15, Lit_6); A_arbace_box_A_const_52 = lang.RT_Var_String_String__Var(Lit_15, Lit_4); A_arbace_box_A_const_53 = lang.RT_Var_String_String__Var(Lit_15, Lit_5); A_arbace_box_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_51); A_arbace_box_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_box_A_const_56 = lang.RT_Var_String_String__Var(Lit_15, Lit_53); A_arbace_box_A_const_57 = lang.RT_Var_String_String__Var(Lit_15, Lit_54); A_arbace_box_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_box_A_const_59 = lang.RT_Var_String_String__Var(Lit_7, Lit_56); A_arbace_box_A_const_60 = lang.RT_Var_String_String__Var(Lit_15, Lit_57); A_arbace_box_A_const_61 = lang.RT_ClassForNameNonLoading_String__Class(Lit_58); A_arbace_box_A_const_62 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_box_A_const_63 = lang.RT_ClassForNameNonLoading_String__Class(Lit_59); A_arbace_box_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_box_A_const_65 = lang.RT_Var_String_String__Var(Lit_15, Lit_61); A_arbace_box_A_const_66 = lang.RT_Var_String_String__Var(Lit_7, Lit_62); A_arbace_box_A_const_67 = lang.RT_Var_String_String__Var(Lit_15, Lit_63); A_arbace_box_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_box_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_box_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_box_A_const_71 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_67, Lit_68, Lit_69)).Ref(); A_arbace_box_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_box_A_const_73 = jrt.Character_ValueOf_C__Character(47).Ref(); A_arbace_box_A_const_74 = jrt.Long_ValueOf_J__Long(127).Ref(); A_arbace_box_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_box_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_box_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_box_A_const_78 = lang.RT_Var_String_String__Var(Lit_15, Lit_74); A_arbace_box_A_const_79 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_box_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_box_A_const_81 = lang.RT_Var_String_String__Var(Lit_15, Lit_77); A_arbace_box_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_box_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_box_A_const_84 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_box_A_const_85 = lang.RT_Var_String_String__Var(Lit_15, Lit_81); A_arbace_box_A_const_86 = lang.RT_Var_String_String__Var(Lit_15, Lit_82); A_arbace_box_A_const_87 = lang.RT_Var_String_String__Var(Lit_10, Lit_83); A_arbace_box_A_const_88 = lang.RT_Var_String_String__Var(Lit_15, Lit_84); A_arbace_box_A_const_89 = lang.RT_Var_String_String__Var(Lit_15, Lit_85); A_arbace_box_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_box_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_box_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_box_A_const_93 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_box_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_box_A_const_95 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_box_A_const_96 = lang.RT_Var_String_String__Var(Lit_15, Lit_92); A_arbace_box_A_const_97 = lang.RT_Var_String_String__Var(Lit_0, Lit_93); A_arbace_box_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_box_A_const_99 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_box_A_const_100 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_box_A_const_101 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_box_A_const_102 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_box_A_const_103 = lang.RT_Var_String_String__Var(Lit_15, Lit_99); A_arbace_box_A_const_104 = lang.RT_Var_String_String__Var(Lit_15, Lit_100); A_arbace_box_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_box_A_const_106 = lang.RT_Var_String_String__Var(Lit_0, Lit_102); A_arbace_box_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_103); A_arbace_box_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_box_A_const_109 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_box_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_box_A_const_111 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_box_A_const_112 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_box_A_const_113 = lang.RT_Keyword_String_String__Keyword(nil, Lit_109); A_arbace_box_A_const_114 = lang.RT_Keyword_String_String__Keyword(nil, Lit_110); A_arbace_box_A_const_115 = lang.RT_Keyword_String_String__Keyword(nil, Lit_111); A_arbace_box_A_const_116 = lang.RT_Keyword_String_String__Keyword(nil, Lit_112); A_arbace_box_A_const_117 = lang.RT_Keyword_String_String__Keyword(nil, Lit_113); A_arbace_box_A_const_118 = lang.RT_Keyword_String_String__Keyword(nil, Lit_114); A_arbace_box_A_const_119 = lang.RT_Keyword_String_String__Keyword(nil, Lit_115); A_arbace_box_A_const_120 = lang.RT_Var_String_String__Var(Lit_0, Lit_116); A_arbace_box_A_const_121 = lang.RT_Var_String_String__Var(Lit_7, Lit_117); A_arbace_box_A_const_122 = lang.RT_Var_String_String__Var(Lit_15, Lit_118); A_arbace_box_A_const_123 = lang.RT_Keyword_String_String__Keyword(nil, Lit_119); A_arbace_box_A_const_124 = lang.RT_Var_String_String__Var(Lit_15, Lit_120); A_arbace_box_A_const_125 = lang.RT_Var_String_String__Var(Lit_7, Lit_121); A_arbace_box_A_const_126 = lang.RT_Keyword_String_String__Keyword(nil, Lit_117); A_arbace_box_A_const_127 = lang.RT_Var_String_String__Var(Lit_15, Lit_122); A_arbace_box_A_const_128 = lang.RT_Var_String_String__Var(Lit_15, Lit_117) }

func A_arbace_box_A_New() *A_arbace_box_A { A_arbace_box_A_Init(); t := &A_arbace_box_A{}; t.Ctor(); return t }

func (t *A_arbace_box_A) Ctor() {}

func (t *A_arbace_box_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_A) GetClass__Class() *jrt.Class { return A_arbace_box_A_class }

func (t *A_arbace_box_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_A); return ok }

func A_arbace_box_A_Cast(x any) *A_arbace_box_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_A_class)) }; return v }



type A_arbace_box_answer_A struct{ jrt.Object }

func (t *A_arbace_box_answer_A) Is_Compiler_AOTF3() {}

var A_arbace_box_answer_A_fn_class *jrt.Class

var A_arbace_box_answer_A_init jrt.ClassInit

func A_arbace_box_answer_A_Init() { if !A_arbace_box_answer_A_init.Done() { A_arbace_box_answer_A_init.Run(A_arbace_box_answer_A_clinit) } }

func A_arbace_box_answer_A_clinit() { A_arbace_box_answer_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_answer_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_answer_A) GetClass__Class() *jrt.Class { return A_arbace_box_answer_A_class }

func (t *A_arbace_box_answer_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_answer_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_answer_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_answer_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_answer_A); return ok }

func A_arbace_box_answer_A_Cast(x any) *A_arbace_box_answer_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_answer_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_answer_A_class)) }; return v }



type A_arbace_box_boxed_QMARK__A struct{ jrt.Object }

func (t *A_arbace_box_boxed_QMARK__A) Is_Compiler_AOTF0() {}

var A_arbace_box_boxed_QMARK__A_fn_class *jrt.Class

var A_arbace_box_boxed_QMARK__A_init jrt.ClassInit

func A_arbace_box_boxed_QMARK__A_Init() { if !A_arbace_box_boxed_QMARK__A_init.Done() { A_arbace_box_boxed_QMARK__A_init.Run(A_arbace_box_boxed_QMARK__A_clinit) } }

func A_arbace_box_boxed_QMARK__A_clinit() { A_arbace_box_boxed_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_boxed_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_boxed_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_box_boxed_QMARK__A_class }

func (t *A_arbace_box_boxed_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_boxed_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_boxed_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_boxed_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_boxed_QMARK__A); return ok }

func A_arbace_box_boxed_QMARK__A_Cast(x any) *A_arbace_box_boxed_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_boxed_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_boxed_QMARK__A_class)) }; return v }



type A_arbace_box_eval533000004_A struct{ jrt.Object }

func A_arbace_box_eval533000004_A_New() *A_arbace_box_eval533000004_A { t := &A_arbace_box_eval533000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000004_A) Ctor() {}

func (t *A_arbace_box_eval533000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000004_A_class }

func (t *A_arbace_box_eval533000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000004_A); return ok }

func A_arbace_box_eval533000004_A_Cast(x any) *A_arbace_box_eval533000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000004_A_class)) }; return v }



type A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A struct{ jrt.Object }

func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Is_Compiler_AOTF0() {}

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_fn_class *jrt.Class

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_init jrt.ClassInit

func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_Init() { if !A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_init.Done() { A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_init.Run(A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_clinit) } }

func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_clinit() { A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_class }

func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A); return ok }

func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_Cast(x any) *A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_class)) }; return v }



type A_arbace_box_eval533000008_A struct{ jrt.Object }

func A_arbace_box_eval533000008_A_New() *A_arbace_box_eval533000008_A { t := &A_arbace_box_eval533000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_eval533000008_A) Ctor() {}

func (t *A_arbace_box_eval533000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000008_A_class }

func (t *A_arbace_box_eval533000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000008_A); return ok }

func A_arbace_box_eval533000008_A_Cast(x any) *A_arbace_box_eval533000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000008_A_class)) }; return v }



type A_arbace_box_eval533000008_fn__533000009_A struct{ jrt.Object }

func (t *A_arbace_box_eval533000008_fn__533000009_A) Is_Compiler_AOTF0() {}

var A_arbace_box_eval533000008_fn__533000009_A_fn_class *jrt.Class

var A_arbace_box_eval533000008_fn__533000009_A_init jrt.ClassInit

func A_arbace_box_eval533000008_fn__533000009_A_Init() { if !A_arbace_box_eval533000008_fn__533000009_A_init.Done() { A_arbace_box_eval533000008_fn__533000009_A_init.Run(A_arbace_box_eval533000008_fn__533000009_A_clinit) } }

func A_arbace_box_eval533000008_fn__533000009_A_clinit() { A_arbace_box_eval533000008_fn__533000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_eval533000008_fn__533000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_eval533000008_fn__533000009_A) GetClass__Class() *jrt.Class { return A_arbace_box_eval533000008_fn__533000009_A_class }

func (t *A_arbace_box_eval533000008_fn__533000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_eval533000008_fn__533000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_eval533000008_fn__533000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_eval533000008_fn__533000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_eval533000008_fn__533000009_A); return ok }

func A_arbace_box_eval533000008_fn__533000009_A_Cast(x any) *A_arbace_box_eval533000008_fn__533000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_eval533000008_fn__533000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_eval533000008_fn__533000009_A_class)) }; return v }



type A_arbace_box_fail_A struct{ jrt.Object }

func (t *A_arbace_box_fail_A) Is_Compiler_AOTF3() {}

var A_arbace_box_fail_A_fn_class *jrt.Class

var A_arbace_box_fail_A_init jrt.ClassInit

func A_arbace_box_fail_A_Init() { if !A_arbace_box_fail_A_init.Done() { A_arbace_box_fail_A_init.Run(A_arbace_box_fail_A_clinit) } }

func A_arbace_box_fail_A_clinit() { A_arbace_box_fail_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_fail_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_fail_A) GetClass__Class() *jrt.Class { return A_arbace_box_fail_A_class }

func (t *A_arbace_box_fail_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_fail_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_fail_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_fail_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_fail_A); return ok }

func A_arbace_box_fail_A_Cast(x any) *A_arbace_box_fail_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_fail_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_fail_A_class)) }; return v }



type A_arbace_box_fs_dir_A struct{ jrt.Object }

func (t *A_arbace_box_fs_dir_A) Is_Compiler_AOTF2() {}

var A_arbace_box_fs_dir_A_fn_class *jrt.Class

var A_arbace_box_fs_dir_A_init jrt.ClassInit

func A_arbace_box_fs_dir_A_Init() { if !A_arbace_box_fs_dir_A_init.Done() { A_arbace_box_fs_dir_A_init.Run(A_arbace_box_fs_dir_A_clinit) } }

func A_arbace_box_fs_dir_A_clinit() { A_arbace_box_fs_dir_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_fs_dir_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_fs_dir_A) GetClass__Class() *jrt.Class { return A_arbace_box_fs_dir_A_class }

func (t *A_arbace_box_fs_dir_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_fs_dir_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_fs_dir_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_fs_dir_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_fs_dir_A); return ok }

func A_arbace_box_fs_dir_A_Cast(x any) *A_arbace_box_fs_dir_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_fs_dir_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_fs_dir_A_class)) }; return v }



type A_arbace_box_get_A struct{ jrt.Object }

func (t *A_arbace_box_get_A) Is_Compiler_AOTF1() {}

var A_arbace_box_get_A_fn_class *jrt.Class

var A_arbace_box_get_A_init jrt.ClassInit

func A_arbace_box_get_A_Init() { if !A_arbace_box_get_A_init.Done() { A_arbace_box_get_A_init.Run(A_arbace_box_get_A_clinit) } }

func A_arbace_box_get_A_clinit() { A_arbace_box_get_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_get_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_get_A) GetClass__Class() *jrt.Class { return A_arbace_box_get_A_class }

func (t *A_arbace_box_get_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_get_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_get_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_get_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_get_A); return ok }

func A_arbace_box_get_A_Cast(x any) *A_arbace_box_get_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_get_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_get_A_class)) }; return v }



type A_arbace_box_get_bytes_A struct{ jrt.Object }

func (t *A_arbace_box_get_bytes_A) Is_Compiler_AOTF1() {}

var A_arbace_box_get_bytes_A_fn_class *jrt.Class

var A_arbace_box_get_bytes_A_init jrt.ClassInit

func A_arbace_box_get_bytes_A_Init() { if !A_arbace_box_get_bytes_A_init.Done() { A_arbace_box_get_bytes_A_init.Run(A_arbace_box_get_bytes_A_clinit) } }

func A_arbace_box_get_bytes_A_clinit() { A_arbace_box_get_bytes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_get_bytes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_get_bytes_A) GetClass__Class() *jrt.Class { return A_arbace_box_get_bytes_A_class }

func (t *A_arbace_box_get_bytes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_get_bytes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_get_bytes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_get_bytes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_get_bytes_A); return ok }

func A_arbace_box_get_bytes_A_Cast(x any) *A_arbace_box_get_bytes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_get_bytes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_get_bytes_A_class)) }; return v }



type A_arbace_box_get_tree_A struct{ jrt.Object }

func (t *A_arbace_box_get_tree_A) Is_Compiler_AOTF2() {}

var A_arbace_box_get_tree_A_fn_class *jrt.Class

var A_arbace_box_get_tree_A_init jrt.ClassInit

func A_arbace_box_get_tree_A_Init() { if !A_arbace_box_get_tree_A_init.Done() { A_arbace_box_get_tree_A_init.Run(A_arbace_box_get_tree_A_clinit) } }

func A_arbace_box_get_tree_A_clinit() { A_arbace_box_get_tree_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_get_tree_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_get_tree_A) GetClass__Class() *jrt.Class { return A_arbace_box_get_tree_A_class }

func (t *A_arbace_box_get_tree_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_get_tree_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_get_tree_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_get_tree_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_get_tree_A); return ok }

func A_arbace_box_get_tree_A_Cast(x any) *A_arbace_box_get_tree_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_get_tree_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_get_tree_A_class)) }; return v }



type A_arbace_box_get_tree_fn__533000077_A struct{ jrt.Object; F_o, F_eh any }

func (t *A_arbace_box_get_tree_fn__533000077_A) Is_Compiler_AOTF0() {}

var A_arbace_box_get_tree_fn__533000077_A_fn_class *jrt.Class

var A_arbace_box_get_tree_fn__533000077_A_init jrt.ClassInit

func A_arbace_box_get_tree_fn__533000077_A_Init() { if !A_arbace_box_get_tree_fn__533000077_A_init.Done() { A_arbace_box_get_tree_fn__533000077_A_init.Run(A_arbace_box_get_tree_fn__533000077_A_clinit) } }

func A_arbace_box_get_tree_fn__533000077_A_clinit() { A_arbace_box_get_tree_fn__533000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_get_tree_fn__533000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_get_tree_fn__533000077_A) GetClass__Class() *jrt.Class { return A_arbace_box_get_tree_fn__533000077_A_class }

func (t *A_arbace_box_get_tree_fn__533000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_get_tree_fn__533000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_get_tree_fn__533000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_get_tree_fn__533000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_get_tree_fn__533000077_A); return ok }

func A_arbace_box_get_tree_fn__533000077_A_Cast(x any) *A_arbace_box_get_tree_fn__533000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_get_tree_fn__533000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_get_tree_fn__533000077_A_class)) }; return v }



type A_arbace_box_get_tree_fn__533000085_A struct{ jrt.Object; F_eh, F_o any }

func (t *A_arbace_box_get_tree_fn__533000085_A) Is_Compiler_AOTF0() {}

var A_arbace_box_get_tree_fn__533000085_A_fn_class *jrt.Class

var A_arbace_box_get_tree_fn__533000085_A_init jrt.ClassInit

func A_arbace_box_get_tree_fn__533000085_A_Init() { if !A_arbace_box_get_tree_fn__533000085_A_init.Done() { A_arbace_box_get_tree_fn__533000085_A_init.Run(A_arbace_box_get_tree_fn__533000085_A_clinit) } }

func A_arbace_box_get_tree_fn__533000085_A_clinit() { A_arbace_box_get_tree_fn__533000085_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_get_tree_fn__533000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_get_tree_fn__533000085_A) GetClass__Class() *jrt.Class { return A_arbace_box_get_tree_fn__533000085_A_class }

func (t *A_arbace_box_get_tree_fn__533000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_get_tree_fn__533000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_get_tree_fn__533000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_get_tree_fn__533000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_get_tree_fn__533000085_A); return ok }

func A_arbace_box_get_tree_fn__533000085_A_Cast(x any) *A_arbace_box_get_tree_fn__533000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_get_tree_fn__533000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_get_tree_fn__533000085_A_class)) }; return v }



type A_arbace_box_hash_bytes_A struct{ jrt.Object }

func (t *A_arbace_box_hash_bytes_A) Is_Compiler_AOTF2() {}

var A_arbace_box_hash_bytes_A_fn_class *jrt.Class

var A_arbace_box_hash_bytes_A_init jrt.ClassInit

func A_arbace_box_hash_bytes_A_Init() { if !A_arbace_box_hash_bytes_A_init.Done() { A_arbace_box_hash_bytes_A_init.Run(A_arbace_box_hash_bytes_A_clinit) } }

func A_arbace_box_hash_bytes_A_clinit() { A_arbace_box_hash_bytes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_hash_bytes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_hash_bytes_A) GetClass__Class() *jrt.Class { return A_arbace_box_hash_bytes_A_class }

func (t *A_arbace_box_hash_bytes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_hash_bytes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_hash_bytes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_hash_bytes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_hash_bytes_A); return ok }

func A_arbace_box_hash_bytes_A_Cast(x any) *A_arbace_box_hash_bytes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_hash_bytes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_hash_bytes_A_class)) }; return v }



type A_arbace_box_hex_A struct{ jrt.Object }

func (t *A_arbace_box_hex_A) Is_Compiler_AOTF1() {}

var A_arbace_box_hex_A_fn_class *jrt.Class

var A_arbace_box_hex_A_init jrt.ClassInit

func A_arbace_box_hex_A_Init() { if !A_arbace_box_hex_A_init.Done() { A_arbace_box_hex_A_init.Run(A_arbace_box_hex_A_clinit) } }

func A_arbace_box_hex_A_clinit() { A_arbace_box_hex_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_150, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_hex_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_hex_A) GetClass__Class() *jrt.Class { return A_arbace_box_hex_A_class }

func (t *A_arbace_box_hex_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_hex_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_hex_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_hex_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_hex_A); return ok }

func A_arbace_box_hex_A_Cast(x any) *A_arbace_box_hex_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_hex_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_hex_A_class)) }; return v }



type A_arbace_box_load_A struct{ jrt.Object }

func (t *A_arbace_box_load_A) Is_Compiler_AOTF1() {}

var A_arbace_box_load_A_fn_class *jrt.Class

var A_arbace_box_load_A_init jrt.ClassInit

func A_arbace_box_load_A_Init() { if !A_arbace_box_load_A_init.Done() { A_arbace_box_load_A_init.Run(A_arbace_box_load_A_clinit) } }

func A_arbace_box_load_A_clinit() { A_arbace_box_load_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_151, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_load_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_load_A) GetClass__Class() *jrt.Class { return A_arbace_box_load_A_class }

func (t *A_arbace_box_load_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_load_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_load_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_load_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_load_A); return ok }

func A_arbace_box_load_A_Cast(x any) *A_arbace_box_load_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_load_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_load_A_class)) }; return v }



type A_arbace_box_load_fs_BANG__A struct{ jrt.Object }

func (t *A_arbace_box_load_fs_BANG__A) Is_Compiler_AOTF2() {}

func (t *A_arbace_box_load_fs_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_box_load_fs_BANG__A_fn_class *jrt.Class

var A_arbace_box_load_fs_BANG__A_init jrt.ClassInit

func A_arbace_box_load_fs_BANG__A_Init() { if !A_arbace_box_load_fs_BANG__A_init.Done() { A_arbace_box_load_fs_BANG__A_init.Run(A_arbace_box_load_fs_BANG__A_clinit) } }

func A_arbace_box_load_fs_BANG__A_clinit() { A_arbace_box_load_fs_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_152, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_load_fs_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_load_fs_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_box_load_fs_BANG__A_class }

func (t *A_arbace_box_load_fs_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_load_fs_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_load_fs_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_load_fs_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_load_fs_BANG__A); return ok }

func A_arbace_box_load_fs_BANG__A_Cast(x any) *A_arbace_box_load_fs_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_load_fs_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_load_fs_BANG__A_class)) }; return v }



type A_arbace_box_load_ref_A struct{ jrt.Object }

func (t *A_arbace_box_load_ref_A) Is_Compiler_AOTF1() {}

var A_arbace_box_load_ref_A_fn_class *jrt.Class

var A_arbace_box_load_ref_A_init jrt.ClassInit

func A_arbace_box_load_ref_A_Init() { if !A_arbace_box_load_ref_A_init.Done() { A_arbace_box_load_ref_A_init.Run(A_arbace_box_load_ref_A_clinit) } }

func A_arbace_box_load_ref_A_clinit() { A_arbace_box_load_ref_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_load_ref_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_load_ref_A) GetClass__Class() *jrt.Class { return A_arbace_box_load_ref_A_class }

func (t *A_arbace_box_load_ref_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_load_ref_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_load_ref_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_load_ref_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_load_ref_A); return ok }

func A_arbace_box_load_ref_A_Cast(x any) *A_arbace_box_load_ref_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_load_ref_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_load_ref_A_class)) }; return v }



type A_arbace_box_put_A struct{ jrt.Object }

func (t *A_arbace_box_put_A) Is_Compiler_AOTF1() {}

var A_arbace_box_put_A_fn_class *jrt.Class

var A_arbace_box_put_A_init jrt.ClassInit

func A_arbace_box_put_A_Init() { if !A_arbace_box_put_A_init.Done() { A_arbace_box_put_A_init.Run(A_arbace_box_put_A_clinit) } }

func A_arbace_box_put_A_clinit() { A_arbace_box_put_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_A) GetClass__Class() *jrt.Class { return A_arbace_box_put_A_class }

func (t *A_arbace_box_put_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_A); return ok }

func A_arbace_box_put_A_Cast(x any) *A_arbace_box_put_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_A_class)) }; return v }



type A_arbace_box_put_BANG__A struct{ jrt.Object }

func (t *A_arbace_box_put_BANG__A) Is_Compiler_AOTF2() {}

var A_arbace_box_put_BANG__A_fn_class *jrt.Class

var A_arbace_box_put_BANG__A_init jrt.ClassInit

func A_arbace_box_put_BANG__A_Init() { if !A_arbace_box_put_BANG__A_init.Done() { A_arbace_box_put_BANG__A_init.Run(A_arbace_box_put_BANG__A_clinit) } }

func A_arbace_box_put_BANG__A_clinit() { A_arbace_box_put_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_box_put_BANG__A_class }

func (t *A_arbace_box_put_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_BANG__A); return ok }

func A_arbace_box_put_BANG__A_Cast(x any) *A_arbace_box_put_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_BANG__A_class)) }; return v }



type A_arbace_box_put_dir_A struct{ jrt.Object }

func (t *A_arbace_box_put_dir_A) Is_Compiler_AOTF1() {}

var A_arbace_box_put_dir_A_fn_class *jrt.Class

var A_arbace_box_put_dir_A_init jrt.ClassInit

func A_arbace_box_put_dir_A_Init() { if !A_arbace_box_put_dir_A_init.Done() { A_arbace_box_put_dir_A_init.Run(A_arbace_box_put_dir_A_clinit) } }

func A_arbace_box_put_dir_A_clinit() { A_arbace_box_put_dir_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_dir_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_dir_A) GetClass__Class() *jrt.Class { return A_arbace_box_put_dir_A_class }

func (t *A_arbace_box_put_dir_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_dir_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_dir_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_dir_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_dir_A); return ok }

func A_arbace_box_put_dir_A_Cast(x any) *A_arbace_box_put_dir_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_dir_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_dir_A_class)) }; return v }



type A_arbace_box_put_dir_iter__533000056__533000060_A struct{ jrt.Object }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Is_Compiler_AOTF1() {}

var A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class *jrt.Class

var A_arbace_box_put_dir_iter__533000056__533000060_A_init jrt.ClassInit

func A_arbace_box_put_dir_iter__533000056__533000060_A_Init() { if !A_arbace_box_put_dir_iter__533000056__533000060_A_init.Done() { A_arbace_box_put_dir_iter__533000056__533000060_A_init.Run(A_arbace_box_put_dir_iter__533000056__533000060_A_clinit) } }

func A_arbace_box_put_dir_iter__533000056__533000060_A_clinit() { A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) GetClass__Class() *jrt.Class { return A_arbace_box_put_dir_iter__533000056__533000060_A_class }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_dir_iter__533000056__533000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_dir_iter__533000056__533000060_A); return ok }

func A_arbace_box_put_dir_iter__533000056__533000060_A_Cast(x any) *A_arbace_box_put_dir_iter__533000056__533000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_dir_iter__533000056__533000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_dir_iter__533000056__533000060_A_class)) }; return v }



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A struct{ jrt.Object; F_s__533000057, F_iter__533000056 any }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Is_Compiler_AOTF0() {}

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class *jrt.Class

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_init jrt.ClassInit

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_Init() { if !A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_init.Done() { A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_init.Run(A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_clinit) } }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_clinit() { A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) GetClass__Class() *jrt.Class { return A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A); return ok }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_Cast(x any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class)) }; return v }



type A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A struct{ jrt.Object; F_b__533000059 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Is_Compiler_AOTF0() {}

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class *jrt.Class

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_init jrt.ClassInit

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_Init() { if !A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_init.Done() { A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_init.Run(A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_clinit) } }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_clinit() { A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) GetClass__Class() *jrt.Class { return A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_class }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A); return ok }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_Cast(x any) *A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_class)) }; return v }



type A_arbace_box_put_file_A struct{ jrt.Object }

func (t *A_arbace_box_put_file_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_box_put_file_A) Is_Compiler_AOTF1() {}

var A_arbace_box_put_file_A_fn_class *jrt.Class

var A_arbace_box_put_file_A_init jrt.ClassInit

func A_arbace_box_put_file_A_Init() { if !A_arbace_box_put_file_A_init.Done() { A_arbace_box_put_file_A_init.Run(A_arbace_box_put_file_A_clinit) } }

func A_arbace_box_put_file_A_clinit() { A_arbace_box_put_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_file_A) GetClass__Class() *jrt.Class { return A_arbace_box_put_file_A_class }

func (t *A_arbace_box_put_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_file_A); return ok }

func A_arbace_box_put_file_A_Cast(x any) *A_arbace_box_put_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_file_A_class)) }; return v }



type A_arbace_box_put_tree_A struct{ jrt.Object }

func (t *A_arbace_box_put_tree_A) Is_Compiler_AOTF1() {}

var A_arbace_box_put_tree_A_fn_class *jrt.Class

var A_arbace_box_put_tree_A_init jrt.ClassInit

func A_arbace_box_put_tree_A_Init() { if !A_arbace_box_put_tree_A_init.Done() { A_arbace_box_put_tree_A_init.Run(A_arbace_box_put_tree_A_clinit) } }

func A_arbace_box_put_tree_A_clinit() { A_arbace_box_put_tree_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_put_tree_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_put_tree_A) GetClass__Class() *jrt.Class { return A_arbace_box_put_tree_A_class }

func (t *A_arbace_box_put_tree_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_put_tree_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_put_tree_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_put_tree_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_put_tree_A); return ok }

func A_arbace_box_put_tree_A_Cast(x any) *A_arbace_box_put_tree_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_put_tree_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_put_tree_A_class)) }; return v }



type A_arbace_box_quote_str_A struct{ jrt.Object }

func (t *A_arbace_box_quote_str_A) Is_Compiler_AOTF1() {}

var A_arbace_box_quote_str_A_fn_class *jrt.Class

var A_arbace_box_quote_str_A_init jrt.ClassInit

func A_arbace_box_quote_str_A_Init() { if !A_arbace_box_quote_str_A_init.Done() { A_arbace_box_quote_str_A_init.Run(A_arbace_box_quote_str_A_clinit) } }

func A_arbace_box_quote_str_A_clinit() { A_arbace_box_quote_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_quote_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_quote_str_A) GetClass__Class() *jrt.Class { return A_arbace_box_quote_str_A_class }

func (t *A_arbace_box_quote_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_quote_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_quote_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_quote_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_quote_str_A); return ok }

func A_arbace_box_quote_str_A_Cast(x any) *A_arbace_box_quote_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_quote_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_quote_str_A_class)) }; return v }



type A_arbace_box_ref_A struct{ jrt.Object }

func (t *A_arbace_box_ref_A) Is_Compiler_AOTF1() {}

var A_arbace_box_ref_A_fn_class *jrt.Class

var A_arbace_box_ref_A_init jrt.ClassInit

func A_arbace_box_ref_A_Init() { if !A_arbace_box_ref_A_init.Done() { A_arbace_box_ref_A_init.Run(A_arbace_box_ref_A_clinit) } }

func A_arbace_box_ref_A_clinit() { A_arbace_box_ref_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_176, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_ref_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_ref_A) GetClass__Class() *jrt.Class { return A_arbace_box_ref_A_class }

func (t *A_arbace_box_ref_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_ref_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_ref_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_ref_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_ref_A); return ok }

func A_arbace_box_ref_A_Cast(x any) *A_arbace_box_ref_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_ref_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_ref_A_class)) }; return v }



type A_arbace_box_ref_BANG__A struct{ jrt.Object }

func (t *A_arbace_box_ref_BANG__A) Is_Compiler_AOTF3() {}

func (t *A_arbace_box_ref_BANG__A) Is_Compiler_AOTF2() {}

var A_arbace_box_ref_BANG__A_fn_class *jrt.Class

var A_arbace_box_ref_BANG__A_init jrt.ClassInit

func A_arbace_box_ref_BANG__A_Init() { if !A_arbace_box_ref_BANG__A_init.Done() { A_arbace_box_ref_BANG__A_init.Run(A_arbace_box_ref_BANG__A_clinit) } }

func A_arbace_box_ref_BANG__A_clinit() { A_arbace_box_ref_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_178, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_ref_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_ref_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_box_ref_BANG__A_class }

func (t *A_arbace_box_ref_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_ref_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_ref_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_ref_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_ref_BANG__A); return ok }

func A_arbace_box_ref_BANG__A_Cast(x any) *A_arbace_box_ref_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_ref_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_ref_BANG__A_class)) }; return v }



type A_arbace_box_ref_BANG__answer_A struct{ jrt.Object }

func (t *A_arbace_box_ref_BANG__answer_A) Is_Compiler_AOTF3() {}

var A_arbace_box_ref_BANG__answer_A_fn_class *jrt.Class

var A_arbace_box_ref_BANG__answer_A_init jrt.ClassInit

func A_arbace_box_ref_BANG__answer_A_Init() { if !A_arbace_box_ref_BANG__answer_A_init.Done() { A_arbace_box_ref_BANG__answer_A_init.Run(A_arbace_box_ref_BANG__answer_A_clinit) } }

func A_arbace_box_ref_BANG__answer_A_clinit() { A_arbace_box_ref_BANG__answer_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_ref_BANG__answer_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_ref_BANG__answer_A) GetClass__Class() *jrt.Class { return A_arbace_box_ref_BANG__answer_A_class }

func (t *A_arbace_box_ref_BANG__answer_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_ref_BANG__answer_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_ref_BANG__answer_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_ref_BANG__answer_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_ref_BANG__answer_A); return ok }

func A_arbace_box_ref_BANG__answer_A_Cast(x any) *A_arbace_box_ref_BANG__answer_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_ref_BANG__answer_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_ref_BANG__answer_A_class)) }; return v }



type A_arbace_box_request_text_A struct{ jrt.Object }

func (t *A_arbace_box_request_text_A) Is_Compiler_AOTF1() {}

var A_arbace_box_request_text_A_fn_class *jrt.Class

var A_arbace_box_request_text_A_init jrt.ClassInit

func A_arbace_box_request_text_A_Init() { if !A_arbace_box_request_text_A_init.Done() { A_arbace_box_request_text_A_init.Run(A_arbace_box_request_text_A_clinit) } }

func A_arbace_box_request_text_A_clinit() { A_arbace_box_request_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_request_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_request_text_A) GetClass__Class() *jrt.Class { return A_arbace_box_request_text_A_class }

func (t *A_arbace_box_request_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_request_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_request_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_request_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_request_text_A); return ok }

func A_arbace_box_request_text_A_Cast(x any) *A_arbace_box_request_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_request_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_request_text_A_class)) }; return v }



type A_arbace_box_request_text_iter__533000096__533000100_A struct{ jrt.Object }

func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Is_Compiler_AOTF1() {}

var A_arbace_box_request_text_iter__533000096__533000100_A_fn_class *jrt.Class

var A_arbace_box_request_text_iter__533000096__533000100_A_init jrt.ClassInit

func A_arbace_box_request_text_iter__533000096__533000100_A_Init() { if !A_arbace_box_request_text_iter__533000096__533000100_A_init.Done() { A_arbace_box_request_text_iter__533000096__533000100_A_init.Run(A_arbace_box_request_text_iter__533000096__533000100_A_clinit) } }

func A_arbace_box_request_text_iter__533000096__533000100_A_clinit() { A_arbace_box_request_text_iter__533000096__533000100_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_195, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_request_text_iter__533000096__533000100_A) GetClass__Class() *jrt.Class { return A_arbace_box_request_text_iter__533000096__533000100_A_class }

func (t *A_arbace_box_request_text_iter__533000096__533000100_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_request_text_iter__533000096__533000100_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_request_text_iter__533000096__533000100_A); return ok }

func A_arbace_box_request_text_iter__533000096__533000100_A_Cast(x any) *A_arbace_box_request_text_iter__533000096__533000100_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_request_text_iter__533000096__533000100_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_request_text_iter__533000096__533000100_A_class)) }; return v }



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A struct{ jrt.Object; F_iter__533000096, F_s__533000097 any }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Is_Compiler_AOTF0() {}

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class *jrt.Class

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_init jrt.ClassInit

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_Init() { if !A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_init.Done() { A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_init.Run(A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_clinit) } }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_clinit() { A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) GetClass__Class() *jrt.Class { return A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A); return ok }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_Cast(x any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class)) }; return v }



type A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A struct{ jrt.Object; F_b__533000099 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Is_Compiler_AOTF0() {}

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class *jrt.Class

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_init jrt.ClassInit

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_Init() { if !A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_init.Done() { A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_init.Run(A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_clinit) } }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_clinit() { A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) GetClass__Class() *jrt.Class { return A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_class }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A); return ok }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_Cast(x any) *A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_class)) }; return v }



type A_arbace_box_request_text_v__533000094_A struct{ jrt.Object }

func (t *A_arbace_box_request_text_v__533000094_A) Is_Compiler_AOTF1() {}

var A_arbace_box_request_text_v__533000094_A_fn_class *jrt.Class

var A_arbace_box_request_text_v__533000094_A_init jrt.ClassInit

func A_arbace_box_request_text_v__533000094_A_Init() { if !A_arbace_box_request_text_v__533000094_A_init.Done() { A_arbace_box_request_text_v__533000094_A_init.Run(A_arbace_box_request_text_v__533000094_A_clinit) } }

func A_arbace_box_request_text_v__533000094_A_clinit() { A_arbace_box_request_text_v__533000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_request_text_v__533000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_request_text_v__533000094_A) GetClass__Class() *jrt.Class { return A_arbace_box_request_text_v__533000094_A_class }

func (t *A_arbace_box_request_text_v__533000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_request_text_v__533000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_request_text_v__533000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_request_text_v__533000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_request_text_v__533000094_A); return ok }

func A_arbace_box_request_text_v__533000094_A_Cast(x any) *A_arbace_box_request_text_v__533000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_request_text_v__533000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_request_text_v__533000094_A_class)) }; return v }



type A_arbace_box_result_A struct{ jrt.Object }

func (t *A_arbace_box_result_A) Is_Compiler_AOTF1() {}

var A_arbace_box_result_A_fn_class *jrt.Class

var A_arbace_box_result_A_init jrt.ClassInit

func A_arbace_box_result_A_Init() { if !A_arbace_box_result_A_init.Done() { A_arbace_box_result_A_init.Run(A_arbace_box_result_A_clinit) } }

func A_arbace_box_result_A_clinit() { A_arbace_box_result_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_result_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_result_A) GetClass__Class() *jrt.Class { return A_arbace_box_result_A_class }

func (t *A_arbace_box_result_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_result_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_result_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_result_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_result_A); return ok }

func A_arbace_box_result_A_Cast(x any) *A_arbace_box_result_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_result_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_result_A_class)) }; return v }



type A_arbace_box_run_A struct{ jrt.Object }

func (t *A_arbace_box_run_A) Is_Compiler_AOTF1() {}

var A_arbace_box_run_A_fn_class *jrt.Class

var A_arbace_box_run_A_init jrt.ClassInit

func A_arbace_box_run_A_Init() { if !A_arbace_box_run_A_init.Done() { A_arbace_box_run_A_init.Run(A_arbace_box_run_A_clinit) } }

func A_arbace_box_run_A_clinit() { A_arbace_box_run_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_run_A) GetClass__Class() *jrt.Class { return A_arbace_box_run_A_class }

func (t *A_arbace_box_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_run_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_run_A); return ok }

func A_arbace_box_run_A_Cast(x any) *A_arbace_box_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_run_A_class)) }; return v }



type A_arbace_box_save_fs_BANG__A struct{ jrt.Object }

func (t *A_arbace_box_save_fs_BANG__A) Is_Compiler_AOTF2() {}

func (t *A_arbace_box_save_fs_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_box_save_fs_BANG__A_fn_class *jrt.Class

var A_arbace_box_save_fs_BANG__A_init jrt.ClassInit

func A_arbace_box_save_fs_BANG__A_Init() { if !A_arbace_box_save_fs_BANG__A_init.Done() { A_arbace_box_save_fs_BANG__A_init.Run(A_arbace_box_save_fs_BANG__A_clinit) } }

func A_arbace_box_save_fs_BANG__A_clinit() { A_arbace_box_save_fs_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_save_fs_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_save_fs_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_box_save_fs_BANG__A_class }

func (t *A_arbace_box_save_fs_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_save_fs_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_save_fs_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_save_fs_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_save_fs_BANG__A); return ok }

func A_arbace_box_save_fs_BANG__A_Cast(x any) *A_arbace_box_save_fs_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_save_fs_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_save_fs_BANG__A_class)) }; return v }



type A_arbace_box_size_A struct{ jrt.Object }

func (t *A_arbace_box_size_A) Is_Compiler_AOTF1() {}

var A_arbace_box_size_A_fn_class *jrt.Class

var A_arbace_box_size_A_init jrt.ClassInit

func A_arbace_box_size_A_Init() { if !A_arbace_box_size_A_init.Done() { A_arbace_box_size_A_init.Run(A_arbace_box_size_A_clinit) } }

func A_arbace_box_size_A_clinit() { A_arbace_box_size_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_size_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_size_A) GetClass__Class() *jrt.Class { return A_arbace_box_size_A_class }

func (t *A_arbace_box_size_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_size_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_size_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_size_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_size_A); return ok }

func A_arbace_box_size_A_Cast(x any) *A_arbace_box_size_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_size_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_size_A_class)) }; return v }



type A_arbace_box_spawn_A struct{ jrt.Object }

func (t *A_arbace_box_spawn_A) Is_Compiler_AOTF1() {}

var A_arbace_box_spawn_A_fn_class *jrt.Class

var A_arbace_box_spawn_A_init jrt.ClassInit

func A_arbace_box_spawn_A_Init() { if !A_arbace_box_spawn_A_init.Done() { A_arbace_box_spawn_A_init.Run(A_arbace_box_spawn_A_clinit) } }

func A_arbace_box_spawn_A_clinit() { A_arbace_box_spawn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_spawn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_spawn_A) GetClass__Class() *jrt.Class { return A_arbace_box_spawn_A_class }

func (t *A_arbace_box_spawn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_spawn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_spawn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_spawn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_spawn_A); return ok }

func A_arbace_box_spawn_A_Cast(x any) *A_arbace_box_spawn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_spawn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_spawn_A_class)) }; return v }



type A_arbace_box_spawn_wait_A struct{ jrt.Object }

func (t *A_arbace_box_spawn_wait_A) Is_Compiler_AOTF1() {}

var A_arbace_box_spawn_wait_A_fn_class *jrt.Class

var A_arbace_box_spawn_wait_A_init jrt.ClassInit

func A_arbace_box_spawn_wait_A_Init() { if !A_arbace_box_spawn_wait_A_init.Done() { A_arbace_box_spawn_wait_A_init.Run(A_arbace_box_spawn_wait_A_clinit) } }

func A_arbace_box_spawn_wait_A_clinit() { A_arbace_box_spawn_wait_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_spawn_wait_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_spawn_wait_A) GetClass__Class() *jrt.Class { return A_arbace_box_spawn_wait_A_class }

func (t *A_arbace_box_spawn_wait_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_spawn_wait_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_spawn_wait_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_spawn_wait_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_spawn_wait_A); return ok }

func A_arbace_box_spawn_wait_A_Cast(x any) *A_arbace_box_spawn_wait_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_spawn_wait_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_spawn_wait_A_class)) }; return v }



type A_arbace_box_store_QMARK__A struct{ jrt.Object }

func (t *A_arbace_box_store_QMARK__A) Is_Compiler_AOTF0() {}

var A_arbace_box_store_QMARK__A_fn_class *jrt.Class

var A_arbace_box_store_QMARK__A_init jrt.ClassInit

func A_arbace_box_store_QMARK__A_Init() { if !A_arbace_box_store_QMARK__A_init.Done() { A_arbace_box_store_QMARK__A_init.Run(A_arbace_box_store_QMARK__A_clinit) } }

func A_arbace_box_store_QMARK__A_clinit() { A_arbace_box_store_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_store_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_store_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_box_store_QMARK__A_class }

func (t *A_arbace_box_store_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_store_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_store_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_store_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_store_QMARK__A); return ok }

func A_arbace_box_store_QMARK__A_Cast(x any) *A_arbace_box_store_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_store_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_store_QMARK__A_class)) }; return v }



type A_arbace_box_tree_A struct{ jrt.Object }

func (t *A_arbace_box_tree_A) Is_Compiler_AOTF1() {}

var A_arbace_box_tree_A_fn_class *jrt.Class

var A_arbace_box_tree_A_init jrt.ClassInit

func A_arbace_box_tree_A_Init() { if !A_arbace_box_tree_A_init.Done() { A_arbace_box_tree_A_init.Run(A_arbace_box_tree_A_clinit) } }

func A_arbace_box_tree_A_clinit() { A_arbace_box_tree_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_219, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_tree_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_tree_A) GetClass__Class() *jrt.Class { return A_arbace_box_tree_A_class }

func (t *A_arbace_box_tree_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_tree_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_tree_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_tree_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_tree_A); return ok }

func A_arbace_box_tree_A_Cast(x any) *A_arbace_box_tree_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_tree_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_tree_A_class)) }; return v }



type A_arbace_box_tree_get_A struct{ jrt.Object }

func (t *A_arbace_box_tree_get_A) Is_Compiler_AOTF2() {}

var A_arbace_box_tree_get_A_fn_class *jrt.Class

var A_arbace_box_tree_get_A_init jrt.ClassInit

func A_arbace_box_tree_get_A_Init() { if !A_arbace_box_tree_get_A_init.Done() { A_arbace_box_tree_get_A_init.Run(A_arbace_box_tree_get_A_clinit) } }

func A_arbace_box_tree_get_A_clinit() { A_arbace_box_tree_get_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_tree_get_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_tree_get_A) GetClass__Class() *jrt.Class { return A_arbace_box_tree_get_A_class }

func (t *A_arbace_box_tree_get_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_tree_get_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_tree_get_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_tree_get_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_tree_get_A); return ok }

func A_arbace_box_tree_get_A_Cast(x any) *A_arbace_box_tree_get_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_tree_get_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_tree_get_A_class)) }; return v }



type A_arbace_box_tree_get_fn__533000088_A struct{ jrt.Object }

func (t *A_arbace_box_tree_get_fn__533000088_A) Is_Compiler_AOTF2() {}

var A_arbace_box_tree_get_fn__533000088_A_fn_class *jrt.Class

var A_arbace_box_tree_get_fn__533000088_A_init jrt.ClassInit

func A_arbace_box_tree_get_fn__533000088_A_Init() { if !A_arbace_box_tree_get_fn__533000088_A_init.Done() { A_arbace_box_tree_get_fn__533000088_A_init.Run(A_arbace_box_tree_get_fn__533000088_A_clinit) } }

func A_arbace_box_tree_get_fn__533000088_A_clinit() { A_arbace_box_tree_get_fn__533000088_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_tree_get_fn__533000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_tree_get_fn__533000088_A) GetClass__Class() *jrt.Class { return A_arbace_box_tree_get_fn__533000088_A_class }

func (t *A_arbace_box_tree_get_fn__533000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_tree_get_fn__533000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_tree_get_fn__533000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_tree_get_fn__533000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_tree_get_fn__533000088_A); return ok }

func A_arbace_box_tree_get_fn__533000088_A_Cast(x any) *A_arbace_box_tree_get_fn__533000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_tree_get_fn__533000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_tree_get_fn__533000088_A_class)) }; return v }



type A_arbace_box_tree_name_QMARK__A struct{ jrt.Object }

func (t *A_arbace_box_tree_name_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_box_tree_name_QMARK__A_fn_class *jrt.Class

var A_arbace_box_tree_name_QMARK__A_init jrt.ClassInit

func A_arbace_box_tree_name_QMARK__A_Init() { if !A_arbace_box_tree_name_QMARK__A_init.Done() { A_arbace_box_tree_name_QMARK__A_init.Run(A_arbace_box_tree_name_QMARK__A_clinit) } }

func A_arbace_box_tree_name_QMARK__A_clinit() { A_arbace_box_tree_name_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_223, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_tree_name_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_tree_name_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_box_tree_name_QMARK__A_class }

func (t *A_arbace_box_tree_name_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_tree_name_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_tree_name_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_tree_name_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_tree_name_QMARK__A); return ok }

func A_arbace_box_tree_name_QMARK__A_Cast(x any) *A_arbace_box_tree_name_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_tree_name_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_tree_name_QMARK__A_class)) }; return v }



type A_arbace_box_tree_name_QMARK__fn__533000038_A struct{ jrt.Object }

func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Is_Compiler_AOTF1() {}

var A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class *jrt.Class

var A_arbace_box_tree_name_QMARK__fn__533000038_A_init jrt.ClassInit

func A_arbace_box_tree_name_QMARK__fn__533000038_A_Init() { if !A_arbace_box_tree_name_QMARK__fn__533000038_A_init.Done() { A_arbace_box_tree_name_QMARK__fn__533000038_A_init.Run(A_arbace_box_tree_name_QMARK__fn__533000038_A_clinit) } }

func A_arbace_box_tree_name_QMARK__fn__533000038_A_clinit() { A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_224, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) GetClass__Class() *jrt.Class { return A_arbace_box_tree_name_QMARK__fn__533000038_A_class }

func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_tree_name_QMARK__fn__533000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_tree_name_QMARK__fn__533000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_tree_name_QMARK__fn__533000038_A); return ok }

func A_arbace_box_tree_name_QMARK__fn__533000038_A_Cast(x any) *A_arbace_box_tree_name_QMARK__fn__533000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_tree_name_QMARK__fn__533000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_tree_name_QMARK__fn__533000038_A_class)) }; return v }



type A_arbace_box_tree_text_A struct{ jrt.Object }

func (t *A_arbace_box_tree_text_A) Is_Compiler_AOTF1() {}

var A_arbace_box_tree_text_A_fn_class *jrt.Class

var A_arbace_box_tree_text_A_init jrt.ClassInit

func A_arbace_box_tree_text_A_Init() { if !A_arbace_box_tree_text_A_init.Done() { A_arbace_box_tree_text_A_init.Run(A_arbace_box_tree_text_A_clinit) } }

func A_arbace_box_tree_text_A_clinit() { A_arbace_box_tree_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_225, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_tree_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_tree_text_A) GetClass__Class() *jrt.Class { return A_arbace_box_tree_text_A_class }

func (t *A_arbace_box_tree_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_tree_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_tree_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_tree_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_tree_text_A); return ok }

func A_arbace_box_tree_text_A_Cast(x any) *A_arbace_box_tree_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_tree_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_tree_text_A_class)) }; return v }



type A_arbace_box_tree_text_fn__533000042_A struct{ jrt.Object }

func (t *A_arbace_box_tree_text_fn__533000042_A) Is_Compiler_AOTF1() {}

var A_arbace_box_tree_text_fn__533000042_A_fn_class *jrt.Class

var A_arbace_box_tree_text_fn__533000042_A_init jrt.ClassInit

func A_arbace_box_tree_text_fn__533000042_A_Init() { if !A_arbace_box_tree_text_fn__533000042_A_init.Done() { A_arbace_box_tree_text_fn__533000042_A_init.Run(A_arbace_box_tree_text_fn__533000042_A_clinit) } }

func A_arbace_box_tree_text_fn__533000042_A_clinit() { A_arbace_box_tree_text_fn__533000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_228, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_tree_text_fn__533000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_tree_text_fn__533000042_A) GetClass__Class() *jrt.Class { return A_arbace_box_tree_text_fn__533000042_A_class }

func (t *A_arbace_box_tree_text_fn__533000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_tree_text_fn__533000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_tree_text_fn__533000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_tree_text_fn__533000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_tree_text_fn__533000042_A); return ok }

func A_arbace_box_tree_text_fn__533000042_A_Cast(x any) *A_arbace_box_tree_text_fn__533000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_tree_text_fn__533000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_tree_text_fn__533000042_A_class)) }; return v }



type A_arbace_box_utf8_compare_A struct{ jrt.Object }

func (t *A_arbace_box_utf8_compare_A) Is_Compiler_AOTF2() {}

var A_arbace_box_utf8_compare_A_fn_class *jrt.Class

var A_arbace_box_utf8_compare_A_init jrt.ClassInit

func A_arbace_box_utf8_compare_A_Init() { if !A_arbace_box_utf8_compare_A_init.Done() { A_arbace_box_utf8_compare_A_init.Run(A_arbace_box_utf8_compare_A_clinit) } }

func A_arbace_box_utf8_compare_A_clinit() { A_arbace_box_utf8_compare_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_233, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_utf8_compare_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_utf8_compare_A) GetClass__Class() *jrt.Class { return A_arbace_box_utf8_compare_A_class }

func (t *A_arbace_box_utf8_compare_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_utf8_compare_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_utf8_compare_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_utf8_compare_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_utf8_compare_A); return ok }

func A_arbace_box_utf8_compare_A_Cast(x any) *A_arbace_box_utf8_compare_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_utf8_compare_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_utf8_compare_A_class)) }; return v }
