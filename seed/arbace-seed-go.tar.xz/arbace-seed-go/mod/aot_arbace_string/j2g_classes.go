//line j2g_classes.ae:1
package aot_arbace_string

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_string_blank_QMARK__A_class, Name: "arbace.string$blank_QMARK_", Modifiers: 25, Simple: "blank_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_blank_QMARK__A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_capitalize_A_class, Name: "arbace.string$capitalize", Modifiers: 25, Simple: "capitalize", Go: "arbace/aot_arbace_string.A_arbace_string_capitalize_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_ends_with_QMARK__A_class, Name: "arbace.string$ends_with_QMARK_", Modifiers: 25, Simple: "ends_with_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_ends_with_QMARK__A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_string_escape_A_class, Name: "arbace.string$escape", Modifiers: 25, Simple: "escape", Go: "arbace/aot_arbace_string.A_arbace_string_escape_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_class, Name: "arbace.string$eval885000004$loading__1927001464__auto____885000005", Modifiers: 25, Simple: "loading__1927001464__auto____885000005", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A", Source: "string.ae", Declaring: &A_arbace_string_eval885000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_string_eval885000008_fn__885000009_A_class, Name: "arbace.string$eval885000008$fn__885000009", Modifiers: 25, Simple: "fn__885000009", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000008_fn__885000009_A", Source: "string.ae", Declaring: &A_arbace_string_eval885000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_string_includes_QMARK__A_class, Name: "arbace.string$includes_QMARK_", Modifiers: 25, Simple: "includes_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_includes_QMARK__A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_string_index_of_A_class, Name: "arbace.string$index_of", Modifiers: 25, Simple: "index_of", Go: "arbace/aot_arbace_string.A_arbace_string_index_of_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_string_join_A_class, Name: "arbace.string$join", Modifiers: 25, Simple: "join", Go: "arbace/aot_arbace_string.A_arbace_string_join_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_last_index_of_A_class, Name: "arbace.string$last_index_of", Modifiers: 25, Simple: "last_index_of", Go: "arbace/aot_arbace_string.A_arbace_string_last_index_of_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_string_lower_case_A_class, Name: "arbace.string$lower_case", Modifiers: 25, Simple: "lower_case", Go: "arbace/aot_arbace_string.A_arbace_string_lower_case_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_re_quote_replacement_A_class, Name: "arbace.string$re_quote_replacement", Modifiers: 25, Simple: "re_quote_replacement", Go: "arbace/aot_arbace_string.A_arbace_string_re_quote_replacement_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_replace_A_class, Name: "arbace.string$replace", Modifiers: 25, Simple: "replace", Go: "arbace/aot_arbace_string.A_arbace_string_replace_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_string_replace_by_A_class, Name: "arbace.string$replace_by", Modifiers: 25, Simple: "replace_by", Go: "arbace/aot_arbace_string.A_arbace_string_replace_by_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_string_replace_first_A_class, Name: "arbace.string$replace_first", Modifiers: 25, Simple: "replace_first", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_string_replace_first_by_A_class, Name: "arbace.string$replace_first_by", Modifiers: 25, Simple: "replace_first_by", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_by_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_string_replace_first_char_A_class, Name: "arbace.string$replace_first_char", Modifiers: 25, Simple: "replace_first_char", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_char_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_string_replace_first_str_A_class, Name: "arbace.string$replace_first_str", Modifiers: 25, Simple: "replace_first_str", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_str_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_string_reverse_A_class, Name: "arbace.string$reverse", Modifiers: 25, Simple: "reverse", Go: "arbace/aot_arbace_string.A_arbace_string_reverse_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_split_A_class, Name: "arbace.string$split", Modifiers: 25, Simple: "split", Go: "arbace/aot_arbace_string.A_arbace_string_split_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_string_split_lines_A_class, Name: "arbace.string$split_lines", Modifiers: 25, Simple: "split_lines", Go: "arbace/aot_arbace_string.A_arbace_string_split_lines_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_starts_with_QMARK__A_class, Name: "arbace.string$starts_with_QMARK_", Modifiers: 25, Simple: "starts_with_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_starts_with_QMARK__A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_string_trim_A_class, Name: "arbace.string$trim", Modifiers: 25, Simple: "trim", Go: "arbace/aot_arbace_string.A_arbace_string_trim_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_trim_newline_A_class, Name: "arbace.string$trim_newline", Modifiers: 25, Simple: "trim_newline", Go: "arbace/aot_arbace_string.A_arbace_string_trim_newline_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_triml_A_class, Name: "arbace.string$triml", Modifiers: 25, Simple: "triml", Go: "arbace/aot_arbace_string.A_arbace_string_triml_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_trimr_A_class, Name: "arbace.string$trimr", Modifiers: 25, Simple: "trimr", Go: "arbace/aot_arbace_string.A_arbace_string_trimr_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_string_upper_case_A_class, Name: "arbace.string$upper_case", Modifiers: 25, Simple: "upper_case", Go: "arbace/aot_arbace_string.A_arbace_string_upper_case_A", Source: "string.ae", Declaring: &A_arbace_string_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_A_New()}; return nil }

var A_arbace_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_string_A_new}

var A_arbace_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_string.A_arbace_string_A"})

func init() { i := A_arbace_string_A_class.Info(); i.IsInstance = A_arbace_string_A_InstanceOf; i.Init = A_arbace_string_A_Init; i.Table = A_arbace_string_A_members }

var A_arbace_string_blank_QMARK__A_class *jrt.Class

var A_arbace_string_capitalize_A_class *jrt.Class

var A_arbace_string_ends_with_QMARK__A_class *jrt.Class

var A_arbace_string_escape_A_class *jrt.Class

func A_arbace_string_eval885000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_eval885000004_A_New()}; return nil }

var A_arbace_string_eval885000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_string_eval885000004_A_new}

var A_arbace_string_eval885000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$eval885000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_string_A_class, Simple: "eval885000004", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000004_A"})

func init() { i := A_arbace_string_eval885000004_A_class.Info(); i.IsInstance = A_arbace_string_eval885000004_A_InstanceOf; i.Table = A_arbace_string_eval885000004_A_members }

var A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_class *jrt.Class

func A_arbace_string_eval885000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_eval885000008_A_New()}; return nil }

var A_arbace_string_eval885000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_string_eval885000008_A_new}

var A_arbace_string_eval885000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$eval885000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_string_A_class, Simple: "eval885000008", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000008_A"})

func init() { i := A_arbace_string_eval885000008_A_class.Info(); i.IsInstance = A_arbace_string_eval885000008_A_InstanceOf; i.Table = A_arbace_string_eval885000008_A_members }

var A_arbace_string_eval885000008_fn__885000009_A_class *jrt.Class

var A_arbace_string_includes_QMARK__A_class *jrt.Class

var A_arbace_string_index_of_A_class *jrt.Class

var A_arbace_string_join_A_class *jrt.Class

var A_arbace_string_last_index_of_A_class *jrt.Class

var A_arbace_string_lower_case_A_class *jrt.Class

var A_arbace_string_re_quote_replacement_A_class *jrt.Class

var A_arbace_string_replace_A_class *jrt.Class

var A_arbace_string_replace_by_A_class *jrt.Class

var A_arbace_string_replace_first_A_class *jrt.Class

var A_arbace_string_replace_first_by_A_class *jrt.Class

var A_arbace_string_replace_first_char_A_class *jrt.Class

var A_arbace_string_replace_first_str_A_class *jrt.Class

var A_arbace_string_reverse_A_class *jrt.Class

var A_arbace_string_split_A_class *jrt.Class

var A_arbace_string_split_lines_A_class *jrt.Class

var A_arbace_string_starts_with_QMARK__A_class *jrt.Class

var A_arbace_string_trim_A_class *jrt.Class

var A_arbace_string_trim_newline_A_class *jrt.Class

var A_arbace_string_triml_A_class *jrt.Class

var A_arbace_string_trimr_A_class *jrt.Class

var A_arbace_string_upper_case_A_class *jrt.Class

func A_arbace_string__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_string__init_A_Load__O()}; return nil }

func A_arbace_string__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string__init_A_New()}; return nil }

var A_arbace_string__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_string__init_A_invoke, New: A_arbace_string__init_A_new}

var A_arbace_string__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_string.A_arbace_string__init_A", Source: "string.ae"})

func init() { i := A_arbace_string__init_A_class.Info(); i.IsInstance = A_arbace_string__init_A_InstanceOf; i.Init = A_arbace_string__init_A_Init; i.Table = A_arbace_string__init_A_members }
