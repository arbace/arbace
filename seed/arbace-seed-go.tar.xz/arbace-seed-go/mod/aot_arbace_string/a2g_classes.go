//line a2g_classes.ae:1
package aot_arbace_string

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_A_New()}; return nil }

var A_arbace_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_string_A_new}

var A_arbace_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_string.A_arbace_string_A"})

func init() { i := A_arbace_string_A_class.Info(); i.IsInstance = A_arbace_string_A_InstanceOf; i.Init = A_arbace_string_A_Init; i.Table = A_arbace_string_A_members; jrt.RegisterGoType(A_arbace_string_A_class, reflect.TypeFor[A_arbace_string_A]()) }

func A_arbace_string_blank_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_blank_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_blank_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_blank_QMARK__A_New()}; return nil }

func A_arbace_string_blank_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_blank_QMARK__A_fn_class)}; return nil }

var A_arbace_string_blank_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_blank_QMARK__A_invoke, New: A_arbace_string_blank_QMARK__A_new, Get: A_arbace_string_blank_QMARK__A_get}

var A_arbace_string_blank_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$blank_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "blank_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_blank_QMARK__A", Source: "string.ae"})

func init() { i := A_arbace_string_blank_QMARK__A_class.Info(); i.IsInstance = A_arbace_string_blank_QMARK__A_InstanceOf; i.Init = A_arbace_string_blank_QMARK__A_Init; i.Table = A_arbace_string_blank_QMARK__A_members; jrt.RegisterGoType(A_arbace_string_blank_QMARK__A_class, reflect.TypeFor[A_arbace_string_blank_QMARK__A]()) }

func A_arbace_string_capitalize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_capitalize_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_capitalize_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_capitalize_A_New()}; return nil }

func A_arbace_string_capitalize_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_capitalize_A_fn_class)}; return nil }

var A_arbace_string_capitalize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_capitalize_A_invoke, New: A_arbace_string_capitalize_A_new, Get: A_arbace_string_capitalize_A_get}

var A_arbace_string_capitalize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$capitalize", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "capitalize", Go: "arbace/aot_arbace_string.A_arbace_string_capitalize_A", Source: "string.ae"})

func init() { i := A_arbace_string_capitalize_A_class.Info(); i.IsInstance = A_arbace_string_capitalize_A_InstanceOf; i.Init = A_arbace_string_capitalize_A_Init; i.Table = A_arbace_string_capitalize_A_members; jrt.RegisterGoType(A_arbace_string_capitalize_A_class, reflect.TypeFor[A_arbace_string_capitalize_A]()) }

func A_arbace_string_ends_with_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_string_ends_with_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_ends_with_QMARK__A_New()}; return nil }

func A_arbace_string_ends_with_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_ends_with_QMARK__A_fn_class)}; return nil }

var A_arbace_string_ends_with_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_ends_with_QMARK__A_invoke, New: A_arbace_string_ends_with_QMARK__A_new, Get: A_arbace_string_ends_with_QMARK__A_get}

var A_arbace_string_ends_with_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$ends_with_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_string_A_class, Simple: "ends_with_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_ends_with_QMARK__A", Source: "string.ae"})

func init() { i := A_arbace_string_ends_with_QMARK__A_class.Info(); i.IsInstance = A_arbace_string_ends_with_QMARK__A_InstanceOf; i.Init = A_arbace_string_ends_with_QMARK__A_Init; i.Table = A_arbace_string_ends_with_QMARK__A_members; jrt.RegisterGoType(A_arbace_string_ends_with_QMARK__A_class, reflect.TypeFor[A_arbace_string_ends_with_QMARK__A]()) }

func A_arbace_string_escape_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_escape_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_string_escape_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_escape_A_New()}; return nil }

func A_arbace_string_escape_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_escape_A_fn_class)}; return nil }

var A_arbace_string_escape_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_escape_A_invoke, New: A_arbace_string_escape_A_new, Get: A_arbace_string_escape_A_get}

var A_arbace_string_escape_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$escape", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_string_A_class, Simple: "escape", Go: "arbace/aot_arbace_string.A_arbace_string_escape_A", Source: "string.ae"})

func init() { i := A_arbace_string_escape_A_class.Info(); i.IsInstance = A_arbace_string_escape_A_InstanceOf; i.Init = A_arbace_string_escape_A_Init; i.Table = A_arbace_string_escape_A_members; jrt.RegisterGoType(A_arbace_string_escape_A_class, reflect.TypeFor[A_arbace_string_escape_A]()) }

func A_arbace_string_eval885000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_eval885000004_A_New()}; return nil }

var A_arbace_string_eval885000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_string_eval885000004_A_new}

var A_arbace_string_eval885000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$eval885000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_string_A_class, Simple: "eval885000004", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000004_A"})

func init() { i := A_arbace_string_eval885000004_A_class.Info(); i.IsInstance = A_arbace_string_eval885000004_A_InstanceOf; i.Table = A_arbace_string_eval885000004_A_members; jrt.RegisterGoType(A_arbace_string_eval885000004_A_class, reflect.TypeFor[A_arbace_string_eval885000004_A]()) }

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_New()}; return nil }

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_fn_class)}; return nil }

var A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_invoke, New: A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_new, Get: A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_get}

var A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$eval885000004$loading__1927001464__auto____885000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_string_eval885000004_A_class, Simple: "loading__1927001464__auto____885000005", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A", Source: "string.ae"})

func init() { i := A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_class.Info(); i.IsInstance = A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_InstanceOf; i.Init = A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_Init; i.Table = A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_members; jrt.RegisterGoType(A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_class, reflect.TypeFor[A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A]()) }

func A_arbace_string_eval885000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_eval885000008_A_New()}; return nil }

var A_arbace_string_eval885000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_string_eval885000008_A_new}

var A_arbace_string_eval885000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$eval885000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_string_A_class, Simple: "eval885000008", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000008_A"})

func init() { i := A_arbace_string_eval885000008_A_class.Info(); i.IsInstance = A_arbace_string_eval885000008_A_InstanceOf; i.Table = A_arbace_string_eval885000008_A_members; jrt.RegisterGoType(A_arbace_string_eval885000008_A_class, reflect.TypeFor[A_arbace_string_eval885000008_A]()) }

func A_arbace_string_eval885000008_fn__885000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_eval885000008_fn__885000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_string_eval885000008_fn__885000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_eval885000008_fn__885000009_A_New()}; return nil }

func A_arbace_string_eval885000008_fn__885000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_eval885000008_fn__885000009_A_fn_class)}; return nil }

var A_arbace_string_eval885000008_fn__885000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_eval885000008_fn__885000009_A_invoke, New: A_arbace_string_eval885000008_fn__885000009_A_new, Get: A_arbace_string_eval885000008_fn__885000009_A_get}

var A_arbace_string_eval885000008_fn__885000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$eval885000008$fn__885000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_string_eval885000008_A_class, Simple: "fn__885000009", Go: "arbace/aot_arbace_string.A_arbace_string_eval885000008_fn__885000009_A", Source: "string.ae"})

func init() { i := A_arbace_string_eval885000008_fn__885000009_A_class.Info(); i.IsInstance = A_arbace_string_eval885000008_fn__885000009_A_InstanceOf; i.Init = A_arbace_string_eval885000008_fn__885000009_A_Init; i.Table = A_arbace_string_eval885000008_fn__885000009_A_members; jrt.RegisterGoType(A_arbace_string_eval885000008_fn__885000009_A_class, reflect.TypeFor[A_arbace_string_eval885000008_fn__885000009_A]()) }

func A_arbace_string_includes_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_string_includes_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_includes_QMARK__A_New()}; return nil }

func A_arbace_string_includes_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_includes_QMARK__A_fn_class)}; return nil }

var A_arbace_string_includes_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_includes_QMARK__A_invoke, New: A_arbace_string_includes_QMARK__A_new, Get: A_arbace_string_includes_QMARK__A_get}

var A_arbace_string_includes_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$includes_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_string_A_class, Simple: "includes_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_includes_QMARK__A", Source: "string.ae"})

func init() { i := A_arbace_string_includes_QMARK__A_class.Info(); i.IsInstance = A_arbace_string_includes_QMARK__A_InstanceOf; i.Init = A_arbace_string_includes_QMARK__A_Init; i.Table = A_arbace_string_includes_QMARK__A_members; jrt.RegisterGoType(A_arbace_string_includes_QMARK__A_class, reflect.TypeFor[A_arbace_string_includes_QMARK__A]()) }

func A_arbace_string_index_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_index_of_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_string_index_of_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_index_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_index_of_A_New()}; return nil }

func A_arbace_string_index_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_index_of_A_fn_class)}; return nil }

var A_arbace_string_index_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_index_of_A_invoke, New: A_arbace_string_index_of_A_new, Get: A_arbace_string_index_of_A_get}

var A_arbace_string_index_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$index_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_string_A_class, Simple: "index_of", Go: "arbace/aot_arbace_string.A_arbace_string_index_of_A", Source: "string.ae"})

func init() { i := A_arbace_string_index_of_A_class.Info(); i.IsInstance = A_arbace_string_index_of_A_InstanceOf; i.Init = A_arbace_string_index_of_A_Init; i.Table = A_arbace_string_index_of_A_members; jrt.RegisterGoType(A_arbace_string_index_of_A_class, reflect.TypeFor[A_arbace_string_index_of_A]()) }

func A_arbace_string_join_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_join_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_string_join_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_string_join_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_join_A_New()}; return nil }

func A_arbace_string_join_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_join_A_fn_class)}; return nil }

var A_arbace_string_join_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_join_A_invoke, New: A_arbace_string_join_A_new, Get: A_arbace_string_join_A_get}

var A_arbace_string_join_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$join", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "join", Go: "arbace/aot_arbace_string.A_arbace_string_join_A", Source: "string.ae"})

func init() { i := A_arbace_string_join_A_class.Info(); i.IsInstance = A_arbace_string_join_A_InstanceOf; i.Init = A_arbace_string_join_A_Init; i.Table = A_arbace_string_join_A_members; jrt.RegisterGoType(A_arbace_string_join_A_class, reflect.TypeFor[A_arbace_string_join_A]()) }

func A_arbace_string_last_index_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_last_index_of_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_string_last_index_of_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_last_index_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_last_index_of_A_New()}; return nil }

func A_arbace_string_last_index_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_last_index_of_A_fn_class)}; return nil }

var A_arbace_string_last_index_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_last_index_of_A_invoke, New: A_arbace_string_last_index_of_A_new, Get: A_arbace_string_last_index_of_A_get}

var A_arbace_string_last_index_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$last_index_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_string_A_class, Simple: "last_index_of", Go: "arbace/aot_arbace_string.A_arbace_string_last_index_of_A", Source: "string.ae"})

func init() { i := A_arbace_string_last_index_of_A_class.Info(); i.IsInstance = A_arbace_string_last_index_of_A_InstanceOf; i.Init = A_arbace_string_last_index_of_A_Init; i.Table = A_arbace_string_last_index_of_A_members; jrt.RegisterGoType(A_arbace_string_last_index_of_A_class, reflect.TypeFor[A_arbace_string_last_index_of_A]()) }

func A_arbace_string_lower_case_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_lower_case_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_lower_case_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_lower_case_A_New()}; return nil }

func A_arbace_string_lower_case_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_lower_case_A_fn_class)}; return nil }

var A_arbace_string_lower_case_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_lower_case_A_invoke, New: A_arbace_string_lower_case_A_new, Get: A_arbace_string_lower_case_A_get}

var A_arbace_string_lower_case_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$lower_case", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "lower_case", Go: "arbace/aot_arbace_string.A_arbace_string_lower_case_A", Source: "string.ae"})

func init() { i := A_arbace_string_lower_case_A_class.Info(); i.IsInstance = A_arbace_string_lower_case_A_InstanceOf; i.Init = A_arbace_string_lower_case_A_Init; i.Table = A_arbace_string_lower_case_A_members; jrt.RegisterGoType(A_arbace_string_lower_case_A_class, reflect.TypeFor[A_arbace_string_lower_case_A]()) }

func A_arbace_string_re_quote_replacement_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_re_quote_replacement_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_re_quote_replacement_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_re_quote_replacement_A_New()}; return nil }

func A_arbace_string_re_quote_replacement_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_re_quote_replacement_A_fn_class)}; return nil }

var A_arbace_string_re_quote_replacement_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_re_quote_replacement_A_invoke, New: A_arbace_string_re_quote_replacement_A_new, Get: A_arbace_string_re_quote_replacement_A_get}

var A_arbace_string_re_quote_replacement_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$re_quote_replacement", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "re_quote_replacement", Go: "arbace/aot_arbace_string.A_arbace_string_re_quote_replacement_A", Source: "string.ae"})

func init() { i := A_arbace_string_re_quote_replacement_A_class.Info(); i.IsInstance = A_arbace_string_re_quote_replacement_A_InstanceOf; i.Init = A_arbace_string_re_quote_replacement_A_Init; i.Table = A_arbace_string_re_quote_replacement_A_members; jrt.RegisterGoType(A_arbace_string_re_quote_replacement_A_class, reflect.TypeFor[A_arbace_string_re_quote_replacement_A]()) }

func A_arbace_string_replace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_replace_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_replace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_replace_A_New()}; return nil }

func A_arbace_string_replace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_replace_A_fn_class)}; return nil }

var A_arbace_string_replace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_replace_A_invoke, New: A_arbace_string_replace_A_new, Get: A_arbace_string_replace_A_get}

var A_arbace_string_replace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$replace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_string_A_class, Simple: "replace", Go: "arbace/aot_arbace_string.A_arbace_string_replace_A", Source: "string.ae"})

func init() { i := A_arbace_string_replace_A_class.Info(); i.IsInstance = A_arbace_string_replace_A_InstanceOf; i.Init = A_arbace_string_replace_A_Init; i.Table = A_arbace_string_replace_A_members; jrt.RegisterGoType(A_arbace_string_replace_A_class, reflect.TypeFor[A_arbace_string_replace_A]()) }

func A_arbace_string_replace_by_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_replace_by_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_replace_by_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_replace_by_A_New()}; return nil }

func A_arbace_string_replace_by_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_replace_by_A_fn_class)}; return nil }

var A_arbace_string_replace_by_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_replace_by_A_invoke, New: A_arbace_string_replace_by_A_new, Get: A_arbace_string_replace_by_A_get}

var A_arbace_string_replace_by_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$replace_by", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_string_A_class, Simple: "replace_by", Go: "arbace/aot_arbace_string.A_arbace_string_replace_by_A", Source: "string.ae"})

func init() { i := A_arbace_string_replace_by_A_class.Info(); i.IsInstance = A_arbace_string_replace_by_A_InstanceOf; i.Init = A_arbace_string_replace_by_A_Init; i.Table = A_arbace_string_replace_by_A_members; jrt.RegisterGoType(A_arbace_string_replace_by_A_class, reflect.TypeFor[A_arbace_string_replace_by_A]()) }

func A_arbace_string_replace_first_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_replace_first_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_replace_first_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_replace_first_A_New()}; return nil }

func A_arbace_string_replace_first_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_replace_first_A_fn_class)}; return nil }

var A_arbace_string_replace_first_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_replace_first_A_invoke, New: A_arbace_string_replace_first_A_new, Get: A_arbace_string_replace_first_A_get}

var A_arbace_string_replace_first_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$replace_first", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_string_A_class, Simple: "replace_first", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_A", Source: "string.ae"})

func init() { i := A_arbace_string_replace_first_A_class.Info(); i.IsInstance = A_arbace_string_replace_first_A_InstanceOf; i.Init = A_arbace_string_replace_first_A_Init; i.Table = A_arbace_string_replace_first_A_members; jrt.RegisterGoType(A_arbace_string_replace_first_A_class, reflect.TypeFor[A_arbace_string_replace_first_A]()) }

func A_arbace_string_replace_first_by_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_replace_first_by_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_replace_first_by_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_replace_first_by_A_New()}; return nil }

func A_arbace_string_replace_first_by_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_replace_first_by_A_fn_class)}; return nil }

var A_arbace_string_replace_first_by_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_replace_first_by_A_invoke, New: A_arbace_string_replace_first_by_A_new, Get: A_arbace_string_replace_first_by_A_get}

var A_arbace_string_replace_first_by_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$replace_first_by", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_string_A_class, Simple: "replace_first_by", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_by_A", Source: "string.ae"})

func init() { i := A_arbace_string_replace_first_by_A_class.Info(); i.IsInstance = A_arbace_string_replace_first_by_A_InstanceOf; i.Init = A_arbace_string_replace_first_by_A_Init; i.Table = A_arbace_string_replace_first_by_A_members; jrt.RegisterGoType(A_arbace_string_replace_first_by_A_class, reflect.TypeFor[A_arbace_string_replace_first_by_A]()) }

func A_arbace_string_replace_first_char_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_replace_first_char_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_replace_first_char_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_replace_first_char_A_New()}; return nil }

func A_arbace_string_replace_first_char_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_replace_first_char_A_fn_class)}; return nil }

var A_arbace_string_replace_first_char_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_replace_first_char_A_invoke, New: A_arbace_string_replace_first_char_A_new, Get: A_arbace_string_replace_first_char_A_get}

var A_arbace_string_replace_first_char_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$replace_first_char", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_string_A_class, Simple: "replace_first_char", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_char_A", Source: "string.ae"})

func init() { i := A_arbace_string_replace_first_char_A_class.Info(); i.IsInstance = A_arbace_string_replace_first_char_A_InstanceOf; i.Init = A_arbace_string_replace_first_char_A_Init; i.Table = A_arbace_string_replace_first_char_A_members; jrt.RegisterGoType(A_arbace_string_replace_first_char_A_class, reflect.TypeFor[A_arbace_string_replace_first_char_A]()) }

func A_arbace_string_replace_first_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_replace_first_str_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_replace_first_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_replace_first_str_A_New()}; return nil }

func A_arbace_string_replace_first_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_replace_first_str_A_fn_class)}; return nil }

var A_arbace_string_replace_first_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_replace_first_str_A_invoke, New: A_arbace_string_replace_first_str_A_new, Get: A_arbace_string_replace_first_str_A_get}

var A_arbace_string_replace_first_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$replace_first_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_string_A_class, Simple: "replace_first_str", Go: "arbace/aot_arbace_string.A_arbace_string_replace_first_str_A", Source: "string.ae"})

func init() { i := A_arbace_string_replace_first_str_A_class.Info(); i.IsInstance = A_arbace_string_replace_first_str_A_InstanceOf; i.Init = A_arbace_string_replace_first_str_A_Init; i.Table = A_arbace_string_replace_first_str_A_members; jrt.RegisterGoType(A_arbace_string_replace_first_str_A_class, reflect.TypeFor[A_arbace_string_replace_first_str_A]()) }

func A_arbace_string_reverse_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_reverse_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_reverse_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_reverse_A_New()}; return nil }

func A_arbace_string_reverse_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_reverse_A_fn_class)}; return nil }

var A_arbace_string_reverse_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_reverse_A_invoke, New: A_arbace_string_reverse_A_new, Get: A_arbace_string_reverse_A_get}

var A_arbace_string_reverse_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$reverse", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "reverse", Go: "arbace/aot_arbace_string.A_arbace_string_reverse_A", Source: "string.ae"})

func init() { i := A_arbace_string_reverse_A_class.Info(); i.IsInstance = A_arbace_string_reverse_A_InstanceOf; i.Init = A_arbace_string_reverse_A_Init; i.Table = A_arbace_string_reverse_A_members; jrt.RegisterGoType(A_arbace_string_reverse_A_class, reflect.TypeFor[A_arbace_string_reverse_A]()) }

func A_arbace_string_split_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_split_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_string_split_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_string_split_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_split_A_New()}; return nil }

func A_arbace_string_split_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_split_A_fn_class)}; return nil }

var A_arbace_string_split_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_split_A_invoke, New: A_arbace_string_split_A_new, Get: A_arbace_string_split_A_get}

var A_arbace_string_split_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$split", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_string_A_class, Simple: "split", Go: "arbace/aot_arbace_string.A_arbace_string_split_A", Source: "string.ae"})

func init() { i := A_arbace_string_split_A_class.Info(); i.IsInstance = A_arbace_string_split_A_InstanceOf; i.Init = A_arbace_string_split_A_Init; i.Table = A_arbace_string_split_A_members; jrt.RegisterGoType(A_arbace_string_split_A_class, reflect.TypeFor[A_arbace_string_split_A]()) }

func A_arbace_string_split_lines_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_split_lines_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_split_lines_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_split_lines_A_New()}; return nil }

func A_arbace_string_split_lines_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_split_lines_A_fn_class)}; return nil }

var A_arbace_string_split_lines_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_split_lines_A_invoke, New: A_arbace_string_split_lines_A_new, Get: A_arbace_string_split_lines_A_get}

var A_arbace_string_split_lines_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$split_lines", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "split_lines", Go: "arbace/aot_arbace_string.A_arbace_string_split_lines_A", Source: "string.ae"})

func init() { i := A_arbace_string_split_lines_A_class.Info(); i.IsInstance = A_arbace_string_split_lines_A_InstanceOf; i.Init = A_arbace_string_split_lines_A_Init; i.Table = A_arbace_string_split_lines_A_members; jrt.RegisterGoType(A_arbace_string_split_lines_A_class, reflect.TypeFor[A_arbace_string_split_lines_A]()) }

func A_arbace_string_starts_with_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_string_starts_with_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_starts_with_QMARK__A_New()}; return nil }

func A_arbace_string_starts_with_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_starts_with_QMARK__A_fn_class)}; return nil }

var A_arbace_string_starts_with_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_starts_with_QMARK__A_invoke, New: A_arbace_string_starts_with_QMARK__A_new, Get: A_arbace_string_starts_with_QMARK__A_get}

var A_arbace_string_starts_with_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$starts_with_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_string_A_class, Simple: "starts_with_QMARK_", Go: "arbace/aot_arbace_string.A_arbace_string_starts_with_QMARK__A", Source: "string.ae"})

func init() { i := A_arbace_string_starts_with_QMARK__A_class.Info(); i.IsInstance = A_arbace_string_starts_with_QMARK__A_InstanceOf; i.Init = A_arbace_string_starts_with_QMARK__A_Init; i.Table = A_arbace_string_starts_with_QMARK__A_members; jrt.RegisterGoType(A_arbace_string_starts_with_QMARK__A_class, reflect.TypeFor[A_arbace_string_starts_with_QMARK__A]()) }

func A_arbace_string_trim_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_trim_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_trim_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_trim_A_New()}; return nil }

func A_arbace_string_trim_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_trim_A_fn_class)}; return nil }

var A_arbace_string_trim_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_trim_A_invoke, New: A_arbace_string_trim_A_new, Get: A_arbace_string_trim_A_get}

var A_arbace_string_trim_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$trim", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "trim", Go: "arbace/aot_arbace_string.A_arbace_string_trim_A", Source: "string.ae"})

func init() { i := A_arbace_string_trim_A_class.Info(); i.IsInstance = A_arbace_string_trim_A_InstanceOf; i.Init = A_arbace_string_trim_A_Init; i.Table = A_arbace_string_trim_A_members; jrt.RegisterGoType(A_arbace_string_trim_A_class, reflect.TypeFor[A_arbace_string_trim_A]()) }

func A_arbace_string_trim_newline_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_trim_newline_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_trim_newline_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_trim_newline_A_New()}; return nil }

func A_arbace_string_trim_newline_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_trim_newline_A_fn_class)}; return nil }

var A_arbace_string_trim_newline_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_trim_newline_A_invoke, New: A_arbace_string_trim_newline_A_new, Get: A_arbace_string_trim_newline_A_get}

var A_arbace_string_trim_newline_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$trim_newline", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "trim_newline", Go: "arbace/aot_arbace_string.A_arbace_string_trim_newline_A", Source: "string.ae"})

func init() { i := A_arbace_string_trim_newline_A_class.Info(); i.IsInstance = A_arbace_string_trim_newline_A_InstanceOf; i.Init = A_arbace_string_trim_newline_A_Init; i.Table = A_arbace_string_trim_newline_A_members; jrt.RegisterGoType(A_arbace_string_trim_newline_A_class, reflect.TypeFor[A_arbace_string_trim_newline_A]()) }

func A_arbace_string_triml_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_triml_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_triml_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_triml_A_New()}; return nil }

func A_arbace_string_triml_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_triml_A_fn_class)}; return nil }

var A_arbace_string_triml_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_triml_A_invoke, New: A_arbace_string_triml_A_new, Get: A_arbace_string_triml_A_get}

var A_arbace_string_triml_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$triml", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "triml", Go: "arbace/aot_arbace_string.A_arbace_string_triml_A", Source: "string.ae"})

func init() { i := A_arbace_string_triml_A_class.Info(); i.IsInstance = A_arbace_string_triml_A_InstanceOf; i.Init = A_arbace_string_triml_A_Init; i.Table = A_arbace_string_triml_A_members; jrt.RegisterGoType(A_arbace_string_triml_A_class, reflect.TypeFor[A_arbace_string_triml_A]()) }

func A_arbace_string_trimr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_trimr_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_trimr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_trimr_A_New()}; return nil }

func A_arbace_string_trimr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_trimr_A_fn_class)}; return nil }

var A_arbace_string_trimr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_trimr_A_invoke, New: A_arbace_string_trimr_A_new, Get: A_arbace_string_trimr_A_get}

var A_arbace_string_trimr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$trimr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "trimr", Go: "arbace/aot_arbace_string.A_arbace_string_trimr_A", Source: "string.ae"})

func init() { i := A_arbace_string_trimr_A_class.Info(); i.IsInstance = A_arbace_string_trimr_A_InstanceOf; i.Init = A_arbace_string_trimr_A_Init; i.Table = A_arbace_string_trimr_A_members; jrt.RegisterGoType(A_arbace_string_trimr_A_class, reflect.TypeFor[A_arbace_string_trimr_A]()) }

func A_arbace_string_upper_case_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_string_upper_case_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_string_upper_case_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string_upper_case_A_New()}; return nil }

func A_arbace_string_upper_case_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_string_upper_case_A_fn_class)}; return nil }

var A_arbace_string_upper_case_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_string_upper_case_A_invoke, New: A_arbace_string_upper_case_A_new, Get: A_arbace_string_upper_case_A_get}

var A_arbace_string_upper_case_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string$upper_case", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_string_A_class, Simple: "upper_case", Go: "arbace/aot_arbace_string.A_arbace_string_upper_case_A", Source: "string.ae"})

func init() { i := A_arbace_string_upper_case_A_class.Info(); i.IsInstance = A_arbace_string_upper_case_A_InstanceOf; i.Init = A_arbace_string_upper_case_A_Init; i.Table = A_arbace_string_upper_case_A_members; jrt.RegisterGoType(A_arbace_string_upper_case_A_class, reflect.TypeFor[A_arbace_string_upper_case_A]()) }

func A_arbace_string__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_string__init_A_Load__O(); case 1: return A_arbace_string__init_A_Unit0__O(); case 2: return A_arbace_string__init_A_Unit1__O(); case 3: return A_arbace_string__init_A_Unit10__O(); case 4: return A_arbace_string__init_A_Unit11__O(); case 5: return A_arbace_string__init_A_Unit12__O(); case 6: return A_arbace_string__init_A_Unit13__O(); case 7: return A_arbace_string__init_A_Unit14__O(); case 8: return A_arbace_string__init_A_Unit15__O(); case 9: return A_arbace_string__init_A_Unit16__O(); case 10: return A_arbace_string__init_A_Unit17__O(); case 11: return A_arbace_string__init_A_Unit18__O(); case 12: return A_arbace_string__init_A_Unit19__O(); case 13: return A_arbace_string__init_A_Unit2__O(); case 14: return A_arbace_string__init_A_Unit20__O(); case 15: return A_arbace_string__init_A_Unit21__O(); case 16: return A_arbace_string__init_A_Unit22__O(); case 17: return A_arbace_string__init_A_Unit23__O(); case 18: return A_arbace_string__init_A_Unit24__O(); case 19: return A_arbace_string__init_A_Unit25__O(); case 20: return A_arbace_string__init_A_Unit26__O(); case 21: return A_arbace_string__init_A_Unit27__O(); case 22: return A_arbace_string__init_A_Unit28__O(); case 23: return A_arbace_string__init_A_Unit29__O(); case 24: return A_arbace_string__init_A_Unit3__O(); case 25: return A_arbace_string__init_A_Unit4__O(); case 26: return A_arbace_string__init_A_Unit5__O(); case 27: return A_arbace_string__init_A_Unit6__O(); case 28: return A_arbace_string__init_A_Unit7__O(); case 29: return A_arbace_string__init_A_Unit8__O(); case 30: return A_arbace_string__init_A_Unit9__O()}; return nil }

func A_arbace_string__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_string__init_A_New()}; return nil }

var A_arbace_string__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_string__init_A_invoke, New: A_arbace_string__init_A_new}

var A_arbace_string__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.string__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_string.A_arbace_string__init_A", Source: "string.ae"})

func init() { i := A_arbace_string__init_A_class.Info(); i.IsInstance = A_arbace_string__init_A_InstanceOf; i.Init = A_arbace_string__init_A_Init; i.Table = A_arbace_string__init_A_members; jrt.RegisterGoType(A_arbace_string__init_A_class, reflect.TypeFor[A_arbace_string__init_A]()) }
