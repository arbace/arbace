//line a2g_strings.ae:1
package aot_arbace_string

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("exclude")

var Lit_3 *jrt.String = jrt.Intern("replace")

var Lit_4 *jrt.String = jrt.Intern("reverse")

var Lit_5 *jrt.String = jrt.Intern("line")

var Lit_6 *jrt.String = jrt.Intern("column")

var Lit_7 *jrt.String = jrt.Intern("commute")

var Lit_8 *jrt.String = jrt.Intern("deref")

var Lit_9 *jrt.String = jrt.Intern("conj")

var Lit_10 *jrt.String = jrt.Intern("arbace.string")

var Lit_11 *jrt.String = jrt.Intern("doc")

var Lit_12 *jrt.String = jrt.Intern("Clojure String utilities\n\nIt is poor form to (:use arbace.string). Instead, use require\nwith :as to specify a prefix, e.g.\n\n(ns your.namespace.here\n  (:require [arbace.string :as str]))\n\nDesign notes for arbace.string:\n\n1. Strings are objects (as opposed to sequences). As such, the\n   string being manipulated is the first argument to a function;\n   passing nil will result in a NullPointerException unless\n   documented otherwise. If you want sequence-y behavior instead,\n   use a sequence.\n\n2. Functions are generally not lazy, and call straight to host\n   methods where those are available and efficient.\n\n3. Functions take advantage of String implementation details to\n   write high-performing loop/recurs instead of using higher-order\n   functions. (This is not idiomatic in general-purpose application\n   code.)\n\n4. When a function is documented to accept a string argument, it\n   will take any implementation of the correct *interface* on the\n   host platform. In Java, this is CharSequence, which is more\n   general than String. In ordinary usage you will almost always\n   pass concrete strings. If you are doing something unusual,\n   e.g. passing a mutable implementation of CharSequence, then\n   thread-safety is your responsibility.")

var Lit_13 *jrt.String = jrt.Intern("author")

var Lit_14 *jrt.String = jrt.Intern("Stuart Sierra, Stuart Halloway, David Liebke")

var Lit_15 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_16 *jrt.String = jrt.Intern("re-matcher")

var Lit_17 *jrt.String = jrt.Intern("re-groups")

var Lit_18 *jrt.String = jrt.Intern("replace-by")

var Lit_19 *jrt.String = jrt.Intern("else")

var Lit_20 *jrt.String = jrt.Intern("str")

var Lit_21 *jrt.String = jrt.Intern("subs")

var Lit_22 *jrt.String = jrt.Intern("replace-first-char")

var Lit_23 *jrt.String = jrt.Intern("replace-first-str")

var Lit_24 *jrt.String = jrt.Intern("replace-first-by")

var Lit_25 *jrt.String = jrt.Intern("next")

var Lit_26 *jrt.String = jrt.Intern("first")

var Lit_27 *jrt.String = jrt.Intern("apply")

var Lit_28 *jrt.String = jrt.Intern("split")

var Lit_29 *jrt.String = jrt.Intern("\\r?\\n")

var Lit_30 *jrt.String = jrt.Intern("arbace.string$blank_QMARK_")

var Lit_31 *jrt.String = jrt.Intern("arbace.string$capitalize")

var Lit_32 *jrt.String = jrt.Intern("arbace.string$ends_with_QMARK_")

var Lit_33 *jrt.String = jrt.Intern("arbace.string$escape")

var Lit_34 *jrt.String = jrt.Intern("arbace.string$eval885000004$loading__1927001464__auto____885000005")

var Lit_35 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_36 *jrt.String = jrt.Intern("java.util.regex.Matcher")

var Lit_37 *jrt.String = jrt.Intern("arbace.lang.LazilyPersistentVector")

var Lit_38 *jrt.String = jrt.Intern("arbace.string$eval885000008$fn__885000009")

var Lit_39 *jrt.String = jrt.Intern("arbace.string$includes_QMARK_")

var Lit_40 *jrt.String = jrt.Intern("arbace.string$index_of")

var Lit_41 *jrt.String = jrt.Intern("arbace.string$join")

var Lit_42 *jrt.String = jrt.Intern("arbace.string$last_index_of")

var Lit_43 *jrt.String = jrt.Intern("arbace.string$lower_case")

var Lit_44 *jrt.String = jrt.Intern("arbace.string$re_quote_replacement")

var Lit_45 *jrt.String = jrt.Intern("arbace.string$replace")

var Lit_46 *jrt.String = jrt.Intern("Invalid match arg: ")

var Lit_47 *jrt.String = jrt.Intern("arbace.string$replace_by")

var Lit_48 *jrt.String = jrt.Intern("arbace.string$replace_first")

var Lit_49 *jrt.String = jrt.Intern("arbace.string$replace_first_by")

var Lit_50 *jrt.String = jrt.Intern("arbace.string$replace_first_char")

var Lit_51 *jrt.String = jrt.Intern("arbace.string$replace_first_str")

var Lit_52 *jrt.String = jrt.Intern("arbace.string$reverse")

var Lit_53 *jrt.String = jrt.Intern("arbace.string$split")

var Lit_54 *jrt.String = jrt.Intern("arbace.string$split_lines")

var Lit_55 *jrt.String = jrt.Intern("arbace.string$starts_with_QMARK_")

var Lit_56 *jrt.String = jrt.Intern("arbace.string$trim")

var Lit_57 *jrt.String = jrt.Intern("")

var Lit_58 *jrt.String = jrt.Intern("arbace.string$trim_newline")

var Lit_59 *jrt.String = jrt.Intern("arbace.string$triml")

var Lit_60 *jrt.String = jrt.Intern("arbace.string$trimr")

var Lit_61 *jrt.String = jrt.Intern("arbace.string$upper_case")

var Lit_62 *jrt.String = jrt.Intern("in-ns")

var Lit_63 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_64 *jrt.String = jrt.Intern("tag")

var Lit_65 *jrt.String = jrt.Intern("java.lang.String")

var Lit_66 *jrt.String = jrt.Intern("arglists")

var Lit_67 *jrt.String = jrt.Intern("s")

var Lit_68 *jrt.String = jrt.Intern("CharSequence")

var Lit_69 *jrt.String = jrt.Intern("Returns s with its characters reversed.")

var Lit_70 *jrt.String = jrt.Intern("added")

var Lit_71 *jrt.String = jrt.Intern("1.2")

var Lit_72 *jrt.String = jrt.Intern("file")

var Lit_73 *jrt.String = jrt.Intern("arbace/string.ae")

var Lit_74 *jrt.String = jrt.Intern("re-quote-replacement")

var Lit_75 *jrt.String = jrt.Intern("replacement")

var Lit_76 *jrt.String = jrt.Intern("Given a replacement string that you wish to be a literal\n   replacement for a pattern match in replace or replace-first, do the\n   necessary escaping of special characters in the replacement.")

var Lit_77 *jrt.String = jrt.Intern("1.5")

var Lit_78 *jrt.String = jrt.Intern("private")

var Lit_79 *jrt.String = jrt.Intern("re")

var Lit_80 *jrt.String = jrt.Intern("f")

var Lit_81 *jrt.String = jrt.Intern("match")

var Lit_82 *jrt.String = jrt.Intern("Replaces all instance of match with replacement in s.\n\n   match/replacement can be:\n\n   string / string\n   char / char\n   pattern / (string or function of match).\n\n   See also replace-first.\n\n   The replacement is literal (i.e. none of its characters are treated\n   specially) for all cases above except pattern / string.\n\n   For pattern / string, $1, $2, etc. in the replacement string are\n   substituted with the string that matched the corresponding\n   parenthesized group in the pattern.  If you wish your replacement\n   string r to be used literally, use (re-quote-replacement r) as the\n   replacement argument.  See also documentation for\n   java.util.regex.Matcher's appendReplacement method.\n\n   Example:\n   (arbace.string/replace \"Almost Pig Latin\" #\"\\b(\\w)(\\w+)\\b\" \"$2$1ay\")\n   -> \"lmostAay igPay atinLay\"")

var Lit_83 *jrt.String = jrt.Intern("Pattern")

var Lit_84 *jrt.String = jrt.Intern("Character")

var Lit_85 *jrt.String = jrt.Intern("String")

var Lit_86 *jrt.String = jrt.Intern("replace-first")

var Lit_87 *jrt.String = jrt.Intern("Replaces the first instance of match with replacement in s.\n\n   match/replacement can be:\n\n   char / char\n   string / string\n   pattern / (string or function of match).\n\n   See also replace.\n\n   The replacement is literal (i.e. none of its characters are treated\n   specially) for all cases above except pattern / string.\n\n   For pattern / string, $1, $2, etc. in the replacement string are\n   substituted with the string that matched the corresponding\n   parenthesized group in the pattern.  If you wish your replacement\n   string r to be used literally, use (re-quote-replacement r) as the\n   replacement argument.  See also documentation for\n   java.util.regex.Matcher's appendReplacement method.\n\n   Example:\n   (arbace.string/replace-first \"swap first two words\"\n                                 #\"(\\w+)(\\s+)(\\w+)\" \"$3$2$1\")\n   -> \"first swap two words\"")

var Lit_88 *jrt.String = jrt.Intern("join")

var Lit_89 *jrt.String = jrt.Intern("coll")

var Lit_90 *jrt.String = jrt.Intern("separator")

var Lit_91 *jrt.String = jrt.Intern("Returns a string of all elements in coll, as returned by (seq coll),\n   separated by an optional separator.")

var Lit_92 *jrt.String = jrt.Intern("capitalize")

var Lit_93 *jrt.String = jrt.Intern("Converts first character of the string to upper-case, all other\n  characters to lower-case.")

var Lit_94 *jrt.String = jrt.Intern("upper-case")

var Lit_95 *jrt.String = jrt.Intern("Converts string to all upper-case.")

var Lit_96 *jrt.String = jrt.Intern("lower-case")

var Lit_97 *jrt.String = jrt.Intern("Converts string to all lower-case.")

var Lit_98 *jrt.String = jrt.Intern("limit")

var Lit_99 *jrt.String = jrt.Intern("Splits string on a regular expression.  Optional argument limit is\n  the maximum number of parts. Not lazy. Returns vector of the parts.\n  Trailing empty strings are not returned - pass limit of -1 to return all.")

var Lit_100 *jrt.String = jrt.Intern("split-lines")

var Lit_101 *jrt.String = jrt.Intern("Splits s on \\n or \\r\\n. Trailing empty lines are not returned.")

var Lit_102 *jrt.String = jrt.Intern("trim")

var Lit_103 *jrt.String = jrt.Intern("Removes whitespace from both ends of string.")

var Lit_104 *jrt.String = jrt.Intern("triml")

var Lit_105 *jrt.String = jrt.Intern("Removes whitespace from the left side of string.")

var Lit_106 *jrt.String = jrt.Intern("trimr")

var Lit_107 *jrt.String = jrt.Intern("Removes whitespace from the right side of string.")

var Lit_108 *jrt.String = jrt.Intern("trim-newline")

var Lit_109 *jrt.String = jrt.Intern("Removes all trailing newline \\n or return \\r characters from\n  string.  Similar to Perl's chomp.")

var Lit_110 *jrt.String = jrt.Intern("blank?")

var Lit_111 *jrt.String = jrt.Intern("True if s is nil, empty, or contains only whitespace.")

var Lit_112 *jrt.String = jrt.Intern("escape")

var Lit_113 *jrt.String = jrt.Intern("cmap")

var Lit_114 *jrt.String = jrt.Intern("Return a new string, using cmap to escape each character ch\n   from s as follows:\n\n   If (cmap ch) is nil, append ch to the new string.\n   If (cmap ch) is non-nil, append (str (cmap ch)) instead.")

var Lit_115 *jrt.String = jrt.Intern("index-of")

var Lit_116 *jrt.String = jrt.Intern("value")

var Lit_117 *jrt.String = jrt.Intern("from-index")

var Lit_118 *jrt.String = jrt.Intern("long")

var Lit_119 *jrt.String = jrt.Intern("Return index of value (string or char) in s, optionally searching\n  forward from from-index. Return nil if value not found.")

var Lit_120 *jrt.String = jrt.Intern("1.8")

var Lit_121 *jrt.String = jrt.Intern("last-index-of")

var Lit_122 *jrt.String = jrt.Intern("Return last index of value (string or char) in s, optionally\n  searching backward from from-index. Return nil if value not found.")

var Lit_123 *jrt.String = jrt.Intern("starts-with?")

var Lit_124 *jrt.String = jrt.Intern("substr")

var Lit_125 *jrt.String = jrt.Intern("True if s starts with substr.")

var Lit_126 *jrt.String = jrt.Intern("ends-with?")

var Lit_127 *jrt.String = jrt.Intern("True if s ends with substr.")

var Lit_128 *jrt.String = jrt.Intern("includes?")

var Lit_129 *jrt.String = jrt.Intern("True if s includes substr.")
