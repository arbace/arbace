//line aot_arbace_string.ae:1
package aot_arbace_string

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_New() *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A { A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_Init(); t := &A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_string_A_Init(); tmp4 = A_arbace_string_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_string_A_Init(); tmp6 = A_arbace_string_A_const_1; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_string_A_Init(); tmp8 = A_arbace_string_A_const_2; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_string_A_Init(); tmp10 = A_arbace_string_A_const_3; tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_35)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_36)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_37)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp14 != nil { panic(tmp14) }; return tmp3 }
//line :9:1
func A_arbace_string_eval885000008_fn__885000009_A_New() *A_arbace_string_eval885000008_fn__885000009_A { A_arbace_string_eval885000008_fn__885000009_A_Init(); t := &A_arbace_string_eval885000008_fn__885000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_string_eval885000008_fn__885000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_string_eval885000008_fn__885000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_string_A_Init(); tmp5 = A_arbace_string_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_string_A_Init(); tmp7 = A_arbace_string_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_string_A_Init(); tmp9 = A_arbace_string_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }






































func A_arbace_string_reverse_A_New() *A_arbace_string_reverse_A { A_arbace_string_reverse_A_Init(); t := &A_arbace_string_reverse_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_string_reverse_A) Ctor() {}
//line :48:1
func (t *A_arbace_string_reverse_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.StringBuilder_New_CharSequence(jrt.CharSequence_Cast(s__0)).Reverse__StringBuilder()).ToString__String().Ref()
}
func A_arbace_string_re_quote_replacement_A_New() *A_arbace_string_re_quote_replacement_A { A_arbace_string_re_quote_replacement_A_Init(); t := &A_arbace_string_re_quote_replacement_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_string_re_quote_replacement_A) Ctor() {}
//line :54:1
func (t *A_arbace_string_re_quote_replacement_A) Invoke_O_O__O(self, replacement__0 any) any {





	return jrt.Matcher_QuoteReplacement_String__String(jrt.ToString(replacement__0)).Ref()
}
func A_arbace_string_replace_by_A_New() *A_arbace_string_replace_by_A { A_arbace_string_replace_by_A_Init(); t := &A_arbace_string_replace_by_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_string_replace_by_A) Ctor() {}
//line :62:1
func (t *A_arbace_string_replace_by_A) Invoke_O_O_O_O__O(self, s__0, re__1, f__2 any) any { { var m__4 any; var tmp1 *lang.Var

	A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_9; m__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(re__1, s__0)
	if jrt.NN(jrt.Matcher_Cast(m__4)).Find__Z() { var buffer__5 any = jrt.StringBuffer_New_I(jrt.CharSequence_Cast(s__0).Length__I()); var found__6 any; jrt.Boolean_Init(); found__6 = jrt.Boolean_TRUE.Ref(); L1: for {


		if jrt.A2g_Truth(found__6) {
			var tmp2 *jrt.Matcher = jrt.Matcher_Cast(m__4); var tmp3 *jrt.StringBuffer = jrt.StringBuffer_Cast(buffer__5); var tmp4 lang.IFn = lang.IFn_Cast(f__2); var tmp5 *lang.Var; A_arbace_string_A_Init(); tmp5 = A_arbace_string_A_const_10; jrt.NN(tmp2).AppendReplacement_StringBuffer_String__Matcher(tmp3, jrt.Matcher_QuoteReplacement_String__String(jrt.String_Cast(tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(m__4)))))
			found__6 = jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Matcher_Cast(m__4)).Find__Z()).Ref(); continue L1 } else {
				jrt.NN(jrt.Matcher_Cast(m__4)).AppendTail_StringBuffer__StringBuffer(jrt.StringBuffer_Cast(buffer__5))
				return jrt.NN(jrt.StringBuffer_Cast(buffer__5)).ToString__String().Ref() } } } else {
//line :65:1
					return s__0 } }; /*line :62:1*/panic("a2g: unreachable") }












func A_arbace_string_replace_A_New() *A_arbace_string_replace_A { A_arbace_string_replace_A_Init(); t := &A_arbace_string_replace_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_string_replace_A) Ctor() {}
//line :75:1
func (t *A_arbace_string_replace_A) Invoke_O_O_O_O__O(self, s__0, match__1, replacement__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); if


























	jrt.Character_InstanceOf(match__1) {
		return jrt.NN(jrt.String_Cast(s__4)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(match__1)).CharValue__C(), jrt.NN(jrt.Character_Cast(replacement__2)).CharValue__C()).Ref() } else {
//line :102:1
			if jrt.CharSequence_InstanceOf(match__1) {

				return jrt.NN(jrt.String_Cast(s__4)).Replace_CharSequence_CharSequence__String(jrt.CharSequence_Cast(match__1), jrt.CharSequence_Cast(replacement__2)).Ref() } else {
//line :102:1
					if jrt.Pattern_InstanceOf(match__1) {


						if jrt.CharSequence_InstanceOf(replacement__2) {
							var tmp1 *lang.Var; A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_9; return jrt.NN(jrt.Matcher_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(match__1, s__4))).ReplaceAll_String__String(jrt.ToString(replacement__2)).Ref() } else {

								var tmp2 *lang.Var; A_arbace_string_A_Init(); tmp2 = A_arbace_string_A_const_11; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(s__4, match__1, replacement__2) } } else {
//line :102:1
									var tmp3 *lang.Keyword; A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_12; if tmp3 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, match__1))))) } else { return nil } } } } }








func A_arbace_string_replace_first_by_A_New() *A_arbace_string_replace_first_by_A { A_arbace_string_replace_first_by_A_Init(); t := &A_arbace_string_replace_first_by_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_string_replace_first_by_A) Ctor() {}
//line :111:1
func (t *A_arbace_string_replace_first_by_A) Invoke_O_O_O_O__O(self, s__0, re__1, f__2 any) any { var m__4 any; var tmp1 *lang.Var;

	A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_9; m__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(re__1, s__0); if
	jrt.NN(jrt.Matcher_Cast(m__4)).Find__Z() { var buffer__5 any = jrt.StringBuffer_New_I(jrt.CharSequence_Cast(s__0).Length__I()); var rep__6 any; var tmp2 lang.IFn = lang.IFn_Cast(f__2); var tmp3 *lang.Var

		A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_10; rep__6 = jrt.Matcher_QuoteReplacement_String__String(jrt.String_Cast(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(m__4)))).Ref()
		jrt.NN(jrt.Matcher_Cast(m__4)).AppendReplacement_StringBuffer_String__Matcher(jrt.StringBuffer_Cast(buffer__5), jrt.String_Cast(rep__6))
		jrt.NN(jrt.Matcher_Cast(m__4)).AppendTail_StringBuffer__StringBuffer(jrt.StringBuffer_Cast(buffer__5))
		var tmp4 *lang.Var; A_arbace_string_A_Init(); tmp4 = A_arbace_string_A_const_13; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(buffer__5) } else {
//line :114:1
			return s__0 } }







func A_arbace_string_replace_first_char_A_New() *A_arbace_string_replace_first_char_A { A_arbace_string_replace_first_char_A_Init(); t := &A_arbace_string_replace_first_char_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_string_replace_first_char_A) Ctor() {}
//line :122:1
func (t *A_arbace_string_replace_first_char_A) Invoke_O_O_O_O__O(self, s__0, match__1, replace__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); var i__5 int32 = jrt.NN(jrt.String_Cast(s__4)).IndexOf_I__I(lang.RT_IntCast_O__I(match__1)); if



	lang.Util_Equiv_J_J__Z(-1, int64(i__5)) { return s__4 } else {

		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *lang.Var; A_arbace_string_A_Init(); tmp2 = A_arbace_string_A_const_14; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_string_A_Init(); tmp4 = A_arbace_string_A_const_15; var tmp5 any = tmp4; var tmp6 any = tmp3.Invoke_O_O_O__O(s__4, tmp5, jrt.Integer_ValueOf_I__Integer(i__5).Ref()); var tmp7 *lang.Var; A_arbace_string_A_Init(); tmp7 = A_arbace_string_A_const_14; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp6, replace__2, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(s__4, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(i__5))).Ref()))).Ref() } }

func A_arbace_string_replace_first_str_A_New() *A_arbace_string_replace_first_str_A { A_arbace_string_replace_first_str_A_Init(); t := &A_arbace_string_replace_first_str_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_string_replace_first_str_A) Ctor() {}
//line :130:1
func (t *A_arbace_string_replace_first_str_A) Invoke_O_O_O_O__O(self, s__0, match__1, replace__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); var i__5 int32 = jrt.NN(jrt.String_Cast(s__4)).IndexOf_String__I(jrt.String_Cast(match__1)); if



	lang.Util_Equiv_J_J__Z(-1, int64(i__5)) { return s__4 } else {

		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *lang.Var; A_arbace_string_A_Init(); tmp2 = A_arbace_string_A_const_14; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_string_A_Init(); tmp4 = A_arbace_string_A_const_15; var tmp5 any = tmp4; var tmp6 any = tmp3.Invoke_O_O_O__O(s__4, tmp5, jrt.Integer_ValueOf_I__Integer(i__5).Ref()); var tmp7 *lang.Var; A_arbace_string_A_Init(); tmp7 = A_arbace_string_A_const_14; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp6, replace__2, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(s__4, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(int64(i__5), int64(jrt.NN(jrt.String_Cast(match__1)).Length__I()))).Ref()))).Ref() } }

func A_arbace_string_replace_first_A_New() *A_arbace_string_replace_first_A { A_arbace_string_replace_first_A_Init(); t := &A_arbace_string_replace_first_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_string_replace_first_A) Ctor() {}
//line :138:1
func (t *A_arbace_string_replace_first_A) Invoke_O_O_O_O__O(self, s__0, match__1, replacement__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); if



























	jrt.Character_InstanceOf(match__1) {

		var tmp1 *lang.Var; A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(s__4, match__1, replacement__2) } else {
//line :166:1
			if jrt.CharSequence_InstanceOf(match__1) {



				var tmp2 *lang.Var; A_arbace_string_A_Init(); tmp2 = A_arbace_string_A_const_17; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(s__4, jrt.ToString(match__1).Ref(), jrt.ToString(replacement__2).Ref()) } else {
//line :166:1
					if jrt.Pattern_InstanceOf(match__1) {






						if jrt.CharSequence_InstanceOf(replacement__2) {
							var tmp3 *lang.Var; A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_9; return jrt.NN(jrt.Matcher_Cast(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(match__1, s__4))).ReplaceFirst_String__String(jrt.ToString(replacement__2)).Ref() } else {

								var tmp4 *lang.Var; A_arbace_string_A_Init(); tmp4 = A_arbace_string_A_const_18; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O__O(s__4, match__1, replacement__2) } } else {
//line :166:1
									var tmp5 *lang.Keyword; A_arbace_string_A_Init(); tmp5 = A_arbace_string_A_const_12; if tmp5 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, match__1))))) } else { return nil } } } } }












func A_arbace_string_join_A_New() *A_arbace_string_join_A { A_arbace_string_join_A_Init(); t := &A_arbace_string_join_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_string_join_A) Ctor() {}
//line :179:1
func (t *A_arbace_string_join_A) Invoke_O_O_O__O(self, separator__0, coll__1 any) any { { var sb__3 any; var tmp1 *lang.Var; A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_13; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_20; sb__3 = jrt.StringBuilder_New_String(jrt.String_Cast(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(coll__1)))); var more__4 any; var tmp4 *lang.Var







	A_arbace_string_A_Init(); tmp4 = A_arbace_string_A_const_19; more__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(coll__1)
//line :179:1
	var sep__5 any; var tmp5 *lang.Var








	A_arbace_string_A_Init(); tmp5 = A_arbace_string_A_const_13; sep__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(separator__0)
//line :179:1
L1: for {









	if jrt.A2g_Truth(more__4) {
		var tmp6 *jrt.StringBuilder = jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(sep__5)); var tmp7 *lang.Var; A_arbace_string_A_Init(); tmp7 = A_arbace_string_A_const_13; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_string_A_Init(); tmp9 = A_arbace_string_A_const_20; var tmp10 any = jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(more__4)))).Ref(); var tmp11 *lang.Var; A_arbace_string_A_Init(); tmp11 = A_arbace_string_A_const_19; sb__3, more__4, sep__5 = tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(more__4), sep__5; continue L1 } else {


			var tmp12 *lang.Var; A_arbace_string_A_Init(); tmp12 = A_arbace_string_A_const_13; return lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(sb__3) } } }; /*line :179:1*/panic("a2g: unreachable") }
//line :179:1
func (t *A_arbace_string_join_A) Invoke_O_O__O(self, coll__0 any) any {




	var tmp1 *lang.Var; A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_13; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), coll__0)
}









func A_arbace_string_capitalize_A_New() *A_arbace_string_capitalize_A { A_arbace_string_capitalize_A_Init(); t := &A_arbace_string_capitalize_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_string_capitalize_A) Ctor() {}
//line :195:1
func (t *A_arbace_string_capitalize_A) Invoke_O_O__O(self, s__0 any) any { var s__2 any = jrt.ToString(s__0).Ref(); if





	lang.Numbers_Lt_J_J__Z(int64(lang.RT_Count_O__I(s__2)), 2) {
		return jrt.NN(jrt.String_Cast(s__2)).ToUpperCase__String().Ref() } else {
			var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 *lang.Var; A_arbace_string_A_Init(); tmp2 = A_arbace_string_A_const_14; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_string_A_Init(); tmp4 = A_arbace_string_A_const_15; var tmp5 any = tmp4; var tmp6 any; A_arbace_string_A_Init(); tmp6 = A_arbace_string_A_const_22; var tmp7 any = jrt.NN(jrt.String_Cast(tmp3.Invoke_O_O_O__O(s__2, tmp5, tmp6))).ToUpperCase__String().Ref(); var tmp8 *lang.Var; A_arbace_string_A_Init(); tmp8 = A_arbace_string_A_const_14; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_string_A_Init(); tmp10 = A_arbace_string_A_const_22; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp7, jrt.NN(jrt.String_Cast(tmp9.Invoke_O_O__O(s__2, tmp10))).ToLowerCase__String().Ref())).Ref() } }


func A_arbace_string_upper_case_A_New() *A_arbace_string_upper_case_A { A_arbace_string_upper_case_A_Init(); t := &A_arbace_string_upper_case_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_string_upper_case_A) Ctor() {}
//line :206:1
func (t *A_arbace_string_upper_case_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.ToString(s__0)).ToUpperCase__String().Ref()
}
func A_arbace_string_lower_case_A_New() *A_arbace_string_lower_case_A { A_arbace_string_lower_case_A_Init(); t := &A_arbace_string_lower_case_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_string_lower_case_A) Ctor() {}
//line :212:1
func (t *A_arbace_string_lower_case_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.ToString(s__0)).ToLowerCase__String().Ref()
}
func A_arbace_string_split_A_New() *A_arbace_string_split_A { A_arbace_string_split_A_Init(); t := &A_arbace_string_split_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_string_split_A) Ctor() {}
//line :218:1
func (t *A_arbace_string_split_A) Invoke_O_O_O_O__O(self, s__0, re__1, limit__2 any) any {







	return lang.LazilyPersistentVector_CreateOwning_O1__IPersistentVector(jrt.NN(jrt.Pattern_Cast(re__1)).Split_CharSequence_I__String1(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I(limit__2))) }
//line :218:1
func (t *A_arbace_string_split_A) Invoke_O_O_O__O(self, s__0, re__1 any) any {





	return lang.LazilyPersistentVector_CreateOwning_O1__IPersistentVector(jrt.NN(jrt.Pattern_Cast(re__1)).Split_CharSequence__String1(jrt.CharSequence_Cast(s__0)))
}


func A_arbace_string_split_lines_A_New() *A_arbace_string_split_lines_A { A_arbace_string_split_lines_A_Init(); t := &A_arbace_string_split_lines_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_string_split_lines_A) Ctor() {}
//line :228:1
func (t *A_arbace_string_split_lines_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Var; A_arbace_string_A_Init(); tmp1 = A_arbace_string_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_24; return tmp2.Invoke_O_O__O(s__0, tmp3)
}
func A_arbace_string_trim_A_New() *A_arbace_string_trim_A { A_arbace_string_trim_A_Init(); t := &A_arbace_string_trim_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_string_trim_A) Ctor() {}
//line :234:1
func (t *A_arbace_string_trim_A) Invoke_O_O__O(self, s__0 any) any { { var len__2 int32 = jrt.CharSequence_Cast(s__0).Length__I(); var rindex__3 int64 = lang.RT_LongCast_I__J(len__2); L1: for {





	if lang.Numbers_IsZero_J__Z(rindex__3) { return Lit_57 } else {

		if jrt.Character_IsWhitespace_C__Z(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(rindex__3)))) {
			rindex__3 = lang.Numbers_Dec_J__J(rindex__3); continue L1 } else {
//line :242:1
				var lindex__4 int64 = 0; L2: for {




					if jrt.Character_IsWhitespace_C__Z(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I(lindex__4))) {
						lindex__4 = lang.Numbers_Inc_J__J(lindex__4); continue L2 } else {
							return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I(lindex__4), lang.RT_IntCast_J__I(rindex__3))).Ref() } } } } } }; /*line :234:1*/panic("a2g: unreachable") }
















func A_arbace_string_triml_A_New() *A_arbace_string_triml_A { A_arbace_string_triml_A_Init(); t := &A_arbace_string_triml_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_string_triml_A) Ctor() {}
//line :251:1
func (t *A_arbace_string_triml_A) Invoke_O_O__O(self, s__0 any) any { { var len__2 int32 = jrt.CharSequence_Cast(s__0).Length__I(); var index__3 int64 = 0; L1: for {





	if lang.Util_Equiv_J_J__Z(int64(len__2), index__3) { return Lit_57 } else {

		if jrt.Character_IsWhitespace_C__Z(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I(index__3))) {
			index__3 = lang.Numbers_Unchecked_inc_J__J(index__3); continue L1 } else {
				return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I(index__3), len__2)).Ref() } } } }; /*line :251:1*/panic("a2g: unreachable") }











func A_arbace_string_trimr_A_New() *A_arbace_string_trimr_A { A_arbace_string_trimr_A_Init(); t := &A_arbace_string_trimr_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_string_trimr_A) Ctor() {}
//line :263:1
func (t *A_arbace_string_trimr_A) Invoke_O_O__O(self, s__0 any) any { { var index__2 int64 = lang.RT_LongCast_I__J(jrt.CharSequence_Cast(s__0).Length__I()); L1: for {




	if lang.Numbers_IsZero_J__Z(index__2) { return Lit_57 } else {

		if jrt.Character_IsWhitespace_C__Z(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Unchecked_dec_J__J(index__2)))) {
			index__2 = lang.Numbers_Unchecked_dec_J__J(index__2); continue L1 } else {
				return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(index__2))).Ref() } } } }; /*line :263:1*/panic("a2g: unreachable") }










func A_arbace_string_trim_newline_A_New() *A_arbace_string_trim_newline_A { A_arbace_string_trim_newline_A_Init(); t := &A_arbace_string_trim_newline_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_string_trim_newline_A) Ctor() {}
//line :274:1
func (t *A_arbace_string_trim_newline_A) Invoke_O_O__O(self, s__0 any) any { { var index__2 int64 = lang.RT_LongCast_I__J(jrt.CharSequence_Cast(s__0).Length__I()); L1: for {





	if lang.Numbers_IsZero_J__Z(index__2) { return Lit_57 } else { var ch__3 uint16 = jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(index__2))); var tmp1 bool; var or__1927000174__auto____4 bool; var tmp2 any


		A_arbace_string_A_Init(); tmp2 = A_arbace_string_A_const_25; or__1927000174__auto____4 = lang.Util_Equiv_C_C__Z(ch__3, jrt.NN(jrt.Character_Cast(tmp2)).CharValue__C()); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { var tmp3 any; A_arbace_string_A_Init(); tmp3 = A_arbace_string_A_const_26; tmp1 = lang.Util_Equiv_C_C__Z(ch__3, jrt.NN(jrt.Character_Cast(tmp3)).CharValue__C()) }; if tmp1 {
			index__2 = lang.Numbers_Dec_J__J(index__2); continue L1 } else {
				return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(index__2))).Ref() } } } }; /*line :274:1*/panic("a2g: unreachable") }












func A_arbace_string_blank_QMARK__A_New() *A_arbace_string_blank_QMARK__A { A_arbace_string_blank_QMARK__A_Init(); t := &A_arbace_string_blank_QMARK__A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_string_blank_QMARK__A) Ctor() {}
//line :287:1
func (t *A_arbace_string_blank_QMARK__A) Invoke_O_O__O(self, s__0 any) any {



	if jrt.A2g_Truth(s__0) { var index__2 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for {

		if lang.Util_Equiv_J_J__Z(int64(jrt.CharSequence_Cast(s__0).Length__I()), index__2) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else {

			if jrt.Character_IsWhitespace_C__Z(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I(index__2))) {
				index__2 = lang.Numbers_Inc_J__J(index__2); continue L1 } else {
//line :295:1
					jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } } } } else {
//line :291:1
						jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }
//line :287:1
	panic("a2g: unreachable")
}











func A_arbace_string_escape_A_New() *A_arbace_string_escape_A { A_arbace_string_escape_A_Init(); t := &A_arbace_string_escape_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_string_escape_A) Ctor() {}
//line :300:1
func (t *A_arbace_string_escape_A) Invoke_O_O_O__O(self, s__0, cmap__1 any) any { { var index__3 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); var buffer__4 any = jrt.StringBuilder_New_I(jrt.CharSequence_Cast(s__0).Length__I()); L1: for {









	if lang.Util_Equiv_J_J__Z(int64(jrt.CharSequence_Cast(s__0).Length__I()), index__3) {
		return jrt.NN(jrt.StringBuilder_Cast(buffer__4)).ToString__String().Ref() } else {
//line :310:1
			var ch__5 uint16 = jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I(index__3)); var temp__1927000408__auto____6 any = lang.IFn_Cast(cmap__1).Invoke_O__O(jrt.Character_ValueOf_C__Character(ch__5).Ref())


			if jrt.A2g_Truth(temp__1927000408__auto____6) { var replacement__7 any = temp__1927000408__auto____6
				jrt.NN(jrt.StringBuilder_Cast(buffer__4)).Append_O__StringBuilder(replacement__7) } else {
					jrt.NN(jrt.StringBuilder_Cast(buffer__4)).Append_C__StringBuilder(ch__5) }
			index__3, buffer__4 = lang.Numbers_Inc_J__J(index__3), buffer__4; continue L1 } } }; /*line :300:1*/panic("a2g: unreachable") }

















func A_arbace_string_index_of_A_New() *A_arbace_string_index_of_A { A_arbace_string_index_of_A_Init(); t := &A_arbace_string_index_of_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_string_index_of_A) Ctor() {}
//line :318:1
func (t *A_arbace_string_index_of_A) Invoke_O_O_O_O__O(self, s__0, value__1, p_from_index__2 any) any { var from_index__2 int64 = lang.RT_LongCast_O__J(p_from_index__2); var result__4 int32; if












	jrt.Character_InstanceOf(value__1) {

		result__4 = jrt.NN(jrt.ToString(s__0)).IndexOf_I_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C()), lang.RT_UncheckedIntCast_J__I(from_index__2)) } else {
			result__4 = jrt.NN(jrt.ToString(s__0)).IndexOf_String_I__I(jrt.String_Cast(value__1), lang.RT_UncheckedIntCast_J__I(from_index__2)) }; if
	lang.Util_Equiv_J_J__Z(int64(result__4), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer(result__4).Ref() } }
//line :318:1
func (t *A_arbace_string_index_of_A) Invoke_O_O_O__O(self, s__0, value__1 any) any { var result__3 int32; if




	jrt.Character_InstanceOf(value__1) {

		result__3 = jrt.NN(jrt.ToString(s__0)).IndexOf_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C())) } else {
			result__3 = jrt.NN(jrt.ToString(s__0)).IndexOf_String__I(jrt.String_Cast(value__1)) }; if
	lang.Util_Equiv_J_J__Z(int64(result__3), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer(result__3).Ref() } }











func A_arbace_string_last_index_of_A_New() *A_arbace_string_last_index_of_A { A_arbace_string_last_index_of_A_Init(); t := &A_arbace_string_last_index_of_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_string_last_index_of_A) Ctor() {}
//line :339:1
func (t *A_arbace_string_last_index_of_A) Invoke_O_O_O_O__O(self, s__0, value__1, p_from_index__2 any) any { var from_index__2 int64 = lang.RT_LongCast_O__J(p_from_index__2); var result__4 int32; if












	jrt.Character_InstanceOf(value__1) {

		result__4 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_I_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C()), lang.RT_UncheckedIntCast_J__I(from_index__2)) } else {
			result__4 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_String_I__I(jrt.String_Cast(value__1), lang.RT_UncheckedIntCast_J__I(from_index__2)) }; if
	lang.Util_Equiv_J_J__Z(int64(result__4), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer(result__4).Ref() } }
//line :339:1
func (t *A_arbace_string_last_index_of_A) Invoke_O_O_O__O(self, s__0, value__1 any) any { var result__3 int32; if




	jrt.Character_InstanceOf(value__1) {

		result__3 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C())) } else {
			result__3 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_String__I(jrt.String_Cast(value__1)) }; if
	lang.Util_Equiv_J_J__Z(int64(result__3), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer(result__3).Ref() } }











func A_arbace_string_starts_with_QMARK__A_New() *A_arbace_string_starts_with_QMARK__A { A_arbace_string_starts_with_QMARK__A_Init(); t := &A_arbace_string_starts_with_QMARK__A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_string_starts_with_QMARK__A) Ctor() {}
//line :360:1
func (t *A_arbace_string_starts_with_QMARK__A) Invoke_O_O_O__O(self, s__0, substr__1 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.ToString(s__0)).StartsWith_String__Z(jrt.String_Cast(substr__1))).Ref()
}
func A_arbace_string_ends_with_QMARK__A_New() *A_arbace_string_ends_with_QMARK__A { A_arbace_string_ends_with_QMARK__A_Init(); t := &A_arbace_string_ends_with_QMARK__A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_string_ends_with_QMARK__A) Ctor() {}
//line :366:1
func (t *A_arbace_string_ends_with_QMARK__A) Invoke_O_O_O__O(self, s__0, substr__1 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.ToString(s__0)).EndsWith_String__Z(jrt.String_Cast(substr__1))).Ref()
}
func A_arbace_string_includes_QMARK__A_New() *A_arbace_string_includes_QMARK__A { A_arbace_string_includes_QMARK__A_Init(); t := &A_arbace_string_includes_QMARK__A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_string_includes_QMARK__A) Ctor() {}
//line :372:1
func (t *A_arbace_string_includes_QMARK__A) Invoke_O_O_O__O(self, s__0, substr__1 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.ToString(s__0)).Contains_CharSequence__Z(jrt.CharSequence_Cast(substr__1))).Ref()
}


type A_arbace_string_A struct{ jrt.Object }

var A_arbace_string_A_const_0 *lang.Var

var A_arbace_string_A_const_1 any

var A_arbace_string_A_const_2 *lang.Keyword

var A_arbace_string_A_const_3 any

var A_arbace_string_A_const_4 *lang.Var

var A_arbace_string_A_const_5 *lang.Var

var A_arbace_string_A_const_6 *lang.Var

var A_arbace_string_A_const_7 any

var A_arbace_string_A_const_8 *lang.Var

var A_arbace_string_A_const_9 *lang.Var

var A_arbace_string_A_const_10 *lang.Var

var A_arbace_string_A_const_11 *lang.Var

var A_arbace_string_A_const_12 *lang.Keyword

var A_arbace_string_A_const_13 *lang.Var

var A_arbace_string_A_const_14 *lang.Var

var A_arbace_string_A_const_15 any

var A_arbace_string_A_const_16 *lang.Var

var A_arbace_string_A_const_17 *lang.Var

var A_arbace_string_A_const_18 *lang.Var

var A_arbace_string_A_const_19 *lang.Var

var A_arbace_string_A_const_20 *lang.Var

var A_arbace_string_A_const_21 *lang.Var

var A_arbace_string_A_const_22 any

var A_arbace_string_A_const_23 *lang.Var

var A_arbace_string_A_const_24 any

var A_arbace_string_A_const_25 any

var A_arbace_string_A_const_26 any

var A_arbace_string_A_init jrt.ClassInit

func A_arbace_string_A_Init() { if !A_arbace_string_A_init.Done() { A_arbace_string_A_init.Run(A_arbace_string_A_clinit) } }

func A_arbace_string_A_clinit() { A_arbace_string_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_string_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_string_A_const_2 = lang.RT_Keyword_String_String__Keyword(nil, Lit_2); A_arbace_string_A_const_3 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref()))); A_arbace_string_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_string_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_string_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_string_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_14))); A_arbace_string_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_string_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_string_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_string_A_const_11 = lang.RT_Var_String_String__Var(Lit_10, Lit_18); A_arbace_string_A_const_12 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_string_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_string_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_string_A_const_15 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_string_A_const_16 = lang.RT_Var_String_String__Var(Lit_10, Lit_22); A_arbace_string_A_const_17 = lang.RT_Var_String_String__Var(Lit_10, Lit_23); A_arbace_string_A_const_18 = lang.RT_Var_String_String__Var(Lit_10, Lit_24); A_arbace_string_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_string_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_string_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_string_A_const_22 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_string_A_const_23 = lang.RT_Var_String_String__Var(Lit_10, Lit_28); A_arbace_string_A_const_24 = jrt.Pattern_Compile_String__Pattern(Lit_29).Ref(); A_arbace_string_A_const_25 = jrt.Character_ValueOf_C__Character(10).Ref(); A_arbace_string_A_const_26 = jrt.Character_ValueOf_C__Character(13).Ref() }

func A_arbace_string_A_New() *A_arbace_string_A { A_arbace_string_A_Init(); t := &A_arbace_string_A{}; t.Ctor(); return t }

func (t *A_arbace_string_A) Ctor() {}

func (t *A_arbace_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_A) GetClass__Class() *jrt.Class { return A_arbace_string_A_class }

func (t *A_arbace_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_A); return ok }

func A_arbace_string_A_Cast(x any) *A_arbace_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_A_class)) }; return v }



type A_arbace_string_blank_QMARK__A struct{ jrt.Object }

func (t *A_arbace_string_blank_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_string_blank_QMARK__A_fn_class *jrt.Class

var A_arbace_string_blank_QMARK__A_init jrt.ClassInit

func A_arbace_string_blank_QMARK__A_Init() { if !A_arbace_string_blank_QMARK__A_init.Done() { A_arbace_string_blank_QMARK__A_init.Run(A_arbace_string_blank_QMARK__A_clinit) } }

func A_arbace_string_blank_QMARK__A_clinit() { A_arbace_string_blank_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_30, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_blank_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_blank_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_string_blank_QMARK__A_class }

func (t *A_arbace_string_blank_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_blank_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_blank_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_blank_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_blank_QMARK__A); return ok }

func A_arbace_string_blank_QMARK__A_Cast(x any) *A_arbace_string_blank_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_blank_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_blank_QMARK__A_class)) }; return v }



type A_arbace_string_capitalize_A struct{ jrt.Object }

func (t *A_arbace_string_capitalize_A) Is_Compiler_AOTF1() {}

var A_arbace_string_capitalize_A_fn_class *jrt.Class

var A_arbace_string_capitalize_A_init jrt.ClassInit

func A_arbace_string_capitalize_A_Init() { if !A_arbace_string_capitalize_A_init.Done() { A_arbace_string_capitalize_A_init.Run(A_arbace_string_capitalize_A_clinit) } }

func A_arbace_string_capitalize_A_clinit() { A_arbace_string_capitalize_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_31, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_capitalize_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_capitalize_A) GetClass__Class() *jrt.Class { return A_arbace_string_capitalize_A_class }

func (t *A_arbace_string_capitalize_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_capitalize_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_capitalize_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_capitalize_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_capitalize_A); return ok }

func A_arbace_string_capitalize_A_Cast(x any) *A_arbace_string_capitalize_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_capitalize_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_capitalize_A_class)) }; return v }



type A_arbace_string_ends_with_QMARK__A struct{ jrt.Object }

func (t *A_arbace_string_ends_with_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_string_ends_with_QMARK__A_fn_class *jrt.Class

var A_arbace_string_ends_with_QMARK__A_init jrt.ClassInit

func A_arbace_string_ends_with_QMARK__A_Init() { if !A_arbace_string_ends_with_QMARK__A_init.Done() { A_arbace_string_ends_with_QMARK__A_init.Run(A_arbace_string_ends_with_QMARK__A_clinit) } }

func A_arbace_string_ends_with_QMARK__A_clinit() { A_arbace_string_ends_with_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_32, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_ends_with_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_ends_with_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_string_ends_with_QMARK__A_class }

func (t *A_arbace_string_ends_with_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_ends_with_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_ends_with_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_ends_with_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_ends_with_QMARK__A); return ok }

func A_arbace_string_ends_with_QMARK__A_Cast(x any) *A_arbace_string_ends_with_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_ends_with_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_ends_with_QMARK__A_class)) }; return v }



type A_arbace_string_escape_A struct{ jrt.Object }

func (t *A_arbace_string_escape_A) Is_Compiler_AOTF2() {}

var A_arbace_string_escape_A_fn_class *jrt.Class

var A_arbace_string_escape_A_init jrt.ClassInit

func A_arbace_string_escape_A_Init() { if !A_arbace_string_escape_A_init.Done() { A_arbace_string_escape_A_init.Run(A_arbace_string_escape_A_clinit) } }

func A_arbace_string_escape_A_clinit() { A_arbace_string_escape_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_33, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_escape_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_escape_A) GetClass__Class() *jrt.Class { return A_arbace_string_escape_A_class }

func (t *A_arbace_string_escape_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_escape_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_escape_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_escape_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_escape_A); return ok }

func A_arbace_string_escape_A_Cast(x any) *A_arbace_string_escape_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_escape_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_escape_A_class)) }; return v }



type A_arbace_string_eval885000004_A struct{ jrt.Object }

func A_arbace_string_eval885000004_A_New() *A_arbace_string_eval885000004_A { t := &A_arbace_string_eval885000004_A{}; t.Ctor(); return t }

func (t *A_arbace_string_eval885000004_A) Ctor() {}

func (t *A_arbace_string_eval885000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_eval885000004_A) GetClass__Class() *jrt.Class { return A_arbace_string_eval885000004_A_class }

func (t *A_arbace_string_eval885000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_eval885000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_eval885000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_eval885000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_eval885000004_A); return ok }

func A_arbace_string_eval885000004_A_Cast(x any) *A_arbace_string_eval885000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_eval885000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_eval885000004_A_class)) }; return v }



type A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A struct{ jrt.Object }

func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) Is_Compiler_AOTF0() {}

var A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_fn_class *jrt.Class

var A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_init jrt.ClassInit

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_Init() { if !A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_init.Done() { A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_init.Run(A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_clinit) } }

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_clinit() { A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_34, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) GetClass__Class() *jrt.Class { return A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_class }

func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A); return ok }

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_Cast(x any) *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_class)) }; return v }



type A_arbace_string_eval885000008_A struct{ jrt.Object }

func A_arbace_string_eval885000008_A_New() *A_arbace_string_eval885000008_A { t := &A_arbace_string_eval885000008_A{}; t.Ctor(); return t }

func (t *A_arbace_string_eval885000008_A) Ctor() {}

func (t *A_arbace_string_eval885000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_eval885000008_A) GetClass__Class() *jrt.Class { return A_arbace_string_eval885000008_A_class }

func (t *A_arbace_string_eval885000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_eval885000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_eval885000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_eval885000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_eval885000008_A); return ok }

func A_arbace_string_eval885000008_A_Cast(x any) *A_arbace_string_eval885000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_eval885000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_eval885000008_A_class)) }; return v }



type A_arbace_string_eval885000008_fn__885000009_A struct{ jrt.Object }

func (t *A_arbace_string_eval885000008_fn__885000009_A) Is_Compiler_AOTF0() {}

var A_arbace_string_eval885000008_fn__885000009_A_fn_class *jrt.Class

var A_arbace_string_eval885000008_fn__885000009_A_init jrt.ClassInit

func A_arbace_string_eval885000008_fn__885000009_A_Init() { if !A_arbace_string_eval885000008_fn__885000009_A_init.Done() { A_arbace_string_eval885000008_fn__885000009_A_init.Run(A_arbace_string_eval885000008_fn__885000009_A_clinit) } }

func A_arbace_string_eval885000008_fn__885000009_A_clinit() { A_arbace_string_eval885000008_fn__885000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_38, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_eval885000008_fn__885000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_eval885000008_fn__885000009_A) GetClass__Class() *jrt.Class { return A_arbace_string_eval885000008_fn__885000009_A_class }

func (t *A_arbace_string_eval885000008_fn__885000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_eval885000008_fn__885000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_eval885000008_fn__885000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_eval885000008_fn__885000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_eval885000008_fn__885000009_A); return ok }

func A_arbace_string_eval885000008_fn__885000009_A_Cast(x any) *A_arbace_string_eval885000008_fn__885000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_eval885000008_fn__885000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_eval885000008_fn__885000009_A_class)) }; return v }



type A_arbace_string_includes_QMARK__A struct{ jrt.Object }

func (t *A_arbace_string_includes_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_string_includes_QMARK__A_fn_class *jrt.Class

var A_arbace_string_includes_QMARK__A_init jrt.ClassInit

func A_arbace_string_includes_QMARK__A_Init() { if !A_arbace_string_includes_QMARK__A_init.Done() { A_arbace_string_includes_QMARK__A_init.Run(A_arbace_string_includes_QMARK__A_clinit) } }

func A_arbace_string_includes_QMARK__A_clinit() { A_arbace_string_includes_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_39, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_includes_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_includes_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_string_includes_QMARK__A_class }

func (t *A_arbace_string_includes_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_includes_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_includes_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_includes_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_includes_QMARK__A); return ok }

func A_arbace_string_includes_QMARK__A_Cast(x any) *A_arbace_string_includes_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_includes_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_includes_QMARK__A_class)) }; return v }



type A_arbace_string_index_of_A struct{ jrt.Object }

func (t *A_arbace_string_index_of_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_string_index_of_A) Is_Compiler_AOTF2() {}

var A_arbace_string_index_of_A_fn_class *jrt.Class

var A_arbace_string_index_of_A_init jrt.ClassInit

func A_arbace_string_index_of_A_Init() { if !A_arbace_string_index_of_A_init.Done() { A_arbace_string_index_of_A_init.Run(A_arbace_string_index_of_A_clinit) } }

func A_arbace_string_index_of_A_clinit() { A_arbace_string_index_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_40, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_index_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_index_of_A) GetClass__Class() *jrt.Class { return A_arbace_string_index_of_A_class }

func (t *A_arbace_string_index_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_index_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_index_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_index_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_index_of_A); return ok }

func A_arbace_string_index_of_A_Cast(x any) *A_arbace_string_index_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_index_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_index_of_A_class)) }; return v }



type A_arbace_string_join_A struct{ jrt.Object }

func (t *A_arbace_string_join_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_string_join_A) Is_Compiler_AOTF1() {}

var A_arbace_string_join_A_fn_class *jrt.Class

var A_arbace_string_join_A_init jrt.ClassInit

func A_arbace_string_join_A_Init() { if !A_arbace_string_join_A_init.Done() { A_arbace_string_join_A_init.Run(A_arbace_string_join_A_clinit) } }

func A_arbace_string_join_A_clinit() { A_arbace_string_join_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_41, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_join_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_join_A) GetClass__Class() *jrt.Class { return A_arbace_string_join_A_class }

func (t *A_arbace_string_join_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_join_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_join_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_join_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_join_A); return ok }

func A_arbace_string_join_A_Cast(x any) *A_arbace_string_join_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_join_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_join_A_class)) }; return v }



type A_arbace_string_last_index_of_A struct{ jrt.Object }

func (t *A_arbace_string_last_index_of_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_string_last_index_of_A) Is_Compiler_AOTF2() {}

var A_arbace_string_last_index_of_A_fn_class *jrt.Class

var A_arbace_string_last_index_of_A_init jrt.ClassInit

func A_arbace_string_last_index_of_A_Init() { if !A_arbace_string_last_index_of_A_init.Done() { A_arbace_string_last_index_of_A_init.Run(A_arbace_string_last_index_of_A_clinit) } }

func A_arbace_string_last_index_of_A_clinit() { A_arbace_string_last_index_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_42, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_last_index_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_last_index_of_A) GetClass__Class() *jrt.Class { return A_arbace_string_last_index_of_A_class }

func (t *A_arbace_string_last_index_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_last_index_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_last_index_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_last_index_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_last_index_of_A); return ok }

func A_arbace_string_last_index_of_A_Cast(x any) *A_arbace_string_last_index_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_last_index_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_last_index_of_A_class)) }; return v }



type A_arbace_string_lower_case_A struct{ jrt.Object }

func (t *A_arbace_string_lower_case_A) Is_Compiler_AOTF1() {}

var A_arbace_string_lower_case_A_fn_class *jrt.Class

var A_arbace_string_lower_case_A_init jrt.ClassInit

func A_arbace_string_lower_case_A_Init() { if !A_arbace_string_lower_case_A_init.Done() { A_arbace_string_lower_case_A_init.Run(A_arbace_string_lower_case_A_clinit) } }

func A_arbace_string_lower_case_A_clinit() { A_arbace_string_lower_case_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_43, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_lower_case_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_lower_case_A) GetClass__Class() *jrt.Class { return A_arbace_string_lower_case_A_class }

func (t *A_arbace_string_lower_case_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_lower_case_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_lower_case_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_lower_case_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_lower_case_A); return ok }

func A_arbace_string_lower_case_A_Cast(x any) *A_arbace_string_lower_case_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_lower_case_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_lower_case_A_class)) }; return v }



type A_arbace_string_re_quote_replacement_A struct{ jrt.Object }

func (t *A_arbace_string_re_quote_replacement_A) Is_Compiler_AOTF1() {}

var A_arbace_string_re_quote_replacement_A_fn_class *jrt.Class

var A_arbace_string_re_quote_replacement_A_init jrt.ClassInit

func A_arbace_string_re_quote_replacement_A_Init() { if !A_arbace_string_re_quote_replacement_A_init.Done() { A_arbace_string_re_quote_replacement_A_init.Run(A_arbace_string_re_quote_replacement_A_clinit) } }

func A_arbace_string_re_quote_replacement_A_clinit() { A_arbace_string_re_quote_replacement_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_44, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_re_quote_replacement_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_re_quote_replacement_A) GetClass__Class() *jrt.Class { return A_arbace_string_re_quote_replacement_A_class }

func (t *A_arbace_string_re_quote_replacement_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_re_quote_replacement_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_re_quote_replacement_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_re_quote_replacement_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_re_quote_replacement_A); return ok }

func A_arbace_string_re_quote_replacement_A_Cast(x any) *A_arbace_string_re_quote_replacement_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_re_quote_replacement_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_re_quote_replacement_A_class)) }; return v }



type A_arbace_string_replace_A struct{ jrt.Object }

func (t *A_arbace_string_replace_A) Is_Compiler_AOTF3() {}

var A_arbace_string_replace_A_fn_class *jrt.Class

var A_arbace_string_replace_A_init jrt.ClassInit

func A_arbace_string_replace_A_Init() { if !A_arbace_string_replace_A_init.Done() { A_arbace_string_replace_A_init.Run(A_arbace_string_replace_A_clinit) } }

func A_arbace_string_replace_A_clinit() { A_arbace_string_replace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_45, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_replace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_replace_A) GetClass__Class() *jrt.Class { return A_arbace_string_replace_A_class }

func (t *A_arbace_string_replace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_replace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_replace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_replace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_replace_A); return ok }

func A_arbace_string_replace_A_Cast(x any) *A_arbace_string_replace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_replace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_replace_A_class)) }; return v }



type A_arbace_string_replace_by_A struct{ jrt.Object }

func (t *A_arbace_string_replace_by_A) Is_Compiler_AOTF3() {}

var A_arbace_string_replace_by_A_fn_class *jrt.Class

var A_arbace_string_replace_by_A_init jrt.ClassInit

func A_arbace_string_replace_by_A_Init() { if !A_arbace_string_replace_by_A_init.Done() { A_arbace_string_replace_by_A_init.Run(A_arbace_string_replace_by_A_clinit) } }

func A_arbace_string_replace_by_A_clinit() { A_arbace_string_replace_by_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_replace_by_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_replace_by_A) GetClass__Class() *jrt.Class { return A_arbace_string_replace_by_A_class }

func (t *A_arbace_string_replace_by_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_replace_by_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_replace_by_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_replace_by_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_replace_by_A); return ok }

func A_arbace_string_replace_by_A_Cast(x any) *A_arbace_string_replace_by_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_replace_by_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_replace_by_A_class)) }; return v }



type A_arbace_string_replace_first_A struct{ jrt.Object }

func (t *A_arbace_string_replace_first_A) Is_Compiler_AOTF3() {}

var A_arbace_string_replace_first_A_fn_class *jrt.Class

var A_arbace_string_replace_first_A_init jrt.ClassInit

func A_arbace_string_replace_first_A_Init() { if !A_arbace_string_replace_first_A_init.Done() { A_arbace_string_replace_first_A_init.Run(A_arbace_string_replace_first_A_clinit) } }

func A_arbace_string_replace_first_A_clinit() { A_arbace_string_replace_first_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_replace_first_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_replace_first_A) GetClass__Class() *jrt.Class { return A_arbace_string_replace_first_A_class }

func (t *A_arbace_string_replace_first_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_replace_first_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_replace_first_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_replace_first_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_replace_first_A); return ok }

func A_arbace_string_replace_first_A_Cast(x any) *A_arbace_string_replace_first_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_replace_first_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_replace_first_A_class)) }; return v }



type A_arbace_string_replace_first_by_A struct{ jrt.Object }

func (t *A_arbace_string_replace_first_by_A) Is_Compiler_AOTF3() {}

var A_arbace_string_replace_first_by_A_fn_class *jrt.Class

var A_arbace_string_replace_first_by_A_init jrt.ClassInit

func A_arbace_string_replace_first_by_A_Init() { if !A_arbace_string_replace_first_by_A_init.Done() { A_arbace_string_replace_first_by_A_init.Run(A_arbace_string_replace_first_by_A_clinit) } }

func A_arbace_string_replace_first_by_A_clinit() { A_arbace_string_replace_first_by_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_replace_first_by_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_replace_first_by_A) GetClass__Class() *jrt.Class { return A_arbace_string_replace_first_by_A_class }

func (t *A_arbace_string_replace_first_by_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_replace_first_by_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_replace_first_by_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_replace_first_by_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_replace_first_by_A); return ok }

func A_arbace_string_replace_first_by_A_Cast(x any) *A_arbace_string_replace_first_by_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_replace_first_by_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_replace_first_by_A_class)) }; return v }



type A_arbace_string_replace_first_char_A struct{ jrt.Object }

func (t *A_arbace_string_replace_first_char_A) Is_Compiler_AOTF3() {}

var A_arbace_string_replace_first_char_A_fn_class *jrt.Class

var A_arbace_string_replace_first_char_A_init jrt.ClassInit

func A_arbace_string_replace_first_char_A_Init() { if !A_arbace_string_replace_first_char_A_init.Done() { A_arbace_string_replace_first_char_A_init.Run(A_arbace_string_replace_first_char_A_clinit) } }

func A_arbace_string_replace_first_char_A_clinit() { A_arbace_string_replace_first_char_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_50, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_replace_first_char_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_replace_first_char_A) GetClass__Class() *jrt.Class { return A_arbace_string_replace_first_char_A_class }

func (t *A_arbace_string_replace_first_char_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_replace_first_char_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_replace_first_char_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_replace_first_char_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_replace_first_char_A); return ok }

func A_arbace_string_replace_first_char_A_Cast(x any) *A_arbace_string_replace_first_char_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_replace_first_char_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_replace_first_char_A_class)) }; return v }



type A_arbace_string_replace_first_str_A struct{ jrt.Object }

func (t *A_arbace_string_replace_first_str_A) Is_Compiler_AOTF3() {}

var A_arbace_string_replace_first_str_A_fn_class *jrt.Class

var A_arbace_string_replace_first_str_A_init jrt.ClassInit

func A_arbace_string_replace_first_str_A_Init() { if !A_arbace_string_replace_first_str_A_init.Done() { A_arbace_string_replace_first_str_A_init.Run(A_arbace_string_replace_first_str_A_clinit) } }

func A_arbace_string_replace_first_str_A_clinit() { A_arbace_string_replace_first_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_replace_first_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_replace_first_str_A) GetClass__Class() *jrt.Class { return A_arbace_string_replace_first_str_A_class }

func (t *A_arbace_string_replace_first_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_replace_first_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_replace_first_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_replace_first_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_replace_first_str_A); return ok }

func A_arbace_string_replace_first_str_A_Cast(x any) *A_arbace_string_replace_first_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_replace_first_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_replace_first_str_A_class)) }; return v }



type A_arbace_string_reverse_A struct{ jrt.Object }

func (t *A_arbace_string_reverse_A) Is_Compiler_AOTF1() {}

var A_arbace_string_reverse_A_fn_class *jrt.Class

var A_arbace_string_reverse_A_init jrt.ClassInit

func A_arbace_string_reverse_A_Init() { if !A_arbace_string_reverse_A_init.Done() { A_arbace_string_reverse_A_init.Run(A_arbace_string_reverse_A_clinit) } }

func A_arbace_string_reverse_A_clinit() { A_arbace_string_reverse_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_reverse_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_reverse_A) GetClass__Class() *jrt.Class { return A_arbace_string_reverse_A_class }

func (t *A_arbace_string_reverse_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_reverse_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_reverse_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_reverse_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_reverse_A); return ok }

func A_arbace_string_reverse_A_Cast(x any) *A_arbace_string_reverse_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_reverse_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_reverse_A_class)) }; return v }



type A_arbace_string_split_A struct{ jrt.Object }

func (t *A_arbace_string_split_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_string_split_A) Is_Compiler_AOTF2() {}

var A_arbace_string_split_A_fn_class *jrt.Class

var A_arbace_string_split_A_init jrt.ClassInit

func A_arbace_string_split_A_Init() { if !A_arbace_string_split_A_init.Done() { A_arbace_string_split_A_init.Run(A_arbace_string_split_A_clinit) } }

func A_arbace_string_split_A_clinit() { A_arbace_string_split_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_53, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_split_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_split_A) GetClass__Class() *jrt.Class { return A_arbace_string_split_A_class }

func (t *A_arbace_string_split_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_split_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_split_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_split_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_split_A); return ok }

func A_arbace_string_split_A_Cast(x any) *A_arbace_string_split_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_split_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_split_A_class)) }; return v }



type A_arbace_string_split_lines_A struct{ jrt.Object }

func (t *A_arbace_string_split_lines_A) Is_Compiler_AOTF1() {}

var A_arbace_string_split_lines_A_fn_class *jrt.Class

var A_arbace_string_split_lines_A_init jrt.ClassInit

func A_arbace_string_split_lines_A_Init() { if !A_arbace_string_split_lines_A_init.Done() { A_arbace_string_split_lines_A_init.Run(A_arbace_string_split_lines_A_clinit) } }

func A_arbace_string_split_lines_A_clinit() { A_arbace_string_split_lines_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_split_lines_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_split_lines_A) GetClass__Class() *jrt.Class { return A_arbace_string_split_lines_A_class }

func (t *A_arbace_string_split_lines_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_split_lines_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_split_lines_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_split_lines_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_split_lines_A); return ok }

func A_arbace_string_split_lines_A_Cast(x any) *A_arbace_string_split_lines_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_split_lines_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_split_lines_A_class)) }; return v }



type A_arbace_string_starts_with_QMARK__A struct{ jrt.Object }

func (t *A_arbace_string_starts_with_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_string_starts_with_QMARK__A_fn_class *jrt.Class

var A_arbace_string_starts_with_QMARK__A_init jrt.ClassInit

func A_arbace_string_starts_with_QMARK__A_Init() { if !A_arbace_string_starts_with_QMARK__A_init.Done() { A_arbace_string_starts_with_QMARK__A_init.Run(A_arbace_string_starts_with_QMARK__A_clinit) } }

func A_arbace_string_starts_with_QMARK__A_clinit() { A_arbace_string_starts_with_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_starts_with_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_starts_with_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_string_starts_with_QMARK__A_class }

func (t *A_arbace_string_starts_with_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_starts_with_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_starts_with_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_starts_with_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_starts_with_QMARK__A); return ok }

func A_arbace_string_starts_with_QMARK__A_Cast(x any) *A_arbace_string_starts_with_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_starts_with_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_starts_with_QMARK__A_class)) }; return v }



type A_arbace_string_trim_A struct{ jrt.Object }

func (t *A_arbace_string_trim_A) Is_Compiler_AOTF1() {}

var A_arbace_string_trim_A_fn_class *jrt.Class

var A_arbace_string_trim_A_init jrt.ClassInit

func A_arbace_string_trim_A_Init() { if !A_arbace_string_trim_A_init.Done() { A_arbace_string_trim_A_init.Run(A_arbace_string_trim_A_clinit) } }

func A_arbace_string_trim_A_clinit() { A_arbace_string_trim_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_trim_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_trim_A) GetClass__Class() *jrt.Class { return A_arbace_string_trim_A_class }

func (t *A_arbace_string_trim_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_trim_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_trim_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_trim_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_trim_A); return ok }

func A_arbace_string_trim_A_Cast(x any) *A_arbace_string_trim_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_trim_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_trim_A_class)) }; return v }



type A_arbace_string_trim_newline_A struct{ jrt.Object }

func (t *A_arbace_string_trim_newline_A) Is_Compiler_AOTF1() {}

var A_arbace_string_trim_newline_A_fn_class *jrt.Class

var A_arbace_string_trim_newline_A_init jrt.ClassInit

func A_arbace_string_trim_newline_A_Init() { if !A_arbace_string_trim_newline_A_init.Done() { A_arbace_string_trim_newline_A_init.Run(A_arbace_string_trim_newline_A_clinit) } }

func A_arbace_string_trim_newline_A_clinit() { A_arbace_string_trim_newline_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_trim_newline_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_trim_newline_A) GetClass__Class() *jrt.Class { return A_arbace_string_trim_newline_A_class }

func (t *A_arbace_string_trim_newline_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_trim_newline_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_trim_newline_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_trim_newline_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_trim_newline_A); return ok }

func A_arbace_string_trim_newline_A_Cast(x any) *A_arbace_string_trim_newline_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_trim_newline_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_trim_newline_A_class)) }; return v }



type A_arbace_string_triml_A struct{ jrt.Object }

func (t *A_arbace_string_triml_A) Is_Compiler_AOTF1() {}

var A_arbace_string_triml_A_fn_class *jrt.Class

var A_arbace_string_triml_A_init jrt.ClassInit

func A_arbace_string_triml_A_Init() { if !A_arbace_string_triml_A_init.Done() { A_arbace_string_triml_A_init.Run(A_arbace_string_triml_A_clinit) } }

func A_arbace_string_triml_A_clinit() { A_arbace_string_triml_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_triml_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_triml_A) GetClass__Class() *jrt.Class { return A_arbace_string_triml_A_class }

func (t *A_arbace_string_triml_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_triml_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_triml_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_triml_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_triml_A); return ok }

func A_arbace_string_triml_A_Cast(x any) *A_arbace_string_triml_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_triml_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_triml_A_class)) }; return v }



type A_arbace_string_trimr_A struct{ jrt.Object }

func (t *A_arbace_string_trimr_A) Is_Compiler_AOTF1() {}

var A_arbace_string_trimr_A_fn_class *jrt.Class

var A_arbace_string_trimr_A_init jrt.ClassInit

func A_arbace_string_trimr_A_Init() { if !A_arbace_string_trimr_A_init.Done() { A_arbace_string_trimr_A_init.Run(A_arbace_string_trimr_A_clinit) } }

func A_arbace_string_trimr_A_clinit() { A_arbace_string_trimr_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_trimr_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_trimr_A) GetClass__Class() *jrt.Class { return A_arbace_string_trimr_A_class }

func (t *A_arbace_string_trimr_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_trimr_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_trimr_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_trimr_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_trimr_A); return ok }

func A_arbace_string_trimr_A_Cast(x any) *A_arbace_string_trimr_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_trimr_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_trimr_A_class)) }; return v }



type A_arbace_string_upper_case_A struct{ jrt.Object }

func (t *A_arbace_string_upper_case_A) Is_Compiler_AOTF1() {}

var A_arbace_string_upper_case_A_fn_class *jrt.Class

var A_arbace_string_upper_case_A_init jrt.ClassInit

func A_arbace_string_upper_case_A_Init() { if !A_arbace_string_upper_case_A_init.Done() { A_arbace_string_upper_case_A_init.Run(A_arbace_string_upper_case_A_clinit) } }

func A_arbace_string_upper_case_A_clinit() { A_arbace_string_upper_case_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_string_upper_case_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_upper_case_A) GetClass__Class() *jrt.Class { return A_arbace_string_upper_case_A_class }

func (t *A_arbace_string_upper_case_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_upper_case_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_string_upper_case_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_upper_case_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_upper_case_A); return ok }

func A_arbace_string_upper_case_A_Cast(x any) *A_arbace_string_upper_case_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_upper_case_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_upper_case_A_class)) }; return v }
