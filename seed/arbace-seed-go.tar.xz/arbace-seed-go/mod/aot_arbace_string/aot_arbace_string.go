//line aot_arbace_string.ae:1
package aot_arbace_string

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_New() *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A { A_arbace_string_A_Init(); t := &A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_string_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_string_A_const_1, A_arbace_string_A_const_2, A_arbace_string_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_string_eval885000008_fn__885000009_A_New() *A_arbace_string_eval885000008_fn__885000009_A { A_arbace_string_A_Init(); t := &A_arbace_string_eval885000008_fn__885000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_string_eval885000008_fn__885000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_string_eval885000008_fn__885000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_string_A_const_4.GetRawRoot__O()); var tmp2 any; var root_7 any = A_arbace_string_A_const_5.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = A_arbace_string_A_const_6; if linked_8 == nil { tmp2 = ifn_9.Invoke_O__O(arg_10) } else { tmp2 = linked_8.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_7, arg_10) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_string_A_const_7.GetRawRoot__O(), A_arbace_string_A_const_8) }






































func A_arbace_string_reverse_A_New() *A_arbace_string_reverse_A { A_arbace_string_A_Init(); t := &A_arbace_string_reverse_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_string_reverse_A) Ctor() {}
//line :48:1
func (t *A_arbace_string_reverse_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.StringBuilder_New_CharSequence(jrt.CharSequence_Cast(s__0)).Reverse__StringBuilder()).ToString__String().Ref()
}
func A_arbace_string_re_quote_replacement_A_New() *A_arbace_string_re_quote_replacement_A { A_arbace_string_A_Init(); t := &A_arbace_string_re_quote_replacement_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_string_re_quote_replacement_A) Ctor() {}
//line :54:1
func (t *A_arbace_string_re_quote_replacement_A) Invoke_O_O__O(self, replacement__0 any) any {





	return jrt.Matcher_QuoteReplacement_String__String(jrt.ToString(replacement__0)).Ref()
}
func A_arbace_string_replace_by_A_New() *A_arbace_string_replace_by_A { A_arbace_string_A_Init(); t := &A_arbace_string_replace_by_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_string_replace_by_A) Ctor() {}
//line :62:1
func (t *A_arbace_string_replace_by_A) Invoke_O_O_O_O__O(self, s__0, re__1, f__2 any) any { { var m__4 any; var root_17 any = A_arbace_string_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_19 lang.IFn

	if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = re__1; var arg_21 any = s__0; if linked_18 == nil { m__4 = ifn_19.Invoke_O_O__O(arg_20, arg_21) } else { m__4 = linked_18.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_17, arg_20, arg_21) }
	if jrt.NN(jrt.Matcher_Cast(m__4)).Find__Z() { var buffer__5 any = jrt.StringBuffer_New_I(jrt.CharSequence_Cast(s__0).Length__I()); var found__6 any = jrt.Boolean_TRUE.Ref(); L1: for {


		if jrt.J2g_Truth(found__6) {
			var tmp1 *jrt.Matcher = jrt.Matcher_Cast(m__4); var tmp2 *jrt.StringBuffer = jrt.StringBuffer_Cast(buffer__5); var tmp3 lang.IFn = lang.IFn_Cast(f__2); var tmp4 any; var root_22 any = A_arbace_string_A_const_10.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_re_groups_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = m__4; if linked_23 == nil { tmp4 = ifn_24.Invoke_O__O(arg_25) } else { tmp4 = linked_23.(*aot_arbace_core.A_arbace_core_re_groups_A).Invoke_O_O__O(root_22, arg_25) }; jrt.NN(tmp1).AppendReplacement_StringBuffer_String__Matcher(tmp2, jrt.Matcher_QuoteReplacement_String__String(jrt.String_Cast(tmp3.Invoke_O__O(tmp4))))
			found__6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Matcher_Cast(m__4)).Find__Z()).Ref(); continue L1 } else {
				jrt.NN(jrt.Matcher_Cast(m__4)).AppendTail_StringBuffer__StringBuffer(jrt.StringBuffer_Cast(buffer__5))
				return jrt.NN(jrt.StringBuffer_Cast(buffer__5)).ToString__String().Ref() } } } else {
//line :65:1
					return s__0 } }; /*line :62:1*/panic("j2g: unreachable") }












func A_arbace_string_replace_A_New() *A_arbace_string_replace_A { A_arbace_string_A_Init(); t := &A_arbace_string_replace_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_string_replace_A) Ctor() {}
//line :75:1
func (t *A_arbace_string_replace_A) Invoke_O_O_O_O__O(self, s__0, match__1, replacement__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); if


























	jrt.Character_InstanceOf(match__1) {
		return jrt.NN(jrt.String_Cast(s__4)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(match__1)).CharValue__C(), jrt.NN(jrt.Character_Cast(replacement__2)).CharValue__C()).Ref() } else {
//line :102:1
			if jrt.CharSequence_InstanceOf(match__1) {

				return jrt.NN(jrt.String_Cast(s__4)).Replace_CharSequence_CharSequence__String(jrt.CharSequence_Cast(match__1), jrt.CharSequence_Cast(replacement__2)).Ref() } else {
//line :102:1
					if jrt.Pattern_InstanceOf(match__1) {


						if jrt.CharSequence_InstanceOf(replacement__2) {
							var tmp1 any; var root_26 any = A_arbace_string_A_const_9.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = match__1; var arg_30 any = s__4; if linked_27 == nil { tmp1 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { tmp1 = linked_27.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; return jrt.NN(jrt.Matcher_Cast(tmp1)).ReplaceAll_String__String(jrt.ToString(replacement__2)).Ref() } else {

								var root_31 any = A_arbace_string_A_const_11.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, A_arbace_string_replace_by_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__4; var arg_35 any = match__1; var arg_36 any = replacement__2; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*A_arbace_string_replace_by_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36) } } } else {
//line :102:1
									if A_arbace_string_A_const_12 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, match__1))))) } else { return nil } } } } }








func A_arbace_string_replace_first_by_A_New() *A_arbace_string_replace_first_by_A { A_arbace_string_A_Init(); t := &A_arbace_string_replace_first_by_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_string_replace_first_by_A) Ctor() {}
//line :111:1
func (t *A_arbace_string_replace_first_by_A) Invoke_O_O_O_O__O(self, s__0, re__1, f__2 any) any { var m__4 any; var root_37 any = A_arbace_string_A_const_9.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_39 lang.IFn; if

	linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = re__1; var arg_41 any = s__0; if linked_38 == nil { m__4 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { m__4 = linked_38.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) }; if
	jrt.NN(jrt.Matcher_Cast(m__4)).Find__Z() { var buffer__5 any = jrt.StringBuffer_New_I(jrt.CharSequence_Cast(s__0).Length__I()); var rep__6 any; var tmp1 lang.IFn = lang.IFn_Cast(f__2); var tmp2 any; var root_46 any = A_arbace_string_A_const_10.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_re_groups_A_fn_class); var ifn_48 lang.IFn

		if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = m__4; if linked_47 == nil { tmp2 = ifn_48.Invoke_O__O(arg_49) } else { tmp2 = linked_47.(*aot_arbace_core.A_arbace_core_re_groups_A).Invoke_O_O__O(root_46, arg_49) }; rep__6 = jrt.Matcher_QuoteReplacement_String__String(jrt.String_Cast(tmp1.Invoke_O__O(tmp2))).Ref()
		jrt.NN(jrt.Matcher_Cast(m__4)).AppendReplacement_StringBuffer_String__Matcher(jrt.StringBuffer_Cast(buffer__5), jrt.String_Cast(rep__6))
		jrt.NN(jrt.Matcher_Cast(m__4)).AppendTail_StringBuffer__StringBuffer(jrt.StringBuffer_Cast(buffer__5))
		var root_42 any = A_arbace_string_A_const_13.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = buffer__5; if linked_43 == nil { return ifn_44.Invoke_O__O(arg_45) } else { return linked_43.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_42, arg_45) } } else {
//line :114:1
			return s__0 } }







func A_arbace_string_replace_first_char_A_New() *A_arbace_string_replace_first_char_A { A_arbace_string_A_Init(); t := &A_arbace_string_replace_first_char_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_string_replace_first_char_A) Ctor() {}
//line :122:1
func (t *A_arbace_string_replace_first_char_A) Invoke_O_O_O_O__O(self, s__0, match__1, replace__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); var i__5 int32 = jrt.NN(jrt.String_Cast(s__4)).IndexOf_I__I(lang.RT_IntCast_O__I_NoInit(match__1)); if



	lang.Util_Equiv_J_J__Z_NoInit(-1, int64(i__5)) { return s__4 } else {

		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 any; var root_50 any = A_arbace_string_A_const_14.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = s__4; var arg_54 any = A_arbace_string_A_const_15; var arg_55 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__5).Ref(); if linked_51 == nil { tmp2 = ifn_52.Invoke_O_O_O__O(arg_53, arg_54, arg_55) } else { tmp2 = linked_51.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_50, arg_53, arg_54, arg_55) }; var tmp3 any = tmp2; var tmp4 any; var root_56 any = A_arbace_string_A_const_14.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = s__4; var arg_60 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__5))).Ref(); if linked_57 == nil { tmp4 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { tmp4 = linked_57.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, replace__2, tmp4)).Ref() } }

func A_arbace_string_replace_first_str_A_New() *A_arbace_string_replace_first_str_A { A_arbace_string_A_Init(); t := &A_arbace_string_replace_first_str_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_string_replace_first_str_A) Ctor() {}
//line :130:1
func (t *A_arbace_string_replace_first_str_A) Invoke_O_O_O_O__O(self, s__0, match__1, replace__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); var i__5 int32 = jrt.NN(jrt.String_Cast(s__4)).IndexOf_String__I(jrt.String_Cast(match__1)); if



	lang.Util_Equiv_J_J__Z_NoInit(-1, int64(i__5)) { return s__4 } else {

		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 any; var root_61 any = A_arbace_string_A_const_14.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = s__4; var arg_65 any = A_arbace_string_A_const_15; var arg_66 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__5).Ref(); if linked_62 == nil { tmp2 = ifn_63.Invoke_O_O_O__O(arg_64, arg_65, arg_66) } else { tmp2 = linked_62.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_61, arg_64, arg_65, arg_66) }; var tmp3 any = tmp2; var tmp4 any; var root_67 any = A_arbace_string_A_const_14.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = s__4; var arg_71 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__5), int64(jrt.NN(jrt.String_Cast(match__1)).Length__I()))).Ref(); if linked_68 == nil { tmp4 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { tmp4 = linked_68.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, replace__2, tmp4)).Ref() } }

func A_arbace_string_replace_first_A_New() *A_arbace_string_replace_first_A { A_arbace_string_A_Init(); t := &A_arbace_string_replace_first_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_string_replace_first_A) Ctor() {}
//line :138:1
func (t *A_arbace_string_replace_first_A) Invoke_O_O_O_O__O(self, s__0, match__1, replacement__2 any) any { var s__4 any = jrt.ToString(s__0).Ref(); if



























	jrt.Character_InstanceOf(match__1) {

		var root_72 any = A_arbace_string_A_const_16.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, A_arbace_string_replace_first_char_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = s__4; var arg_76 any = match__1; var arg_77 any = replacement__2; if linked_73 == nil { return ifn_74.Invoke_O_O_O__O(arg_75, arg_76, arg_77) } else { return linked_73.(*A_arbace_string_replace_first_char_A).Invoke_O_O_O_O__O(root_72, arg_75, arg_76, arg_77) } } else {
//line :166:1
			if jrt.CharSequence_InstanceOf(match__1) {



				var root_78 any = A_arbace_string_A_const_17.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, A_arbace_string_replace_first_str_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = s__4; var arg_82 any = jrt.ToString(match__1).Ref(); var arg_83 any = jrt.ToString(replacement__2).Ref(); if linked_79 == nil { return ifn_80.Invoke_O_O_O__O(arg_81, arg_82, arg_83) } else { return linked_79.(*A_arbace_string_replace_first_str_A).Invoke_O_O_O_O__O(root_78, arg_81, arg_82, arg_83) } } else {
//line :166:1
					if jrt.Pattern_InstanceOf(match__1) {






						if jrt.CharSequence_InstanceOf(replacement__2) {
							var tmp1 any; var root_84 any = A_arbace_string_A_const_9.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = match__1; var arg_88 any = s__4; if linked_85 == nil { tmp1 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) }; return jrt.NN(jrt.Matcher_Cast(tmp1)).ReplaceFirst_String__String(jrt.ToString(replacement__2)).Ref() } else {

								var root_89 any = A_arbace_string_A_const_18.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, A_arbace_string_replace_first_by_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = s__4; var arg_93 any = match__1; var arg_94 any = replacement__2; if linked_90 == nil { return ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { return linked_90.(*A_arbace_string_replace_first_by_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) } } } else {
//line :166:1
									if A_arbace_string_A_const_12 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, match__1))))) } else { return nil } } } } }












func A_arbace_string_join_A_New() *A_arbace_string_join_A { A_arbace_string_A_Init(); t := &A_arbace_string_join_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_string_join_A) Ctor() {}
//line :179:1
func (t *A_arbace_string_join_A) Invoke_O_O_O__O(self, separator__0, coll__1 any) any { { var sb__3 any; var tmp1 any; var root_99 any = A_arbace_string_A_const_13.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_101 lang.IFn






	if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var root_95 any = A_arbace_string_A_const_19.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = coll__1; if linked_96 == nil { arg_102 = ifn_97.Invoke_O__O(arg_98) } else { arg_102 = linked_96.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_95, arg_98) }; if linked_100 == nil { tmp1 = ifn_101.Invoke_O__O(arg_102) } else { tmp1 = linked_100.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_99, arg_102) }
//line :179:1
	sb__3 = jrt.StringBuilder_New_String(jrt.String_Cast(tmp1)); var more__4 any; var root_103 any = A_arbace_string_A_const_20.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_105 lang.IFn







	if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = coll__1; if linked_104 == nil { more__4 = ifn_105.Invoke_O__O(arg_106) } else { more__4 = linked_104.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_103, arg_106) }
//line :179:1
	var sep__5 any; var root_107 any = A_arbace_string_A_const_13.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_109 lang.IFn








	if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = separator__0; if linked_108 == nil { sep__5 = ifn_109.Invoke_O__O(arg_110) } else { sep__5 = linked_108.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_107, arg_110) }
//line :179:1
L1: for {









	if jrt.J2g_Truth(more__4) {
		var tmp2 *jrt.StringBuilder = jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(sep__5)); var tmp3 any; var root_119 any = A_arbace_string_A_const_13.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var root_115 any = A_arbace_string_A_const_19.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = more__4; if linked_116 == nil { arg_122 = ifn_117.Invoke_O__O(arg_118) } else { arg_122 = linked_116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_115, arg_118) }; if linked_120 == nil { tmp3 = ifn_121.Invoke_O__O(arg_122) } else { tmp3 = linked_120.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_119, arg_122) }; var tmp4 any = jrt.NN(tmp2).Append_String__StringBuilder(jrt.String_Cast(tmp3)).Ref(); var tmp5 any; var root_123 any = A_arbace_string_A_const_20.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn
		if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = more__4; if linked_124 == nil { tmp5 = ifn_125.Invoke_O__O(arg_126) } else { tmp5 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }
//line :190:1
		sb__3, more__4, sep__5 = tmp4, tmp5, sep__5; continue L1 } else {


			var root_111 any = A_arbace_string_A_const_13.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = sb__3; if linked_112 == nil { return ifn_113.Invoke_O__O(arg_114) } else { return linked_112.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_111, arg_114) } } } }; /*line :179:1*/panic("j2g: unreachable") }
//line :179:1
func (t *A_arbace_string_join_A) Invoke_O_O__O(self, coll__0 any) any {




	var root_127 any = A_arbace_string_A_const_21.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = A_arbace_string_A_const_13.GetRawRoot__O(); var arg_131 any = coll__0; if linked_128 == nil { return ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { return linked_128.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_127, arg_130, arg_131)
	}
}








func A_arbace_string_capitalize_A_New() *A_arbace_string_capitalize_A { A_arbace_string_A_Init(); t := &A_arbace_string_capitalize_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_string_capitalize_A) Ctor() {}
//line :195:1
func (t *A_arbace_string_capitalize_A) Invoke_O_O__O(self, s__0 any) any { var s__2 any = jrt.ToString(s__0).Ref(); if





	lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s__2)), 2) {
		return jrt.NN(jrt.String_Cast(s__2)).ToUpperCase__String().Ref() } else {
			var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_132 any = A_arbace_string_A_const_14.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__2; var arg_136 any = A_arbace_string_A_const_15; var arg_137 any = A_arbace_string_A_const_22; if linked_133 == nil { tmp2 = ifn_134.Invoke_O_O_O__O(arg_135, arg_136, arg_137) } else { tmp2 = linked_133.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_132, arg_135, arg_136, arg_137) }; var tmp3 any = jrt.NN(jrt.String_Cast(tmp2)).ToUpperCase__String().Ref(); var tmp4 any; var root_138 any = A_arbace_string_A_const_14.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_140 lang.IFn
			if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__2; var arg_142 any = A_arbace_string_A_const_22; if linked_139 == nil { tmp4 = ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { tmp4 = linked_139.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) }
//line :203:1
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.String_Cast(tmp4)).ToLowerCase__String().Ref())).Ref() } }


func A_arbace_string_upper_case_A_New() *A_arbace_string_upper_case_A { A_arbace_string_A_Init(); t := &A_arbace_string_upper_case_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_string_upper_case_A) Ctor() {}
//line :206:1
func (t *A_arbace_string_upper_case_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.ToString(s__0)).ToUpperCase__String().Ref()
}
func A_arbace_string_lower_case_A_New() *A_arbace_string_lower_case_A { A_arbace_string_A_Init(); t := &A_arbace_string_lower_case_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_string_lower_case_A) Ctor() {}
//line :212:1
func (t *A_arbace_string_lower_case_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.ToString(s__0)).ToLowerCase__String().Ref()
}
func A_arbace_string_split_A_New() *A_arbace_string_split_A { A_arbace_string_A_Init(); t := &A_arbace_string_split_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_string_split_A) Ctor() {}
//line :218:1
func (t *A_arbace_string_split_A) Invoke_O_O_O_O__O(self, s__0, re__1, limit__2 any) any {







	return lang.LazilyPersistentVector_CreateOwning_O1__IPersistentVector(jrt.NN(jrt.Pattern_Cast(re__1)).Split_CharSequence_I__String1(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(limit__2))) }
//line :218:1
func (t *A_arbace_string_split_A) Invoke_O_O_O__O(self, s__0, re__1 any) any {





	return lang.LazilyPersistentVector_CreateOwning_O1__IPersistentVector(jrt.NN(jrt.Pattern_Cast(re__1)).Split_CharSequence__String1(jrt.CharSequence_Cast(s__0)))
}


func A_arbace_string_split_lines_A_New() *A_arbace_string_split_lines_A { A_arbace_string_A_Init(); t := &A_arbace_string_split_lines_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_string_split_lines_A) Ctor() {}
//line :228:1
func (t *A_arbace_string_split_lines_A) Invoke_O_O__O(self, s__0 any) any {



	var root_143 any = A_arbace_string_A_const_23.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, A_arbace_string_split_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = s__0; var arg_147 any = A_arbace_string_A_const_24; if linked_144 == nil { return ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { return linked_144.(*A_arbace_string_split_A).Invoke_O_O_O__O(root_143, arg_146, arg_147)
	} }
func A_arbace_string_trim_A_New() *A_arbace_string_trim_A { A_arbace_string_A_Init(); t := &A_arbace_string_trim_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_string_trim_A) Ctor() {}
//line :234:1
func (t *A_arbace_string_trim_A) Invoke_O_O__O(self, s__0 any) any { { var len__2 int32 = jrt.CharSequence_Cast(s__0).Length__I(); var rindex__3 int64 = lang.RT_LongCast_I__J_NoInit(len__2); L1: for {





	if lang.Numbers_IsZero_J__Z_NoInit(rindex__3) { return Lit_5 } else {

		if jrt.Character_IsWhitespace_C__Z_NoInit(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(rindex__3)))) {
			rindex__3 = lang.Numbers_Dec_J__J_NoInit(rindex__3); continue L1 } else {
//line :242:1
				var lindex__4 int64 = 0; L2: for {




					if jrt.Character_IsWhitespace_C__Z_NoInit(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lindex__4))) {
						lindex__4 = lang.Numbers_Inc_J__J_NoInit(lindex__4); continue L2 } else {
							return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I_NoInit(lindex__4), lang.RT_IntCast_J__I_NoInit(rindex__3))).Ref() } } } } } }; /*line :234:1*/panic("j2g: unreachable") }
















func A_arbace_string_triml_A_New() *A_arbace_string_triml_A { A_arbace_string_A_Init(); t := &A_arbace_string_triml_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_string_triml_A) Ctor() {}
//line :251:1
func (t *A_arbace_string_triml_A) Invoke_O_O__O(self, s__0 any) any { { var len__2 int32 = jrt.CharSequence_Cast(s__0).Length__I(); var index__3 int64 = 0; L1: for {





	if lang.Util_Equiv_J_J__Z_NoInit(int64(len__2), index__3) { return Lit_5 } else {

		if jrt.Character_IsWhitespace_C__Z_NoInit(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(index__3))) {
			index__3 = lang.Numbers_Unchecked_inc_J__J_NoInit(index__3); continue L1 } else {
				return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I_NoInit(index__3), len__2)).Ref() } } } }; /*line :251:1*/panic("j2g: unreachable") }











func A_arbace_string_trimr_A_New() *A_arbace_string_trimr_A { A_arbace_string_A_Init(); t := &A_arbace_string_trimr_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_string_trimr_A) Ctor() {}
//line :263:1
func (t *A_arbace_string_trimr_A) Invoke_O_O__O(self, s__0 any) any { { var index__2 int64 = lang.RT_LongCast_I__J_NoInit(jrt.CharSequence_Cast(s__0).Length__I()); L1: for {




	if lang.Numbers_IsZero_J__Z_NoInit(index__2) { return Lit_5 } else {

		if jrt.Character_IsWhitespace_C__Z_NoInit(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Unchecked_dec_J__J_NoInit(index__2)))) {
			index__2 = lang.Numbers_Unchecked_dec_J__J_NoInit(index__2); continue L1 } else {
				return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(index__2))).Ref() } } } }; /*line :263:1*/panic("j2g: unreachable") }










func A_arbace_string_trim_newline_A_New() *A_arbace_string_trim_newline_A { A_arbace_string_A_Init(); t := &A_arbace_string_trim_newline_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_string_trim_newline_A) Ctor() {}
//line :274:1
func (t *A_arbace_string_trim_newline_A) Invoke_O_O__O(self, s__0 any) any { { var index__2 int64 = lang.RT_LongCast_I__J_NoInit(jrt.CharSequence_Cast(s__0).Length__I()); L1: for {





	if lang.Numbers_IsZero_J__Z_NoInit(index__2) { return Lit_5 } else { var ch__3 uint16 = jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(index__2))); var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_C_C__Z_NoInit(ch__3, jrt.NN(jrt.Character_Cast(A_arbace_string_A_const_25)).CharValue__C())


		if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_C_C__Z_NoInit(ch__3, jrt.NN(jrt.Character_Cast(A_arbace_string_A_const_26)).CharValue__C()) }; if tmp1 {
			index__2 = lang.Numbers_Dec_J__J_NoInit(index__2); continue L1 } else {
				return jrt.ToString(jrt.CharSequence_Cast(s__0).SubSequence_I_I__CharSequence(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(index__2))).Ref() } } } }; /*line :274:1*/panic("j2g: unreachable") }












func A_arbace_string_blank_QMARK__A_New() *A_arbace_string_blank_QMARK__A { A_arbace_string_A_Init(); t := &A_arbace_string_blank_QMARK__A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_string_blank_QMARK__A) Ctor() {}
//line :287:1
func (t *A_arbace_string_blank_QMARK__A) Invoke_O_O__O(self, s__0 any) any {



	if jrt.J2g_Truth(s__0) { var index__2 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for {

		if lang.Util_Equiv_J_J__Z_NoInit(int64(jrt.CharSequence_Cast(s__0).Length__I()), index__2) { return jrt.Boolean_TRUE.Ref() } else {

			if jrt.Character_IsWhitespace_C__Z_NoInit(jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(index__2))) {
				index__2 = lang.Numbers_Inc_J__J_NoInit(index__2); continue L1 } else {
//line :295:1
					return jrt.Boolean_FALSE.Ref() } } } } else {
//line :291:1
						return jrt.Boolean_TRUE.Ref() }
//line :287:1
	panic("j2g: unreachable")
}











func A_arbace_string_escape_A_New() *A_arbace_string_escape_A { A_arbace_string_A_Init(); t := &A_arbace_string_escape_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_string_escape_A) Ctor() {}
//line :300:1
func (t *A_arbace_string_escape_A) Invoke_O_O_O__O(self, s__0, cmap__1 any) any { { var index__3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); var buffer__4 any = jrt.StringBuilder_New_I(jrt.CharSequence_Cast(s__0).Length__I()); L1: for {









	if lang.Util_Equiv_J_J__Z_NoInit(int64(jrt.CharSequence_Cast(s__0).Length__I()), index__3) {
		return jrt.NN(jrt.StringBuilder_Cast(buffer__4)).ToString__String().Ref() } else {
//line :310:1
			var ch__5 uint16 = jrt.CharSequence_Cast(s__0).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(index__3)); var temp__1927000408__auto____6 any = lang.IFn_Cast(cmap__1).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(ch__5).Ref())


			if jrt.J2g_Truth(temp__1927000408__auto____6) { var replacement__7 any = temp__1927000408__auto____6
				jrt.NN(jrt.StringBuilder_Cast(buffer__4)).Append_O__StringBuilder(replacement__7) } else {
					jrt.NN(jrt.StringBuilder_Cast(buffer__4)).Append_C__StringBuilder(ch__5) }
			index__3, buffer__4 = lang.Numbers_Inc_J__J_NoInit(index__3), buffer__4; continue L1 } } }; /*line :300:1*/panic("j2g: unreachable") }

















func A_arbace_string_index_of_A_New() *A_arbace_string_index_of_A { A_arbace_string_A_Init(); t := &A_arbace_string_index_of_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_string_index_of_A) Ctor() {}
//line :318:1
func (t *A_arbace_string_index_of_A) Invoke_O_O_O_O__O(self, s__0, value__1, p_from_index__2 any) any { var from_index__2 int64 = lang.RT_LongCast_O__J_NoInit(p_from_index__2); var result__4 int32; if












	jrt.Character_InstanceOf(value__1) {

		result__4 = jrt.NN(jrt.ToString(s__0)).IndexOf_I_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C()), lang.RT_UncheckedIntCast_J__I_NoInit(from_index__2)) } else {
			result__4 = jrt.NN(jrt.ToString(s__0)).IndexOf_String_I__I(jrt.String_Cast(value__1), lang.RT_UncheckedIntCast_J__I_NoInit(from_index__2)) }; if
	lang.Util_Equiv_J_J__Z_NoInit(int64(result__4), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer_NoInit(result__4).Ref() } }
//line :318:1
func (t *A_arbace_string_index_of_A) Invoke_O_O_O__O(self, s__0, value__1 any) any { var result__3 int32; if




	jrt.Character_InstanceOf(value__1) {

		result__3 = jrt.NN(jrt.ToString(s__0)).IndexOf_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C())) } else {
			result__3 = jrt.NN(jrt.ToString(s__0)).IndexOf_String__I(jrt.String_Cast(value__1)) }; if
	lang.Util_Equiv_J_J__Z_NoInit(int64(result__3), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer_NoInit(result__3).Ref() } }











func A_arbace_string_last_index_of_A_New() *A_arbace_string_last_index_of_A { A_arbace_string_A_Init(); t := &A_arbace_string_last_index_of_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_string_last_index_of_A) Ctor() {}
//line :339:1
func (t *A_arbace_string_last_index_of_A) Invoke_O_O_O_O__O(self, s__0, value__1, p_from_index__2 any) any { var from_index__2 int64 = lang.RT_LongCast_O__J_NoInit(p_from_index__2); var result__4 int32; if












	jrt.Character_InstanceOf(value__1) {

		result__4 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_I_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C()), lang.RT_UncheckedIntCast_J__I_NoInit(from_index__2)) } else {
			result__4 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_String_I__I(jrt.String_Cast(value__1), lang.RT_UncheckedIntCast_J__I_NoInit(from_index__2)) }; if
	lang.Util_Equiv_J_J__Z_NoInit(int64(result__4), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer_NoInit(result__4).Ref() } }
//line :339:1
func (t *A_arbace_string_last_index_of_A) Invoke_O_O_O__O(self, s__0, value__1 any) any { var result__3 int32; if




	jrt.Character_InstanceOf(value__1) {

		result__3 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_I__I(int32(jrt.NN(jrt.Character_Cast(value__1)).CharValue__C())) } else {
			result__3 = jrt.NN(jrt.ToString(s__0)).LastIndexOf_String__I(jrt.String_Cast(value__1)) }; if
	lang.Util_Equiv_J_J__Z_NoInit(int64(result__3), -1) { return nil } else { return jrt.Integer_ValueOf_I__Integer_NoInit(result__3).Ref() } }











func A_arbace_string_starts_with_QMARK__A_New() *A_arbace_string_starts_with_QMARK__A { A_arbace_string_A_Init(); t := &A_arbace_string_starts_with_QMARK__A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_string_starts_with_QMARK__A) Ctor() {}
//line :360:1
func (t *A_arbace_string_starts_with_QMARK__A) Invoke_O_O_O__O(self, s__0, substr__1 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ToString(s__0)).StartsWith_String__Z(jrt.String_Cast(substr__1))).Ref()
}
func A_arbace_string_ends_with_QMARK__A_New() *A_arbace_string_ends_with_QMARK__A { A_arbace_string_A_Init(); t := &A_arbace_string_ends_with_QMARK__A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_string_ends_with_QMARK__A) Ctor() {}
//line :366:1
func (t *A_arbace_string_ends_with_QMARK__A) Invoke_O_O_O__O(self, s__0, substr__1 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ToString(s__0)).EndsWith_String__Z(jrt.String_Cast(substr__1))).Ref()
}
func A_arbace_string_includes_QMARK__A_New() *A_arbace_string_includes_QMARK__A { A_arbace_string_A_Init(); t := &A_arbace_string_includes_QMARK__A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_string_includes_QMARK__A) Ctor() {}
//line :372:1
func (t *A_arbace_string_includes_QMARK__A) Invoke_O_O_O__O(self, s__0, substr__1 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ToString(s__0)).Contains_CharSequence__Z(jrt.CharSequence_Cast(substr__1))).Ref()
}


type A_arbace_string_A struct{ jrt.Object }

var A_arbace_string_A_const_pool *jrt.RefArray

var A_arbace_string_A_const_0 *lang.Var

var A_arbace_string_A_const_1 any

var A_arbace_string_A_const_2 *lang.Keyword

var A_arbace_string_A_const_3 any

var A_arbace_string_A_const_4 *lang.Var

var A_arbace_string_A_const_5 *lang.Var

var A_arbace_string_A_const_6 *lang.Var

var A_arbace_string_A_const_7 *lang.Var

var A_arbace_string_A_const_8 any

var A_arbace_string_A_const_9 *lang.Var

var A_arbace_string_A_const_10 *lang.Var

var A_arbace_string_A_const_11 *lang.Var

var A_arbace_string_A_const_12 *lang.Keyword

var A_arbace_string_A_const_13 *lang.Var

var A_arbace_string_A_const_14 *lang.Var

var A_arbace_string_A_const_15 any

var A_arbace_string_A_const_16 *lang.Var

var A_arbace_string_A_const_17 *lang.Var

var A_arbace_string_A_const_18 *lang.Var

var A_arbace_string_A_const_19 *lang.Var

var A_arbace_string_A_const_20 *lang.Var

var A_arbace_string_A_const_21 *lang.Var

var A_arbace_string_A_const_22 any

var A_arbace_string_A_const_23 *lang.Var

var A_arbace_string_A_const_24 any

var A_arbace_string_A_const_25 any

var A_arbace_string_A_const_26 any

var A_arbace_string_A_init jrt.ClassInit

func A_arbace_string_A_Init() { if !A_arbace_string_A_init.Done() { A_arbace_string_A_init.Run(A_arbace_string_A_clinit) } }

func A_arbace_string_A_clinit() { A_arbace_string_A_clinit_p0(); A_arbace_string_A_clinit_p1(); A_arbace_string_A_clinit_p2() }

func A_arbace_string_A_clinit_p0() { jrt.StartCheck(); A_arbace_string_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 36); A_arbace_string_A_const_0 = lang.Var_Cast(A_arbace_string_A_const_pool.A[9]); A_arbace_string_A_const_1 = A_arbace_string_A_const_pool.A[10]; A_arbace_string_A_const_2 = lang.Keyword_Cast(A_arbace_string_A_const_pool.A[11]); A_arbace_string_A_const_3 = A_arbace_string_A_const_pool.A[12]; A_arbace_string_A_const_4 = lang.Var_Cast(A_arbace_string_A_const_pool.A[13]); A_arbace_string_A_const_5 = lang.Var_Cast(A_arbace_string_A_const_pool.A[14]); A_arbace_string_A_const_6 = lang.Var_Cast(A_arbace_string_A_const_pool.A[15]); A_arbace_string_A_const_7 = lang.Var_Cast(A_arbace_string_A_const_pool.A[16]); A_arbace_string_A_const_8 = A_arbace_string_A_const_pool.A[17]; A_arbace_string_A_const_9 = lang.Var_Cast(A_arbace_string_A_const_pool.A[18]); A_arbace_string_A_const_10 = lang.Var_Cast(A_arbace_string_A_const_pool.A[19]); A_arbace_string_A_const_11 = lang.Var_Cast(A_arbace_string_A_const_pool.A[20]) }

func A_arbace_string_A_clinit_p1() { A_arbace_string_A_const_12 = lang.Keyword_Cast(A_arbace_string_A_const_pool.A[21]); A_arbace_string_A_const_13 = lang.Var_Cast(A_arbace_string_A_const_pool.A[22]); A_arbace_string_A_const_14 = lang.Var_Cast(A_arbace_string_A_const_pool.A[23]); A_arbace_string_A_const_15 = A_arbace_string_A_const_pool.A[24]; A_arbace_string_A_const_16 = lang.Var_Cast(A_arbace_string_A_const_pool.A[25]); A_arbace_string_A_const_17 = lang.Var_Cast(A_arbace_string_A_const_pool.A[26]); A_arbace_string_A_const_18 = lang.Var_Cast(A_arbace_string_A_const_pool.A[27]); A_arbace_string_A_const_19 = lang.Var_Cast(A_arbace_string_A_const_pool.A[28]); A_arbace_string_A_const_20 = lang.Var_Cast(A_arbace_string_A_const_pool.A[29]); A_arbace_string_A_const_21 = lang.Var_Cast(A_arbace_string_A_const_pool.A[30]); A_arbace_string_A_const_22 = A_arbace_string_A_const_pool.A[31]; A_arbace_string_A_const_23 = lang.Var_Cast(A_arbace_string_A_const_pool.A[32]) }

func A_arbace_string_A_clinit_p2() { A_arbace_string_A_const_24 = A_arbace_string_A_const_pool.A[33]; A_arbace_string_A_const_25 = A_arbace_string_A_const_pool.A[34]; A_arbace_string_A_const_26 = A_arbace_string_A_const_pool.A[35] }

func A_arbace_string_A_New() *A_arbace_string_A { A_arbace_string_A_Init(); t := &A_arbace_string_A{}; t.Ctor(); return t }

func (t *A_arbace_string_A) Ctor() {}

func (t *A_arbace_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_A) GetClass__Class() *jrt.Class { return A_arbace_string_A_class }

func (t *A_arbace_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_A); return ok }

func A_arbace_string_A_Cast(x any) *A_arbace_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_A_class)) }; return v }



type A_arbace_string_blank_QMARK__A struct{ j2g_header uint64 }

var A_arbace_string_blank_QMARK__A_fn_class *jrt.Class



type A_arbace_string_capitalize_A struct{ j2g_header uint64 }

var A_arbace_string_capitalize_A_fn_class *jrt.Class



type A_arbace_string_ends_with_QMARK__A struct{ j2g_header uint64 }

var A_arbace_string_ends_with_QMARK__A_fn_class *jrt.Class



type A_arbace_string_escape_A struct{ j2g_header uint64 }

var A_arbace_string_escape_A_fn_class *jrt.Class



type A_arbace_string_eval885000004_A struct{ jrt.Object }

func A_arbace_string_eval885000004_A_New() *A_arbace_string_eval885000004_A { t := &A_arbace_string_eval885000004_A{}; t.Ctor(); return t }

func (t *A_arbace_string_eval885000004_A) Ctor() {}

func (t *A_arbace_string_eval885000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_eval885000004_A) GetClass__Class() *jrt.Class { return A_arbace_string_eval885000004_A_class }

func (t *A_arbace_string_eval885000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_eval885000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_string_eval885000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_eval885000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_eval885000004_A); return ok }

func A_arbace_string_eval885000004_A_Cast(x any) *A_arbace_string_eval885000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_eval885000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_eval885000004_A_class)) }; return v }



type A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A struct{ j2g_header uint64 }

var A_arbace_string_eval885000004_loading__1927001464__auto____885000005_A_fn_class *jrt.Class



type A_arbace_string_eval885000008_A struct{ jrt.Object }

func A_arbace_string_eval885000008_A_New() *A_arbace_string_eval885000008_A { t := &A_arbace_string_eval885000008_A{}; t.Ctor(); return t }

func (t *A_arbace_string_eval885000008_A) Ctor() {}

func (t *A_arbace_string_eval885000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_string_eval885000008_A) GetClass__Class() *jrt.Class { return A_arbace_string_eval885000008_A_class }

func (t *A_arbace_string_eval885000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_string_eval885000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_string_eval885000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_string_eval885000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_string_eval885000008_A); return ok }

func A_arbace_string_eval885000008_A_Cast(x any) *A_arbace_string_eval885000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_string_eval885000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_string_eval885000008_A_class)) }; return v }



type A_arbace_string_eval885000008_fn__885000009_A struct{ j2g_header uint64 }

var A_arbace_string_eval885000008_fn__885000009_A_fn_class *jrt.Class



type A_arbace_string_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_string_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_string_index_of_A struct{ j2g_header uint64 }

var A_arbace_string_index_of_A_fn_class *jrt.Class



type A_arbace_string_join_A struct{ j2g_header uint64 }

var A_arbace_string_join_A_fn_class *jrt.Class



type A_arbace_string_last_index_of_A struct{ j2g_header uint64 }

var A_arbace_string_last_index_of_A_fn_class *jrt.Class



type A_arbace_string_lower_case_A struct{ j2g_header uint64 }

var A_arbace_string_lower_case_A_fn_class *jrt.Class



type A_arbace_string_re_quote_replacement_A struct{ j2g_header uint64 }

var A_arbace_string_re_quote_replacement_A_fn_class *jrt.Class



type A_arbace_string_replace_A struct{ j2g_header uint64 }

var A_arbace_string_replace_A_fn_class *jrt.Class



type A_arbace_string_replace_by_A struct{ j2g_header uint64 }

var A_arbace_string_replace_by_A_fn_class *jrt.Class



type A_arbace_string_replace_first_A struct{ j2g_header uint64 }

var A_arbace_string_replace_first_A_fn_class *jrt.Class



type A_arbace_string_replace_first_by_A struct{ j2g_header uint64 }

var A_arbace_string_replace_first_by_A_fn_class *jrt.Class



type A_arbace_string_replace_first_char_A struct{ j2g_header uint64 }

var A_arbace_string_replace_first_char_A_fn_class *jrt.Class



type A_arbace_string_replace_first_str_A struct{ j2g_header uint64 }

var A_arbace_string_replace_first_str_A_fn_class *jrt.Class



type A_arbace_string_reverse_A struct{ j2g_header uint64 }

var A_arbace_string_reverse_A_fn_class *jrt.Class



type A_arbace_string_split_A struct{ j2g_header uint64 }

var A_arbace_string_split_A_fn_class *jrt.Class



type A_arbace_string_split_lines_A struct{ j2g_header uint64 }

var A_arbace_string_split_lines_A_fn_class *jrt.Class



type A_arbace_string_starts_with_QMARK__A struct{ j2g_header uint64 }

var A_arbace_string_starts_with_QMARK__A_fn_class *jrt.Class



type A_arbace_string_trim_A struct{ j2g_header uint64 }

var A_arbace_string_trim_A_fn_class *jrt.Class



type A_arbace_string_trim_newline_A struct{ j2g_header uint64 }

var A_arbace_string_trim_newline_A_fn_class *jrt.Class



type A_arbace_string_triml_A struct{ j2g_header uint64 }

var A_arbace_string_triml_A_fn_class *jrt.Class



type A_arbace_string_trimr_A struct{ j2g_header uint64 }

var A_arbace_string_trimr_A_fn_class *jrt.Class



type A_arbace_string_upper_case_A struct{ j2g_header uint64 }

var A_arbace_string_upper_case_A_fn_class *jrt.Class
