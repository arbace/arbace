//line j2g_strings.ae:1
package aot_arbace_string

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn7,replaceyn7,reversekn4,linekn6,columnkn3,dockn6,authorkn4,elsev11,arbace.core5,referR0,R1,ML2,R2,R3,m4,R4,i42,R5,i28,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn13,arbace.stringm4,R6,s1244,Clojure String utilities\n\nIt is poor form to (:use arbace.string). Instead, use require\nwith :as to specify a prefix, e.g.\n\n(ns your.namespace.here\n  (:require [arbace.string :as str]))\n\nDesign notes for arbace.string:\n\n1. Strings are objects (as opposed to sequences). As such, the\n   string being manipulated is the first argument to a function;\n   passing nil will result in a NullPointerException unless\n   documented otherwise. If you want sequence-y behavior instead,\n   use a sequence.\n\n2. Functions are generally not lazy, and call straight to host\n   methods where those are available and efficient.\n\n3. Functions take advantage of String implementation details to\n   write high-performing loop/recurs instead of using higher-order\n   functions. (This is not idiomatic in general-purpose application\n   code.)\n\n4. When a function is documented to accept a string argument, it\n   will take any implementation of the correct *interface* on the\n   host platform. In Java, this is CharSequence, which is more\n   general than String. In ordinary usage you will almost always\n   pass concrete strings. If you are doing something unusual,\n   e.g. passing a mutable implementation of CharSequence, then\n   thread-safety is your responsibility.R7,s44,Stuart Sierra, Stuart Halloway, David Liebkev11,arbace.core13,*loaded-libs*v11,arbace.core10,re-matcherv11,arbace.core9,re-groupsv13,arbace.string10,replace-byR8,v11,arbace.core3,strv11,arbace.core4,subsl0,v13,arbace.string18,replace-first-charv13,arbace.string17,replace-first-strv13,arbace.string16,replace-first-byv11,arbace.core4,nextv11,arbace.core5,firstv11,arbace.core5,applyl1,v13,arbace.string5,splitp5,\\r?\\nc10,c13,")

var Lit_1 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_2 *jrt.String = jrt.Intern("java.util.regex.Matcher")

var Lit_3 *jrt.String = jrt.Intern("arbace.lang.LazilyPersistentVector")

var Lit_4 *jrt.String = jrt.Intern("Invalid match arg: ")

var Lit_5 *jrt.String = jrt.Intern("")

var Lit_6 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn3,tagkn8,arglistsyn12,CharSequencekn5,addedkn4,linekn6,columnkn4,filekn7,privateyn2,reyn1,fyn5,matchyn11,replacementyn7,Patternyn9,Characteryn7,replaceyn6,Stringyn4,collyn9,separatoryn5,limityn4,cmapyn5,valueyn4,longv11,arbace.core5,in-nsMyn13,arbace.stringm4,R0,s1244,Clojure String utilities\n\nIt is poor form to (:use arbace.string). Instead, use require\nwith :as to specify a prefix, e.g.\n\n(ns your.namespace.here\n  (:require [arbace.string :as str]))\n\nDesign notes for arbace.string:\n\n1. Strings are objects (as opposed to sequences). As such, the\n   string being manipulated is the first argument to a function;\n   passing nil will result in a NullPointerException unless\n   documented otherwise. If you want sequence-y behavior instead,\n   use a sequence.\n\n2. Functions are generally not lazy, and call straight to host\n   methods where those are available and efficient.\n\n3. Functions take advantage of String implementation details to\n   write high-performing loop/recurs instead of using higher-order\n   functions. (This is not idiomatic in general-purpose application\n   code.)\n\n4. When a function is documented to accept a string argument, it\n   will take any implementation of the correct *interface* on the\n   host platform. In Java, this is CharSequence, which is more\n   general than String. In ordinary usage you will almost always\n   pass concrete strings. If you are doing something unusual,\n   e.g. passing a mutable implementation of CharSequence, then\n   thread-safety is your responsibility.R1,s44,Stuart Sierra, Stuart Halloway, David Liebkem4,R0,s1244,Clojure String utilities\n\nIt is poor form to (:use arbace.string). Instead, use require\nwith :as to specify a prefix, e.g.\n\n(ns your.namespace.here\n  (:require [arbace.string :as str]))\n\nDesign notes for arbace.string:\n\n1. Strings are objects (as opposed to sequences). As such, the\n   string being manipulated is the first argument to a function;\n   passing nil will result in a NullPointerException unless\n   documented otherwise. If you want sequence-y behavior instead,\n   use a sequence.\n\n2. Functions are generally not lazy, and call straight to host\n   methods where those are available and efficient.\n\n3. Functions take advantage of String implementation details to\n   write high-performing loop/recurs instead of using higher-order\n   functions. (This is not idiomatic in general-purpose application\n   code.)\n\n4. When a function is documented to accept a string argument, it\n   will take any implementation of the correct *interface* on the\n   host platform. In Java, this is CharSequence, which is more\n   general than String. In ordinary usage you will almost always\n   pass concrete strings. If you are doing something unusual,\n   e.g. passing a mutable implementation of CharSequence, then\n   thread-safety is your responsibility.R1,s44,Stuart Sierra, Stuart Halloway, David LiebkeR2,v11,arbace.core20,*warn-on-reflection*v13,arbace.string7,reversem14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s39,Returns s with its characters reversed.R6,s3,1.2R7,i48,R8,i1,R9,s16,arbace/string.aev13,arbace.string20,re-quote-replacementm14,R3,C16,java.lang.StringR4,L1,V1,Myn11,replacementm2,R3,R5,R0,s191,Given a replacement string that you wish to be a literal\n   replacement for a pattern match in replace or replace-first, do the\n   necessary escaping of special characters in the replacement.R6,s3,1.5R7,i54,R8,i1,R9,s16,arbace/string.aev13,arbace.string10,replace-bym10,R10,TR4,L1,V3,Myn1,sm2,R3,R5,R11,R12,R7,i62,R8,i1,R9,s16,arbace/string.aev13,arbace.string7,replacem14,R3,C16,java.lang.StringR4,L1,V3,Myn1,sm2,R3,R5,R13,R14,R0,s815,Replaces all instance of match with replacement in s.\n\n   match/replacement can be:\n\n   string / string\n   char / char\n   pattern / (string or function of match).\n\n   See also replace-first.\n\n   The replacement is literal (i.e. none of its characters are treated\n   specially) for all cases above except pattern / string.\n\n   For pattern / string, $1, $2, etc. in the replacement string are\n   substituted with the string that matched the corresponding\n   parenthesized group in the pattern.  If you wish your replacement\n   string r to be used literally, use (re-quote-replacement r) as the\n   replacement argument.  See also documentation for\n   java.util.regex.Matcher's appendReplacement method.\n\n   Example:\n   (arbace.string/replace \"Almost Pig Latin\" #\"\\b(\\w)(\\w+)\\b\" \"$2$1ay\")\n   -> \"lmostAay igPay atinLay\"R6,s3,1.2R7,i75,R8,i1,R9,s16,arbace/string.aev13,arbace.string16,replace-first-bym10,R10,TR4,L1,V3,Myn1,sm2,R3,R5,Myn2,rem2,R3,R15,R12,R7,i111,R8,i1,R9,s16,arbace/string.aev13,arbace.string18,replace-first-charm10,R10,TR4,L1,V3,Myn1,sm2,R3,R5,Myn5,matchm2,R3,R16,R17,R7,i122,R8,i1,R9,s16,arbace/string.aev13,arbace.string17,replace-first-strm10,R10,TR4,L1,V3,Myn1,sm2,R3,R5,Myn5,matchm2,R3,R18,Myn7,replacem2,R3,R18,R7,i130,R8,i1,R9,s16,arbace/string.aev13,arbace.string13,replace-firstm14,R3,C16,java.lang.StringR4,L1,V3,Myn1,sm2,R3,R5,R13,R14,R0,s858,Replaces the first instance of match with replacement in s.\n\n   match/replacement can be:\n\n   char / char\n   string / string\n   pattern / (string or function of match).\n\n   See also replace.\n\n   The replacement is literal (i.e. none of its characters are treated\n   specially) for all cases above except pattern / string.\n\n   For pattern / string, $1, $2, etc. in the replacement string are\n   substituted with the string that matched the corresponding\n   parenthesized group in the pattern.  If you wish your replacement\n   string r to be used literally, use (re-quote-replacement r) as the\n   replacement argument.  See also documentation for\n   java.util.regex.Matcher's appendReplacement method.\n\n   Example:\n   (arbace.string/replace-first \"swap first two words\"\n                                 #\"(\\w+)(\\s+)(\\w+)\" \"$3$2$1\")\n   -> \"first swap two words\"R6,s3,1.2R7,i138,R8,i1,R9,s16,arbace/string.aev13,arbace.string4,joinm14,R3,C16,java.lang.StringR4,L2,V1,R19,V2,R20,R19,R0,s107,Returns a string of all elements in coll, as returned by (seq coll),\n   separated by an optional separator.R6,s3,1.2R7,i179,R8,i1,R9,s16,arbace/string.aev13,arbace.string10,capitalizem14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s91,Converts first character of the string to upper-case, all other\n  characters to lower-case.R6,s3,1.2R7,i195,R8,i1,R9,s16,arbace/string.aev13,arbace.string10,upper-casem14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s34,Converts string to all upper-case.R6,s3,1.2R7,i206,R8,i1,R9,s16,arbace/string.aev13,arbace.string10,lower-casem14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s34,Converts string to all lower-case.R6,s3,1.2R7,i212,R8,i1,R9,s16,arbace/string.aev13,arbace.string5,splitm12,R4,L2,V2,Myn1,sm2,R3,R5,Myn2,rem2,R3,R15,V3,Myn1,sm2,R3,R5,Myn2,rem2,R3,R15,R21,R0,s212,Splits string on a regular expression.  Optional argument limit is\n  the maximum number of parts. Not lazy. Returns vector of the parts.\n  Trailing empty strings are not returned - pass limit of -1 to return all.R6,s3,1.2R7,i218,R8,i1,R9,s16,arbace/string.aev13,arbace.string11,split-linesm12,R4,L1,V1,Myn1,sm2,R3,R5,R0,s62,Splits s on \\n or \\r\\n. Trailing empty lines are not returned.R6,s3,1.2R7,i228,R8,i1,R9,s16,arbace/string.aev13,arbace.string4,trimm14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s44,Removes whitespace from both ends of string.R6,s3,1.2R7,i234,R8,i1,R9,s16,arbace/string.aev13,arbace.string5,trimlm14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s48,Removes whitespace from the left side of string.R6,s3,1.2R7,i251,R8,i1,R9,s16,arbace/string.aev13,arbace.string5,trimrm14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s49,Removes whitespace from the right side of string.R6,s3,1.2R7,i263,R8,i1,R9,s16,arbace/string.aev13,arbace.string12,trim-newlinem14,R3,C16,java.lang.StringR4,L1,V1,Myn1,sm2,R3,R5,R0,s96,Removes all trailing newline \\n or return \\r characters from\n  string.  Similar to Perl's chomp.R6,s3,1.2R7,i274,R8,i1,R9,s16,arbace/string.aev13,arbace.string6,blank?m12,R4,L1,V1,Myn1,sm2,R3,R5,R0,s53,True if s is nil, empty, or contains only whitespace.R6,s3,1.2R7,i287,R8,i1,R9,s16,arbace/string.aev13,arbace.string6,escapem14,R3,C16,java.lang.StringR4,L1,V2,Myn1,sm2,R3,R5,R22,R0,s195,Return a new string, using cmap to escape each character ch\n   from s as follows:\n\n   If (cmap ch) is nil, append ch to the new string.\n   If (cmap ch) is non-nil, append (str (cmap ch)) instead.R6,s3,1.2R7,i300,R8,i1,R9,s16,arbace/string.aev13,arbace.string8,index-ofm12,R4,L2,V2,Myn1,sm2,R3,R5,R23,V3,Myn1,sm2,R3,R5,R23,Myn10,from-indexm2,R3,R24,R0,s123,Return index of value (string or char) in s, optionally searching\n  forward from from-index. Return nil if value not found.R6,s3,1.8R7,i318,R8,i1,R9,s16,arbace/string.aev13,arbace.string13,last-index-ofm12,R4,L2,V2,Myn1,sm2,R3,R5,R23,V3,Myn1,sm2,R3,R5,R23,Myn10,from-indexm2,R3,R24,R0,s129,Return last index of value (string or char) in s, optionally\n  searching backward from from-index. Return nil if value not found.R6,s3,1.8R7,i339,R8,i1,R9,s16,arbace/string.aev13,arbace.string12,starts-with?m12,R4,L1,V2,Myn1,sm2,R3,R5,Myn6,substrm2,R3,R18,R0,s29,True if s starts with substr.R6,s3,1.8R7,i360,R8,i1,R9,s16,arbace/string.aev13,arbace.string10,ends-with?m12,R4,L1,V2,Myn1,sm2,R3,R5,Myn6,substrm2,R3,R18,R0,s27,True if s ends with substr.R6,s3,1.8R7,i366,R8,i1,R9,s16,arbace/string.aev13,arbace.string9,includes?m12,R4,L1,V2,Myn1,sm2,R3,R5,Myn6,substrm2,R3,R5,R0,s26,True if s includes substr.R6,s3,1.8R7,i372,R8,i1,R9,s16,arbace/string.ae")

var Lit_7 *jrt.String = jrt.Intern("arbace.string$eval885000004$loading__1927001464__auto____885000005")

var Lit_8 *jrt.String = jrt.Intern("arbace.string$eval885000008$fn__885000009")

var Lit_9 *jrt.String = jrt.Intern("arbace.string$reverse")

var Lit_10 *jrt.String = jrt.Intern("arbace.string$re_quote_replacement")

var Lit_11 *jrt.String = jrt.Intern("arbace.string$replace_by")

var Lit_12 *jrt.String = jrt.Intern("arbace.string$replace")

var Lit_13 *jrt.String = jrt.Intern("arbace.string$replace_first_by")

var Lit_14 *jrt.String = jrt.Intern("arbace.string$replace_first_char")

var Lit_15 *jrt.String = jrt.Intern("arbace.string$replace_first_str")

var Lit_16 *jrt.String = jrt.Intern("arbace.string$replace_first")

var Lit_17 *jrt.String = jrt.Intern("arbace.string$join")

var Lit_18 *jrt.String = jrt.Intern("arbace.string$capitalize")

var Lit_19 *jrt.String = jrt.Intern("arbace.string$upper_case")

var Lit_20 *jrt.String = jrt.Intern("arbace.string$lower_case")

var Lit_21 *jrt.String = jrt.Intern("arbace.string$split")

var Lit_22 *jrt.String = jrt.Intern("arbace.string$split_lines")

var Lit_23 *jrt.String = jrt.Intern("arbace.string$trim")

var Lit_24 *jrt.String = jrt.Intern("arbace.string$triml")

var Lit_25 *jrt.String = jrt.Intern("arbace.string$trimr")

var Lit_26 *jrt.String = jrt.Intern("arbace.string$trim_newline")

var Lit_27 *jrt.String = jrt.Intern("arbace.string$blank_QMARK_")

var Lit_28 *jrt.String = jrt.Intern("arbace.string$escape")

var Lit_29 *jrt.String = jrt.Intern("arbace.string$index_of")

var Lit_30 *jrt.String = jrt.Intern("arbace.string$last_index_of")

var Lit_31 *jrt.String = jrt.Intern("arbace.string$starts_with_QMARK_")

var Lit_32 *jrt.String = jrt.Intern("arbace.string$ends_with_QMARK_")

var Lit_33 *jrt.String = jrt.Intern("arbace.string$includes_QMARK_")
