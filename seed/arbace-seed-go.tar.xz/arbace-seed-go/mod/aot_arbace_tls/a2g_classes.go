//line a2g_classes.ae:1
package aot_arbace_tls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_tls_connect_A_class, Name: "arbace.tls$connect", Modifiers: 25, Simple: "connect", Go: "arbace/aot_arbace_tls.A_arbace_tls_connect_A", Source: "tls.ae", Declaring: &A_arbace_tls_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_class, Name: "arbace.tls$eval1733000004$loading__1927001464__auto____1733000005", Modifiers: 25, Simple: "loading__1927001464__auto____1733000005", Go: "arbace/aot_arbace_tls.A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A", Source: "tls.ae", Declaring: &A_arbace_tls_eval1733000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_tls_eval1733000008_fn__1733000009_A_class, Name: "arbace.tls$eval1733000008$fn__1733000009", Modifiers: 25, Simple: "fn__1733000009", Go: "arbace/aot_arbace_tls.A_arbace_tls_eval1733000008_fn__1733000009_A", Source: "tls.ae", Declaring: &A_arbace_tls_eval1733000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_tls_fail_A_class, Name: "arbace.tls$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_tls.A_arbace_tls_fail_A", Source: "tls.ae", Declaring: &A_arbace_tls_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_tls_fn__1733000015_A_class, Name: "arbace.tls$fn__1733000015", Modifiers: 25, Simple: "fn__1733000015", Go: "arbace/aot_arbace_tls.A_arbace_tls_fn__1733000015_A", Source: "tls.ae", Declaring: &A_arbace_tls_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_tls_peer_certificates_A_class, Name: "arbace.tls$peer_certificates", Modifiers: 25, Simple: "peer_certificates", Go: "arbace/aot_arbace_tls.A_arbace_tls_peer_certificates_A", Source: "tls.ae", Declaring: &A_arbace_tls_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_tls_pem_bytes_A_class, Name: "arbace.tls$pem_bytes", Modifiers: 25, Simple: "pem_bytes", Go: "arbace/aot_arbace_tls.A_arbace_tls_pem_bytes_A", Source: "tls.ae", Declaring: &A_arbace_tls_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_tls_read_roots_A_class, Name: "arbace.tls$read_roots", Modifiers: 25, Simple: "read_roots", Go: "arbace/aot_arbace_tls.A_arbace_tls_read_roots_A", Source: "tls.ae", Declaring: &A_arbace_tls_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_tls_session_A_class, Name: "arbace.tls$session", Modifiers: 25, Simple: "session", Go: "arbace/aot_arbace_tls.A_arbace_tls_session_A", Source: "tls.ae", Declaring: &A_arbace_tls_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_tls_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls_A_New()}; return nil }

var A_arbace_tls_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_tls_A_new}

var A_arbace_tls_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_tls.A_arbace_tls_A"})

func init() { i := A_arbace_tls_A_class.Info(); i.IsInstance = A_arbace_tls_A_InstanceOf; i.Init = A_arbace_tls_A_Init; i.Table = A_arbace_tls_A_members }

var A_arbace_tls_connect_A_class *jrt.Class

func A_arbace_tls_eval1733000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls_eval1733000004_A_New()}; return nil }

var A_arbace_tls_eval1733000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_tls_eval1733000004_A_new}

var A_arbace_tls_eval1733000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls$eval1733000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_tls_A_class, Simple: "eval1733000004", Go: "arbace/aot_arbace_tls.A_arbace_tls_eval1733000004_A"})

func init() { i := A_arbace_tls_eval1733000004_A_class.Info(); i.IsInstance = A_arbace_tls_eval1733000004_A_InstanceOf; i.Table = A_arbace_tls_eval1733000004_A_members }

var A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_class *jrt.Class

func A_arbace_tls_eval1733000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls_eval1733000008_A_New()}; return nil }

var A_arbace_tls_eval1733000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_tls_eval1733000008_A_new}

var A_arbace_tls_eval1733000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls$eval1733000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_tls_A_class, Simple: "eval1733000008", Go: "arbace/aot_arbace_tls.A_arbace_tls_eval1733000008_A"})

func init() { i := A_arbace_tls_eval1733000008_A_class.Info(); i.IsInstance = A_arbace_tls_eval1733000008_A_InstanceOf; i.Table = A_arbace_tls_eval1733000008_A_members }

var A_arbace_tls_eval1733000008_fn__1733000009_A_class *jrt.Class

var A_arbace_tls_fail_A_class *jrt.Class

var A_arbace_tls_fn__1733000015_A_class *jrt.Class

var A_arbace_tls_peer_certificates_A_class *jrt.Class

var A_arbace_tls_pem_bytes_A_class *jrt.Class

var A_arbace_tls_read_roots_A_class *jrt.Class

var A_arbace_tls_session_A_class *jrt.Class

func A_arbace_tls__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_tls__init_A_Load__O()}; return nil }

func A_arbace_tls__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls__init_A_New()}; return nil }

var A_arbace_tls__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_tls__init_A_invoke, New: A_arbace_tls__init_A_new}

var A_arbace_tls__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_tls.A_arbace_tls__init_A", Source: "tls.ae"})

func init() { i := A_arbace_tls__init_A_class.Info(); i.IsInstance = A_arbace_tls__init_A_InstanceOf; i.Init = A_arbace_tls__init_A_Init; i.Table = A_arbace_tls__init_A_members }
