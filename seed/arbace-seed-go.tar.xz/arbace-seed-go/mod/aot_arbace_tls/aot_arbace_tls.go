//line aot_arbace_tls.ae:1
package aot_arbace_tls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_New() *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Ctor() {}
//line :5:1
func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_tls_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_tls_A_const_2); lang.IFn_Cast(A_arbace_tls_A_const_1.GetRawRoot__O()).Invoke_O_O__O(A_arbace_tls_A_const_3, A_arbace_tls_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :5:1
func A_arbace_tls_eval1733000008_fn__1733000009_A_New() *A_arbace_tls_eval1733000008_fn__1733000009_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_eval1733000008_fn__1733000009_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Ctor() {}
//line :5:1
func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_tls_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_tls_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_tls_A_const_9), A_arbace_tls_A_const_7.GetRawRoot__O(), A_arbace_tls_A_const_8) }




































func A_arbace_tls_fail_A_New() *A_arbace_tls_fail_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_fail_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_tls_fail_A) Ctor() {}
//line :42:1
func (t *A_arbace_tls_fail_A) Invoke_O_O_O_O__O(self, kind__0, msg__1, data__2 any) any { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_tls_A_const_10.GetRawRoot__O()).Invoke_O_O__O(msg__1, lang.IFn_Cast(A_arbace_tls_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(data__2, A_arbace_tls_A_const_12, kind__0))))) }


func A_arbace_tls_pem_bytes_A_New() *A_arbace_tls_pem_bytes_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_pem_bytes_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_tls_pem_bytes_A) Ctor() {}
//line :45:1
func (t *A_arbace_tls_pem_bytes_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)) { return jrt.NN(jrt.String_Cast(x__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_14.GetRawRoot__O()).Invoke_O__O(x__0)) { return x__0 } else { if A_arbace_tls_A_const_15 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_tls_A_const_16.GetRawRoot__O()).Invoke_O__O(x__0)))))) } else { return nil
	}
	}
	}
}
func A_arbace_tls_read_roots_A_New() *A_arbace_tls_read_roots_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_read_roots_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_tls_read_roots_A) Ctor() {}
//line :53:1
func (t *A_arbace_tls_read_roots_A) Invoke_O_O__O(self, source__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(source__0, Lit_13)) { var name__2 any = lang.IFn_Cast(A_arbace_tls_A_const_18.GetRawRoot__O()).Invoke_O_O__O(source__0, A_arbace_tls_A_const_21); var load_ref__3 any = lang.IFn_Cast(A_arbace_tls_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_tls_A_const_22); var text__4 any = lang.IFn_Cast(load_ref__3).Invoke_O__O(name__2)



		if lang.Util_Identical_O_O__Z_NoInit(text__4, nil) {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_tls_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_tls_A_const_24; tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__2)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_tls_A_const_24, source__0))) }
		return lang.IFn_Cast(A_arbace_tls_A_const_20.GetRawRoot__O()).Invoke_O__O(text__4) } else {
//line :57:1
			var f__2 any = jrt.File_New_String(jrt.String_Cast(source__0))







			if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { } else {
				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_tls_A_const_23.GetRawRoot__O()); var tmp4 any = A_arbace_tls_A_const_24; tmp3.Invoke_O_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, source__0)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_tls_A_const_24, source__0))) }
			return jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref()
		}
}
func A_arbace_tls_fn__1733000015_A_New() *A_arbace_tls_fn__1733000015_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_fn__1733000015_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_tls_fn__1733000015_A) Ctor() {}
//line :70:1
func (t *A_arbace_tls_fn__1733000015_A) Invoke_O__O(self any) any { var s__1 any = jrt.System_Getenv_String__String(Lit_11).Ref(); if
									jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1)) { return nil } else {
										return lang.IFn_Cast(A_arbace_tls_A_const_26.GetRawRoot__O()).Invoke_O__O(s__1) } }

func A_arbace_tls_connect_A_New() *A_arbace_tls_connect_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_connect_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_tls_connect_A) Ctor() {}
//line :74:1
func (t *A_arbace_tls_connect_A) Invoke_O_O_O_O__O(self, host__0, port__1, p__1733000017__2 any) any { var map__1733000018__4 any = p__1733000017__2; var map__1733000018__5 any; if lang.ISeq_InstanceOf(map__1733000018__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_27.GetRawRoot__O()).Invoke_O__O(map__1733000018__4)) { map__1733000018__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_tls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1733000018__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1733000018__4)) { map__1733000018__5 = lang.IFn_Cast(A_arbace_tls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1733000018__4) } else { map__1733000018__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1733000018__5 = map__1733000018__4 }; var server_name__6 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_31); var alpn__7 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_32); var roots__8 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_24); var timeout__9 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_33); var server_name__10 any; var or__1927000174__auto____10 any = server_name__6; if




	jrt.J2g_Truth(or__1927000174__auto____10) { server_name__10 = or__1927000174__auto____10 } else { server_name__10 = host__0 }; var timeout__11 int32; var tmp1 any; var or__1927000174__auto____11 any = timeout__9; if
	jrt.J2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else { tmp1 = A_arbace_tls_A_const_34 }; timeout__11 = lang.RT_IntCast_O__I_NoInit(tmp1); var alpn__12 any; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_29.GetRawRoot__O()).Invoke_O__O(alpn__7)) { alpn__12 = lang.IFn_Cast(A_arbace_tls_A_const_35.GetRawRoot__O()).Invoke_O_O__O(Lit_1, alpn__7) } else { alpn__12 = nil }; var roots__13 any; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_36.GetRawRoot__O()).Invoke_O__O(roots__8)) { roots__13 = lang.IFn_Cast(A_arbace_tls_A_const_20.GetRawRoot__O()).Invoke_O__O(roots__8) } else { roots__13 = lang.IFn_Cast(A_arbace_tls_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_tls_A_const_40.GetRawRoot__O()) }; var data__14 any = /*line :74:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_tls_A_const_37, host__0, A_arbace_tls_A_const_38, port__1, A_arbace_tls_A_const_31, server_name__10)); var r__15 any = lang.IFn_Cast(A_arbace_tls_A_const_39.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(host__0, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(port__1)).Ref(), server_name__10, alpn__12, roots__13, jrt.Integer_ValueOf_I__Integer_NoInit(timeout__11).Ref()); if










	jrt.Socket_InstanceOf(r__15) { return r__15 } else { var vec__1733000020__16 any = r__15; var kind__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1733000020__16, lang.RT_IntCast_J__I_NoInit(0), nil); var msg__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1733000020__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_tls_A_const_23.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_2, nil, Lit_3, nil, nil, Lit_4, nil); var tmp4 *jrt.String



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_41.GetRawRoot__O()).Invoke_O_O__O(server_name__10, host__0)) { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, server_name__10, nil)) } else { tmp4 = nil }
//line :88:1
		return tmp2.Invoke_O_O_O__O(kind__17, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, host__0, nil, port__1, tmp4.Ref(), nil, msg__18)).Ref(), data__14) } }
//line :74:1
func (t *A_arbace_tls_connect_A) Invoke_O_O_O__O(self, host__0, port__1 any) any {


	return lang.IFn_Cast(A_arbace_tls_A_const_42.GetRawRoot__O()).Invoke_O_O_O__O(host__0, port__1, nil)
}














func A_arbace_tls_session_A_New() *A_arbace_tls_session_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_session_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_tls_session_A) Ctor() {}
//line :93:1
func (t *A_arbace_tls_session_A) Invoke_O_O__O(self, s__0 any) any { var map__1733000024__2 any = lang.IFn_Cast(A_arbace_tls_A_const_43.GetRawRoot__O()).Invoke_O__O(s__0); var map__1733000024__3 any; if



	lang.ISeq_InstanceOf(map__1733000024__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_27.GetRawRoot__O()).Invoke_O__O(map__1733000024__2)) { map__1733000024__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_tls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1733000024__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1733000024__2)) { map__1733000024__3 = lang.IFn_Cast(A_arbace_tls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1733000024__2) } else { map__1733000024__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1733000024__3 = map__1733000024__2 }; var m__4 any = map__1733000024__3; var application_protocol__5 any = /*line :93:1*/lang.RT_Get_O_O__O_NoInit(map__1733000024__3, A_arbace_tls_A_const_44); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_tls_A_const_11.GetRawRoot__O()); var tmp2 any = A_arbace_tls_A_const_44; var tmp3 any; if




	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_tls_A_const_25.GetRawRoot__O()).Invoke_O__O(application_protocol__5)) { tmp3 = nil } else { tmp3 = application_protocol__5 }; return tmp1.Invoke_O_O_O__O(m__4, tmp2, tmp3) }

func A_arbace_tls_peer_certificates_A_New() *A_arbace_tls_peer_certificates_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_peer_certificates_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_tls_peer_certificates_A) Ctor() {}
//line :100:1
func (t *A_arbace_tls_peer_certificates_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.IFn_Cast(A_arbace_tls_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_tls_A_const_46.GetRawRoot__O()).Invoke_O__O(s__0))
}



type A_arbace_tls_A struct{ jrt.Object }

var A_arbace_tls_A_const_pool *jrt.RefArray

var A_arbace_tls_A_const_0 *lang.Var

var A_arbace_tls_A_const_1 *lang.Var

var A_arbace_tls_A_const_2 any

var A_arbace_tls_A_const_3 any

var A_arbace_tls_A_const_4 any

var A_arbace_tls_A_const_5 *lang.Var

var A_arbace_tls_A_const_6 *lang.Var

var A_arbace_tls_A_const_7 *lang.Var

var A_arbace_tls_A_const_8 any

var A_arbace_tls_A_const_9 *lang.Var

var A_arbace_tls_A_const_10 *lang.Var

var A_arbace_tls_A_const_11 *lang.Var

var A_arbace_tls_A_const_12 *lang.Keyword

var A_arbace_tls_A_const_13 *lang.Var

var A_arbace_tls_A_const_14 *lang.Var

var A_arbace_tls_A_const_15 *lang.Keyword

var A_arbace_tls_A_const_16 *lang.Var

var A_arbace_tls_A_const_17 *lang.Var

var A_arbace_tls_A_const_18 *lang.Var

var A_arbace_tls_A_const_19 *lang.Var

var A_arbace_tls_A_const_20 *lang.Var

var A_arbace_tls_A_const_21 any

var A_arbace_tls_A_const_22 any

var A_arbace_tls_A_const_23 *lang.Var

var A_arbace_tls_A_const_24 *lang.Keyword

var A_arbace_tls_A_const_25 *lang.Var

var A_arbace_tls_A_const_26 *lang.Var

var A_arbace_tls_A_const_27 *lang.Var

var A_arbace_tls_A_const_28 *lang.Var

var A_arbace_tls_A_const_29 *lang.Var

var A_arbace_tls_A_const_30 *lang.Var

var A_arbace_tls_A_const_31 *lang.Keyword

var A_arbace_tls_A_const_32 *lang.Keyword

var A_arbace_tls_A_const_33 *lang.Keyword

var A_arbace_tls_A_const_34 any

var A_arbace_tls_A_const_35 *lang.Var

var A_arbace_tls_A_const_36 *lang.Var

var A_arbace_tls_A_const_37 *lang.Keyword

var A_arbace_tls_A_const_38 *lang.Keyword

var A_arbace_tls_A_const_39 *lang.Var

var A_arbace_tls_A_const_40 *lang.Var

var A_arbace_tls_A_const_41 *lang.Var

var A_arbace_tls_A_const_42 *lang.Var

var A_arbace_tls_A_const_43 *lang.Var

var A_arbace_tls_A_const_44 *lang.Keyword

var A_arbace_tls_A_const_45 *lang.Var

var A_arbace_tls_A_const_46 *lang.Var

var A_arbace_tls_A_init jrt.ClassInit

func A_arbace_tls_A_Init() { if !A_arbace_tls_A_init.Done() { A_arbace_tls_A_init.Run(A_arbace_tls_A_clinit) } }

func A_arbace_tls_A_clinit() { A_arbace_tls_A_clinit_p0(); A_arbace_tls_A_clinit_p1(); A_arbace_tls_A_clinit_p2(); A_arbace_tls_A_clinit_p3() }

func A_arbace_tls_A_clinit_p0() { jrt.StartCheck(); A_arbace_tls_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 64); A_arbace_tls_A_const_0 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[17]); A_arbace_tls_A_const_1 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[18]); A_arbace_tls_A_const_2 = A_arbace_tls_A_const_pool.A[19]; A_arbace_tls_A_const_3 = A_arbace_tls_A_const_pool.A[20]; A_arbace_tls_A_const_4 = A_arbace_tls_A_const_pool.A[21]; A_arbace_tls_A_const_5 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[22]); A_arbace_tls_A_const_6 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[23]); A_arbace_tls_A_const_7 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[24]); A_arbace_tls_A_const_8 = A_arbace_tls_A_const_pool.A[25]; A_arbace_tls_A_const_9 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[26]); A_arbace_tls_A_const_10 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[27]); A_arbace_tls_A_const_11 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[28]) }

func A_arbace_tls_A_clinit_p1() { A_arbace_tls_A_const_12 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[29]); A_arbace_tls_A_const_13 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[30]); A_arbace_tls_A_const_14 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[31]); A_arbace_tls_A_const_15 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[32]); A_arbace_tls_A_const_16 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[33]); A_arbace_tls_A_const_17 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[34]); A_arbace_tls_A_const_18 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[35]); A_arbace_tls_A_const_19 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[36]); A_arbace_tls_A_const_20 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[37]); A_arbace_tls_A_const_21 = A_arbace_tls_A_const_pool.A[38]; A_arbace_tls_A_const_22 = A_arbace_tls_A_const_pool.A[39]; A_arbace_tls_A_const_23 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[40]) }

func A_arbace_tls_A_clinit_p2() { A_arbace_tls_A_const_24 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[41]); A_arbace_tls_A_const_25 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[42]); A_arbace_tls_A_const_26 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[43]); A_arbace_tls_A_const_27 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[44]); A_arbace_tls_A_const_28 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[45]); A_arbace_tls_A_const_29 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[46]); A_arbace_tls_A_const_30 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[47]); A_arbace_tls_A_const_31 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[48]); A_arbace_tls_A_const_32 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[49]); A_arbace_tls_A_const_33 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[50]); A_arbace_tls_A_const_34 = A_arbace_tls_A_const_pool.A[51]; A_arbace_tls_A_const_35 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[52]) }

func A_arbace_tls_A_clinit_p3() { A_arbace_tls_A_const_36 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[53]); A_arbace_tls_A_const_37 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[54]); A_arbace_tls_A_const_38 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[55]); A_arbace_tls_A_const_39 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[56]); A_arbace_tls_A_const_40 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[57]); A_arbace_tls_A_const_41 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[58]); A_arbace_tls_A_const_42 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[59]); A_arbace_tls_A_const_43 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[60]); A_arbace_tls_A_const_44 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[61]); A_arbace_tls_A_const_45 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[62]); A_arbace_tls_A_const_46 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[63]) }

func A_arbace_tls_A_New() *A_arbace_tls_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_A) Ctor() {}

func (t *A_arbace_tls_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_A) GetClass__Class() *jrt.Class { return A_arbace_tls_A_class }

func (t *A_arbace_tls_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_tls_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_A); return ok }

func A_arbace_tls_A_Cast(x any) *A_arbace_tls_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_A_class)) }; return v }



type A_arbace_tls_connect_A struct{ j2g_header uint64 }

var A_arbace_tls_connect_A_fn_class *jrt.Class



type A_arbace_tls_eval1733000004_A struct{ jrt.Object }

func A_arbace_tls_eval1733000004_A_New() *A_arbace_tls_eval1733000004_A { t := &A_arbace_tls_eval1733000004_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_eval1733000004_A) Ctor() {}

func (t *A_arbace_tls_eval1733000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000004_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000004_A_class }

func (t *A_arbace_tls_eval1733000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000004_A); return ok }

func A_arbace_tls_eval1733000004_A_Cast(x any) *A_arbace_tls_eval1733000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000004_A_class)) }; return v }



type A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A struct{ j2g_header uint64 }

var A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_fn_class *jrt.Class



type A_arbace_tls_eval1733000008_A struct{ jrt.Object }

func A_arbace_tls_eval1733000008_A_New() *A_arbace_tls_eval1733000008_A { t := &A_arbace_tls_eval1733000008_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_eval1733000008_A) Ctor() {}

func (t *A_arbace_tls_eval1733000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000008_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000008_A_class }

func (t *A_arbace_tls_eval1733000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000008_A); return ok }

func A_arbace_tls_eval1733000008_A_Cast(x any) *A_arbace_tls_eval1733000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000008_A_class)) }; return v }



type A_arbace_tls_eval1733000008_fn__1733000009_A struct{ j2g_header uint64 }

var A_arbace_tls_eval1733000008_fn__1733000009_A_fn_class *jrt.Class



type A_arbace_tls_fail_A struct{ j2g_header uint64 }

var A_arbace_tls_fail_A_fn_class *jrt.Class



type A_arbace_tls_fn__1733000015_A struct{ j2g_header uint64 }

var A_arbace_tls_fn__1733000015_A_fn_class *jrt.Class



type A_arbace_tls_peer_certificates_A struct{ j2g_header uint64 }

var A_arbace_tls_peer_certificates_A_fn_class *jrt.Class



type A_arbace_tls_pem_bytes_A struct{ j2g_header uint64 }

var A_arbace_tls_pem_bytes_A_fn_class *jrt.Class



type A_arbace_tls_read_roots_A struct{ j2g_header uint64 }

var A_arbace_tls_read_roots_A_fn_class *jrt.Class



type A_arbace_tls_session_A struct{ j2g_header uint64 }

var A_arbace_tls_session_A_fn_class *jrt.Class
