//line aot_arbace_tls.ae:1
package aot_arbace_tls

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/aot_arbace_tls_host"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_New() *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Ctor() {}
//line :5:1
func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_tls_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_tls_A_const_1); lang.IFn_Cast(A_arbace_tls_A_const_2.GetRawRoot__O()).Invoke_O_O__O(A_arbace_tls_A_const_3, A_arbace_tls_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :5:1
func A_arbace_tls_eval1733000008_fn__1733000009_A_New() *A_arbace_tls_eval1733000008_fn__1733000009_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_eval1733000008_fn__1733000009_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Ctor() {}
//line :5:1
func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_tls_A_const_5.GetRawRoot__O()); var tmp2 any; var root_10 any = A_arbace_tls_A_const_6.GetRawRoot__O(); var linked_11 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_10, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_12 lang.IFn; if linked_11 == nil { ifn_12 = lang.IFn_Cast(root_10) } else { ifn_12 = nil }; var arg_13 any = A_arbace_tls_A_const_7; if linked_11 == nil { tmp2 = ifn_12.Invoke_O__O(arg_13) } else { tmp2 = linked_11.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_10, arg_13) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_tls_A_const_8.GetRawRoot__O(), A_arbace_tls_A_const_9) }




































func A_arbace_tls_fail_A_New() *A_arbace_tls_fail_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_fail_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_tls_fail_A) Ctor() {}
//line :42:1
func (t *A_arbace_tls_fail_A) Invoke_O_O_O_O__O(self, kind__0, msg__1, data__2 any) any { var tmp1 any; var root_26 any = A_arbace_tls_A_const_10.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_28 lang.IFn; if
											linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = msg__1; var arg_30 any; var root_20 any = A_arbace_tls_A_const_11.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = data__2; var arg_24 any = A_arbace_tls_A_const_12; var arg_25 any = kind__0; if linked_21 == nil { arg_30 = ifn_22.Invoke_O_O_O__O(arg_23, arg_24, arg_25) } else { arg_30 = linked_21.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_20, arg_23, arg_24, arg_25) }; if linked_27 == nil { tmp1 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { tmp1 = linked_27.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; /*line :42:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_tls_pem_bytes_A_New() *A_arbace_tls_pem_bytes_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_pem_bytes_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_tls_pem_bytes_A) Ctor() {}
//line :45:1
func (t *A_arbace_tls_pem_bytes_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_31 any = A_arbace_tls_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = x__0; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp1) { return jrt.NN(jrt.String_Cast(x__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else { var tmp2 any; var root_35 any = A_arbace_tls_A_const_14.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_bytes_QMARK__A_fn_class); var ifn_37 lang.IFn
		if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = x__0; if linked_36 == nil { tmp2 = ifn_37.Invoke_O__O(arg_38) } else { tmp2 = linked_36.(*aot_arbace_core.A_arbace_core_bytes_QMARK__A).Invoke_O_O__O(root_35, arg_38) }
//line :48:1
		if jrt.J2g_Truth(tmp2) { return x__0 } else { if A_arbace_tls_A_const_15 != nil { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp4 any; var root_39 any = A_arbace_tls_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_41 lang.IFn


			if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = x__0; if linked_40 == nil { tmp4 = ifn_41.Invoke_O__O(arg_42) } else { tmp4 = linked_40.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_39, arg_42) }
//line :48:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4))))) } else { return nil
			}
		}
	}
}
func A_arbace_tls_read_roots_A_New() *A_arbace_tls_read_roots_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_read_roots_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_tls_read_roots_A) Ctor() {}
//line :53:1
func (t *A_arbace_tls_read_roots_A) Invoke_O_O__O(self, source__0 any) any {



	var tmp1 any; var root_43 any = A_arbace_tls_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = source__0; var arg_47 any = Lit_13; if linked_44 == nil { tmp1 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp1 = linked_44.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; if jrt.J2g_Truth(tmp1) { var name__2 any; var root_48 any = A_arbace_tls_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_50 lang.IFn
		if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = source__0; var arg_52 any = A_arbace_tls_A_const_19; if linked_49 == nil { name__2 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { name__2 = linked_49.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }
//line :57:1
		var load_ref__3 any; var root_53 any = A_arbace_tls_A_const_20.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_55 lang.IFn

		if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_tls_A_const_21; if linked_54 == nil { load_ref__3 = ifn_55.Invoke_O__O(arg_56) } else { load_ref__3 = linked_54.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_53, arg_56) }
//line :57:1
		var text__4 any = lang.IFn_Cast(load_ref__3).Invoke_O__O(name__2)



		if lang.Util_Identical_O_O__Z_NoInit(text__4, nil) {
			var root_61 any = A_arbace_tls_A_const_23.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, A_arbace_tls_fail_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = A_arbace_tls_A_const_24; var arg_65 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__2)).Ref(); var arg_66 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_tls_A_const_24, source__0)); if linked_62 == nil { ifn_63.Invoke_O_O_O__O(arg_64, arg_65, arg_66) } else { linked_62.(*A_arbace_tls_fail_A).Invoke_O_O_O_O__O(root_61, arg_64, arg_65, arg_66) } }
		var root_57 any = A_arbace_tls_A_const_22.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_tls_pem_bytes_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = text__4; if linked_58 == nil { return ifn_59.Invoke_O__O(arg_60) } else { return linked_58.(*A_arbace_tls_pem_bytes_A).Invoke_O_O__O(root_57, arg_60) } } else {
//line :57:1
			var f__2 any = jrt.File_New_String(jrt.String_Cast(source__0))







			if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { } else {
				var root_67 any = A_arbace_tls_A_const_23.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, A_arbace_tls_fail_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = A_arbace_tls_A_const_24; var arg_71 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, source__0)).Ref(); var arg_72 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_tls_A_const_24, source__0)); if linked_68 == nil { ifn_69.Invoke_O_O_O__O(arg_70, arg_71, arg_72) } else { linked_68.(*A_arbace_tls_fail_A).Invoke_O_O_O_O__O(root_67, arg_70, arg_71, arg_72) } }
			return jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref()
		}
}
func A_arbace_tls_fn__1733000015_A_New() *A_arbace_tls_fn__1733000015_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_fn__1733000015_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_tls_fn__1733000015_A) Ctor() {}
//line :70:1
func (t *A_arbace_tls_fn__1733000015_A) Invoke_O__O(self any) any { var s__1 any = jrt.System_Getenv_String__String(Lit_11).Ref(); var tmp1 any; var root_73 any = A_arbace_tls_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_75 lang.IFn; if
									linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = s__1; if linked_74 == nil { tmp1 = ifn_75.Invoke_O__O(arg_76) } else { tmp1 = linked_74.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(tmp1) { return nil } else {
										var root_77 any = A_arbace_tls_A_const_26.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, A_arbace_tls_read_roots_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = s__1; if linked_78 == nil { return ifn_79.Invoke_O__O(arg_80) } else { return linked_78.(*A_arbace_tls_read_roots_A).Invoke_O_O__O(root_77, arg_80) } } }

func A_arbace_tls_connect_A_New() *A_arbace_tls_connect_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_connect_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_tls_connect_A) Ctor() {}
//line :74:1
func (t *A_arbace_tls_connect_A) Invoke_O_O_O_O__O(self, host__0, port__1, p__1733000017__2 any) any { var map__1733000018__4 any = p__1733000017__2; var map__1733000018__5 any; if lang.ISeq_InstanceOf(map__1733000018__4) { var tmp1 any; var root_81 any = A_arbace_tls_A_const_27.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = map__1733000018__4; if linked_82 == nil { tmp1 = ifn_83.Invoke_O__O(arg_84) } else { tmp1 = linked_82.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_81, arg_84) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_85 any = A_arbace_tls_A_const_28.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = map__1733000018__4; if linked_86 == nil { tmp2 = ifn_87.Invoke_O__O(arg_88) } else { tmp2 = linked_86.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_85, arg_88) }; map__1733000018__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_89 any = A_arbace_tls_A_const_29.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = map__1733000018__4; if linked_90 == nil { tmp3 = ifn_91.Invoke_O__O(arg_92) } else { tmp3 = linked_90.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(tmp3) { var root_93 any = A_arbace_tls_A_const_30.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = map__1733000018__4; if linked_94 == nil { map__1733000018__5 = ifn_95.Invoke_O__O(arg_96) } else { map__1733000018__5 = linked_94.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_93, arg_96) } } else { map__1733000018__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1733000018__5 = map__1733000018__4 }; var server_name__6 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_31); var alpn__7 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_32); var roots__8 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_24); var timeout__9 any = lang.RT_Get_O_O__O_NoInit(map__1733000018__5, A_arbace_tls_A_const_33); var server_name__10 any; var or__1927000174__auto____10 any = server_name__6; if




	jrt.J2g_Truth(or__1927000174__auto____10) { server_name__10 = or__1927000174__auto____10 } else { server_name__10 = host__0 }; var timeout__11 int32; var tmp4 any; var or__1927000174__auto____11 any = timeout__9; if
	jrt.J2g_Truth(or__1927000174__auto____11) { tmp4 = or__1927000174__auto____11 } else { tmp4 = A_arbace_tls_A_const_34 }; timeout__11 = lang.RT_IntCast_O__I_NoInit(tmp4); var alpn__12 any; var tmp5 any; var root_97 any = /*line :74:1*/A_arbace_tls_A_const_29.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_99 lang.IFn; if






	linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = alpn__7; if linked_98 == nil { tmp5 = ifn_99.Invoke_O__O(arg_100) } else { tmp5 = linked_98.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_97, arg_100) }; if jrt.J2g_Truth(tmp5) { var root_101 any = A_arbace_tls_A_const_35.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = Lit_1; var arg_105 any = alpn__7; if linked_102 == nil { alpn__12 = ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { alpn__12 = linked_102.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_101, arg_104, arg_105) } } else { alpn__12 = nil }; var roots__13 any; var tmp6 any; var root_106 any = /*line :74:1*/A_arbace_tls_A_const_36.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_108 lang.IFn; if







	linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = roots__8; if linked_107 == nil { tmp6 = ifn_108.Invoke_O__O(arg_109) } else { tmp6 = linked_107.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_106, arg_109) }; if jrt.J2g_Truth(tmp6) { var root_110 any = A_arbace_tls_A_const_22.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, A_arbace_tls_pem_bytes_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = roots__8; if linked_111 == nil { roots__13 = ifn_112.Invoke_O__O(arg_113) } else { roots__13 = linked_111.(*A_arbace_tls_pem_bytes_A).Invoke_O_O__O(root_110, arg_113) } } else { var root_114 any = A_arbace_tls_A_const_6.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = A_arbace_tls_A_const_37.GetRawRoot__O(); if linked_115 == nil { roots__13 = ifn_116.Invoke_O__O(arg_117) } else { roots__13 = linked_115.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_114, arg_117) } }; var data__14 any = /*line :74:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_tls_A_const_38, host__0, A_arbace_tls_A_const_39, port__1, A_arbace_tls_A_const_31, server_name__10)); var r__15 any; var root_118 any = A_arbace_tls_A_const_40.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_tls_host.A_arbace_tls_host_connect_A_fn_class); var ifn_120 lang.IFn; if









	linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = host__0; var arg_122 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(port__1)).Ref(); var arg_123 any = server_name__10; var arg_124 any = alpn__12; var arg_125 any = roots__13; var arg_126 any = jrt.Integer_ValueOf_I__Integer_NoInit(timeout__11).Ref(); if linked_119 == nil { r__15 = ifn_120.Invoke_O_O_O_O_O_O__O(arg_121, arg_122, arg_123, arg_124, arg_125, arg_126) } else { r__15 = linked_119.(*aot_arbace_tls_host.A_arbace_tls_host_connect_A).Invoke_O_O_O_O_O_O_O__O(root_118, arg_121, arg_122, arg_123, arg_124, arg_125, arg_126) }; if
	jrt.Socket_InstanceOf(r__15) { return r__15 } else { var vec__1733000020__16 any = r__15; var kind__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1733000020__16, lang.RT_IntCast_J__I_NoInit(0), nil); var msg__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1733000020__16, lang.RT_IntCast_J__I_NoInit(1), nil); var root_132 any = A_arbace_tls_A_const_23.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_tls_fail_A_fn_class); var ifn_134 lang.IFn


		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = kind__17; var arg_136 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_2, nil, Lit_3, nil, nil, Lit_4, nil); var tmp8 *jrt.String; var tmp9 any; var root_127 any = A_arbace_tls_A_const_41.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_129 lang.IFn
		if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = server_name__10; var arg_131 any = host__0; if linked_128 == nil { tmp9 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp9 = linked_128.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp9) { tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, server_name__10, nil)) } else { tmp8 = nil }
//line :88:1
		arg_136 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, host__0, nil, port__1, tmp8.Ref(), nil, msg__18)).Ref(); var arg_137 any = data__14; if linked_133 == nil { return ifn_134.Invoke_O_O_O__O(arg_135, arg_136, arg_137) } else { return linked_133.(*A_arbace_tls_fail_A).Invoke_O_O_O_O__O(root_132, arg_135, arg_136, arg_137) } } }
//line :74:1
func (t *A_arbace_tls_connect_A) Invoke_O_O_O__O(self, host__0, port__1 any) any {


	var root_138 any = A_arbace_tls_A_const_42.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_tls_connect_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = host__0; var arg_142 any = port__1; var arg_143 any; if linked_139 == nil { return ifn_140.Invoke_O_O_O__O(arg_141, arg_142, arg_143) } else { return linked_139.(*A_arbace_tls_connect_A).Invoke_O_O_O_O__O(root_138, arg_141, arg_142, arg_143)
	}
}













func A_arbace_tls_session_A_New() *A_arbace_tls_session_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_session_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_tls_session_A) Ctor() {}
//line :93:1
func (t *A_arbace_tls_session_A) Invoke_O_O__O(self, s__0 any) any { var map__1733000024__2 any; var root_144 any = A_arbace_tls_A_const_43.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_tls_host.A_arbace_tls_host_session_A_fn_class); var ifn_146 lang.IFn; if



	linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = s__0; if linked_145 == nil { map__1733000024__2 = ifn_146.Invoke_O__O(arg_147) } else { map__1733000024__2 = linked_145.(*aot_arbace_tls_host.A_arbace_tls_host_session_A).Invoke_O_O__O(root_144, arg_147) }; var map__1733000024__3 any; if lang.ISeq_InstanceOf(map__1733000024__2) { var tmp1 any; var root_148 any = A_arbace_tls_A_const_27.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = map__1733000024__2; if linked_149 == nil { tmp1 = ifn_150.Invoke_O__O(arg_151) } else { tmp1 = linked_149.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_148, arg_151) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_152 any = A_arbace_tls_A_const_28.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = map__1733000024__2; if linked_153 == nil { tmp2 = ifn_154.Invoke_O__O(arg_155) } else { tmp2 = linked_153.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_152, arg_155) }; map__1733000024__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_156 any = A_arbace_tls_A_const_29.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = map__1733000024__2; if linked_157 == nil { tmp3 = ifn_158.Invoke_O__O(arg_159) } else { tmp3 = linked_157.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_156, arg_159) }; if jrt.J2g_Truth(tmp3) { var root_160 any = A_arbace_tls_A_const_30.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = map__1733000024__2; if linked_161 == nil { map__1733000024__3 = ifn_162.Invoke_O__O(arg_163) } else { map__1733000024__3 = linked_161.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_160, arg_163) } } else { map__1733000024__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1733000024__3 = map__1733000024__2 }; var m__4 any = map__1733000024__3; var application_protocol__5 any = /*line :93:1*/lang.RT_Get_O_O__O_NoInit(map__1733000024__3, A_arbace_tls_A_const_44); var root_168 any = A_arbace_tls_A_const_11.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_170 lang.IFn; if




	linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = m__4; var arg_172 any = A_arbace_tls_A_const_44; var arg_173 any; var tmp4 any; var root_164 any = A_arbace_tls_A_const_25.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = application_protocol__5; if linked_165 == nil { tmp4 = ifn_166.Invoke_O__O(arg_167) } else { tmp4 = linked_165.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_164, arg_167) }; if jrt.J2g_Truth(tmp4) { arg_173 = nil } else { arg_173 = application_protocol__5 }; if linked_169 == nil { return ifn_170.Invoke_O_O_O__O(arg_171, arg_172, arg_173) } else { return linked_169.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_168, arg_171, arg_172, arg_173) } }

func A_arbace_tls_peer_certificates_A_New() *A_arbace_tls_peer_certificates_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_peer_certificates_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_tls_peer_certificates_A) Ctor() {}
//line :100:1
func (t *A_arbace_tls_peer_certificates_A) Invoke_O_O__O(self, s__0 any) any {


	var root_178 any = A_arbace_tls_A_const_45.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any; var root_174 any = A_arbace_tls_A_const_46.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_tls_host.A_arbace_tls_host_peer_certificates_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = s__0; if linked_175 == nil { arg_181 = ifn_176.Invoke_O__O(arg_177) } else { arg_181 = linked_175.(*aot_arbace_tls_host.A_arbace_tls_host_peer_certificates_A).Invoke_O_O__O(root_174, arg_177) }; if linked_179 == nil { return ifn_180.Invoke_O__O(arg_181) } else { return linked_179.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_178, arg_181)
	}
}


type A_arbace_tls_A struct{ jrt.Object }

var A_arbace_tls_A_const_pool *jrt.RefArray

var A_arbace_tls_A_const_0 *lang.Var

var A_arbace_tls_A_const_1 any

var A_arbace_tls_A_const_2 *lang.Var

var A_arbace_tls_A_const_3 any

var A_arbace_tls_A_const_4 any

var A_arbace_tls_A_const_5 *lang.Var

var A_arbace_tls_A_const_6 *lang.Var

var A_arbace_tls_A_const_7 *lang.Var

var A_arbace_tls_A_const_8 *lang.Var

var A_arbace_tls_A_const_9 any

var A_arbace_tls_A_const_10 *lang.Var

var A_arbace_tls_A_const_11 *lang.Var

var A_arbace_tls_A_const_12 *lang.Keyword

var A_arbace_tls_A_const_13 *lang.Var

var A_arbace_tls_A_const_14 *lang.Var

var A_arbace_tls_A_const_15 *lang.Keyword

var A_arbace_tls_A_const_16 *lang.Var

var A_arbace_tls_A_const_17 *lang.Var

var A_arbace_tls_A_const_18 *lang.Var

var A_arbace_tls_A_const_19 any

var A_arbace_tls_A_const_20 *lang.Var

var A_arbace_tls_A_const_21 any

var A_arbace_tls_A_const_22 *lang.Var

var A_arbace_tls_A_const_23 *lang.Var

var A_arbace_tls_A_const_24 *lang.Keyword

var A_arbace_tls_A_const_25 *lang.Var

var A_arbace_tls_A_const_26 *lang.Var

var A_arbace_tls_A_const_27 *lang.Var

var A_arbace_tls_A_const_28 *lang.Var

var A_arbace_tls_A_const_29 *lang.Var

var A_arbace_tls_A_const_30 *lang.Var

var A_arbace_tls_A_const_31 *lang.Keyword

var A_arbace_tls_A_const_32 *lang.Keyword

var A_arbace_tls_A_const_33 *lang.Keyword

var A_arbace_tls_A_const_34 any

var A_arbace_tls_A_const_35 *lang.Var

var A_arbace_tls_A_const_36 *lang.Var

var A_arbace_tls_A_const_37 *lang.Var

var A_arbace_tls_A_const_38 *lang.Keyword

var A_arbace_tls_A_const_39 *lang.Keyword

var A_arbace_tls_A_const_40 *lang.Var

var A_arbace_tls_A_const_41 *lang.Var

var A_arbace_tls_A_const_42 *lang.Var

var A_arbace_tls_A_const_43 *lang.Var

var A_arbace_tls_A_const_44 *lang.Keyword

var A_arbace_tls_A_const_45 *lang.Var

var A_arbace_tls_A_const_46 *lang.Var

var A_arbace_tls_A_init jrt.ClassInit

func A_arbace_tls_A_Init() { if !A_arbace_tls_A_init.Done() { A_arbace_tls_A_init.Run(A_arbace_tls_A_clinit) } }

func A_arbace_tls_A_clinit() { A_arbace_tls_A_clinit_p0(); A_arbace_tls_A_clinit_p1(); A_arbace_tls_A_clinit_p2(); A_arbace_tls_A_clinit_p3() }

func A_arbace_tls_A_clinit_p0() { jrt.StartCheck(); A_arbace_tls_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 64); A_arbace_tls_A_const_0 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[17]); A_arbace_tls_A_const_1 = A_arbace_tls_A_const_pool.A[18]; A_arbace_tls_A_const_2 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[19]); A_arbace_tls_A_const_3 = A_arbace_tls_A_const_pool.A[20]; A_arbace_tls_A_const_4 = A_arbace_tls_A_const_pool.A[21]; A_arbace_tls_A_const_5 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[22]); A_arbace_tls_A_const_6 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[23]); A_arbace_tls_A_const_7 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[24]); A_arbace_tls_A_const_8 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[25]); A_arbace_tls_A_const_9 = A_arbace_tls_A_const_pool.A[26]; A_arbace_tls_A_const_10 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[27]); A_arbace_tls_A_const_11 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[28]) }

func A_arbace_tls_A_clinit_p1() { A_arbace_tls_A_const_12 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[29]); A_arbace_tls_A_const_13 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[30]); A_arbace_tls_A_const_14 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[31]); A_arbace_tls_A_const_15 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[32]); A_arbace_tls_A_const_16 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[33]); A_arbace_tls_A_const_17 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[34]); A_arbace_tls_A_const_18 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[35]); A_arbace_tls_A_const_19 = A_arbace_tls_A_const_pool.A[36]; A_arbace_tls_A_const_20 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[37]); A_arbace_tls_A_const_21 = A_arbace_tls_A_const_pool.A[38]; A_arbace_tls_A_const_22 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[39]); A_arbace_tls_A_const_23 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[40]) }

func A_arbace_tls_A_clinit_p2() { A_arbace_tls_A_const_24 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[41]); A_arbace_tls_A_const_25 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[42]); A_arbace_tls_A_const_26 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[43]); A_arbace_tls_A_const_27 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[44]); A_arbace_tls_A_const_28 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[45]); A_arbace_tls_A_const_29 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[46]); A_arbace_tls_A_const_30 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[47]); A_arbace_tls_A_const_31 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[48]); A_arbace_tls_A_const_32 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[49]); A_arbace_tls_A_const_33 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[50]); A_arbace_tls_A_const_34 = A_arbace_tls_A_const_pool.A[51]; A_arbace_tls_A_const_35 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[52]) }

func A_arbace_tls_A_clinit_p3() { A_arbace_tls_A_const_36 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[53]); A_arbace_tls_A_const_37 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[54]); A_arbace_tls_A_const_38 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[55]); A_arbace_tls_A_const_39 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[56]); A_arbace_tls_A_const_40 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[57]); A_arbace_tls_A_const_41 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[58]); A_arbace_tls_A_const_42 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[59]); A_arbace_tls_A_const_43 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[60]); A_arbace_tls_A_const_44 = lang.Keyword_Cast(A_arbace_tls_A_const_pool.A[61]); A_arbace_tls_A_const_45 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[62]); A_arbace_tls_A_const_46 = lang.Var_Cast(A_arbace_tls_A_const_pool.A[63]) }

func A_arbace_tls_A_New() *A_arbace_tls_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_A) Ctor() {}

func (t *A_arbace_tls_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_A) GetClass__Class() *jrt.Class { return A_arbace_tls_A_class }

func (t *A_arbace_tls_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_tls_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_A); return ok }

func A_arbace_tls_A_Cast(x any) *A_arbace_tls_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_A_class)) }; return v }



type A_arbace_tls_connect_A struct{ j2g_header uint64 }

var A_arbace_tls_connect_A_fn_class *jrt.Class



type A_arbace_tls_eval1733000004_A struct{ jrt.Object }

func A_arbace_tls_eval1733000004_A_New() *A_arbace_tls_eval1733000004_A { t := &A_arbace_tls_eval1733000004_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_eval1733000004_A) Ctor() {}

func (t *A_arbace_tls_eval1733000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000004_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000004_A_class }

func (t *A_arbace_tls_eval1733000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000004_A); return ok }

func A_arbace_tls_eval1733000004_A_Cast(x any) *A_arbace_tls_eval1733000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000004_A_class)) }; return v }



type A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A struct{ j2g_header uint64 }

var A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_fn_class *jrt.Class



type A_arbace_tls_eval1733000008_A struct{ jrt.Object }

func A_arbace_tls_eval1733000008_A_New() *A_arbace_tls_eval1733000008_A { t := &A_arbace_tls_eval1733000008_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_eval1733000008_A) Ctor() {}

func (t *A_arbace_tls_eval1733000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000008_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000008_A_class }

func (t *A_arbace_tls_eval1733000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000008_A); return ok }

func A_arbace_tls_eval1733000008_A_Cast(x any) *A_arbace_tls_eval1733000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000008_A_class)) }; return v }



type A_arbace_tls_eval1733000008_fn__1733000009_A struct{ j2g_header uint64 }

var A_arbace_tls_eval1733000008_fn__1733000009_A_fn_class *jrt.Class



type A_arbace_tls_fail_A struct{ j2g_header uint64 }

var A_arbace_tls_fail_A_fn_class *jrt.Class



type A_arbace_tls_fn__1733000015_A struct{ j2g_header uint64 }

var A_arbace_tls_fn__1733000015_A_fn_class *jrt.Class



type A_arbace_tls_peer_certificates_A struct{ j2g_header uint64 }

var A_arbace_tls_peer_certificates_A_fn_class *jrt.Class



type A_arbace_tls_pem_bytes_A struct{ j2g_header uint64 }

var A_arbace_tls_pem_bytes_A_fn_class *jrt.Class



type A_arbace_tls_read_roots_A struct{ j2g_header uint64 }

var A_arbace_tls_read_roots_A_fn_class *jrt.Class



type A_arbace_tls_session_A struct{ j2g_header uint64 }

var A_arbace_tls_session_A_fn_class *jrt.Class
