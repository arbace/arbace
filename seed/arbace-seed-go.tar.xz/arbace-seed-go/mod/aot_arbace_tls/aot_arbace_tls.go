//line aot_arbace_tls.ae:1
package aot_arbace_tls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_New() *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A { A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_Init(); t := &A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Ctor() {}
//line :5:1
func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_tls_A_Init(); tmp4 = A_arbace_tls_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_tls_A_Init(); tmp6 = A_arbace_tls_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_tls_A_Init(); tmp7 = A_arbace_tls_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_tls_A_Init(); tmp9 = A_arbace_tls_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_tls_A_Init(); tmp11 = A_arbace_tls_A_const_4; tmp8.Invoke_O_O__O(tmp10, tmp11); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_57)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_58)); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_59)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_60)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp16 != nil { panic(tmp16) }; return tmp3 }
//line :5:1
func A_arbace_tls_eval1733000008_fn__1733000009_A_New() *A_arbace_tls_eval1733000008_fn__1733000009_A { A_arbace_tls_eval1733000008_fn__1733000009_A_Init(); t := &A_arbace_tls_eval1733000008_fn__1733000009_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Ctor() {}
//line :5:1
func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_tls_A_Init(); tmp3 = A_arbace_tls_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_tls_A_Init(); tmp5 = A_arbace_tls_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_tls_A_Init(); tmp7 = A_arbace_tls_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_tls_A_Init(); tmp9 = A_arbace_tls_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }




































func A_arbace_tls_fail_A_New() *A_arbace_tls_fail_A { A_arbace_tls_fail_A_Init(); t := &A_arbace_tls_fail_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_tls_fail_A) Ctor() {}
//line :42:1
func (t *A_arbace_tls_fail_A) Invoke_O_O_O_O__O(self, kind__0, msg__1, data__2 any) any { var tmp1 *lang.Var; A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_tls_A_Init(); tmp3 = A_arbace_tls_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_tls_A_Init(); tmp5 = A_arbace_tls_A_const_12; panic(jrt.Thrown(jrt.Throwable_Cast(tmp2.Invoke_O_O__O(msg__1, tmp4.Invoke_O_O_O__O(data__2, tmp5.Ref(), kind__0))))) }


func A_arbace_tls_pem_bytes_A_New() *A_arbace_tls_pem_bytes_A { A_arbace_tls_pem_bytes_A_Init(); t := &A_arbace_tls_pem_bytes_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_tls_pem_bytes_A) Ctor() {}
//line :45:1
func (t *A_arbace_tls_pem_bytes_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *lang.Var; A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) { return jrt.NN(jrt.String_Cast(x__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else { var tmp2 *lang.Var; A_arbace_tls_A_Init(); tmp2 = A_arbace_tls_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0)) { return x__0 } else { var tmp3 *lang.Keyword; A_arbace_tls_A_Init(); tmp3 = A_arbace_tls_A_const_15; if tmp3 != nil { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp5 *lang.Var; A_arbace_tls_A_Init(); tmp5 = A_arbace_tls_A_const_16; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__0)))))) } else { return nil
	}
	}
	}
}
func A_arbace_tls_read_roots_A_New() *A_arbace_tls_read_roots_A { A_arbace_tls_read_roots_A_Init(); t := &A_arbace_tls_read_roots_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_tls_read_roots_A) Ctor() {}
//line :53:1
func (t *A_arbace_tls_read_roots_A) Invoke_O_O__O(self, source__0 any) any {



	var tmp1 *lang.Var; A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(source__0, Lit_69)) { var name__2 any; var tmp2 *lang.Var
		A_arbace_tls_A_Init(); tmp2 = A_arbace_tls_A_const_18; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_tls_A_Init(); tmp4 = A_arbace_tls_A_const_21; name__2 = tmp3.Invoke_O_O__O(source__0, tmp4)
//line :57:1
		var load_ref__3 any; var tmp5 *lang.Var

		A_arbace_tls_A_Init(); tmp5 = A_arbace_tls_A_const_19; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_tls_A_Init(); tmp7 = A_arbace_tls_A_const_22; load_ref__3 = tmp6.Invoke_O__O(tmp7)
//line :57:1
		var text__4 any = lang.IFn_Cast(load_ref__3).Invoke_O__O(name__2)



		if lang.Util_Identical_O_O__Z(text__4, nil) {
			var tmp8 *lang.Var; A_arbace_tls_A_Init(); tmp8 = A_arbace_tls_A_const_23; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_tls_A_Init(); tmp10 = A_arbace_tls_A_const_24; var tmp11 any = tmp10.Ref(); var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_70, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__2)).Ref(); var tmp13 *lang.Keyword; A_arbace_tls_A_Init(); tmp13 = A_arbace_tls_A_const_24; tmp9.Invoke_O_O_O__O(tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13.Ref(), source__0))) }
		var tmp14 *lang.Var; A_arbace_tls_A_Init(); tmp14 = A_arbace_tls_A_const_20; return lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(text__4) } else {
//line :57:1
			var f__2 any = jrt.File_New_String(jrt.String_Cast(source__0))







			if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { } else {
				var tmp15 *lang.Var; A_arbace_tls_A_Init(); tmp15 = A_arbace_tls_A_const_23; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_tls_A_Init(); tmp17 = A_arbace_tls_A_const_24; var tmp18 any = tmp17.Ref(); var tmp19 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, source__0)).Ref(); var tmp20 *lang.Keyword; A_arbace_tls_A_Init(); tmp20 = A_arbace_tls_A_const_24; tmp16.Invoke_O_O_O__O(tmp18, tmp19, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20.Ref(), source__0))) }
			return jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref()
		}
}
func A_arbace_tls_fn__1733000015_A_New() *A_arbace_tls_fn__1733000015_A { A_arbace_tls_fn__1733000015_A_Init(); t := &A_arbace_tls_fn__1733000015_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_tls_fn__1733000015_A) Ctor() {}
//line :70:1
func (t *A_arbace_tls_fn__1733000015_A) Invoke_O__O(self any) any { var s__1 any = jrt.System_Getenv_String__String(Lit_64).Ref(); var tmp1 *lang.Var;
									A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_25; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1)) { return nil } else {
										var tmp2 *lang.Var; A_arbace_tls_A_Init(); tmp2 = A_arbace_tls_A_const_26; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1) } }

func A_arbace_tls_connect_A_New() *A_arbace_tls_connect_A { A_arbace_tls_connect_A_Init(); t := &A_arbace_tls_connect_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_tls_connect_A) Ctor() {}
//line :74:1
func (t *A_arbace_tls_connect_A) Invoke_O_O_O_O__O(self, host__0, port__1, p__1733000017__2 any) any { var map__1733000018__4 any = p__1733000017__2; var map__1733000018__5 any; if lang.ISeq_InstanceOf(map__1733000018__4) { var tmp1 *lang.Var; A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1733000018__4)) { var tmp2 *lang.Var; A_arbace_tls_A_Init(); tmp2 = A_arbace_tls_A_const_28; map__1733000018__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1733000018__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_tls_A_Init(); tmp3 = A_arbace_tls_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1733000018__4)) { var tmp4 *lang.Var; A_arbace_tls_A_Init(); tmp4 = A_arbace_tls_A_const_30; map__1733000018__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1733000018__4) } else { lang.PersistentArrayMap_Init(); map__1733000018__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1733000018__5 = map__1733000018__4 }; var server_name__6 any; var tmp5 *lang.Keyword; A_arbace_tls_A_Init(); tmp5 = A_arbace_tls_A_const_31; server_name__6 = lang.RT_Get_O_O__O(map__1733000018__5, tmp5.Ref()); var alpn__7 any; var tmp6 *lang.Keyword; A_arbace_tls_A_Init(); tmp6 = A_arbace_tls_A_const_32; alpn__7 = lang.RT_Get_O_O__O(map__1733000018__5, tmp6.Ref()); var roots__8 any; var tmp7 *lang.Keyword; A_arbace_tls_A_Init(); tmp7 = A_arbace_tls_A_const_24; roots__8 = lang.RT_Get_O_O__O(map__1733000018__5, tmp7.Ref()); var timeout__9 any; var tmp8 *lang.Keyword; A_arbace_tls_A_Init(); tmp8 = A_arbace_tls_A_const_33; timeout__9 = lang.RT_Get_O_O__O(map__1733000018__5, tmp8.Ref()); var server_name__10 any; var or__1927000174__auto____10 any = server_name__6; if




	jrt.A2g_Truth(or__1927000174__auto____10) { server_name__10 = or__1927000174__auto____10 } else { server_name__10 = host__0 }; var timeout__11 int32; var tmp9 any; var or__1927000174__auto____11 any = timeout__9; if
	jrt.A2g_Truth(or__1927000174__auto____11) { tmp9 = or__1927000174__auto____11 } else { A_arbace_tls_A_Init(); tmp9 = A_arbace_tls_A_const_34 }; timeout__11 = lang.RT_IntCast_O__I(tmp9); var alpn__12 any; var tmp10 /*line :74:1*/*lang.Var;






	A_arbace_tls_A_Init(); tmp10 = A_arbace_tls_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(alpn__7)) { var tmp11 *lang.Var; A_arbace_tls_A_Init(); tmp11 = A_arbace_tls_A_const_35; alpn__12 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(Lit_50, alpn__7) } else { alpn__12 = nil }; var roots__13 any; var tmp12 /*line :74:1*/*lang.Var;







	A_arbace_tls_A_Init(); tmp12 = A_arbace_tls_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(roots__8)) { var tmp13 *lang.Var; A_arbace_tls_A_Init(); tmp13 = A_arbace_tls_A_const_20; roots__13 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(roots__8) } else { var tmp14 *lang.Var; A_arbace_tls_A_Init(); tmp14 = A_arbace_tls_A_const_6; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_tls_A_Init(); tmp16 = A_arbace_tls_A_const_40; roots__13 = tmp15.Invoke_O__O(jrt.NN(tmp16).GetRawRoot__O()) }; var data__14 any; var tmp17 /*line :74:1*/*lang.Keyword; A_arbace_tls_A_Init(); tmp17 = A_arbace_tls_A_const_37; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_tls_A_Init(); tmp19 = A_arbace_tls_A_const_38; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_tls_A_Init(); tmp21 = A_arbace_tls_A_const_31; data__14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18, host__0, tmp20, port__1, tmp21.Ref(), server_name__10)); var r__15 any; var tmp22 *lang.Var;









	A_arbace_tls_A_Init(); tmp22 = A_arbace_tls_A_const_39; r__15 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(host__0, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(port__1)).Ref(), server_name__10, alpn__12, roots__13, jrt.Integer_ValueOf_I__Integer(timeout__11).Ref()); if
	jrt.Socket_InstanceOf(r__15) { return r__15 } else { var vec__1733000020__16 any = r__15; var kind__17 any = lang.RT_Nth_O_I_O__O(vec__1733000020__16, lang.RT_IntCast_J__I(0), nil); var msg__18 any = lang.RT_Nth_O_I_O__O(vec__1733000020__16, lang.RT_IntCast_J__I(1), nil); var tmp23 *lang.Var


		A_arbace_tls_A_Init(); tmp23 = A_arbace_tls_A_const_23; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52, nil, nil, Lit_53, nil); var tmp26 *jrt.String; var tmp27 *lang.Var
		A_arbace_tls_A_Init(); tmp27 = A_arbace_tls_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O__O(server_name__10, host__0)) { tmp26 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, server_name__10, nil)) } else { tmp26 = nil }
//line :88:1
		return tmp24.Invoke_O_O_O__O(kind__17, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, host__0, nil, port__1, tmp26.Ref(), nil, msg__18)).Ref(), data__14) } }
//line :74:1
func (t *A_arbace_tls_connect_A) Invoke_O_O_O__O(self, host__0, port__1 any) any {


	var tmp1 *lang.Var; A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_42; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(host__0, port__1, nil)
}














func A_arbace_tls_session_A_New() *A_arbace_tls_session_A { A_arbace_tls_session_A_Init(); t := &A_arbace_tls_session_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_tls_session_A) Ctor() {}
//line :93:1
func (t *A_arbace_tls_session_A) Invoke_O_O__O(self, s__0 any) any { var map__1733000024__2 any; var tmp1 *lang.Var;



	A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_43; map__1733000024__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); var map__1733000024__3 any; if lang.ISeq_InstanceOf(map__1733000024__2) { var tmp2 *lang.Var; A_arbace_tls_A_Init(); tmp2 = A_arbace_tls_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1733000024__2)) { var tmp3 *lang.Var; A_arbace_tls_A_Init(); tmp3 = A_arbace_tls_A_const_28; map__1733000024__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1733000024__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_tls_A_Init(); tmp4 = A_arbace_tls_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1733000024__2)) { var tmp5 *lang.Var; A_arbace_tls_A_Init(); tmp5 = A_arbace_tls_A_const_30; map__1733000024__3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1733000024__2) } else { lang.PersistentArrayMap_Init(); map__1733000024__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1733000024__3 = map__1733000024__2 }; var m__4 any = map__1733000024__3; var application_protocol__5 any; var tmp6 /*line :93:1*/*lang.Keyword;



	A_arbace_tls_A_Init(); tmp6 = A_arbace_tls_A_const_44; application_protocol__5 = lang.RT_Get_O_O__O(map__1733000024__3, tmp6.Ref()); var tmp7 /*line :98:1*/*lang.Var; A_arbace_tls_A_Init(); tmp7 = A_arbace_tls_A_const_11; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_tls_A_Init(); tmp9 = A_arbace_tls_A_const_44; var tmp10 any = tmp9.Ref(); var tmp11 any; var tmp12 *lang.Var; A_arbace_tls_A_Init(); tmp12 = A_arbace_tls_A_const_25; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(application_protocol__5)) { tmp11 = nil } else { tmp11 = application_protocol__5 }; return tmp8.Invoke_O_O_O__O(m__4, tmp10, tmp11) }

func A_arbace_tls_peer_certificates_A_New() *A_arbace_tls_peer_certificates_A { A_arbace_tls_peer_certificates_A_Init(); t := &A_arbace_tls_peer_certificates_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_tls_peer_certificates_A) Ctor() {}
//line :100:1
func (t *A_arbace_tls_peer_certificates_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *lang.Var; A_arbace_tls_A_Init(); tmp1 = A_arbace_tls_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_tls_A_Init(); tmp3 = A_arbace_tls_A_const_46; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__0))
}



type A_arbace_tls_A struct{ jrt.Object }

var A_arbace_tls_A_const_0 *lang.Var

var A_arbace_tls_A_const_1 *lang.Var

var A_arbace_tls_A_const_2 any

var A_arbace_tls_A_const_3 any

var A_arbace_tls_A_const_4 any

var A_arbace_tls_A_const_5 *lang.Var

var A_arbace_tls_A_const_6 *lang.Var

var A_arbace_tls_A_const_7 *lang.Var

var A_arbace_tls_A_const_8 any

var A_arbace_tls_A_const_9 *lang.Var

var A_arbace_tls_A_const_10 *lang.Var

var A_arbace_tls_A_const_11 *lang.Var

var A_arbace_tls_A_const_12 *lang.Keyword

var A_arbace_tls_A_const_13 *lang.Var

var A_arbace_tls_A_const_14 *lang.Var

var A_arbace_tls_A_const_15 *lang.Keyword

var A_arbace_tls_A_const_16 *lang.Var

var A_arbace_tls_A_const_17 *lang.Var

var A_arbace_tls_A_const_18 *lang.Var

var A_arbace_tls_A_const_19 *lang.Var

var A_arbace_tls_A_const_20 *lang.Var

var A_arbace_tls_A_const_21 any

var A_arbace_tls_A_const_22 any

var A_arbace_tls_A_const_23 *lang.Var

var A_arbace_tls_A_const_24 *lang.Keyword

var A_arbace_tls_A_const_25 *lang.Var

var A_arbace_tls_A_const_26 *lang.Var

var A_arbace_tls_A_const_27 *lang.Var

var A_arbace_tls_A_const_28 *lang.Var

var A_arbace_tls_A_const_29 *lang.Var

var A_arbace_tls_A_const_30 *lang.Var

var A_arbace_tls_A_const_31 *lang.Keyword

var A_arbace_tls_A_const_32 *lang.Keyword

var A_arbace_tls_A_const_33 *lang.Keyword

var A_arbace_tls_A_const_34 any

var A_arbace_tls_A_const_35 *lang.Var

var A_arbace_tls_A_const_36 *lang.Var

var A_arbace_tls_A_const_37 *lang.Keyword

var A_arbace_tls_A_const_38 *lang.Keyword

var A_arbace_tls_A_const_39 *lang.Var

var A_arbace_tls_A_const_40 *lang.Var

var A_arbace_tls_A_const_41 *lang.Var

var A_arbace_tls_A_const_42 *lang.Var

var A_arbace_tls_A_const_43 *lang.Var

var A_arbace_tls_A_const_44 *lang.Keyword

var A_arbace_tls_A_const_45 *lang.Var

var A_arbace_tls_A_const_46 *lang.Var

var A_arbace_tls_A_init jrt.ClassInit

func A_arbace_tls_A_Init() { if !A_arbace_tls_A_init.Done() { A_arbace_tls_A_init.Run(A_arbace_tls_A_clinit) } }

func A_arbace_tls_A_clinit() { A_arbace_tls_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_tls_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_tls_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_tls_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_tls_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_tls_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_tls_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_tls_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_tls_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_tls_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_tls_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_tls_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_tls_A_const_12 = lang.RT_Keyword_String_String__Keyword(Lit_11, Lit_17); A_arbace_tls_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_tls_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_tls_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_tls_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_tls_A_const_17 = lang.RT_Var_String_String__Var(Lit_3, Lit_22); A_arbace_tls_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_tls_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_tls_A_const_20 = lang.RT_Var_String_String__Var(Lit_11, Lit_25); A_arbace_tls_A_const_21 = jrt.Long_ValueOf_J__Long(4).Ref(); A_arbace_tls_A_const_22 = lang.Symbol_Intern_String_String__Symbol(Lit_26, Lit_27).Ref(); A_arbace_tls_A_const_23 = lang.RT_Var_String_String__Var(Lit_11, Lit_28); A_arbace_tls_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_tls_A_const_25 = lang.RT_Var_String_String__Var(Lit_3, Lit_30); A_arbace_tls_A_const_26 = lang.RT_Var_String_String__Var(Lit_11, Lit_31); A_arbace_tls_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_tls_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_tls_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_tls_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_tls_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_36); A_arbace_tls_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_tls_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_tls_A_const_34 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_tls_A_const_35 = lang.RT_Var_String_String__Var(Lit_3, Lit_39); A_arbace_tls_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_tls_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_7); A_arbace_tls_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_tls_A_const_39 = lang.RT_Var_String_String__Var(Lit_6, Lit_42); A_arbace_tls_A_const_40 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_tls_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_tls_A_const_42 = lang.RT_Var_String_String__Var(Lit_11, Lit_42); A_arbace_tls_A_const_43 = lang.RT_Var_String_String__Var(Lit_6, Lit_45); A_arbace_tls_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_tls_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_tls_A_const_46 = lang.RT_Var_String_String__Var(Lit_6, Lit_48) }

func A_arbace_tls_A_New() *A_arbace_tls_A { A_arbace_tls_A_Init(); t := &A_arbace_tls_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_A) Ctor() {}

func (t *A_arbace_tls_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_A) GetClass__Class() *jrt.Class { return A_arbace_tls_A_class }

func (t *A_arbace_tls_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_A); return ok }

func A_arbace_tls_A_Cast(x any) *A_arbace_tls_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_A_class)) }; return v }



type A_arbace_tls_connect_A struct{ jrt.Object }

func (t *A_arbace_tls_connect_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_tls_connect_A) Is_Compiler_AOTF2() {}

var A_arbace_tls_connect_A_fn_class *jrt.Class

var A_arbace_tls_connect_A_init jrt.ClassInit

func A_arbace_tls_connect_A_Init() { if !A_arbace_tls_connect_A_init.Done() { A_arbace_tls_connect_A_init.Run(A_arbace_tls_connect_A_clinit) } }

func A_arbace_tls_connect_A_clinit() { A_arbace_tls_connect_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_connect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_connect_A) GetClass__Class() *jrt.Class { return A_arbace_tls_connect_A_class }

func (t *A_arbace_tls_connect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_connect_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_connect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_connect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_connect_A); return ok }

func A_arbace_tls_connect_A_Cast(x any) *A_arbace_tls_connect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_connect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_connect_A_class)) }; return v }



type A_arbace_tls_eval1733000004_A struct{ jrt.Object }

func A_arbace_tls_eval1733000004_A_New() *A_arbace_tls_eval1733000004_A { t := &A_arbace_tls_eval1733000004_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_eval1733000004_A) Ctor() {}

func (t *A_arbace_tls_eval1733000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000004_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000004_A_class }

func (t *A_arbace_tls_eval1733000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000004_A); return ok }

func A_arbace_tls_eval1733000004_A_Cast(x any) *A_arbace_tls_eval1733000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000004_A_class)) }; return v }



type A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A struct{ jrt.Object }

func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Is_Compiler_AOTF0() {}

var A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_fn_class *jrt.Class

var A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_init jrt.ClassInit

func A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_Init() { if !A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_init.Done() { A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_init.Run(A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_clinit) } }

func A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_clinit() { A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_class }

func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A); return ok }

func A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_Cast(x any) *A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_class)) }; return v }



type A_arbace_tls_eval1733000008_A struct{ jrt.Object }

func A_arbace_tls_eval1733000008_A_New() *A_arbace_tls_eval1733000008_A { t := &A_arbace_tls_eval1733000008_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_eval1733000008_A) Ctor() {}

func (t *A_arbace_tls_eval1733000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000008_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000008_A_class }

func (t *A_arbace_tls_eval1733000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000008_A); return ok }

func A_arbace_tls_eval1733000008_A_Cast(x any) *A_arbace_tls_eval1733000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000008_A_class)) }; return v }



type A_arbace_tls_eval1733000008_fn__1733000009_A struct{ jrt.Object }

func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Is_Compiler_AOTF0() {}

var A_arbace_tls_eval1733000008_fn__1733000009_A_fn_class *jrt.Class

var A_arbace_tls_eval1733000008_fn__1733000009_A_init jrt.ClassInit

func A_arbace_tls_eval1733000008_fn__1733000009_A_Init() { if !A_arbace_tls_eval1733000008_fn__1733000009_A_init.Done() { A_arbace_tls_eval1733000008_fn__1733000009_A_init.Run(A_arbace_tls_eval1733000008_fn__1733000009_A_clinit) } }

func A_arbace_tls_eval1733000008_fn__1733000009_A_clinit() { A_arbace_tls_eval1733000008_fn__1733000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) GetClass__Class() *jrt.Class { return A_arbace_tls_eval1733000008_fn__1733000009_A_class }

func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_eval1733000008_fn__1733000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_eval1733000008_fn__1733000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_eval1733000008_fn__1733000009_A); return ok }

func A_arbace_tls_eval1733000008_fn__1733000009_A_Cast(x any) *A_arbace_tls_eval1733000008_fn__1733000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_eval1733000008_fn__1733000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_eval1733000008_fn__1733000009_A_class)) }; return v }



type A_arbace_tls_fail_A struct{ jrt.Object }

func (t *A_arbace_tls_fail_A) Is_Compiler_AOTF3() {}

var A_arbace_tls_fail_A_fn_class *jrt.Class

var A_arbace_tls_fail_A_init jrt.ClassInit

func A_arbace_tls_fail_A_Init() { if !A_arbace_tls_fail_A_init.Done() { A_arbace_tls_fail_A_init.Run(A_arbace_tls_fail_A_clinit) } }

func A_arbace_tls_fail_A_clinit() { A_arbace_tls_fail_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_fail_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_fail_A) GetClass__Class() *jrt.Class { return A_arbace_tls_fail_A_class }

func (t *A_arbace_tls_fail_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_fail_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_fail_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_fail_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_fail_A); return ok }

func A_arbace_tls_fail_A_Cast(x any) *A_arbace_tls_fail_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_fail_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_fail_A_class)) }; return v }



type A_arbace_tls_fn__1733000015_A struct{ jrt.Object }

func (t *A_arbace_tls_fn__1733000015_A) Is_Compiler_AOTF0() {}

var A_arbace_tls_fn__1733000015_A_fn_class *jrt.Class

var A_arbace_tls_fn__1733000015_A_init jrt.ClassInit

func A_arbace_tls_fn__1733000015_A_Init() { if !A_arbace_tls_fn__1733000015_A_init.Done() { A_arbace_tls_fn__1733000015_A_init.Run(A_arbace_tls_fn__1733000015_A_clinit) } }

func A_arbace_tls_fn__1733000015_A_clinit() { A_arbace_tls_fn__1733000015_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_fn__1733000015_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_fn__1733000015_A) GetClass__Class() *jrt.Class { return A_arbace_tls_fn__1733000015_A_class }

func (t *A_arbace_tls_fn__1733000015_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_fn__1733000015_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_fn__1733000015_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_fn__1733000015_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_fn__1733000015_A); return ok }

func A_arbace_tls_fn__1733000015_A_Cast(x any) *A_arbace_tls_fn__1733000015_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_fn__1733000015_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_fn__1733000015_A_class)) }; return v }



type A_arbace_tls_peer_certificates_A struct{ jrt.Object }

func (t *A_arbace_tls_peer_certificates_A) Is_Compiler_AOTF1() {}

var A_arbace_tls_peer_certificates_A_fn_class *jrt.Class

var A_arbace_tls_peer_certificates_A_init jrt.ClassInit

func A_arbace_tls_peer_certificates_A_Init() { if !A_arbace_tls_peer_certificates_A_init.Done() { A_arbace_tls_peer_certificates_A_init.Run(A_arbace_tls_peer_certificates_A_clinit) } }

func A_arbace_tls_peer_certificates_A_clinit() { A_arbace_tls_peer_certificates_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_peer_certificates_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_peer_certificates_A) GetClass__Class() *jrt.Class { return A_arbace_tls_peer_certificates_A_class }

func (t *A_arbace_tls_peer_certificates_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_peer_certificates_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_peer_certificates_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_peer_certificates_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_peer_certificates_A); return ok }

func A_arbace_tls_peer_certificates_A_Cast(x any) *A_arbace_tls_peer_certificates_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_peer_certificates_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_peer_certificates_A_class)) }; return v }



type A_arbace_tls_pem_bytes_A struct{ jrt.Object }

func (t *A_arbace_tls_pem_bytes_A) Is_Compiler_AOTF1() {}

var A_arbace_tls_pem_bytes_A_fn_class *jrt.Class

var A_arbace_tls_pem_bytes_A_init jrt.ClassInit

func A_arbace_tls_pem_bytes_A_Init() { if !A_arbace_tls_pem_bytes_A_init.Done() { A_arbace_tls_pem_bytes_A_init.Run(A_arbace_tls_pem_bytes_A_clinit) } }

func A_arbace_tls_pem_bytes_A_clinit() { A_arbace_tls_pem_bytes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_pem_bytes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_pem_bytes_A) GetClass__Class() *jrt.Class { return A_arbace_tls_pem_bytes_A_class }

func (t *A_arbace_tls_pem_bytes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_pem_bytes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_pem_bytes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_pem_bytes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_pem_bytes_A); return ok }

func A_arbace_tls_pem_bytes_A_Cast(x any) *A_arbace_tls_pem_bytes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_pem_bytes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_pem_bytes_A_class)) }; return v }



type A_arbace_tls_read_roots_A struct{ jrt.Object }

func (t *A_arbace_tls_read_roots_A) Is_Compiler_AOTF1() {}

var A_arbace_tls_read_roots_A_fn_class *jrt.Class

var A_arbace_tls_read_roots_A_init jrt.ClassInit

func A_arbace_tls_read_roots_A_Init() { if !A_arbace_tls_read_roots_A_init.Done() { A_arbace_tls_read_roots_A_init.Run(A_arbace_tls_read_roots_A_clinit) } }

func A_arbace_tls_read_roots_A_clinit() { A_arbace_tls_read_roots_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_read_roots_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_read_roots_A) GetClass__Class() *jrt.Class { return A_arbace_tls_read_roots_A_class }

func (t *A_arbace_tls_read_roots_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_read_roots_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_read_roots_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_read_roots_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_read_roots_A); return ok }

func A_arbace_tls_read_roots_A_Cast(x any) *A_arbace_tls_read_roots_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_read_roots_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_read_roots_A_class)) }; return v }



type A_arbace_tls_session_A struct{ jrt.Object }

func (t *A_arbace_tls_session_A) Is_Compiler_AOTF1() {}

var A_arbace_tls_session_A_fn_class *jrt.Class

var A_arbace_tls_session_A_init jrt.ClassInit

func A_arbace_tls_session_A_Init() { if !A_arbace_tls_session_A_init.Done() { A_arbace_tls_session_A_init.Run(A_arbace_tls_session_A_clinit) } }

func A_arbace_tls_session_A_clinit() { A_arbace_tls_session_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_tls_session_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_session_A) GetClass__Class() *jrt.Class { return A_arbace_tls_session_A_class }

func (t *A_arbace_tls_session_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_session_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_session_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_session_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_session_A); return ok }

func A_arbace_tls_session_A_Cast(x any) *A_arbace_tls_session_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_session_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_session_A_class)) }; return v }
