//line aot_arbace_tls__init.ae:1
package aot_arbace_tls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_tls__init_A_Unit0__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); return lang.IFn_Cast(jrt.NN(A_arbace_tls__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_tls__init_A_const_1) }
//line :5:1
func A_arbace_tls__init_A_Unit1__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_tls__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_2)) }
//line :5:1
func A_arbace_tls__init_A_Unit2__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); var tmp1 any = A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_New(); var tmp2 *jrt.Class; A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_Init(); tmp2 = A_arbace_tls_eval1733000004_loading__1927001464__auto____1733000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :5:1
func A_arbace_tls__init_A_Unit3__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_tls__init_A_const_1)).Equals_O__Z(A_arbace_tls__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_tls_eval1733000008_fn__1733000009_A_New(); var tmp2 *jrt.Class; A_arbace_tls_eval1733000008_fn__1733000009_A_Init(); tmp2 = A_arbace_tls_eval1733000008_fn__1733000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :5:1
func A_arbace_tls__init_A_Load__O() any { A_arbace_tls__init_A_Init(); A_arbace_tls__init_A_Unit0__O(); A_arbace_tls__init_A_Unit1__O(); A_arbace_tls__init_A_Unit2__O(); A_arbace_tls__init_A_Unit3__O(); A_arbace_tls__init_A_Unit4__O(); A_arbace_tls__init_A_Unit5__O(); A_arbace_tls__init_A_Unit6__O(); A_arbace_tls__init_A_Unit7__O(); A_arbace_tls__init_A_Unit8__O(); A_arbace_tls__init_A_Unit9__O(); A_arbace_tls__init_A_Unit10__O(); return nil }




































func A_arbace_tls__init_A_Unit4__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_tls__init_A_const_4; var tmp2 any = A_arbace_tls_fail_A_New(); var tmp3 *jrt.Class; A_arbace_tls_fail_A_Init(); tmp3 = A_arbace_tls_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_tls__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_5)); return A_arbace_tls__init_A_const_4.Ref() }


func A_arbace_tls__init_A_Unit5__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); var tmp1 *lang.Var = A_arbace_tls__init_A_const_6; var tmp2 any = A_arbace_tls_pem_bytes_A_New(); var tmp3 *jrt.Class; A_arbace_tls_pem_bytes_A_Init(); tmp3 = A_arbace_tls_pem_bytes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_tls__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_7)); return A_arbace_tls__init_A_const_6.Ref() }







func A_arbace_tls__init_A_Unit6__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_tls__init_A_const_8; var tmp2 any = A_arbace_tls_read_roots_A_New(); var tmp3 *jrt.Class; A_arbace_tls_read_roots_A_Init(); tmp3 = A_arbace_tls_read_roots_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_tls__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_9)); return A_arbace_tls__init_A_const_8.Ref() }















func A_arbace_tls__init_A_Unit7__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 *lang.Var = A_arbace_tls__init_A_const_10; var tmp2 any = A_arbace_tls_fn__1733000015_A_New(); var tmp3 *jrt.Class; A_arbace_tls_fn__1733000015_A_Init(); tmp3 = A_arbace_tls_fn__1733000015_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_tls__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_11)); return A_arbace_tls__init_A_const_10.Ref() }




func A_arbace_tls__init_A_Unit8__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_tls__init_A_const_12; var tmp2 any = A_arbace_tls_connect_A_New(); var tmp3 *jrt.Class; A_arbace_tls_connect_A_Init(); tmp3 = A_arbace_tls_connect_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_tls__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_13)); return A_arbace_tls__init_A_const_12.Ref() }


















func A_arbace_tls__init_A_Unit9__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(93, 1); var tmp1 *lang.Var = A_arbace_tls__init_A_const_14; var tmp2 any = A_arbace_tls_session_A_New(); var tmp3 *jrt.Class; A_arbace_tls_session_A_Init(); tmp3 = A_arbace_tls_session_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_tls__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_15)); return A_arbace_tls__init_A_const_14.Ref() }






func A_arbace_tls__init_A_Unit10__O() any { A_arbace_tls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_tls__init_A_const_16; var tmp2 any = A_arbace_tls_peer_certificates_A_New(); var tmp3 *jrt.Class; A_arbace_tls_peer_certificates_A_Init(); tmp3 = A_arbace_tls_peer_certificates_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_tls__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_tls__init_A_const_17)); return A_arbace_tls__init_A_const_16.Ref() }



type A_arbace_tls__init_A struct{ jrt.Object }

var A_arbace_tls__init_A_const_0 *lang.Var

var A_arbace_tls__init_A_const_1 any

var A_arbace_tls__init_A_const_2 any

var A_arbace_tls__init_A_const_3 any

var A_arbace_tls__init_A_const_4 *lang.Var

var A_arbace_tls__init_A_const_5 any

var A_arbace_tls__init_A_const_6 *lang.Var

var A_arbace_tls__init_A_const_7 any

var A_arbace_tls__init_A_const_8 *lang.Var

var A_arbace_tls__init_A_const_9 any

var A_arbace_tls__init_A_const_10 *lang.Var

var A_arbace_tls__init_A_const_11 any

var A_arbace_tls__init_A_const_12 *lang.Var

var A_arbace_tls__init_A_const_13 any

var A_arbace_tls__init_A_const_14 *lang.Var

var A_arbace_tls__init_A_const_15 any

var A_arbace_tls__init_A_const_16 *lang.Var

var A_arbace_tls__init_A_const_17 any

var A_arbace_tls__init_A_init jrt.ClassInit

func A_arbace_tls__init_A_Init() { if !A_arbace_tls__init_A_init.Done() { A_arbace_tls__init_A_init.Run(A_arbace_tls__init_A_clinit) } }

func A_arbace_tls__init_A_clinit() { A_arbace_tls__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_tls__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_tls__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_tls__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_tls__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_28); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_tls__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_77)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), Lit_84)); A_arbace_tls__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_25); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_tls__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_87, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), Lit_84)); A_arbace_tls__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_11, Lit_31); A_arbace_tls__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_89, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), Lit_84)); A_arbace_tls__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_tls__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), Lit_84)); A_arbace_tls__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_42); A_arbace_tls__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref()))), lang.IObj_Cast(lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_7)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(74).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), Lit_84)); A_arbace_tls__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_45); A_arbace_tls__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_94, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(93).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), Lit_84)); A_arbace_tls__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_11, Lit_48); A_arbace_tls__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_95, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), Lit_84)) }

func A_arbace_tls__init_A_New() *A_arbace_tls__init_A { A_arbace_tls__init_A_Init(); t := &A_arbace_tls__init_A{}; t.Ctor(); return t }

func (t *A_arbace_tls__init_A) Ctor() {}

func (t *A_arbace_tls__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls__init_A) GetClass__Class() *jrt.Class { return A_arbace_tls__init_A_class }

func (t *A_arbace_tls__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls__init_A); return ok }

func A_arbace_tls__init_A_Cast(x any) *A_arbace_tls__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls__init_A_class)) }; return v }
