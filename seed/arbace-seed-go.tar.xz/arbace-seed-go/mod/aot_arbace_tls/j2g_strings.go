//line j2g_strings.ae:1
package aot_arbace_tls

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn15,arbace.tls.hostyn4,hostkn3,docks10,arbace.tls5,errorkn4,elseys10,arbace.box4,loadkn5,rootskn11,server-namekn4,alpnkn7,timeoutkn4,hostkn4,portkn20,application-protocolv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn10,arbace.tlsm2,R6,s2202,TLS client connections. (connect host port) is a java.net.Socket whose streams carry the plain\n  text of a TLS connection to host: the peer's certificate verified for the server name (host,\n  unless :server-name says another), which is also sent (SNI). In the box the guest does TLS\n  itself (Go's crypto/tls) over the launcher's stream (ARBACE_BOX_NET must allow the dial, e.g.\n  dial=api.anthropic.com:443): the keys and the plain text stay in the guest, the launcher\n  carries only the cipher text. Natively the same, over the host's socket.\n\n    (connect host port)        a connected socket, the handshake made\n    (connect host port opts)   opts:\n        :server-name  the name sent and verified (default host; an IP literal is verified\n                      against the certificate's addresses and not sent)\n        :alpn         the application protocols offered, a sequence of strings (\"http/1.1\")\n        :roots        the trusted certificates, PEM (a string or bytes), in place of the default\n        :timeout      ms for the connection and for the handshake (0, the default: no limit)\n    (session s)                {:protocol \"TLSv1.3\" :cipher-suite ... :application-protocol\n                               (nil when none was agreed) :server-name ...}\n    (peer-certificates s)      the peer's certificates, DER byte arrays, its own first\n\n  The trusted roots, by default: Mozilla's, built into the program (natively and in the box;\n  golang.org/x/crypto/x509roots/fallback's bundle).\n  ARBACE_TLS_ROOTS replaces them for the process: ref:NAME, a PEM bundle in the store\n  (arbace.box; in the box, the launcher's store), or a file's path (in the box, a file of its\n  in-memory file system). :roots replaces them for one connection.\n\n  What fails throws: the network's errors as java.net's exceptions (ConnectException,\n  UnknownHostException, SocketTimeoutException ...); TLS's as an ex-info whose data's\n  :arbace.tls/error is :verify (the peer's certificate is not trusted, has expired, or is not for\n  the server name), :handshake (the handshake failed otherwise: an alert, no common protocol or\n  cipher) or :roots (the roots given hold no certificate, or ARBACE_TLS_ROOTS names none).v11,arbace.core7,ex-infov11,arbace.core5,assocR7,v11,arbace.core7,string?v11,arbace.core6,bytes?R8,v11,arbace.core5,classv13,arbace.string12,starts-with?v11,arbace.core4,subsl4,v11,arbace.core17,requiring-resolveR9,v10,arbace.tls9,pem-bytesv10,arbace.tls4,failR10,v13,arbace.string6,blank?v10,arbace.tls10,read-rootsv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR11,R12,R13,l0,v13,arbace.string4,joinv11,arbace.core5,some?v10,arbace.tls9,env-rootsR14,R15,v15,arbace.tls.host7,connectv11,arbace.core4,not=v10,arbace.tls7,connectv15,arbace.tls.host7,sessionR16,v11,arbace.core3,vecv15,arbace.tls.host17,peer-certificates")

var Lit_1 *jrt.String = jrt.Intern(",")

var Lit_2 *jrt.String = jrt.Intern("TLS with ")

var Lit_3 *jrt.String = jrt.Intern(":")

var Lit_4 *jrt.String = jrt.Intern(": ")

var Lit_5 *jrt.String = jrt.Intern(" (as ")

var Lit_6 *jrt.String = jrt.Intern(")")

var Lit_7 *jrt.String = jrt.Intern("java.io.File")

var Lit_8 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_9 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_10 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_11 *jrt.String = jrt.Intern("ARBACE_TLS_ROOTS")

var Lit_12 *jrt.String = jrt.Intern(":roots is PEM, a string or bytes, not ")

var Lit_13 *jrt.String = jrt.Intern("ref:")

var Lit_14 *jrt.String = jrt.Intern("ARBACE_TLS_ROOTS: no such ref in the store: ")

var Lit_15 *jrt.String = jrt.Intern("ARBACE_TLS_ROOTS: no such file: ")

var Lit_16 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn4,kindkn3,tagyn6,Stringyn4,datakn4,linekn6,columnkn4,fileyn1,xyn5,bytesyn4,hostyn4,portyn15,java.net.Socketkn4,keysyn11,server-nameyn4,alpnyn5,rootsyn7,timeoutyn6,Socketv11,arbace.core5,in-nsMyn10,arbace.tlsm2,R0,s2202,TLS client connections. (connect host port) is a java.net.Socket whose streams carry the plain\n  text of a TLS connection to host: the peer's certificate verified for the server name (host,\n  unless :server-name says another), which is also sent (SNI). In the box the guest does TLS\n  itself (Go's crypto/tls) over the launcher's stream (ARBACE_BOX_NET must allow the dial, e.g.\n  dial=api.anthropic.com:443): the keys and the plain text stay in the guest, the launcher\n  carries only the cipher text. Natively the same, over the host's socket.\n\n    (connect host port)        a connected socket, the handshake made\n    (connect host port opts)   opts:\n        :server-name  the name sent and verified (default host; an IP literal is verified\n                      against the certificate's addresses and not sent)\n        :alpn         the application protocols offered, a sequence of strings (\"http/1.1\")\n        :roots        the trusted certificates, PEM (a string or bytes), in place of the default\n        :timeout      ms for the connection and for the handshake (0, the default: no limit)\n    (session s)                {:protocol \"TLSv1.3\" :cipher-suite ... :application-protocol\n                               (nil when none was agreed) :server-name ...}\n    (peer-certificates s)      the peer's certificates, DER byte arrays, its own first\n\n  The trusted roots, by default: Mozilla's, built into the program (natively and in the box;\n  golang.org/x/crypto/x509roots/fallback's bundle).\n  ARBACE_TLS_ROOTS replaces them for the process: ref:NAME, a PEM bundle in the store\n  (arbace.box; in the box, the launcher's store), or a file's path (in the box, a file of its\n  in-memory file system). :roots replaces them for one connection.\n\n  What fails throws: the network's errors as java.net's exceptions (ConnectException,\n  UnknownHostException, SocketTimeoutException ...); TLS's as an ex-info whose data's\n  :arbace.tls/error is :verify (the peer's certificate is not trusted, has expired, or is not for\n  the server name), :handshake (the handshake failed otherwise: an alert, no common protocol or\n  cipher) or :roots (the roots given hold no certificate, or ARBACE_TLS_ROOTS names none).m2,R0,s2202,TLS client connections. (connect host port) is a java.net.Socket whose streams carry the plain\n  text of a TLS connection to host: the peer's certificate verified for the server name (host,\n  unless :server-name says another), which is also sent (SNI). In the box the guest does TLS\n  itself (Go's crypto/tls) over the launcher's stream (ARBACE_BOX_NET must allow the dial, e.g.\n  dial=api.anthropic.com:443): the keys and the plain text stay in the guest, the launcher\n  carries only the cipher text. Natively the same, over the host's socket.\n\n    (connect host port)        a connected socket, the handshake made\n    (connect host port opts)   opts:\n        :server-name  the name sent and verified (default host; an IP literal is verified\n                      against the certificate's addresses and not sent)\n        :alpn         the application protocols offered, a sequence of strings (\"http/1.1\")\n        :roots        the trusted certificates, PEM (a string or bytes), in place of the default\n        :timeout      ms for the connection and for the handshake (0, the default: no limit)\n    (session s)                {:protocol \"TLSv1.3\" :cipher-suite ... :application-protocol\n                               (nil when none was agreed) :server-name ...}\n    (peer-certificates s)      the peer's certificates, DER byte arrays, its own first\n\n  The trusted roots, by default: Mozilla's, built into the program (natively and in the box;\n  golang.org/x/crypto/x509roots/fallback's bundle).\n  ARBACE_TLS_ROOTS replaces them for the process: ref:NAME, a PEM bundle in the store\n  (arbace.box; in the box, the launcher's store), or a file's path (in the box, a file of its\n  in-memory file system). :roots replaces them for one connection.\n\n  What fails throws: the network's errors as java.net's exceptions (ConnectException,\n  UnknownHostException, SocketTimeoutException ...); TLS's as an ex-info whose data's\n  :arbace.tls/error is :verify (the peer's certificate is not trusted, has expired, or is not for\n  the server name), :handshake (the handshake failed otherwise: an alert, no common protocol or\n  cipher) or :roots (the roots given hold no certificate, or ARBACE_TLS_ROOTS names none).R1,v10,arbace.tls4,failm10,R2,TR3,L1,V3,R4,Myn3,msgm2,R5,R6,R7,R8,i42,R9,i1,R10,s13,arbace/tls.aev10,arbace.tls9,pem-bytesm12,R2,TR3,L1,MV1,R11,m2,R5,R12,R0,s44,The bytes of PEM text x (a string or bytes).R8,i45,R9,i1,R10,s13,arbace/tls.aev10,arbace.tls10,read-rootsm10,R3,L1,MV1,Myn6,sourcem2,R5,R6,m2,R5,R12,R0,s112,The PEM bytes source names: ref:NAME, the blob ref NAME points at in the store (arbace.box), or\n  a file's path.R8,i53,R9,i1,R10,s13,arbace/tls.aev10,arbace.tls9,env-rootsm8,R2,TR8,i69,R9,i1,R10,s13,arbace/tls.aev10,arbace.tls7,connectm10,R3,L2,MV2,R13,R14,m2,R5,R15,MV3,Myn4,hostm2,R5,R6,R14,m2,R16,V4,R17,R18,R19,R20,m2,R5,R15,R0,s143,A socket connected to host and port whose streams carry TLS's plain text, the handshake made\n  (see the namespace's doc for opts and failures).R8,i74,R9,i1,R10,s13,arbace/tls.aev10,arbace.tls7,sessionm10,R3,L1,V1,Myn1,sm2,R5,R21,R0,s135,The TLS session of socket s (from connect): :protocol, :cipher-suite, :application-protocol\n  (nil when none was agreed), :server-name.R8,i93,R9,i1,R10,s13,arbace/tls.aev10,arbace.tls17,peer-certificatesm10,R3,L1,V1,Myn1,sm2,R5,R21,R0,s83,The peer's certificates of socket s (from connect), DER byte arrays, its own first.R8,i100,R9,i1,R10,s13,arbace/tls.ae")

var Lit_17 *jrt.String = jrt.Intern("arbace.tls$eval1733000004$loading__1927001464__auto____1733000005")

var Lit_18 *jrt.String = jrt.Intern("arbace.tls$eval1733000008$fn__1733000009")

var Lit_19 *jrt.String = jrt.Intern("arbace.tls$fail")

var Lit_20 *jrt.String = jrt.Intern("arbace.tls$pem_bytes")

var Lit_21 *jrt.String = jrt.Intern("arbace.tls$read_roots")

var Lit_22 *jrt.String = jrt.Intern("arbace.tls$fn__1733000015")

var Lit_23 *jrt.String = jrt.Intern("arbace.tls$connect")

var Lit_24 *jrt.String = jrt.Intern("arbace.tls$session")

var Lit_25 *jrt.String = jrt.Intern("arbace.tls$peer_certificates")
