//line a2g_strings.ae:1
package aot_arbace_tls

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.tls.host")

var Lit_7 *jrt.String = jrt.Intern("host")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.tls")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("TLS client connections. (connect host port) is a java.net.Socket whose streams carry the plain\n  text of a TLS connection to host: the peer's certificate verified for the server name (host,\n  unless :server-name says another), which is also sent (SNI). In the box the guest does TLS\n  itself (Go's crypto/tls) over the launcher's stream (ARBACE_BOX_NET must allow the dial, e.g.\n  dial=api.anthropic.com:443): the keys and the plain text stay in the guest, the launcher\n  carries only the cipher text. Natively the same, over the host's socket.\n\n    (connect host port)        a connected socket, the handshake made\n    (connect host port opts)   opts:\n        :server-name  the name sent and verified (default host; an IP literal is verified\n                      against the certificate's addresses and not sent)\n        :alpn         the application protocols offered, a sequence of strings (\"http/1.1\")\n        :roots        the trusted certificates, PEM (a string or bytes), in place of the default\n        :timeout      ms for the connection and for the handshake (0, the default: no limit)\n    (session s)                {:protocol \"TLSv1.3\" :cipher-suite ... :application-protocol\n                               (nil when none was agreed) :server-name ...}\n    (peer-certificates s)      the peer's certificates, DER byte arrays, its own first\n\n  The trusted roots, by default: Mozilla's, built into the program (natively and in the box;\n  golang.org/x/crypto/x509roots/fallback's bundle).\n  ARBACE_TLS_ROOTS replaces them for the process: ref:NAME, a PEM bundle in the store\n  (arbace.box; in the box, the launcher's store), or a file's path (in the box, a file of its\n  in-memory file system). :roots replaces them for one connection.\n\n  What fails throws: the network's errors as java.net's exceptions (ConnectException,\n  UnknownHostException, SocketTimeoutException ...); TLS's as an ex-info whose data's\n  :arbace.tls/error is :verify (the peer's certificate is not trusted, has expired, or is not for\n  the server name), :handshake (the handshake failed otherwise: an alert, no common protocol or\n  cipher) or :roots (the roots given hold no certificate, or ARBACE_TLS_ROOTS names none).")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("ex-info")

var Lit_16 *jrt.String = jrt.Intern("assoc")

var Lit_17 *jrt.String = jrt.Intern("error")

var Lit_18 *jrt.String = jrt.Intern("string?")

var Lit_19 *jrt.String = jrt.Intern("bytes?")

var Lit_20 *jrt.String = jrt.Intern("else")

var Lit_21 *jrt.String = jrt.Intern("class")

var Lit_22 *jrt.String = jrt.Intern("starts-with?")

var Lit_23 *jrt.String = jrt.Intern("subs")

var Lit_24 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_25 *jrt.String = jrt.Intern("pem-bytes")

var Lit_26 *jrt.String = jrt.Intern("arbace.box")

var Lit_27 *jrt.String = jrt.Intern("load")

var Lit_28 *jrt.String = jrt.Intern("fail")

var Lit_29 *jrt.String = jrt.Intern("roots")

var Lit_30 *jrt.String = jrt.Intern("blank?")

var Lit_31 *jrt.String = jrt.Intern("read-roots")

var Lit_32 *jrt.String = jrt.Intern("next")

var Lit_33 *jrt.String = jrt.Intern("to-array")

var Lit_34 *jrt.String = jrt.Intern("seq")

var Lit_35 *jrt.String = jrt.Intern("first")

var Lit_36 *jrt.String = jrt.Intern("server-name")

var Lit_37 *jrt.String = jrt.Intern("alpn")

var Lit_38 *jrt.String = jrt.Intern("timeout")

var Lit_39 *jrt.String = jrt.Intern("join")

var Lit_40 *jrt.String = jrt.Intern("some?")

var Lit_41 *jrt.String = jrt.Intern("port")

var Lit_42 *jrt.String = jrt.Intern("connect")

var Lit_43 *jrt.String = jrt.Intern("env-roots")

var Lit_44 *jrt.String = jrt.Intern("not=")

var Lit_45 *jrt.String = jrt.Intern("session")

var Lit_46 *jrt.String = jrt.Intern("application-protocol")

var Lit_47 *jrt.String = jrt.Intern("vec")

var Lit_48 *jrt.String = jrt.Intern("peer-certificates")

var Lit_49 *jrt.String = jrt.Intern("arbace.tls$connect")

var Lit_50 *jrt.String = jrt.Intern(",")

var Lit_51 *jrt.String = jrt.Intern("TLS with ")

var Lit_52 *jrt.String = jrt.Intern(":")

var Lit_53 *jrt.String = jrt.Intern(": ")

var Lit_54 *jrt.String = jrt.Intern(" (as ")

var Lit_55 *jrt.String = jrt.Intern(")")

var Lit_56 *jrt.String = jrt.Intern("arbace.tls$eval1733000004$loading__1927001464__auto____1733000005")

var Lit_57 *jrt.String = jrt.Intern("java.io.File")

var Lit_58 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_59 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_60 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_61 *jrt.String = jrt.Intern("arbace.tls$eval1733000008$fn__1733000009")

var Lit_62 *jrt.String = jrt.Intern("arbace.tls$fail")

var Lit_63 *jrt.String = jrt.Intern("arbace.tls$fn__1733000015")

var Lit_64 *jrt.String = jrt.Intern("ARBACE_TLS_ROOTS")

var Lit_65 *jrt.String = jrt.Intern("arbace.tls$peer_certificates")

var Lit_66 *jrt.String = jrt.Intern("arbace.tls$pem_bytes")

var Lit_67 *jrt.String = jrt.Intern(":roots is PEM, a string or bytes, not ")

var Lit_68 *jrt.String = jrt.Intern("arbace.tls$read_roots")

var Lit_69 *jrt.String = jrt.Intern("ref:")

var Lit_70 *jrt.String = jrt.Intern("ARBACE_TLS_ROOTS: no such ref in the store: ")

var Lit_71 *jrt.String = jrt.Intern("ARBACE_TLS_ROOTS: no such file: ")

var Lit_72 *jrt.String = jrt.Intern("arbace.tls$session")

var Lit_73 *jrt.String = jrt.Intern("in-ns")

var Lit_74 *jrt.String = jrt.Intern("private")

var Lit_75 *jrt.String = jrt.Intern("arglists")

var Lit_76 *jrt.String = jrt.Intern("kind")

var Lit_77 *jrt.String = jrt.Intern("msg")

var Lit_78 *jrt.String = jrt.Intern("tag")

var Lit_79 *jrt.String = jrt.Intern("String")

var Lit_80 *jrt.String = jrt.Intern("data")

var Lit_81 *jrt.String = jrt.Intern("line")

var Lit_82 *jrt.String = jrt.Intern("column")

var Lit_83 *jrt.String = jrt.Intern("file")

var Lit_84 *jrt.String = jrt.Intern("arbace/tls.ae")

var Lit_85 *jrt.String = jrt.Intern("x")

var Lit_86 *jrt.String = jrt.Intern("bytes")

var Lit_87 *jrt.String = jrt.Intern("The bytes of PEM text x (a string or bytes).")

var Lit_88 *jrt.String = jrt.Intern("source")

var Lit_89 *jrt.String = jrt.Intern("The PEM bytes source names: ref:NAME, the blob ref NAME points at in the store (arbace.box), or\n  a file's path.")

var Lit_90 *jrt.String = jrt.Intern("keys")

var Lit_91 *jrt.String = jrt.Intern("A socket connected to host and port whose streams carry TLS's plain text, the handshake made\n  (see the namespace's doc for opts and failures).")

var Lit_92 *jrt.String = jrt.Intern("s")

var Lit_93 *jrt.String = jrt.Intern("Socket")

var Lit_94 *jrt.String = jrt.Intern("The TLS session of socket s (from connect): :protocol, :cipher-suite, :application-protocol\n  (nil when none was agreed), :server-name.")

var Lit_95 *jrt.String = jrt.Intern("The peer's certificates of socket s (from connect), DER byte arrays, its own first.")
