//line java_util_Set.ae:1
package jrt





































func Set_Spliterator__Spliterator(this Set) Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(this, 1)
}
func Set_Of__Set() Set { ImmutableCollections_Init(); return Up_ImmutableCollections_SetN_Set(ImmutableCollections_EMPTY_SET) }


func Set_Of_O__Set(e1 any) Set {
	return ImmutableCollections_Set12_New_O(e1)
}
func Set_Of_O_O__Set(e1, e2 any) Set {
	return ImmutableCollections_Set12_New_O_O(e1, e2)
}
func Set_Of_O_O_O__Set(e1, e2, e3 any) Set {
	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3))
}
func Set_Of_O_O_O_O__Set(e1, e2, e3, e4 any) Set {
	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3, e4))
}
func Set_Of_O_O_O_O_O__Set(e1, e2, e3, e4, e5 any) Set {
	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3, e4, e5))
}
func Set_Of_O_O_O_O_O_O__Set(e1, e2, e3, e4, e5, e6 any) Set {
	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6))
}
func Set_Of_O_O_O_O_O_O_O__Set(e1, e2, e3, e4, e5, e6, e7 any) Set {
	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7))
}
func Set_Of_O_O_O_O_O_O_O_O__Set(e1, e2, e3, e4, e5, e6, e7, e8 any) Set {

	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7, e8))
}
func Set_Of_O_O_O_O_O_O_O_O_O__Set(e1, e2, e3, e4, e5, e6, e7, e8, e9 any) Set {

	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7, e8, e9))
}
func Set_Of_O_O_O_O_O_O_O_O_O_O__Set(e1, e2, e3, e4, e5, e6, e7, e8, e9, e10 any) Set {

	return ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7, e8, e9, e10))
}
func Set_Of_O1__Set(elements *RefArray) Set {
	switch int32(len(elements.A)) { case 0:
		var set *ImmutableCollections_SetN; ImmutableCollections_Init(); set = ImmutableCollections_EMPTY_SET; return Up_ImmutableCollections_SetN_Set(set); case 1:
		return ImmutableCollections_Set12_New_O(elements.A[0]); case 2:
		var tmp1 any = elements.A[0]; return ImmutableCollections_Set12_New_O_O(tmp1, elements.A[1]); default:
		return ImmutableCollections_SetN_New_O1(elements)}; panic("a2g: unreachable")
}
func Set_CopyOf_Collection__Set(coll Collection) Set {
	if ImmutableCollections_AbstractImmutableSet_InstanceOf(coll) {
		return Set_Cast(coll) } else {
//line :86:1
			if coll.IsEmpty__Z() {

				return Set_Of__Set() } else {
					return Set_Of_O1__Set(HashSet_New_Collection(coll).ToArray__O1())
				} } }
type Set interface{ Object_I; Collection; Iterable; Is_Set(); Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; Iterator__Iterator() Iterator; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; AddAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; Clear__V(); Spliterator__Spliterator() Spliterator }

func Set_InstanceOf(x any) bool { _, ok := x.(Set); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Set_class) } }; return ok }

func Set_Cast(x any) Set { if x == nil { return nil }; v, ok := x.(Set); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Set_class) } }; if !ok { panic(ClassCast(x, Set_class)) }; return v }
