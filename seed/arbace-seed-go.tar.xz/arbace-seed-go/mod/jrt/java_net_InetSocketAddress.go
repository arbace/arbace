//line java_net_InetSocketAddress.ae:1
package jrt























func InetSocketAddress_InetSocketAddressHolder_New_String_InetAddress_I(p0 *String, p1 InetAddress_I, p2 int32) *InetSocketAddress_InetSocketAddressHolder { t := &InetSocketAddress_InetSocketAddressHolder{}; t.Ctor_String_InetAddress_I(p0, p1, p2); return t }
//line :25:1
func (t *InetSocketAddress_InetSocketAddressHolder) Ctor_String_InetAddress_I(hostname *String, addr InetAddress_I, port int32) {
	t.F_hostname = hostname
	t.F_addr = addr
	t.F_port = port
}
func (t *InetSocketAddress_InetSocketAddressHolder) GetPort__I() int32 { return t.F_port }

func (t *InetSocketAddress_InetSocketAddressHolder) GetAddress__InetAddress() InetAddress_I { return t.F_addr }

func (t *InetSocketAddress_InetSocketAddressHolder) GetHostName__String() *String {
	if !(t.F_hostname == nil) { return t.F_hostname } else { if !(t.F_addr == nil) { return t.F_addr.GetHostName__String() } else { return nil
	} } }
func (t *InetSocketAddress_InetSocketAddressHolder) GetHostString__String() *String {
	if !(t.F_hostname == nil) { return t.F_hostname } else { if !(t.F_addr == nil) {


		if !(NN(t.F_addr.Holder__InetAddress_InetAddressHolder()).GetHostName__String() == nil) {
			return NN(t.F_addr.Holder__InetAddress_InetAddressHolder()).GetHostName__String() } else {
				return t.F_addr.GetHostAddress__String() } } else {
//line :38:1
					return nil
				}
	}
}



func (t *InetSocketAddress_InetSocketAddressHolder) IsUnresolved__Z() bool { return t.F_addr == nil }

func (t *InetSocketAddress_InetSocketAddressHolder) ToString__String() *String {
	var formatted *String
	if t.IsUnresolved__Z() {
		formatted = Concat(t.F_hostname, Lit_1330) } else {

			formatted = t.F_addr.ToString__String()
			if Inet6Address_InstanceOf(t.F_addr) {
				var i int32 = NN(formatted).LastIndexOf_String__I(Lit_68)
				formatted = Concat(NN(formatted).Substring_I_I__String(0, i+1), Lit_1318, NN(formatted).Substring_I__String(i+1), Lit_1189)
			}
		}


	return Concat(formatted, Lit_1309, StrOfInt(t.F_port))
}
func (t *InetSocketAddress_InetSocketAddressHolder) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if InetSocketAddress_InetSocketAddressHolder_InstanceOf(tmp1) { var that *InetSocketAddress_InetSocketAddressHolder = InetSocketAddress_InetSocketAddressHolder_Cast(tmp1); var sameIP bool
		if !(t.F_addr == nil) {
			var tmp2 InetAddress_I = t.F_addr; sameIP = tmp2.Equals_O__Z(that.F_addr) } else {
//line :64:1
				if !(t.F_hostname == nil) {


					var tmp3 bool; tmp3 = that.F_addr == nil; if tmp3 {
						var tmp4 *String = t.F_hostname; tmp3 = NN(tmp4).EqualsIgnoreCase_String__Z(that.F_hostname) }
//line :67:1
					sameIP = tmp3 } else {

						var tmp5 bool; tmp5 = that.F_addr == nil; if tmp5 { tmp5 = that.F_hostname == nil }; sameIP = tmp5 } }
		var tmp6 bool; tmp6 = sameIP; if tmp6 { var tmp7 int32 = t.F_port; tmp6 = tmp7 == that.F_port }; return tmp6 } else {
//line :63:1
			return false
		}
}







func (t *InetSocketAddress_InetSocketAddressHolder) HashCode__I() int32 {
	if !(t.F_addr == nil) {
		return t.F_addr.HashCode__I() + t.F_port } else {
//line :74:1
			if !(t.F_hostname == nil) {

				var tmp1 *String = t.F_hostname; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; return NN(NN(tmp1).ToLowerCase_Locale__String(tmp2)).HashCode__I() + t.F_port } else {
//line :74:1
					return t.F_port
				}
		}
}





func InetSocketAddress_CheckPort_I__I(port int32) int32 { InetSocketAddress_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = port < 0; if !tmp2 { tmp2 = port > 65535 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1328, StrOfInt(port))))) }
//line :83:1
	return port
}



func InetSocketAddress_CheckHost_String__String(hostname *String) *String { InetSocketAddress_Init()
	if hostname == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1329))) }
//line :88:1
	return hostname
}


func InetSocketAddress_New_I(p0 int32) *InetSocketAddress { InetSocketAddress_Init(); t := &InetSocketAddress{}; t.Ctor_I(p0); return t }
//line :92:1
func (t *InetSocketAddress) Ctor_I(port int32) { t.Ctor_InetAddress_I(InetAddress_AnyLocalAddress__InetAddress(), port) }


func InetSocketAddress_New_InetAddress_I(p0 InetAddress_I, p1 int32) *InetSocketAddress { InetSocketAddress_Init(); t := &InetSocketAddress{}; t.Ctor_InetAddress_I(p0, p1); return t }
//line :95:1
func (t *InetSocketAddress) Ctor_InetAddress_I(addr InetAddress_I, port int32) { t.SocketAddress.Ctor(t)
	var tmp1 InetAddress_I

	if addr == nil { tmp1 = InetAddress_AnyLocalAddress__InetAddress() } else { tmp1 = addr }
//line :96:1
	t.F_holder = InetSocketAddress_InetSocketAddressHolder_New_String_InetAddress_I(nil, tmp1, InetSocketAddress_CheckPort_I__I(port))
}



func InetSocketAddress_New_String_I(p0 *String, p1 int32) *InetSocketAddress { InetSocketAddress_Init(); t := &InetSocketAddress{}; t.Ctor_String_I(p0, p1); return t }
//line :101:1
func (t *InetSocketAddress) Ctor_String_I(hostname *String, port int32) { t.SocketAddress.Ctor(t)
	InetSocketAddress_CheckHost_String__String(hostname)
	var addr InetAddress_I; var host *String; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)


		addr = InetAddress_GetByName_String__InetAddress(hostname)
//line :103:1
		return nil
	}()
	if tmp1 != nil { if UnknownHostException_InstanceOf(tmp1) { var e *UnknownHostException = UnknownHostException_Cast(tmp1); _ = e

		host = hostname } else {
//line :105:1
			panic(tmp1)
		}
	}
	t.F_holder = InetSocketAddress_InetSocketAddressHolder_New_String_InetAddress_I(host, addr, InetSocketAddress_CheckPort_I__I(port))
}
func InetSocketAddress_New_I_String(p0 int32, p1 *String) *InetSocketAddress { InetSocketAddress_Init(); t := &InetSocketAddress{}; t.Ctor_I_String(p0, p1); return t }
//line :110:1
func (t *InetSocketAddress) Ctor_I_String(port int32, hostname *String) { t.SocketAddress.Ctor(t)
	t.F_holder = InetSocketAddress_InetSocketAddressHolder_New_String_InetAddress_I(hostname, nil, port)
}
func InetSocketAddress_CreateUnresolved_String_I__InetSocketAddress(host *String, port int32) *InetSocketAddress { InetSocketAddress_Init()
	return InetSocketAddress_New_I_String(InetSocketAddress_CheckPort_I__I(port), InetSocketAddress_CheckHost_String__String(host))
}

























func (t *InetSocketAddress) ReadObjectNoData__V() { panic(A2g_NotTranslated("java.net.InetSocketAddress.readObjectNoData()V")) }







func (t *InetSocketAddress) GetPort__I() int32 { return NN(t.F_holder).GetPort__I() }

func (t *InetSocketAddress) GetAddress__InetAddress() InetAddress_I {
	return NN(t.F_holder).GetAddress__InetAddress()
}
func (t *InetSocketAddress) GetHostName__String() *String {
	return NN(t.F_holder).GetHostName__String()
}
func (t *InetSocketAddress) GetHostString__String() *String {
	return NN(t.F_holder).GetHostString__String()
}
func (t *InetSocketAddress) IsUnresolved__Z() bool {
	return NN(t.F_holder).IsUnresolved__Z()
}
func (t *InetSocketAddress) ToString__String() *String { return NN(t.F_holder).ToString__String() }

func (t *InetSocketAddress) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if InetSocketAddress_InstanceOf(tmp1) { var addr *InetSocketAddress = InetSocketAddress_Cast(tmp1); var tmp2 *InetSocketAddress_InetSocketAddressHolder = t.F_holder; return NN(tmp2).Equals_O__Z(addr.F_holder.Ref()) } else { return false
	} }
func (t *InetSocketAddress) HashCode__I() int32 { return NN(t.F_holder).HashCode__I() }



type InetSocketAddress struct{ SocketAddress; F_holder *InetSocketAddress_InetSocketAddressHolder }

const InetSocketAddress_serialVersionUID int64 = 5076001401234631237

var InetSocketAddress_UNSAFE *Unsafe

var InetSocketAddress_FIELDS_OFFSET int64

var InetSocketAddress_init ClassInit

func InetSocketAddress_Init() { if !InetSocketAddress_init.Done() { InetSocketAddress_init.Run(InetSocketAddress_clinit) } }

func InetSocketAddress_clinit() { InetSocketAddress_UNSAFE = Unsafe_GetUnsafe__Unsafe(); InetSocketAddress_FIELDS_OFFSET = NN(InetSocketAddress_UNSAFE).ObjectFieldOffset_Class_String__J(InetSocketAddress_class, Lit_1315) }

func (t *InetSocketAddress) Ref() any { if t == nil { return nil }; return t }

func (t *InetSocketAddress) GetClass__Class() *Class { return InetSocketAddress_class }

func (t *InetSocketAddress) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetSocketAddress) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetSocketAddress_InstanceOf(x any) bool { _, ok := x.(*InetSocketAddress); return ok }

func InetSocketAddress_Cast(x any) *InetSocketAddress { if x == nil { return nil }; v, ok := x.(*InetSocketAddress); if !ok { panic(ClassCast(x, InetSocketAddress_class)) }; return v }



type InetSocketAddress_InetSocketAddressHolder struct{ Object; F_hostname *String; F_addr InetAddress_I; F_port int32 }

func (t *InetSocketAddress_InetSocketAddressHolder) Ref() any { if t == nil { return nil }; return t }

func (t *InetSocketAddress_InetSocketAddressHolder) GetClass__Class() *Class { return InetSocketAddress_InetSocketAddressHolder_class }

func (t *InetSocketAddress_InetSocketAddressHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetSocketAddress_InetSocketAddressHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetSocketAddress_InetSocketAddressHolder_InstanceOf(x any) bool { _, ok := x.(*InetSocketAddress_InetSocketAddressHolder); return ok }

func InetSocketAddress_InetSocketAddressHolder_Cast(x any) *InetSocketAddress_InetSocketAddressHolder { if x == nil { return nil }; v, ok := x.(*InetSocketAddress_InetSocketAddressHolder); if !ok { panic(ClassCast(x, InetSocketAddress_InetSocketAddressHolder_class)) }; return v }
