//line java_text_ListFormat.ae:1
package jrt

















































func ListFormat_New_Locale_String1(p0 *Locale, p1 *RefArray) *ListFormat { ListFormat_Init(); t := &ListFormat{}; t.Ctor_Locale_String1(p0, p1); return t }
//line :51:1
func (t *ListFormat) Ctor_Locale_String1(l *Locale, patterns *RefArray) { t.Format.Ctor(t)
	t.F_locale = l
	t.F_patterns = patterns
	t.Init__V()
}
func (t *ListFormat) Init__V() {
	var arr_101317 *RefArray = t.F_patterns; var len_101318 int32 = int32(len(arr_101317.A)); var i_101319 int32 = 0; for ; i_101319 < len_101318; i_101319++ { var elem *String = As[*String](arr_101317.A[i_101319])
		if elem == nil {
			panic(Thrown(IllegalArgumentException_New_String(Lit_1857))) } }
	var tmp1 *Pattern = ListFormat_PARSE_START; var m *Matcher = NN(tmp1).Matcher_CharSequence__Matcher(Up_String_CharSequence(As[*String](t.F_patterns.A[0]))); var startBefore *String; var startBetween *String


	if NN(m).Matches__Z() {
		startBefore = NN(m).Group_I__String(1); startBetween = NN(m).Group_I__String(2) } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1858, As[*String](t.F_patterns.A[0])))))
		}
	var tmp2 *Pattern = ListFormat_PARSE_MIDDLE; m = NN(tmp2).Matcher_CharSequence__Matcher(Up_String_CharSequence(As[*String](t.F_patterns.A[1])))
	if NN(m).Matches__Z() {
		t.F_middleBetween = NN(m).Group_I__String(1) } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1859, As[*String](t.F_patterns.A[1])))))
		}
	var tmp3 *Pattern = ListFormat_PARSE_END; m = NN(tmp3).Matcher_CharSequence__Matcher(Up_String_CharSequence(As[*String](t.F_patterns.A[2])))
	var endBetween *String; var endAfter *String

	if NN(m).Matches__Z() {
		endBetween = NN(m).Group_I__String(1); endAfter = NN(m).Group_I__String(2) } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1860, As[*String](t.F_patterns.A[2])))))
		}
	if !NN(As[*String](t.F_patterns.A[3])).IsEmpty__Z() {
		var tmp4 *Pattern = ListFormat_PARSE_TWO; if NN(NN(tmp4).Matcher_CharSequence__Matcher(Up_String_CharSequence(As[*String](t.F_patterns.A[3])))).Matches__Z() { } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1861, As[*String](t.F_patterns.A[3]))))) } } else {

				var tmp5 *RefArray = t.F_patterns; tmp5.Store(3, Concat(startBefore, Lit_1862, endBetween, Lit_1863, endAfter)) }
	if !NN(As[*String](t.F_patterns.A[4])).IsEmpty__Z() {
		var tmp6 *Pattern = ListFormat_PARSE_THREE; if NN(NN(tmp6).Matcher_CharSequence__Matcher(Up_String_CharSequence(As[*String](t.F_patterns.A[4])))).Matches__Z() { } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1864, As[*String](t.F_patterns.A[4]))))) } } else {

				var tmp7 *RefArray = t.F_patterns; tmp7.Store(4, Concat(startBefore, Lit_1862, startBetween, Lit_1863, endBetween, Lit_1865, endAfter))
			}

	t.F_startPattern = Pattern_Compile_String__Pattern(Concat(startBefore, Lit_1866, startBetween))
	t.F_endPattern = Pattern_Compile_String__Pattern(Concat(endBetween, Lit_1866, endAfter))
}
func ListFormat_GetAvailableLocales__Locale1() *RefArray { ListFormat_Init()
	return DateFormat_GetAvailableLocales__Locale1()
}
func ListFormat_GetInstance__ListFormat() *ListFormat { ListFormat_Init()
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; var tmp2 *Locale = Locale_GetDefault_Locale_Category__Locale(tmp1); var tmp3 *ListFormat_Type; ListFormat_Type_Init(); tmp3 = ListFormat_Type_STANDARD; var tmp4 *ListFormat_Type = tmp3; var tmp5 *ListFormat_Style; ListFormat_Style_Init(); tmp5 = ListFormat_Style_FULL; return ListFormat_GetInstance_Locale_ListFormat_Type_ListFormat_Style__ListFormat(tmp2, tmp4, tmp5)
}
func ListFormat_GetInstance_Locale_ListFormat_Type_ListFormat_Style__ListFormat(locale *Locale, type_ *ListFormat_Type, style *ListFormat_Style) *ListFormat { ListFormat_Init()
	Objects_RequireNonNull_O__O(locale.Ref())
	Objects_RequireNonNull_O__O(type_.Ref())
	Objects_RequireNonNull_O__O(style.Ref())
	var tmp1 *LocaleProviderAdapter_Type; LocaleProviderAdapter_Type_Init(); tmp1 = LocaleProviderAdapter_Type_CLDR; return ListFormat_New_Locale_String1(locale, NN(LocaleProviderAdapter_ForType_LocaleProviderAdapter_Type__LocaleProviderAdapter(tmp1).GetLocaleResources_Locale__LocaleResources(locale)).GetListPatterns_ListFormat_Type_ListFormat_Style__String1(type_, style))
}






func ListFormat_GetInstance_String1__ListFormat(patterns *RefArray) *ListFormat { ListFormat_Init()
	Objects_RequireNonNull_O__O(patterns.Ref())
	if int32(len(patterns.A)) == 5 { } else {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1867)))
	}
	var tmp1 *Locale; Locale_Init(); tmp1 = Locale_ROOT; var tmp2 *Locale = tmp1; return ListFormat_New_Locale_String1(tmp2, A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(patterns, 5).Ref(), String_class.ArrayClass()))
}
func (t *ListFormat) GetLocale__Locale() *Locale { return t.F_locale }

func (t *ListFormat) GetPatterns__String1() *RefArray {
	var tmp1 *RefArray = t.F_patterns; return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_patterns.A))).Ref(), String_class.ArrayClass())
}
func (t *ListFormat) Format_List__String(input List) *String {
	Objects_RequireNonNull_O__O(input)
	var tmp1 Format_StringBuf = StringBufFactory_Of__Format_StringBuf(); var tmp2 FieldPosition_I; DontCareFieldPosition_Init(); tmp2 = DontCareFieldPosition_INSTANCE; return t.Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(input, tmp1, tmp2).ToString__String()
}
func (t *ListFormat) Format_O_StringBuffer_FieldPosition__StringBuffer(obj any, toAppendTo *StringBuffer, pos FieldPosition_I) *StringBuffer {
	Objects_RequireNonNull_O__O(obj)
	Objects_RequireNonNull_O__O(toAppendTo.Ref())
	return t.Format_O_Format_StringBuf__Format_StringBuf(obj, StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo)).AsStringBuffer__StringBuffer()
}
func (t *ListFormat) Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(obj any, toAppendTo Format_StringBuf, pos FieldPosition_I) Format_StringBuf {
	Objects_RequireNonNull_O__O(obj)
	Objects_RequireNonNull_O__O(toAppendTo)
	return t.Format_O_Format_StringBuf__Format_StringBuf(obj, toAppendTo)
}
func (t *ListFormat) Format_O_Format_StringBuf__Format_StringBuf(obj any, toAppendTo Format_StringBuf) Format_StringBuf {
	var tmp1 any = obj; if Object_class.ArrayClass().IsInstance_O__Z(tmp1) { var objs *RefArray = A2g_CastArray[*RefArray](tmp1, Object_class.ArrayClass()); var tmp2 *MessageFormat = t.GenerateMessageFormat_O1__MessageFormat(objs); var tmp3 FieldPosition_I
		DontCareFieldPosition_Init(); tmp3 = DontCareFieldPosition_INSTANCE; return NN(tmp2).Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(objs.Ref(), toAppendTo, tmp3) } else {
			var tmp4 any = obj; if List_InstanceOf(tmp4) { var objs_2 List = List_Cast(tmp4); var a *RefArray = objs_2.ToArray_O1__O1(NewRefArray(Object_class, 0)); var tmp5 *MessageFormat = t.GenerateMessageFormat_O1__MessageFormat(a); var tmp6 FieldPosition_I

				DontCareFieldPosition_Init(); tmp6 = DontCareFieldPosition_INSTANCE; return NN(tmp5).Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(a.Ref(), toAppendTo, tmp6) } else {
					panic(Thrown(IllegalArgumentException_New_String(Lit_1868)))
				}
		} }
func (t *ListFormat) Parse_String__List(source *String) List {
	var pp *ParsePosition = ParsePosition_New_I(0); var tmp1 any = t.ParseObject_String_ParsePosition__O(source, pp)
	if List_InstanceOf(tmp1) { var orig List = List_Cast(tmp1)
		return orig.Stream__Stream().Map_Function__Stream(&Function_Fn{Fn: func(p0 any) any { var o any = p0; return String_Cast(o).Ref() }}).ToList__List() } else {
			panic(Thrown(ParseException_New_String_I(Lit_1869, NN(pp).GetErrorIndex__I())))
		} }
func (t *ListFormat) ParseObject_String_ParsePosition__O(source *String, parsePos *ParsePosition) any {
	Objects_RequireNonNull_O__O(source.Ref())
	Objects_RequireNonNull_O__O(parsePos.Ref())
	var sm *Matcher = NN(t.F_startPattern).Matcher_CharSequence__Matcher(Up_String_CharSequence(source)); var em *Matcher = NN(t.F_endPattern).Matcher_CharSequence__Matcher(Up_String_CharSequence(source)); var parsed any; var tmp1 bool; var tmp2 bool


	tmp2 = NN(sm).Find_I__Z(NN(parsePos).GetIndex__I()); if tmp2 { tmp2 = NN(em).Find_I__Z(NN(parsePos).GetIndex__I()) }; tmp1 = tmp2; if tmp1 {
		var c int32 = NN(em).Start__I()
	L1: for { if NN(em).Find__Z() { c = NN(em).Start__I(); continue L1 }; break L1 }
		NN(em).Find_I__Z(c)
		var startEnd int32 = NN(sm).End__I(); var endStart int32 = NN(em).Start__I()

		if startEnd <= endStart {
			var mid *String = NN(source).Substring_I_I__String(startEnd, endStart); var count int32 = int32(len(NN(mid).Split_String__String1(t.F_middleBetween).A)) + 2

			parsed = MessageFormat_New_String_Locale(t.CreateMessageFormatString_I__String(count), t.F_locale).ParseObject_String_ParsePosition__O(source, parsePos)
		}
	}

	if parsed == nil {
		parsed = MessageFormat_New_String_Locale(As[*String](t.F_patterns.A[3]), t.F_locale).ParseObject_String_ParsePosition__O(source, parsePos)
		if parsed == nil {
			parsed = MessageFormat_New_String_Locale(As[*String](t.F_patterns.A[4]), t.F_locale).ParseObject_String_ParsePosition__O(source, parsePos) } }
	if parsed == nil {
		parsed = RefArrayOf(String_class, NN(source).Substring_I__String(NN(parsePos).GetIndex__I()).Ref())
		NN(parsePos).SetIndex_I__V(NN(source).Length__I()) }
	var tmp3 any = parsed; if Object_class.ArrayClass().IsInstance_O__Z(tmp3) { var objs *RefArray = A2g_CastArray[*RefArray](tmp3, Object_class.ArrayClass()); NN(parsePos).SetErrorIndex_I__V(-1); return Arrays_AsList_O1__List(objs) } else { return nil
	} }
func (t *ListFormat) FormatToCharacterIterator_O__AttributedCharacterIterator(arguments any) AttributedCharacterIterator {
	Objects_RequireNonNull_O__O(arguments)
	var tmp1 any = arguments; if List_InstanceOf(tmp1) { var objs List = List_Cast(tmp1); var a *RefArray = objs.ToArray_O1__O1(NewRefArray(Object_class, 0))

		return NN(t.GenerateMessageFormat_O1__MessageFormat(a)).FormatToCharacterIterator_O__AttributedCharacterIterator(a.Ref()) } else {
			var tmp2 any = arguments; if Object_class.ArrayClass().IsInstance_O__Z(tmp2) { var objs_2 *RefArray = A2g_CastArray[*RefArray](tmp2, Object_class.ArrayClass())
				return NN(t.GenerateMessageFormat_O1__MessageFormat(objs_2)).FormatToCharacterIterator_O__AttributedCharacterIterator(objs_2.Ref()) } else {
					panic(Thrown(IllegalArgumentException_New_String(Lit_1870)))
				} } }
func (t *ListFormat) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if ListFormat_InstanceOf(tmp1) { var other *ListFormat = ListFormat_Cast(tmp1); var tmp2 bool; var tmp3 *Locale = t.F_locale
			tmp2 = NN(tmp3).Equals_O__Z(other.F_locale.Ref()); if tmp2 { var tmp4 *RefArray = t.F_patterns; tmp2 = Arrays_Equals_O1_O1__Z(tmp4, other.F_patterns) }; return tmp2 } else {
//line :193:1
				return false
			}
	}
}
func (t *ListFormat) HashCode__I() int32 {
	var tmp1 any = t.F_locale.Ref(); return Objects_Hash_O1__I(RefArrayOf(Object_class, tmp1, Integer_ValueOf_I__Integer(Arrays_HashCode_O1__I(t.F_patterns))))
}
func (t *ListFormat) ToString__String() *String {
	var tmp1 any = NN(t.F_locale).GetDisplayName__String().Ref(); var tmp2 any = As[*String](t.F_patterns.A[0]).Ref(); var tmp3 any = As[*String](t.F_patterns.A[1]).Ref(); var tmp4 any = As[*String](t.F_patterns.A[2]).Ref(); var tmp5 any = As[*String](t.F_patterns.A[3]).Ref(); return Lit_1871.Formatted_O1__String(RefArrayOf(Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, As[*String](t.F_patterns.A[4]).Ref()))
}







func (t *ListFormat) GenerateMessageFormat_O1__MessageFormat(input *RefArray) *MessageFormat {
	{ var len_ int32 = int32(len(input.A))
		switch len_ { case 0:
			panic(Thrown(IllegalArgumentException_New_String(Lit_1872))); case 1:
			return MessageFormat_New_String_Locale(Lit_1862, t.F_locale); case 2, 3:
			return MessageFormat_New_String_Locale(As[*String](t.F_patterns.A[len_+1]), t.F_locale); default:
			return MessageFormat_New_String_Locale(t.CreateMessageFormatString_I__String(len_), t.F_locale)} }; panic("a2g: unreachable")
}
func (t *ListFormat) CreateMessageFormatString_I__String(count int32) *String {
	var sb *StringBuilder = StringBuilder_New_I(256).Append_String__StringBuilder(As[*String](t.F_patterns.A[0]))
	IntStream_Range_I_I__IntStream(2, count-1).ForEach_IntConsumer__V(&IntConsumer_Fn{Fn: func(p0 int32) { var i int32 = p0;

		NN(NN(NN(NN(sb).Append_String__StringBuilder(t.F_middleBetween)).Append_String__StringBuilder(Lit_1873)).Append_I__StringBuilder(i)).Append_String__StringBuilder(Lit_1874) }})
	NN(sb).Append_String__StringBuilder(NN(NN(As[*String](t.F_patterns.A[2])).ReplaceFirst_String_String__String(Lit_1875, Lit_69)).ReplaceFirst_String_String__String(Lit_1876, Concat(Lit_1877, StrOfInt(count-1), Lit_1878)))



	return NN(sb).ToString__String()
}


type ListFormat struct{ Format; F_locale *Locale; F_patterns *RefArray; F_startPattern *Pattern; F_middleBetween *String; F_endPattern *Pattern }

const ListFormat_serialVersionUID int64 = 5272525550078071946

const ListFormat_START int32 = 0

const ListFormat_MIDDLE int32 = 1

const ListFormat_END int32 = 2

const ListFormat_TWO int32 = 3

const ListFormat_THREE int32 = 4

const ListFormat_PATTERN_ARRAY_LENGTH int32 = 5

var ListFormat_PARSE_START *Pattern

var ListFormat_PARSE_MIDDLE *Pattern

var ListFormat_PARSE_END *Pattern

var ListFormat_PARSE_TWO *Pattern

var ListFormat_PARSE_THREE *Pattern

var ListFormat_init ClassInit

func ListFormat_Init() { if !ListFormat_init.Done() { ListFormat_init.Run(ListFormat_clinit) } }

func ListFormat_clinit() { ListFormat_PARSE_START = Pattern_Compile_String__Pattern(Lit_1852); ListFormat_PARSE_MIDDLE = Pattern_Compile_String__Pattern(Lit_1853); ListFormat_PARSE_END = Pattern_Compile_String__Pattern(Lit_1854); ListFormat_PARSE_TWO = Pattern_Compile_String__Pattern(Lit_1855); ListFormat_PARSE_THREE = Pattern_Compile_String__Pattern(Lit_1856) }

func (t *ListFormat) Format_O__String(p0 any) *String { return t.Impl_Format_O__String(t, p0) }

func (t *ListFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(t, p0) }

func (t *ListFormat) ParseObject_String__O(p0 *String) any { return t.Impl_ParseObject_String__O(t, p0) }

func (t *ListFormat) CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *ListFormat) CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(t, p0) }

func (t *ListFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *ListFormat) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ListFormat) Ref() any { if t == nil { return nil }; return t }

func (t *ListFormat) GetClass__Class() *Class { return ListFormat_class }

func (t *ListFormat) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func ListFormat_InstanceOf(x any) bool { _, ok := x.(*ListFormat); return ok }

func ListFormat_Cast(x any) *ListFormat { if x == nil { return nil }; v, ok := x.(*ListFormat); if !ok { panic(ClassCast(x, ListFormat_class)) }; return v }



type ListFormat_Style struct{ Enum }

func (t *ListFormat_Style) Is_Constable() {}

var ListFormat_Style_FULL *ListFormat_Style

var ListFormat_Style_SHORT *ListFormat_Style

var ListFormat_Style_NARROW *ListFormat_Style

var ListFormat_Style__VALUES *RefArray

var ListFormat_Style_init ClassInit

func ListFormat_Style_Init() { if !ListFormat_Style_init.Done() { ListFormat_Style_init.Run(ListFormat_Style_clinit) } }

func ListFormat_Style_clinit() { ListFormat_Style_FULL = ListFormat_Style_New_String_I(Lit_1798, 0); ListFormat_Style_SHORT = ListFormat_Style_New_String_I(Lit_1801, 1); ListFormat_Style_NARROW = ListFormat_Style_New_String_I(Lit_1879, 2); ListFormat_Style__VALUES = ListFormat_Style_X_values__ListFormat_Style1() }

func ListFormat_Style_New_String_I(p0 *String, p1 int32) *ListFormat_Style { ListFormat_Style_Init(); t := &ListFormat_Style{}; t.Ctor_String_I(p0, p1); return t }

func (t *ListFormat_Style) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func ListFormat_Style_Values__ListFormat_Style1() *RefArray { ListFormat_Style_Init(); return ListFormat_Style__VALUES.Copy() }

func ListFormat_Style_ValueOf_String__ListFormat_Style(p0 *String) *ListFormat_Style { ListFormat_Style_Init(); return ListFormat_Style_Cast(Enum_ValueOf_Class_String__Enum(ListFormat_Style_class, p0)) }

func ListFormat_Style_X_values__ListFormat_Style1() *RefArray { ListFormat_Style_Init(); return RefArrayOf(ListFormat_Style_class, ListFormat_Style_FULL, ListFormat_Style_SHORT, ListFormat_Style_NARROW) }

func (t *ListFormat_Style) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ListFormat_Style) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ListFormat_Style) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ListFormat_Style) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.text.ListFormat$Style.describeConstable()Ljava/util/Optional;")) }

func (t *ListFormat_Style) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ListFormat_Style) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ListFormat_Style) Ref() any { if t == nil { return nil }; return t }

func (t *ListFormat_Style) GetClass__Class() *Class { return ListFormat_Style_class }

func (t *ListFormat_Style) CloneShallow() any { panic(CloneNotSupported(t)) }

func ListFormat_Style_InstanceOf(x any) bool { _, ok := x.(*ListFormat_Style); return ok }

func ListFormat_Style_Cast(x any) *ListFormat_Style { if x == nil { return nil }; v, ok := x.(*ListFormat_Style); if !ok { panic(ClassCast(x, ListFormat_Style_class)) }; return v }



type ListFormat_Type struct{ Enum }

func (t *ListFormat_Type) Is_Constable() {}

var ListFormat_Type_STANDARD *ListFormat_Type

var ListFormat_Type_OR *ListFormat_Type

var ListFormat_Type_UNIT *ListFormat_Type

var ListFormat_Type__VALUES *RefArray

var ListFormat_Type_init ClassInit

func ListFormat_Type_Init() { if !ListFormat_Type_init.Done() { ListFormat_Type_init.Run(ListFormat_Type_clinit) } }

func ListFormat_Type_clinit() { ListFormat_Type_STANDARD = ListFormat_Type_New_String_I(Lit_1880, 0); ListFormat_Type_OR = ListFormat_Type_New_String_I(Lit_1881, 1); ListFormat_Type_UNIT = ListFormat_Type_New_String_I(Lit_1882, 2); ListFormat_Type__VALUES = ListFormat_Type_X_values__ListFormat_Type1() }

func ListFormat_Type_New_String_I(p0 *String, p1 int32) *ListFormat_Type { ListFormat_Type_Init(); t := &ListFormat_Type{}; t.Ctor_String_I(p0, p1); return t }

func (t *ListFormat_Type) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func ListFormat_Type_Values__ListFormat_Type1() *RefArray { ListFormat_Type_Init(); return ListFormat_Type__VALUES.Copy() }

func ListFormat_Type_ValueOf_String__ListFormat_Type(p0 *String) *ListFormat_Type { ListFormat_Type_Init(); return ListFormat_Type_Cast(Enum_ValueOf_Class_String__Enum(ListFormat_Type_class, p0)) }

func ListFormat_Type_X_values__ListFormat_Type1() *RefArray { ListFormat_Type_Init(); return RefArrayOf(ListFormat_Type_class, ListFormat_Type_STANDARD, ListFormat_Type_OR, ListFormat_Type_UNIT) }

func (t *ListFormat_Type) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ListFormat_Type) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ListFormat_Type) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ListFormat_Type) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.text.ListFormat$Type.describeConstable()Ljava/util/Optional;")) }

func (t *ListFormat_Type) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ListFormat_Type) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ListFormat_Type) Ref() any { if t == nil { return nil }; return t }

func (t *ListFormat_Type) GetClass__Class() *Class { return ListFormat_Type_class }

func (t *ListFormat_Type) CloneShallow() any { panic(CloneNotSupported(t)) }

func ListFormat_Type_InstanceOf(x any) bool { _, ok := x.(*ListFormat_Type); return ok }

func ListFormat_Type_Cast(x any) *ListFormat_Type { if x == nil { return nil }; v, ok := x.(*ListFormat_Type); if !ok { panic(ClassCast(x, ListFormat_Type_class)) }; return v }
