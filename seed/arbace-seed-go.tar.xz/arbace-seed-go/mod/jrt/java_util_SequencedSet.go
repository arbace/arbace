//line java_util_SequencedSet.ae:1
package jrt






type SequencedSet interface{ Object_I; SequencedCollection; Set; Collection; Iterable; Is_SequencedSet(); Reversed__SequencedSet() SequencedSet; Reversed__SequencedCollection() SequencedCollection }

func SequencedSet_Reversed__SequencedCollection(this SequencedSet) SequencedCollection { return this.Reversed__SequencedSet() }

func SequencedSet_InstanceOf(x any) bool { _, ok := x.(SequencedSet); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SequencedSet_class) } }; return ok }

func SequencedSet_Cast(x any) SequencedSet { if x == nil { return nil }; v, ok := x.(SequencedSet); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SequencedSet_class) } }; if !ok { panic(ClassCast(x, SequencedSet_class)) }; return v }
