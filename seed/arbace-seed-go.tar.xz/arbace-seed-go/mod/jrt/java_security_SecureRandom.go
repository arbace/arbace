//line java_security_SecureRandom.ae:1
package jrt

import "sync/atomic"


























func SecureRandom_New() *SecureRandom { SecureRandom_Init(); t := &SecureRandom{}; t.Ctor(); return t }
//line :30:1
func (t *SecureRandom) Ctor() { t.Random.Ctor_J(t, 0); t.F_provider = nil; t.F_secureRandomSpi = nil; t.F_digest = nil

	t.GetDefaultPRNG_Z_B1__V(false, nil)
	t.F_threadSafe = t.GetThreadSafe__Z()
}
func (t *SecureRandom) GetThreadSafe__Z() bool {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_provider == nil; if !tmp2 { tmp2 = t.F_algorithm == nil }; tmp1 = tmp2; if tmp1 { return false } else {

		var service *Provider_Service = t.F_provider.GetService_String_String__Provider_Service(Lit_1562, t.F_algorithm)
		return Boolean_ParseBoolean_String__Z(NN(service).GetAttribute_String__String(Lit_1640))
	} }
func SecureRandom_New_B1(p0 *ByteArray) *SecureRandom { SecureRandom_Init(); t := &SecureRandom{}; t.Ctor_B1(p0); return t }
//line :41:1
func (t *SecureRandom) Ctor_B1(seed *ByteArray) { t.Random.Ctor_J(t, 0); t.F_provider = nil; t.F_secureRandomSpi = nil; t.F_digest = nil

	Objects_RequireNonNull_O__O(seed.Ref())
	t.GetDefaultPRNG_Z_B1__V(true, seed)
	t.F_threadSafe = t.GetThreadSafe__Z()
}
func (t *SecureRandom) GetDefaultPRNG_Z_B1__V(setSeed bool, seed *ByteArray) {
	var prngService *Provider_Service; var prngAlgorithm *String; var i_101249 Iterator = NN(Providers_GetProviderList__ProviderList()).Providers__List().Iterator__Iterator()

L1: for i_101249.HasNext__Z() { var p Provider_I = Provider_Cast(i_101249.Next__O())
	if NN(p.GetName__String()).Equals_O__Z(Lit_0) {

		var tmp1 *String; SunEntries_Init(); tmp1 = SunEntries_DEF_SECURE_RANDOM_ALGO; prngAlgorithm = tmp1
		prngService = p.GetService_String_String__Provider_Service(Lit_1562, prngAlgorithm)
		break L1 } else {

			prngService = p.GetDefaultSecureRandomService__Provider_Service()
			if !(prngService == nil) { prngAlgorithm = NN(prngService).GetAlgorithm__String(); break L1 } } }
	if prngService == nil {

		prngAlgorithm = Lit_1641
		t.F_secureRandomSpi = Sun_SecureRandom_New()
		t.F_provider = Providers_GetSunProvider__Provider() } else { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

			t.F_secureRandomSpi = SecureRandomSpi_Cast(NN(prngService).NewInstance_O__O(nil))
			t.F_provider = NN(prngService).GetProvider__Provider(); return nil }()
//line :64:1
			if tmp2 != nil { if NoSuchAlgorithmException_InstanceOf(tmp2) { var nsae *NoSuchAlgorithmException = NoSuchAlgorithmException_Cast(tmp2)


				panic(Thrown(RuntimeException_New_Throwable(Up_NoSuchAlgorithmException_Throwable(nsae)))) } else {
//line :64:1
					panic(tmp2)
				}
			}
		}
	if setSeed { t.F_secureRandomSpi.EngineSetSeed_B1__V(seed) }
	if t.GetClass__Class() == SecureRandom_class { t.F_algorithm = prngAlgorithm
	} }
func SecureRandom_New_SecureRandomSpi_Provider(p0 SecureRandomSpi_I, p1 Provider_I) *SecureRandom { SecureRandom_Init(); t := &SecureRandom{}; t.Ctor_SecureRandomSpi_Provider(p0, p1); return t }
//line :71:1
func (t *SecureRandom) Ctor_SecureRandomSpi_Provider(secureRandomSpi SecureRandomSpi_I, provider Provider_I) { panic(A2g_NotTranslated("java.security.SecureRandom.<init>(Ljava/security/SecureRandomSpi;Ljava/security/Provider;)V")) }


func SecureRandom_New_SecureRandomSpi_Provider_String(p0 SecureRandomSpi_I, p1 Provider_I, p2 *String) *SecureRandom { SecureRandom_Init(); t := &SecureRandom{}; t.Ctor_SecureRandomSpi_Provider_String(p0, p1, p2); return t }
//line :74:1
func (t *SecureRandom) Ctor_SecureRandomSpi_Provider_String(secureRandomSpi SecureRandomSpi_I, provider Provider_I, algorithm *String) { t.Random.Ctor_J(t, 0); t.F_provider = nil; t.F_secureRandomSpi = nil; t.F_digest = nil

	t.F_secureRandomSpi = secureRandomSpi
	t.F_provider = provider
	t.F_algorithm = algorithm
	t.F_threadSafe = t.GetThreadSafe__Z()
	var tmp1 bool; var tmp2 bool; tmp2 = !SecureRandom_skipDebug; if tmp2 { tmp2 = !(SecureRandom_pdebug == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp3 *Debug = SecureRandom_pdebug; NN(tmp3).Println_String__V(Concat(Lit_1639, algorithm, Lit_1541, t.GetProviderName__String()))
	}
}
func (t *SecureRandom) GetProviderName__String() *String {
	if t.F_provider == nil { return Lit_1547 } else { return t.F_provider.GetName__String()
	} }
func SecureRandom_GetInstance_String__SecureRandom(algorithm *String) *SecureRandom { SecureRandom_Init()
	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String__GetInstance_Instance(Lit_1562, SecureRandomSpi_class, algorithm); var tmp1 SecureRandomSpi_I = SecureRandomSpi_Cast(instance.F_impl)
	return SecureRandom_New_SecureRandomSpi_Provider_String(tmp1, instance.F_provider, algorithm)
}
func SecureRandom_GetInstance_String_String__SecureRandom(algorithm, provider *String) *SecureRandom { SecureRandom_Init()

	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String_String__GetInstance_Instance(Lit_1562, SecureRandomSpi_class, algorithm, provider); var tmp1 SecureRandomSpi_I = SecureRandomSpi_Cast(instance.F_impl)
	return SecureRandom_New_SecureRandomSpi_Provider_String(tmp1, instance.F_provider, algorithm)
}
func SecureRandom_GetInstance_String_Provider__SecureRandom(algorithm *String, provider Provider_I) *SecureRandom { SecureRandom_Init()

	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String_Provider__GetInstance_Instance(Lit_1562, SecureRandomSpi_class, algorithm, provider); var tmp1 SecureRandomSpi_I = SecureRandomSpi_Cast(instance.F_impl)
	return SecureRandom_New_SecureRandomSpi_Provider_String(tmp1, instance.F_provider, algorithm)
}
func SecureRandom_GetInstance_String_SecureRandomParameters__SecureRandom(algorithm *String, params SecureRandomParameters) *SecureRandom { SecureRandom_Init()

	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	if params == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1642))) }
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String_O__GetInstance_Instance(Lit_1562, SecureRandomSpi_class, algorithm, params); var tmp1 SecureRandomSpi_I = SecureRandomSpi_Cast(instance.F_impl)
	return SecureRandom_New_SecureRandomSpi_Provider_String(tmp1, instance.F_provider, algorithm)
}
func SecureRandom_GetInstance_String_SecureRandomParameters_String__SecureRandom(algorithm *String, params SecureRandomParameters, provider *String) *SecureRandom { SecureRandom_Init()


	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	if params == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1642))) }
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String_O_String__GetInstance_Instance(Lit_1562, SecureRandomSpi_class, algorithm, params, provider); var tmp1 SecureRandomSpi_I = SecureRandomSpi_Cast(instance.F_impl)




	return SecureRandom_New_SecureRandomSpi_Provider_String(tmp1, instance.F_provider, algorithm)
}
func SecureRandom_GetInstance_String_SecureRandomParameters_Provider__SecureRandom(algorithm *String, params SecureRandomParameters, provider Provider_I) *SecureRandom { SecureRandom_Init()


	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	if params == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1642))) }
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String_O_Provider__GetInstance_Instance(Lit_1562, SecureRandomSpi_class, algorithm, params, provider); var tmp1 SecureRandomSpi_I = SecureRandomSpi_Cast(instance.F_impl)




	return SecureRandom_New_SecureRandomSpi_Provider_String(tmp1, instance.F_provider, algorithm)
}
func (t *SecureRandom) GetProvider__Provider() Provider_I { return t.F_provider }

func (t *SecureRandom) GetAlgorithm__String() *String {
	return Objects_ToString_O_String__String(t.F_algorithm.Ref(), Lit_1643)
}
func (t *SecureRandom) ToString__String() *String { return t.F_secureRandomSpi.ToString__String() }

func (t *SecureRandom) GetParameters__SecureRandomParameters() SecureRandomParameters {
	return t.F_secureRandomSpi.EngineGetParameters__SecureRandomParameters()
}
func (t *SecureRandom) SetSeed_B1__V(seed *ByteArray) {
	Objects_RequireNonNull_O__O(seed.Ref())
	if t.F_threadSafe {
		t.F_secureRandomSpi.EngineSetSeed_B1__V(seed) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_secureRandomSpi.EngineSetSeed_B1__V(seed) }()
		} }
func (t *SecureRandom) SetSeed_J__V(seed int64) {
	if seed == 0 { } else { t.SetSeed_B1__V(SecureRandom_LongToByteArray_J__B1(seed))
	} }
func (t *SecureRandom) NextBytes_B1__V(bytes *ByteArray) {
	Objects_RequireNonNull_O__O(bytes.Ref())
	if t.F_threadSafe {
		t.F_secureRandomSpi.EngineNextBytes_B1__V(bytes) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_secureRandomSpi.EngineNextBytes_B1__V(bytes) }()
		} }
func (t *SecureRandom) NextBytes_B1_SecureRandomParameters__V(bytes *ByteArray, params SecureRandomParameters) {
	if params == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1642))) }
	Objects_RequireNonNull_O__O(bytes.Ref())
	if t.F_threadSafe {
		t.F_secureRandomSpi.EngineNextBytes_B1_SecureRandomParameters__V(bytes, params) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_secureRandomSpi.EngineNextBytes_B1_SecureRandomParameters__V(bytes, params) }()
		} }
func (t *SecureRandom) Next_I__I(numBits int32) int32 {
	var numBytes int32 = (numBits + 7) / 8; var b *ByteArray = NewByteArray(numBytes)
	var next int32 = 0

	t.NextBytes_B1__V(b)
	var i int32 = 0; L1: for {
		if i < numBytes {
			next = next<<8 + int32(b.A[i])&255
			i = i + 1; continue L1 }
//line :172:1
		break L1
	}


	return int32(uint32(next) >> ((numBytes*8 - numBits) & 31))
}



func (t *SecureRandom) NextLong__J() int64 {
	var b *ByteArray = NewByteArray(8); t.NextBytes_B1__V(b); return Jdk_ByteArray_GetLong_B1_I__J(b, 0)
}
func SecureRandom_GetSeed_I__B1(numBytes int32) *ByteArray { SecureRandom_Init()
	var seedGen *SecureRandom = SecureRandom_seedGenerator.Load()
	if seedGen == nil { seedGen = SecureRandom_New(); SecureRandom_seedGenerator.Store(seedGen) }
	return NN(seedGen).GenerateSeed_I__B1(numBytes)
}
func (t *SecureRandom) GenerateSeed_I__B1(numBytes int32) *ByteArray {
	if numBytes < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1644))) }
	if t.F_threadSafe {
		return t.F_secureRandomSpi.EngineGenerateSeed_I__B1(numBytes) } else {
			var tmp1 *ByteArray; var tmp2 any = t; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_secureRandomSpi.EngineGenerateSeed_I__B1(numBytes) }(); return tmp1
		} }
func SecureRandom_LongToByteArray_J__B1(l int64) *ByteArray { SecureRandom_Init()
	var retVal *ByteArray = NewByteArray(8); var i int32 = 0
L1: for {
	if i < 8 {
		retVal.A[i] = int8(l)
		l = l >> 8
		i = i + 1; continue L1 }
//line :197:1
	break L1 }
//line :196:1
	return retVal
}










func SecureRandom_GetInstanceStrong__SecureRandom() *SecureRandom { SecureRandom_Init()
	var property *String = Security_GetProperty_String__String(Lit_1645); var tmp1 bool; var tmp2 bool
	tmp2 = property == nil; if !tmp2 { tmp2 = NN(property).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NoSuchAlgorithmException_New_String(Lit_1646)))
	}
	var remainder *String = property
L1: for { if !(remainder == nil) {
	var m *Matcher; var tmp3 *Matcher; var tmp4 *Pattern
	SecureRandom_StrongPatternHolder_Init(); tmp4 = SecureRandom_StrongPatternHolder_pattern; m = NN(tmp4).Matcher_CharSequence__Matcher(Up_String_CharSequence(remainder)); tmp3 = m; if NN(tmp3).Matches__Z() {
		var alg *String = NN(m).Group_I__String(1); var prov *String = NN(m).Group_I__String(3); tmp5, tmp6, tmp7 := func() (ctl int32, rv *SecureRandom, exc Throwable_I) { defer Catch(&exc)


			if prov == nil { return 2, SecureRandom_GetInstance_String__SecureRandom(alg), nil } else { return 3, SecureRandom_GetInstance_String_String__SecureRandom(alg, prov), nil }; return 0, nil, nil }()
//line :219:1
		if tmp7 != nil { if NoSuchAlgorithmException_InstanceOf(tmp7) || NoSuchProviderException_InstanceOf(tmp7) { var e GeneralSecurityException_I = GeneralSecurityException_Cast(tmp7); _ = e } else { panic(tmp7) } }; switch tmp5 { case 2: { return tmp6 }; case 3: { return tmp6
		}
		}


		remainder = NN(m).Group_I__String(5) } else {
			remainder = nil }
//line :214:1
	continue L1 }; break L1
}










	panic(Thrown(NoSuchAlgorithmException_New_String(Concat(Lit_1647, property))))
}

func (t *SecureRandom) Reseed__V() {
	if t.F_threadSafe {
		t.F_secureRandomSpi.EngineReseed_SecureRandomParameters__V(nil) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_secureRandomSpi.EngineReseed_SecureRandomParameters__V(nil) }()
		} }
func (t *SecureRandom) Reseed_SecureRandomParameters__V(params SecureRandomParameters) {
	if params == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1642))) }
	if t.F_threadSafe {
		t.F_secureRandomSpi.EngineReseed_SecureRandomParameters__V(params) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_secureRandomSpi.EngineReseed_SecureRandomParameters__V(params) }()
		}
}

type SecureRandom struct{ Random; F_provider Provider_I; F_secureRandomSpi SecureRandomSpi_I; F_threadSafe bool; F_algorithm *String; F_state *ByteArray; F_digest MessageDigest_I; F_randomBytes *ByteArray; F_randomBytesUsed int32; F_counter int64 }

var SecureRandom_pdebug *Debug

var SecureRandom_skipDebug bool

var SecureRandom_seedGenerator atomic.Pointer[SecureRandom]

const SecureRandom_serialVersionUID int64 = 4940670005562187

var SecureRandom_init ClassInit

func SecureRandom_Init() { if !SecureRandom_init.Done() { SecureRandom_init.Run(SecureRandom_clinit) } }

func SecureRandom_clinit() { Random_Init(); SecureRandom_pdebug = Debug_GetInstance_String_String__Debug(Lit_1533, Lit_1534)
//line :18:1
	var tmp1 bool; var tmp2 bool; tmp2 = Debug_IsOn_String__Z(Lit_1535); if tmp2 { tmp2 = !Debug_IsOn_String__Z(Lit_1638) }; tmp1 = tmp2; SecureRandom_skipDebug = tmp1
}














































































































































































































































func (t *SecureRandom) NextInt_I__I(p0 int32) int32 { return t.Impl_NextInt_I__I(t, p0) }

func (t *SecureRandom) Doubles_D_D__DoubleStream(p0, p1 float64) DoubleStream { return t.Impl_Doubles_D_D__DoubleStream(t, p0, p1) }

func (t *SecureRandom) NextDouble_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextDouble_D_D__D(t, p0, p1) }

func (t *SecureRandom) Doubles_J_D_D__DoubleStream(p0 int64, p1, p2 float64) DoubleStream { return t.Impl_Doubles_J_D_D__DoubleStream(t, p0, p1, p2) }

func (t *SecureRandom) Longs_J__LongStream(p0 int64) LongStream { return t.Impl_Longs_J__LongStream(t, p0) }

func (t *SecureRandom) NextLong_J_J__J(p0, p1 int64) int64 { return RandomGenerator_NextLong_J_J__J(t, p0, p1) }

func (t *SecureRandom) NextFloat_F__F(p0 float32) float32 { return RandomGenerator_NextFloat_F__F(t, p0) }

func (t *SecureRandom) Longs_J_J__LongStream(p0, p1 int64) LongStream { return t.Impl_Longs_J_J__LongStream(t, p0, p1) }

func (t *SecureRandom) NextLong_J__J(p0 int64) int64 { return RandomGenerator_NextLong_J__J(t, p0) }

func (t *SecureRandom) Ints_J_I_I__IntStream(p0 int64, p1, p2 int32) IntStream { return t.Impl_Ints_J_I_I__IntStream(t, p0, p1, p2) }

func (t *SecureRandom) NextDouble__D() float64 { return t.Impl_NextDouble__D(t) }

func (t *SecureRandom) Ints_I_I__IntStream(p0, p1 int32) IntStream { return t.Impl_Ints_I_I__IntStream(t, p0, p1) }

func (t *SecureRandom) NextInt_I_I__I(p0, p1 int32) int32 { return RandomGenerator_NextInt_I_I__I(t, p0, p1) }

func (t *SecureRandom) EquiDoubles_D_D_Z_Z__DoubleStream(p0, p1 float64, p2, p3 bool) DoubleStream { return RandomGenerator_EquiDoubles_D_D_Z_Z__DoubleStream(t, p0, p1, p2, p3) }

func (t *SecureRandom) NextBoolean__Z() bool { return t.Impl_NextBoolean__Z(t) }

func (t *SecureRandom) NextGaussian__D() float64 { return t.Impl_NextGaussian__D(t) }

func (t *SecureRandom) Ints__IntStream() IntStream { return t.Impl_Ints__IntStream(t) }

func (t *SecureRandom) NextExponential__D() float64 { return RandomGenerator_NextExponential__D(t) }

func (t *SecureRandom) IsDeprecated__Z() bool { return RandomGenerator_IsDeprecated__Z(t) }

func (t *SecureRandom) Doubles_J__DoubleStream(p0 int64) DoubleStream { return t.Impl_Doubles_J__DoubleStream(t, p0) }

func (t *SecureRandom) NextFloat_F_F__F(p0, p1 float32) float32 { return RandomGenerator_NextFloat_F_F__F(t, p0, p1) }

func (t *SecureRandom) Ints_J__IntStream(p0 int64) IntStream { return t.Impl_Ints_J__IntStream(t, p0) }

func (t *SecureRandom) NextFloat__F() float32 { return t.Impl_NextFloat__F(t) }

func (t *SecureRandom) Longs_J_J_J__LongStream(p0, p1, p2 int64) LongStream { return t.Impl_Longs_J_J_J__LongStream(t, p0, p1, p2) }

func (t *SecureRandom) Doubles__DoubleStream() DoubleStream { return t.Impl_Doubles__DoubleStream(t) }

func (t *SecureRandom) NextGaussian_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextGaussian_D_D__D(t, p0, p1) }

func (t *SecureRandom) NextDouble_D__D(p0 float64) float64 { return RandomGenerator_NextDouble_D__D(t, p0) }

func (t *SecureRandom) Longs__LongStream() LongStream { return t.Impl_Longs__LongStream(t) }

func (t *SecureRandom) NextInt__I() int32 { return t.Impl_NextInt__I(t) }

func (t *SecureRandom) Ref() any { if t == nil { return nil }; return t }

func (t *SecureRandom) GetClass__Class() *Class { return SecureRandom_class }

func (t *SecureRandom) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SecureRandom) CloneShallow() any { panic(CloneNotSupported(t)) }

func SecureRandom_InstanceOf(x any) bool { _, ok := x.(*SecureRandom); return ok }

func SecureRandom_Cast(x any) *SecureRandom { if x == nil { return nil }; v, ok := x.(*SecureRandom); if !ok { panic(ClassCast(x, SecureRandom_class)) }; return v }



type SecureRandom_StrongPatternHolder struct{ Object }

var SecureRandom_StrongPatternHolder_pattern *Pattern

var SecureRandom_StrongPatternHolder_init ClassInit

func SecureRandom_StrongPatternHolder_Init() { if !SecureRandom_StrongPatternHolder_init.Done() { SecureRandom_StrongPatternHolder_init.Run(SecureRandom_StrongPatternHolder_clinit) } }

func SecureRandom_StrongPatternHolder_clinit() { SecureRandom_StrongPatternHolder_pattern = Pattern_Compile_String__Pattern(Lit_1648) }

func SecureRandom_StrongPatternHolder_New() *SecureRandom_StrongPatternHolder { SecureRandom_StrongPatternHolder_Init(); t := &SecureRandom_StrongPatternHolder{}; t.Ctor(); return t }

func (t *SecureRandom_StrongPatternHolder) Ctor() {}

func (t *SecureRandom_StrongPatternHolder) Ref() any { if t == nil { return nil }; return t }

func (t *SecureRandom_StrongPatternHolder) GetClass__Class() *Class { return SecureRandom_StrongPatternHolder_class }

func (t *SecureRandom_StrongPatternHolder) ToString__String() *String { return Object_toString(t) }

func (t *SecureRandom_StrongPatternHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SecureRandom_StrongPatternHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func SecureRandom_StrongPatternHolder_InstanceOf(x any) bool { _, ok := x.(*SecureRandom_StrongPatternHolder); return ok }

func SecureRandom_StrongPatternHolder_Cast(x any) *SecureRandom_StrongPatternHolder { if x == nil { return nil }; v, ok := x.(*SecureRandom_StrongPatternHolder); if !ok { panic(ClassCast(x, SecureRandom_StrongPatternHolder_class)) }; return v }
