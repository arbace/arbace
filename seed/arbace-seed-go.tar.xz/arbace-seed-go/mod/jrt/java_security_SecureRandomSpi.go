//line java_security_SecureRandomSpi.ae:1
package jrt










func (t *SecureRandomSpi) Ctor(this SecureRandomSpi_I) {}

func (t *SecureRandomSpi) Ctor_SecureRandomParameters(this SecureRandomSpi_I, params SecureRandomParameters) { panic(A2g_NotTranslated("java.security.SecureRandomSpi.<init>(Ljava/security/SecureRandomParameters;)V")) }





func (t *SecureRandomSpi) Impl_EngineNextBytes_B1_SecureRandomParameters__V(this SecureRandomSpi_I, bytes *ByteArray, params SecureRandomParameters) {
	panic(Thrown(UnsupportedOperationException_New()))
}


func (t *SecureRandomSpi) Impl_EngineReseed_SecureRandomParameters__V(this SecureRandomSpi_I, params SecureRandomParameters) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *SecureRandomSpi) Impl_EngineGetParameters__SecureRandomParameters(this SecureRandomSpi_I) SecureRandomParameters { return nil }


func (t *SecureRandomSpi) Impl_ToString__String(this SecureRandomSpi_I) *String {
	return NN(this.GetClass__Class()).GetSimpleName__String()
}


type SecureRandomSpi struct{ Object }

type SecureRandomSpi_I interface{ Object_I; Serializable; Self_SecureRandomSpi() *SecureRandomSpi; EngineSetSeed_B1__V(p0 *ByteArray); EngineNextBytes_B1__V(p0 *ByteArray); EngineNextBytes_B1_SecureRandomParameters__V(p0 *ByteArray, p1 SecureRandomParameters); EngineGenerateSeed_I__B1(p0 int32) *ByteArray; EngineReseed_SecureRandomParameters__V(p0 SecureRandomParameters); EngineGetParameters__SecureRandomParameters() SecureRandomParameters }

func (t *SecureRandomSpi) Self_SecureRandomSpi() *SecureRandomSpi { return t }

func (t *SecureRandomSpi) Is_Serializable() {}

const SecureRandomSpi_serialVersionUID int64 = -2991854161009191830

func SecureRandomSpi_InstanceOf(x any) bool { _, ok := x.(SecureRandomSpi_I); return ok }

func SecureRandomSpi_Cast(x any) SecureRandomSpi_I { if x == nil { return nil }; v, ok := x.(SecureRandomSpi_I); if !ok { panic(ClassCast(x, SecureRandomSpi_class)) }; return v }
