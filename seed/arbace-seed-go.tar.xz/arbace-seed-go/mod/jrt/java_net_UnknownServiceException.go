//line java_net_UnknownServiceException.ae:1
package jrt










func UnknownServiceException_New() *UnknownServiceException { t := &UnknownServiceException{}; t.Ctor(); return t }
//line :12:1
func (t *UnknownServiceException) Ctor() { t.IOException.Ctor(t) }

func UnknownServiceException_New_String(p0 *String) *UnknownServiceException { t := &UnknownServiceException{}; t.Ctor_String(p0); return t }
//line :14:1
func (t *UnknownServiceException) Ctor_String(msg *String) { t.IOException.Ctor_String(t, msg) }







type UnknownServiceException struct{ IOException }

const UnknownServiceException_serialVersionUID int64 = -4169033248853639508

func (t *UnknownServiceException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *UnknownServiceException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *UnknownServiceException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *UnknownServiceException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *UnknownServiceException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *UnknownServiceException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *UnknownServiceException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *UnknownServiceException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *UnknownServiceException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *UnknownServiceException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *UnknownServiceException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *UnknownServiceException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *UnknownServiceException) Ref() any { if t == nil { return nil }; return t }

func (t *UnknownServiceException) GetClass__Class() *Class { return UnknownServiceException_class }

func (t *UnknownServiceException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UnknownServiceException) CloneShallow() any { panic(CloneNotSupported(t)) }

func UnknownServiceException_InstanceOf(x any) bool { _, ok := x.(*UnknownServiceException); return ok }

func UnknownServiceException_Cast(x any) *UnknownServiceException { if x == nil { return nil }; v, ok := x.(*UnknownServiceException); if !ok { panic(ClassCast(x, UnknownServiceException_class)) }; return v }
