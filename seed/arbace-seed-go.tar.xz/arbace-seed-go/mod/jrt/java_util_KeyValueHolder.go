//line java_util_KeyValueHolder.ae:1
package jrt














func KeyValueHolder_New_O_O(p0, p1 any) *KeyValueHolder { t := &KeyValueHolder{}; t.Ctor_O_O(p0, p1); return t }
//line :16:1
func (t *KeyValueHolder) Ctor_O_O(k, v any) {
	t.F_key = Objects_RequireNonNull_O__O(k)
	t.F_value = Objects_RequireNonNull_O__O(v)
}
func (t *KeyValueHolder) GetKey__O() any { return t.F_key }

func (t *KeyValueHolder) GetValue__O() any { return t.F_value }

func (t *KeyValueHolder) SetValue_O__O(value any) any {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_2737)))
}
func (t *KeyValueHolder) Equals_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var tmp2 any = t.F_key
		if Equals(tmp2, e.GetKey__O()) { var tmp3 any = t.F_value; return Equals(tmp3, e.GetValue__O()) } else { return false } } else {
//line :28:1
			return false
		}
}

func (t *KeyValueHolder) HashCode__I() int32 {
	return HashCode(t.F_key) ^ HashCode(t.F_value)
}
func (t *KeyValueHolder) ToString__String() *String { return Concat(StrOfObj(t.F_key), Lit_1171, StrOfObj(t.F_value)) }



type KeyValueHolder struct{ Object; F_key, F_value any }

func (t *KeyValueHolder) Is_Map_Entry() {}

func (t *KeyValueHolder) Ref() any { if t == nil { return nil }; return t }

func (t *KeyValueHolder) GetClass__Class() *Class { return KeyValueHolder_class }

func (t *KeyValueHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *KeyValueHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func KeyValueHolder_InstanceOf(x any) bool { _, ok := x.(*KeyValueHolder); return ok }

func KeyValueHolder_Cast(x any) *KeyValueHolder { if x == nil { return nil }; v, ok := x.(*KeyValueHolder); if !ok { panic(ClassCast(x, KeyValueHolder_class)) }; return v }
