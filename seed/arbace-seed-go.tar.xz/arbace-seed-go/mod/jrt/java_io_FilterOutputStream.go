//line java_io_FilterOutputStream.ae:1
package jrt

import "sync/atomic"












func FilterOutputStream_New_OutputStream(p0 OutputStream_I) *FilterOutputStream { t := &FilterOutputStream{}; t.Ctor_OutputStream(t, p0); return t }
//line :16:1
func (t *FilterOutputStream) Ctor_OutputStream(this FilterOutputStream_I, out OutputStream_I) { t.OutputStream.Ctor(this); t.F_closeLock = Object_New(); t.F_out = out }

func (t *FilterOutputStream) Impl_Write_I__V(this FilterOutputStream_I, b int32) {
	t.F_out.Write_I__V(b)
}
func (t *FilterOutputStream) Impl_Write_B1__V(this FilterOutputStream_I, b *ByteArray) {
	this.Write_B1_I_I__V(b, 0, int32(len(b.A)))
}
func (t *FilterOutputStream) Impl_Write_B1_I_I__V(this FilterOutputStream_I, b *ByteArray, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	var i int32 = 0; L1: for {
		if i < len_ {
			this.Write_I__V(int32(b.A[off+i]))
			i = i + 1; continue L1 }
//line :26:1
		break L1
	}
}


func (t *FilterOutputStream) Impl_Flush__V(this FilterOutputStream_I) { t.F_out.Flush__V() }

func (t *FilterOutputStream) Impl_Close__V(this FilterOutputStream_I) {
	if t.F_closed.Load() { } else {
		var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); tmp2, tmp3 := func() (ctl int32, rv bool) { defer MonitorExit(tmp1); if t.F_closed.Load() { return 2, false }; t.F_closed.Store(true); return 0, false }(); _ = tmp3; switch tmp2 { case 2: { return }}
		var flushException Throwable_I; tmp5 := func() (exc Throwable_I) { defer Catch(&exc); { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

			this.Flush__V(); return nil }()
//line :37:1
			if tmp4 != nil { if true { var e Throwable_I = tmp4

				flushException = e; panic(Thrown(e)) } } }
//line :38:1
			return nil
		}()

		if flushException == nil {
			t.F_out.Close__V() } else { tmp6 := func() (exc Throwable_I) { defer Catch(&exc)

				t.F_out.Close__V(); return nil }()
//line :43:1
				if tmp6 != nil { if true { var closeException Throwable_I = tmp6


					if flushException == closeException { } else {
						closeException.AddSuppressed_Throwable__V(flushException) }
					panic(Thrown(closeException)) } } }
//line :37:1
		if tmp5 != nil { panic(tmp5)
		}
	}
}







type FilterOutputStream struct{ OutputStream; F_out OutputStream_I; F_closed atomic.Bool; F_closeLock any }

type FilterOutputStream_I interface{ OutputStream_I; Closeable; Flushable; AutoCloseable; Self_FilterOutputStream() *FilterOutputStream; Write_I__V(p0 int32); Write_B1__V(p0 *ByteArray); Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32); Flush__V(); Close__V() }

func (t *FilterOutputStream) Self_FilterOutputStream() *FilterOutputStream { return t }

func (t *FilterOutputStream) Write_I__V(p0 int32) { t.Impl_Write_I__V(t, p0) }

func (t *FilterOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *FilterOutputStream) Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_Write_B1_I_I__V(t, p0, p1, p2) }

func (t *FilterOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *FilterOutputStream) Close__V() { t.Impl_Close__V(t) }

func (t *FilterOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *FilterOutputStream) GetClass__Class() *Class { return FilterOutputStream_class }

func (t *FilterOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *FilterOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FilterOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func FilterOutputStream_InstanceOf(x any) bool { _, ok := x.(FilterOutputStream_I); return ok }

func FilterOutputStream_Cast(x any) FilterOutputStream_I { if x == nil { return nil }; v, ok := x.(FilterOutputStream_I); if !ok { panic(ClassCast(x, FilterOutputStream_class)) }; return v }
