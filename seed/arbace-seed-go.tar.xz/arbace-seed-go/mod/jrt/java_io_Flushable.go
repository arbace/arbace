//line java_io_Flushable.ae:1
package jrt






type Flushable interface{ Object_I; Is_Flushable(); Flush__V() }

func Flushable_InstanceOf(x any) bool { _, ok := x.(Flushable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Flushable_class) } }; return ok }

func Flushable_Cast(x any) Flushable { if x == nil { return nil }; v, ok := x.(Flushable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Flushable_class) } }; if !ok { panic(ClassCast(x, Flushable_class)) }; return v }
