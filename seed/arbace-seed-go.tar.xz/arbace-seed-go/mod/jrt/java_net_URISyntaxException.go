//line java_net_URISyntaxException.ae:1
package jrt












func URISyntaxException_New_String_String_I(p0, p1 *String, p2 int32) *URISyntaxException { t := &URISyntaxException{}; t.Ctor_String_String_I(p0, p1, p2); return t }
//line :14:1
func (t *URISyntaxException) Ctor_String_String_I(input, reason *String, index int32) { t.Exception.Ctor_String(t, reason)

	var tmp1 bool; var tmp2 bool; tmp2 = input == nil; if !tmp2 { tmp2 = reason == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	if index < -1 { panic(Thrown(IllegalArgumentException_New())) }
	t.F_input = input
	t.F_index = index
}
func URISyntaxException_New_String_String(p0, p1 *String) *URISyntaxException { t := &URISyntaxException{}; t.Ctor_String_String(p0, p1); return t }
//line :21:1
func (t *URISyntaxException) Ctor_String_String(input, reason *String) { t.Ctor_String_String_I(input, reason, -1) }


func (t *URISyntaxException) GetInput__String() *String { return t.F_input }

func (t *URISyntaxException) GetReason__String() *String { return t.Exception.Impl_GetMessage__String(t) }

func (t *URISyntaxException) GetIndex__I() int32 { return t.F_index }

func (t *URISyntaxException) GetMessage__String() *String {
	var sb *StringBuilder = StringBuilder_New()
	NN(sb).Append_String__StringBuilder(t.GetReason__String())
	if t.F_index > -1 { NN(sb).Append_String__StringBuilder(Lit_1418); NN(sb).Append_I__StringBuilder(t.F_index) }
	NN(sb).Append_String__StringBuilder(Lit_1157)
	NN(sb).Append_String__StringBuilder(t.F_input)
	return NN(sb).ToString__String()
}


type URISyntaxException struct{ Exception; F_input *String; F_index int32 }

const URISyntaxException_serialVersionUID int64 = 2137979680897488891

func (t *URISyntaxException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *URISyntaxException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *URISyntaxException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *URISyntaxException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *URISyntaxException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *URISyntaxException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *URISyntaxException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *URISyntaxException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *URISyntaxException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *URISyntaxException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *URISyntaxException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *URISyntaxException) Ref() any { if t == nil { return nil }; return t }

func (t *URISyntaxException) GetClass__Class() *Class { return URISyntaxException_class }

func (t *URISyntaxException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URISyntaxException) CloneShallow() any { panic(CloneNotSupported(t)) }

func URISyntaxException_InstanceOf(x any) bool { _, ok := x.(*URISyntaxException); return ok }

func URISyntaxException_Cast(x any) *URISyntaxException { if x == nil { return nil }; v, ok := x.(*URISyntaxException); if !ok { panic(ClassCast(x, URISyntaxException_class)) }; return v }
