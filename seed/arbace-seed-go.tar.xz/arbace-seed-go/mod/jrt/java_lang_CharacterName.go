//line java_lang_CharacterName.ae:1
package jrt























func CharacterName_New() *CharacterName { t := &CharacterName{}; t.Ctor(); return t }
//line :25:1
func (t *CharacterName) Ctor() { tmp9 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var dis *DataInputStream = DataInputStream_New_InputStream(InflaterInputStream_New_InputStream(CharacterName_class.GetResourceAsStream_String__InputStream(Lit_1114))); tmp7 := func() (exc Throwable_I) { defer Catch(&exc)


		{ var total int32 = NN(dis).ReadInt__I(); var bkNum int32 = NN(dis).ReadInt__I(); var cpNum int32 = NN(dis).ReadInt__I(); var cpEnd int32 = NN(dis).ReadInt__I(); var ba *ByteArray = NewByteArray(cpEnd)




			t.F_lookup = NewIntArray(bkNum * 256)
			t.F_bkIndices = NewIntArray(4352)

			t.F_strPool = NewByteArray(total - cpEnd)
			t.F_cpEntries = NewIntArray(cpNum * 3)
			t.F_hsIndices = NewIntArray(cpNum/2 | 1)
			Arrays_Fill_I1_I__V(t.F_bkIndices, -1)
			Arrays_Fill_I1_I__V(t.F_hsIndices, -1)
			NN(dis).ReadFully_B1__V(ba)
			NN(dis).ReadFully_B1__V(t.F_strPool)
			var nameOff int32 = 0
			var cpOff int32 = 0
			var cp int32 = 0
			var bk int32 = -1
			var prevBk int32 = -1
			var idx int32 = 0
			var next int32 = 0
			var hash int32 = 0
			var hsh int32 = 0
		L1: for {
			var len_ int32; var tmp1 int32
			var old_1 int32 = cpOff

			cpOff = cpOff + 1
//line :57:1
			tmp1 = old_1
//line :55:1
			len_ = int32(ba.A[tmp1]) & 255





			if len_ == 0 {

				len_ = int32(ba.A[cpOff]) & 255
				cpOff = cpOff + 1
				var tmp2 int32
				var old_2 int32 = cpOff





				cpOff = cpOff + 1
//line :71:1
				tmp2 = old_2
//line :65:1
				var tmp3 int32 = int32(ba.A[tmp2]) & 255 << 16; var tmp4 int32
				var old_3 int32 = cpOff














				cpOff = cpOff + 1
//line :80:1
				tmp4 = old_3
//line :65:1
				var tmp5 int32 = tmp3 | int32(ba.A[tmp4])&255<<8; var tmp6 int32
				var old_4 int32 = cpOff





















				cpOff = cpOff + 1
//line :87:1
				tmp6 = old_4
//line :65:1
				cp = tmp5 | int32(ba.A[tmp6])&255 } else {

























					cp = cp + 1 }
			var hi int32 = cp >> 8
			if prevBk == hi { } else {
				bk = bk + 1
				t.F_bkIndices.A[hi] = bk
				prevBk = hi }
			t.F_lookup.A[bk<<8+cp&255] = nameOff<<8 | len_


			hash = CharacterName_HashN_B1_I_I__I(t.F_strPool, nameOff, len_)
			hsh = hash & 2147483647 % int32(len(t.F_hsIndices.A))

			next = t.F_hsIndices.A[hsh]
			t.F_hsIndices.A[hsh] = idx
			idx = t.AddCp_I_I_I_I__I(idx, hash, next, cp)
			nameOff = nameOff + len_
			if cpOff < cpEnd { continue L1 }
//line :54:1
			break L1 } }
//line :27:1
		return nil }(); if tmp7 == nil { NN(dis).Close__V() }; if tmp7 != nil { if true { var t_101056 Throwable_I = tmp7; tmp8 := func() (exc Throwable_I) { defer Catch(&exc); NN(dis).Close__V(); return nil }(); if tmp8 != nil { if true { var x_101057 Throwable_I = tmp8; t_101056.AddSuppressed_Throwable__V(x_101057) } }; panic(Thrown(t_101056)) } } }
//line :25:1
	return nil }(); if
	tmp9 != nil { if Exception_InstanceOf(tmp9) { var x Exception_I = Exception_Cast(tmp9)

















































































		panic(Thrown(InternalError_New_String_Throwable(x.GetMessage__String(), x))) } else {
//line :26:1
			panic(tmp9) } } }



















































































func CharacterName_HashN_B1_I_I__I(a *ByteArray, off, len_ int32) int32 {
	return ArraysSupport_HashCode_B1_I_I_I__I(a, off, len_, 1)
}
func (t *CharacterName) AddCp_I_I_I_I__I(idx, hash, next, cp int32) int32 {
	t.F_cpEntries.A[idx] = hash
	idx = idx + 1
	t.F_cpEntries.A[idx] = next
	idx = idx + 1
	t.F_cpEntries.A[idx] = cp
	idx = idx + 1
//line :113:1
	return idx
}







func (t *CharacterName) GetCpHash_I__I(idx int32) int32 { return t.F_cpEntries.A[idx] }

func (t *CharacterName) GetCpNext_I__I(idx int32) int32 {
	return t.F_cpEntries.A[idx+1]
}
func (t *CharacterName) GetCp_I__I(idx int32) int32 {
	return t.F_cpEntries.A[idx+2]
}
func CharacterName_GetInstance__CharacterName() *CharacterName {
	var ref *SoftReference = CharacterName_refCharName; var cname *CharacterName; var tmp1 bool; var tmp2 bool

	tmp2 = ref == nil; if !tmp2 { var tmp3 *CharacterName; cname = CharacterName_Cast(NN(ref).Get__O()); tmp3 = cname; tmp2 = tmp3 == nil }; tmp1 = tmp2; if tmp1 {
		cname = CharacterName_New()
		CharacterName_refCharName = SoftReference_New_O(cname.Ref()) }
//line :131:1
	return cname
}





func (t *CharacterName) GetName_I__String(cp int32) *String {
	var off int32 = 0; var bk int32 = t.F_bkIndices.A[cp>>8]; var tmp1 bool; var tmp2 bool

	tmp2 = bk == -1; if !tmp2 {
		var tmp3 int32; off = t.F_lookup.A[bk<<8+cp&255]; tmp3 = off; tmp2 = tmp3 == 0 }
//line :141:1
	tmp1 = tmp2; if tmp1 { return nil } else {






		var result *String = String_New_B1_I_I_I(t.F_strPool, 0, int32(uint32(off)>>8), off&255); return result
	}
}
func (t *CharacterName) GetCodePoint_String__I(name *String) int32 {
	var bname *ByteArray = NN(name).GetBytes_Charset__B1(Up_ISO_8859_1_Charset(ISO_8859_1_INSTANCE)); var hsh int32 = CharacterName_HashN_B1_I_I__I(bname, 0, int32(len(bname.A))); var tmp1 *IntArray = t.F_hsIndices; var idx int32 = tmp1.A[hsh&2147483647%int32(len(t.F_hsIndices.A))]





L1: for { if !(idx == -1) {
	if t.GetCpHash_I__I(idx) == hsh {
		var cp int32 = t.GetCp_I__I(idx); var off int32 = 0; var bk int32 = t.F_bkIndices.A[cp>>8]; var tmp2 bool; var tmp3 bool


		tmp3 = !(bk == -1); if tmp3 {
			var tmp4 int32; off = t.F_lookup.A[bk<<8+cp&255]; tmp4 = off; tmp3 = !(tmp4 == 0) }
//line :163:1
		tmp2 = tmp3; if tmp2 {






			var len_ int32 = off & 255
			off = int32(uint32(off) >> 8)
			if int32(len(bname.A)) == len_ {
				var i int32 = 0
			L2: for { var tmp5 bool; var tmp6 bool; tmp6 = i < len_; if tmp6 {
				var tmp7 int32 = int32(bname.A[i]); var tmp8 *ByteArray = t.F_strPool; var tmp9 int32
				var old_5 int32 = off

				off = off + 1; tmp9 = old_5
//line :175:1
				tmp6 = tmp7 == int32(tmp8.A[tmp9]) }
//line :174:1
				tmp5 = tmp6; if tmp5 {




					i = i + 1
//line :174:1
					continue L2 }; break L2
			}




				if i == len_ { return cp } } } }
	idx = t.GetCpNext_I__I(idx)
//line :158:1
	continue L1 }; break L1 }
//line :152:1
	return -1
}































type CharacterName struct{ Object; F_strPool *ByteArray; F_lookup, F_bkIndices, F_cpEntries, F_hsIndices *IntArray }

var CharacterName_refCharName *SoftReference

func (t *CharacterName) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterName) GetClass__Class() *Class { return CharacterName_class }

func (t *CharacterName) ToString__String() *String { return Object_toString(t) }

func (t *CharacterName) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterName) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterName_InstanceOf(x any) bool { _, ok := x.(*CharacterName); return ok }

func CharacterName_Cast(x any) *CharacterName { if x == nil { return nil }; v, ok := x.(*CharacterName); if !ok { panic(ClassCast(x, CharacterName_class)) }; return v }
