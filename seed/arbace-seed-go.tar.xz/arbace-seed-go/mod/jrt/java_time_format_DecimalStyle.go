//line java_time_format_DecimalStyle.ae:1
package jrt





















func DecimalStyle_GetAvailableLocales__Set() Set { DecimalStyle_Init()
	var l *RefArray = DecimalFormatSymbols_GetAvailableLocales__Locale1(); var locales Set = HashSet_NewHashSet_I__HashSet(int32(len(l.A)))

	Collections_AddAll_Collection_O1__Z(locales, l)
//line :24:1
	return locales
}



func DecimalStyle_OfDefaultLocale__DecimalStyle() *DecimalStyle { DecimalStyle_Init()
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DecimalStyle_Of_Locale__DecimalStyle(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DecimalStyle_Of_Locale__DecimalStyle(locale *Locale) *DecimalStyle { DecimalStyle_Init()
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	var info *DecimalStyle = DecimalStyle_Cast(DecimalStyle_CACHE.Get_O__O(locale.Ref()))
	if info == nil {
		info = DecimalStyle_Create_Locale__DecimalStyle(locale)
		var existing *DecimalStyle = DecimalStyle_Cast(DecimalStyle_CACHE.PutIfAbsent_O_O__O(locale.Ref(), info.Ref()))
		if !(existing == nil) { info = existing } }
//line :34:1
	return info
}





func DecimalStyle_Create_Locale__DecimalStyle(locale *Locale) *DecimalStyle { DecimalStyle_Init()
	var oldSymbols *DecimalFormatSymbols = DecimalFormatSymbols_GetInstance_Locale__DecimalFormatSymbols(locale); var zeroDigit uint16 = NN(oldSymbols).GetZeroDigit__C(); var positiveSign uint16 = 43; var negativeSign uint16 = NN(oldSymbols).GetMinusSign__C(); var decimalSeparator uint16 = NN(oldSymbols).GetDecimalSeparator__C(); var tmp1 bool; var tmp2 bool; var tmp3 bool




	tmp3 = int32(zeroDigit) == 48; if tmp3 { tmp3 = int32(negativeSign) == 45 }; tmp2 = tmp3; if tmp2 { tmp2 = int32(decimalSeparator) == 46 }; tmp1 = tmp2; if tmp1 { return DecimalStyle_STANDARD } else {

		return DecimalStyle_New_C_C_C_C(zeroDigit, positiveSign, negativeSign, decimalSeparator)
	} }
func DecimalStyle_New_C_C_C_C(p0, p1, p2, p3 uint16) *DecimalStyle { DecimalStyle_Init(); t := &DecimalStyle{}; t.Ctor_C_C_C_C(p0, p1, p2, p3); return t }
//line :51:1
func (t *DecimalStyle) Ctor_C_C_C_C(zeroChar, positiveSignChar, negativeSignChar, decimalPointChar uint16) {

	t.F_zeroDigit = zeroChar
	t.F_positiveSign = positiveSignChar
	t.F_negativeSign = negativeSignChar
	t.F_decimalSeparator = decimalPointChar
}
func (t *DecimalStyle) GetZeroDigit__C() uint16 { return t.F_zeroDigit }

func (t *DecimalStyle) WithZeroDigit_C__DecimalStyle(zeroDigit uint16) *DecimalStyle {
	if int32(zeroDigit) == int32(t.F_zeroDigit) { return t } else {

		return DecimalStyle_New_C_C_C_C(zeroDigit, t.F_positiveSign, t.F_negativeSign, t.F_decimalSeparator)
	} }
func (t *DecimalStyle) GetPositiveSign__C() uint16 { return t.F_positiveSign }

func (t *DecimalStyle) WithPositiveSign_C__DecimalStyle(positiveSign uint16) *DecimalStyle {
	if int32(positiveSign) == int32(t.F_positiveSign) { return t } else {

		return DecimalStyle_New_C_C_C_C(t.F_zeroDigit, positiveSign, t.F_negativeSign, t.F_decimalSeparator)
	} }
func (t *DecimalStyle) GetNegativeSign__C() uint16 { return t.F_negativeSign }

func (t *DecimalStyle) WithNegativeSign_C__DecimalStyle(negativeSign uint16) *DecimalStyle {
	if int32(negativeSign) == int32(t.F_negativeSign) { return t } else {

		return DecimalStyle_New_C_C_C_C(t.F_zeroDigit, t.F_positiveSign, negativeSign, t.F_decimalSeparator)
	} }
func (t *DecimalStyle) GetDecimalSeparator__C() uint16 { return t.F_decimalSeparator }

func (t *DecimalStyle) WithDecimalSeparator_C__DecimalStyle(decimalSeparator uint16) *DecimalStyle {
	if int32(decimalSeparator) == int32(t.F_decimalSeparator) { return t } else {

		return DecimalStyle_New_C_C_C_C(t.F_zeroDigit, t.F_positiveSign, t.F_negativeSign, decimalSeparator)
	} }
func (t *DecimalStyle) ConvertToDigit_C__I(ch uint16) int32 {
	var val int32 = int32(ch) - int32(t.F_zeroDigit); var tmp1 bool; var tmp2 bool; tmp2 = val >= 0; if tmp2 { tmp2 = val <= 9 }; tmp1 = tmp2; if tmp1 { return val } else { return -1
	} }
func (t *DecimalStyle) ConvertNumberToI18N_String__String(numericText *String) *String {
	if int32(t.F_zeroDigit) == 48 { return numericText } else {

		var diff int32 = int32(t.F_zeroDigit) - 48; var array *CharArray = NN(numericText).ToCharArray__C1()
		var i int32 = 0
	L1: for {
		if i < int32(len(array.A)) {
			array.A[i] = uint16(int32(array.A[i]) + diff)
			i = i + 1; continue L1 }
//line :94:1
		break L1
	}


		return String_New_C1(array)
	} }
func (t *DecimalStyle) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if DecimalStyle_InstanceOf(tmp1) { var other *DecimalStyle = DecimalStyle_Cast(tmp1); var tmp2 int32 = int32(t.F_zeroDigit)
			if tmp2 == int32(other.F_zeroDigit) {
				var tmp3 int32 = int32(t.F_positiveSign); if tmp3 == int32(other.F_positiveSign) {
					var tmp4 int32 = int32(t.F_negativeSign); if tmp4 == int32(other.F_negativeSign) {
						var tmp5 int32 = int32(t.F_decimalSeparator); return tmp5 == int32(other.F_decimalSeparator) } else {
//line :106:1
							return false } } else {
//line :105:1
								return false
							} } else {
//line :104:1
								return false
							}
		} else {
//line :103:1
			return false
		}
	}
}






func (t *DecimalStyle) HashCode__I() int32 {
	return int32(t.F_zeroDigit) + int32(t.F_positiveSign) + int32(t.F_negativeSign) + int32(t.F_decimalSeparator)
}

func (t *DecimalStyle) ToString__String() *String {
	return Concat(Lit_2373, StrOfChar(t.F_zeroDigit), StrOfChar(t.F_positiveSign), StrOfChar(t.F_negativeSign), StrOfChar(t.F_decimalSeparator), Lit_1189)
}


type DecimalStyle struct{ Object; F_zeroDigit, F_positiveSign, F_negativeSign, F_decimalSeparator uint16 }

var DecimalStyle_STANDARD *DecimalStyle

var DecimalStyle_CACHE ConcurrentMap

var DecimalStyle_init ClassInit

func DecimalStyle_Init() { if !DecimalStyle_init.Done() { DecimalStyle_init.Run(DecimalStyle_clinit) } }

func DecimalStyle_clinit() { DecimalStyle_STANDARD = DecimalStyle_New_C_C_C_C(48, 43, 45, 46); DecimalStyle_CACHE = ConcurrentHashMap_New_I_F_I(16, 0.75, 2) }

func (t *DecimalStyle) Ref() any { if t == nil { return nil }; return t }

func (t *DecimalStyle) GetClass__Class() *Class { return DecimalStyle_class }

func (t *DecimalStyle) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DecimalStyle) CloneShallow() any { panic(CloneNotSupported(t)) }

func DecimalStyle_InstanceOf(x any) bool { _, ok := x.(*DecimalStyle); return ok }

func DecimalStyle_Cast(x any) *DecimalStyle { if x == nil { return nil }; v, ok := x.(*DecimalStyle); if !ok { panic(ClassCast(x, DecimalStyle_class)) }; return v }
