//line java_io_FileInputStream.ae:1
package jrt

import "sync/atomic"















func FileInputStream_New_String(p0 *String) *FileInputStream { t := &FileInputStream{}; t.Ctor_String(t, p0); return t }
//line :19:1
func (t *FileInputStream) Ctor_String(this FileInputStream_I, name *String) { t.InputStream.Ctor(this); t.F_closeLock = Object_New()
	if name == nil { panic(Thrown(NullPointerException_New())) }
	t.F_fd = FileDescriptor_New()
	var tmp1 *FileDescriptor = t.F_fd; NN(tmp1).Set_I__V(HostFiles_Open_String_I__I(name, 0))
	t.F_path = name
}
func FileInputStream_New_File(p0 *File) *FileInputStream { t := &FileInputStream{}; t.Ctor_File(t, p0); return t }
//line :25:1
func (t *FileInputStream) Ctor_File(this FileInputStream_I, file *File) { var tmp1 *String; if
									!(file == nil) { tmp1 = NN(file).GetPath__String() } else { tmp1 = nil }; /*line :25:1*/t.Ctor_String(this, tmp1) }


func FileInputStream_New_FileDescriptor(p0 *FileDescriptor) *FileInputStream { t := &FileInputStream{}; t.Ctor_FileDescriptor(t, p0); return t }
//line :28:1
func (t *FileInputStream) Ctor_FileDescriptor(this FileInputStream_I, fdObj *FileDescriptor) { t.InputStream.Ctor(this); t.F_closeLock = Object_New()
	if fdObj == nil { panic(Thrown(NullPointerException_New())) }
	t.F_fd = fdObj
	t.F_path = nil
}
func (t *FileInputStream) Impl_Read__I(this FileInputStream_I) int32 {
	var one *ByteArray = NewByteArray(1)
	var n int32 = 0
L1: for { n = HostFiles_Read_I_B1_I_I__I(HostFiles_Handle_FileDescriptor__I(t.F_fd), one, 0, 1); if n == 0 { continue L1 }; break L1 }
	if n < 0 { return -1 } else { return int32(one.A[0]) & 255
	} }
func (t *FileInputStream) Impl_Read_B1__I(this FileInputStream_I, b *ByteArray) int32 {
	return this.Read_B1_I_I__I(b, 0, int32(len(b.A)))
}
func (t *FileInputStream) Impl_Read_B1_I_I__I(this FileInputStream_I, b *ByteArray, off, len_ int32) int32 {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	if len_ == 0 { return 0 } else { return HostFiles_Read_I_B1_I_I__I(HostFiles_Handle_FileDescriptor__I(t.F_fd), b, off, len_)
	} }
func (t *FileInputStream) Impl_Skip_J__J(this FileInputStream_I, n int64) int64 {
	if n <= 0 { return 0 } else { return HostFiles_Skip_I_J__J(HostFiles_Handle_FileDescriptor__I(t.F_fd), n)
	} }
func (t *FileInputStream) Impl_Available__I(this FileInputStream_I) int32 {
	return HostFiles_Available_I__I(HostFiles_Handle_FileDescriptor__I(t.F_fd))
}
func (t *FileInputStream) Impl_Close__V(this FileInputStream_I) {
	var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); tmp2, tmp3 := func() (ctl int32, rv bool) { defer MonitorExit(tmp1); if t.F_closed.Load() { return 2, false }; t.F_closed.Store(true); return 0, false }(); _ = tmp3; switch tmp2 { case 2: { return }}
	NN(t.F_fd).Close__V()
}
func (t *FileInputStream) Impl_GetFD__FileDescriptor(this FileInputStream_I) *FileDescriptor { return t.F_fd }



type FileInputStream struct{ InputStream; F_fd *FileDescriptor; F_path *String; F_closeLock any; F_closed atomic.Bool }

type FileInputStream_I interface{ InputStream_I; Closeable; AutoCloseable; Self_FileInputStream() *FileInputStream; Read__I() int32; Read_B1__I(p0 *ByteArray) int32; Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; Skip_J__J(p0 int64) int64; Available__I() int32; Close__V(); GetFD__FileDescriptor() *FileDescriptor }

func (t *FileInputStream) Self_FileInputStream() *FileInputStream { return t }

func (t *FileInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *FileInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *FileInputStream) Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_Read_B1_I_I__I(t, p0, p1, p2) }

func (t *FileInputStream) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *FileInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *FileInputStream) Close__V() { t.Impl_Close__V(t) }

func (t *FileInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *FileInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *FileInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *FileInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *FileInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *FileInputStream) GetFD__FileDescriptor() *FileDescriptor { return t.Impl_GetFD__FileDescriptor(t) }

func (t *FileInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *FileInputStream) Available__I() int32 { return t.Impl_Available__I(t) }

func (t *FileInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *FileInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *FileInputStream) GetClass__Class() *Class { return FileInputStream_class }

func (t *FileInputStream) ToString__String() *String { return Object_toString(t) }

func (t *FileInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileInputStream_InstanceOf(x any) bool { _, ok := x.(FileInputStream_I); return ok }

func FileInputStream_Cast(x any) FileInputStream_I { if x == nil { return nil }; v, ok := x.(FileInputStream_I); if !ok { panic(ClassCast(x, FileInputStream_class)) }; return v }
