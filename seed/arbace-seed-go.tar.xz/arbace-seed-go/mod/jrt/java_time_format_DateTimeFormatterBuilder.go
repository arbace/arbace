//line java_time_format_DateTimeFormatterBuilder.ae:1
package jrt































































func DateTimeFormatterBuilder_GetLocalizedDateTimePattern_FormatStyle_FormatStyle_Chronology_Locale__String(dateStyle, timeStyle *FormatStyle, chrono Chronology, locale *Locale) *String { DateTimeFormatterBuilder_Init()


	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	Objects_RequireNonNull_O_String__O(chrono, Lit_2196)
	var tmp1 bool; var tmp2 bool; tmp2 = dateStyle == nil; if tmp2 { tmp2 = timeStyle == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2251))) }
	var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(JavaTimeDateTimePatternProvider_class, locale); var provider JavaTimeDateTimePatternProvider_I = adapter.GetJavaTimeDateTimePatternProvider__JavaTimeDateTimePatternProvider()

	return provider.GetJavaTimeDateTimePattern_I_I_String_Locale__String(DateTimeFormatterBuilder_ConvertStyle_FormatStyle__I(timeStyle), DateTimeFormatterBuilder_ConvertStyle_FormatStyle__I(dateStyle), chrono.GetCalendarType__String(), CalendarDataUtility_FindRegionOverride_Locale__Locale(locale))
}




func DateTimeFormatterBuilder_GetLocalizedDateTimePattern_String_Chronology_Locale__String(requestedTemplate *String, chrono Chronology, locale *Locale) *String { DateTimeFormatterBuilder_Init()

	Objects_RequireNonNull_O_String__O(requestedTemplate.Ref(), Lit_2252)
	Objects_RequireNonNull_O_String__O(chrono, Lit_2196)
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	var override *Locale = CalendarDataUtility_FindRegionOverride_Locale__Locale(locale); var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(JavaTimeDateTimePatternProvider_class, override); var provider JavaTimeDateTimePatternProvider_I = adapter.GetJavaTimeDateTimePatternProvider__JavaTimeDateTimePatternProvider()


	return provider.GetJavaTimeDateTimePattern_String_String_Locale__String(requestedTemplate, chrono.GetCalendarType__String(), override)
}
func DateTimeFormatterBuilder_ConvertStyle_FormatStyle__I(style *FormatStyle) int32 { DateTimeFormatterBuilder_Init()
	if style == nil { return -1 } else { return NN(style).Ordinal__I()
	} }
func DateTimeFormatterBuilder_New() *DateTimeFormatterBuilder { DateTimeFormatterBuilder_Init(); t := &DateTimeFormatterBuilder{}; t.Ctor(); return t }
//line :93:1
func (t *DateTimeFormatterBuilder) Ctor() { t.F_active = t; t.F_printerParsers = ArrayList_New(); t.F_valueParserIndex = -1

	t.F_parent = nil
	t.F_optional = false
}
func DateTimeFormatterBuilder_New_DateTimeFormatterBuilder_Z(p0 *DateTimeFormatterBuilder, p1 bool) *DateTimeFormatterBuilder { DateTimeFormatterBuilder_Init(); t := &DateTimeFormatterBuilder{}; t.Ctor_DateTimeFormatterBuilder_Z(p0, p1); return t }
//line :98:1
func (t *DateTimeFormatterBuilder) Ctor_DateTimeFormatterBuilder_Z(parent *DateTimeFormatterBuilder, optional bool) { t.F_active = t; t.F_printerParsers = ArrayList_New(); t.F_valueParserIndex = -1

	t.F_parent = parent
	t.F_optional = optional
}
func (t *DateTimeFormatterBuilder) ParseCaseSensitive__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	var tmp1 *DateTimeFormatterBuilder_SettingsParser; DateTimeFormatterBuilder_SettingsParser_Init(); tmp1 = DateTimeFormatterBuilder_SettingsParser_SENSITIVE; t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_SettingsParser_DateTimeFormatterBuilder_DateTimePrinterParser(tmp1))
//line :103:1
	return t
}


func (t *DateTimeFormatterBuilder) ParseCaseInsensitive__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	var tmp1 *DateTimeFormatterBuilder_SettingsParser; DateTimeFormatterBuilder_SettingsParser_Init(); tmp1 = DateTimeFormatterBuilder_SettingsParser_INSENSITIVE; t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_SettingsParser_DateTimeFormatterBuilder_DateTimePrinterParser(tmp1))
//line :107:1
	return t
}


func (t *DateTimeFormatterBuilder) ParseStrict__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	var tmp1 *DateTimeFormatterBuilder_SettingsParser; DateTimeFormatterBuilder_SettingsParser_Init(); tmp1 = DateTimeFormatterBuilder_SettingsParser_STRICT; t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_SettingsParser_DateTimeFormatterBuilder_DateTimePrinterParser(tmp1))
//line :111:1
	return t
}


func (t *DateTimeFormatterBuilder) ParseLenient__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	var tmp1 *DateTimeFormatterBuilder_SettingsParser; DateTimeFormatterBuilder_SettingsParser_Init(); tmp1 = DateTimeFormatterBuilder_SettingsParser_LENIENT; t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_SettingsParser_DateTimeFormatterBuilder_DateTimePrinterParser(tmp1))
//line :115:1
	return t
}


func (t *DateTimeFormatterBuilder) ParseDefaulting_TemporalField_J__DateTimeFormatterBuilder(field TemporalField, value int64) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_DefaultValueParser_New_TemporalField_J(field, value))
//line :119:1
	return t
}



func (t *DateTimeFormatterBuilder) AppendValue_TemporalField__DateTimeFormatterBuilder(field TemporalField) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	var tmp1 *SignStyle; SignStyle_Init(); tmp1 = SignStyle_NORMAL; t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle(field, 1, 19, tmp1))
//line :124:1
	return t
}



func (t *DateTimeFormatterBuilder) AppendValue_TemporalField_I__DateTimeFormatterBuilder(field TemporalField, width int32) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	var tmp1 bool; var tmp2 bool; tmp2 = width < 1; if !tmp2 { tmp2 = width > 19 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2254, StrOfInt(width)))))
	}
	var pp DateTimeFormatterBuilder_NumberPrinterParser_I; var tmp3 *SignStyle; SignStyle_Init(); tmp3 = SignStyle_NOT_NEGATIVE; pp = DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle(field, width, width, tmp3)
	t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(pp)
//line :134:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(field TemporalField, minWidth, maxWidth int32, signStyle *SignStyle) *DateTimeFormatterBuilder {

	var tmp1 bool; var tmp2 bool; tmp2 = minWidth == maxWidth; if tmp2 { var tmp3 *SignStyle; SignStyle_Init(); tmp3 = SignStyle_NOT_NEGATIVE; tmp2 = signStyle == tmp3 }; tmp1 = tmp2; if tmp1 {
		return t.AppendValue_TemporalField_I__DateTimeFormatterBuilder(field, maxWidth) } else {

			Objects_RequireNonNull_O_String__O(field, Lit_2253)
			Objects_RequireNonNull_O_String__O(signStyle.Ref(), Lit_2255)
			var tmp4 bool; var tmp5 bool; tmp5 = minWidth < 1; if !tmp5 { tmp5 = minWidth > 19 }; tmp4 = tmp5; if tmp4 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2256, StrOfInt(minWidth)))))
			}

			var tmp6 bool; var tmp7 bool; tmp7 = maxWidth < 1; if !tmp7 { tmp7 = maxWidth > 19 }; tmp6 = tmp7; if tmp6 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2257, StrOfInt(maxWidth)))))
			}

			if maxWidth < minWidth {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2258, StrOfInt(maxWidth), Lit_2048, StrOfInt(minWidth)))))
			}



			var pp DateTimeFormatterBuilder_NumberPrinterParser_I = DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle(field, minWidth, maxWidth, signStyle)
			t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(pp)
//line :159:1
			return t
		}
}

func (t *DateTimeFormatterBuilder) AppendValueReduced_TemporalField_I_I_I__DateTimeFormatterBuilder(field TemporalField, width, maxWidth, baseValue int32) *DateTimeFormatterBuilder {


	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	var pp *DateTimeFormatterBuilder_ReducedPrinterParser = DateTimeFormatterBuilder_ReducedPrinterParser_New_TemporalField_I_I_I_ChronoLocalDate(field, width, maxWidth, baseValue, nil)
	t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(Up_DateTimeFormatterBuilder_ReducedPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(pp))
//line :167:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendValueReduced_TemporalField_I_I_ChronoLocalDate__DateTimeFormatterBuilder(field TemporalField, width, maxWidth int32, baseDate ChronoLocalDate) *DateTimeFormatterBuilder {


	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	Objects_RequireNonNull_O_String__O(baseDate, Lit_2259)
	var pp *DateTimeFormatterBuilder_ReducedPrinterParser = DateTimeFormatterBuilder_ReducedPrinterParser_New_TemporalField_I_I_I_ChronoLocalDate(field, width, maxWidth, 0, baseDate); t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(Up_DateTimeFormatterBuilder_ReducedPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(pp)); return t
}
func (t *DateTimeFormatterBuilder) AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(pp DateTimeFormatterBuilder_NumberPrinterParser_I) *DateTimeFormatterBuilder {
	if t.F_active.F_valueParserIndex >= 0 {
		var activeValueParser int32 = t.F_active.F_valueParserIndex; var basePP DateTimeFormatterBuilder_NumberPrinterParser_I = DateTimeFormatterBuilder_NumberPrinterParser_Cast(t.F_active.F_printerParsers.Get_I__O(activeValueParser)); var tmp1 bool; var tmp2 bool; var tmp3 int32 = pp.Self_DateTimeFormatterBuilder_NumberPrinterParser().F_minWidth


		tmp2 = tmp3 == pp.Self_DateTimeFormatterBuilder_NumberPrinterParser().F_maxWidth; if tmp2 {
			var tmp4 *SignStyle = pp.Self_DateTimeFormatterBuilder_NumberPrinterParser().F_signStyle; var tmp5 *SignStyle; SignStyle_Init(); tmp5 = SignStyle_NOT_NEGATIVE; tmp2 = tmp4 == tmp5 }
//line :183:1
		tmp1 = tmp2; if tmp1 {


			basePP = basePP.WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(pp.Self_DateTimeFormatterBuilder_NumberPrinterParser().F_maxWidth)
			t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(pp.WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser())
			t.F_active.F_valueParserIndex = activeValueParser } else {

				basePP = basePP.WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser()
				var tmp6 *DateTimeFormatterBuilder = t.F_active; tmp6.F_valueParserIndex = t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(pp) }
		t.F_active.F_printerParsers.Set_I_O__O(activeValueParser, basePP) } else {
			var tmp7 *DateTimeFormatterBuilder = t.F_active; tmp7.F_valueParserIndex = t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(pp) }
//line :178:1
	return t
}
















func (t *DateTimeFormatterBuilder) AppendFraction_TemporalField_I_I_Z__DateTimeFormatterBuilder(field TemporalField, minWidth, maxWidth int32, decimalPoint bool) *DateTimeFormatterBuilder {

	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_SECOND; if any(field) == any(tmp1.Ref()) {

		var tmp2 bool; var tmp3 bool; tmp3 = minWidth == maxWidth; if tmp3 { tmp3 = decimalPoint == false }; tmp2 = tmp3; if tmp2 {
			t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_NanosPrinterParser_New_I_I_Z(minWidth, maxWidth, decimalPoint)) } else {
				t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_NanosPrinterParser_New_I_I_Z(minWidth, maxWidth, decimalPoint)) } } else {
//line :198:1
					var tmp4 bool; var tmp5 bool




					tmp5 = minWidth == maxWidth; if tmp5 { tmp5 = decimalPoint == false }; tmp4 = tmp5
//line :198:1
					if tmp4 {





						t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_FractionPrinterParser_New_TemporalField_I_I_Z(field, minWidth, maxWidth, decimalPoint)) } else {
							t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_FractionPrinterParser_New_TemporalField_I_I_Z(field, minWidth, maxWidth, decimalPoint)) } }
//line :196:1
	return t
}










func (t *DateTimeFormatterBuilder) AppendText_TemporalField__DateTimeFormatterBuilder(field TemporalField) *DateTimeFormatterBuilder {
	var tmp1 *TextStyle; TextStyle_Init(); tmp1 = TextStyle_FULL; return t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp1)
}
func (t *DateTimeFormatterBuilder) AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field TemporalField, textStyle *TextStyle) *DateTimeFormatterBuilder {

	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	Objects_RequireNonNull_O_String__O(textStyle.Ref(), Lit_2260)
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_TextPrinterParser_New_TemporalField_TextStyle_DateTimeTextProvider(field, textStyle, DateTimeTextProvider_GetInstance__DateTimeTextProvider()))
//line :211:1
	return t
}





func (t *DateTimeFormatterBuilder) AppendText_TemporalField_Map__DateTimeFormatterBuilder(field TemporalField, textLookup Map) *DateTimeFormatterBuilder {

	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	Objects_RequireNonNull_O_String__O(textLookup, Lit_2261)
	var copy_ Map = LinkedHashMap_New_Map(textLookup); var map_ Map; var tmp1 *TextStyle
	TextStyle_Init(); tmp1 = TextStyle_FULL; map_ = Collections_SingletonMap_O_O__Map(tmp1.Ref(), copy_)
//line :222:1
	var store *DateTimeTextProvider_LocaleStore = DateTimeTextProvider_LocaleStore_New_Map(map_); var provider DateTimeTextProvider_I = DateTimeFormatterBuilder_1_New_DateTimeFormatterBuilder_DateTimeTextProvider_LocaleStore(t, store); var tmp2 *TextStyle































	TextStyle_Init(); tmp2 = TextStyle_FULL; t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_TextPrinterParser_New_TemporalField_TextStyle_DateTimeTextProvider(field, tmp2, provider))
//line :222:1
	return t
}




func (t *DateTimeFormatterBuilder_1) GetText_Chronology_TemporalField_J_TextStyle_Locale__String(chrono Chronology, field TemporalField, value int64, style *TextStyle, locale *Locale) *String {




	return NN(t.F_val_store).GetText_J_TextStyle__String(value, style)
}
func (t *DateTimeFormatterBuilder_1) GetText_TemporalField_J_TextStyle_Locale__String(field TemporalField, value int64, style *TextStyle, locale *Locale) *String {




	return NN(t.F_val_store).GetText_J_TextStyle__String(value, style)
}
func (t *DateTimeFormatterBuilder_1) GetTextIterator_Chronology_TemporalField_TextStyle_Locale__Iterator(chrono Chronology, field TemporalField, style *TextStyle, locale *Locale) Iterator {




	return NN(t.F_val_store).GetTextIterator_TextStyle__Iterator(style)
}
func (t *DateTimeFormatterBuilder_1) GetTextIterator_TemporalField_TextStyle_Locale__Iterator(field TemporalField, style *TextStyle, locale *Locale) Iterator {



	return NN(t.F_val_store).GetTextIterator_TextStyle__Iterator(style)
}


func (t *DateTimeFormatterBuilder) AppendInstant__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_InstantPrinterParser_New_I(-2))
//line :257:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendInstant_I__DateTimeFormatterBuilder(fractionalDigits int32) *DateTimeFormatterBuilder {
	var tmp1 bool; var tmp2 bool; tmp2 = fractionalDigits < -1; if !tmp2 { tmp2 = fractionalDigits > 9 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2262, StrOfInt(fractionalDigits)))))
	}

	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_InstantPrinterParser_New_I(fractionalDigits))
//line :261:1
	return t
}






func (t *DateTimeFormatterBuilder) AppendOffsetId__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	var tmp1 *DateTimeFormatterBuilder_OffsetIdPrinterParser; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp1 = DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_Z; t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_OffsetIdPrinterParser_DateTimeFormatterBuilder_DateTimePrinterParser(tmp1))
//line :269:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendOffset_String_String__DateTimeFormatterBuilder(pattern, noOffsetText *String) *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_OffsetIdPrinterParser_New_String_String(pattern, noOffsetText))
//line :273:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendLocalizedOffset_TextStyle__DateTimeFormatterBuilder(style *TextStyle) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(style.Ref(), Lit_2263)
	var tmp1 bool; var tmp2 bool; var tmp3 *TextStyle; TextStyle_Init(); tmp3 = TextStyle_FULL; tmp2 = !(style == tmp3); if tmp2 { var tmp4 *TextStyle; TextStyle_Init(); tmp4 = TextStyle_SHORT; tmp2 = !(style == tmp4) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2264))) }
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_New_TextStyle(style))
//line :277:1
	return t
}





func (t *DateTimeFormatterBuilder) AppendZoneId__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ZoneIdPrinterParser_New_TemporalQuery_String(TemporalQueries_ZoneId__TemporalQuery(), Lit_2265))
//line :284:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendZoneRegionId__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ZoneIdPrinterParser_New_TemporalQuery_String(DateTimeFormatterBuilder_QUERY_REGION_ONLY, Lit_2266))
//line :288:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendZoneOrOffsetId__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ZoneIdPrinterParser_New_TemporalQuery_String(TemporalQueries_Zone__TemporalQuery(), Lit_2267))
//line :292:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendZoneText_TextStyle__DateTimeFormatterBuilder(textStyle *TextStyle) *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ZoneTextPrinterParser_New_TextStyle_Set_Z(textStyle, nil, false))
//line :296:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendZoneText_TextStyle_Set__DateTimeFormatterBuilder(textStyle *TextStyle, preferredZones Set) *DateTimeFormatterBuilder {

	Objects_RequireNonNull_O_String__O(preferredZones, Lit_2268)
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ZoneTextPrinterParser_New_TextStyle_Set_Z(textStyle, preferredZones, false))
//line :300:1
	return t
}




func (t *DateTimeFormatterBuilder) AppendGenericZoneText_TextStyle__DateTimeFormatterBuilder(textStyle *TextStyle) *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ZoneTextPrinterParser_New_TextStyle_Set_Z(textStyle, nil, true))
//line :306:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendGenericZoneText_TextStyle_Set__DateTimeFormatterBuilder(textStyle *TextStyle, preferredZones Set) *DateTimeFormatterBuilder {

	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ZoneTextPrinterParser_New_TextStyle_Set_Z(textStyle, preferredZones, true))
//line :310:1
	return t
}



func (t *DateTimeFormatterBuilder) AppendChronologyId__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ChronoPrinterParser_New_TextStyle(nil))
//line :315:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendChronologyText_TextStyle__DateTimeFormatterBuilder(textStyle *TextStyle) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(textStyle.Ref(), Lit_2260)
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_ChronoPrinterParser_New_TextStyle(textStyle))
//line :319:1
	return t
}



func (t *DateTimeFormatterBuilder) AppendLocalized_FormatStyle_FormatStyle__DateTimeFormatterBuilder(dateStyle, timeStyle *FormatStyle) *DateTimeFormatterBuilder {

	var tmp1 bool; var tmp2 bool; tmp2 = dateStyle == nil; if tmp2 { tmp2 = timeStyle == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2269))) }
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_LocalizedPrinterParser_New_FormatStyle_FormatStyle(dateStyle, timeStyle))
//line :324:1
	return t
}








func (t *DateTimeFormatterBuilder) AppendLocalized_String__DateTimeFormatterBuilder(requestedTemplate *String) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(requestedTemplate.Ref(), Lit_2252)
	if NN(NN(DateTimeFormatterBuilder_VALID_TEMPLATE_PATTERN).Matcher_CharSequence__Matcher(Up_String_CharSequence(requestedTemplate))).Matches__Z() { } else {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2270, requestedTemplate))))
	}
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_LocalizedPrinterParser_New_String(requestedTemplate))
//line :334:1
	return t
}






func (t *DateTimeFormatterBuilder) AppendLiteral_C__DateTimeFormatterBuilder(literal uint16) *DateTimeFormatterBuilder {
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_CharLiteralPrinterParser_New_C(literal))
//line :342:1
	return t
}


func (t *DateTimeFormatterBuilder) AppendLiteral_String__DateTimeFormatterBuilder(literal *String) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(literal.Ref(), Lit_2271)
	if NN(literal).IsEmpty__Z() { } else {
		if NN(literal).Length__I() == 1 {
			t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_CharLiteralPrinterParser_New_C(NN(literal).CharAt_I__C(0))) } else {
				t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_StringLiteralPrinterParser_New_String(literal)) } }
//line :346:1
	return t
}






func (t *DateTimeFormatterBuilder) AppendDayPeriodText_TextStyle__DateTimeFormatterBuilder(style *TextStyle) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(style.Ref(), Lit_2263)
	switch NN(style).F_ordinal { case 1:
		var tmp1 *TextStyle; TextStyle_Init(); tmp1 = TextStyle_FULL; style = tmp1; case 3:
		var tmp2 *TextStyle; TextStyle_Init(); tmp2 = TextStyle_SHORT; style = tmp2; case 5:
		var tmp3 *TextStyle; TextStyle_Init(); tmp3 = TextStyle_NARROW; style = tmp3; default:}
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(DateTimeFormatterBuilder_DayPeriodPrinterParser_New_TextStyle(style))
//line :354:1
	return t
}







func (t *DateTimeFormatterBuilder) Append_DateTimeFormatter__DateTimeFormatterBuilder(formatter *DateTimeFormatter) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_CompositePrinterParser_DateTimeFormatterBuilder_DateTimePrinterParser(NN(formatter).ToPrinterParser_Z__DateTimeFormatterBuilder_CompositePrinterParser(false)))
//line :363:1
	return t
}



func (t *DateTimeFormatterBuilder) AppendOptional_DateTimeFormatter__DateTimeFormatterBuilder(formatter *DateTimeFormatter) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_CompositePrinterParser_DateTimeFormatterBuilder_DateTimePrinterParser(NN(formatter).ToPrinterParser_Z__DateTimeFormatterBuilder_CompositePrinterParser(true)))
//line :368:1
	return t
}



func (t *DateTimeFormatterBuilder) AppendPattern_String__DateTimeFormatterBuilder(pattern *String) *DateTimeFormatterBuilder {
	Objects_RequireNonNull_O_String__O(pattern.Ref(), Lit_2272)
	t.ParsePattern_String__V(pattern)
//line :373:1
	return t
}



func (t *DateTimeFormatterBuilder) ParsePattern_String__V(pattern *String) {
	var pos int32 = 0
L1: for { if pos < NN(pattern).Length__I() {
	var cur uint16 = NN(pattern).CharAt_I__C(pos); var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = int32(cur) >= 65; if tmp3 { tmp3 = int32(cur) <= 90 }; tmp2 = tmp3; if !tmp2 { var tmp4 bool; tmp4 = int32(cur) >= 97; if tmp4 { tmp4 = int32(cur) <= 122 }; tmp2 = tmp4 }; tmp1 = tmp2
//line :382:1
	if tmp1 {

		var start int32; var old_1 int32 = pos; pos = pos + 1; start = old_1
	L2: for { var tmp5 bool; var tmp6 bool; tmp6 = pos < NN(pattern).Length__I(); if tmp6 { tmp6 = int32(NN(pattern).CharAt_I__C(pos)) == int32(cur) }; tmp5 = tmp6; if tmp5 {
		pos = pos + 1
//line :385:1
		continue L2 }; break L2
	}
		var count int32 = pos - start
		if int32(cur) == 112 {
			var pad int32 = 0
			if pos < NN(pattern).Length__I() {
				cur = NN(pattern).CharAt_I__C(pos)
				var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = int32(cur) >= 65; if tmp9 { tmp9 = int32(cur) <= 90 }; tmp8 = tmp9; if !tmp8 { var tmp10 bool; tmp10 = int32(cur) >= 97; if tmp10 { tmp10 = int32(cur) <= 122 }; tmp8 = tmp10 }; tmp7 = tmp8; if tmp7 {
					pad = count
					start = pos
					pos = pos + 1
				L3: for { var tmp11 bool; var tmp12 bool; tmp12 = pos < NN(pattern).Length__I(); if tmp12 { tmp12 = int32(NN(pattern).CharAt_I__C(pos)) == int32(cur) }; tmp11 = tmp12; if tmp11 {
					pos = pos + 1
//line :396:1
					continue L3 }; break L3
				}
					count = pos - start } }
			if pad == 0 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2273, pattern))))
			}

			t.PadNext_I__DateTimeFormatterBuilder(pad) }
		var field TemporalField = DateTimeFormatterBuilder_GetField_C__TemporalField(cur)
		if !(field == nil) {
			t.ParseField_C_I_TemporalField__V(cur, count, field) } else {
//line :405:1
				if int32(cur) == 122 {


					if count > 4 {

						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur))))) } else {
//line :408:1
							if count == 4 {



								var tmp13 *TextStyle; TextStyle_Init(); tmp13 = TextStyle_FULL; t.AppendZoneText_TextStyle__DateTimeFormatterBuilder(tmp13) } else {
									var tmp14 *TextStyle; TextStyle_Init(); tmp14 = TextStyle_SHORT; t.AppendZoneText_TextStyle__DateTimeFormatterBuilder(tmp14) } } } else {
//line :405:1
										if int32(cur) == 86 {










											if count == 2 { } else {
												panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2275, StrOfChar(cur)))))
											}
											t.AppendZoneId__DateTimeFormatterBuilder() } else {
//line :405:1
												if int32(cur) == 118 {















													if count == 1 {
														var tmp15 *TextStyle; TextStyle_Init(); tmp15 = TextStyle_SHORT; t.AppendGenericZoneText_TextStyle__DateTimeFormatterBuilder(tmp15) } else {
//line :421:1
															if count == 4 {

																var tmp16 *TextStyle; TextStyle_Init(); tmp16 = TextStyle_FULL; t.AppendGenericZoneText_TextStyle__DateTimeFormatterBuilder(tmp16) } else {

																	panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2276, StrOfChar(cur))))) } } } else {
//line :405:1
																		if int32(cur) == 90 {






















																			if count < 4 {
																				t.AppendOffset_String_String__DateTimeFormatterBuilder(Lit_2227, Lit_2277) } else {
//line :428:1
																					if count == 4 {

																						var tmp17 *TextStyle; TextStyle_Init(); tmp17 = TextStyle_FULL; t.AppendLocalizedOffset_TextStyle__DateTimeFormatterBuilder(tmp17) } else {
//line :428:1
																							if count == 5 {


																								t.AppendOffset_String_String__DateTimeFormatterBuilder(Lit_2278, Lit_2165) } else {

																									panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur))))) } } } } else {
//line :405:1
																										if int32(cur) == 79 {






























																											if count == 1 {
																												var tmp18 *TextStyle; TextStyle_Init(); tmp18 = TextStyle_SHORT; t.AppendLocalizedOffset_TextStyle__DateTimeFormatterBuilder(tmp18) } else {
//line :436:1
																													if count == 4 {

																														var tmp19 *TextStyle; TextStyle_Init(); tmp19 = TextStyle_FULL; t.AppendLocalizedOffset_TextStyle__DateTimeFormatterBuilder(tmp19) } else {

																															panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2279, StrOfChar(cur))))) } } } else {
//line :405:1
																																if int32(cur) == 88 {






































																																	if count > 5 {
																																		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))
																																	}
																																	var tmp20 *RefArray; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp20 = DateTimeFormatterBuilder_OffsetIdPrinterParser_PATTERNS; var tmp21 *RefArray = tmp20; var tmp22 int32 = count; var tmp23 int32

																																	if count == 1 { tmp23 = 0 } else { tmp23 = 1 }
//line :447:1
																																	t.AppendOffset_String_String__DateTimeFormatterBuilder(As[*String](tmp21.A[tmp22+tmp23]), Lit_2165) } else {
//line :405:1
																																		if int32(cur) == 120 {















































																																			if count > 5 {
																																				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))
																																			}
																																			var zero *String; if count == 1 { zero = Lit_2280 } else { if count%2 == 0 { zero = Lit_2277 } else { zero = Lit_2281
																																			}
																																			}

																																			var tmp24 *RefArray; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp24 = DateTimeFormatterBuilder_OffsetIdPrinterParser_PATTERNS; var tmp25 *RefArray = tmp24; var tmp26 int32 = count; var tmp27 int32


																																			if count == 1 { tmp27 = 0 } else { tmp27 = 1 }
//line :460:1
																																			t.AppendOffset_String_String__DateTimeFormatterBuilder(As[*String](tmp25.A[tmp26+tmp27]), zero) } else {
//line :405:1
																																				if int32(cur) == 87 {





























































																																					if count > 1 {
																																						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))
																																					}
																																					t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, count)) } else {
//line :405:1
																																						if int32(cur) == 119 {



































































																																							if count > 2 {
																																								panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))
																																							}
																																							t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, 2)) } else {
//line :405:1
																																								if int32(cur) == 89 {








































































																																									if count == 2 {
																																										t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, 2)) } else {
																																											t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, 19)) } } else {
//line :405:1
																																												if int32(cur) == 66 {












































































																																													switch count { case 1:
																																														var tmp28 *TextStyle; TextStyle_Init(); tmp28 = TextStyle_SHORT; t.AppendDayPeriodText_TextStyle__DateTimeFormatterBuilder(tmp28)
//line :482:1
																																													case 4:

																																														var tmp29 *TextStyle; TextStyle_Init(); tmp29 = TextStyle_FULL; t.AppendDayPeriodText_TextStyle__DateTimeFormatterBuilder(tmp29)
//line :482:1
																																													case 5:


																																														var tmp30 *TextStyle; TextStyle_Init(); tmp30 = TextStyle_NARROW; t.AppendDayPeriodText_TextStyle__DateTimeFormatterBuilder(tmp30)
//line :482:1
																																													default:



																																														panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2276, StrOfChar(cur)))))} } else {


																																															panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2282, StrOfChar(cur)))))
																																														} } } } } } } } } } } }
		pos = pos - 1 } else {
//line :382:1
			if int32(cur) == 39 {














































































































				var start_2 int32; var old_2 int32 = pos; pos = pos + 1; start_2 = old_2
			L4: for { if pos < NN(pattern).Length__I() {
				if int32(NN(pattern).CharAt_I__C(pos)) == 39 {
					var tmp31 bool; var tmp32 bool; tmp32 = pos+1 < NN(pattern).Length__I(); if tmp32 {
						tmp32 = int32(NN(pattern).CharAt_I__C(pos+1)) == 39 }
//line :496:1
					tmp31 = tmp32; if tmp31 {

						pos = pos + 1 } else {
							break L4 } }
				pos = pos + 1
//line :494:1
				continue L4 }; break L4
			}





				if pos >= NN(pattern).Length__I() {
					panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2283, pattern))))
				}
				var str *String = NN(pattern).Substring_I_I__String(start_2+1, pos)
				if NN(str).IsEmpty__Z() {
					t.AppendLiteral_C__DateTimeFormatterBuilder(39) } else {
						t.AppendLiteral_String__DateTimeFormatterBuilder(NN(str).Replace_CharSequence_CharSequence__String(Lit_1749, Lit_1371)) } } else {
//line :382:1
							if int32(cur) == 91 {





























































































































								t.OptionalStart__DateTimeFormatterBuilder() } else {
//line :382:1
									if int32(cur) == 93 {
































































































































										if t.F_active.F_parent == nil {
											panic(Thrown(IllegalArgumentException_New_String(Lit_2284)))
										}
										t.OptionalEnd__DateTimeFormatterBuilder() } else {
//line :382:1
											var tmp33 bool; var tmp34 bool; var tmp35 bool




































































































































											tmp35 = int32(cur) == 123; if !tmp35 { tmp35 = int32(cur) == 125 }; tmp34 = tmp35; if !tmp34 { tmp34 = int32(cur) == 35 }; tmp33 = tmp34
//line :382:1
											if tmp33 {





































































































































												panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2285, StrOfChar(cur), Lit_1371)))) } else {

													t.AppendLiteral_C__DateTimeFormatterBuilder(cur) } } } } }
	pos = pos + 1
//line :380:1
	continue L1 }; break L1
}
}










































































































































func (t *DateTimeFormatterBuilder) ParseField_C_I_TemporalField__V(cur uint16, count int32, field TemporalField) {
	var standalone bool = false
	switch int32(cur) { case 117, 121:

		if count == 2 {
			var tmp1 *LocalDate; DateTimeFormatterBuilder_ReducedPrinterParser_Init(); tmp1 = DateTimeFormatterBuilder_ReducedPrinterParser_BASE_DATE; t.AppendValueReduced_TemporalField_I_I_ChronoLocalDate__DateTimeFormatterBuilder(field, 2, 2, Up_LocalDate_ChronoLocalDate(tmp1)) } else {
//line :525:1
				if count < 4 {

					var tmp2 *SignStyle; SignStyle_Init(); tmp2 = SignStyle_NORMAL; t.AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(field, count, 19, tmp2) } else {
						var tmp3 *SignStyle; SignStyle_Init(); tmp3 = SignStyle_EXCEEDS_PAD; t.AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(field, count, 19, tmp3) } }
//line :526:1
	case 99:



		if count == 1 {
			t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, count)) } else {

				if count == 2 { panic(Thrown(IllegalArgumentException_New_String(Lit_2286))) }
				standalone = true
				switch count { case 1, 2:

					if int32(cur) == 101 {

						t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, count)) } else {
//line :537:1
							if int32(cur) == 69 {


								var tmp4 *TextStyle; TextStyle_Init(); tmp4 = TextStyle_SHORT; t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp4) } else {
//line :537:1
									if count == 1 {



										t.AppendValue_TemporalField__DateTimeFormatterBuilder(field) } else {
											t.AppendValue_TemporalField_I__DateTimeFormatterBuilder(field, 2) } } }
//line :539:1
				case 3:




					var tmp5 *TextStyle

					if standalone { TextStyle_Init(); tmp5 = TextStyle_SHORT_STANDALONE } else { TextStyle_Init(); tmp5 = TextStyle_SHORT }
//line :544:1
					t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp5)

				case 4:



					var tmp6 *TextStyle


					if standalone { TextStyle_Init(); tmp6 = TextStyle_FULL_STANDALONE } else { TextStyle_Init(); tmp6 = TextStyle_FULL }
//line :550:1
					t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp6)


				case 5:

					var tmp7 *TextStyle

					if standalone { TextStyle_Init(); tmp7 = TextStyle_NARROW_STANDALONE } else { TextStyle_Init(); tmp7 = TextStyle_NARROW }
//line :555:1
					t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp7)

				default:


					panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))} }; case 76, 113:


		standalone = true
		switch count { case 1, 2:

			if int32(cur) == 101 {

				t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, count)) } else {
//line :566:1
					if int32(cur) == 69 {


						var tmp8 *TextStyle; TextStyle_Init(); tmp8 = TextStyle_SHORT; t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp8) } else {
//line :566:1
							if count == 1 {



								t.AppendValue_TemporalField__DateTimeFormatterBuilder(field) } else {
									t.AppendValue_TemporalField_I__DateTimeFormatterBuilder(field, 2) } } }
//line :568:1
		case 3:




			var tmp9 *TextStyle

			if standalone { TextStyle_Init(); tmp9 = TextStyle_SHORT_STANDALONE } else { TextStyle_Init(); tmp9 = TextStyle_SHORT }
//line :573:1
			t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp9)

		case 4:

			var tmp10 *TextStyle

			if standalone { TextStyle_Init(); tmp10 = TextStyle_FULL_STANDALONE } else { TextStyle_Init(); tmp10 = TextStyle_FULL }
//line :577:1
			t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp10)

		case 5:

			var tmp11 *TextStyle


			if standalone { TextStyle_Init(); tmp11 = TextStyle_NARROW_STANDALONE } else { TextStyle_Init(); tmp11 = TextStyle_NARROW }
//line :581:1
			t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp11)


		default:
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))}; case 77, 81, 69, 101:

		switch count { case 1, 2:

			if int32(cur) == 101 {
				t.AppendValue_DateTimeFormatterBuilder_NumberPrinterParser__DateTimeFormatterBuilder(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(cur, count, count, count)) } else {
//line :589:1
					if int32(cur) == 69 {

						var tmp12 *TextStyle; TextStyle_Init(); tmp12 = TextStyle_SHORT; t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp12) } else {
//line :589:1
							if count == 1 {


								t.AppendValue_TemporalField__DateTimeFormatterBuilder(field) } else {
									t.AppendValue_TemporalField_I__DateTimeFormatterBuilder(field, 2) } } }
//line :590:1
		case 3:




			var tmp13 *TextStyle

			if standalone { TextStyle_Init(); tmp13 = TextStyle_SHORT_STANDALONE } else { TextStyle_Init(); tmp13 = TextStyle_SHORT }
//line :595:1
			t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp13)

		case 4:

			var tmp14 *TextStyle

			if standalone { TextStyle_Init(); tmp14 = TextStyle_FULL_STANDALONE } else { TextStyle_Init(); tmp14 = TextStyle_FULL }
//line :599:1
			t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp14)

		case 5:

			var tmp15 *TextStyle

			if standalone { TextStyle_Init(); tmp15 = TextStyle_NARROW_STANDALONE } else { TextStyle_Init(); tmp15 = TextStyle_NARROW }
//line :603:1
			t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp15)

		default:
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))}; case 97:

		if count == 1 {
			var tmp16 *TextStyle; TextStyle_Init(); tmp16 = TextStyle_SHORT; t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp16) } else {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur))))) }; case 71:

		switch count { case 1, 2, 3:
			var tmp17 *TextStyle; TextStyle_Init(); tmp17 = TextStyle_SHORT; t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp17); case 4:
			var tmp18 *TextStyle; TextStyle_Init(); tmp18 = TextStyle_FULL; t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp18); case 5:
			var tmp19 *TextStyle; TextStyle_Init(); tmp19 = TextStyle_NARROW; t.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(field, tmp19); default:
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur)))))}; case 83:
		var tmp20 *ChronoField; ChronoField_Init(); tmp20 = ChronoField_NANO_OF_SECOND; t.AppendFraction_TemporalField_I_I_Z__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp20), count, count, false); case 70:

		if count == 1 {
			t.AppendValue_TemporalField__DateTimeFormatterBuilder(field) } else {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur))))) }; case 100, 104, 72, 107, 75, 109, 115:

		if count == 1 {
			t.AppendValue_TemporalField__DateTimeFormatterBuilder(field) } else {
//line :623:1
				if count == 2 {

					t.AppendValue_TemporalField_I__DateTimeFormatterBuilder(field, count) } else {
						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur))))) } }
//line :624:1
	case 68:



		if count == 1 {
			t.AppendValue_TemporalField__DateTimeFormatterBuilder(field) } else {
//line :628:1
				var tmp21 bool; var tmp22 bool

				tmp22 = count == 2; if !tmp22 { tmp22 = count == 3 }; tmp21 = tmp22
//line :628:1
				if tmp21 {

					var tmp23 *SignStyle; SignStyle_Init(); tmp23 = SignStyle_NOT_NEGATIVE; t.AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(field, count, 3, tmp23) } else {
						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2274, StrOfChar(cur))))) } }
//line :629:1
	case 103:


		var tmp24 *SignStyle; SignStyle_Init(); tmp24 = SignStyle_NORMAL; t.AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(field, count, 19, tmp24); case 65, 110, 78:
		var tmp25 *SignStyle; SignStyle_Init(); tmp25 = SignStyle_NOT_NEGATIVE; t.AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(field, count, 19, tmp25); default:
		if count == 1 { t.AppendValue_TemporalField__DateTimeFormatterBuilder(field) } else { t.AppendValue_TemporalField_I__DateTimeFormatterBuilder(field, count)
		}} }
func DateTimeFormatterBuilder_GetField_C__TemporalField(ch uint16) TemporalField { DateTimeFormatterBuilder_Init()
	switch int32(ch) { case 71: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_ERA); case 121: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_YEAR_OF_ERA); case 117: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_YEAR); case 81: IsoFields_Init(); return IsoFields_QUARTER_OF_YEAR; case 113: IsoFields_Init(); return IsoFields_QUARTER_OF_YEAR; case 77: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_MONTH_OF_YEAR); case 76: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_MONTH_OF_YEAR); case 68: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_DAY_OF_YEAR); case 100: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_DAY_OF_MONTH); case 70: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_ALIGNED_WEEK_OF_MONTH); case 69: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_DAY_OF_WEEK); case 99: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_DAY_OF_WEEK); case 101: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_DAY_OF_WEEK); case 97: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_AMPM_OF_DAY); case 72: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_HOUR_OF_DAY); case 107: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_CLOCK_HOUR_OF_DAY); case 75: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_HOUR_OF_AMPM); case 104: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_CLOCK_HOUR_OF_AMPM); case 109: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_MINUTE_OF_HOUR); case 115: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_SECOND_OF_MINUTE); case 83: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_NANO_OF_SECOND); case 65: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_MILLI_OF_DAY); case 110: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_NANO_OF_SECOND); case 78: ChronoField_Init(); return Up_ChronoField_TemporalField(ChronoField_NANO_OF_DAY); case 103: JulianFields_Init(); return JulianFields_MODIFIED_JULIAN_DAY; default: return nil}; panic("a2g: unreachable")
}


























func (t *DateTimeFormatterBuilder) PadNext_I__DateTimeFormatterBuilder(padWidth int32) *DateTimeFormatterBuilder {
	return t.PadNext_I_C__DateTimeFormatterBuilder(padWidth, 32)
}
func (t *DateTimeFormatterBuilder) PadNext_I_C__DateTimeFormatterBuilder(padWidth int32, padChar uint16) *DateTimeFormatterBuilder {
	if padWidth < 1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2287, StrOfInt(padWidth)))))
	}
	t.F_active.F_padNextWidth = padWidth
	t.F_active.F_padNextChar = padChar
	t.F_active.F_valueParserIndex = -1
//line :668:1
	return t
}







func (t *DateTimeFormatterBuilder) OptionalStart__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	t.F_active.F_valueParserIndex = -1
	t.F_active = DateTimeFormatterBuilder_New_DateTimeFormatterBuilder_Z(t.F_active, true)
//line :677:1
	return t
}



func (t *DateTimeFormatterBuilder) OptionalEnd__DateTimeFormatterBuilder() *DateTimeFormatterBuilder {
	if t.F_active.F_parent == nil {
		panic(Thrown(IllegalStateException_New_String(Lit_2288)))
	}
	if t.F_active.F_printerParsers.Size__I() > 0 {
		var tmp1 List = t.F_active.F_printerParsers; var cpp *DateTimeFormatterBuilder_CompositePrinterParser = DateTimeFormatterBuilder_CompositePrinterParser_New_List_Z(tmp1, t.F_active.F_optional)
		t.F_active = t.F_active.F_parent
		t.AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(Up_DateTimeFormatterBuilder_CompositePrinterParser_DateTimeFormatterBuilder_DateTimePrinterParser(cpp)) } else {
			t.F_active = t.F_active.F_parent }
//line :682:1
	return t
}









func (t *DateTimeFormatterBuilder) AppendInternal_DateTimeFormatterBuilder_DateTimePrinterParser__I(pp DateTimeFormatterBuilder_DateTimePrinterParser) int32 {
	Objects_RequireNonNull_O_String__O(pp, Lit_2289)
	if t.F_active.F_padNextWidth > 0 {
		var tmp1 DateTimeFormatterBuilder_DateTimePrinterParser = pp; var tmp2 int32 = t.F_active.F_padNextWidth; pp = DateTimeFormatterBuilder_PadPrinterParserDecorator_New_DateTimeFormatterBuilder_DateTimePrinterParser_I_C(tmp1, tmp2, t.F_active.F_padNextChar)
		t.F_active.F_padNextWidth = 0
		t.F_active.F_padNextChar = 0 }
	t.F_active.F_printerParsers.Add_O__Z(pp)
	t.F_active.F_valueParserIndex = -1
	return t.F_active.F_printerParsers.Size__I() - 1
}
func (t *DateTimeFormatterBuilder) ToFormatter__DateTimeFormatter() *DateTimeFormatter {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return t.ToFormatter_Locale__DateTimeFormatter(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *DateTimeFormatterBuilder) ToFormatter_Locale__DateTimeFormatter(locale *Locale) *DateTimeFormatter {
	var tmp1 *ResolverStyle; ResolverStyle_Init(); tmp1 = ResolverStyle_SMART; return t.ToFormatter_Locale_ResolverStyle_Chronology__DateTimeFormatter(locale, tmp1, nil)
}
func (t *DateTimeFormatterBuilder) ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(resolverStyle *ResolverStyle, chrono Chronology) *DateTimeFormatter {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return t.ToFormatter_Locale_ResolverStyle_Chronology__DateTimeFormatter(Locale_GetDefault_Locale_Category__Locale(tmp1), resolverStyle, chrono)
}
func (t *DateTimeFormatterBuilder) ToFormatter_Locale_ResolverStyle_Chronology__DateTimeFormatter(locale *Locale, resolverStyle *ResolverStyle, chrono Chronology) *DateTimeFormatter {

	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
L1: for { if !(t.F_active.F_parent == nil) { t.OptionalEnd__DateTimeFormatterBuilder(); continue L1 }; break L1 }
	var pp *DateTimeFormatterBuilder_CompositePrinterParser = DateTimeFormatterBuilder_CompositePrinterParser_New_List_Z(t.F_printerParsers, false); var tmp1 *DecimalStyle
	DecimalStyle_Init(); tmp1 = DecimalStyle_STANDARD; return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(pp, locale, tmp1, resolverStyle, nil, chrono, nil)
}












func DateTimeFormatterBuilder_CompositePrinterParser_New_List_Z(p0 List, p1 bool) *DateTimeFormatterBuilder_CompositePrinterParser { t := &DateTimeFormatterBuilder_CompositePrinterParser{}; t.Ctor_List_Z(p0, p1); return t }
//line :731:1
func (t *DateTimeFormatterBuilder_CompositePrinterParser) Ctor_List_Z(printerParsers List, optional bool) { t.Ctor_DateTimeFormatterBuilder_DateTimePrinterParser1_Z(A2g_CastArray[*RefArray](printerParsers.ToArray_O1__O1(NewRefArray(DateTimeFormatterBuilder_DateTimePrinterParser_class, 0)).Ref(), DateTimeFormatterBuilder_DateTimePrinterParser_class.ArrayClass()), optional) }





func DateTimeFormatterBuilder_CompositePrinterParser_New_DateTimeFormatterBuilder_DateTimePrinterParser1_Z(p0 *RefArray, p1 bool) *DateTimeFormatterBuilder_CompositePrinterParser { t := &DateTimeFormatterBuilder_CompositePrinterParser{}; t.Ctor_DateTimeFormatterBuilder_DateTimePrinterParser1_Z(p0, p1); return t }
//line :737:1
func (t *DateTimeFormatterBuilder_CompositePrinterParser) Ctor_DateTimeFormatterBuilder_DateTimePrinterParser1_Z(printerParsers *RefArray, optional bool) {
	t.F_printerParsers = printerParsers
	t.F_optional = optional
}
func (t *DateTimeFormatterBuilder_CompositePrinterParser) WithOptional_Z__DateTimeFormatterBuilder_CompositePrinterParser(optional bool) *DateTimeFormatterBuilder_CompositePrinterParser {
	if optional == t.F_optional { return t } else { return DateTimeFormatterBuilder_CompositePrinterParser_New_DateTimeFormatterBuilder_DateTimePrinterParser1_Z(t.F_printerParsers, optional)
	} }
func (t *DateTimeFormatterBuilder_CompositePrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var length int32 = NN(buf).Length__I(); var effectiveOptional bool; var a_3 bool = optional; var b_4 bool = t.F_optional; var tmp1 bool
	tmp1 = a_3; if !tmp1 { tmp1 = b_4 }; effectiveOptional = tmp1
	var arr_101595 *RefArray = t.F_printerParsers; var len_101596 int32 = int32(len(arr_101595.A)); var i_101597 int32 = 0; for ; i_101597 < len_101596; i_101597++ { var pp DateTimeFormatterBuilder_DateTimePrinterParser = As[DateTimeFormatterBuilder_DateTimePrinterParser](arr_101595.A[i_101597])
		if pp.Format_DateTimePrintContext_StringBuilder_Z__Z(context, buf, effectiveOptional) { } else {
			NN(buf).SetLength_I__V(length)
			return true } }
//line :746:1
	return true
}






func (t *DateTimeFormatterBuilder_CompositePrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {

	if t.F_optional {

		NN(context).StartOptional__V()
		var pos int32 = position; var arr_101598 *RefArray = t.F_printerParsers; var len_101599 int32 = int32(len(arr_101598.A)); var i_101600 int32 = 0; for ; i_101600 < len_101599; i_101600++ {
			var pp DateTimeFormatterBuilder_DateTimePrinterParser = As[DateTimeFormatterBuilder_DateTimePrinterParser](arr_101598.A[i_101600])
			pos = pp.Parse_DateTimeParseContext_CharSequence_I__I(context, text, pos)
			if pos < 0 { NN(context).EndOptional_Z__V(false); return position } }
		NN(context).EndOptional_Z__V(true)
//line :759:1
		return pos


	} else {



		var arr_101601 *RefArray = t.F_printerParsers; var len_101602 int32 = int32(len(arr_101601.A)); var i_101603 int32 = 0; L2: for ; i_101603 < len_101602; i_101603++ { var pp_2 DateTimeFormatterBuilder_DateTimePrinterParser = As[DateTimeFormatterBuilder_DateTimePrinterParser](arr_101601.A[i_101603])
			position = pp_2.Parse_DateTimeParseContext_CharSequence_I__I(context, text, position)
			if position < 0 { break L2 } }
//line :765:1
		return position
	}
}



func (t *DateTimeFormatterBuilder_CompositePrinterParser) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New()
	if !(t.F_printerParsers == nil) {
		var tmp1 *String; if t.F_optional { tmp1 = Lit_1318 } else { tmp1 = Lit_1695 }; NN(buf).Append_String__StringBuilder(tmp1)
		var arr_101604 *RefArray = t.F_printerParsers; var len_101605 int32 = int32(len(arr_101604.A)); var i_101606 int32 = 0; for ; i_101606 < len_101605; i_101606++ { var pp DateTimeFormatterBuilder_DateTimePrinterParser = As[DateTimeFormatterBuilder_DateTimePrinterParser](arr_101604.A[i_101606]); NN(buf).Append_O__StringBuilder(pp) }
		var tmp2 *String; if t.F_optional { tmp2 = Lit_1189 } else { tmp2 = Lit_1176 }; NN(buf).Append_String__StringBuilder(tmp2) }
	return NN(buf).ToString__String()
}









func DateTimeFormatterBuilder_PadPrinterParserDecorator_New_DateTimeFormatterBuilder_DateTimePrinterParser_I_C(p0 DateTimeFormatterBuilder_DateTimePrinterParser, p1 int32, p2 uint16) *DateTimeFormatterBuilder_PadPrinterParserDecorator { t := &DateTimeFormatterBuilder_PadPrinterParserDecorator{}; t.Ctor_DateTimeFormatterBuilder_DateTimePrinterParser_I_C(p0, p1, p2); return t }
//line :788:1
func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) Ctor_DateTimeFormatterBuilder_DateTimePrinterParser_I_C(printerParser DateTimeFormatterBuilder_DateTimePrinterParser, padWidth int32, padChar uint16) {
	t.F_printerParser = printerParser
	t.F_padWidth = padWidth
	t.F_padChar = padChar
}
func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var preLen int32 = NN(buf).Length__I()
	if t.F_printerParser.Format_DateTimePrintContext_StringBuilder_Z__Z(context, buf, optional) == false { return false } else {

		var len_ int32 = NN(buf).Length__I() - preLen
		if len_ > t.F_padWidth {
			panic(Thrown(DateTimeException_New_String(Concat(Lit_2336, StrOfInt(len_), Lit_2337, StrOfInt(t.F_padWidth)))))
		}



		var count int32 = t.F_padWidth - len_
		if count == 0 { return true } else { if count == 1 {

			NN(buf).Insert_I_C__StringBuilder(preLen, t.F_padChar); return true } else {
				NN(buf).Insert_I_String__StringBuilder(preLen, NN(String_ValueOf_C__String(t.F_padChar)).Repeat_I__String(count)); return true
			} } } }
func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {

	var strict bool = NN(context).IsStrict__Z()
	if position > text.Length__I() { panic(Thrown(IndexOutOfBoundsException_New())) }
	if position == text.Length__I() {
		return ^position } else {
			var endPos int32 = position + t.F_padWidth
			if endPos > text.Length__I() {
				if strict { return ^position }
				endPos = text.Length__I() }
			var pos int32 = position
		L1: for { var tmp1 bool; var tmp2 bool; tmp2 = pos < endPos; if tmp2 { tmp2 = NN(context).CharEquals_C_C__Z(text.CharAt_I__C(pos), t.F_padChar) }; tmp1 = tmp2; if tmp1 {
			pos = pos + 1
//line :822:1
			continue L1 }; break L1
		}
			text = text.SubSequence_I_I__CharSequence(0, endPos)
			var resultPos int32 = t.F_printerParser.Parse_DateTimeParseContext_CharSequence_I__I(context, text, pos); var tmp3 bool; var tmp4 bool
			tmp4 = !(resultPos == endPos); if tmp4 { tmp4 = strict }; tmp3 = tmp4; if tmp3 {
				return ^(position + pos) } else {
//line :826:1
					return resultPos
				}
		}
}
func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) ToString__String() *String {
	var tmp1 DateTimeFormatterBuilder_DateTimePrinterParser = t.F_printerParser; var tmp2 int32 = t.F_padWidth; var tmp3 *String



	if int32(t.F_padChar) == 32 { tmp3 = Lit_1176 } else { tmp3 = Concat(Lit_2335, StrOfChar(t.F_padChar), Lit_1675) }
//line :831:1
	return Concat(Lit_2338, StrOfObj(tmp1), Lit_1532, StrOfInt(tmp2), tmp3)
}









func (t *DateTimeFormatterBuilder_SettingsParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool { return true }



func (t *DateTimeFormatterBuilder_SettingsParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	switch t.Ordinal__I() { case 0:
		NN(context).SetCaseSensitive_Z__V(true); case 1:
		NN(context).SetCaseSensitive_Z__V(false); case 2:
		NN(context).SetStrict_Z__V(true); case 3:
		NN(context).SetStrict_Z__V(false); default:}
//line :846:1
	return position
}






func (t *DateTimeFormatterBuilder_SettingsParser) ToString__String() *String {
	switch t.Ordinal__I() { case 0: return Lit_2349; case 1: return Lit_2350; case 2: return Lit_2351; case 3: return Lit_2352; default:




		panic(Thrown(IllegalStateException_New_String(Lit_2348)))}; panic("a2g: unreachable")
}







func DateTimeFormatterBuilder_DefaultValueParser_New_TemporalField_J(p0 TemporalField, p1 int64) *DateTimeFormatterBuilder_DefaultValueParser { t := &DateTimeFormatterBuilder_DefaultValueParser{}; t.Ctor_TemporalField_J(p0, p1); return t }
//line :869:1
func (t *DateTimeFormatterBuilder_DefaultValueParser) Ctor_TemporalField_J(field TemporalField, value int64) {
	t.F_field = field
	t.F_value = value
}
func (t *DateTimeFormatterBuilder_DefaultValueParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool { return true }



func (t *DateTimeFormatterBuilder_DefaultValueParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	if NN(context).GetParsed_TemporalField__Long(t.F_field) == nil {
		NN(context).SetParsedField_TemporalField_J_I_I__I(t.F_field, t.F_value, position, position) }
//line :877:1
	return position
}










func DateTimeFormatterBuilder_CharLiteralPrinterParser_New_C(p0 uint16) *DateTimeFormatterBuilder_CharLiteralPrinterParser { t := &DateTimeFormatterBuilder_CharLiteralPrinterParser{}; t.Ctor_C(p0); return t }
//line :889:1
func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) Ctor_C(literal uint16) {
	t.F_literal = literal
	t.F_isSpaceSeparator = Character_GetType_C__I(literal) == 12
}
func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	NN(buf).Append_C__StringBuilder(t.F_literal)
//line :893:1
	return true
}



func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var length int32 = text.Length__I()
	if position == length {
		return ^position } else {
			var ch uint16 = text.CharAt_I__C(position)
			if int32(ch) == int32(t.F_literal) { } else {
				var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = NN(context).IsCaseSensitive__Z(); if !tmp3 {
					var tmp4 bool; tmp4 = !(int32(Character_ToUpperCase_C__C(ch)) == int32(Character_ToUpperCase_C__C(t.F_literal))); if tmp4 {

						tmp4 = !(int32(Character_ToLowerCase_C__C(ch)) == int32(Character_ToLowerCase_C__C(t.F_literal))) }
//line :905:1
					tmp3 = tmp4 }
//line :904:1
				tmp2 = tmp3; if tmp2 {




					tmp2 = !t.SpaceEquals_DateTimeParseContext_C__Z(context, ch) }
//line :904:1
				tmp1 = tmp2; if tmp1 {





					return ^position } }
			return position + 1
		} }
func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) ToString__String() *String {
	if int32(t.F_literal) == 39 { return Lit_1749 } else { return Concat(Lit_1371, StrOfChar(t.F_literal), Lit_1371)
	} }
func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) SpaceEquals_DateTimeParseContext_C__Z(context *DateTimeParseContext, ch uint16) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = !NN(context).IsStrict__Z(); if tmp2 { tmp2 = t.F_isSpaceSeparator }; tmp1 = tmp2; if tmp1 {
		tmp1 = Character_GetType_C__I(ch) == 12 }
//line :917:1
	return tmp1
}






func DateTimeFormatterBuilder_StringLiteralPrinterParser_New_String(p0 *String) *DateTimeFormatterBuilder_StringLiteralPrinterParser { t := &DateTimeFormatterBuilder_StringLiteralPrinterParser{}; t.Ctor_String(p0); return t }
//line :925:1
func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) Ctor_String(literal *String) {
	t.F_literal = literal
}
func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	NN(buf).Append_String__StringBuilder(t.F_literal)
//line :928:1
	return true
}



func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var length int32 = text.Length__I(); var tmp1 bool; var tmp2 bool
	tmp2 = position > length; if !tmp2 { tmp2 = position < 0 }; tmp1 = tmp2; if tmp1 { panic(Thrown(IndexOutOfBoundsException_New())) }
	var tmp3 CharSequence = Up_String_CharSequence(t.F_literal); if NN(context).SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(text, position, tmp3, 0, NN(t.F_literal).Length__I()) == false {
		return ^position } else {
			return position + NN(t.F_literal).Length__I()
		} }
func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) ToString__String() *String {
	var converted *String = NN(t.F_literal).Replace_CharSequence_CharSequence__String(Lit_1371, Lit_1749); return Concat(Lit_1371, converted, Lit_1371)
}
















func DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle(p0 TemporalField, p1, p2 int32, p3 *SignStyle) *DateTimeFormatterBuilder_NumberPrinterParser { DateTimeFormatterBuilder_NumberPrinterParser_Init(); t := &DateTimeFormatterBuilder_NumberPrinterParser{}; t.Ctor_TemporalField_I_I_SignStyle(t, p0, p1, p2, p3); return t }
//line :959:1
func (t *DateTimeFormatterBuilder_NumberPrinterParser) Ctor_TemporalField_I_I_SignStyle(this DateTimeFormatterBuilder_NumberPrinterParser_I, field TemporalField, minWidth, maxWidth int32, signStyle *SignStyle) {

	t.F_field = field
	t.F_minWidth = minWidth
	t.F_maxWidth = maxWidth
	t.F_signStyle = signStyle
	t.F_subsequentWidth = 0
}
func DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle_I(p0 TemporalField, p1, p2 int32, p3 *SignStyle, p4 int32) *DateTimeFormatterBuilder_NumberPrinterParser { DateTimeFormatterBuilder_NumberPrinterParser_Init(); t := &DateTimeFormatterBuilder_NumberPrinterParser{}; t.Ctor_TemporalField_I_I_SignStyle_I(t, p0, p1, p2, p3, p4); return t }
//line :967:1
func (t *DateTimeFormatterBuilder_NumberPrinterParser) Ctor_TemporalField_I_I_SignStyle_I(this DateTimeFormatterBuilder_NumberPrinterParser_I, field TemporalField, minWidth, maxWidth int32, signStyle *SignStyle, subsequentWidth int32) {

	t.F_field = field
	t.F_minWidth = minWidth
	t.F_maxWidth = maxWidth
	t.F_signStyle = signStyle
	t.F_subsequentWidth = subsequentWidth
}
func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser(this DateTimeFormatterBuilder_NumberPrinterParser_I) DateTimeFormatterBuilder_NumberPrinterParser_I {
	if t.F_subsequentWidth == -1 { return this } else { return DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle_I(t.F_field, t.F_minWidth, t.F_maxWidth, t.F_signStyle, -1)
	} }
func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(this DateTimeFormatterBuilder_NumberPrinterParser_I, subsequentWidth int32) DateTimeFormatterBuilder_NumberPrinterParser_I {
	return DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle_I(t.F_field, t.F_minWidth, t.F_maxWidth, t.F_signStyle, t.F_subsequentWidth+subsequentWidth)
}




func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_Format_DateTimePrintContext_StringBuilder_Z__Z(this DateTimeFormatterBuilder_NumberPrinterParser_I, context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var valueLong *Long = NN(context).GetValue_TemporalField_Z__Long(t.F_field, optional)
	if valueLong == nil { return false } else {

		var value int64 = this.GetValue_DateTimePrintContext_J__J(context, NN(valueLong).LongValue__J()); var decimalStyle *DecimalStyle = NN(context).GetDecimalStyle__DecimalStyle(); var size int32 = DecimalDigits_StringSize_J__I(value)


		if value < 0 { size = size - 1 }
		if size > t.F_maxWidth {
			panic(Thrown(DateTimeException_New_String(Concat(Lit_2326, StrOfObj(t.F_field), Lit_2327, StrOfLong(value), Lit_2328, StrOfInt(t.F_maxWidth)))))
		}





		if value >= 0 {
			switch NN(t.F_signStyle).F_ordinal { case 4:

				var tmp1 bool; var tmp2 bool; tmp2 = t.F_minWidth < 19; if tmp2 { tmp2 = size > t.F_minWidth }; tmp1 = tmp2; if tmp1 {
					NN(buf).Append_C__StringBuilder(NN(decimalStyle).GetPositiveSign__C()) }; case 1:
				NN(buf).Append_C__StringBuilder(NN(decimalStyle).GetPositiveSign__C()); default:} } else {
					switch NN(t.F_signStyle).F_ordinal { case 0, 4, 1:
						NN(buf).Append_C__StringBuilder(NN(decimalStyle).GetNegativeSign__C()); case 3:

						panic(Thrown(DateTimeException_New_String(Concat(Lit_2326, StrOfObj(t.F_field), Lit_2327, StrOfLong(value), Lit_2329)))); default:
					}
				}



		var zeroDigit uint16 = NN(decimalStyle).GetZeroDigit__C(); var zeros int32 = t.F_minWidth - size

		if zeros > 0 { NN(buf).Repeat_I_I__StringBuilder(int32(zeroDigit), zeros) }
		var tmp3 bool; var tmp4 bool; tmp4 = int32(zeroDigit) == 48; if tmp4 { tmp4 = !(value == -9223372036854775808) }; tmp3 = tmp4; if tmp3 {
			NN(buf).Append_J__StringBuilder(Math_Abs_J__J(value)) } else {
				var str *String; if value == -9223372036854775808 { str = Lit_1841 } else {

					str = Long_ToString_J__String(Math_Abs_J__J(value)) }
				NN(buf).Append_String__StringBuilder(NN(decimalStyle).ConvertNumberToI18N_String__String(str)) }
//line :1017:1
		return true
	}
}








func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_GetValue_DateTimePrintContext_J__J(this DateTimeFormatterBuilder_NumberPrinterParser_I, context *DateTimePrintContext, value int64) int64 { return value }


func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_IsFixedWidth_DateTimeParseContext__Z(this DateTimeFormatterBuilder_NumberPrinterParser_I, context *DateTimeParseContext) bool {
	var tmp1 bool; tmp1 = t.F_subsequentWidth == -1; if !tmp1 {
		var tmp2 bool; var tmp3 bool; tmp3 = t.F_subsequentWidth > 0; if tmp3 { tmp3 = t.F_minWidth == t.F_maxWidth }; tmp2 = tmp3; if tmp2 {
			var tmp4 *SignStyle = t.F_signStyle; var tmp5 *SignStyle; SignStyle_Init(); tmp5 = SignStyle_NOT_NEGATIVE; tmp2 = tmp4 == tmp5 }
//line :1033:1
		tmp1 = tmp2 }
//line :1032:1
	return tmp1
}


func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_Parse_DateTimeParseContext_CharSequence_I__I(this DateTimeFormatterBuilder_NumberPrinterParser_I, context *DateTimeParseContext, text CharSequence, position int32) int32 {

	var length int32 = text.Length__I()
	if position == length {
		return ^position } else {
			var sign uint16 = text.CharAt_I__C(position)
			var negative bool = false
			var positive bool = false
			if int32(sign) == int32(NN(NN(context).GetDecimalStyle__DecimalStyle()).GetPositiveSign__C()) {


				var tmp1 *SignStyle = t.F_signStyle; if NN(tmp1).Parse_Z_Z_Z__Z(true, NN(context).IsStrict__Z(), t.F_minWidth == t.F_maxWidth) == false {

					return ^position }
				positive = true
				position = position + 1 } else {
//line :1044:1
					if int32(sign) == int32(NN(NN(context).GetDecimalStyle__DecimalStyle()).GetNegativeSign__C()) {









						var tmp2 *SignStyle = t.F_signStyle; if NN(tmp2).Parse_Z_Z_Z__Z(false, NN(context).IsStrict__Z(), t.F_minWidth == t.F_maxWidth) == false {

							return ^position }
						negative = true
						position = position + 1 } else {
//line :1044:1
							var tmp3 bool; var tmp4 bool; var tmp5 *SignStyle = t.F_signStyle; var tmp6 *SignStyle














							SignStyle_Init(); tmp6 = SignStyle_ALWAYS; tmp4 = tmp5 == tmp6; if tmp4 { tmp4 = NN(context).IsStrict__Z() }; tmp3 = tmp4
//line :1044:1
							if tmp3 {















								return ^position } } }
			var effMinWidth int32; var tmp7 bool; var tmp8 bool; tmp8 = NN(context).IsStrict__Z(); if !tmp8 { tmp8 = this.IsFixedWidth_DateTimeParseContext__Z(context) }; tmp7 = tmp8; if tmp7 { effMinWidth = t.F_minWidth } else { effMinWidth = 1 }; var minEndPos int32 = position + effMinWidth



			if minEndPos > length {
				return ^position } else {
					var effMaxWidth int32; var tmp9 int32; var tmp10 bool; var tmp11 bool

					tmp11 = NN(context).IsStrict__Z()
//line :1068:1
					if !tmp11 {

						tmp11 = this.IsFixedWidth_DateTimeParseContext__Z(context) }
//line :1068:1
					tmp10 = tmp11; if tmp10 { tmp9 = t.F_maxWidth } else { tmp9 = 9 }
//line :1067:1
					effMaxWidth = tmp9 + Math_Max_I_I__I(t.F_subsequentWidth, 0); var total int64 = 0; var totalBig *BigInteger
					var pos int32 = position
					var pass int32 = 0







				L1: for {
					if pass < 2 {
						var maxEndPos int32 = Math_Min_I_I__I(pos+effMaxWidth, length)
					L2: for { if pos < maxEndPos {
						var ch uint16; var tmp12 int32
						var old_5 int32 = pos
						pos = pos + 1
//line :1082:1
						tmp12 = old_5
//line :1081:1
						ch = text.CharAt_I__C(tmp12); var digit int32 = NN(NN(context).GetDecimalStyle__DecimalStyle()).ConvertToDigit_C__I(ch)




						if digit < 0 {
							pos = pos - 1
							if pos < minEndPos { return ^position }
							break L2 }
						if pos-position > 18 {

							if totalBig == nil {
								totalBig = BigInteger_ValueOf_J__BigInteger(total) }
							var tmp13 *BigInteger = totalBig; var tmp14 *BigInteger; BigInteger_Init(); tmp14 = BigInteger_TEN; totalBig = NN(NN(tmp13).Multiply_BigInteger__BigInteger(tmp14)).Add_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(int64(digit))) } else {



								total = total*10 + int64(digit) }
//line :1080:1
						continue L2 }; break L2
					}

















						var tmp15 bool; var tmp16 bool; tmp16 = t.F_subsequentWidth > 0; if tmp16 { tmp16 = pass == 0 }; tmp15 = tmp16; if tmp15 {
							var parseLen int32 = pos - position
							effMaxWidth = Math_Max_I_I__I(effMinWidth, parseLen-t.F_subsequentWidth)


							pos = position
							total = 0
							totalBig = nil
							pass = pass + 1; continue L1 } }
//line :1077:1
					break L1
				}





























					if negative {

						if !(totalBig == nil) {

							var tmp17 bool; var tmp18 bool; var tmp19 *BigInteger = totalBig; var tmp20 *BigInteger; BigInteger_Init(); tmp20 = BigInteger_ZERO; tmp18 = NN(tmp19).Equals_O__Z(tmp20.Ref()); if tmp18 { tmp18 = NN(context).IsStrict__Z() }; tmp17 = tmp18; if tmp17 {
								return ^(position - 1) }
							totalBig = NN(totalBig).Negate__BigInteger() } else {

								var tmp21 bool; var tmp22 bool; tmp22 = total == 0; if tmp22 { tmp22 = NN(context).IsStrict__Z() }; tmp21 = tmp22; if tmp21 {
									return ^(position - 1) }
								total = -total } } else {
//line :1108:1
									var tmp23 bool; var tmp24 bool; var tmp25 *SignStyle = t.F_signStyle; var tmp26 *SignStyle










									SignStyle_Init(); tmp26 = SignStyle_EXCEEDS_PAD; tmp24 = tmp25 == tmp26; if tmp24 { tmp24 = NN(context).IsStrict__Z() }; tmp23 = tmp24
//line :1108:1
									if tmp23 {











										var parseLen_2 int32 = pos - position
										if positive {

											if parseLen_2 <= t.F_minWidth {
												return ^(position - 1) } } else {
//line :1121:1
													if parseLen_2 > t.F_minWidth {



														return ^position } } } }
					if !(totalBig == nil) {

						if NN(totalBig).BitLength__I() > 63 {
							var tmp27 *BigInteger = totalBig; var tmp28 *BigInteger; BigInteger_Init(); tmp28 = BigInteger_TEN; totalBig = NN(tmp27).Divide_BigInteger__BigInteger(tmp28)
							pos = pos - 1 }
						return this.SetValue_DateTimeParseContext_J_I_I__I(context, NN(totalBig).LongValue__J(), position, pos) } else {
							return this.SetValue_DateTimeParseContext_J_I_I__I(context, total, position, pos)
						} } } }
func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_SetValue_DateTimeParseContext_J_I_I__I(this DateTimeFormatterBuilder_NumberPrinterParser_I, context *DateTimeParseContext, value int64, errorPos, successPos int32) int32 {

	return NN(context).SetParsedField_TemporalField_J_I_I__I(t.F_field, value, errorPos, successPos)
}
func (t *DateTimeFormatterBuilder_NumberPrinterParser) Impl_ToString__String(this DateTimeFormatterBuilder_NumberPrinterParser_I) *String {
	var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = t.F_minWidth == 1; if tmp3 { tmp3 = t.F_maxWidth == 19 }; tmp2 = tmp3; if tmp2 { var tmp4 *SignStyle = t.F_signStyle; var tmp5 *SignStyle; SignStyle_Init(); tmp5 = SignStyle_NORMAL; tmp2 = tmp4 == tmp5 }; tmp1 = tmp2
//line :1139:1
	if tmp1 {

		return Concat(Lit_2330, StrOfObj(t.F_field), Lit_1176) } else {
//line :1139:1
			var tmp6 bool; var tmp7 bool


			tmp7 = t.F_minWidth == t.F_maxWidth; if tmp7 { var tmp8 *SignStyle = t.F_signStyle; var tmp9 *SignStyle; SignStyle_Init(); tmp9 = SignStyle_NOT_NEGATIVE; tmp7 = tmp8 == tmp9 }; tmp6 = tmp7
//line :1139:1
			if tmp6 {



				return Concat(Lit_2330, StrOfObj(t.F_field), Lit_1532, StrOfInt(t.F_minWidth), Lit_1176) } else {
					return Concat(Lit_2330, StrOfObj(t.F_field), Lit_1532, StrOfInt(t.F_minWidth), Lit_1532, StrOfInt(t.F_maxWidth), Lit_1532, StrOfObj(t.F_signStyle.Ref()), Lit_1176)
				}
		}
}







func DateTimeFormatterBuilder_ReducedPrinterParser_New_TemporalField_I_I_I_ChronoLocalDate(p0 TemporalField, p1, p2, p3 int32, p4 ChronoLocalDate) *DateTimeFormatterBuilder_ReducedPrinterParser { DateTimeFormatterBuilder_ReducedPrinterParser_Init(); t := &DateTimeFormatterBuilder_ReducedPrinterParser{}; t.Ctor_TemporalField_I_I_I_ChronoLocalDate(p0, p1, p2, p3, p4); return t }
//line :1155:1
func (t *DateTimeFormatterBuilder_ReducedPrinterParser) Ctor_TemporalField_I_I_I_ChronoLocalDate(field TemporalField, minWidth, maxWidth, baseValue int32, baseDate ChronoLocalDate) { t.Ctor_TemporalField_I_I_I_ChronoLocalDate_I(field, minWidth, maxWidth, baseValue, baseDate, 0)


	var tmp1 bool; var tmp2 bool; tmp2 = minWidth < 1; if !tmp2 { tmp2 = minWidth > 10 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2339, StrOfInt(minWidth)))))
	}
	var tmp3 bool; var tmp4 bool; tmp4 = maxWidth < 1; if !tmp4 { tmp4 = maxWidth > 10 }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2340, StrOfInt(minWidth)))))
	}
	if maxWidth < minWidth {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2317, StrOfInt(maxWidth), Lit_2048, StrOfInt(minWidth)))))
	}



	if baseDate == nil {
		if NN(field.Range__ValueRange()).IsValidValue_J__Z(int64(baseValue)) == false {
			panic(Thrown(IllegalArgumentException_New_String(Lit_2341))) }
		if int64(baseValue)+DateTimeFormatterBuilder_NumberPrinterParser_EXCEED_POINTS.A[maxWidth] > 2147483647 {

			panic(Thrown(DateTimeException_New_String(Lit_2342)))
		}
	} }
func DateTimeFormatterBuilder_ReducedPrinterParser_New_TemporalField_I_I_I_ChronoLocalDate_I(p0 TemporalField, p1, p2, p3 int32, p4 ChronoLocalDate, p5 int32) *DateTimeFormatterBuilder_ReducedPrinterParser { DateTimeFormatterBuilder_ReducedPrinterParser_Init(); t := &DateTimeFormatterBuilder_ReducedPrinterParser{}; t.Ctor_TemporalField_I_I_I_ChronoLocalDate_I(p0, p1, p2, p3, p4, p5); return t }
//line :1178:1
func (t *DateTimeFormatterBuilder_ReducedPrinterParser) Ctor_TemporalField_I_I_I_ChronoLocalDate_I(field TemporalField, minWidth, maxWidth, baseValue int32, baseDate ChronoLocalDate, subsequentWidth int32) { var tmp1 *SignStyle; SignStyle_Init(); tmp1 = SignStyle_NOT_NEGATIVE; t.DateTimeFormatterBuilder_NumberPrinterParser.Ctor_TemporalField_I_I_SignStyle_I(t, field, minWidth, maxWidth, tmp1, subsequentWidth);


	t.F_baseValue = baseValue;
	t.F_baseDate = baseDate }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) GetValue_DateTimePrintContext_J__J(context *DateTimePrintContext, value int64) int64 {
	var absValue int64 = Math_Abs_J__J(value); var baseValue int32 = t.F_baseValue

	if !(t.F_baseDate == nil) {
		var chrono Chronology = Chronology_From_TemporalAccessor__Chronology(NN(context).GetTemporal__TemporalAccessor())
		baseValue = chrono.Date_TemporalAccessor__ChronoLocalDate(t.F_baseDate).Get_TemporalField__I(t.F_field) }
	var tmp1 bool; var tmp2 bool; tmp2 = value >= int64(baseValue); if tmp2 {
		tmp2 = value < int64(baseValue)+DateTimeFormatterBuilder_NumberPrinterParser_EXCEED_POINTS.A[t.F_minWidth] }
//line :1190:1
	tmp1 = tmp2; if tmp1 {



		return absValue % DateTimeFormatterBuilder_NumberPrinterParser_EXCEED_POINTS.A[t.F_minWidth] } else {

			return absValue % DateTimeFormatterBuilder_NumberPrinterParser_EXCEED_POINTS.A[t.F_maxWidth]
		}
}
func (t *DateTimeFormatterBuilder_ReducedPrinterParser) SetValue_DateTimeParseContext_J_I_I__I(context *DateTimeParseContext, value int64, errorPos, successPos int32) int32 {

	var baseValue int32 = t.F_baseValue
	if !(t.F_baseDate == nil) {
		var chrono Chronology = NN(context).GetEffectiveChronology__Chronology()
		baseValue = chrono.Date_TemporalAccessor__ChronoLocalDate(t.F_baseDate).Get_TemporalField__I(t.F_field)
		var initialValue int64 = value
		NN(context).AddChronoChangedListener_Consumer__V(&Consumer_Fn{Fn: func(p0 any) { var _unused Chronology = Chronology_Cast(p0); _ = _unused;


			t.SetValue_DateTimeParseContext_J_I_I__I(context, initialValue, errorPos, successPos) }}) }
	var parseLen int32 = successPos - errorPos; var tmp1 bool; var tmp2 bool
	tmp2 = parseLen == t.F_minWidth; if tmp2 { tmp2 = value >= 0 }; tmp1 = tmp2; if tmp1 {
		var range_ int64 = DateTimeFormatterBuilder_NumberPrinterParser_EXCEED_POINTS.A[t.F_minWidth]; var lastPart int64 = int64(baseValue) % range_; var basePart int64 = int64(baseValue) - lastPart


		if baseValue > 0 {
			value = basePart + value } else {
				value = basePart - value }
		if value < int64(baseValue) { value = value + range_ } }
	return NN(context).SetParsedField_TemporalField_J_I_I__I(t.F_field, value, errorPos, successPos)
}
func (t *DateTimeFormatterBuilder_ReducedPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_ReducedPrinterParser() *DateTimeFormatterBuilder_ReducedPrinterParser {
	if t.F_subsequentWidth == -1 { return t } else {

		return DateTimeFormatterBuilder_ReducedPrinterParser_New_TemporalField_I_I_I_ChronoLocalDate_I(t.F_field, t.F_minWidth, t.F_maxWidth, t.F_baseValue, t.F_baseDate, -1)
	}
}




func (t *DateTimeFormatterBuilder_ReducedPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_ReducedPrinterParser(subsequentWidth int32) *DateTimeFormatterBuilder_ReducedPrinterParser {
	return DateTimeFormatterBuilder_ReducedPrinterParser_New_TemporalField_I_I_I_ChronoLocalDate_I(t.F_field, t.F_minWidth, t.F_maxWidth, t.F_baseValue, t.F_baseDate, t.F_subsequentWidth+subsequentWidth)
}





func (t *DateTimeFormatterBuilder_ReducedPrinterParser) IsFixedWidth_DateTimeParseContext__Z(context *DateTimeParseContext) bool {
	if NN(context).IsStrict__Z() == false { return false } else { return t.DateTimeFormatterBuilder_NumberPrinterParser.Impl_IsFixedWidth_DateTimeParseContext__Z(t, context)
	} }
func (t *DateTimeFormatterBuilder_ReducedPrinterParser) ToString__String() *String {
	var tmp1 TemporalField = t.F_field; var tmp2 int32 = t.F_minWidth; var tmp3 int32 = t.F_maxWidth; return Concat(Lit_2343, StrOfObj(tmp1), Lit_1532, StrOfInt(tmp2), Lit_1532, StrOfInt(tmp3), Lit_1532, StrOfObj(Objects_RequireNonNullElse_O_O__O(t.F_baseDate, Integer_ValueOf_I__Integer(t.F_baseValue))), Lit_1176)
}













func DateTimeFormatterBuilder_NanosPrinterParser_New_I_I_Z(p0, p1 int32, p2 bool) *DateTimeFormatterBuilder_NanosPrinterParser { DateTimeFormatterBuilder_NanosPrinterParser_Init(); t := &DateTimeFormatterBuilder_NanosPrinterParser{}; t.Ctor_I_I_Z(p0, p1, p2); return t }
//line :1258:1
func (t *DateTimeFormatterBuilder_NanosPrinterParser) Ctor_I_I_Z(minWidth, maxWidth int32, decimalPoint bool) { t.Ctor_I_I_Z_I(minWidth, maxWidth, decimalPoint, 0)

	var tmp1 bool; var tmp2 bool; tmp2 = minWidth < 0; if !tmp2 { tmp2 = minWidth > 9 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2315, StrOfInt(minWidth)))))
	}
	var tmp3 bool; var tmp4 bool; tmp4 = maxWidth < 1; if !tmp4 { tmp4 = maxWidth > 9 }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2316, StrOfInt(maxWidth)))))
	}
	if maxWidth < minWidth {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2317, StrOfInt(maxWidth), Lit_2048, StrOfInt(minWidth)))))
	}
}



func DateTimeFormatterBuilder_NanosPrinterParser_New_I_I_Z_I(p0, p1 int32, p2 bool, p3 int32) *DateTimeFormatterBuilder_NanosPrinterParser { DateTimeFormatterBuilder_NanosPrinterParser_Init(); t := &DateTimeFormatterBuilder_NanosPrinterParser{}; t.Ctor_I_I_Z_I(p0, p1, p2, p3); return t }
//line :1273:1
func (t *DateTimeFormatterBuilder_NanosPrinterParser) Ctor_I_I_Z_I(minWidth, maxWidth int32, decimalPoint bool, subsequentWidth int32) { var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_SECOND; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 *SignStyle; SignStyle_Init(); tmp3 = SignStyle_NOT_NEGATIVE; t.DateTimeFormatterBuilder_NumberPrinterParser.Ctor_TemporalField_I_I_SignStyle_I(t, tmp2, minWidth, maxWidth, tmp3, subsequentWidth);


	t.F_decimalPoint = decimalPoint }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_NanosPrinterParser() *DateTimeFormatterBuilder_NanosPrinterParser {
	if t.F_subsequentWidth == -1 { return t } else {

		return DateTimeFormatterBuilder_NanosPrinterParser_New_I_I_Z_I(t.F_minWidth, t.F_maxWidth, t.F_decimalPoint, -1)
	} }
func (t *DateTimeFormatterBuilder_NanosPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_NanosPrinterParser(subsequentWidth int32) *DateTimeFormatterBuilder_NanosPrinterParser {
	return DateTimeFormatterBuilder_NanosPrinterParser_New_I_I_Z_I(t.F_minWidth, t.F_maxWidth, t.F_decimalPoint, t.F_subsequentWidth+subsequentWidth)
}



func (t *DateTimeFormatterBuilder_NanosPrinterParser) IsFixedWidth_DateTimeParseContext__Z(context *DateTimeParseContext) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = NN(context).IsStrict__Z(); if tmp3 { tmp3 = t.F_minWidth == t.F_maxWidth }; tmp2 = tmp3; if tmp2 {
		tmp2 = t.F_decimalPoint == false }
//line :1290:1
	tmp1 = tmp2; if tmp1 { return true } else { return false
	}
}





func (t *DateTimeFormatterBuilder_NanosPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var value *Long = NN(context).GetValue_TemporalField_Z__Long(t.F_field, optional)
	if value == nil { return false } else {

		var val int32 = NN(t.F_field.Range__ValueRange()).CheckValidIntValue_J_TemporalField__I(NN(value).LongValue__J(), t.F_field); var decimalStyle *DecimalStyle = NN(context).GetDecimalStyle__DecimalStyle(); var stringSize int32 = DecimalDigits_StringSize_I__I(val); var zero uint16 = NN(decimalStyle).GetZeroDigit__C(); var tmp1 bool; var tmp2 bool



		tmp2 = val == 0; if !tmp2 { tmp2 = stringSize < 10-t.F_maxWidth }; tmp1 = tmp2; if tmp1 {
			var width int32; if val == 0 { width = t.F_minWidth } else { width = t.F_maxWidth }
			if width > 0 {
				if t.F_decimalPoint { NN(buf).Append_C__StringBuilder(NN(decimalStyle).GetDecimalSeparator__C()) }
				NN(buf).Repeat_I_I__StringBuilder(int32(zero), width) } } else {

					if t.F_decimalPoint { NN(buf).Append_C__StringBuilder(NN(decimalStyle).GetDecimalSeparator__C()) }
					var zeros int32 = 9 - stringSize
					if zeros > 0 { NN(buf).Repeat_I_I__StringBuilder(int32(zero), zeros) }
					if t.F_maxWidth < 9 {
						val = val / DateTimeFormatterBuilder_NanosPrinterParser_TENS.A[9-t.F_maxWidth]
					}


					var i int32 = t.F_maxWidth; L1: for {
						if i > t.F_minWidth {
							if !(val%10 == 0) { } else {
								val = val / 10
								i = i - 1; continue L1 } }
//line :1321:1
						break L1
					}



					if int32(zero) == 48 {
						NN(buf).Append_I__StringBuilder(val) } else {
							NN(buf).Append_String__StringBuilder(NN(decimalStyle).ConvertNumberToI18N_String__String(Integer_ToString_I__String(val))) } }
//line :1303:1
		return true
	}
}

























func (t *DateTimeFormatterBuilder_NanosPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {

	var effectiveMin int32; var tmp1 bool; var tmp2 bool; tmp2 = NN(context).IsStrict__Z(); if !tmp2 { tmp2 = t.IsFixedWidth_DateTimeParseContext__Z(context) }; tmp1 = tmp2; if tmp1 {
		effectiveMin = t.F_minWidth } else {
//line :1333:1
			effectiveMin = 0 }; var effectiveMax int32; var tmp3 bool; var tmp4 bool


	tmp4 = NN(context).IsStrict__Z(); if !tmp4 { tmp4 = t.IsFixedWidth_DateTimeParseContext__Z(context) }; tmp3 = tmp4; if tmp3 {
		effectiveMax = t.F_maxWidth } else {
//line :1336:1
			effectiveMax = 9 }
//line :1333:1
	var length int32 = text.Length__I()






	if position == length {
		if effectiveMin > 0 { return ^position } else { return position } } else {

			if t.F_decimalPoint {
				if int32(text.CharAt_I__C(position)) == int32(NN(NN(context).GetDecimalStyle__DecimalStyle()).GetDecimalSeparator__C()) { } else {

					var tmp5 int32; if effectiveMin > 0 { tmp5 = ^position } else { tmp5 = position }; return tmp5 }
				position = position + 1 }
			var minEndPos int32 = position + effectiveMin
			if minEndPos > length {
				return ^position } else {
					var maxEndPos int32 = Math_Min_I_I__I(position+effectiveMax, length)
					var total int32 = 0
					var pos int32 = position
				L1: for { if pos < maxEndPos {
					var ch uint16 = text.CharAt_I__C(pos); var digit int32 = NN(NN(context).GetDecimalStyle__DecimalStyle()).ConvertToDigit_C__I(ch)

					if digit < 0 {
						if pos < minEndPos { return ^position }
						break L1 }
					pos = pos + 1
					total = total*10 + digit
//line :1354:1
					continue L1 }; break L1
				}






					var i int32 = 9 - (pos - position); L2: for {
						if i > 0 {
							total = total * 10
							i = i - 1; continue L2 }
//line :1362:1
						break L2
					}


					return NN(context).SetParsedField_TemporalField_J_I_I__I(t.F_field, int64(total), position, pos)
				} } }
func (t *DateTimeFormatterBuilder_NanosPrinterParser) ToString__String() *String {
	var decimal *String; if t.F_decimalPoint { decimal = Lit_2318 } else { decimal = Lit_69 }
	return Concat(Lit_2319, StrOfObj(t.F_field), Lit_1532, StrOfInt(t.F_minWidth), Lit_1532, StrOfInt(t.F_maxWidth), decimal, Lit_1176)
}
















func DateTimeFormatterBuilder_FractionPrinterParser_New_TemporalField_I_I_Z(p0 TemporalField, p1, p2 int32, p3 bool) *DateTimeFormatterBuilder_FractionPrinterParser { DateTimeFormatterBuilder_FractionPrinterParser_Init(); t := &DateTimeFormatterBuilder_FractionPrinterParser{}; t.Ctor_TemporalField_I_I_Z(p0, p1, p2, p3); return t }
//line :1388:1
func (t *DateTimeFormatterBuilder_FractionPrinterParser) Ctor_TemporalField_I_I_Z(field TemporalField, minWidth, maxWidth int32, decimalPoint bool) { t.Ctor_TemporalField_I_I_Z_I(field, minWidth, maxWidth, decimalPoint, 0)


	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	if NN(field.Range__ValueRange()).IsFixed__Z() == false {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2314, StrOfObj(field)))))
	}
	var tmp1 bool; var tmp2 bool; tmp2 = minWidth < 0; if !tmp2 { tmp2 = minWidth > 9 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2315, StrOfInt(minWidth)))))
	}
	var tmp3 bool; var tmp4 bool; tmp4 = maxWidth < 1; if !tmp4 { tmp4 = maxWidth > 9 }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2316, StrOfInt(maxWidth)))))
	}
	if maxWidth < minWidth {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2317, StrOfInt(maxWidth), Lit_2048, StrOfInt(minWidth)))))
	}
}



func DateTimeFormatterBuilder_FractionPrinterParser_New_TemporalField_I_I_Z_I(p0 TemporalField, p1, p2 int32, p3 bool, p4 int32) *DateTimeFormatterBuilder_FractionPrinterParser { DateTimeFormatterBuilder_FractionPrinterParser_Init(); t := &DateTimeFormatterBuilder_FractionPrinterParser{}; t.Ctor_TemporalField_I_I_Z_I(p0, p1, p2, p3, p4); return t }
//line :1408:1
func (t *DateTimeFormatterBuilder_FractionPrinterParser) Ctor_TemporalField_I_I_Z_I(field TemporalField, minWidth, maxWidth int32, decimalPoint bool, subsequentWidth int32) { var tmp1 *SignStyle; SignStyle_Init(); tmp1 = SignStyle_NOT_NEGATIVE; t.DateTimeFormatterBuilder_NumberPrinterParser.Ctor_TemporalField_I_I_SignStyle_I(t, field, minWidth, maxWidth, tmp1, subsequentWidth);


	t.F_decimalPoint = decimalPoint; var range_ /*line :1412:1*/*ValueRange = field.Range__ValueRange();
	t.F_minBD = BigDecimal_ValueOf_J__BigDecimal(NN(range_).GetMinimum__J()); var tmp2 /*line :1414:1*/*BigDecimal = NN(BigDecimal_ValueOf_J__BigDecimal(NN(range_).GetMaximum__J())).Subtract_BigDecimal__BigDecimal(t.F_minBD); var tmp3 *BigDecimal; BigDecimal_Init(); tmp3 = BigDecimal_ONE; t.F_rangeBD = NN(tmp2).Add_BigDecimal__BigDecimal(tmp3) }


func (t *DateTimeFormatterBuilder_FractionPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_FractionPrinterParser() *DateTimeFormatterBuilder_FractionPrinterParser {
	if t.F_subsequentWidth == -1 { return t } else {

		return DateTimeFormatterBuilder_FractionPrinterParser_New_TemporalField_I_I_Z_I(t.F_field, t.F_minWidth, t.F_maxWidth, t.F_decimalPoint, -1)
	}
}



func (t *DateTimeFormatterBuilder_FractionPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_FractionPrinterParser(subsequentWidth int32) *DateTimeFormatterBuilder_FractionPrinterParser {
	return DateTimeFormatterBuilder_FractionPrinterParser_New_TemporalField_I_I_Z_I(t.F_field, t.F_minWidth, t.F_maxWidth, t.F_decimalPoint, t.F_subsequentWidth+subsequentWidth)
}




func (t *DateTimeFormatterBuilder_FractionPrinterParser) IsFixedWidth_DateTimeParseContext__Z(context *DateTimeParseContext) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = NN(context).IsStrict__Z(); if tmp3 { tmp3 = t.F_minWidth == t.F_maxWidth }; tmp2 = tmp3; if tmp2 {
		tmp2 = t.F_decimalPoint == false }
//line :1434:1
	tmp1 = tmp2; if tmp1 { return true } else { return false
	}
}


func (t *DateTimeFormatterBuilder_FractionPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var value *Long = NN(context).GetValue_TemporalField_Z__Long(t.F_field, optional)
	if value == nil { return false } else {

		var decimalStyle *DecimalStyle = NN(context).GetDecimalStyle__DecimalStyle(); var fraction *BigDecimal = t.ConvertToFraction_J__BigDecimal(NN(value).LongValue__J())

		if NN(fraction).Scale__I() == 0 {
			if t.F_minWidth > 0 {
				if t.F_decimalPoint { NN(buf).Append_C__StringBuilder(NN(decimalStyle).GetDecimalSeparator__C()) }
				NN(buf).Repeat_I_I__StringBuilder(int32(NN(decimalStyle).GetZeroDigit__C()), t.F_minWidth) } } else {
					var outputScale int32 = Math_Clamp_J_I_I__I(int64(NN(fraction).Scale__I()), t.F_minWidth, t.F_maxWidth); var tmp1 *BigDecimal = fraction; var tmp2 *RoundingMode


					RoundingMode_Init(); tmp2 = RoundingMode_FLOOR; fraction = NN(tmp1).SetScale_I_RoundingMode__BigDecimal(outputScale, tmp2)
					if t.F_decimalPoint { NN(buf).Append_C__StringBuilder(NN(decimalStyle).GetDecimalSeparator__C()) }
					var str *String = NN(fraction).ToPlainString__String()
					str = NN(decimalStyle).ConvertNumberToI18N_String__String(str)
					NN(buf).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(str), 2, NN(str).Length__I()) }
//line :1444:1
		return true
	}
}













func (t *DateTimeFormatterBuilder_FractionPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {

	var effectiveMin int32; var tmp1 bool; var tmp2 bool; tmp2 = NN(context).IsStrict__Z(); if !tmp2 { tmp2 = t.IsFixedWidth_DateTimeParseContext__Z(context) }; tmp1 = tmp2; if tmp1 {
		effectiveMin = t.F_minWidth } else {
//line :1462:1
			effectiveMin = 0 }; var effectiveMax int32; var tmp3 bool; var tmp4 bool


	tmp4 = NN(context).IsStrict__Z(); if !tmp4 { tmp4 = t.IsFixedWidth_DateTimeParseContext__Z(context) }; tmp3 = tmp4; if tmp3 {
		effectiveMax = t.F_maxWidth } else {
//line :1465:1
			effectiveMax = 9 }
//line :1462:1
	var length int32 = text.Length__I()






	if position == length {
		if effectiveMin > 0 { return ^position } else { return position } } else {

			if t.F_decimalPoint {
				if int32(text.CharAt_I__C(position)) == int32(NN(NN(context).GetDecimalStyle__DecimalStyle()).GetDecimalSeparator__C()) { } else {

					var tmp5 int32; if effectiveMin > 0 { tmp5 = ^position } else { tmp5 = position }; return tmp5 }
				position = position + 1 }
			var minEndPos int32 = position + effectiveMin
			if minEndPos > length {
				return ^position } else {
					var maxEndPos int32 = Math_Min_I_I__I(position+effectiveMax, length)
					var total int32 = 0
					var pos int32 = position
				L1: for { if pos < maxEndPos {
					var ch uint16; var tmp6 int32
					var old_6 int32 = pos
					pos = pos + 1; tmp6 = old_6
//line :1484:1
					ch = text.CharAt_I__C(tmp6); var digit int32 = NN(NN(context).GetDecimalStyle__DecimalStyle()).ConvertToDigit_C__I(ch)



					if digit < 0 {
						if pos <= minEndPos { return ^position }
						pos = pos - 1
						break L1 }
					total = total*10 + digit
//line :1483:1
					continue L1 }; break L1
				}








					var fraction *BigDecimal = BigDecimal_New_I(total).MovePointLeft_I__BigDecimal(pos - position); var value int64 = t.ConvertFromFraction_BigDecimal__J(fraction)



					return NN(context).SetParsedField_TemporalField_J_I_I__I(t.F_field, value, position, pos)
				} } }
func (t *DateTimeFormatterBuilder_FractionPrinterParser) ConvertToFraction_J__BigDecimal(value int64) *BigDecimal {
	NN(t.F_field.Range__ValueRange()).CheckValidValue_J_TemporalField__J(value, t.F_field)
	var valueBD *BigDecimal = NN(BigDecimal_ValueOf_J__BigDecimal(value)).Subtract_BigDecimal__BigDecimal(t.F_minBD); var fraction *BigDecimal; var tmp1 *BigDecimal = t.F_rangeBD; var tmp2 *RoundingMode
	RoundingMode_Init(); tmp2 = RoundingMode_FLOOR; fraction = NN(valueBD).Divide_BigDecimal_I_RoundingMode__BigDecimal(tmp1, 9, tmp2)
	var tmp3 *BigDecimal; BigDecimal_Init(); tmp3 = BigDecimal_ZERO; if NN(fraction).CompareTo_BigDecimal__I(tmp3) == 0 { BigDecimal_Init(); return BigDecimal_ZERO } else {

		return NN(fraction).StripTrailingZeros__BigDecimal()
	} }
func (t *DateTimeFormatterBuilder_FractionPrinterParser) ConvertFromFraction_BigDecimal__J(fraction *BigDecimal) int64 {
	var valueBD *BigDecimal; var tmp1 *BigDecimal = NN(fraction).Multiply_BigDecimal__BigDecimal(t.F_rangeBD); var tmp2 *RoundingMode; RoundingMode_Init(); tmp2 = RoundingMode_FLOOR; valueBD = NN(NN(tmp1).SetScale_I_RoundingMode__BigDecimal(0, tmp2)).Add_BigDecimal__BigDecimal(t.F_minBD)
	return NN(valueBD).LongValueExact__J()
}
func (t *DateTimeFormatterBuilder_FractionPrinterParser) ToString__String() *String {
	var decimal *String; if t.F_decimalPoint { decimal = Lit_2318 } else { decimal = Lit_69 }
	return Concat(Lit_2319, StrOfObj(t.F_field), Lit_1532, StrOfInt(t.F_minWidth), Lit_1532, StrOfInt(t.F_maxWidth), decimal, Lit_1176)
}


















func DateTimeFormatterBuilder_TextPrinterParser_New_TemporalField_TextStyle_DateTimeTextProvider(p0 TemporalField, p1 *TextStyle, p2 DateTimeTextProvider_I) *DateTimeFormatterBuilder_TextPrinterParser { t := &DateTimeFormatterBuilder_TextPrinterParser{}; t.Ctor_TemporalField_TextStyle_DateTimeTextProvider(p0, p1, p2); return t }
//line :1533:1
func (t *DateTimeFormatterBuilder_TextPrinterParser) Ctor_TemporalField_TextStyle_DateTimeTextProvider(field TemporalField, textStyle *TextStyle, provider DateTimeTextProvider_I) {

	t.F_field = field
	t.F_textStyle = textStyle
	t.F_provider = provider
}
func (t *DateTimeFormatterBuilder_TextPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var value *Long = NN(context).GetValue_TemporalField_Z__Long(t.F_field, optional)
	if value == nil { return false } else {

		var text *String; var chrono Chronology = Chronology_Cast(NN(context).GetTemporal__TemporalAccessor().Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery())); var tmp1 bool; var tmp2 bool


		tmp2 = chrono == nil; if !tmp2 { var tmp3 *IsoChronology; IsoChronology_Init(); tmp3 = IsoChronology_INSTANCE; tmp2 = any(chrono) == any(tmp3.Ref()) }; tmp1 = tmp2; if tmp1 {
			var tmp4 DateTimeTextProvider_I = t.F_provider; var tmp5 TemporalField = t.F_field; var tmp6 int64 = NN(value).LongValue__J(); var tmp7 *TextStyle = t.F_textStyle; text = tmp4.GetText_TemporalField_J_TextStyle_Locale__String(tmp5, tmp6, tmp7, NN(context).GetLocale__Locale()) } else {
				var tmp8 DateTimeTextProvider_I = t.F_provider; var tmp9 TemporalField = t.F_field; var tmp10 int64 = NN(value).LongValue__J(); var tmp11 *TextStyle = t.F_textStyle; text = tmp8.GetText_Chronology_TemporalField_J_TextStyle_Locale__String(chrono, tmp9, tmp10, tmp11, NN(context).GetLocale__Locale()) }
		if text == nil {
			return t.NumberPrinterParser__DateTimeFormatterBuilder_NumberPrinterParser().Format_DateTimePrintContext_StringBuilder_Z__Z(context, buf, optional) } else {
				NN(buf).Append_String__StringBuilder(text); return true
			} } }
func (t *DateTimeFormatterBuilder_TextPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, parseText CharSequence, position int32) int32 {

	var length int32 = parseText.Length__I(); var tmp1 bool; var tmp2 bool
	tmp2 = position < 0; if !tmp2 { tmp2 = position > length }; tmp1 = tmp2; if tmp1 { panic(Thrown(IndexOutOfBoundsException_New())) }
	var style *TextStyle; if NN(context).IsStrict__Z() { style = t.F_textStyle } else { style = nil }; var chrono Chronology = NN(context).GetEffectiveChronology__Chronology(); var it Iterator; var tmp3 bool; var tmp4 bool


	tmp4 = chrono == nil
//line :1560:1
	if !tmp4 {

		var tmp5 *IsoChronology; IsoChronology_Init(); tmp5 = IsoChronology_INSTANCE; tmp4 = any(chrono) == any(tmp5.Ref()) }
//line :1560:1
	tmp3 = tmp4; if tmp3 {




		var tmp6 DateTimeTextProvider_I = t.F_provider; var tmp7 TemporalField = t.F_field; it = tmp6.GetTextIterator_TemporalField_TextStyle_Locale__Iterator(tmp7, style, NN(context).GetLocale__Locale()) } else {




			var tmp8 DateTimeTextProvider_I = t.F_provider; var tmp9 TemporalField = t.F_field; it = tmp8.GetTextIterator_Chronology_TemporalField_TextStyle_Locale__Iterator(chrono, tmp9, style, NN(context).GetLocale__Locale())
		}




	if !(it == nil) {
	L1: for { if it.HasNext__Z() {
		var entry Map_Entry = Map_Entry_Cast(it.Next__O()); var itText *String = String_Cast(entry.GetKey__O())

		if NN(context).SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(Up_String_CharSequence(itText), 0, parseText, position, NN(itText).Length__I()) {
			var tmp10 TemporalField = t.F_field; return NN(context).SetParsedField_TemporalField_J_I_I__I(tmp10, NN(Long_Cast(entry.GetValue__O())).LongValue__J(), position, position+NN(itText).Length__I()) }
//line :1577:1
		continue L1 }; break L1
	}







		var tmp11 bool; var tmp12 bool; var tmp13 TemporalField = t.F_field; var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_ERA; tmp12 = any(tmp13) == any(tmp14.Ref()); if tmp12 { tmp12 = !NN(context).IsStrict__Z() }; tmp11 = tmp12; if tmp11 {
			var eras List = chrono.Eras__List(); var i_101615 Iterator = eras.Iterator__Iterator(); for i_101615.HasNext__Z() {
				var era Era = Era_Cast(i_101615.Next__O()); var name *String = era.ToString__String()

				if NN(context).SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(Up_String_CharSequence(name), 0, parseText, position, NN(name).Length__I()) {
					var tmp15 TemporalField = t.F_field; return NN(context).SetParsedField_TemporalField_J_I_I__I(tmp15, int64(era.GetValue__I()), position, position+NN(name).Length__I())
				}
			}
		}

		if NN(context).IsStrict__Z() { return ^position } }
	return t.NumberPrinterParser__DateTimeFormatterBuilder_NumberPrinterParser().Parse_DateTimeParseContext_CharSequence_I__I(context, parseText, position)
}
func (t *DateTimeFormatterBuilder_TextPrinterParser) NumberPrinterParser__DateTimeFormatterBuilder_NumberPrinterParser() DateTimeFormatterBuilder_NumberPrinterParser_I {
	if t.F_numberPrinterParser.Load() == nil {
		var tmp1 TemporalField = t.F_field; var tmp2 *SignStyle; SignStyle_Init(); tmp2 = SignStyle_NORMAL; t.F_numberPrinterParser.Store(DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle(tmp1, 1, 19, tmp2)) }
//line :1599:1
	return t.F_numberPrinterParser.Load()
}



func (t *DateTimeFormatterBuilder_TextPrinterParser) ToString__String() *String {
	var tmp1 *TextStyle = t.F_textStyle; var tmp2 *TextStyle; TextStyle_Init(); tmp2 = TextStyle_FULL; if tmp1 == tmp2 {
		return Concat(Lit_2353, StrOfObj(t.F_field), Lit_1176) } else {
			return Concat(Lit_2353, StrOfObj(t.F_field), Lit_1532, StrOfObj(t.F_textStyle.Ref()), Lit_1176)
		}
}













func DateTimeFormatterBuilder_InstantPrinterParser_New_I(p0 int32) *DateTimeFormatterBuilder_InstantPrinterParser { t := &DateTimeFormatterBuilder_InstantPrinterParser{}; t.Ctor_I(p0); return t }
//line :1623:1
func (t *DateTimeFormatterBuilder_InstantPrinterParser) Ctor_I(fractionalDigits int32) {
	t.F_fractionalDigits = fractionalDigits
}
func (t *DateTimeFormatterBuilder_InstantPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var inSecs *Long; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_INSTANT_SECONDS; inSecs = NN(context).GetValue_TemporalField_Z__Long(Up_ChronoField_TemporalField(tmp1), optional); var inNanos *Long; var tmp2 TemporalAccessor = NN(context).GetTemporal__TemporalAccessor(); var tmp3 *ChronoField

	ChronoField_Init(); tmp3 = ChronoField_NANO_OF_SECOND; if tmp2.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp3)) {
		var tmp4 TemporalAccessor = NN(context).GetTemporal__TemporalAccessor(); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_NANO_OF_SECOND; inNanos = Long_ValueOf_J__Long(tmp4.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp5))) }
	if inSecs == nil { return false } else {

		var inSec int64 = NN(inSecs).LongValue__J(); var inNano int32; var tmp6 *ChronoField
		ChronoField_Init(); tmp6 = ChronoField_NANO_OF_SECOND; var tmp7 *ChronoField = tmp6; var tmp8 int64

		if !(inNanos == nil) { tmp8 = NN(inNanos).LongValue__J() } else { tmp8 = 0 }
//line :1635:1
		inNano = NN(tmp7).CheckValidIntValue_J__I(tmp8)


		if t.F_fractionalDigits == 0 { inNano = 0 }
		var printNanoInLocalDateTime bool; var tmp9 bool
		tmp9 = t.F_fractionalDigits == -2
//line :1639:1
		if !tmp9 {

			var tmp10 bool
			tmp10 = inNano == 0
//line :1641:1
			if tmp10 {

				var tmp11 bool
				tmp11 = t.F_fractionalDigits == 0
//line :1643:1
				if !tmp11 {

					tmp11 = t.F_fractionalDigits == -1 }
//line :1643:1
				tmp10 = tmp11 }
//line :1641:1
			tmp9 = tmp10 }
//line :1639:1
		printNanoInLocalDateTime = tmp9






		if inSec >= -62167219200 {
			var tmp12 int32


			if printNanoInLocalDateTime { tmp12 = inNano } else { tmp12 = 0 }
//line :1647:1
			DateTimeFormatterBuilder_InstantPrinterParser_CurrentEra_StringBuilder_J_I__V(buf, inSec, tmp12)

		} else {

			var tmp13 int32


			if printNanoInLocalDateTime { tmp13 = inNano } else { tmp13 = 0 }
//line :1651:1
			DateTimeFormatterBuilder_InstantPrinterParser_BeforeCurrentEra_StringBuilder_J_I__V(buf, inSec, tmp13)
		}


		if printNanoInLocalDateTime { } else { t.PrintNano_StringBuilder_J_I__V(buf, inSec, inNano) }
		NN(buf).Append_C__StringBuilder(90)
//line :1639:1
		return true
	}
}

















func (t *DateTimeFormatterBuilder_InstantPrinterParser) PrintNano_StringBuilder_J_I__V(buf *StringBuilder, inSec int64, inNano int32) {
	NN(buf).Append_C__StringBuilder(46)
	var div int32 = 100000000; var fractionalDigits int32 = t.F_fractionalDigits
	var i int32 = 0
L1: for {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = fractionalDigits == -1; if tmp4 { tmp4 = inNano > 0 }; tmp3 = tmp4; if !tmp3 {
		var tmp5 bool; tmp5 = fractionalDigits == -2; if tmp5 {
			var tmp6 bool; tmp6 = inNano > 0; if !tmp6 { tmp6 = !(i%3 == 0) }; tmp5 = tmp6 }
//line :1665:1
		tmp3 = tmp5 }
//line :1664:1
	tmp2 = tmp3; if !tmp2 {


		tmp2 = i < fractionalDigits }
//line :1664:1
	tmp1 = tmp2; if tmp1 {



		var digit int32 = inNano / div
		NN(buf).Append_C__StringBuilder(uint16(digit + 48))
		inNano = inNano - digit*div
		div = div / 10
		i = i + 1; continue L1 }
//line :1663:1
	break L1
}
}








func DateTimeFormatterBuilder_InstantPrinterParser_CurrentEra_StringBuilder_J_I__V(buf *StringBuilder, inSec int64, inNano int32) {
	var zeroSecs int64 = inSec - 315569520000 + 62167219200; var hi int64 = Math_FloorDiv_J_J__J(zeroSecs, 315569520000) + 1; var lo int64 = Math_FloorMod_J_J__J(zeroSecs, 315569520000); var ldt *LocalDateTime; var tmp1 int64 = lo - 62167219200; var tmp2 *ZoneOffset



	ZoneOffset_Init(); tmp2 = ZoneOffset_UTC; ldt = LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(tmp1, inNano, tmp2)


	if hi > 0 { NN(NN(buf).Append_C__StringBuilder(43)).Append_J__StringBuilder(hi) }
	DateTimeHelper_FormatTo_StringBuilder_LocalDateTime__V(buf, ldt)
	var tmp3 bool; var tmp4 bool; tmp4 = NN(ldt).GetSecond__I() == 0; if tmp4 { tmp4 = inNano == 0 }; tmp3 = tmp4; if tmp3 { NN(buf).Append_String__StringBuilder(Lit_2320)
	} }
func DateTimeFormatterBuilder_InstantPrinterParser_BeforeCurrentEra_StringBuilder_J_I__V(buf *StringBuilder, inSec int64, inNano int32) {
	var zeroSecs int64 = inSec + 62167219200; var hi int64 = zeroSecs / 315569520000; var lo int64 = zeroSecs % 315569520000; var ldt *LocalDateTime; var tmp1 int64 = lo - 62167219200; var tmp2 *ZoneOffset


	ZoneOffset_Init(); tmp2 = ZoneOffset_UTC; ldt = LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(tmp1, inNano, tmp2)
//line :1687:1
	var pos int32 = NN(buf).Length__I()






	DateTimeHelper_FormatTo_StringBuilder_LocalDateTime__V(buf, ldt)
	var tmp3 bool; var tmp4 bool; tmp4 = NN(ldt).GetSecond__I() == 0; if tmp4 { tmp4 = inNano == 0 }; tmp3 = tmp4; if tmp3 { NN(buf).Append_String__StringBuilder(Lit_2320) }
	if hi < 0 {
		if NN(ldt).GetYear__I() == -10000 {

			NN(buf).Replace_I_I_String__StringBuilder(pos, pos+2, Long_ToString_J__String(hi-1)) } else {
//line :1697:1
				if lo == 0 {


					NN(buf).Insert_I_J__StringBuilder(pos, hi) } else {
						NN(buf).Insert_I_J__StringBuilder(pos+1, Math_Abs_J__J(hi))
					} } } }
func (t *DateTimeFormatterBuilder_InstantPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var minDigits int32; if t.F_fractionalDigits < 0 { minDigits = 0 } else { minDigits = t.F_fractionalDigits }; var maxDigits int32
	if t.F_fractionalDigits < 0 { maxDigits = 9 } else { maxDigits = t.F_fractionalDigits }
//line :1704:1
	var parser *DateTimeFormatterBuilder_CompositePrinterParser; var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp2 *DateTimeFormatter

	DateTimeFormatter_Init(); tmp2 = DateTimeFormatter_ISO_LOCAL_DATE; var tmp3 *DateTimeFormatterBuilder = NN(tmp1.Append_DateTimeFormatter__DateTimeFormatterBuilder(tmp2)).AppendLiteral_C__DateTimeFormatterBuilder(84); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_HOUR_OF_DAY; var tmp5 *DateTimeFormatterBuilder = NN(NN(tmp3).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp4), 2)).AppendLiteral_C__DateTimeFormatterBuilder(58); var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_MINUTE_OF_HOUR; var tmp7 *DateTimeFormatterBuilder = NN(NN(tmp5).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp6), 2)).AppendLiteral_C__DateTimeFormatterBuilder(58); var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_SECOND_OF_MINUTE; var tmp9 *DateTimeFormatterBuilder = NN(tmp7).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp8), 2); var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_NANO_OF_SECOND; parser = NN(NN(NN(NN(NN(tmp9).AppendFraction_TemporalField_I_I_Z__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp10), minDigits, maxDigits, true)).ParseLenient__DateTimeFormatterBuilder()).AppendOffset_String_String__DateTimeFormatterBuilder(Lit_2321, Lit_2165)).ToFormatter__DateTimeFormatter()).ToPrinterParser_Z__DateTimeFormatterBuilder_CompositePrinterParser(false)
//line :1704:1
	var newContext *DateTimeParseContext = NN(context).Copy__DateTimeParseContext(); var pos int32 = NN(parser).Parse_DateTimeParseContext_CharSequence_I__I(newContext, text, position)
































	if pos < 0 { return pos } else {

		var yearParsed int64; var tmp11 *ChronoField; ChronoField_Init(); tmp11 = ChronoField_YEAR; yearParsed = NN(NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp11))).LongValue__J(); var month int32; var tmp12 *ChronoField
		ChronoField_Init(); tmp12 = ChronoField_MONTH_OF_YEAR; month = NN(NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp12))).IntValue__I()
//line :1739:1
		var day int32; var tmp13 *ChronoField

		ChronoField_Init(); tmp13 = ChronoField_DAY_OF_MONTH; day = NN(NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp13))).IntValue__I()
//line :1739:1
		var hour int32; var tmp14 *ChronoField


		ChronoField_Init(); tmp14 = ChronoField_HOUR_OF_DAY; hour = NN(NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp14))).IntValue__I()
//line :1739:1
		var min_ int32; var tmp15 *ChronoField



		ChronoField_Init(); tmp15 = ChronoField_MINUTE_OF_HOUR; min_ = NN(NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp15))).IntValue__I()
//line :1739:1
		var secVal *Long; var tmp16 *ChronoField




		ChronoField_Init(); tmp16 = ChronoField_SECOND_OF_MINUTE; secVal = NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp16))
//line :1739:1
		var nanoVal *Long; var tmp17 *ChronoField





		ChronoField_Init(); tmp17 = ChronoField_NANO_OF_SECOND; nanoVal = NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp17))
//line :1739:1
		var sec int32






		if !(secVal == nil) { sec = NN(secVal).IntValue__I() } else { sec = 0 }
//line :1739:1
		var nano int32







		if !(nanoVal == nil) { nano = NN(nanoVal).IntValue__I() } else { nano = 0 }
//line :1739:1
		var offset int32; var tmp18 *ChronoField








		ChronoField_Init(); tmp18 = ChronoField_OFFSET_SECONDS; offset = NN(NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp18))).IntValue__I()
//line :1739:1
		var days int32 = 0; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool










		tmp22 = hour == 24; if tmp22 { tmp22 = min_ == 0 }; tmp21 = tmp22; if tmp21 { tmp21 = sec == 0 }; tmp20 = tmp21; if tmp20 { tmp20 = nano == 0 }; tmp19 = tmp20; if tmp19 {
			hour = 0; days = 1 } else {
				var tmp23 bool; var tmp24 bool; var tmp25 bool; tmp25 = hour == 23; if tmp25 { tmp25 = min_ == 59 }; tmp24 = tmp25; if tmp24 { tmp24 = sec == 60 }; tmp23 = tmp24; if tmp23 {
					NN(context).SetParsedLeapSecond__V()
					sec = 59 } }
		var year int32 = int32(yearParsed) % 10000; var instantSecs int64 = 0; tmp26 := func() (exc Throwable_I) { defer Catch(&exc)


			{ var ldt *LocalDateTime = NN(LocalDateTime_Of_I_I_I_I_I_I_I__LocalDateTime(year, month, day, hour, min_, sec, 0)).PlusDays_J__LocalDateTime(int64(days))
				instantSecs = NN(ldt).ToEpochSecond_ZoneOffset__J(ZoneOffset_OfTotalSeconds_I__ZoneOffset(offset))
				instantSecs = instantSecs + Math_MultiplyExact_J_J__J(yearParsed/10000, 315569520000) }
//line :1755:1
			return nil
		}()
		if tmp26 != nil { if RuntimeException_InstanceOf(tmp26) { var ex RuntimeException_I = RuntimeException_Cast(tmp26); _ = ex







			return ^position } else {
//line :1757:1
				panic(tmp26)
			}
		}






		var successPos int32 = pos; var tmp27 *ChronoField
		ChronoField_Init(); tmp27 = ChronoField_INSTANT_SECONDS; successPos = NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp27), instantSecs, position, successPos)





		var tmp28 *ChronoField; ChronoField_Init(); tmp28 = ChronoField_NANO_OF_SECOND; return NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp28), int64(nano), position, successPos)
	} }
func (t *DateTimeFormatterBuilder_InstantPrinterParser) ToString__String() *String { return Lit_2322 }






















func DateTimeFormatterBuilder_OffsetIdPrinterParser_New_String_String(p0, p1 *String) *DateTimeFormatterBuilder_OffsetIdPrinterParser { DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); t := &DateTimeFormatterBuilder_OffsetIdPrinterParser{}; t.Ctor_String_String(p0, p1); return t }
//line :1798:1
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) Ctor_String_String(pattern, noOffsetText *String) {
	Objects_RequireNonNull_O_String__O(pattern.Ref(), Lit_2272)
	Objects_RequireNonNull_O_String__O(noOffsetText.Ref(), Lit_2331)
	t.F_type = t.CheckPattern_String__I(pattern)
	t.F_style = t.F_type % 11
	t.F_noOffsetText = noOffsetText
}
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) CheckPattern_String__I(pattern *String) int32 {
	var i int32 = 0; L1: for {
		if i < int32(len(DateTimeFormatterBuilder_OffsetIdPrinterParser_PATTERNS.A)) {
			if NN(As[*String](DateTimeFormatterBuilder_OffsetIdPrinterParser_PATTERNS.A[i])).Equals_O__Z(pattern.Ref()) { return i } else { i = i + 1; continue L1 } }
//line :1806:1
		break L1
	}


	panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2332, pattern))))
}
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) IsPaddedHour__Z() bool { return t.F_type < 11 }

func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) IsColon__Z() bool {
	var tmp1 bool; tmp1 = t.F_style > 0; if tmp1 { tmp1 = t.F_style%2 == 0 }; return tmp1
}
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var offsetSecs *Long; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; offsetSecs = NN(context).GetValue_TemporalField_Z__Long(Up_ChronoField_TemporalField(tmp1), optional)
	if offsetSecs == nil { return false } else {

		var totalSecs int32 = Math_ToIntExact_J__I(NN(offsetSecs).LongValue__J())
		if totalSecs == 0 {
			NN(buf).Append_String__StringBuilder(t.F_noOffsetText) } else {
				var absHours int32 = Math_Abs_I__I(totalSecs / 3600 % 100); var absMinutes int32 = Math_Abs_I__I(totalSecs / 60 % 60); var absSeconds int32 = Math_Abs_I__I(totalSecs % 60); var bufPos int32 = NN(buf).Length__I(); var output int32 = absHours; var tmp2 *String








				if totalSecs < 0 { tmp2 = Lit_1134 } else { tmp2 = Lit_1135 }; NN(buf).Append_String__StringBuilder(tmp2)
				var tmp3 bool; var tmp4 bool; tmp4 = t.IsPaddedHour__Z(); if !tmp4 { tmp4 = absHours >= 10 }; tmp3 = tmp4; if tmp3 {
					t.FormatZeroPad_Z_I_StringBuilder__V(false, absHours, buf) } else {
						NN(buf).Append_C__StringBuilder(uint16(absHours + 48)) }
				var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = t.F_style >= 3; if tmp8 { tmp8 = t.F_style <= 8 }; tmp7 = tmp8; if !tmp7 {
					var tmp9 bool; tmp9 = t.F_style >= 9; if tmp9 { tmp9 = absSeconds > 0 }; tmp7 = tmp9 }
//line :1838:1
				tmp6 = tmp7; if !tmp6 {

					var tmp10 bool; tmp10 = t.F_style >= 1; if tmp10 { tmp10 = absMinutes > 0 }; tmp6 = tmp10 }
//line :1838:1
				tmp5 = tmp6; if tmp5 {


					t.FormatZeroPad_Z_I_StringBuilder__V(t.IsColon__Z(), absMinutes, buf)
					output = output + absMinutes
					var tmp11 bool; var tmp12 bool; var tmp13 bool; tmp13 = t.F_style == 7; if !tmp13 { tmp13 = t.F_style == 8 }; tmp12 = tmp13; if !tmp12 { var tmp14 bool; tmp14 = t.F_style >= 5; if tmp14 { tmp14 = absSeconds > 0 }; tmp12 = tmp14 }; tmp11 = tmp12; if tmp11 {
						t.FormatZeroPad_Z_I_StringBuilder__V(t.IsColon__Z(), absSeconds, buf)
						output = output + absSeconds } }
				if output == 0 { NN(buf).SetLength_I__V(bufPos); NN(buf).Append_String__StringBuilder(t.F_noOffsetText) } }
//line :1822:1
		return true
	}
}
























func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) FormatZeroPad_Z_I_StringBuilder__V(colon bool, value int32, buf *StringBuilder) {
	var tmp1 *String; if colon { tmp1 = Lit_1309 } else { tmp1 = Lit_69 }; NN(NN(NN(buf).Append_String__StringBuilder(tmp1)).Append_C__StringBuilder(uint16(value/10 + 48))).Append_C__StringBuilder(uint16(value%10 + 48))
}


func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var length int32 = text.Length__I(); var noOffsetLen int32 = NN(t.F_noOffsetText).Length__I()

	if noOffsetLen == 0 {
		if position == length {
			var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; return NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp1), 0, position, position) } } else {

				if position == length { return ^position }
				if NN(context).SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(text, position, Up_String_CharSequence(t.F_noOffsetText), 0, noOffsetLen) {
					var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_OFFSET_SECONDS; return NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp2), 0, position, position+noOffsetLen)
				}
			}


	var sign uint16 = text.CharAt_I__C(position); var tmp3 bool; var tmp4 bool
	tmp4 = int32(sign) == 43; if !tmp4 { tmp4 = int32(sign) == 45 }; tmp3 = tmp4; if tmp3 {
		var negative int32; if int32(sign) == 45 { negative = -1 } else { negative = 1 }; var isColon bool = t.IsColon__Z(); var paddedHour bool = t.IsPaddedHour__Z(); var array *IntArray = NewIntArray(4)



		array.A[0] = position + 1
		var parseType int32 = t.F_type
		if NN(context).IsStrict__Z() { } else {
			if paddedHour {

				var tmp5 bool; var tmp6 bool; tmp6 = isColon; if !tmp6 {
					var tmp7 bool; var tmp8 bool; tmp8 = parseType == 0; if tmp8 { tmp8 = length > position+3 }; tmp7 = tmp8; if tmp7 {
						tmp7 = int32(text.CharAt_I__C(position+3)) == 58 }
//line :1880:1
					tmp6 = tmp7 }
//line :1879:1
				tmp5 = tmp6; if tmp5 {


					isColon = true; parseType = 10 } else {
						parseType = 9 } } else {
//line :1877:1
							var tmp9 bool; var tmp10 bool






							tmp10 = isColon; if !tmp10 {
								var tmp11 bool; var tmp12 bool; tmp12 = parseType == 11; if tmp12 { tmp12 = length > position+3 }; tmp11 = tmp12; if tmp11 {
									var tmp13 bool; tmp13 = int32(text.CharAt_I__C(position+2)) == 58; if !tmp13 {
										tmp13 = int32(text.CharAt_I__C(position+3)) == 58 }
//line :1886:1
									tmp11 = tmp13 }
//line :1885:1
								tmp10 = tmp11 }
//line :1884:1
							tmp9 = tmp10
//line :1877:1
							if tmp9 {










								isColon = true; parseType = 21 } else {
									parseType = 20 } } }
		switch parseType { case 0, 11:
			t.ParseHour_CharSequence_Z_I1__V(text, paddedHour, array); case 1, 2, 13:


			t.ParseHour_CharSequence_Z_I1__V(text, paddedHour, array)
			t.ParseMinute_CharSequence_Z_Z_I1__V(text, isColon, false, array); case 3, 4, 15:


			t.ParseHour_CharSequence_Z_I1__V(text, paddedHour, array)
			t.ParseMinute_CharSequence_Z_Z_I1__V(text, isColon, true, array); case 5, 6, 17:


			t.ParseHour_CharSequence_Z_I1__V(text, paddedHour, array)
			t.ParseMinute_CharSequence_Z_Z_I1__V(text, isColon, true, array)
			t.ParseSecond_CharSequence_Z_Z_I1__V(text, isColon, false, array); case 7, 8, 19:


			t.ParseHour_CharSequence_Z_I1__V(text, paddedHour, array)
			t.ParseMinute_CharSequence_Z_Z_I1__V(text, isColon, true, array)
			t.ParseSecond_CharSequence_Z_Z_I1__V(text, isColon, true, array); case 9, 10, 21:


			t.ParseHour_CharSequence_Z_I1__V(text, paddedHour, array)
			t.ParseOptionalMinuteSecond_CharSequence_Z_I1__V(text, isColon, array); case 12:
			t.ParseVariableWidthDigits_CharSequence_I_I_I1__V(text, 1, 4, array); case 14:
			t.ParseVariableWidthDigits_CharSequence_I_I_I1__V(text, 3, 4, array); case 16:
			t.ParseVariableWidthDigits_CharSequence_I_I_I1__V(text, 3, 6, array); case 18:
			t.ParseVariableWidthDigits_CharSequence_I_I_I1__V(text, 5, 6, array); case 20:
			t.ParseVariableWidthDigits_CharSequence_I_I_I1__V(text, 1, 6, array); default:}
		if array.A[0] > 0 {
			var tmp14 bool; var tmp15 bool; var tmp16 bool; tmp16 = array.A[1] > 23; if !tmp16 { tmp16 = array.A[2] > 59 }; tmp15 = tmp16; if !tmp15 { tmp15 = array.A[3] > 59 }; tmp14 = tmp15; if tmp14 {
				panic(Thrown(DateTimeException_New_String(Lit_2333)))
			}
			var tmp17 int64 = int64(array.A[1]) * 3600; var tmp18 int64 = tmp17 + int64(array.A[2])*60; var offsetSecs int64 = int64(negative) * (tmp18 + int64(array.A[3])); var tmp19 *ChronoField






			ChronoField_Init(); tmp19 = ChronoField_OFFSET_SECONDS; var tmp20 TemporalField = Up_ChronoField_TemporalField(tmp19); return NN(context).SetParsedField_TemporalField_J_I_I__I(tmp20, offsetSecs, position, array.A[0])
		}
	}


	if noOffsetLen == 0 {
		var tmp21 *ChronoField; ChronoField_Init(); tmp21 = ChronoField_OFFSET_SECONDS; return NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp21), 0, position, position) } else {
			return ^position
		} }
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) ParseHour_CharSequence_Z_I1__V(parseText CharSequence, paddedHour bool, array *IntArray) {
	if paddedHour {
		if t.ParseDigits_CharSequence_Z_I_I1__Z(parseText, false, 1, array) { } else {
			array.A[0] = ^array.A[0] } } else {
				t.ParseVariableWidthDigits_CharSequence_I_I_I1__V(parseText, 1, 2, array)
			} }
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) ParseMinute_CharSequence_Z_Z_I1__V(parseText CharSequence, isColon, mandatory bool, array *IntArray) {

	if t.ParseDigits_CharSequence_Z_I_I1__Z(parseText, isColon, 2, array) { } else {
		if mandatory { array.A[0] = ^array.A[0]
		} } }
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) ParseSecond_CharSequence_Z_Z_I1__V(parseText CharSequence, isColon, mandatory bool, array *IntArray) {

	if t.ParseDigits_CharSequence_Z_I_I1__Z(parseText, isColon, 3, array) { } else {
		if mandatory { array.A[0] = ^array.A[0]
		} } }
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) ParseOptionalMinuteSecond_CharSequence_Z_I1__V(parseText CharSequence, isColon bool, array *IntArray) {

	if t.ParseDigits_CharSequence_Z_I_I1__Z(parseText, isColon, 2, array) {
		t.ParseDigits_CharSequence_Z_I_I1__Z(parseText, isColon, 3, array)
	} }
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) ParseDigits_CharSequence_Z_I_I1__Z(parseText CharSequence, isColon bool, arrayIndex int32, array *IntArray) bool {

	var pos int32 = array.A[0]
	if pos < 0 { return true } else {


		var tmp1 bool; var tmp2 bool; tmp2 = isColon; if tmp2 { tmp2 = !(arrayIndex == 1) }; tmp1 = tmp2; if tmp1 {
			var tmp3 bool; var tmp4 bool; tmp4 = pos+1 > parseText.Length__I(); if !tmp4 {
				tmp4 = !(int32(parseText.CharAt_I__C(pos)) == 58) }
//line :1967:1
			tmp3 = tmp4; if tmp3 {

				return false }
			pos = pos + 1 }
		if pos+2 > parseText.Length__I() { return false } else {

			var ch1 uint16; var tmp5 int32; var old_7 int32 = pos
			pos = pos + 1; tmp5 = old_7
//line :1973:1
			ch1 = parseText.CharAt_I__C(tmp5); var ch2 uint16; var tmp6 int32
			var old_8 int32 = pos

			pos = pos + 1; tmp6 = old_8
//line :1975:1
			ch2 = parseText.CharAt_I__C(tmp6)

			var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = int32(ch1) < 48; if !tmp10 { tmp10 = int32(ch1) > 57 }; tmp9 = tmp10; if !tmp9 { tmp9 = int32(ch2) < 48 }; tmp8 = tmp9; if !tmp8 { tmp8 = int32(ch2) > 57 }; tmp7 = tmp8; if tmp7 { return false } else {

				var value int32 = (int32(ch1)-48)*10 + (int32(ch2) - 48); var tmp11 bool; var tmp12 bool


				tmp12 = value < 0; if !tmp12 { tmp12 = value > 59 }; tmp11 = tmp12; if tmp11 { return false } else {

					array.A[arrayIndex] = value; array.A[0] = pos; return true
				} } } } }
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) ParseVariableWidthDigits_CharSequence_I_I_I1__V(parseText CharSequence, minDigits, maxDigits int32, array *IntArray) {

	var pos int32 = array.A[0]; var available int32 = 0; var chars *CharArray = NewCharArray(maxDigits)
	var i int32 = 0

L1: for {
	if i < maxDigits {
		if pos+1 > parseText.Length__I() { } else {
			var ch uint16; var tmp1 int32; var old_9 int32 = pos
			pos = pos + 1; tmp1 = old_9
//line :1994:1
			ch = parseText.CharAt_I__C(tmp1)

			var tmp2 bool; var tmp3 bool; tmp3 = int32(ch) < 48; if !tmp3 { tmp3 = int32(ch) > 57 }; tmp2 = tmp3; if tmp2 {
				pos = pos - 1 } else {

					chars.A[i] = ch
					available = available + 1
					i = i + 1; continue L1 } } }
//line :1991:1
	break L1
}









	if available < minDigits {
		array.A[0] = ^array.A[0] } else {

			switch available { case 1:
				array.A[1] = int32(chars.A[0]) - 48; case 2:

				var tmp4 int32 = (int32(chars.A[0]) - 48) * 10; array.A[1] = tmp4 + (int32(chars.A[1]) - 48); case 3:






				array.A[1] = int32(chars.A[0]) - 48
				var tmp5 int32 = (int32(chars.A[1]) - 48) * 10; array.A[2] = tmp5 + (int32(chars.A[2]) - 48); case 4:






				var tmp6 int32 = (int32(chars.A[0]) - 48) * 10; array.A[1] = tmp6 + (int32(chars.A[1]) - 48)




				var tmp7 int32 = (int32(chars.A[2]) - 48) * 10; array.A[2] = tmp7 + (int32(chars.A[3]) - 48); case 5:






				array.A[1] = int32(chars.A[0]) - 48
				var tmp8 int32 = (int32(chars.A[1]) - 48) * 10; array.A[2] = tmp8 + (int32(chars.A[2]) - 48)




				var tmp9 int32 = (int32(chars.A[3]) - 48) * 10; array.A[3] = tmp9 + (int32(chars.A[4]) - 48); case 6:






				var tmp10 int32 = (int32(chars.A[0]) - 48) * 10; array.A[1] = tmp10 + (int32(chars.A[1]) - 48)




				var tmp11 int32 = (int32(chars.A[2]) - 48) * 10; array.A[2] = tmp11 + (int32(chars.A[3]) - 48)




				var tmp12 int32 = (int32(chars.A[4]) - 48) * 10; array.A[3] = tmp12 + (int32(chars.A[5]) - 48); default:
			}



			array.A[0] = pos
		} }
func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) ToString__String() *String {
	var converted *String = NN(t.F_noOffsetText).Replace_CharSequence_CharSequence__String(Lit_1371, Lit_1749)
	return Concat(Lit_2334, As[*String](DateTimeFormatterBuilder_OffsetIdPrinterParser_PATTERNS.A[t.F_type]), Lit_2335, converted, Lit_1675)
}





func DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_New_TextStyle(p0 *TextStyle) *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser { t := &DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser{}; t.Ctor_TextStyle(p0); return t }
//line :2074:1
func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) Ctor_TextStyle(style *TextStyle) { t.F_style = style }

func DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_AppendHMS_StringBuilder_I__StringBuilder(buf *StringBuilder, t_ int32) *StringBuilder {
	return NN(NN(buf).Append_C__StringBuilder(uint16(t_/10 + 48))).Append_C__StringBuilder(uint16(t_%10 + 48))
}

func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var offsetSecs *Long; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; offsetSecs = NN(context).GetValue_TemporalField_Z__Long(Up_ChronoField_TemporalField(tmp1), optional)
	if offsetSecs == nil { return false } else {

		var key *String = Lit_2323; var gmtText *String = String_Cast(DateTimeTextProvider_GetLocalizedResource_String_Locale__O(key, NN(context).GetLocale__Locale()))




		if gmtText == nil { gmtText = Lit_1972 }
		NN(buf).Append_String__StringBuilder(gmtText)
		var totalSecs int32 = Math_ToIntExact_J__I(NN(offsetSecs).LongValue__J())
		if totalSecs == 0 { } else {
			var absHours int32 = Math_Abs_I__I(totalSecs / 3600 % 100); var absMinutes int32 = Math_Abs_I__I(totalSecs / 60 % 60); var absSeconds int32 = Math_Abs_I__I(totalSecs % 60); var tmp2 *String






			if totalSecs < 0 { tmp2 = Lit_1134 } else { tmp2 = Lit_1135 }; NN(buf).Append_String__StringBuilder(tmp2)
			var tmp3 *TextStyle = t.F_style; var tmp4 *TextStyle; TextStyle_Init(); tmp4 = TextStyle_FULL; if tmp3 == tmp4 {

				DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_AppendHMS_StringBuilder_I__StringBuilder(buf, absHours)
				NN(buf).Append_C__StringBuilder(58)
				DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_AppendHMS_StringBuilder_I__StringBuilder(buf, absMinutes)
				if absSeconds == 0 { } else {
					NN(buf).Append_C__StringBuilder(58)
					DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_AppendHMS_StringBuilder_I__StringBuilder(buf, absSeconds) } } else {

						if absHours >= 10 {
							NN(buf).Append_C__StringBuilder(uint16(absHours/10 + 48))
						}

						NN(buf).Append_C__StringBuilder(uint16(absHours%10 + 48))


						var tmp5 bool; var tmp6 bool; tmp6 = !(absMinutes == 0); if !tmp6 { tmp6 = !(absSeconds == 0) }; tmp5 = tmp6; if tmp5 {
							NN(buf).Append_C__StringBuilder(58)
							DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_AppendHMS_StringBuilder_I__StringBuilder(buf, absMinutes)
							if absSeconds == 0 { } else {
								NN(buf).Append_C__StringBuilder(58)
								DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_AppendHMS_StringBuilder_I__StringBuilder(buf, absSeconds) } } } }
//line :2092:1
		return true
	}
}































func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) GetDigit_CharSequence_I__I(text CharSequence, position int32) int32 {
	var c uint16 = text.CharAt_I__C(position); var tmp1 bool; var tmp2 bool; tmp2 = int32(c) < 48; if !tmp2 { tmp2 = int32(c) > 57 }; tmp1 = tmp2; if tmp1 { return -1 } else { return int32(c) - 48
	} }
func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var pos int32 = position; var end int32 = text.Length__I(); var key *String = Lit_2323; var gmtText *String = String_Cast(DateTimeTextProvider_GetLocalizedResource_String_Locale__O(key, NN(context).GetLocale__Locale()))






	if gmtText == nil { gmtText = Lit_1972 }
	if !NN(context).SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(text, pos, Up_String_CharSequence(gmtText), 0, NN(gmtText).Length__I()) {
		return ^position } else {

			pos = pos + NN(gmtText).Length__I()
			var negative int32 = 0
			if pos == end {
				var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; return NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp1), 0, position, pos) } else {
					var sign uint16 = text.CharAt_I__C(pos)
					if int32(sign) == 43 {
						negative = 1 } else {
//line :2146:1
							if int32(sign) == 45 {

								negative = -1 } else {

									var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_OFFSET_SECONDS; return NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp2), 0, position, pos)
								}
						}



					pos = pos + 1
					var h int32 = 0; var m int32 = 0; var s int32 = 0; var tmp3 *TextStyle = t.F_style; var tmp4 *TextStyle


					TextStyle_Init(); tmp4 = TextStyle_FULL; if tmp3 == tmp4 {
						var h1 int32; var tmp5 int32
						var old_10 int32 = pos

						pos = pos + 1
//line :2163:1
						tmp5 = old_10
//line :2161:1
						h1 = t.GetDigit_CharSequence_I__I(text, tmp5); var h2 int32; var tmp6 int32
						var old_11 int32 = pos






						pos = pos + 1
//line :2168:1
						tmp6 = old_11
//line :2166:1
						h2 = t.GetDigit_CharSequence_I__I(text, tmp6)




						var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = h1 < 0; if !tmp9 { tmp9 = h2 < 0 }; tmp8 = tmp9; if !tmp8 {
							var tmp10 int32
							var old_12 int32 = pos


							pos = pos + 1
//line :2175:1
							tmp10 = old_12
//line :2172:1
							tmp8 = !(int32(text.CharAt_I__C(tmp10)) == 58) }
//line :2171:1
						tmp7 = tmp8; if tmp7 {







							return ^position }
						h = h1*10 + h2
						var m1 int32; var tmp11 int32
						var old_13 int32 = pos


						pos = pos + 1
//line :2184:1
						tmp11 = old_13
//line :2181:1
						m1 = t.GetDigit_CharSequence_I__I(text, tmp11); var m2 int32; var tmp12 int32
						var old_14 int32 = pos








						pos = pos + 1
//line :2190:1
						tmp12 = old_14
//line :2187:1
						m2 = t.GetDigit_CharSequence_I__I(text, tmp12)





						var tmp13 bool; var tmp14 bool; tmp14 = m1 < 0; if !tmp14 { tmp14 = m2 < 0 }; tmp13 = tmp14; if tmp13 { return ^position }
						m = m1*10 + m2
						var tmp15 bool; var tmp16 bool; tmp16 = pos+2 < end; if tmp16 {
							tmp16 = int32(text.CharAt_I__C(pos)) == 58 }
//line :2195:1
						tmp15 = tmp16; if tmp15 {

							var s1 int32 = t.GetDigit_CharSequence_I__I(text, pos+1); var s2 int32 = t.GetDigit_CharSequence_I__I(text, pos+2); var tmp17 bool; var tmp18 bool

							tmp18 = s1 >= 0; if tmp18 { tmp18 = s2 >= 0 }; tmp17 = tmp18; if tmp17 {
								s = s1*10 + s2
								pos = pos + 3 } } } else {

									h = t.GetDigit_CharSequence_I__I(text, pos)
									pos = pos + 1
									if h < 0 { return ^position }
									if pos < end {
										var h2_2 int32 = t.GetDigit_CharSequence_I__I(text, pos)
										if h2_2 >= 0 {
											h = h*10 + h2_2
											pos = pos + 1 }
										var tmp19 bool; var tmp20 bool; tmp20 = pos+2 < end; if tmp20 {
											tmp20 = int32(text.CharAt_I__C(pos)) == 58 }
//line :2211:1
										tmp19 = tmp20; if tmp19 {

											var tmp21 bool; var tmp22 bool; tmp22 = pos+2 < end; if tmp22 {
												tmp22 = int32(text.CharAt_I__C(pos)) == 58 }
//line :2213:1
											tmp21 = tmp22; if tmp21 {

												var m1_2 int32 = t.GetDigit_CharSequence_I__I(text, pos+1); var m2_2 int32 = t.GetDigit_CharSequence_I__I(text, pos+2); var tmp23 bool; var tmp24 bool

												tmp24 = m1_2 >= 0; if tmp24 { tmp24 = m2_2 >= 0 }; tmp23 = tmp24; if tmp23 {
													m = m1_2*10 + m2_2



													pos = pos + 3
													var tmp25 bool; var tmp26 bool
													tmp26 = pos+2 < end
//line :2223:1
													if tmp26 {

														tmp26 = int32(text.CharAt_I__C(pos)) == 58 }
//line :2223:1
													tmp25 = tmp26; if tmp25 {


														var s1_2 int32 = t.GetDigit_CharSequence_I__I(text, pos+1); var s2_2 int32 = t.GetDigit_CharSequence_I__I(text, pos+2); var tmp27 bool; var tmp28 bool

														tmp28 = s1_2 >= 0; if tmp28 { tmp28 = s2_2 >= 0 }; tmp27 = tmp28; if tmp27 {
															s = s1_2*10 + s2_2




															pos = pos + 3 } } } } } } }
					var offsetSecs int64 = int64(negative) * (int64(h)*3600 + int64(m)*60 + int64(s)); var tmp29 *ChronoField






					ChronoField_Init(); tmp29 = ChronoField_OFFSET_SECONDS; return NN(context).SetParsedField_TemporalField_J_I_I__I(Up_ChronoField_TemporalField(tmp29), offsetSecs, position, pos)
				}
		}
}


func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) ToString__String() *String {
	return Concat(Lit_2324, StrOfObj(t.F_style.Ref()), Lit_1176)
}









func DateTimeFormatterBuilder_ZoneTextPrinterParser_New_TextStyle_Set_Z(p0 *TextStyle, p1 Set, p2 bool) *DateTimeFormatterBuilder_ZoneTextPrinterParser { DateTimeFormatterBuilder_ZoneTextPrinterParser_Init(); t := &DateTimeFormatterBuilder_ZoneTextPrinterParser{}; t.Ctor_TextStyle_Set_Z(p0, p1, p2); return t }
//line :2260:1
func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) Ctor_TextStyle_Set_Z(textStyle *TextStyle, preferredZones Set, isGeneric bool) { t.DateTimeFormatterBuilder_ZoneIdPrinterParser.Ctor_TemporalQuery_String(t, TemporalQueries_Zone__TemporalQuery(), Concat(Lit_2363, StrOfObj(textStyle.Ref()), Lit_1176)); t.F_cachedTree = HashMap_NewHashMap_I__HashMap(1); t.F_cachedTreeCI = HashMap_NewHashMap_I__HashMap(1)


	t.F_textStyle = TextStyle_Cast(Objects_RequireNonNull_O_String__O(textStyle.Ref(), Lit_2260))
	t.F_isGeneric = isGeneric
	var tmp1 bool; var tmp2 bool; tmp2 = !(preferredZones == nil); if tmp2 { tmp2 = !(preferredZones.Size__I() == 0) }; tmp1 = tmp2; if tmp1 {
		t.F_preferredZones = HashSet_New()
		var i_101620 Iterator = preferredZones.Iterator__Iterator(); for i_101620.HasNext__Z() { var id ZoneId_I = ZoneId_Cast(i_101620.Next__O()); var tmp3 Set = t.F_preferredZones; tmp3.Add_O__Z(id.GetId__String().Ref())
		}
	}
}









func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) GetDisplayName_String_I_Locale__String(id *String, type_ int32, locale *Locale) *String {
	{ var tmp1 *TextStyle = t.F_textStyle; var tmp2 *TextStyle; TextStyle_Init(); tmp2 = TextStyle_NARROW; if tmp1 == tmp2 { return nil } else {
		var names *RefArray; var ref *SoftReference = SoftReference_Cast(DateTimeFormatterBuilder_ZoneTextPrinterParser_cache.Get_O__O(id.Ref())); var perLocale Map; var tmp3 bool; var tmp4 bool; var tmp5 bool


		tmp5 = ref == nil; if !tmp5 { var tmp6 Map; perLocale = Map_Cast(NN(ref).Get__O()); tmp6 = perLocale; tmp5 = tmp6 == nil }; tmp4 = tmp5; if !tmp4 {
			var tmp7 *RefArray; names = A2g_CastArray[*RefArray](perLocale.Get_O__O(locale.Ref()), String_class.ArrayClass()); tmp7 = names; tmp4 = tmp7 == nil }
//line :2285:1
		tmp3 = tmp4; if tmp3 {

			names = TimeZoneNameUtility_RetrieveDisplayNames_String_Locale__String1(id, locale)
			if names == nil { return nil }
			names = A2g_CastArray[*RefArray](Arrays_CopyOfRange_O1_I_I__O1(names, 0, 7).Ref(), String_class.ArrayClass())
			names.Store(5, TimeZoneNameUtility_RetrieveGenericDisplayName_String_I_Locale__String(id, 1, locale).Ref())
			if As[*String](names.A[5]) == nil { names.Store(5, As[*String](names.A[0]).Ref()) }
			names.Store(6, TimeZoneNameUtility_RetrieveGenericDisplayName_String_I_Locale__String(id, 0, locale).Ref())
			if As[*String](names.A[6]) == nil { names.Store(6, As[*String](names.A[0]).Ref()) }
			if perLocale == nil { perLocale = ConcurrentHashMap_New() }
			perLocale.Put_O_O__O(locale.Ref(), names.Ref())
			var tmp8 Map = DateTimeFormatterBuilder_ZoneTextPrinterParser_cache; tmp8.Put_O_O__O(id.Ref(), SoftReference_New_O(perLocale)) }
		switch type_ { case 0:
			return As[*String](names.A[NN(t.F_textStyle).ZoneNameStyleIndex__I()+1]); case 1:
			return As[*String](names.A[NN(t.F_textStyle).ZoneNameStyleIndex__I()+3]); default:
			return As[*String](names.A[NN(t.F_textStyle).ZoneNameStyleIndex__I()+5])} } }; panic("a2g: unreachable")
}
func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var zone ZoneId_I = ZoneId_Cast(NN(context).GetValue_TemporalQuery_Z__O(TemporalQueries_ZoneId__TemporalQuery(), optional))
	if zone == nil { return false } else {

		var zname *String = zone.GetId__String()
		if ZoneOffset_InstanceOf(zone) { } else {
			var dt TemporalAccessor = NN(context).GetTemporal__TemporalAccessor()
			var type_ int32 = 2
			if t.F_isGeneric { } else {
				var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_INSTANT_SECONDS; if dt.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp1)) {

					var tmp2 int32
					if NN(zone.GetRules__ZoneRules()).IsDaylightSavings_Instant__Z(Instant_From_TemporalAccessor__Instant(dt)) { tmp2 = 1 } else { tmp2 = 0 }
//line :2314:1
					type_ = tmp2 } else {
//line :2312:1
						var tmp3 bool; var tmp4 bool; var tmp5 *ChronoField



						ChronoField_Init(); tmp5 = ChronoField_EPOCH_DAY; tmp4 = dt.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp5)); if tmp4 {
							var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_NANO_OF_DAY; tmp4 = dt.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp6)) }
//line :2316:1
						tmp3 = tmp4
//line :2312:1
						if tmp3 {





							var date *LocalDate; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_EPOCH_DAY; date = LocalDate_OfEpochDay_J__LocalDate(dt.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp7))); var time *LocalTime; var tmp8 *ChronoField
							ChronoField_Init(); tmp8 = ChronoField_NANO_OF_DAY; time = LocalTime_OfNanoOfDay_J__LocalTime(dt.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp8)))
//line :2318:1
							var ldt *LocalDateTime = NN(date).AtTime_LocalTime__LocalDateTime(time)


							if NN(zone.GetRules__ZoneRules()).GetTransition_LocalDateTime__ZoneOffsetTransition(ldt) == nil {
								var tmp9 int32
								if NN(zone.GetRules__ZoneRules()).IsDaylightSavings_Instant__Z(NN(NN(ldt).AtZone_ZoneId__ZonedDateTime(zone)).ToInstant__Instant()) { tmp9 = 1 } else { tmp9 = 0 }
//line :2322:1
								type_ = tmp9
							}
						}
					}
			}

			var name *String = t.GetDisplayName_String_I_Locale__String(zname, type_, NN(context).GetLocale__Locale())
			if !(name == nil) { zname = name } }
		NN(buf).Append_String__StringBuilder(zname)
//line :2307:1
		return true
	}
}





























func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) GetTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(context *DateTimeParseContext) DateTimeFormatterBuilder_PrefixTree_I {
	var tmp1 *TextStyle = t.F_textStyle; var tmp2 *TextStyle; TextStyle_Init(); tmp2 = TextStyle_NARROW; if tmp1 == tmp2 {
		return t.DateTimeFormatterBuilder_ZoneIdPrinterParser.Impl_GetTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(t, context) } else {
			var locale *Locale = NN(context).GetLocale__Locale(); var isCaseSensitive bool = NN(context).IsCaseSensitive__Z(); var availableZoneIds Set = ZoneRulesProvider_GetAvailableZoneIds__Set(); var regionIdsSize int32 = availableZoneIds.Size__I(); var cached Map




			if isCaseSensitive { cached = t.F_cachedTree } else { cached = t.F_cachedTreeCI }
//line :2342:1
			var entry Map_Entry; var tree DateTimeFormatterBuilder_PrefixTree_I; var zoneStrings *RefArray; var tmp3 bool; var tmp4 bool; var tmp5 Map_Entry








			entry = Map_Entry_Cast(cached.Get_O__O(locale.Ref())); tmp5 = entry; tmp4 = tmp5 == nil; if !tmp4 {
				var tmp6 bool; tmp6 = !(NN(Integer_Cast(entry.GetKey__O())).IntValue__I() == regionIdsSize); if !tmp6 {
					var tmp7 DateTimeFormatterBuilder_PrefixTree_I; tree = DateTimeFormatterBuilder_PrefixTree_Cast(NN(SoftReference_Cast(entry.GetValue__O())).Get__O()); tmp7 = tree; tmp6 = tmp7 == nil }
//line :2352:1
				tmp4 = tmp6 }
//line :2351:1
			tmp3 = tmp4; if tmp3 {




				tree = DateTimeFormatterBuilder_PrefixTree_NewTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(context)
				zoneStrings = TimeZoneNameUtility_GetZoneStrings_Locale__String2(locale)
				var nonRegionIds Set = HashSet_NewHashSet_I__HashSet(64); var regionIds Set = HashSet_New_Collection(availableZoneIds); var arr_101623 *RefArray = zoneStrings; var len_101624 int32 = int32(len(arr_101623.A)); var i_101625 int32 = 0; for ; i_101625 < len_101624; i_101625++ {

					var names *RefArray = As[*RefArray](arr_101623.A[i_101625]); var zid *String = As[*String](names.A[0])

					if !regionIds.Remove_O__Z(zid.Ref()) {
						nonRegionIds.Add_O__Z(zid.Ref()) } else {

							tree.Add_String_String_I__Z(zid, zid, -1)
							zid = ZoneName_ToZid_String_Locale__String(zid, locale)
							var i int32; var tmp8 *TextStyle = t.F_textStyle; var tmp9 *TextStyle; TextStyle_Init(); tmp9 = TextStyle_FULL; if tmp8 == tmp9 { i = 1 } else { i = 2 }
						L2: for { if i < int32(len(names.A)) {
							var tmp10 DateTimeFormatterBuilder_PrefixTree_I = tree; var tmp11 *String = As[*String](names.A[i]); tmp10.Add_String_String_I__Z(tmp11, zid, (i-1)/2)



							i = i + 2
//line :2368:1
							continue L2 }; break L2
						}
						}
				}


				var t_ DateTimeFormatterBuilder_PrefixTree_I = tree
				regionIds.Stream__Stream().Filter_Predicate__Stream(&Predicate_Fn{Fn: func(p0 any) bool { var zid_2 *String = String_Cast(p0); var tmp12 bool; var tmp13 bool; tmp13 =

					!NN(zid_2).StartsWith_String__Z(Lit_2364); if tmp13 {
						tmp13 = !NN(zid_2).StartsWith_String__Z(Lit_1972) }; tmp12 = tmp13; return tmp12 },
				},
				).ForEach_Consumer__V(/*line :2375:1*/&Consumer_Fn{Fn: func(p0_2 any) { var cid *String = String_Cast(p0_2); var cidNames *RefArray = TimeZoneNameUtility_RetrieveDisplayNames_String_Locale__String1(cid, locale); var i_2 int32; var tmp14 *TextStyle = t.F_textStyle; var tmp15 *TextStyle;





					TextStyle_Init(); tmp15 = TextStyle_FULL; if tmp14 == tmp15 { i_2 = 1 } else { i_2 = 2 }; L3:
					for { if i_2 < int32(len(cidNames.A)) {
						var tmp16 bool; var tmp17 bool; tmp17 = !(As[*String](cidNames.A[i_2]) == nil); if tmp17 {
							tmp17 = !NN(As[*String](cidNames.A[i_2])).IsEmpty__Z() }
//line :2383:1
						tmp16 = tmp17; if tmp16 {

							var tmp18 *String = As[*String](cidNames.A[i_2]); t_.Add_String_String_I__Z(tmp18, cid, (i_2-1)/2)
						}


						i_2 = i_2 + 2
//line :2382:1
						continue L3 }; break L3 } },
				},
				)





				if !(t.F_preferredZones == nil) {
					var arr_101626 *RefArray = zoneStrings; var len_101627 int32 = int32(len(arr_101626.A)); var i_101628 int32 = 0; for ; i_101628 < len_101627; i_101628++ { var names_2 *RefArray = As[*RefArray](arr_101626.A[i_101628]); var zid_3 *String = As[*String](names_2.A[0]); var tmp19 bool; var tmp20 bool

						tmp20 = !t.F_preferredZones.Contains_O__Z(zid_3.Ref()); if !tmp20 {
							tmp20 = nonRegionIds.Contains_O__Z(zid_3.Ref()) }
//line :2393:1
						tmp19 = tmp20; if tmp19 { } else {

							var i_3 int32; var tmp21 *TextStyle = t.F_textStyle; var tmp22 *TextStyle; TextStyle_Init(); tmp22 = TextStyle_FULL; if tmp21 == tmp22 { i_3 = 1 } else { i_3 = 2 }
						L5: for { if i_3 < int32(len(names_2.A)) {
							var tmp23 DateTimeFormatterBuilder_PrefixTree_I = tree; var tmp24 *String = As[*String](names_2.A[i_3]); tmp23.Add_String_String_I__Z(tmp24, zid_3, (i_3-1)/2)



							i_3 = i_3 + 2
//line :2396:1
							continue L5 }; break L5
						}
						}
					}
				}

				cached.Put_O_O__O(locale.Ref(), AbstractMap_SimpleImmutableEntry_New_O_O(Integer_ValueOf_I__Integer(regionIdsSize), SoftReference_New_O(tree))) }
//line :2342:1
			return tree
		}
}





































































func DateTimeFormatterBuilder_ZoneIdPrinterParser_New_TemporalQuery_String(p0 TemporalQuery, p1 *String) *DateTimeFormatterBuilder_ZoneIdPrinterParser { t := &DateTimeFormatterBuilder_ZoneIdPrinterParser{}; t.Ctor_TemporalQuery_String(t, p0, p1); return t }
//line :2414:1
func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Ctor_TemporalQuery_String(this DateTimeFormatterBuilder_ZoneIdPrinterParser_I, query TemporalQuery, description *String) {
	t.F_query = query
	t.F_description = description
}
func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Impl_Format_DateTimePrintContext_StringBuilder_Z__Z(this DateTimeFormatterBuilder_ZoneIdPrinterParser_I, context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var zone ZoneId_I = ZoneId_Cast(NN(context).GetValue_TemporalQuery_Z__O(t.F_query, optional))
	if zone == nil { return false } else { NN(buf).Append_String__StringBuilder(zone.GetId__String()); return true
	}
}



func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Impl_GetTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(this DateTimeFormatterBuilder_ZoneIdPrinterParser_I, context *DateTimeParseContext) DateTimeFormatterBuilder_PrefixTree_I {
	var regionIds Set = ZoneRulesProvider_GetAvailableZoneIds__Set(); var regionIdsSize int32 = regionIds.Size__I(); var cached Map_Entry

	if NN(context).IsCaseSensitive__Z() { cached = DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTree.Load() } else { cached = DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTreeCI.Load()
	}

	var tmp1 bool; var tmp2 bool; tmp2 = cached == nil; if !tmp2 {
		tmp2 = !(NN(Integer_Cast(cached.GetKey__O())).IntValue__I() == regionIdsSize) }
//line :2433:1
	tmp1 = tmp2; if tmp1 {

		var tmp3 any = this; MonitorEnter(tmp3); func() { defer MonitorExit(tmp3)
			var tmp4 Map_Entry; if NN(context).IsCaseSensitive__Z() { tmp4 = DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTree.Load() } else { tmp4 = DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTreeCI.Load() }; cached = tmp4
			var tmp5 bool; var tmp6 bool; tmp6 = cached == nil; if !tmp6 {
				tmp6 = !(NN(Integer_Cast(cached.GetKey__O())).IntValue__I() == regionIdsSize) }
//line :2437:1
			tmp5 = tmp6; if tmp5 {

				cached = AbstractMap_SimpleImmutableEntry_New_O_O(Integer_ValueOf_I__Integer(regionIdsSize), DateTimeFormatterBuilder_PrefixTree_NewTree_Set_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(regionIds, context))



				if NN(context).IsCaseSensitive__Z() {
					DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTree.Store(cached) } else {
						DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTreeCI.Store(cached) } } }() }
	return DateTimeFormatterBuilder_PrefixTree_Cast(cached.GetValue__O())
}
func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Impl_Parse_DateTimeParseContext_CharSequence_I__I(this DateTimeFormatterBuilder_ZoneIdPrinterParser_I, context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var length int32 = text.Length__I()
	if position > length { panic(Thrown(IndexOutOfBoundsException_New())) }
	if position == length {
		return ^position } else {
			var nextChar uint16 = text.CharAt_I__C(position); var tmp1 bool; var tmp2 bool
			tmp2 = int32(nextChar) == 43; if !tmp2 { tmp2 = int32(nextChar) == 45 }; tmp1 = tmp2; if tmp1 {
				var tmp3 *DateTimeFormatterBuilder_OffsetIdPrinterParser; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp3 = DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_Z; return t.Impl_ParseOffsetBased_DateTimeParseContext_CharSequence_I_I_DateTimeFormatterBuilder_OffsetIdPrinterParser__I(this, context, text, position, position, tmp3) } else {






					if length >= position+2 {
						var nextNextChar uint16 = text.CharAt_I__C(position + 1); var tmp4 bool; var tmp5 bool
						tmp5 = NN(context).CharEquals_C_C__Z(nextChar, 85); if tmp5 {
							tmp5 = NN(context).CharEquals_C_C__Z(nextNextChar, 84) }
//line :2464:1
						tmp4 = tmp5; if tmp4 {

							var tmp6 bool; var tmp7 bool; tmp7 = length >= position+3; if tmp7 {
								tmp7 = NN(context).CharEquals_C_C__Z(text.CharAt_I__C(position+2), 67) }
//line :2466:1
							tmp6 = tmp7; if tmp6 {




								var tmp8 bool; var tmp9 bool; tmp9 = length > position+3; if tmp9 {
									tmp9 = NN(context).CharEquals_C_C__Z(text.CharAt_I__C(position+3), 8722) }
//line :2471:1
								tmp8 = tmp9; if tmp8 {




									var tmpText *String = Lit_2361.Formatted_O1__String(RefArrayOf(Object_class, text.SubSequence_I_I__CharSequence(0, position+3), text.SubSequence_I_I__CharSequence(position+4, text.Length__I()))); var tmp10 int32 = position + 3; var tmp11 *DateTimeFormatterBuilder_OffsetIdPrinterParser









									DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp11 = DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_ZERO; return t.Impl_ParseOffsetBased_DateTimeParseContext_CharSequence_I_I_DateTimeFormatterBuilder_OffsetIdPrinterParser__I(this, context, Up_String_CharSequence(tmpText), position, tmp10, tmp11) } else {






										var tmp12 int32 = position + 3; var tmp13 *DateTimeFormatterBuilder_OffsetIdPrinterParser; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp13 = DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_ZERO; return t.Impl_ParseOffsetBased_DateTimeParseContext_CharSequence_I_I_DateTimeFormatterBuilder_OffsetIdPrinterParser__I(this, context, text, position, tmp12, tmp13) } } else {






											var tmp14 int32 = position + 2; var tmp15 *DateTimeFormatterBuilder_OffsetIdPrinterParser; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp15 = DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_ZERO; return t.Impl_ParseOffsetBased_DateTimeParseContext_CharSequence_I_I_DateTimeFormatterBuilder_OffsetIdPrinterParser__I(this, context, text, position, tmp14, tmp15) } } else {






												var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 bool
												tmp19 = NN(context).CharEquals_C_C__Z(nextChar, 71)
//line :2507:1
												if tmp19 {

													tmp19 = length >= position+3 }
//line :2507:1
												tmp18 = tmp19; if tmp18 {


													tmp18 = NN(context).CharEquals_C_C__Z(nextNextChar, 77) }
//line :2507:1
												tmp17 = tmp18; if tmp17 {



													tmp17 = NN(context).CharEquals_C_C__Z(text.CharAt_I__C(position+2), 84) }
//line :2507:1
												tmp16 = tmp17; if tmp16 {







													var tmp20 bool; var tmp21 bool; tmp21 = length >= position+4; if tmp21 {
														tmp21 = NN(context).CharEquals_C_C__Z(text.CharAt_I__C(position+3), 48) }
//line :2515:1
													tmp20 = tmp21; if tmp20 {




														NN(context).SetParsed_ZoneId__V(ZoneId_Of_String__ZoneId(Lit_2362))
														return position + 4 }
													var tmp22 int32 = position + 3; var tmp23 *DateTimeFormatterBuilder_OffsetIdPrinterParser; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp23 = DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_ZERO; return t.Impl_ParseOffsetBased_DateTimeParseContext_CharSequence_I_I_DateTimeFormatterBuilder_OffsetIdPrinterParser__I(this, context, text, position, tmp22, tmp23)
												}
											}
					}



					var tree DateTimeFormatterBuilder_PrefixTree_I = this.GetTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(context); var ppos *ParsePosition = ParsePosition_New_I(position); var parsedZoneId DateTimeFormatterBuilder_PrefixTree_I = tree.Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(text, ppos)


					if parsedZoneId.Self_DateTimeFormatterBuilder_PrefixTree().F_value == nil {
						if NN(context).CharEquals_C_C__Z(nextChar, 90) {

							var tmp24 *ZoneOffset; ZoneOffset_Init(); tmp24 = ZoneOffset_UTC; NN(context).SetParsed_ZoneId__V(Up_ZoneOffset_ZoneId(tmp24))
							return position + 1 } else {
								return ^position } } else {

									NN(context).SetParsed_ZoneId__V(ZoneId_Of_String__ZoneId(parsedZoneId.Self_DateTimeFormatterBuilder_PrefixTree().F_value))
									NN(context).SetParsedZoneNameType_I__V(parsedZoneId.Self_DateTimeFormatterBuilder_PrefixTree().F_type)
									return NN(ppos).GetIndex__I()
								} } } }
func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Impl_ParseOffsetBased_DateTimeParseContext_CharSequence_I_I_DateTimeFormatterBuilder_OffsetIdPrinterParser__I(this DateTimeFormatterBuilder_ZoneIdPrinterParser_I, context *DateTimeParseContext, text CharSequence, prefixPos, position int32, parser *DateTimeFormatterBuilder_OffsetIdPrinterParser) int32 {


	var prefix *String; var tmp1 *String = text.SubSequence_I_I__CharSequence(prefixPos, position).ToString__String(); var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; prefix = NN(tmp1).ToUpperCase_Locale__String(tmp2)
	if position >= text.Length__I() {
		NN(context).SetParsed_ZoneId__V(ZoneId_Of_String__ZoneId(prefix)); return position } else {
//line :2547:1
			var tmp3 bool; var tmp4 bool

			tmp4 = int32(text.CharAt_I__C(position)) == 48; if !tmp4 { tmp4 = NN(context).CharEquals_C_C__Z(text.CharAt_I__C(position), 90) }; tmp3 = tmp4
//line :2547:1
			if tmp3 {


				NN(context).SetParsed_ZoneId__V(ZoneId_Of_String__ZoneId(prefix)); return position } else {

					var newContext *DateTimeParseContext = NN(context).Copy__DateTimeParseContext(); var endPos int32 = NN(parser).Parse_DateTimeParseContext_CharSequence_I__I(newContext, text, position); var tmp5 int32; tmp8 := func() (exc Throwable_I) { defer Catch(&exc)


						if endPos < 0 {
							var tmp6 *DateTimeFormatterBuilder_OffsetIdPrinterParser; DateTimeFormatterBuilder_OffsetIdPrinterParser_Init(); tmp6 = DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_Z; if parser == tmp6 {
								tmp5 = ^prefixPos } else {
									NN(context).SetParsed_ZoneId__V(ZoneId_Of_String__ZoneId(prefix)); tmp5 = position } } else {
										var offset int32; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_OFFSET_SECONDS; offset = int32(NN(NN(newContext).GetParsed_TemporalField__Long(Up_ChronoField_TemporalField(tmp7))).LongValue__J()); var zoneOffset *ZoneOffset = ZoneOffset_OfTotalSeconds_I__ZoneOffset(offset)


										NN(context).SetParsed_ZoneId__V(ZoneId_OfOffset_String_ZoneOffset__ZoneId(prefix, zoneOffset))
//line :2559:1
										tmp5 = endPos }
//line :2552:1
						return nil
					}()
					if tmp8 != nil { if DateTimeException_InstanceOf(tmp8) { var dte DateTimeException_I = DateTimeException_Cast(tmp8); _ = dte









						tmp5 = ^prefixPos } else {
//line :2554:1
							panic(tmp8) } }; return tmp5
				}
		}
}








func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Impl_ToString__String(this DateTimeFormatterBuilder_ZoneIdPrinterParser_I) *String { return t.F_description }














func DateTimeFormatterBuilder_PrefixTree_New_String_String_I_DateTimeFormatterBuilder_PrefixTree(p0, p1 *String, p2 int32, p3 DateTimeFormatterBuilder_PrefixTree_I) *DateTimeFormatterBuilder_PrefixTree { t := &DateTimeFormatterBuilder_PrefixTree{}; t.Ctor_String_String_I_DateTimeFormatterBuilder_PrefixTree(t, p0, p1, p2, p3); return t }
//line :2581:1
func (t *DateTimeFormatterBuilder_PrefixTree) Ctor_String_String_I_DateTimeFormatterBuilder_PrefixTree(this DateTimeFormatterBuilder_PrefixTree_I, k, v *String, type_ int32, child DateTimeFormatterBuilder_PrefixTree_I) {
	t.F_key = k
	t.F_value = v
	t.F_type = type_
	t.F_child = child
	if NN(k).IsEmpty__Z() { t.F_c0 = 65535 } else { t.F_c0 = NN(t.F_key).CharAt_I__C(0)
	} }
func DateTimeFormatterBuilder_PrefixTree_NewTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(context *DateTimeParseContext) DateTimeFormatterBuilder_PrefixTree_I {
	if NN(context).IsCaseSensitive__Z() {
		return DateTimeFormatterBuilder_PrefixTree_New_String_String_I_DateTimeFormatterBuilder_PrefixTree(Lit_69, nil, -1, nil) } else {
			return DateTimeFormatterBuilder_PrefixTree_CI_New_String_String_I_DateTimeFormatterBuilder_PrefixTree(Lit_69, nil, -1, nil)
		} }
func DateTimeFormatterBuilder_PrefixTree_NewTree_Set_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(keys Set, context *DateTimeParseContext) DateTimeFormatterBuilder_PrefixTree_I {

	var tree DateTimeFormatterBuilder_PrefixTree_I = DateTimeFormatterBuilder_PrefixTree_NewTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(context); var i_101629 Iterator = keys.Iterator__Iterator(); for i_101629.HasNext__Z() {
		var k *String = String_Cast(i_101629.Next__O()); tree.Self_DateTimeFormatterBuilder_PrefixTree().Impl_Add0_String_String_I__Z(tree, k, k, -1) }
//line :2595:1
	return tree
}


func (t *DateTimeFormatterBuilder_PrefixTree) Impl_CopyTree__DateTimeFormatterBuilder_PrefixTree(this DateTimeFormatterBuilder_PrefixTree_I) DateTimeFormatterBuilder_PrefixTree_I {
	var copy_ DateTimeFormatterBuilder_PrefixTree_I = DateTimeFormatterBuilder_PrefixTree_New_String_String_I_DateTimeFormatterBuilder_PrefixTree(t.F_key, t.F_value, t.F_type, nil)
	if !(t.F_child == nil) { copy_.Self_DateTimeFormatterBuilder_PrefixTree().F_child = t.F_child.CopyTree__DateTimeFormatterBuilder_PrefixTree() }
	if !(t.F_sibling == nil) { copy_.Self_DateTimeFormatterBuilder_PrefixTree().F_sibling = t.F_sibling.CopyTree__DateTimeFormatterBuilder_PrefixTree() }
//line :2600:1
	return copy_
}



func (t *DateTimeFormatterBuilder_PrefixTree) Impl_Add_String_String_I__Z(this DateTimeFormatterBuilder_PrefixTree_I, k, v *String, t_ int32) bool {
	return t.Impl_Add0_String_String_I__Z(this, k, v, t_)
}
func (t *DateTimeFormatterBuilder_PrefixTree) Impl_Add0_String_String_I__Z(this DateTimeFormatterBuilder_PrefixTree_I, k, v *String, t_ int32) bool {
	k = this.ToKey_String__String(k)
	var prefixLen int32 = t.Impl_PrefixLength_String__I(this, k)
	if prefixLen == NN(t.F_key).Length__I() {
		if prefixLen < NN(k).Length__I() {
			var subKey *String = NN(k).Substring_I__String(prefixLen); var c DateTimeFormatterBuilder_PrefixTree_I = t.F_child

		L1: for { if !(c == nil) {
			var tmp1 uint16 = c.Self_DateTimeFormatterBuilder_PrefixTree().F_c0; if this.IsEqual_C_C__Z(tmp1, NN(subKey).CharAt_I__C(0)) { return c.Self_DateTimeFormatterBuilder_PrefixTree().Impl_Add0_String_String_I__Z(c, subKey, v, t_) }
			c = c.Self_DateTimeFormatterBuilder_PrefixTree().F_sibling
//line :2615:1
			continue L1 }; break L1
		}

			c = this.NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(subKey, v, t_, nil)
			c.Self_DateTimeFormatterBuilder_PrefixTree().F_sibling = t.F_child
			t.F_child = c
//line :2613:1
			return true





		} else {


			t.F_value = v; t.F_type = t_; return true } } else {
				var n1 DateTimeFormatterBuilder_PrefixTree_I = this.NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(NN(t.F_key).Substring_I__String(prefixLen), t.F_value, t.F_type, t.F_child)
				t.F_key = NN(k).Substring_I_I__String(0, prefixLen)
				t.F_child = n1
				if prefixLen < NN(k).Length__I() {
					var n2 DateTimeFormatterBuilder_PrefixTree_I = this.NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(NN(k).Substring_I__String(prefixLen), v, t_, nil)
					t.F_child.Self_DateTimeFormatterBuilder_PrefixTree().F_sibling = n2
					t.F_value = nil } else {
						t.F_value = v; t.F_type = t_ }
//line :2623:1
				return true
			}
}







func (t *DateTimeFormatterBuilder_PrefixTree) Impl_Match_CharSequence_I_I__DateTimeFormatterBuilder_PrefixTree(this DateTimeFormatterBuilder_PrefixTree_I, text CharSequence, off, end int32) DateTimeFormatterBuilder_PrefixTree_I {
	if !this.PrefixOf_CharSequence_I_I__Z(text, off, end) { return nil } else {
		var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_child == nil); if tmp2 { var tmp3 int32; off = off + NN(t.F_key).Length__I(); tmp3 = off; tmp2 = !(tmp3 == end) }; tmp1 = tmp2; if tmp1 {
			var c DateTimeFormatterBuilder_PrefixTree_I = t.F_child
		L1: for {
			var tmp4 uint16 = c.Self_DateTimeFormatterBuilder_PrefixTree().F_c0; if this.IsEqual_C_C__Z(tmp4, text.CharAt_I__C(off)) {
				var found DateTimeFormatterBuilder_PrefixTree_I = c.Match_CharSequence_I_I__DateTimeFormatterBuilder_PrefixTree(text, off, end)
				if !(found == nil) { return found }
				return this }
			c = c.Self_DateTimeFormatterBuilder_PrefixTree().F_sibling
			if !(c == nil) { continue L1 }
//line :2637:1
			break L1 } }
//line :2634:1
		return this
	}
}









func (t *DateTimeFormatterBuilder_PrefixTree) Impl_Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(this DateTimeFormatterBuilder_PrefixTree_I, text CharSequence, pos *ParsePosition) DateTimeFormatterBuilder_PrefixTree_I {
	var off int32 = NN(pos).GetIndex__I(); var end int32 = text.Length__I()

	if !this.PrefixOf_CharSequence_I_I__Z(text, off, end) { return nil } else {
		off = off + NN(t.F_key).Length__I()
		var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_child == nil); if tmp2 { tmp2 = !(off == end) }; tmp1 = tmp2; if tmp1 {
			var c DateTimeFormatterBuilder_PrefixTree_I = t.F_child
		L1: for {
			var tmp3 uint16 = c.Self_DateTimeFormatterBuilder_PrefixTree().F_c0; if this.IsEqual_C_C__Z(tmp3, text.CharAt_I__C(off)) {
				NN(pos).SetIndex_I__V(off)
				var found DateTimeFormatterBuilder_PrefixTree_I = c.Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(text, pos); if !(found == nil) { return found }; break L1 }
			c = c.Self_DateTimeFormatterBuilder_PrefixTree().F_sibling
			if !(c == nil) { continue L1 }
//line :2653:1
			break L1
		}
		}



		NN(pos).SetIndex_I__V(off)
//line :2649:1
		return this
	}
}










func (t *DateTimeFormatterBuilder_PrefixTree) Impl_ToKey_String__String(this DateTimeFormatterBuilder_PrefixTree_I, k *String) *String { return k }

func (t *DateTimeFormatterBuilder_PrefixTree) Impl_NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(this DateTimeFormatterBuilder_PrefixTree_I, k, v *String, t_ int32, child DateTimeFormatterBuilder_PrefixTree_I) DateTimeFormatterBuilder_PrefixTree_I {
	return DateTimeFormatterBuilder_PrefixTree_New_String_String_I_DateTimeFormatterBuilder_PrefixTree(k, v, t_, child)
}
func (t *DateTimeFormatterBuilder_PrefixTree) Impl_IsEqual_C_C__Z(this DateTimeFormatterBuilder_PrefixTree_I, c1, c2 uint16) bool {
	return int32(c1) == int32(c2)
}
func (t *DateTimeFormatterBuilder_PrefixTree) Impl_PrefixOf_CharSequence_I_I__Z(this DateTimeFormatterBuilder_PrefixTree_I, text CharSequence, off, end int32) bool {
	if String_InstanceOf(text) {
		return NN(String_Cast(text)).StartsWith_String_I__Z(t.F_key, off) } else {
			var len_ int32 = NN(t.F_key).Length__I()
			if len_ > end-off { return false } else {

				var off0 int32 = 0
			L1: for { var tmp1 int32; var old_15 int32 = len_; len_ = len_ - 1; tmp1 = old_15; if tmp1 > 0 {
				var tmp2 *String = t.F_key; var tmp3 int32
				var old_16 int32 = off0


				off0 = off0 + 1
//line :2681:1
				tmp3 = old_16
//line :2678:1
				var tmp4 uint16 = NN(tmp2).CharAt_I__C(tmp3); var tmp5 int32
				var old_17 int32 = off







				off = off + 1
//line :2686:1
				tmp5 = old_17
//line :2678:1
				if this.IsEqual_C_C__Z(tmp4, text.CharAt_I__C(tmp5)) { } else {










					return false }
//line :2677:1
				continue L1 }; break L1 }
//line :2676:1
				return true
			}
		}
}












func (t *DateTimeFormatterBuilder_PrefixTree) Impl_PrefixLength_String__I(this DateTimeFormatterBuilder_PrefixTree_I, k *String) int32 {
	var off int32 = 0
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = off < NN(k).Length__I(); if tmp2 { tmp2 = off < NN(t.F_key).Length__I() }; tmp1 = tmp2; if tmp1 {
	if this.IsEqual_C_C__Z(NN(k).CharAt_I__C(off), NN(t.F_key).CharAt_I__C(off)) { } else { return off }
	off = off + 1
//line :2694:1
	continue L1 }; break L1 }
//line :2693:1
	return off
}







func DateTimeFormatterBuilder_PrefixTree_CI_New_String_String_I_DateTimeFormatterBuilder_PrefixTree(p0, p1 *String, p2 int32, p3 DateTimeFormatterBuilder_PrefixTree_I) *DateTimeFormatterBuilder_PrefixTree_CI { t := &DateTimeFormatterBuilder_PrefixTree_CI{}; t.Ctor_String_String_I_DateTimeFormatterBuilder_PrefixTree(p0, p1, p2, p3); return t }
//line :2702:1
func (t *DateTimeFormatterBuilder_PrefixTree_CI) Ctor_String_String_I_DateTimeFormatterBuilder_PrefixTree(k, v *String, t_ int32, child DateTimeFormatterBuilder_PrefixTree_I) { t.DateTimeFormatterBuilder_PrefixTree.Ctor_String_String_I_DateTimeFormatterBuilder_PrefixTree(t, k, v, t_, child) }


func (t *DateTimeFormatterBuilder_PrefixTree_CI) NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree_CI(k, v *String, t_ int32, child DateTimeFormatterBuilder_PrefixTree_I) *DateTimeFormatterBuilder_PrefixTree_CI {
	return DateTimeFormatterBuilder_PrefixTree_CI_New_String_String_I_DateTimeFormatterBuilder_PrefixTree(k, v, t_, child)
}
func (t *DateTimeFormatterBuilder_PrefixTree_CI) IsEqual_C_C__Z(c1, c2 uint16) bool {
	return DateTimeParseContext_CharEqualsIgnoreCase_C_C__Z(c1, c2)
}
func (t *DateTimeFormatterBuilder_PrefixTree_CI) PrefixOf_CharSequence_I_I__Z(text CharSequence, off, end int32) bool {
	var len_ int32 = NN(t.F_key).Length__I()
	if len_ > end-off { return false } else {

		var off0 int32 = 0
	L1: for { var tmp1 int32; var old_18 int32 = len_; len_ = len_ - 1; tmp1 = old_18; if tmp1 > 0 {
		var tmp2 *String = t.F_key; var tmp3 int32
		var old_19 int32 = off0

		off0 = off0 + 1
//line :2719:1
		tmp3 = old_19
//line :2717:1
		var tmp4 uint16 = NN(tmp2).CharAt_I__C(tmp3); var tmp5 int32
		var old_20 int32 = off





		off = off + 1
//line :2723:1
		tmp5 = old_20
//line :2717:1
		if t.IsEqual_C_C__Z(tmp4, text.CharAt_I__C(tmp5)) { } else {








			return false }
//line :2716:1
		continue L1 }; break L1 }
//line :2715:1
		return true
	}
}
















func DateTimeFormatterBuilder_ChronoPrinterParser_New_TextStyle(p0 *TextStyle) *DateTimeFormatterBuilder_ChronoPrinterParser { t := &DateTimeFormatterBuilder_ChronoPrinterParser{}; t.Ctor_TextStyle(p0); return t }
//line :2734:1
func (t *DateTimeFormatterBuilder_ChronoPrinterParser) Ctor_TextStyle(textStyle *TextStyle) {
	t.F_textStyle = textStyle
}
func (t *DateTimeFormatterBuilder_ChronoPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var chrono Chronology = Chronology_Cast(NN(context).GetValue_TemporalQuery_Z__O(TemporalQueries_Chronology__TemporalQuery(), optional))
	if chrono == nil { return false } else {


		if t.F_textStyle == nil {
			NN(buf).Append_String__StringBuilder(chrono.GetId__String()) } else {
				NN(buf).Append_String__StringBuilder(t.GetChronologyName_Chronology_Locale__String(chrono, NN(context).GetLocale__Locale())) }
//line :2742:1
		return true
	}
}



func (t *DateTimeFormatterBuilder_ChronoPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = position < 0; if !tmp2 { tmp2 = position > text.Length__I() }; tmp1 = tmp2; if tmp1 { panic(Thrown(IndexOutOfBoundsException_New())) }
	var chronos Set = Chronology_GetAvailableChronologies__Set(); var bestMatch Chronology; var matchLen int32 = -1; var i_101630 Iterator = chronos.Iterator__Iterator(); for i_101630.HasNext__Z() {


		var chrono Chronology = Chronology_Cast(i_101630.Next__O()); var name *String
		if t.F_textStyle == nil {
			name = chrono.GetId__String() } else {
				name = t.GetChronologyName_Chronology_Locale__String(chrono, NN(context).GetLocale__Locale()) }
		var nameLen int32 = NN(name).Length__I(); var tmp3 bool; var tmp4 bool
		tmp4 = nameLen > matchLen; if tmp4 {
			tmp4 = NN(context).SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(text, position, Up_String_CharSequence(name), 0, nameLen) }
//line :2758:1
		tmp3 = tmp4; if tmp3 {

			bestMatch = chrono
			matchLen = nameLen } }
	if bestMatch == nil {
		return ^position } else {
			NN(context).SetParsed_Chronology__V(bestMatch); return position + matchLen
		} }
func (t *DateTimeFormatterBuilder_ChronoPrinterParser) GetChronologyName_Chronology_Locale__String(chrono Chronology, locale *Locale) *String {
	var key *String = Concat(Lit_2290, chrono.GetCalendarType__String()); var name *String = String_Cast(DateTimeTextProvider_GetLocalizedResource_String_Locale__O(key, locale))

	return String_Cast(Objects_RequireNonNullElseGet_O_Supplier__O(name.Ref(), &Supplier_Fn{Fn: func() any { return chrono.GetId__String().Ref() }}))
}













func DateTimeFormatterBuilder_LocalizedPrinterParser_New_FormatStyle_FormatStyle(p0, p1 *FormatStyle) *DateTimeFormatterBuilder_LocalizedPrinterParser { DateTimeFormatterBuilder_LocalizedPrinterParser_Init(); t := &DateTimeFormatterBuilder_LocalizedPrinterParser{}; t.Ctor_FormatStyle_FormatStyle(p0, p1); return t }
//line :2784:1
func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Ctor_FormatStyle_FormatStyle(dateStyle, timeStyle *FormatStyle) {
	t.F_dateStyle = dateStyle
	t.F_timeStyle = timeStyle
	t.F_requestedTemplate = nil
}
func DateTimeFormatterBuilder_LocalizedPrinterParser_New_String(p0 *String) *DateTimeFormatterBuilder_LocalizedPrinterParser { DateTimeFormatterBuilder_LocalizedPrinterParser_Init(); t := &DateTimeFormatterBuilder_LocalizedPrinterParser{}; t.Ctor_String(p0); return t }
//line :2789:1
func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Ctor_String(requestedTemplate *String) {
	t.F_dateStyle = nil
	t.F_timeStyle = nil
	t.F_requestedTemplate = requestedTemplate
}
func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var chrono Chronology = Chronology_From_TemporalAccessor__Chronology(NN(context).GetTemporal__TemporalAccessor())
	return NN(NN(t.Formatter_Locale_Chronology__DateTimeFormatter(NN(context).GetLocale__Locale(), chrono)).ToPrinterParser_Z__DateTimeFormatterBuilder_CompositePrinterParser(false)).Format_DateTimePrintContext_StringBuilder_Z__Z(context, buf, optional)
}



func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	var chrono Chronology = NN(context).GetEffectiveChronology__Chronology()
	return NN(NN(t.Formatter_Locale_Chronology__DateTimeFormatter(NN(context).GetLocale__Locale(), chrono)).ToPrinterParser_Z__DateTimeFormatterBuilder_CompositePrinterParser(false)).Parse_DateTimeParseContext_CharSequence_I__I(context, text, position)
}



func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Formatter_Locale_Chronology__DateTimeFormatter(locale *Locale, chrono Chronology) *DateTimeFormatter {
	var key *String; var tmp1 *String = chrono.GetId__String(); var tmp2 *String = NN(locale).ToString__String(); var tmp3 *String



	if !(t.F_requestedTemplate == nil) { tmp3 = t.F_requestedTemplate } else {

		tmp3 = Concat(Objects_ToString_O__String(t.F_dateStyle.Ref()), StrOfObj(t.F_timeStyle.Ref())) }
//line :2810:1
	key = Concat(tmp1, Lit_1448, tmp2, Lit_1448, tmp3)






	var tmp4 ConcurrentMap = DateTimeFormatterBuilder_LocalizedPrinterParser_FORMATTER_CACHE; return DateTimeFormatter_Cast(tmp4.ComputeIfAbsent_O_Function__O(key.Ref(), &Function_Fn{Fn: func(p0 any) any { var k *String = String_Cast(p0); var tmp5 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp6 *String; _ = k; if






		!(t.F_requestedTemplate == nil) {
			tmp6 = DateTimeFormatterBuilder_GetLocalizedDateTimePattern_String_Chronology_Locale__String(t.F_requestedTemplate, chrono, locale) } else {



				tmp6 = DateTimeFormatterBuilder_GetLocalizedDateTimePattern_FormatStyle_FormatStyle_Chronology_Locale__String(t.F_dateStyle, t.F_timeStyle, chrono, locale) }; return /*line :2817:1*/ NN(tmp5.AppendPattern_String__DateTimeFormatterBuilder(tmp6)).ToFormatter_Locale__DateTimeFormatter(locale).Ref() }}))
}

















func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) ToString__String() *String {
	var tmp1 *String
	if !(t.F_requestedTemplate == nil) { tmp1 = t.F_requestedTemplate } else {

		var tmp2 Serializable; if !(t.F_dateStyle == nil) { tmp2 = Up_FormatStyle_Serializable(t.F_dateStyle) } else { tmp2 = Lit_69 }; var tmp3 Serializable = tmp2; var tmp4 Serializable

		if !(t.F_timeStyle == nil) { tmp4 = Up_FormatStyle_Serializable(t.F_timeStyle) } else { tmp4 = Lit_69 }
//line :2840:1
		tmp1 = Concat(StrOfObj(tmp3), Lit_1532, StrOfObj(tmp4)) }
//line :2837:1
	return Concat(Lit_2325, tmp1, Lit_1176)
}













func DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I(p0 uint16, p1, p2, p3 int32) *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser { DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_Init(); t := &DateTimeFormatterBuilder_WeekBasedFieldPrinterParser{}; t.Ctor_C_I_I_I(p0, p1, p2, p3); return t }
//line :2852:1
func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) Ctor_C_I_I_I(chr uint16, count, minWidth, maxWidth int32) { t.Ctor_C_I_I_I_I(chr, count, minWidth, maxWidth, 0) }


func DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I_I(p0 uint16, p1, p2, p3, p4 int32) *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser { DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_Init(); t := &DateTimeFormatterBuilder_WeekBasedFieldPrinterParser{}; t.Ctor_C_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :2855:1
func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) Ctor_C_I_I_I_I(chr uint16, count, minWidth, maxWidth, subsequentWidth int32) { var tmp1 *SignStyle; SignStyle_Init(); tmp1 = SignStyle_NOT_NEGATIVE; t.DateTimeFormatterBuilder_NumberPrinterParser.Ctor_TemporalField_I_I_SignStyle_I(t, nil, minWidth, maxWidth, tmp1, subsequentWidth);


	t.F_chr = chr;
	t.F_count = count }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_WeekBasedFieldPrinterParser() *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser {
	if t.F_subsequentWidth == -1 { return t } else {

		return DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I_I(t.F_chr, t.F_count, t.F_minWidth, t.F_maxWidth, -1)
	} }
func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_WeekBasedFieldPrinterParser(subsequentWidth int32) *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser {
	return DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_New_C_I_I_I_I(t.F_chr, t.F_count, t.F_minWidth, t.F_maxWidth, t.F_subsequentWidth+subsequentWidth)
}




func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	return t.PrinterParser_Locale__DateTimeFormatterBuilder_DateTimePrinterParser(NN(context).GetLocale__Locale()).Format_DateTimePrintContext_StringBuilder_Z__Z(context, buf, optional)
}
func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, text CharSequence, position int32) int32 {
	return t.PrinterParser_Locale__DateTimeFormatterBuilder_DateTimePrinterParser(NN(context).GetLocale__Locale()).Parse_DateTimeParseContext_CharSequence_I__I(context, text, position)
}
func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) PrinterParser_Locale__DateTimeFormatterBuilder_DateTimePrinterParser(locale *Locale) DateTimeFormatterBuilder_DateTimePrinterParser {
	var weekDef *WeekFields = WeekFields_Of_Locale__WeekFields(locale); var field TemporalField

	switch int32(t.F_chr) { case 89:


		field = NN(weekDef).WeekBasedYear__TemporalField()
		if t.F_count == 2 {
			var tmp1 TemporalField = field; var tmp2 *LocalDate; DateTimeFormatterBuilder_ReducedPrinterParser_Init(); tmp2 = DateTimeFormatterBuilder_ReducedPrinterParser_BASE_DATE; return DateTimeFormatterBuilder_ReducedPrinterParser_New_TemporalField_I_I_I_ChronoLocalDate_I(tmp1, 2, 2, 0, Up_LocalDate_ChronoLocalDate(tmp2), t.F_subsequentWidth) } else {






				var tmp3 TemporalField = field; var tmp4 int32 = t.F_count; var tmp5 *SignStyle


				if t.F_count < 4 { SignStyle_Init(); tmp5 = SignStyle_NORMAL } else { SignStyle_Init(); tmp5 = SignStyle_EXCEEDS_PAD }
//line :2895:1
				return DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle_I(tmp3, tmp4, 19, tmp5, t.F_subsequentWidth)
			}

	case 101, 99:



		field = NN(weekDef).DayOfWeek__TemporalField(); case 119:
		field = NN(weekDef).WeekOfWeekBasedYear__TemporalField(); case 87:
		field = NN(weekDef).WeekOfMonth__TemporalField(); default:
		panic(Thrown(IllegalStateException_New_String(Lit_2354)))}
	var tmp6 TemporalField = field; var tmp7 int32 = t.F_minWidth; var tmp8 int32 = t.F_maxWidth; var tmp9 *SignStyle; SignStyle_Init(); tmp9 = SignStyle_NOT_NEGATIVE; return DateTimeFormatterBuilder_NumberPrinterParser_New_TemporalField_I_I_SignStyle_I(tmp6, tmp7, tmp8, tmp9, t.F_subsequentWidth)
}




func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) ToString__String() *String {
	var sb *StringBuilder = StringBuilder_New_I(30)
	NN(sb).Append_String__StringBuilder(Lit_2325)
	if int32(t.F_chr) == 89 {
		if t.F_count == 1 {
			NN(sb).Append_String__StringBuilder(Lit_2355) } else {
//line :2916:1
				if t.F_count == 2 {

					NN(sb).Append_String__StringBuilder(Lit_2356) } else {

						var tmp1 *StringBuilder = NN(NN(NN(NN(NN(sb).Append_String__StringBuilder(Lit_2357)).Append_I__StringBuilder(t.F_count)).Append_String__StringBuilder(Lit_1532)).Append_I__StringBuilder(19)).Append_String__StringBuilder(Lit_1532); var tmp2 *SignStyle



						if t.F_count < 4 { SignStyle_Init(); tmp2 = SignStyle_NORMAL } else { SignStyle_Init(); tmp2 = SignStyle_EXCEEDS_PAD }
//line :2920:1
						NN(tmp1).Append_O__StringBuilder(tmp2.Ref()) } } } else {





							switch int32(t.F_chr) { case 99, 101:
								NN(sb).Append_String__StringBuilder(Lit_2358); case 119:
								NN(sb).Append_String__StringBuilder(Lit_2359); case 87:
								NN(sb).Append_String__StringBuilder(Lit_2360); default:
							}
							NN(sb).Append_String__StringBuilder(Lit_1532)
							NN(sb).Append_I__StringBuilder(t.F_count) }
	NN(sb).Append_String__StringBuilder(Lit_1176)
	return NN(sb).ToString__String()
}








func DateTimeFormatterBuilder_DayPeriodPrinterParser_New_TextStyle(p0 *TextStyle) *DateTimeFormatterBuilder_DayPeriodPrinterParser { DateTimeFormatterBuilder_DayPeriodPrinterParser_Init(); t := &DateTimeFormatterBuilder_DayPeriodPrinterParser{}; t.Ctor_TextStyle(p0); return t }
//line :2944:1
func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) Ctor_TextStyle(textStyle *TextStyle) {
	t.F_textStyle = textStyle
}
func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(context *DateTimePrintContext, buf *StringBuilder, optional bool) bool {

	var hod *Long; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_HOUR_OF_DAY; hod = NN(context).GetValue_TemporalField_Z__Long(Up_ChronoField_TemporalField(tmp1), optional)
	if hod == nil { return false } else {

		var moh *Long; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MINUTE_OF_HOUR; moh = NN(context).GetValue_TemporalField_Z__Long(Up_ChronoField_TemporalField(tmp2), optional); var value int64; var tmp3 int32 = Math_FloorMod_J_I__I(NN(hod).LongValue__J(), 24) * 60; var tmp4 int32




		if !(moh == nil) { tmp4 = Math_FloorMod_J_I__I(NN(moh).LongValue__J(), 60) } else { tmp4 = 0 }
//line :2952:1
		value = int64(tmp3 + tmp4); var locale *Locale = NN(context).GetLocale__Locale(); var store *DateTimeTextProvider_LocaleStore = DateTimeFormatterBuilder_DayPeriodPrinterParser_FindDayPeriodStore_Locale__DateTimeTextProvider_LocaleStore(locale); var val int64 = value; var map_ Map = DateTimeFormatterBuilder_DayPeriod_GetDayPeriodMap_Locale__Map(locale); var tmp5 Stream = map_.KeySet__Set().Stream__Stream().Filter_Predicate__Stream(&Predicate_Fn{Fn: func(p0 any) bool {









			var k *DateTimeFormatterBuilder_DayPeriod = DateTimeFormatterBuilder_DayPeriod_Cast(p0); return NN(k).Includes_J__Z(val) }})
//line :2952:1
		var tmp6 Comparator









		DateTimeFormatterBuilder_DayPeriod_Init(); tmp6 = DateTimeFormatterBuilder_DayPeriod_DPCOMPARATOR; var tmp7 *Optional = tmp5.Min_Comparator__Optional(tmp6); var tmp8 Function; var tmp9 Map = A2g_NotNull[Map](map_)








		tmp8 = &Function_Fn{Fn: func(p0_2 any) any { return tmp9.Get_O__O(p0_2) }}
//line :2962:1
		value = NN(Long_Cast(NN(NN(tmp7).Map_Function__Optional(tmp8)).OrElse_O__O(Long_ValueOf_J__Long(val / 720)))).LongValue__J()














		var text *String = NN(store).GetText_J_TextStyle__String(value, t.F_textStyle); NN(buf).Append_String__StringBuilder(text); return true
	} }
func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(context *DateTimeParseContext, parseText CharSequence, position int32) int32 {

	var length int32 = parseText.Length__I(); var tmp1 bool; var tmp2 bool
	tmp2 = position < 0; if !tmp2 { tmp2 = position > length }; tmp1 = tmp2; if tmp1 { panic(Thrown(IndexOutOfBoundsException_New())) }
	var style *TextStyle; if NN(context).IsStrict__Z() { style = t.F_textStyle } else { style = nil }; var it Iterator; var store *DateTimeTextProvider_LocaleStore = DateTimeFormatterBuilder_DayPeriodPrinterParser_FindDayPeriodStore_Locale__DateTimeTextProvider_LocaleStore(NN(context).GetLocale__Locale())


	it = NN(store).GetTextIterator_TextStyle__Iterator(style)
	if !(it == nil) {
	L1: for { if it.HasNext__Z() {
		var entry Map_Entry = Map_Entry_Cast(it.Next__O()); var itText *String = String_Cast(entry.GetKey__O())

		if NN(context).SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(Up_String_CharSequence(itText), 0, parseText, position, NN(itText).Length__I()) {
			NN(context).SetParsedDayPeriod_DateTimeFormatterBuilder_DayPeriod__V(DateTimeFormatterBuilder_DayPeriod_OfLocale_Locale_J__DateTimeFormatterBuilder_DayPeriod(NN(context).GetLocale__Locale(), NN(Long_Cast(entry.GetValue__O())).LongValue__J()))



			return position + NN(itText).Length__I() }
//line :2988:1
		continue L1 }; break L1
	}
	}






	return ^position
}
func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) ToString__String() *String {
	return Concat(Lit_2312, StrOfObj(t.F_textStyle.Ref()), Lit_1176)
}
func DateTimeFormatterBuilder_DayPeriodPrinterParser_FindDayPeriodStore_Locale__DateTimeTextProvider_LocaleStore(locale *Locale) *DateTimeTextProvider_LocaleStore { DateTimeFormatterBuilder_DayPeriodPrinterParser_Init()
	var tmp1 ConcurrentMap = DateTimeFormatterBuilder_DayPeriodPrinterParser_DAYPERIOD_LOCALESTORE; return DateTimeTextProvider_LocaleStore_Cast(tmp1.ComputeIfAbsent_O_Function__O(locale.Ref(), &Function_Fn{Fn: func(p0 any) any { var loc *Locale = Locale_Cast(p0); var tmp2 *DateTimeTextProvider_LocaleStore; var styleMap Map = HashMap_New(); var arr_101635 *RefArray = TextStyle_Values__TextStyle1(); var len_101636 int32 = int32(len(arr_101635.A)); var i_101637 int32 = 0; for ; i_101637 < len_101636; i_101637++ {





		var textStyle *TextStyle = As[*TextStyle](arr_101635.A[i_101637])
		if NN(textStyle).IsStandalone__Z() { } else {
			var map_ Map = HashMap_New(); var calStyle int32 = NN(textStyle).ToCalendarStyle__I(); var periodMap Map = DateTimeFormatterBuilder_DayPeriod_GetDayPeriodMap_Locale__Map(loc)


			periodMap.ForEach_BiConsumer__V(&BiConsumer_Fn{Fn: func(p0_2, p1 any) { var key *DateTimeFormatterBuilder_DayPeriod = DateTimeFormatterBuilder_DayPeriod_Cast(p0_2); var value *Long = Long_Cast(p1); var displayName *String = CalendarDataUtility_RetrieveJavaTimeFieldValueName_String_I_I_I_Locale__String(Lit_2313, 9, NN(value).IntValue__I(), calStyle, loc); if








				!(displayName == nil) {
					map_.Put_O_O__O(value.Ref(), displayName.Ref()) } else {
						periodMap.Remove_O__O(key.Ref()) } }})
			if map_.IsEmpty__Z() { } else { styleMap.Put_O_O__O(textStyle.Ref(), map_) } } }; tmp2 =
		DateTimeTextProvider_LocaleStore_New_Map(styleMap); return /*line :3003:1*/ tmp2.Ref() }}))
}









































func DateTimeFormatterBuilder_DayPeriod_New_J_J_J(p0, p1, p2 int64) *DateTimeFormatterBuilder_DayPeriod { DateTimeFormatterBuilder_DayPeriod_Init(); t := &DateTimeFormatterBuilder_DayPeriod{}; t.Ctor_J_J_J(p0, p1, p2); return t }
//line :3046:1
func (t *DateTimeFormatterBuilder_DayPeriod) Ctor_J_J_J(from, to, index int64) {
	t.F_from = from
	t.F_to = to
	t.F_index = index
}
func (t *DateTimeFormatterBuilder_DayPeriod) GetIndex__J() int64 { return t.F_index }

func (t *DateTimeFormatterBuilder_DayPeriod) Mid__J() int64 {
	var tmp1 int64 = t.F_from; return (tmp1 + t.Duration__J()/2) % 1440
}
func (t *DateTimeFormatterBuilder_DayPeriod) Includes_J__Z(mod int64) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = t.F_from == 0; if tmp3 { tmp3 = t.F_to == 0 }; tmp2 = tmp3; if tmp2 { tmp2 = mod == 1440 }; tmp1 = tmp2; if tmp1 { return true } else {

		var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = t.F_from == mod; if tmp6 { tmp6 = t.F_to == mod }; tmp5 = tmp6; if !tmp5 { var tmp7 bool; tmp7 = t.F_from <= mod; if tmp7 { tmp7 = mod < t.F_to }; tmp5 = tmp7 }; tmp4 = tmp5; if !tmp4 {
			var tmp8 bool; tmp8 = t.F_from > t.F_to; if tmp8 { var tmp9 bool; tmp9 = t.F_from <= mod; if !tmp9 { tmp9 = t.F_to > mod }; tmp8 = tmp9 }; tmp4 = tmp8 }
//line :3059:1
		return tmp4
	}
}
func (t *DateTimeFormatterBuilder_DayPeriod) Duration__J() int64 {
	if t.F_from > t.F_to {
		return 1440 - t.F_from + t.F_to } else {
			return t.F_to - t.F_from
		} }
func DateTimeFormatterBuilder_DayPeriod_MapToIndex_String__J(type_ *String) int64 { DateTimeFormatterBuilder_DayPeriod_Init()
	{ var tmp1 *String = type_; var tmp2 int32 = -1; switch NN(tmp1).HashCode__I() { case -1640863024: if tmp1.Equals_O__Z(Lit_2293) { tmp2 = 2 }; case -1045618919: if tmp1.Equals_O__Z(Lit_2294) { tmp2 = 10 }; case -1045618918: if tmp1.Equals_O__Z(Lit_2295) { tmp2 = 11 }; case -209993491: if tmp1.Equals_O__Z(Lit_2296) { tmp2 = 4 }; case -209993490: if tmp1.Equals_O__Z(Lit_2297) { tmp2 = 5 }; case 3116: if tmp1.Equals_O__Z(Lit_2298) { tmp2 = 0 }; case 3581: if tmp1.Equals_O__Z(Lit_2299) { tmp2 = 1 }; case 3387232: if tmp1.Equals_O__Z(Lit_2300) { tmp2 = 3 }; case 277805225: if tmp1.Equals_O__Z(Lit_2301) { tmp2 = 8 }; case 277805226: if tmp1.Equals_O__Z(Lit_2302) { tmp2 = 9 }; case 1556119669: if tmp1.Equals_O__Z(Lit_2303) { tmp2 = 6 }; case 1556119670: if tmp1.Equals_O__Z(Lit_2304) { tmp2 = 7 }}; switch tmp2 { case 0:
		return 0; case 1:
		return 1; case 2:
//line :3068:1
		return 2

	case 3:
//line :3068:1
		return 3

	case 4:
//line :3068:1
		return 4

	case 5:
//line :3068:1
		return 5

	case 6:
//line :3068:1
		return 6

	case 7:
//line :3068:1
		return 7

	case 8:
//line :3068:1
		return 8

	case 9:
//line :3068:1
		return 9

	case 10:
//line :3068:1
		return 10

	case 11:
//line :3068:1
		return 11

	default:










		panic(Thrown(InternalError_New_String(Lit_2292)))} }; panic("a2g: unreachable")
}
func DateTimeFormatterBuilder_DayPeriod_GetDayPeriodMap_Locale__Map(locale *Locale) Map { DateTimeFormatterBuilder_DayPeriod_Init()
	var tmp1 Map = DateTimeFormatterBuilder_DayPeriod_DAYPERIOD_CACHE; return Map_Cast(tmp1.ComputeIfAbsent_O_Function__O(locale.Ref(), &Function_Fn{Fn: func(p0 any) any { var l *Locale = Locale_Cast(p0); var tmp2 Map; var lr *LocaleResources = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(CalendarDataUtility_FindRegionOverride_Locale__Locale(l)); var dayPeriodRules *String = As[*String](NN(lr).GetRules__String1().A[1]); var periodMap Map = ConcurrentHashMap_New();








		Arrays_Stream_O1__Stream(NN(dayPeriodRules).Split_String__String1(Lit_1743)).ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0_2 any) { var rule *String = String_Cast(p0_2); var m *Matcher = NN(DateTimeFormatterBuilder_DayPeriod_RULE).Matcher_CharSequence__Matcher(Up_String_CharSequence(rule)); if


			NN(m).Find__Z() {
				var from *String = NN(m).Group_String__String(Lit_2305); var to *String = NN(m).Group_String__String(Lit_2306); var index int64 = DateTimeFormatterBuilder_DayPeriod_MapToIndex_String__J(NN(m).Group_String__String(Lit_2307))



				if to == nil { to = from }
				periodMap.PutIfAbsent_O_O__O(DateTimeFormatterBuilder_DayPeriod_New_J_J_J(Long_ParseLong_String__J(from)*60, Long_ParseLong_String__J(to)*60, index), Long_ValueOf_J__Long(index)) } }});








		periodMap.PutIfAbsent_O_O__O(DateTimeFormatterBuilder_DayPeriod_New_J_J_J(0, 720, 0), Long_ValueOf_J__Long(0));
		periodMap.PutIfAbsent_O_O__O(DateTimeFormatterBuilder_DayPeriod_New_J_J_J(720, 1440, 1), Long_ValueOf_J__Long(1)); tmp2 = periodMap; return tmp2 },
	},
	)) }
func DateTimeFormatterBuilder_DayPeriod_OfLocale_Locale_J__DateTimeFormatterBuilder_DayPeriod(locale *Locale, index int64) *DateTimeFormatterBuilder_DayPeriod { DateTimeFormatterBuilder_DayPeriod_Init()
	return DateTimeFormatterBuilder_DayPeriod_Cast(NN(DateTimeFormatterBuilder_DayPeriod_GetDayPeriodMap_Locale__Map(locale).KeySet__Set().Stream__Stream().Filter_Predicate__Stream(&Predicate_Fn{Fn: func(p0 any) bool { var dp *DateTimeFormatterBuilder_DayPeriod = DateTimeFormatterBuilder_DayPeriod_Cast(p0); return NN(dp).GetIndex__J() == index }}).FindAny__Optional()).OrElseThrow_Supplier__O(&Supplier_Fn{Fn: func() any { return DateTimeException_New_String(Concat(Lit_2308, StrOfObj(locale.Ref()), Lit_2309, StrOfLong(index))) }}))
}









func (t *DateTimeFormatterBuilder_DayPeriod) Equals_O__Z(o any) bool {
	if any(t) == any(o) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = o == nil; if !tmp2 { tmp2 = !(t.GetClass__Class() == GetClass(o)) }; tmp1 = tmp2
//line :3128:1
		if tmp1 { return false } else {



			var dayPeriod *DateTimeFormatterBuilder_DayPeriod = DateTimeFormatterBuilder_DayPeriod_Cast(o); var tmp3 bool; var tmp4 bool; var tmp5 int64 = t.F_from
			tmp4 = tmp5 == dayPeriod.F_from; if tmp4 { var tmp6 int64 = t.F_to; tmp4 = tmp6 == dayPeriod.F_to }; tmp3 = tmp4; if tmp3 {
				var tmp7 int64 = t.F_index; tmp3 = tmp7 == dayPeriod.F_index }
//line :3133:1
			return tmp3
		}
	} }
func (t *DateTimeFormatterBuilder_DayPeriod) HashCode__I() int32 { return Objects_Hash_O1__I(RefArrayOf(Object_class, Long_ValueOf_J__Long(t.F_from), Long_ValueOf_J__Long(t.F_to), Long_ValueOf_J__Long(t.F_index))) }

func (t *DateTimeFormatterBuilder_DayPeriod) ToString__String() *String {
	var tmp1 any = Long_ValueOf_J__Long(t.F_from / 60); var tmp2 *String = Lit_2310.Formatted_O1__String(RefArrayOf(Object_class, tmp1, Long_ValueOf_J__Long(t.F_from%60))); var tmp3 *String

	if t.F_from == t.F_to { tmp3 = Lit_1176 } else {

		var tmp4 any = Long_ValueOf_J__Long(t.F_to / 60); tmp3 = Lit_2311.Formatted_O1__String(RefArrayOf(Object_class, tmp4, Long_ValueOf_J__Long(t.F_to%60))) }
//line :3139:1
	return Concat(tmp2, tmp3)
}






type DateTimeFormatterBuilder struct{ Object; F_active, F_parent *DateTimeFormatterBuilder; F_printerParsers List; F_optional bool; F_padNextWidth int32; F_padNextChar uint16; F_valueParserIndex int32 }

var DateTimeFormatterBuilder_QUERY_REGION_ONLY TemporalQuery

var DateTimeFormatterBuilder_VALID_TEMPLATE_PATTERN *Pattern

var DateTimeFormatterBuilder_init ClassInit

func DateTimeFormatterBuilder_Init() { if !DateTimeFormatterBuilder_init.Done() { DateTimeFormatterBuilder_init.Run(DateTimeFormatterBuilder_clinit) } }

func DateTimeFormatterBuilder_clinit() { DateTimeFormatterBuilder_QUERY_REGION_ONLY = &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any {
//line :48:1
	var temporal TemporalAccessor = p0; var tmp1 ZoneId_I; var zone ZoneId_I = ZoneId_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_ZoneId__TemporalQuery()))
	if ZoneOffset_InstanceOf(zone) { tmp1 = nil } else { tmp1 = zone }
//line :48:1
	return tmp1
}}; DateTimeFormatterBuilder_VALID_TEMPLATE_PATTERN =



































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































	Pattern_Compile_String__Pattern(Lit_2250) }

func (t *DateTimeFormatterBuilder) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder) GetClass__Class() *Class { return DateTimeFormatterBuilder_class }

func (t *DateTimeFormatterBuilder) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeFormatterBuilder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder); return ok }

func DateTimeFormatterBuilder_Cast(x any) *DateTimeFormatterBuilder { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_class)) }; return v }



type DateTimeFormatterBuilder_1 struct{ DateTimeTextProvider; F_this_0 *DateTimeFormatterBuilder; F_val_store *DateTimeTextProvider_LocaleStore }

var DateTimeFormatterBuilder_1_init ClassInit

func DateTimeFormatterBuilder_1_Init() { if !DateTimeFormatterBuilder_1_init.Done() { DateTimeFormatterBuilder_1_init.Run(DateTimeFormatterBuilder_1_clinit) } }

func DateTimeFormatterBuilder_1_clinit() { DateTimeTextProvider_Init() }

func DateTimeFormatterBuilder_1_New_DateTimeFormatterBuilder_DateTimeTextProvider_LocaleStore(p0 *DateTimeFormatterBuilder, p1 *DateTimeTextProvider_LocaleStore) *DateTimeFormatterBuilder_1 { DateTimeFormatterBuilder_1_Init(); t := &DateTimeFormatterBuilder_1{}; t.Ctor_DateTimeFormatterBuilder_DateTimeTextProvider_LocaleStore(p0, p1); return t }

func (t *DateTimeFormatterBuilder_1) Ctor_DateTimeFormatterBuilder_DateTimeTextProvider_LocaleStore(this_0 *DateTimeFormatterBuilder, val_store *DateTimeTextProvider_LocaleStore) { t.F_val_store = val_store; NN(this_0); t.F_this_0 = this_0; t.DateTimeTextProvider.Ctor(t) }

func (t *DateTimeFormatterBuilder_1) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_1) GetClass__Class() *Class { return DateTimeFormatterBuilder_1_class }

func (t *DateTimeFormatterBuilder_1) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeFormatterBuilder_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_1_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_1); return ok }

func DateTimeFormatterBuilder_1_Cast(x any) *DateTimeFormatterBuilder_1 { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_1); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_1_class)) }; return v }



type DateTimeFormatterBuilder_CharLiteralPrinterParser struct{ Object; F_literal uint16; F_isSpaceSeparator bool }

func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_CharLiteralPrinterParser_class }

func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_CharLiteralPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_CharLiteralPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_CharLiteralPrinterParser); return ok }

func DateTimeFormatterBuilder_CharLiteralPrinterParser_Cast(x any) *DateTimeFormatterBuilder_CharLiteralPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_CharLiteralPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_CharLiteralPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_ChronoPrinterParser struct{ Object; F_textStyle *TextStyle }

func (t *DateTimeFormatterBuilder_ChronoPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_ChronoPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_ChronoPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_ChronoPrinterParser_class }

func (t *DateTimeFormatterBuilder_ChronoPrinterParser) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeFormatterBuilder_ChronoPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_ChronoPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_ChronoPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_ChronoPrinterParser); return ok }

func DateTimeFormatterBuilder_ChronoPrinterParser_Cast(x any) *DateTimeFormatterBuilder_ChronoPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_ChronoPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_ChronoPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_CompositePrinterParser struct{ Object; F_printerParsers *RefArray; F_optional bool }

func (t *DateTimeFormatterBuilder_CompositePrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_CompositePrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_CompositePrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_CompositePrinterParser_class }

func (t *DateTimeFormatterBuilder_CompositePrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_CompositePrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_CompositePrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_CompositePrinterParser); return ok }

func DateTimeFormatterBuilder_CompositePrinterParser_Cast(x any) *DateTimeFormatterBuilder_CompositePrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_CompositePrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_CompositePrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_DateTimePrinterParser interface{ Object_I; Is_DateTimeFormatterBuilder_DateTimePrinterParser(); Format_DateTimePrintContext_StringBuilder_Z__Z(p0 *DateTimePrintContext, p1 *StringBuilder, p2 bool) bool; Parse_DateTimeParseContext_CharSequence_I__I(p0 *DateTimeParseContext, p1 CharSequence, p2 int32) int32 }

func DateTimeFormatterBuilder_DateTimePrinterParser_InstanceOf(x any) bool { _, ok := x.(DateTimeFormatterBuilder_DateTimePrinterParser); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DateTimeFormatterBuilder_DateTimePrinterParser_class) } }; return ok }

func DateTimeFormatterBuilder_DateTimePrinterParser_Cast(x any) DateTimeFormatterBuilder_DateTimePrinterParser { if x == nil { return nil }; v, ok := x.(DateTimeFormatterBuilder_DateTimePrinterParser); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DateTimeFormatterBuilder_DateTimePrinterParser_class) } }; if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_DateTimePrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_DayPeriod struct{ Object; F_from, F_to, F_index int64 }

var DateTimeFormatterBuilder_DayPeriod_DAYPERIOD_CACHE Map

var DateTimeFormatterBuilder_DayPeriod_DPCOMPARATOR Comparator

var DateTimeFormatterBuilder_DayPeriod_RULE *Pattern

var DateTimeFormatterBuilder_DayPeriod_init ClassInit

func DateTimeFormatterBuilder_DayPeriod_Init() { if !DateTimeFormatterBuilder_DayPeriod_init.Done() { DateTimeFormatterBuilder_DayPeriod_init.Run(DateTimeFormatterBuilder_DayPeriod_clinit) } }

func DateTimeFormatterBuilder_DayPeriod_clinit() { DateTimeFormatterBuilder_DayPeriod_DAYPERIOD_CACHE = ConcurrentHashMap_New(); DateTimeFormatterBuilder_DayPeriod_DPCOMPARATOR = &Comparator_Fn{Fn: func(p0, p1 any) int32 { var dp1 *DateTimeFormatterBuilder_DayPeriod = DateTimeFormatterBuilder_DayPeriod_Cast(p0); var dp2 *DateTimeFormatterBuilder_DayPeriod = DateTimeFormatterBuilder_DayPeriod_Cast(p1); return int32(NN(dp1).Duration__J() - NN(dp2).Duration__J()) }}; DateTimeFormatterBuilder_DayPeriod_RULE = Pattern_Compile_String__Pattern(Lit_2291) }

func (t *DateTimeFormatterBuilder_DayPeriod) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_DayPeriod) GetClass__Class() *Class { return DateTimeFormatterBuilder_DayPeriod_class }

func (t *DateTimeFormatterBuilder_DayPeriod) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_DayPeriod) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_DayPeriod_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_DayPeriod); return ok }

func DateTimeFormatterBuilder_DayPeriod_Cast(x any) *DateTimeFormatterBuilder_DayPeriod { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_DayPeriod); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_DayPeriod_class)) }; return v }



type DateTimeFormatterBuilder_DayPeriodPrinterParser struct{ Object; F_textStyle *TextStyle }

func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

var DateTimeFormatterBuilder_DayPeriodPrinterParser_DAYPERIOD_LOCALESTORE ConcurrentMap

var DateTimeFormatterBuilder_DayPeriodPrinterParser_init ClassInit

func DateTimeFormatterBuilder_DayPeriodPrinterParser_Init() { if !DateTimeFormatterBuilder_DayPeriodPrinterParser_init.Done() { DateTimeFormatterBuilder_DayPeriodPrinterParser_init.Run(DateTimeFormatterBuilder_DayPeriodPrinterParser_clinit) } }

func DateTimeFormatterBuilder_DayPeriodPrinterParser_clinit() { DateTimeFormatterBuilder_DayPeriodPrinterParser_DAYPERIOD_LOCALESTORE = ConcurrentHashMap_New() }

func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_DayPeriodPrinterParser_class }

func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_DayPeriodPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_DayPeriodPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_DayPeriodPrinterParser); return ok }

func DateTimeFormatterBuilder_DayPeriodPrinterParser_Cast(x any) *DateTimeFormatterBuilder_DayPeriodPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_DayPeriodPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_DayPeriodPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_DefaultValueParser struct{ Object; F_field TemporalField; F_value int64 }

func (t *DateTimeFormatterBuilder_DefaultValueParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_DefaultValueParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_DefaultValueParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_DefaultValueParser_class }

func (t *DateTimeFormatterBuilder_DefaultValueParser) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeFormatterBuilder_DefaultValueParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_DefaultValueParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_DefaultValueParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_DefaultValueParser); return ok }

func DateTimeFormatterBuilder_DefaultValueParser_Cast(x any) *DateTimeFormatterBuilder_DefaultValueParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_DefaultValueParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_DefaultValueParser_class)) }; return v }



type DateTimeFormatterBuilder_FractionPrinterParser struct{ DateTimeFormatterBuilder_NumberPrinterParser; F_decimalPoint bool; F_minBD, F_rangeBD *BigDecimal }

var DateTimeFormatterBuilder_FractionPrinterParser_init ClassInit

func DateTimeFormatterBuilder_FractionPrinterParser_Init() { if !DateTimeFormatterBuilder_FractionPrinterParser_init.Done() { DateTimeFormatterBuilder_FractionPrinterParser_init.Run(DateTimeFormatterBuilder_FractionPrinterParser_clinit) } }

func DateTimeFormatterBuilder_FractionPrinterParser_clinit() { DateTimeFormatterBuilder_NumberPrinterParser_Init() }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser() DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_FractionPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithFixedWidth__DateTimeFormatterBuilder_FractionPrinterParser()) }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(p0 int32) DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_FractionPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithSubsequentWidth_I__DateTimeFormatterBuilder_FractionPrinterParser(p0)) }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) GetValue_DateTimePrintContext_J__J(p0 *DateTimePrintContext, p1 int64) int64 { return t.Impl_GetValue_DateTimePrintContext_J__J(t, p0, p1) }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) SetValue_DateTimeParseContext_J_I_I__I(p0 *DateTimeParseContext, p1 int64, p2, p3 int32) int32 { return t.Impl_SetValue_DateTimeParseContext_J_I_I__I(t, p0, p1, p2, p3) }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_FractionPrinterParser_class }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_FractionPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_FractionPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_FractionPrinterParser); return ok }

func DateTimeFormatterBuilder_FractionPrinterParser_Cast(x any) *DateTimeFormatterBuilder_FractionPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_FractionPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_FractionPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_InstantPrinterParser struct{ Object; F_fractionalDigits int32 }

func (t *DateTimeFormatterBuilder_InstantPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

const DateTimeFormatterBuilder_InstantPrinterParser_SECONDS_PER_10000_YEARS int64 = 315569520000

const DateTimeFormatterBuilder_InstantPrinterParser_SECONDS_0000_TO_1970 int64 = 62167219200

func (t *DateTimeFormatterBuilder_InstantPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_InstantPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_InstantPrinterParser_class }

func (t *DateTimeFormatterBuilder_InstantPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_InstantPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_InstantPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_InstantPrinterParser); return ok }

func DateTimeFormatterBuilder_InstantPrinterParser_Cast(x any) *DateTimeFormatterBuilder_InstantPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_InstantPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_InstantPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser struct{ Object; F_style *TextStyle }

func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_class }

func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser); return ok }

func DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_Cast(x any) *DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_LocalizedOffsetIdPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_LocalizedPrinterParser struct{ Object; F_dateStyle, F_timeStyle *FormatStyle; F_requestedTemplate *String }

func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

var DateTimeFormatterBuilder_LocalizedPrinterParser_FORMATTER_CACHE ConcurrentMap

var DateTimeFormatterBuilder_LocalizedPrinterParser_init ClassInit

func DateTimeFormatterBuilder_LocalizedPrinterParser_Init() { if !DateTimeFormatterBuilder_LocalizedPrinterParser_init.Done() { DateTimeFormatterBuilder_LocalizedPrinterParser_init.Run(DateTimeFormatterBuilder_LocalizedPrinterParser_clinit) } }

func DateTimeFormatterBuilder_LocalizedPrinterParser_clinit() { DateTimeFormatterBuilder_LocalizedPrinterParser_FORMATTER_CACHE = ConcurrentHashMap_New_I_F_I(16, 0.75, 2) }

func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_LocalizedPrinterParser_class }

func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_LocalizedPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_LocalizedPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_LocalizedPrinterParser); return ok }

func DateTimeFormatterBuilder_LocalizedPrinterParser_Cast(x any) *DateTimeFormatterBuilder_LocalizedPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_LocalizedPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_LocalizedPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_NanosPrinterParser struct{ DateTimeFormatterBuilder_NumberPrinterParser; F_decimalPoint bool }

var DateTimeFormatterBuilder_NanosPrinterParser_TENS *IntArray

var DateTimeFormatterBuilder_NanosPrinterParser_init ClassInit

func DateTimeFormatterBuilder_NanosPrinterParser_Init() { if !DateTimeFormatterBuilder_NanosPrinterParser_init.Done() { DateTimeFormatterBuilder_NanosPrinterParser_init.Run(DateTimeFormatterBuilder_NanosPrinterParser_clinit) } }

func DateTimeFormatterBuilder_NanosPrinterParser_clinit() { DateTimeFormatterBuilder_NumberPrinterParser_Init(); DateTimeFormatterBuilder_NanosPrinterParser_TENS = IntArrayOf(1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000) }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser() DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_NanosPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithFixedWidth__DateTimeFormatterBuilder_NanosPrinterParser()) }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(p0 int32) DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_NanosPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithSubsequentWidth_I__DateTimeFormatterBuilder_NanosPrinterParser(p0)) }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) GetValue_DateTimePrintContext_J__J(p0 *DateTimePrintContext, p1 int64) int64 { return t.Impl_GetValue_DateTimePrintContext_J__J(t, p0, p1) }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) SetValue_DateTimeParseContext_J_I_I__I(p0 *DateTimeParseContext, p1 int64, p2, p3 int32) int32 { return t.Impl_SetValue_DateTimeParseContext_J_I_I__I(t, p0, p1, p2, p3) }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_NanosPrinterParser_class }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_NanosPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_NanosPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_NanosPrinterParser); return ok }

func DateTimeFormatterBuilder_NanosPrinterParser_Cast(x any) *DateTimeFormatterBuilder_NanosPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_NanosPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_NanosPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_NumberPrinterParser struct{ Object; F_field TemporalField; F_minWidth, F_maxWidth int32; F_signStyle *SignStyle; F_subsequentWidth int32 }

type DateTimeFormatterBuilder_NumberPrinterParser_I interface{ Object_I; DateTimeFormatterBuilder_DateTimePrinterParser; Self_DateTimeFormatterBuilder_NumberPrinterParser() *DateTimeFormatterBuilder_NumberPrinterParser; WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser() DateTimeFormatterBuilder_NumberPrinterParser_I; WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(p0 int32) DateTimeFormatterBuilder_NumberPrinterParser_I; Format_DateTimePrintContext_StringBuilder_Z__Z(p0 *DateTimePrintContext, p1 *StringBuilder, p2 bool) bool; GetValue_DateTimePrintContext_J__J(p0 *DateTimePrintContext, p1 int64) int64; IsFixedWidth_DateTimeParseContext__Z(p0 *DateTimeParseContext) bool; Parse_DateTimeParseContext_CharSequence_I__I(p0 *DateTimeParseContext, p1 CharSequence, p2 int32) int32; SetValue_DateTimeParseContext_J_I_I__I(p0 *DateTimeParseContext, p1 int64, p2, p3 int32) int32 }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) Self_DateTimeFormatterBuilder_NumberPrinterParser() *DateTimeFormatterBuilder_NumberPrinterParser { return t }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

var DateTimeFormatterBuilder_NumberPrinterParser_EXCEED_POINTS *LongArray

var DateTimeFormatterBuilder_NumberPrinterParser_init ClassInit

func DateTimeFormatterBuilder_NumberPrinterParser_Init() { if !DateTimeFormatterBuilder_NumberPrinterParser_init.Done() { DateTimeFormatterBuilder_NumberPrinterParser_init.Run(DateTimeFormatterBuilder_NumberPrinterParser_clinit) } }

func DateTimeFormatterBuilder_NumberPrinterParser_clinit() { DateTimeFormatterBuilder_NumberPrinterParser_EXCEED_POINTS = LongArrayOf(0, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser() DateTimeFormatterBuilder_NumberPrinterParser_I { return t.Impl_WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser(t) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(p0 int32) DateTimeFormatterBuilder_NumberPrinterParser_I { return t.Impl_WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(t, p0) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(p0 *DateTimePrintContext, p1 *StringBuilder, p2 bool) bool { return t.Impl_Format_DateTimePrintContext_StringBuilder_Z__Z(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) GetValue_DateTimePrintContext_J__J(p0 *DateTimePrintContext, p1 int64) int64 { return t.Impl_GetValue_DateTimePrintContext_J__J(t, p0, p1) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) IsFixedWidth_DateTimeParseContext__Z(p0 *DateTimeParseContext) bool { return t.Impl_IsFixedWidth_DateTimeParseContext__Z(t, p0) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(p0 *DateTimeParseContext, p1 CharSequence, p2 int32) int32 { return t.Impl_Parse_DateTimeParseContext_CharSequence_I__I(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) SetValue_DateTimeParseContext_J_I_I__I(p0 *DateTimeParseContext, p1 int64, p2, p3 int32) int32 { return t.Impl_SetValue_DateTimeParseContext_J_I_I__I(t, p0, p1, p2, p3) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_NumberPrinterParser_class }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_NumberPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_NumberPrinterParser_InstanceOf(x any) bool { _, ok := x.(DateTimeFormatterBuilder_NumberPrinterParser_I); return ok }

func DateTimeFormatterBuilder_NumberPrinterParser_Cast(x any) DateTimeFormatterBuilder_NumberPrinterParser_I { if x == nil { return nil }; v, ok := x.(DateTimeFormatterBuilder_NumberPrinterParser_I); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_NumberPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_OffsetIdPrinterParser struct{ Object; F_noOffsetText *String; F_type, F_style int32 }

func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

var DateTimeFormatterBuilder_OffsetIdPrinterParser_PATTERNS *RefArray

var DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_Z *DateTimeFormatterBuilder_OffsetIdPrinterParser

var DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_ZERO *DateTimeFormatterBuilder_OffsetIdPrinterParser

var DateTimeFormatterBuilder_OffsetIdPrinterParser_init ClassInit

func DateTimeFormatterBuilder_OffsetIdPrinterParser_Init() { if !DateTimeFormatterBuilder_OffsetIdPrinterParser_init.Done() { DateTimeFormatterBuilder_OffsetIdPrinterParser_init.Run(DateTimeFormatterBuilder_OffsetIdPrinterParser_clinit) } }

func DateTimeFormatterBuilder_OffsetIdPrinterParser_clinit() { DateTimeFormatterBuilder_OffsetIdPrinterParser_PATTERNS = ConstRefArray("[0,22,s3:+HHs5:+HHmms6:+HH:mms5:+HHMMs6:+HH:MMs7:+HHMMsss9:+HH:MM:sss7:+HHMMSSs9:+HH:MM:SSs7:+HHmmsss9:+HH:mm:sss2:+Hs4:+Hmms5:+H:mms4:+HMMs5:+H:MMs6:+HMMsss8:+H:MM:sss6:+HMMSSs8:+H:MM:SSs6:+Hmmsss8:+H:mm:ss", []*Class{String_class}); DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_Z = DateTimeFormatterBuilder_OffsetIdPrinterParser_New_String_String(Lit_2278, Lit_2165); DateTimeFormatterBuilder_OffsetIdPrinterParser_INSTANCE_ID_ZERO = DateTimeFormatterBuilder_OffsetIdPrinterParser_New_String_String(Lit_2278, Lit_1133) }

func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_OffsetIdPrinterParser_class }

func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_OffsetIdPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_OffsetIdPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_OffsetIdPrinterParser); return ok }

func DateTimeFormatterBuilder_OffsetIdPrinterParser_Cast(x any) *DateTimeFormatterBuilder_OffsetIdPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_OffsetIdPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_OffsetIdPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_PadPrinterParserDecorator struct{ Object; F_printerParser DateTimeFormatterBuilder_DateTimePrinterParser; F_padWidth int32; F_padChar uint16 }

func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) GetClass__Class() *Class { return DateTimeFormatterBuilder_PadPrinterParserDecorator_class }

func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_PadPrinterParserDecorator) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_PadPrinterParserDecorator_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_PadPrinterParserDecorator); return ok }

func DateTimeFormatterBuilder_PadPrinterParserDecorator_Cast(x any) *DateTimeFormatterBuilder_PadPrinterParserDecorator { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_PadPrinterParserDecorator); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_PadPrinterParserDecorator_class)) }; return v }



type DateTimeFormatterBuilder_PrefixTree struct{ Object; F_key, F_value *String; F_type int32; F_c0 uint16; F_child, F_sibling DateTimeFormatterBuilder_PrefixTree_I }

type DateTimeFormatterBuilder_PrefixTree_I interface{ Object_I; Self_DateTimeFormatterBuilder_PrefixTree() *DateTimeFormatterBuilder_PrefixTree; CopyTree__DateTimeFormatterBuilder_PrefixTree() DateTimeFormatterBuilder_PrefixTree_I; Add_String_String_I__Z(p0, p1 *String, p2 int32) bool; Match_CharSequence_I_I__DateTimeFormatterBuilder_PrefixTree(p0 CharSequence, p1, p2 int32) DateTimeFormatterBuilder_PrefixTree_I; Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(p0 CharSequence, p1 *ParsePosition) DateTimeFormatterBuilder_PrefixTree_I; ToKey_String__String(p0 *String) *String; NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(p0, p1 *String, p2 int32, p3 DateTimeFormatterBuilder_PrefixTree_I) DateTimeFormatterBuilder_PrefixTree_I; IsEqual_C_C__Z(p0, p1 uint16) bool; PrefixOf_CharSequence_I_I__Z(p0 CharSequence, p1, p2 int32) bool }

func (t *DateTimeFormatterBuilder_PrefixTree) Self_DateTimeFormatterBuilder_PrefixTree() *DateTimeFormatterBuilder_PrefixTree { return t }

func (t *DateTimeFormatterBuilder_PrefixTree) CopyTree__DateTimeFormatterBuilder_PrefixTree() DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_CopyTree__DateTimeFormatterBuilder_PrefixTree(t) }

func (t *DateTimeFormatterBuilder_PrefixTree) Add_String_String_I__Z(p0, p1 *String, p2 int32) bool { return t.Impl_Add_String_String_I__Z(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_PrefixTree) Match_CharSequence_I_I__DateTimeFormatterBuilder_PrefixTree(p0 CharSequence, p1, p2 int32) DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_Match_CharSequence_I_I__DateTimeFormatterBuilder_PrefixTree(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_PrefixTree) Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(p0 CharSequence, p1 *ParsePosition) DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(t, p0, p1) }

func (t *DateTimeFormatterBuilder_PrefixTree) ToKey_String__String(p0 *String) *String { return t.Impl_ToKey_String__String(t, p0) }

func (t *DateTimeFormatterBuilder_PrefixTree) NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(p0, p1 *String, p2 int32, p3 DateTimeFormatterBuilder_PrefixTree_I) DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(t, p0, p1, p2, p3) }

func (t *DateTimeFormatterBuilder_PrefixTree) IsEqual_C_C__Z(p0, p1 uint16) bool { return t.Impl_IsEqual_C_C__Z(t, p0, p1) }

func (t *DateTimeFormatterBuilder_PrefixTree) PrefixOf_CharSequence_I_I__Z(p0 CharSequence, p1, p2 int32) bool { return t.Impl_PrefixOf_CharSequence_I_I__Z(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_PrefixTree) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_PrefixTree) GetClass__Class() *Class { return DateTimeFormatterBuilder_PrefixTree_class }

func (t *DateTimeFormatterBuilder_PrefixTree) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeFormatterBuilder_PrefixTree) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_PrefixTree) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_PrefixTree_InstanceOf(x any) bool { _, ok := x.(DateTimeFormatterBuilder_PrefixTree_I); return ok }

func DateTimeFormatterBuilder_PrefixTree_Cast(x any) DateTimeFormatterBuilder_PrefixTree_I { if x == nil { return nil }; v, ok := x.(DateTimeFormatterBuilder_PrefixTree_I); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_PrefixTree_class)) }; return v }



type DateTimeFormatterBuilder_PrefixTree_CI struct{ DateTimeFormatterBuilder_PrefixTree }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree(p0, p1 *String, p2 int32, p3 DateTimeFormatterBuilder_PrefixTree_I) DateTimeFormatterBuilder_PrefixTree_I { return Up_DateTimeFormatterBuilder_PrefixTree_CI_DateTimeFormatterBuilder_PrefixTree(t.NewNode_String_String_I_DateTimeFormatterBuilder_PrefixTree__DateTimeFormatterBuilder_PrefixTree_CI(p0, p1, p2, p3)) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) Match_CharSequence_I_I__DateTimeFormatterBuilder_PrefixTree(p0 CharSequence, p1, p2 int32) DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_Match_CharSequence_I_I__DateTimeFormatterBuilder_PrefixTree(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(p0 CharSequence, p1 *ParsePosition) DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_Match_CharSequence_ParsePosition__DateTimeFormatterBuilder_PrefixTree(t, p0, p1) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) CopyTree__DateTimeFormatterBuilder_PrefixTree() DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_CopyTree__DateTimeFormatterBuilder_PrefixTree(t) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) ToKey_String__String(p0 *String) *String { return t.Impl_ToKey_String__String(t, p0) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) Add_String_String_I__Z(p0, p1 *String, p2 int32) bool { return t.Impl_Add_String_String_I__Z(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) GetClass__Class() *Class { return DateTimeFormatterBuilder_PrefixTree_CI_class }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_PrefixTree_CI) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_PrefixTree_CI_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_PrefixTree_CI); return ok }

func DateTimeFormatterBuilder_PrefixTree_CI_Cast(x any) *DateTimeFormatterBuilder_PrefixTree_CI { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_PrefixTree_CI); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_PrefixTree_CI_class)) }; return v }



type DateTimeFormatterBuilder_ReducedPrinterParser struct{ DateTimeFormatterBuilder_NumberPrinterParser; F_baseValue int32; F_baseDate ChronoLocalDate }

var DateTimeFormatterBuilder_ReducedPrinterParser_BASE_DATE *LocalDate

var DateTimeFormatterBuilder_ReducedPrinterParser_init ClassInit

func DateTimeFormatterBuilder_ReducedPrinterParser_Init() { if !DateTimeFormatterBuilder_ReducedPrinterParser_init.Done() { DateTimeFormatterBuilder_ReducedPrinterParser_init.Run(DateTimeFormatterBuilder_ReducedPrinterParser_clinit) } }

func DateTimeFormatterBuilder_ReducedPrinterParser_clinit() { DateTimeFormatterBuilder_NumberPrinterParser_Init(); DateTimeFormatterBuilder_ReducedPrinterParser_BASE_DATE = LocalDate_Of_I_I_I__LocalDate(2000, 1, 1) }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser() DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_ReducedPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithFixedWidth__DateTimeFormatterBuilder_ReducedPrinterParser()) }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(p0 int32) DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_ReducedPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithSubsequentWidth_I__DateTimeFormatterBuilder_ReducedPrinterParser(p0)) }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(p0 *DateTimeParseContext, p1 CharSequence, p2 int32) int32 { return t.Impl_Parse_DateTimeParseContext_CharSequence_I__I(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(p0 *DateTimePrintContext, p1 *StringBuilder, p2 bool) bool { return t.Impl_Format_DateTimePrintContext_StringBuilder_Z__Z(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_ReducedPrinterParser_class }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_ReducedPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_ReducedPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_ReducedPrinterParser); return ok }

func DateTimeFormatterBuilder_ReducedPrinterParser_Cast(x any) *DateTimeFormatterBuilder_ReducedPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_ReducedPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_ReducedPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_SettingsParser struct{ Enum }

func (t *DateTimeFormatterBuilder_SettingsParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_SettingsParser) Is_Constable() {}

var DateTimeFormatterBuilder_SettingsParser_SENSITIVE *DateTimeFormatterBuilder_SettingsParser

var DateTimeFormatterBuilder_SettingsParser_INSENSITIVE *DateTimeFormatterBuilder_SettingsParser

var DateTimeFormatterBuilder_SettingsParser_STRICT *DateTimeFormatterBuilder_SettingsParser

var DateTimeFormatterBuilder_SettingsParser_LENIENT *DateTimeFormatterBuilder_SettingsParser

var DateTimeFormatterBuilder_SettingsParser__VALUES *RefArray

var DateTimeFormatterBuilder_SettingsParser_init ClassInit

func DateTimeFormatterBuilder_SettingsParser_Init() { if !DateTimeFormatterBuilder_SettingsParser_init.Done() { DateTimeFormatterBuilder_SettingsParser_init.Run(DateTimeFormatterBuilder_SettingsParser_clinit) } }

func DateTimeFormatterBuilder_SettingsParser_clinit() { DateTimeFormatterBuilder_SettingsParser_SENSITIVE = DateTimeFormatterBuilder_SettingsParser_New_String_I(Lit_2344, 0); DateTimeFormatterBuilder_SettingsParser_INSENSITIVE = DateTimeFormatterBuilder_SettingsParser_New_String_I(Lit_2345, 1); DateTimeFormatterBuilder_SettingsParser_STRICT = DateTimeFormatterBuilder_SettingsParser_New_String_I(Lit_2346, 2); DateTimeFormatterBuilder_SettingsParser_LENIENT = DateTimeFormatterBuilder_SettingsParser_New_String_I(Lit_2347, 3); DateTimeFormatterBuilder_SettingsParser__VALUES = DateTimeFormatterBuilder_SettingsParser_X_values__DateTimeFormatterBuilder_SettingsParser1() }

func DateTimeFormatterBuilder_SettingsParser_New_String_I(p0 *String, p1 int32) *DateTimeFormatterBuilder_SettingsParser { DateTimeFormatterBuilder_SettingsParser_Init(); t := &DateTimeFormatterBuilder_SettingsParser{}; t.Ctor_String_I(p0, p1); return t }

func (t *DateTimeFormatterBuilder_SettingsParser) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func DateTimeFormatterBuilder_SettingsParser_Values__DateTimeFormatterBuilder_SettingsParser1() *RefArray { DateTimeFormatterBuilder_SettingsParser_Init(); return DateTimeFormatterBuilder_SettingsParser__VALUES.Copy() }

func DateTimeFormatterBuilder_SettingsParser_ValueOf_String__DateTimeFormatterBuilder_SettingsParser(p0 *String) *DateTimeFormatterBuilder_SettingsParser { DateTimeFormatterBuilder_SettingsParser_Init(); return DateTimeFormatterBuilder_SettingsParser_Cast(Enum_ValueOf_Class_String__Enum(DateTimeFormatterBuilder_SettingsParser_class, p0)) }

func DateTimeFormatterBuilder_SettingsParser_X_values__DateTimeFormatterBuilder_SettingsParser1() *RefArray { DateTimeFormatterBuilder_SettingsParser_Init(); return RefArrayOf(DateTimeFormatterBuilder_SettingsParser_class, DateTimeFormatterBuilder_SettingsParser_SENSITIVE, DateTimeFormatterBuilder_SettingsParser_INSENSITIVE, DateTimeFormatterBuilder_SettingsParser_STRICT, DateTimeFormatterBuilder_SettingsParser_LENIENT) }

func (t *DateTimeFormatterBuilder_SettingsParser) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *DateTimeFormatterBuilder_SettingsParser) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *DateTimeFormatterBuilder_SettingsParser) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *DateTimeFormatterBuilder_SettingsParser) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.format.DateTimeFormatterBuilder$SettingsParser.describeConstable()Ljava/util/Optional;")) }

func (t *DateTimeFormatterBuilder_SettingsParser) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *DateTimeFormatterBuilder_SettingsParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_SettingsParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_SettingsParser_class }

func (t *DateTimeFormatterBuilder_SettingsParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_SettingsParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_SettingsParser); return ok }

func DateTimeFormatterBuilder_SettingsParser_Cast(x any) *DateTimeFormatterBuilder_SettingsParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_SettingsParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_SettingsParser_class)) }; return v }



type DateTimeFormatterBuilder_StringLiteralPrinterParser struct{ Object; F_literal *String }

func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_StringLiteralPrinterParser_class }

func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_StringLiteralPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_StringLiteralPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_StringLiteralPrinterParser); return ok }

func DateTimeFormatterBuilder_StringLiteralPrinterParser_Cast(x any) *DateTimeFormatterBuilder_StringLiteralPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_StringLiteralPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_StringLiteralPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_TextPrinterParser struct{ Object; F_field TemporalField; F_textStyle *TextStyle; F_provider DateTimeTextProvider_I; F_numberPrinterParser Volatile[DateTimeFormatterBuilder_NumberPrinterParser_I] }

func (t *DateTimeFormatterBuilder_TextPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

func (t *DateTimeFormatterBuilder_TextPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_TextPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_TextPrinterParser_class }

func (t *DateTimeFormatterBuilder_TextPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_TextPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_TextPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_TextPrinterParser); return ok }

func DateTimeFormatterBuilder_TextPrinterParser_Cast(x any) *DateTimeFormatterBuilder_TextPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_TextPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_TextPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_WeekBasedFieldPrinterParser struct{ DateTimeFormatterBuilder_NumberPrinterParser; F_chr uint16; F_count int32 }

var DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_init ClassInit

func DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_Init() { if !DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_init.Done() { DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_init.Run(DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_clinit) } }

func DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_clinit() { DateTimeFormatterBuilder_NumberPrinterParser_Init() }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) WithFixedWidth__DateTimeFormatterBuilder_NumberPrinterParser() DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithFixedWidth__DateTimeFormatterBuilder_WeekBasedFieldPrinterParser()) }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) WithSubsequentWidth_I__DateTimeFormatterBuilder_NumberPrinterParser(p0 int32) DateTimeFormatterBuilder_NumberPrinterParser_I { return Up_DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(t.WithSubsequentWidth_I__DateTimeFormatterBuilder_WeekBasedFieldPrinterParser(p0)) }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) IsFixedWidth_DateTimeParseContext__Z(p0 *DateTimeParseContext) bool { return t.Impl_IsFixedWidth_DateTimeParseContext__Z(t, p0) }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) GetValue_DateTimePrintContext_J__J(p0 *DateTimePrintContext, p1 int64) int64 { return t.Impl_GetValue_DateTimePrintContext_J__J(t, p0, p1) }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) SetValue_DateTimeParseContext_J_I_I__I(p0 *DateTimeParseContext, p1 int64, p2, p3 int32) int32 { return t.Impl_SetValue_DateTimeParseContext_J_I_I__I(t, p0, p1, p2, p3) }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_class }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_WeekBasedFieldPrinterParser); return ok }

func DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_Cast(x any) *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_WeekBasedFieldPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_ZoneIdPrinterParser struct{ Object; F_query TemporalQuery; F_description *String }

type DateTimeFormatterBuilder_ZoneIdPrinterParser_I interface{ Object_I; DateTimeFormatterBuilder_DateTimePrinterParser; Self_DateTimeFormatterBuilder_ZoneIdPrinterParser() *DateTimeFormatterBuilder_ZoneIdPrinterParser; Format_DateTimePrintContext_StringBuilder_Z__Z(p0 *DateTimePrintContext, p1 *StringBuilder, p2 bool) bool; GetTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(p0 *DateTimeParseContext) DateTimeFormatterBuilder_PrefixTree_I; Parse_DateTimeParseContext_CharSequence_I__I(p0 *DateTimeParseContext, p1 CharSequence, p2 int32) int32 }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Self_DateTimeFormatterBuilder_ZoneIdPrinterParser() *DateTimeFormatterBuilder_ZoneIdPrinterParser { return t }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Is_DateTimeFormatterBuilder_DateTimePrinterParser() {}

var DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTree Volatile[Map_Entry]

var DateTimeFormatterBuilder_ZoneIdPrinterParser_cachedPrefixTreeCI Volatile[Map_Entry]

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Format_DateTimePrintContext_StringBuilder_Z__Z(p0 *DateTimePrintContext, p1 *StringBuilder, p2 bool) bool { return t.Impl_Format_DateTimePrintContext_StringBuilder_Z__Z(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) GetTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(p0 *DateTimeParseContext) DateTimeFormatterBuilder_PrefixTree_I { return t.Impl_GetTree_DateTimeParseContext__DateTimeFormatterBuilder_PrefixTree(t, p0) }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(p0 *DateTimeParseContext, p1 CharSequence, p2 int32) int32 { return t.Impl_Parse_DateTimeParseContext_CharSequence_I__I(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_ZoneIdPrinterParser_class }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_ZoneIdPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_ZoneIdPrinterParser_InstanceOf(x any) bool { _, ok := x.(DateTimeFormatterBuilder_ZoneIdPrinterParser_I); return ok }

func DateTimeFormatterBuilder_ZoneIdPrinterParser_Cast(x any) DateTimeFormatterBuilder_ZoneIdPrinterParser_I { if x == nil { return nil }; v, ok := x.(DateTimeFormatterBuilder_ZoneIdPrinterParser_I); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_ZoneIdPrinterParser_class)) }; return v }



type DateTimeFormatterBuilder_ZoneTextPrinterParser struct{ DateTimeFormatterBuilder_ZoneIdPrinterParser; F_textStyle *TextStyle; F_preferredZones Set; F_isGeneric bool; F_cachedTree, F_cachedTreeCI Map }

const DateTimeFormatterBuilder_ZoneTextPrinterParser_UNDEFINED int32 = -1

const DateTimeFormatterBuilder_ZoneTextPrinterParser_STD int32 = 0

const DateTimeFormatterBuilder_ZoneTextPrinterParser_DST int32 = 1

const DateTimeFormatterBuilder_ZoneTextPrinterParser_GENERIC int32 = 2

var DateTimeFormatterBuilder_ZoneTextPrinterParser_cache Map

var DateTimeFormatterBuilder_ZoneTextPrinterParser_init ClassInit

func DateTimeFormatterBuilder_ZoneTextPrinterParser_Init() { if !DateTimeFormatterBuilder_ZoneTextPrinterParser_init.Done() { DateTimeFormatterBuilder_ZoneTextPrinterParser_init.Run(DateTimeFormatterBuilder_ZoneTextPrinterParser_clinit) } }

func DateTimeFormatterBuilder_ZoneTextPrinterParser_clinit() { DateTimeFormatterBuilder_ZoneTextPrinterParser_cache = ConcurrentHashMap_New() }

func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) Parse_DateTimeParseContext_CharSequence_I__I(p0 *DateTimeParseContext, p1 CharSequence, p2 int32) int32 { return t.Impl_Parse_DateTimeParseContext_CharSequence_I__I(t, p0, p1, p2) }

func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) GetClass__Class() *Class { return DateTimeFormatterBuilder_ZoneTextPrinterParser_class }

func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatterBuilder_ZoneTextPrinterParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatterBuilder_ZoneTextPrinterParser_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatterBuilder_ZoneTextPrinterParser); return ok }

func DateTimeFormatterBuilder_ZoneTextPrinterParser_Cast(x any) *DateTimeFormatterBuilder_ZoneTextPrinterParser { if x == nil { return nil }; v, ok := x.(*DateTimeFormatterBuilder_ZoneTextPrinterParser); if !ok { panic(ClassCast(x, DateTimeFormatterBuilder_ZoneTextPrinterParser_class)) }; return v }
