//line java_net_NoRouteToHostException.ae:1
package jrt








func NoRouteToHostException_New_String(p0 *String) *NoRouteToHostException { t := &NoRouteToHostException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *NoRouteToHostException) Ctor_String(msg *String) { t.SocketException.Ctor_String(t, msg) }

func NoRouteToHostException_New() *NoRouteToHostException { t := &NoRouteToHostException{}; t.Ctor(); return t }
//line :12:1
func (t *NoRouteToHostException) Ctor() { t.SocketException.Ctor(t) }







type NoRouteToHostException struct{ SocketException }

const NoRouteToHostException_serialVersionUID int64 = -1897550894873493790

func (t *NoRouteToHostException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoRouteToHostException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoRouteToHostException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoRouteToHostException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoRouteToHostException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoRouteToHostException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoRouteToHostException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoRouteToHostException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoRouteToHostException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoRouteToHostException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoRouteToHostException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoRouteToHostException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoRouteToHostException) Ref() any { if t == nil { return nil }; return t }

func (t *NoRouteToHostException) GetClass__Class() *Class { return NoRouteToHostException_class }

func (t *NoRouteToHostException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoRouteToHostException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoRouteToHostException_InstanceOf(x any) bool { _, ok := x.(*NoRouteToHostException); return ok }

func NoRouteToHostException_Cast(x any) *NoRouteToHostException { if x == nil { return nil }; v, ok := x.(*NoRouteToHostException); if !ok { panic(ClassCast(x, NoRouteToHostException_class)) }; return v }
