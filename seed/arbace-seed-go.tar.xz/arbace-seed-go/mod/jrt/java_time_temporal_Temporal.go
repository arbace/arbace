//line java_time_temporal_Temporal.ae:1
package jrt








func Temporal_With_TemporalAdjuster__Temporal(this Temporal, adjuster TemporalAdjuster) Temporal {
	return adjuster.AdjustInto_Temporal__Temporal(this)
}


func Temporal_Plus_TemporalAmount__Temporal(this Temporal, amount TemporalAmount) Temporal {
	return amount.AddTo_Temporal__Temporal(this)
}


func Temporal_Minus_TemporalAmount__Temporal(this Temporal, amount TemporalAmount) Temporal {
	return amount.SubtractFrom_Temporal__Temporal(this)
}
func Temporal_Minus_J_TemporalUnit__Temporal(this Temporal, amountToSubtract int64, unit TemporalUnit) Temporal {
	if amountToSubtract == -9223372036854775808 {
		return this.Plus_J_TemporalUnit__Temporal(9223372036854775807, unit).Plus_J_TemporalUnit__Temporal(1, unit) } else {
			return this.Plus_J_TemporalUnit__Temporal(-amountToSubtract, unit)
		}
}

type Temporal interface{ Object_I; TemporalAccessor; Is_Temporal(); IsSupported_TemporalUnit__Z(p0 TemporalUnit) bool; With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal; With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal; Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; Until_Temporal_TemporalUnit__J(p0 Temporal, p1 TemporalUnit) int64 }

func Temporal_InstanceOf(x any) bool { _, ok := x.(Temporal); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Temporal_class) } }; return ok }

func Temporal_Cast(x any) Temporal { if x == nil { return nil }; v, ok := x.(Temporal); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Temporal_class) } }; if !ok { panic(ClassCast(x, Temporal_class)) }; return v }
