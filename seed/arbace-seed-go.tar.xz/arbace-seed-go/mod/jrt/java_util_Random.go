//line java_util_Random.ae:1
package jrt

























func Random_RandomWrapper_New_RandomGenerator(p0 RandomGenerator) *Random_RandomWrapper { Random_RandomWrapper_Init(); t := &Random_RandomWrapper{}; t.Ctor_RandomGenerator(p0); return t }
//line :27:1
func (t *Random_RandomWrapper) Ctor_RandomGenerator(randomToWrap RandomGenerator) { t.Random.Ctor_Void(t, nil)

	t.F_generator = randomToWrap
}







func (t *Random_RandomWrapper) SetSeed_J__V(seed int64) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Random_RandomWrapper) IsDeprecated__Z() bool { return t.F_generator.IsDeprecated__Z() }

func (t *Random_RandomWrapper) NextBytes_B1__V(bytes *ByteArray) {
	t.F_generator.NextBytes_B1__V(bytes)
}
func (t *Random_RandomWrapper) NextInt__I() int32 { return t.F_generator.NextInt__I() }

func (t *Random_RandomWrapper) NextInt_I__I(bound int32) int32 {
	return t.F_generator.NextInt_I__I(bound)
}
func (t *Random_RandomWrapper) NextInt_I_I__I(origin, bound int32) int32 {
	return t.F_generator.NextInt_I_I__I(origin, bound)
}
func (t *Random_RandomWrapper) NextLong__J() int64 { return t.F_generator.NextLong__J() }

func (t *Random_RandomWrapper) NextLong_J__J(bound int64) int64 {
	return t.F_generator.NextLong_J__J(bound)
}
func (t *Random_RandomWrapper) NextLong_J_J__J(origin, bound int64) int64 {
	return t.F_generator.NextLong_J_J__J(origin, bound)
}
func (t *Random_RandomWrapper) NextBoolean__Z() bool {
	return t.F_generator.NextBoolean__Z()
}
func (t *Random_RandomWrapper) NextFloat__F() float32 {
	return t.F_generator.NextFloat__F()
}
func (t *Random_RandomWrapper) NextFloat_F__F(bound float32) float32 {
	return t.F_generator.NextFloat_F__F(bound)
}
func (t *Random_RandomWrapper) NextFloat_F_F__F(origin, bound float32) float32 {
	return t.F_generator.NextFloat_F_F__F(origin, bound)
}
func (t *Random_RandomWrapper) NextDouble__D() float64 {
	return t.F_generator.NextDouble__D()
}
func (t *Random_RandomWrapper) NextDouble_D__D(bound float64) float64 {
	return t.F_generator.NextDouble_D__D(bound)
}
func (t *Random_RandomWrapper) NextDouble_D_D__D(origin, bound float64) float64 {
	return t.F_generator.NextDouble_D_D__D(origin, bound)
}
func (t *Random_RandomWrapper) NextExponential__D() float64 {
	return t.F_generator.NextExponential__D()
}
func (t *Random_RandomWrapper) NextGaussian__D() float64 {
	return t.F_generator.NextGaussian__D()
}
func (t *Random_RandomWrapper) NextGaussian_D_D__D(mean, stddev float64) float64 {
	return t.F_generator.NextGaussian_D_D__D(mean, stddev)
}
func (t *Random_RandomWrapper) Ints_J__IntStream(streamSize int64) IntStream {
	return t.F_generator.Ints_J__IntStream(streamSize)
}
func (t *Random_RandomWrapper) Ints__IntStream() IntStream { return t.F_generator.Ints__IntStream() }

func (t *Random_RandomWrapper) Ints_J_I_I__IntStream(streamSize int64, randomNumberOrigin, randomNumberBound int32) IntStream {

	return t.F_generator.Ints_J_I_I__IntStream(streamSize, randomNumberOrigin, randomNumberBound)
}
func (t *Random_RandomWrapper) Ints_I_I__IntStream(randomNumberOrigin, randomNumberBound int32) IntStream {
	return t.F_generator.Ints_I_I__IntStream(randomNumberOrigin, randomNumberBound)
}
func (t *Random_RandomWrapper) Longs_J__LongStream(streamSize int64) LongStream {
	return t.F_generator.Longs_J__LongStream(streamSize)
}
func (t *Random_RandomWrapper) Longs__LongStream() LongStream { return t.F_generator.Longs__LongStream() }

func (t *Random_RandomWrapper) Longs_J_J_J__LongStream(streamSize, randomNumberOrigin, randomNumberBound int64) LongStream {

	return t.F_generator.Longs_J_J_J__LongStream(streamSize, randomNumberOrigin, randomNumberBound)
}
func (t *Random_RandomWrapper) Longs_J_J__LongStream(randomNumberOrigin, randomNumberBound int64) LongStream {
	return t.F_generator.Longs_J_J__LongStream(randomNumberOrigin, randomNumberBound)
}
func (t *Random_RandomWrapper) Doubles_J__DoubleStream(streamSize int64) DoubleStream {
	return t.F_generator.Doubles_J__DoubleStream(streamSize)
}
func (t *Random_RandomWrapper) Doubles__DoubleStream() DoubleStream {
	return t.F_generator.Doubles__DoubleStream()
}
func (t *Random_RandomWrapper) Doubles_J_D_D__DoubleStream(streamSize int64, randomNumberOrigin, randomNumberBound float64) DoubleStream {

	return t.F_generator.Doubles_J_D_D__DoubleStream(streamSize, randomNumberOrigin, randomNumberBound)
}
func (t *Random_RandomWrapper) Doubles_D_D__DoubleStream(randomNumberOrigin, randomNumberBound float64) DoubleStream {

	return t.F_generator.Doubles_D_D__DoubleStream(randomNumberOrigin, randomNumberBound)
}
func (t *Random_RandomWrapper) Next_I__I(bits int32) int32 {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Random_RandomWrapper) ToString__String() *String {
	return Concat(Lit_2816, StrOfObj(t.F_generator), Lit_1189)
}














func Random_New() *Random { Random_Init(); t := &Random{}; t.Ctor(t); return t }
//line :150:1
func (t *Random) Ctor(this Random_I) { t.Ctor_J(this, Random_SeedUniquifier__J()^System_NanoTime__J()) }


func Random_New_Void(p0 *Void) *Random { Random_Init(); t := &Random{}; t.Ctor_Void(t, p0); return t }
//line :153:1
func (t *Random) Ctor_Void(this Random_I, unused *Void) { t.F_haveNextNextGaussian = false; t.F_seed = nil }

func Random_SeedUniquifier__J() int64 { Random_Init()
L1: for {
	var current int64 = NN(Random_seedUniquifier).Get__J(); var next int64 = current * 1181783497276652981

	if NN(Random_seedUniquifier).CompareAndSet_J_J__Z(current, next) { return next }
//line :156:1
	continue L1 }
//line :155:1
	panic("a2g: unreachable")
}






func Random_New_J(p0 int64) *Random { Random_Init(); t := &Random{}; t.Ctor_J(t, p0); return t }
//line :163:1
func (t *Random) Ctor_J(this Random_I, seed int64) { t.F_haveNextNextGaussian = false
	if this.GetClass__Class() == Random_class {
		t.F_seed = AtomicLong_New_J(Random_InitialScramble_J__J(seed)) } else {
			t.F_seed = AtomicLong_New(); this.SetSeed_J__V(seed)
		} }
func Random_InitialScramble_J__J(seed int64) int64 { Random_Init()
	return (seed ^ 25214903917) & 281474976710655
}
func Random_From_RandomGenerator__Random(generator RandomGenerator) Random_I { Random_Init()
	Objects_RequireNonNull_O__O(generator)
	var tmp1 RandomGenerator = generator; if Random_InstanceOf(tmp1) { var rand Random_I = Random_Cast(tmp1); return rand } else { return Random_RandomWrapper_New_RandomGenerator(generator)
	} }
func (t *Random) Impl_SetSeed_J__V(this Random_I, seed int64) { MonitorEnter(this); defer MonitorExit(this)
	var tmp1 *AtomicLong = t.F_seed; NN(tmp1).Set_J__V(Random_InitialScramble_J__J(seed))
	t.F_haveNextNextGaussian = false
}
func (t *Random) Impl_Next_I__I(this Random_I, bits int32) int32 {
	var oldseed int64 = 0; var nextseed int64 = 0; var seed *AtomicLong = t.F_seed


L1: for {
	oldseed = NN(seed).Get__J()
	nextseed = (oldseed*25214903917 + 11) & 281474976710655

	if NN(seed).CompareAndSet_J_J__Z(oldseed, nextseed) { } else { continue L1 }
//line :183:1
	break L1
}



	return int32(int64(uint64(nextseed) >> ((48 - bits) & 63)))
}
func (t *Random) Impl_NextBytes_B1__V(this Random_I, bytes *ByteArray) {
	var i int32 = 0; var len_ int32 = int32(len(bytes.A))

L1: for { if i < len_ {
	var rnd int32 = this.NextInt__I(); var n int32 = Math_Min_I_I__I(len_-i, 4)


L2: for { var tmp1 int32; var old_1 int32 = n; n = n - 1; tmp1 = old_1; if tmp1 > 0 {
	bytes.A[i] = int8(rnd)
	i = i + 1
	rnd = rnd >> 8
//line :197:1
	continue L2 }; break L2 }
//line :193:1
	continue L1 }; break L1
}
}






func (t *Random) Impl_NextInt__I(this Random_I) int32 { return this.Next_I__I(32) }

func (t *Random) Impl_NextInt_I__I(this Random_I, bound int32) int32 {
	if bound <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_2815))) }
	var r int32 = this.Next_I__I(31); var m int32 = bound - 1

	if bound&m == 0 {
		r = int32(int64(bound) * int64(r) >> 31) } else {
			var u int32 = r; L1: for {
				var tmp1 int32
				r = u % bound; tmp1 = r
//line :211:1
				if u-tmp1+m < 0 {



					u = this.Next_I__I(31); continue L1 }
//line :210:1
				break L1 } }
//line :206:1
	return r
}










func (t *Random) Impl_NextLong__J(this Random_I) int64 {
	return int64(this.Next_I__I(32))<<32 + int64(this.Next_I__I(32))
}
func (t *Random) Impl_NextBoolean__Z(this Random_I) bool {
	return !(this.Next_I__I(1) == 0)
}
func (t *Random) Impl_NextFloat__F(this Random_I) float32 {
	return float32(float32(this.Next_I__I(24)) * 5.9604645e-8)
}
func (t *Random) Impl_NextDouble__D(this Random_I) float64 {
	return float64(float64(int64(this.Next_I__I(26))<<27+int64(this.Next_I__I(27))) * 1.1102230246251565e-16)
}








func (t *Random) Impl_NextGaussian__D(this Random_I) float64 { MonitorEnter(this); defer MonitorExit(this)
	if t.F_haveNextNextGaussian {
		t.F_haveNextNextGaussian = false; return t.F_nextNextGaussian } else {
			var v1 float64 = 0.0
			var v2 float64 = 0.0
			var s float64 = 0.0
		L1: for {
			v1 = float64(2.0*this.NextDouble__D()) - 1.0
			v2 = float64(2.0*this.NextDouble__D()) - 1.0
			s = float64(v1*v1) + float64(v2*v2)
			var tmp1 bool; var tmp2 bool; tmp2 = s >= 1.0; if !tmp2 { tmp2 = s == 0.0 }; tmp1 = tmp2; if tmp1 { continue L1 }
//line :244:1
			break L1
		}



			var multiplier float64 = StrictMath_Sqrt_D__D(float64(-2.0*StrictMath_Log_D__D(s)) / s)

			t.F_nextNextGaussian = float64(v2 * multiplier)
			t.F_haveNextNextGaussian = true
			return float64(v1 * multiplier)
		}
}































func (t *Random) Impl_ResetSeed_J__V(this Random_I, p0 int64) { panic(A2g_NotTranslated("java.util.Random.resetSeed(J)V")) }


func (t *Random) Impl_Ints_J__IntStream(this Random_I, streamSize int64) IntStream {
	return RandomSupport_AbstractSpliteratorGenerator_Ints_RandomGenerator_J__IntStream(this, streamSize)
}
func (t *Random) Impl_Ints__IntStream(this Random_I) IntStream {
	return RandomSupport_AbstractSpliteratorGenerator_Ints_RandomGenerator__IntStream(this)
}
func (t *Random) Impl_Ints_J_I_I__IntStream(this Random_I, streamSize int64, randomNumberOrigin, randomNumberBound int32) IntStream {

	return RandomSupport_AbstractSpliteratorGenerator_Ints_RandomGenerator_J_I_I__IntStream(this, streamSize, randomNumberOrigin, randomNumberBound)
}




func (t *Random) Impl_Ints_I_I__IntStream(this Random_I, randomNumberOrigin, randomNumberBound int32) IntStream {
	return RandomSupport_AbstractSpliteratorGenerator_Ints_RandomGenerator_I_I__IntStream(this, randomNumberOrigin, randomNumberBound)
}
func (t *Random) Impl_Longs_J__LongStream(this Random_I, streamSize int64) LongStream {
	return RandomSupport_AbstractSpliteratorGenerator_Longs_RandomGenerator_J__LongStream(this, streamSize)
}
func (t *Random) Impl_Longs__LongStream(this Random_I) LongStream {
	return RandomSupport_AbstractSpliteratorGenerator_Longs_RandomGenerator__LongStream(this)
}
func (t *Random) Impl_Longs_J_J_J__LongStream(this Random_I, streamSize, randomNumberOrigin, randomNumberBound int64) LongStream {

	return RandomSupport_AbstractSpliteratorGenerator_Longs_RandomGenerator_J_J_J__LongStream(this, streamSize, randomNumberOrigin, randomNumberBound)
}




func (t *Random) Impl_Longs_J_J__LongStream(this Random_I, randomNumberOrigin, randomNumberBound int64) LongStream {
	return RandomSupport_AbstractSpliteratorGenerator_Longs_RandomGenerator_J_J__LongStream(this, randomNumberOrigin, randomNumberBound)
}
func (t *Random) Impl_Doubles_J__DoubleStream(this Random_I, streamSize int64) DoubleStream {
	return RandomSupport_AbstractSpliteratorGenerator_Doubles_RandomGenerator_J__DoubleStream(this, streamSize)
}
func (t *Random) Impl_Doubles__DoubleStream(this Random_I) DoubleStream {
	return RandomSupport_AbstractSpliteratorGenerator_Doubles_RandomGenerator__DoubleStream(this)
}
func (t *Random) Impl_Doubles_J_D_D__DoubleStream(this Random_I, streamSize int64, randomNumberOrigin, randomNumberBound float64) DoubleStream {

	return RandomSupport_AbstractSpliteratorGenerator_Doubles_RandomGenerator_J_D_D__DoubleStream(this, streamSize, randomNumberOrigin, randomNumberBound)
}




func (t *Random) Impl_Doubles_D_D__DoubleStream(this Random_I, randomNumberOrigin, randomNumberBound float64) DoubleStream {
	return RandomSupport_AbstractSpliteratorGenerator_Doubles_RandomGenerator_D_D__DoubleStream(this, randomNumberOrigin, randomNumberBound)
}


type Random struct{ Object; F_seed *AtomicLong; F_nextNextGaussian float64; F_haveNextNextGaussian bool }

type Random_I interface{ Object_I; RandomGenerator; Serializable; Self_Random() *Random; SetSeed_J__V(p0 int64); Next_I__I(p0 int32) int32; NextBytes_B1__V(p0 *ByteArray); NextInt__I() int32; NextInt_I__I(p0 int32) int32; NextLong__J() int64; NextBoolean__Z() bool; NextFloat__F() float32; NextDouble__D() float64; NextGaussian__D() float64; Ints_J__IntStream(p0 int64) IntStream; Ints__IntStream() IntStream; Ints_J_I_I__IntStream(p0 int64, p1, p2 int32) IntStream; Ints_I_I__IntStream(p0, p1 int32) IntStream; Longs_J__LongStream(p0 int64) LongStream; Longs__LongStream() LongStream; Longs_J_J_J__LongStream(p0, p1, p2 int64) LongStream; Longs_J_J__LongStream(p0, p1 int64) LongStream; Doubles_J__DoubleStream(p0 int64) DoubleStream; Doubles__DoubleStream() DoubleStream; Doubles_J_D_D__DoubleStream(p0 int64, p1, p2 float64) DoubleStream; Doubles_D_D__DoubleStream(p0, p1 float64) DoubleStream }

func (t *Random) Self_Random() *Random { return t }

func (t *Random) Is_RandomGenerator() {}

func (t *Random) Is_Serializable() {}

const Random_serialVersionUID int64 = 3905348978240129619

const Random_multiplier int64 = 25214903917

const Random_addend int64 = 11

const Random_mask int64 = 281474976710655

const Random_DOUBLE_UNIT float64 = 1.1102230246251565e-16

const Random_FLOAT_UNIT float32 = 5.9604645e-8

var Random_seedUniquifier *AtomicLong

var Random_unsafe *Unsafe

var Random_seedOffset int64

var Random_init ClassInit

func Random_Init() { if !Random_init.Done() { Random_init.Run(Random_clinit) } }

func Random_clinit() { Random_seedUniquifier = AtomicLong_New_J(8682522807148012); Random_unsafe = Unsafe_GetUnsafe__Unsafe()
//line :11:1
	Random_seedOffset = NN(Random_unsafe).ObjectFieldOffset_Class_String__J(Random_class, Lit_2814)
}












































































































































































































































































































































































func (t *Random) NextInt_I__I(p0 int32) int32 { return t.Impl_NextInt_I__I(t, p0) }

func (t *Random) Doubles_D_D__DoubleStream(p0, p1 float64) DoubleStream { return t.Impl_Doubles_D_D__DoubleStream(t, p0, p1) }

func (t *Random) NextDouble_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextDouble_D_D__D(t, p0, p1) }

func (t *Random) Doubles_J_D_D__DoubleStream(p0 int64, p1, p2 float64) DoubleStream { return t.Impl_Doubles_J_D_D__DoubleStream(t, p0, p1, p2) }

func (t *Random) Longs_J__LongStream(p0 int64) LongStream { return t.Impl_Longs_J__LongStream(t, p0) }

func (t *Random) NextLong_J_J__J(p0, p1 int64) int64 { return RandomGenerator_NextLong_J_J__J(t, p0, p1) }

func (t *Random) NextFloat_F__F(p0 float32) float32 { return RandomGenerator_NextFloat_F__F(t, p0) }

func (t *Random) SetSeed_J__V(p0 int64) { t.Impl_SetSeed_J__V(t, p0) }

func (t *Random) Longs_J_J__LongStream(p0, p1 int64) LongStream { return t.Impl_Longs_J_J__LongStream(t, p0, p1) }

func (t *Random) NextLong_J__J(p0 int64) int64 { return RandomGenerator_NextLong_J__J(t, p0) }

func (t *Random) Ints_J_I_I__IntStream(p0 int64, p1, p2 int32) IntStream { return t.Impl_Ints_J_I_I__IntStream(t, p0, p1, p2) }

func (t *Random) NextDouble__D() float64 { return t.Impl_NextDouble__D(t) }

func (t *Random) Ints_I_I__IntStream(p0, p1 int32) IntStream { return t.Impl_Ints_I_I__IntStream(t, p0, p1) }

func (t *Random) NextInt_I_I__I(p0, p1 int32) int32 { return RandomGenerator_NextInt_I_I__I(t, p0, p1) }

func (t *Random) EquiDoubles_D_D_Z_Z__DoubleStream(p0, p1 float64, p2, p3 bool) DoubleStream { return RandomGenerator_EquiDoubles_D_D_Z_Z__DoubleStream(t, p0, p1, p2, p3) }

func (t *Random) NextBoolean__Z() bool { return t.Impl_NextBoolean__Z(t) }

func (t *Random) NextGaussian__D() float64 { return t.Impl_NextGaussian__D(t) }

func (t *Random) Ints__IntStream() IntStream { return t.Impl_Ints__IntStream(t) }

func (t *Random) NextExponential__D() float64 { return RandomGenerator_NextExponential__D(t) }

func (t *Random) IsDeprecated__Z() bool { return RandomGenerator_IsDeprecated__Z(t) }

func (t *Random) Doubles_J__DoubleStream(p0 int64) DoubleStream { return t.Impl_Doubles_J__DoubleStream(t, p0) }

func (t *Random) NextFloat_F_F__F(p0, p1 float32) float32 { return RandomGenerator_NextFloat_F_F__F(t, p0, p1) }

func (t *Random) Ints_J__IntStream(p0 int64) IntStream { return t.Impl_Ints_J__IntStream(t, p0) }

func (t *Random) NextFloat__F() float32 { return t.Impl_NextFloat__F(t) }

func (t *Random) Next_I__I(p0 int32) int32 { return t.Impl_Next_I__I(t, p0) }

func (t *Random) NextBytes_B1__V(p0 *ByteArray) { t.Impl_NextBytes_B1__V(t, p0) }

func (t *Random) Longs_J_J_J__LongStream(p0, p1, p2 int64) LongStream { return t.Impl_Longs_J_J_J__LongStream(t, p0, p1, p2) }

func (t *Random) Doubles__DoubleStream() DoubleStream { return t.Impl_Doubles__DoubleStream(t) }

func (t *Random) NextGaussian_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextGaussian_D_D__D(t, p0, p1) }

func (t *Random) NextDouble_D__D(p0 float64) float64 { return RandomGenerator_NextDouble_D__D(t, p0) }

func (t *Random) NextLong__J() int64 { return t.Impl_NextLong__J(t) }

func (t *Random) Longs__LongStream() LongStream { return t.Impl_Longs__LongStream(t) }

func (t *Random) NextInt__I() int32 { return t.Impl_NextInt__I(t) }

func (t *Random) Ref() any { if t == nil { return nil }; return t }

func (t *Random) GetClass__Class() *Class { return Random_class }

func (t *Random) ToString__String() *String { return Object_toString(t) }

func (t *Random) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Random) CloneShallow() any { panic(CloneNotSupported(t)) }

func Random_InstanceOf(x any) bool { _, ok := x.(Random_I); return ok }

func Random_Cast(x any) Random_I { if x == nil { return nil }; v, ok := x.(Random_I); if !ok { panic(ClassCast(x, Random_class)) }; return v }



type Random_RandomWrapper struct{ Random; F_generator RandomGenerator }

var Random_RandomWrapper_init ClassInit

func Random_RandomWrapper_Init() { if !Random_RandomWrapper_init.Done() { Random_RandomWrapper_init.Run(Random_RandomWrapper_clinit) } }

func Random_RandomWrapper_clinit() { Random_Init() }

func (t *Random_RandomWrapper) EquiDoubles_D_D_Z_Z__DoubleStream(p0, p1 float64, p2, p3 bool) DoubleStream { return RandomGenerator_EquiDoubles_D_D_Z_Z__DoubleStream(t, p0, p1, p2, p3) }

func (t *Random_RandomWrapper) Ref() any { if t == nil { return nil }; return t }

func (t *Random_RandomWrapper) GetClass__Class() *Class { return Random_RandomWrapper_class }

func (t *Random_RandomWrapper) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Random_RandomWrapper) CloneShallow() any { panic(CloneNotSupported(t)) }

func Random_RandomWrapper_InstanceOf(x any) bool { _, ok := x.(*Random_RandomWrapper); return ok }

func Random_RandomWrapper_Cast(x any) *Random_RandomWrapper { if x == nil { return nil }; v, ok := x.(*Random_RandomWrapper); if !ok { panic(ClassCast(x, Random_RandomWrapper_class)) }; return v }
