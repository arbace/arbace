//line java_net_InetAddressImpl.ae:1
package jrt






type InetAddressImpl interface{ Object_I; Is_InetAddressImpl(); GetLocalHostName__String() *String; LookupAllHostAddr_String_InetAddressResolver_LookupPolicy__InetAddress1(p0 *String, p1 *InetAddressResolver_LookupPolicy) *RefArray; GetHostByAddr_B1__String(p0 *ByteArray) *String; AnyLocalAddress__InetAddress() InetAddress_I; LoopbackAddress__InetAddress() InetAddress_I }

func InetAddressImpl_InstanceOf(x any) bool { _, ok := x.(InetAddressImpl); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InetAddressImpl_class) } }; return ok }

func InetAddressImpl_Cast(x any) InetAddressImpl { if x == nil { return nil }; v, ok := x.(InetAddressImpl); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InetAddressImpl_class) } }; if !ok { panic(ClassCast(x, InetAddressImpl_class)) }; return v }
