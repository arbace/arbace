//line java_util_ArrayList.ae:1
package jrt





























func ArrayList_New_I(p0 int32) *ArrayList { ArrayList_Init(); t := &ArrayList{}; t.Ctor_I(p0); return t }
//line :31:1
func (t *ArrayList) Ctor_I(initialCapacity int32) { t.AbstractList.Ctor(t)
	if initialCapacity > 0 {
		t.F_elementData = NewRefArray(Object_class, initialCapacity) } else {
//line :32:1
			if initialCapacity == 0 {

				t.F_elementData = ArrayList_EMPTY_ELEMENTDATA } else {
					panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2601, StrOfInt(initialCapacity)))))
				} } }
func ArrayList_New() *ArrayList { ArrayList_Init(); t := &ArrayList{}; t.Ctor(); return t }
//line :37:1
func (t *ArrayList) Ctor() { t.AbstractList.Ctor(t)
	t.F_elementData = ArrayList_DEFAULTCAPACITY_EMPTY_ELEMENTDATA
}
func ArrayList_New_Collection(p0 Collection) *ArrayList { ArrayList_Init(); t := &ArrayList{}; t.Ctor_Collection(p0); return t }
//line :40:1
func (t *ArrayList) Ctor_Collection(c Collection) { t.AbstractList.Ctor(t)
	var a *RefArray = c.ToArray__O1(); var tmp1 int32; var tmp2 int32 = int32(len(a.A))
	t.F_size = tmp2; tmp1 = tmp2; if !(tmp1 == 0) {
		if c.GetClass__Class() == ArrayList_class {
			t.F_elementData = a } else {
				t.F_elementData = Arrays_CopyOf_O1_I_Class__O1(a, t.F_size, Object_class.ArrayClass()) } } else {
					t.F_elementData = ArrayList_EMPTY_ELEMENTDATA
				} }
func (t *ArrayList) TrimToSize__V() {
	t.F_modCount = t.F_modCount + 1
	var tmp1 int32 = t.F_size; if tmp1 < int32(len(t.F_elementData.A)) {
		var tmp2 *RefArray; if t.F_size == 0 { tmp2 = ArrayList_EMPTY_ELEMENTDATA } else { tmp2 = Arrays_CopyOf_O1_I__O1(t.F_elementData, t.F_size) }; t.F_elementData = tmp2
	} }
func (t *ArrayList) EnsureCapacity_I__V(minCapacity int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = minCapacity > int32(len(t.F_elementData.A)); if tmp2 {
		var tmp3 bool; var tmp4 bool; tmp4 = t.F_elementData == ArrayList_DEFAULTCAPACITY_EMPTY_ELEMENTDATA; if tmp4 {
			tmp4 = minCapacity <= 10 }
//line :55:1
		tmp3 = tmp4; tmp2 = !tmp3 }
//line :54:1
	tmp1 = tmp2; if tmp1 {


		t.F_modCount = t.F_modCount + 1
		t.Grow_I__O1(minCapacity)
	} }
func (t *ArrayList) Grow_I__O1(minCapacity int32) *RefArray {
	var oldCapacity int32 = int32(len(t.F_elementData.A)); var tmp1 bool; var tmp2 bool
	tmp2 = oldCapacity > 0; if !tmp2 { tmp2 = !(t.F_elementData == ArrayList_DEFAULTCAPACITY_EMPTY_ELEMENTDATA) }; tmp1 = tmp2; if tmp1 {
		var newCapacity int32 = ArraysSupport_NewLength_I_I_I__I(oldCapacity, minCapacity-oldCapacity, oldCapacity>>1); var tmp3 *RefArray = Arrays_CopyOf_O1_I__O1(t.F_elementData, newCapacity)



		t.F_elementData = tmp3; return tmp3 } else {
			var tmp4 *RefArray = NewRefArray(Object_class, Math_Max_I_I__I(10, minCapacity)); t.F_elementData = tmp4; return tmp4
		} }
func (t *ArrayList) Grow__O1() *RefArray {
	return t.Grow_I__O1(t.F_size + 1)
}
func (t *ArrayList) Size__I() int32 { return t.F_size }

func (t *ArrayList) IsEmpty__Z() bool { return t.F_size == 0 }

func (t *ArrayList) Contains_O__Z(o any) bool { return t.IndexOf_O__I(o) >= 0 }

func (t *ArrayList) IndexOf_O__I(o any) int32 { return t.IndexOfRange_O_I_I__I(o, 0, t.F_size) }

func (t *ArrayList) IndexOfRange_O_I_I__I(o any, start, end int32) int32 {
	var es *RefArray = t.F_elementData
	if o == nil {
		var i int32 = start; L1: for {
			if i < end { if es.A[i] == nil { return i } else { i = i + 1; continue L1 } }
//line :84:1
			break L1 } } else {

				var i_2 int32 = start; L2: for {
					if i_2 < end { if Equals(o, es.A[i_2]) { return i_2 } else { i_2 = i_2 + 1; continue L2 } }
//line :86:1
					break L2 } }
//line :82:1
	return -1
}






func (t *ArrayList) LastIndexOf_O__I(o any) int32 {
	return t.LastIndexOfRange_O_I_I__I(o, 0, t.F_size)
}
func (t *ArrayList) LastIndexOfRange_O_I_I__I(o any, start, end int32) int32 {
	var es *RefArray = t.F_elementData
	if o == nil {
		var i int32 = end - 1; L1: for {
			if i >= start { if es.A[i] == nil { return i } else { i = i - 1; continue L1 } }
//line :96:1
			break L1 } } else {

				var i_2 int32 = end - 1; L2: for {
					if i_2 >= start {
						if Equals(o, es.A[i_2]) { return i_2 } else { i_2 = i_2 - 1; continue L2 } }
//line :98:1
					break L2 } }
//line :94:1
	return -1
}








func (t *ArrayList) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var v *ArrayList = ArrayList_Cast(A2g_ObjectClone(t))
			v.F_elementData = Arrays_CopyOf_O1_I__O1(t.F_elementData, t.F_size)
			v.F_modCount = 0
//line :106:1
			tmp1 = v.Ref()
		}
		return nil }()
//line :105:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)




		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :105:1
			panic(tmp2) } }; return tmp1
}





func (t *ArrayList) ToArray__O1() *RefArray {
	return Arrays_CopyOf_O1_I__O1(t.F_elementData, t.F_size)
}
func (t *ArrayList) ToArray_O1__O1(a *RefArray) *RefArray {
	if int32(len(a.A)) < t.F_size {
		var tmp1 *RefArray = t.F_elementData; var tmp2 int32 = t.F_size; return Arrays_CopyOf_O1_I_Class__O1(tmp1, tmp2, GetClass(a.Ref())) } else {

			System_Arraycopy_O_I_O_I_I__V(t.F_elementData.Ref(), 0, a.Ref(), 0, t.F_size)
			if int32(len(a.A)) > t.F_size { a.Store(t.F_size, nil) }
//line :118:1
			return a
		}
}


func (t *ArrayList) ElementData_I__O(index int32) any { return t.F_elementData.A[index] }

func ArrayList_ElementAt_O1_I__O(es *RefArray, index int32) any {
	return es.A[index]
}
func (t *ArrayList) Get_I__O(index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	return t.ElementData_I__O(index)
}
func (t *ArrayList) GetFirst__O() any {
	if t.F_size == 0 { panic(Thrown(NoSuchElementException_New())) } else { return t.ElementData_I__O(0)
	} }
func (t *ArrayList) GetLast__O() any {
	var last int32 = t.F_size - 1
	if last < 0 { panic(Thrown(NoSuchElementException_New())) } else { return t.ElementData_I__O(last)
	} }
func (t *ArrayList) Set_I_O__O(index int32, element any) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	var oldValue any = t.ElementData_I__O(index); t.F_elementData.Store(index, element); return oldValue
}
func (t *ArrayList) Add_O_O1_I__V(e any, elementData *RefArray, s int32) {
	if s == int32(len(elementData.A)) { elementData = t.Grow__O1() }
	elementData.Store(s, e)
	t.F_size = s + 1
}
func (t *ArrayList) Add_O__Z(e any) bool {
	t.F_modCount = t.F_modCount + 1
	t.Add_O_O1_I__V(e, t.F_elementData, t.F_size)
//line :148:1
	return true
}



func (t *ArrayList) Add_I_O__V(index int32, element any) {
	t.RangeCheckForAdd_I__V(index)
	t.F_modCount = t.F_modCount + 1
	var s int32 = 0; var elementData *RefArray; var tmp1 int32

	s = t.F_size; tmp1 = s; var tmp2 int32 = tmp1; var tmp3 *RefArray; elementData = t.F_elementData; tmp3 = elementData; if tmp2 == int32(len(tmp3.A)) {
		elementData = t.Grow__O1() }
	System_Arraycopy_O_I_O_I_I__V(elementData.Ref(), index, elementData.Ref(), index+1, s-index)




	elementData.Store(index, element)
	t.F_size = s + 1
}
func (t *ArrayList) AddFirst_O__V(element any) { t.Add_I_O__V(0, element) }

func (t *ArrayList) AddLast_O__V(element any) { t.Add_O__Z(element) }

func (t *ArrayList) Remove_I__O(index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	var es *RefArray = t.F_elementData; var oldValue any = es.A[index]; t.FastRemove_O1_I__V(es, index); return oldValue
}
func (t *ArrayList) RemoveFirst__O() any {
	if t.F_size == 0 {
		panic(Thrown(NoSuchElementException_New())) } else {
			var es *RefArray = t.F_elementData; var oldValue any = es.A[0]; t.FastRemove_O1_I__V(es, 0); return oldValue
		} }
func (t *ArrayList) RemoveLast__O() any {
	var last int32 = t.F_size - 1
	if last < 0 {
		panic(Thrown(NoSuchElementException_New())) } else {
			var es *RefArray = t.F_elementData; var oldValue any = es.A[last]; t.FastRemove_O1_I__V(es, last); return oldValue
		} }
func (t *ArrayList) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else { if !List_InstanceOf(o) { return false } else {



		var expectedModCount int32 = t.F_modCount; var equal bool
		if GetClass(o) == ArrayList_class {
			equal = t.EqualsArrayList_ArrayList__Z(ArrayList_Cast(o)) } else {
				equal = t.EqualsRange_List_I_I__Z(List_Cast(o), 0, t.F_size) }
		t.CheckForComodification_I__V(expectedModCount)
//line :192:1
		return equal
	}
	}
}



func (t *ArrayList) EqualsRange_List_I_I__Z(other List, from, to int32) bool {
	var es *RefArray = t.F_elementData
	if to > int32(len(es.A)) { panic(Thrown(ConcurrentModificationException_New())) }
	var oit Iterator = other.Iterator__Iterator()
L1: for { if from < to {
	var tmp1 bool; var tmp2 bool; tmp2 = !oit.HasNext__Z(); if !tmp2 { var tmp3 any = es.A[from]; tmp2 = !Objects_Equals_O_O__Z(tmp3, oit.Next__O()) }; tmp1 = tmp2; if tmp1 {
		return false }
	from = from + 1
//line :203:1
	continue L1 }; break L1
}


	return !oit.HasNext__Z()
}
func (t *ArrayList) EqualsArrayList_ArrayList__Z(other *ArrayList) bool {
	var otherModCount int32 = other.F_modCount; var s int32 = t.F_size; var equal bool = false; var tmp1 bool


	equal = s == other.F_size; tmp1 = equal; if tmp1 {
		var otherEs *RefArray = other.F_elementData; var es *RefArray = t.F_elementData; var tmp2 bool; var tmp3 bool

		tmp3 = s > int32(len(es.A)); if !tmp3 { tmp3 = s > int32(len(otherEs.A)) }; tmp2 = tmp3; if tmp2 {
			panic(Thrown(ConcurrentModificationException_New())) }
		var i int32 = 0; L1: for {
			if i < s {
				var tmp4 any = es.A[i]; if !Objects_Equals_O_O__Z(tmp4, otherEs.A[i]) {
					equal = false } else {
						i = i + 1; continue L1 } }
//line :218:1
			break L1
		}
	}



	NN(other).CheckForComodification_I__V(otherModCount)
//line :210:1
	return equal
}















func (t *ArrayList) CheckForComodification_I__V(expectedModCount int32) {
	if t.F_modCount == expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *ArrayList) HashCode__I() int32 {
	var expectedModCount int32 = t.F_modCount; var hash int32 = t.HashCodeRange_I_I__I(0, t.F_size)

	t.CheckForComodification_I__V(expectedModCount)
//line :231:1
	return hash
}



func (t *ArrayList) HashCodeRange_I_I__I(from, to int32) int32 {
	var es *RefArray = t.F_elementData
	if to > int32(len(es.A)) { panic(Thrown(ConcurrentModificationException_New())) }
	var hashCode int32 = 1; var i int32 = from
L1: for {
	if i < to {
		var e any = es.A[i]; var tmp1 int32 = 31 * hashCode; var tmp2 int32


		if e == nil { tmp2 = 0 } else { tmp2 = HashCode(e) }
//line :243:1
		hashCode = tmp1 + tmp2


		i = i + 1; continue L1 }
//line :240:1
	break L1 }
//line :239:1
	return hashCode
}








func (t *ArrayList) Remove_O__Z(o any) bool {
	var es *RefArray = t.F_elementData; var size int32 = t.F_size
	var i int32 = 0

L1: switch { default:
	if o == nil {
	L2: for { if i < size {
		if es.A[i] == nil { break L1 }
		i = i + 1
//line :255:1
		continue L2 }; break L2
	} } else {

	L3: for { if i < size {
		if Equals(o, es.A[i]) { break L1 }
		i = i + 1
//line :258:1
		continue L3 }; break L3
	}
	}
	return false}
	t.FastRemove_O1_I__V(es, i)
//line :250:1
	return true
}













func (t *ArrayList) FastRemove_O1_I__V(es *RefArray, i int32) {
	t.F_modCount = t.F_modCount + 1
	var newSize int32 = 0; var tmp1 int32
	newSize = t.F_size - 1; tmp1 = newSize; if tmp1 > i {
		System_Arraycopy_O_I_O_I_I__V(es.Ref(), i+1, es.Ref(), i, newSize-i) }
	var tmp2 int32; var tmp3 int32 = newSize; t.F_size = tmp3; tmp2 = tmp3; es.Store(tmp2, nil)
}
func (t *ArrayList) Clear__V() {
	t.F_modCount = t.F_modCount + 1
	var es *RefArray = t.F_elementData; var to int32 = t.F_size; var i int32
	var tmp1 int32 = 0
	t.F_size = tmp1; i = tmp1
//line :275:1
L1: for {

	if i < to { es.Store(i, nil); to, i = to, i+1; continue L1 }
//line :275:1
	break L1
}
}

func (t *ArrayList) AddAll_Collection__Z(c Collection) bool {
	var a *RefArray
	var numNew int32 = 0
	if c.GetClass__Class() == ArrayList_class {
		var src *ArrayList = ArrayList_Cast(c)
		a = src.F_elementData
		numNew = src.F_size } else {
			a = c.ToArray__O1(); numNew = int32(len(a.A)) }
	t.F_modCount = t.F_modCount + 1
	if numNew == 0 { return false } else {

		var elementData *RefArray; var s int32 = 0; var tmp1 int32 = numNew; var tmp2 *RefArray


		elementData = t.F_elementData; tmp2 = elementData
//line :292:1
		var tmp3 int32 = int32(len(tmp2.A)); var tmp4 int32

		s = t.F_size; tmp4 = s
//line :292:1
		if tmp1 > tmp3-tmp4 {


			elementData = t.Grow_I__O1(s + numNew) }
		System_Arraycopy_O_I_O_I_I__V(a.Ref(), 0, elementData.Ref(), s, numNew)
		t.F_size = s + numNew
//line :290:1
		return true
	}
}







func (t *ArrayList) AddAll_I_Collection__Z(index int32, c Collection) bool {
	t.RangeCheckForAdd_I__V(index)
	var a *RefArray = c.ToArray__O1()
	t.F_modCount = t.F_modCount + 1
	var numNew int32 = int32(len(a.A))
	if numNew == 0 { return false } else {

		var elementData *RefArray; var s int32 = 0; var tmp1 *RefArray


		elementData = t.F_elementData; tmp1 = elementData
//line :309:1
		var tmp2 int32 = int32(len(tmp1.A)); var tmp3 int32

		s = t.F_size; tmp3 = s
//line :309:1
		if numNew > tmp2-tmp3 {


			elementData = t.Grow_I__O1(s + numNew) }
		var numMoved int32 = s - index
		if numMoved > 0 {
			System_Arraycopy_O_I_O_I_I__V(elementData.Ref(), index, elementData.Ref(), index+numNew, numMoved)
		}



		System_Arraycopy_O_I_O_I_I__V(a.Ref(), 0, elementData.Ref(), index, numNew)
		t.F_size = s + numNew
//line :313:1
		return true
	}
}








func (t *ArrayList) RemoveRange_I_I__V(fromIndex, toIndex int32) {
	if fromIndex > toIndex {
		panic(Thrown(IndexOutOfBoundsException_New_String(ArrayList_OutOfBoundsMsg_I_I__String(fromIndex, toIndex)))) }
	t.F_modCount = t.F_modCount + 1
	t.ShiftTailOverGap_O1_I_I__V(t.F_elementData, fromIndex, toIndex)
}
func (t *ArrayList) ShiftTailOverGap_O1_I_I__V(es *RefArray, lo, hi int32) {
	System_Arraycopy_O_I_O_I_I__V(es.Ref(), hi, es.Ref(), lo, t.F_size-hi)
	var to int32 = t.F_size; var i int32; var tmp1 int32 = t.F_size - (hi - lo)
	t.F_size = tmp1; i = tmp1
//line :332:1
L1: for {

	if i < to { es.Store(i, nil); to, i = to, i+1; continue L1 }
//line :332:1
	break L1
}
}

func (t *ArrayList) RangeCheckForAdd_I__V(index int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = index > t.F_size; if !tmp2 { tmp2 = index < 0 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IndexOutOfBoundsException_New_String(t.OutOfBoundsMsg_I__String(index))))
	} }
func (t *ArrayList) OutOfBoundsMsg_I__String(index int32) *String {
	return Concat(Lit_2595, StrOfInt(index), Lit_2596, StrOfInt(t.F_size))
}
func ArrayList_OutOfBoundsMsg_I_I__String(fromIndex, toIndex int32) *String {
	return Concat(Lit_2602, StrOfInt(fromIndex), Lit_2603, StrOfInt(toIndex))
}
func (t *ArrayList) RemoveAll_Collection__Z(c Collection) bool {
	return t.BatchRemove_Collection_Z_I_I__Z(c, false, 0, t.F_size)
}
func (t *ArrayList) RetainAll_Collection__Z(c Collection) bool {
	return t.BatchRemove_Collection_Z_I_I__Z(c, true, 0, t.F_size)
}
func (t *ArrayList) BatchRemove_Collection_Z_I_I__Z(c Collection, complement bool, from, end int32) bool {

	Objects_RequireNonNull_O__O(c)
	var es *RefArray = t.F_elementData
	var r int32 = 0
	r = from
L1: for {
	if r == end { return false }
	if c.Contains_O__Z(es.A[r]) == complement { } else { break L1 }
	r = r + 1
//line :358:1
	continue L1
}


	var w int32; var old_1 int32 = r; r = r + 1; w = old_1; tmp3 := func() (exc Throwable_I) { defer Catch(&exc); { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var e any
		L2: for { if r < end {
			var tmp1 any; e = es.A[r]; tmp1 = e; if c.Contains_O__Z(tmp1) == complement {
				es.Store(w, e)
				w = w + 1 }
			r = r + 1
//line :365:1
			continue L2 }; break L2
		}
		}

		return nil }()
//line :363:1
		if tmp2 != nil { if true { var ex Throwable_I = tmp2







			System_Arraycopy_O_I_O_I_I__V(es.Ref(), r, es.Ref(), w, end-r)
			w = w + (end - r)
			panic(Thrown(ex)) } } }
//line :369:1
		return nil
	}()




	t.F_modCount = t.F_modCount + (end - w)

	t.ShiftTailOverGap_O1_I_I__V(es, w, end)
//line :363:1
	if tmp3 != nil { panic(tmp3) }
//line :362:1
	return true
}







































func (t *ArrayList) ListIterator_I__ListIterator(index int32) ListIterator {
	t.RangeCheckForAdd_I__V(index)
	return ArrayList_ListItr_New_ArrayList_I(t, index)
}
func (t *ArrayList) ListIterator__ListIterator() ListIterator {
	return ArrayList_ListItr_New_ArrayList_I(t, 0)
}
func (t *ArrayList) Iterator__Iterator() Iterator { return ArrayList_Itr_New_ArrayList(t) }










func ArrayList_Itr_New_ArrayList(p0 *ArrayList) *ArrayList_Itr { t := &ArrayList_Itr{}; t.Ctor_ArrayList(t, p0); return t }
//line :421:1
func (t *ArrayList_Itr) Ctor_ArrayList(this ArrayList_Itr_I, this_0 *ArrayList) { NN(this_0); t.F_this_0 = this_0; t.F_lastRet = -1; t.F_expectedModCount = this_0.F_modCount }

func (t *ArrayList_Itr) Impl_HasNext__Z(this ArrayList_Itr_I) bool { return !(t.F_cursor == t.F_this_0.F_size) }

func (t *ArrayList_Itr) Impl_Next__O(this ArrayList_Itr_I) any {
	this.CheckForComodification__V()
	var i int32 = t.F_cursor
	if i >= t.F_this_0.F_size { panic(Thrown(NoSuchElementException_New())) }
	var elementData *RefArray = t.F_this_0.F_elementData
	if i >= int32(len(elementData.A)) { panic(Thrown(ConcurrentModificationException_New())) }
	t.F_cursor = i + 1
	var tmp1 int32; var tmp2 int32 = i; t.F_lastRet = tmp2; tmp1 = tmp2; return elementData.A[tmp1]
}
func (t *ArrayList_Itr) Impl_Remove__V(this ArrayList_Itr_I) {
	if t.F_lastRet < 0 { panic(Thrown(IllegalStateException_New())) }
	this.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		NN(t.F_this_0).Remove_I__O(t.F_lastRet)
		t.F_cursor = t.F_lastRet
		t.F_lastRet = -1
		t.F_expectedModCount = t.F_this_0.F_modCount; return nil }()
//line :437:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex




		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :437:1
			panic(tmp1)
		}
	}
}



func (t *ArrayList_Itr) Impl_ForEachRemaining_Consumer__V(this ArrayList_Itr_I, action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var size int32 = t.F_this_0.F_size; var i int32 = t.F_cursor

	if i < size {
		var es *RefArray = t.F_this_0.F_elementData
		if i >= int32(len(es.A)) { panic(Thrown(ConcurrentModificationException_New())) }
	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = i < size; if tmp2 { tmp2 = t.F_this_0.F_modCount == t.F_expectedModCount }; tmp1 = tmp2; if tmp1 {
		action.Accept_O__V(ArrayList_ElementAt_O1_I__O(es, i))
		i = i + 1
//line :451:1
		continue L1 }; break L1
	}

		t.F_cursor = i
		t.F_lastRet = i - 1
		this.CheckForComodification__V()
	} }
func (t *ArrayList_Itr) Impl_CheckForComodification__V(this ArrayList_Itr_I) {
	if t.F_this_0.F_modCount == t.F_expectedModCount { } else {
		panic(Thrown(ConcurrentModificationException_New()))
	}
}



func ArrayList_ListItr_New_ArrayList_I(p0 *ArrayList, p1 int32) *ArrayList_ListItr { t := &ArrayList_ListItr{}; t.Ctor_ArrayList_I(p0, p1); return t }
//line :466:1
func (t *ArrayList_ListItr) Ctor_ArrayList_I(this_0 *ArrayList, index int32) { NN(this_0); t.F_this_0 = this_0; t.ArrayList_Itr.Ctor_ArrayList(t, this_0); t.F_cursor = index }

func (t *ArrayList_ListItr) HasPrevious__Z() bool {
	return !(t.F_cursor == 0)
}
func (t *ArrayList_ListItr) NextIndex__I() int32 { return t.F_cursor }

func (t *ArrayList_ListItr) PreviousIndex__I() int32 {
	return t.F_cursor - 1
}
func (t *ArrayList_ListItr) Previous__O() any {
	t.CheckForComodification__V()
	var i int32 = t.F_cursor - 1
	if i < 0 { panic(Thrown(NoSuchElementException_New())) }
	var elementData *RefArray = t.F_this_0.F_elementData
	if i >= int32(len(elementData.A)) { panic(Thrown(ConcurrentModificationException_New())) }
	t.F_cursor = i
	var tmp1 int32; var tmp2 int32 = i; t.F_lastRet = tmp2; tmp1 = tmp2; return elementData.A[tmp1]
}
func (t *ArrayList_ListItr) Set_O__V(e any) {
	if t.F_lastRet < 0 { panic(Thrown(IllegalStateException_New())) }
	t.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		NN(t.F_this_0).Set_I_O__O(t.F_lastRet, e); return nil }()
//line :488:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex

		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :488:1
			panic(tmp1)
		}
	}
}
func (t *ArrayList_ListItr) Add_O__V(e any) {
	t.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var i int32 = t.F_cursor
			NN(t.F_this_0).Add_I_O__V(i, e)
			t.F_cursor = i + 1
			t.F_lastRet = -1
			t.F_expectedModCount = t.F_this_0.F_modCount }; return nil }()
//line :494:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex





		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :494:1
			panic(tmp1)
		}
	}
}




func (t *ArrayList) SubList_I_I__List(fromIndex, toIndex int32) List {
	AbstractList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, t.F_size)
	return ArrayList_SubList_New_ArrayList_I_I(t, fromIndex, toIndex)
}













func ArrayList_SubList_New_ArrayList_I_I(p0 *ArrayList, p1, p2 int32) *ArrayList_SubList { t := &ArrayList_SubList{}; t.Ctor_ArrayList_I_I(p0, p1, p2); return t }
//line :519:1
func (t *ArrayList_SubList) Ctor_ArrayList_I_I(root *ArrayList, fromIndex, toIndex int32) { t.AbstractList.Ctor(t)
	t.F_root = root
	t.F_parent = nil
	t.F_offset = fromIndex
	t.F_size = toIndex - fromIndex
	t.F_modCount = root.F_modCount
}
func ArrayList_SubList_New_ArrayList_SubList_I_I(p0 *ArrayList_SubList, p1, p2 int32) *ArrayList_SubList { t := &ArrayList_SubList{}; t.Ctor_ArrayList_SubList_I_I(p0, p1, p2); return t }
//line :526:1
func (t *ArrayList_SubList) Ctor_ArrayList_SubList_I_I(parent *ArrayList_SubList, fromIndex, toIndex int32) { t.AbstractList.Ctor(t)
	t.F_root = parent.F_root
	t.F_parent = parent
	t.F_offset = parent.F_offset + fromIndex
	t.F_size = toIndex - fromIndex
	t.F_modCount = parent.F_modCount
}
func (t *ArrayList_SubList) Set_I_O__O(index int32, element any) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	t.CheckForComodification__V()
	var oldValue any = NN(t.F_root).ElementData_I__O(t.F_offset + index)
	t.F_root.F_elementData.Store(t.F_offset+index, element)
//line :536:1
	return oldValue
}


func (t *ArrayList_SubList) Get_I__O(index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	t.CheckForComodification__V()
	return NN(t.F_root).ElementData_I__O(t.F_offset + index)
}
func (t *ArrayList_SubList) Size__I() int32 { t.CheckForComodification__V(); return t.F_size }

func (t *ArrayList_SubList) Add_I_O__V(index int32, element any) {
	t.RangeCheckForAdd_I__V(index)
	t.CheckForComodification__V()
	NN(t.F_root).Add_I_O__V(t.F_offset+index, element)
	t.UpdateSizeAndModCount_I__V(1)
}
func (t *ArrayList_SubList) Remove_I__O(index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	t.CheckForComodification__V()
	var result any = NN(t.F_root).Remove_I__O(t.F_offset + index)
	t.UpdateSizeAndModCount_I__V(-1)
//line :556:1
	return result
}


func (t *ArrayList_SubList) RemoveRange_I_I__V(fromIndex, toIndex int32) {
	t.CheckForComodification__V()
	NN(t.F_root).RemoveRange_I_I__V(t.F_offset+fromIndex, t.F_offset+toIndex)
	t.UpdateSizeAndModCount_I__V(fromIndex - toIndex)
}
func (t *ArrayList_SubList) AddAll_Collection__Z(c Collection) bool {
	return t.AddAll_I_Collection__Z(t.F_size, c)
}
func (t *ArrayList_SubList) AddAll_I_Collection__Z(index int32, c Collection) bool {
	t.RangeCheckForAdd_I__V(index)
	var cSize int32 = c.Size__I()
	if cSize == 0 { return false } else {


		t.CheckForComodification__V()
		NN(t.F_root).AddAll_I_Collection__Z(t.F_offset+index, c)
		t.UpdateSizeAndModCount_I__V(cSize)
//line :573:1
		return true
	}
}



func (t *ArrayList_SubList) ReplaceAll_UnaryOperator__V(operator UnaryOperator) {
	NN(t.F_root).ReplaceAllRange_UnaryOperator_I_I__V(operator, t.F_offset, t.F_offset+t.F_size)
}
func (t *ArrayList_SubList) RemoveAll_Collection__Z(c Collection) bool {
	return t.BatchRemove_Collection_Z__Z(c, false)
}
func (t *ArrayList_SubList) RetainAll_Collection__Z(c Collection) bool {
	return t.BatchRemove_Collection_Z__Z(c, true)
}
func (t *ArrayList_SubList) BatchRemove_Collection_Z__Z(c Collection, complement bool) bool {
	t.CheckForComodification__V()
	var oldSize int32 = t.F_root.F_size; var modified bool = NN(t.F_root).BatchRemove_Collection_Z_I_I__Z(c, complement, t.F_offset, t.F_offset+t.F_size)

	if modified { t.UpdateSizeAndModCount_I__V(t.F_root.F_size - oldSize) }
//line :590:1
	return modified
}



func (t *ArrayList_SubList) RemoveIf_Predicate__Z(filter Predicate) bool {
	t.CheckForComodification__V()
	var oldSize int32 = t.F_root.F_size; var modified bool = NN(t.F_root).RemoveIf_Predicate_I_I__Z(filter, t.F_offset, t.F_offset+t.F_size)

	if modified { t.UpdateSizeAndModCount_I__V(t.F_root.F_size - oldSize) }
//line :597:1
	return modified
}



func (t *ArrayList_SubList) ToArray__O1() *RefArray {
	t.CheckForComodification__V()
	return Arrays_CopyOfRange_O1_I_I__O1(t.F_root.F_elementData, t.F_offset, t.F_offset+t.F_size)
}
func (t *ArrayList_SubList) ToArray_O1__O1(a *RefArray) *RefArray {
	t.CheckForComodification__V()
	if int32(len(a.A)) < t.F_size {
		var tmp1 *RefArray = t.F_root.F_elementData; var tmp2 int32 = t.F_offset; var tmp3 int32 = t.F_offset + t.F_size; return Arrays_CopyOfRange_O1_I_I_Class__O1(tmp1, tmp2, tmp3, GetClass(a.Ref())) } else {




			System_Arraycopy_O_I_O_I_I__V(t.F_root.F_elementData.Ref(), t.F_offset, a.Ref(), 0, t.F_size)
			if int32(len(a.A)) > t.F_size { a.Store(t.F_size, nil) }
//line :613:1
			return a
		}
}


func (t *ArrayList_SubList) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else { if !List_InstanceOf(o) { return false } else {



		var tmp1 *ArrayList = t.F_root; var equal bool = NN(tmp1).EqualsRange_List_I_I__Z(List_Cast(o), t.F_offset, t.F_offset+t.F_size)
		t.CheckForComodification__V()
//line :623:1
		return equal
	}
	}
}
func (t *ArrayList_SubList) HashCode__I() int32 {
	var hash int32 = NN(t.F_root).HashCodeRange_I_I__I(t.F_offset, t.F_offset+t.F_size)
	t.CheckForComodification__V()
//line :628:1
	return hash
}


func (t *ArrayList_SubList) IndexOf_O__I(o any) int32 {
	var index int32 = NN(t.F_root).IndexOfRange_O_I_I__I(o, t.F_offset, t.F_offset+t.F_size)
	t.CheckForComodification__V()
	if index >= 0 { return index - t.F_offset } else { return -1
	} }
func (t *ArrayList_SubList) LastIndexOf_O__I(o any) int32 {
	var index int32 = NN(t.F_root).LastIndexOfRange_O_I_I__I(o, t.F_offset, t.F_offset+t.F_size)
	t.CheckForComodification__V()
	if index >= 0 { return index - t.F_offset } else { return -1
	} }
func (t *ArrayList_SubList) Contains_O__Z(o any) bool { return t.IndexOf_O__I(o) >= 0 }

func (t *ArrayList_SubList) Iterator__Iterator() Iterator {
	return t.ListIterator__ListIterator()
}
func (t *ArrayList_SubList) ListIterator_I__ListIterator(index int32) ListIterator {
	t.CheckForComodification__V()
	t.RangeCheckForAdd_I__V(index)
	return ArrayList_SubList_1_New_ArrayList_SubList_I(t, index)
}





func (t *ArrayList_SubList_1) HasNext__Z() bool {
	return !(t.F_cursor == t.F_this_0.F_size)
}
func (t *ArrayList_SubList_1) Next__O() any {
	t.CheckForComodification__V()
	var i int32 = t.F_cursor
	if i >= t.F_this_0.F_size { panic(Thrown(NoSuchElementException_New())) }
	var elementData *RefArray = t.F_this_0.F_root.F_elementData; var tmp1 int32 = t.F_this_0.F_offset + i
	if tmp1 >= int32(len(elementData.A)) {
		panic(Thrown(ConcurrentModificationException_New())) }
	t.F_cursor = i + 1
	var tmp2 int32 = t.F_this_0.F_offset; var tmp3 int32; var tmp4 int32 = i; t.F_lastRet = tmp4; tmp3 = tmp4; return elementData.A[tmp2+tmp3]
}
func (t *ArrayList_SubList_1) HasPrevious__Z() bool { return !(t.F_cursor == 0) }

func (t *ArrayList_SubList_1) Previous__O() any {
	t.CheckForComodification__V()
	var i int32 = t.F_cursor - 1
	if i < 0 { panic(Thrown(NoSuchElementException_New())) }
	var elementData *RefArray = t.F_this_0.F_root.F_elementData; var tmp1 int32 = t.F_this_0.F_offset + i
	if tmp1 >= int32(len(elementData.A)) {
		panic(Thrown(ConcurrentModificationException_New())) }
	t.F_cursor = i
	var tmp2 int32 = t.F_this_0.F_offset; var tmp3 int32; var tmp4 int32 = i; t.F_lastRet = tmp4; tmp3 = tmp4; return elementData.A[tmp2+tmp3]
}
func (t *ArrayList_SubList_1) ForEachRemaining_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var size int32 = t.F_this_0.F_size; var i int32 = t.F_cursor

	if i < size {
		var es *RefArray = t.F_this_0.F_root.F_elementData; var tmp1 int32 = t.F_this_0.F_offset + i
		if tmp1 >= int32(len(es.A)) {
			panic(Thrown(ConcurrentModificationException_New())) }
	L1: for { var tmp2 bool; var tmp3 bool; tmp3 = i < size; if tmp3 { tmp3 = t.F_this_0.F_root.F_modCount == t.F_expectedModCount }; tmp2 = tmp3; if tmp2 {
		action.Accept_O__V(ArrayList_ElementAt_O1_I__O(es, t.F_this_0.F_offset+i))
		i = i + 1
//line :690:1
		continue L1 }; break L1
	}

		t.F_cursor = i
		t.F_lastRet = i - 1
		t.CheckForComodification__V()
	} }
func (t *ArrayList_SubList_1) NextIndex__I() int32 { return t.F_cursor }

func (t *ArrayList_SubList_1) PreviousIndex__I() int32 {
	return t.F_cursor - 1
}
func (t *ArrayList_SubList_1) Remove__V() {
	if t.F_lastRet < 0 { panic(Thrown(IllegalStateException_New())) }
	t.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		NN(t.F_this_0).Remove_I__O(t.F_lastRet)
		t.F_cursor = t.F_lastRet
		t.F_lastRet = -1
		t.F_expectedModCount = t.F_this_0.F_modCount; return nil }()
//line :705:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex




		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :705:1
			panic(tmp1)
		}
	}
}



func (t *ArrayList_SubList_1) Set_O__V(e any) {
	if t.F_lastRet < 0 { panic(Thrown(IllegalStateException_New())) }
	t.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		NN(t.F_this_0.F_root).Set_I_O__O(t.F_this_0.F_offset+t.F_lastRet, e); return nil }()
//line :715:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex

		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :715:1
			panic(tmp1)
		}
	}
}
func (t *ArrayList_SubList_1) Add_O__V(e any) {
	t.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var i int32 = t.F_cursor
			NN(t.F_this_0).Add_I_O__V(i, e)
			t.F_cursor = i + 1
			t.F_lastRet = -1
			t.F_expectedModCount = t.F_this_0.F_modCount }; return nil }()
//line :721:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex





		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :721:1
			panic(tmp1)
		}
	}
}




func (t *ArrayList_SubList_1) CheckForComodification__V() {
	if t.F_this_0.F_root.F_modCount == t.F_expectedModCount { } else {
		panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *ArrayList_SubList) SubList_I_I__List(fromIndex, toIndex int32) List {
	AbstractList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, t.F_size)
	return ArrayList_SubList_New_ArrayList_SubList_I_I(t, fromIndex, toIndex)
}
func (t *ArrayList_SubList) RangeCheckForAdd_I__V(index int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = index < 0; if !tmp2 { tmp2 = index > t.F_size }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IndexOutOfBoundsException_New_String(t.OutOfBoundsMsg_I__String(index))))
	} }
func (t *ArrayList_SubList) OutOfBoundsMsg_I__String(index int32) *String {
	return Concat(Lit_2595, StrOfInt(index), Lit_2596, StrOfInt(t.F_size))
}
func (t *ArrayList_SubList) CheckForComodification__V() {
	if t.F_root.F_modCount == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *ArrayList_SubList) UpdateSizeAndModCount_I__V(sizeChange int32) {
	var slist *ArrayList_SubList = t
L1: for {
	slist.F_size = slist.F_size + sizeChange
	slist.F_modCount = t.F_root.F_modCount
	slist = slist.F_parent
	if !(slist == nil) { continue L1 }
//line :749:1
	break L1
}
}



func (t *ArrayList_SubList) Spliterator__Spliterator() Spliterator {
	t.CheckForComodification__V()
	return ArrayList_SubList_2_New_ArrayList_SubList(t)
}





func (t *ArrayList_SubList_2) GetFence__I() int32 {
	var hi int32 = 0; var tmp1 int32
	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {
		t.F_expectedModCount = t.F_this_0.F_modCount
		var tmp2 int32; var tmp3 int32 = t.F_this_0.F_offset + t.F_this_0.F_size; t.F_fence = tmp3; tmp2 = tmp3; hi = tmp2 }
//line :765:1
	return hi
}




func (t *ArrayList_SubList_2) TrySplit__ArrayList_ArrayListSpliterator() *ArrayList_ArrayListSpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi) >> 1)


	if lo >= mid { return nil } else {
		var tmp1 *ArrayList = NN(t.F_this_0.F_root); var tmp2 int32; var tmp3 int32 = mid; t.F_index = tmp3; tmp2 = tmp3; return ArrayList_ArrayListSpliterator_New_ArrayList_I_I_I(tmp1, lo, tmp2, t.F_expectedModCount)
	} }
func (t *ArrayList_SubList_2) TryAdvance_Consumer__Z(action Consumer) bool {
	Objects_RequireNonNull_O__O(action)
	var hi int32 = t.GetFence__I(); var i int32 = t.F_index

	if i < hi {

		t.F_index = i + 1
		var e any = t.F_this_0.F_root.F_elementData.A[i]
		action.Accept_O__V(e)
		if t.F_this_0.F_root.F_modCount == t.F_expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
//line :785:1
		return true

	} else {
//line :782:1
		return false
	}
}







func (t *ArrayList_SubList_2) ForEachRemaining_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var i int32 = 0; var hi int32 = 0; var mc int32 = 0; var lst *ArrayList = t.F_this_0.F_root; var a *RefArray; var tmp1 *RefArray




	a = lst.F_elementData; tmp1 = a; if !(tmp1 == nil) {
		var tmp2 int32; hi = t.F_fence; tmp2 = hi; if tmp2 < 0 {
			mc = t.F_this_0.F_modCount; hi = t.F_this_0.F_offset + t.F_this_0.F_size } else {
				mc = t.F_expectedModCount }
		var tmp3 bool; var tmp4 bool; var tmp5 int32; i = t.F_index; tmp5 = i; tmp4 = tmp5 >= 0; if tmp4 { var tmp6 int32; var tmp7 int32 = hi; t.F_index = tmp7; tmp6 = tmp7; tmp4 = tmp6 <= int32(len(a.A)) }; tmp3 = tmp4; if tmp3 {
		L1: for { if i < hi {
			var e any = a.A[i]; action.Accept_O__V(e)
			i = i + 1
//line :804:1
			continue L1 }; break L1
		}

			if lst.F_modCount == mc { return } } }
	panic(Thrown(ConcurrentModificationException_New()))
}
func (t *ArrayList_SubList_2) EstimateSize__J() int64 { return int64(t.GetFence__I() - t.F_index) }


func (t *ArrayList_SubList_2) Characteristics__I() int32 {
	return 16464
}
func (t *ArrayList_SubList) Sort_Comparator__V(c Comparator) {
	t.CheckForComodification__V()
	NN(t.F_root).SortRange_Comparator_I_I__V(c, t.F_offset, t.F_offset+t.F_size)
	t.UpdateSizeAndModCount_I__V(0)
}
func (t *ArrayList) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var expectedModCount int32 = t.F_modCount; var es *RefArray = t.F_elementData; var size int32 = t.F_size
	var i int32 = 0

L1: for {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_modCount == expectedModCount; if tmp2 { tmp2 = i < size }; tmp1 = tmp2; if tmp1 {
		action.Accept_O__V(ArrayList_ElementAt_O1_I__O(es, i))
		i = i + 1; continue L1 }
//line :826:1
	break L1
}


	if t.F_modCount == expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *ArrayList) Spliterator__Spliterator() Spliterator {
	return ArrayList_ArrayListSpliterator_New_ArrayList_I_I_I(t, 0, -1, 0)
}









func ArrayList_ArrayListSpliterator_New_ArrayList_I_I_I(p0 *ArrayList, p1, p2, p3 int32) *ArrayList_ArrayListSpliterator { t := &ArrayList_ArrayListSpliterator{}; t.Ctor_ArrayList_I_I_I(p0, p1, p2, p3); return t }
//line :844:1
func (t *ArrayList_ArrayListSpliterator) Ctor_ArrayList_I_I_I(this_0 *ArrayList, origin, fence, expectedModCount int32) { NN(this_0); t.F_this_0 = this_0
	t.F_index = origin
	t.F_fence = fence
	t.F_expectedModCount = expectedModCount
}
func (t *ArrayList_ArrayListSpliterator) GetFence__I() int32 {
	var hi int32 = 0; var tmp1 int32
	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {
		t.F_expectedModCount = t.F_this_0.F_modCount
		var tmp2 int32; var tmp3 int32 = t.F_this_0.F_size; t.F_fence = tmp3; tmp2 = tmp3; hi = tmp2 }
//line :850:1
	return hi
}




func (t *ArrayList_ArrayListSpliterator) TrySplit__ArrayList_ArrayListSpliterator() *ArrayList_ArrayListSpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi) >> 1)


	if lo >= mid { return nil } else { var tmp1 int32; var tmp2 int32 = mid; t.F_index = tmp2; tmp1 = tmp2; return ArrayList_ArrayListSpliterator_New_ArrayList_I_I_I(t.F_this_0, lo, tmp1, t.F_expectedModCount)
	} }
func (t *ArrayList_ArrayListSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var hi int32 = t.GetFence__I(); var i int32 = t.F_index

	if i < hi {

		t.F_index = i + 1
		var e any = t.F_this_0.F_elementData.A[i]
		action.Accept_O__V(e)
		if t.F_this_0.F_modCount == t.F_expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
//line :869:1
		return true

	} else {
//line :866:1
		return false
	}
}







func (t *ArrayList_ArrayListSpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	var i int32 = 0; var hi int32 = 0; var mc int32 = 0; var a *RefArray



	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 *RefArray; a = t.F_this_0.F_elementData; tmp1 = a; if !(tmp1 == nil) {
		var tmp2 int32; hi = t.F_fence; tmp2 = hi; if tmp2 < 0 {
			mc = t.F_this_0.F_modCount; hi = t.F_this_0.F_size } else {
				mc = t.F_expectedModCount }
		var tmp3 bool; var tmp4 bool; var tmp5 int32; i = t.F_index; tmp5 = i; tmp4 = tmp5 >= 0; if tmp4 { var tmp6 int32; var tmp7 int32 = hi; t.F_index = tmp7; tmp6 = tmp7; tmp4 = tmp6 <= int32(len(a.A)) }; tmp3 = tmp4; if tmp3 {
		L1: for { if i < hi {
			var e any = a.A[i]; action.Accept_O__V(e)
			i = i + 1
//line :887:1
			continue L1 }; break L1
		}

			if t.F_this_0.F_modCount == mc { return } } }
	panic(Thrown(ConcurrentModificationException_New()))
}
func (t *ArrayList_ArrayListSpliterator) EstimateSize__J() int64 { return int64(t.GetFence__I() - t.F_index) }


func (t *ArrayList_ArrayListSpliterator) Characteristics__I() int32 {
	return 16464
}
func ArrayList_NBits_I__J1(n int32) *LongArray {
	return NewLongArray((n-1)>>6 + 1)
}
func ArrayList_SetBit_J1_I__V(bits *LongArray, i int32) {
	var i_2 int32 = i >> 6
	bits.A[i_2] = bits.A[i_2] | 1<<(i&63)
}
func ArrayList_IsClear_J1_I__Z(bits *LongArray, i int32) bool {
	return bits.A[i>>6]&(1<<(i&63)) == 0
}
func (t *ArrayList) RemoveIf_Predicate__Z(filter Predicate) bool {
	return t.RemoveIf_Predicate_I_I__Z(filter, 0, t.F_size)
}
func (t *ArrayList) RemoveIf_Predicate_I_I__Z(filter Predicate, i, end int32) bool {

	Objects_RequireNonNull_O__O(filter)
	var expectedModCount int32 = t.F_modCount; var es *RefArray = t.F_elementData

L1: for { var tmp1 bool; var tmp2 bool; tmp2 = i < end; if tmp2 { tmp2 = !filter.Test_O__Z(ArrayList_ElementAt_O1_I__O(es, i)) }; tmp1 = tmp2; if tmp1 {
	i = i + 1
//line :917:1
	continue L1 }; break L1
}
	if i < end {
		var beg int32 = i; var deathRow *LongArray = ArrayList_NBits_I__J1(end - beg)

		deathRow.A[0] = 1
		i = beg + 1
	L2: for { if i < end {
		if filter.Test_O__Z(ArrayList_ElementAt_O1_I__O(es, i)) {
			ArrayList_SetBit_J1_I__V(deathRow, i-beg) }
		i = i + 1
//line :924:1
		continue L2 }; break L2
	}


		if t.F_modCount == expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
		t.F_modCount = t.F_modCount + 1
		var w int32 = beg
		i = beg
	L3: for { if i < end {
		if ArrayList_IsClear_J1_I__Z(deathRow, i-beg) {
			es.Store(w, es.A[i])
			w = w + 1 }
		i = i + 1
//line :933:1
		continue L3 }; break L3
	}



		t.ShiftTailOverGap_O1_I_I__V(es, w, end)
//line :931:1
		return true





	} else {



		if t.F_modCount == expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
//line :940:1
		return false
	}
}


func (t *ArrayList) ReplaceAll_UnaryOperator__V(operator UnaryOperator) {
	t.ReplaceAllRange_UnaryOperator_I_I__V(operator, 0, t.F_size)
	t.F_modCount = t.F_modCount + 1
}
func (t *ArrayList) ReplaceAllRange_UnaryOperator_I_I__V(operator UnaryOperator, i, end int32) {

	Objects_RequireNonNull_O__O(operator)
	var expectedModCount int32 = t.F_modCount; var es *RefArray = t.F_elementData

L1: for { var tmp1 bool; var tmp2 bool; tmp2 = t.F_modCount == expectedModCount; if tmp2 { tmp2 = i < end }; tmp1 = tmp2; if tmp1 {
	es.Store(i, operator.Apply_O__O(ArrayList_ElementAt_O1_I__O(es, i)))
	i = i + 1
//line :954:1
	continue L1 }; break L1
}

	if t.F_modCount == expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *ArrayList) Sort_Comparator__V(c Comparator) {
	t.SortRange_Comparator_I_I__V(c, 0, t.F_size)
	t.F_modCount = t.F_modCount + 1
}
func (t *ArrayList) SortRange_Comparator_I_I__V(c Comparator, fromIndex, toIndex int32) {

	var expectedModCount int32 = t.F_modCount
	Arrays_Sort_O1_I_I_Comparator__V(t.F_elementData, fromIndex, toIndex, c)
	if t.F_modCount == expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *ArrayList) CheckInvariants__V() { panic(A2g_NotTranslated("java.util.ArrayList.checkInvariants()V")) }



type ArrayList struct{ AbstractList; F_elementData *RefArray; F_size int32 }

func (t *ArrayList) Is_RandomAccess() {}

func (t *ArrayList) Is_Cloneable() {}

func (t *ArrayList) Is_Serializable() {}

const ArrayList_serialVersionUID int64 = 8683452581122892189

const ArrayList_DEFAULT_CAPACITY int32 = 10

var ArrayList_EMPTY_ELEMENTDATA *RefArray

var ArrayList_DEFAULTCAPACITY_EMPTY_ELEMENTDATA *RefArray

var ArrayList_init ClassInit

func ArrayList_Init() { if !ArrayList_init.Done() { ArrayList_init.Run(ArrayList_clinit) } }

func ArrayList_clinit() { ArrayList_EMPTY_ELEMENTDATA = RefArrayOf(Object_class); ArrayList_DEFAULTCAPACITY_EMPTY_ELEMENTDATA = RefArrayOf(Object_class) }

func (t *ArrayList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *ArrayList) Reversed__List() List { return List_Reversed__List(t) }

func (t *ArrayList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ArrayList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ArrayList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ArrayList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ArrayList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ArrayList) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayList) GetClass__Class() *Class { return ArrayList_class }

func (t *ArrayList) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func ArrayList_InstanceOf(x any) bool { _, ok := x.(*ArrayList); return ok }

func ArrayList_Cast(x any) *ArrayList { if x == nil { return nil }; v, ok := x.(*ArrayList); if !ok { panic(ClassCast(x, ArrayList_class)) }; return v }



type ArrayList_ArrayListSpliterator struct{ Object; F_index, F_fence, F_expectedModCount int32; F_this_0 *ArrayList }

func (t *ArrayList_ArrayListSpliterator) Is_Spliterator() {}

func (t *ArrayList_ArrayListSpliterator) TrySplit__Spliterator() Spliterator { return Up_ArrayList_ArrayListSpliterator_Spliterator(t.TrySplit__ArrayList_ArrayListSpliterator()) }

func (t *ArrayList_ArrayListSpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *ArrayList_ArrayListSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *ArrayList_ArrayListSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *ArrayList_ArrayListSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayList_ArrayListSpliterator) GetClass__Class() *Class { return ArrayList_ArrayListSpliterator_class }

func (t *ArrayList_ArrayListSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *ArrayList_ArrayListSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayList_ArrayListSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayList_ArrayListSpliterator_InstanceOf(x any) bool { _, ok := x.(*ArrayList_ArrayListSpliterator); return ok }

func ArrayList_ArrayListSpliterator_Cast(x any) *ArrayList_ArrayListSpliterator { if x == nil { return nil }; v, ok := x.(*ArrayList_ArrayListSpliterator); if !ok { panic(ClassCast(x, ArrayList_ArrayListSpliterator_class)) }; return v }



type ArrayList_Itr struct{ Object; F_cursor, F_lastRet, F_expectedModCount int32; F_this_0 *ArrayList }

type ArrayList_Itr_I interface{ Object_I; Iterator; Self_ArrayList_Itr() *ArrayList_Itr; HasNext__Z() bool; Next__O() any; Remove__V(); ForEachRemaining_Consumer__V(p0 Consumer); CheckForComodification__V() }

func (t *ArrayList_Itr) Self_ArrayList_Itr() *ArrayList_Itr { return t }

func (t *ArrayList_Itr) Is_Iterator() {}

func (t *ArrayList_Itr) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *ArrayList_Itr) Next__O() any { return t.Impl_Next__O(t) }

func (t *ArrayList_Itr) Remove__V() { t.Impl_Remove__V(t) }

func (t *ArrayList_Itr) ForEachRemaining_Consumer__V(p0 Consumer) { t.Impl_ForEachRemaining_Consumer__V(t, p0) }

func (t *ArrayList_Itr) CheckForComodification__V() { t.Impl_CheckForComodification__V(t) }

func (t *ArrayList_Itr) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayList_Itr) GetClass__Class() *Class { return ArrayList_Itr_class }

func (t *ArrayList_Itr) ToString__String() *String { return Object_toString(t) }

func (t *ArrayList_Itr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayList_Itr) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayList_Itr_InstanceOf(x any) bool { _, ok := x.(ArrayList_Itr_I); return ok }

func ArrayList_Itr_Cast(x any) ArrayList_Itr_I { if x == nil { return nil }; v, ok := x.(ArrayList_Itr_I); if !ok { panic(ClassCast(x, ArrayList_Itr_class)) }; return v }



type ArrayList_ListItr struct{ ArrayList_Itr; F_this_0 *ArrayList }

func (t *ArrayList_ListItr) Is_ListIterator() {}

func (t *ArrayList_ListItr) Next__O() any { return t.Impl_Next__O(t) }

func (t *ArrayList_ListItr) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *ArrayList_ListItr) ForEachRemaining_Consumer__V(p0 Consumer) { t.Impl_ForEachRemaining_Consumer__V(t, p0) }

func (t *ArrayList_ListItr) CheckForComodification__V() { t.Impl_CheckForComodification__V(t) }

func (t *ArrayList_ListItr) Remove__V() { t.Impl_Remove__V(t) }

func (t *ArrayList_ListItr) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayList_ListItr) GetClass__Class() *Class { return ArrayList_ListItr_class }

func (t *ArrayList_ListItr) ToString__String() *String { return Object_toString(t) }

func (t *ArrayList_ListItr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayList_ListItr) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayList_ListItr_InstanceOf(x any) bool { _, ok := x.(*ArrayList_ListItr); return ok }

func ArrayList_ListItr_Cast(x any) *ArrayList_ListItr { if x == nil { return nil }; v, ok := x.(*ArrayList_ListItr); if !ok { panic(ClassCast(x, ArrayList_ListItr_class)) }; return v }



type ArrayList_SubList struct{ AbstractList; F_root *ArrayList; F_parent *ArrayList_SubList; F_offset, F_size int32 }

func (t *ArrayList_SubList) Is_RandomAccess() {}

func (t *ArrayList_SubList) Clear__V() { t.Impl_Clear__V(t) }

func (t *ArrayList_SubList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *ArrayList_SubList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *ArrayList_SubList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *ArrayList_SubList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *ArrayList_SubList) Reversed__List() List { return List_Reversed__List(t) }

func (t *ArrayList_SubList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ArrayList_SubList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ArrayList_SubList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ArrayList_SubList) GetLast__O() any { return List_GetLast__O(t) }

func (t *ArrayList_SubList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *ArrayList_SubList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ArrayList_SubList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ArrayList_SubList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *ArrayList_SubList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ArrayList_SubList) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ArrayList_SubList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *ArrayList_SubList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ArrayList_SubList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ArrayList_SubList) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayList_SubList) GetClass__Class() *Class { return ArrayList_SubList_class }

func (t *ArrayList_SubList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayList_SubList) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayList_SubList_InstanceOf(x any) bool { _, ok := x.(*ArrayList_SubList); return ok }

func ArrayList_SubList_Cast(x any) *ArrayList_SubList { if x == nil { return nil }; v, ok := x.(*ArrayList_SubList); if !ok { panic(ClassCast(x, ArrayList_SubList_class)) }; return v }



type ArrayList_SubList_1 struct{ Object; F_cursor, F_lastRet, F_expectedModCount int32; F_this_0 *ArrayList_SubList; F_val_index int32 }

func (t *ArrayList_SubList_1) Is_ListIterator() {}

func (t *ArrayList_SubList_1) Is_Iterator() {}

func ArrayList_SubList_1_New_ArrayList_SubList_I(p0 *ArrayList_SubList, p1 int32) *ArrayList_SubList_1 { t := &ArrayList_SubList_1{}; t.Ctor_ArrayList_SubList_I(p0, p1); return t }

func (t *ArrayList_SubList_1) Ctor_ArrayList_SubList_I(this_0 *ArrayList_SubList, val_index int32) { t.F_val_index = val_index; NN(this_0); t.F_this_0 = this_0; t.F_cursor = t.F_val_index; t.F_lastRet = -1; t.F_expectedModCount = this_0.F_modCount }

func (t *ArrayList_SubList_1) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayList_SubList_1) GetClass__Class() *Class { return ArrayList_SubList_1_class }

func (t *ArrayList_SubList_1) ToString__String() *String { return Object_toString(t) }

func (t *ArrayList_SubList_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayList_SubList_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayList_SubList_1_InstanceOf(x any) bool { _, ok := x.(*ArrayList_SubList_1); return ok }

func ArrayList_SubList_1_Cast(x any) *ArrayList_SubList_1 { if x == nil { return nil }; v, ok := x.(*ArrayList_SubList_1); if !ok { panic(ClassCast(x, ArrayList_SubList_1_class)) }; return v }



type ArrayList_SubList_2 struct{ Object; F_index, F_fence, F_expectedModCount int32; F_this_0 *ArrayList_SubList }

func (t *ArrayList_SubList_2) Is_Spliterator() {}

func ArrayList_SubList_2_New_ArrayList_SubList(p0 *ArrayList_SubList) *ArrayList_SubList_2 { t := &ArrayList_SubList_2{}; t.Ctor_ArrayList_SubList(p0); return t }

func (t *ArrayList_SubList_2) Ctor_ArrayList_SubList(this_0 *ArrayList_SubList) { NN(this_0); t.F_this_0 = this_0; t.F_index = this_0.F_offset; t.F_fence = -1 }

func (t *ArrayList_SubList_2) TrySplit__Spliterator() Spliterator { return Up_ArrayList_ArrayListSpliterator_Spliterator(t.TrySplit__ArrayList_ArrayListSpliterator()) }

func (t *ArrayList_SubList_2) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *ArrayList_SubList_2) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *ArrayList_SubList_2) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *ArrayList_SubList_2) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayList_SubList_2) GetClass__Class() *Class { return ArrayList_SubList_2_class }

func (t *ArrayList_SubList_2) ToString__String() *String { return Object_toString(t) }

func (t *ArrayList_SubList_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayList_SubList_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayList_SubList_2_InstanceOf(x any) bool { _, ok := x.(*ArrayList_SubList_2); return ok }

func ArrayList_SubList_2_Cast(x any) *ArrayList_SubList_2 { if x == nil { return nil }; v, ok := x.(*ArrayList_SubList_2); if !ok { panic(ClassCast(x, ArrayList_SubList_2_class)) }; return v }
