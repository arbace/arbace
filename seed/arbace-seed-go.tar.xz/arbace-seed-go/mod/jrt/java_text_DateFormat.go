//line java_text_DateFormat.ae:1
package jrt





















































func (t *DateFormat) Impl_Format_O_StringBuffer_FieldPosition__StringBuffer(this DateFormat_I, obj any, toAppendTo *StringBuffer, fieldPosition FieldPosition_I) *StringBuffer {

	if Date_InstanceOf(obj) {
		return this.Format_Date_StringBuffer_FieldPosition__StringBuffer(Date_Cast(obj), toAppendTo, fieldPosition) } else {
//line :57:1
			if Number_InstanceOf(obj) {


				return this.Format_Date_StringBuffer_FieldPosition__StringBuffer(Date_New_J(Number_Cast(obj).LongValue__J()), toAppendTo, fieldPosition) } else {
					panic(Thrown(IllegalArgumentException_New_String(Lit_1774)))
				} } }
func (t *DateFormat) Impl_Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(this DateFormat_I, obj any, toAppendTo Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	if Date_InstanceOf(obj) {
		return this.Format_Date_Format_StringBuf_FieldPosition__Format_StringBuf(Date_Cast(obj), toAppendTo, fieldPosition) } else {
//line :65:1
			if Number_InstanceOf(obj) {


				return this.Format_Date_Format_StringBuf_FieldPosition__Format_StringBuf(Date_New_J(Number_Cast(obj).LongValue__J()), toAppendTo, fieldPosition) } else {
					panic(Thrown(IllegalArgumentException_New_String(Lit_1774)))
				}
		}
}

func (t *DateFormat) Impl_Format_Date_Format_StringBuf_FieldPosition__Format_StringBuf(this DateFormat_I, p0 Date_I, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf { panic(A2g_NotTranslated("java.text.DateFormat.format(Ljava/util/Date;Ljava/text/Format$StringBuf;Ljava/text/FieldPosition;)Ljava/text/Format$StringBuf;")) }



func (t *DateFormat) Impl_Format_Date__String(this DateFormat_I, date Date_I) *String {
	var tmp1 bool; var tmp2 bool; tmp2 = Lit_1775.Equals_O__Z(NN(this.GetClass__Class()).GetPackageName__String().Ref()); if tmp2 {
		tmp2 = Lit_1775.Equals_O__Z(NN(t.F_numberFormat.GetClass__Class()).GetPackageName__String().Ref()) }
//line :79:1
	tmp1 = tmp2; if tmp1 {

		var tmp3 Format_StringBuf = StringBufFactory_Of__Format_StringBuf(); var tmp4 FieldPosition_I; DontCareFieldPosition_Init(); tmp4 = DontCareFieldPosition_INSTANCE; return this.Format_Date_Format_StringBuf_FieldPosition__Format_StringBuf(date, tmp3, tmp4).ToString__String() } else {
			var tmp5 *StringBuffer = StringBuffer_New(); var tmp6 FieldPosition_I; DontCareFieldPosition_Init(); tmp6 = DontCareFieldPosition_INSTANCE; return NN(this.Format_Date_StringBuffer_FieldPosition__StringBuffer(date, tmp5, tmp6)).ToString__String()
		} }
func (t *DateFormat) Impl_Parse_String__Date(this DateFormat_I, source *String) Date_I {
	var pos *ParsePosition = ParsePosition_New_I(0); var result Date_I = this.Parse_String_ParsePosition__Date(source, pos)

	if pos.F_index == 0 {
		panic(Thrown(ParseException_New_String_I(Concat(Lit_1776, source, Lit_1142), pos.F_errorIndex))) }
//line :85:1
	return result
}






func (t *DateFormat) Impl_ParseObject_String_ParsePosition__O(this DateFormat_I, source *String, pos *ParsePosition) any {
	return this.Parse_String_ParsePosition__Date(source, pos)
}




















func DateFormat_Style_New_String_I_I(p0 *String, p1, p2 int32) *DateFormat_Style { DateFormat_Style_Init(); t := &DateFormat_Style{}; t.Ctor_String_I_I(p0, p1, p2); return t }
//line :116:1
func (t *DateFormat_Style) Ctor_String_I_I(enumName *String, enumOrdinal, value int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal); t.F_value = value }

func (t *DateFormat_Style) GetValue__I() int32 { return t.F_value }

func DateFormat_GetTimeInstance__DateFormat() DateFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DateFormat_Get_I_I_I_Locale__DateFormat(2, 0, 1, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormat_GetTimeInstance_I__DateFormat(style int32) DateFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DateFormat_Get_I_I_I_Locale__DateFormat(style, 0, 1, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormat_GetTimeInstance_I_Locale__DateFormat(style int32, aLocale *Locale) DateFormat_I {
	return DateFormat_Get_I_I_I_Locale__DateFormat(style, 0, 1, aLocale)
}
func DateFormat_GetDateInstance__DateFormat() DateFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DateFormat_Get_I_I_I_Locale__DateFormat(0, 2, 2, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormat_GetDateInstance_I__DateFormat(style int32) DateFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DateFormat_Get_I_I_I_Locale__DateFormat(0, style, 2, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormat_GetDateInstance_I_Locale__DateFormat(style int32, aLocale *Locale) DateFormat_I {
	return DateFormat_Get_I_I_I_Locale__DateFormat(0, style, 2, aLocale)
}
func DateFormat_GetDateTimeInstance__DateFormat() DateFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DateFormat_Get_I_I_I_Locale__DateFormat(2, 2, 3, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormat_GetDateTimeInstance_I_I__DateFormat(dateStyle, timeStyle int32) DateFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DateFormat_Get_I_I_I_Locale__DateFormat(timeStyle, dateStyle, 3, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormat_GetDateTimeInstance_I_I_Locale__DateFormat(dateStyle, timeStyle int32, aLocale *Locale) DateFormat_I {

	return DateFormat_Get_I_I_I_Locale__DateFormat(timeStyle, dateStyle, 3, aLocale)
}
func DateFormat_GetInstance__DateFormat() DateFormat_I {
	return DateFormat_GetDateTimeInstance_I_I__DateFormat(3, 3)
}
func DateFormat_GetAvailableLocales__Locale1() *RefArray {
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(DateFormatProvider_class); return NN(pool).GetAvailableLocales__Locale1()
}
func (t *DateFormat) Impl_SetCalendar_Calendar__V(this DateFormat_I, newCalendar Calendar_I) {
	t.F_calendar = newCalendar
}
func (t *DateFormat) Impl_GetCalendar__Calendar(this DateFormat_I) Calendar_I { return t.F_calendar }

func (t *DateFormat) Impl_SetNumberFormat_NumberFormat__V(this DateFormat_I, newNumberFormat NumberFormat_I) {
	t.F_numberFormat = newNumberFormat
}
func (t *DateFormat) Impl_GetNumberFormat__NumberFormat(this DateFormat_I) NumberFormat_I { return t.F_numberFormat }

func (t *DateFormat) Impl_SetTimeZone_TimeZone__V(this DateFormat_I, zone TimeZone_I) {
	t.F_calendar.SetTimeZone_TimeZone__V(zone)
}
func (t *DateFormat) Impl_GetTimeZone__TimeZone(this DateFormat_I) TimeZone_I { return t.F_calendar.GetTimeZone__TimeZone() }

func (t *DateFormat) Impl_SetLenient_Z__V(this DateFormat_I, lenient bool) {
	t.F_calendar.SetLenient_Z__V(lenient)
}
func (t *DateFormat) Impl_IsLenient__Z(this DateFormat_I) bool { return t.F_calendar.IsLenient__Z() }

func (t *DateFormat) Impl_HashCode__I(this DateFormat_I) int32 { return t.F_numberFormat.HashCode__I() }

func (t *DateFormat) Impl_Equals_O__Z(this DateFormat_I, obj any) bool {
	if any(this) == any(obj) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = obj == nil; if !tmp2 { tmp2 = !(this.GetClass__Class() == GetClass(obj)) }; tmp1 = tmp2
//line :177:1
		if tmp1 { return false } else {



			var other DateFormat_I = DateFormat_Cast(obj); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool
			tmp6 = t.F_calendar.GetFirstDayOfWeek__I() == other.Self_DateFormat().F_calendar.GetFirstDayOfWeek__I(); if tmp6 {

				tmp6 = t.F_calendar.GetMinimalDaysInFirstWeek__I() == other.Self_DateFormat().F_calendar.GetMinimalDaysInFirstWeek__I() }
//line :182:1
			tmp5 = tmp6; if tmp5 {



				tmp5 = t.F_calendar.IsLenient__Z() == other.Self_DateFormat().F_calendar.IsLenient__Z() }
//line :182:1
			tmp4 = tmp5; if tmp4 {




				tmp4 = t.F_calendar.GetTimeZone__TimeZone().Equals_O__Z(other.Self_DateFormat().F_calendar.GetTimeZone__TimeZone()) }
//line :182:1
			tmp3 = tmp4; if tmp3 {





				var tmp7 NumberFormat_I = t.F_numberFormat; tmp3 = tmp7.Equals_O__Z(other.Self_DateFormat().F_numberFormat) }
//line :182:1
			return tmp3
		}
	}
}




func (t *DateFormat) Impl_Clone__O(this DateFormat_I) any {
	var other DateFormat_I = DateFormat_Cast(t.Format.Impl_Clone__O(this))
	other.Self_DateFormat().F_calendar = Calendar_Cast(t.F_calendar.Clone__O())
	other.Self_DateFormat().F_numberFormat = NumberFormat_Cast(t.F_numberFormat.Clone__O())
//line :191:1
	return other
}



func DateFormat_Get_I_I_I_Locale__DateFormat(timeStyle, dateStyle, flags int32, loc *Locale) DateFormat_I {

	if !(flags&1 == 0) {
		var tmp1 bool; var tmp2 bool; tmp2 = timeStyle < 0; if !tmp2 { tmp2 = timeStyle > 3 }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1777, StrOfInt(timeStyle))))) } } else {
				timeStyle = -1 }
	if !(flags&2 == 0) {
		var tmp3 bool; var tmp4 bool; tmp4 = dateStyle < 0; if !tmp4 { tmp4 = dateStyle > 3 }; tmp3 = tmp4; if tmp3 {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1778, StrOfInt(dateStyle))))) } } else {
				dateStyle = -1 }
	var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(DateFormatProvider_class, loc); var dateFormat DateFormat_I = DateFormat_Get_LocaleProviderAdapter_I_I_Locale__DateFormat(adapter, timeStyle, dateStyle, loc)

	if dateFormat == nil {
		dateFormat = DateFormat_Get_LocaleProviderAdapter_I_I_Locale__DateFormat(LocaleProviderAdapter_ForJRE__LocaleProviderAdapter(), timeStyle, dateStyle, loc) }
//line :206:1
	return dateFormat
}




func DateFormat_Get_LocaleProviderAdapter_I_I_Locale__DateFormat(adapter LocaleProviderAdapter_I, timeStyle, dateStyle int32, loc *Locale) DateFormat_I {

	var provider DateFormatProvider_I = adapter.GetDateFormatProvider__DateFormatProvider(); var dateFormat DateFormat_I

	if timeStyle == -1 {
		dateFormat = provider.GetDateInstance_I_Locale__DateFormat(dateStyle, loc) } else {
//line :216:1
			if dateStyle == -1 {

				dateFormat = provider.GetTimeInstance_I_Locale__DateFormat(timeStyle, loc) } else {
					dateFormat = provider.GetDateTimeInstance_I_I_Locale__DateFormat(dateStyle, timeStyle, loc) } }
//line :214:1
	return dateFormat
}






func (t *DateFormat) Ctor(this DateFormat_I) { t.Format.Ctor(this) }













func DateFormat_Field_OfCalendarField_I__DateFormat_Field(calendarField int32) *DateFormat_Field { DateFormat_Field_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = calendarField < 0; if !tmp2 { tmp2 = calendarField >= int32(len(DateFormat_Field_calendarToFieldMapping.A)) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1797, StrOfInt(calendarField))))) }
	return As[*DateFormat_Field](DateFormat_Field_calendarToFieldMapping.A[calendarField])
}
func DateFormat_Field_New_String_I(p0 *String, p1 int32) *DateFormat_Field { DateFormat_Field_Init(); t := &DateFormat_Field{}; t.Ctor_String_I(p0, p1); return t }
//line :241:1
func (t *DateFormat_Field) Ctor_String_I(name *String, calendarField int32) { t.Format_Field.Ctor_String(t, name)

	t.F_calendarField = calendarField
	if t.GetClass__Class() == DateFormat_Field_class {
		DateFormat_Field_instanceMap.Put_O_O__O(name.Ref(), t)
		if calendarField >= 0 { DateFormat_Field_calendarToFieldMapping.Store(calendarField, t)
		} } }
func (t *DateFormat_Field) GetCalendarField__I() int32 { return t.F_calendarField }

func (t *DateFormat_Field) ReadResolve__O() any { panic(A2g_NotTranslated("java.text.DateFormat$Field.readResolve()Ljava/lang/Object;")) }



type DateFormat struct{ Format; F_calendar Calendar_I; F_numberFormat NumberFormat_I }

type DateFormat_I interface{ Format_I; Serializable; Cloneable; Self_DateFormat() *DateFormat; Format_O_StringBuffer_FieldPosition__StringBuffer(p0 any, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer; Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(p0 any, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf; Format_Date_StringBuffer_FieldPosition__StringBuffer(p0 Date_I, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer; Format_Date_Format_StringBuf_FieldPosition__Format_StringBuf(p0 Date_I, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf; Format_Date__String(p0 Date_I) *String; Parse_String__Date(p0 *String) Date_I; Parse_String_ParsePosition__Date(p0 *String, p1 *ParsePosition) Date_I; ParseObject_String_ParsePosition__O(p0 *String, p1 *ParsePosition) any; SetCalendar_Calendar__V(p0 Calendar_I); GetCalendar__Calendar() Calendar_I; SetNumberFormat_NumberFormat__V(p0 NumberFormat_I); GetNumberFormat__NumberFormat() NumberFormat_I; SetTimeZone_TimeZone__V(p0 TimeZone_I); GetTimeZone__TimeZone() TimeZone_I; SetLenient_Z__V(p0 bool); IsLenient__Z() bool }

func (t *DateFormat) Self_DateFormat() *DateFormat { return t }

const DateFormat_ERA_FIELD int32 = 0

const DateFormat_YEAR_FIELD int32 = 1

const DateFormat_MONTH_FIELD int32 = 2

const DateFormat_DATE_FIELD int32 = 3

const DateFormat_HOUR_OF_DAY1_FIELD int32 = 4

const DateFormat_HOUR_OF_DAY0_FIELD int32 = 5

const DateFormat_MINUTE_FIELD int32 = 6

const DateFormat_SECOND_FIELD int32 = 7

const DateFormat_MILLISECOND_FIELD int32 = 8

const DateFormat_DAY_OF_WEEK_FIELD int32 = 9

const DateFormat_DAY_OF_YEAR_FIELD int32 = 10

const DateFormat_DAY_OF_WEEK_IN_MONTH_FIELD int32 = 11

const DateFormat_WEEK_OF_YEAR_FIELD int32 = 12

const DateFormat_WEEK_OF_MONTH_FIELD int32 = 13

const DateFormat_AM_PM_FIELD int32 = 14

const DateFormat_HOUR1_FIELD int32 = 15

const DateFormat_HOUR0_FIELD int32 = 16

const DateFormat_TIMEZONE_FIELD int32 = 17

const DateFormat_serialVersionUID int64 = 7218322306649953788

const DateFormat_FULL int32 = 0

const DateFormat_LONG int32 = 1

const DateFormat_MEDIUM int32 = 2

const DateFormat_SHORT int32 = 3

const DateFormat_DEFAULT int32 = 2

func DateFormat_InstanceOf(x any) bool { _, ok := x.(DateFormat_I); return ok }

func DateFormat_Cast(x any) DateFormat_I { if x == nil { return nil }; v, ok := x.(DateFormat_I); if !ok { panic(ClassCast(x, DateFormat_class)) }; return v }



type DateFormat_Field struct{ Format_Field; F_calendarField int32 }

const DateFormat_Field_serialVersionUID int64 = 7441350119349544720

var DateFormat_Field_instanceMap Map

var DateFormat_Field_calendarToFieldMapping *RefArray

var DateFormat_Field_ERA *DateFormat_Field

var DateFormat_Field_YEAR *DateFormat_Field

var DateFormat_Field_MONTH *DateFormat_Field

var DateFormat_Field_DAY_OF_MONTH *DateFormat_Field

var DateFormat_Field_HOUR_OF_DAY1 *DateFormat_Field

var DateFormat_Field_HOUR_OF_DAY0 *DateFormat_Field

var DateFormat_Field_MINUTE *DateFormat_Field

var DateFormat_Field_SECOND *DateFormat_Field

var DateFormat_Field_MILLISECOND *DateFormat_Field

var DateFormat_Field_DAY_OF_WEEK *DateFormat_Field

var DateFormat_Field_DAY_OF_YEAR *DateFormat_Field

var DateFormat_Field_DAY_OF_WEEK_IN_MONTH *DateFormat_Field

var DateFormat_Field_WEEK_OF_YEAR *DateFormat_Field

var DateFormat_Field_WEEK_OF_MONTH *DateFormat_Field

var DateFormat_Field_AM_PM *DateFormat_Field

var DateFormat_Field_HOUR1 *DateFormat_Field

var DateFormat_Field_HOUR0 *DateFormat_Field

var DateFormat_Field_TIME_ZONE *DateFormat_Field

var DateFormat_Field_init ClassInit

func DateFormat_Field_Init() { if !DateFormat_Field_init.Done() { DateFormat_Field_init.Run(DateFormat_Field_clinit) } }

func DateFormat_Field_clinit() { Format_Field_Init(); DateFormat_Field_instanceMap = HashMap_New_I(18); DateFormat_Field_calendarToFieldMapping = NewRefArray(DateFormat_Field_class, 17); DateFormat_Field_ERA = DateFormat_Field_New_String_I(Lit_1779, 0); DateFormat_Field_YEAR = DateFormat_Field_New_String_I(Lit_1780, 1); DateFormat_Field_MONTH = DateFormat_Field_New_String_I(Lit_1781, 2); DateFormat_Field_DAY_OF_MONTH = DateFormat_Field_New_String_I(Lit_1782, 5); DateFormat_Field_HOUR_OF_DAY1 = DateFormat_Field_New_String_I(Lit_1783, -1); DateFormat_Field_HOUR_OF_DAY0 = DateFormat_Field_New_String_I(Lit_1784, 11); DateFormat_Field_MINUTE = DateFormat_Field_New_String_I(Lit_1785, 12); DateFormat_Field_SECOND = DateFormat_Field_New_String_I(Lit_1786, 13); DateFormat_Field_MILLISECOND = DateFormat_Field_New_String_I(Lit_1787, 14); DateFormat_Field_DAY_OF_WEEK = DateFormat_Field_New_String_I(Lit_1788, 7); DateFormat_Field_DAY_OF_YEAR = DateFormat_Field_New_String_I(Lit_1789, 6); DateFormat_Field_DAY_OF_WEEK_IN_MONTH = DateFormat_Field_New_String_I(Lit_1790, 8); DateFormat_Field_WEEK_OF_YEAR = DateFormat_Field_New_String_I(Lit_1791, 3); DateFormat_Field_WEEK_OF_MONTH = DateFormat_Field_New_String_I(Lit_1792, 4); DateFormat_Field_AM_PM = DateFormat_Field_New_String_I(Lit_1793, 9); DateFormat_Field_HOUR1 = DateFormat_Field_New_String_I(Lit_1794, -1); DateFormat_Field_HOUR0 = DateFormat_Field_New_String_I(Lit_1795, 10); DateFormat_Field_TIME_ZONE = DateFormat_Field_New_String_I(Lit_1796, -1) }

func (t *DateFormat_Field) GetName__String() *String { return t.Impl_GetName__String(t) }

func (t *DateFormat_Field) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *DateFormat_Field) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *DateFormat_Field) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DateFormat_Field) Ref() any { if t == nil { return nil }; return t }

func (t *DateFormat_Field) GetClass__Class() *Class { return DateFormat_Field_class }

func (t *DateFormat_Field) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateFormat_Field) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateFormat_Field_InstanceOf(x any) bool { _, ok := x.(*DateFormat_Field); return ok }

func DateFormat_Field_Cast(x any) *DateFormat_Field { if x == nil { return nil }; v, ok := x.(*DateFormat_Field); if !ok { panic(ClassCast(x, DateFormat_Field_class)) }; return v }



type DateFormat_Style struct{ Enum; F_value int32 }

func (t *DateFormat_Style) Is_Constable() {}

var DateFormat_Style_FULL *DateFormat_Style

var DateFormat_Style_LONG *DateFormat_Style

var DateFormat_Style_MEDIUM *DateFormat_Style

var DateFormat_Style_SHORT *DateFormat_Style

var DateFormat_Style_DEFAULT *DateFormat_Style

var DateFormat_Style__VALUES *RefArray

var DateFormat_Style_init ClassInit

func DateFormat_Style_Init() { if !DateFormat_Style_init.Done() { DateFormat_Style_init.Run(DateFormat_Style_clinit) } }

func DateFormat_Style_clinit() { DateFormat_Style_FULL = DateFormat_Style_New_String_I_I(Lit_1798, 0, 0); DateFormat_Style_LONG = DateFormat_Style_New_String_I_I(Lit_1799, 1, 1); DateFormat_Style_MEDIUM = DateFormat_Style_New_String_I_I(Lit_1800, 2, 2); DateFormat_Style_SHORT = DateFormat_Style_New_String_I_I(Lit_1801, 3, 3); DateFormat_Style_DEFAULT = DateFormat_Style_New_String_I_I(Lit_1802, 4, 2); DateFormat_Style__VALUES = DateFormat_Style_X_values__DateFormat_Style1() }

func DateFormat_Style_Values__DateFormat_Style1() *RefArray { DateFormat_Style_Init(); return DateFormat_Style__VALUES.Copy() }

func DateFormat_Style_ValueOf_String__DateFormat_Style(p0 *String) *DateFormat_Style { DateFormat_Style_Init(); return DateFormat_Style_Cast(Enum_ValueOf_Class_String__Enum(DateFormat_Style_class, p0)) }

func DateFormat_Style_X_values__DateFormat_Style1() *RefArray { DateFormat_Style_Init(); return RefArrayOf(DateFormat_Style_class, DateFormat_Style_FULL, DateFormat_Style_LONG, DateFormat_Style_MEDIUM, DateFormat_Style_SHORT, DateFormat_Style_DEFAULT) }

func (t *DateFormat_Style) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *DateFormat_Style) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *DateFormat_Style) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *DateFormat_Style) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.text.DateFormat$Style.describeConstable()Ljava/util/Optional;")) }

func (t *DateFormat_Style) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *DateFormat_Style) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DateFormat_Style) Ref() any { if t == nil { return nil }; return t }

func (t *DateFormat_Style) GetClass__Class() *Class { return DateFormat_Style_class }

func (t *DateFormat_Style) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateFormat_Style_InstanceOf(x any) bool { _, ok := x.(*DateFormat_Style); return ok }

func DateFormat_Style_Cast(x any) *DateFormat_Style { if x == nil { return nil }; v, ok := x.(*DateFormat_Style); if !ok { panic(ClassCast(x, DateFormat_Style_class)) }; return v }
