//line java_io_OutputStream.ae:1
package jrt

import "sync/atomic"






func (t *OutputStream) Ctor(this OutputStream_I) {}

func OutputStream_NullOutputStream__OutputStream() OutputStream_I {
	return OutputStream_1_New()
}

func (t *OutputStream_1) EnsureOpen__V() {
	if t.F_closed.Load() { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *OutputStream_1) Write_I__V(b int32) {
	t.EnsureOpen__V()
}
func (t *OutputStream_1) Write_B1_I_I__V(b *ByteArray, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	t.EnsureOpen__V()
}
func (t *OutputStream_1) Close__V() { t.F_closed.Store(true) }



func (t *OutputStream) Impl_Write_B1__V(this OutputStream_I, b *ByteArray) {
	this.Write_B1_I_I__V(b, 0, int32(len(b.A)))
}
func (t *OutputStream) Impl_Write_B1_I_I__V(this OutputStream_I, b *ByteArray, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	var i int32 = 0; L1: for {
		if i < len_ {
			this.Write_I__V(int32(b.A[off+i]))
			i = i + 1; continue L1 }
//line :35:1
		break L1
	}
}


func (t *OutputStream) Impl_Flush__V(this OutputStream_I) {}

func (t *OutputStream) Impl_Close__V(this OutputStream_I) {}



type OutputStream struct{ Object }

type OutputStream_I interface{ Object_I; Closeable; Flushable; AutoCloseable; Self_OutputStream() *OutputStream; Write_I__V(p0 int32); Write_B1__V(p0 *ByteArray); Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32); Flush__V(); Close__V() }

func (t *OutputStream) Self_OutputStream() *OutputStream { return t }

func (t *OutputStream) Is_Closeable() {}

func (t *OutputStream) Is_Flushable() {}

func (t *OutputStream) Is_AutoCloseable() {}

func OutputStream_InstanceOf(x any) bool { _, ok := x.(OutputStream_I); return ok }

func OutputStream_Cast(x any) OutputStream_I { if x == nil { return nil }; v, ok := x.(OutputStream_I); if !ok { panic(ClassCast(x, OutputStream_class)) }; return v }



type OutputStream_1 struct{ OutputStream; F_closed atomic.Bool }

func OutputStream_1_New() *OutputStream_1 { t := &OutputStream_1{}; t.Ctor(); return t }

func (t *OutputStream_1) Ctor() { t.OutputStream.Ctor(t) }

func (t *OutputStream_1) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *OutputStream_1) Flush__V() { t.Impl_Flush__V(t) }

func (t *OutputStream_1) Ref() any { if t == nil { return nil }; return t }

func (t *OutputStream_1) GetClass__Class() *Class { return OutputStream_1_class }

func (t *OutputStream_1) ToString__String() *String { return Object_toString(t) }

func (t *OutputStream_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OutputStream_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func OutputStream_1_InstanceOf(x any) bool { _, ok := x.(*OutputStream_1); return ok }

func OutputStream_1_Cast(x any) *OutputStream_1 { if x == nil { return nil }; v, ok := x.(*OutputStream_1); if !ok { panic(ClassCast(x, OutputStream_1_class)) }; return v }
