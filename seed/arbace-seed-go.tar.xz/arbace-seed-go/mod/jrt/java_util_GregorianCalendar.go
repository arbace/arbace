//line java_util_GregorianCalendar.ae:1
package jrt






































































































func GregorianCalendar_New() *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor(); return t }
//line :104:1
func (t *GregorianCalendar) Ctor() { var tmp1 TimeZone_I = TimeZone_GetDefaultRef__TimeZone(); var tmp2 *Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_FORMAT; t.Ctor_TimeZone_Locale(tmp1, Locale_GetDefault_Locale_Category__Locale(tmp2)) }


func GregorianCalendar_New_TimeZone(p0 TimeZone_I) *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor_TimeZone(p0); return t }
//line :107:1
func (t *GregorianCalendar) Ctor_TimeZone(zone TimeZone_I) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_TimeZone_Locale(zone, Locale_GetDefault_Locale_Category__Locale(tmp1)) }


func GregorianCalendar_New_Locale(p0 *Locale) *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor_Locale(p0); return t }
//line :110:1
func (t *GregorianCalendar) Ctor_Locale(aLocale *Locale) { t.Ctor_TimeZone_Locale(TimeZone_GetDefaultRef__TimeZone(), aLocale) }


func GregorianCalendar_New_TimeZone_Locale(p0 TimeZone_I, p1 *Locale) *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor_TimeZone_Locale(p0, p1); return t }
//line :113:1
func (t *GregorianCalendar) Ctor_TimeZone_Locale(zone TimeZone_I, aLocale *Locale) { t.Calendar.Ctor_TimeZone_Locale(t, zone, aLocale); t.F_gregorianCutover = -12219292800000

	t.SetCutover_J__V(-12219292800000)
	t.SetTimeInMillis_J__V(System_CurrentTimeMillis__J())
}
func GregorianCalendar_New_I_I_I(p0, p1, p2 int32) *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor_I_I_I(p0, p1, p2); return t }
//line :118:1
func (t *GregorianCalendar) Ctor_I_I_I(year, month, dayOfMonth int32) { t.Ctor_I_I_I_I_I_I_I(year, month, dayOfMonth, 0, 0, 0, 0) }


func GregorianCalendar_New_I_I_I_I_I(p0, p1, p2, p3, p4 int32) *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor_I_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :121:1
func (t *GregorianCalendar) Ctor_I_I_I_I_I(year, month, dayOfMonth, hourOfDay, minute int32) { t.Ctor_I_I_I_I_I_I_I(year, month, dayOfMonth, hourOfDay, minute, 0, 0) }


func GregorianCalendar_New_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5 int32) *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5); return t }
//line :124:1
func (t *GregorianCalendar) Ctor_I_I_I_I_I_I(year, month, dayOfMonth, hourOfDay, minute, second int32) { t.Ctor_I_I_I_I_I_I_I(year, month, dayOfMonth, hourOfDay, minute, second, 0) }



func GregorianCalendar_New_I_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6 int32) *GregorianCalendar { GregorianCalendar_Init(); t := &GregorianCalendar{}; t.Ctor_I_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6); return t }
//line :128:1
func (t *GregorianCalendar) Ctor_I_I_I_I_I_I_I(year, month, dayOfMonth, hourOfDay, minute, second, millis int32) { var tmp1 TimeZone_I = TimeZone_GetDefaultRef__TimeZone(); var tmp2 *Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_FORMAT; t.Calendar.Ctor_TimeZone_Locale(t, tmp1, Locale_GetDefault_Locale_Category__Locale(tmp2)); t.F_gregorianCutover = -12219292800000;


	t.SetCutover_J__V(-12219292800000);
	t.Set_I_I__V(1, year);
	t.Set_I_I__V(2, month);
	t.Set_I_I__V(5, dayOfMonth); var tmp3 bool; var tmp4 bool; tmp4 =
	hourOfDay >= 12; if tmp4 { tmp4 = hourOfDay <= 23 }; tmp3 = tmp4; if tmp3 {

		t.InternalSet_I_I__V(9, 1)
		t.InternalSet_I_I__V(10, hourOfDay-12) } else {
			t.InternalSet_I_I__V(10, hourOfDay) };
	t.Set_I_I__V(11, hourOfDay);
	t.Set_I_I__V(12, minute);
	t.Set_I_I__V(13, second);
	t.InternalSet_I_I__V(14, millis) }

func (t *GregorianCalendar) SetCutover_J__V(cutover int64) {
	t.F_gregorianCutover = cutover
	t.F_gregorianCutoverDay = Math_FloorDiv_J_J__J(cutover, 86400000)
	t.F_gregorianCutoverYear = int32(GregorianCalendar_GregorianYmd_J__J1(t.F_gregorianCutoverDay).A[0])

	t.F_gregorianCutoverYearJulian = int32(GregorianCalendar_JulianYmd_J__J1(t.F_gregorianCutoverDay - 1).A[0])
}


func (t *GregorianCalendar) SetGregorianChange_Date__V(date Date_I) {
	var cutoverTime int64 = date.GetTime__J()
	if cutoverTime == t.F_gregorianCutover { } else {
		t.Complete__V()
		t.SetCutover_J__V(cutoverTime)
		t.SetTimeInMillis_J__V(t.F_time)
	} }
func (t *GregorianCalendar) GetGregorianChange__Date() Date_I {
	return Date_New_J(t.F_gregorianCutover)
}
func GregorianCalendar_GregorianDays_J_J_J__J(y, m, d int64) int64 { GregorianCalendar_Init()
	if m <= 2 { y = y - 1 }
	var era int64 = Math_FloorDiv_J_I__J(y, 400); var yoe int64 = y - era*400; var mp int64 = int64(Math_FloorMod_J_I__I(m+9, 12)); var doy int64 = (153*mp+2)/5 + d - 1; var tmp1 int64 = yoe*365 + yoe/4; var doe int64 = tmp1 - yoe/100 + doy










	return era*146097 + doe - 719468
}
func GregorianCalendar_JulianDays_J_J_J__J(y, m, d int64) int64 { GregorianCalendar_Init()
	var a int64 = Math_FloorDiv_J_I__J(14-m, 12); var yy int64 = y + 4800 - a; var mm int64 = m + 12*a - 3


	return d + Math_FloorDiv_J_I__J(153*mm+2, 5) + 365*yy + Math_FloorDiv_J_I__J(yy, 4) - 32083 - 2440588
}











func GregorianCalendar_GregorianYmd_J__J1(days int64) *LongArray { GregorianCalendar_Init()
	var z int64 = days + 719468; var era int64 = Math_FloorDiv_J_I__J(z, 146097); var doe int64 = z - era*146097; var tmp1 int64 = doe - doe/1460; var tmp2 int64 = tmp1 + doe/36524; var yoe int64 = (tmp2 - doe/146096) / 365; var tmp3 int64 = 365*yoe + yoe/4; var doy int64 = doe - (tmp3 - yoe/100); var mp int64 = (5*doy + 2) / 153; var d int64 = doy - (153*mp+2)/5 + 1; var m int64




















	if mp < 10 { m = mp + 3 } else { m = mp - 9 }
	var tmp4 int64 = yoe + era*400; var tmp5 int32
	if m <= 2 { tmp5 = 1 } else { tmp5 = 0 }
//line :219:1
	return LongArrayOf(tmp4+int64(tmp5), m, d)
}

func GregorianCalendar_JulianYmd_J__J1(days int64) *LongArray { GregorianCalendar_Init()
	var c int64 = days + 2440588 + 32082; var dd int64 = Math_FloorDiv_J_I__J(4*c+3, 1461); var e int64 = c - Math_FloorDiv_J_I__J(1461*dd, 4); var mm int64 = Math_FloorDiv_J_I__J(5*e+2, 153); var d int64 = e - Math_FloorDiv_J_I__J(153*mm+2, 5) + 1; var m int64 = mm + 3 - 12*Math_FloorDiv_J_I__J(mm, 10); var y int64 = dd - 4800 + Math_FloorDiv_J_I__J(mm, 10)












	return LongArrayOf(y, m, d)
}
func (t *GregorianCalendar) Ymd_J__J1(days int64) *LongArray {
	if days >= t.F_gregorianCutoverDay {
		return GregorianCalendar_GregorianYmd_J__J1(days) } else {
			return GregorianCalendar_JulianYmd_J__J1(days)
		} }
func (t *GregorianCalendar) FixedDate_J_J_J__J(y, m0, d int64) int64 {
	y = y + Math_FloorDiv_J_I__J(m0, 12)
	var m int64 = int64(Math_FloorMod_J_I__I(m0, 12) + 1)
	return t.Choose_J_J_J__J(y, GregorianCalendar_GregorianDays_J_J_J__J(y, m, d), GregorianCalendar_JulianDays_J_J_J__J(y, m, d))
}
func (t *GregorianCalendar) Choose_J_J_J__J(year, gfd, jfd int64) int64 {
	var tmp1 bool; var tmp2 bool
	tmp2 = year > int64(t.F_gregorianCutoverYear); if tmp2 { tmp2 = year > int64(t.F_gregorianCutoverYearJulian) }; tmp1 = tmp2
//line :249:1
	if tmp1 {

		if gfd >= t.F_gregorianCutoverDay { return gfd } else { return jfd } } else {
//line :249:1
			var tmp3 bool; var tmp4 bool


			tmp4 = year < int64(t.F_gregorianCutoverYear); if tmp4 { tmp4 = year < int64(t.F_gregorianCutoverYearJulian) }; tmp3 = tmp4
//line :249:1
			if tmp3 { return jfd } else { if gfd >= t.F_gregorianCutoverDay { return gfd } else { return jfd
			}
			}
		}
}


func GregorianCalendar_JulianFirst_J_J__J(y, m0 int64) int64 { GregorianCalendar_Init()
	return GregorianCalendar_JulianDays_J_J_J__J(y+Math_FloorDiv_J_I__J(m0, 12), int64(Math_FloorMod_J_I__I(m0, 12)+1), 1)
}


func (t *GregorianCalendar) IsCutoverYear_J__Z(y int64) bool {
	var tmp1 bool; tmp1 = y == int64(t.F_gregorianCutoverYear); if !tmp1 { tmp1 = y == int64(t.F_gregorianCutoverYearJulian) }; return tmp1
}
func (t *GregorianCalendar) Jan1_J__J(y int64) int64 { return t.FixedDate_J_J_J__J(y, 0, 1) }

func (t *GregorianCalendar) IsLeapYear_I__Z(year int32) bool {
	if !(year&3 == 0) { return false } else { if year > t.F_gregorianCutoverYear {


		var tmp1 bool; tmp1 = !(year%100 == 0); if !tmp1 {
			tmp1 = year%400 == 0 }
//line :270:1
		return tmp1 } else {
//line :267:1
			if year < t.F_gregorianCutoverYearJulian { return true } else {






				var gregorian bool; if t.F_gregorianCutoverYear == t.F_gregorianCutoverYearJulian {
					gregorian = GregorianCalendar_GregorianYmd_J__J1(t.F_gregorianCutoverDay).A[1] < 3 } else {


						gregorian = year == t.F_gregorianCutoverYear }
				if gregorian {
					var tmp2 bool; tmp2 = !(year%100 == 0); if !tmp2 {
						tmp2 = year%400 == 0 }
//line :280:1
					return tmp2 } else {
//line :279:1
						return true
					}
			}
		}
	} }
func (t *GregorianCalendar) MonthLength_I_I__I(month, year int32) int32 {
	if t.IsLeapYear_I__Z(year) { return GregorianCalendar_LEAP_MONTH_LENGTH.A[month] } else { return GregorianCalendar_MONTH_LENGTH.A[month]
	} }
func GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(days int64, dayOfWeek int32) int64 { GregorianCalendar_Init()
	return days - int64(Math_FloorMod_I_I__I(GregorianCalendar_DayOfWeekOf_J__I(days)-dayOfWeek, 7))
}



func GregorianCalendar_DayOfWeekOf_J__I(days int64) int32 { GregorianCalendar_Init()
	return Math_FloorMod_J_I__I(days+4, 7) + 1
}
func (t *GregorianCalendar) WeekNumber_J_J__I(day1, days int64) int32 {
	var day1st int64 = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(day1+6, t.GetFirstDayOfWeek__I()); var ndays int32 = int32(day1st - day1)



	if ndays >= t.GetMinimalDaysInFirstWeek__I() {
		day1st = day1st - 7 }
	var normalized int32 = int32(days - day1st)
	if normalized >= 0 {
		return normalized/7 + 1 } else {
			return Math_FloorDiv_I_I__I(normalized, 7) + 1
		} }
func (t *GregorianCalendar) ComputeFields__V() {
	var tz TimeZone_I = t.GetTimeZone__TimeZone()
	var zoneOffset int32 = 0
	var dstOffset int32 = 0; var tmp1 TimeZone_I = tz
	if ZoneInfo_InstanceOf(tmp1) { var zi *ZoneInfo = ZoneInfo_Cast(tmp1); var offsets *IntArray = NewIntArray(2)

		NN(zi).GetOffsets_J_I1__I(t.F_time, offsets)
		zoneOffset = offsets.A[0]
		dstOffset = offsets.A[1] } else {

			zoneOffset = tz.GetRawOffset__I()
			dstOffset = tz.GetOffset_J__I(t.F_time) - zoneOffset }
	var local int64 = t.F_time + int64(zoneOffset) + int64(dstOffset); var days int64 = Math_FloorDiv_J_J__J(local, 86400000); var tod int32 = int32(Math_FloorMod_J_J__J(local, 86400000)); var ymd *LongArray = t.Ymd_J__J1(days); var y int64 = ymd.A[0]; var month int32 = int32(ymd.A[1]) - 1; var dom int32 = int32(ymd.A[2]); var jan1 int64 = t.Jan1_J__J(y)
	var era int32 = 1
	var yearOfEra int64 = y







	if y <= 0 { era = 0; yearOfEra = 1 - y }
	t.InternalSet_I_I__V(0, era)
	t.InternalSet_I_I__V(1, int32(yearOfEra))
	t.InternalSet_I_I__V(2, month)
	t.InternalSet_I_I__V(5, dom)
	t.InternalSet_I_I__V(7, GregorianCalendar_DayOfWeekOf_J__I(days))
	t.InternalSet_I_I__V(6, int32(days-jan1)+1)


	var month1 int64 = t.FixedDate_J_J_J__J(y, int64(month), 1)
	t.InternalSet_I_I__V(8, int32(days-month1)/7+1)




	t.InternalSet_I_I__V(4, t.WeekNumber_J_J__I(month1, days))
	var weekOfYear int32 = t.WeekNumber_J_J__I(jan1, days)
	if weekOfYear == 0 {

		weekOfYear = t.WeekNumber_J_J__I(t.Jan1_J__J(y-1), jan1-1) } else {
//line :347:1
			var tmp2 bool; var tmp3 bool





			tmp3 = weekOfYear >= 52; if !tmp3 {
				var tmp4 bool; tmp4 = y <= int64(t.F_gregorianCutoverYear); if tmp4 {
					tmp4 = y >= int64(t.F_gregorianCutoverYearJulian-1) }
//line :354:1
				tmp3 = tmp4 }
//line :353:1
			tmp2 = tmp3
//line :347:1
			if tmp2 {








				var nextJan1 int64 = t.Jan1_J__J(y + 1); var nextJan1st int64 = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(nextJan1+6, t.GetFirstDayOfWeek__I()); var ndays int32 = int32(nextJan1st - nextJan1); var tmp5 bool; var tmp6 bool




				tmp6 = ndays >= t.GetMinimalDaysInFirstWeek__I(); if tmp6 {
					tmp6 = days >= nextJan1st-7 }
//line :361:1
				tmp5 = tmp6; if tmp5 {

					weekOfYear = 1 } } }
	t.InternalSet_I_I__V(3, weekOfYear)
	var hour int32 = tod / 3600000
	t.InternalSet_I_I__V(11, hour)
	t.InternalSet_I_I__V(9, hour/12)
	t.InternalSet_I_I__V(10, hour%12)
	t.InternalSet_I_I__V(12, tod/60000%60)


	t.InternalSet_I_I__V(13, tod/1000%60)


	t.InternalSet_I_I__V(14, tod%1000)


	t.InternalSet_I_I__V(15, zoneOffset)
	t.InternalSet_I_I__V(16, dstOffset)
	var tmp7 bool; var tmp8 bool = true; t.F_areAllFieldsSet = tmp8; tmp7 = tmp8; t.F_areFieldsSet = tmp7
}
func (t *GregorianCalendar) ComputeTime__V() {
	var originalFields *IntArray
	if t.IsLenient__Z() { } else {
		originalFields = NewIntArray(17)
		var field int32 = 0; L1: for {
			if field < 17 {
				var value int32 = t.InternalGet_I__I(field)
				if t.IsExternallySet_I__Z(field) {
					var tmp1 bool; var tmp2 bool; tmp2 = value < t.GetMinimum_I__I(field); if !tmp2 { tmp2 = value > t.GetMaximum_I__I(field) }; tmp1 = tmp2; if tmp1 {
						panic(Thrown(IllegalArgumentException_New_String(Calendar_GetFieldName_I__String(field)))) } }
				originalFields.A[field] = value
				field = field + 1; continue L1 }
//line :386:1
			break L1
		}
	}





	var userSet *BooleanArray = NewBooleanArray(17); var field_2 int32 = 0
L2: for {
	if field_2 < 17 {
		userSet.A[field_2] = t.IsExternallySet_I__Z(field_2)
		field_2 = field_2 + 1; continue L2 }
//line :395:1
	break L2
}


	var fieldMask int32 = t.SelectFields__I(); var year int64
	if t.IsSet_I__Z(1) { year = int64(t.InternalGet_I__I(1)) } else { year = 1970 }
//line :399:1
	var era int32



	if t.IsSet_I__Z(0) {
		era = t.InternalGet_I__I(0) } else {
//line :403:1
			era = 1
		}

	if era == 0 {
		year = 1 - year } else {
			if era == 1 { } else { panic(Thrown(IllegalArgumentException_New_String(Lit_2688))) } }
	var timeOfDay int64 = 0
	if Calendar_IsFieldSet_I_I__Z(fieldMask, 11) {
		timeOfDay = timeOfDay + int64(t.InternalGet_I__I(11)) } else {



			timeOfDay = timeOfDay + int64(t.InternalGet_I__I(10))

			if Calendar_IsFieldSet_I_I__Z(fieldMask, 9) {
				timeOfDay = timeOfDay + int64(12*t.InternalGet_I__I(9))
			}
		}


	timeOfDay = timeOfDay * 60
	timeOfDay = timeOfDay + int64(t.InternalGet_I__I(12))
	timeOfDay = timeOfDay * 60
	timeOfDay = timeOfDay + int64(t.InternalGet_I__I(13))
	timeOfDay = timeOfDay * 1000
	timeOfDay = timeOfDay + int64(t.InternalGet_I__I(14))

	var days int64 = timeOfDay / 86400000
	timeOfDay = timeOfDay % 86400000
L3: for { if timeOfDay < 0 {
	timeOfDay = timeOfDay + 86400000
	days = days - 1
//line :432:1
	continue L3 }; break L3
}

	var gfd int64 = 0
	var jfd int64 = 0
L4: switch { default:
	var tmp3 bool; var tmp4 bool
	tmp4 = year > int64(t.F_gregorianCutoverYear); if tmp4 { tmp4 = year > int64(t.F_gregorianCutoverYearJulian) }; tmp3 = tmp4
//line :438:1
	if tmp3 {


		gfd = days + t.DateOfFields_Z_J_I__J(true, year, fieldMask)
		if gfd >= t.F_gregorianCutoverDay { days = gfd; break L4 }
		jfd = days + t.DateOfFields_Z_J_I__J(false, year, fieldMask) } else {
//line :438:1
			var tmp5 bool; var tmp6 bool





			tmp6 = year < int64(t.F_gregorianCutoverYear); if tmp6 { tmp6 = year < int64(t.F_gregorianCutoverYearJulian) }; tmp5 = tmp6
//line :438:1
			if tmp5 {







				jfd = days + t.DateOfFields_Z_J_I__J(false, year, fieldMask)
				if jfd < t.F_gregorianCutoverDay { days = jfd; break L4 }
				gfd = jfd } else {


					jfd = days + t.DateOfFields_Z_J_I__J(false, year, fieldMask)
					gfd = days + t.DateOfFields_Z_J_I__J(true, year, fieldMask) } }
	var tmp7 bool; var tmp8 bool; tmp8 = Calendar_IsFieldSet_I_I__Z(fieldMask, 6); if !tmp8 {
		tmp8 = Calendar_IsFieldSet_I_I__Z(fieldMask, 3) }
//line :453:1
	tmp7 = tmp8; if tmp7 {

		if t.F_gregorianCutoverYear == t.F_gregorianCutoverYearJulian {
			days = jfd; break L4 } else {
				if year == int64(t.F_gregorianCutoverYear) { days = gfd; break L4 } } }
	if gfd >= t.F_gregorianCutoverDay {
		days = gfd } else {
//line :458:1
			if jfd < t.F_gregorianCutoverDay {

				days = jfd } else {


					if t.IsLenient__Z() { } else {
						panic(Thrown(IllegalArgumentException_New_String(Lit_2689))) }
					days = jfd } }}
	var local int64 = days*86400000 + timeOfDay; var tz TimeZone_I = t.GetTimeZone__TimeZone(); var t_ int64 = 0; var offsets *IntArray = NewIntArray(2); var zoneSet bool = Calendar_IsFieldSet_I_I__Z(fieldMask, 15); var dstSet bool = Calendar_IsFieldSet_I_I__Z(fieldMask, 16); var tmp9 bool; var tmp10 bool





	tmp10 = zoneSet; if tmp10 { tmp10 = dstSet }; tmp9 = tmp10; if tmp9 { } else {
		var tmp11 TimeZone_I = tz; if ZoneInfo_InstanceOf(tmp11) { var zi *ZoneInfo = ZoneInfo_Cast(tmp11)
			NN(zi).GetOffsetsByWall_J_I1__I(local, offsets) } else {
				var gmtOffset int32; if zoneSet {
					gmtOffset = t.InternalGet_I__I(15) } else {
						gmtOffset = tz.GetRawOffset__I() }
				offsets.A[0] = tz.GetRawOffset__I()
				offsets.A[1] = tz.GetOffset_J__I(local-int64(gmtOffset)) - offsets.A[0]
			}
	}


	if zoneSet { offsets.A[0] = t.InternalGet_I__I(15) }
	if dstSet { offsets.A[1] = t.InternalGet_I__I(16) }
	var tmp12 int32 = offsets.A[0]; t_ = local - int64(tmp12+offsets.A[1])


	t.F_time = t_
	t.ComputeFields__V()
	if !(originalFields == nil) {
		var field_3 int32 = 0; L5: for {
			if field_3 < 17 {
				var tmp13 bool; var tmp14 bool; tmp14 = userSet.A[field_3]; if tmp14 {
					var tmp15 int32 = originalFields.A[field_3]; tmp14 = !(tmp15 == t.InternalGet_I__I(field_3)) }
//line :494:1
				tmp13 = tmp14; if tmp13 {

					var tmp16 int32 = originalFields.A[field_3]; var s *String = Concat(StrOfInt(tmp16), Lit_1495, StrOfInt(t.InternalGet_I__I(field_3))); var tmp17 any = originalFields.Ref(); var tmp18 any = t.F_fields.Ref()


					System_Arraycopy_O_I_O_I_I__V(tmp17, 0, tmp18, 0, int32(len(t.F_fields.A)))





					panic(Thrown(IllegalArgumentException_New_String(Concat(Calendar_GetFieldName_I__String(field_3), Lit_1157, s)))) } else {

						field_3 = field_3 + 1; continue L5 } }
//line :492:1
			break L5
		}
	}
}














func (t *GregorianCalendar) DateOfFields_Z_J_I__J(gregorian bool, year int64, fieldMask int32) int64 {
	var month int64 = 0
	if Calendar_IsFieldSet_I_I__Z(fieldMask, 2) {
		month = int64(t.InternalGet_I__I(2))
		year = year + Math_FloorDiv_J_I__J(month, 12)
		month = int64(Math_FloorMod_J_I__I(month, 12)) }
	var fixedDate int64; if gregorian {
		fixedDate = GregorianCalendar_GregorianDays_J_J_J__J(year, month+1, 1) } else {
			fixedDate = GregorianCalendar_JulianDays_J_J_J__J(year, month+1, 1) }
	if Calendar_IsFieldSet_I_I__Z(fieldMask, 2) {
		if Calendar_IsFieldSet_I_I__Z(fieldMask, 5) {

			if t.IsSet_I__Z(5) {
				fixedDate = fixedDate + int64(t.InternalGet_I__I(5))


				fixedDate = fixedDate - 1 } } else {
//line :520:1
					if Calendar_IsFieldSet_I_I__Z(fieldMask, 4) {







						var firstDayOfWeek int64 = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(fixedDate+6, t.GetFirstDayOfWeek__I())


						if firstDayOfWeek-fixedDate >= int64(t.GetMinimalDaysInFirstWeek__I()) {

							firstDayOfWeek = firstDayOfWeek - 7 }
						if Calendar_IsFieldSet_I_I__Z(fieldMask, 7) {
							firstDayOfWeek = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(firstDayOfWeek+6, t.InternalGet_I__I(7))
						}


						fixedDate = firstDayOfWeek + 7*int64(t.InternalGet_I__I(4)-1) } else {







							var dayOfWeek int32; if Calendar_IsFieldSet_I_I__Z(fieldMask, 7) {


								dayOfWeek = t.InternalGet_I__I(7) } else {
									dayOfWeek = t.GetFirstDayOfWeek__I() }
//line :547:1
							var dowim int32




							if Calendar_IsFieldSet_I_I__Z(fieldMask, 8) {


								dowim = t.InternalGet_I__I(8) } else {
//line :552:1
									dowim = 1
								}



							if dowim >= 0 {
								fixedDate = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(fixedDate+7*int64(dowim)-1, dayOfWeek) } else {





									var lastDate int32 = t.MonthLength_I_I__I(int32(month), int32(year)) + 7*(dowim+1)





									fixedDate = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(fixedDate+int64(lastDate)-1, dayOfWeek) } } } } else {




										var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = year == int64(t.F_gregorianCutoverYear); if tmp4 { tmp4 = gregorian }; tmp3 = tmp4; if tmp3 {
											tmp3 = fixedDate < t.F_gregorianCutoverDay }
//line :575:1
										tmp2 = tmp3; if tmp2 {

											tmp2 = !(t.F_gregorianCutoverYear == t.F_gregorianCutoverYearJulian) }
//line :575:1
										tmp1 = tmp2; if tmp1 {


											fixedDate = t.F_gregorianCutoverDay }
										if Calendar_IsFieldSet_I_I__Z(fieldMask, 6) {

											fixedDate = fixedDate + int64(t.InternalGet_I__I(6))


											fixedDate = fixedDate - 1 } else {
												var firstDayOfWeek_2 int64 = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(fixedDate+6, t.GetFirstDayOfWeek__I())


												if firstDayOfWeek_2-fixedDate >= int64(t.GetMinimalDaysInFirstWeek__I()) {

													firstDayOfWeek_2 = firstDayOfWeek_2 - 7 }
												if Calendar_IsFieldSet_I_I__Z(fieldMask, 7) {
													var dayOfWeek_2 int32 = t.InternalGet_I__I(7)
													if dayOfWeek_2 == t.GetFirstDayOfWeek__I() { } else {
														firstDayOfWeek_2 = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(firstDayOfWeek_2+6, dayOfWeek_2)
													}
												}

												fixedDate = firstDayOfWeek_2 + 7*(int64(t.InternalGet_I__I(3))-1) } }
//line :516:1
	return fixedDate
}


























































































func (t *GregorianCalendar) Era__I() int32 {
	if t.IsSet_I__Z(0) { return t.InternalGet_I__I(0) } else { return 1
	} }
func (t *GregorianCalendar) MonthLength_I__I(month int32) int32 {
	var year int32 = t.InternalGet_I__I(1)
	if t.Era__I() == 0 { year = 1 - year }
	return t.MonthLength_I_I__I(month, year)
}
func (t *GregorianCalendar) SetYearOfEra_I_Z__V(year int32, ce bool) {
	if year > 0 {
		t.Set_I_I__V(1, year) } else {

			t.Set_I_I__V(1, 1-year)
			var tmp1 int32; if ce { tmp1 = 0 } else { tmp1 = 1 }; t.Set_I_I__V(0, tmp1)
		} }
func (t *GregorianCalendar) PinDayOfMonth__V() {
	var year int32 = t.InternalGet_I__I(1); var monthLen int32 = 0; var tmp1 bool; var tmp2 bool

	tmp2 = year > t.F_gregorianCutoverYear; if !tmp2 { tmp2 = year < t.F_gregorianCutoverYearJulian }; tmp1 = tmp2; if tmp1 {
		monthLen = t.MonthLength_I__I(t.InternalGet_I__I(2)) } else {
			var gc *GregorianCalendar = GregorianCalendar_Cast(t.Clone__O())
			NN(gc).SetLenient_Z__V(true)
			monthLen = NN(gc).GetActualMaximum_I__I(5) }
	var dom int32 = t.InternalGet_I__I(5)
	if dom > monthLen { t.Set_I_I__V(5, monthLen)
	} }
func (t *GregorianCalendar) Add_I_I__V(field, amount int32) {
	if amount == 0 { } else {
		var tmp1 bool; var tmp2 bool; tmp2 = field < 0; if !tmp2 { tmp2 = field >= 15 }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(IllegalArgumentException_New())) }
		t.Complete__V()
		if field == 1 {

			var year int32 = t.InternalGet_I__I(1)
			if t.Era__I() == 1 {
				t.SetYearOfEra_I_Z__V(year+amount, true) } else {
					t.SetYearOfEra_I_Z__V(year-amount, false) }
			t.PinDayOfMonth__V() } else {
//line :639:1
				if field == 2 {







					var month int32 = t.InternalGet_I__I(2) + amount; var year_2 int32 = t.InternalGet_I__I(1); var yAmount int32



					if month >= 0 {
						yAmount = month / 12 } else {
							yAmount = (month+1)/12 - 1
						}

					if yAmount == 0 { } else {
						if t.Era__I() == 1 {
							t.SetYearOfEra_I_Z__V(year_2+yAmount, true) } else {
								t.SetYearOfEra_I_Z__V(year_2-yAmount, false) } }
					if month >= 0 {
						t.Set_I_I__V(2, month%12) } else {

							month = month % 12
							if month < 0 { month = month + 12 }
							t.Set_I_I__V(2, 0+month)
						}

					t.PinDayOfMonth__V() } else {
//line :639:1
						if field == 0 {






























							var era int32 = t.InternalGet_I__I(0) + amount
							if era < 0 { era = 0 }
							if era > 1 { era = 1 }
							t.Set_I_I__V(0, era) } else {

								var delta int64 = int64(amount)
								var timeOfDay int64 = 0
								switch field { case 10, 11:

									delta = delta * 3600000
//line :677:1
								case 12:







									delta = delta * 60000
//line :677:1
								case 13:








									delta = delta * 1000
//line :677:1
								case 3, 4, 8:











									delta = delta * 7
//line :677:1
								case 9:














									delta = int64(amount / 2)
									timeOfDay = int64(12 * (amount % 2))
//line :677:1
								default:
								}
















								if field >= 10 {
									t.SetTimeInMillis_J__V(t.F_time + delta) } else {
										var fd int64 = t.CurrentDay__J()
										timeOfDay = timeOfDay + int64(t.InternalGet_I__I(11))

										timeOfDay = timeOfDay * 60
										timeOfDay = timeOfDay + int64(t.InternalGet_I__I(12))

										timeOfDay = timeOfDay * 60
										timeOfDay = timeOfDay + int64(t.InternalGet_I__I(13))

										timeOfDay = timeOfDay * 1000
										timeOfDay = timeOfDay + int64(t.InternalGet_I__I(14))

										if timeOfDay >= 86400000 {

											fd = fd + 1
											timeOfDay = timeOfDay - 86400000 } else {
												if timeOfDay < 0 {
													fd = fd - 1
													timeOfDay = timeOfDay + 86400000 } }
										fd = fd + delta
										var zoneOffset int32 = t.InternalGet_I__I(15) + t.InternalGet_I__I(16)


										t.SetTimeInMillis_J__V(fd*86400000 + timeOfDay - int64(zoneOffset))
									}
							}
					}
			} } }
func (t *GregorianCalendar) CurrentDay__J() int64 {
	var tmp1 int64 = t.F_time; var tmp2 int64 = tmp1 + int64(t.InternalGet_I__I(15)); return Math_FloorDiv_J_J__J(tmp2+int64(t.InternalGet_I__I(16)), 86400000)
}



func GregorianCalendar_GetRolledValue_I_I_I_I__I(value, amount, min_, max_ int32) int32 { GregorianCalendar_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = value >= min_; if tmp2 { tmp2 = value <= max_ }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var range_ int32 = max_ - min_ + 1
	amount = amount % range_
	var n int32 = value + amount
	if n > max_ {
		n = n - range_ } else {
//line :736:1
			if n < min_ {

				n = n + range_ } }
	var tmp3 bool; var tmp4 bool; tmp4 = n >= min_; if tmp4 { tmp4 = n <= max_ }; tmp3 = tmp4; if !A2g_AssertionsDisabled && !tmp3 { panic(Thrown(AssertionError_New())) }
//line :735:1
	return n
}





func (t *GregorianCalendar) Month1_J__J(fd int64) int64 {
	var dom int32 = t.InternalGet_I__I(5); var y int64
	if t.Era__I() == 0 { y = int64(1 - t.InternalGet_I__I(1)) } else { y = int64(t.InternalGet_I__I(1))
	}

	if t.IsCutoverYear_J__Z(y) {
		return t.FixedDate_J_J_J__J(y, int64(t.InternalGet_I__I(2)), 1) } else {
			return fd - int64(dom) + 1
		} }
func (t *GregorianCalendar) ActualMonthLength_J__I(month1 int64) int32 {
	var y int64; if t.Era__I() == 0 { y = int64(1 - t.InternalGet_I__I(1)) } else { y = int64(t.InternalGet_I__I(1))
	}

	return int32(t.FixedDate_J_J_J__J(y, int64(t.InternalGet_I__I(2)+1), 1) - month1)
}



func (t *GregorianCalendar) Roll_I_Z__V(field int32, up bool) {
	var tmp1 int32; if up { tmp1 = 1 } else { tmp1 = -1 }; t.Roll_I_I__V(field, tmp1)
}
func (t *GregorianCalendar) Roll_I_I__V(field, amount int32) {
	if amount == 0 { } else {
		var tmp1 bool; var tmp2 bool; tmp2 = field < 0; if !tmp2 { tmp2 = field >= 15 }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(IllegalArgumentException_New())) }
		t.Complete__V()
		var min_ int32 = t.GetMinimum_I__I(field); var max_ int32 = t.GetMaximum_I__I(field); var ny int64

		if t.Era__I() == 0 { ny = int64(1 - t.InternalGet_I__I(1)) } else { ny = int64(t.InternalGet_I__I(1))
		}

	L1: switch { default:
		switch field { case 9, 0, 1, 12, 13, 14:; case 10, 11:







			var rolledValue int32 = GregorianCalendar_GetRolledValue_I_I_I_I__I(t.InternalGet_I__I(field), amount, min_, max_); var hourOfDay int32 = rolledValue; var tmp3 bool; var tmp4 bool





			tmp4 = field == 10; if tmp4 {
				tmp4 = t.InternalGet_I__I(9) == 1 }
//line :788:1
			tmp3 = tmp4; if tmp3 {

				hourOfDay = hourOfDay + 12 }
			var fd int64 = t.CurrentDay__J(); var tod int64 = ((int64(hourOfDay)*60+int64(t.InternalGet_I__I(12)))*60+int64(t.InternalGet_I__I(13)))*1000 + int64(t.InternalGet_I__I(14))











			t.SetTimeInMillis_J__V(fd*86400000 + tod - int64(t.InternalGet_I__I(15)) - int64(t.InternalGet_I__I(16)))





			return; case 2:


			if !t.IsCutoverYear_J__Z(ny) {
				var mon int32 = (t.InternalGet_I__I(2) + amount) % 12




				if mon < 0 { mon = mon + 12 }
				t.Set_I_I__V(2, mon)
				var monthLen int32 = t.MonthLength_I__I(mon)
				if t.InternalGet_I__I(5) > monthLen {
					t.Set_I_I__V(5, monthLen) } } else {
						var yearLength int32 = 12; var mon_2 int32 = (t.InternalGet_I__I(2) + amount) % yearLength





						if mon_2 < 0 { mon_2 = mon_2 + yearLength }
						t.Set_I_I__V(2, mon_2)
						var monthLen_2 int32 = t.GetActualMaximum_I__I(5)
						if t.InternalGet_I__I(5) > monthLen_2 {
							t.Set_I_I__V(5, monthLen_2) } }
			return; case 3:


			max_ = t.GetActualMaximum_I__I(3)
			t.Set_I_I__V(7, t.InternalGet_I__I(7))


			var woy int32 = t.InternalGet_I__I(3); var value int32 = woy + amount; var fd_2 int64 = t.CurrentDay__J()


			if t.IsCutoverYear_J__Z(ny) { } else {
				var weekYear int64 = int64(t.GetWeekYear__I())
				if weekYear == ny {


					var tmp5 bool; var tmp6 bool; tmp6 = value > min_; if tmp6 { tmp6 = value < max_ }; tmp5 = tmp6; if tmp5 {
						t.Set_I_I__V(3, value)
						return }
					var day1 int64 = fd_2 - int64(7*(woy-min_))


					if t.Ymd_J__J1(day1).A[0] == ny { } else {
						min_ = min_ + 1 }
					fd_2 = fd_2 + int64(7*(max_-t.InternalGet_I__I(3)))







					if t.Ymd_J__J1(fd_2).A[0] == ny { } else {
						max_ = max_ - 1 } } else {
//line :846:1
							if weekYear > ny {






















								if amount < 0 { amount = amount + 1 }
								woy = max_ } else {


									if amount > 0 {
										amount = amount - (woy - max_)
									}

									woy = min_ } }
				var newWeekOfYear int32 = GregorianCalendar_GetRolledValue_I_I_I_I__I(woy, amount, min_, max_); var tmp7 bool; var tmp8 bool; var tmp9 bool




				tmp9 = newWeekOfYear == 1; if tmp9 { tmp9 = t.IsInvalidWeek1__Z() }; tmp8 = tmp9; if tmp8 { tmp8 = amount > 0 }; tmp7 = tmp8; if tmp7 {
					newWeekOfYear = newWeekOfYear + 1 }
				t.Set_I_I__V(field, newWeekOfYear)
				return }
			var day1_2 int64 = fd_2 - int64(7*(woy-min_))


			if t.Ymd_J__J1(day1_2).A[0] == ny { } else { min_ = min_ + 1 }
			fd_2 = fd_2 + int64(7*(max_-woy))



			if t.Ymd_J__J1(fd_2).A[0] == ny { } else { max_ = max_ - 1 }
			value = GregorianCalendar_GetRolledValue_I_I_I_I__I(woy, amount, min_, max_) - 1



			var d *LongArray = t.Ymd_J__J1(day1_2 + int64(value)*7)
			t.Set_I_I__V(2, int32(d.A[1])-1)


			t.Set_I_I__V(5, int32(d.A[2]))
			return; case 4:

			var cutover bool = t.IsCutoverYear_J__Z(ny); var dow int32 = t.InternalGet_I__I(7) - t.GetFirstDayOfWeek__I()



			if dow < 0 { dow = dow + 7 }
			var fd_3 int64 = t.CurrentDay__J(); var month1 int64 = t.Month1_J__J(fd_3); var monthLength int32 = t.ActualMonthLength_J__I(month1); var monthDay1st int64 = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(month1+6, t.GetFirstDayOfWeek__I())





			if int32(monthDay1st-month1) >= t.GetMinimalDaysInFirstWeek__I() {

				monthDay1st = monthDay1st - 7 }
			max_ = t.GetActualMaximum_I__I(field)
			var value_2 int32 = GregorianCalendar_GetRolledValue_I_I_I_I__I(t.InternalGet_I__I(field), amount, 1, max_) - 1; var nfd int64 = monthDay1st + int64(value_2)*7 + int64(dow)









			if nfd < month1 {
				nfd = month1 } else {
//line :932:1
					if nfd >= month1+int64(monthLength) {


						nfd = month1 + int64(monthLength) - 1 } }
			var dayOfMonth int32; if cutover {
				dayOfMonth = int32(t.Ymd_J__J1(nfd).A[2]) } else {
					dayOfMonth = int32(nfd-month1) + 1
				}

			t.Set_I_I__V(5, dayOfMonth)
			return; case 5:

			if !t.IsCutoverYear_J__Z(ny) {
				max_ = t.MonthLength_I__I(t.InternalGet_I__I(2)) } else {
					var fd_4 int64 = t.CurrentDay__J(); var month1_2 int64 = t.Month1_J__J(fd_4); var value_3 int32 = GregorianCalendar_GetRolledValue_I_I_I_I__I(int32(fd_4-month1_2), amount, 0, t.ActualMonthLength_J__I(month1_2)-1)






					t.Set_I_I__V(5, int32(t.Ymd_J__J1(month1_2 + int64(value_3)).A[2]))


					return }; case 6:


			max_ = t.GetActualMaximum_I__I(field)
			if !t.IsCutoverYear_J__Z(ny) { } else {
				var fd_5 int64 = t.CurrentDay__J(); var jan1 int64 = fd_5 - int64(t.InternalGet_I__I(6)) + 1; var value_4 int32 = GregorianCalendar_GetRolledValue_I_I_I_I__I(int32(fd_5-jan1)+1, amount, min_, max_); var d_2 *LongArray = t.Ymd_J__J1(jan1 + int64(value_4) - 1)











				t.Set_I_I__V(2, int32(d_2.A[1])-1)


				t.Set_I_I__V(5, int32(d_2.A[2]))
				return }; case 7:


			if t.IsCutoverYear_J__Z(ny) { } else {
				var weekOfYear int32 = t.InternalGet_I__I(3); var tmp10 bool; var tmp11 bool
				tmp11 = weekOfYear > 1; if tmp11 { tmp11 = weekOfYear < 52 }; tmp10 = tmp11; if tmp10 {
					t.Set_I_I__V(3, weekOfYear)
					max_ = 7
					break L1 } }
			amount = amount % 7
			if amount == 0 { return }
			var fd_6 int64 = t.CurrentDay__J(); var dowFirst int64 = GregorianCalendar_DayOfWeekOnOrBefore_J_I__J(fd_6, t.GetFirstDayOfWeek__I())

			fd_6 = fd_6 + int64(amount)
			if fd_6 < dowFirst {
				fd_6 = fd_6 + 7 } else {
//line :991:1
					if fd_6 >= dowFirst+7 {

						fd_6 = fd_6 - 7 } }
			var d_3 *LongArray = t.Ymd_J__J1(fd_6); var tmp12 int32
			if d_3.A[0] <= 0 { tmp12 = 0 } else { tmp12 = 1 }; t.Set_I_I__V(0, tmp12)
			var tmp13 int64

			if d_3.A[0] <= 0 { tmp13 = 1 - d_3.A[0] } else { tmp13 = d_3.A[0] }
//line :996:1
			var tmp14 int32 = int32(tmp13); var tmp15 int32 = int32(d_3.A[1]) - 1; t.Set_I_I_I__V(tmp14, tmp15, int32(d_3.A[2]))




			return
//line :998:1
		case 8:





			min_ = 1
			if !t.IsCutoverYear_J__Z(ny) {
				var dom int32 = t.InternalGet_I__I(5); var monthLength_2 int32 = t.MonthLength_I__I(t.InternalGet_I__I(2)); var lastDays int32 = monthLength_2 % 7




				max_ = monthLength_2 / 7
				var x int32 = (dom - 1) % 7
				if x < lastDays { max_ = max_ + 1 }
				t.Set_I_I__V(7, t.InternalGet_I__I(7)) } else {


					var fd_7 int64 = t.CurrentDay__J(); var month1_3 int64 = t.Month1_J__J(fd_7); var monthLength_3 int32 = t.ActualMonthLength_J__I(month1_3); var lastDays_2 int32 = monthLength_3 % 7



					max_ = monthLength_3 / 7
					var x_2 int32 = int32(fd_7-month1_3) % 7


					if x_2 < lastDays_2 { max_ = max_ + 1 }
					var value_5 int32 = GregorianCalendar_GetRolledValue_I_I_I_I__I(t.InternalGet_I__I(field), amount, min_, max_) - 1






					fd_7 = month1_3 + int64(value_5)*7 + int64(x_2)


					t.Set_I_I__V(5, int32(t.Ymd_J__J1(fd_7).A[2]))


					return }; default:
		}}
		t.Set_I_I__V(field, GregorianCalendar_GetRolledValue_I_I_I_I__I(t.InternalGet_I__I(field), amount, min_, max_))
	}
}

func (t *GregorianCalendar) IsInvalidWeek1__Z() bool {
	var jan1 int64 = GregorianCalendar_GregorianDays_J_J_J__J(int64(t.InternalGet_I__I(1)), 1, 1); var jan1Dow int32 = GregorianCalendar_DayOfWeekOf_J__I(jan1); var daysInFirstWeek int32

	if t.GetFirstDayOfWeek__I() <= jan1Dow {
		daysInFirstWeek = 7 - jan1Dow + t.GetFirstDayOfWeek__I() } else {


			daysInFirstWeek = t.GetFirstDayOfWeek__I() - jan1Dow }
	var endDow int32; if t.GetFirstDayOfWeek__I()-1 == 0 { endDow = 7 } else {

		endDow = t.GetFirstDayOfWeek__I() - 1 }
	var tmp1 bool; tmp1 = daysInFirstWeek >= t.GetMinimalDaysInFirstWeek__I(); if tmp1 {
		tmp1 = !GregorianCalendar_DayInMinWeek_I_I_I__Z(t.InternalGet_I__I(7), jan1Dow, endDow) }
//line :1056:1
	return tmp1
}




func GregorianCalendar_DayInMinWeek_I_I_I__Z(day, startDay, endDay int32) bool { GregorianCalendar_Init()
	if endDay >= startDay {
		var tmp1 bool; tmp1 = day >= startDay; if tmp1 { tmp1 = day <= endDay }; return tmp1 } else {
			var tmp2 bool; tmp2 = day >= startDay; if !tmp2 { tmp2 = day <= endDay }; return tmp2
		} }
func (t *GregorianCalendar) IsWeekDateSupported__Z() bool { return true }

func (t *GregorianCalendar) GetWeekYear__I() int32 {
	var year int32 = t.Get_I__I(1)
	if t.Era__I() == 0 { year = 1 - year }
	if year > t.F_gregorianCutoverYear+1 {
		var weekOfYear int32 = t.InternalGet_I__I(3)
		if t.InternalGet_I__I(2) == 0 {

			if weekOfYear >= 52 { year = year - 1 } } else {
//line :1074:1
				if weekOfYear == 1 {


					year = year + 1 } }
//line :1073:1
		return year

	} else {



		var dayOfYear int32 = t.InternalGet_I__I(6); var maxDayOfYear int32 = t.GetActualMaximum_I__I(6); var minimalDays int32 = t.GetMinimalDaysInFirstWeek__I(); var tmp1 bool; var tmp2 bool


		tmp2 = dayOfYear > minimalDays; if tmp2 {
			tmp2 = dayOfYear < maxDayOfYear-6 }
//line :1082:1
		tmp1 = tmp2; if tmp1 { return year } else {


			var cal *GregorianCalendar = GregorianCalendar_Cast(t.Clone__O())
			NN(cal).SetLenient_Z__V(true)
			NN(cal).SetTimeZone_TimeZone__V(TimeZone_GetTimeZone_String__TimeZone(Lit_1972))
			NN(cal).Set_I_I__V(6, 1)
			NN(cal).Complete__V()
			var delta int32 = t.GetFirstDayOfWeek__I() - NN(cal).Get_I__I(7)


			if delta == 0 { } else {
				if delta < 0 { delta = delta + 7 }
				NN(cal).Add_I_I__V(6, delta) }
			var minDayOfYear int32 = NN(cal).Get_I__I(6)
			if dayOfYear < minDayOfYear {
				if minDayOfYear <= minimalDays { year = year - 1 } } else {

					NN(cal).Set_I_I__V(1, year+1)
					NN(cal).Set_I_I__V(6, 1)
					NN(cal).Complete__V()
					var del int32 = t.GetFirstDayOfWeek__I() - NN(cal).Get_I__I(7)


					if del == 0 { } else {
						if del < 0 { del = del + 7 }
						NN(cal).Add_I_I__V(6, del) }
					minDayOfYear = NN(cal).Get_I__I(6) - 1



					if minDayOfYear == 0 { minDayOfYear = 7 }
					if minDayOfYear >= minimalDays {
						var days int32 = maxDayOfYear - dayOfYear + 1


						if days <= 7-minDayOfYear {
							year = year + 1 } } }
//line :1096:1
			return year
		}
	}
}






















func (t *GregorianCalendar) GetMinimum_I__I(field int32) int32 {
	return GregorianCalendar_MIN_VALUES.A[field]
}
func (t *GregorianCalendar) GetMaximum_I__I(field int32) int32 {
	return GregorianCalendar_MAX_VALUES.A[field]
}
func (t *GregorianCalendar) GetGreatestMinimum_I__I(field int32) int32 {
	return GregorianCalendar_MIN_VALUES.A[field]
}
func (t *GregorianCalendar) GetLeastMaximum_I__I(field int32) int32 {
	return GregorianCalendar_LEAST_MAX_VALUES.A[field]
}
func (t *GregorianCalendar) GetActualMinimum_I__I(field int32) int32 {
	return t.GetMinimum_I__I(field)
}
func (t *GregorianCalendar) GetActualMaximum_I__I(field int32) int32 {
	t.Complete__V()
	{ var y int64; if t.InternalGet_I__I(0) == 0 { y = int64(1 - t.InternalGet_I__I(1)) } else { y = int64(t.InternalGet_I__I(1))
	}

		switch field { case 5:

			return t.MonthLength_I_I__I(t.InternalGet_I__I(2), int32(y)); case 6:

			return int32(t.Jan1_J__J(y+1) - t.Jan1_J__J(y)); case 4:

			if t.IsCutoverYear_J__Z(y) {
				var gc *GregorianCalendar = GregorianCalendar_Cast(t.Clone__O()); var yy int32 = NN(gc).InternalGet_I__I(1); var mm int32 = NN(gc).InternalGet_I__I(2)
				var value int32 = 0


			L1: for {
				value = NN(gc).Get_I__I(4)
				NN(gc).Add_I_I__V(4, 1)
				var tmp1 bool; var tmp2 bool; tmp2 = NN(gc).Get_I__I(1) == yy; if tmp2 {
					tmp2 = NN(gc).Get_I__I(2) == mm }
//line :1156:1
				tmp1 = tmp2; if tmp1 {

					continue L1 }
//line :1153:1
				break L1 }
//line :1149:1
				return value






			} else {



				var month int32 = t.InternalGet_I__I(2)
				var first int64 = 0
				var monthLength int32 = 0
				if t.InternalGet_I__I(0) == 0 {

					first = GregorianCalendar_JulianFirst_J_J__J(int64(t.InternalGet_I__I(1)), int64(month))



					monthLength = int32(GregorianCalendar_JulianFirst_J_J__J(int64(t.InternalGet_I__I(1)), int64(month+1)) - first) } else {







						first = t.FixedDate_J_J_J__J(y, int64(month), 1)
						monthLength = int32(t.FixedDate_J_J_J__J(y, int64(month+1), 1) - first)
					}



				var dayOfWeek int32 = GregorianCalendar_DayOfWeekOf_J__I(first) - t.GetFirstDayOfWeek__I()


				if dayOfWeek < 0 { dayOfWeek = dayOfWeek + 7 }
				var nDaysFirstWeek int32 = 7 - dayOfWeek
				var value_2 int32 = 3
				if nDaysFirstWeek >= t.GetMinimalDaysInFirstWeek__I() {
					value_2 = value_2 + 1 }
				monthLength = monthLength - (nDaysFirstWeek + 21)



				if monthLength > 0 {
					value_2 = value_2 + 1
					if monthLength > 7 { value_2 = value_2 + 1 } }
//line :1187:1
				return value_2
			}








		case 3:


			if t.IsCutoverYear_J__Z(y) {
				var gc_2 *GregorianCalendar = GregorianCalendar_Cast(t.Clone__O()); var maxDayOfYear int32 = t.GetActualMaximum_I__I(6)

				NN(gc_2).Set_I_I__V(6, maxDayOfYear)
				var value_3 int32 = NN(gc_2).Get_I__I(3); var tmp3 bool; var tmp4 bool
				tmp4 = NN(gc_2).Get_I__I(2) == 11; if tmp4 {
					tmp4 = value_3 == 1 }
//line :1205:1
				tmp3 = tmp4; if tmp3 {

					NN(gc_2).Set_I_I__V(6, maxDayOfYear-7)
					value_3 = NN(gc_2).Get_I__I(3) }
//line :1204:1
				return value_3
			} else {




				var jan1 int64; if t.InternalGet_I__I(0) == 0 {
					jan1 = GregorianCalendar_JulianFirst_J_J__J(int64(t.InternalGet_I__I(1)), 0) } else {


						jan1 = t.Jan1_J__J(y) }
//line :1210:1
				var dayOfWeek_2 int32 = GregorianCalendar_DayOfWeekOf_J__I(jan1) - t.GetFirstDayOfWeek__I()







				if dayOfWeek_2 < 0 { dayOfWeek_2 = dayOfWeek_2 + 7 }
				var value_4 int32 = 52; var magic int32 = dayOfWeek_2 + t.GetMinimalDaysInFirstWeek__I() - 1; var tmp5 bool; var tmp6 bool



				tmp6 = magic == 6; if !tmp6 {
					var tmp7 bool; tmp7 = t.IsLeapYear_I__Z(int32(y)); if tmp7 {
						var tmp8 bool; tmp8 = magic == 5; if !tmp8 { tmp8 = magic == 12 }; tmp7 = tmp8 }
//line :1224:1
					tmp6 = tmp7 }
//line :1223:1
				tmp5 = tmp6; if tmp5 {


					value_4 = value_4 + 1 }
//line :1219:1
				return value_4 }
//line :1214:1
		case 8:














			var first_2 int64 = t.FixedDate_J_J_J__J(y, int64(t.InternalGet_I__I(2)), 1); var ndays int32 = int32(t.FixedDate_J_J_J__J(y, int64(t.InternalGet_I__I(2)+1), 1) - first_2); var x int32 = t.InternalGet_I__I(7) - GregorianCalendar_DayOfWeekOf_J__I(first_2)












			if x < 0 { x = x + 7 }
			ndays = ndays - x
			return (ndays + 6) / 7; case 1:

			if t.InternalGet_I__I(0) == 0 { return 292269055 } else { return 292278994 }; default:
			return t.GetMaximum_I__I(field)} }; panic("a2g: unreachable")
}
func (t *GregorianCalendar) GetCalendarType__String() *String { return Lit_2313 }

func (t *GregorianCalendar) Equals_O__Z(obj any) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = GregorianCalendar_InstanceOf(obj); if tmp2 { tmp2 = t.Calendar.Impl_Equals_O__Z(t, obj) }; tmp1 = tmp2; if tmp1 {
		var tmp3 int64 = t.F_gregorianCutover; tmp1 = tmp3 == GregorianCalendar_Cast(obj).F_gregorianCutover }
//line :1252:1
	return tmp1
}

func (t *GregorianCalendar) HashCode__I() int32 {
	return t.Calendar.Impl_HashCode__I(t) ^ int32(t.F_gregorianCutoverDay+719163)
}
func (t *GregorianCalendar) Clone__O() any { return t.Calendar.Impl_Clone__O(t) }

func (t *GregorianCalendar) GetTimeZone__TimeZone() TimeZone_I { return t.Calendar.Impl_GetTimeZone__TimeZone(t) }

func (t *GregorianCalendar) SetTimeZone_TimeZone__V(zone TimeZone_I) {
	t.Calendar.Impl_SetTimeZone_TimeZone__V(t, zone)
}
func (t *GregorianCalendar) ToZonedDateTime__ZonedDateTime() *ZonedDateTime {
	return ZonedDateTime_OfInstant_Instant_ZoneId__ZonedDateTime(Instant_OfEpochMilli_J__Instant(t.GetTimeInMillis__J()), t.GetTimeZone__TimeZone().ToZoneId__ZoneId())
}

func GregorianCalendar_From_ZonedDateTime__GregorianCalendar(zdt *ZonedDateTime) *GregorianCalendar { GregorianCalendar_Init()
	var cal *GregorianCalendar = GregorianCalendar_New_TimeZone(TimeZone_GetTimeZone_ZoneId__TimeZone(NN(zdt).GetZone__ZoneId()))
	NN(cal).SetGregorianChange_Date__V(Date_New_J(-9223372036854775808))
	NN(cal).SetFirstDayOfWeek_I__V(2)
	NN(cal).SetMinimalDaysInFirstWeek_I__V(4); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var tmp1 int64 = Math_MultiplyExact_J_I__J(NN(zdt).ToEpochSecond__J(), 1000); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MILLI_OF_SECOND; NN(cal).SetTimeInMillis_J__V(Math_AddExact_J_J__J(tmp1, int64(NN(zdt).Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2))))) }; return nil }()
//line :1274:1
	if tmp3 != nil { if ArithmeticException_InstanceOf(tmp3) { var ex *ArithmeticException = ArithmeticException_Cast(tmp3)



		panic(Thrown(IllegalArgumentException_New_Throwable(Up_ArithmeticException_Throwable(ex)))) } else {
//line :1274:1
			panic(tmp3) } }
//line :1270:1
	return cal
}







type GregorianCalendar struct{ Calendar; F_gregorianCutover, F_gregorianCutoverDay int64; F_gregorianCutoverYear, F_gregorianCutoverYearJulian int32 }

const GregorianCalendar_BC int32 = 0

const GregorianCalendar_AD int32 = 1

const GregorianCalendar_BCE int32 = 0

const GregorianCalendar_CE int32 = 1

const GregorianCalendar_ONE_SECOND int32 = 1000

const GregorianCalendar_ONE_MINUTE int32 = 60000

const GregorianCalendar_ONE_HOUR int32 = 3600000

const GregorianCalendar_ONE_DAY int64 = 86400000

var GregorianCalendar_MIN_VALUES *IntArray

var GregorianCalendar_LEAST_MAX_VALUES *IntArray

var GregorianCalendar_MAX_VALUES *IntArray

var GregorianCalendar_MONTH_LENGTH *IntArray

var GregorianCalendar_LEAP_MONTH_LENGTH *IntArray

const GregorianCalendar_DEFAULT_GREGORIAN_CUTOVER int64 = -12219292800000

var GregorianCalendar_init ClassInit

func GregorianCalendar_Init() { if !GregorianCalendar_init.Done() { GregorianCalendar_init.Run(GregorianCalendar_clinit) } }

func GregorianCalendar_clinit() { Calendar_Init(); GregorianCalendar_MIN_VALUES = IntArrayOf(0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, -46800000, 0); GregorianCalendar_LEAST_MAX_VALUES = IntArrayOf(1, 292269054, 11, 52, 4, 28, 365, 7, 4, 1, 11, 23, 59, 59, 999, 50400000, 1200000); GregorianCalendar_MAX_VALUES = IntArrayOf(1, 292278994, 11, 53, 6, 31, 366, 7, 6, 1, 11, 23, 59, 59, 999, 50400000, 7200000); GregorianCalendar_MONTH_LENGTH = IntArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31); GregorianCalendar_LEAP_MONTH_LENGTH = IntArrayOf(31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31) }

func (t *GregorianCalendar) SetTime_Date__V(p0 Date_I) { t.Impl_SetTime_Date__V(t, p0) }

func (t *GregorianCalendar) SetMinimalDaysInFirstWeek_I__V(p0 int32) { t.Impl_SetMinimalDaysInFirstWeek_I__V(t, p0) }

func (t *GregorianCalendar) Set_I_I__V(p0, p1 int32) { t.Impl_Set_I_I__V(t, p0, p1) }

func (t *GregorianCalendar) Complete__V() { t.Impl_Complete__V(t) }

func (t *GregorianCalendar) Get_I__I(p0 int32) int32 { return t.Impl_Get_I__I(t, p0) }

func (t *GregorianCalendar) Set_I_I_I_I_I__V(p0, p1, p2, p3, p4 int32) { t.Impl_Set_I_I_I_I_I__V(t, p0, p1, p2, p3, p4) }

func (t *GregorianCalendar) Clear__V() { t.Impl_Clear__V(t) }

func (t *GregorianCalendar) GetTime__Date() Date_I { return t.Impl_GetTime__Date(t) }

func (t *GregorianCalendar) InternalGet_I__I(p0 int32) int32 { return t.Impl_InternalGet_I__I(t, p0) }

func (t *GregorianCalendar) Clear_I__V(p0 int32) { t.Impl_Clear_I__V(t, p0) }

func (t *GregorianCalendar) GetBaseStyle_I__I(p0 int32) int32 { return t.Impl_GetBaseStyle_I__I(t, p0) }

func (t *GregorianCalendar) InternalSet_I_I__V(p0, p1 int32) { t.Impl_InternalSet_I_I__V(t, p0, p1) }

func (t *GregorianCalendar) SetFirstDayOfWeek_I__V(p0 int32) { t.Impl_SetFirstDayOfWeek_I__V(t, p0) }

func (t *GregorianCalendar) IsLenient__Z() bool { return t.Impl_IsLenient__Z(t) }

func (t *GregorianCalendar) SelectFields__I() int32 { return t.Impl_SelectFields__I(t) }

func (t *GregorianCalendar) CompareTo_Calendar__I(p0 Calendar_I) int32 { return t.Impl_CompareTo_Calendar__I(t, p0) }

func (t *GregorianCalendar) SetLenient_Z__V(p0 bool) { t.Impl_SetLenient_Z__V(t, p0) }

func (t *GregorianCalendar) SetWeekDate_I_I_I__V(p0, p1, p2 int32) { t.Impl_SetWeekDate_I_I_I__V(t, p0, p1, p2) }

func (t *GregorianCalendar) IsSet_I__Z(p0 int32) bool { return t.Impl_IsSet_I__Z(t, p0) }

func (t *GregorianCalendar) IsExternallySet_I__Z(p0 int32) bool { return t.Impl_IsExternallySet_I__Z(t, p0) }

func (t *GregorianCalendar) GetWeeksInWeekYear__I() int32 { return t.Impl_GetWeeksInWeekYear__I(t) }

func (t *GregorianCalendar) Set_I_I_I_I_I_I__V(p0, p1, p2, p3, p4, p5 int32) { t.Impl_Set_I_I_I_I_I_I__V(t, p0, p1, p2, p3, p4, p5) }

func (t *GregorianCalendar) GetFirstDayOfWeek__I() int32 { return t.Impl_GetFirstDayOfWeek__I(t) }

func (t *GregorianCalendar) GetDisplayName_I_I_Locale__String(p0, p1 int32, p2 *Locale) *String { return t.Impl_GetDisplayName_I_I_Locale__String(t, p0, p1, p2) }

func (t *GregorianCalendar) GetMinimalDaysInFirstWeek__I() int32 { return t.Impl_GetMinimalDaysInFirstWeek__I(t) }

func (t *GregorianCalendar) ToInstant__Instant() *Instant { return t.Impl_ToInstant__Instant(t) }

func (t *GregorianCalendar) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *GregorianCalendar) GetTimeInMillis__J() int64 { return t.Impl_GetTimeInMillis__J(t) }

func (t *GregorianCalendar) CheckDisplayNameParams_I_I_I_I_Locale_I__Z(p0, p1, p2, p3 int32, p4 *Locale, p5 int32) bool { return t.Impl_CheckDisplayNameParams_I_I_I_I_Locale_I__Z(t, p0, p1, p2, p3, p4, p5) }

func (t *GregorianCalendar) After_O__Z(p0 any) bool { return t.Impl_After_O__Z(t, p0) }

func (t *GregorianCalendar) Before_O__Z(p0 any) bool { return t.Impl_Before_O__Z(t, p0) }

func (t *GregorianCalendar) Set_I_I_I__V(p0, p1, p2 int32) { t.Impl_Set_I_I_I__V(t, p0, p1, p2) }

func (t *GregorianCalendar) GetDisplayNames_I_I_Locale__Map(p0, p1 int32, p2 *Locale) Map { return t.Impl_GetDisplayNames_I_I_Locale__Map(t, p0, p1, p2) }

func (t *GregorianCalendar) SetTimeInMillis_J__V(p0 int64) { t.Impl_SetTimeInMillis_J__V(t, p0) }

func (t *GregorianCalendar) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *GregorianCalendar) Ref() any { if t == nil { return nil }; return t }

func (t *GregorianCalendar) GetClass__Class() *Class { return GregorianCalendar_class }

func (t *GregorianCalendar) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func GregorianCalendar_InstanceOf(x any) bool { _, ok := x.(*GregorianCalendar); return ok }

func GregorianCalendar_Cast(x any) *GregorianCalendar { if x == nil { return nil }; v, ok := x.(*GregorianCalendar); if !ok { panic(ClassCast(x, GregorianCalendar_class)) }; return v }
