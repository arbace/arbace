//line java_nio_StringCharBuffer.ae:1
package jrt










func StringCharBuffer_New_CharSequence_I_I(p0 CharSequence, p1, p2 int32) *StringCharBuffer { StringCharBuffer_Init(); t := &StringCharBuffer{}; t.Ctor_CharSequence_I_I(p0, p1, p2); return t }
//line :12:1
func (t *StringCharBuffer) Ctor_CharSequence_I_I(s CharSequence, start, end int32) { t.CharBuffer.Ctor_I_I_I_I_MemorySegment(t, -1, start, end, s.Length__I(), nil)

	var n int32 = s.Length__I()
	Objects_CheckFromToIndex_I_I_I__I(start, end, n)
	t.F_str = s
	t.F_isReadOnly = true
}
func (t *StringCharBuffer) Slice__CharBuffer() CharBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32

	if pos <= lim { rem = lim - pos } else { rem = 0 }
	return StringCharBuffer_New_CharSequence_I_I_I_I_I(t.F_str, -1, 0, rem, rem, t.F_offset+pos)
}
func (t *StringCharBuffer) Slice_I_I__CharBuffer(index, length int32) CharBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	return StringCharBuffer_New_CharSequence_I_I_I_I_I(t.F_str, -1, 0, length, length, t.F_offset+index)
}
func StringCharBuffer_New_CharSequence_I_I_I_I_I(p0 CharSequence, p1, p2, p3, p4, p5 int32) *StringCharBuffer { StringCharBuffer_Init(); t := &StringCharBuffer{}; t.Ctor_CharSequence_I_I_I_I_I(p0, p1, p2, p3, p4, p5); return t }
//line :29:1
func (t *StringCharBuffer) Ctor_CharSequence_I_I_I_I_I(s CharSequence, mark, pos, limit, cap_, offset int32) { t.CharBuffer.Ctor_I_I_I_I_C1_I_MemorySegment(t, mark, pos, limit, cap_, nil, offset, nil)

	t.F_str = s
	t.F_isReadOnly = true
}
func (t *StringCharBuffer) Duplicate__CharBuffer() CharBuffer_I {
	var tmp1 CharSequence = t.F_str; return StringCharBuffer_New_CharSequence_I_I_I_I_I(tmp1, t.MarkValue__I(), t.Position__I(), t.Limit__I(), t.Capacity__I(), t.F_offset)
}





func (t *StringCharBuffer) AsReadOnlyBuffer__CharBuffer() CharBuffer_I { return t.Duplicate__CharBuffer() }

func (t *StringCharBuffer) Get__C() uint16 {
	var tmp1 CharSequence = t.F_str; return tmp1.CharAt_I__C(t.NextGetIndex__I() + t.F_offset)
}
func (t *StringCharBuffer) Get_I__C(index int32) uint16 {
	var tmp1 CharSequence = t.F_str; return tmp1.CharAt_I__C(t.CheckIndex_I__I(index) + t.F_offset)
}
func (t *StringCharBuffer) GetUnchecked_I__C(p0 int32) uint16 { panic(A2g_NotTranslated("java.nio.StringCharBuffer.getUnchecked(I)C")) }


func (t *StringCharBuffer) GetArray_I_C1_I_I__CharBuffer(index int32, dst *CharArray, dstOffset, length int32) CharBuffer_I {
	var srcOffset int32 = t.F_offset + index
	t.F_str.GetChars_I_I_C1_I__V(srcOffset, srcOffset+length, dst, dstOffset)
//line :54:1
	return t
}


func (t *StringCharBuffer) Put_C__CharBuffer(c uint16) CharBuffer_I {
	panic(Thrown(ReadOnlyBufferException_New()))
}
func (t *StringCharBuffer) Put_I_C__CharBuffer(index int32, c uint16) CharBuffer_I {
	panic(Thrown(ReadOnlyBufferException_New()))
}
func (t *StringCharBuffer) Compact__CharBuffer() CharBuffer_I {
	panic(Thrown(ReadOnlyBufferException_New()))
}
func (t *StringCharBuffer) IsReadOnly__Z() bool { return true }

func (t *StringCharBuffer) ToString_I_I__String(start, end int32) *String {
	return t.F_str.SubSequence_I_I__CharSequence(start+t.F_offset, end+t.F_offset).ToString__String()
}


func (t *StringCharBuffer) SubSequence_I_I__CharBuffer(start, end int32) CharBuffer_I {
	var tmp1 CharBuffer_I; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var pos int32 = t.Position__I(); var tmp2 CharSequence = t.F_str
			tmp1 = StringCharBuffer_New_CharSequence_I_I_I_I_I(tmp2, -1, pos+t.CheckIndex_I_I__I(start, pos), pos+t.CheckIndex_I_I__I(end, pos), t.Capacity__I(), t.F_offset) }; return nil }()
//line :75:1
	if tmp3 != nil { if IllegalArgumentException_InstanceOf(tmp3) { var x IllegalArgumentException_I = IllegalArgumentException_Cast(tmp3); _ = x







		panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :75:1
			panic(tmp3) } }; return tmp1
}








func (t *StringCharBuffer) IsDirect__Z() bool { return false }

func (t *StringCharBuffer) Order__ByteOrder() *ByteOrder { return ByteOrder_NativeOrder__ByteOrder() }

func (t *StringCharBuffer) CharRegionOrder__ByteOrder() *ByteOrder { panic(A2g_NotTranslated("java.nio.StringCharBuffer.charRegionOrder()Ljava/nio/ByteOrder;")) }

func (t *StringCharBuffer) IsAddressable__Z() bool { return false }

func (t *StringCharBuffer) Equals_O__Z(ob any) bool {
	if any(t) == any(ob) { return true } else {

		var tmp1 any = ob; if CharBuffer_InstanceOf(tmp1) { var that CharBuffer_I = CharBuffer_Cast(tmp1); var thisPos int32 = t.Position__I(); var thisRem int32 = t.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var tmp2 bool; var tmp3 bool




			tmp3 = thisRem < 0; if !tmp3 { tmp3 = !(thisRem == thatRem) }; tmp2 = tmp3; if tmp2 { return false } else {

				return A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world") < 0 } } else {
//line :96:1
					return false
				}
	}
}






func (t *StringCharBuffer) CompareTo_CharBuffer__I(that CharBuffer_I) int32 {
	var thisPos int32 = t.Position__I(); var thisRem int32 = t.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var length int32 = Math_Min_I_I__I(thisRem, thatRem)




	if length < 0 { return -1 } else {

		var i int32; i = A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world")
		if i >= 0 {
			return Character_Compare_C_C__I(t.Get_I__C(thisPos+i), that.Get_I__C(thatPos+i)) } else {

				return thisRem - thatRem
			}
	}
}
type StringCharBuffer struct{ CharBuffer; F_str CharSequence }

var StringCharBuffer_init ClassInit

func StringCharBuffer_Init() { if !StringCharBuffer_init.Done() { StringCharBuffer_init.Run(StringCharBuffer_clinit) } }

func StringCharBuffer_clinit() { CharBuffer_Init() }

func (t *StringCharBuffer) Slice__Buffer() Buffer_I { return t.Slice__CharBuffer() }

func (t *StringCharBuffer) Slice_I_I__Buffer(p0, p1 int32) Buffer_I { return t.Slice_I_I__CharBuffer(p0, p1) }

func (t *StringCharBuffer) Duplicate__Buffer() Buffer_I { return t.Duplicate__CharBuffer() }

func (t *StringCharBuffer) CompareTo_O__I(p0 any) int32 { return t.CompareTo_CharBuffer__I(CharBuffer_Cast(p0)) }

func (t *StringCharBuffer) SubSequence_I_I__CharSequence(p0, p1 int32) CharSequence { return t.SubSequence_I_I__CharBuffer(p0, p1) }

func (t *StringCharBuffer) CharAt_I__C(p0 int32) uint16 { return t.Impl_CharAt_I__C(t, p0) }

func (t *StringCharBuffer) ScaleShifts__I() int32 { return t.Impl_ScaleShifts__I(t) }

func (t *StringCharBuffer) Get_C1_I_I__CharBuffer(p0 *CharArray, p1, p2 int32) CharBuffer_I { return t.Impl_Get_C1_I_I__CharBuffer(t, p0, p1, p2) }

func (t *StringCharBuffer) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return t.Impl_Append_CharSequence_I_I__Appendable(t, p0, p1, p2) }

func (t *StringCharBuffer) Array__O() any { return t.Impl_Array__O(t) }

func (t *StringCharBuffer) Append_CharSequence_I_I__CharBuffer(p0 CharSequence, p1, p2 int32) CharBuffer_I { return t.Impl_Append_CharSequence_I_I__CharBuffer(t, p0, p1, p2) }

func (t *StringCharBuffer) Get_C1__CharBuffer(p0 *CharArray) CharBuffer_I { return t.Impl_Get_C1__CharBuffer(t, p0) }

func (t *StringCharBuffer) Append_CharSequence__CharBuffer(p0 CharSequence) CharBuffer_I { return t.Impl_Append_CharSequence__CharBuffer(t, p0) }

func (t *StringCharBuffer) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *StringCharBuffer) NextGetIndex__I() int32 { return t.Impl_NextGetIndex__I(t) }

func (t *StringCharBuffer) Put_CharBuffer__CharBuffer(p0 CharBuffer_I) CharBuffer_I { return t.Impl_Put_CharBuffer__CharBuffer(t, p0) }

func (t *StringCharBuffer) Clear__Buffer() Buffer_I { return t.Impl_Clear__Buffer(t) }

func (t *StringCharBuffer) Rewind__CharBuffer() CharBuffer_I { return t.Impl_Rewind__CharBuffer(t) }

func (t *StringCharBuffer) Clear__CharBuffer() CharBuffer_I { return t.Impl_Clear__CharBuffer(t) }

func (t *StringCharBuffer) Session__MemorySessionImpl() MemorySessionImpl_I { return t.Impl_Session__MemorySessionImpl(t) }

func (t *StringCharBuffer) Put_I_CharBuffer_I_I__CharBuffer(p0 int32, p1 CharBuffer_I, p2, p3 int32) CharBuffer_I { return t.Impl_Put_I_CharBuffer_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *StringCharBuffer) Put_String__CharBuffer(p0 *String) CharBuffer_I { return t.Impl_Put_String__CharBuffer(t, p0) }

func (t *StringCharBuffer) Array__C1() *CharArray { return t.Impl_Array__C1(t) }

func (t *StringCharBuffer) PutArray_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_PutArray_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *StringCharBuffer) Limit__I() int32 { return t.Impl_Limit__I(t) }

func (t *StringCharBuffer) Base__O() any { return t.Impl_Base__O(t) }

func (t *StringCharBuffer) Reset__CharBuffer() CharBuffer_I { return t.Impl_Reset__CharBuffer(t) }

func (t *StringCharBuffer) Remaining__I() int32 { return t.Impl_Remaining__I(t) }

func (t *StringCharBuffer) NextGetIndex_I__I(p0 int32) int32 { return t.Impl_NextGetIndex_I__I(t, p0) }

func (t *StringCharBuffer) NextPutIndex__I() int32 { return t.Impl_NextPutIndex__I(t) }

func (t *StringCharBuffer) GetChars_I_I_C1_I__V(p0, p1 int32, p2 *CharArray, p3 int32) { t.Impl_GetChars_I_I_C1_I__V(t, p0, p1, p2, p3) }

func (t *StringCharBuffer) DiscardMark__V() { t.Impl_DiscardMark__V(t) }

func (t *StringCharBuffer) Flip__Buffer() Buffer_I { return t.Impl_Flip__Buffer(t) }

func (t *StringCharBuffer) ArrayOffset__I() int32 { return t.Impl_ArrayOffset__I(t) }

func (t *StringCharBuffer) MarkValue__I() int32 { return t.Impl_MarkValue__I(t) }

func (t *StringCharBuffer) Put_C1__CharBuffer(p0 *CharArray) CharBuffer_I { return t.Impl_Put_C1__CharBuffer(t, p0) }

func (t *StringCharBuffer) Position_I__CharBuffer(p0 int32) CharBuffer_I { return t.Impl_Position_I__CharBuffer(t, p0) }

func (t *StringCharBuffer) Rewind__Buffer() Buffer_I { return t.Impl_Rewind__Buffer(t) }

func (t *StringCharBuffer) HasArray__Z() bool { return t.Impl_HasArray__Z(t) }

func (t *StringCharBuffer) Put_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_Put_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *StringCharBuffer) CodePoints__IntStream() IntStream { return CharSequence_CodePoints__IntStream(t) }

func (t *StringCharBuffer) Get_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I { return t.Impl_Get_I_C1__CharBuffer(t, p0, p1) }

func (t *StringCharBuffer) Limit_I__CharBuffer(p0 int32) CharBuffer_I { return t.Impl_Limit_I__CharBuffer(t, p0) }

func (t *StringCharBuffer) Append_C__CharBuffer(p0 uint16) CharBuffer_I { return t.Impl_Append_C__CharBuffer(t, p0) }

func (t *StringCharBuffer) Chars__IntStream() IntStream { return t.Impl_Chars__IntStream(t) }

func (t *StringCharBuffer) Length__I() int32 { return t.Impl_Length__I(t) }

func (t *StringCharBuffer) Position__I() int32 { return t.Impl_Position__I(t) }

func (t *StringCharBuffer) Reset__Buffer() Buffer_I { return t.Impl_Reset__Buffer(t) }

func (t *StringCharBuffer) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return t.Impl_Append_CharSequence__Appendable(t, p0) }

func (t *StringCharBuffer) Append_C__Appendable(p0 uint16) Appendable { return t.Impl_Append_C__Appendable(t, p0) }

func (t *StringCharBuffer) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *StringCharBuffer) CheckIndex_I_I__I(p0, p1 int32) int32 { return t.Impl_CheckIndex_I_I__I(t, p0, p1) }

func (t *StringCharBuffer) CheckSession__V() { t.Impl_CheckSession__V(t) }

func (t *StringCharBuffer) Flip__CharBuffer() CharBuffer_I { return t.Impl_Flip__CharBuffer(t) }

func (t *StringCharBuffer) CheckIndex_I__I(p0 int32) int32 { return t.Impl_CheckIndex_I__I(t, p0) }

func (t *StringCharBuffer) Get_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_Get_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *StringCharBuffer) Position_I__Buffer(p0 int32) Buffer_I { return t.Impl_Position_I__Buffer(t, p0) }

func (t *StringCharBuffer) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *StringCharBuffer) Mark__Buffer() Buffer_I { return t.Impl_Mark__Buffer(t) }

func (t *StringCharBuffer) Mismatch_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Mismatch_CharBuffer__I(t, p0) }

func (t *StringCharBuffer) Put_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I { return t.Impl_Put_I_C1__CharBuffer(t, p0, p1) }

func (t *StringCharBuffer) Put_String_I_I__CharBuffer(p0 *String, p1, p2 int32) CharBuffer_I { return t.Impl_Put_String_I_I__CharBuffer(t, p0, p1, p2) }

func (t *StringCharBuffer) Put_C1_I_I__CharBuffer(p0 *CharArray, p1, p2 int32) CharBuffer_I { return t.Impl_Put_C1_I_I__CharBuffer(t, p0, p1, p2) }

func (t *StringCharBuffer) HasRemaining__Z() bool { return t.Impl_HasRemaining__Z(t) }

func (t *StringCharBuffer) Mark__CharBuffer() CharBuffer_I { return t.Impl_Mark__CharBuffer(t) }

func (t *StringCharBuffer) PutBuffer_I_CharBuffer_I_I__V(p0 int32, p1 CharBuffer_I, p2, p3 int32) { t.Impl_PutBuffer_I_CharBuffer_I_I__V(t, p0, p1, p2, p3) }

func (t *StringCharBuffer) NextPutIndex_I__I(p0 int32) int32 { return t.Impl_NextPutIndex_I__I(t, p0) }

func (t *StringCharBuffer) Limit_I__Buffer(p0 int32) Buffer_I { return t.Impl_Limit_I__Buffer(t, p0) }

func (t *StringCharBuffer) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *StringCharBuffer) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *StringCharBuffer) Ref() any { if t == nil { return nil }; return t }

func (t *StringCharBuffer) GetClass__Class() *Class { return StringCharBuffer_class }

func (t *StringCharBuffer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringCharBuffer) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringCharBuffer_InstanceOf(x any) bool { _, ok := x.(*StringCharBuffer); return ok }

func StringCharBuffer_Cast(x any) *StringCharBuffer { if x == nil { return nil }; v, ok := x.(*StringCharBuffer); if !ok { panic(ClassCast(x, StringCharBuffer_class)) }; return v }
