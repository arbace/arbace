//line java_time_temporal_TemporalQuery.ae:1
package jrt






type TemporalQuery interface{ Object_I; Is_TemporalQuery(); QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any }

func TemporalQuery_InstanceOf(x any) bool { _, ok := x.(TemporalQuery); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalQuery_class) } }; return ok }

func TemporalQuery_Cast(x any) TemporalQuery { if x == nil { return nil }; v, ok := x.(TemporalQuery); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalQuery_class) } }; if !ok { panic(ClassCast(x, TemporalQuery_class)) }; return v }
