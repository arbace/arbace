//line java_lang_reflect_InvocationTargetException.ae:1
package jrt










func InvocationTargetException_New() *InvocationTargetException { t := &InvocationTargetException{}; t.Ctor(); return t }
//line :12:1
func (t *InvocationTargetException) Ctor() { t.ReflectiveOperationException.Ctor_Throwable(t, nil)

	t.F_target = nil
}
func InvocationTargetException_New_Throwable(p0 Throwable_I) *InvocationTargetException { t := &InvocationTargetException{}; t.Ctor_Throwable(p0); return t }
//line :16:1
func (t *InvocationTargetException) Ctor_Throwable(target Throwable_I) { t.ReflectiveOperationException.Ctor_Throwable(t, nil)

	t.F_target = target
}
func InvocationTargetException_New_Throwable_String(p0 Throwable_I, p1 *String) *InvocationTargetException { t := &InvocationTargetException{}; t.Ctor_Throwable_String(p0, p1); return t }
//line :20:1
func (t *InvocationTargetException) Ctor_Throwable_String(target Throwable_I, s *String) { t.ReflectiveOperationException.Ctor_String_Throwable(t, s, nil)

	t.F_target = target
}
func (t *InvocationTargetException) GetTargetException__Throwable() Throwable_I { return t.F_target }

func (t *InvocationTargetException) GetCause__Throwable() Throwable_I { return t.F_target }



type InvocationTargetException struct{ ReflectiveOperationException; F_target Throwable_I }

const InvocationTargetException_serialVersionUID int64 = 4085088731926701167

func (t *InvocationTargetException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvocationTargetException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvocationTargetException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InvocationTargetException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvocationTargetException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvocationTargetException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvocationTargetException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvocationTargetException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvocationTargetException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvocationTargetException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvocationTargetException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvocationTargetException) Ref() any { if t == nil { return nil }; return t }

func (t *InvocationTargetException) GetClass__Class() *Class { return InvocationTargetException_class }

func (t *InvocationTargetException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvocationTargetException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvocationTargetException_InstanceOf(x any) bool { _, ok := x.(*InvocationTargetException); return ok }

func InvocationTargetException_Cast(x any) *InvocationTargetException { if x == nil { return nil }; v, ok := x.(*InvocationTargetException); if !ok { panic(ClassCast(x, InvocationTargetException_class)) }; return v }
