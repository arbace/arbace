//line files.ae:1
package jrt

import (
	"errors"
	"io"
	"io/fs"
	"os"
	"sync"
	"unsafe"
)
// byteView is n bytes of b from off as Go's []byte (shared, not copied).
//line :11:1
func byteView(b /*line :12:1*/*ByteArray, off, n int32) []byte {
	if n == 0 {
		return nil }
	return unsafe.Slice((*byte)(unsafe.Pointer(&b.A[off])), n)
}
var filesMu sync.Mutex
var openFiles map[int32]HostFile = make(map[int32]HostFile)
var nextFile int32 = 3
// hostFile is the open file of handle h (> 2), or an IOException.
func hostFile(h int32) HostFile {

	filesMu.Lock()
	f := openFiles[h]
	filesMu.Unlock()
	if f == nil {
		panic(IOException_New_String(Str("Stream Closed")))
	}; return f }
// ioError is the IOException of a host error.
func ioError(err error) Throwable_I {

	return IOException_New_String(Str(err.Error())) }
// fileErrorText is the reason the JVM's FileNotFoundException gives in parentheses.
func fileErrorText(err error) string {


	if
		errors.Is(err, fs.ErrNotExist) { return "No such file or directory"
		} else if errors.Is(err, fs.ErrPermission) { return "Permission denied"
		} else if errors.Is(err, os.ErrExist) { return "File exists" }
	pe, ok := err.(*fs.PathError)
	if ok {
		return pe.Err.Error() }
	return err.Error() }
// HostFiles_Open0_String_I_String1__I_native opens path for reading (mode 0), writing (1:
// created or truncated) or appending (2): its handle, or -1 with the reason in error[0].
//line :46:1
func HostFiles_Open0_String_I_String1__I_native(path /*line :49:1*/*String, mode int32, error *RefArray) int32 {
	flag := os.O_RDONLY
	switch mode {
	case 1: flag = os.O_WRONLY | os.O_CREATE | os.O_TRUNC
	case 2: flag = os.O_WRONLY | os.O_CREATE | os.O_APPEND}
	name := path.String()
	if mode == 0 {

		fi, err := CurrentHost().Stat(name)
		if err == nil && fi.IsDir {
			error.A[0] = Str("Is a directory")
			return -1 } }
	f, err := CurrentHost().Open(name, flag, 438)
	if err != nil {
		error.A[0] = Str(fileErrorText(err))
		return -1 }
	filesMu.Lock()
	defer filesMu.Unlock()
	h := nextFile
	nextFile++
	openFiles[h] = f
	return h }
// HostFiles_Close0_I__V_native closes handle h (> 2).
func HostFiles_Close0_I__V_native(h int32) {


	f := hostFile(h)
	filesMu.Lock()
	delete(openFiles, h)
	filesMu.Unlock()
	err := f.Close()
	if err != nil {
		panic(ioError(err)) } }
// HostFiles_Write0_I_B1_I_I__V_native writes len bytes of b from off to handle h.
func HostFiles_Write0_I_B1_I_I__V_native(h int32, b /*line :85:1*/*ByteArray, off, n int32) {
	p := byteView(b, off, n)
	var w io.Writer = nil
	if h == 1 { w = Stdout
	} else if h == 2 { w = Stderr
	} else if h == 0 { panic(IOException_New_String(Str("Bad file descriptor"))) } else {
		w = hostFile(h) }
	_, err := w.Write(p)
	if err != nil {
		panic(ioError(err)) } }
// HostFiles_Read0_I_B1_I_I__I_native reads up to len (> 0) bytes of handle h into b at off:
// the count, or -1 at the end.
//line :96:1
func HostFiles_Read0_I_B1_I_I__I_native(h int32, b /*line :99:1*/*ByteArray, off, n int32) int32 {
	p := byteView(b, off, n)
	var r io.Reader = nil
	if h == 0 { r = Stdin
	} else if h == 1 || h == 2 { panic(IOException_New_String(Str("Bad file descriptor"))) } else {
		r = hostFile(h) }
	for {
		k, err := r.Read(p)
		if k > 0 {
			return int32(k) }
		if errors.Is(err, io.EOF) {
			return -1 }
		if err != nil {
			panic(ioError(err)) } } }
// HostFiles_Available0_I__I_native is what handle h gives without blocking: a file's bytes
// after its position, 0 for the standard input.
//line :114:1
func HostFiles_Available0_I__I_native(h int32) int32 {



	if h <= 2 {
		return 0 }
	{ f := hostFile(h)
		av, isAv := f.(interface{ Available() (int, error) })

		if isAv {
			k, aerr := av.Available()
			if aerr != nil {
				return 0 }
			return int32(k) } }
	f := hostFile(h)
	cur, err := f.Seek(0, io.SeekCurrent)
	if err != nil {
		return 0 }
	end, err2 := f.Seek(0, io.SeekEnd)
	if err2 != nil {
		return 0 }
	f.Seek(cur, io.SeekStart)
	k := end - cur
	if k < 0 { return 0
	} else if k > 2147483647 { return 2147483647 }
	return int32(k) }
// HostFiles_Skip0_I_J__J_native skips up to n (> 0) bytes of handle h: a file seeks (past its
// end, as the JVM's lseek), the standard input reads them.
//line :141:1
func HostFiles_Skip0_I_J__J_native(h int32, n int64) int64 {



	if h > 2 {
		f := hostFile(h)
		cur, err := f.Seek(0, io.SeekCurrent)
		if err != nil {
			panic(ioError(err)) }
		pos, err2 := f.Seek(n, io.SeekCurrent)
		if err2 != nil {
			panic(ioError(err2)) }
		return pos - cur }
	buf := make([]byte, 8192)
	var done int64 = 0
	for done < n {
		k := int64(len(buf))
		if k > n-done {
			k = n - done }
		r, err := Stdin.Read(buf[0:k])
		done += int64(r)
		if err != nil {
			break
		}
	}
	return done
}
