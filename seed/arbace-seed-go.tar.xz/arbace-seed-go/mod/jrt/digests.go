//line digests.ae:1
package jrt

import (
	"encoding"
	"encoding/binary"
	"io"

	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"

	"crypto/sha3"
)


// goDigest is a Go digest whose state can be set and read.
type goDigest /*line :19:1*/ interface{ encoding.BinaryMarshaler; encoding.BinaryUnmarshaler; io.Writer }
// goBlocks runs h's block function on data (whole blocks) from the chaining state words, the
// state's bytes at offset off of h's marshaled state; it returns the new state's bytes.
//line :21:1
func goBlocks(h goDigest, off int, words, data /*line :24:1*/[]byte) []byte {
	m, err := h.MarshalBinary()
	if err != nil {
		panic(err) }
	copy(m[off:], words)
	for i, _ := range m[off+len(words):] {
		m[off+len(words)+i] = 0 }
	{ err2 := h.UnmarshalBinary(m)
		if err2 != nil {
			panic(err2) } }
	h.Write(data)
	m2, err3 := h.MarshalBinary()
	if err3 != nil {
		panic(err3) }
	return m2[off : off+len(words)] }
// intBlocks: goBlocks over an int[] chaining state, big-endian words.
func intBlocks(h goDigest, state /*line :41:1*/*IntArray, b *ByteArray, ofs, n int32) {
	s := state.A
	words := make([]byte, 4*len(s))
	for i, x := range s {
		binary.BigEndian.PutUint32(words[4*i:], uint32(x)) }
	out := goBlocks(h, 4, words, byteView(b, ofs, n))
	for i, _ := range s {
		s[i] = int32(binary.BigEndian.Uint32(out[4*i:])) } }
// MD5's blocks by crypto/md5.
func MD5_GoBlocks_I1_B1_I_I__V_native(state /*line :51:1*/*IntArray, b *ByteArray, ofs, n int32) {
	intBlocks(md5.New().(goDigest), state, b, ofs, n) }
// SHA-1's blocks by crypto/sha1.
func SHA_GoBlocks_I1_B1_I_I__V_native(state /*line :55:1*/*IntArray, b *ByteArray, ofs, n int32) {
	intBlocks(sha1.New().(goDigest), state, b, ofs, n) }
// SHA-224's and SHA-256's blocks by crypto/sha256 (one block function; the state is the
// algorithm's).
//line :58:1
func SHA2_GoBlocks_I1_B1_I_I__V_native(state /*line :61:1*/*IntArray, b *ByteArray, ofs, n int32) {
	intBlocks(sha256.New().(goDigest), state, b, ofs, n) }
// SHA-384's, SHA-512's, SHA-512/224's and SHA-512/256's blocks by crypto/sha512.
func SHA5_GoBlocks_J1_B1_I_I__V_native(state /*line :66:1*/*LongArray, b *ByteArray, ofs, n int32) {
	s := state.A
	words := make([]byte, 8*len(s))
	for i, x := range s {
		binary.BigEndian.PutUint64(words[8*i:], uint64(x)) }
	out := goBlocks(sha512.New().(goDigest), 4, words, byteView(b, ofs, n))
	for i, _ := range s {
		s[i] = int64(binary.BigEndian.Uint64(out[8*i:])) } }
// SHA-3's and SHAKE's blocks by crypto/sha3, for a rate Go has a digest of (false otherwise):
// the lanes little-endian, the Keccak state after the magic and the rate byte.
//line :75:1
func SHA3_GoBlocks_J1_I_B1_I_I__Z_native(state /*line :78:1*/*LongArray, rate int32, b *ByteArray, ofs, n int32) bool {
	var h goDigest = nil
	switch rate {
	case 144: h = sha3.New224()
	case 136: h = sha3.New256()
	case 104: h = sha3.New384()
	case 72: h = sha3.New512()
	case 168: h = sha3.NewSHAKE128()
	default: return false}
	{ s := state.A
		words := make([]byte, 8*len(s))
		for i, x := range s {
			binary.LittleEndian.PutUint64(words[8*i:], uint64(x)) }
		out := goBlocks(h, 5, words, byteView(b, ofs, n))
		for i, _ := range s {
			s[i] = int64(binary.LittleEndian.Uint64(out[8*i:]))
		}
	}
	return true
}
