//line java_text_AttributedCharacterIterator.ae:1
package jrt
















func AttributedCharacterIterator_Attribute_New_String(p0 *String) *AttributedCharacterIterator_Attribute { AttributedCharacterIterator_Attribute_Init(); t := &AttributedCharacterIterator_Attribute{}; t.Ctor_String(t, p0); return t }
//line :18:1
func (t *AttributedCharacterIterator_Attribute) Ctor_String(this AttributedCharacterIterator_Attribute_I, name *String) {
	t.F_name = name
	if this.GetClass__Class() == AttributedCharacterIterator_Attribute_class { AttributedCharacterIterator_Attribute_instanceMap.Put_O_O__O(name.Ref(), this)
	} }
func (t *AttributedCharacterIterator_Attribute) Impl_Equals_O__Z(this AttributedCharacterIterator_Attribute_I, obj any) bool { return this == obj }

func (t *AttributedCharacterIterator_Attribute) Impl_HashCode__I(this AttributedCharacterIterator_Attribute_I) int32 { return IdentityHash(this) }

func (t *AttributedCharacterIterator_Attribute) Impl_ToString__String(this AttributedCharacterIterator_Attribute_I) *String {
	return Concat(NN(this.GetClass__Class()).GetName__String(), Lit_1695, t.F_name, Lit_1176)
}
func (t *AttributedCharacterIterator_Attribute) Impl_GetName__String(this AttributedCharacterIterator_Attribute_I) *String { panic(A2g_NotTranslated("java.text.AttributedCharacterIterator$Attribute.getName()Ljava/lang/String;")) }

func (t *AttributedCharacterIterator_Attribute) Impl_ReadResolve__O(this AttributedCharacterIterator_Attribute_I) any { panic(A2g_NotTranslated("java.text.AttributedCharacterIterator$Attribute.readResolve()Ljava/lang/Object;")) }



type AttributedCharacterIterator interface{ Object_I; CharacterIterator; Cloneable; Is_AttributedCharacterIterator(); GetRunStart__I() int32; GetRunStart_AttributedCharacterIterator_Attribute__I(p0 AttributedCharacterIterator_Attribute_I) int32; GetRunStart_Set__I(p0 Set) int32; GetRunLimit__I() int32; GetRunLimit_AttributedCharacterIterator_Attribute__I(p0 AttributedCharacterIterator_Attribute_I) int32; GetRunLimit_Set__I(p0 Set) int32; GetAttributes__Map() Map; GetAttribute_AttributedCharacterIterator_Attribute__O(p0 AttributedCharacterIterator_Attribute_I) any; GetAllAttributeKeys__Set() Set }

func AttributedCharacterIterator_InstanceOf(x any) bool { _, ok := x.(AttributedCharacterIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AttributedCharacterIterator_class) } }; return ok }

func AttributedCharacterIterator_Cast(x any) AttributedCharacterIterator { if x == nil { return nil }; v, ok := x.(AttributedCharacterIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AttributedCharacterIterator_class) } }; if !ok { panic(ClassCast(x, AttributedCharacterIterator_class)) }; return v }



type AttributedCharacterIterator_Attribute struct{ Object; F_name *String }

type AttributedCharacterIterator_Attribute_I interface{ Object_I; Serializable; Self_AttributedCharacterIterator_Attribute() *AttributedCharacterIterator_Attribute; GetName__String() *String; ReadResolve__O() any }

func (t *AttributedCharacterIterator_Attribute) Self_AttributedCharacterIterator_Attribute() *AttributedCharacterIterator_Attribute { return t }

func (t *AttributedCharacterIterator_Attribute) Is_Serializable() {}

var AttributedCharacterIterator_Attribute_instanceMap Map

var AttributedCharacterIterator_Attribute_LANGUAGE AttributedCharacterIterator_Attribute_I

var AttributedCharacterIterator_Attribute_READING AttributedCharacterIterator_Attribute_I

var AttributedCharacterIterator_Attribute_INPUT_METHOD_SEGMENT AttributedCharacterIterator_Attribute_I

const AttributedCharacterIterator_Attribute_serialVersionUID int64 = -9142742483513960612

var AttributedCharacterIterator_Attribute_init ClassInit

func AttributedCharacterIterator_Attribute_Init() { if !AttributedCharacterIterator_Attribute_init.Done() { AttributedCharacterIterator_Attribute_init.Run(AttributedCharacterIterator_Attribute_clinit) } }

func AttributedCharacterIterator_Attribute_clinit() { AttributedCharacterIterator_Attribute_instanceMap = HashMap_New_I(7); AttributedCharacterIterator_Attribute_LANGUAGE = AttributedCharacterIterator_Attribute_New_String(Lit_1692); AttributedCharacterIterator_Attribute_READING = AttributedCharacterIterator_Attribute_New_String(Lit_1693); AttributedCharacterIterator_Attribute_INPUT_METHOD_SEGMENT = AttributedCharacterIterator_Attribute_New_String(Lit_1694) }

func (t *AttributedCharacterIterator_Attribute) GetName__String() *String { return t.Impl_GetName__String(t) }

func (t *AttributedCharacterIterator_Attribute) ReadResolve__O() any { return t.Impl_ReadResolve__O(t) }

func (t *AttributedCharacterIterator_Attribute) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *AttributedCharacterIterator_Attribute) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *AttributedCharacterIterator_Attribute) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AttributedCharacterIterator_Attribute) Ref() any { if t == nil { return nil }; return t }

func (t *AttributedCharacterIterator_Attribute) GetClass__Class() *Class { return AttributedCharacterIterator_Attribute_class }

func (t *AttributedCharacterIterator_Attribute) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AttributedCharacterIterator_Attribute) CloneShallow() any { panic(CloneNotSupported(t)) }

func AttributedCharacterIterator_Attribute_InstanceOf(x any) bool { _, ok := x.(AttributedCharacterIterator_Attribute_I); return ok }

func AttributedCharacterIterator_Attribute_Cast(x any) AttributedCharacterIterator_Attribute_I { if x == nil { return nil }; v, ok := x.(AttributedCharacterIterator_Attribute_I); if !ok { panic(ClassCast(x, AttributedCharacterIterator_Attribute_class)) }; return v }
