//line java_util_TimSort.ae:1
package jrt
































func TimSort_New_O1_Comparator_O1_I_I(p0 *RefArray, p1 Comparator, p2 *RefArray, p3, p4 int32) *TimSort { TimSort_Init(); t := &TimSort{}; t.Ctor_O1_Comparator_O1_I_I(p0, p1, p2, p3, p4); return t }
//line :34:1
func (t *TimSort) Ctor_O1_Comparator_O1_I_I(a *RefArray, c Comparator, work *RefArray, workBase, workLen int32) { t.F_minGallop = 7; t.F_stackSize = 0

	t.F_a = a
	t.F_c = c
	var len_ int32 = int32(len(a.A)); var tlen int32
	if len_ < 512 {
		tlen = int32(uint32(len_) >> 1) } else {
//line :39:1
			tlen = 256
		}

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = work == nil; if !tmp3 { tmp3 = workLen < tlen }; tmp2 = tmp3; if !tmp2 {
		tmp2 = workBase+tlen > int32(len(work.A)) }
//line :42:1
	tmp1 = tmp2; if tmp1 {

		var newArray *RefArray = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), tlen), Object_class.ArrayClass())

		t.F_tmp = newArray
		t.F_tmpBase = 0
		t.F_tmpLen = tlen } else {
			t.F_tmp = work; t.F_tmpBase = workBase; t.F_tmpLen = workLen }
	var stackLen int32; if len_ < 120 { stackLen = 5 } else { if len_ < 1542 { stackLen = 10 } else { if len_ < 119151 { stackLen = 24 } else { stackLen = 49 } } }
	t.F_runBase = NewIntArray(stackLen)
	t.F_runLen = NewIntArray(stackLen)
}
func TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a *RefArray, lo, hi int32, c Comparator, work *RefArray, workBase, workLen int32) { TimSort_Init()


	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = !(c == nil); if tmp5 { tmp5 = !(a == nil) }; tmp4 = tmp5; if tmp4 { tmp4 = lo >= 0 }; tmp3 = tmp4; if tmp3 { tmp3 = lo <= hi }; tmp2 = tmp3; if tmp2 {
		tmp2 = hi <= int32(len(a.A)) }
//line :57:1
	tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New()))
	}
	var nRemaining int32 = hi - lo
	if nRemaining < 2 { } else {
		if nRemaining < 32 {
			var initRunLen int32 = TimSort_CountRunAndMakeAscending_O1_I_I_Comparator__I(a, lo, hi, c)
			TimSort_BinarySort_O1_I_I_I_Comparator__V(a, lo, hi, lo+initRunLen, c) } else {
				var ts *TimSort = TimSort_New_O1_Comparator_O1_I_I(a, c, work, workBase, workLen); var minRun int32 = TimSort_MinRunLength_I__I(nRemaining)

			L1: for {
				var runLen int32 = TimSort_CountRunAndMakeAscending_O1_I_I_Comparator__I(a, lo, hi, c)
				if runLen < minRun {
					var force int32; if nRemaining <= minRun { force = nRemaining } else { force = minRun }
					TimSort_BinarySort_O1_I_I_I_Comparator__V(a, lo, lo+force, lo+runLen, c)




					runLen = force }
				NN(ts).PushRun_I_I__V(lo, runLen)
				NN(ts).MergeCollapse__V()
				lo = lo + runLen
				nRemaining = nRemaining - runLen
				if nRemaining == 0 { } else { continue L1 }
//line :66:1
				break L1
			}













				if !A2g_AssertionsDisabled && !(lo == hi) { panic(Thrown(AssertionError_New())) }
				NN(ts).MergeForceCollapse__V()
				if !A2g_AssertionsDisabled && !(ts.F_stackSize == 1) { panic(Thrown(AssertionError_New()))
				} } } }
func TimSort_BinarySort_O1_I_I_I_Comparator__V(a *RefArray, lo, hi, start int32, c Comparator) { TimSort_Init()


	var tmp1 bool; var tmp2 bool; tmp2 = lo <= start; if tmp2 { tmp2 = start <= hi }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	if start == lo { start = start + 1 }
L1: for { if start < hi {
	var pivot any = a.A[start]
	var left int32 = lo
	var right int32 = start
	if !A2g_AssertionsDisabled && !(left <= right) { panic(Thrown(AssertionError_New())) }
L2: for { if left < right {
	var mid int32 = int32(uint32(left+right) >> 1)
	if c.Compare_O_O__I(pivot, a.A[mid]) < 0 {
		right = mid } else {
			left = mid + 1 }
//line :95:1
	continue L2 }; break L2
}



	if !A2g_AssertionsDisabled && !(left == right) { panic(Thrown(AssertionError_New())) }
	var n int32 = start - left
	switch n { case 2:


		a.Store(left+2, a.A[left+1])
		a.Store(left+1, a.A[left]); case 1:
		a.Store(left+1, a.A[left]); default:
		System_Arraycopy_O_I_O_I_I__V(a.Ref(), left, a.Ref(), left+1, n)}
	a.Store(left, pivot)
	start = start + 1
//line :90:1
	continue L1 }; break L1
}
}



















func TimSort_CountRunAndMakeAscending_O1_I_I_Comparator__I(a *RefArray, lo, hi int32, c Comparator) int32 { TimSort_Init()

	if !A2g_AssertionsDisabled && !(lo < hi) { panic(Thrown(AssertionError_New())) }
	var runHi int32 = lo + 1
	if runHi == hi { return 1 } else {


		var tmp1 int32
		var old_1 int32 = runHi
		runHi = runHi + 1; tmp1 = old_1
//line :119:1
		var tmp2 any = a.A[tmp1]; if c.Compare_O_O__I(tmp2, a.A[lo]) < 0 {





		L1: for { var tmp3 bool; var tmp4 bool; tmp4 = runHi < hi; if tmp4 {
			var tmp5 any = a.A[runHi]; tmp4 = c.Compare_O_O__I(tmp5, a.A[runHi-1]) < 0 }
//line :125:1
			tmp3 = tmp4; if tmp3 {




				runHi = runHi + 1
//line :125:1
				continue L1 }; break L1
		}




			TimSort_ReverseRange_O1_I_I__V(a, lo, runHi) } else {
			L2: for { var tmp6 bool; var tmp7 bool; tmp7 = runHi < hi; if tmp7 {
				var tmp8 any = a.A[runHi]; tmp7 = c.Compare_O_O__I(tmp8, a.A[runHi-1]) >= 0 }
//line :132:1
				tmp6 = tmp7; if tmp6 {




					runHi = runHi + 1
//line :132:1
					continue L2 }; break L2
			}
			}



		return runHi - lo
	} }
func TimSort_ReverseRange_O1_I_I__V(a *RefArray, lo, hi int32) { TimSort_Init()
	hi = hi - 1
L1: for { if lo < hi {
	var t_ any = a.A[lo]
	a.Store(lo, a.A[hi])
	lo = lo + 1
	a.Store(hi, t_)
	hi = hi - 1
//line :142:1
	continue L1 }; break L1
}
}




func TimSort_MinRunLength_I__I(n int32) int32 { TimSort_Init()
	if !A2g_AssertionsDisabled && !(n >= 0) { panic(Thrown(AssertionError_New())) }
	var r int32 = 0
L1: for { if n >= 32 {
	r = r | n&1
	n = n >> 1
//line :152:1
	continue L1 }; break L1
}

	return n + r
}
func (t *TimSort) PushRun_I_I__V(runBase, runLen int32) {
	t.F_runBase.A[t.F_stackSize] = runBase
	t.F_runLen.A[t.F_stackSize] = runLen
	t.F_stackSize = t.F_stackSize + 1
}
func (t *TimSort) MergeCollapse__V() {
L1: for { if t.F_stackSize > 1 {
	var n int32 = t.F_stackSize - 2; var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = n > 0; if tmp3 {
		var tmp4 int32 = t.F_runLen.A[n-1]; var tmp5 int32 = t.F_runLen.A[n]; tmp3 = tmp4 <= tmp5+t.F_runLen.A[n+1] }
//line :166:1
	tmp2 = tmp3; if !tmp2 {


		var tmp6 bool; tmp6 = n > 1; if tmp6 {
			var tmp7 int32 = t.F_runLen.A[n-2]; var tmp8 int32 = t.F_runLen.A[n]; tmp6 = tmp7 <= tmp8+t.F_runLen.A[n-1] }
//line :169:1
		tmp2 = tmp6 }
//line :166:1
	tmp1 = tmp2
//line :165:1
	if tmp1 {







		var tmp9 int32 = t.F_runLen.A[n-1]; if tmp9 < t.F_runLen.A[n+1] {

			n = n - 1 } } else {
//line :165:1
				var tmp10 bool; var tmp11 bool










				tmp11 = n < 0; if !tmp11 { var tmp12 int32 = t.F_runLen.A[n]; tmp11 = tmp12 > t.F_runLen.A[n+1] }; tmp10 = tmp11
//line :165:1
				if tmp10 {










					break L1 } }
	t.MergeAt_I__V(n)
//line :163:1
	continue L1 }; break L1
}
}













func (t *TimSort) MergeForceCollapse__V() {
L1: for { if t.F_stackSize > 1 {
	var n int32 = t.F_stackSize - 2; var tmp1 bool; var tmp2 bool
	tmp2 = n > 0; if tmp2 {
		var tmp3 int32 = t.F_runLen.A[n-1]; tmp2 = tmp3 < t.F_runLen.A[n+1] }
//line :182:1
	tmp1 = tmp2; if tmp1 {


		n = n - 1 }
	t.MergeAt_I__V(n)
//line :180:1
	continue L1 }; break L1
}
}





func (t *TimSort) MergeAt_I__V(i int32) {
	if !A2g_AssertionsDisabled && !(t.F_stackSize >= 2) { panic(Thrown(AssertionError_New())) }
	if !A2g_AssertionsDisabled && !(i >= 0) { panic(Thrown(AssertionError_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = i == t.F_stackSize-2; if !tmp2 {
		tmp2 = i == t.F_stackSize-3 }
//line :191:1
	tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New()))
	}
	var base1 int32 = t.F_runBase.A[i]; var len1 int32 = t.F_runLen.A[i]; var base2 int32 = t.F_runBase.A[i+1]; var len2 int32 = t.F_runLen.A[i+1]; var tmp3 bool; var tmp4 bool



	tmp4 = len1 > 0; if tmp4 { tmp4 = len2 > 0 }; tmp3 = tmp4; if !A2g_AssertionsDisabled && !tmp3 { panic(Thrown(AssertionError_New())) }
	if !A2g_AssertionsDisabled && !(base1+len1 == base2) { panic(Thrown(AssertionError_New())) }
	t.F_runLen.A[i] = len1 + len2
	if i == t.F_stackSize-3 {
		var tmp5 *IntArray = t.F_runBase; tmp5.A[i+1] = t.F_runBase.A[i+2]
		var tmp6 *IntArray = t.F_runLen; tmp6.A[i+1] = t.F_runLen.A[i+2] }
	t.F_stackSize = t.F_stackSize - 1
	var k int32 = TimSort_GallopRight_O_O1_I_I_I_Comparator__I(t.F_a.A[base2], t.F_a, base1, len1, 0, t.F_c)
	if !A2g_AssertionsDisabled && !(k >= 0) { panic(Thrown(AssertionError_New())) }
	base1 = base1 + k
	len1 = len1 - k
	if len1 == 0 { } else {
		len2 = TimSort_GallopLeft_O_O1_I_I_I_Comparator__I(t.F_a.A[base1+len1-1], t.F_a, base2, len2, len2-1, t.F_c)







		if !A2g_AssertionsDisabled && !(len2 >= 0) { panic(Thrown(AssertionError_New())) }
		if len2 == 0 { } else {
			if len1 <= len2 {
				t.MergeLo_I_I_I_I__V(base1, len1, base2, len2) } else {
					t.MergeHi_I_I_I_I__V(base1, len1, base2, len2)
				} } } }
func TimSort_GallopLeft_O_O1_I_I_I_Comparator__I(key any, a *RefArray, base, len_, hint int32, c Comparator) int32 { TimSort_Init()


	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len_ > 0; if tmp3 { tmp3 = hint >= 0 }; tmp2 = tmp3; if tmp2 { tmp2 = hint < len_ }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var lastOfs int32 = 0
	var ofs int32 = 1
	if c.Compare_O_O__I(key, a.A[base+hint]) > 0 {
		var maxOfs int32 = len_ - hint
	L1: for { var tmp4 bool; var tmp5 bool; tmp5 = ofs < maxOfs; if tmp5 {
		tmp5 = c.Compare_O_O__I(key, a.A[base+hint+ofs]) > 0 }
//line :231:1
		tmp4 = tmp5; if tmp4 {




			lastOfs = ofs
			ofs = ofs<<1 + 1
			if ofs <= 0 { ofs = maxOfs }
//line :231:1
			continue L1 }; break L1
	}






		if ofs > maxOfs { ofs = maxOfs }
		lastOfs = lastOfs + hint
		ofs = ofs + hint } else {
			var maxOfs_2 int32 = hint + 1
		L2: for { var tmp6 bool; var tmp7 bool; tmp7 = ofs < maxOfs_2; if tmp7 {
			tmp7 = c.Compare_O_O__I(key, a.A[base+hint-ofs]) <= 0 }
//line :243:1
			tmp6 = tmp7; if tmp6 {







				lastOfs = ofs
				ofs = ofs<<1 + 1
				if ofs <= 0 { ofs = maxOfs_2 }
//line :243:1
				continue L2 }; break L2
		}









			if ofs > maxOfs_2 { ofs = maxOfs_2 }
			var tmp int32 = lastOfs
			lastOfs = hint - ofs
			ofs = hint - tmp }
	var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = -1 <= lastOfs; if tmp10 { tmp10 = lastOfs < ofs }; tmp9 = tmp10; if tmp9 { tmp9 = ofs <= len_ }; tmp8 = tmp9; if !A2g_AssertionsDisabled && !tmp8 { panic(Thrown(AssertionError_New())) }
	lastOfs = lastOfs + 1
L3: for { if lastOfs < ofs {
	var m int32 = lastOfs + int32(uint32(ofs-lastOfs)>>1)



	if c.Compare_O_O__I(key, a.A[base+m]) > 0 {
		lastOfs = m + 1 } else {
			ofs = m }
//line :260:1
	continue L3 }; break L3
}






	if !A2g_AssertionsDisabled && !(lastOfs == ofs) { panic(Thrown(AssertionError_New())) }
//line :227:1
	return ofs
}










































func TimSort_GallopRight_O_O1_I_I_I_Comparator__I(key any, a *RefArray, base, len_, hint int32, c Comparator) int32 { TimSort_Init()


	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len_ > 0; if tmp3 { tmp3 = hint >= 0 }; tmp2 = tmp3; if tmp2 { tmp2 = hint < len_ }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var ofs int32 = 1
	var lastOfs int32 = 0
	if c.Compare_O_O__I(key, a.A[base+hint]) < 0 {
		var maxOfs int32 = hint + 1
	L1: for { var tmp4 bool; var tmp5 bool; tmp5 = ofs < maxOfs; if tmp5 {
		tmp5 = c.Compare_O_O__I(key, a.A[base+hint-ofs]) < 0 }
//line :279:1
		tmp4 = tmp5; if tmp4 {







			lastOfs = ofs
			ofs = ofs<<1 + 1
			if ofs <= 0 { ofs = maxOfs }
//line :279:1
			continue L1 }; break L1
	}









		if ofs > maxOfs { ofs = maxOfs }
		var tmp int32 = lastOfs
		lastOfs = hint - ofs
		ofs = hint - tmp } else {
			var maxOfs_2 int32 = len_ - hint
		L2: for { var tmp6 bool; var tmp7 bool; tmp7 = ofs < maxOfs_2; if tmp7 {
			tmp7 = c.Compare_O_O__I(key, a.A[base+hint+ofs]) >= 0 }
//line :295:1
			tmp6 = tmp7; if tmp6 {





				lastOfs = ofs
				ofs = ofs<<1 + 1
				if ofs <= 0 { ofs = maxOfs_2 }
//line :295:1
				continue L2 }; break L2
		}







			if ofs > maxOfs_2 { ofs = maxOfs_2 }
			lastOfs = lastOfs + hint
			ofs = ofs + hint }
	var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = -1 <= lastOfs; if tmp10 { tmp10 = lastOfs < ofs }; tmp9 = tmp10; if tmp9 { tmp9 = ofs <= len_ }; tmp8 = tmp9; if !A2g_AssertionsDisabled && !tmp8 { panic(Thrown(AssertionError_New())) }
	lastOfs = lastOfs + 1
L3: for { if lastOfs < ofs {
	var m int32 = lastOfs + int32(uint32(ofs-lastOfs)>>1)



	if c.Compare_O_O__I(key, a.A[base+m]) < 0 {
		ofs = m } else {
			lastOfs = m + 1 }
//line :309:1
	continue L3 }; break L3
}






	if !A2g_AssertionsDisabled && !(lastOfs == ofs) { panic(Thrown(AssertionError_New())) }
//line :275:1
	return ofs
}











































func (t *TimSort) MergeLo_I_I_I_I__V(base1, len1, base2, len2 int32) {

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len1 > 0; if tmp3 { tmp3 = len2 > 0 }; tmp2 = tmp3; if tmp2 { tmp2 = base1+len1 == base2 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var a *RefArray = t.F_a; var tmp *RefArray = t.EnsureCapacity_I__O1(len1); var cursor1 int32 = t.F_tmpBase
	var cursor2 int32 = base2
	var dest int32 = base1


	System_Arraycopy_O_I_O_I_I__V(a.Ref(), base1, tmp.Ref(), cursor1, len1)
	a.Store(dest, a.A[cursor2])
	dest = dest + 1
	cursor2 = cursor2 + 1
	var tmp4 int32
	len2 = len2 - 1; tmp4 = len2
//line :332:1
	if tmp4 == 0 {
		System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor1, a.Ref(), dest, len1) } else {
//line :332:1
			if len1 == 1 {



				System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor2, a.Ref(), dest, len2)
				a.Store(dest+len2, tmp.A[cursor1]) } else {

					var c Comparator = t.F_c; var minGallop int32 = t.F_minGallop

				L1: switch { default: L2: for {

					var count1 int32 = 0
					var count2 int32 = 0
				L3: for {
					var tmp5 bool; var tmp6 bool; tmp6 = len1 > 1; if tmp6 { tmp6 = len2 > 0 }; tmp5 = tmp6; if !A2g_AssertionsDisabled && !tmp5 { panic(Thrown(AssertionError_New())) }
					var tmp7 any = a.A[cursor2]; if c.Compare_O_O__I(tmp7, tmp.A[cursor1]) < 0 {

						a.Store(dest, a.A[cursor2])
						dest = dest + 1
						cursor2 = cursor2 + 1
						count2 = count2 + 1
						count1 = 0
						var tmp8 int32; len2 = len2 - 1; tmp8 = len2; if tmp8 == 0 { break L1 } } else {

							a.Store(dest, tmp.A[cursor1])
							dest = dest + 1
							cursor1 = cursor1 + 1
							count1 = count1 + 1
							count2 = 0
							var tmp9 int32; len1 = len1 - 1; tmp9 = len1; if tmp9 == 1 { break L1 } }
					if count1|count2 < minGallop { continue L3 }
//line :345:1
					break L3
				}
















				L4: for {
					var tmp10 bool; var tmp11 bool; tmp11 = len1 > 1; if tmp11 { tmp11 = len2 > 0 }; tmp10 = tmp11; if !A2g_AssertionsDisabled && !tmp10 { panic(Thrown(AssertionError_New())) }
					count1 = TimSort_GallopRight_O_O1_I_I_I_Comparator__I(a.A[cursor2], tmp, cursor1, len1, 0, c)
					if count1 == 0 { } else {
						System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor1, a.Ref(), dest, count1)
						dest = dest + count1
						cursor1 = cursor1 + count1
						len1 = len1 - count1
						if len1 <= 1 { break L1 } }
					a.Store(dest, a.A[cursor2])
					dest = dest + 1
					cursor2 = cursor2 + 1
					var tmp12 int32; len2 = len2 - 1; tmp12 = len2; if tmp12 == 0 { break L1 }
					count2 = TimSort_GallopLeft_O_O1_I_I_I_Comparator__I(tmp.A[cursor1], a, cursor2, len2, 0, c)
					if count2 == 0 { } else {
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor2, a.Ref(), dest, count2)
						dest = dest + count2
						cursor2 = cursor2 + count2
						len2 = len2 - count2
						if len2 == 0 { break L1 } }
					a.Store(dest, tmp.A[cursor1])
					dest = dest + 1
					cursor1 = cursor1 + 1
					var tmp13 int32; len1 = len1 - 1; tmp13 = len1; if tmp13 == 1 { break L1 }
					minGallop = minGallop - 1
					var tmp14 bool; var a_2 bool = count1 >= 7; var b_3 bool = count2 >= 7; var tmp15 bool; tmp15 = a_2; if !tmp15 { tmp15 = b_3 }; tmp14 = tmp15; if tmp14 {
						continue L4 }
//line :363:1
					break L4
				}

























					if minGallop < 0 { minGallop = 0 }
					minGallop = minGallop + 2
//line :341:1
					continue L2
				}
				}
















































					var tmp16 int32; if minGallop < 1 { tmp16 = 1 } else { tmp16 = minGallop }; t.F_minGallop = tmp16
					if len1 == 1 {


						if !A2g_AssertionsDisabled && !(len2 > 0) { panic(Thrown(AssertionError_New())) }
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor2, a.Ref(), dest, len2)
						a.Store(dest+len2, tmp.A[cursor1]) } else {
//line :393:1
							if len1 == 0 {






								panic(Thrown(IllegalArgumentException_New_String(Lit_2641))) } else {



									if !A2g_AssertionsDisabled && !(len2 == 0) { panic(Thrown(AssertionError_New())) }
									if !A2g_AssertionsDisabled && !(len1 > 1) { panic(Thrown(AssertionError_New())) }
									System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor1, a.Ref(), dest, len1)
								} } } } }
func (t *TimSort) MergeHi_I_I_I_I__V(base1, len1, base2, len2 int32) {

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len1 > 0; if tmp3 { tmp3 = len2 > 0 }; tmp2 = tmp3; if tmp2 { tmp2 = base1+len1 == base2 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var a *RefArray = t.F_a; var tmp *RefArray = t.EnsureCapacity_I__O1(len2); var tmpBase int32 = t.F_tmpBase


	System_Arraycopy_O_I_O_I_I__V(a.Ref(), base2, tmp.Ref(), tmpBase, len2)
	var cursor1 int32 = base1 + len1 - 1; var cursor2 int32 = tmpBase + len2 - 1; var dest int32 = base2 + len2 - 1


	a.Store(dest, a.A[cursor1])
	dest = dest - 1
	cursor1 = cursor1 - 1
	var tmp4 int32
	len1 = len1 - 1; tmp4 = len1
//line :421:1
	if tmp4 == 0 {

		System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), tmpBase, a.Ref(), dest-(len2-1), len2) } else {
//line :421:1
			if len2 == 1 {








				dest = dest - len1
				cursor1 = cursor1 - len1
				System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor1+1, a.Ref(), dest+1, len1)
				a.Store(dest, tmp.A[cursor2]) } else {

					var c Comparator = t.F_c; var minGallop int32 = t.F_minGallop

				L1: switch { default: L2: for {

					var count1 int32 = 0
					var count2 int32 = 0
				L3: for {
					var tmp5 bool; var tmp6 bool; tmp6 = len1 > 0; if tmp6 { tmp6 = len2 > 1 }; tmp5 = tmp6; if !A2g_AssertionsDisabled && !tmp5 { panic(Thrown(AssertionError_New())) }
					var tmp7 any = tmp.A[cursor2]; if c.Compare_O_O__I(tmp7, a.A[cursor1]) < 0 {

						a.Store(dest, a.A[cursor1])
						dest = dest - 1
						cursor1 = cursor1 - 1
						count1 = count1 + 1
						count2 = 0
						var tmp8 int32; len1 = len1 - 1; tmp8 = len1; if tmp8 == 0 { break L1 } } else {

							a.Store(dest, tmp.A[cursor2])
							dest = dest - 1
							cursor2 = cursor2 - 1
							count2 = count2 + 1
							count1 = 0
							var tmp9 int32; len2 = len2 - 1; tmp9 = len2; if tmp9 == 1 { break L1 } }
					if count1|count2 < minGallop { continue L3 }
//line :441:1
					break L3
				}
















				L4: for {
					var tmp10 bool; var tmp11 bool; tmp11 = len1 > 0; if tmp11 { tmp11 = len2 > 1 }; tmp10 = tmp11; if !A2g_AssertionsDisabled && !tmp10 { panic(Thrown(AssertionError_New())) }
					count1 = len1 - TimSort_GallopRight_O_O1_I_I_I_Comparator__I(tmp.A[cursor2], a, base1, len1, len1-1, c)









					if count1 == 0 { } else {
						dest = dest - count1
						cursor1 = cursor1 - count1
						len1 = len1 - count1
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor1+1, a.Ref(), dest+1, count1)




						if len1 == 0 { break L1 } }
					a.Store(dest, tmp.A[cursor2])
					dest = dest - 1
					cursor2 = cursor2 - 1
					var tmp12 int32; len2 = len2 - 1; tmp12 = len2; if tmp12 == 1 { break L1 }
					count2 = len2 - TimSort_GallopLeft_O_O1_I_I_I_Comparator__I(a.A[cursor1], tmp, tmpBase, len2, len2-1, c)









					if count2 == 0 { } else {
						dest = dest - count2
						cursor2 = cursor2 - count2
						len2 = len2 - count2
						System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor2+1, a.Ref(), dest+1, count2)




						if len2 <= 1 { break L1 } }
					a.Store(dest, a.A[cursor1])
					dest = dest - 1
					cursor1 = cursor1 - 1
					var tmp13 int32; len1 = len1 - 1; tmp13 = len1; if tmp13 == 0 { break L1 }
					minGallop = minGallop - 1
					var tmp14 bool; var a_4 bool = count1 >= 7; var b_5 bool = count2 >= 7; var tmp15 bool

					tmp15 = a_4; if !tmp15 { tmp15 = b_5 }; tmp14 = tmp15
//line :510:1
					if tmp14 {


						continue L4 }
//line :459:1
					break L4
				}





















































					if minGallop < 0 { minGallop = 0 }
					minGallop = minGallop + 2
//line :437:1
					continue L2
				}
				}












































































					var tmp16 int32; if minGallop < 1 { tmp16 = 1 } else { tmp16 = minGallop }; t.F_minGallop = tmp16
					if len2 == 1 {


						if !A2g_AssertionsDisabled && !(len1 > 0) { panic(Thrown(AssertionError_New())) }
						dest = dest - len1
						cursor1 = cursor1 - len1
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor1+1, a.Ref(), dest+1, len1)




						a.Store(dest, tmp.A[cursor2]) } else {
//line :517:1
							if len2 == 0 {












								panic(Thrown(IllegalArgumentException_New_String(Lit_2641))) } else {



									if !A2g_AssertionsDisabled && !(len1 == 0) { panic(Thrown(AssertionError_New())) }
									if !A2g_AssertionsDisabled && !(len2 > 0) { panic(Thrown(AssertionError_New())) }
									System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), tmpBase, a.Ref(), dest-(len2-1), len2)
								}
						}
				}
		}
}
func (t *TimSort) EnsureCapacity_I__O1(minCapacity int32) *RefArray {
	if t.F_tmpLen < minCapacity {
		var newSize int32 = int32(uint32(4294967295) >> (Integer_NumberOfLeadingZeros_I__I(minCapacity) & 31))


		newSize = newSize + 1
		if newSize < 0 {
			newSize = minCapacity } else {
				newSize = Math_Min_I_I__I(newSize, int32(uint32(int32(len(t.F_a.A)))>>1)) }
		var newArray *RefArray = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(t.F_a.Ref())).GetComponentType__Class(), newSize), Object_class.ArrayClass())

		t.F_tmp = newArray
		t.F_tmpLen = newSize
		t.F_tmpBase = 0 }
//line :542:1
	return t.F_tmp
}















type TimSort struct{ Object; F_a *RefArray; F_c Comparator; F_minGallop int32; F_tmp *RefArray; F_tmpBase, F_tmpLen, F_stackSize int32; F_runBase, F_runLen *IntArray }

const TimSort_MIN_MERGE int32 = 32

const TimSort_MIN_GALLOP int32 = 7

const TimSort_INITIAL_TMP_STORAGE_LENGTH int32 = 256

var TimSort_init ClassInit

func TimSort_Init() { if !TimSort_init.Done() { TimSort_init.Run(TimSort_clinit) } }

func TimSort_clinit() {}

func (t *TimSort) Ref() any { if t == nil { return nil }; return t }

func (t *TimSort) GetClass__Class() *Class { return TimSort_class }

func (t *TimSort) ToString__String() *String { return Object_toString(t) }

func (t *TimSort) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TimSort) CloneShallow() any { panic(CloneNotSupported(t)) }

func TimSort_InstanceOf(x any) bool { _, ok := x.(*TimSort); return ok }

func TimSort_Cast(x any) *TimSort { if x == nil { return nil }; v, ok := x.(*TimSort); if !ok { panic(ClassCast(x, TimSort_class)) }; return v }
