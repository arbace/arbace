//line java_net_Inet6AddressImpl.ae:1
package jrt










func (t *Inet6AddressImpl) GetLocalHostName__String() *String {
	return HostNet_GetLocalHostName__String() }
func (t *Inet6AddressImpl) LookupAllHostAddr_String_InetAddressResolver_LookupPolicy__InetAddress1(hostname *String, lookupPolicy *InetAddressResolver_LookupPolicy) *RefArray {


	return t.LookupAllHostAddr_String_I__InetAddress1(hostname, NN(lookupPolicy).Characteristics__I()) }
//line :15:1
func (t *Inet6AddressImpl) LookupAllHostAddr_String_I__InetAddress1(hostname *String, characteristics int32) *RefArray {

	return HostNet_LookupAllHostAddr_String_I__InetAddress1(hostname, characteristics)
}
func (t *Inet6AddressImpl) GetHostByAddr_B1__String(addr *ByteArray) *String {
	return HostNet_GetHostByAddr_B1__String(addr)
}
func (t *Inet6AddressImpl) IsReachable0_B1_I_I_B1_I_I__Z(addr *ByteArray, scope, timeout int32, inf *ByteArray, ttl, if_scope int32) bool {

	panic(Thrown(UnsupportedOperationException_New_String(Lit_1301)))
}
func (t *Inet6AddressImpl) LoopbackAddress__InetAddress() InetAddress_I { MonitorEnter(t); defer MonitorExit(t)
	if t.F_loopbackAddress == nil {
		var flags int32; var tmp1 *InetAddressResolver_LookupPolicy; InetAddress_Init(); tmp1 = InetAddress_PLATFORM_LOOKUP_POLICY; flags = NN(tmp1).Characteristics__I()
		var tmp2 InetAddress_I; var tmp3 bool; var tmp4 bool
		tmp4 = InetAddress_Ipv6AddressesFirst_I__Z(flags); if !tmp4 { tmp4 = InetAddress_SystemAddressesOrder_I__Z(flags) }; tmp3 = tmp4; if tmp3 {
			tmp2 = Inet6Address_New_String_B1(Lit_1303, ByteArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1)) } else {
				tmp2 = Inet4Address_New_String_B1(Lit_1303, ByteArrayOf(127, 0, 0, 1)) }
//line :29:1
		t.F_loopbackAddress = tmp2 }
//line :26:1
	return t.F_loopbackAddress
}





















func (t *Inet6AddressImpl) AnyLocalAddress__InetAddress() InetAddress_I { MonitorEnter(t); defer MonitorExit(t)
	if t.F_anyLocalAddress == nil {
		var flags int32; var tmp1 *InetAddressResolver_LookupPolicy; InetAddress_Init(); tmp1 = InetAddress_PLATFORM_LOOKUP_POLICY; flags = NN(tmp1).Characteristics__I()
		var tmp2 bool; var tmp3 bool; tmp3 = InetAddress_Ipv6AddressesFirst_I__Z(flags); if !tmp3 { tmp3 = InetAddress_SystemAddressesOrder_I__Z(flags) }; tmp2 = tmp3; if tmp2 {

			t.F_anyLocalAddress = Inet6Address_New()
			t.F_anyLocalAddress.Holder__InetAddress_InetAddressHolder().F_hostName = Lit_1311 } else {
				t.F_anyLocalAddress = Inet4AddressImpl_New().AnyLocalAddress__InetAddress() } }
//line :49:1
	return t.F_anyLocalAddress
}









type Inet6AddressImpl struct{ Object; F_anyLocalAddress, F_loopbackAddress InetAddress_I }

func (t *Inet6AddressImpl) Is_InetAddressImpl() {}

func Inet6AddressImpl_New() *Inet6AddressImpl { t := &Inet6AddressImpl{}; t.Ctor(); return t }

func (t *Inet6AddressImpl) Ctor() {}

func (t *Inet6AddressImpl) Ref() any { if t == nil { return nil }; return t }

func (t *Inet6AddressImpl) GetClass__Class() *Class { return Inet6AddressImpl_class }

func (t *Inet6AddressImpl) ToString__String() *String { return Object_toString(t) }

func (t *Inet6AddressImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Inet6AddressImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func Inet6AddressImpl_InstanceOf(x any) bool { _, ok := x.(*Inet6AddressImpl); return ok }

func Inet6AddressImpl_Cast(x any) *Inet6AddressImpl { if x == nil { return nil }; v, ok := x.(*Inet6AddressImpl); if !ok { panic(ClassCast(x, Inet6AddressImpl_class)) }; return v }
