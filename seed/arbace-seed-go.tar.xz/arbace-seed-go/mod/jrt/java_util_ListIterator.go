//line java_util_ListIterator.ae:1
package jrt






type ListIterator interface{ Object_I; Iterator; Is_ListIterator(); HasNext__Z() bool; Next__O() any; HasPrevious__Z() bool; Previous__O() any; NextIndex__I() int32; PreviousIndex__I() int32; Remove__V(); Set_O__V(p0 any); Add_O__V(p0 any) }

func ListIterator_InstanceOf(x any) bool { _, ok := x.(ListIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ListIterator_class) } }; return ok }

func ListIterator_Cast(x any) ListIterator { if x == nil { return nil }; v, ok := x.(ListIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ListIterator_class) } }; if !ok { panic(ClassCast(x, ListIterator_class)) }; return v }
