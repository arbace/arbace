//line java_io_EOFException.ae:1
package jrt








func EOFException_New() *EOFException { t := &EOFException{}; t.Ctor(); return t }
//line :10:1
func (t *EOFException) Ctor() { t.IOException.Ctor(t) }

func EOFException_New_String(p0 *String) *EOFException { t := &EOFException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *EOFException) Ctor_String(s *String) { t.IOException.Ctor_String(t, s) }







type EOFException struct{ IOException }

const EOFException_serialVersionUID int64 = 6433858223774886977

func (t *EOFException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *EOFException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *EOFException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *EOFException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *EOFException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *EOFException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *EOFException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *EOFException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *EOFException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *EOFException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *EOFException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *EOFException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *EOFException) Ref() any { if t == nil { return nil }; return t }

func (t *EOFException) GetClass__Class() *Class { return EOFException_class }

func (t *EOFException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EOFException) CloneShallow() any { panic(CloneNotSupported(t)) }

func EOFException_InstanceOf(x any) bool { _, ok := x.(*EOFException); return ok }

func EOFException_Cast(x any) *EOFException { if x == nil { return nil }; v, ok := x.(*EOFException); if !ok { panic(ClassCast(x, EOFException_class)) }; return v }
