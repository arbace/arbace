//line java_text_Annotation.ae:1
package jrt




func Text_Annotation_New_O(p0 any) *Text_Annotation { t := &Text_Annotation{}; t.Ctor_O(p0); return t }
//line :6:1
func (t *Text_Annotation) Ctor_O(value any) { t.F_value = value }

func (t *Text_Annotation) GetValue__O() any { return t.F_value }

func (t *Text_Annotation) ToString__String() *String {
	return Concat(NN(t.GetClass__Class()).GetName__String(), Lit_1691, StrOfObj(t.F_value), Lit_1189)
}



type Text_Annotation struct{ Object; F_value any }

func (t *Text_Annotation) Ref() any { if t == nil { return nil }; return t }

func (t *Text_Annotation) GetClass__Class() *Class { return Text_Annotation_class }

func (t *Text_Annotation) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Text_Annotation) CloneShallow() any { panic(CloneNotSupported(t)) }

func Text_Annotation_InstanceOf(x any) bool { _, ok := x.(*Text_Annotation); return ok }

func Text_Annotation_Cast(x any) *Text_Annotation { if x == nil { return nil }; v, ok := x.(*Text_Annotation); if !ok { panic(ClassCast(x, Text_Annotation_class)) }; return v }
