//line java_time_temporal_TemporalAdjuster.ae:1
package jrt






type TemporalAdjuster interface{ Object_I; Is_TemporalAdjuster(); AdjustInto_Temporal__Temporal(p0 Temporal) Temporal }

func TemporalAdjuster_InstanceOf(x any) bool { _, ok := x.(TemporalAdjuster); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalAdjuster_class) } }; return ok }

func TemporalAdjuster_Cast(x any) TemporalAdjuster { if x == nil { return nil }; v, ok := x.(TemporalAdjuster); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalAdjuster_class) } }; if !ok { panic(ClassCast(x, TemporalAdjuster_class)) }; return v }
