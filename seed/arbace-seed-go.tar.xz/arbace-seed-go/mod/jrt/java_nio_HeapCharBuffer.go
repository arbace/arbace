//line java_nio_HeapCharBuffer.ae:1
package jrt
















func HeapCharBuffer_New_I_I_MemorySegment(p0, p1 int32, p2 MemorySegment) *HeapCharBuffer { HeapCharBuffer_Init(); t := &HeapCharBuffer{}; t.Ctor_I_I_MemorySegment(p0, p1, p2); return t }
//line :18:1
func (t *HeapCharBuffer) Ctor_I_I_MemorySegment(cap_, lim int32, segment MemorySegment) { t.CharBuffer.Ctor_I_I_I_I_C1_I_MemorySegment(t, -1, 0, lim, cap_, NewCharArray(cap_), 0, segment)

	t.F_address = HeapCharBuffer_ARRAY_BASE_OFFSET
}
func HeapCharBuffer_New_C1_I_I_MemorySegment(p0 *CharArray, p1, p2 int32, p3 MemorySegment) *HeapCharBuffer { HeapCharBuffer_Init(); t := &HeapCharBuffer{}; t.Ctor_C1_I_I_MemorySegment(p0, p1, p2, p3); return t }
//line :22:1
func (t *HeapCharBuffer) Ctor_C1_I_I_MemorySegment(buf *CharArray, off, len_ int32, segment MemorySegment) { t.CharBuffer.Ctor_I_I_I_I_C1_I_MemorySegment(t, -1, off, off+len_, int32(len(buf.A)), buf, 0, segment)

	t.F_address = HeapCharBuffer_ARRAY_BASE_OFFSET
}
func HeapCharBuffer_New_C1_I_I_I_I_I_MemorySegment(p0 *CharArray, p1, p2, p3, p4, p5 int32, p6 MemorySegment) *HeapCharBuffer { HeapCharBuffer_Init(); t := &HeapCharBuffer{}; t.Ctor_C1_I_I_I_I_I_MemorySegment(p0, p1, p2, p3, p4, p5, p6); return t }
//line :26:1
func (t *HeapCharBuffer) Ctor_C1_I_I_I_I_I_MemorySegment(buf *CharArray, mark, pos, lim, cap_, off int32, segment MemorySegment) { t.CharBuffer.Ctor_I_I_I_I_C1_I_MemorySegment(t, mark, pos, lim, cap_, buf, off, segment)


	t.F_address = HeapCharBuffer_ARRAY_BASE_OFFSET + int64(off)*HeapCharBuffer_ARRAY_INDEX_SCALE
}

func (t *HeapCharBuffer) Slice__CharBuffer() CharBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32

	if pos <= lim { rem = lim - pos } else { rem = 0 }
	return HeapCharBuffer_New_C1_I_I_I_I_I_MemorySegment(t.F_hb, -1, 0, rem, rem, pos+t.F_offset, t.F_segment)
}






func (t *HeapCharBuffer) Slice_I_I__CharBuffer(index, length int32) CharBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	return HeapCharBuffer_New_C1_I_I_I_I_I_MemorySegment(t.F_hb, -1, 0, length, length, index+t.F_offset, t.F_segment)
}






func (t *HeapCharBuffer) Duplicate__CharBuffer() CharBuffer_I {
	var tmp1 *CharArray = t.F_hb; return HeapCharBuffer_New_C1_I_I_I_I_I_MemorySegment(tmp1, t.MarkValue__I(), t.Position__I(), t.Limit__I(), t.Capacity__I(), t.F_offset, t.F_segment)
}






func (t *HeapCharBuffer) AsReadOnlyBuffer__CharBuffer() CharBuffer_I {
	return A2g_Missing[CharBuffer_I]("class java.nio.HeapCharBufferR is not in the closed world")
}






func (t *HeapCharBuffer) Ix_I__I(i int32) int32 {
	return i + t.F_offset
}
func (t *HeapCharBuffer) Get__C() uint16 {
	var tmp1 *CharArray = t.F_hb; return tmp1.A[t.Ix_I__I(t.NextGetIndex__I())]
}
func (t *HeapCharBuffer) Get_I__C(i int32) uint16 {
	var tmp1 *CharArray = t.F_hb; return tmp1.A[t.Ix_I__I(t.CheckIndex_I__I(i))]
}
func (t *HeapCharBuffer) GetUnchecked_I__C(p0 int32) uint16 { panic(A2g_NotTranslated("java.nio.HeapCharBuffer.getUnchecked(I)C")) }


func (t *HeapCharBuffer) Get_C1_I_I__CharBuffer(dst *CharArray, offset, length int32) CharBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var pos int32 = t.Position__I()
	if length > t.Limit__I()-pos {
		panic(Thrown(BufferUnderflowException_New())) }
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, t.Ix_I__I(pos), dst.Ref(), offset, length)
	t.Position_I__CharBuffer(pos + length)
//line :87:1
	return t
}





func (t *HeapCharBuffer) Get_I_C1_I_I__CharBuffer(index int32, dst *CharArray, offset, length int32) CharBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, t.Ix_I__I(index), dst.Ref(), offset, length)
//line :94:1
	return t
}





func (t *HeapCharBuffer) IsDirect__Z() bool { return false }

func (t *HeapCharBuffer) IsReadOnly__Z() bool { return false }

func (t *HeapCharBuffer) Put_C__CharBuffer(x uint16) CharBuffer_I {
	var tmp1 *CharArray = t.F_hb; tmp1.A[t.Ix_I__I(t.NextPutIndex__I())] = x
//line :105:1
	return t
}


func (t *HeapCharBuffer) Put_I_C__CharBuffer(i int32, x uint16) CharBuffer_I {
	var tmp1 *CharArray = t.F_hb; tmp1.A[t.Ix_I__I(t.CheckIndex_I__I(i))] = x
//line :109:1
	return t
}


func (t *HeapCharBuffer) Put_C1_I_I__CharBuffer(src *CharArray, offset, length int32) CharBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var pos int32 = t.Position__I()
	if length > t.Limit__I()-pos {
		panic(Thrown(BufferOverflowException_New())) }
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(src.Ref(), offset, tmp1, t.Ix_I__I(pos), length)
	t.Position_I__CharBuffer(pos + length)
//line :116:1
	return t
}





func (t *HeapCharBuffer) Put_CharBuffer__CharBuffer(src CharBuffer_I) CharBuffer_I {
	t.CheckSession__V()
	t.CharBuffer.Impl_Put_CharBuffer__CharBuffer(t, src)
//line :123:1
	return t
}



func (t *HeapCharBuffer) Put_I_CharBuffer_I_I__CharBuffer(index int32, src CharBuffer_I, offset, length int32) CharBuffer_I {
	t.CheckSession__V()
	t.CharBuffer.Impl_Put_I_CharBuffer_I_I__CharBuffer(t, index, src, offset, length)
//line :128:1
	return t
}



func (t *HeapCharBuffer) Put_I_C1_I_I__CharBuffer(index int32, src *CharArray, offset, length int32) CharBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(src.Ref(), offset, tmp1, t.Ix_I__I(index), length)
//line :133:1
	return t
}





func (t *HeapCharBuffer) Append_CharSequence_I_I__CharBuffer(csq CharSequence, start, end int32) CharBuffer_I {
	if csq == nil {
		return t.CharBuffer.Impl_Append_CharSequence_I_I__CharBuffer(t, csq, start, end) } else {

			t.CheckSession__V()
			Objects_CheckFromToIndex_I_I_I__I(start, end, csq.Length__I())
			var length int32 = end - start; var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32


			if pos <= lim { rem = lim - pos } else { rem = 0 }
			if length > rem { panic(Thrown(BufferOverflowException_New())) }
			var tmp1 *CharArray = t.F_hb; csq.GetChars_I_I_C1_I__V(start, end, tmp1, t.Ix_I__I(pos))
			t.Position_I__CharBuffer(pos + length)
//line :146:1
			return t
		}
}






func (t *HeapCharBuffer) Append_CharSequence__CharBuffer(csq CharSequence) CharBuffer_I {
	if StringBuilder_InstanceOf(csq) { return t.Append_CharSequence_I_I__CharBuffer(csq, 0, csq.Length__I()) } else { return t.CharBuffer.Impl_Append_CharSequence__CharBuffer(t, csq)
	} }
func (t *HeapCharBuffer) Put_String_I_I__CharBuffer(src *String, start, end int32) CharBuffer_I {
	t.CheckSession__V()
	var length int32 = end - start
	Objects_CheckFromIndexSize_I_I_I__I(start, length, NN(src).Length__I())
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32

	if pos <= lim { rem = lim - pos } else { rem = 0 }
	if length > rem { panic(Thrown(BufferOverflowException_New())) }
	var tmp1 *CharArray = t.F_hb; NN(src).GetChars_I_I_C1_I__V(start, end, tmp1, t.Ix_I__I(pos))
	t.Position_I__CharBuffer(pos + length)
//line :162:1
	return t
}






func (t *HeapCharBuffer) Compact__CharBuffer() CharBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I()

	if !A2g_AssertionsDisabled && !(pos <= lim) { panic(Thrown(AssertionError_New())) }
	var rem int32; if pos <= lim { rem = lim - pos } else { rem = 0 }
	var tmp1 any = t.F_hb.Ref(); var tmp2 int32 = t.Ix_I__I(pos); var tmp3 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, tmp2, tmp3, t.Ix_I__I(0), rem)
	t.Position_I__CharBuffer(rem)
	t.Limit_I__CharBuffer(t.Capacity__I())
	t.DiscardMark__V()
//line :174:1
	return t
}





func (t *HeapCharBuffer) ToString_I_I__String(start, end int32) *String {
	var tmp1 *String; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = String_New_C1_I_I(t.F_hb, start+t.F_offset, end-start); return nil }()
//line :182:1
	if tmp2 != nil { if StringIndexOutOfBoundsException_InstanceOf(tmp2) { var x *StringIndexOutOfBoundsException = StringIndexOutOfBoundsException_Cast(tmp2); _ = x



		panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :182:1
			panic(tmp2) } }; return tmp1
}




func (t *HeapCharBuffer) SubSequence_I_I__CharBuffer(start, end int32) CharBuffer_I {
	var pos int32 = t.Position__I()
	Objects_CheckFromToIndex_I_I_I__I(start, end, t.Limit__I()-pos)
	var tmp1 *CharArray = t.F_hb; return HeapCharBuffer_New_C1_I_I_I_I_I_MemorySegment(tmp1, -1, pos+start, pos+end, t.Capacity__I(), t.F_offset, t.F_segment)
}






func (t *HeapCharBuffer) Order__ByteOrder() *ByteOrder { return ByteOrder_NativeOrder__ByteOrder() }

func (t *HeapCharBuffer) CharRegionOrder__ByteOrder() *ByteOrder { panic(A2g_NotTranslated("java.nio.HeapCharBuffer.charRegionOrder()Ljava/nio/ByteOrder;")) }



type HeapCharBuffer struct{ CharBuffer }

var HeapCharBuffer_ARRAY_BASE_OFFSET int64

var HeapCharBuffer_ARRAY_INDEX_SCALE int64

var HeapCharBuffer_init ClassInit

func HeapCharBuffer_Init() { if !HeapCharBuffer_init.Done() { HeapCharBuffer_init.Run(HeapCharBuffer_clinit) } }

func HeapCharBuffer_clinit() { CharBuffer_Init(); HeapCharBuffer_ARRAY_BASE_OFFSET = NN(Buffer_UNSAFE).ArrayBaseOffset_Class__J(Prim_char.ArrayClass()); HeapCharBuffer_ARRAY_INDEX_SCALE = int64(NN(Buffer_UNSAFE).ArrayIndexScale_Class__I(Prim_char.ArrayClass())) }

func (t *HeapCharBuffer) Slice__Buffer() Buffer_I { return t.Slice__CharBuffer() }

func (t *HeapCharBuffer) Slice_I_I__Buffer(p0, p1 int32) Buffer_I { return t.Slice_I_I__CharBuffer(p0, p1) }

func (t *HeapCharBuffer) Duplicate__Buffer() Buffer_I { return t.Duplicate__CharBuffer() }

func (t *HeapCharBuffer) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return t.Append_CharSequence__CharBuffer(p0) }

func (t *HeapCharBuffer) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return t.Append_CharSequence_I_I__CharBuffer(p0, p1, p2) }

func (t *HeapCharBuffer) SubSequence_I_I__CharSequence(p0, p1 int32) CharSequence { return t.SubSequence_I_I__CharBuffer(p0, p1) }

func (t *HeapCharBuffer) CharAt_I__C(p0 int32) uint16 { return t.Impl_CharAt_I__C(t, p0) }

func (t *HeapCharBuffer) ScaleShifts__I() int32 { return t.Impl_ScaleShifts__I(t) }

func (t *HeapCharBuffer) Array__O() any { return t.Impl_Array__O(t) }

func (t *HeapCharBuffer) Get_C1__CharBuffer(p0 *CharArray) CharBuffer_I { return t.Impl_Get_C1__CharBuffer(t, p0) }

func (t *HeapCharBuffer) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *HeapCharBuffer) NextGetIndex__I() int32 { return t.Impl_NextGetIndex__I(t) }

func (t *HeapCharBuffer) Clear__Buffer() Buffer_I { return t.Impl_Clear__Buffer(t) }

func (t *HeapCharBuffer) Rewind__CharBuffer() CharBuffer_I { return t.Impl_Rewind__CharBuffer(t) }

func (t *HeapCharBuffer) Clear__CharBuffer() CharBuffer_I { return t.Impl_Clear__CharBuffer(t) }

func (t *HeapCharBuffer) Session__MemorySessionImpl() MemorySessionImpl_I { return t.Impl_Session__MemorySessionImpl(t) }

func (t *HeapCharBuffer) Put_String__CharBuffer(p0 *String) CharBuffer_I { return t.Impl_Put_String__CharBuffer(t, p0) }

func (t *HeapCharBuffer) Array__C1() *CharArray { return t.Impl_Array__C1(t) }

func (t *HeapCharBuffer) PutArray_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_PutArray_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *HeapCharBuffer) Limit__I() int32 { return t.Impl_Limit__I(t) }

func (t *HeapCharBuffer) Base__O() any { return t.Impl_Base__O(t) }

func (t *HeapCharBuffer) Reset__CharBuffer() CharBuffer_I { return t.Impl_Reset__CharBuffer(t) }

func (t *HeapCharBuffer) Remaining__I() int32 { return t.Impl_Remaining__I(t) }

func (t *HeapCharBuffer) NextGetIndex_I__I(p0 int32) int32 { return t.Impl_NextGetIndex_I__I(t, p0) }

func (t *HeapCharBuffer) NextPutIndex__I() int32 { return t.Impl_NextPutIndex__I(t) }

func (t *HeapCharBuffer) GetChars_I_I_C1_I__V(p0, p1 int32, p2 *CharArray, p3 int32) { t.Impl_GetChars_I_I_C1_I__V(t, p0, p1, p2, p3) }

func (t *HeapCharBuffer) DiscardMark__V() { t.Impl_DiscardMark__V(t) }

func (t *HeapCharBuffer) Flip__Buffer() Buffer_I { return t.Impl_Flip__Buffer(t) }

func (t *HeapCharBuffer) ArrayOffset__I() int32 { return t.Impl_ArrayOffset__I(t) }

func (t *HeapCharBuffer) MarkValue__I() int32 { return t.Impl_MarkValue__I(t) }

func (t *HeapCharBuffer) Put_C1__CharBuffer(p0 *CharArray) CharBuffer_I { return t.Impl_Put_C1__CharBuffer(t, p0) }

func (t *HeapCharBuffer) Position_I__CharBuffer(p0 int32) CharBuffer_I { return t.Impl_Position_I__CharBuffer(t, p0) }

func (t *HeapCharBuffer) Rewind__Buffer() Buffer_I { return t.Impl_Rewind__Buffer(t) }

func (t *HeapCharBuffer) HasArray__Z() bool { return t.Impl_HasArray__Z(t) }

func (t *HeapCharBuffer) CodePoints__IntStream() IntStream { return CharSequence_CodePoints__IntStream(t) }

func (t *HeapCharBuffer) Get_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I { return t.Impl_Get_I_C1__CharBuffer(t, p0, p1) }

func (t *HeapCharBuffer) Limit_I__CharBuffer(p0 int32) CharBuffer_I { return t.Impl_Limit_I__CharBuffer(t, p0) }

func (t *HeapCharBuffer) Append_C__CharBuffer(p0 uint16) CharBuffer_I { return t.Impl_Append_C__CharBuffer(t, p0) }

func (t *HeapCharBuffer) Chars__IntStream() IntStream { return t.Impl_Chars__IntStream(t) }

func (t *HeapCharBuffer) Length__I() int32 { return t.Impl_Length__I(t) }

func (t *HeapCharBuffer) Position__I() int32 { return t.Impl_Position__I(t) }

func (t *HeapCharBuffer) Reset__Buffer() Buffer_I { return t.Impl_Reset__Buffer(t) }

func (t *HeapCharBuffer) Append_C__Appendable(p0 uint16) Appendable { return t.Impl_Append_C__Appendable(t, p0) }

func (t *HeapCharBuffer) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *HeapCharBuffer) CheckIndex_I_I__I(p0, p1 int32) int32 { return t.Impl_CheckIndex_I_I__I(t, p0, p1) }

func (t *HeapCharBuffer) CheckSession__V() { t.Impl_CheckSession__V(t) }

func (t *HeapCharBuffer) Flip__CharBuffer() CharBuffer_I { return t.Impl_Flip__CharBuffer(t) }

func (t *HeapCharBuffer) CheckIndex_I__I(p0 int32) int32 { return t.Impl_CheckIndex_I__I(t, p0) }

func (t *HeapCharBuffer) Position_I__Buffer(p0 int32) Buffer_I { return t.Impl_Position_I__Buffer(t, p0) }

func (t *HeapCharBuffer) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *HeapCharBuffer) GetArray_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_GetArray_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *HeapCharBuffer) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *HeapCharBuffer) Mark__Buffer() Buffer_I { return t.Impl_Mark__Buffer(t) }

func (t *HeapCharBuffer) Mismatch_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Mismatch_CharBuffer__I(t, p0) }

func (t *HeapCharBuffer) Put_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I { return t.Impl_Put_I_C1__CharBuffer(t, p0, p1) }

func (t *HeapCharBuffer) CompareTo_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_CompareTo_CharBuffer__I(t, p0) }

func (t *HeapCharBuffer) HasRemaining__Z() bool { return t.Impl_HasRemaining__Z(t) }

func (t *HeapCharBuffer) Mark__CharBuffer() CharBuffer_I { return t.Impl_Mark__CharBuffer(t) }

func (t *HeapCharBuffer) PutBuffer_I_CharBuffer_I_I__V(p0 int32, p1 CharBuffer_I, p2, p3 int32) { t.Impl_PutBuffer_I_CharBuffer_I_I__V(t, p0, p1, p2, p3) }

func (t *HeapCharBuffer) NextPutIndex_I__I(p0 int32) int32 { return t.Impl_NextPutIndex_I__I(t, p0) }

func (t *HeapCharBuffer) IsAddressable__Z() bool { return t.Impl_IsAddressable__Z(t) }

func (t *HeapCharBuffer) Limit_I__Buffer(p0 int32) Buffer_I { return t.Impl_Limit_I__Buffer(t, p0) }

func (t *HeapCharBuffer) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HeapCharBuffer) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HeapCharBuffer) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HeapCharBuffer) Ref() any { if t == nil { return nil }; return t }

func (t *HeapCharBuffer) GetClass__Class() *Class { return HeapCharBuffer_class }

func (t *HeapCharBuffer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HeapCharBuffer) CloneShallow() any { panic(CloneNotSupported(t)) }

func HeapCharBuffer_InstanceOf(x any) bool { _, ok := x.(*HeapCharBuffer); return ok }

func HeapCharBuffer_Cast(x any) *HeapCharBuffer { if x == nil { return nil }; v, ok := x.(*HeapCharBuffer); if !ok { panic(ClassCast(x, HeapCharBuffer_class)) }; return v }
