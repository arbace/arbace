//line java_time_chrono_ChronoLocalDateTimeImpl.ae:1
package jrt


























































func ChronoLocalDateTimeImpl_Of_ChronoLocalDate_LocalTime__ChronoLocalDateTimeImpl(date ChronoLocalDate, time *LocalTime) *ChronoLocalDateTimeImpl {

	return ChronoLocalDateTimeImpl_New_ChronoLocalDate_LocalTime(date, time)
}
func ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(chrono Chronology, temporal Temporal) *ChronoLocalDateTimeImpl {

	var other *ChronoLocalDateTimeImpl = ChronoLocalDateTimeImpl_Cast(temporal)
	if chrono.Equals_O__Z(NN(other).GetChronology__Chronology()) == false {
		panic(Thrown(ClassCastException_New_String(Concat(Lit_2192, chrono.GetId__String(), Lit_2189, NN(other).GetChronology__Chronology().GetId__String())))) }
//line :66:1
	return other
}







func ChronoLocalDateTimeImpl_New_ChronoLocalDate_LocalTime(p0 ChronoLocalDate, p1 *LocalTime) *ChronoLocalDateTimeImpl { t := &ChronoLocalDateTimeImpl{}; t.Ctor_ChronoLocalDate_LocalTime(p0, p1); return t }
//line :75:1
func (t *ChronoLocalDateTimeImpl) Ctor_ChronoLocalDate_LocalTime(date ChronoLocalDate, time *LocalTime) {
	Objects_RequireNonNull_O_String__O(date, Lit_1440)
	Objects_RequireNonNull_O_String__O(time.Ref(), Lit_2051)
	t.F_date = date
	t.F_time = time
}
func (t *ChronoLocalDateTimeImpl) With_Temporal_LocalTime__ChronoLocalDateTimeImpl(newDate Temporal, newTime *LocalTime) *ChronoLocalDateTimeImpl {

	var tmp1 bool; var tmp2 bool; tmp2 = any(t.F_date) == any(newDate); if tmp2 { tmp2 = t.F_time == newTime }; tmp1 = tmp2; if tmp1 { return t } else {

		var cd ChronoLocalDate = ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(t.F_date.GetChronology__Chronology(), newDate)
		return ChronoLocalDateTimeImpl_New_ChronoLocalDate_LocalTime(cd, newTime)
	} }
func (t *ChronoLocalDateTimeImpl) ToLocalDate__ChronoLocalDate() ChronoLocalDate { return t.F_date }

func (t *ChronoLocalDateTimeImpl) ToLocalTime__LocalTime() *LocalTime { return t.F_time }

func (t *ChronoLocalDateTimeImpl) IsSupported_TemporalField__Z(field TemporalField) bool {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1); var tmp2 bool
		tmp2 = NN(chronoField).IsDateBased__Z(); if !tmp2 { tmp2 = NN(chronoField).IsTimeBased__Z() }; return tmp2 } else {
			var tmp3 bool; tmp3 = !(field == nil); if tmp3 { tmp3 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp3
		} }
func (t *ChronoLocalDateTimeImpl) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() { return NN(t.F_time).Range_TemporalField__ValueRange(field) } else { return t.F_date.Range_TemporalField__ValueRange(field) } } else {
			return field.RangeRefinedBy_TemporalAccessor__ValueRange(t)
		} }
func (t *ChronoLocalDateTimeImpl) Get_TemporalField__I(field TemporalField) int32 {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() { return NN(t.F_time).Get_TemporalField__I(field) } else { return t.F_date.Get_TemporalField__I(field) } } else {
			return NN(t.Range_TemporalField__ValueRange(field)).CheckValidIntValue_J_TemporalField__I(t.GetLong_TemporalField__J(field), field)
		} }
func (t *ChronoLocalDateTimeImpl) GetLong_TemporalField__J(field TemporalField) int64 {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() { return NN(t.F_time).GetLong_TemporalField__J(field) } else { return t.F_date.GetLong_TemporalField__J(field) } } else {
			return field.GetFrom_TemporalAccessor__J(t)
		} }
func (t *ChronoLocalDateTimeImpl) With_TemporalAdjuster__ChronoLocalDateTimeImpl(adjuster TemporalAdjuster) *ChronoLocalDateTimeImpl {
	if ChronoLocalDate_InstanceOf(adjuster) {
		return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(ChronoLocalDate_Cast(adjuster), t.F_time) } else {
//line :113:1
			if LocalTime_InstanceOf(adjuster) {

				var tmp1 Temporal = t.F_date; return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(tmp1, LocalTime_Cast(adjuster)) } else {
//line :113:1
					if ChronoLocalDateTimeImpl_InstanceOf(adjuster) {



						return ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(t.F_date.GetChronology__Chronology(), Up_ChronoLocalDateTimeImpl_Temporal(ChronoLocalDateTimeImpl_Cast(adjuster))) } else {


							return ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(t.F_date.GetChronology__Chronology(), Up_ChronoLocalDateTimeImpl_Temporal(ChronoLocalDateTimeImpl_Cast(adjuster.AdjustInto_Temporal__Temporal(t))))
						}
				}
		}
}
func (t *ChronoLocalDateTimeImpl) With_TemporalField_J__ChronoLocalDateTimeImpl(field TemporalField, newValue int64) *ChronoLocalDateTimeImpl {

	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() {
			var tmp2 Temporal = t.F_date; return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(tmp2, NN(t.F_time).With_TemporalField_J__LocalTime(field, newValue)) } else {
				return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(t.F_date.With_TemporalField_J__ChronoLocalDate(field, newValue), t.F_time) } } else {
					return ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(t.F_date.GetChronology__Chronology(), field.AdjustInto_Temporal_J__Temporal(t, newValue))
				} }
func (t *ChronoLocalDateTimeImpl) Plus_J_TemporalUnit__ChronoLocalDateTimeImpl(amountToAdd int64, unit TemporalUnit) *ChronoLocalDateTimeImpl {

	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 0:
			return t.PlusNanos_J__ChronoLocalDateTimeImpl(amountToAdd); case 1:

			return NN(t.PlusDays_J__ChronoLocalDateTimeImpl(amountToAdd / 86400000000)).PlusNanos_J__ChronoLocalDateTimeImpl(amountToAdd % 86400000000 * 1000); case 2:


			return NN(t.PlusDays_J__ChronoLocalDateTimeImpl(amountToAdd / 86400000)).PlusNanos_J__ChronoLocalDateTimeImpl(amountToAdd % 86400000 * 1000000); case 3:

			return t.PlusSeconds_J__ChronoLocalDateTimeImpl(amountToAdd); case 4:
			return t.PlusMinutes_J__ChronoLocalDateTimeImpl(amountToAdd); case 5:
			return t.PlusHours_J__ChronoLocalDateTimeImpl(amountToAdd); case 6:

			return NN(t.PlusDays_J__ChronoLocalDateTimeImpl(amountToAdd / 256)).PlusHours_J__ChronoLocalDateTimeImpl(amountToAdd % 256 * 12); default:

			return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(t.F_date.Plus_J_TemporalUnit__ChronoLocalDate(amountToAdd, unit), t.F_time)} } else {
				return ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(t.F_date.GetChronology__Chronology(), unit.AddTo_Temporal_J__Temporal(t, amountToAdd)) } }; panic("a2g: unreachable")
}
func (t *ChronoLocalDateTimeImpl) PlusDays_J__ChronoLocalDateTimeImpl(days int64) *ChronoLocalDateTimeImpl {
	var tmp1 ChronoLocalDate = t.F_date; var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_DAYS; return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(tmp1.Plus_J_TemporalUnit__ChronoLocalDate(days, Up_ChronoUnit_TemporalUnit(tmp2)), t.F_time)
}
func (t *ChronoLocalDateTimeImpl) PlusHours_J__ChronoLocalDateTimeImpl(hours int64) *ChronoLocalDateTimeImpl {
	return t.PlusWithOverflow_ChronoLocalDate_J_J_J_J__ChronoLocalDateTimeImpl(t.F_date, hours, 0, 0, 0)
}
func (t *ChronoLocalDateTimeImpl) PlusMinutes_J__ChronoLocalDateTimeImpl(minutes int64) *ChronoLocalDateTimeImpl {
	return t.PlusWithOverflow_ChronoLocalDate_J_J_J_J__ChronoLocalDateTimeImpl(t.F_date, 0, minutes, 0, 0)
}
func (t *ChronoLocalDateTimeImpl) PlusSeconds_J__ChronoLocalDateTimeImpl(seconds int64) *ChronoLocalDateTimeImpl {
	return t.PlusWithOverflow_ChronoLocalDate_J_J_J_J__ChronoLocalDateTimeImpl(t.F_date, 0, 0, seconds, 0)
}
func (t *ChronoLocalDateTimeImpl) PlusNanos_J__ChronoLocalDateTimeImpl(nanos int64) *ChronoLocalDateTimeImpl {
	return t.PlusWithOverflow_ChronoLocalDate_J_J_J_J__ChronoLocalDateTimeImpl(t.F_date, 0, 0, 0, nanos)
}
func (t *ChronoLocalDateTimeImpl) PlusWithOverflow_ChronoLocalDate_J_J_J_J__ChronoLocalDateTimeImpl(newDate ChronoLocalDate, hours, minutes, seconds, nanos int64) *ChronoLocalDateTimeImpl {


	if hours|minutes|seconds|nanos == 0 {
		return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(newDate, t.F_time) } else {
			var tmp1 int64 = nanos / 86400000000000; var tmp2 int64 = tmp1 + seconds/86400; var tmp3 int64 = tmp2 + minutes/1440; var totDays int64 = tmp3 + hours/24; var tmp4 int64 = nanos % 86400000000000; var tmp5 int64 = tmp4 + seconds%86400*1000000000; var tmp6 int64 = tmp5 + minutes%1440*60000000000; var totNanos int64 = tmp6 + hours%24*3600000000000; var curNoD int64 = NN(t.F_time).ToNanoOfDay__J()




















			totNanos = totNanos + curNoD
			totDays = totDays + Math_FloorDiv_J_J__J(totNanos, 86400000000000)
			var newNoD int64 = Math_FloorMod_J_J__J(totNanos, 86400000000000); var newTime *LocalTime
			if newNoD == curNoD { newTime = t.F_time } else { newTime = LocalTime_OfNanoOfDay_J__LocalTime(newNoD) }
			var tmp7 int64 = totDays; var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_DAYS; return t.With_Temporal_LocalTime__ChronoLocalDateTimeImpl(newDate.Plus_J_TemporalUnit__ChronoLocalDate(tmp7, Up_ChronoUnit_TemporalUnit(tmp8)), newTime)
		} }
func (t *ChronoLocalDateTimeImpl) AtZone_ZoneId__ChronoZonedDateTime(zone ZoneId_I) ChronoZonedDateTime {
	return ChronoZonedDateTimeImpl_OfBest_ChronoLocalDateTimeImpl_ZoneId_ZoneOffset__ChronoZonedDateTime(t, zone, nil)
}
func (t *ChronoLocalDateTimeImpl) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	Objects_RequireNonNull_O_String__O(endExclusive, Lit_2035)
	var end ChronoLocalDateTime = t.GetChronology__Chronology().LocalDateTime_TemporalAccessor__ChronoLocalDateTime(endExclusive); var tmp1 TemporalUnit = unit
	if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		if unit.IsTimeBased__Z() {
			var amount int64; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_EPOCH_DAY; var tmp3 int64 = end.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2)); var tmp4 ChronoLocalDate = t.F_date; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_EPOCH_DAY; amount = tmp3 - tmp4.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp5))


			switch NN(chronoUnit).F_ordinal { case 0:
				amount = Math_MultiplyExact_J_J__J(amount, 86400000000000); case 1:
				amount = Math_MultiplyExact_J_J__J(amount, 86400000000); case 2:
				amount = Math_MultiplyExact_J_J__J(amount, 86400000); case 3:
				amount = Math_MultiplyExact_J_I__J(amount, 86400); case 4:
				amount = Math_MultiplyExact_J_I__J(amount, 1440); case 5:
				amount = Math_MultiplyExact_J_I__J(amount, 24); case 6:
				amount = Math_MultiplyExact_J_I__J(amount, 2); default:}
			var tmp6 *LocalTime = t.F_time; return Math_AddExact_J_J__J(amount, NN(tmp6).Until_Temporal_TemporalUnit__J(Up_LocalTime_Temporal(end.ToLocalTime__LocalTime()), unit)) } else {
				var endDate ChronoLocalDate = end.ToLocalDate__ChronoLocalDate()
				if NN(end.ToLocalTime__LocalTime()).IsBefore_LocalTime__Z(t.F_time) {
					var tmp7 ChronoLocalDate = endDate; var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_DAYS; endDate = tmp7.Minus_J_TemporalUnit__ChronoLocalDate(1, Up_ChronoUnit_TemporalUnit(tmp8)) }
				return t.F_date.Until_Temporal_TemporalUnit__J(endDate, unit) } } else {
					Objects_RequireNonNull_O_String__O(unit, Lit_1921); return unit.Between_Temporal_Temporal__J(t, end)
				} }
func (t *ChronoLocalDateTimeImpl) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.chrono.ChronoLocalDateTimeImpl.writeReplace()Ljava/lang/Object;")) }














func (t *ChronoLocalDateTimeImpl) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if ChronoLocalDateTime_InstanceOf(obj) {

		return t.CompareTo_ChronoLocalDateTime__I(ChronoLocalDateTime_Cast(obj)) == 0 } else {
//line :242:1
			return false
		}
	}
}

func (t *ChronoLocalDateTimeImpl) HashCode__I() int32 {
	return t.ToLocalDate__ChronoLocalDate().HashCode__I() ^ NN(t.ToLocalTime__LocalTime()).HashCode__I()
}
func (t *ChronoLocalDateTimeImpl) ToString__String() *String {
	return Concat(t.ToLocalDate__ChronoLocalDate().ToString__String(), Lit_2193, NN(t.ToLocalTime__LocalTime()).ToString__String())
}


type ChronoLocalDateTimeImpl struct{ Object; F_date ChronoLocalDate; F_time *LocalTime }

func (t *ChronoLocalDateTimeImpl) Is_ChronoLocalDateTime() {}

func (t *ChronoLocalDateTimeImpl) Is_Temporal() {}

func (t *ChronoLocalDateTimeImpl) Is_TemporalAdjuster() {}

func (t *ChronoLocalDateTimeImpl) Is_Serializable() {}

func (t *ChronoLocalDateTimeImpl) Is_Comparable() {}

func (t *ChronoLocalDateTimeImpl) Is_TemporalAccessor() {}

const ChronoLocalDateTimeImpl_serialVersionUID int64 = 4556003607393004514

const ChronoLocalDateTimeImpl_HOURS_PER_DAY int32 = 24

const ChronoLocalDateTimeImpl_MINUTES_PER_HOUR int32 = 60

const ChronoLocalDateTimeImpl_MINUTES_PER_DAY int32 = 1440

const ChronoLocalDateTimeImpl_SECONDS_PER_MINUTE int32 = 60

const ChronoLocalDateTimeImpl_SECONDS_PER_HOUR int32 = 3600

const ChronoLocalDateTimeImpl_SECONDS_PER_DAY int32 = 86400

const ChronoLocalDateTimeImpl_MILLIS_PER_DAY int64 = 86400000

const ChronoLocalDateTimeImpl_MICROS_PER_DAY int64 = 86400000000

const ChronoLocalDateTimeImpl_NANOS_PER_SECOND int64 = 1000000000

const ChronoLocalDateTimeImpl_NANOS_PER_MINUTE int64 = 60000000000

const ChronoLocalDateTimeImpl_NANOS_PER_HOUR int64 = 3600000000000

const ChronoLocalDateTimeImpl_NANOS_PER_DAY int64 = 86400000000000

func (t *ChronoLocalDateTimeImpl) With_TemporalAdjuster__ChronoLocalDateTime(p0 TemporalAdjuster) ChronoLocalDateTime { return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(t.With_TemporalAdjuster__ChronoLocalDateTimeImpl(p0)) }

func (t *ChronoLocalDateTimeImpl) With_TemporalField_J__ChronoLocalDateTime(p0 TemporalField, p1 int64) ChronoLocalDateTime { return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(t.With_TemporalField_J__ChronoLocalDateTimeImpl(p0, p1)) }

func (t *ChronoLocalDateTimeImpl) Plus_J_TemporalUnit__ChronoLocalDateTime(p0 int64, p1 TemporalUnit) ChronoLocalDateTime { return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(t.Plus_J_TemporalUnit__ChronoLocalDateTimeImpl(p0, p1)) }

func (t *ChronoLocalDateTimeImpl) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_ChronoLocalDateTimeImpl_Temporal(t.With_TemporalAdjuster__ChronoLocalDateTimeImpl(p0)) }

func (t *ChronoLocalDateTimeImpl) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_ChronoLocalDateTimeImpl_Temporal(t.With_TemporalField_J__ChronoLocalDateTimeImpl(p0, p1)) }

func (t *ChronoLocalDateTimeImpl) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_ChronoLocalDateTimeImpl_Temporal(t.Plus_J_TemporalUnit__ChronoLocalDateTimeImpl(p0, p1)) }

func (t *ChronoLocalDateTimeImpl) ToInstant_ZoneOffset__Instant(p0 *ZoneOffset) *Instant { return ChronoLocalDateTime_ToInstant_ZoneOffset__Instant(t, p0) }

func (t *ChronoLocalDateTimeImpl) ToEpochSecond_ZoneOffset__J(p0 *ZoneOffset) int64 { return ChronoLocalDateTime_ToEpochSecond_ZoneOffset__J(t, p0) }

func (t *ChronoLocalDateTimeImpl) Plus_TemporalAmount__ChronoLocalDateTime(p0 TemporalAmount) ChronoLocalDateTime { return ChronoLocalDateTime_Plus_TemporalAmount__ChronoLocalDateTime(t, p0) }

func (t *ChronoLocalDateTimeImpl) Minus_TemporalAmount__ChronoLocalDateTime(p0 TemporalAmount) ChronoLocalDateTime { return ChronoLocalDateTime_Minus_TemporalAmount__ChronoLocalDateTime(t, p0) }

func (t *ChronoLocalDateTimeImpl) IsEqual_ChronoLocalDateTime__Z(p0 ChronoLocalDateTime) bool { return ChronoLocalDateTime_IsEqual_ChronoLocalDateTime__Z(t, p0) }

func (t *ChronoLocalDateTimeImpl) Format_DateTimeFormatter__String(p0 *DateTimeFormatter) *String { return ChronoLocalDateTime_Format_DateTimeFormatter__String(t, p0) }

func (t *ChronoLocalDateTimeImpl) AdjustInto_Temporal__Temporal(p0 Temporal) Temporal { return ChronoLocalDateTime_AdjustInto_Temporal__Temporal(t, p0) }

func (t *ChronoLocalDateTimeImpl) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return ChronoLocalDateTime_Minus_TemporalAmount__Temporal(t, p0) }

func (t *ChronoLocalDateTimeImpl) IsBefore_ChronoLocalDateTime__Z(p0 ChronoLocalDateTime) bool { return ChronoLocalDateTime_IsBefore_ChronoLocalDateTime__Z(t, p0) }

func (t *ChronoLocalDateTimeImpl) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return ChronoLocalDateTime_Plus_TemporalAmount__Temporal(t, p0) }

func (t *ChronoLocalDateTimeImpl) Minus_J_TemporalUnit__ChronoLocalDateTime(p0 int64, p1 TemporalUnit) ChronoLocalDateTime { return ChronoLocalDateTime_Minus_J_TemporalUnit__ChronoLocalDateTime(t, p0, p1) }

func (t *ChronoLocalDateTimeImpl) CompareTo_ChronoLocalDateTime__I(p0 ChronoLocalDateTime) int32 { return ChronoLocalDateTime_CompareTo_ChronoLocalDateTime__I(t, p0) }

func (t *ChronoLocalDateTimeImpl) Query_TemporalQuery__O(p0 TemporalQuery) any { return ChronoLocalDateTime_Query_TemporalQuery__O(t, p0) }

func (t *ChronoLocalDateTimeImpl) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return ChronoLocalDateTime_Minus_J_TemporalUnit__Temporal(t, p0, p1) }

func (t *ChronoLocalDateTimeImpl) IsAfter_ChronoLocalDateTime__Z(p0 ChronoLocalDateTime) bool { return ChronoLocalDateTime_IsAfter_ChronoLocalDateTime__Z(t, p0) }

func (t *ChronoLocalDateTimeImpl) CompareTo_O__I(p0 any) int32 { return ChronoLocalDateTime_CompareTo_O__I(t, p0) }

func (t *ChronoLocalDateTimeImpl) IsSupported_TemporalUnit__Z(p0 TemporalUnit) bool { return ChronoLocalDateTime_IsSupported_TemporalUnit__Z(t, p0) }

func (t *ChronoLocalDateTimeImpl) GetChronology__Chronology() Chronology { return ChronoLocalDateTime_GetChronology__Chronology(t) }

func (t *ChronoLocalDateTimeImpl) Ref() any { if t == nil { return nil }; return t }

func (t *ChronoLocalDateTimeImpl) GetClass__Class() *Class { return ChronoLocalDateTimeImpl_class }

func (t *ChronoLocalDateTimeImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ChronoLocalDateTimeImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ChronoLocalDateTimeImpl_InstanceOf(x any) bool { _, ok := x.(*ChronoLocalDateTimeImpl); return ok }

func ChronoLocalDateTimeImpl_Cast(x any) *ChronoLocalDateTimeImpl { if x == nil { return nil }; v, ok := x.(*ChronoLocalDateTimeImpl); if !ok { panic(ClassCast(x, ChronoLocalDateTimeImpl_class)) }; return v }
