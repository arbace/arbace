//line java_time_temporal_TemporalAdjusters.ae:1
package jrt








func TemporalAdjusters_New() *TemporalAdjusters { t := &TemporalAdjusters{}; t.Ctor(); return t }
//line :10:1
func (t *TemporalAdjusters) Ctor() { panic(A2g_NotTranslated("java.time.temporal.TemporalAdjusters.<init>()V")) }

func TemporalAdjusters_OfDateAdjuster_UnaryOperator__TemporalAdjuster(dateBasedAdjuster UnaryOperator) TemporalAdjuster {
	Objects_RequireNonNull_O_String__O(dateBasedAdjuster, Lit_2518)
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 Temporal; var input *LocalDate = LocalDate_From_TemporalAccessor__LocalDate(temporal); var output *LocalDate = LocalDate_Cast(dateBasedAdjuster.Apply_O__O(input.Ref())); tmp1 =


		temporal.With_TemporalAdjuster__Temporal(Up_LocalDate_TemporalAdjuster(output)); return tmp1 },
	} }
func TemporalAdjusters_FirstDayOfMonth__TemporalAdjuster() TemporalAdjuster {
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_MONTH; return temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp1), 1) }}
}

func TemporalAdjusters_LastDayOfMonth__TemporalAdjuster() TemporalAdjuster {
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_MONTH; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_MONTH; return temporal.With_TemporalField_J__Temporal(tmp2, NN(temporal.Range_TemporalField__ValueRange(Up_ChronoField_TemporalField(tmp3))).GetMaximum__J()) }}
}



func TemporalAdjusters_FirstDayOfNextMonth__TemporalAdjuster() TemporalAdjuster {
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_MONTH; var tmp2 Temporal = temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp1), 1); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_MONTHS; return tmp2.Plus_J_TemporalUnit__Temporal(1, Up_ChronoUnit_TemporalUnit(tmp3)) }}
}

func TemporalAdjusters_FirstDayOfYear__TemporalAdjuster() TemporalAdjuster {
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_YEAR; return temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp1), 1) }}
}

func TemporalAdjusters_LastDayOfYear__TemporalAdjuster() TemporalAdjuster {
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_YEAR; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_YEAR; return temporal.With_TemporalField_J__Temporal(tmp2, NN(temporal.Range_TemporalField__ValueRange(Up_ChronoField_TemporalField(tmp3))).GetMaximum__J()) }}
}



func TemporalAdjusters_FirstDayOfNextYear__TemporalAdjuster() TemporalAdjuster {
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_YEAR; var tmp2 Temporal = temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp1), 1); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_YEARS; return tmp2.Plus_J_TemporalUnit__Temporal(1, Up_ChronoUnit_TemporalUnit(tmp3)) }}
}

func TemporalAdjusters_FirstInMonth_DayOfWeek__TemporalAdjuster(dayOfWeek *DayOfWeek) TemporalAdjuster {
	return TemporalAdjusters_DayOfWeekInMonth_I_DayOfWeek__TemporalAdjuster(1, dayOfWeek)
}
func TemporalAdjusters_LastInMonth_DayOfWeek__TemporalAdjuster(dayOfWeek *DayOfWeek) TemporalAdjuster {
	return TemporalAdjusters_DayOfWeekInMonth_I_DayOfWeek__TemporalAdjuster(-1, dayOfWeek)
}
func TemporalAdjusters_DayOfWeekInMonth_I_DayOfWeek__TemporalAdjuster(ordinal int32, dayOfWeek *DayOfWeek) TemporalAdjuster {
	Objects_RequireNonNull_O_String__O(dayOfWeek.Ref(), Lit_2519)
	var dowValue int32 = NN(dayOfWeek).GetValue__I()
	if ordinal >= 0 {
		return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 Temporal; var temp Temporal; var tmp2 *ChronoField;
			ChronoField_Init(); tmp2 = ChronoField_DAY_OF_MONTH; temp = temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp2), 1); var curDow int32; var tmp3 *ChronoField;
			ChronoField_Init(); tmp3 = ChronoField_DAY_OF_WEEK; curDow = temp.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp3)); var dowDiff int32 = /*line :58:1*/(dowValue - curDow + 7) % 7; dowDiff =




			dowDiff + int32((int64(ordinal)-1)*7); var tmp4 int64 =



			int64(dowDiff); var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; tmp1 = temp.Plus_J_TemporalUnit__Temporal(tmp4, Up_ChronoUnit_TemporalUnit(tmp5)); return tmp1 }} } else {
				return &TemporalAdjuster_Fn{Fn: func(p0_2 Temporal) Temporal { var temporal_2 Temporal = p0_2; var tmp6 Temporal; var temp_2 Temporal; var tmp7 *ChronoField;
					ChronoField_Init(); tmp7 = ChronoField_DAY_OF_MONTH; var tmp8 TemporalField = Up_ChronoField_TemporalField(tmp7); var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_DAY_OF_MONTH; temp_2 = temporal_2.With_TemporalField_J__Temporal(tmp8, NN(temporal_2.Range_TemporalField__ValueRange(Up_ChronoField_TemporalField(tmp9))).GetMaximum__J()); var curDow_2 int32; var tmp10 *ChronoField;


					ChronoField_Init(); tmp10 = ChronoField_DAY_OF_WEEK; curDow_2 = temp_2.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp10)); var daysDiff int32 = /*line :69:1*/dowValue - curDow_2; var tmp11 int32; if





					daysDiff == 0 { tmp11 = 0 } else { if daysDiff > 0 {

						tmp11 = daysDiff - 7 } else {
//line :75:1
							tmp11 = daysDiff } }; daysDiff = tmp11; daysDiff =



					daysDiff - int32((int64(-ordinal)-1)*7); var tmp12 int64 =







					int64(daysDiff); var tmp13 *ChronoUnit; ChronoUnit_Init(); tmp13 = ChronoUnit_DAYS; tmp6 = temp_2.Plus_J_TemporalUnit__Temporal(tmp12, Up_ChronoUnit_TemporalUnit(tmp13)); return tmp6 },
				} } }
func TemporalAdjusters_Next_DayOfWeek__TemporalAdjuster(dayOfWeek *DayOfWeek) TemporalAdjuster {
	var dowValue int32 = NN(dayOfWeek).GetValue__I()
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 Temporal; var calDow int32; var tmp2 *ChronoField;
		ChronoField_Init(); tmp2 = ChronoField_DAY_OF_WEEK; calDow = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)); var daysDiff int32 = calDow - dowValue; var tmp3 int64; if


		daysDiff >= 0 { tmp3 = int64(7 - daysDiff) } else { tmp3 = int64(-daysDiff) }; var tmp4 int64 = tmp3; var tmp5 /*line :94:1*/*ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; tmp1 = temporal.Plus_J_TemporalUnit__Temporal(tmp4, Up_ChronoUnit_TemporalUnit(tmp5)); return tmp1 },
	}
}



func TemporalAdjusters_NextOrSame_DayOfWeek__TemporalAdjuster(dayOfWeek *DayOfWeek) TemporalAdjuster {
	var dowValue int32 = NN(dayOfWeek).GetValue__I()
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 Temporal; var calDow int32; var tmp2 *ChronoField;
		ChronoField_Init(); tmp2 = ChronoField_DAY_OF_WEEK; calDow = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)); if
		calDow == dowValue { tmp1 = temporal } else {

			var daysDiff int32 = calDow - dowValue; var tmp3 int64

			if daysDiff >= 0 { tmp3 = int64(7 - daysDiff) } else { tmp3 = int64(-daysDiff) }
//line :107:1
			var tmp4 int64 = tmp3; var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; tmp1 = temporal.Plus_J_TemporalUnit__Temporal(tmp4, Up_ChronoUnit_TemporalUnit(tmp5)) }; return tmp1 },
	}
}



func TemporalAdjusters_Previous_DayOfWeek__TemporalAdjuster(dayOfWeek *DayOfWeek) TemporalAdjuster {
	var dowValue int32 = NN(dayOfWeek).GetValue__I()
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 Temporal; var calDow int32; var tmp2 *ChronoField;
		ChronoField_Init(); tmp2 = ChronoField_DAY_OF_WEEK; calDow = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)); var daysDiff int32 = dowValue - calDow; var tmp3 int64; if


		daysDiff >= 0 { tmp3 = int64(7 - daysDiff) } else { tmp3 = int64(-daysDiff) }; var tmp4 int64 = tmp3; var tmp5 /*line :118:1*/*ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; tmp1 = temporal.Minus_J_TemporalUnit__Temporal(tmp4, Up_ChronoUnit_TemporalUnit(tmp5)); return tmp1 },
	}
}



func TemporalAdjusters_PreviousOrSame_DayOfWeek__TemporalAdjuster(dayOfWeek *DayOfWeek) TemporalAdjuster {
	var dowValue int32 = NN(dayOfWeek).GetValue__I()
	return &TemporalAdjuster_Fn{Fn: func(p0 Temporal) Temporal { var temporal Temporal = p0; var tmp1 Temporal; var calDow int32; var tmp2 *ChronoField;
		ChronoField_Init(); tmp2 = ChronoField_DAY_OF_WEEK; calDow = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)); if
		calDow == dowValue { tmp1 = temporal } else {

			var daysDiff int32 = dowValue - calDow; var tmp3 int64

			if daysDiff >= 0 { tmp3 = int64(7 - daysDiff) } else { tmp3 = int64(-daysDiff) }
//line :131:1
			var tmp4 int64 = tmp3; var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; tmp1 = temporal.Minus_J_TemporalUnit__Temporal(tmp4, Up_ChronoUnit_TemporalUnit(tmp5)) }; return tmp1 },
	}
}


type TemporalAdjusters struct{ Object }

func (t *TemporalAdjusters) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalAdjusters) GetClass__Class() *Class { return TemporalAdjusters_class }

func (t *TemporalAdjusters) ToString__String() *String { return Object_toString(t) }

func (t *TemporalAdjusters) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalAdjusters) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalAdjusters_InstanceOf(x any) bool { _, ok := x.(*TemporalAdjusters); return ok }

func TemporalAdjusters_Cast(x any) *TemporalAdjusters { if x == nil { return nil }; v, ok := x.(*TemporalAdjusters); if !ok { panic(ClassCast(x, TemporalAdjusters_class)) }; return v }
