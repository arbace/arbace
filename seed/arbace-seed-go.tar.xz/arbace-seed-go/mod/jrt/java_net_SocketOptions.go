//line java_net_SocketOptions.ae:1
package jrt






type SocketOptions interface{ Object_I; Is_SocketOptions(); SetOption_I_O__V(p0 int32, p1 any); GetOption_I__O(p0 int32) any }

const SocketOptions_TCP_NODELAY int32 = 1

const SocketOptions_SO_BINDADDR int32 = 15

const SocketOptions_SO_REUSEADDR int32 = 4

const SocketOptions_SO_REUSEPORT int32 = 14

const SocketOptions_SO_BROADCAST int32 = 32

const SocketOptions_IP_MULTICAST_IF int32 = 16

const SocketOptions_IP_MULTICAST_IF2 int32 = 31

const SocketOptions_IP_MULTICAST_LOOP int32 = 18

const SocketOptions_IP_TOS int32 = 3

const SocketOptions_SO_LINGER int32 = 128

const SocketOptions_SO_TIMEOUT int32 = 4102

const SocketOptions_SO_SNDBUF int32 = 4097

const SocketOptions_SO_RCVBUF int32 = 4098

const SocketOptions_SO_KEEPALIVE int32 = 8

const SocketOptions_SO_OOBINLINE int32 = 4099

func SocketOptions_InstanceOf(x any) bool { _, ok := x.(SocketOptions); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SocketOptions_class) } }; return ok }

func SocketOptions_Cast(x any) SocketOptions { if x == nil { return nil }; v, ok := x.(SocketOptions); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SocketOptions_class) } }; if !ok { panic(ClassCast(x, SocketOptions_class)) }; return v }
