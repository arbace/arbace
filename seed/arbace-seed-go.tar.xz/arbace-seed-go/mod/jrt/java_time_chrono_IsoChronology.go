//line java_time_chrono_IsoChronology.ae:1
package jrt






























func IsoChronology_New() *IsoChronology { IsoChronology_Init(); t := &IsoChronology{}; t.Ctor(); return t }
//line :32:1
func (t *IsoChronology) Ctor() { t.AbstractChronology.Ctor(t) }

func (t *IsoChronology) GetId__String() *String { return Lit_2175 }

func (t *IsoChronology) GetCalendarType__String() *String { return Lit_2179 }

func (t *IsoChronology) Date_Era_I_I_I__LocalDate(era Era, yearOfEra, month, dayOfMonth int32) *LocalDate {
	return t.Date_I_I_I__LocalDate(t.ProlepticYear_Era_I__I(era, yearOfEra), month, dayOfMonth)
}
func (t *IsoChronology) Date_I_I_I__LocalDate(prolepticYear, month, dayOfMonth int32) *LocalDate {
	return LocalDate_Of_I_I_I__LocalDate(prolepticYear, month, dayOfMonth)
}
func (t *IsoChronology) DateYearDay_Era_I_I__LocalDate(era Era, yearOfEra, dayOfYear int32) *LocalDate {
	return t.DateYearDay_I_I__LocalDate(t.ProlepticYear_Era_I__I(era, yearOfEra), dayOfYear)
}
func (t *IsoChronology) DateYearDay_I_I__LocalDate(prolepticYear, dayOfYear int32) *LocalDate {
	return LocalDate_OfYearDay_I_I__LocalDate(prolepticYear, dayOfYear)
}
func (t *IsoChronology) DateEpochDay_J__LocalDate(epochDay int64) *LocalDate {
	return LocalDate_OfEpochDay_J__LocalDate(epochDay)
}
func (t *IsoChronology) Date_TemporalAccessor__LocalDate(temporal TemporalAccessor) *LocalDate {
	return LocalDate_From_TemporalAccessor__LocalDate(temporal)
}
func (t *IsoChronology) EpochSecond_I_I_I_I_I_I_ZoneOffset__J(prolepticYear, month, dayOfMonth, hour, minute, second int32, zoneOffset *ZoneOffset) int64 {

	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(prolepticYear))
	var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; NN(tmp2).CheckValidValue_J__J(int64(month))
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_MONTH; NN(tmp3).CheckValidValue_J__J(int64(dayOfMonth))
	var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_HOUR_OF_DAY; NN(tmp4).CheckValidValue_J__J(int64(hour))
	var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MINUTE_OF_HOUR; NN(tmp5).CheckValidValue_J__J(int64(minute))
	var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_SECOND_OF_MINUTE; NN(tmp6).CheckValidValue_J__J(int64(second))
	Objects_RequireNonNull_O_String__O(zoneOffset.Ref(), Lit_2200)
	if dayOfMonth > 28 {
		var dom int32 = t.NumberOfDaysOfMonth_I_I__I(prolepticYear, month)
		if dayOfMonth > dom {
			if dayOfMonth == 29 {
				panic(Thrown(DateTimeException_New_String(Concat(Lit_2042, StrOfInt(prolepticYear), Lit_2038)))) } else {



					panic(Thrown(DateTimeException_New_String(Concat(Lit_2043, NN(Month_Of_I__Month(month)).Name__String(), Lit_115, StrOfInt(dayOfMonth), Lit_1371))))
				} } }
	var totalDays int64 = 0
	var timeinSec int32 = 0
	totalDays = totalDays + 365*int64(prolepticYear)
	if prolepticYear >= 0 {
		var tmp7 int64 = (int64(prolepticYear) + 3) / 4; var tmp8 int64 = tmp7 - (int64(prolepticYear)+99)/100; totalDays = totalDays + (tmp8 + (int64(prolepticYear)+399)/400) } else {






			var tmp9 int32 = prolepticYear / -4; var tmp10 int32 = tmp9 - prolepticYear/-100; totalDays = totalDays - int64(tmp10+prolepticYear/-400)
		}





	totalDays = totalDays + int64((367*month-362)/12)




	totalDays = totalDays + int64(dayOfMonth-1)
	if month > 2 {
		totalDays = totalDays - 1
		if NN(IsoChronology_INSTANCE).IsLeapYear_J__Z(int64(prolepticYear)) == false {
			totalDays = totalDays - 1 } }
	totalDays = totalDays - 719528
	timeinSec = (hour*60+minute)*60 + second




	return Math_AddExact_J_J__J(Math_MultiplyExact_J_J__J(totalDays, 86400), int64(timeinSec-NN(zoneOffset).GetTotalSeconds__I()))
}

func (t *IsoChronology) NumberOfDaysOfMonth_I_I__I(year, month int32) int32 {
	var dom int32 = 0
	switch month { case 2:
		var tmp1 int32; if NN(IsoChronology_INSTANCE).IsLeapYear_J__Z(int64(year)) { tmp1 = 29 } else { tmp1 = 28 }; dom = tmp1; case 4, 6, 9, 11:
		dom = 30; default:
		dom = 31}
//line :113:1
	return dom
}





func (t *IsoChronology) LocalDateTime_TemporalAccessor__LocalDateTime(temporal TemporalAccessor) *LocalDateTime {
	return LocalDateTime_From_TemporalAccessor__LocalDateTime(temporal)
}
func (t *IsoChronology) ZonedDateTime_TemporalAccessor__ZonedDateTime(temporal TemporalAccessor) *ZonedDateTime {
	return ZonedDateTime_From_TemporalAccessor__ZonedDateTime(temporal)
}
func (t *IsoChronology) ZonedDateTime_Instant_ZoneId__ZonedDateTime(instant *Instant, zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_OfInstant_Instant_ZoneId__ZonedDateTime(instant, zone)
}
func (t *IsoChronology) DateNow__LocalDate() *LocalDate {
	return t.DateNow_Clock__LocalDate(Clock_SystemDefaultZone__Clock())
}
func (t *IsoChronology) DateNow_ZoneId__LocalDate(zone ZoneId_I) *LocalDate {
	return t.DateNow_Clock__LocalDate(Clock_System_ZoneId__Clock(zone))
}
func (t *IsoChronology) DateNow_Clock__LocalDate(clock Clock_I) *LocalDate {
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	return t.Date_TemporalAccessor__LocalDate(Up_LocalDate_TemporalAccessor(LocalDate_Now_Clock__LocalDate(clock)))
}
func (t *IsoChronology) IsLeapYear_J__Z(prolepticYear int64) bool {
	return Year_IsLeap_J__Z(prolepticYear)
}
func (t *IsoChronology) ProlepticYear_Era_I__I(era Era, yearOfEra int32) int32 {
	if IsoEra_InstanceOf(era) { } else { panic(Thrown(ClassCastException_New_String(Lit_2201))) }
	var tmp1 *IsoEra; IsoEra_Init(); tmp1 = IsoEra_CE; if any(era) == any(tmp1.Ref()) { return yearOfEra } else { return 1 - yearOfEra
	} }
func (t *IsoChronology) EraOf_I__IsoEra(eraValue int32) *IsoEra {
	return IsoEra_Of_I__IsoEra(eraValue)
}
func (t *IsoChronology) Eras__List() List {
	return List_Of_O1__List(IsoEra_Values__IsoEra1())
}
func (t *IsoChronology) ResolveDate_Map_ResolverStyle__LocalDate(fieldValues Map, resolverStyle *ResolverStyle) *LocalDate {

	return LocalDate_Cast(t.AbstractChronology.Impl_ResolveDate_Map_ResolverStyle__ChronoLocalDate(t, fieldValues, resolverStyle))
}
func (t *IsoChronology) ResolveProlepticMonth_Map_ResolverStyle__V(fieldValues Map, resolverStyle *ResolverStyle) {

	var pMonth *Long; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_PROLEPTIC_MONTH; pMonth = Long_Cast(fieldValues.Remove_O__O(tmp1.Ref()))
	if !(pMonth == nil) {
		var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_LENIENT; if resolverStyle == tmp2 { } else {
			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_PROLEPTIC_MONTH; var tmp4 *ChronoField = tmp3; NN(tmp4).CheckValidValue_J__J(NN(pMonth).LongValue__J()) }
		var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MONTH_OF_YEAR; var tmp6 *ChronoField = tmp5; t.AddFieldValue_Map_ChronoField_J__V(fieldValues, tmp6, int64(Math_FloorMod_J_I__I(NN(pMonth).LongValue__J(), 12)+1))



		var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_YEAR; var tmp8 *ChronoField = tmp7; t.AddFieldValue_Map_ChronoField_J__V(fieldValues, tmp8, Math_FloorDiv_J_I__J(NN(pMonth).LongValue__J(), 12))
	} }
func (t *IsoChronology) ResolveYearOfEra_Map_ResolverStyle__LocalDate(fieldValues Map, resolverStyle *ResolverStyle) *LocalDate {

	var yoeLong *Long; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR_OF_ERA; yoeLong = Long_Cast(fieldValues.Remove_O__O(tmp1.Ref()))
	if !(yoeLong == nil) {


		var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_LENIENT; if resolverStyle == tmp2 { } else {
			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR_OF_ERA; var tmp4 *ChronoField = tmp3; NN(tmp4).CheckValidValue_J__J(NN(yoeLong).LongValue__J()) }
		var era *Long; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_ERA; era = Long_Cast(fieldValues.Remove_O__O(tmp5.Ref()))
		if era == nil {

			var year *Long; var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_YEAR; year = Long_Cast(fieldValues.Get_O__O(tmp6.Ref()))
			var tmp7 *ResolverStyle; ResolverStyle_Init(); tmp7 = ResolverStyle_STRICT; if resolverStyle == tmp7 {
				if !(year == nil) {
					var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_YEAR; var tmp9 *ChronoField = tmp8; var tmp10 int64


					if NN(year).LongValue__J() > 0 {
						tmp10 = NN(yoeLong).LongValue__J() } else {
							tmp10 = Math_SubtractExact_J_J__J(1, NN(yoeLong).LongValue__J()) }
//line :182:1
					t.AddFieldValue_Map_ChronoField_J__V(fieldValues, tmp9, tmp10)



				} else {

					var tmp11 *ChronoField; ChronoField_Init(); tmp11 = ChronoField_YEAR_OF_ERA; fieldValues.Put_O_O__O(tmp11.Ref(), yoeLong.Ref()) } } else {
						var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_YEAR; var tmp13 *ChronoField = tmp12; var tmp14 int64; var tmp15 bool; var tmp16 bool


						tmp16 = year == nil; if !tmp16 { tmp16 = NN(year).LongValue__J() > 0 }; tmp15 = tmp16; if tmp15 {
							tmp14 = NN(yoeLong).LongValue__J() } else {
								tmp14 = Math_SubtractExact_J_J__J(1, NN(yoeLong).LongValue__J()) }
//line :189:1
						t.AddFieldValue_Map_ChronoField_J__V(fieldValues, tmp13, tmp14)
					}


		} else {
//line :177:1
			if NN(era).LongValue__J() == 1 {

















				var tmp17 *ChronoField; ChronoField_Init(); tmp17 = ChronoField_YEAR; var tmp18 *ChronoField = tmp17; t.AddFieldValue_Map_ChronoField_J__V(fieldValues, tmp18, NN(yoeLong).LongValue__J()) } else {
//line :177:1
					if NN(era).LongValue__J() == 0 {



















						var tmp19 *ChronoField; ChronoField_Init(); tmp19 = ChronoField_YEAR; var tmp20 *ChronoField = tmp19; t.AddFieldValue_Map_ChronoField_J__V(fieldValues, tmp20, Math_SubtractExact_J_J__J(1, NN(yoeLong).LongValue__J())) } else {
							panic(Thrown(DateTimeException_New_String(Concat(Lit_2202, StrOfObj(era.Ref()))))) } } } } else {
//line :171:1
								var tmp21 *ChronoField; ChronoField_Init(); tmp21 = ChronoField_ERA; if fieldValues.ContainsKey_O__Z(tmp21.Ref()) {




























									var tmp22 *ChronoField; ChronoField_Init(); tmp22 = ChronoField_ERA; var tmp23 *ChronoField = tmp22; var tmp24 *ChronoField; ChronoField_Init(); tmp24 = ChronoField_ERA; NN(tmp23).CheckValidValue_J__J(NN(Long_Cast(fieldValues.Get_O__O(tmp24.Ref()))).LongValue__J()) } }
//line :170:1
	return nil
}
































func (t *IsoChronology) ResolveYMD_Map_ResolverStyle__LocalDate(fieldValues Map, resolverStyle *ResolverStyle) *LocalDate {

	var y int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ChronoField = tmp1; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; y = NN(tmp2).CheckValidIntValue_J__I(NN(Long_Cast(fieldValues.Remove_O__O(tmp3.Ref()))).LongValue__J())

	var tmp4 *ResolverStyle; ResolverStyle_Init(); tmp4 = ResolverStyle_LENIENT; if resolverStyle == tmp4 {
		var months int64; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MONTH_OF_YEAR; months = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp5.Ref()))).LongValue__J(), 1); var days int64; var tmp6 *ChronoField


		ChronoField_Init(); tmp6 = ChronoField_DAY_OF_MONTH; days = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp6.Ref()))).LongValue__J(), 1)


		return NN(NN(LocalDate_Of_I_I_I__LocalDate(y, 1, 1)).PlusMonths_J__LocalDate(months)).PlusDays_J__LocalDate(days) } else {
			var moy int32; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_MONTH_OF_YEAR; var tmp8 *ChronoField = tmp7; var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_MONTH_OF_YEAR; moy = NN(tmp8).CheckValidIntValue_J__I(NN(Long_Cast(fieldValues.Remove_O__O(tmp9.Ref()))).LongValue__J()); var dom int32; var tmp10 *ChronoField




			ChronoField_Init(); tmp10 = ChronoField_DAY_OF_MONTH; var tmp11 *ChronoField = tmp10; var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_DAY_OF_MONTH; dom = NN(tmp11).CheckValidIntValue_J__I(NN(Long_Cast(fieldValues.Remove_O__O(tmp12.Ref()))).LongValue__J())




			var tmp13 *ResolverStyle; ResolverStyle_Init(); tmp13 = ResolverStyle_SMART; if resolverStyle == tmp13 {
				var tmp14 bool; var tmp15 bool; var tmp16 bool; var tmp17 bool
				tmp17 = moy == 4; if !tmp17 { tmp17 = moy == 6 }; tmp16 = tmp17; if !tmp16 { tmp16 = moy == 9 }; tmp15 = tmp16; if !tmp15 { tmp15 = moy == 11 }; tmp14 = tmp15
//line :227:1
				if tmp14 {

					dom = Math_Min_I_I__I(dom, 30) } else {
//line :227:1
						if moy == 2 {


							var tmp18 int32 = dom; var tmp19 *Month; Month_Init(); tmp19 = Month_FEBRUARY; var tmp20 *Month = tmp19; dom = Math_Min_I_I__I(tmp18, NN(tmp20).Length_Z__I(Year_IsLeap_J__Z(int64(y)))) } } }
			return LocalDate_Of_I_I_I__LocalDate(y, moy, dom)
		} }
func (t *IsoChronology) Range_ChronoField__ValueRange(field *ChronoField) *ValueRange {
	return NN(field).Range__ValueRange()
}
func (t *IsoChronology) Period_I_I_I__Period(years, months, days int32) *Period {
	return Period_Of_I_I_I__Period(years, months, days)
}
func (t *IsoChronology) IsIsoBased__Z() bool { return true }

func (t *IsoChronology) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.chrono.IsoChronology.writeReplace()Ljava/lang/Object;")) }



type IsoChronology struct{ AbstractChronology }

func (t *IsoChronology) Is_Serializable() {}

var IsoChronology_INSTANCE *IsoChronology

const IsoChronology_serialVersionUID int64 = -1440403870442975015

const IsoChronology_DAYS_0000_TO_1970 int64 = 719528

var IsoChronology_init ClassInit

func IsoChronology_Init() { if !IsoChronology_init.Done() { IsoChronology_init.Run(IsoChronology_clinit) } }

func IsoChronology_clinit() { AbstractChronology_Init(); IsoChronology_INSTANCE = IsoChronology_New() }

func (t *IsoChronology) ResolveDate_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.ResolveDate_Map_ResolverStyle__LocalDate(p0, p1)) }

func (t *IsoChronology) ResolveYearOfEra_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.ResolveYearOfEra_Map_ResolverStyle__LocalDate(p0, p1)) }

func (t *IsoChronology) ResolveYMD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.ResolveYMD_Map_ResolverStyle__LocalDate(p0, p1)) }

func (t *IsoChronology) Date_Era_I_I_I__ChronoLocalDate(p0 Era, p1, p2, p3 int32) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.Date_Era_I_I_I__LocalDate(p0, p1, p2, p3)) }

func (t *IsoChronology) Date_I_I_I__ChronoLocalDate(p0, p1, p2 int32) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.Date_I_I_I__LocalDate(p0, p1, p2)) }

func (t *IsoChronology) DateYearDay_Era_I_I__ChronoLocalDate(p0 Era, p1, p2 int32) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.DateYearDay_Era_I_I__LocalDate(p0, p1, p2)) }

func (t *IsoChronology) DateYearDay_I_I__ChronoLocalDate(p0, p1 int32) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.DateYearDay_I_I__LocalDate(p0, p1)) }

func (t *IsoChronology) DateEpochDay_J__ChronoLocalDate(p0 int64) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.DateEpochDay_J__LocalDate(p0)) }

func (t *IsoChronology) DateNow__ChronoLocalDate() ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.DateNow__LocalDate()) }

func (t *IsoChronology) DateNow_ZoneId__ChronoLocalDate(p0 ZoneId_I) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.DateNow_ZoneId__LocalDate(p0)) }

func (t *IsoChronology) DateNow_Clock__ChronoLocalDate(p0 Clock_I) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.DateNow_Clock__LocalDate(p0)) }

func (t *IsoChronology) Date_TemporalAccessor__ChronoLocalDate(p0 TemporalAccessor) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.Date_TemporalAccessor__LocalDate(p0)) }

func (t *IsoChronology) LocalDateTime_TemporalAccessor__ChronoLocalDateTime(p0 TemporalAccessor) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.LocalDateTime_TemporalAccessor__LocalDateTime(p0)) }

func (t *IsoChronology) ZonedDateTime_TemporalAccessor__ChronoZonedDateTime(p0 TemporalAccessor) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.ZonedDateTime_TemporalAccessor__ZonedDateTime(p0)) }

func (t *IsoChronology) ZonedDateTime_Instant_ZoneId__ChronoZonedDateTime(p0 *Instant, p1 ZoneId_I) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.ZonedDateTime_Instant_ZoneId__ZonedDateTime(p0, p1)) }

func (t *IsoChronology) EraOf_I__Era(p0 int32) Era { return Up_IsoEra_Era(t.EraOf_I__IsoEra(p0)) }

func (t *IsoChronology) Period_I_I_I__ChronoPeriod(p0, p1, p2 int32) ChronoPeriod { return Up_Period_ChronoPeriod(t.Period_I_I_I__Period(p0, p1, p2)) }

func (t *IsoChronology) ResolveYAA_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return t.Impl_ResolveYAA_Map_ResolverStyle__ChronoLocalDate(t, p0, p1) }

func (t *IsoChronology) ResolveAligned_ChronoLocalDate_J_J_J__ChronoLocalDate(p0 ChronoLocalDate, p1, p2, p3 int64) ChronoLocalDate { return t.Impl_ResolveAligned_ChronoLocalDate_J_J_J__ChronoLocalDate(t, p0, p1, p2, p3) }

func (t *IsoChronology) ResolveYD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return t.Impl_ResolveYD_Map_ResolverStyle__ChronoLocalDate(t, p0, p1) }

func (t *IsoChronology) AddFieldValue_Map_ChronoField_J__V(p0 Map, p1 *ChronoField, p2 int64) { t.Impl_AddFieldValue_Map_ChronoField_J__V(t, p0, p1, p2) }

func (t *IsoChronology) GetDisplayName_TextStyle_Locale__String(p0 *TextStyle, p1 *Locale) *String { return Chronology_GetDisplayName_TextStyle_Locale__String(t, p0, p1) }

func (t *IsoChronology) ResolveYMAA_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return t.Impl_ResolveYMAA_Map_ResolverStyle__ChronoLocalDate(t, p0, p1) }

func (t *IsoChronology) CompareTo_Chronology__I(p0 Chronology) int32 { return t.Impl_CompareTo_Chronology__I(t, p0) }

func (t *IsoChronology) EpochSecond_Era_I_I_I_I_I_I_ZoneOffset__J(p0 Era, p1, p2, p3, p4, p5, p6 int32, p7 *ZoneOffset) int64 { return Chronology_EpochSecond_Era_I_I_I_I_I_I_ZoneOffset__J(t, p0, p1, p2, p3, p4, p5, p6, p7) }

func (t *IsoChronology) ResolveYMAD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return t.Impl_ResolveYMAD_Map_ResolverStyle__ChronoLocalDate(t, p0, p1) }

func (t *IsoChronology) ResolveYAD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate { return t.Impl_ResolveYAD_Map_ResolverStyle__ChronoLocalDate(t, p0, p1) }

func (t *IsoChronology) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *IsoChronology) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *IsoChronology) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *IsoChronology) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IsoChronology) Ref() any { if t == nil { return nil }; return t }

func (t *IsoChronology) GetClass__Class() *Class { return IsoChronology_class }

func (t *IsoChronology) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IsoChronology) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoChronology_InstanceOf(x any) bool { _, ok := x.(*IsoChronology); return ok }

func IsoChronology_Cast(x any) *IsoChronology { if x == nil { return nil }; v, ok := x.(*IsoChronology); if !ok { panic(ClassCast(x, IsoChronology_class)) }; return v }
