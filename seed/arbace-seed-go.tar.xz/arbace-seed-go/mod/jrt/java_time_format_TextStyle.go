//line java_time_format_TextStyle.ae:1
package jrt


















func TextStyle_New_String_I_I_I(p0 *String, p1, p2, p3 int32) *TextStyle { TextStyle_Init(); t := &TextStyle{}; t.Ctor_String_I_I_I(p0, p1, p2, p3); return t }
//line :20:1
func (t *TextStyle) Ctor_String_I_I_I(enumName *String, enumOrdinal, calendarStyle, zoneNameStyleIndex int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)
	t.F_calendarStyle = calendarStyle
	t.F_zoneNameStyleIndex = zoneNameStyleIndex
}
func (t *TextStyle) IsStandalone__Z() bool {
	return t.Ordinal__I()&1 == 1
}
func (t *TextStyle) AsStandalone__TextStyle() *TextStyle {
	return As[*TextStyle](TextStyle_Values__TextStyle1().A[t.Ordinal__I()|1])
}
func (t *TextStyle) AsNormal__TextStyle() *TextStyle {
	return As[*TextStyle](TextStyle_Values__TextStyle1().A[t.Ordinal__I()&-2])
}
func (t *TextStyle) ToCalendarStyle__I() int32 { return t.F_calendarStyle }

func (t *TextStyle) ZoneNameStyleIndex__I() int32 { return t.F_zoneNameStyleIndex }



type TextStyle struct{ Enum; F_calendarStyle, F_zoneNameStyleIndex int32 }

func (t *TextStyle) Is_Constable() {}

var TextStyle_FULL *TextStyle

var TextStyle_FULL_STANDALONE *TextStyle

var TextStyle_SHORT *TextStyle

var TextStyle_SHORT_STANDALONE *TextStyle

var TextStyle_NARROW *TextStyle

var TextStyle_NARROW_STANDALONE *TextStyle

var TextStyle__VALUES *RefArray

var TextStyle_init ClassInit

func TextStyle_Init() { if !TextStyle_init.Done() { TextStyle_init.Run(TextStyle_clinit) } }

func TextStyle_clinit() { TextStyle_FULL = TextStyle_New_String_I_I_I(Lit_1798, 0, 2, 0); TextStyle_FULL_STANDALONE = TextStyle_New_String_I_I_I(Lit_2393, 1, 32770, 0); TextStyle_SHORT = TextStyle_New_String_I_I_I(Lit_1801, 2, 1, 1); TextStyle_SHORT_STANDALONE = TextStyle_New_String_I_I_I(Lit_2394, 3, 32769, 1); TextStyle_NARROW = TextStyle_New_String_I_I_I(Lit_1879, 4, 4, 1); TextStyle_NARROW_STANDALONE = TextStyle_New_String_I_I_I(Lit_2395, 5, 32772, 1); TextStyle__VALUES = TextStyle_X_values__TextStyle1() }

func TextStyle_Values__TextStyle1() *RefArray { TextStyle_Init(); return TextStyle__VALUES.Copy() }

func TextStyle_ValueOf_String__TextStyle(p0 *String) *TextStyle { TextStyle_Init(); return TextStyle_Cast(Enum_ValueOf_Class_String__Enum(TextStyle_class, p0)) }

func TextStyle_X_values__TextStyle1() *RefArray { TextStyle_Init(); return RefArrayOf(TextStyle_class, TextStyle_FULL, TextStyle_FULL_STANDALONE, TextStyle_SHORT, TextStyle_SHORT_STANDALONE, TextStyle_NARROW, TextStyle_NARROW_STANDALONE) }

func (t *TextStyle) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.format.TextStyle.describeConstable()Ljava/util/Optional;")) }

func (t *TextStyle) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *TextStyle) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *TextStyle) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *TextStyle) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *TextStyle) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *TextStyle) Ref() any { if t == nil { return nil }; return t }

func (t *TextStyle) GetClass__Class() *Class { return TextStyle_class }

func (t *TextStyle) CloneShallow() any { panic(CloneNotSupported(t)) }

func TextStyle_InstanceOf(x any) bool { _, ok := x.(*TextStyle); return ok }

func TextStyle_Cast(x any) *TextStyle { if x == nil { return nil }; v, ok := x.(*TextStyle); if !ok { panic(ClassCast(x, TextStyle_class)) }; return v }
