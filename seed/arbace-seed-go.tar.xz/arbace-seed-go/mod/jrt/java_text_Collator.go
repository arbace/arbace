//line java_text_Collator.ae:1
package jrt


























func Collator_GetInstance__Collator() Collator_I { Collator_Init(); MonitorEnter(Collator_class); defer MonitorExit(Collator_class)
	return Collator_GetInstance_Locale__Collator(Locale_GetDefault__Locale())
}
func Collator_GetInstance_Locale__Collator(desiredLocale *Locale) Collator_I { Collator_Init()
	var ref *SoftReference = SoftReference_Cast(Collator_cache.Get_O__O(desiredLocale.Ref())); var result Collator_I


	if !(ref == nil) { result = Collator_Cast(NN(ref).Get__O()) } else { result = nil }
	if result == nil {
		var adapter LocaleProviderAdapter_I
		adapter = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(CollatorProvider_class, desiredLocale)
		var provider CollatorProvider_I = adapter.GetCollatorProvider__CollatorProvider()
		result = provider.GetInstance_Locale__Collator(desiredLocale)
		if result == nil {
			result = LocaleProviderAdapter_ForJRE__LocaleProviderAdapter().GetCollatorProvider__CollatorProvider().GetInstance_Locale__Collator(desiredLocale)
		}

		var strength *String = NN(desiredLocale).GetUnicodeLocaleType_String__String(Lit_1716)
		if !(strength == nil) {
			var tmp1 *String = strength; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; strength = NN(tmp1).ToLowerCase_Locale__String(tmp2)
			var tmp3 *String = strength; var tmp4 int32 = -1; switch NN(tmp3).HashCode__I() { case -1106127571: if tmp3.Equals_O__Z(Lit_1717) { tmp4 = 0 }; case -1106127570: if tmp3.Equals_O__Z(Lit_1718) { tmp4 = 1 }; case -1106127569: if tmp3.Equals_O__Z(Lit_1719) { tmp4 = 2 }; case 1658188554: if tmp3.Equals_O__Z(Lit_1720) { tmp4 = 3 }}; switch tmp4 { case 0:
				result.SetStrength_I__V(0); case 1:
				result.SetStrength_I__V(1); case 2:
				result.SetStrength_I__V(2); case 3:
				result.SetStrength_I__V(3); default:} }
		var norm *String = NN(desiredLocale).GetUnicodeLocaleType_String__String(Lit_1721)
		if !(norm == nil) {
			var tmp5 *String = norm; var tmp6 *Locale; Locale_Init(); tmp6 = Locale_ROOT; norm = NN(tmp5).ToLowerCase_Locale__String(tmp6)
			var tmp7 *String = norm; var tmp8 int32 = -1; switch NN(tmp7).HashCode__I() { case 3569038: if tmp7.Equals_O__Z(Lit_107) { tmp8 = 0 }; case 97196323: if tmp7.Equals_O__Z(Lit_1316) { tmp8 = 1 }}; switch tmp8 { case 0:
				result.SetDecomposition_I__V(1); case 1:
				result.SetDecomposition_I__V(0); default:} }
	L1: for {
		if !(ref == nil) { Collator_cache.Remove_O_O__Z(desiredLocale.Ref(), ref.Ref()) }
		var tmp9 ConcurrentMap = Collator_cache; ref = SoftReference_Cast(tmp9.PutIfAbsent_O_O__O(desiredLocale.Ref(), SoftReference_New_O(result)))


		if ref == nil { break L1 }
		var cachedColl Collator_I = Collator_Cast(NN(ref).Get__O())
		if !(cachedColl == nil) { result = cachedColl; break L1 }
//line :59:1
		continue L1
	}
	}





	return Collator_Cast(result.Clone__O())
}


func (t *Collator) Impl_Compare_O_O__I(this Collator_I, o1, o2 any) int32 {
	return this.Compare_String_String__I(String_Cast(o1), String_Cast(o2))
}


func (t *Collator) Impl_Equals_String_String__Z(this Collator_I, source, target *String) bool {
	return this.Compare_String_String__I(source, target) == 0
}
func (t *Collator) Impl_GetStrength__I(this Collator_I) int32 { MonitorEnter(this); defer MonitorExit(this); return t.F_strength }

func (t *Collator) Impl_SetStrength_I__V(this Collator_I, newStrength int32) { MonitorEnter(this); defer MonitorExit(this)
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = !(newStrength == 0); if tmp4 { tmp4 = !(newStrength == 1) }; tmp3 = tmp4; if tmp3 {
		tmp3 = !(newStrength == 2) }
//line :82:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = !(newStrength == 3) }
//line :82:1
	tmp1 = tmp2; if tmp1 {


		panic(Thrown(IllegalArgumentException_New_String(Lit_1722))) }
	t.F_strength = newStrength
}
func (t *Collator) Impl_GetDecomposition__I(this Collator_I) int32 { MonitorEnter(this); defer MonitorExit(this); return t.F_decmp }

func (t *Collator) Impl_SetDecomposition_I__V(this Collator_I, decompositionMode int32) { MonitorEnter(this); defer MonitorExit(this)
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !(decompositionMode == 0); if tmp3 {
		tmp3 = !(decompositionMode == 1) }
//line :91:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = !(decompositionMode == 2) }
//line :91:1
	tmp1 = tmp2; if tmp1 {


		panic(Thrown(IllegalArgumentException_New_String(Lit_1723))) }
	t.F_decmp = decompositionMode
}
func Collator_GetAvailableLocales__Locale1() *RefArray { Collator_Init(); MonitorEnter(Collator_class); defer MonitorExit(Collator_class)
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(CollatorProvider_class); return NN(pool).GetAvailableLocales__Locale1()
}
func (t *Collator) Impl_Clone__O(this Collator_I) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = Collator_Cast(A2g_ObjectClone(this)); return nil }()
//line :101:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :101:1
			panic(tmp2) } }; return tmp1
}


func (t *Collator) Impl_Equals_O__Z(this Collator_I, that any) bool {
	if any(this) == any(that) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = that == nil; if !tmp2 { tmp2 = !(this.GetClass__Class() == GetClass(that)) }; tmp1 = tmp2
//line :106:1
		if tmp1 { return false } else {



			var other Collator_I = Collator_Cast(that); var tmp3 bool; var tmp4 int32 = t.F_strength
			tmp3 = tmp4 == other.Self_Collator().F_strength; if tmp3 { var tmp5 int32 = t.F_decmp; tmp3 = tmp5 == other.Self_Collator().F_decmp }; return tmp3
		}
	}
}
func (t *Collator) Ctor(this Collator_I) { t.F_strength = 0; t.F_decmp = 0
	t.F_strength = 2
	t.F_decmp = 1
}


type Collator struct{ Object; F_strength, F_decmp int32 }

type Collator_I interface{ Object_I; Comparator; Cloneable; Self_Collator() *Collator; Compare_String_String__I(p0, p1 *String) int32; Compare_O_O__I(p0, p1 any) int32; GetCollationKey_String__CollationKey(p0 *String) CollationKey_I; Equals_String_String__Z(p0, p1 *String) bool; GetStrength__I() int32; SetStrength_I__V(p0 int32); GetDecomposition__I() int32; SetDecomposition_I__V(p0 int32) }

func (t *Collator) Self_Collator() *Collator { return t }

func (t *Collator) Is_Comparator() {}

func (t *Collator) Is_Cloneable() {}

const Collator_PRIMARY int32 = 0

const Collator_SECONDARY int32 = 1

const Collator_TERTIARY int32 = 2

const Collator_IDENTICAL int32 = 3

const Collator_NO_DECOMPOSITION int32 = 0

const Collator_CANONICAL_DECOMPOSITION int32 = 1

const Collator_FULL_DECOMPOSITION int32 = 2

var Collator_cache ConcurrentMap

const Collator_LESS int32 = -1

const Collator_EQUAL int32 = 0

const Collator_GREATER int32 = 1

var Collator_init ClassInit

func Collator_Init() { if !Collator_init.Done() { Collator_init.Run(Collator_clinit) } }

func Collator_clinit() { Collator_cache = ConcurrentHashMap_New() }

func Collator_InstanceOf(x any) bool { _, ok := x.(Collator_I); return ok }

func Collator_Cast(x any) Collator_I { if x == nil { return nil }; v, ok := x.(Collator_I); if !ok { panic(ClassCast(x, Collator_class)) }; return v }
