//line java_time_Year.ae:1
package jrt












































func Year_Now__Year() *Year { Year_Init()
	return Year_Now_Clock__Year(Clock_SystemDefaultZone__Clock())
}
func Year_Now_ZoneId__Year(zone ZoneId_I) *Year { Year_Init()
	return Year_Now_Clock__Year(Clock_System_ZoneId__Clock(zone))
}
func Year_Now_Clock__Year(clock Clock_I) *Year { Year_Init()
	var now *LocalDate = LocalDate_Now_Clock__LocalDate(clock); return Year_Of_I__Year(NN(now).GetYear__I())
}
func Year_Of_I__Year(isoYear int32) *Year { Year_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(isoYear))
	return Year_New_I(isoYear)
}
func Year_From_TemporalAccessor__Year(temporal TemporalAccessor) *Year { Year_Init()
	if Year_InstanceOf(temporal) {
		return Year_Cast(temporal) } else {

			Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
			var tmp1 *Year; tmp6 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; var tmp3 *IsoChronology = tmp2; if NN(tmp3).Equals_O__Z(Chronology_From_TemporalAccessor__Chronology(temporal)) == false {
					temporal = Up_LocalDate_TemporalAccessor(LocalDate_From_TemporalAccessor__LocalDate(temporal)) }
					var tmp4 TemporalAccessor = temporal; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; tmp1 = Year_Of_I__Year(tmp4.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5))) }; return nil }()
//line :64:1
			if tmp6 != nil { if DateTimeException_InstanceOf(tmp6) { var ex DateTimeException_I = DateTimeException_Cast(tmp6)




				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2086, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :64:1
					panic(tmp6) } }; return tmp1
		}
}









func Year_Parse_CharSequence__Year(text CharSequence) *Year { Year_Init()
	return Year_Parse_CharSequence_DateTimeFormatter__Year(text, Year_PARSER)
}
func Year_Parse_CharSequence_DateTimeFormatter__Year(text CharSequence, formatter *DateTimeFormatter) *Year { Year_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return Year_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return Year_From_TemporalAccessor__Year(p0).Ref() }}))
}

func Year_IsLeap_J__Z(year int64) bool { Year_Init()
	if year&15 == 0 {
		return year&3 == 0 } else {
			var tmp1 bool; tmp1 = year&3 == 0; if tmp1 { tmp1 = !(year%100 == 0) }; return tmp1
		} }
func Year_New_I(p0 int32) *Year { Year_Init(); t := &Year{}; t.Ctor_I(p0); return t }
//line :89:1
func (t *Year) Ctor_I(year int32) { t.F_year = year }

func (t *Year) GetValue__I() int32 { return t.F_year }

func (t *Year) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; var tmp2 bool; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; tmp2 = any(field) == any(tmp3.Ref()); if !tmp2 { var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_YEAR_OF_ERA; tmp2 = any(field) == any(tmp4.Ref()) }; tmp1 = tmp2; if !tmp1 {
			var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_ERA; tmp1 = any(field) == any(tmp5.Ref()) }
//line :95:1
		return tmp1 } else {

			var tmp6 bool; tmp6 = !(field == nil); if tmp6 { tmp6 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp6
		} }
func (t *Year) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_YEARS; tmp4 = any(unit) == any(tmp5.Ref()); if !tmp4 { var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_DECADES; tmp4 = any(unit) == any(tmp6.Ref()) }; tmp3 = tmp4; if !tmp3 {
			var tmp7 *ChronoUnit; ChronoUnit_Init(); tmp7 = ChronoUnit_CENTURIES; tmp3 = any(unit) == any(tmp7.Ref()) }
//line :101:1
		tmp2 = tmp3; if !tmp2 {

			var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_MILLENNIA; tmp2 = any(unit) == any(tmp8.Ref()) }
//line :101:1
		tmp1 = tmp2; if !tmp1 {


			var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_ERAS; tmp1 = any(unit) == any(tmp9.Ref()) }
//line :101:1
		return tmp1 } else {



			var tmp10 bool; tmp10 = !(unit == nil); if tmp10 { tmp10 = unit.IsSupportedBy_Temporal__Z(t) }; return tmp10
		} }
func (t *Year) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR_OF_ERA; if any(field) == any(tmp1.Ref()) {
		if t.F_year <= 0 {
			return ValueRange_Of_J_J__ValueRange(1, 1000000000) } else {
				return ValueRange_Of_J_J__ValueRange(1, 999999999) } } else {
					return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
				} }
func (t *Year) Get_TemporalField__I(field TemporalField) int32 {
	return NN(t.Range_TemporalField__ValueRange(field)).CheckValidIntValue_J_TemporalField__I(t.GetLong_TemporalField__J(field), field)
}
func (t *Year) GetLong_TemporalField__J(field TemporalField) int64 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 25:
			var tmp2 int32; if t.F_year < 1 { tmp2 = 1 - t.F_year } else { tmp2 = t.F_year }; return int64(tmp2); case 26:
			return int64(t.F_year); case 27:
			if t.F_year < 1 { return 0 } else { return 1 }; default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return field.GetFrom_TemporalAccessor__J(t) } }; panic("a2g: unreachable")
}
func (t *Year) IsLeap__Z() bool { return Year_IsLeap_J__Z(int64(t.F_year)) }

func (t *Year) IsValidMonthDay_MonthDay__Z(monthDay *MonthDay) bool {
	var tmp1 bool; tmp1 = !(monthDay == nil); if tmp1 { tmp1 = NN(monthDay).IsValidYear_I__Z(t.F_year) }; return tmp1
}
func (t *Year) Length__I() int32 { if t.IsLeap__Z() { return 366 } else { return 365 } }

func (t *Year) With_TemporalAdjuster__Year(adjuster TemporalAdjuster) *Year {
	return Year_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
}
func (t *Year) With_TemporalField_J__Year(field TemporalField, newValue int64) *Year {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)

		NN(chronoField).CheckValidValue_J__J(newValue)
		switch NN(chronoField).F_ordinal { case 25:

			var tmp2 int64; if t.F_year < 1 { tmp2 = 1 - newValue } else { tmp2 = newValue }; return Year_Of_I__Year(int32(tmp2)); case 26:
			return Year_Of_I__Year(int32(newValue)); case 27:

			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_ERA; if t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3)) == newValue { return t } else {

				return Year_Of_I__Year(1 - t.F_year) }; default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return Year_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue)) } }; panic("a2g: unreachable")
}
func (t *Year) Plus_TemporalAmount__Year(amountToAdd TemporalAmount) *Year {
	return Year_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
}
func (t *Year) Plus_J_TemporalUnit__Year(amountToAdd int64, unit TemporalUnit) *Year {
	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 10:
			return t.PlusYears_J__Year(amountToAdd); case 11:
			return t.PlusYears_J__Year(Math_MultiplyExact_J_I__J(amountToAdd, 10)); case 12:
			return t.PlusYears_J__Year(Math_MultiplyExact_J_I__J(amountToAdd, 100)); case 13:
			return t.PlusYears_J__Year(Math_MultiplyExact_J_I__J(amountToAdd, 1000)); case 14:

			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 TemporalField = Up_ChronoField_TemporalField(tmp2); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return t.With_TemporalField_J__Year(tmp3, Math_AddExact_J_J__J(t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)), amountToAdd)); default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
				return Year_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd)) } }; panic("a2g: unreachable")
}
func (t *Year) PlusYears_J__Year(yearsToAdd int64) *Year {
	if yearsToAdd == 0 { return t } else {

		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; return Year_Of_I__Year(NN(tmp1).CheckValidIntValue_J__I(int64(t.F_year) + yearsToAdd))
	} }
func (t *Year) Minus_TemporalAmount__Year(amountToSubtract TemporalAmount) *Year {
	return Year_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
}
func (t *Year) Minus_J_TemporalUnit__Year(amountToSubtract int64, unit TemporalUnit) *Year {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__Year(9223372036854775807, unit)).Plus_J_TemporalUnit__Year(1, unit) } else {
			return t.Plus_J_TemporalUnit__Year(-amountToSubtract, unit)
		} }
func (t *Year) MinusYears_J__Year(yearsToSubtract int64) *Year {
	if yearsToSubtract == -9223372036854775808 {
		return NN(t.PlusYears_J__Year(9223372036854775807)).PlusYears_J__Year(1) } else {
			return t.PlusYears_J__Year(-yearsToSubtract)
		} }
func (t *Year) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_Chronology__TemporalQuery() { IsoChronology_Init(); return IsoChronology_INSTANCE.Ref() } else { if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_YEARS.Ref() } else {


		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	} } }
func (t *Year) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 Chronology = Chronology_From_TemporalAccessor__Chronology(temporal); var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; if tmp1.Equals_O__Z(tmp2.Ref()) == false {
		panic(Thrown(DateTimeException_New_String(Lit_2071))) }
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; return temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp3), int64(t.F_year))
}
func (t *Year) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	{ var end *Year = Year_From_TemporalAccessor__Year(endExclusive); var tmp1 TemporalUnit = unit
		if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1); var yearsUntil int64 = int64(end.F_year) - int64(t.F_year)

			switch NN(chronoUnit).F_ordinal { case 10: return yearsUntil; case 11:

				return yearsUntil / 10; case 12:
				return yearsUntil / 100; case 13:
				return yearsUntil / 1000; case 14:
				var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 int64 = NN(end).GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2)); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return tmp3 - t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)); default:
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
					return unit.Between_Temporal_Temporal__J(t, Up_Year_Temporal(end)) } }; panic("a2g: unreachable")
}
func (t *Year) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *Year) AtDay_I__LocalDate(dayOfYear int32) *LocalDate {
	return LocalDate_OfYearDay_I_I__LocalDate(t.F_year, dayOfYear)
}
func (t *Year) AtMonth_Month__YearMonth(month *Month) *YearMonth {
	return YearMonth_Of_I_Month__YearMonth(t.F_year, month)
}
func (t *Year) AtMonth_I__YearMonth(month int32) *YearMonth {
	return YearMonth_Of_I_I__YearMonth(t.F_year, month)
}
func (t *Year) AtMonthDay_MonthDay__LocalDate(monthDay *MonthDay) *LocalDate {
	return NN(monthDay).AtYear_I__LocalDate(t.F_year)
}
func (t *Year) CompareTo_Year__I(other *Year) int32 {
	var tmp1 int32 = t.F_year; return tmp1 - other.F_year
}
func (t *Year) IsAfter_Year__Z(other *Year) bool {
	var tmp1 int32 = t.F_year; return tmp1 > other.F_year
}
func (t *Year) IsBefore_Year__Z(other *Year) bool {
	var tmp1 int32 = t.F_year; return tmp1 < other.F_year
}
func (t *Year) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if Year_InstanceOf(obj) {

		var tmp1 int32 = t.F_year; return tmp1 == Year_Cast(obj).F_year } else {
//line :234:1
			return false
		}
	}
}

func (t *Year) HashCode__I() int32 { return t.F_year }

func (t *Year) ToString__String() *String { return Integer_ToString_I__String(t.F_year) }

func (t *Year) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.Year.writeReplace()Ljava/lang/Object;")) }







func Year_ReadExternal_DataInput__Year(p0 DataInput) *Year { Year_Init(); panic(A2g_NotTranslated("java.time.Year.readExternal(Ljava/io/DataInput;)Ljava/time/Year;")) }



type Year struct{ Object; F_year int32 }

func (t *Year) Is_Temporal() {}

func (t *Year) Is_TemporalAdjuster() {}

func (t *Year) Is_Comparable() {}

func (t *Year) Is_Serializable() {}

func (t *Year) Is_TemporalAccessor() {}

const Year_MIN_VALUE int32 = -999999999

const Year_MAX_VALUE int32 = 999999999

const Year_serialVersionUID int64 = -23038383694477807

var Year_PARSER *DateTimeFormatter

var Year_init ClassInit

func Year_Init() { if !Year_init.Done() { Year_init.Run(Year_clinit) } }

func Year_clinit() { var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().ParseLenient__DateTimeFormatterBuilder(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_YEAR; var tmp3 TemporalField = Up_ChronoField_TemporalField(tmp2); var tmp4 *SignStyle; SignStyle_Init(); tmp4 = SignStyle_NORMAL; Year_PARSER = NN(NN(tmp1).AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(tmp3, 1, 10, tmp4)).ToFormatter__DateTimeFormatter() }

func (t *Year) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_Year_Temporal(t.With_TemporalAdjuster__Year(p0)) }

func (t *Year) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_Year_Temporal(t.With_TemporalField_J__Year(p0, p1)) }

func (t *Year) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_Year_Temporal(t.Plus_TemporalAmount__Year(p0)) }

func (t *Year) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_Year_Temporal(t.Plus_J_TemporalUnit__Year(p0, p1)) }

func (t *Year) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_Year_Temporal(t.Minus_TemporalAmount__Year(p0)) }

func (t *Year) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_Year_Temporal(t.Minus_J_TemporalUnit__Year(p0, p1)) }

func (t *Year) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Year__I(Year_Cast(p0)) }

func (t *Year) Ref() any { if t == nil { return nil }; return t }

func (t *Year) GetClass__Class() *Class { return Year_class }

func (t *Year) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Year) CloneShallow() any { panic(CloneNotSupported(t)) }

func Year_InstanceOf(x any) bool { _, ok := x.(*Year); return ok }

func Year_Cast(x any) *Year { if x == nil { return nil }; v, ok := x.(*Year); if !ok { panic(ClassCast(x, Year_class)) }; return v }
