//line java_time_zone_Ser.ae:1
package jrt





























func Ser_New() *Ser { t := &Ser{}; t.Ctor(); return t }
//line :31:1
func (t *Ser) Ctor() {}

func Ser_New_B_Serializable(p0 int8, p1 Serializable) *Ser { t := &Ser{}; t.Ctor_B_Serializable(p0, p1); return t }
//line :33:1
func (t *Ser) Ctor_B_Serializable(type_ int8, object Serializable) { panic(A2g_NotTranslated("java.time.zone.Ser.<init>(BLjava/io/Serializable;)V")) }























func Ser_Read_DataInput__Serializable(in DataInput) Serializable {
	var type_ int8 = in.ReadByte__B(); return Ser_ReadInternal_B_DataInput__Serializable(type_, in)
}
func Ser_ReadInternal_B_DataInput__Serializable(type_ int8, in DataInput) Serializable {

	switch int32(type_) { case 1:
		return Up_ZoneRules_Serializable(ZoneRules_ReadExternal_DataInput__ZoneRules(in)); case 2:
		return Up_ZoneOffsetTransition_Serializable(ZoneOffsetTransition_ReadExternal_DataInput__ZoneOffsetTransition(in)); case 3:
		return Up_ZoneOffsetTransitionRule_Serializable(ZoneOffsetTransitionRule_ReadExternal_DataInput__ZoneOffsetTransitionRule(in)); default:
		panic(Thrown(StreamCorruptedException_New_String(Lit_2542)))}; panic("a2g: unreachable")
}
func (t *Ser) ReadResolve__O() any { panic(A2g_NotTranslated("java.time.zone.Ser.readResolve()Ljava/lang/Object;")) }









func Ser_ReadOffset_DataInput__ZoneOffset(in DataInput) *ZoneOffset {
	var offsetByte int32 = int32(in.ReadByte__B())
	if offsetByte == 127 {
		return ZoneOffset_OfTotalSeconds_I__ZoneOffset(in.ReadInt__I()) } else {
			return ZoneOffset_OfTotalSeconds_I__ZoneOffset(offsetByte * 900)
		}
}








func Ser_ReadEpochSec_DataInput__J(in DataInput) int64 {
	var hiByte int32 = int32(in.ReadByte__B()) & 255
	if hiByte == 255 {
		return in.ReadLong__J() } else {
			var midByte int32 = int32(in.ReadByte__B()) & 255; var loByte int32 = int32(in.ReadByte__B()) & 255; var tot int64 = int64(hiByte<<16 + midByte<<8 + loByte)





			return tot*900 - 4575744000
		}
}

type Ser struct{ Object; F_type int8; F_object Serializable }

func (t *Ser) Is_Serializable() {}

const Ser_serialVersionUID int64 = -8885321777449118786

const Ser_ZRULES int8 = 1

const Ser_ZOT int8 = 2

const Ser_ZOTRULE int8 = 3

func (t *Ser) Ref() any { if t == nil { return nil }; return t }

func (t *Ser) GetClass__Class() *Class { return Ser_class }

func (t *Ser) ToString__String() *String { return Object_toString(t) }

func (t *Ser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Ser) CloneShallow() any { panic(CloneNotSupported(t)) }

func Ser_InstanceOf(x any) bool { _, ok := x.(*Ser); return ok }

func Ser_Cast(x any) *Ser { if x == nil { return nil }; v, ok := x.(*Ser); if !ok { panic(ClassCast(x, Ser_class)) }; return v }
