//line java_util_AbstractSequentialList.ae:1
package jrt







func (t *AbstractSequentialList) Ctor(this AbstractSequentialList_I) { t.AbstractList.Ctor(this) }

func (t *AbstractSequentialList) Impl_Get_I__O(this AbstractSequentialList_I, index int32) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = this.ListIterator_I__ListIterator(index).Next__O(); return nil }()
//line :12:1
	if tmp2 != nil { if NoSuchElementException_InstanceOf(tmp2) { var exc_ NoSuchElementException_I = NoSuchElementException_Cast(tmp2); _ = exc_


		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index))))) } else {
//line :12:1
			panic(tmp2) } }; return tmp1
}



func (t *AbstractSequentialList) Impl_Set_I_O__O(this AbstractSequentialList_I, index int32, element any) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var e ListIterator = this.ListIterator_I__ListIterator(index); var oldVal any = e.Next__O()

			e.Set_O__V(element)
//line :19:1
			tmp1 = oldVal
		}
		return nil }()
//line :18:1
	if tmp2 != nil { if NoSuchElementException_InstanceOf(tmp2) { var exc_ NoSuchElementException_I = NoSuchElementException_Cast(tmp2); _ = exc_





		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index))))) } else {
//line :18:1
			panic(tmp2) } }; return tmp1
}






func (t *AbstractSequentialList) Impl_Add_I_O__V(this AbstractSequentialList_I, index int32, element any) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	this.ListIterator_I__ListIterator(index).Add_O__V(element); return nil }(); if /*line :27:1*/ tmp1 != nil { if NoSuchElementException_InstanceOf(tmp1) { var exc_ NoSuchElementException_I = NoSuchElementException_Cast(tmp1); _ = exc_


		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index))))) } else {
//line :27:1
			panic(tmp1) } } }




func (t *AbstractSequentialList) Impl_Remove_I__O(this AbstractSequentialList_I, index int32) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var e ListIterator = this.ListIterator_I__ListIterator(index); var outCast any = e.Next__O()

			e.Remove__V()
//line :34:1
			tmp1 = outCast
		}
		return nil }()
//line :33:1
	if tmp2 != nil { if NoSuchElementException_InstanceOf(tmp2) { var exc_ NoSuchElementException_I = NoSuchElementException_Cast(tmp2); _ = exc_





		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index))))) } else {
//line :33:1
			panic(tmp2) } }; return tmp1
}






func (t *AbstractSequentialList) Impl_AddAll_I_Collection__Z(this AbstractSequentialList_I, index int32, c Collection) bool {
	var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var modified bool = false; var e1 ListIterator = this.ListIterator_I__ListIterator(index); var i_101731 Iterator = c.Iterator__Iterator(); for i_101731.HasNext__Z() {

			var e any = i_101731.Next__O(); e1.Add_O__V(e); modified = true }
//line :43:1
			tmp1 = modified
		}
		return nil }()
//line :42:1
	if tmp2 != nil { if NoSuchElementException_InstanceOf(tmp2) { var exc_ NoSuchElementException_I = NoSuchElementException_Cast(tmp2); _ = exc_





		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index))))) } else {
//line :42:1
			panic(tmp2) } }; return tmp1
}






func (t *AbstractSequentialList) Impl_Iterator__Iterator(this AbstractSequentialList_I) Iterator {
	return this.ListIterator__ListIterator()
}


type AbstractSequentialList struct{ AbstractList }

type AbstractSequentialList_I interface{ AbstractList_I; List; Collection; SequencedCollection; Iterable; Self_AbstractSequentialList() *AbstractSequentialList; Get_I__O(p0 int32) any; Set_I_O__O(p0 int32, p1 any) any; Add_I_O__V(p0 int32, p1 any); Remove_I__O(p0 int32) any; AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; Iterator__Iterator() Iterator; ListIterator_I__ListIterator(p0 int32) ListIterator }

func (t *AbstractSequentialList) Self_AbstractSequentialList() *AbstractSequentialList { return t }

func AbstractSequentialList_InstanceOf(x any) bool { _, ok := x.(AbstractSequentialList_I); return ok }

func AbstractSequentialList_Cast(x any) AbstractSequentialList_I { if x == nil { return nil }; v, ok := x.(AbstractSequentialList_I); if !ok { panic(ClassCast(x, AbstractSequentialList_class)) }; return v }
