//line java_time_Month.ae:1
package jrt
























func Month_Of_I__Month(month int32) *Month { Month_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = month < 1; if !tmp2 { tmp2 = month > 12 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2069, StrOfInt(month))))) }
	return As[*Month](Month_ENUMS.A[month-1])
}
func Month_From_TemporalAccessor__Month(temporal TemporalAccessor) *Month { Month_Init()
	if Month_InstanceOf(temporal) {
		return Month_Cast(temporal) } else {
			var tmp1 *Month; tmp6 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; var tmp3 *IsoChronology = tmp2; if NN(tmp3).Equals_O__Z(Chronology_From_TemporalAccessor__Chronology(temporal)) == false {
					temporal = Up_LocalDate_TemporalAccessor(LocalDate_From_TemporalAccessor__LocalDate(temporal)) }
					var tmp4 TemporalAccessor = temporal; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MONTH_OF_YEAR; tmp1 = Month_Of_I__Month(tmp4.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5))) }; return nil }()
//line :34:1
			if tmp6 != nil { if DateTimeException_InstanceOf(tmp6) { var ex DateTimeException_I = DateTimeException_Cast(tmp6)




				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2070, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :34:1
					panic(tmp6) } }; return tmp1
		}
}









func (t *Month) GetValue__I() int32 {
	return t.Ordinal__I() + 1
}
func (t *Month) GetDisplayName_TextStyle_Locale__String(style *TextStyle, locale *Locale) *String {
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; return NN(NN(tmp1.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp2), style)).ToFormatter_Locale__DateTimeFormatter(locale)).Format_TemporalAccessor__String(t)
}


func (t *Month) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; return any(field) == any(tmp1.Ref()) } else {
			var tmp2 bool; tmp2 = !(field == nil); if tmp2 { tmp2 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp2
		} }
func (t *Month) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; if any(field) == any(tmp1.Ref()) {
		return field.Range__ValueRange() } else {
			return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
		} }
func (t *Month) Get_TemporalField__I(field TemporalField) int32 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; if any(field) == any(tmp1.Ref()) {
		return t.GetValue__I() } else {
			return TemporalAccessor_Get_TemporalField__I(t, field)
		} }
func (t *Month) GetLong_TemporalField__J(field TemporalField) int64 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; if any(field) == any(tmp1.Ref()) { return int64(t.GetValue__I()) } else {


		if ChronoField_InstanceOf(field) {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
		return field.GetFrom_TemporalAccessor__J(t)
	} }
func (t *Month) Plus_J__Month(months int64) *Month {
	var amount int32 = int32(months % 12); var tmp1 *RefArray = Month_ENUMS
	return As[*Month](tmp1.A[(t.Ordinal__I()+(amount+12))%12])
}



func (t *Month) Minus_J__Month(months int64) *Month {
	return t.Plus_J__Month(-(months % 12))
}
func (t *Month) Length_Z__I(leapYear bool) int32 {
	switch NN(t).F_ordinal { case 1: if leapYear { return 29 } else { return 28 }; case 3, 5, 8, 10: return 30; default: return 31}; panic("a2g: unreachable")
}
func (t *Month) MinLength__I() int32 {
	switch NN(t).F_ordinal { case 1: return 28; case 3, 5, 8, 10: return 30; default: return 31}; panic("a2g: unreachable")
}
func (t *Month) MaxLength__I() int32 {
	switch NN(t).F_ordinal { case 1: return 29; case 3, 5, 8, 10: return 30; default: return 31}; panic("a2g: unreachable")
}
func (t *Month) FirstDayOfYear_Z__I(leapYear bool) int32 {
	{ var leap int32; if leapYear { leap = 1 } else { leap = 0 }
		switch NN(t).F_ordinal { case 0: return 1; case 1: return 32; case 2:


			return 60 + leap; case 3:
			return 91 + leap; case 4:
			return 121 + leap; case 5:
			return 152 + leap; case 6:
			return 182 + leap; case 7:
			return 213 + leap; case 8:
			return 244 + leap; case 9:
			return 274 + leap; case 10:
			return 305 + leap; default:
			return 335 + leap} }; panic("a2g: unreachable")
}
func (t *Month) FirstMonthOfQuarter__Month() *Month {
	var tmp1 *RefArray = Month_ENUMS; return As[*Month](tmp1.A[t.Ordinal__I()/3*3])
}
func (t *Month) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_Chronology__TemporalQuery() { IsoChronology_Init(); return IsoChronology_INSTANCE.Ref() } else { if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_MONTHS.Ref() } else {


		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	} } }
func (t *Month) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 Chronology = Chronology_From_TemporalAccessor__Chronology(temporal); var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; if tmp1.Equals_O__Z(tmp2.Ref()) == false {
		panic(Thrown(DateTimeException_New_String(Lit_2071))) }
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_MONTH_OF_YEAR; var tmp4 TemporalField = Up_ChronoField_TemporalField(tmp3); return temporal.With_TemporalField_J__Temporal(tmp4, int64(t.GetValue__I()))
}


type Month struct{ Enum }

func (t *Month) Is_TemporalAccessor() {}

func (t *Month) Is_TemporalAdjuster() {}

func (t *Month) Is_Constable() {}

var Month_JANUARY *Month

var Month_FEBRUARY *Month

var Month_MARCH *Month

var Month_APRIL *Month

var Month_MAY *Month

var Month_JUNE *Month

var Month_JULY *Month

var Month_AUGUST *Month

var Month_SEPTEMBER *Month

var Month_OCTOBER *Month

var Month_NOVEMBER *Month

var Month_DECEMBER *Month

var Month__VALUES *RefArray

var Month_ENUMS *RefArray

var Month_init ClassInit

func Month_Init() { if !Month_init.Done() { Month_init.Run(Month_clinit) } }

func Month_clinit() { Month_JANUARY = Month_New_String_I(Lit_2057, 0); Month_FEBRUARY = Month_New_String_I(Lit_2058, 1); Month_MARCH = Month_New_String_I(Lit_2059, 2); Month_APRIL = Month_New_String_I(Lit_2060, 3); Month_MAY = Month_New_String_I(Lit_2061, 4); Month_JUNE = Month_New_String_I(Lit_2062, 5); Month_JULY = Month_New_String_I(Lit_2063, 6); Month_AUGUST = Month_New_String_I(Lit_2064, 7); Month_SEPTEMBER = Month_New_String_I(Lit_2065, 8); Month_OCTOBER = Month_New_String_I(Lit_2066, 9); Month_NOVEMBER = Month_New_String_I(Lit_2067, 10); Month_DECEMBER = Month_New_String_I(Lit_2068, 11); Month__VALUES = Month_X_values__Month1(); Month_ENUMS = Month_Values__Month1() }

func Month_New_String_I(p0 *String, p1 int32) *Month { Month_Init(); t := &Month{}; t.Ctor_String_I(p0, p1); return t }

func (t *Month) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Month_Values__Month1() *RefArray { Month_Init(); return Month__VALUES.Copy() }

func Month_ValueOf_String__Month(p0 *String) *Month { Month_Init(); return Month_Cast(Enum_ValueOf_Class_String__Enum(Month_class, p0)) }

func Month_X_values__Month1() *RefArray { Month_Init(); return RefArrayOf(Month_class, Month_JANUARY, Month_FEBRUARY, Month_MARCH, Month_APRIL, Month_MAY, Month_JUNE, Month_JULY, Month_AUGUST, Month_SEPTEMBER, Month_OCTOBER, Month_NOVEMBER, Month_DECEMBER) }

func (t *Month) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.Month.describeConstable()Ljava/util/Optional;")) }

func (t *Month) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Month) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Month) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Month) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Month) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Month) Ref() any { if t == nil { return nil }; return t }

func (t *Month) GetClass__Class() *Class { return Month_class }

func (t *Month) CloneShallow() any { panic(CloneNotSupported(t)) }

func Month_InstanceOf(x any) bool { _, ok := x.(*Month); return ok }

func Month_Cast(x any) *Month { if x == nil { return nil }; v, ok := x.(*Month); if !ok { panic(ClassCast(x, Month_class)) }; return v }
