//line java_lang_IllegalThreadStateException.ae:1
package jrt








func IllegalThreadStateException_New() *IllegalThreadStateException { t := &IllegalThreadStateException{}; t.Ctor(); return t }
//line :10:1
func (t *IllegalThreadStateException) Ctor() { t.IllegalArgumentException.Ctor(t) }

func IllegalThreadStateException_New_String(p0 *String) *IllegalThreadStateException { t := &IllegalThreadStateException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *IllegalThreadStateException) Ctor_String(s *String) { t.IllegalArgumentException.Ctor_String(t, s) }







type IllegalThreadStateException struct{ IllegalArgumentException }

const IllegalThreadStateException_serialVersionUID int64 = -7626246362397460174

func (t *IllegalThreadStateException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalThreadStateException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalThreadStateException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalThreadStateException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalThreadStateException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalThreadStateException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalThreadStateException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalThreadStateException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalThreadStateException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalThreadStateException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalThreadStateException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalThreadStateException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalThreadStateException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalThreadStateException) GetClass__Class() *Class { return IllegalThreadStateException_class }

func (t *IllegalThreadStateException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalThreadStateException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalThreadStateException_InstanceOf(x any) bool { _, ok := x.(*IllegalThreadStateException); return ok }

func IllegalThreadStateException_Cast(x any) *IllegalThreadStateException { if x == nil { return nil }; v, ok := x.(*IllegalThreadStateException); if !ok { panic(ClassCast(x, IllegalThreadStateException_class)) }; return v }
