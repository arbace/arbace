//line java_nio_ReadOnlyBufferException.ae:1
package jrt








func ReadOnlyBufferException_New() *ReadOnlyBufferException { t := &ReadOnlyBufferException{}; t.Ctor(); return t }
//line :10:1
func (t *ReadOnlyBufferException) Ctor() { t.UnsupportedOperationException.Ctor(t) }





type ReadOnlyBufferException struct{ UnsupportedOperationException }

const ReadOnlyBufferException_serialVersionUID int64 = -1210063976496234090

func (t *ReadOnlyBufferException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ReadOnlyBufferException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ReadOnlyBufferException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ReadOnlyBufferException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ReadOnlyBufferException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ReadOnlyBufferException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ReadOnlyBufferException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ReadOnlyBufferException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ReadOnlyBufferException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ReadOnlyBufferException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ReadOnlyBufferException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ReadOnlyBufferException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReadOnlyBufferException) Ref() any { if t == nil { return nil }; return t }

func (t *ReadOnlyBufferException) GetClass__Class() *Class { return ReadOnlyBufferException_class }

func (t *ReadOnlyBufferException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReadOnlyBufferException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReadOnlyBufferException_InstanceOf(x any) bool { _, ok := x.(*ReadOnlyBufferException); return ok }

func ReadOnlyBufferException_Cast(x any) *ReadOnlyBufferException { if x == nil { return nil }; v, ok := x.(*ReadOnlyBufferException); if !ok { panic(ClassCast(x, ReadOnlyBufferException_class)) }; return v }
