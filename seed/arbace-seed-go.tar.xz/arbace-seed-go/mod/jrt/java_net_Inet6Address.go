//line java_net_Inet6Address.ae:1
package jrt











func Inet6Address_New_String_B1(p0 *String, p1 *ByteArray) *Inet6Address { Inet6Address_Init(); t := &Inet6Address{}; t.Ctor_String_B1(p0, p1); return t }
//line :13:1
func (t *Inet6Address) Ctor_String_B1(hostName *String, addr *ByteArray) { t.InetAddress.Ctor(t)
	t.F_holder6 = Inet6Address_Inet6AddressHolder_New()
	NN(t.F_holder6).SetAddr_B1__V(addr)
	var tmp1 *InetAddress_InetAddressHolder = t.F_holder; var tmp2 int32; if int32(len(addr.A)) == 16 { tmp2 = 2 } else { tmp2 = -1 }; NN(tmp1).Init_String_I__V(hostName, tmp2)
}



func (t *Inet6Address_Inet6AddressHolder) GetHostAddress__String() *String {
	var s *String = Inet6Address_NumericToTextFormat_B1__String(t.F_ipaddress)
	if t.F_scope_id_set { s = Concat(s, Lit_1310, StrOfInt(t.F_scope_id)) }
//line :22:1
	return s }
//line :22:1
func Inet6Address_Inet6AddressHolder_New() *Inet6Address_Inet6AddressHolder { t := &Inet6Address_Inet6AddressHolder{}; t.Ctor(); return t }
//line :22:1
func (t *Inet6Address_Inet6AddressHolder) Ctor() { t.F_ipaddress = NewByteArray(16) }



















func (t *Inet6Address_Inet6AddressHolder) SetAddr_B1__V(addr *ByteArray) {
	if int32(len(addr.A)) == 16 { System_Arraycopy_O_I_O_I_I__V(addr.Ref(), 0, t.F_ipaddress.Ref(), 0, 16)
	} }
func (t *Inet6Address_Inet6AddressHolder) Init_B1_I__V(addr *ByteArray, scope_id int32) {
	t.SetAddr_B1__V(addr)
	if scope_id >= 0 { t.F_scope_id = scope_id; t.F_scope_id_set = true
	}
}














func (t *Inet6Address_Inet6AddressHolder) Equals_O__Z(o any) bool {
	var tmp1 any = o; if Inet6Address_Inet6AddressHolder_InstanceOf(tmp1) { var that *Inet6Address_Inet6AddressHolder = Inet6Address_Inet6AddressHolder_Cast(tmp1); var tmp2 *ByteArray = t.F_ipaddress
		return Arrays_Equals_B1_B1__Z(tmp2, that.F_ipaddress) } else {
//line :65:1
			return false
		}
}

func (t *Inet6Address_Inet6AddressHolder) HashCode__I() int32 {
	if !(t.F_ipaddress == nil) {
		var hash int32 = 0
		var i int32 = 0
	L1: for { if i < 16 {
		var j int32 = 0
		var component int32 = 0
	L2: for { var tmp1 bool; var tmp2 bool; tmp2 = j < 4; if tmp2 { tmp2 = i < 16 }; tmp1 = tmp2; if tmp1 {
		component = component<<8 + int32(t.F_ipaddress.A[i])

		j = j + 1
		i = i + 1
//line :76:1
		continue L2 }; break L2
	}



		hash = hash + component
//line :73:1
		continue L1 }; break L1 }
//line :71:1
		return hash








	} else {
//line :70:1
		return 0
	}
}












func (t *Inet6Address_Inet6AddressHolder) IsIPv4CompatibleAddress__Z() bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool



	tmp12 = int32(t.F_ipaddress.A[0]) == 0
//line :89:1
	if tmp12 {

		tmp12 = int32(t.F_ipaddress.A[1]) == 0 }
//line :89:1
	tmp11 = tmp12
//line :88:1
	if tmp11 {



		tmp11 = int32(t.F_ipaddress.A[2]) == 0 }
//line :88:1
	tmp10 = tmp11
//line :87:1
	if tmp10 {





		tmp10 = int32(t.F_ipaddress.A[3]) == 0 }
//line :87:1
	tmp9 = tmp10
//line :86:1
	if tmp9 {







		tmp9 = int32(t.F_ipaddress.A[4]) == 0 }
//line :86:1
	tmp8 = tmp9; if tmp8 {








		tmp8 = int32(t.F_ipaddress.A[5]) == 0 }
//line :86:1
	tmp7 = tmp8; if tmp7 {









		tmp7 = int32(t.F_ipaddress.A[6]) == 0 }
//line :86:1
	tmp6 = tmp7; if tmp6 {










		tmp6 = int32(t.F_ipaddress.A[7]) == 0 }
//line :86:1
	tmp5 = tmp6; if tmp5 {











		tmp5 = int32(t.F_ipaddress.A[8]) == 0 }
//line :86:1
	tmp4 = tmp5; if tmp4 {












		tmp4 = int32(t.F_ipaddress.A[9]) == 0 }
//line :86:1
	tmp3 = tmp4; if tmp3 {













		tmp3 = int32(t.F_ipaddress.A[10]) == 0 }
//line :86:1
	tmp2 = tmp3; if tmp2 {














		tmp2 = int32(t.F_ipaddress.A[11]) == 0 }
//line :86:1
	tmp1 = tmp2; if tmp1 { return true } else { return false
	}
}
















func (t *Inet6Address_Inet6AddressHolder) IsMulticastAddress__Z() bool {
	return int32(t.F_ipaddress.A[0])&255 == 255
}
func (t *Inet6Address_Inet6AddressHolder) IsAnyLocalAddress__Z() bool {
	var test int8 = 0; var i int32 = 0
L1: for {
	if i < 16 {
		test = int8(int32(test) | int32(t.F_ipaddress.A[i]))
		i = i + 1; continue L1 }
//line :110:1
	break L1
}


	return int32(test) == 0
}
func (t *Inet6Address_Inet6AddressHolder) IsLoopbackAddress__Z() bool {
	var test int8 = 0; var i int32 = 0
L1: for {
	if i < 15 {
		test = int8(int32(test) | int32(t.F_ipaddress.A[i]))
		i = i + 1; continue L1 }
//line :118:1
	break L1
}


	var tmp1 bool; tmp1 = int32(test) == 0; if tmp1 { tmp1 = int32(t.F_ipaddress.A[15]) == 1 }; return tmp1
}
func (t *Inet6Address_Inet6AddressHolder) IsLinkLocalAddress__Z() bool {
	var tmp1 bool; tmp1 = int32(t.F_ipaddress.A[0])&255 == 254; if tmp1 {
		tmp1 = int32(t.F_ipaddress.A[1])&192 == 128 }
//line :125:1
	return tmp1
}

func (t *Inet6Address_Inet6AddressHolder) IsSiteLocalAddress__Z() bool {
	var tmp1 bool; tmp1 = int32(t.F_ipaddress.A[0])&255 == 254; if tmp1 {
		tmp1 = int32(t.F_ipaddress.A[1])&192 == 192 }
//line :129:1
	return tmp1
}

func (t *Inet6Address_Inet6AddressHolder) IsMCGlobal__Z() bool {
	var tmp1 bool; tmp1 = int32(t.F_ipaddress.A[0])&255 == 255; if tmp1 {
		tmp1 = int32(t.F_ipaddress.A[1])&15 == 14 }
//line :133:1
	return tmp1
}

func (t *Inet6Address_Inet6AddressHolder) IsMCNodeLocal__Z() bool {
	var tmp1 bool; tmp1 = int32(t.F_ipaddress.A[0])&255 == 255; if tmp1 {
		tmp1 = int32(t.F_ipaddress.A[1])&15 == 1 }
//line :137:1
	return tmp1
}

func (t *Inet6Address_Inet6AddressHolder) IsMCLinkLocal__Z() bool {
	var tmp1 bool; tmp1 = int32(t.F_ipaddress.A[0])&255 == 255; if tmp1 {
		tmp1 = int32(t.F_ipaddress.A[1])&15 == 2 }
//line :141:1
	return tmp1
}

func (t *Inet6Address_Inet6AddressHolder) IsMCSiteLocal__Z() bool {
	var tmp1 bool; tmp1 = int32(t.F_ipaddress.A[0])&255 == 255; if tmp1 {
		tmp1 = int32(t.F_ipaddress.A[1])&15 == 5 }
//line :145:1
	return tmp1
}

func (t *Inet6Address_Inet6AddressHolder) IsMCOrgLocal__Z() bool {
	var tmp1 bool; tmp1 = int32(t.F_ipaddress.A[0])&255 == 255; if tmp1 {
		tmp1 = int32(t.F_ipaddress.A[1])&15 == 8 }
//line :149:1
	return tmp1
}







func Inet6Address_New() *Inet6Address { Inet6Address_Init(); t := &Inet6Address{}; t.Ctor(); return t }
//line :158:1
func (t *Inet6Address) Ctor() { t.InetAddress.Ctor(t)

	NN(t.F_holder).Init_String_I__V(nil, 2)
	t.F_holder6 = Inet6Address_Inet6AddressHolder_New()
}
func Inet6Address_New_String_B1_I(p0 *String, p1 *ByteArray, p2 int32) *Inet6Address { Inet6Address_Init(); t := &Inet6Address{}; t.Ctor_String_B1_I(p0, p1, p2); return t }
//line :163:1
func (t *Inet6Address) Ctor_String_B1_I(hostName *String, addr *ByteArray, scope_id int32) { t.InetAddress.Ctor(t)
	NN(t.F_holder).Init_String_I__V(hostName, 2)
	t.F_holder6 = Inet6Address_Inet6AddressHolder_New()
	NN(t.F_holder6).Init_B1_I__V(addr, scope_id)
}









func Inet6Address_New_String_B1_String(p0 *String, p1 *ByteArray, p2 *String) *Inet6Address { Inet6Address_Init(); t := &Inet6Address{}; t.Ctor_String_B1_String(p0, p1, p2); return t }
//line :177:1
func (t *Inet6Address) Ctor_String_B1_String(hostName *String, addr *ByteArray, ifname *String) { t.InetAddress.Ctor(t)
	t.F_holder6 = Inet6Address_Inet6AddressHolder_New()
	t.Initstr_String_B1_String__V(hostName, addr, ifname)
}










func Inet6Address_GetByAddress_String_B1_I__Inet6Address(host *String, addr *ByteArray, scope_id int32) *Inet6Address { Inet6Address_Init()


	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !(host == nil); if tmp3 { tmp3 = !NN(host).IsEmpty__Z() }; tmp2 = tmp3; if tmp2 { tmp2 = int32(NN(host).CharAt_I__C(0)) == 91 }; tmp1 = tmp2; if tmp1 {
		if int32(NN(host).CharAt_I__C(NN(host).Length__I()-1)) == 93 {
			host = NN(host).Substring_I_I__String(1, NN(host).Length__I()-1) } }
	if !(addr == nil) {
		if int32(len(addr.A)) == 16 { return Inet6Address_New_String_B1_I(host, addr, scope_id) } }
	panic(Thrown(UnknownHostException_New_String(Lit_1305)))
}
func Inet6Address_OfLiteral_String__InetAddress(ipv6AddressLiteral *String) InetAddress_I { Inet6Address_Init()
	Objects_RequireNonNull_O__O(ipv6AddressLiteral.Ref()); tmp1, tmp2, tmp3 := func() (ctl int32, rv InetAddress_I, exc Throwable_I) { defer Catch(&exc)

		{ var parsedAddress InetAddress_I = Inet6Address_ParseAddressString_String_Z__InetAddress(ipv6AddressLiteral, true)
			if !(parsedAddress == nil) { return 2, parsedAddress, nil } }; return 0, nil, nil }()
//line :203:1
	if tmp3 != nil { if UnknownHostException_InstanceOf(tmp3) { var uhe *UnknownHostException = UnknownHostException_Cast(tmp3); _ = uhe } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2
	}
	}

	panic(Thrown(IPAddressUtil_InvalidIpAddressLiteral_String__IllegalArgumentException(ipv6AddressLiteral)))
}
func Inet6Address_ParseAddressString_String_Z__InetAddress(addressLiteral *String, removeSqBrackets bool) InetAddress_I { Inet6Address_Init()

	if NN(addressLiteral).IsEmpty__Z() { return nil } else {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = removeSqBrackets; if tmp4 { tmp4 = int32(NN(addressLiteral).CharAt_I__C(0)) == 91 }; tmp3 = tmp4; if tmp3 {
			tmp3 = NN(addressLiteral).Length__I() > 2 }
//line :212:1
		tmp2 = tmp3; if tmp2 {

			tmp2 = int32(NN(addressLiteral).CharAt_I__C(NN(addressLiteral).Length__I()-1)) == 93 }
//line :212:1
		tmp1 = tmp2; if tmp1 {



			addressLiteral = NN(addressLiteral).Substring_I_I__String(1, NN(addressLiteral).Length__I()-1)
		}
		var pos int32 = 0; var numericZone int32 = -1; var ifname *String; var tmp5 int32


		pos = NN(addressLiteral).IndexOf_I__I(37); tmp5 = pos; if tmp5 == -1 { } else {
			numericZone = Inet6Address_CheckNumericZone_String__I(addressLiteral)
			if numericZone == -1 {
				ifname = NN(addressLiteral).Substring_I__String(pos + 1) } }
		var addrBytes *ByteArray = IPAddressUtil_TextToNumericFormatV6_String__B1(addressLiteral)
		if !(addrBytes == nil) {
			if int32(len(addrBytes.A)) == 4 {


				var tmp6 bool; var tmp7 bool; tmp7 = !(numericZone == -1); if !tmp7 { tmp7 = !(ifname == nil) }; tmp6 = tmp7; if tmp6 {
					panic(Thrown(UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1306, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(addressLiteral).SuffixWith_String__Exceptions_SensitiveInfo(Lit_1157))))))
				}





				return Inet4Address_New_String_B1(nil, addrBytes) } else {
//line :227:1
					if !(ifname == nil) {











						return Inet6Address_New_String_B1_String(nil, addrBytes, ifname) } else {
							return Inet6Address_New_String_B1_I(nil, addrBytes, numericZone) } } } else {
//line :226:1
								return nil
							}
	}
}












func Inet6Address_CheckNumericZone_String__I(s *String) int32 { Inet6Address_Init()
	var percent int32 = NN(s).IndexOf_I__I(37); var slen int32 = NN(s).Length__I()
	var digit int32 = 0
	var zone int32 = 0
	var multmax int32 = 214748364

	if percent == -1 { return -1 } else {


		var i int32 = percent + 1; L1: for {
			if i < slen {
				var c uint16 = NN(s).CharAt_I__C(i); var tmp1 int32
				digit = IPAddressUtil_ParseAsciiDigit_C_I__I(c, 10); tmp1 = digit; if tmp1 < 0 { return -1 }
				if zone > multmax { return -1 }
				zone = zone*10 + digit
				if zone < 0 { return -1 } else { i = i + 1; continue L1 } }
//line :251:1
			break L1 }
//line :250:1
		return zone
	}
}







func (t *Inet6Address) Initstr_String_B1_String__V(hostName *String, addr *ByteArray, ifname *String) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)


	{ var nif any; nif = A2g_Missing[any]("class java.net.NetworkInterface is not in the closed world")
		if nif == nil { panic(Thrown(UnknownHostException_New_String(Concat(Lit_1307, ifname)))) }
		A2g_Missing[bool]("class java.net.NetworkInterface is not in the closed world") }; return nil }(); if /*line :262:1*/ tmp1 != nil { if SocketException_InstanceOf(tmp1) { var e SocketException_I = SocketException_Cast(tmp1); _ = e




			panic(Thrown(UnknownHostException_New_String(Concat(Lit_1308, ifname)))) } else {
//line :262:1
				panic(tmp1) } } }













func Inet6Address_IsDifferentLocalAddressType_B1_B1__Z(thisAddr, otherAddr *ByteArray) bool { Inet6Address_Init()

	var tmp1 bool; var tmp2 bool
	tmp2 = Inet6Address_IsLinkLocalAddress_B1__Z(thisAddr); if tmp2 {
		tmp2 = !Inet6Address_IsLinkLocalAddress_B1__Z(otherAddr) }
//line :279:1
	tmp1 = tmp2
//line :278:1
	if tmp1 { return false } else { var tmp3 bool; var tmp4 bool



		tmp4 = Inet6Address_IsSiteLocalAddress_B1__Z(thisAddr); if tmp4 {
			tmp4 = !Inet6Address_IsSiteLocalAddress_B1__Z(otherAddr) }
//line :282:1
		tmp3 = tmp4
//line :278:1
		if tmp3 { return false } else { return true
		}
	}
}

















func (t *Inet6Address) DeriveNumericScope_String__I(p0 *String) int32 { panic(A2g_NotTranslated("java.net.Inet6Address.deriveNumericScope(Ljava/lang/String;)I")) }


































































func (t *Inet6Address) IsMulticastAddress__Z() bool {
	return NN(t.F_holder6).IsMulticastAddress__Z()
}
func (t *Inet6Address) IsAnyLocalAddress__Z() bool {
	return NN(t.F_holder6).IsAnyLocalAddress__Z()
}
func (t *Inet6Address) IsLoopbackAddress__Z() bool {
	return NN(t.F_holder6).IsLoopbackAddress__Z()
}
func (t *Inet6Address) IsLinkLocalAddress__Z() bool {
	return NN(t.F_holder6).IsLinkLocalAddress__Z()
}
func Inet6Address_IsLinkLocalAddress_B1__Z(ipaddress *ByteArray) bool { Inet6Address_Init()
	var tmp1 bool; tmp1 = int32(ipaddress.A[0])&255 == 254; if tmp1 {
		tmp1 = int32(ipaddress.A[1])&192 == 128 }
//line :379:1
	return tmp1
}

func (t *Inet6Address) IsSiteLocalAddress__Z() bool {
	return NN(t.F_holder6).IsSiteLocalAddress__Z()
}
func Inet6Address_IsSiteLocalAddress_B1__Z(ipaddress *ByteArray) bool { Inet6Address_Init()
	var tmp1 bool; tmp1 = int32(ipaddress.A[0])&255 == 254; if tmp1 {
		tmp1 = int32(ipaddress.A[1])&192 == 192 }
//line :386:1
	return tmp1
}

func (t *Inet6Address) IsMCGlobal__Z() bool { return NN(t.F_holder6).IsMCGlobal__Z() }

func (t *Inet6Address) IsMCNodeLocal__Z() bool { return NN(t.F_holder6).IsMCNodeLocal__Z() }

func (t *Inet6Address) IsMCLinkLocal__Z() bool { return NN(t.F_holder6).IsMCLinkLocal__Z() }

func (t *Inet6Address) IsMCSiteLocal__Z() bool { return NN(t.F_holder6).IsMCSiteLocal__Z() }

func (t *Inet6Address) IsMCOrgLocal__Z() bool { return NN(t.F_holder6).IsMCOrgLocal__Z() }

func (t *Inet6Address) GetAddress__B1() *ByteArray {
	return NN(t.F_holder6.F_ipaddress).Copy()
}
func (t *Inet6Address) AddressBytes__B1() *ByteArray { panic(A2g_NotTranslated("java.net.Inet6Address.addressBytes()[B")) }

func (t *Inet6Address) GetScopeId__I() int32 { return t.F_holder6.F_scope_id }




func (t *Inet6Address) GetHostAddress__String() *String {
	return NN(t.F_holder6).GetHostAddress__String()
}
func (t *Inet6Address) HashCode__I() int32 { return NN(t.F_holder6).HashCode__I() }

func (t *Inet6Address) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Inet6Address_InstanceOf(tmp1) { var inetAddr *Inet6Address = Inet6Address_Cast(tmp1); var tmp2 *Inet6Address_Inet6AddressHolder = t.F_holder6; return NN(tmp2).Equals_O__Z(inetAddr.F_holder6.Ref()) } else { return false
	} }
func (t *Inet6Address) IsIPv4CompatibleAddress__Z() bool {
	return NN(t.F_holder6).IsIPv4CompatibleAddress__Z()
}


func Inet6Address_NumericToTextFormat_B1__String(src *ByteArray) *String { Inet6Address_Init()
	var sb *StringBuilder = StringBuilder_New_I(39); var i int32 = 0
L1: for {
	if i < 8 {
		var tmp1 int32 = int32(src.A[i<<1]) << 8 & 65280; NN(sb).Append_String__StringBuilder(Integer_ToHexString_I__String(tmp1 | int32(src.A[i<<1+1])&255))









		if i < 7 {
			NN(sb).Append_String__StringBuilder(Lit_1309); i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :424:1
	break L1
}













	return NN(sb).ToString__String()
}


type Inet6Address struct{ InetAddress; F_holder6 *Inet6Address_Inet6AddressHolder }

const Inet6Address_INADDRSZ int32 = 16

const Inet6Address_serialVersionUID int64 = 6880410070516793377

var Inet6Address_UNSAFE *Unsafe

var Inet6Address_FIELDS_OFFSET int64

const Inet6Address_INT16SZ int32 = 2

var Inet6Address_init ClassInit

func Inet6Address_Init() { if !Inet6Address_init.Done() { Inet6Address_init.Run(Inet6Address_clinit) } }

func Inet6Address_clinit() { InetAddress_Init(); Inet6Address_UNSAFE = Unsafe_GetUnsafe__Unsafe(); Inet6Address_FIELDS_OFFSET = NN(Inet6Address_UNSAFE).ObjectFieldOffset_Class_String__J(Inet6Address_class, Lit_1304) }

func (t *Inet6Address) Holder__InetAddress_InetAddressHolder() *InetAddress_InetAddressHolder { return t.Impl_Holder__InetAddress_InetAddressHolder(t) }

func (t *Inet6Address) IsReachable_I__Z(p0 int32) bool { return t.Impl_IsReachable_I__Z(t, p0) }

func (t *Inet6Address) GetHostName__String() *String { return t.Impl_GetHostName__String(t) }

func (t *Inet6Address) GetCanonicalHostName__String() *String { return t.Impl_GetCanonicalHostName__String(t) }

func (t *Inet6Address) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Inet6Address) Ref() any { if t == nil { return nil }; return t }

func (t *Inet6Address) GetClass__Class() *Class { return Inet6Address_class }

func (t *Inet6Address) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Inet6Address) CloneShallow() any { panic(CloneNotSupported(t)) }

func Inet6Address_InstanceOf(x any) bool { _, ok := x.(*Inet6Address); return ok }

func Inet6Address_Cast(x any) *Inet6Address { if x == nil { return nil }; v, ok := x.(*Inet6Address); if !ok { panic(ClassCast(x, Inet6Address_class)) }; return v }



type Inet6Address_Inet6AddressHolder struct{ Object; F_ipaddress *ByteArray; F_scope_id int32; F_scope_id_set, F_scope_ifname_set bool }

func (t *Inet6Address_Inet6AddressHolder) Ref() any { if t == nil { return nil }; return t }

func (t *Inet6Address_Inet6AddressHolder) GetClass__Class() *Class { return Inet6Address_Inet6AddressHolder_class }

func (t *Inet6Address_Inet6AddressHolder) ToString__String() *String { return Object_toString(t) }

func (t *Inet6Address_Inet6AddressHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Inet6Address_Inet6AddressHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func Inet6Address_Inet6AddressHolder_InstanceOf(x any) bool { _, ok := x.(*Inet6Address_Inet6AddressHolder); return ok }

func Inet6Address_Inet6AddressHolder_Cast(x any) *Inet6Address_Inet6AddressHolder { if x == nil { return nil }; v, ok := x.(*Inet6Address_Inet6AddressHolder); if !ok { panic(ClassCast(x, Inet6Address_Inet6AddressHolder_class)) }; return v }
