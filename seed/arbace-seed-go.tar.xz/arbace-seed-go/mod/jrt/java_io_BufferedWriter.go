//line java_io_BufferedWriter.ae:1
package jrt























func BufferedWriter_InitialBufferSize__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = VM_IsBooted__Z(); if tmp2 { tmp2 = Thread_CurrentThread__Thread().IsVirtual__Z() }; tmp1 = tmp2; if tmp1 { return 512 } else { return 8192
	}
}

func BufferedWriter_New_Writer_I_I(p0 Writer_I, p1, p2 int32) *BufferedWriter { t := &BufferedWriter{}; t.Ctor_Writer_I_I(t, p0, p1, p2); return t }
//line :30:1
func (t *BufferedWriter) Ctor_Writer_I_I(this BufferedWriter_I, out Writer_I, initialSize, maxSize int32) { t.Writer.Ctor_O(this, out)

	if initialSize <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_47))) }
	t.F_out = out
	t.F_cb = NewCharArray(initialSize)
	t.F_nChars = initialSize
	t.F_maxChars = maxSize
}
func BufferedWriter_New_Writer(p0 Writer_I) *BufferedWriter { t := &BufferedWriter{}; t.Ctor_Writer(t, p0); return t }
//line :38:1
func (t *BufferedWriter) Ctor_Writer(this BufferedWriter_I, out Writer_I) { t.Ctor_Writer_I_I(this, out, BufferedWriter_InitialBufferSize__I(), 8192) }


func BufferedWriter_New_Writer_I(p0 Writer_I, p1 int32) *BufferedWriter { t := &BufferedWriter{}; t.Ctor_Writer_I(t, p0, p1); return t }
//line :41:1
func (t *BufferedWriter) Ctor_Writer_I(this BufferedWriter_I, out Writer_I, sz int32) { t.Ctor_Writer_I_I(this, out, sz, sz) }

func (t *BufferedWriter) Impl_EnsureOpen__V(this BufferedWriter_I) {
	if t.F_out == nil { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *BufferedWriter) Impl_GrowIfNeeded_I__V(this BufferedWriter_I, len_ int32) {
	var neededSize int32 = t.F_nextChar + len_ + 1
	if neededSize < 0 { neededSize = 2147483647 }
	var tmp1 bool; var tmp2 bool; tmp2 = neededSize > t.F_nChars; if tmp2 { tmp2 = t.F_nChars < t.F_maxChars }; tmp1 = tmp2; if tmp1 {
		var newSize int32 = t.Impl_Min_I_I__I(this, neededSize, t.F_maxChars)
		t.F_cb = Arrays_CopyOf_C1_I__C1(t.F_cb, newSize)
		t.F_nChars = newSize
	} }
func (t *BufferedWriter) Impl_FlushBuffer__V(this BufferedWriter_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		if t.F_nextChar == 0 { } else { t.F_out.Write_C1_I_I__V(t.F_cb, 0, t.F_nextChar); t.F_nextChar = 0
		} }() }
func (t *BufferedWriter) Impl_Write_I__V(this BufferedWriter_I, c int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		t.Impl_GrowIfNeeded_I__V(this, 1)
		if t.F_nextChar >= t.F_nChars { this.FlushBuffer__V() }
		var tmp2 *CharArray = t.F_cb; var tmp3 int32; var old_1 int32 = t.F_nextChar
		t.F_nextChar = t.F_nextChar + 1; tmp3 = old_1
//line :64:1
		tmp2.A[tmp3] = uint16(c)
	}()
}

func (t *BufferedWriter) Impl_Min_I_I__I(this BufferedWriter_I, a, b int32) int32 { if a < b { return a } else { return b } }

func (t *BufferedWriter) Impl_Write_C1_I_I__V(this BufferedWriter_I, cbuf *CharArray, off, len_ int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
		if len_ == 0 { } else {
			if len_ >= t.F_maxChars {
				this.FlushBuffer__V(); t.F_out.Write_C1_I_I__V(cbuf, off, len_) } else {

					t.Impl_GrowIfNeeded_I__V(this, len_)
					var b int32 = off; var t_ int32 = off + len_

				L1: for { if b < t_ {
					var d int32 = t.Impl_Min_I_I__I(this, t.F_nChars-t.F_nextChar, t_-b)


					System_Arraycopy_O_I_O_I_I__V(cbuf.Ref(), b, t.F_cb.Ref(), t.F_nextChar, d)
					b = b + d
					t.F_nextChar = t.F_nextChar + d
					if t.F_nextChar >= t.F_nChars { this.FlushBuffer__V() }
//line :81:1
					continue L1 }; break L1
				}
				}
		}
	}()
}



func (t *BufferedWriter) Impl_Write_String_I_I__V(this BufferedWriter_I, s *String, off, len_ int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		t.Impl_GrowIfNeeded_I__V(this, len_)
		var b int32 = off; var t_ int32 = off + len_

	L1: for { if b < t_ {
		var d int32 = t.Impl_Min_I_I__I(this, t.F_nChars-t.F_nextChar, t_-b)
		NN(s).GetChars_I_I_C1_I__V(b, b+d, t.F_cb, t.F_nextChar)
		b = b + d
		t.F_nextChar = t.F_nextChar + d
		if t.F_nextChar >= t.F_nChars { this.FlushBuffer__V() }
//line :96:1
		continue L1 }; break L1
	}
	}()
}



func (t *BufferedWriter) Impl_NewLine__V(this BufferedWriter_I) {
	this.Write_String__V(System_LineSeparator__String())
}
func (t *BufferedWriter) Impl_Flush__V(this BufferedWriter_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); this.FlushBuffer__V(); t.F_out.Flush__V() }()
}
func (t *BufferedWriter) Impl_Close__V(this BufferedWriter_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if !(t.F_out == nil) { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
			{ var w Writer_I = t.F_out; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); this.FlushBuffer__V(); return nil }(); if tmp2 == nil { if !(w == nil) { w.Close__V() } }; if tmp2 != nil { if true { var t_100989 Throwable_I = tmp2; if !(w == nil) { tmp3 := func() (exc Throwable_I) { defer Catch(&exc); w.Close__V(); return nil }(); if tmp3 != nil { if true { var x_100990 Throwable_I = tmp3; t_100989.AddSuppressed_Throwable__V(x_100990) } } }; panic(Thrown(t_100989)) } } }; return nil }(); t.F_out = nil; t.F_cb = nil; if tmp4 != nil { panic(tmp4)
			}
		}
	}() }
type BufferedWriter struct{ Writer; F_out Writer_I; F_cb *CharArray; F_nChars, F_nextChar, F_maxChars int32 }

type BufferedWriter_I interface{ Writer_I; Appendable; Closeable; Flushable; AutoCloseable; Self_BufferedWriter() *BufferedWriter; FlushBuffer__V(); Write_I__V(p0 int32); Write_C1_I_I__V(p0 *CharArray, p1, p2 int32); Write_String_I_I__V(p0 *String, p1, p2 int32); NewLine__V(); Flush__V(); Close__V() }

func (t *BufferedWriter) Self_BufferedWriter() *BufferedWriter { return t }

const BufferedWriter_DEFAULT_INITIAL_BUFFER_SIZE int32 = 512

const BufferedWriter_DEFAULT_MAX_BUFFER_SIZE int32 = 8192

func (t *BufferedWriter) Write_C1__V(p0 *CharArray) { t.Impl_Write_C1__V(t, p0) }

func (t *BufferedWriter) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return t.Impl_Append_CharSequence_I_I__Appendable(t, p0, p1, p2) }

func (t *BufferedWriter) Append_CharSequence_I_I__Writer(p0 CharSequence, p1, p2 int32) Writer_I { return t.Impl_Append_CharSequence_I_I__Writer(t, p0, p1, p2) }

func (t *BufferedWriter) Flush__V() { t.Impl_Flush__V(t) }

func (t *BufferedWriter) Append_C__Writer(p0 uint16) Writer_I { return t.Impl_Append_C__Writer(t, p0) }

func (t *BufferedWriter) NewLine__V() { t.Impl_NewLine__V(t) }

func (t *BufferedWriter) Close__V() { t.Impl_Close__V(t) }

func (t *BufferedWriter) Write_String__V(p0 *String) { t.Impl_Write_String__V(t, p0) }

func (t *BufferedWriter) Write_C1_I_I__V(p0 *CharArray, p1, p2 int32) { t.Impl_Write_C1_I_I__V(t, p0, p1, p2) }

func (t *BufferedWriter) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return t.Impl_Append_CharSequence__Appendable(t, p0) }

func (t *BufferedWriter) FlushBuffer__V() { t.Impl_FlushBuffer__V(t) }

func (t *BufferedWriter) Append_C__Appendable(p0 uint16) Appendable { return t.Impl_Append_C__Appendable(t, p0) }

func (t *BufferedWriter) Append_CharSequence__Writer(p0 CharSequence) Writer_I { return t.Impl_Append_CharSequence__Writer(t, p0) }

func (t *BufferedWriter) Write_I__V(p0 int32) { t.Impl_Write_I__V(t, p0) }

func (t *BufferedWriter) Write_String_I_I__V(p0 *String, p1, p2 int32) { t.Impl_Write_String_I_I__V(t, p0, p1, p2) }

func (t *BufferedWriter) Ref() any { if t == nil { return nil }; return t }

func (t *BufferedWriter) GetClass__Class() *Class { return BufferedWriter_class }

func (t *BufferedWriter) ToString__String() *String { return Object_toString(t) }

func (t *BufferedWriter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BufferedWriter) CloneShallow() any { panic(CloneNotSupported(t)) }

func BufferedWriter_InstanceOf(x any) bool { _, ok := x.(BufferedWriter_I); return ok }

func BufferedWriter_Cast(x any) BufferedWriter_I { if x == nil { return nil }; v, ok := x.(BufferedWriter_I); if !ok { panic(ClassCast(x, BufferedWriter_class)) }; return v }
