//line java_io_InputStreamReader.ae:1
package jrt



































func InputStreamReader_New_InputStream(p0 InputStream_I) *InputStreamReader { t := &InputStreamReader{}; t.Ctor_InputStream(t, p0); return t }
//line :37:1
func (t *InputStreamReader) Ctor_InputStream(this InputStreamReader_I, in InputStream_I) { t.Reader.Ctor_O(this, in); t.F_bb = NewByteArray(8192)

	t.F_in = in
	t.F_cs = Charset_DefaultCharset__Charset()
	t.F_kind = InputStreamReader_KindOf_Charset__I(t.F_cs)
}
func InputStreamReader_New_InputStream_String(p0 InputStream_I, p1 *String) *InputStreamReader { t := &InputStreamReader{}; t.Ctor_InputStream_String(t, p0, p1); return t }
//line :43:1
func (t *InputStreamReader) Ctor_InputStream_String(this InputStreamReader_I, in InputStream_I, charsetName *String) { t.Reader.Ctor_O(this, in); t.F_bb = NewByteArray(8192)


	if charsetName == nil { panic(Thrown(NullPointerException_New_String(Lit_85))) }
	var c Charset_I; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		c = Charset_ForName_String__Charset(charsetName)
//line :47:1
		return nil }()
	if tmp1 != nil { if IllegalCharsetNameException_InstanceOf(tmp1) || UnsupportedCharsetException_InstanceOf(tmp1) { var x IllegalArgumentException_I = IllegalArgumentException_Cast(tmp1); _ = x


		panic(Thrown(UnsupportedEncodingException_New_String(charsetName))) } else {
//line :48:1
			panic(tmp1)
		}
	}

	t.F_in = in
	t.F_cs = c
	t.F_kind = InputStreamReader_KindOf_Charset__I(c)
}
func InputStreamReader_New_InputStream_Charset(p0 InputStream_I, p1 Charset_I) *InputStreamReader { t := &InputStreamReader{}; t.Ctor_InputStream_Charset(t, p0, p1); return t }
//line :56:1
func (t *InputStreamReader) Ctor_InputStream_Charset(this InputStreamReader_I, in InputStream_I, cs Charset_I) { t.Reader.Ctor_O(this, in); t.F_bb = NewByteArray(8192)

	if cs == nil { panic(Thrown(NullPointerException_New_String(Lit_86))) }
	t.F_in = in
	t.F_cs = cs
	t.F_kind = InputStreamReader_KindOf_Charset__I(cs)
}
func InputStreamReader_KindOf_Charset__I(cs Charset_I) int32 {
	var n *String = cs.Name__String()
	if NN(n).Equals_O__Z(Lit_87) { return 1 } else { if NN(n).Equals_O__Z(Lit_88) { return 2 } else { if NN(n).Equals_O__Z(Lit_89) { return 0 } else {



		panic(Thrown(UnsupportedOperationException_New_String(Concat(Lit_90, n))))
	} } } }
func (t *InputStreamReader) Impl_GetEncoding__String(this InputStreamReader_I) *String {
	var tmp1 *String; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); if t.F_closed { tmp1 = nil } else { switch t.F_kind { case 1: tmp1 = Lit_92; case 2: tmp1 = Lit_93; default: tmp1 = Lit_91} } }(); return tmp1
}
func (t *InputStreamReader) Impl_EnsureOpen__V(this InputStreamReader_I) {
	if t.F_closed { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *InputStreamReader) Impl_Read__I(this InputStreamReader_I) int32 {
	var one *CharArray = NewCharArray(1); var n int32 = this.Read_C1_I_I__I(one, 0, 1); if n < 0 { return -1 } else { return int32(one.A[0])
	} }
func (t *InputStreamReader) Impl_Read_C1_I_I__I(this InputStreamReader_I, cbuf *CharArray, off, len_ int32) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); tmp7, tmp8 := func() (ctl, rv int32) { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
		Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
		if len_ == 0 { tmp1 = 0 } else {

			var n int32 = 0
			if int32(t.F_pending) == 0 { } else {
				cbuf.A[off+n] = t.F_pending
				n = n + 1
				t.F_pending = 0 }
		L1: for {
			n = t.Impl_Decode_C1_I_I_I__I(this, cbuf, off, len_, n)
			var tmp3 bool; var tmp4 bool; tmp4 = n > 0; if tmp4 { var tmp5 bool; tmp5 = n == len_; if !tmp5 { tmp5 = !t.Impl_InReady__Z(this) }; tmp4 = tmp5 }; tmp3 = tmp4; if tmp3 { return 2, n }
			if t.F_eof {
				if t.F_bpos < t.F_blim {
					t.F_bpos = t.F_blim
					cbuf.A[off+n] = 65533
					n = n + 1
					continue L1 }
				var tmp6 int32; if n == 0 { tmp6 = -1 } else { tmp6 = n }; return 3, tmp6 }
			if n == len_ { return 4, n }
			t.Impl_Fill__V(this)
//line :91:1
			continue L1
		}
		}








		return 0, 0 }()
//line :81:1
	switch tmp7 { case 2: { return tmp8 }; case 3: { return tmp8 }; case 4: { return tmp8 }}; return tmp1
}





















func (t *InputStreamReader) Impl_InReady__Z(this InputStreamReader_I) bool {
	var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = t.F_in.Available__I() > 0; return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; tmp1 = false } else { panic(tmp2) } }; return tmp1
}
func (t *InputStreamReader) Impl_Fill__V(this InputStreamReader_I) {
	if t.F_bpos > 0 {
		System_Arraycopy_O_I_O_I_I__V(t.F_bb.Ref(), t.F_bpos, t.F_bb.Ref(), 0, t.F_blim-t.F_bpos)
		t.F_blim = t.F_blim - t.F_bpos
		t.F_bpos = 0 }
	var tmp1 InputStream_I = t.F_in; var tmp2 *ByteArray = t.F_bb; var tmp3 int32 = t.F_blim; var r int32 = tmp1.Read_B1_I_I__I(tmp2, tmp3, int32(len(t.F_bb.A))-t.F_blim)
	if r < 0 { t.F_eof = true } else { t.F_blim = t.F_blim + r
	} }
func InputStreamReader_NotCont_I__Z(b int32) bool {
	return !(b&192 == 128)
}
func (t *InputStreamReader) Impl_Decode_C1_I_I_I__I(this InputStreamReader_I, cbuf *CharArray, off, len_, n int32) int32 {
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = t.F_bpos < t.F_blim; if tmp2 { tmp2 = n < len_ }; tmp1 = tmp2; if tmp1 {
	var b1 int32 = int32(t.F_bb.A[t.F_bpos])
	if !(t.F_kind == 0) {

		var tmp3 int32 = off + n; var tmp4 uint16; var tmp5 bool; var tmp6 bool

		tmp6 = t.F_kind == 2; if tmp6 { tmp6 = b1 < 0 }; tmp5 = tmp6; if tmp5 { tmp4 = 65533 } else {

			tmp4 = uint16(b1 & 255) }
//line :123:1
		cbuf.A[tmp3] = tmp4




		n = n + 1
		t.F_bpos = t.F_bpos + 1 } else {
			var rem int32 = t.F_blim - t.F_bpos
			if b1 >= 0 {


				cbuf.A[off+n] = uint16(b1)
				n = n + 1
				t.F_bpos = t.F_bpos + 1 } else {
//line :131:1
					var tmp7 bool; var tmp8 bool





					tmp8 = b1>>5 == -2; if tmp8 { tmp8 = !(b1&30 == 0) }; tmp7 = tmp8
//line :131:1
					if tmp7 {







						if rem < 2 { return n }
						var b2 int32 = int32(t.F_bb.A[t.F_bpos+1])
						if InputStreamReader_NotCont_I__Z(b2) {
							t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, n, 1); n = n + 1 } else {

								cbuf.A[off+n] = uint16(b1&31<<6 | b2&63)




								n = n + 1
								t.F_bpos = t.F_bpos + 2 } } else {
//line :131:1
									if b1>>4 == -2 {





















										if rem < 3 {
											var tmp9 bool; var tmp10 bool; tmp10 = rem > 1; if tmp10 {
												var tmp11 bool; var tmp12 bool; tmp12 = b1 == -32; if tmp12 {
													tmp12 = int32(t.F_bb.A[t.F_bpos+1])&224 == 128 }
//line :155:1
												tmp11 = tmp12; if !tmp11 {




													tmp11 = InputStreamReader_NotCont_I__Z(int32(t.F_bb.A[t.F_bpos+1])) }
//line :155:1
												tmp10 = tmp11 }
//line :154:1
											tmp9 = tmp10; if tmp9 {







												t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, n, 1)
												n = n + 1
												continue L1 }
											return n }
										var b2_2 int32 = int32(t.F_bb.A[t.F_bpos+1]); var b3 int32 = int32(t.F_bb.A[t.F_bpos+2]); var tmp13 bool; var tmp14 bool; var tmp15 bool; var tmp16 bool

										tmp16 = b1 == -32; if tmp16 {
											tmp16 = b2_2&224 == 128 }
//line :168:1
										tmp15 = tmp16; if !tmp15 {

											tmp15 = InputStreamReader_NotCont_I__Z(b2_2) }
//line :168:1
										tmp14 = tmp15; if !tmp14 {


											tmp14 = InputStreamReader_NotCont_I__Z(b3) }
//line :168:1
										tmp13 = tmp14; if tmp13 {




											var tmp17 int32 = n; var tmp18 int32; var tmp19 bool; var tmp20 bool; var tmp21 bool




											tmp21 = b1 == -32
//line :177:1
											if tmp21 {

												tmp21 = b2_2&224 == 128 }
//line :177:1
											tmp20 = tmp21; if !tmp20 {


												tmp20 = InputStreamReader_NotCont_I__Z(b2_2) }
//line :177:1
											tmp19 = tmp20; if tmp19 { tmp18 = 1 } else { tmp18 = 2 }
//line :173:1
											t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, tmp17, tmp18)









											n = n + 1 } else {
												var c uint16 = uint16(b1&15<<12 | b2_2&63<<6 | b3&63)




												if Character_IsSurrogate_C__Z(c) {
													t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, n, 3); n = n + 1 } else {

														cbuf.A[off+n] = c
														n = n + 1
														t.F_bpos = t.F_bpos + 3 } } } else {
//line :131:1
															if b1>>3 == -2 {
































































																var u1 int32 = b1 & 255
																if rem < 4 {
																	var tmp22 bool; var tmp23 bool; tmp23 = u1 > 244; if !tmp23 {
																		var tmp24 bool; tmp24 = rem > 1; if tmp24 {
																			tmp24 = InputStreamReader_Malformed4First_I_I__Z(u1, int32(t.F_bb.A[t.F_bpos+1])&255) }
//line :199:1
																		tmp23 = tmp24 }
//line :198:1
																	tmp22 = tmp23; if tmp22 {




																		t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, n, 1)
																		n = n + 1
																		continue L1 }
																	var tmp25 bool; var tmp26 bool; tmp26 = rem > 2; if tmp26 {
																		tmp26 = InputStreamReader_NotCont_I__Z(int32(t.F_bb.A[t.F_bpos+2])) }
//line :206:1
																	tmp25 = tmp26; if tmp25 {

																		t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, n, 2)
																		n = n + 1
																		continue L1 }
																	return n }
																var b2_3 int32 = int32(t.F_bb.A[t.F_bpos+1]); var b3_2 int32 = int32(t.F_bb.A[t.F_bpos+2]); var b4 int32 = int32(t.F_bb.A[t.F_bpos+3]); var uc int32 = b1&7<<18 | b2_3&63<<12 | b3_2&63<<6 | b4&63; var tmp27 bool; var tmp28 bool; var tmp29 bool; var tmp30 bool








																tmp30 = InputStreamReader_NotCont_I__Z(b2_3); if !tmp30 { tmp30 = InputStreamReader_NotCont_I__Z(b3_2) }; tmp29 = tmp30; if !tmp29 {
																	tmp29 = InputStreamReader_NotCont_I__Z(b4) }
//line :221:1
																tmp28 = tmp29; if !tmp28 {

																	tmp28 = !Character_IsSupplementaryCodePoint_I__Z(uc) }
//line :221:1
																tmp27 = tmp28; if tmp27 {


																	var u2 int32 = b2_3 & 255; var tmp31 int32 = n; var tmp32 int32; var tmp33 bool; var tmp34 bool





																	tmp34 = u1 > 244; if !tmp34 { tmp34 = InputStreamReader_Malformed4First_I_I__Z(u1, u2) }; tmp33 = tmp34
//line :229:1
																	if tmp33 { tmp32 = 1 } else { if InputStreamReader_NotCont_I__Z(b3_2) { tmp32 = 2 } else { tmp32 = 3 } }
//line :225:1
																	t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, tmp31, tmp32)








																	n = n + 1 } else {

																		cbuf.A[off+n] = Character_HighSurrogate_I__C(uc)
																		n = n + 1
																		t.F_bpos = t.F_bpos + 4
																		if n < len_ {

																			cbuf.A[off+n] = Character_LowSurrogate_I__C(uc)
																			n = n + 1 } else {
																				t.F_pending = Character_LowSurrogate_I__C(uc) } } } else {
																					t.Impl_Malformed_C1_I_I_I__V(this, cbuf, off, n, 1); n = n + 1 } } } } }
//line :119:1
	continue L1 }; break L1 }
//line :118:1
	return n
}































































































































func InputStreamReader_Malformed4First_I_I__Z(u1, u2 int32) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = u1 == 240; if tmp3 { var tmp4 bool; tmp4 = u2 < 144; if !tmp4 { tmp4 = u2 > 191 }; tmp3 = tmp4 }; tmp2 = tmp3; if !tmp2 {
		var tmp5 bool; tmp5 = u1 == 244; if tmp5 { tmp5 = !(u2&240 == 128) }; tmp2 = tmp5 }
//line :248:1
	tmp1 = tmp2; if !tmp1 {

		tmp1 = !(u2&192 == 128) }
//line :248:1
	return tmp1
}


func (t *InputStreamReader) Impl_Malformed_C1_I_I_I__V(this InputStreamReader_I, cbuf *CharArray, off, n, length int32) {
	cbuf.A[off+n] = 65533
	t.F_bpos = t.F_bpos + length
}
func (t *InputStreamReader) Impl_Ready__Z(this InputStreamReader_I) bool {
	var tmp1 bool; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
		var tmp3 bool; var tmp4 bool; tmp4 = !(int32(t.F_pending) == 0); if !tmp4 { tmp4 = t.F_bpos < t.F_blim }; tmp3 = tmp4; if !tmp3 { tmp3 = t.Impl_InReady__Z(this) }; tmp1 = tmp3 }()
//line :257:1
	return tmp1
}


func (t *InputStreamReader) Impl_Close__V(this InputStreamReader_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); if t.F_closed { } else { tmp2 := func() (exc Throwable_I) { defer Catch(&exc); t.F_in.Close__V(); return nil }(); t.F_closed = true; if tmp2 != nil { panic(tmp2) } } }()
}


type InputStreamReader struct{ Reader; F_in InputStream_I; F_cs Charset_I; F_kind int32; F_bb *ByteArray; F_bpos, F_blim int32; F_eof bool; F_pending uint16; F_closed bool }

type InputStreamReader_I interface{ Reader_I; Closeable; AutoCloseable; Self_InputStreamReader() *InputStreamReader; GetEncoding__String() *String; Read__I() int32; Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32; Ready__Z() bool; Close__V() }

func (t *InputStreamReader) Self_InputStreamReader() *InputStreamReader { return t }

const InputStreamReader_UTF8 int32 = 0

const InputStreamReader_LATIN1 int32 = 1

const InputStreamReader_ASCII int32 = 2

const InputStreamReader_REPLACEMENT uint16 = 65533

func (t *InputStreamReader) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *InputStreamReader) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *InputStreamReader) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *InputStreamReader) Close__V() { t.Impl_Close__V(t) }

func (t *InputStreamReader) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *InputStreamReader) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *InputStreamReader) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *InputStreamReader) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *InputStreamReader) Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32 { return t.Impl_Read_C1_I_I__I(t, p0, p1, p2) }

func (t *InputStreamReader) Reset__V() { t.Impl_Reset__V(t) }

func (t *InputStreamReader) GetEncoding__String() *String { return t.Impl_GetEncoding__String(t) }

func (t *InputStreamReader) Ready__Z() bool { return t.Impl_Ready__Z(t) }

func (t *InputStreamReader) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *InputStreamReader) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *InputStreamReader) Ref() any { if t == nil { return nil }; return t }

func (t *InputStreamReader) GetClass__Class() *Class { return InputStreamReader_class }

func (t *InputStreamReader) ToString__String() *String { return Object_toString(t) }

func (t *InputStreamReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InputStreamReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func InputStreamReader_InstanceOf(x any) bool { _, ok := x.(InputStreamReader_I); return ok }

func InputStreamReader_Cast(x any) InputStreamReader_I { if x == nil { return nil }; v, ok := x.(InputStreamReader_I); if !ok { panic(ClassCast(x, InputStreamReader_class)) }; return v }
