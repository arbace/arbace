//line java_lang_IllegalArgumentException.ae:1
package jrt






func IllegalArgumentException_New() *IllegalArgumentException { t := &IllegalArgumentException{}; t.Ctor(t); return t }
//line :8:1
func (t *IllegalArgumentException) Ctor(this IllegalArgumentException_I) { t.RuntimeException.Ctor(this) }

func IllegalArgumentException_New_String(p0 *String) *IllegalArgumentException { t := &IllegalArgumentException{}; t.Ctor_String(t, p0); return t }
//line :10:1
func (t *IllegalArgumentException) Ctor_String(this IllegalArgumentException_I, s *String) { t.RuntimeException.Ctor_String(this, s) }

func IllegalArgumentException_New_String_Throwable(p0 *String, p1 Throwable_I) *IllegalArgumentException { t := &IllegalArgumentException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :12:1
func (t *IllegalArgumentException) Ctor_String_Throwable(this IllegalArgumentException_I, message *String, cause Throwable_I) { t.RuntimeException.Ctor_String_Throwable(this, message, cause) }


func IllegalArgumentException_New_Throwable(p0 Throwable_I) *IllegalArgumentException { t := &IllegalArgumentException{}; t.Ctor_Throwable(t, p0); return t }
//line :15:1
func (t *IllegalArgumentException) Ctor_Throwable(this IllegalArgumentException_I, cause Throwable_I) { t.RuntimeException.Ctor_Throwable(this, cause) }










type IllegalArgumentException struct{ RuntimeException }

type IllegalArgumentException_I interface{ RuntimeException_I; Serializable; Self_IllegalArgumentException() *IllegalArgumentException }

func (t *IllegalArgumentException) Self_IllegalArgumentException() *IllegalArgumentException { return t }

const IllegalArgumentException_serialVersionUID int64 = -5365630128856068164

func (t *IllegalArgumentException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalArgumentException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalArgumentException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalArgumentException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalArgumentException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalArgumentException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalArgumentException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalArgumentException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalArgumentException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalArgumentException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalArgumentException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalArgumentException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalArgumentException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalArgumentException) GetClass__Class() *Class { return IllegalArgumentException_class }

func (t *IllegalArgumentException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalArgumentException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalArgumentException_InstanceOf(x any) bool { _, ok := x.(IllegalArgumentException_I); return ok }

func IllegalArgumentException_Cast(x any) IllegalArgumentException_I { if x == nil { return nil }; v, ok := x.(IllegalArgumentException_I); if !ok { panic(ClassCast(x, IllegalArgumentException_class)) }; return v }
