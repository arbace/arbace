//line java_util_MissingFormatWidthException.ae:1
package jrt










func MissingFormatWidthException_New_String(p0 *String) *MissingFormatWidthException { t := &MissingFormatWidthException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *MissingFormatWidthException) Ctor_String(s *String) { t.IllegalFormatException.Ctor(t)
	if s == nil { panic(Thrown(NullPointerException_New())) }
	t.F_s = s
}
func (t *MissingFormatWidthException) GetFormatSpecifier__String() *String { return t.F_s }

func (t *MissingFormatWidthException) GetMessage__String() *String { return t.F_s }



type MissingFormatWidthException struct{ IllegalFormatException; F_s *String }

const MissingFormatWidthException_serialVersionUID int64 = 15560123

func (t *MissingFormatWidthException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *MissingFormatWidthException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *MissingFormatWidthException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *MissingFormatWidthException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *MissingFormatWidthException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *MissingFormatWidthException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *MissingFormatWidthException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *MissingFormatWidthException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *MissingFormatWidthException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *MissingFormatWidthException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *MissingFormatWidthException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MissingFormatWidthException) Ref() any { if t == nil { return nil }; return t }

func (t *MissingFormatWidthException) GetClass__Class() *Class { return MissingFormatWidthException_class }

func (t *MissingFormatWidthException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MissingFormatWidthException) CloneShallow() any { panic(CloneNotSupported(t)) }

func MissingFormatWidthException_InstanceOf(x any) bool { _, ok := x.(*MissingFormatWidthException); return ok }

func MissingFormatWidthException_Cast(x any) *MissingFormatWidthException { if x == nil { return nil }; v, ok := x.(*MissingFormatWidthException); if !ok { panic(ClassCast(x, MissingFormatWidthException_class)) }; return v }
