//line java_util_Spliterators.ae:1
package jrt






func Spliterators_New() *Spliterators { t := &Spliterators{}; t.Ctor(); return t }
//line :8:1
func (t *Spliterators) Ctor() { panic(A2g_NotTranslated("java.util.Spliterators.<init>()V")) }

func Spliterators_EmptySpliterator__Spliterator() Spliterator { Spliterators_EmptySpliterator_OfRef_Init(); return Spliterators_EmptySpliterator_OfRef_EMPTY_SPLITERATOR }


func Spliterators_EmptyIntSpliterator__Spliterator_OfInt() Spliterator_OfInt { Spliterators_EmptySpliterator_OfInt_Init(); return Spliterators_EmptySpliterator_OfInt_EMPTY_INT_SPLITERATOR }


func Spliterators_EmptyLongSpliterator__Spliterator_OfLong() Spliterator_OfLong { Spliterators_EmptySpliterator_OfLong_Init(); return Spliterators_EmptySpliterator_OfLong_EMPTY_LONG_SPLITERATOR }


func Spliterators_EmptyDoubleSpliterator__Spliterator_OfDouble() Spliterator_OfDouble { Spliterators_EmptySpliterator_OfDouble_Init(); return Spliterators_EmptySpliterator_OfDouble_EMPTY_DOUBLE_SPLITERATOR }


func Spliterators_Spliterator_O1_I__Spliterator(array *RefArray, additionalCharacteristics int32) Spliterator {

	return Spliterators_ArraySpliterator_New_O1_I(A2g_CastArray[*RefArray](Objects_RequireNonNull_O__O(array.Ref()), Object_class.ArrayClass()), additionalCharacteristics)
}
func Spliterators_Spliterator_O1_I_I_I__Spliterator(array *RefArray, fromIndex, toIndex, additionalCharacteristics int32) Spliterator {



	Spliterators_CheckFromToBounds_I_I_I__V(int32(len(A2g_CastArray[*RefArray](Objects_RequireNonNull_O__O(array.Ref()), Object_class.ArrayClass()).A)), fromIndex, toIndex)


	return Spliterators_ArraySpliterator_New_O1_I_I_I(array, fromIndex, toIndex, additionalCharacteristics)
}
func Spliterators_Spliterator_I1_I__Spliterator_OfInt(array *IntArray, additionalCharacteristics int32) Spliterator_OfInt {

	return Spliterators_IntArraySpliterator_New_I1_I(A2g_CastArray[*IntArray](Objects_RequireNonNull_O__O(array.Ref()), Prim_int.ArrayClass()), additionalCharacteristics)
}
func Spliterators_Spliterator_I1_I_I_I__Spliterator_OfInt(array *IntArray, fromIndex, toIndex, additionalCharacteristics int32) Spliterator_OfInt {

	Spliterators_CheckFromToBounds_I_I_I__V(int32(len(A2g_CastArray[*IntArray](Objects_RequireNonNull_O__O(array.Ref()), Prim_int.ArrayClass()).A)), fromIndex, toIndex)


	return Spliterators_IntArraySpliterator_New_I1_I_I_I(array, fromIndex, toIndex, additionalCharacteristics)
}
func Spliterators_Spliterator_J1_I__Spliterator_OfLong(array *LongArray, additionalCharacteristics int32) Spliterator_OfLong {

	return Spliterators_LongArraySpliterator_New_J1_I(A2g_CastArray[*LongArray](Objects_RequireNonNull_O__O(array.Ref()), Prim_long.ArrayClass()), additionalCharacteristics)
}
func Spliterators_Spliterator_J1_I_I_I__Spliterator_OfLong(array *LongArray, fromIndex, toIndex, additionalCharacteristics int32) Spliterator_OfLong {


	Spliterators_CheckFromToBounds_I_I_I__V(int32(len(A2g_CastArray[*LongArray](Objects_RequireNonNull_O__O(array.Ref()), Prim_long.ArrayClass()).A)), fromIndex, toIndex)


	return Spliterators_LongArraySpliterator_New_J1_I_I_I(array, fromIndex, toIndex, additionalCharacteristics)
}
func Spliterators_Spliterator_D1_I__Spliterator_OfDouble(array *DoubleArray, additionalCharacteristics int32) Spliterator_OfDouble {

	return Spliterators_DoubleArraySpliterator_New_D1_I(A2g_CastArray[*DoubleArray](Objects_RequireNonNull_O__O(array.Ref()), Prim_double.ArrayClass()), additionalCharacteristics)
}

func Spliterators_Spliterator_D1_I_I_I__Spliterator_OfDouble(array *DoubleArray, fromIndex, toIndex, additionalCharacteristics int32) Spliterator_OfDouble {


	Spliterators_CheckFromToBounds_I_I_I__V(int32(len(A2g_CastArray[*DoubleArray](Objects_RequireNonNull_O__O(array.Ref()), Prim_double.ArrayClass()).A)), fromIndex, toIndex)


	return Spliterators_DoubleArraySpliterator_New_D1_I_I_I(array, fromIndex, toIndex, additionalCharacteristics)
}
func Spliterators_CheckFromToBounds_I_I_I__V(arrayLength, origin, fence int32) {
	if origin > fence {
		panic(Thrown(ArrayIndexOutOfBoundsException_New_String(Concat(Lit_2870, StrOfInt(origin), Lit_2871, StrOfInt(fence), Lit_1176)))) }
	if origin < 0 { panic(Thrown(ArrayIndexOutOfBoundsException_New_I(origin))) }
	if fence > arrayLength { panic(Thrown(ArrayIndexOutOfBoundsException_New_I(fence)))
	} }
func Spliterators_Spliterator_Collection_I__Spliterator(c Collection, characteristics int32) Spliterator {

	return Spliterators_IteratorSpliterator_New_Collection_I(Collection_Cast(Objects_RequireNonNull_O__O(c)), characteristics)
}
func Spliterators_Spliterator_Iterator_J_I__Spliterator(iterator Iterator, size int64, characteristics int32) Spliterator {


	return Spliterators_IteratorSpliterator_New_Iterator_J_I(Iterator_Cast(Objects_RequireNonNull_O__O(iterator)), size, characteristics)
}
func Spliterators_SpliteratorUnknownSize_Iterator_I__Spliterator(iterator Iterator, characteristics int32) Spliterator {

	return Spliterators_IteratorSpliterator_New_Iterator_I(Iterator_Cast(Objects_RequireNonNull_O__O(iterator)), characteristics)
}
func Spliterators_Spliterator_PrimitiveIterator_OfInt_J_I__Spliterator_OfInt(iterator PrimitiveIterator_OfInt, size int64, characteristics int32) Spliterator_OfInt {

	return Spliterators_IntIteratorSpliterator_New_PrimitiveIterator_OfInt_J_I(PrimitiveIterator_OfInt_Cast(Objects_RequireNonNull_O__O(iterator)), size, characteristics)
}


func Spliterators_SpliteratorUnknownSize_PrimitiveIterator_OfInt_I__Spliterator_OfInt(iterator PrimitiveIterator_OfInt, characteristics int32) Spliterator_OfInt {

	return Spliterators_IntIteratorSpliterator_New_PrimitiveIterator_OfInt_I(PrimitiveIterator_OfInt_Cast(Objects_RequireNonNull_O__O(iterator)), characteristics)
}

func Spliterators_Spliterator_PrimitiveIterator_OfLong_J_I__Spliterator_OfLong(iterator PrimitiveIterator_OfLong, size int64, characteristics int32) Spliterator_OfLong {

	return Spliterators_LongIteratorSpliterator_New_PrimitiveIterator_OfLong_J_I(PrimitiveIterator_OfLong_Cast(Objects_RequireNonNull_O__O(iterator)), size, characteristics)
}


func Spliterators_SpliteratorUnknownSize_PrimitiveIterator_OfLong_I__Spliterator_OfLong(iterator PrimitiveIterator_OfLong, characteristics int32) Spliterator_OfLong {

	return Spliterators_LongIteratorSpliterator_New_PrimitiveIterator_OfLong_I(PrimitiveIterator_OfLong_Cast(Objects_RequireNonNull_O__O(iterator)), characteristics)
}

func Spliterators_Spliterator_PrimitiveIterator_OfDouble_J_I__Spliterator_OfDouble(iterator PrimitiveIterator_OfDouble, size int64, characteristics int32) Spliterator_OfDouble {

	return Spliterators_DoubleIteratorSpliterator_New_PrimitiveIterator_OfDouble_J_I(PrimitiveIterator_OfDouble_Cast(Objects_RequireNonNull_O__O(iterator)), size, characteristics)
}


func Spliterators_SpliteratorUnknownSize_PrimitiveIterator_OfDouble_I__Spliterator_OfDouble(iterator PrimitiveIterator_OfDouble, characteristics int32) Spliterator_OfDouble {

	return Spliterators_DoubleIteratorSpliterator_New_PrimitiveIterator_OfDouble_I(PrimitiveIterator_OfDouble_Cast(Objects_RequireNonNull_O__O(iterator)), characteristics)
}

func Spliterators_Iterator_Spliterator__Iterator(spliterator Spliterator) Iterator {
	Objects_RequireNonNull_O__O(spliterator)




























	return Spliterators_1Adapter_New_Spliterator(spliterator) }
//line :132:1
func (t *Spliterators_1Adapter) Accept_O__V(t_ any) {
	t.F_valueReady = true
	t.F_nextElement = t_
}
func (t *Spliterators_1Adapter) HasNext__Z() bool {
	if t.F_valueReady { } else { t.F_val_spliterator.TryAdvance_Consumer__Z(t) }
//line :136:1
	return t.F_valueReady
}


func (t *Spliterators_1Adapter) Next__O() any {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_valueReady; if tmp2 { tmp2 = !t.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NoSuchElementException_New())) } else {

			t.F_valueReady = false
			var t_ any = t.F_nextElement; t.F_nextElement = nil; return t_
		} }
func (t *Spliterators_1Adapter) ForEachRemaining_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	if t.F_valueReady {
		t.F_valueReady = false
		var t_ any = t.F_nextElement; t.F_nextElement = nil; action.Accept_O__V(t_) }
	t.F_val_spliterator.ForEachRemaining_Consumer__V(action)
}

func Spliterators_Iterator_Spliterator_OfInt__PrimitiveIterator_OfInt(spliterator Spliterator_OfInt) PrimitiveIterator_OfInt {
	Objects_RequireNonNull_O__O(spliterator)
























	return Spliterators_2Adapter_New_Spliterator_OfInt(spliterator) }
//line :164:1
func (t *Spliterators_2Adapter) Accept_I__V(t_ int32) {
	t.F_valueReady = true
	t.F_nextElement = t_
}
func (t *Spliterators_2Adapter) HasNext__Z() bool {
	if t.F_valueReady { } else { t.F_val_spliterator.TryAdvance_IntConsumer__Z(t) }
//line :168:1
	return t.F_valueReady
}


func (t *Spliterators_2Adapter) NextInt__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_valueReady; if tmp2 { tmp2 = !t.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NoSuchElementException_New())) } else {
			t.F_valueReady = false; return t.F_nextElement
		} }
func (t *Spliterators_2Adapter) ForEachRemaining_IntConsumer__V(action IntConsumer) {
	Objects_RequireNonNull_O__O(action)
	if t.F_valueReady { t.F_valueReady = false; action.Accept_I__V(t.F_nextElement) }
	t.F_val_spliterator.ForEachRemaining_IntConsumer__V(action)
}

func Spliterators_Iterator_Spliterator_OfLong__PrimitiveIterator_OfLong(spliterator Spliterator_OfLong) PrimitiveIterator_OfLong {
	Objects_RequireNonNull_O__O(spliterator)
























	return Spliterators_3Adapter_New_Spliterator_OfLong(spliterator) }
//line :192:1
func (t *Spliterators_3Adapter) Accept_J__V(t_ int64) {
	t.F_valueReady = true
	t.F_nextElement = t_
}
func (t *Spliterators_3Adapter) HasNext__Z() bool {
	if t.F_valueReady { } else { t.F_val_spliterator.TryAdvance_LongConsumer__Z(t) }
//line :196:1
	return t.F_valueReady
}


func (t *Spliterators_3Adapter) NextLong__J() int64 {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_valueReady; if tmp2 { tmp2 = !t.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NoSuchElementException_New())) } else {
			t.F_valueReady = false; return t.F_nextElement
		} }
func (t *Spliterators_3Adapter) ForEachRemaining_LongConsumer__V(action LongConsumer) {
	Objects_RequireNonNull_O__O(action)
	if t.F_valueReady { t.F_valueReady = false; action.Accept_J__V(t.F_nextElement) }
	t.F_val_spliterator.ForEachRemaining_LongConsumer__V(action)
}

func Spliterators_Iterator_Spliterator_OfDouble__PrimitiveIterator_OfDouble(spliterator Spliterator_OfDouble) PrimitiveIterator_OfDouble {
	Objects_RequireNonNull_O__O(spliterator)
























	return Spliterators_4Adapter_New_Spliterator_OfDouble(spliterator) }
//line :220:1
func (t *Spliterators_4Adapter) Accept_D__V(t_ float64) {
	t.F_valueReady = true
	t.F_nextElement = t_
}
func (t *Spliterators_4Adapter) HasNext__Z() bool {
	if t.F_valueReady { } else { t.F_val_spliterator.TryAdvance_DoubleConsumer__Z(t) }
//line :224:1
	return t.F_valueReady
}


func (t *Spliterators_4Adapter) NextDouble__D() float64 {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_valueReady; if tmp2 { tmp2 = !t.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NoSuchElementException_New())) } else {
			t.F_valueReady = false; return t.F_nextElement
		} }
func (t *Spliterators_4Adapter) ForEachRemaining_DoubleConsumer__V(action DoubleConsumer) {
	Objects_RequireNonNull_O__O(action)
	if t.F_valueReady { t.F_valueReady = false; action.Accept_D__V(t.F_nextElement) }
	t.F_val_spliterator.ForEachRemaining_DoubleConsumer__V(action)
}




func (t *Spliterators_EmptySpliterator) Ctor(this Spliterators_EmptySpliterator_I) {}

func (t *Spliterators_EmptySpliterator) Impl_TrySplit__Spliterator(this Spliterators_EmptySpliterator_I) Spliterator { return nil }

func (t *Spliterators_EmptySpliterator) Impl_TryAdvance_O__Z(this Spliterators_EmptySpliterator_I, consumer any) bool {
	Objects_RequireNonNull_O__O(consumer)
//line :246:1
	return false
}


func (t *Spliterators_EmptySpliterator) Impl_ForEachRemaining_O__V(this Spliterators_EmptySpliterator_I, consumer any) {
	Objects_RequireNonNull_O__O(consumer)
}
func (t *Spliterators_EmptySpliterator) Impl_EstimateSize__J(this Spliterators_EmptySpliterator_I) int64 { return 0 }

func (t *Spliterators_EmptySpliterator) Impl_Characteristics__I(this Spliterators_EmptySpliterator_I) int32 {
	return 16448
}







func Spliterators_EmptySpliterator_OfRef_New() *Spliterators_EmptySpliterator_OfRef { Spliterators_EmptySpliterator_OfRef_Init(); t := &Spliterators_EmptySpliterator_OfRef{}; t.Ctor(); return t }
//line :265:1
func (t *Spliterators_EmptySpliterator_OfRef) Ctor() { t.Spliterators_EmptySpliterator.Ctor(t) }







func Spliterators_EmptySpliterator_OfInt_New() *Spliterators_EmptySpliterator_OfInt { Spliterators_EmptySpliterator_OfInt_Init(); t := &Spliterators_EmptySpliterator_OfInt{}; t.Ctor(); return t }
//line :273:1
func (t *Spliterators_EmptySpliterator_OfInt) Ctor() { t.Spliterators_EmptySpliterator.Ctor(t) }







func Spliterators_EmptySpliterator_OfLong_New() *Spliterators_EmptySpliterator_OfLong { Spliterators_EmptySpliterator_OfLong_Init(); t := &Spliterators_EmptySpliterator_OfLong{}; t.Ctor(); return t }
//line :281:1
func (t *Spliterators_EmptySpliterator_OfLong) Ctor() { t.Spliterators_EmptySpliterator.Ctor(t) }







func Spliterators_EmptySpliterator_OfDouble_New() *Spliterators_EmptySpliterator_OfDouble { Spliterators_EmptySpliterator_OfDouble_Init(); t := &Spliterators_EmptySpliterator_OfDouble{}; t.Ctor(); return t }
//line :289:1
func (t *Spliterators_EmptySpliterator_OfDouble) Ctor() { t.Spliterators_EmptySpliterator.Ctor(t) }















func Spliterators_ArraySpliterator_New_O1_I(p0 *RefArray, p1 int32) *Spliterators_ArraySpliterator { t := &Spliterators_ArraySpliterator{}; t.Ctor_O1_I(p0, p1); return t }
//line :305:1
func (t *Spliterators_ArraySpliterator) Ctor_O1_I(array *RefArray, additionalCharacteristics int32) { t.Ctor_O1_I_I_I(array, 0, int32(len(array.A)), additionalCharacteristics) }


func Spliterators_ArraySpliterator_New_O1_I_I_I(p0 *RefArray, p1, p2, p3 int32) *Spliterators_ArraySpliterator { t := &Spliterators_ArraySpliterator{}; t.Ctor_O1_I_I_I(p0, p1, p2, p3); return t }
//line :308:1
func (t *Spliterators_ArraySpliterator) Ctor_O1_I_I_I(array *RefArray, origin, fence, additionalCharacteristics int32) {

	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = additionalCharacteristics | 64 | 16384


	t.F_estimatedSize = -1
}
func Spliterators_ArraySpliterator_New_O1_I_I_I_J(p0 *RefArray, p1, p2, p3 int32, p4 int64) *Spliterators_ArraySpliterator { t := &Spliterators_ArraySpliterator{}; t.Ctor_O1_I_I_I_J(p0, p1, p2, p3, p4); return t }
//line :318:1
func (t *Spliterators_ArraySpliterator) Ctor_O1_I_I_I_J(array *RefArray, origin, fence, characteristics int32, estimatedSize int64) {

	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = characteristics & -16449


	t.F_estimatedSize = estimatedSize
}
func (t *Spliterators_ArraySpliterator) TrySplit__Spliterator() Spliterator {
	var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+t.F_fence) >> 1)

	if lo >= mid { return nil } else {
		if t.F_estimatedSize == -1 {
			var tmp1 *RefArray = t.F_array; var tmp2 int32; var tmp3 int32 = mid; t.F_index = tmp3; tmp2 = tmp3; return Spliterators_ArraySpliterator_New_O1_I_I_I(tmp1, lo, tmp2, t.F_characteristics) } else {
				var prefixEstimatedSize int64 = int64(uint64(t.F_estimatedSize) >> 1)
				t.F_estimatedSize = t.F_estimatedSize - prefixEstimatedSize
				var tmp4 *RefArray = t.F_array; var tmp5 int32; var tmp6 int32 = mid; t.F_index = tmp6; tmp5 = tmp6; return Spliterators_ArraySpliterator_New_O1_I_I_I_J(tmp4, lo, tmp5, t.F_characteristics, prefixEstimatedSize)
			} } }
func (t *Spliterators_ArraySpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	var a *RefArray
	var i int32 = 0
	var hi int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *RefArray; a = t.F_array; tmp4 = a; var tmp5 int32 = int32(len(tmp4.A)); var tmp6 int32; hi = t.F_fence; tmp6 = hi; tmp3 = tmp5 >= tmp6; if tmp3 { var tmp7 int32; i = t.F_index; tmp7 = i; tmp3 = tmp7 >= 0 }; tmp2 = tmp3; if tmp2 {
		var tmp8 int32 = i; var tmp9 int32; var tmp10 int32 = hi; t.F_index = tmp10; tmp9 = tmp10; tmp2 = tmp8 < tmp9 }
//line :343:1
	tmp1 = tmp2; if tmp1 {

	L1: for { action.Accept_O__V(a.A[i]); var tmp11 int32; i = i + 1; tmp11 = i; if tmp11 < hi { continue L1 }; break L1
	} } }
func (t *Spliterators_ArraySpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_index >= 0; if tmp2 { tmp2 = t.F_index < t.F_fence }; tmp1 = tmp2; if tmp1 {
		var e any; var tmp3 *RefArray = t.F_array; var tmp4 int32; var old_1 int32 = t.F_index; t.F_index = t.F_index + 1; tmp4 = old_1; e = tmp3.A[tmp4]
		action.Accept_O__V(e)
//line :350:1
		return true } else {
//line :349:1
			return false
		}
}



func (t *Spliterators_ArraySpliterator) EstimateSize__J() int64 {
	if t.F_estimatedSize >= 0 { return t.F_estimatedSize } else { return int64(t.F_fence - t.F_index)
	} }
func (t *Spliterators_ArraySpliterator) Characteristics__I() int32 { return t.F_characteristics }

func (t *Spliterators_ArraySpliterator) GetComparator__Comparator() Comparator {
	if t.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}












func Spliterators_IntArraySpliterator_New_I1_I(p0 *IntArray, p1 int32) *Spliterators_IntArraySpliterator { t := &Spliterators_IntArraySpliterator{}; t.Ctor_I1_I(p0, p1); return t }
//line :376:1
func (t *Spliterators_IntArraySpliterator) Ctor_I1_I(array *IntArray, additionalCharacteristics int32) { t.Ctor_I1_I_I_I(array, 0, int32(len(array.A)), additionalCharacteristics) }


func Spliterators_IntArraySpliterator_New_I1_I_I_I(p0 *IntArray, p1, p2, p3 int32) *Spliterators_IntArraySpliterator { t := &Spliterators_IntArraySpliterator{}; t.Ctor_I1_I_I_I(p0, p1, p2, p3); return t }
//line :379:1
func (t *Spliterators_IntArraySpliterator) Ctor_I1_I_I_I(array *IntArray, origin, fence, additionalCharacteristics int32) {
	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = additionalCharacteristics | 64 | 16384


	t.F_estimatedSize = -1
}
func Spliterators_IntArraySpliterator_New_I1_I_I_I_J(p0 *IntArray, p1, p2, p3 int32, p4 int64) *Spliterators_IntArraySpliterator { t := &Spliterators_IntArraySpliterator{}; t.Ctor_I1_I_I_I_J(p0, p1, p2, p3, p4); return t }
//line :388:1
func (t *Spliterators_IntArraySpliterator) Ctor_I1_I_I_I_J(array *IntArray, origin, fence, characteristics int32, estimatedSize int64) {

	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = characteristics & -16449


	t.F_estimatedSize = estimatedSize
}
func (t *Spliterators_IntArraySpliterator) TrySplit__Spliterator_OfInt() Spliterator_OfInt {
	var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+t.F_fence) >> 1)

	if lo >= mid { return nil } else {
		if t.F_estimatedSize == -1 {
			var tmp1 *IntArray = t.F_array; var tmp2 int32; var tmp3 int32 = mid; t.F_index = tmp3; tmp2 = tmp3; return Spliterators_IntArraySpliterator_New_I1_I_I_I(tmp1, lo, tmp2, t.F_characteristics) } else {
				var prefixEstimatedSize int64 = int64(uint64(t.F_estimatedSize) >> 1)
				t.F_estimatedSize = t.F_estimatedSize - prefixEstimatedSize
				var tmp4 *IntArray = t.F_array; var tmp5 int32; var tmp6 int32 = mid; t.F_index = tmp6; tmp5 = tmp6; return Spliterators_IntArraySpliterator_New_I1_I_I_I_J(tmp4, lo, tmp5, t.F_characteristics, prefixEstimatedSize)
			} } }
func (t *Spliterators_IntArraySpliterator) ForEachRemaining_IntConsumer__V(action IntConsumer) {
	var a *IntArray
	var i int32 = 0
	var hi int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *IntArray; a = t.F_array; tmp4 = a; var tmp5 int32 = int32(len(tmp4.A)); var tmp6 int32; hi = t.F_fence; tmp6 = hi; tmp3 = tmp5 >= tmp6; if tmp3 { var tmp7 int32; i = t.F_index; tmp7 = i; tmp3 = tmp7 >= 0 }; tmp2 = tmp3; if tmp2 {
		var tmp8 int32 = i; var tmp9 int32; var tmp10 int32 = hi; t.F_index = tmp10; tmp9 = tmp10; tmp2 = tmp8 < tmp9 }
//line :413:1
	tmp1 = tmp2; if tmp1 {

	L1: for { action.Accept_I__V(a.A[i]); var tmp11 int32; i = i + 1; tmp11 = i; if tmp11 < hi { continue L1 }; break L1
	} } }
func (t *Spliterators_IntArraySpliterator) TryAdvance_IntConsumer__Z(action IntConsumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_index >= 0; if tmp2 { tmp2 = t.F_index < t.F_fence }; tmp1 = tmp2; if tmp1 {

		var tmp3 *IntArray = t.F_array; var tmp4 int32; var old_2 int32 = t.F_index
		t.F_index = t.F_index + 1; tmp4 = old_2
//line :421:1
		action.Accept_I__V(tmp3.A[tmp4])
//line :420:1
		return true
	} else {
//line :419:1
		return false
	}
}




func (t *Spliterators_IntArraySpliterator) EstimateSize__J() int64 {
	if t.F_estimatedSize >= 0 { return t.F_estimatedSize } else { return int64(t.F_fence - t.F_index)
	} }
func (t *Spliterators_IntArraySpliterator) Characteristics__I() int32 { return t.F_characteristics }

func (t *Spliterators_IntArraySpliterator) GetComparator__Comparator() Comparator {
	if t.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}












func Spliterators_LongArraySpliterator_New_J1_I(p0 *LongArray, p1 int32) *Spliterators_LongArraySpliterator { t := &Spliterators_LongArraySpliterator{}; t.Ctor_J1_I(p0, p1); return t }
//line :447:1
func (t *Spliterators_LongArraySpliterator) Ctor_J1_I(array *LongArray, additionalCharacteristics int32) { t.Ctor_J1_I_I_I(array, 0, int32(len(array.A)), additionalCharacteristics) }


func Spliterators_LongArraySpliterator_New_J1_I_I_I(p0 *LongArray, p1, p2, p3 int32) *Spliterators_LongArraySpliterator { t := &Spliterators_LongArraySpliterator{}; t.Ctor_J1_I_I_I(p0, p1, p2, p3); return t }
//line :450:1
func (t *Spliterators_LongArraySpliterator) Ctor_J1_I_I_I(array *LongArray, origin, fence, additionalCharacteristics int32) {
	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = additionalCharacteristics | 64 | 16384


	t.F_estimatedSize = -1
}
func Spliterators_LongArraySpliterator_New_J1_I_I_I_J(p0 *LongArray, p1, p2, p3 int32, p4 int64) *Spliterators_LongArraySpliterator { t := &Spliterators_LongArraySpliterator{}; t.Ctor_J1_I_I_I_J(p0, p1, p2, p3, p4); return t }
//line :459:1
func (t *Spliterators_LongArraySpliterator) Ctor_J1_I_I_I_J(array *LongArray, origin, fence, characteristics int32, estimatedSize int64) {

	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = characteristics & -16449


	t.F_estimatedSize = estimatedSize
}
func (t *Spliterators_LongArraySpliterator) TrySplit__Spliterator_OfLong() Spliterator_OfLong {
	var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+t.F_fence) >> 1)

	if lo >= mid { return nil } else {
		if t.F_estimatedSize == -1 {
			var tmp1 *LongArray = t.F_array; var tmp2 int32; var tmp3 int32 = mid; t.F_index = tmp3; tmp2 = tmp3; return Spliterators_LongArraySpliterator_New_J1_I_I_I(tmp1, lo, tmp2, t.F_characteristics) } else {
				var prefixEstimatedSize int64 = int64(uint64(t.F_estimatedSize) >> 1)
				t.F_estimatedSize = t.F_estimatedSize - prefixEstimatedSize
				var tmp4 *LongArray = t.F_array; var tmp5 int32
				var tmp6 int32 = mid
				t.F_index = tmp6; tmp5 = tmp6
//line :477:1
				return Spliterators_LongArraySpliterator_New_J1_I_I_I_J(tmp4, lo, tmp5, t.F_characteristics, prefixEstimatedSize)
			}
	}
}


func (t *Spliterators_LongArraySpliterator) ForEachRemaining_LongConsumer__V(action LongConsumer) {
	var a *LongArray
	var i int32 = 0
	var hi int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *LongArray; a = t.F_array; tmp4 = a; var tmp5 int32 = int32(len(tmp4.A)); var tmp6 int32; hi = t.F_fence; tmp6 = hi; tmp3 = tmp5 >= tmp6; if tmp3 { var tmp7 int32; i = t.F_index; tmp7 = i; tmp3 = tmp7 >= 0 }; tmp2 = tmp3; if tmp2 {
		var tmp8 int32 = i; var tmp9 int32; var tmp10 int32 = hi; t.F_index = tmp10; tmp9 = tmp10; tmp2 = tmp8 < tmp9 }
//line :488:1
	tmp1 = tmp2; if tmp1 {

	L1: for { action.Accept_J__V(a.A[i]); var tmp11 int32; i = i + 1; tmp11 = i; if tmp11 < hi { continue L1 }; break L1
	} } }
func (t *Spliterators_LongArraySpliterator) TryAdvance_LongConsumer__Z(action LongConsumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_index >= 0; if tmp2 { tmp2 = t.F_index < t.F_fence }; tmp1 = tmp2; if tmp1 {

		var tmp3 *LongArray = t.F_array; var tmp4 int32; var old_3 int32 = t.F_index
		t.F_index = t.F_index + 1; tmp4 = old_3
//line :496:1
		action.Accept_J__V(tmp3.A[tmp4])
//line :495:1
		return true
	} else {
//line :494:1
		return false
	}
}




func (t *Spliterators_LongArraySpliterator) EstimateSize__J() int64 {
	if t.F_estimatedSize >= 0 { return t.F_estimatedSize } else { return int64(t.F_fence - t.F_index)
	} }
func (t *Spliterators_LongArraySpliterator) Characteristics__I() int32 { return t.F_characteristics }

func (t *Spliterators_LongArraySpliterator) GetComparator__Comparator() Comparator {
	if t.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}












func Spliterators_DoubleArraySpliterator_New_D1_I(p0 *DoubleArray, p1 int32) *Spliterators_DoubleArraySpliterator { t := &Spliterators_DoubleArraySpliterator{}; t.Ctor_D1_I(p0, p1); return t }
//line :522:1
func (t *Spliterators_DoubleArraySpliterator) Ctor_D1_I(array *DoubleArray, additionalCharacteristics int32) { t.Ctor_D1_I_I_I(array, 0, int32(len(array.A)), additionalCharacteristics) }


func Spliterators_DoubleArraySpliterator_New_D1_I_I_I(p0 *DoubleArray, p1, p2, p3 int32) *Spliterators_DoubleArraySpliterator { t := &Spliterators_DoubleArraySpliterator{}; t.Ctor_D1_I_I_I(p0, p1, p2, p3); return t }
//line :525:1
func (t *Spliterators_DoubleArraySpliterator) Ctor_D1_I_I_I(array *DoubleArray, origin, fence, additionalCharacteristics int32) {

	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = additionalCharacteristics | 64 | 16384


	t.F_estimatedSize = -1
}
func Spliterators_DoubleArraySpliterator_New_D1_I_I_I_J(p0 *DoubleArray, p1, p2, p3 int32, p4 int64) *Spliterators_DoubleArraySpliterator { t := &Spliterators_DoubleArraySpliterator{}; t.Ctor_D1_I_I_I_J(p0, p1, p2, p3, p4); return t }
//line :535:1
func (t *Spliterators_DoubleArraySpliterator) Ctor_D1_I_I_I_J(array *DoubleArray, origin, fence, characteristics int32, estimatedSize int64) {

	t.F_array = array
	t.F_index = origin
	t.F_fence = fence
	t.F_characteristics = characteristics & -16449


	t.F_estimatedSize = estimatedSize
}
func (t *Spliterators_DoubleArraySpliterator) TrySplit__Spliterator_OfDouble() Spliterator_OfDouble {
	var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+t.F_fence) >> 1)

	if lo >= mid { return nil } else {
		if t.F_estimatedSize == -1 {
			var tmp1 *DoubleArray = t.F_array; var tmp2 int32; var tmp3 int32 = mid; t.F_index = tmp3; tmp2 = tmp3; return Spliterators_DoubleArraySpliterator_New_D1_I_I_I(tmp1, lo, tmp2, t.F_characteristics) } else {
				var prefixEstimatedSize int64 = int64(uint64(t.F_estimatedSize) >> 1)
				t.F_estimatedSize = t.F_estimatedSize - prefixEstimatedSize
				var tmp4 *DoubleArray = t.F_array; var tmp5 int32
				var tmp6 int32 = mid
				t.F_index = tmp6; tmp5 = tmp6
//line :553:1
				return Spliterators_DoubleArraySpliterator_New_D1_I_I_I_J(tmp4, lo, tmp5, t.F_characteristics, prefixEstimatedSize)
			}
	}
}


func (t *Spliterators_DoubleArraySpliterator) ForEachRemaining_DoubleConsumer__V(action DoubleConsumer) {
	var a *DoubleArray
	var i int32 = 0
	var hi int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *DoubleArray; a = t.F_array; tmp4 = a; var tmp5 int32 = int32(len(tmp4.A)); var tmp6 int32; hi = t.F_fence; tmp6 = hi; tmp3 = tmp5 >= tmp6; if tmp3 { var tmp7 int32; i = t.F_index; tmp7 = i; tmp3 = tmp7 >= 0 }; tmp2 = tmp3; if tmp2 {
		var tmp8 int32 = i; var tmp9 int32; var tmp10 int32 = hi; t.F_index = tmp10; tmp9 = tmp10; tmp2 = tmp8 < tmp9 }
//line :564:1
	tmp1 = tmp2; if tmp1 {

	L1: for { action.Accept_D__V(a.A[i]); var tmp11 int32; i = i + 1; tmp11 = i; if tmp11 < hi { continue L1 }; break L1
	} } }
func (t *Spliterators_DoubleArraySpliterator) TryAdvance_DoubleConsumer__Z(action DoubleConsumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_index >= 0; if tmp2 { tmp2 = t.F_index < t.F_fence }; tmp1 = tmp2; if tmp1 {

		var tmp3 *DoubleArray = t.F_array; var tmp4 int32; var old_4 int32 = t.F_index
		t.F_index = t.F_index + 1; tmp4 = old_4
//line :572:1
		action.Accept_D__V(tmp3.A[tmp4])
//line :571:1
		return true
	} else {
//line :570:1
		return false
	}
}




func (t *Spliterators_DoubleArraySpliterator) EstimateSize__J() int64 {
	if t.F_estimatedSize >= 0 { return t.F_estimatedSize } else { return int64(t.F_fence - t.F_index)
	} }
func (t *Spliterators_DoubleArraySpliterator) Characteristics__I() int32 { return t.F_characteristics }

func (t *Spliterators_DoubleArraySpliterator) GetComparator__Comparator() Comparator {
	if t.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}













func (t *Spliterators_AbstractSpliterator) Ctor_J_I(this Spliterators_AbstractSpliterator_I, est int64, additionalCharacteristics int32) {
	t.F_est = est
	var tmp1 int32
	if !(additionalCharacteristics&64 == 0) {
		tmp1 = additionalCharacteristics | 16384 } else {
//line :602:1
			tmp1 = additionalCharacteristics }
//line :601:1
	t.F_characteristics = tmp1
}









func (t *Spliterators_AbstractSpliterator_HoldingConsumer) Accept_O__V(value any) {
	t.F_value = value
}
func (t *Spliterators_AbstractSpliterator) Impl_TrySplit__Spliterator(this Spliterators_AbstractSpliterator_I) Spliterator {
	var holder *Spliterators_AbstractSpliterator_HoldingConsumer = Spliterators_AbstractSpliterator_HoldingConsumer_New(); var s int64 = t.F_est; var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { tmp2 = this.TryAdvance_Consumer__Z(Up_Spliterators_AbstractSpliterator_HoldingConsumer_Consumer(holder)) }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *RefArray = NewRefArray(Object_class, n)
		var j int32 = 0
	L1: for {
		a.Store(j, holder.F_value)
		var tmp3 bool; var tmp4 bool; var tmp5 int32; j = j + 1; tmp5 = j; tmp4 = tmp5 < n; if tmp4 { tmp4 = this.TryAdvance_Consumer__Z(Up_Spliterators_AbstractSpliterator_HoldingConsumer_Consumer(holder)) }; tmp3 = tmp4; if tmp3 { continue L1 }
//line :624:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_ArraySpliterator_New_O1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_ArraySpliterator_New_O1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :618:1
					return nil
				}
}













func (t *Spliterators_AbstractSpliterator) Impl_EstimateSize__J(this Spliterators_AbstractSpliterator_I) int64 { return t.F_est }

func (t *Spliterators_AbstractSpliterator) Impl_Characteristics__I(this Spliterators_AbstractSpliterator_I) int32 { return t.F_characteristics }














func (t *Spliterators_AbstractIntSpliterator) Ctor_J_I(this Spliterators_AbstractIntSpliterator_I, est int64, additionalCharacteristics int32) {
	t.F_est = est
	var tmp1 int32
	if !(additionalCharacteristics&64 == 0) {
		tmp1 = additionalCharacteristics | 16384 } else {
//line :654:1
			tmp1 = additionalCharacteristics }
//line :653:1
	t.F_characteristics = tmp1
}








func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) Accept_I__V(value int32) {
	t.F_value = value
}
func (t *Spliterators_AbstractIntSpliterator) Impl_TrySplit__Spliterator_OfInt(this Spliterators_AbstractIntSpliterator_I) Spliterator_OfInt {
	var holder *Spliterators_AbstractIntSpliterator_HoldingIntConsumer = Spliterators_AbstractIntSpliterator_HoldingIntConsumer_New(); var s int64 = t.F_est; var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { tmp2 = this.TryAdvance_IntConsumer__Z(Up_Spliterators_AbstractIntSpliterator_HoldingIntConsumer_IntConsumer(holder)) }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *IntArray = NewIntArray(n)
		var j int32 = 0
	L1: for {
		a.A[j] = holder.F_value
		var tmp3 bool; var tmp4 bool; var tmp5 int32; j = j + 1; tmp5 = j; tmp4 = tmp5 < n; if tmp4 { tmp4 = this.TryAdvance_IntConsumer__Z(Up_Spliterators_AbstractIntSpliterator_HoldingIntConsumer_IntConsumer(holder)) }; tmp3 = tmp4; if tmp3 { continue L1 }
//line :675:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_IntArraySpliterator_New_I1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_IntArraySpliterator_New_I1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :669:1
					return nil
				}
}













func (t *Spliterators_AbstractIntSpliterator) Impl_EstimateSize__J(this Spliterators_AbstractIntSpliterator_I) int64 { return t.F_est }

func (t *Spliterators_AbstractIntSpliterator) Impl_Characteristics__I(this Spliterators_AbstractIntSpliterator_I) int32 { return t.F_characteristics }














func (t *Spliterators_AbstractLongSpliterator) Ctor_J_I(this Spliterators_AbstractLongSpliterator_I, est int64, additionalCharacteristics int32) {
	t.F_est = est
	var tmp1 int32
	if !(additionalCharacteristics&64 == 0) {
		tmp1 = additionalCharacteristics | 16384 } else {
//line :705:1
			tmp1 = additionalCharacteristics }
//line :704:1
	t.F_characteristics = tmp1
}








func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) Accept_J__V(value int64) {
	t.F_value = value
}
func (t *Spliterators_AbstractLongSpliterator) Impl_TrySplit__Spliterator_OfLong(this Spliterators_AbstractLongSpliterator_I) Spliterator_OfLong {
	var holder *Spliterators_AbstractLongSpliterator_HoldingLongConsumer = Spliterators_AbstractLongSpliterator_HoldingLongConsumer_New(); var s int64 = t.F_est; var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { tmp2 = this.TryAdvance_LongConsumer__Z(Up_Spliterators_AbstractLongSpliterator_HoldingLongConsumer_LongConsumer(holder)) }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *LongArray = NewLongArray(n)
		var j int32 = 0
	L1: for {
		a.A[j] = holder.F_value
		var tmp3 bool; var tmp4 bool; var tmp5 int32; j = j + 1; tmp5 = j; tmp4 = tmp5 < n; if tmp4 { tmp4 = this.TryAdvance_LongConsumer__Z(Up_Spliterators_AbstractLongSpliterator_HoldingLongConsumer_LongConsumer(holder)) }; tmp3 = tmp4; if tmp3 { continue L1 }
//line :726:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_LongArraySpliterator_New_J1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_LongArraySpliterator_New_J1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :720:1
					return nil
				}
}













func (t *Spliterators_AbstractLongSpliterator) Impl_EstimateSize__J(this Spliterators_AbstractLongSpliterator_I) int64 { return t.F_est }

func (t *Spliterators_AbstractLongSpliterator) Impl_Characteristics__I(this Spliterators_AbstractLongSpliterator_I) int32 { return t.F_characteristics }














func (t *Spliterators_AbstractDoubleSpliterator) Ctor_J_I(this Spliterators_AbstractDoubleSpliterator_I, est int64, additionalCharacteristics int32) {
	t.F_est = est
	var tmp1 int32
	if !(additionalCharacteristics&64 == 0) {
		tmp1 = additionalCharacteristics | 16384 } else {
//line :756:1
			tmp1 = additionalCharacteristics }
//line :755:1
	t.F_characteristics = tmp1
}








func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) Accept_D__V(value float64) {
	t.F_value = value
}
func (t *Spliterators_AbstractDoubleSpliterator) Impl_TrySplit__Spliterator_OfDouble(this Spliterators_AbstractDoubleSpliterator_I) Spliterator_OfDouble {
	var holder *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer = Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_New(); var s int64 = t.F_est; var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { tmp2 = this.TryAdvance_DoubleConsumer__Z(Up_Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_DoubleConsumer(holder)) }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *DoubleArray = NewDoubleArray(n)
		var j int32 = 0
	L1: for {
		a.A[j] = holder.F_value
		var tmp3 bool; var tmp4 bool; var tmp5 int32; j = j + 1; tmp5 = j; tmp4 = tmp5 < n; if tmp4 { tmp4 = this.TryAdvance_DoubleConsumer__Z(Up_Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_DoubleConsumer(holder)) }; tmp3 = tmp4; if tmp3 { continue L1 }
//line :777:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_DoubleArraySpliterator_New_D1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_DoubleArraySpliterator_New_D1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :771:1
					return nil
				}
}

















func (t *Spliterators_AbstractDoubleSpliterator) Impl_EstimateSize__J(this Spliterators_AbstractDoubleSpliterator_I) int64 { return t.F_est }

func (t *Spliterators_AbstractDoubleSpliterator) Impl_Characteristics__I(this Spliterators_AbstractDoubleSpliterator_I) int32 { return t.F_characteristics }



















func Spliterators_IteratorSpliterator_New_Collection_I(p0 Collection, p1 int32) *Spliterators_IteratorSpliterator { t := &Spliterators_IteratorSpliterator{}; t.Ctor_Collection_I(t, p0, p1); return t }
//line :813:1
func (t *Spliterators_IteratorSpliterator) Ctor_Collection_I(this Spliterators_IteratorSpliterator_I, collection Collection, characteristics int32) {
	t.F_collection = collection
	t.F_it = nil
	var tmp1 int32
	if characteristics&4096 == 0 {
		tmp1 = characteristics | 64 | 16384 } else {
//line :817:1
			tmp1 = characteristics }
//line :816:1
	t.F_characteristics = tmp1
}



func Spliterators_IteratorSpliterator_New_Iterator_J_I(p0 Iterator, p1 int64, p2 int32) *Spliterators_IteratorSpliterator { t := &Spliterators_IteratorSpliterator{}; t.Ctor_Iterator_J_I(t, p0, p1, p2); return t }
//line :821:1
func (t *Spliterators_IteratorSpliterator) Ctor_Iterator_J_I(this Spliterators_IteratorSpliterator_I, iterator Iterator, size int64, characteristics int32) {

	t.F_collection = nil
	t.F_it = iterator
	t.F_est = size
	var tmp1 int32
	if characteristics&4096 == 0 {
		tmp1 = characteristics | 64 | 16384 } else {
//line :827:1
			tmp1 = characteristics }
//line :826:1
	t.F_characteristics = tmp1
}



func Spliterators_IteratorSpliterator_New_Iterator_I(p0 Iterator, p1 int32) *Spliterators_IteratorSpliterator { t := &Spliterators_IteratorSpliterator{}; t.Ctor_Iterator_I(t, p0, p1); return t }
//line :831:1
func (t *Spliterators_IteratorSpliterator) Ctor_Iterator_I(this Spliterators_IteratorSpliterator_I, iterator Iterator, characteristics int32) {
	t.F_collection = nil
	t.F_it = iterator
	t.F_est = 9223372036854775807
	t.F_characteristics = characteristics & -16449
}


func (t *Spliterators_IteratorSpliterator) Impl_TrySplit__Spliterator(this Spliterators_IteratorSpliterator_I) Spliterator {
	var i Iterator; var s int64 = 0; var tmp1 Iterator

	i = t.F_it; tmp1 = i; if tmp1 == nil {

		var tmp2 Iterator; var tmp3 Iterator = t.F_collection.Iterator__Iterator(); t.F_it = tmp3; tmp2 = tmp3; i = tmp2
		var tmp4 int64; var tmp5 int64 = int64(t.F_collection.Size__I()); t.F_est = tmp5; tmp4 = tmp5; s = tmp4 } else {
			s = t.F_est }
	var tmp6 bool; var tmp7 bool; tmp7 = s > 1; if tmp7 { tmp7 = i.HasNext__Z() }; tmp6 = tmp7; if tmp6 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *RefArray = NewRefArray(Object_class, n)
		var j int32 = 0
	L1: for {
		a.Store(j, i.Next__O())
		var tmp8 bool; var tmp9 bool; var tmp10 int32; j = j + 1; tmp10 = j; tmp9 = tmp10 < n; if tmp9 { tmp9 = i.HasNext__Z() }; tmp8 = tmp9; if tmp8 { continue L1 }
//line :853:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_ArraySpliterator_New_O1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_ArraySpliterator_New_O1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :847:1
					return nil
				}
}













func (t *Spliterators_IteratorSpliterator) Impl_ForEachRemaining_Consumer__V(this Spliterators_IteratorSpliterator_I, action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var i Iterator; var tmp1 Iterator
	i = t.F_it; tmp1 = i; if tmp1 == nil {
		var tmp2 Iterator; var tmp3 Iterator = t.F_collection.Iterator__Iterator(); t.F_it = tmp3; tmp2 = tmp3; i = tmp2
		t.F_est = int64(t.F_collection.Size__I()) }
	i.ForEachRemaining_Consumer__V(action)
}
func (t *Spliterators_IteratorSpliterator) Impl_TryAdvance_Consumer__Z(this Spliterators_IteratorSpliterator_I, action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	if t.F_it == nil { t.F_it = t.F_collection.Iterator__Iterator(); t.F_est = int64(t.F_collection.Size__I()) }
	if t.F_it.HasNext__Z() { action.Accept_O__V(t.F_it.Next__O()); return true } else { return false
	} }
func (t *Spliterators_IteratorSpliterator) Impl_EstimateSize__J(this Spliterators_IteratorSpliterator_I) int64 {
	if t.F_it == nil { t.F_it = t.F_collection.Iterator__Iterator(); var tmp1 int64 = int64(t.F_collection.Size__I()); t.F_est = tmp1; return tmp1 } else { return t.F_est
	} }
func (t *Spliterators_IteratorSpliterator) Impl_Characteristics__I(this Spliterators_IteratorSpliterator_I) int32 { return t.F_characteristics }

func (t *Spliterators_IteratorSpliterator) Impl_GetComparator__Comparator(this Spliterators_IteratorSpliterator_I) Comparator {
	if this.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}














func Spliterators_IntIteratorSpliterator_New_PrimitiveIterator_OfInt_J_I(p0 PrimitiveIterator_OfInt, p1 int64, p2 int32) *Spliterators_IntIteratorSpliterator { t := &Spliterators_IntIteratorSpliterator{}; t.Ctor_PrimitiveIterator_OfInt_J_I(p0, p1, p2); return t }
//line :899:1
func (t *Spliterators_IntIteratorSpliterator) Ctor_PrimitiveIterator_OfInt_J_I(iterator PrimitiveIterator_OfInt, size int64, characteristics int32) {
	t.F_it = iterator
	t.F_est = size
	var tmp1 int32
	if characteristics&4096 == 0 {
		tmp1 = characteristics | 64 | 16384 } else {
//line :903:1
			tmp1 = characteristics }
//line :902:1
	t.F_characteristics = tmp1
}



func Spliterators_IntIteratorSpliterator_New_PrimitiveIterator_OfInt_I(p0 PrimitiveIterator_OfInt, p1 int32) *Spliterators_IntIteratorSpliterator { t := &Spliterators_IntIteratorSpliterator{}; t.Ctor_PrimitiveIterator_OfInt_I(p0, p1); return t }
//line :907:1
func (t *Spliterators_IntIteratorSpliterator) Ctor_PrimitiveIterator_OfInt_I(iterator PrimitiveIterator_OfInt, characteristics int32) {
	t.F_it = iterator
	t.F_est = 9223372036854775807
	t.F_characteristics = characteristics & -16449
}


func (t *Spliterators_IntIteratorSpliterator) TrySplit__Spliterator_OfInt() Spliterator_OfInt {
	var i PrimitiveIterator_OfInt = t.F_it; var s int64 = t.F_est; var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { tmp2 = i.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *IntArray = NewIntArray(n)
		var j int32 = 0
	L1: for {
		a.A[j] = i.NextInt__I()
		var tmp3 bool; var tmp4 bool; var tmp5 int32; j = j + 1; tmp5 = j; tmp4 = tmp5 < n; if tmp4 { tmp4 = i.HasNext__Z() }; tmp3 = tmp4; if tmp3 { continue L1 }
//line :923:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_IntArraySpliterator_New_I1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_IntArraySpliterator_New_I1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :917:1
					return nil
				}
}













func (t *Spliterators_IntIteratorSpliterator) ForEachRemaining_IntConsumer__V(action IntConsumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	t.F_it.ForEachRemaining_IntConsumer__V(action)
}
func (t *Spliterators_IntIteratorSpliterator) TryAdvance_IntConsumer__Z(action IntConsumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	if t.F_it.HasNext__Z() { action.Accept_I__V(t.F_it.NextInt__I()); return true } else { return false
	} }
func (t *Spliterators_IntIteratorSpliterator) EstimateSize__J() int64 { return t.F_est }

func (t *Spliterators_IntIteratorSpliterator) Characteristics__I() int32 { return t.F_characteristics }

func (t *Spliterators_IntIteratorSpliterator) GetComparator__Comparator() Comparator {
	if t.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}














func Spliterators_LongIteratorSpliterator_New_PrimitiveIterator_OfLong_J_I(p0 PrimitiveIterator_OfLong, p1 int64, p2 int32) *Spliterators_LongIteratorSpliterator { t := &Spliterators_LongIteratorSpliterator{}; t.Ctor_PrimitiveIterator_OfLong_J_I(p0, p1, p2); return t }
//line :963:1
func (t *Spliterators_LongIteratorSpliterator) Ctor_PrimitiveIterator_OfLong_J_I(iterator PrimitiveIterator_OfLong, size int64, characteristics int32) {
	t.F_it = iterator
	t.F_est = size
	var tmp1 int32
	if characteristics&4096 == 0 {
		tmp1 = characteristics | 64 | 16384 } else {
//line :967:1
			tmp1 = characteristics }
//line :966:1
	t.F_characteristics = tmp1
}



func Spliterators_LongIteratorSpliterator_New_PrimitiveIterator_OfLong_I(p0 PrimitiveIterator_OfLong, p1 int32) *Spliterators_LongIteratorSpliterator { t := &Spliterators_LongIteratorSpliterator{}; t.Ctor_PrimitiveIterator_OfLong_I(p0, p1); return t }
//line :971:1
func (t *Spliterators_LongIteratorSpliterator) Ctor_PrimitiveIterator_OfLong_I(iterator PrimitiveIterator_OfLong, characteristics int32) {
	t.F_it = iterator
	t.F_est = 9223372036854775807
	t.F_characteristics = characteristics & -16449
}


func (t *Spliterators_LongIteratorSpliterator) TrySplit__Spliterator_OfLong() Spliterator_OfLong {
	var i PrimitiveIterator_OfLong = t.F_it; var s int64 = t.F_est; var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { tmp2 = i.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *LongArray = NewLongArray(n)
		var j int32 = 0
	L1: for {
		a.A[j] = i.NextLong__J()
		var tmp3 bool; var tmp4 bool; var tmp5 int32; j = j + 1; tmp5 = j; tmp4 = tmp5 < n; if tmp4 { tmp4 = i.HasNext__Z() }; tmp3 = tmp4; if tmp3 { continue L1 }
//line :987:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_LongArraySpliterator_New_J1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_LongArraySpliterator_New_J1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :981:1
					return nil
				}
}













func (t *Spliterators_LongIteratorSpliterator) ForEachRemaining_LongConsumer__V(action LongConsumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	t.F_it.ForEachRemaining_LongConsumer__V(action)
}
func (t *Spliterators_LongIteratorSpliterator) TryAdvance_LongConsumer__Z(action LongConsumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	if t.F_it.HasNext__Z() { action.Accept_J__V(t.F_it.NextLong__J()); return true } else { return false
	} }
func (t *Spliterators_LongIteratorSpliterator) EstimateSize__J() int64 { return t.F_est }

func (t *Spliterators_LongIteratorSpliterator) Characteristics__I() int32 { return t.F_characteristics }

func (t *Spliterators_LongIteratorSpliterator) GetComparator__Comparator() Comparator {
	if t.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}














func Spliterators_DoubleIteratorSpliterator_New_PrimitiveIterator_OfDouble_J_I(p0 PrimitiveIterator_OfDouble, p1 int64, p2 int32) *Spliterators_DoubleIteratorSpliterator { t := &Spliterators_DoubleIteratorSpliterator{}; t.Ctor_PrimitiveIterator_OfDouble_J_I(p0, p1, p2); return t }
//line :1027:1
func (t *Spliterators_DoubleIteratorSpliterator) Ctor_PrimitiveIterator_OfDouble_J_I(iterator PrimitiveIterator_OfDouble, size int64, characteristics int32) {
	t.F_it = iterator
	t.F_est = size
	var tmp1 int32
	if characteristics&4096 == 0 {
		tmp1 = characteristics | 64 | 16384 } else {
//line :1031:1
			tmp1 = characteristics }
//line :1030:1
	t.F_characteristics = tmp1
}



func Spliterators_DoubleIteratorSpliterator_New_PrimitiveIterator_OfDouble_I(p0 PrimitiveIterator_OfDouble, p1 int32) *Spliterators_DoubleIteratorSpliterator { t := &Spliterators_DoubleIteratorSpliterator{}; t.Ctor_PrimitiveIterator_OfDouble_I(p0, p1); return t }
//line :1035:1
func (t *Spliterators_DoubleIteratorSpliterator) Ctor_PrimitiveIterator_OfDouble_I(iterator PrimitiveIterator_OfDouble, characteristics int32) {
	t.F_it = iterator
	t.F_est = 9223372036854775807
	t.F_characteristics = characteristics & -16449
}


func (t *Spliterators_DoubleIteratorSpliterator) TrySplit__Spliterator_OfDouble() Spliterator_OfDouble {
	var i PrimitiveIterator_OfDouble = t.F_it; var s int64 = t.F_est; var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { tmp2 = i.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if int64(n) > s { n = int32(s) }
		if n > 33554432 { n = 33554432 }
		var a *DoubleArray = NewDoubleArray(n)
		var j int32 = 0
	L1: for {
		a.A[j] = i.NextDouble__D()
		var tmp3 bool; var tmp4 bool; var tmp5 int32; j = j + 1; tmp5 = j; tmp4 = tmp5 < n; if tmp4 { tmp4 = i.HasNext__Z() }; tmp3 = tmp4; if tmp3 { continue L1 }
//line :1051:1
		break L1
	}

		t.F_batch = j
		if !(t.F_est == 9223372036854775807) {

			t.F_est = t.F_est - int64(j)
			return Spliterators_DoubleArraySpliterator_New_D1_I_I_I(a, 0, j, t.F_characteristics) } else {
				return Spliterators_DoubleArraySpliterator_New_D1_I_I_I_J(a, 0, j, t.F_characteristics, 4611686018427387903) } } else {
//line :1045:1
					return nil
				}
}

















func (t *Spliterators_DoubleIteratorSpliterator) ForEachRemaining_DoubleConsumer__V(action DoubleConsumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	t.F_it.ForEachRemaining_DoubleConsumer__V(action)
}
func (t *Spliterators_DoubleIteratorSpliterator) TryAdvance_DoubleConsumer__Z(action DoubleConsumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	if t.F_it.HasNext__Z() { action.Accept_D__V(t.F_it.NextDouble__D()); return true } else { return false
	} }
func (t *Spliterators_DoubleIteratorSpliterator) EstimateSize__J() int64 { return t.F_est }

func (t *Spliterators_DoubleIteratorSpliterator) Characteristics__I() int32 { return t.F_characteristics }

func (t *Spliterators_DoubleIteratorSpliterator) GetComparator__Comparator() Comparator {
	if t.HasCharacteristics_I__Z(4) { return nil } else { panic(Thrown(IllegalStateException_New()))
	}
}

type Spliterators struct{ Object }

func (t *Spliterators) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators) GetClass__Class() *Class { return Spliterators_class }

func (t *Spliterators) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_InstanceOf(x any) bool { _, ok := x.(*Spliterators); return ok }

func Spliterators_Cast(x any) *Spliterators { if x == nil { return nil }; v, ok := x.(*Spliterators); if !ok { panic(ClassCast(x, Spliterators_class)) }; return v }



type Spliterators_1Adapter struct{ Object; F_valueReady bool; F_nextElement any; F_val_spliterator Spliterator }

func (t *Spliterators_1Adapter) Is_Iterator() {}

func (t *Spliterators_1Adapter) Is_Consumer() {}

func Spliterators_1Adapter_New_Spliterator(p0 Spliterator) *Spliterators_1Adapter { t := &Spliterators_1Adapter{}; t.Ctor_Spliterator(p0); return t }

func (t *Spliterators_1Adapter) Ctor_Spliterator(val_spliterator Spliterator) { t.F_val_spliterator = val_spliterator; t.F_valueReady = false }

func (t *Spliterators_1Adapter) Remove__V() { Iterator_Remove__V(t) }

func (t *Spliterators_1Adapter) AndThen_Consumer__Consumer(p0 Consumer) Consumer { return Consumer_AndThen_Consumer__Consumer(t, p0) }

func (t *Spliterators_1Adapter) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_1Adapter) GetClass__Class() *Class { return Spliterators_1Adapter_class }

func (t *Spliterators_1Adapter) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_1Adapter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_1Adapter) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_1Adapter_InstanceOf(x any) bool { _, ok := x.(*Spliterators_1Adapter); return ok }

func Spliterators_1Adapter_Cast(x any) *Spliterators_1Adapter { if x == nil { return nil }; v, ok := x.(*Spliterators_1Adapter); if !ok { panic(ClassCast(x, Spliterators_1Adapter_class)) }; return v }



type Spliterators_2Adapter struct{ Object; F_valueReady bool; F_nextElement int32; F_val_spliterator Spliterator_OfInt }

func (t *Spliterators_2Adapter) Is_PrimitiveIterator_OfInt() {}

func (t *Spliterators_2Adapter) Is_IntConsumer() {}

func (t *Spliterators_2Adapter) Is_PrimitiveIterator() {}

func (t *Spliterators_2Adapter) Is_Iterator() {}

func Spliterators_2Adapter_New_Spliterator_OfInt(p0 Spliterator_OfInt) *Spliterators_2Adapter { t := &Spliterators_2Adapter{}; t.Ctor_Spliterator_OfInt(p0); return t }

func (t *Spliterators_2Adapter) Ctor_Spliterator_OfInt(val_spliterator Spliterator_OfInt) { t.F_val_spliterator = val_spliterator; t.F_valueReady = false }

func (t *Spliterators_2Adapter) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func (t *Spliterators_2Adapter) Next__O() any { return PrimitiveIterator_OfInt_Next__O(t) }

func (t *Spliterators_2Adapter) AndThen_IntConsumer__IntConsumer(p0 IntConsumer) IntConsumer { return IntConsumer_AndThen_IntConsumer__IntConsumer(t, p0) }

func (t *Spliterators_2Adapter) ForEachRemaining_Consumer__V(p0 Consumer) { PrimitiveIterator_OfInt_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_2Adapter) Next__Integer() *Integer { return PrimitiveIterator_OfInt_Next__Integer(t) }

func (t *Spliterators_2Adapter) Remove__V() { Iterator_Remove__V(t) }

func (t *Spliterators_2Adapter) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_2Adapter) GetClass__Class() *Class { return Spliterators_2Adapter_class }

func (t *Spliterators_2Adapter) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_2Adapter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_2Adapter) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_2Adapter_InstanceOf(x any) bool { _, ok := x.(*Spliterators_2Adapter); return ok }

func Spliterators_2Adapter_Cast(x any) *Spliterators_2Adapter { if x == nil { return nil }; v, ok := x.(*Spliterators_2Adapter); if !ok { panic(ClassCast(x, Spliterators_2Adapter_class)) }; return v }



type Spliterators_3Adapter struct{ Object; F_valueReady bool; F_nextElement int64; F_val_spliterator Spliterator_OfLong }

func (t *Spliterators_3Adapter) Is_PrimitiveIterator_OfLong() {}

func (t *Spliterators_3Adapter) Is_LongConsumer() {}

func (t *Spliterators_3Adapter) Is_PrimitiveIterator() {}

func (t *Spliterators_3Adapter) Is_Iterator() {}

func Spliterators_3Adapter_New_Spliterator_OfLong(p0 Spliterator_OfLong) *Spliterators_3Adapter { t := &Spliterators_3Adapter{}; t.Ctor_Spliterator_OfLong(p0); return t }

func (t *Spliterators_3Adapter) Ctor_Spliterator_OfLong(val_spliterator Spliterator_OfLong) { t.F_val_spliterator = val_spliterator; t.F_valueReady = false }

func (t *Spliterators_3Adapter) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_LongConsumer__V(LongConsumer_Cast(p0)) }

func (t *Spliterators_3Adapter) Next__O() any { return PrimitiveIterator_OfLong_Next__O(t) }

func (t *Spliterators_3Adapter) ForEachRemaining_Consumer__V(p0 Consumer) { PrimitiveIterator_OfLong_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_3Adapter) Next__Long() *Long { return PrimitiveIterator_OfLong_Next__Long(t) }

func (t *Spliterators_3Adapter) AndThen_LongConsumer__LongConsumer(p0 LongConsumer) LongConsumer { return LongConsumer_AndThen_LongConsumer__LongConsumer(t, p0) }

func (t *Spliterators_3Adapter) Remove__V() { Iterator_Remove__V(t) }

func (t *Spliterators_3Adapter) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_3Adapter) GetClass__Class() *Class { return Spliterators_3Adapter_class }

func (t *Spliterators_3Adapter) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_3Adapter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_3Adapter) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_3Adapter_InstanceOf(x any) bool { _, ok := x.(*Spliterators_3Adapter); return ok }

func Spliterators_3Adapter_Cast(x any) *Spliterators_3Adapter { if x == nil { return nil }; v, ok := x.(*Spliterators_3Adapter); if !ok { panic(ClassCast(x, Spliterators_3Adapter_class)) }; return v }



type Spliterators_4Adapter struct{ Object; F_valueReady bool; F_nextElement float64; F_val_spliterator Spliterator_OfDouble }

func (t *Spliterators_4Adapter) Is_PrimitiveIterator_OfDouble() {}

func (t *Spliterators_4Adapter) Is_DoubleConsumer() {}

func (t *Spliterators_4Adapter) Is_PrimitiveIterator() {}

func (t *Spliterators_4Adapter) Is_Iterator() {}

func Spliterators_4Adapter_New_Spliterator_OfDouble(p0 Spliterator_OfDouble) *Spliterators_4Adapter { t := &Spliterators_4Adapter{}; t.Ctor_Spliterator_OfDouble(p0); return t }

func (t *Spliterators_4Adapter) Ctor_Spliterator_OfDouble(val_spliterator Spliterator_OfDouble) { t.F_val_spliterator = val_spliterator; t.F_valueReady = false }

func (t *Spliterators_4Adapter) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_DoubleConsumer__V(DoubleConsumer_Cast(p0)) }

func (t *Spliterators_4Adapter) Next__O() any { return PrimitiveIterator_OfDouble_Next__O(t) }

func (t *Spliterators_4Adapter) ForEachRemaining_Consumer__V(p0 Consumer) { PrimitiveIterator_OfDouble_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_4Adapter) AndThen_DoubleConsumer__DoubleConsumer(p0 DoubleConsumer) DoubleConsumer { return DoubleConsumer_AndThen_DoubleConsumer__DoubleConsumer(t, p0) }

func (t *Spliterators_4Adapter) Next__Double() *Double { return PrimitiveIterator_OfDouble_Next__Double(t) }

func (t *Spliterators_4Adapter) Remove__V() { Iterator_Remove__V(t) }

func (t *Spliterators_4Adapter) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_4Adapter) GetClass__Class() *Class { return Spliterators_4Adapter_class }

func (t *Spliterators_4Adapter) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_4Adapter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_4Adapter) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_4Adapter_InstanceOf(x any) bool { _, ok := x.(*Spliterators_4Adapter); return ok }

func Spliterators_4Adapter_Cast(x any) *Spliterators_4Adapter { if x == nil { return nil }; v, ok := x.(*Spliterators_4Adapter); if !ok { panic(ClassCast(x, Spliterators_4Adapter_class)) }; return v }



type Spliterators_AbstractDoubleSpliterator struct{ Object; F_characteristics int32; F_est int64; F_batch int32 }

type Spliterators_AbstractDoubleSpliterator_I interface{ Object_I; Spliterator_OfDouble; Spliterator_OfPrimitive; Spliterator; Self_Spliterators_AbstractDoubleSpliterator() *Spliterators_AbstractDoubleSpliterator; TrySplit__Spliterator_OfDouble() Spliterator_OfDouble; EstimateSize__J() int64; Characteristics__I() int32; TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive; TrySplit__Spliterator() Spliterator }

func (t *Spliterators_AbstractDoubleSpliterator) Self_Spliterators_AbstractDoubleSpliterator() *Spliterators_AbstractDoubleSpliterator { return t }

func (t *Spliterators_AbstractDoubleSpliterator) Is_Spliterator_OfDouble() {}

func (t *Spliterators_AbstractDoubleSpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_AbstractDoubleSpliterator) Is_Spliterator() {}

const Spliterators_AbstractDoubleSpliterator_MAX_BATCH int32 = 33554432

const Spliterators_AbstractDoubleSpliterator_BATCH_UNIT int32 = 1024

func (t *Spliterators_AbstractDoubleSpliterator) Impl_TrySplit__Spliterator_OfPrimitive(this Spliterators_AbstractDoubleSpliterator_I) Spliterator_OfPrimitive { return this.TrySplit__Spliterator_OfDouble() }

func (t *Spliterators_AbstractDoubleSpliterator) Impl_TrySplit__Spliterator(this Spliterators_AbstractDoubleSpliterator_I) Spliterator { return this.TrySplit__Spliterator_OfDouble() }

func Spliterators_AbstractDoubleSpliterator_InstanceOf(x any) bool { _, ok := x.(Spliterators_AbstractDoubleSpliterator_I); return ok }

func Spliterators_AbstractDoubleSpliterator_Cast(x any) Spliterators_AbstractDoubleSpliterator_I { if x == nil { return nil }; v, ok := x.(Spliterators_AbstractDoubleSpliterator_I); if !ok { panic(ClassCast(x, Spliterators_AbstractDoubleSpliterator_class)) }; return v }



type Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer struct{ Object; F_value float64 }

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) Is_DoubleConsumer() {}

func Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_New() *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer { t := &Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer{}; t.Ctor(); return t }

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) Ctor() {}

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) AndThen_DoubleConsumer__DoubleConsumer(p0 DoubleConsumer) DoubleConsumer { return DoubleConsumer_AndThen_DoubleConsumer__DoubleConsumer(t, p0) }

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) GetClass__Class() *Class { return Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_class }

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_InstanceOf(x any) bool { _, ok := x.(*Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer); return ok }

func Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_Cast(x any) *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer { if x == nil { return nil }; v, ok := x.(*Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer); if !ok { panic(ClassCast(x, Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_class)) }; return v }



type Spliterators_AbstractIntSpliterator struct{ Object; F_characteristics int32; F_est int64; F_batch int32 }

type Spliterators_AbstractIntSpliterator_I interface{ Object_I; Spliterator_OfInt; Spliterator_OfPrimitive; Spliterator; Self_Spliterators_AbstractIntSpliterator() *Spliterators_AbstractIntSpliterator; TrySplit__Spliterator_OfInt() Spliterator_OfInt; EstimateSize__J() int64; Characteristics__I() int32; TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive; TrySplit__Spliterator() Spliterator }

func (t *Spliterators_AbstractIntSpliterator) Self_Spliterators_AbstractIntSpliterator() *Spliterators_AbstractIntSpliterator { return t }

func (t *Spliterators_AbstractIntSpliterator) Is_Spliterator_OfInt() {}

func (t *Spliterators_AbstractIntSpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_AbstractIntSpliterator) Is_Spliterator() {}

const Spliterators_AbstractIntSpliterator_MAX_BATCH int32 = 33554432

const Spliterators_AbstractIntSpliterator_BATCH_UNIT int32 = 1024

func (t *Spliterators_AbstractIntSpliterator) Impl_TrySplit__Spliterator_OfPrimitive(this Spliterators_AbstractIntSpliterator_I) Spliterator_OfPrimitive { return this.TrySplit__Spliterator_OfInt() }

func (t *Spliterators_AbstractIntSpliterator) Impl_TrySplit__Spliterator(this Spliterators_AbstractIntSpliterator_I) Spliterator { return this.TrySplit__Spliterator_OfInt() }

func Spliterators_AbstractIntSpliterator_InstanceOf(x any) bool { _, ok := x.(Spliterators_AbstractIntSpliterator_I); return ok }

func Spliterators_AbstractIntSpliterator_Cast(x any) Spliterators_AbstractIntSpliterator_I { if x == nil { return nil }; v, ok := x.(Spliterators_AbstractIntSpliterator_I); if !ok { panic(ClassCast(x, Spliterators_AbstractIntSpliterator_class)) }; return v }



type Spliterators_AbstractIntSpliterator_HoldingIntConsumer struct{ Object; F_value int32 }

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) Is_IntConsumer() {}

func Spliterators_AbstractIntSpliterator_HoldingIntConsumer_New() *Spliterators_AbstractIntSpliterator_HoldingIntConsumer { t := &Spliterators_AbstractIntSpliterator_HoldingIntConsumer{}; t.Ctor(); return t }

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) Ctor() {}

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) AndThen_IntConsumer__IntConsumer(p0 IntConsumer) IntConsumer { return IntConsumer_AndThen_IntConsumer__IntConsumer(t, p0) }

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) GetClass__Class() *Class { return Spliterators_AbstractIntSpliterator_HoldingIntConsumer_class }

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_AbstractIntSpliterator_HoldingIntConsumer_InstanceOf(x any) bool { _, ok := x.(*Spliterators_AbstractIntSpliterator_HoldingIntConsumer); return ok }

func Spliterators_AbstractIntSpliterator_HoldingIntConsumer_Cast(x any) *Spliterators_AbstractIntSpliterator_HoldingIntConsumer { if x == nil { return nil }; v, ok := x.(*Spliterators_AbstractIntSpliterator_HoldingIntConsumer); if !ok { panic(ClassCast(x, Spliterators_AbstractIntSpliterator_HoldingIntConsumer_class)) }; return v }



type Spliterators_AbstractLongSpliterator struct{ Object; F_characteristics int32; F_est int64; F_batch int32 }

type Spliterators_AbstractLongSpliterator_I interface{ Object_I; Spliterator_OfLong; Spliterator_OfPrimitive; Spliterator; Self_Spliterators_AbstractLongSpliterator() *Spliterators_AbstractLongSpliterator; TrySplit__Spliterator_OfLong() Spliterator_OfLong; EstimateSize__J() int64; Characteristics__I() int32; TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive; TrySplit__Spliterator() Spliterator }

func (t *Spliterators_AbstractLongSpliterator) Self_Spliterators_AbstractLongSpliterator() *Spliterators_AbstractLongSpliterator { return t }

func (t *Spliterators_AbstractLongSpliterator) Is_Spliterator_OfLong() {}

func (t *Spliterators_AbstractLongSpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_AbstractLongSpliterator) Is_Spliterator() {}

const Spliterators_AbstractLongSpliterator_MAX_BATCH int32 = 33554432

const Spliterators_AbstractLongSpliterator_BATCH_UNIT int32 = 1024

func (t *Spliterators_AbstractLongSpliterator) Impl_TrySplit__Spliterator_OfPrimitive(this Spliterators_AbstractLongSpliterator_I) Spliterator_OfPrimitive { return this.TrySplit__Spliterator_OfLong() }

func (t *Spliterators_AbstractLongSpliterator) Impl_TrySplit__Spliterator(this Spliterators_AbstractLongSpliterator_I) Spliterator { return this.TrySplit__Spliterator_OfLong() }

func Spliterators_AbstractLongSpliterator_InstanceOf(x any) bool { _, ok := x.(Spliterators_AbstractLongSpliterator_I); return ok }

func Spliterators_AbstractLongSpliterator_Cast(x any) Spliterators_AbstractLongSpliterator_I { if x == nil { return nil }; v, ok := x.(Spliterators_AbstractLongSpliterator_I); if !ok { panic(ClassCast(x, Spliterators_AbstractLongSpliterator_class)) }; return v }



type Spliterators_AbstractLongSpliterator_HoldingLongConsumer struct{ Object; F_value int64 }

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) Is_LongConsumer() {}

func Spliterators_AbstractLongSpliterator_HoldingLongConsumer_New() *Spliterators_AbstractLongSpliterator_HoldingLongConsumer { t := &Spliterators_AbstractLongSpliterator_HoldingLongConsumer{}; t.Ctor(); return t }

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) Ctor() {}

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) AndThen_LongConsumer__LongConsumer(p0 LongConsumer) LongConsumer { return LongConsumer_AndThen_LongConsumer__LongConsumer(t, p0) }

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) GetClass__Class() *Class { return Spliterators_AbstractLongSpliterator_HoldingLongConsumer_class }

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_AbstractLongSpliterator_HoldingLongConsumer_InstanceOf(x any) bool { _, ok := x.(*Spliterators_AbstractLongSpliterator_HoldingLongConsumer); return ok }

func Spliterators_AbstractLongSpliterator_HoldingLongConsumer_Cast(x any) *Spliterators_AbstractLongSpliterator_HoldingLongConsumer { if x == nil { return nil }; v, ok := x.(*Spliterators_AbstractLongSpliterator_HoldingLongConsumer); if !ok { panic(ClassCast(x, Spliterators_AbstractLongSpliterator_HoldingLongConsumer_class)) }; return v }



type Spliterators_AbstractSpliterator struct{ Object; F_characteristics int32; F_est int64; F_batch int32 }

type Spliterators_AbstractSpliterator_I interface{ Object_I; Spliterator; Self_Spliterators_AbstractSpliterator() *Spliterators_AbstractSpliterator; TrySplit__Spliterator() Spliterator; EstimateSize__J() int64; Characteristics__I() int32 }

func (t *Spliterators_AbstractSpliterator) Self_Spliterators_AbstractSpliterator() *Spliterators_AbstractSpliterator { return t }

func (t *Spliterators_AbstractSpliterator) Is_Spliterator() {}

const Spliterators_AbstractSpliterator_BATCH_UNIT int32 = 1024

const Spliterators_AbstractSpliterator_MAX_BATCH int32 = 33554432

func Spliterators_AbstractSpliterator_InstanceOf(x any) bool { _, ok := x.(Spliterators_AbstractSpliterator_I); return ok }

func Spliterators_AbstractSpliterator_Cast(x any) Spliterators_AbstractSpliterator_I { if x == nil { return nil }; v, ok := x.(Spliterators_AbstractSpliterator_I); if !ok { panic(ClassCast(x, Spliterators_AbstractSpliterator_class)) }; return v }



type Spliterators_AbstractSpliterator_HoldingConsumer struct{ Object; F_value any }

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) Is_Consumer() {}

func Spliterators_AbstractSpliterator_HoldingConsumer_New() *Spliterators_AbstractSpliterator_HoldingConsumer { t := &Spliterators_AbstractSpliterator_HoldingConsumer{}; t.Ctor(); return t }

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) Ctor() {}

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) AndThen_Consumer__Consumer(p0 Consumer) Consumer { return Consumer_AndThen_Consumer__Consumer(t, p0) }

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) GetClass__Class() *Class { return Spliterators_AbstractSpliterator_HoldingConsumer_class }

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_AbstractSpliterator_HoldingConsumer) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_AbstractSpliterator_HoldingConsumer_InstanceOf(x any) bool { _, ok := x.(*Spliterators_AbstractSpliterator_HoldingConsumer); return ok }

func Spliterators_AbstractSpliterator_HoldingConsumer_Cast(x any) *Spliterators_AbstractSpliterator_HoldingConsumer { if x == nil { return nil }; v, ok := x.(*Spliterators_AbstractSpliterator_HoldingConsumer); if !ok { panic(ClassCast(x, Spliterators_AbstractSpliterator_HoldingConsumer_class)) }; return v }



type Spliterators_ArraySpliterator struct{ Object; F_array *RefArray; F_index, F_fence, F_characteristics int32; F_estimatedSize int64 }

func (t *Spliterators_ArraySpliterator) Is_Spliterator() {}

func (t *Spliterators_ArraySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_ArraySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_ArraySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_ArraySpliterator) GetClass__Class() *Class { return Spliterators_ArraySpliterator_class }

func (t *Spliterators_ArraySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_ArraySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_ArraySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_ArraySpliterator_InstanceOf(x any) bool { _, ok := x.(*Spliterators_ArraySpliterator); return ok }

func Spliterators_ArraySpliterator_Cast(x any) *Spliterators_ArraySpliterator { if x == nil { return nil }; v, ok := x.(*Spliterators_ArraySpliterator); if !ok { panic(ClassCast(x, Spliterators_ArraySpliterator_class)) }; return v }



type Spliterators_DoubleArraySpliterator struct{ Object; F_array *DoubleArray; F_index, F_fence, F_characteristics int32; F_estimatedSize int64 }

func (t *Spliterators_DoubleArraySpliterator) Is_Spliterator_OfDouble() {}

func (t *Spliterators_DoubleArraySpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_DoubleArraySpliterator) Is_Spliterator() {}

func (t *Spliterators_DoubleArraySpliterator) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return t.TrySplit__Spliterator_OfDouble() }

func (t *Spliterators_DoubleArraySpliterator) TryAdvance_O__Z(p0 any) bool { return t.TryAdvance_DoubleConsumer__Z(DoubleConsumer_Cast(p0)) }

func (t *Spliterators_DoubleArraySpliterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_DoubleConsumer__V(DoubleConsumer_Cast(p0)) }

func (t *Spliterators_DoubleArraySpliterator) TrySplit__Spliterator() Spliterator { return t.TrySplit__Spliterator_OfDouble() }

func (t *Spliterators_DoubleArraySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_DoubleArraySpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfDouble_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_DoubleArraySpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfDouble_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_DoubleArraySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_DoubleArraySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_DoubleArraySpliterator) GetClass__Class() *Class { return Spliterators_DoubleArraySpliterator_class }

func (t *Spliterators_DoubleArraySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_DoubleArraySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_DoubleArraySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_DoubleArraySpliterator_InstanceOf(x any) bool { _, ok := x.(*Spliterators_DoubleArraySpliterator); return ok }

func Spliterators_DoubleArraySpliterator_Cast(x any) *Spliterators_DoubleArraySpliterator { if x == nil { return nil }; v, ok := x.(*Spliterators_DoubleArraySpliterator); if !ok { panic(ClassCast(x, Spliterators_DoubleArraySpliterator_class)) }; return v }



type Spliterators_DoubleIteratorSpliterator struct{ Object; F_it PrimitiveIterator_OfDouble; F_characteristics int32; F_est int64; F_batch int32 }

func (t *Spliterators_DoubleIteratorSpliterator) Is_Spliterator_OfDouble() {}

func (t *Spliterators_DoubleIteratorSpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_DoubleIteratorSpliterator) Is_Spliterator() {}

const Spliterators_DoubleIteratorSpliterator_BATCH_UNIT int32 = 1024

const Spliterators_DoubleIteratorSpliterator_MAX_BATCH int32 = 33554432

func (t *Spliterators_DoubleIteratorSpliterator) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return t.TrySplit__Spliterator_OfDouble() }

func (t *Spliterators_DoubleIteratorSpliterator) TryAdvance_O__Z(p0 any) bool { return t.TryAdvance_DoubleConsumer__Z(DoubleConsumer_Cast(p0)) }

func (t *Spliterators_DoubleIteratorSpliterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_DoubleConsumer__V(DoubleConsumer_Cast(p0)) }

func (t *Spliterators_DoubleIteratorSpliterator) TrySplit__Spliterator() Spliterator { return t.TrySplit__Spliterator_OfDouble() }

func (t *Spliterators_DoubleIteratorSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_DoubleIteratorSpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfDouble_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_DoubleIteratorSpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfDouble_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_DoubleIteratorSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_DoubleIteratorSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_DoubleIteratorSpliterator) GetClass__Class() *Class { return Spliterators_DoubleIteratorSpliterator_class }

func (t *Spliterators_DoubleIteratorSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_DoubleIteratorSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_DoubleIteratorSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_DoubleIteratorSpliterator_InstanceOf(x any) bool { _, ok := x.(*Spliterators_DoubleIteratorSpliterator); return ok }

func Spliterators_DoubleIteratorSpliterator_Cast(x any) *Spliterators_DoubleIteratorSpliterator { if x == nil { return nil }; v, ok := x.(*Spliterators_DoubleIteratorSpliterator); if !ok { panic(ClassCast(x, Spliterators_DoubleIteratorSpliterator_class)) }; return v }



type Spliterators_EmptySpliterator struct{ Object }

type Spliterators_EmptySpliterator_I interface{ Object_I; Self_Spliterators_EmptySpliterator() *Spliterators_EmptySpliterator; TrySplit__Spliterator() Spliterator; TryAdvance_O__Z(p0 any) bool; ForEachRemaining_O__V(p0 any); EstimateSize__J() int64; Characteristics__I() int32 }

func (t *Spliterators_EmptySpliterator) Self_Spliterators_EmptySpliterator() *Spliterators_EmptySpliterator { return t }

func Spliterators_EmptySpliterator_InstanceOf(x any) bool { _, ok := x.(Spliterators_EmptySpliterator_I); return ok }

func Spliterators_EmptySpliterator_Cast(x any) Spliterators_EmptySpliterator_I { if x == nil { return nil }; v, ok := x.(Spliterators_EmptySpliterator_I); if !ok { panic(ClassCast(x, Spliterators_EmptySpliterator_class)) }; return v }



type Spliterators_EmptySpliterator_OfDouble struct{ Spliterators_EmptySpliterator }

func (t *Spliterators_EmptySpliterator_OfDouble) Is_Spliterator_OfDouble() {}

func (t *Spliterators_EmptySpliterator_OfDouble) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_EmptySpliterator_OfDouble) Is_Spliterator() {}

var Spliterators_EmptySpliterator_OfDouble_EMPTY_DOUBLE_SPLITERATOR Spliterator_OfDouble

var Spliterators_EmptySpliterator_OfDouble_init ClassInit

func Spliterators_EmptySpliterator_OfDouble_Init() { if !Spliterators_EmptySpliterator_OfDouble_init.Done() { Spliterators_EmptySpliterator_OfDouble_init.Run(Spliterators_EmptySpliterator_OfDouble_clinit) } }

func Spliterators_EmptySpliterator_OfDouble_clinit() { Spliterators_EmptySpliterator_OfDouble_EMPTY_DOUBLE_SPLITERATOR = Spliterators_EmptySpliterator_OfDouble_New() }

func (t *Spliterators_EmptySpliterator_OfDouble) TrySplit__Spliterator_OfDouble() Spliterator_OfDouble { return Spliterator_OfDouble_Cast(t.Spliterators_EmptySpliterator.Impl_TrySplit__Spliterator(t)) }

func (t *Spliterators_EmptySpliterator_OfDouble) TryAdvance_DoubleConsumer__Z(p0 DoubleConsumer) bool { return t.Spliterators_EmptySpliterator.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfDouble) ForEachRemaining_DoubleConsumer__V(p0 DoubleConsumer) { t.Spliterators_EmptySpliterator.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfDouble) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return Spliterator_OfPrimitive_Cast(t.Spliterators_EmptySpliterator.Impl_TrySplit__Spliterator(t)) }

func (t *Spliterators_EmptySpliterator_OfDouble) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *Spliterators_EmptySpliterator_OfDouble) Characteristics__I() int32 { return t.Impl_Characteristics__I(t) }

func (t *Spliterators_EmptySpliterator_OfDouble) TrySplit__Spliterator() Spliterator { return t.Impl_TrySplit__Spliterator(t) }

func (t *Spliterators_EmptySpliterator_OfDouble) TryAdvance_O__Z(p0 any) bool { return t.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfDouble) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfDouble) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfDouble_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfDouble) ForEachRemaining_O__V(p0 any) { t.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfDouble) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *Spliterators_EmptySpliterator_OfDouble) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfDouble_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfDouble) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_EmptySpliterator_OfDouble) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_EmptySpliterator_OfDouble) GetClass__Class() *Class { return Spliterators_EmptySpliterator_OfDouble_class }

func (t *Spliterators_EmptySpliterator_OfDouble) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_EmptySpliterator_OfDouble) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_EmptySpliterator_OfDouble) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_EmptySpliterator_OfDouble_InstanceOf(x any) bool { _, ok := x.(*Spliterators_EmptySpliterator_OfDouble); return ok }

func Spliterators_EmptySpliterator_OfDouble_Cast(x any) *Spliterators_EmptySpliterator_OfDouble { if x == nil { return nil }; v, ok := x.(*Spliterators_EmptySpliterator_OfDouble); if !ok { panic(ClassCast(x, Spliterators_EmptySpliterator_OfDouble_class)) }; return v }



type Spliterators_EmptySpliterator_OfInt struct{ Spliterators_EmptySpliterator }

func (t *Spliterators_EmptySpliterator_OfInt) Is_Spliterator_OfInt() {}

func (t *Spliterators_EmptySpliterator_OfInt) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_EmptySpliterator_OfInt) Is_Spliterator() {}

var Spliterators_EmptySpliterator_OfInt_EMPTY_INT_SPLITERATOR Spliterator_OfInt

var Spliterators_EmptySpliterator_OfInt_init ClassInit

func Spliterators_EmptySpliterator_OfInt_Init() { if !Spliterators_EmptySpliterator_OfInt_init.Done() { Spliterators_EmptySpliterator_OfInt_init.Run(Spliterators_EmptySpliterator_OfInt_clinit) } }

func Spliterators_EmptySpliterator_OfInt_clinit() { Spliterators_EmptySpliterator_OfInt_EMPTY_INT_SPLITERATOR = Spliterators_EmptySpliterator_OfInt_New() }

func (t *Spliterators_EmptySpliterator_OfInt) TrySplit__Spliterator_OfInt() Spliterator_OfInt { return Spliterator_OfInt_Cast(t.Spliterators_EmptySpliterator.Impl_TrySplit__Spliterator(t)) }

func (t *Spliterators_EmptySpliterator_OfInt) TryAdvance_IntConsumer__Z(p0 IntConsumer) bool { return t.Spliterators_EmptySpliterator.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfInt) ForEachRemaining_IntConsumer__V(p0 IntConsumer) { t.Spliterators_EmptySpliterator.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfInt) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return Spliterator_OfPrimitive_Cast(t.Spliterators_EmptySpliterator.Impl_TrySplit__Spliterator(t)) }

func (t *Spliterators_EmptySpliterator_OfInt) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *Spliterators_EmptySpliterator_OfInt) Characteristics__I() int32 { return t.Impl_Characteristics__I(t) }

func (t *Spliterators_EmptySpliterator_OfInt) TrySplit__Spliterator() Spliterator { return t.Impl_TrySplit__Spliterator(t) }

func (t *Spliterators_EmptySpliterator_OfInt) TryAdvance_O__Z(p0 any) bool { return t.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfInt) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfInt) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfInt_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfInt) ForEachRemaining_O__V(p0 any) { t.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfInt) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *Spliterators_EmptySpliterator_OfInt) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfInt_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfInt) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_EmptySpliterator_OfInt) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_EmptySpliterator_OfInt) GetClass__Class() *Class { return Spliterators_EmptySpliterator_OfInt_class }

func (t *Spliterators_EmptySpliterator_OfInt) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_EmptySpliterator_OfInt) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_EmptySpliterator_OfInt) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_EmptySpliterator_OfInt_InstanceOf(x any) bool { _, ok := x.(*Spliterators_EmptySpliterator_OfInt); return ok }

func Spliterators_EmptySpliterator_OfInt_Cast(x any) *Spliterators_EmptySpliterator_OfInt { if x == nil { return nil }; v, ok := x.(*Spliterators_EmptySpliterator_OfInt); if !ok { panic(ClassCast(x, Spliterators_EmptySpliterator_OfInt_class)) }; return v }



type Spliterators_EmptySpliterator_OfLong struct{ Spliterators_EmptySpliterator }

func (t *Spliterators_EmptySpliterator_OfLong) Is_Spliterator_OfLong() {}

func (t *Spliterators_EmptySpliterator_OfLong) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_EmptySpliterator_OfLong) Is_Spliterator() {}

var Spliterators_EmptySpliterator_OfLong_EMPTY_LONG_SPLITERATOR Spliterator_OfLong

var Spliterators_EmptySpliterator_OfLong_init ClassInit

func Spliterators_EmptySpliterator_OfLong_Init() { if !Spliterators_EmptySpliterator_OfLong_init.Done() { Spliterators_EmptySpliterator_OfLong_init.Run(Spliterators_EmptySpliterator_OfLong_clinit) } }

func Spliterators_EmptySpliterator_OfLong_clinit() { Spliterators_EmptySpliterator_OfLong_EMPTY_LONG_SPLITERATOR = Spliterators_EmptySpliterator_OfLong_New() }

func (t *Spliterators_EmptySpliterator_OfLong) TrySplit__Spliterator_OfLong() Spliterator_OfLong { return Spliterator_OfLong_Cast(t.Spliterators_EmptySpliterator.Impl_TrySplit__Spliterator(t)) }

func (t *Spliterators_EmptySpliterator_OfLong) TryAdvance_LongConsumer__Z(p0 LongConsumer) bool { return t.Spliterators_EmptySpliterator.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfLong) ForEachRemaining_LongConsumer__V(p0 LongConsumer) { t.Spliterators_EmptySpliterator.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfLong) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return Spliterator_OfPrimitive_Cast(t.Spliterators_EmptySpliterator.Impl_TrySplit__Spliterator(t)) }

func (t *Spliterators_EmptySpliterator_OfLong) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *Spliterators_EmptySpliterator_OfLong) Characteristics__I() int32 { return t.Impl_Characteristics__I(t) }

func (t *Spliterators_EmptySpliterator_OfLong) TrySplit__Spliterator() Spliterator { return t.Impl_TrySplit__Spliterator(t) }

func (t *Spliterators_EmptySpliterator_OfLong) TryAdvance_O__Z(p0 any) bool { return t.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfLong) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfLong) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfLong_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfLong) ForEachRemaining_O__V(p0 any) { t.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfLong) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *Spliterators_EmptySpliterator_OfLong) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfLong_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfLong) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_EmptySpliterator_OfLong) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_EmptySpliterator_OfLong) GetClass__Class() *Class { return Spliterators_EmptySpliterator_OfLong_class }

func (t *Spliterators_EmptySpliterator_OfLong) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_EmptySpliterator_OfLong) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_EmptySpliterator_OfLong) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_EmptySpliterator_OfLong_InstanceOf(x any) bool { _, ok := x.(*Spliterators_EmptySpliterator_OfLong); return ok }

func Spliterators_EmptySpliterator_OfLong_Cast(x any) *Spliterators_EmptySpliterator_OfLong { if x == nil { return nil }; v, ok := x.(*Spliterators_EmptySpliterator_OfLong); if !ok { panic(ClassCast(x, Spliterators_EmptySpliterator_OfLong_class)) }; return v }



type Spliterators_EmptySpliterator_OfRef struct{ Spliterators_EmptySpliterator }

func (t *Spliterators_EmptySpliterator_OfRef) Is_Spliterator() {}

var Spliterators_EmptySpliterator_OfRef_EMPTY_SPLITERATOR Spliterator

var Spliterators_EmptySpliterator_OfRef_init ClassInit

func Spliterators_EmptySpliterator_OfRef_Init() { if !Spliterators_EmptySpliterator_OfRef_init.Done() { Spliterators_EmptySpliterator_OfRef_init.Run(Spliterators_EmptySpliterator_OfRef_clinit) } }

func Spliterators_EmptySpliterator_OfRef_clinit() { Spliterators_EmptySpliterator_OfRef_EMPTY_SPLITERATOR = Spliterators_EmptySpliterator_OfRef_New() }

func (t *Spliterators_EmptySpliterator_OfRef) TryAdvance_Consumer__Z(p0 Consumer) bool { return t.Spliterators_EmptySpliterator.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfRef) ForEachRemaining_Consumer__V(p0 Consumer) { t.Spliterators_EmptySpliterator.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfRef) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *Spliterators_EmptySpliterator_OfRef) Characteristics__I() int32 { return t.Impl_Characteristics__I(t) }

func (t *Spliterators_EmptySpliterator_OfRef) TrySplit__Spliterator() Spliterator { return t.Impl_TrySplit__Spliterator(t) }

func (t *Spliterators_EmptySpliterator_OfRef) TryAdvance_O__Z(p0 any) bool { return t.Impl_TryAdvance_O__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfRef) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_EmptySpliterator_OfRef) ForEachRemaining_O__V(p0 any) { t.Impl_ForEachRemaining_O__V(t, p0) }

func (t *Spliterators_EmptySpliterator_OfRef) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *Spliterators_EmptySpliterator_OfRef) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_EmptySpliterator_OfRef) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_EmptySpliterator_OfRef) GetClass__Class() *Class { return Spliterators_EmptySpliterator_OfRef_class }

func (t *Spliterators_EmptySpliterator_OfRef) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_EmptySpliterator_OfRef) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_EmptySpliterator_OfRef) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_EmptySpliterator_OfRef_InstanceOf(x any) bool { _, ok := x.(*Spliterators_EmptySpliterator_OfRef); return ok }

func Spliterators_EmptySpliterator_OfRef_Cast(x any) *Spliterators_EmptySpliterator_OfRef { if x == nil { return nil }; v, ok := x.(*Spliterators_EmptySpliterator_OfRef); if !ok { panic(ClassCast(x, Spliterators_EmptySpliterator_OfRef_class)) }; return v }



type Spliterators_IntArraySpliterator struct{ Object; F_array *IntArray; F_index, F_fence, F_characteristics int32; F_estimatedSize int64 }

func (t *Spliterators_IntArraySpliterator) Is_Spliterator_OfInt() {}

func (t *Spliterators_IntArraySpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_IntArraySpliterator) Is_Spliterator() {}

func (t *Spliterators_IntArraySpliterator) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return t.TrySplit__Spliterator_OfInt() }

func (t *Spliterators_IntArraySpliterator) TryAdvance_O__Z(p0 any) bool { return t.TryAdvance_IntConsumer__Z(IntConsumer_Cast(p0)) }

func (t *Spliterators_IntArraySpliterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func (t *Spliterators_IntArraySpliterator) TrySplit__Spliterator() Spliterator { return t.TrySplit__Spliterator_OfInt() }

func (t *Spliterators_IntArraySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_IntArraySpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfInt_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_IntArraySpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfInt_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_IntArraySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_IntArraySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_IntArraySpliterator) GetClass__Class() *Class { return Spliterators_IntArraySpliterator_class }

func (t *Spliterators_IntArraySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_IntArraySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_IntArraySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_IntArraySpliterator_InstanceOf(x any) bool { _, ok := x.(*Spliterators_IntArraySpliterator); return ok }

func Spliterators_IntArraySpliterator_Cast(x any) *Spliterators_IntArraySpliterator { if x == nil { return nil }; v, ok := x.(*Spliterators_IntArraySpliterator); if !ok { panic(ClassCast(x, Spliterators_IntArraySpliterator_class)) }; return v }



type Spliterators_IntIteratorSpliterator struct{ Object; F_it PrimitiveIterator_OfInt; F_characteristics int32; F_est int64; F_batch int32 }

func (t *Spliterators_IntIteratorSpliterator) Is_Spliterator_OfInt() {}

func (t *Spliterators_IntIteratorSpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_IntIteratorSpliterator) Is_Spliterator() {}

const Spliterators_IntIteratorSpliterator_BATCH_UNIT int32 = 1024

const Spliterators_IntIteratorSpliterator_MAX_BATCH int32 = 33554432

func (t *Spliterators_IntIteratorSpliterator) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return t.TrySplit__Spliterator_OfInt() }

func (t *Spliterators_IntIteratorSpliterator) TryAdvance_O__Z(p0 any) bool { return t.TryAdvance_IntConsumer__Z(IntConsumer_Cast(p0)) }

func (t *Spliterators_IntIteratorSpliterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func (t *Spliterators_IntIteratorSpliterator) TrySplit__Spliterator() Spliterator { return t.TrySplit__Spliterator_OfInt() }

func (t *Spliterators_IntIteratorSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_IntIteratorSpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfInt_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_IntIteratorSpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfInt_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_IntIteratorSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_IntIteratorSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_IntIteratorSpliterator) GetClass__Class() *Class { return Spliterators_IntIteratorSpliterator_class }

func (t *Spliterators_IntIteratorSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_IntIteratorSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_IntIteratorSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_IntIteratorSpliterator_InstanceOf(x any) bool { _, ok := x.(*Spliterators_IntIteratorSpliterator); return ok }

func Spliterators_IntIteratorSpliterator_Cast(x any) *Spliterators_IntIteratorSpliterator { if x == nil { return nil }; v, ok := x.(*Spliterators_IntIteratorSpliterator); if !ok { panic(ClassCast(x, Spliterators_IntIteratorSpliterator_class)) }; return v }



type Spliterators_IteratorSpliterator struct{ Object; F_collection Collection; F_it Iterator; F_characteristics int32; F_est int64; F_batch int32 }

type Spliterators_IteratorSpliterator_I interface{ Object_I; Spliterator; Self_Spliterators_IteratorSpliterator() *Spliterators_IteratorSpliterator; TrySplit__Spliterator() Spliterator; ForEachRemaining_Consumer__V(p0 Consumer); TryAdvance_Consumer__Z(p0 Consumer) bool; EstimateSize__J() int64; Characteristics__I() int32; GetComparator__Comparator() Comparator }

func (t *Spliterators_IteratorSpliterator) Self_Spliterators_IteratorSpliterator() *Spliterators_IteratorSpliterator { return t }

func (t *Spliterators_IteratorSpliterator) Is_Spliterator() {}

const Spliterators_IteratorSpliterator_BATCH_UNIT int32 = 1024

const Spliterators_IteratorSpliterator_MAX_BATCH int32 = 33554432

func (t *Spliterators_IteratorSpliterator) TrySplit__Spliterator() Spliterator { return t.Impl_TrySplit__Spliterator(t) }

func (t *Spliterators_IteratorSpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { t.Impl_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_IteratorSpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return t.Impl_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_IteratorSpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *Spliterators_IteratorSpliterator) Characteristics__I() int32 { return t.Impl_Characteristics__I(t) }

func (t *Spliterators_IteratorSpliterator) GetComparator__Comparator() Comparator { return t.Impl_GetComparator__Comparator(t) }

func (t *Spliterators_IteratorSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_IteratorSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_IteratorSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_IteratorSpliterator) GetClass__Class() *Class { return Spliterators_IteratorSpliterator_class }

func (t *Spliterators_IteratorSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_IteratorSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_IteratorSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_IteratorSpliterator_InstanceOf(x any) bool { _, ok := x.(Spliterators_IteratorSpliterator_I); return ok }

func Spliterators_IteratorSpliterator_Cast(x any) Spliterators_IteratorSpliterator_I { if x == nil { return nil }; v, ok := x.(Spliterators_IteratorSpliterator_I); if !ok { panic(ClassCast(x, Spliterators_IteratorSpliterator_class)) }; return v }



type Spliterators_LongArraySpliterator struct{ Object; F_array *LongArray; F_index, F_fence, F_characteristics int32; F_estimatedSize int64 }

func (t *Spliterators_LongArraySpliterator) Is_Spliterator_OfLong() {}

func (t *Spliterators_LongArraySpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_LongArraySpliterator) Is_Spliterator() {}

func (t *Spliterators_LongArraySpliterator) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return t.TrySplit__Spliterator_OfLong() }

func (t *Spliterators_LongArraySpliterator) TryAdvance_O__Z(p0 any) bool { return t.TryAdvance_LongConsumer__Z(LongConsumer_Cast(p0)) }

func (t *Spliterators_LongArraySpliterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_LongConsumer__V(LongConsumer_Cast(p0)) }

func (t *Spliterators_LongArraySpliterator) TrySplit__Spliterator() Spliterator { return t.TrySplit__Spliterator_OfLong() }

func (t *Spliterators_LongArraySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_LongArraySpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfLong_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_LongArraySpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfLong_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_LongArraySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_LongArraySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_LongArraySpliterator) GetClass__Class() *Class { return Spliterators_LongArraySpliterator_class }

func (t *Spliterators_LongArraySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_LongArraySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_LongArraySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_LongArraySpliterator_InstanceOf(x any) bool { _, ok := x.(*Spliterators_LongArraySpliterator); return ok }

func Spliterators_LongArraySpliterator_Cast(x any) *Spliterators_LongArraySpliterator { if x == nil { return nil }; v, ok := x.(*Spliterators_LongArraySpliterator); if !ok { panic(ClassCast(x, Spliterators_LongArraySpliterator_class)) }; return v }



type Spliterators_LongIteratorSpliterator struct{ Object; F_it PrimitiveIterator_OfLong; F_characteristics int32; F_est int64; F_batch int32 }

func (t *Spliterators_LongIteratorSpliterator) Is_Spliterator_OfLong() {}

func (t *Spliterators_LongIteratorSpliterator) Is_Spliterator_OfPrimitive() {}

func (t *Spliterators_LongIteratorSpliterator) Is_Spliterator() {}

const Spliterators_LongIteratorSpliterator_BATCH_UNIT int32 = 1024

const Spliterators_LongIteratorSpliterator_MAX_BATCH int32 = 33554432

func (t *Spliterators_LongIteratorSpliterator) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return t.TrySplit__Spliterator_OfLong() }

func (t *Spliterators_LongIteratorSpliterator) TryAdvance_O__Z(p0 any) bool { return t.TryAdvance_LongConsumer__Z(LongConsumer_Cast(p0)) }

func (t *Spliterators_LongIteratorSpliterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_LongConsumer__V(LongConsumer_Cast(p0)) }

func (t *Spliterators_LongIteratorSpliterator) TrySplit__Spliterator() Spliterator { return t.TrySplit__Spliterator_OfLong() }

func (t *Spliterators_LongIteratorSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Spliterators_LongIteratorSpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfLong_ForEachRemaining_Consumer__V(t, p0) }

func (t *Spliterators_LongIteratorSpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfLong_TryAdvance_Consumer__Z(t, p0) }

func (t *Spliterators_LongIteratorSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Spliterators_LongIteratorSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Spliterators_LongIteratorSpliterator) GetClass__Class() *Class { return Spliterators_LongIteratorSpliterator_class }

func (t *Spliterators_LongIteratorSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Spliterators_LongIteratorSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Spliterators_LongIteratorSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Spliterators_LongIteratorSpliterator_InstanceOf(x any) bool { _, ok := x.(*Spliterators_LongIteratorSpliterator); return ok }

func Spliterators_LongIteratorSpliterator_Cast(x any) *Spliterators_LongIteratorSpliterator { if x == nil { return nil }; v, ok := x.(*Spliterators_LongIteratorSpliterator); if !ok { panic(ClassCast(x, Spliterators_LongIteratorSpliterator_class)) }; return v }
