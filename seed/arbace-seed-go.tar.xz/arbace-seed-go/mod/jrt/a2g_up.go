//line a2g_up.ae:1
package jrt




func Up_ByteArrayOutputStream_OutputStream(p *ByteArrayOutputStream) OutputStream_I { if p == nil { return nil }; return p }

func Up_DataInputStream_DataInput(p *DataInputStream) DataInput { if p == nil { return nil }; return p }

func Up_FileReader_Reader(p *FileReader) Reader_I { if p == nil { return nil }; return p }

func Up_PrintStream_Appendable(p *PrintStream) Appendable { if p == nil { return nil }; return p }

func Up_PrintWriter_Writer(p *PrintWriter) Writer_I { if p == nil { return nil }; return p }

func Up_PrintWriter_Appendable(p *PrintWriter) Appendable { if p == nil { return nil }; return p }

func Up_StringWriter_Writer(p *StringWriter) Writer_I { if p == nil { return nil }; return p }

func Up_StringWriter_Appendable(p *StringWriter) Appendable { if p == nil { return nil }; return p }

func Up_ArithmeticException_Throwable(p *ArithmeticException) Throwable_I { if p == nil { return nil }; return p }

func Up_CharacterData00_CharacterData(p *CharacterData00) CharacterData_I { if p == nil { return nil }; return p }

func Up_CharacterDataLatin1_CharacterData(p *CharacterDataLatin1) CharacterData_I { if p == nil { return nil }; return p }

func Up_ClassNotFoundException_Throwable(p *ClassNotFoundException) Throwable_I { if p == nil { return nil }; return p }

func Up_CloneNotSupportedException_Throwable(p *CloneNotSupportedException) Throwable_I { if p == nil { return nil }; return p }

func Up_Double_Number(p *Double) Number_I { if p == nil { return nil }; return p }

func Up_InterruptedException_Throwable(p *InterruptedException) Throwable_I { if p == nil { return nil }; return p }

func Up_Long_Number(p *Long) Number_I { if p == nil { return nil }; return p }

func Up_NoSuchMethodException_Throwable(p *NoSuchMethodException) Throwable_I { if p == nil { return nil }; return p }

func Up_NumberFormatException_Throwable(p *NumberFormatException) Throwable_I { if p == nil { return nil }; return p }

func Up_ProcessBuilder_NullInputStream_InputStream(p *ProcessBuilder_NullInputStream) InputStream_I { if p == nil { return nil }; return p }

func Up_ProcessBuilder_NullOutputStream_OutputStream(p *ProcessBuilder_NullOutputStream) OutputStream_I { if p == nil { return nil }; return p }

func Up_ProcessHandleImpl_ExitCompletion_CompletableFuture(p *ProcessHandleImpl_ExitCompletion) CompletableFuture_I { if p == nil { return nil }; return p }

func Up_ProcessHandleImpl_Info_ProcessHandle_Info(p *ProcessHandleImpl_Info) ProcessHandle_Info { if p == nil { return nil }; return p }

func Up_ProcessHandleImpl_ProcessHandle(p *ProcessHandleImpl) ProcessHandle { if p == nil { return nil }; return p }

func Up_ProcessImpl_Process(p *ProcessImpl) Process_I { if p == nil { return nil }; return p }

func Up_String_CharSequence(p *String) CharSequence { if p == nil { return nil }; return p }

func Up_StringBuffer_Appendable(p *StringBuffer) Appendable { if p == nil { return nil }; return p }

func Up_StringBuilder_Appendable(p *StringBuilder) Appendable { if p == nil { return nil }; return p }

func Up_StringBuilder_CharSequence(p *StringBuilder) CharSequence { if p == nil { return nil }; return p }

func Up_BigDecimal_Number(p *BigDecimal) Number_I { if p == nil { return nil }; return p }

func Up_BigInteger_Number(p *BigInteger) Number_I { if p == nil { return nil }; return p }

func Up_SignedMutableBigInteger_MutableBigInteger(p *SignedMutableBigInteger) MutableBigInteger_I { if p == nil { return nil }; return p }

func Up_Inet4Address_InetAddress(p *Inet4Address) InetAddress_I { if p == nil { return nil }; return p }

func Up_InetSocketAddress_SocketAddress(p *InetSocketAddress) SocketAddress_I { if p == nil { return nil }; return p }

func Up_MalformedURLException_Throwable(p *MalformedURLException) Throwable_I { if p == nil { return nil }; return p }

func Up_SocketTimeoutException_Throwable(p *SocketTimeoutException) Throwable_I { if p == nil { return nil }; return p }

func Up_URISyntaxException_Throwable(p *URISyntaxException) Throwable_I { if p == nil { return nil }; return p }

func Up_UnknownHostException_Throwable(p *UnknownHostException) Throwable_I { if p == nil { return nil }; return p }

func Up_BufferUnderflowException_Throwable(p *BufferUnderflowException) Throwable_I { if p == nil { return nil }; return p }

func Up_InvalidPathException_Exception(p *InvalidPathException) Exception_I { if p == nil { return nil }; return p }

func Up_StandardCopyOption_CopyOption(p *StandardCopyOption) CopyOption { if p == nil { return nil }; return p }

func Up_StandardOpenOption_OpenOption(p *StandardOpenOption) OpenOption { if p == nil { return nil }; return p }

func Up_DigestException_Throwable(p *DigestException) Throwable_I { if p == nil { return nil }; return p }

func Up_DrbgParameters_Instantiation_SecureRandomParameters(p *DrbgParameters_Instantiation) SecureRandomParameters { if p == nil { return nil }; return p }

func Up_DrbgParameters_NextBytes_SecureRandomParameters(p *DrbgParameters_NextBytes) SecureRandomParameters { if p == nil { return nil }; return p }

func Up_DrbgParameters_Reseed_SecureRandomParameters(p *DrbgParameters_Reseed) SecureRandomParameters { if p == nil { return nil }; return p }

func Up_InvalidAlgorithmParameterException_Throwable(p *InvalidAlgorithmParameterException) Throwable_I { if p == nil { return nil }; return p }

func Up_InvalidKeyException_Throwable(p *InvalidKeyException) Throwable_I { if p == nil { return nil }; return p }

func Up_NoSuchAlgorithmException_Exception(p *NoSuchAlgorithmException) Exception_I { if p == nil { return nil }; return p }

func Up_NoSuchAlgorithmException_Throwable(p *NoSuchAlgorithmException) Throwable_I { if p == nil { return nil }; return p }

func Up_ProviderException_Throwable(p *ProviderException) Throwable_I { if p == nil { return nil }; return p }

func Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(p *CharacterIteratorFieldDelegate) Format_FieldDelegate { if p == nil { return nil }; return p }

func Up_DateFormat_Field_Format_Field(p *DateFormat_Field) Format_Field_I { if p == nil { return nil }; return p }

func Up_DecimalFormat_NumberFormat(p *DecimalFormat) NumberFormat_I { if p == nil { return nil }; return p }

func Up_ListFormat_Format(p *ListFormat) Format_I { if p == nil { return nil }; return p }

func Up_MessageFormat_Field_AttributedCharacterIterator_Attribute(p *MessageFormat_Field) AttributedCharacterIterator_Attribute_I { if p == nil { return nil }; return p }

func Up_NumberFormat_Field_Format_Field(p *NumberFormat_Field) Format_Field_I { if p == nil { return nil }; return p }

func Up_ParseException_Throwable(p *ParseException) Throwable_I { if p == nil { return nil }; return p }

func Up_SimpleDateFormat_DateFormat(p *SimpleDateFormat) DateFormat_I { if p == nil { return nil }; return p }

func Up_Clock_SystemClock_Clock(p *Clock_SystemClock) Clock_I { if p == nil { return nil }; return p }

func Up_Clock_SystemInstantSource_InstantSource(p *Clock_SystemInstantSource) InstantSource { if p == nil { return nil }; return p }

func Up_Duration_TemporalAmount(p *Duration) TemporalAmount { if p == nil { return nil }; return p }

func Up_Instant_Temporal(p *Instant) Temporal { if p == nil { return nil }; return p }

func Up_Instant_TemporalAccessor(p *Instant) TemporalAccessor { if p == nil { return nil }; return p }

func Up_LocalDate_ChronoLocalDate(p *LocalDate) ChronoLocalDate { if p == nil { return nil }; return p }

func Up_LocalDate_Temporal(p *LocalDate) Temporal { if p == nil { return nil }; return p }

func Up_LocalDate_TemporalAccessor(p *LocalDate) TemporalAccessor { if p == nil { return nil }; return p }

func Up_LocalDate_TemporalAdjuster(p *LocalDate) TemporalAdjuster { if p == nil { return nil }; return p }

func Up_LocalDateTime_ChronoLocalDateTime(p *LocalDateTime) ChronoLocalDateTime { if p == nil { return nil }; return p }

func Up_LocalDateTime_Temporal(p *LocalDateTime) Temporal { if p == nil { return nil }; return p }

func Up_LocalDateTime_TemporalAccessor(p *LocalDateTime) TemporalAccessor { if p == nil { return nil }; return p }

func Up_LocalTime_Temporal(p *LocalTime) Temporal { if p == nil { return nil }; return p }

func Up_LocalTime_TemporalAccessor(p *LocalTime) TemporalAccessor { if p == nil { return nil }; return p }

func Up_OffsetDateTime_Temporal(p *OffsetDateTime) Temporal { if p == nil { return nil }; return p }

func Up_OffsetTime_Temporal(p *OffsetTime) Temporal { if p == nil { return nil }; return p }

func Up_Period_ChronoPeriod(p *Period) ChronoPeriod { if p == nil { return nil }; return p }

func Up_Period_TemporalAmount(p *Period) TemporalAmount { if p == nil { return nil }; return p }

func Up_Year_Temporal(p *Year) Temporal { if p == nil { return nil }; return p }

func Up_YearMonth_Temporal(p *YearMonth) Temporal { if p == nil { return nil }; return p }

func Up_ZoneOffset_ZoneId(p *ZoneOffset) ZoneId_I { if p == nil { return nil }; return p }

func Up_ZoneRegion_ZoneId(p *ZoneRegion) ZoneId_I { if p == nil { return nil }; return p }

func Up_ZonedDateTime_ChronoZonedDateTime(p *ZonedDateTime) ChronoZonedDateTime { if p == nil { return nil }; return p }

func Up_ZonedDateTime_Temporal(p *ZonedDateTime) Temporal { if p == nil { return nil }; return p }

func Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(p *ChronoLocalDateTimeImpl) ChronoLocalDateTime { if p == nil { return nil }; return p }

func Up_ChronoLocalDateTimeImpl_Temporal(p *ChronoLocalDateTimeImpl) Temporal { if p == nil { return nil }; return p }

func Up_ChronoLocalDateTimeImpl_TemporalAccessor(p *ChronoLocalDateTimeImpl) TemporalAccessor { if p == nil { return nil }; return p }

func Up_ChronoLocalDateTimeImpl_TemporalAdjuster(p *ChronoLocalDateTimeImpl) TemporalAdjuster { if p == nil { return nil }; return p }

func Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(p *ChronoZonedDateTimeImpl) ChronoZonedDateTime { if p == nil { return nil }; return p }

func Up_IsoChronology_Chronology(p *IsoChronology) Chronology { if p == nil { return nil }; return p }

func Up_IsoEra_Era(p *IsoEra) Era { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_CompositePrinterParser_DateTimeFormatterBuilder_DateTimePrinterParser(p *DateTimeFormatterBuilder_CompositePrinterParser) DateTimeFormatterBuilder_DateTimePrinterParser { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_FractionPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(p *DateTimeFormatterBuilder_FractionPrinterParser) DateTimeFormatterBuilder_NumberPrinterParser_I { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_NanosPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(p *DateTimeFormatterBuilder_NanosPrinterParser) DateTimeFormatterBuilder_NumberPrinterParser_I { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_OffsetIdPrinterParser_DateTimeFormatterBuilder_DateTimePrinterParser(p *DateTimeFormatterBuilder_OffsetIdPrinterParser) DateTimeFormatterBuilder_DateTimePrinterParser { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_PrefixTree_CI_DateTimeFormatterBuilder_PrefixTree(p *DateTimeFormatterBuilder_PrefixTree_CI) DateTimeFormatterBuilder_PrefixTree_I { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_ReducedPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(p *DateTimeFormatterBuilder_ReducedPrinterParser) DateTimeFormatterBuilder_NumberPrinterParser_I { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_SettingsParser_DateTimeFormatterBuilder_DateTimePrinterParser(p *DateTimeFormatterBuilder_SettingsParser) DateTimeFormatterBuilder_DateTimePrinterParser { if p == nil { return nil }; return p }

func Up_DateTimeFormatterBuilder_WeekBasedFieldPrinterParser_DateTimeFormatterBuilder_NumberPrinterParser(p *DateTimeFormatterBuilder_WeekBasedFieldPrinterParser) DateTimeFormatterBuilder_NumberPrinterParser_I { if p == nil { return nil }; return p }

func Up_DateTimeParseException_Throwable(p *DateTimeParseException) Throwable_I { if p == nil { return nil }; return p }

func Up_FormatStyle_Serializable(p *FormatStyle) Serializable { if p == nil { return nil }; return p }

func Up_Parsed_TemporalAccessor(p *Parsed) TemporalAccessor { if p == nil { return nil }; return p }

func Up_ChronoField_TemporalField(p *ChronoField) TemporalField { if p == nil { return nil }; return p }

func Up_ChronoUnit_Enum(p *ChronoUnit) Enum_I { if p == nil { return nil }; return p }

func Up_ChronoUnit_TemporalUnit(p *ChronoUnit) TemporalUnit { if p == nil { return nil }; return p }

func Up_IsoFields_Unit_TemporalUnit(p *IsoFields_Unit) TemporalUnit { if p == nil { return nil }; return p }

func Up_JulianFields_Field_TemporalField(p *JulianFields_Field) TemporalField { if p == nil { return nil }; return p }

func Up_WeekFields_ComputedDayOfField_TemporalField(p *WeekFields_ComputedDayOfField) TemporalField { if p == nil { return nil }; return p }

func Up_ZoneOffsetTransition_Serializable(p *ZoneOffsetTransition) Serializable { if p == nil { return nil }; return p }

func Up_ZoneOffsetTransitionRule_Serializable(p *ZoneOffsetTransitionRule) Serializable { if p == nil { return nil }; return p }

func Up_ZoneRules_Serializable(p *ZoneRules) Serializable { if p == nil { return nil }; return p }

func Up_ZoneRulesException_Throwable(p *ZoneRulesException) Throwable_I { if p == nil { return nil }; return p }

func Up_AbstractList_RandomAccessSubList_AbstractList_SubList(p *AbstractList_RandomAccessSubList) AbstractList_SubList_I { if p == nil { return nil }; return p }

func Up_AbstractMap_SimpleImmutableEntry_Map_Entry(p *AbstractMap_SimpleImmutableEntry) Map_Entry { if p == nil { return nil }; return p }

func Up_ArrayDeque_DeqSpliterator_Spliterator(p *ArrayDeque_DeqSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ArrayList_ArrayListSpliterator_Spliterator(p *ArrayList_ArrayListSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ArrayList_Collection(p *ArrayList) Collection { if p == nil { return nil }; return p }

func Up_ArrayList_List(p *ArrayList) List { if p == nil { return nil }; return p }

func Up_ArrayPrefixHelpers_CumulateTask_CountedCompleter(p *ArrayPrefixHelpers_CumulateTask) CountedCompleter_I { if p == nil { return nil }; return p }

func Up_ArrayPrefixHelpers_DoubleCumulateTask_CountedCompleter(p *ArrayPrefixHelpers_DoubleCumulateTask) CountedCompleter_I { if p == nil { return nil }; return p }

func Up_ArrayPrefixHelpers_IntCumulateTask_CountedCompleter(p *ArrayPrefixHelpers_IntCumulateTask) CountedCompleter_I { if p == nil { return nil }; return p }

func Up_ArrayPrefixHelpers_LongCumulateTask_CountedCompleter(p *ArrayPrefixHelpers_LongCumulateTask) CountedCompleter_I { if p == nil { return nil }; return p }

func Up_Arrays_NaturalOrder_Comparator(p *Arrays_NaturalOrder) Comparator { if p == nil { return nil }; return p }

func Up_ArraysParallelSortHelpers_Relay_CountedCompleter(p *ArraysParallelSortHelpers_Relay) CountedCompleter_I { if p == nil { return nil }; return p }

func Up_Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry(p *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) Map_Entry { if p == nil { return nil }; return p }

func Up_Collections_EmptyEnumeration_Enumeration(p *Collections_EmptyEnumeration) Enumeration { if p == nil { return nil }; return p }

func Up_Collections_EmptyListIterator_ListIterator(p *Collections_EmptyListIterator) ListIterator { if p == nil { return nil }; return p }

func Up_Collections_ReverseComparator_Comparator(p *Collections_ReverseComparator) Comparator { if p == nil { return nil }; return p }

func Up_Collections_UnmodifiableNavigableMap_EmptyNavigableMap_NavigableMap(p *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) NavigableMap { if p == nil { return nil }; return p }

func Up_Collections_UnmodifiableNavigableMap_EmptyNavigableMap_SortedMap(p *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) SortedMap { if p == nil { return nil }; return p }

func Up_Comparators_NaturalOrderComparator_Comparator(p *Comparators_NaturalOrderComparator) Comparator { if p == nil { return nil }; return p }

func Up_Currency_CurrencyNameGetter_LocaleServiceProviderPool_LocalizedObjectGetter(p *Currency_CurrencyNameGetter) LocaleServiceProviderPool_LocalizedObjectGetter { if p == nil { return nil }; return p }

func Up_EnumMap_EntryIterator_Entry_Map_Entry(p *EnumMap_EntryIterator_Entry) Map_Entry { if p == nil { return nil }; return p }

func Up_HashMap_EntrySpliterator_Spliterator(p *HashMap_EntrySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_HashMap_KeySpliterator_Spliterator(p *HashMap_KeySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_HashMap_TreeNode_HashMap_Node(p *HashMap_TreeNode) HashMap_Node_I { if p == nil { return nil }; return p }

func Up_HashMap_TreeNode_LinkedHashMap_Entry(p *HashMap_TreeNode) LinkedHashMap_Entry_I { if p == nil { return nil }; return p }

func Up_HashMap_ValueSpliterator_Spliterator(p *HashMap_ValueSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_IdentityHashMap_EntryIterator_Entry_Map_Entry(p *IdentityHashMap_EntryIterator_Entry) Map_Entry { if p == nil { return nil }; return p }

func Up_IdentityHashMap_EntrySpliterator_Spliterator(p *IdentityHashMap_EntrySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_IdentityHashMap_KeySpliterator_Spliterator(p *IdentityHashMap_KeySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_IdentityHashMap_ValueSpliterator_Spliterator(p *IdentityHashMap_ValueSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ImmutableCollections_ListN_List(p *ImmutableCollections_ListN) List { if p == nil { return nil }; return p }

func Up_ImmutableCollections_MapN_Map(p *ImmutableCollections_MapN) Map { if p == nil { return nil }; return p }

func Up_ImmutableCollections_SetN_Set(p *ImmutableCollections_SetN) Set { if p == nil { return nil }; return p }

func Up_ImmutableCollections_SubList_List(p *ImmutableCollections_SubList) List { if p == nil { return nil }; return p }

func Up_JumboEnumSet_EnumSet(p *JumboEnumSet) EnumSet_I { if p == nil { return nil }; return p }

func Up_LinkedHashMap_Map(p *LinkedHashMap) Map { if p == nil { return nil }; return p }

func Up_LinkedHashMap_SequencedMap(p *LinkedHashMap) SequencedMap { if p == nil { return nil }; return p }

func Up_LinkedHashSet_Collection(p *LinkedHashSet) Collection { if p == nil { return nil }; return p }

func Up_LinkedHashSet_SequencedSet(p *LinkedHashSet) SequencedSet { if p == nil { return nil }; return p }

func Up_Locale_LocaleNameGetter_LocaleServiceProviderPool_LocalizedObjectGetter(p *Locale_LocaleNameGetter) LocaleServiceProviderPool_LocalizedObjectGetter { if p == nil { return nil }; return p }

func Up_MissingResourceException_Throwable(p *MissingResourceException) Throwable_I { if p == nil { return nil }; return p }

func Up_PriorityQueue_PriorityQueueSpliterator_Spliterator(p *PriorityQueue_PriorityQueueSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_PriorityQueue_Collection(p *PriorityQueue) Collection { if p == nil { return nil }; return p }

func Up_SimpleTimeZone_TimeZone(p *SimpleTimeZone) TimeZone_I { if p == nil { return nil }; return p }

func Up_Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer_DoubleConsumer(p *Spliterators_AbstractDoubleSpliterator_HoldingDoubleConsumer) DoubleConsumer { if p == nil { return nil }; return p }

func Up_Spliterators_AbstractIntSpliterator_HoldingIntConsumer_IntConsumer(p *Spliterators_AbstractIntSpliterator_HoldingIntConsumer) IntConsumer { if p == nil { return nil }; return p }

func Up_Spliterators_AbstractLongSpliterator_HoldingLongConsumer_LongConsumer(p *Spliterators_AbstractLongSpliterator_HoldingLongConsumer) LongConsumer { if p == nil { return nil }; return p }

func Up_Spliterators_AbstractSpliterator_HoldingConsumer_Consumer(p *Spliterators_AbstractSpliterator_HoldingConsumer) Consumer { if p == nil { return nil }; return p }

func Up_SplittableRandom_RandomGenerator_SplittableGenerator(p *SplittableRandom) RandomGenerator_SplittableGenerator { if p == nil { return nil }; return p }

func Up_TreeMap_AscendingSubMap_TreeMap_NavigableSubMap(p *TreeMap_AscendingSubMap) TreeMap_NavigableSubMap_I { if p == nil { return nil }; return p }

func Up_TreeMap_DescendingKeySpliterator_Spliterator(p *TreeMap_DescendingKeySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_TreeMap_DescendingSubMap_TreeMap_NavigableSubMap(p *TreeMap_DescendingSubMap) TreeMap_NavigableSubMap_I { if p == nil { return nil }; return p }

func Up_TreeMap_Entry_Map_Entry(p *TreeMap_Entry) Map_Entry { if p == nil { return nil }; return p }

func Up_TreeMap_EntrySet_Set(p *TreeMap_EntrySet) Set { if p == nil { return nil }; return p }

func Up_TreeMap_EntrySpliterator_Spliterator(p *TreeMap_EntrySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_TreeMap_KeySet_NavigableSet(p *TreeMap_KeySet) NavigableSet { if p == nil { return nil }; return p }

func Up_TreeMap_KeySpliterator_Spliterator(p *TreeMap_KeySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_TreeMap_ValueSpliterator_Spliterator(p *TreeMap_ValueSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_TreeMap_NavigableMap(p *TreeMap) NavigableMap { if p == nil { return nil }; return p }

func Up_WeakHashMap_Entry_Map_Entry(p *WeakHashMap_Entry) Map_Entry { if p == nil { return nil }; return p }

func Up_WeakHashMap_EntrySpliterator_Spliterator(p *WeakHashMap_EntrySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_WeakHashMap_KeySpliterator_Spliterator(p *WeakHashMap_KeySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_WeakHashMap_ValueSpliterator_Spliterator(p *WeakHashMap_ValueSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_CancellationException_Throwable(p *CancellationException) Throwable_I { if p == nil { return nil }; return p }

func Up_CompletableFuture_MinimalStage_CompletableFuture(p *CompletableFuture_MinimalStage) CompletableFuture_I { if p == nil { return nil }; return p }

func Up_CompletableFuture_MinimalStage_CompletionStage(p *CompletableFuture_MinimalStage) CompletionStage { if p == nil { return nil }; return p }

func Up_CompletableFuture_Signaller_CompletableFuture_Completion(p *CompletableFuture_Signaller) CompletableFuture_Completion_I { if p == nil { return nil }; return p }

func Up_CompletableFuture_Signaller_ForkJoinPool_ManagedBlocker(p *CompletableFuture_Signaller) ForkJoinPool_ManagedBlocker { if p == nil { return nil }; return p }

func Up_CompletableFuture_Timeout_Runnable(p *CompletableFuture_Timeout) Runnable { if p == nil { return nil }; return p }

func Up_CompletionException_Throwable(p *CompletionException) Throwable_I { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_EntrySetView_Set(p *ConcurrentHashMap_EntrySetView) Set { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_EntrySpliterator_Spliterator(p *ConcurrentHashMap_EntrySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_ForwardingNode_ConcurrentHashMap_Node(p *ConcurrentHashMap_ForwardingNode) ConcurrentHashMap_Node_I { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_KeySetView_Collection(p *ConcurrentHashMap_KeySetView) Collection { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_KeySetView_Set(p *ConcurrentHashMap_KeySetView) Set { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_KeySpliterator_Spliterator(p *ConcurrentHashMap_KeySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_TreeBin_ConcurrentHashMap_Node(p *ConcurrentHashMap_TreeBin) ConcurrentHashMap_Node_I { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_TreeNode_ConcurrentHashMap_Node(p *ConcurrentHashMap_TreeNode) ConcurrentHashMap_Node_I { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_ValueSpliterator_Spliterator(p *ConcurrentHashMap_ValueSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_ValuesView_Collection(p *ConcurrentHashMap_ValuesView) Collection { if p == nil { return nil }; return p }

func Up_ConcurrentHashMap_Map(p *ConcurrentHashMap) Map { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_EntrySet_Set(p *ConcurrentSkipListMap_EntrySet) Set { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_EntrySpliterator_Spliterator(p *ConcurrentSkipListMap_EntrySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_KeySet_NavigableSet(p *ConcurrentSkipListMap_KeySet) NavigableSet { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_KeySpliterator_Spliterator(p *ConcurrentSkipListMap_KeySpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_SubMap_NavigableMap(p *ConcurrentSkipListMap_SubMap) NavigableMap { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_SubMap_SortedMap(p *ConcurrentSkipListMap_SubMap) SortedMap { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_SubMap_ConcurrentNavigableMap(p *ConcurrentSkipListMap_SubMap) ConcurrentNavigableMap { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_ValueSpliterator_Spliterator(p *ConcurrentSkipListMap_ValueSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ConcurrentSkipListMap_Values_Collection(p *ConcurrentSkipListMap_Values) Collection { if p == nil { return nil }; return p }

func Up_CopyOnWriteArrayList_Collection(p *CopyOnWriteArrayList) Collection { if p == nil { return nil }; return p }

func Up_CopyOnWriteArrayList_List(p *CopyOnWriteArrayList) List { if p == nil { return nil }; return p }

func Up_ExecutionException_Throwable(p *ExecutionException) Throwable_I { if p == nil { return nil }; return p }

func Up_ForkJoinPool_Executor(p *ForkJoinPool) Executor { if p == nil { return nil }; return p }

func Up_Phaser_QNode_ForkJoinPool_ManagedBlocker(p *Phaser_QNode) ForkJoinPool_ManagedBlocker { if p == nil { return nil }; return p }

func Up_PriorityBlockingQueue_PBQSpliterator_Spliterator(p *PriorityBlockingQueue_PBQSpliterator) Spliterator { if p == nil { return nil }; return p }

func Up_ScheduledThreadPoolExecutor_ScheduledFutureTask_RunnableScheduledFuture(p *ScheduledThreadPoolExecutor_ScheduledFutureTask) RunnableScheduledFuture { if p == nil { return nil }; return p }

func Up_SubmissionPublisher_ConsumerTask_Runnable(p *SubmissionPublisher_ConsumerTask) Runnable { if p == nil { return nil }; return p }

func Up_ThreadLocalRandom_Random(p *ThreadLocalRandom) Random_I { if p == nil { return nil }; return p }

func Up_TimeoutException_Throwable(p *TimeoutException) Throwable_I { if p == nil { return nil }; return p }

func Up_AbstractQueuedLongSynchronizer_ConditionNode_ForkJoinPool_ManagedBlocker(p *AbstractQueuedLongSynchronizer_ConditionNode) ForkJoinPool_ManagedBlocker { if p == nil { return nil }; return p }

func Up_AbstractQueuedLongSynchronizer_ConditionNode_AbstractQueuedLongSynchronizer_Node(p *AbstractQueuedLongSynchronizer_ConditionNode) AbstractQueuedLongSynchronizer_Node_I { if p == nil { return nil }; return p }

func Up_StampedLock_ReadLockView_Lock(p *StampedLock_ReadLockView) Lock { if p == nil { return nil }; return p }

func Up_StampedLock_ReadWriteLockView_ReadWriteLock(p *StampedLock_ReadWriteLockView) ReadWriteLock { if p == nil { return nil }; return p }

func Up_StampedLock_ReaderNode_StampedLock_Node(p *StampedLock_ReaderNode) StampedLock_Node_I { if p == nil { return nil }; return p }

func Up_StampedLock_WriteLockView_Lock(p *StampedLock_WriteLockView) Lock { if p == nil { return nil }; return p }

func Up_StampedLock_WriterNode_StampedLock_Node(p *StampedLock_WriterNode) StampedLock_Node_I { if p == nil { return nil }; return p }

func Up_Pattern_BitClass_Pattern_CharPredicate(p *Pattern_BitClass) Pattern_CharPredicate { if p == nil { return nil }; return p }

func Up_Pattern_BmpCharProperty_Pattern_CharProperty(p *Pattern_BmpCharProperty) Pattern_CharProperty_I { if p == nil { return nil }; return p }

func Up_Pattern_Branch_Pattern_Node(p *Pattern_Branch) Pattern_Node_I { if p == nil { return nil }; return p }

func Up_Pattern_GroupHead_Pattern_Node(p *Pattern_GroupHead) Pattern_Node_I { if p == nil { return nil }; return p }

func Up_Pattern_LookBehindEndNode_Pattern_Node(p *Pattern_LookBehindEndNode) Pattern_Node_I { if p == nil { return nil }; return p }

func Up_Pattern_Prolog_Pattern_Node(p *Pattern_Prolog) Pattern_Node_I { if p == nil { return nil }; return p }

func Up_PatternSyntaxException_Throwable(p *PatternSyntaxException) Throwable_I { if p == nil { return nil }; return p }

func Up_Collector_Characteristics_Enum(p *Collector_Characteristics) Enum_I { if p == nil { return nil }; return p }

func Up_FindOps_FindTask_AbstractShortCircuitTask(p *FindOps_FindTask) AbstractShortCircuitTask_I { if p == nil { return nil }; return p }

func Up_FindOps_FindTask_AbstractTask(p *FindOps_FindTask) AbstractTask_I { if p == nil { return nil }; return p }

func Up_ForEachOps_ForEachOrderedTask_CountedCompleter(p *ForEachOps_ForEachOrderedTask) CountedCompleter_I { if p == nil { return nil }; return p }

func Up_ForEachOps_ForEachTask_CountedCompleter(p *ForEachOps_ForEachTask) CountedCompleter_I { if p == nil { return nil }; return p }

func Up_GathererOp_NodeBuilder_Builder_Node(p *GathererOp_NodeBuilder_Builder) Node { if p == nil { return nil }; return p }

func Up_GathererOp_AbstractPipeline(p *GathererOp) AbstractPipeline_I { if p == nil { return nil }; return p }

func Up_Gatherers_Composite_Gatherer(p *Gatherers_Composite) Gatherer { if p == nil { return nil }; return p }

func Up_MatchOps_MatchTask_AbstractShortCircuitTask(p *MatchOps_MatchTask) AbstractShortCircuitTask_I { if p == nil { return nil }; return p }

func Up_MatchOps_MatchTask_AbstractTask(p *MatchOps_MatchTask) AbstractTask_I { if p == nil { return nil }; return p }

func Up_Nodes_SizedCollectorTask_OfDouble_Nodes_SizedCollectorTask(p *Nodes_SizedCollectorTask_OfDouble) Nodes_SizedCollectorTask_I { if p == nil { return nil }; return p }

func Up_Nodes_SizedCollectorTask_OfInt_Nodes_SizedCollectorTask(p *Nodes_SizedCollectorTask_OfInt) Nodes_SizedCollectorTask_I { if p == nil { return nil }; return p }

func Up_Nodes_SizedCollectorTask_OfLong_Nodes_SizedCollectorTask(p *Nodes_SizedCollectorTask_OfLong) Nodes_SizedCollectorTask_I { if p == nil { return nil }; return p }

func Up_Nodes_SizedCollectorTask_OfRef_Nodes_SizedCollectorTask(p *Nodes_SizedCollectorTask_OfRef) Nodes_SizedCollectorTask_I { if p == nil { return nil }; return p }

func Up_Nodes_ToArrayTask_OfRef_Nodes_ToArrayTask(p *Nodes_ToArrayTask_OfRef) Nodes_ToArrayTask_I { if p == nil { return nil }; return p }

func Up_ReduceOps_10ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_10ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_11ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_11ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_12ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_12ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_13ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_13ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_1ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_1ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_2ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_2ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_3ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_3ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_4ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_4ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_5ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_5ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_6ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_6ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_7ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_7ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_8ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_8ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_9ReducingSink_ReduceOps_AccumulatingSink(p *ReduceOps_9ReducingSink) ReduceOps_AccumulatingSink { if p == nil { return nil }; return p }

func Up_ReduceOps_ReduceTask_AbstractTask(p *ReduceOps_ReduceTask) AbstractTask_I { if p == nil { return nil }; return p }

func Up_SliceOps_SliceTask_AbstractShortCircuitTask(p *SliceOps_SliceTask) AbstractShortCircuitTask_I { if p == nil { return nil }; return p }

func Up_SliceOps_SliceTask_AbstractTask(p *SliceOps_SliceTask) AbstractTask_I { if p == nil { return nil }; return p }

func Up_SpinedBuffer_OfDouble_1Splitr_Spliterator_OfPrimitive(p *SpinedBuffer_OfDouble_1Splitr) Spliterator_OfPrimitive { if p == nil { return nil }; return p }

func Up_SpinedBuffer_OfInt_1Splitr_Spliterator_OfPrimitive(p *SpinedBuffer_OfInt_1Splitr) Spliterator_OfPrimitive { if p == nil { return nil }; return p }

func Up_SpinedBuffer_OfLong_1Splitr_Spliterator_OfPrimitive(p *SpinedBuffer_OfLong_1Splitr) Spliterator_OfPrimitive { if p == nil { return nil }; return p }

func Up_StreamSpliterators_ArrayBuffer_OfDouble_StreamSpliterators_ArrayBuffer_OfPrimitive(p *StreamSpliterators_ArrayBuffer_OfDouble) StreamSpliterators_ArrayBuffer_OfPrimitive_I { if p == nil { return nil }; return p }

func Up_StreamSpliterators_ArrayBuffer_OfInt_StreamSpliterators_ArrayBuffer_OfPrimitive(p *StreamSpliterators_ArrayBuffer_OfInt) StreamSpliterators_ArrayBuffer_OfPrimitive_I { if p == nil { return nil }; return p }

func Up_StreamSpliterators_ArrayBuffer_OfLong_StreamSpliterators_ArrayBuffer_OfPrimitive(p *StreamSpliterators_ArrayBuffer_OfLong) StreamSpliterators_ArrayBuffer_OfPrimitive_I { if p == nil { return nil }; return p }

func Up_StreamSpliterators_ArrayBuffer_OfRef_Consumer(p *StreamSpliterators_ArrayBuffer_OfRef) Consumer { if p == nil { return nil }; return p }

func Up_StreamSpliterators_UnorderedSliceSpliterator_OfDouble_StreamSpliterators_UnorderedSliceSpliterator_OfPrimitive(p *StreamSpliterators_UnorderedSliceSpliterator_OfDouble) StreamSpliterators_UnorderedSliceSpliterator_OfPrimitive_I { if p == nil { return nil }; return p }

func Up_StreamSpliterators_UnorderedSliceSpliterator_OfInt_StreamSpliterators_UnorderedSliceSpliterator_OfPrimitive(p *StreamSpliterators_UnorderedSliceSpliterator_OfInt) StreamSpliterators_UnorderedSliceSpliterator_OfPrimitive_I { if p == nil { return nil }; return p }

func Up_StreamSpliterators_UnorderedSliceSpliterator_OfLong_StreamSpliterators_UnorderedSliceSpliterator_OfPrimitive(p *StreamSpliterators_UnorderedSliceSpliterator_OfLong) StreamSpliterators_UnorderedSliceSpliterator_OfPrimitive_I { if p == nil { return nil }; return p }

func Up_StreamSpliterators_UnorderedSliceSpliterator_OfRef_StreamSpliterators_UnorderedSliceSpliterator(p *StreamSpliterators_UnorderedSliceSpliterator_OfRef) StreamSpliterators_UnorderedSliceSpliterator_I { if p == nil { return nil }; return p }

func Up_StreamSpliterators_WrappingSpliterator_StreamSpliterators_AbstractWrappingSpliterator(p *StreamSpliterators_WrappingSpliterator) StreamSpliterators_AbstractWrappingSpliterator_I { if p == nil { return nil }; return p }

func Up_WhileOps_DropWhileTask_AbstractTask(p *WhileOps_DropWhileTask) AbstractTask_I { if p == nil { return nil }; return p }

func Up_WhileOps_TakeWhileTask_AbstractShortCircuitTask(p *WhileOps_TakeWhileTask) AbstractShortCircuitTask_I { if p == nil { return nil }; return p }

func Up_WhileOps_TakeWhileTask_AbstractTask(p *WhileOps_TakeWhileTask) AbstractTask_I { if p == nil { return nil }; return p }

func Up_WhileOps_UnorderedWhileSpliterator_OfRef_Dropping_WhileOps_UnorderedWhileSpliterator_OfRef(p *WhileOps_UnorderedWhileSpliterator_OfRef_Dropping) WhileOps_UnorderedWhileSpliterator_OfRef_I { if p == nil { return nil }; return p }

func Up_WhileOps_UnorderedWhileSpliterator_OfRef_Taking_WhileOps_UnorderedWhileSpliterator_OfRef(p *WhileOps_UnorderedWhileSpliterator_OfRef_Taking) WhileOps_UnorderedWhileSpliterator_OfRef_I { if p == nil { return nil }; return p }

func Up_CharacterIteratorWrapper_UCharacterIterator(p *CharacterIteratorWrapper) UCharacterIterator_I { if p == nil { return nil }; return p }

func Up_Norm2AllModes_ComposeNormalizer2_Normalizer2(p *Norm2AllModes_ComposeNormalizer2) Normalizer2_I { if p == nil { return nil }; return p }

func Up_Norm2AllModes_DecomposeNormalizer2_Normalizer2(p *Norm2AllModes_DecomposeNormalizer2) Normalizer2_I { if p == nil { return nil }; return p }

func Up_Norm2AllModes_NoopNormalizer2_Normalizer2(p *Norm2AllModes_NoopNormalizer2) Normalizer2_I { if p == nil { return nil }; return p }

func Up_NormalizerImpl_IsAcceptable_ICUBinary_Authenticate(p *NormalizerImpl_IsAcceptable) ICUBinary_Authenticate { if p == nil { return nil }; return p }

func Up_NormalizerImpl_ReorderingBuffer_Appendable(p *NormalizerImpl_ReorderingBuffer) Appendable { if p == nil { return nil }; return p }

func Up_ReplaceableUCharacterIterator_UCharacterIterator(p *ReplaceableUCharacterIterator) UCharacterIterator_I { if p == nil { return nil }; return p }

func Up_ClassPathResources_EmbeddedHandler_URLStreamHandler(p *ClassPathResources_EmbeddedHandler) URLStreamHandler_I { if p == nil { return nil }; return p }

func Up_Delays_DelayedTask_Future(p *Delays_DelayedTask) Future { if p == nil { return nil }; return p }

func Up_HostPath_Path(p *HostPath) Path { if p == nil { return nil }; return p }

func Up_HostRandom_InputStream(p *HostRandom) InputStream_I { if p == nil { return nil }; return p }

func Up_HostSocketImpl_SocketImpl(p *HostSocketImpl) SocketImpl_I { if p == nil { return nil }; return p }

func Up_ThreadPerTaskExecutor_ExecutorService(p *ThreadPerTaskExecutor) ExecutorService { if p == nil { return nil }; return p }

func Up_LazyConstantImpl_LazyConstant(p *LazyConstantImpl) LazyConstant { if p == nil { return nil }; return p }

func Up_NullableKeyValueHolder_Map_Entry(p *NullableKeyValueHolder) Map_Entry { if p == nil { return nil }; return p }

func Up_ISO_8859_1_Charset(p *ISO_8859_1) Charset_I { if p == nil { return nil }; return p }

func Up_UTF_8_Charset(p *UTF_8) Charset_I { if p == nil { return nil }; return p }

func Up_MoreDrbgParameters_SecureRandomParameters(p *MoreDrbgParameters) SecureRandomParameters { if p == nil { return nil }; return p }

func Up_PropertyExpander_ExpandException_Throwable(p *PropertyExpander_ExpandException) Throwable_I { if p == nil { return nil }; return p }

func Up_Gregorian_Date_CalendarDate(p *Gregorian_Date) CalendarDate_I { if p == nil { return nil }; return p }

func Up_Gregorian_BaseCalendar(p *Gregorian) BaseCalendar_I { if p == nil { return nil }; return p }

func Up_Gregorian_CalendarSystem(p *Gregorian) CalendarSystem_I { if p == nil { return nil }; return p }

func Up_ZoneInfo_TimeZone(p *ZoneInfo) TimeZone_I { if p == nil { return nil }; return p }

func Up_UnicodeLocaleExtension_Extension(p *UnicodeLocaleExtension) Extension_I { if p == nil { return nil }; return p }

func Up_BreakIteratorProviderImpl_CharacterIteratorCharSequence_CharSequence(p *BreakIteratorProviderImpl_CharacterIteratorCharSequence) CharSequence { if p == nil { return nil }; return p }

func Up_CalendarDataUtility_LengthBasedComparator_Comparator(p *CalendarDataUtility_LengthBasedComparator) Comparator { if p == nil { return nil }; return p }

func Up_JavaTimeDateTimePatternImpl_JavaTimeDateTimePatternProvider(p *JavaTimeDateTimePatternImpl) JavaTimeDateTimePatternProvider_I { if p == nil { return nil }; return p }
