//line java_util_AbstractSet.ae:1
package jrt








func (t *AbstractSet) Ctor(this AbstractSet_I) { t.AbstractCollection.Ctor(this) }

func (t *AbstractSet) Impl_Equals_O__Z(this AbstractSet_I, o any) bool {
	if any(o) == any(this) { return true } else { if !Set_InstanceOf(o) { return false } else {



		var c Collection = Collection_Cast(o)
		if !(c.Size__I() == this.Size__I()) { return false } else {

			var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
				tmp1 = this.ContainsAll_Collection__Z(c); return nil }()
//line :20:1
			if tmp2 != nil { if ClassCastException_InstanceOf(tmp2) || NullPointerException_InstanceOf(tmp2) { var unused RuntimeException_I = RuntimeException_Cast(tmp2); _ = unused; tmp1 = false } else { panic(tmp2) } }; return tmp1
		}
	}
	} }
func (t *AbstractSet) Impl_HashCode__I(this AbstractSet_I) int32 {
	var h int32 = 0; var i Iterator = this.Iterator__Iterator()

L1: for { if i.HasNext__Z() {
	var obj any = i.Next__O(); if !(obj == nil) { h = h + HashCode(obj) }
//line :27:1
	continue L1 }; break L1 }
//line :25:1
	return h
}




func (t *AbstractSet) Impl_RemoveAll_Collection__Z(this AbstractSet_I, c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false
	if this.Size__I() > c.Size__I() {
		var i_101732 Iterator = c.Iterator__Iterator(); for i_101732.HasNext__Z() { var e any = i_101732.Next__O(); var tmp1 bool; var a_1 bool = modified; var b_2 bool = this.Remove_O__Z(e); var tmp2 bool; tmp2 = a_1; if !tmp2 { tmp2 = b_2 }; tmp1 = tmp2; modified = tmp1 } } else {
			var i Iterator = this.Iterator__Iterator(); L2: for {
				if i.HasNext__Z() {
					if c.Contains_O__Z(i.Next__O()) {
						i.Remove__V(); modified = true; i = i; continue L2 } else {
							i = i; continue L2 } }
//line :36:1
				break L2 } }
//line :33:1
	return modified
}









type AbstractSet struct{ AbstractCollection }

type AbstractSet_I interface{ AbstractCollection_I; Set; Collection; Iterable; Self_AbstractSet() *AbstractSet; RemoveAll_Collection__Z(p0 Collection) bool }

func (t *AbstractSet) Self_AbstractSet() *AbstractSet { return t }

func (t *AbstractSet) Is_Set() {}

func AbstractSet_InstanceOf(x any) bool { _, ok := x.(AbstractSet_I); return ok }

func AbstractSet_Cast(x any) AbstractSet_I { if x == nil { return nil }; v, ok := x.(AbstractSet_I); if !ok { panic(ClassCast(x, AbstractSet_class)) }; return v }
