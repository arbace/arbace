//line java_time_format_FormatStyle.ae:1
package jrt






type FormatStyle struct{ Enum }

func (t *FormatStyle) Is_Constable() {}

var FormatStyle_FULL *FormatStyle

var FormatStyle_LONG *FormatStyle

var FormatStyle_MEDIUM *FormatStyle

var FormatStyle_SHORT *FormatStyle

var FormatStyle__VALUES *RefArray

var FormatStyle_init ClassInit

func FormatStyle_Init() { if !FormatStyle_init.Done() { FormatStyle_init.Run(FormatStyle_clinit) } }

func FormatStyle_clinit() { FormatStyle_FULL = FormatStyle_New_String_I(Lit_1798, 0); FormatStyle_LONG = FormatStyle_New_String_I(Lit_1799, 1); FormatStyle_MEDIUM = FormatStyle_New_String_I(Lit_1800, 2); FormatStyle_SHORT = FormatStyle_New_String_I(Lit_1801, 3); FormatStyle__VALUES = FormatStyle_X_values__FormatStyle1() }

func FormatStyle_New_String_I(p0 *String, p1 int32) *FormatStyle { FormatStyle_Init(); t := &FormatStyle{}; t.Ctor_String_I(p0, p1); return t }

func (t *FormatStyle) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func FormatStyle_Values__FormatStyle1() *RefArray { FormatStyle_Init(); return FormatStyle__VALUES.Copy() }

func FormatStyle_ValueOf_String__FormatStyle(p0 *String) *FormatStyle { FormatStyle_Init(); return FormatStyle_Cast(Enum_ValueOf_Class_String__Enum(FormatStyle_class, p0)) }

func FormatStyle_X_values__FormatStyle1() *RefArray { FormatStyle_Init(); return RefArrayOf(FormatStyle_class, FormatStyle_FULL, FormatStyle_LONG, FormatStyle_MEDIUM, FormatStyle_SHORT) }

func (t *FormatStyle) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *FormatStyle) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *FormatStyle) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *FormatStyle) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.format.FormatStyle.describeConstable()Ljava/util/Optional;")) }

func (t *FormatStyle) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *FormatStyle) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *FormatStyle) Ref() any { if t == nil { return nil }; return t }

func (t *FormatStyle) GetClass__Class() *Class { return FormatStyle_class }

func (t *FormatStyle) CloneShallow() any { panic(CloneNotSupported(t)) }

func FormatStyle_InstanceOf(x any) bool { _, ok := x.(*FormatStyle); return ok }

func FormatStyle_Cast(x any) *FormatStyle { if x == nil { return nil }; v, ok := x.(*FormatStyle); if !ok { panic(ClassCast(x, FormatStyle_class)) }; return v }
