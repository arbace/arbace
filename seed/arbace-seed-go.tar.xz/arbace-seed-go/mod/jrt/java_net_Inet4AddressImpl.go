//line java_net_Inet4AddressImpl.ae:1
package jrt







func (t *Inet4AddressImpl) GetLocalHostName__String() *String {
	return HostNet_GetLocalHostName__String()
}
func (t *Inet4AddressImpl) LookupAllHostAddr_String__InetAddress1(hostname *String) *RefArray {
	return HostNet_LookupAllHostAddr_String_I__InetAddress1(hostname, 1)
}
func (t *Inet4AddressImpl) LookupAllHostAddr_String_InetAddressResolver_LookupPolicy__InetAddress1(hostname *String, lookupPolicy *InetAddressResolver_LookupPolicy) *RefArray {


	if NN(lookupPolicy).Characteristics__I()&1 == 0 {
		panic(Thrown(UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(hostname))))))
	}


	return t.LookupAllHostAddr_String__InetAddress1(hostname) }
//line :15:1
func (t *Inet4AddressImpl) GetHostByAddr_B1__String(addr *ByteArray) *String {
	return HostNet_GetHostByAddr_B1__String(addr)
}
func (t *Inet4AddressImpl) IsReachable0_B1_I_B1_I__Z(addr *ByteArray, timeout int32, ifaddr *ByteArray, ttl int32) bool {

	panic(Thrown(UnsupportedOperationException_New_String(Lit_1301)))
}












func (t *Inet4AddressImpl) AnyLocalAddress__InetAddress() InetAddress_I { MonitorEnter(t); defer MonitorExit(t)
	if t.F_anyLocalAddress == nil {
		t.F_anyLocalAddress = Inet4Address_New()
		t.F_anyLocalAddress.Holder__InetAddress_InetAddressHolder().F_hostName = Lit_1302 }
//line :34:1
	return t.F_anyLocalAddress
}




func (t *Inet4AddressImpl) LoopbackAddress__InetAddress() InetAddress_I { MonitorEnter(t); defer MonitorExit(t)
	if t.F_loopbackAddress == nil {
		var loopback *ByteArray = ByteArrayOf(127, 0, 0, 1)
		t.F_loopbackAddress = Inet4Address_New_String_B1(Lit_1303, loopback) }
//line :40:1
	return t.F_loopbackAddress
}





type Inet4AddressImpl struct{ Object; F_anyLocalAddress, F_loopbackAddress InetAddress_I }

func (t *Inet4AddressImpl) Is_InetAddressImpl() {}

func Inet4AddressImpl_New() *Inet4AddressImpl { t := &Inet4AddressImpl{}; t.Ctor(); return t }

func (t *Inet4AddressImpl) Ctor() {}

func (t *Inet4AddressImpl) Ref() any { if t == nil { return nil }; return t }

func (t *Inet4AddressImpl) GetClass__Class() *Class { return Inet4AddressImpl_class }

func (t *Inet4AddressImpl) ToString__String() *String { return Object_toString(t) }

func (t *Inet4AddressImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Inet4AddressImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func Inet4AddressImpl_InstanceOf(x any) bool { _, ok := x.(*Inet4AddressImpl); return ok }

func Inet4AddressImpl_Cast(x any) *Inet4AddressImpl { if x == nil { return nil }; v, ok := x.(*Inet4AddressImpl); if !ok { panic(ClassCast(x, Inet4AddressImpl_class)) }; return v }
