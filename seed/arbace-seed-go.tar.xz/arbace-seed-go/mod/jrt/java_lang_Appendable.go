//line java_lang_Appendable.ae:1
package jrt






type Appendable interface{ Object_I; Is_Appendable(); Append_CharSequence__Appendable(p0 CharSequence) Appendable; Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable; Append_C__Appendable(p0 uint16) Appendable }

func Appendable_InstanceOf(x any) bool { _, ok := x.(Appendable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Appendable_class) } }; return ok }

func Appendable_Cast(x any) Appendable { if x == nil { return nil }; v, ok := x.(Appendable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Appendable_class) } }; if !ok { panic(ClassCast(x, Appendable_class)) }; return v }
