//line java_net_SocketException.ae:1
package jrt










func SocketException_New_String(p0 *String) *SocketException { t := &SocketException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *SocketException) Ctor_String(this SocketException_I, msg *String) { t.IOException.Ctor_String(this, msg) }

func SocketException_New() *SocketException { t := &SocketException{}; t.Ctor(t); return t }
//line :14:1
func (t *SocketException) Ctor(this SocketException_I) { t.IOException.Ctor(this) }

func SocketException_New_String_Throwable(p0 *String, p1 Throwable_I) *SocketException { t := &SocketException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :16:1
func (t *SocketException) Ctor_String_Throwable(this SocketException_I, msg *String, cause Throwable_I) { t.IOException.Ctor_String_Throwable(this, msg, cause) }


func SocketException_New_Throwable(p0 Throwable_I) *SocketException { t := &SocketException{}; t.Ctor_Throwable(t, p0); return t }
//line :19:1
func (t *SocketException) Ctor_Throwable(this SocketException_I, cause Throwable_I) { t.IOException.Ctor_Throwable(this, cause) }










type SocketException struct{ IOException }

type SocketException_I interface{ IOException_I; Serializable; Self_SocketException() *SocketException }

func (t *SocketException) Self_SocketException() *SocketException { return t }

const SocketException_serialVersionUID int64 = -5935874303556886934

func (t *SocketException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *SocketException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *SocketException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *SocketException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *SocketException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *SocketException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *SocketException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *SocketException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *SocketException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *SocketException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *SocketException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *SocketException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *SocketException) Ref() any { if t == nil { return nil }; return t }

func (t *SocketException) GetClass__Class() *Class { return SocketException_class }

func (t *SocketException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SocketException) CloneShallow() any { panic(CloneNotSupported(t)) }

func SocketException_InstanceOf(x any) bool { _, ok := x.(SocketException_I); return ok }

func SocketException_Cast(x any) SocketException_I { if x == nil { return nil }; v, ok := x.(SocketException_I); if !ok { panic(ClassCast(x, SocketException_class)) }; return v }
