//line java_util_OptionalDouble.ae:1
package jrt














func OptionalDouble_New() *OptionalDouble { OptionalDouble_Init(); t := &OptionalDouble{}; t.Ctor(); return t }
//line :16:1
func (t *OptionalDouble) Ctor() {
	t.F_isPresent = false
	t.F_value = NaN64
}
func OptionalDouble_Empty__OptionalDouble() *OptionalDouble { OptionalDouble_Init(); return OptionalDouble_EMPTY }

func OptionalDouble_New_D(p0 float64) *OptionalDouble { OptionalDouble_Init(); t := &OptionalDouble{}; t.Ctor_D(p0); return t }
//line :22:1
func (t *OptionalDouble) Ctor_D(value float64) {
	t.F_isPresent = true
	t.F_value = value
}
func OptionalDouble_Of_D__OptionalDouble(value float64) *OptionalDouble {
	return OptionalDouble_New_D(value)
}
func (t *OptionalDouble) GetAsDouble__D() float64 {
	if t.F_isPresent { } else { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :29:1
	return t.F_value
}


func (t *OptionalDouble) IsPresent__Z() bool { return t.F_isPresent }

func (t *OptionalDouble) IsEmpty__Z() bool { return !t.F_isPresent }

func (t *OptionalDouble) IfPresent_DoubleConsumer__V(action DoubleConsumer) {
	if t.F_isPresent { action.Accept_D__V(t.F_value)
	} }
func (t *OptionalDouble) IfPresentOrElse_DoubleConsumer_Runnable__V(action DoubleConsumer, emptyAction Runnable) {
	if t.F_isPresent { action.Accept_D__V(t.F_value) } else { emptyAction.Run__V()
	} }
func (t *OptionalDouble) Stream__DoubleStream() DoubleStream {
	if t.F_isPresent { return DoubleStream_Of_D__DoubleStream(t.F_value) } else { return DoubleStream_Empty__DoubleStream()
	} }
func (t *OptionalDouble) OrElse_D__D(other float64) float64 {
	if t.F_isPresent { return t.F_value } else { return other
	} }
func (t *OptionalDouble) OrElseGet_DoubleSupplier__D(supplier DoubleSupplier) float64 {
	if t.F_isPresent { return t.F_value } else { return supplier.GetAsDouble__D()
	} }
func (t *OptionalDouble) OrElseThrow__D() float64 {
	if t.F_isPresent { } else { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :52:1
	return t.F_value
}


func (t *OptionalDouble) OrElseThrow_Supplier__D(exceptionSupplier Supplier) float64 {

	if t.F_isPresent { return t.F_value } else { panic(Thrown(Throwable_Cast(exceptionSupplier.Get__O())))
	} }
func (t *OptionalDouble) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if OptionalDouble_InstanceOf(tmp1) { var other *OptionalDouble = OptionalDouble_Cast(tmp1); var tmp2 bool; var tmp3 bool
			tmp3 = t.F_isPresent; if tmp3 { tmp3 = other.F_isPresent }; tmp2 = tmp3; if tmp2 {
				var tmp4 float64 = t.F_value; return Double_Compare_D_D__I(tmp4, other.F_value) == 0 } else {
					var tmp5 bool = t.F_isPresent; return tmp5 == other.F_isPresent } } else {
//line :63:1
						return false
					}
	}
}


func (t *OptionalDouble) HashCode__I() int32 {
	if t.F_isPresent { return Double_HashCode_D__I(t.F_value) } else { return 0
	} }
func (t *OptionalDouble) ToString__String() *String {
	if t.F_isPresent { return Concat(Lit_2796, StrOfDouble(t.F_value), Lit_1189) } else { return Lit_2797
	}
}

type OptionalDouble struct{ Object; F_isPresent bool; F_value float64 }

var OptionalDouble_EMPTY *OptionalDouble

var OptionalDouble_init ClassInit

func OptionalDouble_Init() { if !OptionalDouble_init.Done() { OptionalDouble_init.Run(OptionalDouble_clinit) } }

func OptionalDouble_clinit() { OptionalDouble_EMPTY = OptionalDouble_New() }

func (t *OptionalDouble) Ref() any { if t == nil { return nil }; return t }

func (t *OptionalDouble) GetClass__Class() *Class { return OptionalDouble_class }

func (t *OptionalDouble) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OptionalDouble) CloneShallow() any { panic(CloneNotSupported(t)) }

func OptionalDouble_InstanceOf(x any) bool { _, ok := x.(*OptionalDouble); return ok }

func OptionalDouble_Cast(x any) *OptionalDouble { if x == nil { return nil }; v, ok := x.(*OptionalDouble); if !ok { panic(ClassCast(x, OptionalDouble_class)) }; return v }
