//line java_time_MonthDay.ae:1
package jrt















































func MonthDay_Now__MonthDay() *MonthDay { MonthDay_Init()
	return MonthDay_Now_Clock__MonthDay(Clock_SystemDefaultZone__Clock())
}
func MonthDay_Now_ZoneId__MonthDay(zone ZoneId_I) *MonthDay { MonthDay_Init()
	return MonthDay_Now_Clock__MonthDay(Clock_System_ZoneId__Clock(zone))
}
func MonthDay_Now_Clock__MonthDay(clock Clock_I) *MonthDay { MonthDay_Init()
	var now *LocalDate = LocalDate_Now_Clock__LocalDate(clock); return MonthDay_Of_Month_I__MonthDay(NN(now).GetMonth__Month(), NN(now).GetDayOfMonth__I())
}
func MonthDay_Of_Month_I__MonthDay(month *Month, dayOfMonth int32) *MonthDay { MonthDay_Init()
	Objects_RequireNonNull_O_String__O(month.Ref(), Lit_1781)
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_MONTH; NN(tmp1).CheckValidValue_J__J(int64(dayOfMonth))
	if dayOfMonth > NN(month).MaxLength__I() {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2073, StrOfInt(dayOfMonth), Lit_2074, NN(month).Name__String()))))
	}



	return MonthDay_New_I_I(NN(month).GetValue__I(), dayOfMonth)
}
func MonthDay_Of_I_I__MonthDay(month, dayOfMonth int32) *MonthDay { MonthDay_Init()
	return MonthDay_Of_Month_I__MonthDay(Month_Of_I__Month(month), dayOfMonth)
}
func MonthDay_From_TemporalAccessor__MonthDay(temporal TemporalAccessor) *MonthDay { MonthDay_Init()
	if MonthDay_InstanceOf(temporal) {
		return MonthDay_Cast(temporal) } else {
			var tmp1 *MonthDay; tmp9 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; var tmp3 *IsoChronology = tmp2; if NN(tmp3).Equals_O__Z(Chronology_From_TemporalAccessor__Chronology(temporal)) == false {
					temporal = Up_LocalDate_TemporalAccessor(LocalDate_From_TemporalAccessor__LocalDate(temporal)) }
					var tmp4 TemporalAccessor = temporal; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MONTH_OF_YEAR; var tmp6 int32 = tmp4.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5)); var tmp7 TemporalAccessor = temporal; var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_DAY_OF_MONTH; tmp1 = MonthDay_Of_I_I__MonthDay(tmp6, tmp7.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp8))) }; return nil }()
//line :75:1
			if tmp9 != nil { if DateTimeException_InstanceOf(tmp9) { var ex DateTimeException_I = DateTimeException_Cast(tmp9)





				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2075, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :75:1
					panic(tmp9) } }; return tmp1
		}
}










func MonthDay_Parse_CharSequence__MonthDay(text CharSequence) *MonthDay { MonthDay_Init()
	return MonthDay_Parse_CharSequence_DateTimeFormatter__MonthDay(text, MonthDay_PARSER)
}
func MonthDay_Parse_CharSequence_DateTimeFormatter__MonthDay(text CharSequence, formatter *DateTimeFormatter) *MonthDay { MonthDay_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return MonthDay_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return MonthDay_From_TemporalAccessor__MonthDay(p0).Ref() }}))
}



func MonthDay_New_I_I(p0, p1 int32) *MonthDay { MonthDay_Init(); t := &MonthDay{}; t.Ctor_I_I(p0, p1); return t }
//line :98:1
func (t *MonthDay) Ctor_I_I(month, dayOfMonth int32) {
	t.F_month = int8(month)
	t.F_day = int8(dayOfMonth)
}
func (t *MonthDay) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; tmp1 = any(field) == any(tmp2.Ref()); if !tmp1 {
			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_MONTH; tmp1 = any(field) == any(tmp3.Ref()) }
//line :104:1
		return tmp1 } else {

			var tmp4 bool; tmp4 = !(field == nil); if tmp4 { tmp4 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp4
		} }
func (t *MonthDay) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; if any(field) == any(tmp1.Ref()) {
		return field.Range__ValueRange() } else {
//line :109:1
			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_DAY_OF_MONTH; if any(field) == any(tmp2.Ref()) {


				return ValueRange_Of_J_J_J__ValueRange(1, int64(NN(t.GetMonth__Month()).MinLength__I()), int64(NN(t.GetMonth__Month()).MaxLength__I())) } else {
					return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
				} } }
func (t *MonthDay) Get_TemporalField__I(field TemporalField) int32 {
	return NN(t.Range_TemporalField__ValueRange(field)).CheckValidIntValue_J_TemporalField__I(t.GetLong_TemporalField__J(field), field)
}
func (t *MonthDay) GetLong_TemporalField__J(field TemporalField) int64 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 18:
			return int64(t.F_day); case 23:
			return int64(t.F_month); default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return field.GetFrom_TemporalAccessor__J(t) } }; panic("a2g: unreachable")
}
func (t *MonthDay) GetMonthValue__I() int32 { return int32(t.F_month) }

func (t *MonthDay) GetMonth__Month() *Month { return Month_Of_I__Month(int32(t.F_month)) }

func (t *MonthDay) GetDayOfMonth__I() int32 { return int32(t.F_day) }

func (t *MonthDay) IsValidYear_I__Z(year int32) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = int32(t.F_day) == 29; if tmp3 { tmp3 = int32(t.F_month) == 2 }; tmp2 = tmp3; if tmp2 { tmp2 = Year_IsLeap_J__Z(int64(year)) == false }; tmp1 = tmp2; return tmp1 == false
}
func (t *MonthDay) WithMonth_I__MonthDay(month int32) *MonthDay {
	return t.With_Month__MonthDay(Month_Of_I__Month(month))
}
func (t *MonthDay) With_Month__MonthDay(month *Month) *MonthDay {
	Objects_RequireNonNull_O_String__O(month.Ref(), Lit_1781)
	if NN(month).GetValue__I() == int32(t.F_month) { return t } else {

		var tmp1 int32 = int32(t.F_day); var day int32 = Math_Min_I_I__I(tmp1, NN(month).MaxLength__I()); return MonthDay_New_I_I(NN(month).GetValue__I(), day)
	} }
func (t *MonthDay) WithDayOfMonth_I__MonthDay(dayOfMonth int32) *MonthDay {
	if dayOfMonth == int32(t.F_day) { return t } else { return MonthDay_Of_I_I__MonthDay(int32(t.F_month), dayOfMonth)
	} }
func (t *MonthDay) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_Chronology__TemporalQuery() { IsoChronology_Init(); return IsoChronology_INSTANCE.Ref() } else {

		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	} }
func (t *MonthDay) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 Chronology = Chronology_From_TemporalAccessor__Chronology(temporal); var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; if tmp1.Equals_O__Z(tmp2.Ref()) == false {
		panic(Thrown(DateTimeException_New_String(Lit_2071))) }
	var tmp3 Temporal = temporal; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_MONTH_OF_YEAR; temporal = tmp3.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp4), int64(t.F_month))
	var tmp5 Temporal = temporal; var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_DAY_OF_MONTH; var tmp7 TemporalField = Up_ChronoField_TemporalField(tmp6); var tmp8 Temporal = temporal; var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_DAY_OF_MONTH; return tmp5.With_TemporalField_J__Temporal(tmp7, Math_Min_J_J__J(NN(tmp8.Range_TemporalField__ValueRange(Up_ChronoField_TemporalField(tmp9))).GetMaximum__J(), int64(t.F_day)))
}


func (t *MonthDay) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *MonthDay) AtYear_I__LocalDate(year int32) *LocalDate {
	var tmp1 int32 = int32(t.F_month); var tmp2 int32; if t.IsValidYear_I__Z(year) { tmp2 = int32(t.F_day) } else { tmp2 = 28 }; return LocalDate_Of_I_I_I__LocalDate(year, tmp1, tmp2)
}
func (t *MonthDay) CompareTo_MonthDay__I(other *MonthDay) int32 {
	var tmp1 int32 = int32(t.F_month); var cmp int32 = tmp1 - int32(other.F_month)
	if cmp == 0 { var tmp2 int32 = int32(t.F_day); cmp = tmp2 - int32(other.F_day) }
//line :168:1
	return cmp
}


func (t *MonthDay) IsAfter_MonthDay__Z(other *MonthDay) bool {
	return t.CompareTo_MonthDay__I(other) > 0
}
func (t *MonthDay) IsBefore_MonthDay__Z(other *MonthDay) bool {
	return t.CompareTo_MonthDay__I(other) < 0
}
func (t *MonthDay) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if MonthDay_InstanceOf(tmp1) { var other *MonthDay = MonthDay_Cast(tmp1); var tmp2 int32 = int32(t.F_month)
			if tmp2 == int32(other.F_month) { var tmp3 int32 = int32(t.F_day); return tmp3 == int32(other.F_day) } else { return false } } else {
//line :181:1
				return false
			}
	}
}
func (t *MonthDay) HashCode__I() int32 {
	return int32(t.F_month)<<6 + int32(t.F_day)
}
func (t *MonthDay) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New_I(10)
	NN(buf).Append_String__StringBuilder(Lit_2072)
	DecimalDigits_AppendPair_StringBuilder_I__V(buf, int32(t.F_month))
	NN(buf).Append_C__StringBuilder(45)
	DecimalDigits_AppendPair_StringBuilder_I__V(buf, int32(t.F_day))
	return NN(buf).ToString__String()
}
func (t *MonthDay) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.MonthDay.writeReplace()Ljava/lang/Object;")) }








func MonthDay_ReadExternal_DataInput__MonthDay(p0 DataInput) *MonthDay { MonthDay_Init(); panic(A2g_NotTranslated("java.time.MonthDay.readExternal(Ljava/io/DataInput;)Ljava/time/MonthDay;")) }



type MonthDay struct{ Object; F_month, F_day int8 }

func (t *MonthDay) Is_TemporalAccessor() {}

func (t *MonthDay) Is_TemporalAdjuster() {}

func (t *MonthDay) Is_Comparable() {}

func (t *MonthDay) Is_Serializable() {}

const MonthDay_serialVersionUID int64 = -939150713474957432

var MonthDay_PARSER *DateTimeFormatter

var MonthDay_init ClassInit

func MonthDay_Init() { if !MonthDay_init.Done() { MonthDay_init.Run(MonthDay_clinit) } }

func MonthDay_clinit() { var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().AppendLiteral_String__DateTimeFormatterBuilder(Lit_2072); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; var tmp3 *DateTimeFormatterBuilder = NN(NN(tmp1).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp2), 2)).AppendLiteral_C__DateTimeFormatterBuilder(45); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_DAY_OF_MONTH; MonthDay_PARSER = NN(NN(tmp3).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp4), 2)).ToFormatter__DateTimeFormatter() }

func (t *MonthDay) CompareTo_O__I(p0 any) int32 { return t.CompareTo_MonthDay__I(MonthDay_Cast(p0)) }

func (t *MonthDay) Ref() any { if t == nil { return nil }; return t }

func (t *MonthDay) GetClass__Class() *Class { return MonthDay_class }

func (t *MonthDay) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MonthDay) CloneShallow() any { panic(CloneNotSupported(t)) }

func MonthDay_InstanceOf(x any) bool { _, ok := x.(*MonthDay); return ok }

func MonthDay_Cast(x any) *MonthDay { if x == nil { return nil }; v, ok := x.(*MonthDay); if !ok { panic(ClassCast(x, MonthDay_class)) }; return v }
