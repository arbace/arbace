//line java_util_SequencedMap.ae:1
package jrt











func SequencedMap_FirstEntry__Map_Entry(this SequencedMap) Map_Entry {
	var it Iterator = this.EntrySet__Set().Iterator__Iterator()
	if it.HasNext__Z() { return NullableKeyValueHolder_New_Map_Entry(Map_Entry_Cast(it.Next__O())) } else { return nil
	} }
func SequencedMap_LastEntry__Map_Entry(this SequencedMap) Map_Entry {
	var it Iterator = this.Reversed__SequencedMap().EntrySet__Set().Iterator__Iterator()
	if it.HasNext__Z() { return NullableKeyValueHolder_New_Map_Entry(Map_Entry_Cast(it.Next__O())) } else { return nil
	} }
func SequencedMap_PollFirstEntry__Map_Entry(this SequencedMap) Map_Entry {
	var it Iterator = this.EntrySet__Set().Iterator__Iterator()
	if it.HasNext__Z() {
		var entry *NullableKeyValueHolder = NullableKeyValueHolder_New_Map_Entry(Map_Entry_Cast(it.Next__O())); it.Remove__V(); return Up_NullableKeyValueHolder_Map_Entry(entry) } else {
//line :23:1
			return nil
		}
}
func SequencedMap_PollLastEntry__Map_Entry(this SequencedMap) Map_Entry {
	var it Iterator = this.Reversed__SequencedMap().EntrySet__Set().Iterator__Iterator()
	if it.HasNext__Z() {
		var entry *NullableKeyValueHolder = NullableKeyValueHolder_New_Map_Entry(Map_Entry_Cast(it.Next__O())); it.Remove__V(); return Up_NullableKeyValueHolder_Map_Entry(entry) } else {
//line :28:1
			return nil
		}
}
func SequencedMap_PutFirst_O_O__O(this SequencedMap, k, v any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SequencedMap_PutLast_O_O__O(this SequencedMap, k, v any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SequencedMap_SequencedKeySet__SequencedSet(this SequencedMap) SequencedSet {































	return SequencedMap_1SeqKeySet_New_SequencedMap(this) }
//line :42:1
func (t *SequencedMap_1SeqKeySet) View__Collection() Collection { return t.F_this_0.KeySet__Set() }

func (t *SequencedMap_1SeqKeySet) Reversed__SequencedSet() SequencedSet {
	return t.F_this_0.Reversed__SequencedMap().SequencedKeySet__SequencedSet()
}
func (t *SequencedMap_1SeqKeySet) Equals_O__Z(other any) bool {
	return t.View__Collection().Equals_O__Z(other)
}
func (t *SequencedMap_1SeqKeySet) HashCode__I() int32 { return t.View__Collection().HashCode__I() }

func (t *SequencedMap_1SeqKeySet) AddFirst_O__V(k any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *SequencedMap_1SeqKeySet) AddLast_O__V(k any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *SequencedMap_1SeqKeySet) GetFirst__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.FirstEntry__Map_Entry()).GetKey__O()
}
func (t *SequencedMap_1SeqKeySet) GetLast__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.LastEntry__Map_Entry()).GetKey__O()
}
func (t *SequencedMap_1SeqKeySet) RemoveFirst__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.PollFirstEntry__Map_Entry()).GetKey__O()
}
func (t *SequencedMap_1SeqKeySet) RemoveLast__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.PollLastEntry__Map_Entry()).GetKey__O()
}

func SequencedMap_SequencedValues__SequencedCollection(this SequencedMap) SequencedCollection {


























	return SequencedMap_1SeqValues_New_SequencedMap(this) }
//line :76:1
func (t *SequencedMap_1SeqValues) View__Collection() Collection { return t.F_this_0.Values__Collection() }

func (t *SequencedMap_1SeqValues) Reversed__SequencedCollection() SequencedCollection {
	return t.F_this_0.Reversed__SequencedMap().SequencedValues__SequencedCollection()
}
func (t *SequencedMap_1SeqValues) AddFirst_O__V(v any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *SequencedMap_1SeqValues) AddLast_O__V(v any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *SequencedMap_1SeqValues) GetFirst__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.FirstEntry__Map_Entry()).GetValue__O()
}
func (t *SequencedMap_1SeqValues) GetLast__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.LastEntry__Map_Entry()).GetValue__O()
}
func (t *SequencedMap_1SeqValues) RemoveFirst__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.PollFirstEntry__Map_Entry()).GetValue__O()
}
func (t *SequencedMap_1SeqValues) RemoveLast__O() any {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.PollLastEntry__Map_Entry()).GetValue__O()
}

func SequencedMap_SequencedEntrySet__SequencedSet(this SequencedMap) SequencedSet {
































	return SequencedMap_1SeqEntrySet_New_SequencedMap(this) }
//line :105:1
func (t *SequencedMap_1SeqEntrySet) View__Collection() Collection {
	return t.F_this_0.EntrySet__Set()
}
func (t *SequencedMap_1SeqEntrySet) Reversed__SequencedSet() SequencedSet {
	return t.F_this_0.Reversed__SequencedMap().SequencedEntrySet__SequencedSet()
}
func (t *SequencedMap_1SeqEntrySet) Equals_O__Z(other any) bool {
	return t.View__Collection().Equals_O__Z(other)
}
func (t *SequencedMap_1SeqEntrySet) HashCode__I() int32 { return t.View__Collection().HashCode__I() }

func (t *SequencedMap_1SeqEntrySet) AddFirst_Map_Entry__V(e Map_Entry) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *SequencedMap_1SeqEntrySet) AddLast_Map_Entry__V(e Map_Entry) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *SequencedMap_1SeqEntrySet) GetFirst__Map_Entry() Map_Entry {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.FirstEntry__Map_Entry())
}
func (t *SequencedMap_1SeqEntrySet) GetLast__Map_Entry() Map_Entry {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.LastEntry__Map_Entry())
}
func (t *SequencedMap_1SeqEntrySet) RemoveFirst__Map_Entry() Map_Entry {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.PollFirstEntry__Map_Entry())
}
func (t *SequencedMap_1SeqEntrySet) RemoveLast__Map_Entry() Map_Entry {
	return AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(t.F_this_0.PollLastEntry__Map_Entry())
}


type SequencedMap interface{ Object_I; Map; Is_SequencedMap(); Reversed__SequencedMap() SequencedMap; FirstEntry__Map_Entry() Map_Entry; LastEntry__Map_Entry() Map_Entry; PollFirstEntry__Map_Entry() Map_Entry; PollLastEntry__Map_Entry() Map_Entry; PutFirst_O_O__O(p0, p1 any) any; PutLast_O_O__O(p0, p1 any) any; SequencedKeySet__SequencedSet() SequencedSet; SequencedValues__SequencedCollection() SequencedCollection; SequencedEntrySet__SequencedSet() SequencedSet }

func SequencedMap_InstanceOf(x any) bool { _, ok := x.(SequencedMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SequencedMap_class) } }; return ok }

func SequencedMap_Cast(x any) SequencedMap { if x == nil { return nil }; v, ok := x.(SequencedMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SequencedMap_class) } }; if !ok { panic(ClassCast(x, SequencedMap_class)) }; return v }



type SequencedMap_1SeqEntrySet struct{ AbstractMap_ViewCollection; F_this_0 SequencedMap }

func (t *SequencedMap_1SeqEntrySet) Is_SequencedSet() {}

func (t *SequencedMap_1SeqEntrySet) Is_SequencedCollection() {}

func (t *SequencedMap_1SeqEntrySet) Is_Set() {}

func SequencedMap_1SeqEntrySet_New_SequencedMap(p0 SequencedMap) *SequencedMap_1SeqEntrySet { t := &SequencedMap_1SeqEntrySet{}; t.Ctor_SequencedMap(p0); return t }

func (t *SequencedMap_1SeqEntrySet) Ctor_SequencedMap(this_0 SequencedMap) { A2g_NotNull[SequencedMap](this_0); t.F_this_0 = this_0; t.AbstractMap_ViewCollection.Ctor(t) }

func (t *SequencedMap_1SeqEntrySet) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *SequencedMap_1SeqEntrySet) AddFirst_O__V(p0 any) { t.AddFirst_Map_Entry__V(Map_Entry_Cast(p0)) }

func (t *SequencedMap_1SeqEntrySet) AddLast_O__V(p0 any) { t.AddLast_Map_Entry__V(Map_Entry_Cast(p0)) }

func (t *SequencedMap_1SeqEntrySet) GetFirst__O() any { return t.GetFirst__Map_Entry() }

func (t *SequencedMap_1SeqEntrySet) GetLast__O() any { return t.GetLast__Map_Entry() }

func (t *SequencedMap_1SeqEntrySet) RemoveFirst__O() any { return t.RemoveFirst__Map_Entry() }

func (t *SequencedMap_1SeqEntrySet) RemoveLast__O() any { return t.RemoveLast__Map_Entry() }

func (t *SequencedMap_1SeqEntrySet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *SequencedMap_1SeqEntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *SequencedMap_1SeqEntrySet) Clear__V() { t.Impl_Clear__V(t) }

func (t *SequencedMap_1SeqEntrySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *SequencedMap_1SeqEntrySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) Uoe__UnsupportedOperationException() UnsupportedOperationException_I { return t.Impl_Uoe__UnsupportedOperationException(t) }

func (t *SequencedMap_1SeqEntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *SequencedMap_1SeqEntrySet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *SequencedMap_1SeqEntrySet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *SequencedMap_1SeqEntrySet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *SequencedMap_1SeqEntrySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *SequencedMap_1SeqEntrySet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *SequencedMap_1SeqEntrySet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *SequencedMap_1SeqEntrySet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqEntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *SequencedMap_1SeqEntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *SequencedMap_1SeqEntrySet) GetClass__Class() *Class { return SequencedMap_1SeqEntrySet_class }

func (t *SequencedMap_1SeqEntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SequencedMap_1SeqEntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func SequencedMap_1SeqEntrySet_InstanceOf(x any) bool { _, ok := x.(*SequencedMap_1SeqEntrySet); return ok }

func SequencedMap_1SeqEntrySet_Cast(x any) *SequencedMap_1SeqEntrySet { if x == nil { return nil }; v, ok := x.(*SequencedMap_1SeqEntrySet); if !ok { panic(ClassCast(x, SequencedMap_1SeqEntrySet_class)) }; return v }



type SequencedMap_1SeqKeySet struct{ AbstractMap_ViewCollection; F_this_0 SequencedMap }

func (t *SequencedMap_1SeqKeySet) Is_SequencedSet() {}

func (t *SequencedMap_1SeqKeySet) Is_SequencedCollection() {}

func (t *SequencedMap_1SeqKeySet) Is_Set() {}

func SequencedMap_1SeqKeySet_New_SequencedMap(p0 SequencedMap) *SequencedMap_1SeqKeySet { t := &SequencedMap_1SeqKeySet{}; t.Ctor_SequencedMap(p0); return t }

func (t *SequencedMap_1SeqKeySet) Ctor_SequencedMap(this_0 SequencedMap) { A2g_NotNull[SequencedMap](this_0); t.F_this_0 = this_0; t.AbstractMap_ViewCollection.Ctor(t) }

func (t *SequencedMap_1SeqKeySet) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *SequencedMap_1SeqKeySet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *SequencedMap_1SeqKeySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *SequencedMap_1SeqKeySet) Clear__V() { t.Impl_Clear__V(t) }

func (t *SequencedMap_1SeqKeySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *SequencedMap_1SeqKeySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) Uoe__UnsupportedOperationException() UnsupportedOperationException_I { return t.Impl_Uoe__UnsupportedOperationException(t) }

func (t *SequencedMap_1SeqKeySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *SequencedMap_1SeqKeySet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *SequencedMap_1SeqKeySet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *SequencedMap_1SeqKeySet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *SequencedMap_1SeqKeySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *SequencedMap_1SeqKeySet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *SequencedMap_1SeqKeySet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *SequencedMap_1SeqKeySet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqKeySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *SequencedMap_1SeqKeySet) Ref() any { if t == nil { return nil }; return t }

func (t *SequencedMap_1SeqKeySet) GetClass__Class() *Class { return SequencedMap_1SeqKeySet_class }

func (t *SequencedMap_1SeqKeySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SequencedMap_1SeqKeySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func SequencedMap_1SeqKeySet_InstanceOf(x any) bool { _, ok := x.(*SequencedMap_1SeqKeySet); return ok }

func SequencedMap_1SeqKeySet_Cast(x any) *SequencedMap_1SeqKeySet { if x == nil { return nil }; v, ok := x.(*SequencedMap_1SeqKeySet); if !ok { panic(ClassCast(x, SequencedMap_1SeqKeySet_class)) }; return v }



type SequencedMap_1SeqValues struct{ AbstractMap_ViewCollection; F_this_0 SequencedMap }

func (t *SequencedMap_1SeqValues) Is_SequencedCollection() {}

func SequencedMap_1SeqValues_New_SequencedMap(p0 SequencedMap) *SequencedMap_1SeqValues { t := &SequencedMap_1SeqValues{}; t.Ctor_SequencedMap(p0); return t }

func (t *SequencedMap_1SeqValues) Ctor_SequencedMap(this_0 SequencedMap) { A2g_NotNull[SequencedMap](this_0); t.F_this_0 = this_0; t.AbstractMap_ViewCollection.Ctor(t) }

func (t *SequencedMap_1SeqValues) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *SequencedMap_1SeqValues) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *SequencedMap_1SeqValues) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *SequencedMap_1SeqValues) Clear__V() { t.Impl_Clear__V(t) }

func (t *SequencedMap_1SeqValues) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *SequencedMap_1SeqValues) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqValues) Uoe__UnsupportedOperationException() UnsupportedOperationException_I { return t.Impl_Uoe__UnsupportedOperationException(t) }

func (t *SequencedMap_1SeqValues) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *SequencedMap_1SeqValues) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *SequencedMap_1SeqValues) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqValues) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *SequencedMap_1SeqValues) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *SequencedMap_1SeqValues) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *SequencedMap_1SeqValues) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqValues) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *SequencedMap_1SeqValues) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *SequencedMap_1SeqValues) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *SequencedMap_1SeqValues) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *SequencedMap_1SeqValues) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *SequencedMap_1SeqValues) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *SequencedMap_1SeqValues) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *SequencedMap_1SeqValues) Ref() any { if t == nil { return nil }; return t }

func (t *SequencedMap_1SeqValues) GetClass__Class() *Class { return SequencedMap_1SeqValues_class }

func (t *SequencedMap_1SeqValues) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SequencedMap_1SeqValues) CloneShallow() any { panic(CloneNotSupported(t)) }

func SequencedMap_1SeqValues_InstanceOf(x any) bool { _, ok := x.(*SequencedMap_1SeqValues); return ok }

func SequencedMap_1SeqValues_Cast(x any) *SequencedMap_1SeqValues { if x == nil { return nil }; v, ok := x.(*SequencedMap_1SeqValues); if !ok { panic(ClassCast(x, SequencedMap_1SeqValues_class)) }; return v }
