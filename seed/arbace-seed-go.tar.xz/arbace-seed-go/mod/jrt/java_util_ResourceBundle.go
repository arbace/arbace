//line java_util_ResourceBundle.ae:1
package jrt












func (t *ResourceBundle) Ctor(this ResourceBundle_I) { t.F_parent = nil }

func (t *ResourceBundle) Impl_GetBaseBundleName__String(this ResourceBundle_I) *String { return nil }

func (t *ResourceBundle) Impl_GetString_String__String(this ResourceBundle_I, key *String) *String {
	return String_Cast(this.GetObject_String__O(key))
}
func (t *ResourceBundle) Impl_GetStringArray_String__String1(this ResourceBundle_I, key *String) *RefArray {
	return A2g_CastArray[*RefArray](this.GetObject_String__O(key), String_class.ArrayClass())
}
func (t *ResourceBundle) Impl_GetObject_String__O(this ResourceBundle_I, key *String) any {
	var obj any = this.HandleGetObject_String__O(key)
	if obj == nil {
		if !(t.F_parent == nil) { obj = t.F_parent.GetObject_String__O(key) }
		if obj == nil {
			panic(Thrown(MissingResourceException_New_String_String_String(Concat(Lit_2817, NN(this.GetClass__Class()).GetName__String(), Lit_2818, key), NN(this.GetClass__Class()).GetName__String(), key))) } }
//line :25:1
	return obj
}











func (t *ResourceBundle) Impl_GetLocale__Locale(this ResourceBundle_I) *Locale { return nil }

func (t *ResourceBundle) Impl_SetParent_ResourceBundle__V(this, p0 ResourceBundle_I) { panic(A2g_NotTranslated("java.util.ResourceBundle.setParent(Ljava/util/ResourceBundle;)V")) }






func (t *ResourceBundle) Impl_ContainsKey_String__Z(this ResourceBundle_I, key *String) bool {
	if key == nil { panic(Thrown(NullPointerException_New())) }
	var rb ResourceBundle_I = this; L1: for {
		if !(rb == nil) {
			if rb.HandleKeySet__Set().Contains_O__Z(key.Ref()) { return true } else { rb = rb.Self_ResourceBundle().F_parent; continue L1 } }
//line :49:1
		break L1 }
//line :47:1
	return false
}






func (t *ResourceBundle) Impl_KeySet__Set(this ResourceBundle_I) Set {
	var keys Set = HashSet_New(); var rb ResourceBundle_I = this
L1: for { if !(rb == nil) { keys.AddAll_Collection__Z(rb.HandleKeySet__Set()); rb = rb.Self_ResourceBundle().F_parent; continue L1 }; break L1 }
//line :56:1
	return keys
}


func (t *ResourceBundle) Impl_HandleKeySet__Set(this ResourceBundle_I) Set {
	var keys Set = t.F_handleKeys.Load()
	if keys == nil {
		keys = HashSet_New()
		var enumKeys Enumeration = this.GetKeys__Enumeration()
	L1: for { if enumKeys.HasMoreElements__Z() {
		var key *String = String_Cast(enumKeys.NextElement__O())
		if !(this.HandleGetObject_String__O(key) == nil) { keys.Add_O__Z(key.Ref()) }
//line :65:1
		continue L1 }; break L1
	}

		t.F_handleKeys.Store(keys) }
//line :61:1
	return keys
}























func ResourceBundle_Control_New() *ResourceBundle_Control { ResourceBundle_Control_Init(); t := &ResourceBundle_Control{}; t.Ctor(t); return t }
//line :86:1
func (t *ResourceBundle_Control) Ctor(this ResourceBundle_Control_I) {}

func ResourceBundle_Control_GetControl_List__ResourceBundle_Control(formats List) ResourceBundle_Control_I { ResourceBundle_Control_Init()
	if formats.Equals_O__Z(ResourceBundle_Control_FORMAT_PROPERTIES) { ResourceBundle_SingleFormatControl_Init(); return ResourceBundle_SingleFormatControl_PROPERTIES_ONLY } else { if formats.Equals_O__Z(ResourceBundle_Control_FORMAT_CLASS) { ResourceBundle_SingleFormatControl_Init(); return ResourceBundle_SingleFormatControl_CLASS_ONLY } else { if formats.Equals_O__Z(ResourceBundle_Control_FORMAT_DEFAULT) { return ResourceBundle_Control_INSTANCE } else {



		panic(Thrown(IllegalArgumentException_New()))
	} } } }
func ResourceBundle_Control_GetNoFallbackControl_List__ResourceBundle_Control(formats List) ResourceBundle_Control_I { ResourceBundle_Control_Init()
	if formats.Equals_O__Z(ResourceBundle_Control_FORMAT_DEFAULT) { ResourceBundle_NoFallbackControl_Init(); return ResourceBundle_NoFallbackControl_NO_FALLBACK } else { if formats.Equals_O__Z(ResourceBundle_Control_FORMAT_PROPERTIES) { ResourceBundle_NoFallbackControl_Init(); return ResourceBundle_NoFallbackControl_PROPERTIES_ONLY_NO_FALLBACK } else { if formats.Equals_O__Z(ResourceBundle_Control_FORMAT_CLASS) { ResourceBundle_NoFallbackControl_Init(); return ResourceBundle_NoFallbackControl_CLASS_ONLY_NO_FALLBACK } else {



		panic(Thrown(IllegalArgumentException_New()))
	} } } }
func (t *ResourceBundle_Control) Impl_GetFormats_String__List(this ResourceBundle_Control_I, baseName *String) List {
	if baseName == nil { panic(Thrown(NullPointerException_New())) }
//line :102:1
	return ResourceBundle_Control_FORMAT_DEFAULT
}


func (t *ResourceBundle_Control) Impl_GetCandidateLocales_String_Locale__List(this ResourceBundle_Control_I, baseName *String, locale *Locale) List {
	if baseName == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 Map = ResourceBundle_Control_CANDIDATES_CACHE; return ArrayList_New_Collection(Collection_Cast(tmp1.ComputeIfAbsent_O_Function__O(NN(locale).GetBaseLocale__BaseLocale().Ref(), &Function_Fn{Fn: func(p0 any) any { return ResourceBundle_Control_CreateCandidateList_BaseLocale__List(BaseLocale_Cast(p0)) }})))
}









func ResourceBundle_Control_CreateCandidateList_BaseLocale__List(base *BaseLocale) List { ResourceBundle_Control_Init()
	var language *String = NN(base).GetLanguage__String(); var script *String = NN(base).GetScript__String(); var region *String = NN(base).GetRegion__String(); var variant *String = NN(base).GetVariant__String()
	var isNorwegianBokmal bool = false
	var isNorwegianNynorsk bool = false



	if NN(language).Equals_O__Z(Lit_2821) {
		var tmp1 bool; var tmp2 bool; tmp2 = NN(region).Equals_O__Z(Lit_2822); if tmp2 { tmp2 = NN(variant).Equals_O__Z(Lit_2823) }; tmp1 = tmp2; if tmp1 {
			variant = Lit_69; isNorwegianNynorsk = true } else {
				isNorwegianBokmal = true } }
	var tmp3 bool; var tmp4 bool
	tmp4 = NN(language).Equals_O__Z(Lit_2824); if !tmp4 { tmp4 = isNorwegianBokmal }; tmp3 = tmp4
//line :130:1
	if tmp3 {

		var tmpList List = ResourceBundle_Control_GetDefaultList_String_String_String_String__List(Lit_2824, script, region, variant); var bokmalList List = ArrayList_New(); var i_101999 Iterator = tmpList.Iterator__Iterator()

	L1: for i_101999.HasNext__Z() { var l_nb *Locale = Locale_Cast(i_101999.Next__O()); var isRoot bool = NN(NN(l_nb).GetLanguage__String()).IsEmpty__Z(); var l_no *Locale; var tmp5 *String

		if isRoot { tmp5 = Lit_69 } else { tmp5 = Lit_2821 }; l_no = Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(tmp5, NN(l_nb).GetScript__String(), NN(l_nb).GetCountry__String(), NN(l_nb).GetVariant__String(), nil)




		var tmp6 *Locale; if isNorwegianBokmal { tmp6 = l_no } else { tmp6 = l_nb }; bokmalList.Add_O__Z(tmp6.Ref())
		if isRoot { break L1 }
		var tmp7 *Locale; if isNorwegianBokmal { tmp7 = l_nb } else { tmp7 = l_no }; bokmalList.Add_O__Z(tmp7.Ref()) }
//line :132:1
		return bokmalList } else {
//line :130:1
			var tmp8 bool; var tmp9 bool














			tmp9 = NN(language).Equals_O__Z(Lit_2825); if !tmp9 { tmp9 = isNorwegianNynorsk }; tmp8 = tmp9
//line :130:1
			if tmp8 {















				var nynorskList List = ResourceBundle_Control_GetDefaultList_String_String_String_String__List(Lit_2825, script, region, variant); var idx int32 = nynorskList.Size__I() - 1





				nynorskList.Add_I_O__V(idx, Locale_GetInstance_String_String_String__Locale(Lit_2821, Lit_2822, Lit_2823).Ref())
				idx = idx + 1
				nynorskList.Add_I_O__V(idx, Locale_GetInstance_String_String_String__Locale(Lit_2821, Lit_2822, Lit_69).Ref())
				idx = idx + 1
				nynorskList.Add_I_O__V(idx, Locale_GetInstance_String_String_String__Locale(Lit_2821, Lit_69, Lit_69).Ref())
				idx = idx + 1
//line :146:1
				return nynorskList } else {














					if NN(language).Equals_O__Z(Lit_2826) {
						var tmp10 bool; var tmp11 bool; tmp11 = NN(script).IsEmpty__Z(); if tmp11 { tmp11 = !NN(region).IsEmpty__Z() }; tmp10 = tmp11; if tmp10 {
							var tmp12 *String = region; var tmp13 int32 = -1; switch NN(tmp12).HashCode__I() { case 2155: if tmp12.Equals_O__Z(Lit_2827) { tmp13 = 3 }; case 2307: if tmp12.Equals_O__Z(Lit_2828) { tmp13 = 1 }; case 2466: if tmp12.Equals_O__Z(Lit_2829) { tmp13 = 2 }; case 2644: if tmp12.Equals_O__Z(Lit_2830) { tmp13 = 4 }; case 2691: if tmp12.Equals_O__Z(Lit_2831) { tmp13 = 0 }}; switch tmp13 { case 0, 1, 2:
								script = Lit_2832
//line :163:1
							case 3, 4:

								script = Lit_2833
//line :163:1
							default:
							}
						} }
					return ResourceBundle_Control_GetDefaultList_String_String_String_String__List(language, script, region, variant)
				} } }
func ResourceBundle_Control_GetDefaultList_String_String_String_String__List(language, script, region, variant *String) List { ResourceBundle_Control_Init()


	var variants List
	if NN(variant).IsEmpty__Z() { } else {
		variants = ArrayList_New()
		var idx int32 = NN(variant).Length__I()
	L1: for { if !(idx == -1) {
		variants.Add_O__Z(NN(variant).Substring_I_I__String(0, idx).Ref())
		var tmp1 int32; idx = idx - 1; tmp1 = idx; idx = NN(variant).LastIndexOf_I_I__I(95, tmp1)
//line :175:1
		continue L1 }; break L1
	}
	}
	var list List = ArrayList_New()
	if !(variants == nil) {
		var i_102002 Iterator = variants.Iterator__Iterator(); for i_102002.HasNext__Z() { var v *String = String_Cast(i_102002.Next__O())
			list.Add_O__Z(Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, script, region, v, nil).Ref()) } }
	if NN(region).IsEmpty__Z() { } else {
		list.Add_O__Z(Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, script, region, Lit_69, nil).Ref()) }
	if NN(script).IsEmpty__Z() { } else {
		list.Add_O__Z(Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, script, Lit_69, Lit_69, nil).Ref())
		if NN(language).Equals_O__Z(Lit_2826) {
			if NN(region).IsEmpty__Z() {
				var tmp2 *String = script; var tmp3 int32 = -1; switch NN(tmp2).HashCode__I() { case 2241694: if tmp2.Equals_O__Z(Lit_2833) { tmp3 = 0 }; case 2241695: if tmp2.Equals_O__Z(Lit_2832) { tmp3 = 1 }}; switch tmp3 { case 0: region = Lit_2827; case 1: region = Lit_2831; default:} } }
		if !(variants == nil) {
			var i_102005 Iterator = variants.Iterator__Iterator(); for i_102005.HasNext__Z() { var v_2 *String = String_Cast(i_102005.Next__O())
				list.Add_O__Z(Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, Lit_69, region, v_2, nil).Ref()) } }
		if NN(region).IsEmpty__Z() { } else { list.Add_O__Z(Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, Lit_69, region, Lit_69, nil).Ref()) } }
	if NN(language).IsEmpty__Z() { } else { list.Add_O__Z(Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, Lit_69, Lit_69, Lit_69, nil).Ref()) }
	var tmp4 *Locale; Locale_Init(); tmp4 = Locale_ROOT; list.Add_O__Z(tmp4.Ref())
//line :178:1
	return list
}

















func (t *ResourceBundle_Control) Impl_GetFallbackLocale_String_Locale__Locale(this ResourceBundle_Control_I, baseName *String, locale *Locale) *Locale {
	if baseName == nil { panic(Thrown(NullPointerException_New())) }
	var defaultLocale *Locale = Locale_GetDefault__Locale()
	if NN(locale).Equals_O__Z(defaultLocale.Ref()) { return nil } else { return defaultLocale
	} }
func (t *ResourceBundle_Control) Impl_GetTimeToLive_String_Locale__J(this ResourceBundle_Control_I, baseName *String, locale *Locale) int64 {
	var tmp1 bool; var tmp2 bool; tmp2 = baseName == nil; if !tmp2 { tmp2 = locale == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
//line :202:1
	return -2
}


func (t *ResourceBundle_Control) Impl_ToBundleName_String_Locale__String(this ResourceBundle_Control_I, baseName *String, locale *Locale) *String {
	var tmp1 *Locale; Locale_Init(); tmp1 = Locale_ROOT; if locale == tmp1 { return baseName } else {

		var language *String = NN(locale).GetLanguage__String(); var script *String = NN(locale).GetScript__String(); var country *String = NN(locale).GetCountry__String(); var variant *String = NN(locale).GetVariant__String(); var tmp2 bool; var tmp3 bool; var tmp4 bool



		tmp4 = language == Lit_69; if tmp4 { tmp4 = country == Lit_69 }; tmp3 = tmp4; if tmp3 { tmp3 = variant == Lit_69 }; tmp2 = tmp3; if tmp2 { return baseName } else {

			var sb *StringBuilder = StringBuilder_New_String(baseName)
			NN(sb).Append_C__StringBuilder(95)
			if !(script == Lit_69) {

				if !(variant == Lit_69) {

					NN(NN(NN(NN(NN(NN(NN(sb).Append_String__StringBuilder(language)).Append_C__StringBuilder(95)).Append_String__StringBuilder(script)).Append_C__StringBuilder(95)).Append_String__StringBuilder(country)).Append_C__StringBuilder(95)).Append_String__StringBuilder(variant) } else {
//line :219:1
						if !(country == Lit_69) {









							NN(NN(NN(NN(NN(sb).Append_String__StringBuilder(language)).Append_C__StringBuilder(95)).Append_String__StringBuilder(script)).Append_C__StringBuilder(95)).Append_String__StringBuilder(country) } else {

								NN(NN(NN(sb).Append_String__StringBuilder(language)).Append_C__StringBuilder(95)).Append_String__StringBuilder(script) } } } else {
//line :217:1
									if !(variant == Lit_69) {















										NN(NN(NN(NN(NN(sb).Append_String__StringBuilder(language)).Append_C__StringBuilder(95)).Append_String__StringBuilder(country)).Append_C__StringBuilder(95)).Append_String__StringBuilder(variant) } else {
//line :217:1
											if !(country == Lit_69) {


















												NN(NN(NN(sb).Append_String__StringBuilder(language)).Append_C__StringBuilder(95)).Append_String__StringBuilder(country) } else {
													NN(sb).Append_String__StringBuilder(language) } } }
			return NN(sb).ToString__String()
		} } }
func (t *ResourceBundle_Control) Impl_ToResourceName_String_String__String(this ResourceBundle_Control_I, bundleName, suffix *String) *String {
	var sb *StringBuilder = StringBuilder_New_I(NN(bundleName).Length__I() + 1 + NN(suffix).Length__I())

	NN(NN(NN(sb).Append_String__StringBuilder(NN(bundleName).Replace_C_C__String(46, 47))).Append_C__StringBuilder(46)).Append_String__StringBuilder(suffix)
	return NN(sb).ToString__String()
}











func ResourceBundle_SingleFormatControl_New_List(p0 List) *ResourceBundle_SingleFormatControl { ResourceBundle_SingleFormatControl_Init(); t := &ResourceBundle_SingleFormatControl{}; t.Ctor_List(t, p0); return t }
//line :257:1
func (t *ResourceBundle_SingleFormatControl) Ctor_List(this ResourceBundle_SingleFormatControl_I, formats List) { t.ResourceBundle_Control.Ctor(this)
	t.F_formats = formats
}
func (t *ResourceBundle_SingleFormatControl) Impl_GetFormats_String__List(this ResourceBundle_SingleFormatControl_I, baseName *String) List {
	if baseName == nil { panic(Thrown(NullPointerException_New())) }
//line :260:1
	return t.F_formats
}














func ResourceBundle_NoFallbackControl_New_List(p0 List) *ResourceBundle_NoFallbackControl { ResourceBundle_NoFallbackControl_Init(); t := &ResourceBundle_NoFallbackControl{}; t.Ctor_List(p0); return t }
//line :276:1
func (t *ResourceBundle_NoFallbackControl) Ctor_List(formats List) { t.ResourceBundle_SingleFormatControl.Ctor_List(t, formats) }


func (t *ResourceBundle_NoFallbackControl) GetFallbackLocale_String_Locale__Locale(baseName *String, locale *Locale) *Locale {
	var tmp1 bool; var tmp2 bool; tmp2 = baseName == nil; if !tmp2 { tmp2 = locale == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
//line :279:1
	return nil
}



type ResourceBundle struct{ Object; F_parent ResourceBundle_I; F_handleKeys Volatile[Set] }

type ResourceBundle_I interface{ Object_I; Self_ResourceBundle() *ResourceBundle; GetBaseBundleName__String() *String; GetString_String__String(p0 *String) *String; GetStringArray_String__String1(p0 *String) *RefArray; GetObject_String__O(p0 *String) any; GetLocale__Locale() *Locale; SetParent_ResourceBundle__V(p0 ResourceBundle_I); HandleGetObject_String__O(p0 *String) any; GetKeys__Enumeration() Enumeration; ContainsKey_String__Z(p0 *String) bool; KeySet__Set() Set; HandleKeySet__Set() Set }

func (t *ResourceBundle) Self_ResourceBundle() *ResourceBundle { return t }

func ResourceBundle_InstanceOf(x any) bool { _, ok := x.(ResourceBundle_I); return ok }

func ResourceBundle_Cast(x any) ResourceBundle_I { if x == nil { return nil }; v, ok := x.(ResourceBundle_I); if !ok { panic(ClassCast(x, ResourceBundle_class)) }; return v }



type ResourceBundle_Control struct{ Object }

type ResourceBundle_Control_I interface{ Object_I; Self_ResourceBundle_Control() *ResourceBundle_Control; GetFormats_String__List(p0 *String) List; GetCandidateLocales_String_Locale__List(p0 *String, p1 *Locale) List; GetFallbackLocale_String_Locale__Locale(p0 *String, p1 *Locale) *Locale; GetTimeToLive_String_Locale__J(p0 *String, p1 *Locale) int64; ToBundleName_String_Locale__String(p0 *String, p1 *Locale) *String; ToResourceName_String_String__String(p0, p1 *String) *String }

func (t *ResourceBundle_Control) Self_ResourceBundle_Control() *ResourceBundle_Control { return t }

var ResourceBundle_Control_FORMAT_DEFAULT List

var ResourceBundle_Control_FORMAT_CLASS List

var ResourceBundle_Control_FORMAT_PROPERTIES List

const ResourceBundle_Control_TTL_DONT_CACHE int64 = -1

const ResourceBundle_Control_TTL_NO_EXPIRATION_CONTROL int64 = -2

var ResourceBundle_Control_INSTANCE ResourceBundle_Control_I

var ResourceBundle_Control_CANDIDATES_CACHE Map

var ResourceBundle_Control_init ClassInit

func ResourceBundle_Control_Init() { if !ResourceBundle_Control_init.Done() { ResourceBundle_Control_init.Run(ResourceBundle_Control_clinit) } }

func ResourceBundle_Control_clinit() { ResourceBundle_Control_FORMAT_DEFAULT = List_Of_O_O__List(Lit_2819, Lit_2820); ResourceBundle_Control_FORMAT_CLASS = List_Of_O__List(Lit_2819); ResourceBundle_Control_FORMAT_PROPERTIES = List_Of_O__List(Lit_2820); ResourceBundle_Control_INSTANCE = ResourceBundle_Control_New(); ResourceBundle_Control_CANDIDATES_CACHE = ConcurrentHashMap_New() }

func (t *ResourceBundle_Control) GetFormats_String__List(p0 *String) List { return t.Impl_GetFormats_String__List(t, p0) }

func (t *ResourceBundle_Control) GetCandidateLocales_String_Locale__List(p0 *String, p1 *Locale) List { return t.Impl_GetCandidateLocales_String_Locale__List(t, p0, p1) }

func (t *ResourceBundle_Control) GetFallbackLocale_String_Locale__Locale(p0 *String, p1 *Locale) *Locale { return t.Impl_GetFallbackLocale_String_Locale__Locale(t, p0, p1) }

func (t *ResourceBundle_Control) GetTimeToLive_String_Locale__J(p0 *String, p1 *Locale) int64 { return t.Impl_GetTimeToLive_String_Locale__J(t, p0, p1) }

func (t *ResourceBundle_Control) ToBundleName_String_Locale__String(p0 *String, p1 *Locale) *String { return t.Impl_ToBundleName_String_Locale__String(t, p0, p1) }

func (t *ResourceBundle_Control) ToResourceName_String_String__String(p0, p1 *String) *String { return t.Impl_ToResourceName_String_String__String(t, p0, p1) }

func (t *ResourceBundle_Control) Ref() any { if t == nil { return nil }; return t }

func (t *ResourceBundle_Control) GetClass__Class() *Class { return ResourceBundle_Control_class }

func (t *ResourceBundle_Control) ToString__String() *String { return Object_toString(t) }

func (t *ResourceBundle_Control) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ResourceBundle_Control) CloneShallow() any { panic(CloneNotSupported(t)) }

func ResourceBundle_Control_InstanceOf(x any) bool { _, ok := x.(ResourceBundle_Control_I); return ok }

func ResourceBundle_Control_Cast(x any) ResourceBundle_Control_I { if x == nil { return nil }; v, ok := x.(ResourceBundle_Control_I); if !ok { panic(ClassCast(x, ResourceBundle_Control_class)) }; return v }



type ResourceBundle_NoFallbackControl struct{ ResourceBundle_SingleFormatControl }

var ResourceBundle_NoFallbackControl_NO_FALLBACK ResourceBundle_Control_I

var ResourceBundle_NoFallbackControl_PROPERTIES_ONLY_NO_FALLBACK ResourceBundle_Control_I

var ResourceBundle_NoFallbackControl_CLASS_ONLY_NO_FALLBACK ResourceBundle_Control_I

var ResourceBundle_NoFallbackControl_init ClassInit

func ResourceBundle_NoFallbackControl_Init() { if !ResourceBundle_NoFallbackControl_init.Done() { ResourceBundle_NoFallbackControl_init.Run(ResourceBundle_NoFallbackControl_clinit) } }

func ResourceBundle_NoFallbackControl_clinit() { ResourceBundle_SingleFormatControl_Init(); ResourceBundle_NoFallbackControl_NO_FALLBACK = ResourceBundle_NoFallbackControl_New_List(ResourceBundle_Control_FORMAT_DEFAULT); ResourceBundle_NoFallbackControl_PROPERTIES_ONLY_NO_FALLBACK = ResourceBundle_NoFallbackControl_New_List(ResourceBundle_Control_FORMAT_PROPERTIES); ResourceBundle_NoFallbackControl_CLASS_ONLY_NO_FALLBACK = ResourceBundle_NoFallbackControl_New_List(ResourceBundle_Control_FORMAT_CLASS) }

func (t *ResourceBundle_NoFallbackControl) GetFormats_String__List(p0 *String) List { return t.Impl_GetFormats_String__List(t, p0) }

func (t *ResourceBundle_NoFallbackControl) GetCandidateLocales_String_Locale__List(p0 *String, p1 *Locale) List { return t.Impl_GetCandidateLocales_String_Locale__List(t, p0, p1) }

func (t *ResourceBundle_NoFallbackControl) GetTimeToLive_String_Locale__J(p0 *String, p1 *Locale) int64 { return t.Impl_GetTimeToLive_String_Locale__J(t, p0, p1) }

func (t *ResourceBundle_NoFallbackControl) ToBundleName_String_Locale__String(p0 *String, p1 *Locale) *String { return t.Impl_ToBundleName_String_Locale__String(t, p0, p1) }

func (t *ResourceBundle_NoFallbackControl) ToResourceName_String_String__String(p0, p1 *String) *String { return t.Impl_ToResourceName_String_String__String(t, p0, p1) }

func (t *ResourceBundle_NoFallbackControl) Ref() any { if t == nil { return nil }; return t }

func (t *ResourceBundle_NoFallbackControl) GetClass__Class() *Class { return ResourceBundle_NoFallbackControl_class }

func (t *ResourceBundle_NoFallbackControl) ToString__String() *String { return Object_toString(t) }

func (t *ResourceBundle_NoFallbackControl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ResourceBundle_NoFallbackControl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ResourceBundle_NoFallbackControl_InstanceOf(x any) bool { _, ok := x.(*ResourceBundle_NoFallbackControl); return ok }

func ResourceBundle_NoFallbackControl_Cast(x any) *ResourceBundle_NoFallbackControl { if x == nil { return nil }; v, ok := x.(*ResourceBundle_NoFallbackControl); if !ok { panic(ClassCast(x, ResourceBundle_NoFallbackControl_class)) }; return v }



type ResourceBundle_SingleFormatControl struct{ ResourceBundle_Control; F_formats List }

type ResourceBundle_SingleFormatControl_I interface{ ResourceBundle_Control_I; Self_ResourceBundle_SingleFormatControl() *ResourceBundle_SingleFormatControl; GetFormats_String__List(p0 *String) List }

func (t *ResourceBundle_SingleFormatControl) Self_ResourceBundle_SingleFormatControl() *ResourceBundle_SingleFormatControl { return t }

var ResourceBundle_SingleFormatControl_PROPERTIES_ONLY ResourceBundle_Control_I

var ResourceBundle_SingleFormatControl_CLASS_ONLY ResourceBundle_Control_I

var ResourceBundle_SingleFormatControl_init ClassInit

func ResourceBundle_SingleFormatControl_Init() { if !ResourceBundle_SingleFormatControl_init.Done() { ResourceBundle_SingleFormatControl_init.Run(ResourceBundle_SingleFormatControl_clinit) } }

func ResourceBundle_SingleFormatControl_clinit() { ResourceBundle_Control_Init(); ResourceBundle_SingleFormatControl_PROPERTIES_ONLY = ResourceBundle_SingleFormatControl_New_List(ResourceBundle_Control_FORMAT_PROPERTIES); ResourceBundle_SingleFormatControl_CLASS_ONLY = ResourceBundle_SingleFormatControl_New_List(ResourceBundle_Control_FORMAT_CLASS) }

func (t *ResourceBundle_SingleFormatControl) GetFormats_String__List(p0 *String) List { return t.Impl_GetFormats_String__List(t, p0) }

func (t *ResourceBundle_SingleFormatControl) GetCandidateLocales_String_Locale__List(p0 *String, p1 *Locale) List { return t.Impl_GetCandidateLocales_String_Locale__List(t, p0, p1) }

func (t *ResourceBundle_SingleFormatControl) GetFallbackLocale_String_Locale__Locale(p0 *String, p1 *Locale) *Locale { return t.Impl_GetFallbackLocale_String_Locale__Locale(t, p0, p1) }

func (t *ResourceBundle_SingleFormatControl) GetTimeToLive_String_Locale__J(p0 *String, p1 *Locale) int64 { return t.Impl_GetTimeToLive_String_Locale__J(t, p0, p1) }

func (t *ResourceBundle_SingleFormatControl) ToBundleName_String_Locale__String(p0 *String, p1 *Locale) *String { return t.Impl_ToBundleName_String_Locale__String(t, p0, p1) }

func (t *ResourceBundle_SingleFormatControl) ToResourceName_String_String__String(p0, p1 *String) *String { return t.Impl_ToResourceName_String_String__String(t, p0, p1) }

func (t *ResourceBundle_SingleFormatControl) Ref() any { if t == nil { return nil }; return t }

func (t *ResourceBundle_SingleFormatControl) GetClass__Class() *Class { return ResourceBundle_SingleFormatControl_class }

func (t *ResourceBundle_SingleFormatControl) ToString__String() *String { return Object_toString(t) }

func (t *ResourceBundle_SingleFormatControl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ResourceBundle_SingleFormatControl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ResourceBundle_SingleFormatControl_InstanceOf(x any) bool { _, ok := x.(ResourceBundle_SingleFormatControl_I); return ok }

func ResourceBundle_SingleFormatControl_Cast(x any) ResourceBundle_SingleFormatControl_I { if x == nil { return nil }; v, ok := x.(ResourceBundle_SingleFormatControl_I); if !ok { panic(ClassCast(x, ResourceBundle_SingleFormatControl_class)) }; return v }
