//line java_net_SocketImpl.ae:1
package jrt







func SocketImpl_CreatePlatformSocketImpl_Z__SocketImpl(server bool) SocketImpl_I {
	return HostSocketImpl_New_Z(server)
}












func (t *SocketImpl) Ctor(this SocketImpl_I) {}

























func (t *SocketImpl) Impl_CloseQuietly__V(this SocketImpl_I) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
								this.Close__V(); return nil }(); if tmp1 != nil { if IOException_InstanceOf(tmp1) { var ignore IOException_I = IOException_Cast(tmp1); _ = ignore } else { panic(tmp1) } } }

func (t *SocketImpl) Impl_ShutdownInput__V(this SocketImpl_I) {
	panic(Thrown(IOException_New_String(Lit_1370)))
}
func (t *SocketImpl) Impl_ShutdownOutput__V(this SocketImpl_I) {
	panic(Thrown(IOException_New_String(Lit_1370)))
}
func (t *SocketImpl) Impl_GetFileDescriptor__FileDescriptor(this SocketImpl_I) *FileDescriptor { panic(A2g_NotTranslated("java.net.SocketImpl.getFileDescriptor()Ljava/io/FileDescriptor;")) }

func (t *SocketImpl) Impl_GetInetAddress__InetAddress(this SocketImpl_I) InetAddress_I { return t.F_address }

func (t *SocketImpl) Impl_GetPort__I(this SocketImpl_I) int32 { return t.F_port }

func (t *SocketImpl) Impl_SupportsUrgentData__Z(this SocketImpl_I) bool { return false }



func (t *SocketImpl) Impl_GetLocalPort__I(this SocketImpl_I) int32 { return t.F_localport }

func (t *SocketImpl) Impl_ToString__String(this SocketImpl_I) *String {
	return Concat(Lit_1367, StrOfObj(this.GetInetAddress__InetAddress()), Lit_1368, StrOfInt(this.GetPort__I()), Lit_1344, StrOfInt(this.GetLocalPort__I()), Lit_1189)
}






func (t *SocketImpl) Impl_Reset__V(this SocketImpl_I) {
	t.F_fd = nil
	t.F_address = nil
	t.F_port = 0
	t.F_localport = 0
}
func (t *SocketImpl) Impl_SetPerformancePreferences_I_I_I__V(this SocketImpl_I, p0, p1, p2 int32) { panic(A2g_NotTranslated("java.net.SocketImpl.setPerformancePreferences(III)V")) }




func (t *SocketImpl) Impl_SetOption_SocketOption_O__V(this SocketImpl_I, name SocketOption, value any) {


	Objects_RequireNonNull_O__O(name)
	panic(Thrown(UnsupportedOperationException_New_String(Concat(Lit_1371, StrOfObj(name), Lit_1372))))
}
func (t *SocketImpl) Impl_GetOption_SocketOption__O(this SocketImpl_I, name SocketOption) any {

	Objects_RequireNonNull_O__O(name)
	panic(Thrown(UnsupportedOperationException_New_String(Concat(Lit_1371, StrOfObj(name), Lit_1372))))
}
func (t *SocketImpl) Impl_CopyOptionsTo_SocketImpl__V(this, target SocketImpl_I) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var timeout any = this.GetOption_I__O(4102)
		if Integer_InstanceOf(timeout) { target.SetOption_I_O__V(4102, timeout) } }; return nil }(); if /*line :103:1*/ tmp1 != nil { if IOException_InstanceOf(tmp1) { var ignore IOException_I = IOException_Cast(tmp1); _ = ignore } else { panic(tmp1) } } }




func (t *SocketImpl) Impl_SupportedOptions__Set(this SocketImpl_I) Set {
	return Set_Of__Set()
}


type SocketImpl struct{ Object; F_fd *FileDescriptor; F_address InetAddress_I; F_port, F_localport int32 }

type SocketImpl_I interface{ Object_I; SocketOptions; Self_SocketImpl() *SocketImpl; Create_Z__V(p0 bool); Connect_String_I__V(p0 *String, p1 int32); Connect_InetAddress_I__V(p0 InetAddress_I, p1 int32); Connect_SocketAddress_I__V(p0 SocketAddress_I, p1 int32); Bind_InetAddress_I__V(p0 InetAddress_I, p1 int32); Listen_I__V(p0 int32); Accept_SocketImpl__V(p0 SocketImpl_I); GetInputStream__InputStream() InputStream_I; GetOutputStream__OutputStream() OutputStream_I; Available__I() int32; Close__V(); CloseQuietly__V(); ShutdownInput__V(); ShutdownOutput__V(); GetFileDescriptor__FileDescriptor() *FileDescriptor; GetInetAddress__InetAddress() InetAddress_I; GetPort__I() int32; SupportsUrgentData__Z() bool; SendUrgentData_I__V(p0 int32); GetLocalPort__I() int32; Reset__V(); SetPerformancePreferences_I_I_I__V(p0, p1, p2 int32); SetOption_SocketOption_O__V(p0 SocketOption, p1 any); GetOption_SocketOption__O(p0 SocketOption) any; CopyOptionsTo_SocketImpl__V(p0 SocketImpl_I); SupportedOptions__Set() Set }

func (t *SocketImpl) Self_SocketImpl() *SocketImpl { return t }

func (t *SocketImpl) Is_SocketOptions() {}

func SocketImpl_InstanceOf(x any) bool { _, ok := x.(SocketImpl_I); return ok }

func SocketImpl_Cast(x any) SocketImpl_I { if x == nil { return nil }; v, ok := x.(SocketImpl_I); if !ok { panic(ClassCast(x, SocketImpl_class)) }; return v }
