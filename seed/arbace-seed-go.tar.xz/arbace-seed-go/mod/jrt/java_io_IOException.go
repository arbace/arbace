//line java_io_IOException.ae:1
package jrt








func IOException_New() *IOException { t := &IOException{}; t.Ctor(t); return t }
//line :10:1
func (t *IOException) Ctor(this IOException_I) { t.Exception.Ctor(this) }

func IOException_New_String(p0 *String) *IOException { t := &IOException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *IOException) Ctor_String(this IOException_I, message *String) { t.Exception.Ctor_String(this, message) }

func IOException_New_String_Throwable(p0 *String, p1 Throwable_I) *IOException { t := &IOException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :14:1
func (t *IOException) Ctor_String_Throwable(this IOException_I, message *String, cause Throwable_I) { t.Exception.Ctor_String_Throwable(this, message, cause) }


func IOException_New_Throwable(p0 Throwable_I) *IOException { t := &IOException{}; t.Ctor_Throwable(t, p0); return t }
//line :17:1
func (t *IOException) Ctor_Throwable(this IOException_I, cause Throwable_I) { t.Exception.Ctor_Throwable(this, cause) }










type IOException struct{ Exception }

type IOException_I interface{ Exception_I; Serializable; Self_IOException() *IOException }

func (t *IOException) Self_IOException() *IOException { return t }

const IOException_serialVersionUID int64 = 7818375828146090155

func (t *IOException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IOException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IOException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IOException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IOException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IOException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IOException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IOException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IOException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IOException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IOException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IOException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IOException) Ref() any { if t == nil { return nil }; return t }

func (t *IOException) GetClass__Class() *Class { return IOException_class }

func (t *IOException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IOException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IOException_InstanceOf(x any) bool { _, ok := x.(IOException_I); return ok }

func IOException_Cast(x any) IOException_I { if x == nil { return nil }; v, ok := x.(IOException_I); if !ok { panic(ClassCast(x, IOException_class)) }; return v }
