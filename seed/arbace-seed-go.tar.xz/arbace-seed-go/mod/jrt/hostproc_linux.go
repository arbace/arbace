//line hostproc_linux.ae:1
//go:build linux

package jrt

import (
	"bytes"
	"errors"
	"io"
	"os"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"unsafe"
)




// osChild is a child OSHost.Start started; done is closed when the waiting goroutine has
// reaped it, status then its JDK-encoded status.
type osChild /*line :25:1*/ struct{ p *os.Process; done chan struct{}; status int }

func (c *osChild) Pid() int { return c.p.Pid }

func (c *osChild) Wait() int {
	<-c.done
	return c.status
}
func (c *osChild) Signal(force bool) error {
	var sig syscall.Signal = syscall.SIGTERM
	if force {
		sig = syscall.SIGKILL }
	return c.p.Signal(sig) }
// waitStatus is the JDK's encoding of a wait status (ProcessHandleImpl_unix.c's
// waitForProcessExit0): the exit status, or 0x80 plus the terminating signal.
//line :39:1
func waitStatus(ws syscall.WaitStatus) int {



	if
		ws.Exited() { return ws.ExitStatus()
		} else if ws.Signaled() { return 128 + int(ws.Signal()) }
	return int(ws) }
// errnoOf is the system error number of err (EIO when it has none).
func errnoOf(err error) syscall.Errno {

	var e syscall.Errno = 0
	if errors.As(err, &e) {
		return e
	}; return syscall.EIO }
// checkDir is the error the child's chdir(dir) would meet (ENOENT, ENOTDIR, EACCES ...), or 0.
func checkDir(dir string) syscall.Errno {


	var st syscall.Stat_t = syscall.Stat_t{}
	{ err := syscall.Stat(dir, &st)
		if err != nil {
			return errnoOf(err) } }
	if st.Mode&syscall.S_IFMT != syscall.S_IFDIR {
		return syscall.ENOTDIR }
	{ err := syscall.Access(dir, 1)
		if err != nil {
			return errnoOf(err)
		}
	}; return 0 }
func (h OSHost) Start(path string, argv, env []string, dir string, stdio /*line :70:1*/[]HostStdio, errToOut bool) (HostChild,
	[]HostFile, error) {
	if dir != "" {
		e := checkDir(dir)
		if e != 0 {
			return nil, nil, &HostProcError{Chdir: true, Errno: int(e)} } }
	files := make([]*os.File, 3)
	own := []*os.File{os.Stdin, os.Stdout, os.Stderr}
	pipes := make([]HostFile, 3)
	var childEnds []*os.File = nil
	var parentEnds []*os.File = nil
	fail := func(e syscall.Errno) (HostChild, []HostFile, error) {
		for _, f := range childEnds { f.Close() }
		for _, f := range parentEnds { f.Close() }
		return nil, nil, &HostProcError{Errno: int(e)} }
	for i, s := range stdio {
		if i == 2 && errToOut {



			files[2] = files[1]
			if s.Kind == StdioPipe {
				r, w, err := os.Pipe()
				if err != nil {
					return fail(errnoOf(err)) }
				childEnds = append(childEnds, w)
				parentEnds = append(parentEnds, r)
				pipes[2] = &procPipe{f: r} }
			continue }
		switch s.Kind {
		case StdioPipe:
			r, w, err := os.Pipe()
			if err != nil {
				return fail(errnoOf(err)) }
			if i == 0 {
				files[0] = r
				childEnds = append(childEnds, r)
				parentEnds = append(parentEnds, w)
				pipes[0] = &procPipe{f: w} } else {
					files[i] = w
					childEnds = append(childEnds, w)
					parentEnds = append(parentEnds, r)
					pipes[i] = &procPipe{f: r} }
		case StdioInherit:
			files[i] = own[i]
		default:
			f := osFileOf(s.File)
			if f == nil {
				return fail(syscall.EBADF) }
			files[i] = f} }
	p, err := os.StartProcess(path, argv, &os.ProcAttr{Dir: dir, Env: env, Files: files})
	for _, f := range childEnds { f.Close() }
	if err != nil {
		for _, f := range parentEnds { f.Close() }
		return nil, nil, &HostProcError{Errno: int(errnoOf(err))} }
	c := &osChild{p: p, done: make(chan struct{})}
	go func() {
		{ st, werr := p.Wait()
			if werr != nil {
				c.status = -1 } else {
					c.status = waitStatus(st.Sys().(syscall.WaitStatus)) } }
		close(c.done) }()
	return c, pipes, nil }
// osFileOf is the *os.File of an open file of the host (Host.Open's, or a pipe end), or nil.
func osFileOf(f HostFile,

) *os.File {
	{ of, ok := f.(*os.File)
		if ok {
			return of } }
	{ pp, ok := f.(*procPipe)
		if ok {
			return pp.f
		}
	}; return nil }
// procPipe is the program's end of a pipe to or from a child, a HostFile of jrt's file table
// (HostFiles): reads and writes fail with the C library's texts, as the JVM's do (Broken pipe); a
// read on an end another thread closed ends the stream; Available is FIONREAD's count.
type procPipe /*line :152:1*/ struct{ f *os.File }

func (p *procPipe) Read(b []byte) (int, error) {
	n, err := p.f.Read(b)
	if err != nil && errors.Is(err, os.ErrClosed) {
		return n, io.EOF }
	if err != nil && !errors.Is(err, io.EOF) {
		return n, errors.New(ErrnoText(int(errnoOf(err)))) }
	return n, err
}
func (p *procPipe) Write(b []byte) (int, error) {
	n, err := p.f.Write(b)
	if err != nil {
		if errors.Is(err, os.ErrClosed) {
			return n, errors.New("Stream Closed") }
		return n, errors.New(ErrnoText(int(errnoOf(err)))) }
	return n, nil
}
func (p *procPipe) Close() error { return p.f.Close() }

func (p *procPipe) Seek(offset int64, whence int) (int64, error) {
	return 0, errors.New(ErrnoText(int(syscall.ESPIPE)))
}
func (p *procPipe) Available() (int, error) {
	rc, err := p.f.SyscallConn()
	if err != nil {
		return 0, err }
	var n int32 = 0
	rc.Control(func(fd uintptr) {
		syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TIOCINQ),
			uintptr(unsafe.Pointer(&n))) })
	return int(n), nil
}



func (h OSHost) Pid() int { return os.Getpid() }

func (h OSHost) Kill(pid int, force bool) error {
	var sig syscall.Signal = syscall.SIGTERM
	if force {
		sig = syscall.SIGKILL }
	return syscall.Kill(pid, sig)
}
const (
	// clockTicks is sysconf(_SC_CLK_TCK): Linux's USER_HZ, 100 on every
	// architecture.
	clockTicks int64 = 100
)
var bootOnce sync.Once
var bootMillis int64 = 0
// bootTimeMillis is getBoottime: /proc/stat's btime, in milliseconds since the epoch (0 when
// unknown).
//line :204:1
func bootTimeMillis() int64 {



	bootOnce.Do(
		func() {
			b, err := os.ReadFile("/proc/stat")
			if err != nil {
				return }
			for _, line := range strings.Split(string(b), "\n") {
				if strings.HasPrefix(line, "btime ") {
					{ v, perr := strconv.ParseInt(strings.TrimSpace(line[6:]), 10, 64)
						if perr == nil {
							bootMillis = v * 1000 } }
					return
				}
			} }); return bootMillis }
func (h OSHost) ProcStat(pid int) (HostProcStat, bool) {

	b, err := os.ReadFile("/proc/" + strconv.Itoa(pid) + "/stat")
	if err != nil {
		return HostProcStat{}, false }
	s := string(b)
	i := strings.LastIndexByte(s, ')')
	if strings.IndexByte(s, '(') < 0 || i < 0 {
		return HostProcStat{}, false }
	fs := strings.Fields(s[i+1:])

	if len(fs) < 20 {
		return HostProcStat{Ppid: 0}, true }
	ppid, e1 := strconv.Atoi(fs[1])
	ut, e2 := strconv.ParseUint(fs[11], 10, 64)
	st, e3 := strconv.ParseUint(fs[12], 10, 64)
	start, e4 := strconv.ParseUint(fs[19], 10, 64)
	if e1 != nil || e2 != nil || e3 != nil || e4 != nil {
					return HostProcStat{Ppid: 0}, true }
	return HostProcStat{Ppid: ppid,

		TotalNanos:  int64(ut+st) * (1000000000 / clockTicks),
		StartMillis: bootTimeMillis() + int64(start)*1000/clockTicks,
	}, true
}
func (h OSHost) Pids() []int {
	f, err := os.Open("/proc")
	if err != nil {
		return nil }
	defer f.Close()
	names, _ := f.Readdirnames(-1)
	var pids []int = nil
	for _, n := range names {
		pid, aerr := strconv.Atoi(n)
		if aerr == nil && pid > 0 {
			pids = append(pids, pid)
		} }; return pids }
// userName is the name of user uid, as getpwuid finds it in /etc/passwd; "" when none.
func userName(uid uint32) string {


	b, err := os.ReadFile("/etc/passwd")
	u := strconv.FormatUint(uint64(uid), 10)
	if err != nil {
		return "" }
	for _, line := range strings.Split(string(b), "\n") {
		fs := strings.Split(line, ":")
		if len(fs) >= 3 && fs[2] == u {
			return fs[0]
		}
	}; return "" }
func (h OSHost) ProcInfo(pid int) HostProcInfo {

	info := HostProcInfo{}
	dir := "/proc/" + strconv.Itoa(pid)
	var st syscall.Stat_t = syscall.Stat_t{}
	if syscall.Stat(dir, &st) == nil {
		info.User = userName(st.Uid) }
	f, err := os.Open(dir + "/cmdline")
	if err != nil {
		return info }
	defer f.Close()

	{ exe, lerr := os.Readlink(dir + "/exe")
		if lerr == nil && exe != "" {
			info.Command = exe
		} }
	{ page := os.Getpagesize()
		buf := make([]byte, page)
		n := 0
		for n < page {
			k, rerr := f.Read(buf[n:])
			n = n + k
			if rerr != nil {
				break } }
		cmdline := buf[0:n]
		truncated := n == page && buf[page-1] != 0
		if n > 0 && (info.Command == "" || truncated) {

			info.CommandLine =
				string(bytes.ReplaceAll(cmdline, []byte{0}, []byte{32})) }
		if !truncated {


			parts := strings.Split(string(cmdline), "\x00")
			k := 0
			for k < len(parts) && parts[k] != "" {
				k = k + 1 }
			if k >= 1 {
				info.HasArgs = true
				info.Args = append([]string{}, parts[1:k]...)
			}
		}
	}
	return info
}
