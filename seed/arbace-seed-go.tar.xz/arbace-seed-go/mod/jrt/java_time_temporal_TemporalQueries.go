//line java_time_temporal_TemporalQueries.ae:1
package jrt







func TemporalQueries_New() *TemporalQueries { TemporalQueries_Init(); t := &TemporalQueries{}; t.Ctor(); return t }
//line :9:1
func (t *TemporalQueries) Ctor() { panic(A2g_NotTranslated("java.time.temporal.TemporalQueries.<init>()V")) }

func TemporalQueries_ZoneId__TemporalQuery() TemporalQuery { TemporalQueries_Init(); return TemporalQueries_ZONE_ID }


func TemporalQueries_Chronology__TemporalQuery() TemporalQuery { TemporalQueries_Init(); return TemporalQueries_CHRONO }


func TemporalQueries_Precision__TemporalQuery() TemporalQuery { TemporalQueries_Init(); return TemporalQueries_PRECISION }


func TemporalQueries_Zone__TemporalQuery() TemporalQuery { TemporalQueries_Init(); return TemporalQueries_ZONE }


func TemporalQueries_Offset__TemporalQuery() TemporalQuery { TemporalQueries_Init(); return TemporalQueries_OFFSET }


func TemporalQueries_LocalDate__TemporalQuery() TemporalQuery { TemporalQueries_Init(); return TemporalQueries_LOCAL_DATE }


func TemporalQueries_LocalTime__TemporalQuery() TemporalQuery { TemporalQueries_Init(); return TemporalQueries_LOCAL_TIME }




func (t *TemporalQueries_1) QueryFrom_TemporalAccessor__ZoneId(temporal TemporalAccessor) ZoneId_I {
	var tmp1 TemporalQuery; TemporalQueries_Init(); tmp1 = TemporalQueries_ZONE_ID; return ZoneId_Cast(temporal.Query_TemporalQuery__O(tmp1))
}
func (t *TemporalQueries_1) ToString__String() *String { return Lit_2520 }



func (t *TemporalQueries_2) QueryFrom_TemporalAccessor__Chronology(temporal TemporalAccessor) Chronology {
	var tmp1 TemporalQuery; TemporalQueries_Init(); tmp1 = TemporalQueries_CHRONO; return Chronology_Cast(temporal.Query_TemporalQuery__O(tmp1))
}
func (t *TemporalQueries_2) ToString__String() *String { return Lit_2521 }



func (t *TemporalQueries_3) QueryFrom_TemporalAccessor__TemporalUnit(temporal TemporalAccessor) TemporalUnit {
	var tmp1 TemporalQuery; TemporalQueries_Init(); tmp1 = TemporalQueries_PRECISION; return TemporalUnit_Cast(temporal.Query_TemporalQuery__O(tmp1))
}
func (t *TemporalQueries_3) ToString__String() *String { return Lit_2522 }



func (t *TemporalQueries_4) QueryFrom_TemporalAccessor__ZoneOffset(temporal TemporalAccessor) *ZoneOffset {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; if temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp1)) {
		var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_OFFSET_SECONDS; return ZoneOffset_OfTotalSeconds_I__ZoneOffset(temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2))) } else {
//line :56:1
			return nil
		}
}
func (t *TemporalQueries_4) ToString__String() *String { return Lit_2523 }



func (t *TemporalQueries_5) QueryFrom_TemporalAccessor__ZoneId(temporal TemporalAccessor) ZoneId_I {
	var zone ZoneId_I; var tmp1 TemporalQuery; TemporalQueries_Init(); tmp1 = TemporalQueries_ZONE_ID; zone = ZoneId_Cast(temporal.Query_TemporalQuery__O(tmp1))
	if !(zone == nil) { return zone } else { var tmp2 TemporalQuery; TemporalQueries_Init(); tmp2 = TemporalQueries_OFFSET; return ZoneId_Cast(temporal.Query_TemporalQuery__O(tmp2))
	} }
func (t *TemporalQueries_5) ToString__String() *String { return Lit_2524 }



func (t *TemporalQueries_6) QueryFrom_TemporalAccessor__LocalDate(temporal TemporalAccessor) *LocalDate {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; if temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp1)) {
		var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_EPOCH_DAY; return LocalDate_OfEpochDay_J__LocalDate(temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2))) } else {
//line :72:1
			return nil
		}
}
func (t *TemporalQueries_6) ToString__String() *String { return Lit_2525 }



func (t *TemporalQueries_7) QueryFrom_TemporalAccessor__LocalTime(temporal TemporalAccessor) *LocalTime {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_DAY; if temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp1)) {
		var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_NANO_OF_DAY; return LocalTime_OfNanoOfDay_J__LocalTime(temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2))) } else {
//line :80:1
			return nil
		}
}
func (t *TemporalQueries_7) ToString__String() *String { return Lit_2526 }



type TemporalQueries struct{ Object }

var TemporalQueries_ZONE_ID TemporalQuery

var TemporalQueries_CHRONO TemporalQuery

var TemporalQueries_PRECISION TemporalQuery

var TemporalQueries_OFFSET TemporalQuery

var TemporalQueries_ZONE TemporalQuery

var TemporalQueries_LOCAL_DATE TemporalQuery

var TemporalQueries_LOCAL_TIME TemporalQuery

var TemporalQueries_init ClassInit

func TemporalQueries_Init() { if !TemporalQueries_init.Done() { TemporalQueries_init.Run(TemporalQueries_clinit) } }

func TemporalQueries_clinit() { TemporalQueries_ZONE_ID = TemporalQueries_1_New(); TemporalQueries_CHRONO = TemporalQueries_2_New(); TemporalQueries_PRECISION = TemporalQueries_3_New(); TemporalQueries_OFFSET = TemporalQueries_4_New(); TemporalQueries_ZONE = TemporalQueries_5_New(); TemporalQueries_LOCAL_DATE = TemporalQueries_6_New(); TemporalQueries_LOCAL_TIME = TemporalQueries_7_New() }

func (t *TemporalQueries) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries) GetClass__Class() *Class { return TemporalQueries_class }

func (t *TemporalQueries) ToString__String() *String { return Object_toString(t) }

func (t *TemporalQueries) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries); return ok }

func TemporalQueries_Cast(x any) *TemporalQueries { if x == nil { return nil }; v, ok := x.(*TemporalQueries); if !ok { panic(ClassCast(x, TemporalQueries_class)) }; return v }



type TemporalQueries_1 struct{ Object }

func (t *TemporalQueries_1) Is_TemporalQuery() {}

func TemporalQueries_1_New() *TemporalQueries_1 { t := &TemporalQueries_1{}; t.Ctor(); return t }

func (t *TemporalQueries_1) Ctor() {}

func (t *TemporalQueries_1) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.QueryFrom_TemporalAccessor__ZoneId(p0) }

func (t *TemporalQueries_1) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries_1) GetClass__Class() *Class { return TemporalQueries_1_class }

func (t *TemporalQueries_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_1_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries_1); return ok }

func TemporalQueries_1_Cast(x any) *TemporalQueries_1 { if x == nil { return nil }; v, ok := x.(*TemporalQueries_1); if !ok { panic(ClassCast(x, TemporalQueries_1_class)) }; return v }



type TemporalQueries_2 struct{ Object }

func (t *TemporalQueries_2) Is_TemporalQuery() {}

func TemporalQueries_2_New() *TemporalQueries_2 { t := &TemporalQueries_2{}; t.Ctor(); return t }

func (t *TemporalQueries_2) Ctor() {}

func (t *TemporalQueries_2) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.QueryFrom_TemporalAccessor__Chronology(p0) }

func (t *TemporalQueries_2) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries_2) GetClass__Class() *Class { return TemporalQueries_2_class }

func (t *TemporalQueries_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_2_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries_2); return ok }

func TemporalQueries_2_Cast(x any) *TemporalQueries_2 { if x == nil { return nil }; v, ok := x.(*TemporalQueries_2); if !ok { panic(ClassCast(x, TemporalQueries_2_class)) }; return v }



type TemporalQueries_3 struct{ Object }

func (t *TemporalQueries_3) Is_TemporalQuery() {}

func TemporalQueries_3_New() *TemporalQueries_3 { t := &TemporalQueries_3{}; t.Ctor(); return t }

func (t *TemporalQueries_3) Ctor() {}

func (t *TemporalQueries_3) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.QueryFrom_TemporalAccessor__TemporalUnit(p0) }

func (t *TemporalQueries_3) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries_3) GetClass__Class() *Class { return TemporalQueries_3_class }

func (t *TemporalQueries_3) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_3_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries_3); return ok }

func TemporalQueries_3_Cast(x any) *TemporalQueries_3 { if x == nil { return nil }; v, ok := x.(*TemporalQueries_3); if !ok { panic(ClassCast(x, TemporalQueries_3_class)) }; return v }



type TemporalQueries_4 struct{ Object }

func (t *TemporalQueries_4) Is_TemporalQuery() {}

func TemporalQueries_4_New() *TemporalQueries_4 { t := &TemporalQueries_4{}; t.Ctor(); return t }

func (t *TemporalQueries_4) Ctor() {}

func (t *TemporalQueries_4) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.QueryFrom_TemporalAccessor__ZoneOffset(p0).Ref() }

func (t *TemporalQueries_4) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries_4) GetClass__Class() *Class { return TemporalQueries_4_class }

func (t *TemporalQueries_4) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries_4) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_4_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries_4); return ok }

func TemporalQueries_4_Cast(x any) *TemporalQueries_4 { if x == nil { return nil }; v, ok := x.(*TemporalQueries_4); if !ok { panic(ClassCast(x, TemporalQueries_4_class)) }; return v }



type TemporalQueries_5 struct{ Object }

func (t *TemporalQueries_5) Is_TemporalQuery() {}

func TemporalQueries_5_New() *TemporalQueries_5 { t := &TemporalQueries_5{}; t.Ctor(); return t }

func (t *TemporalQueries_5) Ctor() {}

func (t *TemporalQueries_5) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.QueryFrom_TemporalAccessor__ZoneId(p0) }

func (t *TemporalQueries_5) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries_5) GetClass__Class() *Class { return TemporalQueries_5_class }

func (t *TemporalQueries_5) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries_5) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_5_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries_5); return ok }

func TemporalQueries_5_Cast(x any) *TemporalQueries_5 { if x == nil { return nil }; v, ok := x.(*TemporalQueries_5); if !ok { panic(ClassCast(x, TemporalQueries_5_class)) }; return v }



type TemporalQueries_6 struct{ Object }

func (t *TemporalQueries_6) Is_TemporalQuery() {}

func TemporalQueries_6_New() *TemporalQueries_6 { t := &TemporalQueries_6{}; t.Ctor(); return t }

func (t *TemporalQueries_6) Ctor() {}

func (t *TemporalQueries_6) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.QueryFrom_TemporalAccessor__LocalDate(p0).Ref() }

func (t *TemporalQueries_6) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries_6) GetClass__Class() *Class { return TemporalQueries_6_class }

func (t *TemporalQueries_6) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries_6) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_6_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries_6); return ok }

func TemporalQueries_6_Cast(x any) *TemporalQueries_6 { if x == nil { return nil }; v, ok := x.(*TemporalQueries_6); if !ok { panic(ClassCast(x, TemporalQueries_6_class)) }; return v }



type TemporalQueries_7 struct{ Object }

func (t *TemporalQueries_7) Is_TemporalQuery() {}

func TemporalQueries_7_New() *TemporalQueries_7 { t := &TemporalQueries_7{}; t.Ctor(); return t }

func (t *TemporalQueries_7) Ctor() {}

func (t *TemporalQueries_7) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.QueryFrom_TemporalAccessor__LocalTime(p0).Ref() }

func (t *TemporalQueries_7) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQueries_7) GetClass__Class() *Class { return TemporalQueries_7_class }

func (t *TemporalQueries_7) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TemporalQueries_7) CloneShallow() any { panic(CloneNotSupported(t)) }

func TemporalQueries_7_InstanceOf(x any) bool { _, ok := x.(*TemporalQueries_7); return ok }

func TemporalQueries_7_Cast(x any) *TemporalQueries_7 { if x == nil { return nil }; v, ok := x.(*TemporalQueries_7); if !ok { panic(ClassCast(x, TemporalQueries_7_class)) }; return v }
