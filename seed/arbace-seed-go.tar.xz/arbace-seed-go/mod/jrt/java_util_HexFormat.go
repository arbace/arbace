//line java_util_HexFormat.ae:1
package jrt







func (t *HexFormat) ParseHex_C1_I_I__B1(chars *CharArray, fromIndex, toIndex int32) *ByteArray {
	Objects_RequireNonNull_O_String__O(chars.Ref(), Lit_2704)
	Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, int32(len(chars.A)))
	return t.ParseHex_CharSequence__B1(String_New_C1_I_I(chars, fromIndex, toIndex-fromIndex))
}





















func HexFormat_New_String_String_String_Z(p0, p1, p2 *String, p3 bool) *HexFormat { HexFormat_Init(); t := &HexFormat{}; t.Ctor_String_String_String_Z(p0, p1, p2, p3); return t }
//line :35:1
func (t *HexFormat) Ctor_String_String_String_Z(delimiter, prefix, suffix *String, ucase bool) {
	t.F_delimiter = String_Cast(Objects_RequireNonNull_O_String__O(delimiter.Ref(), Lit_2697))
	t.F_prefix = String_Cast(Objects_RequireNonNull_O_String__O(prefix.Ref(), Lit_1960))
	t.F_suffix = String_Cast(Objects_RequireNonNull_O_String__O(suffix.Ref(), Lit_1961))
	t.F_ucase = ucase
}
func HexFormat_Of__HexFormat() *HexFormat { HexFormat_Init(); return HexFormat_HEX_FORMAT }

func HexFormat_OfDelimiter_String__HexFormat(delimiter *String) *HexFormat { HexFormat_Init()
	return HexFormat_New_String_String_String_Z(delimiter, Lit_69, Lit_69, false)
}
func (t *HexFormat) WithDelimiter_String__HexFormat(delimiter *String) *HexFormat {
	return HexFormat_New_String_String_String_Z(delimiter, t.F_prefix, t.F_suffix, t.F_ucase)
}
func (t *HexFormat) WithPrefix_String__HexFormat(prefix *String) *HexFormat {
	return HexFormat_New_String_String_String_Z(t.F_delimiter, prefix, t.F_suffix, t.F_ucase)
}
func (t *HexFormat) WithSuffix_String__HexFormat(suffix *String) *HexFormat {
	return HexFormat_New_String_String_String_Z(t.F_delimiter, t.F_prefix, suffix, t.F_ucase)
}
func (t *HexFormat) WithUpperCase__HexFormat() *HexFormat {
	if t == HexFormat_HEX_FORMAT { return HexFormat_HEX_UPPER_FORMAT } else {

		return HexFormat_New_String_String_String_Z(t.F_delimiter, t.F_prefix, t.F_suffix, true)
	} }
func (t *HexFormat) WithLowerCase__HexFormat() *HexFormat {
	return HexFormat_New_String_String_String_Z(t.F_delimiter, t.F_prefix, t.F_suffix, false)
}
func (t *HexFormat) Delimiter__String() *String { return t.F_delimiter }

func (t *HexFormat) Prefix__String() *String { return t.F_prefix }

func (t *HexFormat) Suffix__String() *String { return t.F_suffix }

func (t *HexFormat) IsUpperCase__Z() bool { return t.F_ucase }

func (t *HexFormat) FormatHex_B1__String(bytes *ByteArray) *String {
	return t.FormatHex_B1_I_I__String(bytes, 0, int32(len(bytes.A)))
}
func (t *HexFormat) FormatHex_B1_I_I__String(bytes *ByteArray, fromIndex, toIndex int32) *String {
	Objects_RequireNonNull_O_String__O(bytes.Ref(), Lit_2698)
	Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, int32(len(bytes.A)))
	if toIndex-fromIndex == 0 { return Lit_69 } else {

		var s *String = t.FormatOptDelimiter_B1_I_I__String(bytes, fromIndex, toIndex)
		if s == nil {
			var stride int64 = int64(NN(t.F_prefix).Length__I()) + 2 + int64(NN(t.F_suffix).Length__I()) + int64(NN(t.F_delimiter).Length__I()); var capacity int32 = HexFormat_CheckMaxArraySize_J__I(int64(toIndex-fromIndex)*stride - int64(NN(t.F_delimiter).Length__I())); var sb *StringBuilder = StringBuilder_New_I(capacity)









			t.FormatHex_Appendable_B1_I_I__Appendable(Up_StringBuilder_Appendable(sb), bytes, fromIndex, toIndex)
			s = NN(sb).ToString__String() }
//line :79:1
		return s
	}
}













func (t *HexFormat) FormatHex_Appendable_B1__Appendable(out Appendable, bytes *ByteArray) Appendable {
	return t.FormatHex_Appendable_B1_I_I__Appendable(out, bytes, 0, int32(len(bytes.A)))
}
func (t *HexFormat) FormatHex_Appendable_B1_I_I__Appendable(out Appendable, bytes *ByteArray, fromIndex, toIndex int32) Appendable {

	Objects_RequireNonNull_O_String__O(out, Lit_50)
	Objects_RequireNonNull_O_String__O(bytes.Ref(), Lit_2698)
	Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, int32(len(bytes.A)))
	var length int32 = toIndex - fromIndex
	if length > 0 { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var s *String = t.FormatOptDelimiter_B1_I_I__String(bytes, fromIndex, toIndex)
			if !(s == nil) {
				out.Append_CharSequence__Appendable(Up_String_CharSequence(s)) } else {

					out.Append_CharSequence__Appendable(Up_String_CharSequence(t.F_prefix))
					t.ToHexDigits_Appendable_B__Appendable(out, bytes.A[fromIndex])
					var i int32 = 1; L1: for {
						if i < length {
							out.Append_CharSequence__Appendable(Up_String_CharSequence(t.F_suffix))
							out.Append_CharSequence__Appendable(Up_String_CharSequence(t.F_delimiter))
							out.Append_CharSequence__Appendable(Up_String_CharSequence(t.F_prefix))
							t.ToHexDigits_Appendable_B__Appendable(out, bytes.A[fromIndex+i])
							i = i + 1; continue L1 }
//line :112:1
						break L1
					}





					out.Append_CharSequence__Appendable(Up_String_CharSequence(t.F_suffix)) } }; return nil }()
//line :105:1
		if tmp1 != nil { if IOException_InstanceOf(tmp1) { var ioe IOException_I = IOException_Cast(tmp1)














			panic(Thrown(UncheckedIOException_New_String_IOException(ioe.GetMessage__String(), ioe))) } else {
//line :105:1
				panic(tmp1) } } }
//line :103:1
	return out
}


















func (t *HexFormat) FormatOptDelimiter_B1_I_I__String(bytes *ByteArray, fromIndex, toIndex int32) *String {
	var sep uint16 = 0; var rep *ByteArray; var tmp1 bool; var tmp2 bool

	tmp2 = !NN(t.F_prefix).IsEmpty__Z(); if !tmp2 { tmp2 = !NN(t.F_suffix).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { return nil } else {
		var length int32 = toIndex - fromIndex
		if NN(t.F_delimiter).IsEmpty__Z() {


			rep = NewByteArray(HexFormat_CheckMaxArraySize_J__I(int64(length) * 2))
			var i int32 = 0; L1: for {
				if i < length {
					var pair int16 = HexDigits_DigitPair_I_Z__S(int32(bytes.A[fromIndex+i]), t.F_ucase); var pos int32 = i * 2



					rep.A[pos] = int8(pair)
					rep.A[pos+1] = int8(int32(uint32(int32(pair)) >> 8))


					i = i + 1; continue L1 }
//line :132:1
				break L1
			}







		} else {
//line :128:1
			var tmp3 bool; var tmp4 bool














			tmp4 = NN(t.F_delimiter).Length__I() == 1; if tmp4 { var tmp5 uint16; sep = NN(t.F_delimiter).CharAt_I__C(0); tmp5 = sep; tmp4 = int32(tmp5) < 256 }; tmp3 = tmp4
//line :128:1
			if tmp3 {
















				rep = NewByteArray(HexFormat_CheckMaxArraySize_J__I(int64(length)*3 - 1))



				var pair_2 int16 = HexDigits_DigitPair_I_Z__S(int32(bytes.A[fromIndex]), t.F_ucase)
				rep.A[0] = int8(pair_2)
				rep.A[1] = int8(int32(uint32(int32(pair_2)) >> 8))
				var i_2 int32 = 1; L2: for {
					if i_2 < length {
						var pos_2 int32 = i_2 * 3
						pair_2 = HexDigits_DigitPair_I_Z__S(int32(bytes.A[fromIndex+i_2]), t.F_ucase)



						rep.A[pos_2-1] = int8(sep)
						rep.A[pos_2] = int8(pair_2)
						rep.A[pos_2+1] = int8(int32(uint32(int32(pair_2)) >> 8))


						i_2 = i_2 + 1; continue L2 }
//line :152:1
					break L2 } } else {












						return nil } }
		return HexFormat_jla.UncheckedNewStringWithLatin1Bytes_B1__String(rep)
	} }
func HexFormat_CheckMaxArraySize_J__I(length int64) int32 { HexFormat_Init()
	if length > 2147483647 {
		panic(Thrown(OutOfMemoryError_New_String(Concat(Lit_2699, StrOfLong(length), Lit_2700, Lit_2701))))
	}
	return int32(length)
}
func (t *HexFormat) ParseHex_CharSequence__B1(string_ CharSequence) *ByteArray {
	return t.ParseHex_CharSequence_I_I__B1(string_, 0, string_.Length__I())
}
func (t *HexFormat) ParseHex_CharSequence_I_I__B1(string_ CharSequence, fromIndex, toIndex int32) *ByteArray {
	Objects_RequireNonNull_O_String__O(string_, Lit_2702)
	Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, string_.Length__I())
	var tmp1 bool; var tmp2 bool; tmp2 = !(fromIndex == 0); if !tmp2 { tmp2 = !(toIndex == string_.Length__I()) }; tmp1 = tmp2; if tmp1 {
		string_ = string_.SubSequence_I_I__CharSequence(fromIndex, toIndex) }
	if string_.IsEmpty__Z() { return HexFormat_EMPTY_BYTES } else { var tmp3 bool; var tmp4 bool; var tmp5 bool

		tmp5 = NN(t.F_delimiter).IsEmpty__Z(); if tmp5 { tmp5 = NN(t.F_prefix).IsEmpty__Z() }; tmp4 = tmp5; if tmp4 { tmp4 = NN(t.F_suffix).IsEmpty__Z() }; tmp3 = tmp4
//line :182:1
		if tmp3 {


			return HexFormat_ParseNoDelimiter_CharSequence__B1(string_) } else {

				var valueChars int64 = int64(NN(t.F_prefix).Length__I()) + 2 + int64(NN(t.F_suffix).Length__I()); var stride int64 = valueChars + int64(NN(t.F_delimiter).Length__I())

				if (int64(string_.Length__I())-valueChars)%stride == 0 { } else {


					panic(Thrown(IllegalArgumentException_New_String(Lit_2703)))
				}

				HexFormat_CheckLiteral_CharSequence_I_String__V(string_, 0, t.F_prefix)
				HexFormat_CheckLiteral_CharSequence_I_String__V(string_, string_.Length__I()-NN(t.F_suffix).Length__I(), t.F_suffix)


				var between *String = Concat(t.F_suffix, t.F_delimiter, t.F_prefix); var len_ int32 = int32((int64(string_.Length__I())-valueChars)/stride + 1); var bytes *ByteArray = NewByteArray(len_)
				var i int32 = 0
				var offset int32 = 0





				i = 0
				offset = NN(t.F_prefix).Length__I()
			L1: for { if i < len_-1 {
				bytes.A[i] = int8(HexFormat_FromHexDigits_CharSequence_I__I(string_, offset))
				HexFormat_CheckLiteral_CharSequence_I_String__V(string_, offset+2, between)
				i = i + 1
				offset = offset + (2 + NN(between).Length__I())
//line :209:1
				continue L1 }; break L1
			}



				bytes.A[i] = int8(HexFormat_FromHexDigits_CharSequence_I__I(string_, offset))
//line :199:1
				return bytes
			}
	}
}




















func HexFormat_CheckLiteral_CharSequence_I_String__V(string_ CharSequence, index int32, literal *String) { HexFormat_Init()
	if !A2g_AssertionsDisabled && !(index <= string_.Length__I()-NN(literal).Length__I()) { panic(Thrown(AssertionError_New_O(Lit_2705)))
	}
	var tmp1 bool; var tmp2 bool; tmp2 = NN(literal).IsEmpty__Z(); if !tmp2 {
		var tmp3 bool; tmp3 = NN(literal).Length__I() == 1; if tmp3 { tmp3 = int32(NN(literal).CharAt_I__C(0)) == int32(string_.CharAt_I__C(index)) }; tmp2 = tmp3 }
//line :226:1
	tmp1 = tmp2; if tmp1 { } else {

		var i int32 = 0; L1: for {
			if i < NN(literal).Length__I() {
				if !(int32(string_.CharAt_I__C(index+i)) == int32(NN(literal).CharAt_I__C(i))) {
					panic(Thrown(IllegalArgumentException_New_String(HexFormat_EscapeNL_String__String(Concat(Lit_2706, StrOfObj(string_.SubSequence_I_I__CharSequence(index, index+NN(literal).Length__I())), Lit_2707, literal, Lit_2708, StrOfInt(index), Lit_2709, StrOfInt(int32(string_.CharAt_I__C(index+i)))))))) } else {












						i = i + 1; continue L1 } }
//line :228:1
			break L1
		}
	}
}















func HexFormat_EscapeNL_String__String(string_ *String) *String { HexFormat_Init()
	return NN(NN(string_).Replace_CharSequence_CharSequence__String(Lit_2710, Lit_2711)).Replace_CharSequence_CharSequence__String(Lit_2712, Lit_2713)
}
func (t *HexFormat) ToLowHexDigit_I__C(value int32) uint16 {
	value = value & 15
	if value < 10 {
		return uint16(48 + value) } else {
//line :252:1
			if !t.F_ucase {

				return uint16(87 + value) } else {
					return uint16(55 + value)
				} } }
func (t *HexFormat) ToHighHexDigit_I__C(value int32) uint16 {
	value = value >> 4 & 15
	if value < 10 {
		return uint16(48 + value) } else {
//line :259:1
			if !t.F_ucase {

				return uint16(87 + value) } else {
					return uint16(55 + value)
				} } }
func (t *HexFormat) ToHexDigits_Appendable_B__Appendable(out Appendable, value int8) Appendable {
	var tmp1 Appendable; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		out.Append_C__Appendable(t.ToHighHexDigit_I__C(int32(value)))
		out.Append_C__Appendable(t.ToLowHexDigit_I__C(int32(value)))
//line :265:1
		tmp1 = out

		return nil }()
//line :265:1
	if tmp2 != nil { if IOException_InstanceOf(tmp2) { var ioe IOException_I = IOException_Cast(tmp2)



		panic(Thrown(UncheckedIOException_New_String_IOException(ioe.GetMessage__String(), ioe))) } else {
//line :265:1
			panic(tmp2) } }; return tmp1
}




func (t *HexFormat) ToHexDigits_B__String(value int8) *String {
	var rep *ByteArray = NewByteArray(2)
	rep.A[0] = int8(t.ToHighHexDigit_I__C(int32(value)))
	rep.A[1] = int8(t.ToLowHexDigit_I__C(int32(value)))
	return HexFormat_jla.UncheckedNewStringWithLatin1Bytes_B1__String(rep)
}
func (t *HexFormat) ToHexDigits_C__String(value uint16) *String {
	return t.ToHexDigits_S__String(int16(value))
}
func (t *HexFormat) ToHexDigits_S__String(value int16) *String {
	var rep *ByteArray = NewByteArray(4)
	rep.A[0] = int8(t.ToHighHexDigit_I__C(int32(int8(int32(value) >> 8))))


	rep.A[1] = int8(t.ToLowHexDigit_I__C(int32(int8(int32(value) >> 8))))


	rep.A[2] = int8(t.ToHighHexDigit_I__C(int32(int8(value))))
	rep.A[3] = int8(t.ToLowHexDigit_I__C(int32(int8(value))))
	return HexFormat_jla.UncheckedNewStringWithLatin1Bytes_B1__String(rep)
}
func (t *HexFormat) ToHexDigits_I__String(value int32) *String {
	var rep *ByteArray = NewByteArray(8)
	rep.A[0] = int8(t.ToHighHexDigit_I__C(int32(int8(value >> 24))))


	rep.A[1] = int8(t.ToLowHexDigit_I__C(int32(int8(value >> 24))))


	rep.A[2] = int8(t.ToHighHexDigit_I__C(int32(int8(value >> 16))))


	rep.A[3] = int8(t.ToLowHexDigit_I__C(int32(int8(value >> 16))))


	rep.A[4] = int8(t.ToHighHexDigit_I__C(int32(int8(value >> 8))))


	rep.A[5] = int8(t.ToLowHexDigit_I__C(int32(int8(value >> 8))))


	rep.A[6] = int8(t.ToHighHexDigit_I__C(int32(int8(value))))
	rep.A[7] = int8(t.ToLowHexDigit_I__C(int32(int8(value))))
	return HexFormat_jla.UncheckedNewStringWithLatin1Bytes_B1__String(rep)
}
func (t *HexFormat) ToHexDigits_J__String(value int64) *String {
	var rep *ByteArray = NewByteArray(16)
	rep.A[0] = int8(t.ToHighHexDigit_I__C(int32(int8(int64(uint64(value) >> 56)))))



	rep.A[1] = int8(t.ToLowHexDigit_I__C(int32(int8(int64(uint64(value) >> 56)))))



	rep.A[2] = int8(t.ToHighHexDigit_I__C(int32(int8(int64(uint64(value) >> 48)))))



	rep.A[3] = int8(t.ToLowHexDigit_I__C(int32(int8(int64(uint64(value) >> 48)))))



	rep.A[4] = int8(t.ToHighHexDigit_I__C(int32(int8(int64(uint64(value) >> 40)))))



	rep.A[5] = int8(t.ToLowHexDigit_I__C(int32(int8(int64(uint64(value) >> 40)))))



	rep.A[6] = int8(t.ToHighHexDigit_I__C(int32(int8(int64(uint64(value) >> 32)))))



	rep.A[7] = int8(t.ToLowHexDigit_I__C(int32(int8(int64(uint64(value) >> 32)))))



	rep.A[8] = int8(t.ToHighHexDigit_I__C(int32(int8(int64(uint64(value) >> 24)))))



	rep.A[9] = int8(t.ToLowHexDigit_I__C(int32(int8(int64(uint64(value) >> 24)))))



	rep.A[10] = int8(t.ToHighHexDigit_I__C(int32(int8(int64(uint64(value) >> 16)))))



	rep.A[11] = int8(t.ToLowHexDigit_I__C(int32(int8(int64(uint64(value) >> 16)))))



	rep.A[12] = int8(t.ToHighHexDigit_I__C(int32(int8(int64(uint64(value) >> 8)))))



	rep.A[13] = int8(t.ToLowHexDigit_I__C(int32(int8(int64(uint64(value) >> 8)))))



	rep.A[14] = int8(t.ToHighHexDigit_I__C(int32(int8(value))))
	rep.A[15] = int8(t.ToLowHexDigit_I__C(int32(int8(value))))
	return HexFormat_jla.UncheckedNewStringWithLatin1Bytes_B1__String(rep)
}
func (t *HexFormat) ToHexDigits_J_I__String(value int64, digits int32) *String {
	var tmp1 bool; var tmp2 bool; tmp2 = digits < 0; if !tmp2 { tmp2 = digits > 16 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2714, StrOfInt(digits))))) }
	if digits == 0 { return Lit_69 } else {

		var rep *ByteArray = NewByteArray(digits); var i int32 = int32(len(rep.A)) - 1
	L1: for {
		if i >= 0 {
			rep.A[i] = int8(t.ToLowHexDigit_I__C(int32(int8(value))))
			value = int64(uint64(value) >> 4)
			i = i - 1; continue L1 }
//line :384:1
		break L1
	}



		return HexFormat_jla.UncheckedNewStringWithLatin1Bytes_B1__String(rep)
	} }
func HexFormat_ParseNoDelimiter_CharSequence__B1(string_ CharSequence) *ByteArray { HexFormat_Init()
	if string_.Length__I()&1 == 0 { } else {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2715, StrOfInt(string_.Length__I()))))) }
	var bytes *ByteArray = NewByteArray(string_.Length__I() / 2); var i int32 = 0
L1: for {
	if i < int32(len(bytes.A)) {
		bytes.A[i] = int8(HexFormat_FromHexDigits_CharSequence_I__I(string_, i*2))


		i = i + 1; continue L1 }
//line :395:1
	break L1 }
//line :394:1
	return bytes
}







func HexFormat_CheckDigitCount_I_I_I__I(fromIndex, toIndex, limit int32) int32 { HexFormat_Init()
	var length int32 = toIndex - fromIndex
	if length > limit {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2716, StrOfInt(limit), Lit_1157, StrOfInt(length))))) }
//line :404:1
	return length
}




func HexFormat_IsHexDigit_I__Z(ch int32) bool { HexFormat_Init()
	var tmp1 bool; tmp1 = int32(uint32(ch)>>7) == 0; if tmp1 { tmp1 = int32(HexFormat_DIGITS.A[ch]) >= 0 }; return tmp1
}
func HexFormat_FromHexDigit_I__I(ch int32) int32 { HexFormat_Init()
	var value int32 = 0; var tmp1 bool; var tmp2 bool
	tmp2 = int32(uint32(ch)>>7) == 0; if tmp2 { var tmp3 int32; value = int32(HexFormat_DIGITS.A[ch]); tmp3 = value; tmp2 = tmp3 >= 0 }; tmp1 = tmp2; if tmp1 { return value } else {

		panic(Thrown(NumberFormatException_New_String(Concat(Lit_2717, StrOfChar(uint16(ch)), Lit_2718, StrOfInt(ch)))))
	}
}
func HexFormat_FromHexDigits_CharSequence_I__I(string_ CharSequence, index int32) int32 { HexFormat_Init()
	var high int32 = HexFormat_FromHexDigit_I__I(int32(string_.CharAt_I__C(index))); var low int32 = HexFormat_FromHexDigit_I__I(int32(string_.CharAt_I__C(index + 1)))

	return high<<4 | low
}
func HexFormat_FromHexDigits_CharSequence__I(string_ CharSequence) int32 { HexFormat_Init()
	return HexFormat_FromHexDigits_CharSequence_I_I__I(string_, 0, string_.Length__I())
}
func HexFormat_FromHexDigits_CharSequence_I_I__I(string_ CharSequence, fromIndex, toIndex int32) int32 { HexFormat_Init()
	Objects_RequireNonNull_O_String__O(string_, Lit_2702)
	Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, string_.Length__I())
	var length int32 = HexFormat_CheckDigitCount_I_I_I__I(fromIndex, toIndex, 8)
	var value int32 = 0; var i int32 = 0
L1: for {
	if i < length {
		value = value<<4 + HexFormat_FromHexDigit_I__I(int32(string_.CharAt_I__C(fromIndex+i)))



		i = i + 1; continue L1 }
//line :433:1
	break L1 }
//line :431:1
	return value
}









func HexFormat_FromHexDigitsToLong_CharSequence__J(string_ CharSequence) int64 { HexFormat_Init()
	return HexFormat_FromHexDigitsToLong_CharSequence_I_I__J(string_, 0, string_.Length__I())
}
func HexFormat_FromHexDigitsToLong_CharSequence_I_I__J(string_ CharSequence, fromIndex, toIndex int32) int64 { HexFormat_Init()

	Objects_RequireNonNull_O_String__O(string_, Lit_2702)
	Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, string_.Length__I())
	var length int32 = HexFormat_CheckDigitCount_I_I_I__I(fromIndex, toIndex, 16)
	var value int64 = 0; var i int32 = 0
L1: for {
	if i < length {
		value = value<<4 + int64(HexFormat_FromHexDigit_I__I(int32(string_.CharAt_I__C(fromIndex+i))))



		i = i + 1; continue L1 }
//line :451:1
	break L1 }
//line :449:1
	return value
}









func (t *HexFormat) Equals_O__Z(o any) bool {
	if any(t) == any(o) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = o == nil; if !tmp2 { tmp2 = !(t.GetClass__Class() == GetClass(o)) }; tmp1 = tmp2
//line :461:1
		if tmp1 { return false } else {



			var otherHex *HexFormat = HexFormat_Cast(o); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool = t.F_ucase
			tmp5 = tmp6 == otherHex.F_ucase; if tmp5 { var tmp7 *String = t.F_delimiter; tmp5 = NN(tmp7).Equals_O__Z(otherHex.F_delimiter.Ref()) }; tmp4 = tmp5; if tmp4 {
				var tmp8 *String = t.F_prefix; tmp4 = NN(tmp8).Equals_O__Z(otherHex.F_prefix.Ref()) }
//line :466:1
			tmp3 = tmp4; if tmp3 {

				var tmp9 *String = t.F_suffix; tmp3 = NN(tmp9).Equals_O__Z(otherHex.F_suffix.Ref()) }
//line :466:1
			return tmp3
		}
	}
}
func (t *HexFormat) HashCode__I() int32 {
	var result int32 = Objects_Hash_O1__I(RefArrayOf(Object_class, t.F_delimiter.Ref(), t.F_prefix.Ref(), t.F_suffix.Ref()))
	result = 31*result + Boolean_HashCode_Z__I(t.F_ucase)
//line :471:1
	return result
}


func (t *HexFormat) ToString__String() *String {
	return HexFormat_EscapeNL_String__String(Concat(Lit_2719, StrOfBool(t.F_ucase), Lit_2720, t.F_delimiter, Lit_2721, t.F_prefix, Lit_2722, t.F_suffix, Lit_1142))
}


type HexFormat struct{ Object; F_delimiter, F_prefix, F_suffix *String; F_ucase bool }

var HexFormat_jla JavaLangAccess

var HexFormat_DIGITS *ByteArray

var HexFormat_HEX_FORMAT *HexFormat

var HexFormat_HEX_UPPER_FORMAT *HexFormat

var HexFormat_EMPTY_BYTES *ByteArray

var HexFormat_init ClassInit

func HexFormat_Init() { if !HexFormat_init.Done() { HexFormat_init.Run(HexFormat_clinit) } }

func HexFormat_clinit() { HexFormat_jla = SharedSecrets_GetJavaLangAccess__JavaLangAccess(); HexFormat_DIGITS = ByteArrayOf(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1); HexFormat_HEX_FORMAT = HexFormat_New_String_String_String_Z(Lit_69, Lit_69, Lit_69, false); HexFormat_HEX_UPPER_FORMAT = HexFormat_New_String_String_String_Z(Lit_69, Lit_69, Lit_69, true); HexFormat_EMPTY_BYTES = ByteArrayOf() }

func (t *HexFormat) Ref() any { if t == nil { return nil }; return t }

func (t *HexFormat) GetClass__Class() *Class { return HexFormat_class }

func (t *HexFormat) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HexFormat) CloneShallow() any { panic(CloneNotSupported(t)) }

func HexFormat_InstanceOf(x any) bool { _, ok := x.(*HexFormat); return ok }

func HexFormat_Cast(x any) *HexFormat { if x == nil { return nil }; v, ok := x.(*HexFormat); if !ok { panic(ClassCast(x, HexFormat_class)) }; return v }
