//line java_nio_file_NotDirectoryException.ae:1
package jrt








func NotDirectoryException_New_String(p0 *String) *NotDirectoryException { t := &NotDirectoryException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *NotDirectoryException) Ctor_String(file *String) { t.FileSystemException.Ctor_String(t, file) }





type NotDirectoryException struct{ FileSystemException }

const NotDirectoryException_serialVersionUID int64 = -9011457427178200199

func (t *NotDirectoryException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NotDirectoryException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NotDirectoryException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NotDirectoryException) GetFile__String() *String { return t.Impl_GetFile__String(t) }

func (t *NotDirectoryException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NotDirectoryException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NotDirectoryException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NotDirectoryException) GetReason__String() *String { return t.Impl_GetReason__String(t) }

func (t *NotDirectoryException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NotDirectoryException) GetOtherFile__String() *String { return t.Impl_GetOtherFile__String(t) }

func (t *NotDirectoryException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NotDirectoryException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NotDirectoryException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NotDirectoryException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NotDirectoryException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NotDirectoryException) Ref() any { if t == nil { return nil }; return t }

func (t *NotDirectoryException) GetClass__Class() *Class { return NotDirectoryException_class }

func (t *NotDirectoryException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NotDirectoryException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NotDirectoryException_InstanceOf(x any) bool { _, ok := x.(*NotDirectoryException); return ok }

func NotDirectoryException_Cast(x any) *NotDirectoryException { if x == nil { return nil }; v, ok := x.(*NotDirectoryException); if !ok { panic(ClassCast(x, NotDirectoryException_class)) }; return v }
