//line java_security_cert_CertStoreParameters.ae:1
package jrt






type CertStoreParameters interface{ Object_I; Cloneable; Is_CertStoreParameters() }

func CertStoreParameters_InstanceOf(x any) bool { _, ok := x.(CertStoreParameters); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CertStoreParameters_class) } }; return ok }

func CertStoreParameters_Cast(x any) CertStoreParameters { if x == nil { return nil }; v, ok := x.(CertStoreParameters); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CertStoreParameters_class) } }; if !ok { panic(ClassCast(x, CertStoreParameters_class)) }; return v }
