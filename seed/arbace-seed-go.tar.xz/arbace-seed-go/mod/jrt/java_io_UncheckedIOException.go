//line java_io_UncheckedIOException.ae:1
package jrt










func UncheckedIOException_New_String_IOException(p0 *String, p1 IOException_I) *UncheckedIOException { t := &UncheckedIOException{}; t.Ctor_String_IOException(p0, p1); return t }
//line :12:1
func (t *UncheckedIOException) Ctor_String_IOException(message *String, cause IOException_I) { t.RuntimeException.Ctor_String_Throwable(t, message, Throwable_Cast(Objects_RequireNonNull_O__O(cause))) }


func UncheckedIOException_New_IOException(p0 IOException_I) *UncheckedIOException { t := &UncheckedIOException{}; t.Ctor_IOException(p0); return t }
//line :15:1
func (t *UncheckedIOException) Ctor_IOException(cause IOException_I) { t.RuntimeException.Ctor_Throwable(t, Throwable_Cast(Objects_RequireNonNull_O__O(cause))) }


func (t *UncheckedIOException) GetCause__IOException() IOException_I {
	return IOException_Cast(t.RuntimeException.Impl_GetCause__Throwable(t))
}


type UncheckedIOException struct{ RuntimeException }

const UncheckedIOException_serialVersionUID int64 = -8134305061645241065

func (t *UncheckedIOException) GetCause__Throwable() Throwable_I { return t.GetCause__IOException() }

func (t *UncheckedIOException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *UncheckedIOException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *UncheckedIOException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *UncheckedIOException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *UncheckedIOException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *UncheckedIOException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *UncheckedIOException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *UncheckedIOException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *UncheckedIOException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *UncheckedIOException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *UncheckedIOException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *UncheckedIOException) Ref() any { if t == nil { return nil }; return t }

func (t *UncheckedIOException) GetClass__Class() *Class { return UncheckedIOException_class }

func (t *UncheckedIOException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UncheckedIOException) CloneShallow() any { panic(CloneNotSupported(t)) }

func UncheckedIOException_InstanceOf(x any) bool { _, ok := x.(*UncheckedIOException); return ok }

func UncheckedIOException_Cast(x any) *UncheckedIOException { if x == nil { return nil }; v, ok := x.(*UncheckedIOException); if !ok { panic(ClassCast(x, UncheckedIOException_class)) }; return v }
