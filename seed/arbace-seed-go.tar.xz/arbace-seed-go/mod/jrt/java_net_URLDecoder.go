//line java_net_URLDecoder.ae:1
package jrt








func URLDecoder_New() *URLDecoder { t := &URLDecoder{}; t.Ctor(); return t }
//line :10:1
func (t *URLDecoder) Ctor() { panic(A2g_NotTranslated("java.net.URLDecoder.<init>()V")) }

func URLDecoder_Decode_String__String(s *String) *String {
	return URLDecoder_Decode_String_Charset__String(s, Charset_DefaultCharset__Charset())
}
func URLDecoder_Decode_String_String__String(s, enc *String) *String {

	if NN(enc).IsEmpty__Z() {
		panic(Thrown(UnsupportedEncodingException_New_String(Lit_1462))) }
	var tmp1 *String; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var charset Charset_I = Charset_ForName_String__Charset(enc); tmp1 = URLDecoder_Decode_String_Charset__String(s, charset) }; return nil }()
//line :19:1
	if tmp2 != nil { if IllegalCharsetNameException_InstanceOf(tmp2) || UnsupportedCharsetException_InstanceOf(tmp2) { var e IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = e


		panic(Thrown(UnsupportedEncodingException_New_String(enc))) } else {
//line :19:1
			panic(tmp2) } }; return tmp1
}



func URLDecoder_Decode_String_Charset__String(s *String, charset Charset_I) *String {
	Objects_RequireNonNull_O_String__O(charset, Lit_1463)
	var needToChange bool = false; var numChars int32 = NN(s).Length__I(); var sb *StringBuilder; var tmp1 int32

	if numChars > 500 { tmp1 = numChars / 2 } else { tmp1 = numChars }; sb = StringBuilder_New_I(tmp1)
//line :26:1
	var i int32 = 0; var c uint16 = 0; var bytes *ByteArray





L1: for { if i < numChars {
	c = NN(s).CharAt_I__C(i)
	switch int32(c) { case 43:
		NN(sb).Append_C__StringBuilder(32); i = i + 1; needToChange = true
//line :34:1
	case 37: tmp6 := func() (exc Throwable_I) { defer Catch(&exc)




		if bytes == nil {
			bytes = NewByteArray((numChars - i) / 3)
		}
		{ var pos int32 = 0
		L2: for { var tmp2 bool; var tmp3 bool; tmp3 = i+2 < numChars; if tmp3 { tmp3 = int32(c) == 37 }; tmp2 = tmp3; if tmp2 {
			var v int32 = HexFormat_FromHexDigits_CharSequence_I_I__I(Up_String_CharSequence(s), i+1, i+3)



			bytes.A[pos] = int8(v)
			pos = pos + 1
			i = i + 3
			if i < numChars { c = NN(s).CharAt_I__C(i) }
//line :43:1
			continue L2 }; break L2
		}







			var tmp4 bool; var tmp5 bool; tmp5 = i < numChars; if tmp5 { tmp5 = int32(c) == 37 }; tmp4 = tmp5; if tmp4 {
				panic(Thrown(IllegalArgumentException_New_String(Lit_1464)))
			}
			NN(sb).Append_String__StringBuilder(String_New_B1_I_I_Charset(bytes, 0, pos, charset)) }
//line :34:1
		return nil
	}()


		if tmp6 != nil { if NumberFormatException_InstanceOf(tmp6) { var e *NumberFormatException = NumberFormatException_Cast(tmp6)


















			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1465, NN(e).GetMessage__String())))) } else {
//line :38:1
				panic(tmp6)
			}
		}



















		needToChange = true
//line :34:1
	default:


























		NN(sb).Append_C__StringBuilder(c); i = i + 1}
//line :32:1
	continue L1 }; break L1
}




























	if needToChange { return NN(sb).ToString__String() } else { return s } }
//line :32:1
type URLDecoder struct{ Object }

func (t *URLDecoder) Ref() any { if t == nil { return nil }; return t }

func (t *URLDecoder) GetClass__Class() *Class { return URLDecoder_class }

func (t *URLDecoder) ToString__String() *String { return Object_toString(t) }

func (t *URLDecoder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URLDecoder) CloneShallow() any { panic(CloneNotSupported(t)) }

func URLDecoder_InstanceOf(x any) bool { _, ok := x.(*URLDecoder); return ok }

func URLDecoder_Cast(x any) *URLDecoder { if x == nil { return nil }; v, ok := x.(*URLDecoder); if !ok { panic(ClassCast(x, URLDecoder_class)) }; return v }
