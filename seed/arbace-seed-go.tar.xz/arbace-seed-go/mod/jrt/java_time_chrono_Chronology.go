//line java_time_chrono_Chronology.ae:1
package jrt

















func Chronology_From_TemporalAccessor__Chronology(temporal TemporalAccessor) Chronology {
	Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
	var obj Chronology = Chronology_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery())); var tmp1 *IsoChronology
	IsoChronology_Init(); tmp1 = IsoChronology_INSTANCE; return Chronology_Cast(Objects_RequireNonNullElse_O_O__O(obj, tmp1.Ref()))
}
func Chronology_OfLocale_Locale__Chronology(locale *Locale) Chronology {
	return AbstractChronology_OfLocale_Locale__Chronology(locale)
}
func Chronology_Of_String__Chronology(id *String) Chronology { return AbstractChronology_Of_String__Chronology(id) }

func Chronology_GetAvailableChronologies__Set() Set {
	return AbstractChronology_GetAvailableChronologies__Set()
}




func Chronology_Date_Era_I_I_I__ChronoLocalDate(this Chronology, era Era, yearOfEra, month, dayOfMonth int32) ChronoLocalDate {
	return this.Date_I_I_I__ChronoLocalDate(this.ProlepticYear_Era_I__I(era, yearOfEra), month, dayOfMonth)
}


func Chronology_DateYearDay_Era_I_I__ChronoLocalDate(this Chronology, era Era, yearOfEra, dayOfYear int32) ChronoLocalDate {
	return this.DateYearDay_I_I__ChronoLocalDate(this.ProlepticYear_Era_I__I(era, yearOfEra), dayOfYear)
}




func Chronology_DateNow__ChronoLocalDate(this Chronology) ChronoLocalDate {
	return this.DateNow_Clock__ChronoLocalDate(Clock_SystemDefaultZone__Clock())
}
func Chronology_DateNow_ZoneId__ChronoLocalDate(this Chronology, zone ZoneId_I) ChronoLocalDate {
	return this.DateNow_Clock__ChronoLocalDate(Clock_System_ZoneId__Clock(zone))
}
func Chronology_DateNow_Clock__ChronoLocalDate(this Chronology, clock Clock_I) ChronoLocalDate {
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	return this.Date_TemporalAccessor__ChronoLocalDate(Up_LocalDate_TemporalAccessor(LocalDate_Now_Clock__LocalDate(clock)))
}


func Chronology_LocalDateTime_TemporalAccessor__ChronoLocalDateTime(this Chronology, temporal TemporalAccessor) ChronoLocalDateTime {

	var tmp1 ChronoLocalDateTime; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = this.Date_TemporalAccessor__ChronoLocalDate(temporal).AtTime_LocalTime__ChronoLocalDateTime(LocalTime_From_TemporalAccessor__LocalTime(temporal)); return nil }()
//line :62:1
	if tmp2 != nil { if DateTimeException_InstanceOf(tmp2) { var ex DateTimeException_I = DateTimeException_Cast(tmp2)


		panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2191, StrOfObj(temporal.GetClass__Class().Ref())), ex))) } else {
//line :62:1
			panic(tmp2) } }; return tmp1
}






func Chronology_ZonedDateTime_TemporalAccessor__ChronoZonedDateTime(this Chronology, temporal TemporalAccessor) ChronoZonedDateTime {

	var tmp1 ChronoZonedDateTime; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var zone ZoneId_I = ZoneId_From_TemporalAccessor__ZoneId(temporal); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

			{ var instant *Instant = Instant_From_TemporalAccessor__Instant(temporal); tmp1 = this.ZonedDateTime_Instant_ZoneId__ChronoZonedDateTime(instant, zone) }; return nil }()
//line :74:1
			if tmp2 != nil { if DateTimeException_InstanceOf(tmp2) { var ex1 DateTimeException_I = DateTimeException_Cast(tmp2); var cldt *ChronoLocalDateTimeImpl = ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(this, this.LocalDateTime_TemporalAccessor__ChronoLocalDateTime(temporal)); _ = ex1





				tmp1 = ChronoZonedDateTimeImpl_OfBest_ChronoLocalDateTimeImpl_ZoneId_ZoneOffset__ChronoZonedDateTime(cldt, zone, nil) } else {
//line :74:1
					panic(tmp2) } } }
		return nil }()
//line :72:1
	if tmp3 != nil { if DateTimeException_InstanceOf(tmp3) { var ex DateTimeException_I = DateTimeException_Cast(tmp3)









		panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2199, StrOfObj(temporal.GetClass__Class().Ref())), ex))) } else {
//line :72:1
			panic(tmp3) } }; return tmp1
}













func Chronology_ZonedDateTime_Instant_ZoneId__ChronoZonedDateTime(this Chronology, instant *Instant, zone ZoneId_I) ChronoZonedDateTime {


	return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(ChronoZonedDateTimeImpl_OfInstant_Chronology_Instant_ZoneId__ChronoZonedDateTimeImpl(this, instant, zone))
}










func Chronology_GetDisplayName_TextStyle_Locale__String(this Chronology, style *TextStyle, locale *Locale) *String {
	var temporal TemporalAccessor = Chronology_1_New_Chronology(this)













	return NN(NN(DateTimeFormatterBuilder_New().AppendChronologyText_TextStyle__DateTimeFormatterBuilder(style)).ToFormatter_Locale__DateTimeFormatter(locale)).Format_TemporalAccessor__String(temporal) }
//line :104:1
func (t *Chronology_1) IsSupported_TemporalField__Z(field TemporalField) bool { return false }



func (t *Chronology_1) GetLong_TemporalField__J(field TemporalField) int64 {
	panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))
}

func (t *Chronology_1) Query_TemporalQuery__O(query TemporalQuery) any {

	if query == TemporalQueries_Chronology__TemporalQuery() { return t.F_this_0 } else {

		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	}
}




func Chronology_Period_I_I_I__ChronoPeriod(this Chronology, years, months, days int32) ChronoPeriod {
	return ChronoPeriodImpl_New_Chronology_I_I_I(this, years, months, days)
}
func Chronology_EpochSecond_I_I_I_I_I_I_ZoneOffset__J(this Chronology, prolepticYear, month, dayOfMonth, hour, minute, second int32, zoneOffset *ZoneOffset) int64 {

	Objects_RequireNonNull_O_String__O(zoneOffset.Ref(), Lit_2200)
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_HOUR_OF_DAY; NN(tmp1).CheckValidValue_J__J(int64(hour))
	var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MINUTE_OF_HOUR; NN(tmp2).CheckValidValue_J__J(int64(minute))
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_SECOND_OF_MINUTE; NN(tmp3).CheckValidValue_J__J(int64(second))
	var daysInSec int64 = Math_MultiplyExact_J_I__J(this.Date_I_I_I__ChronoLocalDate(prolepticYear, month, dayOfMonth).ToEpochDay__J(), 86400); var timeinSec int64 = int64((hour*60+minute)*60 + second)







	return Math_AddExact_J_J__J(daysInSec, timeinSec-int64(NN(zoneOffset).GetTotalSeconds__I()))
}
func Chronology_EpochSecond_Era_I_I_I_I_I_I_ZoneOffset__J(this Chronology, era Era, yearOfEra, month, dayOfMonth, hour, minute, second int32, zoneOffset *ZoneOffset) int64 {

	Objects_RequireNonNull_O_String__O(era, Lit_1779)
	return this.EpochSecond_I_I_I_I_I_I_ZoneOffset__J(this.ProlepticYear_Era_I__I(era, yearOfEra), month, dayOfMonth, hour, minute, second, zoneOffset)
}







func Chronology_IsIsoBased__Z(this Chronology) bool { return false }



type Chronology interface{ Object_I; Comparable; Is_Chronology(); GetId__String() *String; GetCalendarType__String() *String; Date_Era_I_I_I__ChronoLocalDate(p0 Era, p1, p2, p3 int32) ChronoLocalDate; Date_I_I_I__ChronoLocalDate(p0, p1, p2 int32) ChronoLocalDate; DateYearDay_Era_I_I__ChronoLocalDate(p0 Era, p1, p2 int32) ChronoLocalDate; DateYearDay_I_I__ChronoLocalDate(p0, p1 int32) ChronoLocalDate; DateEpochDay_J__ChronoLocalDate(p0 int64) ChronoLocalDate; DateNow__ChronoLocalDate() ChronoLocalDate; DateNow_ZoneId__ChronoLocalDate(p0 ZoneId_I) ChronoLocalDate; DateNow_Clock__ChronoLocalDate(p0 Clock_I) ChronoLocalDate; Date_TemporalAccessor__ChronoLocalDate(p0 TemporalAccessor) ChronoLocalDate; LocalDateTime_TemporalAccessor__ChronoLocalDateTime(p0 TemporalAccessor) ChronoLocalDateTime; ZonedDateTime_TemporalAccessor__ChronoZonedDateTime(p0 TemporalAccessor) ChronoZonedDateTime; ZonedDateTime_Instant_ZoneId__ChronoZonedDateTime(p0 *Instant, p1 ZoneId_I) ChronoZonedDateTime; IsLeapYear_J__Z(p0 int64) bool; ProlepticYear_Era_I__I(p0 Era, p1 int32) int32; EraOf_I__Era(p0 int32) Era; Eras__List() List; Range_ChronoField__ValueRange(p0 *ChronoField) *ValueRange; GetDisplayName_TextStyle_Locale__String(p0 *TextStyle, p1 *Locale) *String; ResolveDate_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; Period_I_I_I__ChronoPeriod(p0, p1, p2 int32) ChronoPeriod; EpochSecond_I_I_I_I_I_I_ZoneOffset__J(p0, p1, p2, p3, p4, p5 int32, p6 *ZoneOffset) int64; EpochSecond_Era_I_I_I_I_I_I_ZoneOffset__J(p0 Era, p1, p2, p3, p4, p5, p6 int32, p7 *ZoneOffset) int64; IsIsoBased__Z() bool; CompareTo_Chronology__I(p0 Chronology) int32; CompareTo_O__I(p0 any) int32 }

func Chronology_CompareTo_O__I(this Chronology, p0 any) int32 { return this.CompareTo_Chronology__I(Chronology_Cast(p0)) }

func Chronology_InstanceOf(x any) bool { _, ok := x.(Chronology); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Chronology_class) } }; return ok }

func Chronology_Cast(x any) Chronology { if x == nil { return nil }; v, ok := x.(Chronology); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Chronology_class) } }; if !ok { panic(ClassCast(x, Chronology_class)) }; return v }



type Chronology_1 struct{ Object; F_this_0 Chronology }

func (t *Chronology_1) Is_TemporalAccessor() {}

func Chronology_1_New_Chronology(p0 Chronology) *Chronology_1 { t := &Chronology_1{}; t.Ctor_Chronology(p0); return t }

func (t *Chronology_1) Ctor_Chronology(this_0 Chronology) { A2g_NotNull[Chronology](this_0); t.F_this_0 = this_0 }

func (t *Chronology_1) Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange { return TemporalAccessor_Range_TemporalField__ValueRange(t, p0) }

func (t *Chronology_1) Get_TemporalField__I(p0 TemporalField) int32 { return TemporalAccessor_Get_TemporalField__I(t, p0) }

func (t *Chronology_1) Ref() any { if t == nil { return nil }; return t }

func (t *Chronology_1) GetClass__Class() *Class { return Chronology_1_class }

func (t *Chronology_1) ToString__String() *String { return Object_toString(t) }

func (t *Chronology_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Chronology_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Chronology_1_InstanceOf(x any) bool { _, ok := x.(*Chronology_1); return ok }

func Chronology_1_Cast(x any) *Chronology_1 { if x == nil { return nil }; v, ok := x.(*Chronology_1); if !ok { panic(ClassCast(x, Chronology_1_class)) }; return v }
