//line java_lang_Double.ae:1
package jrt











































func Double_ToString_D__String(d float64) *String {
	return DoubleToDecimal_ToString_D__String(d)
}
func Double_ToHexString_D__String(d float64) *String {
	if !Double_IsFinite_D__Z(d) {
		return Double_ToString_D__String(d) } else {
			var doubleToLongBits int64 = Double_DoubleToLongBits_D__J(d); var negative bool = doubleToLongBits < 0

			if d == 0.0 {
				if negative { return Lit_1116 } else { return Lit_1117 } } else {

					d = Math_Abs_D__D(d)
					var subnormal bool = d < 2.2250738585072014e-308; var signifBits int64 = doubleToLongBits & 4503599627370495; var trailingZeros int32 = Long_NumberOfTrailingZeros_J__I(signifBits|281474976710656) >> 2; var exp int32






					if subnormal { exp = -1022 } else { exp = Math_GetExponent_D__I(d) }
//line :57:1
					var charlen int32; var tmp1 int32










					if negative { tmp1 = 1 } else { tmp1 = 0 }
//line :65:1
					charlen = tmp1 + 4 + 13 - trailingZeros + 1 + DecimalDigits_StringSize_I__I(exp)
//line :57:1
					var chars *ByteArray = NewByteArray(charlen)
					var index int32 = 0















					if negative {
						chars.A[index] = 45
						index = index + 1 }
					chars.A[index] = 48
					chars.A[index+1] = 120
					var tmp2 int32 = index + 2; var tmp3 uint16; if subnormal { tmp3 = 48 } else { tmp3 = 49 }; chars.A[tmp2] = int8(tmp3)
					chars.A[index+3] = 46
					index = index + 4
					var sh int32 = 48; var end int32 = 4 * trailingZeros; L1: for {

						if sh >= end {
							var tmp4 int32 = index; var tmp5 *ByteArray; Integer_Init(); tmp5 = Integer_digits; chars.A[tmp4] = tmp5.A[int32(signifBits>>(sh&63))&15]




							index = index + 1
							sh, end = sh-4, end; continue L1 }
//line :82:1
						break L1
					}








					chars.A[index] = 112
					DecimalDigits_UncheckedGetCharsLatin1_I_I_B1__I(exp, charlen, chars)
					return String_NewStringWithLatin1Bytes_B1__String(chars)
				} } }
func Double_ValueOf_String__Double(s *String) *Double {
	return Double_New_D(Double_ParseDouble_String__D(s))
}
func Double_ValueOf_D__Double(d float64) *Double {
	return Double_New_D(d)
}
func Double_ParseDouble_String__D(s *String) float64 {
	return FloatingDecimal_ParseDouble_String__D(s)
}
func Double_IsNaN_D__Z(v float64) bool { return !(v == v) }

func Double_IsInfinite_D__Z(v float64) bool {
	return Math_Abs_D__D(v) > 1.7976931348623157e308
}
func Double_IsFinite_D__Z(d float64) bool {
	return Math_Abs_D__D(d) <= 1.7976931348623157e308
}


func Double_New_D(p0 float64) *Double { Double_Init(); t := &Double{}; t.Ctor_D(p0); return t }
//line :115:1
func (t *Double) Ctor_D(value float64) { t.Number.Ctor(t)
	t.F_value = value
}
func Double_New_String(p0 *String) *Double { Double_Init(); t := &Double{}; t.Ctor_String(p0); return t }
//line :118:1
func (t *Double) Ctor_String(s *String) { t.Number.Ctor(t)
	t.F_value = Double_ParseDouble_String__D(s)
}
func (t *Double) IsNaN__Z() bool { return Double_IsNaN_D__Z(t.F_value) }

func (t *Double) IsInfinite__Z() bool { return Double_IsInfinite_D__Z(t.F_value) }

func (t *Double) ToString__String() *String { return Double_ToString_D__String(t.F_value) }

func (t *Double) ByteValue__B() int8 { return int8(D2I(t.F_value)) }

func (t *Double) ShortValue__S() int16 { return int16(D2I(t.F_value)) }

func (t *Double) IntValue__I() int32 { return D2I(t.F_value) }

func (t *Double) LongValue__J() int64 { return D2L(t.F_value) }

func (t *Double) FloatValue__F() float32 { return float32(t.F_value) }

func (t *Double) DoubleValue__D() float64 { return t.F_value }


func (t *Double) HashCode__I() int32 { return Double_HashCode_D__I(t.F_value) }

func Double_HashCode_D__I(value float64) int32 {
	return Long_HashCode_J__I(Double_DoubleToLongBits_D__J(value))
}
func (t *Double) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Double_InstanceOf(tmp1) { var d *Double = Double_Cast(tmp1)
		return Double_DoubleToLongBits_D__J(d.F_value) == Double_DoubleToLongBits_D__J(t.F_value) } else {
//line :146:1
			return false
		}
}

func Double_DoubleToLongBits_D__J(value float64) int64 {
	if !Double_IsNaN_D__Z(value) { return Double_DoubleToRawLongBits_D__J(value) } else { return 9221120237041090560
	} }
func Double_DoubleToRawLongBits_D__J(p0 float64) int64 { return Double_DoubleToRawLongBits_D__J_native(p0) }

func Double_LongBitsToDouble_J__D(p0 int64) float64 { return Double_LongBitsToDouble_J__D_native(p0) }

func (t *Double) CompareTo_Double__I(anotherDouble *Double) int32 {
	var tmp1 float64 = t.F_value; return Double_Compare_D_D__I(tmp1, anotherDouble.F_value)
}
func Double_Compare_D_D__I(d1, d2 float64) int32 {
	if d1 < d2 { return -1 } else { if d1 > d2 { return 1 } else {



		var thisBits int64 = Double_DoubleToLongBits_D__J(d1); var anotherBits int64 = Double_DoubleToLongBits_D__J(d2)

		if thisBits == anotherBits { return 0 } else { if thisBits < anotherBits { return -1 } else { return 1
		} } } } }
func Double_Sum_D_D__D(a, b float64) float64 {
	return a + b
}
func Double_Max_D_D__D(a, b float64) float64 {
	return Math_Max_D_D__D(a, b)
}
func Double_Min_D_D__D(a, b float64) float64 {
	return Math_Min_D_D__D(a, b)
}
func (t *Double) DescribeConstable__Optional() *Optional {
	return Optional_Of_O__Optional(t)
}


type Double struct{ Number; F_value float64 }

func (t *Double) Is_Comparable() {}

func (t *Double) Is_Constable() {}

func (t *Double) Is_ConstantDesc() {}

var Double_POSITIVE_INFINITY float64 = PosInf64

var Double_NEGATIVE_INFINITY float64 = NegInf64

var Double_NaN float64 = NaN64

const Double_MAX_VALUE float64 = 1.7976931348623157e308

const Double_MIN_NORMAL float64 = 2.2250738585072014e-308

const Double_MIN_VALUE float64 = 4.9e-324

const Double_SIZE int32 = 64

const Double_PRECISION int32 = 53

const Double_MAX_EXPONENT int32 = 1023

const Double_MIN_EXPONENT int32 = -1022

const Double_BYTES int32 = 8

var Double_TYPE *Class

const Double_serialVersionUID int64 = -9172774392245257468

var Double_init ClassInit

func Double_Init() { if !Double_init.Done() { Double_init.Run(Double_clinit) } }

func Double_clinit() { Double_TYPE = Class_GetPrimitiveClass_String__Class(Lit_1115) }

func (t *Double) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Double__I(Double_Cast(p0)) }

func (t *Double) Ref() any { if t == nil { return nil }; return t }

func (t *Double) GetClass__Class() *Class { return Double_class }

func (t *Double) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Double) CloneShallow() any { panic(CloneNotSupported(t)) }

func Double_InstanceOf(x any) bool { _, ok := x.(*Double); return ok }

func Double_Cast(x any) *Double { if x == nil { return nil }; v, ok := x.(*Double); if !ok { panic(ClassCast(x, Double_class)) }; return v }
