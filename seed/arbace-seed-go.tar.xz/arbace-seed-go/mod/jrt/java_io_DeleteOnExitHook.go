//line java_io_DeleteOnExitHook.ae:1
package jrt










func (t *DeleteOnExitHook_1) Run__V() { DeleteOnExitHook_RunHooks__V() }





func DeleteOnExitHook_New() *DeleteOnExitHook { DeleteOnExitHook_Init(); t := &DeleteOnExitHook{}; t.Ctor(); return t }
//line :18:1
func (t *DeleteOnExitHook) Ctor() { panic(A2g_NotTranslated("java.io.DeleteOnExitHook.<init>()V")) }

func DeleteOnExitHook_Add_String__V(file *String) { DeleteOnExitHook_Init(); MonitorEnter(DeleteOnExitHook_class); defer MonitorExit(DeleteOnExitHook_class)
	if DeleteOnExitHook_files == nil { panic(Thrown(IllegalStateException_New_String(Lit_56))) }
	NN(DeleteOnExitHook_files).Add_O__Z(file.Ref())
}
func DeleteOnExitHook_RunHooks__V() { DeleteOnExitHook_Init()
	var theFiles *LinkedHashSet; var tmp1 any = DeleteOnExitHook_class
	MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); theFiles = DeleteOnExitHook_files; DeleteOnExitHook_files = nil }()
	var toBeDeleted *ArrayList = ArrayList_New_Collection(Up_LinkedHashSet_Collection(theFiles))
	Collections_Reverse_List__V(Up_ArrayList_List(toBeDeleted))
	var i_100998 Iterator = NN(toBeDeleted).Iterator__Iterator(); for i_100998.HasNext__Z() { var filename *String = String_Cast(i_100998.Next__O()); File_New_String(filename).Delete__Z()
	}
}

type DeleteOnExitHook struct{ Object }

var DeleteOnExitHook_files *LinkedHashSet

var DeleteOnExitHook_init ClassInit

func DeleteOnExitHook_Init() { if !DeleteOnExitHook_init.Done() { DeleteOnExitHook_init.Run(DeleteOnExitHook_clinit) } }

func DeleteOnExitHook_clinit() { DeleteOnExitHook_files = LinkedHashSet_New()
//line :10:1
	NN(Runtime_GetRuntime__Runtime()).AddShutdownHook_Thread__V(Thread_New_Runnable(DeleteOnExitHook_1_New()))
}































func (t *DeleteOnExitHook) Ref() any { if t == nil { return nil }; return t }

func (t *DeleteOnExitHook) GetClass__Class() *Class { return DeleteOnExitHook_class }

func (t *DeleteOnExitHook) ToString__String() *String { return Object_toString(t) }

func (t *DeleteOnExitHook) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DeleteOnExitHook) CloneShallow() any { panic(CloneNotSupported(t)) }

func DeleteOnExitHook_InstanceOf(x any) bool { _, ok := x.(*DeleteOnExitHook); return ok }

func DeleteOnExitHook_Cast(x any) *DeleteOnExitHook { if x == nil { return nil }; v, ok := x.(*DeleteOnExitHook); if !ok { panic(ClassCast(x, DeleteOnExitHook_class)) }; return v }



type DeleteOnExitHook_1 struct{ Object }

func (t *DeleteOnExitHook_1) Is_Runnable() {}

func DeleteOnExitHook_1_New() *DeleteOnExitHook_1 { t := &DeleteOnExitHook_1{}; t.Ctor(); return t }

func (t *DeleteOnExitHook_1) Ctor() {}

func (t *DeleteOnExitHook_1) Ref() any { if t == nil { return nil }; return t }

func (t *DeleteOnExitHook_1) GetClass__Class() *Class { return DeleteOnExitHook_1_class }

func (t *DeleteOnExitHook_1) ToString__String() *String { return Object_toString(t) }

func (t *DeleteOnExitHook_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DeleteOnExitHook_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func DeleteOnExitHook_1_InstanceOf(x any) bool { _, ok := x.(*DeleteOnExitHook_1); return ok }

func DeleteOnExitHook_1_Cast(x any) *DeleteOnExitHook_1 { if x == nil { return nil }; v, ok := x.(*DeleteOnExitHook_1); if !ok { panic(ClassCast(x, DeleteOnExitHook_1_class)) }; return v }
