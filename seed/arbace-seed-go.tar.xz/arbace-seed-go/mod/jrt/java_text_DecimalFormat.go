//line java_text_DecimalFormat.ae:1
package jrt













func DecimalFormat_New() *DecimalFormat { DecimalFormat_Init(); t := &DecimalFormat{}; t.Ctor(); return t }
//line :15:1
func (t *DecimalFormat) Ctor() { t.NumberFormat.Ctor(t); t.F_digitList = DigitList_New(); t.F_positivePrefix = Lit_69; t.F_positiveSuffix = Lit_69; t.F_negativePrefix = Lit_1134; t.F_negativeSuffix = Lit_69; t.F_multiplier = 1; t.F_groupingSize = 3; t.F_decimalSeparatorAlwaysShown = false; t.F_parseBigDecimal = false; t.F_isCurrencyFormat = false; t.F_symbols = nil; t.F_parseStrict = false; t.F_maximumIntegerDigits = t.NumberFormat.Impl_GetMaximumIntegerDigits__I(t); t.F_minimumIntegerDigits = t.NumberFormat.Impl_GetMinimumIntegerDigits__I(t); t.F_maximumFractionDigits = t.NumberFormat.Impl_GetMaximumFractionDigits__I(t); t.F_minimumFractionDigits = t.NumberFormat.Impl_GetMinimumFractionDigits__I(t); var tmp1 *RoundingMode; RoundingMode_Init(); tmp1 = RoundingMode_HALF_EVEN; t.F_roundingMode = tmp1; t.F_isFastPath = false; t.F_fastPathCheckNeeded = true; t.F_serialVersionOnStream = 4; var def /*line :16:1*/*Locale; var tmp2 *Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_FORMAT; def = Locale_GetDefault_Locale_Category__Locale(tmp2); var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(NumberFormatProvider_class, def); if

	ResourceBundleBasedAdapter_InstanceOf(adapter) { } else {
		adapter = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter() }; var all /*line :20:1*/*RefArray = NN(adapter.GetLocaleResources_Locale__LocaleResources(def)).GetNumberPatterns__String1();
	t.F_symbols = DecimalFormatSymbols_GetInstance_Locale__DecimalFormatSymbols(def);
	t.ApplyPattern_String_Z__V(As[*String](all.A[0]), false) }

func DecimalFormat_New_String(p0 *String) *DecimalFormat { DecimalFormat_Init(); t := &DecimalFormat{}; t.Ctor_String(p0); return t }
//line :24:1
func (t *DecimalFormat) Ctor_String(pattern *String) { t.NumberFormat.Ctor(t); t.F_digitList = DigitList_New(); t.F_positivePrefix = Lit_69; t.F_positiveSuffix = Lit_69; t.F_negativePrefix = Lit_1134; t.F_negativeSuffix = Lit_69; t.F_multiplier = 1; t.F_groupingSize = 3; t.F_decimalSeparatorAlwaysShown = false; t.F_parseBigDecimal = false; t.F_isCurrencyFormat = false; t.F_symbols = nil; t.F_parseStrict = false; t.F_maximumIntegerDigits = t.NumberFormat.Impl_GetMaximumIntegerDigits__I(t); t.F_minimumIntegerDigits = t.NumberFormat.Impl_GetMinimumIntegerDigits__I(t); t.F_maximumFractionDigits = t.NumberFormat.Impl_GetMaximumFractionDigits__I(t); t.F_minimumFractionDigits = t.NumberFormat.Impl_GetMinimumFractionDigits__I(t); var tmp1 *RoundingMode; RoundingMode_Init(); tmp1 = RoundingMode_HALF_EVEN; t.F_roundingMode = tmp1; t.F_isFastPath = false; t.F_fastPathCheckNeeded = true; t.F_serialVersionOnStream = 4; var tmp2 /*line :25:1*/*Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_FORMAT; t.F_symbols = DecimalFormatSymbols_GetInstance_Locale__DecimalFormatSymbols(Locale_GetDefault_Locale_Category__Locale(tmp2));

	t.ApplyPattern_String_Z__V(pattern, false) }

func DecimalFormat_New_String_DecimalFormatSymbols(p0 *String, p1 *DecimalFormatSymbols) *DecimalFormat { DecimalFormat_Init(); t := &DecimalFormat{}; t.Ctor_String_DecimalFormatSymbols(p0, p1); return t }
//line :29:1
func (t *DecimalFormat) Ctor_String_DecimalFormatSymbols(pattern *String, symbols *DecimalFormatSymbols) { t.NumberFormat.Ctor(t); t.F_digitList = DigitList_New(); t.F_positivePrefix = Lit_69; t.F_positiveSuffix = Lit_69; t.F_negativePrefix = Lit_1134; t.F_negativeSuffix = Lit_69; t.F_multiplier = 1; t.F_groupingSize = 3; t.F_decimalSeparatorAlwaysShown = false; t.F_parseBigDecimal = false; t.F_isCurrencyFormat = false; t.F_symbols = nil; t.F_parseStrict = false; t.F_maximumIntegerDigits = t.NumberFormat.Impl_GetMaximumIntegerDigits__I(t); t.F_minimumIntegerDigits = t.NumberFormat.Impl_GetMinimumIntegerDigits__I(t); t.F_maximumFractionDigits = t.NumberFormat.Impl_GetMaximumFractionDigits__I(t); t.F_minimumFractionDigits = t.NumberFormat.Impl_GetMinimumFractionDigits__I(t); var tmp1 *RoundingMode; RoundingMode_Init(); tmp1 = RoundingMode_HALF_EVEN; t.F_roundingMode = tmp1; t.F_isFastPath = false; t.F_fastPathCheckNeeded = true; t.F_serialVersionOnStream = 4;
														t.F_symbols = DecimalFormatSymbols_Cast(NN(symbols).Clone__O());
														t.ApplyPattern_String_Z__V(pattern, false) }

func (t *DecimalFormat) Format_O_StringBuffer_FieldPosition__StringBuffer(number any, toAppendTo *StringBuffer, pos FieldPosition_I) *StringBuffer {

	var tmp1 any = number; if tmp1 == nil {










		panic(Thrown(IllegalArgumentException_New_String(Lit_1736))) }
//line :35:1
	if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)
		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(l).LongValue__J(), toAppendTo, pos) }
//line :35:1
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)

		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(i).LongValue__J(), toAppendTo, pos) }
//line :35:1
	if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)


		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(s).LongValue__J(), toAppendTo, pos) }
//line :35:1
	if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)



		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(b).LongValue__J(), toAppendTo, pos) }
//line :35:1
	if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)




		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(ai).LongValue__J(), toAppendTo, pos) }
//line :35:1
	if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)





		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(al).LongValue__J(), toAppendTo, pos) }
//line :35:1
	if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1); if NN(bi).BitLength__I() < 64 {






		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(bi).LongValue__J(), toAppendTo, pos) } }
//line :35:1
	if BigDecimal_InstanceOf(tmp1) { var bd *BigDecimal = BigDecimal_Cast(tmp1)







		return t.Format_BigDecimal_Format_StringBuf_FieldPosition__Format_StringBuf(bd, StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo), pos).AsStringBuffer__StringBuffer() }
//line :35:1
	if BigInteger_InstanceOf(tmp1) { var bi_2 *BigInteger = BigInteger_Cast(tmp1)








		return t.Format_BigInteger_Format_StringBuf_FieldPosition__Format_StringBuf(bi_2, StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo), pos).AsStringBuffer__StringBuffer() }
//line :35:1
	if Number_InstanceOf(tmp1) { var n Number_I = Number_Cast(tmp1)









		return t.Format_D_StringBuffer_FieldPosition__StringBuffer(n.DoubleValue__D(), toAppendTo, pos) }
	panic(Thrown(IllegalArgumentException_New_String(Lit_1736)))
}
func (t *DecimalFormat) Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(number any, toAppendTo Format_StringBuf, pos FieldPosition_I) Format_StringBuf {

	var tmp1 any = number; if tmp1 == nil {










		panic(Thrown(IllegalArgumentException_New_String(Lit_1736))) }
//line :50:1
	if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)
		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(l).LongValue__J(), toAppendTo, pos) }
//line :50:1
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)

		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(i).LongValue__J(), toAppendTo, pos) }
//line :50:1
	if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)


		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(s).LongValue__J(), toAppendTo, pos) }
//line :50:1
	if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)



		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(b).LongValue__J(), toAppendTo, pos) }
//line :50:1
	if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)




		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(ai).LongValue__J(), toAppendTo, pos) }
//line :50:1
	if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)





		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(al).LongValue__J(), toAppendTo, pos) }
//line :50:1
	if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1); if NN(bi).BitLength__I() < 64 {






		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(bi).LongValue__J(), toAppendTo, pos) } }
//line :50:1
	if BigDecimal_InstanceOf(tmp1) { var bd *BigDecimal = BigDecimal_Cast(tmp1)







		return t.Format_BigDecimal_Format_StringBuf_FieldPosition__Format_StringBuf(bd, toAppendTo, pos) }
//line :50:1
	if BigInteger_InstanceOf(tmp1) { var bi_2 *BigInteger = BigInteger_Cast(tmp1)








		return t.Format_BigInteger_Format_StringBuf_FieldPosition__Format_StringBuf(bi_2, toAppendTo, pos) }
//line :50:1
	if Number_InstanceOf(tmp1) { var n Number_I = Number_Cast(tmp1)









		return t.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(n.DoubleValue__D(), toAppendTo, pos) }
	panic(Thrown(IllegalArgumentException_New_String(Lit_1736)))
}
func (t *DecimalFormat) Format_D_StringBuffer_FieldPosition__StringBuffer(number float64, result *StringBuffer, fieldPosition FieldPosition_I) *StringBuffer {

	return t.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(number, StringBufFactory_Of_StringBuffer__Format_StringBuf(result), fieldPosition).AsStringBuffer__StringBuffer()
}
func (t *DecimalFormat) Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(number float64, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	var tryFastPath bool = false; var tmp1 FieldPosition_I
	DontCareFieldPosition_Init(); tmp1 = DontCareFieldPosition_INSTANCE; if fieldPosition == tmp1 {
		tryFastPath = true } else {
			fieldPosition.SetBeginIndex_I__V(0); fieldPosition.SetEndIndex_I__V(0) }
	if tryFastPath {
		var tempResult *String = t.FastFormat_D__String(number)
		if !(tempResult == nil) { result.Append_String__Format_StringBuf(tempResult); return result } }
	return t.Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate())
}
func (t *DecimalFormat) Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number float64, result Format_StringBuf, delegate Format_FieldDelegate) Format_StringBuf {

	var nanOrInfinity bool = t.HandleNaN_D_Format_StringBuf_Format_FieldDelegate__Z(number, result, delegate)
	if nanOrInfinity { return result } else {

		var isNegative bool = !(Double_DoubleToRawLongBits_D__J(number) < 0 == (t.F_multiplier < 0))
		if t.F_multiplier == 1 { } else { number = float64(number * float64(t.F_multiplier)) }
		nanOrInfinity = t.HandleInfinity_D_Format_StringBuf_Format_FieldDelegate_Z__Z(number, result, delegate, isNegative)
		if nanOrInfinity { return result } else {


			if isNegative { number = -number }
			var tmp1 bool; var tmp2 bool; tmp2 = number >= 0.0; if tmp2 { tmp2 = !Double_IsInfinite_D__Z(number) }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
			return t.DoubleSubformat_D_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number, result, delegate, isNegative)
		} } }
func (t *DecimalFormat) HandleNaN_D_Format_StringBuf_Format_FieldDelegate__Z(number float64, result Format_StringBuf, delegate Format_FieldDelegate) bool {

	var tmp1 bool; var tmp2 bool; tmp2 = Double_IsNaN_D__Z(number); if !tmp2 { var tmp3 bool; tmp3 = Double_IsInfinite_D__Z(number); if tmp3 { tmp3 = t.F_multiplier == 0 }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 {
		var iFieldStart int32 = result.Length__I()
		result.Append_String__Format_StringBuf(NN(t.F_symbols).GetNaN__String())
		var tmp4 *NumberFormat_Field; NumberFormat_Field_Init(); tmp4 = NumberFormat_Field_INTEGER; var tmp5 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp4); var tmp6 *NumberFormat_Field; NumberFormat_Field_Init(); tmp6 = NumberFormat_Field_INTEGER; var tmp7 any = tmp6.Ref(); delegate.Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(0, tmp5, tmp7, iFieldStart, result.Length__I(), result)
//line :96:1
		return true
	} else {
//line :95:1
		return false
	}
}










func (t *DecimalFormat) HandleInfinity_D_Format_StringBuf_Format_FieldDelegate_Z__Z(number float64, result Format_StringBuf, delegate Format_FieldDelegate, isNegative bool) bool {

	if Double_IsInfinite_D__Z(number) {

		if isNegative {
			var tmp1 *String = t.F_negativePrefix; var tmp2 *RefArray = t.GetNegativePrefixFieldPositions__FieldPosition1(); var tmp3 *NumberFormat_Field; NumberFormat_Field_Init(); tmp3 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp1, delegate, tmp2, Up_NumberFormat_Field_Format_Field(tmp3)) } else {





				var tmp4 *String = t.F_positivePrefix; var tmp5 *RefArray = t.GetPositivePrefixFieldPositions__FieldPosition1(); var tmp6 *NumberFormat_Field; NumberFormat_Field_Init(); tmp6 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp4, delegate, tmp5, Up_NumberFormat_Field_Format_Field(tmp6))
			}




		var iFieldStart int32 = result.Length__I()
		result.Append_String__Format_StringBuf(NN(t.F_symbols).GetInfinity__String())
		var tmp7 *NumberFormat_Field; NumberFormat_Field_Init(); tmp7 = NumberFormat_Field_INTEGER; var tmp8 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp7); var tmp9 *NumberFormat_Field; NumberFormat_Field_Init(); tmp9 = NumberFormat_Field_INTEGER; var tmp10 any = tmp9.Ref(); delegate.Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(0, tmp8, tmp10, iFieldStart, result.Length__I(), result)






		if isNegative {
			var tmp11 *String = t.F_negativeSuffix; var tmp12 *RefArray = t.GetNegativeSuffixFieldPositions__FieldPosition1(); var tmp13 *NumberFormat_Field; NumberFormat_Field_Init(); tmp13 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp11, delegate, tmp12, Up_NumberFormat_Field_Format_Field(tmp13)) } else {





				var tmp14 *String = t.F_positiveSuffix; var tmp15 *RefArray = t.GetPositiveSuffixFieldPositions__FieldPosition1(); var tmp16 *NumberFormat_Field; NumberFormat_Field_Init(); tmp16 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp14, delegate, tmp15, Up_NumberFormat_Field_Format_Field(tmp16)) }
//line :125:1
		return true














	} else {
//line :110:1
		return false
	}
}





































func (t *DecimalFormat) DoubleSubformat_D_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number float64, result Format_StringBuf, delegate Format_FieldDelegate, isNegative bool) Format_StringBuf {

	var tmp1 Format_StringBuf; var tmp2 any = t.F_digitList.Ref(); MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var maxIntDigits int32 = t.NumberFormat.Impl_GetMaximumIntegerDigits__I(t); var minIntDigits int32 = t.NumberFormat.Impl_GetMinimumIntegerDigits__I(t); var maxFraDigits int32 = t.NumberFormat.Impl_GetMaximumFractionDigits__I(t); var minFraDigits int32 = t.NumberFormat.Impl_GetMinimumFractionDigits__I(t); var tmp3 *DigitList = t.F_digitList; var tmp4 int32






		if t.F_useExponentialNotation { tmp4 = maxIntDigits + maxFraDigits } else { tmp4 = maxFraDigits }
//line :157:1
		NN(tmp3).Set_Z_D_I_Z__V(isNegative, number, tmp4, !t.F_useExponentialNotation)




		tmp1 = t.Subformat_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__Format_StringBuf(result, delegate, isNegative, false, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits) }()
//line :152:1
	return tmp1
}


















func (t *DecimalFormat) Format_J_StringBuffer_FieldPosition__StringBuffer(number int64, result *StringBuffer, fieldPosition FieldPosition_I) *StringBuffer {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, StringBufFactory_Of_StringBuffer__Format_StringBuf(result), fieldPosition.GetFieldDelegate__Format_FieldDelegate()).AsStringBuffer__StringBuffer()
}

func (t *DecimalFormat) Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(number int64, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate())
}
func (t *DecimalFormat) Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number int64, result Format_StringBuf, delegate Format_FieldDelegate) Format_StringBuf {

	var isNegative bool = number < 0
	if isNegative { number = -number }
	var useBigInteger bool = false
	if number < 0 {
		if t.F_multiplier == 0 { } else { useBigInteger = true } } else {
//line :190:1
			var tmp1 bool; var tmp2 bool

			tmp2 = !(t.F_multiplier == 1); if tmp2 { tmp2 = !(t.F_multiplier == 0) }; tmp1 = tmp2
//line :190:1
			if tmp1 {


				var cutoff int64 = 9223372036854775807 / int64(t.F_multiplier)
				if cutoff < 0 { cutoff = -cutoff }
				useBigInteger = number > cutoff } }
	if useBigInteger {

		if isNegative { number = -number }
		var bigIntegerValue *BigInteger = BigInteger_ValueOf_J__BigInteger(number)
		return t.Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(bigIntegerValue, result, delegate, true) } else {

			number = number * int64(t.F_multiplier)
			if number == 0 {
				isNegative = false } else {
					if t.F_multiplier < 0 {
						number = -number
						isNegative = !isNegative } }
			var tmp3 Format_StringBuf; var tmp4 any = t.F_digitList.Ref(); MonitorEnter(tmp4); func() { defer MonitorExit(tmp4)
				var maxIntDigits int32 = t.NumberFormat.Impl_GetMaximumIntegerDigits__I(t); var minIntDigits int32 = t.NumberFormat.Impl_GetMinimumIntegerDigits__I(t); var maxFraDigits int32 = t.NumberFormat.Impl_GetMaximumFractionDigits__I(t); var minFraDigits int32 = t.NumberFormat.Impl_GetMinimumFractionDigits__I(t); var tmp5 *DigitList = t.F_digitList; var tmp6 bool = isNegative; var tmp7 int64 = number; var tmp8 int32






				if t.F_useExponentialNotation { tmp8 = maxIntDigits + maxFraDigits } else { tmp8 = 0 }
//line :213:1
				NN(tmp5).Set_Z_J_I__V(tmp6, tmp7, tmp8)



				tmp3 = t.Subformat_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__Format_StringBuf(result, delegate, isNegative, true, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits) }()
//line :208:1
			return tmp3
		}
}
















func (t *DecimalFormat) Format_BigDecimal_Format_StringBuf_FieldPosition__Format_StringBuf(number *BigDecimal, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate())
}
func (t *DecimalFormat) Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number *BigDecimal, result Format_StringBuf, delegate Format_FieldDelegate) Format_StringBuf {

	if t.F_multiplier == 1 { } else { number = NN(number).Multiply_BigDecimal__BigDecimal(t.GetBigDecimalMultiplier__BigDecimal()) }
	var isNegative bool = NN(number).Signum__I() == -1
	if isNegative { number = NN(number).Negate__BigDecimal() }
	var tmp1 Format_StringBuf; var tmp2 any = t.F_digitList.Ref(); MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var maxIntDigits int32 = t.GetMaximumIntegerDigits__I(); var minIntDigits int32 = t.GetMinimumIntegerDigits__I(); var maxFraDigits int32 = t.GetMaximumFractionDigits__I(); var minFraDigits int32 = t.GetMinimumFractionDigits__I(); var maximumDigits int32 = maxIntDigits + maxFraDigits; var tmp3 *DigitList = t.F_digitList; var tmp4 *BigDecimal = number; var tmp5 int32







		if t.F_useExponentialNotation {
			if maximumDigits < 0 { tmp5 = 2147483647 } else { tmp5 = maximumDigits } } else {
//line :247:1
				tmp5 = maxFraDigits }
//line :244:1
		NN(tmp3).Set_Z_BigDecimal_I_Z__V(isNegative, tmp4, tmp5, !t.F_useExponentialNotation)






		tmp1 = t.Subformat_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__Format_StringBuf(result, delegate, isNegative, false, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits) }()
//line :238:1
	return tmp1
}





















func (t *DecimalFormat) Format_BigInteger_Format_StringBuf_FieldPosition__Format_StringBuf(number *BigInteger, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate(), false)
}
func (t *DecimalFormat) Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number *BigInteger, result Format_StringBuf, delegate Format_FieldDelegate, formatLong bool) Format_StringBuf {

	if t.F_multiplier == 1 { } else { number = NN(number).Multiply_BigInteger__BigInteger(t.GetBigIntegerMultiplier__BigInteger()) }
	var isNegative bool = NN(number).Signum__I() == -1
	if isNegative { number = NN(number).Negate__BigInteger() }
	var tmp1 Format_StringBuf; var tmp2 any = t.F_digitList.Ref(); MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var maxIntDigits int32 = 0
		var minIntDigits int32 = 0
		var maxFraDigits int32 = 0
		var minFraDigits int32 = 0
		var maximumDigits int32 = 0
		if formatLong {

			maxIntDigits = t.NumberFormat.Impl_GetMaximumIntegerDigits__I(t)
			minIntDigits = t.NumberFormat.Impl_GetMinimumIntegerDigits__I(t)
			maxFraDigits = t.NumberFormat.Impl_GetMaximumFractionDigits__I(t)
			minFraDigits = t.NumberFormat.Impl_GetMinimumFractionDigits__I(t)
			maximumDigits = maxIntDigits + maxFraDigits } else {

				maxIntDigits = t.GetMaximumIntegerDigits__I()
				minIntDigits = t.GetMinimumIntegerDigits__I()
				maxFraDigits = t.GetMaximumFractionDigits__I()
				minFraDigits = t.GetMinimumFractionDigits__I()
				maximumDigits = maxIntDigits + maxFraDigits
				if maximumDigits < 0 { maximumDigits = 2147483647 } }
		var tmp3 *DigitList = t.F_digitList; var tmp4 *BigInteger = number; var tmp5 int32; if t.F_useExponentialNotation { tmp5 = maximumDigits } else { tmp5 = 0 }; NN(tmp3).Set_Z_BigInteger_I__V(isNegative, tmp4, tmp5)
		tmp1 = t.Subformat_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__Format_StringBuf(result, delegate, isNegative, true, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits) }()
//line :272:1
	return tmp1
}





























func (t *DecimalFormat) FormatToCharacterIterator_O__AttributedCharacterIterator(obj any) AttributedCharacterIterator {
	var delegate *CharacterIteratorFieldDelegate = CharacterIteratorFieldDelegate_New(); var sb Format_StringBuf = StringBufFactory_Of__Format_StringBuf()
	var tmp1 any = obj
L1: switch { default: if tmp1 == nil {











	panic(Thrown(NullPointerException_New_String(Lit_1737))) }
//line :306:1
	if Double_InstanceOf(tmp1) { var d *Double = Double_Cast(tmp1)
		t.Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(d).DoubleValue__D(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
		break L1 }; if Float_InstanceOf(tmp1) { var f *Float = Float_Cast(tmp1)

			t.Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(f).DoubleValue__D(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
			break L1 }; if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)


				t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(l).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
				break L1 }; if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)



					t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(i).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
					break L1 }; if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)




						t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(s).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
						break L1 }; if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)





							t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(b).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
							break L1 }; if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)






								t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(ai).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
								break L1 }; if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)







									t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(al).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
									break L1 }; if BigDecimal_InstanceOf(tmp1) { var bd *BigDecimal = BigDecimal_Cast(tmp1)








										t.Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(bd, sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :306:1
										break L1 }; if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1)









											t.Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(bi, sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate), false)
//line :306:1
											break L1
										}











	panic(Thrown(IllegalArgumentException_New_String(Lit_1736)))}
	return NN(delegate).GetIterator_String__AttributedCharacterIterator(sb.ToString__String())
}
func (t *DecimalFormat) CheckAndSetFastPathStatus__Z() bool {
	var fastPathWasOn bool = t.F_isFastPath; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 *RoundingMode = t.F_roundingMode; var tmp8 *RoundingMode
	RoundingMode_Init(); tmp8 = RoundingMode_HALF_EVEN; tmp6 = tmp7 == tmp8; if tmp6 {
		tmp6 = t.IsGroupingUsed__Z() }
//line :324:1
	tmp5 = tmp6; if tmp5 {

		tmp5 = int32(t.F_groupingSize) == 3 }
//line :324:1
	tmp4 = tmp5; if tmp4 {


		tmp4 = t.F_multiplier == 1 }
//line :324:1
	tmp3 = tmp4; if tmp3 {



		tmp3 = !t.F_decimalSeparatorAlwaysShown }
//line :324:1
	tmp2 = tmp3; if tmp2 {




		tmp2 = !t.F_useExponentialNotation }
//line :324:1
	tmp1 = tmp2; if tmp1 {






		var tmp9 bool; var tmp10 bool; tmp10 = t.F_minimumIntegerDigits == 1; if tmp10 { tmp10 = t.F_maximumIntegerDigits >= 10 }; tmp9 = tmp10; t.F_isFastPath = tmp9
		if t.F_isFastPath {
			if t.F_isCurrencyFormat {

				var tmp11 bool; var tmp12 bool; tmp12 = !(t.F_minimumFractionDigits == 2); if !tmp12 { tmp12 = !(t.F_maximumFractionDigits == 2) }; tmp11 = tmp12; if tmp11 {
					t.F_isFastPath = false } } else {
//line :333:1
						var tmp13 bool; var tmp14 bool



						tmp14 = !(t.F_minimumFractionDigits == 0); if !tmp14 { tmp14 = !(t.F_maximumFractionDigits == 3) }; tmp13 = tmp14
//line :333:1
						if tmp13 {




							t.F_isFastPath = false } } } } else {
								t.F_isFastPath = false }
	t.ResetFastPathData_Z__V(fastPathWasOn)
	t.F_fastPathCheckNeeded = false
//line :323:1
	return true
}



















func (t *DecimalFormat) ResetFastPathData_Z__V(fastPathWasOn bool) {
	if t.F_isFastPath {

		if t.F_fastPathData == nil { t.F_fastPathData = DecimalFormat_FastPathData_New() }
		var tmp1 *DecimalFormat_FastPathData = t.F_fastPathData; tmp1.F_zeroDelta = int32(NN(t.F_symbols).GetZeroDigit__C()) - 48
		var tmp2 *DecimalFormat_FastPathData = t.F_fastPathData; var tmp3 uint16
		if t.F_isCurrencyFormat {
			tmp3 = NN(t.F_symbols).GetMonetaryGroupingSeparator__C() } else {
				tmp3 = NN(t.F_symbols).GetGroupingSeparator__C() }
//line :349:1
		tmp2.F_groupingChar = tmp3



		var tmp4 *DecimalFormat_FastPathData = t.F_fastPathData; var tmp5 int32; if t.F_isCurrencyFormat { tmp5 = 99 } else { tmp5 = 999 }; tmp4.F_fractionalMaxIntBound = tmp5
		var tmp6 *DecimalFormat_FastPathData = t.F_fastPathData; var tmp7 float64; if t.F_isCurrencyFormat { tmp7 = 100.0 } else { tmp7 = 1000.0 }; tmp6.F_fractionalScaleFactor = tmp7
		var tmp8 *DecimalFormat_FastPathData = t.F_fastPathData; var tmp9 bool; var tmp10 bool
		tmp10 = !NN(t.F_positivePrefix).IsEmpty__Z(); if !tmp10 { tmp10 = !NN(t.F_positiveSuffix).IsEmpty__Z() }; tmp9 = tmp10
//line :355:1
		tmp8.F_positiveAffixesRequired = tmp9

		var tmp11 *DecimalFormat_FastPathData = t.F_fastPathData; var tmp12 bool; var tmp13 bool
		tmp13 = !NN(t.F_negativePrefix).IsEmpty__Z(); if !tmp13 { tmp13 = !NN(t.F_negativeSuffix).IsEmpty__Z() }; tmp12 = tmp13
//line :357:1
		tmp11.F_negativeAffixesRequired = tmp12

		var maxNbIntegralDigits int32 = 10; var maxNbGroups int32 = 3; var tmp14 int32 = Math_Max_I_I__I(NN(t.F_positivePrefix).Length__I(), NN(t.F_negativePrefix).Length__I()) + maxNbIntegralDigits + maxNbGroups + 1 + t.F_maximumFractionDigits; var containerSize int32 = tmp14 + Math_Max_I_I__I(NN(t.F_positiveSuffix).Length__I(), NN(t.F_negativeSuffix).Length__I()); var tmp15 *DecimalFormat_FastPathData = t.F_fastPathData












		tmp15.F_fastPathContainer = NewCharArray(containerSize)
		var tmp16 *DecimalFormat_FastPathData = t.F_fastPathData; tmp16.F_charsPositiveSuffix = NN(t.F_positiveSuffix).ToCharArray__C1()
		var tmp17 *DecimalFormat_FastPathData = t.F_fastPathData; tmp17.F_charsNegativeSuffix = NN(t.F_negativeSuffix).ToCharArray__C1()
		var tmp18 *DecimalFormat_FastPathData = t.F_fastPathData; tmp18.F_charsPositivePrefix = NN(t.F_positivePrefix).ToCharArray__C1()
		var tmp19 *DecimalFormat_FastPathData = t.F_fastPathData; tmp19.F_charsNegativePrefix = NN(t.F_negativePrefix).ToCharArray__C1()
		var longestPrefixLength int32 = Math_Max_I_I__I(NN(t.F_positivePrefix).Length__I(), NN(t.F_negativePrefix).Length__I()); var decimalPointIndex int32 = maxNbIntegralDigits + maxNbGroups + longestPrefixLength



		t.F_fastPathData.F_integralLastIndex = decimalPointIndex - 1
		t.F_fastPathData.F_fractionalFirstIndex = decimalPointIndex + 1
		var tmp20 *CharArray = t.F_fastPathData.F_fastPathContainer; var tmp21 uint16

		if t.F_isCurrencyFormat {
			tmp21 = NN(t.F_symbols).GetMonetaryDecimalSeparator__C() } else {
				tmp21 = NN(t.F_symbols).GetDecimalSeparator__C() }
//line :383:1
		tmp20.A[decimalPointIndex] = tmp21


	} else {

		if fastPathWasOn {
			t.F_fastPathData.F_fastPathContainer = nil
			t.F_fastPathData.F_charsPositiveSuffix = nil
			t.F_fastPathData.F_charsNegativeSuffix = nil
			t.F_fastPathData.F_charsPositivePrefix = nil
			t.F_fastPathData.F_charsNegativePrefix = nil
		} } }
func (t *DecimalFormat) ExactRoundUp_D_I__Z(fractionalPart float64, scaledFractionalPartAsInt int32) bool {

	var approxMax float64 = 0.0
	var approxMedium float64 = 0.0
	var approxMin float64 = 0.0
	var fastTwoSumApproximation float64 = 0.0
	var fastTwoSumRoundOff float64 = 0.0
	var bVirtual float64 = 0.0
	if t.F_isCurrencyFormat {

		approxMax = float64(fractionalPart * 128.0)
		approxMedium = -float64(fractionalPart * 32.0)
		approxMin = float64(fractionalPart * 4.0) } else {

			approxMax = float64(fractionalPart * 1024.0)
			approxMedium = -float64(fractionalPart * 16.0)
			approxMin = -float64(fractionalPart * 8.0) }
	if !A2g_AssertionsDisabled && !(-approxMedium >= Math_Abs_D__D(approxMin)) { panic(Thrown(AssertionError_New())) }
	fastTwoSumApproximation = approxMedium + approxMin
	bVirtual = fastTwoSumApproximation - approxMedium
	fastTwoSumRoundOff = approxMin - bVirtual
	var approxS1 float64 = fastTwoSumApproximation
	var roundoffS1 float64 = fastTwoSumRoundOff
	if !A2g_AssertionsDisabled && !(approxMax >= Math_Abs_D__D(approxS1)) { panic(Thrown(AssertionError_New())) }
	fastTwoSumApproximation = approxMax + approxS1
	bVirtual = fastTwoSumApproximation - approxMax
	fastTwoSumRoundOff = approxS1 - bVirtual
	var roundoff1000 float64 = fastTwoSumRoundOff; var approx1000 float64 = fastTwoSumApproximation; var roundoffTotal float64 = roundoffS1 + roundoff1000


	if !A2g_AssertionsDisabled && !(approx1000 >= Math_Abs_D__D(roundoffTotal)) { panic(Thrown(AssertionError_New())) }
	fastTwoSumApproximation = approx1000 + roundoffTotal
	bVirtual = fastTwoSumApproximation - approx1000
	var scaledFractionalRoundoff float64 = roundoffTotal - bVirtual
	if scaledFractionalRoundoff > 0.0 { return true } else { if scaledFractionalRoundoff < 0.0 { return false } else { if !(scaledFractionalPartAsInt&1 == 0) { return true } else { return false
	}
	}
	}
}

func (t *DecimalFormat) CollectIntegralDigits_I_C1_I__V(number int32, digitsBuffer *CharArray, backwardIndex int32) {

	var index int32 = backwardIndex
	var q int32 = 0
	var r int32 = 0
L1: for { if number > 999 {
	q = number / 1000
	r = number - q<<10 + q<<4 + q<<3




	number = q
	var tmp1 int32 = index; var tmp2 *CharArray; DecimalFormat_DigitArrays_Init(); tmp2 = DecimalFormat_DigitArrays_DigitOnes1000; digitsBuffer.A[tmp1] = tmp2.A[r]
	index = index - 1
	var tmp3 int32 = index; var tmp4 *CharArray; DecimalFormat_DigitArrays_Init(); tmp4 = DecimalFormat_DigitArrays_DigitTens1000; digitsBuffer.A[tmp3] = tmp4.A[r]
	index = index - 1
	var tmp5 int32 = index; var tmp6 *CharArray; DecimalFormat_DigitArrays_Init(); tmp6 = DecimalFormat_DigitArrays_DigitHundreds1000; digitsBuffer.A[tmp5] = tmp6.A[r]
	index = index - 1
	digitsBuffer.A[index] = t.F_fastPathData.F_groupingChar
	index = index - 1
//line :440:1
	continue L1 }; break L1
}














	var tmp7 int32 = index; var tmp8 *CharArray; DecimalFormat_DigitArrays_Init(); tmp8 = DecimalFormat_DigitArrays_DigitOnes1000; digitsBuffer.A[tmp7] = tmp8.A[number]
	if number > 9 {
		var tmp9 int32
		index = index - 1; tmp9 = index
//line :458:1
		var tmp10 int32 = tmp9; var tmp11 *CharArray; DecimalFormat_DigitArrays_Init(); tmp11 = DecimalFormat_DigitArrays_DigitTens1000; digitsBuffer.A[tmp10] = tmp11.A[number]


		if number > 99 {
			var tmp12 int32
			index = index - 1; tmp12 = index
//line :462:1
			var tmp13 int32 = tmp12; var tmp14 *CharArray; DecimalFormat_DigitArrays_Init(); tmp14 = DecimalFormat_DigitArrays_DigitHundreds1000; digitsBuffer.A[tmp13] = tmp14.A[number]
		}
	}
	t.F_fastPathData.F_firstUsedIndex = index
}
func (t *DecimalFormat) CollectFractionalDigits_I_C1_I__V(number int32, digitsBuffer *CharArray, startIndex int32) {

	var index int32 = startIndex; var digitOnes uint16; var tmp1 *CharArray
	DecimalFormat_DigitArrays_Init(); tmp1 = DecimalFormat_DigitArrays_DigitOnes1000; digitOnes = tmp1.A[number]
//line :469:1
	var digitTens uint16; var tmp2 *CharArray

	DecimalFormat_DigitArrays_Init(); tmp2 = DecimalFormat_DigitArrays_DigitTens1000; digitTens = tmp2.A[number]
	if t.F_isCurrencyFormat {


		digitsBuffer.A[index] = digitTens
		index = index + 1
		digitsBuffer.A[index] = digitOnes
		index = index + 1 } else {
//line :472:1
			if !(number == 0) {








				var tmp3 int32 = index; var tmp4 *CharArray; DecimalFormat_DigitArrays_Init(); tmp4 = DecimalFormat_DigitArrays_DigitHundreds1000; digitsBuffer.A[tmp3] = tmp4.A[number]
				index = index + 1
				if !(int32(digitOnes) == 48) {

					digitsBuffer.A[index] = digitTens
					index = index + 1
					digitsBuffer.A[index] = digitOnes
					index = index + 1 } else {
						if int32(digitTens) == 48 { } else {
							digitsBuffer.A[index] = digitTens
							index = index + 1 } } } else {
								index = index - 1 } }
	t.F_fastPathData.F_lastFreeIndex = index
}
func (t *DecimalFormat) AddAffixes_C1_C1_C1__V(container, prefix, suffix *CharArray) {
	var pl int32 = int32(len(prefix.A)); var sl int32 = int32(len(suffix.A))

	if pl == 0 { } else { t.PrependPrefix_C1_I_C1__V(prefix, pl, container) }
	if sl == 0 { } else { t.AppendSuffix_C1_I_C1__V(suffix, sl, container)
	} }
func (t *DecimalFormat) PrependPrefix_C1_I_C1__V(prefix *CharArray, len_ int32, container *CharArray) {
	var tmp1 *DecimalFormat_FastPathData = t.F_fastPathData; tmp1.F_firstUsedIndex = t.F_fastPathData.F_firstUsedIndex - len_

	var startIndex int32 = t.F_fastPathData.F_firstUsedIndex
	if len_ == 1 {
		container.A[startIndex] = prefix.A[0] } else {
//line :505:1
			if len_ <= 4 {


				var dstLower int32 = startIndex; var dstUpper int32 = dstLower + len_ - 1; var srcUpper int32 = len_ - 1


				container.A[dstLower] = prefix.A[0]
				container.A[dstUpper] = prefix.A[srcUpper]
				if len_ > 2 {
					var tmp2 int32; dstLower = dstLower + 1; tmp2 = dstLower; container.A[tmp2] = prefix.A[1] }
				if len_ == 4 {
					var tmp3 int32; dstUpper = dstUpper - 1; tmp3 = dstUpper; container.A[tmp3] = prefix.A[2] } } else {
						System_Arraycopy_O_I_O_I_I__V(prefix.Ref(), 0, container.Ref(), startIndex, len_)
					} } }
func (t *DecimalFormat) AppendSuffix_C1_I_C1__V(suffix *CharArray, len_ int32, container *CharArray) {
	var startIndex int32 = t.F_fastPathData.F_lastFreeIndex
	if len_ == 1 {
		container.A[startIndex] = suffix.A[0] } else {
//line :521:1
			if len_ <= 4 {


				var dstLower int32 = startIndex; var dstUpper int32 = dstLower + len_ - 1; var srcUpper int32 = len_ - 1


				container.A[dstLower] = suffix.A[0]
				container.A[dstUpper] = suffix.A[srcUpper]
				if len_ > 2 {
					var tmp1 int32; dstLower = dstLower + 1; tmp1 = dstLower; container.A[tmp1] = suffix.A[1] }
				if len_ == 4 {
					var tmp2 int32; dstUpper = dstUpper - 1; tmp2 = dstUpper; container.A[tmp2] = suffix.A[2] } } else {
						System_Arraycopy_O_I_O_I_I__V(suffix.Ref(), 0, container.Ref(), startIndex, len_) } }
	var tmp3 *DecimalFormat_FastPathData = t.F_fastPathData; tmp3.F_lastFreeIndex = t.F_fastPathData.F_lastFreeIndex + len_
}
func (t *DecimalFormat) LocalizeDigits_C1__V(digitsBuffer *CharArray) {
	var tmp1 int32 = t.F_fastPathData.F_lastFreeIndex; var digitsCounter int32 = tmp1 - t.F_fastPathData.F_fractionalFirstIndex


	if digitsCounter < 0 { digitsCounter = int32(t.F_groupingSize) }
	var cursor int32 = t.F_fastPathData.F_lastFreeIndex - 1; L1: for {
		if cursor >= t.F_fastPathData.F_firstUsedIndex {
			if !(digitsCounter == 0) {

				var tmp2 int32 = int32(digitsBuffer.A[cursor]); digitsBuffer.A[cursor] = uint16(tmp2 + int32(uint16(t.F_fastPathData.F_zeroDelta)))




				digitsCounter = digitsCounter - 1
				cursor = cursor - 1; continue L1 } else {
					digitsCounter = int32(t.F_groupingSize); cursor = cursor - 1; continue L1 } }
//line :541:1
		break L1
	}
}











func (t *DecimalFormat) FastDoubleFormat_D_Z__V(d float64, negative bool) {
	var container *CharArray = t.F_fastPathData.F_fastPathContainer; var integralPartAsInt int32 = D2I(d); var exactFractionalPart float64 = d - float64(integralPartAsInt); var scaledFractional float64 = float64(exactFractionalPart * t.F_fastPathData.F_fractionalScaleFactor); var fractionalPartAsInt int32 = D2I(scaledFractional)






	scaledFractional = scaledFractional - float64(fractionalPartAsInt)
	var roundItUp bool = false
	if scaledFractional >= 0.5 {
		if scaledFractional == 0.5 {
			roundItUp = t.ExactRoundUp_D_I__Z(exactFractionalPart, fractionalPartAsInt) } else {
				roundItUp = true }
		if roundItUp {
			if fractionalPartAsInt < t.F_fastPathData.F_fractionalMaxIntBound {
				fractionalPartAsInt = fractionalPartAsInt + 1 } else {

					fractionalPartAsInt = 0
					integralPartAsInt = integralPartAsInt + 1 } } }
	t.CollectFractionalDigits_I_C1_I__V(fractionalPartAsInt, container, t.F_fastPathData.F_fractionalFirstIndex)



	t.CollectIntegralDigits_I_C1_I__V(integralPartAsInt, container, t.F_fastPathData.F_integralLastIndex)
	if t.F_fastPathData.F_zeroDelta == 0 { } else { t.LocalizeDigits_C1__V(container) }
	if negative {

		if t.F_fastPathData.F_negativeAffixesRequired {
			var tmp1 *CharArray = t.F_fastPathData.F_charsNegativePrefix; t.AddAffixes_C1_C1_C1__V(container, tmp1, t.F_fastPathData.F_charsNegativeSuffix) } } else {
//line :581:1
				if t.F_fastPathData.F_positiveAffixesRequired {







					var tmp2 *CharArray = t.F_fastPathData.F_charsPositivePrefix; t.AddAffixes_C1_C1_C1__V(container, tmp2, t.F_fastPathData.F_charsPositiveSuffix)
				}
			}
}

func (t *DecimalFormat) FastFormat_D__String(d float64) *String {
	var isDataSet bool = false
	if t.F_fastPathCheckNeeded { isDataSet = t.CheckAndSetFastPathStatus__Z() }
	if !t.F_isFastPath { return nil } else {
		if !Double_IsFinite_D__Z(d) { return nil } else {
			var negative bool = false
			if d < 0.0 {
				negative = true; d = -d } else {
					if d == 0.0 {
						negative = Math_CopySign_D_D__D(1.0, d) == -1.0
						d = 0.0 } }
			if d > 2.147483647e9 { return nil } else {
				if isDataSet { } else { t.ResetFastPathData_Z__V(t.F_isFastPath) }
				t.FastDoubleFormat_D_Z__V(d, negative)
				var tmp1 *CharArray = t.F_fastPathData.F_fastPathContainer; var tmp2 int32 = t.F_fastPathData.F_firstUsedIndex; var tmp3 int32 = t.F_fastPathData.F_lastFreeIndex; return String_New_C1_I_I(tmp1, tmp2, tmp3-t.F_fastPathData.F_firstUsedIndex)
			}
		}
	}
}
func (t *DecimalFormat) SetDigitList_Number_Z_I__V(number Number_I, isNegative bool, maxDigits int32) {
	var tmp1 Number_I = number; L1: switch { default: if tmp1 == nil { panic(NPE()) }; if Double_InstanceOf(tmp1) { var d *Double = Double_Cast(tmp1)
		{ var tmp2 *DigitList = t.F_digitList; NN(tmp2).Set_Z_D_I_Z__V(isNegative, NN(d).DoubleValue__D(), maxDigits, true) }; break L1 }
//line :614:1
		if BigDecimal_InstanceOf(tmp1) { var bd *BigDecimal = BigDecimal_Cast(tmp1)

			NN(t.F_digitList).Set_Z_BigDecimal_I_Z__V(isNegative, bd, maxDigits, true)
//line :614:1
			break L1 }; if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)


				{ var tmp3 *DigitList = t.F_digitList; NN(tmp3).Set_Z_J_I__V(isNegative, NN(l).LongValue__J(), maxDigits) }
//line :614:1
				break L1 }; if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1)



					NN(t.F_digitList).Set_Z_BigInteger_I__V(isNegative, bi, maxDigits)
//line :614:1
					break L1
				}



		panic(Thrown(AssertionError_New_O(String_Format_String_O1__String(Lit_1817, RefArrayOf(Object_class, NN(number.GetClass__Class()).GetName__String().Ref())).Ref())))
	}
}

func (t *DecimalFormat) GetDigitList__DigitList() *DigitList { return t.F_digitList }

func (t *DecimalFormat) Subformat_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__Format_StringBuf(result Format_StringBuf, delegate Format_FieldDelegate, isNegative, isInteger bool, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits int32) Format_StringBuf {




	if isNegative {
		var tmp1 *String = t.F_negativePrefix; var tmp2 *RefArray = t.GetNegativePrefixFieldPositions__FieldPosition1(); var tmp3 *NumberFormat_Field; NumberFormat_Field_Init(); tmp3 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp1, delegate, tmp2, Up_NumberFormat_Field_Format_Field(tmp3)) } else {





			var tmp4 *String = t.F_positivePrefix; var tmp5 *RefArray = t.GetPositivePrefixFieldPositions__FieldPosition1(); var tmp6 *NumberFormat_Field; NumberFormat_Field_Init(); tmp6 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp4, delegate, tmp5, Up_NumberFormat_Field_Format_Field(tmp6))
		}




	t.SubformatNumber_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__V(result, delegate, isNegative, isInteger, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits)








	if isNegative {
		var tmp7 *String = t.F_negativeSuffix; var tmp8 *RefArray = t.GetNegativeSuffixFieldPositions__FieldPosition1(); var tmp9 *NumberFormat_Field; NumberFormat_Field_Init(); tmp9 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp7, delegate, tmp8, Up_NumberFormat_Field_Format_Field(tmp9)) } else {





			var tmp10 *String = t.F_positiveSuffix; var tmp11 *RefArray = t.GetPositiveSuffixFieldPositions__FieldPosition1(); var tmp12 *NumberFormat_Field; NumberFormat_Field_Init(); tmp12 = NumberFormat_Field_SIGN; t.Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result, tmp10, delegate, tmp11, Up_NumberFormat_Field_Format_Field(tmp12)) }
//line :625:1
	return result
}








































func (t *DecimalFormat) SubformatNumber_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__V(result Format_StringBuf, delegate Format_FieldDelegate, isNegative, isInteger bool, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits int32) {


	var grouping uint16; if t.F_isCurrencyFormat {
		grouping = NN(t.F_symbols).GetMonetaryGroupingSeparator__C() } else {
			grouping = NN(t.F_symbols).GetGroupingSeparator__C() }
//line :670:1
	var zero uint16 = NN(t.F_symbols).GetZeroDigit__C(); var zeroDelta int32 = int32(zero) - 48; var decimal uint16




	if t.F_isCurrencyFormat {
		decimal = NN(t.F_symbols).GetMonetaryDecimalSeparator__C() } else {
			decimal = NN(t.F_symbols).GetDecimalSeparator__C() }
	if NN(t.F_digitList).IsZero__Z() { t.F_digitList.F_decimalAt = 0 }
	if t.F_useExponentialNotation {
		var iFieldStart int32 = result.Length__I(); var iFieldEnd int32 = -1; var fFieldStart int32 = -1; var exponent int32 = t.F_digitList.F_decimalAt; var repeat int32 = maxIntDigits; var minimumIntegerDigits int32 = minIntDigits; var tmp1 bool; var tmp2 bool





		tmp2 = repeat > 1; if tmp2 { tmp2 = repeat > minIntDigits }; tmp1 = tmp2; if tmp1 {

			if exponent >= 1 {
				exponent = (exponent - 1) / repeat * repeat } else {



					exponent = (exponent - repeat) / repeat * repeat
				}


			minimumIntegerDigits = 1 } else {
				exponent = exponent - minimumIntegerDigits }
		var minimumDigits int32 = minIntDigits + minFraDigits
		if minimumDigits < 0 { minimumDigits = 2147483647 }
		var integerDigits int32; if NN(t.F_digitList).IsZero__Z() { integerDigits = minimumIntegerDigits } else {

			integerDigits = t.F_digitList.F_decimalAt - exponent }
		if minimumDigits < integerDigits { minimumDigits = integerDigits }
		var totalDigits int32 = t.F_digitList.F_count
		if minimumDigits > totalDigits { totalDigits = minimumDigits }
		var addedDecimalSeparator bool = false; var i int32 = 0
	L1: for {
		if i < totalDigits {
			if i == integerDigits {
				iFieldEnd = result.Length__I()
				result.Append_C__Format_StringBuf(decimal)
				addedDecimalSeparator = true
				fFieldStart = result.Length__I() }
			var tmp3 uint16
			if i < t.F_digitList.F_count {
				tmp3 = uint16(int32(t.F_digitList.F_digits.A[i]) + zeroDelta) } else {
//line :716:1
					tmp3 = zero }
//line :715:1
			result.Append_C__Format_StringBuf(tmp3)




			i = i + 1; continue L1 }
//line :708:1
		break L1
	}











		var tmp4 bool; var tmp5 bool; tmp5 = t.F_decimalSeparatorAlwaysShown; if tmp5 { tmp5 = totalDigits == integerDigits }; tmp4 = tmp5; if tmp4 {
			iFieldEnd = result.Length__I()
			result.Append_C__Format_StringBuf(decimal)
			addedDecimalSeparator = true
			fFieldStart = result.Length__I() }
		if iFieldEnd == -1 { iFieldEnd = result.Length__I() }
		var tmp6 *NumberFormat_Field; NumberFormat_Field_Init(); tmp6 = NumberFormat_Field_INTEGER; var tmp7 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp6); var tmp8 *NumberFormat_Field; NumberFormat_Field_Init(); tmp8 = NumberFormat_Field_INTEGER; delegate.Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(0, tmp7, tmp8.Ref(), iFieldStart, iFieldEnd, result)






		if addedDecimalSeparator {
			var tmp9 *NumberFormat_Field; NumberFormat_Field_Init(); tmp9 = NumberFormat_Field_DECIMAL_SEPARATOR; var tmp10 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp9); var tmp11 *NumberFormat_Field; NumberFormat_Field_Init(); tmp11 = NumberFormat_Field_DECIMAL_SEPARATOR; delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(tmp10, tmp11.Ref(), iFieldEnd, fFieldStart, result)
		}




		if fFieldStart == -1 { fFieldStart = result.Length__I() }
		var tmp12 *NumberFormat_Field; NumberFormat_Field_Init(); tmp12 = NumberFormat_Field_FRACTION; var tmp13 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp12); var tmp14 *NumberFormat_Field; NumberFormat_Field_Init(); tmp14 = NumberFormat_Field_FRACTION; var tmp15 any = tmp14.Ref(); delegate.Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(1, tmp13, tmp15, fFieldStart, result.Length__I(), result)






		var fieldStart int32 = result.Length__I()
		result.Append_String__Format_StringBuf(NN(t.F_symbols).GetExponentSeparator__String())
		var tmp16 *NumberFormat_Field; NumberFormat_Field_Init(); tmp16 = NumberFormat_Field_EXPONENT_SYMBOL; var tmp17 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp16); var tmp18 *NumberFormat_Field; NumberFormat_Field_Init(); tmp18 = NumberFormat_Field_EXPONENT_SYMBOL; var tmp19 any = tmp18.Ref(); delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(tmp17, tmp19, fieldStart, result.Length__I(), result)





		if NN(t.F_digitList).IsZero__Z() { exponent = 0 }
		var negativeExponent bool = exponent < 0
		if negativeExponent {
			exponent = -exponent
			fieldStart = result.Length__I()
			result.Append_String__Format_StringBuf(NN(t.F_symbols).GetMinusSignText__String())
			var tmp20 *NumberFormat_Field; NumberFormat_Field_Init(); tmp20 = NumberFormat_Field_EXPONENT_SIGN; var tmp21 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp20); var tmp22 *NumberFormat_Field; NumberFormat_Field_Init(); tmp22 = NumberFormat_Field_EXPONENT_SIGN; var tmp23 any = tmp22.Ref(); delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(tmp21, tmp23, fieldStart, result.Length__I(), result)
		}




		NN(t.F_digitList).Set_Z_J__V(negativeExponent, int64(exponent))
		var eFieldStart int32 = result.Length__I(); var i_2 int32 = t.F_digitList.F_decimalAt
	L2: for {
		if i_2 < int32(t.F_minExponentDigits) {
			result.Append_C__Format_StringBuf(zero)
			i_2 = i_2 + 1; continue L2 }
//line :771:1
		break L2
	}


		var i_3 int32 = 0; L3: for {
			if i_3 < t.F_digitList.F_decimalAt {
				var tmp24 uint16
				if i_3 < t.F_digitList.F_count {
					tmp24 = uint16(int32(t.F_digitList.F_digits.A[i_3]) + zeroDelta) } else {
//line :778:1
						tmp24 = zero }
//line :777:1
				result.Append_C__Format_StringBuf(tmp24)






				i_3 = i_3 + 1; continue L3 }
//line :775:1
			break L3
		}








		var tmp25 *NumberFormat_Field; NumberFormat_Field_Init(); tmp25 = NumberFormat_Field_EXPONENT; var tmp26 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp25); var tmp27 *NumberFormat_Field; NumberFormat_Field_Init(); tmp27 = NumberFormat_Field_EXPONENT; var tmp28 any = tmp27.Ref(); delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(tmp26, tmp28, eFieldStart, result.Length__I(), result) } else {





			var iFieldStart_2 int32 = result.Length__I(); var count int32 = minIntDigits; var digitIndex int32 = 0; var tmp29 bool; var tmp30 bool


			tmp30 = t.F_digitList.F_decimalAt > 0; if tmp30 { tmp30 = count < t.F_digitList.F_decimalAt }; tmp29 = tmp30; if tmp29 {
				count = t.F_digitList.F_decimalAt }
			if count > maxIntDigits {
				count = maxIntDigits
				digitIndex = t.F_digitList.F_decimalAt - count }
			var sizeBeforeIntegerPart int32 = result.Length__I(); var i_4 int32 = count - 1
		L4: for {
			if i_4 >= 0 {
				var tmp31 bool; var tmp32 bool; tmp32 = i_4 < t.F_digitList.F_decimalAt; if tmp32 { tmp32 = digitIndex < t.F_digitList.F_count }; tmp31 = tmp32; if tmp31 {

					result.Append_C__Format_StringBuf(uint16(int32(t.F_digitList.F_digits.A[digitIndex]) + zeroDelta))




					digitIndex = digitIndex + 1 } else {
						result.Append_C__Format_StringBuf(zero) }
				var tmp33 bool; var tmp34 bool; var tmp35 bool; var tmp36 bool; tmp36 = t.IsGroupingUsed__Z(); if tmp36 { tmp36 = i_4 > 0 }; tmp35 = tmp36; if tmp35 { tmp35 = !(int32(t.F_groupingSize) == 0) }; tmp34 = tmp35; if tmp34 {
					tmp34 = i_4%int32(t.F_groupingSize) == 0 }
//line :811:1
				tmp33 = tmp34; if tmp33 {

					var gStart int32 = result.Length__I()
					result.Append_C__Format_StringBuf(grouping)
					var tmp37 *NumberFormat_Field; NumberFormat_Field_Init(); tmp37 = NumberFormat_Field_GROUPING_SEPARATOR; var tmp38 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp37); var tmp39 *NumberFormat_Field; NumberFormat_Field_Init(); tmp39 = NumberFormat_Field_GROUPING_SEPARATOR; var tmp40 any = tmp39.Ref(); delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(tmp38, tmp40, gStart, result.Length__I(), result)





					i_4 = i_4 - 1; continue L4 } else {
						i_4 = i_4 - 1; continue L4 } }
//line :800:1
			break L4
		}





















			var fractionPresent bool; var tmp41 bool; tmp41 = minFraDigits > 0; if !tmp41 {
				var tmp42 bool; tmp42 = !isInteger; if tmp42 { tmp42 = digitIndex < t.F_digitList.F_count }; tmp41 = tmp42 }
//line :823:1
			fractionPresent = tmp41

			var tmp43 bool; var tmp44 bool; tmp44 = !fractionPresent; if tmp44 { tmp44 = result.Length__I() == sizeBeforeIntegerPart }; tmp43 = tmp44; if tmp43 {
				result.Append_C__Format_StringBuf(zero) }
			var tmp45 *NumberFormat_Field; NumberFormat_Field_Init(); tmp45 = NumberFormat_Field_INTEGER; var tmp46 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp45); var tmp47 *NumberFormat_Field; NumberFormat_Field_Init(); tmp47 = NumberFormat_Field_INTEGER; var tmp48 any = tmp47.Ref(); delegate.Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(0, tmp46, tmp48, iFieldStart_2, result.Length__I(), result)






			var sStart int32 = result.Length__I(); var tmp49 bool; var tmp50 bool
			tmp50 = t.F_decimalSeparatorAlwaysShown; if !tmp50 { tmp50 = fractionPresent }; tmp49 = tmp50; if tmp49 { result.Append_C__Format_StringBuf(decimal) }
			if sStart == result.Length__I() { } else {
				var tmp51 *NumberFormat_Field; NumberFormat_Field_Init(); tmp51 = NumberFormat_Field_DECIMAL_SEPARATOR; var tmp52 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp51); var tmp53 *NumberFormat_Field; NumberFormat_Field_Init(); tmp53 = NumberFormat_Field_DECIMAL_SEPARATOR; var tmp54 any = tmp53.Ref(); delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(tmp52, tmp54, sStart, result.Length__I(), result)
			}




			var fFieldStart_2 int32 = result.Length__I(); var i_5 int32 = 0
		L5: for {
			if i_5 < maxFraDigits {
				var tmp55 bool; var tmp56 bool; tmp56 = i_5 >= minFraDigits; if tmp56 {
					var tmp57 bool; tmp57 = isInteger; if !tmp57 { tmp57 = digitIndex >= t.F_digitList.F_count }; tmp56 = tmp57 }
//line :846:1
				tmp55 = tmp56; if tmp55 { } else {

					if -1-i_5 > t.F_digitList.F_decimalAt-1 {


						result.Append_C__Format_StringBuf(zero); i_5 = i_5 + 1; continue L5 } else {
//line :848:1
							var tmp58 bool; var tmp59 bool



							tmp59 = !isInteger; if tmp59 { tmp59 = digitIndex < t.F_digitList.F_count }; tmp58 = tmp59
//line :848:1
							if tmp58 {





								result.Append_C__Format_StringBuf(uint16(int32(t.F_digitList.F_digits.A[digitIndex]) + zeroDelta))




								digitIndex = digitIndex + 1
								i_5 = i_5 + 1; continue L5 } else {
									result.Append_C__Format_StringBuf(zero); i_5 = i_5 + 1; continue L5 } } } }
//line :844:1
			break L5
		}
















			var tmp60 *NumberFormat_Field; NumberFormat_Field_Init(); tmp60 = NumberFormat_Field_FRACTION; var tmp61 Format_Field_I = Up_NumberFormat_Field_Format_Field(tmp60); var tmp62 *NumberFormat_Field; NumberFormat_Field_Init(); tmp62 = NumberFormat_Field_FRACTION; var tmp63 any = tmp62.Ref(); delegate.Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(1, tmp61, tmp63, fFieldStart_2, result.Length__I(), result)
		}
}





func (t *DecimalFormat) Append_Format_StringBuf_String_Format_FieldDelegate_FieldPosition1_Format_Field__V(result Format_StringBuf, string_ *String, delegate Format_FieldDelegate, positions *RefArray, signAttribute Format_Field_I) {


	var start int32 = result.Length__I()
	if NN(string_).IsEmpty__Z() { } else {
		result.Append_String__Format_StringBuf(string_)
		var counter int32 = 0; var max_ int32 = int32(len(positions.A)); L1: for {

			if counter < max_ {
				var fp FieldPosition_I = As[FieldPosition_I](positions.A[counter]); var attribute Format_Field_I = fp.GetFieldAttribute__Format_Field(); var tmp1 Format_Field_I = attribute; var tmp2 *NumberFormat_Field

				NumberFormat_Field_Init(); tmp2 = NumberFormat_Field_SIGN; if any(tmp1) == any(tmp2.Ref()) { attribute = signAttribute }
				delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(attribute, attribute, start+fp.GetBeginIndex__I(), start+fp.GetEndIndex__I(), result)





				counter, max_ = counter+1, max_; continue L1 }
//line :876:1
			break L1
		}
	}
}










func (t *DecimalFormat) Parse_String_ParsePosition__Number(text *String, pos *ParsePosition) Number_I {
	var tmp1 int32 = pos.F_index; if NN(text).RegionMatches_I_String_I_I__Z(tmp1, NN(t.F_symbols).GetNaN__String(), 0, NN(NN(t.F_symbols).GetNaN__String()).Length__I()) {

		var tmp2 int32 = pos.F_index; pos.F_index = tmp2 + NN(NN(t.F_symbols).GetNaN__String()).Length__I()
		return Up_Double_Number(Double_ValueOf_D__Double(NaN64)) } else {
			var status *BooleanArray = NewBooleanArray(2)
			if !t.Subparse_String_ParsePosition_String_String_DigitList_Z_Z1__Z(text, pos, t.F_positivePrefix, t.F_negativePrefix, t.F_digitList, false, status) { return nil } else {







				if status.A[0] {

					if status.A[1] == (t.F_multiplier >= 0) {
						return Up_Double_Number(Double_ValueOf_D__Double(PosInf64)) } else {
							return Up_Double_Number(Double_ValueOf_D__Double(NegInf64)) } } else {
//line :904:1
								if t.F_multiplier == 0 {





									if NN(t.F_digitList).IsZero__Z() {
										return Up_Double_Number(Double_ValueOf_D__Double(NaN64)) } else {
//line :910:1
											if status.A[1] {

												return Up_Double_Number(Double_ValueOf_D__Double(PosInf64)) } else {
													return Up_Double_Number(Double_ValueOf_D__Double(NegInf64)) } } } else {
//line :904:1
														if t.IsParseBigDecimal__Z() {










															var bigDecimalResult *BigDecimal = NN(t.F_digitList).GetBigDecimal__BigDecimal()
															if t.F_multiplier == 1 { } else { tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

																bigDecimalResult = NN(bigDecimalResult).Divide_BigDecimal__BigDecimal(t.GetBigDecimalMultiplier__BigDecimal())
//line :916:1
																return nil }()
																if tmp3 != nil { if ArithmeticException_InstanceOf(tmp3) { var e *ArithmeticException = ArithmeticException_Cast(tmp3); _ = e



																	bigDecimalResult = NN(bigDecimalResult).Divide_BigDecimal_RoundingMode__BigDecimal(t.GetBigDecimalMultiplier__BigDecimal(), t.F_roundingMode) } else {
//line :917:1
																		panic(tmp3)
																	}
																}
															}




															if status.A[1] { } else {
																bigDecimalResult = NN(bigDecimalResult).Negate__BigDecimal() }
//line :915:1
															return Up_BigDecimal_Number(bigDecimalResult) } else {













																var gotDouble bool = true; var gotLongMinimum bool = false; var doubleResult float64 = 0.0; var longResult int64 = 0; var tmp4 *DigitList = t.F_digitList; var tmp5 bool = status.A[1]



																if NN(tmp4).FitsIntoLong_Z_Z__Z(tmp5, t.IsParseIntegerOnly__Z()) {



																	gotDouble = false
																	longResult = NN(t.F_digitList).GetLong__J()
																	if longResult < 0 { gotLongMinimum = true } } else {
																		doubleResult = NN(t.F_digitList).GetDouble__D() }
																if t.F_multiplier == 1 { } else {
																	if gotDouble {
																		doubleResult = doubleResult / float64(t.F_multiplier) } else {
//line :942:1
																			if longResult%int64(t.F_multiplier) == 0 {


																				longResult = longResult / int64(t.F_multiplier) } else {


																					doubleResult = float64(longResult) / float64(t.F_multiplier)
																					gotDouble = true } } }
																var tmp6 bool; var tmp7 bool; tmp7 = !status.A[1]; if tmp7 { tmp7 = !gotLongMinimum }; tmp6 = tmp7; if tmp6 {
																	doubleResult = -doubleResult
																	longResult = -longResult }
																var tmp8 bool; var tmp9 bool; tmp9 = !(t.F_multiplier == 1); if tmp9 { tmp9 = gotDouble }; tmp8 = tmp9; if tmp8 {
																	longResult = D2L(doubleResult)
																	var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool
																	tmp14 = doubleResult >= 9.223372036854776e18; if !tmp14 {
																		tmp14 = doubleResult <= -9.223372036854776e18 }
//line :956:1
																	tmp13 = tmp14; if !tmp13 {

																		tmp13 = !(doubleResult == float64(longResult)) }
//line :956:1
																	tmp12 = tmp13; if !tmp12 {


																		var tmp15 bool; tmp15 = doubleResult == 0.0; if tmp15 {
																			tmp15 = 1.0/doubleResult < 0.0 }
//line :959:1
																		tmp12 = tmp15 }
//line :956:1
																	tmp11 = tmp12; if tmp11 {




																		tmp11 = !t.IsParseIntegerOnly__Z() }
//line :956:1
																	tmp10 = tmp11
//line :955:1
																	gotDouble = tmp10
																}





																if gotDouble {
																	return Up_Double_Number(Double_ValueOf_D__Double(doubleResult)) } else {
																		return Up_Long_Number(Long_ValueOf_J__Long(longResult))
																	} } } } } } }
func (t *DecimalFormat) GetBigIntegerMultiplier__BigInteger() *BigInteger {
	if t.F_bigIntegerMultiplier == nil { t.F_bigIntegerMultiplier = BigInteger_ValueOf_J__BigInteger(int64(t.F_multiplier)) }
//line :966:1
	return t.F_bigIntegerMultiplier
}




func (t *DecimalFormat) GetBigDecimalMultiplier__BigDecimal() *BigDecimal {
	if t.F_bigDecimalMultiplier == nil { t.F_bigDecimalMultiplier = BigDecimal_New_I(t.F_multiplier) }
//line :972:1
	return t.F_bigDecimalMultiplier
}










func (t *DecimalFormat) Subparse_String_ParsePosition_String_String_DigitList_Z_Z1__Z(text *String, parsePosition *ParsePosition, positivePrefix, negativePrefix *String, digits *DigitList, isExponent bool, status *BooleanArray) bool {



	var position int32 = parsePosition.F_index; var oldStart int32 = parsePosition.F_index
	var gotPositive bool = false
	var gotNegative bool = false

	gotPositive = t.MatchAffix_String_I_String__Z(text, position, positivePrefix)
	gotNegative = t.MatchAffix_String_I_String__Z(text, position, negativePrefix)
	var tmp1 bool; var tmp2 bool; tmp2 = gotPositive; if tmp2 { tmp2 = gotNegative }; tmp1 = tmp2; if tmp1 {
		if NN(positivePrefix).Length__I() > NN(negativePrefix).Length__I() {
			gotNegative = false } else {
//line :995:1
				if NN(positivePrefix).Length__I() < NN(negativePrefix).Length__I() {

					gotPositive = false } } }
	if gotPositive {
		position = position + NN(positivePrefix).Length__I() } else {
//line :998:1
			if gotNegative {

				position = position + NN(negativePrefix).Length__I() } else {
					parsePosition.F_errorIndex = position; return false } }
	var pos *DecimalFormat_NumericPosition = t.SubparseNumber_String_I_DigitList_Z_Z_Z1__DecimalFormat_NumericPosition(text, position, digits, true, isExponent, status)
	position = pos.F_fullPos
	if position == -1 {

		parsePosition.F_index = oldStart
		parsePosition.F_errorIndex = oldStart
//line :1005:1
		return false
	} else {



		if !isExponent {

			if gotPositive {
				var containsPosSuffix bool = t.MatchAffix_String_I_String__Z(text, position, t.F_positiveSuffix); var endsWithPosSuffix bool; var tmp3 bool
				tmp3 = containsPosSuffix; if tmp3 {

					tmp3 = NN(text).Length__I() == position+NN(t.F_positiveSuffix).Length__I() }
//line :1014:1
				endsWithPosSuffix = tmp3






				var tmp4 bool; if t.F_parseStrict { tmp4 = endsWithPosSuffix } else { tmp4 = containsPosSuffix }; gotPositive = tmp4 }
			if gotNegative {
				var containsNegSuffix bool = t.MatchAffix_String_I_String__Z(text, position, t.F_negativeSuffix); var endsWithNegSuffix bool; var tmp5 bool
				tmp5 = containsNegSuffix; if tmp5 {

					tmp5 = NN(text).Length__I() == position+NN(t.F_negativeSuffix).Length__I() }
//line :1024:1
				endsWithNegSuffix = tmp5






				var tmp6 bool; if t.F_parseStrict { tmp6 = endsWithNegSuffix } else { tmp6 = containsNegSuffix }; gotNegative = tmp6 }
			var tmp7 bool; var tmp8 bool; tmp8 = gotPositive; if tmp8 { tmp8 = gotNegative }; tmp7 = tmp8; if tmp7 {
				if NN(t.F_positiveSuffix).Length__I() > NN(t.F_negativeSuffix).Length__I() {

					gotNegative = false } else {
//line :1033:1
						if NN(t.F_positiveSuffix).Length__I() < NN(t.F_negativeSuffix).Length__I() {



							gotPositive = false } } }
			if gotPositive == gotNegative {
				parsePosition.F_errorIndex = position
				return false }
			var tmp9 bool; var tmp10 bool; tmp10 = t.IsParseIntegerOnly__Z(); if tmp10 { tmp10 = !(pos.F_intPos == -1) }; tmp9 = tmp10; if tmp9 {
				parsePosition.F_index = pos.F_intPos } else {
					var tmp11 int32 = position; var tmp12 int32


					if gotPositive { tmp12 = NN(t.F_positiveSuffix).Length__I() } else { tmp12 = NN(t.F_negativeSuffix).Length__I() }
//line :1043:1
					parsePosition.F_index = tmp11 + tmp12
				}
		} else {

			parsePosition.F_index = position }
		status.A[1] = gotPositive
		if parsePosition.F_index == oldStart {
			parsePosition.F_errorIndex = position; return false } else {
//line :1049:1
				return true
			}
	}
}


func (t *DecimalFormat) SubparseNumber_String_I_DigitList_Z_Z_Z1__DecimalFormat_NumericPosition(text *String, position int32, digits *DigitList, checkExponent, isExponent bool, status *BooleanArray) *DecimalFormat_NumericPosition {


	status.A[0] = false
	var intIndex int32 = -1; var tmp1 bool; var tmp2 bool
	tmp2 = !isExponent; if tmp2 {
		tmp2 = NN(text).RegionMatches_I_String_I_I__Z(position, NN(t.F_symbols).GetInfinity__String(), 0, NN(NN(t.F_symbols).GetInfinity__String()).Length__I()) }
//line :1060:1
	tmp1 = tmp2; if tmp1 {






		position = position + NN(NN(t.F_symbols).GetInfinity__String()).Length__I()
		status.A[0] = true } else {

			var tmp3 int32; var tmp4 int32 = 0; digits.F_count = tmp4; tmp3 = tmp4; digits.F_decimalAt = tmp3
			var zero uint16 = NN(t.F_symbols).GetZeroDigit__C(); var decimal uint16
			if t.F_isCurrencyFormat {
				decimal = NN(t.F_symbols).GetMonetaryDecimalSeparator__C() } else {
					decimal = NN(t.F_symbols).GetDecimalSeparator__C() }
//line :1071:1
			var grouping uint16



			if t.F_isCurrencyFormat {
				grouping = NN(t.F_symbols).GetMonetaryGroupingSeparator__C() } else {
					grouping = NN(t.F_symbols).GetGroupingSeparator__C() }
//line :1071:1
			var exponentString *String = NN(t.F_symbols).GetExponentSeparator__String(); var sawDecimal bool = false; var sawDigit bool = false; var exponent int64 = 0; var expStat *BooleanArray = NewBooleanArray(2); var digitCount int32 = 0; var prevSeparatorIndex int32 = -int32(t.F_groupingSize)
			var startPos int32 = position
			var backup int32 = -1













		L1: for { if position < NN(text).Length__I() {
			var ch uint16 = NN(text).CharAt_I__C(position); var digit int32 = int32(ch) - int32(zero); var tmp5 bool; var tmp6 bool

			tmp6 = digit < 0; if !tmp6 { tmp6 = digit > 9 }; tmp5 = tmp6; if tmp5 { digit = Character_Digit_C_I__I(ch, 10) }
			var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool
			tmp13 = t.F_parseStrict; if tmp13 { tmp13 = t.IsGroupingUsed__Z() }; tmp12 = tmp13
//line :1091:1
			if tmp12 {

				tmp12 = position == startPos+int32(t.F_groupingSize) }
//line :1091:1
			tmp11 = tmp12; if tmp11 {




				tmp11 = prevSeparatorIndex == -int32(t.F_groupingSize) }
//line :1091:1
			tmp10 = tmp11; if tmp10 {






				tmp10 = !sawDecimal }
//line :1091:1
			tmp9 = tmp10; if tmp9 {







				tmp9 = digit >= 0 }
//line :1091:1
			tmp8 = tmp9; if tmp8 {








				tmp8 = digit <= 9 }
//line :1091:1
			tmp7 = tmp8; if tmp7 {









				return DecimalFormat_NumericPosition_New_I_I(position, intIndex) }
			if digit == 0 {


				backup = -1
				sawDigit = true
				if digits.F_count == 0 {
					if !sawDecimal { } else {
						digits.F_decimalAt = digits.F_decimalAt - 1 } } else {

							digitCount = digitCount + 1
							var tmp14 bool; var tmp15 bool; tmp15 = !sawDecimal; if !tmp15 { tmp15 = !t.IsParseIntegerOnly__Z() }; tmp14 = tmp15; if tmp14 {
								NN(digits).Append_C__V(uint16(digit + 48)) } } } else {
//line :1102:1
									var tmp16 bool; var tmp17 bool











									tmp17 = digit > 0; if tmp17 { tmp17 = digit <= 9 }; tmp16 = tmp17
//line :1102:1
									if tmp16 {













										sawDigit = true
										digitCount = digitCount + 1
										var tmp18 bool; var tmp19 bool; tmp19 = !sawDecimal; if !tmp19 { tmp19 = !t.IsParseIntegerOnly__Z() }; tmp18 = tmp19; if tmp18 {
											NN(digits).Append_C__V(uint16(digit + 48)) }
										backup = -1 } else {
//line :1102:1
											var tmp20 bool; var tmp21 bool


















											tmp21 = !isExponent; if tmp21 { tmp21 = int32(ch) == int32(decimal) }; tmp20 = tmp21
//line :1102:1
											if tmp20 {




















												var tmp22 bool; var tmp23 bool; tmp23 = t.IsParseIntegerOnly__Z(); if tmp23 { tmp23 = startPos == position }; tmp22 = tmp23; if tmp22 {
													return DecimalFormat_NumericPosition_New_I_I(-1, intIndex) }
												var tmp24 bool; var tmp25 bool; tmp25 = t.F_parseStrict; if tmp25 {
													tmp25 = t.IsGroupingViolation_I_I__Z(position, prevSeparatorIndex) }
//line :1125:1
												tmp24 = tmp25; if tmp24 {

													return DecimalFormat_NumericPosition_New_I_I(t.GroupingViolationIndex_I_I__I(position, prevSeparatorIndex), intIndex)
												}

												if sawDecimal { break L1 }
												intIndex = position
												digits.F_decimalAt = digitCount
												sawDecimal = true } else {
//line :1102:1
													var tmp26 bool; var tmp27 bool; var tmp28 bool































													tmp28 = !isExponent; if tmp28 { tmp28 = int32(ch) == int32(grouping) }; tmp27 = tmp28; if tmp27 { tmp27 = t.IsGroupingUsed__Z() }; tmp26 = tmp27
//line :1102:1
													if tmp26 {

































														if t.F_parseStrict {


															if position == startPos {
																return DecimalFormat_NumericPosition_New_I_I(startPos, intIndex) }
															var tmp29 bool; var tmp30 bool; tmp30 = sawDecimal; if !tmp30 {
																tmp30 = t.IsGroupingViolation_I_I__Z(position, prevSeparatorIndex) }
//line :1141:1
															tmp29 = tmp30; if tmp29 {

																return DecimalFormat_NumericPosition_New_I_I(t.GroupingViolationIndex_I_I__I(position, prevSeparatorIndex), intIndex)
															}

															prevSeparatorIndex = position } else {
//line :1136:1
																if sawDecimal {










																	break L1 } }
														backup = position } else {
//line :1102:1
															var tmp31 bool; var tmp32 bool; var tmp33 bool














































															tmp33 = checkExponent; if tmp33 { tmp33 = !isExponent }; tmp32 = tmp33; if tmp32 {
																tmp32 = NN(text).RegionMatches_I_String_I_I__Z(position, exponentString, 0, NN(exponentString).Length__I()) }
//line :1149:1
															tmp31 = tmp32
//line :1102:1
															if tmp31 {
















































																var pos *ParsePosition = ParsePosition_New_I(position + NN(exponentString).Length__I()); var exponentDigits *DigitList = DigitList_New()


																if t.Subparse_String_ParsePosition_String_String_DigitList_Z_Z1__Z(text, pos, Lit_69, NN(t.F_symbols).GetMinusSignText__String(), exponentDigits, true, expStat) {







																	if NN(exponentDigits).FitsIntoLong_Z_Z__Z(expStat.A[1], true) {

																		exponent = NN(exponentDigits).GetLong__J()
																		if expStat.A[1] { } else {
																			exponent = -exponent } } else {
																				var tmp34 int64
																				if expStat.A[1] { tmp34 = 9223372036854775807 } else { tmp34 = -9223372036854775808 }
//line :1167:1
																				exponent = tmp34
																			}


																	position = pos.F_index }
																break L1 } else {
																	break L1 } } } } }
			position = position + 1
//line :1087:1
			continue L1 }; break L1
		}






















































































			if t.F_parseStrict {
				var tmp35 bool; var tmp36 bool; tmp36 = !sawDecimal; if tmp36 { tmp36 = t.IsGroupingViolation_I_I__Z(position, prevSeparatorIndex) }; tmp35 = tmp36; if tmp35 {
					return DecimalFormat_NumericPosition_New_I_I(t.GroupingViolationIndex_I_I__I(position-1, prevSeparatorIndex), intIndex)
				}
			}



			if backup == -1 { } else { position = backup }
			if sawDecimal { } else { digits.F_decimalAt = digitCount }
			var tmp37 bool; var tmp38 bool; tmp38 = !sawDecimal; if !tmp38 { tmp38 = !t.IsParseIntegerOnly__Z() }; tmp37 = tmp38; if tmp37 {
				digits.F_decimalAt = t.ShiftDecimalAt_I_J__I(digits.F_decimalAt, exponent) }
			var tmp39 bool; var tmp40 bool; tmp40 = !sawDigit; if tmp40 { tmp40 = digitCount == 0 }; tmp39 = tmp40; if tmp39 { return DecimalFormat_NumericPosition_New_I_I(-1, intIndex) } }
	return DecimalFormat_NumericPosition_New_I_I(position, intIndex)
}
func (t *DecimalFormat) ShiftDecimalAt_I_J__I(decimalAt int32, exponent int64) int32 { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	exponent = Math_AddExact_J_J__J(int64(decimalAt), exponent); return nil }(); if /*line :1191:1*/ tmp1 != nil { if ArithmeticException_InstanceOf(tmp1) { var ex *ArithmeticException = ArithmeticException_Cast(tmp1); var tmp2 bool; var tmp3 bool; _ = ex


		tmp3 = exponent > 0; if tmp3 { tmp3 = decimalAt > 0 }; tmp2 = tmp3; if tmp2 {
			return 2147483647 } else {
				return -2147483648 } } else {
//line :1191:1
					panic(tmp1) } }; tmp4 :=
	func() (exc Throwable_I) { defer Catch(&exc)





		decimalAt = Math_ToIntExact_J__I(exponent); return nil }(); if /*line :1197:1*/ tmp4 != nil { if ArithmeticException_InstanceOf(tmp4) { var ex_2 *ArithmeticException = ArithmeticException_Cast(tmp4); var tmp5 int32; _ = ex_2


			if exponent > 0 { tmp5 = 2147483647 } else { tmp5 = -2147483648 }; decimalAt = tmp5 } else {
//line :1197:1
				panic(tmp4) } }; return decimalAt }





func (t *DecimalFormat) IsGroupingViolation_I_I__Z(pos, prevGroupingPos int32) bool {
	if !A2g_AssertionsDisabled && !t.F_parseStrict { panic(Thrown(AssertionError_New_O(Lit_1819))) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.IsGroupingUsed__Z(); if tmp2 { tmp2 = !(prevGroupingPos == -int32(t.F_groupingSize)) }; tmp1 = tmp2; if tmp1 {
		tmp1 = !(pos-1 == prevGroupingPos+int32(t.F_groupingSize)) }
//line :1205:1
	return tmp1
}

func (t *DecimalFormat) GroupingViolationIndex_I_I__I(pos, prevGroupingPos int32) int32 {
	return Math_Min_I_I__I(pos, prevGroupingPos+int32(t.F_groupingSize)+1)
}
func (t *DecimalFormat) GetDecimalFormatSymbols__DecimalFormatSymbols() *DecimalFormatSymbols {
	var tmp1 *DecimalFormatSymbols; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = DecimalFormatSymbols_Cast(NN(t.F_symbols).Clone__O()); return nil }(); if tmp2 != nil { if Exception_InstanceOf(tmp2) { var foo Exception_I = Exception_Cast(tmp2); _ = foo; tmp1 = nil } else { panic(tmp2) } }; return tmp1
}
func (t *DecimalFormat) SetDecimalFormatSymbols_DecimalFormatSymbols__V(newSymbols *DecimalFormatSymbols) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	t.F_symbols = DecimalFormatSymbols_Cast(NN(newSymbols).Clone__O())
	t.ExpandAffixes__V()
	t.F_fastPathCheckNeeded = true; return nil }(); if /*line :1215:1*/ tmp1 != nil { if Exception_InstanceOf(tmp1) { var foo Exception_I = Exception_Cast(tmp1); _ = foo } else { panic(tmp1) } } }





func (t *DecimalFormat) GetPositivePrefix__String() *String { return t.F_positivePrefix }

func (t *DecimalFormat) SetPositivePrefix_String__V(newValue *String) {
	Objects_RequireNonNull_O_String__O(newValue.Ref(), Lit_1820)
	t.F_positivePrefix = newValue
	t.F_posPrefixPattern = nil
	t.F_positivePrefixFieldPositions = nil
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) GetPositivePrefixFieldPositions__FieldPosition1() *RefArray {
	if t.F_positivePrefixFieldPositions == nil {
		if !(t.F_posPrefixPattern == nil) {
			t.F_positivePrefixFieldPositions = t.ExpandAffix_String__FieldPosition1(t.F_posPrefixPattern) } else {
				t.F_positivePrefixFieldPositions = DecimalFormat_EmptyFieldPositionArray } }
//line :1230:1
	return t.F_positivePrefixFieldPositions
}





func (t *DecimalFormat) GetNegativePrefix__String() *String { return t.F_negativePrefix }

func (t *DecimalFormat) SetNegativePrefix_String__V(newValue *String) {
	Objects_RequireNonNull_O_String__O(newValue.Ref(), Lit_1820)
	t.F_negativePrefix = newValue
	t.F_negPrefixPattern = nil
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) GetNegativePrefixFieldPositions__FieldPosition1() *RefArray {
	if t.F_negativePrefixFieldPositions == nil {
		if !(t.F_negPrefixPattern == nil) {
			t.F_negativePrefixFieldPositions = t.ExpandAffix_String__FieldPosition1(t.F_negPrefixPattern) } else {
				t.F_negativePrefixFieldPositions = DecimalFormat_EmptyFieldPositionArray } }
//line :1245:1
	return t.F_negativePrefixFieldPositions
}





func (t *DecimalFormat) GetPositiveSuffix__String() *String { return t.F_positiveSuffix }

func (t *DecimalFormat) SetPositiveSuffix_String__V(newValue *String) {
	Objects_RequireNonNull_O_String__O(newValue.Ref(), Lit_1821)
	t.F_positiveSuffix = newValue
	t.F_posSuffixPattern = nil
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) GetPositiveSuffixFieldPositions__FieldPosition1() *RefArray {
	if t.F_positiveSuffixFieldPositions == nil {
		if !(t.F_posSuffixPattern == nil) {
			t.F_positiveSuffixFieldPositions = t.ExpandAffix_String__FieldPosition1(t.F_posSuffixPattern) } else {
				t.F_positiveSuffixFieldPositions = DecimalFormat_EmptyFieldPositionArray } }
//line :1260:1
	return t.F_positiveSuffixFieldPositions
}





func (t *DecimalFormat) GetNegativeSuffix__String() *String { return t.F_negativeSuffix }

func (t *DecimalFormat) SetNegativeSuffix_String__V(newValue *String) {
	Objects_RequireNonNull_O_String__O(newValue.Ref(), Lit_1821)
	t.F_negativeSuffix = newValue
	t.F_negSuffixPattern = nil
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) GetNegativeSuffixFieldPositions__FieldPosition1() *RefArray {
	if t.F_negativeSuffixFieldPositions == nil {
		if !(t.F_negSuffixPattern == nil) {
			t.F_negativeSuffixFieldPositions = t.ExpandAffix_String__FieldPosition1(t.F_negSuffixPattern) } else {
				t.F_negativeSuffixFieldPositions = DecimalFormat_EmptyFieldPositionArray } }
//line :1275:1
	return t.F_negativeSuffixFieldPositions
}





func (t *DecimalFormat) GetMultiplier__I() int32 { return t.F_multiplier }

func (t *DecimalFormat) SetMultiplier_I__V(newValue int32) {
	t.F_multiplier = newValue
	t.F_bigDecimalMultiplier = nil
	t.F_bigIntegerMultiplier = nil
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) SetGroupingUsed_Z__V(newValue bool) {
	t.NumberFormat.Impl_SetGroupingUsed_Z__V(t, newValue)
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) GetGroupingSize__I() int32 { return int32(t.F_groupingSize) }

func (t *DecimalFormat) SetGroupingSize_I__V(newValue int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = newValue < 0; if !tmp2 { tmp2 = newValue > 127 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1822, StrOfInt(newValue)))))
	}
	t.F_groupingSize = int8(newValue)
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) IsDecimalSeparatorAlwaysShown__Z() bool { return t.F_decimalSeparatorAlwaysShown }


func (t *DecimalFormat) SetDecimalSeparatorAlwaysShown_Z__V(newValue bool) {
	t.F_decimalSeparatorAlwaysShown = newValue
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) IsStrict__Z() bool { return t.F_parseStrict }

func (t *DecimalFormat) SetStrict_Z__V(strict bool) {
	t.F_parseStrict = strict
}
func (t *DecimalFormat) IsParseBigDecimal__Z() bool { return t.F_parseBigDecimal }

func (t *DecimalFormat) SetParseBigDecimal_Z__V(newValue bool) {
	t.F_parseBigDecimal = newValue
}
func (t *DecimalFormat) Clone__O() any {
	var other *DecimalFormat = DecimalFormat_Cast(t.NumberFormat.Impl_Clone__O(t))
	other.F_symbols = DecimalFormatSymbols_Cast(NN(t.F_symbols).Clone__O())
	other.F_digitList = DigitList_Cast(NN(t.F_digitList).Clone__O())
	other.F_fastPathCheckNeeded = true
	other.F_isFastPath = false
	other.F_fastPathData = nil
//line :1321:1
	return other.Ref()
}






func (t *DecimalFormat) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if !t.NumberFormat.Impl_Equals_O__Z(t, obj) { return false } else {



		var other *DecimalFormat = DecimalFormat_Cast(obj); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 *String = t.F_posPrefixPattern












		tmp18 = tmp19 == other.F_posPrefixPattern
//line :1346:1
		if tmp18 {



			var tmp20 *String = t.F_positivePrefix; tmp18 = NN(tmp20).Equals_O__Z(other.F_positivePrefix.Ref()) }
//line :1346:1
		tmp17 = tmp18
//line :1345:1
		if !tmp17 {







			var tmp21 bool
			tmp21 = !(t.F_posPrefixPattern == nil)
//line :1353:1
			if tmp21 {

				var tmp22 *String = t.F_posPrefixPattern; tmp21 = NN(tmp22).Equals_O__Z(other.F_posPrefixPattern.Ref()) }
//line :1353:1
			tmp17 = tmp21 }
//line :1345:1
		tmp16 = tmp17
//line :1344:1
		if tmp16 {













			var tmp23 bool; var tmp24 bool; var tmp25 *String = t.F_posSuffixPattern

			tmp24 = tmp25 == other.F_posSuffixPattern
//line :1359:1
			if tmp24 {



				var tmp26 *String = t.F_positiveSuffix; tmp24 = NN(tmp26).Equals_O__Z(other.F_positiveSuffix.Ref()) }
//line :1359:1
			tmp23 = tmp24
//line :1358:1
			if !tmp23 {







				var tmp27 bool
				tmp27 = !(t.F_posSuffixPattern == nil)
//line :1366:1
				if tmp27 {

					var tmp28 *String = t.F_posSuffixPattern; tmp27 = NN(tmp28).Equals_O__Z(other.F_posSuffixPattern.Ref()) }
//line :1366:1
				tmp23 = tmp27 }
//line :1358:1
			tmp16 = tmp23 }
//line :1344:1
		tmp15 = tmp16
//line :1343:1
		if tmp15 {



























			var tmp29 bool; var tmp30 bool; var tmp31 *String = t.F_negPrefixPattern

			tmp30 = tmp31 == other.F_negPrefixPattern
//line :1372:1
			if tmp30 {



				var tmp32 *String = t.F_negativePrefix; tmp30 = NN(tmp32).Equals_O__Z(other.F_negativePrefix.Ref()) }
//line :1372:1
			tmp29 = tmp30
//line :1371:1
			if !tmp29 {







				var tmp33 bool
				tmp33 = !(t.F_negPrefixPattern == nil)
//line :1379:1
				if tmp33 {

					var tmp34 *String = t.F_negPrefixPattern; tmp33 = NN(tmp34).Equals_O__Z(other.F_negPrefixPattern.Ref()) }
//line :1379:1
				tmp29 = tmp33 }
//line :1371:1
			tmp15 = tmp29 }
//line :1343:1
		tmp14 = tmp15
//line :1342:1
		if tmp14 {









































			var tmp35 bool; var tmp36 bool; var tmp37 *String = t.F_negSuffixPattern

			tmp36 = tmp37 == other.F_negSuffixPattern
//line :1385:1
			if tmp36 {



				var tmp38 *String = t.F_negativeSuffix; tmp36 = NN(tmp38).Equals_O__Z(other.F_negativeSuffix.Ref()) }
//line :1385:1
			tmp35 = tmp36
//line :1384:1
			if !tmp35 {







				var tmp39 bool
				tmp39 = !(t.F_negSuffixPattern == nil)
//line :1392:1
				if tmp39 {

					var tmp40 *String = t.F_negSuffixPattern; tmp39 = NN(tmp40).Equals_O__Z(other.F_negSuffixPattern.Ref()) }
//line :1392:1
				tmp35 = tmp39 }
//line :1384:1
			tmp14 = tmp35 }
//line :1342:1
		tmp13 = tmp14
//line :1341:1
		if tmp13 {























































			var tmp41 int32 = t.F_multiplier; tmp13 = tmp41 == other.F_multiplier }
//line :1341:1
		tmp12 = tmp13
//line :1340:1
		if tmp12 {

























































			var tmp42 int32 = int32(t.F_groupingSize); tmp12 = tmp42 == int32(other.F_groupingSize) }
//line :1340:1
		tmp11 = tmp12
//line :1339:1
		if tmp11 {



























































			var tmp43 bool = t.F_decimalSeparatorAlwaysShown; tmp11 = tmp43 == other.F_decimalSeparatorAlwaysShown }
//line :1339:1
		tmp10 = tmp11
//line :1338:1
		if tmp10 {































































			var tmp44 bool = t.F_parseBigDecimal; tmp10 = tmp44 == other.F_parseBigDecimal }
//line :1338:1
		tmp9 = tmp10
//line :1337:1
		if tmp9 {

































































			var tmp45 bool = t.F_useExponentialNotation; tmp9 = tmp45 == other.F_useExponentialNotation }
//line :1337:1
		tmp8 = tmp9
//line :1336:1
		if tmp8 {





































































			var tmp46 bool; tmp46 = !t.F_useExponentialNotation; if !tmp46 {
				var tmp47 int32 = int32(t.F_minExponentDigits); tmp46 = tmp47 == int32(other.F_minExponentDigits) }
//line :1406:1
			tmp8 = tmp46 }
//line :1336:1
		tmp7 = tmp8
//line :1335:1
		if tmp7 {








































































			var tmp48 int32 = t.F_maximumIntegerDigits; tmp7 = tmp48 == other.F_maximumIntegerDigits }
//line :1335:1
		tmp6 = tmp7; if tmp6 {









































































			var tmp49 int32 = t.F_minimumIntegerDigits; tmp6 = tmp49 == other.F_minimumIntegerDigits }
//line :1335:1
		tmp5 = tmp6; if tmp5 {










































































			var tmp50 int32 = t.F_maximumFractionDigits; tmp5 = tmp50 == other.F_maximumFractionDigits }
//line :1335:1
		tmp4 = tmp5; if tmp4 {











































































			var tmp51 int32 = t.F_minimumFractionDigits; tmp4 = tmp51 == other.F_minimumFractionDigits }
//line :1335:1
		tmp3 = tmp4; if tmp3 {












































































			var tmp52 *RoundingMode = t.F_roundingMode; tmp3 = tmp52 == other.F_roundingMode }
//line :1335:1
		tmp2 = tmp3; if tmp2 {













































































			var tmp53 *DecimalFormatSymbols = t.F_symbols; tmp2 = NN(tmp53).Equals_O__Z(other.F_symbols.Ref()) }
//line :1335:1
		tmp1 = tmp2; if tmp1 {














































































			var tmp54 bool = t.F_parseStrict; tmp1 = tmp54 == other.F_parseStrict }
//line :1335:1
		return tmp1
	}
	}
}













































































func (t *DecimalFormat) HashCode__I() int32 {
	return t.NumberFormat.Impl_HashCode__I(t)*37 + NN(t.F_positivePrefix).HashCode__I()
}
func (t *DecimalFormat) ToString__String() *String {
	return Lit_1823.Formatted_O1__String(RefArrayOf(Object_class, NN(NN(t.F_symbols).GetLocale__Locale()).GetDisplayName__String().Ref(), t.ToPattern__String().Ref()))
}


func (t *DecimalFormat) ToPattern__String() *String { return t.ToPattern_Z__String(false) }

func (t *DecimalFormat) ToLocalizedPattern__String() *String {
	return t.ToPattern_Z__String(true)
}
func (t *DecimalFormat) ExpandAffixes__V() {
	var buffer *StringBuilder = StringBuilder_New()
	if !(t.F_posPrefixPattern == nil) {
		t.F_positivePrefix = t.ExpandAffix_String_StringBuilder__String(t.F_posPrefixPattern, buffer)
		t.F_positivePrefixFieldPositions = nil }
	if !(t.F_posSuffixPattern == nil) {
		t.F_positiveSuffix = t.ExpandAffix_String_StringBuilder__String(t.F_posSuffixPattern, buffer)
		t.F_positiveSuffixFieldPositions = nil }
	if !(t.F_negPrefixPattern == nil) {
		t.F_negativePrefix = t.ExpandAffix_String_StringBuilder__String(t.F_negPrefixPattern, buffer)
		t.F_negativePrefixFieldPositions = nil }
	if !(t.F_negSuffixPattern == nil) {
		t.F_negativeSuffix = t.ExpandAffix_String_StringBuilder__String(t.F_negSuffixPattern, buffer)
		t.F_negativeSuffixFieldPositions = nil
	} }
func (t *DecimalFormat) ExpandAffix_String_StringBuilder__String(pattern *String, buffer *StringBuilder) *String {
	NN(buffer).SetLength_I__V(0)
	var i int32 = 0
L1: for { if i < NN(pattern).Length__I() {
	var c uint16; var tmp1 int32; var old_1 int32 = i; i = i + 1; tmp1 = old_1; c = NN(pattern).CharAt_I__C(tmp1)
	if int32(c) == 39 {
		c = NN(pattern).CharAt_I__C(i)
		i = i + 1
		switch int32(c) { case 164:


			var tmp2 bool; var tmp3 bool; tmp3 = i < NN(pattern).Length__I(); if tmp3 { tmp3 = int32(NN(pattern).CharAt_I__C(i)) == 164 }; tmp2 = tmp3; if tmp2 {

				i = i + 1
				NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetInternationalCurrencySymbol__String()) } else {
					NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetCurrencySymbol__String()) }
			continue L1; case 37:
			NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetPercentText__String()); continue L1; case 8240:
			NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetPerMillText__String()); continue L1; case 45:
			NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetMinusSignText__String()); continue L1; default:} }
	NN(buffer).Append_C__StringBuilder(c)
//line :1447:1
	continue L1 }; break L1
}
















	return NN(buffer).ToString__String()
}
func (t *DecimalFormat) ExpandAffix_String__FieldPosition1(pattern *String) *RefArray {
	var positions *ArrayList
	var stringIndex int32 = 0
	var i int32 = 0
L1: for { if i < NN(pattern).Length__I() {
	var c uint16; var tmp1 int32; var old_2 int32 = i; i = i + 1; tmp1 = old_2; c = NN(pattern).CharAt_I__C(tmp1)
	if int32(c) == 39 {
		var fieldID Format_Field_I; var string_ *String

		c = NN(pattern).CharAt_I__C(i)
		i = i + 1
		switch int32(c) { case 164:


			var tmp2 bool; var tmp3 bool; tmp3 = i < NN(pattern).Length__I(); if tmp3 { tmp3 = int32(NN(pattern).CharAt_I__C(i)) == 164 }; tmp2 = tmp3; if tmp2 {

				i = i + 1
				string_ = NN(t.F_symbols).GetInternationalCurrencySymbol__String() } else {
					string_ = NN(t.F_symbols).GetCurrencySymbol__String() }
			var tmp4 *NumberFormat_Field; NumberFormat_Field_Init(); tmp4 = NumberFormat_Field_CURRENCY; fieldID = Up_NumberFormat_Field_Format_Field(tmp4); case 37:


			string_ = NN(t.F_symbols).GetPercentText__String()
			var tmp5 *NumberFormat_Field; NumberFormat_Field_Init(); tmp5 = NumberFormat_Field_PERCENT; fieldID = Up_NumberFormat_Field_Format_Field(tmp5); case 8240:


			string_ = NN(t.F_symbols).GetPerMillText__String()
			var tmp6 *NumberFormat_Field; NumberFormat_Field_Init(); tmp6 = NumberFormat_Field_PERMILLE; fieldID = Up_NumberFormat_Field_Format_Field(tmp6); case 45:


			string_ = NN(t.F_symbols).GetMinusSignText__String()
			var tmp7 *NumberFormat_Field; NumberFormat_Field_Init(); tmp7 = NumberFormat_Field_SIGN; fieldID = Up_NumberFormat_Field_Format_Field(tmp7); default:}
		var tmp8 bool; var tmp9 bool; tmp9 = !(fieldID == nil); if tmp9 { tmp9 = !NN(string_).IsEmpty__Z() }; tmp8 = tmp9; if tmp8 {
			if positions == nil { positions = ArrayList_New_I(2) }
			var fp FieldPosition_I = FieldPosition_New_Format_Field(fieldID)
			fp.SetBeginIndex_I__V(stringIndex)
			fp.SetEndIndex_I__V(stringIndex + NN(string_).Length__I())
			NN(positions).Add_O__Z(fp)
			stringIndex = stringIndex + NN(string_).Length__I()
			continue L1 } }
	stringIndex = stringIndex + 1
//line :1471:1
	continue L1 }; break L1
}



































	if !(positions == nil) {
		return A2g_CastArray[*RefArray](NN(positions).ToArray_O1__O1(DecimalFormat_EmptyFieldPositionArray).Ref(), FieldPosition_class.ArrayClass()) } else {
//line :1508:1
			return DecimalFormat_EmptyFieldPositionArray
		}
}

func (t *DecimalFormat) AppendAffix_StringBuilder_String_String_Z__V(buffer *StringBuilder, affixPattern, expAffix *String, localized bool) {

	if affixPattern == nil {
		t.AppendAffix_StringBuilder_String_Z__V(buffer, expAffix, localized) } else {
			var i int32 = 0; var pos int32 = 0
		L1: for {
			if pos < NN(affixPattern).Length__I() {
				i = NN(affixPattern).IndexOf_I_I__I(39, pos)
				if i < 0 {
					t.AppendAffix_StringBuilder_String_Z__V(buffer, NN(affixPattern).Substring_I__String(pos), localized) } else {

						if i > pos {
							t.AppendAffix_StringBuilder_String_Z__V(buffer, NN(affixPattern).Substring_I_I__String(pos, i), localized) }
						var c uint16; var tmp1 int32; i = i + 1; tmp1 = i; c = NN(affixPattern).CharAt_I__C(tmp1)
						i = i + 1
						if int32(c) == 39 {
							NN(buffer).Append_C__StringBuilder(c) } else {
//line :1527:1
								var tmp2 bool; var tmp3 bool; var tmp4 bool

								tmp4 = int32(c) == 164; if tmp4 { tmp4 = i < NN(affixPattern).Length__I() }; tmp3 = tmp4; if tmp3 {
									tmp3 = int32(NN(affixPattern).CharAt_I__C(i)) == 164 }
//line :1529:1
								tmp2 = tmp3
//line :1527:1
								if tmp2 {



									i = i + 1; NN(buffer).Append_C__StringBuilder(c) } else {
//line :1527:1
										if localized {





											switch int32(c) { case 37:

												NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetPercentText__String()); pos = i; continue L1
//line :1533:1
											case 8240:



												NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetPerMillText__String()); pos = i; continue L1
//line :1533:1
											case 45:





												NN(buffer).Append_String__StringBuilder(NN(t.F_symbols).GetMinusSignText__String()); pos = i; continue L1
//line :1533:1
											default:
											}
										}
									}
							}


						NN(buffer).Append_C__StringBuilder(c)
						pos = i; continue L1 } }
//line :1517:1
			break L1
		}
		}
}






















func (t *DecimalFormat) AppendAffix_StringBuilder_String_Z__V(buffer *StringBuilder, affix *String, localized bool) {
	var needQuote bool; if localized {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool





		tmp8 = NN(affix).IndexOf_I__I(int32(NN(t.F_symbols).GetZeroDigit__C())) >= 0
//line :1550:1
		if !tmp8 {

			tmp8 = NN(affix).IndexOf_I__I(int32(NN(t.F_symbols).GetGroupingSeparator__C())) >= 0 }
//line :1550:1
		tmp7 = tmp8
//line :1549:1
		if !tmp7 {







			tmp7 = NN(affix).IndexOf_I__I(int32(NN(t.F_symbols).GetDecimalSeparator__C())) >= 0 }
//line :1549:1
		tmp6 = tmp7
//line :1548:1
		if !tmp6 {











			tmp6 = NN(affix).IndexOf_String__I(NN(t.F_symbols).GetPercentText__String()) >= 0 }
//line :1548:1
		tmp5 = tmp6
//line :1547:1
		if !tmp5 {













			tmp5 = NN(affix).IndexOf_String__I(NN(t.F_symbols).GetPerMillText__String()) >= 0 }
//line :1547:1
		tmp4 = tmp5
//line :1546:1
		if !tmp4 {















			tmp4 = NN(affix).IndexOf_I__I(int32(NN(t.F_symbols).GetDigit__C())) >= 0 }
//line :1546:1
		tmp3 = tmp4
//line :1545:1
		if !tmp3 {

















			tmp3 = NN(affix).IndexOf_I__I(int32(NN(t.F_symbols).GetPatternSeparator__C())) >= 0 }
//line :1545:1
		tmp2 = tmp3; if !tmp2 {


















			tmp2 = NN(affix).IndexOf_String__I(NN(t.F_symbols).GetMinusSignText__String()) >= 0 }
//line :1545:1
		tmp1 = tmp2; if !tmp1 {



















			tmp1 = NN(affix).IndexOf_I__I(164) >= 0 }
//line :1545:1
		needQuote = tmp1




	} else {















		var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; var tmp16 bool




		tmp16 = NN(affix).IndexOf_I__I(48) >= 0
//line :1570:1
		if !tmp16 {

			tmp16 = NN(affix).IndexOf_I__I(44) >= 0 }
//line :1570:1
		tmp15 = tmp16
//line :1569:1
		if !tmp15 {





			tmp15 = NN(affix).IndexOf_I__I(46) >= 0 }
//line :1569:1
		tmp14 = tmp15
//line :1568:1
		if !tmp14 {









			tmp14 = NN(affix).IndexOf_I__I(37) >= 0 }
//line :1568:1
		tmp13 = tmp14
//line :1567:1
		if !tmp13 {











			tmp13 = NN(affix).IndexOf_I__I(8240) >= 0 }
//line :1567:1
		tmp12 = tmp13
//line :1566:1
		if !tmp12 {













			tmp12 = NN(affix).IndexOf_I__I(35) >= 0 }
//line :1566:1
		tmp11 = tmp12; if !tmp11 {














			tmp11 = NN(affix).IndexOf_I__I(59) >= 0 }
//line :1566:1
		tmp10 = tmp11; if !tmp10 {















			tmp10 = NN(affix).IndexOf_I__I(45) >= 0 }
//line :1566:1
		tmp9 = tmp10; if !tmp9 {
















			tmp9 = NN(affix).IndexOf_I__I(164) >= 0 }
//line :1566:1
		needQuote = tmp9
	}
















	if needQuote { NN(buffer).Append_C__StringBuilder(39) }
	if NN(affix).IndexOf_I__I(39) < 0 {
		NN(buffer).Append_String__StringBuilder(affix) } else {
			var j int32 = 0; L1: for {
				if j < NN(affix).Length__I() {
					var c uint16 = NN(affix).CharAt_I__C(j)
					NN(buffer).Append_C__StringBuilder(c)
					if int32(c) == 39 {
						NN(buffer).Append_C__StringBuilder(c); j = j + 1; continue L1 } else {
							j = j + 1; continue L1 } }
//line :1587:1
				break L1
			}
		}




	if needQuote { NN(buffer).Append_C__StringBuilder(39)
	} }
func (t *DecimalFormat) MatchAffix_String_I_String__Z(text *String, position int32, affix *String) bool {
	var alen int32 = NN(affix).Length__I(); var tlen int32 = NN(text).Length__I(); var tmp1 bool; var tmp2 bool


	tmp2 = position+alen > tlen; if !tmp2 { tmp2 = position < 0 }; tmp1 = tmp2
//line :1599:1
	if tmp1 { return false } else { if alen == 0 { return true } else { if t.F_parseStrict {


		return NN(text).RegionMatches_I_String_I_I__Z(position, affix, 0, alen) } else {

			var lms *String = NN(t.F_symbols).GetLenientMinusSigns__String(); var i int32 = 0; var limit int32 = Math_Min_I_I__I(tlen, position+alen)


		L1: for { if position+i < limit {
			var t_ uint16 = NN(text).CharAt_I__C(position + i); var a uint16 = NN(affix).CharAt_I__C(i); var tIndex int32 = NN(lms).IndexOf_I__I(int32(t_)); var aIndex int32 = NN(lms).IndexOf_I__I(int32(a)); var tmp3 bool; var tmp4 bool




			tmp4 = tIndex < 0; if tmp4 { tmp4 = aIndex < 0 }; tmp3 = tmp4
//line :1612:1
			if tmp3 {
				if int32(t_) == int32(a) { } else { return false } } else {
//line :1612:1
					var tmp5 bool; var tmp6 bool

					tmp6 = tIndex < 0; if !tmp6 { tmp6 = aIndex < 0 }; tmp5 = tmp6
//line :1612:1
					if tmp5 {

						return false } }
			i = i + 1
//line :1607:1
			continue L1 }; break L1
		}







			return i == alen
		} } } }
func (t *DecimalFormat) ToPattern_Z__String(localized bool) *String {
	var zeroSymbol uint16; if localized { zeroSymbol = NN(t.F_symbols).GetZeroDigit__C() } else { zeroSymbol = 48 }; var digitSymbol uint16
	if localized { digitSymbol = NN(t.F_symbols).GetDigit__C() } else { digitSymbol = 35 }
//line :1619:1
	var groupingSymbol uint16

	if localized {
		if t.F_isCurrencyFormat {
			groupingSymbol = NN(t.F_symbols).GetMonetaryGroupingSeparator__C() } else {
				groupingSymbol = NN(t.F_symbols).GetGroupingSeparator__C() } } else {
//line :1621:1
					groupingSymbol = 44 }
//line :1619:1
	var decimalSymbol uint16






	if localized {
		if t.F_isCurrencyFormat {
			decimalSymbol = NN(t.F_symbols).GetMonetaryDecimalSeparator__C() } else {
				decimalSymbol = NN(t.F_symbols).GetDecimalSeparator__C() } } else {
//line :1626:1
					decimalSymbol = 46 }
//line :1619:1
	var exponentSymbol *String











	if localized { exponentSymbol = NN(t.F_symbols).GetExponentSeparator__String() } else { exponentSymbol = Lit_1818 }
//line :1619:1
	var patternSeparator uint16












	if localized { patternSeparator = NN(t.F_symbols).GetPatternSeparator__C() } else { patternSeparator = 59 }
//line :1619:1
	var result *StringBuilder = StringBuilder_New()
	var j int32 = 1













L1: for {
	if j >= 0 {
		if j == 1 {
			t.AppendAffix_StringBuilder_String_String_Z__V(result, t.F_posPrefixPattern, t.F_positivePrefix, localized) } else {
				t.AppendAffix_StringBuilder_String_String_Z__V(result, t.F_negPrefixPattern, t.F_negativePrefix, localized) }
		var digitCount int32; if t.F_useExponentialNotation {
			digitCount = t.GetMaximumIntegerDigits__I() } else {
				var tmp1 int32 = int32(t.F_groupingSize); digitCount = Math_Max_I_I__I(tmp1, t.GetMinimumIntegerDigits__I()) + 1
			}

		var i int32 = digitCount; L2: for {
			if i > 0 {
				var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = !(i == digitCount); if tmp5 { tmp5 = t.IsGroupingUsed__Z() }; tmp4 = tmp5; if tmp4 {
					tmp4 = !(int32(t.F_groupingSize) == 0) }
//line :1646:1
				tmp3 = tmp4; if tmp3 {

					tmp3 = i%int32(t.F_groupingSize) == 0 }
//line :1646:1
				tmp2 = tmp3; if tmp2 {


					NN(result).Append_C__StringBuilder(groupingSymbol) }
				var tmp6 uint16; if i <= t.GetMinimumIntegerDigits__I() { tmp6 = zeroSymbol } else { tmp6 = digitSymbol }; NN(result).Append_C__StringBuilder(tmp6)
				i = i - 1; continue L2 }
//line :1644:1
			break L2
		}






		var tmp7 bool; var tmp8 bool; tmp8 = t.GetMaximumFractionDigits__I() > 0; if !tmp8 { tmp8 = t.F_decimalSeparatorAlwaysShown }; tmp7 = tmp8; if tmp7 {
			NN(result).Append_C__StringBuilder(decimalSymbol) }
		NN(result).Repeat_I_I__StringBuilder(int32(zeroSymbol), t.GetMinimumFractionDigits__I())
		NN(result).Repeat_I_I__StringBuilder(int32(digitSymbol), t.GetMaximumFractionDigits__I()-t.GetMinimumFractionDigits__I())



		if t.F_useExponentialNotation {
			NN(result).Append_String__StringBuilder(exponentSymbol)
			NN(result).Repeat_I_I__StringBuilder(int32(zeroSymbol), int32(t.F_minExponentDigits)) }
		if j == 1 {

			t.AppendAffix_StringBuilder_String_String_Z__V(result, t.F_posSuffixPattern, t.F_positiveSuffix, localized)
			if t.PosEqualsNegPattern__Z() { } else {
				NN(result).Append_C__StringBuilder(patternSeparator)
				j = j - 1; continue L1 } } else {

					t.AppendAffix_StringBuilder_String_String_Z__V(result, t.F_negSuffixPattern, t.F_negativeSuffix, localized)
					j = j - 1; continue L1 } }
//line :1634:1
	break L1
}



































	return NN(result).ToString__String()
}
func (t *DecimalFormat) PosEqualsNegPattern__Z() bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = t.F_negSuffixPattern == t.F_posSuffixPattern; if tmp3 {
		tmp3 = NN(t.F_negativeSuffix).Equals_O__Z(t.F_positiveSuffix.Ref()) }
//line :1674:1
	tmp2 = tmp3; if !tmp2 {

		var tmp4 bool; tmp4 = !(t.F_negSuffixPattern == nil); if tmp4 { tmp4 = NN(t.F_negSuffixPattern).Equals_O__Z(t.F_posSuffixPattern.Ref()) }; tmp2 = tmp4 }
//line :1674:1
	tmp1 = tmp2; if tmp1 {


		var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = !(t.F_negPrefixPattern == nil); if tmp7 { tmp7 = !(t.F_posPrefixPattern == nil) }; tmp6 = tmp7; if tmp6 {
			var tmp8 *String = t.F_negPrefixPattern; tmp6 = NN(tmp8).Equals_O__Z(Concat(Lit_1752, t.F_posPrefixPattern)) }
//line :1677:1
		tmp5 = tmp6; if !tmp5 {

			var tmp9 bool; tmp9 = t.F_negPrefixPattern == t.F_posPrefixPattern; if tmp9 {
				var tmp10 *String = t.F_negativePrefix; tmp9 = NN(tmp10).Equals_O__Z(Concat(NN(t.F_symbols).GetMinusSignText__String(), t.F_positivePrefix)) }
//line :1679:1
			tmp5 = tmp9 }
//line :1677:1
		tmp1 = tmp5 }
//line :1674:1
	return tmp1
}






func (t *DecimalFormat) ApplyPattern_String__V(pattern *String) {
	t.ApplyPattern_String_Z__V(pattern, false)
}
func (t *DecimalFormat) ApplyLocalizedPattern_String__V(pattern *String) {
	t.ApplyPattern_String_Z__V(pattern, true)
}
func (t *DecimalFormat) ApplyPattern_String_Z__V(pattern *String, localized bool) {
	var zeroDigit uint16 = 48
	var groupingSeparator uint16 = 44
	var decimalSeparator uint16 = 46
	var percent uint16 = 37
	var perMill uint16 = 8240
	var digit uint16 = 35
	var separator uint16 = 59
	var exponent /*line :1689:1*/*String = Lit_1818
	var minus uint16 = 45







	if localized {
		zeroDigit = NN(t.F_symbols).GetZeroDigit__C()
		groupingSeparator = NN(t.F_symbols).GetGroupingSeparator__C()
		decimalSeparator = NN(t.F_symbols).GetDecimalSeparator__C()
		percent = NN(t.F_symbols).GetPercent__C()
		perMill = NN(t.F_symbols).GetPerMill__C()
		digit = NN(t.F_symbols).GetDigit__C()
		separator = NN(t.F_symbols).GetPatternSeparator__C()
		exponent = NN(t.F_symbols).GetExponentSeparator__String()
		minus = NN(t.F_symbols).GetMinusSign__C() }
	var gotNegative bool = false
	t.F_decimalSeparatorAlwaysShown = false
	t.F_isCurrencyFormat = false
	t.F_useExponentialNotation = false
	var start int32 = 0; var j int32 = 1
L1: for {
	var tmp1 bool; var tmp2 bool; tmp2 = j >= 0; if tmp2 { tmp2 = start < NN(pattern).Length__I() }; tmp1 = tmp2; if tmp1 {
		var inQuote bool = false; var prefix *StringBuilder = StringBuilder_New(); var suffix *StringBuilder = StringBuilder_New()
		var decimalPos int32 = -1
		var multiplier int32 = 1
		var digitLeftCount int32 = 0
		var zeroDigitCount int32 = 0
		var digitRightCount int32 = 0
		var groupingCount int8 = -1
		var phase int32 = 0
		var affix /*line :1715:1*/*StringBuilder = prefix
		var pos int32 = start










	L2: for { if pos < NN(pattern).Length__I() {
		var ch uint16 = NN(pattern).CharAt_I__C(pos)
		switch phase { case 0, 2:


			if inQuote {

				if int32(ch) == 39 {
					var tmp3 bool; var tmp4 bool; tmp4 = pos+1 < NN(pattern).Length__I(); if tmp4 {
						tmp4 = int32(NN(pattern).CharAt_I__C(pos+1)) == 39 }
//line :1735:1
					tmp3 = tmp4; if tmp3 {

						pos = pos + 1; NN(affix).Append_String__StringBuilder(Lit_1749) } else {
							inQuote = false }
					pos = pos + 1
					continue L2 } } else {
//line :1732:1
						var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool








						tmp8 = int32(ch) == int32(digit); if !tmp8 { tmp8 = int32(ch) == int32(zeroDigit) }; tmp7 = tmp8; if !tmp7 {
							tmp7 = int32(ch) == int32(groupingSeparator) }
//line :1741:1
						tmp6 = tmp7; if !tmp6 {

							tmp6 = int32(ch) == int32(decimalSeparator) }
//line :1741:1
						tmp5 = tmp6
//line :1732:1
						if tmp5 {












							phase = 1
							pos = pos - 1
							pos = pos + 1
							continue L2 } else {
//line :1732:1
								if int32(ch) == 164 {

















									var doubled bool; var tmp9 bool
									tmp9 = pos+1 < NN(pattern).Length__I()
//line :1750:1
									if tmp9 {

										tmp9 = int32(NN(pattern).CharAt_I__C(pos+1)) == 164 }
//line :1750:1
									doubled = tmp9




									if doubled { pos = pos + 1 }
									t.F_isCurrencyFormat = true
									var tmp10 *StringBuilder = affix; var tmp11 *String; if doubled { tmp11 = Lit_1824 } else { tmp11 = Lit_1825 }; NN(tmp10).Append_String__StringBuilder(tmp11)
									pos = pos + 1
									continue L2 } else {
//line :1732:1
										if int32(ch) == 39 {





























											var tmp12 bool; var tmp13 bool; tmp13 = pos+1 < NN(pattern).Length__I(); if tmp13 {
												tmp13 = int32(NN(pattern).CharAt_I__C(pos+1)) == 39 }
//line :1762:1
											tmp12 = tmp13; if tmp12 {

												pos = pos + 1; NN(affix).Append_String__StringBuilder(Lit_1749) } else {
													inQuote = true }
											pos = pos + 1
											continue L2 } else {
//line :1732:1
												if int32(ch) == int32(separator) {





































													var tmp14 bool; var tmp15 bool; tmp15 = phase == 0; if !tmp15 { tmp15 = j == 0 }; tmp14 = tmp15; if tmp14 {
														panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1750, StrOfChar(ch), Lit_1751, pattern, Lit_1142))))
													}





													start = pos + 1
													pos = NN(pattern).Length__I()
													pos = pos + 1
													continue L2 } else {
//line :1732:1
														if int32(ch) == int32(percent) {



















































															if multiplier == 1 { } else {
																panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1826, pattern, Lit_1142))))
															}



															multiplier = 100
															NN(affix).Append_String__StringBuilder(Lit_1827)
															pos = pos + 1
															continue L2 } else {
//line :1732:1
																if int32(ch) == int32(perMill) {































































																	if multiplier == 1 { } else {
																		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1826, pattern, Lit_1142))))
																	}



																	multiplier = 1000
																	NN(affix).Append_String__StringBuilder(Lit_1828)
																	pos = pos + 1
																	continue L2 } else {

																		if int32(ch) == int32(minus) {
																			NN(affix).Append_String__StringBuilder(Lit_1752)
																			pos = pos + 1
																			continue L2 } } } } } } } }
			NN(affix).Append_C__StringBuilder(ch); case 1:

			if j == 0 {

			L3: for { if pos < NN(pattern).Length__I() {
				var negPatternChar uint16 = NN(pattern).CharAt_I__C(pos); var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 bool

				tmp19 = int32(negPatternChar) == int32(digit); if !tmp19 {
					tmp19 = int32(negPatternChar) == int32(zeroDigit) }
//line :1818:1
				tmp18 = tmp19; if !tmp18 {

					tmp18 = int32(negPatternChar) == int32(groupingSeparator) }
//line :1818:1
				tmp17 = tmp18; if !tmp17 {


					tmp17 = int32(negPatternChar) == int32(decimalSeparator) }
//line :1818:1
				tmp16 = tmp17
//line :1817:1
				if tmp16 {




					pos = pos + 1 } else {
//line :1817:1
						if NN(pattern).RegionMatches_I_String_I_I__Z(pos, exponent, 0, NN(exponent).Length__I()) {






							pos = pos + NN(exponent).Length__I() } else {


								pos = pos - 1
								phase = 2
								affix = suffix
								break L3 } }
//line :1815:1
				continue L3 }; break L3
			}

			} else {
//line :1813:1
				if int32(ch) == int32(digit) {



















					if zeroDigitCount > 0 {
						digitRightCount = digitRightCount + 1 } else {
							digitLeftCount = digitLeftCount + 1 }
					var tmp20 bool; var tmp21 bool; tmp21 = int32(groupingCount) >= 0; if tmp21 { tmp21 = decimalPos < 0 }; tmp20 = tmp21; if tmp20 {
						groupingCount = int8(int32(groupingCount) + 1) } } else {
//line :1813:1
							if int32(ch) == int32(zeroDigit) {



























								if digitRightCount > 0 {
									panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1829, pattern, Lit_1142))))
								}
								zeroDigitCount = zeroDigitCount + 1
								var tmp22 bool; var tmp23 bool; tmp23 = int32(groupingCount) >= 0; if tmp23 { tmp23 = decimalPos < 0 }; tmp22 = tmp23; if tmp22 {
									groupingCount = int8(int32(groupingCount) + 1) } } else {
//line :1813:1
										if int32(ch) == int32(groupingSeparator) {


































											groupingCount = 0 } else {
//line :1813:1
												if int32(ch) == int32(decimalSeparator) {





































													if decimalPos >= 0 {
														panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1830, pattern, Lit_1142))))
													}



													decimalPos = digitLeftCount + zeroDigitCount + digitRightCount } else {
//line :1813:1
														if NN(pattern).RegionMatches_I_String_I_I__Z(pos, exponent, 0, NN(exponent).Length__I()) {

















































															if t.F_useExponentialNotation {
																panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1831, pattern, Lit_1142))))
															}



															t.F_useExponentialNotation = true
															t.F_minExponentDigits = 0
															pos = pos + NN(exponent).Length__I()
														L4: for { var tmp24 bool; var tmp25 bool; tmp25 = pos < NN(pattern).Length__I(); if tmp25 {
															tmp25 = int32(NN(pattern).CharAt_I__C(pos)) == int32(zeroDigit) }
//line :1872:1
															tmp24 = tmp25; if tmp24 {

																t.F_minExponentDigits = int8(int32(t.F_minExponentDigits) + 1)

																pos = pos + 1
//line :1872:1
																continue L4 }; break L4
														}



															var tmp26 bool; var tmp27 bool; tmp27 = digitLeftCount+zeroDigitCount < 1; if !tmp27 {
																tmp27 = int32(t.F_minExponentDigits) < 1 }
//line :1877:1
															tmp26 = tmp27; if tmp26 {

																panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1832, pattern, Lit_1142))))
															}

															phase = 2
															affix = suffix
															pos = pos - 1
															pos = pos + 1
															continue L2 } else {


																phase = 2
																affix = suffix
																pos = pos - 1
																pos = pos + 1
																continue L2 } } } } } }
//line :1819:1
		default:
		}









































































		pos = pos + 1
//line :1727:1
		continue L2 }; break L2
	}






































































































































































		var tmp28 bool; var tmp29 bool; var tmp30 bool; tmp30 = zeroDigitCount == 0; if tmp30 { tmp30 = digitLeftCount > 0 }; tmp29 = tmp30; if tmp29 { tmp29 = decimalPos >= 0 }; tmp28 = tmp29; if tmp28 {
			var n int32 = decimalPos
			if n == 0 { n = n + 1 }
			digitRightCount = digitLeftCount - n
			digitLeftCount = n - 1
			zeroDigitCount = 1 }
		var tmp31 bool; var tmp32 bool; var tmp33 bool; var tmp34 bool; var tmp35 bool; tmp35 = decimalPos < 0; if tmp35 { tmp35 = digitRightCount > 0 }; tmp34 = tmp35; if !tmp34 {
			var tmp36 bool; tmp36 = decimalPos >= 0; if tmp36 {
				var tmp37 bool; tmp37 = decimalPos < digitLeftCount; if !tmp37 {
					tmp37 = decimalPos > digitLeftCount+zeroDigitCount }
//line :1903:1
				tmp36 = tmp37 }
//line :1902:1
			tmp34 = tmp36 }
//line :1901:1
		tmp33 = tmp34; if !tmp33 {




			tmp33 = int32(groupingCount) == 0 }
//line :1901:1
		tmp32 = tmp33; if !tmp32 { tmp32 = inQuote }; tmp31 = tmp32; if tmp31 {






			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1833, pattern, Lit_1142)))) }
		if j == 1 {

			t.F_posPrefixPattern = NN(prefix).ToString__String()
			t.F_posSuffixPattern = NN(suffix).ToString__String()
			t.F_negPrefixPattern = t.F_posPrefixPattern
			t.F_negSuffixPattern = t.F_posSuffixPattern
			var digitTotalCount int32 = digitLeftCount + zeroDigitCount + digitRightCount; var effectiveDecimalPos int32


			if decimalPos >= 0 { effectiveDecimalPos = decimalPos } else { effectiveDecimalPos = digitTotalCount
			}

			t.SetMinimumIntegerDigits_I__V(effectiveDecimalPos - digitLeftCount)


			var tmp38 int32

			if t.F_useExponentialNotation {
				tmp38 = digitLeftCount + t.GetMinimumIntegerDigits__I() } else {
//line :1926:1
					tmp38 = 2147483647 }
//line :1924:1
			t.SetMaximumIntegerDigits_I__V(tmp38)




			var tmp39 int32

			if decimalPos >= 0 {
				tmp39 = digitTotalCount - decimalPos } else {
//line :1931:1
					tmp39 = 0 }
//line :1929:1
			t.SetMaximumFractionDigits_I__V(tmp39)




			var tmp40 int32

			if decimalPos >= 0 {
				tmp40 = digitLeftCount + zeroDigitCount - decimalPos } else {
//line :1936:1
					tmp40 = 0 }
//line :1934:1
			t.SetMinimumFractionDigits_I__V(tmp40)






			t.SetGroupingUsed_Z__V(int32(groupingCount) > 0)
			var tmp41 int8; if int32(groupingCount) > 0 { tmp41 = groupingCount } else { tmp41 = 0 }; t.F_groupingSize = tmp41
			t.F_multiplier = multiplier
			var tmp42 bool; var tmp43 bool

			tmp43 = decimalPos == 0; if !tmp43 { tmp43 = decimalPos == digitTotalCount }; tmp42 = tmp43
//line :1944:1
			t.SetDecimalSeparatorAlwaysShown_Z__V(tmp42)


			j = j - 1; continue L1 } else {

				t.F_negPrefixPattern = NN(prefix).ToString__String()
				t.F_negSuffixPattern = NN(suffix).ToString__String()
				gotNegative = true
				j = j - 1; continue L1 } }
//line :1713:1
	break L1
}














































































































































































































































	if NN(pattern).IsEmpty__Z() {
		var tmp44 *String; var tmp45 *String = Lit_69; t.F_posSuffixPattern = tmp45; tmp44 = tmp45; t.F_posPrefixPattern = tmp44
		t.SetMinimumIntegerDigits_I__V(0)
		t.SetMaximumIntegerDigits_I__V(2147483647)
		t.SetMinimumFractionDigits_I__V(0)
		t.SetMaximumFractionDigits_I__V(340) }
	var tmp46 bool; var tmp47 bool; tmp47 = !gotNegative; if !tmp47 {
		var tmp48 bool; tmp48 = NN(t.F_negPrefixPattern).Equals_O__Z(t.F_posPrefixPattern.Ref()); if tmp48 {
			tmp48 = NN(t.F_negSuffixPattern).Equals_O__Z(t.F_posSuffixPattern.Ref()) }
//line :1960:1
		tmp47 = tmp48 }
//line :1959:1
	tmp46 = tmp47; if tmp46 {


		t.F_negSuffixPattern = t.F_posSuffixPattern
		t.F_negPrefixPattern = Concat(Lit_1752, t.F_posPrefixPattern) }
	t.ExpandAffixes__V()
}
func (t *DecimalFormat) SetMaximumIntegerDigits_I__V(newValue int32) {
	t.F_maximumIntegerDigits = Math_Clamp_J_I_I__I(int64(newValue), 0, 2147483647)
	t.NumberFormat.Impl_SetMaximumIntegerDigits_I__V(t, Math_Min_I_I__I(t.F_maximumIntegerDigits, 309))
	if t.F_minimumIntegerDigits > t.F_maximumIntegerDigits {
		t.F_minimumIntegerDigits = t.F_maximumIntegerDigits
		t.NumberFormat.Impl_SetMinimumIntegerDigits_I__V(t, Math_Min_I_I__I(t.F_minimumIntegerDigits, 309)) }
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) SetMinimumIntegerDigits_I__V(newValue int32) {
	t.F_minimumIntegerDigits = Math_Clamp_J_I_I__I(int64(newValue), 0, 2147483647)
	t.NumberFormat.Impl_SetMinimumIntegerDigits_I__V(t, Math_Min_I_I__I(t.F_minimumIntegerDigits, 309))
	if t.F_minimumIntegerDigits > t.F_maximumIntegerDigits {
		t.F_maximumIntegerDigits = t.F_minimumIntegerDigits
		t.NumberFormat.Impl_SetMaximumIntegerDigits_I__V(t, Math_Min_I_I__I(t.F_maximumIntegerDigits, 309)) }
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) SetMaximumFractionDigits_I__V(newValue int32) {
	t.F_maximumFractionDigits = Math_Clamp_J_I_I__I(int64(newValue), 0, 2147483647)
	t.NumberFormat.Impl_SetMaximumFractionDigits_I__V(t, Math_Min_I_I__I(t.F_maximumFractionDigits, 340))
	if t.F_minimumFractionDigits > t.F_maximumFractionDigits {
		t.F_minimumFractionDigits = t.F_maximumFractionDigits
		t.NumberFormat.Impl_SetMinimumFractionDigits_I__V(t, Math_Min_I_I__I(t.F_minimumFractionDigits, 340)) }
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) SetMinimumFractionDigits_I__V(newValue int32) {
	t.F_minimumFractionDigits = Math_Clamp_J_I_I__I(int64(newValue), 0, 2147483647)
	t.NumberFormat.Impl_SetMinimumFractionDigits_I__V(t, Math_Min_I_I__I(t.F_minimumFractionDigits, 340))
	if t.F_minimumFractionDigits > t.F_maximumFractionDigits {
		t.F_maximumFractionDigits = t.F_minimumFractionDigits
		t.NumberFormat.Impl_SetMaximumFractionDigits_I__V(t, Math_Min_I_I__I(t.F_maximumFractionDigits, 340)) }
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) GetMaximumIntegerDigits__I() int32 { return t.F_maximumIntegerDigits }


func (t *DecimalFormat) GetMinimumIntegerDigits__I() int32 { return t.F_minimumIntegerDigits }


func (t *DecimalFormat) GetMaximumFractionDigits__I() int32 { return t.F_maximumFractionDigits }


func (t *DecimalFormat) GetMinimumFractionDigits__I() int32 { return t.F_minimumFractionDigits }


func (t *DecimalFormat) GetCurrency__Currency() *Currency { return NN(t.F_symbols).GetCurrency__Currency() }

func (t *DecimalFormat) SetCurrency_Currency__V(currency *Currency) {
	if currency == NN(t.F_symbols).GetCurrency__Currency() { } else {
		NN(t.F_symbols).SetCurrency_Currency__V(currency)
		if t.F_isCurrencyFormat { t.ExpandAffixes__V() } }
	t.F_fastPathCheckNeeded = true
}
func (t *DecimalFormat) GetRoundingMode__RoundingMode() *RoundingMode { return t.F_roundingMode }

func (t *DecimalFormat) SetRoundingMode_RoundingMode__V(roundingMode *RoundingMode) {
	if roundingMode == nil { panic(Thrown(NullPointerException_New())) }
	t.F_roundingMode = roundingMode
	NN(t.F_digitList).SetRoundingMode_RoundingMode__V(roundingMode)
	t.F_fastPathCheckNeeded = true
}


type DecimalFormat struct{ NumberFormat; F_bigIntegerMultiplier *BigInteger; F_bigDecimalMultiplier *BigDecimal; F_digitList *DigitList; F_positivePrefix, F_positiveSuffix, F_negativePrefix, F_negativeSuffix, F_posPrefixPattern, F_posSuffixPattern, F_negPrefixPattern, F_negSuffixPattern *String; F_multiplier int32; F_groupingSize int8; F_decimalSeparatorAlwaysShown, F_parseBigDecimal, F_isCurrencyFormat bool; F_symbols *DecimalFormatSymbols; F_useExponentialNotation, F_parseStrict bool; F_positivePrefixFieldPositions, F_positiveSuffixFieldPositions, F_negativePrefixFieldPositions, F_negativeSuffixFieldPositions *RefArray; F_minExponentDigits int8; F_maximumIntegerDigits, F_minimumIntegerDigits, F_maximumFractionDigits, F_minimumFractionDigits int32; F_roundingMode *RoundingMode; F_isFastPath, F_fastPathCheckNeeded bool; F_fastPathData *DecimalFormat_FastPathData; F_serialVersionOnStream int32 }

const DecimalFormat_STATUS_INFINITE int32 = 0

const DecimalFormat_STATUS_POSITIVE int32 = 1

const DecimalFormat_STATUS_LENGTH int32 = 2

const DecimalFormat_currentSerialVersion int32 = 4

const DecimalFormat_MAX_INT_AS_DOUBLE float64 = 2.147483647e9

const DecimalFormat_PATTERN_ZERO_DIGIT uint16 = 48

const DecimalFormat_PATTERN_GROUPING_SEPARATOR uint16 = 44

const DecimalFormat_PATTERN_DECIMAL_SEPARATOR uint16 = 46

const DecimalFormat_PATTERN_PER_MILLE uint16 = 8240

const DecimalFormat_PATTERN_PERCENT uint16 = 37

const DecimalFormat_PATTERN_DIGIT uint16 = 35

const DecimalFormat_PATTERN_SEPARATOR uint16 = 59

var DecimalFormat_PATTERN_EXPONENT *String = Lit_1818

const DecimalFormat_PATTERN_MINUS uint16 = 45

const DecimalFormat_CURRENCY_SIGN uint16 = 164

const DecimalFormat_QUOTE uint16 = 39

var DecimalFormat_EmptyFieldPositionArray *RefArray

const DecimalFormat_DOUBLE_INTEGER_DIGITS int32 = 309

const DecimalFormat_DOUBLE_FRACTION_DIGITS int32 = 340

const DecimalFormat_MAXIMUM_INTEGER_DIGITS int32 = 2147483647

const DecimalFormat_MAXIMUM_FRACTION_DIGITS int32 = 2147483647

const DecimalFormat_serialVersionUID int64 = 864413376551465018

var DecimalFormat_init ClassInit

func DecimalFormat_Init() { if !DecimalFormat_init.Done() { DecimalFormat_init.Run(DecimalFormat_clinit) } }

func DecimalFormat_clinit() { DecimalFormat_EmptyFieldPositionArray = NewRefArray(FieldPosition_class, 0) }

func (t *DecimalFormat) Format_O__String(p0 any) *String { return t.Impl_Format_O__String(t, p0) }

func (t *DecimalFormat) IsGroupingUsed__Z() bool { return t.Impl_IsGroupingUsed__Z(t) }

func (t *DecimalFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(t, p0) }

func (t *DecimalFormat) Format_D__String(p0 float64) *String { return t.Impl_Format_D__String(t, p0) }

func (t *DecimalFormat) ParseObject_String__O(p0 *String) any { return t.Impl_ParseObject_String__O(t, p0) }

func (t *DecimalFormat) ParseObject_String_ParsePosition__O(p0 *String, p1 *ParsePosition) any { return t.Impl_ParseObject_String_ParsePosition__O(t, p0, p1) }

func (t *DecimalFormat) Parse_String__Number(p0 *String) Number_I { return t.Impl_Parse_String__Number(t, p0) }

func (t *DecimalFormat) Format_J__String(p0 int64) *String { return t.Impl_Format_J__String(t, p0) }

func (t *DecimalFormat) CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *DecimalFormat) IsParseIntegerOnly__Z() bool { return t.Impl_IsParseIntegerOnly__Z(t) }

func (t *DecimalFormat) SetParseIntegerOnly_Z__V(p0 bool) { t.Impl_SetParseIntegerOnly_Z__V(t, p0) }

func (t *DecimalFormat) CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(t, p0) }

func (t *DecimalFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *DecimalFormat) Ref() any { if t == nil { return nil }; return t }

func (t *DecimalFormat) GetClass__Class() *Class { return DecimalFormat_class }

func (t *DecimalFormat) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func DecimalFormat_InstanceOf(x any) bool { _, ok := x.(*DecimalFormat); return ok }

func DecimalFormat_Cast(x any) *DecimalFormat { if x == nil { return nil }; v, ok := x.(*DecimalFormat); if !ok { panic(ClassCast(x, DecimalFormat_class)) }; return v }



type DecimalFormat_DigitArrays struct{ Object }

var DecimalFormat_DigitArrays_DigitOnes1000 *CharArray

var DecimalFormat_DigitArrays_DigitTens1000 *CharArray

var DecimalFormat_DigitArrays_DigitHundreds1000 *CharArray

var DecimalFormat_DigitArrays_init ClassInit

func DecimalFormat_DigitArrays_Init() { if !DecimalFormat_DigitArrays_init.Done() { DecimalFormat_DigitArrays_init.Run(DecimalFormat_DigitArrays_clinit) } }

func DecimalFormat_DigitArrays_clinit() { DecimalFormat_DigitArrays_DigitOnes1000 = NewCharArray(1000); DecimalFormat_DigitArrays_DigitTens1000 = NewCharArray(1000); DecimalFormat_DigitArrays_DigitHundreds1000 = NewCharArray(1000)






















	var tenIndex int32 = 0
	var hundredIndex int32 = 0
	var digitOne uint16 = 48
	var digitTen uint16 = 48
	var digitHundred uint16 = 48; var i int32 = 0
L1: for {
	if i < 1000 {
		DecimalFormat_DigitArrays_DigitOnes1000.A[i] = digitOne
		if int32(digitOne) == 57 {
			digitOne = 48 } else {
				digitOne = uint16(int32(digitOne) + 1) }
		DecimalFormat_DigitArrays_DigitTens1000.A[i] = digitTen
		if i == tenIndex+9 {
			tenIndex = tenIndex + 10
			if int32(digitTen) == 57 {
				digitTen = 48 } else {
					digitTen = uint16(int32(digitTen) + 1) } }
		DecimalFormat_DigitArrays_DigitHundreds1000.A[i] = digitHundred
		if i == hundredIndex+99 {

			digitHundred = uint16(int32(digitHundred) + 1)
			hundredIndex = hundredIndex + 100
			i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :2158:1
	break L1
}
}

















func DecimalFormat_DigitArrays_New() *DecimalFormat_DigitArrays { DecimalFormat_DigitArrays_Init(); t := &DecimalFormat_DigitArrays{}; t.Ctor(); return t }

func (t *DecimalFormat_DigitArrays) Ctor() {}

func (t *DecimalFormat_DigitArrays) Ref() any { if t == nil { return nil }; return t }

func (t *DecimalFormat_DigitArrays) GetClass__Class() *Class { return DecimalFormat_DigitArrays_class }

func (t *DecimalFormat_DigitArrays) ToString__String() *String { return Object_toString(t) }

func (t *DecimalFormat_DigitArrays) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DecimalFormat_DigitArrays) CloneShallow() any { panic(CloneNotSupported(t)) }

func DecimalFormat_DigitArrays_InstanceOf(x any) bool { _, ok := x.(*DecimalFormat_DigitArrays); return ok }

func DecimalFormat_DigitArrays_Cast(x any) *DecimalFormat_DigitArrays { if x == nil { return nil }; v, ok := x.(*DecimalFormat_DigitArrays); if !ok { panic(ClassCast(x, DecimalFormat_DigitArrays_class)) }; return v }



type DecimalFormat_FastPathData struct{ Object; F_lastFreeIndex, F_firstUsedIndex, F_zeroDelta int32; F_groupingChar uint16; F_integralLastIndex, F_fractionalFirstIndex int32; F_fractionalScaleFactor float64; F_fractionalMaxIntBound int32; F_fastPathContainer, F_charsPositivePrefix, F_charsNegativePrefix, F_charsPositiveSuffix, F_charsNegativeSuffix *CharArray; F_positiveAffixesRequired, F_negativeAffixesRequired bool }

func DecimalFormat_FastPathData_New() *DecimalFormat_FastPathData { t := &DecimalFormat_FastPathData{}; t.Ctor(); return t }

func (t *DecimalFormat_FastPathData) Ctor() { t.F_positiveAffixesRequired = true; t.F_negativeAffixesRequired = true }

func (t *DecimalFormat_FastPathData) Ref() any { if t == nil { return nil }; return t }

func (t *DecimalFormat_FastPathData) GetClass__Class() *Class { return DecimalFormat_FastPathData_class }

func (t *DecimalFormat_FastPathData) ToString__String() *String { return Object_toString(t) }

func (t *DecimalFormat_FastPathData) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DecimalFormat_FastPathData) CloneShallow() any { panic(CloneNotSupported(t)) }

func DecimalFormat_FastPathData_InstanceOf(x any) bool { _, ok := x.(*DecimalFormat_FastPathData); return ok }

func DecimalFormat_FastPathData_Cast(x any) *DecimalFormat_FastPathData { if x == nil { return nil }; v, ok := x.(*DecimalFormat_FastPathData); if !ok { panic(ClassCast(x, DecimalFormat_FastPathData_class)) }; return v }



type DecimalFormat_NumericPosition struct{ Record; F_fullPos, F_intPos int32 }

func DecimalFormat_NumericPosition_New_I_I(p0, p1 int32) *DecimalFormat_NumericPosition { t := &DecimalFormat_NumericPosition{}; t.Ctor_I_I(p0, p1); return t }

func (t *DecimalFormat_NumericPosition) Ctor_I_I(fullPos, intPos int32) { t.Record.Ctor(t); t.F_fullPos = fullPos; t.F_intPos = intPos }

func (t *DecimalFormat_NumericPosition) FullPos__I() int32 { return t.F_fullPos }

func (t *DecimalFormat_NumericPosition) IntPos__I() int32 { return t.F_intPos }

func (t *DecimalFormat_NumericPosition) ToString__String() *String { return Concat(Lit_1834, Lit_1835, StrOfInt(int32(t.F_fullPos)), Lit_1836, StrOfInt(int32(t.F_intPos)), Lit_1189) }

func (t *DecimalFormat_NumericPosition) HashCode__I() int32 { return (int32(0)*31+int32(t.F_fullPos))*31 + int32(t.F_intPos) }

func (t *DecimalFormat_NumericPosition) Equals_O__Z(p0 any) bool { if any(t) == p0 { return true }; if p0 == nil || GetClass(p0) != DecimalFormat_NumericPosition_class { return false }; other := p0.(*DecimalFormat_NumericPosition); return t.F_fullPos == other.F_fullPos && t.F_intPos == other.F_intPos }

func (t *DecimalFormat_NumericPosition) Ref() any { if t == nil { return nil }; return t }

func (t *DecimalFormat_NumericPosition) GetClass__Class() *Class { return DecimalFormat_NumericPosition_class }

func (t *DecimalFormat_NumericPosition) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DecimalFormat_NumericPosition) CloneShallow() any { panic(CloneNotSupported(t)) }

func DecimalFormat_NumericPosition_InstanceOf(x any) bool { _, ok := x.(*DecimalFormat_NumericPosition); return ok }

func DecimalFormat_NumericPosition_Cast(x any) *DecimalFormat_NumericPosition { if x == nil { return nil }; v, ok := x.(*DecimalFormat_NumericPosition); if !ok { panic(ClassCast(x, DecimalFormat_NumericPosition_class)) }; return v }
