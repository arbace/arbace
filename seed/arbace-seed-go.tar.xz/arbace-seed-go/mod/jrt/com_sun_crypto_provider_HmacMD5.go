//line com_sun_crypto_provider_HmacMD5.ae:1
package jrt








func HmacMD5_New() *HmacMD5 { t := &HmacMD5{}; t.Ctor(); return t }
//line :10:1
func (t *HmacMD5) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_15, 64) }





type HmacMD5 struct{ HmacCore }

func (t *HmacMD5) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacMD5) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacMD5) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacMD5) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacMD5) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacMD5) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacMD5) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacMD5) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacMD5) Ref() any { if t == nil { return nil }; return t }

func (t *HmacMD5) GetClass__Class() *Class { return HmacMD5_class }

func (t *HmacMD5) ToString__String() *String { return Object_toString(t) }

func (t *HmacMD5) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacMD5_InstanceOf(x any) bool { _, ok := x.(*HmacMD5); return ok }

func HmacMD5_Cast(x any) *HmacMD5 { if x == nil { return nil }; v, ok := x.(*HmacMD5); if !ok { panic(ClassCast(x, HmacMD5_class)) }; return v }
