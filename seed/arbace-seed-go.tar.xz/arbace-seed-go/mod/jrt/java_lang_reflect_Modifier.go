//line java_lang_reflect_Modifier.ae:1
package jrt






func Modifier_New() *Modifier { t := &Modifier{}; t.Ctor(); return t }
//line :8:1
func (t *Modifier) Ctor() { panic(A2g_NotTranslated("java.lang.reflect.Modifier.<init>()V")) }

func Modifier_IsPublic_I__Z(mod int32) bool {
	return !(mod&1 == 0)
}
func Modifier_IsPrivate_I__Z(mod int32) bool {
	return !(mod&2 == 0)
}
func Modifier_IsProtected_I__Z(mod int32) bool {
	return !(mod&4 == 0)
}
func Modifier_IsStatic_I__Z(mod int32) bool {
	return !(mod&8 == 0)
}
func Modifier_IsFinal_I__Z(mod int32) bool {
	return !(mod&16 == 0)
}
func Modifier_IsSynchronized_I__Z(mod int32) bool {
	return !(mod&32 == 0)
}
func Modifier_IsVolatile_I__Z(mod int32) bool {
	return !(mod&64 == 0)
}
func Modifier_IsTransient_I__Z(mod int32) bool {
	return !(mod&128 == 0)
}
func Modifier_IsNative_I__Z(mod int32) bool {
	return !(mod&256 == 0)
}
func Modifier_IsInterface_I__Z(mod int32) bool {
	return !(mod&512 == 0)
}
func Modifier_IsAbstract_I__Z(mod int32) bool {
	return !(mod&1024 == 0)
}
func Modifier_IsStrict_I__Z(mod int32) bool {
	return !(mod&2048 == 0)
}
func Modifier_ToString_I__String(mod int32) *String {
	var sj *StringJoiner = StringJoiner_New_CharSequence(Lit_115)
	if mod&1 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1196) }
	if mod&4 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1197) }
	if mod&2 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1198) }
	if mod&1024 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1199) }
	if mod&8 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1200) }
	if mod&16 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1201) }
	if mod&128 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1202) }
	if mod&64 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1203) }
	if mod&32 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1204) }
	if mod&256 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1205) }
	if mod&2048 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1206) }
	if mod&512 == 0 { } else { NN(sj).Add_CharSequence__StringJoiner(Lit_1207) }
	return NN(sj).ToString__String()
}




































func Modifier_IsSynthetic_I__Z(p0 int32) bool { panic(A2g_NotTranslated("java.lang.reflect.Modifier.isSynthetic(I)Z")) }


func Modifier_IsMandated_I__Z(p0 int32) bool { panic(A2g_NotTranslated("java.lang.reflect.Modifier.isMandated(I)Z")) }




















































func Modifier_ClassModifiers__I() int32 { return 3103 }

func Modifier_InterfaceModifiers__I() int32 { return 3087 }


func Modifier_ConstructorModifiers__I() int32 { return 7 }


func Modifier_MethodModifiers__I() int32 { return 3391 }

func Modifier_FieldModifiers__I() int32 { return 223 }

func Modifier_ParameterModifiers__I() int32 { return 16 }



type Modifier struct{ Object }

const Modifier_PUBLIC int32 = 1

const Modifier_PRIVATE int32 = 2

const Modifier_PROTECTED int32 = 4

const Modifier_STATIC int32 = 8

const Modifier_FINAL int32 = 16

const Modifier_SYNCHRONIZED int32 = 32

const Modifier_VOLATILE int32 = 64

const Modifier_TRANSIENT int32 = 128

const Modifier_NATIVE int32 = 256

const Modifier_INTERFACE int32 = 512

const Modifier_ABSTRACT int32 = 1024

const Modifier_STRICT int32 = 2048

const Modifier_BRIDGE int32 = 64

const Modifier_VARARGS int32 = 128

const Modifier_SYNTHETIC int32 = 4096

const Modifier_ANNOTATION int32 = 8192

const Modifier_ENUM int32 = 16384

const Modifier_MANDATED int32 = 32768

const Modifier_CLASS_MODIFIERS int32 = 3103

const Modifier_INTERFACE_MODIFIERS int32 = 3087

const Modifier_CONSTRUCTOR_MODIFIERS int32 = 7

const Modifier_METHOD_MODIFIERS int32 = 3391

const Modifier_FIELD_MODIFIERS int32 = 223

const Modifier_PARAMETER_MODIFIERS int32 = 16

const Modifier_ACCESS_MODIFIERS int32 = 7

func (t *Modifier) Ref() any { if t == nil { return nil }; return t }

func (t *Modifier) GetClass__Class() *Class { return Modifier_class }

func (t *Modifier) ToString__String() *String { return Object_toString(t) }

func (t *Modifier) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Modifier) CloneShallow() any { panic(CloneNotSupported(t)) }

func Modifier_InstanceOf(x any) bool { _, ok := x.(*Modifier); return ok }

func Modifier_Cast(x any) *Modifier { if x == nil { return nil }; v, ok := x.(*Modifier); if !ok { panic(ClassCast(x, Modifier_class)) }; return v }
