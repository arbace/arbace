//line java_util_Formattable.ae:1
package jrt






type Formattable interface{ Object_I; Is_Formattable(); FormatTo_Formatter_I_I_I__V(p0 *Formatter, p1, p2, p3 int32) }

func Formattable_InstanceOf(x any) bool { _, ok := x.(Formattable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Formattable_class) } }; return ok }

func Formattable_Cast(x any) Formattable { if x == nil { return nil }; v, ok := x.(Formattable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Formattable_class) } }; if !ok { panic(ClassCast(x, Formattable_class)) }; return v }
