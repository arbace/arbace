//line java_nio_file_LinkOption.ae:1
package jrt






type LinkOption struct{ Enum }

func (t *LinkOption) Is_OpenOption() {}

func (t *LinkOption) Is_CopyOption() {}

func (t *LinkOption) Is_Constable() {}

var LinkOption_NOFOLLOW_LINKS *LinkOption

var LinkOption__VALUES *RefArray

var LinkOption_init ClassInit

func LinkOption_Init() { if !LinkOption_init.Done() { LinkOption_init.Run(LinkOption_clinit) } }

func LinkOption_clinit() { LinkOption_NOFOLLOW_LINKS = LinkOption_New_String_I(Lit_1505, 0); LinkOption__VALUES = LinkOption_X_values__LinkOption1() }

func LinkOption_New_String_I(p0 *String, p1 int32) *LinkOption { LinkOption_Init(); t := &LinkOption{}; t.Ctor_String_I(p0, p1); return t }

func (t *LinkOption) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func LinkOption_Values__LinkOption1() *RefArray { LinkOption_Init(); return LinkOption__VALUES.Copy() }

func LinkOption_ValueOf_String__LinkOption(p0 *String) *LinkOption { LinkOption_Init(); return LinkOption_Cast(Enum_ValueOf_Class_String__Enum(LinkOption_class, p0)) }

func LinkOption_X_values__LinkOption1() *RefArray { LinkOption_Init(); return RefArrayOf(LinkOption_class, LinkOption_NOFOLLOW_LINKS) }

func (t *LinkOption) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *LinkOption) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *LinkOption) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *LinkOption) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.nio.file.LinkOption.describeConstable()Ljava/util/Optional;")) }

func (t *LinkOption) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *LinkOption) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkOption) Ref() any { if t == nil { return nil }; return t }

func (t *LinkOption) GetClass__Class() *Class { return LinkOption_class }

func (t *LinkOption) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkOption_InstanceOf(x any) bool { _, ok := x.(*LinkOption); return ok }

func LinkOption_Cast(x any) *LinkOption { if x == nil { return nil }; v, ok := x.(*LinkOption); if !ok { panic(ClassCast(x, LinkOption_class)) }; return v }
