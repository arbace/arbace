//line java_util_Map.ae:1
package jrt















































func Map_Entry_ComparingByKey__Comparator() Comparator {
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 Map_Entry = Map_Entry_Cast(p0); var c2 Map_Entry = Map_Entry_Cast(p1); return Comparable_Cast(c1.GetKey__O()).CompareTo_O__I(c2.GetKey__O()) }}))
}



func Map_Entry_ComparingByValue__Comparator() Comparator {
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 Map_Entry = Map_Entry_Cast(p0); var c2 Map_Entry = Map_Entry_Cast(p1); return Comparable_Cast(c1.GetValue__O()).CompareTo_O__I(c2.GetValue__O()) }}))
}



func Map_Entry_ComparingByKey_Comparator__Comparator(cmp Comparator) Comparator {
	Objects_RequireNonNull_O__O(cmp)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 Map_Entry = Map_Entry_Cast(p0); var c2 Map_Entry = Map_Entry_Cast(p1); return cmp.Compare_O_O__I(c1.GetKey__O(), c2.GetKey__O()) }}))
}



func Map_Entry_ComparingByValue_Comparator__Comparator(cmp Comparator) Comparator {
	Objects_RequireNonNull_O__O(cmp)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 Map_Entry = Map_Entry_Cast(p0); var c2 Map_Entry = Map_Entry_Cast(p1); return cmp.Compare_O_O__I(c1.GetValue__O(), c2.GetValue__O()) }}))
}



func Map_Entry_CopyOf_Map_Entry__Map_Entry(e Map_Entry) Map_Entry {
	Objects_RequireNonNull_O__O(e)
	if KeyValueHolder_InstanceOf(e) { return e } else { return Map_Entry_O_O__Map_Entry(e.GetKey__O(), e.GetValue__O())
	}
}



func Map_GetOrDefault_O_O__O(this Map, key, defaultValue any) any {
	var v any; var tmp1 bool; var tmp2 bool; var tmp3 any
	v = this.Get_O__O(key); tmp3 = v; tmp2 = !(tmp3 == nil); if !tmp2 { tmp2 = this.ContainsKey_O__Z(key) }; tmp1 = tmp2; if tmp1 { return v } else { return defaultValue
	} }
func Map_ForEach_BiConsumer__V(this Map, action BiConsumer) {
	Objects_RequireNonNull_O__O(action)
	var i_101970 Iterator = this.EntrySet__Set().Iterator__Iterator(); for i_101970.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101970.Next__O()); var k any; var v any; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)



		k = entry.GetKey__O()
		v = entry.GetValue__O(); return nil }()
//line :92:1
		if tmp1 != nil { if IllegalStateException_InstanceOf(tmp1) { var ise IllegalStateException_I = IllegalStateException_Cast(tmp1)


			panic(Thrown(ConcurrentModificationException_New_Throwable(ise))) } else {
//line :92:1
				panic(tmp1)
			}
		}

		action.Accept_O_O__V(k, v)
	} }
func Map_ReplaceAll_BiFunction__V(this Map, function BiFunction) {

	Objects_RequireNonNull_O__O(function)
	var i_101971 Iterator = this.EntrySet__Set().Iterator__Iterator(); for i_101971.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101971.Next__O()); var k any; var v any; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)



		k = entry.GetKey__O()
		v = entry.GetValue__O(); return nil }()
//line :104:1
		if tmp1 != nil { if IllegalStateException_InstanceOf(tmp1) { var ise IllegalStateException_I = IllegalStateException_Cast(tmp1)


			panic(Thrown(ConcurrentModificationException_New_Throwable(ise))) } else {
//line :104:1
				panic(tmp1)
			}
		}

		v = function.Apply_O_O__O(k, v); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

			entry.SetValue_O__O(v); return nil }()
//line :109:1
		if tmp2 != nil { if IllegalStateException_InstanceOf(tmp2) { var ise_2 IllegalStateException_I = IllegalStateException_Cast(tmp2)

			panic(Thrown(ConcurrentModificationException_New_Throwable(ise_2))) } else {
//line :109:1
				panic(tmp2)
			}
		}
	} }
func Map_PutIfAbsent_O_O__O(this Map, key, value any) any {
	var v any = this.Get_O__O(key); if v == nil { v = this.Put_O_O__O(key, value) }; return v
}
func Map_Remove_O_O__Z(this Map, key, value any) bool {
	var curValue any = this.Get_O__O(key); var tmp1 bool; var tmp2 bool
	tmp2 = !Objects_Equals_O_O__Z(curValue, value); if !tmp2 {
		var tmp3 bool; tmp3 = curValue == nil; if tmp3 { tmp3 = !this.ContainsKey_O__Z(key) }; tmp2 = tmp3 }
//line :118:1
	tmp1 = tmp2; if tmp1 { return false } else {


		this.Remove_O__O(key); return true
	} }
func Map_Replace_O_O_O__Z(this Map, key, oldValue, newValue any) bool {
	var curValue any = this.Get_O__O(key); var tmp1 bool; var tmp2 bool
	tmp2 = !Objects_Equals_O_O__Z(curValue, oldValue); if !tmp2 {
		var tmp3 bool; tmp3 = curValue == nil; if tmp3 { tmp3 = !this.ContainsKey_O__Z(key) }; tmp2 = tmp3 }
//line :125:1
	tmp1 = tmp2; if tmp1 { return false } else {


		this.Put_O_O__O(key, newValue); return true
	} }
func Map_Replace_O_O__O(this Map, key, value any) any {
	var curValue any; var tmp1 bool; var tmp2 bool; var tmp3 any
	curValue = this.Get_O__O(key); tmp3 = curValue; tmp2 = !(tmp3 == nil); if !tmp2 { tmp2 = this.ContainsKey_O__Z(key) }; tmp1 = tmp2; if tmp1 {
		curValue = this.Put_O_O__O(key, value) }
//line :131:1
	return curValue
}



func Map_ComputeIfAbsent_O_Function__O(this Map, key any, mappingFunction Function) any {

	Objects_RequireNonNull_O__O(mappingFunction)
	var v any; var tmp1 any
	v = this.Get_O__O(key); tmp1 = v; if tmp1 == nil {
		var newValue any; var tmp2 any
		newValue = mappingFunction.Apply_O__O(key); tmp2 = newValue; if !(tmp2 == nil) {
			this.Put_O_O__O(key, newValue)
			return newValue } }
//line :139:1
	return v
}






func Map_ComputeIfPresent_O_BiFunction__O(this Map, key any, remappingFunction BiFunction) any {

	Objects_RequireNonNull_O__O(remappingFunction)
	var oldValue any; var tmp1 any
	oldValue = this.Get_O__O(key); tmp1 = oldValue; if !(tmp1 == nil) {
		var newValue any = remappingFunction.Apply_O_O__O(key, oldValue)
		if !(newValue == nil) { this.Put_O_O__O(key, newValue); return newValue } else { this.Remove_O__O(key); return nil } } else {
//line :151:1
			return nil
		}
}

func Map_Compute_O_BiFunction__O(this Map, key any, remappingFunction BiFunction) any {

	Objects_RequireNonNull_O__O(remappingFunction)
	var oldValue any = this.Get_O__O(key); var newValue any = remappingFunction.Apply_O_O__O(key, oldValue)

	if newValue == nil {
		var tmp1 bool; var tmp2 bool; tmp2 = !(oldValue == nil); if !tmp2 { tmp2 = this.ContainsKey_O__Z(key) }; tmp1 = tmp2; if tmp1 { this.Remove_O__O(key); return nil } else { return nil } } else {
			this.Put_O_O__O(key, newValue); return newValue
		} }
func Map_Merge_O_O_BiFunction__O(this Map, key, value any, remappingFunction BiFunction) any {

	Objects_RequireNonNull_O__O(remappingFunction)
	Objects_RequireNonNull_O__O(value)
	var oldValue any = this.Get_O__O(key); var newValue any
	if oldValue == nil { newValue = value } else { newValue = remappingFunction.Apply_O_O__O(oldValue, value) }
	if newValue == nil { this.Remove_O__O(key) } else { this.Put_O_O__O(key, newValue) }
//line :168:1
	return newValue
}



func Map_Of__Map() Map { ImmutableCollections_Init(); return Up_ImmutableCollections_MapN_Map(ImmutableCollections_EMPTY_MAP) }


func Map_Of_O_O__Map(k1, v1 any) Map {
	return ImmutableCollections_Map1_New_O_O(k1, v1)
}
func Map_Of_O_O_O_O__Map(k1, v1, k2, v2 any) Map {
	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2))
}
func Map_Of_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3 any) Map {
	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3))
}
func Map_Of_O_O_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3, k4, v4 any) Map {

	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3, k4, v4))
}
func Map_Of_O_O_O_O_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3, k4, v4, k5, v5 any) Map {

	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5))
}
func Map_Of_O_O_O_O_O_O_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6 any) Map {

	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6))
}
func Map_Of_O_O_O_O_O_O_O_O_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7 any) Map {


	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7))
}
func Map_Of_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7, k8, v8 any) Map {


	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7, k8, v8))
}
func Map_Of_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7, k8, v8, k9, v9 any) Map {


	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7, k8, v8, k9, v9))
}
func Map_Of_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__Map(k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7, k8, v8, k9, v9, k10, v10 any) Map {



	return ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5, k6, v6, k7, v7, k8, v8, k9, v9, k10, v10))
}
func Map_OfEntries_Map_Entry1__Map(entries *RefArray) Map {

	if int32(len(entries.A)) == 0 {
		var map_ *ImmutableCollections_MapN; ImmutableCollections_Init(); map_ = ImmutableCollections_EMPTY_MAP; return Up_ImmutableCollections_MapN_Map(map_) } else {
//line :220:1
			if int32(len(entries.A)) == 1 {


				return ImmutableCollections_Map1_New_O_O(As[Map_Entry](entries.A[0]).GetKey__O(), As[Map_Entry](entries.A[0]).GetValue__O()) } else {

					var kva *RefArray = NewRefArray(Object_class, int32(len(entries.A))<<1); var a int32 = 0; var arr_101972 *RefArray = entries; var len_101973 int32 = int32(len(arr_101972.A)); var i_101974 int32 = 0; for ; i_101974 < len_101973; i_101974++ {

						var entry Map_Entry = As[Map_Entry](arr_101972.A[i_101974])
						kva.Store(a, entry.GetKey__O())
						a = a + 1
						kva.Store(a, entry.GetValue__O())
						a = a + 1 }
					return ImmutableCollections_MapN_New_O1(kva)
				} } }
func Map_Entry_O_O__Map_Entry(k, v any) Map_Entry {
	return KeyValueHolder_New_O_O(k, v)
}
func Map_CopyOf_Map__Map(map_ Map) Map {
	if ImmutableCollections_AbstractImmutableMap_InstanceOf(map_) { return map_ } else { if map_.IsEmpty__Z() {

		return Map_Of__Map() } else {
			return Map_OfEntries_Map_Entry1__Map(A2g_CastArray[*RefArray](map_.EntrySet__Set().ToArray_O1__O1(NewRefArray(Map_Entry_class, 0)).Ref(), Map_Entry_class.ArrayClass()))
		} } }
func Map_OfLazy_Set_Function__Map(keys Set, computingFunction Function) Map {


	var keyCopies Set = Set_CopyOf_Collection__Set(keys)
	Objects_RequireNonNull_O__O(computingFunction)
	var tmp1 bool; var tmp2 bool; tmp2 = EnumSet_InstanceOf(keys); if tmp2 { tmp2 = !keyCopies.IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		var enumMap Map; enumMap = A2g_Missing[Map]("class java.util.LazyCollections is not in the closed world"); return enumMap } else {

			return A2g_Missing[Map]("class java.util.LazyCollections is not in the closed world")
		}
}

type Map interface{ Object_I; Is_Map(); Size__I() int32; IsEmpty__Z() bool; ContainsKey_O__Z(p0 any) bool; ContainsValue_O__Z(p0 any) bool; Get_O__O(p0 any) any; Put_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; PutAll_Map__V(p0 Map); Clear__V(); KeySet__Set() Set; Values__Collection() Collection; EntrySet__Set() Set; GetOrDefault_O_O__O(p0, p1 any) any; ForEach_BiConsumer__V(p0 BiConsumer); ReplaceAll_BiFunction__V(p0 BiFunction); PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any }

func Map_InstanceOf(x any) bool { _, ok := x.(Map); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Map_class) } }; return ok }

func Map_Cast(x any) Map { if x == nil { return nil }; v, ok := x.(Map); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Map_class) } }; if !ok { panic(ClassCast(x, Map_class)) }; return v }



type Map_Entry interface{ Object_I; Is_Map_Entry(); GetKey__O() any; GetValue__O() any; SetValue_O__O(p0 any) any }

func Map_Entry_InstanceOf(x any) bool { _, ok := x.(Map_Entry); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Map_Entry_class) } }; return ok }

func Map_Entry_Cast(x any) Map_Entry { if x == nil { return nil }; v, ok := x.(Map_Entry); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Map_Entry_class) } }; if !ok { panic(ClassCast(x, Map_Entry_class)) }; return v }
