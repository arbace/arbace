//line java_net_ContentHandler.ae:1
package jrt






func (t *ContentHandler) Ctor(this ContentHandler_I) {}



func (t *ContentHandler) Impl_GetContent_URLConnection_Class1__O(this ContentHandler_I, urlc URLConnection_I, classes *RefArray) any {
	var obj any = this.GetContent_URLConnection__O(urlc); var arr_101113 *RefArray = classes; var len_101114 int32 = int32(len(arr_101113.A)); var i_101115 int32 = 0; for ; i_101115 < len_101114; i_101115++ {
		var c *Class = As[*Class](arr_101113.A[i_101115]); if NN(c).IsInstance_O__Z(obj) { return obj } }
//line :13:1
	return nil
}



type ContentHandler struct{ Object }

type ContentHandler_I interface{ Object_I; Self_ContentHandler() *ContentHandler; GetContent_URLConnection__O(p0 URLConnection_I) any; GetContent_URLConnection_Class1__O(p0 URLConnection_I, p1 *RefArray) any }

func (t *ContentHandler) Self_ContentHandler() *ContentHandler { return t }

func ContentHandler_InstanceOf(x any) bool { _, ok := x.(ContentHandler_I); return ok }

func ContentHandler_Cast(x any) ContentHandler_I { if x == nil { return nil }; v, ok := x.(ContentHandler_I); if !ok { panic(ClassCast(x, ContentHandler_class)) }; return v }
