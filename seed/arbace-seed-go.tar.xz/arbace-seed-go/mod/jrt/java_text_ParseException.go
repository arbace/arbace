//line java_text_ParseException.ae:1
package jrt








func ParseException_New_String_I(p0 *String, p1 int32) *ParseException { t := &ParseException{}; t.Ctor_String_I(p0, p1); return t }
//line :10:1
func (t *ParseException) Ctor_String_I(s *String, errorOffset int32) { t.Exception.Ctor_String(t, s)

	t.F_errorOffset = errorOffset
}
func (t *ParseException) GetErrorOffset__I() int32 { return t.F_errorOffset }



type ParseException struct{ Exception; F_errorOffset int32 }

const ParseException_serialVersionUID int64 = 2703218443322787634

func (t *ParseException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ParseException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ParseException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ParseException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ParseException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ParseException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ParseException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ParseException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ParseException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ParseException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ParseException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ParseException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ParseException) Ref() any { if t == nil { return nil }; return t }

func (t *ParseException) GetClass__Class() *Class { return ParseException_class }

func (t *ParseException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ParseException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ParseException_InstanceOf(x any) bool { _, ok := x.(*ParseException); return ok }

func ParseException_Cast(x any) *ParseException { if x == nil { return nil }; v, ok := x.(*ParseException); if !ok { panic(ClassCast(x, ParseException_class)) }; return v }
