//line java_time_temporal_TemporalAccessor.ae:1
package jrt









func TemporalAccessor_Range_TemporalField__ValueRange(this TemporalAccessor, field TemporalField) *ValueRange {
	if ChronoField_InstanceOf(field) {
		if this.IsSupported_TemporalField__Z(field) { return field.Range__ValueRange() }
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	return field.RangeRefinedBy_TemporalAccessor__ValueRange(this)
}
func TemporalAccessor_Get_TemporalField__I(this TemporalAccessor, field TemporalField) int32 {
	var range_ *ValueRange = this.Range_TemporalField__ValueRange(field)
	if NN(range_).IsIntValue__Z() == false {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2513, StrOfObj(field), Lit_2514))))
	}
	var value int64 = this.GetLong_TemporalField__J(field)
	if NN(range_).IsValidValue_J__Z(value) == false {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2515, StrOfObj(field), Lit_2516, StrOfObj(range_.Ref()), Lit_2517, StrOfLong(value)))))
	}
	return int32(value)
}


func TemporalAccessor_Query_TemporalQuery__O(this TemporalAccessor, query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = query == TemporalQueries_ZoneId__TemporalQuery(); if !tmp3 {
		tmp3 = query == TemporalQueries_Chronology__TemporalQuery() }
//line :32:1
	tmp2 = tmp3; if !tmp2 {

		tmp2 = query == TemporalQueries_Precision__TemporalQuery() }
//line :32:1
	tmp1 = tmp2; if tmp1 { return nil } else {


		return query.QueryFrom_TemporalAccessor__O(this)
	} }
type TemporalAccessor interface{ Object_I; Is_TemporalAccessor(); IsSupported_TemporalField__Z(p0 TemporalField) bool; Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange; Get_TemporalField__I(p0 TemporalField) int32; GetLong_TemporalField__J(p0 TemporalField) int64; Query_TemporalQuery__O(p0 TemporalQuery) any }

func TemporalAccessor_InstanceOf(x any) bool { _, ok := x.(TemporalAccessor); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalAccessor_class) } }; return ok }

func TemporalAccessor_Cast(x any) TemporalAccessor { if x == nil { return nil }; v, ok := x.(TemporalAccessor); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalAccessor_class) } }; if !ok { panic(ClassCast(x, TemporalAccessor_class)) }; return v }
