//line java_util_IllegalFormatWidthException.ae:1
package jrt










func IllegalFormatWidthException_New_I(p0 int32) *IllegalFormatWidthException { t := &IllegalFormatWidthException{}; t.Ctor_I(p0); return t }
//line :12:1
func (t *IllegalFormatWidthException) Ctor_I(w int32) { t.IllegalFormatException.Ctor(t); t.F_w = w }

func (t *IllegalFormatWidthException) GetWidth__I() int32 { return t.F_w }

func (t *IllegalFormatWidthException) GetMessage__String() *String { return Integer_ToString_I__String(t.F_w) }





type IllegalFormatWidthException struct{ IllegalFormatException; F_w int32 }

const IllegalFormatWidthException_serialVersionUID int64 = 16660902

func (t *IllegalFormatWidthException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalFormatWidthException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalFormatWidthException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalFormatWidthException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalFormatWidthException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalFormatWidthException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalFormatWidthException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalFormatWidthException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalFormatWidthException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalFormatWidthException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalFormatWidthException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalFormatWidthException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalFormatWidthException) GetClass__Class() *Class { return IllegalFormatWidthException_class }

func (t *IllegalFormatWidthException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalFormatWidthException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalFormatWidthException_InstanceOf(x any) bool { _, ok := x.(*IllegalFormatWidthException); return ok }

func IllegalFormatWidthException_Cast(x any) *IllegalFormatWidthException { if x == nil { return nil }; v, ok := x.(*IllegalFormatWidthException); if !ok { panic(ClassCast(x, IllegalFormatWidthException_class)) }; return v }
