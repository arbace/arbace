//line java_util_Properties.ae:1
package jrt

import "sync/atomic"


































func Properties_New() *Properties { Properties_Init(); t := &Properties{}; t.Ctor(t); return t }
//line :38:1
func (t *Properties) Ctor(this Properties_I) { t.Ctor_Properties_I(this, nil, 8) }

func Properties_New_I(p0 int32) *Properties { Properties_Init(); t := &Properties{}; t.Ctor_I(t, p0); return t }
//line :40:1
func (t *Properties) Ctor_I(this Properties_I, initialCapacity int32) { t.Ctor_Properties_I(this, nil, initialCapacity) }


func Properties_New_Properties(p0 Properties_I) *Properties { Properties_Init(); t := &Properties{}; t.Ctor_Properties(t, p0); return t }
//line :43:1
func (t *Properties) Ctor_Properties(this, defaults Properties_I) { t.Ctor_Properties_I(this, defaults, 8) }

func Properties_New_Properties_I(p0 Properties_I, p1 int32) *Properties { Properties_Init(); t := &Properties{}; t.Ctor_Properties_I(t, p0, p1); return t }
//line :45:1
func (t *Properties) Ctor_Properties_I(this, defaults Properties_I, initialCapacity int32) { t.Hashtable.Ctor_Void(this, nil)

	t.F_map.Store(ConcurrentHashMap_New_I(initialCapacity))
	t.F_defaults.Store(defaults)
	NN(Properties_UNSAFE).StoreFence__V()
}
func (t *Properties) Impl_SetProperty_String_String__O(this Properties_I, key, value *String) any { MonitorEnter(this); defer MonitorExit(this)
	return this.Put_O_O__O(key.Ref(), value.Ref())
}
func (t *Properties) Impl_Load_Reader__V(this Properties_I, reader Reader_I) { MonitorEnter(this); defer MonitorExit(this)
	Objects_RequireNonNull_O_String__O(reader, Lit_2808)
	t.Impl_Load0_Properties_LineReader__V(this, Properties_LineReader_New_Reader(reader))
}
func (t *Properties) Impl_Load_InputStream__V(this Properties_I, inStream InputStream_I) { MonitorEnter(this); defer MonitorExit(this)
	Objects_RequireNonNull_O_String__O(inStream, Lit_2809)
	t.Impl_Load0_Properties_LineReader__V(this, Properties_LineReader_New_InputStream(inStream))
}
func (t *Properties) Impl_Load0_Properties_LineReader__V(this Properties_I, lr *Properties_LineReader) {
	var outBuffer *StringBuilder = StringBuilder_New()
	var limit int32 = 0
	var keyLen int32 = 0
	var valueStart int32 = 0
	var hasSep bool = false
	var precedingBackslash bool = false
L1: for { var tmp1 int32; limit = NN(lr).ReadLine__I(); tmp1 = limit; if tmp1 >= 0 {
	keyLen = 0
	valueStart = limit
	hasSep = false
	precedingBackslash = false
L2: for { if keyLen < limit {
	var c uint16 = lr.F_lineBuf.A[keyLen]; var tmp2 bool; var tmp3 bool; var tmp4 bool
	tmp4 = int32(c) == 61; if !tmp4 { tmp4 = int32(c) == 58 }; tmp3 = tmp4; if tmp3 { tmp3 = !precedingBackslash }; tmp2 = tmp3; if tmp2 {
		valueStart = keyLen + 1; hasSep = true; break L2 } else {
			var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = int32(c) == 32; if !tmp8 { tmp8 = int32(c) == 9 }; tmp7 = tmp8; if !tmp7 { tmp7 = int32(c) == 12 }; tmp6 = tmp7; if tmp6 {
				tmp6 = !precedingBackslash }
//line :78:1
			tmp5 = tmp6; if tmp5 {

				valueStart = keyLen + 1
				break L2 } }
	if int32(c) == 92 {
		precedingBackslash = !precedingBackslash } else {
			precedingBackslash = false }
	keyLen = keyLen + 1
//line :74:1
	continue L2 }; break L2
}










L3: for { if valueStart < limit {
	var c_2 uint16 = lr.F_lineBuf.A[valueStart]; var tmp9 bool; var tmp10 bool; var tmp11 bool
	tmp11 = !(int32(c_2) == 32); if tmp11 { tmp11 = !(int32(c_2) == 9) }; tmp10 = tmp11; if tmp10 { tmp10 = !(int32(c_2) == 12) }; tmp9 = tmp10; if tmp9 {
		var tmp12 bool; var tmp13 bool; tmp13 = !hasSep; if tmp13 { var tmp14 bool; tmp14 = int32(c_2) == 61; if !tmp14 { tmp14 = int32(c_2) == 58 }; tmp13 = tmp14 }; tmp12 = tmp13; if tmp12 { hasSep = true } else { break L3 } }
	valueStart = valueStart + 1
//line :86:1
	continue L3 }; break L3
}



	var key *String = t.Impl_LoadConvert_C1_I_I_StringBuilder__String(this, lr.F_lineBuf, 0, keyLen, outBuffer); var value *String = t.Impl_LoadConvert_C1_I_I_StringBuilder__String(this, lr.F_lineBuf, valueStart, limit-valueStart, outBuffer)





	this.Put_O_O__O(key.Ref(), value.Ref())
//line :69:1
	continue L1 }; break L1
}
}




























func Properties_LineReader_New_InputStream(p0 InputStream_I) *Properties_LineReader { t := &Properties_LineReader{}; t.Ctor_InputStream(p0); return t }
//line :100:1
func (t *Properties_LineReader) Ctor_InputStream(inStream InputStream_I) { t.F_lineBuf = NewCharArray(1024); t.F_inLimit = 0; t.F_inOff = 0
	t.F_inStream = inStream
	t.F_inByteBuf = NewByteArray(8192)
}
func Properties_LineReader_New_Reader(p0 Reader_I) *Properties_LineReader { t := &Properties_LineReader{}; t.Ctor_Reader(p0); return t }
//line :104:1
func (t *Properties_LineReader) Ctor_Reader(reader Reader_I) { t.F_lineBuf = NewCharArray(1024); t.F_inLimit = 0; t.F_inOff = 0
	t.F_reader = reader
	t.F_inCharBuf = NewCharArray(8192)
}














func (t *Properties_LineReader) ReadLine__I() int32 {
	{ var len_ int32 = 0; var off int32 = t.F_inOff; var limit int32 = t.F_inLimit; var skipWhiteSpace bool = true; var appendedLineBegin bool = false; var precedingBackslash bool = false; var fromStream bool = !(t.F_inStream == nil); var byteBuf *ByteArray = t.F_inByteBuf; var charBuf *CharArray = t.F_inCharBuf; var lineBuf *CharArray = t.F_lineBuf
		var c uint16 = 0









	L1: for {
		if off >= limit {
			var tmp1 int32; var tmp2 int32
			if fromStream { tmp2 = t.F_inStream.Read_B1__I(byteBuf) } else { tmp2 = t.F_reader.Read_C1__I(charBuf) }; limit = tmp2; tmp1 = limit
//line :136:1
			t.F_inLimit = tmp1

			if limit <= 0 {
				if len_ == 0 { return -1 }
				var tmp3 int32; if precedingBackslash { tmp3 = len_ - 1 } else { tmp3 = len_ }; return tmp3 }
			off = 0 }
		var tmp4 uint16
		if fromStream {
			var tmp5 int32
			var old_1 int32 = off
			off = off + 1; tmp5 = old_1
//line :144:1
			tmp4 = uint16(int32(byteBuf.A[tmp5]) & 255)
		} else {


			var tmp6 int32; var old_2 int32 = off; off = off + 1; tmp6 = old_2; tmp4 = charBuf.A[tmp6] }
//line :142:1
		c = tmp4






		if skipWhiteSpace {
			var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = int32(c) == 32; if !tmp9 { tmp9 = int32(c) == 9 }; tmp8 = tmp9; if !tmp8 { tmp8 = int32(c) == 12 }; tmp7 = tmp8; if tmp7 { continue L1 }
			var tmp10 bool; var tmp11 bool; tmp11 = !appendedLineBegin; if tmp11 { var tmp12 bool; tmp12 = int32(c) == 13; if !tmp12 { tmp12 = int32(c) == 10 }; tmp11 = tmp12 }; tmp10 = tmp11; if tmp10 { continue L1 }
			skipWhiteSpace = false
			appendedLineBegin = false }
		if len_ == 0 {
			var tmp13 bool; var tmp14 bool; tmp14 = int32(c) == 35; if !tmp14 { tmp14 = int32(c) == 33 }; tmp13 = tmp14; if tmp13 {
			L2: switch { default: L3: for {

				if fromStream {
					var b int8 = 0
				L4: for { if off < limit {
					b = byteBuf.A[off]
					off = off + 1
					var tmp15 bool; var tmp16 bool; tmp16 = int32(b) <= 13; if tmp16 { var tmp17 bool; tmp17 = int32(b) == 13; if !tmp17 { tmp17 = int32(b) == 10 }; tmp16 = tmp17 }; tmp15 = tmp16; if tmp15 {
						break L2 }
//line :160:1
					continue L4 }; break L4
				}



					if off == limit {
						var tmp18 int32; limit = t.F_inStream.Read_B1__I(byteBuf); tmp18 = limit; t.F_inLimit = tmp18
						if limit <= 0 { return -1 }
						off = 0 } } else {

						L5: for { if off < limit {
							c = charBuf.A[off]
							off = off + 1
							var tmp19 bool; var tmp20 bool; tmp20 = int32(c) <= 13; if tmp20 { var tmp21 bool; tmp21 = int32(c) == 13; if !tmp21 { tmp21 = int32(c) == 10 }; tmp20 = tmp21 }; tmp19 = tmp20; if tmp19 {
								break L2 }
//line :170:1
							continue L5 }; break L5
						}



							if off == limit {
								var tmp22 int32; limit = t.F_reader.Read_C1__I(charBuf); tmp22 = limit; t.F_inLimit = tmp22
								if limit <= 0 { return -1 }
								off = 0 } }
//line :156:1
				continue L3
			}
			}




















				skipWhiteSpace = true
				continue L1 } }
		var tmp23 bool; var tmp24 bool
		tmp24 = !(int32(c) == 10); if tmp24 { tmp24 = !(int32(c) == 13) }; tmp23 = tmp24
//line :181:1
		if tmp23 {


			lineBuf.A[len_] = c
			len_ = len_ + 1
			if len_ == int32(len(lineBuf.A)) {
				lineBuf = NewCharArray(ArraysSupport_NewLength_I_I_I__I(len_, 1, len_))
				System_Arraycopy_O_I_O_I_I__V(t.F_lineBuf.Ref(), 0, lineBuf.Ref(), 0, len_)
				t.F_lineBuf = lineBuf }
			var tmp25 bool; if int32(c) == 92 { tmp25 = !precedingBackslash } else { tmp25 = false }; precedingBackslash = tmp25 } else {
//line :181:1
				if len_ == 0 {









					skipWhiteSpace = true } else {


						if off >= limit {
							var tmp26 int32; var tmp27 int32

							if fromStream { tmp27 = t.F_inStream.Read_B1__I(byteBuf) } else { tmp27 = t.F_reader.Read_C1__I(charBuf) }; limit = tmp27; tmp26 = limit
//line :195:1
							t.F_inLimit = tmp26


							off = 0
							if limit <= 0 {
								var tmp28 int32; if precedingBackslash { tmp28 = len_ - 1 } else { tmp28 = len_ }; return tmp28 } }
						if precedingBackslash {

							len_ = len_ - 1
							skipWhiteSpace = true
							appendedLineBegin = true
							precedingBackslash = false
							if int32(c) == 13 {
								if fromStream {

									if int32(byteBuf.A[off]) == 10 {
										off = off + 1 } } else {
//line :208:1
											if int32(charBuf.A[off]) == 10 {



												off = off + 1 } } } } else {
													t.F_inOff = off; return len_ } } }
//line :134:1
		continue L1
	}
	}













































	panic("a2g: unreachable")
}































func (t *Properties) Impl_LoadConvert_C1_I_I_StringBuilder__String(this Properties_I, in *CharArray, off, len_ int32, out *StringBuilder) *String {

	var aChar uint16 = 0; var end int32 = off + len_
	var start int32 = off

L1: for { if off < end {
	aChar = in.A[off]
	off = off + 1
	if int32(aChar) == 92 { break L1 }
//line :220:1
	continue L1 }; break L1
}


	if off == end {
		return String_New_C1_I_I(in, start, len_) } else {

			NN(out).SetLength_I__V(0)
			off = off - 1
			NN(out).Append_C1_I_I__StringBuilder(in, start, off-start)
		L2: for { if off < end {
			aChar = in.A[off]
			off = off + 1
			if int32(aChar) == 92 {

				aChar = in.A[off]
				off = off + 1
				if int32(aChar) == 117 {

					if off > end-4 {
						panic(Thrown(IllegalArgumentException_New_String(Lit_2810))) }
					var value int32 = 0; var i int32 = 0
				L3: for {
					if i < 4 {
						aChar = in.A[off]
						off = off + 1
						var tmp1 int32
						switch int32(aChar) { case 48, 49, 50, 51, 52, 53, 54, 55, 56, 57:

							tmp1 = value<<4 + int32(aChar) - 48; case 97, 98, 99, 100, 101, 102:



							tmp1 = value<<4 + 10 + int32(aChar) - 97; case 65, 66, 67, 68, 69, 70:





							tmp1 = value<<4 + 10 + int32(aChar) - 65; default:




							panic(Thrown(IllegalArgumentException_New_String(Lit_2810)))}
//line :246:1
						value = tmp1



















						i = i + 1; continue L3 }
//line :242:1
					break L3
				}























					NN(out).Append_C__StringBuilder(uint16(value)) } else {

						if int32(aChar) == 116 {
							aChar = 9 } else {
//line :269:1
								if int32(aChar) == 114 {

									aChar = 13 } else {
//line :269:1
										if int32(aChar) == 110 {


											aChar = 10 } else {
//line :269:1
												if int32(aChar) == 102 {



													aChar = 12 } } } }
						NN(out).Append_C__StringBuilder(aChar) } } else {
							NN(out).Append_C__StringBuilder(aChar) }
//line :230:1
			continue L2 }; break L2
		}












































			return NN(out).ToString__String()
		} }
func (t *Properties) Impl_SaveConvert_String_Z_Z__String(this Properties_I, theString *String, escapeSpace, escapeUnicode bool) *String {

	var len_ int32 = NN(theString).Length__I(); var bufLen int32 = len_ * 2

	if bufLen < 0 { bufLen = 2147483647 }
	var outBuffer *StringBuilder = StringBuilder_New_I(bufLen); var hex *HexFormat = NN(HexFormat_Of__HexFormat()).WithUpperCase__HexFormat()
	var x int32 = 0
L1: for {
	if x < len_ {
		var aChar uint16 = NN(theString).CharAt_I__C(x); var tmp1 bool; var tmp2 bool
		tmp2 = int32(aChar) > 61; if tmp2 { tmp2 = int32(aChar) < 127 }; tmp1 = tmp2; if tmp1 {
			if int32(aChar) == 92 {

				NN(outBuffer).Append_C__StringBuilder(92)
				NN(outBuffer).Append_C__StringBuilder(92)
				x = x + 1; continue L1 } else {
					NN(outBuffer).Append_C__StringBuilder(aChar); x = x + 1; continue L1 } } else {
						switch int32(aChar) { case 32:


							var tmp6 bool; var tmp7 bool; tmp7 = x == 0; if !tmp7 { tmp7 = escapeSpace }; tmp6 = tmp7; if tmp6 { NN(outBuffer).Append_C__StringBuilder(92) }
							NN(outBuffer).Append_C__StringBuilder(32)
							x = x + 1; continue L1; case 9:


							NN(outBuffer).Append_C__StringBuilder(92)
							NN(outBuffer).Append_C__StringBuilder(116)
							x = x + 1; continue L1; case 10:


							NN(outBuffer).Append_C__StringBuilder(92)
							NN(outBuffer).Append_C__StringBuilder(110)
							x = x + 1; continue L1; case 13:


							NN(outBuffer).Append_C__StringBuilder(92)
							NN(outBuffer).Append_C__StringBuilder(114)
							x = x + 1; continue L1; case 12:


							NN(outBuffer).Append_C__StringBuilder(92)
							NN(outBuffer).Append_C__StringBuilder(102)
							x = x + 1; continue L1; case 61, 58, 35, 33:


							NN(outBuffer).Append_C__StringBuilder(92)
							NN(outBuffer).Append_C__StringBuilder(aChar)
							x = x + 1; continue L1; default:
							var tmp3 bool; var a_3 bool; var tmp4 bool; tmp4 = int32(aChar) < 32; if !tmp4 { tmp4 = int32(aChar) > 126 }; a_3 = tmp4; var b_4 bool = escapeUnicode; var tmp5 bool

							tmp5 = a_3; if tmp5 { tmp5 = b_4 }; tmp3 = tmp5
//line :326:1
							if tmp3 {



								NN(outBuffer).Append_String__StringBuilder(Lit_2811)
								NN(outBuffer).Append_String__StringBuilder(NN(hex).ToHexDigits_C__String(aChar))
								x = x + 1; continue L1 } else {
									NN(outBuffer).Append_C__StringBuilder(aChar); x = x + 1; continue L1 }} } }
//line :285:1
	break L1
}















































	return NN(outBuffer).ToString__String()
}
func Properties_WriteComments_BufferedWriter_String__V(bw BufferedWriter_I, comments *String) { Properties_Init()

	var hex *HexFormat = NN(HexFormat_Of__HexFormat()).WithUpperCase__HexFormat()
	bw.Write_String__V(Lit_1132)
	var len_ int32 = NN(comments).Length__I()
	var current int32 = 0
	var last int32 = 0
L1: for { if current < len_ {
	var c uint16 = NN(comments).CharAt_I__C(current); var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = int32(c) > 255; if !tmp3 { tmp3 = int32(c) == 10 }; tmp2 = tmp3; if !tmp2 { tmp2 = int32(c) == 13 }; tmp1 = tmp2; if tmp1 {
		if last == current { } else { bw.Write_String__V(NN(comments).Substring_I_I__String(last, current)) }
		if int32(c) > 255 {
			bw.Write_String__V(Lit_2811); bw.Write_String__V(NN(hex).ToHexDigits_C__String(c)) } else {

				bw.NewLine__V()
				var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = int32(c) == 13; if tmp6 {
					tmp6 = !(current == len_-1) }
//line :351:1
				tmp5 = tmp6; if tmp5 {

					tmp5 = int32(NN(comments).CharAt_I__C(current+1)) == 10 }
//line :351:1
				tmp4 = tmp5; if tmp4 {


					current = current + 1 }
				var tmp7 bool; var tmp8 bool; tmp8 = current == len_-1; if !tmp8 {
					var tmp9 bool; tmp9 = !(int32(NN(comments).CharAt_I__C(current+1)) == 35); if tmp9 {
						tmp9 = !(int32(NN(comments).CharAt_I__C(current+1)) == 33) }
//line :356:1
					tmp8 = tmp9 }
//line :355:1
				tmp7 = tmp8; if tmp7 {


					bw.Write_String__V(Lit_1132) } }
		last = current + 1 }
	current = current + 1
//line :343:1
	continue L1 }; break L1
}
















	if last == current { } else { bw.Write_String__V(NN(comments).Substring_I_I__String(last, current)) }
	bw.NewLine__V()
}
func (t *Properties) Impl_Save_OutputStream_String__V(this Properties_I, out OutputStream_I, comments *String) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
														this.Store_OutputStream_String__V(out, comments); return nil }(); if tmp1 != nil { if IOException_InstanceOf(tmp1) { var e IOException_I = IOException_Cast(tmp1); _ = e } else { panic(tmp1) } } }

func (t *Properties) Impl_Store_Writer_String__V(this Properties_I, writer Writer_I, comments *String) {
	var tmp1 BufferedWriter_I
	if BufferedWriter_InstanceOf(writer) {
		tmp1 = BufferedWriter_Cast(writer) } else {
			tmp1 = BufferedWriter_New_Writer(writer) }
//line :368:1
	t.Impl_Store0_BufferedWriter_String_Z__V(this, tmp1, comments, false)
}





func (t *Properties) Impl_Store_OutputStream_String__V(this Properties_I, out OutputStream_I, comments *String) {
	t.Impl_Store0_BufferedWriter_String_Z__V(this, BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_Charset(out, Up_ISO_8859_1_Charset(ISO_8859_1_INSTANCE))), comments, true)
}
func (t *Properties) Impl_Store0_BufferedWriter_String_Z__V(this Properties_I, bw BufferedWriter_I, comments *String, escUnicode bool) {

	if !(comments == nil) { Properties_WriteComments_BufferedWriter_String__V(bw, comments) }
	Properties_WriteDateComment_BufferedWriter__V(bw)
	var tmp1 any = this; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		var entries Collection = this.EntrySet__Set(); var tmp2 Collection = entries
		if Collections_SynchronizedSet_InstanceOf(tmp2) { var ss Collections_SynchronizedSet_I = Collections_SynchronizedSet_Cast(tmp2)
			if Properties_EntrySet_InstanceOf(ss.Self_Collections_SynchronizedCollection().F_c) {
				entries = ArrayList_New_Collection(entries)
				List_Cast(entries).Sort_Comparator__V(Map_Entry_ComparingByKey__Comparator()) } } else { }
		var i_101987 Iterator = entries.Iterator__Iterator(); for i_101987.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101987.Next__O()); var key *String = String_Cast(e.GetKey__O()); var val *String = String_Cast(e.GetValue__O())


			key = t.Impl_SaveConvert_String_Z_Z__String(this, key, true, escUnicode)
			val = t.Impl_SaveConvert_String_Z_Z__String(this, val, false, escUnicode)
			bw.Write_String__V(Concat(key, Lit_1171, val))
			bw.NewLine__V() } }()
	bw.Flush__V()
}
func Properties_WriteDateComment_BufferedWriter__V(bw BufferedWriter_I) { Properties_Init()
	var sysPropVal *String = StaticProperty_JavaPropertiesDate__String(); var tmp1 bool; var tmp2 bool
	tmp2 = !(sysPropVal == nil); if tmp2 { tmp2 = !NN(sysPropVal).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		Properties_WriteComments_BufferedWriter_String__V(bw, sysPropVal) } else {
			bw.Write_String__V(Concat(Lit_1132, StrOfObj(Date_New()))); bw.NewLine__V()
		} }
func (t *Properties) Impl_LoadFromXML_InputStream__V(this Properties_I, in InputStream_I) { MonitorEnter(this); defer MonitorExit(this)

	Objects_RequireNonNull_O__O(in)
	var handler any; _ = handler; handler = A2g_Missing[any]("class jdk.internal.util.xml.PropertiesDefaultHandler is not in the closed world"); A2g_Missing[bool]("class jdk.internal.util.xml.PropertiesDefaultHandler is not in the closed world"); in.Close__V()
}
func (t *Properties) Impl_StoreToXML_OutputStream_String__V(this Properties_I, os OutputStream_I, comment *String) {
	this.StoreToXML_OutputStream_String_Charset__V(os, comment, Up_UTF_8_Charset(UTF_8_INSTANCE))
}
func (t *Properties) Impl_StoreToXML_OutputStream_String_String__V(this Properties_I, os OutputStream_I, comment, encoding *String) {

	Objects_RequireNonNull_O__O(os)
	Objects_RequireNonNull_O__O(encoding.Ref()); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var charset Charset_I = Charset_ForName_String__Charset(encoding); this.StoreToXML_OutputStream_String_Charset__V(os, comment, charset) }; return nil }()
//line :415:1
	if tmp1 != nil { if IllegalCharsetNameException_InstanceOf(tmp1) || UnsupportedCharsetException_InstanceOf(tmp1) { var e IllegalArgumentException_I = IllegalArgumentException_Cast(tmp1); _ = e


		panic(Thrown(UnsupportedEncodingException_New_String(encoding))) } else {
//line :415:1
			panic(tmp1)
		}
	}
}

func (t *Properties) Impl_StoreToXML_OutputStream_String_Charset__V(this Properties_I, os OutputStream_I, comment *String, charset Charset_I) {

	Objects_RequireNonNull_O_String__O(os, Lit_2812)
	Objects_RequireNonNull_O_String__O(charset, Lit_1463)
	var handler any; _ = handler; handler = A2g_Missing[any]("class jdk.internal.util.xml.PropertiesDefaultHandler is not in the closed world"); A2g_Missing[bool]("class jdk.internal.util.xml.PropertiesDefaultHandler is not in the closed world")
}
func (t *Properties) Impl_GetProperty_String__String(this Properties_I, key *String) *String {
	var oval any = NN(t.F_map.Load()).Get_O__O(key.Ref()); var sval *String
	if String_InstanceOf(oval) { sval = String_Cast(oval) } else { sval = nil }
//line :427:1
	var defaults Properties_I; var tmp1 bool; var tmp2 bool


	tmp2 = sval == nil; if tmp2 { var tmp3 Properties_I; defaults = t.F_defaults.Load(); tmp3 = defaults; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		return defaults.GetProperty_String__String(key) } else {
//line :430:1
			return sval
		}
}

func (t *Properties) Impl_GetProperty_String_String__String(this Properties_I, key, defaultValue *String) *String {
	var val *String = this.GetProperty_String__String(key); if val == nil { return defaultValue } else { return val
	} }
func (t *Properties) Impl_PropertyNames__Enumeration(this Properties_I) Enumeration {
	var h Hashtable_I = Hashtable_New(); t.Impl_Enumerate_Map__V(this, h); return h.Keys__Enumeration()
}
func (t *Properties) Impl_StringPropertyNames__Set(this Properties_I) Set {
	var h Map = HashMap_New()
	t.Impl_EnumerateStringProperties_Map__V(this, h)
	return Collections_UnmodifiableSet_Set__Set(h.KeySet__Set())
}
func (t *Properties) Impl_List_PrintStream__V(this Properties_I, out *PrintStream) {
	NN(out).Println_String__V(Lit_2813)
	var h Map = HashMap_New()
	t.Impl_Enumerate_Map__V(this, h)
	var i_101988 Iterator = h.EntrySet__Set().Iterator__Iterator(); for i_101988.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101988.Next__O()); var key *String = String_Cast(e.GetKey__O()); var val *String = String_Cast(e.GetValue__O())


		if NN(val).Length__I() > 40 { val = Concat(NN(val).Substring_I_I__String(0, 37), Lit_2240) }
		NN(out).Println_String__V(Concat(key, Lit_1171, val))
	} }
func (t *Properties) Impl_List_PrintWriter__V(this Properties_I, out *PrintWriter) {
	NN(out).Println_String__V(Lit_2813)
	var h Map = HashMap_New()
	t.Impl_Enumerate_Map__V(this, h)
	var i_101989 Iterator = h.EntrySet__Set().Iterator__Iterator(); for i_101989.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101989.Next__O()); var key *String = String_Cast(e.GetKey__O()); var val *String = String_Cast(e.GetValue__O())


		if NN(val).Length__I() > 40 { val = Concat(NN(val).Substring_I_I__String(0, 37), Lit_2240) }
		NN(out).Println_String__V(Concat(key, Lit_1171, val))
	} }
func (t *Properties) Impl_Enumerate_Map__V(this Properties_I, h Map) {
	if !(t.F_defaults.Load() == nil) { var tmp1 Properties_I = t.F_defaults.Load(); tmp1.Self_Properties().Impl_Enumerate_Map__V(tmp1, h) }
	var i_101990 Iterator = this.EntrySet__Set().Iterator__Iterator(); for i_101990.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101990.Next__O()); var key *String = String_Cast(e.GetKey__O())
		h.Put_O_O__O(key.Ref(), e.GetValue__O())
	} }
func (t *Properties) Impl_EnumerateStringProperties_Map__V(this Properties_I, h Map) {
	if !(t.F_defaults.Load() == nil) { var tmp1 Properties_I = t.F_defaults.Load(); tmp1.Self_Properties().Impl_EnumerateStringProperties_Map__V(tmp1, h) }
	var i_101991 Iterator = this.EntrySet__Set().Iterator__Iterator(); for i_101991.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101991.Next__O()); var k any = e.GetKey__O(); var v any = e.GetValue__O(); var tmp2 bool; var tmp3 bool


		tmp3 = String_InstanceOf(k); if tmp3 { tmp3 = String_InstanceOf(v) }; tmp2 = tmp3; if tmp2 {
			h.Put_O_O__O(String_Cast(k).Ref(), String_Cast(v).Ref())
		} } }
func (t *Properties) Impl_Size__I(this Properties_I) int32 { return NN(t.F_map.Load()).Size__I() }

func (t *Properties) Impl_IsEmpty__Z(this Properties_I) bool { return NN(t.F_map.Load()).IsEmpty__Z() }

func (t *Properties) Impl_Keys__Enumeration(this Properties_I) Enumeration {
	return Collections_Enumeration_Collection__Enumeration(Up_ConcurrentHashMap_KeySetView_Collection(NN(t.F_map.Load()).KeySet__ConcurrentHashMap_KeySetView()))
}
func (t *Properties) Impl_Elements__Enumeration(this Properties_I) Enumeration {
	return Collections_Enumeration_Collection__Enumeration(NN(t.F_map.Load()).Values__Collection())
}
func (t *Properties) Impl_Contains_O__Z(this Properties_I, value any) bool { return NN(t.F_map.Load()).Contains_O__Z(value) }

func (t *Properties) Impl_ContainsValue_O__Z(this Properties_I, value any) bool {
	return NN(t.F_map.Load()).ContainsValue_O__Z(value)
}
func (t *Properties) Impl_ContainsKey_O__Z(this Properties_I, key any) bool { return NN(t.F_map.Load()).ContainsKey_O__Z(key) }

func (t *Properties) Impl_Get_O__O(this Properties_I, key any) any { return NN(t.F_map.Load()).Get_O__O(key) }

func (t *Properties) Impl_Put_O_O__O(this Properties_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	return NN(t.F_map.Load()).Put_O_O__O(key, value)
}
func (t *Properties) Impl_Remove_O__O(this Properties_I, key any) any { MonitorEnter(this); defer MonitorExit(this); return NN(t.F_map.Load()).Remove_O__O(key) }

func (t *Properties) Impl_PutAll_Map__V(this Properties_I, t_ Map) { MonitorEnter(this); defer MonitorExit(this)
	NN(t.F_map.Load()).PutAll_Map__V(t_)
}
func (t *Properties) Impl_Clear__V(this Properties_I) { MonitorEnter(this); defer MonitorExit(this); NN(t.F_map.Load()).Clear__V() }

func (t *Properties) Impl_ToString__String(this Properties_I) *String { MonitorEnter(this); defer MonitorExit(this); return NN(t.F_map.Load()).ToString__String() }

func (t *Properties) Impl_KeySet__Set(this Properties_I) Set {
	return Collections_SynchronizedSet_Set_O__Set(Up_ConcurrentHashMap_KeySetView_Set(NN(t.F_map.Load()).KeySet__ConcurrentHashMap_KeySetView()), this)
}
func (t *Properties) Impl_Values__Collection(this Properties_I) Collection {
	return Collections_SynchronizedCollection_Collection_O__Collection(NN(t.F_map.Load()).Values__Collection(), this)
}
func (t *Properties) Impl_EntrySet__Set(this Properties_I) Set {
	return Collections_SynchronizedSet_Set_O__Set(Properties_EntrySet_New_Set(NN(t.F_map.Load()).EntrySet__Set()), this)
}





func Properties_EntrySet_New_Set(p0 Set) *Properties_EntrySet { t := &Properties_EntrySet{}; t.Ctor_Set(p0); return t }
//line :523:1
func (t *Properties_EntrySet) Ctor_Set(entrySet Set) {
	t.F_entrySet = entrySet
}
func (t *Properties_EntrySet) Size__I() int32 { return t.F_entrySet.Size__I() }

func (t *Properties_EntrySet) IsEmpty__Z() bool { return t.F_entrySet.IsEmpty__Z() }

func (t *Properties_EntrySet) Contains_O__Z(o any) bool { return t.F_entrySet.Contains_O__Z(o) }

func (t *Properties_EntrySet) ToArray__O1() *RefArray { return t.F_entrySet.ToArray__O1() }

func (t *Properties_EntrySet) ToArray_O1__O1(a *RefArray) *RefArray {
	return t.F_entrySet.ToArray_O1__O1(a)
}
func (t *Properties_EntrySet) Clear__V() { t.F_entrySet.Clear__V() }

func (t *Properties_EntrySet) Remove_O__Z(o any) bool { return t.F_entrySet.Remove_O__Z(o) }

func (t *Properties_EntrySet) Add_Map_Entry__Z(e Map_Entry) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Properties_EntrySet) AddAll_Collection__Z(c Collection) bool {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Properties_EntrySet) ContainsAll_Collection__Z(c Collection) bool {
	return t.F_entrySet.ContainsAll_Collection__Z(c)
}
func (t *Properties_EntrySet) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(t); if !tmp1 { tmp1 = t.F_entrySet.Equals_O__Z(o) }; return tmp1
}
func (t *Properties_EntrySet) HashCode__I() int32 { return t.F_entrySet.HashCode__I() }

func (t *Properties_EntrySet) ToString__String() *String { return t.F_entrySet.ToString__String() }

func (t *Properties_EntrySet) RemoveAll_Collection__Z(c Collection) bool {
	return t.F_entrySet.RemoveAll_Collection__Z(c)
}
func (t *Properties_EntrySet) RetainAll_Collection__Z(c Collection) bool {
	return t.F_entrySet.RetainAll_Collection__Z(c)
}
func (t *Properties_EntrySet) Iterator__Iterator() Iterator {
	return t.F_entrySet.Iterator__Iterator()
}
func (t *Properties) Impl_Equals_O__Z(this Properties_I, o any) bool { MonitorEnter(this); defer MonitorExit(this)
	return NN(t.F_map.Load()).Equals_O__Z(o)
}
func (t *Properties) Impl_HashCode__I(this Properties_I) int32 { MonitorEnter(this); defer MonitorExit(this); return NN(t.F_map.Load()).HashCode__I() }

func (t *Properties) Impl_GetOrDefault_O_O__O(this Properties_I, key, defaultValue any) any {
	return NN(t.F_map.Load()).GetOrDefault_O_O__O(key, defaultValue)
}
func (t *Properties) Impl_ForEach_BiConsumer__V(this Properties_I, action BiConsumer) { MonitorEnter(this); defer MonitorExit(this)

	NN(t.F_map.Load()).ForEach_BiConsumer__V(action)
}
func (t *Properties) Impl_ReplaceAll_BiFunction__V(this Properties_I, function BiFunction) { MonitorEnter(this); defer MonitorExit(this)

	NN(t.F_map.Load()).ReplaceAll_BiFunction__V(function)
}
func (t *Properties) Impl_PutIfAbsent_O_O__O(this Properties_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	return NN(t.F_map.Load()).PutIfAbsent_O_O__O(key, value)
}
func (t *Properties) Impl_Remove_O_O__Z(this Properties_I, key, value any) bool { MonitorEnter(this); defer MonitorExit(this)
	return NN(t.F_map.Load()).Remove_O_O__Z(key, value)
}
func (t *Properties) Impl_Replace_O_O_O__Z(this Properties_I, key, oldValue, newValue any) bool { MonitorEnter(this); defer MonitorExit(this)
	return NN(t.F_map.Load()).Replace_O_O_O__Z(key, oldValue, newValue)
}
func (t *Properties) Impl_Replace_O_O__O(this Properties_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	return NN(t.F_map.Load()).Replace_O_O__O(key, value)
}
func (t *Properties) Impl_ComputeIfAbsent_O_Function__O(this Properties_I, key any, mappingFunction Function) any { MonitorEnter(this); defer MonitorExit(this)

	return NN(t.F_map.Load()).ComputeIfAbsent_O_Function__O(key, mappingFunction)
}
func (t *Properties) Impl_ComputeIfPresent_O_BiFunction__O(this Properties_I, key any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	return NN(t.F_map.Load()).ComputeIfPresent_O_BiFunction__O(key, remappingFunction)
}
func (t *Properties) Impl_Compute_O_BiFunction__O(this Properties_I, key any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	return NN(t.F_map.Load()).Compute_O_BiFunction__O(key, remappingFunction)
}
func (t *Properties) Impl_Merge_O_O_BiFunction__O(this Properties_I, key, value any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	return NN(t.F_map.Load()).Merge_O_O_BiFunction__O(key, value, remappingFunction)
}
func (t *Properties) Impl_Rehash__V(this Properties_I) {}

func (t *Properties) Impl_Clone__O(this Properties_I) any { MonitorEnter(this); defer MonitorExit(this)
	var clone Properties_I = Properties_Cast(this.CloneHashtable__Hashtable())
	clone.Self_Properties().F_map.Store(ConcurrentHashMap_New_Map(Up_ConcurrentHashMap_Map(t.F_map.Load())))
//line :614:1
	return clone
}



type Properties struct{ Hashtable; F_defaults Volatile[Properties_I]; F_map atomic.Pointer[ConcurrentHashMap] }

type Properties_I interface{ Hashtable_I; Map; Cloneable; Serializable; Self_Properties() *Properties; SetProperty_String_String__O(p0, p1 *String) any; Load_Reader__V(p0 Reader_I); Load_InputStream__V(p0 InputStream_I); Save_OutputStream_String__V(p0 OutputStream_I, p1 *String); Store_Writer_String__V(p0 Writer_I, p1 *String); Store_OutputStream_String__V(p0 OutputStream_I, p1 *String); LoadFromXML_InputStream__V(p0 InputStream_I); StoreToXML_OutputStream_String__V(p0 OutputStream_I, p1 *String); StoreToXML_OutputStream_String_String__V(p0 OutputStream_I, p1, p2 *String); StoreToXML_OutputStream_String_Charset__V(p0 OutputStream_I, p1 *String, p2 Charset_I); GetProperty_String__String(p0 *String) *String; GetProperty_String_String__String(p0, p1 *String) *String; PropertyNames__Enumeration() Enumeration; StringPropertyNames__Set() Set; List_PrintStream__V(p0 *PrintStream); List_PrintWriter__V(p0 *PrintWriter); Size__I() int32; IsEmpty__Z() bool; Keys__Enumeration() Enumeration; Elements__Enumeration() Enumeration; Contains_O__Z(p0 any) bool; ContainsValue_O__Z(p0 any) bool; ContainsKey_O__Z(p0 any) bool; Get_O__O(p0 any) any; Put_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; PutAll_Map__V(p0 Map); Clear__V(); KeySet__Set() Set; Values__Collection() Collection; EntrySet__Set() Set; GetOrDefault_O_O__O(p0, p1 any) any; ForEach_BiConsumer__V(p0 BiConsumer); ReplaceAll_BiFunction__V(p0 BiFunction); PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any; Rehash__V() }

func (t *Properties) Self_Properties() *Properties { return t }

const Properties_serialVersionUID int64 = 4112578634029874840

var Properties_UNSAFE *Unsafe

var Properties_init ClassInit

func Properties_Init() { if !Properties_init.Done() { Properties_init.Run(Properties_clinit) } }

func Properties_clinit() { Properties_UNSAFE = Unsafe_GetUnsafe__Unsafe() }

func (t *Properties) LoadFromXML_InputStream__V(p0 InputStream_I) { t.Impl_LoadFromXML_InputStream__V(t, p0) }

func (t *Properties) PropertyNames__Enumeration() Enumeration { return t.Impl_PropertyNames__Enumeration(t) }

func (t *Properties) Rehash__V() { t.Impl_Rehash__V(t) }

func (t *Properties) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Properties) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Properties) CloneHashtable__Hashtable() Hashtable_I { return t.Impl_CloneHashtable__Hashtable(t) }

func (t *Properties) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Properties) Clear__V() { t.Impl_Clear__V(t) }

func (t *Properties) Load_InputStream__V(p0 InputStream_I) { t.Impl_Load_InputStream__V(t, p0) }

func (t *Properties) SetProperty_String_String__O(p0, p1 *String) any { return t.Impl_SetProperty_String_String__O(t, p0, p1) }

func (t *Properties) StoreToXML_OutputStream_String_Charset__V(p0 OutputStream_I, p1 *String, p2 Charset_I) { t.Impl_StoreToXML_OutputStream_String_Charset__V(t, p0, p1, p2) }

func (t *Properties) Keys__Enumeration() Enumeration { return t.Impl_Keys__Enumeration(t) }

func (t *Properties) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Properties) StoreToXML_OutputStream_String_String__V(p0 OutputStream_I, p1, p2 *String) { t.Impl_StoreToXML_OutputStream_String_String__V(t, p0, p1, p2) }

func (t *Properties) GetProperty_String__String(p0 *String) *String { return t.Impl_GetProperty_String__String(t, p0) }

func (t *Properties) StringPropertyNames__Set() Set { return t.Impl_StringPropertyNames__Set(t) }

func (t *Properties) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Properties) Save_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_Save_OutputStream_String__V(t, p0, p1) }

func (t *Properties) StoreToXML_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_StoreToXML_OutputStream_String__V(t, p0, p1) }

func (t *Properties) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Properties) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Properties) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Properties) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Properties) Store_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_Store_OutputStream_String__V(t, p0, p1) }

func (t *Properties) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Properties) GetProperty_String_String__String(p0, p1 *String) *String { return t.Impl_GetProperty_String_String__String(t, p0, p1) }

func (t *Properties) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Properties) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Properties) Load_Reader__V(p0 Reader_I) { t.Impl_Load_Reader__V(t, p0) }

func (t *Properties) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Properties) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Properties) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Properties) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Properties) List_PrintStream__V(p0 *PrintStream) { t.Impl_List_PrintStream__V(t, p0) }

func (t *Properties) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Properties) Store_Writer_String__V(p0 Writer_I, p1 *String) { t.Impl_Store_Writer_String__V(t, p0, p1) }

func (t *Properties) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Properties) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Properties) List_PrintWriter__V(p0 *PrintWriter) { t.Impl_List_PrintWriter__V(t, p0) }

func (t *Properties) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Properties) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Properties) Elements__Enumeration() Enumeration { return t.Impl_Elements__Enumeration(t) }

func (t *Properties) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Properties) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Properties) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Properties) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Properties) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Properties) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Properties) Ref() any { if t == nil { return nil }; return t }

func (t *Properties) GetClass__Class() *Class { return Properties_class }

func (t *Properties) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func Properties_InstanceOf(x any) bool { _, ok := x.(Properties_I); return ok }

func Properties_Cast(x any) Properties_I { if x == nil { return nil }; v, ok := x.(Properties_I); if !ok { panic(ClassCast(x, Properties_class)) }; return v }



type Properties_EntrySet struct{ Object; F_entrySet Set }

func (t *Properties_EntrySet) Is_Set() {}

func (t *Properties_EntrySet) Is_Collection() {}

func (t *Properties_EntrySet) Is_Iterable() {}

func (t *Properties_EntrySet) Add_O__Z(p0 any) bool { return t.Add_Map_Entry__Z(Map_Entry_Cast(p0)) }

func (t *Properties_EntrySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *Properties_EntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *Properties_EntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Properties_EntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Properties_EntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Properties_EntrySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *Properties_EntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *Properties_EntrySet) GetClass__Class() *Class { return Properties_EntrySet_class }

func (t *Properties_EntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Properties_EntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Properties_EntrySet_InstanceOf(x any) bool { _, ok := x.(*Properties_EntrySet); return ok }

func Properties_EntrySet_Cast(x any) *Properties_EntrySet { if x == nil { return nil }; v, ok := x.(*Properties_EntrySet); if !ok { panic(ClassCast(x, Properties_EntrySet_class)) }; return v }



type Properties_LineReader struct{ Object; F_lineBuf *CharArray; F_inByteBuf *ByteArray; F_inCharBuf *CharArray; F_inLimit, F_inOff int32; F_inStream InputStream_I; F_reader Reader_I }

func (t *Properties_LineReader) Ref() any { if t == nil { return nil }; return t }

func (t *Properties_LineReader) GetClass__Class() *Class { return Properties_LineReader_class }

func (t *Properties_LineReader) ToString__String() *String { return Object_toString(t) }

func (t *Properties_LineReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Properties_LineReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func Properties_LineReader_InstanceOf(x any) bool { _, ok := x.(*Properties_LineReader); return ok }

func Properties_LineReader_Cast(x any) *Properties_LineReader { if x == nil { return nil }; v, ok := x.(*Properties_LineReader); if !ok { panic(ClassCast(x, Properties_LineReader_class)) }; return v }
