//line java_math_MutableBigInteger.ae:1
package jrt


















func MutableBigInteger_New() *MutableBigInteger { MutableBigInteger_Init(); t := &MutableBigInteger{}; t.Ctor(t); return t }
//line :20:1
func (t *MutableBigInteger) Ctor(this MutableBigInteger_I) { t.F_offset = 0; t.F_value = NewIntArray(1); t.F_intLen = 0 }

func MutableBigInteger_New_I(p0 int32) *MutableBigInteger { MutableBigInteger_Init(); t := &MutableBigInteger{}; t.Ctor_I(t, p0); return t }
//line :22:1
func (t *MutableBigInteger) Ctor_I(this MutableBigInteger_I, val int32) { t.F_offset = 0; t.Impl_Init_I__V(this, val) }

func MutableBigInteger_New_J(p0 int64) *MutableBigInteger { MutableBigInteger_Init(); t := &MutableBigInteger{}; t.Ctor_J(t, p0); return t }
//line :24:1
func (t *MutableBigInteger) Ctor_J(this MutableBigInteger_I, val int64) { t.F_offset = 0
	var hi int32 = int32(int64(uint64(val) >> 32))
	if hi == 0 {
		t.Impl_Init_I__V(this, int32(val)) } else {
			t.F_value = IntArrayOf(hi, int32(val)); t.F_intLen = 2
		} }
func (t *MutableBigInteger) Impl_Init_I__V(this MutableBigInteger_I, val int32) {
	t.F_value = IntArrayOf(val)
	var tmp1 int32; if !(val == 0) { tmp1 = 1 } else { tmp1 = 0 }; t.F_intLen = tmp1
}
func MutableBigInteger_New_I1(p0 *IntArray) *MutableBigInteger { MutableBigInteger_Init(); t := &MutableBigInteger{}; t.Ctor_I1(t, p0); return t }
//line :34:1
func (t *MutableBigInteger) Ctor_I1(this MutableBigInteger_I, val *IntArray) { t.F_offset = 0
	t.F_value = val
	t.F_intLen = int32(len(val.A))
}
func MutableBigInteger_New_BigInteger(p0 *BigInteger) *MutableBigInteger { MutableBigInteger_Init(); t := &MutableBigInteger{}; t.Ctor_BigInteger(t, p0); return t }
//line :38:1
func (t *MutableBigInteger) Ctor_BigInteger(this MutableBigInteger_I, b *BigInteger) { t.F_offset = 0
	t.F_intLen = int32(len(b.F_mag.A))
	t.F_value = Arrays_CopyOf_I1_I__I1(b.F_mag, t.F_intLen)
}
func MutableBigInteger_New_MutableBigInteger(p0 MutableBigInteger_I) *MutableBigInteger { MutableBigInteger_Init(); t := &MutableBigInteger{}; t.Ctor_MutableBigInteger(t, p0); return t }
//line :42:1
func (t *MutableBigInteger) Ctor_MutableBigInteger(this, val MutableBigInteger_I) { t.F_offset = 0
	t.F_intLen = val.Self_MutableBigInteger().F_intLen
	var tmp1 *IntArray = val.Self_MutableBigInteger().F_value; var tmp2 int32 = val.Self_MutableBigInteger().F_offset; t.F_value = Arrays_CopyOfRange_I1_I_I__I1(tmp1, tmp2, val.Self_MutableBigInteger().F_offset+t.F_intLen)
}



func (t *MutableBigInteger) Impl_Ones_I__V(this MutableBigInteger_I, n int32) {
	if n > int32(len(t.F_value.A)) { t.F_value = NewIntArray(n) }
	Arrays_Fill_I1_I__V(t.F_value, -1)
	t.F_offset = 0
	t.F_intLen = n
}
func (t *MutableBigInteger) Impl_GetMagnitudeArray__I1(this MutableBigInteger_I) *IntArray {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_offset > 0; if !tmp2 { tmp2 = !(int32(len(t.F_value.A)) == t.F_intLen) }; tmp1 = tmp2; if tmp1 {
		var tmp *IntArray = Arrays_CopyOfRange_I1_I_I__I1(t.F_value, t.F_offset, t.F_offset+t.F_intLen)
		Arrays_Fill_I1_I__V(t.F_value, 0)
		t.F_offset = 0
		t.F_intLen = int32(len(tmp.A))
		t.F_value = tmp }
//line :55:1
	return t.F_value
}







func (t *MutableBigInteger) Impl_ToLong__J(this MutableBigInteger_I) int64 {
	if !A2g_AssertionsDisabled && !(t.F_intLen <= 2) { panic(Thrown(AssertionError_New_O(Lit_1287))) }
	if t.F_intLen == 0 { return 0 } else {

		var d int64 = int64(t.F_value.A[t.F_offset]) & 4294967295
		if t.F_intLen == 2 {
			return d<<32 | int64(t.F_value.A[t.F_offset+1])&4294967295 } else {
//line :69:1
				return d
			}
	}
}

func (t *MutableBigInteger) Impl_ToBigInteger_I__BigInteger(this MutableBigInteger_I, sign int32) *BigInteger {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_intLen == 0; if !tmp2 { tmp2 = sign == 0 }; tmp1 = tmp2; if tmp1 { BigInteger_Init(); return BigInteger_ZERO } else { return BigInteger_New_I1_I(t.Impl_GetMagnitudeArray__I1(this), sign)
	} }
func (t *MutableBigInteger) Impl_ToBigInteger__BigInteger(this MutableBigInteger_I) *BigInteger {
	this.Normalize__V()
	var tmp1 int32; if this.IsZero__Z() { tmp1 = 0 } else { tmp1 = 1 }; return this.ToBigInteger_I__BigInteger(tmp1)
}
func (t *MutableBigInteger) Impl_ToBigDecimal_I_I__BigDecimal(this MutableBigInteger_I, sign, scale int32) *BigDecimal {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_intLen == 0; if !tmp2 { tmp2 = sign == 0 }; tmp1 = tmp2; if tmp1 {
		return BigDecimal_ZeroValueOf_I__BigDecimal(scale) } else {
			var mag *IntArray = t.Impl_GetMagnitudeArray__I1(this); var len_ int32 = int32(len(mag.A)); var d int32 = mag.A[0]; var tmp3 bool; var tmp4 bool


			tmp4 = len_ > 2; if !tmp4 { var tmp5 bool; tmp5 = d < 0; if tmp5 { tmp5 = len_ == 2 }; tmp4 = tmp5 }; tmp3 = tmp4; if tmp3 {
				return BigDecimal_New_BigInteger_J_I_I(BigInteger_New_I1_I(mag, sign), -9223372036854775808, scale, 0) } else {
					var v int64; if len_ == 2 {
						v = int64(mag.A[1])&4294967295 | int64(d)&4294967295<<32 } else {

							v = int64(d) & 4294967295 }
					var tmp6 int64; if sign == -1 { tmp6 = -v } else { tmp6 = v }; return BigDecimal_ValueOf_J_I__BigDecimal(tmp6, scale)
				} } }
func (t *MutableBigInteger) Impl_ToCompactValue_I__J(this MutableBigInteger_I, sign int32) int64 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_intLen == 0; if !tmp2 { tmp2 = sign == 0 }; tmp1 = tmp2; if tmp1 { return 0 } else {

		var mag *IntArray = t.Impl_GetMagnitudeArray__I1(this); var len_ int32 = int32(len(mag.A)); var d int32 = mag.A[0]; var tmp3 bool; var tmp4 bool


		tmp4 = len_ > 2; if !tmp4 { var tmp5 bool; tmp5 = d < 0; if tmp5 { tmp5 = len_ == 2 }; tmp4 = tmp5 }; tmp3 = tmp4; if tmp3 { return -9223372036854775808 } else {

			var v int64; if len_ == 2 {
				v = int64(mag.A[1])&4294967295 | int64(d)&4294967295<<32 } else {

					v = int64(d) & 4294967295 }
			if sign == -1 { return -v } else { return v
			} } } }
func (t *MutableBigInteger) Impl_Clear__V(this MutableBigInteger_I) {
	var tmp1 int32; var tmp2 int32 = 0; t.F_intLen = tmp2; tmp1 = tmp2; t.F_offset = tmp1
	var index int32 = 0; var n int32 = int32(len(t.F_value.A)); L1: for {

		if index < n { t.F_value.A[index] = 0; index, n = index+1, n; continue L1 }
//line :111:1
		break L1
	}
}

func (t *MutableBigInteger) Impl_Reset__V(this MutableBigInteger_I) { var tmp1 int32; var tmp2 int32 = 0; t.F_intLen = tmp2; tmp1 = tmp2; t.F_offset = tmp1 }

func (t *MutableBigInteger) Impl_Compare_MutableBigInteger__I(this, b MutableBigInteger_I) int32 {
	var blen int32 = b.Self_MutableBigInteger().F_intLen
	if t.F_intLen < blen { return -1 } else { if t.F_intLen > blen { return 1 } else {



		var bval *IntArray = b.Self_MutableBigInteger().F_value; var i int32 = t.F_offset; var j int32 = b.Self_MutableBigInteger().F_offset
	L1: for {

		if i < t.F_intLen+t.F_offset {
			var b1 int32 = t.F_value.A[i] + -2147483648; var b2 int32 = bval.A[j] + -2147483648

			if b1 < b2 { return -1 }
			if b1 > b2 { return 1 } else { i, j = i+1, j+1; continue L1 } }
//line :124:1
		break L1 }
//line :123:1
		return 0
	}
	}
}






func (t *MutableBigInteger) Impl_CompareShifted_MutableBigInteger_I__I(this, b MutableBigInteger_I, ints int32) int32 {
	var blen int32 = b.Self_MutableBigInteger().F_intLen; var alen int32 = t.F_intLen - ints

	if alen < blen { return -1 } else { if alen > blen { return 1 } else {



		var bval *IntArray = b.Self_MutableBigInteger().F_value; var i int32 = t.F_offset; var j int32 = b.Self_MutableBigInteger().F_offset
	L1: for {

		if i < alen+t.F_offset {
			var b1 int32 = t.F_value.A[i] + -2147483648; var b2 int32 = bval.A[j] + -2147483648

			if b1 < b2 { return -1 }
			if b1 > b2 { return 1 } else { i, j = i+1, j+1; continue L1 } }
//line :141:1
		break L1 }
//line :140:1
		return 0
	}
	}
}






func (t *MutableBigInteger) Impl_CompareHalf_MutableBigInteger__I(this, b MutableBigInteger_I) int32 {
	var blen int32 = b.Self_MutableBigInteger().F_intLen; var len_ int32 = t.F_intLen

	if len_ <= 0 {
		if blen <= 0 { return 0 } else { return -1 } } else {
//line :153:1
			if len_ > blen { return 1 } else { if len_ < blen-1 { return -1 } else {




				var bval *IntArray = b.Self_MutableBigInteger().F_value
				var bstart int32 = 0
				var carry int32 = 0
				if len_ == blen { } else {
					if bval.A[bstart] == 1 {

						bstart = bstart + 1
						carry = -2147483648 } else {
							return -1 } }
				var val *IntArray = t.F_value; var i int32 = t.F_offset
				var j int32 = bstart

			L1: for { if i < len_+t.F_offset {
				var bv int32; var tmp1 int32; var old_1 int32 = j; j = j + 1; tmp1 = old_1; bv = bval.A[tmp1]; var hb int64 = int64(int32(uint32(bv)>>1)+carry) & 4294967295; var v int64; var tmp2 int32
				var old_2 int32 = i

				i = i + 1; tmp2 = old_2; v = int64(val.A[tmp2]) & 4294967295

				if v == hb { } else { var tmp3 int32; if v < hb { tmp3 = -1 } else { tmp3 = 1 }; return tmp3 }
				carry = bv & 1 << 31
//line :170:1
				continue L1 }; break L1
			}






				if carry == 0 { return 0 } else { return -1
				} } } } }
func (t *MutableBigInteger) Impl_GetLowestSetBit__I(this MutableBigInteger_I) int32 {
	if t.F_intLen == 0 { return -1 } else {

		var j int32 = 0
		var b int32 = 0
		j = t.F_intLen - 1
	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = j > 0; if tmp2 { tmp2 = t.F_value.A[j+t.F_offset] == 0 }; tmp1 = tmp2; if tmp1 {
		j = j - 1
//line :186:1
		continue L1 }; break L1
	}
		b = t.F_value.A[j+t.F_offset]
		if b == 0 { return -1 } else {

			var tmp3 int32 = (t.F_intLen - 1 - j) << 5; return tmp3 + Integer_NumberOfTrailingZeros_I__I(b)
		}
	}
}
func (t *MutableBigInteger) Impl_GetInt_I__I(this MutableBigInteger_I, p0 int32) int32 { panic(A2g_NotTranslated("java.math.MutableBigInteger.getInt(I)I")) }


func (t *MutableBigInteger) Impl_GetLong_I__J(this MutableBigInteger_I, p0 int32) int64 { panic(A2g_NotTranslated("java.math.MutableBigInteger.getLong(I)J")) }


func (t *MutableBigInteger) Impl_Normalize__V(this MutableBigInteger_I) {
	if t.F_intLen == 0 {
		t.F_offset = 0 } else {
			var index int32 = t.F_offset
			if !(t.F_value.A[index] == 0) { } else {
				var indexBound int32 = index + t.F_intLen
			L1: for {
				index = index + 1
				var tmp1 bool; var tmp2 bool; tmp2 = index < indexBound; if tmp2 { tmp2 = t.F_value.A[index] == 0 }; tmp1 = tmp2; if tmp1 { continue L1 }
//line :207:1
				break L1
			}

				var numZeros int32 = index - t.F_offset
				t.F_intLen = t.F_intLen - numZeros
				var tmp3 int32; if t.F_intLen == 0 { tmp3 = 0 } else { tmp3 = t.F_offset + numZeros }; t.F_offset = tmp3
			} } }
func (t *MutableBigInteger) Impl_EnsureCapacity_I__V(this MutableBigInteger_I, p0 int32) { panic(A2g_NotTranslated("java.math.MutableBigInteger.ensureCapacity(I)V")) }


func (t *MutableBigInteger) Impl_ToIntArray__I1(this MutableBigInteger_I) *IntArray {
	var result *IntArray = NewIntArray(t.F_intLen); var i int32 = 0
L1: for {
	if i < t.F_intLen {
		result.A[i] = t.F_value.A[t.F_offset+i]
		i = i + 1; continue L1 }
//line :219:1
	break L1 }
//line :218:1
	return result
}





func (t *MutableBigInteger) Impl_SetInt_I_I__V(this MutableBigInteger_I, p0, p1 int32) { panic(A2g_NotTranslated("java.math.MutableBigInteger.setInt(II)V")) }


func (t *MutableBigInteger) Impl_SetValue_I1_I__V(this MutableBigInteger_I, p0 *IntArray, p1 int32) { panic(A2g_NotTranslated("java.math.MutableBigInteger.setValue([II)V")) }




func (t *MutableBigInteger) Impl_CopyValue_MutableBigInteger__V(this, src MutableBigInteger_I) {
	var len_ int32 = src.Self_MutableBigInteger().F_intLen
	if int32(len(t.F_value.A)) < len_ { t.F_value = NewIntArray(len_) }
	var tmp1 any = src.Self_MutableBigInteger().F_value.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, src.Self_MutableBigInteger().F_offset, t.F_value.Ref(), 0, len_)
	t.F_intLen = len_
	t.F_offset = 0
}
func (t *MutableBigInteger) Impl_CopyValue_I1__V(this MutableBigInteger_I, p0 *IntArray) { panic(A2g_NotTranslated("java.math.MutableBigInteger.copyValue([I)V")) }






func (t *MutableBigInteger) Impl_IsOne__Z(this MutableBigInteger_I) bool {
	var tmp1 bool; tmp1 = t.F_intLen == 1; if tmp1 { tmp1 = t.F_value.A[t.F_offset] == 1 }; return tmp1
}
func (t *MutableBigInteger) Impl_IsZero__Z(this MutableBigInteger_I) bool { return t.F_intLen == 0 }

func (t *MutableBigInteger) Impl_IsEven__Z(this MutableBigInteger_I) bool {
	var tmp1 bool; tmp1 = t.F_intLen == 0; if !tmp1 {
		tmp1 = t.F_value.A[t.F_offset+t.F_intLen-1]&1 == 0 }
//line :253:1
	return tmp1
}



func (t *MutableBigInteger) Impl_IsOdd__Z(this MutableBigInteger_I) bool {
	if this.IsZero__Z() { return false } else {

		return t.F_value.A[t.F_offset+t.F_intLen-1]&1 == 1
	}
}

func (t *MutableBigInteger) Impl_IsNormal__Z(this MutableBigInteger_I) bool { panic(A2g_NotTranslated("java.math.MutableBigInteger.isNormal()Z")) }





func (t *MutableBigInteger) Impl_ToString__String(this MutableBigInteger_I) *String {
	var b *BigInteger = this.ToBigInteger_I__BigInteger(1); return NN(b).ToString__String()
}
func (t *MutableBigInteger) Impl_SafeRightShift_I__V(this MutableBigInteger_I, n int32) {
	if n/32 >= t.F_intLen { this.Reset__V() } else { this.RightShift_I__V(n)
	} }
func (t *MutableBigInteger) Impl_RightShift_I__V(this MutableBigInteger_I, n int32) {
	if t.F_intLen == 0 { } else {
		var nInts int32 = int32(uint32(n) >> 5); var nBits int32 = n & 31

		t.F_intLen = t.F_intLen - nInts
		if nBits == 0 { } else {
			var bitsInHighWord int32 = BigInteger_BitLengthForInt_I__I(t.F_value.A[t.F_offset])
			if nBits >= bitsInHighWord {

				t.Impl_PrimitiveLeftShift_I__V(this, 32-nBits)
				t.F_intLen = t.F_intLen - 1 } else {
					t.Impl_PrimitiveRightShift_I__V(this, nBits)
				} } } }
func (t *MutableBigInteger) Impl_SafeLeftShift_I__V(this MutableBigInteger_I, n int32) {
	if n > 0 { this.LeftShift_I__V(n)
	} }
func (t *MutableBigInteger) Impl_LeftShift_I__V(this MutableBigInteger_I, n int32) {
	if t.F_intLen == 0 { } else {
		var nInts int32 = int32(uint32(n) >> 5); var nBits int32 = n & 31; var leadingZeros int32 = Integer_NumberOfLeadingZeros_I__I(t.F_value.A[t.F_offset])


		if n <= leadingZeros {
			t.Impl_PrimitiveLeftShift_I__V(this, nBits) } else {
				var newLen int32 = t.F_intLen + nInts
				if nBits > leadingZeros { newLen = newLen + 1 }
				var result *IntArray
				var newOffset int32 = 0
				if int32(len(t.F_value.A)) < newLen {
					result = NewIntArray(newLen); newOffset = 0 } else {

						result = t.F_value
						var tmp1 int32
						if int32(len(t.F_value.A))-t.F_offset >= newLen { tmp1 = t.F_offset } else { tmp1 = 0 }
//line :308:1
						newOffset = tmp1
					}


				var trailingZerosPos int32 = newOffset + t.F_intLen
				if !(nBits == 0) {

					if nBits <= leadingZeros {
						t.Impl_PrimitiveLeftShift_I_I1_I__V(this, nBits, result, newOffset) } else {
							var lastInt int32 = t.F_value.A[t.F_offset+t.F_intLen-1]



							t.Impl_PrimitiveRightShift_I_I1_I__V(this, 32-nBits, result, newOffset)




							result.A[trailingZerosPos] = lastInt << (nBits & 31)
							trailingZerosPos = trailingZerosPos + 1 } } else {
//line :313:1
								var tmp2 bool; var tmp3 bool














								tmp3 = !(result == t.F_value); if !tmp3 { tmp3 = !(newOffset == t.F_offset) }; tmp2 = tmp3
//line :313:1
								if tmp2 {















									System_Arraycopy_O_I_O_I_I__V(t.F_value.Ref(), t.F_offset, result.Ref(), newOffset, t.F_intLen) } }
				if result == t.F_value {
					Arrays_Fill_I1_I_I_I__V(result, trailingZerosPos, newOffset+newLen, 0) }
				t.F_value = result
				t.F_intLen = newLen
				t.F_offset = newOffset
			} } }
func (t *MutableBigInteger) Impl_Divadd_I1_I1_I__I(this MutableBigInteger_I, a, result *IntArray, offset int32) int32 {
	var carry int64 = 0; var j int32 = int32(len(a.A)) - 1
L1: for {
	if j >= 0 {
		var tmp1 int64 = int64(a.A[j]) & 4294967295; var sum int64 = tmp1 + int64(result.A[j+offset])&4294967295 + carry




		result.A[j+offset] = int32(sum)
		carry = int64(uint64(sum) >> 32)
		j = j - 1; continue L1 }
//line :338:1
	break L1
}








	return int32(carry)
}
func (t *MutableBigInteger) Impl_Mulsub_I1_I1_I_I_I__I(this MutableBigInteger_I, q, a *IntArray, x, len_, offset int32) int32 {
	var xLong int64 = int64(x) & 4294967295
	var carry int64 = 0
	offset = offset + len_
	var j int32 = len_ - 1; L1: for {
		if j >= 0 {
			var product int64 = int64(a.A[j])&4294967295*xLong + carry; var difference int64 = int64(q.A[offset]) - product



			q.A[offset] = int32(difference)
			offset = offset - 1
			var tmp1 int64 = int64(uint64(product) >> 32); var tmp2 int32

			if difference&4294967295 > int64(^int32(product))&4294967295 { tmp2 = 1 } else { tmp2 = 0 }
//line :362:1
			carry = tmp1 + int64(tmp2)







			j = j - 1; continue L1 }
//line :354:1
		break L1
	}















	return int32(carry)
}
func (t *MutableBigInteger) Impl_MulsubBorrow_I1_I1_I_I_I__I(this MutableBigInteger_I, q, a *IntArray, x, len_, offset int32) int32 {
	var xLong int64 = int64(x) & 4294967295
	var carry int64 = 0
	offset = offset + len_
	var j int32 = len_ - 1; L1: for {
		if j >= 0 {
			var product int64 = int64(a.A[j])&4294967295*xLong + carry; var difference int64; var tmp1 int32
			var old_3 int32 = offset




			offset = offset - 1
//line :384:1
			tmp1 = old_3
//line :382:1
			difference = int64(q.A[tmp1]) - product





			var tmp2 int64 = int64(uint64(product) >> 32); var tmp3 int32

			if difference&4294967295 > int64(^int32(product))&4294967295 { tmp3 = 1 } else { tmp3 = 0 }
//line :388:1
			carry = tmp2 + int64(tmp3)







			j = j - 1; continue L1 }
//line :377:1
		break L1
	}


















	return int32(carry)
}
func (t *MutableBigInteger) Impl_PrimitiveRightShift_I__V(this MutableBigInteger_I, n int32) {
	t.Impl_PrimitiveRightShift_I_I1_I__V(this, n, t.F_value, t.F_offset)
}
func (t *MutableBigInteger) Impl_PrimitiveRightShift_I_I1_I__V(this MutableBigInteger_I, n int32, result *IntArray, resFrom int32) {
	var val *IntArray = t.F_value; var n2 int32 = 32 - n; var b int32 = val.A[t.F_offset]


	result.A[resFrom] = int32(uint32(b) >> (n & 31))
	var i int32 = 1; L1: for {
		if i < t.F_intLen {
			var c int32 = b
			b = val.A[t.F_offset+i]
			result.A[resFrom+i] = c<<(n2&31) | int32(uint32(b)>>(n&31))


			i = i + 1; continue L1 }
//line :407:1
		break L1
	}
}






func (t *MutableBigInteger) Impl_PrimitiveLeftShift_I__V(this MutableBigInteger_I, n int32) {
	t.Impl_PrimitiveLeftShift_I_I1_I__V(this, n, t.F_value, t.F_offset)
}
func (t *MutableBigInteger) Impl_PrimitiveLeftShift_I_I1_I__V(this MutableBigInteger_I, n int32, result *IntArray, resFrom int32) {
	var val *IntArray = t.F_value; var n2 int32 = 32 - n; var m int32 = t.F_intLen - 1; var b int32 = val.A[t.F_offset]
	var i int32 = 0


L1: for {
	if i < m {
		var c int32 = val.A[t.F_offset+i+1]
		result.A[resFrom+i] = b<<(n&31) | int32(uint32(c)>>(n2&31))


		b = c
		i = i + 1; continue L1 }
//line :424:1
	break L1
}






	result.A[resFrom+m] = b << (n & 31)
}
func (t *MutableBigInteger) Impl_GetLower_I__BigInteger(this MutableBigInteger_I, n int32) *BigInteger {
	if this.IsZero__Z() { BigInteger_Init(); return BigInteger_ZERO } else { if t.F_intLen < n {

		return this.ToBigInteger_I__BigInteger(1) } else {

			var len_ int32 = n
		L1: for { var tmp1 bool; var tmp2 bool; tmp2 = len_ > 0; if tmp2 {
			tmp2 = t.F_value.A[t.F_offset+t.F_intLen-len_] == 0 }
//line :440:1
			tmp1 = tmp2; if tmp1 {



				len_ = len_ - 1
//line :440:1
				continue L1 }; break L1
		}



			var sign int32; if len_ > 0 { sign = 1 } else { sign = 0 }
			return BigInteger_New_I1_I(Arrays_CopyOfRange_I1_I_I__I1(t.F_value, t.F_offset+t.F_intLen-len_, t.F_offset+t.F_intLen), sign)
		}
	}
}



func (t *MutableBigInteger) Impl_KeepLower_I__V(this MutableBigInteger_I, n int32) {
	if t.F_intLen >= n {
		t.F_offset = t.F_offset + (t.F_intLen - n)
		t.F_intLen = n
	} }
func (t *MutableBigInteger) Impl_Add_MutableBigInteger__V(this, addend MutableBigInteger_I) {
	var x int32 = t.F_intLen; var y int32 = addend.Self_MutableBigInteger().F_intLen; var resultLen int32; var tmp1 int32 = t.F_intLen

	if tmp1 > addend.Self_MutableBigInteger().F_intLen { resultLen = t.F_intLen } else { resultLen = addend.Self_MutableBigInteger().F_intLen }
//line :459:1
	var result *IntArray


	if int32(len(t.F_value.A)) < resultLen { result = NewIntArray(resultLen) } else { result = t.F_value }
//line :459:1
	var rstart int32 = int32(len(result.A)) - 1
	var sum int64 = 0
	var carry int64 = 0




L1: for { var tmp2 bool; var tmp3 bool; tmp3 = x > 0; if tmp3 { tmp3 = y > 0 }; tmp2 = tmp3; if tmp2 {
	x = x - 1
	y = y - 1
	var tmp4 int64 = int64(t.F_value.A[x+t.F_offset]) & 4294967295; var tmp5 *IntArray = addend.Self_MutableBigInteger().F_value; sum = tmp4 + int64(tmp5.A[y+addend.Self_MutableBigInteger().F_offset])&4294967295 + carry






	result.A[rstart] = int32(sum)
	rstart = rstart - 1
	carry = int64(uint64(sum) >> 32)
//line :466:1
	continue L1 }; break L1
}











L2: for { if x > 0 {
	x = x - 1
	var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = carry == 0; if tmp8 { tmp8 = result == t.F_value }; tmp7 = tmp8; if tmp7 {
		tmp7 = rstart == x+t.F_offset }
//line :481:1
	tmp6 = tmp7; if tmp6 {

		return }
	sum = int64(t.F_value.A[x+t.F_offset])&4294967295 + carry



	result.A[rstart] = int32(sum)
	rstart = rstart - 1
	carry = int64(uint64(sum) >> 32)
//line :479:1
	continue L2 }; break L2
}










L3: for { if y > 0 {
	y = y - 1
	var tmp9 *IntArray = addend.Self_MutableBigInteger().F_value; sum = int64(tmp9.A[y+addend.Self_MutableBigInteger().F_offset])&4294967295 + carry




	result.A[rstart] = int32(sum)
	rstart = rstart - 1
	carry = int64(uint64(sum) >> 32)
//line :491:1
	continue L3 }; break L3
}








	if carry > 0 {
		resultLen = resultLen + 1
		if int32(len(result.A)) < resultLen {
			var temp *IntArray = NewIntArray(resultLen)
			System_Arraycopy_O_I_O_I_I__V(result.Ref(), 0, temp.Ref(), 1, int32(len(result.A)))
			temp.A[0] = 1
			result = temp } else {
				result.A[rstart] = 1; rstart = rstart - 1 } }
	t.F_value = result
	t.F_intLen = resultLen
	t.F_offset = int32(len(result.A)) - resultLen
}
func (t *MutableBigInteger) Impl_AddShifted_MutableBigInteger_I__V(this, addend MutableBigInteger_I, n int32) {
	if addend.IsZero__Z() { } else {
		var x int32 = t.F_intLen; var y int32 = addend.Self_MutableBigInteger().F_intLen + n; var resultLen int32

		if t.F_intLen > y { resultLen = t.F_intLen } else { resultLen = y }
//line :515:1
		var result *IntArray


		if int32(len(t.F_value.A)) < resultLen { result = NewIntArray(resultLen) } else { result = t.F_value }
//line :515:1
		var rstart int32 = int32(len(result.A)) - 1
		var sum int64 = 0
		var carry int64 = 0




	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = x > 0; if tmp2 { tmp2 = y > 0 }; tmp1 = tmp2; if tmp1 {
		x = x - 1
		y = y - 1
		var bval int32; var tmp3 int32 = y + addend.Self_MutableBigInteger().F_offset; if tmp3 < int32(len(addend.Self_MutableBigInteger().F_value.A)) {
			var tmp4 *IntArray = addend.Self_MutableBigInteger().F_value; bval = tmp4.A[y+addend.Self_MutableBigInteger().F_offset] } else {
//line :525:1
				bval = 0
			}

		sum = int64(t.F_value.A[x+t.F_offset])&4294967295 + int64(bval)&4294967295 + carry





		result.A[rstart] = int32(sum)
		rstart = rstart - 1
		carry = int64(uint64(sum) >> 32)
//line :522:1
		continue L1 }; break L1
	}













	L2: for { if x > 0 {
		x = x - 1
		var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = carry == 0; if tmp7 { tmp7 = result == t.F_value }; tmp6 = tmp7; if tmp6 {
			tmp6 = rstart == x+t.F_offset }
//line :539:1
		tmp5 = tmp6; if tmp5 {

			return }
		sum = int64(t.F_value.A[x+t.F_offset])&4294967295 + carry



		result.A[rstart] = int32(sum)
		rstart = rstart - 1
		carry = int64(uint64(sum) >> 32)
//line :537:1
		continue L2 }; break L2
	}










	L3: for { if y > 0 {
		y = y - 1
		var bval_2 int32; var tmp8 int32 = y + addend.Self_MutableBigInteger().F_offset; if tmp8 < int32(len(addend.Self_MutableBigInteger().F_value.A)) {
			var tmp9 *IntArray = addend.Self_MutableBigInteger().F_value; bval_2 = tmp9.A[y+addend.Self_MutableBigInteger().F_offset] } else {
//line :551:1
				bval_2 = 0
			}

		sum = int64(bval_2)&4294967295 + carry
		result.A[rstart] = int32(sum)
		rstart = rstart - 1
		carry = int64(uint64(sum) >> 32)
//line :549:1
		continue L3 }; break L3
	}







		if carry > 0 {
			resultLen = resultLen + 1
			if int32(len(result.A)) < resultLen {
				var temp *IntArray = NewIntArray(resultLen)
				System_Arraycopy_O_I_O_I_I__V(result.Ref(), 0, temp.Ref(), 1, int32(len(result.A)))
				temp.A[0] = 1
				result = temp } else {
					result.A[rstart] = 1; rstart = rstart - 1 } }
		t.F_value = result
		t.F_intLen = resultLen
		t.F_offset = int32(len(result.A)) - resultLen
	} }
func (t *MutableBigInteger) Impl_AddDisjoint_MutableBigInteger_I__V(this, addend MutableBigInteger_I, n int32) {
	if addend.IsZero__Z() { } else {
		var x int32 = t.F_intLen; var y int32 = addend.Self_MutableBigInteger().F_intLen + n; var resultLen int32

		if t.F_intLen > y { resultLen = t.F_intLen } else { resultLen = y }
//line :572:1
		var result *IntArray



		if int32(len(t.F_value.A)) < resultLen {
			result = NewIntArray(resultLen) } else {

				result = t.F_value
				var tmp1 *IntArray = t.F_value; var tmp2 int32 = t.F_offset + t.F_intLen; Arrays_Fill_I1_I_I_I__V(tmp1, tmp2, int32(len(t.F_value.A)), 0) }
		var rstart int32 = int32(len(result.A)) - 1
		System_Arraycopy_O_I_O_I_I__V(t.F_value.Ref(), t.F_offset, result.Ref(), rstart+1-x, x)




		y = y - x
		rstart = rstart - x
		var tmp3 int32 = int32(len(addend.Self_MutableBigInteger().F_value.A)); var len_ int32 = Math_Min_I_I__I(y, tmp3-addend.Self_MutableBigInteger().F_offset); var tmp4 any = addend.Self_MutableBigInteger().F_value.Ref()

		System_Arraycopy_O_I_O_I_I__V(tmp4, addend.Self_MutableBigInteger().F_offset, result.Ref(), rstart+1-y, len_)




		var i int32 = rstart + 1 - y + len_; L1: for {

			if i < rstart+1 {
				result.A[i] = 0
				i = i + 1; continue L1 }
//line :596:1
			break L1
		}



		t.F_value = result
		t.F_intLen = resultLen
		t.F_offset = int32(len(result.A)) - resultLen
	} }
func (t *MutableBigInteger) Impl_AddLower_MutableBigInteger_I__V(this, addend MutableBigInteger_I, n int32) {
	var a MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(addend); var tmp1 int32 = a.Self_MutableBigInteger().F_offset
	if tmp1+a.Self_MutableBigInteger().F_intLen >= n {
		var tmp2 int32 = a.Self_MutableBigInteger().F_offset; a.Self_MutableBigInteger().F_offset = tmp2 + a.Self_MutableBigInteger().F_intLen - n
		a.Self_MutableBigInteger().F_intLen = n }
	a.Normalize__V()
	this.Add_MutableBigInteger__V(a)
}
func (t *MutableBigInteger) Impl_ShiftAdd_MutableBigInteger_I__V(this, addend MutableBigInteger_I, n int32) {
	if addend.Self_MutableBigInteger().F_intLen <= n {
		this.ShiftAddDisjoint_MutableBigInteger_I__V(addend, n) } else {
//line :614:1
			if t.F_intLen == 0 {

				this.CopyValue_MutableBigInteger__V(addend) } else {
					this.LeftShift_I__V(n << 5); this.Add_MutableBigInteger__V(addend)
				} } }
func (t *MutableBigInteger) Impl_ShiftAddDisjoint_MutableBigInteger_I__V(this, addend MutableBigInteger_I, n int32) {
	if t.F_intLen == 0 {
		this.CopyValue_MutableBigInteger__V(addend) } else {
			var res *IntArray; var resLen int32 = t.F_intLen + n
			var resOffset int32 = 0

			if resLen > int32(len(t.F_value.A)) {

				res = NewIntArray(resLen)
				System_Arraycopy_O_I_O_I_I__V(t.F_value.Ref(), t.F_offset, res.Ref(), 0, t.F_intLen)
				resOffset = 0 } else {

					res = t.F_value
					var tmp1 int32 = t.F_offset + resLen; if tmp1 > int32(len(t.F_value.A)) {
						System_Arraycopy_O_I_O_I_I__V(t.F_value.Ref(), t.F_offset, res.Ref(), 0, t.F_intLen); resOffset = 0 } else {
							resOffset = t.F_offset }
					if addend.Self_MutableBigInteger().F_intLen < n {
						var tmp2 *IntArray = res; var tmp3 int32 = resOffset + t.F_intLen; Arrays_Fill_I1_I_I_I__V(tmp2, tmp3, resOffset+resLen-addend.Self_MutableBigInteger().F_intLen, 0)
					}
				}



			var tmp4 any = addend.Self_MutableBigInteger().F_value.Ref(); var tmp5 int32 = addend.Self_MutableBigInteger().F_offset; var tmp6 any = res.Ref(); var tmp7 int32 = resOffset + resLen - addend.Self_MutableBigInteger().F_intLen; System_Arraycopy_O_I_O_I_I__V(tmp4, tmp5, tmp6, tmp7, addend.Self_MutableBigInteger().F_intLen)






			t.F_value = res
			t.F_offset = resOffset
			t.F_intLen = resLen
		} }
func (t *MutableBigInteger) Impl_Subtract_MutableBigInteger__I(this, b MutableBigInteger_I) int32 {
	var a MutableBigInteger_I = this; var result *IntArray = t.F_value; var sign int32 = a.Compare_MutableBigInteger__I(b)


	if sign == 0 {
		this.Reset__V(); return 0 } else {

			if sign < 0 { var tmp MutableBigInteger_I = a; a = b; b = tmp }
			var resultLen int32 = a.Self_MutableBigInteger().F_intLen
			if int32(len(result.A)) < resultLen { result = NewIntArray(resultLen) }
			var diff int64 = 0; var x int32 = a.Self_MutableBigInteger().F_intLen; var y int32 = b.Self_MutableBigInteger().F_intLen; var rstart int32 = int32(len(result.A)) - 1



		L1: for { if y > 0 {
			x = x - 1
			y = y - 1
			var tmp1 *IntArray = a.Self_MutableBigInteger().F_value; var tmp2 int64 = int64(tmp1.A[x+a.Self_MutableBigInteger().F_offset]) & 4294967295; var tmp3 *IntArray = b.Self_MutableBigInteger().F_value; diff = tmp2 - int64(tmp3.A[y+b.Self_MutableBigInteger().F_offset])&4294967295 + diff>>32







			result.A[rstart] = int32(diff)
			rstart = rstart - 1
//line :667:1
			continue L1 }; break L1
		}











		L2: for { if x > 0 {
			x = x - 1
			var tmp4 *IntArray = a.Self_MutableBigInteger().F_value; diff = int64(tmp4.A[x+a.Self_MutableBigInteger().F_offset])&4294967295 + diff>>32




			result.A[rstart] = int32(diff)
			rstart = rstart - 1
//line :680:1
			continue L2 }; break L2
		}







			t.F_value = result
			t.F_intLen = resultLen
			t.F_offset = int32(len(t.F_value.A)) - resultLen
			this.Normalize__V()
//line :663:1
			return sign
		}
}





























func (t *MutableBigInteger) Impl_Difference_MutableBigInteger__I(this, b MutableBigInteger_I) int32 {
	var a MutableBigInteger_I = this; var sign int32 = a.Compare_MutableBigInteger__I(b)

	if sign == 0 { return 0 } else {


		if sign < 0 { var tmp MutableBigInteger_I = a; a = b; b = tmp }
		var diff int64 = 0; var x int32 = a.Self_MutableBigInteger().F_intLen; var y int32 = b.Self_MutableBigInteger().F_intLen


	L1: for { if y > 0 {
		x = x - 1
		y = y - 1
		var tmp1 *IntArray = a.Self_MutableBigInteger().F_value; var tmp2 int64 = int64(tmp1.A[a.Self_MutableBigInteger().F_offset+x]) & 4294967295; var tmp3 *IntArray = b.Self_MutableBigInteger().F_value; diff = tmp2 - int64(tmp3.A[b.Self_MutableBigInteger().F_offset+y])&4294967295 + diff>>32







		var tmp4 *IntArray = a.Self_MutableBigInteger().F_value; tmp4.A[a.Self_MutableBigInteger().F_offset+x] = int32(diff)
//line :705:1
		continue L1 }; break L1
	}










	L2: for { var tmp5 bool; var tmp6 bool; tmp6 = diff < 0; if tmp6 { tmp6 = x > 0 }; tmp5 = tmp6; if tmp5 {
		x = x - 1
		var tmp7 *IntArray = a.Self_MutableBigInteger().F_value; diff = int64(tmp7.A[a.Self_MutableBigInteger().F_offset+x])&4294967295 + diff>>32




		var tmp8 *IntArray = a.Self_MutableBigInteger().F_value; tmp8.A[a.Self_MutableBigInteger().F_offset+x] = int32(diff)
//line :717:1
		continue L2 }; break L2
	}






		a.Normalize__V()
//line :702:1
		return sign
	}
}























func (t *MutableBigInteger) Impl_Multiply_MutableBigInteger_MutableBigInteger__V(this, y, z MutableBigInteger_I) {
	var xLen int32 = t.F_intLen; var yLen int32 = y.Self_MutableBigInteger().F_intLen; var newLen int32 = xLen + yLen


	if int32(len(z.Self_MutableBigInteger().F_value.A)) < newLen { z.Self_MutableBigInteger().F_value = NewIntArray(newLen) }
	z.Self_MutableBigInteger().F_offset = 0
	z.Self_MutableBigInteger().F_intLen = newLen
	var carry int64 = 0; var j int32 = yLen - 1; var k int32 = yLen + xLen - 1
L1: for {

	if j >= 0 {
		var tmp1 *IntArray = y.Self_MutableBigInteger().F_value; var tmp2 int64 = int64(tmp1.A[j+y.Self_MutableBigInteger().F_offset]) & 4294967295; var product int64 = tmp2*(int64(t.F_value.A[xLen-1+t.F_offset])&4294967295) + carry









		z.Self_MutableBigInteger().F_value.A[k] = int32(product)
		carry = int64(uint64(product) >> 32)
		j, k = j-1, k-1; continue L1 }
//line :736:1
	break L1
}














	z.Self_MutableBigInteger().F_value.A[xLen-1] = int32(carry)
	var i int32 = xLen - 2; L2: for {
		if i >= 0 {
			carry = 0
			var j_2 int32 = yLen - 1; var k_2 int32 = yLen + i; L3: for {

				if j_2 >= 0 {
					var tmp3 *IntArray = y.Self_MutableBigInteger().F_value; var tmp4 int64 = int64(tmp3.A[j_2+y.Self_MutableBigInteger().F_offset]) & 4294967295; var tmp5 int64 = tmp4 * (int64(t.F_value.A[i+t.F_offset]) & 4294967295); var product_2 int64 = tmp5 + int64(z.Self_MutableBigInteger().F_value.A[k_2])&4294967295 + carry








					z.Self_MutableBigInteger().F_value.A[k_2] = int32(product_2)
					carry = int64(uint64(product_2) >> 32)
					j_2, k_2 = j_2-1, k_2-1; continue L3 }
//line :756:1
				break L3
			}













			z.Self_MutableBigInteger().F_value.A[i] = int32(carry)
			i = i - 1; continue L2 }
//line :753:1
		break L2
	}


















	z.Normalize__V()
}
func (t *MutableBigInteger) Impl_Mul_I_MutableBigInteger__V(this MutableBigInteger_I, y int32, z MutableBigInteger_I) {
	if y == 1 {
		z.CopyValue_MutableBigInteger__V(this) } else {
//line :776:1
			if y == 0 {

				z.Clear__V() } else {

					var ylong int64 = int64(y) & 4294967295; var zval *IntArray
					if int32(len(z.Self_MutableBigInteger().F_value.A)) < t.F_intLen+1 {
						zval = NewIntArray(t.F_intLen + 1) } else {
							zval = z.Self_MutableBigInteger().F_value }
//line :780:1
					var carry int64 = 0; var i int32 = t.F_intLen - 1




				L1: for {
					if i >= 0 {
						var product int64 = ylong*(int64(t.F_value.A[i+t.F_offset])&4294967295) + carry





						zval.A[i+1] = int32(product)
						carry = int64(uint64(product) >> 32)
						i = i - 1; continue L1 }
//line :785:1
					break L1
				}









					if carry == 0 {
						z.Self_MutableBigInteger().F_offset = 1; z.Self_MutableBigInteger().F_intLen = t.F_intLen } else {

							z.Self_MutableBigInteger().F_offset = 0
							z.Self_MutableBigInteger().F_intLen = t.F_intLen + 1
							zval.A[0] = int32(carry) }
					z.Self_MutableBigInteger().F_value = zval
				} } }
func (t *MutableBigInteger) Impl_DivideOneWord_I_MutableBigInteger__I(this MutableBigInteger_I, divisor int32, quotient MutableBigInteger_I) int32 {
	var divisorLong int64 = int64(divisor) & 4294967295
	if t.F_intLen == 1 {
		var dividendValue int32 = t.F_value.A[t.F_offset]; var q int32 = Integer_DivideUnsigned_I_I__I(dividendValue, divisor); var r int32 = Integer_RemainderUnsigned_I_I__I(dividendValue, divisor)


		quotient.Self_MutableBigInteger().F_value.A[0] = q
		var tmp1 int32; if q == 0 { tmp1 = 0 } else { tmp1 = 1 }; quotient.Self_MutableBigInteger().F_intLen = tmp1
		quotient.Self_MutableBigInteger().F_offset = 0
//line :807:1
		return r



	} else {



		if int32(len(quotient.Self_MutableBigInteger().F_value.A)) < t.F_intLen {
			quotient.Self_MutableBigInteger().F_value = NewIntArray(t.F_intLen) }
		quotient.Self_MutableBigInteger().F_offset = 0
		quotient.Self_MutableBigInteger().F_intLen = t.F_intLen
		var rem int64 = 0; var xlen int32 = t.F_intLen
	L1: for {
		if xlen > 0 {
			var dividendEstimate int64 = rem<<32 | int64(t.F_value.A[t.F_offset+t.F_intLen-xlen])&4294967295; var q_2 int32 = int32(Long_DivideUnsigned_J_J__J(dividendEstimate, divisorLong))









			rem = Long_RemainderUnsigned_J_J__J(dividendEstimate, divisorLong)
			quotient.Self_MutableBigInteger().F_value.A[t.F_intLen-xlen] = q_2
			xlen = xlen - 1; continue L1 }
//line :820:1
		break L1
	}













		quotient.Normalize__V()
		return int32(rem)
	} }
func (t *MutableBigInteger) Impl_Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(this, b, quotient MutableBigInteger_I) MutableBigInteger_I {
	return this.Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(b, quotient, true)
}
func (t *MutableBigInteger) Impl_Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(this, b, quotient MutableBigInteger_I, needRemainder bool) MutableBigInteger_I {

	var tmp1 bool; var tmp2 bool; tmp2 = b.Self_MutableBigInteger().F_intLen < 80; if !tmp2 {
		var tmp3 int32 = t.F_intLen; tmp2 = tmp3-b.Self_MutableBigInteger().F_intLen < 40 }
//line :843:1
	tmp1 = tmp2; if tmp1 {

		return this.DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(b, quotient, needRemainder) } else {
			return this.DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, quotient)
		} }
func (t *MutableBigInteger) Impl_DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(this, b, quotient MutableBigInteger_I) MutableBigInteger_I {
	return this.DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(b, quotient, true)
}
func (t *MutableBigInteger) Impl_DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(this, b, quotient MutableBigInteger_I, needRemainder bool) MutableBigInteger_I {

	if b.Self_MutableBigInteger().F_intLen == 0 { panic(Thrown(ArithmeticException_New_String(Lit_1288))) }
	if t.F_intLen == 0 {

		var tmp1 int32; var tmp2 int32 = 0; quotient.Self_MutableBigInteger().F_offset = tmp2; tmp1 = tmp2; quotient.Self_MutableBigInteger().F_intLen = tmp1
		if needRemainder { return MutableBigInteger_New() } else { return nil } } else {
			var cmp int32 = this.Compare_MutableBigInteger__I(b)
			if cmp < 0 {


				var tmp3 int32; var tmp4 int32 = 0; quotient.Self_MutableBigInteger().F_offset = tmp4; tmp3 = tmp4; quotient.Self_MutableBigInteger().F_intLen = tmp3
				if needRemainder { return MutableBigInteger_New_MutableBigInteger(this) } else { return nil } } else {
//line :859:1
					if cmp == 0 {






						var tmp5 *IntArray = quotient.Self_MutableBigInteger().F_value; var tmp6 int32; var tmp7 int32 = 1; quotient.Self_MutableBigInteger().F_intLen = tmp7; tmp6 = tmp7; tmp5.A[0] = tmp6
						quotient.Self_MutableBigInteger().F_offset = 0
						if needRemainder { return MutableBigInteger_New() } else { return nil } } else {


							quotient.Clear__V()
							if b.Self_MutableBigInteger().F_intLen == 1 {
								var tmp8 *IntArray = b.Self_MutableBigInteger().F_value; var r int32 = this.DivideOneWord_I_MutableBigInteger__I(tmp8.A[b.Self_MutableBigInteger().F_offset], quotient)
								if needRemainder { if r == 0 { return MutableBigInteger_New() } else { return MutableBigInteger_New_I(r) } } else { return nil } } else {

									if t.F_intLen >= 6 {
										var trailingZeroBits int32 = Math_Min_I_I__I(t.Impl_GetLowestSetBit__I(this), b.Self_MutableBigInteger().Impl_GetLowestSetBit__I(b))


										if trailingZeroBits >= 96 {

											var a MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this)
											b = MutableBigInteger_New_MutableBigInteger(b)
											a.RightShift_I__V(trailingZeroBits)
											b.RightShift_I__V(trailingZeroBits)
											var r_2 MutableBigInteger_I = a.DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, quotient)
											r_2.LeftShift_I__V(trailingZeroBits)
											return r_2 } }
									return t.Impl_DivideMagnitude_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(this, b, quotient, needRemainder)
								} } } } }
func (t *MutableBigInteger) Impl_DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(this, b, quotient MutableBigInteger_I) MutableBigInteger_I {

	var r int32 = t.F_intLen; var s int32 = b.Self_MutableBigInteger().F_intLen; var tmp1 int32
	var tmp2 int32 = 0
	quotient.Self_MutableBigInteger().F_intLen = tmp2; tmp1 = tmp2; quotient.Self_MutableBigInteger().F_offset = tmp1
	if r < s { return this } else {

		var m int32 = 1 << ((32 - Integer_NumberOfLeadingZeros_I__I(s/80)) & 31); var j int32 = (s + m - 1) / m; var n int32 = j * m; var n32 int64 = 32 * int64(n); var sigma int32 = int32(Math_Max_J_J__J(0, n32-b.BitLength__J())); var bShifted MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(b)











		bShifted.SafeLeftShift_I__V(sigma)
		var aShifted MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this)
		aShifted.SafeLeftShift_I__V(sigma)
		var t_ int32 = int32((aShifted.BitLength__J() + n32) / n32)

		if t_ < 2 { t_ = 2 }
		var a1 MutableBigInteger_I = aShifted.Self_MutableBigInteger().Impl_GetBlock_I_I_I__MutableBigInteger(aShifted, t_-1, t_, n); var z MutableBigInteger_I = aShifted.Self_MutableBigInteger().Impl_GetBlock_I_I_I__MutableBigInteger(aShifted, t_-2, t_, n)

		z.AddDisjoint_MutableBigInteger_I__V(a1, n)
		var qi MutableBigInteger_I = MutableBigInteger_New(); var ri MutableBigInteger_I; var i int32 = t_ - 2

	L1: for {
		if i > 0 {
			ri = z.Self_MutableBigInteger().Impl_Divide2n1n_MutableBigInteger_MutableBigInteger__MutableBigInteger(z, bShifted, qi)
			z = aShifted.Self_MutableBigInteger().Impl_GetBlock_I_I_I__MutableBigInteger(aShifted, i-1, t_, n)
			z.AddDisjoint_MutableBigInteger_I__V(ri, n)
			quotient.AddShifted_MutableBigInteger_I__V(qi, i*n)
			i = i - 1; continue L1 }
//line :921:1
		break L1
	}





		ri = z.Self_MutableBigInteger().Impl_Divide2n1n_MutableBigInteger_MutableBigInteger__MutableBigInteger(z, bShifted, qi)
		quotient.Add_MutableBigInteger__V(qi)
		ri.RightShift_I__V(sigma)
//line :919:1
		return ri
	}
}











func (t *MutableBigInteger) Impl_Divide2n1n_MutableBigInteger_MutableBigInteger__MutableBigInteger(this, b, quotient MutableBigInteger_I) MutableBigInteger_I {

	var n int32 = b.Self_MutableBigInteger().F_intLen; var tmp1 bool; var tmp2 bool
	tmp2 = !(n%2 == 0); if !tmp2 {
		tmp2 = n < 80 }
//line :936:1
	tmp1 = tmp2; if tmp1 {

		return this.DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, quotient) } else {
			var aUpper MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this)
			aUpper.SafeRightShift_I__V(32 * (n / 2))
			t.Impl_KeepLower_I__V(this, n/2)
			var q1 MutableBigInteger_I = MutableBigInteger_New(); var r1 MutableBigInteger_I = aUpper.Self_MutableBigInteger().Impl_Divide3n2n_MutableBigInteger_MutableBigInteger__MutableBigInteger(aUpper, b, q1)

			this.AddDisjoint_MutableBigInteger_I__V(r1, n/2)
			var r2 MutableBigInteger_I = t.Impl_Divide3n2n_MutableBigInteger_MutableBigInteger__MutableBigInteger(this, b, quotient)
			quotient.AddDisjoint_MutableBigInteger_I__V(q1, n/2)
//line :945:1
			return r2
		}
}

func (t *MutableBigInteger) Impl_Divide3n2n_MutableBigInteger_MutableBigInteger__MutableBigInteger(this, b, quotient MutableBigInteger_I) MutableBigInteger_I {

	var n int32 = b.Self_MutableBigInteger().F_intLen / 2; var a12 MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this)

	a12.SafeRightShift_I__V(32 * n)
	var b1 MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(b)
	b1.SafeRightShift_I__V(n * 32)
	var b2 *BigInteger = b.Self_MutableBigInteger().Impl_GetLower_I__BigInteger(b, n); var r MutableBigInteger_I; var d MutableBigInteger_I


	if t.Impl_CompareShifted_MutableBigInteger_I__I(this, b, n) < 0 {

		r = a12.Self_MutableBigInteger().Impl_Divide2n1n_MutableBigInteger_MutableBigInteger__MutableBigInteger(a12, b1, quotient)
		d = MutableBigInteger_New_BigInteger(NN(quotient.ToBigInteger__BigInteger()).Multiply_BigInteger__BigInteger(b2)) } else {

			quotient.Self_MutableBigInteger().Impl_Ones_I__V(quotient, n)
			a12.Add_MutableBigInteger__V(b1)
			b1.LeftShift_I__V(32 * n)
			a12.Subtract_MutableBigInteger__I(b1)
			r = a12
			d = MutableBigInteger_New_BigInteger(b2)
			d.LeftShift_I__V(32 * n)
			d.Subtract_MutableBigInteger__I(MutableBigInteger_New_BigInteger(b2)) }
	r.LeftShift_I__V(32 * n)
	r.AddLower_MutableBigInteger_I__V(this, n)
L1: for { if r.Compare_MutableBigInteger__I(d) < 0 { r.Add_MutableBigInteger__V(b); quotient.Subtract_MutableBigInteger__I(MutableBigInteger_ONE); continue L1 }; break L1 }
	r.Subtract_MutableBigInteger__I(d)
//line :956:1
	return r
}




















func (t *MutableBigInteger) Impl_GetBlock_I_I_I__MutableBigInteger(this MutableBigInteger_I, index, numBlocks, blockLength int32) MutableBigInteger_I {
	var blockStart int32 = index * blockLength
	if blockStart >= t.F_intLen {
		return MutableBigInteger_New() } else {
			var blockEnd int32; if index == numBlocks-1 { blockEnd = t.F_intLen } else {

				blockEnd = (index + 1) * blockLength }
			if blockEnd > t.F_intLen {
				return MutableBigInteger_New() } else {
					var newVal *IntArray = Arrays_CopyOfRange_I1_I_I__I1(t.F_value, t.F_offset+t.F_intLen-blockEnd, t.F_offset+t.F_intLen-blockStart)



					return MutableBigInteger_New_I1(newVal)
				} } }
func (t *MutableBigInteger) Impl_BitLength__J(this MutableBigInteger_I) int64 {
	if t.F_intLen == 0 { return 0 } else {

		var tmp1 int64 = int64(t.F_intLen) * 32; return tmp1 - int64(Integer_NumberOfLeadingZeros_I__I(t.F_value.A[t.F_offset]))
	}
}
func (t *MutableBigInteger) Impl_Divide_J_MutableBigInteger__J(this MutableBigInteger_I, v int64, quotient MutableBigInteger_I) int64 {
	if v == 0 { panic(Thrown(ArithmeticException_New_String(Lit_1288))) }
	if t.F_intLen == 0 {
		var tmp1 int32; var tmp2 int32 = 0; quotient.Self_MutableBigInteger().F_offset = tmp2; tmp1 = tmp2; quotient.Self_MutableBigInteger().F_intLen = tmp1; return 0 } else {

			if v < 0 { v = -v }
			var d int32 = int32(int64(uint64(v) >> 32))
			quotient.Clear__V()
			if d == 0 {
				return int64(this.DivideOneWord_I_MutableBigInteger__I(int32(v), quotient)) & 4294967295 } else {
					var tmp3 MutableBigInteger_I = t.Impl_DivideLongMagnitude_J_MutableBigInteger__MutableBigInteger(this, v, quotient); return tmp3.Self_MutableBigInteger().Impl_ToLong__J(tmp3)
				} } }
func (t *MutableBigInteger) Impl_DivideMagnitude_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(this, div, quotient MutableBigInteger_I, needRemainder bool) MutableBigInteger_I {


	var tmp1 *IntArray = div.Self_MutableBigInteger().F_value; var shift int32 = Integer_NumberOfLeadingZeros_I__I(tmp1.A[div.Self_MutableBigInteger().F_offset]); var dlen int32 = div.Self_MutableBigInteger().F_intLen; var divisor *IntArray; var rem MutableBigInteger_I



	if shift > 0 {

		divisor = NewIntArray(dlen)
		div.Self_MutableBigInteger().Impl_PrimitiveLeftShift_I_I1_I__V(div, shift, divisor, 0)
		if Integer_NumberOfLeadingZeros_I__I(t.F_value.A[t.F_offset]) >= shift {
			var remarr *IntArray = NewIntArray(t.F_intLen + 1)
			rem = MutableBigInteger_New_I1(remarr)
			rem.Self_MutableBigInteger().F_intLen = t.F_intLen
			rem.Self_MutableBigInteger().F_offset = 1
			t.Impl_PrimitiveLeftShift_I_I1_I__V(this, shift, remarr, 1) } else {
				var remarr_2 *IntArray = NewIntArray(t.F_intLen + 2)
				rem = MutableBigInteger_New_I1(remarr_2)
				rem.Self_MutableBigInteger().F_intLen = t.F_intLen + 1
				rem.Self_MutableBigInteger().F_offset = 1
				var rFrom int32 = t.F_offset; var c int32 = 0; var n2 int32 = 32 - shift
				var i int32 = 1


			L1: for { if i < t.F_intLen+1 {
				var b int32 = c
				c = t.F_value.A[rFrom]
				remarr_2.A[i] = b<<(shift&31) | int32(uint32(c)>>(n2&31))



				i = i + 1
				rFrom = rFrom + 1
//line :1036:1
				continue L1 }; break L1
			}







				remarr_2.A[t.F_intLen+1] = c << (shift & 31) } } else {

					var tmp2 *IntArray = div.Self_MutableBigInteger().F_value; var tmp3 int32 = div.Self_MutableBigInteger().F_offset; var tmp4 int32 = div.Self_MutableBigInteger().F_offset; divisor = Arrays_CopyOfRange_I1_I_I__I1(tmp2, tmp3, tmp4+div.Self_MutableBigInteger().F_intLen)



					rem = MutableBigInteger_New_I1(NewIntArray(t.F_intLen + 1))
					var tmp5 any = t.F_value.Ref(); var tmp6 int32 = t.F_offset; System_Arraycopy_O_I_O_I_I__V(tmp5, tmp6, rem.Self_MutableBigInteger().F_value.Ref(), 1, t.F_intLen)
					rem.Self_MutableBigInteger().F_intLen = t.F_intLen
					rem.Self_MutableBigInteger().F_offset = 1 }
	var nlen int32 = rem.Self_MutableBigInteger().F_intLen; var limit int32 = nlen - dlen + 1

	if int32(len(quotient.Self_MutableBigInteger().F_value.A)) < limit {
		quotient.Self_MutableBigInteger().F_value = NewIntArray(limit)
		quotient.Self_MutableBigInteger().F_offset = 0 }
	quotient.Self_MutableBigInteger().F_intLen = limit
	var q *IntArray = quotient.Self_MutableBigInteger().F_value
	rem.Self_MutableBigInteger().F_offset = 0
	rem.Self_MutableBigInteger().F_value.A[0] = 0
	rem.Self_MutableBigInteger().F_intLen = rem.Self_MutableBigInteger().F_intLen + 1
	var dh int32 = divisor.A[0]; var dhLong int64 = int64(dh) & 4294967295; var dl int32 = divisor.A[1]
	var j int32 = 0

L2: for {
	if j < limit-1 {
		var qhat int32 = 0; var qrem int32 = 0; var skipCorrection bool = false; var tmp7 *IntArray = rem.Self_MutableBigInteger().F_value; var nh int32 = tmp7.A[j+rem.Self_MutableBigInteger().F_offset]; var nh2 int32 = nh + -2147483648; var tmp8 *IntArray = rem.Self_MutableBigInteger().F_value; var nm int32 = tmp8.A[j+1+rem.Self_MutableBigInteger().F_offset]






		if nh == dh {

			qhat = -1
			qrem = nh + nm
			skipCorrection = qrem+-2147483648 < nh2 } else {

				var nChunk int64 = int64(nh)<<32 | int64(nm)&4294967295

				qhat = int32(Long_DivideUnsigned_J_J__J(nChunk, dhLong))
				qrem = int32(Long_RemainderUnsigned_J_J__J(nChunk, dhLong)) }
		if qhat == 0 {
			j = j + 1; continue L2 } else {

				if skipCorrection { } else {
					var tmp9 *IntArray = rem.Self_MutableBigInteger().F_value; var nl int64 = int64(tmp9.A[j+2+rem.Self_MutableBigInteger().F_offset]) & 4294967295; var rs int64 = int64(qrem)&4294967295<<32 | nl; var estProduct int64 = int64(dl) & 4294967295 * (int64(qhat) & 4294967295)













					if t.Impl_UnsignedLongCompare_J_J__Z(this, estProduct, rs) {
						qhat = qhat - 1
						qrem = int32(int64(qrem)&4294967295 + dhLong)


						if int64(qrem)&4294967295 >= dhLong {
							estProduct = estProduct - int64(dl)&4294967295



							rs = int64(qrem)&4294967295<<32 | nl




							if t.Impl_UnsignedLongCompare_J_J__Z(this, estProduct, rs) {
								qhat = qhat - 1 } } } }
				var tmp10 *IntArray = rem.Self_MutableBigInteger().F_value; tmp10.A[j+rem.Self_MutableBigInteger().F_offset] = 0
				var tmp11 *IntArray = rem.Self_MutableBigInteger().F_value; var borrow int32 = t.Impl_Mulsub_I1_I1_I_I_I__I(this, tmp11, divisor, qhat, dlen, j+rem.Self_MutableBigInteger().F_offset)





				if borrow+-2147483648 > nh2 {
					var tmp12 *IntArray = divisor; var tmp13 *IntArray = rem.Self_MutableBigInteger().F_value; t.Impl_Divadd_I1_I1_I__I(this, tmp12, tmp13, j+1+rem.Self_MutableBigInteger().F_offset)



					qhat = qhat - 1 }
				q.A[j] = qhat
				j = j + 1; continue L2 } }
//line :1068:1
	break L2
}



































































	var qhat_2 int32 = 0; var qrem_2 int32 = 0; var skipCorrection_2 bool = false; var tmp14 *IntArray = rem.Self_MutableBigInteger().F_value; var nh_2 int32 = tmp14.A[limit-1+rem.Self_MutableBigInteger().F_offset]; var nh2_2 int32 = nh_2 + -2147483648; var tmp15 *IntArray = rem.Self_MutableBigInteger().F_value; var nm_2 int32 = tmp15.A[limit+rem.Self_MutableBigInteger().F_offset]






	if nh_2 == dh {

		qhat_2 = -1
		qrem_2 = nh_2 + nm_2
		skipCorrection_2 = qrem_2+-2147483648 < nh2_2 } else {

			var nChunk_2 int64 = int64(nh_2)<<32 | int64(nm_2)&4294967295

			qhat_2 = int32(Long_DivideUnsigned_J_J__J(nChunk_2, dhLong))
			qrem_2 = int32(Long_RemainderUnsigned_J_J__J(nChunk_2, dhLong)) }
	if qhat_2 == 0 { } else {
		if skipCorrection_2 { } else {
			var tmp16 *IntArray = rem.Self_MutableBigInteger().F_value; var nl_2 int64 = int64(tmp16.A[limit+1+rem.Self_MutableBigInteger().F_offset]) & 4294967295; var rs_2 int64 = int64(qrem_2)&4294967295<<32 | nl_2; var estProduct_2 int64 = int64(dl) & 4294967295 * (int64(qhat_2) & 4294967295)









			if t.Impl_UnsignedLongCompare_J_J__Z(this, estProduct_2, rs_2) {
				qhat_2 = qhat_2 - 1
				qrem_2 = int32(int64(qrem_2)&4294967295 + dhLong)


				if int64(qrem_2)&4294967295 >= dhLong {
					estProduct_2 = estProduct_2 - int64(dl)&4294967295

					rs_2 = int64(qrem_2)&4294967295<<32 | nl_2

					if t.Impl_UnsignedLongCompare_J_J__Z(this, estProduct_2, rs_2) {
						qhat_2 = qhat_2 - 1 } } } }
		var borrow_2 int32 = 0; var tmp17 *IntArray = rem.Self_MutableBigInteger().F_value
		tmp17.A[limit-1+rem.Self_MutableBigInteger().F_offset] = 0


		if needRemainder {
			var tmp18 *IntArray = rem.Self_MutableBigInteger().F_value; borrow_2 = t.Impl_Mulsub_I1_I1_I_I_I__I(this, tmp18, divisor, qhat_2, dlen, limit-1+rem.Self_MutableBigInteger().F_offset) } else {








				var tmp19 *IntArray = rem.Self_MutableBigInteger().F_value; borrow_2 = t.Impl_MulsubBorrow_I1_I1_I_I_I__I(this, tmp19, divisor, qhat_2, dlen, limit-1+rem.Self_MutableBigInteger().F_offset)
			}







		if borrow_2+-2147483648 > nh2_2 {
			if needRemainder {
				var tmp20 *IntArray = divisor; var tmp21 *IntArray = rem.Self_MutableBigInteger().F_value; t.Impl_Divadd_I1_I1_I__I(this, tmp20, tmp21, limit-1+1+rem.Self_MutableBigInteger().F_offset)
			}




			qhat_2 = qhat_2 - 1 }
		q.A[limit-1] = qhat_2 }
	if needRemainder { if shift > 0 { rem.RightShift_I__V(shift) }; rem.Normalize__V() }
	quotient.Normalize__V()
	if needRemainder { return rem } else { return nil
	} }
func (t *MutableBigInteger) Impl_DivideLongMagnitude_J_MutableBigInteger__MutableBigInteger(this MutableBigInteger_I, ldivisor int64, quotient MutableBigInteger_I) MutableBigInteger_I {

	var rem MutableBigInteger_I = MutableBigInteger_New_I1(NewIntArray(t.F_intLen + 1)); var tmp1 any = t.F_value.Ref(); var tmp2 int32 = t.F_offset
	System_Arraycopy_O_I_O_I_I__V(tmp1, tmp2, rem.Self_MutableBigInteger().F_value.Ref(), 1, t.F_intLen)
	rem.Self_MutableBigInteger().F_intLen = t.F_intLen
	rem.Self_MutableBigInteger().F_offset = 1
	var nlen int32 = rem.Self_MutableBigInteger().F_intLen; var limit int32 = nlen - 2 + 1

	if int32(len(quotient.Self_MutableBigInteger().F_value.A)) < limit {
		quotient.Self_MutableBigInteger().F_value = NewIntArray(limit)
		quotient.Self_MutableBigInteger().F_offset = 0 }
	quotient.Self_MutableBigInteger().F_intLen = limit
	var q *IntArray = quotient.Self_MutableBigInteger().F_value; var shift int32 = Long_NumberOfLeadingZeros_J__I(ldivisor)

	if shift > 0 { ldivisor = ldivisor << (shift & 63); rem.LeftShift_I__V(shift) }
	if rem.Self_MutableBigInteger().F_intLen == nlen {
		rem.Self_MutableBigInteger().F_offset = 0
		rem.Self_MutableBigInteger().F_value.A[0] = 0
		rem.Self_MutableBigInteger().F_intLen = rem.Self_MutableBigInteger().F_intLen + 1 }
	var dh int32 = int32(int64(uint64(ldivisor) >> 32)); var dhLong int64 = int64(dh) & 4294967295; var dl int32 = int32(ldivisor & 4294967295)
	var j int32 = 0

L1: for {
	if j < limit {
		var qhat int32 = 0; var qrem int32 = 0; var skipCorrection bool = false; var tmp3 *IntArray = rem.Self_MutableBigInteger().F_value; var nh int32 = tmp3.A[j+rem.Self_MutableBigInteger().F_offset]; var nh2 int32 = nh + -2147483648; var tmp4 *IntArray = rem.Self_MutableBigInteger().F_value; var nm int32 = tmp4.A[j+1+rem.Self_MutableBigInteger().F_offset]






		if nh == dh {

			qhat = -1
			qrem = nh + nm
			skipCorrection = qrem+-2147483648 < nh2 } else {

				var nChunk int64 = int64(nh)<<32 | int64(nm)&4294967295

				qhat = int32(Long_DivideUnsigned_J_J__J(nChunk, dhLong))
				qrem = int32(Long_RemainderUnsigned_J_J__J(nChunk, dhLong)) }
		if qhat == 0 {
			j = j + 1; continue L1 } else {

				if skipCorrection { } else {
					var tmp5 *IntArray = rem.Self_MutableBigInteger().F_value; var nl int64 = int64(tmp5.A[j+2+rem.Self_MutableBigInteger().F_offset]) & 4294967295; var rs int64 = int64(qrem)&4294967295<<32 | nl; var estProduct int64 = int64(dl) & 4294967295 * (int64(qhat) & 4294967295)













					if t.Impl_UnsignedLongCompare_J_J__Z(this, estProduct, rs) {
						qhat = qhat - 1
						qrem = int32(int64(qrem)&4294967295 + dhLong)


						if int64(qrem)&4294967295 >= dhLong {
							estProduct = estProduct - int64(dl)&4294967295



							rs = int64(qrem)&4294967295<<32 | nl




							if t.Impl_UnsignedLongCompare_J_J__Z(this, estProduct, rs) {
								qhat = qhat - 1 } } } }
				var tmp6 *IntArray = rem.Self_MutableBigInteger().F_value; tmp6.A[j+rem.Self_MutableBigInteger().F_offset] = 0
				var tmp7 *IntArray = rem.Self_MutableBigInteger().F_value; var borrow int32 = t.Impl_MulsubLong_I1_I_I_I_I__I(this, tmp7, dh, dl, qhat, j+rem.Self_MutableBigInteger().F_offset)






				if borrow+-2147483648 > nh2 {
					var tmp8 *IntArray = rem.Self_MutableBigInteger().F_value; t.Impl_DivaddLong_I_I_I1_I__I(this, dh, dl, tmp8, j+1+rem.Self_MutableBigInteger().F_offset)




					qhat = qhat - 1 }
				q.A[j] = qhat
				j = j + 1; continue L1 } }
//line :1237:1
	break L1
}





































































	if shift > 0 { rem.RightShift_I__V(shift) }
	quotient.Normalize__V()
	rem.Normalize__V()
//line :1234:1
	return rem
}













































































func (t *MutableBigInteger) Impl_DivaddLong_I_I_I1_I__I(this MutableBigInteger_I, dh, dl int32, result *IntArray, offset int32) int32 {
	var carry int64 = 0; var sum int64 = int64(dl)&4294967295 + int64(result.A[1+offset])&4294967295



	result.A[1+offset] = int32(sum)
	sum = int64(dh)&4294967295 + int64(result.A[offset])&4294967295 + carry




	result.A[offset] = int32(sum)
	carry = int64(uint64(sum) >> 32)
	return int32(carry)
}
func (t *MutableBigInteger) Impl_MulsubLong_I1_I_I_I_I__I(this MutableBigInteger_I, q *IntArray, dh, dl, x, offset int32) int32 {
	var xLong int64 = int64(x) & 4294967295
	offset = offset + 2
	var product int64 = int64(dl) & 4294967295 * xLong; var difference int64 = int64(q.A[offset]) - product

	q.A[offset] = int32(difference)
	offset = offset - 1
	var carry int64; var tmp1 int64 = int64(uint64(product) >> 32); var tmp2 int32
	if difference&4294967295 > int64(^int32(product))&4294967295 { tmp2 = 1 } else { tmp2 = 0 }
//line :1335:1
	carry = tmp1 + int64(tmp2)







	product = int64(dh)&4294967295*xLong + carry

	difference = int64(q.A[offset]) - product
	q.A[offset] = int32(difference)
	offset = offset - 1
	var tmp3 int64 = int64(uint64(product) >> 32); var tmp4 int32

	if difference&4294967295 > int64(^int32(product))&4294967295 { tmp4 = 1 } else { tmp4 = 0 }
//line :1348:1
	carry = tmp3 + int64(tmp4)






	return int32(carry)
}
func (t *MutableBigInteger) Impl_UnsignedLongCompare_J_J__Z(this MutableBigInteger_I, one, two int64) bool {
	return one+-9223372036854775808 > two+-9223372036854775808
}
func (t *MutableBigInteger) Impl_RootnRem_I__MutableBigInteger1(this MutableBigInteger_I, n int32) *RefArray {
	{ var tmp1 bool; var tmp2 bool; tmp2 = this.IsZero__Z(); if !tmp2 { tmp2 = this.IsOne__Z() }; tmp1 = tmp2; if tmp1 {
		return RefArrayOf(MutableBigInteger_class, this, MutableBigInteger_New()) } else {
			var bitLength int32 = int32(this.BitLength__J())
			if bitLength <= n {
				var rem MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this)
				rem.Subtract_MutableBigInteger__I(MutableBigInteger_ONE)
				return RefArrayOf(MutableBigInteger_class, MutableBigInteger_New_I(1), rem) } else {
					var s MutableBigInteger_I
					if bitLength <= 64 {
						var x int64 = t.Impl_ToLong__J(this); var sLong int64; var tmp3 float64




						if x >= 0 {
							tmp3 = float64(x) } else {
								tmp3 = float64(x) + 1.8446744073709552e19 }
//line :1371:1
						sLong = D2L(MutableBigInteger_RootnApprox_D_I__D(Math_NextUp_D__D(tmp3), n)) + 1








						if BigInteger_BitLengthForLong_J__I(sLong)*(n-1) <= 64 {



							var sToN1 int64 = BigInteger_UnsignedLongPow_J_I__J(sLong, n-1)


							sLong = (int64(n-1)*sLong + Long_DivideUnsigned_J_J__J(x, sToN1)) / int64(n)





							if BigInteger_BitLengthForLong_J__I(sLong)*(n-1) <= 64 {



								var u int64 = sLong
							L1: for {
								sLong = u
								sToN1 = BigInteger_UnsignedLongPow_J_I__J(sLong, n-1)



								u = (int64(n-1)*sLong + Long_DivideUnsigned_J_J__J(x, sToN1)) / int64(n)





								if u < sLong { continue L1 }
//line :1398:1
								break L1
							}











								return RefArrayOf(MutableBigInteger_class, MutableBigInteger_New_J(sLong), MutableBigInteger_New_J(x-sToN1*sLong))
							}
						}



						s = MutableBigInteger_New_J(sLong) } else {
							var rootLen int32 = (bitLength-1)/n + 1
							var rootSh int32 = 0
							var rad float64 = 0.0
							var approx float64 = 0.0


							if n < 53 {

								rootSh = (bitLength - 53) / n



								rad = NN(NN(this.ToBigInteger__BigInteger()).ShiftRight_I__BigInteger(rootSh * n)).DoubleValue__D()



								rad = Math_NextUp_D__D(rad)
								approx = MutableBigInteger_RootnApprox_D_I__D(rad, n) } else {
									rootSh = rootLen - 1 }
							if rootSh == 0 {
								s = MutableBigInteger_New_I(D2I(approx) + 1) } else {

									s = MutableBigInteger_New_I1(NewIntArray((t.F_intLen-1)/n + 1))







									if n >= 53 {
										s.Self_MutableBigInteger().F_value.A[0] = 2; s.Self_MutableBigInteger().F_intLen = 1 } else {
											var wrongBits int32 = (Math_GetExponent_D__I(rad) + 1 - 53) / n




											rootSh = rootSh + wrongBits
											approx = Math_Scalb_D_I__D(approx, -wrongBits)
											s.Self_MutableBigInteger().F_value.A[0] = D2I(approx) + 1
											s.Self_MutableBigInteger().F_intLen = 1 }
									var correctBits int32 = rootLen - rootSh; L2: for {
										if correctBits < rootSh {
											s.LeftShift_I__V(correctBits)
											rootSh = rootSh - correctBits
											var x_2 MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this)
											x_2.RightShift_I__V(rootSh * n)
											MutableBigInteger_NewtonRecurrenceRootn_MutableBigInteger_MutableBigInteger_I_BigInteger__V(x_2, s, n, NN(s.ToBigInteger__BigInteger()).Pow_I__BigInteger(n-1))




											s.Add_MutableBigInteger__V(MutableBigInteger_ONE)
											correctBits = correctBits << 1; continue L2 }
//line :1459:1
										break L2
									}











									s.LeftShift_I__V(rootSh) } }
					MutableBigInteger_NewtonRecurrenceRootn_MutableBigInteger_MutableBigInteger_I_BigInteger__V(this, s, n, NN(s.ToBigInteger__BigInteger()).Pow_I__BigInteger(n-1))




				L3: for {
					var sBig *BigInteger = s.ToBigInteger__BigInteger(); var sToN1_2 *BigInteger = NN(sBig).Pow_I__BigInteger(n - 1); var rem_2 MutableBigInteger_I = MutableBigInteger_New_I1(NN(sToN1_2).Multiply_BigInteger__BigInteger(sBig).F_mag)


					if rem_2.Subtract_MutableBigInteger__I(this) <= 0 { return RefArrayOf(MutableBigInteger_class, s, rem_2) }
					MutableBigInteger_NewtonRecurrenceRootn_MutableBigInteger_MutableBigInteger_I_BigInteger__V(this, s, n, sToN1_2)
					continue L3 } } } }; panic("a2g: unreachable")
}
func MutableBigInteger_RootnApprox_D_I__D(x float64, n int32) float64 { MutableBigInteger_Init()
	var tmp1 float64; if n == 3 { tmp1 = Math_Cbrt_D__D(x) } else { tmp1 = Math_Pow_D_D__D(x, Math_NextUp_D__D(1.0/float64(n))) }; return Math_NextUp_D__D(tmp1)
}
func MutableBigInteger_NewtonRecurrenceRootn_MutableBigInteger_MutableBigInteger_I_BigInteger__V(x, s MutableBigInteger_I, n int32, sToN1 *BigInteger) { MutableBigInteger_Init()

	var dividend MutableBigInteger_I = MutableBigInteger_New()
	s.Mul_I_MutableBigInteger__V(n-1, dividend)
	var xDivSToN1 MutableBigInteger_I = MutableBigInteger_New()
	x.Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(MutableBigInteger_New_I1(sToN1.F_mag), xDivSToN1, false)
	dividend.Add_MutableBigInteger__V(xDivSToN1)
	dividend.DivideOneWord_I_MutableBigInteger__I(n, s)
}
func (t *MutableBigInteger) Impl_SqrtRem_Z__MutableBigInteger1(this MutableBigInteger_I, needRemainder bool) *RefArray {
	if t.F_intLen <= 2 {
		var x int64 = t.Impl_ToLong__J(this); var s int64 = MutableBigInteger_UnsignedLongSqrt_J__J(x); var tmp1 any = MutableBigInteger_New_I(int32(s)); var tmp2 MutableBigInteger_I



		if needRemainder {
			tmp2 = MutableBigInteger_New_J(x - s*s) } else {
//line :1504:1
				tmp2 = nil }
//line :1502:1
		return RefArrayOf(MutableBigInteger_class, tmp1, tmp2)

	} else {

		var x_2 MutableBigInteger_I = this; var tmp3 *IntArray = x_2.Self_MutableBigInteger().F_value; var shift int32 = Integer_NumberOfLeadingZeros_I__I(tmp3.A[x_2.Self_MutableBigInteger().F_offset])&-2 + x_2.Self_MutableBigInteger().F_intLen&1<<5




		if shift == 0 { } else { x_2 = MutableBigInteger_New_MutableBigInteger(x_2); x_2.LeftShift_I__V(shift) }
		var sqrtRem *RefArray = x_2.Self_MutableBigInteger().Impl_SqrtRemKaratsuba_I_Z__MutableBigInteger1(x_2, x_2.Self_MutableBigInteger().F_intLen, needRemainder)
		if shift == 0 { } else {
			var halfShift int32 = shift >> 1
			if needRemainder {
				var tmp4 *IntArray = As[MutableBigInteger_I](sqrtRem.A[0]).Self_MutableBigInteger().F_value; var tmp5 int32 = As[MutableBigInteger_I](sqrtRem.A[0]).Self_MutableBigInteger().F_offset; var s0 int64 = int64(tmp4.A[tmp5+As[MutableBigInteger_I](sqrtRem.A[0]).Self_MutableBigInteger().F_intLen-1] & int32(uint32(4294967295)>>(-halfShift&31)))









				if s0 == 0 { } else {
					var doubleProd MutableBigInteger_I = MutableBigInteger_New()
					As[MutableBigInteger_I](sqrtRem.A[0]).Mul_I_MutableBigInteger__V(int32(s0<<1), doubleProd)
					As[MutableBigInteger_I](sqrtRem.A[1]).Add_MutableBigInteger__V(doubleProd)
					var tmp6 MutableBigInteger_I = As[MutableBigInteger_I](sqrtRem.A[1]); tmp6.Subtract_MutableBigInteger__I(MutableBigInteger_New_J(s0 * s0)) }
				As[MutableBigInteger_I](sqrtRem.A[1]).RightShift_I__V(shift) }
			var tmp7 MutableBigInteger_I = As[MutableBigInteger_I](sqrtRem.A[0]); tmp7.Self_MutableBigInteger().Impl_PrimitiveRightShift_I__V(tmp7, halfShift) }
//line :1512:1
		return sqrtRem
	}
}




















func MutableBigInteger_UnsignedLongSqrt_J__J(x int64) int64 { MutableBigInteger_Init()
	var s int64; var tmp1 float64
	if x >= 0 { tmp1 = float64(x) } else { tmp1 = float64(x) + 1.8446744073709552e19 }
//line :1536:1
	s = D2L(Math_Sqrt_D__D(tmp1)); var s2 int64 = s * s; var tmp2 bool; var tmp3 bool



	tmp3 = Long_CompareUnsigned_J_J__I(x, s2) < 0; if !tmp3 { tmp3 = s > 4294967295 }; tmp2 = tmp3
//line :1539:1
	if tmp2 {
		return s - 1 } else {
//line :1539:1
			if Long_CompareUnsigned_J_J__I(x, s2+s<<1) <= 0 { return s } else {


				return s + 1
			} } }
func (t *MutableBigInteger) Impl_SqrtRemKaratsuba_I_Z__MutableBigInteger1(this MutableBigInteger_I, len_ int32, needRemainder bool) *RefArray {
	if len_ == 2 {
		var tmp1 int64 = int64(t.F_value.A[t.F_offset]) & 4294967295 << 32; var x int64 = tmp1 | int64(t.F_value.A[t.F_offset+1])&4294967295; var s int64 = MutableBigInteger_UnsignedLongSqrt_J__J(x); var sqrt MutableBigInteger_I = MutableBigInteger_New_I1(NewIntArray(t.F_intLen >> 1))



		sqrt.Self_MutableBigInteger().F_intLen = 1
		sqrt.Self_MutableBigInteger().F_value.A[0] = int32(s)
		return RefArrayOf(MutableBigInteger_class, sqrt, MutableBigInteger_New_J(x-s*s)) } else {

			var halfLen int32 = len_ >> 1; var sr *RefArray = t.Impl_SqrtRemKaratsuba_I_Z__MutableBigInteger1(this, halfLen+halfLen&1, true); var blockLen int32 = halfLen >> 1; var dividend MutableBigInteger_I = As[MutableBigInteger_I](sr.A[1])



			dividend.ShiftAddDisjoint_MutableBigInteger_I__V(t.Impl_GetBlockForSqrt_I_I_I__MutableBigInteger(this, 1, len_, blockLen), blockLen)
			var sqrt_2 MutableBigInteger_I = As[MutableBigInteger_I](sr.A[0]); var q MutableBigInteger_I = MutableBigInteger_New(); var u MutableBigInteger_I = dividend.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(sqrt_2, q)


			if q.IsOdd__Z() { u.Add_MutableBigInteger__V(sqrt_2) }
			q.RightShift_I__V(1)
			sqrt_2.ShiftAdd_MutableBigInteger_I__V(q, blockLen)
			u.ShiftAddDisjoint_MutableBigInteger_I__V(t.Impl_GetBlockForSqrt_I_I_I__MutableBigInteger(this, 0, len_, blockLen), blockLen)
			var qBig *BigInteger = q.ToBigInteger__BigInteger(); var qSqr MutableBigInteger_I = MutableBigInteger_New_I1(NN(qBig).Multiply_BigInteger__BigInteger(qBig).F_mag); var rem MutableBigInteger_I


			if needRemainder {

				rem = u
				if rem.Subtract_MutableBigInteger__I(qSqr) < 0 {
					var twiceSqrt MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(sqrt_2)
					twiceSqrt.LeftShift_I__V(1)
					rem.Add_MutableBigInteger__V(MutableBigInteger_ONE)
					rem.Subtract_MutableBigInteger__I(twiceSqrt)
					sqrt_2.Subtract_MutableBigInteger__I(MutableBigInteger_ONE) } } else {
						rem = nil; if u.Compare_MutableBigInteger__I(qSqr) < 0 { sqrt_2.Subtract_MutableBigInteger__I(MutableBigInteger_ONE) } }
			sr.Store(1, rem)
//line :1566:1
			return sr
		}
}













func (t *MutableBigInteger) Impl_GetBlockForSqrt_I_I_I__MutableBigInteger(this MutableBigInteger_I, blockIndex, len_, blockLen int32) MutableBigInteger_I {
	var to int32 = t.F_offset + len_ - blockIndex*blockLen
	var from int32 = 0

	from = to - blockLen
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = from < to; if tmp2 { tmp2 = t.F_value.A[from] == 0 }; tmp1 = tmp2; if tmp1 { from = from + 1; continue L1 }; break L1 }
	if from == to { return MutableBigInteger_New() } else { return MutableBigInteger_New_I1(Arrays_CopyOfRange_I1_I_I__I1(t.F_value, from, to))
	} }
func (t *MutableBigInteger) Impl_HybridGCD_MutableBigInteger__MutableBigInteger(this, b MutableBigInteger_I) MutableBigInteger_I {
	var a MutableBigInteger_I = this; var q MutableBigInteger_I = MutableBigInteger_New()

L1: for { if !(b.Self_MutableBigInteger().F_intLen == 0) {
	var tmp1 int32 = a.Self_MutableBigInteger().F_intLen; if Math_Abs_I__I(tmp1-b.Self_MutableBigInteger().F_intLen) < 2 {
		return a.Self_MutableBigInteger().Impl_BinaryGCD_MutableBigInteger__MutableBigInteger(a, b) }
	var r MutableBigInteger_I = a.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, q); a = b; b = r
//line :1593:1
	continue L1 }; break L1 }
//line :1591:1
	return a
}






func (t *MutableBigInteger) Impl_BinaryGCD_MutableBigInteger__MutableBigInteger(this, v MutableBigInteger_I) MutableBigInteger_I {
	var u MutableBigInteger_I = this; var r MutableBigInteger_I = MutableBigInteger_New(); var s1 int32 = u.Self_MutableBigInteger().Impl_GetLowestSetBit__I(u); var s2 int32 = v.Self_MutableBigInteger().Impl_GetLowestSetBit__I(v); var k int32



	if s1 < s2 { k = s1 } else { k = s2 }
	if k == 0 { } else { u.RightShift_I__V(k); v.RightShift_I__V(k) }
	var uOdd bool = k == s1; var t_ MutableBigInteger_I
	if uOdd { t_ = v } else { t_ = u }
//line :1606:1
	var tsign int32

	if uOdd { tsign = -1 } else { tsign = 1 }
//line :1606:1
	var lb int32 = 0



L1: for { var tmp1 int32; lb = t_.Self_MutableBigInteger().Impl_GetLowestSetBit__I(t_); tmp1 = lb; if tmp1 >= 0 {
	t_.RightShift_I__V(lb)
	if tsign > 0 { u = t_ } else { v = t_ }
	var tmp2 bool; var tmp3 bool; tmp3 = u.Self_MutableBigInteger().F_intLen < 2; if tmp3 { tmp3 = v.Self_MutableBigInteger().F_intLen < 2 }; tmp2 = tmp3; if tmp2 {
		var tmp4 *IntArray = u.Self_MutableBigInteger().F_value; var x int32 = tmp4.A[u.Self_MutableBigInteger().F_offset]; var tmp5 *IntArray = v.Self_MutableBigInteger().F_value; var y int32 = tmp5.A[v.Self_MutableBigInteger().F_offset]

		x = MutableBigInteger_BinaryGcd_I_I__I(x, y)
		r.Self_MutableBigInteger().F_value.A[0] = x
		r.Self_MutableBigInteger().F_intLen = 1
		r.Self_MutableBigInteger().F_offset = 0
		if k > 0 { r.LeftShift_I__V(k) }
		return r }
	var tmp6 int32; tsign = u.Self_MutableBigInteger().Impl_Difference_MutableBigInteger__I(u, v); tmp6 = tsign; if tmp6 == 0 { break L1 }
	var tmp7 MutableBigInteger_I; if tsign >= 0 { tmp7 = u } else { tmp7 = v }; t_ = tmp7
//line :1610:1
	continue L1 }; break L1
}












	if k > 0 { u.LeftShift_I__V(k) }
//line :1606:1
	return u
}



















func MutableBigInteger_BinaryGcd_I_I__I(a, b int32) int32 { MutableBigInteger_Init()
	if b == 0 { return a } else { if a == 0 { return b } else {



		var aZeros int32 = Integer_NumberOfTrailingZeros_I__I(a); var bZeros int32 = Integer_NumberOfTrailingZeros_I__I(b)

		a = int32(uint32(a) >> (aZeros & 31))
		b = int32(uint32(b) >> (bZeros & 31))
		var t_ int32; if aZeros < bZeros { t_ = aZeros } else { t_ = bZeros }
	L1: for { if !(a == b) {
		if a+-2147483648 > b+-2147483648 {


			a = a - b
			a = int32(uint32(a) >> (Integer_NumberOfTrailingZeros_I__I(a) & 31)) } else {

				b = b - a
				b = int32(uint32(b) >> (Integer_NumberOfTrailingZeros_I__I(b) & 31)) }
//line :1637:1
		continue L1 }; break L1
	}







		return a << (t_ & 31)
	} } }
func (t *MutableBigInteger) Impl_MutableModInverse_MutableBigInteger__MutableBigInteger(this, p MutableBigInteger_I) MutableBigInteger_I {
	if p.IsOdd__Z() {
		return t.Impl_ModInverse_MutableBigInteger__MutableBigInteger(this, p) } else {

			if this.IsEven__Z() { panic(Thrown(ArithmeticException_New_String(Lit_1289))) }
			var powersOf2 int32 = p.Self_MutableBigInteger().Impl_GetLowestSetBit__I(p); var oddMod MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(p)

			oddMod.RightShift_I__V(powersOf2)
			if oddMod.IsOne__Z() {
				return this.ModInverseMP2_I__MutableBigInteger(powersOf2) } else {
					var oddPart MutableBigInteger_I = t.Impl_ModInverse_MutableBigInteger__MutableBigInteger(this, oddMod); var evenPart MutableBigInteger_I = this.ModInverseMP2_I__MutableBigInteger(powersOf2); var y1 MutableBigInteger_I = MutableBigInteger_ModInverseBP2_MutableBigInteger_I__MutableBigInteger(oddMod, powersOf2); var y2 MutableBigInteger_I = oddMod.ModInverseMP2_I__MutableBigInteger(powersOf2); var temp1 MutableBigInteger_I = MutableBigInteger_New(); var temp2 MutableBigInteger_I = MutableBigInteger_New(); var result MutableBigInteger_I = MutableBigInteger_New()






					oddPart.LeftShift_I__V(powersOf2)
					oddPart.Multiply_MutableBigInteger_MutableBigInteger__V(y1, result)
					oddPart.Clear__V()
					evenPart.Multiply_MutableBigInteger_MutableBigInteger__V(oddMod, temp1)
					temp1.Multiply_MutableBigInteger_MutableBigInteger__V(y2, temp2)
					result.Add_MutableBigInteger__V(temp2)
					return result.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(p, temp1)
				} } }
func (t *MutableBigInteger) Impl_ModInverseMP2_I__MutableBigInteger(this MutableBigInteger_I, k int32) MutableBigInteger_I {
	if this.IsEven__Z() { panic(Thrown(ArithmeticException_New_String(Lit_1290))) }
	if k > 64 {
		return this.EuclidModInverse_I__MutableBigInteger(k) } else {
			var t_ int32 = MutableBigInteger_InverseMod32_I__I(t.F_value.A[t.F_offset+t.F_intLen-1])


			if k < 33 {

				var tmp1 int32
				if k == 32 { tmp1 = t_ } else {

					tmp1 = t_ & (1<<(k&31) - 1) }
//line :1682:1
				t_ = tmp1



				return MutableBigInteger_New_I(t_) } else {
					var pLong int64 = int64(t.F_value.A[t.F_offset+t.F_intLen-1]) & 4294967295





					if t.F_intLen > 1 {
						pLong = pLong | int64(t.F_value.A[t.F_offset+t.F_intLen-2])<<32
					}






					var tLong int64 = int64(t_) & 4294967295
					tLong = tLong * (2 - pLong*tLong)



					var tmp2 int64
					if k == 64 { tmp2 = tLong } else {

						tmp2 = tLong & (1<<(k&63) - 1) }
//line :1707:1
					tLong = tmp2



					var result MutableBigInteger_I = MutableBigInteger_New_I1(NewIntArray(2))
					result.Self_MutableBigInteger().F_value.A[0] = int32(int64(uint64(tLong) >> 32))
					result.Self_MutableBigInteger().F_value.A[1] = int32(tLong)
					result.Self_MutableBigInteger().F_intLen = 2
					result.Normalize__V()
//line :1711:1
					return result
				}
		}
}



func MutableBigInteger_InverseMod32_I__I(val int32) int32 { MutableBigInteger_Init()
	var t_ int32 = val
	t_ = t_ * (2 - val*t_)
	t_ = t_ * (2 - val*t_)
	t_ = t_ * (2 - val*t_)
	t_ = t_ * (2 - val*t_)
//line :1719:1
	return t_
}





func MutableBigInteger_InverseMod64_J__J(val int64) int64 { MutableBigInteger_Init()
	var t_ int64 = val
	t_ = t_ * (2 - val*t_)
	t_ = t_ * (2 - val*t_)
	t_ = t_ * (2 - val*t_)
	t_ = t_ * (2 - val*t_)
	t_ = t_ * (2 - val*t_)
	if !A2g_AssertionsDisabled && !(t_*val == 1) { panic(Thrown(AssertionError_New())) }
//line :1727:1
	return t_
}







func MutableBigInteger_ModInverseBP2_MutableBigInteger_I__MutableBigInteger(mod MutableBigInteger_I, k int32) MutableBigInteger_I { MutableBigInteger_Init()
	return MutableBigInteger_Fixup_MutableBigInteger_MutableBigInteger_I__MutableBigInteger(MutableBigInteger_New_I(1), MutableBigInteger_New_MutableBigInteger(mod), k)
}
func (t *MutableBigInteger) Impl_ModInverse_MutableBigInteger__MutableBigInteger(this, mod MutableBigInteger_I) MutableBigInteger_I {
	var p MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(mod); var f MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this); var g MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(p); var c *SignedMutableBigInteger = SignedMutableBigInteger_New_I(1); var d *SignedMutableBigInteger = SignedMutableBigInteger_New(); var temp MutableBigInteger_I; var sTemp *SignedMutableBigInteger
	var k int32 = 0






	if f.IsEven__Z() {
		var trailingZeros int32 = f.Self_MutableBigInteger().Impl_GetLowestSetBit__I(f)
		f.RightShift_I__V(trailingZeros)
		NN(d).LeftShift_I__V(trailingZeros)
		k = trailingZeros }
L1: for { if !f.IsOne__Z() {
	if f.IsZero__Z() { panic(Thrown(ArithmeticException_New_String(Lit_1289))) }
	if f.Compare_MutableBigInteger__I(g) < 0 {
		temp = f
		f = g
		g = temp
		sTemp = d
		d = c
		c = sTemp }
	var tmp1 *IntArray = f.Self_MutableBigInteger().F_value; var tmp2 int32 = f.Self_MutableBigInteger().F_offset; var tmp3 int32 = tmp1.A[tmp2+f.Self_MutableBigInteger().F_intLen-1]; var tmp4 *IntArray = g.Self_MutableBigInteger().F_value; var tmp5 int32 = g.Self_MutableBigInteger().F_offset; if (tmp3^tmp4.A[tmp5+g.Self_MutableBigInteger().F_intLen-1])&3 == 0 {









		f.Subtract_MutableBigInteger__I(g); NN(c).SignedSubtract_SignedMutableBigInteger__V(d) } else {
			f.Add_MutableBigInteger__V(g); NN(c).SignedAdd_SignedMutableBigInteger__V(d) }
	var trailingZeros_2 int32 = f.Self_MutableBigInteger().Impl_GetLowestSetBit__I(f)
	f.RightShift_I__V(trailingZeros_2)
	NN(d).LeftShift_I__V(trailingZeros_2)
	k = k + trailingZeros_2
//line :1753:1
	continue L1 }; break L1
}























	if NN(c).Compare_MutableBigInteger__I(p) >= 0 {
		var remainder MutableBigInteger_I = NN(c).Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(p, MutableBigInteger_New()); NN(c).CopyValue_MutableBigInteger__V(remainder) }
	if c.F_sign < 0 { NN(c).SignedAdd_MutableBigInteger__V(p) }
	return MutableBigInteger_Fixup_MutableBigInteger_MutableBigInteger_I__MutableBigInteger(Up_SignedMutableBigInteger_MutableBigInteger(c), p, k)
}
func MutableBigInteger_Fixup_MutableBigInteger_MutableBigInteger_I__MutableBigInteger(c, p MutableBigInteger_I, k int32) MutableBigInteger_I { MutableBigInteger_Init()

	var temp MutableBigInteger_I = MutableBigInteger_New(); var tmp1 *IntArray = p.Self_MutableBigInteger().F_value; var tmp2 int32 = p.Self_MutableBigInteger().F_offset; var r int32 = -MutableBigInteger_InverseMod32_I__I(tmp1.A[tmp2+p.Self_MutableBigInteger().F_intLen-1]); var i int32 = 0; var numWords int32 = k >> 5




L1: for {

	if i < numWords {
		var tmp3 *IntArray = c.Self_MutableBigInteger().F_value; var tmp4 int32 = c.Self_MutableBigInteger().F_offset; var v int32 = r * tmp3.A[tmp4+c.Self_MutableBigInteger().F_intLen-1]




		p.Mul_I_MutableBigInteger__V(v, temp)
		c.Add_MutableBigInteger__V(temp)
		c.Self_MutableBigInteger().F_intLen = c.Self_MutableBigInteger().F_intLen - 1
		i, numWords = i+1, numWords; continue L1 }
//line :1790:1
	break L1
}










	var numBits int32 = k & 31
	if numBits == 0 { } else {
		var tmp5 *IntArray = c.Self_MutableBigInteger().F_value; var tmp6 int32 = c.Self_MutableBigInteger().F_offset; var v_2 int32 = r * tmp5.A[tmp6+c.Self_MutableBigInteger().F_intLen-1]





		v_2 = v_2 & (1<<(numBits&31) - 1)
		p.Mul_I_MutableBigInteger__V(v_2, temp)
		c.Add_MutableBigInteger__V(temp)
		c.RightShift_I__V(numBits) }
	if c.Compare_MutableBigInteger__I(p) >= 0 { c = c.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(p, MutableBigInteger_New()) }
//line :1802:1
	return c
}













func (t *MutableBigInteger) Impl_EuclidModInverse_I__MutableBigInteger(this MutableBigInteger_I, k int32) MutableBigInteger_I {
	var b MutableBigInteger_I = MutableBigInteger_New_I(1)
	b.LeftShift_I__V(k)
	var mod MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(b); var a MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(this); var q MutableBigInteger_I = MutableBigInteger_New(); var r MutableBigInteger_I = b.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(a, q)
	var swapper MutableBigInteger_I = b



	b = r
	r = swapper
	var t1 MutableBigInteger_I = MutableBigInteger_New_MutableBigInteger(q); var t0 MutableBigInteger_I = MutableBigInteger_New_I(1); var temp MutableBigInteger_I = MutableBigInteger_New()


L1: for { if !b.IsOne__Z() {
	r = a.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, q)
	if r.Self_MutableBigInteger().F_intLen == 0 { panic(Thrown(ArithmeticException_New_String(Lit_1289))) }
	swapper = r
	a = swapper
	if q.Self_MutableBigInteger().F_intLen == 1 {
		var tmp1 *IntArray = q.Self_MutableBigInteger().F_value; t1.Mul_I_MutableBigInteger__V(tmp1.A[q.Self_MutableBigInteger().F_offset], temp) } else {
			q.Multiply_MutableBigInteger_MutableBigInteger__V(t1, temp) }
	swapper = q
	q = temp
	temp = swapper
	t0.Add_MutableBigInteger__V(q)
	if a.IsOne__Z() { return t0 }
	r = b.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(a, q)
	if r.Self_MutableBigInteger().F_intLen == 0 { panic(Thrown(ArithmeticException_New_String(Lit_1289))) }
	swapper = b
	b = r
	if q.Self_MutableBigInteger().F_intLen == 1 {
		var tmp2 *IntArray = q.Self_MutableBigInteger().F_value; t0.Mul_I_MutableBigInteger__V(tmp2.A[q.Self_MutableBigInteger().F_offset], temp) } else {
			q.Multiply_MutableBigInteger_MutableBigInteger__V(t0, temp) }
	swapper = q
	q = temp
	temp = swapper
	t1.Add_MutableBigInteger__V(q)
//line :1830:1
	continue L1 }; break L1
}






















	mod.Subtract_MutableBigInteger__I(t1)
//line :1827:1
	return mod
}





























type MutableBigInteger struct{ Object; F_value *IntArray; F_intLen, F_offset int32 }

type MutableBigInteger_I interface{ Object_I; Self_MutableBigInteger() *MutableBigInteger; ToBigInteger_I__BigInteger(p0 int32) *BigInteger; ToBigInteger__BigInteger() *BigInteger; ToBigDecimal_I_I__BigDecimal(p0, p1 int32) *BigDecimal; ToCompactValue_I__J(p0 int32) int64; Clear__V(); Reset__V(); Compare_MutableBigInteger__I(p0 MutableBigInteger_I) int32; CompareHalf_MutableBigInteger__I(p0 MutableBigInteger_I) int32; Normalize__V(); ToIntArray__I1() *IntArray; SetInt_I_I__V(p0, p1 int32); SetValue_I1_I__V(p0 *IntArray, p1 int32); CopyValue_MutableBigInteger__V(p0 MutableBigInteger_I); CopyValue_I1__V(p0 *IntArray); IsOne__Z() bool; IsZero__Z() bool; IsEven__Z() bool; IsOdd__Z() bool; IsNormal__Z() bool; SafeRightShift_I__V(p0 int32); RightShift_I__V(p0 int32); SafeLeftShift_I__V(p0 int32); LeftShift_I__V(p0 int32); Add_MutableBigInteger__V(p0 MutableBigInteger_I); AddShifted_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32); AddDisjoint_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32); AddLower_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32); ShiftAdd_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32); ShiftAddDisjoint_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32); Subtract_MutableBigInteger__I(p0 MutableBigInteger_I) int32; Multiply_MutableBigInteger_MutableBigInteger__V(p0, p1 MutableBigInteger_I); Mul_I_MutableBigInteger__V(p0 int32, p1 MutableBigInteger_I); DivideOneWord_I_MutableBigInteger__I(p0 int32, p1 MutableBigInteger_I) int32; Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I; Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(p0, p1 MutableBigInteger_I, p2 bool) MutableBigInteger_I; DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I; DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(p0, p1 MutableBigInteger_I, p2 bool) MutableBigInteger_I; DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I; BitLength__J() int64; Divide_J_MutableBigInteger__J(p0 int64, p1 MutableBigInteger_I) int64; RootnRem_I__MutableBigInteger1(p0 int32) *RefArray; SqrtRem_Z__MutableBigInteger1(p0 bool) *RefArray; HybridGCD_MutableBigInteger__MutableBigInteger(p0 MutableBigInteger_I) MutableBigInteger_I; MutableModInverse_MutableBigInteger__MutableBigInteger(p0 MutableBigInteger_I) MutableBigInteger_I; ModInverseMP2_I__MutableBigInteger(p0 int32) MutableBigInteger_I; EuclidModInverse_I__MutableBigInteger(p0 int32) MutableBigInteger_I }

func (t *MutableBigInteger) Self_MutableBigInteger() *MutableBigInteger { return t }

var MutableBigInteger_ONE MutableBigInteger_I

const MutableBigInteger_KNUTH_POW2_THRESH_LEN int32 = 6

const MutableBigInteger_KNUTH_POW2_THRESH_ZEROS int32 = 3

var MutableBigInteger_init ClassInit

func MutableBigInteger_Init() { if !MutableBigInteger_init.Done() { MutableBigInteger_init.Run(MutableBigInteger_clinit) } }

func MutableBigInteger_clinit() { MutableBigInteger_ONE = MutableBigInteger_New_I(1) }

func (t *MutableBigInteger) AddShifted_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_AddShifted_MutableBigInteger_I__V(t, p0, p1) }

func (t *MutableBigInteger) Subtract_MutableBigInteger__I(p0 MutableBigInteger_I) int32 { return t.Impl_Subtract_MutableBigInteger__I(t, p0) }

func (t *MutableBigInteger) IsOdd__Z() bool { return t.Impl_IsOdd__Z(t) }

func (t *MutableBigInteger) CopyValue_I1__V(p0 *IntArray) { t.Impl_CopyValue_I1__V(t, p0) }

func (t *MutableBigInteger) DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(t, p0, p1) }

func (t *MutableBigInteger) Clear__V() { t.Impl_Clear__V(t) }

func (t *MutableBigInteger) CopyValue_MutableBigInteger__V(p0 MutableBigInteger_I) { t.Impl_CopyValue_MutableBigInteger__V(t, p0) }

func (t *MutableBigInteger) SafeRightShift_I__V(p0 int32) { t.Impl_SafeRightShift_I__V(t, p0) }

func (t *MutableBigInteger) ToIntArray__I1() *IntArray { return t.Impl_ToIntArray__I1(t) }

func (t *MutableBigInteger) Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(p0, p1 MutableBigInteger_I, p2 bool) MutableBigInteger_I { return t.Impl_Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(t, p0, p1, p2) }

func (t *MutableBigInteger) Add_MutableBigInteger__V(p0 MutableBigInteger_I) { t.Impl_Add_MutableBigInteger__V(t, p0) }

func (t *MutableBigInteger) Mul_I_MutableBigInteger__V(p0 int32, p1 MutableBigInteger_I) { t.Impl_Mul_I_MutableBigInteger__V(t, p0, p1) }

func (t *MutableBigInteger) DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(t, p0, p1) }

func (t *MutableBigInteger) IsEven__Z() bool { return t.Impl_IsEven__Z(t) }

func (t *MutableBigInteger) DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(p0, p1 MutableBigInteger_I, p2 bool) MutableBigInteger_I { return t.Impl_DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(t, p0, p1, p2) }

func (t *MutableBigInteger) LeftShift_I__V(p0 int32) { t.Impl_LeftShift_I__V(t, p0) }

func (t *MutableBigInteger) SafeLeftShift_I__V(p0 int32) { t.Impl_SafeLeftShift_I__V(t, p0) }

func (t *MutableBigInteger) IsNormal__Z() bool { return t.Impl_IsNormal__Z(t) }

func (t *MutableBigInteger) ShiftAdd_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_ShiftAdd_MutableBigInteger_I__V(t, p0, p1) }

func (t *MutableBigInteger) Normalize__V() { t.Impl_Normalize__V(t) }

func (t *MutableBigInteger) SetValue_I1_I__V(p0 *IntArray, p1 int32) { t.Impl_SetValue_I1_I__V(t, p0, p1) }

func (t *MutableBigInteger) ShiftAddDisjoint_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_ShiftAddDisjoint_MutableBigInteger_I__V(t, p0, p1) }

func (t *MutableBigInteger) Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(t, p0, p1) }

func (t *MutableBigInteger) ModInverseMP2_I__MutableBigInteger(p0 int32) MutableBigInteger_I { return t.Impl_ModInverseMP2_I__MutableBigInteger(t, p0) }

func (t *MutableBigInteger) MutableModInverse_MutableBigInteger__MutableBigInteger(p0 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_MutableModInverse_MutableBigInteger__MutableBigInteger(t, p0) }

func (t *MutableBigInteger) AddLower_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_AddLower_MutableBigInteger_I__V(t, p0, p1) }

func (t *MutableBigInteger) AddDisjoint_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_AddDisjoint_MutableBigInteger_I__V(t, p0, p1) }

func (t *MutableBigInteger) IsOne__Z() bool { return t.Impl_IsOne__Z(t) }

func (t *MutableBigInteger) CompareHalf_MutableBigInteger__I(p0 MutableBigInteger_I) int32 { return t.Impl_CompareHalf_MutableBigInteger__I(t, p0) }

func (t *MutableBigInteger) SetInt_I_I__V(p0, p1 int32) { t.Impl_SetInt_I_I__V(t, p0, p1) }

func (t *MutableBigInteger) BitLength__J() int64 { return t.Impl_BitLength__J(t) }

func (t *MutableBigInteger) ToBigDecimal_I_I__BigDecimal(p0, p1 int32) *BigDecimal { return t.Impl_ToBigDecimal_I_I__BigDecimal(t, p0, p1) }

func (t *MutableBigInteger) RootnRem_I__MutableBigInteger1(p0 int32) *RefArray { return t.Impl_RootnRem_I__MutableBigInteger1(t, p0) }

func (t *MutableBigInteger) HybridGCD_MutableBigInteger__MutableBigInteger(p0 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_HybridGCD_MutableBigInteger__MutableBigInteger(t, p0) }

func (t *MutableBigInteger) DivideOneWord_I_MutableBigInteger__I(p0 int32, p1 MutableBigInteger_I) int32 { return t.Impl_DivideOneWord_I_MutableBigInteger__I(t, p0, p1) }

func (t *MutableBigInteger) RightShift_I__V(p0 int32) { t.Impl_RightShift_I__V(t, p0) }

func (t *MutableBigInteger) IsZero__Z() bool { return t.Impl_IsZero__Z(t) }

func (t *MutableBigInteger) Reset__V() { t.Impl_Reset__V(t) }

func (t *MutableBigInteger) Divide_J_MutableBigInteger__J(p0 int64, p1 MutableBigInteger_I) int64 { return t.Impl_Divide_J_MutableBigInteger__J(t, p0, p1) }

func (t *MutableBigInteger) Multiply_MutableBigInteger_MutableBigInteger__V(p0, p1 MutableBigInteger_I) { t.Impl_Multiply_MutableBigInteger_MutableBigInteger__V(t, p0, p1) }

func (t *MutableBigInteger) ToBigInteger__BigInteger() *BigInteger { return t.Impl_ToBigInteger__BigInteger(t) }

func (t *MutableBigInteger) SqrtRem_Z__MutableBigInteger1(p0 bool) *RefArray { return t.Impl_SqrtRem_Z__MutableBigInteger1(t, p0) }

func (t *MutableBigInteger) EuclidModInverse_I__MutableBigInteger(p0 int32) MutableBigInteger_I { return t.Impl_EuclidModInverse_I__MutableBigInteger(t, p0) }

func (t *MutableBigInteger) ToBigInteger_I__BigInteger(p0 int32) *BigInteger { return t.Impl_ToBigInteger_I__BigInteger(t, p0) }

func (t *MutableBigInteger) Compare_MutableBigInteger__I(p0 MutableBigInteger_I) int32 { return t.Impl_Compare_MutableBigInteger__I(t, p0) }

func (t *MutableBigInteger) ToCompactValue_I__J(p0 int32) int64 { return t.Impl_ToCompactValue_I__J(t, p0) }

func (t *MutableBigInteger) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MutableBigInteger) Ref() any { if t == nil { return nil }; return t }

func (t *MutableBigInteger) GetClass__Class() *Class { return MutableBigInteger_class }

func (t *MutableBigInteger) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MutableBigInteger) CloneShallow() any { panic(CloneNotSupported(t)) }

func MutableBigInteger_InstanceOf(x any) bool { _, ok := x.(MutableBigInteger_I); return ok }

func MutableBigInteger_Cast(x any) MutableBigInteger_I { if x == nil { return nil }; v, ok := x.(MutableBigInteger_I); if !ok { panic(ClassCast(x, MutableBigInteger_class)) }; return v }
