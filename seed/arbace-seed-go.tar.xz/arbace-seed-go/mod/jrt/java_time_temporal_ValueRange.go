//line java_time_temporal_ValueRange.ae:1
package jrt



















func ValueRange_Of_J_J__ValueRange(min_, max_ int64) *ValueRange {
	if min_ > max_ {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2527))) }
	return ValueRange_New_J_J_J_J(min_, min_, max_, max_)
}
func ValueRange_Of_J_J_J__ValueRange(min_, maxSmallest, maxLargest int64) *ValueRange {
	if min_ > maxSmallest {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2528))) }
	return ValueRange_Of_J_J_J_J__ValueRange(min_, min_, maxSmallest, maxLargest)
}
func ValueRange_Of_J_J_J_J__ValueRange(minSmallest, minLargest, maxSmallest, maxLargest int64) *ValueRange {

	if minSmallest > minLargest {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2529)))
	}
	if maxSmallest > maxLargest {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2530)))
	}
	if minLargest > maxLargest {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2531)))
	}
	if minSmallest > maxSmallest {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2532)))
	}
	return ValueRange_New_J_J_J_J(minSmallest, minLargest, maxSmallest, maxLargest)
}
func ValueRange_New_J_J_J_J(p0, p1, p2, p3 int64) *ValueRange { t := &ValueRange{}; t.Ctor_J_J_J_J(p0, p1, p2, p3); return t }
//line :47:1
func (t *ValueRange) Ctor_J_J_J_J(minSmallest, minLargest, maxSmallest, maxLargest int64) {
	t.F_minSmallest = minSmallest
	t.F_minLargest = minLargest
	t.F_maxSmallest = maxSmallest
	t.F_maxLargest = maxLargest
}
func (t *ValueRange) IsFixed__Z() bool {
	var tmp1 bool; tmp1 = t.F_minSmallest == t.F_minLargest; if tmp1 { tmp1 = t.F_maxSmallest == t.F_maxLargest }; return tmp1
}
func (t *ValueRange) GetMinimum__J() int64 { return t.F_minSmallest }

func (t *ValueRange) GetLargestMinimum__J() int64 { return t.F_minLargest }

func (t *ValueRange) GetSmallestMaximum__J() int64 { return t.F_maxSmallest }

func (t *ValueRange) GetMaximum__J() int64 { return t.F_maxLargest }

func (t *ValueRange) IsIntValue__Z() bool {
	var tmp1 bool; tmp1 = t.GetMinimum__J() >= -2147483648; if tmp1 { tmp1 = t.GetMaximum__J() <= 2147483647 }; return tmp1
}
func (t *ValueRange) IsValidValue_J__Z(value int64) bool {
	var tmp1 bool; tmp1 = value >= t.GetMinimum__J(); if tmp1 { tmp1 = value <= t.GetMaximum__J() }; return tmp1
}
func (t *ValueRange) IsValidIntValue_J__Z(value int64) bool {
	var tmp1 bool; tmp1 = t.IsIntValue__Z(); if tmp1 { tmp1 = t.IsValidValue_J__Z(value) }; return tmp1
}
func (t *ValueRange) CheckValidValue_J_TemporalField__J(value int64, field TemporalField) int64 {
	if t.IsValidValue_J__Z(value) == false {
		panic(Thrown(DateTimeException_New_String(t.GenInvalidFieldMessage_TemporalField_J__String(field, value)))) }
//line :73:1
	return value
}



func (t *ValueRange) CheckValidIntValue_J_TemporalField__I(value int64, field TemporalField) int32 {
	if t.IsValidIntValue_J__Z(value) == false {
		panic(Thrown(DateTimeException_New_String(t.GenInvalidFieldMessage_TemporalField_J__String(field, value)))) }
	return int32(value)
}
func (t *ValueRange) GenInvalidFieldMessage_TemporalField_J__String(field TemporalField, value int64) *String {
	if !(field == nil) {
		return Concat(Lit_2515, StrOfObj(field), Lit_2516, StrOfObj(t), Lit_2517, StrOfLong(value)) } else {
			return Concat(Lit_2533, StrOfObj(t), Lit_2517, StrOfLong(value))
		}
}











func (t *ValueRange) Equals_O__Z(obj any) bool {
	if any(obj) == any(t) { return true } else {

		var tmp1 any = obj; if ValueRange_InstanceOf(tmp1) { var other *ValueRange = ValueRange_Cast(tmp1); var tmp2 int64 = t.F_minSmallest
			if tmp2 == other.F_minSmallest {
				var tmp3 int64 = t.F_minLargest; if tmp3 == other.F_minLargest {
					var tmp4 int64 = t.F_maxSmallest; if tmp4 == other.F_maxSmallest {
						var tmp5 int64 = t.F_maxLargest; return tmp5 == other.F_maxLargest } else {
//line :106:1
							return false } } else {
//line :105:1
								return false
							} } else {
//line :104:1
								return false
							}
		} else {
//line :103:1
			return false
		}
	}
}






func (t *ValueRange) HashCode__I() int32 {
	var hash int64 = t.F_minSmallest + t.F_minLargest<<16 + t.F_minLargest>>48 + t.F_maxSmallest<<32 + t.F_maxSmallest>>32 + t.F_maxLargest<<48 + t.F_maxLargest>>16









	return Long_HashCode_J__I(hash)
}
func (t *ValueRange) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New()
	NN(buf).Append_J__StringBuilder(t.F_minSmallest)
	if t.F_minSmallest == t.F_minLargest { } else { NN(NN(buf).Append_C__StringBuilder(47)).Append_J__StringBuilder(t.F_minLargest) }
	NN(NN(buf).Append_String__StringBuilder(Lit_2534)).Append_J__StringBuilder(t.F_maxSmallest)
	if t.F_maxSmallest == t.F_maxLargest { } else { NN(NN(buf).Append_C__StringBuilder(47)).Append_J__StringBuilder(t.F_maxLargest) }
	return NN(buf).ToString__String()
}


type ValueRange struct{ Object; F_minSmallest, F_minLargest, F_maxSmallest, F_maxLargest int64 }

func (t *ValueRange) Is_Serializable() {}

const ValueRange_serialVersionUID int64 = -7317881728594519368

func (t *ValueRange) Ref() any { if t == nil { return nil }; return t }

func (t *ValueRange) GetClass__Class() *Class { return ValueRange_class }

func (t *ValueRange) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ValueRange) CloneShallow() any { panic(CloneNotSupported(t)) }

func ValueRange_InstanceOf(x any) bool { _, ok := x.(*ValueRange); return ok }

func ValueRange_Cast(x any) *ValueRange { if x == nil { return nil }; v, ok := x.(*ValueRange); if !ok { panic(ClassCast(x, ValueRange_class)) }; return v }
