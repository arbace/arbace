//line java_io_InputStream.ae:1
package jrt

import "sync/atomic"











func (t *InputStream) Ctor(this InputStream_I) {}

func InputStream_NullInputStream__InputStream() InputStream_I {
	return InputStream_1_New()
}

func (t *InputStream_1) EnsureOpen__V() {
	if t.F_closed.Load() { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *InputStream_1) Available__I() int32 {
	t.EnsureOpen__V()
//line :24:1
	return 0
}


func (t *InputStream_1) Read__I() int32 {
	t.EnsureOpen__V()
//line :28:1
	return -1
}


func (t *InputStream_1) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	if len_ == 0 { return 0 } else { t.EnsureOpen__V(); return -1
	} }
func (t *InputStream_1) ReadAllBytes__B1() *ByteArray {
	t.EnsureOpen__V()
	return NewByteArray(0)
}
func (t *InputStream_1) ReadNBytes_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	t.EnsureOpen__V()
//line :40:1
	return 0
}



func (t *InputStream_1) ReadNBytes_I__B1(len_ int32) *ByteArray {
	if len_ < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_81))) }
	t.EnsureOpen__V()
	return NewByteArray(0)
}
func (t *InputStream_1) Skip_J__J(n int64) int64 {
	t.EnsureOpen__V()
//line :50:1
	return 0
}


func (t *InputStream_1) SkipNBytes_J__V(n int64) {
	t.EnsureOpen__V()
	if n > 0 { panic(Thrown(EOFException_New()))
	} }
func (t *InputStream_1) TransferTo_OutputStream__J(out OutputStream_I) int64 {
	Objects_RequireNonNull_O__O(out)
	t.EnsureOpen__V()
//line :58:1
	return 0
}



func (t *InputStream_1) Close__V() {
	t.F_closed.Store(true)
}


func (t *InputStream) Impl_Read_B1__I(this InputStream_I, b *ByteArray) int32 {
	return this.Read_B1_I_I__I(b, 0, int32(len(b.A)))
}
func (t *InputStream) Impl_Read_B1_I_I__I(this InputStream_I, b *ByteArray, off, len_ int32) int32 {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	if len_ == 0 { return 0 } else {

		var c int32 = this.Read__I()
		if c == -1 { return -1 } else {


			b.A[off] = int8(c)
			var i int32 = 1; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

			L1: for { if i < len_ {
				c = this.Read__I()
				if c == -1 { break L1 }
				b.A[off+i] = int8(c)
				i = i + 1
//line :82:1
				continue L1 }; break L1
			}


				return nil }()
//line :81:1
			if tmp1 != nil { if IOException_InstanceOf(tmp1) { var ee IOException_I = IOException_Cast(tmp1); _ = ee } else { panic(tmp1) } }
//line :80:1
			return i
		}
	}
}








func (t *InputStream) Impl_ReadAllBytes__B1(this InputStream_I) *ByteArray {
	return this.ReadNBytes_I__B1(2147483647)
}
func (t *InputStream) Impl_ReadNBytes_I__B1(this InputStream_I, len_ int32) *ByteArray {
	if len_ < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_81))) }
	var bufs List; var result *ByteArray
	var total int32 = 0
	var remaining int32 = len_
	var n int32 = 0

L1: for {
	var buf *ByteArray = NewByteArray(Math_Min_I_I__I(remaining, 16384))
	var nread int32 = 0
L2: for { var tmp1 int32; n = this.Read_B1_I_I__I(buf, nread, Math_Min_I_I__I(int32(len(buf.A))-nread, remaining)); tmp1 = n; if tmp1 > 0 {





	nread = nread + n
	remaining = remaining - n
//line :105:1
	continue L2 }; break L2
}






	if nread > 0 {
		if 2147483639-total < nread {
			panic(Thrown(OutOfMemoryError_New_String(Lit_82))) }
		if nread < int32(len(buf.A)) { buf = Arrays_CopyOfRange_B1_I_I__B1(buf, 0, nread) }
		total = total + nread
		if result == nil {
			result = buf } else {
				if bufs == nil { bufs = ArrayList_New(); bufs.Add_O__Z(result.Ref()) }; bufs.Add_O__Z(buf.Ref()) } }
	var tmp2 bool; var tmp3 bool; tmp3 = n >= 0; if tmp3 { tmp3 = remaining > 0 }; tmp2 = tmp3; if tmp2 { continue L1 }
//line :102:1
	break L1
}


















	if bufs == nil {
		if result == nil {
			return NewByteArray(0) } else {
//line :123:1
				if int32(len(result.A)) == total { return result } else {


					return Arrays_CopyOf_B1_I__B1(result, total) } } } else {

						result = NewByteArray(total)
						var offset int32 = 0
						remaining = total
						var i_101006 Iterator = bufs.Iterator__Iterator(); for i_101006.HasNext__Z() { var b *ByteArray = A2g_CastArray[*ByteArray](i_101006.Next__O(), Prim_byte.ArrayClass()); var count int32 = Math_Min_I_I__I(int32(len(b.A)), remaining)

							System_Arraycopy_O_I_O_I_I__V(b.Ref(), 0, result.Ref(), offset, count)
							offset = offset + count
							remaining = remaining - count }
//line :129:1
						return result
					}
}






func (t *InputStream) Impl_ReadNBytes_B1_I_I__I(this InputStream_I, b *ByteArray, off, len_ int32) int32 {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	var n int32 = 0
L1: for { if n < len_ {
	var count int32 = this.Read_B1_I_I__I(b, off+n, len_-n)
	if count < 0 { break L1 }
	n = n + count
//line :141:1
	continue L1 }; break L1 }
//line :140:1
	return n
}





func (t *InputStream) Impl_Skip_J__J(this InputStream_I, n int64) int64 {
	var remaining int64 = n
	var nr int32 = 0
	if n <= 0 { return 0 } else {

		var size int32 = int32(Math_Min_J_J__J(2048, remaining)); var skipBuffer *ByteArray = NewByteArray(size)

	L1: for { if remaining > 0 {
		nr = this.Read_B1_I_I__I(skipBuffer, 0, int32(Math_Min_J_J__J(int64(size), remaining)))
		if nr < 0 { break L1 }
		remaining = remaining - int64(nr)
//line :154:1
		continue L1 }; break L1
	}


		return n - remaining
	} }
func (t *InputStream) Impl_SkipNBytes_J__V(this InputStream_I, n int64) {
L1: for { if n > 0 {
	var ns int64 = this.Skip_J__J(n); var tmp1 bool; var tmp2 bool

	tmp2 = ns > 0; if tmp2 { tmp2 = ns <= n }; tmp1 = tmp2
//line :163:1
	if tmp1 {
		n = n - ns } else {
//line :163:1
			if ns == 0 {


				if this.Read__I() == -1 { panic(Thrown(EOFException_New())) }; n = n - 1 } else {
					panic(Thrown(IOException_New_String(Lit_83))) } }
//line :161:1
	continue L1 }; break L1
}
}





func (t *InputStream) Impl_Available__I(this InputStream_I) int32 { return 0 }

func (t *InputStream) Impl_Close__V(this InputStream_I) {}

func (t *InputStream) Impl_Mark_I__V(this InputStream_I, p0 int32) {}

func (t *InputStream) Impl_Reset__V(this InputStream_I) {
	panic(Thrown(IOException_New_String(Lit_84)))
}
func (t *InputStream) Impl_MarkSupported__Z(this InputStream_I) bool { return false }

func (t *InputStream) Impl_TransferTo_OutputStream__J(this InputStream_I, out OutputStream_I) int64 {
	Objects_RequireNonNull_O_String__O(out, Lit_50)
	var transferred int64 = 0; var buffer *ByteArray = NewByteArray(16384)
	var read int32 = 0

L1: for { var tmp1 int32; read = this.Read_B1_I_I__I(buffer, 0, 16384); tmp1 = read; if tmp1 >= 0 {
	out.Write_B1_I_I__V(buffer, 0, read)
	if transferred < 9223372036854775807 { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

		transferred = Math_AddExact_J_J__J(transferred, int64(read)); return nil }()
//line :188:1
		if tmp2 != nil { if ArithmeticException_InstanceOf(tmp2) { var ignore *ArithmeticException = ArithmeticException_Cast(tmp2); _ = ignore

			transferred = 9223372036854775807 } else {
//line :188:1
				panic(tmp2) } } }
//line :185:1
	continue L1 }; break L1 }
//line :182:1
	return transferred
}









type InputStream struct{ Object }

type InputStream_I interface{ Object_I; Closeable; AutoCloseable; Self_InputStream() *InputStream; Read__I() int32; Read_B1__I(p0 *ByteArray) int32; Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; ReadAllBytes__B1() *ByteArray; ReadNBytes_I__B1(p0 int32) *ByteArray; ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; Skip_J__J(p0 int64) int64; SkipNBytes_J__V(p0 int64); Available__I() int32; Close__V(); Mark_I__V(p0 int32); Reset__V(); MarkSupported__Z() bool; TransferTo_OutputStream__J(p0 OutputStream_I) int64 }

func (t *InputStream) Self_InputStream() *InputStream { return t }

func (t *InputStream) Is_Closeable() {}

func (t *InputStream) Is_AutoCloseable() {}

const InputStream_MAX_SKIP_BUFFER_SIZE int32 = 2048

const InputStream_DEFAULT_BUFFER_SIZE int32 = 16384

const InputStream_MAX_BUFFER_SIZE int32 = 2147483639

func InputStream_InstanceOf(x any) bool { _, ok := x.(InputStream_I); return ok }

func InputStream_Cast(x any) InputStream_I { if x == nil { return nil }; v, ok := x.(InputStream_I); if !ok { panic(ClassCast(x, InputStream_class)) }; return v }



type InputStream_1 struct{ InputStream; F_closed atomic.Bool }

func InputStream_1_New() *InputStream_1 { t := &InputStream_1{}; t.Ctor(); return t }

func (t *InputStream_1) Ctor() { t.InputStream.Ctor(t) }

func (t *InputStream_1) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *InputStream_1) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *InputStream_1) Reset__V() { t.Impl_Reset__V(t) }

func (t *InputStream_1) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *InputStream_1) Ref() any { if t == nil { return nil }; return t }

func (t *InputStream_1) GetClass__Class() *Class { return InputStream_1_class }

func (t *InputStream_1) ToString__String() *String { return Object_toString(t) }

func (t *InputStream_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InputStream_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func InputStream_1_InstanceOf(x any) bool { _, ok := x.(*InputStream_1); return ok }

func InputStream_1_Cast(x any) *InputStream_1 { if x == nil { return nil }; v, ok := x.(*InputStream_1); if !ok { panic(ClassCast(x, InputStream_1_class)) }; return v }
