//line java_security_MessageDigestSpi.ae:1
package jrt









func (t *MessageDigestSpi) Ctor(this MessageDigestSpi_I) {}

func (t *MessageDigestSpi) Impl_EngineGetDigestLength__I(this MessageDigestSpi_I) int32 { return 0 }





func (t *MessageDigestSpi) Impl_EngineUpdate_ByteBuffer__V(this MessageDigestSpi_I, input ByteBuffer_I) {
	if !input.HasRemaining__Z() { } else {
		if input.HasArray__Z() {
			var b *ByteArray = input.Array__B1(); var ofs int32 = input.ArrayOffset__I(); var pos int32 = input.Position__I(); var lim int32 = input.Limit__I()



			this.EngineUpdate_B1_I_I__V(b, ofs+pos, lim-pos)
			input.Position_I__ByteBuffer(lim) } else {
				var len_ int32 = input.Remaining__I(); var n int32 = JCAUtil_GetTempArraySize_I__I(len_); var tmp1 bool; var tmp2 bool

				tmp2 = t.F_tempArray == nil; if !tmp2 { tmp2 = n > int32(len(t.F_tempArray.A)) }; tmp1 = tmp2; if tmp1 { t.F_tempArray = NewByteArray(n) }
			L1: for { if len_ > 0 {
				var chunk int32 = Math_Min_I_I__I(len_, int32(len(t.F_tempArray.A)))
				input.Get_B1_I_I__ByteBuffer(t.F_tempArray, 0, chunk)
				this.EngineUpdate_B1_I_I__V(t.F_tempArray, 0, chunk)
				len_ = len_ - chunk
//line :31:1
				continue L1 }; break L1
			}
			}
	}
}



func (t *MessageDigestSpi) Impl_EngineDigest_B1_I_I__I(this MessageDigestSpi_I, buf *ByteArray, offset, len_ int32) int32 {

	var digest *ByteArray = this.EngineDigest__B1()
	if len_ < int32(len(digest.A)) { panic(Thrown(DigestException_New_String(Lit_1554))) }
	var tmp1 int32 = int32(len(buf.A)) - offset; if tmp1 < int32(len(digest.A)) {
		panic(Thrown(DigestException_New_String(Lit_1555))) }
	System_Arraycopy_O_I_O_I_I__V(digest.Ref(), 0, buf.Ref(), offset, int32(len(digest.A)))
	return int32(len(digest.A))
}


func (t *MessageDigestSpi) Impl_Clone__O(this MessageDigestSpi_I) any {
	if Cloneable_InstanceOf(this) {
		var o MessageDigestSpi_I = MessageDigestSpi_Cast(A2g_ObjectClone(this))
		if !(o.Self_MessageDigestSpi().F_tempArray == nil) { o.Self_MessageDigestSpi().F_tempArray = NN(t.F_tempArray).Copy() }
//line :52:1
		return o } else {


			panic(Thrown(CloneNotSupportedException_New()))
		}
}

type MessageDigestSpi struct{ Object; F_tempArray *ByteArray }

type MessageDigestSpi_I interface{ Object_I; Self_MessageDigestSpi() *MessageDigestSpi; EngineGetDigestLength__I() int32; EngineUpdate_B__V(p0 int8); EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32); EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I); EngineDigest__B1() *ByteArray; EngineDigest_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; EngineReset__V() }

func (t *MessageDigestSpi) Self_MessageDigestSpi() *MessageDigestSpi { return t }

func MessageDigestSpi_InstanceOf(x any) bool { _, ok := x.(MessageDigestSpi_I); return ok }

func MessageDigestSpi_Cast(x any) MessageDigestSpi_I { if x == nil { return nil }; v, ok := x.(MessageDigestSpi_I); if !ok { panic(ClassCast(x, MessageDigestSpi_class)) }; return v }
