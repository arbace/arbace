//line java_lang_CharacterData00.ae:1
package jrt








func (t *CharacterData00) GetProperties_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var tmp1 *IntArray = CharacterData00_A; var tmp2 *CharArray = CharacterData00_Y; var props int32 = tmp1.A[int32(tmp2.A[int32(CharacterData00_X.A[int32(offset)>>5])|int32(offset)>>1&15])|int32(offset)&1]; return props
}







func (t *CharacterData00) GetPropertiesEx_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var tmp1 *CharArray = CharacterData00_B; var tmp2 *CharArray = CharacterData00_Y; var props int32 = int32(tmp1.A[int32(tmp2.A[int32(CharacterData00_X.A[int32(offset)>>5])|int32(offset)>>1&15])|int32(offset)&1]); return props
}







func (t *CharacterData00) GetType_I__I(ch int32) int32 {
	var props int32 = t.GetProperties_I__I(ch); return props & 31
}
func (t *CharacterData00) IsOtherAlphabetic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&4 == 0)
}
func (t *CharacterData00) IsIdeographic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&8 == 0)
}
func (t *CharacterData00) IsJavaIdentifierStart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 >= 20480
}
func (t *CharacterData00) IsJavaIdentifierPart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return !(props&12288 == 0)
}
func (t *CharacterData00) IsUnicodeIdentifierStart_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = !(t.GetPropertiesEx_I__I(ch)&16 == 0); if !tmp1 { tmp1 = ch == 11823 }; return tmp1
}
func (t *CharacterData00) IsUnicodeIdentifierPart_I__Z(ch int32) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.GetPropertiesEx_I__I(ch)&32 == 0); if !tmp2 {
		tmp2 = t.IsIdentifierIgnorable_I__Z(ch) }
//line :49:1
	tmp1 = tmp2; if !tmp1 {

		tmp1 = ch == 11823 }
//line :49:1
	return tmp1
}


func (t *CharacterData00) IsIdentifierIgnorable_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 4096
}
func (t *CharacterData00) IsEmoji_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&64 == 0)
}
func (t *CharacterData00) IsEmojiPresentation_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&128 == 0)
}
func (t *CharacterData00) IsEmojiModifier_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&256 == 0)
}
func (t *CharacterData00) IsEmojiModifierBase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&512 == 0)
}
func (t *CharacterData00) IsEmojiComponent_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1024 == 0)
}
func (t *CharacterData00) IsExtendedPictographic_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2048 == 0)
}
func (t *CharacterData00) ToLowerCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if val&131072 == 0 { } else {
		if val&133955584 == 133955584 {
			switch ch { case 304:
				mapChar = 105; case 570:
				mapChar = 11365; case 574:
				mapChar = 11366; case 1042:
				mapChar = 7296; case 1044:
				mapChar = 7297; case 1054:
				mapChar = 7298; case 1057:
				mapChar = 7299; case 1066:
				mapChar = 7302; case 1122:
				mapChar = 7303; case 4256:
				mapChar = 11520; case 4257:
				mapChar = 11521; case 4258:
				mapChar = 11522; case 4259:
				mapChar = 11523; case 4260:
				mapChar = 11524; case 4261:
				mapChar = 11525; case 4262:
				mapChar = 11526; case 4263:
				mapChar = 11527; case 4264:
				mapChar = 11528; case 4265:
				mapChar = 11529; case 4266:
				mapChar = 11530; case 4267:
				mapChar = 11531; case 4268:
				mapChar = 11532; case 4269:
				mapChar = 11533; case 4270:
				mapChar = 11534; case 4271:
				mapChar = 11535; case 4272:
				mapChar = 11536; case 4273:
				mapChar = 11537; case 4274:
				mapChar = 11538; case 4275:
				mapChar = 11539; case 4276:
				mapChar = 11540; case 4277:
				mapChar = 11541; case 4278:
				mapChar = 11542; case 4279:
				mapChar = 11543; case 4280:
				mapChar = 11544; case 4281:
				mapChar = 11545; case 4282:
				mapChar = 11546; case 4283:
				mapChar = 11547; case 4284:
				mapChar = 11548; case 4285:
				mapChar = 11549; case 4286:
				mapChar = 11550; case 4287:
				mapChar = 11551; case 4288:
				mapChar = 11552; case 4289:
				mapChar = 11553; case 4290:
				mapChar = 11554; case 4291:
				mapChar = 11555; case 4292:
				mapChar = 11556; case 4293:
				mapChar = 11557; case 4295:
				mapChar = 11559; case 4301:
				mapChar = 11565; case 5024:
				mapChar = 43888; case 5025:
				mapChar = 43889; case 5026:
				mapChar = 43890; case 5027:
				mapChar = 43891; case 5028:
				mapChar = 43892; case 5029:
				mapChar = 43893; case 5030:
				mapChar = 43894; case 5031:
				mapChar = 43895; case 5032:
				mapChar = 43896; case 5033:
				mapChar = 43897; case 5034:
				mapChar = 43898; case 5035:
				mapChar = 43899; case 5036:
				mapChar = 43900; case 5037:
				mapChar = 43901; case 5038:
				mapChar = 43902; case 5039:
				mapChar = 43903; case 5040:
				mapChar = 43904; case 5041:
				mapChar = 43905; case 5042:
				mapChar = 43906; case 5043:
				mapChar = 43907; case 5044:
				mapChar = 43908; case 5045:
				mapChar = 43909; case 5046:
				mapChar = 43910; case 5047:
				mapChar = 43911; case 5048:
				mapChar = 43912; case 5049:
				mapChar = 43913; case 5050:
				mapChar = 43914; case 5051:
				mapChar = 43915; case 5052:
				mapChar = 43916; case 5053:
				mapChar = 43917; case 5054:
				mapChar = 43918; case 5055:
				mapChar = 43919; case 5056:
				mapChar = 43920; case 5057:
				mapChar = 43921; case 5058:
				mapChar = 43922; case 5059:
				mapChar = 43923; case 5060:
				mapChar = 43924; case 5061:
				mapChar = 43925; case 5062:
				mapChar = 43926; case 5063:
				mapChar = 43927; case 5064:
				mapChar = 43928; case 5065:
				mapChar = 43929; case 5066:
				mapChar = 43930; case 5067:
				mapChar = 43931; case 5068:
				mapChar = 43932; case 5069:
				mapChar = 43933; case 5070:
				mapChar = 43934; case 5071:
				mapChar = 43935; case 5072:
				mapChar = 43936; case 5073:
				mapChar = 43937; case 5074:
				mapChar = 43938; case 5075:
				mapChar = 43939; case 5076:
				mapChar = 43940; case 5077:
				mapChar = 43941; case 5078:
				mapChar = 43942; case 5079:
				mapChar = 43943; case 5080:
				mapChar = 43944; case 5081:
				mapChar = 43945; case 5082:
				mapChar = 43946; case 5083:
				mapChar = 43947; case 5084:
				mapChar = 43948; case 5085:
				mapChar = 43949; case 5086:
				mapChar = 43950; case 5087:
				mapChar = 43951; case 5088:
				mapChar = 43952; case 5089:
				mapChar = 43953; case 5090:
				mapChar = 43954; case 5091:
				mapChar = 43955; case 5092:
				mapChar = 43956; case 5093:
				mapChar = 43957; case 5094:
				mapChar = 43958; case 5095:
				mapChar = 43959; case 5096:
				mapChar = 43960; case 5097:
				mapChar = 43961; case 5098:
				mapChar = 43962; case 5099:
				mapChar = 43963; case 5100:
				mapChar = 43964; case 5101:
				mapChar = 43965; case 5102:
				mapChar = 43966; case 5103:
				mapChar = 43967; case 7312:
				mapChar = 4304; case 7313:
				mapChar = 4305; case 7314:
				mapChar = 4306; case 7315:
				mapChar = 4307; case 7316:
				mapChar = 4308; case 7317:
				mapChar = 4309; case 7318:
				mapChar = 4310; case 7319:
				mapChar = 4311; case 7320:
				mapChar = 4312; case 7321:
				mapChar = 4313; case 7322:
				mapChar = 4314; case 7323:
				mapChar = 4315; case 7324:
				mapChar = 4316; case 7325:
				mapChar = 4317; case 7326:
				mapChar = 4318; case 7327:
				mapChar = 4319; case 7328:
				mapChar = 4320; case 7329:
				mapChar = 4321; case 7330:
				mapChar = 4322; case 7331:
				mapChar = 4323; case 7332:
				mapChar = 4324; case 7333:
				mapChar = 4325; case 7334:
				mapChar = 4326; case 7335:
				mapChar = 4327; case 7336:
				mapChar = 4328; case 7337:
				mapChar = 4329; case 7338:
				mapChar = 4330; case 7339:
				mapChar = 4331; case 7340:
				mapChar = 4332; case 7341:
				mapChar = 4333; case 7342:
				mapChar = 4334; case 7343:
				mapChar = 4335; case 7344:
				mapChar = 4336; case 7345:
				mapChar = 4337; case 7346:
				mapChar = 4338; case 7347:
				mapChar = 4339; case 7348:
				mapChar = 4340; case 7349:
				mapChar = 4341; case 7350:
				mapChar = 4342; case 7351:
				mapChar = 4343; case 7352:
				mapChar = 4344; case 7353:
				mapChar = 4345; case 7354:
				mapChar = 4346; case 7355:
				mapChar = 4347; case 7356:
				mapChar = 4348; case 7357:
				mapChar = 4349; case 7358:
				mapChar = 4350; case 7359:
				mapChar = 4351; case 7838:
				mapChar = 223; case 8072:
				mapChar = 8064; case 8073:
				mapChar = 8065; case 8074:
				mapChar = 8066; case 8075:
				mapChar = 8067; case 8076:
				mapChar = 8068; case 8077:
				mapChar = 8069; case 8078:
				mapChar = 8070; case 8079:
				mapChar = 8071; case 8088:
				mapChar = 8080; case 8089:
				mapChar = 8081; case 8090:
				mapChar = 8082; case 8091:
				mapChar = 8083; case 8092:
				mapChar = 8084; case 8093:
				mapChar = 8085; case 8094:
				mapChar = 8086; case 8095:
				mapChar = 8087; case 8104:
				mapChar = 8096; case 8105:
				mapChar = 8097; case 8106:
				mapChar = 8098; case 8107:
				mapChar = 8099; case 8108:
				mapChar = 8100; case 8109:
				mapChar = 8101; case 8110:
				mapChar = 8102; case 8111:
				mapChar = 8103; case 8124:
				mapChar = 8115; case 8140:
				mapChar = 8131; case 8188:
				mapChar = 8179; case 8486:
				mapChar = 969; case 8490:
				mapChar = 107; case 8491:
				mapChar = 229; case 11362:
				mapChar = 619; case 11363:
				mapChar = 7549; case 11364:
				mapChar = 637; case 11373:
				mapChar = 593; case 11374:
				mapChar = 625; case 11375:
				mapChar = 592; case 11376:
				mapChar = 594; case 11390:
				mapChar = 575; case 11391:
				mapChar = 576; case 42570:
				mapChar = 7304; case 42877:
				mapChar = 7545; case 42893:
				mapChar = 613; case 42922:
				mapChar = 614; case 42923:
				mapChar = 604; case 42924:
				mapChar = 609; case 42925:
				mapChar = 620; case 42926:
				mapChar = 618; case 42928:
				mapChar = 670; case 42929:
				mapChar = 647; case 42930:
				mapChar = 669; case 42931:
				mapChar = 43859; case 42949:
				mapChar = 642; case 42950:
				mapChar = 7566; case 42955:
				mapChar = 612; case 42972:
				mapChar = 411; default:} } else {
					var offset int32 = val << 5 >> 23
					mapChar = ch + offset } }
//line :75:1
	return mapChar
}
















































































































































































































































func (t *CharacterData00) ToUpperCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if val&65536 == 0 { } else {
		if val&133955584 == 133955584 {
			switch ch { case 383:
				mapChar = 83; case 411:
				mapChar = 42972; case 575:
				mapChar = 11390; case 576:
				mapChar = 11391; case 592:
				mapChar = 11375; case 593:
				mapChar = 11373; case 594:
				mapChar = 11376; case 604:
				mapChar = 42923; case 609:
				mapChar = 42924; case 612:
				mapChar = 42955; case 613:
				mapChar = 42893; case 614:
				mapChar = 42922; case 618:
				mapChar = 42926; case 619:
				mapChar = 11362; case 620:
				mapChar = 42925; case 625:
				mapChar = 11374; case 637:
				mapChar = 11364; case 642:
				mapChar = 42949; case 647:
				mapChar = 42929; case 669:
				mapChar = 42930; case 670:
				mapChar = 42928; case 4304:
				mapChar = 7312; case 4305:
				mapChar = 7313; case 4306:
				mapChar = 7314; case 4307:
				mapChar = 7315; case 4308:
				mapChar = 7316; case 4309:
				mapChar = 7317; case 4310:
				mapChar = 7318; case 4311:
				mapChar = 7319; case 4312:
				mapChar = 7320; case 4313:
				mapChar = 7321; case 4314:
				mapChar = 7322; case 4315:
				mapChar = 7323; case 4316:
				mapChar = 7324; case 4317:
				mapChar = 7325; case 4318:
				mapChar = 7326; case 4319:
				mapChar = 7327; case 4320:
				mapChar = 7328; case 4321:
				mapChar = 7329; case 4322:
				mapChar = 7330; case 4323:
				mapChar = 7331; case 4324:
				mapChar = 7332; case 4325:
				mapChar = 7333; case 4326:
				mapChar = 7334; case 4327:
				mapChar = 7335; case 4328:
				mapChar = 7336; case 4329:
				mapChar = 7337; case 4330:
				mapChar = 7338; case 4331:
				mapChar = 7339; case 4332:
				mapChar = 7340; case 4333:
				mapChar = 7341; case 4334:
				mapChar = 7342; case 4335:
				mapChar = 7343; case 4336:
				mapChar = 7344; case 4337:
				mapChar = 7345; case 4338:
				mapChar = 7346; case 4339:
				mapChar = 7347; case 4340:
				mapChar = 7348; case 4341:
				mapChar = 7349; case 4342:
				mapChar = 7350; case 4343:
				mapChar = 7351; case 4344:
				mapChar = 7352; case 4345:
				mapChar = 7353; case 4346:
				mapChar = 7354; case 4349:
				mapChar = 7357; case 4350:
				mapChar = 7358; case 4351:
				mapChar = 7359; case 7296:
				mapChar = 1042; case 7297:
				mapChar = 1044; case 7298:
				mapChar = 1054; case 7299:
				mapChar = 1057; case 7300:
				mapChar = 1058; case 7301:
				mapChar = 1058; case 7302:
				mapChar = 1066; case 7303:
				mapChar = 1122; case 7304:
				mapChar = 42570; case 7545:
				mapChar = 42877; case 7549:
				mapChar = 11363; case 7566:
				mapChar = 42950; case 8064:
				mapChar = 8072; case 8065:
				mapChar = 8073; case 8066:
				mapChar = 8074; case 8067:
				mapChar = 8075; case 8068:
				mapChar = 8076; case 8069:
				mapChar = 8077; case 8070:
				mapChar = 8078; case 8071:
				mapChar = 8079; case 8080:
				mapChar = 8088; case 8081:
				mapChar = 8089; case 8082:
				mapChar = 8090; case 8083:
				mapChar = 8091; case 8084:
				mapChar = 8092; case 8085:
				mapChar = 8093; case 8086:
				mapChar = 8094; case 8087:
				mapChar = 8095; case 8096:
				mapChar = 8104; case 8097:
				mapChar = 8105; case 8098:
				mapChar = 8106; case 8099:
				mapChar = 8107; case 8100:
				mapChar = 8108; case 8101:
				mapChar = 8109; case 8102:
				mapChar = 8110; case 8103:
				mapChar = 8111; case 8115:
				mapChar = 8124; case 8126:
				mapChar = 921; case 8131:
				mapChar = 8140; case 8179:
				mapChar = 8188; case 11365:
				mapChar = 570; case 11366:
				mapChar = 574; case 11520:
				mapChar = 4256; case 11521:
				mapChar = 4257; case 11522:
				mapChar = 4258; case 11523:
				mapChar = 4259; case 11524:
				mapChar = 4260; case 11525:
				mapChar = 4261; case 11526:
				mapChar = 4262; case 11527:
				mapChar = 4263; case 11528:
				mapChar = 4264; case 11529:
				mapChar = 4265; case 11530:
				mapChar = 4266; case 11531:
				mapChar = 4267; case 11532:
				mapChar = 4268; case 11533:
				mapChar = 4269; case 11534:
				mapChar = 4270; case 11535:
				mapChar = 4271; case 11536:
				mapChar = 4272; case 11537:
				mapChar = 4273; case 11538:
				mapChar = 4274; case 11539:
				mapChar = 4275; case 11540:
				mapChar = 4276; case 11541:
				mapChar = 4277; case 11542:
				mapChar = 4278; case 11543:
				mapChar = 4279; case 11544:
				mapChar = 4280; case 11545:
				mapChar = 4281; case 11546:
				mapChar = 4282; case 11547:
				mapChar = 4283; case 11548:
				mapChar = 4284; case 11549:
				mapChar = 4285; case 11550:
				mapChar = 4286; case 11551:
				mapChar = 4287; case 11552:
				mapChar = 4288; case 11553:
				mapChar = 4289; case 11554:
				mapChar = 4290; case 11555:
				mapChar = 4291; case 11556:
				mapChar = 4292; case 11557:
				mapChar = 4293; case 11559:
				mapChar = 4295; case 11565:
				mapChar = 4301; case 43859:
				mapChar = 42931; case 43888:
				mapChar = 5024; case 43889:
				mapChar = 5025; case 43890:
				mapChar = 5026; case 43891:
				mapChar = 5027; case 43892:
				mapChar = 5028; case 43893:
				mapChar = 5029; case 43894:
				mapChar = 5030; case 43895:
				mapChar = 5031; case 43896:
				mapChar = 5032; case 43897:
				mapChar = 5033; case 43898:
				mapChar = 5034; case 43899:
				mapChar = 5035; case 43900:
				mapChar = 5036; case 43901:
				mapChar = 5037; case 43902:
				mapChar = 5038; case 43903:
				mapChar = 5039; case 43904:
				mapChar = 5040; case 43905:
				mapChar = 5041; case 43906:
				mapChar = 5042; case 43907:
				mapChar = 5043; case 43908:
				mapChar = 5044; case 43909:
				mapChar = 5045; case 43910:
				mapChar = 5046; case 43911:
				mapChar = 5047; case 43912:
				mapChar = 5048; case 43913:
				mapChar = 5049; case 43914:
				mapChar = 5050; case 43915:
				mapChar = 5051; case 43916:
				mapChar = 5052; case 43917:
				mapChar = 5053; case 43918:
				mapChar = 5054; case 43919:
				mapChar = 5055; case 43920:
				mapChar = 5056; case 43921:
				mapChar = 5057; case 43922:
				mapChar = 5058; case 43923:
				mapChar = 5059; case 43924:
				mapChar = 5060; case 43925:
				mapChar = 5061; case 43926:
				mapChar = 5062; case 43927:
				mapChar = 5063; case 43928:
				mapChar = 5064; case 43929:
				mapChar = 5065; case 43930:
				mapChar = 5066; case 43931:
				mapChar = 5067; case 43932:
				mapChar = 5068; case 43933:
				mapChar = 5069; case 43934:
				mapChar = 5070; case 43935:
				mapChar = 5071; case 43936:
				mapChar = 5072; case 43937:
				mapChar = 5073; case 43938:
				mapChar = 5074; case 43939:
				mapChar = 5075; case 43940:
				mapChar = 5076; case 43941:
				mapChar = 5077; case 43942:
				mapChar = 5078; case 43943:
				mapChar = 5079; case 43944:
				mapChar = 5080; case 43945:
				mapChar = 5081; case 43946:
				mapChar = 5082; case 43947:
				mapChar = 5083; case 43948:
				mapChar = 5084; case 43949:
				mapChar = 5085; case 43950:
				mapChar = 5086; case 43951:
				mapChar = 5087; case 43952:
				mapChar = 5088; case 43953:
				mapChar = 5089; case 43954:
				mapChar = 5090; case 43955:
				mapChar = 5091; case 43956:
				mapChar = 5092; case 43957:
				mapChar = 5093; case 43958:
				mapChar = 5094; case 43959:
				mapChar = 5095; case 43960:
				mapChar = 5096; case 43961:
				mapChar = 5097; case 43962:
				mapChar = 5098; case 43963:
				mapChar = 5099; case 43964:
				mapChar = 5100; case 43965:
				mapChar = 5101; case 43966:
				mapChar = 5102; case 43967:
				mapChar = 5103; default:} } else {
					var offset int32 = val << 5 >> 23
					mapChar = ch - offset } }
//line :318:1
	return mapChar
}













































































































































































































































func (t *CharacterData00) ToTitleCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if !(val&32768 == 0) {
		if val&65536 == 0 {
			mapChar = ch + 1 } else {
//line :561:1
				if val&131072 == 0 {


					var tmp1 bool; var tmp2 bool; tmp2 = ch >= 4304; if tmp2 { tmp2 = ch <= 4351 }; tmp1 = tmp2; if tmp1 {
						mapChar = ch } else {
							mapChar = ch - 1 } } } } else {
								if val&65536 == 0 { } else { mapChar = t.ToUpperCase_I__I(ch) } }
//line :558:1
	return mapChar
}










func (t *CharacterData00) Digit_I_I__I(ch, radix int32) int32 {
	var value int32 = -1; var tmp1 bool; var tmp2 bool
	tmp2 = radix >= 2; if tmp2 { tmp2 = radix <= 36 }; tmp1 = tmp2; if tmp1 {
		var val int32 = t.GetProperties_I__I(ch); var kind int32 = val & 31

		if kind == 9 {

			value = (ch + val&992>>5) & 31 } else {
//line :575:1
				if val&3072 == 3072 {







					value = (ch+val&992>>5)&31 + 10
				}
			}
	}



	if value < radix { return value } else { return -1
	} }
func (t *CharacterData00) GetNumericValue_I__I(ch int32) int32 {
	var val int32 = t.GetProperties_I__I(ch)
	var retval int32 = -1
	switch val & 3072 { case 1024:

		retval = (ch + val&992>>5) & 31; case 2048:



		switch ch { case 3057:
			retval = 100; case 3058:
			retval = 1000; case 3441:
			retval = 100; case 3442:
			retval = 1000; case 4981:
			retval = 40; case 4982:
			retval = 50; case 4983:
			retval = 60; case 4984:
			retval = 70; case 4985:
			retval = 80; case 4986:
			retval = 90; case 4987:
			retval = 100; case 4988:
			retval = 10000; case 8543:
			retval = 1; case 8556:
			retval = 50; case 8557:
			retval = 100; case 8558:
			retval = 500; case 8559:
			retval = 1000; case 8572:
			retval = 50; case 8573:
			retval = 100; case 8574:
			retval = 500; case 8575:
			retval = 1000; case 8576:
			retval = 1000; case 8577:
			retval = 5000; case 8578:
			retval = 10000; case 8582:
			retval = 50; case 8583:
			retval = 50000; case 8584:
			retval = 100000; case 12875:
			retval = 40; case 12876:
			retval = 50; case 12877:
			retval = 60; case 12878:
			retval = 70; case 12879:
			retval = 80; case 12892:
			retval = 32; case 12893:
			retval = 33; case 12894:
			retval = 34; case 12895:
			retval = 35; case 12977:
			retval = 36; case 12978:
			retval = 37; case 12979:
			retval = 38; case 12980:
			retval = 39; case 12981:
			retval = 40; case 12982:
			retval = 41; case 12983:
			retval = 42; case 12984:
			retval = 43; case 12985:
			retval = 44; case 12986:
			retval = 45; case 12987:
			retval = 46; case 12988:
			retval = 47; case 12989:
			retval = 48; case 12990:
			retval = 49; case 12991:
			retval = 50; default:
			retval = -2}; case 3072:

		retval = (ch+val&992>>5)&31 + 10; default:






		retval = -1}
//line :593:1
	return retval
}






































































func (t *CharacterData00) IsDigit_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch)
	return props&31 == 9
}
func (t *CharacterData00) IsLowerCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1 == 0)
}
func (t *CharacterData00) IsUpperCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2 == 0)
}
func (t *CharacterData00) IsWhitespace_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 16384
}
func (t *CharacterData00) GetDirectionality_I__B(ch int32) int8 {
	var val int32 = t.GetProperties_I__I(ch); var directionality int8 = int8(val & 2013265920 >> 27)


	if int32(directionality) == 15 {
		switch ch { case 8234:
			directionality = 14; case 8235:
			directionality = 16; case 8236:
			directionality = 18; case 8237:
			directionality = 15; case 8238:
			directionality = 17; case 8294:
			directionality = 19; case 8295:
			directionality = 20; case 8296:
			directionality = 21; case 8297:
			directionality = 22; default:
			directionality = -1} }
//line :679:1
	return directionality
}















func (t *CharacterData00) IsMirrored_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch)
	return !(props&-2147483648 == 0)
}
func (t *CharacterData00) ToUpperCaseEx_I__I(p0 int32) int32 { panic(A2g_NotTranslated("java.lang.CharacterData00.toUpperCaseEx(I)I")) }





















































































































































































































func (t *CharacterData00) ToUpperCaseCharArray_I__C1(p0 int32) *CharArray { panic(A2g_NotTranslated("java.lang.CharacterData00.toUpperCaseCharArray(I)[C")) }





func (t *CharacterData00) FindInCharMap_I__I(p0 int32) int32 { panic(A2g_NotTranslated("java.lang.CharacterData00.findInCharMap(I)I")) }















func CharacterData00_New() *CharacterData00 { CharacterData00_Init(); t := &CharacterData00{}; t.Ctor(); return t }
//line :936:1
func (t *CharacterData00) Ctor() { t.CharacterData.Ctor(t) }





type CharacterData00 struct{ CharacterData }

var CharacterData00_instance *CharacterData00

var CharacterData00_charMap *RefArray

var CharacterData00_X *CharArray

var CharacterData00_Y *CharArray

var CharacterData00_A *IntArray

var CharacterData00_A_DATA *String = Lit_1097

var CharacterData00_B *CharArray

var CharacterData00_init ClassInit

func CharacterData00_Init() { if !CharacterData00_init.Done() { CharacterData00_init.Run(CharacterData00_clinit) } }

func CharacterData00_clinit() { CharacterData00_instance = CharacterData00_New(); CharacterData00_X = Lit_1094.ToCharArray__C1(); CharacterData00_Y = Lit_1095.ToCharArray__C1(); CharacterData00_A = NewIntArray(1038); CharacterData00_B = Lit_1096.ToCharArray__C1()
//line :958:1
	CharacterData00_charMap = RefArrayOf(Prim_char.ArrayClass().ArrayClass(), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(223), CharArrayOf(83, 83)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(304), CharArrayOf(304)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(329), CharArrayOf(700, 78)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(496), CharArrayOf(74, 780)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(912), CharArrayOf(921, 776, 769)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(944), CharArrayOf(933, 776, 769)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(1415), CharArrayOf(1333, 1362)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(7830), CharArrayOf(72, 817)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(7831), CharArrayOf(84, 776)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(7832), CharArrayOf(87, 778)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(7833), CharArrayOf(89, 778)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(7834), CharArrayOf(65, 702)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8016), CharArrayOf(933, 787)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8018), CharArrayOf(933, 787, 768)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8020), CharArrayOf(933, 787, 769)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8022), CharArrayOf(933, 787, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8064), CharArrayOf(7944, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8065), CharArrayOf(7945, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8066), CharArrayOf(7946, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8067), CharArrayOf(7947, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8068), CharArrayOf(7948, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8069), CharArrayOf(7949, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8070), CharArrayOf(7950, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8071), CharArrayOf(7951, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8072), CharArrayOf(7944, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8073), CharArrayOf(7945, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8074), CharArrayOf(7946, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8075), CharArrayOf(7947, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8076), CharArrayOf(7948, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8077), CharArrayOf(7949, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8078), CharArrayOf(7950, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8079), CharArrayOf(7951, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8080), CharArrayOf(7976, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8081), CharArrayOf(7977, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8082), CharArrayOf(7978, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8083), CharArrayOf(7979, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8084), CharArrayOf(7980, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8085), CharArrayOf(7981, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8086), CharArrayOf(7982, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8087), CharArrayOf(7983, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8088), CharArrayOf(7976, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8089), CharArrayOf(7977, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8090), CharArrayOf(7978, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8091), CharArrayOf(7979, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8092), CharArrayOf(7980, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8093), CharArrayOf(7981, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8094), CharArrayOf(7982, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8095), CharArrayOf(7983, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8096), CharArrayOf(8040, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8097), CharArrayOf(8041, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8098), CharArrayOf(8042, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8099), CharArrayOf(8043, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8100), CharArrayOf(8044, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8101), CharArrayOf(8045, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8102), CharArrayOf(8046, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8103), CharArrayOf(8047, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8104), CharArrayOf(8040, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8105), CharArrayOf(8041, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8106), CharArrayOf(8042, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8107), CharArrayOf(8043, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8108), CharArrayOf(8044, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8109), CharArrayOf(8045, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8110), CharArrayOf(8046, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8111), CharArrayOf(8047, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8114), CharArrayOf(8122, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8115), CharArrayOf(913, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8116), CharArrayOf(902, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8118), CharArrayOf(913, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8119), CharArrayOf(913, 834, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8124), CharArrayOf(913, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8130), CharArrayOf(8138, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8131), CharArrayOf(919, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8132), CharArrayOf(905, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8134), CharArrayOf(919, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8135), CharArrayOf(919, 834, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8140), CharArrayOf(919, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8146), CharArrayOf(921, 776, 768)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8147), CharArrayOf(921, 776, 769)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8150), CharArrayOf(921, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8151), CharArrayOf(921, 776, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8162), CharArrayOf(933, 776, 768)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8163), CharArrayOf(933, 776, 769)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8164), CharArrayOf(929, 787)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8166), CharArrayOf(933, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8167), CharArrayOf(933, 776, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8178), CharArrayOf(8186, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8179), CharArrayOf(937, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8180), CharArrayOf(911, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8182), CharArrayOf(937, 834)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8183), CharArrayOf(937, 834, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(8188), CharArrayOf(937, 921)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64256), CharArrayOf(70, 70)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64257), CharArrayOf(70, 73)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64258), CharArrayOf(70, 76)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64259), CharArrayOf(70, 70, 73)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64260), CharArrayOf(70, 70, 76)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64261), CharArrayOf(83, 84)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64262), CharArrayOf(83, 84)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64275), CharArrayOf(1348, 1350)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64276), CharArrayOf(1348, 1333)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64277), CharArrayOf(1348, 1339)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64278), CharArrayOf(1358, 1350)), RefArrayOf(Prim_char.ArrayClass(), CharArrayOf(64279), CharArrayOf(1348, 1341)))








































































































	var data *CharArray = Lit_1097.ToCharArray__C1()
	if !A2g_AssertionsDisabled && !(int32(len(data.A)) == 2076) { panic(Thrown(AssertionError_New())) }
	var i int32 = 0
	var j int32 = 0
L1: for { if i < 2076 {
	var entry int32; var tmp1 int32; var old_1 int32 = i
	i = i + 1; tmp1 = old_1
//line :1068:1
	entry = int32(data.A[tmp1]) << 16


	var tmp2 *IntArray = CharacterData00_A; tmp2.A[j] = entry | int32(data.A[i])
	j = j + 1
	i = i + 1
//line :1067:1
	continue L1 }; break L1
}
}





func (t *CharacterData00) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterData00) GetClass__Class() *Class { return CharacterData00_class }

func (t *CharacterData00) ToString__String() *String { return Object_toString(t) }

func (t *CharacterData00) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterData00) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterData00_InstanceOf(x any) bool { _, ok := x.(*CharacterData00); return ok }

func CharacterData00_Cast(x any) *CharacterData00 { if x == nil { return nil }; v, ok := x.(*CharacterData00); if !ok { panic(ClassCast(x, CharacterData00_class)) }; return v }
