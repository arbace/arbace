//line java_net_MalformedURLException.ae:1
package jrt










func MalformedURLException_New() *MalformedURLException { t := &MalformedURLException{}; t.Ctor(); return t }
//line :12:1
func (t *MalformedURLException) Ctor() { t.IOException.Ctor(t) }

func MalformedURLException_New_String(p0 *String) *MalformedURLException { t := &MalformedURLException{}; t.Ctor_String(p0); return t }
//line :14:1
func (t *MalformedURLException) Ctor_String(msg *String) { t.IOException.Ctor_String(t, msg) }







type MalformedURLException struct{ IOException }

const MalformedURLException_serialVersionUID int64 = -182787522200415866

func (t *MalformedURLException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *MalformedURLException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *MalformedURLException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *MalformedURLException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *MalformedURLException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *MalformedURLException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *MalformedURLException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *MalformedURLException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *MalformedURLException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *MalformedURLException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *MalformedURLException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *MalformedURLException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MalformedURLException) Ref() any { if t == nil { return nil }; return t }

func (t *MalformedURLException) GetClass__Class() *Class { return MalformedURLException_class }

func (t *MalformedURLException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MalformedURLException) CloneShallow() any { panic(CloneNotSupported(t)) }

func MalformedURLException_InstanceOf(x any) bool { _, ok := x.(*MalformedURLException); return ok }

func MalformedURLException_Cast(x any) *MalformedURLException { if x == nil { return nil }; v, ok := x.(*MalformedURLException); if !ok { panic(ClassCast(x, MalformedURLException_class)) }; return v }
