//line java_lang_Cloneable.ae:1
package jrt






type Cloneable interface{ Object_I; Is_Cloneable() }

func Cloneable_InstanceOf(x any) bool { _, ok := x.(Cloneable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Cloneable_class) } }; return ok }

func Cloneable_Cast(x any) Cloneable { if x == nil { return nil }; v, ok := x.(Cloneable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Cloneable_class) } }; if !ok { panic(ClassCast(x, Cloneable_class)) }; return v }
