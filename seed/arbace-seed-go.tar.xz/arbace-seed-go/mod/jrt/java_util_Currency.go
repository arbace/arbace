//line java_util_Currency.ae:1
package jrt
















































































func Currency_InitStatic__V() { Currency_Init(); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var in InputStream_I = Currency_class.GetResourceAsStream_String__InputStream(Lit_2643); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
		if in == nil { panic(Thrown(InternalError_New_String(Lit_2644))) }
		{ var dis *DataInputStream = DataInputStream_New_InputStream(BufferedInputStream_New_InputStream(in))
			if NN(dis).ReadInt__I() == 1131770436 { } else {
				panic(Thrown(InternalError_New_String(Lit_2645))) }
			Currency_formatVersion = NN(dis).ReadInt__I()
			if Currency_formatVersion == 3 { } else {
				panic(Thrown(InternalError_New_String(Lit_2646))) }
			Currency_dataVersion = NN(dis).ReadInt__I()
			Currency_mainTable = Currency_ReadIntArray_DataInputStream_I__I1(dis, 676)
			var scCount int32 = NN(dis).ReadInt__I()
			Currency_specialCasesList = Currency_ReadSpecialCases_DataInputStream_I__List(dis, scCount)
			var ocCount int32 = NN(dis).ReadInt__I()
			Currency_otherCurrenciesList = Currency_ReadOtherCurrencies_DataInputStream_I__List(dis, ocCount) }; return nil }()
//line :84:1
		if tmp1 == nil { if !(in == nil) { in.Close__V() } }; if tmp1 != nil { if true { var t_101789 Throwable_I = tmp1; if !(in == nil) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc); in.Close__V(); return nil }(); if tmp2 != nil { if true { var x_101790 Throwable_I = tmp2; t_101789.AddSuppressed_Throwable__V(x_101790) } } }; panic(Thrown(t_101789))
		}
		}
	}









	return nil }(); if /*line :83:1*/ tmp3 != nil { if IOException_InstanceOf(tmp3) { var e IOException_I = IOException_Cast(tmp3)














		panic(Thrown(InternalError_New_Throwable(e))) } else {
//line :83:1
			panic(tmp3) } }; var propsFile /*line :99:1*/*String = System_GetProperty_String__String(Lit_2647); if
	propsFile == nil {
		var tmp4 *String = StaticProperty_JavaHome__String(); var tmp5 *String; File_Init(); tmp5 = File_separator; var tmp6 *String = tmp5; var tmp7 *String; File_Init(); tmp7 = File_separator; propsFile = Concat(tmp4, tmp6, Lit_2648, tmp7, Lit_2649) }; tmp10 := func() (exc Throwable_I) { defer Catch(&exc)






			{ var propFile *File = File_New_String(propsFile)
				if NN(propFile).Exists__Z() {
					var props Properties_I = Properties_New(); var fr *FileReader = FileReader_New_File(propFile); tmp8 := func() (exc Throwable_I) { defer Catch(&exc)
						props.Load_Reader__V(Up_FileReader_Reader(fr)); return nil }(); if tmp8 == nil { NN(fr).Close__V() }; if tmp8 != nil { if true { var t_101791 Throwable_I = tmp8; tmp9 := func() (exc Throwable_I) { defer Catch(&exc); NN(fr).Close__V(); return nil }(); if tmp9 != nil { if true { var x_101792 Throwable_I = tmp9; t_101791.AddSuppressed_Throwable__V(x_101792) } }; panic(Thrown(t_101791)) } }
					var propertiesPattern *Pattern = Pattern_Compile_String__Pattern(Lit_2650); var currencyEntries List = Currency_GetValidCurrencyData_Properties_Pattern__List(props, propertiesPattern)




					currencyEntries.ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0 any) { Currency_ReplaceCurrencyData_Currency_CurrencyProperty__V(Currency_CurrencyProperty_Cast(p0)) }}) } }; return nil }(); if /*line :107:1*/ tmp10 != nil { if IOException_InstanceOf(tmp10) { var e_2 IOException_I = IOException_Cast(tmp10)












						Currency_CurrencyProperty_Info_String_Throwable__V(Lit_2651, e_2) } else {
//line :107:1
							panic(tmp10) } } }


















func Currency_New_String_I_I(p0 *String, p1, p2 int32) *Currency { Currency_Init(); t := &Currency{}; t.Ctor_String_I_I(p0, p1, p2); return t }
//line :126:1
func (t *Currency) Ctor_String_I_I(currencyCode *String, defaultFractionDigits, numericCode int32) {
	t.F_currencyCode = currencyCode
	t.F_defaultFractionDigits = defaultFractionDigits
	t.F_numericCode = numericCode
}
func Currency_GetInstance_String__Currency(currencyCode *String) *Currency { Currency_Init()
	return Currency_GetInstance_String_I_I__Currency(currencyCode, -2147483648, 0)
}
func Currency_GetInstance_String_I_I__Currency(currencyCode *String, defaultFractionDigits, numericCode int32) *Currency { Currency_Init()


	var instance *Currency = Currency_Cast(Currency_instances.Get_O__O(currencyCode.Ref()))
	if !(instance == nil) { return instance } else {


		if defaultFractionDigits == -2147483648 {
			var found bool = false
			if NN(currencyCode).Length__I() == 3 { } else {
				panic(Thrown(IllegalArgumentException_New_String(Lit_2652.Formatted_O1__String(RefArrayOf(Object_class, currencyCode.Ref())))))
			}


			var char1 uint16 = NN(currencyCode).CharAt_I__C(0); var char2 uint16 = NN(currencyCode).CharAt_I__C(1); var tableEntry int32 = Currency_GetMainTableEntry_C_C__I(char1, char2); var tmp1 bool; var tmp2 bool; var tmp3 bool


			tmp3 = tableEntry&512 == 0; if tmp3 {

				tmp3 = !(tableEntry == 127) }
//line :151:1
			tmp2 = tmp3; if tmp2 {


				tmp2 = int32(NN(currencyCode).CharAt_I__C(2))-65 == tableEntry&31 }
//line :151:1
			tmp1 = tmp2; if tmp1 {





				defaultFractionDigits = tableEntry & 480 >> 5



				numericCode = tableEntry & 1047552 >> 10



				found = true } else {
					var fractionAndNumericCode *IntArray = Currency_SpecialCaseEntry_FindEntry_String__I1(currencyCode)
					if !(fractionAndNumericCode == nil) {
						defaultFractionDigits = fractionAndNumericCode.A[0]
						numericCode = fractionAndNumericCode.A[1]
						found = true } }
			if found { } else {
				var ocEntry *Currency_OtherCurrencyEntry = Currency_OtherCurrencyEntry_FindEntry_String__Currency_OtherCurrencyEntry(currencyCode)
				if ocEntry == nil {
					panic(Thrown(IllegalArgumentException_New_String(Lit_2653.Formatted_O1__String(RefArrayOf(Object_class, currencyCode.Ref())))))
				}


				defaultFractionDigits = ocEntry.F_fraction
				numericCode = ocEntry.F_numericCode } }
		var currencyVal *Currency = Currency_New_String_I_I(currencyCode, defaultFractionDigits, numericCode)
		instance = Currency_Cast(Currency_instances.PutIfAbsent_O_O__O(currencyCode.Ref(), currencyVal.Ref()))
		if !(instance == nil) { return instance } else { return currencyVal
		} } }
func Currency_GetInstance_Locale__Currency(locale *Locale) *Currency { Currency_Init()
	var override *String = NN(locale).GetUnicodeLocaleType_String__String(Lit_2654)
	if !(override == nil) { tmp2, tmp3, tmp4 := func() (ctl int32, rv *Currency, exc Throwable_I) { defer Catch(&exc)

		{ var tmp1 *Locale; Locale_Init(); tmp1 = Locale_ROOT; return 2, Currency_GetInstance_String__Currency(NN(override).ToUpperCase_Locale__String(tmp1)), nil }; return 0, nil, nil }()
//line :187:1
		if tmp4 != nil { if IllegalArgumentException_InstanceOf(tmp4) { var iae IllegalArgumentException_I = IllegalArgumentException_Cast(tmp4); _ = iae } else { panic(tmp4) } }; switch tmp2 { case 2: { return tmp3
		}
		} }
	var country *String = NN(CalendarDataUtility_FindRegionOverride_Locale__Locale(locale)).GetCountry__String(); var tmp5 bool; var tmp6 bool
	tmp6 = country == nil; if !tmp6 { tmp6 = !NN(country).Matches_String__Z(Lit_2655) }; tmp5 = tmp6; if tmp5 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2656.Formatted_O1__String(RefArrayOf(Object_class, locale.Ref())))))
	}


	var char1 uint16 = NN(country).CharAt_I__C(0); var char2 uint16 = NN(country).CharAt_I__C(1); var tableEntry int32 = Currency_GetMainTableEntry_C_C__I(char1, char2); var tmp7 bool; var tmp8 bool


	tmp8 = tableEntry&512 == 0; if tmp8 {
		tmp8 = !(tableEntry == 127) }
//line :199:1
	tmp7 = tmp8; if tmp7 {

		var finalChar uint16 = uint16(tableEntry&31 + 65); var defaultFractionDigits int32 = tableEntry & 480 >> 5; var numericCode int32 = tableEntry & 1047552 >> 10; var sb *StringBuilder = StringBuilder_New_String(country)












		NN(sb).Append_C__StringBuilder(finalChar)
		return Currency_GetInstance_String_I_I__Currency(NN(sb).ToString__String(), defaultFractionDigits, numericCode) } else {

			if tableEntry == 127 {
				panic(Thrown(IllegalArgumentException_New_String(Lit_2656.Formatted_O1__String(RefArrayOf(Object_class, locale.Ref())))))
			}



			if tableEntry == 512 { return nil } else {
				var index int32 = Currency_SpecialCaseEntry_ToIndex_I__I(tableEntry); var scEntry *Currency_SpecialCaseEntry = Currency_SpecialCaseEntry_Cast(Currency_specialCasesList.Get_I__O(index)); var tmp9 bool; var tmp10 bool

				tmp10 = scEntry.F_cutOverTime == 9223372036854775807; if !tmp10 {
					tmp10 = System_CurrentTimeMillis__J() < scEntry.F_cutOverTime }
//line :226:1
				tmp9 = tmp10; if tmp9 {

					var tmp11 *String = scEntry.F_oldCurrency; var tmp12 int32 = scEntry.F_oldCurrencyFraction; return Currency_GetInstance_String_I_I__Currency(tmp11, tmp12, scEntry.F_oldCurrencyNumericCode) } else {


						var tmp13 *String = scEntry.F_newCurrency; var tmp14 int32 = scEntry.F_newCurrencyFraction; return Currency_GetInstance_String_I_I__Currency(tmp13, tmp14, scEntry.F_newCurrencyNumericCode)
					}
			}
		} }
func Currency_GetAvailableCurrencies__Set() Set { Currency_Init()
	return HashSet_New_Collection(Collection_Cast(Currency_available.Get__O()))
}
func Currency_AvailableCurrencies__Stream() Stream { Currency_Init()
	return HashSet_Cast(Currency_available.Get__O()).Stream__Stream()
}
func Currency_ComputeAllCurrencies__HashSet() HashSet_I { Currency_Init()
	var sysTime int64 = System_CurrentTimeMillis__J(); var available HashSet_I = HashSet_NewHashSet_I__HashSet(256)
	var c1 uint16 = 65
L1: for {
	if int32(c1) <= 90 {
		var c2 uint16 = 65; L2: for {
			if int32(c2) <= 90 {
				var tableEntry int32 = Currency_GetMainTableEntry_C_C__I(c1, c2); var tmp1 bool; var tmp2 bool

				tmp2 = tableEntry&512 == 0; if tmp2 {
					tmp2 = !(tableEntry == 127) }
//line :250:1
				tmp1 = tmp2
//line :249:1
				if tmp1 {


					var finalChar uint16 = uint16(tableEntry&31 + 65); var defaultFractionDigits int32 = tableEntry & 480 >> 5; var numericCode int32 = tableEntry & 1047552 >> 10; var sb *StringBuilder = StringBuilder_New()












					NN(sb).Append_C__StringBuilder(c1)
					NN(sb).Append_C__StringBuilder(c2)
					NN(sb).Append_C__StringBuilder(finalChar)
					available.Add_O__Z(Currency_GetInstance_String_I_I__Currency(NN(sb).ToString__String(), defaultFractionDigits, numericCode).Ref())

					c2 = uint16(int32(c2) + 1); continue L2 } else {
//line :249:1
						var tmp3 bool; var tmp4 bool; var tmp5 bool





















						tmp5 = tableEntry&512 == 512; if tmp5 {

							tmp5 = !(tableEntry == 127) }
//line :271:1
						tmp4 = tmp5; if tmp4 {


							tmp4 = !(tableEntry == 512) }
//line :271:1
						tmp3 = tmp4
//line :249:1
						if tmp3 {

























							var index int32 = Currency_SpecialCaseEntry_ToIndex_I__I(tableEntry); var scEntry *Currency_SpecialCaseEntry = Currency_SpecialCaseEntry_Cast(Currency_specialCasesList.Get_I__O(index)); var tmp6 bool; var tmp7 bool

							tmp7 = scEntry.F_cutOverTime == 9223372036854775807; if !tmp7 {
								tmp7 = sysTime < scEntry.F_cutOverTime }
//line :277:1
							tmp6 = tmp7; if tmp6 {


								var tmp8 *String = scEntry.F_oldCurrency; var tmp9 int32 = scEntry.F_oldCurrencyFraction; available.Add_O__Z(Currency_GetInstance_String_I_I__Currency(tmp8, tmp9, scEntry.F_oldCurrencyNumericCode).Ref())




								c2 = uint16(int32(c2) + 1); continue L2 } else {

									var tmp10 *String = scEntry.F_newCurrency; var tmp11 int32 = scEntry.F_newCurrencyFraction; available.Add_O__Z(Currency_GetInstance_String_I_I__Currency(tmp10, tmp11, scEntry.F_newCurrencyNumericCode).Ref())




									c2 = uint16(int32(c2) + 1); continue L2 } } else {
										c2 = uint16(int32(c2) + 1); continue L2 } } }
//line :246:1
			break L2
		}














































		c1 = uint16(int32(c1) + 1); continue L1 }
//line :244:1
	break L1
}

















































	var i_101793 Iterator = Currency_otherCurrenciesList.Iterator__Iterator(); for i_101793.HasNext__Z() { var entry *Currency_OtherCurrencyEntry = Currency_OtherCurrencyEntry_Cast(i_101793.Next__O())
		available.Add_O__Z(Currency_GetInstance_String__Currency(entry.F_currencyCode).Ref()) }
//line :242:1
	return available
}























































func (t *Currency) GetCurrencyCode__String() *String { return t.F_currencyCode }

func (t *Currency) GetSymbol__String() *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return t.GetSymbol_Locale__String(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *Currency) GetSymbol_Locale__String(locale *Locale) *String {
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(CurrencyNameProvider_class)
	locale = CalendarDataUtility_FindRegionOverride_Locale__Locale(locale)
	var symbol *String; var tmp1 *Currency_CurrencyNameGetter; Currency_CurrencyNameGetter_Init(); tmp1 = Currency_CurrencyNameGetter_INSTANCE; var tmp2 LocaleServiceProviderPool_LocalizedObjectGetter = Up_Currency_CurrencyNameGetter_LocaleServiceProviderPool_LocalizedObjectGetter(tmp1); var tmp3 *Locale = locale; var tmp4 *String = t.F_currencyCode; symbol = String_Cast(NN(pool).GetLocalizedObject_LocaleServiceProviderPool_LocalizedObjectGetter_Locale_String_O1__O(tmp2, tmp3, tmp4, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(0))))





	if !(symbol == nil) { return symbol } else { return t.F_currencyCode
	} }
func (t *Currency) GetDefaultFractionDigits__I() int32 { return t.F_defaultFractionDigits }


func (t *Currency) GetNumericCode__I() int32 { return t.F_numericCode }

func (t *Currency) GetNumericCodeAsString__String() *String {
	if t.F_numericCode < 100 {
		var sb *StringBuilder = StringBuilder_New()
		NN(sb).Append_C__StringBuilder(48)
		if t.F_numericCode < 10 { NN(sb).Append_C__StringBuilder(48) }
		return NN(NN(sb).Append_I__StringBuilder(t.F_numericCode)).ToString__String() } else {
			return String_ValueOf_I__String(t.F_numericCode)
		} }
func (t *Currency) GetDisplayName__String() *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return t.GetDisplayName_Locale__String(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *Currency) GetDisplayName_Locale__String(locale *Locale) *String {
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(CurrencyNameProvider_class); var result *String; var tmp1 *Currency_CurrencyNameGetter
	Currency_CurrencyNameGetter_Init(); tmp1 = Currency_CurrencyNameGetter_INSTANCE; var tmp2 LocaleServiceProviderPool_LocalizedObjectGetter = Up_Currency_CurrencyNameGetter_LocaleServiceProviderPool_LocalizedObjectGetter(tmp1); var tmp3 *String = t.F_currencyCode; result = String_Cast(NN(pool).GetLocalizedObject_LocaleServiceProviderPool_LocalizedObjectGetter_Locale_String_O1__O(tmp2, locale, tmp3, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(1))))





	if !(result == nil) { return result } else { return t.F_currencyCode
	} }
func (t *Currency) ToString__String() *String { return t.F_currencyCode }

func (t *Currency) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Currency.readResolve()Ljava/lang/Object;")) }


func Currency_GetMainTableEntry_C_C__I(char1, char2 uint16) int32 { Currency_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = int32(char1) < 65; if !tmp4 { tmp4 = int32(char1) > 90 }; tmp3 = tmp4; if !tmp3 { tmp3 = int32(char2) < 65 }; tmp2 = tmp3; if !tmp2 { tmp2 = int32(char2) > 90 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2657.Formatted_O1__String(RefArrayOf(Object_class, Character_ValueOf_C__Character(char1), Character_ValueOf_C__Character(char2))))))
	}
	return Currency_mainTable.A[(int32(char1)-65)*26+(int32(char2)-65)]
}


func Currency_SetMainTableEntry_C_C_I__V(char1, char2 uint16, entry int32) { Currency_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = int32(char1) < 65; if !tmp4 { tmp4 = int32(char1) > 90 }; tmp3 = tmp4; if !tmp3 { tmp3 = int32(char2) < 65 }; tmp2 = tmp3; if !tmp2 { tmp2 = int32(char2) > 90 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2657.Formatted_O1__String(RefArrayOf(Object_class, Character_ValueOf_C__Character(char1), Character_ValueOf_C__Character(char2))))))
	}
	Currency_mainTable.A[(int32(char1)-65)*26+(int32(char2)-65)] = entry
}








func (t *Currency_CurrencyNameGetter) GetObject_CurrencyNameProvider_Locale_String_O1__String(currencyNameProvider CurrencyNameProvider_I, locale *Locale, key *String, params *RefArray) *String {

	if !A2g_AssertionsDisabled && !(int32(len(params.A)) == 1) { panic(Thrown(AssertionError_New())) }
	var type_ int32 = NN(Integer_Cast(params.A[0])).IntValue__I()
	switch type_ { case 0:
		return currencyNameProvider.GetSymbol_String_Locale__String(key, locale); case 1:
		return currencyNameProvider.GetDisplayName_String_Locale__String(key, locale); default:
		if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New())) }}
//line :371:1
	return nil
}





func Currency_ReadIntArray_DataInputStream_I__I1(dis *DataInputStream, count int32) *IntArray { Currency_Init()

	var ret *IntArray = NewIntArray(count); var i int32 = 0
L1: for { if i < count { ret.A[i] = NN(dis).ReadInt__I(); i = i + 1; continue L1 }; break L1 }
//line :380:1
	return ret
}


func Currency_ReadSpecialCases_DataInputStream_I__List(dis *DataInputStream, count int32) List { Currency_Init()

	var list List = ArrayList_New_I(count); var cutOverTime int64 = 0; var oldCurrency *String; var newCurrency *String
	var oldCurrencyFraction int32 = 0
	var newCurrencyFraction int32 = 0
	var oldCurrencyNumericCode int32 = 0
	var newCurrencyNumericCode int32 = 0
	var i int32 = 0


L1: for {
	if i < count {
		cutOverTime = NN(dis).ReadLong__J()
		oldCurrency = NN(dis).ReadUTF__String()
		newCurrency = NN(dis).ReadUTF__String()
		oldCurrencyFraction = NN(dis).ReadInt__I()
		newCurrencyFraction = NN(dis).ReadInt__I()
		oldCurrencyNumericCode = NN(dis).ReadInt__I()
		newCurrencyNumericCode = NN(dis).ReadInt__I()
		var sc *Currency_SpecialCaseEntry = Currency_SpecialCaseEntry_New_J_String_String_I_I_I_I(cutOverTime, oldCurrency, newCurrency, oldCurrencyFraction, newCurrencyFraction, oldCurrencyNumericCode, newCurrencyNumericCode)






		list.Add_O__Z(sc.Ref())
		i = i + 1; continue L1 }
//line :394:1
	break L1 }
//line :386:1
	return list
}


























func Currency_ReadOtherCurrencies_DataInputStream_I__List(dis *DataInputStream, count int32) List { Currency_Init()

	var list List = ArrayList_New_I(count); var currencyCode *String
	var fraction int32 = 0
	var numericCode int32 = 0
	var i int32 = 0
L1: for {
	if i < count {
		currencyCode = NN(dis).ReadUTF__String()
		fraction = NN(dis).ReadInt__I()
		numericCode = NN(dis).ReadInt__I()
		var oc *Currency_OtherCurrencyEntry = Currency_OtherCurrencyEntry_New_String_I_I(currencyCode, fraction, numericCode)
		list.Add_O__Z(oc.Ref())
		i = i + 1; continue L1 }
//line :420:1
	break L1 }
//line :416:1
	return list
}












func Currency_GetValidCurrencyData_Properties_Pattern__List(props Properties_I, pattern *Pattern) List { Currency_Init()

	var keys Set = props.StringPropertyNames__Set(); var propertyEntries List = ArrayList_New(); var currencyCodeGroup Map = Map_Cast(keys.Stream__Stream().Map_Function__Stream(&Function_Fn{Fn: func(p0 any) any { var k *String = String_Cast(p0); var tmp1 *Locale; Locale_Init(); tmp1 = Locale_ROOT; var tmp2 *String = NN(k).ToUpperCase_Locale__String(tmp1); var tmp3 *String = props.GetProperty_String__String(k); var tmp4 *Locale; Locale_Init(); tmp4 = Locale_ROOT; return Currency_CurrencyProperty_GetValidEntry_String_String_Pattern__Optional(tmp2, NN(tmp3).ToUpperCase_Locale__String(tmp4), pattern).Ref() }}).FlatMap_Function__Stream(&Function_Fn{Fn: func(p0_2 any) any { var o *Optional = Optional_Cast(p0_2); return NN(o).Stream__Stream() }}).Collect_Collector__O(Collectors_GroupingBy_Function__Collector(&Function_Fn{Fn: func(p0_3 any) any { var entry *Currency_CurrencyProperty = Currency_CurrencyProperty_Cast(p0_3); return entry.F_currencyCode.Ref() }})))
























	currencyCodeGroup.ForEach_BiConsumer__V(&BiConsumer_Fn{Fn: func(p0_4, p1 any) { var curCode *String = String_Cast(p0_4); var list List = List_Cast(p1); var inconsistent bool = Currency_CurrencyProperty_ContainsInconsistentInstances_List__Z(list); _ = curCode; if inconsistent {



		list.ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0_5 any) { var prop *Currency_CurrencyProperty = Currency_CurrencyProperty_Cast(p0_5);

			Currency_CurrencyProperty_Info_String_Throwable__V(Concat(Lit_2658, prop.F_country, Lit_2659), nil) }}) } else {




				propertyEntries.AddAll_Collection__Z(list) } }})
//line :432:1
	return propertyEntries
}





































func Currency_ReplaceCurrencyData_Currency_CurrencyProperty__V(prop *Currency_CurrencyProperty) { Currency_Init()
	var ctry *String = prop.F_country; var code *String = prop.F_currencyCode; var numeric int32 = prop.F_numericCode; var fraction int32 = prop.F_fraction; var entry int32 = numeric << 10; var index int32 = Currency_SpecialCaseEntry_IndexOf_String_I_I__I(code, fraction, numeric)
	var scCurrencyCodeIndex int32 = -1





	if index == -1 {
		scCurrencyCodeIndex = Currency_SpecialCaseEntry_CurrencyCodeIndex_String__I(code)
		if scCurrencyCodeIndex == -1 { } else {
			var tmp1 List = Currency_specialCasesList; tmp1.Set_I_O__O(scCurrencyCodeIndex, Currency_SpecialCaseEntry_New_String_I_I(code, fraction, numeric))
			var oe *Currency_OtherCurrencyEntry = Currency_OtherCurrencyEntry_FindEntry_String__Currency_OtherCurrencyEntry(code)
			if !(oe == nil) {
				var oIndex int32 = Currency_otherCurrenciesList.IndexOf_O__I(oe.Ref()); var tmp2 List = Currency_otherCurrenciesList
				tmp2.Set_I_O__O(oIndex, Currency_OtherCurrencyEntry_New_String_I_I(code, fraction, numeric)) } } }
	var tmp3 bool; var tmp4 bool; tmp4 = index == -1; if tmp4 {
		var tmp5 bool; tmp5 = !(int32(NN(ctry).CharAt_I__C(0)) == int32(NN(code).CharAt_I__C(0))); if !tmp5 {
			tmp5 = !(int32(NN(ctry).CharAt_I__C(1)) == int32(NN(code).CharAt_I__C(1))) }
//line :488:1
		tmp4 = tmp5 }
//line :487:1
	tmp3 = tmp4; if tmp3 {


		if scCurrencyCodeIndex == -1 {

			var tmp6 List = Currency_specialCasesList; tmp6.Add_O__Z(Currency_SpecialCaseEntry_New_String_I_I(code, fraction, numeric))
			index = Currency_specialCasesList.Size__I() - 1 } else {
				index = scCurrencyCodeIndex }
		Currency_UpdateMainTableEntry_String_I_I__V(code, fraction, numeric) }
	if index == -1 {
		entry = entry | (fraction<<5 | (int32(NN(code).CharAt_I__C(2)) - 65)) } else {





			entry = 512 | (index + 1)
		}

	Currency_SetMainTableEntry_C_C_I__V(NN(ctry).CharAt_I__C(0), NN(ctry).CharAt_I__C(1), entry)
}
func Currency_UpdateMainTableEntry_String_I_I__V(code *String, fraction, numeric int32) { Currency_Init()
	var tableEntry int32 = Currency_GetMainTableEntry_C_C__I(NN(code).CharAt_I__C(0), NN(code).CharAt_I__C(1)); var entry int32 = numeric << 10; var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = tableEntry&512 == 0; if tmp3 {
		tmp3 = !(tableEntry == 127) }
//line :511:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = int32(NN(code).CharAt_I__C(2))-65 == tableEntry&31 }
//line :511:1
	tmp1 = tmp2; if tmp1 {



		var numericCode int32 = tableEntry & 1047552 >> 10; var defaultFractionDigits int32 = tableEntry & 480 >> 5; var tmp4 bool; var tmp5 bool






		tmp5 = !(numeric == numericCode); if !tmp5 { tmp5 = !(fraction == defaultFractionDigits) }; tmp4 = tmp5; if tmp4 {
			entry = entry | (fraction<<5 | (int32(NN(code).CharAt_I__C(2)) - 65))





			Currency_SetMainTableEntry_C_C_I__V(NN(code).CharAt_I__C(0), NN(code).CharAt_I__C(1), entry)
		}
	}
}













func Currency_SpecialCaseEntry_New_J_String_String_I_I_I_I(p0 int64, p1, p2 *String, p3, p4, p5, p6 int32) *Currency_SpecialCaseEntry { t := &Currency_SpecialCaseEntry{}; t.Ctor_J_String_String_I_I_I_I(p0, p1, p2, p3, p4, p5, p6); return t }
//line :546:1
func (t *Currency_SpecialCaseEntry) Ctor_J_String_String_I_I_I_I(cutOverTime int64, oldCurrency, newCurrency *String, oldCurrencyFraction, newCurrencyFraction, oldCurrencyNumericCode, newCurrencyNumericCode int32) {


	t.F_cutOverTime = cutOverTime
	t.F_oldCurrency = oldCurrency
	t.F_newCurrency = newCurrency
	t.F_oldCurrencyFraction = oldCurrencyFraction
	t.F_newCurrencyFraction = newCurrencyFraction
	t.F_oldCurrencyNumericCode = oldCurrencyNumericCode
	t.F_newCurrencyNumericCode = newCurrencyNumericCode
}
func Currency_SpecialCaseEntry_New_String_I_I(p0 *String, p1, p2 int32) *Currency_SpecialCaseEntry { t := &Currency_SpecialCaseEntry{}; t.Ctor_String_I_I(p0, p1, p2); return t }
//line :557:1
func (t *Currency_SpecialCaseEntry) Ctor_String_I_I(currencyCode *String, fraction, numericCode int32) { t.Ctor_J_String_String_I_I_I_I(9223372036854775807, currencyCode, Lit_69, fraction, 0, numericCode, 0) }


func Currency_SpecialCaseEntry_IndexOf_String_I_I__I(code *String, fraction, numeric int32) int32 {
	var size int32; var tmp1 List; Currency_Init(); tmp1 = Currency_specialCasesList; size = tmp1.Size__I()
	var index int32 = 0; L1: for {
		if index < size {
			var scEntry *Currency_SpecialCaseEntry; var tmp2 List; Currency_Init(); tmp2 = Currency_specialCasesList; scEntry = Currency_SpecialCaseEntry_Cast(tmp2.Get_I__O(index))
			var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = NN(scEntry.F_oldCurrency).Equals_O__Z(code.Ref()); if tmp6 {
				tmp6 = scEntry.F_oldCurrencyFraction == fraction }
//line :565:1
			tmp5 = tmp6; if tmp5 {

				tmp5 = scEntry.F_oldCurrencyNumericCode == numeric }
//line :565:1
			tmp4 = tmp5; if tmp4 {


				tmp4 = scEntry.F_cutOverTime == 9223372036854775807 }
//line :565:1
			tmp3 = tmp4; if tmp3 {



				return index } else {
					index = index + 1; continue L1 } }
//line :562:1
		break L1 }
//line :561:1
	return -1
}










func Currency_SpecialCaseEntry_FindEntry_String__I1(code *String) *IntArray {
	var fractionAndNumericCode *IntArray; var size int32; var tmp1 List
	Currency_Init(); tmp1 = Currency_specialCasesList; size = tmp1.Size__I()
	var index int32 = 0; L1: for {
		if index < size {
			var scEntry *Currency_SpecialCaseEntry; var tmp2 List; Currency_Init(); tmp2 = Currency_specialCasesList; scEntry = Currency_SpecialCaseEntry_Cast(tmp2.Get_I__O(index))
			var tmp3 bool; var tmp4 bool
			tmp4 = NN(scEntry.F_oldCurrency).Equals_O__Z(code.Ref()); if tmp4 {
				var tmp5 bool; tmp5 = scEntry.F_cutOverTime == 9223372036854775807; if !tmp5 {
					tmp5 = System_CurrentTimeMillis__J() < scEntry.F_cutOverTime }
//line :581:1
				tmp4 = tmp5 }
//line :580:1
			tmp3 = tmp4
//line :579:1
			if tmp3 {




				fractionAndNumericCode = NewIntArray(2)
				fractionAndNumericCode.A[0] = scEntry.F_oldCurrencyFraction
				fractionAndNumericCode.A[1] = scEntry.F_oldCurrencyNumericCode } else {
//line :579:1
					var tmp6 bool; var tmp7 bool







					tmp7 = NN(scEntry.F_newCurrency).Equals_O__Z(code.Ref()); if tmp7 {
						tmp7 = System_CurrentTimeMillis__J() >= scEntry.F_cutOverTime }
//line :587:1
					tmp6 = tmp7
//line :579:1
					if tmp6 {










						fractionAndNumericCode = NewIntArray(2)
						fractionAndNumericCode.A[0] = scEntry.F_newCurrencyFraction
						fractionAndNumericCode.A[1] = scEntry.F_newCurrencyNumericCode } else {
							index = index + 1; continue L1 } } }
//line :576:1
		break L1 }
//line :574:1
	return fractionAndNumericCode
}




















func Currency_SpecialCaseEntry_CurrencyCodeIndex_String__I(code *String) int32 {
	var size int32; var tmp1 List; Currency_Init(); tmp1 = Currency_specialCasesList; size = tmp1.Size__I()
	var index int32 = 0; L1: for {
		if index < size {
			var scEntry *Currency_SpecialCaseEntry; var tmp2 List; Currency_Init(); tmp2 = Currency_specialCasesList; scEntry = Currency_SpecialCaseEntry_Cast(tmp2.Get_I__O(index))
			var tmp3 bool; var tmp4 bool
			tmp4 = NN(scEntry.F_oldCurrency).Equals_O__Z(code.Ref()); if tmp4 {
				var tmp5 bool; tmp5 = scEntry.F_cutOverTime == 9223372036854775807; if !tmp5 {
					tmp5 = System_CurrentTimeMillis__J() < scEntry.F_cutOverTime }
//line :603:1
				tmp4 = tmp5 }
//line :602:1
			tmp3 = tmp4
//line :601:1
			if tmp3 {



				return index } else {
//line :601:1
					var tmp6 bool; var tmp7 bool




					tmp7 = NN(scEntry.F_newCurrency).Equals_O__Z(code.Ref()); if tmp7 {
						tmp7 = System_CurrentTimeMillis__J() >= scEntry.F_cutOverTime }
//line :606:1
					tmp6 = tmp7
//line :601:1
					if tmp6 {






						return index } else {
							index = index + 1; continue L1 } } }
//line :598:1
		break L1 }
//line :597:1
	return -1
}













func Currency_SpecialCaseEntry_ToIndex_I__I(tableEntry int32) int32 {
	return tableEntry&31 - 1
}








func Currency_OtherCurrencyEntry_New_String_I_I(p0 *String, p1, p2 int32) *Currency_OtherCurrencyEntry { t := &Currency_OtherCurrencyEntry{}; t.Ctor_String_I_I(p0, p1, p2); return t }
//line :623:1
func (t *Currency_OtherCurrencyEntry) Ctor_String_I_I(currencyCode *String, fraction, numericCode int32) {
	t.F_currencyCode = currencyCode
	t.F_fraction = fraction
	t.F_numericCode = numericCode
}
func Currency_OtherCurrencyEntry_FindEntry_String__Currency_OtherCurrencyEntry(code *String) *Currency_OtherCurrencyEntry {
	var size int32; var tmp1 List; Currency_Init(); tmp1 = Currency_otherCurrenciesList; size = tmp1.Size__I()
	var index int32 = 0; L1: for {
		if index < size {
			var ocEntry *Currency_OtherCurrencyEntry; var tmp2 List; Currency_Init(); tmp2 = Currency_otherCurrenciesList; ocEntry = Currency_OtherCurrencyEntry_Cast(tmp2.Get_I__O(index))
			if NN(ocEntry.F_currencyCode).EqualsIgnoreCase_String__Z(code) {
				return ocEntry } else {
					index = index + 1; continue L1 } }
//line :630:1
		break L1 }
//line :629:1
	return nil
}


















func Currency_CurrencyProperty_New_String_String_I_I_String(p0, p1 *String, p2, p3 int32, p4 *String) *Currency_CurrencyProperty { t := &Currency_CurrencyProperty{}; t.Ctor_String_String_I_I_String(p0, p1, p2, p3, p4); return t }
//line :649:1
func (t *Currency_CurrencyProperty) Ctor_String_String_I_I_String(country, currencyCode *String, fraction, numericCode int32, date *String) {

	t.F_country = country
	t.F_currencyCode = currencyCode
	t.F_fraction = fraction
	t.F_numericCode = numericCode
	t.F_date = date
}
func Currency_CurrencyProperty_GetValidEntry_String_String_Pattern__Optional(ctry, curData *String, pattern *Pattern) *Optional {


	var prop *Currency_CurrencyProperty
	if !(NN(ctry).Length__I() == 2) { } else {
		prop = Currency_CurrencyProperty_ParseProperty_String_String_Pattern__Currency_CurrencyProperty(ctry, curData, pattern)
		var tmp1 bool; var tmp2 bool
		tmp2 = prop == nil; if !tmp2 {
			var tmp3 bool; tmp3 = prop.F_date == nil; if tmp3 {
				tmp3 = NN(curData).Chars__IntStream().Map_IntUnaryOperator__IntStream(&IntUnaryOperator_Fn{Fn: func(p0 int32) int32 { var c int32 = p0; var tmp4 int32; if
					c == 44 { tmp4 = 1 } else { tmp4 = 0 }; return tmp4 }}).Sum__I() >= 3 }
//line :665:1
			tmp2 = tmp3 }
//line :664:1
		tmp1 = tmp2
//line :663:1
		if tmp1 {





			prop = nil } else {
//line :663:1
				if prop.F_fraction > 9 {






					prop = nil } else {
//line :663:1
						tmp7 := func() (exc Throwable_I) { defer Catch(&exc)









							{ var tmp5 bool; var tmp6 bool; tmp6 = !(prop.F_date == nil); if tmp6 {
								tmp6 = !Currency_CurrencyProperty_IsPastCutoverDate_String__Z(prop.F_date) }
//line :673:1
								tmp5 = tmp6; if tmp5 {

									prop = nil } }
//line :663:1
							return nil
						}()







						if tmp7 != nil { if DateTimeParseException_InstanceOf(tmp7) { var ex *DateTimeParseException = DateTimeParseException_Cast(tmp7); _ = ex



							prop = nil } else {
//line :672:1
								panic(tmp7)
							}
						}
					}
			} }
	if prop == nil {
		Currency_CurrencyProperty_Info_String_Throwable__V(Concat(Lit_2658, ctry, Lit_2660), nil)
	}
	return Optional_OfNullable_O__Optional(prop.Ref())
}
func Currency_CurrencyProperty_ParseProperty_String_String_Pattern__Currency_CurrencyProperty(ctry, curData *String, pattern *Pattern) *Currency_CurrencyProperty {

	var m *Matcher = NN(pattern).Matcher_CharSequence__Matcher(Up_String_CharSequence(curData))
	if !NN(m).Find__Z() { return nil } else {
		return Currency_CurrencyProperty_New_String_String_I_I_String(ctry, NN(m).Group_I__String(1), Integer_ParseInt_String__I(NN(m).Group_I__String(3)), Integer_ParseInt_String__I(NN(m).Group_I__String(2)), NN(m).Group_I__String(4))
	}
}



func Currency_CurrencyProperty_ContainsInconsistentInstances_List__Z(list List) bool {
	var numCode int32 = Currency_CurrencyProperty_Cast(list.Get_I__O(0)).F_numericCode; var fractionDigit int32 = Currency_CurrencyProperty_Cast(list.Get_I__O(0)).F_fraction

	return list.Stream__Stream().AnyMatch_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var prop *Currency_CurrencyProperty = Currency_CurrencyProperty_Cast(p0); var tmp1 bool; var tmp2 bool; tmp2 =

		!(prop.F_numericCode == numCode); if !tmp2 {
			tmp2 = !(prop.F_fraction == fractionDigit) }; tmp1 = tmp2; return tmp1 },
	}) }
func Currency_CurrencyProperty_IsPastCutoverDate_String__Z(cutOver *String) bool {
	var tmp1 int64 = System_CurrentTimeMillis__J(); var tmp2 *DateTimeFormatter; DateTimeFormatter_Init(); tmp2 = DateTimeFormatter_ISO_LOCAL_DATE_TIME; var tmp3 *LocalDateTime = LocalDateTime_Parse_CharSequence_DateTimeFormatter__LocalDateTime(Up_String_CharSequence(cutOver), tmp2); var tmp4 *ZoneOffset; ZoneOffset_Init(); tmp4 = ZoneOffset_UTC; return tmp1 > NN(NN(tmp3).ToInstant_ZoneOffset__Instant(tmp4)).ToEpochMilli__J()
}



func Currency_CurrencyProperty_Info_String_Throwable__V(message *String, t_ Throwable_I) {
	var logger any; _ = logger; logger = A2g_Missing[any]("class sun.util.logging.PlatformLogger is not in the closed world")
	if A2g_Missing[bool]("class sun.util.logging.PlatformLogger is not in the closed world") {
		if !(t_ == nil) { A2g_Missing[bool]("class sun.util.logging.PlatformLogger is not in the closed world") } else { A2g_Missing[bool]("class sun.util.logging.PlatformLogger is not in the closed world")
		}
	}
}
type Currency struct{ Object; F_currencyCode *String; F_defaultFractionDigits, F_numericCode int32 }

func (t *Currency) Is_Serializable() {}

const Currency_serialVersionUID int64 = -158308464356906721

var Currency_instances ConcurrentMap

var Currency_available LazyConstant

var Currency_formatVersion int32

var Currency_dataVersion int32

var Currency_mainTable *IntArray

var Currency_specialCasesList List

var Currency_otherCurrenciesList List

const Currency_MAGIC_NUMBER int32 = 1131770436

const Currency_A_TO_Z int32 = 26

const Currency_INVALID_COUNTRY_ENTRY int32 = 127

const Currency_COUNTRY_WITHOUT_CURRENCY_ENTRY int32 = 512

const Currency_SIMPLE_CASE_COUNTRY_MASK int32 = 0

const Currency_SIMPLE_CASE_COUNTRY_FINAL_CHAR_MASK int32 = 31

const Currency_SIMPLE_CASE_COUNTRY_DEFAULT_DIGITS_MASK int32 = 480

const Currency_SIMPLE_CASE_COUNTRY_DEFAULT_DIGITS_SHIFT int32 = 5

const Currency_SIMPLE_CASE_COUNTRY_MAX_DEFAULT_DIGITS int32 = 9

const Currency_SPECIAL_CASE_COUNTRY_MASK int32 = 512

const Currency_SPECIAL_CASE_COUNTRY_INDEX_MASK int32 = 31

const Currency_SPECIAL_CASE_COUNTRY_INDEX_DELTA int32 = 1

const Currency_COUNTRY_TYPE_MASK int32 = 512

const Currency_NUMERIC_CODE_MASK int32 = 1047552

const Currency_NUMERIC_CODE_SHIFT int32 = 10

const Currency_VALID_FORMAT_VERSION int32 = 3

const Currency_SYMBOL int32 = 0

const Currency_DISPLAYNAME int32 = 1

var Currency_init ClassInit

func Currency_Init() { if !Currency_init.Done() { Currency_init.Run(Currency_clinit) } }

func Currency_clinit() { Currency_instances = ConcurrentHashMap_New_I(7); Currency_available = LazyConstant_Of_Supplier__LazyConstant(&Supplier_Fn{Fn: func() any { return Currency_ComputeAllCurrencies__HashSet() }})
//line :80:1
	Currency_InitStatic__V()
}





















































































































































































































































































































































































































































































































































































































































































































func (t *Currency) Ref() any { if t == nil { return nil }; return t }

func (t *Currency) GetClass__Class() *Class { return Currency_class }

func (t *Currency) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Currency) CloneShallow() any { panic(CloneNotSupported(t)) }

func Currency_InstanceOf(x any) bool { _, ok := x.(*Currency); return ok }

func Currency_Cast(x any) *Currency { if x == nil { return nil }; v, ok := x.(*Currency); if !ok { panic(ClassCast(x, Currency_class)) }; return v }



type Currency_CurrencyNameGetter struct{ Object }

func (t *Currency_CurrencyNameGetter) Is_LocaleServiceProviderPool_LocalizedObjectGetter() {}

var Currency_CurrencyNameGetter_INSTANCE *Currency_CurrencyNameGetter

var Currency_CurrencyNameGetter_init ClassInit

func Currency_CurrencyNameGetter_Init() { if !Currency_CurrencyNameGetter_init.Done() { Currency_CurrencyNameGetter_init.Run(Currency_CurrencyNameGetter_clinit) } }

func Currency_CurrencyNameGetter_clinit() { Currency_CurrencyNameGetter_INSTANCE = Currency_CurrencyNameGetter_New() }

func Currency_CurrencyNameGetter_New() *Currency_CurrencyNameGetter { Currency_CurrencyNameGetter_Init(); t := &Currency_CurrencyNameGetter{}; t.Ctor(); return t }

func (t *Currency_CurrencyNameGetter) Ctor() {}

func (t *Currency_CurrencyNameGetter) GetObject_LocaleServiceProvider_Locale_String_O1__O(p0 LocaleServiceProvider_I, p1 *Locale, p2 *String, p3 *RefArray) any { return t.GetObject_CurrencyNameProvider_Locale_String_O1__String(CurrencyNameProvider_Cast(p0), p1, p2, p3).Ref() }

func (t *Currency_CurrencyNameGetter) Ref() any { if t == nil { return nil }; return t }

func (t *Currency_CurrencyNameGetter) GetClass__Class() *Class { return Currency_CurrencyNameGetter_class }

func (t *Currency_CurrencyNameGetter) ToString__String() *String { return Object_toString(t) }

func (t *Currency_CurrencyNameGetter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Currency_CurrencyNameGetter) CloneShallow() any { panic(CloneNotSupported(t)) }

func Currency_CurrencyNameGetter_InstanceOf(x any) bool { _, ok := x.(*Currency_CurrencyNameGetter); return ok }

func Currency_CurrencyNameGetter_Cast(x any) *Currency_CurrencyNameGetter { if x == nil { return nil }; v, ok := x.(*Currency_CurrencyNameGetter); if !ok { panic(ClassCast(x, Currency_CurrencyNameGetter_class)) }; return v }



type Currency_CurrencyProperty struct{ Object; F_country, F_currencyCode *String; F_fraction, F_numericCode int32; F_date *String }

func (t *Currency_CurrencyProperty) Ref() any { if t == nil { return nil }; return t }

func (t *Currency_CurrencyProperty) GetClass__Class() *Class { return Currency_CurrencyProperty_class }

func (t *Currency_CurrencyProperty) ToString__String() *String { return Object_toString(t) }

func (t *Currency_CurrencyProperty) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Currency_CurrencyProperty) CloneShallow() any { panic(CloneNotSupported(t)) }

func Currency_CurrencyProperty_InstanceOf(x any) bool { _, ok := x.(*Currency_CurrencyProperty); return ok }

func Currency_CurrencyProperty_Cast(x any) *Currency_CurrencyProperty { if x == nil { return nil }; v, ok := x.(*Currency_CurrencyProperty); if !ok { panic(ClassCast(x, Currency_CurrencyProperty_class)) }; return v }



type Currency_OtherCurrencyEntry struct{ Object; F_currencyCode *String; F_fraction, F_numericCode int32 }

func (t *Currency_OtherCurrencyEntry) Ref() any { if t == nil { return nil }; return t }

func (t *Currency_OtherCurrencyEntry) GetClass__Class() *Class { return Currency_OtherCurrencyEntry_class }

func (t *Currency_OtherCurrencyEntry) ToString__String() *String { return Object_toString(t) }

func (t *Currency_OtherCurrencyEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Currency_OtherCurrencyEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func Currency_OtherCurrencyEntry_InstanceOf(x any) bool { _, ok := x.(*Currency_OtherCurrencyEntry); return ok }

func Currency_OtherCurrencyEntry_Cast(x any) *Currency_OtherCurrencyEntry { if x == nil { return nil }; v, ok := x.(*Currency_OtherCurrencyEntry); if !ok { panic(ClassCast(x, Currency_OtherCurrencyEntry_class)) }; return v }



type Currency_SpecialCaseEntry struct{ Object; F_cutOverTime int64; F_oldCurrency, F_newCurrency *String; F_oldCurrencyFraction, F_newCurrencyFraction, F_oldCurrencyNumericCode, F_newCurrencyNumericCode int32 }

func (t *Currency_SpecialCaseEntry) Ref() any { if t == nil { return nil }; return t }

func (t *Currency_SpecialCaseEntry) GetClass__Class() *Class { return Currency_SpecialCaseEntry_class }

func (t *Currency_SpecialCaseEntry) ToString__String() *String { return Object_toString(t) }

func (t *Currency_SpecialCaseEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Currency_SpecialCaseEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func Currency_SpecialCaseEntry_InstanceOf(x any) bool { _, ok := x.(*Currency_SpecialCaseEntry); return ok }

func Currency_SpecialCaseEntry_Cast(x any) *Currency_SpecialCaseEntry { if x == nil { return nil }; v, ok := x.(*Currency_SpecialCaseEntry); if !ok { panic(ClassCast(x, Currency_SpecialCaseEntry_class)) }; return v }
