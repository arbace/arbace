//line java_security_CryptoPrimitive.ae:1
package jrt






type CryptoPrimitive struct{ Enum }

func (t *CryptoPrimitive) Is_Constable() {}

var CryptoPrimitive_MESSAGE_DIGEST *CryptoPrimitive

var CryptoPrimitive_SECURE_RANDOM *CryptoPrimitive

var CryptoPrimitive_BLOCK_CIPHER *CryptoPrimitive

var CryptoPrimitive_STREAM_CIPHER *CryptoPrimitive

var CryptoPrimitive_MAC *CryptoPrimitive

var CryptoPrimitive_KEY_WRAP *CryptoPrimitive

var CryptoPrimitive_PUBLIC_KEY_ENCRYPTION *CryptoPrimitive

var CryptoPrimitive_SIGNATURE *CryptoPrimitive

var CryptoPrimitive_KEY_ENCAPSULATION *CryptoPrimitive

var CryptoPrimitive_KEY_AGREEMENT *CryptoPrimitive

var CryptoPrimitive__VALUES *RefArray

var CryptoPrimitive_init ClassInit

func CryptoPrimitive_Init() { if !CryptoPrimitive_init.Done() { CryptoPrimitive_init.Run(CryptoPrimitive_clinit) } }

func CryptoPrimitive_clinit() { CryptoPrimitive_MESSAGE_DIGEST = CryptoPrimitive_New_String_I(Lit_1516, 0); CryptoPrimitive_SECURE_RANDOM = CryptoPrimitive_New_String_I(Lit_1517, 1); CryptoPrimitive_BLOCK_CIPHER = CryptoPrimitive_New_String_I(Lit_1518, 2); CryptoPrimitive_STREAM_CIPHER = CryptoPrimitive_New_String_I(Lit_1519, 3); CryptoPrimitive_MAC = CryptoPrimitive_New_String_I(Lit_1520, 4); CryptoPrimitive_KEY_WRAP = CryptoPrimitive_New_String_I(Lit_1521, 5); CryptoPrimitive_PUBLIC_KEY_ENCRYPTION = CryptoPrimitive_New_String_I(Lit_1522, 6); CryptoPrimitive_SIGNATURE = CryptoPrimitive_New_String_I(Lit_1523, 7); CryptoPrimitive_KEY_ENCAPSULATION = CryptoPrimitive_New_String_I(Lit_1524, 8); CryptoPrimitive_KEY_AGREEMENT = CryptoPrimitive_New_String_I(Lit_1525, 9); CryptoPrimitive__VALUES = CryptoPrimitive_X_values__CryptoPrimitive1() }

func CryptoPrimitive_New_String_I(p0 *String, p1 int32) *CryptoPrimitive { CryptoPrimitive_Init(); t := &CryptoPrimitive{}; t.Ctor_String_I(p0, p1); return t }

func (t *CryptoPrimitive) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func CryptoPrimitive_Values__CryptoPrimitive1() *RefArray { CryptoPrimitive_Init(); return CryptoPrimitive__VALUES.Copy() }

func CryptoPrimitive_ValueOf_String__CryptoPrimitive(p0 *String) *CryptoPrimitive { CryptoPrimitive_Init(); return CryptoPrimitive_Cast(Enum_ValueOf_Class_String__Enum(CryptoPrimitive_class, p0)) }

func CryptoPrimitive_X_values__CryptoPrimitive1() *RefArray { CryptoPrimitive_Init(); return RefArrayOf(CryptoPrimitive_class, CryptoPrimitive_MESSAGE_DIGEST, CryptoPrimitive_SECURE_RANDOM, CryptoPrimitive_BLOCK_CIPHER, CryptoPrimitive_STREAM_CIPHER, CryptoPrimitive_MAC, CryptoPrimitive_KEY_WRAP, CryptoPrimitive_PUBLIC_KEY_ENCRYPTION, CryptoPrimitive_SIGNATURE, CryptoPrimitive_KEY_ENCAPSULATION, CryptoPrimitive_KEY_AGREEMENT) }

func (t *CryptoPrimitive) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *CryptoPrimitive) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *CryptoPrimitive) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *CryptoPrimitive) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.security.CryptoPrimitive.describeConstable()Ljava/util/Optional;")) }

func (t *CryptoPrimitive) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *CryptoPrimitive) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *CryptoPrimitive) Ref() any { if t == nil { return nil }; return t }

func (t *CryptoPrimitive) GetClass__Class() *Class { return CryptoPrimitive_class }

func (t *CryptoPrimitive) CloneShallow() any { panic(CloneNotSupported(t)) }

func CryptoPrimitive_InstanceOf(x any) bool { _, ok := x.(*CryptoPrimitive); return ok }

func CryptoPrimitive_Cast(x any) *CryptoPrimitive { if x == nil { return nil }; v, ok := x.(*CryptoPrimitive); if !ok { panic(ClassCast(x, CryptoPrimitive_class)) }; return v }
