//line java_lang_ProcessHandleImpl.ae:1
package jrt


















func ProcessHandleImpl_InitReaper__Executor() Executor { ProcessHandleImpl_Init()
	ThreadLocalRandom_Current__ThreadLocalRandom()
	var threadFactory ThreadFactory = &ThreadFactory_Fn{Fn: func(p0 Runnable) Thread_I { var grimReaper Runnable = p0; var tmp1 Thread_I; var t_ Thread_I = Thread_New_Runnable_String(grimReaper, Lit_1172);

		t_.SetPriority_I__V(10);
		t_.SetDaemon_Z__V(true); tmp1 = t_; return tmp1 },
	}
	return Executors_NewCachedThreadPool_ThreadFactory__ExecutorService(threadFactory)
}




func (t *ProcessHandleImpl_Info) Info0_J__V(pid int64) {
	var times *LongArray = LongArrayOf(-1, -1); var s *RefArray = ProcessHandleImpl_Info_HostInfo_J_J1__String1(pid, times)

	t.F_totalTime = times.A[0]
	t.F_startTime = times.A[1]
	if !(As[*String](s.A[0]) == nil) { t.F_command = As[*String](s.A[0]) }
	if !(As[*String](s.A[1]) == nil) { t.F_commandLine = As[*String](s.A[1]) }
	if !(As[*String](s.A[2]) == nil) { t.F_user = As[*String](s.A[2]) }
	if !(As[*String](s.A[3]) == nil) {
		t.F_arguments = A2g_CastArray[*RefArray](Arrays_CopyOfRange_O1_I_I__O1(s, 4, int32(len(s.A))).Ref(), String_class.ArrayClass())
	} }
func ProcessHandleImpl_Info_HostInfo_J_J1__String1(p0 int64, p1 *LongArray) *RefArray { return ProcessHandleImpl_Info_HostInfo_J_J1__String1_native(p0, p1) }



















func ProcessHandleImpl_ExitCompletion_New_Z(p0 bool) *ProcessHandleImpl_ExitCompletion { ProcessHandleImpl_ExitCompletion_Init(); t := &ProcessHandleImpl_ExitCompletion{}; t.Ctor_Z(p0); return t }
//line :64:1
func (t *ProcessHandleImpl_ExitCompletion) Ctor_Z(isReaping bool) { t.CompletableFuture.Ctor(t)
	t.F_isReaping = isReaping
}
func ProcessHandleImpl_Completion_J_Z__CompletableFuture(pid int64, shouldReap bool) CompletableFuture_I { ProcessHandleImpl_Init()
	var completion *ProcessHandleImpl_ExitCompletion = ProcessHandleImpl_ExitCompletion_Cast(ProcessHandleImpl_completions.Get_O__O(Long_ValueOf_J__Long(pid)))
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = completion == nil; if !tmp2 { var tmp3 bool; tmp3 = shouldReap; if tmp3 { tmp3 = !completion.F_isReaping }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 {
	var newCompletion *ProcessHandleImpl_ExitCompletion = ProcessHandleImpl_ExitCompletion_New_Z(shouldReap)
	if completion == nil {
		completion = ProcessHandleImpl_ExitCompletion_Cast(ProcessHandleImpl_completions.PutIfAbsent_O_O__O(Long_ValueOf_J__Long(pid), newCompletion.Ref())) } else {
			var tmp4 *ProcessHandleImpl_ExitCompletion
			if ProcessHandleImpl_completions.Replace_O_O_O__Z(Long_ValueOf_J__Long(pid), completion.Ref(), newCompletion.Ref()) { tmp4 = nil } else {
				tmp4 = ProcessHandleImpl_ExitCompletion_Cast(ProcessHandleImpl_completions.Get_O__O(Long_ValueOf_J__Long(pid))) }
//line :73:1
			completion = tmp4
		}

	if completion == nil {
		completion = newCompletion
		var tmp5 Executor = ProcessHandleImpl_processReaperExecutor; tmp5.Execute_Runnable__V(ProcessHandleImpl_1_New_J_Z_ProcessHandleImpl_ExitCompletion(pid, shouldReap, newCompletion)) }
//line :69:1
	continue L1 }; break L1 }
//line :68:1
	return Up_ProcessHandleImpl_ExitCompletion_CompletableFuture(completion)
}










func (t *ProcessHandleImpl_1) Run__V() {
	var t_ Thread_I = Thread_CurrentThread__Thread(); var threadName *String = t_.GetName__String()

	t_.SetName_String__V(Concat(Lit_1175, StrOfLong(t.F_val_pid), Lit_1176)); tmp6 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var exitValue int32 = ProcessHandleImpl_WaitForProcessExit0_J_Z__I(t.F_val_pid, t.F_val_shouldReap)


			if exitValue == -2 {
				var sleep int64 = 300; var incr int32 = 30; var startTime int64 = ProcessHandleImpl_IsAlive0_J__J(t.F_val_pid)
				var origStart int64 = startTime


			L1: for { if startTime >= 0 { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

				Thread_Sleep_J__V(Math_Min_J_J__J(sleep, 5000))
				sleep = sleep + int64(incr); return nil }()
//line :94:1
				if tmp1 != nil { if InterruptedException_InstanceOf(tmp1) { var ie *InterruptedException = InterruptedException_Cast(tmp1); _ = ie } else { panic(tmp1)
				}
				}

				startTime = ProcessHandleImpl_IsAlive0_J__J(t.F_val_pid)
				var tmp2 bool; var tmp3 bool; var tmp4 bool
				tmp4 = startTime > 0; if tmp4 { tmp4 = origStart > 0 }; tmp3 = tmp4
//line :99:1
				if tmp3 {

					tmp3 = !(startTime == origStart) }
//line :99:1
				tmp2 = tmp3; if tmp2 {


					break L1 }
//line :93:1
				continue L1 }; break L1
			}








				exitValue = 0 }
			NN(t.F_val_newCompletion).Complete_O__Z(Integer_ValueOf_I__Integer(exitValue))
			var tmp5 ConcurrentMap; ProcessHandleImpl_Init(); tmp5 = ProcessHandleImpl_completions; tmp5.Remove_O_O__Z(Long_ValueOf_J__Long(t.F_val_pid), t.F_val_newCompletion.Ref()) }; return nil }()
	t_.SetName_String__V(threadName)
//line :84:1
	if tmp6 != nil { panic(tmp6)
	}
}






















func (t *ProcessHandleImpl) OnExit__CompletableFuture() CompletableFuture_I {
	if t.Equals_O__Z(ProcessHandleImpl_current.Ref()) {
		panic(Thrown(IllegalStateException_New_String(Lit_1173))) }
	return ProcessHandleImpl_Completion_J_Z__CompletableFuture(t.Pid__J(), false).HandleAsync_BiFunction__CompletableFuture(&BiFunction_Fn{Fn: func(p0, p1 any) any { var exitStatus *Integer = Integer_Cast(p0); var unusedThrowable Throwable_I = Throwable_Cast(p1); _ = exitStatus; _ = unusedThrowable; return t }})
}


func ProcessHandleImpl_WaitForProcessExit0_J_Z__I(p0 int64, p1 bool) int32 { return ProcessHandleImpl_WaitForProcessExit0_J_Z__I_native(p0, p1) }









func ProcessHandleImpl_New_J_J(p0, p1 int64) *ProcessHandleImpl { ProcessHandleImpl_Init(); t := &ProcessHandleImpl{}; t.Ctor_J_J(p0, p1); return t }
//line :126:1
func (t *ProcessHandleImpl) Ctor_J_J(pid, startTime int64) {
	t.F_pid = pid
	t.F_startTime = startTime
}
func ProcessHandleImpl_Get_J__Optional(pid int64) *Optional { ProcessHandleImpl_Init()
	var start int64 = ProcessHandleImpl_IsAlive0_J__J(pid)
	if start >= 0 { return Optional_Of_O__Optional(ProcessHandleImpl_New_J_J(pid, start)) } else { return Optional_Empty__Optional()
	} }
func ProcessHandleImpl_GetInternal_J__ProcessHandleImpl(pid int64) *ProcessHandleImpl { ProcessHandleImpl_Init()
	return ProcessHandleImpl_New_J_J(pid, ProcessHandleImpl_IsAlive0_J__J(pid))
}
func (t *ProcessHandleImpl) Pid__J() int64 { return t.F_pid }

func ProcessHandleImpl_Current__ProcessHandleImpl() *ProcessHandleImpl { ProcessHandleImpl_Init(); return ProcessHandleImpl_current }

func ProcessHandleImpl_GetCurrentPid0__J() int64 { return ProcessHandleImpl_GetCurrentPid0__J_native() }

func (t *ProcessHandleImpl) Parent__Optional() *Optional {
	var ppid int64 = ProcessHandleImpl_Parent0_J_J__J(t.F_pid, t.F_startTime)
	if ppid <= 0 { return Optional_Empty__Optional() } else { return ProcessHandleImpl_Get_J__Optional(ppid)
	} }
func ProcessHandleImpl_Parent0_J_J__J(p0, p1 int64) int64 { return ProcessHandleImpl_Parent0_J_J__J_native(p0, p1) }

func ProcessHandleImpl_GetProcessPids0_J_J1_J1_J1__I(p0 int64, p1, p2, p3 *LongArray) int32 { return ProcessHandleImpl_GetProcessPids0_J_J1_J1_J1__I_native(p0, p1, p2, p3) }


func (t *ProcessHandleImpl) DestroyProcess_Z__Z(force bool) bool {
	if t.Equals_O__Z(ProcessHandleImpl_current.Ref()) {
		panic(Thrown(IllegalStateException_New_String(Lit_1174))) }
	return ProcessHandleImpl_Destroy0_J_J_Z__Z(t.F_pid, t.F_startTime, force)
}
func ProcessHandleImpl_Destroy0_J_J_Z__Z(p0, p1 int64, p2 bool) bool { return ProcessHandleImpl_Destroy0_J_J_Z__Z_native(p0, p1, p2) }

func (t *ProcessHandleImpl) Destroy__Z() bool { return t.DestroyProcess_Z__Z(false) }

func (t *ProcessHandleImpl) DestroyForcibly__Z() bool {
	return t.DestroyProcess_Z__Z(true)
}
func (t *ProcessHandleImpl) SupportsNormalTermination__Z() bool { return true }


func (t *ProcessHandleImpl) IsAlive__Z() bool {
	var start int64 = ProcessHandleImpl_IsAlive0_J__J(t.F_pid); var tmp1 bool
	tmp1 = start >= 0; if tmp1 { var tmp2 bool; var tmp3 bool; tmp3 = start == t.F_startTime; if !tmp3 { tmp3 = start == 0 }; tmp2 = tmp3; if !tmp2 { tmp2 = t.F_startTime == 0 }; tmp1 = tmp2 }; return tmp1
}
func ProcessHandleImpl_IsAlive0_J__J(p0 int64) int64 { return ProcessHandleImpl_IsAlive0_J__J_native(p0) }

func (t *ProcessHandleImpl) Children__Stream() Stream {
	return ProcessHandleImpl_Children_J__Stream(t.F_pid).Filter_Predicate__Stream(&Predicate_Fn{Fn: func(p0 any) bool { var ph ProcessHandle = ProcessHandle_Cast(p0); var tmp1 int64 = t.F_startTime; return tmp1 <= ProcessHandleImpl_Cast(ph).F_startTime }})
}


func ProcessHandleImpl_Children_J__Stream(pid int64) Stream { ProcessHandleImpl_Init()
	var size int32 = 100; var childpids *LongArray; var starttimes *LongArray


L1: for { var tmp1 bool; var tmp2 bool; tmp2 = childpids == nil; if !tmp2 { tmp2 = size > int32(len(childpids.A)) }; tmp1 = tmp2; if tmp1 {
	childpids = NewLongArray(size)
	starttimes = NewLongArray(size)
	size = ProcessHandleImpl_GetProcessPids0_J_J1_J1_J1__I(pid, childpids, nil, starttimes)
//line :182:1
	continue L1 }; break L1
}


	var cpids *LongArray = childpids
	var stimes /*line :186:1*/*LongArray = starttimes

	return IntStream_Range_I_I__IntStream(0, size).MapToObj_IntFunction__Stream(&IntFunction_Fn{Fn: func(p0 int32) any { var i int32 = p0; var tmp3 int64 = cpids.A[i]; return ProcessHandleImpl_New_J_J(tmp3, stimes.A[i]) }})
}


func (t *ProcessHandleImpl) Descendants__Stream() Stream {
	var size int32 = 100; var pids *LongArray; var ppids *LongArray; var starttimes *LongArray



L1: for { var tmp1 bool; var tmp2 bool; tmp2 = pids == nil; if !tmp2 { tmp2 = size > int32(len(pids.A)) }; tmp1 = tmp2; if tmp1 {
	pids = NewLongArray(size)
	ppids = NewLongArray(size)
	starttimes = NewLongArray(size)
	size = ProcessHandleImpl_GetProcessPids0_J_J1_J1_J1__I(0, pids, ppids, starttimes)
//line :197:1
	continue L1 }; break L1
}



	var next int32 = 0; var count int32 = -1; var ppid int64 = t.F_pid
	var ppStart int64 = 0
	var i int32 = 0

L2: for {
	if i < size {
		if pids.A[i] == ppid {
			ppStart = starttimes.A[i] } else {
				i = i + 1; continue L2 } }
//line :206:1
	break L2
}




L3: for {
	var i_2 int32 = next; L4: for {
		if i_2 < size {
			var tmp3 bool; var tmp4 bool; tmp4 = ppids.A[i_2] == ppid; if tmp4 { tmp4 = ppStart <= starttimes.A[i_2] }; tmp3 = tmp4; if tmp3 {

				ProcessHandleImpl_Swap_J1_I_I__V(pids, i_2, next)
				ProcessHandleImpl_Swap_J1_I_I__V(ppids, i_2, next)
				ProcessHandleImpl_Swap_J1_I_I__V(starttimes, i_2, next)
				next = next + 1
				i_2 = i_2 + 1; continue L4 } else {
					i_2 = i_2 + 1; continue L4 } }
//line :213:1
		break L4
	}









	var tmp5 *LongArray = pids; var tmp6 int32; count = count + 1; tmp6 = count; ppid = tmp5.A[tmp6]
	ppStart = starttimes.A[count]
	if count < next { continue L3 }
//line :212:1
	break L3
}













	var cpids *LongArray = pids
	var stimes /*line :227:1*/*LongArray = starttimes

	return IntStream_Range_I_I__IntStream(0, count).MapToObj_IntFunction__Stream(&IntFunction_Fn{Fn: func(p0 int32) any { var i_3 int32 = p0; var tmp7 int64 = cpids.A[i_3]; return ProcessHandleImpl_New_J_J(tmp7, stimes.A[i_3]) }})
}


func ProcessHandleImpl_Swap_J1_I_I__V(array *LongArray, x, y int32) { ProcessHandleImpl_Init()
	var v int64 = array.A[x]; array.A[x] = array.A[y]; array.A[y] = v
}
func (t *ProcessHandleImpl) Info__ProcessHandle_Info() ProcessHandle_Info {
	return ProcessHandleImpl_Info_Info_J_J__ProcessHandle_Info(t.F_pid, t.F_startTime)
}
func (t *ProcessHandleImpl) CompareTo_ProcessHandle__I(other ProcessHandle) int32 {
	var tmp1 int64 = t.F_pid; return Long_Compare_J_J__I(tmp1, ProcessHandleImpl_Cast(other).F_pid)
}
func (t *ProcessHandleImpl) ToString__String() *String { return Long_ToString_J__String(t.F_pid) }

func (t *ProcessHandleImpl) HashCode__I() int32 { return Long_HashCode_J__I(t.F_pid) }

func (t *ProcessHandleImpl) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if ProcessHandleImpl_InstanceOf(tmp1) { var other *ProcessHandleImpl = ProcessHandleImpl_Cast(tmp1); var tmp2 int64 = t.F_pid
			if tmp2 == other.F_pid {
				var tmp3 bool; var tmp4 bool; var tmp5 int64 = t.F_startTime; tmp4 = tmp5 == other.F_startTime; if !tmp4 { tmp4 = t.F_startTime == 0 }; tmp3 = tmp4; if !tmp3 {
					tmp3 = other.F_startTime == 0 }
//line :251:1
				return tmp3 } else {
//line :250:1
					return false
				} } else {
//line :249:1
					return false
				}
	}
}
























func ProcessHandleImpl_Info_New() *ProcessHandleImpl_Info { t := &ProcessHandleImpl_Info{}; t.Ctor(); return t }
//line :277:1
func (t *ProcessHandleImpl_Info) Ctor() {
	t.F_command = nil
	t.F_commandLine = nil
	t.F_arguments = nil
	t.F_startTime = -1
	t.F_totalTime = -1
	t.F_user = nil
}
func ProcessHandleImpl_Info_Info_J_J__ProcessHandle_Info(pid, startTime int64) ProcessHandle_Info {
	var info *ProcessHandleImpl_Info = ProcessHandleImpl_Info_New()
	NN(info).Info0_J__V(pid)
	if startTime == info.F_startTime { } else {
		info.F_command = nil
		info.F_arguments = nil
		info.F_startTime = -1
		info.F_totalTime = -1
		info.F_user = nil }
//line :286:1
	return Up_ProcessHandleImpl_Info_ProcessHandle_Info(info)
}








func (t *ProcessHandleImpl_Info) Command__Optional() *Optional {
	return Optional_OfNullable_O__Optional(t.F_command.Ref())
}
func (t *ProcessHandleImpl_Info) CommandLine__Optional() *Optional {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_command == nil); if tmp2 { tmp2 = !(t.F_arguments == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp3 *String = t.F_command; return Optional_Of_O__Optional(Concat(tmp3, Lit_115, String_Join_CharSequence_CharSequence1__String(Lit_115, t.F_arguments))) } else {
			return Optional_OfNullable_O__Optional(t.F_commandLine.Ref())
		} }
func (t *ProcessHandleImpl_Info) Arguments__Optional() *Optional {
	return Optional_OfNullable_O__Optional(t.F_arguments.Ref())
}
func (t *ProcessHandleImpl_Info) StartInstant__Optional() *Optional {
	if t.F_startTime > 0 { return Optional_Of_O__Optional(Instant_OfEpochMilli_J__Instant(t.F_startTime).Ref()) } else { return Optional_Empty__Optional()
	} }
func (t *ProcessHandleImpl_Info) TotalCpuDuration__Optional() *Optional {
	if !(t.F_totalTime == -1) { return Optional_Of_O__Optional(Duration_OfNanos_J__Duration(t.F_totalTime).Ref()) } else { return Optional_Empty__Optional()
	} }
func (t *ProcessHandleImpl_Info) User__Optional() *Optional {
	return Optional_OfNullable_O__Optional(t.F_user.Ref())
}
func (t *ProcessHandleImpl_Info) ToString__String() *String {
	var sb *StringBuilder = StringBuilder_New_I(60)
	NN(sb).Append_C__StringBuilder(91)
	if !(t.F_user == nil) { NN(sb).Append_String__StringBuilder(Lit_1177); NN(sb).Append_O__StringBuilder(t.User__Optional().Ref()) }
	if !(t.F_command == nil) {
		if NN(sb).Length__I() > 1 { NN(sb).Append_String__StringBuilder(Lit_1178) }
		NN(sb).Append_String__StringBuilder(Lit_1179)
		NN(sb).Append_String__StringBuilder(t.F_command) }
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_arguments == nil); if tmp2 { tmp2 = int32(len(t.F_arguments.A)) > 0 }; tmp1 = tmp2; if tmp1 {
		if NN(sb).Length__I() > 1 { NN(sb).Append_String__StringBuilder(Lit_1178) }
		NN(sb).Append_String__StringBuilder(Lit_1180)
		NN(sb).Append_String__StringBuilder(Arrays_ToString_O1__String(t.F_arguments)) }
	if !(t.F_commandLine == nil) {
		if NN(sb).Length__I() > 1 { NN(sb).Append_String__StringBuilder(Lit_1178) }
		NN(sb).Append_String__StringBuilder(Lit_1181)
		NN(sb).Append_String__StringBuilder(t.F_commandLine) }
	if t.F_startTime > 0 {
		if NN(sb).Length__I() > 1 { NN(sb).Append_String__StringBuilder(Lit_1178) }
		NN(sb).Append_String__StringBuilder(Lit_1182)
		NN(sb).Append_O__StringBuilder(t.StartInstant__Optional().Ref()) }
	if t.F_totalTime == -1 { } else {
		if NN(sb).Length__I() > 1 { NN(sb).Append_String__StringBuilder(Lit_1178) }
		NN(sb).Append_String__StringBuilder(Lit_1183)
		NN(sb).Append_String__StringBuilder(NN(t.TotalCpuDuration__Optional()).ToString__String()) }
	NN(sb).Append_C__StringBuilder(93)
	return NN(sb).ToString__String()
}


type ProcessHandleImpl struct{ Object; F_pid, F_startTime int64 }

func (t *ProcessHandleImpl) Is_ProcessHandle() {}

func (t *ProcessHandleImpl) Is_Comparable() {}

const ProcessHandleImpl_REAPER_DEFAULT_STACKSIZE int64 = 131072

const ProcessHandleImpl_NOT_A_CHILD int32 = -2

var ProcessHandleImpl_current *ProcessHandleImpl

var ProcessHandleImpl_completions ConcurrentMap

var ProcessHandleImpl_processReaperExecutor Executor

const ProcessHandleImpl_STARTTIME_ANY int64 = 0

const ProcessHandleImpl_STARTTIME_PROCESS_UNKNOWN int64 = -1

var ProcessHandleImpl_init ClassInit

func ProcessHandleImpl_Init() { if !ProcessHandleImpl_init.Done() { ProcessHandleImpl_init.Run(ProcessHandleImpl_clinit) } }

func ProcessHandleImpl_clinit() { ProcessHandleImpl_completions = ConcurrentHashMap_New()
//line :17:1
	var pid int64 = ProcessHandleImpl_GetCurrentPid0__J()
	ProcessHandleImpl_current = ProcessHandleImpl_New_J_J(pid, ProcessHandleImpl_IsAlive0_J__J(pid))
//line :17:1
	ProcessHandleImpl_processReaperExecutor = ProcessHandleImpl_InitReaper__Executor()
}
































































































































































































































































































































































func (t *ProcessHandleImpl) CompareTo_O__I(p0 any) int32 { return t.CompareTo_ProcessHandle__I(ProcessHandle_Cast(p0)) }

func (t *ProcessHandleImpl) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessHandleImpl) GetClass__Class() *Class { return ProcessHandleImpl_class }

func (t *ProcessHandleImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessHandleImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessHandleImpl_InstanceOf(x any) bool { _, ok := x.(*ProcessHandleImpl); return ok }

func ProcessHandleImpl_Cast(x any) *ProcessHandleImpl { if x == nil { return nil }; v, ok := x.(*ProcessHandleImpl); if !ok { panic(ClassCast(x, ProcessHandleImpl_class)) }; return v }



type ProcessHandleImpl_1 struct{ Object; F_val_pid int64; F_val_shouldReap bool; F_val_newCompletion *ProcessHandleImpl_ExitCompletion }

func (t *ProcessHandleImpl_1) Is_Runnable() {}

func ProcessHandleImpl_1_New_J_Z_ProcessHandleImpl_ExitCompletion(p0 int64, p1 bool, p2 *ProcessHandleImpl_ExitCompletion) *ProcessHandleImpl_1 { t := &ProcessHandleImpl_1{}; t.Ctor_J_Z_ProcessHandleImpl_ExitCompletion(p0, p1, p2); return t }

func (t *ProcessHandleImpl_1) Ctor_J_Z_ProcessHandleImpl_ExitCompletion(val_pid int64, val_shouldReap bool, val_newCompletion *ProcessHandleImpl_ExitCompletion) { t.F_val_pid = val_pid; t.F_val_shouldReap = val_shouldReap; t.F_val_newCompletion = val_newCompletion }

func (t *ProcessHandleImpl_1) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessHandleImpl_1) GetClass__Class() *Class { return ProcessHandleImpl_1_class }

func (t *ProcessHandleImpl_1) ToString__String() *String { return Object_toString(t) }

func (t *ProcessHandleImpl_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessHandleImpl_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessHandleImpl_1_InstanceOf(x any) bool { _, ok := x.(*ProcessHandleImpl_1); return ok }

func ProcessHandleImpl_1_Cast(x any) *ProcessHandleImpl_1 { if x == nil { return nil }; v, ok := x.(*ProcessHandleImpl_1); if !ok { panic(ClassCast(x, ProcessHandleImpl_1_class)) }; return v }



type ProcessHandleImpl_ExitCompletion struct{ CompletableFuture; F_isReaping bool }

var ProcessHandleImpl_ExitCompletion_init ClassInit

func ProcessHandleImpl_ExitCompletion_Init() { if !ProcessHandleImpl_ExitCompletion_init.Done() { ProcessHandleImpl_ExitCompletion_init.Run(ProcessHandleImpl_ExitCompletion_clinit) } }

func ProcessHandleImpl_ExitCompletion_clinit() { CompletableFuture_Init() }

func (t *ProcessHandleImpl_ExitCompletion) Unipush_CompletableFuture_Completion__V(p0 CompletableFuture_Completion_I) { t.Impl_Unipush_CompletableFuture_Completion__V(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterBothAsync_CompletionStage_Runnable__CompletableFuture(p0 CompletionStage, p1 Runnable) CompletableFuture_I { return t.Impl_RunAfterBothAsync_CompletionStage_Runnable__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenApplyAsync_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_ThenApplyAsync_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCombine_CompletionStage_BiFunction__CompletionStage(p0 CompletionStage, p1 BiFunction) CompletionStage { return t.Impl_ThenCombine_CompletionStage_BiFunction__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenRun_Runnable__CompletionStage(p0 Runnable) CompletionStage { return t.Impl_ThenRun_Runnable__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCombine_CompletionStage_BiFunction__CompletableFuture(p0 CompletionStage, p1 BiFunction) CompletableFuture_I { return t.Impl_ThenCombine_CompletionStage_BiFunction__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyComposeAsync_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_ExceptionallyComposeAsync_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptBothAsync_CompletionStage_BiConsumer__CompletableFuture(p0 CompletionStage, p1 BiConsumer) CompletableFuture_I { return t.Impl_ThenAcceptBothAsync_CompletionStage_BiConsumer__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) WhenCompleteAsync_BiConsumer__CompletionStage(p0 BiConsumer) CompletionStage { return t.Impl_WhenCompleteAsync_BiConsumer__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) PostFire_CompletableFuture_CompletableFuture_I__CompletableFuture(p0, p1 CompletableFuture_I, p2 int32) CompletableFuture_I { return t.Impl_PostFire_CompletableFuture_CompletableFuture_I__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) Copy__CompletableFuture() CompletableFuture_I { return t.Impl_Copy__CompletableFuture(t) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyCompose_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_ExceptionallyCompose_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCombineAsync_CompletionStage_BiFunction_Executor__CompletableFuture(p0 CompletionStage, p1 BiFunction, p2 Executor) CompletableFuture_I { return t.Impl_ThenCombineAsync_CompletionStage_BiFunction_Executor__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) PostComplete__V() { t.Impl_PostComplete__V(t) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterEitherAsync_CompletionStage_Runnable_Executor__CompletableFuture(p0 CompletionStage, p1 Runnable, p2 Executor) CompletableFuture_I { return t.Impl_RunAfterEitherAsync_CompletionStage_Runnable_Executor__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptAsync_Consumer__CompletionStage(p0 Consumer) CompletionStage { return t.Impl_ThenAcceptAsync_Consumer__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) HandleAsync_BiFunction_Executor__CompletableFuture(p0 BiFunction, p1 Executor) CompletableFuture_I { return t.Impl_HandleAsync_BiFunction_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) PushStack_CompletableFuture_Completion__V(p0 CompletableFuture_Completion_I) { t.Impl_PushStack_CompletableFuture_Completion__V(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) AcceptEitherAsync_CompletionStage_Consumer_Executor__CompletionStage(p0 CompletionStage, p1 Consumer, p2 Executor) CompletionStage { return t.Impl_AcceptEitherAsync_CompletionStage_Consumer_Executor__CompletionStage(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterBothAsync_CompletionStage_Runnable_Executor__CompletionStage(p0 CompletionStage, p1 Runnable, p2 Executor) CompletionStage { return t.Impl_RunAfterBothAsync_CompletionStage_Runnable_Executor__CompletionStage(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) ThenComposeAsync_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_ThenComposeAsync_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteAsync_Supplier__CompletableFuture(p0 Supplier) CompletableFuture_I { return t.Impl_CompleteAsync_Supplier__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenComposeAsync_Function_Executor__CompletionStage(p0 Function, p1 Executor) CompletionStage { return t.Impl_ThenComposeAsync_Function_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) WhenComplete_BiConsumer__CompletableFuture(p0 BiConsumer) CompletableFuture_I { return t.Impl_WhenComplete_BiConsumer__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) Handle_BiFunction__CompletableFuture(p0 BiFunction) CompletableFuture_I { return t.Impl_Handle_BiFunction__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) BiRun_O_O_Runnable_CompletableFuture_BiRun__Z(p0, p1 any, p2 Runnable, p3 *CompletableFuture_BiRun) bool { return t.Impl_BiRun_O_O_Runnable_CompletableFuture_BiRun__Z(t, p0, p1, p2, p3) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterEitherAsync_CompletionStage_Runnable__CompletableFuture(p0 CompletionStage, p1 Runnable) CompletableFuture_I { return t.Impl_RunAfterEitherAsync_CompletionStage_Runnable__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenRunAsync_Runnable__CompletableFuture(p0 Runnable) CompletableFuture_I { return t.Impl_ThenRunAsync_Runnable__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) GetNow_O__O(p0 any) any { return t.Impl_GetNow_O__O(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) OrTimeout_J_TimeUnit__CompletableFuture(p0 int64, p1 *TimeUnit) CompletableFuture_I { return t.Impl_OrTimeout_J_TimeUnit__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ObtrudeValue_O__V(p0 any) { t.Impl_ObtrudeValue_O__V(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) InternalComplete_O__Z(p0 any) bool { return t.Impl_InternalComplete_O__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) UniWhenComplete_O_BiConsumer_CompletableFuture_UniWhenComplete__Z(p0 any, p1 BiConsumer, p2 *CompletableFuture_UniWhenComplete) bool { return t.Impl_UniWhenComplete_O_BiConsumer_CompletableFuture_UniWhenComplete__Z(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCombineAsync_CompletionStage_BiFunction__CompletableFuture(p0 CompletionStage, p1 BiFunction) CompletableFuture_I { return t.Impl_ThenCombineAsync_CompletionStage_BiFunction__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptAsync_Consumer_Executor__CompletableFuture(p0 Consumer, p1 Executor) CompletableFuture_I { return t.Impl_ThenAcceptAsync_Consumer_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteThrowable_Throwable__Z(p0 Throwable_I) bool { return t.Impl_CompleteThrowable_Throwable__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) Get__O() any { return t.Impl_Get__O(t) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterBothAsync_CompletionStage_Runnable_Executor__CompletableFuture(p0 CompletionStage, p1 Runnable, p2 Executor) CompletableFuture_I { return t.Impl_RunAfterBothAsync_CompletionStage_Runnable_Executor__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) Exceptionally_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_Exceptionally_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) AcceptEitherAsync_CompletionStage_Consumer__CompletableFuture(p0 CompletionStage, p1 Consumer) CompletableFuture_I { return t.Impl_AcceptEitherAsync_CompletionStage_Consumer__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyAsync_Function_Executor__CompletionStage(p0 Function, p1 Executor) CompletionStage { return t.Impl_ExceptionallyAsync_Function_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) AcceptEitherAsync_CompletionStage_Consumer__CompletionStage(p0 CompletionStage, p1 Consumer) CompletionStage { return t.Impl_AcceptEitherAsync_CompletionStage_Consumer__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptBothAsync_CompletionStage_BiConsumer_Executor__CompletionStage(p0 CompletionStage, p1 BiConsumer, p2 Executor) CompletionStage { return t.Impl_ThenAcceptBothAsync_CompletionStage_BiConsumer_Executor__CompletionStage(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyComposeAsync_Function_Executor__CompletableFuture(p0 Function, p1 Executor) CompletableFuture_I { return t.Impl_ExceptionallyComposeAsync_Function_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCompose_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_ThenCompose_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptBoth_CompletionStage_BiConsumer__CompletableFuture(p0 CompletionStage, p1 BiConsumer) CompletableFuture_I { return t.Impl_ThenAcceptBoth_CompletionStage_BiConsumer__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterBoth_CompletionStage_Runnable__CompletableFuture(p0 CompletionStage, p1 Runnable) CompletableFuture_I { return t.Impl_RunAfterBoth_CompletionStage_Runnable__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAccept_Consumer__CompletableFuture(p0 Consumer) CompletableFuture_I { return t.Impl_ThenAccept_Consumer__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) HandleAsync_BiFunction__CompletionStage(p0 BiFunction) CompletionStage { return t.Impl_HandleAsync_BiFunction__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteExceptionally_Throwable__Z(p0 Throwable_I) bool { return t.Impl_CompleteExceptionally_Throwable__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterBothAsync_CompletionStage_Runnable__CompletionStage(p0 CompletionStage, p1 Runnable) CompletionStage { return t.Impl_RunAfterBothAsync_CompletionStage_Runnable__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) UniExceptionally_O_Function_CompletableFuture_UniExceptionally__Z(p0 any, p1 Function, p2 *CompletableFuture_UniExceptionally) bool { return t.Impl_UniExceptionally_O_Function_CompletableFuture_UniExceptionally__Z(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ProcessHandleImpl_ExitCompletion) ApplyToEitherAsync_CompletionStage_Function__CompletableFuture(p0 CompletionStage, p1 Function) CompletableFuture_I { return t.Impl_ApplyToEitherAsync_CompletionStage_Function__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCombineAsync_CompletionStage_BiFunction__CompletionStage(p0 CompletionStage, p1 BiFunction) CompletionStage { return t.Impl_ThenCombineAsync_CompletionStage_BiFunction__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ApplyToEither_CompletionStage_Function__CompletableFuture(p0 CompletionStage, p1 Function) CompletableFuture_I { return t.Impl_ApplyToEither_CompletionStage_Function__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) GetNumberOfDependents__I() int32 { return t.Impl_GetNumberOfDependents__I(t) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterEitherAsync_CompletionStage_Runnable_Executor__CompletionStage(p0 CompletionStage, p1 Runnable, p2 Executor) CompletionStage { return t.Impl_RunAfterEitherAsync_CompletionStage_Runnable_Executor__CompletionStage(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) DefaultExecutor__Executor() Executor { return t.Impl_DefaultExecutor__Executor(t) }

func (t *ProcessHandleImpl_ExitCompletion) WhenCompleteAsync_BiConsumer_Executor__CompletionStage(p0 BiConsumer, p1 Executor) CompletionStage { return t.Impl_WhenCompleteAsync_BiConsumer_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterBoth_CompletionStage_Runnable__CompletionStage(p0 CompletionStage, p1 Runnable) CompletionStage { return t.Impl_RunAfterBoth_CompletionStage_Runnable__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenApply_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_ThenApply_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ToCompletableFuture__CompletableFuture() CompletableFuture_I { return t.Impl_ToCompletableFuture__CompletableFuture(t) }

func (t *ProcessHandleImpl_ExitCompletion) Bipush_CompletableFuture_CompletableFuture_BiCompletion__V(p0 CompletableFuture_I, p1 CompletableFuture_BiCompletion_I) { t.Impl_Bipush_CompletableFuture_CompletableFuture_BiCompletion__V(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterEitherAsync_CompletionStage_Runnable__CompletionStage(p0 CompletionStage, p1 Runnable) CompletionStage { return t.Impl_RunAfterEitherAsync_CompletionStage_Runnable__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) TryPushStack_CompletableFuture_Completion__Z(p0 CompletableFuture_Completion_I) bool { return t.Impl_TryPushStack_CompletableFuture_Completion__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) WhenCompleteAsync_BiConsumer_Executor__CompletableFuture(p0 BiConsumer, p1 Executor) CompletableFuture_I { return t.Impl_WhenCompleteAsync_BiConsumer_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptBothAsync_CompletionStage_BiConsumer_Executor__CompletableFuture(p0 CompletionStage, p1 BiConsumer, p2 Executor) CompletableFuture_I { return t.Impl_ThenAcceptBothAsync_CompletionStage_BiConsumer_Executor__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) Exceptionally_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_Exceptionally_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) MinimalCompletionStage__CompletionStage() CompletionStage { return t.Impl_MinimalCompletionStage__CompletionStage(t) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyComposeAsync_Function_Executor__CompletionStage(p0 Function, p1 Executor) CompletionStage { return t.Impl_ExceptionallyComposeAsync_Function_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) PostFire_CompletableFuture_I__CompletableFuture(p0 CompletableFuture_I, p1 int32) CompletableFuture_I { return t.Impl_PostFire_CompletableFuture_I__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) Join__O() any { return t.Impl_Join__O(t) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyComposeAsync_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_ExceptionallyComposeAsync_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenApplyAsync_Function_Executor__CompletionStage(p0 Function, p1 Executor) CompletionStage { return t.Impl_ThenApplyAsync_Function_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteAsync_Supplier_Executor__CompletableFuture(p0 Supplier, p1 Executor) CompletableFuture_I { return t.Impl_CompleteAsync_Supplier_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenRunAsync_Runnable_Executor__CompletionStage(p0 Runnable, p1 Executor) CompletionStage { return t.Impl_ThenRunAsync_Runnable_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) IsCompletedExceptionally__Z() bool { return t.Impl_IsCompletedExceptionally__Z(t) }

func (t *ProcessHandleImpl_ExitCompletion) Orpush_CompletableFuture_CompletableFuture_BiCompletion__V(p0 CompletableFuture_I, p1 CompletableFuture_BiCompletion_I) { t.Impl_Orpush_CompletableFuture_CompletableFuture_BiCompletion__V(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyAsync_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_ExceptionallyAsync_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyCompose_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_ExceptionallyCompose_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) Complete_O__Z(p0 any) bool { return t.Impl_Complete_O__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptBoth_CompletionStage_BiConsumer__CompletionStage(p0 CompletionStage, p1 BiConsumer) CompletionStage { return t.Impl_ThenAcceptBoth_CompletionStage_BiConsumer__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) Handle_BiFunction__CompletionStage(p0 BiFunction) CompletionStage { return t.Impl_Handle_BiFunction__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteThrowable_Throwable_O__Z(p0 Throwable_I, p1 any) bool { return t.Impl_CompleteThrowable_Throwable_O__Z(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) AcceptEither_CompletionStage_Consumer__CompletionStage(p0 CompletionStage, p1 Consumer) CompletionStage { return t.Impl_AcceptEither_CompletionStage_Consumer__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) EncodeValue_O__O(p0 any) any { return t.Impl_EncodeValue_O__O(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCombineAsync_CompletionStage_BiFunction_Executor__CompletionStage(p0 CompletionStage, p1 BiFunction, p2 Executor) CompletionStage { return t.Impl_ThenCombineAsync_CompletionStage_BiFunction_Executor__CompletionStage(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteOnTimeout_O_J_TimeUnit__CompletableFuture(p0 any, p1 int64, p2 *TimeUnit) CompletableFuture_I { return t.Impl_CompleteOnTimeout_O_J_TimeUnit__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) ApplyToEitherAsync_CompletionStage_Function_Executor__CompletableFuture(p0 CompletionStage, p1 Function, p2 Executor) CompletableFuture_I { return t.Impl_ApplyToEitherAsync_CompletionStage_Function_Executor__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) ThenComposeAsync_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_ThenComposeAsync_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptAsync_Consumer__CompletableFuture(p0 Consumer) CompletableFuture_I { return t.Impl_ThenAcceptAsync_Consumer__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptAsync_Consumer_Executor__CompletionStage(p0 Consumer, p1 Executor) CompletionStage { return t.Impl_ThenAcceptAsync_Consumer_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) BiApply_O_O_BiFunction_CompletableFuture_BiApply__Z(p0, p1 any, p2 BiFunction, p3 *CompletableFuture_BiApply) bool { return t.Impl_BiApply_O_O_BiFunction_CompletableFuture_BiApply__Z(t, p0, p1, p2, p3) }

func (t *ProcessHandleImpl_ExitCompletion) ThenRun_Runnable__CompletableFuture(p0 Runnable) CompletableFuture_I { return t.Impl_ThenRun_Runnable__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenRunAsync_Runnable__CompletionStage(p0 Runnable) CompletionStage { return t.Impl_ThenRunAsync_Runnable__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyAsync_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_ExceptionallyAsync_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) AcceptEitherAsync_CompletionStage_Consumer_Executor__CompletableFuture(p0 CompletionStage, p1 Consumer, p2 Executor) CompletableFuture_I { return t.Impl_AcceptEitherAsync_CompletionStage_Consumer_Executor__CompletableFuture(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) AcceptEither_CompletionStage_Consumer__CompletableFuture(p0 CompletionStage, p1 Consumer) CompletableFuture_I { return t.Impl_AcceptEither_CompletionStage_Consumer__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ApplyToEither_CompletionStage_Function__CompletionStage(p0 CompletionStage, p1 Function) CompletionStage { return t.Impl_ApplyToEither_CompletionStage_Function__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAcceptBothAsync_CompletionStage_BiConsumer__CompletionStage(p0 CompletionStage, p1 BiConsumer) CompletionStage { return t.Impl_ThenAcceptBothAsync_CompletionStage_BiConsumer__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ApplyToEitherAsync_CompletionStage_Function_Executor__CompletionStage(p0 CompletionStage, p1 Function, p2 Executor) CompletionStage { return t.Impl_ApplyToEitherAsync_CompletionStage_Function_Executor__CompletionStage(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) BiAccept_O_O_BiConsumer_CompletableFuture_BiAccept__Z(p0, p1 any, p2 BiConsumer, p3 *CompletableFuture_BiAccept) bool { return t.Impl_BiAccept_O_O_BiConsumer_CompletableFuture_BiAccept__Z(t, p0, p1, p2, p3) }

func (t *ProcessHandleImpl_ExitCompletion) ExceptionallyAsync_Function_Executor__CompletableFuture(p0 Function, p1 Executor) CompletableFuture_I { return t.Impl_ExceptionallyAsync_Function_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ProcessHandleImpl_ExitCompletion) HandleAsync_BiFunction__CompletableFuture(p0 BiFunction) CompletableFuture_I { return t.Impl_HandleAsync_BiFunction__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteValue_O__Z(p0 any) bool { return t.Impl_CompleteValue_O__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) HandleAsync_BiFunction_Executor__CompletionStage(p0 BiFunction, p1 Executor) CompletionStage { return t.Impl_HandleAsync_BiFunction_Executor__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) WhenCompleteAsync_BiConsumer__CompletableFuture(p0 BiConsumer) CompletableFuture_I { return t.Impl_WhenCompleteAsync_BiConsumer__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenComposeAsync_Function_Executor__CompletableFuture(p0 Function, p1 Executor) CompletableFuture_I { return t.Impl_ThenComposeAsync_Function_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) CleanStack__V() { t.Impl_CleanStack__V(t) }

func (t *ProcessHandleImpl_ExitCompletion) ThenApplyAsync_Function_Executor__CompletableFuture(p0 Function, p1 Executor) CompletableFuture_I { return t.Impl_ThenApplyAsync_Function_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenAccept_Consumer__CompletionStage(p0 Consumer) CompletionStage { return t.Impl_ThenAccept_Consumer__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterEither_CompletionStage_Runnable__CompletableFuture(p0 CompletionStage, p1 Runnable) CompletableFuture_I { return t.Impl_RunAfterEither_CompletionStage_Runnable__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ObtrudeException_Throwable__V(p0 Throwable_I) { t.Impl_ObtrudeException_Throwable__V(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) RunAfterEither_CompletionStage_Runnable__CompletionStage(p0 CompletionStage, p1 Runnable) CompletionStage { return t.Impl_RunAfterEither_CompletionStage_Runnable__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenRunAsync_Runnable_Executor__CompletableFuture(p0 Runnable, p1 Executor) CompletableFuture_I { return t.Impl_ThenRunAsync_Runnable_Executor__CompletableFuture(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) NewIncompleteFuture__CompletableFuture() CompletableFuture_I { return t.Impl_NewIncompleteFuture__CompletableFuture(t) }

func (t *ProcessHandleImpl_ExitCompletion) UniHandle_O_BiFunction_CompletableFuture_UniHandle__Z(p0 any, p1 BiFunction, p2 *CompletableFuture_UniHandle) bool { return t.Impl_UniHandle_O_BiFunction_CompletableFuture_UniHandle__Z(t, p0, p1, p2) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteNull__Z() bool { return t.Impl_CompleteNull__Z(t) }

func (t *ProcessHandleImpl_ExitCompletion) ThenCompose_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_ThenCompose_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) EncodeOutcome_O_Throwable__O(p0 any, p1 Throwable_I) any { return t.Impl_EncodeOutcome_O_Throwable__O(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) ThenApplyAsync_Function__CompletableFuture(p0 Function) CompletableFuture_I { return t.Impl_ThenApplyAsync_Function__CompletableFuture(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) WhenComplete_BiConsumer__CompletionStage(p0 BiConsumer) CompletionStage { return t.Impl_WhenComplete_BiConsumer__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ApplyToEitherAsync_CompletionStage_Function__CompletionStage(p0 CompletionStage, p1 Function) CompletionStage { return t.Impl_ApplyToEitherAsync_CompletionStage_Function__CompletionStage(t, p0, p1) }

func (t *ProcessHandleImpl_ExitCompletion) CompleteRelay_O__Z(p0 any) bool { return t.Impl_CompleteRelay_O__Z(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ThenApply_Function__CompletionStage(p0 Function) CompletionStage { return t.Impl_ThenApply_Function__CompletionStage(t, p0) }

func (t *ProcessHandleImpl_ExitCompletion) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessHandleImpl_ExitCompletion) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessHandleImpl_ExitCompletion) GetClass__Class() *Class { return ProcessHandleImpl_ExitCompletion_class }

func (t *ProcessHandleImpl_ExitCompletion) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessHandleImpl_ExitCompletion) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessHandleImpl_ExitCompletion_InstanceOf(x any) bool { _, ok := x.(*ProcessHandleImpl_ExitCompletion); return ok }

func ProcessHandleImpl_ExitCompletion_Cast(x any) *ProcessHandleImpl_ExitCompletion { if x == nil { return nil }; v, ok := x.(*ProcessHandleImpl_ExitCompletion); if !ok { panic(ClassCast(x, ProcessHandleImpl_ExitCompletion_class)) }; return v }



type ProcessHandleImpl_Info struct{ Object; F_command, F_commandLine *String; F_arguments *RefArray; F_startTime, F_totalTime int64; F_user *String }

func (t *ProcessHandleImpl_Info) Is_ProcessHandle_Info() {}

func (t *ProcessHandleImpl_Info) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessHandleImpl_Info) GetClass__Class() *Class { return ProcessHandleImpl_Info_class }

func (t *ProcessHandleImpl_Info) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessHandleImpl_Info) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessHandleImpl_Info_InstanceOf(x any) bool { _, ok := x.(*ProcessHandleImpl_Info); return ok }

func ProcessHandleImpl_Info_Cast(x any) *ProcessHandleImpl_Info { if x == nil { return nil }; v, ok := x.(*ProcessHandleImpl_Info); if !ok { panic(ClassCast(x, ProcessHandleImpl_Info_class)) }; return v }
