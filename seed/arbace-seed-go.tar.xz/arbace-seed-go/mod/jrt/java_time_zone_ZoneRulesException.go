//line java_time_zone_ZoneRulesException.ae:1
package jrt










func ZoneRulesException_New_String(p0 *String) *ZoneRulesException { t := &ZoneRulesException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *ZoneRulesException) Ctor_String(message *String) { t.DateTimeException.Ctor_String(t, message) }

func ZoneRulesException_New_String_Throwable(p0 *String, p1 Throwable_I) *ZoneRulesException { t := &ZoneRulesException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *ZoneRulesException) Ctor_String_Throwable(message *String, cause Throwable_I) { t.DateTimeException.Ctor_String_Throwable(t, message, cause) }







type ZoneRulesException struct{ DateTimeException }

const ZoneRulesException_serialVersionUID int64 = -1632418723876261839

func (t *ZoneRulesException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ZoneRulesException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ZoneRulesException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ZoneRulesException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ZoneRulesException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ZoneRulesException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ZoneRulesException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ZoneRulesException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ZoneRulesException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ZoneRulesException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ZoneRulesException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ZoneRulesException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ZoneRulesException) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneRulesException) GetClass__Class() *Class { return ZoneRulesException_class }

func (t *ZoneRulesException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneRulesException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneRulesException_InstanceOf(x any) bool { _, ok := x.(*ZoneRulesException); return ok }

func ZoneRulesException_Cast(x any) *ZoneRulesException { if x == nil { return nil }; v, ok := x.(*ZoneRulesException); if !ok { panic(ClassCast(x, ZoneRulesException_class)) }; return v }
