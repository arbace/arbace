//line java_text_StringCharacterIterator.ae:1
package jrt
















func StringCharacterIterator_New_String(p0 *String) *StringCharacterIterator { t := &StringCharacterIterator{}; t.Ctor_String(p0); return t }
//line :18:1
func (t *StringCharacterIterator) Ctor_String(text *String) { t.Ctor_String_I(text, 0) }

func StringCharacterIterator_New_String_I(p0 *String, p1 int32) *StringCharacterIterator { t := &StringCharacterIterator{}; t.Ctor_String_I(p0, p1); return t }
//line :20:1
func (t *StringCharacterIterator) Ctor_String_I(text *String, pos int32) { t.Ctor_String_I_I_I(text, 0, NN(text).Length__I(), pos) }


func StringCharacterIterator_New_String_I_I_I(p0 *String, p1, p2, p3 int32) *StringCharacterIterator { t := &StringCharacterIterator{}; t.Ctor_String_I_I_I(p0, p1, p2, p3); return t }
//line :23:1
func (t *StringCharacterIterator) Ctor_String_I_I_I(text *String, begin, end, pos int32) {
	t.F_text = String_Cast(Objects_RequireNonNull_O_String__O(text.Ref(), Lit_1978))
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = begin < 0; if !tmp3 { tmp3 = begin > end }; tmp2 = tmp3; if !tmp2 { tmp2 = end > NN(text).Length__I() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1698))) }
	var tmp4 bool; var tmp5 bool; tmp5 = pos < begin; if !tmp5 { tmp5 = pos > end }; tmp4 = tmp5; if tmp4 { panic(Thrown(IllegalArgumentException_New_String(Lit_1979))) }
	t.F_begin = begin
	t.F_end = end
	t.F_pos = pos
}
func (t *StringCharacterIterator) SetText_String__V(text *String) {
	t.F_text = String_Cast(Objects_RequireNonNull_O_String__O(text.Ref(), Lit_1978))
	t.F_begin = 0
	t.F_end = NN(text).Length__I()
	t.F_pos = 0
}
func (t *StringCharacterIterator) First__C() uint16 { t.F_pos = t.F_begin; return t.Current__C() }

func (t *StringCharacterIterator) Last__C() uint16 {
	if !(t.F_end == t.F_begin) { t.F_pos = t.F_end - 1 } else { t.F_pos = t.F_end }
	return t.Current__C()
}
func (t *StringCharacterIterator) SetIndex_I__C(p int32) uint16 {
	var tmp1 bool; var tmp2 bool; tmp2 = p < t.F_begin; if !tmp2 { tmp2 = p > t.F_end }; tmp1 = tmp2; if tmp1 { panic(Thrown(IllegalArgumentException_New_String(Lit_1699))) }
	t.F_pos = p
	return t.Current__C()
}
func (t *StringCharacterIterator) Current__C() uint16 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_pos >= t.F_begin; if tmp2 { tmp2 = t.F_pos < t.F_end }; tmp1 = tmp2; if tmp1 { return NN(t.F_text).CharAt_I__C(t.F_pos) } else { return 65535
	} }
func (t *StringCharacterIterator) Next__C() uint16 {
	if t.F_pos < t.F_end-1 {
		t.F_pos = t.F_pos + 1; return NN(t.F_text).CharAt_I__C(t.F_pos) } else {
			t.F_pos = t.F_end; return 65535
		} }
func (t *StringCharacterIterator) Previous__C() uint16 {
	if t.F_pos > t.F_begin {
		t.F_pos = t.F_pos - 1; return NN(t.F_text).CharAt_I__C(t.F_pos) } else {
//line :58:1
			return 65535
		}
}

func (t *StringCharacterIterator) GetBeginIndex__I() int32 { return t.F_begin }

func (t *StringCharacterIterator) GetEndIndex__I() int32 { return t.F_end }

func (t *StringCharacterIterator) GetIndex__I() int32 { return t.F_pos }

func (t *StringCharacterIterator) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if StringCharacterIterator_InstanceOf(tmp1) { var that *StringCharacterIterator = StringCharacterIterator_Cast(tmp1)
			if !(t.HashCode__I() == NN(that).HashCode__I()) { return false } else { var tmp2 *String = t.F_text; if !NN(tmp2).Equals_O__Z(that.F_text.Ref()) { return false } else { var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 int32 = t.F_pos


				tmp5 = !(tmp6 == that.F_pos); if !tmp5 { var tmp7 int32 = t.F_begin; tmp5 = !(tmp7 == that.F_begin) }; tmp4 = tmp5; if !tmp4 {
					var tmp8 int32 = t.F_end; tmp4 = !(tmp8 == that.F_end) }
//line :75:1
				tmp3 = tmp4
//line :72:1
				if tmp3 { return false } else { return true
				}
			}
			} } else {
//line :71:1
				return false
			}
	}
}






func (t *StringCharacterIterator) HashCode__I() int32 {
	return NN(t.F_text).HashCode__I() ^ t.F_pos ^ t.F_begin ^ t.F_end
}
func (t *StringCharacterIterator) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var other *StringCharacterIterator = StringCharacterIterator_Cast(A2g_ObjectClone(t)); tmp1 = other.Ref() }; return nil }()
//line :85:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :85:1
			panic(tmp2) } }; return tmp1
}



type StringCharacterIterator struct{ Object; F_text *String; F_begin, F_end, F_pos int32 }

func (t *StringCharacterIterator) Is_CharacterIterator() {}

func (t *StringCharacterIterator) Is_Cloneable() {}

func (t *StringCharacterIterator) Ref() any { if t == nil { return nil }; return t }

func (t *StringCharacterIterator) GetClass__Class() *Class { return StringCharacterIterator_class }

func (t *StringCharacterIterator) ToString__String() *String { return Object_toString(t) }

func (t *StringCharacterIterator) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func StringCharacterIterator_InstanceOf(x any) bool { _, ok := x.(*StringCharacterIterator); return ok }

func StringCharacterIterator_Cast(x any) *StringCharacterIterator { if x == nil { return nil }; v, ok := x.(*StringCharacterIterator); if !ok { panic(ClassCast(x, StringCharacterIterator_class)) }; return v }
