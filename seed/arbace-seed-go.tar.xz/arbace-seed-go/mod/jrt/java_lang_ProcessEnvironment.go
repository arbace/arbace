//line java_lang_ProcessEnvironment.ae:1
package jrt



































func ProcessEnvironment_Getenv_String__String(p0 *String) *String { ProcessEnvironment_Init(); panic(A2g_NotTranslated("java.lang.ProcessEnvironment.getenv(Ljava/lang/String;)Ljava/lang/String;")) }


func ProcessEnvironment_Getenv__Map() Map { ProcessEnvironment_Init(); panic(A2g_NotTranslated("java.lang.ProcessEnvironment.getenv()Ljava/util/Map;")) }


func ProcessEnvironment_Environment__Map() Map { ProcessEnvironment_Init()
	return ProcessEnvironment_StringEnvironment_New_Map(Map_Cast(ProcessEnvironment_theEnvironment.Clone__O()))
}
func ProcessEnvironment_EmptyEnvironment_I__Map(p0 int32) Map { ProcessEnvironment_Init(); panic(A2g_NotTranslated("java.lang.ProcessEnvironment.emptyEnvironment(I)Ljava/util/Map;")) }


func ProcessEnvironment_Environ__B2() *RefArray { return ProcessEnvironment_Environ__B2_native() }

func ProcessEnvironment_New() *ProcessEnvironment { ProcessEnvironment_Init(); t := &ProcessEnvironment{}; t.Ctor(); return t }
//line :51:1
func (t *ProcessEnvironment) Ctor() { panic(A2g_NotTranslated("java.lang.ProcessEnvironment.<init>()V")) }

func ProcessEnvironment_ValidateVariable_String__V(name *String) { ProcessEnvironment_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = !(NN(name).IndexOf_I__I(61) == -1); if !tmp2 { tmp2 = !(NN(name).IndexOf_I__I(0) == -1) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1169, name, Lit_1142))))
	}
}
func ProcessEnvironment_ValidateValue_String__V(value *String) { ProcessEnvironment_Init()
	if NN(value).IndexOf_I__I(0) == -1 { } else {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1170, value, Lit_1142))))
	}
}





func (t *ProcessEnvironment_ExternalData) Ctor_String_B1(this ProcessEnvironment_ExternalData_I, str *String, bytes *ByteArray) {
	t.F_str = str
	t.F_bytes = bytes
}
func (t *ProcessEnvironment_ExternalData) Impl_GetBytes__B1(this ProcessEnvironment_ExternalData_I) *ByteArray { return t.F_bytes }

func (t *ProcessEnvironment_ExternalData) Impl_ToString__String(this ProcessEnvironment_ExternalData_I) *String { return t.F_str }

func (t *ProcessEnvironment_ExternalData) Impl_Equals_O__Z(this ProcessEnvironment_ExternalData_I, o any) bool {
	var tmp1 bool; tmp1 = ProcessEnvironment_ExternalData_InstanceOf(o); if tmp1 {
		tmp1 = Arrays_Equals_B1_B1__Z(this.GetBytes__B1(), ProcessEnvironment_ExternalData_Cast(o).GetBytes__B1()) }
//line :77:1
	return tmp1
}

func (t *ProcessEnvironment_ExternalData) Impl_HashCode__I(this ProcessEnvironment_ExternalData_I) int32 {
	return Arrays_HashCode_B1__I(this.GetBytes__B1())
}




func ProcessEnvironment_Variable_New_String_B1(p0 *String, p1 *ByteArray) *ProcessEnvironment_Variable { t := &ProcessEnvironment_Variable{}; t.Ctor_String_B1(p0, p1); return t }
//line :87:1
func (t *ProcessEnvironment_Variable) Ctor_String_B1(str *String, bytes *ByteArray) { t.ProcessEnvironment_ExternalData.Ctor_String_B1(t, str, bytes) }


func ProcessEnvironment_Variable_ValueOfQueryOnly_O__ProcessEnvironment_Variable(str any) *ProcessEnvironment_Variable {
	return ProcessEnvironment_Variable_ValueOfQueryOnly_String__ProcessEnvironment_Variable(String_Cast(str))
}
func ProcessEnvironment_Variable_ValueOfQueryOnly_String__ProcessEnvironment_Variable(str *String) *ProcessEnvironment_Variable {
	var tmp1 Charset_I; ProcessImpl_Init(); tmp1 = ProcessImpl_JNU_CHARSET; return ProcessEnvironment_Variable_New_String_B1(str, NN(str).GetBytes_Charset__B1(tmp1))
}
func ProcessEnvironment_Variable_ValueOf_String__ProcessEnvironment_Variable(str *String) *ProcessEnvironment_Variable {
	ProcessEnvironment_ValidateVariable_String__V(str)
	return ProcessEnvironment_Variable_ValueOfQueryOnly_String__ProcessEnvironment_Variable(str)
}
func ProcessEnvironment_Variable_ValueOf_B1__ProcessEnvironment_Variable(bytes *ByteArray) *ProcessEnvironment_Variable {
	var tmp1 Charset_I; ProcessImpl_Init(); tmp1 = ProcessImpl_JNU_CHARSET; return ProcessEnvironment_Variable_New_String_B1(String_New_B1_Charset(bytes, tmp1), bytes)
}
func (t *ProcessEnvironment_Variable) CompareTo_ProcessEnvironment_Variable__I(variable *ProcessEnvironment_Variable) int32 {
	return Arrays_Compare_B1_B1__I(t.GetBytes__B1(), NN(variable).GetBytes__B1())
}
func (t *ProcessEnvironment_Variable) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = ProcessEnvironment_Variable_InstanceOf(o); if tmp1 { tmp1 = t.ProcessEnvironment_ExternalData.Impl_Equals_O__Z(t, o) }; return tmp1
}




func ProcessEnvironment_Value_New_String_B1(p0 *String, p1 *ByteArray) *ProcessEnvironment_Value { t := &ProcessEnvironment_Value{}; t.Ctor_String_B1(p0, p1); return t }
//line :113:1
func (t *ProcessEnvironment_Value) Ctor_String_B1(str *String, bytes *ByteArray) { t.ProcessEnvironment_ExternalData.Ctor_String_B1(t, str, bytes) }


func ProcessEnvironment_Value_ValueOfQueryOnly_O__ProcessEnvironment_Value(str any) *ProcessEnvironment_Value {
	return ProcessEnvironment_Value_ValueOfQueryOnly_String__ProcessEnvironment_Value(String_Cast(str))
}
func ProcessEnvironment_Value_ValueOfQueryOnly_String__ProcessEnvironment_Value(str *String) *ProcessEnvironment_Value {
	var tmp1 Charset_I; ProcessImpl_Init(); tmp1 = ProcessImpl_JNU_CHARSET; return ProcessEnvironment_Value_New_String_B1(str, NN(str).GetBytes_Charset__B1(tmp1))
}
func ProcessEnvironment_Value_ValueOf_String__ProcessEnvironment_Value(str *String) *ProcessEnvironment_Value {
	ProcessEnvironment_ValidateValue_String__V(str)
	return ProcessEnvironment_Value_ValueOfQueryOnly_String__ProcessEnvironment_Value(str)
}
func ProcessEnvironment_Value_ValueOf_B1__ProcessEnvironment_Value(bytes *ByteArray) *ProcessEnvironment_Value {
	var tmp1 Charset_I; ProcessImpl_Init(); tmp1 = ProcessImpl_JNU_CHARSET; return ProcessEnvironment_Value_New_String_B1(String_New_B1_Charset(bytes, tmp1), bytes)
}
func (t *ProcessEnvironment_Value) CompareTo_ProcessEnvironment_Value__I(value *ProcessEnvironment_Value) int32 {
	return Arrays_Compare_B1_B1__I(t.GetBytes__B1(), NN(value).GetBytes__B1())
}
func (t *ProcessEnvironment_Value) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = ProcessEnvironment_Value_InstanceOf(o); if tmp1 { tmp1 = t.ProcessEnvironment_ExternalData.Impl_Equals_O__Z(t, o) }; return tmp1
}





func ProcessEnvironment_StringEnvironment_ToString_ProcessEnvironment_Value__String(v *ProcessEnvironment_Value) *String {
	if !(v == nil) { return NN(v).ToString__String() } else { return nil
	} }
func ProcessEnvironment_StringEnvironment_New_Map(p0 Map) *ProcessEnvironment_StringEnvironment { t := &ProcessEnvironment_StringEnvironment{}; t.Ctor_Map(p0); return t }
//line :143:1
func (t *ProcessEnvironment_StringEnvironment) Ctor_Map(m Map) { t.AbstractMap.Ctor(t)
	t.F_m = m
}
func (t *ProcessEnvironment_StringEnvironment) Size__I() int32 { return t.F_m.Size__I() }

func (t *ProcessEnvironment_StringEnvironment) IsEmpty__Z() bool { return t.F_m.IsEmpty__Z() }

func (t *ProcessEnvironment_StringEnvironment) Clear__V() { t.F_m.Clear__V() }

func (t *ProcessEnvironment_StringEnvironment) ContainsKey_O__Z(key any) bool {
	var tmp1 Map = t.F_m; return tmp1.ContainsKey_O__Z(ProcessEnvironment_Variable_ValueOfQueryOnly_O__ProcessEnvironment_Variable(key).Ref())
}
func (t *ProcessEnvironment_StringEnvironment) ContainsValue_O__Z(value any) bool {
	var tmp1 Map = t.F_m; return tmp1.ContainsValue_O__Z(ProcessEnvironment_Value_ValueOfQueryOnly_O__ProcessEnvironment_Value(value).Ref())
}
func (t *ProcessEnvironment_StringEnvironment) Get_O__String(key any) *String {
	var tmp1 Map = t.F_m; return ProcessEnvironment_StringEnvironment_ToString_ProcessEnvironment_Value__String(ProcessEnvironment_Value_Cast(tmp1.Get_O__O(ProcessEnvironment_Variable_ValueOfQueryOnly_O__ProcessEnvironment_Variable(key).Ref())))
}
func (t *ProcessEnvironment_StringEnvironment) Put_String_String__String(key, value *String) *String {
	var tmp1 Map = t.F_m; return ProcessEnvironment_StringEnvironment_ToString_ProcessEnvironment_Value__String(ProcessEnvironment_Value_Cast(tmp1.Put_O_O__O(ProcessEnvironment_Variable_ValueOf_String__ProcessEnvironment_Variable(key).Ref(), ProcessEnvironment_Value_ValueOf_String__ProcessEnvironment_Value(value).Ref())))
}

func (t *ProcessEnvironment_StringEnvironment) Remove_O__String(key any) *String {
	var tmp1 Map = t.F_m; return ProcessEnvironment_StringEnvironment_ToString_ProcessEnvironment_Value__String(ProcessEnvironment_Value_Cast(tmp1.Remove_O__O(ProcessEnvironment_Variable_ValueOfQueryOnly_O__ProcessEnvironment_Variable(key).Ref())))
}
func (t *ProcessEnvironment_StringEnvironment) KeySet__Set() Set {
	return ProcessEnvironment_StringKeySet_New_Set(t.F_m.KeySet__Set())
}
func (t *ProcessEnvironment_StringEnvironment) EntrySet__Set() Set {
	return ProcessEnvironment_StringEntrySet_New_Set(t.F_m.EntrySet__Set())
}
func (t *ProcessEnvironment_StringEnvironment) Values__Collection() Collection {
	return ProcessEnvironment_StringValues_New_Collection(t.F_m.Values__Collection())
}
func (t *ProcessEnvironment_StringEnvironment) ToEnvironmentBlock_I1__B1(envc *IntArray) *ByteArray {
	var count int32 = t.F_m.Size__I() * 2; var i_101084 Iterator = t.F_m.EntrySet__Set().Iterator__Iterator(); for i_101084.HasNext__Z() {
		var entry Map_Entry = Map_Entry_Cast(i_101084.Next__O())
		count = count + int32(len(NN(ProcessEnvironment_Variable_Cast(entry.GetKey__O())).GetBytes__B1().A))

		count = count + int32(len(NN(ProcessEnvironment_Value_Cast(entry.GetValue__O())).GetBytes__B1().A))
	}
	var block *ByteArray = NewByteArray(count); var i int32 = 0; var i_101085 Iterator = t.F_m.EntrySet__Set().Iterator__Iterator(); for i_101085.HasNext__Z() {

		var entry_2 Map_Entry = Map_Entry_Cast(i_101085.Next__O()); var key *ByteArray = NN(ProcessEnvironment_Variable_Cast(entry_2.GetKey__O())).GetBytes__B1(); var value *ByteArray = NN(ProcessEnvironment_Value_Cast(entry_2.GetValue__O())).GetBytes__B1()


		System_Arraycopy_O_I_O_I_I__V(key.Ref(), 0, block.Ref(), i, int32(len(key.A)))
		i = i + int32(len(key.A))
		block.A[i] = 61
		i = i + 1
		System_Arraycopy_O_I_O_I_I__V(value.Ref(), 0, block.Ref(), i, int32(len(value.A)))
		i = i + (int32(len(value.A)) + 1) }
	envc.A[0] = t.F_m.Size__I()
//line :184:1
	return block
}












func ProcessEnvironment_ToEnvironmentBlock_Map_I1__B1(map_ Map, envc *IntArray) *ByteArray { ProcessEnvironment_Init()
	if !(map_ == nil) { return NN(ProcessEnvironment_StringEnvironment_Cast(map_)).ToEnvironmentBlock_I1__B1(envc) } else { return nil
	}
}




func ProcessEnvironment_StringEntry_New_Map_Entry(p0 Map_Entry) *ProcessEnvironment_StringEntry { t := &ProcessEnvironment_StringEntry{}; t.Ctor_Map_Entry(p0); return t }
//line :206:1
func (t *ProcessEnvironment_StringEntry) Ctor_Map_Entry(e Map_Entry) {
	t.F_e = e
}
func (t *ProcessEnvironment_StringEntry) GetKey__String() *String {
	return NN(ProcessEnvironment_Variable_Cast(t.F_e.GetKey__O())).ToString__String()
}
func (t *ProcessEnvironment_StringEntry) GetValue__String() *String {
	return NN(ProcessEnvironment_Value_Cast(t.F_e.GetValue__O())).ToString__String()
}
func (t *ProcessEnvironment_StringEntry) SetValue_String__String(newValue *String) *String {
	var tmp1 Map_Entry = t.F_e; return NN(ProcessEnvironment_Value_Cast(tmp1.SetValue_O__O(ProcessEnvironment_Value_ValueOf_String__ProcessEnvironment_Value(newValue).Ref()))).ToString__String()
}
func (t *ProcessEnvironment_StringEntry) ToString__String() *String {
	return Concat(t.GetKey__String(), Lit_1171, t.GetValue__String())
}
func (t *ProcessEnvironment_StringEntry) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = ProcessEnvironment_StringEntry_InstanceOf(o); if tmp1 { var tmp2 Map_Entry = t.F_e; tmp1 = tmp2.Equals_O__Z(ProcessEnvironment_StringEntry_Cast(o).F_e) }; return tmp1
}
func (t *ProcessEnvironment_StringEntry) HashCode__I() int32 { return t.F_e.HashCode__I() }






func ProcessEnvironment_StringEntrySet_New_Set(p0 Set) *ProcessEnvironment_StringEntrySet { t := &ProcessEnvironment_StringEntrySet{}; t.Ctor_Set(p0); return t }
//line :231:1
func (t *ProcessEnvironment_StringEntrySet) Ctor_Set(s Set) { t.AbstractSet.Ctor(t)
	t.F_s = s
}
func (t *ProcessEnvironment_StringEntrySet) Size__I() int32 { return t.F_s.Size__I() }

func (t *ProcessEnvironment_StringEntrySet) IsEmpty__Z() bool { return t.F_s.IsEmpty__Z() }

func (t *ProcessEnvironment_StringEntrySet) Clear__V() { t.F_s.Clear__V() }

func (t *ProcessEnvironment_StringEntrySet) Iterator__Iterator() Iterator {
	return ProcessEnvironment_StringEntrySet_1_New_ProcessEnvironment_StringEntrySet(t)
}

func (t *ProcessEnvironment_StringEntrySet_1) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *ProcessEnvironment_StringEntrySet_1) Next__Map_Entry() Map_Entry {
	return ProcessEnvironment_StringEntry_New_Map_Entry(Map_Entry_Cast(t.F_i.Next__O()))
}
func (t *ProcessEnvironment_StringEntrySet_1) Remove__V() { t.F_i.Remove__V() }

func ProcessEnvironment_StringEntrySet_VvEntry_O__Map_Entry(o any) Map_Entry {
	if ProcessEnvironment_StringEntry_InstanceOf(o) {
		return ProcessEnvironment_StringEntry_Cast(o).F_e } else {
			return ProcessEnvironment_StringEntrySet_2_New_O(o) } }
func (t *ProcessEnvironment_StringEntrySet_2) GetKey__ProcessEnvironment_Variable() *ProcessEnvironment_Variable {
	return ProcessEnvironment_Variable_ValueOfQueryOnly_O__ProcessEnvironment_Variable(Map_Entry_Cast(t.F_val_o).GetKey__O())
}
func (t *ProcessEnvironment_StringEntrySet_2) GetValue__ProcessEnvironment_Value() *ProcessEnvironment_Value {
	return ProcessEnvironment_Value_ValueOfQueryOnly_O__ProcessEnvironment_Value(Map_Entry_Cast(t.F_val_o).GetValue__O())
}
func (t *ProcessEnvironment_StringEntrySet_2) SetValue_ProcessEnvironment_Value__ProcessEnvironment_Value(value *ProcessEnvironment_Value) *ProcessEnvironment_Value {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *ProcessEnvironment_StringEntrySet) Contains_O__Z(o any) bool {
	var tmp1 Set = t.F_s; return tmp1.Contains_O__Z(ProcessEnvironment_StringEntrySet_VvEntry_O__Map_Entry(o))
}
func (t *ProcessEnvironment_StringEntrySet) Remove_O__Z(o any) bool {
	var tmp1 Set = t.F_s; return tmp1.Remove_O__Z(ProcessEnvironment_StringEntrySet_VvEntry_O__Map_Entry(o))
}
func (t *ProcessEnvironment_StringEntrySet) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = ProcessEnvironment_StringEntrySet_InstanceOf(o); if tmp1 { var tmp2 Set = t.F_s; tmp1 = tmp2.Equals_O__Z(ProcessEnvironment_StringEntrySet_Cast(o).F_s) }; return tmp1
}
func (t *ProcessEnvironment_StringEntrySet) HashCode__I() int32 { return t.F_s.HashCode__I() }






func ProcessEnvironment_StringValues_New_Collection(p0 Collection) *ProcessEnvironment_StringValues { t := &ProcessEnvironment_StringValues{}; t.Ctor_Collection(p0); return t }
//line :280:1
func (t *ProcessEnvironment_StringValues) Ctor_Collection(c Collection) { t.AbstractCollection.Ctor(t)
	t.F_c = c
}
func (t *ProcessEnvironment_StringValues) Size__I() int32 { return t.F_c.Size__I() }

func (t *ProcessEnvironment_StringValues) IsEmpty__Z() bool { return t.F_c.IsEmpty__Z() }

func (t *ProcessEnvironment_StringValues) Clear__V() { t.F_c.Clear__V() }

func (t *ProcessEnvironment_StringValues) Iterator__Iterator() Iterator {
	return ProcessEnvironment_StringValues_1_New_ProcessEnvironment_StringValues(t)
}

func (t *ProcessEnvironment_StringValues_1) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *ProcessEnvironment_StringValues_1) Next__String() *String { return NN(ProcessEnvironment_Value_Cast(t.F_i.Next__O())).ToString__String() }

func (t *ProcessEnvironment_StringValues_1) Remove__V() { t.F_i.Remove__V() }

func (t *ProcessEnvironment_StringValues) Contains_O__Z(o any) bool {
	var tmp1 Collection = t.F_c; return tmp1.Contains_O__Z(ProcessEnvironment_Value_ValueOfQueryOnly_O__ProcessEnvironment_Value(o).Ref())
}
func (t *ProcessEnvironment_StringValues) Remove_O__Z(o any) bool {
	var tmp1 Collection = t.F_c; return tmp1.Remove_O__Z(ProcessEnvironment_Value_ValueOfQueryOnly_O__ProcessEnvironment_Value(o).Ref())
}
func (t *ProcessEnvironment_StringValues) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = ProcessEnvironment_StringValues_InstanceOf(o); if tmp1 { var tmp2 Collection = t.F_c; tmp1 = tmp2.Equals_O__Z(ProcessEnvironment_StringValues_Cast(o).F_c) }; return tmp1
}
func (t *ProcessEnvironment_StringValues) HashCode__I() int32 { return t.F_c.HashCode__I() }






func ProcessEnvironment_StringKeySet_New_Set(p0 Set) *ProcessEnvironment_StringKeySet { t := &ProcessEnvironment_StringKeySet{}; t.Ctor_Set(p0); return t }
//line :315:1
func (t *ProcessEnvironment_StringKeySet) Ctor_Set(s Set) { t.AbstractSet.Ctor(t)
	t.F_s = s
}
func (t *ProcessEnvironment_StringKeySet) Size__I() int32 { return t.F_s.Size__I() }

func (t *ProcessEnvironment_StringKeySet) IsEmpty__Z() bool { return t.F_s.IsEmpty__Z() }

func (t *ProcessEnvironment_StringKeySet) Clear__V() { t.F_s.Clear__V() }

func (t *ProcessEnvironment_StringKeySet) Iterator__Iterator() Iterator {
	return ProcessEnvironment_StringKeySet_1_New_ProcessEnvironment_StringKeySet(t)
}

func (t *ProcessEnvironment_StringKeySet_1) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *ProcessEnvironment_StringKeySet_1) Next__String() *String {
	return NN(ProcessEnvironment_Variable_Cast(t.F_i.Next__O())).ToString__String()
}
func (t *ProcessEnvironment_StringKeySet_1) Remove__V() { t.F_i.Remove__V() }

func (t *ProcessEnvironment_StringKeySet) Contains_O__Z(o any) bool {
	var tmp1 Set = t.F_s; return tmp1.Contains_O__Z(ProcessEnvironment_Variable_ValueOfQueryOnly_O__ProcessEnvironment_Variable(o).Ref())
}
func (t *ProcessEnvironment_StringKeySet) Remove_O__Z(o any) bool {
	var tmp1 Set = t.F_s; return tmp1.Remove_O__Z(ProcessEnvironment_Variable_ValueOfQueryOnly_O__ProcessEnvironment_Variable(o).Ref())
}


type ProcessEnvironment struct{ Object }

var ProcessEnvironment_theEnvironment HashMap_I

var ProcessEnvironment_theUnmodifiableEnvironment Map

const ProcessEnvironment_MIN_NAME_LENGTH int32 = 0

var ProcessEnvironment_init ClassInit

func ProcessEnvironment_Init() { if !ProcessEnvironment_init.Done() { ProcessEnvironment_init.Run(ProcessEnvironment_clinit) } }

func ProcessEnvironment_clinit() {
//line :25:1
	var environ *RefArray = ProcessEnvironment_Environ__B2()
	ProcessEnvironment_theEnvironment = HashMap_New_I(int32(len(environ.A))/2 + 3)

	var i int32 = int32(len(environ.A)) - 1; L1: for {
		if i > 0 {
			var tmp1 HashMap_I = ProcessEnvironment_theEnvironment; tmp1.Put_O_O__O(ProcessEnvironment_Variable_ValueOf_B1__ProcessEnvironment_Variable(As[*ByteArray](environ.A[i-1])).Ref(), ProcessEnvironment_Value_ValueOf_B1__ProcessEnvironment_Value(As[*ByteArray](environ.A[i])).Ref())


			i = i - 2; continue L1 }
//line :28:1
		break L1
	}




	ProcessEnvironment_theUnmodifiableEnvironment = Collections_UnmodifiableMap_Map__Map(ProcessEnvironment_StringEnvironment_New_Map(ProcessEnvironment_theEnvironment))
}

































































































































































































































































































































func (t *ProcessEnvironment) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment) GetClass__Class() *Class { return ProcessEnvironment_class }

func (t *ProcessEnvironment) ToString__String() *String { return Object_toString(t) }

func (t *ProcessEnvironment) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment); return ok }

func ProcessEnvironment_Cast(x any) *ProcessEnvironment { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment); if !ok { panic(ClassCast(x, ProcessEnvironment_class)) }; return v }



type ProcessEnvironment_ExternalData struct{ Object; F_str *String; F_bytes *ByteArray }

type ProcessEnvironment_ExternalData_I interface{ Object_I; Self_ProcessEnvironment_ExternalData() *ProcessEnvironment_ExternalData; GetBytes__B1() *ByteArray }

func (t *ProcessEnvironment_ExternalData) Self_ProcessEnvironment_ExternalData() *ProcessEnvironment_ExternalData { return t }

func ProcessEnvironment_ExternalData_InstanceOf(x any) bool { _, ok := x.(ProcessEnvironment_ExternalData_I); return ok }

func ProcessEnvironment_ExternalData_Cast(x any) ProcessEnvironment_ExternalData_I { if x == nil { return nil }; v, ok := x.(ProcessEnvironment_ExternalData_I); if !ok { panic(ClassCast(x, ProcessEnvironment_ExternalData_class)) }; return v }



type ProcessEnvironment_StringEntry struct{ Object; F_e Map_Entry }

func (t *ProcessEnvironment_StringEntry) Is_Map_Entry() {}

func (t *ProcessEnvironment_StringEntry) GetKey__O() any { return t.GetKey__String().Ref() }

func (t *ProcessEnvironment_StringEntry) GetValue__O() any { return t.GetValue__String().Ref() }

func (t *ProcessEnvironment_StringEntry) SetValue_O__O(p0 any) any { return t.SetValue_String__String(String_Cast(p0)).Ref() }

func (t *ProcessEnvironment_StringEntry) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringEntry) GetClass__Class() *Class { return ProcessEnvironment_StringEntry_class }

func (t *ProcessEnvironment_StringEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringEntry_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringEntry); return ok }

func ProcessEnvironment_StringEntry_Cast(x any) *ProcessEnvironment_StringEntry { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringEntry); if !ok { panic(ClassCast(x, ProcessEnvironment_StringEntry_class)) }; return v }



type ProcessEnvironment_StringEntrySet struct{ AbstractSet; F_s Set }

func (t *ProcessEnvironment_StringEntrySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *ProcessEnvironment_StringEntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ProcessEnvironment_StringEntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ProcessEnvironment_StringEntrySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ProcessEnvironment_StringEntrySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringEntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessEnvironment_StringEntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringEntrySet) GetClass__Class() *Class { return ProcessEnvironment_StringEntrySet_class }

func (t *ProcessEnvironment_StringEntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringEntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringEntrySet_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringEntrySet); return ok }

func ProcessEnvironment_StringEntrySet_Cast(x any) *ProcessEnvironment_StringEntrySet { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringEntrySet); if !ok { panic(ClassCast(x, ProcessEnvironment_StringEntrySet_class)) }; return v }



type ProcessEnvironment_StringEntrySet_1 struct{ Object; F_i Iterator; F_this_0 *ProcessEnvironment_StringEntrySet }

func (t *ProcessEnvironment_StringEntrySet_1) Is_Iterator() {}

func ProcessEnvironment_StringEntrySet_1_New_ProcessEnvironment_StringEntrySet(p0 *ProcessEnvironment_StringEntrySet) *ProcessEnvironment_StringEntrySet_1 { t := &ProcessEnvironment_StringEntrySet_1{}; t.Ctor_ProcessEnvironment_StringEntrySet(p0); return t }

func (t *ProcessEnvironment_StringEntrySet_1) Ctor_ProcessEnvironment_StringEntrySet(this_0 *ProcessEnvironment_StringEntrySet) { NN(this_0); t.F_this_0 = this_0; t.F_i = this_0.F_s.Iterator__Iterator() }

func (t *ProcessEnvironment_StringEntrySet_1) Next__O() any { return t.Next__Map_Entry() }

func (t *ProcessEnvironment_StringEntrySet_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ProcessEnvironment_StringEntrySet_1) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringEntrySet_1) GetClass__Class() *Class { return ProcessEnvironment_StringEntrySet_1_class }

func (t *ProcessEnvironment_StringEntrySet_1) ToString__String() *String { return Object_toString(t) }

func (t *ProcessEnvironment_StringEntrySet_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringEntrySet_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringEntrySet_1_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringEntrySet_1); return ok }

func ProcessEnvironment_StringEntrySet_1_Cast(x any) *ProcessEnvironment_StringEntrySet_1 { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringEntrySet_1); if !ok { panic(ClassCast(x, ProcessEnvironment_StringEntrySet_1_class)) }; return v }



type ProcessEnvironment_StringEntrySet_2 struct{ Object; F_val_o any }

func (t *ProcessEnvironment_StringEntrySet_2) Is_Map_Entry() {}

func ProcessEnvironment_StringEntrySet_2_New_O(p0 any) *ProcessEnvironment_StringEntrySet_2 { t := &ProcessEnvironment_StringEntrySet_2{}; t.Ctor_O(p0); return t }

func (t *ProcessEnvironment_StringEntrySet_2) Ctor_O(val_o any) { t.F_val_o = val_o }

func (t *ProcessEnvironment_StringEntrySet_2) GetKey__O() any { return t.GetKey__ProcessEnvironment_Variable().Ref() }

func (t *ProcessEnvironment_StringEntrySet_2) GetValue__O() any { return t.GetValue__ProcessEnvironment_Value().Ref() }

func (t *ProcessEnvironment_StringEntrySet_2) SetValue_O__O(p0 any) any { return t.SetValue_ProcessEnvironment_Value__ProcessEnvironment_Value(ProcessEnvironment_Value_Cast(p0)).Ref() }

func (t *ProcessEnvironment_StringEntrySet_2) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringEntrySet_2) GetClass__Class() *Class { return ProcessEnvironment_StringEntrySet_2_class }

func (t *ProcessEnvironment_StringEntrySet_2) ToString__String() *String { return Object_toString(t) }

func (t *ProcessEnvironment_StringEntrySet_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringEntrySet_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringEntrySet_2_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringEntrySet_2); return ok }

func ProcessEnvironment_StringEntrySet_2_Cast(x any) *ProcessEnvironment_StringEntrySet_2 { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringEntrySet_2); if !ok { panic(ClassCast(x, ProcessEnvironment_StringEntrySet_2_class)) }; return v }



type ProcessEnvironment_StringEnvironment struct{ AbstractMap; F_m Map }

func (t *ProcessEnvironment_StringEnvironment) Get_O__O(p0 any) any { return t.Get_O__String(p0).Ref() }

func (t *ProcessEnvironment_StringEnvironment) Put_O_O__O(p0, p1 any) any { return t.Put_String_String__String(String_Cast(p0), String_Cast(p1)).Ref() }

func (t *ProcessEnvironment_StringEnvironment) Remove_O__O(p0 any) any { return t.Remove_O__String(p0).Ref() }

func (t *ProcessEnvironment_StringEnvironment) Replace_O_O__O(p0, p1 any) any { return Map_Replace_O_O__O(t, p0, p1) }

func (t *ProcessEnvironment_StringEnvironment) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *ProcessEnvironment_StringEnvironment) Remove_O_O__Z(p0, p1 any) bool { return Map_Remove_O_O__Z(t, p0, p1) }

func (t *ProcessEnvironment_StringEnvironment) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *ProcessEnvironment_StringEnvironment) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *ProcessEnvironment_StringEnvironment) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *ProcessEnvironment_StringEnvironment) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *ProcessEnvironment_StringEnvironment) ReplaceAll_BiFunction__V(p0 BiFunction) { Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *ProcessEnvironment_StringEnvironment) PutIfAbsent_O_O__O(p0, p1 any) any { return Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *ProcessEnvironment_StringEnvironment) ForEach_BiConsumer__V(p0 BiConsumer) { Map_ForEach_BiConsumer__V(t, p0) }

func (t *ProcessEnvironment_StringEnvironment) Replace_O_O_O__Z(p0, p1, p2 any) bool { return Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *ProcessEnvironment_StringEnvironment) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *ProcessEnvironment_StringEnvironment) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ProcessEnvironment_StringEnvironment) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessEnvironment_StringEnvironment) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessEnvironment_StringEnvironment) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessEnvironment_StringEnvironment) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringEnvironment) GetClass__Class() *Class { return ProcessEnvironment_StringEnvironment_class }

func (t *ProcessEnvironment_StringEnvironment) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringEnvironment_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringEnvironment); return ok }

func ProcessEnvironment_StringEnvironment_Cast(x any) *ProcessEnvironment_StringEnvironment { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringEnvironment); if !ok { panic(ClassCast(x, ProcessEnvironment_StringEnvironment_class)) }; return v }



type ProcessEnvironment_StringKeySet struct{ AbstractSet; F_s Set }

func (t *ProcessEnvironment_StringKeySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *ProcessEnvironment_StringKeySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ProcessEnvironment_StringKeySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ProcessEnvironment_StringKeySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringKeySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ProcessEnvironment_StringKeySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringKeySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ProcessEnvironment_StringKeySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ProcessEnvironment_StringKeySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringKeySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ProcessEnvironment_StringKeySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ProcessEnvironment_StringKeySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ProcessEnvironment_StringKeySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringKeySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessEnvironment_StringKeySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessEnvironment_StringKeySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessEnvironment_StringKeySet) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringKeySet) GetClass__Class() *Class { return ProcessEnvironment_StringKeySet_class }

func (t *ProcessEnvironment_StringKeySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringKeySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringKeySet_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringKeySet); return ok }

func ProcessEnvironment_StringKeySet_Cast(x any) *ProcessEnvironment_StringKeySet { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringKeySet); if !ok { panic(ClassCast(x, ProcessEnvironment_StringKeySet_class)) }; return v }



type ProcessEnvironment_StringKeySet_1 struct{ Object; F_i Iterator; F_this_0 *ProcessEnvironment_StringKeySet }

func (t *ProcessEnvironment_StringKeySet_1) Is_Iterator() {}

func ProcessEnvironment_StringKeySet_1_New_ProcessEnvironment_StringKeySet(p0 *ProcessEnvironment_StringKeySet) *ProcessEnvironment_StringKeySet_1 { t := &ProcessEnvironment_StringKeySet_1{}; t.Ctor_ProcessEnvironment_StringKeySet(p0); return t }

func (t *ProcessEnvironment_StringKeySet_1) Ctor_ProcessEnvironment_StringKeySet(this_0 *ProcessEnvironment_StringKeySet) { NN(this_0); t.F_this_0 = this_0; t.F_i = this_0.F_s.Iterator__Iterator() }

func (t *ProcessEnvironment_StringKeySet_1) Next__O() any { return t.Next__String().Ref() }

func (t *ProcessEnvironment_StringKeySet_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ProcessEnvironment_StringKeySet_1) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringKeySet_1) GetClass__Class() *Class { return ProcessEnvironment_StringKeySet_1_class }

func (t *ProcessEnvironment_StringKeySet_1) ToString__String() *String { return Object_toString(t) }

func (t *ProcessEnvironment_StringKeySet_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringKeySet_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringKeySet_1_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringKeySet_1); return ok }

func ProcessEnvironment_StringKeySet_1_Cast(x any) *ProcessEnvironment_StringKeySet_1 { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringKeySet_1); if !ok { panic(ClassCast(x, ProcessEnvironment_StringKeySet_1_class)) }; return v }



type ProcessEnvironment_StringValues struct{ AbstractCollection; F_c Collection }

func (t *ProcessEnvironment_StringValues) Spliterator__Spliterator() Spliterator { return Collection_Spliterator__Spliterator(t) }

func (t *ProcessEnvironment_StringValues) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ProcessEnvironment_StringValues) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ProcessEnvironment_StringValues) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringValues) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ProcessEnvironment_StringValues) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringValues) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ProcessEnvironment_StringValues) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ProcessEnvironment_StringValues) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringValues) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ProcessEnvironment_StringValues) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ProcessEnvironment_StringValues) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ProcessEnvironment_StringValues) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ProcessEnvironment_StringValues) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessEnvironment_StringValues) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringValues) GetClass__Class() *Class { return ProcessEnvironment_StringValues_class }

func (t *ProcessEnvironment_StringValues) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringValues) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringValues_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringValues); return ok }

func ProcessEnvironment_StringValues_Cast(x any) *ProcessEnvironment_StringValues { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringValues); if !ok { panic(ClassCast(x, ProcessEnvironment_StringValues_class)) }; return v }



type ProcessEnvironment_StringValues_1 struct{ Object; F_i Iterator; F_this_0 *ProcessEnvironment_StringValues }

func (t *ProcessEnvironment_StringValues_1) Is_Iterator() {}

func ProcessEnvironment_StringValues_1_New_ProcessEnvironment_StringValues(p0 *ProcessEnvironment_StringValues) *ProcessEnvironment_StringValues_1 { t := &ProcessEnvironment_StringValues_1{}; t.Ctor_ProcessEnvironment_StringValues(p0); return t }

func (t *ProcessEnvironment_StringValues_1) Ctor_ProcessEnvironment_StringValues(this_0 *ProcessEnvironment_StringValues) { NN(this_0); t.F_this_0 = this_0; t.F_i = this_0.F_c.Iterator__Iterator() }

func (t *ProcessEnvironment_StringValues_1) Next__O() any { return t.Next__String().Ref() }

func (t *ProcessEnvironment_StringValues_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ProcessEnvironment_StringValues_1) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_StringValues_1) GetClass__Class() *Class { return ProcessEnvironment_StringValues_1_class }

func (t *ProcessEnvironment_StringValues_1) ToString__String() *String { return Object_toString(t) }

func (t *ProcessEnvironment_StringValues_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_StringValues_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_StringValues_1_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_StringValues_1); return ok }

func ProcessEnvironment_StringValues_1_Cast(x any) *ProcessEnvironment_StringValues_1 { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_StringValues_1); if !ok { panic(ClassCast(x, ProcessEnvironment_StringValues_1_class)) }; return v }



type ProcessEnvironment_Value struct{ ProcessEnvironment_ExternalData }

func (t *ProcessEnvironment_Value) Is_Comparable() {}

func (t *ProcessEnvironment_Value) CompareTo_O__I(p0 any) int32 { return t.CompareTo_ProcessEnvironment_Value__I(ProcessEnvironment_Value_Cast(p0)) }

func (t *ProcessEnvironment_Value) GetBytes__B1() *ByteArray { return t.Impl_GetBytes__B1(t) }

func (t *ProcessEnvironment_Value) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessEnvironment_Value) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessEnvironment_Value) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_Value) GetClass__Class() *Class { return ProcessEnvironment_Value_class }

func (t *ProcessEnvironment_Value) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_Value) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_Value_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_Value); return ok }

func ProcessEnvironment_Value_Cast(x any) *ProcessEnvironment_Value { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_Value); if !ok { panic(ClassCast(x, ProcessEnvironment_Value_class)) }; return v }



type ProcessEnvironment_Variable struct{ ProcessEnvironment_ExternalData }

func (t *ProcessEnvironment_Variable) Is_Comparable() {}

func (t *ProcessEnvironment_Variable) CompareTo_O__I(p0 any) int32 { return t.CompareTo_ProcessEnvironment_Variable__I(ProcessEnvironment_Variable_Cast(p0)) }

func (t *ProcessEnvironment_Variable) GetBytes__B1() *ByteArray { return t.Impl_GetBytes__B1(t) }

func (t *ProcessEnvironment_Variable) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessEnvironment_Variable) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessEnvironment_Variable) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessEnvironment_Variable) GetClass__Class() *Class { return ProcessEnvironment_Variable_class }

func (t *ProcessEnvironment_Variable) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessEnvironment_Variable) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessEnvironment_Variable_InstanceOf(x any) bool { _, ok := x.(*ProcessEnvironment_Variable); return ok }

func ProcessEnvironment_Variable_Cast(x any) *ProcessEnvironment_Variable { if x == nil { return nil }; v, ok := x.(*ProcessEnvironment_Variable); if !ok { panic(ClassCast(x, ProcessEnvironment_Variable_class)) }; return v }
