//line java_io_Reader.ae:1
package jrt

import "sync/atomic"










func Reader_NullReader__Reader() Reader_I {
	return Reader_1_New()
}

func (t *Reader_1) EnsureOpen__V() {
	if t.F_closed.Load() { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *Reader_1) Read__I() int32 {
	t.EnsureOpen__V()
//line :21:1
	return -1
}


func (t *Reader_1) Read_C1_I_I__I(cbuf *CharArray, off, len_ int32) int32 {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
	t.EnsureOpen__V()
	if len_ == 0 { return 0 } else { return -1
	} }
func (t *Reader_1) Read_CharBuffer__I(target CharBuffer_I) int32 {
	Objects_RequireNonNull_O__O(target)
	t.EnsureOpen__V()
	if target.HasRemaining__Z() { return -1 } else { return 0
	} }
func (t *Reader_1) Ready__Z() bool {
	t.EnsureOpen__V()
//line :35:1
	return false
}


func (t *Reader_1) Skip_J__J(n int64) int64 {
	t.EnsureOpen__V()
//line :39:1
	return 0
}


func (t *Reader_1) TransferTo_Writer__J(out Writer_I) int64 {
	Objects_RequireNonNull_O__O(out)
	t.EnsureOpen__V()
//line :43:1
	return 0
}



func (t *Reader_1) Close__V() { t.F_closed.Store(true) }

func Reader_Of_CharSequence__Reader(cs CharSequence) Reader_I {
	Objects_RequireNonNull_O__O(cs)
	return Reader_2_New_CharSequence(cs)
}





func (t *Reader_2) EnsureOpen__V() {
	if t.F_isClosed { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *Reader_2) Read__I() int32 {
	t.EnsureOpen__V()
	var tmp1 int32 = t.F_next; if tmp1 >= t.F_val_cs.Length__I() { return -1 } else {

		var tmp2 int32; var old_1 int32 = t.F_next; t.F_next = t.F_next + 1; tmp2 = old_1; return int32(t.F_val_cs.CharAt_I__C(tmp2))
	} }
func (t *Reader_2) Read_C1_I_I__I(cbuf *CharArray, off, len_ int32) int32 {
	t.EnsureOpen__V()
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
	if len_ == 0 { return 0 } else {

		var length int32 = t.F_val_cs.Length__I()
		if t.F_next >= length { return -1 } else {

			var n int32 = Math_Min_I_I__I(length-t.F_next, len_)
			t.F_val_cs.GetChars_I_I_C1_I__V(t.F_next, t.F_next+n, cbuf, off)
			t.F_next = t.F_next + n
//line :76:1
			return n
		}
	}
}

func (t *Reader_2) ReadAllAsString__String() *String {
	t.EnsureOpen__V()
	var len_ int32 = t.F_val_cs.Length__I(); var result *String = t.F_val_cs.SubSequence_I_I__CharSequence(t.F_next, len_).ToString__String(); var tmp1 int32 = t.F_next

	t.F_next = tmp1 + NN(result).Length__I()
//line :83:1
	return result
}



func (t *Reader_2) ReadAllLines__List() List {
	return NN(t.ReadAllAsString__String()).Lines__Stream().ToList__List()
}
func (t *Reader_2) Skip_J__J(n int64) int64 {
	t.EnsureOpen__V()
	var tmp1 int32 = t.F_next; if tmp1 >= t.F_val_cs.Length__I() { return 0 } else {

		var r int64 = Math_Min_J_J__J(int64(t.F_val_cs.Length__I()-t.F_next), n)
		r = Math_Max_J_J__J(int64(-t.F_next), r)
		t.F_next = t.F_next + int32(r)
//line :95:1
		return r
	}
}


func (t *Reader_2) Ready__Z() bool {
	t.EnsureOpen__V()
//line :100:1
	return true
}


func (t *Reader_2) MarkSupported__Z() bool { return true }

func (t *Reader_2) Mark_I__V(readAheadLimit int32) {
	if readAheadLimit < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_52))) }
	t.EnsureOpen__V()
	t.F_mark = t.F_next
}
func (t *Reader_2) Reset__V() {
	t.EnsureOpen__V()
	t.F_next = t.F_mark
}
func (t *Reader_2) Close__V() { t.F_isClosed = true }



func (t *Reader) Ctor(this Reader_I) { t.F_skipBuffer = nil; t.F_lock = this }

func (t *Reader) Ctor_O(this Reader_I, lock any) { t.F_skipBuffer = nil
	if lock == nil { panic(Thrown(NullPointerException_New())) }
	t.F_lock = lock
}
func (t *Reader) Impl_Read_CharBuffer__I(this Reader_I, target CharBuffer_I) int32 {
	if target.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	var nread int32 = 0
	if target.HasArray__Z() {
		var cbuf *CharArray = target.Array__C1(); var pos int32 = target.Position__I(); var rem int32 = Math_Max_I_I__I(target.Limit__I()-pos, 0); var off int32 = target.ArrayOffset__I() + pos



		nread = this.Read_C1_I_I__I(cbuf, off, rem)
		if nread > 0 { target.Position_I__CharBuffer(pos + nread) } } else {
			var len_ int32 = target.Remaining__I(); var cbuf_2 *CharArray = NewCharArray(len_)

			nread = this.Read_C1_I_I__I(cbuf_2, 0, len_)
			if nread > 0 { target.Put_C1_I_I__CharBuffer(cbuf_2, 0, nread) } }
//line :127:1
	return nread
}












func (t *Reader) Impl_Read__I(this Reader_I) int32 {
	var cb *CharArray = NewCharArray(1); if this.Read_C1_I_I__I(cb, 0, 1) == -1 { return -1 } else { return int32(cb.A[0])
	} }
func (t *Reader) Impl_Read_C1__I(this Reader_I, cbuf *CharArray) int32 {
	return this.Read_C1_I_I__I(cbuf, 0, int32(len(cbuf.A)))
}


func (t *Reader) Impl_ReadAllLines__List(this Reader_I) List {
	var lines List = ArrayList_New(); var cb *CharArray = NewCharArray(1024)
	var start int32 = 0
	var pos int32 = 0
	var limit int32 = 0
	var skipLF bool = false
	var n int32 = 0

L1: for { var tmp1 int32; n = this.Read_C1_I_I__I(cb, pos, int32(len(cb.A))-pos); tmp1 = n; if !(tmp1 == -1) {
	limit = pos + n
L2: for { if pos < limit {
	if skipLF {
		if int32(cb.A[pos]) == 10 {
			pos = pos + 1
			start = start + 1 }
		skipLF = false }
L3: for { if pos < limit {
	var c uint16; var tmp2 *CharArray = cb; var tmp3 int32; var old_2 int32 = pos; pos = pos + 1; tmp3 = old_2; c = tmp2.A[tmp3]
	var tmp4 bool; var tmp5 bool; tmp5 = int32(c) == 10; if !tmp5 { tmp5 = int32(c) == 13 }; tmp4 = tmp5; if tmp4 {
		lines.Add_O__Z(String_New_C1_I_I(cb, start, pos-1-start))



		skipLF = int32(c) == 13
		start = pos
		break L3 }
//line :165:1
	continue L3 }; break L3
}








	if pos == limit {
		var len_ int32 = limit - start
		if len_ >= int32(len(cb.A))/2 {

			var tmp6 int32 = int32(len(cb.A)); var newLength int32 = ArraysSupport_NewLength_I_I_I__I(tmp6, 8192, int32(len(cb.A))); var tmp *CharArray = NewCharArray(newLength)




			System_Arraycopy_O_I_O_I_I__V(cb.Ref(), start, tmp.Ref(), 0, len_)
			cb = tmp } else {
//line :177:1
				var tmp7 bool; var tmp8 bool








				tmp8 = !(start == 0); if tmp8 { tmp8 = !(len_ == 0) }; tmp7 = tmp8
//line :177:1
				if tmp7 {








					System_Arraycopy_O_I_O_I_I__V(cb.Ref(), start, cb.Ref(), 0, len_) } }
		var tmp9 int32; limit = len_; tmp9 = limit; pos = tmp9
		start = 0
		break L2 }
//line :159:1
	continue L2 }; break L2 }
//line :157:1
	continue L1 }; break L1
}































	if limit > start { lines.Add_O__Z(String_New_C1_I_I(cb, start, limit-start)) }
	return Collections_UnmodifiableList_List__List(lines)
}
func (t *Reader) Impl_ReadAllAsString__String(this Reader_I) *String {
	var result *StringBuilder = StringBuilder_New(); var cbuf *CharArray = NewCharArray(8192)
	var nread int32 = 0

L1: for { var tmp1 int32; nread = this.Read_C1_I_I__I(cbuf, 0, int32(len(cbuf.A))); tmp1 = nread; if !(tmp1 == -1) {
	NN(result).Append_C1_I_I__StringBuilder(cbuf, 0, nread)
//line :197:1
	continue L1 }; break L1
}
	return NN(result).ToString__String()
}




func (t *Reader) Impl_Skip_J__J(this Reader_I, n int64) int64 {
	if n < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_51))) }
	var tmp1 int64; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var nn int32 = int32(Math_Min_J_J__J(n, 8192)); var tmp3 bool; var tmp4 bool
		tmp4 = t.F_skipBuffer == nil; if !tmp4 { tmp4 = int32(len(t.F_skipBuffer.A)) < nn }; tmp3 = tmp4; if tmp3 { t.F_skipBuffer = NewCharArray(nn) }
		var r int64 = n
	L1: for { if r > 0 {
		var tmp5 *CharArray = t.F_skipBuffer; var nc int32 = this.Read_C1_I_I__I(tmp5, 0, int32(Math_Min_J_J__J(r, int64(nn))))
		if nc == -1 { break L1 }
		r = r - int64(nc)
//line :211:1
		continue L1 }; break L1
	}


		tmp1 = n - r }()
//line :207:1
	return tmp1
}








func (t *Reader) Impl_Ready__Z(this Reader_I) bool { return false }

func (t *Reader) Impl_MarkSupported__Z(this Reader_I) bool { return false }

func (t *Reader) Impl_Mark_I__V(this Reader_I, readAheadLimit int32) {
	panic(Thrown(IOException_New_String(Lit_99)))
}
func (t *Reader) Impl_Reset__V(this Reader_I) {
	panic(Thrown(IOException_New_String(Lit_100)))
}


func (t *Reader) Impl_TransferTo_Writer__J(this Reader_I, out Writer_I) int64 {
	Objects_RequireNonNull_O_String__O(out, Lit_50)
	var transferred int64 = 0; var buffer *CharArray = NewCharArray(8192)
	var nRead int32 = 0

L1: for { var tmp1 int32; nRead = this.Read_C1_I_I__I(buffer, 0, 8192); tmp1 = nRead; if tmp1 >= 0 {
	out.Write_C1_I_I__V(buffer, 0, nRead)
	if transferred < 9223372036854775807 { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

		transferred = Math_AddExact_J_J__J(transferred, int64(nRead)); return nil }()
//line :237:1
		if tmp2 != nil { if ArithmeticException_InstanceOf(tmp2) { var ignore *ArithmeticException = ArithmeticException_Cast(tmp2); _ = ignore

			transferred = 9223372036854775807 } else {
//line :237:1
				panic(tmp2) } } }
//line :234:1
	continue L1 }; break L1 }
//line :231:1
	return transferred
}









type Reader struct{ Object; F_lock any; F_skipBuffer *CharArray }

type Reader_I interface{ Object_I; Closeable; AutoCloseable; Self_Reader() *Reader; Read_CharBuffer__I(p0 CharBuffer_I) int32; Read__I() int32; Read_C1__I(p0 *CharArray) int32; Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32; ReadAllLines__List() List; ReadAllAsString__String() *String; Skip_J__J(p0 int64) int64; Ready__Z() bool; MarkSupported__Z() bool; Mark_I__V(p0 int32); Reset__V(); Close__V(); TransferTo_Writer__J(p0 Writer_I) int64 }

func (t *Reader) Self_Reader() *Reader { return t }

func (t *Reader) Is_Closeable() {}

func (t *Reader) Is_AutoCloseable() {}

const Reader_TRANSFER_BUFFER_SIZE int32 = 8192

const Reader_maxSkipBufferSize int32 = 8192

func Reader_InstanceOf(x any) bool { _, ok := x.(Reader_I); return ok }

func Reader_Cast(x any) Reader_I { if x == nil { return nil }; v, ok := x.(Reader_I); if !ok { panic(ClassCast(x, Reader_class)) }; return v }



type Reader_1 struct{ Reader; F_closed atomic.Bool }

func Reader_1_New() *Reader_1 { t := &Reader_1{}; t.Ctor(); return t }

func (t *Reader_1) Ctor() { t.Reader.Ctor(t) }

func (t *Reader_1) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *Reader_1) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *Reader_1) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *Reader_1) Reset__V() { t.Impl_Reset__V(t) }

func (t *Reader_1) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *Reader_1) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *Reader_1) Ref() any { if t == nil { return nil }; return t }

func (t *Reader_1) GetClass__Class() *Class { return Reader_1_class }

func (t *Reader_1) ToString__String() *String { return Object_toString(t) }

func (t *Reader_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Reader_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Reader_1_InstanceOf(x any) bool { _, ok := x.(*Reader_1); return ok }

func Reader_1_Cast(x any) *Reader_1 { if x == nil { return nil }; v, ok := x.(*Reader_1); if !ok { panic(ClassCast(x, Reader_1_class)) }; return v }



type Reader_2 struct{ Reader; F_isClosed bool; F_next, F_mark int32; F_val_cs CharSequence }

func Reader_2_New_CharSequence(p0 CharSequence) *Reader_2 { t := &Reader_2{}; t.Ctor_CharSequence(p0); return t }

func (t *Reader_2) Ctor_CharSequence(val_cs CharSequence) { t.F_val_cs = val_cs; t.Reader.Ctor(t); t.F_next = 0; t.F_mark = 0 }

func (t *Reader_2) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *Reader_2) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *Reader_2) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *Reader_2) Ref() any { if t == nil { return nil }; return t }

func (t *Reader_2) GetClass__Class() *Class { return Reader_2_class }

func (t *Reader_2) ToString__String() *String { return Object_toString(t) }

func (t *Reader_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Reader_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func Reader_2_InstanceOf(x any) bool { _, ok := x.(*Reader_2); return ok }

func Reader_2_Cast(x any) *Reader_2 { if x == nil { return nil }; v, ok := x.(*Reader_2); if !ok { panic(ClassCast(x, Reader_2_class)) }; return v }
