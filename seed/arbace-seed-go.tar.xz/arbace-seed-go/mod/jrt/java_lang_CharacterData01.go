//line java_lang_CharacterData01.ae:1
package jrt








func (t *CharacterData01) GetProperties_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var tmp1 *IntArray = CharacterData01_A; var tmp2 *CharArray = CharacterData01_Y; var props int32 = tmp1.A[int32(tmp2.A[int32(CharacterData01_X.A[int32(offset)>>5])|int32(offset)>>1&15])|int32(offset)&1]; return props
}







func (t *CharacterData01) GetPropertiesEx_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var tmp1 *CharArray = CharacterData01_B; var tmp2 *CharArray = CharacterData01_Y; var props int32 = int32(tmp1.A[int32(tmp2.A[int32(CharacterData01_X.A[int32(offset)>>5])|int32(offset)>>1&15])|int32(offset)&1]); return props
}







func (t *CharacterData01) GetType_I__I(ch int32) int32 {
	var props int32 = t.GetProperties_I__I(ch); return props & 31
}
func (t *CharacterData01) IsOtherAlphabetic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&4 == 0)
}
func (t *CharacterData01) IsIdeographic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&8 == 0)
}
func (t *CharacterData01) IsJavaIdentifierStart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 >= 20480
}
func (t *CharacterData01) IsJavaIdentifierPart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return !(props&12288 == 0)
}
func (t *CharacterData01) IsUnicodeIdentifierStart_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&16 == 0)
}
func (t *CharacterData01) IsUnicodeIdentifierPart_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = !(t.GetPropertiesEx_I__I(ch)&32 == 0); if !tmp1 {
		tmp1 = t.IsIdentifierIgnorable_I__Z(ch) }
//line :49:1
	return tmp1
}

func (t *CharacterData01) IsIdentifierIgnorable_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 4096
}
func (t *CharacterData01) IsEmoji_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&64 == 0)
}
func (t *CharacterData01) IsEmojiPresentation_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&128 == 0)
}
func (t *CharacterData01) IsEmojiModifier_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&256 == 0)
}
func (t *CharacterData01) IsEmojiModifierBase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&512 == 0)
}
func (t *CharacterData01) IsEmojiComponent_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1024 == 0)
}
func (t *CharacterData01) IsExtendedPictographic_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2048 == 0)
}
func (t *CharacterData01) ToLowerCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if val&131072 == 0 { } else {
		var offset int32 = val << 5 >> 23
		mapChar = ch + offset }
//line :74:1
	return mapChar
}





func (t *CharacterData01) ToUpperCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if val&65536 == 0 { } else {
		var offset int32 = val << 5 >> 23
		mapChar = ch - offset }
//line :82:1
	return mapChar
}





func (t *CharacterData01) ToTitleCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if !(val&32768 == 0) {
		if val&65536 == 0 {
			mapChar = ch + 1 } else {
//line :93:1
				if val&131072 == 0 {

					mapChar = ch - 1 } } } else {
						if val&65536 == 0 { } else { mapChar = t.ToUpperCase_I__I(ch) } }
//line :90:1
	return mapChar
}







func (t *CharacterData01) Digit_I_I__I(ch, radix int32) int32 {
	var value int32 = -1; var tmp1 bool; var tmp2 bool
	tmp2 = radix >= 2; if tmp2 { tmp2 = radix <= 36 }; tmp1 = tmp2; if tmp1 {
		var val int32 = t.GetProperties_I__I(ch); var kind int32 = val & 31

		if kind == 9 {

			value = (ch + val&992>>5) & 31 } else {
//line :104:1
				if val&3072 == 3072 {







					value = (ch+val&992>>5)&31 + 10
				}
			}
	}



	if value < radix { return value } else { return -1
	} }
func (t *CharacterData01) GetNumericValue_I__I(ch int32) int32 {
	var val int32 = t.GetProperties_I__I(ch)
	var retval int32 = -1
	switch val & 3072 { case 1024:

		retval = (ch + val&992>>5) & 31; case 2048:



		switch ch { case 65811:
			retval = 40; case 65812:
			retval = 50; case 65813:
			retval = 60; case 65814:
			retval = 70; case 65815:
			retval = 80; case 65816:
			retval = 90; case 65817:
			retval = 100; case 65818:
			retval = 200; case 65819:
			retval = 300; case 65820:
			retval = 400; case 65821:
			retval = 500; case 65822:
			retval = 600; case 65823:
			retval = 700; case 65824:
			retval = 800; case 65825:
			retval = 900; case 65826:
			retval = 1000; case 65827:
			retval = 2000; case 65828:
			retval = 3000; case 65829:
			retval = 4000; case 65830:
			retval = 5000; case 65831:
			retval = 6000; case 65832:
			retval = 7000; case 65833:
			retval = 8000; case 65834:
			retval = 9000; case 65835:
			retval = 10000; case 65836:
			retval = 20000; case 65837:
			retval = 30000; case 65838:
			retval = 40000; case 65839:
			retval = 50000; case 65840:
			retval = 60000; case 65841:
			retval = 70000; case 65842:
			retval = 80000; case 65843:
			retval = 90000; case 65860:
			retval = 50; case 65861:
			retval = 500; case 65862:
			retval = 5000; case 65863:
			retval = 50000; case 65866:
			retval = 50; case 65867:
			retval = 100; case 65868:
			retval = 500; case 65869:
			retval = 1000; case 65870:
			retval = 5000; case 65873:
			retval = 50; case 65874:
			retval = 100; case 65875:
			retval = 500; case 65876:
			retval = 1000; case 65877:
			retval = 10000; case 65878:
			retval = 50000; case 65894:
			retval = 50; case 65895:
			retval = 50; case 65896:
			retval = 50; case 65897:
			retval = 50; case 65898:
			retval = 100; case 65899:
			retval = 300; case 65900:
			retval = 500; case 65901:
			retval = 500; case 65902:
			retval = 500; case 65903:
			retval = 500; case 65904:
			retval = 500; case 65905:
			retval = 1000; case 65906:
			retval = 5000; case 65908:
			retval = 50; case 66285:
			retval = 40; case 66286:
			retval = 50; case 66287:
			retval = 60; case 66288:
			retval = 70; case 66289:
			retval = 80; case 66290:
			retval = 90; case 66291:
			retval = 100; case 66292:
			retval = 200; case 66293:
			retval = 300; case 66294:
			retval = 400; case 66295:
			retval = 500; case 66296:
			retval = 600; case 66297:
			retval = 700; case 66298:
			retval = 800; case 66299:
			retval = 900; case 66339:
			retval = 50; case 66369:
			retval = 90; case 66378:
			retval = 900; case 66517:
			retval = 100; case 67677:
			retval = 100; case 67678:
			retval = 1000; case 67679:
			retval = 10000; case 67759:
			retval = 100; case 67839:
			retval = 100; case 67865:
			retval = 100; case 68044:
			retval = 40; case 68045:
			retval = 50; case 68046:
			retval = 60; case 68047:
			retval = 70; case 68050:
			retval = 100; case 68051:
			retval = 200; case 68052:
			retval = 300; case 68053:
			retval = 400; case 68054:
			retval = 500; case 68055:
			retval = 600; case 68056:
			retval = 700; case 68057:
			retval = 800; case 68058:
			retval = 900; case 68059:
			retval = 1000; case 68060:
			retval = 2000; case 68061:
			retval = 3000; case 68062:
			retval = 4000; case 68063:
			retval = 5000; case 68064:
			retval = 6000; case 68065:
			retval = 7000; case 68066:
			retval = 8000; case 68067:
			retval = 9000; case 68068:
			retval = 10000; case 68069:
			retval = 20000; case 68070:
			retval = 30000; case 68071:
			retval = 40000; case 68072:
			retval = 50000; case 68073:
			retval = 60000; case 68074:
			retval = 70000; case 68075:
			retval = 80000; case 68076:
			retval = 90000; case 68077:
			retval = 100000; case 68078:
			retval = 200000; case 68079:
			retval = 300000; case 68080:
			retval = 400000; case 68081:
			retval = 500000; case 68082:
			retval = 600000; case 68083:
			retval = 700000; case 68084:
			retval = 800000; case 68085:
			retval = 900000; case 68166:
			retval = 100; case 68167:
			retval = 1000; case 68222:
			retval = 50; case 68335:
			retval = 100; case 68446:
			retval = 100; case 68447:
			retval = 1000; case 68478:
			retval = 100; case 68479:
			retval = 1000; case 68527:
			retval = 100; case 68861:
			retval = 50; case 68862:
			retval = 100; case 68863:
			retval = 1000; case 69228:
			retval = 40; case 69229:
			retval = 50; case 69230:
			retval = 60; case 69231:
			retval = 70; case 69232:
			retval = 80; case 69233:
			retval = 90; case 69234:
			retval = 100; case 69235:
			retval = 200; case 69236:
			retval = 300; case 69237:
			retval = 400; case 69238:
			retval = 500; case 69239:
			retval = 600; case 69240:
			retval = 700; case 69241:
			retval = 800; case 69242:
			retval = 900; case 69413:
			retval = 100; case 69460:
			retval = 100; case 69579:
			retval = 100; case 69726:
			retval = 40; case 69727:
			retval = 50; case 69728:
			retval = 60; case 69729:
			retval = 70; case 69730:
			retval = 80; case 69731:
			retval = 90; case 69732:
			retval = 100; case 69733:
			retval = 1000; case 72806:
			retval = 40; case 72807:
			retval = 50; case 72808:
			retval = 60; case 72809:
			retval = 70; case 72810:
			retval = 80; case 72811:
			retval = 90; case 72812:
			retval = 100; case 70125:
			retval = 40; case 70126:
			retval = 50; case 70127:
			retval = 60; case 70128:
			retval = 70; case 70129:
			retval = 80; case 70130:
			retval = 90; case 70131:
			retval = 100; case 70132:
			retval = 1000; case 71917:
			retval = 40; case 71918:
			retval = 50; case 71919:
			retval = 60; case 71920:
			retval = 70; case 71921:
			retval = 80; case 71922:
			retval = 90; case 74802:
			retval = 216000; case 74803:
			retval = 432000; case 74855:
			retval = 40; case 74856:
			retval = 50; case 93020:
			retval = 100; case 93021:
			retval = 10000; case 93022:
			retval = 1000000; case 93023:
			retval = 100000000; case 119660:
			retval = 40; case 119661:
			retval = 50; case 119662:
			retval = 60; case 119663:
			retval = 70; case 119664:
			retval = 80; case 119665:
			retval = 90; case 126077:
			retval = 40; case 126078:
			retval = 50; case 126079:
			retval = 60; case 126080:
			retval = 70; case 126081:
			retval = 80; case 126082:
			retval = 90; case 126083:
			retval = 100; case 126084:
			retval = 200; case 126085:
			retval = 300; case 126086:
			retval = 400; case 126087:
			retval = 500; case 126088:
			retval = 600; case 126089:
			retval = 700; case 126090:
			retval = 800; case 126091:
			retval = 900; case 126092:
			retval = 1000; case 126093:
			retval = 2000; case 126094:
			retval = 3000; case 126095:
			retval = 4000; case 126096:
			retval = 5000; case 126097:
			retval = 6000; case 126098:
			retval = 7000; case 126099:
			retval = 8000; case 126100:
			retval = 9000; case 126101:
			retval = 10000; case 126102:
			retval = 20000; case 126103:
			retval = 30000; case 126104:
			retval = 40000; case 126105:
			retval = 50000; case 126106:
			retval = 60000; case 126107:
			retval = 70000; case 126108:
			retval = 80000; case 126109:
			retval = 90000; case 126110:
			retval = 100000; case 126111:
			retval = 200000; case 126112:
			retval = 100000; case 126113:
			retval = 10000000; case 126114:
			retval = 20000000; case 126131:
			retval = 10000; case 126132:
			retval = 100000; case 126221:
			retval = 40; case 126222:
			retval = 50; case 126223:
			retval = 60; case 126224:
			retval = 70; case 126225:
			retval = 80; case 126226:
			retval = 90; case 126227:
			retval = 100; case 126228:
			retval = 200; case 126229:
			retval = 300; case 126230:
			retval = 400; case 126231:
			retval = 500; case 126232:
			retval = 600; case 126233:
			retval = 700; case 126234:
			retval = 800; case 126235:
			retval = 900; case 126236:
			retval = 1000; case 126237:
			retval = 2000; case 126238:
			retval = 3000; case 126239:
			retval = 4000; case 126240:
			retval = 5000; case 126241:
			retval = 6000; case 126242:
			retval = 7000; case 126243:
			retval = 8000; case 126244:
			retval = 9000; case 126245:
			retval = 10000; case 126246:
			retval = 20000; case 126247:
			retval = 30000; case 126248:
			retval = 40000; case 126249:
			retval = 50000; case 126250:
			retval = 60000; case 126251:
			retval = 70000; case 126252:
			retval = 80000; case 126253:
			retval = 90000; case 126264:
			retval = 400; case 126265:
			retval = 600; case 126266:
			retval = 2000; case 126267:
			retval = 10000; default:
			retval = -2}; case 3072:

		retval = (ch+val&992>>5)&31 + 10; default:






		retval = -1}
//line :122:1
	return retval
}








































































































































































































































































































func (t *CharacterData01) IsDigit_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch)
	return props&31 == 9
}
func (t *CharacterData01) IsLowerCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1 == 0)
}
func (t *CharacterData01) IsUpperCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2 == 0)
}
func (t *CharacterData01) IsWhitespace_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 16384
}
func (t *CharacterData01) GetDirectionality_I__B(ch int32) int8 {
	var val int32 = t.GetProperties_I__I(ch); var directionality int8 = int8(val & 2013265920 >> 27)


	if int32(directionality) == 15 { directionality = -1 }
//line :434:1
	return directionality
}




func (t *CharacterData01) IsMirrored_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch)
	return !(props&-2147483648 == 0)
}


func CharacterData01_New() *CharacterData01 { CharacterData01_Init(); t := &CharacterData01{}; t.Ctor(); return t }
//line :446:1
func (t *CharacterData01) Ctor() { t.CharacterData.Ctor(t) }





type CharacterData01 struct{ CharacterData }

var CharacterData01_instance CharacterData_I

var CharacterData01_X *CharArray

var CharacterData01_Y *CharArray

var CharacterData01_A *IntArray

var CharacterData01_A_DATA *String = Lit_1101

var CharacterData01_B *CharArray

var CharacterData01_init ClassInit

func CharacterData01_Init() { if !CharacterData01_init.Done() { CharacterData01_init.Run(CharacterData01_clinit) } }

func CharacterData01_clinit() { CharacterData01_instance = CharacterData01_New(); CharacterData01_X = Lit_1098.ToCharArray__C1(); CharacterData01_Y = Lit_1099.ToCharArray__C1(); CharacterData01_A = NewIntArray(710); CharacterData01_B = Lit_1100.ToCharArray__C1()
//line :466:1
	var data *CharArray = Lit_1101.ToCharArray__C1()
	if !A2g_AssertionsDisabled && !(int32(len(data.A)) == 1420) { panic(Thrown(AssertionError_New())) }
	var i int32 = 0
	var j int32 = 0
L1: for { if i < 1420 {
	var entry int32; var tmp1 int32; var old_1 int32 = i
	i = i + 1; tmp1 = old_1
//line :471:1
	entry = int32(data.A[tmp1]) << 16


	var tmp2 *IntArray = CharacterData01_A; tmp2.A[j] = entry | int32(data.A[i])
	j = j + 1
	i = i + 1
//line :470:1
	continue L1 }; break L1
} }
func (t *CharacterData01) ToUpperCaseCharArray_I__C1(p0 int32) *CharArray { return t.Impl_ToUpperCaseCharArray_I__C1(t, p0) }

func (t *CharacterData01) ToUpperCaseEx_I__I(p0 int32) int32 { return t.Impl_ToUpperCaseEx_I__I(t, p0) }

func (t *CharacterData01) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterData01) GetClass__Class() *Class { return CharacterData01_class }

func (t *CharacterData01) ToString__String() *String { return Object_toString(t) }

func (t *CharacterData01) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterData01) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterData01_InstanceOf(x any) bool { _, ok := x.(*CharacterData01); return ok }

func CharacterData01_Cast(x any) *CharacterData01 { if x == nil { return nil }; v, ok := x.(*CharacterData01); if !ok { panic(ClassCast(x, CharacterData01_class)) }; return v }
