//line java_io_BufferedOutputStream.ae:1
package jrt



















func BufferedOutputStream_InitialBufferSize__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = VM_IsBooted__Z(); if tmp2 { tmp2 = Thread_CurrentThread__Thread().IsVirtual__Z() }; tmp1 = tmp2; if tmp1 { return 512 } else { return 8192
	}
}

func BufferedOutputStream_New_OutputStream_I_I(p0 OutputStream_I, p1, p2 int32) *BufferedOutputStream { t := &BufferedOutputStream{}; t.Ctor_OutputStream_I_I(t, p0, p1, p2); return t }
//line :26:1
func (t *BufferedOutputStream) Ctor_OutputStream_I_I(this BufferedOutputStream_I, out OutputStream_I, initialSize, maxSize int32) { t.FilterOutputStream.Ctor_OutputStream(this, out)

	if initialSize <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_47))) }
	if this.GetClass__Class() == BufferedOutputStream_class {
		t.F_buf = NewByteArray(initialSize) } else {
			t.F_buf = NewByteArray(maxSize) }
	t.F_maxBufSize = maxSize
}
func BufferedOutputStream_New_OutputStream(p0 OutputStream_I) *BufferedOutputStream { t := &BufferedOutputStream{}; t.Ctor_OutputStream(t, p0); return t }
//line :34:1
func (t *BufferedOutputStream) Ctor_OutputStream(this BufferedOutputStream_I, out OutputStream_I) { t.Ctor_OutputStream_I_I(this, out, BufferedOutputStream_InitialBufferSize__I(), 8192) }


func BufferedOutputStream_New_OutputStream_I(p0 OutputStream_I, p1 int32) *BufferedOutputStream { t := &BufferedOutputStream{}; t.Ctor_OutputStream_I(t, p0, p1); return t }
//line :37:1
func (t *BufferedOutputStream) Ctor_OutputStream_I(this BufferedOutputStream_I, out OutputStream_I, size int32) { t.Ctor_OutputStream_I_I(this, out, size, size) }


func (t *BufferedOutputStream) Impl_FlushBuffer__V(this BufferedOutputStream_I) {
	if t.F_count > 0 { t.F_out.Write_B1_I_I__V(t.F_buf, 0, t.F_count); t.F_count = 0
	} }
func (t *BufferedOutputStream) Impl_GrowIfNeeded_I__V(this BufferedOutputStream_I, len_ int32) {
	var neededSize int32 = t.F_count + len_ + 1
	if neededSize < 0 { neededSize = 2147483647 }
	var bufSize int32 = int32(len(t.F_buf.A)); var tmp1 bool; var tmp2 bool
	tmp2 = neededSize > bufSize; if tmp2 { tmp2 = bufSize < t.F_maxBufSize }; tmp1 = tmp2; if tmp1 {
		var newSize int32 = Math_Min_I_I__I(neededSize, t.F_maxBufSize); t.F_buf = Arrays_CopyOf_B1_I__B1(t.F_buf, newSize)
	} }
func (t *BufferedOutputStream) Impl_Write_I__V(this BufferedOutputStream_I, b int32) { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_GrowIfNeeded_I__V(this, 1)
	var tmp1 int32 = t.F_count; if tmp1 >= int32(len(t.F_buf.A)) { t.Impl_FlushBuffer__V(this) }
	var tmp2 *ByteArray = t.F_buf; var tmp3 int32; var old_1 int32 = t.F_count; t.F_count = t.F_count + 1; tmp3 = old_1; tmp2.A[tmp3] = int8(b)
}
func (t *BufferedOutputStream) Impl_Write_B1_I_I__V(this BufferedOutputStream_I, b *ByteArray, off, len_ int32) { MonitorEnter(this); defer MonitorExit(this)

	if len_ >= t.F_maxBufSize {
		t.Impl_FlushBuffer__V(this); t.F_out.Write_B1_I_I__V(b, off, len_) } else {

			t.Impl_GrowIfNeeded_I__V(this, len_)
			if len_ > int32(len(t.F_buf.A))-t.F_count { t.Impl_FlushBuffer__V(this) }
			System_Arraycopy_O_I_O_I_I__V(b.Ref(), off, t.F_buf.Ref(), t.F_count, len_)
			t.F_count = t.F_count + len_
		} }
func (t *BufferedOutputStream) Impl_Flush__V(this BufferedOutputStream_I) { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_FlushBuffer__V(this)
	t.F_out.Flush__V()
}


type BufferedOutputStream struct{ FilterOutputStream; F_buf *ByteArray; F_count, F_maxBufSize int32 }

type BufferedOutputStream_I interface{ FilterOutputStream_I; Closeable; Flushable; AutoCloseable; Self_BufferedOutputStream() *BufferedOutputStream; Write_I__V(p0 int32); Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32); Flush__V() }

func (t *BufferedOutputStream) Self_BufferedOutputStream() *BufferedOutputStream { return t }

const BufferedOutputStream_DEFAULT_INITIAL_BUFFER_SIZE int32 = 512

const BufferedOutputStream_DEFAULT_MAX_BUFFER_SIZE int32 = 8192

func (t *BufferedOutputStream) Write_I__V(p0 int32) { t.Impl_Write_I__V(t, p0) }

func (t *BufferedOutputStream) Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_Write_B1_I_I__V(t, p0, p1, p2) }

func (t *BufferedOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *BufferedOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *BufferedOutputStream) Close__V() { t.Impl_Close__V(t) }

func (t *BufferedOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *BufferedOutputStream) GetClass__Class() *Class { return BufferedOutputStream_class }

func (t *BufferedOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *BufferedOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BufferedOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func BufferedOutputStream_InstanceOf(x any) bool { _, ok := x.(BufferedOutputStream_I); return ok }

func BufferedOutputStream_Cast(x any) BufferedOutputStream_I { if x == nil { return nil }; v, ok := x.(BufferedOutputStream_I); if !ok { panic(ClassCast(x, BufferedOutputStream_class)) }; return v }
