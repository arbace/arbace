//line java_util_DuplicateFormatFlagsException.ae:1
package jrt










func DuplicateFormatFlagsException_New_String(p0 *String) *DuplicateFormatFlagsException { t := &DuplicateFormatFlagsException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *DuplicateFormatFlagsException) Ctor_String(f *String) { t.IllegalFormatException.Ctor(t)
	if f == nil { panic(Thrown(NullPointerException_New())) }
	t.F_flags = f
}
func (t *DuplicateFormatFlagsException) GetFlags__String() *String { return t.F_flags }

func (t *DuplicateFormatFlagsException) GetMessage__String() *String {
	return String_Format_String_O1__String(Lit_2666, RefArrayOf(Object_class, t.F_flags.Ref()))
}


type DuplicateFormatFlagsException struct{ IllegalFormatException; F_flags *String }

const DuplicateFormatFlagsException_serialVersionUID int64 = 18890531

func (t *DuplicateFormatFlagsException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *DuplicateFormatFlagsException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *DuplicateFormatFlagsException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *DuplicateFormatFlagsException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *DuplicateFormatFlagsException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *DuplicateFormatFlagsException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *DuplicateFormatFlagsException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *DuplicateFormatFlagsException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *DuplicateFormatFlagsException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *DuplicateFormatFlagsException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *DuplicateFormatFlagsException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DuplicateFormatFlagsException) Ref() any { if t == nil { return nil }; return t }

func (t *DuplicateFormatFlagsException) GetClass__Class() *Class { return DuplicateFormatFlagsException_class }

func (t *DuplicateFormatFlagsException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DuplicateFormatFlagsException) CloneShallow() any { panic(CloneNotSupported(t)) }

func DuplicateFormatFlagsException_InstanceOf(x any) bool { _, ok := x.(*DuplicateFormatFlagsException); return ok }

func DuplicateFormatFlagsException_Cast(x any) *DuplicateFormatFlagsException { if x == nil { return nil }; v, ok := x.(*DuplicateFormatFlagsException); if !ok { panic(ClassCast(x, DuplicateFormatFlagsException_class)) }; return v }
