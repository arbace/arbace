//line java_text_Normalizer.ae:1
package jrt






func Normalizer_New() *Normalizer { t := &Normalizer{}; t.Ctor(); return t }
//line :8:1
func (t *Normalizer) Ctor() { panic(A2g_NotTranslated("java.text.Normalizer.<init>()V")) }




func Normalizer_Normalize_CharSequence_Normalizer_Form__String(src CharSequence, form *Normalizer_Form) *String {
	return NormalizerBase_Normalize_String_Normalizer_Form__String(src.ToString__String(), form)
}
func Normalizer_IsNormalized_CharSequence_Normalizer_Form__Z(src CharSequence, form *Normalizer_Form) bool {
	return NormalizerBase_IsNormalized_String_Normalizer_Form__Z(src.ToString__String(), form)
}


type Normalizer struct{ Object }

func (t *Normalizer) Ref() any { if t == nil { return nil }; return t }

func (t *Normalizer) GetClass__Class() *Class { return Normalizer_class }

func (t *Normalizer) ToString__String() *String { return Object_toString(t) }

func (t *Normalizer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Normalizer) CloneShallow() any { panic(CloneNotSupported(t)) }

func Normalizer_InstanceOf(x any) bool { _, ok := x.(*Normalizer); return ok }

func Normalizer_Cast(x any) *Normalizer { if x == nil { return nil }; v, ok := x.(*Normalizer); if !ok { panic(ClassCast(x, Normalizer_class)) }; return v }



type Normalizer_Form struct{ Enum }

func (t *Normalizer_Form) Is_Constable() {}

var Normalizer_Form_NFD *Normalizer_Form

var Normalizer_Form_NFC *Normalizer_Form

var Normalizer_Form_NFKD *Normalizer_Form

var Normalizer_Form_NFKC *Normalizer_Form

var Normalizer_Form__VALUES *RefArray

var Normalizer_Form_init ClassInit

func Normalizer_Form_Init() { if !Normalizer_Form_init.Done() { Normalizer_Form_init.Run(Normalizer_Form_clinit) } }

func Normalizer_Form_clinit() { Normalizer_Form_NFD = Normalizer_Form_New_String_I(Lit_1946, 0); Normalizer_Form_NFC = Normalizer_Form_New_String_I(Lit_1947, 1); Normalizer_Form_NFKD = Normalizer_Form_New_String_I(Lit_1948, 2); Normalizer_Form_NFKC = Normalizer_Form_New_String_I(Lit_1949, 3); Normalizer_Form__VALUES = Normalizer_Form_X_values__Normalizer_Form1() }

func Normalizer_Form_New_String_I(p0 *String, p1 int32) *Normalizer_Form { Normalizer_Form_Init(); t := &Normalizer_Form{}; t.Ctor_String_I(p0, p1); return t }

func (t *Normalizer_Form) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Normalizer_Form_Values__Normalizer_Form1() *RefArray { Normalizer_Form_Init(); return Normalizer_Form__VALUES.Copy() }

func Normalizer_Form_ValueOf_String__Normalizer_Form(p0 *String) *Normalizer_Form { Normalizer_Form_Init(); return Normalizer_Form_Cast(Enum_ValueOf_Class_String__Enum(Normalizer_Form_class, p0)) }

func Normalizer_Form_X_values__Normalizer_Form1() *RefArray { Normalizer_Form_Init(); return RefArrayOf(Normalizer_Form_class, Normalizer_Form_NFD, Normalizer_Form_NFC, Normalizer_Form_NFKD, Normalizer_Form_NFKC) }

func (t *Normalizer_Form) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Normalizer_Form) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Normalizer_Form) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Normalizer_Form) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.text.Normalizer$Form.describeConstable()Ljava/util/Optional;")) }

func (t *Normalizer_Form) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Normalizer_Form) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Normalizer_Form) Ref() any { if t == nil { return nil }; return t }

func (t *Normalizer_Form) GetClass__Class() *Class { return Normalizer_Form_class }

func (t *Normalizer_Form) CloneShallow() any { panic(CloneNotSupported(t)) }

func Normalizer_Form_InstanceOf(x any) bool { _, ok := x.(*Normalizer_Form); return ok }

func Normalizer_Form_Cast(x any) *Normalizer_Form { if x == nil { return nil }; v, ok := x.(*Normalizer_Form); if !ok { panic(ClassCast(x, Normalizer_Form_class)) }; return v }
