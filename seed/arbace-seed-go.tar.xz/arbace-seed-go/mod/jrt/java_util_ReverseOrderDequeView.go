//line java_util_ReverseOrderDequeView.ae:1
package jrt













func ReverseOrderDequeView_New_Deque(p0 Deque) *ReverseOrderDequeView { t := &ReverseOrderDequeView{}; t.Ctor_Deque(p0); return t }
//line :15:1
func (t *ReverseOrderDequeView) Ctor_Deque(deque Deque) { t.F_base = deque }

func ReverseOrderDequeView_Of_Deque__Deque(deque Deque) Deque {
	var tmp1 Deque = deque; if ReverseOrderDequeView_InstanceOf(tmp1) { var rodv *ReverseOrderDequeView = ReverseOrderDequeView_Cast(tmp1)
		return rodv.F_base } else {
			return ReverseOrderDequeView_New_Deque(deque)
		} }
func (t *ReverseOrderDequeView) ForEach_Consumer__V(action Consumer) {
	var i_102007 Iterator = t.Iterator__Iterator(); for i_102007.HasNext__Z() { var e any = i_102007.Next__O(); action.Accept_O__V(e)
	} }
func (t *ReverseOrderDequeView) Iterator__Iterator() Iterator {
	return t.F_base.DescendingIterator__Iterator()
}
func (t *ReverseOrderDequeView) Spliterator__Spliterator() Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(t, 16)
}
func (t *ReverseOrderDequeView) Add_O__Z(e any) bool { t.F_base.AddFirst_O__V(e); return true }

func (t *ReverseOrderDequeView) AddAll_Collection__Z(c Collection) bool {
	var modified bool = false; var i_102008 Iterator = c.Iterator__Iterator(); for i_102008.HasNext__Z() {
		var e any = i_102008.Next__O(); t.F_base.AddFirst_O__V(e); modified = true }
//line :34:1
	return modified
}


func (t *ReverseOrderDequeView) Clear__V() { t.F_base.Clear__V() }

func (t *ReverseOrderDequeView) Contains_O__Z(o any) bool { return t.F_base.Contains_O__Z(o) }

func (t *ReverseOrderDequeView) ContainsAll_Collection__Z(c Collection) bool {
	return t.F_base.ContainsAll_Collection__Z(c)
}
func (t *ReverseOrderDequeView) IsEmpty__Z() bool { return t.F_base.IsEmpty__Z() }

func (t *ReverseOrderDequeView) ParallelStream__Stream() Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(t.Spliterator__Spliterator(), true)
}
func (t *ReverseOrderDequeView) Remove_O__Z(o any) bool {
	var it Iterator = t.Iterator__Iterator()
	if o == nil {
	L1: for { if it.HasNext__Z() { if it.Next__O() == nil { it.Remove__V(); return true }; continue L1 }; break L1 } } else {
	L2: for { if it.HasNext__Z() { if Equals(o, it.Next__O()) { it.Remove__V(); return true }; continue L2 }; break L2 } }
//line :51:1
	return false
}




func (t *ReverseOrderDequeView) RemoveAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var it Iterator = t.Iterator__Iterator()

L1: for { if it.HasNext__Z() { if c.Contains_O__Z(it.Next__O()) { it.Remove__V(); modified = true }; continue L1 }; break L1 }
//line :59:1
	return modified
}



func (t *ReverseOrderDequeView) RetainAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var it Iterator = t.Iterator__Iterator()

L1: for { if it.HasNext__Z() { if c.Contains_O__Z(it.Next__O()) { } else { it.Remove__V(); modified = true }; continue L1 }; break L1 }
//line :66:1
	return modified
}



func (t *ReverseOrderDequeView) Size__I() int32 { return t.F_base.Size__I() }

func (t *ReverseOrderDequeView) Stream__Stream() Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(t.Spliterator__Spliterator(), false)
}
func (t *ReverseOrderDequeView) ToArray__O1() *RefArray {
	return ArraysSupport_Reverse_O1__O1(t.F_base.ToArray__O1())
}
func (t *ReverseOrderDequeView) ToArray_O1__O1(a *RefArray) *RefArray {
	return ArraysSupport_ToArrayReversed_Collection_O1__O1(t.F_base, a)
}
func (t *ReverseOrderDequeView) ToArray_IntFunction__O1(generator IntFunction) *RefArray {
	return ArraysSupport_Reverse_O1__O1(t.F_base.ToArray_IntFunction__O1(generator))
}
func (t *ReverseOrderDequeView) ToString__String() *String {
	{ var it Iterator = t.Iterator__Iterator()
		if !it.HasNext__Z() { return Lit_2589 } else {

			var sb *StringBuilder = StringBuilder_New()
			NN(sb).Append_C__StringBuilder(91)
		L1: for {
			var e any = it.Next__O(); var tmp1 any
			if any(e) == any(t) { tmp1 = Lit_2590 } else { tmp1 = e }; NN(sb).Append_O__StringBuilder(tmp1)
			if it.HasNext__Z() { } else { return NN(NN(sb).Append_C__StringBuilder(93)).ToString__String() }
			NN(NN(sb).Append_C__StringBuilder(44)).Append_C__StringBuilder(32)
//line :91:1
			continue L1
		}
		}
	}
	panic("a2g: unreachable")
}
func (t *ReverseOrderDequeView) AddFirst_O__V(e any) { t.F_base.AddLast_O__V(e) }

func (t *ReverseOrderDequeView) AddLast_O__V(e any) { t.F_base.AddFirst_O__V(e) }

func (t *ReverseOrderDequeView) DescendingIterator__Iterator() Iterator {
	return t.F_base.Iterator__Iterator()
}
func (t *ReverseOrderDequeView) Element__O() any { return t.F_base.GetLast__O() }

func (t *ReverseOrderDequeView) GetFirst__O() any { return t.F_base.GetLast__O() }

func (t *ReverseOrderDequeView) GetLast__O() any { return t.F_base.GetFirst__O() }

func (t *ReverseOrderDequeView) Offer_O__Z(e any) bool { return t.F_base.OfferFirst_O__Z(e) }

func (t *ReverseOrderDequeView) OfferFirst_O__Z(e any) bool { return t.F_base.OfferLast_O__Z(e) }

func (t *ReverseOrderDequeView) OfferLast_O__Z(e any) bool { return t.F_base.OfferFirst_O__Z(e) }

func (t *ReverseOrderDequeView) Peek__O() any { return t.F_base.PeekLast__O() }

func (t *ReverseOrderDequeView) PeekFirst__O() any { return t.F_base.PeekLast__O() }

func (t *ReverseOrderDequeView) PeekLast__O() any { return t.F_base.PeekFirst__O() }

func (t *ReverseOrderDequeView) Poll__O() any { return t.F_base.PollLast__O() }

func (t *ReverseOrderDequeView) PollFirst__O() any { return t.F_base.PollLast__O() }

func (t *ReverseOrderDequeView) PollLast__O() any { return t.F_base.PollFirst__O() }

func (t *ReverseOrderDequeView) Pop__O() any { return t.F_base.RemoveLast__O() }

func (t *ReverseOrderDequeView) Push_O__V(e any) { t.F_base.AddLast_O__V(e) }

func (t *ReverseOrderDequeView) Remove__O() any { return t.F_base.RemoveLast__O() }

func (t *ReverseOrderDequeView) RemoveFirst__O() any { return t.F_base.RemoveLast__O() }

func (t *ReverseOrderDequeView) RemoveLast__O() any { return t.F_base.RemoveFirst__O() }

func (t *ReverseOrderDequeView) RemoveFirstOccurrence_O__Z(o any) bool {
	return t.F_base.RemoveLastOccurrence_O__Z(o)
}
func (t *ReverseOrderDequeView) RemoveLastOccurrence_O__Z(o any) bool {
	return t.F_base.RemoveFirstOccurrence_O__Z(o)
}


type ReverseOrderDequeView struct{ Object; F_base Deque }

func (t *ReverseOrderDequeView) Is_Deque() {}

func (t *ReverseOrderDequeView) Is_Queue() {}

func (t *ReverseOrderDequeView) Is_SequencedCollection() {}

func (t *ReverseOrderDequeView) Is_Collection() {}

func (t *ReverseOrderDequeView) Is_Iterable() {}

func (t *ReverseOrderDequeView) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderDequeView) Reversed__SequencedCollection() SequencedCollection { return Deque_Reversed__SequencedCollection(t) }

func (t *ReverseOrderDequeView) Reversed__Deque() Deque { return Deque_Reversed__Deque(t) }

func (t *ReverseOrderDequeView) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderDequeView) GetClass__Class() *Class { return ReverseOrderDequeView_class }

func (t *ReverseOrderDequeView) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderDequeView) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderDequeView_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderDequeView); return ok }

func ReverseOrderDequeView_Cast(x any) *ReverseOrderDequeView { if x == nil { return nil }; v, ok := x.(*ReverseOrderDequeView); if !ok { panic(ClassCast(x, ReverseOrderDequeView_class)) }; return v }
