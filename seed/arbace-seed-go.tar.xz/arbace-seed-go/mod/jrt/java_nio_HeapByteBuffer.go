//line java_nio_HeapByteBuffer.ae:1
package jrt


















func HeapByteBuffer_New_I_I_MemorySegment(p0, p1 int32, p2 MemorySegment) *HeapByteBuffer { HeapByteBuffer_Init(); t := &HeapByteBuffer{}; t.Ctor_I_I_MemorySegment(p0, p1, p2); return t }
//line :20:1
func (t *HeapByteBuffer) Ctor_I_I_MemorySegment(cap_, lim int32, segment MemorySegment) { t.ByteBuffer.Ctor_I_I_I_I_B1_I_MemorySegment(t, -1, 0, lim, cap_, NewByteArray(cap_), 0, segment)

	t.F_address = HeapByteBuffer_ARRAY_BASE_OFFSET
}
func HeapByteBuffer_New_B1_I_I_MemorySegment(p0 *ByteArray, p1, p2 int32, p3 MemorySegment) *HeapByteBuffer { HeapByteBuffer_Init(); t := &HeapByteBuffer{}; t.Ctor_B1_I_I_MemorySegment(p0, p1, p2, p3); return t }
//line :24:1
func (t *HeapByteBuffer) Ctor_B1_I_I_MemorySegment(buf *ByteArray, off, len_ int32, segment MemorySegment) { t.ByteBuffer.Ctor_I_I_I_I_B1_I_MemorySegment(t, -1, off, off+len_, int32(len(buf.A)), buf, 0, segment)

	t.F_address = HeapByteBuffer_ARRAY_BASE_OFFSET
}
func HeapByteBuffer_New_B1_I_I_I_I_I_MemorySegment(p0 *ByteArray, p1, p2, p3, p4, p5 int32, p6 MemorySegment) *HeapByteBuffer { HeapByteBuffer_Init(); t := &HeapByteBuffer{}; t.Ctor_B1_I_I_I_I_I_MemorySegment(p0, p1, p2, p3, p4, p5, p6); return t }
//line :28:1
func (t *HeapByteBuffer) Ctor_B1_I_I_I_I_I_MemorySegment(buf *ByteArray, mark, pos, lim, cap_, off int32, segment MemorySegment) { t.ByteBuffer.Ctor_I_I_I_I_B1_I_MemorySegment(t, mark, pos, lim, cap_, buf, off, segment)


	t.F_address = HeapByteBuffer_ARRAY_BASE_OFFSET + int64(off)*HeapByteBuffer_ARRAY_INDEX_SCALE
}

func (t *HeapByteBuffer) Slice__ByteBuffer() ByteBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32

	if pos <= lim { rem = lim - pos } else { rem = 0 }
	return HeapByteBuffer_New_B1_I_I_I_I_I_MemorySegment(t.F_hb, -1, 0, rem, rem, pos+t.F_offset, t.F_segment)
}






func (t *HeapByteBuffer) Slice_I_I__ByteBuffer(index, length int32) ByteBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	return HeapByteBuffer_New_B1_I_I_I_I_I_MemorySegment(t.F_hb, -1, 0, length, length, index+t.F_offset, t.F_segment)
}






func (t *HeapByteBuffer) Duplicate__ByteBuffer() ByteBuffer_I {
	var tmp1 *ByteArray = t.F_hb; return HeapByteBuffer_New_B1_I_I_I_I_I_MemorySegment(tmp1, t.MarkValue__I(), t.Position__I(), t.Limit__I(), t.Capacity__I(), t.F_offset, t.F_segment)
}






func (t *HeapByteBuffer) AsReadOnlyBuffer__ByteBuffer() ByteBuffer_I {
	return A2g_Missing[ByteBuffer_I]("class java.nio.HeapByteBufferR is not in the closed world")
}






func (t *HeapByteBuffer) Ix_I__I(i int32) int32 {
	return i + t.F_offset
}
func (t *HeapByteBuffer) ByteOffset_J__J(i int64) int64 {
	return t.F_address + i
}
func (t *HeapByteBuffer) Get__B() int8 {
	var tmp1 *ByteArray = t.F_hb; return tmp1.A[t.Ix_I__I(t.NextGetIndex__I())]
}
func (t *HeapByteBuffer) Get_I__B(i int32) int8 {
	var tmp1 *ByteArray = t.F_hb; return tmp1.A[t.Ix_I__I(t.CheckIndex_I__I(i))]
}
func (t *HeapByteBuffer) Get_B1_I_I__ByteBuffer(dst *ByteArray, offset, length int32) ByteBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var pos int32 = t.Position__I()
	if length > t.Limit__I()-pos {
		panic(Thrown(BufferUnderflowException_New())) }
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, t.Ix_I__I(pos), dst.Ref(), offset, length)
	t.Position_I__ByteBuffer(pos + length)
//line :89:1
	return t
}





func (t *HeapByteBuffer) Get_I_B1_I_I__ByteBuffer(index int32, dst *ByteArray, offset, length int32) ByteBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, t.Ix_I__I(index), dst.Ref(), offset, length)
//line :96:1
	return t
}





func (t *HeapByteBuffer) IsDirect__Z() bool { return false }

func (t *HeapByteBuffer) IsReadOnly__Z() bool { return false }

func (t *HeapByteBuffer) Put_B__ByteBuffer(x int8) ByteBuffer_I {
	var tmp1 *ByteArray = t.F_hb; tmp1.A[t.Ix_I__I(t.NextPutIndex__I())] = x
//line :107:1
	return t
}


func (t *HeapByteBuffer) Put_I_B__ByteBuffer(i int32, x int8) ByteBuffer_I {
	var tmp1 *ByteArray = t.F_hb; tmp1.A[t.Ix_I__I(t.CheckIndex_I__I(i))] = x
//line :111:1
	return t
}


func (t *HeapByteBuffer) Put_B1_I_I__ByteBuffer(src *ByteArray, offset, length int32) ByteBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var pos int32 = t.Position__I()
	if length > t.Limit__I()-pos {
		panic(Thrown(BufferOverflowException_New())) }
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(src.Ref(), offset, tmp1, t.Ix_I__I(pos), length)
	t.Position_I__ByteBuffer(pos + length)
//line :118:1
	return t
}





func (t *HeapByteBuffer) Put_ByteBuffer__ByteBuffer(src ByteBuffer_I) ByteBuffer_I {
	t.CheckSession__V()
	t.ByteBuffer.Impl_Put_ByteBuffer__ByteBuffer(t, src)
//line :125:1
	return t
}



func (t *HeapByteBuffer) Put_I_ByteBuffer_I_I__ByteBuffer(index int32, src ByteBuffer_I, offset, length int32) ByteBuffer_I {
	t.CheckSession__V()
	t.ByteBuffer.Impl_Put_I_ByteBuffer_I_I__ByteBuffer(t, index, src, offset, length)
//line :130:1
	return t
}



func (t *HeapByteBuffer) Put_I_B1_I_I__ByteBuffer(index int32, src *ByteArray, offset, length int32) ByteBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(src.Ref(), offset, tmp1, t.Ix_I__I(index), length)
//line :135:1
	return t
}





func (t *HeapByteBuffer) Compact__ByteBuffer() ByteBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I()

	if !A2g_AssertionsDisabled && !(pos <= lim) { panic(Thrown(AssertionError_New())) }
	var rem int32; if pos <= lim { rem = lim - pos } else { rem = 0 }
	var tmp1 any = t.F_hb.Ref(); var tmp2 int32 = t.Ix_I__I(pos); var tmp3 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, tmp2, tmp3, t.Ix_I__I(0), rem)
	t.Position_I__ByteBuffer(rem)
	t.Limit_I__ByteBuffer(t.Capacity__I())
	t.DiscardMark__V()
//line :146:1
	return t
}





func (t *HeapByteBuffer) X_get_I__B(p0 int32) int8 { panic(A2g_NotTranslated("java.nio.HeapByteBuffer._get(I)B")) }

func (t *HeapByteBuffer) X_put_I_B__V(p0 int32, p1 int8) { panic(A2g_NotTranslated("java.nio.HeapByteBuffer._put(IB)V")) }

func (t *HeapByteBuffer) GetChar__C() uint16 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetCharUnaligned_MemorySessionImpl_O_J_Z__C(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex_I__I(2))), t.F_bigEndian)
}




func (t *HeapByteBuffer) GetChar_I__C(i int32) uint16 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetCharUnaligned_MemorySessionImpl_O_J_Z__C(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 2))), t.F_bigEndian)
}




func (t *HeapByteBuffer) PutChar_C__ByteBuffer(x uint16) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutCharUnaligned_MemorySessionImpl_O_J_C_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex_I__I(2))), x, t.F_bigEndian)
//line :171:1
	return t
}







func (t *HeapByteBuffer) PutChar_I_C__ByteBuffer(i int32, x uint16) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutCharUnaligned_MemorySessionImpl_O_J_C_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 2))), x, t.F_bigEndian)
//line :180:1
	return t
}







func (t *HeapByteBuffer) AsCharBuffer__CharBuffer() CharBuffer_I {
	var pos int32 = t.Position__I(); var size int32 = (t.Limit__I() - pos) >> 1; var addr int64 = t.F_address + int64(pos)


	if t.F_bigEndian {
		return ByteBufferAsCharBufferB_New_ByteBuffer_I_I_I_I_J_MemorySegment(t, -1, 0, size, size, addr, t.F_segment) } else {
			return ByteBufferAsCharBufferL_New_ByteBuffer_I_I_I_I_J_MemorySegment(t, -1, 0, size, size, addr, t.F_segment)
		} }
func (t *HeapByteBuffer) GetShort__S() int16 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetShortUnaligned_MemorySessionImpl_O_J_Z__S(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex_I__I(2))), t.F_bigEndian)
}




func (t *HeapByteBuffer) GetShort_I__S(i int32) int16 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetShortUnaligned_MemorySessionImpl_O_J_Z__S(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 2))), t.F_bigEndian)
}




func (t *HeapByteBuffer) PutShort_S__ByteBuffer(x int16) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutShortUnaligned_MemorySessionImpl_O_J_S_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex_I__I(2))), x, t.F_bigEndian)
//line :211:1
	return t
}







func (t *HeapByteBuffer) PutShort_I_S__ByteBuffer(i int32, x int16) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutShortUnaligned_MemorySessionImpl_O_J_S_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 2))), x, t.F_bigEndian)
//line :220:1
	return t
}















func (t *HeapByteBuffer) GetInt__I() int32 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetIntUnaligned_MemorySessionImpl_O_J_Z__I(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex_I__I(4))), t.F_bigEndian)
}




func (t *HeapByteBuffer) GetInt_I__I(i int32) int32 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetIntUnaligned_MemorySessionImpl_O_J_Z__I(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 4))), t.F_bigEndian)
}




func (t *HeapByteBuffer) PutInt_I__ByteBuffer(x int32) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutIntUnaligned_MemorySessionImpl_O_J_I_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex_I__I(4))), x, t.F_bigEndian)
//line :251:1
	return t
}







func (t *HeapByteBuffer) PutInt_I_I__ByteBuffer(i, x int32) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutIntUnaligned_MemorySessionImpl_O_J_I_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 4))), x, t.F_bigEndian)
//line :260:1
	return t
}







func (t *HeapByteBuffer) AsIntBuffer__IntBuffer() IntBuffer_I {
	var pos int32 = t.Position__I(); var size int32 = (t.Limit__I() - pos) >> 2; var addr int64 = t.F_address + int64(pos)


	if t.F_bigEndian {
		return ByteBufferAsIntBufferB_New_ByteBuffer_I_I_I_I_J_MemorySegment(t, -1, 0, size, size, addr, t.F_segment) } else {
			return ByteBufferAsIntBufferL_New_ByteBuffer_I_I_I_I_J_MemorySegment(t, -1, 0, size, size, addr, t.F_segment)
		} }
func (t *HeapByteBuffer) GetLong__J() int64 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetLongUnaligned_MemorySessionImpl_O_J_Z__J(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex_I__I(8))), t.F_bigEndian)
}




func (t *HeapByteBuffer) GetLong_I__J(i int32) int64 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); return NN(tmp1).GetLongUnaligned_MemorySessionImpl_O_J_Z__J(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 8))), t.F_bigEndian)
}




func (t *HeapByteBuffer) PutLong_J__ByteBuffer(x int64) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutLongUnaligned_MemorySessionImpl_O_J_J_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex_I__I(8))), x, t.F_bigEndian)
//line :291:1
	return t
}







func (t *HeapByteBuffer) PutLong_I_J__ByteBuffer(i int32, x int64) ByteBuffer_I {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); NN(tmp1).PutLongUnaligned_MemorySessionImpl_O_J_J_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 8))), x, t.F_bigEndian)
//line :300:1
	return t
}















func (t *HeapByteBuffer) GetFloat__F() float32 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); var x int32 = NN(tmp1).GetIntUnaligned_MemorySessionImpl_O_J_Z__I(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex_I__I(4))), t.F_bigEndian)




	return Float_IntBitsToFloat_I__F(x)
}
func (t *HeapByteBuffer) GetFloat_I__F(i int32) float32 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); var x int32 = NN(tmp1).GetIntUnaligned_MemorySessionImpl_O_J_Z__I(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 4))), t.F_bigEndian)




	return Float_IntBitsToFloat_I__F(x)
}
func (t *HeapByteBuffer) PutFloat_F__ByteBuffer(x float32) ByteBuffer_I {
	var y int32 = Float_FloatToRawIntBits_F__I(x); var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref()
	NN(tmp1).PutIntUnaligned_MemorySessionImpl_O_J_I_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex_I__I(4))), y, t.F_bigEndian)
//line :334:1
	return t
}







func (t *HeapByteBuffer) PutFloat_I_F__ByteBuffer(i int32, x float32) ByteBuffer_I {
	var y int32 = Float_FloatToRawIntBits_F__I(x); var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref()
	NN(tmp1).PutIntUnaligned_MemorySessionImpl_O_J_I_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 4))), y, t.F_bigEndian)
//line :344:1
	return t
}















func (t *HeapByteBuffer) GetDouble__D() float64 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); var x int64 = NN(tmp1).GetLongUnaligned_MemorySessionImpl_O_J_Z__J(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex_I__I(8))), t.F_bigEndian)




	return Double_LongBitsToDouble_J__D(x)
}
func (t *HeapByteBuffer) GetDouble_I__D(i int32) float64 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref(); var x int64 = NN(tmp1).GetLongUnaligned_MemorySessionImpl_O_J_Z__J(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 8))), t.F_bigEndian)




	return Double_LongBitsToDouble_J__D(x)
}
func (t *HeapByteBuffer) PutDouble_D__ByteBuffer(x float64) ByteBuffer_I {
	var y int64 = Double_DoubleToRawLongBits_D__J(x); var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref()
	NN(tmp1).PutLongUnaligned_MemorySessionImpl_O_J_J_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex_I__I(8))), y, t.F_bigEndian)
//line :378:1
	return t
}







func (t *HeapByteBuffer) PutDouble_I_D__ByteBuffer(i int32, x float64) ByteBuffer_I {
	var y int64 = Double_DoubleToRawLongBits_D__J(x); var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_hb.Ref()
	NN(tmp1).PutLongUnaligned_MemorySessionImpl_O_J_J_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I_I__I(i, 8))), y, t.F_bigEndian)
//line :388:1
	return t
}















func (t *HeapByteBuffer) ScaleShifts__I() int32 { panic(A2g_NotTranslated("java.nio.HeapByteBuffer.scaleShifts()I")) }



type HeapByteBuffer struct{ ByteBuffer }

var HeapByteBuffer_ARRAY_BASE_OFFSET int64

var HeapByteBuffer_ARRAY_INDEX_SCALE int64

var HeapByteBuffer_init ClassInit

func HeapByteBuffer_Init() { if !HeapByteBuffer_init.Done() { HeapByteBuffer_init.Run(HeapByteBuffer_clinit) } }

func HeapByteBuffer_clinit() { ByteBuffer_Init(); HeapByteBuffer_ARRAY_BASE_OFFSET = NN(Buffer_UNSAFE).ArrayBaseOffset_Class__J(Prim_byte.ArrayClass()); HeapByteBuffer_ARRAY_INDEX_SCALE = int64(NN(Buffer_UNSAFE).ArrayIndexScale_Class__I(Prim_byte.ArrayClass())) }

func (t *HeapByteBuffer) Slice__Buffer() Buffer_I { return t.Slice__ByteBuffer() }

func (t *HeapByteBuffer) Slice_I_I__Buffer(p0, p1 int32) Buffer_I { return t.Slice_I_I__ByteBuffer(p0, p1) }

func (t *HeapByteBuffer) Duplicate__Buffer() Buffer_I { return t.Duplicate__ByteBuffer() }

func (t *HeapByteBuffer) Order_ByteOrder__ByteBuffer(p0 *ByteOrder) ByteBuffer_I { return t.Impl_Order_ByteOrder__ByteBuffer(t, p0) }

func (t *HeapByteBuffer) Reset__ByteBuffer() ByteBuffer_I { return t.Impl_Reset__ByteBuffer(t) }

func (t *HeapByteBuffer) AlignedSlice_I__ByteBuffer(p0 int32) ByteBuffer_I { return t.Impl_AlignedSlice_I__ByteBuffer(t, p0) }

func (t *HeapByteBuffer) Array__B1() *ByteArray { return t.Impl_Array__B1(t) }

func (t *HeapByteBuffer) CompareTo_ByteBuffer__I(p0 ByteBuffer_I) int32 { return t.Impl_CompareTo_ByteBuffer__I(t, p0) }

func (t *HeapByteBuffer) Array__O() any { return t.Impl_Array__O(t) }

func (t *HeapByteBuffer) Position_I__ByteBuffer(p0 int32) ByteBuffer_I { return t.Impl_Position_I__ByteBuffer(t, p0) }

func (t *HeapByteBuffer) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *HeapByteBuffer) NextGetIndex__I() int32 { return t.Impl_NextGetIndex__I(t) }

func (t *HeapByteBuffer) Clear__Buffer() Buffer_I { return t.Impl_Clear__Buffer(t) }

func (t *HeapByteBuffer) Mismatch_ByteBuffer__I(p0 ByteBuffer_I) int32 { return t.Impl_Mismatch_ByteBuffer__I(t, p0) }

func (t *HeapByteBuffer) Session__MemorySessionImpl() MemorySessionImpl_I { return t.Impl_Session__MemorySessionImpl(t) }

func (t *HeapByteBuffer) Order__ByteOrder() *ByteOrder { return t.Impl_Order__ByteOrder(t) }

func (t *HeapByteBuffer) Flip__ByteBuffer() ByteBuffer_I { return t.Impl_Flip__ByteBuffer(t) }

func (t *HeapByteBuffer) Rewind__ByteBuffer() ByteBuffer_I { return t.Impl_Rewind__ByteBuffer(t) }

func (t *HeapByteBuffer) Clear__ByteBuffer() ByteBuffer_I { return t.Impl_Clear__ByteBuffer(t) }

func (t *HeapByteBuffer) PutBuffer_I_ByteBuffer_I_I__V(p0 int32, p1 ByteBuffer_I, p2, p3 int32) { t.Impl_PutBuffer_I_ByteBuffer_I_I__V(t, p0, p1, p2, p3) }

func (t *HeapByteBuffer) Limit__I() int32 { return t.Impl_Limit__I(t) }

func (t *HeapByteBuffer) Base__O() any { return t.Impl_Base__O(t) }

func (t *HeapByteBuffer) Remaining__I() int32 { return t.Impl_Remaining__I(t) }

func (t *HeapByteBuffer) NextGetIndex_I__I(p0 int32) int32 { return t.Impl_NextGetIndex_I__I(t, p0) }

func (t *HeapByteBuffer) PutArray_I_B1_I_I__ByteBuffer(p0 int32, p1 *ByteArray, p2, p3 int32) ByteBuffer_I { return t.Impl_PutArray_I_B1_I_I__ByteBuffer(t, p0, p1, p2, p3) }

func (t *HeapByteBuffer) NextPutIndex__I() int32 { return t.Impl_NextPutIndex__I(t) }

func (t *HeapByteBuffer) Get_I_B1__ByteBuffer(p0 int32, p1 *ByteArray) ByteBuffer_I { return t.Impl_Get_I_B1__ByteBuffer(t, p0, p1) }

func (t *HeapByteBuffer) DiscardMark__V() { t.Impl_DiscardMark__V(t) }

func (t *HeapByteBuffer) Flip__Buffer() Buffer_I { return t.Impl_Flip__Buffer(t) }

func (t *HeapByteBuffer) Put_B1__ByteBuffer(p0 *ByteArray) ByteBuffer_I { return t.Impl_Put_B1__ByteBuffer(t, p0) }

func (t *HeapByteBuffer) ArrayOffset__I() int32 { return t.Impl_ArrayOffset__I(t) }

func (t *HeapByteBuffer) MarkValue__I() int32 { return t.Impl_MarkValue__I(t) }

func (t *HeapByteBuffer) Rewind__Buffer() Buffer_I { return t.Impl_Rewind__Buffer(t) }

func (t *HeapByteBuffer) HasArray__Z() bool { return t.Impl_HasArray__Z(t) }

func (t *HeapByteBuffer) AlignmentOffset_I_I__I(p0, p1 int32) int32 { return t.Impl_AlignmentOffset_I_I__I(t, p0, p1) }

func (t *HeapByteBuffer) Position__I() int32 { return t.Impl_Position__I(t) }

func (t *HeapByteBuffer) Reset__Buffer() Buffer_I { return t.Impl_Reset__Buffer(t) }

func (t *HeapByteBuffer) Limit_I__ByteBuffer(p0 int32) ByteBuffer_I { return t.Impl_Limit_I__ByteBuffer(t, p0) }

func (t *HeapByteBuffer) CheckIndex_I_I__I(p0, p1 int32) int32 { return t.Impl_CheckIndex_I_I__I(t, p0, p1) }

func (t *HeapByteBuffer) CheckSession__V() { t.Impl_CheckSession__V(t) }

func (t *HeapByteBuffer) CheckIndex_I__I(p0 int32) int32 { return t.Impl_CheckIndex_I__I(t, p0) }

func (t *HeapByteBuffer) Position_I__Buffer(p0 int32) Buffer_I { return t.Impl_Position_I__Buffer(t, p0) }

func (t *HeapByteBuffer) GetArray_I_B1_I_I__ByteBuffer(p0 int32, p1 *ByteArray, p2, p3 int32) ByteBuffer_I { return t.Impl_GetArray_I_B1_I_I__ByteBuffer(t, p0, p1, p2, p3) }

func (t *HeapByteBuffer) Get_B1__ByteBuffer(p0 *ByteArray) ByteBuffer_I { return t.Impl_Get_B1__ByteBuffer(t, p0) }

func (t *HeapByteBuffer) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *HeapByteBuffer) Mark__Buffer() Buffer_I { return t.Impl_Mark__Buffer(t) }

func (t *HeapByteBuffer) HasRemaining__Z() bool { return t.Impl_HasRemaining__Z(t) }

func (t *HeapByteBuffer) NextPutIndex_I__I(p0 int32) int32 { return t.Impl_NextPutIndex_I__I(t, p0) }

func (t *HeapByteBuffer) Mark__ByteBuffer() ByteBuffer_I { return t.Impl_Mark__ByteBuffer(t) }

func (t *HeapByteBuffer) Put_I_B1__ByteBuffer(p0 int32, p1 *ByteArray) ByteBuffer_I { return t.Impl_Put_I_B1__ByteBuffer(t, p0, p1) }

func (t *HeapByteBuffer) Limit_I__Buffer(p0 int32) Buffer_I { return t.Impl_Limit_I__Buffer(t, p0) }

func (t *HeapByteBuffer) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HeapByteBuffer) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HeapByteBuffer) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HeapByteBuffer) Ref() any { if t == nil { return nil }; return t }

func (t *HeapByteBuffer) GetClass__Class() *Class { return HeapByteBuffer_class }

func (t *HeapByteBuffer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HeapByteBuffer) CloneShallow() any { panic(CloneNotSupported(t)) }

func HeapByteBuffer_InstanceOf(x any) bool { _, ok := x.(*HeapByteBuffer); return ok }

func HeapByteBuffer_Cast(x any) *HeapByteBuffer { if x == nil { return nil }; v, ok := x.(*HeapByteBuffer); if !ok { panic(ClassCast(x, HeapByteBuffer_class)) }; return v }
