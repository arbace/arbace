//line java_lang_IndexOutOfBoundsException.ae:1
package jrt








func IndexOutOfBoundsException_New() *IndexOutOfBoundsException { t := &IndexOutOfBoundsException{}; t.Ctor(t); return t }
//line :10:1
func (t *IndexOutOfBoundsException) Ctor(this IndexOutOfBoundsException_I) { t.RuntimeException.Ctor(this) }

func IndexOutOfBoundsException_New_String(p0 *String) *IndexOutOfBoundsException { t := &IndexOutOfBoundsException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *IndexOutOfBoundsException) Ctor_String(this IndexOutOfBoundsException_I, s *String) { t.RuntimeException.Ctor_String(this, s) }

func IndexOutOfBoundsException_New_I(p0 int32) *IndexOutOfBoundsException { t := &IndexOutOfBoundsException{}; t.Ctor_I(t, p0); return t }
//line :14:1
func (t *IndexOutOfBoundsException) Ctor_I(this IndexOutOfBoundsException_I, index int32) { t.RuntimeException.Ctor_String(this, Concat(Lit_1121, StrOfInt(index))) }


func IndexOutOfBoundsException_New_J(p0 int64) *IndexOutOfBoundsException { t := &IndexOutOfBoundsException{}; t.Ctor_J(t, p0); return t }
//line :17:1
func (t *IndexOutOfBoundsException) Ctor_J(this IndexOutOfBoundsException_I, index int64) { t.RuntimeException.Ctor_String(this, Concat(Lit_1121, StrOfLong(index))) }










type IndexOutOfBoundsException struct{ RuntimeException }

type IndexOutOfBoundsException_I interface{ RuntimeException_I; Serializable; Self_IndexOutOfBoundsException() *IndexOutOfBoundsException }

func (t *IndexOutOfBoundsException) Self_IndexOutOfBoundsException() *IndexOutOfBoundsException { return t }

const IndexOutOfBoundsException_serialVersionUID int64 = 234122996006267687

func (t *IndexOutOfBoundsException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IndexOutOfBoundsException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IndexOutOfBoundsException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IndexOutOfBoundsException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IndexOutOfBoundsException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IndexOutOfBoundsException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IndexOutOfBoundsException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IndexOutOfBoundsException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IndexOutOfBoundsException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IndexOutOfBoundsException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IndexOutOfBoundsException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IndexOutOfBoundsException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IndexOutOfBoundsException) Ref() any { if t == nil { return nil }; return t }

func (t *IndexOutOfBoundsException) GetClass__Class() *Class { return IndexOutOfBoundsException_class }

func (t *IndexOutOfBoundsException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IndexOutOfBoundsException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IndexOutOfBoundsException_InstanceOf(x any) bool { _, ok := x.(IndexOutOfBoundsException_I); return ok }

func IndexOutOfBoundsException_Cast(x any) IndexOutOfBoundsException_I { if x == nil { return nil }; v, ok := x.(IndexOutOfBoundsException_I); if !ok { panic(ClassCast(x, IndexOutOfBoundsException_class)) }; return v }
