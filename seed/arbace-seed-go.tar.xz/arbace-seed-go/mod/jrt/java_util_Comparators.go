//line java_util_Comparators.ae:1
package jrt






func Comparators_New() *Comparators { t := &Comparators{}; t.Ctor(); return t }
//line :8:1
func (t *Comparators) Ctor() { panic(A2g_NotTranslated("java.util.Comparators.<init>()V")) }






func (t *Comparators_NaturalOrderComparator) Compare_Comparable_Comparable__I(c1, c2 Comparable) int32 {

	return c1.CompareTo_O__I(c2)
}
func (t *Comparators_NaturalOrderComparator) Reversed__Comparator() Comparator {
	return Comparator_ReverseOrder__Comparator()
}










func Comparators_NullComparator_New_Z_Comparator(p0 bool, p1 Comparator) *Comparators_NullComparator { t := &Comparators_NullComparator{}; t.Ctor_Z_Comparator(p0, p1); return t }
//line :32:1
func (t *Comparators_NullComparator) Ctor_Z_Comparator(nullFirst bool, real_ Comparator) {
	t.F_nullFirst = nullFirst
	t.F_real = real_
}
func (t *Comparators_NullComparator) Compare_O_O__I(a, b any) int32 {
	if a == nil {
		if b == nil { return 0 } else { if t.F_nullFirst { return -1 } else { return 1 } } } else {
//line :37:1
			if b == nil {

				if t.F_nullFirst { return 1 } else { return -1 } } else {
//line :37:1
					if t.F_real == nil { return 0 } else {



						return t.F_real.Compare_O_O__I(a, b)
					} } } }
func (t *Comparators_NullComparator) ThenComparing_Comparator__Comparator(other Comparator) Comparator {

	Objects_RequireNonNull_O__O(other)
	var tmp1 bool = t.F_nullFirst; var tmp2 Comparator; if t.F_real == nil { tmp2 = other } else { tmp2 = t.F_real.ThenComparing_Comparator__Comparator(other) }; return Comparators_NullComparator_New_Z_Comparator(tmp1, tmp2)
}
func (t *Comparators_NullComparator) Reversed__Comparator() Comparator {
	var tmp1 bool = !t.F_nullFirst; var tmp2 Comparator; if !(t.F_real == nil) { tmp2 = t.F_real.Reversed__Comparator() } else { tmp2 = nil }; return Comparators_NullComparator_New_Z_Comparator(tmp1, tmp2)
}


type Comparators struct{ Object }

func (t *Comparators) Ref() any { if t == nil { return nil }; return t }

func (t *Comparators) GetClass__Class() *Class { return Comparators_class }

func (t *Comparators) ToString__String() *String { return Object_toString(t) }

func (t *Comparators) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Comparators) CloneShallow() any { panic(CloneNotSupported(t)) }

func Comparators_InstanceOf(x any) bool { _, ok := x.(*Comparators); return ok }

func Comparators_Cast(x any) *Comparators { if x == nil { return nil }; v, ok := x.(*Comparators); if !ok { panic(ClassCast(x, Comparators_class)) }; return v }



type Comparators_NaturalOrderComparator struct{ Enum }

func (t *Comparators_NaturalOrderComparator) Is_Comparator() {}

func (t *Comparators_NaturalOrderComparator) Is_Constable() {}

var Comparators_NaturalOrderComparator_INSTANCE *Comparators_NaturalOrderComparator

var Comparators_NaturalOrderComparator__VALUES *RefArray

var Comparators_NaturalOrderComparator_init ClassInit

func Comparators_NaturalOrderComparator_Init() { if !Comparators_NaturalOrderComparator_init.Done() { Comparators_NaturalOrderComparator_init.Run(Comparators_NaturalOrderComparator_clinit) } }

func Comparators_NaturalOrderComparator_clinit() { Comparators_NaturalOrderComparator_INSTANCE = Comparators_NaturalOrderComparator_New_String_I(Lit_2642, 0); Comparators_NaturalOrderComparator__VALUES = Comparators_NaturalOrderComparator_X_values__Comparators_NaturalOrderComparator1() }

func Comparators_NaturalOrderComparator_New_String_I(p0 *String, p1 int32) *Comparators_NaturalOrderComparator { Comparators_NaturalOrderComparator_Init(); t := &Comparators_NaturalOrderComparator{}; t.Ctor_String_I(p0, p1); return t }

func (t *Comparators_NaturalOrderComparator) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Comparators_NaturalOrderComparator_Values__Comparators_NaturalOrderComparator1() *RefArray { Comparators_NaturalOrderComparator_Init(); return Comparators_NaturalOrderComparator__VALUES.Copy() }

func Comparators_NaturalOrderComparator_ValueOf_String__Comparators_NaturalOrderComparator(p0 *String) *Comparators_NaturalOrderComparator { Comparators_NaturalOrderComparator_Init(); return Comparators_NaturalOrderComparator_Cast(Enum_ValueOf_Class_String__Enum(Comparators_NaturalOrderComparator_class, p0)) }

func Comparators_NaturalOrderComparator_X_values__Comparators_NaturalOrderComparator1() *RefArray { Comparators_NaturalOrderComparator_Init(); return RefArrayOf(Comparators_NaturalOrderComparator_class, Comparators_NaturalOrderComparator_INSTANCE) }

func (t *Comparators_NaturalOrderComparator) Compare_O_O__I(p0, p1 any) int32 { return t.Compare_Comparable_Comparable__I(Comparable_Cast(p0), Comparable_Cast(p1)) }

func (t *Comparators_NaturalOrderComparator) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.util.Comparators$NaturalOrderComparator.describeConstable()Ljava/util/Optional;")) }

func (t *Comparators_NaturalOrderComparator) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *Comparators_NaturalOrderComparator) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *Comparators_NaturalOrderComparator) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Comparators_NaturalOrderComparator) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *Comparators_NaturalOrderComparator) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *Comparators_NaturalOrderComparator) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *Comparators_NaturalOrderComparator) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *Comparators_NaturalOrderComparator) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *Comparators_NaturalOrderComparator) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Comparators_NaturalOrderComparator) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *Comparators_NaturalOrderComparator) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Comparators_NaturalOrderComparator) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Comparators_NaturalOrderComparator) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Comparators_NaturalOrderComparator) Ref() any { if t == nil { return nil }; return t }

func (t *Comparators_NaturalOrderComparator) GetClass__Class() *Class { return Comparators_NaturalOrderComparator_class }

func (t *Comparators_NaturalOrderComparator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Comparators_NaturalOrderComparator_InstanceOf(x any) bool { _, ok := x.(*Comparators_NaturalOrderComparator); return ok }

func Comparators_NaturalOrderComparator_Cast(x any) *Comparators_NaturalOrderComparator { if x == nil { return nil }; v, ok := x.(*Comparators_NaturalOrderComparator); if !ok { panic(ClassCast(x, Comparators_NaturalOrderComparator_class)) }; return v }



type Comparators_NullComparator struct{ Object; F_nullFirst bool; F_real Comparator }

func (t *Comparators_NullComparator) Is_Comparator() {}

func (t *Comparators_NullComparator) Is_Serializable() {}

const Comparators_NullComparator_serialVersionUID int64 = -7569533591570686392

func (t *Comparators_NullComparator) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *Comparators_NullComparator) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *Comparators_NullComparator) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *Comparators_NullComparator) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *Comparators_NullComparator) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *Comparators_NullComparator) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *Comparators_NullComparator) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *Comparators_NullComparator) Ref() any { if t == nil { return nil }; return t }

func (t *Comparators_NullComparator) GetClass__Class() *Class { return Comparators_NullComparator_class }

func (t *Comparators_NullComparator) ToString__String() *String { return Object_toString(t) }

func (t *Comparators_NullComparator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Comparators_NullComparator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Comparators_NullComparator_InstanceOf(x any) bool { _, ok := x.(*Comparators_NullComparator); return ok }

func Comparators_NullComparator_Cast(x any) *Comparators_NullComparator { if x == nil { return nil }; v, ok := x.(*Comparators_NullComparator); if !ok { panic(ClassCast(x, Comparators_NullComparator_class)) }; return v }
