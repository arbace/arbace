//line java_lang_IllegalAccessException.ae:1
package jrt








func IllegalAccessException_New() *IllegalAccessException { t := &IllegalAccessException{}; t.Ctor(); return t }
//line :10:1
func (t *IllegalAccessException) Ctor() { t.ReflectiveOperationException.Ctor(t) }

func IllegalAccessException_New_String(p0 *String) *IllegalAccessException { t := &IllegalAccessException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *IllegalAccessException) Ctor_String(s *String) { t.ReflectiveOperationException.Ctor_String(t, s) }







type IllegalAccessException struct{ ReflectiveOperationException }

const IllegalAccessException_serialVersionUID int64 = 6616958222490762034

func (t *IllegalAccessException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalAccessException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalAccessException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalAccessException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalAccessException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalAccessException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalAccessException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalAccessException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalAccessException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalAccessException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalAccessException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalAccessException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalAccessException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalAccessException) GetClass__Class() *Class { return IllegalAccessException_class }

func (t *IllegalAccessException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalAccessException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalAccessException_InstanceOf(x any) bool { _, ok := x.(*IllegalAccessException); return ok }

func IllegalAccessException_Cast(x any) *IllegalAccessException { if x == nil { return nil }; v, ok := x.(*IllegalAccessException); if !ok { panic(ClassCast(x, IllegalAccessException_class)) }; return v }
