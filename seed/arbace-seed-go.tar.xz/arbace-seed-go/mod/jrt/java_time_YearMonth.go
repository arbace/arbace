//line java_time_YearMonth.ae:1
package jrt




















































func YearMonth_Now__YearMonth() *YearMonth { YearMonth_Init()
	return YearMonth_Now_Clock__YearMonth(Clock_SystemDefaultZone__Clock())
}
func YearMonth_Now_ZoneId__YearMonth(zone ZoneId_I) *YearMonth { YearMonth_Init()
	return YearMonth_Now_Clock__YearMonth(Clock_System_ZoneId__Clock(zone))
}
func YearMonth_Now_Clock__YearMonth(clock Clock_I) *YearMonth { YearMonth_Init()
	var now *LocalDate = LocalDate_Now_Clock__LocalDate(clock); return YearMonth_Of_I_Month__YearMonth(NN(now).GetYear__I(), NN(now).GetMonth__Month())
}
func YearMonth_Of_I_Month__YearMonth(year int32, month *Month) *YearMonth { YearMonth_Init()
	Objects_RequireNonNull_O_String__O(month.Ref(), Lit_1781)
	return YearMonth_Of_I_I__YearMonth(year, NN(month).GetValue__I())
}
func YearMonth_Of_I_I__YearMonth(year, month int32) *YearMonth { YearMonth_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(year))
	var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; NN(tmp2).CheckValidValue_J__J(int64(month))
	return YearMonth_New_I_I(year, month)
}
func YearMonth_From_TemporalAccessor__YearMonth(temporal TemporalAccessor) *YearMonth { YearMonth_Init()
	if YearMonth_InstanceOf(temporal) {
		return YearMonth_Cast(temporal) } else {

			Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
			var tmp1 *YearMonth; tmp9 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; var tmp3 *IsoChronology = tmp2; if NN(tmp3).Equals_O__Z(Chronology_From_TemporalAccessor__Chronology(temporal)) == false {
					temporal = Up_LocalDate_TemporalAccessor(LocalDate_From_TemporalAccessor__LocalDate(temporal)) }
					var tmp4 TemporalAccessor = temporal; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; var tmp6 int32 = tmp4.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5)); var tmp7 TemporalAccessor = temporal; var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_MONTH_OF_YEAR; tmp1 = YearMonth_Of_I_I__YearMonth(tmp6, tmp7.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp8))) }; return nil }()
//line :77:1
			if tmp9 != nil { if DateTimeException_InstanceOf(tmp9) { var ex DateTimeException_I = DateTimeException_Cast(tmp9)





				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2087, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :77:1
					panic(tmp9) } }; return tmp1
		}
}










func YearMonth_Parse_CharSequence__YearMonth(text CharSequence) *YearMonth { YearMonth_Init()
	return YearMonth_Parse_CharSequence_DateTimeFormatter__YearMonth(text, YearMonth_PARSER)
}
func YearMonth_Parse_CharSequence_DateTimeFormatter__YearMonth(text CharSequence, formatter *DateTimeFormatter) *YearMonth { YearMonth_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return YearMonth_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return YearMonth_From_TemporalAccessor__YearMonth(p0).Ref() }}))
}



func YearMonth_New_I_I(p0, p1 int32) *YearMonth { YearMonth_Init(); t := &YearMonth{}; t.Ctor_I_I(p0, p1); return t }
//line :100:1
func (t *YearMonth) Ctor_I_I(year, month int32) {
	t.F_year = year
	t.F_month = int8(month)
}
func (t *YearMonth) With_I_I__YearMonth(newYear, newMonth int32) *YearMonth {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_year == newYear; if tmp2 { tmp2 = int32(t.F_month) == newMonth }; tmp1 = tmp2; if tmp1 { return t } else { return YearMonth_New_I_I(newYear, newMonth)
	} }
func (t *YearMonth) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; tmp4 = any(field) == any(tmp5.Ref()); if !tmp4 {
			var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_MONTH_OF_YEAR; tmp4 = any(field) == any(tmp6.Ref()) }
//line :109:1
		tmp3 = tmp4; if !tmp3 {

			var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_PROLEPTIC_MONTH; tmp3 = any(field) == any(tmp7.Ref()) }
//line :109:1
		tmp2 = tmp3; if !tmp2 {


			var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_YEAR_OF_ERA; tmp2 = any(field) == any(tmp8.Ref()) }
//line :109:1
		tmp1 = tmp2; if !tmp1 {



			var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_ERA; tmp1 = any(field) == any(tmp9.Ref()) }
//line :109:1
		return tmp1 } else {




			var tmp10 bool; tmp10 = !(field == nil); if tmp10 { tmp10 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp10
		} }
func (t *YearMonth) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_MONTHS; tmp5 = any(unit) == any(tmp6.Ref()); if !tmp5 { var tmp7 *ChronoUnit; ChronoUnit_Init(); tmp7 = ChronoUnit_YEARS; tmp5 = any(unit) == any(tmp7.Ref()) }; tmp4 = tmp5; if !tmp4 {
			var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_DECADES; tmp4 = any(unit) == any(tmp8.Ref()) }
//line :118:1
		tmp3 = tmp4; if !tmp3 {

			var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_CENTURIES; tmp3 = any(unit) == any(tmp9.Ref()) }
//line :118:1
		tmp2 = tmp3; if !tmp2 {


			var tmp10 *ChronoUnit; ChronoUnit_Init(); tmp10 = ChronoUnit_MILLENNIA; tmp2 = any(unit) == any(tmp10.Ref()) }
//line :118:1
		tmp1 = tmp2; if !tmp1 {



			var tmp11 *ChronoUnit; ChronoUnit_Init(); tmp11 = ChronoUnit_ERAS; tmp1 = any(unit) == any(tmp11.Ref()) }
//line :118:1
		return tmp1 } else {




			var tmp12 bool; tmp12 = !(unit == nil); if tmp12 { tmp12 = unit.IsSupportedBy_Temporal__Z(t) }; return tmp12
		} }
func (t *YearMonth) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR_OF_ERA; if any(field) == any(tmp1.Ref()) {
		if t.GetYear__I() <= 0 {
			return ValueRange_Of_J_J__ValueRange(1, 1000000000) } else {
				return ValueRange_Of_J_J__ValueRange(1, 999999999) } } else {
					return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
				} }
func (t *YearMonth) Get_TemporalField__I(field TemporalField) int32 {
	return NN(t.Range_TemporalField__ValueRange(field)).CheckValidIntValue_J_TemporalField__I(t.GetLong_TemporalField__J(field), field)
}
func (t *YearMonth) GetLong_TemporalField__J(field TemporalField) int64 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 23:
			return int64(t.F_month); case 24:
			return t.GetProlepticMonth__J(); case 25:
			var tmp2 int32; if t.F_year < 1 { tmp2 = 1 - t.F_year } else { tmp2 = t.F_year }; return int64(tmp2); case 26:
			return int64(t.F_year); case 27:
			if t.F_year < 1 { return 0 } else { return 1 }; default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return field.GetFrom_TemporalAccessor__J(t) } }; panic("a2g: unreachable")
}
func (t *YearMonth) GetProlepticMonth__J() int64 {
	return int64(t.F_year)*12 + int64(t.F_month) - 1
}
func (t *YearMonth) GetYear__I() int32 { return t.F_year }

func (t *YearMonth) GetMonthValue__I() int32 { return int32(t.F_month) }

func (t *YearMonth) GetMonth__Month() *Month { return Month_Of_I__Month(int32(t.F_month)) }

func (t *YearMonth) IsLeapYear__Z() bool {
	var tmp1 *IsoChronology; IsoChronology_Init(); tmp1 = IsoChronology_INSTANCE; return NN(tmp1).IsLeapYear_J__Z(int64(t.F_year))
}
func (t *YearMonth) IsValidDay_I__Z(dayOfMonth int32) bool {
	var tmp1 bool; tmp1 = dayOfMonth >= 1; if tmp1 { tmp1 = dayOfMonth <= t.LengthOfMonth__I() }; return tmp1
}
func (t *YearMonth) LengthOfMonth__I() int32 {
	return NN(t.GetMonth__Month()).Length_Z__I(t.IsLeapYear__Z())
}
func (t *YearMonth) LengthOfYear__I() int32 {
	if t.IsLeapYear__Z() { return 366 } else { return 365
	} }
func (t *YearMonth) With_TemporalAdjuster__YearMonth(adjuster TemporalAdjuster) *YearMonth {
	return YearMonth_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
}
func (t *YearMonth) With_TemporalField_J__YearMonth(field TemporalField, newValue int64) *YearMonth {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)

		NN(chronoField).CheckValidValue_J__J(newValue)
		switch NN(chronoField).F_ordinal { case 23:
			return t.WithMonth_I__YearMonth(int32(newValue)); case 24:
			return t.PlusMonths_J__YearMonth(newValue - t.GetProlepticMonth__J()); case 25:

			var tmp2 int64
			if t.F_year < 1 { tmp2 = 1 - newValue } else { tmp2 = newValue }
//line :178:1
			return t.WithYear_I__YearMonth(int32(tmp2))
		case 26:
			return t.WithYear_I__YearMonth(int32(newValue)); case 27:

			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_ERA; if t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3)) == newValue { return t } else {

				return t.WithYear_I__YearMonth(1 - t.F_year) }; default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return YearMonth_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue)) } }; panic("a2g: unreachable")
}
func (t *YearMonth) WithYear_I__YearMonth(year int32) *YearMonth {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(year))
	return t.With_I_I__YearMonth(year, int32(t.F_month))
}
func (t *YearMonth) WithMonth_I__YearMonth(month int32) *YearMonth {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; NN(tmp1).CheckValidValue_J__J(int64(month))
	return t.With_I_I__YearMonth(t.F_year, month)
}
func (t *YearMonth) Plus_TemporalAmount__YearMonth(amountToAdd TemporalAmount) *YearMonth {
	return YearMonth_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
}
func (t *YearMonth) Plus_J_TemporalUnit__YearMonth(amountToAdd int64, unit TemporalUnit) *YearMonth {
	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 9:
			return t.PlusMonths_J__YearMonth(amountToAdd); case 10:
			return t.PlusYears_J__YearMonth(amountToAdd); case 11:
			return t.PlusYears_J__YearMonth(Math_MultiplyExact_J_I__J(amountToAdd, 10)); case 12:
			return t.PlusYears_J__YearMonth(Math_MultiplyExact_J_I__J(amountToAdd, 100)); case 13:
			return t.PlusYears_J__YearMonth(Math_MultiplyExact_J_I__J(amountToAdd, 1000)); case 14:

			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 TemporalField = Up_ChronoField_TemporalField(tmp2); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return t.With_TemporalField_J__YearMonth(tmp3, Math_AddExact_J_J__J(t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)), amountToAdd)); default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
				return YearMonth_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd)) } }; panic("a2g: unreachable")
}
func (t *YearMonth) PlusYears_J__YearMonth(yearsToAdd int64) *YearMonth {
	if yearsToAdd == 0 { return t } else {

		var newYear int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; newYear = NN(tmp1).CheckValidIntValue_J__I(int64(t.F_year) + yearsToAdd)
		return t.With_I_I__YearMonth(newYear, int32(t.F_month))
	} }
func (t *YearMonth) PlusMonths_J__YearMonth(monthsToAdd int64) *YearMonth {
	if monthsToAdd == 0 { return t } else {

		var monthCount int64 = int64(t.F_year)*12 + int64(int32(t.F_month)-1); var calcMonths int64 = monthCount + monthsToAdd; var newYear int32; var tmp1 *ChronoField


		ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ChronoField = tmp1; newYear = NN(tmp2).CheckValidIntValue_J__I(Math_FloorDiv_J_I__J(calcMonths, 12))
//line :221:1
		var newMonth int32 = Math_FloorMod_J_I__I(calcMonths, 12) + 1





		return t.With_I_I__YearMonth(newYear, newMonth)
	} }
func (t *YearMonth) Minus_TemporalAmount__YearMonth(amountToSubtract TemporalAmount) *YearMonth {
	return YearMonth_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
}
func (t *YearMonth) Minus_J_TemporalUnit__YearMonth(amountToSubtract int64, unit TemporalUnit) *YearMonth {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__YearMonth(9223372036854775807, unit)).Plus_J_TemporalUnit__YearMonth(1, unit) } else {
			return t.Plus_J_TemporalUnit__YearMonth(-amountToSubtract, unit)
		} }
func (t *YearMonth) MinusYears_J__YearMonth(yearsToSubtract int64) *YearMonth {
	if yearsToSubtract == -9223372036854775808 {
		return NN(t.PlusYears_J__YearMonth(9223372036854775807)).PlusYears_J__YearMonth(1) } else {
			return t.PlusYears_J__YearMonth(-yearsToSubtract)
		} }
func (t *YearMonth) MinusMonths_J__YearMonth(monthsToSubtract int64) *YearMonth {
	if monthsToSubtract == -9223372036854775808 {
		return NN(t.PlusMonths_J__YearMonth(9223372036854775807)).PlusMonths_J__YearMonth(1) } else {
			return t.PlusMonths_J__YearMonth(-monthsToSubtract)
		} }
func (t *YearMonth) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_Chronology__TemporalQuery() { IsoChronology_Init(); return IsoChronology_INSTANCE.Ref() } else { if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_MONTHS.Ref() } else {


		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	} } }
func (t *YearMonth) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 Chronology = Chronology_From_TemporalAccessor__Chronology(temporal); var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; if tmp1.Equals_O__Z(tmp2.Ref()) == false {
		panic(Thrown(DateTimeException_New_String(Lit_2071))) }
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_PROLEPTIC_MONTH; var tmp4 TemporalField = Up_ChronoField_TemporalField(tmp3); return temporal.With_TemporalField_J__Temporal(tmp4, t.GetProlepticMonth__J())
}
func (t *YearMonth) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	{ var end *YearMonth = YearMonth_From_TemporalAccessor__YearMonth(endExclusive); var tmp1 TemporalUnit = unit
		if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1); var monthsUntil int64 = NN(end).GetProlepticMonth__J() - t.GetProlepticMonth__J()

			switch NN(chronoUnit).F_ordinal { case 9: return monthsUntil; case 10:

				return monthsUntil / 12; case 11:
				return monthsUntil / 120; case 12:
				return monthsUntil / 1200; case 13:
				return monthsUntil / 12000; case 14:
				var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 int64 = NN(end).GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2)); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return tmp3 - t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)); default:
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
					return unit.Between_Temporal_Temporal__J(t, Up_YearMonth_Temporal(end)) } }; panic("a2g: unreachable")
}
func (t *YearMonth) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *YearMonth) AtDay_I__LocalDate(dayOfMonth int32) *LocalDate {
	return LocalDate_Of_I_I_I__LocalDate(t.F_year, int32(t.F_month), dayOfMonth)
}
func (t *YearMonth) AtEndOfMonth__LocalDate() *LocalDate {
	var tmp1 int32 = t.F_year; var tmp2 int32 = int32(t.F_month); return LocalDate_Of_I_I_I__LocalDate(tmp1, tmp2, t.LengthOfMonth__I())
}
func (t *YearMonth) CompareTo_YearMonth__I(other *YearMonth) int32 {
	var tmp1 int32 = t.F_year; var cmp int32 = tmp1 - other.F_year
	if cmp == 0 { var tmp2 int32 = int32(t.F_month); cmp = tmp2 - int32(other.F_month) }
//line :283:1
	return cmp
}


func (t *YearMonth) IsAfter_YearMonth__Z(other *YearMonth) bool {
	return t.CompareTo_YearMonth__I(other) > 0
}
func (t *YearMonth) IsBefore_YearMonth__Z(other *YearMonth) bool {
	return t.CompareTo_YearMonth__I(other) < 0
}
func (t *YearMonth) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if YearMonth_InstanceOf(tmp1) { var other *YearMonth = YearMonth_Cast(tmp1); var tmp2 int32 = t.F_year
			if tmp2 == other.F_year { var tmp3 int32 = int32(t.F_month); return tmp3 == int32(other.F_month) } else { return false } } else {
//line :296:1
				return false
			}
	}
}
func (t *YearMonth) HashCode__I() int32 {
	return t.F_year ^ int32(t.F_month)<<27
}
func (t *YearMonth) ToString__String() *String {
	var absYear int32 = Math_Abs_I__I(t.F_year); var buf *StringBuilder = StringBuilder_New_I(9)

	if absYear < 10000 {
		if t.F_year < 0 { NN(buf).Append_C__StringBuilder(45) }; DecimalDigits_AppendQuad_StringBuilder_I__V(buf, absYear) } else {
			NN(buf).Append_I__StringBuilder(t.F_year) }
	NN(buf).Append_C__StringBuilder(45)
	DecimalDigits_AppendPair_StringBuilder_I__V(buf, int32(t.F_month))
	return NN(buf).ToString__String()
}
func (t *YearMonth) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.YearMonth.writeReplace()Ljava/lang/Object;")) }








func YearMonth_ReadExternal_DataInput__YearMonth(p0 DataInput) *YearMonth { YearMonth_Init(); panic(A2g_NotTranslated("java.time.YearMonth.readExternal(Ljava/io/DataInput;)Ljava/time/YearMonth;")) }



type YearMonth struct{ Object; F_year int32; F_month int8 }

func (t *YearMonth) Is_Temporal() {}

func (t *YearMonth) Is_TemporalAdjuster() {}

func (t *YearMonth) Is_Comparable() {}

func (t *YearMonth) Is_Serializable() {}

func (t *YearMonth) Is_TemporalAccessor() {}

const YearMonth_serialVersionUID int64 = 4183400860270640070

var YearMonth_PARSER *DateTimeFormatter

var YearMonth_init ClassInit

func YearMonth_Init() { if !YearMonth_init.Done() { YearMonth_init.Run(YearMonth_clinit) } }

func YearMonth_clinit() { var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_YEAR; var tmp3 TemporalField = Up_ChronoField_TemporalField(tmp2); var tmp4 *SignStyle; SignStyle_Init(); tmp4 = SignStyle_EXCEEDS_PAD; var tmp5 *DateTimeFormatterBuilder = NN(tmp1.AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(tmp3, 4, 10, tmp4)).AppendLiteral_C__DateTimeFormatterBuilder(45); var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_MONTH_OF_YEAR; YearMonth_PARSER = NN(NN(tmp5).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp6), 2)).ToFormatter__DateTimeFormatter() }

func (t *YearMonth) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_YearMonth_Temporal(t.With_TemporalAdjuster__YearMonth(p0)) }

func (t *YearMonth) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_YearMonth_Temporal(t.With_TemporalField_J__YearMonth(p0, p1)) }

func (t *YearMonth) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_YearMonth_Temporal(t.Plus_TemporalAmount__YearMonth(p0)) }

func (t *YearMonth) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_YearMonth_Temporal(t.Plus_J_TemporalUnit__YearMonth(p0, p1)) }

func (t *YearMonth) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_YearMonth_Temporal(t.Minus_TemporalAmount__YearMonth(p0)) }

func (t *YearMonth) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_YearMonth_Temporal(t.Minus_J_TemporalUnit__YearMonth(p0, p1)) }

func (t *YearMonth) CompareTo_O__I(p0 any) int32 { return t.CompareTo_YearMonth__I(YearMonth_Cast(p0)) }

func (t *YearMonth) Ref() any { if t == nil { return nil }; return t }

func (t *YearMonth) GetClass__Class() *Class { return YearMonth_class }

func (t *YearMonth) Clone__O() any { return A2g_ObjectClone(t) }

func (t *YearMonth) CloneShallow() any { panic(CloneNotSupported(t)) }

func YearMonth_InstanceOf(x any) bool { _, ok := x.(*YearMonth); return ok }

func YearMonth_Cast(x any) *YearMonth { if x == nil { return nil }; v, ok := x.(*YearMonth); if !ok { panic(ClassCast(x, YearMonth_class)) }; return v }
