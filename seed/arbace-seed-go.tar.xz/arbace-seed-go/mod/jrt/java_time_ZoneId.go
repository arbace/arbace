//line java_time_ZoneId.ae:1
package jrt


















































func ZoneId_SystemDefault__ZoneId() ZoneId_I { ZoneId_Init()
	return TimeZone_GetDefault__TimeZone().ToZoneId__ZoneId()
}
func ZoneId_GetAvailableZoneIds__Set() Set { ZoneId_Init()
	return HashSet_New_Collection(ZoneRulesProvider_GetAvailableZoneIds__Set())
}
func ZoneId_Of_String_Map__ZoneId(zoneId *String, aliasMap Map) ZoneId_I { ZoneId_Init()
	Objects_RequireNonNull_O_String__O(zoneId.Ref(), Lit_2143)
	Objects_RequireNonNull_O_String__O(aliasMap, Lit_2144)
	var id *String = String_Cast(Objects_RequireNonNullElse_O_O__O(String_Cast(aliasMap.Get_O__O(zoneId.Ref())).Ref(), zoneId.Ref()))
	return ZoneId_Of_String__ZoneId(id)
}
func ZoneId_Of_String__ZoneId(zoneId *String) ZoneId_I { ZoneId_Init()
	return ZoneId_Of_String_Z__ZoneId(zoneId, true)
}
func ZoneId_OfOffset_String_ZoneOffset__ZoneId(prefix *String, offset *ZoneOffset) ZoneId_I { ZoneId_Init()
	Objects_RequireNonNull_O_String__O(prefix.Ref(), Lit_1960)
	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	if NN(prefix).IsEmpty__Z() { return Up_ZoneOffset_ZoneId(offset) } else {


		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !NN(prefix).Equals_O__Z(Lit_1972); if tmp3 { tmp3 = !NN(prefix).Equals_O__Z(Lit_2145) }; tmp2 = tmp3; if tmp2 {
			tmp2 = !NN(prefix).Equals_O__Z(Lit_2146) }
//line :73:1
		tmp1 = tmp2; if tmp1 {

			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2147, prefix))))
		}
		if NN(offset).GetTotalSeconds__I() == 0 { } else { prefix = NN(prefix).Concat_String__String(NN(offset).GetId__String()) }
		return ZoneRegion_New_String_ZoneRules(prefix, NN(offset).GetRules__ZoneRules())
	} }
func ZoneId_Of_String_Z__ZoneId(zoneId *String, checkAvailable bool) ZoneId_I { ZoneId_Init()
	Objects_RequireNonNull_O_String__O(zoneId.Ref(), Lit_2143)
	var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = NN(zoneId).Length__I() <= 1; if !tmp3 { tmp3 = NN(zoneId).StartsWith_String__Z(Lit_1135) }; tmp2 = tmp3; if !tmp2 { tmp2 = NN(zoneId).StartsWith_String__Z(Lit_1134) }; tmp1 = tmp2
//line :82:1
	if tmp1 {

		return Up_ZoneOffset_ZoneId(ZoneOffset_Of_String__ZoneOffset(zoneId)) } else {
//line :82:1
			var tmp4 bool; var tmp5 bool


			tmp5 = NN(zoneId).StartsWith_String__Z(Lit_2145); if !tmp5 { tmp5 = NN(zoneId).StartsWith_String__Z(Lit_1972) }; tmp4 = tmp5
//line :82:1
			if tmp4 {



				return ZoneId_OfWithPrefix_String_I_Z__ZoneId(zoneId, 3, checkAvailable) } else {
//line :82:1
					if NN(zoneId).StartsWith_String__Z(Lit_2146) {




						return ZoneId_OfWithPrefix_String_I_Z__ZoneId(zoneId, 2, checkAvailable) } else {
							return Up_ZoneRegion_ZoneId(ZoneRegion_OfId_String_Z__ZoneRegion(zoneId, checkAvailable))
						} } } }
func ZoneId_OfWithPrefix_String_I_Z__ZoneId(zoneId *String, prefixLength int32, checkAvailable bool) ZoneId_I { ZoneId_Init()

	var prefix *String = NN(zoneId).Substring_I_I__String(0, prefixLength)
	if NN(zoneId).Length__I() == prefixLength {
		var tmp1 *ZoneOffset; ZoneOffset_Init(); tmp1 = ZoneOffset_UTC; return ZoneId_OfOffset_String_ZoneOffset__ZoneId(prefix, tmp1) } else {
//line :93:1
			var tmp2 bool; var tmp3 bool

			tmp3 = !(int32(NN(zoneId).CharAt_I__C(prefixLength)) == 43); if tmp3 {
				tmp3 = !(int32(NN(zoneId).CharAt_I__C(prefixLength)) == 45) }
//line :95:1
			tmp2 = tmp3
//line :93:1
			if tmp2 {



				return Up_ZoneRegion_ZoneId(ZoneRegion_OfId_String_Z__ZoneRegion(zoneId, checkAvailable)) } else {

					var tmp4 ZoneId_I; tmp6 := func() (exc Throwable_I) { defer Catch(&exc)
						{ var offset *ZoneOffset = ZoneOffset_Of_String__ZoneOffset(NN(zoneId).Substring_I__String(prefixLength)); var tmp5 *ZoneOffset
							ZoneOffset_Init(); tmp5 = ZoneOffset_UTC; if offset == tmp5 {
								tmp4 = ZoneId_OfOffset_String_ZoneOffset__ZoneId(prefix, offset) } else {
									tmp4 = ZoneId_OfOffset_String_ZoneOffset__ZoneId(prefix, offset) } }
//line :99:1
						return nil }(); if tmp6 != nil { if DateTimeException_InstanceOf(tmp6) { var ex DateTimeException_I = DateTimeException_Cast(tmp6)





							panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2148, zoneId), ex))) } else {
//line :99:1
								panic(tmp6) } }; return tmp4
				}
		}
}





func ZoneId_From_TemporalAccessor__ZoneId(temporal TemporalAccessor) ZoneId_I { ZoneId_Init()
	var obj ZoneId_I = ZoneId_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Zone__TemporalQuery()))
	if obj == nil {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2149, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String())))) }
//line :109:1
	return obj
}







func (t *ZoneId) Ctor(this ZoneId_I) {}



func (t *ZoneId) Impl_GetDisplayName_TextStyle_Locale__String(this ZoneId_I, style *TextStyle, locale *Locale) *String {
	return NN(NN(DateTimeFormatterBuilder_New().AppendZoneText_TextStyle__DateTimeFormatterBuilder(style)).ToFormatter_Locale__DateTimeFormatter(locale)).Format_TemporalAccessor__String(t.Impl_ToTemporal__TemporalAccessor(this))
}

func (t *ZoneId) Impl_ToTemporal__TemporalAccessor(this ZoneId_I) TemporalAccessor {
	return ZoneId_1_New_ZoneId(this) }
func (t *ZoneId_1) IsSupported_TemporalField__Z(field TemporalField) bool { return false }

func (t *ZoneId_1) GetLong_TemporalField__J(field TemporalField) int64 {
	panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))
}
func (t *ZoneId_1) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_ZoneId__TemporalQuery() { return t.F_this_0 } else {

		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	}
}

func (t *ZoneId) Impl_Normalized__ZoneId(this ZoneId_I) ZoneId_I { tmp2, tmp3, tmp4 := func() (ctl int32, rv ZoneId_I, exc Throwable_I) { defer Catch(&exc)

	{ var rules *ZoneRules = this.GetRules__ZoneRules()
		if NN(rules).IsFixedOffset__Z() { var tmp1 *Instant; Instant_Init(); tmp1 = Instant_EPOCH; return 2, Up_ZoneOffset_ZoneId(NN(rules).GetOffset_Instant__ZoneOffset(tmp1)), nil } }; return 0, nil, nil }(); if /*line :141:1*/ tmp4 != nil { if ZoneRulesException_InstanceOf(tmp4) { var ex *ZoneRulesException = ZoneRulesException_Cast(tmp4); _ = ex } else { panic(tmp4) } }; switch tmp2 { case 2: { return tmp3 }}; return this }







func (t *ZoneId) Impl_Equals_O__Z(this ZoneId_I, obj any) bool {
	if any(this) == any(obj) { return true } else {

		var tmp1 any = obj; if ZoneId_InstanceOf(tmp1) { var other ZoneId_I = ZoneId_Cast(tmp1); return NN(this.GetId__String()).Equals_O__Z(other.GetId__String().Ref()) } else { return false
		} } }
func (t *ZoneId) Impl_HashCode__I(this ZoneId_I) int32 { return NN(this.GetId__String()).HashCode__I() }




func (t *ZoneId) Impl_ToString__String(this ZoneId_I) *String { return this.GetId__String() }

func (t *ZoneId) Impl_WriteReplace__O(this ZoneId_I) any { panic(A2g_NotTranslated("java.time.ZoneId.writeReplace()Ljava/lang/Object;")) }



type ZoneId struct{ Object }

type ZoneId_I interface{ Object_I; Serializable; Self_ZoneId() *ZoneId; GetId__String() *String; GetDisplayName_TextStyle_Locale__String(p0 *TextStyle, p1 *Locale) *String; GetRules__ZoneRules() *ZoneRules; Normalized__ZoneId() ZoneId_I; GetOffset_J__ZoneOffset(p0 int64) *ZoneOffset }

func (t *ZoneId) Self_ZoneId() *ZoneId { return t }

func (t *ZoneId) Is_Serializable() {}

var ZoneId_SHORT_IDS Map

const ZoneId_serialVersionUID int64 = 8352817235686

var ZoneId_init ClassInit

func ZoneId_Init() { if !ZoneId_init.Done() { ZoneId_init.Run(ZoneId_clinit) } }

func ZoneId_clinit() { ZoneId_SHORT_IDS = Map_OfEntries_Map_Entry1__Map(RefArrayOf(Map_Entry_class, Map_Entry_O_O__Map_Entry(Lit_2088, Lit_2089), Map_Entry_O_O__Map_Entry(Lit_2090, Lit_2091), Map_Entry_O_O__Map_Entry(Lit_2092, Lit_2093), Map_Entry_O_O__Map_Entry(Lit_2094, Lit_2095), Map_Entry_O_O__Map_Entry(Lit_2096, Lit_2097), Map_Entry_O_O__Map_Entry(Lit_2098, Lit_2099), Map_Entry_O_O__Map_Entry(Lit_2100, Lit_2101), Map_Entry_O_O__Map_Entry(Lit_2102, Lit_2103), Map_Entry_O_O__Map_Entry(Lit_2104, Lit_2105), Map_Entry_O_O__Map_Entry(Lit_2106, Lit_2107), Map_Entry_O_O__Map_Entry(Lit_2108, Lit_2109), Map_Entry_O_O__Map_Entry(Lit_2110, Lit_2111), Map_Entry_O_O__Map_Entry(Lit_2112, Lit_2113), Map_Entry_O_O__Map_Entry(Lit_2114, Lit_2115), Map_Entry_O_O__Map_Entry(Lit_2116, Lit_2117), Map_Entry_O_O__Map_Entry(Lit_2118, Lit_2119), Map_Entry_O_O__Map_Entry(Lit_2120, Lit_2121), Map_Entry_O_O__Map_Entry(Lit_2122, Lit_2123), Map_Entry_O_O__Map_Entry(Lit_2124, Lit_2125), Map_Entry_O_O__Map_Entry(Lit_2126, Lit_2127), Map_Entry_O_O__Map_Entry(Lit_2128, Lit_2129), Map_Entry_O_O__Map_Entry(Lit_2130, Lit_2131), Map_Entry_O_O__Map_Entry(Lit_2132, Lit_2133), Map_Entry_O_O__Map_Entry(Lit_2134, Lit_2135), Map_Entry_O_O__Map_Entry(Lit_2136, Lit_2137), Map_Entry_O_O__Map_Entry(Lit_2138, Lit_2139), Map_Entry_O_O__Map_Entry(Lit_2140, Lit_2129), Map_Entry_O_O__Map_Entry(Lit_2141, Lit_2142))) }

func ZoneId_InstanceOf(x any) bool { _, ok := x.(ZoneId_I); return ok }

func ZoneId_Cast(x any) ZoneId_I { if x == nil { return nil }; v, ok := x.(ZoneId_I); if !ok { panic(ClassCast(x, ZoneId_class)) }; return v }



type ZoneId_1 struct{ Object; F_this_0 ZoneId_I }

func (t *ZoneId_1) Is_TemporalAccessor() {}

func ZoneId_1_New_ZoneId(p0 ZoneId_I) *ZoneId_1 { t := &ZoneId_1{}; t.Ctor_ZoneId(p0); return t }

func (t *ZoneId_1) Ctor_ZoneId(this_0 ZoneId_I) { A2g_NotNull[ZoneId_I](this_0); t.F_this_0 = this_0 }

func (t *ZoneId_1) Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange { return TemporalAccessor_Range_TemporalField__ValueRange(t, p0) }

func (t *ZoneId_1) Get_TemporalField__I(p0 TemporalField) int32 { return TemporalAccessor_Get_TemporalField__I(t, p0) }

func (t *ZoneId_1) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneId_1) GetClass__Class() *Class { return ZoneId_1_class }

func (t *ZoneId_1) ToString__String() *String { return Object_toString(t) }

func (t *ZoneId_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneId_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneId_1_InstanceOf(x any) bool { _, ok := x.(*ZoneId_1); return ok }

func ZoneId_1_Cast(x any) *ZoneId_1 { if x == nil { return nil }; v, ok := x.(*ZoneId_1); if !ok { panic(ClassCast(x, ZoneId_1_class)) }; return v }
