//line java_util_EventListener.ae:1
package jrt






type EventListener interface{ Object_I; Is_EventListener() }

func EventListener_InstanceOf(x any) bool { _, ok := x.(EventListener); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(EventListener_class) } }; return ok }

func EventListener_Cast(x any) EventListener { if x == nil { return nil }; v, ok := x.(EventListener); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(EventListener_class) } }; if !ok { panic(ClassCast(x, EventListener_class)) }; return v }
