//line java_time_ZoneRegion.ae:1
package jrt






















func ZoneRegion_OfId_String_Z__ZoneRegion(zoneId *String, checkAvailable bool) *ZoneRegion { ZoneRegion_Init()
	Objects_RequireNonNull_O_String__O(zoneId.Ref(), Lit_2143)
	ZoneRegion_CheckName_String__V(zoneId)
	var rules *ZoneRules; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		rules = ZoneRulesProvider_GetRules_String_Z__ZoneRules(zoneId, true); return nil }()
//line :28:1
	if tmp1 != nil { if ZoneRulesException_InstanceOf(tmp1) { var ex *ZoneRulesException = ZoneRulesException_Cast(tmp1)

		if checkAvailable { panic(Thrown(Up_ZoneRulesException_Throwable(ex))) } } else {
//line :28:1
			panic(tmp1)
		}
	}
	return ZoneRegion_New_String_ZoneRules(zoneId, rules)
}
func ZoneRegion_CheckName_String__V(zoneId *String) { ZoneRegion_Init()
	var n int32 = NN(zoneId).Length__I()
	if n < 2 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2166, zoneId))))
	}
	var i int32 = 0; L1: for {
		if i < n {
			var c uint16 = NN(zoneId).CharAt_I__C(i); var tmp1 bool; var tmp2 bool

			tmp2 = int32(c) >= 97; if tmp2 { tmp2 = int32(c) <= 122 }; tmp1 = tmp2
//line :41:1
			if tmp1 {
				i = i + 1; continue L1 } else {
//line :41:1
					var tmp3 bool; var tmp4 bool

					tmp4 = int32(c) >= 65; if tmp4 { tmp4 = int32(c) <= 90 }; tmp3 = tmp4
//line :41:1
					if tmp3 {

						i = i + 1; continue L1 } else {
//line :41:1
							var tmp5 bool; var tmp6 bool


							tmp6 = int32(c) == 47; if tmp6 { tmp6 = !(i == 0) }; tmp5 = tmp6
//line :41:1
							if tmp5 {


								i = i + 1; continue L1 } else {
//line :41:1
									var tmp7 bool; var tmp8 bool; var tmp9 bool



									tmp9 = int32(c) >= 48; if tmp9 { tmp9 = int32(c) <= 57 }; tmp8 = tmp9; if tmp8 { tmp8 = !(i == 0) }; tmp7 = tmp8
//line :41:1
									if tmp7 {



										i = i + 1; continue L1 } else {
//line :41:1
											var tmp10 bool; var tmp11 bool




											tmp11 = int32(c) == 126; if tmp11 { tmp11 = !(i == 0) }; tmp10 = tmp11
//line :41:1
											if tmp10 {




												i = i + 1; continue L1 } else {
//line :41:1
													var tmp12 bool; var tmp13 bool





													tmp13 = int32(c) == 46; if tmp13 { tmp13 = !(i == 0) }; tmp12 = tmp13
//line :41:1
													if tmp12 {





														i = i + 1; continue L1 } else {
//line :41:1
															var tmp14 bool; var tmp15 bool






															tmp15 = int32(c) == 95; if tmp15 { tmp15 = !(i == 0) }; tmp14 = tmp15
//line :41:1
															if tmp14 {






																i = i + 1; continue L1 } else {
//line :41:1
																	var tmp16 bool; var tmp17 bool







																	tmp17 = int32(c) == 43; if tmp17 { tmp17 = !(i == 0) }; tmp16 = tmp17
//line :41:1
																	if tmp16 {







																		i = i + 1; continue L1 } else {
//line :41:1
																			var tmp18 bool; var tmp19 bool








																			tmp19 = int32(c) == 45; if tmp19 { tmp19 = !(i == 0) }; tmp18 = tmp19
//line :41:1
																			if tmp18 {








																				i = i + 1; continue L1 } else {

																					panic(Thrown(DateTimeException_New_String(Concat(Lit_2166, zoneId)))) } } } } } } } } } }
//line :38:1
		break L1
	}
}














func ZoneRegion_New_String_ZoneRules(p0 *String, p1 *ZoneRules) *ZoneRegion { ZoneRegion_Init(); t := &ZoneRegion{}; t.Ctor_String_ZoneRules(p0, p1); return t }
//line :55:1
func (t *ZoneRegion) Ctor_String_ZoneRules(id *String, rules *ZoneRules) { t.ZoneId.Ctor(t)
	t.F_id = id
	t.F_rules = rules
}
func (t *ZoneRegion) GetId__String() *String { return t.F_id }

func (t *ZoneRegion) GetRules__ZoneRules() *ZoneRules {
	if !(t.F_rules == nil) { return t.F_rules } else { return ZoneRulesProvider_GetRules_String_Z__ZoneRules(t.F_id, false)
	} }
func (t *ZoneRegion) GetOffset_J__ZoneOffset(epochSecond int64) *ZoneOffset {
	return NN(t.GetRules__ZoneRules()).GetOffset_Instant__ZoneOffset(Instant_OfEpochSecond_J__Instant(epochSecond))
}
func (t *ZoneRegion) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.ZoneRegion.writeReplace()Ljava/lang/Object;")) }











func ZoneRegion_ReadExternal_DataInput__ZoneId(p0 DataInput) ZoneId_I { ZoneRegion_Init(); panic(A2g_NotTranslated("java.time.ZoneRegion.readExternal(Ljava/io/DataInput;)Ljava/time/ZoneId;")) }



type ZoneRegion struct{ ZoneId; F_id *String; F_rules *ZoneRules }

const ZoneRegion_serialVersionUID int64 = 8386373296231747096

var ZoneRegion_init ClassInit

func ZoneRegion_Init() { if !ZoneRegion_init.Done() { ZoneRegion_init.Run(ZoneRegion_clinit) } }

func ZoneRegion_clinit() { ZoneId_Init() }

func (t *ZoneRegion) GetDisplayName_TextStyle_Locale__String(p0 *TextStyle, p1 *Locale) *String { return t.Impl_GetDisplayName_TextStyle_Locale__String(t, p0, p1) }

func (t *ZoneRegion) Normalized__ZoneId() ZoneId_I { return t.Impl_Normalized__ZoneId(t) }

func (t *ZoneRegion) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ZoneRegion) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ZoneRegion) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ZoneRegion) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneRegion) GetClass__Class() *Class { return ZoneRegion_class }

func (t *ZoneRegion) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneRegion) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneRegion_InstanceOf(x any) bool { _, ok := x.(*ZoneRegion); return ok }

func ZoneRegion_Cast(x any) *ZoneRegion { if x == nil { return nil }; v, ok := x.(*ZoneRegion); if !ok { panic(ClassCast(x, ZoneRegion_class)) }; return v }
