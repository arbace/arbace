//line java_time_Duration.ae:1
package jrt













































func Duration_OfDays_J__Duration(days int64) *Duration { Duration_Init()
	return Duration_Create_J_I__Duration(Math_MultiplyExact_J_I__J(days, 86400), 0)
}
func Duration_OfHours_J__Duration(hours int64) *Duration { Duration_Init()
	return Duration_Create_J_I__Duration(Math_MultiplyExact_J_I__J(hours, 3600), 0)
}
func Duration_OfMinutes_J__Duration(minutes int64) *Duration { Duration_Init()
	return Duration_Create_J_I__Duration(Math_MultiplyExact_J_I__J(minutes, 60), 0)
}
func Duration_OfSeconds_J__Duration(seconds int64) *Duration { Duration_Init()
	return Duration_Create_J_I__Duration(seconds, 0)
}
func Duration_OfSeconds_J_J__Duration(seconds, nanoAdjustment int64) *Duration { Duration_Init()
	var secs int64 = Math_AddExact_J_J__J(seconds, Math_FloorDiv_J_J__J(nanoAdjustment, 1000000000)); var nos int32 = int32(Math_FloorMod_J_J__J(nanoAdjustment, 1000000000))

	return Duration_Create_J_I__Duration(secs, nos)
}
func Duration_OfMillis_J__Duration(millis int64) *Duration { Duration_Init()
	var secs int64 = millis / 1000; var mos int32 = int32(millis % 1000)

	if mos < 0 { mos = mos + 1000; secs = secs - 1 }
	return Duration_Create_J_I__Duration(secs, mos*1000000)
}
func Duration_OfNanos_J__Duration(nanos int64) *Duration { Duration_Init()
	var secs int64 = nanos / 1000000000; var nos int32 = int32(nanos % 1000000000)

	if nos < 0 {
		nos = nos + 1000000000
		secs = secs - 1 }
	return Duration_Create_J_I__Duration(secs, nos)
}
func Duration_Of_J_TemporalUnit__Duration(amount int64, unit TemporalUnit) *Duration { Duration_Init()
	return NN(Duration_ZERO).Plus_J_TemporalUnit__Duration(amount, unit)
}
func Duration_From_TemporalAmount__Duration(amount TemporalAmount) *Duration { Duration_Init()
	Objects_RequireNonNull_O_String__O(amount, Lit_2010)
	var duration *Duration = Duration_ZERO; var i_101403 Iterator = amount.GetUnits__List().Iterator__Iterator(); for i_101403.HasNext__Z() {
		var unit TemporalUnit = TemporalUnit_Cast(i_101403.Next__O())
		duration = NN(duration).Plus_J_TemporalUnit__Duration(amount.Get_TemporalUnit__J(unit), unit) }
//line :83:1
	return duration
}



func Duration_Parse_CharSequence__Duration(text CharSequence) *Duration { Duration_Init()
	Objects_RequireNonNull_O_String__O(text, Lit_2011)
	var matcher *Matcher; var tmp1 *Pattern; Duration_Lazy_Init(); tmp1 = Duration_Lazy_PATTERN; matcher = NN(tmp1).Matcher_CharSequence__Matcher(text)
	if NN(matcher).Matches__Z() {
		if Duration_CharMatch_CharSequence_I_I_C__Z(text, NN(matcher).Start_I__I(3), NN(matcher).End_I__I(3), 84) { } else {
			var negate bool = Duration_CharMatch_CharSequence_I_I_C__Z(text, NN(matcher).Start_I__I(1), NN(matcher).End_I__I(1), 45); var dayStart int32 = NN(matcher).Start_I__I(2); var dayEnd int32 = NN(matcher).End_I__I(2); var hourStart int32 = NN(matcher).Start_I__I(4); var hourEnd int32 = NN(matcher).End_I__I(4); var minuteStart int32 = NN(matcher).Start_I__I(5); var minuteEnd int32 = NN(matcher).End_I__I(5); var secondStart int32 = NN(matcher).Start_I__I(6); var secondEnd int32 = NN(matcher).End_I__I(6); var fractionStart int32 = NN(matcher).Start_I__I(7); var fractionEnd int32 = NN(matcher).End_I__I(7); var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool










			tmp5 = dayStart >= 0; if !tmp5 { tmp5 = hourStart >= 0 }; tmp4 = tmp5; if !tmp4 { tmp4 = minuteStart >= 0 }; tmp3 = tmp4; if !tmp3 {
				tmp3 = secondStart >= 0 }
//line :104:1
			tmp2 = tmp3; if tmp2 {

				var daysAsSecs int64 = Duration_ParseNumber_CharSequence_I_I_I_String__J(text, dayStart, dayEnd, 86400, Lit_2012); var hoursAsSecs int64 = Duration_ParseNumber_CharSequence_I_I_I_String__J(text, hourStart, hourEnd, 3600, Lit_2013); var minsAsSecs int64 = Duration_ParseNumber_CharSequence_I_I_I_String__J(text, minuteStart, minuteEnd, 60, Lit_2014); var seconds int64 = Duration_ParseNumber_CharSequence_I_I_I_String__J(text, secondStart, secondEnd, 1, Lit_2015); var negativeSecs bool; var tmp6 bool


















				tmp6 = secondStart >= 0; if tmp6 { tmp6 = int32(text.CharAt_I__C(secondStart)) == 45 }; negativeSecs = tmp6
//line :106:1
				var nanos int32; var tmp7 int32























				if negativeSecs { tmp7 = -1 } else { tmp7 = 1 }
//line :126:1
				nanos = Duration_ParseFraction_CharSequence_I_I_I__I(text, fractionStart, fractionEnd, tmp7)
//line :106:1
				tmp8, tmp9, tmp10 := func() (ctl int32, rv *Duration, exc Throwable_I) { defer Catch(&exc); return 2, Duration_Create_Z_J_J_J_J_I__Duration(negate, daysAsSecs, hoursAsSecs, minsAsSecs, seconds, nanos), nil; return 0, nil, nil }()
























				if tmp10 != nil { if ArithmeticException_InstanceOf(tmp10) { var ex *ArithmeticException = ArithmeticException_Cast(tmp10)


					panic(Thrown(DateTimeParseException_New_String_CharSequence_I_Throwable(Lit_2016, text, 0, Up_ArithmeticException_Throwable(ex)))) } else {
//line :131:1
						panic(tmp10) } }; switch tmp8 { case 2: { return tmp9
						}
						}
			}
		}
	}


	panic(Thrown(DateTimeParseException_New_String_CharSequence_I(Lit_2017, text, 0)))
}
func Duration_CharMatch_CharSequence_I_I_C__Z(text CharSequence, start, end int32, c uint16) bool { Duration_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = start >= 0; if tmp2 { tmp2 = end == start+1 }; tmp1 = tmp2; if tmp1 { tmp1 = int32(text.CharAt_I__C(start)) == int32(c) }; return tmp1
}
func Duration_ParseNumber_CharSequence_I_I_I_String__J(text CharSequence, start, end, multiplier int32, errorText *String) int64 { Duration_Init()

	var tmp1 bool; var tmp2 bool; tmp2 = start < 0; if !tmp2 { tmp2 = end < 0 }; tmp1 = tmp2; if tmp1 { return 0 } else {

		var tmp3 int64; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
			{ var val int64 = Long_ParseLong_CharSequence_I_I_I__J(text, start, end, 10); tmp3 = Math_MultiplyExact_J_I__J(val, multiplier) }; return nil }()
//line :148:1
		if tmp4 != nil { if NumberFormatException_InstanceOf(tmp4) || ArithmeticException_InstanceOf(tmp4) { var ex RuntimeException_I = RuntimeException_Cast(tmp4)


			panic(Thrown(DateTimeParseException_New_String_CharSequence_I_Throwable(Concat(Lit_2018, errorText), text, 0, ex))) } else {
//line :148:1
				panic(tmp4) } }; return tmp3
	}
}






func Duration_ParseFraction_CharSequence_I_I_I__I(text CharSequence, start, end, negate int32) int32 { Duration_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = start < 0; if !tmp3 { tmp3 = end < 0 }; tmp2 = tmp3; if !tmp2 { tmp2 = end-start == 0 }; tmp1 = tmp2; if tmp1 { return 0 } else {

		var tmp4 int32; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)
			{ var fraction int32 = Integer_ParseInt_CharSequence_I_I_I__I(text, start, end, 10); var i int32 = end - start
			L1: for {
				if i < 9 {
					fraction = fraction * 10
					i = i + 1; continue L1 }
//line :162:1
				break L1
			}


				tmp4 = fraction * negate }; return nil }()
//line :160:1
		if tmp5 != nil { if NumberFormatException_InstanceOf(tmp5) || ArithmeticException_InstanceOf(tmp5) { var ex RuntimeException_I = RuntimeException_Cast(tmp5)







			panic(Thrown(DateTimeParseException_New_String_CharSequence_I_Throwable(Lit_2019, text, 0, ex))) } else {
//line :160:1
				panic(tmp5) } }; return tmp4
	}
}










func Duration_Create_Z_J_J_J_J_I__Duration(negate bool, daysAsSecs, hoursAsSecs, minsAsSecs, secs int64, nanos int32) *Duration { Duration_Init()

	var seconds int64 = Math_AddExact_J_J__J(daysAsSecs, Math_AddExact_J_J__J(hoursAsSecs, Math_AddExact_J_J__J(minsAsSecs, secs)))

	if negate { return NN(Duration_OfSeconds_J_J__Duration(seconds, int64(nanos))).Negated__Duration() } else { return Duration_OfSeconds_J_J__Duration(seconds, int64(nanos))
	} }
func Duration_Between_Temporal_Temporal__Duration(startInclusive, endExclusive Temporal) *Duration { Duration_Init()
	var secs int64; var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_SECONDS; secs = startInclusive.Until_Temporal_TemporalUnit__J(endExclusive, Up_ChronoUnit_TemporalUnit(tmp1))
	if secs == 0 {
		var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_NANOS; return Duration_OfNanos_J__Duration(startInclusive.Until_Temporal_TemporalUnit__J(endExclusive, Up_ChronoUnit_TemporalUnit(tmp2))) } else {
			var nanos int64 = 0; tmp6 := func() (exc Throwable_I) { defer Catch(&exc)

				{ var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_NANO_OF_SECOND; var tmp4 int64 = endExclusive.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3)); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_NANO_OF_SECOND; nanos = tmp4 - startInclusive.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp5)) }; return nil }()
//line :184:1
			if tmp6 != nil { if DateTimeException_InstanceOf(tmp6) { var ex2 DateTimeException_I = DateTimeException_Cast(tmp6); _ = ex2



				nanos = 0 } else {
//line :184:1
					panic(tmp6)
				}
			}


			var tmp7 bool; var tmp8 bool
			tmp8 = nanos < 0; if tmp8 { tmp8 = secs > 0 }; tmp7 = tmp8
//line :189:1
			if tmp7 {
				secs = secs + 1 } else {
//line :189:1
					var tmp9 bool; var tmp10 bool

					tmp10 = nanos > 0; if tmp10 { tmp10 = secs < 0 }; tmp9 = tmp10
//line :189:1
					if tmp9 {

						secs = secs - 1 } }
			return Duration_OfSeconds_J_J__Duration(secs, nanos)
		} }
func Duration_Create_J_I__Duration(seconds int64, nanoAdjustment int32) *Duration { Duration_Init()
	if seconds|int64(nanoAdjustment) == 0 { return Duration_ZERO } else { return Duration_New_J_I(seconds, nanoAdjustment)
	} }
func Duration_New_J_I(p0 int64, p1 int32) *Duration { Duration_Init(); t := &Duration{}; t.Ctor_J_I(p0, p1); return t }
//line :197:1
func (t *Duration) Ctor_J_I(seconds int64, nanos int32) {
	t.F_seconds = seconds
	t.F_nanos = nanos
}
func (t *Duration) Get_TemporalUnit__J(unit TemporalUnit) int64 {
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_SECONDS; if any(unit) == any(tmp1.Ref()) { return t.F_seconds } else { var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_NANOS; if any(unit) == any(tmp2.Ref()) { return int64(t.F_nanos) } else {


		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))
	} } }
func (t *Duration) GetUnits__List() List { Duration_DurationUnits_Init(); return Duration_DurationUnits_UNITS }






func (t *Duration) IsPositive__Z() bool {
	return t.F_seconds|int64(t.F_nanos) > 0
}
func (t *Duration) IsZero__Z() bool { return t.F_seconds|int64(t.F_nanos) == 0 }

func (t *Duration) IsNegative__Z() bool { return t.F_seconds < 0 }

func (t *Duration) GetSeconds__J() int64 { return t.F_seconds }

func (t *Duration) GetNano__I() int32 { return t.F_nanos }

func (t *Duration) WithSeconds_J__Duration(seconds int64) *Duration {
	return Duration_Create_J_I__Duration(seconds, t.F_nanos)
}
func (t *Duration) WithNanos_I__Duration(nanoOfSecond int32) *Duration {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_SECOND; NN(tmp1).CheckValidIntValue_J__I(int64(nanoOfSecond))
	return Duration_Create_J_I__Duration(t.F_seconds, nanoOfSecond)
}
func (t *Duration) Plus_Duration__Duration(duration *Duration) *Duration {
	return t.Plus_J_J__Duration(NN(duration).GetSeconds__J(), int64(NN(duration).GetNano__I()))
}
func (t *Duration) Plus_J_TemporalUnit__Duration(amountToAdd int64, unit TemporalUnit) *Duration {
	Objects_RequireNonNull_O_String__O(unit, Lit_1921)
	{ var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_DAYS; if any(unit) == any(tmp1.Ref()) {
		return t.Plus_J_J__Duration(Math_MultiplyExact_J_I__J(amountToAdd, 86400), 0) } else {

			if unit.IsDurationEstimated__Z() {
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2021))) }
			if amountToAdd == 0 { return t } else {

				var tmp2 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp2) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp2)
					switch NN(chronoUnit).F_ordinal { case 0:
						return t.PlusNanos_J__Duration(amountToAdd); case 1:

						return NN(t.PlusSeconds_J__Duration(amountToAdd / 1000000000 * 1000)).PlusNanos_J__Duration(amountToAdd % 1000000000 * 1000); case 2:










						return t.PlusMillis_J__Duration(amountToAdd); case 3:
						return t.PlusSeconds_J__Duration(amountToAdd); default:
						return t.PlusSeconds_J__Duration(Math_MultiplyExact_J_J__J(unit.GetDuration__Duration().F_seconds, amountToAdd))} } else {

							var duration *Duration = NN(unit.GetDuration__Duration()).MultipliedBy_J__Duration(amountToAdd)
							return NN(t.PlusSeconds_J__Duration(NN(duration).GetSeconds__J())).PlusNanos_J__Duration(int64(NN(duration).GetNano__I())) } } } }; panic("a2g: unreachable")
}
func (t *Duration) PlusDays_J__Duration(daysToAdd int64) *Duration {
	return t.Plus_J_J__Duration(Math_MultiplyExact_J_I__J(daysToAdd, 86400), 0)
}
func (t *Duration) PlusHours_J__Duration(hoursToAdd int64) *Duration {
	return t.Plus_J_J__Duration(Math_MultiplyExact_J_I__J(hoursToAdd, 3600), 0)
}
func (t *Duration) PlusMinutes_J__Duration(minutesToAdd int64) *Duration {
	return t.Plus_J_J__Duration(Math_MultiplyExact_J_I__J(minutesToAdd, 60), 0)
}
func (t *Duration) PlusSeconds_J__Duration(secondsToAdd int64) *Duration {
	return t.Plus_J_J__Duration(secondsToAdd, 0)
}
func (t *Duration) PlusMillis_J__Duration(millisToAdd int64) *Duration {
	var tmp1 int64 = millisToAdd / 1000; return t.Plus_J_J__Duration(tmp1, millisToAdd%1000*1000000)
}


func (t *Duration) PlusNanos_J__Duration(nanosToAdd int64) *Duration {
	return t.Plus_J_J__Duration(0, nanosToAdd)
}
func (t *Duration) Plus_J_J__Duration(secondsToAdd, nanosToAdd int64) *Duration {
	if secondsToAdd|nanosToAdd == 0 { return t } else {

		var epochSec int64 = Math_AddExact_J_J__J(t.F_seconds, secondsToAdd)
		epochSec = Math_AddExact_J_J__J(epochSec, nanosToAdd/1000000000)

		nanosToAdd = nanosToAdd % 1000000000
		var nanoAdjustment int64 = int64(t.F_nanos) + nanosToAdd
		return Duration_OfSeconds_J_J__Duration(epochSec, nanoAdjustment)
	} }
func (t *Duration) Minus_Duration__Duration(duration *Duration) *Duration {
	var secsToSubtract int64 = NN(duration).GetSeconds__J(); var nanosToSubtract int32 = NN(duration).GetNano__I()

	if secsToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_J__Duration(9223372036854775807, int64(-nanosToSubtract))).Plus_J_J__Duration(1, 0) } else {
			return t.Plus_J_J__Duration(-secsToSubtract, int64(-nanosToSubtract))
		} }
func (t *Duration) Minus_J_TemporalUnit__Duration(amountToSubtract int64, unit TemporalUnit) *Duration {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__Duration(9223372036854775807, unit)).Plus_J_TemporalUnit__Duration(1, unit) } else {
			return t.Plus_J_TemporalUnit__Duration(-amountToSubtract, unit)
		} }
func (t *Duration) MinusDays_J__Duration(daysToSubtract int64) *Duration {
	if daysToSubtract == -9223372036854775808 {
		return NN(t.PlusDays_J__Duration(9223372036854775807)).PlusDays_J__Duration(1) } else {
			return t.PlusDays_J__Duration(-daysToSubtract)
		} }
func (t *Duration) MinusHours_J__Duration(hoursToSubtract int64) *Duration {
	if hoursToSubtract == -9223372036854775808 {
		return NN(t.PlusHours_J__Duration(9223372036854775807)).PlusHours_J__Duration(1) } else {
			return t.PlusHours_J__Duration(-hoursToSubtract)
		} }
func (t *Duration) MinusMinutes_J__Duration(minutesToSubtract int64) *Duration {
	if minutesToSubtract == -9223372036854775808 {
		return NN(t.PlusMinutes_J__Duration(9223372036854775807)).PlusMinutes_J__Duration(1) } else {
			return t.PlusMinutes_J__Duration(-minutesToSubtract)
		} }
func (t *Duration) MinusSeconds_J__Duration(secondsToSubtract int64) *Duration {
	if secondsToSubtract == -9223372036854775808 {
		return NN(t.PlusSeconds_J__Duration(9223372036854775807)).PlusSeconds_J__Duration(1) } else {
			return t.PlusSeconds_J__Duration(-secondsToSubtract)
		} }
func (t *Duration) MinusMillis_J__Duration(millisToSubtract int64) *Duration {
	if millisToSubtract == -9223372036854775808 {
		return NN(t.PlusMillis_J__Duration(9223372036854775807)).PlusMillis_J__Duration(1) } else {
			return t.PlusMillis_J__Duration(-millisToSubtract)
		} }
func (t *Duration) MinusNanos_J__Duration(nanosToSubtract int64) *Duration {
	if nanosToSubtract == -9223372036854775808 {
		return NN(t.PlusNanos_J__Duration(9223372036854775807)).PlusNanos_J__Duration(1) } else {
			return t.PlusNanos_J__Duration(-nanosToSubtract)
		} }
func (t *Duration) MultipliedBy_J__Duration(multiplicand int64) *Duration {
	if multiplicand == 0 { return Duration_ZERO } else { if multiplicand == 1 { return t } else {



		return Duration_Create_BigDecimal__Duration(NN(t.ToBigDecimalSeconds__BigDecimal()).Multiply_BigDecimal__BigDecimal(BigDecimal_ValueOf_J__BigDecimal(multiplicand)))
	} } }
func (t *Duration) DividedBy_J__Duration(divisor int64) *Duration {
	if divisor == 0 { panic(Thrown(ArithmeticException_New_String(Lit_2022))) }
	if divisor == 1 { return t } else {

		var tmp1 *BigDecimal = t.ToBigDecimalSeconds__BigDecimal(); var tmp2 *BigDecimal = BigDecimal_ValueOf_J__BigDecimal(divisor); var tmp3 *RoundingMode; RoundingMode_Init(); tmp3 = RoundingMode_DOWN; return Duration_Create_BigDecimal__Duration(NN(tmp1).Divide_BigDecimal_RoundingMode__BigDecimal(tmp2, tmp3))
	}
}
func (t *Duration) DividedBy_Duration__J(divisor *Duration) int64 {
	Objects_RequireNonNull_O_String__O(divisor.Ref(), Lit_2023)
	var dividendBigD *BigDecimal = t.ToBigDecimalSeconds__BigDecimal(); var divisorBigD *BigDecimal = NN(divisor).ToBigDecimalSeconds__BigDecimal()

	return NN(NN(dividendBigD).DivideToIntegralValue_BigDecimal__BigDecimal(divisorBigD)).LongValueExact__J()
}
func (t *Duration) ToBigDecimalSeconds__BigDecimal() *BigDecimal {
	return NN(BigDecimal_ValueOf_J__BigDecimal(t.F_seconds)).Add_BigDecimal__BigDecimal(BigDecimal_ValueOf_J_I__BigDecimal(int64(t.F_nanos), 9))
}
func Duration_Create_BigDecimal__Duration(seconds *BigDecimal) *Duration { Duration_Init()
	var nanos *BigInteger = NN(NN(seconds).MovePointRight_I__BigDecimal(9)).ToBigIntegerExact__BigInteger(); var divRem *RefArray = NN(nanos).DivideAndRemainder_BigInteger__BigInteger1(Duration_BI_NANOS_PER_SECOND)

	if NN(As[*BigInteger](divRem.A[0])).BitLength__I() > 63 {
		panic(Thrown(ArithmeticException_New_String(Concat(Lit_2024, StrOfObj(nanos.Ref()))))) }
	return Duration_OfSeconds_J_J__Duration(NN(As[*BigInteger](divRem.A[0])).LongValue__J(), int64(NN(As[*BigInteger](divRem.A[1])).IntValue__I()))
}
func (t *Duration) Negated__Duration() *Duration { return t.MultipliedBy_J__Duration(-1) }

func (t *Duration) Abs__Duration() *Duration {
	if t.IsNegative__Z() { return t.Negated__Duration() } else { return t
	} }
func (t *Duration) AddTo_Temporal__Temporal(temporal Temporal) Temporal {
	if t.F_seconds == 0 { } else { var tmp1 Temporal = temporal; var tmp2 int64 = t.F_seconds; var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_SECONDS; temporal = tmp1.Plus_J_TemporalUnit__Temporal(tmp2, Up_ChronoUnit_TemporalUnit(tmp3)) }
	if t.F_nanos == 0 { } else { var tmp4 Temporal = temporal; var tmp5 int64 = int64(t.F_nanos); var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_NANOS; temporal = tmp4.Plus_J_TemporalUnit__Temporal(tmp5, Up_ChronoUnit_TemporalUnit(tmp6)) }
//line :373:1
	return temporal
}



func (t *Duration) SubtractFrom_Temporal__Temporal(temporal Temporal) Temporal {
	if t.F_seconds == 0 { } else { var tmp1 Temporal = temporal; var tmp2 int64 = t.F_seconds; var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_SECONDS; temporal = tmp1.Minus_J_TemporalUnit__Temporal(tmp2, Up_ChronoUnit_TemporalUnit(tmp3)) }
	if t.F_nanos == 0 { } else { var tmp4 Temporal = temporal; var tmp5 int64 = int64(t.F_nanos); var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_NANOS; temporal = tmp4.Minus_J_TemporalUnit__Temporal(tmp5, Up_ChronoUnit_TemporalUnit(tmp6)) }
//line :378:1
	return temporal
}



func (t *Duration) ToDays__J() int64 {
	return t.F_seconds / 86400
}
func (t *Duration) ToHours__J() int64 {
	return t.F_seconds / 3600
}
func (t *Duration) ToMinutes__J() int64 {
	return t.F_seconds / 60
}
func (t *Duration) ToSeconds__J() int64 { return t.F_seconds }

func (t *Duration) ToMillis__J() int64 {
	var tempSeconds int64 = t.F_seconds; var tempNanos int64 = int64(t.F_nanos)

	if tempSeconds < 0 {
		tempSeconds = tempSeconds + 1
		tempNanos = tempNanos - 1000000000 }
	var millis int64 = Math_MultiplyExact_J_I__J(tempSeconds, 1000)
	millis = Math_AddExact_J_J__J(millis, tempNanos/1000000)
//line :400:1
	return millis
}


func (t *Duration) ToNanos__J() int64 {
	var tempSeconds int64 = t.F_seconds; var tempNanos int64 = int64(t.F_nanos)

	if tempSeconds < 0 {
		tempSeconds = tempSeconds + 1
		tempNanos = tempNanos - 1000000000 }
	var totalNanos int64 = Math_MultiplyExact_J_J__J(tempSeconds, 1000000000)
	totalNanos = Math_AddExact_J_J__J(totalNanos, tempNanos)
//line :410:1
	return totalNanos
}


func (t *Duration) ToDaysPart__J() int64 {
	return t.F_seconds / 86400
}
func (t *Duration) ToHoursPart__I() int32 {
	return int32(t.ToHours__J() % 24)
}
func (t *Duration) ToMinutesPart__I() int32 {
	return int32(t.ToMinutes__J() % 60)
}
func (t *Duration) ToSecondsPart__I() int32 {
	return int32(t.F_seconds % 60)
}
func (t *Duration) ToMillisPart__I() int32 {
	return t.F_nanos / 1000000
}
func (t *Duration) ToNanosPart__I() int32 { return t.F_nanos }

func (t *Duration) TruncatedTo_TemporalUnit__Duration(unit TemporalUnit) *Duration {
	Objects_RequireNonNull_O_String__O(unit, Lit_1921)
	var tmp1 bool; var tmp2 bool; var tmp3 *ChronoUnit
	ChronoUnit_Init(); tmp3 = ChronoUnit_SECONDS; tmp2 = any(unit) == any(tmp3.Ref()); if tmp2 { var tmp4 bool; tmp4 = t.F_seconds >= 0; if !tmp4 { tmp4 = t.F_nanos == 0 }; tmp2 = tmp4 }; tmp1 = tmp2
//line :433:1
	if tmp1 {

		return Duration_New_J_I(t.F_seconds, 0) } else {
//line :433:1
			var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_NANOS; if any(unit) == any(tmp5.Ref()) { return t } else {




				var unitDur *Duration = unit.GetDuration__Duration()
				if NN(unitDur).GetSeconds__J() > 86400 {
					panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2025)))
				}
				var dur int64 = NN(unitDur).ToNanos__J()
				if 86400000000000%dur == 0 { } else {
					panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2026)))
				}
				var nod int64 = t.F_seconds%86400*1000000000 + int64(t.F_nanos); var result int64 = nod / dur * dur




				return t.PlusNanos_J__Duration(result - nod)
			} } }
func (t *Duration) CompareTo_Duration__I(otherDuration *Duration) int32 {
	var tmp1 int64 = t.F_seconds; var cmp int32 = Long_Compare_J_J__I(tmp1, otherDuration.F_seconds)
	if !(cmp == 0) { return cmp } else { var tmp2 int32 = t.F_nanos; return tmp2 - otherDuration.F_nanos
	} }
func (t *Duration) Equals_O__Z(other any) bool {
	if any(t) == any(other) { return true } else {

		var tmp1 any = other; if Duration_InstanceOf(tmp1) { var otherDuration *Duration = Duration_Cast(tmp1); var tmp2 int64 = t.F_seconds
			if tmp2 == otherDuration.F_seconds {
				var tmp3 int32 = t.F_nanos; return tmp3 == otherDuration.F_nanos } else {
//line :461:1
					return false } } else {
//line :460:1
						return false
					}
	}
}


func (t *Duration) HashCode__I() int32 {
	return Long_HashCode_J__I(t.F_seconds) + 51*t.F_nanos
}
func (t *Duration) ToString__String() *String {
	if t == Duration_ZERO { return Lit_2027 } else {

		var effectiveTotalSecs int64 = t.F_seconds; var tmp1 bool; var tmp2 bool
		tmp2 = t.F_seconds < 0; if tmp2 { tmp2 = t.F_nanos > 0 }; tmp1 = tmp2; if tmp1 {
			effectiveTotalSecs = effectiveTotalSecs + 1 }
		var hours int64 = effectiveTotalSecs / 3600; var minutes int32 = int32(effectiveTotalSecs % 3600 / 60); var secs int32 = int32(effectiveTotalSecs % 60); var buf *StringBuilder = StringBuilder_New_I(24)







		NN(buf).Append_String__StringBuilder(Lit_2028)
		if hours == 0 { } else { NN(NN(buf).Append_J__StringBuilder(hours)).Append_C__StringBuilder(72) }
		if minutes == 0 { } else { NN(NN(buf).Append_I__StringBuilder(minutes)).Append_C__StringBuilder(77) }
		var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = secs == 0; if tmp5 { tmp5 = t.F_nanos == 0 }; tmp4 = tmp5; if tmp4 { tmp4 = NN(buf).Length__I() > 2 }; tmp3 = tmp4; if tmp3 {
			return NN(buf).ToString__String() } else {

				var tmp6 bool; var tmp7 bool; tmp7 = t.F_seconds < 0; if tmp7 { tmp7 = t.F_nanos > 0 }; tmp6 = tmp7; if tmp6 {
					if secs == 0 { NN(buf).Append_String__StringBuilder(Lit_2029) } else { NN(buf).Append_I__StringBuilder(secs) } } else {
						NN(buf).Append_I__StringBuilder(secs) }
				if t.F_nanos > 0 {
					var pos int32 = NN(buf).Length__I()
					if t.F_seconds < 0 {
						NN(buf).Append_J__StringBuilder(2000000000 - int64(t.F_nanos)) } else {



							NN(buf).Append_J__StringBuilder(int64(t.F_nanos) + 1000000000) }
				L1: for { if int32(NN(buf).CharAt_I__C(NN(buf).Length__I()-1)) == 48 {
					NN(buf).SetLength_I__V(NN(buf).Length__I() - 1)
//line :500:1
					continue L1 }; break L1
				}
					NN(buf).SetCharAt_I_C__V(pos, 46) }
				NN(buf).Append_C__StringBuilder(83)
				return NN(buf).ToString__String()
			} } }
func (t *Duration) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.Duration.writeReplace()Ljava/lang/Object;")) }








func Duration_ReadExternal_DataInput__Duration(p0 DataInput) *Duration { Duration_Init(); panic(A2g_NotTranslated("java.time.Duration.readExternal(Ljava/io/DataInput;)Ljava/time/Duration;")) }



type Duration struct{ Object; F_seconds int64; F_nanos int32 }

func (t *Duration) Is_TemporalAmount() {}

func (t *Duration) Is_Comparable() {}

func (t *Duration) Is_Serializable() {}

var Duration_ZERO *Duration

var Duration_MIN *Duration

var Duration_MAX *Duration

const Duration_serialVersionUID int64 = 3078945930695997490

var Duration_BI_NANOS_PER_SECOND *BigInteger

var Duration_init ClassInit

func Duration_Init() { if !Duration_init.Done() { Duration_init.Run(Duration_clinit) } }

func Duration_clinit() { Duration_ZERO = Duration_New_J_I(0, 0); Duration_MIN = Duration_New_J_I(-9223372036854775808, 0); Duration_MAX = Duration_New_J_I(9223372036854775807, 999999999); Duration_BI_NANOS_PER_SECOND = BigInteger_ValueOf_J__BigInteger(1000000000) }

func (t *Duration) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Duration__I(Duration_Cast(p0)) }

func (t *Duration) Ref() any { if t == nil { return nil }; return t }

func (t *Duration) GetClass__Class() *Class { return Duration_class }

func (t *Duration) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Duration) CloneShallow() any { panic(CloneNotSupported(t)) }

func Duration_InstanceOf(x any) bool { _, ok := x.(*Duration); return ok }

func Duration_Cast(x any) *Duration { if x == nil { return nil }; v, ok := x.(*Duration); if !ok { panic(ClassCast(x, Duration_class)) }; return v }



type Duration_DurationUnits struct{ Object }

var Duration_DurationUnits_UNITS List

var Duration_DurationUnits_init ClassInit

func Duration_DurationUnits_Init() { if !Duration_DurationUnits_init.Done() { Duration_DurationUnits_init.Run(Duration_DurationUnits_clinit) } }

func Duration_DurationUnits_clinit() { var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_SECONDS; var tmp2 any = tmp1.Ref(); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_NANOS; Duration_DurationUnits_UNITS = List_Of_O_O__List(tmp2, tmp3.Ref()) }

func Duration_DurationUnits_New() *Duration_DurationUnits { Duration_DurationUnits_Init(); t := &Duration_DurationUnits{}; t.Ctor(); return t }

func (t *Duration_DurationUnits) Ctor() {}

func (t *Duration_DurationUnits) Ref() any { if t == nil { return nil }; return t }

func (t *Duration_DurationUnits) GetClass__Class() *Class { return Duration_DurationUnits_class }

func (t *Duration_DurationUnits) ToString__String() *String { return Object_toString(t) }

func (t *Duration_DurationUnits) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Duration_DurationUnits) CloneShallow() any { panic(CloneNotSupported(t)) }

func Duration_DurationUnits_InstanceOf(x any) bool { _, ok := x.(*Duration_DurationUnits); return ok }

func Duration_DurationUnits_Cast(x any) *Duration_DurationUnits { if x == nil { return nil }; v, ok := x.(*Duration_DurationUnits); if !ok { panic(ClassCast(x, Duration_DurationUnits_class)) }; return v }



type Duration_Lazy struct{ Object }

var Duration_Lazy_PATTERN *Pattern

var Duration_Lazy_init ClassInit

func Duration_Lazy_Init() { if !Duration_Lazy_init.Done() { Duration_Lazy_init.Run(Duration_Lazy_clinit) } }

func Duration_Lazy_clinit() { Duration_Lazy_PATTERN = Pattern_Compile_String_I__Pattern(Lit_2030, 2) }

func Duration_Lazy_New() *Duration_Lazy { Duration_Lazy_Init(); t := &Duration_Lazy{}; t.Ctor(); return t }

func (t *Duration_Lazy) Ctor() {}

func (t *Duration_Lazy) Ref() any { if t == nil { return nil }; return t }

func (t *Duration_Lazy) GetClass__Class() *Class { return Duration_Lazy_class }

func (t *Duration_Lazy) ToString__String() *String { return Object_toString(t) }

func (t *Duration_Lazy) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Duration_Lazy) CloneShallow() any { panic(CloneNotSupported(t)) }

func Duration_Lazy_InstanceOf(x any) bool { _, ok := x.(*Duration_Lazy); return ok }

func Duration_Lazy_Cast(x any) *Duration_Lazy { if x == nil { return nil }; v, ok := x.(*Duration_Lazy); if !ok { panic(ClassCast(x, Duration_Lazy_class)) }; return v }
