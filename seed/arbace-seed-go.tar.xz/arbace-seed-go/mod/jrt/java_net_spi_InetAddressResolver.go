//line java_net_spi_InetAddressResolver.ae:1
package jrt
























func InetAddressResolver_LookupPolicy_New_I(p0 int32) *InetAddressResolver_LookupPolicy { t := &InetAddressResolver_LookupPolicy{}; t.Ctor_I(p0); return t }
//line :26:1
func (t *InetAddressResolver_LookupPolicy) Ctor_I(characteristics int32) {
	t.F_characteristics = characteristics
}
func InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(characteristics int32) *InetAddressResolver_LookupPolicy {
	var tmp1 bool; var tmp2 bool; tmp2 = characteristics&1 == 0; if tmp2 {
		tmp2 = characteristics&2 == 0 }
//line :30:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1473))) }
	var tmp3 bool; var tmp4 bool; tmp4 = !(characteristics&4 == 0); if tmp4 {
		tmp4 = !(characteristics&8 == 0) }
//line :33:1
	tmp3 = tmp4; if tmp3 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1474))) }
	var tmp5 bool; var tmp6 bool; tmp6 = !(characteristics&4 == 0); if tmp6 {
		tmp6 = characteristics&1 == 0 }
//line :36:1
	tmp5 = tmp6; if tmp5 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1475))) }
	var tmp7 bool; var tmp8 bool; tmp8 = !(characteristics&8 == 0); if tmp8 {
		tmp8 = characteristics&2 == 0 }
//line :39:1
	tmp7 = tmp8; if tmp7 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1475))) }
	return InetAddressResolver_LookupPolicy_New_I(characteristics)
}
func (t *InetAddressResolver_LookupPolicy) Characteristics__I() int32 { return t.F_characteristics }



type InetAddressResolver interface{ Object_I; Is_InetAddressResolver(); LookupByName_String_InetAddressResolver_LookupPolicy__Stream(p0 *String, p1 *InetAddressResolver_LookupPolicy) Stream; LookupByAddress_B1__String(p0 *ByteArray) *String }

func InetAddressResolver_InstanceOf(x any) bool { _, ok := x.(InetAddressResolver); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InetAddressResolver_class) } }; return ok }

func InetAddressResolver_Cast(x any) InetAddressResolver { if x == nil { return nil }; v, ok := x.(InetAddressResolver); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InetAddressResolver_class) } }; if !ok { panic(ClassCast(x, InetAddressResolver_class)) }; return v }



type InetAddressResolver_LookupPolicy struct{ Object; F_characteristics int32 }

const InetAddressResolver_LookupPolicy_IPV4 int32 = 1

const InetAddressResolver_LookupPolicy_IPV6 int32 = 2

const InetAddressResolver_LookupPolicy_IPV4_FIRST int32 = 4

const InetAddressResolver_LookupPolicy_IPV6_FIRST int32 = 8

func (t *InetAddressResolver_LookupPolicy) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddressResolver_LookupPolicy) GetClass__Class() *Class { return InetAddressResolver_LookupPolicy_class }

func (t *InetAddressResolver_LookupPolicy) ToString__String() *String { return Object_toString(t) }

func (t *InetAddressResolver_LookupPolicy) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddressResolver_LookupPolicy) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddressResolver_LookupPolicy_InstanceOf(x any) bool { _, ok := x.(*InetAddressResolver_LookupPolicy); return ok }

func InetAddressResolver_LookupPolicy_Cast(x any) *InetAddressResolver_LookupPolicy { if x == nil { return nil }; v, ok := x.(*InetAddressResolver_LookupPolicy); if !ok { panic(ClassCast(x, InetAddressResolver_LookupPolicy_class)) }; return v }
