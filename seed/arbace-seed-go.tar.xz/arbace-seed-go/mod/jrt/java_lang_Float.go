//line java_lang_Float.ae:1
package jrt











































func Float_ToString_F__String(f float32) *String { Float_Init()
	return FloatToDecimal_ToString_F__String(f)
}
func Float_ToHexString_F__String(f float32) *String { Float_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = Math_Abs_F__F(f) < 1.1754944e-38; if tmp2 { tmp2 = !(f == 0.0) }; tmp1 = tmp2; if tmp1 {
		var s *String = Double_ToHexString_D__String(Math_Scalb_D_I__D(float64(f), -896))


		return NN(s).Replace_CharSequence_CharSequence__String(Lit_1119, Lit_1120) } else {
			return Double_ToHexString_D__String(float64(f))
		} }
func Float_ValueOf_String__Float(s *String) *Float { Float_Init()
	return Float_New_F(Float_ParseFloat_String__F(s))
}
func Float_ValueOf_F__Float(f float32) *Float { Float_Init()
	return Float_New_F(f)
}
func Float_ParseFloat_String__F(s *String) float32 { Float_Init()
	return FloatingDecimal_ParseFloat_String__F(s)
}
func Float_IsNaN_F__Z(v float32) bool { Float_Init(); return !(v == v) }

func Float_IsInfinite_F__Z(v float32) bool { Float_Init()
	return Math_Abs_F__F(v) > 3.4028235e38
}
func Float_IsFinite_F__Z(f float32) bool { Float_Init()
	return Math_Abs_F__F(f) <= 3.4028235e38
}


func Float_New_F(p0 float32) *Float { Float_Init(); t := &Float{}; t.Ctor_F(p0); return t }
//line :75:1
func (t *Float) Ctor_F(value float32) { t.Number.Ctor(t)
	t.F_value = value
}
func Float_New_D(p0 float64) *Float { Float_Init(); t := &Float{}; t.Ctor_D(p0); return t }
//line :78:1
func (t *Float) Ctor_D(value float64) { t.Number.Ctor(t)
	t.F_value = float32(value)
}
func Float_New_String(p0 *String) *Float { Float_Init(); t := &Float{}; t.Ctor_String(p0); return t }
//line :81:1
func (t *Float) Ctor_String(s *String) { t.Number.Ctor(t)
	t.F_value = Float_ParseFloat_String__F(s)
}
func (t *Float) IsNaN__Z() bool { return Float_IsNaN_F__Z(t.F_value) }

func (t *Float) IsInfinite__Z() bool { return Float_IsInfinite_F__Z(t.F_value) }

func (t *Float) ToString__String() *String { return Float_ToString_F__String(t.F_value) }

func (t *Float) ByteValue__B() int8 { return int8(F2I(t.F_value)) }

func (t *Float) ShortValue__S() int16 { return int16(F2I(t.F_value)) }

func (t *Float) IntValue__I() int32 { return F2I(t.F_value) }

func (t *Float) LongValue__J() int64 { return F2L(t.F_value) }

func (t *Float) FloatValue__F() float32 { return t.F_value }


func (t *Float) DoubleValue__D() float64 { return float64(t.F_value) }

func (t *Float) HashCode__I() int32 { return Float_HashCode_F__I(t.F_value) }

func Float_HashCode_F__I(value float32) int32 { Float_Init()
	return Float_FloatToIntBits_F__I(value)
}
func (t *Float) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Float_InstanceOf(tmp1) { var f *Float = Float_Cast(tmp1)
		return Float_FloatToIntBits_F__I(f.F_value) == Float_FloatToIntBits_F__I(t.F_value) } else {
//line :109:1
			return false
		}
}

func Float_FloatToIntBits_F__I(value float32) int32 { Float_Init()
	if !Float_IsNaN_F__Z(value) { return Float_FloatToRawIntBits_F__I(value) } else { return 2143289344
	} }
func Float_FloatToRawIntBits_F__I(p0 float32) int32 { return Float_FloatToRawIntBits_F__I_native(p0) }

func Float_IntBitsToFloat_I__F(p0 int32) float32 { return Float_IntBitsToFloat_I__F_native(p0) }

func Float_Float16ToFloat_S__F(floatBinary16 int16) float32 { Float_Init()
	var bin16arg int32 = int32(floatBinary16); var bin16SignBit int32 = 32768 & bin16arg; var bin16ExpBits int32 = 31744 & bin16arg; var bin16SignifBits int32 = 1023 & bin16arg; var sign float32




	if !(bin16SignBit == 0) {
		sign = -1.0 } else {
			sign = 1.0 }
//line :121:1
	var bin16Exp int32 = bin16ExpBits>>10 - 15








	if bin16Exp == -15 {

		return float32(sign * float32(5.9604645e-8*float32(bin16SignifBits))) } else {
//line :130:1
			if bin16Exp == 16 {




				if bin16SignifBits == 0 {
					return float32(sign * PosInf32) } else {
						return Float_IntBitsToFloat_I__F(bin16SignBit<<16 | 2139095040 | bin16SignifBits<<13) } } else {




							var tmp1 bool; var tmp2 bool; tmp2 = -15 < bin16Exp; if tmp2 { tmp2 = bin16Exp < 16 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
							var floatExpBits int32 = (bin16Exp + 127) << 23


							return Float_IntBitsToFloat_I__F(bin16SignBit<<16 | floatExpBits | bin16SignifBits<<13)
						}
		}
}
func Float_FloatToFloat16_F__S(f float32) int16 { Float_Init()
	var doppel int32 = Float_FloatToRawIntBits_F__I(f); var sign_bit int16 = int16(doppel & -2147483648 >> 16)


	if Float_IsNaN_F__Z(f) {
		return int16(int32(sign_bit) | 31744 | doppel&8380416>>13 | doppel&8176>>4 | doppel&15) } else {






			var abs_f float32 = Math_Abs_F__F(f)
			if abs_f >= 65520.0 {

				return int16(int32(sign_bit) | 31744) } else {
//line :163:1
					if abs_f <= 2.9802322e-8 { return sign_bit } else {




						var exp int32 = Math_GetExponent_F__I(f); var tmp1 bool; var tmp2 bool
						tmp2 = -25 <= exp; if tmp2 { tmp2 = exp <= 15 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
						var expdelta int32 = 0
						var msb int32 = 0
						if exp < -14 {
							expdelta = -14 - exp
							exp = -15
							msb = 8388608 }
						var f_signif_bits int32 = doppel&8388607 | msb; var signif_bits int16 = int16(f_signif_bits >> ((13 + expdelta) & 31)); var lsb int32 = f_signif_bits & (1 << ((13 + expdelta) & 31)); var round int32 = f_signif_bits & (1 << ((12 + expdelta) & 31)); var sticky int32 = f_signif_bits & (1<<((12+expdelta)&31) - 1); var tmp3 bool; var tmp4 bool














						tmp4 = !(round == 0); if tmp4 { tmp4 = !(lsb|sticky == 0) }; tmp3 = tmp4; if tmp3 {
							signif_bits = int16(int32(signif_bits) + 1) }
						if !A2g_AssertionsDisabled && !(63488&int32(signif_bits) == 0) { panic(Thrown(AssertionError_New())) }
						return int16(int32(sign_bit) | ((exp+15)<<10 + int32(signif_bits)))
					}
				}
		}
}

func (t *Float) CompareTo_Float__I(anotherFloat *Float) int32 {
	var tmp1 float32 = t.F_value; return Float_Compare_F_F__I(tmp1, anotherFloat.F_value)
}
func Float_Compare_F_F__I(f1, f2 float32) int32 { Float_Init()
	if f1 < f2 { return -1 } else { if f1 > f2 { return 1 } else {



		var thisBits int32 = Float_FloatToIntBits_F__I(f1); var anotherBits int32 = Float_FloatToIntBits_F__I(f2)

		if thisBits == anotherBits { return 0 } else { if thisBits < anotherBits { return -1 } else { return 1
		} } } } }
func Float_Sum_F_F__F(a, b float32) float32 { Float_Init()
	return a + b
}
func Float_Max_F_F__F(a, b float32) float32 { Float_Init(); return Math_Max_F_F__F(a, b) }

func Float_Min_F_F__F(a, b float32) float32 { Float_Init(); return Math_Min_F_F__F(a, b) }

func (t *Float) DescribeConstable__Optional() *Optional {
	return Optional_Of_O__Optional(t)
}


type Float struct{ Number; F_value float32 }

func (t *Float) Is_Comparable() {}

func (t *Float) Is_Constable() {}

func (t *Float) Is_ConstantDesc() {}

var Float_POSITIVE_INFINITY float32 = PosInf32

var Float_NEGATIVE_INFINITY float32 = NegInf32

var Float_NaN float32 = NaN32

const Float_MAX_VALUE float32 = 3.4028235e38

const Float_MIN_NORMAL float32 = 1.1754944e-38

const Float_MIN_VALUE float32 = 1.4e-45

const Float_SIZE int32 = 32

const Float_PRECISION int32 = 24

const Float_MAX_EXPONENT int32 = 127

const Float_MIN_EXPONENT int32 = -126

const Float_BYTES int32 = 4

var Float_TYPE *Class

const Float_serialVersionUID int64 = -2671257302660747028

var Float_init ClassInit

func Float_Init() { if !Float_init.Done() { Float_init.Run(Float_clinit) } }

func Float_clinit() { Float_TYPE = Class_GetPrimitiveClass_String__Class(Lit_1118) }

func (t *Float) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Float__I(Float_Cast(p0)) }

func (t *Float) Ref() any { if t == nil { return nil }; return t }

func (t *Float) GetClass__Class() *Class { return Float_class }

func (t *Float) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Float) CloneShallow() any { panic(CloneNotSupported(t)) }

func Float_InstanceOf(x any) bool { _, ok := x.(*Float); return ok }

func Float_Cast(x any) *Float { if x == nil { return nil }; v, ok := x.(*Float); if !ok { panic(ClassCast(x, Float_class)) }; return v }
