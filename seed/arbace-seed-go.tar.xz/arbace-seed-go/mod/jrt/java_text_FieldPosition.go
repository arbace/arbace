//line java_text_FieldPosition.ae:1
package jrt














func FieldPosition_New_I(p0 int32) *FieldPosition { t := &FieldPosition{}; t.Ctor_I(t, p0); return t }
//line :16:1
func (t *FieldPosition) Ctor_I(this FieldPosition_I, field int32) { t.F_field = 0; t.F_endIndex = 0; t.F_beginIndex = 0; t.F_field = field }

func FieldPosition_New_Format_Field(p0 Format_Field_I) *FieldPosition { t := &FieldPosition{}; t.Ctor_Format_Field(t, p0); return t }
//line :18:1
func (t *FieldPosition) Ctor_Format_Field(this FieldPosition_I, attribute Format_Field_I) { t.Ctor_Format_Field_I(this, attribute, -1) }


func FieldPosition_New_Format_Field_I(p0 Format_Field_I, p1 int32) *FieldPosition { t := &FieldPosition{}; t.Ctor_Format_Field_I(t, p0, p1); return t }
//line :21:1
func (t *FieldPosition) Ctor_Format_Field_I(this FieldPosition_I, attribute Format_Field_I, fieldID int32) { t.F_field = 0; t.F_endIndex = 0; t.F_beginIndex = 0
	t.F_attribute = attribute
	t.F_field = fieldID
}
func (t *FieldPosition) Impl_GetFieldAttribute__Format_Field(this FieldPosition_I) Format_Field_I { return t.F_attribute }

func (t *FieldPosition) Impl_GetField__I(this FieldPosition_I) int32 { return t.F_field }

func (t *FieldPosition) Impl_GetBeginIndex__I(this FieldPosition_I) int32 { return t.F_beginIndex }

func (t *FieldPosition) Impl_GetEndIndex__I(this FieldPosition_I) int32 { return t.F_endIndex }

func (t *FieldPosition) Impl_SetBeginIndex_I__V(this FieldPosition_I, bi int32) {
	t.F_beginIndex = bi
}
func (t *FieldPosition) Impl_SetEndIndex_I__V(this FieldPosition_I, ei int32) { t.F_endIndex = ei }

func (t *FieldPosition) Impl_GetFieldDelegate__Format_FieldDelegate(this FieldPosition_I) Format_FieldDelegate { return FieldPosition_Delegate_New_FieldPosition(this) }

func (t *FieldPosition) Impl_Equals_O__Z(this FieldPosition_I, obj any) bool {
	var tmp1 any = obj; if FieldPosition_InstanceOf(tmp1) { var other FieldPosition_I = FieldPosition_Cast(tmp1); var tmp2 any = t.F_attribute
		if !Objects_Equals_O_O__Z(tmp2, other.Self_FieldPosition().F_attribute) { return false } else {

			var tmp3 bool; var tmp4 bool; var tmp5 int32 = t.F_beginIndex; tmp4 = tmp5 == other.Self_FieldPosition().F_beginIndex; if tmp4 { var tmp6 int32 = t.F_endIndex; tmp4 = tmp6 == other.Self_FieldPosition().F_endIndex }; tmp3 = tmp4; if tmp3 {
				var tmp7 int32 = t.F_field; tmp3 = tmp7 == other.Self_FieldPosition().F_field }
//line :44:1
			return tmp3 } } else {
//line :41:1
				return false
			}
}




func (t *FieldPosition) Impl_HashCode__I(this FieldPosition_I) int32 {
	return t.F_field<<24 | t.F_beginIndex<<16 | t.F_endIndex
}

func (t *FieldPosition) Impl_ToString__String(this FieldPosition_I) *String {
	return Concat(NN(this.GetClass__Class()).GetName__String(), Lit_1846, StrOfInt(t.F_field), Lit_1847, StrOfObj(t.F_attribute), Lit_1848, StrOfInt(t.F_beginIndex), Lit_1849, StrOfInt(t.F_endIndex), Lit_1189)
}









func (t *FieldPosition) Impl_MatchesField_Format_Field__Z(this FieldPosition_I, attribute Format_Field_I) bool {
	if !(t.F_attribute == nil) { return t.F_attribute.Equals_O__Z(attribute) } else { return false
	} }
func (t *FieldPosition) Impl_MatchesField_Format_Field_I__Z(this FieldPosition_I, attribute Format_Field_I, field int32) bool {
	if !(t.F_attribute == nil) { return t.F_attribute.Equals_O__Z(attribute) } else { return field == t.F_field
	}
}




func (t *FieldPosition_Delegate) Formatted_Format_Field_O_I_I_Format_StringBuf__V(attr Format_Field_I, value any, start, end int32, buffer Format_StringBuf) {

	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_encounteredField; if tmp2 { tmp2 = t.F_this_0.Self_FieldPosition().Impl_MatchesField_Format_Field__Z(t.F_this_0, attr) }; tmp1 = tmp2; if tmp1 {
		t.F_this_0.SetBeginIndex_I__V(start)
		t.F_this_0.SetEndIndex_I__V(end)
		t.F_encounteredField = !(start == end)
	} }
func (t *FieldPosition_Delegate) Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(fieldID int32, attr Format_Field_I, value any, start, end int32, buffer Format_StringBuf) {

	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_encounteredField; if tmp2 { tmp2 = t.F_this_0.Self_FieldPosition().Impl_MatchesField_Format_Field_I__Z(t.F_this_0, attr, fieldID) }; tmp1 = tmp2; if tmp1 {
		t.F_this_0.SetBeginIndex_I__V(start)
		t.F_this_0.SetEndIndex_I__V(end)
		t.F_encounteredField = !(start == end)
	}
}

type FieldPosition struct{ Object; F_field, F_endIndex, F_beginIndex int32; F_attribute Format_Field_I }

type FieldPosition_I interface{ Object_I; Self_FieldPosition() *FieldPosition; GetFieldAttribute__Format_Field() Format_Field_I; GetField__I() int32; GetBeginIndex__I() int32; GetEndIndex__I() int32; SetBeginIndex_I__V(p0 int32); SetEndIndex_I__V(p0 int32); GetFieldDelegate__Format_FieldDelegate() Format_FieldDelegate }

func (t *FieldPosition) Self_FieldPosition() *FieldPosition { return t }

func (t *FieldPosition) GetFieldAttribute__Format_Field() Format_Field_I { return t.Impl_GetFieldAttribute__Format_Field(t) }

func (t *FieldPosition) GetField__I() int32 { return t.Impl_GetField__I(t) }

func (t *FieldPosition) GetBeginIndex__I() int32 { return t.Impl_GetBeginIndex__I(t) }

func (t *FieldPosition) GetEndIndex__I() int32 { return t.Impl_GetEndIndex__I(t) }

func (t *FieldPosition) SetBeginIndex_I__V(p0 int32) { t.Impl_SetBeginIndex_I__V(t, p0) }

func (t *FieldPosition) SetEndIndex_I__V(p0 int32) { t.Impl_SetEndIndex_I__V(t, p0) }

func (t *FieldPosition) GetFieldDelegate__Format_FieldDelegate() Format_FieldDelegate { return t.Impl_GetFieldDelegate__Format_FieldDelegate(t) }

func (t *FieldPosition) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *FieldPosition) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *FieldPosition) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *FieldPosition) Ref() any { if t == nil { return nil }; return t }

func (t *FieldPosition) GetClass__Class() *Class { return FieldPosition_class }

func (t *FieldPosition) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FieldPosition) CloneShallow() any { panic(CloneNotSupported(t)) }

func FieldPosition_InstanceOf(x any) bool { _, ok := x.(FieldPosition_I); return ok }

func FieldPosition_Cast(x any) FieldPosition_I { if x == nil { return nil }; v, ok := x.(FieldPosition_I); if !ok { panic(ClassCast(x, FieldPosition_class)) }; return v }



type FieldPosition_Delegate struct{ Object; F_encounteredField bool; F_this_0 FieldPosition_I }

func (t *FieldPosition_Delegate) Is_Format_FieldDelegate() {}

func FieldPosition_Delegate_New_FieldPosition(p0 FieldPosition_I) *FieldPosition_Delegate { t := &FieldPosition_Delegate{}; t.Ctor_FieldPosition(p0); return t }

func (t *FieldPosition_Delegate) Ctor_FieldPosition(this_0 FieldPosition_I) { A2g_NotNull[FieldPosition_I](this_0); t.F_this_0 = this_0 }

func (t *FieldPosition_Delegate) Ref() any { if t == nil { return nil }; return t }

func (t *FieldPosition_Delegate) GetClass__Class() *Class { return FieldPosition_Delegate_class }

func (t *FieldPosition_Delegate) ToString__String() *String { return Object_toString(t) }

func (t *FieldPosition_Delegate) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FieldPosition_Delegate) CloneShallow() any { panic(CloneNotSupported(t)) }

func FieldPosition_Delegate_InstanceOf(x any) bool { _, ok := x.(*FieldPosition_Delegate); return ok }

func FieldPosition_Delegate_Cast(x any) *FieldPosition_Delegate { if x == nil { return nil }; v, ok := x.(*FieldPosition_Delegate); if !ok { panic(ClassCast(x, FieldPosition_Delegate_class)) }; return v }
