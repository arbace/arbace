//line java_sql_Timestamp.ae:1
package jrt








func Timestamp_New_I_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6 int32) *Timestamp { t := &Timestamp{}; t.Ctor_I_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6); return t }
//line :10:1
func (t *Timestamp) Ctor_I_I_I_I_I_I_I(year, month, date, hour, minute, second, nano int32) { t.Date.Ctor_I_I_I_I_I_I(t, year, month, date, hour, minute, second)


	var tmp1 bool; var tmp2 bool; tmp2 = nano > 999999999; if !tmp2 { tmp2 = nano < 0 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1688))) }
	t.F_nanos = nano
}
func Timestamp_New_J(p0 int64) *Timestamp { t := &Timestamp{}; t.Ctor_J(p0); return t }
//line :17:1
func (t *Timestamp) Ctor_J(time int64) { t.Date.Ctor_J(t, time/1000*1000)

	t.F_nanos = int32(time % 1000 * 1000000)
	if t.F_nanos < 0 {
		t.F_nanos = 1000000000 + t.F_nanos
		t.Date.Impl_SetTime_J__V(t, (time/1000-1)*1000)
	} }
func (t *Timestamp) SetTime_J__V(time int64) {
	t.Date.Impl_SetTime_J__V(t, time/1000*1000)
	t.F_nanos = int32(time % 1000 * 1000000)
	if t.F_nanos < 0 {
		t.F_nanos = 1000000000 + t.F_nanos
		t.Date.Impl_SetTime_J__V(t, (time/1000-1)*1000)
	} }
func (t *Timestamp) GetTime__J() int64 {
	var time int64 = t.Date.Impl_GetTime__J(t); return time + int64(t.F_nanos/1000000)
}


func Timestamp_ValueOf_String__Timestamp(s *String) *Timestamp {
	var year int32 = 0
	var month int32 = 0
	var day int32 = 0
	var hour int32 = 0
	var minute int32 = 0
	var second int32 = 0
	var a_nanos int32 = 0
	var firstDash int32 = 0
	var secondDash int32 = 0
	var dividingSpace int32 = 0
	var firstColon int32 = 0
	var secondColon int32 = 0
	var period int32 = 0
	var formatError /*line :37:1*/*String = Lit_1689


















	if s == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1690))) }
	s = NN(s).Trim__String()
	dividingSpace = NN(s).IndexOf_I__I(32)
	if dividingSpace < 0 { panic(Thrown(IllegalArgumentException_New_String(formatError))) }
	firstDash = NN(s).IndexOf_I__I(45)
	secondDash = NN(s).IndexOf_I_I__I(45, firstDash+1)
	firstColon = NN(s).IndexOf_I_I__I(58, dividingSpace+1)
	secondColon = NN(s).IndexOf_I_I__I(58, firstColon+1)
	period = NN(s).IndexOf_I_I__I(46, secondColon+1)
	var parsedDate bool = false; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = firstDash > 0; if tmp3 { tmp3 = secondDash > 0 }; tmp2 = tmp3; if tmp2 {
		tmp2 = secondDash < dividingSpace-1 }
//line :66:1
	tmp1 = tmp2; if tmp1 {

		var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = firstDash == 4; if tmp6 {
			var tmp7 bool; tmp7 = secondDash-firstDash > 1; if tmp7 {
				tmp7 = secondDash-firstDash <= 3 }
//line :69:1
			tmp6 = tmp7 }
//line :68:1
		tmp5 = tmp6; if tmp5 {



			var tmp8 bool; tmp8 = dividingSpace-secondDash > 1; if tmp8 {
				tmp8 = dividingSpace-secondDash <= 3 }
//line :72:1
			tmp5 = tmp8 }
//line :68:1
		tmp4 = tmp5; if tmp4 {






			year = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), 0, firstDash, 10)
			month = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), firstDash+1, secondDash, 10)
			day = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), secondDash+1, dividingSpace, 10)
			var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = month >= 1; if tmp11 { tmp11 = month <= 12 }; tmp10 = tmp11; if tmp10 { var tmp12 bool; tmp12 = day >= 1; if tmp12 { tmp12 = day <= 31 }; tmp10 = tmp12 }; tmp9 = tmp10; if tmp9 {
				parsedDate = true } } }
	if parsedDate { } else { panic(Thrown(IllegalArgumentException_New_String(formatError))) }
	var len_ int32 = NN(s).Length__I(); var tmp13 bool; var tmp14 bool; var tmp15 bool
	tmp15 = firstColon > 0; if tmp15 { tmp15 = secondColon > 0 }; tmp14 = tmp15; if tmp14 {
		tmp14 = secondColon < len_-1 }
//line :82:1
	tmp13 = tmp14; if tmp13 {


		hour = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), dividingSpace+1, firstColon, 10)
		minute = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), firstColon+1, secondColon, 10)
		var tmp16 bool; var tmp17 bool
		tmp17 = period > 0; if tmp17 { tmp17 = period < len_-1 }; tmp16 = tmp17
//line :87:1
		if tmp16 {


			second = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), secondColon+1, period, 10)
			var nanoPrecision int32 = len_ - (period + 1)


			if nanoPrecision > 9 { panic(Thrown(IllegalArgumentException_New_String(formatError))) }
			if Character_IsDigit_C__Z(NN(s).CharAt_I__C(period + 1)) { } else {
				panic(Thrown(IllegalArgumentException_New_String(formatError))) }
			var tmpNanos int32 = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), period+1, len_, 10)




		L1: for { if nanoPrecision < 9 {
			tmpNanos = tmpNanos * 10
			nanoPrecision = nanoPrecision + 1
//line :102:1
			continue L1 }; break L1
		}

			a_nanos = tmpNanos } else {
//line :87:1
				if period > 0 {


















					panic(Thrown(IllegalArgumentException_New_String(formatError))) } else {
						second = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), secondColon+1, len_, 10) } } } else {
							panic(Thrown(IllegalArgumentException_New_String(formatError))) }
	return Timestamp_New_I_I_I_I_I_I_I(year-1900, month-1, day, hour, minute, second, a_nanos)
}






func (t *Timestamp) ToString__String() *String {
	var year int32 = t.Date.Impl_GetYear__I(t) + 1900; var month int32 = t.Date.Impl_GetMonth__I(t) + 1; var day int32 = t.Date.Impl_GetDate__I(t); var hour int32 = t.Date.Impl_GetHours__I(t); var minute int32 = t.Date.Impl_GetMinutes__I(t); var second int32 = t.Date.Impl_GetSeconds__I(t); var trailingZeros int32 = 0; var tmpNanos int32 = t.F_nanos







	if tmpNanos == 0 {
		trailingZeros = 8 } else {
		L1: for { if tmpNanos%10 == 0 {
			tmpNanos = tmpNanos / 10
			trailingZeros = trailingZeros + 1
//line :128:1
			continue L1 }; break L1
		}
		}
	var count int32 = 10000
	var yearSize int32 = 4
L2: for {
	if year < count { break L2 }
	yearSize = yearSize + 1
	count = count * 10
	if count < 1000000000 { continue L2 }
//line :133:1
	break L2
}



	var buf *CharArray = NewCharArray(25 + yearSize - trailingZeros)

	Sql_Date_FormatDecimalInt_I_C1_I_I__V(year, buf, 0, yearSize)
	buf.A[yearSize] = 45
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(month, buf, yearSize+1, 2)
	buf.A[yearSize+3] = 45
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(day, buf, yearSize+4, 2)
	buf.A[yearSize+6] = 32
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(hour, buf, yearSize+7, 2)
	buf.A[yearSize+9] = 58
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(minute, buf, yearSize+10, 2)
	buf.A[yearSize+12] = 58
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(second, buf, yearSize+13, 2)
	buf.A[yearSize+15] = 46
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(tmpNanos, buf, yearSize+16, 9-trailingZeros)



	return String_New_C1(buf)
}
func (t *Timestamp) GetNanos__I() int32 { return t.F_nanos }

func (t *Timestamp) SetNanos_I__V(n int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = n > 999999999; if !tmp2 { tmp2 = n < 0 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1688))) }
	t.F_nanos = n
}
func (t *Timestamp) Equals_Timestamp__Z(ts *Timestamp) bool {
	if t.Date.Impl_Equals_O__Z(t, ts.Ref()) { var tmp1 int32 = t.F_nanos; if tmp1 == ts.F_nanos { return true } else { return false } } else { return false
	} }
func (t *Timestamp) Equals_O__Z(ts any) bool {
	if Timestamp_InstanceOf(ts) { return t.Equals_Timestamp__Z(Timestamp_Cast(ts)) } else { return false
	} }
func (t *Timestamp) Before_Timestamp__Z(ts *Timestamp) bool {
	return t.CompareTo_Timestamp__I(ts) < 0
}
func (t *Timestamp) After_Timestamp__Z(ts *Timestamp) bool {
	return t.CompareTo_Timestamp__I(ts) > 0
}
func (t *Timestamp) CompareTo_Timestamp__I(ts *Timestamp) int32 {
	var thisTime int64 = t.GetTime__J(); var anotherTime int64 = NN(ts).GetTime__J(); var i int32

	if thisTime < anotherTime { i = -1 } else { if thisTime == anotherTime { i = 0 } else { i = 1 } }
	if i == 0 { var tmp1 int32 = t.F_nanos; if tmp1 > ts.F_nanos { return 1 } else { var tmp2 int32 = t.F_nanos; if tmp2 < ts.F_nanos { return -1 } } }
//line :178:1
	return i
}




func (t *Timestamp) CompareTo_Date__I(o Date_I) int32 {
	if Timestamp_InstanceOf(o) {
		return t.CompareTo_Timestamp__I(Timestamp_Cast(o)) } else {
			var ts *Timestamp = Timestamp_New_J(o.GetTime__J()); return t.CompareTo_Timestamp__I(ts)
		} }
func (t *Timestamp) HashCode__I() int32 { return t.Date.Impl_HashCode__I(t) }





func Timestamp_ValueOf_LocalDateTime__Timestamp(dateTime *LocalDateTime) *Timestamp {
	return Timestamp_New_I_I_I_I_I_I_I(NN(dateTime).GetYear__I()-1900, NN(dateTime).GetMonthValue__I()-1, NN(dateTime).GetDayOfMonth__I(), NN(dateTime).GetHour__I(), NN(dateTime).GetMinute__I(), NN(dateTime).GetSecond__I(), NN(dateTime).GetNano__I())
}






func (t *Timestamp) ToLocalDateTime__LocalDateTime() *LocalDateTime {
	return LocalDateTime_Of_I_I_I_I_I_I_I__LocalDateTime(t.GetYear__I()+1900, t.GetMonth__I()+1, t.GetDate__I(), t.GetHours__I(), t.GetMinutes__I(), t.GetSeconds__I(), t.GetNanos__I())
}






func Timestamp_From_Instant__Timestamp(instant *Instant) *Timestamp {
	var tmp1 *Timestamp; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var stamp *Timestamp = Timestamp_New_J(Math_MultiplyExact_J_I__J(NN(instant).GetEpochSecond__J(), 1000))
			stamp.F_nanos = NN(instant).GetNano__I()
//line :215:1
			tmp1 = stamp }
		return nil }()
//line :214:1
	if tmp2 != nil { if ArithmeticException_InstanceOf(tmp2) { var ex *ArithmeticException = ArithmeticException_Cast(tmp2)



		panic(Thrown(IllegalArgumentException_New_Throwable(Up_ArithmeticException_Throwable(ex)))) } else {
//line :214:1
			panic(tmp2) } }; return tmp1
}




func (t *Timestamp) ToInstant__Instant() *Instant {
	return Instant_OfEpochSecond_J_J__Instant(t.Date.Impl_GetTime__J(t)/1000, int64(t.F_nanos))
}


type Timestamp struct{ Date; F_nanos int32 }

const Timestamp_serialVersionUID int64 = 2745179027874758501

const Timestamp_MILLIS_PER_SECOND int32 = 1000

func (t *Timestamp) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Date__I(Date_Cast(p0)) }

func (t *Timestamp) GetMonth__I() int32 { return t.Impl_GetMonth__I(t) }

func (t *Timestamp) GetDay__I() int32 { return t.Impl_GetDay__I(t) }

func (t *Timestamp) GetSeconds__I() int32 { return t.Impl_GetSeconds__I(t) }

func (t *Timestamp) After_Date__Z(p0 Date_I) bool { return t.Impl_After_Date__Z(t, p0) }

func (t *Timestamp) GetYear__I() int32 { return t.Impl_GetYear__I(t) }

func (t *Timestamp) GetDate__I() int32 { return t.Impl_GetDate__I(t) }

func (t *Timestamp) GetMinutes__I() int32 { return t.Impl_GetMinutes__I(t) }

func (t *Timestamp) ToGMTString__String() *String { return t.Impl_ToGMTString__String(t) }

func (t *Timestamp) GetHours__I() int32 { return t.Impl_GetHours__I(t) }

func (t *Timestamp) Before_Date__Z(p0 Date_I) bool { return t.Impl_Before_Date__Z(t, p0) }

func (t *Timestamp) GetTimezoneOffset__I() int32 { return t.Impl_GetTimezoneOffset__I(t) }

func (t *Timestamp) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Timestamp) Ref() any { if t == nil { return nil }; return t }

func (t *Timestamp) GetClass__Class() *Class { return Timestamp_class }

func (t *Timestamp) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func Timestamp_InstanceOf(x any) bool { _, ok := x.(*Timestamp); return ok }

func Timestamp_Cast(x any) *Timestamp { if x == nil { return nil }; v, ok := x.(*Timestamp); if !ok { panic(ClassCast(x, Timestamp_class)) }; return v }
