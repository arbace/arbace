//line java_lang_Comparable.ae:1
package jrt






type Comparable interface{ Object_I; Is_Comparable(); CompareTo_O__I(p0 any) int32 }

func Comparable_InstanceOf(x any) bool { _, ok := x.(Comparable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Comparable_class) } }; return ok }

func Comparable_Cast(x any) Comparable { if x == nil { return nil }; v, ok := x.(Comparable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Comparable_class) } }; if !ok { panic(ClassCast(x, Comparable_class)) }; return v }
