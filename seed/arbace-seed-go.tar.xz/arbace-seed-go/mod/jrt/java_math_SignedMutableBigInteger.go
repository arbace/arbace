//line java_math_SignedMutableBigInteger.ae:1
package jrt








func SignedMutableBigInteger_New() *SignedMutableBigInteger { SignedMutableBigInteger_Init(); t := &SignedMutableBigInteger{}; t.Ctor(); return t }
//line :10:1
func (t *SignedMutableBigInteger) Ctor() { t.MutableBigInteger.Ctor(t); t.F_sign = 1 }

func SignedMutableBigInteger_New_I(p0 int32) *SignedMutableBigInteger { SignedMutableBigInteger_Init(); t := &SignedMutableBigInteger{}; t.Ctor_I(p0); return t }
//line :12:1
func (t *SignedMutableBigInteger) Ctor_I(val int32) { t.MutableBigInteger.Ctor_I(t, val); t.F_sign = 1 }

func SignedMutableBigInteger_New_MutableBigInteger(p0 MutableBigInteger_I) *SignedMutableBigInteger { SignedMutableBigInteger_Init(); t := &SignedMutableBigInteger{}; t.Ctor_MutableBigInteger(p0); return t }
//line :14:1
func (t *SignedMutableBigInteger) Ctor_MutableBigInteger(val MutableBigInteger_I) { panic(A2g_NotTranslated("java.math.SignedMutableBigInteger.<init>(Ljava/math/MutableBigInteger;)V")) }

func (t *SignedMutableBigInteger) SignedAdd_SignedMutableBigInteger__V(addend *SignedMutableBigInteger) {
	var tmp1 int32 = t.F_sign; if tmp1 == addend.F_sign {
		t.Add_MutableBigInteger__V(Up_SignedMutableBigInteger_MutableBigInteger(addend)) } else {
			var tmp2 int32 = t.F_sign; t.F_sign = tmp2 * t.Subtract_MutableBigInteger__I(Up_SignedMutableBigInteger_MutableBigInteger(addend))
		} }
func (t *SignedMutableBigInteger) SignedAdd_MutableBigInteger__V(addend MutableBigInteger_I) {
	if t.F_sign == 1 {
		t.Add_MutableBigInteger__V(addend) } else {
			var tmp1 int32 = t.F_sign; t.F_sign = tmp1 * t.Subtract_MutableBigInteger__I(addend)
		} }
func (t *SignedMutableBigInteger) SignedSubtract_SignedMutableBigInteger__V(addend *SignedMutableBigInteger) {
	var tmp1 int32 = t.F_sign; if tmp1 == addend.F_sign {
		var tmp2 int32 = t.F_sign; t.F_sign = tmp2 * t.Subtract_MutableBigInteger__I(Up_SignedMutableBigInteger_MutableBigInteger(addend)) } else {
			t.Add_MutableBigInteger__V(Up_SignedMutableBigInteger_MutableBigInteger(addend))
		} }
func (t *SignedMutableBigInteger) SignedSubtract_MutableBigInteger__V(p0 MutableBigInteger_I) { panic(A2g_NotTranslated("java.math.SignedMutableBigInteger.signedSubtract(Ljava/math/MutableBigInteger;)V")) }





func (t *SignedMutableBigInteger) ToString__String() *String {
	return NN(t.ToBigInteger_I__BigInteger(t.F_sign)).ToString__String()
}


type SignedMutableBigInteger struct{ MutableBigInteger; F_sign int32 }

var SignedMutableBigInteger_init ClassInit

func SignedMutableBigInteger_Init() { if !SignedMutableBigInteger_init.Done() { SignedMutableBigInteger_init.Run(SignedMutableBigInteger_clinit) } }

func SignedMutableBigInteger_clinit() { MutableBigInteger_Init() }

func (t *SignedMutableBigInteger) AddShifted_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_AddShifted_MutableBigInteger_I__V(t, p0, p1) }

func (t *SignedMutableBigInteger) Subtract_MutableBigInteger__I(p0 MutableBigInteger_I) int32 { return t.Impl_Subtract_MutableBigInteger__I(t, p0) }

func (t *SignedMutableBigInteger) IsOdd__Z() bool { return t.Impl_IsOdd__Z(t) }

func (t *SignedMutableBigInteger) CopyValue_I1__V(p0 *IntArray) { t.Impl_CopyValue_I1__V(t, p0) }

func (t *SignedMutableBigInteger) DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(t, p0, p1) }

func (t *SignedMutableBigInteger) Clear__V() { t.Impl_Clear__V(t) }

func (t *SignedMutableBigInteger) CopyValue_MutableBigInteger__V(p0 MutableBigInteger_I) { t.Impl_CopyValue_MutableBigInteger__V(t, p0) }

func (t *SignedMutableBigInteger) SafeRightShift_I__V(p0 int32) { t.Impl_SafeRightShift_I__V(t, p0) }

func (t *SignedMutableBigInteger) ToIntArray__I1() *IntArray { return t.Impl_ToIntArray__I1(t) }

func (t *SignedMutableBigInteger) Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(p0, p1 MutableBigInteger_I, p2 bool) MutableBigInteger_I { return t.Impl_Divide_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(t, p0, p1, p2) }

func (t *SignedMutableBigInteger) Add_MutableBigInteger__V(p0 MutableBigInteger_I) { t.Impl_Add_MutableBigInteger__V(t, p0) }

func (t *SignedMutableBigInteger) Mul_I_MutableBigInteger__V(p0 int32, p1 MutableBigInteger_I) { t.Impl_Mul_I_MutableBigInteger__V(t, p0, p1) }

func (t *SignedMutableBigInteger) DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(t, p0, p1) }

func (t *SignedMutableBigInteger) IsEven__Z() bool { return t.Impl_IsEven__Z(t) }

func (t *SignedMutableBigInteger) DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(p0, p1 MutableBigInteger_I, p2 bool) MutableBigInteger_I { return t.Impl_DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(t, p0, p1, p2) }

func (t *SignedMutableBigInteger) LeftShift_I__V(p0 int32) { t.Impl_LeftShift_I__V(t, p0) }

func (t *SignedMutableBigInteger) SafeLeftShift_I__V(p0 int32) { t.Impl_SafeLeftShift_I__V(t, p0) }

func (t *SignedMutableBigInteger) IsNormal__Z() bool { return t.Impl_IsNormal__Z(t) }

func (t *SignedMutableBigInteger) ShiftAdd_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_ShiftAdd_MutableBigInteger_I__V(t, p0, p1) }

func (t *SignedMutableBigInteger) Normalize__V() { t.Impl_Normalize__V(t) }

func (t *SignedMutableBigInteger) SetValue_I1_I__V(p0 *IntArray, p1 int32) { t.Impl_SetValue_I1_I__V(t, p0, p1) }

func (t *SignedMutableBigInteger) ShiftAddDisjoint_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_ShiftAddDisjoint_MutableBigInteger_I__V(t, p0, p1) }

func (t *SignedMutableBigInteger) Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(p0, p1 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(t, p0, p1) }

func (t *SignedMutableBigInteger) ModInverseMP2_I__MutableBigInteger(p0 int32) MutableBigInteger_I { return t.Impl_ModInverseMP2_I__MutableBigInteger(t, p0) }

func (t *SignedMutableBigInteger) MutableModInverse_MutableBigInteger__MutableBigInteger(p0 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_MutableModInverse_MutableBigInteger__MutableBigInteger(t, p0) }

func (t *SignedMutableBigInteger) AddLower_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_AddLower_MutableBigInteger_I__V(t, p0, p1) }

func (t *SignedMutableBigInteger) AddDisjoint_MutableBigInteger_I__V(p0 MutableBigInteger_I, p1 int32) { t.Impl_AddDisjoint_MutableBigInteger_I__V(t, p0, p1) }

func (t *SignedMutableBigInteger) IsOne__Z() bool { return t.Impl_IsOne__Z(t) }

func (t *SignedMutableBigInteger) CompareHalf_MutableBigInteger__I(p0 MutableBigInteger_I) int32 { return t.Impl_CompareHalf_MutableBigInteger__I(t, p0) }

func (t *SignedMutableBigInteger) SetInt_I_I__V(p0, p1 int32) { t.Impl_SetInt_I_I__V(t, p0, p1) }

func (t *SignedMutableBigInteger) BitLength__J() int64 { return t.Impl_BitLength__J(t) }

func (t *SignedMutableBigInteger) ToBigDecimal_I_I__BigDecimal(p0, p1 int32) *BigDecimal { return t.Impl_ToBigDecimal_I_I__BigDecimal(t, p0, p1) }

func (t *SignedMutableBigInteger) RootnRem_I__MutableBigInteger1(p0 int32) *RefArray { return t.Impl_RootnRem_I__MutableBigInteger1(t, p0) }

func (t *SignedMutableBigInteger) HybridGCD_MutableBigInteger__MutableBigInteger(p0 MutableBigInteger_I) MutableBigInteger_I { return t.Impl_HybridGCD_MutableBigInteger__MutableBigInteger(t, p0) }

func (t *SignedMutableBigInteger) DivideOneWord_I_MutableBigInteger__I(p0 int32, p1 MutableBigInteger_I) int32 { return t.Impl_DivideOneWord_I_MutableBigInteger__I(t, p0, p1) }

func (t *SignedMutableBigInteger) RightShift_I__V(p0 int32) { t.Impl_RightShift_I__V(t, p0) }

func (t *SignedMutableBigInteger) IsZero__Z() bool { return t.Impl_IsZero__Z(t) }

func (t *SignedMutableBigInteger) Reset__V() { t.Impl_Reset__V(t) }

func (t *SignedMutableBigInteger) Divide_J_MutableBigInteger__J(p0 int64, p1 MutableBigInteger_I) int64 { return t.Impl_Divide_J_MutableBigInteger__J(t, p0, p1) }

func (t *SignedMutableBigInteger) Multiply_MutableBigInteger_MutableBigInteger__V(p0, p1 MutableBigInteger_I) { t.Impl_Multiply_MutableBigInteger_MutableBigInteger__V(t, p0, p1) }

func (t *SignedMutableBigInteger) ToBigInteger__BigInteger() *BigInteger { return t.Impl_ToBigInteger__BigInteger(t) }

func (t *SignedMutableBigInteger) SqrtRem_Z__MutableBigInteger1(p0 bool) *RefArray { return t.Impl_SqrtRem_Z__MutableBigInteger1(t, p0) }

func (t *SignedMutableBigInteger) EuclidModInverse_I__MutableBigInteger(p0 int32) MutableBigInteger_I { return t.Impl_EuclidModInverse_I__MutableBigInteger(t, p0) }

func (t *SignedMutableBigInteger) ToBigInteger_I__BigInteger(p0 int32) *BigInteger { return t.Impl_ToBigInteger_I__BigInteger(t, p0) }

func (t *SignedMutableBigInteger) Compare_MutableBigInteger__I(p0 MutableBigInteger_I) int32 { return t.Impl_Compare_MutableBigInteger__I(t, p0) }

func (t *SignedMutableBigInteger) ToCompactValue_I__J(p0 int32) int64 { return t.Impl_ToCompactValue_I__J(t, p0) }

func (t *SignedMutableBigInteger) Ref() any { if t == nil { return nil }; return t }

func (t *SignedMutableBigInteger) GetClass__Class() *Class { return SignedMutableBigInteger_class }

func (t *SignedMutableBigInteger) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SignedMutableBigInteger) CloneShallow() any { panic(CloneNotSupported(t)) }

func SignedMutableBigInteger_InstanceOf(x any) bool { _, ok := x.(*SignedMutableBigInteger); return ok }

func SignedMutableBigInteger_Cast(x any) *SignedMutableBigInteger { if x == nil { return nil }; v, ok := x.(*SignedMutableBigInteger); if !ok { panic(ClassCast(x, SignedMutableBigInteger_class)) }; return v }
