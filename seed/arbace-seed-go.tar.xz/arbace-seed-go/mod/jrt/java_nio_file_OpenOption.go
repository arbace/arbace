//line java_nio_file_OpenOption.ae:1
package jrt






type OpenOption interface{ Object_I; Is_OpenOption() }

func OpenOption_InstanceOf(x any) bool { _, ok := x.(OpenOption); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(OpenOption_class) } }; return ok }

func OpenOption_Cast(x any) OpenOption { if x == nil { return nil }; v, ok := x.(OpenOption); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(OpenOption_class) } }; if !ok { panic(ClassCast(x, OpenOption_class)) }; return v }
