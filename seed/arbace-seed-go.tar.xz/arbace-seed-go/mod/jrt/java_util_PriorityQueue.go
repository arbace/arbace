//line java_util_PriorityQueue.ae:1
package jrt

























func PriorityQueue_New() *PriorityQueue { t := &PriorityQueue{}; t.Ctor(); return t }
//line :27:1
func (t *PriorityQueue) Ctor() { t.Ctor_I_Comparator(11, nil) }

func PriorityQueue_New_I(p0 int32) *PriorityQueue { t := &PriorityQueue{}; t.Ctor_I(p0); return t }
//line :29:1
func (t *PriorityQueue) Ctor_I(initialCapacity int32) { t.Ctor_I_Comparator(initialCapacity, nil) }


func PriorityQueue_New_Comparator(p0 Comparator) *PriorityQueue { t := &PriorityQueue{}; t.Ctor_Comparator(p0); return t }
//line :32:1
func (t *PriorityQueue) Ctor_Comparator(comparator Comparator) { t.Ctor_I_Comparator(11, comparator) }


func PriorityQueue_New_I_Comparator(p0 int32, p1 Comparator) *PriorityQueue { t := &PriorityQueue{}; t.Ctor_I_Comparator(p0, p1); return t }
//line :35:1
func (t *PriorityQueue) Ctor_I_Comparator(initialCapacity int32, comparator Comparator) { t.AbstractQueue.Ctor(t)
	if initialCapacity < 1 { panic(Thrown(IllegalArgumentException_New())) }
	t.F_queue = NewRefArray(Object_class, initialCapacity)
	t.F_comparator = comparator
}
func PriorityQueue_New_Collection(p0 Collection) *PriorityQueue { t := &PriorityQueue{}; t.Ctor_Collection(p0); return t }
//line :40:1
func (t *PriorityQueue) Ctor_Collection(c Collection) { t.AbstractQueue.Ctor(t)
	if SortedSet_InstanceOf(c) {

		var ss SortedSet = SortedSet_Cast(c)
		t.F_comparator = ss.Comparator__Comparator()
		t.InitElementsFromCollection_Collection__V(ss) } else {
//line :41:1
			if PriorityQueue_InstanceOf(c) {





				var pq *PriorityQueue = PriorityQueue_Cast(c)
				t.F_comparator = NN(pq).Comparator__Comparator()
				t.InitFromPriorityQueue_PriorityQueue__V(pq) } else {
					t.F_comparator = nil; t.InitFromCollection_Collection__V(c)
				} } }
func PriorityQueue_New_PriorityQueue(p0 *PriorityQueue) *PriorityQueue { t := &PriorityQueue{}; t.Ctor_PriorityQueue(p0); return t }
//line :52:1
func (t *PriorityQueue) Ctor_PriorityQueue(c *PriorityQueue) { t.AbstractQueue.Ctor(t)
	t.F_comparator = NN(c).Comparator__Comparator()
	t.InitFromPriorityQueue_PriorityQueue__V(c)
}
func PriorityQueue_New_SortedSet(p0 SortedSet) *PriorityQueue { t := &PriorityQueue{}; t.Ctor_SortedSet(p0); return t }
//line :56:1
func (t *PriorityQueue) Ctor_SortedSet(c SortedSet) { t.AbstractQueue.Ctor(t)
	t.F_comparator = c.Comparator__Comparator()
	t.InitElementsFromCollection_Collection__V(c)
}
func PriorityQueue_EnsureNonEmpty_O1__O1(es *RefArray) *RefArray {
	if int32(len(es.A)) > 0 { return es } else { return NewRefArray(Object_class, 1)
	} }
func (t *PriorityQueue) InitFromPriorityQueue_PriorityQueue__V(c *PriorityQueue) {
	if NN(c).GetClass__Class() == PriorityQueue_class {

		t.F_queue = PriorityQueue_EnsureNonEmpty_O1__O1(NN(c).ToArray__O1())
		t.F_size = NN(c).Size__I() } else {
			t.InitFromCollection_Collection__V(Up_PriorityQueue_Collection(c))
		} }
func (t *PriorityQueue) InitElementsFromCollection_Collection__V(c Collection) {
	var es *RefArray = c.ToArray__O1(); var len_ int32 = int32(len(es.A))

	if c.GetClass__Class() == ArrayList_class { } else { es = Arrays_CopyOf_O1_I_Class__O1(es, len_, Object_class.ArrayClass()) }
	var tmp1 bool; var tmp2 bool; tmp2 = len_ == 1; if !tmp2 { tmp2 = !(t.F_comparator == nil) }; tmp1 = tmp2; if tmp1 {
		var arr_101979 *RefArray = es; var len_101980 int32 = int32(len(arr_101979.A)); var i_101981 int32 = 0; for ; i_101981 < len_101980; i_101981++ { var e any = arr_101979.A[i_101981]; if e == nil { panic(Thrown(NullPointerException_New())) } } }
	t.F_queue = PriorityQueue_EnsureNonEmpty_O1__O1(es)
	t.F_size = len_
}
func (t *PriorityQueue) InitFromCollection_Collection__V(c Collection) {
	t.InitElementsFromCollection_Collection__V(c)
	t.Heapify__V()
}
func (t *PriorityQueue) Grow_I__V(minCapacity int32) {
	var oldCapacity int32 = int32(len(t.F_queue.A)); var newCapacity int32; var tmp1 int32 = minCapacity - oldCapacity; var tmp2 int32


	if oldCapacity < 64 {
		tmp2 = oldCapacity + 2 } else {
			tmp2 = oldCapacity >> 1 }
//line :85:1
	newCapacity = ArraysSupport_NewLength_I_I_I__I(oldCapacity, tmp1, tmp2)




	t.F_queue = Arrays_CopyOf_O1_I__O1(t.F_queue, newCapacity)
}
func (t *PriorityQueue) Add_O__Z(e any) bool { return t.Offer_O__Z(e) }

func (t *PriorityQueue) Offer_O__Z(e any) bool {
	if e == nil { panic(Thrown(NullPointerException_New())) }
	t.F_modCount = t.F_modCount + 1
	var i int32 = t.F_size
	if i >= int32(len(t.F_queue.A)) { t.Grow_I__V(i + 1) }
	t.SiftUp_I_O__V(i, e)
	t.F_size = i + 1
//line :97:1
	return true
}




func (t *PriorityQueue) Peek__O() any { return t.F_queue.A[0] }

func (t *PriorityQueue) IndexOf_O__I(o any) int32 {
	if !(o == nil) {
		var es *RefArray = t.F_queue; var i int32 = 0; var n int32 = t.F_size
	L1: for {

		if i < n { if Equals(o, es.A[i]) { return i } else { i, n = i+1, n; continue L1 } }
//line :108:1
		break L1 } }
//line :105:1
	return -1
}






func (t *PriorityQueue) Remove_O__Z(o any) bool {
	var i int32 = t.IndexOf_O__I(o); if i == -1 { return false } else { t.RemoveAt_I__O(i); return true
	} }
func (t *PriorityQueue) RemoveEq_O__V(o any) {
	var es *RefArray = t.F_queue; var i int32 = 0; var n int32 = t.F_size
L1: for {

	if i < n {
		if o == es.A[i] { t.RemoveAt_I__O(i) } else { i, n = i+1, n; continue L1 } }
//line :118:1
	break L1
}
}



func (t *PriorityQueue) Contains_O__Z(o any) bool { return t.IndexOf_O__I(o) >= 0 }

func (t *PriorityQueue) ToArray__O1() *RefArray { return Arrays_CopyOf_O1_I__O1(t.F_queue, t.F_size) }

func (t *PriorityQueue) ToArray_O1__O1(a *RefArray) *RefArray {
	var size int32 = t.F_size
	if int32(len(a.A)) < size {
		var tmp1 *RefArray = t.F_queue; return Arrays_CopyOf_O1_I_Class__O1(tmp1, size, GetClass(a.Ref())) } else {
			System_Arraycopy_O_I_O_I_I__V(t.F_queue.Ref(), 0, a.Ref(), 0, size); if int32(len(a.A)) > size { a.Store(size, nil) }; return a
		} }
func (t *PriorityQueue) Iterator__Iterator() Iterator { return PriorityQueue_Itr_New_PriorityQueue(t) }














func PriorityQueue_Itr_New_PriorityQueue(p0 *PriorityQueue) *PriorityQueue_Itr { t := &PriorityQueue_Itr{}; t.Ctor_PriorityQueue(p0); return t }
//line :149:1
func (t *PriorityQueue_Itr) Ctor_PriorityQueue(this_0 *PriorityQueue) { NN(this_0); t.F_this_0 = this_0; t.F_lastRet = -1; t.F_expectedModCount = this_0.F_modCount }

func (t *PriorityQueue_Itr) HasNext__Z() bool {
	var tmp1 bool; tmp1 = t.F_cursor < t.F_this_0.F_size; if !tmp1 { var tmp2 bool; tmp2 = !(t.F_forgetMeNot == nil); if tmp2 { tmp2 = !NN(t.F_forgetMeNot).IsEmpty__Z() }; tmp1 = tmp2 }; return tmp1
}
func (t *PriorityQueue_Itr) Next__O() any {
	if t.F_expectedModCount == t.F_this_0.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	if t.F_cursor < t.F_this_0.F_size {
		var tmp1 *RefArray = t.F_this_0.F_queue; var tmp2 int32; var tmp3 int32; var old_1 int32 = t.F_cursor
		t.F_cursor = t.F_cursor + 1; tmp3 = old_1; var tmp4 int32 = tmp3; t.F_lastRet = tmp4; tmp2 = tmp4
//line :157:1
		return tmp1.A[tmp2] } else {


			if !(t.F_forgetMeNot == nil) {
				t.F_lastRet = -1
				t.F_lastRetElt = NN(t.F_forgetMeNot).Poll__O()
				if !(t.F_lastRetElt == nil) { return t.F_lastRetElt } }
			panic(Thrown(NoSuchElementException_New()))
		} }
func (t *PriorityQueue_Itr) Remove__V() {
	if t.F_expectedModCount == t.F_this_0.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	if !(t.F_lastRet == -1) {

		var moved any = NN(t.F_this_0).RemoveAt_I__O(t.F_lastRet)
		t.F_lastRet = -1
		if moved == nil {
			t.F_cursor = t.F_cursor - 1 } else {

				if t.F_forgetMeNot == nil { t.F_forgetMeNot = ArrayDeque_New() }
				NN(t.F_forgetMeNot).Add_O__Z(moved) } } else {
//line :168:1
					if !(t.F_lastRetElt == nil) {








						NN(t.F_this_0).RemoveEq_O__V(t.F_lastRetElt); t.F_lastRetElt = nil } else {
							panic(Thrown(IllegalStateException_New())) } }
	t.F_expectedModCount = t.F_this_0.F_modCount
}
func (t *PriorityQueue) Size__I() int32 { return t.F_size }

func (t *PriorityQueue) Clear__V() {
	t.F_modCount = t.F_modCount + 1
	var es *RefArray = t.F_queue; var i int32 = 0; var n int32 = t.F_size
L1: for { if i < n { es.Store(i, nil); i, n = i+1, n; continue L1 }; break L1 }
	t.F_size = 0
}
func (t *PriorityQueue) Poll__O() any {
	var es *RefArray; var result any; var tmp1 any; var tmp2 *RefArray

	es = t.F_queue; tmp2 = es; result = tmp2.A[0]; tmp1 = result; if !(tmp1 == nil) {
		t.F_modCount = t.F_modCount + 1
		var n int32 = 0; var x any; var tmp3 *RefArray = es; var tmp4 int32; var tmp5 int32; var tmp6 int32 = t.F_size - 1
		t.F_size = tmp6; tmp5 = tmp6; n = tmp5; tmp4 = n; x = tmp3.A[tmp4]
		es.Store(n, nil)
		if n > 0 {
			var cmp Comparator; var tmp7 Comparator
			cmp = t.F_comparator; tmp7 = cmp; if tmp7 == nil {
				PriorityQueue_SiftDownComparable_I_O_O1_I__V(0, x, es, n) } else {
					PriorityQueue_SiftDownUsingComparator_I_O_O1_I_Comparator__V(0, x, es, n, cmp) } } }
//line :190:1
	return result
}












func (t *PriorityQueue) RemoveAt_I__O(i int32) any {
	var es *RefArray = t.F_queue
	t.F_modCount = t.F_modCount + 1
	var s int32; var tmp1 int32 = t.F_size - 1; t.F_size = tmp1; s = tmp1
	if s == i {
		es.Store(i, nil) } else {
			var moved any = es.A[s]
			es.Store(s, nil)
			t.SiftDown_I_O__V(i, moved)
			if es.A[i] == moved {
				t.SiftUp_I_O__V(i, moved)
				if es.A[i] == moved { } else { return moved } } }
//line :207:1
	return nil
}









func (t *PriorityQueue) SiftUp_I_O__V(k int32, x any) {
	if !(t.F_comparator == nil) {
		PriorityQueue_SiftUpUsingComparator_I_O_O1_Comparator__V(k, x, t.F_queue, t.F_comparator) } else {
			PriorityQueue_SiftUpComparable_I_O_O1__V(k, x, t.F_queue)
		} }
func PriorityQueue_SiftUpComparable_I_O_O1__V(k int32, x any, es *RefArray) {

	var key Comparable = Comparable_Cast(x)
L1: for { if k > 0 {
	var parent int32 = int32(uint32(k-1) >> 1); var e any = es.A[parent]

	if key.CompareTo_O__I(e) >= 0 { break L1 }
	es.Store(k, e)
	k = parent
//line :226:1
	continue L1 }; break L1
}




	es.Store(k, key)
}
func PriorityQueue_SiftUpUsingComparator_I_O_O1_Comparator__V(k int32, x any, es *RefArray, cmp Comparator) {


L1: for { if k > 0 {
	var parent int32 = int32(uint32(k-1) >> 1); var e any = es.A[parent]

	if cmp.Compare_O_O__I(x, e) >= 0 { break L1 }
	es.Store(k, e)
	k = parent
//line :237:1
	continue L1 }; break L1
}




	es.Store(k, x)
}
func (t *PriorityQueue) SiftDown_I_O__V(k int32, x any) {
	if !(t.F_comparator == nil) {
		PriorityQueue_SiftDownUsingComparator_I_O_O1_I_Comparator__V(k, x, t.F_queue, t.F_size, t.F_comparator) } else {
			PriorityQueue_SiftDownComparable_I_O_O1_I__V(k, x, t.F_queue, t.F_size)
		} }
func PriorityQueue_SiftDownComparable_I_O_O1_I__V(k int32, x any, es *RefArray, n int32) {

	var key Comparable = Comparable_Cast(x); var half int32 = int32(uint32(n) >> 1)

L1: for { if k < half {
	var child int32 = k<<1 + 1; var c any = es.A[child]; var right int32 = child + 1; var tmp1 bool; var tmp2 bool


	tmp2 = right < n; if tmp2 { tmp2 = Comparable_Cast(c).CompareTo_O__I(es.A[right]) > 0 }; tmp1 = tmp2; if tmp1 {
		var tmp3 int32; child = right; tmp3 = child; c = es.A[tmp3] }
	if key.CompareTo_O__I(c) <= 0 { break L1 }
	es.Store(k, c)
	k = child
//line :254:1
	continue L1 }; break L1
}







	es.Store(k, key)
}
func PriorityQueue_SiftDownUsingComparator_I_O_O1_I_Comparator__V(k int32, x any, es *RefArray, n int32, cmp Comparator) {


	var half int32 = int32(uint32(n) >> 1)
L1: for { if k < half {
	var child int32 = k<<1 + 1; var c any = es.A[child]; var right int32 = child + 1; var tmp1 bool; var tmp2 bool


	tmp2 = right < n; if tmp2 { tmp2 = cmp.Compare_O_O__I(c, es.A[right]) > 0 }; tmp1 = tmp2; if tmp1 {
		var tmp3 int32; child = right; tmp3 = child; c = es.A[tmp3] }
	if cmp.Compare_O_O__I(x, c) <= 0 { break L1 }
	es.Store(k, c)
	k = child
//line :269:1
	continue L1 }; break L1
}







	es.Store(k, x)
}
func (t *PriorityQueue) Heapify__V() {
	var es *RefArray = t.F_queue; var n int32 = t.F_size; var i int32 = int32(uint32(n)>>1) - 1; var cmp Comparator; var tmp1 Comparator



	cmp = t.F_comparator; tmp1 = cmp; if tmp1 == nil {
	L1: for { if i >= 0 {
		PriorityQueue_SiftDownComparable_I_O_O1_I__V(i, es.A[i], es, n)
		i = i - 1
//line :286:1
		continue L1 }; break L1
	} } else {

	L2: for { if i >= 0 {
		PriorityQueue_SiftDownUsingComparator_I_O_O1_I_Comparator__V(i, es.A[i], es, n, cmp)
		i = i - 1
//line :289:1
		continue L2 }; break L2
	}
	}
}
func (t *PriorityQueue) Comparator__Comparator() Comparator { return t.F_comparator }





















func (t *PriorityQueue) Spliterator__Spliterator() Spliterator {
	return PriorityQueue_PriorityQueueSpliterator_New_PriorityQueue_I_I_I(t, 0, -1, 0)
}









func PriorityQueue_PriorityQueueSpliterator_New_PriorityQueue_I_I_I(p0 *PriorityQueue, p1, p2, p3 int32) *PriorityQueue_PriorityQueueSpliterator { t := &PriorityQueue_PriorityQueueSpliterator{}; t.Ctor_PriorityQueue_I_I_I(p0, p1, p2, p3); return t }
//line :327:1
func (t *PriorityQueue_PriorityQueueSpliterator) Ctor_PriorityQueue_I_I_I(this_0 *PriorityQueue, origin, fence, expectedModCount int32) { NN(this_0); t.F_this_0 = this_0
	t.F_index = origin
	t.F_fence = fence
	t.F_expectedModCount = expectedModCount
}
func (t *PriorityQueue_PriorityQueueSpliterator) GetFence__I() int32 {
	var hi int32 = 0; var tmp1 int32
	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 { t.F_expectedModCount = t.F_this_0.F_modCount; var tmp2 int32; var tmp3 int32 = t.F_this_0.F_size; t.F_fence = tmp3; tmp2 = tmp3; hi = tmp2 }
//line :333:1
	return hi
}


func (t *PriorityQueue_PriorityQueueSpliterator) TrySplit__PriorityQueue_PriorityQueueSpliterator() *PriorityQueue_PriorityQueueSpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi) >> 1)


	if lo >= mid { return nil } else { var tmp1 int32; var tmp2 int32 = mid; t.F_index = tmp2; tmp1 = tmp2; return PriorityQueue_PriorityQueueSpliterator_New_PriorityQueue_I_I_I(t.F_this_0, lo, tmp1, t.F_expectedModCount)
	} }
func (t *PriorityQueue_PriorityQueueSpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	if t.F_fence < 0 { t.F_fence = t.F_this_0.F_size; t.F_expectedModCount = t.F_this_0.F_modCount }
	var es *RefArray = t.F_this_0.F_queue; var i int32 = 0; var hi int32 = 0; var e any



	i = t.F_index
	var tmp1 int32; hi = t.F_fence; tmp1 = hi; t.F_index = tmp1
L1: for { if i < hi {
	var tmp2 any; e = es.A[i]; tmp2 = e; if tmp2 == nil { break L1 }
	action.Accept_O__V(e)
	i = i + 1
//line :352:1
	continue L1 }; break L1
}


	if t.F_this_0.F_modCount == t.F_expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *PriorityQueue_PriorityQueueSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	if t.F_fence < 0 { t.F_fence = t.F_this_0.F_size; t.F_expectedModCount = t.F_this_0.F_modCount }
	var i int32 = 0; var tmp1 int32
	i = t.F_index; tmp1 = i; if tmp1 < t.F_fence {

		t.F_index = i + 1
		var e any; var tmp2 bool; var tmp3 bool; var tmp4 any
		e = t.F_this_0.F_queue.A[i]; tmp4 = e; tmp3 = tmp4 == nil; if !tmp3 { tmp3 = !(t.F_this_0.F_modCount == t.F_expectedModCount) }; tmp2 = tmp3; if tmp2 {
			panic(Thrown(ConcurrentModificationException_New())) }
		action.Accept_O__V(e)
//line :365:1
		return true

	} else {
//line :362:1
		return false
	}
}







func (t *PriorityQueue_PriorityQueueSpliterator) EstimateSize__J() int64 { return int64(t.GetFence__I() - t.F_index) }


func (t *PriorityQueue_PriorityQueueSpliterator) Characteristics__I() int32 {
	return 16704
}
func (t *PriorityQueue) RemoveIf_Predicate__Z(filter Predicate) bool {
	Objects_RequireNonNull_O__O(filter)
	return t.BulkRemove_Predicate__Z(filter)
}
func (t *PriorityQueue) RemoveAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	return t.BulkRemove_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var e any = p0; return c.Contains_O__Z(e) }})
}
func (t *PriorityQueue) RetainAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	return t.BulkRemove_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var e any = p0; return !c.Contains_O__Z(e) }})
}
func PriorityQueue_NBits_I__J1(n int32) *LongArray {
	return NewLongArray((n-1)>>6 + 1)
}
func PriorityQueue_SetBit_J1_I__V(bits *LongArray, i int32) {
	var i_2 int32 = i >> 6
	bits.A[i_2] = bits.A[i_2] | 1<<(i&63)
}
func PriorityQueue_IsClear_J1_I__Z(bits *LongArray, i int32) bool {
	return bits.A[i>>6]&(1<<(i&63)) == 0
}
func (t *PriorityQueue) BulkRemove_Predicate__Z(filter Predicate) bool {
	var expectedModCount int32; var tmp1 int32 = t.F_modCount + 1; t.F_modCount = tmp1; expectedModCount = tmp1; var es *RefArray = t.F_queue; var end int32 = t.F_size
	var i int32 = 0


	i = 0
L1: for { var tmp2 bool; var tmp3 bool; tmp3 = i < end; if tmp3 { tmp3 = !filter.Test_O__Z(es.A[i]) }; tmp2 = tmp3; if tmp2 { i = i + 1; continue L1 }; break L1 }
	if i >= end {

		if t.F_modCount == expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
//line :408:1
		return false } else {


			var beg int32 = i; var deathRow *LongArray = PriorityQueue_NBits_I__J1(end - beg)

			deathRow.A[0] = 1
			i = beg + 1
		L2: for { if i < end {
			if filter.Test_O__Z(es.A[i]) {
				PriorityQueue_SetBit_J1_I__V(deathRow, i-beg) }
			i = i + 1
//line :415:1
			continue L2 }; break L2
		}


			if t.F_modCount == expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
			var w int32 = beg
			i = beg
		L3: for { if i < end {
			if PriorityQueue_IsClear_J1_I__Z(deathRow, i-beg) {
				es.Store(w, es.A[i])
				w = w + 1 }
			i = i + 1
//line :422:1
			continue L3 }; break L3
		}



			var tmp4 int32; var tmp5 int32 = w; t.F_size = tmp5; tmp4 = tmp5; i = tmp4
		L4: for { if i < end { es.Store(i, nil); i = i + 1; continue L4 }; break L4 }
			t.Heapify__V()
//line :420:1
			return true
		}
}









func (t *PriorityQueue) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var expectedModCount int32 = t.F_modCount; var es *RefArray = t.F_queue; var i int32 = 0; var n int32 = t.F_size

L1: for {

	if i < n { action.Accept_O__V(es.A[i]); i, n = i+1, n; continue L1 }
//line :436:1
	break L1
}

	if expectedModCount == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	}
}

type PriorityQueue struct{ AbstractQueue; F_queue *RefArray; F_size int32; F_comparator Comparator; F_modCount int32 }

func (t *PriorityQueue) Is_Serializable() {}

const PriorityQueue_serialVersionUID int64 = -7720805057305804111

const PriorityQueue_DEFAULT_INITIAL_CAPACITY int32 = 11

func (t *PriorityQueue) Element__O() any { return t.Impl_Element__O(t) }

func (t *PriorityQueue) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *PriorityQueue) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *PriorityQueue) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *PriorityQueue) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *PriorityQueue) Remove__O() any { return t.Impl_Remove__O(t) }

func (t *PriorityQueue) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *PriorityQueue) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *PriorityQueue) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *PriorityQueue) Ref() any { if t == nil { return nil }; return t }

func (t *PriorityQueue) GetClass__Class() *Class { return PriorityQueue_class }

func (t *PriorityQueue) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PriorityQueue) CloneShallow() any { panic(CloneNotSupported(t)) }

func PriorityQueue_InstanceOf(x any) bool { _, ok := x.(*PriorityQueue); return ok }

func PriorityQueue_Cast(x any) *PriorityQueue { if x == nil { return nil }; v, ok := x.(*PriorityQueue); if !ok { panic(ClassCast(x, PriorityQueue_class)) }; return v }



type PriorityQueue_Itr struct{ Object; F_cursor, F_lastRet int32; F_forgetMeNot *ArrayDeque; F_lastRetElt any; F_expectedModCount int32; F_this_0 *PriorityQueue }

func (t *PriorityQueue_Itr) Is_Iterator() {}

func (t *PriorityQueue_Itr) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *PriorityQueue_Itr) Ref() any { if t == nil { return nil }; return t }

func (t *PriorityQueue_Itr) GetClass__Class() *Class { return PriorityQueue_Itr_class }

func (t *PriorityQueue_Itr) ToString__String() *String { return Object_toString(t) }

func (t *PriorityQueue_Itr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PriorityQueue_Itr) CloneShallow() any { panic(CloneNotSupported(t)) }

func PriorityQueue_Itr_InstanceOf(x any) bool { _, ok := x.(*PriorityQueue_Itr); return ok }

func PriorityQueue_Itr_Cast(x any) *PriorityQueue_Itr { if x == nil { return nil }; v, ok := x.(*PriorityQueue_Itr); if !ok { panic(ClassCast(x, PriorityQueue_Itr_class)) }; return v }



type PriorityQueue_PriorityQueueSpliterator struct{ Object; F_index, F_fence, F_expectedModCount int32; F_this_0 *PriorityQueue }

func (t *PriorityQueue_PriorityQueueSpliterator) Is_Spliterator() {}

func (t *PriorityQueue_PriorityQueueSpliterator) TrySplit__Spliterator() Spliterator { return Up_PriorityQueue_PriorityQueueSpliterator_Spliterator(t.TrySplit__PriorityQueue_PriorityQueueSpliterator()) }

func (t *PriorityQueue_PriorityQueueSpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *PriorityQueue_PriorityQueueSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *PriorityQueue_PriorityQueueSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *PriorityQueue_PriorityQueueSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *PriorityQueue_PriorityQueueSpliterator) GetClass__Class() *Class { return PriorityQueue_PriorityQueueSpliterator_class }

func (t *PriorityQueue_PriorityQueueSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *PriorityQueue_PriorityQueueSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PriorityQueue_PriorityQueueSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func PriorityQueue_PriorityQueueSpliterator_InstanceOf(x any) bool { _, ok := x.(*PriorityQueue_PriorityQueueSpliterator); return ok }

func PriorityQueue_PriorityQueueSpliterator_Cast(x any) *PriorityQueue_PriorityQueueSpliterator { if x == nil { return nil }; v, ok := x.(*PriorityQueue_PriorityQueueSpliterator); if !ok { panic(ClassCast(x, PriorityQueue_PriorityQueueSpliterator_class)) }; return v }
