//line java_util_EventObject.ae:1
package jrt












func EventObject_New_O(p0 any) *EventObject { t := &EventObject{}; t.Ctor_O(p0); return t }
//line :14:1
func (t *EventObject) Ctor_O(source any) {
	if source == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_2673))) }
	t.F_source = source
}
func (t *EventObject) GetSource__O() any { return t.F_source }

func (t *EventObject) ToString__String() *String {
	return Concat(NN(t.GetClass__Class()).GetName__String(), Lit_2674, StrOfObj(t.F_source), Lit_1189)
}


type EventObject struct{ Object; F_source any }

func (t *EventObject) Is_Serializable() {}

const EventObject_serialVersionUID int64 = 5516075349620653480

func (t *EventObject) Ref() any { if t == nil { return nil }; return t }

func (t *EventObject) GetClass__Class() *Class { return EventObject_class }

func (t *EventObject) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EventObject) CloneShallow() any { panic(CloneNotSupported(t)) }

func EventObject_InstanceOf(x any) bool { _, ok := x.(*EventObject); return ok }

func EventObject_Cast(x any) *EventObject { if x == nil { return nil }; v, ok := x.(*EventObject); if !ok { panic(ClassCast(x, EventObject_class)) }; return v }
