//line java_util_MissingResourceException.ae:1
package jrt






func MissingResourceException_New_String_String_String(p0, p1, p2 *String) *MissingResourceException { t := &MissingResourceException{}; t.Ctor_String_String_String(p0, p1, p2); return t }
//line :8:1
func (t *MissingResourceException) Ctor_String_String_String(s, className, key *String) { t.RuntimeException.Ctor_String(t, s)

	t.F_className = className
	t.F_key = key
}
func MissingResourceException_New_String_String_String_Throwable(p0, p1, p2 *String, p3 Throwable_I) *MissingResourceException { t := &MissingResourceException{}; t.Ctor_String_String_String_Throwable(p0, p1, p2, p3); return t }
//line :13:1
func (t *MissingResourceException) Ctor_String_String_String_Throwable(message, className, key *String, cause Throwable_I) { panic(A2g_NotTranslated("java.util.MissingResourceException.<init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V")) }




func (t *MissingResourceException) GetClassName__String() *String { return t.F_className }

func (t *MissingResourceException) GetKey__String() *String { return t.F_key }



type MissingResourceException struct{ RuntimeException; F_className, F_key *String }

const MissingResourceException_serialVersionUID int64 = -4876345176062000401

func (t *MissingResourceException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *MissingResourceException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *MissingResourceException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *MissingResourceException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *MissingResourceException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *MissingResourceException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *MissingResourceException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *MissingResourceException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *MissingResourceException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *MissingResourceException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *MissingResourceException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *MissingResourceException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MissingResourceException) Ref() any { if t == nil { return nil }; return t }

func (t *MissingResourceException) GetClass__Class() *Class { return MissingResourceException_class }

func (t *MissingResourceException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MissingResourceException) CloneShallow() any { panic(CloneNotSupported(t)) }

func MissingResourceException_InstanceOf(x any) bool { _, ok := x.(*MissingResourceException); return ok }

func MissingResourceException_Cast(x any) *MissingResourceException { if x == nil { return nil }; v, ok := x.(*MissingResourceException); if !ok { panic(ClassCast(x, MissingResourceException_class)) }; return v }
