//line java_nio_charset_UnsupportedCharsetException.ae:1
package jrt










func UnsupportedCharsetException_New_String(p0 *String) *UnsupportedCharsetException { t := &UnsupportedCharsetException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *UnsupportedCharsetException) Ctor_String(charsetName *String) { t.IllegalArgumentException.Ctor_String(t, String_ValueOf_O__String(charsetName.Ref()))

	t.F_charsetName = charsetName
}
func (t *UnsupportedCharsetException) GetCharsetName__String() *String { return t.F_charsetName }



type UnsupportedCharsetException struct{ IllegalArgumentException; F_charsetName *String }

const UnsupportedCharsetException_serialVersionUID int64 = 1490765524727386367

func (t *UnsupportedCharsetException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *UnsupportedCharsetException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *UnsupportedCharsetException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *UnsupportedCharsetException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *UnsupportedCharsetException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *UnsupportedCharsetException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *UnsupportedCharsetException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *UnsupportedCharsetException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *UnsupportedCharsetException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *UnsupportedCharsetException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *UnsupportedCharsetException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *UnsupportedCharsetException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *UnsupportedCharsetException) Ref() any { if t == nil { return nil }; return t }

func (t *UnsupportedCharsetException) GetClass__Class() *Class { return UnsupportedCharsetException_class }

func (t *UnsupportedCharsetException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UnsupportedCharsetException) CloneShallow() any { panic(CloneNotSupported(t)) }

func UnsupportedCharsetException_InstanceOf(x any) bool { _, ok := x.(*UnsupportedCharsetException); return ok }

func UnsupportedCharsetException_Cast(x any) *UnsupportedCharsetException { if x == nil { return nil }; v, ok := x.(*UnsupportedCharsetException); if !ok { panic(ClassCast(x, UnsupportedCharsetException_class)) }; return v }
