//line java_security_ProviderException.ae:1
package jrt








func ProviderException_New() *ProviderException { t := &ProviderException{}; t.Ctor(); return t }
//line :10:1
func (t *ProviderException) Ctor() { t.RuntimeException.Ctor(t) }

func ProviderException_New_String(p0 *String) *ProviderException { t := &ProviderException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *ProviderException) Ctor_String(s *String) { t.RuntimeException.Ctor_String(t, s) }

func ProviderException_New_String_Throwable(p0 *String, p1 Throwable_I) *ProviderException { t := &ProviderException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *ProviderException) Ctor_String_Throwable(message *String, cause Throwable_I) { t.RuntimeException.Ctor_String_Throwable(t, message, cause) }


func ProviderException_New_Throwable(p0 Throwable_I) *ProviderException { t := &ProviderException{}; t.Ctor_Throwable(p0); return t }
//line :17:1
func (t *ProviderException) Ctor_Throwable(cause Throwable_I) { t.RuntimeException.Ctor_Throwable(t, cause) }










type ProviderException struct{ RuntimeException }

const ProviderException_serialVersionUID int64 = 5256023526693665674

func (t *ProviderException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ProviderException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ProviderException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ProviderException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ProviderException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ProviderException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ProviderException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ProviderException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ProviderException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ProviderException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ProviderException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ProviderException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProviderException) Ref() any { if t == nil { return nil }; return t }

func (t *ProviderException) GetClass__Class() *Class { return ProviderException_class }

func (t *ProviderException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProviderException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProviderException_InstanceOf(x any) bool { _, ok := x.(*ProviderException); return ok }

func ProviderException_Cast(x any) *ProviderException { if x == nil { return nil }; v, ok := x.(*ProviderException); if !ok { panic(ClassCast(x, ProviderException_class)) }; return v }
