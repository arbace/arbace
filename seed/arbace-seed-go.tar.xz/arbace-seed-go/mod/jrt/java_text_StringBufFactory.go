//line java_text_StringBufFactory.ae:1
package jrt




func StringBufFactory_New() *StringBufFactory { t := &StringBufFactory{}; t.Ctor(); return t }
//line :6:1
func (t *StringBufFactory) Ctor() { panic(A2g_NotTranslated("java.text.StringBufFactory.<init>()V")) }

func StringBufFactory_Of_StringBuffer__Format_StringBuf(sb *StringBuffer) Format_StringBuf {
	return StringBufFactory_StringBufferImpl_New_StringBuffer(sb)
}
func StringBufFactory_Of_StringBuilder__Format_StringBuf(p0 *StringBuilder) Format_StringBuf { panic(A2g_NotTranslated("java.text.StringBufFactory.of(Ljava/lang/StringBuilder;)Ljava/text/Format$StringBuf;")) }


func StringBufFactory_Of__Format_StringBuf() Format_StringBuf { return StringBufFactory_StringBuilderImpl_New() }






func StringBufFactory_StringBufferImpl_New_StringBuffer(p0 *StringBuffer) *StringBufFactory_StringBufferImpl { t := &StringBufFactory_StringBufferImpl{}; t.Ctor_StringBuffer(p0); return t }
//line :21:1
func (t *StringBufFactory_StringBufferImpl) Ctor_StringBuffer(sb *StringBuffer) { t.F_sb = sb }

func (t *StringBufFactory_StringBufferImpl) Length__I() int32 { return NN(t.F_sb).Length__I() }

func (t *StringBufFactory_StringBufferImpl) Substring_I_I__String(start, end int32) *String {
	return NN(t.F_sb).Substring_I_I__String(start, end)
}
func (t *StringBufFactory_StringBufferImpl) Substring_I__String(start int32) *String {
	return NN(t.F_sb).Substring_I__String(start)
}
func (t *StringBufFactory_StringBufferImpl) Append_C__Format_StringBuf(c uint16) Format_StringBuf {
	NN(t.F_sb).Append_C__StringBuffer(c)
//line :31:1
	return t
}


func (t *StringBufFactory_StringBufferImpl) Append_String__Format_StringBuf(str *String) Format_StringBuf {
	NN(t.F_sb).Append_String__StringBuffer(str)
//line :35:1
	return t
}


func (t *StringBufFactory_StringBufferImpl) Append_I__Format_StringBuf(i int32) Format_StringBuf {
	NN(t.F_sb).Append_I__StringBuffer(i)
//line :39:1
	return t
}


func (t *StringBufFactory_StringBufferImpl) Append_C1_I_I__Format_StringBuf(str *CharArray, offset, len_ int32) Format_StringBuf {
	NN(t.F_sb).Append_C1_I_I__StringBuffer(str, offset, len_)
//line :43:1
	return t
}


func (t *StringBufFactory_StringBufferImpl) Append_CharSequence_I_I__Format_StringBuf(s CharSequence, start, end int32) Format_StringBuf {
	NN(t.F_sb).Append_CharSequence_I_I__StringBuffer(s, start, end)
//line :47:1
	return t
}


func (t *StringBufFactory_StringBufferImpl) Append_StringBuffer__Format_StringBuf(asb *StringBuffer) Format_StringBuf {
	NN(t.F_sb).Append_StringBuffer__StringBuffer(asb)
//line :51:1
	return t
}


func (t *StringBufFactory_StringBufferImpl) IsProxyStringBuilder__Z() bool { return false }

func (t *StringBufFactory_StringBufferImpl) AsStringBuffer__StringBuffer() *StringBuffer { return t.F_sb }

func (t *StringBufFactory_StringBufferImpl) AsStringBuilder__StringBuilder() *StringBuilder {
	panic(Thrown(AssertionError_New_O(Lit_1976)))
}
func (t *StringBufFactory_StringBufferImpl) ToString__String() *String { return NN(t.F_sb).ToString__String() }






func StringBufFactory_StringBuilderImpl_New_StringBuilder(p0 *StringBuilder) *StringBufFactory_StringBuilderImpl { t := &StringBufFactory_StringBuilderImpl{}; t.Ctor_StringBuilder(p0); return t }
//line :69:1
func (t *StringBufFactory_StringBuilderImpl) Ctor_StringBuilder(sb *StringBuilder) { panic(A2g_NotTranslated("java.text.StringBufFactory$StringBuilderImpl.<init>(Ljava/lang/StringBuilder;)V")) }

func StringBufFactory_StringBuilderImpl_New() *StringBufFactory_StringBuilderImpl { t := &StringBufFactory_StringBuilderImpl{}; t.Ctor(); return t }
//line :71:1
func (t *StringBufFactory_StringBuilderImpl) Ctor() { t.F_sb = StringBuilder_New() }

func (t *StringBufFactory_StringBuilderImpl) Length__I() int32 { return NN(t.F_sb).Length__I() }

func (t *StringBufFactory_StringBuilderImpl) Substring_I_I__String(start, end int32) *String {
	return NN(t.F_sb).Substring_I_I__String(start, end)
}
func (t *StringBufFactory_StringBuilderImpl) Substring_I__String(start int32) *String {
	return NN(t.F_sb).Substring_I__String(start)
}
func (t *StringBufFactory_StringBuilderImpl) Append_C__Format_StringBuf(c uint16) Format_StringBuf {
	NN(t.F_sb).Append_C__StringBuilder(c)
//line :81:1
	return t
}


func (t *StringBufFactory_StringBuilderImpl) Append_String__Format_StringBuf(str *String) Format_StringBuf {
	NN(t.F_sb).Append_String__StringBuilder(str)
//line :85:1
	return t
}


func (t *StringBufFactory_StringBuilderImpl) Append_I__Format_StringBuf(i int32) Format_StringBuf {
	NN(t.F_sb).Append_I__StringBuilder(i)
//line :89:1
	return t
}


func (t *StringBufFactory_StringBuilderImpl) Append_C1_I_I__Format_StringBuf(str *CharArray, offset, len_ int32) Format_StringBuf {
	NN(t.F_sb).Append_C1_I_I__StringBuilder(str, offset, len_)
//line :93:1
	return t
}


func (t *StringBufFactory_StringBuilderImpl) Append_CharSequence_I_I__Format_StringBuf(s CharSequence, start, end int32) Format_StringBuf {
	NN(t.F_sb).Append_CharSequence_I_I__StringBuilder(s, start, end)
//line :97:1
	return t
}


func (t *StringBufFactory_StringBuilderImpl) Append_StringBuffer__Format_StringBuf(asb *StringBuffer) Format_StringBuf {
	NN(t.F_sb).Append_StringBuffer__StringBuilder(asb)
//line :101:1
	return t
}


func (t *StringBufFactory_StringBuilderImpl) IsProxyStringBuilder__Z() bool { return true }

func (t *StringBufFactory_StringBuilderImpl) AsStringBuffer__StringBuffer() *StringBuffer {
	panic(Thrown(AssertionError_New_O(Lit_1977)))
}
func (t *StringBufFactory_StringBuilderImpl) AsStringBuilder__StringBuilder() *StringBuilder { return t.F_sb }

func (t *StringBufFactory_StringBuilderImpl) ToString__String() *String { return NN(t.F_sb).ToString__String() }



type StringBufFactory struct{ Object }

func (t *StringBufFactory) Ref() any { if t == nil { return nil }; return t }

func (t *StringBufFactory) GetClass__Class() *Class { return StringBufFactory_class }

func (t *StringBufFactory) ToString__String() *String { return Object_toString(t) }

func (t *StringBufFactory) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringBufFactory) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringBufFactory_InstanceOf(x any) bool { _, ok := x.(*StringBufFactory); return ok }

func StringBufFactory_Cast(x any) *StringBufFactory { if x == nil { return nil }; v, ok := x.(*StringBufFactory); if !ok { panic(ClassCast(x, StringBufFactory_class)) }; return v }



type StringBufFactory_StringBufferImpl struct{ Object; F_sb *StringBuffer }

func (t *StringBufFactory_StringBufferImpl) Is_Format_StringBuf() {}

func (t *StringBufFactory_StringBufferImpl) Ref() any { if t == nil { return nil }; return t }

func (t *StringBufFactory_StringBufferImpl) GetClass__Class() *Class { return StringBufFactory_StringBufferImpl_class }

func (t *StringBufFactory_StringBufferImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringBufFactory_StringBufferImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringBufFactory_StringBufferImpl_InstanceOf(x any) bool { _, ok := x.(*StringBufFactory_StringBufferImpl); return ok }

func StringBufFactory_StringBufferImpl_Cast(x any) *StringBufFactory_StringBufferImpl { if x == nil { return nil }; v, ok := x.(*StringBufFactory_StringBufferImpl); if !ok { panic(ClassCast(x, StringBufFactory_StringBufferImpl_class)) }; return v }



type StringBufFactory_StringBuilderImpl struct{ Object; F_sb *StringBuilder }

func (t *StringBufFactory_StringBuilderImpl) Is_Format_StringBuf() {}

func (t *StringBufFactory_StringBuilderImpl) Ref() any { if t == nil { return nil }; return t }

func (t *StringBufFactory_StringBuilderImpl) GetClass__Class() *Class { return StringBufFactory_StringBuilderImpl_class }

func (t *StringBufFactory_StringBuilderImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringBufFactory_StringBuilderImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringBufFactory_StringBuilderImpl_InstanceOf(x any) bool { _, ok := x.(*StringBufFactory_StringBuilderImpl); return ok }

func StringBufFactory_StringBuilderImpl_Cast(x any) *StringBufFactory_StringBuilderImpl { if x == nil { return nil }; v, ok := x.(*StringBufFactory_StringBuilderImpl); if !ok { panic(ClassCast(x, StringBufFactory_StringBuilderImpl_class)) }; return v }
