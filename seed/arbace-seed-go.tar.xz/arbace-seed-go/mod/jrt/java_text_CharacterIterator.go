//line java_text_CharacterIterator.ae:1
package jrt






type CharacterIterator interface{ Object_I; Cloneable; Is_CharacterIterator(); First__C() uint16; Last__C() uint16; Current__C() uint16; Next__C() uint16; Previous__C() uint16; SetIndex_I__C(p0 int32) uint16; GetBeginIndex__I() int32; GetEndIndex__I() int32; GetIndex__I() int32 }

const CharacterIterator_DONE uint16 = 65535

func CharacterIterator_InstanceOf(x any) bool { _, ok := x.(CharacterIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CharacterIterator_class) } }; return ok }

func CharacterIterator_Cast(x any) CharacterIterator { if x == nil { return nil }; v, ok := x.(CharacterIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CharacterIterator_class) } }; if !ok { panic(ClassCast(x, CharacterIterator_class)) }; return v }
