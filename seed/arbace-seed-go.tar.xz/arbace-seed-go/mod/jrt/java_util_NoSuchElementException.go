//line java_util_NoSuchElementException.ae:1
package jrt








func NoSuchElementException_New() *NoSuchElementException { t := &NoSuchElementException{}; t.Ctor(t); return t }
//line :10:1
func (t *NoSuchElementException) Ctor(this NoSuchElementException_I) { t.RuntimeException.Ctor(this) }

func NoSuchElementException_New_String_Throwable(p0 *String, p1 Throwable_I) *NoSuchElementException { t := &NoSuchElementException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :12:1
func (t *NoSuchElementException) Ctor_String_Throwable(this NoSuchElementException_I, s *String, cause Throwable_I) { t.RuntimeException.Ctor_String_Throwable(this, s, cause) }


func NoSuchElementException_New_Throwable(p0 Throwable_I) *NoSuchElementException { t := &NoSuchElementException{}; t.Ctor_Throwable(t, p0); return t }
//line :15:1
func (t *NoSuchElementException) Ctor_Throwable(this NoSuchElementException_I, cause Throwable_I) { t.RuntimeException.Ctor_Throwable(this, cause) }

func NoSuchElementException_New_String(p0 *String) *NoSuchElementException { t := &NoSuchElementException{}; t.Ctor_String(t, p0); return t }
//line :17:1
func (t *NoSuchElementException) Ctor_String(this NoSuchElementException_I, s *String) { t.RuntimeException.Ctor_String(this, s) }










type NoSuchElementException struct{ RuntimeException }

type NoSuchElementException_I interface{ RuntimeException_I; Serializable; Self_NoSuchElementException() *NoSuchElementException }

func (t *NoSuchElementException) Self_NoSuchElementException() *NoSuchElementException { return t }

const NoSuchElementException_serialVersionUID int64 = 6769829250639411880

func (t *NoSuchElementException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoSuchElementException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoSuchElementException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoSuchElementException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoSuchElementException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoSuchElementException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoSuchElementException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoSuchElementException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoSuchElementException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoSuchElementException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoSuchElementException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoSuchElementException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoSuchElementException) Ref() any { if t == nil { return nil }; return t }

func (t *NoSuchElementException) GetClass__Class() *Class { return NoSuchElementException_class }

func (t *NoSuchElementException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoSuchElementException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoSuchElementException_InstanceOf(x any) bool { _, ok := x.(NoSuchElementException_I); return ok }

func NoSuchElementException_Cast(x any) NoSuchElementException_I { if x == nil { return nil }; v, ok := x.(NoSuchElementException_I); if !ok { panic(ClassCast(x, NoSuchElementException_class)) }; return v }
