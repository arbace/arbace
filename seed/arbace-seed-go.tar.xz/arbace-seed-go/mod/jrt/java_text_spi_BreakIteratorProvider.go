//line java_text_spi_BreakIteratorProvider.ae:1
package jrt










func (t *BreakIteratorProvider) Ctor(this BreakIteratorProvider_I) { t.LocaleServiceProvider.Ctor(this) }



type BreakIteratorProvider struct{ LocaleServiceProvider }

type BreakIteratorProvider_I interface{ LocaleServiceProvider_I; Self_BreakIteratorProvider() *BreakIteratorProvider; GetWordInstance_Locale__BreakIterator(p0 *Locale) BreakIterator_I; GetLineInstance_Locale__BreakIterator(p0 *Locale) BreakIterator_I; GetCharacterInstance_Locale__BreakIterator(p0 *Locale) BreakIterator_I; GetSentenceInstance_Locale__BreakIterator(p0 *Locale) BreakIterator_I }

func (t *BreakIteratorProvider) Self_BreakIteratorProvider() *BreakIteratorProvider { return t }

func BreakIteratorProvider_InstanceOf(x any) bool { _, ok := x.(BreakIteratorProvider_I); return ok }

func BreakIteratorProvider_Cast(x any) BreakIteratorProvider_I { if x == nil { return nil }; v, ok := x.(BreakIteratorProvider_I); if !ok { panic(ClassCast(x, BreakIteratorProvider_class)) }; return v }
