//line java_util_AbstractQueue.ae:1
package jrt








func (t *AbstractQueue) Ctor(this AbstractQueue_I) { t.AbstractCollection.Ctor(this) }

func (t *AbstractQueue) Impl_Add_O__Z(this AbstractQueue_I, e any) bool {
	if this.Offer_O__Z(e) { return true } else { panic(Thrown(IllegalStateException_New_String(Lit_2599)))
	} }
func (t *AbstractQueue) Impl_Remove__O(this AbstractQueue_I) any {
	var x any = this.Poll__O(); if !(x == nil) { return x } else { panic(Thrown(NoSuchElementException_New()))
	} }
func (t *AbstractQueue) Impl_Element__O(this AbstractQueue_I) any {
	var x any = this.Peek__O(); if !(x == nil) { return x } else { panic(Thrown(NoSuchElementException_New()))
	} }
func (t *AbstractQueue) Impl_Clear__V(this AbstractQueue_I) { L1: for { if !(this.Poll__O() == nil) { continue L1 }; break L1 } }

func (t *AbstractQueue) Impl_AddAll_Collection__Z(this AbstractQueue_I, c Collection) bool {
	if c == nil { panic(Thrown(NullPointerException_New())) }
	if any(c) == any(this) { panic(Thrown(IllegalArgumentException_New())) }
	var modified bool = false; var i_101730 Iterator = c.Iterator__Iterator(); for i_101730.HasNext__Z() {
		var e any = i_101730.Next__O(); if this.Add_O__Z(e) { modified = true } }
//line :26:1
	return modified
}



type AbstractQueue struct{ AbstractCollection }

type AbstractQueue_I interface{ AbstractCollection_I; Queue; Collection; Iterable; Self_AbstractQueue() *AbstractQueue; Add_O__Z(p0 any) bool; Remove__O() any; Element__O() any; Clear__V(); AddAll_Collection__Z(p0 Collection) bool }

func (t *AbstractQueue) Self_AbstractQueue() *AbstractQueue { return t }

func (t *AbstractQueue) Is_Queue() {}

func AbstractQueue_InstanceOf(x any) bool { _, ok := x.(AbstractQueue_I); return ok }

func AbstractQueue_Cast(x any) AbstractQueue_I { if x == nil { return nil }; v, ok := x.(AbstractQueue_I); if !ok { panic(ClassCast(x, AbstractQueue_class)) }; return v }
