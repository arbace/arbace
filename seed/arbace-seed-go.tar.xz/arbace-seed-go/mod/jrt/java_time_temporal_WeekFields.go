//line java_time_temporal_WeekFields.ae:1
package jrt












































func WeekFields_Of_Locale__WeekFields(locale *Locale) *WeekFields { WeekFields_Init()
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	var calDow int32 = CalendarDataUtility_RetrieveFirstDayOfWeek_Locale__I(locale); var dow *DayOfWeek; var tmp1 *DayOfWeek
	DayOfWeek_Init(); tmp1 = DayOfWeek_SUNDAY; dow = NN(tmp1).Plus_J__DayOfWeek(int64(calDow - 1))
//line :48:1
	var minDays int32 = CalendarDataUtility_RetrieveMinimalDaysInFirstWeek_Locale__I(locale)


	return WeekFields_Of_DayOfWeek_I__WeekFields(dow, minDays)
}
func WeekFields_Of_DayOfWeek_I__WeekFields(firstDayOfWeek *DayOfWeek, minimalDaysInFirstWeek int32) *WeekFields { WeekFields_Init()
	var key *String = Concat(NN(firstDayOfWeek).ToString__String(), StrOfInt(minimalDaysInFirstWeek)); var rules *WeekFields = WeekFields_Cast(WeekFields_CACHE.Get_O__O(key.Ref()))

	if rules == nil {
		rules = WeekFields_New_DayOfWeek_I(firstDayOfWeek, minimalDaysInFirstWeek)
		var prev *WeekFields = WeekFields_Cast(WeekFields_CACHE.PutIfAbsent_O_O__O(key.Ref(), rules.Ref()))
		if !(prev == nil) { rules = prev } }
//line :54:1
	return rules
}






func WeekFields_New_DayOfWeek_I(p0 *DayOfWeek, p1 int32) *WeekFields { WeekFields_Init(); t := &WeekFields{}; t.Ctor_DayOfWeek_I(p0, p1); return t }
//line :62:1
func (t *WeekFields) Ctor_DayOfWeek_I(firstDayOfWeek *DayOfWeek, minimalDaysInFirstWeek int32) { t.F_dayOfWeek = Up_WeekFields_ComputedDayOfField_TemporalField(WeekFields_ComputedDayOfField_OfDayOfWeekField_WeekFields__WeekFields_ComputedDayOfField(t)); t.F_weekOfMonth = Up_WeekFields_ComputedDayOfField_TemporalField(WeekFields_ComputedDayOfField_OfWeekOfMonthField_WeekFields__WeekFields_ComputedDayOfField(t)); t.F_weekOfYear = Up_WeekFields_ComputedDayOfField_TemporalField(WeekFields_ComputedDayOfField_OfWeekOfYearField_WeekFields__WeekFields_ComputedDayOfField(t)); t.F_weekOfWeekBasedYear = Up_WeekFields_ComputedDayOfField_TemporalField(WeekFields_ComputedDayOfField_OfWeekOfWeekBasedYearField_WeekFields__WeekFields_ComputedDayOfField(t)); t.F_weekBasedYear = Up_WeekFields_ComputedDayOfField_TemporalField(WeekFields_ComputedDayOfField_OfWeekBasedYearField_WeekFields__WeekFields_ComputedDayOfField(t))
	Objects_RequireNonNull_O_String__O(firstDayOfWeek.Ref(), Lit_2535)
	var tmp1 bool; var tmp2 bool; tmp2 = minimalDaysInFirstWeek < 1; if !tmp2 { tmp2 = minimalDaysInFirstWeek > 7 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2536))) }
	t.F_firstDayOfWeek = firstDayOfWeek
	t.F_minimalDays = minimalDaysInFirstWeek
}







func (t *WeekFields) ReadResolve__O() any { panic(A2g_NotTranslated("java.time.temporal.WeekFields.readResolve()Ljava/lang/Object;")) }






func (t *WeekFields) GetFirstDayOfWeek__DayOfWeek() *DayOfWeek { return t.F_firstDayOfWeek }

func (t *WeekFields) GetMinimalDaysInFirstWeek__I() int32 { return t.F_minimalDays }

func (t *WeekFields) DayOfWeek__TemporalField() TemporalField { return t.F_dayOfWeek }

func (t *WeekFields) WeekOfMonth__TemporalField() TemporalField { return t.F_weekOfMonth }

func (t *WeekFields) WeekOfYear__TemporalField() TemporalField { return t.F_weekOfYear }

func (t *WeekFields) WeekOfWeekBasedYear__TemporalField() TemporalField { return t.F_weekOfWeekBasedYear }


func (t *WeekFields) WeekBasedYear__TemporalField() TemporalField { return t.F_weekBasedYear }

func (t *WeekFields) Equals_O__Z(object any) bool {
	if any(t) == any(object) { return true } else { if WeekFields_InstanceOf(object) {

		return t.HashCode__I() == HashCode(object) } else {
//line :99:1
			return false
		}
	}
}

func (t *WeekFields) HashCode__I() int32 {
	return NN(t.F_firstDayOfWeek).Ordinal__I()*7 + t.F_minimalDays
}
func (t *WeekFields) ToString__String() *String {
	return Concat(Lit_2537, StrOfObj(t.F_firstDayOfWeek.Ref()), Lit_1532, StrOfInt(t.F_minimalDays), Lit_1189)
}



func WeekFields_ComputedDayOfField_OfDayOfWeekField_WeekFields__WeekFields_ComputedDayOfField(weekDef *WeekFields) *WeekFields_ComputedDayOfField { WeekFields_ComputedDayOfField_Init()
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_DAYS; var tmp2 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp1); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_WEEKS; return WeekFields_ComputedDayOfField_New_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(Lit_2358, weekDef, tmp2, Up_ChronoUnit_TemporalUnit(tmp3), WeekFields_ComputedDayOfField_DAY_OF_WEEK_RANGE)
}
func WeekFields_ComputedDayOfField_OfWeekOfMonthField_WeekFields__WeekFields_ComputedDayOfField(weekDef *WeekFields) *WeekFields_ComputedDayOfField { WeekFields_ComputedDayOfField_Init()
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_WEEKS; var tmp2 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp1); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_MONTHS; return WeekFields_ComputedDayOfField_New_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(Lit_2360, weekDef, tmp2, Up_ChronoUnit_TemporalUnit(tmp3), WeekFields_ComputedDayOfField_WEEK_OF_MONTH_RANGE)
}




func WeekFields_ComputedDayOfField_OfWeekOfYearField_WeekFields__WeekFields_ComputedDayOfField(weekDef *WeekFields) *WeekFields_ComputedDayOfField { WeekFields_ComputedDayOfField_Init()
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_WEEKS; var tmp2 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp1); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_YEARS; return WeekFields_ComputedDayOfField_New_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(Lit_2538, weekDef, tmp2, Up_ChronoUnit_TemporalUnit(tmp3), WeekFields_ComputedDayOfField_WEEK_OF_YEAR_RANGE)
}




func WeekFields_ComputedDayOfField_OfWeekOfWeekBasedYearField_WeekFields__WeekFields_ComputedDayOfField(weekDef *WeekFields) *WeekFields_ComputedDayOfField { WeekFields_ComputedDayOfField_Init()
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_WEEKS; var tmp2 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp1); var tmp3 TemporalUnit; IsoFields_Init(); tmp3 = IsoFields_WEEK_BASED_YEARS; return WeekFields_ComputedDayOfField_New_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(Lit_2359, weekDef, tmp2, tmp3, WeekFields_ComputedDayOfField_WEEK_OF_WEEK_BASED_YEAR_RANGE)
}




func WeekFields_ComputedDayOfField_OfWeekBasedYearField_WeekFields__WeekFields_ComputedDayOfField(weekDef *WeekFields) *WeekFields_ComputedDayOfField { WeekFields_ComputedDayOfField_Init()
	var tmp1 TemporalUnit; IsoFields_Init(); tmp1 = IsoFields_WEEK_BASED_YEARS; var tmp2 TemporalUnit = tmp1; var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_FOREVER; var tmp4 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp3); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; return WeekFields_ComputedDayOfField_New_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(Lit_2355, weekDef, tmp2, tmp4, NN(tmp5).Range__ValueRange())
}




func (t *WeekFields_ComputedDayOfField) OfWeekBasedYear_Chronology_I_I_I__ChronoLocalDate(chrono Chronology, yowby, wowby, dow int32) ChronoLocalDate {

	var date ChronoLocalDate = chrono.Date_I_I_I__ChronoLocalDate(yowby, 1, 1); var ldow int32 = t.LocalizedDayOfWeek_TemporalAccessor__I(date); var offset int32 = t.StartOfWeekOffset_I_I__I(1, ldow); var yearLen int32 = date.LengthOfYear__I(); var newYearWeek int32 = t.ComputeWeek_I_I__I(offset, yearLen+NN(t.F_weekDef).GetMinimalDaysInFirstWeek__I())








	wowby = Math_Min_I_I__I(wowby, newYearWeek-1)
	var days int32 = -offset + (dow - 1) + (wowby-1)*7; var tmp1 int64 = int64(days); var tmp2 *ChronoUnit



	ChronoUnit_Init(); tmp2 = ChronoUnit_DAYS; return date.Plus_J_TemporalUnit__ChronoLocalDate(tmp1, Up_ChronoUnit_TemporalUnit(tmp2))
}










func WeekFields_ComputedDayOfField_New_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(p0 *String, p1 *WeekFields, p2, p3 TemporalUnit, p4 *ValueRange) *WeekFields_ComputedDayOfField { WeekFields_ComputedDayOfField_Init(); t := &WeekFields_ComputedDayOfField{}; t.Ctor_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(p0, p1, p2, p3, p4); return t }
//line :172:1
func (t *WeekFields_ComputedDayOfField) Ctor_String_WeekFields_TemporalUnit_TemporalUnit_ValueRange(name *String, weekDef *WeekFields, baseUnit, rangeUnit TemporalUnit, range_ *ValueRange) {

	t.F_name = name
	t.F_weekDef = weekDef
	t.F_baseUnit = baseUnit
	t.F_rangeUnit = rangeUnit
	t.F_range = range_
}









func (t *WeekFields_ComputedDayOfField) GetFrom_TemporalAccessor__J(temporal TemporalAccessor) int64 {
	var tmp1 TemporalUnit = t.F_rangeUnit; var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_WEEKS; if any(tmp1) == any(tmp2.Ref()) { return int64(t.LocalizedDayOfWeek_TemporalAccessor__I(temporal)) } else { var tmp3 TemporalUnit = t.F_rangeUnit; var tmp4 *ChronoUnit; ChronoUnit_Init(); tmp4 = ChronoUnit_MONTHS; if any(tmp3) == any(tmp4.Ref()) {

		return t.LocalizedWeekOfMonth_TemporalAccessor__J(temporal) } else {
//line :190:1
			var tmp5 TemporalUnit = t.F_rangeUnit; var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_YEARS; if any(tmp5) == any(tmp6.Ref()) {


				return t.LocalizedWeekOfYear_TemporalAccessor__J(temporal) } else {
//line :190:1
					var tmp7 TemporalUnit = t.F_rangeUnit; var tmp8 TemporalUnit; WeekFields_Init(); tmp8 = WeekFields_WEEK_BASED_YEARS; if tmp7 == tmp8 { return int64(t.LocalizedWeekOfWeekBasedYear_TemporalAccessor__I(temporal)) } else { var tmp9 TemporalUnit = t.F_rangeUnit; var tmp10 *ChronoUnit; ChronoUnit_Init(); tmp10 = ChronoUnit_FOREVER; if any(tmp9) == any(tmp10.Ref()) { return int64(t.LocalizedWeekBasedYear_TemporalAccessor__I(temporal)) } else {






						panic(Thrown(IllegalStateException_New_String(Concat(Lit_2539, StrOfObj(t.F_rangeUnit), Lit_2540, StrOfObj(t)))))
					}
					} } } } }
func (t *WeekFields_ComputedDayOfField) LocalizedDayOfWeek_TemporalAccessor__I(temporal TemporalAccessor) int32 {
	var sow int32 = NN(NN(t.F_weekDef).GetFirstDayOfWeek__DayOfWeek()).GetValue__I(); var isoDow int32; var tmp1 *ChronoField
	ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; isoDow = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp1))
	return Math_FloorMod_I_I__I(isoDow-sow, 7) + 1
}
func (t *WeekFields_ComputedDayOfField) LocalizedDayOfWeek_I__I(isoDow int32) int32 {
	var sow int32 = NN(NN(t.F_weekDef).GetFirstDayOfWeek__DayOfWeek()).GetValue__I()
	return Math_FloorMod_I_I__I(isoDow-sow, 7) + 1
}
func (t *WeekFields_ComputedDayOfField) LocalizedWeekOfMonth_TemporalAccessor__J(temporal TemporalAccessor) int64 { var tmp1 int32; var dow int32 = t.LocalizedDayOfWeek_TemporalAccessor__I(temporal); var dom int32; var tmp2 *ChronoField;

	ChronoField_Init(); tmp2 = ChronoField_DAY_OF_MONTH; dom = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)); var offset int32 = /*line :210:1*/t.StartOfWeekOffset_I_I__I(dom, dow); tmp1 =


	t.ComputeWeek_I_I__I(offset, dom); return /*line :209:1*/ int64(tmp1) }





func (t *WeekFields_ComputedDayOfField) LocalizedWeekOfYear_TemporalAccessor__J(temporal TemporalAccessor) int64 { var tmp1 int32; var dow int32 = t.LocalizedDayOfWeek_TemporalAccessor__I(temporal); var doy int32; var tmp2 *ChronoField;

	ChronoField_Init(); tmp2 = ChronoField_DAY_OF_YEAR; doy = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)); var offset int32 = /*line :216:1*/t.StartOfWeekOffset_I_I__I(doy, dow); tmp1 =


	t.ComputeWeek_I_I__I(offset, doy); return /*line :215:1*/ int64(tmp1) }





func (t *WeekFields_ComputedDayOfField) LocalizedWeekBasedYear_TemporalAccessor__I(temporal TemporalAccessor) int32 {
	var dow int32 = t.LocalizedDayOfWeek_TemporalAccessor__I(temporal); var year int32; var tmp1 *ChronoField
	ChronoField_Init(); tmp1 = ChronoField_YEAR; year = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp1))
//line :222:1
	var doy int32; var tmp2 *ChronoField

	ChronoField_Init(); tmp2 = ChronoField_DAY_OF_YEAR; doy = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2))
//line :222:1
	var offset int32 = t.StartOfWeekOffset_I_I__I(doy, dow); var week int32 = t.ComputeWeek_I_I__I(offset, doy)




	if week == 0 {
		return year - 1 } else {

			var dayRange *ValueRange; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_YEAR; dayRange = temporal.Range_TemporalField__ValueRange(Up_ChronoField_TemporalField(tmp3)); var yearLen int32 = int32(NN(dayRange).GetMaximum__J()); var newYearWeek int32 = t.ComputeWeek_I_I__I(offset, yearLen+NN(t.F_weekDef).GetMinimalDaysInFirstWeek__I())






			if week >= newYearWeek { return year + 1 }
//line :229:1
			return year
		}
}








func (t *WeekFields_ComputedDayOfField) LocalizedWeekOfWeekBasedYear_TemporalAccessor__I(temporal TemporalAccessor) int32 {
	var dow int32 = t.LocalizedDayOfWeek_TemporalAccessor__I(temporal); var doy int32; var tmp1 *ChronoField
	ChronoField_Init(); tmp1 = ChronoField_DAY_OF_YEAR; doy = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp1))
//line :241:1
	var offset int32 = t.StartOfWeekOffset_I_I__I(doy, dow); var week int32 = t.ComputeWeek_I_I__I(offset, doy)



	if week == 0 {
		var date ChronoLocalDate = Chronology_From_TemporalAccessor__Chronology(temporal).Date_TemporalAccessor__ChronoLocalDate(temporal); var tmp2 ChronoLocalDate = date; var tmp3 int64 = int64(doy); var tmp4 *ChronoUnit
		ChronoUnit_Init(); tmp4 = ChronoUnit_DAYS; date = tmp2.Minus_J_TemporalUnit__ChronoLocalDate(tmp3, Up_ChronoUnit_TemporalUnit(tmp4))
		return t.LocalizedWeekOfWeekBasedYear_TemporalAccessor__I(date) } else {

			if week > 50 {
				var dayRange *ValueRange; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_DAY_OF_YEAR; dayRange = temporal.Range_TemporalField__ValueRange(Up_ChronoField_TemporalField(tmp5)); var yearLen int32 = int32(NN(dayRange).GetMaximum__J()); var newYearWeek int32 = t.ComputeWeek_I_I__I(offset, yearLen+NN(t.F_weekDef).GetMinimalDaysInFirstWeek__I())






				if week >= newYearWeek {
					week = week - newYearWeek + 1 } }
//line :249:1
			return week
		}
}










func (t *WeekFields_ComputedDayOfField) StartOfWeekOffset_I_I__I(day, dow int32) int32 {
	var weekStart int32 = Math_FloorMod_I_I__I(day-dow, 7); var offset int32 = -weekStart

	if weekStart+1 > NN(t.F_weekDef).GetMinimalDaysInFirstWeek__I() {
		offset = 7 - weekStart }
//line :263:1
	return offset
}




func (t *WeekFields_ComputedDayOfField) ComputeWeek_I_I__I(offset, day int32) int32 {
	return (7 + offset + (day - 1)) / 7
}


func (t *WeekFields_ComputedDayOfField) AdjustInto_Temporal_J__Temporal(temporal Temporal, newValue int64) Temporal {

	var newVal int32 = NN(t.F_range).CheckValidIntValue_J_TemporalField__I(newValue, t); var currentVal int32 = temporal.Get_TemporalField__I(t)

	if newVal == currentVal { return temporal } else { var tmp1 TemporalUnit = t.F_rangeUnit; var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_FOREVER; if any(tmp1) == any(tmp2.Ref()) {


		var idow int32 = temporal.Get_TemporalField__I(t.F_weekDef.F_dayOfWeek); var wowby int32 = temporal.Get_TemporalField__I(t.F_weekDef.F_weekOfWeekBasedYear)

		return t.OfWeekBasedYear_Chronology_I_I_I__ChronoLocalDate(Chronology_From_TemporalAccessor__Chronology(temporal), int32(newValue), wowby, idow) } else {




			return temporal.Plus_J_TemporalUnit__Temporal(int64(newVal-currentVal), t.F_baseUnit)
		} } }
func (t *WeekFields_ComputedDayOfField) Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(fieldValues Map, partialTemporal TemporalAccessor, resolverStyle *ResolverStyle) ChronoLocalDate {


	var value int64 = NN(Long_Cast(fieldValues.Get_O__O(t))).LongValue__J(); var newValue int32 = Math_ToIntExact_J__I(value); var tmp1 TemporalUnit = t.F_rangeUnit; var tmp2 *ChronoUnit

	ChronoUnit_Init(); tmp2 = ChronoUnit_WEEKS; if any(tmp1) == any(tmp2.Ref()) {
		var checkedValue int32 = NN(t.F_range).CheckValidIntValue_J_TemporalField__I(value, t); var startDow int32 = NN(NN(t.F_weekDef).GetFirstDayOfWeek__DayOfWeek()).GetValue__I(); var isoDow int64 = int64(Math_FloorMod_I_I__I(startDow-1+(checkedValue-1), 7) + 1)








		fieldValues.Remove_O__O(t)
		var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_WEEK; fieldValues.Put_O_O__O(tmp3.Ref(), Long_ValueOf_J__Long(isoDow))
//line :296:1
		return nil








	} else {


		var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_DAY_OF_WEEK; if fieldValues.ContainsKey_O__Z(tmp4.Ref()) == false { return nil } else {
			var isoDow_2 int32; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_DAY_OF_WEEK; var tmp6 *ChronoField = tmp5; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_DAY_OF_WEEK; isoDow_2 = NN(tmp6).CheckValidIntValue_J__I(NN(Long_Cast(fieldValues.Get_O__O(tmp7.Ref()))).LongValue__J()); var dow int32 = t.LocalizedDayOfWeek_I__I(isoDow_2); var chrono Chronology = Chronology_From_TemporalAccessor__Chronology(partialTemporal); var tmp8 *ChronoField






			ChronoField_Init(); tmp8 = ChronoField_YEAR; if fieldValues.ContainsKey_O__Z(tmp8.Ref()) {

				var year int32; var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_YEAR; var tmp10 *ChronoField = tmp9; var tmp11 *ChronoField; ChronoField_Init(); tmp11 = ChronoField_YEAR; year = NN(tmp10).CheckValidIntValue_J__I(NN(Long_Cast(fieldValues.Get_O__O(tmp11.Ref()))).LongValue__J())


				var tmp12 bool; var tmp13 bool; var tmp14 TemporalUnit = t.F_rangeUnit; var tmp15 *ChronoUnit; ChronoUnit_Init(); tmp15 = ChronoUnit_MONTHS; tmp13 = any(tmp14) == any(tmp15.Ref()); if tmp13 {
					var tmp16 *ChronoField; ChronoField_Init(); tmp16 = ChronoField_MONTH_OF_YEAR; tmp13 = fieldValues.ContainsKey_O__Z(tmp16.Ref()) }
//line :321:1
				tmp12 = tmp13; if tmp12 {

					var month int64; var tmp17 *ChronoField; ChronoField_Init(); tmp17 = ChronoField_MONTH_OF_YEAR; month = NN(Long_Cast(fieldValues.Get_O__O(tmp17.Ref()))).LongValue__J()


					return t.ResolveWoM_Map_Chronology_I_J_J_I_ResolverStyle__ChronoLocalDate(fieldValues, chrono, year, month, int64(newValue), dow, resolverStyle)
				}






				var tmp18 TemporalUnit = t.F_rangeUnit; var tmp19 *ChronoUnit; ChronoUnit_Init(); tmp19 = ChronoUnit_YEARS; if any(tmp18) == any(tmp19.Ref()) {
					return t.ResolveWoY_Map_Chronology_I_J_I_ResolverStyle__ChronoLocalDate(fieldValues, chrono, year, int64(newValue), dow, resolverStyle) } } else {
//line :316:1
						var tmp20 bool; var tmp21 bool; var tmp22 bool; var tmp23 bool; var tmp24 TemporalUnit = t.F_rangeUnit; var tmp25 TemporalUnit

























						WeekFields_Init(); tmp25 = WeekFields_WEEK_BASED_YEARS; tmp23 = tmp24 == tmp25; if !tmp23 {
							var tmp26 TemporalUnit = t.F_rangeUnit; var tmp27 *ChronoUnit; ChronoUnit_Init(); tmp27 = ChronoUnit_FOREVER; tmp23 = any(tmp26) == any(tmp27.Ref()) }
//line :342:1
						tmp22 = tmp23; if tmp22 {

							tmp22 = fieldValues.ContainsKey_O__Z(t.F_weekDef.F_weekBasedYear) }
//line :342:1
						tmp21 = tmp22; if tmp21 {


							tmp21 = fieldValues.ContainsKey_O__Z(t.F_weekDef.F_weekOfWeekBasedYear) }
//line :342:1
						tmp20 = tmp21
//line :316:1
						if tmp20 {





























							return t.ResolveWBY_Map_Chronology_I_ResolverStyle__ChronoLocalDate(fieldValues, chrono, dow, resolverStyle) } }
//line :309:1
			return nil
		}
	}
}




































func (t *WeekFields_ComputedDayOfField) ResolveWoM_Map_Chronology_I_J_J_I_ResolverStyle__ChronoLocalDate(fieldValues Map, chrono Chronology, year int32, month, wom int64, localDow int32, resolverStyle *ResolverStyle) ChronoLocalDate {



	var date ChronoLocalDate; var tmp1 *ResolverStyle
	ResolverStyle_Init(); tmp1 = ResolverStyle_LENIENT; if resolverStyle == tmp1 {

		var tmp2 ChronoLocalDate = chrono.Date_I_I_I__ChronoLocalDate(year, 1, 1); var tmp3 int64 = Math_SubtractExact_J_J__J(month, 1); var tmp4 *ChronoUnit; ChronoUnit_Init(); tmp4 = ChronoUnit_MONTHS; date = tmp2.Plus_J_TemporalUnit__ChronoLocalDate(tmp3, Up_ChronoUnit_TemporalUnit(tmp4))

		var weeks int64 = Math_SubtractExact_J_J__J(wom, t.LocalizedWeekOfMonth_TemporalAccessor__J(date)); var days int32 = localDow - t.LocalizedDayOfWeek_TemporalAccessor__I(date); var tmp5 ChronoLocalDate = date; var tmp6 int64 = Math_AddExact_J_J__J(Math_MultiplyExact_J_I__J(weeks, 7), int64(days)); var tmp7 *ChronoUnit

		ChronoUnit_Init(); tmp7 = ChronoUnit_DAYS; date = tmp5.Plus_J_TemporalUnit__ChronoLocalDate(tmp6, Up_ChronoUnit_TemporalUnit(tmp7)) } else {



			var monthValid int32; var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_MONTH_OF_YEAR; monthValid = NN(tmp8).CheckValidIntValue_J__I(month)
			date = chrono.Date_I_I_I__ChronoLocalDate(year, monthValid, 1)
			var womInt int32 = NN(t.F_range).CheckValidIntValue_J_TemporalField__I(wom, t); var weeks_2 int32 = int32(int64(womInt) - t.LocalizedWeekOfMonth_TemporalAccessor__J(date)); var days_2 int32 = localDow - t.LocalizedDayOfWeek_TemporalAccessor__I(date); var tmp9 ChronoLocalDate = date; var tmp10 int64 = int64(weeks_2*7 + days_2); var tmp11 *ChronoUnit



			ChronoUnit_Init(); tmp11 = ChronoUnit_DAYS; date = tmp9.Plus_J_TemporalUnit__ChronoLocalDate(tmp10, Up_ChronoUnit_TemporalUnit(tmp11))



			var tmp12 bool; var tmp13 bool; var tmp14 *ResolverStyle; ResolverStyle_Init(); tmp14 = ResolverStyle_STRICT; tmp13 = resolverStyle == tmp14; if tmp13 {
				var tmp15 ChronoLocalDate = date; var tmp16 *ChronoField; ChronoField_Init(); tmp16 = ChronoField_MONTH_OF_YEAR; tmp13 = !(tmp15.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp16)) == month) }
//line :374:1
			tmp12 = tmp13; if tmp12 {

				panic(Thrown(DateTimeException_New_String(Lit_2183)))
			} }
	fieldValues.Remove_O__O(t)
	var tmp17 *ChronoField; ChronoField_Init(); tmp17 = ChronoField_YEAR; fieldValues.Remove_O__O(tmp17.Ref())
	var tmp18 *ChronoField; ChronoField_Init(); tmp18 = ChronoField_MONTH_OF_YEAR; fieldValues.Remove_O__O(tmp18.Ref())
	var tmp19 *ChronoField; ChronoField_Init(); tmp19 = ChronoField_DAY_OF_WEEK; fieldValues.Remove_O__O(tmp19.Ref())
//line :353:1
	return date
}





























func (t *WeekFields_ComputedDayOfField) ResolveWoY_Map_Chronology_I_J_I_ResolverStyle__ChronoLocalDate(fieldValues Map, chrono Chronology, year int32, woy int64, localDow int32, resolverStyle *ResolverStyle) ChronoLocalDate {


	var date ChronoLocalDate = chrono.Date_I_I_I__ChronoLocalDate(year, 1, 1); var tmp1 *ResolverStyle
	ResolverStyle_Init(); tmp1 = ResolverStyle_LENIENT; if resolverStyle == tmp1 {
		var weeks int64 = Math_SubtractExact_J_J__J(woy, t.LocalizedWeekOfYear_TemporalAccessor__J(date)); var days int32 = localDow - t.LocalizedDayOfWeek_TemporalAccessor__I(date); var tmp2 ChronoLocalDate = date; var tmp3 int64 = Math_AddExact_J_J__J(Math_MultiplyExact_J_I__J(weeks, 7), int64(days)); var tmp4 *ChronoUnit

		ChronoUnit_Init(); tmp4 = ChronoUnit_DAYS; date = tmp2.Plus_J_TemporalUnit__ChronoLocalDate(tmp3, Up_ChronoUnit_TemporalUnit(tmp4)) } else {



			var womInt int32 = NN(t.F_range).CheckValidIntValue_J_TemporalField__I(woy, t); var weeks_2 int32 = int32(int64(womInt) - t.LocalizedWeekOfYear_TemporalAccessor__J(date)); var days_2 int32 = localDow - t.LocalizedDayOfWeek_TemporalAccessor__I(date); var tmp5 ChronoLocalDate = date; var tmp6 int64 = int64(weeks_2*7 + days_2); var tmp7 *ChronoUnit


			ChronoUnit_Init(); tmp7 = ChronoUnit_DAYS; date = tmp5.Plus_J_TemporalUnit__ChronoLocalDate(tmp6, Up_ChronoUnit_TemporalUnit(tmp7))



			var tmp8 bool; var tmp9 bool; var tmp10 *ResolverStyle; ResolverStyle_Init(); tmp10 = ResolverStyle_STRICT; tmp9 = resolverStyle == tmp10; if tmp9 {
				var tmp11 ChronoLocalDate = date; var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_YEAR; tmp9 = !(tmp11.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp12)) == int64(year)) }
//line :402:1
			tmp8 = tmp9; if tmp8 {

				panic(Thrown(DateTimeException_New_String(Lit_2184)))
			} }
	fieldValues.Remove_O__O(t)
	var tmp13 *ChronoField; ChronoField_Init(); tmp13 = ChronoField_YEAR; fieldValues.Remove_O__O(tmp13.Ref())
	var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_DAY_OF_WEEK; fieldValues.Remove_O__O(tmp14.Ref())
//line :387:1
	return date
}






















func (t *WeekFields_ComputedDayOfField) ResolveWBY_Map_Chronology_I_ResolverStyle__ChronoLocalDate(fieldValues Map, chrono Chronology, localDow int32, resolverStyle *ResolverStyle) ChronoLocalDate {


	var yowby int32 = NN(t.F_weekDef.F_weekBasedYear.Range__ValueRange()).CheckValidIntValue_J_TemporalField__I(NN(Long_Cast(fieldValues.Get_O__O(t.F_weekDef.F_weekBasedYear))).LongValue__J(), t.F_weekDef.F_weekBasedYear); var date ChronoLocalDate; var tmp1 *ResolverStyle




	ResolverStyle_Init(); tmp1 = ResolverStyle_LENIENT; if resolverStyle == tmp1 {

		date = t.OfWeekBasedYear_Chronology_I_I_I__ChronoLocalDate(chrono, yowby, 1, localDow)
		var wowby int64 = NN(Long_Cast(fieldValues.Get_O__O(t.F_weekDef.F_weekOfWeekBasedYear))).LongValue__J(); var weeks int64 = Math_SubtractExact_J_J__J(wowby, 1); var tmp2 ChronoLocalDate = date; var tmp3 *ChronoUnit


		ChronoUnit_Init(); tmp3 = ChronoUnit_WEEKS; date = tmp2.Plus_J_TemporalUnit__ChronoLocalDate(weeks, Up_ChronoUnit_TemporalUnit(tmp3)) } else {
			var tmp4 TemporalField = t.F_weekDef.F_weekOfWeekBasedYear; var wowby_2 int32 = NN(tmp4.RangeRefinedBy_TemporalAccessor__ValueRange(Up_LocalDate_TemporalAccessor(LocalDate_Of_I_I_I__LocalDate(yowby, 7, 2)))).CheckValidIntValue_J_TemporalField__I(NN(Long_Cast(fieldValues.Get_O__O(t.F_weekDef.F_weekOfWeekBasedYear))).LongValue__J(), t.F_weekDef.F_weekOfWeekBasedYear)




			date = t.OfWeekBasedYear_Chronology_I_I_I__ChronoLocalDate(chrono, yowby, wowby_2, localDow)
			var tmp5 bool; var tmp6 bool; var tmp7 *ResolverStyle; ResolverStyle_Init(); tmp7 = ResolverStyle_STRICT; tmp6 = resolverStyle == tmp7; if tmp6 {
				tmp6 = !(t.LocalizedWeekBasedYear_TemporalAccessor__I(date) == yowby) }
//line :432:1
			tmp5 = tmp6; if tmp5 {

				panic(Thrown(DateTimeException_New_String(Lit_2541)))
			}
		}
	fieldValues.Remove_O__O(t)
	fieldValues.Remove_O__O(t.F_weekDef.F_weekBasedYear)
	fieldValues.Remove_O__O(t.F_weekDef.F_weekOfWeekBasedYear)
	var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_DAY_OF_WEEK; fieldValues.Remove_O__O(tmp8.Ref())
//line :414:1
	return date
}



























func (t *WeekFields_ComputedDayOfField) GetDisplayName_Locale__String(locale *Locale) *String {
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	var tmp1 TemporalUnit = t.F_rangeUnit; var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_YEARS; if any(tmp1) == any(tmp2.Ref()) {
		var lr *LocaleResources = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(CalendarDataUtility_FindRegionOverride_Locale__Locale(locale)); var rb ResourceBundle_I = NN(lr).GetJavaTimeFormatData__ResourceBundle()


		if rb.ContainsKey_String__Z(Lit_2499) { return rb.GetString_String__String(Lit_2499) } else { return t.F_name } } else {
//line :445:1
			return t.F_name
		}
}




func (t *WeekFields_ComputedDayOfField) GetBaseUnit__TemporalUnit() TemporalUnit { return t.F_baseUnit }

func (t *WeekFields_ComputedDayOfField) GetRangeUnit__TemporalUnit() TemporalUnit { return t.F_rangeUnit }

func (t *WeekFields_ComputedDayOfField) IsDateBased__Z() bool { return true }

func (t *WeekFields_ComputedDayOfField) IsTimeBased__Z() bool { return false }

func (t *WeekFields_ComputedDayOfField) Range__ValueRange() *ValueRange { return t.F_range }

func (t *WeekFields_ComputedDayOfField) IsSupportedBy_TemporalAccessor__Z(temporal TemporalAccessor) bool {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; if temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp1)) {
		var tmp2 TemporalUnit = t.F_rangeUnit; var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_WEEKS; if any(tmp2) == any(tmp3.Ref()) {
			return true } else {
//line :464:1
				var tmp4 TemporalUnit = t.F_rangeUnit; var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_MONTHS; if any(tmp4) == any(tmp5.Ref()) {


					var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_DAY_OF_MONTH; return temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp6)) } else {
//line :464:1
						var tmp7 TemporalUnit = t.F_rangeUnit; var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_YEARS; if any(tmp7) == any(tmp8.Ref()) {




							var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_DAY_OF_YEAR; return temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp9)) } else {
//line :464:1
								var tmp10 TemporalUnit = t.F_rangeUnit; var tmp11 TemporalUnit; WeekFields_Init(); tmp11 = WeekFields_WEEK_BASED_YEARS; if tmp10 == tmp11 {






									var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_DAY_OF_YEAR; return temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp12)) } else {
//line :464:1
										var tmp13 TemporalUnit = t.F_rangeUnit; var tmp14 *ChronoUnit; ChronoUnit_Init(); tmp14 = ChronoUnit_FOREVER; if any(tmp13) == any(tmp14.Ref()) {








											var tmp15 *ChronoField; ChronoField_Init(); tmp15 = ChronoField_YEAR; return temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp15)) } } } } } }
//line :462:1
	return false
}












func (t *WeekFields_ComputedDayOfField) RangeRefinedBy_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	var tmp1 TemporalUnit = t.F_rangeUnit; var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_WEEKS; if any(tmp1) == any(tmp2.Ref()) { return t.F_range } else { var tmp3 TemporalUnit = t.F_rangeUnit; var tmp4 *ChronoUnit; ChronoUnit_Init(); tmp4 = ChronoUnit_MONTHS; if any(tmp3) == any(tmp4.Ref()) {


		var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_DAY_OF_MONTH; return t.RangeByWeek_TemporalAccessor_TemporalField__ValueRange(temporal, Up_ChronoField_TemporalField(tmp5)) } else {
//line :477:1
			var tmp6 TemporalUnit = t.F_rangeUnit; var tmp7 *ChronoUnit; ChronoUnit_Init(); tmp7 = ChronoUnit_YEARS; if any(tmp6) == any(tmp7.Ref()) {



				var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_DAY_OF_YEAR; return t.RangeByWeek_TemporalAccessor_TemporalField__ValueRange(temporal, Up_ChronoField_TemporalField(tmp8)) } else {
//line :477:1
					var tmp9 TemporalUnit = t.F_rangeUnit; var tmp10 TemporalUnit; WeekFields_Init(); tmp10 = WeekFields_WEEK_BASED_YEARS; if tmp9 == tmp10 {




						return t.RangeWeekOfWeekBasedYear_TemporalAccessor__ValueRange(temporal) } else {
//line :477:1
							var tmp11 TemporalUnit = t.F_rangeUnit; var tmp12 *ChronoUnit; ChronoUnit_Init(); tmp12 = ChronoUnit_FOREVER; if any(tmp11) == any(tmp12.Ref()) {





								var tmp13 *ChronoField; ChronoField_Init(); tmp13 = ChronoField_YEAR; return NN(tmp13).Range__ValueRange() } else {

									panic(Thrown(IllegalStateException_New_String(Concat(Lit_2539, StrOfObj(t.F_rangeUnit), Lit_2540, StrOfObj(t)))))
								}
						} } } } }
func (t *WeekFields_ComputedDayOfField) RangeByWeek_TemporalAccessor_TemporalField__ValueRange(temporal TemporalAccessor, field TemporalField) *ValueRange {
	var dow int32 = t.LocalizedDayOfWeek_TemporalAccessor__I(temporal); var offset int32 = t.StartOfWeekOffset_I_I__I(temporal.Get_TemporalField__I(field), dow); var fieldRange *ValueRange = temporal.Range_TemporalField__ValueRange(field)


	return ValueRange_Of_J_J__ValueRange(int64(t.ComputeWeek_I_I__I(offset, int32(NN(fieldRange).GetMinimum__J()))), int64(t.ComputeWeek_I_I__I(offset, int32(NN(fieldRange).GetMaximum__J()))))
}

func (t *WeekFields_ComputedDayOfField) RangeWeekOfWeekBasedYear_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_YEAR; if !temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp1)) { return WeekFields_ComputedDayOfField_WEEK_OF_YEAR_RANGE } else {

		var dow int32 = t.LocalizedDayOfWeek_TemporalAccessor__I(temporal); var doy int32; var tmp2 *ChronoField
		ChronoField_Init(); tmp2 = ChronoField_DAY_OF_YEAR; doy = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2))
//line :498:1
		var offset int32 = t.StartOfWeekOffset_I_I__I(doy, dow); var week int32 = t.ComputeWeek_I_I__I(offset, doy)



		if week == 0 {
			var date ChronoLocalDate = Chronology_From_TemporalAccessor__Chronology(temporal).Date_TemporalAccessor__ChronoLocalDate(temporal); var tmp3 ChronoLocalDate = date; var tmp4 int64 = int64(doy + 7); var tmp5 *ChronoUnit
			ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; date = tmp3.Minus_J_TemporalUnit__ChronoLocalDate(tmp4, Up_ChronoUnit_TemporalUnit(tmp5))
			return t.RangeWeekOfWeekBasedYear_TemporalAccessor__ValueRange(date) } else {
				var dayRange *ValueRange; var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_DAY_OF_YEAR; dayRange = temporal.Range_TemporalField__ValueRange(Up_ChronoField_TemporalField(tmp6)); var yearLen int32 = int32(NN(dayRange).GetMaximum__J()); var newYearWeek int32 = t.ComputeWeek_I_I__I(offset, yearLen+NN(t.F_weekDef).GetMinimalDaysInFirstWeek__I())






				if week >= newYearWeek {
					var date_2 ChronoLocalDate = Chronology_From_TemporalAccessor__Chronology(temporal).Date_TemporalAccessor__ChronoLocalDate(temporal); var tmp7 ChronoLocalDate = date_2; var tmp8 int64 = int64(yearLen - doy + 1 + 7); var tmp9 *ChronoUnit
					ChronoUnit_Init(); tmp9 = ChronoUnit_DAYS; date_2 = tmp7.Plus_J_TemporalUnit__ChronoLocalDate(tmp8, Up_ChronoUnit_TemporalUnit(tmp9))





					return t.RangeWeekOfWeekBasedYear_TemporalAccessor__ValueRange(date_2) } else {
						return ValueRange_Of_J_J__ValueRange(1, int64(newYearWeek-1))
					} } } }
func (t *WeekFields_ComputedDayOfField) ToString__String() *String {
	var tmp1 *String = t.F_name; return Concat(tmp1, Lit_1318, NN(t.F_weekDef).ToString__String(), Lit_1189)
}


type WeekFields struct{ Object; F_firstDayOfWeek *DayOfWeek; F_minimalDays int32; F_dayOfWeek, F_weekOfMonth, F_weekOfYear, F_weekOfWeekBasedYear, F_weekBasedYear TemporalField }

func (t *WeekFields) Is_Serializable() {}

var WeekFields_CACHE ConcurrentMap

var WeekFields_ISO *WeekFields

var WeekFields_SUNDAY_START *WeekFields

var WeekFields_WEEK_BASED_YEARS TemporalUnit

const WeekFields_serialVersionUID int64 = -1177360819670808121

var WeekFields_init ClassInit

func WeekFields_Init() { if !WeekFields_init.Done() { WeekFields_init.Run(WeekFields_clinit) } }

func WeekFields_clinit() { WeekFields_CACHE = ConcurrentHashMap_New_I_F_I(4, 0.75, 2); var tmp1 *DayOfWeek; DayOfWeek_Init(); tmp1 = DayOfWeek_MONDAY; WeekFields_ISO = WeekFields_Of_DayOfWeek_I__WeekFields(tmp1, 4); var tmp2 *DayOfWeek; DayOfWeek_Init(); tmp2 = DayOfWeek_SUNDAY; WeekFields_SUNDAY_START = WeekFields_Of_DayOfWeek_I__WeekFields(tmp2, 1); var tmp3 TemporalUnit; IsoFields_Init(); tmp3 = IsoFields_WEEK_BASED_YEARS; WeekFields_WEEK_BASED_YEARS = tmp3 }

func (t *WeekFields) Ref() any { if t == nil { return nil }; return t }

func (t *WeekFields) GetClass__Class() *Class { return WeekFields_class }

func (t *WeekFields) Clone__O() any { return A2g_ObjectClone(t) }

func (t *WeekFields) CloneShallow() any { panic(CloneNotSupported(t)) }

func WeekFields_InstanceOf(x any) bool { _, ok := x.(*WeekFields); return ok }

func WeekFields_Cast(x any) *WeekFields { if x == nil { return nil }; v, ok := x.(*WeekFields); if !ok { panic(ClassCast(x, WeekFields_class)) }; return v }



type WeekFields_ComputedDayOfField struct{ Object; F_name *String; F_weekDef *WeekFields; F_baseUnit, F_rangeUnit TemporalUnit; F_range *ValueRange }

func (t *WeekFields_ComputedDayOfField) Is_TemporalField() {}

var WeekFields_ComputedDayOfField_DAY_OF_WEEK_RANGE *ValueRange

var WeekFields_ComputedDayOfField_WEEK_OF_MONTH_RANGE *ValueRange

var WeekFields_ComputedDayOfField_WEEK_OF_YEAR_RANGE *ValueRange

var WeekFields_ComputedDayOfField_WEEK_OF_WEEK_BASED_YEAR_RANGE *ValueRange

var WeekFields_ComputedDayOfField_init ClassInit

func WeekFields_ComputedDayOfField_Init() { if !WeekFields_ComputedDayOfField_init.Done() { WeekFields_ComputedDayOfField_init.Run(WeekFields_ComputedDayOfField_clinit) } }

func WeekFields_ComputedDayOfField_clinit() { WeekFields_ComputedDayOfField_DAY_OF_WEEK_RANGE = ValueRange_Of_J_J__ValueRange(1, 7); WeekFields_ComputedDayOfField_WEEK_OF_MONTH_RANGE = ValueRange_Of_J_J_J_J__ValueRange(0, 1, 4, 6); WeekFields_ComputedDayOfField_WEEK_OF_YEAR_RANGE = ValueRange_Of_J_J_J_J__ValueRange(0, 1, 52, 54); WeekFields_ComputedDayOfField_WEEK_OF_WEEK_BASED_YEAR_RANGE = ValueRange_Of_J_J_J__ValueRange(1, 52, 53) }

func (t *WeekFields_ComputedDayOfField) Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor { return t.Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(p0, p1, p2) }

func (t *WeekFields_ComputedDayOfField) Ref() any { if t == nil { return nil }; return t }

func (t *WeekFields_ComputedDayOfField) GetClass__Class() *Class { return WeekFields_ComputedDayOfField_class }

func (t *WeekFields_ComputedDayOfField) Clone__O() any { return A2g_ObjectClone(t) }

func (t *WeekFields_ComputedDayOfField) CloneShallow() any { panic(CloneNotSupported(t)) }

func WeekFields_ComputedDayOfField_InstanceOf(x any) bool { _, ok := x.(*WeekFields_ComputedDayOfField); return ok }

func WeekFields_ComputedDayOfField_Cast(x any) *WeekFields_ComputedDayOfField { if x == nil { return nil }; v, ok := x.(*WeekFields_ComputedDayOfField); if !ok { panic(ClassCast(x, WeekFields_ComputedDayOfField_class)) }; return v }
