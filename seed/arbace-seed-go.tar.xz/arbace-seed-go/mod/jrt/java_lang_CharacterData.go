//line java_lang_CharacterData.ae:1
package jrt





























































func (t *CharacterData) Impl_ToUpperCaseEx_I__I(this CharacterData_I, p0 int32) int32 { panic(A2g_NotTranslated("java.lang.CharacterData.toUpperCaseEx(I)I")) }

func (t *CharacterData) Impl_ToUpperCaseCharArray_I__C1(this CharacterData_I, p0 int32) *CharArray { panic(A2g_NotTranslated("java.lang.CharacterData.toUpperCaseCharArray(I)[C")) }

func (t *CharacterData) Impl_IsOtherAlphabetic_I__Z(this CharacterData_I, ch int32) bool { return false }

func (t *CharacterData) Impl_IsIdeographic_I__Z(this CharacterData_I, ch int32) bool { return false }

func CharacterData_Of_I__CharacterData(ch int32) CharacterData_I {
	if int32(uint32(ch)>>8) == 0 { CharacterDataLatin1_Init(); return Up_CharacterDataLatin1_CharacterData(CharacterDataLatin1_instance) } else {

		switch int32(uint32(ch) >> 16) { case 0: CharacterData00_Init(); return Up_CharacterData00_CharacterData(CharacterData00_instance); case 1: CharacterData01_Init(); return CharacterData01_instance; case 2: CharacterData02_Init(); return CharacterData02_instance; case 3: CharacterData03_Init(); return CharacterData03_instance; case 14: CharacterData0E_Init(); return CharacterData0E_instance; case 15, 16: CharacterDataPrivateUse_Init(); return CharacterDataPrivateUse_instance; default: CharacterDataUndefined_Init(); return CharacterDataUndefined_instance} }; panic("a2g: unreachable")
}


type CharacterData struct{ Object }

type CharacterData_I interface{ Object_I; Self_CharacterData() *CharacterData; GetProperties_I__I(p0 int32) int32; GetType_I__I(p0 int32) int32; IsDigit_I__Z(p0 int32) bool; IsLowerCase_I__Z(p0 int32) bool; IsUpperCase_I__Z(p0 int32) bool; IsWhitespace_I__Z(p0 int32) bool; IsMirrored_I__Z(p0 int32) bool; IsJavaIdentifierStart_I__Z(p0 int32) bool; IsJavaIdentifierPart_I__Z(p0 int32) bool; IsUnicodeIdentifierStart_I__Z(p0 int32) bool; IsUnicodeIdentifierPart_I__Z(p0 int32) bool; IsIdentifierIgnorable_I__Z(p0 int32) bool; IsEmoji_I__Z(p0 int32) bool; IsEmojiPresentation_I__Z(p0 int32) bool; IsEmojiModifier_I__Z(p0 int32) bool; IsEmojiModifierBase_I__Z(p0 int32) bool; IsEmojiComponent_I__Z(p0 int32) bool; IsExtendedPictographic_I__Z(p0 int32) bool; ToLowerCase_I__I(p0 int32) int32; ToUpperCase_I__I(p0 int32) int32; ToTitleCase_I__I(p0 int32) int32; Digit_I_I__I(p0, p1 int32) int32; GetNumericValue_I__I(p0 int32) int32; GetDirectionality_I__B(p0 int32) int8; ToUpperCaseEx_I__I(p0 int32) int32; ToUpperCaseCharArray_I__C1(p0 int32) *CharArray; IsOtherAlphabetic_I__Z(p0 int32) bool; IsIdeographic_I__Z(p0 int32) bool }

func (t *CharacterData) Self_CharacterData() *CharacterData { return t }

func (t *CharacterData) Ctor(this CharacterData_I) {}

func CharacterData_InstanceOf(x any) bool { _, ok := x.(CharacterData_I); return ok }

func CharacterData_Cast(x any) CharacterData_I { if x == nil { return nil }; v, ok := x.(CharacterData_I); if !ok { panic(ClassCast(x, CharacterData_class)) }; return v }
