//line java_io_PrintWriter.ae:1
package jrt



















func PrintWriter_ToCharset_String__Charset(csn *String) Charset_I {
	Objects_RequireNonNull_O_String__O(csn.Ref(), Lit_85)
	var tmp1 Charset_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = Charset_ForName_String__Charset(csn); return nil }()
//line :23:1
	if tmp2 != nil { if IllegalCharsetNameException_InstanceOf(tmp2) || UnsupportedCharsetException_InstanceOf(tmp2) { var unused IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = unused


		panic(Thrown(UnsupportedEncodingException_New_String(csn))) } else {
//line :23:1
			panic(tmp2) } }; return tmp1
}



func PrintWriter_New_Writer(p0 Writer_I) *PrintWriter { t := &PrintWriter{}; t.Ctor_Writer(p0); return t }
//line :28:1
func (t *PrintWriter) Ctor_Writer(out Writer_I) { t.Ctor_Writer_Z(out, false) }

func PrintWriter_New_Writer_Z(p0 Writer_I, p1 bool) *PrintWriter { t := &PrintWriter{}; t.Ctor_Writer_Z(p0, p1); return t }
//line :30:1
func (t *PrintWriter) Ctor_Writer_Z(out Writer_I, autoFlush bool) { t.Writer.Ctor_O(t, out); t.F_trouble = false; t.F_psOut = nil

	t.F_out = out
	t.F_autoFlush = autoFlush
}
func PrintWriter_New_OutputStream(p0 OutputStream_I) *PrintWriter { t := &PrintWriter{}; t.Ctor_OutputStream(p0); return t }
//line :35:1
func (t *PrintWriter) Ctor_OutputStream(out OutputStream_I) { t.Ctor_OutputStream_Z(out, false) }

func PrintWriter_New_OutputStream_Z(p0 OutputStream_I, p1 bool) *PrintWriter { t := &PrintWriter{}; t.Ctor_OutputStream_Z(p0, p1); return t }
//line :37:1
func (t *PrintWriter) Ctor_OutputStream_Z(out OutputStream_I, autoFlush bool) { var tmp1 Charset_I; var tmp2 OutputStream_I = out; if


	PrintStream_InstanceOf(tmp2) { var ps *PrintStream = PrintStream_Cast(tmp2); tmp1 = NN(ps).Charset__Charset() } else { tmp1 = Charset_DefaultCharset__Charset() }; /*line :37:1*/t.Ctor_OutputStream_Z_Charset(out, autoFlush, tmp1) }




func PrintWriter_New_OutputStream_Z_Charset(p0 OutputStream_I, p1 bool, p2 Charset_I) *PrintWriter { t := &PrintWriter{}; t.Ctor_OutputStream_Z_Charset(p0, p1, p2); return t }
//line :42:1
func (t *PrintWriter) Ctor_OutputStream_Z_Charset(out OutputStream_I, autoFlush bool, charset Charset_I) { t.Ctor_Writer_Z(BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_Charset(out, charset)), autoFlush)

	if PrintStream_InstanceOf(out) { t.F_psOut = PrintStream_Cast(out)
	} }
func PrintWriter_New_String(p0 *String) *PrintWriter { t := &PrintWriter{}; t.Ctor_String(p0); return t }
//line :46:1
func (t *PrintWriter) Ctor_String(fileName *String) { t.Ctor_Writer_Z(BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream(FileOutputStream_New_String(fileName))), false) }


func PrintWriter_New_Writer_O(p0 Writer_I, p1 any) *PrintWriter { t := &PrintWriter{}; t.Ctor_Writer_O(p0, p1); return t }
//line :49:1
func (t *PrintWriter) Ctor_Writer_O(out Writer_I, lock any) { panic(A2g_NotTranslated("java.io.PrintWriter.<init>(Ljava/io/Writer;Ljava/lang/Object;)V")) }




func PrintWriter_New_Charset_File(p0 Charset_I, p1 *File) *PrintWriter { t := &PrintWriter{}; t.Ctor_Charset_File(p0, p1); return t }
//line :54:1
func (t *PrintWriter) Ctor_Charset_File(charset Charset_I, file *File) { t.Ctor_Writer_Z(BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_Charset(FileOutputStream_New_File(file), charset)), false) }


func PrintWriter_New_String_String(p0, p1 *String) *PrintWriter { t := &PrintWriter{}; t.Ctor_String_String(p0, p1); return t }
//line :57:1
func (t *PrintWriter) Ctor_String_String(fileName, csn *String) { t.Ctor_Charset_File(PrintWriter_ToCharset_String__Charset(csn), File_New_String(fileName)) }




func PrintWriter_New_String_Charset(p0 *String, p1 Charset_I) *PrintWriter { t := &PrintWriter{}; t.Ctor_String_Charset(p0, p1); return t }
//line :62:1
func (t *PrintWriter) Ctor_String_Charset(fileName *String, charset Charset_I) { t.Ctor_Charset_File(Charset_Cast(Objects_RequireNonNull_O_String__O(charset, Lit_86)), File_New_String(fileName)) }


func PrintWriter_New_File(p0 *File) *PrintWriter { t := &PrintWriter{}; t.Ctor_File(p0); return t }
//line :65:1
func (t *PrintWriter) Ctor_File(file *File) { t.Ctor_Writer_Z(BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream(FileOutputStream_New_File(file))), false) }


func PrintWriter_New_File_String(p0 *File, p1 *String) *PrintWriter { t := &PrintWriter{}; t.Ctor_File_String(p0, p1); return t }
//line :68:1
func (t *PrintWriter) Ctor_File_String(file *File, csn *String) { t.Ctor_Charset_File(PrintWriter_ToCharset_String__Charset(csn), file) }




func PrintWriter_New_File_Charset(p0 *File, p1 Charset_I) *PrintWriter { t := &PrintWriter{}; t.Ctor_File_Charset(p0, p1); return t }
//line :73:1
func (t *PrintWriter) Ctor_File_Charset(file *File, charset Charset_I) { t.Ctor_Charset_File(Charset_Cast(Objects_RequireNonNull_O_String__O(charset, Lit_86)), file) }


func (t *PrintWriter) EnsureOpen__V() {
	if t.F_out == nil { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *PrintWriter) Flush__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		t.EnsureOpen__V(); t.F_out.Flush__V(); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; t.F_trouble = true } else { panic(tmp2) } } }()
}
func (t *PrintWriter) Close__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		if !(t.F_out == nil) { t.F_out.Close__V(); t.F_out = nil }; return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; t.F_trouble = true } else { panic(tmp2) } } }()
}
func (t *PrintWriter) CheckError__Z() bool {
	if !(t.F_out == nil) { t.Flush__V() }
	var tmp1 Writer_I = t.F_out; if PrintWriter_InstanceOf(tmp1) { var pw *PrintWriter = PrintWriter_Cast(tmp1)
		return NN(pw).CheckError__Z() } else {
			if !(t.F_psOut == nil) { return NN(t.F_psOut).CheckError__Z() } else { return t.F_trouble
			} } }
func (t *PrintWriter) SetError__V() { panic(A2g_NotTranslated("java.io.PrintWriter.setError()V")) }

func (t *PrintWriter) ClearError__V() { panic(A2g_NotTranslated("java.io.PrintWriter.clearError()V")) }

func (t *PrintWriter) Write_I__V(c int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		t.EnsureOpen__V(); t.F_out.Write_I__V(c); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; t.F_trouble = true } else { panic(tmp2) } } }()
}
func (t *PrintWriter) Write_C1_I_I__V(buf *CharArray, off, len_ int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		t.EnsureOpen__V(); t.F_out.Write_C1_I_I__V(buf, off, len_); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; t.F_trouble = true } else { panic(tmp2) } } }()
}
func (t *PrintWriter) Write_C1__V(buf *CharArray) {
	t.Write_C1_I_I__V(buf, 0, int32(len(buf.A)))
}
func (t *PrintWriter) Write_String_I_I__V(s *String, off, len_ int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		t.EnsureOpen__V(); t.F_out.Write_String_I_I__V(s, off, len_); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; t.F_trouble = true } else { panic(tmp2) } } }()
}
func (t *PrintWriter) Write_String__V(s *String) {
	t.Write_String_I_I__V(s, 0, NN(s).Length__I())
}
func (t *PrintWriter) NewLine__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

		t.EnsureOpen__V()
		{ var tmp2 Writer_I = t.F_out; tmp2.Write_String__V(System_LineSeparator__String())
			if t.F_autoFlush { t.F_out.Flush__V() } }; return nil }(); if /*line :117:1*/ tmp3 != nil { if IOException_InstanceOf(tmp3) { var x IOException_I = IOException_Cast(tmp3); _ = x



				t.F_trouble = true } else {
//line :117:1
					panic(tmp3) } } }()
}




func (t *PrintWriter) Print_Z__V(b bool) {
	t.Write_String__V(String_ValueOf_Z__String(b))
}
func (t *PrintWriter) Print_C__V(c uint16) { t.Write_I__V(int32(c)) }

func (t *PrintWriter) Print_I__V(i int32) {
	t.Write_String__V(String_ValueOf_I__String(i))
}
func (t *PrintWriter) Print_J__V(l int64) {
	t.Write_String__V(String_ValueOf_J__String(l))
}
func (t *PrintWriter) Print_F__V(f float32) {
	t.Write_String__V(String_ValueOf_F__String(f))
}
func (t *PrintWriter) Print_D__V(d float64) {
	t.Write_String__V(String_ValueOf_D__String(d))
}
func (t *PrintWriter) Print_C1__V(s *CharArray) { t.Write_C1__V(s) }

func (t *PrintWriter) Print_String__V(s *String) {
	t.Write_String__V(String_ValueOf_O__String(s.Ref()))
}
func (t *PrintWriter) Print_O__V(obj any) {
	t.Write_String__V(String_ValueOf_O__String(obj))
}
func (t *PrintWriter) Println__V() { t.NewLine__V() }

func (t *PrintWriter) Println_Z__V(x bool) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_Z__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_C__V(x uint16) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_C__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_I__V(x int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_I__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_J__V(x int64) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_J__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_F__V(x float32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_F__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_D__V(x float64) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_D__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_C1__V(x *CharArray) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_C1__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_String__V(x *String) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_String__V(x); t.Println__V() }()
}
func (t *PrintWriter) Println_O__V(x any) {
	var s *String = String_ValueOf_O__String(x); var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_String__V(s); t.Println__V() }()
}
func (t *PrintWriter) Printf_String_O1__PrintWriter(format *String, args *RefArray) *PrintWriter {
	return t.Format_String_O1__PrintWriter(format, args)
}
func (t *PrintWriter) Printf_Locale_String_O1__PrintWriter(l *Locale, format *String, args *RefArray) *PrintWriter {
	return t.Format_Locale_String_O1__PrintWriter(l, format, args)
}
func (t *PrintWriter) Format_String_O1__PrintWriter(format *String, args *RefArray) *PrintWriter {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp5 := func() (exc Throwable_I) { defer Catch(&exc)

		t.EnsureOpen__V()
		{ var tmp2 bool; var tmp3 bool; tmp3 = t.F_formatter == nil; if !tmp3 { tmp3 = !(NN(t.F_formatter).Locale__Locale() == Locale_GetDefault__Locale()) }; tmp2 = tmp3; if tmp2 {
			t.F_formatter = Formatter_New_Appendable(t) }
			var tmp4 *Formatter = t.F_formatter; NN(tmp4).Format_Locale_String_O1__Formatter(Locale_GetDefault__Locale(), format, args)
			if t.F_autoFlush { t.F_out.Flush__V() } }; return nil }(); if /*line :185:1*/ tmp5 != nil { if IOException_InstanceOf(tmp5) { var x IOException_I = IOException_Cast(tmp5); _ = x





				t.F_trouble = true } else {
//line :185:1
					panic(tmp5) } } }()
//line :183:1
	return t
}









func (t *PrintWriter) Format_Locale_String_O1__PrintWriter(l *Locale, format *String, args *RefArray) *PrintWriter {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

		t.EnsureOpen__V()
		{ var tmp2 bool; var tmp3 bool; tmp3 = t.F_formatter == nil; if !tmp3 { tmp3 = !(NN(t.F_formatter).Locale__Locale() == l) }; tmp2 = tmp3; if tmp2 {
			t.F_formatter = Formatter_New_Appendable_Locale(t, l) }
			NN(t.F_formatter).Format_Locale_String_O1__Formatter(l, format, args)
			if t.F_autoFlush { t.F_out.Flush__V() } }; return nil }(); if /*line :196:1*/ tmp4 != nil { if IOException_InstanceOf(tmp4) { var x IOException_I = IOException_Cast(tmp4); _ = x





				t.F_trouble = true } else {
//line :196:1
					panic(tmp4) } } }()
//line :194:1
	return t
}









func (t *PrintWriter) Append_CharSequence__PrintWriter(csq CharSequence) *PrintWriter {
	t.Write_String__V(String_ValueOf_O__String(csq))
//line :205:1
	return t
}


func (t *PrintWriter) Append_CharSequence_I_I__PrintWriter(csq CharSequence, start, end int32) *PrintWriter {
	if csq == nil { csq = Lit_95 }
	return t.Append_CharSequence__PrintWriter(csq.SubSequence_I_I__CharSequence(start, end))
}
func (t *PrintWriter) Append_C__PrintWriter(c uint16) *PrintWriter {
	t.Write_I__V(int32(c))
//line :213:1
	return t
}



type PrintWriter struct{ Writer; F_out Writer_I; F_autoFlush, F_trouble bool; F_formatter *Formatter; F_psOut *PrintStream }

func (t *PrintWriter) Append_CharSequence__Writer(p0 CharSequence) Writer_I { return Up_PrintWriter_Writer(t.Append_CharSequence__PrintWriter(p0)) }

func (t *PrintWriter) Append_CharSequence_I_I__Writer(p0 CharSequence, p1, p2 int32) Writer_I { return Up_PrintWriter_Writer(t.Append_CharSequence_I_I__PrintWriter(p0, p1, p2)) }

func (t *PrintWriter) Append_C__Writer(p0 uint16) Writer_I { return Up_PrintWriter_Writer(t.Append_C__PrintWriter(p0)) }

func (t *PrintWriter) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return Up_PrintWriter_Appendable(t.Append_CharSequence__PrintWriter(p0)) }

func (t *PrintWriter) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return Up_PrintWriter_Appendable(t.Append_CharSequence_I_I__PrintWriter(p0, p1, p2)) }

func (t *PrintWriter) Append_C__Appendable(p0 uint16) Appendable { return Up_PrintWriter_Appendable(t.Append_C__PrintWriter(p0)) }

func (t *PrintWriter) Ref() any { if t == nil { return nil }; return t }

func (t *PrintWriter) GetClass__Class() *Class { return PrintWriter_class }

func (t *PrintWriter) ToString__String() *String { return Object_toString(t) }

func (t *PrintWriter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PrintWriter) CloneShallow() any { panic(CloneNotSupported(t)) }

func PrintWriter_InstanceOf(x any) bool { _, ok := x.(*PrintWriter); return ok }

func PrintWriter_Cast(x any) *PrintWriter { if x == nil { return nil }; v, ok := x.(*PrintWriter); if !ok { panic(ClassCast(x, PrintWriter_class)) }; return v }
