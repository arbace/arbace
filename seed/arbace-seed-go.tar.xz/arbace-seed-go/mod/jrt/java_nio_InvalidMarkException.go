//line java_nio_InvalidMarkException.ae:1
package jrt








func InvalidMarkException_New() *InvalidMarkException { t := &InvalidMarkException{}; t.Ctor(); return t }
//line :10:1
func (t *InvalidMarkException) Ctor() { t.IllegalStateException.Ctor(t) }





type InvalidMarkException struct{ IllegalStateException }

const InvalidMarkException_serialVersionUID int64 = 1698329710438510774

func (t *InvalidMarkException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvalidMarkException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvalidMarkException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InvalidMarkException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvalidMarkException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvalidMarkException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InvalidMarkException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvalidMarkException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvalidMarkException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvalidMarkException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvalidMarkException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvalidMarkException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvalidMarkException) Ref() any { if t == nil { return nil }; return t }

func (t *InvalidMarkException) GetClass__Class() *Class { return InvalidMarkException_class }

func (t *InvalidMarkException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvalidMarkException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvalidMarkException_InstanceOf(x any) bool { _, ok := x.(*InvalidMarkException); return ok }

func InvalidMarkException_Cast(x any) *InvalidMarkException { if x == nil { return nil }; v, ok := x.(*InvalidMarkException); if !ok { panic(ClassCast(x, InvalidMarkException_class)) }; return v }
