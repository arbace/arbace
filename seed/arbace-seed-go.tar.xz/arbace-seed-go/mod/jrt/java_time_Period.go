//line java_time_Period.ae:1
package jrt











































func Period_OfYears_I__Period(years int32) *Period { Period_Init()
	return Period_Create_I_I_I__Period(years, 0, 0)
}
func Period_OfMonths_I__Period(months int32) *Period { Period_Init()
	return Period_Create_I_I_I__Period(0, months, 0)
}
func Period_OfWeeks_I__Period(weeks int32) *Period { Period_Init()
	return Period_Create_I_I_I__Period(0, 0, Math_MultiplyExact_I_I__I(weeks, 7))
}
func Period_OfDays_I__Period(days int32) *Period { Period_Init()
	return Period_Create_I_I_I__Period(0, 0, days)
}
func Period_Of_I_I_I__Period(years, months, days int32) *Period { Period_Init()
	return Period_Create_I_I_I__Period(years, months, days)
}
func Period_From_TemporalAmount__Period(amount TemporalAmount) *Period { Period_Init()
	if Period_InstanceOf(amount) {
		return Period_Cast(amount) } else {

			if ChronoPeriod_InstanceOf(amount) {
				var tmp1 *IsoChronology; IsoChronology_Init(); tmp1 = IsoChronology_INSTANCE; var tmp2 *IsoChronology = tmp1; if NN(tmp2).Equals_O__Z(ChronoPeriod_Cast(amount).GetChronology__Chronology()) == false {

					panic(Thrown(DateTimeException_New_String(Concat(Lit_2081, StrOfObj(amount))))) } }
			Objects_RequireNonNull_O_String__O(amount, Lit_2010)
			var years int32 = 0; var months int32 = 0; var days int32 = 0; var i_101498 Iterator = amount.GetUnits__List().Iterator__Iterator(); for i_101498.HasNext__Z() {


				var unit TemporalUnit = TemporalUnit_Cast(i_101498.Next__O()); var unitAmount int64 = amount.Get_TemporalUnit__J(unit); var tmp3 *ChronoUnit

				ChronoUnit_Init(); tmp3 = ChronoUnit_YEARS; if any(unit) == any(tmp3.Ref()) {
					years = Math_ToIntExact_J__I(unitAmount) } else {
//line :74:1
						var tmp4 *ChronoUnit; ChronoUnit_Init(); tmp4 = ChronoUnit_MONTHS; if any(unit) == any(tmp4.Ref()) {

							months = Math_ToIntExact_J__I(unitAmount) } else {
//line :74:1
								var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; if any(unit) == any(tmp5.Ref()) {


									days = Math_ToIntExact_J__I(unitAmount) } else {

										panic(Thrown(DateTimeException_New_String(Concat(Lit_2082, StrOfObj(unit)))))
									} } } }
			return Period_Create_I_I_I__Period(years, months, days)
		} }
func Period_Parse_CharSequence__Period(text CharSequence) *Period { Period_Init()
	Objects_RequireNonNull_O_String__O(text, Lit_2011)
	var matcher *Matcher = NN(Period_PATTERN).Matcher_CharSequence__Matcher(text)
	if NN(matcher).Matches__Z() {
		var negate int32; if Period_CharMatch_CharSequence_I_I_C__Z(text, NN(matcher).Start_I__I(1), NN(matcher).End_I__I(1), 45) { negate = -1 } else { negate = 1 }; var yearStart int32 = NN(matcher).Start_I__I(2); var yearEnd int32 = NN(matcher).End_I__I(2); var monthStart int32 = NN(matcher).Start_I__I(3); var monthEnd int32 = NN(matcher).End_I__I(3); var weekStart int32 = NN(matcher).Start_I__I(4); var weekEnd int32 = NN(matcher).End_I__I(4); var dayStart int32 = NN(matcher).Start_I__I(5); var dayEnd int32 = NN(matcher).End_I__I(5); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool








		tmp4 = yearStart >= 0; if !tmp4 { tmp4 = monthStart >= 0 }; tmp3 = tmp4; if !tmp3 { tmp3 = weekStart >= 0 }; tmp2 = tmp3; if !tmp2 { tmp2 = dayStart >= 0 }; tmp1 = tmp2; if tmp1 { tmp5, tmp6, tmp7 := func() (ctl int32, rv *Period, exc Throwable_I) { defer Catch(&exc)

			{ var years int32 = Period_ParseNumber_CharSequence_I_I_I__I(text, yearStart, yearEnd, negate); var months int32 = Period_ParseNumber_CharSequence_I_I_I__I(text, monthStart, monthEnd, negate); var weeks int32 = Period_ParseNumber_CharSequence_I_I_I__I(text, weekStart, weekEnd, negate); var days int32 = Period_ParseNumber_CharSequence_I_I_I__I(text, dayStart, dayEnd, negate)



				days = Math_AddExact_I_I__I(days, Math_MultiplyExact_I_I__I(weeks, 7)); return 2, Period_Create_I_I_I__Period(years, months, days), nil }; return 0, nil, nil }()
//line :97:1
			if tmp7 != nil { if NumberFormatException_InstanceOf(tmp7) { var ex *NumberFormatException = NumberFormatException_Cast(tmp7)







				panic(Thrown(DateTimeParseException_New_String_CharSequence_I_Throwable(Lit_2083, text, 0, Up_NumberFormatException_Throwable(ex)))) } else {
//line :97:1
					panic(tmp7) } }; switch tmp5 { case 2: { return tmp6
					}
					}
		}
	}




	panic(Thrown(DateTimeParseException_New_String_CharSequence_I(Lit_2083, text, 0)))
}
func Period_CharMatch_CharSequence_I_I_C__Z(text CharSequence, start, end int32, c uint16) bool { Period_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = start >= 0; if tmp2 { tmp2 = end == start+1 }; tmp1 = tmp2; if tmp1 { tmp1 = int32(text.CharAt_I__C(start)) == int32(c) }; return tmp1
}
func Period_ParseNumber_CharSequence_I_I_I__I(text CharSequence, start, end, negate int32) int32 { Period_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = start < 0; if !tmp2 { tmp2 = end < 0 }; tmp1 = tmp2; if tmp1 { return 0 } else {

		var val int32 = Integer_ParseInt_CharSequence_I_I_I__I(text, start, end, 10); var tmp3 int32; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

			tmp3 = Math_MultiplyExact_I_I__I(val, negate); return nil }()
//line :115:1
		if tmp4 != nil { if ArithmeticException_InstanceOf(tmp4) { var ex *ArithmeticException = ArithmeticException_Cast(tmp4)


			panic(Thrown(DateTimeParseException_New_String_CharSequence_I_Throwable(Lit_2083, text, 0, Up_ArithmeticException_Throwable(ex)))) } else {
//line :115:1
				panic(tmp4) } }; return tmp3
	}
}


func Period_Between_LocalDate_LocalDate__Period(startDateInclusive, endDateExclusive *LocalDate) *Period { Period_Init()

	return NN(startDateInclusive).Until_ChronoLocalDate__Period(Up_LocalDate_ChronoLocalDate(endDateExclusive))
}
func Period_Create_I_I_I__Period(years, months, days int32) *Period { Period_Init()
	if years|months|days == 0 { return Period_ZERO } else { return Period_New_I_I_I(years, months, days)
	} }
func Period_New_I_I_I(p0, p1, p2 int32) *Period { Period_Init(); t := &Period{}; t.Ctor_I_I_I(p0, p1, p2); return t }
//line :127:1
func (t *Period) Ctor_I_I_I(years, months, days int32) {
	t.F_years = years
	t.F_months = months
	t.F_days = days
}
func (t *Period) Get_TemporalUnit__J(unit TemporalUnit) int64 {
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_YEARS; if any(unit) == any(tmp1.Ref()) { return int64(t.GetYears__I()) } else { var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_MONTHS; if any(unit) == any(tmp2.Ref()) { return int64(t.GetMonths__I()) } else { var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_DAYS; if any(unit) == any(tmp3.Ref()) { return int64(t.GetDays__I()) } else {



		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))
	} } } }
func (t *Period) GetUnits__List() List { return Period_SUPPORTED_UNITS }


func (t *Period) GetChronology__IsoChronology() *IsoChronology { IsoChronology_Init(); return IsoChronology_INSTANCE }


func (t *Period) IsZero__Z() bool { return t == Period_ZERO }

func (t *Period) IsNegative__Z() bool {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_years < 0; if !tmp2 { tmp2 = t.F_months < 0 }; tmp1 = tmp2; if !tmp1 { tmp1 = t.F_days < 0 }; return tmp1
}
func (t *Period) GetYears__I() int32 { return t.F_years }

func (t *Period) GetMonths__I() int32 { return t.F_months }

func (t *Period) GetDays__I() int32 { return t.F_days }

func (t *Period) WithYears_I__Period(years int32) *Period {
	if years == t.F_years { return t } else { return Period_Create_I_I_I__Period(years, t.F_months, t.F_days)
	} }
func (t *Period) WithMonths_I__Period(months int32) *Period {
	if months == t.F_months { return t } else { return Period_Create_I_I_I__Period(t.F_years, months, t.F_days)
	} }
func (t *Period) WithDays_I__Period(days int32) *Period {
	if days == t.F_days { return t } else { return Period_Create_I_I_I__Period(t.F_years, t.F_months, days)
	} }
func (t *Period) Plus_TemporalAmount__Period(amountToAdd TemporalAmount) *Period {
	var isoAmount *Period = Period_From_TemporalAmount__Period(amountToAdd); var tmp1 int32 = t.F_years; var tmp2 int32 = t.F_months; var tmp3 int32 = t.F_days
	return Period_Create_I_I_I__Period(Math_AddExact_I_I__I(tmp1, isoAmount.F_years), Math_AddExact_I_I__I(tmp2, isoAmount.F_months), Math_AddExact_I_I__I(tmp3, isoAmount.F_days))
}


func (t *Period) PlusYears_J__Period(yearsToAdd int64) *Period {
	if yearsToAdd == 0 { return t } else {

		return Period_Create_I_I_I__Period(Math_ToIntExact_J__I(Math_AddExact_J_J__J(int64(t.F_years), yearsToAdd)), t.F_months, t.F_days)
	} }
func (t *Period) PlusMonths_J__Period(monthsToAdd int64) *Period {
	if monthsToAdd == 0 { return t } else {

		var tmp1 int32 = t.F_years; return Period_Create_I_I_I__Period(tmp1, Math_ToIntExact_J__I(Math_AddExact_J_J__J(int64(t.F_months), monthsToAdd)), t.F_days)
	} }
func (t *Period) PlusDays_J__Period(daysToAdd int64) *Period {
	if daysToAdd == 0 { return t } else {

		var tmp1 int32 = t.F_years; var tmp2 int32 = t.F_months; return Period_Create_I_I_I__Period(tmp1, tmp2, Math_ToIntExact_J__I(Math_AddExact_J_J__J(int64(t.F_days), daysToAdd)))
	} }
func (t *Period) Minus_TemporalAmount__Period(amountToSubtract TemporalAmount) *Period {
	var isoAmount *Period = Period_From_TemporalAmount__Period(amountToSubtract); var tmp1 int32 = t.F_years; var tmp2 int32 = t.F_months; var tmp3 int32 = t.F_days
	return Period_Create_I_I_I__Period(Math_SubtractExact_I_I__I(tmp1, isoAmount.F_years), Math_SubtractExact_I_I__I(tmp2, isoAmount.F_months), Math_SubtractExact_I_I__I(tmp3, isoAmount.F_days))
}


func (t *Period) MinusYears_J__Period(yearsToSubtract int64) *Period {
	if yearsToSubtract == -9223372036854775808 {
		return NN(t.PlusYears_J__Period(9223372036854775807)).PlusYears_J__Period(1) } else {
			return t.PlusYears_J__Period(-yearsToSubtract)
		} }
func (t *Period) MinusMonths_J__Period(monthsToSubtract int64) *Period {
	if monthsToSubtract == -9223372036854775808 {
		return NN(t.PlusMonths_J__Period(9223372036854775807)).PlusMonths_J__Period(1) } else {
			return t.PlusMonths_J__Period(-monthsToSubtract)
		} }
func (t *Period) MinusDays_J__Period(daysToSubtract int64) *Period {
	if daysToSubtract == -9223372036854775808 {
		return NN(t.PlusDays_J__Period(9223372036854775807)).PlusDays_J__Period(1) } else {
			return t.PlusDays_J__Period(-daysToSubtract)
		} }
func (t *Period) MultipliedBy_I__Period(scalar int32) *Period {
	var tmp1 bool; var tmp2 bool; tmp2 = t == Period_ZERO; if !tmp2 { tmp2 = scalar == 1 }; tmp1 = tmp2; if tmp1 { return t } else {

		return Period_Create_I_I_I__Period(Math_MultiplyExact_I_I__I(t.F_years, scalar), Math_MultiplyExact_I_I__I(t.F_months, scalar), Math_MultiplyExact_I_I__I(t.F_days, scalar))
	}
}

func (t *Period) Negated__Period() *Period { return t.MultipliedBy_I__Period(-1) }

func (t *Period) Normalized__Period() *Period {
	var totalMonths int64 = t.ToTotalMonths__J(); var splitYears int64 = totalMonths / 12; var splitMonths int32 = int32(totalMonths % 12); var tmp1 bool; var tmp2 bool


	tmp2 = splitYears == int64(t.F_years); if tmp2 { tmp2 = splitMonths == t.F_months }; tmp1 = tmp2; if tmp1 { return t } else {

		return Period_Create_I_I_I__Period(Math_ToIntExact_J__I(splitYears), splitMonths, t.F_days)
	} }
func (t *Period) ToTotalMonths__J() int64 {
	return int64(t.F_years)*12 + int64(t.F_months)
}
func (t *Period) AddTo_Temporal__Temporal(temporal Temporal) Temporal {
	t.ValidateChrono_TemporalAccessor__V(temporal)
	if t.F_months == 0 {
		if t.F_years == 0 { } else { var tmp1 Temporal = temporal; var tmp2 int64 = int64(t.F_years); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_YEARS; temporal = tmp1.Plus_J_TemporalUnit__Temporal(tmp2, Up_ChronoUnit_TemporalUnit(tmp3)) } } else {
			var totalMonths int64 = t.ToTotalMonths__J()
			if totalMonths == 0 { } else {
				var tmp4 Temporal = temporal; var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_MONTHS; temporal = tmp4.Plus_J_TemporalUnit__Temporal(totalMonths, Up_ChronoUnit_TemporalUnit(tmp5)) } }
	if t.F_days == 0 { } else { var tmp6 Temporal = temporal; var tmp7 int64 = int64(t.F_days); var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_DAYS; temporal = tmp6.Plus_J_TemporalUnit__Temporal(tmp7, Up_ChronoUnit_TemporalUnit(tmp8)) }
//line :227:1
	return temporal
}








func (t *Period) SubtractFrom_Temporal__Temporal(temporal Temporal) Temporal {
	t.ValidateChrono_TemporalAccessor__V(temporal)
	if t.F_months == 0 {
		if t.F_years == 0 { } else { var tmp1 Temporal = temporal; var tmp2 int64 = int64(t.F_years); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_YEARS; temporal = tmp1.Minus_J_TemporalUnit__Temporal(tmp2, Up_ChronoUnit_TemporalUnit(tmp3)) } } else {
			var totalMonths int64 = t.ToTotalMonths__J()
			if totalMonths == 0 { } else {
				var tmp4 Temporal = temporal; var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_MONTHS; temporal = tmp4.Minus_J_TemporalUnit__Temporal(totalMonths, Up_ChronoUnit_TemporalUnit(tmp5)) } }
	if t.F_days == 0 { } else { var tmp6 Temporal = temporal; var tmp7 int64 = int64(t.F_days); var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_DAYS; temporal = tmp6.Minus_J_TemporalUnit__Temporal(tmp7, Up_ChronoUnit_TemporalUnit(tmp8)) }
//line :237:1
	return temporal
}








func (t *Period) ValidateChrono_TemporalAccessor__V(temporal TemporalAccessor) {
	Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
	var temporalChrono Chronology = Chronology_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery())); var tmp1 bool; var tmp2 bool
	tmp2 = !(temporalChrono == nil); if tmp2 { var tmp3 *IsoChronology; IsoChronology_Init(); tmp3 = IsoChronology_INSTANCE; tmp2 = NN(tmp3).Equals_O__Z(temporalChrono) == false }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2084, temporalChrono.GetId__String()))))
	}
}
func (t *Period) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if Period_InstanceOf(tmp1) { var other *Period = Period_Cast(tmp1); var tmp2 int32 = t.F_years
			if tmp2 == other.F_years {
				var tmp3 int32 = t.F_months; if tmp3 == other.F_months { var tmp4 int32 = t.F_days; return tmp4 == other.F_days } else { return false } } else {
//line :258:1
					return false } } else {
//line :257:1
						return false
					}
	}
}


func (t *Period) HashCode__I() int32 {
	var tmp1 int32 = t.F_years; var tmp2 int32 = tmp1 + Integer_RotateLeft_I_I__I(t.F_months, 8); return tmp2 + Integer_RotateLeft_I_I__I(t.F_days, 16)
}

func (t *Period) ToString__String() *String {
	if t == Period_ZERO { return Lit_2085 } else {

		var buf *StringBuilder = StringBuilder_New()
		NN(buf).Append_C__StringBuilder(80)
		if t.F_years == 0 { } else { NN(NN(buf).Append_I__StringBuilder(t.F_years)).Append_C__StringBuilder(89) }
		if t.F_months == 0 { } else { NN(NN(buf).Append_I__StringBuilder(t.F_months)).Append_C__StringBuilder(77) }
		if t.F_days == 0 { } else { NN(NN(buf).Append_I__StringBuilder(t.F_days)).Append_C__StringBuilder(68) }
		return NN(buf).ToString__String()
	} }
func (t *Period) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.Period.writeReplace()Ljava/lang/Object;")) }









func Period_ReadExternal_DataInput__Period(p0 DataInput) *Period { Period_Init(); panic(A2g_NotTranslated("java.time.Period.readExternal(Ljava/io/DataInput;)Ljava/time/Period;")) }



type Period struct{ Object; F_years, F_months, F_days int32 }

func (t *Period) Is_ChronoPeriod() {}

func (t *Period) Is_Serializable() {}

func (t *Period) Is_TemporalAmount() {}

var Period_ZERO *Period

const Period_serialVersionUID int64 = -3587258372562876

var Period_PATTERN *Pattern

var Period_SUPPORTED_UNITS List

var Period_init ClassInit

func Period_Init() { if !Period_init.Done() { Period_init.Run(Period_clinit) } }

func Period_clinit() { Period_ZERO = Period_New_I_I_I(0, 0, 0); Period_PATTERN = Pattern_Compile_String_I__Pattern(Lit_2080, 2); var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_YEARS; var tmp2 any = tmp1.Ref(); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_MONTHS; var tmp4 any = tmp3.Ref(); var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; Period_SUPPORTED_UNITS = List_Of_O_O_O__List(tmp2, tmp4, tmp5.Ref()) }

func (t *Period) GetChronology__Chronology() Chronology { return Up_IsoChronology_Chronology(t.GetChronology__IsoChronology()) }

func (t *Period) Plus_TemporalAmount__ChronoPeriod(p0 TemporalAmount) ChronoPeriod { return Up_Period_ChronoPeriod(t.Plus_TemporalAmount__Period(p0)) }

func (t *Period) Minus_TemporalAmount__ChronoPeriod(p0 TemporalAmount) ChronoPeriod { return Up_Period_ChronoPeriod(t.Minus_TemporalAmount__Period(p0)) }

func (t *Period) MultipliedBy_I__ChronoPeriod(p0 int32) ChronoPeriod { return Up_Period_ChronoPeriod(t.MultipliedBy_I__Period(p0)) }

func (t *Period) Negated__ChronoPeriod() ChronoPeriod { return Up_Period_ChronoPeriod(t.Negated__Period()) }

func (t *Period) Normalized__ChronoPeriod() ChronoPeriod { return Up_Period_ChronoPeriod(t.Normalized__Period()) }

func (t *Period) Ref() any { if t == nil { return nil }; return t }

func (t *Period) GetClass__Class() *Class { return Period_class }

func (t *Period) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Period) CloneShallow() any { panic(CloneNotSupported(t)) }

func Period_InstanceOf(x any) bool { _, ok := x.(*Period); return ok }

func Period_Cast(x any) *Period { if x == nil { return nil }; v, ok := x.(*Period); if !ok { panic(ClassCast(x, Period_class)) }; return v }
