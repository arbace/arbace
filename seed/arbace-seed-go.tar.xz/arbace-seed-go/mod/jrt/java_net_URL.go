//line java_net_URL.ae:1
package jrt


















func URL_LookupViaProviders_String__URLStreamHandler(protocol *String) URLStreamHandler_I { URL_Init(); return nil }



func (t *URL_DefaultFactory) CreateURLStreamHandler_String__URLStreamHandler(protocol *String) URLStreamHandler_I {
	var tmp1 *String = protocol; var tmp2 int32 = -1; switch NN(tmp1).HashCode__I() { case 104987: if tmp1.Equals_O__Z(Lit_1422) { tmp2 = 1 }; case 3143036: if tmp1.Equals_O__Z(Lit_61) { tmp2 = 0 }; case 3213448: if tmp1.Equals_O__Z(Lit_1432) { tmp2 = 2 }; case 99617003: if tmp1.Equals_O__Z(Lit_1433) { tmp2 = 3 }}; switch tmp2 { case 0:
		return File_Handler_New(); case 1:
		return Jar_Handler_New(); case 2:
		return Http_Handler_New(); case 3:
		return Https_Handler_New(); default:}
//line :24:1
	return nil
}

































func URL_New_String_String_I_String(p0, p1 *String, p2 int32, p3 *String) *URL { URL_Init(); t := &URL{}; t.Ctor_String_String_I_String(p0, p1, p2, p3); return t }
//line :59:1
func (t *URL) Ctor_String_String_I_String(protocol, host *String, port int32, file *String) { t.Ctor_String_String_I_String_URLStreamHandler(protocol, host, port, file, nil) }






func URL_New_String_String_String(p0, p1, p2 *String) *URL { URL_Init(); t := &URL{}; t.Ctor_String_String_String(p0, p1, p2); return t }
//line :66:1
func (t *URL) Ctor_String_String_String(protocol, host, file *String) { t.Ctor_String_String_I_String(protocol, host, -1, file) }





func URL_New_String_String_I_String_URLStreamHandler(p0, p1 *String, p2 int32, p3 *String, p4 URLStreamHandler_I) *URL { URL_Init(); t := &URL{}; t.Ctor_String_String_I_String_URLStreamHandler(p0, p1, p2, p3, p4); return t }
//line :72:1
func (t *URL) Ctor_String_String_I_String_URLStreamHandler(protocol, host *String, port int32, file *String, handler URLStreamHandler_I) { t.F_port = -1; t.F_hashCode = -1





	protocol = URL_LowerCaseProtocol_String__String(protocol)
	t.F_protocol = protocol
	if !(host == nil) {
		var tmp1 bool; var tmp2 bool; tmp2 = NN(host).IndexOf_I__I(58) >= 0; if tmp2 { tmp2 = !NN(host).StartsWith_String__Z(Lit_1318) }; tmp1 = tmp2; if tmp1 {
			host = Concat(Lit_1318, host, Lit_1189) }
		t.F_host = host
		if port < -1 { panic(Thrown(MalformedURLException_New_String(Concat(Lit_1419, StrOfInt(port))))) }
		t.F_port = port
		var tmp3 *String; if port == -1 { tmp3 = host } else { tmp3 = Concat(host, Lit_1309, StrOfInt(port)) }; t.F_authority = tmp3 }
	var index int32 = NN(file).IndexOf_I__I(35); var tmp4 *String
	if index < 0 { tmp4 = nil } else { tmp4 = NN(file).Substring_I__String(index + 1) }; t.F_ref = tmp4
	var tmp5 *String; if index < 0 { tmp5 = file } else { tmp5 = NN(file).Substring_I_I__String(0, index) }; file = tmp5
	var q int32 = NN(file).LastIndexOf_I__I(63)
	if !(q == -1) {

		t.F_query = NN(file).Substring_I__String(q + 1)
		t.F_path = NN(file).Substring_I_I__String(0, q)
		t.F_file = Concat(t.F_path, Lit_1420, t.F_query) } else {
			t.F_path = file; t.F_file = t.F_path }
	var tmp6 bool; var tmp7 bool; tmp7 = handler == nil; if tmp7 { var tmp8 URLStreamHandler_I; handler = URL_GetURLStreamHandler_String__URLStreamHandler(protocol); tmp8 = handler; tmp7 = tmp8 == nil }; tmp6 = tmp7; if tmp6 {
		panic(Thrown(MalformedURLException_New_String(Concat(Lit_1421, protocol)))) }
	t.F_handler = handler
	var tmp9 bool; var tmp10 bool; tmp10 = !(host == nil); if tmp10 { tmp10 = t.IsBuiltinStreamHandler_URLStreamHandler__Z(handler) }; tmp9 = tmp10; if tmp9 {
		var s *String = IPAddressUtil_CheckExternalForm_URL__String(t)
		if !(s == nil) { panic(Thrown(MalformedURLException_New_String(s))) } }
	if Lit_1422.EqualsIgnoreCase_String__Z(protocol) {
		if Jar_Handler_InstanceOf(handler) {
			var s_2 *String = Jar_Handler_Cast(handler).CheckNestedProtocol_String__String(file)
			if !(s_2 == nil) { panic(Thrown(MalformedURLException_New_String(s_2)))
			} } } }
func URL_New_String(p0 *String) *URL { URL_Init(); t := &URL{}; t.Ctor_String(p0); return t }
//line :108:1
func (t *URL) Ctor_String(spec *String) { t.Ctor_URL_String(nil, spec) }



func URL_New_URL_String(p0 *URL, p1 *String) *URL { URL_Init(); t := &URL{}; t.Ctor_URL_String(p0, p1); return t }
//line :112:1
func (t *URL) Ctor_URL_String(context *URL, spec *String) { t.Ctor_URL_String_URLStreamHandler(context, spec, nil) }




func URL_New_URL_String_URLStreamHandler(p0 *URL, p1 *String, p2 URLStreamHandler_I) *URL { URL_Init(); t := &URL{}; t.Ctor_URL_String_URLStreamHandler(p0, p1, p2); return t }
//line :117:1
func (t *URL) Ctor_URL_String_URLStreamHandler(context *URL, spec *String, handler URLStreamHandler_I) { t.F_port = -1; t.F_hashCode = -1



	var original *String = spec; var i int32 = 0; var limit int32 = 0; var c int32 = 0; var start int32 = 0; var newProtocol *String; var aRef bool = false; var isRelative bool = false; tmp21 := func() (exc Throwable_I) { defer Catch(&exc)








		limit = NN(spec).Length__I()
	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = limit > 0; if tmp2 { tmp2 = int32(NN(spec).CharAt_I__C(limit-1)) <= 32 }; tmp1 = tmp2; if tmp1 {
		limit = limit - 1
//line :131:1
		continue L1 }; break L1
	}
	L2: for { var tmp3 bool; var tmp4 bool; tmp4 = start < limit; if tmp4 { tmp4 = int32(NN(spec).CharAt_I__C(start)) <= 32 }; tmp3 = tmp4; if tmp3 {
		start = start + 1
//line :133:1
		continue L2 }; break L2
	}
		if NN(spec).RegionMatches_Z_I_String_I_I__Z(true, start, Lit_1423, 0, 4) { start = start + 4 }
		{ var tmp5 bool; var tmp6 bool; tmp6 = start < NN(spec).Length__I(); if tmp6 { tmp6 = int32(NN(spec).CharAt_I__C(start)) == 35 }; tmp5 = tmp6; if tmp5 { aRef = true }
			i = start
		L3: for { var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = !aRef; if tmp9 { tmp9 = i < limit }; tmp8 = tmp9; if tmp8 { var tmp10 int32; c = int32(NN(spec).CharAt_I__C(i)); tmp10 = c; tmp8 = !(tmp10 == 47) }; tmp7 = tmp8; if tmp7 {
			if c == 58 {
				var s *String = URL_LowerCaseProtocol_String__String(NN(spec).Substring_I_I__String(start, i))
				if t.IsValidProtocol_String__Z(s) {
					newProtocol = s
					start = i + 1 }
				break L3 }
			i = i + 1
//line :138:1
			continue L3 }; break L3
		}






			t.F_protocol = newProtocol
			var tmp11 bool; var tmp12 bool; tmp12 = !(context == nil); if tmp12 {
				var tmp13 bool; tmp13 = newProtocol == nil; if !tmp13 { tmp13 = NN(newProtocol).EqualsIgnoreCase_String__Z(context.F_protocol) }; tmp12 = tmp13 }
//line :147:1
			tmp11 = tmp12; if tmp11 {

				if handler == nil { handler = context.F_handler }
				var tmp14 bool; var tmp15 bool; tmp15 = !(context.F_path == nil); if tmp15 { tmp15 = NN(context.F_path).StartsWith_String__Z(Lit_68) }; tmp14 = tmp15; if tmp14 {
					newProtocol = nil }
				if newProtocol == nil {
					t.F_protocol = context.F_protocol
					t.F_authority = context.F_authority
					t.F_userInfo = context.F_userInfo
					t.F_host = context.F_host
					t.F_port = context.F_port
					t.F_file = context.F_file
					t.F_path = context.F_path
					isRelative = true } }
			if t.F_protocol == nil { panic(Thrown(MalformedURLException_New_String(Concat(Lit_1424, original)))) }
			var tmp16 bool; var tmp17 bool; tmp17 = handler == nil; if tmp17 { var tmp18 URLStreamHandler_I; handler = URL_GetURLStreamHandler_String__URLStreamHandler(t.F_protocol); tmp18 = handler; tmp17 = tmp18 == nil }; tmp16 = tmp17; if tmp16 {
				panic(Thrown(MalformedURLException_New_String(Concat(Lit_1421, t.F_protocol)))) }
			t.F_handler = handler
			i = NN(spec).IndexOf_I_I__I(35, start)
			if i >= 0 { t.F_ref = NN(spec).Substring_I_I__String(i+1, limit); limit = i }
			var tmp19 bool; var tmp20 bool; tmp20 = isRelative; if tmp20 { tmp20 = start == limit }; tmp19 = tmp20; if tmp19 {
				t.F_query = context.F_query
				if t.F_ref == nil { t.F_ref = context.F_ref } }
			handler.ParseURL_URL_String_I_I__V(t, spec, start, limit) }
//line :121:1
		return nil
	}()






	if tmp21 != nil { if MalformedURLException_InstanceOf(tmp21) { var e *MalformedURLException = MalformedURLException_Cast(tmp21)









































		panic(Thrown(Up_MalformedURLException_Throwable(e))) } else if /*line :129:1*/ Exception_InstanceOf(tmp21) { var e_2 Exception_I = Exception_Cast(tmp21); var exception *MalformedURLException = MalformedURLException_New_String(e_2.GetMessage__String())












































			NN(exception).InitCause_Throwable__Throwable(e_2)
			panic(Thrown(Up_MalformedURLException_Throwable(exception))) } else {
//line :129:1
				panic(tmp21)
			}
	}
}












































func URL_Of_URI_URLStreamHandler__URL(uri *URI, handler URLStreamHandler_I) *URL { URL_Init()

	if NN(uri).IsAbsolute__Z() { } else { panic(Thrown(IllegalArgumentException_New_String(Lit_59))) }
	var protocol *String = NN(uri).GetScheme__String(); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool
	tmp5 = handler == nil; if tmp5 { tmp5 = NN(protocol).Equals_O__Z(Lit_1425) }; tmp4 = tmp5; if tmp4 { tmp4 = !NN(uri).IsOpaque__Z() }; tmp3 = tmp4; if tmp3 {
		tmp3 = NN(uri).GetRawAuthority__String() == nil }
//line :181:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = NN(uri).GetRawFragment__String() == nil }
//line :181:1
	tmp1 = tmp2; if tmp1 {


		var query *String = NN(uri).GetRawQuery__String(); var path *String = NN(uri).GetRawPath__String(); var file *String

		if query == nil { file = path } else { file = Concat(path, Lit_1420, query) }
//line :184:1
		var host *String = NN(uri).GetHost__String()



		if host == nil { host = Lit_69 }
		var port int32 = NN(uri).GetPort__I(); return URL_New_String_String_I_String_URLStreamHandler(Lit_1425, host, port, file, nil) } else {

			if Lit_1426.EqualsIgnoreCase_String__Z(protocol) {
				var uristr *String = NN(uri).ToString__String(); tmp6 := func() (exc Throwable_I) { defer Catch(&exc)

					{ var inner *URI = URI_New_String(NN(uristr).Substring_I__String(4))
						if NN(inner).IsAbsolute__Z() { protocol = NN(inner).GetScheme__String() } }
//line :192:1
					return nil }()
				if tmp6 != nil { if URISyntaxException_InstanceOf(tmp6) { var use *URISyntaxException = URISyntaxException_Cast(tmp6)


					panic(Thrown(MalformedURLException_New_String(NN(use).GetMessage__String()))) } else {
//line :193:1
						panic(tmp6)
					}
				}
			}
			var tmp7 bool; var tmp8 bool; tmp8 = !(handler == nil); if tmp8 { tmp8 = !URL_IsOverrideable_String__Z(protocol) }; tmp7 = tmp8; if tmp7 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1427, protocol))))
			}
			return URL_New_URL_String_URLStreamHandler(nil, NN(uri).ToString__String(), handler)
		} }
func (t *URL) IsValidProtocol_String__Z(protocol *String) bool {
	var len_ int32 = NN(protocol).Length__I()
	if len_ < 1 { return false } else {

		var c uint16 = NN(protocol).CharAt_I__C(0)
		if !Character_IsLetter_C__Z(c) { return false } else {


			var i int32 = 1; L1: for {
				if i < len_ {
					c = NN(protocol).CharAt_I__C(i)
					var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = !Character_IsLetterOrDigit_C__Z(c); if tmp4 { tmp4 = !(int32(c) == 46) }; tmp3 = tmp4; if tmp3 {
						tmp3 = !(int32(c) == 43) }
//line :213:1
					tmp2 = tmp3; if tmp2 {

						tmp2 = !(int32(c) == 45) }
//line :213:1
					tmp1 = tmp2; if tmp1 {


						return false } else {
							i = i + 1; continue L1 } }
//line :210:1
				break L1 }
//line :209:1
			return true
		}
	}
}







func (t *URL) Set_String_String_I_String_String_String_String_String__V(protocol, host *String, port int32, authority, userInfo, path, query, ref *String) {

	var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.F_protocol = protocol
		t.F_host = host
		t.F_port = port
		var tmp2 *String; if query == nil { tmp2 = path } else { tmp2 = Concat(path, Lit_1420, query) }; t.F_file = tmp2
		t.F_userInfo = userInfo
		t.F_path = path
		t.F_ref = ref
		t.F_hashCode = -1
		t.F_hostAddress = nil
		t.F_query = query
		t.F_authority = authority
	}() }
func (t *URL) GetHostAddress__InetAddress() InetAddress_I { MonitorEnter(t); defer MonitorExit(t)
	if !(t.F_hostAddress == nil) { return t.F_hostAddress } else {

		var tmp1 bool; var tmp2 bool; tmp2 = t.F_host == nil; if !tmp2 { tmp2 = NN(t.F_host).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { return nil } else { tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

			t.F_hostAddress = InetAddress_GetByName_String__InetAddress(t.F_host); return nil }()
//line :239:1
			if tmp3 != nil { if UnknownHostException_InstanceOf(tmp3) { var e *UnknownHostException = UnknownHostException_Cast(tmp3); _ = e

				return nil } else {
//line :239:1
					panic(tmp3) } }
//line :238:1
			return t.F_hostAddress
		}
	}
}


func (t *URL) GetQuery__String() *String { return t.F_query }

func (t *URL) GetPath__String() *String { return t.F_path }

func (t *URL) GetUserInfo__String() *String { return t.F_userInfo }

func (t *URL) GetAuthority__String() *String { return t.F_authority }

func (t *URL) GetPort__I() int32 { return t.F_port }

func (t *URL) GetDefaultPort__I() int32 { return t.F_handler.GetDefaultPort__I() }

func (t *URL) GetProtocol__String() *String { return t.F_protocol }

func (t *URL) GetHost__String() *String { return t.F_host }

func (t *URL) GetFile__String() *String { return t.F_file }

func (t *URL) GetRef__String() *String { return t.F_ref }

func (t *URL) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if URL_InstanceOf(tmp1) { var u2 *URL = URL_Cast(tmp1); return t.F_handler.Equals_URL_URL__Z(t, u2) } else { return false
	} }
func (t *URL) HashCode__I() int32 { MonitorEnter(t); defer MonitorExit(t)
	if !(t.F_hashCode == -1) { return t.F_hashCode } else { t.F_hashCode = t.F_handler.HashCode_URL__I(t); return t.F_hashCode
	} }
func (t *URL) SameFile_URL__Z(other *URL) bool {
	return t.F_handler.SameFile_URL_URL__Z(t, other)
}
func (t *URL) ToString__String() *String { return t.ToExternalForm__String() }

func (t *URL) ToExternalForm__String() *String {
	return t.F_handler.ToExternalForm_URL__String(t)
}
func (t *URL) ToURI__URI() *URI {
	var uri *URI = URI_New_String(t.ToString__String()); var tmp1 bool; var tmp2 bool
	tmp2 = !(t.F_authority == nil); if tmp2 { tmp2 = t.IsBuiltinStreamHandler_URLStreamHandler__Z(t.F_handler) }; tmp1 = tmp2; if tmp1 {
		var s *String = IPAddressUtil_CheckAuthority_URL__String(t)
		if !(s == nil) {
			panic(Thrown(URISyntaxException_New_String_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_authority))), s))) } }
//line :279:1
	return uri
}









func (t *URL) OpenConnection__URLConnection() URLConnection_I {
	return t.F_handler.OpenConnection_URL__URLConnection(t)
}







func (t *URL) OpenStream__InputStream() InputStream_I {
	return t.OpenConnection__URLConnection().GetInputStream__InputStream()
}
func (t *URL) GetContent__O() any {
	return t.OpenConnection__URLConnection().GetContent__O()
}
func (t *URL) GetContent_Class1__O(classes *RefArray) any {
	return t.OpenConnection__URLConnection().GetContent_Class1__O(classes)
}


func URL_SetURLStreamHandlerFactory_URLStreamHandlerFactory__V(fac URLStreamHandlerFactory) { URL_Init()
	var tmp1 any = URL_streamHandlerLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if !(URL_factory.Load() == nil) { panic(Thrown(Error_New_String(Lit_1345))) }
		URL_handlers.Clear__V()
		URL_factory.Store(fac)
	}()
}


















func URL_LookupViaProperty_String__URLStreamHandler(protocol *String) URLStreamHandler_I { URL_Init()
	var packagePrefixList *String = System_GetProperty_String__String(Lit_1428); var tmp1 bool; var tmp2 bool
	tmp2 = packagePrefixList == nil; if !tmp2 { tmp2 = NN(packagePrefixList).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { return nil } else {
		var packagePrefixes *RefArray = NN(packagePrefixList).Split_String__String1(Lit_1429); var handler URLStreamHandler_I
		var i int32 = 0
	L1: for {
		var tmp3 bool; var tmp4 bool; tmp4 = handler == nil; if tmp4 { tmp4 = i < int32(len(packagePrefixes.A)) }; tmp3 = tmp4; if tmp3 {
			var packagePrefix *String = NN(As[*String](packagePrefixes.A[i])).Trim__String()
			if NN(packagePrefix).IsEmpty__Z() {
				i = i + 1; continue L1 } else { tmp6 := func() (exc Throwable_I) { defer Catch(&exc)


					{ var clsName *String = Concat(packagePrefix, Lit_79, protocol, Lit_1430); var cls *Class; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)


						cls = Class_ForName_String__Class(clsName); return nil }()
//line :350:1
						if tmp5 != nil { if ClassNotFoundException_InstanceOf(tmp5) { var e *ClassNotFoundException = ClassNotFoundException_Cast(tmp5); var cl ClassLoader_I = ClassLoader_GetSystemClassLoader__ClassLoader(); _ = e



							if !(cl == nil) { cls = cl.LoadClass_String__Class(clsName) } } else {
//line :350:1
								panic(tmp5)
							}
						}


						if !(cls == nil) {
							var tmp any = NN(cls).NewInstance__O()
							handler = URLStreamHandler_Cast(tmp) } }; return nil }()
//line :347:1
					if tmp6 != nil { if Exception_InstanceOf(tmp6) { var e_2 Exception_I = Exception_Cast(tmp6); _ = e_2 } else { panic(tmp6)
					}
					}









					i = i + 1; continue L1 } }
//line :341:1
		break L1 }
//line :339:1
		return handler
	}
}









































func URL_LowerCaseProtocol_String__String(protocol *String) *String { URL_Init()
	if NN(protocol).Equals_O__Z(Lit_1425) { return Lit_1425 } else { if NN(protocol).Equals_O__Z(Lit_61) { return Lit_61 } else { if NN(protocol).Equals_O__Z(Lit_1422) { return Lit_1422 } else {



		var tmp1 *Locale; Locale_Init(); tmp1 = Locale_ROOT; return NN(protocol).ToLowerCase_Locale__String(tmp1)
	} } } }
func URL_IsOverrideable_String__Z(protocol *String) bool { URL_Init()
	if NN(protocol).Length__I() == 3 {

		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = int32(Character_ToLowerCase_C__C(NN(protocol).CharAt_I__C(0))) == 106; if tmp3 {
			tmp3 = int32(Character_ToLowerCase_C__C(NN(protocol).CharAt_I__C(1))) == 114 }
//line :393:1
		tmp2 = tmp3; if tmp2 {

			tmp2 = int32(Character_ToLowerCase_C__C(NN(protocol).CharAt_I__C(2))) == 116 }
//line :393:1
		tmp1 = tmp2; if tmp1 {


			return false } } else {
//line :391:1
				if NN(protocol).Length__I() == 4 {






					var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = int32(Character_ToLowerCase_C__C(NN(protocol).CharAt_I__C(0))) == 102; if tmp7 {
						tmp7 = int32(Character_ToLowerCase_C__C(NN(protocol).CharAt_I__C(1))) == 105 }
//line :398:1
					tmp6 = tmp7; if tmp6 {

						tmp6 = int32(Character_ToLowerCase_C__C(NN(protocol).CharAt_I__C(2))) == 108 }
//line :398:1
					tmp5 = tmp6; if tmp5 {


						tmp5 = int32(Character_ToLowerCase_C__C(NN(protocol).CharAt_I__C(3))) == 101 }
//line :398:1
					tmp4 = tmp5; if tmp4 {



						return false } } }
//line :390:1
	return true
}


















func URL_GetURLStreamHandler_String__URLStreamHandler(protocol *String) URLStreamHandler_I { URL_Init()
	var handler URLStreamHandler_I = URLStreamHandler_Cast(URL_handlers.Get_O__O(protocol.Ref()))
	if !(handler == nil) { return handler } else {

		var fac URLStreamHandlerFactory; var checkedWithFactory bool = false; var overrideableProtocol bool = URL_IsOverrideable_String__Z(protocol); var tmp1 bool; var tmp2 bool


		tmp2 = overrideableProtocol; if tmp2 { tmp2 = VM_IsBooted__Z() }; tmp1 = tmp2; if tmp1 {
			fac = URL_factory.Load()
			if !(fac == nil) {
				handler = fac.CreateURLStreamHandler_String__URLStreamHandler(protocol)
				checkedWithFactory = true }
			var tmp3 bool; var tmp4 bool; tmp4 = handler == nil; if tmp4 { tmp4 = !NN(protocol).EqualsIgnoreCase_String__Z(Lit_1422) }; tmp3 = tmp4; if tmp3 {
				handler = URL_LookupViaProviders_String__URLStreamHandler(protocol) }
			if handler == nil { handler = URL_LookupViaProperty_String__URLStreamHandler(protocol) } }
		if handler == nil { handler = URL_defaultFactory.CreateURLStreamHandler_String__URLStreamHandler(protocol) }
		var tmp5 any = URL_streamHandlerLock; MonitorEnter(tmp5); tmp10, tmp11 := func() (ctl int32, rv URLStreamHandler_I) { defer MonitorExit(tmp5)
			{ var handler2 URLStreamHandler_I
				handler2 = URLStreamHandler_Cast(URL_handlers.Get_O__O(protocol.Ref()))
				if !(handler2 == nil) { return 2, handler2 }
				var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = overrideableProtocol; if tmp8 { tmp8 = !checkedWithFactory }; tmp7 = tmp8; if tmp7 {
					var tmp9 URLStreamHandlerFactory; fac = URL_factory.Load(); tmp9 = fac; tmp7 = !(tmp9 == nil) }
//line :430:1
				tmp6 = tmp7; if tmp6 {

					handler2 = fac.CreateURLStreamHandler_String__URLStreamHandler(protocol) }
				if !(handler2 == nil) { handler = handler2 }
				if !(handler == nil) { URL_handlers.Put_O_O__O(protocol.Ref(), handler) } }; return 0, nil }()
//line :426:1
		switch tmp10 { case 2: { return tmp11 }}
//line :414:1
		return handler
	}
}




















































func (t *URL) ReadResolve__O() any { panic(A2g_NotTranslated("java.net.URL.readResolve()Ljava/lang/Object;")) }








func (t *URL) SetDeserializedFields_URLStreamHandler__URL(p0 URLStreamHandler_I) *URL { panic(A2g_NotTranslated("java.net.URL.setDeserializedFields(Ljava/net/URLStreamHandler;)Ljava/net/URL;")) }












































func (t *URL) FabricateNewURL__URL() *URL { panic(A2g_NotTranslated("java.net.URL.fabricateNewURL()Ljava/net/URL;")) }













func (t *URL) IsBuiltinStreamHandler_URLStreamHandler__Z(handler URLStreamHandler_I) bool {
	var handlerClass *Class = handler.GetClass__Class(); var tmp1 bool
	tmp1 = t.IsBuiltinStreamHandler_String__Z(NN(handlerClass).GetName__String()); if !tmp1 {
		tmp1 = VM_IsSystemDomainLoader_ClassLoader__Z(NN(handlerClass).GetClassLoader__ClassLoader()) }
//line :539:1
	return tmp1
}

func (t *URL) IsBuiltinStreamHandler_String__Z(handlerClassName *String) bool {
	return NN(handlerClassName).StartsWith_String__Z(Lit_1431)
}
func (t *URL) ResetState__V() { panic(A2g_NotTranslated("java.net.URL.resetState()V")) }













func (t *URL) SetSerializedHashCode_I__V(p0 int32) { panic(A2g_NotTranslated("java.net.URL.setSerializedHashCode(I)V")) }



type URL struct{ Object; F_protocol, F_host *String; F_port int32; F_file, F_query, F_authority, F_path, F_userInfo, F_ref *String; F_hostAddress InetAddress_I; F_handler URLStreamHandler_I; F_hashCode int32; F_tempState *UrlDeserializedState }

func (t *URL) Is_Serializable() {}

var URL_BUILTIN_HANDLERS_PREFIX *String = Lit_1431

const URL_serialVersionUID int64 = -7627629688361524110

var URL_protocolPathProp *String = Lit_1428

var URL_factory Volatile[URLStreamHandlerFactory]

var URL_defaultFactory URLStreamHandlerFactory

var URL_handlers Hashtable_I

var URL_streamHandlerLock any

var URL_init ClassInit

func URL_Init() { if !URL_init.Done() { URL_init.Run(URL_clinit) } }

func URL_clinit() { URL_defaultFactory = URL_DefaultFactory_New(); URL_handlers = Hashtable_New(); URL_streamHandlerLock = Object_New() }

func (t *URL) Ref() any { if t == nil { return nil }; return t }

func (t *URL) GetClass__Class() *Class { return URL_class }

func (t *URL) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URL) CloneShallow() any { panic(CloneNotSupported(t)) }

func URL_InstanceOf(x any) bool { _, ok := x.(*URL); return ok }

func URL_Cast(x any) *URL { if x == nil { return nil }; v, ok := x.(*URL); if !ok { panic(ClassCast(x, URL_class)) }; return v }



type URL_DefaultFactory struct{ Object }

func (t *URL_DefaultFactory) Is_URLStreamHandlerFactory() {}

var URL_DefaultFactory_PREFIX *String = Lit_1434

func URL_DefaultFactory_New() *URL_DefaultFactory { t := &URL_DefaultFactory{}; t.Ctor(); return t }

func (t *URL_DefaultFactory) Ctor() {}

func (t *URL_DefaultFactory) Ref() any { if t == nil { return nil }; return t }

func (t *URL_DefaultFactory) GetClass__Class() *Class { return URL_DefaultFactory_class }

func (t *URL_DefaultFactory) ToString__String() *String { return Object_toString(t) }

func (t *URL_DefaultFactory) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URL_DefaultFactory) CloneShallow() any { panic(CloneNotSupported(t)) }

func URL_DefaultFactory_InstanceOf(x any) bool { _, ok := x.(*URL_DefaultFactory); return ok }

func URL_DefaultFactory_Cast(x any) *URL_DefaultFactory { if x == nil { return nil }; v, ok := x.(*URL_DefaultFactory); if !ok { panic(ClassCast(x, URL_DefaultFactory_class)) }; return v }
