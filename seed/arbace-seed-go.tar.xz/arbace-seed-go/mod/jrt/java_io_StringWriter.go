//line java_io_StringWriter.ae:1
package jrt










func StringWriter_New() *StringWriter { t := &StringWriter{}; t.Ctor(); return t }
//line :12:1
func (t *StringWriter) Ctor() { t.Writer.Ctor(t)
	t.F_buf = StringBuffer_New()
	t.F_lock = t.F_buf.Ref()
}
func StringWriter_New_I(p0 int32) *StringWriter { t := &StringWriter{}; t.Ctor_I(p0); return t }
//line :16:1
func (t *StringWriter) Ctor_I(initialSize int32) { t.Writer.Ctor(t)
	if initialSize < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_101))) }
	t.F_buf = StringBuffer_New_I(initialSize)
	t.F_lock = t.F_buf.Ref()
}
func (t *StringWriter) Write_I__V(c int32) {
	NN(t.F_buf).Append_C__StringBuffer(uint16(c))
}
func (t *StringWriter) Write_C1_I_I__V(cbuf *CharArray, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
	if len_ == 0 { } else { NN(t.F_buf).Append_C1_I_I__StringBuffer(cbuf, off, len_)
	} }
func (t *StringWriter) Write_String__V(str *String) { NN(t.F_buf).Append_String__StringBuffer(str) }

func (t *StringWriter) Write_String_I_I__V(str *String, off, len_ int32) {
	NN(t.F_buf).Append_CharSequence_I_I__StringBuffer(Up_String_CharSequence(str), off, off+len_)
}
func (t *StringWriter) Append_CharSequence__StringWriter(csq CharSequence) *StringWriter {
	t.Write_String__V(String_ValueOf_O__String(csq))
//line :33:1
	return t
}


func (t *StringWriter) Append_CharSequence_I_I__StringWriter(csq CharSequence, start, end int32) *StringWriter {
	if csq == nil { csq = Lit_95 }
	return t.Append_CharSequence__StringWriter(csq.SubSequence_I_I__CharSequence(start, end))
}
func (t *StringWriter) Append_C__StringWriter(c uint16) *StringWriter {
	t.Write_I__V(int32(c))
//line :41:1
	return t
}


func (t *StringWriter) ToString__String() *String { return NN(t.F_buf).ToString__String() }

func (t *StringWriter) GetBuffer__StringBuffer() *StringBuffer { return t.F_buf }

func (t *StringWriter) Flush__V() {}

func (t *StringWriter) Close__V() {}



type StringWriter struct{ Writer; F_buf *StringBuffer }

func (t *StringWriter) Append_CharSequence__Writer(p0 CharSequence) Writer_I { return Up_StringWriter_Writer(t.Append_CharSequence__StringWriter(p0)) }

func (t *StringWriter) Append_CharSequence_I_I__Writer(p0 CharSequence, p1, p2 int32) Writer_I { return Up_StringWriter_Writer(t.Append_CharSequence_I_I__StringWriter(p0, p1, p2)) }

func (t *StringWriter) Append_C__Writer(p0 uint16) Writer_I { return Up_StringWriter_Writer(t.Append_C__StringWriter(p0)) }

func (t *StringWriter) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return Up_StringWriter_Appendable(t.Append_CharSequence__StringWriter(p0)) }

func (t *StringWriter) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return Up_StringWriter_Appendable(t.Append_CharSequence_I_I__StringWriter(p0, p1, p2)) }

func (t *StringWriter) Append_C__Appendable(p0 uint16) Appendable { return Up_StringWriter_Appendable(t.Append_C__StringWriter(p0)) }

func (t *StringWriter) Write_C1__V(p0 *CharArray) { t.Impl_Write_C1__V(t, p0) }

func (t *StringWriter) Ref() any { if t == nil { return nil }; return t }

func (t *StringWriter) GetClass__Class() *Class { return StringWriter_class }

func (t *StringWriter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringWriter) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringWriter_InstanceOf(x any) bool { _, ok := x.(*StringWriter); return ok }

func StringWriter_Cast(x any) *StringWriter { if x == nil { return nil }; v, ok := x.(*StringWriter); if !ok { panic(ClassCast(x, StringWriter_class)) }; return v }
