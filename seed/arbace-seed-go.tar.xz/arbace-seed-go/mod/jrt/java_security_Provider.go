//line java_security_Provider.ae:1
package jrt

import "sync/atomic"
















































func Provider_ParseVersionStr_String__D(s *String) float64 { Provider_Init()
	var tmp1 float64; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var firstDotIdx int32 = NN(s).IndexOf_I__I(46); var nextDotIdx int32 = NN(s).IndexOf_I_I__I(46, firstDotIdx+1)

			if nextDotIdx == -1 { } else { s = NN(s).Substring_I_I__String(0, nextDotIdx) }
			var endIdx int32 = NN(s).IndexOf_I__I(45)
			if endIdx > 0 { s = NN(s).Substring_I_I__String(0, endIdx) }
			endIdx = NN(s).IndexOf_I__I(43)
			if endIdx > 0 { s = NN(s).Substring_I_I__String(0, endIdx) }
			tmp1 = Double_ParseDouble_String__D(s) }; return nil }()
//line :53:1
	if tmp2 != nil { if NullPointerException_InstanceOf(tmp2) || NumberFormatException_InstanceOf(tmp2) { var e RuntimeException_I = RuntimeException_Cast(tmp2); _ = e; tmp1 = 0.0 } else { panic(tmp2) } }; return tmp1
}

func (t *Provider_Service) NewInstanceUtil_Class_O__O(ctrParamClz *Class, ctorParamObj any) any {

	var o any = JrtServices_NewInstance_String_Class_O__O(t.F_className, ctrParamClz, ctorParamObj)
	if !(o == nil) {
		return o }
	if ctrParamClz == nil {
		return t.NewInstanceOf__O() } else {
			var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var con *Constructor = NN(t.GetImplClass__Class()).GetConstructor_Class1__Constructor(RefArrayOf(Class_class, ctrParamClz.Ref()))
					tmp1 = NN(con).NewInstance_O1__O(RefArrayOf(Object_class, ctorParamObj)) }
//line :63:1
				return nil }(); if tmp2 != nil { if NoSuchMethodException_InstanceOf(tmp2) { var nsme *NoSuchMethodException = NoSuchMethodException_Cast(tmp2)



					if ctorParamObj == nil { tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

						tmp1 = t.NewInstanceOf__O()
//line :67:1
						return nil }()
						if tmp3 != nil { if NoSuchMethodException_InstanceOf(tmp3) { var nsme2 *NoSuchMethodException = NoSuchMethodException_Cast(tmp3)


							NN(nsme).AddSuppressed_Throwable__V(Up_NoSuchMethodException_Throwable(nsme2))
							panic(Thrown(Up_NoSuchMethodException_Throwable(nsme))) } else {
//line :68:1
								panic(tmp3) } } } else {




									panic(Thrown(Up_NoSuchMethodException_Throwable(nsme))) } } else {
//line :63:1
										panic(tmp2) } }; return tmp1 } }
func (t *Provider) Ctor_String_D_String(this Provider_I, name *String, version float64, info *String) { panic(A2g_NotTranslated("java.security.Provider.<init>(Ljava/lang/String;DLjava/lang/String;)V")) }











func (t *Provider) Ctor_String_String_String(this Provider_I, name, versionStr, info *String) { t.Properties.Ctor(this); t.F_entrySet = nil; t.F_entrySetCallCount = 0
	t.F_name = name
	t.F_versionStr = versionStr
	t.F_version = Provider_ParseVersionStr_String__D(versionStr)
	t.F_info = info
	t.F_serviceMap = ConcurrentHashMap_New()
	t.F_legacyMap = ConcurrentHashMap_New()
	t.F_prngAlgos = LinkedHashSet_New_I(6)
	t.Impl_PutId__V(this)
	t.F_initialized = true
}
func (t *Provider) Impl_Configure_String__Provider(this Provider_I, configArg *String) Provider_I {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_1587)))
}
func (t *Provider) Impl_IsConfigured__Z(this Provider_I) bool { return true }

func (t *Provider) Impl_GetName__String(this Provider_I) *String { return t.F_name }

func (t *Provider) Impl_GetVersion__D(this Provider_I) float64 { return t.F_version }


func (t *Provider) Impl_GetVersionStr__String(this Provider_I) *String { return t.F_versionStr }

func (t *Provider) Impl_GetInfo__String(this Provider_I) *String { return t.F_info }

func (t *Provider) Impl_ToString__String(this Provider_I) *String {
	return Concat(t.F_name, Lit_1588, t.F_versionStr)
}
func (t *Provider) Impl_Clear__V(this Provider_I) { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1589, t.F_name, Lit_1590)) }
	t.Impl_ImplClear__V(this)
}
func (t *Provider) Impl_Load_InputStream__V(this Provider_I, inStream InputStream_I) { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1591, t.F_name, Lit_1590)) }
	var tempProperties Properties_I = Properties_New()
	tempProperties.Load_InputStream__V(inStream)
	t.Impl_ImplPutAll_Map__V(this, tempProperties)
}
func (t *Provider) Impl_PutAll_Map__V(this Provider_I, t_ Map) { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1592, t.F_name, Lit_1590)) }
	t.Impl_ImplPutAll_Map__V(this, t_)
}
func (t *Provider) Impl_EntrySet__Set(this Provider_I) Set { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if t.F_entrySet == nil {
		var tmp1 int32; var old_1 int32 = t.F_entrySetCallCount
		t.F_entrySetCallCount = t.F_entrySetCallCount + 1
//line :124:1
		tmp1 = old_1; if tmp1 == 0 {



			t.F_entrySet = Collections_UnmodifiableMap_Map__Map(this).EntrySet__Set() } else {
				return t.Properties.Impl_EntrySet__Set(this) } }
	if t.F_entrySetCallCount == 2 { } else { panic(Thrown(RuntimeException_New_String(Lit_1593))) }
//line :121:1
	return t.F_entrySet
}










func (t *Provider) Impl_KeySet__Set(this Provider_I) Set {
	t.Impl_CheckInitialized__V(this)
	return Collections_UnmodifiableSet_Set__Set(t.Properties.Impl_KeySet__Set(this))
}
func (t *Provider) Impl_Values__Collection(this Provider_I) Collection {
	t.Impl_CheckInitialized__V(this)
	return Collections_UnmodifiableCollection_Collection__Collection(t.Properties.Impl_Values__Collection(this))
}
func (t *Provider) Impl_Put_O_O__O(this Provider_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) {
		var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1594, t.F_name, Lit_1595, StrOfObj(key), Lit_68, StrOfObj(value), Lit_1189)) }
	return t.Impl_ImplPut_O_O__O(this, key, value)
}
func (t *Provider) Impl_PutIfAbsent_O_O__O(this Provider_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) {
		var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1594, t.F_name, Lit_1595, StrOfObj(key), Lit_68, StrOfObj(value), Lit_1189)) }
	return t.Impl_ImplPutIfAbsent_O_O__O(this, key, value)
}
func (t *Provider) Impl_Remove_O__O(this Provider_I, key any) any { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1589, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplRemove_O__O(this, key)
}
func (t *Provider) Impl_Remove_O_O__Z(this Provider_I, key, value any) bool { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1589, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplRemove_O_O__Z(this, key, value)
}
func (t *Provider) Impl_Replace_O_O_O__Z(this Provider_I, key, oldValue, newValue any) bool { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1597, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplReplace_O_O_O__Z(this, key, oldValue, newValue)
}
func (t *Provider) Impl_Replace_O_O__O(this Provider_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1597, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplReplace_O_O__O(this, key, value)
}
func (t *Provider) Impl_ReplaceAll_BiFunction__V(this Provider_I, function BiFunction) { MonitorEnter(this); defer MonitorExit(this)

	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1598, t.F_name, Lit_1596)) }
	t.Impl_ImplReplaceAll_BiFunction__V(this, function)
}
func (t *Provider) Impl_Compute_O_BiFunction__O(this Provider_I, key any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1599, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplCompute_O_BiFunction__O(this, key, remappingFunction)
}
func (t *Provider) Impl_ComputeIfAbsent_O_Function__O(this Provider_I, key any, mappingFunction Function) any { MonitorEnter(this); defer MonitorExit(this)

	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) {
		var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1600, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplComputeIfAbsent_O_Function__O(this, key, mappingFunction)
}
func (t *Provider) Impl_ComputeIfPresent_O_BiFunction__O(this Provider_I, key any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) {
		var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1601, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplComputeIfPresent_O_BiFunction__O(this, key, remappingFunction)
}
func (t *Provider) Impl_Merge_O_O_BiFunction__O(this Provider_I, key, value any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1602, t.F_name, Lit_1596, StrOfObj(key))) }
	return t.Impl_ImplMerge_O_O_BiFunction__O(this, key, value, remappingFunction)
}
func (t *Provider) Impl_Get_O__O(this Provider_I, key any) any {
	t.Impl_CheckInitialized__V(this)
	return t.Properties.Impl_Get_O__O(this, key)
}
func (t *Provider) Impl_GetOrDefault_O_O__O(this Provider_I, key, defaultValue any) any { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_CheckInitialized__V(this)
	return t.Properties.Impl_GetOrDefault_O_O__O(this, key, defaultValue)
}
func (t *Provider) Impl_ForEach_BiConsumer__V(this Provider_I, action BiConsumer) { MonitorEnter(this); defer MonitorExit(this)

	t.Impl_CheckInitialized__V(this)
	t.Properties.Impl_ForEach_BiConsumer__V(this, action)
}
func (t *Provider) Impl_Keys__Enumeration(this Provider_I) Enumeration {
	t.Impl_CheckInitialized__V(this)
	return t.Properties.Impl_Keys__Enumeration(this)
}
func (t *Provider) Impl_Elements__Enumeration(this Provider_I) Enumeration {
	t.Impl_CheckInitialized__V(this)
	return t.Properties.Impl_Elements__Enumeration(this)
}
func (t *Provider) Impl_GetProperty_String__String(this Provider_I, key *String) *String {
	t.Impl_CheckInitialized__V(this)
	return t.Properties.Impl_GetProperty_String__String(this, key)
}
func (t *Provider) Impl_CheckInitialized__V(this Provider_I) {
	if t.F_initialized { } else { panic(Thrown(IllegalStateException_New()))
	}
}











func (t *Provider) Impl_PutId__V(this Provider_I) {
	t.Properties.Impl_Put_O_O__O(this, Lit_1604, String_ValueOf_O__String(t.F_name.Ref()).Ref())
	t.Properties.Impl_Put_O_O__O(this, Lit_1605, String_ValueOf_O__String(t.F_versionStr.Ref()).Ref())
	t.Properties.Impl_Put_O_O__O(this, Lit_1606, String_ValueOf_O__String(t.F_info.Ref()).Ref())
	t.Properties.Impl_Put_O_O__O(this, Lit_1607, NN(this.GetClass__Class()).GetName__String().Ref())
}

















func Provider_CheckLegacy_O__Z(key any) bool { Provider_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = String_InstanceOf(key); if tmp2 { tmp2 = NN(String_Cast(key)).StartsWith_String__Z(Lit_1608) }; tmp1 = tmp2; if tmp1 { return false } else { return true
	} }
func (t *Provider) Impl_ImplPutAll_Map__V(this Provider_I, t_ Map) {
	var i_101194 Iterator = t_.EntrySet__Set().Iterator__Iterator(); for i_101194.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101194.Next__O()); t.Impl_ImplPut_O_O__O(this, e.GetKey__O(), e.GetValue__O())
	} }
func (t *Provider) Impl_ImplRemove_O__O(this Provider_I, key any) any {
	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_Remove_O__O(this, key); var tmp1 any = o
		if String_InstanceOf(tmp1) { var so *String = String_Cast(tmp1); var tmp2 any = key
			if String_InstanceOf(tmp2) { var sk *String = String_Cast(tmp2); var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_REMOVE; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, so, tmp3) } else { } } else { }
//line :276:1
		return o
	}
}


func (t *Provider) Impl_ImplRemove_O_O__Z(this Provider_I, key, value any) bool {
	if !Provider_CheckLegacy_O__Z(key) { return false } else {

		var result bool = t.Properties.Impl_Remove_O_O__Z(this, key, value)
		if result {
			var tmp1 any = key; if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1); var tmp2 any = value
				if String_InstanceOf(tmp2) { var sv *String = String_Cast(tmp2); var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_REMOVE; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, sv, tmp3) } else { } } else { } }
//line :284:1
		return result
	}
}



func (t *Provider) Impl_ImplReplace_O_O_O__Z(this Provider_I, key, oldValue, newValue any) bool {
	if !Provider_CheckLegacy_O__Z(key) { return false } else {

		var result bool = t.Properties.Impl_Replace_O_O_O__Z(this, key, oldValue, newValue)
		if result {
			var tmp1 any = key; if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1); var tmp2 any = newValue
				if String_InstanceOf(tmp2) { var sv *String = String_Cast(tmp2); var tmp3 *Provider_OPType
					Provider_OPType_Init(); tmp3 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, sv, tmp3) } else {
						var tmp4 any = oldValue; if String_InstanceOf(tmp4) { var sv_2 *String = String_Cast(tmp4); var tmp5 *Provider_OPType; Provider_OPType_Init(); tmp5 = Provider_OPType_REMOVE; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, sv_2, tmp5) } else { } } } else { } }
//line :293:1
		return result
	}
}





func (t *Provider) Impl_ImplReplace_O_O__O(this Provider_I, key, value any) any {
	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_Replace_O_O__O(this, key, value); var tmp1 any = key
		if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1); var tmp2 any = o
			if String_InstanceOf(tmp2) { var so *String = String_Cast(tmp2); var tmp3 any = value
				if String_InstanceOf(tmp3) { var sv *String = String_Cast(tmp3); var tmp4 *Provider_OPType
					Provider_OPType_Init(); tmp4 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, sv, tmp4) } else {
						var tmp5 *Provider_OPType; Provider_OPType_Init(); tmp5 = Provider_OPType_REMOVE; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, so, tmp5) } } else { } } else { }
//line :303:1
		return o
	}
}





func (t *Provider) Impl_ImplReplaceAll_BiFunction__V(this Provider_I, function BiFunction) {

	t.Properties.Impl_ReplaceAll_BiFunction__V(this, function)
	t.F_legacyMap.Clear__V()
	t.F_legacyChanged.Store(true)
	var i_101205 Iterator = t.Properties.Impl_EntrySet__Set(this).Iterator__Iterator(); for i_101205.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101205.Next__O()); var key any = entry.GetKey__O(); var value any = entry.GetValue__O()
		var tmp1 any = key

		if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1); var tmp2 any = value
			if String_InstanceOf(tmp2) { var sv *String = String_Cast(tmp2)
				if !Provider_CheckLegacy_O__Z(sk.Ref()) { } else { var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, sv, tmp3) } } else { } } else {
				} } }
func (t *Provider) Impl_ImplMerge_O_O_BiFunction__O(this Provider_I, key, value any, remappingFunction BiFunction) any {

	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_Merge_O_O_BiFunction__O(this, key, value, remappingFunction); var tmp1 any = key
		if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1)
			if o == nil {
				var tmp2 *Provider_OPType; Provider_OPType_Init(); tmp2 = Provider_OPType_REMOVE; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, nil, tmp2) } else {
					var tmp3 any = o; if String_InstanceOf(tmp3) { var so *String = String_Cast(tmp3); var tmp4 *Provider_OPType; Provider_OPType_Init(); tmp4 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, so, tmp4) } else { } } } else { }
//line :326:1
		return o
	}
}




func (t *Provider) Impl_ImplCompute_O_BiFunction__O(this Provider_I, key any, remappingFunction BiFunction) any {

	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_Compute_O_BiFunction__O(this, key, remappingFunction); var tmp1 any = key
		if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1)
			if o == nil {
				var tmp2 *Provider_OPType; Provider_OPType_Init(); tmp2 = Provider_OPType_REMOVE; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, nil, tmp2) } else {
					var tmp3 any = o; if String_InstanceOf(tmp3) { var so *String = String_Cast(tmp3); var tmp4 *Provider_OPType; Provider_OPType_Init(); tmp4 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, so, tmp4) } else { } } } else { }
//line :336:1
		return o
	}
}




func (t *Provider) Impl_ImplComputeIfAbsent_O_Function__O(this Provider_I, key any, mappingFunction Function) any {

	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_ComputeIfAbsent_O_Function__O(this, key, mappingFunction); var tmp1 any = o
		if String_InstanceOf(tmp1) { var so *String = String_Cast(tmp1); var tmp2 any = key
			if String_InstanceOf(tmp2) { var sk *String = String_Cast(tmp2); var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, so, tmp3) } else { } } else { }
//line :346:1
		return o
	}
}


func (t *Provider) Impl_ImplComputeIfPresent_O_BiFunction__O(this Provider_I, key any, remappingFunction BiFunction) any {

	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_ComputeIfPresent_O_BiFunction__O(this, key, remappingFunction); var tmp1 any = o
		if String_InstanceOf(tmp1) { var so *String = String_Cast(tmp1); var tmp2 any = key
			if String_InstanceOf(tmp2) { var sk *String = String_Cast(tmp2); var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, so, tmp3) } else { } } else { }
//line :354:1
		return o
	}
}


func (t *Provider) Impl_ImplPut_O_O__O(this Provider_I, key, value any) any {
	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_Put_O_O__O(this, key, value); var tmp1 any = key
		if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1); var tmp2 any = value
			if String_InstanceOf(tmp2) { var sv *String = String_Cast(tmp2); var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, sv, tmp3) } else { } } else { }
//line :361:1
		return o
	}
}


func (t *Provider) Impl_ImplPutIfAbsent_O_O__O(this Provider_I, key, value any) any {
	if !Provider_CheckLegacy_O__Z(key) { return nil } else {
		var o any = t.Properties.Impl_PutIfAbsent_O_O__O(this, key, value)
		if o == nil {
			var tmp1 any = key; if String_InstanceOf(tmp1) { var sk *String = String_Cast(tmp1); var tmp2 any = value
				if String_InstanceOf(tmp2) { var sv *String = String_Cast(tmp2); var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_ADD; t.Impl_ParseLegacy_String_String_Provider_OPType__V(this, sk, sv, tmp3) } else { } } else { } }
//line :368:1
		return o
	}
}



func (t *Provider) Impl_ImplClear__V(this Provider_I) {
	t.F_legacyMap.Clear__V()
	t.F_serviceMap.Clear__V()
	t.F_legacyChanged.Store(false)
	t.F_servicesChanged.Store(false)
	t.F_serviceSet.Store(nil)
	t.F_prngAlgos.Clear__V()
	t.Properties.Impl_Clear__V(this)
	t.Impl_PutId__V(this)
}







func Provider_ServiceKey_New_String_String_Z(p0, p1 *String, p2 bool) *Provider_ServiceKey { t := &Provider_ServiceKey{}; t.Ctor_String_String_Z(p0, p1, p2); return t }
//line :391:1
func (t *Provider_ServiceKey) Ctor_String_String_Z(type_, algorithm *String, intern bool) {
	t.F_type = type_
	t.F_originalAlgorithm = algorithm
	var tmp1 *String = algorithm; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ENGLISH; algorithm = NN(tmp1).ToUpperCase_Locale__String(tmp2)
	var tmp3 *String; if intern { tmp3 = NN(algorithm).Intern__String() } else { tmp3 = algorithm }; t.F_algorithm = tmp3
}
func (t *Provider_ServiceKey) HashCode__I() int32 {
	return NN(t.F_type).HashCode__I()*31 + NN(t.F_algorithm).HashCode__I()
}
func (t *Provider_ServiceKey) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if Provider_ServiceKey_InstanceOf(tmp1) { var other *Provider_ServiceKey = Provider_ServiceKey_Cast(tmp1); var tmp2 *String = t.F_type
			if NN(tmp2).Equals_O__Z(other.F_type.Ref()) {
				var tmp3 *String = t.F_algorithm; return NN(tmp3).Equals_O__Z(other.F_algorithm.Ref()) } else {
//line :404:1
					return false } } else {
//line :403:1
						return false
					}
	}
}


func (t *Provider_ServiceKey) Matches_String_String__Z(type_, algorithm *String) bool {
	var tmp1 bool; tmp1 = t.F_type == type_; if tmp1 { tmp1 = t.F_originalAlgorithm == algorithm }; return tmp1
}
func (t *Provider_ServiceKey) ToString__String() *String { return Concat(t.F_type, Lit_79, t.F_algorithm) }

func Provider_GetTypeAndAlgorithm_String__String1(key *String) *RefArray { Provider_Init()
	var i int32 = NN(key).IndexOf_I__I(46)
	if i < 1 {

		if !(Provider_debug == nil) {
			var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(Lit_1609, key)) }
//line :417:1
		return nil
	} else {


		var type_ *String = NN(key).Substring_I_I__String(0, i); var alg *String = NN(key).Substring_I__String(i + 1)

		return RefArrayOf(String_class, type_.Ref(), alg.Ref())
	}
}








func (t *Provider) Impl_ParseLegacy_String_String_Provider_OPType__V(this Provider_I, name, value *String, opType *Provider_OPType) {
	var tmp1 *Locale; Locale_Init(); tmp1 = Locale_ENGLISH; if NN(NN(name).ToLowerCase_Locale__String(tmp1)).StartsWith_String__Z(Lit_1603) {
		var aliasKeyStr *String = NN(name).Substring_I__String(Provider_ALIAS_LENGTH); var typeAndAlg *RefArray = Provider_GetTypeAndAlgorithm_String__String1(aliasKeyStr)

		if !(typeAndAlg == nil) {
			t.F_legacyChanged.Store(true)
			Objects_RequireNonNull_O_String__O(value.Ref(), Lit_1610)
			var type_ *String = Provider_GetEngineName_String__String(As[*String](typeAndAlg.A[0])); var aliasAlg *String = NN(As[*String](typeAndAlg.A[1])).Intern__String(); var stdKey *Provider_ServiceKey = Provider_ServiceKey_New_String_String_Z(type_, value, true); var stdService *Provider_Service = Provider_Service_Cast(t.F_legacyMap.Get_O__O(stdKey.Ref())); var aliasKey *Provider_ServiceKey = Provider_ServiceKey_New_String_String_Z(type_, aliasAlg, true)




			switch NN(opType).F_ordinal { case 0:

				var prevAliasService *Provider_Service = Provider_Service_Cast(t.F_legacyMap.Get_O__O(aliasKey.Ref()))
				if !(prevAliasService == nil) { NN(prevAliasService).RemoveAlias_String__V(aliasAlg) }
				if stdService == nil {
					stdService = Provider_Service_New_Provider_String_String(this, type_, value)
					t.F_legacyMap.Put_O_O__O(stdKey.Ref(), stdService.Ref()) }
				NN(stdService).AddAlias_String__V(aliasAlg)
				t.F_legacyMap.Put_O_O__O(aliasKey.Ref(), stdService.Ref()); case 1:


				if !(stdService == nil) { NN(stdService).RemoveAlias_String__V(aliasAlg) }
				t.F_legacyMap.Remove_O__O(aliasKey.Ref()); default:
				panic(Thrown(AssertionError_New()))} } } else {
					var typeAndAlg_2 *RefArray = Provider_GetTypeAndAlgorithm_String__String1(name)
					if !(typeAndAlg_2 == nil) {
						t.F_legacyChanged.Store(true)
						var i int32 = NN(As[*String](typeAndAlg_2.A[1])).IndexOf_I__I(32)
						if i == -1 {
							var type__2 *String = Provider_GetEngineName_String__String(As[*String](typeAndAlg_2.A[0])); var stdAlg *String = NN(As[*String](typeAndAlg_2.A[1])).Intern__String(); var stdKey_2 *Provider_ServiceKey = Provider_ServiceKey_New_String_String_Z(type__2, stdAlg, true); var stdService_2 *Provider_Service = Provider_Service_Cast(t.F_legacyMap.Get_O__O(stdKey_2.Ref()))



							switch NN(opType).F_ordinal { case 0:


								Objects_RequireNonNull_O_String__O(value.Ref(), Lit_1611)
								if stdService_2 == nil {
									stdService_2 = Provider_Service_New_Provider_String_String(this, type__2, stdAlg)
									t.F_legacyMap.Put_O_O__O(stdKey_2.Ref(), stdService_2.Ref()) }
								stdService_2.F_className = value; case 1:

								if !(stdService_2 == nil) {
									if value == nil {
										t.F_legacyMap.Remove_O__O(stdKey_2.Ref()) } else {
//line :479:1
											if NN(stdService_2.F_className).Equals_O__Z(value.Ref()) {


												t.F_legacyMap.Remove_O_O__Z(stdKey_2.Ref(), stdService_2.Ref()) } }
									var i_101223 Iterator = NN(stdService_2).GetAliases__List().Iterator__Iterator(); for i_101223.HasNext__Z() { var alias *String = String_Cast(i_101223.Next__O()); var tmp2 Map = t.F_legacyMap
										tmp2.Remove_O_O__Z(Provider_ServiceKey_New_String_String_Z(type__2, alias, true), stdService_2.Ref()) } }; default:
								panic(Thrown(AssertionError_New()))}
							var tmp3 *Provider_OPType; Provider_OPType_Init(); tmp3 = Provider_OPType_REMOVE; t.Impl_CheckAndUpdateSecureRandom_String_String_Z__V(this, type__2, stdAlg, !(opType == tmp3)) } else {




								var type__3 *String = Provider_GetEngineName_String__String(As[*String](typeAndAlg_2.A[0])); var attrString *String = As[*String](typeAndAlg_2.A[1]); var stdAlg_2 *String = NN(NN(attrString).Substring_I_I__String(0, i)).Intern__String(); var attrName *String = NN(attrString).Substring_I__String(i + 1)



							L2: for { if NN(attrName).StartsWith_String__Z(Lit_115) { attrName = NN(attrName).Substring_I__String(1); continue L2 }; break L2 }
								attrName = NN(attrName).Intern__String()
								var stdKey_3 *Provider_ServiceKey = Provider_ServiceKey_New_String_String_Z(type__3, stdAlg_2, true); var stdService_3 *Provider_Service = Provider_Service_Cast(t.F_legacyMap.Get_O__O(stdKey_3.Ref()))

								switch NN(opType).F_ordinal { case 0:


									Objects_RequireNonNull_O_String__O(value.Ref(), Lit_1612)
									if stdService_3 == nil {
										stdService_3 = Provider_Service_New_Provider_String_String(this, type__3, stdAlg_2)
										t.F_legacyMap.Put_O_O__O(stdKey_3.Ref(), stdService_3.Ref()) }
									NN(stdService_3).AddAttribute_String_String__V(attrName, value); case 1:

									if !(stdService_3 == nil) { NN(stdService_3).RemoveAttribute_String_String__V(attrName, value) }; default:
									panic(Thrown(AssertionError_New()))
								} } } } }
func (t *Provider) Impl_GetService_String_String__Provider_Service(this Provider_I, type_, algorithm *String) *Provider_Service {
	t.Impl_CheckInitialized__V(this)
	var key *Provider_ServiceKey = Provider_ServiceKey_Cast(Provider_previousKey.Get__O())
	if NN(key).Matches_String_String__Z(type_, algorithm) { } else {
		key = Provider_ServiceKey_New_String_String_Z(type_, algorithm, false)
		Provider_previousKey.Set_O__V(key.Ref()) }
	var s *Provider_Service = Provider_Service_Cast(t.F_serviceMap.Get_O__O(key.Ref()))
	if s == nil {
		s = Provider_Service_Cast(t.F_legacyMap.Get_O__O(key.Ref()))
		var tmp1 bool; var tmp2 bool; tmp2 = !(s == nil); if tmp2 { tmp2 = !NN(s).IsValid__Z() }; tmp1 = tmp2; if tmp1 { t.F_legacyMap.Remove_O_O__Z(key.Ref(), s.Ref()); return nil } }
	var tmp3 bool; var tmp4 bool; tmp4 = !(s == nil); if tmp4 { tmp4 = SecurityProviderServiceEvent_IsTurnedOn__Z() }; tmp3 = tmp4; if tmp3 {
		var e *SecurityProviderServiceEvent = SecurityProviderServiceEvent_New()
		e.F_provider = this.GetName__String()
		e.F_type = type_
		e.F_algorithm = algorithm
		NN(e).Commit__V() }
//line :517:1
	return s
}













func (t *Provider) Impl_GetServices__Set(this Provider_I) Set {
	t.Impl_CheckInitialized__V(this)
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = t.F_serviceSet.Load() == nil; if !tmp3 { tmp3 = t.F_legacyChanged.Load() }; tmp2 = tmp3; if !tmp2 { tmp2 = t.F_servicesChanged.Load() }; tmp1 = tmp2; if tmp1 {
		var set Set = LinkedHashSet_New()
		if t.F_serviceMap.IsEmpty__Z() { } else { set.AddAll_Collection__Z(t.F_serviceMap.Values__Collection()) }
		if t.F_legacyMap.IsEmpty__Z() { } else {
			t.F_legacyMap.EntrySet__Set().ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0 any) { var entry Map_Entry = Map_Entry_Cast(p0); if

				!NN(Provider_Service_Cast(entry.GetValue__O())).IsValid__Z() {
					var tmp4 Map = t.F_legacyMap; tmp4.Remove_O_O__Z(entry.GetKey__O(), entry.GetValue__O()) } else {
						set.Add_O__Z(Provider_Service_Cast(entry.GetValue__O()).Ref()) } }}) }
		t.F_serviceSet.Store(Collections_UnmodifiableSet_Set__Set(set))
		t.F_servicesChanged.Store(false)
		t.F_legacyChanged.Store(false) }
//line :532:1
	return t.F_serviceSet.Load()
}














func (t *Provider) Impl_PutService_Provider_Service__V(this Provider_I, s *Provider_Service) {
	t.Impl_CheckInitialized__V(this)
	if !(Provider_debug == nil) { var tmp1 *Debug = Provider_debug; NN(tmp1).Println_String__V(Concat(t.F_name, Lit_1613, StrOfObj(s.Ref()))) }
	if s == nil { panic(Thrown(NullPointerException_New())) }
	if NN(s).GetProvider__Provider() == this { } else {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1614))) }
	var type_ *String = NN(s).GetType__String(); var algorithm *String = NN(s).GetAlgorithm__String(); var key *Provider_ServiceKey = Provider_ServiceKey_New_String_String_Z(type_, algorithm, true)


	t.Impl_ImplRemoveService_Provider_Service__V(this, Provider_Service_Cast(t.F_serviceMap.Get_O__O(key.Ref())))
	t.F_serviceMap.Put_O_O__O(key.Ref(), s.Ref())
	var i_101228 Iterator = NN(s).GetAliases__List().Iterator__Iterator(); for i_101228.HasNext__Z() { var alias *String = String_Cast(i_101228.Next__O()); var tmp2 Map = t.F_serviceMap; tmp2.Put_O_O__O(Provider_ServiceKey_New_String_String_Z(type_, alias, true), s.Ref()) }
	t.F_servicesChanged.Store(true)
	var tmp3 any = this; MonitorEnter(tmp3); func() { defer MonitorExit(tmp3)
		t.Impl_PutPropertyStrings_Provider_Service__V(this, s)
		t.Impl_CheckAndUpdateSecureRandom_String_String_Z__V(this, type_, algorithm, true)
	}() }
func (t *Provider) Impl_CheckAndUpdateSecureRandom_String_String_Z__V(this Provider_I, type_, algo *String, doAdd bool) {
	if NN(type_).EqualsIgnoreCase_String__Z(Lit_1562) {
		if doAdd { t.F_prngAlgos.Add_O__Z(algo.Ref()) } else { t.F_prngAlgos.Remove_O__Z(algo.Ref()) }
		if !(Provider_debug == nil) {
			var tmp1 *Debug = Provider_debug; var tmp2 *String; if doAdd { tmp2 = Lit_1615 } else { tmp2 = Lit_1616 }; NN(tmp1).Println_String__V(Concat(tmp2, Lit_1617, algo))
		} } }
func (t *Provider) Impl_GetDefaultSecureRandomService__Provider_Service(this Provider_I) *Provider_Service {
	t.Impl_CheckInitialized__V(this)
	if t.F_prngAlgos.IsEmpty__Z() { return nil } else {
		var algo *String = String_Cast(t.F_prngAlgos.Iterator__Iterator().Next__O())
		return this.GetService_String_String__Provider_Service(Lit_1562, algo)
	} }
func (t *Provider) Impl_PutPropertyStrings_Provider_Service__V(this Provider_I, s *Provider_Service) {
	var type_ *String = NN(s).GetType__String(); var algorithm *String = NN(s).GetAlgorithm__String()

	t.Properties.Impl_Put_O_O__O(this, Concat(type_, Lit_79, algorithm), NN(s).GetClassName__String().Ref())
	var i_101229 Iterator = NN(s).GetAliases__List().Iterator__Iterator(); for i_101229.HasNext__Z() { var alias *String = String_Cast(i_101229.Next__O())
		t.Properties.Impl_Put_O_O__O(this, Concat(Lit_1556, type_, Lit_79, alias), algorithm.Ref()) }
	var i_101230 Iterator = s.F_attributes.EntrySet__Set().Iterator__Iterator(); for i_101230.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101230.Next__O()); var key *String = Concat(type_, Lit_79, algorithm, Lit_115, StrOfObj(entry.GetKey__O()))

		t.Properties.Impl_Put_O_O__O(this, key.Ref(), entry.GetValue__O())
	} }
func (t *Provider) Impl_RemovePropertyStrings_Provider_Service__V(this Provider_I, s *Provider_Service) {
	var type_ *String = NN(s).GetType__String(); var algorithm *String = NN(s).GetAlgorithm__String()

	t.Properties.Impl_Remove_O__O(this, Concat(type_, Lit_79, algorithm))
	var i_101231 Iterator = NN(s).GetAliases__List().Iterator__Iterator(); for i_101231.HasNext__Z() { var alias *String = String_Cast(i_101231.Next__O())
		t.Properties.Impl_Remove_O__O(this, Concat(Lit_1556, type_, Lit_79, alias)) }
	var i_101232 Iterator = s.F_attributes.EntrySet__Set().Iterator__Iterator(); for i_101232.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101232.Next__O()); var key *String = Concat(type_, Lit_79, algorithm, Lit_115, StrOfObj(entry.GetKey__O()))
		t.Properties.Impl_Remove_O__O(this, key.Ref())
	} }
func (t *Provider) Impl_RemoveService_Provider_Service__V(this Provider_I, p0 *Provider_Service) { panic(A2g_NotTranslated("java.security.Provider.removeService(Ljava/security/Provider$Service;)V")) }





func (t *Provider) Impl_ImplRemoveService_Provider_Service__V(this Provider_I, s *Provider_Service) {
	var tmp1 bool; var tmp2 bool; tmp2 = s == nil; if !tmp2 { tmp2 = t.F_serviceMap.IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { } else {
		var type_ *String = NN(s).GetType__String(); var algorithm *String = NN(s).GetAlgorithm__String(); var key *Provider_ServiceKey = Provider_ServiceKey_New_String_String_Z(type_, algorithm, false); var oldService *Provider_Service = Provider_Service_Cast(t.F_serviceMap.Get_O__O(key.Ref()))



		if !(s == oldService) { } else {
			t.F_servicesChanged.Store(true)
			t.F_serviceMap.Remove_O__O(key.Ref())
			var i_101233 Iterator = NN(s).GetAliases__List().Iterator__Iterator(); for i_101233.HasNext__Z() { var alias *String = String_Cast(i_101233.Next__O()); var tmp3 Map = t.F_serviceMap
				tmp3.Remove_O__O(Provider_ServiceKey_New_String_String_Z(type_, alias, false)) }
			t.Impl_RemovePropertyStrings_Provider_Service__V(this, s)
			t.Impl_CheckAndUpdateSecureRandom_String_String_Z__V(this, type_, algorithm, false)
		}
	}
}



func Provider_UString_New_String(p0 *String) *Provider_UString { t := &Provider_UString{}; t.Ctor_String(p0); return t }
//line :621:1
func (t *Provider_UString) Ctor_String(s *String) {
	t.F_string = s
	var tmp1 *Locale; Locale_Init(); tmp1 = Locale_ENGLISH; t.F_lowerString = NN(s).ToLowerCase_Locale__String(tmp1)
}
func (t *Provider_UString) HashCode__I() int32 { return NN(t.F_lowerString).HashCode__I() }

func (t *Provider_UString) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if Provider_UString_InstanceOf(tmp1) { var other *Provider_UString = Provider_UString_Cast(tmp1); var tmp2 *String = t.F_lowerString; return NN(tmp2).Equals_O__Z(other.F_lowerString.Ref()) } else { return false
		} } }
func (t *Provider_UString) ToString__String() *String { return t.F_string }








func Provider_EngineDescription_New_String_Z_Class(p0 *String, p1 bool, p2 *Class) *Provider_EngineDescription { t := &Provider_EngineDescription{}; t.Ctor_String_Z_Class(p0, p1, p2); return t }
//line :641:1
func (t *Provider_EngineDescription) Ctor_String_Z_Class(name *String, sp bool, constructorParameterClass *Class) {
	t.F_name = name
	t.F_supportsParameter = sp
	t.F_constructorParameterClass = constructorParameterClass
}


func Provider_AddEngine_String_Z_Class__V(name *String, sp bool, constructorParameterClass *Class) { Provider_Init()

	var ed *Provider_EngineDescription = Provider_EngineDescription_New_String_Z_Class(name, sp, constructorParameterClass); var tmp1 Map = Provider_knownEngines; var tmp2 *Locale
	Locale_Init(); tmp2 = Locale_ENGLISH; tmp1.Put_O_O__O(NN(name).ToLowerCase_Locale__String(tmp2).Ref(), ed.Ref())
	Provider_knownEngines.Put_O_O__O(name.Ref(), ed.Ref())
}




































func Provider_GetEngineName_String__String(s *String) *String { Provider_Init()
	var e *Provider_EngineDescription = Provider_EngineDescription_Cast(Provider_knownEngines.Get_O__O(s.Ref()))
	if e == nil {
		var tmp1 Map = Provider_knownEngines; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ENGLISH; e = Provider_EngineDescription_Cast(tmp1.Get_O__O(NN(s).ToLowerCase_Locale__String(tmp2).Ref())) }
	if e == nil { return s } else { return e.F_name
	}
}




























func Provider_Service_New_Provider_String_String(p0 Provider_I, p1, p2 *String) *Provider_Service { Provider_Service_Init(); t := &Provider_Service{}; t.Ctor_Provider_String_String(p0, p1, p2); return t }
//line :725:1
func (t *Provider_Service) Ctor_Provider_String_String(provider Provider_I, type_, algorithm *String) {
	t.F_provider = provider
	t.F_type = type_
	t.F_algorithm = algorithm
	var tmp1 Map; Provider_Init(); tmp1 = Provider_knownEngines; t.F_engineDescription = Provider_EngineDescription_Cast(tmp1.Get_O__O(type_.Ref()))
	t.F_aliases = Collections_EmptyList__List()
	t.F_attributes = Collections_EmptyMap__Map()
}
func (t *Provider_Service) IsValid__Z() bool {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_type == nil); if tmp2 { tmp2 = !(t.F_algorithm == nil) }; tmp1 = tmp2; if tmp1 { tmp1 = !(t.F_className == nil) }; return tmp1
}
func (t *Provider_Service) AddAlias_String__V(alias *String) {
	if t.F_aliases.IsEmpty__Z() { t.F_aliases = ArrayList_New_I(2) }
	t.F_aliases.Add_O__Z(alias.Ref())
}
func (t *Provider_Service) RemoveAlias_String__V(alias *String) {
	if t.F_aliases.IsEmpty__Z() { } else { t.F_aliases.Remove_O__Z(alias.Ref())
	} }
func (t *Provider_Service) AddAttribute_String_String__V(type_, value *String) {
	if t.F_attributes.IsEmpty__Z() { t.F_attributes = HashMap_New_I(8) }
	var tmp1 Map = t.F_attributes; tmp1.Put_O_O__O(Provider_UString_New_String(type_), value.Ref())
}
func (t *Provider_Service) RemoveAttribute_String_String__V(type_, value *String) {
	if t.F_attributes.IsEmpty__Z() { } else {
		if value == nil {
			var tmp1 Map = t.F_attributes; tmp1.Remove_O__O(Provider_UString_New_String(type_)) } else {
				var tmp2 Map = t.F_attributes; tmp2.Remove_O_O__Z(Provider_UString_New_String(type_), value.Ref())
			} } }
func Provider_Service_New_Provider_String_String_String_List_Map(p0 Provider_I, p1, p2, p3 *String, p4 List, p5 Map) *Provider_Service { Provider_Service_Init(); t := &Provider_Service{}; t.Ctor_Provider_String_String_String_List_Map(p0, p1, p2, p3, p4, p5); return t }
//line :753:1
func (t *Provider_Service) Ctor_Provider_String_String_String_List_Map(provider Provider_I, type_, algorithm, className *String, aliases List, attributes Map) {

	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = provider == nil; if !tmp4 { tmp4 = type_ == nil }; tmp3 = tmp4; if !tmp3 { tmp3 = algorithm == nil }; tmp2 = tmp3; if !tmp2 { tmp2 = className == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NullPointerException_New())) }
	t.F_provider = provider
	t.F_type = Provider_GetEngineName_String__String(type_)
	var tmp5 Map; Provider_Init(); tmp5 = Provider_knownEngines; t.F_engineDescription = Provider_EngineDescription_Cast(tmp5.Get_O__O(type_.Ref()))
	t.F_algorithm = algorithm
	t.F_className = className
	if aliases == nil {
		t.F_aliases = Collections_EmptyList__List() } else {
			t.F_aliases = ArrayList_New_Collection(aliases) }
	if attributes == nil {
		t.F_attributes = Collections_EmptyMap__Map() } else {

			t.F_attributes = HashMap_New()
			var i_101235 Iterator = attributes.EntrySet__Set().Iterator__Iterator(); for i_101235.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101235.Next__O()); var tmp6 Map = t.F_attributes
				tmp6.Put_O_O__O(Provider_UString_New_String(String_Cast(entry.GetKey__O())), String_Cast(entry.GetValue__O()).Ref())
			}
		}
}
func (t *Provider_Service) GetType__String() *String { return t.F_type }

func (t *Provider_Service) GetAlgorithm__String() *String { return t.F_algorithm }

func (t *Provider_Service) GetProvider__Provider() Provider_I { return t.F_provider }

func (t *Provider_Service) GetClassName__String() *String { return t.F_className }

func (t *Provider_Service) GetAliases__List() List { return t.F_aliases }

func (t *Provider_Service) GetAttribute_String__String(name *String) *String {
	if name == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 Map = t.F_attributes; return String_Cast(tmp1.Get_O__O(Provider_UString_New_String(name)))
}
func (t *Provider_Service) NewInstance_O__O(constructorParameter any) any {
	if t.F_registered { } else {
		if t.F_provider.GetService_String_String__Provider_Service(t.F_type, t.F_algorithm) == t { } else {
			panic(Thrown(NoSuchAlgorithmException_New_String(Concat(Lit_1620, t.F_provider.GetName__String(), Lit_1157, StrOfObj(t)))))
		}

		t.F_registered = true }
	var ctrParamClz *Class; var tmp1 any; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var cap_ *Provider_EngineDescription = t.F_engineDescription
			if cap_ == nil {
				var tmp2 *Class
				if !(constructorParameter == nil) { tmp2 = GetClass(constructorParameter) } else { tmp2 = nil }
//line :799:1
				ctrParamClz = tmp2 } else {


					ctrParamClz = cap_.F_constructorParameterClass
					if !(constructorParameter == nil) {
						if ctrParamClz == nil {
							panic(Thrown(InvalidParameterException_New_String(Concat(Lit_1621, t.F_type, Lit_1622)))) } else {

								var argClass *Class = GetClass(constructorParameter)
								if NN(ctrParamClz).IsAssignableFrom_Class__Z(argClass) { } else {
									panic(Thrown(InvalidParameterException_New_String(Concat(Lit_1623, NN(NN(cap_.F_constructorParameterClass).GetName__String()).Replace_C_C__String(36, 46), Lit_1624, t.F_type))))
								}
							}
					}
				}



			tmp1 = t.NewInstanceUtil_Class_O__O(ctrParamClz, constructorParameter) }; return nil }()
//line :796:1
	if tmp3 != nil { if NoSuchAlgorithmException_InstanceOf(tmp3) { var e *NoSuchAlgorithmException = NoSuchAlgorithmException_Cast(tmp3)





















		panic(Thrown(Up_NoSuchAlgorithmException_Throwable(e))) } else if /*line :796:1*/ InvocationTargetException_InstanceOf(tmp3) { var e_2 *InvocationTargetException = InvocationTargetException_Cast(tmp3); var tmp4 *String = t.F_algorithm























			panic(Thrown(NoSuchAlgorithmException_New_String_Throwable(Concat(Lit_1625, tmp4, Lit_1626, t.F_provider.GetName__String(), Lit_1627, t.F_className, Lit_1176), NN(e_2).GetCause__Throwable()))) } else if /*line :796:1*/ Exception_InstanceOf(tmp3) { var e_3 Exception_I = Exception_Cast(tmp3); var tmp5 *String = t.F_algorithm

































				panic(Thrown(NoSuchAlgorithmException_New_String_Throwable(Concat(Lit_1625, tmp5, Lit_1626, t.F_provider.GetName__String(), Lit_1627, t.F_className, Lit_1176), e_3))) } else {
//line :796:1
					panic(tmp3) } }; return tmp1
}










































func (t *Provider_Service) NewInstanceOf__O() any {
	var con *Constructor = t.GetDefaultConstructor__Constructor(); var tmp1 *RefArray; Provider_Init(); tmp1 = Provider_EMPTY; return NN(con).NewInstance_O1__O(tmp1)
}














func (t *Provider_Service) GetImplClass__Class() *Class {
	var tmp1 *Class; tmp6 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var cache any = t.F_classCache; var tmp2 any = cache
			if Class_InstanceOf(tmp2) { var clazz *Class = Class_Cast(tmp2); tmp1 = clazz } else {

				var clazz_2 *Class; var tmp3 any = cache
				if WeakReference_InstanceOf(tmp3) { var ref *WeakReference = WeakReference_Cast(tmp3)
					clazz_2 = Class_Cast(NN(ref).Get__O()) } else { }
				if clazz_2 == nil {
					var cl ClassLoader_I = NN(t.F_provider.GetClass__Class()).GetClassLoader__ClassLoader()
					if cl == nil {
						clazz_2 = Class_ForName_String__Class(t.F_className) } else {
							clazz_2 = cl.LoadClass_String__Class(t.F_className) }
					if Modifier_IsPublic_I__Z(NN(clazz_2).GetModifiers__I()) { } else {
						var tmp4 *String = t.F_type; panic(Thrown(NoSuchAlgorithmException_New_String(Concat(Lit_1628, tmp4, Lit_1629, t.F_provider.GetName__String(), Lit_1630))))
					}




					var tmp5 any; if cl == nil { tmp5 = clazz_2.Ref() } else { tmp5 = WeakReference_New_O(clazz_2.Ref()) }; t.F_classCache = tmp5 }
//line :862:1
				tmp1 = clazz_2
			}
		}












		return nil }()
//line :858:1
	if tmp6 != nil { if ClassNotFoundException_InstanceOf(tmp6) { var e *ClassNotFoundException = ClassNotFoundException_Cast(tmp6); var tmp7 *String = t.F_type





















		panic(Thrown(NoSuchAlgorithmException_New_String_Throwable(Concat(Lit_1628, tmp7, Lit_1629, t.F_provider.GetName__String(), Lit_1631), Up_ClassNotFoundException_Throwable(e)))) } else {
//line :858:1
			panic(tmp6) } }; return tmp1
}




























func (t *Provider_Service) GetDefaultConstructor__Constructor() *Constructor {
	var cache any = t.F_constructorCache; var tmp1 any = cache
	if Constructor_InstanceOf(tmp1) { var con *Constructor = Constructor_Cast(tmp1); return con } else {

		var con_2 *Constructor; var tmp2 any = cache
		if WeakReference_InstanceOf(tmp2) { var ref *WeakReference = WeakReference_Cast(tmp2)
			con_2 = Constructor_Cast(NN(ref).Get__O()) } else { }
		if con_2 == nil {
			var clazz *Class = t.GetImplClass__Class()
			con_2 = NN(clazz).GetConstructor_Class1__Constructor(RefArrayOf(Class_class))
			var tmp3 any
			if NN(clazz).GetClassLoader__ClassLoader() == nil { tmp3 = con_2.Ref() } else { tmp3 = WeakReference_New_O(con_2.Ref()) }
//line :898:1
			t.F_constructorCache = tmp3 }
//line :892:1
		return con_2
	}
}







func (t *Provider_Service) SupportsParameter_O__Z(parameter any) bool {
	var cap_ *Provider_EngineDescription = t.F_engineDescription
	if cap_ == nil { return true } else {


		if cap_.F_supportsParameter { } else {
			panic(Thrown(InvalidParameterException_New_String(Concat(Lit_1632, t.F_type, Lit_1622))))
		}
		var tmp1 bool; var tmp2 bool; tmp2 = !(parameter == nil); if tmp2 { tmp2 = !Key_InstanceOf(parameter) }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(InvalidParameterException_New_String(Concat(Lit_1633, t.F_type))))
		}
		if !t.HasKeyAttributes__Z() { return true } else { if parameter == nil { return false } else {



			var key Key = Key_Cast(parameter)
			if t.SupportsKeyFormat_Key__Z(key) { return true } else { return t.SupportsKeyClass_Key__Z(key)
			} } } } }
func (t *Provider_Service) HasKeyAttributes__Z() bool {
	var b *Boolean = t.F_hasKeyAttributes.Load()
	if b == nil {
		var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
			b = t.F_hasKeyAttributes.Load()
			if b == nil {
				var s *String
				s = t.GetAttribute_String__String(Lit_31)
				if !(s == nil) { t.F_supportedFormats = NN(s).Split_String__String1(Lit_1429) }
				s = t.GetAttribute_String__String(Lit_1634)
				if !(s == nil) {
					var classNames *RefArray = NN(s).Split_String__String1(Lit_1429); var classList List = ArrayList_New_I(int32(len(classNames.A))); var arr_101240 *RefArray = classNames; var len_101241 int32 = int32(len(arr_101240.A)); var i_101242 int32 = 0; for ; i_101242 < len_101241; i_101242++ {

						var className *String = As[*String](arr_101240.A[i_101242]); var clazz *Class = t.GetKeyClass_String__Class(className)

						if !(clazz == nil) { classList.Add_O__Z(clazz.Ref()) } }
					t.F_supportedClasses = A2g_CastArray[*RefArray](classList.ToArray_O1__O1(Provider_Service_CLASS0).Ref(), Class_class.ArrayClass()) }
				var tmp2 bool; var tmp3 bool; tmp3 = !(t.F_supportedFormats == nil); if !tmp3 { tmp3 = !(t.F_supportedClasses == nil) }; tmp2 = tmp3; b = Boolean_ValueOf_Z__Boolean(tmp2)
				t.F_hasKeyAttributes.Store(b) } }() }
	return NN(b).BooleanValue__Z()
}
func (t *Provider_Service) GetKeyClass_String__Class(name *String) *Class { tmp1, tmp2, tmp3 := func() (ctl int32, rv *Class, exc Throwable_I) { defer Catch(&exc); return 2, Class_ForName_String__Class(name), nil; return 0, nil, nil }(); if
										tmp3 != nil { if ClassNotFoundException_InstanceOf(tmp3) { var e *ClassNotFoundException = ClassNotFoundException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }}; tmp4, tmp5, tmp6 := func() (ctl int32, rv *Class, exc Throwable_I) { defer Catch(&exc)

		{ var cl ClassLoader_I = NN(t.F_provider.GetClass__Class()).GetClassLoader__ClassLoader()
			if !(cl == nil) { return 2, cl.LoadClass_String__Class(name), nil } }; return 0, nil, nil }(); if /*line :943:1*/ tmp6 != nil { if ClassNotFoundException_InstanceOf(tmp6) { var e_2 *ClassNotFoundException = ClassNotFoundException_Cast(tmp6); _ = e_2 } else { panic(tmp6) } }; switch tmp4 { case 2: { return tmp5 }}; return nil }





func (t *Provider_Service) SupportsKeyFormat_Key__Z(key Key) bool {
	if t.F_supportedFormats == nil { return false } else {

		var format *String = key.GetFormat__String()
		if format == nil { return false } else {


			var arr_101243 *RefArray = t.F_supportedFormats; var len_101244 int32 = int32(len(arr_101243.A)); var i_101245 int32 = 0; for ; i_101245 < len_101244; i_101245++ { var supportedFormat *String = As[*String](arr_101243.A[i_101245])
				if NN(supportedFormat).Equals_O__Z(format.Ref()) { return true } }
//line :955:1
			return false
		}
	}
}

func (t *Provider_Service) SupportsKeyClass_Key__Z(key Key) bool {
	if t.F_supportedClasses == nil { return false } else {

		var keyClass *Class = key.GetClass__Class(); var arr_101246 *RefArray = t.F_supportedClasses; var len_101247 int32 = int32(len(arr_101246.A)); var i_101248 int32 = 0; for ; i_101248 < len_101247; i_101248++ {
			var clazz *Class = As[*Class](arr_101246.A[i_101248])
			if NN(clazz).IsAssignableFrom_Class__Z(keyClass) { return true } }
//line :963:1
		return false
	}
}


func (t *Provider_Service) ToString__String() *String {
	var aString *String; if t.F_aliases.IsEmpty__Z() { aString = Lit_69 } else {

		aString = Concat(Lit_1635, t.F_aliases.ToString__String()) }
//line :969:1
	var attrs *String


	if t.F_attributes.IsEmpty__Z() { attrs = Lit_69 } else {

		attrs = Concat(Lit_1636, t.F_attributes.ToString__String()) }
	return Concat(t.F_provider.GetName__String(), Lit_1157, t.F_type, Lit_79, t.F_algorithm, Lit_1495, t.F_className, aString, attrs, Lit_1637) }
//line :975:1
type Provider struct{ Properties; F_name, F_info *String; F_version float64; F_versionStr *String; F_entrySet Set; F_entrySetCallCount int32; F_initialized bool; F_legacyChanged, F_servicesChanged atomic.Bool; F_serviceMap Map; F_prngAlgos Set; F_legacyMap Map; F_serviceSet Volatile[Set] }

type Provider_I interface{ Properties_I; Map; Cloneable; Serializable; Self_Provider() *Provider; Configure_String__Provider(p0 *String) Provider_I; IsConfigured__Z() bool; GetName__String() *String; GetVersion__D() float64; GetVersionStr__String() *String; GetInfo__String() *String; Clear__V(); Load_InputStream__V(p0 InputStream_I); PutAll_Map__V(p0 Map); EntrySet__Set() Set; KeySet__Set() Set; Values__Collection() Collection; Put_O_O__O(p0, p1 any) any; PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ReplaceAll_BiFunction__V(p0 BiFunction); Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any; Get_O__O(p0 any) any; GetOrDefault_O_O__O(p0, p1 any) any; ForEach_BiConsumer__V(p0 BiConsumer); Keys__Enumeration() Enumeration; Elements__Enumeration() Enumeration; GetProperty_String__String(p0 *String) *String; GetService_String_String__Provider_Service(p0, p1 *String) *Provider_Service; GetServices__Set() Set; PutService_Provider_Service__V(p0 *Provider_Service); GetDefaultSecureRandomService__Provider_Service() *Provider_Service; RemoveService_Provider_Service__V(p0 *Provider_Service) }

func (t *Provider) Self_Provider() *Provider { return t }

const Provider_serialVersionUID int64 = -4298000515446427739

var Provider_debug *Debug

var Provider_EMPTY *RefArray

var Provider_ALIAS_PREFIX *String = Lit_1556

var Provider_ALIAS_PREFIX_LOWER *String = Lit_1603

var Provider_ALIAS_LENGTH int32

var Provider_previousKey ThreadLocal_I

var Provider_knownEngines Map

var Provider_init ClassInit

func Provider_Init() { if !Provider_init.Done() { Provider_init.Run(Provider_clinit) } }

func Provider_clinit() { Properties_Init(); Provider_debug = Debug_GetInstance_String_String__Debug(Lit_1533, Lit_1534); Provider_EMPTY = NewRefArray(Object_class, 0); Provider_ALIAS_LENGTH = Lit_1556.Length__I(); Provider_previousKey = ThreadLocal_WithInitial_Supplier__ThreadLocal(&Supplier_Fn{Fn: func() any { return Provider_ServiceKey_New_String_String_Z(Lit_69, Lit_69, false).Ref() }})
//line :20:1
	Provider_knownEngines = HashMap_New()
	Provider_AddEngine_String_Z_Class__V(Lit_1557, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1558, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1559, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1560, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1561, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1538, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1562, false, SecureRandomParameters_class)
	Provider_AddEngine_String_Z_Class__V(Lit_1563, true, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1564, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1565, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1566, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1567, false, CertStoreParameters_class)
	Provider_AddEngine_String_Z_Class__V(Lit_1568, true, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1569, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_33, true, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1570, true, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1571, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1572, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1573, true, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1574, false, KDFParameters_class)
	Provider_AddEngine_String_Z_Class__V(Lit_1575, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1576, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1577, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1578, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1579, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1580, false, nil)

	Provider_AddEngine_String_Z_Class__V(Lit_1581, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1582, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1583, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1584, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1585, false, nil)
	Provider_AddEngine_String_Z_Class__V(Lit_1586, false, Object_class)
}




















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func Provider_InstanceOf(x any) bool { _, ok := x.(Provider_I); return ok }

func Provider_Cast(x any) Provider_I { if x == nil { return nil }; v, ok := x.(Provider_I); if !ok { panic(ClassCast(x, Provider_class)) }; return v }



type Provider_EngineDescription struct{ Object; F_name *String; F_supportsParameter bool; F_constructorParameterClass *Class }

func (t *Provider_EngineDescription) Ref() any { if t == nil { return nil }; return t }

func (t *Provider_EngineDescription) GetClass__Class() *Class { return Provider_EngineDescription_class }

func (t *Provider_EngineDescription) ToString__String() *String { return Object_toString(t) }

func (t *Provider_EngineDescription) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Provider_EngineDescription) CloneShallow() any { panic(CloneNotSupported(t)) }

func Provider_EngineDescription_InstanceOf(x any) bool { _, ok := x.(*Provider_EngineDescription); return ok }

func Provider_EngineDescription_Cast(x any) *Provider_EngineDescription { if x == nil { return nil }; v, ok := x.(*Provider_EngineDescription); if !ok { panic(ClassCast(x, Provider_EngineDescription_class)) }; return v }



type Provider_OPType struct{ Enum }

func (t *Provider_OPType) Is_Constable() {}

var Provider_OPType_ADD *Provider_OPType

var Provider_OPType_REMOVE *Provider_OPType

var Provider_OPType__VALUES *RefArray

var Provider_OPType_init ClassInit

func Provider_OPType_Init() { if !Provider_OPType_init.Done() { Provider_OPType_init.Run(Provider_OPType_clinit) } }

func Provider_OPType_clinit() { Provider_OPType_ADD = Provider_OPType_New_String_I(Lit_1618, 0); Provider_OPType_REMOVE = Provider_OPType_New_String_I(Lit_1619, 1); Provider_OPType__VALUES = Provider_OPType_X_values__Provider_OPType1() }

func Provider_OPType_New_String_I(p0 *String, p1 int32) *Provider_OPType { Provider_OPType_Init(); t := &Provider_OPType{}; t.Ctor_String_I(p0, p1); return t }

func (t *Provider_OPType) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Provider_OPType_Values__Provider_OPType1() *RefArray { Provider_OPType_Init(); return Provider_OPType__VALUES.Copy() }

func Provider_OPType_ValueOf_String__Provider_OPType(p0 *String) *Provider_OPType { Provider_OPType_Init(); return Provider_OPType_Cast(Enum_ValueOf_Class_String__Enum(Provider_OPType_class, p0)) }

func Provider_OPType_X_values__Provider_OPType1() *RefArray { Provider_OPType_Init(); return RefArrayOf(Provider_OPType_class, Provider_OPType_ADD, Provider_OPType_REMOVE) }

func (t *Provider_OPType) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Provider_OPType) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Provider_OPType) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Provider_OPType) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.security.Provider$OPType.describeConstable()Ljava/util/Optional;")) }

func (t *Provider_OPType) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Provider_OPType) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Provider_OPType) Ref() any { if t == nil { return nil }; return t }

func (t *Provider_OPType) GetClass__Class() *Class { return Provider_OPType_class }

func (t *Provider_OPType) CloneShallow() any { panic(CloneNotSupported(t)) }

func Provider_OPType_InstanceOf(x any) bool { _, ok := x.(*Provider_OPType); return ok }

func Provider_OPType_Cast(x any) *Provider_OPType { if x == nil { return nil }; v, ok := x.(*Provider_OPType); if !ok { panic(ClassCast(x, Provider_OPType_class)) }; return v }



type Provider_Service struct{ Object; F_type, F_algorithm, F_className *String; F_provider Provider_I; F_aliases List; F_attributes Map; F_engineDescription *Provider_EngineDescription; F_classCache, F_constructorCache any; F_hasKeyAttributes atomic.Pointer[Boolean]; F_supportedFormats, F_supportedClasses *RefArray; F_registered bool }

var Provider_Service_CLASS0 *RefArray

var Provider_Service_init ClassInit

func Provider_Service_Init() { if !Provider_Service_init.Done() { Provider_Service_init.Run(Provider_Service_clinit) } }

func Provider_Service_clinit() { Provider_Service_CLASS0 = NewRefArray(Class_class, 0) }

func (t *Provider_Service) Ref() any { if t == nil { return nil }; return t }

func (t *Provider_Service) GetClass__Class() *Class { return Provider_Service_class }

func (t *Provider_Service) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Provider_Service) CloneShallow() any { panic(CloneNotSupported(t)) }

func Provider_Service_InstanceOf(x any) bool { _, ok := x.(*Provider_Service); return ok }

func Provider_Service_Cast(x any) *Provider_Service { if x == nil { return nil }; v, ok := x.(*Provider_Service); if !ok { panic(ClassCast(x, Provider_Service_class)) }; return v }



type Provider_ServiceKey struct{ Object; F_type, F_algorithm, F_originalAlgorithm *String }

func (t *Provider_ServiceKey) Ref() any { if t == nil { return nil }; return t }

func (t *Provider_ServiceKey) GetClass__Class() *Class { return Provider_ServiceKey_class }

func (t *Provider_ServiceKey) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Provider_ServiceKey) CloneShallow() any { panic(CloneNotSupported(t)) }

func Provider_ServiceKey_InstanceOf(x any) bool { _, ok := x.(*Provider_ServiceKey); return ok }

func Provider_ServiceKey_Cast(x any) *Provider_ServiceKey { if x == nil { return nil }; v, ok := x.(*Provider_ServiceKey); if !ok { panic(ClassCast(x, Provider_ServiceKey_class)) }; return v }



type Provider_UString struct{ Object; F_string, F_lowerString *String }

func (t *Provider_UString) Ref() any { if t == nil { return nil }; return t }

func (t *Provider_UString) GetClass__Class() *Class { return Provider_UString_class }

func (t *Provider_UString) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Provider_UString) CloneShallow() any { panic(CloneNotSupported(t)) }

func Provider_UString_InstanceOf(x any) bool { _, ok := x.(*Provider_UString); return ok }

func Provider_UString_Cast(x any) *Provider_UString { if x == nil { return nil }; v, ok := x.(*Provider_UString); if !ok { panic(ClassCast(x, Provider_UString_class)) }; return v }
