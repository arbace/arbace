//line java_text_spi_NumberFormatProvider.ae:1
package jrt










func (t *NumberFormatProvider) Ctor(this NumberFormatProvider_I) { t.LocaleServiceProvider.Ctor(this) }









func (t *NumberFormatProvider) Impl_GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(this NumberFormatProvider_I, locale *Locale, formatStyle *NumberFormat_Style) NumberFormat_I {

	panic(Thrown(UnsupportedOperationException_New_String(Concat(Lit_1980, NN(this.GetClass__Class()).GetName__String(), Lit_1981, StrOfObj(locale.Ref()), Lit_1982, StrOfObj(formatStyle.Ref()), Lit_1983))))
}


type NumberFormatProvider struct{ LocaleServiceProvider }

type NumberFormatProvider_I interface{ LocaleServiceProvider_I; Self_NumberFormatProvider() *NumberFormatProvider; GetCurrencyInstance_Locale__NumberFormat(p0 *Locale) NumberFormat_I; GetIntegerInstance_Locale__NumberFormat(p0 *Locale) NumberFormat_I; GetNumberInstance_Locale__NumberFormat(p0 *Locale) NumberFormat_I; GetPercentInstance_Locale__NumberFormat(p0 *Locale) NumberFormat_I; GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(p0 *Locale, p1 *NumberFormat_Style) NumberFormat_I }

func (t *NumberFormatProvider) Self_NumberFormatProvider() *NumberFormatProvider { return t }

func NumberFormatProvider_InstanceOf(x any) bool { _, ok := x.(NumberFormatProvider_I); return ok }

func NumberFormatProvider_Cast(x any) NumberFormatProvider_I { if x == nil { return nil }; v, ok := x.(NumberFormatProvider_I); if !ok { panic(ClassCast(x, NumberFormatProvider_class)) }; return v }
