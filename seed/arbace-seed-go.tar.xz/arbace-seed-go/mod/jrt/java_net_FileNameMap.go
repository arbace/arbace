//line java_net_FileNameMap.ae:1
package jrt






type FileNameMap interface{ Object_I; Is_FileNameMap(); GetContentTypeFor_String__String(p0 *String) *String }

func FileNameMap_InstanceOf(x any) bool { _, ok := x.(FileNameMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FileNameMap_class) } }; return ok }

func FileNameMap_Cast(x any) FileNameMap { if x == nil { return nil }; v, ok := x.(FileNameMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FileNameMap_class) } }; if !ok { panic(ClassCast(x, FileNameMap_class)) }; return v }
