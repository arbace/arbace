//line java_net_SocketTimeoutException.ae:1
package jrt










func SocketTimeoutException_New_String(p0 *String) *SocketTimeoutException { t := &SocketTimeoutException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *SocketTimeoutException) Ctor_String(msg *String) { t.InterruptedIOException.Ctor_String(t, msg) }

func SocketTimeoutException_New() *SocketTimeoutException { t := &SocketTimeoutException{}; t.Ctor(); return t }
//line :14:1
func (t *SocketTimeoutException) Ctor() { t.InterruptedIOException.Ctor(t) }







type SocketTimeoutException struct{ InterruptedIOException }

const SocketTimeoutException_serialVersionUID int64 = -8846654841826352300

func (t *SocketTimeoutException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *SocketTimeoutException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *SocketTimeoutException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *SocketTimeoutException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *SocketTimeoutException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *SocketTimeoutException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *SocketTimeoutException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *SocketTimeoutException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *SocketTimeoutException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *SocketTimeoutException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *SocketTimeoutException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *SocketTimeoutException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *SocketTimeoutException) Ref() any { if t == nil { return nil }; return t }

func (t *SocketTimeoutException) GetClass__Class() *Class { return SocketTimeoutException_class }

func (t *SocketTimeoutException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SocketTimeoutException) CloneShallow() any { panic(CloneNotSupported(t)) }

func SocketTimeoutException_InstanceOf(x any) bool { _, ok := x.(*SocketTimeoutException); return ok }

func SocketTimeoutException_Cast(x any) *SocketTimeoutException { if x == nil { return nil }; v, ok := x.(*SocketTimeoutException); if !ok { panic(ClassCast(x, SocketTimeoutException_class)) }; return v }
