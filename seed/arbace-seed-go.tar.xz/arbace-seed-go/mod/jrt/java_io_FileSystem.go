//line java_io_FileSystem.ae:1
package jrt








func FileSystem_CurrentWorkingDirectoryHolder_CurrentWorkingDirectory__File() *File { FileSystem_CurrentWorkingDirectoryHolder_Init()
	return File_New_String(Lit_79)
}
func FileSystem_GetCWD__File() *File { FileSystem_CurrentWorkingDirectoryHolder_Init(); return FileSystem_CurrentWorkingDirectoryHolder_CURRENT_WORKING_DIRECTORY }


































func (t *FileSystem) Impl_HasBooleanAttributes_File_I__Z(this FileSystem_I, f *File, attributes int32) bool {
	return this.GetBooleanAttributes_File__I(f)&attributes == attributes
}


type FileSystem struct{ Object }

type FileSystem_I interface{ Object_I; Self_FileSystem() *FileSystem; GetSeparator__C() uint16; GetPathSeparator__C() uint16; Normalize_String__String(p0 *String) *String; PrefixLength_String__I(p0 *String) int32; Resolve_String_String__String(p0, p1 *String) *String; GetDefaultParent__String() *String; FromURIPath_String__String(p0 *String) *String; IsAbsolute_File__Z(p0 *File) bool; IsInvalid_File__Z(p0 *File) bool; Resolve_File__String(p0 *File) *String; Canonicalize_String__String(p0 *String) *String; GetBooleanAttributes_File__I(p0 *File) int32; HasBooleanAttributes_File_I__Z(p0 *File, p1 int32) bool; CheckAccess_File_I__Z(p0 *File, p1 int32) bool; SetPermission_File_I_Z_Z__Z(p0 *File, p1 int32, p2, p3 bool) bool; GetLastModifiedTime_File__J(p0 *File) int64; GetLength_File__J(p0 *File) int64; CreateFileExclusively_String__Z(p0 *String) bool; Delete_File__Z(p0 *File) bool; List_File__String1(p0 *File) *RefArray; CreateDirectory_File__Z(p0 *File) bool; Rename_File_File__Z(p0, p1 *File) bool; SetLastModifiedTime_File_J__Z(p0 *File, p1 int64) bool; SetReadOnly_File__Z(p0 *File) bool; ListRoots__File1() *RefArray; GetSpace_File_I__J(p0 *File, p1 int32) int64; GetNameMax_String__I(p0 *String) int32; Compare_File_File__I(p0, p1 *File) int32; HashCode_File__I(p0 *File) int32 }

func (t *FileSystem) Self_FileSystem() *FileSystem { return t }

const FileSystem_BA_EXISTS int32 = 1

const FileSystem_BA_REGULAR int32 = 2

const FileSystem_BA_DIRECTORY int32 = 4

const FileSystem_BA_HIDDEN int32 = 8

const FileSystem_ACCESS_READ int32 = 4

const FileSystem_ACCESS_WRITE int32 = 2

const FileSystem_ACCESS_EXECUTE int32 = 1

const FileSystem_SPACE_TOTAL int32 = 0

const FileSystem_SPACE_FREE int32 = 1

const FileSystem_SPACE_USABLE int32 = 2

func (t *FileSystem) Ctor(this FileSystem_I) {}

func FileSystem_InstanceOf(x any) bool { _, ok := x.(FileSystem_I); return ok }

func FileSystem_Cast(x any) FileSystem_I { if x == nil { return nil }; v, ok := x.(FileSystem_I); if !ok { panic(ClassCast(x, FileSystem_class)) }; return v }



type FileSystem_CurrentWorkingDirectoryHolder struct{ Object }

var FileSystem_CurrentWorkingDirectoryHolder_CURRENT_WORKING_DIRECTORY *File

var FileSystem_CurrentWorkingDirectoryHolder_init ClassInit

func FileSystem_CurrentWorkingDirectoryHolder_Init() { if !FileSystem_CurrentWorkingDirectoryHolder_init.Done() { FileSystem_CurrentWorkingDirectoryHolder_init.Run(FileSystem_CurrentWorkingDirectoryHolder_clinit) } }

func FileSystem_CurrentWorkingDirectoryHolder_clinit() { FileSystem_CurrentWorkingDirectoryHolder_CURRENT_WORKING_DIRECTORY = FileSystem_CurrentWorkingDirectoryHolder_CurrentWorkingDirectory__File() }

func FileSystem_CurrentWorkingDirectoryHolder_New() *FileSystem_CurrentWorkingDirectoryHolder { FileSystem_CurrentWorkingDirectoryHolder_Init(); t := &FileSystem_CurrentWorkingDirectoryHolder{}; t.Ctor(); return t }

func (t *FileSystem_CurrentWorkingDirectoryHolder) Ctor() {}

func (t *FileSystem_CurrentWorkingDirectoryHolder) Ref() any { if t == nil { return nil }; return t }

func (t *FileSystem_CurrentWorkingDirectoryHolder) GetClass__Class() *Class { return FileSystem_CurrentWorkingDirectoryHolder_class }

func (t *FileSystem_CurrentWorkingDirectoryHolder) ToString__String() *String { return Object_toString(t) }

func (t *FileSystem_CurrentWorkingDirectoryHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileSystem_CurrentWorkingDirectoryHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileSystem_CurrentWorkingDirectoryHolder_InstanceOf(x any) bool { _, ok := x.(*FileSystem_CurrentWorkingDirectoryHolder); return ok }

func FileSystem_CurrentWorkingDirectoryHolder_Cast(x any) *FileSystem_CurrentWorkingDirectoryHolder { if x == nil { return nil }; v, ok := x.(*FileSystem_CurrentWorkingDirectoryHolder); if !ok { panic(ClassCast(x, FileSystem_CurrentWorkingDirectoryHolder_class)) }; return v }
