//line java_util_Enumeration.ae:1
package jrt










func Enumeration_AsIterator__Iterator(this Enumeration) Iterator {
	return Enumeration_1_New_Enumeration(this) }
func (t *Enumeration_1) HasNext__Z() bool {
	return t.F_this_0.HasMoreElements__Z()
}
func (t *Enumeration_1) Next__O() any { return t.F_this_0.NextElement__O() }



type Enumeration interface{ Object_I; Is_Enumeration(); HasMoreElements__Z() bool; NextElement__O() any; AsIterator__Iterator() Iterator }

func Enumeration_InstanceOf(x any) bool { _, ok := x.(Enumeration); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Enumeration_class) } }; return ok }

func Enumeration_Cast(x any) Enumeration { if x == nil { return nil }; v, ok := x.(Enumeration); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Enumeration_class) } }; if !ok { panic(ClassCast(x, Enumeration_class)) }; return v }



type Enumeration_1 struct{ Object; F_this_0 Enumeration }

func (t *Enumeration_1) Is_Iterator() {}

func Enumeration_1_New_Enumeration(p0 Enumeration) *Enumeration_1 { t := &Enumeration_1{}; t.Ctor_Enumeration(p0); return t }

func (t *Enumeration_1) Ctor_Enumeration(this_0 Enumeration) { A2g_NotNull[Enumeration](this_0); t.F_this_0 = this_0 }

func (t *Enumeration_1) Remove__V() { Iterator_Remove__V(t) }

func (t *Enumeration_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *Enumeration_1) Ref() any { if t == nil { return nil }; return t }

func (t *Enumeration_1) GetClass__Class() *Class { return Enumeration_1_class }

func (t *Enumeration_1) ToString__String() *String { return Object_toString(t) }

func (t *Enumeration_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Enumeration_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Enumeration_1_InstanceOf(x any) bool { _, ok := x.(*Enumeration_1); return ok }

func Enumeration_1_Cast(x any) *Enumeration_1 { if x == nil { return nil }; v, ok := x.(*Enumeration_1); if !ok { panic(ClassCast(x, Enumeration_1_class)) }; return v }
