//line java_net_URLStreamHandlerFactory.ae:1
package jrt






type URLStreamHandlerFactory interface{ Object_I; Is_URLStreamHandlerFactory(); CreateURLStreamHandler_String__URLStreamHandler(p0 *String) URLStreamHandler_I }

func URLStreamHandlerFactory_InstanceOf(x any) bool { _, ok := x.(URLStreamHandlerFactory); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(URLStreamHandlerFactory_class) } }; return ok }

func URLStreamHandlerFactory_Cast(x any) URLStreamHandlerFactory { if x == nil { return nil }; v, ok := x.(URLStreamHandlerFactory); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(URLStreamHandlerFactory_class) } }; if !ok { panic(ClassCast(x, URLStreamHandlerFactory_class)) }; return v }
