//line java_io_InterruptedIOException.ae:1
package jrt








func InterruptedIOException_New() *InterruptedIOException { t := &InterruptedIOException{}; t.Ctor(t); return t }
//line :10:1
func (t *InterruptedIOException) Ctor(this InterruptedIOException_I) { t.IOException.Ctor(this); t.F_bytesTransferred = 0 }

func InterruptedIOException_New_String(p0 *String) *InterruptedIOException { t := &InterruptedIOException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *InterruptedIOException) Ctor_String(this InterruptedIOException_I, s *String) { t.IOException.Ctor_String(this, s); t.F_bytesTransferred = 0 }







type InterruptedIOException struct{ IOException; F_bytesTransferred int32 }

type InterruptedIOException_I interface{ IOException_I; Serializable; Self_InterruptedIOException() *InterruptedIOException }

func (t *InterruptedIOException) Self_InterruptedIOException() *InterruptedIOException { return t }

const InterruptedIOException_serialVersionUID int64 = 4020568460727500567

func (t *InterruptedIOException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InterruptedIOException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InterruptedIOException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InterruptedIOException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InterruptedIOException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InterruptedIOException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InterruptedIOException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InterruptedIOException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InterruptedIOException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InterruptedIOException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InterruptedIOException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InterruptedIOException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InterruptedIOException) Ref() any { if t == nil { return nil }; return t }

func (t *InterruptedIOException) GetClass__Class() *Class { return InterruptedIOException_class }

func (t *InterruptedIOException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InterruptedIOException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InterruptedIOException_InstanceOf(x any) bool { _, ok := x.(InterruptedIOException_I); return ok }

func InterruptedIOException_Cast(x any) InterruptedIOException_I { if x == nil { return nil }; v, ok := x.(InterruptedIOException_I); if !ok { panic(ClassCast(x, InterruptedIOException_class)) }; return v }
