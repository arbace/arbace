//line java_util_EnumMap.ae:1
package jrt






















func (t *EnumMap_1) HashCode__I() int32 { return 0 }

func (t *EnumMap_1) ToString__String() *String { return Lit_2669 }

func (t *EnumMap) MaskNull_O__O(value any) any { if value == nil { return EnumMap_NULL } else { return value } }

func (t *EnumMap) UnmaskNull_O__O(value any) any {
	if value == EnumMap_NULL { return nil } else { return value
	} }
func EnumMap_New_Class(p0 *Class) *EnumMap { EnumMap_Init(); t := &EnumMap{}; t.Ctor_Class(p0); return t }
//line :33:1
func (t *EnumMap) Ctor_Class(keyType *Class) { t.AbstractMap.Ctor(t); t.F_size = 0
	t.F_keyType = keyType
	t.F_keyUniverse = EnumMap_GetKeyUniverse_Class__Enum1(keyType)
	t.F_vals = NewRefArray(Object_class, int32(len(t.F_keyUniverse.A)))
}
func EnumMap_New_EnumMap(p0 *EnumMap) *EnumMap { EnumMap_Init(); t := &EnumMap{}; t.Ctor_EnumMap(p0); return t }
//line :38:1
func (t *EnumMap) Ctor_EnumMap(m *EnumMap) { t.AbstractMap.Ctor(t); t.F_size = 0
	t.F_keyType = m.F_keyType
	t.F_keyUniverse = m.F_keyUniverse
	t.F_vals = NN(m.F_vals).Copy()
	t.F_size = m.F_size
}
func EnumMap_New_Map(p0 Map) *EnumMap { EnumMap_Init(); t := &EnumMap{}; t.Ctor_Map(p0); return t }
//line :44:1
func (t *EnumMap) Ctor_Map(m Map) { t.AbstractMap.Ctor(t); t.F_size = 0
	if EnumMap_InstanceOf(m) {
		var em *EnumMap = EnumMap_Cast(m)
		t.F_keyType = em.F_keyType
		t.F_keyUniverse = em.F_keyUniverse
		t.F_vals = NN(em.F_vals).Copy()
		t.F_size = em.F_size } else {

			if m.IsEmpty__Z() { panic(Thrown(IllegalArgumentException_New_String(Lit_2667))) }
			t.F_keyType = Enum_Cast(m.KeySet__Set().Iterator__Iterator().Next__O()).GetDeclaringClass__Class()
			t.F_keyUniverse = EnumMap_GetKeyUniverse_Class__Enum1(t.F_keyType)
			t.F_vals = NewRefArray(Object_class, int32(len(t.F_keyUniverse.A)))
			t.PutAll_Map__V(m)
		} }
func (t *EnumMap) Size__I() int32 { return t.F_size }

func (t *EnumMap) ContainsValue_O__Z(value any) bool {
	value = t.MaskNull_O__O(value)
	var arr_101796 *RefArray = t.F_vals; var len_101797 int32 = int32(len(arr_101796.A)); var i_101798 int32 = 0; for ; i_101798 < len_101797; i_101798++ { var val any = arr_101796.A[i_101798]; if Equals(value, val) { return true } }
//line :60:1
	return false
}



func (t *EnumMap) ContainsKey_O__Z(key any) bool {
	var tmp1 bool; tmp1 = t.IsValidKey_O__Z(key); if tmp1 { var tmp2 *RefArray = t.F_vals; tmp1 = !(tmp2.A[Enum_Cast(key).Ordinal__I()] == nil) }; return tmp1
}
func (t *EnumMap) ContainsMapping_O_O__Z(key, value any) bool {
	var tmp1 bool; tmp1 = t.IsValidKey_O__Z(key); if tmp1 {
		var tmp2 *RefArray = t.F_vals; tmp1 = Equals(t.MaskNull_O__O(value), tmp2.A[Enum_Cast(key).Ordinal__I()]) }
//line :69:1
	return tmp1
}

func (t *EnumMap) Get_O__O(key any) any {
	if t.IsValidKey_O__Z(key) { var tmp1 *RefArray = t.F_vals; return t.UnmaskNull_O__O(tmp1.A[Enum_Cast(key).Ordinal__I()]) } else { return nil
	} }
func (t *EnumMap) Put_Enum_O__O(key Enum_I, value any) any {
	t.TypeCheck_Enum__V(key)
	var index int32 = key.Ordinal__I(); var oldValue any = t.F_vals.A[index]; var tmp1 *RefArray = t.F_vals

	tmp1.Store(index, t.MaskNull_O__O(value))
	if oldValue == nil { t.F_size = t.F_size + 1 }
	return t.UnmaskNull_O__O(oldValue)
}
func (t *EnumMap) Remove_O__O(key any) any {
	if !t.IsValidKey_O__Z(key) { return nil } else {
		var index int32 = Enum_Cast(key).Ordinal__I(); var oldValue any = t.F_vals.A[index]

		t.F_vals.Store(index, nil)
		if !(oldValue == nil) { t.F_size = t.F_size - 1 }
		return t.UnmaskNull_O__O(oldValue)
	} }
func (t *EnumMap) RemoveMapping_O_O__Z(key, value any) bool {
	if !t.IsValidKey_O__Z(key) { return false } else {

		var index int32 = Enum_Cast(key).Ordinal__I()
		if Equals(t.MaskNull_O__O(value), t.F_vals.A[index]) {
			t.F_vals.Store(index, nil); t.F_size = t.F_size - 1; return true } else {
//line :95:1
				return false
			}
	}
}
func (t *EnumMap) IsValidKey_O__Z(key any) bool {
	if key == nil { return false } else {

		var keyClass *Class = GetClass(key); var tmp1 bool
		tmp1 = keyClass == t.F_keyType; if !tmp1 { tmp1 = NN(keyClass).GetSuperclass__Class() == t.F_keyType }; return tmp1
	} }
func (t *EnumMap) PutAll_Map__V(m Map) {
	var tmp1 Map = m; if EnumMap_InstanceOf(tmp1) { var em *EnumMap = EnumMap_Cast(tmp1)

		if em.F_keyType == t.F_keyType { } else {
			if NN(em).IsEmpty__Z() { return }
			panic(Thrown(ClassCastException_New_String(Concat(StrOfObj(em.F_keyType.Ref()), Lit_2668, StrOfObj(t.F_keyType.Ref()))))) }
		var i int32 = 0; L1: for {
			if i < int32(len(t.F_keyUniverse.A)) {
				var emValue any = em.F_vals.A[i]
				if !(emValue == nil) {

					if t.F_vals.A[i] == nil { t.F_size = t.F_size + 1 }
					t.F_vals.Store(i, emValue)
					i = i + 1; continue L1 } else {
						i = i + 1; continue L1 } }
//line :111:1
			break L1
		}





	} else {

		t.AbstractMap.Impl_PutAll_Map__V(t, m)
	} }
func (t *EnumMap) Clear__V() {
	Arrays_Fill_O1_O__V(t.F_vals, nil)
	t.F_size = 0
}


func (t *EnumMap) KeySet__Set() Set {
	var ks Set = t.F_keySet
	if ks == nil { ks = EnumMap_KeySet_New_EnumMap(t); t.F_keySet = ks }
//line :129:1
	return ks
}





func (t *EnumMap_KeySet) Iterator__Iterator() Iterator { return EnumMap_KeyIterator_New_EnumMap(t.F_this_0) }

func (t *EnumMap_KeySet) Size__I() int32 { return t.F_this_0.F_size }

func (t *EnumMap_KeySet) Contains_O__Z(o any) bool {
	return NN(t.F_this_0).ContainsKey_O__Z(o)
}
func (t *EnumMap_KeySet) Remove_O__Z(o any) bool {
	var oldSize int32 = t.F_this_0.F_size; NN(t.F_this_0).Remove_O__O(o); return !(t.F_this_0.F_size == oldSize)
}
func (t *EnumMap_KeySet) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *EnumMap) Values__Collection() Collection {
	var vs Collection = t.F_values
	if vs == nil { vs = EnumMap_Values_New_EnumMap(t); t.F_values = vs }
//line :149:1
	return vs
}





func (t *EnumMap_Values) Iterator__Iterator() Iterator { return EnumMap_ValueIterator_New_EnumMap(t.F_this_0) }

func (t *EnumMap_Values) Size__I() int32 { return t.F_this_0.F_size }

func (t *EnumMap_Values) Contains_O__Z(o any) bool {
	return NN(t.F_this_0).ContainsValue_O__Z(o)
}
func (t *EnumMap_Values) Remove_O__Z(o any) bool {
	o = NN(t.F_this_0).MaskNull_O__O(o)
	var i int32 = 0; L1: for {
		if i < int32(len(t.F_this_0.F_vals.A)) {
			if Equals(o, t.F_this_0.F_vals.A[i]) {
				t.F_this_0.F_vals.Store(i, nil); t.F_this_0.F_size = t.F_this_0.F_size - 1; return true } else {
					i = i + 1; continue L1 } }
//line :165:1
		break L1 }
//line :163:1
	return false
}








func (t *EnumMap_Values) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *EnumMap) EntrySet__Set() Set {
	var es Set = t.F_entrySet; if !(es == nil) { return es } else { var tmp1 Set = EnumMap_EntrySet_New_EnumMap(t); t.F_entrySet = tmp1; return tmp1
	}
}


func (t *EnumMap_EntrySet) Iterator__Iterator() Iterator {
	return EnumMap_EntryIterator_New_EnumMap(t.F_this_0)
}
func (t *EnumMap_EntrySet) Contains_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var entry Map_Entry = Map_Entry_Cast(tmp1)
		return NN(t.F_this_0).ContainsMapping_O_O__Z(entry.GetKey__O(), entry.GetValue__O()) } else {
//line :185:1
			return false
		}
}

func (t *EnumMap_EntrySet) Remove_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var entry Map_Entry = Map_Entry_Cast(tmp1)
		return NN(t.F_this_0).RemoveMapping_O_O__Z(entry.GetKey__O(), entry.GetValue__O()) } else {
//line :190:1
			return false
		}
}

func (t *EnumMap_EntrySet) Size__I() int32 { return t.F_this_0.F_size }

func (t *EnumMap_EntrySet) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *EnumMap_EntrySet) ToArray__O1() *RefArray {
	return t.FillEntryArray_O1__O1(NewRefArray(Object_class, t.F_this_0.F_size))
}
func (t *EnumMap_EntrySet) ToArray_O1__O1(a *RefArray) *RefArray {
	var size int32 = t.Size__I()
	if int32(len(a.A)) < size {
		a = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass()) }
	if int32(len(a.A)) > size { a.Store(size, nil) }
	return t.FillEntryArray_O1__O1(a)
}
func (t *EnumMap_EntrySet) FillEntryArray_O1__O1(a *RefArray) *RefArray {
	var j int32 = 0; var i int32 = 0
L1: for {
	if i < int32(len(t.F_this_0.F_vals.A)) {
		if !(t.F_this_0.F_vals.A[i] == nil) {

			var tmp1 any = As[Enum_I](t.F_this_0.F_keyUniverse.A[i]); a.Store(j, AbstractMap_SimpleEntry_New_O_O(tmp1, NN(t.F_this_0).UnmaskNull_O__O(t.F_this_0.F_vals.A[i])))




			j = j + 1
			i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :210:1
	break L1 }
//line :209:1
	return a
}






















func (t *EnumMap_EnumMapIterator) Impl_HasNext__Z(this EnumMap_EnumMapIterator_I) bool {
L1: for { var tmp1 bool; var tmp2 bool; var tmp3 int32 = t.F_index; tmp2 = tmp3 < int32(len(t.F_this_0.F_vals.A)); if tmp2 { tmp2 = t.F_this_0.F_vals.A[t.F_index] == nil }; tmp1 = tmp2; if tmp1 {
	t.F_index = t.F_index + 1
//line :234:1
	continue L1 }; break L1
}
	var tmp4 int32 = t.F_index; return !(tmp4 == int32(len(t.F_this_0.F_vals.A)))
}
func (t *EnumMap_EnumMapIterator) Impl_Remove__V(this EnumMap_EnumMapIterator_I) {
	t.Impl_CheckLastReturnedIndex__V(this)
	if !(t.F_this_0.F_vals.A[t.F_lastReturnedIndex] == nil) {
		t.F_this_0.F_vals.Store(t.F_lastReturnedIndex, nil)
		t.F_this_0.F_size = t.F_this_0.F_size - 1 }
	t.F_lastReturnedIndex = -1
}
func (t *EnumMap_EnumMapIterator) Impl_CheckLastReturnedIndex__V(this EnumMap_EnumMapIterator_I) {
	if t.F_lastReturnedIndex < 0 { panic(Thrown(IllegalStateException_New()))
	}
}


func (t *EnumMap_KeyIterator) Next__Enum() Enum_I {
	if t.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	var tmp1 int32; var old_1 int32 = t.F_index

	t.F_index = t.F_index + 1
//line :254:1
	tmp1 = old_1
//line :253:1
	t.F_lastReturnedIndex = tmp1



	return As[Enum_I](t.F_this_0.F_keyUniverse.A[t.F_lastReturnedIndex])
}



func (t *EnumMap_ValueIterator) Next__O() any {
	if t.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	var tmp1 int32; var old_2 int32 = t.F_index

	t.F_index = t.F_index + 1
//line :265:1
	tmp1 = old_2
//line :264:1
	t.F_lastReturnedIndex = tmp1



	return NN(t.F_this_0).UnmaskNull_O__O(t.F_this_0.F_vals.A[t.F_lastReturnedIndex])
}





func (t *EnumMap_EntryIterator) Next__Map_Entry() Map_Entry {
	if t.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	var tmp1 int32; var old_3 int32 = t.F_index

	t.F_index = t.F_index + 1
//line :278:1
	tmp1 = old_3
//line :277:1
	t.F_lastReturnedEntry = EnumMap_EntryIterator_Entry_New_EnumMap_EntryIterator_I(t, tmp1)
//line :275:1
	return Up_EnumMap_EntryIterator_Entry_Map_Entry(t.F_lastReturnedEntry)
}






func (t *EnumMap_EntryIterator) Remove__V() {
	var tmp1 int32; if t.F_lastReturnedEntry == nil { tmp1 = -1 } else { tmp1 = t.F_lastReturnedEntry.F_index }; t.F_lastReturnedIndex = tmp1
	t.EnumMap_EnumMapIterator.Impl_Remove__V(t)
	t.F_lastReturnedEntry.F_index = t.F_lastReturnedIndex
	t.F_lastReturnedEntry = nil
}





func EnumMap_EntryIterator_Entry_New_EnumMap_EntryIterator_I(p0 *EnumMap_EntryIterator, p1 int32) *EnumMap_EntryIterator_Entry { t := &EnumMap_EntryIterator_Entry{}; t.Ctor_EnumMap_EntryIterator_I(p0, p1); return t }
//line :294:1
func (t *EnumMap_EntryIterator_Entry) Ctor_EnumMap_EntryIterator_I(this_0 *EnumMap_EntryIterator, index int32) { NN(this_0); t.F_this_1 = this_0; t.F_index = index }

func (t *EnumMap_EntryIterator_Entry) GetKey__Enum() Enum_I {
	t.CheckIndexForEntryUse__V()
	return As[Enum_I](t.F_this_1.F_this_0.F_keyUniverse.A[t.F_index])
}
func (t *EnumMap_EntryIterator_Entry) GetValue__O() any {
	t.CheckIndexForEntryUse__V()
	return NN(t.F_this_1.F_this_0).UnmaskNull_O__O(t.F_this_1.F_this_0.F_vals.A[t.F_index])
}
func (t *EnumMap_EntryIterator_Entry) SetValue_O__O(value any) any {
	t.CheckIndexForEntryUse__V()
	var oldValue any = NN(t.F_this_1.F_this_0).UnmaskNull_O__O(t.F_this_1.F_this_0.F_vals.A[t.F_index]); var tmp1 *RefArray = t.F_this_1.F_this_0.F_vals; var tmp2 int32 = t.F_index
	tmp1.Store(tmp2, NN(t.F_this_1.F_this_0).MaskNull_O__O(value))
//line :306:1
	return oldValue
}


func (t *EnumMap_EntryIterator_Entry) Equals_O__Z(o any) bool {
	if t.F_index < 0 {
		return any(o) == any(t) } else {
			var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var ourValue any = NN(t.F_this_1.F_this_0).UnmaskNull_O__O(t.F_this_1.F_this_0.F_vals.A[t.F_index]); var otherValue any = e.GetValue__O(); var tmp2 bool


				tmp2 = any(e.GetKey__O()) == any(As[Enum_I](t.F_this_1.F_this_0.F_keyUniverse.A[t.F_index])); if tmp2 {
					var tmp3 bool; tmp3 = ourValue == otherValue; if !tmp3 {
						var tmp4 bool; tmp4 = !(ourValue == nil); if tmp4 { tmp4 = Equals(ourValue, otherValue) }; tmp3 = tmp4 }
//line :317:1
					tmp2 = tmp3 }
//line :316:1
				return tmp2
			} else {
//line :313:1
				return false
			}
		}
}




func (t *EnumMap_EntryIterator_Entry) HashCode__I() int32 {
	if t.F_index < 0 { return IdentityHash(t) } else { return NN(t.F_this_1.F_this_0).EntryHashCode_I__I(t.F_index)
	} }
func (t *EnumMap_EntryIterator_Entry) ToString__String() *String {
	if t.F_index < 0 {
		return Object_toString(t) } else {
			var tmp1 Enum_I = As[Enum_I](t.F_this_1.F_this_0.F_keyUniverse.A[t.F_index]); return Concat(StrOfObj(tmp1), Lit_1171, StrOfObj(NN(t.F_this_1.F_this_0).UnmaskNull_O__O(t.F_this_1.F_this_0.F_vals.A[t.F_index])))
		} }
func (t *EnumMap_EntryIterator_Entry) CheckIndexForEntryUse__V() {
	if t.F_index < 0 { panic(Thrown(IllegalStateException_New_String(Lit_2670)))
	} }
func (t *EnumMap) Equals_O__Z(o any) bool {
	if any(t) == any(o) { return true } else { if EnumMap_InstanceOf(o) {

		return t.Equals_EnumMap__Z(EnumMap_Cast(o)) } else {

			var tmp1 any = o; if Map_InstanceOf(tmp1) { var m Map = Map_Cast(tmp1); var tmp2 int32 = t.F_size
				if !(tmp2 == m.Size__I()) { return false } else {


					var i int32 = 0; L1: for {
						if i < int32(len(t.F_keyUniverse.A)) {
							if !(t.F_vals.A[i] == nil) {
								var key Enum_I = As[Enum_I](t.F_keyUniverse.A[i]); var value any = t.UnmaskNull_O__O(t.F_vals.A[i])

								if value == nil {

									var tmp3 bool; var tmp4 bool; tmp4 = m.Get_O__O(key) == nil; if tmp4 { tmp4 = m.ContainsKey_O__Z(key) }; tmp3 = tmp4; if !tmp3 {
										return false } else {
											i = i + 1; continue L1 } } else {
//line :346:1
												if !Equals(value, m.Get_O__O(key)) {




													return false } else {
														i = i + 1; continue L1 } } } else {
															i = i + 1; continue L1 } }
//line :341:1
						break L1 }
//line :340:1
					return true
				}










			} else {
//line :337:1
				return false
			}
		}
	}
}
















func (t *EnumMap) Equals_EnumMap__Z(em *EnumMap) bool {
	if !(em.F_size == t.F_size) { return false } else { if !(em.F_keyType == t.F_keyType) {

		return t.F_size == 0 } else {


			var i int32 = 0; L1: for {
				if i < int32(len(t.F_keyUniverse.A)) {
					var ourValue any = t.F_vals.A[i]; var otherValue any = em.F_vals.A[i]; var tmp1 bool; var tmp2 bool

					tmp2 = !(otherValue == ourValue); if tmp2 {
						var tmp3 bool; tmp3 = otherValue == nil; if !tmp3 { tmp3 = !Equals(otherValue, ourValue) }; tmp2 = tmp3 }
//line :368:1
					tmp1 = tmp2; if tmp1 {

						return false } else {
							i = i + 1; continue L1 } }
//line :364:1
				break L1 }
//line :363:1
			return true
		}
	}
}







func (t *EnumMap) HashCode__I() int32 {
	var h int32 = 0; var i int32 = 0
L1: for {
	if i < int32(len(t.F_keyUniverse.A)) {
		if !(t.F_vals.A[i] == nil) {

			h = h + t.EntryHashCode_I__I(i)
			i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :376:1
	break L1 }
//line :375:1
	return h
}









func (t *EnumMap) EntryHashCode_I__I(index int32) int32 {
	return As[Enum_I](t.F_keyUniverse.A[index]).HashCode__I() ^ HashCode(t.F_vals.A[index])
}
func (t *EnumMap) Clone__EnumMap() *EnumMap {
	var result *EnumMap; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		result = EnumMap_Cast(t.AbstractMap.Impl_Clone__O(t)); return nil }()
//line :391:1
	if tmp1 != nil { if CloneNotSupportedException_InstanceOf(tmp1) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp1); _ = e

		panic(Thrown(AssertionError_New())) } else {
//line :391:1
			panic(tmp1)
		}
	}
	result.F_vals = NN(result.F_vals).Copy()
	result.F_entrySet = nil
//line :390:1
	return result
}






func (t *EnumMap) TypeCheck_Enum__V(key Enum_I) {
	var keyClass *Class = key.GetClass__Class(); var tmp1 bool; var tmp2 bool
	tmp2 = !(keyClass == t.F_keyType); if tmp2 {
		tmp2 = !(NN(keyClass).GetSuperclass__Class() == t.F_keyType) }
//line :400:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(ClassCastException_New_String(Concat(StrOfObj(keyClass.Ref()), Lit_2668, StrOfObj(t.F_keyType.Ref())))))
	} }
func EnumMap_GetKeyUniverse_Class__Enum1(keyType *Class) *RefArray {
	return SharedSecrets_GetJavaLangAccess__JavaLangAccess().GetEnumConstantsShared_Class__Enum1(keyType)
}


type EnumMap struct{ AbstractMap; F_keyType *Class; F_keyUniverse, F_vals *RefArray; F_size int32; F_entrySet Set }

func (t *EnumMap) Is_Serializable() {}

func (t *EnumMap) Is_Cloneable() {}

var EnumMap_NULL any

const EnumMap_serialVersionUID int64 = 458661240069192865

var EnumMap_init ClassInit

func EnumMap_Init() { if !EnumMap_init.Done() { EnumMap_init.Run(EnumMap_clinit) } }

func EnumMap_clinit() { EnumMap_NULL = EnumMap_1_New() }

func (t *EnumMap) Put_O_O__O(p0, p1 any) any { return t.Put_Enum_O__O(Enum_Cast(p0), p1) }

func (t *EnumMap) Clone__O() any { return t.Clone__EnumMap().Ref() }

func (t *EnumMap) Replace_O_O__O(p0, p1 any) any { return Map_Replace_O_O__O(t, p0, p1) }

func (t *EnumMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *EnumMap) Remove_O_O__Z(p0, p1 any) bool { return Map_Remove_O_O__Z(t, p0, p1) }

func (t *EnumMap) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *EnumMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *EnumMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *EnumMap) ReplaceAll_BiFunction__V(p0 BiFunction) { Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *EnumMap) PutIfAbsent_O_O__O(p0, p1 any) any { return Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *EnumMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *EnumMap) ForEach_BiConsumer__V(p0 BiConsumer) { Map_ForEach_BiConsumer__V(t, p0) }

func (t *EnumMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *EnumMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *EnumMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *EnumMap) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap) GetClass__Class() *Class { return EnumMap_class }

func (t *EnumMap) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func EnumMap_InstanceOf(x any) bool { _, ok := x.(*EnumMap); return ok }

func EnumMap_Cast(x any) *EnumMap { if x == nil { return nil }; v, ok := x.(*EnumMap); if !ok { panic(ClassCast(x, EnumMap_class)) }; return v }



type EnumMap_1 struct{ Object }

func EnumMap_1_New() *EnumMap_1 { t := &EnumMap_1{}; t.Ctor(); return t }

func (t *EnumMap_1) Ctor() {}

func (t *EnumMap_1) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_1) GetClass__Class() *Class { return EnumMap_1_class }

func (t *EnumMap_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_1_InstanceOf(x any) bool { _, ok := x.(*EnumMap_1); return ok }

func EnumMap_1_Cast(x any) *EnumMap_1 { if x == nil { return nil }; v, ok := x.(*EnumMap_1); if !ok { panic(ClassCast(x, EnumMap_1_class)) }; return v }



type EnumMap_EntryIterator struct{ EnumMap_EnumMapIterator; F_lastReturnedEntry *EnumMap_EntryIterator_Entry; F_this_0 *EnumMap }

func EnumMap_EntryIterator_New_EnumMap(p0 *EnumMap) *EnumMap_EntryIterator { t := &EnumMap_EntryIterator{}; t.Ctor_EnumMap(p0); return t }

func (t *EnumMap_EntryIterator) Ctor_EnumMap(this_0 *EnumMap) { NN(this_0); t.F_this_0 = this_0; t.EnumMap_EnumMapIterator.Ctor_EnumMap(t, this_0) }

func (t *EnumMap_EntryIterator) Next__O() any { return t.Next__Map_Entry() }

func (t *EnumMap_EntryIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *EnumMap_EntryIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *EnumMap_EntryIterator) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_EntryIterator) GetClass__Class() *Class { return EnumMap_EntryIterator_class }

func (t *EnumMap_EntryIterator) ToString__String() *String { return Object_toString(t) }

func (t *EnumMap_EntryIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_EntryIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_EntryIterator_InstanceOf(x any) bool { _, ok := x.(*EnumMap_EntryIterator); return ok }

func EnumMap_EntryIterator_Cast(x any) *EnumMap_EntryIterator { if x == nil { return nil }; v, ok := x.(*EnumMap_EntryIterator); if !ok { panic(ClassCast(x, EnumMap_EntryIterator_class)) }; return v }



type EnumMap_EntryIterator_Entry struct{ Object; F_index int32; F_this_1 *EnumMap_EntryIterator }

func (t *EnumMap_EntryIterator_Entry) Is_Map_Entry() {}

func (t *EnumMap_EntryIterator_Entry) GetKey__O() any { return t.GetKey__Enum() }

func (t *EnumMap_EntryIterator_Entry) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_EntryIterator_Entry) GetClass__Class() *Class { return EnumMap_EntryIterator_Entry_class }

func (t *EnumMap_EntryIterator_Entry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_EntryIterator_Entry) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_EntryIterator_Entry_InstanceOf(x any) bool { _, ok := x.(*EnumMap_EntryIterator_Entry); return ok }

func EnumMap_EntryIterator_Entry_Cast(x any) *EnumMap_EntryIterator_Entry { if x == nil { return nil }; v, ok := x.(*EnumMap_EntryIterator_Entry); if !ok { panic(ClassCast(x, EnumMap_EntryIterator_Entry_class)) }; return v }



type EnumMap_EntrySet struct{ AbstractSet; F_this_0 *EnumMap }

func EnumMap_EntrySet_New_EnumMap(p0 *EnumMap) *EnumMap_EntrySet { t := &EnumMap_EntrySet{}; t.Ctor_EnumMap(p0); return t }

func (t *EnumMap_EntrySet) Ctor_EnumMap(this_0 *EnumMap) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *EnumMap_EntrySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *EnumMap_EntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *EnumMap_EntrySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *EnumMap_EntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *EnumMap_EntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *EnumMap_EntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *EnumMap_EntrySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *EnumMap_EntrySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *EnumMap_EntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *EnumMap_EntrySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *EnumMap_EntrySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *EnumMap_EntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *EnumMap_EntrySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *EnumMap_EntrySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *EnumMap_EntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *EnumMap_EntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_EntrySet) GetClass__Class() *Class { return EnumMap_EntrySet_class }

func (t *EnumMap_EntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_EntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_EntrySet_InstanceOf(x any) bool { _, ok := x.(*EnumMap_EntrySet); return ok }

func EnumMap_EntrySet_Cast(x any) *EnumMap_EntrySet { if x == nil { return nil }; v, ok := x.(*EnumMap_EntrySet); if !ok { panic(ClassCast(x, EnumMap_EntrySet_class)) }; return v }



type EnumMap_EnumMapIterator struct{ Object; F_index, F_lastReturnedIndex int32; F_this_0 *EnumMap }

type EnumMap_EnumMapIterator_I interface{ Object_I; Iterator; Self_EnumMap_EnumMapIterator() *EnumMap_EnumMapIterator; HasNext__Z() bool; Remove__V() }

func (t *EnumMap_EnumMapIterator) Self_EnumMap_EnumMapIterator() *EnumMap_EnumMapIterator { return t }

func (t *EnumMap_EnumMapIterator) Is_Iterator() {}

func (t *EnumMap_EnumMapIterator) Ctor_EnumMap(this EnumMap_EnumMapIterator_I, this_0 *EnumMap) { NN(this_0); t.F_this_0 = this_0; t.F_index = 0; t.F_lastReturnedIndex = -1 }

func EnumMap_EnumMapIterator_InstanceOf(x any) bool { _, ok := x.(EnumMap_EnumMapIterator_I); return ok }

func EnumMap_EnumMapIterator_Cast(x any) EnumMap_EnumMapIterator_I { if x == nil { return nil }; v, ok := x.(EnumMap_EnumMapIterator_I); if !ok { panic(ClassCast(x, EnumMap_EnumMapIterator_class)) }; return v }



type EnumMap_KeyIterator struct{ EnumMap_EnumMapIterator; F_this_0 *EnumMap }

func EnumMap_KeyIterator_New_EnumMap(p0 *EnumMap) *EnumMap_KeyIterator { t := &EnumMap_KeyIterator{}; t.Ctor_EnumMap(p0); return t }

func (t *EnumMap_KeyIterator) Ctor_EnumMap(this_0 *EnumMap) { NN(this_0); t.F_this_0 = this_0; t.EnumMap_EnumMapIterator.Ctor_EnumMap(t, this_0) }

func (t *EnumMap_KeyIterator) Next__O() any { return t.Next__Enum() }

func (t *EnumMap_KeyIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *EnumMap_KeyIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *EnumMap_KeyIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *EnumMap_KeyIterator) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_KeyIterator) GetClass__Class() *Class { return EnumMap_KeyIterator_class }

func (t *EnumMap_KeyIterator) ToString__String() *String { return Object_toString(t) }

func (t *EnumMap_KeyIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_KeyIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_KeyIterator_InstanceOf(x any) bool { _, ok := x.(*EnumMap_KeyIterator); return ok }

func EnumMap_KeyIterator_Cast(x any) *EnumMap_KeyIterator { if x == nil { return nil }; v, ok := x.(*EnumMap_KeyIterator); if !ok { panic(ClassCast(x, EnumMap_KeyIterator_class)) }; return v }



type EnumMap_KeySet struct{ AbstractSet; F_this_0 *EnumMap }

func EnumMap_KeySet_New_EnumMap(p0 *EnumMap) *EnumMap_KeySet { t := &EnumMap_KeySet{}; t.Ctor_EnumMap(p0); return t }

func (t *EnumMap_KeySet) Ctor_EnumMap(this_0 *EnumMap) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *EnumMap_KeySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *EnumMap_KeySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *EnumMap_KeySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *EnumMap_KeySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *EnumMap_KeySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *EnumMap_KeySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *EnumMap_KeySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *EnumMap_KeySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *EnumMap_KeySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *EnumMap_KeySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *EnumMap_KeySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *EnumMap_KeySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *EnumMap_KeySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *EnumMap_KeySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *EnumMap_KeySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *EnumMap_KeySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *EnumMap_KeySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *EnumMap_KeySet) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_KeySet) GetClass__Class() *Class { return EnumMap_KeySet_class }

func (t *EnumMap_KeySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_KeySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_KeySet_InstanceOf(x any) bool { _, ok := x.(*EnumMap_KeySet); return ok }

func EnumMap_KeySet_Cast(x any) *EnumMap_KeySet { if x == nil { return nil }; v, ok := x.(*EnumMap_KeySet); if !ok { panic(ClassCast(x, EnumMap_KeySet_class)) }; return v }



type EnumMap_ValueIterator struct{ EnumMap_EnumMapIterator; F_this_0 *EnumMap }

func EnumMap_ValueIterator_New_EnumMap(p0 *EnumMap) *EnumMap_ValueIterator { t := &EnumMap_ValueIterator{}; t.Ctor_EnumMap(p0); return t }

func (t *EnumMap_ValueIterator) Ctor_EnumMap(this_0 *EnumMap) { NN(this_0); t.F_this_0 = this_0; t.EnumMap_EnumMapIterator.Ctor_EnumMap(t, this_0) }

func (t *EnumMap_ValueIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *EnumMap_ValueIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *EnumMap_ValueIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *EnumMap_ValueIterator) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_ValueIterator) GetClass__Class() *Class { return EnumMap_ValueIterator_class }

func (t *EnumMap_ValueIterator) ToString__String() *String { return Object_toString(t) }

func (t *EnumMap_ValueIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_ValueIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_ValueIterator_InstanceOf(x any) bool { _, ok := x.(*EnumMap_ValueIterator); return ok }

func EnumMap_ValueIterator_Cast(x any) *EnumMap_ValueIterator { if x == nil { return nil }; v, ok := x.(*EnumMap_ValueIterator); if !ok { panic(ClassCast(x, EnumMap_ValueIterator_class)) }; return v }



type EnumMap_Values struct{ AbstractCollection; F_this_0 *EnumMap }

func EnumMap_Values_New_EnumMap(p0 *EnumMap) *EnumMap_Values { t := &EnumMap_Values{}; t.Ctor_EnumMap(p0); return t }

func (t *EnumMap_Values) Ctor_EnumMap(this_0 *EnumMap) { NN(this_0); t.F_this_0 = this_0; t.AbstractCollection.Ctor(t) }

func (t *EnumMap_Values) Spliterator__Spliterator() Spliterator { return Collection_Spliterator__Spliterator(t) }

func (t *EnumMap_Values) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *EnumMap_Values) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *EnumMap_Values) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *EnumMap_Values) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *EnumMap_Values) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *EnumMap_Values) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *EnumMap_Values) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *EnumMap_Values) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *EnumMap_Values) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *EnumMap_Values) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *EnumMap_Values) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *EnumMap_Values) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *EnumMap_Values) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *EnumMap_Values) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *EnumMap_Values) Ref() any { if t == nil { return nil }; return t }

func (t *EnumMap_Values) GetClass__Class() *Class { return EnumMap_Values_class }

func (t *EnumMap_Values) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumMap_Values) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumMap_Values_InstanceOf(x any) bool { _, ok := x.(*EnumMap_Values); return ok }

func EnumMap_Values_Cast(x any) *EnumMap_Values { if x == nil { return nil }; v, ok := x.(*EnumMap_Values); if !ok { panic(ClassCast(x, EnumMap_Values_class)) }; return v }
