//line java_util_Spliterator.ae:1
package jrt










func Spliterator_ForEachRemaining_Consumer__V(this Spliterator, action Consumer) {
L1: for { if this.TryAdvance_Consumer__Z(action) { continue L1 }; break L1
}
}



func Spliterator_GetExactSizeIfKnown__J(this Spliterator) int64 {
	if this.Characteristics__I()&64 == 0 { return -1 } else { return this.EstimateSize__J()
	}
}

func Spliterator_HasCharacteristics_I__Z(this Spliterator, characteristics int32) bool {
	return this.Characteristics__I()&characteristics == characteristics
}
func Spliterator_GetComparator__Comparator(this Spliterator) Comparator {
	panic(Thrown(IllegalStateException_New()))
}
























func Spliterator_OfPrimitive_ForEachRemaining_O__V(this Spliterator_OfPrimitive, action any) {
L1: for { if this.TryAdvance_O__Z(action) { continue L1 }; break L1
}
}






func Spliterator_OfInt_ForEachRemaining_IntConsumer__V(this Spliterator_OfInt, action IntConsumer) {
L1: for { if this.TryAdvance_IntConsumer__Z(action) { continue L1 }; break L1
} }
func Spliterator_OfInt_TryAdvance_Consumer__Z(this Spliterator_OfInt, action Consumer) bool {
	if IntConsumer_InstanceOf(action) {
		return this.TryAdvance_IntConsumer__Z(IntConsumer_Cast(action)) } else {

			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2866)
			}

			var tmp2 IntConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &IntConsumer_Fn{Fn: func(p0 int32) { tmp3.Accept_O__V(Integer_ValueOf_I__Integer(p0)) }}; return this.TryAdvance_IntConsumer__Z(tmp2)
		} }
func Spliterator_OfInt_ForEachRemaining_Consumer__V(this Spliterator_OfInt, action Consumer) {
	if IntConsumer_InstanceOf(action) {
		this.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(action)) } else {

			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2867)
			}

			var tmp2 IntConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &IntConsumer_Fn{Fn: func(p0 int32) { tmp3.Accept_O__V(Integer_ValueOf_I__Integer(p0)) }}; this.ForEachRemaining_IntConsumer__V(tmp2)
		}
}






func Spliterator_OfLong_ForEachRemaining_LongConsumer__V(this Spliterator_OfLong, action LongConsumer) {
L1: for { if this.TryAdvance_LongConsumer__Z(action) { continue L1 }; break L1
} }
func Spliterator_OfLong_TryAdvance_Consumer__Z(this Spliterator_OfLong, action Consumer) bool {
	if LongConsumer_InstanceOf(action) {
		return this.TryAdvance_LongConsumer__Z(LongConsumer_Cast(action)) } else {

			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2868)
			}

			var tmp2 LongConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &LongConsumer_Fn{Fn: func(p0 int64) { tmp3.Accept_O__V(Long_ValueOf_J__Long(p0)) }}; return this.TryAdvance_LongConsumer__Z(tmp2)
		} }
func Spliterator_OfLong_ForEachRemaining_Consumer__V(this Spliterator_OfLong, action Consumer) {
	if LongConsumer_InstanceOf(action) {
		this.ForEachRemaining_LongConsumer__V(LongConsumer_Cast(action)) } else {

			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2869)
			}

			var tmp2 LongConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &LongConsumer_Fn{Fn: func(p0 int64) { tmp3.Accept_O__V(Long_ValueOf_J__Long(p0)) }}; this.ForEachRemaining_LongConsumer__V(tmp2)
		}
}






func Spliterator_OfDouble_ForEachRemaining_DoubleConsumer__V(this Spliterator_OfDouble, action DoubleConsumer) {
L1: for { if this.TryAdvance_DoubleConsumer__Z(action) { continue L1 }; break L1
} }
func Spliterator_OfDouble_TryAdvance_Consumer__Z(this Spliterator_OfDouble, action Consumer) bool {
	if DoubleConsumer_InstanceOf(action) {
		return this.TryAdvance_DoubleConsumer__Z(DoubleConsumer_Cast(action)) } else {

			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2864)
			}

			var tmp2 DoubleConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &DoubleConsumer_Fn{Fn: func(p0 float64) { tmp3.Accept_O__V(Double_ValueOf_D__Double(p0)) }}; return this.TryAdvance_DoubleConsumer__Z(tmp2)
		} }
func Spliterator_OfDouble_ForEachRemaining_Consumer__V(this Spliterator_OfDouble, action Consumer) {
	if DoubleConsumer_InstanceOf(action) {
		this.ForEachRemaining_DoubleConsumer__V(DoubleConsumer_Cast(action)) } else {

			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2865)
			}

			var tmp2 DoubleConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &DoubleConsumer_Fn{Fn: func(p0 float64) { tmp3.Accept_O__V(Double_ValueOf_D__Double(p0)) }}; this.ForEachRemaining_DoubleConsumer__V(tmp2)
		}
}

type Spliterator interface{ Object_I; Is_Spliterator(); TryAdvance_Consumer__Z(p0 Consumer) bool; ForEachRemaining_Consumer__V(p0 Consumer); TrySplit__Spliterator() Spliterator; EstimateSize__J() int64; GetExactSizeIfKnown__J() int64; Characteristics__I() int32; HasCharacteristics_I__Z(p0 int32) bool; GetComparator__Comparator() Comparator }

const Spliterator_ORDERED int32 = 16

const Spliterator_DISTINCT int32 = 1

const Spliterator_SORTED int32 = 4

const Spliterator_SIZED int32 = 64

const Spliterator_NONNULL int32 = 256

const Spliterator_IMMUTABLE int32 = 1024

const Spliterator_CONCURRENT int32 = 4096

const Spliterator_SUBSIZED int32 = 16384

func Spliterator_InstanceOf(x any) bool { _, ok := x.(Spliterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_class) } }; return ok }

func Spliterator_Cast(x any) Spliterator { if x == nil { return nil }; v, ok := x.(Spliterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_class) } }; if !ok { panic(ClassCast(x, Spliterator_class)) }; return v }



type Spliterator_OfDouble interface{ Object_I; Spliterator_OfPrimitive; Spliterator; Is_Spliterator_OfDouble(); TrySplit__Spliterator_OfDouble() Spliterator_OfDouble; TryAdvance_DoubleConsumer__Z(p0 DoubleConsumer) bool; ForEachRemaining_DoubleConsumer__V(p0 DoubleConsumer); TryAdvance_Consumer__Z(p0 Consumer) bool; ForEachRemaining_Consumer__V(p0 Consumer); TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive; TryAdvance_O__Z(p0 any) bool; ForEachRemaining_O__V(p0 any); TrySplit__Spliterator() Spliterator }

func Spliterator_OfDouble_TrySplit__Spliterator_OfPrimitive(this Spliterator_OfDouble) Spliterator_OfPrimitive { return this.TrySplit__Spliterator_OfDouble() }

func Spliterator_OfDouble_TryAdvance_O__Z(this Spliterator_OfDouble, p0 any) bool { return this.TryAdvance_DoubleConsumer__Z(DoubleConsumer_Cast(p0)) }

func Spliterator_OfDouble_ForEachRemaining_O__V(this Spliterator_OfDouble, p0 any) { this.ForEachRemaining_DoubleConsumer__V(DoubleConsumer_Cast(p0)) }

func Spliterator_OfDouble_TrySplit__Spliterator(this Spliterator_OfDouble) Spliterator { return this.TrySplit__Spliterator_OfDouble() }

func Spliterator_OfDouble_InstanceOf(x any) bool { _, ok := x.(Spliterator_OfDouble); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfDouble_class) } }; return ok }

func Spliterator_OfDouble_Cast(x any) Spliterator_OfDouble { if x == nil { return nil }; v, ok := x.(Spliterator_OfDouble); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfDouble_class) } }; if !ok { panic(ClassCast(x, Spliterator_OfDouble_class)) }; return v }



type Spliterator_OfInt interface{ Object_I; Spliterator_OfPrimitive; Spliterator; Is_Spliterator_OfInt(); TrySplit__Spliterator_OfInt() Spliterator_OfInt; TryAdvance_IntConsumer__Z(p0 IntConsumer) bool; ForEachRemaining_IntConsumer__V(p0 IntConsumer); TryAdvance_Consumer__Z(p0 Consumer) bool; ForEachRemaining_Consumer__V(p0 Consumer); TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive; TryAdvance_O__Z(p0 any) bool; ForEachRemaining_O__V(p0 any); TrySplit__Spliterator() Spliterator }

func Spliterator_OfInt_TrySplit__Spliterator_OfPrimitive(this Spliterator_OfInt) Spliterator_OfPrimitive { return this.TrySplit__Spliterator_OfInt() }

func Spliterator_OfInt_TryAdvance_O__Z(this Spliterator_OfInt, p0 any) bool { return this.TryAdvance_IntConsumer__Z(IntConsumer_Cast(p0)) }

func Spliterator_OfInt_ForEachRemaining_O__V(this Spliterator_OfInt, p0 any) { this.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func Spliterator_OfInt_TrySplit__Spliterator(this Spliterator_OfInt) Spliterator { return this.TrySplit__Spliterator_OfInt() }

func Spliterator_OfInt_InstanceOf(x any) bool { _, ok := x.(Spliterator_OfInt); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfInt_class) } }; return ok }

func Spliterator_OfInt_Cast(x any) Spliterator_OfInt { if x == nil { return nil }; v, ok := x.(Spliterator_OfInt); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfInt_class) } }; if !ok { panic(ClassCast(x, Spliterator_OfInt_class)) }; return v }



type Spliterator_OfLong interface{ Object_I; Spliterator_OfPrimitive; Spliterator; Is_Spliterator_OfLong(); TrySplit__Spliterator_OfLong() Spliterator_OfLong; TryAdvance_LongConsumer__Z(p0 LongConsumer) bool; ForEachRemaining_LongConsumer__V(p0 LongConsumer); TryAdvance_Consumer__Z(p0 Consumer) bool; ForEachRemaining_Consumer__V(p0 Consumer); TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive; TryAdvance_O__Z(p0 any) bool; ForEachRemaining_O__V(p0 any); TrySplit__Spliterator() Spliterator }

func Spliterator_OfLong_TrySplit__Spliterator_OfPrimitive(this Spliterator_OfLong) Spliterator_OfPrimitive { return this.TrySplit__Spliterator_OfLong() }

func Spliterator_OfLong_TryAdvance_O__Z(this Spliterator_OfLong, p0 any) bool { return this.TryAdvance_LongConsumer__Z(LongConsumer_Cast(p0)) }

func Spliterator_OfLong_ForEachRemaining_O__V(this Spliterator_OfLong, p0 any) { this.ForEachRemaining_LongConsumer__V(LongConsumer_Cast(p0)) }

func Spliterator_OfLong_TrySplit__Spliterator(this Spliterator_OfLong) Spliterator { return this.TrySplit__Spliterator_OfLong() }

func Spliterator_OfLong_InstanceOf(x any) bool { _, ok := x.(Spliterator_OfLong); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfLong_class) } }; return ok }

func Spliterator_OfLong_Cast(x any) Spliterator_OfLong { if x == nil { return nil }; v, ok := x.(Spliterator_OfLong); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfLong_class) } }; if !ok { panic(ClassCast(x, Spliterator_OfLong_class)) }; return v }



type Spliterator_OfPrimitive interface{ Object_I; Spliterator; Is_Spliterator_OfPrimitive(); TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive; TryAdvance_O__Z(p0 any) bool; ForEachRemaining_O__V(p0 any); TrySplit__Spliterator() Spliterator }

func Spliterator_OfPrimitive_TrySplit__Spliterator(this Spliterator_OfPrimitive) Spliterator { return this.TrySplit__Spliterator_OfPrimitive() }

func Spliterator_OfPrimitive_InstanceOf(x any) bool { _, ok := x.(Spliterator_OfPrimitive); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfPrimitive_class) } }; return ok }

func Spliterator_OfPrimitive_Cast(x any) Spliterator_OfPrimitive { if x == nil { return nil }; v, ok := x.(Spliterator_OfPrimitive); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Spliterator_OfPrimitive_class) } }; if !ok { panic(ClassCast(x, Spliterator_OfPrimitive_class)) }; return v }
