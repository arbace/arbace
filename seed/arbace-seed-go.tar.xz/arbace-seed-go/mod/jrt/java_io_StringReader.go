//line java_io_StringReader.ae:1
package jrt








func StringReader_New_String(p0 *String) *StringReader { t := &StringReader{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *StringReader) Ctor_String(s *String) { t.Reader.Ctor(t); t.F_r = Reader_Of_CharSequence__Reader(Up_String_CharSequence(s)) }

func (t *StringReader) Read__I() int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_r.Read__I() }(); return tmp1
}
func (t *StringReader) Read_C1_I_I__I(cbuf *CharArray, off, len_ int32) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_r.Read_C1_I_I__I(cbuf, off, len_) }(); return tmp1
}
func (t *StringReader) Skip_J__J(n int64) int64 {
	var tmp1 int64; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_r.Skip_J__J(n) }(); return tmp1
}
func (t *StringReader) Ready__Z() bool {
	var tmp1 bool; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_r.Ready__Z() }(); return tmp1
}
func (t *StringReader) MarkSupported__Z() bool { return true }

func (t *StringReader) Mark_I__V(readAheadLimit int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_r.Mark_I__V(readAheadLimit) }()
}
func (t *StringReader) Reset__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_r.Reset__V() }()
}
func (t *StringReader) Close__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp2 := func() (exc Throwable_I) { defer Catch(&exc); t.F_r.Close__V(); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var e IOException_I = IOException_Cast(tmp2); panic(Thrown(UncheckedIOException_New_IOException(e))) } else { panic(tmp2) } } }()
}


type StringReader struct{ Reader; F_r Reader_I }

func (t *StringReader) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *StringReader) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *StringReader) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *StringReader) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *StringReader) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *StringReader) Ref() any { if t == nil { return nil }; return t }

func (t *StringReader) GetClass__Class() *Class { return StringReader_class }

func (t *StringReader) ToString__String() *String { return Object_toString(t) }

func (t *StringReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringReader_InstanceOf(x any) bool { _, ok := x.(*StringReader); return ok }

func StringReader_Cast(x any) *StringReader { if x == nil { return nil }; v, ok := x.(*StringReader); if !ok { panic(ClassCast(x, StringReader_class)) }; return v }
