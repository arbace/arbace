//line java_security_Key.ae:1
package jrt






type Key interface{ Object_I; Serializable; Is_Key(); GetAlgorithm__String() *String; GetFormat__String() *String; GetEncoded__B1() *ByteArray }

const Key_serialVersionUID int64 = 6603384152749567654

func Key_InstanceOf(x any) bool { _, ok := x.(Key); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Key_class) } }; return ok }

func Key_Cast(x any) Key { if x == nil { return nil }; v, ok := x.(Key); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Key_class) } }; if !ok { panic(ClassCast(x, Key_class)) }; return v }
