//line access.ae:1
package jrt






// JavaLangAccess is jdk.internal.access.JavaLangAccess (an interface).
type JavaLangAccess /*line :10:1*/ interface { Object_I
	Is_JavaLangAccess()
	CountPositives_B1_I_I__I(ba *ByteArray, off, n int32) int32
	UncheckedNewStringWithLatin1Bytes_B1__String(b *ByteArray) *String
	UncheckedGetUTF16Char_B1_I__C(v *ByteArray, index int32) uint16
	UncheckedPutCharUTF16_B1_I_I__V(v *ByteArray, index, c int32)
	InflateBytesToChars_B1_I_C1_I_I__V(src *ByteArray, srcOff int32, dst *CharArray, dstOff, n int32)
	CurrentCarrierThread__Thread() Thread_I
	GetEnumConstantsShared_Class__Enum1(c *Class) *RefArray
	Join_String_String_String_String1_I__String(prefix, suffix, delimiter /*line :20:1*/*String, elements *RefArray, size int32/*line :19:1*/) *String
}

var JavaLangAccess_class =
	Define(&ClassInfo{Name: "jdk.internal.access.JavaLangAccess", Kind: KindInterface,
				Modifiers:                                  AccPublic | AccInterface | AccAbstract, Go: "arbace/jrt.JavaLangAccess"})
// javaLangAccess is jrt's JavaLangAccess.
type javaLangAccess struct{ Object }

func (t *javaLangAccess) Is_JavaLangAccess() {}
// countPositives: the number of leading bytes that are not negative.
func (t /*line :31:1*/*javaLangAccess) CountPositives_B1_I_I__I(ba *ByteArray, off, n int32) int32 {
	a := NN(ba).A
	for i := off; i < off+n; i++ {
		if a[i] < 0 {
			return i - off
		}
	}; return n }
func (t /*line :39:1*/*javaLangAccess) UncheckedNewStringWithLatin1Bytes_B1__String(b *ByteArray) *String {
	return String_NewStringWithLatin1Bytes_B1__String(b)
}
func (t /*line :43:1*/*javaLangAccess) UncheckedGetUTF16Char_B1_I__C(v *ByteArray, index int32) uint16 {
	a := NN(v).A
	j := 2 * index
	return uint16(uint8(a[j])) | uint16(uint8(a[j+1]))<<8
}
func (t /*line :49:1*/*javaLangAccess) UncheckedPutCharUTF16_B1_I_I__V(v *ByteArray, index, c int32) {
	StringUTF16_PutChar_B1_I_I__V(v, index, c)
}
func (t /*line :53:1*/*javaLangAccess) InflateBytesToChars_B1_I_C1_I_I__V(src *ByteArray, srcOff int32, dst *CharArray, dstOff, n int32) {
	s := NN(src).A
	d := NN(dst).A
	for i := int32(0); i < n; i++ {
		d[dstOff+i] = uint16(uint8(s[srcOff+i]))
	} }
func (t *javaLangAccess) CurrentCarrierThread__Thread() Thread_I {
	return Thread_CurrentThread__Thread() }
// GetEnumConstantsShared_Class__Enum1 is getEnumConstantsShared (EnumSet): the enum's constants,
// null for a class that is not an enum.
//line :62:1
func (t /*line :65:1*/*javaLangAccess) GetEnumConstantsShared_Class__Enum1(c *Class) *RefArray {
	return NN(c).GetEnumConstants__O1() }
// Join_String_String_String_String1_I__String is join (StringJoiner, String.join): prefix, the
// first size elements separated by delimiter, suffix.
//line :68:1
func (t /*line :71:1*/*javaLangAccess) Join_String_String_String_String1_I__String(prefix, suffix, delimiter *String, elements /*line :72:1*/*RefArray, size int32/*line :71:1*/) *String {

	var v []uint16 = nil
	v = append(v, NN(prefix).value...)
	for i := int32(0); i < size; i++ {
		if i > 0 {
			v = append(v, NN(delimiter).value...) }
		v = append(v, StrOfObj(elements.A[i]).value...) }
	v = append(v, NN(suffix).value...)
	return newString(v)
}
func (t *javaLangAccess) Ref() any { if t == nil { return nil }; return t }
func (t *javaLangAccess) GetClass__Class() *Class { return JavaLangAccess_class }
func (t *javaLangAccess) ToString__String() *String { return Object_toString(t) }
func (t *javaLangAccess) Clone__O() any { panic(CloneNotSupported(t)) }

func JavaLangAccess_InstanceOf(x any) bool { _, ok := x.(JavaLangAccess); return ok }
func JavaLangAccess_Cast(x any) JavaLangAccess {
	if x == nil { return nil }
	v, ok := x.(JavaLangAccess)
	if !ok { panic(ClassCast(x, JavaLangAccess_class))
	}; return v }
// SharedSecrets is jdk.internal.access.SharedSecrets: the accesses jrt has.
type SharedSecrets /*line :95:1*/ struct{ Object }

var SharedSecrets_class =
	Define(&ClassInfo{Name: "jdk.internal.access.SharedSecrets", Kind: KindClass,
				Modifiers:                                 AccPublic | AccFinal, Super: Object_class, Go: "arbace/jrt.SharedSecrets",
	})
var theJavaLangAccess JavaLangAccess = &javaLangAccess{}
// SharedSecrets.getJavaLangAccess.
func SharedSecrets_GetJavaLangAccess__JavaLangAccess() JavaLangAccess { return theJavaLangAccess }



func init() {
	JavaLangAccess_class.Info().IsInstance = JavaLangAccess_InstanceOf
}
