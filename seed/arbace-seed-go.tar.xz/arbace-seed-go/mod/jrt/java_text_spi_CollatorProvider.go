//line java_text_spi_CollatorProvider.ae:1
package jrt










func (t *CollatorProvider) Ctor(this CollatorProvider_I) { t.LocaleServiceProvider.Ctor(this) }



type CollatorProvider struct{ LocaleServiceProvider }

type CollatorProvider_I interface{ LocaleServiceProvider_I; Self_CollatorProvider() *CollatorProvider; GetInstance_Locale__Collator(p0 *Locale) Collator_I }

func (t *CollatorProvider) Self_CollatorProvider() *CollatorProvider { return t }

func CollatorProvider_InstanceOf(x any) bool { _, ok := x.(CollatorProvider_I); return ok }

func CollatorProvider_Cast(x any) CollatorProvider_I { if x == nil { return nil }; v, ok := x.(CollatorProvider_I); if !ok { panic(ClassCast(x, CollatorProvider_class)) }; return v }
