//line java_lang_ExceptionInInitializerError.ae:1
package jrt










func ExceptionInInitializerError_New() *ExceptionInInitializerError { ExceptionInInitializerError_Init(); t := &ExceptionInInitializerError{}; t.Ctor(); return t }
//line :12:1
func (t *ExceptionInInitializerError) Ctor() { t.LinkageError.Ctor(t); t.InitCause_Throwable__Throwable(nil) }

func ExceptionInInitializerError_New_Throwable(p0 Throwable_I) *ExceptionInInitializerError { ExceptionInInitializerError_Init(); t := &ExceptionInInitializerError{}; t.Ctor_Throwable(p0); return t }
//line :14:1
func (t *ExceptionInInitializerError) Ctor_Throwable(thrown Throwable_I) { t.LinkageError.Ctor_String_Throwable(t, nil, thrown) }

func ExceptionInInitializerError_New_String(p0 *String) *ExceptionInInitializerError { ExceptionInInitializerError_Init(); t := &ExceptionInInitializerError{}; t.Ctor_String(p0); return t }
//line :16:1
func (t *ExceptionInInitializerError) Ctor_String(s *String) { t.LinkageError.Ctor_String_Throwable(t, s, nil) }

func (t *ExceptionInInitializerError) GetException__Throwable() Throwable_I { return t.LinkageError.Impl_GetCause__Throwable(t) }









type ExceptionInInitializerError struct{ LinkageError }

const ExceptionInInitializerError_serialVersionUID int64 = 1521711792217232256

var ExceptionInInitializerError_init ClassInit

func ExceptionInInitializerError_Init() { if !ExceptionInInitializerError_init.Done() { ExceptionInInitializerError_init.Run(ExceptionInInitializerError_clinit) } }

func ExceptionInInitializerError_clinit() {}

func (t *ExceptionInInitializerError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ExceptionInInitializerError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ExceptionInInitializerError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ExceptionInInitializerError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ExceptionInInitializerError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ExceptionInInitializerError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ExceptionInInitializerError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ExceptionInInitializerError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ExceptionInInitializerError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ExceptionInInitializerError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ExceptionInInitializerError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ExceptionInInitializerError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ExceptionInInitializerError) Ref() any { if t == nil { return nil }; return t }

func (t *ExceptionInInitializerError) GetClass__Class() *Class { return ExceptionInInitializerError_class }

func (t *ExceptionInInitializerError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ExceptionInInitializerError) CloneShallow() any { panic(CloneNotSupported(t)) }

func ExceptionInInitializerError_InstanceOf(x any) bool { _, ok := x.(*ExceptionInInitializerError); return ok }

func ExceptionInInitializerError_Cast(x any) *ExceptionInInitializerError { if x == nil { return nil }; v, ok := x.(*ExceptionInInitializerError); if !ok { panic(ClassCast(x, ExceptionInInitializerError_class)) }; return v }
