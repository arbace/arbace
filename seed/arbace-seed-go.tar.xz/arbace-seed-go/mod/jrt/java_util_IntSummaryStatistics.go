//line java_util_IntSummaryStatistics.ae:1
package jrt
















func IntSummaryStatistics_New() *IntSummaryStatistics { t := &IntSummaryStatistics{}; t.Ctor(); return t }
//line :18:1
func (t *IntSummaryStatistics) Ctor() { t.F_min = 2147483647; t.F_max = -2147483648 }

func IntSummaryStatistics_New_J_I_I_J(p0 int64, p1, p2 int32, p3 int64) *IntSummaryStatistics { t := &IntSummaryStatistics{}; t.Ctor_J_I_I_J(p0, p1, p2, p3); return t }
//line :20:1
func (t *IntSummaryStatistics) Ctor_J_I_I_J(count int64, min_, max_ int32, sum int64) { t.F_min = 2147483647; t.F_max = -2147483648

	if count < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2661))) } else {
			if count > 0 {
				if min_ > max_ { panic(Thrown(IllegalArgumentException_New_String(Lit_2662))) }
				t.F_count = count
				t.F_sum = sum
				t.F_min = min_
				t.F_max = max_
			} } }
func (t *IntSummaryStatistics) Accept_I__V(value int32) {
	t.F_count = t.F_count + 1
	t.F_sum = t.F_sum + int64(value)
	t.F_min = Math_Min_I_I__I(t.F_min, value)
	t.F_max = Math_Max_I_I__I(t.F_max, value)
}
func (t *IntSummaryStatistics) Combine_IntSummaryStatistics__V(other *IntSummaryStatistics) {
	var tmp1 int64 = t.F_count; t.F_count = tmp1 + other.F_count
	var tmp2 int64 = t.F_sum; t.F_sum = tmp2 + other.F_sum
	var tmp3 int32 = t.F_min; t.F_min = Math_Min_I_I__I(tmp3, other.F_min)
	var tmp4 int32 = t.F_max; t.F_max = Math_Max_I_I__I(tmp4, other.F_max)
}
func (t *IntSummaryStatistics) GetCount__J() int64 { return t.F_count }

func (t *IntSummaryStatistics) GetSum__J() int64 { return t.F_sum }

func (t *IntSummaryStatistics) GetMin__I() int32 { return t.F_min }

func (t *IntSummaryStatistics) GetMax__I() int32 { return t.F_max }

func (t *IntSummaryStatistics) GetAverage__D() float64 {
	if t.GetCount__J() > 0 { return float64(t.GetSum__J()) / float64(t.GetCount__J()) } else { return 0.0
	} }
func (t *IntSummaryStatistics) ToString__String() *String {
	return String_Format_String_O1__String(Lit_2735, RefArrayOf(Object_class, NN(t.GetClass__Class()).GetSimpleName__String().Ref(), Long_ValueOf_J__Long(t.GetCount__J()), Long_ValueOf_J__Long(t.GetSum__J()), Integer_ValueOf_I__Integer(t.GetMin__I()), Double_ValueOf_D__Double(t.GetAverage__D()), Integer_ValueOf_I__Integer(t.GetMax__I())))
}


type IntSummaryStatistics struct{ Object; F_count, F_sum int64; F_min, F_max int32 }

func (t *IntSummaryStatistics) Is_IntConsumer() {}

func (t *IntSummaryStatistics) AndThen_IntConsumer__IntConsumer(p0 IntConsumer) IntConsumer { return IntConsumer_AndThen_IntConsumer__IntConsumer(t, p0) }

func (t *IntSummaryStatistics) Ref() any { if t == nil { return nil }; return t }

func (t *IntSummaryStatistics) GetClass__Class() *Class { return IntSummaryStatistics_class }

func (t *IntSummaryStatistics) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IntSummaryStatistics) CloneShallow() any { panic(CloneNotSupported(t)) }

func IntSummaryStatistics_InstanceOf(x any) bool { _, ok := x.(*IntSummaryStatistics); return ok }

func IntSummaryStatistics_Cast(x any) *IntSummaryStatistics { if x == nil { return nil }; v, ok := x.(*IntSummaryStatistics); if !ok { panic(ClassCast(x, IntSummaryStatistics_class)) }; return v }
