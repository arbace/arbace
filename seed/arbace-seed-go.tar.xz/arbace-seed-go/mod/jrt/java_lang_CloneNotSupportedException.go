//line java_lang_CloneNotSupportedException.ae:1
package jrt








func CloneNotSupportedException_New() *CloneNotSupportedException { t := &CloneNotSupportedException{}; t.Ctor(); return t }
//line :10:1
func (t *CloneNotSupportedException) Ctor() { t.Exception.Ctor(t) }

func CloneNotSupportedException_New_String(p0 *String) *CloneNotSupportedException { t := &CloneNotSupportedException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *CloneNotSupportedException) Ctor_String(s *String) { t.Exception.Ctor_String(t, s) }







type CloneNotSupportedException struct{ Exception }

const CloneNotSupportedException_serialVersionUID int64 = 5195511250079656443

func (t *CloneNotSupportedException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *CloneNotSupportedException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *CloneNotSupportedException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *CloneNotSupportedException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *CloneNotSupportedException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *CloneNotSupportedException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *CloneNotSupportedException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *CloneNotSupportedException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *CloneNotSupportedException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *CloneNotSupportedException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *CloneNotSupportedException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *CloneNotSupportedException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *CloneNotSupportedException) Ref() any { if t == nil { return nil }; return t }

func (t *CloneNotSupportedException) GetClass__Class() *Class { return CloneNotSupportedException_class }

func (t *CloneNotSupportedException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CloneNotSupportedException) CloneShallow() any { panic(CloneNotSupported(t)) }

func CloneNotSupportedException_InstanceOf(x any) bool { _, ok := x.(*CloneNotSupportedException); return ok }

func CloneNotSupportedException_Cast(x any) *CloneNotSupportedException { if x == nil { return nil }; v, ok := x.(*CloneNotSupportedException); if !ok { panic(ClassCast(x, CloneNotSupportedException_class)) }; return v }
