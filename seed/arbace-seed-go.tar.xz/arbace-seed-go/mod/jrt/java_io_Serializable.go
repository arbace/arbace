//line java_io_Serializable.ae:1
package jrt






type Serializable interface{ Object_I; Is_Serializable() }

func Serializable_InstanceOf(x any) bool { _, ok := x.(Serializable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Serializable_class) } }; return ok }

func Serializable_Cast(x any) Serializable { if x == nil { return nil }; v, ok := x.(Serializable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Serializable_class) } }; if !ok { panic(ClassCast(x, Serializable_class)) }; return v }
