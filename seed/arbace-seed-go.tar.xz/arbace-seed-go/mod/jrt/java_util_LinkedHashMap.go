//line java_util_LinkedHashMap.ae:1
package jrt



















func LinkedHashMap_Entry_New_I_O_O_HashMap_Node(p0 int32, p1, p2 any, p3 HashMap_Node_I) *LinkedHashMap_Entry { t := &LinkedHashMap_Entry{}; t.Ctor_I_O_O_HashMap_Node(t, p0, p1, p2, p3); return t }
//line :21:1
func (t *LinkedHashMap_Entry) Ctor_I_O_O_HashMap_Node(this LinkedHashMap_Entry_I, hash int32, key, value any, next HashMap_Node_I) { t.HashMap_Node.Ctor_I_O_O_HashMap_Node(this, hash, key, value, next) }










func (t *LinkedHashMap) LinkNodeAtEnd_LinkedHashMap_Entry__V(p LinkedHashMap_Entry_I) {
	if t.F_putMode == 1 {
		var first LinkedHashMap_Entry_I = t.F_head
		t.F_head = p
		if first == nil { t.F_tail = p } else { p.Self_LinkedHashMap_Entry().F_after = first; first.Self_LinkedHashMap_Entry().F_before = p } } else {
			var last LinkedHashMap_Entry_I = t.F_tail
			t.F_tail = p
			if last == nil { t.F_head = p } else { p.Self_LinkedHashMap_Entry().F_before = last; last.Self_LinkedHashMap_Entry().F_after = p
			} } }
func (t *LinkedHashMap) TransferLinks_LinkedHashMap_Entry_LinkedHashMap_Entry__V(src, dst LinkedHashMap_Entry_I) {
	var b LinkedHashMap_Entry_I; var tmp1 LinkedHashMap_Entry_I = src.Self_LinkedHashMap_Entry().F_before; dst.Self_LinkedHashMap_Entry().F_before = tmp1; b = tmp1; var a LinkedHashMap_Entry_I; var tmp2 LinkedHashMap_Entry_I = src.Self_LinkedHashMap_Entry().F_after
	dst.Self_LinkedHashMap_Entry().F_after = tmp2; a = tmp2
	if b == nil { t.F_head = dst } else { b.Self_LinkedHashMap_Entry().F_after = dst }
	if a == nil { t.F_tail = dst } else { a.Self_LinkedHashMap_Entry().F_before = dst
	} }
func (t *LinkedHashMap) Reinitialize__V() {
	t.HashMap.Impl_Reinitialize__V(t)
	var tmp1 LinkedHashMap_Entry_I; var tmp2 LinkedHashMap_Entry_I; t.F_tail = tmp2; tmp1 = tmp2; t.F_head = tmp1
}
func (t *LinkedHashMap) NewNode_I_O_O_HashMap_Node__HashMap_Node(hash int32, key, value any, e HashMap_Node_I) HashMap_Node_I {

	var p LinkedHashMap_Entry_I = LinkedHashMap_Entry_New_I_O_O_HashMap_Node(hash, key, value, e); t.LinkNodeAtEnd_LinkedHashMap_Entry__V(p); return p
}
func (t *LinkedHashMap) ReplacementNode_HashMap_Node_HashMap_Node__HashMap_Node(p, next HashMap_Node_I) HashMap_Node_I {

	var q LinkedHashMap_Entry_I = LinkedHashMap_Entry_Cast(p); var tmp1 int32 = q.Self_HashMap_Node().F_hash; var tmp2 any = q.Self_HashMap_Node().F_key; var t_ LinkedHashMap_Entry_I = LinkedHashMap_Entry_New_I_O_O_HashMap_Node(tmp1, tmp2, q.Self_HashMap_Node().F_value, next)

	t.TransferLinks_LinkedHashMap_Entry_LinkedHashMap_Entry__V(q, t_)
//line :57:1
	return t_
}



func (t *LinkedHashMap) NewTreeNode_I_O_O_HashMap_Node__HashMap_TreeNode(hash int32, key, value any, next HashMap_Node_I) *HashMap_TreeNode {

	var p *HashMap_TreeNode = HashMap_TreeNode_New_I_O_O_HashMap_Node(hash, key, value, next)
	t.LinkNodeAtEnd_LinkedHashMap_Entry__V(Up_HashMap_TreeNode_LinkedHashMap_Entry(p))
//line :64:1
	return p
}


func (t *LinkedHashMap) ReplacementTreeNode_HashMap_Node_HashMap_Node__HashMap_TreeNode(p, next HashMap_Node_I) *HashMap_TreeNode {

	var q LinkedHashMap_Entry_I = LinkedHashMap_Entry_Cast(p); var tmp1 int32 = q.Self_HashMap_Node().F_hash; var tmp2 any = q.Self_HashMap_Node().F_key; var t_ *HashMap_TreeNode = HashMap_TreeNode_New_I_O_O_HashMap_Node(tmp1, tmp2, q.Self_HashMap_Node().F_value, next)

	t.TransferLinks_LinkedHashMap_Entry_LinkedHashMap_Entry__V(q, Up_HashMap_TreeNode_LinkedHashMap_Entry(t_))
//line :70:1
	return t_
}



func (t *LinkedHashMap) AfterNodeRemoval_HashMap_Node__V(e HashMap_Node_I) {
	var p LinkedHashMap_Entry_I = LinkedHashMap_Entry_Cast(e); var b LinkedHashMap_Entry_I = p.Self_LinkedHashMap_Entry().F_before; var a LinkedHashMap_Entry_I = p.Self_LinkedHashMap_Entry().F_after; var tmp1 LinkedHashMap_Entry_I; var tmp2 LinkedHashMap_Entry_I


	p.Self_LinkedHashMap_Entry().F_after = tmp2; tmp1 = tmp2; p.Self_LinkedHashMap_Entry().F_before = tmp1
	if b == nil { t.F_head = a } else { b.Self_LinkedHashMap_Entry().F_after = a }
	if a == nil { t.F_tail = b } else { a.Self_LinkedHashMap_Entry().F_before = b
	} }
func (t *LinkedHashMap) AfterNodeInsertion_Z__V(evict bool) {
	var first LinkedHashMap_Entry_I; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = evict; if tmp3 { var tmp4 LinkedHashMap_Entry_I; first = t.F_head; tmp4 = first; tmp3 = !(tmp4 == nil) }; tmp2 = tmp3; if tmp2 { tmp2 = t.RemoveEldestEntry_Map_Entry__Z(first) }; tmp1 = tmp2; if tmp1 {
		var key any = first.Self_HashMap_Node().F_key; t.RemoveNode_I_O_O_Z_Z__HashMap_Node(HashMap_Hash_O__I(key), key, nil, false, true)
	}
}







func (t *LinkedHashMap) AfterNodeAccess_HashMap_Node__V(e HashMap_Node_I) {
	var last LinkedHashMap_Entry_I; var first LinkedHashMap_Entry_I; var tmp1 bool; var tmp2 bool; var tmp3 bool


	tmp3 = t.F_putMode == 2; if !tmp3 { var tmp4 bool; tmp4 = t.F_putMode == 0; if tmp4 { tmp4 = t.F_accessOrder }; tmp3 = tmp4 }; tmp2 = tmp3; if tmp2 {
		var tmp5 LinkedHashMap_Entry_I; last = t.F_tail; tmp5 = last; tmp2 = !(any(tmp5) == any(e)) }
//line :100:1
	tmp1 = tmp2
//line :99:1
	if tmp1 {


		var p LinkedHashMap_Entry_I = LinkedHashMap_Entry_Cast(e); var b LinkedHashMap_Entry_I = p.Self_LinkedHashMap_Entry().F_before; var a LinkedHashMap_Entry_I = p.Self_LinkedHashMap_Entry().F_after


		p.Self_LinkedHashMap_Entry().F_after = nil
		if b == nil { t.F_head = a } else { b.Self_LinkedHashMap_Entry().F_after = a }
		if !(a == nil) { a.Self_LinkedHashMap_Entry().F_before = b } else { last = b }
		if last == nil { t.F_head = p } else { p.Self_LinkedHashMap_Entry().F_before = last; last.Self_LinkedHashMap_Entry().F_after = p }
		t.F_tail = p
		t.F_modCount = t.F_modCount + 1 } else {
//line :99:1
			var tmp6 bool; var tmp7 bool











			tmp7 = t.F_putMode == 1; if tmp7 { var tmp8 LinkedHashMap_Entry_I; first = t.F_head; tmp8 = first; tmp7 = !(any(tmp8) == any(e)) }; tmp6 = tmp7
//line :99:1
			if tmp6 {












				var p_2 LinkedHashMap_Entry_I = LinkedHashMap_Entry_Cast(e); var b_2 LinkedHashMap_Entry_I = p_2.Self_LinkedHashMap_Entry().F_before; var a_2 LinkedHashMap_Entry_I = p_2.Self_LinkedHashMap_Entry().F_after


				p_2.Self_LinkedHashMap_Entry().F_before = nil
				if a_2 == nil { t.F_tail = b_2 } else { a_2.Self_LinkedHashMap_Entry().F_before = b_2 }
				if !(b_2 == nil) { b_2.Self_LinkedHashMap_Entry().F_after = a_2 } else { first = a_2 }
				if first == nil { t.F_tail = p_2 } else { p_2.Self_LinkedHashMap_Entry().F_after = first; first.Self_LinkedHashMap_Entry().F_before = p_2 }
				t.F_head = p_2
				t.F_modCount = t.F_modCount + 1
			} } }
func (t *LinkedHashMap) PutFirst_O_O__O(k, v any) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); t.F_putMode = 1; tmp1 = t.Put_O_O__O(k, v); return nil }(); t.F_putMode = 0; if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *LinkedHashMap) PutLast_O_O__O(k, v any) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); t.F_putMode = 2; tmp1 = t.Put_O_O__O(k, v); return nil }(); t.F_putMode = 0; if tmp2 != nil { panic(tmp2) }; return tmp1
}




func LinkedHashMap_New_I_F(p0 int32, p1 float32) *LinkedHashMap { t := &LinkedHashMap{}; t.Ctor_I_F(p0, p1); return t }
//line :132:1
func (t *LinkedHashMap) Ctor_I_F(initialCapacity int32, loadFactor float32) { t.HashMap.Ctor_I_F(t, initialCapacity, loadFactor); t.F_putMode = 0

	t.F_accessOrder = false
}
func LinkedHashMap_New_I(p0 int32) *LinkedHashMap { t := &LinkedHashMap{}; t.Ctor_I(p0); return t }
//line :136:1
func (t *LinkedHashMap) Ctor_I(initialCapacity int32) { t.HashMap.Ctor_I(t, initialCapacity); t.F_putMode = 0

	t.F_accessOrder = false
}
func LinkedHashMap_New() *LinkedHashMap { t := &LinkedHashMap{}; t.Ctor(); return t }
//line :140:1
func (t *LinkedHashMap) Ctor() { t.HashMap.Ctor(t); t.F_putMode = 0; t.F_accessOrder = false }

func LinkedHashMap_New_Map(p0 Map) *LinkedHashMap { t := &LinkedHashMap{}; t.Ctor_Map(p0); return t }
//line :142:1
func (t *LinkedHashMap) Ctor_Map(m Map) { t.HashMap.Ctor(t); t.F_putMode = 0

	t.F_accessOrder = false
	t.PutMapEntries_Map_Z__V(m, false)
}
func LinkedHashMap_New_I_F_Z(p0 int32, p1 float32, p2 bool) *LinkedHashMap { t := &LinkedHashMap{}; t.Ctor_I_F_Z(p0, p1, p2); return t }
//line :147:1
func (t *LinkedHashMap) Ctor_I_F_Z(initialCapacity int32, loadFactor float32, accessOrder bool) { t.HashMap.Ctor_I_F(t, initialCapacity, loadFactor); t.F_putMode = 0

	t.F_accessOrder = accessOrder
}
func (t *LinkedHashMap) ContainsValue_O__Z(value any) bool {
	var e LinkedHashMap_Entry_I = t.F_head; L1: for {
		if !(e == nil) {
			var v any = e.Self_HashMap_Node().F_value; var tmp1 bool; var tmp2 bool
			tmp2 = v == value; if !tmp2 { var tmp3 bool; tmp3 = !(value == nil); if tmp3 { tmp3 = Equals(value, v) }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 {
				return true } else {
					e = e.Self_LinkedHashMap_Entry().F_after; continue L1 } }
//line :152:1
		break L1 }
//line :151:1
	return false
}







func (t *LinkedHashMap) Get_O__O(key any) any {
	var e HashMap_Node_I; var tmp1 HashMap_Node_I
	e = t.GetNode_O__HashMap_Node(key); tmp1 = e; if !(tmp1 == nil) {
		if t.F_accessOrder { t.AfterNodeAccess_HashMap_Node__V(e) }
		return e.Self_HashMap_Node().F_value } else {
//line :162:1
			return nil
		}
}

func (t *LinkedHashMap) GetOrDefault_O_O__O(key, defaultValue any) any {
	var e HashMap_Node_I; var tmp1 HashMap_Node_I
	e = t.GetNode_O__HashMap_Node(key); tmp1 = e; if tmp1 == nil { return defaultValue } else {

		if t.F_accessOrder { t.AfterNodeAccess_HashMap_Node__V(e) }; return e.Self_HashMap_Node().F_value
	} }
func (t *LinkedHashMap) Clear__V() {
	t.HashMap.Impl_Clear__V(t)
	var tmp1 LinkedHashMap_Entry_I; var tmp2 LinkedHashMap_Entry_I; t.F_tail = tmp2; tmp1 = tmp2; t.F_head = tmp1
}
func (t *LinkedHashMap) RemoveEldestEntry_Map_Entry__Z(eldest Map_Entry) bool { return false }


func (t *LinkedHashMap) KeySet__Set() Set { return t.SequencedKeySet__SequencedSet() }

func (t *LinkedHashMap) SequencedKeySet__SequencedSet() SequencedSet {
	var ks Set = t.F_keySet
	if ks == nil {
		var sks SequencedSet = LinkedHashMap_LinkedKeySet_New_LinkedHashMap_Z(t, false); t.F_keySet = sks; return sks } else {
			return SequencedSet_Cast(ks)
		} }
func LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(node HashMap_Node_I) HashMap_Node_I {
	if node == nil { panic(Thrown(NoSuchElementException_New())) } else { return node
	} }
func (t *LinkedHashMap) KeysToArray_O1__O1(a *RefArray) *RefArray {
	return t.KeysToArray_O1_Z__O1(a, false)
}
func (t *LinkedHashMap) KeysToArray_O1_Z__O1(a *RefArray, reversed bool) *RefArray {
	var r *RefArray = a
	var idx int32 = 0
	if reversed {
		var e LinkedHashMap_Entry_I = t.F_tail; L1: for {
			if !(e == nil) {
				r.Store(idx, e.Self_HashMap_Node().F_key)
				idx = idx + 1
				e = e.Self_LinkedHashMap_Entry().F_before; continue L1 }
//line :197:1
			break L1
		}

	} else {

		var e_2 LinkedHashMap_Entry_I = t.F_head; L2: for {
			if !(e_2 == nil) {
				r.Store(idx, e_2.Self_HashMap_Node().F_key)
				idx = idx + 1
				e_2 = e_2.Self_LinkedHashMap_Entry().F_after; continue L2 }
//line :202:1
			break L2 } }
//line :194:1
	return a
}













func (t *LinkedHashMap) ValuesToArray_O1_Z__O1(a *RefArray, reversed bool) *RefArray {
	var r *RefArray = a
	var idx int32 = 0
	if reversed {
		var e LinkedHashMap_Entry_I = t.F_tail; L1: for {
			if !(e == nil) {
				r.Store(idx, e.Self_HashMap_Node().F_value)
				idx = idx + 1
				e = e.Self_LinkedHashMap_Entry().F_before; continue L1 }
//line :213:1
			break L1
		}

	} else {

		var e_2 LinkedHashMap_Entry_I = t.F_head; L2: for {
			if !(e_2 == nil) {
				r.Store(idx, e_2.Self_HashMap_Node().F_value)
				idx = idx + 1
				e_2 = e_2.Self_LinkedHashMap_Entry().F_after; continue L2 }
//line :218:1
			break L2 } }
//line :210:1
	return a
}



















func LinkedHashMap_LinkedKeySet_New_LinkedHashMap_Z(p0 *LinkedHashMap, p1 bool) *LinkedHashMap_LinkedKeySet { t := &LinkedHashMap_LinkedKeySet{}; t.Ctor_LinkedHashMap_Z(p0, p1); return t }
//line :231:1
func (t *LinkedHashMap_LinkedKeySet) Ctor_LinkedHashMap_Z(this_0 *LinkedHashMap, reversed bool) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t); t.F_reversed = reversed }

func (t *LinkedHashMap_LinkedKeySet) Size__I() int32 { return t.F_this_0.F_size }

func (t *LinkedHashMap_LinkedKeySet) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *LinkedHashMap_LinkedKeySet) Iterator__Iterator() Iterator {
	return LinkedHashMap_LinkedKeyIterator_New_LinkedHashMap_Z(t.F_this_0, t.F_reversed)
}
func (t *LinkedHashMap_LinkedKeySet) Contains_O__Z(o any) bool {
	return NN(t.F_this_0).ContainsKey_O__Z(o)
}
func (t *LinkedHashMap_LinkedKeySet) Remove_O__Z(key any) bool {
	return !(NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(HashMap_Hash_O__I(key), key, nil, false, true) == nil)
}
func (t *LinkedHashMap_LinkedKeySet) Spliterator__Spliterator() Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(t, 81)
}


func (t *LinkedHashMap_LinkedKeySet) ToArray__O1() *RefArray {
	return NN(t.F_this_0).KeysToArray_O1_Z__O1(NewRefArray(Object_class, t.F_this_0.F_size), t.F_reversed)
}
func (t *LinkedHashMap_LinkedKeySet) ToArray_O1__O1(a *RefArray) *RefArray {
	return NN(t.F_this_0).KeysToArray_O1_Z__O1(NN(t.F_this_0).PrepareArray_O1__O1(a), t.F_reversed)
}
func (t *LinkedHashMap_LinkedKeySet) ForEach_Consumer__V(action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var mc int32 = t.F_this_0.F_modCount
	if t.F_reversed {
		var e LinkedHashMap_Entry_I = t.F_this_0.F_tail; L1: for {
			if !(e == nil) { action.Accept_O__V(e.Self_HashMap_Node().F_key); e = e.Self_LinkedHashMap_Entry().F_before; continue L1 }
//line :261:1
			break L1 } } else {

				var e_2 LinkedHashMap_Entry_I = t.F_this_0.F_head; L2: for {
					if !(e_2 == nil) { action.Accept_O__V(e_2.Self_HashMap_Node().F_key); e_2 = e_2.Self_LinkedHashMap_Entry().F_after; continue L2 }
//line :263:1
					break L2
				} }
	if t.F_this_0.F_modCount == mc { } else {
		panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *LinkedHashMap_LinkedKeySet) AddFirst_O__V(k any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *LinkedHashMap_LinkedKeySet) AddLast_O__V(k any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *LinkedHashMap_LinkedKeySet) GetFirst__O() any {
	var tmp1 HashMap_Node_I; if t.F_reversed { tmp1 = t.F_this_0.F_tail } else { tmp1 = t.F_this_0.F_head }; return LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1).Self_HashMap_Node().F_key
}
func (t *LinkedHashMap_LinkedKeySet) GetLast__O() any {
	var tmp1 HashMap_Node_I; if t.F_reversed { tmp1 = t.F_this_0.F_head } else { tmp1 = t.F_this_0.F_tail }; return LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1).Self_HashMap_Node().F_key
}
func (t *LinkedHashMap_LinkedKeySet) RemoveFirst__O() any {
	var node HashMap_Node_I; var tmp1 HashMap_Node_I
	if t.F_reversed { tmp1 = t.F_this_0.F_tail } else { tmp1 = t.F_this_0.F_head }
//line :281:1
	node = LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1)

	var tmp2 int32 = node.Self_HashMap_Node().F_hash; NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp2, node.Self_HashMap_Node().F_key, nil, false, false)
	return node.Self_HashMap_Node().F_key
}
func (t *LinkedHashMap_LinkedKeySet) RemoveLast__O() any {
	var node HashMap_Node_I; var tmp1 HashMap_Node_I
	if t.F_reversed { tmp1 = t.F_this_0.F_head } else { tmp1 = t.F_this_0.F_tail }
//line :287:1
	node = LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1)

	var tmp2 int32 = node.Self_HashMap_Node().F_hash; NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp2, node.Self_HashMap_Node().F_key, nil, false, false)
	return node.Self_HashMap_Node().F_key
}
func (t *LinkedHashMap_LinkedKeySet) Reversed__SequencedSet() SequencedSet {
	if t.F_reversed { return NN(t.F_this_0).SequencedKeySet__SequencedSet() } else { return LinkedHashMap_LinkedKeySet_New_LinkedHashMap_Z(t.F_this_0, true)
	} }
func (t *LinkedHashMap) Values__Collection() Collection {
	return t.SequencedValues__SequencedCollection()
}
func (t *LinkedHashMap) SequencedValues__SequencedCollection() SequencedCollection {
	var vs Collection = t.F_values
	if vs == nil {
		var svs SequencedCollection = LinkedHashMap_LinkedValues_New_LinkedHashMap_Z(t, false)
		t.F_values = svs
//line :301:1
		return svs } else {


			return SequencedCollection_Cast(vs)
		}
}





func LinkedHashMap_LinkedValues_New_LinkedHashMap_Z(p0 *LinkedHashMap, p1 bool) *LinkedHashMap_LinkedValues { t := &LinkedHashMap_LinkedValues{}; t.Ctor_LinkedHashMap_Z(p0, p1); return t }
//line :312:1
func (t *LinkedHashMap_LinkedValues) Ctor_LinkedHashMap_Z(this_0 *LinkedHashMap, reversed bool) { NN(this_0); t.F_this_0 = this_0; t.AbstractCollection.Ctor(t); t.F_reversed = reversed }

func (t *LinkedHashMap_LinkedValues) Size__I() int32 { return t.F_this_0.F_size }

func (t *LinkedHashMap_LinkedValues) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *LinkedHashMap_LinkedValues) Iterator__Iterator() Iterator {
	return LinkedHashMap_LinkedValueIterator_New_LinkedHashMap_Z(t.F_this_0, t.F_reversed)
}
func (t *LinkedHashMap_LinkedValues) Contains_O__Z(o any) bool {
	return NN(t.F_this_0).ContainsValue_O__Z(o)
}
func (t *LinkedHashMap_LinkedValues) Spliterator__Spliterator() Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(t, 80)
}
func (t *LinkedHashMap_LinkedValues) ToArray__O1() *RefArray {
	return NN(t.F_this_0).ValuesToArray_O1_Z__O1(NewRefArray(Object_class, t.F_this_0.F_size), t.F_reversed)
}
func (t *LinkedHashMap_LinkedValues) ToArray_O1__O1(a *RefArray) *RefArray {
	return NN(t.F_this_0).ValuesToArray_O1_Z__O1(NN(t.F_this_0).PrepareArray_O1__O1(a), t.F_reversed)
}
func (t *LinkedHashMap_LinkedValues) ForEach_Consumer__V(action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var mc int32 = t.F_this_0.F_modCount
	if t.F_reversed {
		var e LinkedHashMap_Entry_I = t.F_this_0.F_tail; L1: for {
			if !(e == nil) { action.Accept_O__V(e.Self_HashMap_Node().F_value); e = e.Self_LinkedHashMap_Entry().F_before; continue L1 }
//line :337:1
			break L1 } } else {

				var e_2 LinkedHashMap_Entry_I = t.F_this_0.F_head; L2: for {
					if !(e_2 == nil) { action.Accept_O__V(e_2.Self_HashMap_Node().F_value); e_2 = e_2.Self_LinkedHashMap_Entry().F_after; continue L2 }
//line :339:1
					break L2
				} }
	if t.F_this_0.F_modCount == mc { } else {
		panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *LinkedHashMap_LinkedValues) AddFirst_O__V(v any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *LinkedHashMap_LinkedValues) AddLast_O__V(v any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *LinkedHashMap_LinkedValues) GetFirst__O() any {
	var tmp1 HashMap_Node_I
	if t.F_reversed { tmp1 = t.F_this_0.F_tail } else { tmp1 = t.F_this_0.F_head }
//line :351:1
	return LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1).Self_HashMap_Node().F_value
}

func (t *LinkedHashMap_LinkedValues) GetLast__O() any {
	var tmp1 HashMap_Node_I
	if t.F_reversed { tmp1 = t.F_this_0.F_head } else { tmp1 = t.F_this_0.F_tail }
//line :355:1
	return LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1).Self_HashMap_Node().F_value
}

func (t *LinkedHashMap_LinkedValues) RemoveFirst__O() any {
	var node HashMap_Node_I; var tmp1 HashMap_Node_I
	if t.F_reversed { tmp1 = t.F_this_0.F_tail } else { tmp1 = t.F_this_0.F_head }
//line :359:1
	node = LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1)

	var tmp2 int32 = node.Self_HashMap_Node().F_hash; NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp2, node.Self_HashMap_Node().F_key, nil, false, false)
	return node.Self_HashMap_Node().F_value
}
func (t *LinkedHashMap_LinkedValues) RemoveLast__O() any {
	var node HashMap_Node_I; var tmp1 HashMap_Node_I
	if t.F_reversed { tmp1 = t.F_this_0.F_head } else { tmp1 = t.F_this_0.F_tail }
//line :365:1
	node = LinkedHashMap_Nsee_HashMap_Node__HashMap_Node(tmp1)

	var tmp2 int32 = node.Self_HashMap_Node().F_hash; NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp2, node.Self_HashMap_Node().F_key, nil, false, false)
	return node.Self_HashMap_Node().F_value
}
func (t *LinkedHashMap_LinkedValues) Reversed__SequencedCollection() SequencedCollection {
	if t.F_reversed { return NN(t.F_this_0).SequencedValues__SequencedCollection() } else { return LinkedHashMap_LinkedValues_New_LinkedHashMap_Z(t.F_this_0, true)
	} }
func (t *LinkedHashMap) EntrySet__Set() Set {
	return t.SequencedEntrySet__SequencedSet()
}
func (t *LinkedHashMap) SequencedEntrySet__SequencedSet() SequencedSet {
	var es Set = t.F_entrySet
	if es == nil {
		var ses SequencedSet = LinkedHashMap_LinkedEntrySet_New_LinkedHashMap_Z(t, false)
		t.F_entrySet = ses
//line :379:1
		return ses } else {


			return SequencedSet_Cast(es)
		}
}





func LinkedHashMap_LinkedEntrySet_New_LinkedHashMap_Z(p0 *LinkedHashMap, p1 bool) *LinkedHashMap_LinkedEntrySet { t := &LinkedHashMap_LinkedEntrySet{}; t.Ctor_LinkedHashMap_Z(p0, p1); return t }
//line :390:1
func (t *LinkedHashMap_LinkedEntrySet) Ctor_LinkedHashMap_Z(this_0 *LinkedHashMap, reversed bool) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t); t.F_reversed = reversed }

func (t *LinkedHashMap_LinkedEntrySet) Size__I() int32 { return t.F_this_0.F_size }

func (t *LinkedHashMap_LinkedEntrySet) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *LinkedHashMap_LinkedEntrySet) Iterator__Iterator() Iterator {
	return LinkedHashMap_LinkedEntryIterator_New_LinkedHashMap_Z(t.F_this_0, t.F_reversed)
}
func (t *LinkedHashMap_LinkedEntrySet) Contains_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var key any = e.GetKey__O(); var candidate HashMap_Node_I = NN(t.F_this_0).GetNode_O__HashMap_Node(key); var tmp2 bool


		tmp2 = !(candidate == nil); if tmp2 { tmp2 = candidate.Equals_O__Z(e) }; return tmp2 } else {
//line :400:1
			return false
		}
}



func (t *LinkedHashMap_LinkedEntrySet) Remove_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var key any = e.GetKey__O(); var value any = e.GetValue__O()


		return !(NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(HashMap_Hash_O__I(key), key, value, true, true) == nil) } else {
//line :407:1
			return false
		}
}



func (t *LinkedHashMap_LinkedEntrySet) Spliterator__Spliterator() Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(t, 81)
}


func (t *LinkedHashMap_LinkedEntrySet) ForEach_Consumer__V(action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var mc int32 = t.F_this_0.F_modCount
	if t.F_reversed {
		var e LinkedHashMap_Entry_I = t.F_this_0.F_tail; L1: for {
			if !(e == nil) { action.Accept_O__V(e); e = e.Self_LinkedHashMap_Entry().F_before; continue L1 }
//line :422:1
			break L1 } } else {

				var e_2 LinkedHashMap_Entry_I = t.F_this_0.F_head; L2: for {
					if !(e_2 == nil) { action.Accept_O__V(e_2); e_2 = e_2.Self_LinkedHashMap_Entry().F_after; continue L2 }
//line :424:1
					break L2
				} }
	if t.F_this_0.F_modCount == mc { } else {
		panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *LinkedHashMap_LinkedEntrySet) Nsee_HashMap_Node__HashMap_Node(e HashMap_Node_I) HashMap_Node_I {
	if e == nil { panic(Thrown(NoSuchElementException_New())) } else { return e
	} }
func (t *LinkedHashMap_LinkedEntrySet) AddFirst_Map_Entry__V(e Map_Entry) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *LinkedHashMap_LinkedEntrySet) AddLast_Map_Entry__V(e Map_Entry) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *LinkedHashMap_LinkedEntrySet) GetFirst__Map_Entry() Map_Entry {
	var tmp1 HashMap_Node_I; if t.F_reversed { tmp1 = t.F_this_0.F_tail } else { tmp1 = t.F_this_0.F_head }; return t.Nsee_HashMap_Node__HashMap_Node(tmp1)
}
func (t *LinkedHashMap_LinkedEntrySet) GetLast__Map_Entry() Map_Entry {
	var tmp1 HashMap_Node_I; if t.F_reversed { tmp1 = t.F_this_0.F_head } else { tmp1 = t.F_this_0.F_tail }; return t.Nsee_HashMap_Node__HashMap_Node(tmp1)
}
func (t *LinkedHashMap_LinkedEntrySet) RemoveFirst__Map_Entry() Map_Entry {
	var node HashMap_Node_I; var tmp1 HashMap_Node_I; if t.F_reversed { tmp1 = t.F_this_0.F_tail } else { tmp1 = t.F_this_0.F_head }; node = t.Nsee_HashMap_Node__HashMap_Node(tmp1)
	var tmp2 int32 = node.Self_HashMap_Node().F_hash; NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp2, node.Self_HashMap_Node().F_key, nil, false, false)
//line :445:1
	return node
}


func (t *LinkedHashMap_LinkedEntrySet) RemoveLast__Map_Entry() Map_Entry {
	var node HashMap_Node_I; var tmp1 HashMap_Node_I; if t.F_reversed { tmp1 = t.F_this_0.F_head } else { tmp1 = t.F_this_0.F_tail }; node = t.Nsee_HashMap_Node__HashMap_Node(tmp1)
	var tmp2 int32 = node.Self_HashMap_Node().F_hash; NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp2, node.Self_HashMap_Node().F_key, nil, false, false)
//line :450:1
	return node
}


func (t *LinkedHashMap_LinkedEntrySet) Reversed__SequencedSet() SequencedSet {
	if t.F_reversed { return NN(t.F_this_0).SequencedEntrySet__SequencedSet() } else { return LinkedHashMap_LinkedEntrySet_New_LinkedHashMap_Z(t.F_this_0, true)
	} }
func (t *LinkedHashMap) ForEach_BiConsumer__V(action BiConsumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var mc int32 = t.F_modCount; var e LinkedHashMap_Entry_I = t.F_head
L1: for {
	if !(e == nil) { var tmp1 any = e.Self_HashMap_Node().F_key; action.Accept_O_O__V(tmp1, e.Self_HashMap_Node().F_value); e = e.Self_LinkedHashMap_Entry().F_after; continue L1 }
//line :460:1
	break L1
}
	if t.F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *LinkedHashMap) ReplaceAll_BiFunction__V(function BiFunction) {

	if function == nil { panic(Thrown(NullPointerException_New())) }
	var mc int32 = t.F_modCount; var e LinkedHashMap_Entry_I = t.F_head
L1: for {
	if !(e == nil) {
		var tmp1 any = e.Self_HashMap_Node().F_key; e.Self_HashMap_Node().F_value = function.Apply_O_O__O(tmp1, e.Self_HashMap_Node().F_value)
		e = e.Self_LinkedHashMap_Entry().F_after; continue L1 }
//line :468:1
	break L1
}


	if t.F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
	}
}








func (t *LinkedHashMap_LinkedHashIterator) Ctor_LinkedHashMap_Z(this LinkedHashMap_LinkedHashIterator_I, this_0 *LinkedHashMap, reversed bool) { NN(this_0); t.F_this_0 = this_0
	t.F_reversed = reversed
	var tmp1 LinkedHashMap_Entry_I; if reversed { tmp1 = this_0.F_tail } else { tmp1 = this_0.F_head }; t.F_next = tmp1
	t.F_expectedModCount = this_0.F_modCount
	t.F_current = nil
}
func (t *LinkedHashMap_LinkedHashIterator) Impl_HasNext__Z(this LinkedHashMap_LinkedHashIterator_I) bool { return !(t.F_next == nil) }

func (t *LinkedHashMap_LinkedHashIterator) Impl_NextNode__LinkedHashMap_Entry(this LinkedHashMap_LinkedHashIterator_I) LinkedHashMap_Entry_I {
	var e LinkedHashMap_Entry_I = t.F_next
	if t.F_this_0.F_modCount == t.F_expectedModCount { } else {
		panic(Thrown(ConcurrentModificationException_New())) }
	if e == nil { panic(Thrown(NoSuchElementException_New())) }
	t.F_current = e
	var tmp1 LinkedHashMap_Entry_I; if t.F_reversed { tmp1 = e.Self_LinkedHashMap_Entry().F_before } else { tmp1 = e.Self_LinkedHashMap_Entry().F_after }; t.F_next = tmp1
//line :492:1
	return e
}






func (t *LinkedHashMap_LinkedHashIterator) Impl_Remove__V(this LinkedHashMap_LinkedHashIterator_I) {
	var p HashMap_Node_I = t.F_current
	if p == nil { panic(Thrown(IllegalStateException_New())) }
	if t.F_this_0.F_modCount == t.F_expectedModCount { } else {
		panic(Thrown(ConcurrentModificationException_New())) }
	t.F_current = nil
	var tmp1 int32 = p.Self_HashMap_Node().F_hash; NN(t.F_this_0).RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp1, p.Self_HashMap_Node().F_key, nil, false, false)
	t.F_expectedModCount = t.F_this_0.F_modCount
}




func LinkedHashMap_LinkedKeyIterator_New_LinkedHashMap_Z(p0 *LinkedHashMap, p1 bool) *LinkedHashMap_LinkedKeyIterator { t := &LinkedHashMap_LinkedKeyIterator{}; t.Ctor_LinkedHashMap_Z(p0, p1); return t }
//line :513:1
func (t *LinkedHashMap_LinkedKeyIterator) Ctor_LinkedHashMap_Z(this_0 *LinkedHashMap, reversed bool) { NN(this_0); t.F_this_0 = this_0; t.LinkedHashMap_LinkedHashIterator.Ctor_LinkedHashMap_Z(t, this_0, reversed) }

func (t *LinkedHashMap_LinkedKeyIterator) Next__O() any { return t.NextNode__LinkedHashMap_Entry().GetKey__O() }





func LinkedHashMap_LinkedValueIterator_New_LinkedHashMap_Z(p0 *LinkedHashMap, p1 bool) *LinkedHashMap_LinkedValueIterator { t := &LinkedHashMap_LinkedValueIterator{}; t.Ctor_LinkedHashMap_Z(p0, p1); return t }
//line :521:1
func (t *LinkedHashMap_LinkedValueIterator) Ctor_LinkedHashMap_Z(this_0 *LinkedHashMap, reversed bool) { NN(this_0); t.F_this_0 = this_0; t.LinkedHashMap_LinkedHashIterator.Ctor_LinkedHashMap_Z(t, this_0, reversed) }

func (t *LinkedHashMap_LinkedValueIterator) Next__O() any { return t.NextNode__LinkedHashMap_Entry().Self_HashMap_Node().F_value }





func LinkedHashMap_LinkedEntryIterator_New_LinkedHashMap_Z(p0 *LinkedHashMap, p1 bool) *LinkedHashMap_LinkedEntryIterator { t := &LinkedHashMap_LinkedEntryIterator{}; t.Ctor_LinkedHashMap_Z(p0, p1); return t }
//line :529:1
func (t *LinkedHashMap_LinkedEntryIterator) Ctor_LinkedHashMap_Z(this_0 *LinkedHashMap, reversed bool) { NN(this_0); t.F_this_0 = this_0; t.LinkedHashMap_LinkedHashIterator.Ctor_LinkedHashMap_Z(t, this_0, reversed) }

func (t *LinkedHashMap_LinkedEntryIterator) Next__Map_Entry() Map_Entry {
	return t.NextNode__LinkedHashMap_Entry()
}
func LinkedHashMap_NewLinkedHashMap_I__LinkedHashMap(numMappings int32) *LinkedHashMap {
	if numMappings < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2692, StrOfInt(numMappings))))) }
	return LinkedHashMap_New_I(HashMap_CalculateHashMapCapacity_I__I(numMappings))
}
func (t *LinkedHashMap) Reversed__SequencedMap() SequencedMap {
	return LinkedHashMap_ReversedLinkedHashMapView_New_LinkedHashMap(t)
}







func LinkedHashMap_ReversedLinkedHashMapView_New_LinkedHashMap(p0 *LinkedHashMap) *LinkedHashMap_ReversedLinkedHashMapView { t := &LinkedHashMap_ReversedLinkedHashMapView{}; t.Ctor_LinkedHashMap(p0); return t }
//line :549:1
func (t *LinkedHashMap_ReversedLinkedHashMapView) Ctor_LinkedHashMap(lhm *LinkedHashMap) { t.AbstractMap.Ctor(t); t.F_base = lhm }

func (t *LinkedHashMap_ReversedLinkedHashMapView) Equals_O__Z(o any) bool { return NN(t.F_base).Equals_O__Z(o) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) HashCode__I() int32 { return NN(t.F_base).HashCode__I() }

func (t *LinkedHashMap_ReversedLinkedHashMapView) Size__I() int32 { return NN(t.F_base).Size__I() }

func (t *LinkedHashMap_ReversedLinkedHashMapView) IsEmpty__Z() bool { return NN(t.F_base).IsEmpty__Z() }

func (t *LinkedHashMap_ReversedLinkedHashMapView) ContainsKey_O__Z(key any) bool {
	return NN(t.F_base).ContainsKey_O__Z(key)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) ContainsValue_O__Z(value any) bool {
	return NN(t.F_base).ContainsValue_O__Z(value)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Get_O__O(key any) any { return NN(t.F_base).Get_O__O(key) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) Put_O_O__O(key, value any) any { return NN(t.F_base).Put_O_O__O(key, value) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) Remove_O__O(key any) any { return NN(t.F_base).Remove_O__O(key) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) PutAll_Map__V(m Map) {
	NN(t.F_base).PutAll_Map__V(m)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Clear__V() { NN(t.F_base).Clear__V() }

func (t *LinkedHashMap_ReversedLinkedHashMapView) KeySet__Set() Set {
	return NN(t.F_base).SequencedKeySet__SequencedSet().Reversed__SequencedSet()
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Values__Collection() Collection {
	return NN(t.F_base).SequencedValues__SequencedCollection().Reversed__SequencedCollection()
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) EntrySet__Set() Set {
	return NN(t.F_base).SequencedEntrySet__SequencedSet().Reversed__SequencedSet()
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) GetOrDefault_O_O__O(key, defaultValue any) any {
	return NN(t.F_base).GetOrDefault_O_O__O(key, defaultValue)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) ForEach_BiConsumer__V(action BiConsumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var mc int32 = t.F_base.F_modCount; var e LinkedHashMap_Entry_I = t.F_base.F_tail
L1: for {
	if !(e == nil) { var tmp1 any = e.Self_HashMap_Node().F_key; action.Accept_O_O__V(tmp1, e.Self_HashMap_Node().F_value); e = e.Self_LinkedHashMap_Entry().F_before; continue L1 }
//line :591:1
	break L1
}
	if t.F_base.F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *LinkedHashMap_ReversedLinkedHashMapView) ReplaceAll_BiFunction__V(function BiFunction) {

	if function == nil { panic(Thrown(NullPointerException_New())) }
	var mc int32 = t.F_base.F_modCount; var e LinkedHashMap_Entry_I = t.F_base.F_tail
L1: for {
	if !(e == nil) {
		var tmp1 any = e.Self_HashMap_Node().F_key; e.Self_HashMap_Node().F_value = function.Apply_O_O__O(tmp1, e.Self_HashMap_Node().F_value)
		e = e.Self_LinkedHashMap_Entry().F_before; continue L1 }
//line :599:1
	break L1
}


	if t.F_base.F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *LinkedHashMap_ReversedLinkedHashMapView) PutIfAbsent_O_O__O(key, value any) any {
	return NN(t.F_base).PutIfAbsent_O_O__O(key, value)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Remove_O_O__Z(key, value any) bool {
	return NN(t.F_base).Remove_O_O__Z(key, value)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Replace_O_O_O__Z(key, oldValue, newValue any) bool {
	return NN(t.F_base).Replace_O_O_O__Z(key, oldValue, newValue)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Replace_O_O__O(key, value any) any {
	return NN(t.F_base).Replace_O_O__O(key, value)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) ComputeIfAbsent_O_Function__O(key any, mappingFunction Function) any {

	return NN(t.F_base).ComputeIfAbsent_O_Function__O(key, mappingFunction)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) ComputeIfPresent_O_BiFunction__O(key any, remappingFunction BiFunction) any {

	return NN(t.F_base).ComputeIfPresent_O_BiFunction__O(key, remappingFunction)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Compute_O_BiFunction__O(key any, remappingFunction BiFunction) any {

	return NN(t.F_base).Compute_O_BiFunction__O(key, remappingFunction)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Merge_O_O_BiFunction__O(key, value any, remappingFunction BiFunction) any {

	return NN(t.F_base).Merge_O_O_BiFunction__O(key, value, remappingFunction)
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) Reversed__SequencedMap() SequencedMap { return Up_LinkedHashMap_SequencedMap(t.F_base) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) FirstEntry__Map_Entry() Map_Entry {
	return NN(t.F_base).LastEntry__Map_Entry()
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) LastEntry__Map_Entry() Map_Entry {
	return NN(t.F_base).FirstEntry__Map_Entry()
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) PollFirstEntry__Map_Entry() Map_Entry {
	return NN(t.F_base).PollLastEntry__Map_Entry()
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) PollLastEntry__Map_Entry() Map_Entry {
	return NN(t.F_base).PollFirstEntry__Map_Entry()
}
func (t *LinkedHashMap_ReversedLinkedHashMapView) PutFirst_O_O__O(k, v any) any { return NN(t.F_base).PutLast_O_O__O(k, v) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) PutLast_O_O__O(k, v any) any { return NN(t.F_base).PutFirst_O_O__O(k, v) }



type LinkedHashMap struct{ HashMap; F_head, F_tail LinkedHashMap_Entry_I; F_accessOrder bool; F_putMode int32 }

func (t *LinkedHashMap) Is_SequencedMap() {}

const LinkedHashMap_serialVersionUID int64 = 3801124242820219131

const LinkedHashMap_PUT_NORM int32 = 0

const LinkedHashMap_PUT_FIRST int32 = 1

const LinkedHashMap_PUT_LAST int32 = 2

func (t *LinkedHashMap) PutMapEntries_Map_Z__V(p0 Map, p1 bool) { t.Impl_PutMapEntries_Map_Z__V(t, p0, p1) }

func (t *LinkedHashMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *LinkedHashMap) PutVal_I_O_O_Z_Z__O(p0 int32, p1, p2 any, p3, p4 bool) any { return t.Impl_PutVal_I_O_O_Z_Z__O(t, p0, p1, p2, p3, p4) }

func (t *LinkedHashMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *LinkedHashMap) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *LinkedHashMap) TreeifyBin_HashMap_Node1_I__V(p0 *RefArray, p1 int32) { t.Impl_TreeifyBin_HashMap_Node1_I__V(t, p0, p1) }

func (t *LinkedHashMap) PollFirstEntry__Map_Entry() Map_Entry { return SequencedMap_PollFirstEntry__Map_Entry(t) }

func (t *LinkedHashMap) FirstEntry__Map_Entry() Map_Entry { return SequencedMap_FirstEntry__Map_Entry(t) }

func (t *LinkedHashMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *LinkedHashMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *LinkedHashMap) RemoveNode_I_O_O_Z_Z__HashMap_Node(p0 int32, p1, p2 any, p3, p4 bool) HashMap_Node_I { return t.Impl_RemoveNode_I_O_O_Z_Z__HashMap_Node(t, p0, p1, p2, p3, p4) }

func (t *LinkedHashMap) LastEntry__Map_Entry() Map_Entry { return SequencedMap_LastEntry__Map_Entry(t) }

func (t *LinkedHashMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *LinkedHashMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *LinkedHashMap) Resize__HashMap_Node1() *RefArray { return t.Impl_Resize__HashMap_Node1(t) }

func (t *LinkedHashMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *LinkedHashMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *LinkedHashMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *LinkedHashMap) PollLastEntry__Map_Entry() Map_Entry { return SequencedMap_PollLastEntry__Map_Entry(t) }

func (t *LinkedHashMap) ValuesToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ValuesToArray_O1__O1(t, p0) }

func (t *LinkedHashMap) GetNode_O__HashMap_Node(p0 any) HashMap_Node_I { return t.Impl_GetNode_O__HashMap_Node(t, p0) }

func (t *LinkedHashMap) LoadFactor__F() float32 { return t.Impl_LoadFactor__F(t) }

func (t *LinkedHashMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *LinkedHashMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *LinkedHashMap) PrepareArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_PrepareArray_O1__O1(t, p0) }

func (t *LinkedHashMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *LinkedHashMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *LinkedHashMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *LinkedHashMap) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *LinkedHashMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *LinkedHashMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *LinkedHashMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashMap) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap) GetClass__Class() *Class { return LinkedHashMap_class }

func (t *LinkedHashMap) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func LinkedHashMap_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap); return ok }

func LinkedHashMap_Cast(x any) *LinkedHashMap { if x == nil { return nil }; v, ok := x.(*LinkedHashMap); if !ok { panic(ClassCast(x, LinkedHashMap_class)) }; return v }



type LinkedHashMap_Entry struct{ HashMap_Node; F_before, F_after LinkedHashMap_Entry_I }

type LinkedHashMap_Entry_I interface{ HashMap_Node_I; Map_Entry; Self_LinkedHashMap_Entry() *LinkedHashMap_Entry }

func (t *LinkedHashMap_Entry) Self_LinkedHashMap_Entry() *LinkedHashMap_Entry { return t }

func (t *LinkedHashMap_Entry) GetKey__O() any { return t.Impl_GetKey__O(t) }

func (t *LinkedHashMap_Entry) GetValue__O() any { return t.Impl_GetValue__O(t) }

func (t *LinkedHashMap_Entry) SetValue_O__O(p0 any) any { return t.Impl_SetValue_O__O(t, p0) }

func (t *LinkedHashMap_Entry) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *LinkedHashMap_Entry) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *LinkedHashMap_Entry) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashMap_Entry) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_Entry) GetClass__Class() *Class { return LinkedHashMap_Entry_class }

func (t *LinkedHashMap_Entry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashMap_Entry) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_Entry_InstanceOf(x any) bool { _, ok := x.(LinkedHashMap_Entry_I); return ok }

func LinkedHashMap_Entry_Cast(x any) LinkedHashMap_Entry_I { if x == nil { return nil }; v, ok := x.(LinkedHashMap_Entry_I); if !ok { panic(ClassCast(x, LinkedHashMap_Entry_class)) }; return v }



type LinkedHashMap_LinkedEntryIterator struct{ LinkedHashMap_LinkedHashIterator; F_this_0 *LinkedHashMap }

func (t *LinkedHashMap_LinkedEntryIterator) Is_Iterator() {}

func (t *LinkedHashMap_LinkedEntryIterator) Next__O() any { return t.Next__Map_Entry() }

func (t *LinkedHashMap_LinkedEntryIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *LinkedHashMap_LinkedEntryIterator) NextNode__LinkedHashMap_Entry() LinkedHashMap_Entry_I { return t.Impl_NextNode__LinkedHashMap_Entry(t) }

func (t *LinkedHashMap_LinkedEntryIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *LinkedHashMap_LinkedEntryIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *LinkedHashMap_LinkedEntryIterator) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_LinkedEntryIterator) GetClass__Class() *Class { return LinkedHashMap_LinkedEntryIterator_class }

func (t *LinkedHashMap_LinkedEntryIterator) ToString__String() *String { return Object_toString(t) }

func (t *LinkedHashMap_LinkedEntryIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashMap_LinkedEntryIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_LinkedEntryIterator_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap_LinkedEntryIterator); return ok }

func LinkedHashMap_LinkedEntryIterator_Cast(x any) *LinkedHashMap_LinkedEntryIterator { if x == nil { return nil }; v, ok := x.(*LinkedHashMap_LinkedEntryIterator); if !ok { panic(ClassCast(x, LinkedHashMap_LinkedEntryIterator_class)) }; return v }



type LinkedHashMap_LinkedEntrySet struct{ AbstractSet; F_reversed bool; F_this_0 *LinkedHashMap }

func (t *LinkedHashMap_LinkedEntrySet) Is_SequencedSet() {}

func (t *LinkedHashMap_LinkedEntrySet) Is_SequencedCollection() {}

func (t *LinkedHashMap_LinkedEntrySet) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *LinkedHashMap_LinkedEntrySet) AddFirst_O__V(p0 any) { t.AddFirst_Map_Entry__V(Map_Entry_Cast(p0)) }

func (t *LinkedHashMap_LinkedEntrySet) AddLast_O__V(p0 any) { t.AddLast_Map_Entry__V(Map_Entry_Cast(p0)) }

func (t *LinkedHashMap_LinkedEntrySet) GetFirst__O() any { return t.GetFirst__Map_Entry() }

func (t *LinkedHashMap_LinkedEntrySet) GetLast__O() any { return t.GetLast__Map_Entry() }

func (t *LinkedHashMap_LinkedEntrySet) RemoveFirst__O() any { return t.RemoveFirst__Map_Entry() }

func (t *LinkedHashMap_LinkedEntrySet) RemoveLast__O() any { return t.RemoveLast__Map_Entry() }

func (t *LinkedHashMap_LinkedEntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *LinkedHashMap_LinkedEntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *LinkedHashMap_LinkedEntrySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *LinkedHashMap_LinkedEntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *LinkedHashMap_LinkedEntrySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *LinkedHashMap_LinkedEntrySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *LinkedHashMap_LinkedEntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashMap_LinkedEntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_LinkedEntrySet) GetClass__Class() *Class { return LinkedHashMap_LinkedEntrySet_class }

func (t *LinkedHashMap_LinkedEntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashMap_LinkedEntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_LinkedEntrySet_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap_LinkedEntrySet); return ok }

func LinkedHashMap_LinkedEntrySet_Cast(x any) *LinkedHashMap_LinkedEntrySet { if x == nil { return nil }; v, ok := x.(*LinkedHashMap_LinkedEntrySet); if !ok { panic(ClassCast(x, LinkedHashMap_LinkedEntrySet_class)) }; return v }



type LinkedHashMap_LinkedHashIterator struct{ Object; F_next, F_current LinkedHashMap_Entry_I; F_expectedModCount int32; F_reversed bool; F_this_0 *LinkedHashMap }

type LinkedHashMap_LinkedHashIterator_I interface{ Object_I; Self_LinkedHashMap_LinkedHashIterator() *LinkedHashMap_LinkedHashIterator; HasNext__Z() bool; NextNode__LinkedHashMap_Entry() LinkedHashMap_Entry_I; Remove__V() }

func (t *LinkedHashMap_LinkedHashIterator) Self_LinkedHashMap_LinkedHashIterator() *LinkedHashMap_LinkedHashIterator { return t }

func LinkedHashMap_LinkedHashIterator_InstanceOf(x any) bool { _, ok := x.(LinkedHashMap_LinkedHashIterator_I); return ok }

func LinkedHashMap_LinkedHashIterator_Cast(x any) LinkedHashMap_LinkedHashIterator_I { if x == nil { return nil }; v, ok := x.(LinkedHashMap_LinkedHashIterator_I); if !ok { panic(ClassCast(x, LinkedHashMap_LinkedHashIterator_class)) }; return v }



type LinkedHashMap_LinkedKeyIterator struct{ LinkedHashMap_LinkedHashIterator; F_this_0 *LinkedHashMap }

func (t *LinkedHashMap_LinkedKeyIterator) Is_Iterator() {}

func (t *LinkedHashMap_LinkedKeyIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *LinkedHashMap_LinkedKeyIterator) NextNode__LinkedHashMap_Entry() LinkedHashMap_Entry_I { return t.Impl_NextNode__LinkedHashMap_Entry(t) }

func (t *LinkedHashMap_LinkedKeyIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *LinkedHashMap_LinkedKeyIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *LinkedHashMap_LinkedKeyIterator) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_LinkedKeyIterator) GetClass__Class() *Class { return LinkedHashMap_LinkedKeyIterator_class }

func (t *LinkedHashMap_LinkedKeyIterator) ToString__String() *String { return Object_toString(t) }

func (t *LinkedHashMap_LinkedKeyIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashMap_LinkedKeyIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_LinkedKeyIterator_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap_LinkedKeyIterator); return ok }

func LinkedHashMap_LinkedKeyIterator_Cast(x any) *LinkedHashMap_LinkedKeyIterator { if x == nil { return nil }; v, ok := x.(*LinkedHashMap_LinkedKeyIterator); if !ok { panic(ClassCast(x, LinkedHashMap_LinkedKeyIterator_class)) }; return v }



type LinkedHashMap_LinkedKeySet struct{ AbstractSet; F_reversed bool; F_this_0 *LinkedHashMap }

func (t *LinkedHashMap_LinkedKeySet) Is_SequencedSet() {}

func (t *LinkedHashMap_LinkedKeySet) Is_SequencedCollection() {}

func (t *LinkedHashMap_LinkedKeySet) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *LinkedHashMap_LinkedKeySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *LinkedHashMap_LinkedKeySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *LinkedHashMap_LinkedKeySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *LinkedHashMap_LinkedKeySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *LinkedHashMap_LinkedKeySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *LinkedHashMap_LinkedKeySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashMap_LinkedKeySet) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_LinkedKeySet) GetClass__Class() *Class { return LinkedHashMap_LinkedKeySet_class }

func (t *LinkedHashMap_LinkedKeySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashMap_LinkedKeySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_LinkedKeySet_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap_LinkedKeySet); return ok }

func LinkedHashMap_LinkedKeySet_Cast(x any) *LinkedHashMap_LinkedKeySet { if x == nil { return nil }; v, ok := x.(*LinkedHashMap_LinkedKeySet); if !ok { panic(ClassCast(x, LinkedHashMap_LinkedKeySet_class)) }; return v }



type LinkedHashMap_LinkedValueIterator struct{ LinkedHashMap_LinkedHashIterator; F_this_0 *LinkedHashMap }

func (t *LinkedHashMap_LinkedValueIterator) Is_Iterator() {}

func (t *LinkedHashMap_LinkedValueIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *LinkedHashMap_LinkedValueIterator) NextNode__LinkedHashMap_Entry() LinkedHashMap_Entry_I { return t.Impl_NextNode__LinkedHashMap_Entry(t) }

func (t *LinkedHashMap_LinkedValueIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *LinkedHashMap_LinkedValueIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *LinkedHashMap_LinkedValueIterator) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_LinkedValueIterator) GetClass__Class() *Class { return LinkedHashMap_LinkedValueIterator_class }

func (t *LinkedHashMap_LinkedValueIterator) ToString__String() *String { return Object_toString(t) }

func (t *LinkedHashMap_LinkedValueIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashMap_LinkedValueIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_LinkedValueIterator_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap_LinkedValueIterator); return ok }

func LinkedHashMap_LinkedValueIterator_Cast(x any) *LinkedHashMap_LinkedValueIterator { if x == nil { return nil }; v, ok := x.(*LinkedHashMap_LinkedValueIterator); if !ok { panic(ClassCast(x, LinkedHashMap_LinkedValueIterator_class)) }; return v }



type LinkedHashMap_LinkedValues struct{ AbstractCollection; F_reversed bool; F_this_0 *LinkedHashMap }

func (t *LinkedHashMap_LinkedValues) Is_SequencedCollection() {}

func (t *LinkedHashMap_LinkedValues) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *LinkedHashMap_LinkedValues) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedValues) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *LinkedHashMap_LinkedValues) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *LinkedHashMap_LinkedValues) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedValues) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *LinkedHashMap_LinkedValues) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedValues) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *LinkedHashMap_LinkedValues) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *LinkedHashMap_LinkedValues) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *LinkedHashMap_LinkedValues) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *LinkedHashMap_LinkedValues) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashMap_LinkedValues) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_LinkedValues) GetClass__Class() *Class { return LinkedHashMap_LinkedValues_class }

func (t *LinkedHashMap_LinkedValues) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashMap_LinkedValues) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_LinkedValues_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap_LinkedValues); return ok }

func LinkedHashMap_LinkedValues_Cast(x any) *LinkedHashMap_LinkedValues { if x == nil { return nil }; v, ok := x.(*LinkedHashMap_LinkedValues); if !ok { panic(ClassCast(x, LinkedHashMap_LinkedValues_class)) }; return v }



type LinkedHashMap_ReversedLinkedHashMapView struct{ AbstractMap; F_base *LinkedHashMap }

func (t *LinkedHashMap_ReversedLinkedHashMapView) Is_SequencedMap() {}

func (t *LinkedHashMap_ReversedLinkedHashMapView) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashMap_ReversedLinkedHashMapView) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashMap_ReversedLinkedHashMapView) GetClass__Class() *Class { return LinkedHashMap_ReversedLinkedHashMapView_class }

func (t *LinkedHashMap_ReversedLinkedHashMapView) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashMap_ReversedLinkedHashMapView_InstanceOf(x any) bool { _, ok := x.(*LinkedHashMap_ReversedLinkedHashMapView); return ok }

func LinkedHashMap_ReversedLinkedHashMapView_Cast(x any) *LinkedHashMap_ReversedLinkedHashMapView { if x == nil { return nil }; v, ok := x.(*LinkedHashMap_ReversedLinkedHashMapView); if !ok { panic(ClassCast(x, LinkedHashMap_ReversedLinkedHashMapView_class)) }; return v }
