//line java_math_BigDecimal.ae:1
package jrt

import "sync/atomic"






































































































func BigDecimal_New_BigInteger_J_I_I(p0 *BigInteger, p1 int64, p2, p3 int32) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_BigInteger_J_I_I(p0, p1, p2, p3); return t }
//line :106:1
func (t *BigDecimal) Ctor_BigInteger_J_I_I(intVal *BigInteger, val int64, scale, prec int32) { t.Number.Ctor(t)
	t.F_scale = scale
	t.F_precision = prec
	t.F_intCompact = val
	t.F_intVal = intVal
}
func BigDecimal_New_C1_I_I(p0 *CharArray, p1, p2 int32) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_C1_I_I(p0, p1, p2); return t }
//line :112:1
func (t *BigDecimal) Ctor_C1_I_I(in *CharArray, offset, len_ int32) { var tmp1 *MathContext; MathContext_Init(); tmp1 = MathContext_UNLIMITED; t.Ctor_C1_I_I_MathContext(in, offset, len_, tmp1) }


func BigDecimal_New_C1_I_I_MathContext(p0 *CharArray, p1, p2 int32, p3 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_C1_I_I_MathContext(p0, p1, p2, p3); return t }
//line :115:1
func (t *BigDecimal) Ctor_C1_I_I_MathContext(in *CharArray, offset, len_ int32, mc *MathContext) { t.Number.Ctor(t); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	Objects_CheckFromIndexSize_I_I_I__I(offset, len_, int32(len(in.A)))
//line :115:1
	return nil }(); if
	tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = e


		panic(Thrown(NumberFormatException_New_String(Lit_1208))) } else {
//line :116:1
			panic(tmp1) } }; var prec int32 = 0; var scl int64 = 0; var rs int64 = 0; var rb /*line :120:1*/*BigInteger; tmp29 := func() (exc Throwable_I) { defer Catch(&exc)




				{ var isneg bool = false
					if int32(in.A[offset]) == 45 {

						isneg = true
						offset = offset + 1
						len_ = len_ - 1 } else {
							if int32(in.A[offset]) == 43 {
								offset = offset + 1
								len_ = len_ - 1 } }
					var dot bool = false; var c uint16 = 0; var isCompact bool = len_ <= 18
					var idx int32 = 0


					if isCompact {

					L1: for { if len_ > 0 {
						c = in.A[offset]
						if int32(c) == 48 {


							if prec == 0 {
								prec = 1 } else {
									if rs == 0 { } else {
										rs = rs * 10
										prec = prec + 1 } }
							if dot { scl = scl + 1 } } else {
//line :142:1
								var tmp2 bool; var tmp3 bool








								tmp3 = int32(c) >= 49; if tmp3 { tmp3 = int32(c) <= 57 }; tmp2 = tmp3
//line :142:1
								if tmp2 {









									var digit int32 = int32(c) - 48; var tmp4 bool; var tmp5 bool
									tmp5 = !(prec == 1); if !tmp5 { tmp5 = !(rs == 0) }; tmp4 = tmp5; if tmp4 {
										prec = prec + 1 }
									rs = rs*10 + int64(digit)
									if dot { scl = scl + 1 } } else {
//line :142:1
										if int32(c) == 46 {
















											if dot {
												panic(Thrown(NumberFormatException_New_String(Lit_1209)))
											}
											dot = true } else {
//line :142:1
												if Character_IsDigit_C__Z(c) {





















													var digit_2 int32 = Character_Digit_C_I__I(c, 10)
													if digit_2 == 0 {
														if prec == 0 {
															prec = 1 } else {
																if rs == 0 { } else {
																	rs = rs * 10
																	prec = prec + 1 } } } else {

																		var tmp6 bool; var tmp7 bool; tmp7 = !(prec == 1); if !tmp7 { tmp7 = !(rs == 0) }; tmp6 = tmp7; if tmp6 {
																			prec = prec + 1 }
																		rs = rs*10 + int64(digit_2) }
													if dot { scl = scl + 1 } } else {
//line :142:1
														var tmp8 bool; var tmp9 bool

































														tmp9 = int32(c) == 101; if !tmp9 { tmp9 = int32(c) == 69 }; tmp8 = tmp9
//line :142:1
														if tmp8 {



































															scl = scl - BigDecimal_ParseExp_C1_I_I__J(in, offset, len_)
															break L1 } else {

																panic(Thrown(NumberFormatException_New_String(Concat(Lit_1210, StrOfChar(c), Lit_1211))))
															}
													}
											}
									}
							}
						offset = offset + 1
						len_ = len_ - 1
//line :140:1
						continue L1 }; break L1
					}















































						if prec == 0 { panic(Thrown(NumberFormatException_New_String(Lit_1212))) }
						var tmp10 int64; if isneg { tmp10 = -rs } else { tmp10 = rs }; rs = tmp10
						var mcp int32 = mc.F_precision; var drop int32 = prec - mcp; var tmp11 bool; var tmp12 bool

						tmp12 = mcp > 0; if tmp12 { tmp12 = drop > 0 }; tmp11 = tmp12; if tmp11 {
						L2: for { if drop > 0 {
							scl = scl - int64(drop)
							var tmp13 int64 = rs; var tmp14 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop]; rs = BigDecimal_DivideAndRound_J_J_I__J(tmp13, tmp14, mc.F_roundingMode.F_oldMode)




							prec = BigDecimal_LongDigitLength_J__I(rs)
							drop = prec - mcp
//line :194:1
							continue L2 }; break L2 } } } else {








								var coeff *CharArray = NewCharArray(len_)
							L3: for { if len_ > 0 {
								c = in.A[offset]
								var tmp15 bool; var tmp16 bool; var tmp17 bool
								tmp17 = int32(c) >= 48; if tmp17 { tmp17 = int32(c) <= 57 }; tmp16 = tmp17; if !tmp16 { tmp16 = Character_IsDigit_C__Z(c) }; tmp15 = tmp16
//line :206:1
								if tmp15 {


									var tmp18 bool; var tmp19 bool; tmp19 = int32(c) == 48; if !tmp19 { tmp19 = Character_Digit_C_I__I(c, 10) == 0 }; tmp18 = tmp19; if tmp18 {
										if prec == 0 {
											coeff.A[idx] = c; prec = 1 } else {
												if idx == 0 { } else {
													coeff.A[idx] = c
													idx = idx + 1
													prec = prec + 1 } } } else {

														var tmp20 bool; var tmp21 bool; tmp21 = !(prec == 1); if !tmp21 { tmp21 = !(idx == 0) }; tmp20 = tmp21; if tmp20 {
															prec = prec + 1 }
														coeff.A[idx] = c
														idx = idx + 1 }
									if dot { scl = scl + 1 } } else {
//line :206:1
										if int32(c) == 46 {

















											if dot {
												panic(Thrown(NumberFormatException_New_String(Lit_1209)))
											}
											dot = true } else {


												var tmp22 bool; var tmp23 bool; tmp23 = !(int32(c) == 101); if tmp23 { tmp23 = !(int32(c) == 69) }; tmp22 = tmp23; if tmp22 {
													panic(Thrown(NumberFormatException_New_String(Lit_1213)))
												}
												scl = scl - BigDecimal_ParseExp_C1_I_I__J(in, offset, len_)
												break L3 } }
								offset = offset + 1
								len_ = len_ - 1
//line :204:1
								continue L3 }; break L3
							}































								if prec == 0 { panic(Thrown(NumberFormatException_New_String(Lit_1212))) }
								var tmp24 int32; if isneg { tmp24 = -1 } else { tmp24 = 1 }; rb = BigInteger_New_C1_I_I(coeff, tmp24, prec)
								rs = BigDecimal_CompactValFor_BigInteger__J(rb)
								var mcp_2 int32 = mc.F_precision; var tmp25 bool; var tmp26 bool
								tmp26 = mcp_2 > 0; if tmp26 { tmp26 = prec > mcp_2 }; tmp25 = tmp26; if tmp25 {
									if rs == -9223372036854775808 {
										var drop_2 int32 = prec - mcp_2
									L4: for { if drop_2 > 0 {
										scl = scl - int64(drop_2)
										rb = BigDecimal_DivideAndRoundByTenPow_BigInteger_I_I__BigInteger(rb, drop_2, mc.F_roundingMode.F_oldMode)




										rs = BigDecimal_CompactValFor_BigInteger__J(rb)
										if rs == -9223372036854775808 { } else {
											prec = BigDecimal_LongDigitLength_J__I(rs)
											break L4 }
										prec = BigDecimal_BigDigitLength_BigInteger__I(rb)
										drop_2 = prec - mcp_2
//line :244:1
										continue L4 }; break L4
									}
									}










									if rs == -9223372036854775808 { } else {
										var drop_3 int32 = prec - mcp_2
									L5: for { if drop_3 > 0 {
										scl = scl - int64(drop_3)
										var tmp27 int64 = rs; var tmp28 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop_3]; rs = BigDecimal_DivideAndRound_J_J_I__J(tmp27, tmp28, mc.F_roundingMode.F_oldMode)




										prec = BigDecimal_LongDigitLength_J__I(rs)
										drop_3 = prec - mcp_2
//line :259:1
										continue L5 }; break L5
									}







										rb = nil } } } }
//line :120:1
				return nil }(); if



	tmp29 != nil { if ArrayIndexOutOfBoundsException_InstanceOf(tmp29) || NegativeArraySizeException_InstanceOf(tmp29) { var e_2 RuntimeException_I = RuntimeException_Cast(tmp29); var nfe *NumberFormatException = NumberFormatException_New()

















































































































































		NN(nfe).InitCause_Throwable__Throwable(e_2); panic(Thrown(Up_NumberFormatException_Throwable(nfe))) } else {
//line :124:1
			panic(tmp29) } }; if


















































































































































	int64(int32(scl)) == scl { } else { panic(Thrown(NumberFormatException_New_String(Lit_1214))) };
	t.F_scale = int32(scl);
	t.F_precision = prec;
	t.F_intCompact = rs;
	t.F_intVal = rb }

func BigDecimal_ParseExp_C1_I_I__J(in *CharArray, offset, len_ int32) int64 { BigDecimal_Init()
	var exp int64 = 0
	offset = offset + 1
	var c uint16 = in.A[offset]
	len_ = len_ - 1
	var negexp bool = int32(c) == 45; var tmp1 bool; var tmp2 bool
	tmp2 = negexp; if !tmp2 { tmp2 = int32(c) == 43 }; tmp1 = tmp2; if tmp1 {
		offset = offset + 1
		c = in.A[offset]
		len_ = len_ - 1 }
	if len_ <= 0 { panic(Thrown(NumberFormatException_New_String(Lit_1215))) }
L1: for { var tmp3 bool; var tmp4 bool; tmp4 = len_ > 10; if tmp4 { var tmp5 bool; tmp5 = int32(c) == 48; if !tmp5 { tmp5 = Character_Digit_C_I__I(c, 10) == 0 }; tmp4 = tmp5 }; tmp3 = tmp4; if tmp3 {
	offset = offset + 1
	c = in.A[offset]
	len_ = len_ - 1
//line :288:1
	continue L1 }; break L1
}


	if len_ > 10 { panic(Thrown(NumberFormatException_New_String(Lit_1216))) }
L2: for {
	var v int32 = 0; var tmp6 bool; var tmp7 bool
	tmp7 = int32(c) >= 48; if tmp7 { tmp7 = int32(c) <= 57 }; tmp6 = tmp7; if tmp6 {
		v = int32(c) - 48 } else {

			v = Character_Digit_C_I__I(c, 10)
			if v < 0 { panic(Thrown(NumberFormatException_New_String(Lit_1217))) } }
	exp = exp*10 + int64(v)
	if len_ == 1 { break L2 }
	offset = offset + 1
	c = in.A[offset]
	len_ = len_ - 1
//line :293:1
	continue L2
}










	if negexp { exp = -exp }
//line :282:1
	return exp
}
























func BigDecimal_New_C1(p0 *CharArray) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_C1(p0); return t }
//line :308:1
func (t *BigDecimal) Ctor_C1(in *CharArray) { t.Ctor_C1_I_I(in, 0, int32(len(in.A))) }

func BigDecimal_New_C1_MathContext(p0 *CharArray, p1 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_C1_MathContext(p0, p1); return t }
//line :310:1
func (t *BigDecimal) Ctor_C1_MathContext(in *CharArray, mc *MathContext) { t.Ctor_C1_I_I_MathContext(in, 0, int32(len(in.A)), mc) }


func BigDecimal_New_String(p0 *String) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_String(p0); return t }
//line :313:1
func (t *BigDecimal) Ctor_String(val *String) { t.Ctor_C1_I_I(NN(val).ToCharArray__C1(), 0, NN(val).Length__I()) }


func BigDecimal_New_String_MathContext(p0 *String, p1 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_String_MathContext(p0, p1); return t }
//line :316:1
func (t *BigDecimal) Ctor_String_MathContext(val *String, mc *MathContext) { t.Ctor_C1_I_I_MathContext(NN(val).ToCharArray__C1(), 0, NN(val).Length__I(), mc) }


func BigDecimal_New_D(p0 float64) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_D(p0); return t }
//line :319:1
func (t *BigDecimal) Ctor_D(val float64) { var tmp1 *MathContext; MathContext_Init(); tmp1 = MathContext_UNLIMITED; t.Ctor_D_MathContext(val, tmp1) }


func BigDecimal_New_D_MathContext(p0 float64, p1 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_D_MathContext(p0, p1); return t }
//line :322:1
func (t *BigDecimal) Ctor_D_MathContext(val float64, mc *MathContext) { t.Number.Ctor(t)
	var tmp1 bool; var tmp2 bool; tmp2 = Double_IsInfinite_D__Z(val); if !tmp2 { tmp2 = Double_IsNaN_D__Z(val) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NumberFormatException_New_String(Lit_1218))) }
	var valBits int64 = Double_DoubleToLongBits_D__J(val); var sign int32
	if valBits>>63 == 0 { sign = 1 } else { sign = -1 }
//line :325:1
	var exponent int32 = int32(valBits >> 52 & 2047); var significand int64


	if exponent == 0 {
		significand = valBits & 4503599627370495 << 1 } else {


			significand = valBits&4503599627370495 | 4503599627370496
		}


	exponent = exponent - 1075
	if significand == 0 {

		var tmp3 *BigInteger; BigInteger_Init(); tmp3 = BigInteger_ZERO; t.F_intVal = tmp3
		t.F_scale = 0
		t.F_intCompact = 0
		t.F_precision = 1 } else {

		L1: for { if significand&1 == 0 {
			significand = significand >> 1
			exponent = exponent + 1
//line :344:1
			continue L1 }; break L1
		}

			var scl int32 = 0; var rb *BigInteger; var compactVal int64 = int64(sign) * significand


			if exponent == 0 {
				var tmp4 *BigInteger; if compactVal == -9223372036854775808 { tmp4 = BigDecimal_INFLATED_BIGINT } else { tmp4 = nil }; rb = tmp4 } else {

					if exponent < 0 {

						rb = NN(NN(BigInteger_ValueOf_J__BigInteger(5)).Pow_I__BigInteger(-exponent)).Multiply_J__BigInteger(compactVal)




						scl = -exponent } else {
							var tmp5 *BigInteger; BigInteger_Init(); tmp5 = BigInteger_TWO; rb = NN(NN(tmp5).Pow_I__BigInteger(exponent)).Multiply_J__BigInteger(compactVal) }
					compactVal = BigDecimal_CompactValFor_BigInteger__J(rb) }
			var prec int32 = 0; var mcp int32 = mc.F_precision

			if mcp > 0 {
				var mode int32 = mc.F_roundingMode.F_oldMode
				var drop int32 = 0
				if compactVal == -9223372036854775808 {
					prec = BigDecimal_BigDigitLength_BigInteger__I(rb)
					drop = prec - mcp
				L2: for { if drop > 0 {
					scl = BigDecimal_CheckScaleNonZero_J__I(int64(scl) - int64(drop))

					rb = BigDecimal_DivideAndRoundByTenPow_BigInteger_I_I__BigInteger(rb, drop, mode)
					compactVal = BigDecimal_CompactValFor_BigInteger__J(rb)
					if compactVal == -9223372036854775808 { } else { break L2 }
					prec = BigDecimal_BigDigitLength_BigInteger__I(rb)
					drop = prec - mcp
//line :371:1
					continue L2 }; break L2
				}
				}





				if compactVal == -9223372036854775808 { } else {
					prec = BigDecimal_LongDigitLength_J__I(compactVal)
					drop = prec - mcp
				L3: for { if drop > 0 {
					scl = BigDecimal_CheckScaleNonZero_J__I(int64(scl) - int64(drop))

					var tmp6 int64 = compactVal; var tmp7 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop]; compactVal = BigDecimal_DivideAndRound_J_J_I__J(tmp6, tmp7, mc.F_roundingMode.F_oldMode)




					prec = BigDecimal_LongDigitLength_J__I(compactVal)
					drop = prec - mcp
//line :382:1
					continue L3 }; break L3
				}








					rb = nil } }
			t.F_intVal = rb
			t.F_intCompact = compactVal
			t.F_scale = scl
			t.F_precision = prec
		} }
func BigDecimal_ToStrictBigInteger_BigInteger__BigInteger(val *BigInteger) *BigInteger { BigDecimal_Init()
	if NN(val).GetClass__Class() == BigInteger_class { return val } else {

		return BigInteger_New_B1(NN(NN(val).ToByteArray__B1()).Copy())
	} }
func BigDecimal_New_BigInteger(p0 *BigInteger) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_BigInteger(p0); return t }
//line :403:1
func (t *BigDecimal) Ctor_BigInteger(val *BigInteger) { t.Number.Ctor(t)
	t.F_scale = 0
	t.F_intVal = BigDecimal_ToStrictBigInteger_BigInteger__BigInteger(val)
	t.F_intCompact = BigDecimal_CompactValFor_BigInteger__J(t.F_intVal)
}
func BigDecimal_New_BigInteger_MathContext(p0 *BigInteger, p1 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_BigInteger_MathContext(p0, p1); return t }
//line :408:1
func (t *BigDecimal) Ctor_BigInteger_MathContext(val *BigInteger, mc *MathContext) { t.Ctor_BigInteger_I_MathContext(BigDecimal_ToStrictBigInteger_BigInteger__BigInteger(val), 0, mc) }


func BigDecimal_New_BigInteger_I(p0 *BigInteger, p1 int32) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_BigInteger_I(p0, p1); return t }
//line :411:1
func (t *BigDecimal) Ctor_BigInteger_I(unscaledVal *BigInteger, scale int32) { t.Number.Ctor(t)
	t.F_intVal = BigDecimal_ToStrictBigInteger_BigInteger__BigInteger(unscaledVal)
	t.F_intCompact = BigDecimal_CompactValFor_BigInteger__J(t.F_intVal)
	t.F_scale = scale
}
func BigDecimal_New_BigInteger_I_MathContext(p0 *BigInteger, p1 int32, p2 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_BigInteger_I_MathContext(p0, p1, p2); return t }
//line :416:1
func (t *BigDecimal) Ctor_BigInteger_I_MathContext(unscaledVal *BigInteger, scale int32, mc *MathContext) { t.Number.Ctor(t)
	unscaledVal = BigDecimal_ToStrictBigInteger_BigInteger__BigInteger(unscaledVal)
	var compactVal int64 = BigDecimal_CompactValFor_BigInteger__J(unscaledVal); var mcp int32 = mc.F_precision
	var prec int32 = 0

	if mcp > 0 {
		var mode int32 = mc.F_roundingMode.F_oldMode
		if compactVal == -9223372036854775808 {
			prec = BigDecimal_BigDigitLength_BigInteger__I(unscaledVal)
			var drop int32 = prec - mcp
		L1: for { if drop > 0 {
			scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop))
			unscaledVal = BigDecimal_DivideAndRoundByTenPow_BigInteger_I_I__BigInteger(unscaledVal, drop, mode)
			compactVal = BigDecimal_CompactValFor_BigInteger__J(unscaledVal)
			if compactVal == -9223372036854775808 { } else { break L1 }
			prec = BigDecimal_BigDigitLength_BigInteger__I(unscaledVal)
			drop = prec - mcp
//line :426:1
			continue L1 }; break L1
		}
		}




		if compactVal == -9223372036854775808 { } else {
			prec = BigDecimal_LongDigitLength_J__I(compactVal)
			var drop_2 int32 = prec - mcp
		L2: for { if drop_2 > 0 {
			scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop_2))
			compactVal = BigDecimal_DivideAndRound_J_J_I__J(compactVal, BigDecimal_LONG_TEN_POWERS_TABLE.A[drop_2], mode)

			prec = BigDecimal_LongDigitLength_J__I(compactVal)
			drop_2 = prec - mcp
//line :436:1
			continue L2 }; break L2
		}




			unscaledVal = nil } }
	t.F_intVal = unscaledVal
	t.F_intCompact = compactVal
	t.F_scale = scale
	t.F_precision = prec
}
func BigDecimal_New_I(p0 int32) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_I(p0); return t }
//line :448:1
func (t *BigDecimal) Ctor_I(val int32) { t.Number.Ctor(t)
	t.F_intCompact = int64(val)
	t.F_scale = 0
	t.F_intVal = nil
}
func BigDecimal_New_I_MathContext(p0 int32, p1 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_I_MathContext(p0, p1); return t }
//line :453:1
func (t *BigDecimal) Ctor_I_MathContext(val int32, mc *MathContext) { t.Number.Ctor(t)
	var mcp int32 = mc.F_precision; var compactVal int64 = int64(val)
	var scl int32 = 0
	var prec int32 = 0

	if mcp > 0 {
		prec = BigDecimal_LongDigitLength_J__I(compactVal)
		var drop int32 = prec - mcp
	L1: for { if drop > 0 {
		scl = BigDecimal_CheckScaleNonZero_J__I(int64(scl) - int64(drop))
		var tmp1 int64 = compactVal; var tmp2 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop]; compactVal = BigDecimal_DivideAndRound_J_J_I__J(tmp1, tmp2, mc.F_roundingMode.F_oldMode)



		prec = BigDecimal_LongDigitLength_J__I(compactVal)
		drop = prec - mcp
//line :461:1
		continue L1 }; break L1
	}
	}





	t.F_intVal = nil
	t.F_intCompact = compactVal
	t.F_scale = scl
	t.F_precision = prec
}
func BigDecimal_New_J(p0 int64) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_J(p0); return t }
//line :474:1
func (t *BigDecimal) Ctor_J(val int64) { t.Number.Ctor(t)
	t.F_intCompact = val
	var tmp1 *BigInteger; if val == -9223372036854775808 { tmp1 = BigDecimal_INFLATED_BIGINT } else { tmp1 = nil }; t.F_intVal = tmp1
	t.F_scale = 0
}
func BigDecimal_New_J_MathContext(p0 int64, p1 *MathContext) *BigDecimal { BigDecimal_Init(); t := &BigDecimal{}; t.Ctor_J_MathContext(p0, p1); return t }
//line :479:1
func (t *BigDecimal) Ctor_J_MathContext(val int64, mc *MathContext) { t.Number.Ctor(t)
	var mcp int32 = mc.F_precision; var mode int32 = mc.F_roundingMode.F_oldMode; var prec int32 = 0; var scl int32 = 0; var rb *BigInteger



	if val == -9223372036854775808 { rb = BigDecimal_INFLATED_BIGINT } else { rb = nil }
	if mcp > 0 {
		if val == -9223372036854775808 {
			prec = 19
			var drop int32 = prec - mcp
		L1: for { if drop > 0 {
			scl = BigDecimal_CheckScaleNonZero_J__I(int64(scl) - int64(drop))
			rb = BigDecimal_DivideAndRoundByTenPow_BigInteger_I_I__BigInteger(rb, drop, mode)
			val = BigDecimal_CompactValFor_BigInteger__J(rb)
			if val == -9223372036854775808 { } else { break L1 }
			prec = BigDecimal_BigDigitLength_BigInteger__I(rb)
			drop = prec - mcp
//line :489:1
			continue L1 }; break L1
		}
		}




		if val == -9223372036854775808 { } else {
			prec = BigDecimal_LongDigitLength_J__I(val)
			var drop_2 int32 = prec - mcp
		L2: for { if drop_2 > 0 {
			scl = BigDecimal_CheckScaleNonZero_J__I(int64(scl) - int64(drop_2))
			var tmp1 int64 = val; var tmp2 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop_2]; val = BigDecimal_DivideAndRound_J_J_I__J(tmp1, tmp2, mc.F_roundingMode.F_oldMode)



			prec = BigDecimal_LongDigitLength_J__I(val)
			drop_2 = prec - mcp
//line :499:1
			continue L2 }; break L2
		}






			rb = nil } }
	t.F_intVal = rb
	t.F_intCompact = val
	t.F_scale = scl
	t.F_precision = prec
}
func BigDecimal_ValueOf_J_I__BigDecimal(unscaledVal int64, scale int32) *BigDecimal { BigDecimal_Init()
	if scale == 0 {
		return BigDecimal_ValueOf_J__BigDecimal(unscaledVal) } else {
//line :514:1
			if unscaledVal == 0 {

				return BigDecimal_ZeroValueOf_I__BigDecimal(scale) } else {

					var tmp1 *BigInteger; if unscaledVal == -9223372036854775808 { tmp1 = BigDecimal_INFLATED_BIGINT } else { tmp1 = nil }; return BigDecimal_New_BigInteger_J_I_I(tmp1, unscaledVal, scale, 0)
				}
		}
}

func BigDecimal_ValueOf_J__BigDecimal(val int64) *BigDecimal { BigDecimal_Init()
	var tmp1 bool; var tmp2 bool
	tmp2 = val >= 0; if tmp2 { tmp2 = val < int64(int32(len(BigDecimal_ZERO_THROUGH_TEN.A))) }; tmp1 = tmp2
//line :524:1
	if tmp1 {

		return As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[int32(val)]) } else {
//line :524:1
			if !(val == -9223372036854775808) {


				return BigDecimal_New_BigInteger_J_I_I(nil, val, 0, 0) } else {
					return BigDecimal_New_BigInteger_J_I_I(BigDecimal_INFLATED_BIGINT, val, 0, 0)
				} } }
func BigDecimal_ValueOf_J_I_I__BigDecimal(unscaledVal int64, scale, prec int32) *BigDecimal { BigDecimal_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = scale == 0; if tmp3 { tmp3 = unscaledVal >= 0 }; tmp2 = tmp3; if tmp2 { tmp2 = unscaledVal < int64(int32(len(BigDecimal_ZERO_THROUGH_TEN.A))) }; tmp1 = tmp2
//line :531:1
	if tmp1 {

		return As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[int32(unscaledVal)]) } else {
//line :531:1
			if unscaledVal == 0 {


				return BigDecimal_ZeroValueOf_I__BigDecimal(scale) } else {

					var tmp4 *BigInteger; if unscaledVal == -9223372036854775808 { tmp4 = BigDecimal_INFLATED_BIGINT } else { tmp4 = nil }; return BigDecimal_New_BigInteger_J_I_I(tmp4, unscaledVal, scale, prec)
				}
		}
}

func BigDecimal_ValueOf_BigInteger_I_I__BigDecimal(intVal *BigInteger, scale, prec int32) *BigDecimal { BigDecimal_Init()
	var val int64 = BigDecimal_CompactValFor_BigInteger__J(intVal)
	if val == 0 {
		return BigDecimal_ZeroValueOf_I__BigDecimal(scale) } else {
//line :543:1
			var tmp1 bool; var tmp2 bool; var tmp3 bool

			tmp3 = scale == 0; if tmp3 { tmp3 = val >= 0 }; tmp2 = tmp3; if tmp2 { tmp2 = val < int64(int32(len(BigDecimal_ZERO_THROUGH_TEN.A))) }; tmp1 = tmp2
//line :543:1
			if tmp1 {


				return As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[int32(val)]) } else {
					return BigDecimal_New_BigInteger_J_I_I(intVal, val, scale, prec)
				} } }
func BigDecimal_ZeroValueOf_I__BigDecimal(scale int32) *BigDecimal { BigDecimal_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = scale >= 0; if tmp2 { tmp2 = scale < int32(len(BigDecimal_ZERO_SCALED_BY.A)) }; tmp1 = tmp2; if tmp1 {
		return As[*BigDecimal](BigDecimal_ZERO_SCALED_BY.A[scale]) } else {
			var tmp3 *BigInteger; BigInteger_Init(); tmp3 = BigInteger_ZERO; return BigDecimal_New_BigInteger_J_I_I(tmp3, 0, scale, 1)
		} }
func BigDecimal_ValueOf_D__BigDecimal(val float64) *BigDecimal { BigDecimal_Init()
	if Double_IsFinite_D__Z(val) { } else { panic(Thrown(NumberFormatException_New_String(Lit_1218))) }
	var fmt *FormattedFPDecimal = FormattedFPDecimal_ValueForDoubleToString_D__FormattedFPDecimal(Math_Abs_D__D(val)); var s int64 = NN(fmt).GetSignificand__J()

	if val < 0.0 { s = -s }
	return BigDecimal_ValueOf_J_I_I__BigDecimal(s, -NN(fmt).GetExp__I(), NN(fmt).GetPrecision__I())
}
func (t *BigDecimal) Add_BigDecimal__BigDecimal(augend *BigDecimal) *BigDecimal {
	if !(t.F_intCompact == -9223372036854775808) {

		if !(augend.F_intCompact == -9223372036854775808) {
			var tmp1 int64 = t.F_intCompact; var tmp2 int32 = t.F_scale; var tmp3 int64 = augend.F_intCompact; return BigDecimal_Add_J_I_J_I__BigDecimal(tmp1, tmp2, tmp3, augend.F_scale) } else {



				var tmp4 int64 = t.F_intCompact; var tmp5 int32 = t.F_scale; var tmp6 *BigInteger = augend.F_intVal; return BigDecimal_Add_J_I_BigInteger_I__BigDecimal(tmp4, tmp5, tmp6, augend.F_scale) } } else {
//line :562:1
					if !(augend.F_intCompact == -9223372036854775808) {








						var tmp7 int64 = augend.F_intCompact; return BigDecimal_Add_J_I_BigInteger_I__BigDecimal(tmp7, augend.F_scale, t.F_intVal, t.F_scale) } else {
							var tmp8 *BigInteger = t.F_intVal; var tmp9 int32 = t.F_scale; var tmp10 *BigInteger = augend.F_intVal; return BigDecimal_Add_BigInteger_I_BigInteger_I__BigDecimal(tmp8, tmp9, tmp10, augend.F_scale)
						} } }
func (t *BigDecimal) Add_BigDecimal_MathContext__BigDecimal(augend *BigDecimal, mc *MathContext) *BigDecimal {
	if mc.F_precision == 0 {
		return t.Add_BigDecimal__BigDecimal(augend) } else {
			var lhs *BigDecimal = t; var lhsIsZero bool = NN(lhs).Signum__I() == 0; var augendIsZero bool = NN(augend).Signum__I() == 0; var tmp1 bool; var tmp2 bool


			tmp2 = lhsIsZero; if !tmp2 { tmp2 = augendIsZero }; tmp1 = tmp2; if tmp1 {
				var preferredScale int32 = Math_Max_I_I__I(NN(lhs).Scale__I(), NN(augend).Scale__I()); var result *BigDecimal; var tmp3 bool; var tmp4 bool

				tmp4 = lhsIsZero; if tmp4 { tmp4 = augendIsZero }; tmp3 = tmp4; if tmp3 { return BigDecimal_ZeroValueOf_I__BigDecimal(preferredScale) }
				var tmp5 *BigDecimal
				if lhsIsZero { tmp5 = BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(augend, mc) } else { tmp5 = BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(lhs, mc) }
//line :584:1
				result = tmp5

				if NN(result).Scale__I() == preferredScale {
					return result } else {
//line :586:1
						if NN(result).Scale__I() > preferredScale {


							var tmp6 *BigInteger = result.F_intVal; var tmp7 int64 = result.F_intCompact; return BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(tmp6, tmp7, result.F_scale, int64(preferredScale)) } else {





								var tmp8 int32 = mc.F_precision; var precisionDiff int32 = tmp8 - NN(result).Precision__I(); var scaleDiff int32 = preferredScale - NN(result).Scale__I()



								if precisionDiff >= scaleDiff {
									return NN(result).SetScale_I__BigDecimal(preferredScale) } else {
										return NN(result).SetScale_I__BigDecimal(NN(result).Scale__I() + precisionDiff)
									} } } }
			var tmp9 int64 = int64(lhs.F_scale); var padding int64 = tmp9 - int64(augend.F_scale)
			if padding == 0 { } else {
				var arg *RefArray = t.PreAlign_BigDecimal_BigDecimal_J_MathContext__BigDecimal1(lhs, augend, padding, mc)
				BigDecimal_MatchScale_BigDecimal1__V(arg)
				lhs = As[*BigDecimal](arg.A[0])
				augend = As[*BigDecimal](arg.A[1]) }
			return BigDecimal_DoRound_BigInteger_I_MathContext__BigDecimal(NN(NN(lhs).Inflated__BigInteger()).Add_BigInteger__BigInteger(NN(augend).Inflated__BigInteger()), lhs.F_scale, mc)
		} }
func (t *BigDecimal) PreAlign_BigDecimal_BigDecimal_J_MathContext__BigDecimal1(lhs, augend *BigDecimal, padding int64, mc *MathContext) *RefArray {

	if !A2g_AssertionsDisabled && !!(padding == 0) { panic(Thrown(AssertionError_New())) }
	var big *BigDecimal; var small *BigDecimal

	if padding < 0 {
		big = lhs; small = augend } else {
			big = augend; small = lhs }
	var tmp1 int64 = int64(big.F_scale); var tmp2 int64 = tmp1 - int64(NN(big).Precision__I()); var estResultUlpScale int64 = tmp2 + int64(mc.F_precision); var tmp3 int64 = int64(small.F_scale); var smallHighDigitPos int64 = tmp3 - int64(NN(small).Precision__I()) + 1; var tmp4 bool; var tmp5 bool





	tmp5 = smallHighDigitPos > int64(big.F_scale+2); if tmp5 {
		tmp5 = smallHighDigitPos > estResultUlpScale+2 }
//line :625:1
	tmp4 = tmp5; if tmp4 {

		small = BigDecimal_ValueOf_J_I__BigDecimal(int64(NN(small).Signum__I()), t.CheckScale_J__I(Math_Max_J_J__J(int64(big.F_scale), estResultUlpScale)+3))
	}





	var result *RefArray = RefArrayOf(BigDecimal_class, big.Ref(), small.Ref()); return result
}
func (t *BigDecimal) Subtract_BigDecimal__BigDecimal(subtrahend *BigDecimal) *BigDecimal {
	if !(t.F_intCompact == -9223372036854775808) {

		if !(subtrahend.F_intCompact == -9223372036854775808) {
			var tmp1 int64 = t.F_intCompact; var tmp2 int32 = t.F_scale; var tmp3 int64 = -subtrahend.F_intCompact; return BigDecimal_Add_J_I_J_I__BigDecimal(tmp1, tmp2, tmp3, subtrahend.F_scale) } else {



				var tmp4 int64 = t.F_intCompact; var tmp5 int32 = t.F_scale; return BigDecimal_Add_J_I_BigInteger_I__BigDecimal(tmp4, tmp5, NN(subtrahend.F_intVal).Negate__BigInteger(), subtrahend.F_scale) } } else {
//line :637:1
					if !(subtrahend.F_intCompact == -9223372036854775808) {











						var tmp6 int64 = -subtrahend.F_intCompact; return BigDecimal_Add_J_I_BigInteger_I__BigDecimal(tmp6, subtrahend.F_scale, t.F_intVal, t.F_scale) } else {




							var tmp7 *BigInteger = t.F_intVal; var tmp8 int32 = t.F_scale; return BigDecimal_Add_BigInteger_I_BigInteger_I__BigDecimal(tmp7, tmp8, NN(subtrahend.F_intVal).Negate__BigInteger(), subtrahend.F_scale)
						}
				}
}

func (t *BigDecimal) Subtract_BigDecimal_MathContext__BigDecimal(subtrahend *BigDecimal, mc *MathContext) *BigDecimal {
	if mc.F_precision == 0 { return t.Subtract_BigDecimal__BigDecimal(subtrahend) } else { return t.Add_BigDecimal_MathContext__BigDecimal(NN(subtrahend).Negate__BigDecimal(), mc)
	} }
func (t *BigDecimal) Multiply_BigDecimal__BigDecimal(multiplicand *BigDecimal) *BigDecimal {
	var tmp1 int64 = int64(t.F_scale); var productScale int32 = t.CheckScale_J__I(tmp1 + int64(multiplicand.F_scale))
	if !(t.F_intCompact == -9223372036854775808) {

		if !(multiplicand.F_intCompact == -9223372036854775808) {
			var tmp2 int64 = t.F_intCompact; return BigDecimal_Multiply_J_J_I__BigDecimal(tmp2, multiplicand.F_intCompact, productScale) } else {
				var tmp3 int64 = t.F_intCompact; return BigDecimal_Multiply_J_BigInteger_I__BigDecimal(tmp3, multiplicand.F_intVal, productScale) } } else {
//line :664:1
					if !(multiplicand.F_intCompact == -9223372036854775808) {





						return BigDecimal_Multiply_J_BigInteger_I__BigDecimal(multiplicand.F_intCompact, t.F_intVal, productScale) } else {
							var tmp4 *BigInteger = t.F_intVal; return BigDecimal_Multiply_BigInteger_BigInteger_I__BigDecimal(tmp4, multiplicand.F_intVal, productScale)
						} } }
func (t *BigDecimal) Multiply_BigDecimal_MathContext__BigDecimal(multiplicand *BigDecimal, mc *MathContext) *BigDecimal {
	if mc.F_precision == 0 {
		return t.Multiply_BigDecimal__BigDecimal(multiplicand) } else {
			var tmp1 int64 = int64(t.F_scale); var productScale int32 = t.CheckScale_J__I(tmp1 + int64(multiplicand.F_scale))
			if !(t.F_intCompact == -9223372036854775808) {

				if !(multiplicand.F_intCompact == -9223372036854775808) {
					var tmp2 int64 = t.F_intCompact; return BigDecimal_MultiplyAndRound_J_J_I_MathContext__BigDecimal(tmp2, multiplicand.F_intCompact, productScale, mc) } else {



						var tmp3 int64 = t.F_intCompact; return BigDecimal_MultiplyAndRound_J_BigInteger_I_MathContext__BigDecimal(tmp3, multiplicand.F_intVal, productScale, mc) } } else {
//line :677:1
							if !(multiplicand.F_intCompact == -9223372036854775808) {











								return BigDecimal_MultiplyAndRound_J_BigInteger_I_MathContext__BigDecimal(multiplicand.F_intCompact, t.F_intVal, productScale, mc) } else {




									var tmp4 *BigInteger = t.F_intVal; return BigDecimal_MultiplyAndRound_BigInteger_BigInteger_I_MathContext__BigDecimal(tmp4, multiplicand.F_intVal, productScale, mc)
								} } } }
func (t *BigDecimal) Divide_BigDecimal_I_I__BigDecimal(divisor *BigDecimal, scale, roundingMode int32) *BigDecimal {

	var tmp1 bool; var tmp2 bool; tmp2 = roundingMode < 0; if !tmp2 { tmp2 = roundingMode > 7 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1219))) }
	if !(t.F_intCompact == -9223372036854775808) {

		if !(divisor.F_intCompact == -9223372036854775808) {
			var tmp3 int64 = t.F_intCompact; var tmp4 int32 = t.F_scale; var tmp5 int64 = divisor.F_intCompact; return BigDecimal_Divide_J_I_J_I_I_I__BigDecimal(tmp3, tmp4, tmp5, divisor.F_scale, scale, roundingMode) } else {





				var tmp6 int64 = t.F_intCompact; var tmp7 int32 = t.F_scale; var tmp8 *BigInteger = divisor.F_intVal; return BigDecimal_Divide_J_I_BigInteger_I_I_I__BigDecimal(tmp6, tmp7, tmp8, divisor.F_scale, scale, roundingMode) } } else {
//line :700:1
					if !(divisor.F_intCompact == -9223372036854775808) {















						var tmp9 *BigInteger = t.F_intVal; var tmp10 int32 = t.F_scale; var tmp11 int64 = divisor.F_intCompact; return BigDecimal_Divide_BigInteger_I_J_I_I_I__BigDecimal(tmp9, tmp10, tmp11, divisor.F_scale, scale, roundingMode) } else {






							var tmp12 *BigInteger = t.F_intVal; var tmp13 int32 = t.F_scale; var tmp14 *BigInteger = divisor.F_intVal; return BigDecimal_Divide_BigInteger_I_BigInteger_I_I_I__BigDecimal(tmp12, tmp13, tmp14, divisor.F_scale, scale, roundingMode)
						}
				}
}



func (t *BigDecimal) Divide_BigDecimal_I_RoundingMode__BigDecimal(divisor *BigDecimal, scale int32, roundingMode *RoundingMode) *BigDecimal {

	return t.Divide_BigDecimal_I_I__BigDecimal(divisor, scale, roundingMode.F_oldMode)
}
func (t *BigDecimal) Divide_BigDecimal_I__BigDecimal(divisor *BigDecimal, roundingMode int32) *BigDecimal {

	return t.Divide_BigDecimal_I_I__BigDecimal(divisor, t.F_scale, roundingMode)
}
func (t *BigDecimal) Divide_BigDecimal_RoundingMode__BigDecimal(divisor *BigDecimal, roundingMode *RoundingMode) *BigDecimal {
	var tmp1 int32 = t.F_scale; return t.Divide_BigDecimal_I_I__BigDecimal(divisor, tmp1, roundingMode.F_oldMode)
}
func (t *BigDecimal) Divide_BigDecimal__BigDecimal(divisor *BigDecimal) *BigDecimal {
	if NN(divisor).Signum__I() == 0 {
		if t.Signum__I() == 0 { panic(Thrown(ArithmeticException_New_String(Lit_1220))) }
		panic(Thrown(ArithmeticException_New_String(Lit_1221))) }
	var tmp1 int64 = int64(t.F_scale); var preferredScale int32 = BigDecimal_SaturateLong_J__I(tmp1 - int64(divisor.F_scale))

	if t.Signum__I() == 0 {
		return BigDecimal_ZeroValueOf_I__BigDecimal(preferredScale) } else {
			var mc *MathContext; var tmp2 int32 = int32(Math_Min_J_J__J(int64(t.Precision__I())+D2L(Math_Ceil_D__D(float64(10.0*float64(NN(divisor).Precision__I()))/3.0)), 2147483647)); var tmp3 *RoundingMode; RoundingMode_Init(); tmp3 = RoundingMode_UNNECESSARY; mc = MathContext_New_I_RoundingMode(tmp2, tmp3); var quotient *BigDecimal; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)











				quotient = t.Divide_BigDecimal_MathContext__BigDecimal(divisor, mc); return nil }()
//line :760:1
			if tmp4 != nil { if ArithmeticException_InstanceOf(tmp4) { var e *ArithmeticException = ArithmeticException_Cast(tmp4); _ = e


				panic(Thrown(ArithmeticException_New_String(Lit_1222))) } else {
//line :760:1
					panic(tmp4)
				}
			}



			var quotientScale int32 = NN(quotient).Scale__I()
			if preferredScale > quotientScale {
				return NN(quotient).SetScale_I_I__BigDecimal(preferredScale, 7) } else {
//line :767:1
					return quotient
				}
		}
}
func (t *BigDecimal) Divide_BigDecimal_MathContext__BigDecimal(divisor *BigDecimal, mc *MathContext) *BigDecimal {
	var mcp int32 = mc.F_precision
	if mcp == 0 {
		return t.Divide_BigDecimal__BigDecimal(divisor) } else {
			var dividend *BigDecimal = t; var tmp1 int64 = int64(dividend.F_scale); var preferredScale int64 = tmp1 - int64(divisor.F_scale)

			if NN(divisor).Signum__I() == 0 {
				if NN(dividend).Signum__I() == 0 { panic(Thrown(ArithmeticException_New_String(Lit_1220))) }
				panic(Thrown(ArithmeticException_New_String(Lit_1221))) }
			if NN(dividend).Signum__I() == 0 {
				return BigDecimal_ZeroValueOf_I__BigDecimal(BigDecimal_SaturateLong_J__I(preferredScale)) } else {
					var xscale int32 = NN(dividend).Precision__I(); var yscale int32 = NN(divisor).Precision__I()

					if !(dividend.F_intCompact == -9223372036854775808) {

						if !(divisor.F_intCompact == -9223372036854775808) {
							var tmp2 int64 = dividend.F_intCompact; return BigDecimal_Divide_J_I_J_I_J_MathContext__BigDecimal(tmp2, xscale, divisor.F_intCompact, yscale, preferredScale, mc) } else {





								var tmp3 int64 = dividend.F_intCompact; return BigDecimal_Divide_J_I_BigInteger_I_J_MathContext__BigDecimal(tmp3, xscale, divisor.F_intVal, yscale, preferredScale, mc) } } else {
//line :784:1
									if !(divisor.F_intCompact == -9223372036854775808) {















										var tmp4 *BigInteger = dividend.F_intVal; return BigDecimal_Divide_BigInteger_I_J_I_J_MathContext__BigDecimal(tmp4, xscale, divisor.F_intCompact, yscale, preferredScale, mc) } else {






											var tmp5 *BigInteger = dividend.F_intVal; return BigDecimal_Divide_BigInteger_I_BigInteger_I_J_MathContext__BigDecimal(tmp5, xscale, divisor.F_intVal, yscale, preferredScale, mc)
										}
								}
				}
		}
}

func (t *BigDecimal) DivideToIntegralValue_BigDecimal__BigDecimal(divisor *BigDecimal) *BigDecimal {
	var tmp1 int64 = int64(t.F_scale); var preferredScale int32 = BigDecimal_SaturateLong_J__I(tmp1 - int64(divisor.F_scale))

	if t.CompareMagnitude_BigDecimal__I(divisor) < 0 {
		return BigDecimal_ZeroValueOf_I__BigDecimal(preferredScale) } else {
//line :817:1
			var tmp2 bool; var tmp3 bool

			tmp3 = t.Signum__I() == 0; if tmp3 { tmp3 = !(NN(divisor).Signum__I() == 0) }; tmp2 = tmp3
//line :817:1
			if tmp2 {


				return t.SetScale_I_I__BigDecimal(preferredScale, 7) } else {

					var maxDigits int32 = int32(Math_Min_J_J__J(int64(t.Precision__I())+D2L(Math_Ceil_D__D(float64(10.0*float64(NN(divisor).Precision__I()))/3.0))+Math_Abs_J__J(int64(t.Scale__I())-int64(NN(divisor).Scale__I()))+2, 2147483647)); var quotient *BigDecimal; var tmp4 *RoundingMode















					RoundingMode_Init(); tmp4 = RoundingMode_DOWN; quotient = t.Divide_BigDecimal_MathContext__BigDecimal(divisor, MathContext_New_I_RoundingMode(maxDigits, tmp4))
					if quotient.F_scale > 0 {
						var tmp5 *BigDecimal = quotient; var tmp6 *RoundingMode; RoundingMode_Init(); tmp6 = RoundingMode_DOWN; quotient = NN(tmp5).SetScale_I_RoundingMode__BigDecimal(0, tmp6)
						var tmp7 *BigInteger = quotient.F_intVal; var tmp8 int64 = quotient.F_intCompact; quotient = BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(tmp7, tmp8, quotient.F_scale, int64(preferredScale))
					}




					if quotient.F_scale < preferredScale {
						quotient = NN(quotient).SetScale_I_I__BigDecimal(preferredScale, 7) }
//line :822:1
					return quotient
				}
		}
}

























func (t *BigDecimal) DivideToIntegralValue_BigDecimal_MathContext__BigDecimal(divisor *BigDecimal, mc *MathContext) *BigDecimal {
	var tmp1 bool; var tmp2 bool; tmp2 = mc.F_precision == 0; if !tmp2 { tmp2 = t.CompareMagnitude_BigDecimal__I(divisor) < 0 }; tmp1 = tmp2; if tmp1 {
		return t.DivideToIntegralValue_BigDecimal__BigDecimal(divisor) } else {
			var tmp3 int64 = int64(t.F_scale); var preferredScale int32 = BigDecimal_SaturateLong_J__I(tmp3 - int64(divisor.F_scale)); var result *BigDecimal; var tmp4 int32 = mc.F_precision; var tmp5 *RoundingMode

			RoundingMode_Init(); tmp5 = RoundingMode_DOWN; result = t.Divide_BigDecimal_MathContext__BigDecimal(divisor, MathContext_New_I_RoundingMode(tmp4, tmp5))


			if NN(result).Scale__I() < 0 {

				var product *BigDecimal = NN(result).Multiply_BigDecimal__BigDecimal(divisor)
				if NN(t.Subtract_BigDecimal__BigDecimal(product)).CompareMagnitude_BigDecimal__I(divisor) >= 0 {
					panic(Thrown(ArithmeticException_New_String(Lit_1223))) } } else {
//line :859:1
						if NN(result).Scale__I() > 0 {




							var tmp6 *BigDecimal = result; var tmp7 *RoundingMode; RoundingMode_Init(); tmp7 = RoundingMode_DOWN; result = NN(tmp6).SetScale_I_RoundingMode__BigDecimal(0, tmp7) } }
			var precisionDiff int32 = 0; var tmp8 bool; var tmp9 bool
			tmp9 = preferredScale > NN(result).Scale__I(); if tmp9 {
				var tmp10 int32; var tmp11 int32 = mc.F_precision; precisionDiff = tmp11 - NN(result).Precision__I(); tmp10 = precisionDiff; tmp9 = tmp10 > 0 }
//line :866:1
			tmp8 = tmp9; if tmp8 {



				return NN(result).SetScale_I__BigDecimal(NN(result).Scale__I() + Math_Min_I_I__I(precisionDiff, preferredScale-result.F_scale)) } else {






					var tmp12 *BigInteger = result.F_intVal; var tmp13 int64 = result.F_intCompact; return BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(tmp12, tmp13, result.F_scale, int64(preferredScale))
				}
		}
}


func (t *BigDecimal) Remainder_BigDecimal__BigDecimal(divisor *BigDecimal) *BigDecimal {
	var divrem *RefArray = t.DivideAndRemainder_BigDecimal__BigDecimal1(divisor); return As[*BigDecimal](divrem.A[1])
}
func (t *BigDecimal) Remainder_BigDecimal_MathContext__BigDecimal(divisor *BigDecimal, mc *MathContext) *BigDecimal {
	var divrem *RefArray = t.DivideAndRemainder_BigDecimal_MathContext__BigDecimal1(divisor, mc); return As[*BigDecimal](divrem.A[1])
}
func (t *BigDecimal) DivideAndRemainder_BigDecimal__BigDecimal1(divisor *BigDecimal) *RefArray {
	var result *RefArray = NewRefArray(BigDecimal_class, 2)
	result.Store(0, t.DivideToIntegralValue_BigDecimal__BigDecimal(divisor).Ref())
	result.Store(1, t.Subtract_BigDecimal__BigDecimal(NN(As[*BigDecimal](result.A[0])).Multiply_BigDecimal__BigDecimal(divisor)).Ref())
//line :890:1
	return result
}



func (t *BigDecimal) DivideAndRemainder_BigDecimal_MathContext__BigDecimal1(divisor *BigDecimal, mc *MathContext) *RefArray {
	if mc.F_precision == 0 {
		return t.DivideAndRemainder_BigDecimal__BigDecimal1(divisor) } else {
			var result *RefArray = NewRefArray(BigDecimal_class, 2)
			var lhs /*line :898:1*/*BigDecimal = t

			result.Store(0, NN(lhs).DivideToIntegralValue_BigDecimal_MathContext__BigDecimal(divisor, mc).Ref())
			result.Store(1, NN(lhs).Subtract_BigDecimal__BigDecimal(NN(As[*BigDecimal](result.A[0])).Multiply_BigDecimal__BigDecimal(divisor)).Ref())
//line :898:1
			return result
		}
}



func (t *BigDecimal) Sqrt_MathContext__BigDecimal(mc *MathContext) *BigDecimal {
	var signum int32 = t.Signum__I()
	if signum == 1 { } else {
		switch signum { case -1:
			panic(Thrown(ArithmeticException_New_String(Lit_1225))); case 0:

			var result *BigDecimal = BigDecimal_ValueOf_J_I__BigDecimal(0, t.F_scale/2)
			if !A2g_AssertionsDisabled && !t.SquareRootResultAssertions_BigDecimal_MathContext__Z(result, mc) { panic(Thrown(AssertionError_New())) }
			return result; default:
			panic(Thrown(AssertionError_New_O(Lit_1224)))} }
	var preferredScale int32 = Math_CeilDiv_I_I__I(t.F_scale, 2); var result_2 *BigDecimal; var tmp1 bool; var tmp2 bool; var tmp3 *RoundingMode = mc.F_roundingMode; var tmp4 *RoundingMode

	RoundingMode_Init(); tmp4 = RoundingMode_UNNECESSARY; tmp2 = tmp3 == tmp4; if !tmp2 { tmp2 = mc.F_precision == 0 }; tmp1 = tmp2; if tmp1 {
		var stripped *BigDecimal = t.StripTrailingZeros__BigDecimal(); var strippedScale int32 = stripped.F_scale

		if strippedScale&1 == 0 { } else {
			panic(Thrown(ArithmeticException_New_String(Lit_1226))) }
		if NN(stripped).IsPowerOfTen__Z() {

			result_2 = BigDecimal_ValueOf_J_I__BigDecimal(1, strippedScale>>1)
			return NN(result_2).AdjustToPreferredScale_I_I__BigDecimal(preferredScale, mc.F_precision) } else {
				var sqrtRem *RefArray = NN(NN(stripped).UnscaledValue__BigInteger()).SqrtAndRemainder__BigInteger1()
				result_2 = BigDecimal_New_BigInteger_I(As[*BigInteger](sqrtRem.A[0]), strippedScale>>1)

				var tmp5 bool; var tmp6 bool; tmp6 = !(As[*BigInteger](sqrtRem.A[1]).F_signum == 0); if !tmp6 {
					var tmp7 bool; tmp7 = !(mc.F_precision == 0); if tmp7 {
						tmp7 = NN(result_2).Precision__I() > mc.F_precision }
//line :929:1
					tmp6 = tmp7 }
//line :928:1
				tmp5 = tmp6; if tmp5 {


					panic(Thrown(ArithmeticException_New_String(Lit_1226))) }
				if !A2g_AssertionsDisabled && !t.SquareRootResultAssertions_BigDecimal_MathContext__Z(result_2, mc) { panic(Thrown(AssertionError_New())) }
				return NN(result_2).AdjustToPreferredScale_I_I__BigDecimal(preferredScale, mc.F_precision) } } else {
					var halfWay bool = BigDecimal_IsHalfWay_RoundingMode__Z(mc.F_roundingMode); var minWorkingPrec int64; var tmp8 int64 = int64(mc.F_precision); var tmp9 int32


					if halfWay { tmp9 = 1 } else { tmp9 = 0 }
//line :935:1
					minWorkingPrec = (tmp8+int64(tmp9))<<1 - 1
//line :934:1
					var normScale int64 = minWorkingPrec - int64(t.Precision__I()) + int64(t.F_scale)








					normScale = normScale + normScale&1
					var workingScale int64 = int64(t.F_scale) - normScale
					if workingScale == int64(int32(workingScale)) { } else {
						panic(Thrown(ArithmeticException_New_String(Lit_1227))) }
					var working *BigDecimal = BigDecimal_New_BigInteger_J_I_I(t.F_intVal, t.F_intCompact, int32(workingScale), t.F_precision); var workingInt *BigInteger = NN(working).ToBigInteger__BigInteger(); var sqrt *BigInteger; var resultScale int64 = normScale >> 1






					if halfWay {
						var workingSqrt *BigInteger = NN(workingInt).Sqrt__BigInteger(); var quotRem10 *RefArray; var tmp10 *BigInteger
						BigInteger_Init(); tmp10 = BigInteger_TEN; quotRem10 = NN(workingSqrt).DivideAndRemainder_BigInteger__BigInteger1(tmp10)
						sqrt = As[*BigInteger](quotRem10.A[0])
						resultScale = resultScale - 1
						var increment bool = false; var digit int32 = NN(As[*BigInteger](quotRem10.A[1])).IntValue__I()

						if digit > 5 {
							increment = true } else {
//line :961:1
								if digit == 5 {


									var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 *RoundingMode = mc.F_roundingMode; var tmp16 *RoundingMode; RoundingMode_Init(); tmp16 = RoundingMode_HALF_UP; tmp14 = tmp15 == tmp16; if !tmp14 {


										var tmp17 bool; var tmp18 *RoundingMode = mc.F_roundingMode; var tmp19 *RoundingMode
										RoundingMode_Init(); tmp19 = RoundingMode_HALF_EVEN; tmp17 = tmp18 == tmp19
//line :967:1
										if tmp17 {



											tmp17 = NN(sqrt).TestBit_I__Z(0) }
//line :967:1
										tmp14 = tmp17 }
//line :964:1
									tmp13 = tmp14; if !tmp13 {







										tmp13 = !NN(workingInt).Equals_O__Z(NN(workingSqrt).Multiply_BigInteger__BigInteger(workingSqrt).Ref()) }
//line :964:1
									tmp12 = tmp13; if !tmp12 {











										tmp12 = !NN(working).IsInteger__Z() }
//line :964:1
									tmp11 = tmp12; if tmp11 {












										increment = true } } }
						if increment { sqrt = NN(sqrt).Add_J__BigInteger(1) } } else {
							switch NN(mc.F_roundingMode).F_ordinal { case 1, 3:
								sqrt = NN(workingInt).Sqrt__BigInteger()
//line :979:1
							case 0, 2:


								var sqrtRem_2 *RefArray = NN(workingInt).SqrtAndRemainder__BigInteger1()
								sqrt = As[*BigInteger](sqrtRem_2.A[0])
								var tmp20 bool; var tmp21 bool; tmp21 = !(As[*BigInteger](sqrtRem_2.A[1]).F_signum == 0); if !tmp21 {
									tmp21 = !NN(working).IsInteger__Z() }
//line :984:1
								tmp20 = tmp21; if tmp20 {

									sqrt = NN(sqrt).Add_J__BigInteger(1) }
//line :979:1
							default:







								panic(Thrown(AssertionError_New_O(Concat(Lit_1228, StrOfObj(mc.F_roundingMode.Ref())))))
							}
						}
					result_2 = BigDecimal_New_BigInteger_I_MathContext(sqrt, BigDecimal_CheckScale_BigInteger_J__I(sqrt, resultScale), mc)
					if !A2g_AssertionsDisabled && !t.SquareRootResultAssertions_BigDecimal_MathContext__Z(result_2, mc) { panic(Thrown(AssertionError_New())) }
					if result_2.F_scale > preferredScale {
						var tmp22 *BigInteger = result_2.F_intVal; var tmp23 int64 = result_2.F_intCompact; result_2 = BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(tmp22, tmp23, result_2.F_scale, int64(preferredScale)) }
//line :947:1
					return result_2
				}
}



















































func (t *BigDecimal) AdjustToPreferredScale_I_I__BigDecimal(preferredScale, maxPrecision int32) *BigDecimal {
	var result *BigDecimal = t
	if result.F_scale > preferredScale {

		var tmp1 *BigInteger = result.F_intVal; var tmp2 int64 = result.F_intCompact; result = BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(tmp1, tmp2, result.F_scale, int64(preferredScale)) } else {
//line :1003:1
			if result.F_scale < preferredScale {








				var maxScale int32; if maxPrecision == 0 { maxScale = preferredScale } else {

					var tmp3 int64 = int64(result.F_scale); maxScale = int32(Math_Min_J_J__J(int64(preferredScale), tmp3+int64(maxPrecision-NN(result).Precision__I())))
				}






				result = NN(result).SetScale_I__BigDecimal(maxScale) } }
//line :1002:1
	return result
}





















func BigDecimal_IsHalfWay_RoundingMode__Z(m *RoundingMode) bool { BigDecimal_Init()
	switch NN(m).F_ordinal { case 5, 4, 6: return true; case 3, 2, 1, 0, 7: return false; default:


		panic(Thrown(MatchException_New_String_Throwable(nil, nil)))}; panic("a2g: unreachable")
}
func (t *BigDecimal) Square__BigDecimal() *BigDecimal { return t.Multiply_BigDecimal__BigDecimal(t) }

func (t *BigDecimal) IsPowerOfTen__Z() bool {
	var tmp1 *BigInteger; BigInteger_Init(); tmp1 = BigInteger_ONE; var tmp2 *BigInteger = tmp1; return NN(tmp2).Equals_O__Z(t.UnscaledValue__BigInteger().Ref())
}
func (t *BigDecimal) SquareRootResultAssertions_BigDecimal_MathContext__Z(result *BigDecimal, mc *MathContext) bool {
	if NN(result).Signum__I() == 0 {
		return t.SquareRootZeroResultAssertions_BigDecimal_MathContext__Z(result, mc) } else {
			var rm *RoundingMode = NN(mc).GetRoundingMode__RoundingMode(); var ulp *BigDecimal = NN(result).Ulp__BigDecimal(); var neighborUp *BigDecimal = NN(result).Add_BigDecimal__BigDecimal(ulp)


			if NN(result).IsPowerOfTen__Z() { ulp = NN(ulp).Divide_BigDecimal__BigDecimal(BigDecimal_TEN) }
			var neighborDown *BigDecimal = NN(result).Subtract_BigDecimal__BigDecimal(ulp); var tmp1 bool; var tmp2 bool
			tmp2 = NN(result).Signum__I() == 1; if tmp2 { tmp2 = t.Signum__I() == 1 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New_O(Lit_1229)))
			}
			switch NN(rm).F_ordinal { case 1, 3:


				var tmp3 bool; var tmp4 bool; tmp4 = NN(NN(result).Square__BigDecimal()).CompareTo_BigDecimal__I(t) <= 0; if tmp4 {
					tmp4 = NN(NN(neighborUp).Square__BigDecimal()).CompareTo_BigDecimal__I(t) > 0 }
//line :1049:1
				tmp3 = tmp4; if !A2g_AssertionsDisabled && !tmp3 { panic(Thrown(AssertionError_New_O(Concat(Lit_1230, StrOfObj(rm.Ref()))))) }
//line :1048:1
				return true

			case 0, 2:




				var tmp5 bool; var tmp6 bool; tmp6 = NN(NN(result).Square__BigDecimal()).CompareTo_BigDecimal__I(t) >= 0; if tmp6 {
					tmp6 = NN(NN(neighborDown).Square__BigDecimal()).CompareTo_BigDecimal__I(t) < 0 }
//line :1055:1
				tmp5 = tmp6; if !A2g_AssertionsDisabled && !tmp5 { panic(Thrown(AssertionError_New_O(Concat(Lit_1230, StrOfObj(rm.Ref()))))) }
//line :1054:1
				return true

			case 5, 6, 4:



				var err *BigDecimal = NN(NN(NN(result).Square__BigDecimal()).Subtract_BigDecimal__BigDecimal(t)).Abs__BigDecimal(); var errUp *BigDecimal = NN(NN(neighborUp).Square__BigDecimal()).Subtract_BigDecimal__BigDecimal(t); var errDown *BigDecimal = t.Subtract_BigDecimal__BigDecimal(NN(neighborDown).Square__BigDecimal()); var err_comp_errUp int32 = NN(err).CompareTo_BigDecimal__I(errUp); var err_comp_errDown int32 = NN(err).CompareTo_BigDecimal__I(errDown); var tmp7 bool; var tmp8 bool




				tmp8 = NN(errUp).Signum__I() == 1; if tmp8 { tmp8 = NN(errDown).Signum__I() == 1 }; tmp7 = tmp8; if !A2g_AssertionsDisabled && !tmp7 { panic(Thrown(AssertionError_New_O(Lit_1231)))
				}
				var tmp9 bool; var tmp10 bool; tmp10 = err_comp_errUp <= 0; if !tmp10 { tmp10 = err_comp_errDown <= 0 }; tmp9 = tmp10; if !A2g_AssertionsDisabled && !tmp9 { panic(Thrown(AssertionError_New_O(Concat(Lit_1232, StrOfObj(rm.Ref())))))
				}
				var tmp11 bool; var tmp12 bool; if err_comp_errUp == 0 { tmp12 = err_comp_errDown < 0 } else { tmp12 = true }; if tmp12 {
					if err_comp_errDown == 0 { tmp12 = err_comp_errUp < 0 } else { tmp12 = true } }
//line :1069:1
				tmp11 = tmp12; if !A2g_AssertionsDisabled && !tmp11 { panic(Thrown(AssertionError_New_O(Lit_1233))) }
//line :1060:1
				return true









			default:
//line :1046:1
				return true
			}
		}





















	panic("a2g: unreachable")
}



func (t *BigDecimal) SquareRootZeroResultAssertions_BigDecimal_MathContext__Z(result *BigDecimal, mc *MathContext) bool {
	return t.CompareTo_BigDecimal__I(BigDecimal_ZERO) == 0
}
func (t *BigDecimal) Pow_I__BigDecimal(n int32) *BigDecimal {
	var tmp1 bool; var tmp2 bool; tmp2 = n < 0; if !tmp2 { tmp2 = n > 999999999 }; tmp1 = tmp2; if tmp1 { panic(Thrown(ArithmeticException_New_String(Lit_1234))) }
	var newScale int32 = t.CheckScale_J__I(int64(t.F_scale) * int64(n))
	return BigDecimal_New_BigInteger_I(NN(t.Inflated__BigInteger()).Pow_I__BigInteger(n), newScale)
}
func (t *BigDecimal) Pow_I_MathContext__BigDecimal(n int32, mc *MathContext) *BigDecimal {
	if mc.F_precision == 0 {
		return t.Pow_I__BigDecimal(n) } else {

			var tmp1 bool; var tmp2 bool; tmp2 = n < -999999999; if !tmp2 { tmp2 = n > 999999999 }; tmp1 = tmp2; if tmp1 {
				panic(Thrown(ArithmeticException_New_String(Lit_1234))) }
			if n == 0 { return BigDecimal_ONE } else {

				var lhs *BigDecimal = t; var workmc *MathContext = mc; var mag int32 = Math_Abs_I__I(n)


				if mc.F_precision > 0 {
					var elength int32 = BigDecimal_LongDigitLength_J__I(int64(mag))
					if elength > mc.F_precision {
						panic(Thrown(ArithmeticException_New_String(Lit_1234))) }
					var tmp3 int32 = mc.F_precision + elength + 1; workmc = MathContext_New_I_RoundingMode(tmp3, mc.F_roundingMode)
				}



				var acc *BigDecimal = BigDecimal_ONE
				var seenbit bool = false; var i int32 = 1
			L1: for {
				mag = mag + mag
				if mag < 0 { seenbit = true; acc = NN(acc).Multiply_BigDecimal_MathContext__BigDecimal(lhs, workmc) }
				if i == 31 { } else {
					if seenbit {
						acc = NN(acc).Multiply_BigDecimal_MathContext__BigDecimal(acc, workmc); i = i + 1; continue L1 } else {
							i = i + 1; continue L1 } }
//line :1105:1
				break L1
			}





				if n < 0 { acc = NN(BigDecimal_ONE).Divide_BigDecimal_MathContext__BigDecimal(acc, workmc) }
				return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(acc, mc)
			} } }
func (t *BigDecimal) Abs__BigDecimal() *BigDecimal {
	if t.Signum__I() < 0 { return t.Negate__BigDecimal() } else { return t
	} }
func (t *BigDecimal) Abs_MathContext__BigDecimal(mc *MathContext) *BigDecimal {
	if t.Signum__I() < 0 { return t.Negate_MathContext__BigDecimal(mc) } else { return t.Plus_MathContext__BigDecimal(mc)
	} }
func (t *BigDecimal) Negate__BigDecimal() *BigDecimal {
	if t.F_intCompact == -9223372036854775808 {
		return BigDecimal_New_BigInteger_J_I_I(NN(t.F_intVal).Negate__BigInteger(), -9223372036854775808, t.F_scale, t.F_precision) } else {
			return BigDecimal_ValueOf_J_I_I__BigDecimal(-t.F_intCompact, t.F_scale, t.F_precision)
		} }
func (t *BigDecimal) Negate_MathContext__BigDecimal(mc *MathContext) *BigDecimal {
	return NN(t.Negate__BigDecimal()).Plus_MathContext__BigDecimal(mc)
}
func (t *BigDecimal) Plus__BigDecimal() *BigDecimal { return t }

func (t *BigDecimal) Plus_MathContext__BigDecimal(mc *MathContext) *BigDecimal {
	if mc.F_precision == 0 { return t } else { return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(t, mc)
	} }
func (t *BigDecimal) Signum__I() int32 {
	if !(t.F_intCompact == -9223372036854775808) { return Long_Signum_J__I(t.F_intCompact) } else { return NN(t.F_intVal).Signum__I()
	} }
func (t *BigDecimal) Scale__I() int32 { return t.F_scale }

func (t *BigDecimal) Precision__I() int32 {
	var result int32 = t.F_precision
	if result == 0 {
		var s int64 = t.F_intCompact
		if !(s == -9223372036854775808) {
			result = BigDecimal_LongDigitLength_J__I(s) } else {
				result = BigDecimal_BigDigitLength_BigInteger__I(t.F_intVal) }
		t.F_precision = result }
//line :1140:1
	return result
}







func (t *BigDecimal) UnscaledValue__BigInteger() *BigInteger { return t.Inflated__BigInteger() }

















func (t *BigDecimal) Round_MathContext__BigDecimal(mc *MathContext) *BigDecimal {
	return t.Plus_MathContext__BigDecimal(mc)
}
func (t *BigDecimal) SetScale_I_RoundingMode__BigDecimal(newScale int32, roundingMode *RoundingMode) *BigDecimal {
	return t.SetScale_I_I__BigDecimal(newScale, roundingMode.F_oldMode)
}
func (t *BigDecimal) SetScale_I_I__BigDecimal(newScale, roundingMode int32) *BigDecimal {

	var tmp1 bool; var tmp2 bool; tmp2 = roundingMode < 0; if !tmp2 { tmp2 = roundingMode > 7 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1219))) }
	var oldScale int32 = t.F_scale
	if newScale == oldScale { return t } else { if t.Signum__I() == 0 {

		return BigDecimal_ZeroValueOf_I__BigDecimal(newScale) } else {
//line :1178:1
			if !(t.F_intCompact == -9223372036854775808) {



				var rs int64 = t.F_intCompact
				if newScale > oldScale {
					var raise int32 = t.CheckScale_J__I(int64(newScale) - int64(oldScale)); var tmp3 int64
					rs = BigDecimal_LongMultiplyPowerTen_J_I__J(rs, raise); tmp3 = rs; if !(tmp3 == -9223372036854775808) {
						return BigDecimal_ValueOf_J_I__BigDecimal(rs, newScale) } else {
							var rb *BigInteger = t.BigMultiplyPowerTen_I__BigInteger(raise); var tmp4 int32



							if t.F_precision > 0 { tmp4 = t.F_precision + raise } else { tmp4 = 0 }
//line :1188:1
							return BigDecimal_New_BigInteger_J_I_I(rb, -9223372036854775808, newScale, tmp4) } } else {



								var drop int32 = t.CheckScale_J__I(int64(oldScale) - int64(newScale))
								if drop < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
									return BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(rs, BigDecimal_LONG_TEN_POWERS_TABLE.A[drop], newScale, roundingMode, newScale) } else {





										return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(t.Inflated__BigInteger(), BigDecimal_BigTenToThe_I__BigInteger(drop), newScale, roundingMode, newScale) } } } else {
//line :1178:1
											if newScale > oldScale {




























												var raise_2 int32 = t.CheckScale_J__I(int64(newScale) - int64(oldScale)); var rb_2 *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(t.F_intVal, raise_2); var tmp5 int32




												if t.F_precision > 0 { tmp5 = t.F_precision + raise_2 } else { tmp5 = 0 }
//line :1209:1
												return BigDecimal_New_BigInteger_J_I_I(rb_2, -9223372036854775808, newScale, tmp5) } else {




													var drop_2 int32 = t.CheckScale_J__I(int64(oldScale) - int64(newScale))
													if drop_2 < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
														var tmp6 *BigInteger = t.F_intVal; return BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(tmp6, BigDecimal_LONG_TEN_POWERS_TABLE.A[drop_2], newScale, roundingMode, newScale) } else {




															var tmp7 *BigInteger = t.F_intVal; return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(tmp7, BigDecimal_BigTenToThe_I__BigInteger(drop_2), newScale, roundingMode, newScale)
														}
												}
										}
		}
	} }
func (t *BigDecimal) SetScale_I__BigDecimal(newScale int32) *BigDecimal {
	return t.SetScale_I_I__BigDecimal(newScale, 7)
}
func (t *BigDecimal) MovePointLeft_I__BigDecimal(n int32) *BigDecimal {
	var tmp1 bool; var tmp2 bool; tmp2 = n == 0; if tmp2 { tmp2 = t.F_scale >= 0 }; tmp1 = tmp2; if tmp1 { return t } else {

		var newScale int32 = t.CheckScale_J__I(int64(t.F_scale) + int64(n)); var num *BigDecimal = BigDecimal_New_BigInteger_J_I_I(t.F_intVal, t.F_intCompact, newScale, 0)

		if num.F_scale < 0 { return NN(num).SetScale_I_I__BigDecimal(0, 7) } else { return num
		} } }
func (t *BigDecimal) MovePointRight_I__BigDecimal(n int32) *BigDecimal {
	var tmp1 bool; var tmp2 bool; tmp2 = n == 0; if tmp2 { tmp2 = t.F_scale >= 0 }; tmp1 = tmp2; if tmp1 { return t } else {

		var newScale int32 = t.CheckScale_J__I(int64(t.F_scale) - int64(n)); var num *BigDecimal = BigDecimal_New_BigInteger_J_I_I(t.F_intVal, t.F_intCompact, newScale, 0)

		if num.F_scale < 0 { return NN(num).SetScale_I_I__BigDecimal(0, 7) } else { return num
		} } }
func (t *BigDecimal) ScaleByPowerOfTen_I__BigDecimal(n int32) *BigDecimal {
	var tmp1 *BigInteger = t.F_intVal; var tmp2 int64 = t.F_intCompact; return BigDecimal_New_BigInteger_J_I_I(tmp1, tmp2, t.CheckScale_J__I(int64(t.F_scale)-int64(n)), t.F_precision)
}
func (t *BigDecimal) StripTrailingZeros__BigDecimal() *BigDecimal {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_intCompact == 0; if !tmp2 { var tmp3 bool; tmp3 = !(t.F_intVal == nil); if tmp3 { tmp3 = NN(t.F_intVal).Signum__I() == 0 }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 { return BigDecimal_ZERO } else {

		return BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(t.F_intVal, t.F_intCompact, t.F_scale, -9223372036854775808)
	} }
func (t *BigDecimal) CompareTo_BigDecimal__I(val *BigDecimal) int32 {
	var tmp1 int32 = t.F_scale; if tmp1 == val.F_scale {
		var xs int64 = t.F_intCompact; var ys int64 = val.F_intCompact; var tmp2 bool; var tmp3 bool

		tmp3 = !(xs == -9223372036854775808); if tmp3 { tmp3 = !(ys == -9223372036854775808) }; tmp2 = tmp3; if tmp2 {
			var tmp4 int32; if !(xs == ys) { if xs > ys { tmp4 = 1 } else { tmp4 = -1 } } else { tmp4 = 0 }; return tmp4 } }
	var xsign int32 = t.Signum__I(); var ysign int32 = NN(val).Signum__I()

	if !(xsign == ysign) {
		if xsign > ysign { return 1 } else { return -1 } } else {
//line :1260:1
			if xsign == 0 { return 0 } else {



				var cmp int32 = t.CompareMagnitude_BigDecimal__I(val); if xsign > 0 { return cmp } else { return -cmp
				} } } }
func (t *BigDecimal) CompareMagnitude_BigDecimal__I(val *BigDecimal) int32 {
	var ys int64 = val.F_intCompact; var xs int64 = t.F_intCompact

	if xs == 0 {
		if ys == 0 { return 0 } else { return -1 } } else {
//line :1269:1
			if ys == 0 { return 1 } else {



				var tmp1 int64 = int64(t.F_scale); var sdiff int64 = tmp1 - int64(val.F_scale)
				if sdiff == 0 { } else {
					var xae int64 = int64(t.Precision__I()) - int64(t.F_scale); var yae int64 = int64(NN(val).Precision__I()) - int64(val.F_scale)

					if xae < yae { return -1 }
					if xae > yae { return 1 }
					if sdiff < 0 {

						var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = sdiff > -2147483648; if tmp4 {
							var tmp5 bool; tmp5 = xs == -9223372036854775808; if !tmp5 {
								var tmp6 int64; xs = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, int32(-sdiff)); tmp6 = xs; tmp5 = tmp6 == -9223372036854775808 }
//line :1282:1
							tmp4 = tmp5 }
//line :1281:1
						tmp3 = tmp4; if tmp3 {







							tmp3 = ys == -9223372036854775808 }
//line :1281:1
						tmp2 = tmp3; if tmp2 {








							var rb *BigInteger = t.BigMultiplyPowerTen_I__BigInteger(int32(-sdiff))
							return NN(rb).CompareMagnitude_BigInteger__I(val.F_intVal) } } else {
//line :1279:1
								var tmp7 bool; var tmp8 bool; var tmp9 bool












								tmp9 = sdiff <= 2147483647; if tmp9 {
									var tmp10 bool; tmp10 = ys == -9223372036854775808; if !tmp10 {
										var tmp11 int64; ys = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, int32(sdiff)); tmp11 = ys; tmp10 = tmp11 == -9223372036854775808 }
//line :1293:1
									tmp9 = tmp10 }
//line :1292:1
								tmp8 = tmp9; if tmp8 {





									tmp8 = xs == -9223372036854775808 }
//line :1292:1
								tmp7 = tmp8
//line :1279:1
								if tmp7 {



















									var rb_2 *BigInteger = NN(val).BigMultiplyPowerTen_I__BigInteger(int32(sdiff))
									return NN(t.F_intVal).CompareMagnitude_BigInteger__I(rb_2) } } }
				if !(xs == -9223372036854775808) {

					if !(ys == -9223372036854775808) { return BigDecimal_LongCompareMagnitude_J_J__I(xs, ys) } else { return -1 } } else {
//line :1301:1
						if !(ys == -9223372036854775808) { return 1 } else {



							var tmp12 *BigInteger = t.F_intVal; return NN(tmp12).CompareMagnitude_BigInteger__I(val.F_intVal)
						} } } } }
func (t *BigDecimal) Equals_O__Z(x any) bool {
	var tmp1 any = x; if BigDecimal_InstanceOf(tmp1) { var xDec *BigDecimal = BigDecimal_Cast(tmp1)
		if any(x) == any(t) { return true } else { var tmp2 int32 = t.F_scale; if !(tmp2 == xDec.F_scale) { return false } else {



			var s int64 = t.F_intCompact; var xs int64 = xDec.F_intCompact

			if !(s == -9223372036854775808) {


				if xs == -9223372036854775808 { xs = BigDecimal_CompactValFor_BigInteger__J(xDec.F_intVal) }
				return xs == s } else {
//line :1315:1
					if !(xs == -9223372036854775808) {




						return xs == BigDecimal_CompactValFor_BigInteger__J(t.F_intVal) } else {
							return NN(t.Inflated__BigInteger()).Equals_O__Z(NN(xDec).Inflated__BigInteger().Ref()) } } } } } else {
//line :1308:1
								return false
							}
}













func (t *BigDecimal) Min_BigDecimal__BigDecimal(val *BigDecimal) *BigDecimal {
	if t.CompareTo_BigDecimal__I(val) <= 0 { return t } else { return val
	} }
func (t *BigDecimal) Max_BigDecimal__BigDecimal(val *BigDecimal) *BigDecimal {
	if t.CompareTo_BigDecimal__I(val) >= 0 { return t } else { return val
	} }
func (t *BigDecimal) HashCode__I() int32 {
	if !(t.F_intCompact == -9223372036854775808) {
		var val2 int64; if t.F_intCompact < 0 { val2 = -t.F_intCompact } else { val2 = t.F_intCompact }; var temp int32 = int32(int64(int32(int64(uint64(val2)>>32))*31) + val2&4294967295); var tmp1 int32






		if t.F_intCompact < 0 { tmp1 = -temp } else { tmp1 = temp }
//line :1338:1
		return 31*tmp1 + t.F_scale } else {


			return 31*NN(t.F_intVal).HashCode__I() + t.F_scale
		} }
func (t *BigDecimal) ToString__String() *String {
	var sc *String = t.F_stringCache
	if sc == nil { var tmp1 *String; sc = t.LayoutChars_Z__String(true); tmp1 = sc; t.F_stringCache = tmp1 }
//line :1344:1
	return sc
}


func (t *BigDecimal) ToEngineeringString__String() *String {
	return t.LayoutChars_Z__String(false)
}
func (t *BigDecimal) ToPlainString__String() *String {
	if t.F_scale == 0 {
		if !(t.F_intCompact == -9223372036854775808) { return Long_ToString_J__String(t.F_intCompact) } else { return NN(t.F_intVal).ToString__String() } } else {
//line :1352:1
			if t.F_scale < 0 {


				if t.Signum__I() == 0 { return Lit_1133 } else {

					var trailingZeros int32 = BigDecimal_CheckScaleNonZero_J__I(-int64(t.F_scale)); var str *String
					if !(t.F_intCompact == -9223372036854775808) {
						str = Long_ToString_J__String(t.F_intCompact) } else {
							str = NN(t.F_intVal).ToString__String() }
//line :1357:1
					var len_ int32 = NN(str).Length__I() + trailingZeros




					if len_ < 0 { panic(Thrown(OutOfMemoryError_New_String(Lit_1235))) }
					var buf *StringBuilder = StringBuilder_New_I(len_)
					NN(buf).Append_String__StringBuilder(str)
					NN(buf).Repeat_I_I__StringBuilder(48, trailingZeros)
					return NN(buf).ToString__String() } } else {

						var str_2 *String; if !(t.F_intCompact == -9223372036854775808) {
							str_2 = Long_ToString_J__String(Math_Abs_J__J(t.F_intCompact)) } else {
								str_2 = NN(NN(t.F_intVal).Abs__BigInteger()).ToString__String() }
						return BigDecimal_GetValueString_I_String_I__String(t.Signum__I(), str_2, t.F_scale)
					} } }
func BigDecimal_GetValueString_I_String_I__String(signum int32, intString *String, scale int32) *String { BigDecimal_Init()
	var buf *StringBuilder; var insertionPoint int32 = NN(intString).Length__I() - scale

	if insertionPoint == 0 {
		var tmp1 *String; if signum < 0 { tmp1 = Lit_1236 } else { tmp1 = Lit_1237 }; return Concat(tmp1, intString) } else {

			if insertionPoint > 0 {

				buf = StringBuilder_New_String(intString)
				NN(buf).Insert_I_C__StringBuilder(insertionPoint, 46)
				if signum < 0 { NN(buf).Insert_I_C__StringBuilder(0, 45) } } else {
					var len_ int32; var tmp2 int32; if signum < 0 { tmp2 = 3 } else { tmp2 = 2 }; len_ = tmp2 + scale
					if len_ < 0 { panic(Thrown(OutOfMemoryError_New_String(Lit_1235))) }
					buf = StringBuilder_New_I(len_)
					var tmp3 *StringBuilder = buf; var tmp4 *String; if signum < 0 { tmp4 = Lit_1236 } else { tmp4 = Lit_1237 }; NN(tmp3).Append_String__StringBuilder(tmp4)
					NN(buf).Repeat_I_I__StringBuilder(48, -insertionPoint)
					NN(buf).Append_String__StringBuilder(intString) }
			return NN(buf).ToString__String()
		} }
func (t *BigDecimal) IsInteger__Z() bool {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_scale <= 0; if !tmp2 { tmp2 = t.Signum__I() == 0 }; tmp1 = tmp2; if tmp1 { return true } else {

		var digitLen int32; if !(t.F_precision == 0) { digitLen = t.F_precision } else { if !(t.F_intCompact == -9223372036854775808) {

			digitLen = t.Precision__I() } else {

				digitLen = BigDecimal_DigitLengthLower_BigInteger__I(t.UnscaledValue__BigInteger()) + 1
			}
		}
		var tmp3 bool; tmp3 = digitLen > t.F_scale; if tmp3 {
			tmp3 = BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(t.F_intVal, t.F_intCompact, t.F_scale, 0).F_scale == 0 }
//line :1402:1
		return tmp3
	}
}
func (t *BigDecimal) ToBigInteger__BigInteger() *BigInteger {
	return NN(t.SetScale_I_I__BigDecimal(0, 1)).Inflated__BigInteger()
}
func (t *BigDecimal) ToBigIntegerExact__BigInteger() *BigInteger {
	return NN(t.SetScale_I_I__BigDecimal(0, 7)).Inflated__BigInteger()
}
func (t *BigDecimal) LongValue__J() int64 {
	var tmp1 bool; var tmp2 bool
	tmp2 = !(t.F_intCompact == -9223372036854775808); if tmp2 { tmp2 = t.F_scale == 0 }; tmp1 = tmp2
//line :1412:1
	if tmp1 { return t.F_intCompact } else { var tmp3 bool; var tmp4 bool; var tmp5 bool

		tmp5 = t.Signum__I() == 0; if !tmp5 { tmp5 = t.FractionOnly__Z() }; tmp4 = tmp5; if !tmp4 { tmp4 = t.F_scale <= -64 }; tmp3 = tmp4
//line :1412:1
		if tmp3 { return 0 } else {


			return NN(t.ToBigInteger__BigInteger()).LongValue__J()
		} } }
func (t *BigDecimal) FractionOnly__Z() bool {
	if !A2g_AssertionsDisabled && !!(t.Signum__I() == 0) { panic(Thrown(AssertionError_New())) }
	return t.Precision__I() <= t.F_scale
}
func (t *BigDecimal) LongValueExact__J() int64 {
	var tmp1 bool; var tmp2 bool
	tmp2 = !(t.F_intCompact == -9223372036854775808); if tmp2 { tmp2 = t.F_scale == 0 }; tmp1 = tmp2
//line :1422:1
	if tmp1 { return t.F_intCompact } else { if t.Signum__I() == 0 { return 0 } else {




		if t.FractionOnly__Z() { panic(Thrown(ArithmeticException_New_String(Lit_1238))) }
		if t.Precision__I()-19 > t.F_scale {
			panic(Thrown(ArithmeticException_New_String(Lit_1227))) }
		var num *BigDecimal = t.SetScale_I_I__BigDecimal(0, 7)
		if NN(num).Precision__I() >= 19 { BigDecimal_LongOverflow_Check_BigDecimal__V(num) }
		return NN(NN(num).Inflated__BigInteger()).LongValue__J()
	}
	}
}



func BigDecimal_LongOverflow_Check_BigDecimal__V(num *BigDecimal) { BigDecimal_LongOverflow_Init()
	var intVal *BigInteger = NN(num).Inflated__BigInteger(); var tmp1 bool; var tmp2 bool
	tmp2 = NN(intVal).CompareTo_BigInteger__I(BigDecimal_LongOverflow_LONGMIN) < 0; if !tmp2 { tmp2 = NN(intVal).CompareTo_BigInteger__I(BigDecimal_LongOverflow_LONGMAX) > 0 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(ArithmeticException_New_String(Lit_1227)))
	} }
func (t *BigDecimal) IntValue__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_intCompact == -9223372036854775808); if tmp2 { tmp2 = t.F_scale == 0 }; tmp1 = tmp2; if tmp1 {
		return int32(t.F_intCompact) } else {
			return int32(t.LongValue__J())
		} }
func (t *BigDecimal) IntValueExact__I() int32 {
	var num int64 = 0
	num = t.LongValueExact__J()
	if int64(int32(num)) == num { } else { panic(Thrown(ArithmeticException_New_String(Lit_1227))) }
	return int32(num)
}
func (t *BigDecimal) ShortValueExact__S() int16 {
	var num int64 = 0
	num = t.LongValueExact__J()
	if int64(int16(num)) == num { } else { panic(Thrown(ArithmeticException_New_String(Lit_1227))) }
	return int16(num)
}
func (t *BigDecimal) ByteValueExact__B() int8 {
	var num int64 = 0
	num = t.LongValueExact__J()
	if int64(int8(num)) == num { } else { panic(Thrown(ArithmeticException_New_String(Lit_1227))) }
	return int8(num)
}
func (t *BigDecimal) FloatValue__F() float32 {
	if t.F_intCompact == -9223372036854775808 { } else {
		var v float32 = float32(t.F_intCompact)
		if t.F_scale == 0 { return v }
		if F2L(v) == t.F_intCompact {
			var tmp1 bool; var tmp2 bool; tmp2 = 0 < t.F_scale; if tmp2 { var tmp3 int32 = t.F_scale; tmp2 = tmp3 < int32(len(BigDecimal_FLOAT_10_POW.A)) }; tmp1 = tmp2; if tmp1 {
				return v / BigDecimal_FLOAT_10_POW.A[t.F_scale] }
			var tmp4 bool; var tmp5 bool; tmp5 = 0 > t.F_scale; if tmp5 { var tmp6 int32 = t.F_scale; tmp5 = tmp6 > -int32(len(BigDecimal_FLOAT_10_POW.A)) }; tmp4 = tmp5; if tmp4 {
				return float32(v * BigDecimal_FLOAT_10_POW.A[-t.F_scale]) } } }
	return t.FullFloatValue__F()
}
func (t *BigDecimal) FullFloatValue__F() float32 {
	if t.F_intCompact == 0 {
		return 0.0 } else {
			var w *BigInteger = NN(t.UnscaledValue__BigInteger()).Abs__BigInteger(); var qb int64 = int64(NN(w).BitLength__I()) - D2L(Math_Ceil_D__D(float64(float64(t.F_scale)*3.321928094887362)))


			if qb < -151 {

				return float32(float32(t.Signum__I()) * 0.0) } else {
//line :1484:1
					if qb > 129 {



						return float32(float32(t.Signum__I()) * PosInf32) } else {
//line :1484:1
							if t.F_scale < 0 {





								return float32(float32(t.Signum__I()) * NN(NN(w).Multiply_BigInteger__BigInteger(BigDecimal_BigTenToThe_I__BigInteger(-t.F_scale))).FloatValue__F()) } else {
//line :1484:1
									if t.F_scale == 0 {










										return float32(float32(t.Signum__I()) * NN(w).FloatValue__F()) } else {

											var ql int32 = int32(qb) - 27; var pow10 *BigInteger = BigDecimal_BigTenToThe_I__BigInteger(t.F_scale); var m *BigInteger; var n *BigInteger



											if ql <= 0 {
												m = NN(w).ShiftLeft_I__BigInteger(-ql); n = pow10 } else {
													m = w; n = NN(pow10).ShiftLeft_I__BigInteger(ql) }
											var qr *RefArray = NN(m).DivideAndRemainder_BigInteger__BigInteger1(n); var i int32 = NN(As[*BigInteger](qr.A[0])).IntValue__I(); var sb int32 = NN(As[*BigInteger](qr.A[1])).Signum__I(); var dq int32 = 6 - Integer_NumberOfLeadingZeros_I__I(i); var eq int32 = -151 - ql






											if dq >= eq {
												return float32(float32(t.Signum__I()) * Math_Scalb_F_I__F(float32(i|sb), ql)) } else {

													var mask int32 = 1<<(eq&31) - 1; var j int32 = i>>(eq&31) | Integer_Signum_I__I(i&mask) | sb




													return float32(float32(t.Signum__I()) * Math_Scalb_F_I__F(float32(j), -151))
												}
										}
								} } } } }
func (t *BigDecimal) DoubleValue__D() float64 {
	if t.F_intCompact == -9223372036854775808 { } else {
		var v float64 = float64(t.F_intCompact)
		if t.F_scale == 0 { return v }
		if D2L(v) == t.F_intCompact {
			var tmp1 bool; var tmp2 bool; tmp2 = 0 < t.F_scale; if tmp2 { var tmp3 int32 = t.F_scale; tmp2 = tmp3 < int32(len(BigDecimal_DOUBLE_10_POW.A)) }; tmp1 = tmp2; if tmp1 {
				return v / BigDecimal_DOUBLE_10_POW.A[t.F_scale] }
			var tmp4 bool; var tmp5 bool; tmp5 = 0 > t.F_scale; if tmp5 { var tmp6 int32 = t.F_scale; tmp5 = tmp6 > -int32(len(BigDecimal_DOUBLE_10_POW.A)) }; tmp4 = tmp5; if tmp4 {
				return float64(v * BigDecimal_DOUBLE_10_POW.A[-t.F_scale]) } } }
	return t.FullDoubleValue__D()
}
func (t *BigDecimal) FullDoubleValue__D() float64 {
	if t.F_intCompact == 0 { return 0.0 } else {

		var w *BigInteger = NN(t.UnscaledValue__BigInteger()).Abs__BigInteger(); var qb int64 = int64(NN(w).BitLength__I()) - D2L(Math_Ceil_D__D(float64(float64(t.F_scale)*3.321928094887362)))


		if qb < -1076 {
			return float64(float64(t.Signum__I()) * 0.0) } else {
//line :1540:1
				if qb > 1025 {


					return float64(float64(t.Signum__I()) * PosInf64) } else {
//line :1540:1
						if t.F_scale < 0 {




							return float64(float64(t.Signum__I()) * NN(NN(w).Multiply_BigInteger__BigInteger(BigDecimal_BigTenToThe_I__BigInteger(-t.F_scale))).DoubleValue__D()) } else {
//line :1540:1
								if t.F_scale == 0 {









									return float64(float64(t.Signum__I()) * NN(w).DoubleValue__D()) } else {

										var ql int32 = int32(qb) - 56; var pow10 *BigInteger = BigDecimal_BigTenToThe_I__BigInteger(t.F_scale); var m *BigInteger; var n *BigInteger



										if ql <= 0 {
											m = NN(w).ShiftLeft_I__BigInteger(-ql); n = pow10 } else {
												m = w; n = NN(pow10).ShiftLeft_I__BigInteger(ql) }
										var qr *RefArray = NN(m).DivideAndRemainder_BigInteger__BigInteger1(n); var i int64 = NN(As[*BigInteger](qr.A[0])).LongValue__J(); var sb int32 = NN(As[*BigInteger](qr.A[1])).Signum__I(); var dq int32 = 9 - Long_NumberOfLeadingZeros_J__I(i); var eq int32 = -1076 - ql






										if dq >= eq {
											return float64(float64(t.Signum__I()) * Math_Scalb_D_I__D(float64(i|int64(sb)), ql)) } else {
												var mask int64 = 1<<(eq&63) - 1; var j int64 = i>>(eq&63) | int64(Long_Signum_J__I(i&mask)) | int64(sb)


												return float64(float64(t.Signum__I()) * Math_Scalb_D_I__D(float64(j), -1076))
											}
									}
							}
					}
			}
	}
}
















func (t *BigDecimal) Ulp__BigDecimal() *BigDecimal {
	return BigDecimal_ValueOf_J_I_I__BigDecimal(1, t.Scale__I(), 1)
}
func (t *BigDecimal) LayoutChars_Z__String(sci bool) *String {
	var intCompact int64 = t.F_intCompact; var scale int32 = t.F_scale

	if scale == 0 {

		if !(intCompact == -9223372036854775808) { return Long_ToString_J__String(intCompact) } else { return NN(t.F_intVal).ToString__String() } } else {
//line :1601:1
			var tmp1 bool; var tmp2 bool; var tmp3 bool


			tmp3 = scale == 2; if tmp3 { tmp3 = intCompact >= 0 }; tmp2 = tmp3; if tmp2 { tmp2 = intCompact < 2147483647 }; tmp1 = tmp2
//line :1601:1
			if tmp1 {



				var lowInt int32 = int32(intCompact) % 100; var highInt int32 = int32(intCompact) / 100; var highIntSize int32 = DecimalDigits_StringSize_I__I(highInt); var buf *ByteArray = NewByteArray(highIntSize + 3)



				DecimalDigits_UncheckedGetCharsLatin1_I_I_B1__I(highInt, highIntSize, buf)
				buf.A[highIntSize] = 46
				DecimalDigits_UncheckedPutPairLatin1_B1_I_I__V(buf, highIntSize+1, lowInt)
				return BigDecimal_JLA.UncheckedNewStringWithLatin1Bytes_B1__String(buf) } else {

					var coeff *CharArray
					var offset int32 = 0
					if !(intCompact == -9223372036854775808) {

						coeff = NewCharArray(19)
						offset = DecimalDigits_GetChars_J_I_C1__I(Math_Abs_J__J(intCompact), int32(len(coeff.A)), coeff) } else {
							offset = 0; coeff = NN(NN(NN(t.F_intVal).Abs__BigInteger()).ToString__String()).ToCharArray__C1() }
					var buf_2 *StringBuilder = StringBuilder_New_I(32)
					if t.Signum__I() < 0 { NN(buf_2).Append_C__StringBuilder(45) }
					var coeffLen int32 = int32(len(coeff.A)) - offset; var adjusted int64 = -int64(scale) + int64(coeffLen-1); var tmp4 bool; var tmp5 bool



					tmp5 = scale >= 0; if tmp5 { tmp5 = adjusted >= -6 }; tmp4 = tmp5; if tmp4 {
						var pad int32 = scale - coeffLen
						if pad >= 0 {

							NN(buf_2).Append_C__StringBuilder(48)
							NN(buf_2).Append_C__StringBuilder(46)
						L1: for { if pad > 0 { NN(buf_2).Append_C__StringBuilder(48); pad = pad - 1; continue L1 }; break L1 }
							NN(buf_2).Append_C1_I_I__StringBuilder(coeff, offset, coeffLen) } else {

								NN(buf_2).Append_C1_I_I__StringBuilder(coeff, offset, -pad)
								NN(buf_2).Append_C__StringBuilder(46)
								NN(buf_2).Append_C1_I_I__StringBuilder(coeff, -pad+offset, scale) } } else {




									if sci {

										NN(buf_2).Append_C__StringBuilder(coeff.A[offset])
										if coeffLen > 1 {
											NN(buf_2).Append_C__StringBuilder(46)
											NN(buf_2).Append_C1_I_I__StringBuilder(coeff, offset+1, coeffLen-1) } } else {



												var sig int32 = int32(adjusted % 3)
												if sig < 0 { sig = sig + 3 }
												adjusted = adjusted - int64(sig)
												sig = sig + 1
												if t.Signum__I() == 0 {

													switch sig { case 1:
														NN(buf_2).Append_C__StringBuilder(48)
//line :1658:1
													case 2:



														NN(buf_2).Append_String__StringBuilder(Lit_1240)
														adjusted = adjusted + 3
//line :1658:1
													case 3:







														NN(buf_2).Append_String__StringBuilder(Lit_1241)
														adjusted = adjusted + 3
//line :1658:1
													default:









														panic(Thrown(AssertionError_New_O(Concat(Lit_1239, StrOfInt(sig)))))} } else {
//line :1656:1
															if sig >= coeffLen {














																NN(buf_2).Append_C1_I_I__StringBuilder(coeff, offset, coeffLen)
																var i int32 = sig - coeffLen; L2: for {
																	if i > 0 { NN(buf_2).Append_C__StringBuilder(48); i = i - 1; continue L2 }
//line :1672:1
																	break L2 } } else {



																		NN(buf_2).Append_C1_I_I__StringBuilder(coeff, offset, sig)
																		NN(buf_2).Append_C__StringBuilder(46)
																		NN(buf_2).Append_C1_I_I__StringBuilder(coeff, offset+sig, coeffLen-sig)
																	}
														}
											}
									if adjusted == 0 { } else {
										NN(buf_2).Append_C__StringBuilder(69)
										if adjusted > 0 { NN(buf_2).Append_C__StringBuilder(43) }
										NN(buf_2).Append_J__StringBuilder(adjusted) } }
					return NN(buf_2).ToString__String()
				} } }
func BigDecimal_BigTenToThe_I__BigInteger(n int32) *BigInteger { BigDecimal_Init()
	if n < 0 { BigInteger_Init(); return BigInteger_ZERO } else { if n < BigDecimal_BIG_TEN_POWERS_TABLE_MAX {


		var pows *RefArray = BigDecimal_BIG_TEN_POWERS_TABLE.Load()
		if n < int32(len(pows.A)) { return As[*BigInteger](pows.A[n]) } else { return BigDecimal_ExpandBigIntegerTenPowers_I__BigInteger(n) } } else {
			var tmp1 *BigInteger; BigInteger_Init(); tmp1 = BigInteger_TEN; return NN(tmp1).Pow_I__BigInteger(n)
		} } }
func BigDecimal_ExpandBigIntegerTenPowers_I__BigInteger(n int32) *BigInteger { BigDecimal_Init()
	var tmp1 *BigInteger; var tmp2 any = BigDecimal_class; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var pows *RefArray = BigDecimal_BIG_TEN_POWERS_TABLE.Load(); var curLen int32 = int32(len(pows.A))

		if curLen <= n {
			var newLen int32 = curLen << 1
		L1: for { if newLen <= n { newLen = newLen << 1; continue L1 }; break L1 }
			pows = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(pows, newLen).Ref(), BigInteger_class.ArrayClass())
			var i int32 = curLen; L2: for {
				if i < newLen {
					var tmp3 *RefArray = pows; var tmp4 *BigInteger = As[*BigInteger](pows.A[i-1]); var tmp5 *BigInteger; BigInteger_Init(); tmp5 = BigInteger_TEN; tmp3.Store(i, NN(tmp4).Multiply_BigInteger__BigInteger(tmp5).Ref())
					i = i + 1; continue L2 }
//line :1704:1
				break L2
			}


			BigDecimal_BIG_TEN_POWERS_TABLE.Store(pows) }
		tmp1 = As[*BigInteger](pows.A[n]) }()
//line :1697:1
	return tmp1
}




































































func BigDecimal_LongMultiplyPowerTen_J_I__J(val int64, n int32) int64 { BigDecimal_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = val == 0; if !tmp2 { tmp2 = n <= 0 }; tmp1 = tmp2; if tmp1 { return val } else {

		var tab *LongArray = BigDecimal_LONG_TEN_POWERS_TABLE; var bounds *LongArray = BigDecimal_THRESHOLDS_TABLE; var tmp3 bool; var tmp4 bool

		tmp4 = n < int32(len(tab.A)); if tmp4 { tmp4 = n < int32(len(bounds.A)) }; tmp3 = tmp4; if tmp3 {
			var tenpower int64 = tab.A[n]
			if val == 1 { return tenpower }
			if Math_Abs_J__J(val) <= bounds.A[n] { return val * tenpower } }
//line :1770:1
		return -9223372036854775808
	}
}





func (t *BigDecimal) BigMultiplyPowerTen_I__BigInteger(n int32) *BigInteger {
	if n <= 0 {
		return t.Inflated__BigInteger() } else {
//line :1779:1
			if !(t.F_intCompact == -9223372036854775808) {

				return NN(BigDecimal_BigTenToThe_I__BigInteger(n)).Multiply_J__BigInteger(t.F_intCompact) } else {
					var tmp1 *BigInteger = t.F_intVal; return NN(tmp1).Multiply_BigInteger__BigInteger(BigDecimal_BigTenToThe_I__BigInteger(n))
				} } }
func (t *BigDecimal) Inflated__BigInteger() *BigInteger {
	if t.F_intVal == nil { return BigInteger_ValueOf_J__BigInteger(t.F_intCompact) } else { return t.F_intVal
	} }
func BigDecimal_MatchScale_BigDecimal1__V(val *RefArray) { BigDecimal_Init()
	var tmp1 int32 = As[*BigDecimal](val.A[0]).F_scale; if tmp1 < As[*BigDecimal](val.A[1]).F_scale {

		var tmp2 *BigDecimal = As[*BigDecimal](val.A[0]); val.Store(0, NN(tmp2).SetScale_I_I__BigDecimal(As[*BigDecimal](val.A[1]).F_scale, 7).Ref()) } else {
//line :1788:1
			var tmp3 int32 = As[*BigDecimal](val.A[1]).F_scale; if tmp3 < As[*BigDecimal](val.A[0]).F_scale {



				var tmp4 *BigDecimal = As[*BigDecimal](val.A[1]); val.Store(1, NN(tmp4).SetScale_I_I__BigDecimal(As[*BigDecimal](val.A[0]).F_scale, 7).Ref())
			}
		}
}










func BigDecimal_UnsafeHolder_SetIntValAndScale_BigDecimal_BigInteger_I__V(p0 *BigDecimal, p1 *BigInteger, p2 int32) { BigDecimal_UnsafeHolder_Init(); panic(A2g_NotTranslated("java.math.BigDecimal$UnsafeHolder.setIntValAndScale(Ljava/math/BigDecimal;Ljava/math/BigInteger;I)V")) }




func BigDecimal_UnsafeHolder_SetIntValVolatile_BigDecimal_BigInteger__V(p0 *BigDecimal, p1 *BigInteger) { BigDecimal_UnsafeHolder_Init(); panic(A2g_NotTranslated("java.math.BigDecimal$UnsafeHolder.setIntValVolatile(Ljava/math/BigDecimal;Ljava/math/BigInteger;)V")) }












func (t *BigDecimal) ReadObjectNoData__V() { panic(A2g_NotTranslated("java.math.BigDecimal.readObjectNoData()V")) }







func BigDecimal_LongDigitLength_J__I(x int64) int32 { BigDecimal_Init()
	if !A2g_AssertionsDisabled && !!(x == -9223372036854775808) { panic(Thrown(AssertionError_New())) }
	if x < 0 { x = -x }
	if x < 10 { return 1 } else {

		var r int32 = int32(uint32((64-Long_NumberOfLeadingZeros_J__I(x)+1)*1233) >> 12); var tab *LongArray = BigDecimal_LONG_TEN_POWERS_TABLE; var tmp1 bool; var tmp2 bool





		tmp2 = r >= int32(len(tab.A)); if !tmp2 { tmp2 = x < tab.A[r] }; tmp1 = tmp2; if tmp1 { return r } else { return r + 1
		} } }
func BigDecimal_BigDigitLength_BigInteger__I(b *BigInteger) int32 { BigDecimal_Init()
	if b.F_signum == 0 { return 1 } else {

		var r int32 = BigDecimal_DigitLengthLower_BigInteger__I(b)
		if NN(b).CompareMagnitude_BigInteger__I(BigDecimal_BigTenToThe_I__BigInteger(r)) < 0 { return r } else { return r + 1
		} } }
func BigDecimal_DigitLengthLower_BigInteger__I(b *BigInteger) int32 { BigDecimal_Init()
	return int32(int64(uint64((int64(NN(NN(b).Abs__BigInteger()).BitLength__I())+1)*646456993) >> 31))
}



func (t *BigDecimal) CheckScale_J__I(val int64) int32 {
	var asInt int32 = int32(val)
	if int64(asInt) == val { } else {
		var tmp1 int32; if val > 2147483647 { tmp1 = 2147483647 } else { tmp1 = -2147483648 }; asInt = tmp1
		var b *BigInteger; var tmp2 bool; var tmp3 bool
		tmp3 = !(t.F_intCompact == 0); if tmp3 { var tmp4 bool; var tmp5 *BigInteger; b = t.F_intVal; tmp5 = b; tmp4 = tmp5 == nil; if !tmp4 { tmp4 = !(NN(b).Signum__I() == 0) }; tmp3 = tmp4 }; tmp2 = tmp3; if tmp2 {
			var tmp6 *String; if asInt > 0 { tmp6 = Lit_1242 } else { tmp6 = Lit_1227 }; panic(Thrown(ArithmeticException_New_String(tmp6))) } }
//line :1858:1
	return asInt
}






func BigDecimal_CompactValFor_BigInteger__J(b *BigInteger) int64 { BigDecimal_Init()
	var m *IntArray = b.F_mag; var len_ int32 = int32(len(m.A))

	if len_ == 0 { return 0 } else {

		var d int32 = m.A[0]; var tmp1 bool; var tmp2 bool
		tmp2 = len_ > 2; if !tmp2 { var tmp3 bool; tmp3 = len_ == 2; if tmp3 { tmp3 = d < 0 }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 { return -9223372036854775808 } else {

			var u int64; if len_ == 2 {
				u = int64(m.A[1])&4294967295 + int64(d)<<32 } else {

					u = int64(d) & 4294967295 }
			if b.F_signum < 0 { return -u } else { return u
			} } } }
func BigDecimal_LongCompareMagnitude_J_J__I(x, y int64) int32 { BigDecimal_Init()
	if x < 0 { x = -x }
	if y < 0 { y = -y }
	return Long_Compare_J_J__I(x, y)
}
func BigDecimal_SaturateLong_J__I(s int64) int32 { BigDecimal_Init()
	var i int32 = int32(s); if s == int64(i) { return i } else { if s < 0 { return -2147483648 } else { return 2147483647
	} } }
func BigDecimal_Print_String_BigDecimal__V(p0 *String, p1 *BigDecimal) { BigDecimal_Init(); panic(A2g_NotTranslated("java.math.BigDecimal.print(Ljava/lang/String;Ljava/math/BigDecimal;)V")) }




func (t *BigDecimal) Audit__BigDecimal() *BigDecimal { panic(A2g_NotTranslated("java.math.BigDecimal.audit()Ljava/math/BigDecimal;")) }




















func BigDecimal_CheckScaleNonZero_J__I(val int64) int32 { BigDecimal_Init()
	var asInt int32 = int32(val)
	if int64(asInt) == val { } else {
		var tmp1 *String; if asInt > 0 { tmp1 = Lit_1242 } else { tmp1 = Lit_1227 }; panic(Thrown(ArithmeticException_New_String(tmp1))) }
//line :1915:1
	return asInt
}



func BigDecimal_CheckScale_J_J__I(intCompact, val int64) int32 { BigDecimal_Init()
	var asInt int32 = int32(val)
	if int64(asInt) == val { } else {
		var tmp1 int32; if val > 2147483647 { tmp1 = 2147483647 } else { tmp1 = -2147483648 }; asInt = tmp1
		if intCompact == 0 { } else {
			var tmp2 *String; if asInt > 0 { tmp2 = Lit_1242 } else { tmp2 = Lit_1227 }; panic(Thrown(ArithmeticException_New_String(tmp2))) } }
//line :1921:1
	return asInt
}





func BigDecimal_CheckScale_BigInteger_J__I(intVal *BigInteger, val int64) int32 { BigDecimal_Init()
	var asInt int32 = int32(val)
	if int64(asInt) == val { } else {
		var tmp1 int32; if val > 2147483647 { tmp1 = 2147483647 } else { tmp1 = -2147483648 }; asInt = tmp1
		if NN(intVal).Signum__I() == 0 { } else {
			var tmp2 *String; if asInt > 0 { tmp2 = Lit_1242 } else { tmp2 = Lit_1227 }; panic(Thrown(ArithmeticException_New_String(tmp2))) } }
//line :1929:1
	return asInt
}





func BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(val *BigDecimal, mc *MathContext) *BigDecimal { BigDecimal_Init()
	var mcp int32 = mc.F_precision
	var wasDivided bool = false
	if mcp > 0 {
		var intVal *BigInteger = val.F_intVal; var compactVal int64 = val.F_intCompact; var scale int32 = val.F_scale; var prec int32 = NN(val).Precision__I(); var mode int32 = mc.F_roundingMode.F_oldMode
		var drop int32 = 0




		if compactVal == -9223372036854775808 {
			drop = prec - mcp
		L1: for { if drop > 0 {
			scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop))
			intVal = BigDecimal_DivideAndRoundByTenPow_BigInteger_I_I__BigInteger(intVal, drop, mode)
			wasDivided = true
			compactVal = BigDecimal_CompactValFor_BigInteger__J(intVal)
			if compactVal == -9223372036854775808 { } else {
				prec = BigDecimal_LongDigitLength_J__I(compactVal)
				break L1 }
			prec = BigDecimal_BigDigitLength_BigInteger__I(intVal)
			drop = prec - mcp
//line :1948:1
			continue L1 }; break L1
		}
		}







		if compactVal == -9223372036854775808 { } else {
			drop = prec - mcp
		L2: for { if drop > 0 {
			scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop))
			var tmp1 int64 = compactVal; var tmp2 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop]; compactVal = BigDecimal_DivideAndRound_J_J_I__J(tmp1, tmp2, mc.F_roundingMode.F_oldMode)




			wasDivided = true
			prec = BigDecimal_LongDigitLength_J__I(compactVal)
			drop = prec - mcp
			intVal = nil
//line :1960:1
			continue L2 }; break L2
		}
		}








		if wasDivided { return BigDecimal_New_BigInteger_J_I_I(intVal, compactVal, scale, prec) } else { return val } } else {
//line :1939:1
			return val
		}
}
































func BigDecimal_DoRound_J_I_MathContext__BigDecimal(compactVal int64, scale int32, mc *MathContext) *BigDecimal { BigDecimal_Init()

	var mcp int32 = mc.F_precision; var tmp1 bool; var tmp2 bool
	tmp2 = mcp > 0; if tmp2 { tmp2 = mcp < 19 }; tmp1 = tmp2; if tmp1 {
		var prec int32 = BigDecimal_LongDigitLength_J__I(compactVal); var drop int32 = prec - mcp

	L1: for { if drop > 0 {
		scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop))
		var tmp3 int64 = compactVal; var tmp4 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop]; compactVal = BigDecimal_DivideAndRound_J_J_I__J(tmp3, tmp4, mc.F_roundingMode.F_oldMode)



		prec = BigDecimal_LongDigitLength_J__I(compactVal)
		drop = prec - mcp
//line :1980:1
		continue L1 }; break L1
	}






		return BigDecimal_ValueOf_J_I_I__BigDecimal(compactVal, scale, prec) } else {
			return BigDecimal_ValueOf_J_I__BigDecimal(compactVal, scale)
		} }
func BigDecimal_DoRound_BigInteger_I_MathContext__BigDecimal(intVal *BigInteger, scale int32, mc *MathContext) *BigDecimal { BigDecimal_Init()

	var mcp int32 = mc.F_precision
	var prec int32 = 0
	if mcp > 0 {
		var compactVal int64 = BigDecimal_CompactValFor_BigInteger__J(intVal); var mode int32 = mc.F_roundingMode.F_oldMode
		var drop int32 = 0

		if compactVal == -9223372036854775808 {
			prec = BigDecimal_BigDigitLength_BigInteger__I(intVal)
			drop = prec - mcp
		L1: for { if drop > 0 {
			scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop))
			intVal = BigDecimal_DivideAndRoundByTenPow_BigInteger_I_I__BigInteger(intVal, drop, mode)
			compactVal = BigDecimal_CompactValFor_BigInteger__J(intVal)
			if compactVal == -9223372036854775808 { } else { break L1 }
			prec = BigDecimal_BigDigitLength_BigInteger__I(intVal)
			drop = prec - mcp
//line :2002:1
			continue L1 }; break L1
		}
		}




		if compactVal == -9223372036854775808 { } else {
			prec = BigDecimal_LongDigitLength_J__I(compactVal)
			drop = prec - mcp
		L2: for { if drop > 0 {
			scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop))
			var tmp1 int64 = compactVal; var tmp2 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop]; compactVal = BigDecimal_DivideAndRound_J_J_I__J(tmp1, tmp2, mc.F_roundingMode.F_oldMode)



			prec = BigDecimal_LongDigitLength_J__I(compactVal)
			drop = prec - mcp
//line :2012:1
			continue L2 }; break L2
		}






			return BigDecimal_ValueOf_J_I_I__BigDecimal(compactVal, scale, prec) } }
	return BigDecimal_New_BigInteger_J_I_I(intVal, -9223372036854775808, scale, prec)
}
func BigDecimal_DivideAndRoundByTenPow_BigInteger_I_I__BigInteger(intVal *BigInteger, tenPow, roundingMode int32) *BigInteger { BigDecimal_Init()

	if tenPow < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
		intVal = BigDecimal_DivideAndRound_BigInteger_J_I__BigInteger(intVal, BigDecimal_LONG_TEN_POWERS_TABLE.A[tenPow], roundingMode) } else {

			intVal = BigDecimal_DivideAndRound_BigInteger_BigInteger_I__BigInteger(intVal, BigDecimal_BigTenToThe_I__BigInteger(tenPow), roundingMode) }
//line :2023:1
	return intVal
}







func BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(ldividend, ldivisor int64, scale, roundingMode, preferredScale int32) *BigDecimal { BigDecimal_Init()

	var qsign int32 = 0; var q int64 = ldividend / ldivisor; var tmp1 bool; var tmp2 bool

	tmp2 = roundingMode == 1; if tmp2 { tmp2 = scale == preferredScale }; tmp1 = tmp2; if tmp1 {
		return BigDecimal_ValueOf_J_I__BigDecimal(q, scale) } else {
			var r int64 = ldividend % ldivisor; var tmp3 int32
			if ldividend < 0 == (ldivisor < 0) { tmp3 = 1 } else { tmp3 = -1 }; qsign = tmp3
			if !(r == 0) {

				var increment bool = BigDecimal_NeedIncrement_J_I_I_J_J__Z(ldivisor, roundingMode, qsign, q, r); var tmp4 int64
				if increment { tmp4 = q + int64(qsign) } else { tmp4 = q }; return BigDecimal_ValueOf_J_I__BigDecimal(tmp4, scale) } else {
//line :2040:1
					if !(preferredScale == scale) {




						return BigDecimal_CreateAndStripZerosToMatchScale_J_I_J__BigDecimal(q, scale, int64(preferredScale)) } else {
							return BigDecimal_ValueOf_J_I__BigDecimal(q, scale)
						} } } }
func BigDecimal_DivideAndRound_J_J_I__J(ldividend, ldivisor int64, roundingMode int32) int64 { BigDecimal_Init()
	var qsign int32 = 0; var q int64 = ldividend / ldivisor

	if roundingMode == 1 { return q } else {

		var r int64 = ldividend % ldivisor; var tmp1 int32
		if ldividend < 0 == (ldivisor < 0) { tmp1 = 1 } else { tmp1 = -1 }; qsign = tmp1
		if !(r == 0) {
			var increment bool = BigDecimal_NeedIncrement_J_I_I_J_J__Z(ldivisor, roundingMode, qsign, q, r)
			if increment { return q + int64(qsign) } else { return q } } else {
//line :2055:1
				return q
			}
	}
}

func BigDecimal_CommonNeedIncrement_I_I_I_Z__Z(roundingMode, qsign, cmpFracHalf int32, oddQuot bool) bool { BigDecimal_Init()

	switch roundingMode { case 7:
		panic(Thrown(ArithmeticException_New_String(Lit_1238))); case 0:
//line :2062:1
		return true
	case 1:
//line :2062:1
		return false
	case 2:


		return qsign > 0; case 3:
		return qsign < 0; default:

		var tmp1 bool; var tmp2 bool; tmp2 = roundingMode >= 4; if tmp2 { tmp2 = roundingMode <= 6 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New_O(Concat(Lit_1243, StrOfObj(RoundingMode_ValueOf_I__RoundingMode(roundingMode).Ref())))))
		}
		if cmpFracHalf < 0 { return false } else { if cmpFracHalf > 0 { return true } else {




			if !A2g_AssertionsDisabled && !(cmpFracHalf == 0) { panic(Thrown(AssertionError_New())) }
			switch roundingMode { case 5: return false; case 4: return true; case 6: return oddQuot; default:



				panic(Thrown(AssertionError_New_O(Concat(Lit_1243, StrOfInt(roundingMode)))))} } }}; panic("a2g: unreachable")
}
func BigDecimal_NeedIncrement_J_I_I_J_J__Z(ldivisor int64, roundingMode, qsign int32, q, r int64) bool { BigDecimal_Init()

	if !A2g_AssertionsDisabled && !!(r == 0) { panic(Thrown(AssertionError_New())) }
	var cmpFracHalf int32; var tmp1 bool; var tmp2 bool; tmp2 = r <= -4611686018427387904; if !tmp2 { tmp2 = r > 4611686018427387903 }; tmp1 = tmp2; if tmp1 { cmpFracHalf = 1 } else {

		cmpFracHalf = BigDecimal_LongCompareMagnitude_J_J__I(2*r, ldivisor) }
	return BigDecimal_CommonNeedIncrement_I_I_I_Z__Z(roundingMode, qsign, cmpFracHalf, !(q&1 == 0))
}
func BigDecimal_DivideAndRound_BigInteger_J_I__BigInteger(bdividend *BigInteger, ldivisor int64, roundingMode int32) *BigInteger { BigDecimal_Init()

	var mdividend MutableBigInteger_I = MutableBigInteger_New_I1(bdividend.F_mag); var mq MutableBigInteger_I = MutableBigInteger_New(); var r int64 = mdividend.Divide_J_MutableBigInteger__J(ldivisor, mq); var isRemainderZero bool = r == 0; var qsign int32



	if ldivisor < 0 {
		qsign = -bdividend.F_signum } else {
			qsign = bdividend.F_signum }
	if isRemainderZero { } else {
		if BigDecimal_NeedIncrement_J_I_I_MutableBigInteger_J__Z(ldivisor, roundingMode, qsign, mq, r) {
			var tmp1 MutableBigInteger_I; MutableBigInteger_Init(); tmp1 = MutableBigInteger_ONE; mq.Add_MutableBigInteger__V(tmp1) } }
	return mq.ToBigInteger_I__BigInteger(qsign)
}
func BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(bdividend *BigInteger, ldivisor int64, scale, roundingMode, preferredScale int32) *BigDecimal { BigDecimal_Init()


	var mdividend MutableBigInteger_I = MutableBigInteger_New_I1(bdividend.F_mag); var mq MutableBigInteger_I = MutableBigInteger_New(); var r int64 = mdividend.Divide_J_MutableBigInteger__J(ldivisor, mq); var isRemainderZero bool = r == 0; var qsign int32



	if ldivisor < 0 {
		qsign = -bdividend.F_signum } else {
			qsign = bdividend.F_signum }
	if !isRemainderZero {


		if BigDecimal_NeedIncrement_J_I_I_MutableBigInteger_J__Z(ldivisor, roundingMode, qsign, mq, r) {
			var tmp1 MutableBigInteger_I; MutableBigInteger_Init(); tmp1 = MutableBigInteger_ONE; mq.Add_MutableBigInteger__V(tmp1) }
		return mq.ToBigDecimal_I_I__BigDecimal(qsign, scale) } else {
//line :2115:1
			if !(preferredScale == scale) {






				var compactVal int64 = mq.ToCompactValue_I__J(qsign)
				if !(compactVal == -9223372036854775808) {
					return BigDecimal_CreateAndStripZerosToMatchScale_J_I_J__BigDecimal(compactVal, scale, int64(preferredScale)) } else {
						var intVal *BigInteger = mq.ToBigInteger_I__BigInteger(qsign)
						return BigDecimal_CreateAndStripZerosToMatchScale_BigInteger_I_J__BigDecimal(intVal, scale, int64(preferredScale)) } } else {
							return mq.ToBigDecimal_I_I__BigDecimal(qsign, scale)
						} } }
func BigDecimal_NeedIncrement_J_I_I_MutableBigInteger_J__Z(ldivisor int64, roundingMode, qsign int32, mq MutableBigInteger_I, r int64) bool { BigDecimal_Init()

	if !A2g_AssertionsDisabled && !!(r == 0) { panic(Thrown(AssertionError_New())) }
	var cmpFracHalf int32; var tmp1 bool; var tmp2 bool; tmp2 = r <= -4611686018427387904; if !tmp2 { tmp2 = r > 4611686018427387903 }; tmp1 = tmp2; if tmp1 { cmpFracHalf = 1 } else {

		cmpFracHalf = BigDecimal_LongCompareMagnitude_J_J__I(2*r, ldivisor) }
	return BigDecimal_CommonNeedIncrement_I_I_I_Z__Z(roundingMode, qsign, cmpFracHalf, mq.IsOdd__Z())
}
func BigDecimal_DivideAndRound_BigInteger_BigInteger_I__BigInteger(bdividend, bdivisor *BigInteger, roundingMode int32) *BigInteger { BigDecimal_Init()

	var isRemainderZero bool = false; var qsign int32 = 0; var mdividend MutableBigInteger_I = MutableBigInteger_New_I1(bdividend.F_mag); var mq MutableBigInteger_I = MutableBigInteger_New(); var mdivisor MutableBigInteger_I = MutableBigInteger_New_I1(bdivisor.F_mag); var mr MutableBigInteger_I = mdividend.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(mdivisor, mq)





	isRemainderZero = mr.IsZero__Z()
	var tmp1 int32; var tmp2 int32 = bdividend.F_signum; if !(tmp2 == bdivisor.F_signum) { tmp1 = -1 } else { tmp1 = 1 }; qsign = tmp1
	if isRemainderZero { } else {
		if BigDecimal_NeedIncrement_MutableBigInteger_I_I_MutableBigInteger_MutableBigInteger__Z(mdivisor, roundingMode, qsign, mq, mr) {
			var tmp3 MutableBigInteger_I; MutableBigInteger_Init(); tmp3 = MutableBigInteger_ONE; mq.Add_MutableBigInteger__V(tmp3) } }
	return mq.ToBigInteger_I__BigInteger(qsign)
}
func BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(bdividend, bdivisor *BigInteger, scale, roundingMode, preferredScale int32) *BigDecimal { BigDecimal_Init()


	var isRemainderZero bool = false; var qsign int32 = 0; var mdividend MutableBigInteger_I = MutableBigInteger_New_I1(bdividend.F_mag); var mq MutableBigInteger_I = MutableBigInteger_New(); var mdivisor MutableBigInteger_I = MutableBigInteger_New_I1(bdivisor.F_mag); var mr MutableBigInteger_I = mdividend.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(mdivisor, mq)





	isRemainderZero = mr.IsZero__Z()
	var tmp1 int32; var tmp2 int32 = bdividend.F_signum; if !(tmp2 == bdivisor.F_signum) { tmp1 = -1 } else { tmp1 = 1 }; qsign = tmp1
	if !isRemainderZero {


		if BigDecimal_NeedIncrement_MutableBigInteger_I_I_MutableBigInteger_MutableBigInteger__Z(mdivisor, roundingMode, qsign, mq, mr) {
			var tmp3 MutableBigInteger_I; MutableBigInteger_Init(); tmp3 = MutableBigInteger_ONE; mq.Add_MutableBigInteger__V(tmp3) }
		return mq.ToBigDecimal_I_I__BigDecimal(qsign, scale) } else {
//line :2163:1
			if !(preferredScale == scale) {






				var compactVal int64 = mq.ToCompactValue_I__J(qsign)
				if !(compactVal == -9223372036854775808) {
					return BigDecimal_CreateAndStripZerosToMatchScale_J_I_J__BigDecimal(compactVal, scale, int64(preferredScale)) } else {
						var intVal *BigInteger = mq.ToBigInteger_I__BigInteger(qsign)
						return BigDecimal_CreateAndStripZerosToMatchScale_BigInteger_I_J__BigDecimal(intVal, scale, int64(preferredScale)) } } else {
							return mq.ToBigDecimal_I_I__BigDecimal(qsign, scale)
						} } }
func BigDecimal_NeedIncrement_MutableBigInteger_I_I_MutableBigInteger_MutableBigInteger__Z(mdivisor MutableBigInteger_I, roundingMode, qsign int32, mq, mr MutableBigInteger_I) bool { BigDecimal_Init()


	if !A2g_AssertionsDisabled && !!mr.IsZero__Z() { panic(Thrown(AssertionError_New())) }
	var cmpFracHalf int32 = mr.CompareHalf_MutableBigInteger__I(mdivisor)
	return BigDecimal_CommonNeedIncrement_I_I_I_Z__Z(roundingMode, qsign, cmpFracHalf, mq.IsOdd__Z())
}










func BigDecimal_FiveToTwoToThe_I__BigInteger(n int32) *BigInteger { BigDecimal_Init()
	var i int32 = Math_Min_I_I__I(n, int32(len(BigDecimal_FIVE_TO_2_TO.A))-1); var pow *BigInteger = As[*BigInteger](BigDecimal_FIVE_TO_2_TO.A[i])

L1: for { if i < n { pow = NN(pow).Multiply_BigInteger__BigInteger(pow); i = i + 1; continue L1 }; break L1 }
//line :2195:1
	return pow
}





func BigDecimal_CreateAndStripZerosToMatchScale_BigInteger_I_J__BigDecimal(intVal *BigInteger, scale int32, preferredScale int64) *BigDecimal { BigDecimal_Init()


	preferredScale = Math_Clamp_J_J_J__J(preferredScale, -2147483649, 2147483647)

	var powsOf2 int32 = NN(intVal).GetLowestSetBit__I(); var remainingZeros int64 = Math_Min_J_J__J(int64(scale)-preferredScale, int64(powsOf2))

	if remainingZeros <= 0 {
		return BigDecimal_ValueOf_BigInteger_I_I__BigDecimal(intVal, scale, 0) } else {
			var sign int32 = intVal.F_signum
			if sign < 0 { intVal = NN(intVal).Negate__BigInteger() }
			intVal = NN(intVal).ShiftRight_I__BigInteger(powsOf2)
			var maxPowsOf5 int64 = Math_Round_D__J(float64(float64(NN(intVal).BitLength__I()) * 0.43067655807339306))
			remainingZeros = Math_Min_J_J__J(remainingZeros, maxPowsOf5)
			var qr *RefArray; var i int32 = 0
		L1: for {
			if remainingZeros >= 1<<(i&63) {
				var exp int32 = 1 << (i & 31)
				qr = NN(intVal).DivideAndRemainder_BigInteger__BigInteger1(BigDecimal_FiveToTwoToThe_I__BigInteger(i))
				if !(As[*BigInteger](qr.A[1]).F_signum == 0) {

					remainingZeros = int64(exp - 1)
					i = i + 1; continue L1 } else {

						intVal = As[*BigInteger](qr.A[0])
						scale = BigDecimal_CheckScale_BigInteger_J__I(intVal, int64(scale)-int64(exp))



						remainingZeros = remainingZeros - int64(exp)
						powsOf2 = powsOf2 - exp
						i = i + 1; continue L1 } }
//line :2217:1
			break L1
		}















			var i_2 int32 = BigInteger_BitLengthForLong_J__I(remainingZeros) - 1


		L2: for { if i_2 >= 0 {
			var exp_2 int32 = 1 << (i_2 & 31)
			qr = NN(intVal).DivideAndRemainder_BigInteger__BigInteger1(BigDecimal_FiveToTwoToThe_I__BigInteger(i_2))
			if !(As[*BigInteger](qr.A[1]).F_signum == 0) {
				remainingZeros = int64(exp_2 - 1) } else {

					intVal = As[*BigInteger](qr.A[0])
					scale = BigDecimal_CheckScale_BigInteger_J__I(intVal, int64(scale)-int64(exp_2))



					remainingZeros = remainingZeros - int64(exp_2)
					powsOf2 = powsOf2 - exp_2
					if remainingZeros < int64(exp_2>>1) {
						i_2 = BigInteger_BitLengthForLong_J__I(remainingZeros) } }
			i_2 = i_2 - 1
//line :2237:1
			continue L2 }; break L2
		}














			intVal = NN(intVal).ShiftLeft_I__BigInteger(powsOf2)
			var tmp1 *BigInteger; if sign >= 0 { tmp1 = intVal } else { tmp1 = NN(intVal).Negate__BigInteger() }; return BigDecimal_ValueOf_BigInteger_I_I__BigDecimal(tmp1, scale, 0)
		} }
func BigDecimal_CreateAndStripZerosToMatchScale_J_I_J__BigDecimal(compactVal int64, scale int32, preferredScale int64) *BigDecimal { BigDecimal_Init()


L1: for { var tmp1 bool; var tmp2 bool; tmp2 = compactVal%10 == 0; if tmp2 { tmp2 = int64(scale) > preferredScale }; tmp1 = tmp2; if tmp1 {
	compactVal = compactVal / 10
	scale = BigDecimal_CheckScale_J_J__I(compactVal, int64(scale)-1)
//line :2259:1
	continue L1 }; break L1
}

	return BigDecimal_ValueOf_J_I__BigDecimal(compactVal, scale)
}
func BigDecimal_StripZerosToMatchScale_BigInteger_J_I_J__BigDecimal(intVal *BigInteger, intCompact int64, scale int32, preferredScale int64) *BigDecimal { BigDecimal_Init()

	if !(intCompact == -9223372036854775808) {
		return BigDecimal_CreateAndStripZerosToMatchScale_J_I_J__BigDecimal(intCompact, scale, preferredScale) } else {
			var tmp1 *BigInteger
			if intVal == nil { tmp1 = BigDecimal_INFLATED_BIGINT } else { tmp1 = intVal }
//line :2268:1
			return BigDecimal_CreateAndStripZerosToMatchScale_BigInteger_I_J__BigDecimal(tmp1, scale, preferredScale)
		}
}


func BigDecimal_Add_J_J__J(xs, ys int64) int64 { BigDecimal_Init()
	var sum int64 = xs + ys
	if (sum^xs)&(sum^ys) >= 0 { return sum } else { return -9223372036854775808
	} }
func BigDecimal_Add_J_J_I__BigDecimal(xs, ys int64, scale int32) *BigDecimal { BigDecimal_Init()
	var sum int64 = BigDecimal_Add_J_J__J(xs, ys)
	if !(sum == -9223372036854775808) {
		return BigDecimal_ValueOf_J_I__BigDecimal(sum, scale) } else {
			return BigDecimal_New_BigInteger_I(NN(BigInteger_ValueOf_J__BigInteger(xs)).Add_J__BigInteger(ys), scale)
		} }
func BigDecimal_Add_J_I_J_I__BigDecimal(xs int64, scale1 int32, ys int64, scale2 int32) *BigDecimal { BigDecimal_Init()

	var sdiff int64 = int64(scale1) - int64(scale2)
	if sdiff == 0 {
		return BigDecimal_Add_J_J_I__BigDecimal(xs, ys, scale1) } else {
//line :2286:1
			if sdiff < 0 {


				var raise int32 = BigDecimal_CheckScale_J_J__I(xs, -sdiff); var scaledX int64 = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, raise)

				if !(scaledX == -9223372036854775808) {
					return BigDecimal_Add_J_J_I__BigDecimal(scaledX, ys, scale2) } else {
						var bigsum *BigInteger = NN(BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(xs, raise)).Add_J__BigInteger(ys)
						if xs^ys >= 0 {
							return BigDecimal_New_BigInteger_J_I_I(bigsum, -9223372036854775808, scale2, 0) } else {
								return BigDecimal_ValueOf_BigInteger_I_I__BigDecimal(bigsum, scale2, 0) } } } else {

									var raise_2 int32 = BigDecimal_CheckScale_J_J__I(ys, sdiff); var scaledY int64 = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, raise_2)

									if !(scaledY == -9223372036854775808) {
										return BigDecimal_Add_J_J_I__BigDecimal(xs, scaledY, scale1) } else {
											var bigsum_2 *BigInteger = NN(BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(ys, raise_2)).Add_J__BigInteger(xs)
											if xs^ys >= 0 {
												return BigDecimal_New_BigInteger_J_I_I(bigsum_2, -9223372036854775808, scale1, 0) } else {
													return BigDecimal_ValueOf_BigInteger_I_I__BigDecimal(bigsum_2, scale1, 0)
												} } } } }
func BigDecimal_Add_J_I_BigInteger_I__BigDecimal(xs int64, scale1 int32, snd *BigInteger, scale2 int32) *BigDecimal { BigDecimal_Init()

	var rscale int32 = scale1; var sdiff int64 = int64(rscale) - int64(scale2); var sameSigns bool = Long_Signum_J__I(xs) == snd.F_signum; var sum *BigInteger



	if sdiff < 0 {
		var raise int32 = BigDecimal_CheckScale_J_J__I(xs, -sdiff)
		rscale = scale2
		var scaledX int64 = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, raise)
		if scaledX == -9223372036854775808 {
			sum = NN(snd).Add_BigInteger__BigInteger(BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(xs, raise)) } else {
				sum = NN(snd).Add_J__BigInteger(scaledX) } } else {
					var raise_2 int32 = BigDecimal_CheckScale_BigInteger_J__I(snd, sdiff)
					snd = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(snd, raise_2)
					sum = NN(snd).Add_J__BigInteger(xs) }
	if sameSigns { return BigDecimal_New_BigInteger_J_I_I(sum, -9223372036854775808, rscale, 0) } else { return BigDecimal_ValueOf_BigInteger_I_I__BigDecimal(sum, rscale, 0)
	} }
func BigDecimal_Add_BigInteger_I_BigInteger_I__BigDecimal(fst *BigInteger, scale1 int32, snd *BigInteger, scale2 int32) *BigDecimal { BigDecimal_Init()

	var rscale int32 = scale1; var sdiff int64 = int64(rscale) - int64(scale2)

	if sdiff == 0 { } else {
		if sdiff < 0 {
			var raise int32 = BigDecimal_CheckScale_BigInteger_J__I(fst, -sdiff)
			rscale = scale2
			fst = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(fst, raise) } else {
				var raise_2 int32 = BigDecimal_CheckScale_BigInteger_J__I(snd, sdiff)
				snd = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(snd, raise_2) } }
	var sum *BigInteger = NN(fst).Add_BigInteger__BigInteger(snd); var tmp1 int32 = fst.F_signum
	if tmp1 == snd.F_signum {
		return BigDecimal_New_BigInteger_J_I_I(sum, -9223372036854775808, rscale, 0) } else {
			return BigDecimal_ValueOf_BigInteger_I_I__BigDecimal(sum, rscale, 0)
		} }
func BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(value int64, n int32) *BigInteger { BigDecimal_Init()
	if n <= 0 { return BigInteger_ValueOf_J__BigInteger(value) } else { return NN(BigDecimal_BigTenToThe_I__BigInteger(n)).Multiply_J__BigInteger(value)
	} }
func BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(value *BigInteger, n int32) *BigInteger { BigDecimal_Init()
	if n <= 0 { return value } else { if n < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {

		return NN(value).Multiply_J__BigInteger(BigDecimal_LONG_TEN_POWERS_TABLE.A[n]) } else {
			return NN(value).Multiply_BigInteger__BigInteger(BigDecimal_BigTenToThe_I__BigInteger(n))
		} } }
func BigDecimal_DivideSmallFastPath_J_I_J_I_J_MathContext__BigDecimal(xs int64, xscale int32, ys int64, yscale int32, preferredScale int64, mc *MathContext) *BigDecimal { BigDecimal_Init()


	var mcp int32 = mc.F_precision; var roundingMode int32 = mc.F_roundingMode.F_oldMode; var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = xscale <= yscale; if tmp3 { tmp3 = yscale < 18 }; tmp2 = tmp3; if tmp2 { tmp2 = mcp < 18 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var xraise int32 = yscale - xscale; var scaledX int64
	if xraise == 0 { scaledX = xs } else { scaledX = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, xraise) }
//line :2356:1
	var quotient *BigDecimal; var cmp int32 = BigDecimal_LongCompareMagnitude_J_J__I(scaledX, ys)



	if cmp > 0 {

		yscale = yscale - 1
		var scl int32 = BigDecimal_CheckScaleNonZero_J__I(preferredScale + int64(yscale) - int64(xscale) + int64(mcp))



		if BigDecimal_CheckScaleNonZero_J__I(int64(mcp)+int64(yscale)-int64(xscale)) > 0 {


			var raise int32 = BigDecimal_CheckScaleNonZero_J__I(int64(mcp) + int64(yscale) - int64(xscale)); var scaledXs int64 = 0; var tmp4 int64


			scaledXs = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, raise); tmp4 = scaledXs; if tmp4 == -9223372036854775808 {

				quotient = nil
				var tmp5 bool; var tmp6 bool; tmp6 = mcp-1 >= 0; if tmp6 {
					tmp6 = mcp-1 < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) }
//line :2376:1
				tmp5 = tmp6; if tmp5 {


					var tmp7 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[mcp-1]; quotient = BigDecimal_MultiplyDivideAndRound_J_J_J_I_I_I__BigDecimal(tmp7, scaledX, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale))
				}






				if quotient == nil {
					var rb *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(scaledX, mcp-1)


					quotient = BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(rb, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } } else {






						quotient = BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(scaledXs, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } } else {






							var newScale int32 = BigDecimal_CheckScaleNonZero_J__I(int64(xscale) - int64(mcp))

							if newScale == yscale {
								quotient = BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(xs, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {






									var raise_2 int32 = BigDecimal_CheckScaleNonZero_J__I(int64(newScale) - int64(yscale)); var scaledYs int64 = 0; var tmp8 int64


									scaledYs = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, raise_2); tmp8 = scaledYs; if tmp8 == -9223372036854775808 {

										var rb_2 *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(ys, raise_2)
										quotient = BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(BigInteger_ValueOf_J__BigInteger(xs), rb_2, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {






											quotient = BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(xs, scaledYs, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } } } } else {






												var scl_2 int32 = BigDecimal_CheckScaleNonZero_J__I(preferredScale + int64(yscale) - int64(xscale) + int64(mcp))



												if cmp == 0 {
													var tmp9 int32

													if scaledX < 0 == (ys < 0) { tmp9 = 1 } else { tmp9 = -1 }
//line :2440:1
													quotient = BigDecimal_RoundedTenPower_I_I_I_I__BigDecimal(tmp9, mcp, scl_2, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {





														var scaledXs_2 int64 = 0; var tmp10 int64
														scaledXs_2 = BigDecimal_LongMultiplyPowerTen_J_I__J(scaledX, mcp); tmp10 = scaledXs_2; if tmp10 == -9223372036854775808 {

															quotient = nil
															if mcp < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
																var tmp11 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[mcp]; quotient = BigDecimal_MultiplyDivideAndRound_J_J_J_I_I_I__BigDecimal(tmp11, scaledX, ys, scl_2, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale))
															}






															if quotient == nil {
																var rb_3 *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(scaledX, mcp)
																quotient = BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(rb_3, ys, scl_2, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } } else {






																	quotient = BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(scaledXs_2, ys, scl_2, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale))
																}
													}
											}



	return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(quotient, mc)
}
func BigDecimal_Divide_J_I_J_I_J_MathContext__BigDecimal(xs int64, xscale int32, ys int64, yscale int32, preferredScale int64, mc *MathContext) *BigDecimal { BigDecimal_Init()


	var mcp int32 = mc.F_precision; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = xscale <= yscale; if tmp3 { tmp3 = yscale < 18 }; tmp2 = tmp3; if tmp2 { tmp2 = mcp < 18 }; tmp1 = tmp2; if tmp1 {
		return BigDecimal_DivideSmallFastPath_J_I_J_I_J_MathContext__BigDecimal(xs, xscale, ys, yscale, preferredScale, mc) } else {

			if BigDecimal_CompareMagnitudeNormalized_J_I_J_I__I(xs, xscale, ys, yscale) > 0 {
				yscale = yscale - 1 }
			var roundingMode int32 = mc.F_roundingMode.F_oldMode; var scl int32 = BigDecimal_CheckScaleNonZero_J__I(preferredScale + int64(yscale) - int64(xscale) + int64(mcp)); var quotient *BigDecimal





			if BigDecimal_CheckScaleNonZero_J__I(int64(mcp)+int64(yscale)-int64(xscale)) > 0 {


				var raise int32 = BigDecimal_CheckScaleNonZero_J__I(int64(mcp) + int64(yscale) - int64(xscale)); var scaledXs int64 = 0; var tmp4 int64


				scaledXs = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, raise); tmp4 = scaledXs; if tmp4 == -9223372036854775808 {
					var rb *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(xs, raise)
					quotient = BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(rb, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {






						quotient = BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(scaledXs, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } } else {






							var newScale int32 = BigDecimal_CheckScaleNonZero_J__I(int64(xscale) - int64(mcp))

							if newScale == yscale {
								quotient = BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(xs, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {






									var raise_2 int32 = BigDecimal_CheckScaleNonZero_J__I(int64(newScale) - int64(yscale)); var scaledYs int64 = 0; var tmp5 int64


									scaledYs = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, raise_2); tmp5 = scaledYs; if tmp5 == -9223372036854775808 {

										var rb_2 *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(ys, raise_2)
										quotient = BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(BigInteger_ValueOf_J__BigInteger(xs), rb_2, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {






											quotient = BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(xs, scaledYs, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale))
										}
								}
						}



			return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(quotient, mc)
		} }
func BigDecimal_Divide_BigInteger_I_J_I_J_MathContext__BigDecimal(xs *BigInteger, xscale int32, ys int64, yscale int32, preferredScale int64, mc *MathContext) *BigDecimal { BigDecimal_Init()


	if -BigDecimal_CompareMagnitudeNormalized_J_I_BigInteger_I__I(ys, yscale, xs, xscale) > 0 {
		yscale = yscale - 1 }
	var mcp int32 = mc.F_precision; var roundingMode int32 = mc.F_roundingMode.F_oldMode; var quotient *BigDecimal; var scl int32 = BigDecimal_CheckScaleNonZero_J__I(preferredScale + int64(yscale) - int64(xscale) + int64(mcp))





	if BigDecimal_CheckScaleNonZero_J__I(int64(mcp)+int64(yscale)-int64(xscale)) > 0 {


		var raise int32 = BigDecimal_CheckScaleNonZero_J__I(int64(mcp) + int64(yscale) - int64(xscale)); var rb *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(xs, raise)


		quotient = BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(rb, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {





			var newScale int32 = BigDecimal_CheckScaleNonZero_J__I(int64(xscale) - int64(mcp))
			if newScale == yscale {
				quotient = BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(xs, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {






					var raise_2 int32 = BigDecimal_CheckScaleNonZero_J__I(int64(newScale) - int64(yscale)); var scaledYs int64 = 0; var tmp1 int64


					scaledYs = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, raise_2); tmp1 = scaledYs; if tmp1 == -9223372036854775808 {
						var rb_2 *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(ys, raise_2)
						quotient = BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(xs, rb_2, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {






							quotient = BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(xs, scaledYs, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale))
						}
				}
		}



	return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(quotient, mc)
}
func BigDecimal_Divide_J_I_BigInteger_I_J_MathContext__BigDecimal(xs int64, xscale int32, ys *BigInteger, yscale int32, preferredScale int64, mc *MathContext) *BigDecimal { BigDecimal_Init()


	if BigDecimal_CompareMagnitudeNormalized_J_I_BigInteger_I__I(xs, xscale, ys, yscale) > 0 {
		yscale = yscale - 1 }
	var mcp int32 = mc.F_precision; var roundingMode int32 = mc.F_roundingMode.F_oldMode; var quotient *BigDecimal; var scl int32 = BigDecimal_CheckScaleNonZero_J__I(preferredScale + int64(yscale) - int64(xscale) + int64(mcp))





	if BigDecimal_CheckScaleNonZero_J__I(int64(mcp)+int64(yscale)-int64(xscale)) > 0 {


		var raise int32 = BigDecimal_CheckScaleNonZero_J__I(int64(mcp) + int64(yscale) - int64(xscale)); var rb *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(xs, raise)


		quotient = BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(rb, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {





			var newScale int32 = BigDecimal_CheckScaleNonZero_J__I(int64(xscale) - int64(mcp)); var raise_2 int32 = BigDecimal_CheckScaleNonZero_J__I(int64(newScale) - int64(yscale)); var rb_2 *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(ys, raise_2)


			quotient = BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(BigInteger_ValueOf_J__BigInteger(xs), rb_2, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale))
		}




	return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(quotient, mc)
}
func BigDecimal_Divide_BigInteger_I_BigInteger_I_J_MathContext__BigDecimal(xs *BigInteger, xscale int32, ys *BigInteger, yscale int32, preferredScale int64, mc *MathContext) *BigDecimal { BigDecimal_Init()


	if BigDecimal_CompareMagnitudeNormalized_BigInteger_I_BigInteger_I__I(xs, xscale, ys, yscale) > 0 {
		yscale = yscale - 1 }
	var mcp int32 = mc.F_precision; var roundingMode int32 = mc.F_roundingMode.F_oldMode; var quotient *BigDecimal; var scl int32 = BigDecimal_CheckScaleNonZero_J__I(preferredScale + int64(yscale) - int64(xscale) + int64(mcp))





	if BigDecimal_CheckScaleNonZero_J__I(int64(mcp)+int64(yscale)-int64(xscale)) > 0 {


		var raise int32 = BigDecimal_CheckScaleNonZero_J__I(int64(mcp) + int64(yscale) - int64(xscale)); var rb *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(xs, raise)


		quotient = BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(rb, ys, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale)) } else {





			var newScale int32 = BigDecimal_CheckScaleNonZero_J__I(int64(xscale) - int64(mcp)); var raise_2 int32 = BigDecimal_CheckScaleNonZero_J__I(int64(newScale) - int64(yscale)); var rb_2 *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(ys, raise_2)


			quotient = BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(xs, rb_2, scl, roundingMode, BigDecimal_CheckScaleNonZero_J__I(preferredScale))
		}




	return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(quotient, mc)
}
func BigDecimal_MultiplyDivideAndRound_J_J_J_I_I_I__BigDecimal(dividend0, dividend1, divisor int64, scale, roundingMode, preferredScale int32) *BigDecimal { BigDecimal_Init()




	var qsign int32 = Long_Signum_J__I(dividend0) * Long_Signum_J__I(dividend1) * Long_Signum_J__I(divisor)


	dividend0 = Math_Abs_J__J(dividend0)
	dividend1 = Math_Abs_J__J(dividend1)
	divisor = Math_Abs_J__J(divisor)
	var d0_hi int64 = int64(uint64(dividend0) >> 32); var d0_lo int64 = dividend0 & 4294967295; var d1_hi int64 = int64(uint64(dividend1) >> 32); var d1_lo int64 = dividend1 & 4294967295; var product int64 = d0_lo * d1_lo; var d0 int64 = product & 4294967295; var d1 int64 = int64(uint64(product) >> 32)






	product = d0_hi*d1_lo + d1
	d1 = product & 4294967295
	var d2 int64 = int64(uint64(product) >> 32)
	product = d0_lo*d1_hi + d1
	d1 = product & 4294967295
	d2 = d2 + int64(uint64(product)>>32)
	var d3 int64 = int64(uint64(d2) >> 32)
	d2 = d2 & 4294967295
	product = d0_hi*d1_hi + d2
	d2 = product & 4294967295
	d3 = (int64(uint64(product)>>32) + d3) & 4294967295


	var dividendHi int64 = BigDecimal_Make64_J_J__J(d3, d2); var dividendLo int64 = BigDecimal_Make64_J_J__J(d1, d0)

	return BigDecimal_DivideAndRound128_J_J_J_I_I_I_I__BigDecimal(dividendHi, dividendLo, divisor, qsign, scale, roundingMode, preferredScale)
}








func BigDecimal_DivideAndRound128_J_J_J_I_I_I_I__BigDecimal(dividendHi, dividendLo, divisor int64, sign, scale, roundingMode, preferredScale int32) *BigDecimal { BigDecimal_Init()




	if dividendHi >= divisor { return nil } else {
		var shift int32 = Long_NumberOfLeadingZeros_J__I(divisor)
		divisor = divisor << (shift & 63)
		var v1 int64 = int64(uint64(divisor) >> 32); var v0 int64 = divisor & 4294967295; var tmp int64 = dividendLo << (shift & 63); var u1 int64 = int64(uint64(tmp) >> 32); var u0 int64 = tmp & 4294967295




		tmp = dividendHi<<(shift&63) | int64(uint64(dividendLo)>>((64-shift)&63))


		var u2 int64 = tmp & 4294967295; var q1 int64 = Long_DivideUnsigned_J_J__J(tmp, v1); var r_tmp int64 = Long_RemainderUnsigned_J_J__J(tmp, v1)


	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = q1 >= 4294967296; if !tmp2 {
		tmp2 = BigDecimal_UnsignedLongCompare_J_J__Z(q1*v0, BigDecimal_Make64_J_J__J(r_tmp, u1)) }
//line :2729:1
		tmp1 = tmp2; if tmp1 {



			q1 = q1 - 1
			r_tmp = r_tmp + v1
			if r_tmp >= 4294967296 { break L1 }
//line :2729:1
			continue L1 }; break L1
	}





		tmp = BigDecimal_Mulsub_J_J_J_J_J__J(u2, u1, v1, v0, q1)
		u1 = tmp & 4294967295
		var q0 int64 = Long_DivideUnsigned_J_J__J(tmp, v1)
		r_tmp = Long_RemainderUnsigned_J_J__J(tmp, v1)
	L2: for { var tmp3 bool; var tmp4 bool; tmp4 = q0 >= 4294967296; if !tmp4 {
		tmp4 = BigDecimal_UnsignedLongCompare_J_J__Z(q0*v0, BigDecimal_Make64_J_J__J(r_tmp, u0)) }
//line :2740:1
		tmp3 = tmp4; if tmp3 {



			q0 = q0 - 1
			r_tmp = r_tmp + v1
			if r_tmp >= 4294967296 { break L2 }
//line :2740:1
			continue L2 }; break L2
	}





		if int32(q1) < 0 {
			var mq MutableBigInteger_I = MutableBigInteger_New_I1(IntArrayOf(int32(q1), int32(q0))); var tmp5 bool; var tmp6 bool
			tmp6 = roundingMode == 1; if tmp6 { tmp6 = scale == preferredScale }; tmp5 = tmp6; if tmp5 {
				return mq.ToBigDecimal_I_I__BigDecimal(sign, scale) } else {
					var r int64 = int64(uint64(BigDecimal_Mulsub_J_J_J_J_J__J(u1, u0, v1, v0, q0)) >> (shift & 63))
					if !(r == 0) {


						if BigDecimal_NeedIncrement_J_I_I_MutableBigInteger_J__Z(int64(uint64(divisor)>>(shift&63)), roundingMode, sign, mq, r) {





							var tmp7 MutableBigInteger_I; MutableBigInteger_Init(); tmp7 = MutableBigInteger_ONE; mq.Add_MutableBigInteger__V(tmp7) }
						return mq.ToBigDecimal_I_I__BigDecimal(sign, scale) } else {
//line :2752:1
							if !(preferredScale == scale) {











								var intVal *BigInteger = mq.ToBigInteger_I__BigInteger(sign)
								return BigDecimal_CreateAndStripZerosToMatchScale_BigInteger_I_J__BigDecimal(intVal, scale, int64(preferredScale)) } else {



									return mq.ToBigDecimal_I_I__BigDecimal(sign, scale) } } } } else {
										var q int64 = BigDecimal_Make64_J_J__J(q1, q0)
										q = q * int64(sign)
										var tmp8 bool; var tmp9 bool; tmp9 = roundingMode == 1; if tmp9 { tmp9 = scale == preferredScale }; tmp8 = tmp9; if tmp8 {
											return BigDecimal_ValueOf_J_I__BigDecimal(q, scale) } else {
												var r_2 int64 = int64(uint64(BigDecimal_Mulsub_J_J_J_J_J__J(u1, u0, v1, v0, q0)) >> (shift & 63))
												if !(r_2 == 0) {

													var increment bool = BigDecimal_NeedIncrement_J_I_I_J_J__Z(int64(uint64(divisor)>>(shift&63)), roundingMode, sign, q, r_2); var tmp10 int64





													if increment { tmp10 = q + int64(sign) } else { tmp10 = q }; return BigDecimal_ValueOf_J_I__BigDecimal(tmp10, scale) } else {
//line :2775:1
														if !(preferredScale == scale) {









															return BigDecimal_CreateAndStripZerosToMatchScale_J_I_J__BigDecimal(q, scale, int64(preferredScale)) } else {
																return BigDecimal_ValueOf_J_I__BigDecimal(q, scale)
															} } } } } }
func BigDecimal_RoundedTenPower_I_I_I_I__BigDecimal(qsign, raise, scale, preferredScale int32) *BigDecimal { BigDecimal_Init()

	if scale > preferredScale {
		var diff int32 = scale - preferredScale
		if diff < raise {
			return BigDecimal_ScaledTenPow_I_I_I__BigDecimal(raise-diff, qsign, preferredScale) } else {
				return BigDecimal_ValueOf_J_I__BigDecimal(int64(qsign), scale-raise) } } else {
					return BigDecimal_ScaledTenPow_I_I_I__BigDecimal(raise, qsign, scale)
				} }
func BigDecimal_ScaledTenPow_I_I_I__BigDecimal(n, sign, scale int32) *BigDecimal { BigDecimal_Init()
	if n < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
		return BigDecimal_ValueOf_J_I__BigDecimal(int64(sign)*BigDecimal_LONG_TEN_POWERS_TABLE.A[n], scale) } else {
			var unscaledVal *BigInteger = BigDecimal_BigTenToThe_I__BigInteger(n)
			if sign == -1 { unscaledVal = NN(unscaledVal).Negate__BigInteger() }
			return BigDecimal_New_BigInteger_J_I_I(unscaledVal, -9223372036854775808, scale, n+1)
		} }
func BigDecimal_Make64_J_J__J(hi, lo int64) int64 { BigDecimal_Init()
	return hi<<32 | lo
}
func BigDecimal_Mulsub_J_J_J_J_J__J(u1, u0, v1, v0, q0 int64) int64 { BigDecimal_Init()

	var tmp int64 = u0 - q0*v0
	return BigDecimal_Make64_J_J__J(u1+int64(uint64(tmp)>>32)-q0*v1, tmp&4294967295)
}



func BigDecimal_UnsignedLongCompare_J_J__Z(one, two int64) bool { BigDecimal_Init()
	return one+-9223372036854775808 > two+-9223372036854775808
}
func BigDecimal_UnsignedLongCompareEq_J_J__Z(one, two int64) bool { BigDecimal_Init()
	return one+-9223372036854775808 >= two+-9223372036854775808
}
func BigDecimal_CompareMagnitudeNormalized_J_I_J_I__I(xs int64, xscale int32, ys int64, yscale int32) int32 { BigDecimal_Init()

	var sdiff int32 = xscale - yscale
	if sdiff == 0 { } else {
		if sdiff < 0 {
			xs = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, -sdiff) } else {
				ys = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, sdiff) } }
	if !(xs == -9223372036854775808) {
		if !(ys == -9223372036854775808) { return BigDecimal_LongCompareMagnitude_J_J__I(xs, ys) } else { return -1 } } else {
//line :2828:1
			return 1
		}
}

func BigDecimal_CompareMagnitudeNormalized_J_I_BigInteger_I__I(xs int64, xscale int32, ys *BigInteger, yscale int32) int32 { BigDecimal_Init()

	if xs == 0 { return -1 } else {

		var sdiff int32 = xscale - yscale
		if sdiff < 0 {
			if BigDecimal_LongMultiplyPowerTen_J_I__J(xs, -sdiff) == -9223372036854775808 {
				return NN(BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(xs, -sdiff)).CompareMagnitude_BigInteger__I(ys) } }
//line :2836:1
		return -1
	}
}





func BigDecimal_CompareMagnitudeNormalized_BigInteger_I_BigInteger_I__I(xs *BigInteger, xscale int32, ys *BigInteger, yscale int32) int32 { BigDecimal_Init()

	var sdiff int32 = xscale - yscale
	if sdiff < 0 {
		return NN(BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(xs, -sdiff)).CompareMagnitude_BigInteger__I(ys) } else {
			return NN(xs).CompareMagnitude_BigInteger__I(BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(ys, sdiff))
		} }
func BigDecimal_Multiply_J_J__J(x, y int64) int64 { BigDecimal_Init()
	var product int64 = x * y; var ax int64 = Math_Abs_J__J(x); var ay int64 = Math_Abs_J__J(y); var tmp1 bool; var tmp2 bool; var tmp3 bool


	tmp3 = int64(uint64(ax|ay)>>31) == 0; if !tmp3 { tmp3 = y == 0 }; tmp2 = tmp3; if !tmp2 {
		tmp2 = product/y == x }
//line :2855:1
	tmp1 = tmp2; if tmp1 { return product } else { return -9223372036854775808
	}
}


func BigDecimal_Multiply_J_J_I__BigDecimal(x, y int64, scale int32) *BigDecimal { BigDecimal_Init()
	var product int64 = BigDecimal_Multiply_J_J__J(x, y)
	if !(product == -9223372036854775808) {
		return BigDecimal_ValueOf_J_I__BigDecimal(product, scale) } else {
			return BigDecimal_New_BigInteger_J_I_I(NN(BigInteger_ValueOf_J__BigInteger(x)).Multiply_J__BigInteger(y), -9223372036854775808, scale, 0)
		} }
func BigDecimal_Multiply_J_BigInteger_I__BigDecimal(x int64, y *BigInteger, scale int32) *BigDecimal { BigDecimal_Init()
	if x == 0 { return BigDecimal_ZeroValueOf_I__BigDecimal(scale) } else { return BigDecimal_New_BigInteger_J_I_I(NN(y).Multiply_J__BigInteger(x), -9223372036854775808, scale, 0)
	} }
func BigDecimal_Multiply_BigInteger_BigInteger_I__BigDecimal(x, y *BigInteger, scale int32) *BigDecimal { BigDecimal_Init()
	return BigDecimal_New_BigInteger_J_I_I(NN(x).Multiply_BigInteger__BigInteger(y), -9223372036854775808, scale, 0)
}
func BigDecimal_MultiplyAndRound_J_J_I_MathContext__BigDecimal(x, y int64, scale int32, mc *MathContext) *BigDecimal { BigDecimal_Init()

	var product int64 = BigDecimal_Multiply_J_J__J(x, y)
	if !(product == -9223372036854775808) {
		return BigDecimal_DoRound_J_I_MathContext__BigDecimal(product, scale, mc) } else {
			var rsign int32 = 1
			if x < 0 { x = -x; rsign = -1 }
			if y < 0 {
				y = -y
				rsign = rsign * -1 }
			var m0_hi int64 = int64(uint64(x) >> 32); var m0_lo int64 = x & 4294967295; var m1_hi int64 = int64(uint64(y) >> 32); var m1_lo int64 = y & 4294967295



			product = m0_lo * m1_lo
			var m0 int64 = product & 4294967295; var m1 int64 = int64(uint64(product) >> 32)

			product = m0_hi*m1_lo + m1
			m1 = product & 4294967295
			var m2 int64 = int64(uint64(product) >> 32)
			product = m0_lo*m1_hi + m1
			m1 = product & 4294967295
			m2 = m2 + int64(uint64(product)>>32)
			var m3 int64 = int64(uint64(m2) >> 32)
			m2 = m2 & 4294967295
			product = m0_hi*m1_hi + m2
			m2 = product & 4294967295
			m3 = (int64(uint64(product)>>32) + m3) & 4294967295


			var mHi int64 = BigDecimal_Make64_J_J__J(m3, m2); var mLo int64 = BigDecimal_Make64_J_J__J(m1, m0); var res *BigDecimal = BigDecimal_DoRound128_J_J_I_I_MathContext__BigDecimal(mHi, mLo, rsign, scale, mc)


			if !(res == nil) { return res } else {


				res = BigDecimal_New_BigInteger_J_I_I(NN(BigInteger_ValueOf_J__BigInteger(x)).Multiply_J__BigInteger(y*int64(rsign)), -9223372036854775808, scale, 0)






				return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(res, mc)
			} } }
func BigDecimal_MultiplyAndRound_J_BigInteger_I_MathContext__BigDecimal(x int64, y *BigInteger, scale int32, mc *MathContext) *BigDecimal { BigDecimal_Init()

	if x == 0 { return BigDecimal_ZeroValueOf_I__BigDecimal(scale) } else { return BigDecimal_DoRound_BigInteger_I_MathContext__BigDecimal(NN(y).Multiply_J__BigInteger(x), scale, mc)
	} }
func BigDecimal_MultiplyAndRound_BigInteger_BigInteger_I_MathContext__BigDecimal(x, y *BigInteger, scale int32, mc *MathContext) *BigDecimal { BigDecimal_Init()

	return BigDecimal_DoRound_BigInteger_I_MathContext__BigDecimal(NN(x).Multiply_BigInteger__BigInteger(y), scale, mc)
}
func BigDecimal_DoRound128_J_J_I_I_MathContext__BigDecimal(hi, lo int64, sign, scale int32, mc *MathContext) *BigDecimal { BigDecimal_Init()

	var mcp int32 = mc.F_precision; var drop int32 = 0; var res *BigDecimal; var tmp1 bool; var tmp2 bool; var tmp3 int32


	drop = BigDecimal_Precision_J_J__I(hi, lo) - mcp; tmp3 = drop; tmp2 = tmp3 > 0; if tmp2 {
		tmp2 = drop < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) }
//line :2930:1
	tmp1 = tmp2; if tmp1 {

		scale = BigDecimal_CheckScaleNonZero_J__I(int64(scale) - int64(drop))
		var tmp4 int64 = BigDecimal_LONG_TEN_POWERS_TABLE.A[drop]; res = BigDecimal_DivideAndRound128_J_J_J_I_I_I_I__BigDecimal(hi, lo, tmp4, sign, scale, mc.F_roundingMode.F_oldMode, scale)
	}






	if !(res == nil) { return BigDecimal_DoRound_BigDecimal_MathContext__BigDecimal(res, mc) } else { return nil
	}
}






















func BigDecimal_Precision_J_J__I(hi, lo int64) int32 { BigDecimal_Init()
	if hi == 0 {
		if lo >= 0 {
			return BigDecimal_LongDigitLength_J__I(lo) } else {
//line :2968:1
				if BigDecimal_UnsignedLongCompareEq_J_J__Z(lo, As[*LongArray](BigDecimal_LONGLONG_TEN_POWERS_TABLE.A[0]).A[1]) { return 20 } else { return 19 } } } else {



					var r int32 = int32(uint32((128-Long_NumberOfLeadingZeros_J__I(hi)+1)*1233) >> 12); var idx int32 = r - 19; var tmp1 bool; var tmp2 bool






					tmp2 = idx >= int32(len(BigDecimal_LONGLONG_TEN_POWERS_TABLE.A)); if !tmp2 {
						var tmp3 int64 = As[*LongArray](BigDecimal_LONGLONG_TEN_POWERS_TABLE.A[idx]).A[0]; tmp2 = BigDecimal_LongLongCompareMagnitude_J_J_J_J__Z(hi, lo, tmp3, As[*LongArray](BigDecimal_LONGLONG_TEN_POWERS_TABLE.A[idx]).A[1]) }
//line :2979:1
					tmp1 = tmp2; if tmp1 { return r } else {






						return r + 1
					} } }
func BigDecimal_LongLongCompareMagnitude_J_J_J_J__Z(hi0, lo0, hi1, lo1 int64) bool { BigDecimal_Init()

	if !(hi0 == hi1) {
		return hi0 < hi1 } else {
			return lo0+-9223372036854775808 < lo1+-9223372036854775808
		} }
func BigDecimal_Divide_J_I_J_I_I_I__BigDecimal(dividend int64, dividendScale int32, divisor int64, divisorScale, scale, roundingMode int32) *BigDecimal { BigDecimal_Init()

	if BigDecimal_CheckScale_J_J__I(dividend, int64(scale)+int64(divisorScale)) > dividendScale {
		var newScale int32 = scale + divisorScale; var raise int32 = newScale - dividendScale

		if raise < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
			var xs int64 = dividend; var tmp1 int64
			xs = BigDecimal_LongMultiplyPowerTen_J_I__J(xs, raise); tmp1 = xs; if tmp1 == -9223372036854775808 { } else {
				return BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(xs, divisor, scale, roundingMode, scale) }
			var q *BigDecimal = BigDecimal_MultiplyDivideAndRound_J_J_J_I_I_I__BigDecimal(BigDecimal_LONG_TEN_POWERS_TABLE.A[raise], dividend, divisor, scale, roundingMode, scale)






			if !(q == nil) { return q } }
		var scaledDividend *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(dividend, raise)
		return BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(scaledDividend, divisor, scale, roundingMode, scale) } else {
			var newScale_2 int32 = BigDecimal_CheckScale_J_J__I(divisor, int64(dividendScale)-int64(scale)); var raise_2 int32 = newScale_2 - divisorScale


			if raise_2 < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
				var ys int64 = divisor; var tmp2 int64
				ys = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, raise_2); tmp2 = ys; if tmp2 == -9223372036854775808 { } else {
					return BigDecimal_DivideAndRound_J_J_I_I_I__BigDecimal(dividend, ys, scale, roundingMode, scale) } }
			var scaledDivisor *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(divisor, raise_2)
			return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(BigInteger_ValueOf_J__BigInteger(dividend), scaledDivisor, scale, roundingMode, scale)
		}
}



func BigDecimal_Divide_BigInteger_I_J_I_I_I__BigDecimal(dividend *BigInteger, dividendScale int32, divisor int64, divisorScale, scale, roundingMode int32) *BigDecimal { BigDecimal_Init()


	if BigDecimal_CheckScale_BigInteger_J__I(dividend, int64(scale)+int64(divisorScale)) > dividendScale {
		var newScale int32 = scale + divisorScale; var raise int32 = newScale - dividendScale; var scaledDividend *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(dividend, raise)


		return BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(scaledDividend, divisor, scale, roundingMode, scale) } else {
			var newScale_2 int32 = BigDecimal_CheckScale_J_J__I(divisor, int64(dividendScale)-int64(scale)); var raise_2 int32 = newScale_2 - divisorScale


			if raise_2 < int32(len(BigDecimal_LONG_TEN_POWERS_TABLE.A)) {
				var ys int64 = divisor; var tmp1 int64
				ys = BigDecimal_LongMultiplyPowerTen_J_I__J(ys, raise_2); tmp1 = ys; if tmp1 == -9223372036854775808 { } else {
					return BigDecimal_DivideAndRound_BigInteger_J_I_I_I__BigDecimal(dividend, ys, scale, roundingMode, scale) } }
			var scaledDivisor *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(divisor, raise_2)
			return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(dividend, scaledDivisor, scale, roundingMode, scale)
		} }
func BigDecimal_Divide_J_I_BigInteger_I_I_I__BigDecimal(dividend int64, dividendScale int32, divisor *BigInteger, divisorScale, scale, roundingMode int32) *BigDecimal { BigDecimal_Init()


	if BigDecimal_CheckScale_J_J__I(dividend, int64(scale)+int64(divisorScale)) > dividendScale {
		var newScale int32 = scale + divisorScale; var raise int32 = newScale - dividendScale; var scaledDividend *BigInteger = BigDecimal_BigMultiplyPowerTen_J_I__BigInteger(dividend, raise)


		return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(scaledDividend, divisor, scale, roundingMode, scale) } else {
			var newScale_2 int32 = BigDecimal_CheckScale_BigInteger_J__I(divisor, int64(dividendScale)-int64(scale)); var raise_2 int32 = newScale_2 - divisorScale; var scaledDivisor *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(divisor, raise_2)



			return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(BigInteger_ValueOf_J__BigInteger(dividend), scaledDivisor, scale, roundingMode, scale)
		}
}



func BigDecimal_Divide_BigInteger_I_BigInteger_I_I_I__BigDecimal(dividend *BigInteger, dividendScale int32, divisor *BigInteger, divisorScale, scale, roundingMode int32) *BigDecimal { BigDecimal_Init()


	if BigDecimal_CheckScale_BigInteger_J__I(dividend, int64(scale)+int64(divisorScale)) > dividendScale {
		var newScale int32 = scale + divisorScale; var raise int32 = newScale - dividendScale; var scaledDividend *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(dividend, raise)


		return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(scaledDividend, divisor, scale, roundingMode, scale) } else {
			var newScale_2 int32 = BigDecimal_CheckScale_BigInteger_J__I(divisor, int64(dividendScale)-int64(scale)); var raise_2 int32 = newScale_2 - divisorScale; var scaledDivisor *BigInteger = BigDecimal_BigMultiplyPowerTen_BigInteger_I__BigInteger(divisor, raise_2)



			return BigDecimal_DivideAndRound_BigInteger_BigInteger_I_I_I__BigDecimal(dividend, scaledDivisor, scale, roundingMode, scale)
		}
}

type BigDecimal struct{ Number; F_intVal *BigInteger; F_scale, F_precision int32; F_stringCache *String; F_intCompact int64 }

func (t *BigDecimal) Is_Comparable() {}

var BigDecimal_JLA JavaLangAccess

const BigDecimal_L float64 = 3.321928094887362

const BigDecimal_P_F int32 = 24

const BigDecimal_Q_MIN_F int32 = -149

const BigDecimal_Q_MAX_F int32 = 104

const BigDecimal_P_D int32 = 53

const BigDecimal_Q_MIN_D int32 = -1074

const BigDecimal_Q_MAX_D int32 = 971

const BigDecimal_INFLATED int64 = -9223372036854775808

var BigDecimal_INFLATED_BIGINT *BigInteger

const BigDecimal_MAX_COMPACT_DIGITS int32 = 18

const BigDecimal_serialVersionUID int64 = 6108874887143696463

var BigDecimal_ZERO_THROUGH_TEN *RefArray

var BigDecimal_ZERO_SCALED_BY *RefArray

const BigDecimal_HALF_LONG_MAX_VALUE int64 = 4611686018427387903

const BigDecimal_HALF_LONG_MIN_VALUE int64 = -4611686018427387904

var BigDecimal_ZERO *BigDecimal

var BigDecimal_ONE *BigDecimal

var BigDecimal_TWO *BigDecimal

var BigDecimal_TEN *BigDecimal

const BigDecimal_ROUND_UP int32 = 0

const BigDecimal_ROUND_DOWN int32 = 1

const BigDecimal_ROUND_CEILING int32 = 2

const BigDecimal_ROUND_FLOOR int32 = 3

const BigDecimal_ROUND_HALF_UP int32 = 4

const BigDecimal_ROUND_HALF_DOWN int32 = 5

const BigDecimal_ROUND_HALF_EVEN int32 = 6

const BigDecimal_ROUND_UNNECESSARY int32 = 7

var BigDecimal_DOUBLE_10_POW *DoubleArray

var BigDecimal_FLOAT_10_POW *FloatArray

var BigDecimal_LONG_TEN_POWERS_TABLE *LongArray

var BigDecimal_BIG_TEN_POWERS_TABLE atomic.Pointer[RefArray]

var BigDecimal_BIG_TEN_POWERS_TABLE_INITLEN int32

var BigDecimal_BIG_TEN_POWERS_TABLE_MAX int32

var BigDecimal_THRESHOLDS_TABLE *LongArray

var BigDecimal_FIVE_TO_2_TO *RefArray

const BigDecimal_LOG_5_OF_2 float64 = 0.43067655807339306

const BigDecimal_DIV_NUM_BASE int64 = 4294967296

var BigDecimal_LONGLONG_TEN_POWERS_TABLE *RefArray

var BigDecimal_init ClassInit

func BigDecimal_Init() { if !BigDecimal_init.Done() { BigDecimal_init.Run(BigDecimal_clinit) } }

func BigDecimal_clinit() { BigDecimal_JLA = SharedSecrets_GetJavaLangAccess__JavaLangAccess(); BigDecimal_INFLATED_BIGINT = BigInteger_ValueOf_J__BigInteger(-9223372036854775808); var tmp1 *BigInteger; BigInteger_Init(); tmp1 = BigInteger_ZERO; var tmp2 any = BigDecimal_New_BigInteger_J_I_I(tmp1, 0, 0, 1); var tmp3 *BigInteger; BigInteger_Init(); tmp3 = BigInteger_ONE; var tmp4 any = BigDecimal_New_BigInteger_J_I_I(tmp3, 1, 0, 1); var tmp5 *BigInteger; BigInteger_Init(); tmp5 = BigInteger_TWO; var tmp6 any = BigDecimal_New_BigInteger_J_I_I(tmp5, 2, 0, 1); var tmp7 any = BigDecimal_New_BigInteger_J_I_I(BigInteger_ValueOf_J__BigInteger(3), 3, 0, 1); var tmp8 any = BigDecimal_New_BigInteger_J_I_I(BigInteger_ValueOf_J__BigInteger(4), 4, 0, 1); var tmp9 any = BigDecimal_New_BigInteger_J_I_I(BigInteger_ValueOf_J__BigInteger(5), 5, 0, 1); var tmp10 any = BigDecimal_New_BigInteger_J_I_I(BigInteger_ValueOf_J__BigInteger(6), 6, 0, 1); var tmp11 any = BigDecimal_New_BigInteger_J_I_I(BigInteger_ValueOf_J__BigInteger(7), 7, 0, 1); var tmp12 any = BigDecimal_New_BigInteger_J_I_I(BigInteger_ValueOf_J__BigInteger(8), 8, 0, 1); var tmp13 any = BigDecimal_New_BigInteger_J_I_I(BigInteger_ValueOf_J__BigInteger(9), 9, 0, 1); var tmp14 *BigInteger; BigInteger_Init(); tmp14 = BigInteger_TEN; BigDecimal_ZERO_THROUGH_TEN = RefArrayOf(BigDecimal_class, tmp2, tmp4, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, BigDecimal_New_BigInteger_J_I_I(tmp14, 10, 0, 2)); var tmp15 any = As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[0]).Ref(); var tmp16 *BigInteger; BigInteger_Init(); tmp16 = BigInteger_ZERO; var tmp17 any = BigDecimal_New_BigInteger_J_I_I(tmp16, 0, 1, 1); var tmp18 *BigInteger; BigInteger_Init(); tmp18 = BigInteger_ZERO; var tmp19 any = BigDecimal_New_BigInteger_J_I_I(tmp18, 0, 2, 1); var tmp20 *BigInteger; BigInteger_Init(); tmp20 = BigInteger_ZERO; var tmp21 any = BigDecimal_New_BigInteger_J_I_I(tmp20, 0, 3, 1); var tmp22 *BigInteger; BigInteger_Init(); tmp22 = BigInteger_ZERO; var tmp23 any = BigDecimal_New_BigInteger_J_I_I(tmp22, 0, 4, 1); var tmp24 *BigInteger; BigInteger_Init(); tmp24 = BigInteger_ZERO; var tmp25 any = BigDecimal_New_BigInteger_J_I_I(tmp24, 0, 5, 1); var tmp26 *BigInteger; BigInteger_Init(); tmp26 = BigInteger_ZERO; var tmp27 any = BigDecimal_New_BigInteger_J_I_I(tmp26, 0, 6, 1); var tmp28 *BigInteger; BigInteger_Init(); tmp28 = BigInteger_ZERO; var tmp29 any = BigDecimal_New_BigInteger_J_I_I(tmp28, 0, 7, 1); var tmp30 *BigInteger; BigInteger_Init(); tmp30 = BigInteger_ZERO; var tmp31 any = BigDecimal_New_BigInteger_J_I_I(tmp30, 0, 8, 1); var tmp32 *BigInteger; BigInteger_Init(); tmp32 = BigInteger_ZERO; var tmp33 any = BigDecimal_New_BigInteger_J_I_I(tmp32, 0, 9, 1); var tmp34 *BigInteger; BigInteger_Init(); tmp34 = BigInteger_ZERO; var tmp35 any = BigDecimal_New_BigInteger_J_I_I(tmp34, 0, 10, 1); var tmp36 *BigInteger; BigInteger_Init(); tmp36 = BigInteger_ZERO; var tmp37 any = BigDecimal_New_BigInteger_J_I_I(tmp36, 0, 11, 1); var tmp38 *BigInteger; BigInteger_Init(); tmp38 = BigInteger_ZERO; var tmp39 any = BigDecimal_New_BigInteger_J_I_I(tmp38, 0, 12, 1); var tmp40 *BigInteger; BigInteger_Init(); tmp40 = BigInteger_ZERO; var tmp41 any = BigDecimal_New_BigInteger_J_I_I(tmp40, 0, 13, 1); var tmp42 *BigInteger; BigInteger_Init(); tmp42 = BigInteger_ZERO; var tmp43 any = BigDecimal_New_BigInteger_J_I_I(tmp42, 0, 14, 1); var tmp44 *BigInteger; BigInteger_Init(); tmp44 = BigInteger_ZERO; BigDecimal_ZERO_SCALED_BY = RefArrayOf(BigDecimal_class, tmp15, tmp17, tmp19, tmp21, tmp23, tmp25, tmp27, tmp29, tmp31, tmp33, tmp35, tmp37, tmp39, tmp41, tmp43, BigDecimal_New_BigInteger_J_I_I(tmp44, 0, 15, 1)); BigDecimal_ZERO = As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[0]); BigDecimal_ONE = As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[1]); BigDecimal_TWO = As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[2]); BigDecimal_TEN = As[*BigDecimal](BigDecimal_ZERO_THROUGH_TEN.A[10]); BigDecimal_DOUBLE_10_POW = DoubleArrayOf(1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 1.0e7, 1.0e8, 1.0e9, 1.0e10, 1.0e11, 1.0e12, 1.0e13, 1.0e14, 1.0e15, 1.0e16, 1.0e17, 1.0e18, 1.0e19, 1.0e20, 1.0e21, 1.0e22); BigDecimal_FLOAT_10_POW = FloatArrayOf(1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 1.0e7, 1.0e8, 1.0e9, 1.0e10); BigDecimal_LONG_TEN_POWERS_TABLE = LongArrayOf(1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000, 100000000000, 1000000000000, 10000000000000, 100000000000000, 1000000000000000, 10000000000000000, 100000000000000000, 1000000000000000000); var tmp45 *BigInteger; BigInteger_Init(); tmp45 = BigInteger_ONE; var tmp46 any = tmp45.Ref(); BigDecimal_BIG_TEN_POWERS_TABLE.Store(RefArrayOf(BigInteger_class, tmp46, BigInteger_ValueOf_J__BigInteger(10).Ref(), BigInteger_ValueOf_J__BigInteger(100).Ref(), BigInteger_ValueOf_J__BigInteger(1000).Ref(), BigInteger_ValueOf_J__BigInteger(10000).Ref(), BigInteger_ValueOf_J__BigInteger(100000).Ref(), BigInteger_ValueOf_J__BigInteger(1000000).Ref(), BigInteger_ValueOf_J__BigInteger(10000000).Ref(), BigInteger_ValueOf_J__BigInteger(100000000).Ref(), BigInteger_ValueOf_J__BigInteger(1000000000).Ref(), BigInteger_ValueOf_J__BigInteger(10000000000).Ref(), BigInteger_ValueOf_J__BigInteger(100000000000).Ref(), BigInteger_ValueOf_J__BigInteger(1000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(10000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(100000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(1000000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(10000000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(100000000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(1000000000000000000).Ref())); BigDecimal_BIG_TEN_POWERS_TABLE_INITLEN = int32(len(BigDecimal_BIG_TEN_POWERS_TABLE.Load().A)); BigDecimal_BIG_TEN_POWERS_TABLE_MAX = 16 * BigDecimal_BIG_TEN_POWERS_TABLE_INITLEN; BigDecimal_THRESHOLDS_TABLE = LongArrayOf(9223372036854775807, 922337203685477580, 92233720368547758, 9223372036854775, 922337203685477, 92233720368547, 9223372036854, 922337203685, 92233720368, 9223372036, 922337203, 92233720, 9223372, 922337, 92233, 9223, 922, 92, 9); BigDecimal_FIVE_TO_2_TO = NewRefArray(BigInteger_class, 17); var pow /*line :2188:1*/*BigInteger; var tmp47 *RefArray = BigDecimal_FIVE_TO_2_TO; var tmp48 *BigInteger = BigInteger_ValueOf_J__BigInteger(5); tmp47.Store(0, tmp48.Ref()); pow = tmp48; var i int32 = 1; L1:
for {
	if i < int32(len(BigDecimal_FIVE_TO_2_TO.A)) {
		var tmp49 *RefArray = BigDecimal_FIVE_TO_2_TO; var tmp50 *BigInteger; pow = NN(pow).Multiply_BigInteger__BigInteger(pow); tmp50 = pow; tmp49.Store(i, tmp50.Ref())
		i = i + 1; continue L1 }
//line :2189:1
	break L1
}; BigDecimal_LONGLONG_TEN_POWERS_TABLE = /*line :2189:1*/RefArrayOf(Prim_long.ArrayClass(), LongArrayOf(0, -8446744073709551616), LongArrayOf(5, 7766279631452241920), LongArrayOf(54, 3875820019684212736), LongArrayOf(542, 1864712049423024128), LongArrayOf(5421, 200376420520689664), LongArrayOf(54210, 2003764205206896640), LongArrayOf(542101, 1590897978359414784), LongArrayOf(5421010, -2537764290115403776), LongArrayOf(54210108, -6930898827444486144), LongArrayOf(542101086, 4477988020393345024), LongArrayOf(5421010862, 7886392056514347008), LongArrayOf(54210108624, 5076944270305263616), LongArrayOf(542101086242, -4570789518076018688), LongArrayOf(5421010862427, -8814407033341083648), LongArrayOf(54210108624275, 4089650035136921600), LongArrayOf(542101086242752, 4003012203950112768), LongArrayOf(5421010862427522, 3136633892082024448), LongArrayOf(54210108624275221, -5527149226598858752), LongArrayOf(542101086242752217, 68739955140067328), LongArrayOf(5421010862427522170, 687399551400673280)) }

















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func (t *BigDecimal) CompareTo_O__I(p0 any) int32 { return t.CompareTo_BigDecimal__I(BigDecimal_Cast(p0)) }

func (t *BigDecimal) ByteValue__B() int8 { return t.Impl_ByteValue__B(t) }

func (t *BigDecimal) ShortValue__S() int16 { return t.Impl_ShortValue__S(t) }

func (t *BigDecimal) Ref() any { if t == nil { return nil }; return t }

func (t *BigDecimal) GetClass__Class() *Class { return BigDecimal_class }

func (t *BigDecimal) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BigDecimal) CloneShallow() any { panic(CloneNotSupported(t)) }

func BigDecimal_InstanceOf(x any) bool { _, ok := x.(*BigDecimal); return ok }

func BigDecimal_Cast(x any) *BigDecimal { if x == nil { return nil }; v, ok := x.(*BigDecimal); if !ok { panic(ClassCast(x, BigDecimal_class)) }; return v }



type BigDecimal_LongOverflow struct{ Object }

var BigDecimal_LongOverflow_LONGMIN *BigInteger

var BigDecimal_LongOverflow_LONGMAX *BigInteger

var BigDecimal_LongOverflow_init ClassInit

func BigDecimal_LongOverflow_Init() { if !BigDecimal_LongOverflow_init.Done() { BigDecimal_LongOverflow_init.Run(BigDecimal_LongOverflow_clinit) } }

func BigDecimal_LongOverflow_clinit() { BigDecimal_LongOverflow_LONGMIN = BigInteger_ValueOf_J__BigInteger(-9223372036854775808); BigDecimal_LongOverflow_LONGMAX = BigInteger_ValueOf_J__BigInteger(9223372036854775807) }

func BigDecimal_LongOverflow_New() *BigDecimal_LongOverflow { BigDecimal_LongOverflow_Init(); t := &BigDecimal_LongOverflow{}; t.Ctor(); return t }

func (t *BigDecimal_LongOverflow) Ctor() {}

func (t *BigDecimal_LongOverflow) Ref() any { if t == nil { return nil }; return t }

func (t *BigDecimal_LongOverflow) GetClass__Class() *Class { return BigDecimal_LongOverflow_class }

func (t *BigDecimal_LongOverflow) ToString__String() *String { return Object_toString(t) }

func (t *BigDecimal_LongOverflow) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BigDecimal_LongOverflow) CloneShallow() any { panic(CloneNotSupported(t)) }

func BigDecimal_LongOverflow_InstanceOf(x any) bool { _, ok := x.(*BigDecimal_LongOverflow); return ok }

func BigDecimal_LongOverflow_Cast(x any) *BigDecimal_LongOverflow { if x == nil { return nil }; v, ok := x.(*BigDecimal_LongOverflow); if !ok { panic(ClassCast(x, BigDecimal_LongOverflow_class)) }; return v }



type BigDecimal_UnsafeHolder struct{ Object }

var BigDecimal_UnsafeHolder_unsafe *Unsafe

var BigDecimal_UnsafeHolder_intCompactOffset int64

var BigDecimal_UnsafeHolder_intValOffset int64

var BigDecimal_UnsafeHolder_scaleOffset int64

var BigDecimal_UnsafeHolder_init ClassInit

func BigDecimal_UnsafeHolder_Init() { if !BigDecimal_UnsafeHolder_init.Done() { BigDecimal_UnsafeHolder_init.Run(BigDecimal_UnsafeHolder_clinit) } }

func BigDecimal_UnsafeHolder_clinit() { BigDecimal_UnsafeHolder_unsafe = Unsafe_GetUnsafe__Unsafe(); BigDecimal_UnsafeHolder_intCompactOffset = NN(BigDecimal_UnsafeHolder_unsafe).ObjectFieldOffset_Class_String__J(BigDecimal_class, Lit_1244); BigDecimal_UnsafeHolder_intValOffset = NN(BigDecimal_UnsafeHolder_unsafe).ObjectFieldOffset_Class_String__J(BigDecimal_class, Lit_1245); BigDecimal_UnsafeHolder_scaleOffset = NN(BigDecimal_UnsafeHolder_unsafe).ObjectFieldOffset_Class_String__J(BigDecimal_class, Lit_1246) }

func BigDecimal_UnsafeHolder_New() *BigDecimal_UnsafeHolder { BigDecimal_UnsafeHolder_Init(); t := &BigDecimal_UnsafeHolder{}; t.Ctor(); return t }

func (t *BigDecimal_UnsafeHolder) Ctor() {}

func (t *BigDecimal_UnsafeHolder) Ref() any { if t == nil { return nil }; return t }

func (t *BigDecimal_UnsafeHolder) GetClass__Class() *Class { return BigDecimal_UnsafeHolder_class }

func (t *BigDecimal_UnsafeHolder) ToString__String() *String { return Object_toString(t) }

func (t *BigDecimal_UnsafeHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BigDecimal_UnsafeHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func BigDecimal_UnsafeHolder_InstanceOf(x any) bool { _, ok := x.(*BigDecimal_UnsafeHolder); return ok }

func BigDecimal_UnsafeHolder_Cast(x any) *BigDecimal_UnsafeHolder { if x == nil { return nil }; v, ok := x.(*BigDecimal_UnsafeHolder); if !ok { panic(ClassCast(x, BigDecimal_UnsafeHolder_class)) }; return v }
