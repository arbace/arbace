//line java_util_StringJoiner.ae:1
package jrt






















func StringJoiner_New_CharSequence(p0 CharSequence) *StringJoiner { StringJoiner_Init(); t := &StringJoiner{}; t.Ctor_CharSequence(p0); return t }
//line :24:1
func (t *StringJoiner) Ctor_CharSequence(delimiter CharSequence) { t.Ctor_CharSequence_CharSequence_CharSequence(delimiter, Lit_69, Lit_69) }


func StringJoiner_New_CharSequence_CharSequence_CharSequence(p0, p1, p2 CharSequence) *StringJoiner { StringJoiner_Init(); t := &StringJoiner{}; t.Ctor_CharSequence_CharSequence_CharSequence(p0, p1, p2); return t }
//line :27:1
func (t *StringJoiner) Ctor_CharSequence_CharSequence_CharSequence(delimiter, prefix, suffix CharSequence) {
	Objects_RequireNonNull_O_String__O(prefix, Lit_2872)
	Objects_RequireNonNull_O_String__O(delimiter, Lit_2873)
	Objects_RequireNonNull_O_String__O(suffix, Lit_2874)
	t.F_prefix = prefix.ToString__String()
	t.F_delimiter = delimiter.ToString__String()
	t.F_suffix = suffix.ToString__String()
	t.CheckAddLength_I_I__I(0, 0)
}
func (t *StringJoiner) SetEmptyValue_CharSequence__StringJoiner(emptyValue CharSequence) *StringJoiner {
	t.F_emptyValue = CharSequence_Cast(Objects_RequireNonNull_O_String__O(emptyValue, Lit_2875)).ToString__String()
//line :36:1
	return t
}




func (t *StringJoiner) ToString__String() *String {
	var size int32 = t.F_size; var elts *RefArray = t.F_elts

	if size == 0 {
		if !(t.F_emptyValue == nil) { return t.F_emptyValue }
		elts = StringJoiner_EMPTY_STRING_ARRAY }
	return StringJoiner_JLA.Join_String_String_String_String1_I__String(t.F_prefix, t.F_suffix, t.F_delimiter, elts, size)
}
func (t *StringJoiner) Add_CharSequence__StringJoiner(newElement CharSequence) *StringJoiner {
	var elt *String = String_ValueOf_O__String(newElement)
	if t.F_elts == nil {
		t.F_elts = NewRefArray(String_class, 8) } else {

			var tmp1 int32 = t.F_size; if tmp1 == int32(len(t.F_elts.A)) {
				t.F_elts = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(t.F_elts, 2*t.F_size).Ref(), String_class.ArrayClass()) }
			var tmp2 int32 = t.F_len; t.F_len = t.CheckAddLength_I_I__I(tmp2, NN(t.F_delimiter).Length__I()) }
	var tmp3 int32 = t.F_len; t.F_len = t.CheckAddLength_I_I__I(tmp3, NN(elt).Length__I())
	var tmp4 *RefArray = t.F_elts; var tmp5 int32; var old_1 int32 = t.F_size; t.F_size = t.F_size + 1; tmp5 = old_1; tmp4.Store(tmp5, elt.Ref())
//line :51:1
	return t
}









func (t *StringJoiner) CheckAddLength_I_I__I(oldLen, inc int32) int32 {
	var newLen int64 = int64(oldLen) + int64(inc); var tmpLen int64 = newLen + int64(NN(t.F_prefix).Length__I()) + int64(NN(t.F_suffix).Length__I())


	if tmpLen == int64(int32(tmpLen)) { } else {
		panic(Thrown(OutOfMemoryError_New_String(Lit_2876))) }
	return int32(newLen)
}
func (t *StringJoiner) Merge_StringJoiner__StringJoiner(other *StringJoiner) *StringJoiner {
	Objects_RequireNonNull_O__O(other.Ref())
	if other.F_size == 0 { return t } else { NN(other).CompactElts__V(); return t.Add_CharSequence__StringJoiner(Up_String_CharSequence(As[*String](other.F_elts.A[0])))
	} }
func (t *StringJoiner) CompactElts__V() {
	var sz int32 = t.F_size
	if sz > 1 {
		var tmp1 *RefArray = t.F_elts; tmp1.Store(0, StringJoiner_JLA.Join_String_String_String_String1_I__String(Lit_69, Lit_69, t.F_delimiter, t.F_elts, sz).Ref())
		Arrays_Fill_O1_I_I_O__V(t.F_elts, 1, sz, nil)
		t.F_size = 1
	} }
func (t *StringJoiner) Length__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_size == 0; if tmp2 { tmp2 = !(t.F_emptyValue == nil) }; tmp1 = tmp2; if tmp1 {
		return NN(t.F_emptyValue).Length__I() } else {
			var tmp3 int32 = t.F_len; var tmp4 int32 = tmp3 + NN(t.F_prefix).Length__I(); return tmp4 + NN(t.F_suffix).Length__I()
		}
}

type StringJoiner struct{ Object; F_prefix, F_delimiter, F_suffix *String; F_elts *RefArray; F_size, F_len int32; F_emptyValue *String }

var StringJoiner_EMPTY_STRING_ARRAY *RefArray

var StringJoiner_JLA JavaLangAccess

var StringJoiner_init ClassInit

func StringJoiner_Init() { if !StringJoiner_init.Done() { StringJoiner_init.Run(StringJoiner_clinit) } }

func StringJoiner_clinit() { StringJoiner_EMPTY_STRING_ARRAY = NewRefArray(String_class, 0); StringJoiner_JLA = SharedSecrets_GetJavaLangAccess__JavaLangAccess() }

func (t *StringJoiner) Ref() any { if t == nil { return nil }; return t }

func (t *StringJoiner) GetClass__Class() *Class { return StringJoiner_class }

func (t *StringJoiner) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringJoiner) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringJoiner_InstanceOf(x any) bool { _, ok := x.(*StringJoiner); return ok }

func StringJoiner_Cast(x any) *StringJoiner { if x == nil { return nil }; v, ok := x.(*StringJoiner); if !ok { panic(ClassCast(x, StringJoiner_class)) }; return v }
