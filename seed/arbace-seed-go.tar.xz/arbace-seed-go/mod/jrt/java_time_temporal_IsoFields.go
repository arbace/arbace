//line java_time_temporal_IsoFields.ae:1
package jrt























func IsoFields_New() *IsoFields { IsoFields_Init(); t := &IsoFields{}; t.Ctor(); return t }
//line :25:1
func (t *IsoFields) Ctor() { panic(A2g_NotTranslated("java.time.temporal.IsoFields.<init>()V")) }








func (t *IsoFields_Field_1) GetBaseUnit__TemporalUnit() TemporalUnit { ChronoUnit_Init(); return Up_ChronoUnit_TemporalUnit(ChronoUnit_DAYS) }
func (t *IsoFields_Field_1) GetRangeUnit__TemporalUnit() TemporalUnit { IsoFields_Init(); return IsoFields_QUARTER_YEARS }
func (t *IsoFields_Field_1) Range__ValueRange() *ValueRange { return ValueRange_Of_J_J_J__ValueRange(1, 90, 92) }
func (t *IsoFields_Field_1) IsSupportedBy_TemporalAccessor__Z(temporal TemporalAccessor) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_DAY_OF_YEAR; tmp3 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp4)); if tmp3 {
		var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MONTH_OF_YEAR; tmp3 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp5)) }
//line :38:1
	tmp2 = tmp3; if tmp2 {

		var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_YEAR; tmp2 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp6)) }
//line :38:1
	tmp1 = tmp2; if tmp1 {


		tmp1 = IsoFields_IsIso_TemporalAccessor__Z(temporal) }
//line :38:1
	return tmp1
}


func (t *IsoFields_Field_1) RangeRefinedBy_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	if t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2495))) }
	var qoy int64 = temporal.GetLong_TemporalField__J(IsoFields_Field_QUARTER_OF_YEAR)
	if qoy == 1 {

		var year int64; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; year = temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp1))
		var tmp2 *IsoChronology; IsoChronology_Init(); tmp2 = IsoChronology_INSTANCE; if NN(tmp2).IsLeapYear_J__Z(year) {
			return ValueRange_Of_J_J__ValueRange(1, 91) } else {
				return ValueRange_Of_J_J__ValueRange(1, 90) } } else {
//line :46:1
					if qoy == 2 {





						return ValueRange_Of_J_J__ValueRange(1, 91) } else {
//line :46:1
							var tmp3 bool; var tmp4 bool






							tmp4 = qoy == 3; if !tmp4 { tmp4 = qoy == 4 }; tmp3 = tmp4
//line :46:1
							if tmp3 {






								return ValueRange_Of_J_J__ValueRange(1, 92) } else {
									return t.Range__ValueRange() } } } }
func (t *IsoFields_Field_1) GetFrom_TemporalAccessor__J(temporal TemporalAccessor) int64 { var tmp1 int32; if
												t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
													panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2495))) }; var doy int32; var tmp2 /*line :58:1*/*ChronoField; ChronoField_Init(); tmp2 = ChronoField_DAY_OF_YEAR; doy = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)); var moy int32; var tmp3 *ChronoField;
												ChronoField_Init(); tmp3 = ChronoField_MONTH_OF_YEAR; moy = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp3)); var year int64; var tmp4 /*line :58:1*/*ChronoField;

	ChronoField_Init(); tmp4 = ChronoField_YEAR; year = temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)); var tmp5 /*line :61:1*/*IntArray = IsoFields_Field_QUARTER_DAYS; var tmp6 int32 = (moy - 1) / 3; var tmp7 int32; var tmp8 *IsoChronology;



	IsoChronology_Init(); tmp8 = IsoChronology_INSTANCE; if NN(tmp8).IsLeapYear_J__Z(year) { tmp7 = 4 } else { tmp7 = 0 }; tmp1 = /*line :61:1*/doy - tmp5.A[tmp6+tmp7]; return /*line :55:1*/ int64(tmp1) }










func (t *IsoFields_Field_1) AdjustInto_Temporal_J__Temporal(temporal Temporal, newValue int64) Temporal {

	var curValue int64 = t.GetFrom_TemporalAccessor__J(temporal)
	NN(t.Range__ValueRange()).CheckValidValue_J_TemporalField__J(newValue, t)
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_YEAR; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_YEAR; return temporal.With_TemporalField_J__Temporal(tmp2, temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3))+(newValue-curValue))
}


func (t *IsoFields_Field_1) Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(fieldValues Map, partialTemporal TemporalAccessor, resolverStyle *ResolverStyle) ChronoLocalDate {


	var yearLong *Long; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; yearLong = Long_Cast(fieldValues.Get_O__O(tmp1.Ref())); var qoyLong *Long = Long_Cast(fieldValues.Get_O__O(IsoFields_Field_QUARTER_OF_YEAR)); var tmp2 bool; var tmp3 bool

	tmp3 = yearLong == nil; if !tmp3 { tmp3 = qoyLong == nil }; tmp2 = tmp3; if tmp2 { return nil } else {
		var y int32; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_YEAR; var tmp5 *ChronoField = tmp4; y = NN(tmp5).CheckValidIntValue_J__I(NN(yearLong).LongValue__J()); var doq int64 = NN(Long_Cast(fieldValues.Get_O__O(IsoFields_Field_DAY_OF_QUARTER))).LongValue__J()

		IsoFields_EnsureIso_TemporalAccessor__V(partialTemporal)
		var date *LocalDate; var tmp6 *ResolverStyle
		ResolverStyle_Init(); tmp6 = ResolverStyle_LENIENT; if resolverStyle == tmp6 {

			date = NN(LocalDate_Of_I_I_I__LocalDate(y, 1, 1)).PlusMonths_J__LocalDate(Math_MultiplyExact_J_I__J(Math_SubtractExact_J_J__J(NN(qoyLong).LongValue__J(), 1), 3))




			doq = Math_SubtractExact_J_J__J(doq, 1) } else {
				var qoy int32 = NN(IsoFields_Field_QUARTER_OF_YEAR.Range__ValueRange()).CheckValidIntValue_J_TemporalField__I(NN(qoyLong).LongValue__J(), IsoFields_Field_QUARTER_OF_YEAR)



				date = LocalDate_Of_I_I_I__LocalDate(y, (qoy-1)*3+1, 1)







				var tmp7 bool; var tmp8 bool; tmp8 = doq < 1; if !tmp8 { tmp8 = doq > 90 }; tmp7 = tmp8; if tmp7 {
					var tmp9 *ResolverStyle; ResolverStyle_Init(); tmp9 = ResolverStyle_STRICT; if resolverStyle == tmp9 {
						NN(t.RangeRefinedBy_TemporalAccessor__ValueRange(Up_LocalDate_TemporalAccessor(date))).CheckValidValue_J_TemporalField__J(doq, t) } else {
							NN(t.Range__ValueRange()).CheckValidValue_J_TemporalField__J(doq, t) } }
				doq = doq - 1 }
		fieldValues.Remove_O__O(t)
		var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_YEAR; fieldValues.Remove_O__O(tmp10.Ref())
		fieldValues.Remove_O__O(IsoFields_Field_QUARTER_OF_YEAR)
		return Up_LocalDate_ChronoLocalDate(NN(date).PlusDays_J__LocalDate(doq)) } }
func (t *IsoFields_Field_1) ToString__String() *String { return Lit_2496 }


func (t *IsoFields_Field_2) GetBaseUnit__TemporalUnit() TemporalUnit { IsoFields_Init(); return IsoFields_QUARTER_YEARS }
func (t *IsoFields_Field_2) GetRangeUnit__TemporalUnit() TemporalUnit { ChronoUnit_Init(); return Up_ChronoUnit_TemporalUnit(ChronoUnit_YEARS) }
func (t *IsoFields_Field_2) Range__ValueRange() *ValueRange { return ValueRange_Of_J_J__ValueRange(1, 4) }
func (t *IsoFields_Field_2) IsSupportedBy_TemporalAccessor__Z(temporal TemporalAccessor) bool {
	var tmp1 bool; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; tmp1 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp2)); if tmp1 { tmp1 = IsoFields_IsIso_TemporalAccessor__Z(temporal) }; return tmp1 }
func (t *IsoFields_Field_2) GetFrom_TemporalAccessor__J(temporal TemporalAccessor) int64 {
	if t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2497))) }
	var moy int64; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; moy = temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp1))
	return (moy + 2) / 3 }
func (t *IsoFields_Field_2) RangeRefinedBy_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	if t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2497))) }
	return t.IsoFields_Field.Impl_RangeRefinedBy_TemporalAccessor__ValueRange(t, temporal) }
func (t *IsoFields_Field_2) AdjustInto_Temporal_J__Temporal(temporal Temporal, newValue int64) Temporal {

	var curValue int64 = t.GetFrom_TemporalAccessor__J(temporal)
	NN(t.Range__ValueRange()).CheckValidValue_J_TemporalField__J(newValue, t)
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_MONTH_OF_YEAR; return temporal.With_TemporalField_J__Temporal(tmp2, temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3))+(newValue-curValue)*3)
}


func (t *IsoFields_Field_2) ToString__String() *String { return Lit_2498 }


func (t *IsoFields_Field_3) GetDisplayName_Locale__String(locale *Locale) *String {
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	var lr *LocaleResources = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(CalendarDataUtility_FindRegionOverride_Locale__Locale(locale)); var rb ResourceBundle_I = NN(lr).GetJavaTimeFormatData__ResourceBundle()


	if rb.ContainsKey_String__Z(Lit_2499) { return rb.GetString_String__String(Lit_2499) } else { return t.ToString__String() } }
func (t *IsoFields_Field_3) GetBaseUnit__TemporalUnit() TemporalUnit { ChronoUnit_Init(); return Up_ChronoUnit_TemporalUnit(ChronoUnit_WEEKS) }
func (t *IsoFields_Field_3) GetRangeUnit__TemporalUnit() TemporalUnit { IsoFields_Init(); return IsoFields_WEEK_BASED_YEARS }
func (t *IsoFields_Field_3) Range__ValueRange() *ValueRange { return ValueRange_Of_J_J_J__ValueRange(1, 52, 53) }
func (t *IsoFields_Field_3) IsSupportedBy_TemporalAccessor__Z(temporal TemporalAccessor) bool {
	var tmp1 bool; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_EPOCH_DAY; tmp1 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp2)); if tmp1 { tmp1 = IsoFields_IsIso_TemporalAccessor__Z(temporal) }; return tmp1 }
func (t *IsoFields_Field_3) RangeRefinedBy_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	if t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2500))) }
	return IsoFields_Field_GetWeekRange_LocalDate__ValueRange(LocalDate_From_TemporalAccessor__LocalDate(temporal)) }
func (t *IsoFields_Field_3) GetFrom_TemporalAccessor__J(temporal TemporalAccessor) int64 { var tmp1 int32; if
												t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
													panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2500))) }; tmp1 =
												IsoFields_Field_GetWeek_LocalDate__I(LocalDate_From_TemporalAccessor__LocalDate(temporal)); return /*line :156:1*/ int64(tmp1) }



func (t *IsoFields_Field_3) AdjustInto_Temporal_J__Temporal(temporal Temporal, newValue int64) Temporal {

	NN(t.Range__ValueRange()).CheckValidValue_J_TemporalField__J(newValue, t)
	var tmp1 int64 = Math_SubtractExact_J_J__J(newValue, t.GetFrom_TemporalAccessor__J(temporal)); var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_WEEKS; return temporal.Plus_J_TemporalUnit__Temporal(tmp1, Up_ChronoUnit_TemporalUnit(tmp2)) }
func (t *IsoFields_Field_3) Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(fieldValues Map, partialTemporal TemporalAccessor, resolverStyle *ResolverStyle) ChronoLocalDate {


	var wbyLong *Long = Long_Cast(fieldValues.Get_O__O(IsoFields_Field_WEEK_BASED_YEAR)); var dowLong *Long; var tmp1 *ChronoField
	ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; dowLong = Long_Cast(fieldValues.Get_O__O(tmp1.Ref()))
	var tmp2 bool; var tmp3 bool; tmp3 = wbyLong == nil; if !tmp3 { tmp3 = dowLong == nil }; tmp2 = tmp3; if tmp2 { return nil } else {
		var wby int32 = NN(IsoFields_Field_WEEK_BASED_YEAR.Range__ValueRange()).CheckValidIntValue_J_TemporalField__I(NN(wbyLong).LongValue__J(), IsoFields_Field_WEEK_BASED_YEAR); var wowby int64 = NN(Long_Cast(fieldValues.Get_O__O(IsoFields_Field_WEEK_OF_WEEK_BASED_YEAR))).LongValue__J()

		IsoFields_EnsureIso_TemporalAccessor__V(partialTemporal)
		var date *LocalDate = LocalDate_Of_I_I_I__LocalDate(wby, 1, 4); var tmp4 *ResolverStyle
		ResolverStyle_Init(); tmp4 = ResolverStyle_LENIENT; if resolverStyle == tmp4 {
			var dow int64 = NN(dowLong).LongValue__J()
			if dow > 7 {

				date = NN(date).PlusWeeks_J__LocalDate((dow - 1) / 7)


				dow = (dow-1)%7 + 1 } else {



					if dow < 1 {
						date = NN(date).PlusWeeks_J__LocalDate(Math_SubtractExact_J_J__J(dow, 7) / 7)


						dow = (dow+6)%7 + 1
					} }
			var tmp5 *LocalDate = NN(date).PlusWeeks_J__LocalDate(Math_SubtractExact_J_J__J(wowby, 1)); var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_DAY_OF_WEEK; date = NN(tmp5).With_TemporalField_J__LocalDate(Up_ChronoField_TemporalField(tmp6), dow) } else {



				var dow_2 int32; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_DAY_OF_WEEK; var tmp8 *ChronoField = tmp7; dow_2 = NN(tmp8).CheckValidIntValue_J__I(NN(dowLong).LongValue__J())
				var tmp9 bool; var tmp10 bool; tmp10 = wowby < 1; if !tmp10 { tmp10 = wowby > 52 }; tmp9 = tmp10; if tmp9 {
					var tmp11 *ResolverStyle; ResolverStyle_Init(); tmp11 = ResolverStyle_STRICT; if resolverStyle == tmp11 {
						NN(IsoFields_Field_GetWeekRange_LocalDate__ValueRange(date)).CheckValidValue_J_TemporalField__J(wowby, t) } else {
							NN(t.Range__ValueRange()).CheckValidValue_J_TemporalField__J(wowby, t) } }
				var tmp12 *LocalDate = NN(date).PlusWeeks_J__LocalDate(wowby - 1); var tmp13 *ChronoField; ChronoField_Init(); tmp13 = ChronoField_DAY_OF_WEEK; date = NN(tmp12).With_TemporalField_J__LocalDate(Up_ChronoField_TemporalField(tmp13), int64(dow_2))
			}


		fieldValues.Remove_O__O(t)
		fieldValues.Remove_O__O(IsoFields_Field_WEEK_BASED_YEAR)
		var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_DAY_OF_WEEK; fieldValues.Remove_O__O(tmp14.Ref())
//line :173:1
		return Up_LocalDate_ChronoLocalDate(date)
	}
}
































func (t *IsoFields_Field_3) ToString__String() *String { return Lit_2359 }


func (t *IsoFields_Field_4) GetBaseUnit__TemporalUnit() TemporalUnit { IsoFields_Init(); return IsoFields_WEEK_BASED_YEARS }
func (t *IsoFields_Field_4) GetRangeUnit__TemporalUnit() TemporalUnit { ChronoUnit_Init(); return Up_ChronoUnit_TemporalUnit(ChronoUnit_FOREVER) }
func (t *IsoFields_Field_4) Range__ValueRange() *ValueRange { var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; return NN(tmp1).Range__ValueRange() }
func (t *IsoFields_Field_4) IsSupportedBy_TemporalAccessor__Z(temporal TemporalAccessor) bool {
	var tmp1 bool; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_EPOCH_DAY; tmp1 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp2)); if tmp1 { tmp1 = IsoFields_IsIso_TemporalAccessor__Z(temporal) }; return tmp1 }
func (t *IsoFields_Field_4) GetFrom_TemporalAccessor__J(temporal TemporalAccessor) int64 { var tmp1 int32; if
												t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
													panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2501))) }; tmp1 =
												IsoFields_Field_GetWeekBasedYear_LocalDate__I(LocalDate_From_TemporalAccessor__LocalDate(temporal)); return /*line :216:1*/ int64(tmp1) }



func (t *IsoFields_Field_4) RangeRefinedBy_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	if t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2501))) }
	var range_ *ValueRange = t.IsoFields_Field.Impl_RangeRefinedBy_TemporalAccessor__ValueRange(t, temporal); var chronoRange *ValueRange; var tmp1 Chronology = Chronology_From_TemporalAccessor__Chronology(temporal); var tmp2 *ChronoField
	ChronoField_Init(); tmp2 = ChronoField_YEAR; chronoRange = tmp1.Range_ChronoField__ValueRange(tmp2)
	return ValueRange_Of_J_J__ValueRange(Math_Max_J_J__J(NN(range_).GetMinimum__J(), NN(chronoRange).GetMinimum__J()), Math_Min_J_J__J(NN(range_).GetMaximum__J(), NN(chronoRange).GetMaximum__J()))
}
func (t *IsoFields_Field_4) AdjustInto_Temporal_J__Temporal(temporal Temporal, newValue int64) Temporal {

	if t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2501))) }
	var newWby int32 = NN(t.Range__ValueRange()).CheckValidIntValue_J_TemporalField__I(newValue, IsoFields_Field_WEEK_BASED_YEAR); var date *LocalDate = LocalDate_From_TemporalAccessor__LocalDate(temporal); var dow int32; var tmp1 *ChronoField

	ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; dow = NN(date).Get_TemporalField__I(Up_ChronoField_TemporalField(tmp1))
//line :231:1
	var week int32 = IsoFields_Field_GetWeek_LocalDate__I(date); var tmp2 bool; var tmp3 bool



	tmp3 = week == 53; if tmp3 { tmp3 = IsoFields_Field_GetWeekRange_I__I(newWby) == 52 }; tmp2 = tmp3; if tmp2 { week = 52 }
	var resolved *LocalDate = LocalDate_Of_I_I_I__LocalDate(newWby, 1, 4); var days int32; var tmp4 *LocalDate = resolved; var tmp5 *ChronoField
	ChronoField_Init(); tmp5 = ChronoField_DAY_OF_WEEK; days = dow - NN(tmp4).Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5)) + (week-1)*7


	resolved = NN(resolved).PlusDays_J__LocalDate(int64(days))
	return temporal.With_TemporalAdjuster__Temporal(Up_LocalDate_TemporalAdjuster(resolved)) }
func (t *IsoFields_Field_4) ToString__String() *String { return Lit_2355 }

func (t *IsoFields_Field) Impl_IsDateBased__Z(this IsoFields_Field_I) bool { return true }

func (t *IsoFields_Field) Impl_IsTimeBased__Z(this IsoFields_Field_I) bool { return false }

func (t *IsoFields_Field) Impl_RangeRefinedBy_TemporalAccessor__ValueRange(this IsoFields_Field_I, temporal TemporalAccessor) *ValueRange {
	return this.Range__ValueRange()
}


func IsoFields_Field_GetWeekRange_LocalDate__ValueRange(date *LocalDate) *ValueRange { IsoFields_Field_Init()
	var wby int32 = IsoFields_Field_GetWeekBasedYear_LocalDate__I(date); return ValueRange_Of_J_J__ValueRange(1, int64(IsoFields_Field_GetWeekRange_I__I(wby)))
}
func IsoFields_Field_GetWeekRange_I__I(wby int32) int32 { IsoFields_Field_Init()
	var date *LocalDate = LocalDate_Of_I_I_I__LocalDate(wby, 1, 1); var tmp1 bool; var tmp2 bool; var tmp3 *DayOfWeek = NN(date).GetDayOfWeek__DayOfWeek(); var tmp4 *DayOfWeek
	DayOfWeek_Init(); tmp4 = DayOfWeek_THURSDAY; tmp2 = tmp3 == tmp4; if !tmp2 {
		var tmp5 bool; var tmp6 *DayOfWeek = NN(date).GetDayOfWeek__DayOfWeek(); var tmp7 *DayOfWeek; DayOfWeek_Init(); tmp7 = DayOfWeek_WEDNESDAY; tmp5 = tmp6 == tmp7; if tmp5 { tmp5 = NN(date).IsLeapYear__Z() }; tmp2 = tmp5 }
//line :258:1
	tmp1 = tmp2; if tmp1 { return 53 } else { return 52
	}
}


func IsoFields_Field_GetWeek_LocalDate__I(date *LocalDate) int32 { IsoFields_Field_Init()
	var dow0 int32 = NN(NN(date).GetDayOfWeek__DayOfWeek()).Ordinal__I(); var doy0 int32 = NN(date).GetDayOfYear__I() - 1; var doyThu0 int32 = doy0 + (3 - dow0); var alignedWeek int32 = doyThu0 / 7; var firstThuDoy0 int32 = doyThu0 - alignedWeek*7; var firstMonDoy0 int32 = firstThuDoy0 - 3





	if firstMonDoy0 < -3 { firstMonDoy0 = firstMonDoy0 + 7 }
	if doy0 < firstMonDoy0 {
		return int32(NN(IsoFields_Field_GetWeekRange_LocalDate__ValueRange(NN(NN(date).WithDayOfYear_I__LocalDate(180)).MinusYears_J__LocalDate(1))).GetMaximum__J()) } else {

			var week int32 = (doy0-firstMonDoy0)/7 + 1




			if week == 53 {
				var tmp1 bool; var tmp2 bool; tmp2 = firstMonDoy0 == -3; if !tmp2 { var tmp3 bool; tmp3 = firstMonDoy0 == -2; if tmp3 { tmp3 = NN(date).IsLeapYear__Z() }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 == false {

					week = 1 } }
//line :274:1
			return week
		}
}








func IsoFields_Field_GetWeekBasedYear_LocalDate__I(date *LocalDate) int32 { IsoFields_Field_Init()
	var year int32 = NN(date).GetYear__I(); var doy int32 = NN(date).GetDayOfYear__I()

	if doy <= 3 {

		var dow int32 = NN(NN(date).GetDayOfWeek__DayOfWeek()).Ordinal__I()
		if doy-dow < -2 { year = year - 1 } } else {
//line :288:1
			if doy >= 363 {




				var dow_2 int32 = NN(NN(date).GetDayOfWeek__DayOfWeek()).Ordinal__I(); var tmp1 int32 = doy - 363; var tmp2 int32


				if NN(date).IsLeapYear__Z() { tmp2 = 1 } else { tmp2 = 0 }
//line :294:1
				doy = tmp1 - tmp2


				if doy-dow_2 >= 0 { year = year + 1 } } }
//line :286:1
	return year
}























func IsoFields_Unit_New_String_I_String_Duration(p0 *String, p1 int32, p2 *String, p3 *Duration) *IsoFields_Unit { IsoFields_Unit_Init(); t := &IsoFields_Unit{}; t.Ctor_String_I_String_Duration(p0, p1, p2, p3); return t }
//line :311:1
func (t *IsoFields_Unit) Ctor_String_I_String_Duration(enumName *String, enumOrdinal int32, name *String, estimatedDuration *Duration) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)
	t.F_name = name
	t.F_duration = estimatedDuration
}
func (t *IsoFields_Unit) GetDuration__Duration() *Duration { return t.F_duration }

func (t *IsoFields_Unit) IsDurationEstimated__Z() bool { return true }

func (t *IsoFields_Unit) IsDateBased__Z() bool { return true }

func (t *IsoFields_Unit) IsTimeBased__Z() bool { return false }

func (t *IsoFields_Unit) IsSupportedBy_Temporal__Z(temporal Temporal) bool {
	var tmp1 bool; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_EPOCH_DAY; tmp1 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp2)); if tmp1 { tmp1 = IsoFields_IsIso_TemporalAccessor__Z(temporal) }; return tmp1
}
func (t *IsoFields_Unit) AddTo_Temporal_J__Temporal(temporal Temporal, amount int64) Temporal {
	switch NN(t).F_ordinal { case 0:

		var tmp1 TemporalField; IsoFields_Init(); tmp1 = IsoFields_WEEK_BASED_YEAR; var tmp2 TemporalField = tmp1; var tmp3 TemporalField; IsoFields_Init(); tmp3 = IsoFields_WEEK_BASED_YEAR; return temporal.With_TemporalField_J__Temporal(tmp2, Math_AddExact_J_J__J(int64(temporal.Get_TemporalField__I(tmp3)), amount)); case 1:

		var tmp4 int64 = amount / 4; var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_YEARS; var tmp6 Temporal = temporal.Plus_J_TemporalUnit__Temporal(tmp4, Up_ChronoUnit_TemporalUnit(tmp5)); var tmp7 int64 = amount % 4 * 3; var tmp8 *ChronoUnit; ChronoUnit_Init(); tmp8 = ChronoUnit_MONTHS; return tmp6.Plus_J_TemporalUnit__Temporal(tmp7, Up_ChronoUnit_TemporalUnit(tmp8)); default:


		panic(Thrown(IllegalStateException_New_String(Lit_2348)))}; panic("a2g: unreachable")
}
func (t *IsoFields_Unit) Between_Temporal_Temporal__J(temporal1Inclusive, temporal2Exclusive Temporal) int64 {
	if !(temporal1Inclusive.GetClass__Class() == temporal2Exclusive.GetClass__Class()) {
		return temporal1Inclusive.Until_Temporal_TemporalUnit__J(temporal2Exclusive, t) } else {
			switch NN(t).F_ordinal { case 0:

				var tmp1 TemporalField; IsoFields_Init(); tmp1 = IsoFields_WEEK_BASED_YEAR; var tmp2 int64 = temporal2Exclusive.GetLong_TemporalField__J(tmp1); var tmp3 TemporalField; IsoFields_Init(); tmp3 = IsoFields_WEEK_BASED_YEAR; return Math_SubtractExact_J_J__J(tmp2, temporal1Inclusive.GetLong_TemporalField__J(tmp3)); case 1:


				var tmp4 *ChronoUnit; ChronoUnit_Init(); tmp4 = ChronoUnit_MONTHS; return temporal1Inclusive.Until_Temporal_TemporalUnit__J(temporal2Exclusive, Up_ChronoUnit_TemporalUnit(tmp4)) / 3; default:
				panic(Thrown(IllegalStateException_New_String(Lit_2348)))} }; panic("a2g: unreachable")
}
func (t *IsoFields_Unit) ToString__String() *String { return t.F_name }

func IsoFields_EnsureIso_TemporalAccessor__V(temporal TemporalAccessor) { IsoFields_Init()
	if IsoFields_IsIso_TemporalAccessor__Z(temporal) { } else {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2490, StrOfObj(Chronology_From_TemporalAccessor__Chronology(temporal))))))
	}
}
func IsoFields_IsIso_TemporalAccessor__Z(temporal TemporalAccessor) bool { IsoFields_Init()
	return Chronology_From_TemporalAccessor__Chronology(temporal).IsIsoBased__Z()
}


type IsoFields struct{ Object }

var IsoFields_DAY_OF_QUARTER TemporalField

var IsoFields_QUARTER_OF_YEAR TemporalField

var IsoFields_WEEK_OF_WEEK_BASED_YEAR TemporalField

var IsoFields_WEEK_BASED_YEAR TemporalField

var IsoFields_WEEK_BASED_YEARS TemporalUnit

var IsoFields_QUARTER_YEARS TemporalUnit

var IsoFields_init ClassInit

func IsoFields_Init() { if !IsoFields_init.Done() { IsoFields_init.Run(IsoFields_clinit) } }

func IsoFields_clinit() { var tmp1 IsoFields_Field_I; IsoFields_Field_Init(); tmp1 = IsoFields_Field_DAY_OF_QUARTER; IsoFields_DAY_OF_QUARTER = tmp1; var tmp2 IsoFields_Field_I; IsoFields_Field_Init(); tmp2 = IsoFields_Field_QUARTER_OF_YEAR; IsoFields_QUARTER_OF_YEAR = tmp2; var tmp3 IsoFields_Field_I; IsoFields_Field_Init(); tmp3 = IsoFields_Field_WEEK_OF_WEEK_BASED_YEAR; IsoFields_WEEK_OF_WEEK_BASED_YEAR = tmp3; var tmp4 IsoFields_Field_I; IsoFields_Field_Init(); tmp4 = IsoFields_Field_WEEK_BASED_YEAR; IsoFields_WEEK_BASED_YEAR = tmp4; var tmp5 *IsoFields_Unit; IsoFields_Unit_Init(); tmp5 = IsoFields_Unit_WEEK_BASED_YEARS; IsoFields_WEEK_BASED_YEARS = Up_IsoFields_Unit_TemporalUnit(tmp5); var tmp6 *IsoFields_Unit; IsoFields_Unit_Init(); tmp6 = IsoFields_Unit_QUARTER_YEARS; IsoFields_QUARTER_YEARS = Up_IsoFields_Unit_TemporalUnit(tmp6) }

func (t *IsoFields) Ref() any { if t == nil { return nil }; return t }

func (t *IsoFields) GetClass__Class() *Class { return IsoFields_class }

func (t *IsoFields) ToString__String() *String { return Object_toString(t) }

func (t *IsoFields) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IsoFields) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoFields_InstanceOf(x any) bool { _, ok := x.(*IsoFields); return ok }

func IsoFields_Cast(x any) *IsoFields { if x == nil { return nil }; v, ok := x.(*IsoFields); if !ok { panic(ClassCast(x, IsoFields_class)) }; return v }



type IsoFields_Field struct{ Enum }

type IsoFields_Field_I interface{ Enum_I; TemporalField; Constable; Comparable; Serializable; Self_IsoFields_Field() *IsoFields_Field; IsDateBased__Z() bool; IsTimeBased__Z() bool; RangeRefinedBy_TemporalAccessor__ValueRange(p0 TemporalAccessor) *ValueRange }

func (t *IsoFields_Field) Self_IsoFields_Field() *IsoFields_Field { return t }

func (t *IsoFields_Field) Is_TemporalField() {}

func (t *IsoFields_Field) Is_Constable() {}

var IsoFields_Field_DAY_OF_QUARTER IsoFields_Field_I

var IsoFields_Field_QUARTER_OF_YEAR IsoFields_Field_I

var IsoFields_Field_WEEK_OF_WEEK_BASED_YEAR IsoFields_Field_I

var IsoFields_Field_WEEK_BASED_YEAR IsoFields_Field_I

var IsoFields_Field__VALUES *RefArray

var IsoFields_Field_QUARTER_DAYS *IntArray

var IsoFields_Field_init ClassInit

func IsoFields_Field_Init() { if !IsoFields_Field_init.Done() { IsoFields_Field_init.Run(IsoFields_Field_clinit) } }

func IsoFields_Field_clinit() { IsoFields_Field_DAY_OF_QUARTER = IsoFields_Field_1_New_String_I(Lit_2491, 0); IsoFields_Field_QUARTER_OF_YEAR = IsoFields_Field_2_New_String_I(Lit_2492, 1); IsoFields_Field_WEEK_OF_WEEK_BASED_YEAR = IsoFields_Field_3_New_String_I(Lit_2493, 2); IsoFields_Field_WEEK_BASED_YEAR = IsoFields_Field_4_New_String_I(Lit_2494, 3); IsoFields_Field__VALUES = IsoFields_Field_X_values__IsoFields_Field1(); IsoFields_Field_QUARTER_DAYS = IntArrayOf(0, 90, 181, 273, 0, 91, 182, 274) }

func (t *IsoFields_Field) Ctor_String_I(this IsoFields_Field_I, enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(this, enumName, enumOrdinal) }

func IsoFields_Field_Values__IsoFields_Field1() *RefArray { IsoFields_Field_Init(); return IsoFields_Field__VALUES.Copy() }

func IsoFields_Field_ValueOf_String__IsoFields_Field(p0 *String) IsoFields_Field_I { IsoFields_Field_Init(); return IsoFields_Field_Cast(Enum_ValueOf_Class_String__Enum(IsoFields_Field_class, p0)) }

func IsoFields_Field_X_values__IsoFields_Field1() *RefArray { IsoFields_Field_Init(); return RefArrayOf(IsoFields_Field_class, IsoFields_Field_DAY_OF_QUARTER, IsoFields_Field_QUARTER_OF_YEAR, IsoFields_Field_WEEK_OF_WEEK_BASED_YEAR, IsoFields_Field_WEEK_BASED_YEAR) }

func IsoFields_Field_InstanceOf(x any) bool { _, ok := x.(IsoFields_Field_I); return ok }

func IsoFields_Field_Cast(x any) IsoFields_Field_I { if x == nil { return nil }; v, ok := x.(IsoFields_Field_I); if !ok { panic(ClassCast(x, IsoFields_Field_class)) }; return v }



type IsoFields_Field_1 struct{ IsoFields_Field }

var IsoFields_Field_1_init ClassInit

func IsoFields_Field_1_Init() { if !IsoFields_Field_1_init.Done() { IsoFields_Field_1_init.Run(IsoFields_Field_1_clinit) } }

func IsoFields_Field_1_clinit() { IsoFields_Field_Init() }

func IsoFields_Field_1_New_String_I(p0 *String, p1 int32) *IsoFields_Field_1 { IsoFields_Field_1_Init(); t := &IsoFields_Field_1{}; t.Ctor_String_I(p0, p1); return t }

func (t *IsoFields_Field_1) Ctor_String_I(enumName *String, enumOrdinal int32) { t.IsoFields_Field.Ctor_String_I(t, enumName, enumOrdinal) }

func (t *IsoFields_Field_1) Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor { return t.Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(p0, p1, p2) }

func (t *IsoFields_Field_1) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.IsoFields$Field$1.describeConstable()Ljava/util/Optional;")) }

func (t *IsoFields_Field_1) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *IsoFields_Field_1) GetDisplayName_Locale__String(p0 *Locale) *String { return TemporalField_GetDisplayName_Locale__String(t, p0) }

func (t *IsoFields_Field_1) IsTimeBased__Z() bool { return t.Impl_IsTimeBased__Z(t) }

func (t *IsoFields_Field_1) IsDateBased__Z() bool { return t.Impl_IsDateBased__Z(t) }

func (t *IsoFields_Field_1) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *IsoFields_Field_1) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *IsoFields_Field_1) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *IsoFields_Field_1) Ref() any { if t == nil { return nil }; return t }

func (t *IsoFields_Field_1) GetClass__Class() *Class { return IsoFields_Field_1_class }

func (t *IsoFields_Field_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoFields_Field_1_InstanceOf(x any) bool { _, ok := x.(*IsoFields_Field_1); return ok }

func IsoFields_Field_1_Cast(x any) *IsoFields_Field_1 { if x == nil { return nil }; v, ok := x.(*IsoFields_Field_1); if !ok { panic(ClassCast(x, IsoFields_Field_1_class)) }; return v }



type IsoFields_Field_2 struct{ IsoFields_Field }

var IsoFields_Field_2_init ClassInit

func IsoFields_Field_2_Init() { if !IsoFields_Field_2_init.Done() { IsoFields_Field_2_init.Run(IsoFields_Field_2_clinit) } }

func IsoFields_Field_2_clinit() { IsoFields_Field_Init() }

func IsoFields_Field_2_New_String_I(p0 *String, p1 int32) *IsoFields_Field_2 { IsoFields_Field_2_Init(); t := &IsoFields_Field_2{}; t.Ctor_String_I(p0, p1); return t }

func (t *IsoFields_Field_2) Ctor_String_I(enumName *String, enumOrdinal int32) { t.IsoFields_Field.Ctor_String_I(t, enumName, enumOrdinal) }

func (t *IsoFields_Field_2) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.IsoFields$Field$2.describeConstable()Ljava/util/Optional;")) }

func (t *IsoFields_Field_2) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *IsoFields_Field_2) Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor { return TemporalField_Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(t, p0, p1, p2) }

func (t *IsoFields_Field_2) GetDisplayName_Locale__String(p0 *Locale) *String { return TemporalField_GetDisplayName_Locale__String(t, p0) }

func (t *IsoFields_Field_2) IsTimeBased__Z() bool { return t.Impl_IsTimeBased__Z(t) }

func (t *IsoFields_Field_2) IsDateBased__Z() bool { return t.Impl_IsDateBased__Z(t) }

func (t *IsoFields_Field_2) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *IsoFields_Field_2) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *IsoFields_Field_2) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *IsoFields_Field_2) Ref() any { if t == nil { return nil }; return t }

func (t *IsoFields_Field_2) GetClass__Class() *Class { return IsoFields_Field_2_class }

func (t *IsoFields_Field_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoFields_Field_2_InstanceOf(x any) bool { _, ok := x.(*IsoFields_Field_2); return ok }

func IsoFields_Field_2_Cast(x any) *IsoFields_Field_2 { if x == nil { return nil }; v, ok := x.(*IsoFields_Field_2); if !ok { panic(ClassCast(x, IsoFields_Field_2_class)) }; return v }



type IsoFields_Field_3 struct{ IsoFields_Field }

var IsoFields_Field_3_init ClassInit

func IsoFields_Field_3_Init() { if !IsoFields_Field_3_init.Done() { IsoFields_Field_3_init.Run(IsoFields_Field_3_clinit) } }

func IsoFields_Field_3_clinit() { IsoFields_Field_Init() }

func IsoFields_Field_3_New_String_I(p0 *String, p1 int32) *IsoFields_Field_3 { IsoFields_Field_3_Init(); t := &IsoFields_Field_3{}; t.Ctor_String_I(p0, p1); return t }

func (t *IsoFields_Field_3) Ctor_String_I(enumName *String, enumOrdinal int32) { t.IsoFields_Field.Ctor_String_I(t, enumName, enumOrdinal) }

func (t *IsoFields_Field_3) Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor { return t.Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(p0, p1, p2) }

func (t *IsoFields_Field_3) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.IsoFields$Field$3.describeConstable()Ljava/util/Optional;")) }

func (t *IsoFields_Field_3) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *IsoFields_Field_3) IsTimeBased__Z() bool { return t.Impl_IsTimeBased__Z(t) }

func (t *IsoFields_Field_3) IsDateBased__Z() bool { return t.Impl_IsDateBased__Z(t) }

func (t *IsoFields_Field_3) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *IsoFields_Field_3) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *IsoFields_Field_3) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *IsoFields_Field_3) Ref() any { if t == nil { return nil }; return t }

func (t *IsoFields_Field_3) GetClass__Class() *Class { return IsoFields_Field_3_class }

func (t *IsoFields_Field_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoFields_Field_3_InstanceOf(x any) bool { _, ok := x.(*IsoFields_Field_3); return ok }

func IsoFields_Field_3_Cast(x any) *IsoFields_Field_3 { if x == nil { return nil }; v, ok := x.(*IsoFields_Field_3); if !ok { panic(ClassCast(x, IsoFields_Field_3_class)) }; return v }



type IsoFields_Field_4 struct{ IsoFields_Field }

var IsoFields_Field_4_init ClassInit

func IsoFields_Field_4_Init() { if !IsoFields_Field_4_init.Done() { IsoFields_Field_4_init.Run(IsoFields_Field_4_clinit) } }

func IsoFields_Field_4_clinit() { IsoFields_Field_Init() }

func IsoFields_Field_4_New_String_I(p0 *String, p1 int32) *IsoFields_Field_4 { IsoFields_Field_4_Init(); t := &IsoFields_Field_4{}; t.Ctor_String_I(p0, p1); return t }

func (t *IsoFields_Field_4) Ctor_String_I(enumName *String, enumOrdinal int32) { t.IsoFields_Field.Ctor_String_I(t, enumName, enumOrdinal) }

func (t *IsoFields_Field_4) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.IsoFields$Field$4.describeConstable()Ljava/util/Optional;")) }

func (t *IsoFields_Field_4) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *IsoFields_Field_4) Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor { return TemporalField_Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(t, p0, p1, p2) }

func (t *IsoFields_Field_4) GetDisplayName_Locale__String(p0 *Locale) *String { return TemporalField_GetDisplayName_Locale__String(t, p0) }

func (t *IsoFields_Field_4) IsTimeBased__Z() bool { return t.Impl_IsTimeBased__Z(t) }

func (t *IsoFields_Field_4) IsDateBased__Z() bool { return t.Impl_IsDateBased__Z(t) }

func (t *IsoFields_Field_4) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *IsoFields_Field_4) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *IsoFields_Field_4) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *IsoFields_Field_4) Ref() any { if t == nil { return nil }; return t }

func (t *IsoFields_Field_4) GetClass__Class() *Class { return IsoFields_Field_4_class }

func (t *IsoFields_Field_4) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoFields_Field_4_InstanceOf(x any) bool { _, ok := x.(*IsoFields_Field_4); return ok }

func IsoFields_Field_4_Cast(x any) *IsoFields_Field_4 { if x == nil { return nil }; v, ok := x.(*IsoFields_Field_4); if !ok { panic(ClassCast(x, IsoFields_Field_4_class)) }; return v }



type IsoFields_Unit struct{ Enum; F_name *String; F_duration *Duration }

func (t *IsoFields_Unit) Is_TemporalUnit() {}

func (t *IsoFields_Unit) Is_Constable() {}

var IsoFields_Unit_WEEK_BASED_YEARS *IsoFields_Unit

var IsoFields_Unit_QUARTER_YEARS *IsoFields_Unit

var IsoFields_Unit__VALUES *RefArray

var IsoFields_Unit_init ClassInit

func IsoFields_Unit_Init() { if !IsoFields_Unit_init.Done() { IsoFields_Unit_init.Run(IsoFields_Unit_clinit) } }

func IsoFields_Unit_clinit() { IsoFields_Unit_WEEK_BASED_YEARS = IsoFields_Unit_New_String_I_String_Duration(Lit_2503, 0, Lit_2502, Duration_OfSeconds_J__Duration(31556952)); IsoFields_Unit_QUARTER_YEARS = IsoFields_Unit_New_String_I_String_Duration(Lit_2505, 1, Lit_2504, Duration_OfSeconds_J__Duration(7889238)); IsoFields_Unit__VALUES = IsoFields_Unit_X_values__IsoFields_Unit1() }

func IsoFields_Unit_Values__IsoFields_Unit1() *RefArray { IsoFields_Unit_Init(); return IsoFields_Unit__VALUES.Copy() }

func IsoFields_Unit_ValueOf_String__IsoFields_Unit(p0 *String) *IsoFields_Unit { IsoFields_Unit_Init(); return IsoFields_Unit_Cast(Enum_ValueOf_Class_String__Enum(IsoFields_Unit_class, p0)) }

func IsoFields_Unit_X_values__IsoFields_Unit1() *RefArray { IsoFields_Unit_Init(); return RefArrayOf(IsoFields_Unit_class, IsoFields_Unit_WEEK_BASED_YEARS, IsoFields_Unit_QUARTER_YEARS) }

func (t *IsoFields_Unit) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.IsoFields$Unit.describeConstable()Ljava/util/Optional;")) }

func (t *IsoFields_Unit) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *IsoFields_Unit) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *IsoFields_Unit) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *IsoFields_Unit) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *IsoFields_Unit) Ref() any { if t == nil { return nil }; return t }

func (t *IsoFields_Unit) GetClass__Class() *Class { return IsoFields_Unit_class }

func (t *IsoFields_Unit) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoFields_Unit_InstanceOf(x any) bool { _, ok := x.(*IsoFields_Unit); return ok }

func IsoFields_Unit_Cast(x any) *IsoFields_Unit { if x == nil { return nil }; v, ok := x.(*IsoFields_Unit); if !ok { panic(ClassCast(x, IsoFields_Unit_class)) }; return v }
