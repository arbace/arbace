//line java_text_SimpleDateFormat.ae:1
package jrt































































func SimpleDateFormat_New() *SimpleDateFormat { SimpleDateFormat_Init(); t := &SimpleDateFormat{}; t.Ctor(); return t }
//line :65:1
func (t *SimpleDateFormat) Ctor() { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_String_Locale(Lit_69, Locale_GetDefault_Locale_Category__Locale(tmp1));

	t.ApplyPatternImpl_String__V(NN(LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(t.F_locale)).GetDateTimePattern_I_I_Calendar__String(3, 3, t.F_calendar)) }






func SimpleDateFormat_New_String(p0 *String) *SimpleDateFormat { SimpleDateFormat_Init(); t := &SimpleDateFormat{}; t.Ctor_String(p0); return t }
//line :74:1
func (t *SimpleDateFormat) Ctor_String(pattern *String) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_String_Locale(pattern, Locale_GetDefault_Locale_Category__Locale(tmp1)) }


func SimpleDateFormat_New_String_Locale(p0 *String, p1 *Locale) *SimpleDateFormat { SimpleDateFormat_Init(); t := &SimpleDateFormat{}; t.Ctor_String_Locale(p0, p1); return t }
//line :77:1
func (t *SimpleDateFormat) Ctor_String_Locale(pattern *String, locale *Locale) { t.DateFormat.Ctor(t); t.F_serialVersionOnStream = 1; t.F_minusSign = 45; t.F_hasFollowingMinusSign = false; t.F_forceStandaloneForm = false
	var tmp1 bool; var tmp2 bool; tmp2 = pattern == nil; if !tmp2 { tmp2 = locale == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	t.InitializeCalendar_Locale__V(locale)
	t.F_pattern = pattern
	t.F_formatData = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(locale)
	t.F_locale = locale
	t.Initialize_Locale__V(locale)
}
func SimpleDateFormat_New_String_DateFormatSymbols(p0 *String, p1 *DateFormatSymbols) *SimpleDateFormat { SimpleDateFormat_Init(); t := &SimpleDateFormat{}; t.Ctor_String_DateFormatSymbols(p0, p1); return t }
//line :85:1
func (t *SimpleDateFormat) Ctor_String_DateFormatSymbols(pattern *String, formatSymbols *DateFormatSymbols) { t.DateFormat.Ctor(t); t.F_serialVersionOnStream = 1; t.F_minusSign = 45; t.F_hasFollowingMinusSign = false; t.F_forceStandaloneForm = false
	var tmp1 bool; var tmp2 bool; tmp2 = pattern == nil; if !tmp2 { tmp2 = formatSymbols == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	t.F_pattern = pattern
	t.F_formatData = DateFormatSymbols_Cast(NN(formatSymbols).Clone__O())
	var tmp3 *Locale_Category; Locale_Category_Init(); tmp3 = Locale_Category_FORMAT; t.F_locale = Locale_GetDefault_Locale_Category__Locale(tmp3)
	t.InitializeCalendar_Locale__V(t.F_locale)
	t.Initialize_Locale__V(t.F_locale)
	t.F_useDateFormatSymbols = true
}
func (t *SimpleDateFormat) Initialize_Locale__V(loc *Locale) {
	t.F_compiledPattern = t.Compile_String__C1(t.F_pattern)
	t.F_numberFormat = NumberFormat_Cast(SimpleDateFormat_cachedNumberFormatData.Get_O__O(loc.Ref()))
	if t.F_numberFormat == nil {
		t.F_numberFormat = NumberFormat_GetIntegerInstance_Locale__NumberFormat(loc)
		t.F_numberFormat.SetGroupingUsed_Z__V(false)
		SimpleDateFormat_cachedNumberFormatData.PutIfAbsent_O_O__O(loc.Ref(), t.F_numberFormat) }
	t.F_numberFormat = NumberFormat_Cast(t.F_numberFormat.Clone__O())
	t.InitializeDefaultCentury__V()
}
func (t *SimpleDateFormat) InitializeCalendar_Locale__V(loc *Locale) {
	if t.F_calendar == nil {
		if !A2g_AssertionsDisabled && !!(loc == nil) { panic(Thrown(AssertionError_New())) }
		t.F_calendar = Calendar_GetInstance_Locale__Calendar(loc)
	} }
func (t *SimpleDateFormat) Compile_String__C1(pattern *String) *CharArray {
	var length int32 = NN(pattern).Length__I(); var inQuote bool = false; var compiledCode *StringBuilder = StringBuilder_New_I(length * 2); var tmpBuffer *StringBuilder
	var count int32 = 0
	var tagcount int32 = 0
	var lastTag int32 = -1
	var prevTag int32 = -1
	var i int32 = 0



L1: for { if i < length {
	var c uint16 = NN(pattern).CharAt_I__C(i)
	if int32(c) == 39 {


		if i+1 < length {
			c = NN(pattern).CharAt_I__C(i + 1)
			if int32(c) == 39 {
				i = i + 1
				if count == 0 { } else {
					SimpleDateFormat_Encode_I_I_StringBuilder__V(lastTag, count, compiledCode)
					tagcount = tagcount + 1
					prevTag = lastTag
					lastTag = -1
					count = 0 }
				if inQuote {
					NN(tmpBuffer).Append_C__StringBuilder(c) } else {
						NN(compiledCode).Append_C__StringBuilder(uint16(25600 | int32(c)))
					}

				i = i + 1
				continue L1 } }
		if !inQuote {

			if count == 0 { } else {
				SimpleDateFormat_Encode_I_I_StringBuilder__V(lastTag, count, compiledCode)
				tagcount = tagcount + 1
				prevTag = lastTag
				lastTag = -1
				count = 0 }
			if tmpBuffer == nil {
				tmpBuffer = StringBuilder_New_I(length) } else {
					NN(tmpBuffer).SetLength_I__V(0) }
			inQuote = true } else {
				var len_ int32 = NN(tmpBuffer).Length__I()
				if len_ == 1 {
					var ch uint16 = NN(tmpBuffer).CharAt_I__C(0)
					if int32(ch) < 128 {
						NN(compiledCode).Append_C__StringBuilder(uint16(25600 | int32(ch))) } else {





							NN(compiledCode).Append_C__StringBuilder(25857)



							NN(compiledCode).Append_C__StringBuilder(ch) } } else {

								SimpleDateFormat_Encode_I_I_StringBuilder__V(101, len_, compiledCode)
								NN(compiledCode).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(tmpBuffer)) }
				inQuote = false } } else {
//line :121:1
					if inQuote {


















































						NN(tmpBuffer).Append_C__StringBuilder(c) } else {
//line :121:1
							var tmp1 bool; var tmp2 bool; var tmp3 bool



















































							tmp3 = int32(c) >= 97; if tmp3 { tmp3 = int32(c) <= 122 }; tmp2 = tmp3; if !tmp2 { var tmp4 bool; tmp4 = int32(c) >= 65; if tmp4 { tmp4 = int32(c) <= 90 }; tmp2 = tmp4 }; tmp1 = tmp2
//line :121:1
							if !tmp1 {





















































								if count == 0 { } else {
									SimpleDateFormat_Encode_I_I_StringBuilder__V(lastTag, count, compiledCode)
									tagcount = tagcount + 1
									prevTag = lastTag
									lastTag = -1
									count = 0 }
								if int32(c) < 128 {
									NN(compiledCode).Append_C__StringBuilder(uint16(25600 | int32(c))) } else {


										var j int32 = 0
										j = i + 1
									L2: for { if j < length {
										var d uint16 = NN(pattern).CharAt_I__C(j); var tmp5 bool; var tmp6 bool
										tmp6 = int32(d) == 39; if !tmp6 {
											var tmp7 bool; var tmp8 bool; tmp8 = int32(d) >= 97; if tmp8 { tmp8 = int32(d) <= 122 }; tmp7 = tmp8; if !tmp7 { var tmp9 bool; tmp9 = int32(d) >= 65; if tmp9 { tmp9 = int32(d) <= 90 }; tmp7 = tmp9 }; tmp6 = tmp7 }
//line :189:1
										tmp5 = tmp6; if tmp5 {

											break L2 }
										j = j + 1
//line :187:1
										continue L2 }; break L2
									}




										SimpleDateFormat_Encode_I_I_StringBuilder__V(101, j-i, compiledCode)



									L3: for { if i < j {
										NN(compiledCode).Append_C__StringBuilder(NN(pattern).CharAt_I__C(i))
										i = i + 1
//line :197:1
										continue L3 }; break L3
									}

										i = i - 1 } } else {

											var tag int32 = 0; var tmp10 int32
											tag = Lit_1816.IndexOf_I__I(int32(c)); tmp10 = tag; if tmp10 == -1 {
												panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1969, StrOfChar(c), Lit_1371))))
											}
											var tmp11 bool; var tmp12 bool; tmp12 = lastTag == -1; if !tmp12 { tmp12 = lastTag == tag }; tmp11 = tmp12; if tmp11 {
												lastTag = tag; count = count + 1 } else {

													SimpleDateFormat_Encode_I_I_StringBuilder__V(lastTag, count, compiledCode)
													tagcount = tagcount + 1
													prevTag = lastTag
													lastTag = tag
													count = 1 } } } }
	i = i + 1
//line :119:1
	continue L1 }; break L1
}






























































































	if inQuote { panic(Thrown(IllegalArgumentException_New_String(Lit_1970))) }
	if count == 0 { } else {
		SimpleDateFormat_Encode_I_I_StringBuilder__V(lastTag, count, compiledCode)
		tagcount = tagcount + 1
		prevTag = lastTag }
	var tmp13 bool; var tmp14 bool; tmp14 = tagcount == 1; if tmp14 { tmp14 = prevTag == 2 }; tmp13 = tmp14; t.F_forceStandaloneForm = tmp13
	var len__2 int32 = NN(compiledCode).Length__I(); var r *CharArray = NewCharArray(len__2); NN(compiledCode).GetChars_I_I_C1_I__V(0, len__2, r, 0); return r
}
func SimpleDateFormat_Encode_I_I_StringBuilder__V(tag, length int32, buffer *StringBuilder) { SimpleDateFormat_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = tag == 21; if tmp2 { tmp2 = length >= 4 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1971, StrOfInt(length))))) }
	if length < 255 {
		NN(buffer).Append_C__StringBuilder(uint16(tag<<8 | length)) } else {

			NN(buffer).Append_C__StringBuilder(uint16(tag<<8 | 255))
			NN(buffer).Append_C__StringBuilder(uint16(int32(uint32(length) >> 16)))
			NN(buffer).Append_C__StringBuilder(uint16(length & 65535))
		} }
func (t *SimpleDateFormat) InitializeDefaultCentury__V() {
	var tmp1 Calendar_I = t.F_calendar; tmp1.SetTimeInMillis_J__V(System_CurrentTimeMillis__J())
	t.F_calendar.Add_I_I__V(1, -80)
	t.ParseAmbiguousDatesAsAfter_Date__V(t.F_calendar.GetTime__Date())
}
func (t *SimpleDateFormat) ParseAmbiguousDatesAsAfter_Date__V(startDate Date_I) {
	t.F_defaultCenturyStart = startDate
	t.F_calendar.SetTime_Date__V(startDate)
	t.F_defaultCenturyStartYear = t.F_calendar.Get_I__I(1)
}
func (t *SimpleDateFormat) Set2DigitYearStart_Date__V(startDate Date_I) {
	t.ParseAmbiguousDatesAsAfter_Date__V(Date_New_J(startDate.GetTime__J()))
}
func (t *SimpleDateFormat) Get2DigitYearStart__Date() Date_I {
	return Date_Cast(t.F_defaultCenturyStart.Clone__O())
}
func (t *SimpleDateFormat) Format_Date_StringBuffer_FieldPosition__StringBuffer(date Date_I, toAppendTo *StringBuffer, pos FieldPosition_I) *StringBuffer {
	var tmp1 int32; var tmp2 int32 = 0; pos.Self_FieldPosition().F_endIndex = tmp2; tmp1 = tmp2; pos.Self_FieldPosition().F_beginIndex = tmp1
	return t.Format_Date_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(date, StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo), pos.GetFieldDelegate__Format_FieldDelegate()).AsStringBuffer__StringBuffer()
}
func (t *SimpleDateFormat) Format_Date_Format_StringBuf_FieldPosition__Format_StringBuf(date Date_I, toAppendTo Format_StringBuf, pos FieldPosition_I) Format_StringBuf {

	var tmp1 int32; var tmp2 int32 = 0; pos.Self_FieldPosition().F_endIndex = tmp2; tmp1 = tmp2; pos.Self_FieldPosition().F_beginIndex = tmp1
	return t.Format_Date_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(date, toAppendTo, pos.GetFieldDelegate__Format_FieldDelegate())
}
func (t *SimpleDateFormat) Format_Date_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(date Date_I, toAppendTo Format_StringBuf, delegate Format_FieldDelegate) Format_StringBuf {

	t.F_calendar.SetTime_Date__V(date)
	var useDateFormatSymbols bool = t.UseDateFormatSymbols__Z()
	var i int32 = 0
L1: for { if i < int32(len(t.F_compiledPattern.A)) {
	var tag int32 = int32(uint32(int32(t.F_compiledPattern.A[i])) >> 8); var count int32; var tmp1 *CharArray = t.F_compiledPattern; var tmp2 int32
	var old_1 int32 = i

	i = i + 1; tmp2 = old_1
//line :265:1
	count = int32(tmp1.A[tmp2]) & 255



	if count == 255 {
		count = int32(t.F_compiledPattern.A[i]) << 16
		i = i + 1
		count = count | int32(t.F_compiledPattern.A[i])
		i = i + 1 }
	switch tag { case 100:
		toAppendTo.Append_C__Format_StringBuf(uint16(count)); case 101:


		toAppendTo.Append_C1_I_I__Format_StringBuf(t.F_compiledPattern, i, count)
		i = i + count; default:
		t.SubFormat_I_I_Format_FieldDelegate_Format_StringBuf_Z__V(tag, count, delegate, toAppendTo, useDateFormatSymbols)}
//line :263:1
	continue L1 }; break L1 }
//line :261:1
	return toAppendTo
}




















func (t *SimpleDateFormat) FormatToCharacterIterator_O__AttributedCharacterIterator(obj any) AttributedCharacterIterator {
	var sb Format_StringBuf = StringBufFactory_Of__Format_StringBuf(); var delegate *CharacterIteratorFieldDelegate = CharacterIteratorFieldDelegate_New()

	if Date_InstanceOf(obj) {
		t.Format_Date_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(Date_Cast(obj), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate)) } else {
//line :286:1
			if Number_InstanceOf(obj) {

				t.Format_Date_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(Date_New_J(Number_Cast(obj).LongValue__J()), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate)) } else {
//line :286:1
					if obj == nil {



						panic(Thrown(NullPointerException_New_String(Lit_1737))) } else {
							panic(Thrown(IllegalArgumentException_New_String(Lit_1774))) } } }
	return NN(delegate).GetIterator_String__AttributedCharacterIterator(sb.ToString__String())
}














































































func (t *SimpleDateFormat) SubFormat_I_I_Format_FieldDelegate_Format_StringBuf_Z__V(patternCharIndex, count int32, delegate Format_FieldDelegate, buffer Format_StringBuf, useDateFormatSymbols bool) {


	var maxIntCount int32 = 2147483647; var current *String; var beginOffset int32 = buffer.Length__I(); var field int32 = SimpleDateFormat_PATTERN_INDEX_TO_CALENDAR_FIELD.A[patternCharIndex]
	var value int32 = 0



	if field == 17 {

		if t.F_calendar.IsWeekDateSupported__Z() {
			value = t.F_calendar.GetWeekYear__I() } else {

				patternCharIndex = 1
				field = SimpleDateFormat_PATTERN_INDEX_TO_CALENDAR_FIELD.A[patternCharIndex]
				value = t.F_calendar.Get_I__I(field) } } else {
//line :380:1
					if field == 1000 {








						value = CalendarBuilder_ToISODayOfWeek_I__I(t.F_calendar.Get_I__I(7)) } else {

							value = t.F_calendar.Get_I__I(field) } }
	var style int32; if count >= 4 { style = 2 } else { style = 1 }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !useDateFormatSymbols; if tmp3 { tmp3 = field < 15 }; tmp2 = tmp3; if tmp2 {
		tmp2 = !(patternCharIndex == 22) }
//line :393:1
	tmp1 = tmp2; if tmp1 {

		current = t.F_calendar.GetDisplayName_I_I_Locale__String(field, style, t.F_locale) }
	switch patternCharIndex { case 0:


		if useDateFormatSymbols {
			var eras *RefArray = NN(t.F_formatData).GetEras__String1()
			if value < int32(len(eras.A)) { current = As[*String](eras.A[value]) } }
		if current == nil { current = Lit_69 }; case 19, 1:

		if GregorianCalendar_InstanceOf(t.F_calendar) {

			if !(count == 2) {
				t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value, count, maxIntCount, buffer) } else {
					t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value, 2, 2, buffer) } } else {
//line :404:1
						if current == nil {





							var tmp4 int32 = value; var tmp5 int32

							if style == 2 { tmp5 = 1 } else { tmp5 = count }
//line :410:1
							t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(tmp4, tmp5, maxIntCount, buffer) } }
//line :408:1
	case 2:








		if useDateFormatSymbols {

			var months *RefArray
			if count >= 4 {

				months = NN(t.F_formatData).GetMonths__String1()
				current = As[*String](months.A[value]) } else {
					if count == 3 {
						months = NN(t.F_formatData).GetShortMonths__String1()
						current = As[*String](months.A[value]) } } } else {
//line :417:1
							if count < 3 {









								current = nil } else {

									if t.F_forceStandaloneForm {
										current = t.F_calendar.GetDisplayName_I_I_Locale__String(field, style|32768, t.F_locale)


										if current == nil {
											current = t.F_calendar.GetDisplayName_I_I_Locale__String(field, style, t.F_locale) } } } }
		if current == nil {
			t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value+1, count, maxIntCount, buffer) }; case 22:


		if !A2g_AssertionsDisabled && !(current == nil) { panic(Thrown(AssertionError_New())) }
		if t.F_locale == nil {

			var months_2 *RefArray
			if count >= 4 {

				months_2 = NN(t.F_formatData).GetMonths__String1()
				current = As[*String](months_2.A[value]) } else {
					if count == 3 {
						months_2 = NN(t.F_formatData).GetShortMonths__String1()
						current = As[*String](months_2.A[value]) } } } else {
//line :440:1
							if count >= 3 {










								current = t.F_calendar.GetDisplayName_I_I_Locale__String(field, style|32768, t.F_locale)
							} }
		if current == nil {
			t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value+1, count, maxIntCount, buffer) }; case 4:

		if current == nil {
			if value == 0 {
				t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(t.F_calendar.GetMaximum_I__I(11)+1, count, maxIntCount, buffer) } else {






					t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value, count, maxIntCount, buffer) } }; case 9:

		if useDateFormatSymbols {
			var weekdays *RefArray
			if count >= 4 {

				weekdays = NN(t.F_formatData).GetWeekdays__String1()
				current = As[*String](weekdays.A[value]) } else {

					weekdays = NN(t.F_formatData).GetShortWeekdays__String1()
					current = As[*String](weekdays.A[value]) } }; case 14:

		if useDateFormatSymbols {
			var ampm *RefArray = NN(t.F_formatData).GetAmPmStrings__String1(); current = As[*String](ampm.A[value]) }; case 15:

		if current == nil {
			if value == 0 {
				t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(t.F_calendar.GetLeastMaximum_I__I(10)+1, count, maxIntCount, buffer) } else {






					t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value, count, maxIntCount, buffer) } }; case 17:

		if current == nil {
			var tmp6 bool; var tmp7 bool; tmp7 = t.F_formatData.F_locale == nil; if !tmp7 { tmp7 = t.F_formatData.F_isZoneStringsSet }; tmp6 = tmp7; if tmp6 {
				var tmp8 *DateFormatSymbols = t.F_formatData; var zoneIndex int32 = NN(tmp8).GetZoneIndex_String__I(t.F_calendar.GetTimeZone__TimeZone().GetID__String())


				if zoneIndex == -1 {

					value = t.F_calendar.Get_I__I(15) + t.F_calendar.Get_I__I(16)



					buffer.Append_String__Format_StringBuf(ZoneInfoFile_ToCustomID_I__String(value)) } else {
						var index int32; if t.F_calendar.Get_I__I(16) == 0 { index = 1 } else { index = 3
						}





						if count < 4 { index = index + 1 }
						var zoneStrings *RefArray = NN(t.F_formatData).GetZoneStringsWrapper__String2()
						buffer.Append_String__Format_StringBuf(As[*String](As[*RefArray](zoneStrings.A[zoneIndex]).A[index])) } } else {
							var tz TimeZone_I = t.F_calendar.GetTimeZone__TimeZone(); var daylight bool = !(t.F_calendar.Get_I__I(16) == 0); var tzstyle int32

							if count < 4 { tzstyle = 0 } else { tzstyle = 1 }
							buffer.Append_String__Format_StringBuf(tz.GetDisplayName_Z_I_Locale__String(daylight, tzstyle, t.F_formatData.F_locale)) } }; case 18:


		value = (t.F_calendar.Get_I__I(15) + t.F_calendar.Get_I__I(16)) / 60000




		var width int32 = 4
		if value >= 0 { buffer.Append_C__Format_StringBuf(43) } else { width = width + 1 }
		var tmp9 int32 = value / 60 * 100; var num int32 = tmp9 + value%60


		if buffer.IsProxyStringBuilder__Z() {
			CalendarUtils_Sprintf0d_StringBuilder_I_I__StringBuilder(buffer.AsStringBuilder__StringBuilder(), num, width) } else {
				CalendarUtils_Sprintf0d_StringBuffer_I_I__StringBuffer(buffer.AsStringBuffer__StringBuffer(), num, width) }; case 21:


		value = t.F_calendar.Get_I__I(15) + t.F_calendar.Get_I__I(16)


		if value == 0 {
			buffer.Append_C__Format_StringBuf(90) } else {

				value = value / 60000
				if value >= 0 {
					buffer.Append_C__Format_StringBuf(43) } else {
						buffer.Append_C__Format_StringBuf(45); value = -value }
				if buffer.IsProxyStringBuilder__Z() {
					CalendarUtils_Sprintf0d_StringBuilder_I_I__StringBuilder(buffer.AsStringBuilder__StringBuilder(), value/60, 2) } else {



						CalendarUtils_Sprintf0d_StringBuffer_I_I__StringBuffer(buffer.AsStringBuffer__StringBuffer(), value/60, 2)
					}


				if count == 1 { } else {
					if count == 3 { buffer.Append_C__Format_StringBuf(58) }
					if buffer.IsProxyStringBuilder__Z() {
						CalendarUtils_Sprintf0d_StringBuilder_I_I__StringBuilder(buffer.AsStringBuilder__StringBuilder(), value%60, 2) } else {



							CalendarUtils_Sprintf0d_StringBuffer_I_I__StringBuffer(buffer.AsStringBuffer__StringBuffer(), value%60, 2) } } }; default:



		if current == nil { t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value, count, maxIntCount, buffer) }}
	if !(current == nil) { buffer.Append_String__Format_StringBuf(current) }
	var fieldID int32 = SimpleDateFormat_PATTERN_INDEX_TO_DATE_FORMAT_FIELD.A[patternCharIndex]; var f *DateFormat_Field = As[*DateFormat_Field](SimpleDateFormat_PATTERN_INDEX_TO_DATE_FORMAT_FIELD_ID.A[patternCharIndex])

	delegate.Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(fieldID, Up_DateFormat_Field_Format_Field(f), f.Ref(), beginOffset, buffer.Length__I(), buffer)
}
func (t *SimpleDateFormat) ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value, minDigits, maxDigits int32, buffer Format_StringBuf) { tmp14, tmp15, tmp16 := func() (ctl int32, rv bool, exc Throwable_I) { defer Catch(&exc)


	if int32(t.F_zeroDigit) == 0 {
		t.F_zeroDigit = NN(NN(DecimalFormat_Cast(t.F_numberFormat)).GetDecimalFormatSymbols__DecimalFormatSymbols()).GetZeroDigit__C()
	}
	if value >= 0 {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = value < 100; if tmp3 { tmp3 = minDigits >= 1 }; tmp2 = tmp3; if tmp2 { tmp2 = minDigits <= 2 }; tmp1 = tmp2; if tmp1 {

			if value < 10 {

				if minDigits == 2 { buffer.Append_C__Format_StringBuf(t.F_zeroDigit) }
				buffer.Append_C__Format_StringBuf(uint16(int32(t.F_zeroDigit) + value)) } else {

					var tmp4 int32 = int32(t.F_zeroDigit); buffer.Append_C__Format_StringBuf(uint16(tmp4 + value/10))


					var tmp5 int32 = int32(t.F_zeroDigit); buffer.Append_C__Format_StringBuf(uint16(tmp5 + value%10)) }; return 2, false, nil } else {



						var tmp6 bool; var tmp7 bool; tmp7 = value >= 1000; if tmp7 { tmp7 = value < 10000 }; tmp6 = tmp7; if tmp6 {
							if minDigits == 4 {
								var tmp8 int32 = int32(t.F_zeroDigit); buffer.Append_C__Format_StringBuf(uint16(tmp8 + value/1000))


								value = value % 1000
								var tmp9 int32 = int32(t.F_zeroDigit); buffer.Append_C__Format_StringBuf(uint16(tmp9 + value/100))


								value = value % 100
								var tmp10 int32 = int32(t.F_zeroDigit); buffer.Append_C__Format_StringBuf(uint16(tmp10 + value/10))


								var tmp11 int32 = int32(t.F_zeroDigit); buffer.Append_C__Format_StringBuf(uint16(tmp11 + value%10)); return 3, false, nil
							}


							var tmp12 bool; var tmp13 bool; tmp13 = minDigits == 2; if tmp13 { tmp13 = maxDigits == 2 }; tmp12 = tmp13; if tmp12 {
								t.ZeroPaddingNumber_I_I_I_Format_StringBuf__V(value%100, 2, 2, buffer); return 4, false, nil } } } }; return 0, false, nil }(); _ = tmp15; if /*line :572:1*/ tmp16 != nil { if Exception_InstanceOf(tmp16) { var e Exception_I = Exception_Cast(tmp16); _ = e } else { panic(tmp16) } }; switch tmp14 { case 2: { return }; case 3: { return }; case 4: { return }};







































	t.F_numberFormat.SetMinimumIntegerDigits_I__V(minDigits);
	t.F_numberFormat.SetMaximumIntegerDigits_I__V(maxDigits); if
	buffer.IsProxyStringBuilder__Z() {
		if Lit_1775.Equals_O__Z(NN(t.F_numberFormat.GetClass__Class()).GetPackageName__String().Ref()) {
			var tmp17 NumberFormat_I = t.F_numberFormat; var tmp18 int64 = int64(value); var tmp19 FieldPosition_I; DontCareFieldPosition_Init(); tmp19 = DontCareFieldPosition_INSTANCE; tmp17.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(tmp18, buffer, tmp19) } else {
				var tmp20 NumberFormat_I = t.F_numberFormat; var tmp21 int64 = int64(value); var tmp22 *StringBuffer = StringBuffer_New(); var tmp23 FieldPosition_I; DontCareFieldPosition_Init(); tmp23 = DontCareFieldPosition_INSTANCE; buffer.Append_StringBuffer__Format_StringBuf(tmp20.Format_J_StringBuffer_FieldPosition__StringBuffer(tmp21, tmp22, tmp23)) } } else {




					var tmp24 NumberFormat_I = t.F_numberFormat; var tmp25 int64 = int64(value); var tmp26 *StringBuffer = buffer.AsStringBuffer__StringBuffer(); var tmp27 FieldPosition_I; DontCareFieldPosition_Init(); tmp27 = DontCareFieldPosition_INSTANCE; tmp24.Format_J_StringBuffer_FieldPosition__StringBuffer(tmp25, tmp26, tmp27) } }




func (t *SimpleDateFormat) Parse_String_ParsePosition__Date(text *String, pos *ParsePosition) Date_I {
	t.CheckNegativeNumberExpression__V()
	var start int32 = pos.F_index; var oldStart int32 = start; var textLength int32 = NN(text).Length__I(); var ambiguousYear *BooleanArray = BooleanArrayOf(false); var calb *CalendarBuilder = CalendarBuilder_New()
	var i int32 = 0




L1: for { if i < int32(len(t.F_compiledPattern.A)) {
	var tag int32 = int32(uint32(int32(t.F_compiledPattern.A[i])) >> 8); var count int32; var tmp1 *CharArray = t.F_compiledPattern; var tmp2 int32
	var old_2 int32 = i

	i = i + 1; tmp2 = old_2
//line :637:1
	count = int32(tmp1.A[tmp2]) & 255



	if count == 255 {
		count = int32(t.F_compiledPattern.A[i]) << 16
		i = i + 1
		count = count | int32(t.F_compiledPattern.A[i])
		i = i + 1 }
	switch tag { case 100:


		var tmp6 bool; var tmp7 bool; tmp7 = start >= textLength; if !tmp7 {
			tmp7 = !t.CharEquals_C_C__Z(NN(text).CharAt_I__C(start), uint16(count)) }
//line :649:1
		tmp6 = tmp7; if tmp6 {

			pos.F_index = oldStart
			pos.F_errorIndex = start
			return nil }
		start = start + 1; case 101:

	L2: for { var tmp8 int32; var old_3 int32 = count; count = count - 1; tmp8 = old_3; if tmp8 > 0 {
		var tmp9 bool; var tmp10 bool; tmp10 = start >= textLength; if !tmp10 {
			var tmp11 uint16 = NN(text).CharAt_I__C(start); var tmp12 *CharArray = t.F_compiledPattern; var tmp13 int32
			var old_4 int32 = i


			i = i + 1; tmp13 = old_4
//line :658:1
			tmp10 = !t.CharEquals_C_C__Z(tmp11, tmp12.A[tmp13]) }
//line :657:1
		tmp9 = tmp10; if tmp9 {





			pos.F_index = oldStart
			pos.F_errorIndex = start
			return nil }
		start = start + 1
//line :656:1
		continue L2 }; break L2
	}








	default:
		var obeyCount bool = false
		var useFollowingMinusSignAsDelimiter bool = false
		if i < int32(len(t.F_compiledPattern.A)) {
			var nextTag int32 = int32(uint32(int32(t.F_compiledPattern.A[i])) >> 8); var nextCount int32 = int32(t.F_compiledPattern.A[i]) & 255

			obeyCount = t.ShouldObeyCount_I_I__Z(nextTag, nextCount)
			var tmp3 bool; var tmp4 bool; tmp4 = t.F_hasFollowingMinusSign; if tmp4 {
				var tmp5 bool; tmp5 = nextTag == 100; if !tmp5 { tmp5 = nextTag == 101 }; tmp4 = tmp5 }
//line :673:1
			tmp3 = tmp4; if tmp3 {

				if nextTag == 100 { } else {
					nextCount = int32(t.F_compiledPattern.A[i+1]) }
				if nextCount == int32(t.F_minusSign) { useFollowingMinusSignAsDelimiter = true } } }
		start = t.SubParse_String_I_I_I_Z_Z1_ParsePosition_Z_CalendarBuilder__I(text, start, tag, count, obeyCount, ambiguousYear, pos, useFollowingMinusSignAsDelimiter, calb)










		if start < 0 { pos.F_index = oldStart; return nil }}
//line :635:1
	continue L1 }; break L1
}





















































	pos.F_index = start
	var parsedDate Date_I; tmp14 := func() (exc Throwable_I) { defer Catch(&exc)

		parsedDate = NN(calb).Establish_Calendar__Calendar(t.F_calendar).GetTime__Date()
		if ambiguousYear.A[0] {
			if parsedDate.Before_Date__Z(t.F_defaultCenturyStart) {
				parsedDate = NN(NN(calb).AddYear_I__CalendarBuilder(100)).Establish_Calendar__Calendar(t.F_calendar).GetTime__Date() } }; return nil }()
//line :692:1
	if tmp14 != nil { if IllegalArgumentException_InstanceOf(tmp14) { var e IllegalArgumentException_I = IllegalArgumentException_Cast(tmp14); _ = e





		pos.F_errorIndex = start
		pos.F_index = oldStart
		return nil } else {
//line :692:1
			panic(tmp14) } }
//line :691:1
	return parsedDate
}










func (t *SimpleDateFormat) CharEquals_C_C__Z(ch1, ch2 uint16) bool {
	var tmp1 bool; tmp1 = int32(ch1) == int32(ch2); if !tmp1 {
		var tmp2 bool; var tmp3 bool; tmp3 = t.IsLenient__Z(); if tmp3 { tmp3 = Character_GetType_C__I(ch1) == 12 }; tmp2 = tmp3; if tmp2 {
			tmp2 = Character_GetType_C__I(ch2) == 12 }
//line :705:1
		tmp1 = tmp2 }
//line :704:1
	return tmp1
}


func (t *SimpleDateFormat) ShouldObeyCount_I_I__Z(tag, count int32) bool {
	switch tag { case 2, 22:
		return count <= 2; case 1, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 15, 16, 19, 20:
//line :709:1
		return true
	default:
//line :709:1
		return false}
	panic("a2g: unreachable")
}
















func (t *SimpleDateFormat) MatchString_String_I_I_String1_CalendarBuilder__I(text *String, start, field int32, data *RefArray, calb *CalendarBuilder) int32 {

	var i int32 = 0; var count int32 = int32(len(data.A))

	if field == 7 { i = 1 }
	var bestMatchLength int32 = 0
	var bestMatch int32 = -1
L1: for { if i < count {
	var length int32 = NN(As[*String](data.A[i])).Length__I(); var tmp1 bool; var tmp2 bool
	tmp2 = length > bestMatchLength; if tmp2 {
		tmp2 = NN(text).RegionMatches_Z_I_String_I_I__Z(true, start, As[*String](data.A[i]), 0, length) }
//line :737:1
	tmp1 = tmp2; if tmp1 {

		bestMatch = i
		bestMatchLength = length }
	i = i + 1
//line :735:1
	continue L1 }; break L1
}





	if bestMatch >= 0 {
		NN(calb).Set_I_I__CalendarBuilder(field, bestMatch); return start + bestMatchLength } else {
			return -start
		} }
func (t *SimpleDateFormat) MatchString_String_I_I_Map_CalendarBuilder__I(text *String, start, field int32, data Map, calb *CalendarBuilder) int32 {

	if !(data == nil) {
		if SortedMap_InstanceOf(data) {
			var i_101388 Iterator = data.KeySet__Set().Iterator__Iterator(); for i_101388.HasNext__Z() { var name *String = String_Cast(i_101388.Next__O())
				if NN(text).RegionMatches_Z_I_String_I_I__Z(true, start, name, 0, NN(name).Length__I()) {
					NN(calb).Set_I_I__CalendarBuilder(field, NN(Integer_Cast(data.Get_O__O(name.Ref()))).IntValue__I())
					return start + NN(name).Length__I() } }
			return -start }
		var bestMatch *String; var i_101389 Iterator = data.KeySet__Set().Iterator__Iterator(); for i_101389.HasNext__Z() {
			var name_2 *String = String_Cast(i_101389.Next__O()); var length int32 = NN(name_2).Length__I(); var tmp1 bool; var tmp2 bool

			tmp2 = bestMatch == nil; if !tmp2 { tmp2 = length > NN(bestMatch).Length__I() }; tmp1 = tmp2; if tmp1 {
				if NN(text).RegionMatches_Z_I_String_I_I__Z(true, start, name_2, 0, length) { bestMatch = name_2 } } }
		if !(bestMatch == nil) {
			NN(calb).Set_I_I__CalendarBuilder(field, NN(Integer_Cast(data.Get_O__O(bestMatch.Ref()))).IntValue__I())
			return start + NN(bestMatch).Length__I() } }
	return -start
}
func (t *SimpleDateFormat) MatchZoneString_String_I_String1__I(text *String, start int32, zoneNames *RefArray) int32 {
	var i int32 = 1; L1: for {
		if i <= 4 {
			var zoneName *String = As[*String](zoneNames.A[i])
			if NN(zoneName).IsEmpty__Z() {
				var tmp1 *String = As[*String](zoneNames.A[0]); zoneName = TimeZoneNameUtility_RetrieveDisplayName_String_Z_I_Locale__String(tmp1, i >= 3, i%2, t.F_locale)





				zoneNames.Store(i, zoneName.Ref()) }
			if NN(text).RegionMatches_Z_I_String_I_I__Z(true, start, zoneName, 0, NN(zoneName).Length__I()) {
				return i } else {
					i = i + 1; continue L1 } }
//line :766:1
		break L1 }
//line :765:1
	return -1
}















func (t *SimpleDateFormat) MatchDSTString_String_I_I_I_String2__Z(p0 *String, p1, p2, p3 int32, p4 *RefArray) bool { panic(A2g_NotTranslated("java.text.SimpleDateFormat.matchDSTString(Ljava/lang/String;III[[Ljava/lang/String;)Z")) }





func (t *SimpleDateFormat) SubParseZoneString_String_I_CalendarBuilder__I(text *String, start int32, calb *CalendarBuilder) int32 {
	var useSameName bool = false; var currentTimeZone TimeZone_I = t.GetTimeZone__TimeZone(); var tmp1 *DateFormatSymbols = t.F_formatData; var zoneIndex int32 = NN(tmp1).GetZoneIndex_String__I(currentTimeZone.GetID__String()); var tz TimeZone_I; var zoneStrings *RefArray = NN(t.F_formatData).GetZoneStringsWrapper__String2(); var zoneNames *RefArray
	var nameIndex int32 = 0





	if zoneIndex == -1 { } else {
		zoneNames = As[*RefArray](zoneStrings.A[zoneIndex])
		var tmp2 int32; nameIndex = t.MatchZoneString_String_I_String1__I(text, start, zoneNames); tmp2 = nameIndex; if tmp2 > 0 {
			if nameIndex <= 2 {
				var tmp3 *String = As[*String](zoneNames.A[nameIndex]); useSameName = NN(tmp3).EqualsIgnoreCase_String__Z(As[*String](zoneNames.A[nameIndex+2]))
			}

			tz = TimeZone_GetTimeZone_String__TimeZone(As[*String](zoneNames.A[0])) } }
	if tz == nil {
		var tmp4 *DateFormatSymbols = t.F_formatData; zoneIndex = NN(tmp4).GetZoneIndex_String__I(TimeZone_GetDefault__TimeZone().GetID__String())
		if zoneIndex == -1 { } else {
			zoneNames = As[*RefArray](zoneStrings.A[zoneIndex])
			var tmp5 int32; nameIndex = t.MatchZoneString_String_I_String1__I(text, start, zoneNames); tmp5 = nameIndex; if tmp5 > 0 {
				if nameIndex <= 2 {
					var tmp6 *String = As[*String](zoneNames.A[nameIndex]); useSameName = NN(tmp6).EqualsIgnoreCase_String__Z(As[*String](zoneNames.A[nameIndex+2]))
				}

				tz = TimeZone_GetTimeZone_String__TimeZone(As[*String](zoneNames.A[0])) } } }
	if tz == nil {
		var len_ int32 = int32(len(zoneStrings.A)); var i int32 = 0
	L1: for {
		if i < len_ {
			zoneNames = As[*RefArray](zoneStrings.A[i])
			var tmp7 int32; nameIndex = t.MatchZoneString_String_I_String1__I(text, start, zoneNames); tmp7 = nameIndex; if tmp7 > 0 {

				if nameIndex <= 2 {
					var tmp8 *String = As[*String](zoneNames.A[nameIndex]); useSameName = NN(tmp8).EqualsIgnoreCase_String__Z(As[*String](zoneNames.A[nameIndex+2]))
				}

				tz = TimeZone_GetTimeZone_String__TimeZone(As[*String](zoneNames.A[0])) } else {
					i = i + 1; continue L1 } }
//line :816:1
		break L1
	}
	}








	if !(tz == nil) {

		if tz.Equals_O__Z(currentTimeZone) { } else { t.SetTimeZone_TimeZone__V(tz) }
		var dstAmount int32; if nameIndex >= 3 { dstAmount = tz.GetDSTSavings__I() } else { dstAmount = 0 }
		var tmp9 bool; var tmp10 bool; tmp10 = useSameName; if !tmp10 { var tmp11 bool; tmp11 = nameIndex >= 3; if tmp11 { tmp11 = dstAmount == 0 }; tmp10 = tmp11 }; tmp9 = tmp10; if tmp9 { } else {
			NN(NN(calb).Clear_I__CalendarBuilder(15)).Set_I_I__CalendarBuilder(16, dstAmount) }
		return start + NN(As[*String](zoneNames.A[nameIndex])).Length__I() } else {
			return -start
		} }
func (t *SimpleDateFormat) SubParseNumericZone_String_I_I_I_Z_CalendarBuilder__I(text *String, start, sign, count int32, colon bool, calb *CalendarBuilder) int32 {

	var index int32 = start
L1: switch { default: tmp4, tmp5, tmp6 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc)

	{ var c uint16; var tmp1 int32
		var old_5 int32 = index
		index = index + 1
//line :842:1
		tmp1 = old_5
//line :841:1
		c = NN(text).CharAt_I__C(tmp1); var hours int32 = 0




		if !t.IsDigit_C__Z(c) { } else {
			hours = int32(c) - 48
			c = NN(text).CharAt_I__C(index)
			index = index + 1
			if t.IsDigit_C__Z(c) {
				hours = hours*10 + (int32(c) - 48) } else {



					var tmp2 bool; var tmp3 bool; tmp3 = count > 0; if !tmp3 { tmp3 = !colon }; tmp2 = tmp3; if tmp2 { return 2, 0, nil }
					index = index - 1 }
			if hours > 23 { } else {
				var minutes int32 = 0
				if count == 1 { } else {
					c = NN(text).CharAt_I__C(index)
					index = index + 1
					if colon {
						if int32(c) == 58 { } else { return 3, 0, nil }
						c = NN(text).CharAt_I__C(index)
						index = index + 1 }
					if t.IsDigit_C__Z(c) { } else { return 4, 0, nil }
					minutes = int32(c) - 48
					c = NN(text).CharAt_I__C(index)
					index = index + 1
					if t.IsDigit_C__Z(c) { } else { return 5, 0, nil }
					minutes = minutes*10 + (int32(c) - 48)


					if minutes > 59 { return 6, 0, nil } }
				minutes = minutes + hours*60
				NN(NN(calb).Set_I_I__CalendarBuilder(15, minutes*60000*sign)).Set_I_I__CalendarBuilder(16, 0)
//line :858:1
				return 7, index, nil } } }
//line :843:1
	return 0, 0, nil }()
//line :840:1
	if tmp6 != nil { if IndexOutOfBoundsException_InstanceOf(tmp6) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp6); _ = e } else { panic(tmp6) } }; switch tmp4 { case 2: { break L1 }; case 3: { break L1 }; case 4: { break L1 }; case 5: { break L1 }; case 6: { break L1 }; case 7: { return tmp5
	}
	}
}









































	return 1 - index
}
func (t *SimpleDateFormat) IsDigit_C__Z(c uint16) bool {
	var tmp1 bool; tmp1 = int32(c) >= 48; if tmp1 { tmp1 = int32(c) <= 57 }; return tmp1
}
func (t *SimpleDateFormat) SubParse_String_I_I_I_Z_Z1_ParsePosition_Z_CalendarBuilder__I(text *String, start, patternCharIndex, count int32, obeyCount bool, ambiguousYear *BooleanArray, origPos *ParsePosition, useFollowingMinusSignAsDelimiter bool, calb *CalendarBuilder) int32 {



	var number Number_I; var value int32 = 0; var pos *ParsePosition = ParsePosition_New_I(0)


	pos.F_index = start
	var tmp1 bool; var tmp2 bool; tmp2 = patternCharIndex == 19; if tmp2 {
		tmp2 = !t.F_calendar.IsWeekDateSupported__Z() }
//line :898:1
	tmp1 = tmp2; if tmp1 {

		patternCharIndex = 1 }
	var field int32 = SimpleDateFormat_PATTERN_INDEX_TO_CALENDAR_FIELD.A[patternCharIndex]
L1: for {
	var tmp3 int32 = pos.F_index; if tmp3 >= NN(text).Length__I() { origPos.F_errorIndex = start; return -1 }
	var c uint16 = NN(text).CharAt_I__C(pos.F_index); var tmp4 bool; var tmp5 bool
	tmp5 = !(int32(c) == 32); if tmp5 { tmp5 = !(int32(c) == 9) }; tmp4 = tmp5; if tmp4 { break L1 }
	pos.F_index = pos.F_index + 1
//line :902:1
	continue L1
}



	var actualStart int32 = pos.F_index
L2: switch { default:
	var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = patternCharIndex == 4; if !tmp11 {
		tmp11 = patternCharIndex == 15 }
//line :909:1
	tmp10 = tmp11; if !tmp10 {

		var tmp12 bool; tmp12 = patternCharIndex == 2; if tmp12 {
			tmp12 = count <= 2 }
//line :911:1
		tmp10 = tmp12 }
//line :909:1
	tmp9 = tmp10; if !tmp9 {



		var tmp13 bool; tmp13 = patternCharIndex == 22; if tmp13 {
			tmp13 = count <= 2 }
//line :913:1
		tmp9 = tmp13 }
//line :909:1
	tmp8 = tmp9; if !tmp8 {





		tmp8 = patternCharIndex == 1 }
//line :909:1
	tmp7 = tmp8; if !tmp7 {






		tmp7 = patternCharIndex == 19 }
//line :909:1
	tmp6 = tmp7; if tmp6 {







		if obeyCount {

			if start+count > NN(text).Length__I() { break L2 }
			var tmp14 NumberFormat_I = t.F_numberFormat; number = tmp14.Parse_String_ParsePosition__Number(NN(text).Substring_I_I__String(0, start+count), pos) } else {



				number = t.F_numberFormat.Parse_String_ParsePosition__Number(text, pos) }
		if number == nil {
			var tmp15 bool; var tmp16 bool; tmp16 = !(patternCharIndex == 1); if !tmp16 {
				tmp16 = GregorianCalendar_InstanceOf(t.F_calendar) }
//line :926:1
			tmp15 = tmp16; if tmp15 {

				break L2 } } else {

					value = number.IntValue__I()
					var tmp17 bool; var tmp18 bool; var tmp19 bool; tmp19 = useFollowingMinusSignAsDelimiter; if tmp19 { tmp19 = value < 0 }; tmp18 = tmp19; if tmp18 {
						var tmp20 bool; var tmp21 bool; var tmp22 int32 = pos.F_index; tmp21 = tmp22 < NN(text).Length__I(); if tmp21 {
							tmp21 = !(int32(NN(text).CharAt_I__C(pos.F_index)) == int32(t.F_minusSign)) }
//line :932:1
						tmp20 = tmp21; if !tmp20 {

							var tmp23 bool; var tmp24 int32 = pos.F_index; tmp23 = tmp24 == NN(text).Length__I(); if tmp23 {
								tmp23 = int32(NN(text).CharAt_I__C(pos.F_index-1)) == int32(t.F_minusSign) }
//line :934:1
							tmp20 = tmp23 }
//line :932:1
						tmp18 = tmp20 }
//line :931:1
					tmp17 = tmp18; if tmp17 {





						value = -value
						pos.F_index = pos.F_index - 1 } } }
	var useDateFormatSymbols bool = t.UseDateFormatSymbols__Z()
	var index int32 = 0
	switch patternCharIndex { case 0:

		if useDateFormatSymbols {
			var tmp34 int32; index = t.MatchString_String_I_I_String1_CalendarBuilder__I(text, start, 0, NN(t.F_formatData).GetEras__String1(), calb); tmp34 = index; if tmp34 > 0 {








				return index } } else {
					var map_ Map = t.GetDisplayNamesMap_I_Locale__Map(field, t.F_locale); var tmp35 int32
					index = t.MatchString_String_I_I_Map_CalendarBuilder__I(text, start, field, map_, calb); tmp35 = index; if tmp35 > 0 {
						return index } }; case 19, 1:


		if GregorianCalendar_InstanceOf(t.F_calendar) { } else {
			var style int32; if count >= 4 { style = 2 } else { style = 1 }; var map__2 Map = t.F_calendar.GetDisplayNames_I_I_Locale__Map(field, style, t.F_locale)





			if !(map__2 == nil) {
				var tmp36 int32; index = t.MatchString_String_I_I_Map_CalendarBuilder__I(text, start, field, map__2, calb); tmp36 = index; if tmp36 > 0 {
					return index } }
			NN(calb).Set_I_I__CalendarBuilder(field, value)
			return pos.F_index }
		var tmp37 bool; var tmp38 bool; var tmp39 bool; var tmp40 bool; tmp40 = count <= 2; if tmp40 {
			tmp40 = pos.F_index-actualStart == 2 }
//line :971:1
		tmp39 = tmp40; if tmp39 {

			tmp39 = Character_IsDigit_C__Z(NN(text).CharAt_I__C(actualStart)) }
//line :971:1
		tmp38 = tmp39; if tmp38 {


			tmp38 = Character_IsDigit_C__Z(NN(text).CharAt_I__C(actualStart + 1)) }
//line :971:1
		tmp37 = tmp38; if tmp37 {



			var ambiguousTwoDigitYear int32 = t.F_defaultCenturyStartYear % 100


			ambiguousYear.A[0] = value == ambiguousTwoDigitYear
			var tmp41 int32 = value; var tmp42 int32 = t.F_defaultCenturyStartYear / 100 * 100; var tmp43 int32






			if value < ambiguousTwoDigitYear { tmp43 = 100 } else { tmp43 = 0 }
//line :979:1
			value = tmp41 + (tmp42 + tmp43)
		}






		NN(calb).Set_I_I__CalendarBuilder(field, value)
		return pos.F_index; case 2:


		if count <= 2 {
			NN(calb).Set_I_I__CalendarBuilder(2, value-1)
			return pos.F_index }
		if useDateFormatSymbols {
			var newStart int32 = 0; var tmp44 int32
			newStart = t.MatchString_String_I_I_String1_CalendarBuilder__I(text, start, 2, NN(t.F_formatData).GetMonths__String1(), calb); tmp44 = newStart; if tmp44 > 0 {








				return newStart }
			var tmp45 int32; index = t.MatchString_String_I_I_String1_CalendarBuilder__I(text, start, 2, NN(t.F_formatData).GetShortMonths__String1(), calb); tmp45 = index; if tmp45 > 0 {








				return index } } else {
					var map__3 Map = t.GetDisplayContextNamesMap_I_Locale__Map(field, t.F_locale); var tmp46 int32



					index = t.MatchString_String_I_I_Map_CalendarBuilder__I(text, start, field, map__3, calb); tmp46 = index; if tmp46 > 0 {
						return index } }; case 22:


		if count <= 2 {
			NN(calb).Set_I_I__CalendarBuilder(2, value-1)
			return pos.F_index }
		var maps Map = t.GetDisplayNamesMap_I_Locale__Map(field, t.F_locale); var tmp47 int32
		index = t.MatchString_String_I_I_Map_CalendarBuilder__I(text, start, field, maps, calb); tmp47 = index; if tmp47 > 0 {
			return index }; case 4:


		if t.IsLenient__Z() { } else {
			var tmp48 bool; var tmp49 bool; tmp49 = value < 1; if !tmp49 { tmp49 = value > 24 }; tmp48 = tmp49; if tmp48 { break L2 } }
		if value == t.F_calendar.GetMaximum_I__I(11)+1 {



			value = 0 }
		NN(calb).Set_I_I__CalendarBuilder(11, value)
		return pos.F_index; case 9:

		if useDateFormatSymbols {
			var newStart_2 int32 = 0; var tmp50 int32
			newStart_2 = t.MatchString_String_I_I_String1_CalendarBuilder__I(text, start, 7, NN(t.F_formatData).GetWeekdays__String1(), calb); tmp50 = newStart_2; if tmp50 > 0 {








				return newStart_2 }
			var tmp51 int32; index = t.MatchString_String_I_I_String1_CalendarBuilder__I(text, start, 7, NN(t.F_formatData).GetShortWeekdays__String1(), calb); tmp51 = index; if tmp51 > 0 {








				return index } } else {
					var styles *IntArray = IntArrayOf(2, 1); var arr_101390 *IntArray = styles; var len_101391 int32 = int32(len(arr_101390.A)); var i_101392 int32 = 0; for ; i_101392 < len_101391; i_101392++ {
						var style_2 int32 = arr_101390.A[i_101392]; var map__4 Map = t.F_calendar.GetDisplayNames_I_I_Locale__Map(field, style_2, t.F_locale); var tmp52 int32





						index = t.MatchString_String_I_I_Map_CalendarBuilder__I(text, start, field, map__4, calb); tmp52 = index; if tmp52 > 0 {
							return index } } }; case 14:

		if useDateFormatSymbols {
			var tmp53 int32; index = t.MatchString_String_I_I_String1_CalendarBuilder__I(text, start, 9, NN(t.F_formatData).GetAmPmStrings__String1(), calb); tmp53 = index; if tmp53 > 0 {








				return index } } else {
					var map__5 Map = t.GetDisplayNamesMap_I_Locale__Map(field, t.F_locale); var tmp54 int32
					index = t.MatchString_String_I_I_Map_CalendarBuilder__I(text, start, field, map__5, calb); tmp54 = index; if tmp54 > 0 {
						return index } }; case 15:


		if t.IsLenient__Z() { } else {
			var tmp55 bool; var tmp56 bool; tmp56 = value < 1; if !tmp56 { tmp56 = value > 12 }; tmp55 = tmp56; if tmp55 { break L2 } }
		if value == t.F_calendar.GetLeastMaximum_I__I(10)+1 {



			value = 0 }
		NN(calb).Set_I_I__CalendarBuilder(10, value)
		return pos.F_index; case 17, 18:

		var sign int32 = 0; tmp65, tmp66, tmp67 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc)

			{ var c_2 uint16 = NN(text).CharAt_I__C(pos.F_index)
				if int32(c_2) == 43 { sign = 1 } else { if int32(c_2) == 45 { sign = -1 } }
				if sign == 0 {
					var tmp57 bool; var tmp58 bool; var tmp59 bool; var tmp60 bool; tmp60 = int32(c_2) == 71; if !tmp60 { tmp60 = int32(c_2) == 103 }; tmp59 = tmp60; if tmp59 {
						tmp59 = NN(text).Length__I()-start >= Lit_1972.Length__I() }
//line :1105:1
					tmp58 = tmp59; if tmp58 {


						tmp58 = NN(text).RegionMatches_Z_I_String_I_I__Z(true, start, Lit_1972, 0, Lit_1972.Length__I()) }
//line :1105:1
					tmp57 = tmp58; if tmp57 {




						pos.F_index = start + Lit_1972.Length__I()
						if NN(text).Length__I()-pos.F_index > 0 {
							c_2 = NN(text).CharAt_I__C(pos.F_index)
							if int32(c_2) == 43 { sign = 1 } else { if int32(c_2) == 45 { sign = -1 } } }
						if sign == 0 {
							NN(NN(calb).Set_I_I__CalendarBuilder(15, 0)).Set_I_I__CalendarBuilder(16, 0)
//line :1114:1
							return 2, pos.F_index, nil
						}

						var i int32; var tmp61 int32; var tmp62 int32 = pos.F_index + 1


						pos.F_index = tmp62; tmp61 = tmp62
//line :1117:1
						i = t.SubParseNumericZone_String_I_I_I_Z_CalendarBuilder__I(text, tmp61, sign, 0, true, calb)







						if i > 0 { return 3, i, nil }
						pos.F_index = -i } else {
							var i_2 int32 = t.SubParseZoneString_String_I_CalendarBuilder__I(text, pos.F_index, calb)
							if i_2 > 0 { return 4, i_2, nil }
							pos.F_index = -i_2 } } else {
								var i_3 int32; var tmp63 int32; var tmp64 int32 = pos.F_index + 1


								pos.F_index = tmp64; tmp63 = tmp64
//line :1130:1
								i_3 = t.SubParseNumericZone_String_I_I_I_Z_CalendarBuilder__I(text, tmp63, sign, 0, false, calb)







								if i_3 > 0 { return 5, i_3, nil }
								pos.F_index = -i_3 } }; return 0, 0, nil }()
//line :1101:1
		if tmp67 != nil { if IndexOutOfBoundsException_InstanceOf(tmp67) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp67); _ = e } else { panic(tmp67) } }; switch tmp65 { case 2: { return tmp66 }; case 3: { return tmp66 }; case 4: { return tmp66 }; case 5: { return tmp66
		}
		}



































	case 21:



		if NN(text).Length__I()-pos.F_index <= 0 {
			break L2 }
		var sign_2 int32 = 0; var c_3 uint16 = NN(text).CharAt_I__C(pos.F_index)

		if int32(c_3) == 90 {
			NN(NN(calb).Set_I_I__CalendarBuilder(15, 0)).Set_I_I__CalendarBuilder(16, 0)
			var tmp68 int32; var tmp69 int32 = pos.F_index + 1; pos.F_index = tmp69; tmp68 = tmp69; return tmp68 }
		if int32(c_3) == 43 {
			sign_2 = 1 } else {
//line :1150:1
				if int32(c_3) == 45 {

					sign_2 = -1 } else {


						pos.F_index = pos.F_index + 1
						break L2 } }
		var i_4 int32; var tmp70 int32; var tmp71 int32 = pos.F_index + 1


		pos.F_index = tmp71; tmp70 = tmp71
//line :1157:1
		i_4 = t.SubParseNumericZone_String_I_I_I_Z_CalendarBuilder__I(text, tmp70, sign_2, count, count == 3, calb)







		if i_4 > 0 { return i_4 }
		pos.F_index = -i_4; default:

		if obeyCount {

			if start+count > NN(text).Length__I() { break L2 }
			var tmp25 NumberFormat_I = t.F_numberFormat; number = tmp25.Parse_String_ParsePosition__Number(NN(text).Substring_I_I__String(0, start+count), pos) } else {



				number = t.F_numberFormat.Parse_String_ParsePosition__Number(text, pos) }
		if !(number == nil) {
			value = number.IntValue__I()
			var tmp26 bool; var tmp27 bool; var tmp28 bool; tmp28 = useFollowingMinusSignAsDelimiter; if tmp28 { tmp28 = value < 0 }; tmp27 = tmp28; if tmp27 {
				var tmp29 bool; var tmp30 bool; var tmp31 int32 = pos.F_index; tmp30 = tmp31 < NN(text).Length__I(); if tmp30 {
					tmp30 = !(int32(NN(text).CharAt_I__C(pos.F_index)) == int32(t.F_minusSign)) }
//line :1179:1
				tmp29 = tmp30; if !tmp29 {

					var tmp32 bool; var tmp33 int32 = pos.F_index; tmp32 = tmp33 == NN(text).Length__I(); if tmp32 {
						tmp32 = int32(NN(text).CharAt_I__C(pos.F_index-1)) == int32(t.F_minusSign) }
//line :1181:1
					tmp29 = tmp32 }
//line :1179:1
				tmp27 = tmp29 }
//line :1178:1
			tmp26 = tmp27; if tmp26 {





				value = -value
				pos.F_index = pos.F_index - 1 }
			NN(calb).Set_I_I__CalendarBuilder(field, value)
			return pos.F_index }}}
	origPos.F_errorIndex = pos.F_index
//line :907:1
	return -1
}


























































































































































































































































































func (t *SimpleDateFormat) UseDateFormatSymbols__Z() bool {
	var tmp1 bool; tmp1 = t.F_useDateFormatSymbols; if !tmp1 { tmp1 = t.F_locale == nil }; return tmp1
}
func (t *SimpleDateFormat) TranslatePattern_String_String_String__String(pattern, from, to *String) *String {
	var result *StringBuilder = StringBuilder_New()
	var inQuote bool = false; var i int32 = 0
L1: for {
	if i < NN(pattern).Length__I() {
		var c uint16 = NN(pattern).CharAt_I__C(i)
		if inQuote {
			if int32(c) == 39 { inQuote = false } } else {
//line :1200:1
				if int32(c) == 39 {

					inQuote = true } else {
//line :1200:1
						var tmp1 bool; var tmp2 bool; var tmp3 bool


						tmp3 = int32(c) >= 97; if tmp3 { tmp3 = int32(c) <= 122 }; tmp2 = tmp3; if !tmp2 { var tmp4 bool; tmp4 = int32(c) >= 65; if tmp4 { tmp4 = int32(c) <= 90 }; tmp2 = tmp4 }; tmp1 = tmp2
//line :1200:1
						if tmp1 {



							var ci int32 = NN(from).IndexOf_I__I(int32(c))
							if ci >= 0 {
								if ci < NN(to).Length__I() { c = NN(to).CharAt_I__C(ci) } } else {
									panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1973, StrOfChar(c), Lit_1371))))
								} } } }
		NN(result).Append_C__StringBuilder(c)
		i = i + 1; continue L1 }
//line :1197:1
	break L1
}












	if inQuote { panic(Thrown(IllegalArgumentException_New_String(Lit_1974))) }
	return NN(result).ToString__String()
}
func (t *SimpleDateFormat) ToPattern__String() *String { return t.F_pattern }

func (t *SimpleDateFormat) ToLocalizedPattern__String() *String {
	var tmp1 *String = t.F_pattern; return t.TranslatePattern_String_String_String__String(tmp1, Lit_1816, NN(t.F_formatData).GetLocalPatternChars__String())
}



func (t *SimpleDateFormat) ApplyPattern_String__V(pattern *String) {
	t.ApplyPatternImpl_String__V(pattern)
}
func (t *SimpleDateFormat) ApplyPatternImpl_String__V(pattern *String) {
	t.F_compiledPattern = t.Compile_String__C1(pattern)
	t.F_pattern = pattern
}
func (t *SimpleDateFormat) ApplyLocalizedPattern_String__V(pattern *String) {
	var p *String = t.TranslatePattern_String_String_String__String(pattern, NN(t.F_formatData).GetLocalPatternChars__String(), Lit_1816)



	t.F_compiledPattern = t.Compile_String__C1(p)
	t.F_pattern = p
}
func (t *SimpleDateFormat) GetDateFormatSymbols__DateFormatSymbols() *DateFormatSymbols {
	return DateFormatSymbols_Cast(NN(t.F_formatData).Clone__O())
}
func (t *SimpleDateFormat) SetDateFormatSymbols_DateFormatSymbols__V(newFormatSymbols *DateFormatSymbols) {
	t.F_formatData = DateFormatSymbols_Cast(NN(newFormatSymbols).Clone__O())
	t.F_useDateFormatSymbols = true
}
func (t *SimpleDateFormat) Clone__O() any {
	var other *SimpleDateFormat = SimpleDateFormat_Cast(t.DateFormat.Impl_Clone__O(t))
	other.F_formatData = DateFormatSymbols_Cast(NN(t.F_formatData).Clone__O())
//line :1245:1
	return other.Ref()
}


func (t *SimpleDateFormat) HashCode__I() int32 { return NN(t.F_pattern).HashCode__I() }

func (t *SimpleDateFormat) ToString__String() *String {
	var tmp1 any
	if !(t.F_locale == nil) { tmp1 = Concat(Lit_1142, NN(t.F_locale).GetDisplayName__String(), Lit_1142) } else { tmp1 = nil }
//line :1252:1
	return Lit_1975.Formatted_O1__String(RefArrayOf(Object_class, tmp1, t.ToPattern__String().Ref()))
}


func (t *SimpleDateFormat) Equals_O__Z(obj any) bool {
	if !t.DateFormat.Impl_Equals_O__Z(t, obj) { return false } else {

		var that *SimpleDateFormat = SimpleDateFormat_Cast(obj); var tmp1 bool; var tmp2 *String = t.F_pattern
		tmp1 = NN(tmp2).Equals_O__Z(that.F_pattern.Ref()); if tmp1 { var tmp3 *DateFormatSymbols = t.F_formatData; tmp1 = NN(tmp3).Equals_O__Z(that.F_formatData.Ref()) }; return tmp1
	}
}


func (t *SimpleDateFormat) GetDisplayNamesMap_I_Locale__Map(field int32, locale *Locale) Map {
	var map_ Map = t.F_calendar.GetDisplayNames_I_I_Locale__Map(field, 1, locale); var arr_101395 *IntArray = SimpleDateFormat_REST_OF_STYLES; var len_101396 int32 = int32(len(arr_101395.A)); var i_101397 int32 = 0; for ; i_101397 < len_101396; i_101397++ {




		var style int32 = arr_101395.A[i_101397]; var m Map = t.F_calendar.GetDisplayNames_I_I_Locale__Map(field, style, locale)

		if !(m == nil) { map_.PutAll_Map__V(m) } }
//line :1266:1
	return map_
}








func (t *SimpleDateFormat) GetDisplayContextNamesMap_I_Locale__Map(field int32, locale *Locale) Map {

	var map_ Map; var tmp1 Calendar_I = t.F_calendar; var tmp2 int32


	if t.F_forceStandaloneForm { tmp2 = 32769 } else { tmp2 = 1 }
//line :1278:1
	map_ = tmp1.GetDisplayNames_I_I_Locale__Map(field, tmp2, locale); var m Map; var tmp3 Calendar_I = t.F_calendar; var tmp4 int32









	if t.F_forceStandaloneForm { tmp4 = 32770 } else { tmp4 = 2 }
//line :1285:1
	m = tmp3.GetDisplayNames_I_I_Locale__Map(field, tmp4, locale)






	if !(m == nil) { map_.PutAll_Map__V(m) }
//line :1278:1
	return map_
}
































func (t *SimpleDateFormat) CheckNegativeNumberExpression__V() {
	var tmp1 bool; var tmp2 bool; tmp2 = DecimalFormat_InstanceOf(t.F_numberFormat); if tmp2 {
		tmp2 = !t.F_numberFormat.Equals_O__Z(t.F_originalNumberFormat) }
//line :1313:1
	tmp1 = tmp2; if tmp1 {

		var numberPattern *String = NN(DecimalFormat_Cast(t.F_numberFormat)).ToPattern__String()
		if NN(numberPattern).Equals_O__Z(t.F_originalNumberPattern.Ref()) { } else {
			t.F_hasFollowingMinusSign = false
			var separatorIndex int32 = NN(numberPattern).IndexOf_I__I(59)
			if separatorIndex > -1 {
				var minusIndex int32 = NN(numberPattern).IndexOf_I_I__I(45, separatorIndex); var tmp3 bool; var tmp4 bool
				tmp4 = minusIndex > NN(numberPattern).LastIndexOf_I__I(48); if tmp4 {
					tmp4 = minusIndex > NN(numberPattern).LastIndexOf_I__I(35) }
//line :1321:1
				tmp3 = tmp4; if tmp3 {

					t.F_hasFollowingMinusSign = true
					t.F_minusSign = NN(NN(DecimalFormat_Cast(t.F_numberFormat)).GetDecimalFormatSymbols__DecimalFormatSymbols()).GetMinusSign__C()
				}
			}
			t.F_originalNumberPattern = numberPattern }
		t.F_originalNumberFormat = t.F_numberFormat } }
//line :1318:1
type SimpleDateFormat struct{ DateFormat; F_serialVersionOnStream int32; F_pattern *String; F_originalNumberFormat NumberFormat_I; F_originalNumberPattern *String; F_minusSign uint16; F_hasFollowingMinusSign, F_forceStandaloneForm bool; F_compiledPattern *CharArray; F_zeroDigit uint16; F_formatData *DateFormatSymbols; F_defaultCenturyStart Date_I; F_defaultCenturyStartYear int32; F_locale *Locale; F_useDateFormatSymbols bool }

const SimpleDateFormat_serialVersionUID int64 = 4774881970558875024

const SimpleDateFormat_currentSerialVersion int32 = 1

const SimpleDateFormat_TAG_QUOTE_ASCII_CHAR int32 = 100

const SimpleDateFormat_TAG_QUOTE_CHARS int32 = 101

const SimpleDateFormat_MILLIS_PER_MINUTE int32 = 60000

var SimpleDateFormat_GMT *String = Lit_1972

var SimpleDateFormat_cachedNumberFormatData ConcurrentMap

var SimpleDateFormat_PATTERN_INDEX_TO_CALENDAR_FIELD *IntArray

var SimpleDateFormat_PATTERN_INDEX_TO_DATE_FORMAT_FIELD *IntArray

var SimpleDateFormat_PATTERN_INDEX_TO_DATE_FORMAT_FIELD_ID *RefArray

var SimpleDateFormat_REST_OF_STYLES *IntArray

var SimpleDateFormat_init ClassInit

func SimpleDateFormat_Init() { if !SimpleDateFormat_init.Done() { SimpleDateFormat_init.Run(SimpleDateFormat_clinit) } }

func SimpleDateFormat_clinit() { SimpleDateFormat_cachedNumberFormatData = ConcurrentHashMap_New_I(3); SimpleDateFormat_PATTERN_INDEX_TO_CALENDAR_FIELD = IntArrayOf(0, 1, 2, 5, 11, 11, 12, 13, 14, 7, 6, 8, 3, 4, 9, 10, 10, 15, 15, 17, 1000, 15, 2); SimpleDateFormat_PATTERN_INDEX_TO_DATE_FORMAT_FIELD = IntArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 17, 1, 9, 17, 2); var tmp1 *DateFormat_Field; DateFormat_Field_Init(); tmp1 = DateFormat_Field_ERA; var tmp2 any = tmp1.Ref(); var tmp3 *DateFormat_Field; DateFormat_Field_Init(); tmp3 = DateFormat_Field_YEAR; var tmp4 any = tmp3.Ref(); var tmp5 *DateFormat_Field; DateFormat_Field_Init(); tmp5 = DateFormat_Field_MONTH; var tmp6 any = tmp5.Ref(); var tmp7 *DateFormat_Field; DateFormat_Field_Init(); tmp7 = DateFormat_Field_DAY_OF_MONTH; var tmp8 any = tmp7.Ref(); var tmp9 *DateFormat_Field; DateFormat_Field_Init(); tmp9 = DateFormat_Field_HOUR_OF_DAY1; var tmp10 any = tmp9.Ref(); var tmp11 *DateFormat_Field; DateFormat_Field_Init(); tmp11 = DateFormat_Field_HOUR_OF_DAY0; var tmp12 any = tmp11.Ref(); var tmp13 *DateFormat_Field; DateFormat_Field_Init(); tmp13 = DateFormat_Field_MINUTE; var tmp14 any = tmp13.Ref(); var tmp15 *DateFormat_Field; DateFormat_Field_Init(); tmp15 = DateFormat_Field_SECOND; var tmp16 any = tmp15.Ref(); var tmp17 *DateFormat_Field; DateFormat_Field_Init(); tmp17 = DateFormat_Field_MILLISECOND; var tmp18 any = tmp17.Ref(); var tmp19 *DateFormat_Field; DateFormat_Field_Init(); tmp19 = DateFormat_Field_DAY_OF_WEEK; var tmp20 any = tmp19.Ref(); var tmp21 *DateFormat_Field; DateFormat_Field_Init(); tmp21 = DateFormat_Field_DAY_OF_YEAR; var tmp22 any = tmp21.Ref(); var tmp23 *DateFormat_Field; DateFormat_Field_Init(); tmp23 = DateFormat_Field_DAY_OF_WEEK_IN_MONTH; var tmp24 any = tmp23.Ref(); var tmp25 *DateFormat_Field; DateFormat_Field_Init(); tmp25 = DateFormat_Field_WEEK_OF_YEAR; var tmp26 any = tmp25.Ref(); var tmp27 *DateFormat_Field; DateFormat_Field_Init(); tmp27 = DateFormat_Field_WEEK_OF_MONTH; var tmp28 any = tmp27.Ref(); var tmp29 *DateFormat_Field; DateFormat_Field_Init(); tmp29 = DateFormat_Field_AM_PM; var tmp30 any = tmp29.Ref(); var tmp31 *DateFormat_Field; DateFormat_Field_Init(); tmp31 = DateFormat_Field_HOUR1; var tmp32 any = tmp31.Ref(); var tmp33 *DateFormat_Field; DateFormat_Field_Init(); tmp33 = DateFormat_Field_HOUR0; var tmp34 any = tmp33.Ref(); var tmp35 *DateFormat_Field; DateFormat_Field_Init(); tmp35 = DateFormat_Field_TIME_ZONE; var tmp36 any = tmp35.Ref(); var tmp37 *DateFormat_Field; DateFormat_Field_Init(); tmp37 = DateFormat_Field_TIME_ZONE; var tmp38 any = tmp37.Ref(); var tmp39 *DateFormat_Field; DateFormat_Field_Init(); tmp39 = DateFormat_Field_YEAR; var tmp40 any = tmp39.Ref(); var tmp41 *DateFormat_Field; DateFormat_Field_Init(); tmp41 = DateFormat_Field_DAY_OF_WEEK; var tmp42 any = tmp41.Ref(); var tmp43 *DateFormat_Field; DateFormat_Field_Init(); tmp43 = DateFormat_Field_TIME_ZONE; var tmp44 any = tmp43.Ref(); var tmp45 *DateFormat_Field; DateFormat_Field_Init(); tmp45 = DateFormat_Field_MONTH; SimpleDateFormat_PATTERN_INDEX_TO_DATE_FORMAT_FIELD_ID = RefArrayOf(DateFormat_Field_class, tmp2, tmp4, tmp6, tmp8, tmp10, tmp12, tmp14, tmp16, tmp18, tmp20, tmp22, tmp24, tmp26, tmp28, tmp30, tmp32, tmp34, tmp36, tmp38, tmp40, tmp42, tmp44, tmp45.Ref()); SimpleDateFormat_REST_OF_STYLES = IntArrayOf(32769, 2, 32770) }

func (t *SimpleDateFormat) Format_O__String(p0 any) *String { return t.Impl_Format_O__String(t, p0) }

func (t *SimpleDateFormat) Format_Date__String(p0 Date_I) *String { return t.Impl_Format_Date__String(t, p0) }

func (t *SimpleDateFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(t, p0) }

func (t *SimpleDateFormat) Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(p0 any, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf { return t.Impl_Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(t, p0, p1, p2) }

func (t *SimpleDateFormat) GetTimeZone__TimeZone() TimeZone_I { return t.Impl_GetTimeZone__TimeZone(t) }

func (t *SimpleDateFormat) Parse_String__Date(p0 *String) Date_I { return t.Impl_Parse_String__Date(t, p0) }

func (t *SimpleDateFormat) SetCalendar_Calendar__V(p0 Calendar_I) { t.Impl_SetCalendar_Calendar__V(t, p0) }

func (t *SimpleDateFormat) SetTimeZone_TimeZone__V(p0 TimeZone_I) { t.Impl_SetTimeZone_TimeZone__V(t, p0) }

func (t *SimpleDateFormat) GetCalendar__Calendar() Calendar_I { return t.Impl_GetCalendar__Calendar(t) }

func (t *SimpleDateFormat) ParseObject_String__O(p0 *String) any { return t.Impl_ParseObject_String__O(t, p0) }

func (t *SimpleDateFormat) IsLenient__Z() bool { return t.Impl_IsLenient__Z(t) }

func (t *SimpleDateFormat) SetLenient_Z__V(p0 bool) { t.Impl_SetLenient_Z__V(t, p0) }

func (t *SimpleDateFormat) Format_O_StringBuffer_FieldPosition__StringBuffer(p0 any, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer { return t.Impl_Format_O_StringBuffer_FieldPosition__StringBuffer(t, p0, p1, p2) }

func (t *SimpleDateFormat) ParseObject_String_ParsePosition__O(p0 *String, p1 *ParsePosition) any { return t.Impl_ParseObject_String_ParsePosition__O(t, p0, p1) }

func (t *SimpleDateFormat) CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *SimpleDateFormat) CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(t, p0) }

func (t *SimpleDateFormat) GetNumberFormat__NumberFormat() NumberFormat_I { return t.Impl_GetNumberFormat__NumberFormat(t) }

func (t *SimpleDateFormat) SetNumberFormat_NumberFormat__V(p0 NumberFormat_I) { t.Impl_SetNumberFormat_NumberFormat__V(t, p0) }

func (t *SimpleDateFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *SimpleDateFormat) Ref() any { if t == nil { return nil }; return t }

func (t *SimpleDateFormat) GetClass__Class() *Class { return SimpleDateFormat_class }

func (t *SimpleDateFormat) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func SimpleDateFormat_InstanceOf(x any) bool { _, ok := x.(*SimpleDateFormat); return ok }

func SimpleDateFormat_Cast(x any) *SimpleDateFormat { if x == nil { return nil }; v, ok := x.(*SimpleDateFormat); if !ok { panic(ClassCast(x, SimpleDateFormat_class)) }; return v }
