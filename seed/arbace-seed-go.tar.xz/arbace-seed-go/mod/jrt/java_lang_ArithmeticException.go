//line java_lang_ArithmeticException.ae:1
package jrt








func ArithmeticException_New() *ArithmeticException { t := &ArithmeticException{}; t.Ctor(); return t }
//line :10:1
func (t *ArithmeticException) Ctor() { t.RuntimeException.Ctor(t) }

func ArithmeticException_New_String(p0 *String) *ArithmeticException { t := &ArithmeticException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *ArithmeticException) Ctor_String(s *String) { t.RuntimeException.Ctor_String(t, s) }







type ArithmeticException struct{ RuntimeException }

const ArithmeticException_serialVersionUID int64 = 2256477558314496007

func (t *ArithmeticException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ArithmeticException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ArithmeticException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ArithmeticException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ArithmeticException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ArithmeticException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ArithmeticException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ArithmeticException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ArithmeticException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ArithmeticException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ArithmeticException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ArithmeticException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ArithmeticException) Ref() any { if t == nil { return nil }; return t }

func (t *ArithmeticException) GetClass__Class() *Class { return ArithmeticException_class }

func (t *ArithmeticException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArithmeticException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArithmeticException_InstanceOf(x any) bool { _, ok := x.(*ArithmeticException); return ok }

func ArithmeticException_Cast(x any) *ArithmeticException { if x == nil { return nil }; v, ok := x.(*ArithmeticException); if !ok { panic(ClassCast(x, ArithmeticException_class)) }; return v }
