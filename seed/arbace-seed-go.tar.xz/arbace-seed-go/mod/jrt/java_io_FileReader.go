//line java_io_FileReader.ae:1
package jrt








func FileReader_New_String(p0 *String) *FileReader { t := &FileReader{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *FileReader) Ctor_String(fileName *String) { t.InputStreamReader.Ctor_InputStream(t, FileInputStream_New_String(fileName)) }


func FileReader_New_File(p0 *File) *FileReader { t := &FileReader{}; t.Ctor_File(p0); return t }
//line :13:1
func (t *FileReader) Ctor_File(file *File) { t.InputStreamReader.Ctor_InputStream(t, FileInputStream_New_File(file)) }


func FileReader_New_FileDescriptor(p0 *FileDescriptor) *FileReader { t := &FileReader{}; t.Ctor_FileDescriptor(p0); return t }
//line :16:1
func (t *FileReader) Ctor_FileDescriptor(fd *FileDescriptor) { t.InputStreamReader.Ctor_InputStream(t, FileInputStream_New_FileDescriptor(fd)) }


func FileReader_New_String_Charset(p0 *String, p1 Charset_I) *FileReader { t := &FileReader{}; t.Ctor_String_Charset(p0, p1); return t }
//line :19:1
func (t *FileReader) Ctor_String_Charset(fileName *String, charset Charset_I) { t.InputStreamReader.Ctor_InputStream_Charset(t, FileInputStream_New_String(fileName), charset) }


func FileReader_New_File_Charset(p0 *File, p1 Charset_I) *FileReader { t := &FileReader{}; t.Ctor_File_Charset(p0, p1); return t }
//line :22:1
func (t *FileReader) Ctor_File_Charset(file *File, charset Charset_I) { t.InputStreamReader.Ctor_InputStream_Charset(t, FileInputStream_New_File(file), charset) }





type FileReader struct{ InputStreamReader }

func (t *FileReader) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *FileReader) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *FileReader) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *FileReader) Close__V() { t.Impl_Close__V(t) }

func (t *FileReader) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *FileReader) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *FileReader) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *FileReader) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *FileReader) Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32 { return t.Impl_Read_C1_I_I__I(t, p0, p1, p2) }

func (t *FileReader) Reset__V() { t.Impl_Reset__V(t) }

func (t *FileReader) GetEncoding__String() *String { return t.Impl_GetEncoding__String(t) }

func (t *FileReader) Ready__Z() bool { return t.Impl_Ready__Z(t) }

func (t *FileReader) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *FileReader) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *FileReader) Ref() any { if t == nil { return nil }; return t }

func (t *FileReader) GetClass__Class() *Class { return FileReader_class }

func (t *FileReader) ToString__String() *String { return Object_toString(t) }

func (t *FileReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileReader_InstanceOf(x any) bool { _, ok := x.(*FileReader); return ok }

func FileReader_Cast(x any) *FileReader { if x == nil { return nil }; v, ok := x.(*FileReader); if !ok { panic(ClassCast(x, FileReader_class)) }; return v }
