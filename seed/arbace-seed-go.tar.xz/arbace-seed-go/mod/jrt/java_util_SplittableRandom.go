//line java_util_SplittableRandom.ae:1
package jrt

















func SplittableRandom_New_J_J(p0, p1 int64) *SplittableRandom { SplittableRandom_Init(); t := &SplittableRandom{}; t.Ctor_J_J(p0, p1); return t }
//line :19:1
func (t *SplittableRandom) Ctor_J_J(seed, gamma int64) {
	t.F_seed = seed
	t.F_gamma = gamma
	t.F_proxy = SplittableRandom_AbstractSplittableGeneratorProxy_New_SplittableRandom(t)
}
func SplittableRandom_Mix64_J__J(z int64) int64 { SplittableRandom_Init()
	z = (z ^ int64(uint64(z)>>30)) * -4658895280553007687


	z = (z ^ int64(uint64(z)>>27)) * -7723592293110705685


	return z ^ int64(uint64(z)>>31)
}
func SplittableRandom_Mix32_J__I(z int64) int32 { SplittableRandom_Init()
	z = (z ^ int64(uint64(z)>>33)) * 7109453100751455733
	return int32(int64(uint64((z^int64(uint64(z)>>28))*-3808689974395783757) >> 32))
}




func SplittableRandom_MixGamma_J__J(z int64) int64 { SplittableRandom_Init()
	z = (z ^ int64(uint64(z)>>33)) * -49064778989728563


	z = (z ^ int64(uint64(z)>>33)) * -4265267296055464877


	z = z ^ int64(uint64(z)>>33) | 1
	var n int32 = Long_BitCount_J__I(z ^ int64(uint64(z)>>1))
	if n < 24 { return z ^ -6148914691236517206 } else { return z
	}
}


func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextInt__I() int32 { return NN(t.F_this_0).NextInt__I() }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextLong__J() int64 {
	return NN(t.F_this_0).NextLong__J()
}
func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Split_RandomGenerator_SplittableGenerator__SplittableRandom(source RandomGenerator_SplittableGenerator) *SplittableRandom {
	return SplittableRandom_New_J_J(source.NextLong__J(), SplittableRandom_MixGamma_J__J(source.NextLong__J()))
}


func (t *SplittableRandom) NextSeed__J() int64 {
	var tmp1 int64 = t.F_seed + t.F_gamma; t.F_seed = tmp1; return tmp1
}



func SplittableRandom_New_J(p0 int64) *SplittableRandom { SplittableRandom_Init(); t := &SplittableRandom{}; t.Ctor_J(p0); return t }
//line :71:1
func (t *SplittableRandom) Ctor_J(seed int64) { t.Ctor_J_J(seed, -7046029254386353131) }

func SplittableRandom_New() *SplittableRandom { SplittableRandom_Init(); t := &SplittableRandom{}; t.Ctor(); return t }
//line :73:1
func (t *SplittableRandom) Ctor() {
	var s int64 = NN(SplittableRandom_defaultGen).GetAndAdd_J__J(4354685564936845354)
	t.F_seed = SplittableRandom_Mix64_J__J(s)
	t.F_gamma = SplittableRandom_MixGamma_J__J(s + -7046029254386353131)
	t.F_proxy = SplittableRandom_AbstractSplittableGeneratorProxy_New_SplittableRandom(t)
}
func (t *SplittableRandom) Split__SplittableRandom() *SplittableRandom {
	return SplittableRandom_New_J_J(t.NextLong__J(), SplittableRandom_MixGamma_J__J(t.NextSeed__J()))
}
func (t *SplittableRandom) Split_RandomGenerator_SplittableGenerator__SplittableRandom(source RandomGenerator_SplittableGenerator) *SplittableRandom {
	return SplittableRandom_New_J_J(source.NextLong__J(), SplittableRandom_MixGamma_J__J(source.NextLong__J()))
}
func (t *SplittableRandom) NextInt__I() int32 {
	return SplittableRandom_Mix32_J__I(t.NextSeed__J())
}
func (t *SplittableRandom) NextLong__J() int64 {
	return SplittableRandom_Mix64_J__J(t.NextSeed__J())
}
func (t *SplittableRandom) NextBytes_B1__V(bytes *ByteArray) {
	NN(t.F_proxy).NextBytes_B1__V(bytes)
}
func (t *SplittableRandom) Splits__Stream() Stream {
	return NN(t.F_proxy).Splits__Stream()
}
func (t *SplittableRandom) Splits_J__Stream(streamSize int64) Stream {

	return NN(t.F_proxy).Splits_J_RandomGenerator_SplittableGenerator__Stream(streamSize, t)
}
func (t *SplittableRandom) Splits_RandomGenerator_SplittableGenerator__Stream(source RandomGenerator_SplittableGenerator) Stream {

	return NN(t.F_proxy).Splits_J_RandomGenerator_SplittableGenerator__Stream(9223372036854775807, source)
}
func (t *SplittableRandom) Splits_J_RandomGenerator_SplittableGenerator__Stream(streamSize int64, source RandomGenerator_SplittableGenerator) Stream {


	return NN(t.F_proxy).Splits_J_RandomGenerator_SplittableGenerator__Stream(streamSize, source)
}
func (t *SplittableRandom) Ints_J__IntStream(streamSize int64) IntStream {
	return NN(t.F_proxy).Ints_J__IntStream(streamSize)
}
func (t *SplittableRandom) Ints__IntStream() IntStream { return NN(t.F_proxy).Ints__IntStream() }

func (t *SplittableRandom) Ints_J_I_I__IntStream(streamSize int64, randomNumberOrigin, randomNumberBound int32) IntStream {

	return NN(t.F_proxy).Ints_J_I_I__IntStream(streamSize, randomNumberOrigin, randomNumberBound)
}
func (t *SplittableRandom) Ints_I_I__IntStream(randomNumberOrigin, randomNumberBound int32) IntStream {
	return NN(t.F_proxy).Ints_I_I__IntStream(randomNumberOrigin, randomNumberBound)
}
func (t *SplittableRandom) Longs_J__LongStream(streamSize int64) LongStream {
	return NN(t.F_proxy).Longs_J__LongStream(streamSize)
}
func (t *SplittableRandom) Longs__LongStream() LongStream { return NN(t.F_proxy).Longs__LongStream() }

func (t *SplittableRandom) Longs_J_J_J__LongStream(streamSize, randomNumberOrigin, randomNumberBound int64) LongStream {

	return NN(t.F_proxy).Longs_J_J_J__LongStream(streamSize, randomNumberOrigin, randomNumberBound)
}
func (t *SplittableRandom) Longs_J_J__LongStream(randomNumberOrigin, randomNumberBound int64) LongStream {
	return NN(t.F_proxy).Longs_J_J__LongStream(randomNumberOrigin, randomNumberBound)
}
func (t *SplittableRandom) Doubles_J__DoubleStream(streamSize int64) DoubleStream {
	return NN(t.F_proxy).Doubles_J__DoubleStream(streamSize)
}
func (t *SplittableRandom) Doubles__DoubleStream() DoubleStream { return NN(t.F_proxy).Doubles__DoubleStream() }

func (t *SplittableRandom) Doubles_J_D_D__DoubleStream(streamSize int64, randomNumberOrigin, randomNumberBound float64) DoubleStream {

	return NN(t.F_proxy).Doubles_J_D_D__DoubleStream(streamSize, randomNumberOrigin, randomNumberBound)
}
func (t *SplittableRandom) Doubles_D_D__DoubleStream(randomNumberOrigin, randomNumberBound float64) DoubleStream {
	return NN(t.F_proxy).Doubles_D_D__DoubleStream(randomNumberOrigin, randomNumberBound)
}


type SplittableRandom struct{ Object; F_seed, F_gamma int64; F_proxy *SplittableRandom_AbstractSplittableGeneratorProxy }

func (t *SplittableRandom) Is_RandomGenerator() {}

func (t *SplittableRandom) Is_RandomGenerator_SplittableGenerator() {}

func (t *SplittableRandom) Is_RandomGenerator_StreamableGenerator() {}

const SplittableRandom_GOLDEN_GAMMA int64 = -7046029254386353131

var SplittableRandom_defaultGen *AtomicLong

var SplittableRandom_init ClassInit

func SplittableRandom_Init() { if !SplittableRandom_init.Done() { SplittableRandom_init.Run(SplittableRandom_clinit) } }

func SplittableRandom_clinit() { SplittableRandom_defaultGen = AtomicLong_New_J(RandomSupport_InitialSeed__J()) }

func (t *SplittableRandom) Split__RandomGenerator_SplittableGenerator() RandomGenerator_SplittableGenerator { return Up_SplittableRandom_RandomGenerator_SplittableGenerator(t.Split__SplittableRandom()) }

func (t *SplittableRandom) Split_RandomGenerator_SplittableGenerator__RandomGenerator_SplittableGenerator(p0 RandomGenerator_SplittableGenerator) RandomGenerator_SplittableGenerator { return Up_SplittableRandom_RandomGenerator_SplittableGenerator(t.Split_RandomGenerator_SplittableGenerator__SplittableRandom(p0)) }

func (t *SplittableRandom) NextInt_I__I(p0 int32) int32 { return RandomGenerator_NextInt_I__I(t, p0) }

func (t *SplittableRandom) NextDouble_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextDouble_D_D__D(t, p0, p1) }

func (t *SplittableRandom) NextLong_J_J__J(p0, p1 int64) int64 { return RandomGenerator_NextLong_J_J__J(t, p0, p1) }

func (t *SplittableRandom) NextFloat_F__F(p0 float32) float32 { return RandomGenerator_NextFloat_F__F(t, p0) }

func (t *SplittableRandom) NextLong_J__J(p0 int64) int64 { return RandomGenerator_NextLong_J__J(t, p0) }

func (t *SplittableRandom) NextDouble__D() float64 { return RandomGenerator_NextDouble__D(t) }

func (t *SplittableRandom) NextInt_I_I__I(p0, p1 int32) int32 { return RandomGenerator_NextInt_I_I__I(t, p0, p1) }

func (t *SplittableRandom) EquiDoubles_D_D_Z_Z__DoubleStream(p0, p1 float64, p2, p3 bool) DoubleStream { return RandomGenerator_EquiDoubles_D_D_Z_Z__DoubleStream(t, p0, p1, p2, p3) }

func (t *SplittableRandom) NextBoolean__Z() bool { return RandomGenerator_NextBoolean__Z(t) }

func (t *SplittableRandom) NextGaussian__D() float64 { return RandomGenerator_NextGaussian__D(t) }

func (t *SplittableRandom) NextExponential__D() float64 { return RandomGenerator_NextExponential__D(t) }

func (t *SplittableRandom) Rngs_J__Stream(p0 int64) Stream { return RandomGenerator_SplittableGenerator_Rngs_J__Stream(t, p0) }

func (t *SplittableRandom) IsDeprecated__Z() bool { return RandomGenerator_IsDeprecated__Z(t) }

func (t *SplittableRandom) NextFloat_F_F__F(p0, p1 float32) float32 { return RandomGenerator_NextFloat_F_F__F(t, p0, p1) }

func (t *SplittableRandom) Rngs__Stream() Stream { return RandomGenerator_SplittableGenerator_Rngs__Stream(t) }

func (t *SplittableRandom) NextFloat__F() float32 { return RandomGenerator_NextFloat__F(t) }

func (t *SplittableRandom) NextGaussian_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextGaussian_D_D__D(t, p0, p1) }

func (t *SplittableRandom) NextDouble_D__D(p0 float64) float64 { return RandomGenerator_NextDouble_D__D(t, p0) }

func (t *SplittableRandom) Ref() any { if t == nil { return nil }; return t }

func (t *SplittableRandom) GetClass__Class() *Class { return SplittableRandom_class }

func (t *SplittableRandom) ToString__String() *String { return Object_toString(t) }

func (t *SplittableRandom) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SplittableRandom) CloneShallow() any { panic(CloneNotSupported(t)) }

func SplittableRandom_InstanceOf(x any) bool { _, ok := x.(*SplittableRandom); return ok }

func SplittableRandom_Cast(x any) *SplittableRandom { if x == nil { return nil }; v, ok := x.(*SplittableRandom); if !ok { panic(ClassCast(x, SplittableRandom_class)) }; return v }



type SplittableRandom_AbstractSplittableGeneratorProxy struct{ RandomSupport_AbstractSplittableGenerator; F_this_0 *SplittableRandom }

func SplittableRandom_AbstractSplittableGeneratorProxy_New_SplittableRandom(p0 *SplittableRandom) *SplittableRandom_AbstractSplittableGeneratorProxy { t := &SplittableRandom_AbstractSplittableGeneratorProxy{}; t.Ctor_SplittableRandom(p0); return t }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Ctor_SplittableRandom(this_0 *SplittableRandom) { NN(this_0); t.F_this_0 = this_0; t.RandomSupport_AbstractSplittableGenerator.Ctor(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Split_RandomGenerator_SplittableGenerator__RandomGenerator_SplittableGenerator(p0 RandomGenerator_SplittableGenerator) RandomGenerator_SplittableGenerator { return Up_SplittableRandom_RandomGenerator_SplittableGenerator(t.Split_RandomGenerator_SplittableGenerator__SplittableRandom(p0)) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextInt_I__I(p0 int32) int32 { return RandomGenerator_NextInt_I__I(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Doubles_D_D__DoubleStream(p0, p1 float64) DoubleStream { return t.Impl_Doubles_D_D__DoubleStream(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextDouble_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextDouble_D_D__D(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Doubles_J_D_D__DoubleStream(p0 int64, p1, p2 float64) DoubleStream { return t.Impl_Doubles_J_D_D__DoubleStream(t, p0, p1, p2) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Longs_J__LongStream(p0 int64) LongStream { return t.Impl_Longs_J__LongStream(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextLong_J_J__J(p0, p1 int64) int64 { return RandomGenerator_NextLong_J_J__J(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextFloat_F__F(p0 float32) float32 { return RandomGenerator_NextFloat_F__F(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Longs_J_J__LongStream(p0, p1 int64) LongStream { return t.Impl_Longs_J_J__LongStream(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextLong_J__J(p0 int64) int64 { return RandomGenerator_NextLong_J__J(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Ints_J_I_I__IntStream(p0 int64, p1, p2 int32) IntStream { return t.Impl_Ints_J_I_I__IntStream(t, p0, p1, p2) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextDouble__D() float64 { return RandomGenerator_NextDouble__D(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Splits_J_RandomGenerator_SplittableGenerator__Stream(p0 int64, p1 RandomGenerator_SplittableGenerator) Stream { return t.Impl_Splits_J_RandomGenerator_SplittableGenerator__Stream(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Ints_I_I__IntStream(p0, p1 int32) IntStream { return t.Impl_Ints_I_I__IntStream(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextInt_I_I__I(p0, p1 int32) int32 { return RandomGenerator_NextInt_I_I__I(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) MakeSplitsSpliterator_J_J_RandomGenerator_SplittableGenerator__Spliterator(p0, p1 int64, p2 RandomGenerator_SplittableGenerator) Spliterator { return t.Impl_MakeSplitsSpliterator_J_J_RandomGenerator_SplittableGenerator__Spliterator(t, p0, p1, p2) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) EquiDoubles_D_D_Z_Z__DoubleStream(p0, p1 float64, p2, p3 bool) DoubleStream { return RandomGenerator_EquiDoubles_D_D_Z_Z__DoubleStream(t, p0, p1, p2, p3) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextBoolean__Z() bool { return RandomGenerator_NextBoolean__Z(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextGaussian__D() float64 { return RandomGenerator_NextGaussian__D(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Ints__IntStream() IntStream { return t.Impl_Ints__IntStream(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextExponential__D() float64 { return RandomGenerator_NextExponential__D(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Split__RandomGenerator_SplittableGenerator() RandomGenerator_SplittableGenerator { return t.Impl_Split__RandomGenerator_SplittableGenerator(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Splits__Stream() Stream { return t.Impl_Splits__Stream(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Rngs_J__Stream(p0 int64) Stream { return RandomGenerator_SplittableGenerator_Rngs_J__Stream(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) IsDeprecated__Z() bool { return RandomGenerator_IsDeprecated__Z(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Doubles_J__DoubleStream(p0 int64) DoubleStream { return t.Impl_Doubles_J__DoubleStream(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextFloat_F_F__F(p0, p1 float32) float32 { return RandomGenerator_NextFloat_F_F__F(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Ints_J__IntStream(p0 int64) IntStream { return t.Impl_Ints_J__IntStream(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Rngs__Stream() Stream { return RandomGenerator_SplittableGenerator_Rngs__Stream(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Splits_RandomGenerator_SplittableGenerator__Stream(p0 RandomGenerator_SplittableGenerator) Stream { return t.Impl_Splits_RandomGenerator_SplittableGenerator__Stream(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextFloat__F() float32 { return RandomGenerator_NextFloat__F(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextBytes_B1__V(p0 *ByteArray) { RandomGenerator_NextBytes_B1__V(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Longs_J_J_J__LongStream(p0, p1, p2 int64) LongStream { return t.Impl_Longs_J_J_J__LongStream(t, p0, p1, p2) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Doubles__DoubleStream() DoubleStream { return t.Impl_Doubles__DoubleStream(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Splits_J__Stream(p0 int64) Stream { return t.Impl_Splits_J__Stream(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextGaussian_D_D__D(p0, p1 float64) float64 { return RandomGenerator_NextGaussian_D_D__D(t, p0, p1) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) NextDouble_D__D(p0 float64) float64 { return RandomGenerator_NextDouble_D__D(t, p0) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Longs__LongStream() LongStream { return t.Impl_Longs__LongStream(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Ref() any { if t == nil { return nil }; return t }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) GetClass__Class() *Class { return SplittableRandom_AbstractSplittableGeneratorProxy_class }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) ToString__String() *String { return Object_toString(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SplittableRandom_AbstractSplittableGeneratorProxy) CloneShallow() any { panic(CloneNotSupported(t)) }

func SplittableRandom_AbstractSplittableGeneratorProxy_InstanceOf(x any) bool { _, ok := x.(*SplittableRandom_AbstractSplittableGeneratorProxy); return ok }

func SplittableRandom_AbstractSplittableGeneratorProxy_Cast(x any) *SplittableRandom_AbstractSplittableGeneratorProxy { if x == nil { return nil }; v, ok := x.(*SplittableRandom_AbstractSplittableGeneratorProxy); if !ok { panic(ClassCast(x, SplittableRandom_AbstractSplittableGeneratorProxy_class)) }; return v }
