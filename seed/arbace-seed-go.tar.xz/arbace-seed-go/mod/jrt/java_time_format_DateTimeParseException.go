//line java_time_format_DateTimeParseException.ae:1
package jrt














func DateTimeParseException_New_String_CharSequence_I(p0 *String, p1 CharSequence, p2 int32) *DateTimeParseException { t := &DateTimeParseException{}; t.Ctor_String_CharSequence_I(p0, p1, p2); return t }
//line :16:1
func (t *DateTimeParseException) Ctor_String_CharSequence_I(message *String, parsedData CharSequence, errorIndex int32) { t.DateTimeException.Ctor_String(t, message)

	t.F_parsedString = parsedData.ToString__String()
	t.F_errorIndex = errorIndex
}
func DateTimeParseException_New_String_CharSequence_I_Throwable(p0 *String, p1 CharSequence, p2 int32, p3 Throwable_I) *DateTimeParseException { t := &DateTimeParseException{}; t.Ctor_String_CharSequence_I_Throwable(p0, p1, p2, p3); return t }
//line :21:1
func (t *DateTimeParseException) Ctor_String_CharSequence_I_Throwable(message *String, parsedData CharSequence, errorIndex int32, cause Throwable_I) { t.DateTimeException.Ctor_String_Throwable(t, message, cause)


	t.F_parsedString = parsedData.ToString__String()
	t.F_errorIndex = errorIndex
}
func (t *DateTimeParseException) GetParsedString__String() *String { return t.F_parsedString }

func (t *DateTimeParseException) GetErrorIndex__I() int32 { return t.F_errorIndex }



type DateTimeParseException struct{ DateTimeException; F_parsedString *String; F_errorIndex int32 }

const DateTimeParseException_serialVersionUID int64 = 4304633501674722597

func (t *DateTimeParseException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *DateTimeParseException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *DateTimeParseException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *DateTimeParseException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *DateTimeParseException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *DateTimeParseException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *DateTimeParseException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *DateTimeParseException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *DateTimeParseException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *DateTimeParseException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *DateTimeParseException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *DateTimeParseException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DateTimeParseException) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeParseException) GetClass__Class() *Class { return DateTimeParseException_class }

func (t *DateTimeParseException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeParseException) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeParseException_InstanceOf(x any) bool { _, ok := x.(*DateTimeParseException); return ok }

func DateTimeParseException_Cast(x any) *DateTimeParseException { if x == nil { return nil }; v, ok := x.(*DateTimeParseException); if !ok { panic(ClassCast(x, DateTimeParseException_class)) }; return v }
