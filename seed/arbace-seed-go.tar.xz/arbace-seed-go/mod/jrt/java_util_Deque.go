//line java_util_Deque.ae:1
package jrt































































func Deque_Reversed__Deque(this Deque) Deque {
	return ReverseOrderDequeView_Of_Deque__Deque(this)
}


type Deque interface{ Object_I; Queue; SequencedCollection; Collection; Iterable; Is_Deque(); AddFirst_O__V(p0 any); AddLast_O__V(p0 any); OfferFirst_O__Z(p0 any) bool; OfferLast_O__Z(p0 any) bool; RemoveFirst__O() any; RemoveLast__O() any; PollFirst__O() any; PollLast__O() any; GetFirst__O() any; GetLast__O() any; PeekFirst__O() any; PeekLast__O() any; RemoveFirstOccurrence_O__Z(p0 any) bool; RemoveLastOccurrence_O__Z(p0 any) bool; Add_O__Z(p0 any) bool; Offer_O__Z(p0 any) bool; Remove__O() any; Poll__O() any; Element__O() any; Peek__O() any; AddAll_Collection__Z(p0 Collection) bool; Push_O__V(p0 any); Pop__O() any; Remove_O__Z(p0 any) bool; Contains_O__Z(p0 any) bool; Size__I() int32; Iterator__Iterator() Iterator; DescendingIterator__Iterator() Iterator; Reversed__Deque() Deque; Reversed__SequencedCollection() SequencedCollection }

func Deque_Reversed__SequencedCollection(this Deque) SequencedCollection { return this.Reversed__Deque() }

func Deque_InstanceOf(x any) bool { _, ok := x.(Deque); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Deque_class) } }; return ok }

func Deque_Cast(x any) Deque { if x == nil { return nil }; v, ok := x.(Deque); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Deque_class) } }; if !ok { panic(ClassCast(x, Deque_class)) }; return v }
