//line java_util_IllegalFormatCodePointException.ae:1
package jrt










func IllegalFormatCodePointException_New_I(p0 int32) *IllegalFormatCodePointException { t := &IllegalFormatCodePointException{}; t.Ctor_I(p0); return t }
//line :12:1
func (t *IllegalFormatCodePointException) Ctor_I(c int32) { t.IllegalFormatException.Ctor(t); t.F_c = c }

func (t *IllegalFormatCodePointException) GetCodePoint__I() int32 { return t.F_c }

func (t *IllegalFormatCodePointException) GetMessage__String() *String {
	return String_Format_String_O1__String(Lit_2727, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(t.F_c)))
}



type IllegalFormatCodePointException struct{ IllegalFormatException; F_c int32 }

const IllegalFormatCodePointException_serialVersionUID int64 = 19080630

func (t *IllegalFormatCodePointException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalFormatCodePointException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalFormatCodePointException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalFormatCodePointException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalFormatCodePointException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalFormatCodePointException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalFormatCodePointException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalFormatCodePointException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalFormatCodePointException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalFormatCodePointException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalFormatCodePointException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalFormatCodePointException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalFormatCodePointException) GetClass__Class() *Class { return IllegalFormatCodePointException_class }

func (t *IllegalFormatCodePointException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalFormatCodePointException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalFormatCodePointException_InstanceOf(x any) bool { _, ok := x.(*IllegalFormatCodePointException); return ok }

func IllegalFormatCodePointException_Cast(x any) *IllegalFormatCodePointException { if x == nil { return nil }; v, ok := x.(*IllegalFormatCodePointException); if !ok { panic(ClassCast(x, IllegalFormatCodePointException_class)) }; return v }
