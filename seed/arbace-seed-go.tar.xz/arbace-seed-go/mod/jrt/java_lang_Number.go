//line java_lang_Number.ae:1
package jrt








func (t *Number) Ctor(this Number_I) {}









func (t *Number) Impl_ByteValue__B(this Number_I) int8 {
	return int8(this.IntValue__I())
}
func (t *Number) Impl_ShortValue__S(this Number_I) int16 {
	return int16(this.IntValue__I())
}


type Number struct{ Object }

type Number_I interface{ Object_I; Serializable; Self_Number() *Number; IntValue__I() int32; LongValue__J() int64; FloatValue__F() float32; DoubleValue__D() float64; ByteValue__B() int8; ShortValue__S() int16 }

func (t *Number) Self_Number() *Number { return t }

func (t *Number) Is_Serializable() {}

const Number_serialVersionUID int64 = -8742448824652078965

func Number_InstanceOf(x any) bool { _, ok := x.(Number_I); return ok }

func Number_Cast(x any) Number_I { if x == nil { return nil }; v, ok := x.(Number_I); if !ok { panic(ClassCast(x, Number_class)) }; return v }
