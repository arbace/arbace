//line java_lang_NoSuchMethodException.ae:1
package jrt








func NoSuchMethodException_New() *NoSuchMethodException { t := &NoSuchMethodException{}; t.Ctor(); return t }
//line :10:1
func (t *NoSuchMethodException) Ctor() { t.ReflectiveOperationException.Ctor(t) }

func NoSuchMethodException_New_String(p0 *String) *NoSuchMethodException { t := &NoSuchMethodException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NoSuchMethodException) Ctor_String(s *String) { t.ReflectiveOperationException.Ctor_String(t, s) }







type NoSuchMethodException struct{ ReflectiveOperationException }

const NoSuchMethodException_serialVersionUID int64 = 5034388446362600923

func (t *NoSuchMethodException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoSuchMethodException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoSuchMethodException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoSuchMethodException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoSuchMethodException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoSuchMethodException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoSuchMethodException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoSuchMethodException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoSuchMethodException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoSuchMethodException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoSuchMethodException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoSuchMethodException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoSuchMethodException) Ref() any { if t == nil { return nil }; return t }

func (t *NoSuchMethodException) GetClass__Class() *Class { return NoSuchMethodException_class }

func (t *NoSuchMethodException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoSuchMethodException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoSuchMethodException_InstanceOf(x any) bool { _, ok := x.(*NoSuchMethodException); return ok }

func NoSuchMethodException_Cast(x any) *NoSuchMethodException { if x == nil { return nil }; v, ok := x.(*NoSuchMethodException); if !ok { panic(ClassCast(x, NoSuchMethodException_class)) }; return v }
