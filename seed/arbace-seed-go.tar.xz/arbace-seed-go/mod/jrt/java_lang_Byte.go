//line java_lang_Byte.ae:1
package jrt



















func Byte_ToString_B__String(b int8) *String {
	return Integer_ToString_I__String(int32(b))
}
func (t *Byte) DescribeConstable__Optional() *Optional {
	return Optional_Of_O__Optional(A2g_Missing[any]("class java.lang.constant.DynamicConstantDesc is not in the closed world"))
}




func Byte_ByteCache_New() *Byte_ByteCache { Byte_ByteCache_Init(); t := &Byte_ByteCache{}; t.Ctor(); return t }
//line :31:1
func (t *Byte_ByteCache) Ctor() { panic(A2g_NotTranslated("java.lang.Byte$ByteCache.<init>()V")) }























func Byte_ValueOf_B__Byte(b int8) *Byte {
	var tmp1 *RefArray; Byte_ByteCache_Init(); tmp1 = Byte_ByteCache_cache; return As[*Byte](tmp1.A[int32(b)+128])
}
func Byte_ParseByte_String_I__B(s *String, radix int32) int8 {
	var i int32 = Integer_ParseInt_String_I__I(s, radix); var tmp1 bool; var tmp2 bool
	tmp2 = i < -128; if !tmp2 { tmp2 = i > 127 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NumberFormatException_New_String(Concat(Lit_109, s, Lit_110, StrOfInt(radix)))))
	}
	return int8(i)
}
func Byte_ParseByte_String__B(s *String) int8 {
	return Byte_ParseByte_String_I__B(s, 10)
}
func Byte_ValueOf_String_I__Byte(s *String, radix int32) *Byte {
	return Byte_ValueOf_B__Byte(Byte_ParseByte_String_I__B(s, radix))
}
func Byte_ValueOf_String__Byte(s *String) *Byte {
	return Byte_ValueOf_String_I__Byte(s, 10)
}
func Byte_Decode_String__Byte(nm *String) *Byte {
	var i int32 = NN(Integer_Decode_String__Integer(nm)).IntValue__I(); var tmp1 bool; var tmp2 bool
	tmp2 = i < -128; if !tmp2 { tmp2 = i > 127 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NumberFormatException_New_String(Concat(Lit_111, StrOfInt(i), Lit_112, nm)))) }
	return Byte_ValueOf_B__Byte(int8(i))
}


func Byte_New_B(p0 int8) *Byte { Byte_Init(); t := &Byte{}; t.Ctor_B(p0); return t }
//line :82:1
func (t *Byte) Ctor_B(value int8) { t.Number.Ctor(t)
	t.F_value = value
}
func Byte_New_String(p0 *String) *Byte { Byte_Init(); t := &Byte{}; t.Ctor_String(p0); return t }
//line :85:1
func (t *Byte) Ctor_String(s *String) { t.Number.Ctor(t)
	t.F_value = Byte_ParseByte_String_I__B(s, 10)
}
func (t *Byte) ByteValue__B() int8 { return t.F_value }


func (t *Byte) ShortValue__S() int16 { return int16(t.F_value) }

func (t *Byte) IntValue__I() int32 { return int32(t.F_value) }

func (t *Byte) LongValue__J() int64 { return int64(t.F_value) }

func (t *Byte) FloatValue__F() float32 { return float32(t.F_value) }

func (t *Byte) DoubleValue__D() float64 { return float64(t.F_value) }

func (t *Byte) ToString__String() *String { return Integer_ToString_I__String(int32(t.F_value)) }

func (t *Byte) HashCode__I() int32 { return Byte_HashCode_B__I(t.F_value) }

func Byte_HashCode_B__I(value int8) int32 { return int32(value) }

func (t *Byte) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1); var tmp2 int32 = int32(t.F_value); return tmp2 == int32(NN(b).ByteValue__B()) } else { return false
	} }
func (t *Byte) CompareTo_Byte__I(anotherByte *Byte) int32 {
	var tmp1 int8 = t.F_value; return Byte_Compare_B_B__I(tmp1, anotherByte.F_value)
}
func Byte_Compare_B_B__I(x, y int8) int32 {
	return int32(x) - int32(y)
}
func Byte_CompareUnsigned_B_B__I(x, y int8) int32 {
	return Byte_ToUnsignedInt_B__I(x) - Byte_ToUnsignedInt_B__I(y)
}
func Byte_ToUnsignedInt_B__I(x int8) int32 {
	return int32(x) & 255
}
func Byte_ToUnsignedLong_B__J(x int8) int64 {
	return int64(x) & 255
}


type Byte struct{ Number; F_value int8 }

func (t *Byte) Is_Comparable() {}

func (t *Byte) Is_Constable() {}

const Byte_MIN_VALUE int8 = -128

const Byte_MAX_VALUE int8 = 127

var Byte_TYPE *Class

const Byte_SIZE int32 = 8

const Byte_BYTES int32 = 1

const Byte_serialVersionUID int64 = -7183698231559129828

var Byte_init ClassInit

func Byte_Init() { if !Byte_init.Done() { Byte_init.Run(Byte_clinit) } }

func Byte_clinit() { Byte_TYPE = Class_GetPrimitiveClass_String__Class(Lit_108) }

func (t *Byte) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Byte__I(Byte_Cast(p0)) }

func (t *Byte) Ref() any { if t == nil { return nil }; return t }

func (t *Byte) GetClass__Class() *Class { return Byte_class }

func (t *Byte) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Byte) CloneShallow() any { panic(CloneNotSupported(t)) }

func Byte_InstanceOf(x any) bool { _, ok := x.(*Byte); return ok }

func Byte_Cast(x any) *Byte { if x == nil { return nil }; v, ok := x.(*Byte); if !ok { panic(ClassCast(x, Byte_class)) }; return v }



type Byte_ByteCache struct{ Object }

var Byte_ByteCache_cache *RefArray

var Byte_ByteCache_archivedCache *RefArray

var Byte_ByteCache_init ClassInit

func Byte_ByteCache_Init() { if !Byte_ByteCache_init.Done() { Byte_ByteCache_init.Run(Byte_ByteCache_clinit) } }

func Byte_ByteCache_clinit() {
//line :39:1
	CDS_InitializeFromArchive_Class__V(Byte_ByteCache_class)
	if Byte_ByteCache_archivedCache == nil {
		var c *RefArray = NewRefArray(Byte_class, 256)
		var value int8 = -128; var i int32 = 0
	L1: for {
		if i < 256 {
			var tmp1 int8
			var old_1 int8 = value

			value = int8(int32(value) + 1)
//line :47:1
			tmp1 = old_1
//line :45:1
			c.Store(i, Byte_New_B(tmp1))




			i = i + 1; continue L1 }
//line :43:1
		break L1
	}






		Byte_ByteCache_archivedCache = c }
	Byte_ByteCache_cache = Byte_ByteCache_archivedCache
	if !A2g_AssertionsDisabled && !(int32(len(Byte_ByteCache_cache.A)) == 256) { panic(Thrown(AssertionError_New()))
	}
}



























































































































func (t *Byte_ByteCache) Ref() any { if t == nil { return nil }; return t }

func (t *Byte_ByteCache) GetClass__Class() *Class { return Byte_ByteCache_class }

func (t *Byte_ByteCache) ToString__String() *String { return Object_toString(t) }

func (t *Byte_ByteCache) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Byte_ByteCache) CloneShallow() any { panic(CloneNotSupported(t)) }

func Byte_ByteCache_InstanceOf(x any) bool { _, ok := x.(*Byte_ByteCache); return ok }

func Byte_ByteCache_Cast(x any) *Byte_ByteCache { if x == nil { return nil }; v, ok := x.(*Byte_ByteCache); if !ok { panic(ClassCast(x, Byte_ByteCache_class)) }; return v }
