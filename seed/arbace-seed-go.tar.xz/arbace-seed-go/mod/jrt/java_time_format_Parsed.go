//line java_time_format_Parsed.ae:1
package jrt




































func Parsed_New() *Parsed { t := &Parsed{}; t.Ctor(); return t }
//line :38:1
func (t *Parsed) Ctor() { t.F_fieldValues = HashMap_New(); t.F_zoneNameType = -1; var tmp1 *Period; Period_Init(); tmp1 = Period_ZERO; t.F_excessDays = tmp1 }

func (t *Parsed) Copy__Parsed() *Parsed {
	var cloned *Parsed = Parsed_New()
	cloned.F_fieldValues.PutAll_Map__V(t.F_fieldValues)
	cloned.F_zone = t.F_zone
	cloned.F_zoneNameType = t.F_zoneNameType
	cloned.F_chrono = t.F_chrono
	cloned.F_leapSecond = t.F_leapSecond
	cloned.F_dayPeriod = t.F_dayPeriod
//line :41:1
	return cloned
}







func (t *Parsed) IsSupported_TemporalField__Z(field TemporalField) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = t.F_fieldValues.ContainsKey_O__Z(field); if !tmp3 { var tmp4 bool; tmp4 = !(t.F_date == nil); if tmp4 { tmp4 = t.F_date.IsSupported_TemporalField__Z(field) }; tmp3 = tmp4 }; tmp2 = tmp3; if !tmp2 {
		var tmp5 bool; tmp5 = !(t.F_time == nil); if tmp5 { tmp5 = NN(t.F_time).IsSupported_TemporalField__Z(field) }; tmp2 = tmp5 }
//line :51:1
	tmp1 = tmp2; if tmp1 { return true } else {


		var tmp6 bool; var tmp7 bool; tmp7 = !(field == nil); if tmp7 { tmp7 = !ChronoField_InstanceOf(field) }; tmp6 = tmp7; if tmp6 { tmp6 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp6
	} }
func (t *Parsed) GetLong_TemporalField__J(field TemporalField) int64 {
	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	var value *Long = Long_Cast(t.F_fieldValues.Get_O__O(field))
	if !(value == nil) { return NN(value).LongValue__J() } else { var tmp1 bool; var tmp2 bool

		tmp2 = !(t.F_date == nil); if tmp2 { tmp2 = t.F_date.IsSupported_TemporalField__Z(field) }; tmp1 = tmp2
//line :59:1
		if tmp1 {

			return t.F_date.GetLong_TemporalField__J(field) } else {
//line :59:1
				var tmp3 bool; var tmp4 bool


				tmp4 = !(t.F_time == nil); if tmp4 { tmp4 = NN(t.F_time).IsSupported_TemporalField__Z(field) }; tmp3 = tmp4
//line :59:1
				if tmp3 {


					return NN(t.F_time).GetLong_TemporalField__J(field) } else {


						if ChronoField_InstanceOf(field) {
							panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
						return field.GetFrom_TemporalAccessor__J(t)
					} } } }
func (t *Parsed) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_ZoneId__TemporalQuery() { return t.F_zone } else { if query == TemporalQueries_Chronology__TemporalQuery() { return t.F_chrono } else { if query == TemporalQueries_LocalDate__TemporalQuery() {



		if !(t.F_date == nil) { return LocalDate_From_TemporalAccessor__LocalDate(t.F_date).Ref() } else { return nil } } else {
//line :70:1
			if query == TemporalQueries_LocalTime__TemporalQuery() { return t.F_time.Ref() } else { if query == TemporalQueries_Offset__TemporalQuery() {






				var offsetSecs *Long; var tmp1 Map = t.F_fieldValues; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_OFFSET_SECONDS; offsetSecs = Long_Cast(tmp1.Get_O__O(tmp2.Ref()))
				if !(offsetSecs == nil) {
					return ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(offsetSecs).IntValue__I()).Ref() } else {
//line :78:1
						if ZoneOffset_InstanceOf(t.F_zone) { return t.F_zone } else {


							return query.QueryFrom_TemporalAccessor__O(t) } } } else {
//line :70:1
								if query == TemporalQueries_Zone__TemporalQuery() {











									return query.QueryFrom_TemporalAccessor__O(t) } else {
										if query == TemporalQueries_Precision__TemporalQuery() { return nil } else { return query.QueryFrom_TemporalAccessor__O(t)
										} } } } } } } }
func (t *Parsed) Resolve_ResolverStyle_Set__TemporalAccessor(resolverStyle *ResolverStyle, resolverFields Set) TemporalAccessor {

	if !(resolverFields == nil) { t.F_fieldValues.KeySet__Set().RetainAll_Collection__Z(resolverFields) }
	t.F_resolverStyle = resolverStyle
	t.ResolveFields__V()
	t.ResolveTimeLenient__V()
	t.CrossCheck__V()
	t.ResolvePeriod__V()
	t.ResolveFractional__V()
	t.ResolveInstant__V()
//line :85:1
	return t
}










func (t *Parsed) ResolveFields__V() {
	t.ResolveInstantFields__V()
	t.ResolveDateFields__V()
	t.ResolveTimeFields__V()
	if t.F_fieldValues.Size__I() > 0 {
		var changedCount int32 = 0
	L2: for { if changedCount < 50 {

		var i_101673 Iterator = t.F_fieldValues.EntrySet__Set().Iterator__Iterator(); for i_101673.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101673.Next__O()); var targetField TemporalField = TemporalField_Cast(entry.GetKey__O()); var resolvedObject TemporalAccessor = targetField.Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(t.F_fieldValues, t, t.F_resolverStyle)


			if !(resolvedObject == nil) {

				var tmp1 TemporalAccessor = resolvedObject; if ChronoZonedDateTime_InstanceOf(tmp1) { var czdt ChronoZonedDateTime = ChronoZonedDateTime_Cast(tmp1)
					if t.F_zone == nil {
						t.F_zone = czdt.GetZone__ZoneId() } else {
//line :111:1
							var tmp2 ZoneId_I = t.F_zone; if tmp2.Equals_O__Z(czdt.GetZone__ZoneId()) == false {


								panic(Thrown(DateTimeException_New_String(Concat(Lit_2374, StrOfObj(t.F_zone)))))
							}
						}

					resolvedObject = czdt.ToLocalDateTime__ChronoLocalDateTime() } else { }
				var tmp3 TemporalAccessor = resolvedObject; if ChronoLocalDateTime_InstanceOf(tmp3) { var cldt ChronoLocalDateTime = ChronoLocalDateTime_Cast(tmp3); var tmp4 *LocalTime = cldt.ToLocalTime__LocalTime(); var tmp5 *Period
					Period_Init(); tmp5 = Period_ZERO; t.UpdateCheckConflict_LocalTime_Period__V(tmp4, tmp5)
					t.UpdateCheckConflict_ChronoLocalDate__V(cldt.ToLocalDate__ChronoLocalDate())
					changedCount = changedCount + 1
					continue L2 } else { }
				if ChronoLocalDate_InstanceOf(resolvedObject) {
					t.UpdateCheckConflict_ChronoLocalDate__V(ChronoLocalDate_Cast(resolvedObject))
					changedCount = changedCount + 1
					continue L2 }
				if LocalTime_InstanceOf(resolvedObject) {
					var tmp6 *LocalTime = LocalTime_Cast(resolvedObject); var tmp7 *Period; Period_Init(); tmp7 = Period_ZERO; t.UpdateCheckConflict_LocalTime_Period__V(tmp6, tmp7)
					changedCount = changedCount + 1
					continue L2 }
				panic(Thrown(DateTimeException_New_String(Lit_2375))) } else {


					if t.F_fieldValues.ContainsKey_O__Z(targetField) == false {
						changedCount = changedCount + 1
						continue L2 } } }
		break L2
//line :103:1
		continue L2 }; break L2
	}


































		if changedCount == 50 {
			panic(Thrown(DateTimeException_New_String(Lit_2376)))
		}
		if changedCount > 0 {
			t.ResolveInstantFields__V()
			t.ResolveDateFields__V()
			t.ResolveTimeFields__V()
		} } }
func (t *Parsed) UpdateCheckConflict_TemporalField_TemporalField_Long__V(targetField, changeField TemporalField, changeValue *Long) {

	var old *Long = Long_Cast(t.F_fieldValues.Put_O_O__O(changeField, changeValue.Ref())); var tmp1 bool; var tmp2 bool
	tmp2 = !(old == nil); if tmp2 { tmp2 = !(NN(old).LongValue__J() == NN(changeValue).LongValue__J()) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2185, StrOfObj(changeField), Lit_115, StrOfObj(old.Ref()), Lit_2186, StrOfObj(changeField), Lit_115, StrOfObj(changeValue.Ref()), Lit_2377, StrOfObj(targetField)))))
	}
}









func (t *Parsed) ResolveInstantFields__V() {
	var tmp1 Map = t.F_fieldValues; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_INSTANT_SECONDS; if tmp1.ContainsKey_O__Z(tmp2.Ref()) {
		if !(t.F_zone == nil) {
			t.ResolveInstantFields0_ZoneId__V(t.F_zone) } else {
				var offsetSecs *Long; var tmp3 Map = t.F_fieldValues; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_OFFSET_SECONDS; offsetSecs = Long_Cast(tmp3.Get_O__O(tmp4.Ref()))
				if !(offsetSecs == nil) {
					var offset *ZoneOffset = ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(offsetSecs).IntValue__I())
					t.ResolveInstantFields0_ZoneId__V(Up_ZoneOffset_ZoneId(offset))
				} } } }
func (t *Parsed) ResolveInstantFields0_ZoneId__V(selectedZone ZoneId_I) {
	var instant *Instant; var tmp1 Map = t.F_fieldValues; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_INSTANT_SECONDS; instant = Instant_OfEpochSecond_J__Instant(NN(Long_Cast(tmp1.Get_O__O(tmp2.Ref()))).LongValue__J()); var zdt ChronoZonedDateTime = t.F_chrono.ZonedDateTime_Instant_ZoneId__ChronoZonedDateTime(instant, selectedZone)


	t.UpdateCheckConflict_ChronoLocalDate__V(zdt.ToLocalDate__ChronoLocalDate())
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_INSTANT_SECONDS; var tmp4 TemporalField = Up_ChronoField_TemporalField(tmp3); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_SECOND_OF_DAY; var tmp6 TemporalField = Up_ChronoField_TemporalField(tmp5); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp4, tmp6, Long_ValueOf_J__Long(int64(NN(zdt.ToLocalTime__LocalTime()).ToSecondOfDay__I())))



	var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_INSTANT_SECONDS; var tmp8 TemporalField = Up_ChronoField_TemporalField(tmp7); var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_OFFSET_SECONDS; var tmp10 TemporalField = Up_ChronoField_TemporalField(tmp9); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp8, tmp10, Long_ValueOf_J__Long(int64(NN(zdt.GetOffset__ZoneOffset()).GetTotalSeconds__I())))
}



func (t *Parsed) ResolveDateFields__V() {
	t.UpdateCheckConflict_ChronoLocalDate__V(t.F_chrono.ResolveDate_Map_ResolverStyle__ChronoLocalDate(t.F_fieldValues, t.F_resolverStyle))
}
func (t *Parsed) UpdateCheckConflict_ChronoLocalDate__V(cld ChronoLocalDate) {
	if !(t.F_date == nil) {
		var tmp1 bool; var tmp2 bool; tmp2 = !(cld == nil); if tmp2 { tmp2 = t.F_date.Equals_O__Z(cld) == false }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(DateTimeException_New_String(Concat(Lit_2378, StrOfObj(t.F_date), Lit_115, StrOfObj(cld))))) } } else {




				if !(cld == nil) {
					var tmp3 Chronology = t.F_chrono; if tmp3.Equals_O__Z(cld.GetChronology__Chronology()) == false {
						panic(Thrown(DateTimeException_New_String(Concat(Lit_2379, StrOfObj(t.F_chrono)))))
					}

					t.F_date = cld
				} } }
func (t *Parsed) ResolveTimeFields__V() {
	var tmp1 Map = t.F_fieldValues; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_CLOCK_HOUR_OF_DAY; if tmp1.ContainsKey_O__Z(tmp2.Ref()) {
		var ch int64; var tmp3 Map = t.F_fieldValues; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_CLOCK_HOUR_OF_DAY; ch = NN(Long_Cast(tmp3.Remove_O__O(tmp4.Ref()))).LongValue__J()
		var tmp5 bool; var tmp6 bool; var tmp7 *ResolverStyle = t.F_resolverStyle; var tmp8 *ResolverStyle; ResolverStyle_Init(); tmp8 = ResolverStyle_STRICT; tmp6 = tmp7 == tmp8; if !tmp6 {
			var tmp9 bool; var tmp10 *ResolverStyle = t.F_resolverStyle; var tmp11 *ResolverStyle; ResolverStyle_Init(); tmp11 = ResolverStyle_SMART; tmp9 = tmp10 == tmp11; if tmp9 { tmp9 = !(ch == 0) }; tmp6 = tmp9 }
//line :207:1
		tmp5 = tmp6; if tmp5 {

			var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_CLOCK_HOUR_OF_DAY; NN(tmp12).CheckValidValue_J__J(ch) }
		var tmp13 *ChronoField; ChronoField_Init(); tmp13 = ChronoField_CLOCK_HOUR_OF_DAY; var tmp14 TemporalField = Up_ChronoField_TemporalField(tmp13); var tmp15 *ChronoField; ChronoField_Init(); tmp15 = ChronoField_HOUR_OF_DAY; var tmp16 TemporalField = Up_ChronoField_TemporalField(tmp15); var tmp17 *Long


		if ch == 24 { tmp17 = Long_ValueOf_J__Long(0) } else { tmp17 = Long_ValueOf_J__Long(ch) }
//line :210:1
		t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp14, tmp16, tmp17)
	}


	var tmp18 Map = t.F_fieldValues; var tmp19 *ChronoField; ChronoField_Init(); tmp19 = ChronoField_CLOCK_HOUR_OF_AMPM; if tmp18.ContainsKey_O__Z(tmp19.Ref()) {
		var ch_2 int64; var tmp20 Map = t.F_fieldValues; var tmp21 *ChronoField; ChronoField_Init(); tmp21 = ChronoField_CLOCK_HOUR_OF_AMPM; ch_2 = NN(Long_Cast(tmp20.Remove_O__O(tmp21.Ref()))).LongValue__J()
		var tmp22 bool; var tmp23 bool; var tmp24 *ResolverStyle = t.F_resolverStyle; var tmp25 *ResolverStyle; ResolverStyle_Init(); tmp25 = ResolverStyle_STRICT; tmp23 = tmp24 == tmp25; if !tmp23 {
			var tmp26 bool; var tmp27 *ResolverStyle = t.F_resolverStyle; var tmp28 *ResolverStyle; ResolverStyle_Init(); tmp28 = ResolverStyle_SMART; tmp26 = tmp27 == tmp28; if tmp26 { tmp26 = !(ch_2 == 0) }; tmp23 = tmp26 }
//line :216:1
		tmp22 = tmp23; if tmp22 {

			var tmp29 *ChronoField; ChronoField_Init(); tmp29 = ChronoField_CLOCK_HOUR_OF_AMPM; NN(tmp29).CheckValidValue_J__J(ch_2) }
		var tmp30 *ChronoField; ChronoField_Init(); tmp30 = ChronoField_CLOCK_HOUR_OF_AMPM; var tmp31 TemporalField = Up_ChronoField_TemporalField(tmp30); var tmp32 *ChronoField; ChronoField_Init(); tmp32 = ChronoField_HOUR_OF_AMPM; var tmp33 TemporalField = Up_ChronoField_TemporalField(tmp32); var tmp34 *Long


		if ch_2 == 12 { tmp34 = Long_ValueOf_J__Long(0) } else { tmp34 = Long_ValueOf_J__Long(ch_2) }
//line :219:1
		t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp31, tmp33, tmp34)
	}


	var tmp35 bool; var tmp36 bool; var tmp37 Map = t.F_fieldValues; var tmp38 *ChronoField; ChronoField_Init(); tmp38 = ChronoField_AMPM_OF_DAY; tmp36 = tmp37.ContainsKey_O__Z(tmp38.Ref()); if tmp36 {
		var tmp39 Map = t.F_fieldValues; var tmp40 *ChronoField; ChronoField_Init(); tmp40 = ChronoField_HOUR_OF_AMPM; tmp36 = tmp39.ContainsKey_O__Z(tmp40.Ref()) }
//line :223:1
	tmp35 = tmp36; if tmp35 {

		var ap int64; var tmp41 Map = t.F_fieldValues; var tmp42 *ChronoField; ChronoField_Init(); tmp42 = ChronoField_AMPM_OF_DAY; ap = NN(Long_Cast(tmp41.Remove_O__O(tmp42.Ref()))).LongValue__J(); var hap int64; var tmp43 Map = t.F_fieldValues; var tmp44 *ChronoField
		ChronoField_Init(); tmp44 = ChronoField_HOUR_OF_AMPM; hap = NN(Long_Cast(tmp43.Remove_O__O(tmp44.Ref()))).LongValue__J()
		var tmp45 *ResolverStyle = t.F_resolverStyle; var tmp46 *ResolverStyle; ResolverStyle_Init(); tmp46 = ResolverStyle_LENIENT; if tmp45 == tmp46 {
			var tmp47 *ChronoField; ChronoField_Init(); tmp47 = ChronoField_AMPM_OF_DAY; var tmp48 TemporalField = Up_ChronoField_TemporalField(tmp47); var tmp49 *ChronoField; ChronoField_Init(); tmp49 = ChronoField_HOUR_OF_DAY; var tmp50 TemporalField = Up_ChronoField_TemporalField(tmp49); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp48, tmp50, Long_ValueOf_J__Long(Math_AddExact_J_J__J(Math_MultiplyExact_J_I__J(ap, 12), hap))) } else {




				var tmp51 *ChronoField; ChronoField_Init(); tmp51 = ChronoField_AMPM_OF_DAY; NN(tmp51).CheckValidValue_J__J(ap)
				var tmp52 *ChronoField; ChronoField_Init(); tmp52 = ChronoField_HOUR_OF_AMPM; NN(tmp52).CheckValidValue_J__J(hap)
				var tmp53 *ChronoField; ChronoField_Init(); tmp53 = ChronoField_AMPM_OF_DAY; var tmp54 TemporalField = Up_ChronoField_TemporalField(tmp53); var tmp55 *ChronoField; ChronoField_Init(); tmp55 = ChronoField_HOUR_OF_DAY; t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp54, Up_ChronoField_TemporalField(tmp55), Long_ValueOf_J__Long(ap*12+hap))
			}
	}

	var tmp56 Map = t.F_fieldValues; var tmp57 *ChronoField; ChronoField_Init(); tmp57 = ChronoField_NANO_OF_DAY; if tmp56.ContainsKey_O__Z(tmp57.Ref()) {
		var nod int64; var tmp58 Map = t.F_fieldValues; var tmp59 *ChronoField; ChronoField_Init(); tmp59 = ChronoField_NANO_OF_DAY; nod = NN(Long_Cast(tmp58.Remove_O__O(tmp59.Ref()))).LongValue__J()
		var tmp60 *ResolverStyle = t.F_resolverStyle; var tmp61 *ResolverStyle; ResolverStyle_Init(); tmp61 = ResolverStyle_LENIENT; if tmp60 == tmp61 { } else {
			var tmp62 *ChronoField; ChronoField_Init(); tmp62 = ChronoField_NANO_OF_DAY; NN(tmp62).CheckValidValue_J__J(nod) }
		var tmp63 *ChronoField; ChronoField_Init(); tmp63 = ChronoField_NANO_OF_DAY; var tmp64 TemporalField = Up_ChronoField_TemporalField(tmp63); var tmp65 *ChronoField; ChronoField_Init(); tmp65 = ChronoField_HOUR_OF_DAY; var tmp66 TemporalField = Up_ChronoField_TemporalField(tmp65); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp64, tmp66, Long_ValueOf_J__Long(nod/3600000000000))



		var tmp67 *ChronoField; ChronoField_Init(); tmp67 = ChronoField_NANO_OF_DAY; var tmp68 TemporalField = Up_ChronoField_TemporalField(tmp67); var tmp69 *ChronoField; ChronoField_Init(); tmp69 = ChronoField_MINUTE_OF_HOUR; var tmp70 TemporalField = Up_ChronoField_TemporalField(tmp69); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp68, tmp70, Long_ValueOf_J__Long(nod/60000000000%60))



		var tmp71 *ChronoField; ChronoField_Init(); tmp71 = ChronoField_NANO_OF_DAY; var tmp72 TemporalField = Up_ChronoField_TemporalField(tmp71); var tmp73 *ChronoField; ChronoField_Init(); tmp73 = ChronoField_SECOND_OF_MINUTE; var tmp74 TemporalField = Up_ChronoField_TemporalField(tmp73); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp72, tmp74, Long_ValueOf_J__Long(nod/1000000000%60))



		var tmp75 *ChronoField; ChronoField_Init(); tmp75 = ChronoField_NANO_OF_DAY; var tmp76 TemporalField = Up_ChronoField_TemporalField(tmp75); var tmp77 *ChronoField; ChronoField_Init(); tmp77 = ChronoField_NANO_OF_SECOND; var tmp78 TemporalField = Up_ChronoField_TemporalField(tmp77); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp76, tmp78, Long_ValueOf_J__Long(nod%1000000000))
	}


	var tmp79 Map = t.F_fieldValues; var tmp80 *ChronoField; ChronoField_Init(); tmp80 = ChronoField_MICRO_OF_DAY; if tmp79.ContainsKey_O__Z(tmp80.Ref()) {
		var cod int64; var tmp81 Map = t.F_fieldValues; var tmp82 *ChronoField; ChronoField_Init(); tmp82 = ChronoField_MICRO_OF_DAY; cod = NN(Long_Cast(tmp81.Remove_O__O(tmp82.Ref()))).LongValue__J()
		var tmp83 *ResolverStyle = t.F_resolverStyle; var tmp84 *ResolverStyle; ResolverStyle_Init(); tmp84 = ResolverStyle_LENIENT; if tmp83 == tmp84 { } else {
			var tmp85 *ChronoField; ChronoField_Init(); tmp85 = ChronoField_MICRO_OF_DAY; NN(tmp85).CheckValidValue_J__J(cod) }
		var tmp86 *ChronoField; ChronoField_Init(); tmp86 = ChronoField_MICRO_OF_DAY; var tmp87 TemporalField = Up_ChronoField_TemporalField(tmp86); var tmp88 *ChronoField; ChronoField_Init(); tmp88 = ChronoField_SECOND_OF_DAY; var tmp89 TemporalField = Up_ChronoField_TemporalField(tmp88); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp87, tmp89, Long_ValueOf_J__Long(cod/1000000))



		var tmp90 *ChronoField; ChronoField_Init(); tmp90 = ChronoField_MICRO_OF_DAY; var tmp91 TemporalField = Up_ChronoField_TemporalField(tmp90); var tmp92 *ChronoField; ChronoField_Init(); tmp92 = ChronoField_MICRO_OF_SECOND; var tmp93 TemporalField = Up_ChronoField_TemporalField(tmp92); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp91, tmp93, Long_ValueOf_J__Long(cod%1000000))
	}


	var tmp94 Map = t.F_fieldValues; var tmp95 *ChronoField; ChronoField_Init(); tmp95 = ChronoField_MILLI_OF_DAY; if tmp94.ContainsKey_O__Z(tmp95.Ref()) {
		var lod int64; var tmp96 Map = t.F_fieldValues; var tmp97 *ChronoField; ChronoField_Init(); tmp97 = ChronoField_MILLI_OF_DAY; lod = NN(Long_Cast(tmp96.Remove_O__O(tmp97.Ref()))).LongValue__J()
		var tmp98 *ResolverStyle = t.F_resolverStyle; var tmp99 *ResolverStyle; ResolverStyle_Init(); tmp99 = ResolverStyle_LENIENT; if tmp98 == tmp99 { } else {
			var tmp100 *ChronoField; ChronoField_Init(); tmp100 = ChronoField_MILLI_OF_DAY; NN(tmp100).CheckValidValue_J__J(lod) }
		var tmp101 *ChronoField; ChronoField_Init(); tmp101 = ChronoField_MILLI_OF_DAY; var tmp102 TemporalField = Up_ChronoField_TemporalField(tmp101); var tmp103 *ChronoField; ChronoField_Init(); tmp103 = ChronoField_SECOND_OF_DAY; var tmp104 TemporalField = Up_ChronoField_TemporalField(tmp103); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp102, tmp104, Long_ValueOf_J__Long(lod/1000))



		var tmp105 *ChronoField; ChronoField_Init(); tmp105 = ChronoField_MILLI_OF_DAY; var tmp106 TemporalField = Up_ChronoField_TemporalField(tmp105); var tmp107 *ChronoField; ChronoField_Init(); tmp107 = ChronoField_MILLI_OF_SECOND; var tmp108 TemporalField = Up_ChronoField_TemporalField(tmp107); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp106, tmp108, Long_ValueOf_J__Long(lod%1000))
	}


	var tmp109 Map = t.F_fieldValues; var tmp110 *ChronoField; ChronoField_Init(); tmp110 = ChronoField_SECOND_OF_DAY; if tmp109.ContainsKey_O__Z(tmp110.Ref()) {
		var sod int64; var tmp111 Map = t.F_fieldValues; var tmp112 *ChronoField; ChronoField_Init(); tmp112 = ChronoField_SECOND_OF_DAY; sod = NN(Long_Cast(tmp111.Remove_O__O(tmp112.Ref()))).LongValue__J()
		var tmp113 *ResolverStyle = t.F_resolverStyle; var tmp114 *ResolverStyle; ResolverStyle_Init(); tmp114 = ResolverStyle_LENIENT; if tmp113 == tmp114 { } else {
			var tmp115 *ChronoField; ChronoField_Init(); tmp115 = ChronoField_SECOND_OF_DAY; NN(tmp115).CheckValidValue_J__J(sod) }
		var tmp116 *ChronoField; ChronoField_Init(); tmp116 = ChronoField_SECOND_OF_DAY; var tmp117 TemporalField = Up_ChronoField_TemporalField(tmp116); var tmp118 *ChronoField; ChronoField_Init(); tmp118 = ChronoField_HOUR_OF_DAY; var tmp119 TemporalField = Up_ChronoField_TemporalField(tmp118); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp117, tmp119, Long_ValueOf_J__Long(sod/3600))



		var tmp120 *ChronoField; ChronoField_Init(); tmp120 = ChronoField_SECOND_OF_DAY; var tmp121 TemporalField = Up_ChronoField_TemporalField(tmp120); var tmp122 *ChronoField; ChronoField_Init(); tmp122 = ChronoField_MINUTE_OF_HOUR; var tmp123 TemporalField = Up_ChronoField_TemporalField(tmp122); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp121, tmp123, Long_ValueOf_J__Long(sod/60%60))



		var tmp124 *ChronoField; ChronoField_Init(); tmp124 = ChronoField_SECOND_OF_DAY; var tmp125 TemporalField = Up_ChronoField_TemporalField(tmp124); var tmp126 *ChronoField; ChronoField_Init(); tmp126 = ChronoField_SECOND_OF_MINUTE; var tmp127 TemporalField = Up_ChronoField_TemporalField(tmp126); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp125, tmp127, Long_ValueOf_J__Long(sod%60))
	}


	var tmp128 Map = t.F_fieldValues; var tmp129 *ChronoField; ChronoField_Init(); tmp129 = ChronoField_MINUTE_OF_DAY; if tmp128.ContainsKey_O__Z(tmp129.Ref()) {
		var mod int64; var tmp130 Map = t.F_fieldValues; var tmp131 *ChronoField; ChronoField_Init(); tmp131 = ChronoField_MINUTE_OF_DAY; mod = NN(Long_Cast(tmp130.Remove_O__O(tmp131.Ref()))).LongValue__J()
		var tmp132 *ResolverStyle = t.F_resolverStyle; var tmp133 *ResolverStyle; ResolverStyle_Init(); tmp133 = ResolverStyle_LENIENT; if tmp132 == tmp133 { } else {
			var tmp134 *ChronoField; ChronoField_Init(); tmp134 = ChronoField_MINUTE_OF_DAY; NN(tmp134).CheckValidValue_J__J(mod) }
		var tmp135 *ChronoField; ChronoField_Init(); tmp135 = ChronoField_MINUTE_OF_DAY; var tmp136 TemporalField = Up_ChronoField_TemporalField(tmp135); var tmp137 *ChronoField; ChronoField_Init(); tmp137 = ChronoField_HOUR_OF_DAY; var tmp138 TemporalField = Up_ChronoField_TemporalField(tmp137); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp136, tmp138, Long_ValueOf_J__Long(mod/60))



		var tmp139 *ChronoField; ChronoField_Init(); tmp139 = ChronoField_MINUTE_OF_DAY; var tmp140 TemporalField = Up_ChronoField_TemporalField(tmp139); var tmp141 *ChronoField; ChronoField_Init(); tmp141 = ChronoField_MINUTE_OF_HOUR; var tmp142 TemporalField = Up_ChronoField_TemporalField(tmp141); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp140, tmp142, Long_ValueOf_J__Long(mod%60))
	}


	var tmp143 Map = t.F_fieldValues; var tmp144 *ChronoField; ChronoField_Init(); tmp144 = ChronoField_NANO_OF_SECOND; if tmp143.ContainsKey_O__Z(tmp144.Ref()) {
		var nos int64; var tmp145 Map = t.F_fieldValues; var tmp146 *ChronoField; ChronoField_Init(); tmp146 = ChronoField_NANO_OF_SECOND; nos = NN(Long_Cast(tmp145.Get_O__O(tmp146.Ref()))).LongValue__J()
		var tmp147 *ResolverStyle = t.F_resolverStyle; var tmp148 *ResolverStyle; ResolverStyle_Init(); tmp148 = ResolverStyle_LENIENT; if tmp147 == tmp148 { } else {
			var tmp149 *ChronoField; ChronoField_Init(); tmp149 = ChronoField_NANO_OF_SECOND; NN(tmp149).CheckValidValue_J__J(nos) }
		var tmp150 Map = t.F_fieldValues; var tmp151 *ChronoField; ChronoField_Init(); tmp151 = ChronoField_MICRO_OF_SECOND; if tmp150.ContainsKey_O__Z(tmp151.Ref()) {
			var cos int64; var tmp152 Map = t.F_fieldValues; var tmp153 *ChronoField; ChronoField_Init(); tmp153 = ChronoField_MICRO_OF_SECOND; cos = NN(Long_Cast(tmp152.Remove_O__O(tmp153.Ref()))).LongValue__J()
			var tmp154 *ResolverStyle = t.F_resolverStyle; var tmp155 *ResolverStyle; ResolverStyle_Init(); tmp155 = ResolverStyle_LENIENT; if tmp154 == tmp155 { } else {
				var tmp156 *ChronoField; ChronoField_Init(); tmp156 = ChronoField_MICRO_OF_SECOND; NN(tmp156).CheckValidValue_J__J(cos) }
			nos = cos*1000 + nos%1000
			var tmp157 *ChronoField; ChronoField_Init(); tmp157 = ChronoField_MICRO_OF_SECOND; var tmp158 TemporalField = Up_ChronoField_TemporalField(tmp157); var tmp159 *ChronoField; ChronoField_Init(); tmp159 = ChronoField_NANO_OF_SECOND; t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp158, Up_ChronoField_TemporalField(tmp159), Long_ValueOf_J__Long(nos)) }
		var tmp160 Map = t.F_fieldValues; var tmp161 *ChronoField; ChronoField_Init(); tmp161 = ChronoField_MILLI_OF_SECOND; if tmp160.ContainsKey_O__Z(tmp161.Ref()) {
			var los int64; var tmp162 Map = t.F_fieldValues; var tmp163 *ChronoField; ChronoField_Init(); tmp163 = ChronoField_MILLI_OF_SECOND; los = NN(Long_Cast(tmp162.Remove_O__O(tmp163.Ref()))).LongValue__J()
			var tmp164 *ResolverStyle = t.F_resolverStyle; var tmp165 *ResolverStyle; ResolverStyle_Init(); tmp165 = ResolverStyle_LENIENT; if tmp164 == tmp165 { } else {
				var tmp166 *ChronoField; ChronoField_Init(); tmp166 = ChronoField_MILLI_OF_SECOND; NN(tmp166).CheckValidValue_J__J(los) }
			var tmp167 *ChronoField; ChronoField_Init(); tmp167 = ChronoField_MILLI_OF_SECOND; var tmp168 TemporalField = Up_ChronoField_TemporalField(tmp167); var tmp169 *ChronoField; ChronoField_Init(); tmp169 = ChronoField_NANO_OF_SECOND; var tmp170 TemporalField = Up_ChronoField_TemporalField(tmp169); t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp168, tmp170, Long_ValueOf_J__Long(los*1000000+nos%1000000))
		}
	}



	var tmp171 bool; var tmp172 bool; tmp172 = !(t.F_dayPeriod == nil); if tmp172 { var tmp173 Map = t.F_fieldValues; var tmp174 *ChronoField; ChronoField_Init(); tmp174 = ChronoField_HOUR_OF_AMPM; tmp172 = tmp173.ContainsKey_O__Z(tmp174.Ref()) }; tmp171 = tmp172; if tmp171 {
		var hoap int64; var tmp175 Map = t.F_fieldValues; var tmp176 *ChronoField; ChronoField_Init(); tmp176 = ChronoField_HOUR_OF_AMPM; hoap = NN(Long_Cast(tmp175.Remove_O__O(tmp176.Ref()))).LongValue__J()
		var tmp177 *ResolverStyle = t.F_resolverStyle; var tmp178 *ResolverStyle; ResolverStyle_Init(); tmp178 = ResolverStyle_LENIENT; if tmp177 == tmp178 { } else {
			var tmp179 *ChronoField; ChronoField_Init(); tmp179 = ChronoField_HOUR_OF_AMPM; NN(tmp179).CheckValidValue_J__J(hoap) }
		var mohObj *Long; var tmp180 Map = t.F_fieldValues; var tmp181 *ChronoField; ChronoField_Init(); tmp181 = ChronoField_MINUTE_OF_HOUR; mohObj = Long_Cast(tmp180.Get_O__O(tmp181.Ref())); var moh int64
		if !(mohObj == nil) { moh = int64(Math_FloorMod_J_I__I(NN(mohObj).LongValue__J(), 60)) } else { moh = 0 }
//line :335:1
		var excessHours int64; var tmp182 *DateTimeFormatterBuilder_DayPeriod = t.F_dayPeriod

		if NN(tmp182).Includes_J__Z(int64((Math_FloorMod_J_I__I(hoap, 12)+12)*60) + moh) { excessHours = 12 } else { excessHours = 0 }
//line :335:1
		var hod int64 = Math_AddExact_J_J__J(hoap, excessHours); var tmp183 *ChronoField












		ChronoField_Init(); tmp183 = ChronoField_HOUR_OF_AMPM; var tmp184 TemporalField = Up_ChronoField_TemporalField(tmp183); var tmp185 *ChronoField; ChronoField_Init(); tmp185 = ChronoField_HOUR_OF_DAY; t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp184, Up_ChronoField_TemporalField(tmp185), Long_ValueOf_J__Long(hod))
		t.F_dayPeriod = nil }
	var tmp186 bool; var tmp187 bool; var tmp188 bool; var tmp189 bool; var tmp190 Map = t.F_fieldValues; var tmp191 *ChronoField; ChronoField_Init(); tmp191 = ChronoField_HOUR_OF_DAY; tmp189 = tmp190.ContainsKey_O__Z(tmp191.Ref()); if tmp189 {
		var tmp192 Map = t.F_fieldValues; var tmp193 *ChronoField; ChronoField_Init(); tmp193 = ChronoField_MINUTE_OF_HOUR; tmp189 = tmp192.ContainsKey_O__Z(tmp193.Ref()) }
//line :350:1
	tmp188 = tmp189; if tmp188 {

		var tmp194 Map = t.F_fieldValues; var tmp195 *ChronoField; ChronoField_Init(); tmp195 = ChronoField_SECOND_OF_MINUTE; tmp188 = tmp194.ContainsKey_O__Z(tmp195.Ref()) }
//line :350:1
	tmp187 = tmp188; if tmp187 {


		var tmp196 Map = t.F_fieldValues; var tmp197 *ChronoField; ChronoField_Init(); tmp197 = ChronoField_NANO_OF_SECOND; tmp187 = tmp196.ContainsKey_O__Z(tmp197.Ref()) }
//line :350:1
	tmp186 = tmp187; if tmp186 {



		var hod_2 int64; var tmp198 Map = t.F_fieldValues; var tmp199 *ChronoField; ChronoField_Init(); tmp199 = ChronoField_HOUR_OF_DAY; hod_2 = NN(Long_Cast(tmp198.Remove_O__O(tmp199.Ref()))).LongValue__J(); var moh_2 int64; var tmp200 Map = t.F_fieldValues; var tmp201 *ChronoField
		ChronoField_Init(); tmp201 = ChronoField_MINUTE_OF_HOUR; moh_2 = NN(Long_Cast(tmp200.Remove_O__O(tmp201.Ref()))).LongValue__J()
//line :354:1
		var som int64; var tmp202 Map = t.F_fieldValues; var tmp203 *ChronoField

		ChronoField_Init(); tmp203 = ChronoField_SECOND_OF_MINUTE; som = NN(Long_Cast(tmp202.Remove_O__O(tmp203.Ref()))).LongValue__J()
//line :354:1
		var nos_2 int64; var tmp204 Map = t.F_fieldValues; var tmp205 *ChronoField


		ChronoField_Init(); tmp205 = ChronoField_NANO_OF_SECOND; nos_2 = NN(Long_Cast(tmp204.Remove_O__O(tmp205.Ref()))).LongValue__J()
		t.ResolveTime_J_J_J_J__V(hod_2, moh_2, som, nos_2)
	} }
func (t *Parsed) ResolveTimeLenient__V() {
	if t.F_time == nil {
		var tmp1 Map = t.F_fieldValues; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MILLI_OF_SECOND; if tmp1.ContainsKey_O__Z(tmp2.Ref()) {

			var los int64; var tmp3 Map = t.F_fieldValues; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_MILLI_OF_SECOND; los = NN(Long_Cast(tmp3.Remove_O__O(tmp4.Ref()))).LongValue__J()
			var tmp5 Map = t.F_fieldValues; var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_MICRO_OF_SECOND; if tmp5.ContainsKey_O__Z(tmp6.Ref()) {
				var cos int64; var tmp7 int64 = los * 1000; var tmp8 Map = t.F_fieldValues; var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_MICRO_OF_SECOND; cos = tmp7 + NN(Long_Cast(tmp8.Get_O__O(tmp9.Ref()))).LongValue__J()%1000






				var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_MILLI_OF_SECOND; var tmp11 TemporalField = Up_ChronoField_TemporalField(tmp10); var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_MICRO_OF_SECOND; t.UpdateCheckConflict_TemporalField_TemporalField_Long__V(tmp11, Up_ChronoField_TemporalField(tmp12), Long_ValueOf_J__Long(cos))



				var tmp13 Map = t.F_fieldValues; var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_MICRO_OF_SECOND; tmp13.Remove_O__O(tmp14.Ref())
				var tmp15 Map = t.F_fieldValues; var tmp16 *ChronoField; ChronoField_Init(); tmp16 = ChronoField_NANO_OF_SECOND; tmp15.Put_O_O__O(tmp16.Ref(), Long_ValueOf_J__Long(cos*1000)) } else {
					var tmp17 Map = t.F_fieldValues; var tmp18 *ChronoField; ChronoField_Init(); tmp18 = ChronoField_NANO_OF_SECOND; tmp17.Put_O_O__O(tmp18.Ref(), Long_ValueOf_J__Long(los*1000000)) } } else {
//line :362:1
						var tmp19 Map = t.F_fieldValues; var tmp20 *ChronoField; ChronoField_Init(); tmp20 = ChronoField_MICRO_OF_SECOND; if tmp19.ContainsKey_O__Z(tmp20.Ref()) {


















							var cos_2 int64; var tmp21 Map = t.F_fieldValues; var tmp22 *ChronoField; ChronoField_Init(); tmp22 = ChronoField_MICRO_OF_SECOND; cos_2 = NN(Long_Cast(tmp21.Remove_O__O(tmp22.Ref()))).LongValue__J()
							var tmp23 Map = t.F_fieldValues; var tmp24 *ChronoField; ChronoField_Init(); tmp24 = ChronoField_NANO_OF_SECOND; tmp23.Put_O_O__O(tmp24.Ref(), Long_ValueOf_J__Long(cos_2*1000)) } }
		var tmp25 bool; var tmp26 bool; var tmp27 bool; var tmp28 bool; var tmp29 bool; var tmp30 Map = t.F_fieldValues; var tmp31 *ChronoField; ChronoField_Init(); tmp31 = ChronoField_HOUR_OF_DAY; tmp29 = !tmp30.ContainsKey_O__Z(tmp31.Ref()); if tmp29 {
			var tmp32 Map = t.F_fieldValues; var tmp33 *ChronoField; ChronoField_Init(); tmp33 = ChronoField_MINUTE_OF_HOUR; tmp29 = !tmp32.ContainsKey_O__Z(tmp33.Ref()) }
//line :383:1
		tmp28 = tmp29; if tmp28 {

			var tmp34 Map = t.F_fieldValues; var tmp35 *ChronoField; ChronoField_Init(); tmp35 = ChronoField_SECOND_OF_MINUTE; tmp28 = !tmp34.ContainsKey_O__Z(tmp35.Ref()) }
//line :383:1
		tmp27 = tmp28; if tmp27 {


			var tmp36 Map = t.F_fieldValues; var tmp37 *ChronoField; ChronoField_Init(); tmp37 = ChronoField_NANO_OF_SECOND; tmp27 = !tmp36.ContainsKey_O__Z(tmp37.Ref()) }
//line :383:1
		tmp26 = tmp27; if tmp26 {



			var tmp38 *ResolverStyle = t.F_resolverStyle; var tmp39 *ResolverStyle; ResolverStyle_Init(); tmp39 = ResolverStyle_STRICT; tmp26 = !(tmp38 == tmp39) }
//line :383:1
		tmp25 = tmp26; if tmp25 {




			if !(t.F_dayPeriod == nil) {

				var midpoint int64 = NN(t.F_dayPeriod).Mid__J(); var tmp40 int64 = midpoint / 60
				t.ResolveTime_J_J_J_J__V(tmp40, midpoint%60, 0, 0)




				t.F_dayPeriod = nil } else {
//line :388:1
					var tmp41 Map = t.F_fieldValues; var tmp42 *ChronoField; ChronoField_Init(); tmp42 = ChronoField_AMPM_OF_DAY; if tmp41.ContainsKey_O__Z(tmp42.Ref()) {









						var ap int64; var tmp43 Map = t.F_fieldValues; var tmp44 *ChronoField; ChronoField_Init(); tmp44 = ChronoField_AMPM_OF_DAY; ap = NN(Long_Cast(tmp43.Remove_O__O(tmp44.Ref()))).LongValue__J()
						var tmp45 *ResolverStyle = t.F_resolverStyle; var tmp46 *ResolverStyle; ResolverStyle_Init(); tmp46 = ResolverStyle_LENIENT; if tmp45 == tmp46 {
							t.ResolveTime_J_J_J_J__V(Math_AddExact_J_J__J(Math_MultiplyExact_J_I__J(ap, 12), 6), 0, 0, 0) } else {

								var tmp47 *ChronoField; ChronoField_Init(); tmp47 = ChronoField_AMPM_OF_DAY; NN(tmp47).CheckValidValue_J__J(ap)
								t.ResolveTime_J_J_J_J__V(ap*12+6, 0, 0, 0) } } } }
		var hod *Long; var tmp48 Map = t.F_fieldValues; var tmp49 *ChronoField; ChronoField_Init(); tmp49 = ChronoField_HOUR_OF_DAY; hod = Long_Cast(tmp48.Get_O__O(tmp49.Ref()))
		if !(hod == nil) {
			var moh *Long; var tmp50 Map = t.F_fieldValues; var tmp51 *ChronoField; ChronoField_Init(); tmp51 = ChronoField_MINUTE_OF_HOUR; moh = Long_Cast(tmp50.Get_O__O(tmp51.Ref())); var som *Long; var tmp52 Map = t.F_fieldValues; var tmp53 *ChronoField
			ChronoField_Init(); tmp53 = ChronoField_SECOND_OF_MINUTE; som = Long_Cast(tmp52.Get_O__O(tmp53.Ref()))
//line :406:1
			var nos *Long; var tmp54 Map = t.F_fieldValues; var tmp55 *ChronoField

			ChronoField_Init(); tmp55 = ChronoField_NANO_OF_SECOND; nos = Long_Cast(tmp54.Get_O__O(tmp55.Ref()))
			var tmp56 bool; var tmp57 bool; var tmp58 bool; tmp58 = moh == nil; if tmp58 { var tmp59 bool; tmp59 = !(som == nil); if !tmp59 { tmp59 = !(nos == nil) }; tmp58 = tmp59 }; tmp57 = tmp58; if !tmp57 {
				var tmp60 bool; var tmp61 bool; tmp61 = !(moh == nil); if tmp61 { tmp61 = som == nil }; tmp60 = tmp61; if tmp60 { tmp60 = !(nos == nil) }; tmp57 = tmp60 }
//line :409:1
			tmp56 = tmp57; if tmp56 {

				return }
			var mohVal int64; if !(moh == nil) { mohVal = NN(moh).LongValue__J() } else { mohVal = 0 }; var somVal int64
			if !(som == nil) { somVal = NN(som).LongValue__J() } else { somVal = 0 }
//line :412:1
			var nosVal int64

			if !(nos == nil) { nosVal = NN(nos).LongValue__J() } else { nosVal = 0 }
			var tmp62 bool; var tmp63 bool; tmp63 = !(t.F_dayPeriod == nil); if tmp63 { var tmp64 *ResolverStyle = t.F_resolverStyle; var tmp65 *ResolverStyle; ResolverStyle_Init(); tmp65 = ResolverStyle_LENIENT; tmp63 = !(tmp64 == tmp65) }; tmp62 = tmp63; if tmp62 {
				var tmp66 *DateTimeFormatterBuilder_DayPeriod = t.F_dayPeriod; if NN(tmp66).Includes_J__Z(NN(hod).LongValue__J()*60 + mohVal) { } else {
					panic(Thrown(DateTimeException_New_String(Concat(Lit_2380.Formatted_O1__String(RefArrayOf(Object_class, hod.Ref(), Long_ValueOf_J__Long(mohVal))), Lit_2381, StrOfObj(t.F_dayPeriod.Ref())))))
				}
			}




			t.ResolveTime_J_J_J_J__V(NN(hod).LongValue__J(), mohVal, somVal, nosVal)
			var tmp67 Map = t.F_fieldValues; var tmp68 *ChronoField; ChronoField_Init(); tmp68 = ChronoField_HOUR_OF_DAY; tmp67.Remove_O__O(tmp68.Ref())
			var tmp69 Map = t.F_fieldValues; var tmp70 *ChronoField; ChronoField_Init(); tmp70 = ChronoField_MINUTE_OF_HOUR; tmp69.Remove_O__O(tmp70.Ref())
			var tmp71 Map = t.F_fieldValues; var tmp72 *ChronoField; ChronoField_Init(); tmp72 = ChronoField_SECOND_OF_MINUTE; tmp71.Remove_O__O(tmp72.Ref())
			var tmp73 Map = t.F_fieldValues; var tmp74 *ChronoField; ChronoField_Init(); tmp74 = ChronoField_NANO_OF_SECOND; tmp73.Remove_O__O(tmp74.Ref()) } }
	var tmp75 bool; var tmp76 bool; var tmp77 *ResolverStyle = t.F_resolverStyle; var tmp78 *ResolverStyle; ResolverStyle_Init(); tmp78 = ResolverStyle_LENIENT; tmp76 = !(tmp77 == tmp78); if tmp76 { tmp76 = t.F_fieldValues.Size__I() > 0 }; tmp75 = tmp76; if tmp75 {
		var i_101676 Iterator = t.F_fieldValues.EntrySet__Set().Iterator__Iterator(); for i_101676.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101676.Next__O()); var field TemporalField = TemporalField_Cast(entry.GetKey__O()); var tmp79 bool; var tmp80 bool

			tmp80 = ChronoField_InstanceOf(field); if tmp80 { tmp80 = field.IsTimeBased__Z() }; tmp79 = tmp80; if tmp79 {
				NN(ChronoField_Cast(field)).CheckValidValue_J__J(NN(Long_Cast(entry.GetValue__O())).LongValue__J())
			} } } }
func (t *Parsed) ResolveTime_J_J_J_J__V(hod, moh, som, nos int64) {
	var tmp1 *ResolverStyle = t.F_resolverStyle; var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_LENIENT; if tmp1 == tmp2 {
		var totalNanos int64 = Math_MultiplyExact_J_J__J(hod, 3600000000000)
		totalNanos = Math_AddExact_J_J__J(totalNanos, Math_MultiplyExact_J_J__J(moh, 60000000000))
		totalNanos = Math_AddExact_J_J__J(totalNanos, Math_MultiplyExact_J_J__J(som, 1000000000))
		totalNanos = Math_AddExact_J_J__J(totalNanos, nos)
		var excessDays int32 = int32(Math_FloorDiv_J_J__J(totalNanos, 86400000000000)); var nod int64 = Math_FloorMod_J_J__J(totalNanos, 86400000000000)

		t.UpdateCheckConflict_LocalTime_Period__V(LocalTime_OfNanoOfDay_J__LocalTime(nod), Period_OfDays_I__Period(excessDays)) } else {
			var mohVal int32; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_MINUTE_OF_HOUR; mohVal = NN(tmp3).CheckValidIntValue_J__I(moh); var nosVal int32; var tmp4 *ChronoField
			ChronoField_Init(); tmp4 = ChronoField_NANO_OF_SECOND; nosVal = NN(tmp4).CheckValidIntValue_J__I(nos)
			var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 *ResolverStyle = t.F_resolverStyle; var tmp11 *ResolverStyle; ResolverStyle_Init(); tmp11 = ResolverStyle_SMART; tmp9 = tmp10 == tmp11; if tmp9 { tmp9 = hod == 24 }; tmp8 = tmp9; if tmp8 {
				tmp8 = mohVal == 0 }
//line :446:1
			tmp7 = tmp8; if tmp7 {

				tmp7 = som == 0 }
//line :446:1
			tmp6 = tmp7; if tmp6 {


				tmp6 = nosVal == 0 }
//line :446:1
			tmp5 = tmp6; if tmp5 {



				var tmp12 *LocalTime; LocalTime_Init(); tmp12 = LocalTime_MIDNIGHT; var tmp13 *LocalTime = tmp12; t.UpdateCheckConflict_LocalTime_Period__V(tmp13, Period_OfDays_I__Period(1)) } else {
					var hodVal int32; var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_HOUR_OF_DAY; hodVal = NN(tmp14).CheckValidIntValue_J__I(hod); var somVal int32; var tmp15 *ChronoField
					ChronoField_Init(); tmp15 = ChronoField_SECOND_OF_MINUTE; somVal = NN(tmp15).CheckValidIntValue_J__I(som)
					var tmp16 *LocalTime = LocalTime_Of_I_I_I_I__LocalTime(hodVal, mohVal, somVal, nosVal); var tmp17 *Period; Period_Init(); tmp17 = Period_ZERO; t.UpdateCheckConflict_LocalTime_Period__V(tmp16, tmp17)
				} } }
func (t *Parsed) ResolvePeriod__V() {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !(t.F_date == nil); if tmp3 { tmp3 = !(t.F_time == nil) }; tmp2 = tmp3; if tmp2 { tmp2 = NN(t.F_excessDays).IsZero__Z() == false }; tmp1 = tmp2; if tmp1 {
		t.F_date = t.F_date.Plus_TemporalAmount__ChronoLocalDate(Up_Period_TemporalAmount(t.F_excessDays))
		var tmp4 *Period; Period_Init(); tmp4 = Period_ZERO; t.F_excessDays = tmp4
	} }
func (t *Parsed) ResolveFractional__V() {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_time == nil; if tmp2 {
		var tmp3 bool; var tmp4 bool; var tmp5 Map = t.F_fieldValues; var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_INSTANT_SECONDS; tmp4 = tmp5.ContainsKey_O__Z(tmp6.Ref()); if !tmp4 {
			var tmp7 Map = t.F_fieldValues; var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_SECOND_OF_DAY; tmp4 = tmp7.ContainsKey_O__Z(tmp8.Ref()) }
//line :462:1
		tmp3 = tmp4; if !tmp3 {

			var tmp9 Map = t.F_fieldValues; var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_SECOND_OF_MINUTE; tmp3 = tmp9.ContainsKey_O__Z(tmp10.Ref()) }
//line :462:1
		tmp2 = tmp3 }
//line :461:1
	tmp1 = tmp2; if tmp1 {



		var tmp11 Map = t.F_fieldValues; var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_NANO_OF_SECOND; if tmp11.ContainsKey_O__Z(tmp12.Ref()) {
			var nos int64; var tmp13 Map = t.F_fieldValues; var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_NANO_OF_SECOND; nos = NN(Long_Cast(tmp13.Get_O__O(tmp14.Ref()))).LongValue__J()
			var tmp15 Map = t.F_fieldValues; var tmp16 *ChronoField; ChronoField_Init(); tmp16 = ChronoField_MICRO_OF_SECOND; var tmp17 any = tmp16.Ref(); tmp15.Put_O_O__O(tmp17, Long_ValueOf_J__Long(nos/1000))
			var tmp18 Map = t.F_fieldValues; var tmp19 *ChronoField; ChronoField_Init(); tmp19 = ChronoField_MILLI_OF_SECOND; var tmp20 any = tmp19.Ref(); tmp18.Put_O_O__O(tmp20, Long_ValueOf_J__Long(nos/1000000)) } else {

				var tmp21 Map = t.F_fieldValues; var tmp22 *ChronoField; ChronoField_Init(); tmp22 = ChronoField_NANO_OF_SECOND; tmp21.Put_O_O__O(tmp22.Ref(), Long_ValueOf_J__Long(0))
				var tmp23 Map = t.F_fieldValues; var tmp24 *ChronoField; ChronoField_Init(); tmp24 = ChronoField_MICRO_OF_SECOND; tmp23.Put_O_O__O(tmp24.Ref(), Long_ValueOf_J__Long(0))
				var tmp25 Map = t.F_fieldValues; var tmp26 *ChronoField; ChronoField_Init(); tmp26 = ChronoField_MILLI_OF_SECOND; tmp25.Put_O_O__O(tmp26.Ref(), Long_ValueOf_J__Long(0))
			} } }
func (t *Parsed) ResolveInstant__V() {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 Map = t.F_fieldValues; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_INSTANT_SECONDS; tmp3 = !tmp4.ContainsKey_O__Z(tmp5.Ref()); if tmp3 { tmp3 = !(t.F_date == nil) }; tmp2 = tmp3; if tmp2 {
		tmp2 = !(t.F_time == nil) }
//line :475:1
	tmp1 = tmp2; if tmp1 {

		var offsetSecs *Long; var tmp6 Map = t.F_fieldValues; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_OFFSET_SECONDS; offsetSecs = Long_Cast(tmp6.Get_O__O(tmp7.Ref()))
		if !(offsetSecs == nil) {

			var offset *ZoneOffset = ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(offsetSecs).IntValue__I()); var instant int64 = t.F_date.AtTime_LocalTime__ChronoLocalDateTime(t.F_time).AtZone_ZoneId__ChronoZonedDateTime(Up_ZoneOffset_ZoneId(offset)).ToEpochSecond__J(); var tmp8 Map = t.F_fieldValues; var tmp9 *ChronoField

			ChronoField_Init(); tmp9 = ChronoField_INSTANT_SECONDS; tmp8.Put_O_O__O(tmp9.Ref(), Long_ValueOf_J__Long(instant)) } else {
//line :478:1
				if !(t.F_zone == nil) {





					var czdt ChronoZonedDateTime = t.F_date.AtTime_LocalTime__ChronoLocalDateTime(t.F_time).AtZone_ZoneId__ChronoZonedDateTime(t.F_zone); var tmp10 bool; var tmp11 bool
					tmp11 = t.F_zoneNameType == 0; if !tmp11 {
						tmp11 = t.F_zoneNameType == 2 }
//line :485:1
					tmp10 = tmp11; if tmp10 {

						czdt = czdt.WithLaterOffsetAtOverlap__ChronoZonedDateTime() }
					var tmp12 Map = t.F_fieldValues; var tmp13 *ChronoField; ChronoField_Init(); tmp13 = ChronoField_INSTANT_SECONDS; var tmp14 any = tmp13.Ref(); tmp12.Put_O_O__O(tmp14, Long_ValueOf_J__Long(czdt.ToEpochSecond__J()))
				} } } }
func (t *Parsed) UpdateCheckConflict_LocalTime_Period__V(timeToSet *LocalTime, periodToSet *Period) {
	if !(t.F_time == nil) {

		if NN(t.F_time).Equals_O__Z(timeToSet.Ref()) == false {
			panic(Thrown(DateTimeException_New_String(Concat(Lit_2382, StrOfObj(t.F_time.Ref()), Lit_115, StrOfObj(timeToSet.Ref())))))
		}



		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = NN(t.F_excessDays).IsZero__Z() == false; if tmp3 { tmp3 = NN(periodToSet).IsZero__Z() == false }; tmp2 = tmp3; if tmp2 {
			tmp2 = NN(t.F_excessDays).Equals_O__Z(periodToSet.Ref()) == false }
//line :499:1
		tmp1 = tmp2; if tmp1 {

			panic(Thrown(DateTimeException_New_String(Concat(Lit_2383, StrOfObj(t.F_excessDays.Ref()), Lit_115, StrOfObj(periodToSet.Ref()))))) } else {




				t.F_excessDays = periodToSet } } else {
					t.F_time = timeToSet; t.F_excessDays = periodToSet
				} }
func (t *Parsed) CrossCheck__V() {
	if !(t.F_date == nil) { t.CrossCheck_TemporalAccessor__V(t.F_date) }
	if !(t.F_time == nil) {
		t.CrossCheck_TemporalAccessor__V(Up_LocalTime_TemporalAccessor(t.F_time))
		var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_date == nil); if tmp2 { tmp2 = t.F_fieldValues.Size__I() > 0 }; tmp1 = tmp2; if tmp1 { t.CrossCheck_TemporalAccessor__V(t.F_date.AtTime_LocalTime__ChronoLocalDateTime(t.F_time))
		} } }
func (t *Parsed) CrossCheck_TemporalAccessor__V(target TemporalAccessor) {
	var it Iterator = t.F_fieldValues.EntrySet__Set().Iterator__Iterator(); L1: for {
		if it.HasNext__Z() {
			var entry Map_Entry = Map_Entry_Cast(it.Next__O()); var field TemporalField = TemporalField_Cast(entry.GetKey__O())

			if target.IsSupported_TemporalField__Z(field) {
				var val1 int64 = 0; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
					val1 = target.GetLong_TemporalField__J(field); return nil }(); if tmp1 != nil { if RuntimeException_InstanceOf(tmp1) { var ex RuntimeException_I = RuntimeException_Cast(tmp1); _ = ex; it = it; continue L1 } else { panic(tmp1) } }
				var val2 int64 = NN(Long_Cast(entry.GetValue__O())).LongValue__J()
				if val1 == val2 { } else {
					panic(Thrown(DateTimeException_New_String(Concat(Lit_2384, StrOfObj(field), Lit_115, StrOfLong(val1), Lit_2186, StrOfObj(field), Lit_115, StrOfLong(val2), Lit_2385, StrOfObj(target)))))
				}









				it.Remove__V()
				it = it; continue L1 } else {
					it = it; continue L1 } }
//line :516:1
		break L1
	}
}





















func (t *Parsed) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New_I(64)
	NN(NN(NN(buf).Append_O__StringBuilder(t.F_fieldValues)).Append_C__StringBuilder(44)).Append_O__StringBuilder(t.F_chrono)
	if !(t.F_zone == nil) { NN(NN(buf).Append_C__StringBuilder(44)).Append_O__StringBuilder(t.F_zone); NN(NN(buf).Append_C__StringBuilder(44)).Append_I__StringBuilder(t.F_zoneNameType) }
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_date == nil); if !tmp2 { tmp2 = !(t.F_time == nil) }; tmp1 = tmp2; if tmp1 {
		NN(buf).Append_String__StringBuilder(Lit_2386)
		if !(t.F_date == nil) {
			NN(buf).Append_O__StringBuilder(t.F_date); if !(t.F_time == nil) { NN(NN(buf).Append_C__StringBuilder(84)).Append_O__StringBuilder(t.F_time.Ref()) } } else {
				NN(buf).Append_O__StringBuilder(t.F_time.Ref()) } }
	return NN(buf).ToString__String()
}


type Parsed struct{ Object; F_fieldValues Map; F_zone ZoneId_I; F_zoneNameType int32; F_chrono Chronology; F_leapSecond bool; F_resolverStyle *ResolverStyle; F_date ChronoLocalDate; F_time *LocalTime; F_excessDays *Period; F_dayPeriod *DateTimeFormatterBuilder_DayPeriod }

func (t *Parsed) Is_TemporalAccessor() {}

func (t *Parsed) Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange { return TemporalAccessor_Range_TemporalField__ValueRange(t, p0) }

func (t *Parsed) Get_TemporalField__I(p0 TemporalField) int32 { return TemporalAccessor_Get_TemporalField__I(t, p0) }

func (t *Parsed) Ref() any { if t == nil { return nil }; return t }

func (t *Parsed) GetClass__Class() *Class { return Parsed_class }

func (t *Parsed) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Parsed) CloneShallow() any { panic(CloneNotSupported(t)) }

func Parsed_InstanceOf(x any) bool { _, ok := x.(*Parsed); return ok }

func Parsed_Cast(x any) *Parsed { if x == nil { return nil }; v, ok := x.(*Parsed); if !ok { panic(ClassCast(x, Parsed_class)) }; return v }
