//line java_security_spec_AlgorithmParameterSpec.ae:1
package jrt






type AlgorithmParameterSpec interface{ Object_I; Is_AlgorithmParameterSpec() }

func AlgorithmParameterSpec_InstanceOf(x any) bool { _, ok := x.(AlgorithmParameterSpec); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AlgorithmParameterSpec_class) } }; return ok }

func AlgorithmParameterSpec_Cast(x any) AlgorithmParameterSpec { if x == nil { return nil }; v, ok := x.(AlgorithmParameterSpec); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AlgorithmParameterSpec_class) } }; if !ok { panic(ClassCast(x, AlgorithmParameterSpec_class)) }; return v }
