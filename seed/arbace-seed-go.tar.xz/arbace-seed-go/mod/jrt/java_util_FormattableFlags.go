//line java_util_FormattableFlags.ae:1
package jrt




func FormattableFlags_New() *FormattableFlags { t := &FormattableFlags{}; t.Ctor(); return t }
//line :6:1
func (t *FormattableFlags) Ctor() { panic(A2g_NotTranslated("java.util.FormattableFlags.<init>()V")) }





type FormattableFlags struct{ Object }

const FormattableFlags_LEFT_JUSTIFY int32 = 1

const FormattableFlags_UPPERCASE int32 = 2

const FormattableFlags_ALTERNATE int32 = 4

func (t *FormattableFlags) Ref() any { if t == nil { return nil }; return t }

func (t *FormattableFlags) GetClass__Class() *Class { return FormattableFlags_class }

func (t *FormattableFlags) ToString__String() *String { return Object_toString(t) }

func (t *FormattableFlags) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FormattableFlags) CloneShallow() any { panic(CloneNotSupported(t)) }

func FormattableFlags_InstanceOf(x any) bool { _, ok := x.(*FormattableFlags); return ok }

func FormattableFlags_Cast(x any) *FormattableFlags { if x == nil { return nil }; v, ok := x.(*FormattableFlags); if !ok { panic(ClassCast(x, FormattableFlags_class)) }; return v }
