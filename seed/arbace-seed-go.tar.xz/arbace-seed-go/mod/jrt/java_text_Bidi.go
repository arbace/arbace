//line java_text_Bidi.ae:1
package jrt
















func Bidi_New_String_I(p0 *String, p1 int32) *Bidi { t := &Bidi{}; t.Ctor_String_I(p0, p1); return t }
//line :18:1
func (t *Bidi) Ctor_String_I(paragraph *String, flags int32) {
	if paragraph == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1700))) }
	t.F_bidiBase = BidiBase_New_C1_I_B1_I_I_I(NN(paragraph).ToCharArray__C1(), 0, nil, 0, NN(paragraph).Length__I(), flags)
}
func Bidi_New_AttributedCharacterIterator(p0 AttributedCharacterIterator) *Bidi { t := &Bidi{}; t.Ctor_AttributedCharacterIterator(p0); return t }
//line :22:1
func (t *Bidi) Ctor_AttributedCharacterIterator(paragraph AttributedCharacterIterator) {
	if paragraph == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1700))) }
	t.F_bidiBase = BidiBase_New_I_I(0, 0)
	NN(t.F_bidiBase).SetPara_AttributedCharacterIterator__V(paragraph)
}
func Bidi_New_C1_I_B1_I_I_I(p0 *CharArray, p1 int32, p2 *ByteArray, p3, p4, p5 int32) *Bidi { t := &Bidi{}; t.Ctor_C1_I_B1_I_I_I(p0, p1, p2, p3, p4, p5); return t }
//line :27:1
func (t *Bidi) Ctor_C1_I_B1_I_I_I(text *CharArray, textStart int32, embeddings *ByteArray, embStart, paragraphLength, flags int32) {

	if text == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1701))) }
	if paragraphLength < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1702, StrOfInt(paragraphLength))))) }
	var tmp1 bool; var tmp2 bool; tmp2 = textStart < 0; if !tmp2 { tmp2 = paragraphLength > int32(len(text.A))-textStart }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1703, StrOfInt(textStart), Lit_1704, StrOfInt(paragraphLength), Lit_1705, StrOfInt(int32(len(text.A)))))))
	}





	var tmp3 bool; var tmp4 bool; tmp4 = !(embeddings == nil); if tmp4 {
		var tmp5 bool; tmp5 = embStart < 0; if !tmp5 {
			tmp5 = paragraphLength > int32(len(embeddings.A))-embStart }
//line :41:1
		tmp4 = tmp5 }
//line :40:1
	tmp3 = tmp4; if tmp3 {


		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1703, StrOfInt(embStart), Lit_1704, StrOfInt(paragraphLength), Lit_1706, StrOfInt(int32(len(text.A)))))))
	}





	t.F_bidiBase = BidiBase_New_C1_I_B1_I_I_I(text, textStart, embeddings, embStart, paragraphLength, flags)
}
func (t *Bidi) CreateLineBidi_I_I__Bidi(lineStart, lineLimit int32) *Bidi {
	var astr *AttributedString = AttributedString_New_String(Lit_69); var newBidi *Bidi = Bidi_New_AttributedCharacterIterator(NN(astr).GetIterator__AttributedCharacterIterator()); var tmp1 *BidiBase = t.F_bidiBase; var tmp2 *BidiBase = t.F_bidiBase

	return NN(tmp1).SetLine_Bidi_BidiBase_Bidi_BidiBase_I_I__Bidi(t, tmp2, newBidi, newBidi.F_bidiBase, lineStart, lineLimit)
}
func (t *Bidi) IsMixed__Z() bool { return NN(t.F_bidiBase).IsMixed__Z() }

func (t *Bidi) IsLeftToRight__Z() bool {
	return NN(t.F_bidiBase).IsLeftToRight__Z()
}
func (t *Bidi) IsRightToLeft__Z() bool {
	return NN(t.F_bidiBase).IsRightToLeft__Z()
}
func (t *Bidi) GetLength__I() int32 { return NN(t.F_bidiBase).GetLength__I() }

func (t *Bidi) BaseIsLeftToRight__Z() bool {
	return NN(t.F_bidiBase).BaseIsLeftToRight__Z()
}
func (t *Bidi) GetBaseLevel__I() int32 { return int32(NN(t.F_bidiBase).GetParaLevel__B()) }

func (t *Bidi) GetLevelAt_I__I(offset int32) int32 { return int32(NN(t.F_bidiBase).GetLevelAt_I__B(offset)) }


func (t *Bidi) GetRunCount__I() int32 { return NN(t.F_bidiBase).CountRuns__I() }

func (t *Bidi) GetRunLevel_I__I(run int32) int32 {
	return NN(t.F_bidiBase).GetRunLevel_I__I(run)
}
func (t *Bidi) GetRunStart_I__I(run int32) int32 {
	return NN(t.F_bidiBase).GetRunStart_I__I(run)
}
func (t *Bidi) GetRunLimit_I__I(run int32) int32 {
	return NN(t.F_bidiBase).GetRunLimit_I__I(run)
}
func Bidi_RequiresBidi_C1_I_I__Z(text *CharArray, start, limit int32) bool {
	return BidiBase_RequiresBidi_C1_I_I__Z(text, start, limit)
}
func Bidi_ReorderVisually_B1_I_O1_I_I__V(levels *ByteArray, levelStart int32, objects *RefArray, objectStart, count int32) {

	BidiBase_ReorderVisually_B1_I_O1_I_I__V(levels, levelStart, objects, objectStart, count)
}
func (t *Bidi) ToString__String() *String { return NN(t.F_bidiBase).ToString__String() }



type Bidi struct{ Object; F_bidiBase *BidiBase }

const Bidi_DIRECTION_LEFT_TO_RIGHT int32 = 0

const Bidi_DIRECTION_RIGHT_TO_LEFT int32 = 1

const Bidi_DIRECTION_DEFAULT_LEFT_TO_RIGHT int32 = -2

const Bidi_DIRECTION_DEFAULT_RIGHT_TO_LEFT int32 = -1

func (t *Bidi) Ref() any { if t == nil { return nil }; return t }

func (t *Bidi) GetClass__Class() *Class { return Bidi_class }

func (t *Bidi) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Bidi) CloneShallow() any { panic(CloneNotSupported(t)) }

func Bidi_InstanceOf(x any) bool { _, ok := x.(*Bidi); return ok }

func Bidi_Cast(x any) *Bidi { if x == nil { return nil }; v, ok := x.(*Bidi); if !ok { panic(ClassCast(x, Bidi_class)) }; return v }
