//line java_lang_Boolean.ae:1
package jrt






















func Boolean_New_Z(p0 bool) *Boolean { Boolean_Init(); t := &Boolean{}; t.Ctor_Z(p0); return t }
//line :24:1
func (t *Boolean) Ctor_Z(value bool) {
	t.F_value = value
}
func Boolean_New_String(p0 *String) *Boolean { Boolean_Init(); t := &Boolean{}; t.Ctor_String(p0); return t }
//line :27:1
func (t *Boolean) Ctor_String(s *String) { t.Ctor_Z(Boolean_ParseBoolean_String__Z(s)) }


func Boolean_ParseBoolean_String__Z(s *String) bool {
	return Lit_107.EqualsIgnoreCase_String__Z(s)
}
func (t *Boolean) BooleanValue__Z() bool { return t.F_value }


func Boolean_ValueOf_Z__Boolean(b bool) *Boolean { Boolean_Init()
	if b { return Boolean_TRUE } else { return Boolean_FALSE
	} }
func Boolean_ValueOf_String__Boolean(s *String) *Boolean { Boolean_Init()
	if Boolean_ParseBoolean_String__Z(s) { return Boolean_TRUE } else { return Boolean_FALSE
	} }
func Boolean_ToString_Z__String(b bool) *String {
	return String_ValueOf_Z__String(b)
}
func (t *Boolean) ToString__String() *String { return String_ValueOf_Z__String(t.F_value) }

func (t *Boolean) HashCode__I() int32 { return Boolean_HashCode_Z__I(t.F_value) }

func Boolean_HashCode_Z__I(value bool) int32 {
	if value { return 1231 } else { return 1237
	} }
func (t *Boolean) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Boolean_InstanceOf(tmp1) { var b *Boolean = Boolean_Cast(tmp1); var tmp2 bool = t.F_value; return tmp2 == NN(b).BooleanValue__Z() } else { return false
	} }
func Boolean_GetBoolean_String__Z(name *String) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = !(name == nil); if tmp2 { tmp2 = !NN(name).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { tmp1 = Boolean_ParseBoolean_String__Z(System_GetProperty_String__String(name)) }; return tmp1
}
func (t *Boolean) CompareTo_Boolean__I(b *Boolean) int32 {
	var tmp1 bool = t.F_value; return Boolean_Compare_Z_Z__I(tmp1, b.F_value)
}
func Boolean_Compare_Z_Z__I(x, y bool) int32 {
	if x == y { return 0 } else { if x { return 1 } else { return -1
	} } }
func Boolean_LogicalAnd_Z_Z__Z(a, b bool) bool {
	var tmp1 bool; tmp1 = a; if tmp1 { tmp1 = b }; return tmp1
}
func Boolean_LogicalOr_Z_Z__Z(a, b bool) bool {
	var tmp1 bool; tmp1 = a; if !tmp1 { tmp1 = b }; return tmp1
}
func Boolean_LogicalXor_Z_Z__Z(a, b bool) bool {
	return !(a == b)
}
func (t *Boolean) DescribeConstable__Optional() *Optional {
	var tmp1 any; if t.F_value { tmp1 = A2g_Missing[any]("class java.lang.constant.ConstantDescs is not in the closed world") } else { tmp1 = A2g_Missing[any]("class java.lang.constant.ConstantDescs is not in the closed world") }; return Optional_Of_O__Optional(tmp1)
}


type Boolean struct{ Object; F_value bool }

func (t *Boolean) Is_Serializable() {}

func (t *Boolean) Is_Comparable() {}

func (t *Boolean) Is_Constable() {}

var Boolean_TRUE *Boolean

var Boolean_FALSE *Boolean

var Boolean_TYPE *Class

const Boolean_serialVersionUID int64 = -3665804199014368530

var Boolean_init ClassInit

func Boolean_Init() { if !Boolean_init.Done() { Boolean_init.Run(Boolean_clinit) } }

func Boolean_clinit() { Boolean_TRUE = Boolean_New_Z(true); Boolean_FALSE = Boolean_New_Z(false); Boolean_TYPE = Class_GetPrimitiveClass_String__Class(Lit_106) }

func (t *Boolean) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Boolean__I(Boolean_Cast(p0)) }

func (t *Boolean) Ref() any { if t == nil { return nil }; return t }

func (t *Boolean) GetClass__Class() *Class { return Boolean_class }

func (t *Boolean) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Boolean) CloneShallow() any { panic(CloneNotSupported(t)) }

func Boolean_InstanceOf(x any) bool { _, ok := x.(*Boolean); return ok }

func Boolean_Cast(x any) *Boolean { if x == nil { return nil }; v, ok := x.(*Boolean); if !ok { panic(ClassCast(x, Boolean_class)) }; return v }
