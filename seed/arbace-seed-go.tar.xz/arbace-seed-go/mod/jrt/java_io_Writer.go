//line java_io_Writer.ae:1
package jrt

import "sync/atomic"










func Writer_NullWriter__Writer() Writer_I {
	return Writer_1_New()
}

func (t *Writer_1) EnsureOpen__V() {
	if t.F_closed.Load() { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *Writer_1) Append_C__Writer(c uint16) Writer_I {
	t.EnsureOpen__V()
//line :21:1
	return t
}


func (t *Writer_1) Append_CharSequence__Writer(csq CharSequence) Writer_I {
	t.EnsureOpen__V()
//line :25:1
	return t
}


func (t *Writer_1) Append_CharSequence_I_I__Writer(csq CharSequence, start, end int32) Writer_I {

	t.EnsureOpen__V()
	if !(csq == nil) { Objects_CheckFromToIndex_I_I_I__I(start, end, csq.Length__I()) }
//line :29:1
	return t
}




func (t *Writer_1) Write_I__V(c int32) {
	t.EnsureOpen__V()
}
func (t *Writer_1) Write_C1_I_I__V(cbuf *CharArray, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
	t.EnsureOpen__V()
}
func (t *Writer_1) Write_String__V(str *String) {
	Objects_RequireNonNull_O__O(str.Ref())
	t.EnsureOpen__V()
}
func (t *Writer_1) Write_String_I_I__V(str *String, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, NN(str).Length__I())
	t.EnsureOpen__V()
}
func (t *Writer_1) Flush__V() {
	t.EnsureOpen__V()
}
func (t *Writer_1) Close__V() {
	t.F_closed.Store(true)
}


func (t *Writer) Ctor(this Writer_I) { t.F_lock = this }

func (t *Writer) Ctor_O(this Writer_I, lock any) {
	if lock == nil { panic(Thrown(NullPointerException_New())) }
	t.F_lock = lock
}
func (t *Writer) Impl_Write_I__V(this Writer_I, c int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if t.F_writeBuffer == nil { t.F_writeBuffer = NewCharArray(1024) }
		t.F_writeBuffer.A[0] = uint16(c)
		this.Write_C1_I_I__V(t.F_writeBuffer, 0, 1)
	}() }
func (t *Writer) Impl_Write_C1__V(this Writer_I, cbuf *CharArray) {
	this.Write_C1_I_I__V(cbuf, 0, int32(len(cbuf.A)))
}


func (t *Writer) Impl_Write_String__V(this Writer_I, str *String) {
	this.Write_String_I_I__V(str, 0, NN(str).Length__I())
}
func (t *Writer) Impl_Write_String_I_I__V(this Writer_I, str *String, off, len_ int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		var cbuf *CharArray
		if len_ <= 1024 {

			if t.F_writeBuffer == nil { t.F_writeBuffer = NewCharArray(1024) }
			cbuf = t.F_writeBuffer } else {
				cbuf = NewCharArray(len_) }
		NN(str).GetChars_I_I_C1_I__V(off, off+len_, cbuf, 0)
		this.Write_C1_I_I__V(cbuf, 0, len_)
	}() }
func (t *Writer) Impl_Append_CharSequence__Writer(this Writer_I, csq CharSequence) Writer_I {
	this.Write_String__V(String_ValueOf_O__String(csq))
//line :89:1
	return this
}


func (t *Writer) Impl_Append_CharSequence_I_I__Writer(this Writer_I, csq CharSequence, start, end int32) Writer_I {

	if csq == nil { csq = Lit_95 }
	return this.Append_CharSequence__Writer(csq.SubSequence_I_I__CharSequence(start, end))
}
func (t *Writer) Impl_Append_C__Writer(this Writer_I, c uint16) Writer_I {
	this.Write_I__V(int32(c))
//line :98:1
	return this
}



type Writer struct{ Object; F_writeBuffer *CharArray; F_lock any }

type Writer_I interface{ Object_I; Appendable; Closeable; Flushable; AutoCloseable; Self_Writer() *Writer; Write_I__V(p0 int32); Write_C1__V(p0 *CharArray); Write_C1_I_I__V(p0 *CharArray, p1, p2 int32); Write_String__V(p0 *String); Write_String_I_I__V(p0 *String, p1, p2 int32); Append_CharSequence__Writer(p0 CharSequence) Writer_I; Append_CharSequence_I_I__Writer(p0 CharSequence, p1, p2 int32) Writer_I; Append_C__Writer(p0 uint16) Writer_I; Flush__V(); Close__V(); Append_CharSequence__Appendable(p0 CharSequence) Appendable; Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable; Append_C__Appendable(p0 uint16) Appendable }

func (t *Writer) Self_Writer() *Writer { return t }

func (t *Writer) Is_Appendable() {}

func (t *Writer) Is_Closeable() {}

func (t *Writer) Is_Flushable() {}

func (t *Writer) Is_AutoCloseable() {}

const Writer_WRITE_BUFFER_SIZE int32 = 1024

func (t *Writer) Impl_Append_CharSequence__Appendable(this Writer_I, p0 CharSequence) Appendable { return this.Append_CharSequence__Writer(p0) }

func (t *Writer) Impl_Append_CharSequence_I_I__Appendable(this Writer_I, p0 CharSequence, p1, p2 int32) Appendable { return this.Append_CharSequence_I_I__Writer(p0, p1, p2) }

func (t *Writer) Impl_Append_C__Appendable(this Writer_I, p0 uint16) Appendable { return this.Append_C__Writer(p0) }

func Writer_InstanceOf(x any) bool { _, ok := x.(Writer_I); return ok }

func Writer_Cast(x any) Writer_I { if x == nil { return nil }; v, ok := x.(Writer_I); if !ok { panic(ClassCast(x, Writer_class)) }; return v }



type Writer_1 struct{ Writer; F_closed atomic.Bool }

func Writer_1_New() *Writer_1 { t := &Writer_1{}; t.Ctor(); return t }

func (t *Writer_1) Ctor() { t.Writer.Ctor(t) }

func (t *Writer_1) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return t.Append_CharSequence__Writer(p0) }

func (t *Writer_1) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return t.Append_CharSequence_I_I__Writer(p0, p1, p2) }

func (t *Writer_1) Append_C__Appendable(p0 uint16) Appendable { return t.Append_C__Writer(p0) }

func (t *Writer_1) Write_C1__V(p0 *CharArray) { t.Impl_Write_C1__V(t, p0) }

func (t *Writer_1) Ref() any { if t == nil { return nil }; return t }

func (t *Writer_1) GetClass__Class() *Class { return Writer_1_class }

func (t *Writer_1) ToString__String() *String { return Object_toString(t) }

func (t *Writer_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Writer_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Writer_1_InstanceOf(x any) bool { _, ok := x.(*Writer_1); return ok }

func Writer_1_Cast(x any) *Writer_1 { if x == nil { return nil }; v, ok := x.(*Writer_1); if !ok { panic(ClassCast(x, Writer_1_class)) }; return v }
