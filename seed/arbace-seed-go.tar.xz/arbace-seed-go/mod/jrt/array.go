//line array.ae:1
package jrt

import (
	"strconv"
	"unsafe"
)
func negativeArraySize(n int32) Throwable_I {
	return NegativeArraySizeException_New_String(Str(strconv.Itoa(int(n)))) }
// IndexOutOfBounds is the ArrayIndexOutOfBoundsException of an array access a[i] on an array
// of length n, with the JVM's message.
//line :10:1
func IndexOutOfBounds(i, n int) Throwable_I {



	return ArrayIndexOutOfBoundsException_New_String(
		Str("Index " + strconv.Itoa(i) + " out of bounds for length " + strconv.Itoa(n)),
	) }
// BooleanArray is boolean[].
type BooleanArray struct{ Object; A []bool }
// NewBooleanArray is new boolean[n].
func NewBooleanArray(n int32,
) *BooleanArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &BooleanArray{A: make([]bool, n)} }
// BooleanArrayOf is an array initializer of boolean[].
func BooleanArrayOf(a ...bool,
) *BooleanArray {
	if a == nil {
		a = []bool{} }
	return &BooleanArray{A: a}
}
func (t *BooleanArray) Ref() any { if t == nil { return nil }; return t }
func (t *BooleanArray) GetClass__Class() *Class { return Prim_boolean.ArrayClass() }
func (t *BooleanArray) ToString__String() *String { return Object_toString(t) }
func (t *BooleanArray) Is_Cloneable() {}
func (t *BooleanArray) Is_Serializable() {}
func (t *BooleanArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :38:1
func (t /*line :39:1*/*BooleanArray) Copy() *BooleanArray {
	a := make([]bool, len(t.A))
	copy(a, t.A)
	return &BooleanArray{A: a}
}
// ByteArray is byte[].
type ByteArray struct{ Object; A []int8 }
// NewByteArray is new byte[n].
func NewByteArray(n int32,
) *ByteArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &ByteArray{A: make([]int8, n)} }
// ByteArrayOf is an array initializer of byte[].
func ByteArrayOf(a ...int8,
) *ByteArray {
	if a == nil {
		a = []int8{} }
	return &ByteArray{A: a}
}
func (t *ByteArray) Ref() any { if t == nil { return nil }; return t }
func (t *ByteArray) GetClass__Class() *Class { return Prim_byte.ArrayClass() }
func (t *ByteArray) ToString__String() *String { return Object_toString(t) }
func (t *ByteArray) Is_Cloneable() {}
func (t *ByteArray) Is_Serializable() {}
func (t *ByteArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :65:1
func (t /*line :66:1*/*ByteArray) Copy() *ByteArray {
	a := make([]int8, len(t.A))
	copy(a, t.A)
	return &ByteArray{A: a}
}
// CharArray is char[].
type CharArray struct{ Object; A []uint16 }
// NewCharArray is new char[n].
func NewCharArray(n int32,
) *CharArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &CharArray{A: make([]uint16, n)} }
// CharArrayOf is an array initializer of char[].
func CharArrayOf(a ...uint16,
) *CharArray {
	if a == nil {
		a = []uint16{} }
	return &CharArray{A: a}
}
func (t *CharArray) Ref() any { if t == nil { return nil }; return t }
func (t *CharArray) GetClass__Class() *Class { return Prim_char.ArrayClass() }
func (t *CharArray) ToString__String() *String { return Object_toString(t) }
func (t *CharArray) Is_Cloneable() {}
func (t *CharArray) Is_Serializable() {}
func (t *CharArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :92:1
func (t /*line :93:1*/*CharArray) Copy() *CharArray {
	a := make([]uint16, len(t.A))
	copy(a, t.A)
	return &CharArray{A: a}
}
// ShortArray is short[].
type ShortArray struct{ Object; A []int16 }
// NewShortArray is new short[n].
func NewShortArray(n int32,
) *ShortArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &ShortArray{A: make([]int16, n)} }
// ShortArrayOf is an array initializer of short[].
func ShortArrayOf(a ...int16,
) *ShortArray {
	if a == nil {
		a = []int16{} }
	return &ShortArray{A: a}
}
func (t *ShortArray) Ref() any { if t == nil { return nil }; return t }
func (t *ShortArray) GetClass__Class() *Class { return Prim_short.ArrayClass() }
func (t *ShortArray) ToString__String() *String { return Object_toString(t) }
func (t *ShortArray) Is_Cloneable() {}
func (t *ShortArray) Is_Serializable() {}
func (t *ShortArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :119:1
func (t /*line :120:1*/*ShortArray) Copy() *ShortArray {
	a := make([]int16, len(t.A))
	copy(a, t.A)
	return &ShortArray{A: a}
}
// IntArray is int[].
type IntArray struct{ Object; A []int32 }
// NewIntArray is new int[n].
func NewIntArray(n int32,
) *IntArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &IntArray{A: make([]int32, n)} }
// IntArrayOf is an array initializer of int[].
func IntArrayOf(a ...int32,
) *IntArray {
	if a == nil {
		a = []int32{} }
	return &IntArray{A: a}
}
func (t *IntArray) Ref() any { if t == nil { return nil }; return t }
func (t *IntArray) GetClass__Class() *Class { return Prim_int.ArrayClass() }
func (t *IntArray) ToString__String() *String { return Object_toString(t) }
func (t *IntArray) Is_Cloneable() {}
func (t *IntArray) Is_Serializable() {}
func (t *IntArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :146:1
func (t /*line :147:1*/*IntArray) Copy() *IntArray {
	a := make([]int32, len(t.A))
	copy(a, t.A)
	return &IntArray{A: a}
}
// LongArray is long[].
type LongArray struct{ Object; A []int64 }
// NewLongArray is new long[n].
func NewLongArray(n int32,
) *LongArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &LongArray{A: make([]int64, n)} }
// LongArrayOf is an array initializer of long[].
func LongArrayOf(a ...int64,
) *LongArray {
	if a == nil {
		a = []int64{} }
	return &LongArray{A: a}
}
func (t *LongArray) Ref() any { if t == nil { return nil }; return t }
func (t *LongArray) GetClass__Class() *Class { return Prim_long.ArrayClass() }
func (t *LongArray) ToString__String() *String { return Object_toString(t) }
func (t *LongArray) Is_Cloneable() {}
func (t *LongArray) Is_Serializable() {}
func (t *LongArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :173:1
func (t /*line :174:1*/*LongArray) Copy() *LongArray {
	a := make([]int64, len(t.A))
	copy(a, t.A)
	return &LongArray{A: a}
}
// FloatArray is float[].
type FloatArray struct{ Object; A []float32 }
// NewFloatArray is new float[n].
func NewFloatArray(n int32,
) *FloatArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &FloatArray{A: make([]float32, n)} }
// FloatArrayOf is an array initializer of float[].
func FloatArrayOf(a ...float32,
) *FloatArray {
	if a == nil {
		a = []float32{} }
	return &FloatArray{A: a}
}
func (t *FloatArray) Ref() any { if t == nil { return nil }; return t }
func (t *FloatArray) GetClass__Class() *Class { return Prim_float.ArrayClass() }
func (t *FloatArray) ToString__String() *String { return Object_toString(t) }
func (t *FloatArray) Is_Cloneable() {}
func (t *FloatArray) Is_Serializable() {}
func (t *FloatArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :200:1
func (t /*line :201:1*/*FloatArray) Copy() *FloatArray {
	a := make([]float32, len(t.A))
	copy(a, t.A)
	return &FloatArray{A: a}
}
// DoubleArray is double[].
type DoubleArray struct{ Object; A []float64 }
// NewDoubleArray is new double[n].
func NewDoubleArray(n int32,
) *DoubleArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return &DoubleArray{A: make([]float64, n)} }
// DoubleArrayOf is an array initializer of double[].
func DoubleArrayOf(a ...float64,
) *DoubleArray {
	if a == nil {
		a = []float64{} }
	return &DoubleArray{A: a}
}
func (t *DoubleArray) Ref() any { if t == nil { return nil }; return t }
func (t *DoubleArray) GetClass__Class() *Class { return Prim_double.ArrayClass() }
func (t *DoubleArray) ToString__String() *String { return Object_toString(t) }
func (t *DoubleArray) Is_Cloneable() {}
func (t *DoubleArray) Is_Serializable() {}
func (t *DoubleArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :227:1
func (t /*line :228:1*/*DoubleArray) Copy() *DoubleArray {
	a := make([]float64, len(t.A))
	copy(a, t.A)
	return &DoubleArray{A: a} }
// RefArray is every array of references (Object[], String[], int[][] ...): Java's arrays are
// covariant, Go's slices are not. Comp is the component class.
type RefArray /*line :237:1*/ struct{ Object; Comp *Class; A []any }
// NewRefArray is new T[n] for a reference type T, comp its class.
func NewRefArray(comp /*line :240:1*/*Class, n int32) *RefArray {
	if n < 0 {
		panic(negativeArraySize(n)) }
	return newRefArray(comp, n) }
// refArrayBuf is a reference array whose slots follow its header in the same allocation
// (A2G-SPEC §13.4, D7; doc/go/SPEED-NOTES.md): B is an array type [N]any.
//line :245:1
type refArrayBuf[B any] /*line :249:1*/struct{ RefArray; buf B }
// newRefBuf allocates a RefArray of n <= N slots in one object, its slots the array B.
func newRefBuf[B any](comp /*line :253:1*/*Class, n int32) *RefArray {
	p := &refArrayBuf[B]{}
	p.Comp = comp
	p.A = unsafe.Slice((*any)(unsafe.Pointer(&p.buf)), n)
	return &p.RefArray }
// newRefArray is new T[n] (n >= 0): up to 32 slots in one allocation with the header, the
// lengths rounded up to Go's size classes, larger arrays as a header and a slice.
//line :259:1
func newRefArray(comp /*line :262:1*/*Class, n int32) *RefArray {
	switch {
	case n == 0: return &RefArray{Comp: comp, A: []any{}}
	case n == 1: return newRefBuf[[1]any](comp, n)
	case n == 2: return newRefBuf[[2]any](comp, n)
	case n == 3: return newRefBuf[[3]any](comp, n)
	case n == 4: return newRefBuf[[4]any](comp, n)
	case n == 5: return newRefBuf[[5]any](comp, n)
	case n == 6: return newRefBuf[[6]any](comp, n)
	case n == 7: return newRefBuf[[7]any](comp, n)
	case n == 8: return newRefBuf[[8]any](comp, n)
	case n == 9: return newRefBuf[[9]any](comp, n)
	case n == 10: return newRefBuf[[10]any](comp, n)
	case n == 11: return newRefBuf[[11]any](comp, n)
	case n == 12: return newRefBuf[[12]any](comp, n)
	case n == 13: return newRefBuf[[13]any](comp, n)
	case n <= 15: return newRefBuf[[15]any](comp, n)
	case n <= 17: return newRefBuf[[17]any](comp, n)
	case n <= 19: return newRefBuf[[19]any](comp, n)
	case n <= 21: return newRefBuf[[21]any](comp, n)
	case n <= 23: return newRefBuf[[23]any](comp, n)
	case n <= 25: return newRefBuf[[25]any](comp, n)
	case n <= 27: return newRefBuf[[27]any](comp, n)
	case n <= 29: return newRefBuf[[29]any](comp, n)
	case n <= 32: return newRefBuf[[32]any](comp, n)}
	return &RefArray{Comp: comp, A: make([]any, n)} }
// RefArrayOf is an array initializer of T[], comp T's class.
func RefArrayOf(comp /*line :290:1*/*Class, a ...any) *RefArray {
	if a == nil {
		a = []any{} }
	return &RefArray{Comp: comp, A: a}
}
func (t *RefArray) Ref() any { if t == nil { return nil }; return t }
func (t *RefArray) GetClass__Class() *Class { return t.Comp.ArrayClass() }
func (t *RefArray) ToString__String() *String { return Object_toString(t) }
func (t *RefArray) Is_Cloneable() {}
func (t *RefArray) Is_Serializable() {}
func (t *RefArray) Clone__O() any { return t.Copy() }
// Copy is clone() at the array's type.
//line :301:1
func (t /*line :302:1*/*RefArray) Copy() *RefArray {
	r := newRefArray(t.Comp, int32(len(t.A)))
	copy(r.A, t.A); return r }
// Store is aastore, a[i] = v with Java's checks in Java's order: the index
// (ArrayIndexOutOfBoundsException), then the store (ArrayStoreException naming v's class). The
// common case (in range, null or an Object[]) is small enough for gc to inline.
//line :307:1
func (t /*line :311:1*/*RefArray) Store(i int32, v any) {
	if uint32(i) < uint32(len(t.A)) && (v == nil || t.Comp == Object_class) {
		t.A[i] = v
		return }
	t.storeChecked(i, v) }
// storeChecked is Store's checks and store, out of line.
func (t /*line :318:1*/*RefArray) storeChecked(i int32, v any) {
	if uint32(i) >= uint32(len(t.A)) {
		panic(IndexOutOfBounds(int(i), len(t.A))) }
	if v != nil && t.Comp != Object_class && !t.Comp.IsInstance_O__Z(v) {
		panic(ArrayStoreException_New_String(Str(GetClass(v).GoName()))) }
	t.A[i] = v }
// newArray is new C[n] for any component class (Array.newInstance).
func newArray(comp /*line :326:1*/*Class, n int32) any {
	switch comp {
	case Prim_boolean: return NewBooleanArray(n)
	case Prim_byte: return NewByteArray(n)
	case Prim_char: return NewCharArray(n)
	case Prim_short: return NewShortArray(n)
	case Prim_int: return NewIntArray(n)
	case Prim_long: return NewLongArray(n)
	case Prim_float: return NewFloatArray(n)
	case Prim_double: return NewDoubleArray(n)
	case Prim_void: panic(IllegalArgumentException_New())}
	return NewRefArray(comp, n) }
// Array_NewInstance_Class_I__O is java.lang.reflect.Array.newInstance(Class, int).
func Array_NewInstance_Class_I__O(comp /*line :341:1*/*Class, n int32) any {
	return newArray(NN(comp), n) }
// NewMultiArray is multianewarray: new T[d0][d1]... for the array class cls with
// len(dims) <= its rank dimensions given; every size is checked before any is allocated.
//line :344:1
func NewMultiArray(cls /*line :347:1*/*Class, dims ...int32) *RefArray {
	for _, d := range dims {
		if d < 0 {
			panic(negativeArraySize(d)) } }
	return multiArray(cls, dims).(*RefArray)
}
func multiArray(cls *Class, dims []int32) any {
	if len(dims) == 1 {
		return newArray(cls.comp, dims[0]) }
	a := NewRefArray(cls.comp, dims[0])
	for i, _ := range a.A {
		a.A[i] = multiArray(cls.comp, dims[1:])
	}
	return a
}

func elemName(c *Class) string {
	if c.comp.IsPrimitive__Z() {
		return c.comp.GoName()
	}
	return "object array" }
func arrayLength(a any) int {
	switch x := a.(type) {
	case *BooleanArray: return len(x.A)
	case *ByteArray: return len(x.A)
	case *CharArray: return len(x.A)
	case *ShortArray: return len(x.A)
	case *IntArray: return len(x.A)
	case *LongArray: return len(x.A)
	case *FloatArray: return len(x.A)
	case *DoubleArray: return len(x.A)
	case *RefArray: return len(x.A)}; return -1 }
// Arraycopy is System.arraycopy, with HotSpot's checks and messages in its order: null
// (NullPointerException), not arrays or mismatched element types (ArrayStoreException), negative
// positions or length, then ranges (ArrayIndexOutOfBoundsException); overlapping copies within
// one array are correct; a reference copy that needs element checks copies up to the first
// element that fails and throws ArrayStoreException.
//line :381:1
func Arraycopy(src any, srcPos int32, dst any, dstPos, n int32) {







	{ x, xok := src.(*RefArray)
		y, yok := dst.(*RefArray)
		if xok && yok && x != nil && y != nil &&
			(x == y || y.Comp == Object_class || y.Comp == x.Comp) &&
			srcPos >= 0 && dstPos >= 0 && n >= 0 &&
			int64(srcPos)+int64(n) <= int64(len(x.A)) &&
			int64(dstPos)+int64(n) <= int64(len(y.A)) {
				copy(y.A[dstPos:], x.A[srcPos:srcPos+n])
				return } }
	if src == nil || dst == nil {
		panic(NPE()) }
	sc := GetClass(src)
	dc := GetClass(dst)
	if !sc.IsArray__Z() {
		panic(ArrayStoreException_New_String(Str("arraycopy: source type " + sc.GoName() + " is not an array"))) }
	if !dc.IsArray__Z() {
		panic(ArrayStoreException_New_String(Str("arraycopy: destination type " + dc.GoName() + " is not an array"))) }
	{ sp := sc.comp.IsPrimitive__Z()
		dp := dc.comp.IsPrimitive__Z()
		if sp != dp || sp && sc.comp != dc.comp {
			panic(ArrayStoreException_New_String(
				Str("arraycopy: type mismatch: can not copy " + elemName(sc) + "[] into " + elemName(dc) + "[]"))) } }
	{ sl := arrayLength(src)
		dl := arrayLength(dst)
		en := elemName(sc)
		if
			srcPos < 0 {
				panic(ArrayIndexOutOfBoundsException_New_String(
					Str("arraycopy: source index " + strconv.Itoa(int(srcPos)) + " out of bounds for " + en + "[" + strconv.Itoa(sl) + "]")))
			} else if dstPos < 0 {
				panic(ArrayIndexOutOfBoundsException_New_String(
					Str("arraycopy: destination index " + strconv.Itoa(int(dstPos)) + " out of bounds for " + elemName(dc) + "[" + strconv.Itoa(dl) + "]")))
			} else if n < 0 {
				panic(ArrayIndexOutOfBoundsException_New_String(
					Str("arraycopy: length " + strconv.Itoa(int(n)) + " is negative"))) }
		se := uint32(n) + uint32(srcPos)
		de := uint32(n) + uint32(dstPos)
		if se > uint32(sl) {
			panic(ArrayIndexOutOfBoundsException_New_String(
				Str("arraycopy: last source index " + strconv.FormatUint(uint64(se), 10) + " out of bounds for " + en + "[" + strconv.Itoa(sl) + "]"))) }
		if de > uint32(dl) {
			panic(ArrayIndexOutOfBoundsException_New_String(
				Str("arraycopy: last destination index " + strconv.FormatUint(uint64(de), 10) + " out of bounds for " + elemName(dc) + "[" + strconv.Itoa(dl) + "]"))) } }
	if n == 0 {
		return }
	s := int(srcPos)
	d := int(dstPos)
	e := int(n)
	switch x := src.(type) {
	case *BooleanArray: copy(dst.(*BooleanArray).A[d:], x.A[s:s+e])
	case *ByteArray: copy(dst.(*ByteArray).A[d:], x.A[s:s+e])
	case *CharArray: copy(dst.(*CharArray).A[d:], x.A[s:s+e])
	case *ShortArray: copy(dst.(*ShortArray).A[d:], x.A[s:s+e])
	case *IntArray: copy(dst.(*IntArray).A[d:], x.A[s:s+e])
	case *LongArray: copy(dst.(*LongArray).A[d:], x.A[s:s+e])
	case *FloatArray: copy(dst.(*FloatArray).A[d:], x.A[s:s+e])
	case *DoubleArray: copy(dst.(*DoubleArray).A[d:], x.A[s:s+e])
	case *RefArray:
		y := dst.(*RefArray)
		if x == y || y.Comp.assignableFrom(x.Comp) {
			copy(y.A[d:], x.A[s:s+e]) } else {
				for i := 0; i < e; i++ {
					v := x.A[s+i]
					if v != nil && !y.Comp.IsInstance_O__Z(v) {
						if !x.Comp.assignableFrom(y.Comp) {
							panic(ArrayStoreException_New_String(
								Str("arraycopy: type mismatch: can not copy " + x.Comp.GoName() + "[] into " + y.Comp.GoName() + "[]"))) } else {
									panic(ArrayStoreException_New_String(
										Str("arraycopy: element type mismatch: can not cast one of the elements of " +
											x.Comp.GoName() + "[] to the type of the destination array, " + y.Comp.GoName()))) } }
					y.A[d+i] = v } }} }
// System_Arraycopy_O_I_O_I_I__V is System.arraycopy (System is phase 2's; this member is the
// object model's).
//line :461:1
func System_Arraycopy_O_I_O_I_I__V(src any, srcPos int32, dst any, dstPos, n int32) {



	Arraycopy(src, srcPos, dst, dstPos, n) }
// System_IdentityHashCode_O__I is System.identityHashCode.
func System_IdentityHashCode_O__I(x any) int32 {

	return IdentityHash(x)
}
