//line java_text_RBTableBuilder.ae:1
package jrt








func RBTableBuilder_New_RBCollationTables_BuildAPI(p0 *RBCollationTables_BuildAPI) *RBTableBuilder { t := &RBTableBuilder{}; t.Ctor_RBCollationTables_BuildAPI(p0); return t }
//line :10:1
func (t *RBTableBuilder) Ctor_RBCollationTables_BuildAPI(tables *RBCollationTables_BuildAPI) { t.F_tables = nil; t.F_mPattern = nil; t.F_isOverIgnore = false; t.F_keyBuf = NewCharArray(5); t.F_contractFlags = IntHashtable_New_I(100); t.F_frenchSec = false; t.F_seAsianSwapping = false; t.F_mapping = nil; t.F_contractTable = nil; t.F_expandTable = nil; t.F_maxSecOrder = 0; t.F_maxTerOrder = 0
	t.F_tables = tables
}
func (t *RBTableBuilder) Build_String_I__V(pattern *String, decmp int32) {
	var expChars *String; var groupChars *String

	if NN(pattern).IsEmpty__Z() { panic(Thrown(ParseException_New_String_I(Lit_1968, 0))) }
	t.F_mapping = UCompactIntArray_New_I(-1)
	pattern = NormalizerImpl_CanonicalDecomposeWithSingleQuotation_String__String(pattern)
	t.F_mPattern = MergeCollation_New_String(pattern)
	var order int32 = 0; var i int32 = 0
L1: for {
	if i < NN(t.F_mPattern).GetCount__I() {
		var entry *PatternEntry = NN(t.F_mPattern).GetItemAt_I__PatternEntry(i)
		if !(entry == nil) {

			groupChars = NN(entry).GetChars__String()
			if NN(groupChars).Length__I() > 1 {
				switch int32(NN(groupChars).CharAt_I__C(NN(groupChars).Length__I() - 1)) { case 64:


					t.F_frenchSec = true
					groupChars = NN(groupChars).Substring_I_I__String(0, NN(groupChars).Length__I()-1); case 33:





					t.F_seAsianSwapping = true
					groupChars = NN(groupChars).Substring_I_I__String(0, NN(groupChars).Length__I()-1); default:
				}
			}

			order = t.Increment_I_I__I(NN(entry).GetStrength__I(), order)
			expChars = NN(entry).GetExtension__String()
			if !NN(expChars).IsEmpty__Z() {


				t.AddExpandOrder_String_String_I__V(groupChars, expChars, order)
				i = i + 1; continue L1 } else {
//line :45:1
					if NN(groupChars).Length__I() > 1 {





						var ch uint16 = NN(groupChars).CharAt_I__C(0); var tmp1 bool; var tmp2 bool
						tmp2 = Character_IsHighSurrogate_C__Z(ch); if tmp2 { tmp2 = NN(groupChars).Length__I() == 2 }; tmp1 = tmp2; if tmp1 {

							t.AddOrder_I_I__V(Character_ToCodePoint_C_C__I(ch, NN(groupChars).CharAt_I__C(1)), order)


							i = i + 1; continue L1 } else {

								t.AddContractOrder_String_I__V(groupChars, order)
								i = i + 1; continue L1 } } else {

									var ch_2 uint16 = NN(groupChars).CharAt_I__C(0)
									t.AddOrder_I_I__V(int32(ch_2), order)
									i = i + 1; continue L1 } } } else {
										i = i + 1; continue L1 } }
//line :21:1
	break L1
}











































	t.AddComposedChars__V()
	t.Commit__V()
	NN(t.F_mapping).Compact__V()
	NN(t.F_tables).FillInTables_Z_Z_UCompactIntArray_Vector_Vector_IntHashtable_S_S__V(t.F_frenchSec, t.F_seAsianSwapping, t.F_mapping, t.F_contractTable, t.F_expandTable, t.F_contractFlags, t.F_maxSecOrder, t.F_maxTerOrder)
}








func (t *RBTableBuilder) AddComposedChars__V() {
	var iter *ComposedCharIter = ComposedCharIter_New()
	var c int32 = 0
L1: for { var tmp1 int32; c = NN(iter).Next__I(); tmp1 = c; if !(tmp1 == -1) {
	if t.GetCharOrder_I__I(c) == -1 {
		var s *String = NN(iter).Decomposition__String()
		if NN(s).Length__I() == 1 {
			var order int32 = t.GetCharOrder_I__I(int32(NN(s).CharAt_I__C(0)))
			if order == -1 { } else { t.AddOrder_I_I__V(c, order) } } else {

				if NN(s).Length__I() == 2 {
					var ch0 uint16 = NN(s).CharAt_I__C(0)
					if Character_IsHighSurrogate_C__Z(ch0) {
						var order_2 int32 = t.GetCharOrder_I__I(NN(s).CodePointAt_I__I(0))
						if order_2 == -1 { } else { t.AddOrder_I_I__V(c, order_2) }
						continue L1 } }
				var contractOrder int32 = t.GetContractOrder_String__I(s)
				if !(contractOrder == -1) {
					t.AddOrder_I_I__V(c, contractOrder) } else {
						var allThere bool = true; var i int32 = 0
					L2: for {
						if i < NN(s).Length__I() {
							if t.GetCharOrder_I__I(int32(NN(s).CharAt_I__C(i))) == -1 {

								allThere = false } else {
									i = i + 1; continue L2 } }
//line :99:1
						break L2
					}





						if allThere { t.AddExpandOrder_I_String_I__V(c, s, -1) } } } }
//line :82:1
	continue L1 }; break L1
}
}























func (t *RBTableBuilder) Commit__V() {
	if !(t.F_expandTable == nil) {
		var i int32 = 0; L1: for {
			if i < t.F_expandTable.Size__I() {
				var valueList *IntArray = A2g_CastArray[*IntArray](t.F_expandTable.ElementAt_I__O(i), Prim_int.ArrayClass()); var j int32 = 0
			L2: for {
				if j < int32(len(valueList.A)) {
					var order int32 = valueList.A[j]; var tmp1 bool; var tmp2 bool
					tmp2 = order < 2113929216; if tmp2 { tmp2 = order > 1879048192 }; tmp1 = tmp2; if tmp1 {
						var ch int32 = order - 1879048192; var realValue int32 = t.GetCharOrder_I__I(ch)

						if realValue == -1 {

							valueList.A[j] = 65535 & ch
							j = j + 1; continue L2 } else {
								valueList.A[j] = realValue; j = j + 1; continue L2 } } else {
									j = j + 1; continue L2 } }
//line :113:1
				break L2
			}










				i = i + 1; continue L1 }
//line :110:1
			break L1
		}
	}
}













func (t *RBTableBuilder) Increment_I_I__I(aStrength, lastValue int32) int32 {
	switch aStrength { case 0:


		lastValue = lastValue + 65536
		lastValue = lastValue & -65536
		t.F_isOverIgnore = true; case 1:


		lastValue = lastValue + 256
		lastValue = lastValue & -256
		if t.F_isOverIgnore { } else {
			t.F_maxSecOrder = int16(int32(t.F_maxSecOrder) + 1) }; case 2:


		lastValue = lastValue + 1
		if t.F_isOverIgnore { } else {
			t.F_maxTerOrder = int16(int32(t.F_maxTerOrder) + 1) }; default:}
//line :127:1
	return lastValue
}


















func (t *RBTableBuilder) AddOrder_I_I__V(ch, anOrder int32) {
	var order int32 = NN(t.F_mapping).ElementAt_I__I(ch)
	if order >= 2130706432 {
		var length int32 = 1
		if Character_IsSupplementaryCodePoint_I__Z(ch) {
			length = Character_ToChars_I_C1_I__I(ch, t.F_keyBuf, 0) } else {
				t.F_keyBuf.A[0] = uint16(ch) }
		t.AddContractOrder_String_I__V(String_New_C1_I_I(t.F_keyBuf, 0, length), anOrder) } else {
			NN(t.F_mapping).SetElementAt_I_I__V(ch, anOrder)
		} }
func (t *RBTableBuilder) AddContractOrder_String_I__V(groupChars *String, anOrder int32) {
	t.AddContractOrder_String_I_Z__V(groupChars, anOrder, true)
}
func (t *RBTableBuilder) AddContractOrder_String_I_Z__V(groupChars *String, anOrder int32, fwd bool) {

	if t.F_contractTable == nil { t.F_contractTable = Vector_New_I(20) }
	var ch int32 = NN(groupChars).CodePointAt_I__I(0); var entry int32 = NN(t.F_mapping).ElementAt_I__I(ch); var entryTable Vector_I = t.GetContractValuesImpl_I__Vector(entry - 2130706432)






	if entryTable == nil {
		var tableIndex int32 = 2130706432 + t.F_contractTable.Size__I()

		entryTable = Vector_New_I(20)
		t.F_contractTable.AddElement_O__V(entryTable)
		entryTable.AddElement_O__V(EntryPair_New_String_I(NN(groupChars).Substring_I_I__String(0, Character_CharCount_I__I(ch)), entry))

		NN(t.F_mapping).SetElementAt_I_I__V(ch, tableIndex) }
	var index int32 = RBCollationTables_GetEntry_Vector_String_Z__I(entryTable, groupChars, fwd)
	if !(index == -1) {
		var pair *EntryPair = EntryPair_Cast(entryTable.ElementAt_I__O(index))
		pair.F_value = anOrder } else {
			var pair_2 *EntryPair = EntryPair_Cast(entryTable.LastElement__O())
			if NN(groupChars).Length__I() > NN(pair_2.F_entryName).Length__I() {
				entryTable.AddElement_O__V(EntryPair_New_String_I_Z(groupChars, anOrder, fwd)) } else {
					entryTable.InsertElementAt_O_I__V(EntryPair_New_String_I_Z(groupChars, anOrder, fwd), entryTable.Size__I()-1)
				}
		}
	var tmp1 bool; var tmp2 bool; tmp2 = fwd; if tmp2 { tmp2 = NN(groupChars).Length__I() > 1 }; tmp1 = tmp2; if tmp1 {
		t.AddContractFlags_String__V(groupChars)
		t.AddContractOrder_String_I_Z__V(NN(StringBuilder_New_String(groupChars).Reverse__StringBuilder()).ToString__String(), anOrder, false)
	} }
func (t *RBTableBuilder) GetContractOrder_String__I(groupChars *String) int32 {
	var result int32 = -1
	if !(t.F_contractTable == nil) {
		var ch int32 = NN(groupChars).CodePointAt_I__I(0); var entryTable Vector_I = t.GetContractValues_I__Vector(ch)

		if !(entryTable == nil) {
			var index int32 = RBCollationTables_GetEntry_Vector_String_Z__I(entryTable, groupChars, true)
			if index == -1 { } else {
				var pair *EntryPair = EntryPair_Cast(entryTable.ElementAt_I__O(index))
				result = pair.F_value } } }
//line :193:1
	return result
}









func (t *RBTableBuilder) GetCharOrder_I__I(ch int32) int32 {
	var order int32 = NN(t.F_mapping).ElementAt_I__I(ch)
	if order >= 2130706432 {
		var groupList Vector_I = t.GetContractValuesImpl_I__Vector(order - 2130706432); var pair *EntryPair = EntryPair_Cast(groupList.FirstElement__O())





		order = pair.F_value }
//line :205:1
	return order
}









func (t *RBTableBuilder) GetContractValues_I__Vector(ch int32) Vector_I {
	var index int32 = NN(t.F_mapping).ElementAt_I__I(ch)
	return t.GetContractValuesImpl_I__Vector(index - 2130706432)
}

func (t *RBTableBuilder) GetContractValuesImpl_I__Vector(index int32) Vector_I {
	if index >= 0 { return Vector_Cast(t.F_contractTable.ElementAt_I__O(index)) } else { return nil
	} }
func (t *RBTableBuilder) AddExpandOrder_String_String_I__V(contractChars, expandChars *String, anOrder int32) {



	var tableIndex int32 = t.AddExpansion_I_String__I(anOrder, expandChars)
	if NN(contractChars).Length__I() > 1 {
		var ch uint16 = NN(contractChars).CharAt_I__C(0); var tmp1 bool; var tmp2 bool
		tmp2 = Character_IsHighSurrogate_C__Z(ch); if tmp2 { tmp2 = NN(contractChars).Length__I() == 2 }; tmp1 = tmp2; if tmp1 {
			var ch2 uint16 = NN(contractChars).CharAt_I__C(1)
			if Character_IsLowSurrogate_C__Z(ch2) {
				t.AddOrder_I_I__V(Character_ToCodePoint_C_C__I(ch, ch2), tableIndex) } } else {
					t.AddContractOrder_String_I__V(contractChars, tableIndex) } } else {
						t.AddOrder_I_I__V(int32(NN(contractChars).CharAt_I__C(0)), tableIndex)
					} }
func (t *RBTableBuilder) AddExpandOrder_I_String_I__V(ch int32, expandChars *String, anOrder int32) {


	var tableIndex int32 = t.AddExpansion_I_String__I(anOrder, expandChars); t.AddOrder_I_I__V(ch, tableIndex)
}
func (t *RBTableBuilder) AddExpansion_I_String__I(anOrder int32, expandChars *String) int32 {
	if t.F_expandTable == nil { t.F_expandTable = Vector_New_I(20) }
	var offset int32; if anOrder == -1 { offset = 0 } else { offset = 1 }; var valueList *IntArray = NewIntArray(NN(expandChars).Length__I() + offset)

	if offset == 1 { valueList.A[0] = anOrder }
	var j int32 = offset
	var i int32 = 0
L1: for { if i < NN(expandChars).Length__I() {
	var ch0 uint16 = NN(expandChars).CharAt_I__C(i)
	var ch1 uint16 = 0
	var ch int32 = 0
	if Character_IsHighSurrogate_C__Z(ch0) {

		var tmp1 bool; var tmp2 bool; var tmp3 int32; i = i + 1; tmp3 = i; tmp2 = tmp3 == NN(expandChars).Length__I(); if !tmp2 {
			var tmp4 uint16; ch1 = NN(expandChars).CharAt_I__C(i); tmp4 = ch1; tmp2 = !Character_IsLowSurrogate_C__Z(tmp4) }
//line :256:1
		tmp1 = tmp2; if tmp1 {

			break L1 }
		ch = Character_ToCodePoint_C_C__I(ch0, ch1) } else {
			ch = int32(ch0) }
	var mapValue int32 = t.GetCharOrder_I__I(ch)
	if !(mapValue == -1) {
		valueList.A[j] = mapValue; j = j + 1 } else {

			valueList.A[j] = 1879048192 + ch
			j = j + 1 }
	i = i + 1
//line :250:1
	continue L1 }; break L1
}
















	if j < int32(len(valueList.A)) {
		var tmpBuf *IntArray = NewIntArray(j)
	L2: for { var tmp5 int32; j = j - 1; tmp5 = j; if tmp5 >= 0 { tmpBuf.A[j] = valueList.A[j]; continue L2 }; break L2 }
		valueList = tmpBuf }
	var tableIndex int32 = 2113929216 + t.F_expandTable.Size__I()
	t.F_expandTable.AddElement_O__V(valueList.Ref())
//line :272:1
	return tableIndex
}


func (t *RBTableBuilder) AddContractFlags_String__V(chars *String) {
	var c0 uint16 = 0; var c int32 = 0; var len_ int32 = NN(chars).Length__I()
	var i int32 = 0


L1: for { if i < len_ {
	c0 = NN(chars).CharAt_I__C(i)
	var tmp1 int32
	if Character_IsHighSurrogate_C__Z(c0) {
		var tmp2 uint16 = c0; var tmp3 int32; i = i + 1; tmp3 = i; tmp1 = Character_ToCodePoint_C_C__I(tmp2, NN(chars).CharAt_I__C(tmp3)) } else {
			tmp1 = int32(c0) }
//line :283:1
	c = tmp1



	NN(t.F_contractFlags).Put_I_I__V(c, 1)
	i = i + 1
//line :281:1
	continue L1 }; break L1
}
}








type RBTableBuilder struct{ Object; F_tables *RBCollationTables_BuildAPI; F_mPattern *MergeCollation; F_isOverIgnore bool; F_keyBuf *CharArray; F_contractFlags *IntHashtable; F_frenchSec, F_seAsianSwapping bool; F_mapping *UCompactIntArray; F_contractTable, F_expandTable Vector_I; F_maxSecOrder, F_maxTerOrder int16 }

const RBTableBuilder_CHARINDEX int32 = 1879048192

const RBTableBuilder_IGNORABLEMASK int32 = 65535

const RBTableBuilder_PRIMARYORDERINCREMENT int32 = 65536

const RBTableBuilder_SECONDARYORDERINCREMENT int32 = 256

const RBTableBuilder_TERTIARYORDERINCREMENT int32 = 1

const RBTableBuilder_INITIALTABLESIZE int32 = 20

const RBTableBuilder_MAXKEYSIZE int32 = 5

func (t *RBTableBuilder) Ref() any { if t == nil { return nil }; return t }

func (t *RBTableBuilder) GetClass__Class() *Class { return RBTableBuilder_class }

func (t *RBTableBuilder) ToString__String() *String { return Object_toString(t) }

func (t *RBTableBuilder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *RBTableBuilder) CloneShallow() any { panic(CloneNotSupported(t)) }

func RBTableBuilder_InstanceOf(x any) bool { _, ok := x.(*RBTableBuilder); return ok }

func RBTableBuilder_Cast(x any) *RBTableBuilder { if x == nil { return nil }; v, ok := x.(*RBTableBuilder); if !ok { panic(ClassCast(x, RBTableBuilder_class)) }; return v }
