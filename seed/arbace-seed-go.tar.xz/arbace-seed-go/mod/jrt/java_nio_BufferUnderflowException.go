//line java_nio_BufferUnderflowException.ae:1
package jrt








func BufferUnderflowException_New() *BufferUnderflowException { t := &BufferUnderflowException{}; t.Ctor(); return t }
//line :10:1
func (t *BufferUnderflowException) Ctor() { t.RuntimeException.Ctor(t) }





type BufferUnderflowException struct{ RuntimeException }

const BufferUnderflowException_serialVersionUID int64 = -1713313658691622206

func (t *BufferUnderflowException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *BufferUnderflowException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *BufferUnderflowException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *BufferUnderflowException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *BufferUnderflowException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *BufferUnderflowException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *BufferUnderflowException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *BufferUnderflowException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *BufferUnderflowException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *BufferUnderflowException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *BufferUnderflowException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *BufferUnderflowException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *BufferUnderflowException) Ref() any { if t == nil { return nil }; return t }

func (t *BufferUnderflowException) GetClass__Class() *Class { return BufferUnderflowException_class }

func (t *BufferUnderflowException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BufferUnderflowException) CloneShallow() any { panic(CloneNotSupported(t)) }

func BufferUnderflowException_InstanceOf(x any) bool { _, ok := x.(*BufferUnderflowException); return ok }

func BufferUnderflowException_Cast(x any) *BufferUnderflowException { if x == nil { return nil }; v, ok := x.(*BufferUnderflowException); if !ok { panic(ClassCast(x, BufferUnderflowException_class)) }; return v }
