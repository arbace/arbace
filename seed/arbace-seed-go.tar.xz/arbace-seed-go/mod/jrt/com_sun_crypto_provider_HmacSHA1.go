//line com_sun_crypto_provider_HmacSHA1.ae:1
package jrt








func HmacSHA1_New() *HmacSHA1 { t := &HmacSHA1{}; t.Ctor(); return t }
//line :10:1
func (t *HmacSHA1) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_16, 64) }





type HmacSHA1 struct{ HmacCore }

func (t *HmacSHA1) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacSHA1) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacSHA1) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacSHA1) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacSHA1) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacSHA1) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacSHA1) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacSHA1) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacSHA1) Ref() any { if t == nil { return nil }; return t }

func (t *HmacSHA1) GetClass__Class() *Class { return HmacSHA1_class }

func (t *HmacSHA1) ToString__String() *String { return Object_toString(t) }

func (t *HmacSHA1) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacSHA1_InstanceOf(x any) bool { _, ok := x.(*HmacSHA1); return ok }

func HmacSHA1_Cast(x any) *HmacSHA1 { if x == nil { return nil }; v, ok := x.(*HmacSHA1); if !ok { panic(ClassCast(x, HmacSHA1_class)) }; return v }
