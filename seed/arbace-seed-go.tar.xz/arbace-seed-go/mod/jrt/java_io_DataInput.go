//line java_io_DataInput.ae:1
package jrt






type DataInput interface{ Object_I; Is_DataInput(); ReadFully_B1__V(p0 *ByteArray); ReadFully_B1_I_I__V(p0 *ByteArray, p1, p2 int32); SkipBytes_I__I(p0 int32) int32; ReadBoolean__Z() bool; ReadByte__B() int8; ReadUnsignedByte__I() int32; ReadShort__S() int16; ReadUnsignedShort__I() int32; ReadChar__C() uint16; ReadInt__I() int32; ReadLong__J() int64; ReadFloat__F() float32; ReadDouble__D() float64; ReadLine__String() *String; ReadUTF__String() *String }

func DataInput_InstanceOf(x any) bool { _, ok := x.(DataInput); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DataInput_class) } }; return ok }

func DataInput_Cast(x any) DataInput { if x == nil { return nil }; v, ok := x.(DataInput); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DataInput_class) } }; if !ok { panic(ClassCast(x, DataInput_class)) }; return v }
