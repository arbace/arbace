//line java_lang_Iterable.ae:1
package jrt











func Iterable_ForEach_Consumer__V(this Iterable, action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var i_101061 Iterator = this.Iterator__Iterator(); for i_101061.HasNext__Z() { var t_ any = i_101061.Next__O(); action.Accept_O__V(t_)
	} }
func Iterable_Spliterator__Spliterator(this Iterable) Spliterator {
	return Spliterators_SpliteratorUnknownSize_Iterator_I__Spliterator(this.Iterator__Iterator(), 0)
}


type Iterable interface{ Object_I; Is_Iterable(); Iterator__Iterator() Iterator; ForEach_Consumer__V(p0 Consumer); Spliterator__Spliterator() Spliterator }

func Iterable_InstanceOf(x any) bool { _, ok := x.(Iterable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Iterable_class) } }; return ok }

func Iterable_Cast(x any) Iterable { if x == nil { return nil }; v, ok := x.(Iterable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Iterable_class) } }; if !ok { panic(ClassCast(x, Iterable_class)) }; return v }
