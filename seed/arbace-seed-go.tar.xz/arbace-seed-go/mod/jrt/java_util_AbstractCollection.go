//line java_util_AbstractCollection.ae:1
package jrt










func (t *AbstractCollection) Ctor(this AbstractCollection_I) {}





func (t *AbstractCollection) Impl_IsEmpty__Z(this AbstractCollection_I) bool { return this.Size__I() == 0 }

func (t *AbstractCollection) Impl_Contains_O__Z(this AbstractCollection_I, o any) bool {
	var it Iterator = this.Iterator__Iterator()
	if o == nil {
	L1: for { if it.HasNext__Z() { if it.Next__O() == nil { return true }; continue L1 }; break L1 } } else {
	L2: for { if it.HasNext__Z() { if Equals(o, it.Next__O()) { return true }; continue L2 }; break L2 } }
//line :21:1
	return false
}




func (t *AbstractCollection) Impl_ToArray__O1(this AbstractCollection_I) *RefArray {
	var r *RefArray = NewRefArray(Object_class, this.Size__I()); var it Iterator = this.Iterator__Iterator()
	var i int32 = 0
L1: for {
	if i < int32(len(r.A)) {
		if it.HasNext__Z() { } else { return Arrays_CopyOf_O1_I__O1(r, i) }
		r.Store(i, it.Next__O())
		i = i + 1; continue L1 }
//line :30:1
	break L1
}



	if it.HasNext__Z() { return AbstractCollection_FinishToArray_O1_Iterator__O1(r, it) } else { return r
	} }
func (t *AbstractCollection) Impl_ToArray_O1__O1(this AbstractCollection_I, a *RefArray) *RefArray {
	var size int32 = this.Size__I(); var r *RefArray
	if int32(len(a.A)) >= size { r = a } else {

		r = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass()) }
//line :38:1
	var it Iterator = this.Iterator__Iterator()
	var i int32 = 0



L1: for {
	if i < int32(len(r.A)) {
		if it.HasNext__Z() { } else {
			if a == r {
				r.Store(i, nil) } else {
//line :46:1
					if int32(len(a.A)) < i {

						return Arrays_CopyOf_O1_I__O1(r, i) } else {
							System_Arraycopy_O_I_O_I_I__V(r.Ref(), 0, a.Ref(), 0, i); if int32(len(a.A)) > i { a.Store(i, nil) } } }
			return a }
		r.Store(i, it.Next__O())
		i = i + 1; continue L1 }
//line :43:1
	break L1
}








	if it.HasNext__Z() { return AbstractCollection_FinishToArray_O1_Iterator__O1(r, it) } else { return r
	} }
func AbstractCollection_FinishToArray_O1_Iterator__O1(r *RefArray, it Iterator) *RefArray {

	var len_ int32 = int32(len(r.A))
	var i int32 = len_
L1: for { if it.HasNext__Z() {
	if i == len_ {
		len_ = ArraysSupport_NewLength_I_I_I__I(len_, 1, len_>>1+1)

		r = Arrays_CopyOf_O1_I__O1(r, len_) }
	r.Store(i, it.Next__O())
	i = i + 1
//line :59:1
	continue L1 }; break L1
}





	if i == len_ { return r } else { return Arrays_CopyOf_O1_I__O1(r, i)
	} }
func (t *AbstractCollection) Impl_Add_O__Z(this AbstractCollection_I, e any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *AbstractCollection) Impl_Remove_O__Z(this AbstractCollection_I, o any) bool {
	var it Iterator = this.Iterator__Iterator()
	if o == nil {
	L1: for { if it.HasNext__Z() { if it.Next__O() == nil { it.Remove__V(); return true }; continue L1 }; break L1 } } else {
	L2: for { if it.HasNext__Z() { if Equals(o, it.Next__O()) { it.Remove__V(); return true }; continue L2 }; break L2 } }
//line :72:1
	return false
}




func (t *AbstractCollection) Impl_ContainsAll_Collection__Z(this AbstractCollection_I, c Collection) bool {
	var i_101720 Iterator = c.Iterator__Iterator(); for i_101720.HasNext__Z() { var e any = i_101720.Next__O(); if this.Contains_O__Z(e) { } else { return false } }
//line :78:1
	return true
}


func (t *AbstractCollection) Impl_AddAll_Collection__Z(this AbstractCollection_I, c Collection) bool {
	var modified bool = false; var i_101721 Iterator = c.Iterator__Iterator(); for i_101721.HasNext__Z() {
		var e any = i_101721.Next__O(); if this.Add_O__Z(e) { modified = true } }
//line :83:1
	return modified
}


func (t *AbstractCollection) Impl_RemoveAll_Collection__Z(this AbstractCollection_I, c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var it Iterator = this.Iterator__Iterator()

L1: for { if it.HasNext__Z() { if c.Contains_O__Z(it.Next__O()) { it.Remove__V(); modified = true }; continue L1 }; break L1 }
//line :89:1
	return modified
}



func (t *AbstractCollection) Impl_RetainAll_Collection__Z(this AbstractCollection_I, c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var it Iterator = this.Iterator__Iterator()

L1: for { if it.HasNext__Z() { if c.Contains_O__Z(it.Next__O()) { } else { it.Remove__V(); modified = true }; continue L1 }; break L1 }
//line :96:1
	return modified
}



func (t *AbstractCollection) Impl_Clear__V(this AbstractCollection_I) {
	var it Iterator = this.Iterator__Iterator(); L1: for { if it.HasNext__Z() { it.Next__O(); it.Remove__V(); continue L1 }; break L1
	} }
func (t *AbstractCollection) Impl_ToString__String(this AbstractCollection_I) *String {
	{ var it Iterator = this.Iterator__Iterator()
		if !it.HasNext__Z() { return Lit_2589 } else {

			var sb *StringBuilder = StringBuilder_New()
			NN(sb).Append_C__StringBuilder(91)
		L1: for {
			var e any = it.Next__O(); var tmp1 any
			if any(e) == any(this) { tmp1 = Lit_2590 } else { tmp1 = e }; NN(sb).Append_O__StringBuilder(tmp1)
			if it.HasNext__Z() { } else { return NN(NN(sb).Append_C__StringBuilder(93)).ToString__String() }
			NN(NN(sb).Append_C__StringBuilder(44)).Append_C__StringBuilder(32)
//line :110:1
			continue L1
		}
		}
	}
	panic("a2g: unreachable")
}


type AbstractCollection struct{ Object }

type AbstractCollection_I interface{ Object_I; Collection; Iterable; Self_AbstractCollection() *AbstractCollection; Iterator__Iterator() Iterator; Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; AddAll_Collection__Z(p0 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; Clear__V() }

func (t *AbstractCollection) Self_AbstractCollection() *AbstractCollection { return t }

func (t *AbstractCollection) Is_Collection() {}

func (t *AbstractCollection) Is_Iterable() {}

func AbstractCollection_InstanceOf(x any) bool { _, ok := x.(AbstractCollection_I); return ok }

func AbstractCollection_Cast(x any) AbstractCollection_I { if x == nil { return nil }; v, ok := x.(AbstractCollection_I); if !ok { panic(ClassCast(x, AbstractCollection_class)) }; return v }
