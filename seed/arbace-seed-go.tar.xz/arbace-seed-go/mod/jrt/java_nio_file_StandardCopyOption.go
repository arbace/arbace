//line java_nio_file_StandardCopyOption.ae:1
package jrt






type StandardCopyOption struct{ Enum }

func (t *StandardCopyOption) Is_CopyOption() {}

func (t *StandardCopyOption) Is_Constable() {}

var StandardCopyOption_REPLACE_EXISTING *StandardCopyOption

var StandardCopyOption_COPY_ATTRIBUTES *StandardCopyOption

var StandardCopyOption_ATOMIC_MOVE *StandardCopyOption

var StandardCopyOption__VALUES *RefArray

var StandardCopyOption_init ClassInit

func StandardCopyOption_Init() { if !StandardCopyOption_init.Done() { StandardCopyOption_init.Run(StandardCopyOption_clinit) } }

func StandardCopyOption_clinit() { StandardCopyOption_REPLACE_EXISTING = StandardCopyOption_New_String_I(Lit_1506, 0); StandardCopyOption_COPY_ATTRIBUTES = StandardCopyOption_New_String_I(Lit_1507, 1); StandardCopyOption_ATOMIC_MOVE = StandardCopyOption_New_String_I(Lit_1508, 2); StandardCopyOption__VALUES = StandardCopyOption_X_values__StandardCopyOption1() }

func StandardCopyOption_New_String_I(p0 *String, p1 int32) *StandardCopyOption { StandardCopyOption_Init(); t := &StandardCopyOption{}; t.Ctor_String_I(p0, p1); return t }

func (t *StandardCopyOption) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func StandardCopyOption_Values__StandardCopyOption1() *RefArray { StandardCopyOption_Init(); return StandardCopyOption__VALUES.Copy() }

func StandardCopyOption_ValueOf_String__StandardCopyOption(p0 *String) *StandardCopyOption { StandardCopyOption_Init(); return StandardCopyOption_Cast(Enum_ValueOf_Class_String__Enum(StandardCopyOption_class, p0)) }

func StandardCopyOption_X_values__StandardCopyOption1() *RefArray { StandardCopyOption_Init(); return RefArrayOf(StandardCopyOption_class, StandardCopyOption_REPLACE_EXISTING, StandardCopyOption_COPY_ATTRIBUTES, StandardCopyOption_ATOMIC_MOVE) }

func (t *StandardCopyOption) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *StandardCopyOption) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *StandardCopyOption) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *StandardCopyOption) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.nio.file.StandardCopyOption.describeConstable()Ljava/util/Optional;")) }

func (t *StandardCopyOption) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *StandardCopyOption) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *StandardCopyOption) Ref() any { if t == nil { return nil }; return t }

func (t *StandardCopyOption) GetClass__Class() *Class { return StandardCopyOption_class }

func (t *StandardCopyOption) CloneShallow() any { panic(CloneNotSupported(t)) }

func StandardCopyOption_InstanceOf(x any) bool { _, ok := x.(*StandardCopyOption); return ok }

func StandardCopyOption_Cast(x any) *StandardCopyOption { if x == nil { return nil }; v, ok := x.(*StandardCopyOption); if !ok { panic(ClassCast(x, StandardCopyOption_class)) }; return v }
