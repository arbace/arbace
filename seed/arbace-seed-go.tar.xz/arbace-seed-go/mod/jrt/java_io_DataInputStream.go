//line java_io_DataInputStream.ae:1
package jrt


















func DataInputStream_New_InputStream(p0 InputStream_I) *DataInputStream { DataInputStream_Init(); t := &DataInputStream{}; t.Ctor_InputStream(p0); return t }
//line :20:1
func (t *DataInputStream) Ctor_InputStream(in InputStream_I) { t.FilterInputStream.Ctor_InputStream(t, in); t.F_readBuffer = NewByteArray(8); t.F_bytearr = DataInputStream_EMPTY_BYTE_ARRAY; t.F_chararr = DataInputStream_EMPTY_CHAR_ARRAY }







func (t *DataInputStream) Read_B1__I(b *ByteArray) int32 {
	var tmp1 InputStream_I = t.F_in.Load(); return tmp1.Read_B1_I_I__I(b, 0, int32(len(b.A)))
}
func (t *DataInputStream) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	return t.F_in.Load().Read_B1_I_I__I(b, off, len_)
}
func (t *DataInputStream) ReadFully_B1__V(b *ByteArray) {
	t.ReadFully_B1_I_I__V(b, 0, int32(len(b.A)))
}
func (t *DataInputStream) ReadFully_B1_I_I__V(b *ByteArray, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	var n int32 = 0
L1: for { if n < len_ {
	var count int32 = t.F_in.Load().Read_B1_I_I__I(b, off+n, len_-n)
	if count < 0 { panic(Thrown(EOFException_New())) }
	n = n + count
//line :40:1
	continue L1 }; break L1
}
}


func (t *DataInputStream) SkipBytes_I__I(n int32) int32 {
	var total int32 = 0
	var cur int32 = 0
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = total < n; if tmp2 {
	var tmp3 int32; cur = int32(t.F_in.Load().Skip_J__J(int64(n - total))); tmp3 = cur; tmp2 = tmp3 > 0 }
//line :48:1
	tmp1 = tmp2; if tmp1 {


		total = total + cur
//line :48:1
		continue L1 }; break L1 }
//line :46:1
	return total
}






func (t *DataInputStream) ReadBoolean__Z() bool {
	return !(t.ReadUnsignedByte__I() == 0)
}
func (t *DataInputStream) ReadByte__B() int8 {
	return int8(t.ReadUnsignedByte__I())
}
func (t *DataInputStream) ReadUnsignedByte__I() int32 {
	var ch int32 = t.F_in.Load().Read__I(); if ch < 0 { panic(Thrown(EOFException_New())) }; return ch
}
func (t *DataInputStream) ReadShort__S() int16 {
	t.ReadFully_B1_I_I__V(t.F_readBuffer, 0, 2)
	return Jdk_ByteArray_GetShort_B1_I__S(t.F_readBuffer, 0)
}
func (t *DataInputStream) ReadUnsignedShort__I() int32 {
	t.ReadFully_B1_I_I__V(t.F_readBuffer, 0, 2)
	return Jdk_ByteArray_GetUnsignedShort_B1_I__I(t.F_readBuffer, 0)
}
func (t *DataInputStream) ReadChar__C() uint16 {
	t.ReadFully_B1_I_I__V(t.F_readBuffer, 0, 2)
	return Jdk_ByteArray_GetChar_B1_I__C(t.F_readBuffer, 0)
}
func (t *DataInputStream) ReadInt__I() int32 {
	t.ReadFully_B1_I_I__V(t.F_readBuffer, 0, 4)
	return Jdk_ByteArray_GetInt_B1_I__I(t.F_readBuffer, 0)
}
func (t *DataInputStream) ReadLong__J() int64 {
	t.ReadFully_B1_I_I__V(t.F_readBuffer, 0, 8)
	return Jdk_ByteArray_GetLong_B1_I__J(t.F_readBuffer, 0)
}
func (t *DataInputStream) ReadFloat__F() float32 {
	t.ReadFully_B1_I_I__V(t.F_readBuffer, 0, 4)
	return Jdk_ByteArray_GetFloat_B1_I__F(t.F_readBuffer, 0)
}
func (t *DataInputStream) ReadDouble__D() float64 {
	t.ReadFully_B1_I_I__V(t.F_readBuffer, 0, 8)
	return Jdk_ByteArray_GetDouble_B1_I__D(t.F_readBuffer, 0)
}


func (t *DataInputStream) ReadLine__String() *String {
	var buf *CharArray = t.F_lineBuffer
	if buf == nil { var tmp1 *CharArray; var tmp2 *CharArray = NewCharArray(128); t.F_lineBuffer = tmp2; tmp1 = tmp2; buf = tmp1 }
	var room int32 = int32(len(buf.A))
	var offset int32 = 0
	var c int32 = 0
L1: for {
	var tmp4 int32; c = t.F_in.Load().Read__I(); tmp4 = c; switch tmp4 { case -1, 10:
		break L1; case 13:

		var c2 int32 = t.F_in.Load().Read__I(); var tmp5 bool; var tmp6 bool
		tmp6 = !(c2 == 10); if tmp6 { tmp6 = !(c2 == -1) }; tmp5 = tmp6; if tmp5 {
			if A2g_Discard(t.F_in.Load()) { } else {
				t.F_in.Store(A2g_Missing[InputStream_I]("class java.io.PushbackInputStream is not in the closed world")) }
			A2g_Missing[bool]("class java.io.PushbackInputStream is not in the closed world") }
		break L1; default:

		var tmp3 int32; room = room - 1; tmp3 = room; if tmp3 < 0 {
			buf = NewCharArray(offset + 128)
			room = int32(len(buf.A)) - offset - 1
			System_Arraycopy_O_I_O_I_I__V(t.F_lineBuffer.Ref(), 0, buf.Ref(), 0, offset)
			t.F_lineBuffer = buf }
		buf.A[offset] = uint16(c)
		offset = offset + 1}
//line :99:1
	continue L1
}
















	var tmp7 bool; var tmp8 bool; tmp8 = c == -1; if tmp8 { tmp8 = offset == 0 }; tmp7 = tmp8; if tmp7 { return nil } else { return String_CopyValueOf_C1_I_I__String(buf, 0, offset)
	} }
func (t *DataInputStream) ReadUTF__String() *String {
	return DataInputStream_ReadUTF_DataInput__String(t)
}
func DataInputStream_ReadUTF_DataInput__String(in DataInput) *String { DataInputStream_Init()
	var utflen int32 = in.ReadUnsignedShort__I(); var bytearr *ByteArray
	var tmp1 DataInput = in
	if DataInputStream_InstanceOf(tmp1) { var dis *DataInputStream = DataInputStream_Cast(tmp1)
		if int32(len(dis.F_bytearr.A)) >= utflen { bytearr = dis.F_bytearr } } else { }
	var trusted bool = false
	if bytearr == nil { bytearr = NewByteArray(utflen); trusted = true }
	var c int32 = 0
	var char2 int32 = 0
	var char3 int32 = 0
	var count int32 = 0
	var chararr_count int32 = 0
	in.ReadFully_B1_I_I__V(bytearr, 0, utflen)
	var ascii int32 = DataInputStream_JLA.CountPositives_B1_I_I__I(bytearr, 0, utflen)
	if ascii == utflen {
		var str *String; if trusted {
			str = DataInputStream_JLA.UncheckedNewStringWithLatin1Bytes_B1__String(bytearr) } else {
				str = String_New_B1_I_I_Charset(bytearr, 0, utflen, StandardCharsets_ISO_8859_1) }
//line :137:1
		return str
	} else {



		if trusted {
			var tmp2 DataInput = in; if DataInputStream_InstanceOf(tmp2) { var dis_2 *DataInputStream = DataInputStream_Cast(tmp2)
				dis_2.F_bytearr = bytearr
				trusted = false } else { } }
		var chararr *CharArray; var tmp3 DataInput = in
		if DataInputStream_InstanceOf(tmp3) { var dis_3 *DataInputStream = DataInputStream_Cast(tmp3)

			if int32(len(dis_3.F_chararr.A)) < utflen<<1 {
				dis_3.F_chararr = NewCharArray(utflen << 1) }
			chararr = dis_3.F_chararr } else {
				chararr = NewCharArray(utflen) }
		if ascii == 0 { } else {
			DataInputStream_JLA.InflateBytesToChars_B1_I_C1_I_I__V(bytearr, 0, chararr, 0, ascii)
			count = count + ascii
			chararr_count = chararr_count + ascii }
	L1: for { if count < utflen {
		c = int32(bytearr.A[count]) & 255
		switch c >> 4 { case 0, 1, 2, 3, 4, 5, 6, 7:


			count = count + 1
			chararr.A[chararr_count] = uint16(c)
			chararr_count = chararr_count + 1; case 12, 13:


			count = count + 2
			if count > utflen {
				panic(Thrown(A2g_Missing[Throwable_I]("class java.io.UTFDataFormatException is not in the closed world")))
			}
			char2 = int32(bytearr.A[count-1])
			if char2&192 == 128 { } else {
				panic(Thrown(A2g_Missing[Throwable_I]("class java.io.UTFDataFormatException is not in the closed world")))
			}
			chararr.A[chararr_count] = uint16(c&31<<6 | char2&63)




			chararr_count = chararr_count + 1; case 14:


			count = count + 3
			if count > utflen {
				panic(Thrown(A2g_Missing[Throwable_I]("class java.io.UTFDataFormatException is not in the closed world")))
			}
			char2 = int32(bytearr.A[count-2])
			char3 = int32(bytearr.A[count-1])
			var tmp4 bool; var tmp5 bool; tmp5 = !(char2&192 == 128); if !tmp5 {
				tmp5 = !(char3&192 == 128) }
//line :189:1
			tmp4 = tmp5; if tmp4 {

				panic(Thrown(A2g_Missing[Throwable_I]("class java.io.UTFDataFormatException is not in the closed world")))
			}


			chararr.A[chararr_count] = uint16(c&15<<12 | char2&63<<6 | char3&63<<0)






			chararr_count = chararr_count + 1; default:
			panic(Thrown(A2g_Missing[Throwable_I]("class java.io.UTFDataFormatException is not in the closed world")))}
//line :157:1
		continue L1 }; break L1
	}














































		return String_New_C1_I_I(chararr, 0, chararr_count)
	}
}

type DataInputStream struct{ FilterInputStream; F_readBuffer, F_bytearr *ByteArray; F_chararr, F_lineBuffer *CharArray }

func (t *DataInputStream) Is_DataInput() {}

var DataInputStream_JLA JavaLangAccess

var DataInputStream_EMPTY_BYTE_ARRAY *ByteArray

var DataInputStream_EMPTY_CHAR_ARRAY *CharArray

var DataInputStream_init ClassInit

func DataInputStream_Init() { if !DataInputStream_init.Done() { DataInputStream_init.Run(DataInputStream_clinit) } }

func DataInputStream_clinit() { DataInputStream_JLA = SharedSecrets_GetJavaLangAccess__JavaLangAccess(); DataInputStream_EMPTY_BYTE_ARRAY = NewByteArray(0); DataInputStream_EMPTY_CHAR_ARRAY = NewCharArray(0) }

func (t *DataInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *DataInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *DataInputStream) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *DataInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *DataInputStream) Close__V() { t.Impl_Close__V(t) }

func (t *DataInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *DataInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *DataInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *DataInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *DataInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *DataInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *DataInputStream) Available__I() int32 { return t.Impl_Available__I(t) }

func (t *DataInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *DataInputStream) GetClass__Class() *Class { return DataInputStream_class }

func (t *DataInputStream) ToString__String() *String { return Object_toString(t) }

func (t *DataInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DataInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func DataInputStream_InstanceOf(x any) bool { _, ok := x.(*DataInputStream); return ok }

func DataInputStream_Cast(x any) *DataInputStream { if x == nil { return nil }; v, ok := x.(*DataInputStream); if !ok { panic(ClassCast(x, DataInputStream_class)) }; return v }
