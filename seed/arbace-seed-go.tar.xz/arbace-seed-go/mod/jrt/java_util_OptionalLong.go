//line java_util_OptionalLong.ae:1
package jrt














func OptionalLong_New() *OptionalLong { OptionalLong_Init(); t := &OptionalLong{}; t.Ctor(); return t }
//line :16:1
func (t *OptionalLong) Ctor() {
	t.F_isPresent = false
	t.F_value = 0
}
func OptionalLong_Empty__OptionalLong() *OptionalLong { OptionalLong_Init(); return OptionalLong_EMPTY }

func OptionalLong_New_J(p0 int64) *OptionalLong { OptionalLong_Init(); t := &OptionalLong{}; t.Ctor_J(p0); return t }
//line :22:1
func (t *OptionalLong) Ctor_J(value int64) {
	t.F_isPresent = true
	t.F_value = value
}
func OptionalLong_Of_J__OptionalLong(value int64) *OptionalLong {
	return OptionalLong_New_J(value)
}
func (t *OptionalLong) GetAsLong__J() int64 {
	if t.F_isPresent { } else { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :29:1
	return t.F_value
}


func (t *OptionalLong) IsPresent__Z() bool { return t.F_isPresent }

func (t *OptionalLong) IsEmpty__Z() bool { return !t.F_isPresent }

func (t *OptionalLong) IfPresent_LongConsumer__V(action LongConsumer) {
	if t.F_isPresent { action.Accept_J__V(t.F_value)
	} }
func (t *OptionalLong) IfPresentOrElse_LongConsumer_Runnable__V(action LongConsumer, emptyAction Runnable) {
	if t.F_isPresent { action.Accept_J__V(t.F_value) } else { emptyAction.Run__V()
	} }
func (t *OptionalLong) Stream__LongStream() LongStream {
	if t.F_isPresent { return LongStream_Of_J__LongStream(t.F_value) } else { return LongStream_Empty__LongStream()
	} }
func (t *OptionalLong) OrElse_J__J(other int64) int64 {
	if t.F_isPresent { return t.F_value } else { return other
	} }
func (t *OptionalLong) OrElseGet_LongSupplier__J(supplier LongSupplier) int64 {
	if t.F_isPresent { return t.F_value } else { return supplier.GetAsLong__J()
	} }
func (t *OptionalLong) OrElseThrow__J() int64 {
	if t.F_isPresent { } else { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :52:1
	return t.F_value
}


func (t *OptionalLong) OrElseThrow_Supplier__J(exceptionSupplier Supplier) int64 {

	if t.F_isPresent { return t.F_value } else { panic(Thrown(Throwable_Cast(exceptionSupplier.Get__O())))
	} }
func (t *OptionalLong) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if OptionalLong_InstanceOf(tmp1) { var other *OptionalLong = OptionalLong_Cast(tmp1); var tmp2 bool; var tmp3 bool
			tmp3 = t.F_isPresent; if tmp3 { tmp3 = other.F_isPresent }; tmp2 = tmp3; if tmp2 {
				var tmp4 int64 = t.F_value; return tmp4 == other.F_value } else {
					var tmp5 bool = t.F_isPresent; return tmp5 == other.F_isPresent } } else {
//line :63:1
						return false
					}
	}
}


func (t *OptionalLong) HashCode__I() int32 {
	if t.F_isPresent { return Long_HashCode_J__I(t.F_value) } else { return 0
	} }
func (t *OptionalLong) ToString__String() *String {
	if t.F_isPresent { return Concat(Lit_2800, StrOfLong(t.F_value), Lit_1189) } else { return Lit_2801
	}
}

type OptionalLong struct{ Object; F_isPresent bool; F_value int64 }

var OptionalLong_EMPTY *OptionalLong

var OptionalLong_init ClassInit

func OptionalLong_Init() { if !OptionalLong_init.Done() { OptionalLong_init.Run(OptionalLong_clinit) } }

func OptionalLong_clinit() { OptionalLong_EMPTY = OptionalLong_New() }

func (t *OptionalLong) Ref() any { if t == nil { return nil }; return t }

func (t *OptionalLong) GetClass__Class() *Class { return OptionalLong_class }

func (t *OptionalLong) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OptionalLong) CloneShallow() any { panic(CloneNotSupported(t)) }

func OptionalLong_InstanceOf(x any) bool { _, ok := x.(*OptionalLong); return ok }

func OptionalLong_Cast(x any) *OptionalLong { if x == nil { return nil }; v, ok := x.(*OptionalLong); if !ok { panic(ClassCast(x, OptionalLong_class)) }; return v }
