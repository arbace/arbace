//line java_io_DefaultFileSystem.ae:1
package jrt




func DefaultFileSystem_New() *DefaultFileSystem { t := &DefaultFileSystem{}; t.Ctor(); return t }
//line :6:1
func (t *DefaultFileSystem) Ctor() { panic(A2g_NotTranslated("java.io.DefaultFileSystem.<init>()V")) }

func DefaultFileSystem_GetFileSystem__FileSystem() FileSystem_I {
	return UnixFileSystem_New()
}



type DefaultFileSystem struct{ Object }

func (t *DefaultFileSystem) Ref() any { if t == nil { return nil }; return t }

func (t *DefaultFileSystem) GetClass__Class() *Class { return DefaultFileSystem_class }

func (t *DefaultFileSystem) ToString__String() *String { return Object_toString(t) }

func (t *DefaultFileSystem) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DefaultFileSystem) CloneShallow() any { panic(CloneNotSupported(t)) }

func DefaultFileSystem_InstanceOf(x any) bool { _, ok := x.(*DefaultFileSystem); return ok }

func DefaultFileSystem_Cast(x any) *DefaultFileSystem { if x == nil { return nil }; v, ok := x.(*DefaultFileSystem); if !ok { panic(ClassCast(x, DefaultFileSystem_class)) }; return v }
