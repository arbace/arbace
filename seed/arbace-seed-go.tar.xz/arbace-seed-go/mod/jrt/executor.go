//line executor.ae:1
package jrt

import (
	"strconv"
	"sync"
	"time"
)




// ThreadFactory is java.util.concurrent.ThreadFactory.
type ThreadFactory /*line :14:1*/ interface { Object_I
	Is_ThreadFactory()
	NewThread_Runnable__Thread(r Runnable) Thread_I }
// Executor is java.util.concurrent.Executor.
type Executor /*line :19:1*/ interface { Object_I
	Is_Executor()
	Execute_Runnable__V(r Runnable) }
// Future is java.util.concurrent.Future.
type Future /*line :24:1*/ interface { Object_I
	Is_Future()
	Get__O() any
	Get_J_TimeUnit__O(timeout int64, unit *TimeUnit) any
	Cancel_Z__Z(mayInterruptIfRunning bool) bool
	IsCancelled__Z() bool
	IsDone__Z() bool
	ResultNow__O() any
	ExceptionNow__Throwable() Throwable_I
	State__Future_State() *Future_State
}
var ThreadFactory_class =
	Define(&ClassInfo{Name: "java.util.concurrent.ThreadFactory", Kind: KindInterface,
				Modifiers:                                  AccPublic | AccInterface | AccAbstract, Go: "arbace/jrt.ThreadFactory"})
var Executor_class =
	Define(&ClassInfo{Name: "java.util.concurrent.Executor", Kind: KindInterface,
				Modifiers:                             AccPublic | AccInterface | AccAbstract, Go: "arbace/jrt.Executor"})
var Future_class =
	Define(&ClassInfo{Name: "java.util.concurrent.Future", Kind: KindInterface,
				Modifiers:                           AccPublic | AccInterface | AccAbstract, Go: "arbace/jrt.Future",
	})
func ThreadFactory_InstanceOf(x any) bool { _, ok := x.(ThreadFactory); return dynNominal(x, ThreadFactory_class, ok) }
func Executor_InstanceOf(x any) bool { _, ok := x.(Executor); return dynNominal(x, Executor_class, ok) }
func Future_InstanceOf(x any) bool { _, ok := x.(Future); return dynNominal(x, Future_class, ok) }
func Future_Cast(x any) Future {
	if x == nil { return nil }
	v, ok := x.(Future)
	if !dynNominal(x, Future_class, ok) { panic(ClassCast(x, Future_class))
	}; return v }
func Executor_Cast(x any) Executor {
	if x == nil { return nil }
	v, ok := x.(Executor)
	if !dynNominal(x, Executor_class, ok) { panic(ClassCast(x, Executor_class))
	}; return v }
func ThreadFactory_Cast(x any) ThreadFactory {
	if x == nil { return nil }
	v, ok := x.(ThreadFactory)
	if !dynNominal(x, ThreadFactory_class, ok) { panic(ClassCast(x, ThreadFactory_class))
	}
	return v }
// Future_State is the enum java.util.concurrent.Future.State.
type Future_State struct{ Enum }

var Future_State_class =
	Define(&ClassInfo{Name: "java.util.concurrent.Future$State", Kind: KindEnum,
				Modifiers:                                 AccPublic | AccStatic | AccFinal | AccEnum, Super: Enum_class, Declaring: Future_class, Simple: "State", Go: "arbace/jrt.Future_State",
	},
	)
func newFutureState(n string, o int32) *Future_State {
	t := &Future_State{}
	t.Enum.Ctor_String_I(t, Intern(n), o)
	return t
}
var (
	// Future_State_RUNNING is Future.State.RUNNING.
	Future_State_RUNNING   /*line :78:1*/*Future_State = newFutureState("RUNNING", 0)
	Future_State_SUCCESS   *Future_State               = newFutureState("SUCCESS", 1)
	Future_State_FAILED    *Future_State               = newFutureState("FAILED", 2)
	Future_State_CANCELLED *Future_State               = newFutureState("CANCELLED", 3)
)
func Future_State_Values__Future_State1() *RefArray {
	return RefArrayOf(Future_State_class, Future_State_RUNNING, Future_State_SUCCESS, Future_State_FAILED, Future_State_CANCELLED)
}
func Future_State_ValueOf_String__Future_State(n *String) *Future_State {
	return Enum_ValueOf_Class_String__Enum(Future_State_class, n).(*Future_State)
}
func (t *Future_State) Ref() any { if t == nil { return nil }; return t }
func (t *Future_State) GetClass__Class() *Class { return Future_State_class }
func (t *Future_State) Clone__O() any { return t.Impl_Clone__O(t) }
func (t *Future_State) ToString__String() *String { return t.Impl_ToString__String(t) }
func (t *Future_State) CompareTo_Enum__I(o Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, o) }
func (t *Future_State) CompareTo_O__I(o any) int32 { return t.Impl_CompareTo_O__I(t, o) }
func (t *Future_State) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }
func Future_State_Cast(x any) *Future_State {
	if x == nil { return nil }
	v, ok := x.(*Future_State)
	if !ok { panic(ClassCast(x, Future_State_class))
	}; return v }
func Future_State_InstanceOf(x any) bool { _, ok := x.(*Future_State); return ok }
// futureGet is f.get() for Future's defaults: its result, its exception (ExecutionException,
// CancellationException: exc), whether an interrupt was taken (Java's loops retry get then and
// set the status again at the end).
//line :103:1
func futureGet(f Future) (v any, exc Throwable_I, interrupted bool) {




	for {
		exc = runCatching(func() { v = f.Get__O() })
		if exc != nil && InterruptedException_InstanceOf(exc) {
			interrupted = true } else {
				return } } }
// Future_ResultNow__O is Future's default resultNow(): the result of a task done normally, else
// IllegalStateException.
//line :114:1
func Future_ResultNow__O(this Future) any {



	if !this.IsDone__Z() {
		panic(IllegalStateException_New_String(Str("Task has not completed"))) }
	v, exc, interrupted := futureGet(this)
	if interrupted {
		Thread_CurrentThread__Thread().Interrupt__V() }
	if exc == nil {
		return v }
	if ExecutionException_InstanceOf(exc) {
		panic(IllegalStateException_New_String(Str("Task completed with exception"))) }
	if CancellationException_InstanceOf(exc) {
		panic(IllegalStateException_New_String(Str("Task was cancelled"))) }
	panic(exc) }
// Future_ExceptionNow__Throwable is Future's default exceptionNow(): the exception of a task
// that failed, else IllegalStateException.
//line :131:1
func Future_ExceptionNow__Throwable(this Future) Throwable_I {



	if !this.IsDone__Z() {
		panic(IllegalStateException_New_String(Str("Task has not completed"))) }
	if this.IsCancelled__Z() {
		panic(IllegalStateException_New_String(Str("Task was cancelled"))) }
	_, exc, interrupted := futureGet(this)
	if interrupted {
		Thread_CurrentThread__Thread().Interrupt__V() }
	if exc == nil {
		panic(IllegalStateException_New_String(Str("Task completed with a result"))) }
	if ExecutionException_InstanceOf(exc) {
		return exc.GetCause__Throwable() }
	panic(exc) }
// Future_State__Future_State is Future's default state().
func Future_State__Future_State(this Future,

) *Future_State {
	if !this.IsDone__Z() {
		return Future_State_RUNNING }
	if this.IsCancelled__Z() {
		return Future_State_CANCELLED }
	_, exc, interrupted := futureGet(this)
	if interrupted {
		Thread_CurrentThread__Thread().Interrupt__V() }
	if exc == nil {
		return Future_State_SUCCESS }
	if ExecutionException_InstanceOf(exc) {
		return Future_State_FAILED }
	panic(exc)
}







// CountDownLatch is java.util.concurrent.CountDownLatch: the count under mu; done is closed
// when it reaches 0.
type CountDownLatch /*line :176:1*/ struct{ Object; mu sync.Mutex; count int64; done chan struct{} }

var CountDownLatch_class =
	Define(&ClassInfo{Name: "java.util.concurrent.CountDownLatch", Kind: KindClass, Modifiers: AccPublic, Super: Object_class, Go: "arbace/jrt.CountDownLatch"})


func CountDownLatch_New_I(count int32) *CountDownLatch {
	if count < 0 {
		panic(IllegalArgumentException_New_String(Str("count < 0"))) }
	l := &CountDownLatch{count: int64(count), done: make(chan struct{})}
	if count == 0 {
		close(l.done)
	}
	return l }
func (l *CountDownLatch) Await__V() {
	if block(l.done, CurrentThread(), true, time.Time{}) == wokenInterrupted {
		panic(InterruptedException_New())
	} }
func (l *CountDownLatch) Await_J_TimeUnit__Z(timeout int64, unit *TimeUnit) bool {
	me := CurrentThread()
	if interruptedNow(me) {
		panic(InterruptedException_New()) }
	switch block(l.done, me, true, deadlineOf(unitNanos(timeout, unit))) {
	case wokenInterrupted: panic(InterruptedException_New())
	case wokenTimeout:
		select {
		case <-l.done: return true
		default: return false
		}
	}; return true }
func (l *CountDownLatch) CountDown__V() {
	l.mu.Lock()
	if l.count > 0 {
		l.count--
		if l.count == 0 {
			close(l.done) } }
	l.mu.Unlock()
}
func (l *CountDownLatch) GetCount__J() int64 {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.count
}
func (l *CountDownLatch) ToString__String() *String {
	return Concat(Object_toString(l), Str("[Count = "+strconv.FormatInt(l.GetCount__J(), 10)+"]")) }
func (t *CountDownLatch) Ref() any { if t == nil { return nil }; return t }
func (t *CountDownLatch) GetClass__Class() *Class { return CountDownLatch_class }
func (t *CountDownLatch) Clone__O() any { panic(CloneNotSupported(t)) }
func CountDownLatch_InstanceOf(x any) bool { _, ok := x.(*CountDownLatch); return ok }
// Semaphore is java.util.concurrent.Semaphore (leaf), as the locks are: the permits under mu
// (they may be negative, as Java's); a thread that must wait takes the gate, which every release
// opens, and tries again. waiting counts the threads waiting (getQueueLength). Fairness is not
// kept (a fair semaphore behaves as a non-fair one), as for ReentrantLock.
type Semaphore /*line :234:1*/ struct{ Object; mu sync.Mutex; permits, waiting int32; g gate; fair bool }

var Semaphore_class =
	Define(&ClassInfo{Name: "java.util.concurrent.Semaphore", Kind: KindClass, Modifiers: AccPublic, Super: Object_class,

		Interfaces: []*Class{Serializable_class}, Go: "arbace/jrt.Semaphore",
	},
	)
func Semaphore_New_I(permits int32) *Semaphore {
	return &Semaphore{permits: permits} }
func Semaphore_New_I_Z(permits int32, fair bool) *Semaphore {
	return &Semaphore{permits: permits, fair: fair}
}
func semArg(n int32) {
	if n < 0 {
		panic(IllegalArgumentException_New()) } }
// take takes n permits when there are enough (mu held).
func (s /*line :253:1*/*Semaphore) take(n int32) bool {
	if s.permits-n >= 0 {
		s.permits = s.permits - n
		return true }; return false }
// acquire takes n permits for me: false when the deadline passed; InterruptedException when
// interruptible and interrupted (the status consumed). Uninterruptible, an interrupt leaves the
// status set, as Java's.
//line :259:1
func (s /*line :263:1*/*Semaphore) acquire(n int32, me *Thread, interruptible bool, deadline time.Time) bool {
	if interruptible && interruptedNow(me) {
		panic(InterruptedException_New()) }
	s.mu.Lock()
	for {
		if s.take(n) {
			s.mu.Unlock()
			return true }
		ch := (&s.g).wait()
		s.waiting++
		s.mu.Unlock()
		w := block(ch, me, interruptible, deadline)
		s.mu.Lock()
		s.waiting--
		switch w {
		case wokenInterrupted: s.mu.Unlock(); panic(InterruptedException_New())
		case wokenTimeout: s.mu.Unlock(); return false} } }
// Acquire__V is acquire().
func (s *Semaphore) Acquire__V() {
	s.acquire(1, CurrentThread(), true, time.Time{}) }
func (s *Semaphore) Acquire_I__V(n int32) {
	semArg(n)
	s.acquire(n, CurrentThread(), true, time.Time{}) }
func (s *Semaphore) AcquireUninterruptibly__V() {
	s.acquire(1, CurrentThread(), false, time.Time{}) }
func (s *Semaphore) AcquireUninterruptibly_I__V(n int32) {
	semArg(n)
	s.acquire(n, CurrentThread(), false, time.Time{}) }
// TryAcquire_I__Z is tryAcquire(int): the permits when there are enough now.
func (s /*line :293:1*/*Semaphore) TryAcquire_I__Z(n int32) bool {
	semArg(n)
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.take(n) }
func (s *Semaphore) TryAcquire__Z() bool { return s.TryAcquire_I__Z(1) }
// TryAcquire_I_J_TimeUnit__Z is tryAcquire(int, long, TimeUnit): interruptible; a timeout of
// zero or less tries once.
//line :300:1
func (s /*line :303:1*/*Semaphore) TryAcquire_I_J_TimeUnit__Z(n int32, d int64, unit *TimeUnit) bool {
	semArg(n)
	nanos := NN(unit).ToNanos_J__J(d)
	me := CurrentThread()
	if nanos <= 0 {
		if interruptedNow(me) {
			panic(InterruptedException_New()) }
		return s.TryAcquire_I__Z(n) }
	return s.acquire(n, me, true, deadlineOf(nanos)) }
func (s *Semaphore) TryAcquire_J_TimeUnit__Z(d int64, unit *TimeUnit) bool {
	return s.TryAcquire_I_J_TimeUnit__Z(1, d, unit) }
// Release_I__V is release(int): Error "Maximum permit count exceeded" on overflow, as Java's.
func (s /*line :317:1*/*Semaphore) Release_I__V(n int32) {
	semArg(n)
	s.mu.Lock()
	{ next := s.permits + n
		if next < s.permits {
			s.mu.Unlock()
			panic(Error_New_String(Str("Maximum permit count exceeded"))) }
		s.permits = next }
	(&s.g).open()
	s.mu.Unlock() }
func (s *Semaphore) Release__V() { s.Release_I__V(1) }

func (s *Semaphore) AvailablePermits__I() int32 {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.permits }
// DrainPermits__I is drainPermits(): the permits, then none (also when negative, as Java's).
func (s /*line :335:1*/*Semaphore) DrainPermits__I() int32 {
	s.mu.Lock()
	defer s.mu.Unlock()
	n := s.permits
	s.permits = 0
	return n
}
func (s *Semaphore) IsFair__Z() bool { return s.fair }
func (s *Semaphore) HasQueuedThreads__Z() bool { return s.GetQueueLength__I() > 0 }
func (s *Semaphore) GetQueueLength__I() int32 {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.waiting
}
func (s *Semaphore) ToString__String() *String {
	return Concat(Object_toString(s), Str("[Permits = "+strconv.FormatInt(int64(s.AvailablePermits__I()), 10)+"]")) }
func (s *Semaphore) Is_Serializable() {}
func (t *Semaphore) Ref() any { if t == nil { return nil }; return t }
func (t *Semaphore) GetClass__Class() *Class { return Semaphore_class }
func (t *Semaphore) Clone__O() any { panic(CloneNotSupported(t)) }
func Semaphore_InstanceOf(x any) bool { _, ok := x.(*Semaphore); return ok }

func init() {
	ThreadFactory_class.Info().IsInstance = ThreadFactory_InstanceOf
	Executor_class.Info().IsInstance = Executor_InstanceOf
	Future_class.Info().IsInstance = Future_InstanceOf
	Future_State_class.Info().IsInstance = Future_State_InstanceOf
	Future_State_class.Info().Enum = Future_State_Values__Future_State1
	CountDownLatch_class.Info().IsInstance = CountDownLatch_InstanceOf
	Semaphore_class.Info().IsInstance = Semaphore_InstanceOf
}
