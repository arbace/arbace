//line java_security_DigestException.ae:1
package jrt








func DigestException_New() *DigestException { t := &DigestException{}; t.Ctor(); return t }
//line :10:1
func (t *DigestException) Ctor() { t.GeneralSecurityException.Ctor(t) }

func DigestException_New_String(p0 *String) *DigestException { t := &DigestException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *DigestException) Ctor_String(msg *String) { t.GeneralSecurityException.Ctor_String(t, msg) }

func DigestException_New_String_Throwable(p0 *String, p1 Throwable_I) *DigestException { t := &DigestException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *DigestException) Ctor_String_Throwable(message *String, cause Throwable_I) { t.GeneralSecurityException.Ctor_String_Throwable(t, message, cause) }


func DigestException_New_Throwable(p0 Throwable_I) *DigestException { t := &DigestException{}; t.Ctor_Throwable(p0); return t }
//line :17:1
func (t *DigestException) Ctor_Throwable(cause Throwable_I) { t.GeneralSecurityException.Ctor_Throwable(t, cause) }










type DigestException struct{ GeneralSecurityException }

const DigestException_serialVersionUID int64 = 5821450303093652515

func (t *DigestException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *DigestException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *DigestException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *DigestException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *DigestException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *DigestException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *DigestException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *DigestException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *DigestException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *DigestException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *DigestException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *DigestException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DigestException) Ref() any { if t == nil { return nil }; return t }

func (t *DigestException) GetClass__Class() *Class { return DigestException_class }

func (t *DigestException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DigestException) CloneShallow() any { panic(CloneNotSupported(t)) }

func DigestException_InstanceOf(x any) bool { _, ok := x.(*DigestException); return ok }

func DigestException_Cast(x any) *DigestException { if x == nil { return nil }; v, ok := x.(*DigestException); if !ok { panic(ClassCast(x, DigestException_class)) }; return v }
