//line java_text_MergeCollation.ae:1
package jrt






func MergeCollation_New_String(p0 *String) *MergeCollation { t := &MergeCollation{}; t.Ctor_String(p0); return t }
//line :8:1
func (t *MergeCollation) Ctor_String(pattern *String) { t.F_patterns = ArrayList_New(); t.F_saveEntry = nil; t.F_lastEntry = nil; t.F_excess = StringBuilder_New(); t.F_statusArray = NewByteArray(8192)
	t.SetPattern_String__V(pattern)
}
func (t *MergeCollation) GetPattern__String() *String { return t.GetPattern_Z__String(true) }

func (t *MergeCollation) GetPattern_Z__String(withWhiteSpace bool) *String {
	var result *StringBuilder = StringBuilder_New(); var tmp *PatternEntry; var extList *ArrayList
	var i int32 = 0


	i = 0
L1: for { if i < NN(t.F_patterns).Size__I() {
	var entry *PatternEntry = PatternEntry_Cast(NN(t.F_patterns).Get_I__O(i))
	if !NN(entry.F_extension).IsEmpty__Z() {
		if extList == nil { extList = ArrayList_New() }; NN(extList).Add_O__Z(entry.Ref()) } else {

			if !(extList == nil) {
				var last *PatternEntry = t.FindLastWithNoExtension_I__PatternEntry(i - 1); var j int32 = NN(extList).Size__I() - 1
			L2: for {
				if j >= 0 {
					tmp = PatternEntry_Cast(NN(extList).Get_I__O(j))
					NN(tmp).AddToBuilder_StringBuilder_Z_Z_PatternEntry__V(result, false, withWhiteSpace, last)
					j = j - 1; continue L2 }
//line :26:1
				break L2
			}



				extList = nil }
			NN(entry).AddToBuilder_StringBuilder_Z_Z_PatternEntry__V(result, false, withWhiteSpace, nil) }
	i = i + 1
//line :19:1
	continue L1 }; break L1
}













	if !(extList == nil) {
		var last_2 *PatternEntry = t.FindLastWithNoExtension_I__PatternEntry(i - 1); var j_2 int32 = NN(extList).Size__I() - 1
	L3: for {
		if j_2 >= 0 {
			tmp = PatternEntry_Cast(NN(extList).Get_I__O(j_2))
			NN(tmp).AddToBuilder_StringBuilder_Z_Z_PatternEntry__V(result, false, withWhiteSpace, last_2)
			j_2 = j_2 - 1; continue L3 }
//line :36:1
		break L3
	}



		extList = nil }
	return NN(result).ToString__String()
}
func (t *MergeCollation) FindLastWithNoExtension_I__PatternEntry(i int32) *PatternEntry {
	i = i - 1
L1: for { if i >= 0 {
	var entry *PatternEntry = PatternEntry_Cast(NN(t.F_patterns).Get_I__O(i))
	if NN(entry.F_extension).IsEmpty__Z() { return entry }
	i = i - 1
//line :46:1
	continue L1 }; break L1 }
//line :44:1
	return nil
}






func (t *MergeCollation) EmitPattern__String() *String { return t.EmitPattern_Z__String(true) }

func (t *MergeCollation) EmitPattern_Z__String(withWhiteSpace bool) *String {
	var result *StringBuilder = StringBuilder_New(); var i int32 = 0
L1: for {
	if i < NN(t.F_patterns).Size__I() {
		var entry *PatternEntry = PatternEntry_Cast(NN(t.F_patterns).Get_I__O(i))
		if !(entry == nil) {

			NN(entry).AddToBuilder_StringBuilder_Z_Z_PatternEntry__V(result, true, withWhiteSpace, nil)
			i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :56:1
	break L1
}






	return NN(result).ToString__String()
}
func (t *MergeCollation) SetPattern_String__V(pattern *String) {
	NN(t.F_patterns).Clear__V()
	t.AddPattern_String__V(pattern)
}
func (t *MergeCollation) AddPattern_String__V(pattern *String) {
	if !(pattern == nil) {
		var parser *PatternEntry_Parser = PatternEntry_Parser_New_String(pattern); var entry *PatternEntry = NN(parser).Next__PatternEntry()

	L1: for { if !(entry == nil) { t.FixEntry_PatternEntry__V(entry); entry = NN(parser).Next__PatternEntry(); continue L1 }; break L1
	} } }
func (t *MergeCollation) GetCount__I() int32 { return NN(t.F_patterns).Size__I() }

func (t *MergeCollation) GetItemAt_I__PatternEntry(index int32) *PatternEntry {
	return PatternEntry_Cast(NN(t.F_patterns).Get_I__O(index))
}

















func (t *MergeCollation) FixEntry_PatternEntry__V(newEntry *PatternEntry) {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !(t.F_lastEntry == nil); if tmp3 { var tmp4 *String = newEntry.F_chars; tmp3 = NN(tmp4).Equals_O__Z(t.F_lastEntry.F_chars.Ref()) }; tmp2 = tmp3; if tmp2 {
		var tmp5 *String = newEntry.F_extension; tmp2 = NN(tmp5).Equals_O__Z(t.F_lastEntry.F_extension.Ref()) }
//line :99:1
	tmp1 = tmp2; if tmp1 {

		var tmp6 bool; var tmp7 bool; tmp7 = !(newEntry.F_strength == 3); if tmp7 {
			tmp7 = !(newEntry.F_strength == -2) }
//line :101:1
		tmp6 = tmp7; if tmp6 {

			panic(Thrown(ParseException_New_String_I(Concat(Lit_1883, StrOfObj(t.F_lastEntry.Ref()), Lit_1884, StrOfObj(newEntry.Ref()), Lit_1885), -1))) } else {








				return } }
	var changeLastEntry bool = true
	if newEntry.F_strength == -2 { } else {
		var oldIndex int32 = -1
		if NN(newEntry.F_chars).Length__I() == 1 {
			var c uint16 = NN(newEntry.F_chars).CharAt_I__C(0); var statusIndex int32 = int32(c) >> 3; var bitClump int8 = t.F_statusArray.A[statusIndex]; var setBit int8 = int8(1 << (int32(c) & 7 & 31)); var tmp8 bool; var tmp9 bool




			tmp9 = !(int32(bitClump) == 0); if tmp9 { tmp9 = !(int32(bitClump)&int32(setBit) == 0) }; tmp8 = tmp9; if tmp8 {
				oldIndex = NN(t.F_patterns).LastIndexOf_O__I(newEntry.Ref()) } else {
					t.F_statusArray.A[statusIndex] = int8(int32(bitClump) | int32(setBit)) } } else {
						oldIndex = NN(t.F_patterns).LastIndexOf_O__I(newEntry.Ref()) }
		if oldIndex == -1 { } else { NN(t.F_patterns).Remove_I__O(oldIndex) }
		NN(t.F_excess).SetLength_I__V(0)
		var lastIndex int32 = t.FindLastEntry_PatternEntry_StringBuilder__I(t.F_lastEntry, t.F_excess)
		if NN(t.F_excess).Length__I() == 0 { } else {
			var tmp10 *StringBuilder = t.F_excess; newEntry.F_extension = Concat(StrOfObj(tmp10.Ref()), newEntry.F_extension)
			if lastIndex == NN(t.F_patterns).Size__I() { } else {
				t.F_lastEntry = t.F_saveEntry
				changeLastEntry = false } }
		if lastIndex == NN(t.F_patterns).Size__I() {
			NN(t.F_patterns).Add_O__Z(newEntry.Ref()); t.F_saveEntry = newEntry } else {
				NN(t.F_patterns).Add_I_O__V(lastIndex, newEntry.Ref()) } }
	if changeLastEntry { t.F_lastEntry = newEntry
	} }
func (t *MergeCollation) FindLastEntry_PatternEntry_StringBuilder__I(entry *PatternEntry, excessChars *StringBuilder) int32 {

	if entry == nil { return 0 } else { if !(entry.F_strength == -2) {


		var oldIndex int32 = -1
		if NN(entry.F_chars).Length__I() == 1 {
			var index int32 = int32(NN(entry.F_chars).CharAt_I__C(0)) >> 3; var tmp1 int32 = int32(t.F_statusArray.A[index])
			if tmp1&(1<<(int32(NN(entry.F_chars).CharAt_I__C(0))&7&31)) == 0 { } else {




				oldIndex = NN(t.F_patterns).LastIndexOf_O__I(entry.Ref()) } } else {
					oldIndex = NN(t.F_patterns).LastIndexOf_O__I(entry.Ref()) }
		if oldIndex == -1 {
			panic(Thrown(ParseException_New_String_I(Concat(Lit_1886, StrOfObj(entry.Ref())), oldIndex))) }
		return oldIndex + 1 } else {

			var i int32 = 0
			i = NN(t.F_patterns).Size__I() - 1
		L1: for { if i >= 0 {
			var e *PatternEntry = PatternEntry_Cast(NN(t.F_patterns).Get_I__O(i)); var tmp2 *String = e.F_chars; var tmp3 *String = entry.F_chars
			if NN(tmp2).RegionMatches_I_String_I_I__Z(0, tmp3, 0, NN(e.F_chars).Length__I()) {
				var tmp4 CharSequence = Up_String_CharSequence(entry.F_chars); NN(excessChars).Append_CharSequence_I_I__StringBuilder(tmp4, NN(e.F_chars).Length__I(), NN(entry.F_chars).Length__I())



				break L1 }
			i = i - 1
//line :160:1
			continue L1 }; break L1
		}







			if i == -1 { panic(Thrown(ParseException_New_String_I(Concat(Lit_1887, StrOfObj(entry.Ref())), i))) }
			return i + 1
		}
	}
}
type MergeCollation struct{ Object; F_patterns *ArrayList; F_saveEntry, F_lastEntry *PatternEntry; F_excess *StringBuilder; F_statusArray *ByteArray }

const MergeCollation_BITARRAYMASK int8 = 1

const MergeCollation_BYTEPOWER int32 = 3

const MergeCollation_BYTEMASK int32 = 7

func (t *MergeCollation) Ref() any { if t == nil { return nil }; return t }

func (t *MergeCollation) GetClass__Class() *Class { return MergeCollation_class }

func (t *MergeCollation) ToString__String() *String { return Object_toString(t) }

func (t *MergeCollation) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MergeCollation) CloneShallow() any { panic(CloneNotSupported(t)) }

func MergeCollation_InstanceOf(x any) bool { _, ok := x.(*MergeCollation); return ok }

func MergeCollation_Cast(x any) *MergeCollation { if x == nil { return nil }; v, ok := x.(*MergeCollation); if !ok { panic(ClassCast(x, MergeCollation_class)) }; return v }
