//line java_util_MissingFormatArgumentException.ae:1
package jrt










func MissingFormatArgumentException_New_String(p0 *String) *MissingFormatArgumentException { t := &MissingFormatArgumentException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *MissingFormatArgumentException) Ctor_String(s *String) { t.IllegalFormatException.Ctor(t)
	if s == nil { panic(Thrown(NullPointerException_New())) }
	t.F_s = s
}
func (t *MissingFormatArgumentException) GetFormatSpecifier__String() *String { return t.F_s }

func (t *MissingFormatArgumentException) GetMessage__String() *String {
	return Concat(Lit_2789, t.F_s, Lit_1371)
}


type MissingFormatArgumentException struct{ IllegalFormatException; F_s *String }

const MissingFormatArgumentException_serialVersionUID int64 = 19190115

func (t *MissingFormatArgumentException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *MissingFormatArgumentException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *MissingFormatArgumentException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *MissingFormatArgumentException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *MissingFormatArgumentException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *MissingFormatArgumentException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *MissingFormatArgumentException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *MissingFormatArgumentException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *MissingFormatArgumentException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *MissingFormatArgumentException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *MissingFormatArgumentException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MissingFormatArgumentException) Ref() any { if t == nil { return nil }; return t }

func (t *MissingFormatArgumentException) GetClass__Class() *Class { return MissingFormatArgumentException_class }

func (t *MissingFormatArgumentException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MissingFormatArgumentException) CloneShallow() any { panic(CloneNotSupported(t)) }

func MissingFormatArgumentException_InstanceOf(x any) bool { _, ok := x.(*MissingFormatArgumentException); return ok }

func MissingFormatArgumentException_Cast(x any) *MissingFormatArgumentException { if x == nil { return nil }; v, ok := x.(*MissingFormatArgumentException); if !ok { panic(ClassCast(x, MissingFormatArgumentException_class)) }; return v }
