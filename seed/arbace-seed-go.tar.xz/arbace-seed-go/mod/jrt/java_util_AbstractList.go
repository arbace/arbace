//line java_util_AbstractList.ae:1
package jrt










func (t *AbstractList) Ctor(this AbstractList_I) { t.AbstractCollection.Ctor(this); t.F_modCount = 0 }

func (t *AbstractList) Impl_Add_O__Z(this AbstractList_I, e any) bool {
	this.Add_I_O__V(this.Size__I(), e)
//line :14:1
	return true
}




func (t *AbstractList) Impl_Set_I_O__O(this AbstractList_I, index int32, element any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *AbstractList) Impl_Add_I_O__V(this AbstractList_I, index int32, element any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *AbstractList) Impl_Remove_I__O(this AbstractList_I, index int32) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *AbstractList) Impl_IndexOf_O__I(this AbstractList_I, o any) int32 {
	var it ListIterator = this.ListIterator__ListIterator()
	if o == nil {
	L1: for { if it.HasNext__Z() { if it.Next__O() == nil { return it.PreviousIndex__I() }; continue L1 }; break L1 } } else {
	L2: for { if it.HasNext__Z() { if Equals(o, it.Next__O()) { return it.PreviousIndex__I() }; continue L2 }; break L2 } }
//line :30:1
	return -1
}




func (t *AbstractList) Impl_LastIndexOf_O__I(this AbstractList_I, o any) int32 {
	var it ListIterator = this.ListIterator_I__ListIterator(this.Size__I())
	if o == nil {
	L1: for { if it.HasPrevious__Z() { if it.Previous__O() == nil { return it.NextIndex__I() }; continue L1 }; break L1 } } else {
	L2: for { if it.HasPrevious__Z() { if Equals(o, it.Previous__O()) { return it.NextIndex__I() }; continue L2 }; break L2 } }
//line :37:1
	return -1
}




func (t *AbstractList) Impl_Clear__V(this AbstractList_I) { this.RemoveRange_I_I__V(0, this.Size__I()) }

func (t *AbstractList) Impl_AddAll_I_Collection__Z(this AbstractList_I, index int32, c Collection) bool {
	t.Impl_RangeCheckForAdd_I__V(this, index)
	var modified bool = false; var i_101722 Iterator = c.Iterator__Iterator(); for i_101722.HasNext__Z() {
		var e any = i_101722.Next__O()
		this.Add_I_O__V(index, e)
		index = index + 1
		modified = true }
//line :47:1
	return modified
}





func (t *AbstractList) Impl_Iterator__Iterator(this AbstractList_I) Iterator { return AbstractList_Itr_New_AbstractList(this) }

func (t *AbstractList) Impl_ListIterator__ListIterator(this AbstractList_I) ListIterator {
	return this.ListIterator_I__ListIterator(0)
}
func (t *AbstractList) Impl_ListIterator_I__ListIterator(this AbstractList_I, index int32) ListIterator {
	t.Impl_RangeCheckForAdd_I__V(this, index)
	return AbstractList_ListItr_New_AbstractList_I(this, index)
}









func (t *AbstractList_Itr) Impl_HasNext__Z(this AbstractList_Itr_I) bool {
	var tmp1 int32 = t.F_cursor; return !(tmp1 == t.F_this_0.Size__I())
}
func (t *AbstractList_Itr) Impl_Next__O(this AbstractList_Itr_I) any {
	this.CheckForComodification__V()
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var i int32 = t.F_cursor; var next any = t.F_this_0.Get_I__O(i)

			t.F_lastRet = i
			t.F_cursor = i + 1
//line :78:1
			tmp1 = next
		}

		return nil }()
//line :77:1
	if tmp2 != nil { if IndexOutOfBoundsException_InstanceOf(tmp2) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp2)






		this.CheckForComodification__V()
		panic(Thrown(NoSuchElementException_New_Throwable(e))) } else {
//line :77:1
			panic(tmp2) } }; return tmp1
}








func (t *AbstractList_Itr) Impl_Remove__V(this AbstractList_Itr_I) {
	if t.F_lastRet < 0 { panic(Thrown(IllegalStateException_New())) }
	this.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_this_0.Remove_I__O(t.F_lastRet)
		if t.F_lastRet < t.F_cursor { t.F_cursor = t.F_cursor - 1 }
		t.F_lastRet = -1
		t.F_expectedModCount = t.F_this_0.Self_AbstractList().F_modCount; return nil }()
//line :90:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = e




		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :90:1
			panic(tmp1)
		}
	}
}



func (t *AbstractList_Itr) Impl_CheckForComodification__V(this AbstractList_Itr_I) {
	if t.F_this_0.Self_AbstractList().F_modCount == t.F_expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	}
}



func AbstractList_ListItr_New_AbstractList_I(p0 AbstractList_I, p1 int32) *AbstractList_ListItr { t := &AbstractList_ListItr{}; t.Ctor_AbstractList_I(p0, p1); return t }
//line :104:1
func (t *AbstractList_ListItr) Ctor_AbstractList_I(this_0 AbstractList_I, index int32) { A2g_NotNull[AbstractList_I](this_0); t.F_this_0 = this_0; t.AbstractList_Itr.Ctor_AbstractList(t, this_0); t.F_cursor = index }

func (t *AbstractList_ListItr) HasPrevious__Z() bool {
	return !(t.F_cursor == 0)
}
func (t *AbstractList_ListItr) Previous__O() any {
	t.CheckForComodification__V()
	var tmp1 any; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var i int32 = t.F_cursor - 1; var previous any = t.F_this_0.Get_I__O(i); var tmp2 int32
			var tmp3 int32 = i
			t.F_cursor = tmp3; tmp2 = tmp3; t.F_lastRet = tmp2
//line :112:1
			tmp1 = previous
		}
		return nil }()
//line :111:1
	if tmp4 != nil { if IndexOutOfBoundsException_InstanceOf(tmp4) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp4)





		t.CheckForComodification__V()
		panic(Thrown(NoSuchElementException_New_Throwable(e))) } else {
//line :111:1
			panic(tmp4) } }; return tmp1
}







func (t *AbstractList_ListItr) NextIndex__I() int32 { return t.F_cursor }

func (t *AbstractList_ListItr) PreviousIndex__I() int32 {
	return t.F_cursor - 1
}
func (t *AbstractList_ListItr) Set_O__V(e any) {
	if t.F_lastRet < 0 { panic(Thrown(IllegalStateException_New())) }
	t.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_this_0.Set_I_O__O(t.F_lastRet, e)
		t.F_expectedModCount = t.F_this_0.Self_AbstractList().F_modCount; return nil }()
//line :128:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex


		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :128:1
			panic(tmp1)
		}
	}
}

func (t *AbstractList_ListItr) Add_O__V(e any) {
	t.CheckForComodification__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var i int32 = t.F_cursor
			t.F_this_0.Add_I_O__V(i, e)
			t.F_lastRet = -1
			t.F_cursor = i + 1
			t.F_expectedModCount = t.F_this_0.Self_AbstractList().F_modCount }; return nil }()
//line :135:1
	if tmp1 != nil { if IndexOutOfBoundsException_InstanceOf(tmp1) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp1); _ = ex





		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :135:1
			panic(tmp1)
		}
	}
}




func (t *AbstractList) Impl_SubList_I_I__List(this AbstractList_I, fromIndex, toIndex int32) List {
	AbstractList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, this.Size__I())
	if RandomAccess_InstanceOf(this) {
		return AbstractList_RandomAccessSubList_New_AbstractList_I_I(this, fromIndex, toIndex) } else {
			return AbstractList_SubList_New_AbstractList_I_I(this, fromIndex, toIndex)
		} }
func AbstractList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, size int32) {
	if fromIndex < 0 { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2591, StrOfInt(fromIndex))))) }
	if toIndex > size { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2592, StrOfInt(toIndex))))) }
	if fromIndex > toIndex {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2593, StrOfInt(fromIndex), Lit_2594, StrOfInt(toIndex), Lit_1176))))
	}
}
func (t *AbstractList) Impl_Equals_O__Z(this AbstractList_I, o any) bool {
	if any(o) == any(this) { return true } else { if !List_InstanceOf(o) { return false } else {



		var e1 ListIterator = this.ListIterator__ListIterator(); var e2 ListIterator = List_Cast(o).ListIterator__ListIterator()

	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = e1.HasNext__Z(); if tmp2 { tmp2 = e2.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		var o1 any = e1.Next__O(); var o2 any = e2.Next__O(); var tmp3 bool

		if o1 == nil { tmp3 = o2 == nil } else { tmp3 = Equals(o1, o2) }; if tmp3 { } else { return false }
//line :163:1
		continue L1 }; break L1
	}


		var tmp4 bool; var tmp5 bool; tmp5 = e1.HasNext__Z(); if !tmp5 { tmp5 = e2.HasNext__Z() }; tmp4 = tmp5; return !tmp4
	} } }
func (t *AbstractList) Impl_HashCode__I(this AbstractList_I) int32 {
	var hashCode int32 = 1; var i_101723 Iterator = this.Iterator__Iterator(); for i_101723.HasNext__Z() {
		var e any = i_101723.Next__O(); var tmp1 int32 = 31 * hashCode; var tmp2 int32


		if e == nil { tmp2 = 0 } else { tmp2 = HashCode(e) }
//line :172:1
		hashCode = tmp1 + tmp2 }
//line :170:1
	return hashCode
}





func (t *AbstractList) Impl_RemoveRange_I_I__V(this AbstractList_I, fromIndex, toIndex int32) {
	var it ListIterator = this.ListIterator_I__ListIterator(fromIndex); var i int32 = 0; var n int32 = toIndex - fromIndex
L1: for {

	if i < n { it.Next__O(); it.Remove__V(); i, n = i+1, n; continue L1 }
//line :179:1
	break L1
}
}



func (t *AbstractList) Impl_RangeCheckForAdd_I__V(this AbstractList_I, index int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = index < 0; if !tmp2 { tmp2 = index > this.Size__I() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IndexOutOfBoundsException_New_String(t.Impl_OutOfBoundsMsg_I__String(this, index))))
	} }
func (t *AbstractList) Impl_OutOfBoundsMsg_I__String(this AbstractList_I, index int32) *String {
	return Concat(Lit_2595, StrOfInt(index), Lit_2596, StrOfInt(this.Size__I()))
}














func AbstractList_RandomAccessSpliterator_New_List(p0 List) *AbstractList_RandomAccessSpliterator { AbstractList_RandomAccessSpliterator_Init(); t := &AbstractList_RandomAccessSpliterator{}; t.Ctor_List(p0); return t }
//line :206:1
func (t *AbstractList_RandomAccessSpliterator) Ctor_List(list List) {
	if !A2g_AssertionsDisabled && !RandomAccess_InstanceOf(list) { panic(Thrown(AssertionError_New())) }
	t.F_list = list
	t.F_index = 0
	t.F_fence = -1
	var tmp1 AbstractList_I; if AbstractList_InstanceOf(list) { tmp1 = AbstractList_Cast(list) } else { tmp1 = nil }; t.F_alist = tmp1
	var tmp2 int32; if !(t.F_alist == nil) { tmp2 = t.F_alist.Self_AbstractList().F_modCount } else { tmp2 = 0 }; t.F_expectedModCount = tmp2
}
func AbstractList_RandomAccessSpliterator_New_AbstractList_RandomAccessSpliterator_I_I(p0 *AbstractList_RandomAccessSpliterator, p1, p2 int32) *AbstractList_RandomAccessSpliterator { AbstractList_RandomAccessSpliterator_Init(); t := &AbstractList_RandomAccessSpliterator{}; t.Ctor_AbstractList_RandomAccessSpliterator_I_I(p0, p1, p2); return t }
//line :214:1
func (t *AbstractList_RandomAccessSpliterator) Ctor_AbstractList_RandomAccessSpliterator_I_I(parent *AbstractList_RandomAccessSpliterator, origin, fence int32) {
	t.F_list = parent.F_list
	t.F_index = origin
	t.F_fence = fence
	t.F_alist = parent.F_alist
	t.F_expectedModCount = parent.F_expectedModCount
}
func (t *AbstractList_RandomAccessSpliterator) GetFence__I() int32 {
	var hi int32 = 0; var lst List = t.F_list; var tmp1 int32

	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {
		if !(t.F_alist == nil) { t.F_expectedModCount = t.F_alist.Self_AbstractList().F_modCount }
		var tmp2 int32; var tmp3 int32 = lst.Size__I(); t.F_fence = tmp3; tmp2 = tmp3; hi = tmp2 }
//line :222:1
	return hi
}





func (t *AbstractList_RandomAccessSpliterator) TrySplit__Spliterator() Spliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi) >> 1)


	if lo >= mid { return nil } else { var tmp1 int32; var tmp2 int32 = mid; t.F_index = tmp2; tmp1 = tmp2; return AbstractList_RandomAccessSpliterator_New_AbstractList_RandomAccessSpliterator_I_I(t, lo, tmp1)
	} }
func (t *AbstractList_RandomAccessSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var hi int32 = t.GetFence__I(); var i int32 = t.F_index

	if i < hi {

		t.F_index = i + 1
		action.Accept_O__V(AbstractList_RandomAccessSpliterator_Get_List_I__O(t.F_list, i))
		AbstractList_RandomAccessSpliterator_CheckAbstractListModCount_AbstractList_I__V(t.F_alist, t.F_expectedModCount)
//line :240:1
		return true

	} else {
//line :239:1
		return false
	}
}





func (t *AbstractList_RandomAccessSpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var lst List = t.F_list; var hi int32 = t.GetFence__I(); var i int32 = t.F_index


	t.F_index = hi
L1: for { if i < hi {
	action.Accept_O__V(AbstractList_RandomAccessSpliterator_Get_List_I__O(lst, i))
	i = i + 1
//line :253:1
	continue L1 }; break L1
}

	AbstractList_RandomAccessSpliterator_CheckAbstractListModCount_AbstractList_I__V(t.F_alist, t.F_expectedModCount)
}
func (t *AbstractList_RandomAccessSpliterator) EstimateSize__J() int64 {
	return int64(t.GetFence__I() - t.F_index)
}
func (t *AbstractList_RandomAccessSpliterator) Characteristics__I() int32 {
	return 16464
}
func AbstractList_RandomAccessSpliterator_Get_List_I__O(list List, i int32) any { AbstractList_RandomAccessSpliterator_Init()
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = list.Get_I__O(i); return nil }()
//line :265:1
	if tmp2 != nil { if IndexOutOfBoundsException_InstanceOf(tmp2) { var ex IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp2); _ = ex

		panic(Thrown(ConcurrentModificationException_New())) } else {
//line :265:1
			panic(tmp2) } }; return tmp1
}


func AbstractList_RandomAccessSpliterator_CheckAbstractListModCount_AbstractList_I__V(alist AbstractList_I, expectedModCount int32) { AbstractList_RandomAccessSpliterator_Init()

	var tmp1 bool; var tmp2 bool; tmp2 = !(alist == nil); if tmp2 { tmp2 = !(alist.Self_AbstractList().F_modCount == expectedModCount) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(ConcurrentModificationException_New()))
	}
}











func AbstractList_SubList_New_AbstractList_I_I(p0 AbstractList_I, p1, p2 int32) *AbstractList_SubList { t := &AbstractList_SubList{}; t.Ctor_AbstractList_I_I(t, p0, p1, p2); return t }
//line :286:1
func (t *AbstractList_SubList) Ctor_AbstractList_I_I(this AbstractList_SubList_I, root AbstractList_I, fromIndex, toIndex int32) { t.AbstractList.Ctor(this)
	t.F_root = root
	t.F_parent = nil
	t.F_offset = fromIndex
	t.F_size = toIndex - fromIndex
	t.F_modCount = root.Self_AbstractList().F_modCount
}
func AbstractList_SubList_New_AbstractList_SubList_I_I(p0 AbstractList_SubList_I, p1, p2 int32) *AbstractList_SubList { t := &AbstractList_SubList{}; t.Ctor_AbstractList_SubList_I_I(t, p0, p1, p2); return t }
//line :293:1
func (t *AbstractList_SubList) Ctor_AbstractList_SubList_I_I(this, parent AbstractList_SubList_I, fromIndex, toIndex int32) { t.AbstractList.Ctor(this)
	t.F_root = parent.Self_AbstractList_SubList().F_root
	t.F_parent = parent
	t.F_offset = parent.Self_AbstractList_SubList().F_offset + fromIndex
	t.F_size = toIndex - fromIndex
	t.F_modCount = t.F_root.Self_AbstractList().F_modCount
}
func (t *AbstractList_SubList) Impl_Set_I_O__O(this AbstractList_SubList_I, index int32, element any) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	t.Impl_CheckForComodification__V(this)
	return t.F_root.Set_I_O__O(t.F_offset+index, element)
}
func (t *AbstractList_SubList) Impl_Get_I__O(this AbstractList_SubList_I, index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	t.Impl_CheckForComodification__V(this)
	return t.F_root.Get_I__O(t.F_offset + index)
}
func (t *AbstractList_SubList) Impl_Size__I(this AbstractList_SubList_I) int32 { t.Impl_CheckForComodification__V(this); return t.F_size }

func (t *AbstractList_SubList) Impl_Add_I_O__V(this AbstractList_SubList_I, index int32, element any) {
	t.Impl_RangeCheckForAdd_I__V(this, index)
	t.Impl_CheckForComodification__V(this)
	t.F_root.Add_I_O__V(t.F_offset+index, element)
	t.Impl_UpdateSizeAndModCount_I__V(this, 1)
}
func (t *AbstractList_SubList) Impl_Remove_I__O(this AbstractList_SubList_I, index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	t.Impl_CheckForComodification__V(this)
	var result any = t.F_root.Remove_I__O(t.F_offset + index)
	t.Impl_UpdateSizeAndModCount_I__V(this, -1)
//line :321:1
	return result
}


func (t *AbstractList_SubList) Impl_RemoveRange_I_I__V(this AbstractList_SubList_I, fromIndex, toIndex int32) {
	t.Impl_CheckForComodification__V(this)
	t.F_root.RemoveRange_I_I__V(t.F_offset+fromIndex, t.F_offset+toIndex)
	t.Impl_UpdateSizeAndModCount_I__V(this, fromIndex-toIndex)
}
func (t *AbstractList_SubList) Impl_AddAll_Collection__Z(this AbstractList_SubList_I, c Collection) bool {
	return this.AddAll_I_Collection__Z(t.F_size, c)
}
func (t *AbstractList_SubList) Impl_AddAll_I_Collection__Z(this AbstractList_SubList_I, index int32, c Collection) bool {
	t.Impl_RangeCheckForAdd_I__V(this, index)
	var cSize int32 = c.Size__I()
	if cSize == 0 { return false } else {


		t.Impl_CheckForComodification__V(this)
		t.F_root.AddAll_I_Collection__Z(t.F_offset+index, c)
		t.Impl_UpdateSizeAndModCount_I__V(this, cSize)
//line :338:1
		return true
	}
}



func (t *AbstractList_SubList) Impl_Iterator__Iterator(this AbstractList_SubList_I) Iterator {
	return this.ListIterator__ListIterator()
}
func (t *AbstractList_SubList) Impl_ListIterator_I__ListIterator(this AbstractList_SubList_I, index int32) ListIterator {
	t.Impl_CheckForComodification__V(this)
	t.Impl_RangeCheckForAdd_I__V(this, index)
	return AbstractList_SubList_1_New_AbstractList_SubList_I(this, index)
}


func (t *AbstractList_SubList_1) HasNext__Z() bool { return t.NextIndex__I() < t.F_this_0.Self_AbstractList_SubList().F_size }

func (t *AbstractList_SubList_1) Next__O() any {
	if t.HasNext__Z() { return t.F_i.Next__O() } else { panic(Thrown(NoSuchElementException_New()))
	} }
func (t *AbstractList_SubList_1) HasPrevious__Z() bool {
	return t.PreviousIndex__I() >= 0
}
func (t *AbstractList_SubList_1) Previous__O() any {
	if t.HasPrevious__Z() { return t.F_i.Previous__O() } else { panic(Thrown(NoSuchElementException_New()))
	} }
func (t *AbstractList_SubList_1) NextIndex__I() int32 {
	return t.F_i.NextIndex__I() - t.F_this_0.Self_AbstractList_SubList().F_offset
}
func (t *AbstractList_SubList_1) PreviousIndex__I() int32 {
	return t.F_i.PreviousIndex__I() - t.F_this_0.Self_AbstractList_SubList().F_offset
}
func (t *AbstractList_SubList_1) Remove__V() {
	t.F_i.Remove__V()
	t.F_this_0.Self_AbstractList_SubList().Impl_UpdateSizeAndModCount_I__V(t.F_this_0, -1)
}
func (t *AbstractList_SubList_1) Set_O__V(e any) { t.F_i.Set_O__V(e) }

func (t *AbstractList_SubList_1) Add_O__V(e any) {
	t.F_i.Add_O__V(e)
	t.F_this_0.Self_AbstractList_SubList().Impl_UpdateSizeAndModCount_I__V(t.F_this_0, 1)
}
func (t *AbstractList_SubList) Impl_SubList_I_I__List(this AbstractList_SubList_I, fromIndex, toIndex int32) List {
	AbstractList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, t.F_size)
	return AbstractList_SubList_New_AbstractList_SubList_I_I(this, fromIndex, toIndex)
}
func (t *AbstractList_SubList) Impl_RangeCheckForAdd_I__V(this AbstractList_SubList_I, index int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = index < 0; if !tmp2 { tmp2 = index > t.F_size }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IndexOutOfBoundsException_New_String(t.Impl_OutOfBoundsMsg_I__String(this, index))))
	} }
func (t *AbstractList_SubList) Impl_OutOfBoundsMsg_I__String(this AbstractList_SubList_I, index int32) *String {
	return Concat(Lit_2595, StrOfInt(index), Lit_2596, StrOfInt(t.F_size))
}
func (t *AbstractList_SubList) Impl_CheckForComodification__V(this AbstractList_SubList_I) {
	if t.F_root.Self_AbstractList().F_modCount == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *AbstractList_SubList) Impl_UpdateSizeAndModCount_I__V(this AbstractList_SubList_I, sizeChange int32) {
	var slist AbstractList_SubList_I = this
L1: for {
	slist.Self_AbstractList_SubList().F_size = slist.Self_AbstractList_SubList().F_size + sizeChange
	slist.Self_AbstractList().F_modCount = t.F_root.Self_AbstractList().F_modCount
	slist = slist.Self_AbstractList_SubList().F_parent
	if !(slist == nil) { continue L1 }
//line :397:1
	break L1
}
}








func AbstractList_RandomAccessSubList_New_AbstractList_I_I(p0 AbstractList_I, p1, p2 int32) *AbstractList_RandomAccessSubList { t := &AbstractList_RandomAccessSubList{}; t.Ctor_AbstractList_I_I(p0, p1, p2); return t }
//line :408:1
func (t *AbstractList_RandomAccessSubList) Ctor_AbstractList_I_I(root AbstractList_I, fromIndex, toIndex int32) { t.AbstractList_SubList.Ctor_AbstractList_I_I(t, root, fromIndex, toIndex) }


func AbstractList_RandomAccessSubList_New_AbstractList_RandomAccessSubList_I_I(p0 *AbstractList_RandomAccessSubList, p1, p2 int32) *AbstractList_RandomAccessSubList { t := &AbstractList_RandomAccessSubList{}; t.Ctor_AbstractList_RandomAccessSubList_I_I(p0, p1, p2); return t }
//line :411:1
func (t *AbstractList_RandomAccessSubList) Ctor_AbstractList_RandomAccessSubList_I_I(parent *AbstractList_RandomAccessSubList, fromIndex, toIndex int32) { t.AbstractList_SubList.Ctor_AbstractList_SubList_I_I(t, Up_AbstractList_RandomAccessSubList_AbstractList_SubList(parent), fromIndex, toIndex) }


func (t *AbstractList_RandomAccessSubList) SubList_I_I__List(fromIndex, toIndex int32) List {
	AbstractList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, t.F_size)
	return AbstractList_RandomAccessSubList_New_AbstractList_RandomAccessSubList_I_I(t, fromIndex, toIndex)
}


type AbstractList struct{ AbstractCollection; F_modCount int32 }

type AbstractList_I interface{ AbstractCollection_I; List; Collection; SequencedCollection; Iterable; Self_AbstractList() *AbstractList; Add_O__Z(p0 any) bool; Get_I__O(p0 int32) any; Set_I_O__O(p0 int32, p1 any) any; Add_I_O__V(p0 int32, p1 any); Remove_I__O(p0 int32) any; IndexOf_O__I(p0 any) int32; LastIndexOf_O__I(p0 any) int32; Clear__V(); AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; Iterator__Iterator() Iterator; ListIterator__ListIterator() ListIterator; ListIterator_I__ListIterator(p0 int32) ListIterator; SubList_I_I__List(p0, p1 int32) List; RemoveRange_I_I__V(p0, p1 int32) }

func (t *AbstractList) Self_AbstractList() *AbstractList { return t }

func (t *AbstractList) Is_List() {}

func (t *AbstractList) Is_SequencedCollection() {}

func AbstractList_InstanceOf(x any) bool { _, ok := x.(AbstractList_I); return ok }

func AbstractList_Cast(x any) AbstractList_I { if x == nil { return nil }; v, ok := x.(AbstractList_I); if !ok { panic(ClassCast(x, AbstractList_class)) }; return v }



type AbstractList_Itr struct{ Object; F_cursor, F_lastRet, F_expectedModCount int32; F_this_0 AbstractList_I }

type AbstractList_Itr_I interface{ Object_I; Iterator; Self_AbstractList_Itr() *AbstractList_Itr; HasNext__Z() bool; Next__O() any; Remove__V(); CheckForComodification__V() }

func (t *AbstractList_Itr) Self_AbstractList_Itr() *AbstractList_Itr { return t }

func (t *AbstractList_Itr) Is_Iterator() {}

func AbstractList_Itr_New_AbstractList(p0 AbstractList_I) *AbstractList_Itr { t := &AbstractList_Itr{}; t.Ctor_AbstractList(t, p0); return t }

func (t *AbstractList_Itr) Ctor_AbstractList(this AbstractList_Itr_I, this_0 AbstractList_I) { A2g_NotNull[AbstractList_I](this_0); t.F_this_0 = this_0; t.F_cursor = 0; t.F_lastRet = -1; t.F_expectedModCount = this_0.Self_AbstractList().F_modCount }

func (t *AbstractList_Itr) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *AbstractList_Itr) Next__O() any { return t.Impl_Next__O(t) }

func (t *AbstractList_Itr) Remove__V() { t.Impl_Remove__V(t) }

func (t *AbstractList_Itr) CheckForComodification__V() { t.Impl_CheckForComodification__V(t) }

func (t *AbstractList_Itr) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *AbstractList_Itr) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractList_Itr) GetClass__Class() *Class { return AbstractList_Itr_class }

func (t *AbstractList_Itr) ToString__String() *String { return Object_toString(t) }

func (t *AbstractList_Itr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractList_Itr) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractList_Itr_InstanceOf(x any) bool { _, ok := x.(AbstractList_Itr_I); return ok }

func AbstractList_Itr_Cast(x any) AbstractList_Itr_I { if x == nil { return nil }; v, ok := x.(AbstractList_Itr_I); if !ok { panic(ClassCast(x, AbstractList_Itr_class)) }; return v }



type AbstractList_ListItr struct{ AbstractList_Itr; F_this_0 AbstractList_I }

func (t *AbstractList_ListItr) Is_ListIterator() {}

func (t *AbstractList_ListItr) Next__O() any { return t.Impl_Next__O(t) }

func (t *AbstractList_ListItr) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *AbstractList_ListItr) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *AbstractList_ListItr) CheckForComodification__V() { t.Impl_CheckForComodification__V(t) }

func (t *AbstractList_ListItr) Remove__V() { t.Impl_Remove__V(t) }

func (t *AbstractList_ListItr) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractList_ListItr) GetClass__Class() *Class { return AbstractList_ListItr_class }

func (t *AbstractList_ListItr) ToString__String() *String { return Object_toString(t) }

func (t *AbstractList_ListItr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractList_ListItr) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractList_ListItr_InstanceOf(x any) bool { _, ok := x.(*AbstractList_ListItr); return ok }

func AbstractList_ListItr_Cast(x any) *AbstractList_ListItr { if x == nil { return nil }; v, ok := x.(*AbstractList_ListItr); if !ok { panic(ClassCast(x, AbstractList_ListItr_class)) }; return v }



type AbstractList_RandomAccessSpliterator struct{ Object; F_list List; F_index, F_fence int32; F_alist AbstractList_I; F_expectedModCount int32 }

func (t *AbstractList_RandomAccessSpliterator) Is_Spliterator() {}

var AbstractList_RandomAccessSpliterator_init ClassInit

func AbstractList_RandomAccessSpliterator_Init() { if !AbstractList_RandomAccessSpliterator_init.Done() { AbstractList_RandomAccessSpliterator_init.Run(AbstractList_RandomAccessSpliterator_clinit) } }

func AbstractList_RandomAccessSpliterator_clinit() {}

func (t *AbstractList_RandomAccessSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *AbstractList_RandomAccessSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *AbstractList_RandomAccessSpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *AbstractList_RandomAccessSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractList_RandomAccessSpliterator) GetClass__Class() *Class { return AbstractList_RandomAccessSpliterator_class }

func (t *AbstractList_RandomAccessSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *AbstractList_RandomAccessSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractList_RandomAccessSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractList_RandomAccessSpliterator_InstanceOf(x any) bool { _, ok := x.(*AbstractList_RandomAccessSpliterator); return ok }

func AbstractList_RandomAccessSpliterator_Cast(x any) *AbstractList_RandomAccessSpliterator { if x == nil { return nil }; v, ok := x.(*AbstractList_RandomAccessSpliterator); if !ok { panic(ClassCast(x, AbstractList_RandomAccessSpliterator_class)) }; return v }



type AbstractList_RandomAccessSubList struct{ AbstractList_SubList }

func (t *AbstractList_RandomAccessSubList) Is_RandomAccess() {}

func (t *AbstractList_RandomAccessSubList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *AbstractList_RandomAccessSubList) Spliterator__Spliterator() Spliterator { return List_Spliterator__Spliterator(t) }

func (t *AbstractList_RandomAccessSubList) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *AbstractList_RandomAccessSubList) Clear__V() { t.Impl_Clear__V(t) }

func (t *AbstractList_RandomAccessSubList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *AbstractList_RandomAccessSubList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *AbstractList_RandomAccessSubList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *AbstractList_RandomAccessSubList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *AbstractList_RandomAccessSubList) Sort_Comparator__V(p0 Comparator) { List_Sort_Comparator__V(t, p0) }

func (t *AbstractList_RandomAccessSubList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *AbstractList_RandomAccessSubList) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *AbstractList_RandomAccessSubList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *AbstractList_RandomAccessSubList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *AbstractList_RandomAccessSubList) Reversed__List() List { return List_Reversed__List(t) }

func (t *AbstractList_RandomAccessSubList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { List_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *AbstractList_RandomAccessSubList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *AbstractList_RandomAccessSubList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *AbstractList_RandomAccessSubList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *AbstractList_RandomAccessSubList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *AbstractList_RandomAccessSubList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *AbstractList_RandomAccessSubList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *AbstractList_RandomAccessSubList) GetLast__O() any { return List_GetLast__O(t) }

func (t *AbstractList_RandomAccessSubList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *AbstractList_RandomAccessSubList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *AbstractList_RandomAccessSubList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *AbstractList_RandomAccessSubList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *AbstractList_RandomAccessSubList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *AbstractList_RandomAccessSubList) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *AbstractList_RandomAccessSubList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *AbstractList_RandomAccessSubList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *AbstractList_RandomAccessSubList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *AbstractList_RandomAccessSubList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *AbstractList_RandomAccessSubList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *AbstractList_RandomAccessSubList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AbstractList_RandomAccessSubList) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractList_RandomAccessSubList) GetClass__Class() *Class { return AbstractList_RandomAccessSubList_class }

func (t *AbstractList_RandomAccessSubList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractList_RandomAccessSubList) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractList_RandomAccessSubList_InstanceOf(x any) bool { _, ok := x.(*AbstractList_RandomAccessSubList); return ok }

func AbstractList_RandomAccessSubList_Cast(x any) *AbstractList_RandomAccessSubList { if x == nil { return nil }; v, ok := x.(*AbstractList_RandomAccessSubList); if !ok { panic(ClassCast(x, AbstractList_RandomAccessSubList_class)) }; return v }



type AbstractList_SubList struct{ AbstractList; F_root AbstractList_I; F_parent AbstractList_SubList_I; F_offset, F_size int32 }

type AbstractList_SubList_I interface{ AbstractList_I; List; Collection; SequencedCollection; Iterable; Self_AbstractList_SubList() *AbstractList_SubList; Set_I_O__O(p0 int32, p1 any) any; Get_I__O(p0 int32) any; Size__I() int32; Add_I_O__V(p0 int32, p1 any); Remove_I__O(p0 int32) any; RemoveRange_I_I__V(p0, p1 int32); AddAll_Collection__Z(p0 Collection) bool; AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; Iterator__Iterator() Iterator; ListIterator_I__ListIterator(p0 int32) ListIterator; SubList_I_I__List(p0, p1 int32) List }

func (t *AbstractList_SubList) Self_AbstractList_SubList() *AbstractList_SubList { return t }

func (t *AbstractList_SubList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *AbstractList_SubList) Spliterator__Spliterator() Spliterator { return List_Spliterator__Spliterator(t) }

func (t *AbstractList_SubList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *AbstractList_SubList) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *AbstractList_SubList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *AbstractList_SubList) Clear__V() { t.Impl_Clear__V(t) }

func (t *AbstractList_SubList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *AbstractList_SubList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *AbstractList_SubList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *AbstractList_SubList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *AbstractList_SubList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *AbstractList_SubList) Sort_Comparator__V(p0 Comparator) { List_Sort_Comparator__V(t, p0) }

func (t *AbstractList_SubList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *AbstractList_SubList) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *AbstractList_SubList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *AbstractList_SubList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *AbstractList_SubList) Reversed__List() List { return List_Reversed__List(t) }

func (t *AbstractList_SubList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { List_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *AbstractList_SubList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *AbstractList_SubList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *AbstractList_SubList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *AbstractList_SubList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *AbstractList_SubList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *AbstractList_SubList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *AbstractList_SubList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *AbstractList_SubList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *AbstractList_SubList) GetLast__O() any { return List_GetLast__O(t) }

func (t *AbstractList_SubList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *AbstractList_SubList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *AbstractList_SubList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *AbstractList_SubList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *AbstractList_SubList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *AbstractList_SubList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *AbstractList_SubList) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *AbstractList_SubList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *AbstractList_SubList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *AbstractList_SubList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *AbstractList_SubList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *AbstractList_SubList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *AbstractList_SubList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *AbstractList_SubList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *AbstractList_SubList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *AbstractList_SubList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AbstractList_SubList) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractList_SubList) GetClass__Class() *Class { return AbstractList_SubList_class }

func (t *AbstractList_SubList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractList_SubList) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractList_SubList_InstanceOf(x any) bool { _, ok := x.(AbstractList_SubList_I); return ok }

func AbstractList_SubList_Cast(x any) AbstractList_SubList_I { if x == nil { return nil }; v, ok := x.(AbstractList_SubList_I); if !ok { panic(ClassCast(x, AbstractList_SubList_class)) }; return v }



type AbstractList_SubList_1 struct{ Object; F_i ListIterator; F_this_0 AbstractList_SubList_I; F_val_index int32 }

func (t *AbstractList_SubList_1) Is_ListIterator() {}

func (t *AbstractList_SubList_1) Is_Iterator() {}

func AbstractList_SubList_1_New_AbstractList_SubList_I(p0 AbstractList_SubList_I, p1 int32) *AbstractList_SubList_1 { t := &AbstractList_SubList_1{}; t.Ctor_AbstractList_SubList_I(p0, p1); return t }

func (t *AbstractList_SubList_1) Ctor_AbstractList_SubList_I(this_0 AbstractList_SubList_I, val_index int32) { t.F_val_index = val_index; A2g_NotNull[AbstractList_SubList_I](this_0); t.F_this_0 = this_0; t.F_i = this_0.Self_AbstractList_SubList().F_root.ListIterator_I__ListIterator(this_0.Self_AbstractList_SubList().F_offset + t.F_val_index) }

func (t *AbstractList_SubList_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *AbstractList_SubList_1) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractList_SubList_1) GetClass__Class() *Class { return AbstractList_SubList_1_class }

func (t *AbstractList_SubList_1) ToString__String() *String { return Object_toString(t) }

func (t *AbstractList_SubList_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractList_SubList_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractList_SubList_1_InstanceOf(x any) bool { _, ok := x.(*AbstractList_SubList_1); return ok }

func AbstractList_SubList_1_Cast(x any) *AbstractList_SubList_1 { if x == nil { return nil }; v, ok := x.(*AbstractList_SubList_1); if !ok { panic(ClassCast(x, AbstractList_SubList_1_class)) }; return v }
