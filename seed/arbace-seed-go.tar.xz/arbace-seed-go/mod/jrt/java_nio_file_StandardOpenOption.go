//line java_nio_file_StandardOpenOption.ae:1
package jrt






type StandardOpenOption struct{ Enum }

func (t *StandardOpenOption) Is_OpenOption() {}

func (t *StandardOpenOption) Is_Constable() {}

var StandardOpenOption_READ *StandardOpenOption

var StandardOpenOption_WRITE *StandardOpenOption

var StandardOpenOption_APPEND *StandardOpenOption

var StandardOpenOption_TRUNCATE_EXISTING *StandardOpenOption

var StandardOpenOption_CREATE *StandardOpenOption

var StandardOpenOption_CREATE_NEW *StandardOpenOption

var StandardOpenOption_DELETE_ON_CLOSE *StandardOpenOption

var StandardOpenOption_SPARSE *StandardOpenOption

var StandardOpenOption_SYNC *StandardOpenOption

var StandardOpenOption_DSYNC *StandardOpenOption

var StandardOpenOption__VALUES *RefArray

var StandardOpenOption_init ClassInit

func StandardOpenOption_Init() { if !StandardOpenOption_init.Done() { StandardOpenOption_init.Run(StandardOpenOption_clinit) } }

func StandardOpenOption_clinit() { StandardOpenOption_READ = StandardOpenOption_New_String_I(Lit_1166, 0); StandardOpenOption_WRITE = StandardOpenOption_New_String_I(Lit_1167, 1); StandardOpenOption_APPEND = StandardOpenOption_New_String_I(Lit_1168, 2); StandardOpenOption_TRUNCATE_EXISTING = StandardOpenOption_New_String_I(Lit_1509, 3); StandardOpenOption_CREATE = StandardOpenOption_New_String_I(Lit_1510, 4); StandardOpenOption_CREATE_NEW = StandardOpenOption_New_String_I(Lit_1511, 5); StandardOpenOption_DELETE_ON_CLOSE = StandardOpenOption_New_String_I(Lit_1512, 6); StandardOpenOption_SPARSE = StandardOpenOption_New_String_I(Lit_1513, 7); StandardOpenOption_SYNC = StandardOpenOption_New_String_I(Lit_1514, 8); StandardOpenOption_DSYNC = StandardOpenOption_New_String_I(Lit_1515, 9); StandardOpenOption__VALUES = StandardOpenOption_X_values__StandardOpenOption1() }

func StandardOpenOption_New_String_I(p0 *String, p1 int32) *StandardOpenOption { StandardOpenOption_Init(); t := &StandardOpenOption{}; t.Ctor_String_I(p0, p1); return t }

func (t *StandardOpenOption) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func StandardOpenOption_Values__StandardOpenOption1() *RefArray { StandardOpenOption_Init(); return StandardOpenOption__VALUES.Copy() }

func StandardOpenOption_ValueOf_String__StandardOpenOption(p0 *String) *StandardOpenOption { StandardOpenOption_Init(); return StandardOpenOption_Cast(Enum_ValueOf_Class_String__Enum(StandardOpenOption_class, p0)) }

func StandardOpenOption_X_values__StandardOpenOption1() *RefArray { StandardOpenOption_Init(); return RefArrayOf(StandardOpenOption_class, StandardOpenOption_READ, StandardOpenOption_WRITE, StandardOpenOption_APPEND, StandardOpenOption_TRUNCATE_EXISTING, StandardOpenOption_CREATE, StandardOpenOption_CREATE_NEW, StandardOpenOption_DELETE_ON_CLOSE, StandardOpenOption_SPARSE, StandardOpenOption_SYNC, StandardOpenOption_DSYNC) }

func (t *StandardOpenOption) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *StandardOpenOption) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *StandardOpenOption) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *StandardOpenOption) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.nio.file.StandardOpenOption.describeConstable()Ljava/util/Optional;")) }

func (t *StandardOpenOption) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *StandardOpenOption) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *StandardOpenOption) Ref() any { if t == nil { return nil }; return t }

func (t *StandardOpenOption) GetClass__Class() *Class { return StandardOpenOption_class }

func (t *StandardOpenOption) CloneShallow() any { panic(CloneNotSupported(t)) }

func StandardOpenOption_InstanceOf(x any) bool { _, ok := x.(*StandardOpenOption); return ok }

func StandardOpenOption_Cast(x any) *StandardOpenOption { if x == nil { return nil }; v, ok := x.(*StandardOpenOption); if !ok { panic(ClassCast(x, StandardOpenOption_class)) }; return v }
