//line java_text_DateFormatSymbols.ae:1
package jrt

import "sync/atomic"















func DateFormatSymbols_New() *DateFormatSymbols { DateFormatSymbols_Init(); t := &DateFormatSymbols{}; t.Ctor(); return t }
//line :19:1
func (t *DateFormatSymbols) Ctor() { t.F_eras = nil; t.F_months = nil; t.F_shortMonths = nil; t.F_weekdays = nil; t.F_shortWeekdays = nil; t.F_ampms = nil; t.F_zoneStrings = nil; t.F_isZoneStringsSet = false; t.F_localPatternChars = nil; t.F_locale = nil
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.InitializeData_Locale__V(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormatSymbols_New_Locale(p0 *Locale) *DateFormatSymbols { DateFormatSymbols_Init(); t := &DateFormatSymbols{}; t.Ctor_Locale(p0); return t }
//line :22:1
func (t *DateFormatSymbols) Ctor_Locale(locale *Locale) { t.F_eras = nil; t.F_months = nil; t.F_shortMonths = nil; t.F_weekdays = nil; t.F_shortWeekdays = nil; t.F_ampms = nil; t.F_zoneStrings = nil; t.F_isZoneStringsSet = false; t.F_localPatternChars = nil; t.F_locale = nil
	t.InitializeData_Locale__V(Locale_Cast(Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_1803)))
}
func DateFormatSymbols_New_Z(p0 bool) *DateFormatSymbols { DateFormatSymbols_Init(); t := &DateFormatSymbols{}; t.Ctor_Z(p0); return t }
//line :25:1
func (t *DateFormatSymbols) Ctor_Z(flag bool) { t.F_eras = nil; t.F_months = nil; t.F_shortMonths = nil; t.F_weekdays = nil; t.F_shortWeekdays = nil; t.F_ampms = nil; t.F_zoneStrings = nil; t.F_isZoneStringsSet = false; t.F_localPatternChars = nil; t.F_locale = nil }







































































func DateFormatSymbols_GetAvailableLocales__Locale1() *RefArray { DateFormatSymbols_Init()
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(DateFormatSymbolsProvider_class)
	return NN(pool).GetAvailableLocales__Locale1()
}
func DateFormatSymbols_GetInstance__DateFormatSymbols() *DateFormatSymbols { DateFormatSymbols_Init()
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(locale *Locale) *DateFormatSymbols { DateFormatSymbols_Init()
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_1803)
	var dfs *DateFormatSymbols = DateFormatSymbols_GetProviderInstance_Locale__DateFormatSymbols(locale)
	if !(dfs == nil) { return dfs } else { panic(Thrown(RuntimeException_New_String(Lit_1804)))
	} }
func DateFormatSymbols_GetProviderInstance_Locale__DateFormatSymbols(locale *Locale) *DateFormatSymbols { DateFormatSymbols_Init()
	var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(DateFormatSymbolsProvider_class, locale); var provider DateFormatSymbolsProvider_I = adapter.GetDateFormatSymbolsProvider__DateFormatSymbolsProvider(); var dfsyms *DateFormatSymbols = provider.GetInstance_Locale__DateFormatSymbols(locale)


	if dfsyms == nil {
		provider = LocaleProviderAdapter_ForJRE__LocaleProviderAdapter().GetDateFormatSymbolsProvider__DateFormatSymbolsProvider()
		dfsyms = provider.GetInstance_Locale__DateFormatSymbols(locale) }
//line :110:1
	return dfsyms
}






func (t *DateFormatSymbols) GetEras__String1() *RefArray {
	var tmp1 *RefArray = t.F_eras; return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_eras.A))).Ref(), String_class.ArrayClass())
}
func (t *DateFormatSymbols) SetEras_String1__V(newEras *RefArray) {
	t.F_eras = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(newEras, int32(len(newEras.A))).Ref(), String_class.ArrayClass())
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) GetMonths__String1() *RefArray {
	var tmp1 *RefArray = t.F_months; return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_months.A))).Ref(), String_class.ArrayClass())
}
func (t *DateFormatSymbols) SetMonths_String1__V(newMonths *RefArray) {
	t.F_months = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(newMonths, int32(len(newMonths.A))).Ref(), String_class.ArrayClass())
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) GetShortMonths__String1() *RefArray {
	var tmp1 *RefArray = t.F_shortMonths; return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_shortMonths.A))).Ref(), String_class.ArrayClass())
}
func (t *DateFormatSymbols) SetShortMonths_String1__V(newShortMonths *RefArray) {
	t.F_shortMonths = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(newShortMonths, int32(len(newShortMonths.A))).Ref(), String_class.ArrayClass())
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) GetWeekdays__String1() *RefArray {
	var tmp1 *RefArray = t.F_weekdays; return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_weekdays.A))).Ref(), String_class.ArrayClass())
}
func (t *DateFormatSymbols) SetWeekdays_String1__V(newWeekdays *RefArray) {
	t.F_weekdays = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(newWeekdays, int32(len(newWeekdays.A))).Ref(), String_class.ArrayClass())
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) GetShortWeekdays__String1() *RefArray {
	var tmp1 *RefArray = t.F_shortWeekdays; return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_shortWeekdays.A))).Ref(), String_class.ArrayClass())
}
func (t *DateFormatSymbols) SetShortWeekdays_String1__V(newShortWeekdays *RefArray) {
	t.F_shortWeekdays = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(newShortWeekdays, int32(len(newShortWeekdays.A))).Ref(), String_class.ArrayClass())
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) GetAmPmStrings__String1() *RefArray {
	var tmp1 *RefArray = t.F_ampms; return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_ampms.A))).Ref(), String_class.ArrayClass())
}
func (t *DateFormatSymbols) SetAmPmStrings_String1__V(newAmpms *RefArray) {
	t.F_ampms = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(newAmpms, int32(len(newAmpms.A))).Ref(), String_class.ArrayClass())
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) GetZoneStrings__String2() *RefArray {
	return t.GetZoneStringsImpl_Z__String2(true)
}
func (t *DateFormatSymbols) SetZoneStrings_String2__V(newZoneStrings *RefArray) {
	var aCopy *RefArray = NewRefArray(String_class.ArrayClass(), int32(len(newZoneStrings.A))); var i int32 = 0
L1: for {
	if i < int32(len(newZoneStrings.A)) {
		var len_ int32 = int32(len(As[*RefArray](newZoneStrings.A[i]).A))
		if len_ < 5 {
			panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_1805, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(i))))))
		}


		aCopy.Store(i, A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(As[*RefArray](newZoneStrings.A[i]), len_).Ref(), String_class.ArrayClass()).Ref())
		i = i + 1; continue L1 }
//line :165:1
	break L1
}








	t.F_zoneStrings = aCopy
	t.F_isZoneStringsSet = true
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) GetLocalPatternChars__String() *String { return t.F_localPatternChars }

func (t *DateFormatSymbols) SetLocalPatternChars_String__V(newLocalPatternChars *String) {
	t.F_localPatternChars = NN(newLocalPatternChars).ToString__String()
	t.F_cachedHashCode.Store(0)
}
func (t *DateFormatSymbols) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var other *DateFormatSymbols = DateFormatSymbols_Cast(A2g_ObjectClone(t)); t.CopyMembers_DateFormatSymbols_DateFormatSymbols__V(t, other); tmp1 = other.Ref() }; return nil }()
//line :186:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :186:1
			panic(tmp2) } }; return tmp1
}


func (t *DateFormatSymbols) HashCode__I() int32 {
	var hashCode int32 = t.F_cachedHashCode.Load()
	if hashCode == 0 {
		hashCode = 5
		hashCode = 11*hashCode + Arrays_HashCode_O1__I(t.F_eras)

		hashCode = 11*hashCode + Arrays_HashCode_O1__I(t.F_months)

		hashCode = 11*hashCode + Arrays_HashCode_O1__I(t.F_shortMonths)


		hashCode = 11*hashCode + Arrays_HashCode_O1__I(t.F_weekdays)

		hashCode = 11*hashCode + Arrays_HashCode_O1__I(t.F_shortWeekdays)


		hashCode = 11*hashCode + Arrays_HashCode_O1__I(t.F_ampms)

		hashCode = 11*hashCode + Arrays_DeepHashCode_O1__I(t.GetZoneStringsWrapper__String2())


		hashCode = 11*hashCode + Objects_HashCode_O__I(t.F_localPatternChars.Ref())


		if hashCode == 0 { } else { t.F_cachedHashCode.Store(hashCode) } }
//line :191:1
	return hashCode
}
























func (t *DateFormatSymbols) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = obj == nil; if !tmp2 { tmp2 = !(t.GetClass__Class() == GetClass(obj)) }; tmp1 = tmp2
//line :218:1
		if tmp1 { return false } else {



			var that *DateFormatSymbols = DateFormatSymbols_Cast(obj); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 *RefArray = t.F_eras
			tmp9 = Arrays_Equals_O1_O1__Z(tmp10, that.F_eras); if tmp9 {
				var tmp11 *RefArray = t.F_months; tmp9 = Arrays_Equals_O1_O1__Z(tmp11, that.F_months) }
//line :223:1
			tmp8 = tmp9; if tmp8 {

				var tmp12 *RefArray = t.F_shortMonths; tmp8 = Arrays_Equals_O1_O1__Z(tmp12, that.F_shortMonths) }
//line :223:1
			tmp7 = tmp8; if tmp7 {


				var tmp13 *RefArray = t.F_weekdays; tmp7 = Arrays_Equals_O1_O1__Z(tmp13, that.F_weekdays) }
//line :223:1
			tmp6 = tmp7; if tmp6 {



				var tmp14 *RefArray = t.F_shortWeekdays; tmp6 = Arrays_Equals_O1_O1__Z(tmp14, that.F_shortWeekdays) }
//line :223:1
			tmp5 = tmp6; if tmp5 {




				var tmp15 *RefArray = t.F_ampms; tmp5 = Arrays_Equals_O1_O1__Z(tmp15, that.F_ampms) }
//line :223:1
			tmp4 = tmp5; if tmp4 {





				tmp4 = Arrays_DeepEquals_O1_O1__Z(t.GetZoneStringsWrapper__String2(), NN(that).GetZoneStringsWrapper__String2()) }
//line :223:1
			tmp3 = tmp4; if tmp3 {






				var tmp16 any = t.F_localPatternChars.Ref(); tmp3 = Objects_Equals_O_O__Z(tmp16, that.F_localPatternChars.Ref()) }
//line :223:1
			return tmp3
		}
	}
}












func (t *DateFormatSymbols) InitializeData_Locale__V(locale *Locale) {
	var ref *SoftReference = SoftReference_Cast(DateFormatSymbols_cachedInstances.Get_O__O(locale.Ref())); var dfs *DateFormatSymbols; var tmp1 bool; var tmp2 bool



	tmp2 = ref == nil; if !tmp2 { var tmp3 *DateFormatSymbols; dfs = DateFormatSymbols_Cast(NN(ref).Get__O()); tmp3 = dfs; tmp2 = tmp3 == nil }; tmp1 = tmp2; if tmp1 {
		if !(ref == nil) { DateFormatSymbols_cachedInstances.Remove_O_O__Z(locale.Ref(), ref.Ref()) }
		dfs = DateFormatSymbols_New_Z(false)
		var override *Locale = CalendarDataUtility_FindRegionOverride_Locale__Locale(locale); var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(DateFormatSymbolsProvider_class, override)



		if ResourceBundleBasedAdapter_InstanceOf(adapter) { } else {
			adapter = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter() }
		var resource ResourceBundle_I = NN(ResourceBundleBasedAdapter_Cast(adapter).GetLocaleData__LocaleData()).GetDateFormatData_Locale__ResourceBundle(override)


		dfs.F_locale = locale
		if resource.ContainsKey_String__Z(Lit_1806) {
			dfs.F_eras = resource.GetStringArray_String__String1(Lit_1806) } else {
//line :257:1
				if resource.ContainsKey_String__Z(Lit_1807) {


					dfs.F_eras = resource.GetStringArray_String__String1(Lit_1807) } else {
//line :257:1
						if resource.ContainsKey_String__Z(Lit_1808) {




							dfs.F_eras = resource.GetStringArray_String__String1(Lit_1808) } } }
		dfs.F_months = resource.GetStringArray_String__String1(Lit_1809)
		dfs.F_shortMonths = resource.GetStringArray_String__String1(Lit_1810)
		dfs.F_ampms = resource.GetStringArray_String__String1(Lit_1811)
		if int32(len(dfs.F_ampms.A)) > 2 {
			dfs.F_ampms = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(dfs.F_ampms, 2).Ref(), String_class.ArrayClass()) }
		dfs.F_localPatternChars = resource.GetString_String__String(Lit_1812)
		dfs.F_weekdays = DateFormatSymbols_ToOneBasedArray_String1__String1(resource.GetStringArray_String__String1(Lit_1813))

		dfs.F_shortWeekdays = DateFormatSymbols_ToOneBasedArray_String1__String1(resource.GetStringArray_String__String1(Lit_1814))

		ref = SoftReference_New_O(dfs.Ref())
		var x *SoftReference = SoftReference_Cast(DateFormatSymbols_cachedInstances.PutIfAbsent_O_O__O(locale.Ref(), ref.Ref()))





		if !(x == nil) {
			var y *DateFormatSymbols = DateFormatSymbols_Cast(NN(x).Get__O())
			if y == nil {
				DateFormatSymbols_cachedInstances.Replace_O_O_O__Z(locale.Ref(), x.Ref(), ref.Ref()) } else {
					ref = x; dfs = y } } }
	t.CopyMembers_DateFormatSymbols_DateFormatSymbols__V(dfs, t)
}
func DateFormatSymbols_ToOneBasedArray_String1__String1(src *RefArray) *RefArray { DateFormatSymbols_Init()
	var len_ int32 = int32(len(src.A)); var dst *RefArray = NewRefArray(String_class, len_+1)

	dst.Store(0, Lit_69)
	var i int32 = 0; L1: for {
		if i < len_ {
			dst.Store(i+1, As[*String](src.A[i]).Ref())
			i = i + 1; continue L1 }
//line :291:1
		break L1 }
//line :288:1
	return dst
}







func (t *DateFormatSymbols) GetZoneIndex_String__I(ID_ *String) int32 {
	var zoneStrings *RefArray = t.GetZoneStringsWrapper__String2(); var tmp1 bool; var tmp2 bool; var tmp3 int32 = t.F_lastZoneIndex
	tmp2 = tmp3 < int32(len(zoneStrings.A)); if tmp2 {
		tmp2 = NN(ID_).Equals_O__Z(As[*String](As[*RefArray](zoneStrings.A[t.F_lastZoneIndex]).A[0]).Ref()) }
//line :299:1
	tmp1 = tmp2; if tmp1 { return t.F_lastZoneIndex } else {



		var index int32 = 0; L1: for {
			if index < int32(len(zoneStrings.A)) {
				if NN(ID_).Equals_O__Z(As[*String](As[*RefArray](zoneStrings.A[index]).A[0]).Ref()) {
					t.F_lastZoneIndex = index; return index } else {
						index = index + 1; continue L1 } }
//line :303:1
			break L1 }
//line :302:1
		return -1
	}
}






func (t *DateFormatSymbols) GetZoneStringsWrapper__String2() *RefArray {
	if t.IsSubclassObject__Z() { return t.GetZoneStrings__String2() } else { return t.GetZoneStringsImpl_Z__String2(false)
	} }
func (t *DateFormatSymbols) GetZoneStringsImpl_Z__String2(needsCopy bool) *RefArray {
	if t.F_zoneStrings == nil { t.F_zoneStrings = TimeZoneNameUtility_GetZoneStrings_Locale__String2(t.F_locale) }
	if !needsCopy { return t.F_zoneStrings } else {

		var len_ int32 = int32(len(t.F_zoneStrings.A)); var aCopy *RefArray = NewRefArray(String_class.ArrayClass(), len_)
		var i int32 = 0
	L1: for {
		if i < len_ {
			var tmp1 *RefArray = As[*RefArray](t.F_zoneStrings.A[i]); aCopy.Store(i, A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(As[*RefArray](t.F_zoneStrings.A[i]).A))).Ref(), String_class.ArrayClass()).Ref())



			i = i + 1; continue L1 }
//line :320:1
		break L1 }
//line :318:1
		return aCopy
	}
}








func (t *DateFormatSymbols) IsSubclassObject__Z() bool {
	return !NN(NN(t.GetClass__Class()).GetName__String()).Equals_O__Z(Lit_1815)
}
func (t *DateFormatSymbols) CopyMembers_DateFormatSymbols_DateFormatSymbols__V(src, dst *DateFormatSymbols) {
	dst.F_locale = src.F_locale
	var tmp1 *RefArray = src.F_eras; dst.F_eras = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp1, int32(len(src.F_eras.A))).Ref(), String_class.ArrayClass())
	var tmp2 *RefArray = src.F_months; dst.F_months = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp2, int32(len(src.F_months.A))).Ref(), String_class.ArrayClass())
	var tmp3 *RefArray = src.F_shortMonths; dst.F_shortMonths = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp3, int32(len(src.F_shortMonths.A))).Ref(), String_class.ArrayClass())

	var tmp4 *RefArray = src.F_weekdays; dst.F_weekdays = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp4, int32(len(src.F_weekdays.A))).Ref(), String_class.ArrayClass())

	var tmp5 *RefArray = src.F_shortWeekdays; dst.F_shortWeekdays = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp5, int32(len(src.F_shortWeekdays.A))).Ref(), String_class.ArrayClass())

	var tmp6 *RefArray = src.F_ampms; dst.F_ampms = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(tmp6, int32(len(src.F_ampms.A))).Ref(), String_class.ArrayClass())
	if !(src.F_zoneStrings == nil) {
		dst.F_zoneStrings = NN(src).GetZoneStringsImpl_Z__String2(true) } else {
			dst.F_zoneStrings = nil }
	dst.F_localPatternChars = src.F_localPatternChars
	dst.F_cachedHashCode.Store(0)
}


type DateFormatSymbols struct{ Object; F_eras, F_months, F_shortMonths, F_weekdays, F_shortWeekdays, F_ampms, F_zoneStrings *RefArray; F_isZoneStringsSet bool; F_localPatternChars *String; F_locale *Locale; F_lastZoneIndex int32; F_cachedHashCode atomic.Int32 }

func (t *DateFormatSymbols) Is_Serializable() {}

func (t *DateFormatSymbols) Is_Cloneable() {}

var DateFormatSymbols_patternChars *String = Lit_1816

const DateFormatSymbols_PATTERN_ERA int32 = 0

const DateFormatSymbols_PATTERN_YEAR int32 = 1

const DateFormatSymbols_PATTERN_MONTH int32 = 2

const DateFormatSymbols_PATTERN_DAY_OF_MONTH int32 = 3

const DateFormatSymbols_PATTERN_HOUR_OF_DAY1 int32 = 4

const DateFormatSymbols_PATTERN_HOUR_OF_DAY0 int32 = 5

const DateFormatSymbols_PATTERN_MINUTE int32 = 6

const DateFormatSymbols_PATTERN_SECOND int32 = 7

const DateFormatSymbols_PATTERN_MILLISECOND int32 = 8

const DateFormatSymbols_PATTERN_DAY_OF_WEEK int32 = 9

const DateFormatSymbols_PATTERN_DAY_OF_YEAR int32 = 10

const DateFormatSymbols_PATTERN_DAY_OF_WEEK_IN_MONTH int32 = 11

const DateFormatSymbols_PATTERN_WEEK_OF_YEAR int32 = 12

const DateFormatSymbols_PATTERN_WEEK_OF_MONTH int32 = 13

const DateFormatSymbols_PATTERN_AM_PM int32 = 14

const DateFormatSymbols_PATTERN_HOUR1 int32 = 15

const DateFormatSymbols_PATTERN_HOUR0 int32 = 16

const DateFormatSymbols_PATTERN_ZONE_NAME int32 = 17

const DateFormatSymbols_PATTERN_ZONE_VALUE int32 = 18

const DateFormatSymbols_PATTERN_WEEK_YEAR int32 = 19

const DateFormatSymbols_PATTERN_ISO_DAY_OF_WEEK int32 = 20

const DateFormatSymbols_PATTERN_ISO_ZONE int32 = 21

const DateFormatSymbols_PATTERN_MONTH_STANDALONE int32 = 22

const DateFormatSymbols_serialVersionUID int64 = -5987973545549424702

var DateFormatSymbols_cachedInstances ConcurrentMap

var DateFormatSymbols_init ClassInit

func DateFormatSymbols_Init() { if !DateFormatSymbols_init.Done() { DateFormatSymbols_init.Run(DateFormatSymbols_clinit) } }

func DateFormatSymbols_clinit() { DateFormatSymbols_cachedInstances = ConcurrentHashMap_New_I(3) }

func (t *DateFormatSymbols) Ref() any { if t == nil { return nil }; return t }

func (t *DateFormatSymbols) GetClass__Class() *Class { return DateFormatSymbols_class }

func (t *DateFormatSymbols) ToString__String() *String { return Object_toString(t) }

func (t *DateFormatSymbols) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func DateFormatSymbols_InstanceOf(x any) bool { _, ok := x.(*DateFormatSymbols); return ok }

func DateFormatSymbols_Cast(x any) *DateFormatSymbols { if x == nil { return nil }; v, ok := x.(*DateFormatSymbols); if !ok { panic(ClassCast(x, DateFormatSymbols_class)) }; return v }
