//line java_io_File.ae:1
package jrt















func (t *File) ToPath__Path() Path {
	var result Path = t.F_filePath.Load()
	if result == nil {
		var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
			result = t.F_filePath.Load()
			if result == nil {
				result = HostPath_OfFile_String__Path(t.F_path)
				t.F_filePath.Store(result) } }() }
//line :18:1
	return result
}




func (t *File) IsInvalid__Z() bool {
	var s *File_PathStatus = t.F_status
	if s == nil {
		var tmp1 *File_PathStatus; if File_FS.IsInvalid_File__Z(t) { File_PathStatus_Init(); tmp1 = File_PathStatus_INVALID } else { File_PathStatus_Init(); tmp1 = File_PathStatus_CHECKED }; s = tmp1
		t.F_status = s }
	var tmp2 *File_PathStatus = s; var tmp3 *File_PathStatus; File_PathStatus_Init(); tmp3 = File_PathStatus_INVALID; return tmp2 == tmp3
}


func (t *File) GetPrefixLength__I() int32 { return t.F_prefixLength }









func File_New_String_I(p0 *String, p1 int32) *File { File_Init(); t := &File{}; t.Ctor_String_I(p0, p1); return t }
//line :43:1
func (t *File) Ctor_String_I(pathname *String, prefixLength int32) { t.F_status = nil
	t.F_path = pathname
	t.F_prefixLength = prefixLength
}
func File_New_String_File(p0 *String, p1 *File) *File { File_Init(); t := &File{}; t.Ctor_String_File(p0, p1); return t }
//line :47:1
func (t *File) Ctor_String_File(child *String, parent *File) { t.F_status = nil
	if !A2g_AssertionsDisabled && !!(parent.F_path == nil) { panic(Thrown(AssertionError_New())) }
	if !A2g_AssertionsDisabled && !!NN(parent.F_path).IsEmpty__Z() { panic(Thrown(AssertionError_New())) }
	var tmp1 FileSystem_I = File_FS; t.F_path = tmp1.Resolve_String_String__String(parent.F_path, child)
	t.F_prefixLength = parent.F_prefixLength
}
func File_New_String(p0 *String) *File { File_Init(); t := &File{}; t.Ctor_String(p0); return t }
//line :53:1
func (t *File) Ctor_String(pathname *String) { t.F_status = nil
	if pathname == nil { panic(Thrown(NullPointerException_New())) }
	t.F_path = File_FS.Normalize_String__String(pathname)
	t.F_prefixLength = File_FS.PrefixLength_String__I(t.F_path)
}
func File_New_String_String(p0, p1 *String) *File { File_Init(); t := &File{}; t.Ctor_String_String(p0, p1); return t }
//line :58:1
func (t *File) Ctor_String_String(parent, child *String) { t.F_status = nil
	if child == nil { panic(Thrown(NullPointerException_New())) }
	if !(parent == nil) {
		if NN(parent).IsEmpty__Z() {
			var tmp1 FileSystem_I = File_FS; t.F_path = tmp1.Resolve_String_String__String(File_FS.GetDefaultParent__String(), File_FS.Normalize_String__String(child)) } else {
				var tmp2 FileSystem_I = File_FS; t.F_path = tmp2.Resolve_String_String__String(File_FS.Normalize_String__String(parent), File_FS.Normalize_String__String(child)) } } else {
					t.F_path = File_FS.Normalize_String__String(child) }
	t.F_prefixLength = File_FS.PrefixLength_String__I(t.F_path)
}
func File_New_File_String(p0 *File, p1 *String) *File { File_Init(); t := &File{}; t.Ctor_File_String(p0, p1); return t }
//line :67:1
func (t *File) Ctor_File_String(parent *File, child *String) { t.F_status = nil
	if child == nil { panic(Thrown(NullPointerException_New())) }
	if !(parent == nil) {
		if NN(parent.F_path).IsEmpty__Z() {
			var tmp1 FileSystem_I = File_FS; t.F_path = tmp1.Resolve_String_String__String(File_FS.GetDefaultParent__String(), File_FS.Normalize_String__String(child)) } else {
				var tmp2 FileSystem_I = File_FS; var tmp3 *String = parent.F_path; t.F_path = tmp2.Resolve_String_String__String(tmp3, File_FS.Normalize_String__String(child)) } } else {
					t.F_path = File_FS.Normalize_String__String(child) }
	t.F_prefixLength = File_FS.PrefixLength_String__I(t.F_path)
}
func File_New_URI(p0 *URI) *File { File_Init(); t := &File{}; t.Ctor_URI(p0); return t }
//line :76:1
func (t *File) Ctor_URI(uri *URI) { t.F_status = nil
	if NN(uri).IsAbsolute__Z() { } else { panic(Thrown(IllegalArgumentException_New_String(Lit_59))) }
	if NN(uri).IsOpaque__Z() { panic(Thrown(IllegalArgumentException_New_String(Lit_60))) }
	var scheme *String = NN(uri).GetScheme__String(); var tmp1 bool; var tmp2 bool
	tmp2 = scheme == nil; if !tmp2 { tmp2 = !NN(scheme).EqualsIgnoreCase_String__Z(Lit_61) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_62))) }
	if !(NN(uri).GetRawAuthority__String() == nil) {
		panic(Thrown(IllegalArgumentException_New_String(Lit_63))) }
	if !(NN(uri).GetRawFragment__String() == nil) {
		panic(Thrown(IllegalArgumentException_New_String(Lit_64))) }
	if !(NN(uri).GetRawQuery__String() == nil) {
		panic(Thrown(IllegalArgumentException_New_String(Lit_65))) }
	var p *String = NN(uri).GetPath__String()
	if NN(p).IsEmpty__Z() { panic(Thrown(IllegalArgumentException_New_String(Lit_66))) }
	p = File_FS.FromURIPath_String__String(p)
	if int32(File_separatorChar) == 47 { } else { p = NN(p).Replace_C_C__String(47, File_separatorChar) }
	t.F_path = File_FS.Normalize_String__String(p)
	t.F_prefixLength = File_FS.PrefixLength_String__I(t.F_path)
}
func (t *File) GetName__String() *String {
	var index int32 = NN(t.F_path).LastIndexOf_I__I(int32(File_separatorChar))
	if index < t.F_prefixLength {
		return NN(t.F_path).Substring_I__String(t.F_prefixLength) } else {
			return NN(t.F_path).Substring_I__String(index + 1)
		} }
func (t *File) GetParent__String() *String {
	var index int32 = NN(t.F_path).LastIndexOf_I__I(int32(File_separatorChar))
	if index < t.F_prefixLength {
		var tmp1 bool; var tmp2 bool; tmp2 = t.F_prefixLength > 0; if tmp2 { tmp2 = NN(t.F_path).Length__I() > t.F_prefixLength }; tmp1 = tmp2; if tmp1 {
			return NN(t.F_path).Substring_I_I__String(0, t.F_prefixLength) } else {
//line :104:1
				return nil } } else {

					return NN(t.F_path).Substring_I_I__String(0, index)
				} }
func (t *File) GetParentFile__File() *File {
	var p *String = t.GetParent__String()
	if !(p == nil) {
		if t.GetClass__Class() == File_class { } else { p = File_FS.Normalize_String__String(p) }
		return File_New_String_I(p, t.F_prefixLength) } else {
//line :110:1
			return nil
		}
}

func (t *File) GetPath__String() *String { return t.F_path }

func (t *File) IsAbsolute__Z() bool { return File_FS.IsAbsolute_File__Z(t) }

func (t *File) GetAbsolutePath__String() *String { return File_FS.Resolve_File__String(t) }

func (t *File) GetAbsoluteFile__File() *File {
	var absPath *String = t.GetAbsolutePath__String()
	if t.GetClass__Class() == File_class { } else { absPath = File_FS.Normalize_String__String(absPath) }
	return File_New_String_I(absPath, File_FS.PrefixLength_String__I(absPath))
}
func (t *File) GetCanonicalPath__String() *String {
	if t.IsInvalid__Z() { panic(Thrown(IOException_New_String(Lit_67))) }
	var tmp1 FileSystem_I = File_FS; return tmp1.Canonicalize_String__String(File_FS.Resolve_File__String(t))
}
func (t *File) GetCanonicalFile__File() *File {
	var canonPath *String = t.GetCanonicalPath__String()
	if t.GetClass__Class() == File_class { } else { canonPath = File_FS.Normalize_String__String(canonPath) }
	return File_New_String_I(canonPath, File_FS.PrefixLength_String__I(canonPath))
}
func File_Slashify_String_Z__String(path *String, isDirectory bool) *String { File_Init()
	var p *String = path
	if int32(File_separatorChar) == 47 { } else { p = NN(p).Replace_C_C__String(File_separatorChar, 47) }
	if NN(p).StartsWith_String__Z(Lit_68) { } else { p = Concat(Lit_68, p) }
	var tmp1 bool; var tmp2 bool; tmp2 = !NN(p).EndsWith_String__Z(Lit_68); if tmp2 { tmp2 = isDirectory }; tmp1 = tmp2; if tmp1 { p = Concat(p, Lit_68) }
//line :135:1
	return p
}




func (t *File) ToURL__URL() *URL {
	if t.IsInvalid__Z() { panic(Thrown(MalformedURLException_New_String(Lit_67))) }
	var result *URL = URL_New_String_String_String(Lit_61, Lit_69, File_Slashify_String_Z__String(t.GetAbsolutePath__String(), t.IsDirectory__Z())); return result
}

func (t *File) ToURI__URI() *URI {
	var tmp1 *URI; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var f *File = t.GetAbsoluteFile__File(); var sp *String = File_Slashify_String_Z__String(NN(f).GetPath__String(), NN(f).IsDirectory__Z())

			if NN(sp).StartsWith_String__Z(Lit_70) { sp = Concat(Lit_70, sp) }
			tmp1 = URI_New_String_String_String_String(Lit_61, nil, sp, nil) }; return nil }()
//line :147:1
	if tmp2 != nil { if URISyntaxException_InstanceOf(tmp2) { var x *URISyntaxException = URISyntaxException_Cast(tmp2)




		panic(Thrown(Error_New_Throwable(Up_URISyntaxException_Throwable(x)))) } else {
//line :147:1
			panic(tmp2) } }; return tmp1
}





func (t *File) CanRead__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.CheckAccess_File_I__Z(t, 4)
	} }
func (t *File) CanWrite__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.CheckAccess_File_I__Z(t, 2)
	} }
func (t *File) Exists__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.HasBooleanAttributes_File_I__Z(t, 1)
	} }
func (t *File) IsDirectory__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.HasBooleanAttributes_File_I__Z(t, 4)
	} }
func (t *File) IsFile__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.HasBooleanAttributes_File_I__Z(t, 2)
	} }
func (t *File) IsHidden__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.HasBooleanAttributes_File_I__Z(t, 8)
	} }
func (t *File) LastModified__J() int64 {
	if t.IsInvalid__Z() { return 0 } else { return File_FS.GetLastModifiedTime_File__J(t)
	} }
func (t *File) Length__J() int64 {
	if t.IsInvalid__Z() { return 0 } else { return File_FS.GetLength_File__J(t)
	} }
func (t *File) CreateNewFile__Z() bool {
	if t.IsInvalid__Z() { panic(Thrown(IOException_New_String(Lit_67))) }
	return File_FS.CreateFileExclusively_String__Z(t.F_path)
}
func (t *File) Delete__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.Delete_File__Z(t)
	} }
func (t *File) DeleteOnExit__V() {
	if t.IsInvalid__Z() { } else { DeleteOnExitHook_Add_String__V(t.F_path)
	} }
func (t *File) List__String1() *RefArray { return t.NormalizedList__String1() }

func (t *File) NormalizedList__String1() *RefArray {
	if t.IsInvalid__Z() { return nil } else {
		var s *RefArray = File_FS.List_File__String1(t); var tmp1 bool; var tmp2 bool
		tmp2 = !(s == nil); if tmp2 { tmp2 = !(t.GetClass__Class() == File_class) }; tmp1 = tmp2; if tmp1 {
			var normalized *RefArray = NewRefArray(String_class, int32(len(s.A))); var i int32 = 0
		L1: for {
			if i < int32(len(s.A)) {
				var tmp3 FileSystem_I = File_FS; normalized.Store(i, tmp3.Normalize_String__String(As[*String](s.A[i])).Ref())
				i = i + 1; continue L1 }
//line :195:1
			break L1
		}


			s = normalized }
//line :192:1
		return s
	}
}







func (t *File) List_FilenameFilter__String1(filter FilenameFilter) *RefArray {
	var names *RefArray = t.NormalizedList__String1(); var tmp1 bool; var tmp2 bool
	tmp2 = names == nil; if !tmp2 { tmp2 = filter == nil }; tmp1 = tmp2; if tmp1 { return names } else {

		var v List = ArrayList_New(); var i int32 = 0
	L1: for {
		if i < int32(len(names.A)) {
			if filter.Accept_File_String__Z(t, As[*String](names.A[i])) {
				v.Add_O__Z(As[*String](names.A[i]).Ref()); i = i + 1; continue L1 } else {
					i = i + 1; continue L1 } }
//line :207:1
		break L1
	}




		return A2g_CastArray[*RefArray](v.ToArray_O1__O1(NewRefArray(String_class, v.Size__I())).Ref(), String_class.ArrayClass())
	} }
func (t *File) ListFiles__File1() *RefArray {
	var ss *RefArray = t.NormalizedList__String1()
	if !(ss == nil) {
		var n int32 = int32(len(ss.A)); var fs *RefArray = NewRefArray(File_class, n); var isEmpty bool = NN(t.F_path).IsEmpty__Z()
		var i int32 = 0

	L1: for {
		if i < n {
			var tmp1 *File; if isEmpty { tmp1 = File_New_String(As[*String](ss.A[i])) } else { tmp1 = File_New_String_File(As[*String](ss.A[i]), t) }; fs.Store(i, tmp1.Ref())
			i = i + 1; continue L1 }
//line :221:1
		break L1 }
//line :218:1
		return fs




	} else {
//line :217:1
		return nil
	}
}







func (t *File) ListFiles_FilenameFilter__File1(filter FilenameFilter) *RefArray {
	var ss *RefArray = t.NormalizedList__String1()
	if !(ss == nil) {
		var files *ArrayList = ArrayList_New(); var isEmpty bool = NN(t.F_path).IsEmpty__Z(); var arr_100999 *RefArray = ss; var len_101000 int32 = int32(len(arr_100999.A)); var i_101001 int32 = 0; for ; i_101001 < len_101000; i_101001++ {

			var s *String = As[*String](arr_100999.A[i_101001]); var tmp1 bool; var tmp2 bool
			tmp2 = filter == nil; if !tmp2 { tmp2 = filter.Accept_File_String__Z(t, s) }; tmp1 = tmp2; if tmp1 {
				var tmp3 *File; if isEmpty { tmp3 = File_New_String(s) } else { tmp3 = File_New_String_File(s, t) }; NN(files).Add_O__Z(tmp3.Ref()) } }
		return A2g_CastArray[*RefArray](NN(files).ToArray_O1__O1(NewRefArray(File_class, NN(files).Size__I())).Ref(), File_class.ArrayClass()) } else {
//line :229:1
			return nil
		}
}





func (t *File) ListFiles_FileFilter__File1(filter FileFilter) *RefArray {
	var ss *RefArray = t.NormalizedList__String1()
	if !(ss == nil) {
		var files *ArrayList = ArrayList_New(); var isEmpty bool = NN(t.F_path).IsEmpty__Z(); var arr_101002 *RefArray = ss; var len_101003 int32 = int32(len(arr_101002.A)); var i_101004 int32 = 0; for ; i_101004 < len_101003; i_101004++ {

			var s *String = As[*String](arr_101002.A[i_101004]); var f *File
			if isEmpty { f = File_New_String(s) } else { f = File_New_String_File(s, t) }
			var tmp1 bool; var tmp2 bool; tmp2 = filter == nil; if !tmp2 { tmp2 = filter.Accept_File__Z(f) }; tmp1 = tmp2; if tmp1 { NN(files).Add_O__Z(f.Ref()) } }
		return A2g_CastArray[*RefArray](NN(files).ToArray_O1__O1(NewRefArray(File_class, NN(files).Size__I())).Ref(), File_class.ArrayClass()) } else {
//line :239:1
			return nil
		}
}





func (t *File) Mkdir__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.CreateDirectory_File__Z(t)
	} }
func (t *File) Mkdirs__Z() bool {
	if t.Exists__Z() { return false } else { if t.Mkdir__Z() { return true } else {



		var canonFile *File; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
			canonFile = t.GetCanonicalFile__File(); return nil }(); if tmp1 != nil { if IOException_InstanceOf(tmp1) { var e IOException_I = IOException_Cast(tmp1); _ = e; return false } else { panic(tmp1) } }
		var parent *File = NN(canonFile).GetParentFile__File(); var tmp2 bool; var tmp3 bool
		tmp3 = !(parent == nil); if tmp3 { var tmp4 bool; tmp4 = NN(parent).Mkdirs__Z(); if !tmp4 { tmp4 = NN(parent).Exists__Z() }; tmp3 = tmp4 }; tmp2 = tmp3; if tmp2 { tmp2 = NN(canonFile).Mkdir__Z() }; return tmp2
	} } }
func (t *File) RenameTo_File__Z(dest *File) bool {
	if dest == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.IsInvalid__Z(); if !tmp2 { tmp2 = NN(dest).IsInvalid__Z() }; tmp1 = tmp2; if tmp1 { return false } else { return File_FS.Rename_File_File__Z(t, dest)
	} }
func (t *File) SetLastModified_J__Z(time int64) bool {
	if time < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_71))) }
	if t.IsInvalid__Z() { return false } else { return File_FS.SetLastModifiedTime_File_J__Z(t, time)
	} }
func (t *File) SetReadOnly__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.SetReadOnly_File__Z(t)
	} }
func (t *File) SetWritable_Z_Z__Z(writable, ownerOnly bool) bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.SetPermission_File_I_Z_Z__Z(t, 2, writable, ownerOnly)
	} }
func (t *File) SetWritable_Z__Z(writable bool) bool {
	return t.SetWritable_Z_Z__Z(writable, true)
}
func (t *File) SetReadable_Z_Z__Z(readable, ownerOnly bool) bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.SetPermission_File_I_Z_Z__Z(t, 4, readable, ownerOnly)
	} }
func (t *File) SetReadable_Z__Z(readable bool) bool {
	return t.SetReadable_Z_Z__Z(readable, true)
}
func (t *File) SetExecutable_Z_Z__Z(executable, ownerOnly bool) bool {
	if t.IsInvalid__Z() { return false } else {

		return File_FS.SetPermission_File_I_Z_Z__Z(t, 1, executable, ownerOnly)
	} }
func (t *File) SetExecutable_Z__Z(executable bool) bool {
	return t.SetExecutable_Z_Z__Z(executable, true)
}
func (t *File) CanExecute__Z() bool {
	if t.IsInvalid__Z() { return false } else { return File_FS.CheckAccess_File_I__Z(t, 1)
	} }
func File_ListRoots__File1() *RefArray { File_Init(); return File_FS.ListRoots__File1() }

func (t *File) GetTotalSpace__J() int64 {
	if t.IsInvalid__Z() { return 0 } else {

		var space int64 = File_FS.GetSpace_File_I__J(t, 0)
		if space >= 0 { return space } else { return 9223372036854775807
		} } }
func (t *File) GetFreeSpace__J() int64 {
	if t.IsInvalid__Z() { return 0 } else {

		var space int64 = File_FS.GetSpace_File_I__J(t, 1)
		if space >= 0 { return space } else { return 9223372036854775807
		} } }
func (t *File) GetUsableSpace__J() int64 {
	if t.IsInvalid__Z() { return 0 } else {

		var space int64 = File_FS.GetSpace_File_I__J(t, 2)
		if space >= 0 { return space } else { return 9223372036854775807
		}
	} }
func File_TempDirectory_New() *File_TempDirectory { File_TempDirectory_Init(); t := &File_TempDirectory{}; t.Ctor(); return t }
//line :315:1
func (t *File_TempDirectory) Ctor() { panic(A2g_NotTranslated("java.io.File$TempDirectory.<init>()V")) }



func File_TempDirectory_Location__File() *File { File_TempDirectory_Init(); return File_TempDirectory_TMPDIR }



func File_TempDirectory_ShortenSubName_I_I_I__I(subNameLength, excess, nameMin int32) int32 { File_TempDirectory_Init()
	var newLength int32 = Math_Max_I_I__I(nameMin, subNameLength-excess)
	if newLength < subNameLength { return newLength } else { return subNameLength
	} }
func File_TempDirectory_GenerateFile_String_String_File__File(prefix, suffix *String, dir *File) *File { File_TempDirectory_Init()

	var n int64 = File_TempDirectory_RANDOM.NextLong__J(); var nus *String = Long_ToUnsignedString_J__String(n)

	prefix = File_New_String(prefix).GetName__String()
	var prefixLength int32 = NN(prefix).Length__I(); var nusLength int32 = NN(nus).Length__I(); var suffixLength int32 = NN(suffix).Length__I(); var name *String; var nameMax int32; var tmp1 FileSystem_I



	File_Init(); tmp1 = File_FS; var tmp2 FileSystem_I = tmp1; nameMax = tmp2.GetNameMax_String__I(NN(dir).GetPath__String())
//line :332:1
	var excess int32 = prefixLength + nusLength + suffixLength - nameMax









	if excess <= 0 {
		name = Concat(prefix, nus, suffix) } else {

			prefixLength = File_TempDirectory_ShortenSubName_I_I_I__I(prefixLength, excess, 3)
			excess = prefixLength + nusLength + suffixLength - nameMax



			if excess > 0 {
				var tmp3 int32 = suffixLength; var tmp4 int32 = excess; var tmp5 int32



				if NN(suffix).IndexOf_String__I(Lit_79) == 0 { tmp5 = 4 } else { tmp5 = 0 }
//line :351:1
				suffixLength = File_TempDirectory_ShortenSubName_I_I_I__I(tmp3, tmp4, tmp5)




				suffixLength = File_TempDirectory_ShortenSubName_I_I_I__I(suffixLength, excess, 3)
				excess = prefixLength + nusLength + suffixLength - nameMax
			}



			var tmp6 bool; var tmp7 bool; tmp7 = excess > 0; if tmp7 { tmp7 = excess <= nusLength-5 }; tmp6 = tmp7; if tmp6 {
				nusLength = File_TempDirectory_ShortenSubName_I_I_I__I(nusLength, excess, 5) }
			var sb *StringBuilder = StringBuilder_New_I(prefixLength + nusLength + suffixLength); var tmp8 *String



			if prefixLength < NN(prefix).Length__I() {
				tmp8 = NN(prefix).Substring_I_I__String(0, prefixLength) } else {
//line :368:1
					tmp8 = prefix }
//line :367:1
			NN(sb).Append_String__StringBuilder(tmp8)



			var tmp9 *String

			if nusLength < NN(nus).Length__I() { tmp9 = NN(nus).Substring_I_I__String(0, nusLength) } else { tmp9 = nus }
//line :371:1
			NN(sb).Append_String__StringBuilder(tmp9)


			var tmp10 *String
			if suffixLength < NN(suffix).Length__I() {
				tmp10 = NN(suffix).Substring_I_I__String(0, suffixLength) } else {
//line :375:1
					tmp10 = suffix }
//line :374:1
			NN(sb).Append_String__StringBuilder(tmp10)



			name = NN(sb).ToString__String() }
	var tmp11 FileSystem_I; File_Init(); tmp11 = File_FS; name = tmp11.Normalize_String__String(name)
	var f *File = File_New_File_String(dir, name); var tmp12 bool; var tmp13 bool
	tmp13 = !NN(name).Equals_O__Z(NN(f).GetName__String().Ref()); if !tmp13 { tmp13 = NN(f).IsInvalid__Z() }; tmp12 = tmp13; if tmp12 {
		panic(Thrown(IOException_New_String(Concat(Lit_80, name)))) }
//line :380:1
	return f
}



func File_CreateTempFile_String_String_File__File(prefix, suffix *String, directory *File) *File { File_Init()


	if NN(prefix).Length__I() < 3 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_72, prefix, Lit_73))))
	}
	if suffix == nil { suffix = Lit_74 }
	var tmpdir *File; if !(directory == nil) { tmpdir = directory } else { tmpdir = File_TempDirectory_Location__File() }; var f *File

L1: for {
	f = File_TempDirectory_GenerateFile_String_String_File__File(prefix, suffix, tmpdir)
	if File_FS.HasBooleanAttributes_File_I__Z(f, 1) { continue L1 }
//line :394:1
	break L1
}

	var tmp1 FileSystem_I = File_FS; if tmp1.CreateFileExclusively_String__Z(NN(f).GetPath__String()) { } else {
		panic(Thrown(IOException_New_String(Lit_75))) }
//line :392:1
	return f
}







func File_CreateTempFile_String_String__File(prefix, suffix *String) *File { File_Init()

	return File_CreateTempFile_String_String_File__File(prefix, suffix, nil)
}
func (t *File) CompareTo_File__I(pathname *File) int32 {
	return File_FS.Compare_File_File__I(t, pathname)
}
func (t *File) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if File_InstanceOf(tmp1) { var file *File = File_Cast(tmp1); return t.CompareTo_File__I(file) == 0 } else { return false
	} }
func (t *File) HashCode__I() int32 { return File_FS.HashCode_File__I(t) }

func (t *File) ToString__String() *String { return t.GetPath__String() }



type File struct{ Object; F_path *String; F_status *File_PathStatus; F_prefixLength int32; F_filePath Volatile[Path] }

func (t *File) Is_Serializable() {}

func (t *File) Is_Comparable() {}

var File_FS FileSystem_I

var File_separatorChar uint16

var File_separator *String

var File_pathSeparatorChar uint16

var File_pathSeparator *String

var File_UNSAFE *Unsafe

var File_PATH_OFFSET int64

var File_PREFIX_LENGTH_OFFSET int64

const File_serialVersionUID int64 = 301077366599181567

var File_init ClassInit

func File_Init() { if !File_init.Done() { File_init.Run(File_clinit) } }

func File_clinit() { File_FS = DefaultFileSystem_GetFileSystem__FileSystem(); File_separatorChar = File_FS.GetSeparator__C(); File_separator = String_ValueOf_C__String(File_separatorChar); File_pathSeparatorChar = File_FS.GetPathSeparator__C(); File_pathSeparator = String_ValueOf_C__String(File_pathSeparatorChar); File_UNSAFE = Unsafe_GetUnsafe__Unsafe(); File_PATH_OFFSET = NN(File_UNSAFE).ObjectFieldOffset_Class_String__J(File_class, Lit_57); File_PREFIX_LENGTH_OFFSET = NN(File_UNSAFE).ObjectFieldOffset_Class_String__J(File_class, Lit_58) }

func (t *File) CompareTo_O__I(p0 any) int32 { return t.CompareTo_File__I(File_Cast(p0)) }

func (t *File) Ref() any { if t == nil { return nil }; return t }

func (t *File) GetClass__Class() *Class { return File_class }

func (t *File) Clone__O() any { return A2g_ObjectClone(t) }

func (t *File) CloneShallow() any { panic(CloneNotSupported(t)) }

func File_InstanceOf(x any) bool { _, ok := x.(*File); return ok }

func File_Cast(x any) *File { if x == nil { return nil }; v, ok := x.(*File); if !ok { panic(ClassCast(x, File_class)) }; return v }



type File_PathStatus struct{ Enum }

func (t *File_PathStatus) Is_Constable() {}

var File_PathStatus_INVALID *File_PathStatus

var File_PathStatus_CHECKED *File_PathStatus

var File_PathStatus__VALUES *RefArray

var File_PathStatus_init ClassInit

func File_PathStatus_Init() { if !File_PathStatus_init.Done() { File_PathStatus_init.Run(File_PathStatus_clinit) } }

func File_PathStatus_clinit() { File_PathStatus_INVALID = File_PathStatus_New_String_I(Lit_76, 0); File_PathStatus_CHECKED = File_PathStatus_New_String_I(Lit_77, 1); File_PathStatus__VALUES = File_PathStatus_X_values__File_PathStatus1() }

func File_PathStatus_New_String_I(p0 *String, p1 int32) *File_PathStatus { File_PathStatus_Init(); t := &File_PathStatus{}; t.Ctor_String_I(p0, p1); return t }

func (t *File_PathStatus) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func File_PathStatus_Values__File_PathStatus1() *RefArray { File_PathStatus_Init(); return File_PathStatus__VALUES.Copy() }

func File_PathStatus_ValueOf_String__File_PathStatus(p0 *String) *File_PathStatus { File_PathStatus_Init(); return File_PathStatus_Cast(Enum_ValueOf_Class_String__Enum(File_PathStatus_class, p0)) }

func File_PathStatus_X_values__File_PathStatus1() *RefArray { File_PathStatus_Init(); return RefArrayOf(File_PathStatus_class, File_PathStatus_INVALID, File_PathStatus_CHECKED) }

func (t *File_PathStatus) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *File_PathStatus) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *File_PathStatus) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *File_PathStatus) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.io.File$PathStatus.describeConstable()Ljava/util/Optional;")) }

func (t *File_PathStatus) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *File_PathStatus) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *File_PathStatus) Ref() any { if t == nil { return nil }; return t }

func (t *File_PathStatus) GetClass__Class() *Class { return File_PathStatus_class }

func (t *File_PathStatus) CloneShallow() any { panic(CloneNotSupported(t)) }

func File_PathStatus_InstanceOf(x any) bool { _, ok := x.(*File_PathStatus); return ok }

func File_PathStatus_Cast(x any) *File_PathStatus { if x == nil { return nil }; v, ok := x.(*File_PathStatus); if !ok { panic(ClassCast(x, File_PathStatus_class)) }; return v }



type File_TempDirectory struct{ Object }

var File_TempDirectory_TMPDIR *File

var File_TempDirectory_RANDOM Random_I

var File_TempDirectory_init ClassInit

func File_TempDirectory_Init() { if !File_TempDirectory_init.Done() { File_TempDirectory_init.Run(File_TempDirectory_clinit) } }

func File_TempDirectory_clinit() { File_TempDirectory_TMPDIR = File_New_String(System_GetProperty_String__String(Lit_78)); File_TempDirectory_RANDOM = Random_New() }

func (t *File_TempDirectory) Ref() any { if t == nil { return nil }; return t }

func (t *File_TempDirectory) GetClass__Class() *Class { return File_TempDirectory_class }

func (t *File_TempDirectory) ToString__String() *String { return Object_toString(t) }

func (t *File_TempDirectory) Clone__O() any { return A2g_ObjectClone(t) }

func (t *File_TempDirectory) CloneShallow() any { panic(CloneNotSupported(t)) }

func File_TempDirectory_InstanceOf(x any) bool { _, ok := x.(*File_TempDirectory); return ok }

func File_TempDirectory_Cast(x any) *File_TempDirectory { if x == nil { return nil }; v, ok := x.(*File_TempDirectory); if !ok { panic(ClassCast(x, File_TempDirectory_class)) }; return v }
