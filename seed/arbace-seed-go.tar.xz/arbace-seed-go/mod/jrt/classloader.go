//line classloader.ae:1
package jrt







// ClassLoader_I is java.lang.ClassLoader's class interface.
type ClassLoader_I /*line :12:1*/ interface { Object_I
	Self_ClassLoader() *ClassLoader
	LoadClass_String__Class(name *String) *Class
	LoadClass_String_Z__Class(name *String, resolve bool) *Class
	GetParent__ClassLoader() ClassLoader_I
	GetName__String() *String }
// ClassLoader is java.lang.ClassLoader (abstract): a parent and a name.
type ClassLoader /*line :21:1*/ struct{ Object; parent ClassLoader_I; name *String }

var ClassLoader_class =
	Define(&ClassInfo{Name: "java.lang.ClassLoader", Kind: KindClass,
				Modifiers:                     AccPublic | AccAbstract, Super: Object_class, Go: "arbace/jrt.ClassLoader",
	})
// Ctor is ClassLoader(): the system class loader as parent.
func (t /*line :29:1*/*ClassLoader) Ctor(this ClassLoader_I) {
	t.parent = appLoader }
// Ctor_ClassLoader is ClassLoader(ClassLoader parent).
//line :31:1
func (t /*line :32:1*/*ClassLoader) Ctor_ClassLoader(this, parent ClassLoader_I) {
	t.parent = parent
}
func (t *ClassLoader) Self_ClassLoader() *ClassLoader { return t }
func (t *ClassLoader) GetParent__ClassLoader() ClassLoader_I { return t.parent }
func (t *ClassLoader) GetName__String() *String { return t.name }
// LoadClass_String__Class is ClassLoader.loadClass: the registry's class, not initialized;
// ClassNotFoundException otherwise.
//line :39:1
func (t /*line :42:1*/*ClassLoader) LoadClass_String__Class(name *String) *Class {
	return Class_ForName_String_Z_ClassLoader__Class(name, false, nil)
}
func (t /*line :46:1*/*ClassLoader) LoadClass_String_Z__Class(name *String, resolve bool/*line :45:1*/) *Class {

	return Class_ForName_String_Z_ClassLoader__Class(name, false, nil)
}
func ClassLoader_InstanceOf(x any) bool { _, ok := x.(ClassLoader_I); return ok }
func ClassLoader_Cast(x any) ClassLoader_I {
	if x == nil { return nil }
	v, ok := x.(ClassLoader_I)
	if !ok { panic(ClassCast(x, ClassLoader_class))
	}
	return v
}

type builtinLoader struct{ ClassLoader; cls *Class }
func (t *builtinLoader) Ref() any { if t == nil { return nil }; return t }
func (t *builtinLoader) GetClass__Class() *Class { return t.cls }
func (t *builtinLoader) ToString__String() *String { return Object_toString(t) }
func (t *builtinLoader) Clone__O() any { panic(CloneNotSupported(t)) }

var (

	builtinLoader_class = Define(&ClassInfo{Name: "jdk.internal.loader.BuiltinClassLoader", Kind: KindClass, Modifiers: AccPublic, Super: ClassLoader_class, Go: "arbace/jrt.builtinLoader"})


	platformLoader_class = Define(&ClassInfo{Name: "jdk.internal.loader.ClassLoaders$PlatformClassLoader", Kind: KindClass,
				Modifiers:                AccPrivate | AccStatic, Super:                                builtinLoader_class,
	},
	); appLoader_class = Define(&ClassInfo{Name: "jdk.internal.loader.ClassLoaders$AppClassLoader", Kind: KindClass,
				Modifiers:                AccPrivate | AccStatic, Super:                           builtinLoader_class,
	}))
var (

	platformLoader /*line :76:1*/*builtinLoader =
	&builtinLoader{ClassLoader: ClassLoader{name: Intern("platform")}, cls: platformLoader_class}

	appLoader /*line :78:1*/*builtinLoader =
	&builtinLoader{ClassLoader: ClassLoader{parent: platformLoader, name: Intern("app")}, cls: appLoader_class})
// ClassLoader_GetSystemClassLoader__ClassLoader is ClassLoader.getSystemClassLoader: the
// application loader.
func ClassLoader_GetSystemClassLoader__ClassLoader() ClassLoader_I { return appLoader }





func ClassLoader_GetPlatformClassLoader__ClassLoader() ClassLoader_I { return platformLoader }



// Utils_CheckNonNegativeArgument_J_String__V is jdk.internal.foreign.Utils.
// checkNonNegativeArgument: IllegalArgumentException("The provided NAME is negative: V").
func Utils_CheckNonNegativeArgument_J_String__V(value int64, name /*line :97:1*/*String) {
	if value < 0 {
		panic(IllegalArgumentException_New_String(
			Concat(Str("The provided "), name, Str(" is negative: "), StrOfLong(value)),
		),
		)
	}
}
