//line java_time_format_ZoneName.ae:1
package jrt






func ZoneName_ToZid_String_Locale__String(zid *String, locale *Locale) *String { ZoneName_Init()
	var mzone *String = String_Cast(ZoneName_zidToMzone.Get_O__O(zid.Ref()))
	if mzone == nil {
		var alias *String = String_Cast(ZoneName_aliases.Get_O__O(zid.Ref()))
		if !(alias == nil) { zid = alias; mzone = String_Cast(ZoneName_zidToMzone.Get_O__O(zid.Ref())) } }
	if !(mzone == nil) {
		var map_ Map = Map_Cast(ZoneName_mzoneToZidL.Get_O__O(mzone.Ref())); var tmp1 bool; var tmp2 bool
		tmp2 = map_ == nil; if !tmp2 { var tmp3 *String; zid = String_Cast(map_.Get_O__O(NN(locale).GetCountry__String().Ref())); tmp3 = zid; tmp2 = tmp3 == nil }; tmp1 = tmp2; if tmp1 {
			zid = String_Cast(ZoneName_mzoneToZid.Get_O__O(mzone.Ref())) } }
	return ZoneName_ToZid_String__String(zid)
}
func ZoneName_ToZid_String__String(zid *String) *String { ZoneName_Init()
	return String_Cast(ZoneName_aliases.GetOrDefault_O_O__O(zid.Ref(), zid.Ref()))
}


type ZoneName struct{ Object }

var ZoneName_zidMap *RefArray

var ZoneName_mzoneMap *RefArray

var ZoneName_aliasMap *RefArray

var ZoneName_zidToMzone Map

var ZoneName_mzoneToZid Map

var ZoneName_mzoneToZidL Map

var ZoneName_aliases Map

var ZoneName_init ClassInit

func ZoneName_Init() { if !ZoneName_init.Done() { ZoneName_init.Run(ZoneName_clinit) } }

func ZoneName_clinit() { ZoneName_zidMap = ConstRefArray("[0,1665,s14:Africa/Abidjans3:GMTs18:Atlantic/Reykjaviks12:Africa/Accras3:GMTs18:Atlantic/Reykjaviks18:Africa/Addis_Ababas14:Africa_Easterns14:Africa/Nairobis14:Africa/Algierss14:Europe_Centrals12:Europe/Pariss13:Africa/Asmaras14:Africa_Easterns14:Africa/Nairobis13:Africa/Asmeras14:Africa_Easterns14:Africa/Nairobis13:Africa/Bamakos3:GMTs18:Atlantic/Reykjaviks13:Africa/Banguis14:Africa_Westerns12:Africa/Lagoss13:Africa/Banjuls3:GMTs18:Atlantic/Reykjaviks13:Africa/Bissaus3:GMTs18:Atlantic/Reykjaviks15:Africa/Blantyres14:Africa_Centrals13:Africa/Maputos18:Africa/Brazzavilles14:Africa_Westerns12:Africa/Lagoss16:Africa/Bujumburas14:Africa_Centrals13:Africa/Maputos12:Africa/Cairos14:Europe_Easterns16:Europe/Bucharests12:Africa/Ceutas14:Europe_Centrals12:Europe/Pariss14:Africa/Conakrys3:GMTs18:Atlantic/Reykjaviks12:Africa/Dakars3:GMTs18:Atlantic/Reykjaviks20:Africa/Dar_es_Salaams14:Africa_Easterns14:Africa/Nairobis15:Africa/Djiboutis14:Africa_Easterns14:Africa/Nairobis13:Africa/Doualas14:Africa_Westerns12:Africa/Lagoss15:Africa/Freetowns3:GMTs18:Atlantic/Reykjaviks15:Africa/Gaborones14:Africa_Centrals13:Africa/Maputos13:Africa/Harares14:Africa_Centrals13:Africa/Maputos19:Africa/Johannesburgs15:Africa_Southerns19:Africa/Johannesburgs11:Africa/Jubas14:Africa_Centrals13:Africa/Maputos14:Africa/Kampalas14:Africa_Easterns14:Africa/Nairobis15:Africa/Khartoums14:Africa_Centrals13:Africa/Maputos13:Africa/Kigalis14:Africa_Centrals13:Africa/Maputos15:Africa/Kinshasas14:Africa_Westerns12:Africa/Lagoss12:Africa/Lagoss14:Africa_Westerns12:Africa/Lagoss17:Africa/Librevilles14:Africa_Westerns12:Africa/Lagoss11:Africa/Lomes3:GMTs18:Atlantic/Reykjaviks13:Africa/Luandas14:Africa_Westerns12:Africa/Lagoss17:Africa/Lubumbashis14:Africa_Centrals13:Africa/Maputos13:Africa/Lusakas14:Africa_Centrals13:Africa/Maputos13:Africa/Malabos14:Africa_Westerns12:Africa/Lagoss13:Africa/Maputos14:Africa_Centrals13:Africa/Maputos13:Africa/Maserus15:Africa_Southerns19:Africa/Johannesburgs14:Africa/Mbabanes15:Africa_Southerns19:Africa/Johannesburgs16:Africa/Mogadishus14:Africa_Easterns14:Africa/Nairobis15:Africa/Monrovias3:GMTs18:Atlantic/Reykjaviks14:Africa/Nairobis14:Africa_Easterns14:Africa/Nairobis15:Africa/Ndjamenas14:Africa_Westerns12:Africa/Lagoss13:Africa/Niameys14:Africa_Westerns12:Africa/Lagoss17:Africa/Nouakchotts3:GMTs18:Atlantic/Reykjaviks18:Africa/Ouagadougous3:GMTs18:Atlantic/Reykjaviks17:Africa/Porto-Novos14:Africa_Westerns12:Africa/Lagoss15:Africa/Sao_Tomes3:GMTs18:Atlantic/Reykjaviks15:Africa/Timbuktus3:GMTs18:Atlantic/Reykjaviks14:Africa/Tripolis14:Europe_Easterns16:Europe/Bucharests12:Africa/Tuniss14:Europe_Centrals12:Europe/Pariss15:Africa/Windhoeks14:Africa_Centrals13:Africa/Maputos12:America/Adaks15:Hawaii_Aleutians12:America/Adaks17:America/Anchorages6:Alaskas14:America/Juneaus16:America/Anguillas8:Atlantics15:America/Halifaxs15:America/Antiguas8:Atlantics15:America/Halifaxs17:America/Araguainas8:Brasilias17:America/Sao_Paulos30:America/Argentina/Buenos_Airess9:Argentinas20:America/Buenos_Airess27:America/Argentina/Catamarcas9:Argentinas20:America/Buenos_Airess32:America/Argentina/ComodRivadavias9:Argentinas20:America/Buenos_Airess25:America/Argentina/Cordobas9:Argentinas20:America/Buenos_Airess23:America/Argentina/Jujuys9:Argentinas20:America/Buenos_Airess26:America/Argentina/La_Riojas9:Argentinas20:America/Buenos_Airess25:America/Argentina/Mendozas9:Argentinas20:America/Buenos_Airess30:America/Argentina/Rio_Gallegoss9:Argentinas20:America/Buenos_Airess23:America/Argentina/Saltas9:Argentinas20:America/Buenos_Airess26:America/Argentina/San_Juans9:Argentinas20:America/Buenos_Airess26:America/Argentina/San_Luiss9:Argentinas20:America/Buenos_Airess25:America/Argentina/Tucumans9:Argentinas20:America/Buenos_Airess25:America/Argentina/Ushuaias9:Argentinas20:America/Buenos_Airess13:America/Arubas8:Atlantics15:America/Halifaxs16:America/Asuncions8:Paraguays16:America/Asuncions16:America/Atikokans15:America_Easterns16:America/New_Yorks12:America/Atkas15:Hawaii_Aleutians12:America/Adaks13:America/Bahias8:Brasilias17:America/Sao_Paulos22:America/Bahia_Banderass15:America_Centrals15:America/Chicagos16:America/Barbadoss8:Atlantics15:America/Halifaxs13:America/Belems8:Brasilias17:America/Sao_Paulos14:America/Belizes15:America_Centrals15:America/Chicagos20:America/Blanc-Sablons8:Atlantics15:America/Halifaxs17:America/Boa_Vistas6:Amazons14:America/Manauss14:America/Bogotas8:Colombias14:America/Bogotas13:America/Boises16:America_Mountains14:America/Denvers20:America/Buenos_Airess9:Argentinas20:America/Buenos_Airess21:America/Cambridge_Bays16:America_Mountains14:America/Denvers20:America/Campo_Grandes6:Amazons14:America/Manauss14:America/Cancuns15:America_Easterns16:America/New_Yorks15:America/Caracass9:Venezuelas15:America/Caracass17:America/Catamarcas9:Argentinas20:America/Buenos_Airess15:America/Cayennes13:French_Guianas15:America/Cayennes14:America/Caymans15:America_Easterns16:America/New_Yorks15:America/Chicagos15:America_Centrals15:America/Chicagos17:America/Chihuahuas15:America_Centrals15:America/Chicagos21:America/Ciudad_Juarezs16:America_Mountains14:America/Denvers21:America/Coral_Harbours15:America_Easterns16:America/New_Yorks15:America/Cordobas9:Argentinas20:America/Buenos_Airess18:America/Costa_Ricas15:America_Centrals15:America/Chicagos15:America/Crestons16:America_Mountains14:America/Denvers14:America/Cuiabas6:Amazons14:America/Manauss15:America/Curacaos8:Atlantics15:America/Halifaxs20:America/Danmarkshavns3:GMTs18:Atlantic/Reykjaviks14:America/Dawsons5:Yukons18:America/Whitehorses20:America/Dawson_Creeks16:America_Mountains14:America/Denvers14:America/Denvers16:America_Mountains14:America/Denvers15:America/Detroits15:America_Easterns16:America/New_Yorks16:America/Dominicas8:Atlantics15:America/Halifaxs16:America/Edmontons16:America_Mountains14:America/Denvers16:America/Eirunepes4:Acres18:America/Rio_Brancos19:America/El_Salvadors15:America_Centrals15:America/Chicagos16:America/Ensenadas15:America_Pacifics19:America/Los_Angeless19:America/Fort_Nelsons16:America_Mountains14:America/Denvers18:America/Fort_Waynes15:America_Easterns16:America/New_Yorks17:America/Fortalezas8:Brasilias17:America/Sao_Paulos17:America/Glace_Bays8:Atlantics15:America/Halifaxs15:America/Godthabs9:Greenlands15:America/Godthabs17:America/Goose_Bays8:Atlantics15:America/Halifaxs18:America/Grand_Turks15:America_Easterns16:America/New_Yorks15:America/Grenadas8:Atlantics15:America/Halifaxs18:America/Guadeloupes8:Atlantics15:America/Halifaxs17:America/Guatemalas15:America_Centrals15:America/Chicagos17:America/Guayaquils7:Ecuadors17:America/Guayaquils14:America/Guyanas6:Guyanas14:America/Guyanas15:America/Halifaxs8:Atlantics15:America/Halifaxs14:America/Havanas4:Cubas14:America/Havanas18:America/Hermosillos14:Mexico_Pacifics16:America/Mazatlans28:America/Indiana/Indianapoliss15:America_Easterns16:America/New_Yorks20:America/Indiana/Knoxs15:America_Centrals15:America/Chicagos23:America/Indiana/Marengos15:America_Easterns16:America/New_Yorks26:America/Indiana/Petersburgs15:America_Easterns16:America/New_Yorks25:America/Indiana/Tell_Citys15:America_Centrals15:America/Chicagos21:America/Indiana/Vevays15:America_Easterns16:America/New_Yorks25:America/Indiana/Vincenness15:America_Easterns16:America/New_Yorks23:America/Indiana/Winamacs15:America_Easterns16:America/New_Yorks20:America/Indianapoliss15:America_Easterns16:America/New_Yorks14:America/Inuviks16:America_Mountains14:America/Denvers15:America/Iqaluits15:America_Easterns16:America/New_Yorks15:America/Jamaicas15:America_Easterns16:America/New_Yorks13:America/Jujuys9:Argentinas20:America/Buenos_Airess14:America/Juneaus6:Alaskas14:America/Juneaus27:America/Kentucky/Louisvilles15:America_Easterns16:America/New_Yorks27:America/Kentucky/Monticellos15:America_Easterns16:America/New_Yorks15:America/Knox_INs15:America_Centrals15:America/Chicagos18:America/Kralendijks8:Atlantics15:America/Halifaxs14:America/La_Pazs7:Bolivias14:America/La_Pazs12:America/Limas4:Perus12:America/Limas19:America/Los_Angeless15:America_Pacifics19:America/Los_Angeless18:America/Louisvilles15:America_Easterns16:America/New_Yorks21:America/Lower_Princess8:Atlantics15:America/Halifaxs14:America/Maceios8:Brasilias17:America/Sao_Paulos15:America/Managuas15:America_Centrals15:America/Chicagos14:America/Manauss6:Amazons14:America/Manauss15:America/Marigots8:Atlantics15:America/Halifaxs18:America/Martiniques8:Atlantics15:America/Halifaxs17:America/Matamoross15:America_Centrals15:America/Chicagos16:America/Mazatlans14:Mexico_Pacifics16:America/Mazatlans15:America/Mendozas9:Argentinas20:America/Buenos_Airess17:America/Menominees15:America_Centrals15:America/Chicagos14:America/Meridas15:America_Centrals15:America/Chicagos18:America/Metlakatlas6:Alaskas14:America/Juneaus19:America/Mexico_Citys15:America_Centrals15:America/Chicagos16:America/Miquelons15:Pierre_Miquelons16:America/Miquelons15:America/Monctons8:Atlantics15:America/Halifaxs17:America/Monterreys15:America_Centrals15:America/Chicagos18:America/Montevideos7:Uruguays18:America/Montevideos16:America/Montreals15:America_Easterns16:America/New_Yorks18:America/Montserrats8:Atlantics15:America/Halifaxs14:America/Nassaus15:America_Easterns16:America/New_Yorks16:America/New_Yorks15:America_Easterns16:America/New_Yorks15:America/Nipigons15:America_Easterns16:America/New_Yorks12:America/Nomes6:Alaskas14:America/Juneaus15:America/Noronhas7:Noronhas15:America/Noronhas27:America/North_Dakota/Beulahs15:America_Centrals15:America/Chicagos27:America/North_Dakota/Centers15:America_Centrals15:America/Chicagos30:America/North_Dakota/New_Salems15:America_Centrals15:America/Chicagos12:America/Nuuks9:Greenlands15:America/Godthabs15:America/Ojinagas15:America_Centrals15:America/Chicagos14:America/Panamas15:America_Easterns16:America/New_Yorks19:America/Pangnirtungs15:America_Easterns16:America/New_Yorks18:America/Paramaribos8:Surinames18:America/Paramaribos15:America/Phoenixs16:America_Mountains14:America/Denvers22:America/Port-au-Princes15:America_Easterns16:America/New_Yorks21:America/Port_of_Spains8:Atlantics15:America/Halifaxs18:America/Porto_Acres4:Acres18:America/Rio_Brancos19:America/Porto_Velhos6:Amazons14:America/Manauss19:America/Puerto_Ricos8:Atlantics15:America/Halifaxs19:America/Rainy_Rivers15:America_Centrals15:America/Chicagos20:America/Rankin_Inlets15:America_Centrals15:America/Chicagos14:America/Recifes8:Brasilias17:America/Sao_Paulos14:America/Reginas15:America_Centrals15:America/Chicagos16:America/Resolutes15:America_Centrals15:America/Chicagos18:America/Rio_Brancos4:Acres18:America/Rio_Brancos15:America/Rosarios9:Argentinas20:America/Buenos_Airess20:America/Santa_Isabels15:America_Pacifics19:America/Los_Angeless16:America/Santarems8:Brasilias17:America/Sao_Paulos16:America/Santiagos5:Chiles16:America/Santiagos21:America/Santo_Domingos8:Atlantics15:America/Halifaxs17:America/Sao_Paulos8:Brasilias17:America/Sao_Paulos20:America/Scoresbysunds9:Greenlands15:America/Godthabs16:America/Shiprocks16:America_Mountains14:America/Denvers13:America/Sitkas6:Alaskas14:America/Juneaus21:America/St_Barthelemys8:Atlantics15:America/Halifaxs16:America/St_Johnss12:Newfoundlands16:America/St_Johnss16:America/St_Kittss8:Atlantics15:America/Halifaxs16:America/St_Lucias8:Atlantics15:America/Halifaxs17:America/St_Thomass8:Atlantics15:America/Halifaxs18:America/St_Vincents8:Atlantics15:America/Halifaxs21:America/Swift_Currents15:America_Centrals15:America/Chicagos19:America/Tegucigalpas15:America_Centrals15:America/Chicagos13:America/Thules8:Atlantics15:America/Halifaxs19:America/Thunder_Bays15:America_Easterns16:America/New_Yorks15:America/Tijuanas15:America_Pacifics19:America/Los_Angeless15:America/Torontos15:America_Easterns16:America/New_Yorks15:America/Tortolas8:Atlantics15:America/Halifaxs17:America/Vancouvers15:America_Pacifics19:America/Los_Angeless14:America/Virgins8:Atlantics15:America/Halifaxs18:America/Whitehorses5:Yukons18:America/Whitehorses16:America/Winnipegs15:America_Centrals15:America/Chicagos15:America/Yakutats6:Alaskas14:America/Juneaus19:America/Yellowknifes16:America_Mountains14:America/Denvers16:Antarctica/Caseys17:Australia_Westerns15:Australia/Perths16:Antarctica/Daviss5:Daviss16:Antarctica/Daviss25:Antarctica/DumontDUrvilles14:DumontDUrvilles25:Antarctica/DumontDUrvilles20:Antarctica/Macquaries17:Australia_Easterns16:Australia/Sydneys17:Antarctica/Mawsons6:Mawsons17:Antarctica/Mawsons18:Antarctica/McMurdos11:New_Zealands16:Pacific/Aucklands18:Antarctica/Rotheras7:Rotheras18:Antarctica/Rotheras21:Antarctica/South_Poles11:New_Zealands16:Pacific/Aucklands16:Antarctica/Syowas5:Syowas16:Antarctica/Syowas16:Antarctica/Trolls3:GMTs18:Atlantic/Reykjaviks17:Antarctica/Vostoks6:Vostoks17:Antarctica/Vostoks19:Arctic/Longyearbyens14:Europe_Centrals12:Europe/Pariss9:Asia/Adens7:Arabians11:Asia/Riyadhs11:Asia/Almatys10:Kazakhstans11:Asia/Almatys11:Asia/Anadyrs9:Kamchatkas14:Asia/Kamchatkas10:Asia/Aqtaus10:Kazakhstans11:Asia/Almatys11:Asia/Aqtobes10:Kazakhstans11:Asia/Almatys13:Asia/Ashgabats12:Turkmenistans13:Asia/Ashgabats14:Asia/Ashkhabads12:Turkmenistans13:Asia/Ashgabats11:Asia/Atyraus10:Kazakhstans11:Asia/Almatys12:Asia/Baghdads7:Arabians11:Asia/Riyadhs12:Asia/Bahrains7:Arabians11:Asia/Riyadhs9:Asia/Bakus10:Azerbaijans9:Asia/Bakus12:Asia/Bangkoks9:Indochinas12:Asia/Bangkoks12:Asia/Barnauls11:Krasnoyarsks16:Asia/Krasnoyarsks11:Asia/Beiruts14:Europe_Easterns16:Europe/Bucharests12:Asia/Bishkeks9:Kyrgystans12:Asia/Bishkeks11:Asia/Bruneis6:Bruneis11:Asia/Bruneis13:Asia/Calcuttas5:Indias13:Asia/Calcuttas10:Asia/Chitas7:Yakutsks12:Asia/Yakutsks15:Asia/Choibalsans8:Mongolias16:Asia/Ulaanbaatars14:Asia/Chongqings5:Chinas13:Asia/Shanghais14:Asia/Chungkings5:Chinas13:Asia/Shanghais12:Asia/Colombos5:Indias13:Asia/Calcuttas10:Asia/Daccas10:Bangladeshs10:Asia/Dhakas10:Asia/Dhakas10:Bangladeshs10:Asia/Dhakas9:Asia/Dilis10:East_Timors9:Asia/Dilis10:Asia/Dubais4:Gulfs10:Asia/Dubais13:Asia/Dushanbes10:Tajikistans13:Asia/Dushanbes14:Asia/Famagustas14:Europe_Easterns16:Europe/Bucharests9:Asia/Gazas14:Europe_Easterns16:Europe/Bucharests11:Asia/Harbins5:Chinas13:Asia/Shanghais11:Asia/Hebrons14:Europe_Easterns16:Europe/Bucharests16:Asia/Ho_Chi_Minhs9:Indochinas12:Asia/Bangkoks14:Asia/Hong_Kongs9:Hong_Kongs14:Asia/Hong_Kongs9:Asia/Hovds4:Hovds9:Asia/Hovds12:Asia/Irkutsks7:Irkutsks12:Asia/Irkutsks13:Asia/Istanbuls6:Turkeys15:Europe/Istanbuls12:Asia/Jakartas17:Indonesia_Westerns12:Asia/Jakartas13:Asia/Jayapuras17:Indonesia_Easterns13:Asia/Jayapuras14:Asia/Jerusalems6:Israels14:Asia/Jerusalems10:Asia/Kabuls11:Afghanistans10:Asia/Kabuls14:Asia/Kamchatkas9:Kamchatkas14:Asia/Kamchatkas12:Asia/Karachis8:Pakistans12:Asia/Karachis12:Asia/Kashgars6:Urumqis11:Asia/Urumqis14:Asia/Kathmandus5:Nepals13:Asia/Katmandus13:Asia/Katmandus5:Nepals13:Asia/Katmandus13:Asia/Khandygas7:Yakutsks12:Asia/Yakutsks12:Asia/Kolkatas5:Indias13:Asia/Calcuttas16:Asia/Krasnoyarsks11:Krasnoyarsks16:Asia/Krasnoyarsks17:Asia/Kuala_Lumpurs8:Malaysias12:Asia/Kuchings12:Asia/Kuchings8:Malaysias12:Asia/Kuchings11:Asia/Kuwaits7:Arabians11:Asia/Riyadhs10:Asia/Macaos5:Chinas13:Asia/Shanghais10:Asia/Macaus5:Chinas13:Asia/Shanghais12:Asia/Magadans7:Magadans12:Asia/Magadans13:Asia/Makassars17:Indonesia_Centrals13:Asia/Makassars11:Asia/Manilas11:Philippiness11:Asia/Manilas11:Asia/Muscats4:Gulfs10:Asia/Dubais12:Asia/Nicosias14:Europe_Easterns16:Europe/Bucharests17:Asia/Novokuznetsks11:Krasnoyarsks16:Asia/Krasnoyarsks16:Asia/Novosibirsks11:Krasnoyarsks16:Asia/Krasnoyarsks9:Asia/Omsks4:Omsks9:Asia/Omsks9:Asia/Orals10:Kazakhstans11:Asia/Almatys15:Asia/Phnom_Penhs9:Indochinas12:Asia/Bangkoks14:Asia/Pontianaks17:Indonesia_Westerns12:Asia/Jakartas14:Asia/Pyongyangs5:Koreas10:Asia/Seouls10:Asia/Qatars7:Arabians11:Asia/Riyadhs13:Asia/Qostanays10:Kazakhstans11:Asia/Almatys14:Asia/Qyzylordas10:Kazakhstans11:Asia/Almatys12:Asia/Rangoons7:Myanmars12:Asia/Rangoons11:Asia/Riyadhs7:Arabians11:Asia/Riyadhs11:Asia/Saigons9:Indochinas12:Asia/Bangkoks13:Asia/Sakhalins7:Magadans12:Asia/Magadans14:Asia/Samarkands10:Uzbekistans13:Asia/Tashkents10:Asia/Seouls5:Koreas10:Asia/Seouls13:Asia/Shanghais5:Chinas13:Asia/Shanghais14:Asia/Singapores9:Singapores14:Asia/Singapores18:Asia/Srednekolymsks7:Magadans12:Asia/Magadans11:Asia/Taipeis6:Taipeis11:Asia/Taipeis13:Asia/Tashkents10:Uzbekistans13:Asia/Tashkents12:Asia/Tbilisis7:Georgias12:Asia/Tbilisis11:Asia/Tehrans4:Irans11:Asia/Tehrans13:Asia/Tel_Avivs6:Israels14:Asia/Jerusalems11:Asia/Thimbus6:Bhutans12:Asia/Thimphus12:Asia/Thimphus6:Bhutans12:Asia/Thimphus10:Asia/Tokyos5:Japans10:Asia/Tokyos10:Asia/Tomsks11:Krasnoyarsks16:Asia/Krasnoyarsks18:Asia/Ujung_Pandangs17:Indonesia_Centrals13:Asia/Makassars16:Asia/Ulaanbaatars8:Mongolias16:Asia/Ulaanbaatars15:Asia/Ulan_Bators8:Mongolias16:Asia/Ulaanbaatars11:Asia/Urumqis6:Urumqis11:Asia/Urumqis13:Asia/Ust-Neras11:Vladivostoks16:Asia/Vladivostoks14:Asia/Vientianes9:Indochinas12:Asia/Bangkoks16:Asia/Vladivostoks11:Vladivostoks16:Asia/Vladivostoks12:Asia/Yakutsks7:Yakutsks12:Asia/Yakutsks11:Asia/Yangons7:Myanmars12:Asia/Rangoons18:Asia/Yekaterinburgs13:Yekaterinburgs18:Asia/Yekaterinburgs12:Asia/Yerevans7:Armenias12:Asia/Yerevans15:Atlantic/Azoress6:Azoress15:Atlantic/Azoress16:Atlantic/Bermudas8:Atlantics15:America/Halifaxs15:Atlantic/Canarys14:Europe_Westerns15:Atlantic/Canarys19:Atlantic/Cape_Verdes10:Cape_Verdes19:Atlantic/Cape_Verdes15:Atlantic/Faeroes14:Europe_Westerns15:Atlantic/Canarys14:Atlantic/Faroes14:Europe_Westerns15:Atlantic/Canarys18:Atlantic/Jan_Mayens14:Europe_Centrals12:Europe/Pariss16:Atlantic/Madeiras14:Europe_Westerns15:Atlantic/Canarys18:Atlantic/Reykjaviks3:GMTs18:Atlantic/Reykjaviks22:Atlantic/South_Georgias13:South_Georgias22:Atlantic/South_Georgias18:Atlantic/St_Helenas3:GMTs18:Atlantic/Reykjaviks16:Atlantic/Stanleys8:Falklands16:Atlantic/Stanleys13:Australia/ACTs17:Australia_Easterns16:Australia/Sydneys18:Australia/Adelaides17:Australia_Centrals18:Australia/Adelaides18:Australia/Brisbanes17:Australia_Easterns16:Australia/Sydneys21:Australia/Broken_Hills17:Australia_Centrals18:Australia/Adelaides18:Australia/Canberras17:Australia_Easterns16:Australia/Sydneys16:Australia/Curries17:Australia_Easterns16:Australia/Sydneys16:Australia/Darwins17:Australia_Centrals18:Australia/Adelaides15:Australia/Euclas24:Australia_CentralWesterns15:Australia/Euclas16:Australia/Hobarts17:Australia_Easterns16:Australia/Sydneys13:Australia/LHIs9:Lord_Howes19:Australia/Lord_Howes18:Australia/Lindemans17:Australia_Easterns16:Australia/Sydneys19:Australia/Lord_Howes9:Lord_Howes19:Australia/Lord_Howes19:Australia/Melbournes17:Australia_Easterns16:Australia/Sydneys13:Australia/NSWs17:Australia_Easterns16:Australia/Sydneys15:Australia/Norths17:Australia_Centrals18:Australia/Adelaides15:Australia/Perths17:Australia_Westerns15:Australia/Perths20:Australia/Queenslands17:Australia_Easterns16:Australia/Sydneys15:Australia/Souths17:Australia_Centrals18:Australia/Adelaides16:Australia/Sydneys17:Australia_Easterns16:Australia/Sydneys18:Australia/Tasmanias17:Australia_Easterns16:Australia/Sydneys18:Australia/Victorias17:Australia_Easterns16:Australia/Sydneys14:Australia/Wests17:Australia_Westerns15:Australia/Perths20:Australia/Yancowinnas17:Australia_Centrals18:Australia/Adelaides11:Brazil/Acres4:Acres18:America/Rio_Brancos16:Brazil/DeNoronhas7:Noronhas15:America/Noronhas11:Brazil/Easts8:Brasilias17:America/Sao_Paulos11:Brazil/Wests6:Amazons14:America/Manauss3:CETs14:Europe_Centrals12:Europe/Pariss7:CST6CDTs15:America_Centrals15:America/Chicagos15:Canada/Atlantics8:Atlantics15:America/Halifaxs14:Canada/Centrals15:America_Centrals15:America/Chicagos14:Canada/Easterns15:America_Easterns16:America/New_Yorks15:Canada/Mountains16:America_Mountains14:America/Denvers19:Canada/Newfoundlands12:Newfoundlands16:America/St_Johnss14:Canada/Pacifics15:America_Pacifics19:America/Los_Angeless19:Canada/Saskatchewans15:America_Centrals15:America/Chicagos12:Canada/Yukons5:Yukons18:America/Whitehorses17:Chile/Continentals5:Chiles16:America/Santiagos18:Chile/EasterIslands6:Easters14:Pacific/Easters4:Cubas4:Cubas14:America/Havanas3:EETs14:Europe_Easterns16:Europe/Bucharests3:ESTs15:America_Easterns16:America/New_Yorks7:EST5EDTs15:America_Easterns16:America/New_Yorks5:Egypts14:Europe_Easterns16:Europe/Bucharests4:Eires3:GMTs18:Atlantic/Reykjaviks7:Etc/GMTs3:GMTs18:Atlantic/Reykjaviks9:Etc/GMT+0s3:GMTs18:Atlantic/Reykjaviks9:Etc/GMT-0s3:GMTs18:Atlantic/Reykjaviks8:Etc/GMT0s3:GMTs18:Atlantic/Reykjaviks13:Etc/Greenwichs3:GMTs18:Atlantic/Reykjaviks16:Europe/Amsterdams14:Europe_Centrals12:Europe/Pariss14:Europe/Andorras14:Europe_Centrals12:Europe/Pariss16:Europe/Astrakhans6:Samaras13:Europe/Samaras13:Europe/Athenss14:Europe_Easterns16:Europe/Bucharests14:Europe/Belfasts3:GMTs18:Atlantic/Reykjaviks15:Europe/Belgrades14:Europe_Centrals12:Europe/Pariss13:Europe/Berlins14:Europe_Centrals12:Europe/Pariss17:Europe/Bratislavas14:Europe_Centrals12:Europe/Pariss15:Europe/Brusselss14:Europe_Centrals12:Europe/Pariss16:Europe/Bucharests14:Europe_Easterns16:Europe/Bucharests15:Europe/Budapests14:Europe_Centrals12:Europe/Pariss15:Europe/Busingens14:Europe_Centrals12:Europe/Pariss15:Europe/Chisinaus14:Europe_Easterns16:Europe/Bucharests17:Europe/Copenhagens14:Europe_Centrals12:Europe/Pariss13:Europe/Dublins3:GMTs18:Atlantic/Reykjaviks16:Europe/Gibraltars14:Europe_Centrals12:Europe/Pariss15:Europe/Guernseys3:GMTs18:Atlantic/Reykjaviks15:Europe/Helsinkis14:Europe_Easterns16:Europe/Bucharests18:Europe/Isle_of_Mans3:GMTs18:Atlantic/Reykjaviks15:Europe/Istanbuls6:Turkeys15:Europe/Istanbuls13:Europe/Jerseys3:GMTs18:Atlantic/Reykjaviks18:Europe/Kaliningrads14:Europe_Easterns16:Europe/Bucharests11:Europe/Kievs14:Europe_Easterns16:Europe/Bucharests12:Europe/Kirovs6:Moscows13:Europe/Moscows11:Europe/Kyivs14:Europe_Easterns16:Europe/Bucharests13:Europe/Lisbons14:Europe_Westerns15:Atlantic/Canarys16:Europe/Ljubljanas14:Europe_Centrals12:Europe/Pariss13:Europe/Londons3:GMTs18:Atlantic/Reykjaviks17:Europe/Luxembourgs14:Europe_Centrals12:Europe/Pariss13:Europe/Madrids14:Europe_Centrals12:Europe/Pariss12:Europe/Maltas14:Europe_Centrals12:Europe/Pariss16:Europe/Mariehamns14:Europe_Easterns16:Europe/Bucharests12:Europe/Minsks6:Moscows13:Europe/Moscows13:Europe/Monacos14:Europe_Centrals12:Europe/Pariss13:Europe/Moscows6:Moscows13:Europe/Moscows14:Europe/Nicosias14:Europe_Easterns16:Europe/Bucharests11:Europe/Oslos14:Europe_Centrals12:Europe/Pariss12:Europe/Pariss14:Europe_Centrals12:Europe/Pariss16:Europe/Podgoricas14:Europe_Centrals12:Europe/Pariss13:Europe/Pragues14:Europe_Centrals12:Europe/Pariss11:Europe/Rigas14:Europe_Easterns16:Europe/Bucharests11:Europe/Romes14:Europe_Centrals12:Europe/Pariss13:Europe/Samaras6:Samaras13:Europe/Samaras17:Europe/San_Marinos14:Europe_Centrals12:Europe/Pariss15:Europe/Sarajevos14:Europe_Centrals12:Europe/Pariss14:Europe/Saratovs6:Samaras13:Europe/Samaras17:Europe/Simferopols6:Moscows13:Europe/Moscows13:Europe/Skopjes14:Europe_Centrals12:Europe/Pariss12:Europe/Sofias14:Europe_Easterns16:Europe/Bucharests16:Europe/Stockholms14:Europe_Centrals12:Europe/Pariss14:Europe/Tallinns14:Europe_Easterns16:Europe/Bucharests13:Europe/Tiranes14:Europe_Centrals12:Europe/Pariss15:Europe/Tiraspols14:Europe_Easterns16:Europe/Bucharests16:Europe/Ulyanovsks6:Samaras13:Europe/Samaras15:Europe/Uzhgorods14:Europe_Easterns16:Europe/Bucharests12:Europe/Vaduzs14:Europe_Centrals12:Europe/Pariss14:Europe/Vaticans14:Europe_Centrals12:Europe/Pariss13:Europe/Viennas14:Europe_Centrals12:Europe/Pariss14:Europe/Vilniuss14:Europe_Easterns16:Europe/Bucharests16:Europe/Volgograds6:Moscows13:Europe/Moscows13:Europe/Warsaws14:Europe_Centrals12:Europe/Pariss13:Europe/Zagrebs14:Europe_Centrals12:Europe/Pariss17:Europe/Zaporozhyes14:Europe_Easterns16:Europe/Bucharests13:Europe/Zurichs14:Europe_Centrals12:Europe/Pariss2:GBs3:GMTs18:Atlantic/Reykjaviks7:GB-Eires3:GMTs18:Atlantic/Reykjaviks3:GMTs3:GMTs18:Atlantic/Reykjaviks4:GMT0s3:GMTs18:Atlantic/Reykjaviks9:Greenwichs3:GMTs18:Atlantic/Reykjaviks3:HSTs6:Hawaiis16:Pacific/Honolulus8:Hongkongs9:Hong_Kongs14:Asia/Hong_Kongs7:Icelands3:GMTs18:Atlantic/Reykjaviks19:Indian/Antananarivos14:Africa_Easterns14:Africa/Nairobis13:Indian/Chagoss12:Indian_Oceans13:Indian/Chagoss16:Indian/Christmass9:Christmass16:Indian/Christmass12:Indian/Cocoss5:Cocoss12:Indian/Cocoss13:Indian/Comoros14:Africa_Easterns14:Africa/Nairobis16:Indian/Kerguelens15:French_Southerns16:Indian/Kerguelens11:Indian/Mahes10:Seychelless11:Indian/Mahes15:Indian/Maldivess8:Maldivess15:Indian/Maldivess16:Indian/Mauritiuss9:Mauritiuss16:Indian/Mauritiuss14:Indian/Mayottes14:Africa_Easterns14:Africa/Nairobis14:Indian/Reunions7:Reunions14:Indian/Reunions4:Irans4:Irans11:Asia/Tehrans6:Israels6:Israels14:Asia/Jerusalems7:Jamaicas15:America_Easterns16:America/New_Yorks5:Japans5:Japans10:Asia/Tokyos9:Kwajaleins16:Marshall_Islandss14:Pacific/Majuros5:Libyas14:Europe_Easterns16:Europe/Bucharests3:METs14:Europe_Centrals12:Europe/Pariss3:MSTs16:America_Mountains14:America/Denvers7:MST7MDTs16:America_Mountains14:America/Denvers16:Mexico/BajaNortes15:America_Pacifics19:America/Los_Angeless14:Mexico/BajaSurs14:Mexico_Pacifics16:America/Mazatlans14:Mexico/Generals15:America_Centrals15:America/Chicagos2:NZs11:New_Zealands16:Pacific/Aucklands7:NZ-CHATs7:Chathams15:Pacific/Chathams6:Navajos16:America_Mountains14:America/Denvers3:PRCs5:Chinas13:Asia/Shanghais7:PST8PDTs15:America_Pacifics19:America/Los_Angeless12:Pacific/Apias4:Apias12:Pacific/Apias16:Pacific/Aucklands11:New_Zealands16:Pacific/Aucklands15:Pacific/Chathams7:Chathams15:Pacific/Chathams13:Pacific/Chuuks4:Truks12:Pacific/Truks14:Pacific/Easters6:Easters14:Pacific/Easters13:Pacific/Efates7:Vanuatus13:Pacific/Efates17:Pacific/Enderburys15:Phoenix_Islandss17:Pacific/Enderburys15:Pacific/Fakaofos7:Tokelaus15:Pacific/Fakaofos12:Pacific/Fijis4:Fijis12:Pacific/Fijis16:Pacific/Funafutis6:Tuvalus16:Pacific/Funafutis17:Pacific/Galapagoss9:Galapagoss17:Pacific/Galapagoss15:Pacific/Gambiers7:Gambiers15:Pacific/Gambiers19:Pacific/Guadalcanals7:Solomons19:Pacific/Guadalcanals12:Pacific/Guams8:Chamorros14:Pacific/Saipans16:Pacific/Honolulus6:Hawaiis16:Pacific/Honolulus16:Pacific/Johnstons6:Hawaiis16:Pacific/Honolulus14:Pacific/Kantons15:Phoenix_Islandss17:Pacific/Enderburys18:Pacific/Kiritimatis12:Line_Islandss18:Pacific/Kiritimatis14:Pacific/Kosraes6:Kosraes14:Pacific/Kosraes17:Pacific/Kwajaleins16:Marshall_Islandss14:Pacific/Majuros14:Pacific/Majuros16:Marshall_Islandss14:Pacific/Majuros17:Pacific/Marquesass9:Marquesass17:Pacific/Marquesass14:Pacific/Midways5:Samoas17:Pacific/Pago_Pagos13:Pacific/Naurus5:Naurus13:Pacific/Naurus12:Pacific/Niues4:Niues12:Pacific/Niues15:Pacific/Norfolks7:Norfolks15:Pacific/Norfolks14:Pacific/Noumeas13:New_Caledonias14:Pacific/Noumeas17:Pacific/Pago_Pagos5:Samoas17:Pacific/Pago_Pagos13:Pacific/Palaus5:Palaus13:Pacific/Palaus16:Pacific/Pitcairns8:Pitcairns16:Pacific/Pitcairns15:Pacific/Pohnpeis6:Ponapes14:Pacific/Ponapes14:Pacific/Ponapes6:Ponapes14:Pacific/Ponapes20:Pacific/Port_Moresbys16:Papua_New_Guineas20:Pacific/Port_Moresbys17:Pacific/Rarotongas4:Cooks17:Pacific/Rarotongas14:Pacific/Saipans8:Chamorros14:Pacific/Saipans13:Pacific/Samoas5:Samoas17:Pacific/Pago_Pagos14:Pacific/Tahitis6:Tahitis14:Pacific/Tahitis14:Pacific/Tarawas15:Gilbert_Islandss14:Pacific/Tarawas17:Pacific/Tongatapus5:Tongas17:Pacific/Tongatapus12:Pacific/Truks4:Truks12:Pacific/Truks12:Pacific/Wakes4:Wakes12:Pacific/Wakes14:Pacific/Walliss6:Walliss14:Pacific/Walliss11:Pacific/Yaps4:Truks12:Pacific/Truks6:Polands14:Europe_Centrals12:Europe/Pariss8:Portugals14:Europe_Westerns15:Atlantic/Canarys3:ROKs5:Koreas10:Asia/Seouls9:Singapores9:Singapores14:Asia/Singapores6:Turkeys6:Turkeys15:Europe/Istanbuls9:US/Alaskas6:Alaskas14:America/Juneaus11:US/Aleutians15:Hawaii_Aleutians12:America/Adaks10:US/Arizonas16:America_Mountains14:America/Denvers10:US/Centrals15:America_Centrals15:America/Chicagos15:US/East-Indianas15:America_Easterns16:America/New_Yorks10:US/Easterns15:America_Easterns16:America/New_Yorks9:US/Hawaiis6:Hawaiis16:Pacific/Honolulus17:US/Indiana-Starkes15:America_Centrals15:America/Chicagos11:US/Michigans15:America_Easterns16:America/New_Yorks11:US/Mountains16:America_Mountains14:America/Denvers10:US/Pacifics15:America_Pacifics19:America/Los_Angeless8:US/Samoas5:Samoas17:Pacific/Pago_Pagos4:W-SUs6:Moscows13:Europe/Moscows3:WETs14:Europe_Westerns15:Atlantic/Canarys15:Africa/Khartoums14:Africa_Centrals13:Africa/Maputos15:Africa/Windhoeks14:Africa_Centrals13:Africa/Maputos15:Africa/Sao_Tomes14:Africa_Westerns12:Africa/Lagos", []*Class{String_class}); ZoneName_mzoneMap = ConstRefArray("[0,396,s14:Africa_Centrals2:BIs16:Africa/Bujumburas14:Africa_Centrals2:BWs15:Africa/Gaborones14:Africa_Centrals2:CDs17:Africa/Lubumbashis14:Africa_Centrals2:MWs15:Africa/Blantyres14:Africa_Centrals2:RWs13:Africa/Kigalis14:Africa_Centrals2:ZMs13:Africa/Lusakas14:Africa_Centrals2:ZWs13:Africa/Harares14:Africa_Easterns2:DJs15:Africa/Djiboutis14:Africa_Easterns2:ERs13:Africa/Asmeras14:Africa_Easterns2:ETs18:Africa/Addis_Ababas14:Africa_Easterns2:KMs13:Indian/Comoros14:Africa_Easterns2:MGs19:Indian/Antananarivos14:Africa_Easterns2:SOs16:Africa/Mogadishus14:Africa_Easterns2:TZs20:Africa/Dar_es_Salaams14:Africa_Easterns2:UGs14:Africa/Kampalas14:Africa_Easterns2:YTs14:Indian/Mayottes15:Africa_Southerns2:LSs13:Africa/Maserus15:Africa_Southerns2:SZs14:Africa/Mbabanes14:Africa_Westerns2:AOs13:Africa/Luandas14:Africa_Westerns2:BJs17:Africa/Porto-Novos14:Africa_Westerns2:CDs15:Africa/Kinshasas14:Africa_Westerns2:CFs13:Africa/Banguis14:Africa_Westerns2:CGs18:Africa/Brazzavilles14:Africa_Westerns2:CMs13:Africa/Doualas14:Africa_Westerns2:GAs17:Africa/Librevilles14:Africa_Westerns2:GQs13:Africa/Malabos14:Africa_Westerns2:NEs13:Africa/Niameys14:Africa_Westerns2:TDs15:Africa/Ndjamenas15:America_Centrals2:BZs14:America/Belizes15:America_Centrals2:CAs16:America/Winnipegs15:America_Centrals2:CRs18:America/Costa_Ricas15:America_Centrals2:GTs17:America/Guatemalas15:America_Centrals2:HNs19:America/Tegucigalpas15:America_Centrals2:MXs19:America/Mexico_Citys15:America_Centrals2:SVs19:America/El_Salvadors15:America_Easterns2:BSs14:America/Nassaus15:America_Easterns2:CAs15:America/Torontos15:America_Easterns2:HTs22:America/Port-au-Princes15:America_Easterns2:JMs15:America/Jamaicas15:America_Easterns2:KYs14:America/Caymans15:America_Easterns2:PAs14:America/Panamas16:America_Mountains2:CAs16:America/Edmontons15:America_Pacifics2:CAs17:America/Vancouvers15:America_Pacifics2:MXs15:America/Tijuanas7:Arabians2:BHs12:Asia/Bahrains7:Arabians2:IQs12:Asia/Baghdads7:Arabians2:KWs11:Asia/Kuwaits7:Arabians2:QAs10:Asia/Qatars7:Arabians2:YEs9:Asia/Adens8:Atlantics2:AGs15:America/Antiguas8:Atlantics2:AIs16:America/Anguillas8:Atlantics2:AWs13:America/Arubas8:Atlantics2:BBs16:America/Barbadoss8:Atlantics2:BMs16:Atlantic/Bermudas8:Atlantics2:BQs18:America/Kralendijks8:Atlantics2:CWs15:America/Curacaos8:Atlantics2:DMs16:America/Dominicas8:Atlantics2:GDs15:America/Grenadas8:Atlantics2:GLs13:America/Thules8:Atlantics2:GPs18:America/Guadeloupes8:Atlantics2:KNs16:America/St_Kittss8:Atlantics2:LCs16:America/St_Lucias8:Atlantics2:MFs15:America/Marigots8:Atlantics2:MQs18:America/Martiniques8:Atlantics2:MSs18:America/Montserrats8:Atlantics2:PRs19:America/Puerto_Ricos8:Atlantics2:SXs21:America/Lower_Princess8:Atlantics2:TTs21:America/Port_of_Spains8:Atlantics2:VCs18:America/St_Vincents8:Atlantics2:VGs15:America/Tortolas8:Atlantics2:VIs17:America/St_Thomass8:Chamorros2:GUs12:Pacific/Guams14:Europe_Centrals2:ADs14:Europe/Andorras14:Europe_Centrals2:ALs13:Europe/Tiranes14:Europe_Centrals2:ATs13:Europe/Viennas14:Europe_Centrals2:BAs15:Europe/Sarajevos14:Europe_Centrals2:BEs15:Europe/Brusselss14:Europe_Centrals2:CHs13:Europe/Zurichs14:Europe_Centrals2:CZs13:Europe/Pragues14:Europe_Centrals2:DEs13:Europe/Berlins14:Europe_Centrals2:DKs17:Europe/Copenhagens14:Europe_Centrals2:ESs13:Europe/Madrids14:Europe_Centrals2:GIs16:Europe/Gibraltars14:Europe_Centrals2:HRs13:Europe/Zagrebs14:Europe_Centrals2:HUs15:Europe/Budapests14:Europe_Centrals2:ITs11:Europe/Romes14:Europe_Centrals2:LIs12:Europe/Vaduzs14:Europe_Centrals2:LUs17:Europe/Luxembourgs14:Europe_Centrals2:MCs13:Europe/Monacos14:Europe_Centrals2:MEs16:Europe/Podgoricas14:Europe_Centrals2:MKs13:Europe/Skopjes14:Europe_Centrals2:MTs12:Europe/Maltas14:Europe_Centrals2:NLs16:Europe/Amsterdams14:Europe_Centrals2:NOs11:Europe/Oslos14:Europe_Centrals2:PLs13:Europe/Warsaws14:Europe_Centrals2:RSs15:Europe/Belgrades14:Europe_Centrals2:SEs16:Europe/Stockholms14:Europe_Centrals2:SIs16:Europe/Ljubljanas14:Europe_Centrals2:SJs19:Arctic/Longyearbyens14:Europe_Centrals2:SKs17:Europe/Bratislavas14:Europe_Centrals2:SMs17:Europe/San_Marinos14:Europe_Centrals2:TNs12:Africa/Tuniss14:Europe_Centrals2:VAs14:Europe/Vaticans14:Europe_Centrals2:XKs15:Europe/Belgrades14:Europe_Easterns2:AXs16:Europe/Mariehamns14:Europe_Easterns2:BGs12:Europe/Sofias14:Europe_Easterns2:CYs12:Asia/Nicosias14:Europe_Easterns2:EGs12:Africa/Cairos14:Europe_Easterns2:FIs15:Europe/Helsinkis14:Europe_Easterns2:GRs13:Europe/Athenss14:Europe_Easterns2:LBs11:Asia/Beiruts22:Europe_Further_Easterns2:RUs18:Europe/Kaliningrads14:Europe_Westerns2:FOs15:Atlantic/Faeroes3:GMTs2:BFs18:Africa/Ouagadougous3:GMTs2:CIs14:Africa/Abidjans3:GMTs2:GBs13:Europe/Londons3:GMTs2:GHs12:Africa/Accras3:GMTs2:GMs13:Africa/Banjuls3:GMTs2:GNs14:Africa/Conakrys3:GMTs2:IEs13:Europe/Dublins3:GMTs2:MLs13:Africa/Bamakos3:GMTs2:MRs17:Africa/Nouakchotts3:GMTs2:SHs18:Atlantic/St_Helenas3:GMTs2:SLs15:Africa/Freetowns3:GMTs2:SNs12:Africa/Dakars3:GMTs2:TGs11:Africa/Lomes4:Gulfs2:OMs11:Asia/Muscats5:Indias2:LKs12:Asia/Colombos9:Indochinas2:KHs15:Asia/Phnom_Penhs9:Indochinas2:LAs14:Asia/Vientianes11:New_Zealands2:AQs18:Antarctica/McMurdos14:Africa_Westerns2:STs15:Africa/Sao_Tome", []*Class{String_class}); ZoneName_aliasMap = ConstRefArray("[0,596,s15:Africa/Timbuktus13:Africa/Bamakos16:America/Montreals15:America/Torontos15:America/Nipigons15:America/Torontos19:America/Pangnirtungs15:America/Iqaluits19:America/Rainy_Rivers16:America/Winnipegs20:America/Santa_Isabels15:America/Tijuanas16:America/Shiprocks14:America/Denvers19:America/Thunder_Bays15:America/Torontos19:America/Yellowknifes16:America/Edmontons21:Antarctica/South_Poles16:Pacific/Aucklands15:Asia/Choibalsans16:Asia/Ulaanbaatars14:Asia/Chongqings13:Asia/Shanghais11:Asia/Harbins13:Asia/Shanghais12:Asia/Kashgars11:Asia/Urumqis18:Atlantic/Jan_Mayens11:Europe/Oslos16:Australia/Curries16:Australia/Hobarts7:CST6CDTs15:America/Chicagos3:ESTs14:America/Panamas7:EST5EDTs16:America/New_Yorks14:Europe/Belfasts13:Europe/Londons15:Europe/Uzhgorods11:Europe/Kievs17:Europe/Zaporozhyes11:Europe/Kievs3:HSTs16:Pacific/Honolulus3:MSTs15:America/Phoenixs7:MST7MDTs14:America/Denvers7:PST8PDTs19:America/Los_Angeless16:Pacific/Johnstons16:Pacific/Honolulus11:Pacific/Yaps12:Pacific/Truks12:SystemV/AST4s19:America/Puerto_Ricos15:SystemV/AST4ADTs15:America/Halifaxs12:SystemV/CST6s14:America/Reginas15:SystemV/CST6CDTs15:America/Chicagos12:SystemV/EST5s20:America/Indianapoliss15:SystemV/EST5EDTs16:America/New_Yorks13:SystemV/HST10s16:Pacific/Honolulus12:SystemV/MST7s15:America/Phoenixs15:SystemV/MST7MDTs14:America/Denvers12:SystemV/PST8s16:Pacific/Pitcairns15:SystemV/PST8PDTs19:America/Los_Angeless12:SystemV/YST9s15:Pacific/Gambiers15:SystemV/YST9YDTs17:America/Anchorages12:Africa/Accras14:Africa/Abidjans18:Africa/Addis_Ababas14:Africa/Nairobis13:Africa/Asmaras14:Africa/Nairobis13:Africa/Asmeras14:Africa/Nairobis13:Africa/Bamakos14:Africa/Abidjans13:Africa/Banguis12:Africa/Lagoss13:Africa/Banjuls14:Africa/Abidjans15:Africa/Blantyres13:Africa/Maputos18:Africa/Brazzavilles12:Africa/Lagoss16:Africa/Bujumburas13:Africa/Maputos14:Africa/Conakrys14:Africa/Abidjans12:Africa/Dakars14:Africa/Abidjans20:Africa/Dar_es_Salaams14:Africa/Nairobis15:Africa/Djiboutis14:Africa/Nairobis13:Africa/Doualas12:Africa/Lagoss15:Africa/Freetowns14:Africa/Abidjans15:Africa/Gaborones13:Africa/Maputos13:Africa/Harares13:Africa/Maputos14:Africa/Kampalas14:Africa/Nairobis13:Africa/Kigalis13:Africa/Maputos15:Africa/Kinshasas12:Africa/Lagoss17:Africa/Librevilles12:Africa/Lagoss11:Africa/Lomes14:Africa/Abidjans13:Africa/Luandas12:Africa/Lagoss17:Africa/Lubumbashis13:Africa/Maputos13:Africa/Lusakas13:Africa/Maputos13:Africa/Malabos12:Africa/Lagoss13:Africa/Maserus19:Africa/Johannesburgs14:Africa/Mbabanes19:Africa/Johannesburgs16:Africa/Mogadishus14:Africa/Nairobis13:Africa/Niameys12:Africa/Lagoss17:Africa/Nouakchotts14:Africa/Abidjans18:Africa/Ouagadougous14:Africa/Abidjans17:Africa/Porto-Novos12:Africa/Lagoss15:Africa/Timbuktus14:Africa/Abidjans16:America/Anguillas19:America/Puerto_Ricos15:America/Antiguas19:America/Puerto_Ricos32:America/Argentina/ComodRivadavias27:America/Argentina/Catamarcas13:America/Arubas19:America/Puerto_Ricos16:America/Atikokans14:America/Panamas12:America/Atkas12:America/Adaks20:America/Blanc-Sablons19:America/Puerto_Ricos20:America/Buenos_Airess30:America/Argentina/Buenos_Airess17:America/Catamarcas27:America/Argentina/Catamarcas14:America/Caymans14:America/Panamas21:America/Coral_Harbours14:America/Panamas15:America/Cordobas25:America/Argentina/Cordobas15:America/Crestons15:America/Phoenixs15:America/Curacaos19:America/Puerto_Ricos16:America/Dominicas19:America/Puerto_Ricos16:America/Ensenadas15:America/Tijuanas18:America/Fort_Waynes28:America/Indiana/Indianapoliss15:America/Godthabs12:America/Nuuks15:America/Grenadas19:America/Puerto_Ricos18:America/Guadeloupes19:America/Puerto_Ricos20:America/Indianapoliss28:America/Indiana/Indianapoliss13:America/Jujuys23:America/Argentina/Jujuys15:America/Knox_INs20:America/Indiana/Knoxs18:America/Kralendijks19:America/Puerto_Ricos18:America/Louisvilles27:America/Kentucky/Louisvilles21:America/Lower_Princess19:America/Puerto_Ricos15:America/Marigots19:America/Puerto_Ricos15:America/Mendozas25:America/Argentina/Mendozas16:America/Montreals15:America/Torontos18:America/Montserrats19:America/Puerto_Ricos14:America/Nassaus15:America/Torontos15:America/Nipigons15:America/Torontos19:America/Pangnirtungs15:America/Iqaluits21:America/Port_of_Spains19:America/Puerto_Ricos18:America/Porto_Acres18:America/Rio_Brancos19:America/Rainy_Rivers16:America/Winnipegs15:America/Rosarios25:America/Argentina/Cordobas20:America/Santa_Isabels15:America/Tijuanas16:America/Shiprocks14:America/Denvers21:America/St_Barthelemys19:America/Puerto_Ricos16:America/St_Kittss19:America/Puerto_Ricos16:America/St_Lucias19:America/Puerto_Ricos17:America/St_Thomass19:America/Puerto_Ricos18:America/St_Vincents19:America/Puerto_Ricos19:America/Thunder_Bays15:America/Torontos15:America/Tortolas19:America/Puerto_Ricos14:America/Virgins19:America/Puerto_Ricos19:America/Yellowknifes16:America/Edmontons25:Antarctica/DumontDUrvilles20:Pacific/Port_Moresbys18:Antarctica/McMurdos16:Pacific/Aucklands21:Antarctica/South_Poles16:Pacific/Aucklands16:Antarctica/Syowas11:Asia/Riyadhs19:Arctic/Longyearbyens13:Europe/Berlins9:Asia/Adens11:Asia/Riyadhs14:Asia/Ashkhabads13:Asia/Ashgabats12:Asia/Bahrains10:Asia/Qatars11:Asia/Bruneis12:Asia/Kuchings13:Asia/Calcuttas12:Asia/Kolkatas15:Asia/Choibalsans16:Asia/Ulaanbaatars14:Asia/Chongqings13:Asia/Shanghais14:Asia/Chungkings13:Asia/Shanghais10:Asia/Daccas10:Asia/Dhakas11:Asia/Harbins13:Asia/Shanghais13:Asia/Istanbuls15:Europe/Istanbuls12:Asia/Kashgars11:Asia/Urumqis13:Asia/Katmandus14:Asia/Kathmandus17:Asia/Kuala_Lumpurs14:Asia/Singapores11:Asia/Kuwaits11:Asia/Riyadhs10:Asia/Macaos10:Asia/Macaus11:Asia/Muscats10:Asia/Dubais15:Asia/Phnom_Penhs12:Asia/Bangkoks12:Asia/Rangoons11:Asia/Yangons11:Asia/Saigons16:Asia/Ho_Chi_Minhs13:Asia/Tel_Avivs14:Asia/Jerusalems11:Asia/Thimbus12:Asia/Thimphus18:Asia/Ujung_Pandangs13:Asia/Makassars15:Asia/Ulan_Bators16:Asia/Ulaanbaatars14:Asia/Vientianes12:Asia/Bangkoks15:Atlantic/Faeroes14:Atlantic/Faroes18:Atlantic/Jan_Mayens13:Europe/Berlins18:Atlantic/Reykjaviks14:Africa/Abidjans18:Atlantic/St_Helenas14:Africa/Abidjans13:Australia/ACTs16:Australia/Sydneys18:Australia/Canberras16:Australia/Sydneys16:Australia/Curries16:Australia/Hobarts13:Australia/LHIs19:Australia/Lord_Howes13:Australia/NSWs16:Australia/Sydneys15:Australia/Norths16:Australia/Darwins20:Australia/Queenslands18:Australia/Brisbanes15:Australia/Souths18:Australia/Adelaides18:Australia/Tasmanias16:Australia/Hobarts18:Australia/Victorias19:Australia/Melbournes14:Australia/Wests15:Australia/Perths20:Australia/Yancowinnas21:Australia/Broken_Hills11:Brazil/Acres18:America/Rio_Brancos16:Brazil/DeNoronhas15:America/Noronhas11:Brazil/Easts17:America/Sao_Paulos11:Brazil/Wests14:America/Manauss3:CETs15:Europe/Brusselss7:CST6CDTs15:America/Chicagos15:Canada/Atlantics15:America/Halifaxs14:Canada/Centrals16:America/Winnipegs14:Canada/Easterns15:America/Torontos15:Canada/Mountains16:America/Edmontons19:Canada/Newfoundlands16:America/St_Johnss14:Canada/Pacifics17:America/Vancouvers19:Canada/Saskatchewans14:America/Reginas12:Canada/Yukons18:America/Whitehorses17:Chile/Continentals16:America/Santiagos18:Chile/EasterIslands14:Pacific/Easters4:Cubas14:America/Havanas3:EETs13:Europe/Athenss3:ESTs14:America/Panamas7:EST5EDTs16:America/New_Yorks5:Egypts12:Africa/Cairos4:Eires13:Europe/Dublins9:Etc/GMT+0s7:Etc/GMTs9:Etc/GMT-0s7:Etc/GMTs8:Etc/GMT0s7:Etc/GMTs13:Etc/Greenwichs7:Etc/GMTs7:Etc/UCTs7:Etc/UTCs13:Etc/Universals7:Etc/UTCs8:Etc/Zulus7:Etc/UTCs16:Europe/Amsterdams15:Europe/Brusselss14:Europe/Belfasts13:Europe/Londons17:Europe/Bratislavas13:Europe/Pragues15:Europe/Busingens13:Europe/Zurichs17:Europe/Copenhagens13:Europe/Berlins15:Europe/Guernseys13:Europe/Londons18:Europe/Isle_of_Mans13:Europe/Londons13:Europe/Jerseys13:Europe/Londons11:Europe/Kievs11:Europe/Kyivs16:Europe/Ljubljanas15:Europe/Belgrades17:Europe/Luxembourgs15:Europe/Brusselss16:Europe/Mariehamns15:Europe/Helsinkis13:Europe/Monacos12:Europe/Pariss14:Europe/Nicosias12:Asia/Nicosias11:Europe/Oslos13:Europe/Berlins16:Europe/Podgoricas15:Europe/Belgrades17:Europe/San_Marinos11:Europe/Romes15:Europe/Sarajevos15:Europe/Belgrades13:Europe/Skopjes15:Europe/Belgrades16:Europe/Stockholms13:Europe/Berlins15:Europe/Tiraspols15:Europe/Chisinaus15:Europe/Uzhgorods11:Europe/Kyivs12:Europe/Vaduzs13:Europe/Zurichs14:Europe/Vaticans11:Europe/Romes13:Europe/Zagrebs15:Europe/Belgrades17:Europe/Zaporozhyes11:Europe/Kyivs2:GBs13:Europe/Londons7:GB-Eires13:Europe/Londons3:GMTs7:Etc/GMTs5:GMT+0s7:Etc/GMTs5:GMT-0s7:Etc/GMTs4:GMT0s7:Etc/GMTs9:Greenwichs7:Etc/GMTs3:HSTs16:Pacific/Honolulus8:Hongkongs14:Asia/Hong_Kongs7:Icelands14:Africa/Abidjans19:Indian/Antananarivos14:Africa/Nairobis16:Indian/Christmass12:Asia/Bangkoks12:Indian/Cocoss11:Asia/Yangons13:Indian/Comoros14:Africa/Nairobis16:Indian/Kerguelens15:Indian/Maldivess11:Indian/Mahes10:Asia/Dubais14:Indian/Mayottes14:Africa/Nairobis14:Indian/Reunions10:Asia/Dubais4:Irans11:Asia/Tehrans6:Israels14:Asia/Jerusalems7:Jamaicas15:America/Jamaicas5:Japans10:Asia/Tokyos9:Kwajaleins17:Pacific/Kwajaleins5:Libyas14:Africa/Tripolis3:METs15:Europe/Brusselss3:MSTs15:America/Phoenixs7:MST7MDTs14:America/Denvers16:Mexico/BajaNortes15:America/Tijuanas14:Mexico/BajaSurs16:America/Mazatlans14:Mexico/Generals19:America/Mexico_Citys2:NZs16:Pacific/Aucklands7:NZ-CHATs15:Pacific/Chathams6:Navajos14:America/Denvers3:PRCs13:Asia/Shanghais7:PST8PDTs19:America/Los_Angeless13:Pacific/Chuuks20:Pacific/Port_Moresbys17:Pacific/Enderburys14:Pacific/Kantons16:Pacific/Funafutis14:Pacific/Tarawas16:Pacific/Johnstons16:Pacific/Honolulus14:Pacific/Majuros14:Pacific/Tarawas14:Pacific/Midways17:Pacific/Pago_Pagos15:Pacific/Pohnpeis19:Pacific/Guadalcanals14:Pacific/Ponapes19:Pacific/Guadalcanals14:Pacific/Saipans12:Pacific/Guams13:Pacific/Samoas17:Pacific/Pago_Pagos12:Pacific/Truks20:Pacific/Port_Moresbys12:Pacific/Wakes14:Pacific/Tarawas14:Pacific/Walliss14:Pacific/Tarawas11:Pacific/Yaps20:Pacific/Port_Moresbys6:Polands13:Europe/Warsaws8:Portugals13:Europe/Lisbons3:ROCs11:Asia/Taipeis3:ROKs10:Asia/Seouls9:Singapores14:Asia/Singapores6:Turkeys15:Europe/Istanbuls3:UCTs7:Etc/UTCs9:US/Alaskas17:America/Anchorages11:US/Aleutians12:America/Adaks10:US/Arizonas15:America/Phoenixs10:US/Centrals15:America/Chicagos15:US/East-Indianas28:America/Indiana/Indianapoliss10:US/Easterns16:America/New_Yorks9:US/Hawaiis16:Pacific/Honolulus17:US/Indiana-Starkes20:America/Indiana/Knoxs11:US/Michigans15:America/Detroits11:US/Mountains14:America/Denvers10:US/Pacifics19:America/Los_Angeless8:US/Samoas17:Pacific/Pago_Pagos3:UTCs7:Etc/UTCs9:Universals7:Etc/UTCs4:W-SUs13:Europe/Moscows3:WETs13:Europe/Lisbons4:Zulus7:Etc/UTC", []*Class{String_class}); ZoneName_zidToMzone = HashMap_New(); ZoneName_mzoneToZid = HashMap_New(); ZoneName_mzoneToZidL = HashMap_New(); ZoneName_aliases = HashMap_New()



























































































































































































































































































































































































































































































































	var i int32 = 0; L1: for {
		if i < int32(len(ZoneName_zidMap.A)) {
			var tmp1 Map = ZoneName_zidToMzone; var tmp2 any = As[*String](ZoneName_zidMap.A[i]).Ref(); tmp1.Put_O_O__O(tmp2, As[*String](ZoneName_zidMap.A[i+1]).Ref())
			var tmp3 Map = ZoneName_mzoneToZid; var tmp4 any = As[*String](ZoneName_zidMap.A[i+1]).Ref(); tmp3.Put_O_O__O(tmp4, As[*String](ZoneName_zidMap.A[i+2]).Ref())


			i = i + 3; continue L1 }
//line :552:1
		break L1
	}





	var i_2 int32 = 0; L2: for {
		if i_2 < int32(len(ZoneName_mzoneMap.A)) {
			var mzone *String = As[*String](ZoneName_mzoneMap.A[i_2]); var map_ Map = Map_Cast(ZoneName_mzoneToZidL.Get_O__O(mzone.Ref()))

			if map_ == nil { map_ = HashMap_New(); ZoneName_mzoneToZidL.Put_O_O__O(mzone.Ref(), map_) }
			var tmp5 Map = map_; var tmp6 any = As[*String](ZoneName_mzoneMap.A[i_2+1]).Ref(); tmp5.Put_O_O__O(tmp6, As[*String](ZoneName_mzoneMap.A[i_2+2]).Ref())
			i_2 = i_2 + 3; continue L2 }
//line :559:1
		break L2
	}





	var i_3 int32 = 0; L3: for {
		if i_3 < int32(len(ZoneName_aliasMap.A)) {
			var tmp7 Map = ZoneName_aliases; var tmp8 any = As[*String](ZoneName_aliasMap.A[i_3]).Ref(); tmp7.Put_O_O__O(tmp8, As[*String](ZoneName_aliasMap.A[i_3+1]).Ref())
			i_3 = i_3 + 2; continue L3 }
//line :566:1
		break L3
	}
}


func ZoneName_New() *ZoneName { ZoneName_Init(); t := &ZoneName{}; t.Ctor(); return t }

func (t *ZoneName) Ctor() {}

func (t *ZoneName) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneName) GetClass__Class() *Class { return ZoneName_class }

func (t *ZoneName) ToString__String() *String { return Object_toString(t) }

func (t *ZoneName) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneName) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneName_InstanceOf(x any) bool { _, ok := x.(*ZoneName); return ok }

func ZoneName_Cast(x any) *ZoneName { if x == nil { return nil }; v, ok := x.(*ZoneName); if !ok { panic(ClassCast(x, ZoneName_class)) }; return v }
