//line java_util_EnumSet.ae:1
package jrt


















func (t *EnumSet) Ctor_Class_Enum1(this EnumSet_I, elementType *Class, universe *RefArray) { t.AbstractSet.Ctor(this)
	t.F_elementType = elementType
	t.F_universe = universe
}
func EnumSet_NoneOf_Class__EnumSet(elementType *Class) EnumSet_I {
	var universe *RefArray = EnumSet_GetUniverse_Class__Enum1(elementType)
	if universe == nil { panic(Thrown(ClassCastException_New_String(Concat(StrOfObj(elementType.Ref()), Lit_2671)))) }
	if int32(len(universe.A)) <= 64 {
		return RegularEnumSet_New_Class_Enum1(elementType, universe) } else {
			return JumboEnumSet_New_Class_Enum1(elementType, universe)
		} }
func EnumSet_AllOf_Class__EnumSet(elementType *Class) EnumSet_I {
	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(elementType); result.AddAll__V(); return result
}


func EnumSet_CopyOf_EnumSet__EnumSet(s EnumSet_I) EnumSet_I {
	return s.Clone__EnumSet()
}
func EnumSet_CopyOf_Collection__EnumSet(c Collection) EnumSet_I {
	if EnumSet_InstanceOf(c) {
		return EnumSet_Cast(c).Clone__EnumSet() } else {

			if c.IsEmpty__Z() { panic(Thrown(IllegalArgumentException_New_String(Lit_2672))) }
			var i Iterator = c.Iterator__Iterator(); var first Enum_I = Enum_Cast(i.Next__O()); var result EnumSet_I = EnumSet_Of_Enum__EnumSet(first)


		L1: for { if i.HasNext__Z() { result.Add_O__Z(Enum_Cast(i.Next__O())); continue L1 }; break L1 }
//line :44:1
			return result
		}
}



func EnumSet_ComplementOf_EnumSet__EnumSet(s EnumSet_I) EnumSet_I {
	var result EnumSet_I = EnumSet_CopyOf_EnumSet__EnumSet(s); result.Complement__V(); return result
}
func EnumSet_Of_Enum__EnumSet(e Enum_I) EnumSet_I {
	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(e.GetDeclaringClass__Class())
	result.Add_O__Z(e)
//line :54:1
	return result
}


func EnumSet_Of_Enum_Enum__EnumSet(e1, e2 Enum_I) EnumSet_I {
	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(e1.GetDeclaringClass__Class())
	result.Add_O__Z(e1)
	result.Add_O__Z(e2)
//line :59:1
	return result
}



func EnumSet_Of_Enum_Enum_Enum__EnumSet(e1, e2, e3 Enum_I) EnumSet_I {

	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(e1.GetDeclaringClass__Class())
	result.Add_O__Z(e1)
	result.Add_O__Z(e2)
	result.Add_O__Z(e3)
//line :66:1
	return result
}




func EnumSet_Of_Enum_Enum_Enum_Enum__EnumSet(e1, e2, e3, e4 Enum_I) EnumSet_I {

	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(e1.GetDeclaringClass__Class())
	result.Add_O__Z(e1)
	result.Add_O__Z(e2)
	result.Add_O__Z(e3)
	result.Add_O__Z(e4)
//line :74:1
	return result
}





func EnumSet_Of_Enum_Enum_Enum_Enum_Enum__EnumSet(e1, e2, e3, e4, e5 Enum_I) EnumSet_I {


	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(e1.GetDeclaringClass__Class())
	result.Add_O__Z(e1)
	result.Add_O__Z(e2)
	result.Add_O__Z(e3)
	result.Add_O__Z(e4)
	result.Add_O__Z(e5)
//line :84:1
	return result
}






func EnumSet_Of_Enum_Enum1__EnumSet(first Enum_I, rest *RefArray) EnumSet_I {


	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(first.GetDeclaringClass__Class())
	result.Add_O__Z(first)
	var arr_101804 *RefArray = rest; var len_101805 int32 = int32(len(arr_101804.A)); var i_101806 int32 = 0; for ; i_101806 < len_101805; i_101806++ { var e Enum_I = As[Enum_I](arr_101804.A[i_101806]); result.Add_O__Z(e) }
//line :95:1
	return result
}



func EnumSet_Range_Enum_Enum__EnumSet(from, to Enum_I) EnumSet_I {

	if from.CompareTo_Enum__I(to) > 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfObj(from), Lit_1260, StrOfObj(to))))) }
	var result EnumSet_I = EnumSet_NoneOf_Class__EnumSet(from.GetDeclaringClass__Class())
	result.AddRange_Enum_Enum__V(from, to)
//line :103:1
	return result
}




func (t *EnumSet) Impl_Clone__EnumSet(this EnumSet_I) EnumSet_I {
	var tmp1 EnumSet_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = EnumSet_Cast(A2g_ObjectClone(this)); return nil }()
//line :110:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(AssertionError_New_O(e.Ref()))) } else {
//line :110:1
			panic(tmp2) } }; return tmp1
}




func (t *EnumSet) Impl_TypeCheck_Enum__V(this EnumSet_I, e Enum_I) {
	var eClass *Class = e.GetClass__Class(); var tmp1 bool; var tmp2 bool
	tmp2 = !(eClass == t.F_elementType); if tmp2 {
		tmp2 = !(NN(eClass).GetSuperclass__Class() == t.F_elementType) }
//line :118:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(ClassCastException_New_String(Concat(StrOfObj(eClass.Ref()), Lit_2668, StrOfObj(t.F_elementType.Ref())))))
	} }
func EnumSet_GetUniverse_Class__Enum1(elementType *Class) *RefArray {
	return SharedSecrets_GetJavaLangAccess__JavaLangAccess().GetEnumConstantsShared_Class__Enum1(elementType)
}











func EnumSet_SerializationProxy_New_EnumSet(p0 EnumSet_I) *EnumSet_SerializationProxy { EnumSet_SerializationProxy_Init(); t := &EnumSet_SerializationProxy{}; t.Ctor_EnumSet(p0); return t }
//line :136:1
func (t *EnumSet_SerializationProxy) Ctor_EnumSet(set EnumSet_I) { panic(A2g_NotTranslated("java.util.EnumSet$SerializationProxy.<init>(Ljava/util/EnumSet;)V")) }



func (t *EnumSet_SerializationProxy) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.EnumSet$SerializationProxy.readResolve()Ljava/lang/Object;")) }






func (t *EnumSet) Impl_WriteReplace__O(this EnumSet_I) any { panic(A2g_NotTranslated("java.util.EnumSet.writeReplace()Ljava/lang/Object;")) }




func (t *EnumSet) Impl_ReadObjectNoData__V(this EnumSet_I) { panic(A2g_NotTranslated("java.util.EnumSet.readObjectNoData()V")) }



type EnumSet struct{ AbstractSet; F_elementType *Class; F_universe *RefArray }

type EnumSet_I interface{ AbstractSet_I; Cloneable; Serializable; Set; Collection; Iterable; Self_EnumSet() *EnumSet; AddAll__V(); AddRange_Enum_Enum__V(p0, p1 Enum_I); Clone__EnumSet() EnumSet_I; Complement__V(); TypeCheck_Enum__V(p0 Enum_I); WriteReplace__O() any }

func (t *EnumSet) Self_EnumSet() *EnumSet { return t }

func (t *EnumSet) Is_Cloneable() {}

func (t *EnumSet) Is_Serializable() {}

const EnumSet_serialVersionUID int64 = 1009687484059888093

func (t *EnumSet) Impl_Clone__O(this EnumSet_I) any { return this.Clone__EnumSet() }

func EnumSet_InstanceOf(x any) bool { _, ok := x.(EnumSet_I); return ok }

func EnumSet_Cast(x any) EnumSet_I { if x == nil { return nil }; v, ok := x.(EnumSet_I); if !ok { panic(ClassCast(x, EnumSet_class)) }; return v }



type EnumSet_SerializationProxy struct{ Object; F_elementType *Class; F_elements *RefArray }

func (t *EnumSet_SerializationProxy) Is_Serializable() {}

var EnumSet_SerializationProxy_ZERO_LENGTH_ENUM_ARRAY *RefArray

const EnumSet_SerializationProxy_serialVersionUID int64 = 362491234563181265

var EnumSet_SerializationProxy_init ClassInit

func EnumSet_SerializationProxy_Init() { if !EnumSet_SerializationProxy_init.Done() { EnumSet_SerializationProxy_init.Run(EnumSet_SerializationProxy_clinit) } }

func EnumSet_SerializationProxy_clinit() { EnumSet_SerializationProxy_ZERO_LENGTH_ENUM_ARRAY = NewRefArray(Enum_class, 0) }

func (t *EnumSet_SerializationProxy) Ref() any { if t == nil { return nil }; return t }

func (t *EnumSet_SerializationProxy) GetClass__Class() *Class { return EnumSet_SerializationProxy_class }

func (t *EnumSet_SerializationProxy) ToString__String() *String { return Object_toString(t) }

func (t *EnumSet_SerializationProxy) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EnumSet_SerializationProxy) CloneShallow() any { panic(CloneNotSupported(t)) }

func EnumSet_SerializationProxy_InstanceOf(x any) bool { _, ok := x.(*EnumSet_SerializationProxy); return ok }

func EnumSet_SerializationProxy_Cast(x any) *EnumSet_SerializationProxy { if x == nil { return nil }; v, ok := x.(*EnumSet_SerializationProxy); if !ok { panic(ClassCast(x, EnumSet_SerializationProxy_class)) }; return v }
