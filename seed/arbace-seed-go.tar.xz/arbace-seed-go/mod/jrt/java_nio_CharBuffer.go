//line java_nio_CharBuffer.ae:1
package jrt































func (t *CharBuffer) Ctor_I_I_I_I_C1_I_MemorySegment(this CharBuffer_I, mark, pos, lim, cap_ int32, hb *CharArray, offset int32, segment MemorySegment) { t.Buffer.Ctor_I_I_I_I_MemorySegment(this, mark, pos, lim, cap_, segment)


	t.F_hb = hb
	t.F_offset = offset
}
func (t *CharBuffer) Ctor_I_I_I_I_MemorySegment(this CharBuffer_I, mark, pos, lim, cap_ int32, segment MemorySegment) { t.Ctor_I_I_I_I_C1_I_MemorySegment(this, mark, pos, lim, cap_, nil, 0, segment) }


func (t *CharBuffer) Ctor_C1_J_I_MemorySegment(this CharBuffer_I, hb *CharArray, addr int64, cap_ int32, segment MemorySegment) { panic(A2g_NotTranslated("java.nio.CharBuffer.<init>([CJILjava/lang/foreign/MemorySegment;)V")) }




func (t *CharBuffer) Impl_Base__O(this CharBuffer_I) any { return t.F_hb.Ref() }

func CharBuffer_Allocate_I__CharBuffer(capacity int32) CharBuffer_I { CharBuffer_Init()
	if capacity < 0 { panic(Thrown(Buffer_CreateCapacityException_I__IllegalArgumentException(capacity))) }
	return HeapCharBuffer_New_I_I_MemorySegment(capacity, capacity, nil)
}
func CharBuffer_Wrap_C1_I_I__CharBuffer(array *CharArray, offset, length int32) CharBuffer_I { CharBuffer_Init()
	var tmp1 CharBuffer_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = HeapCharBuffer_New_C1_I_I_MemorySegment(array, offset, length, nil); return nil }()
//line :54:1
	if tmp2 != nil { if IllegalArgumentException_InstanceOf(tmp2) { var x IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = x

		panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :54:1
			panic(tmp2) } }; return tmp1
}


func CharBuffer_Wrap_C1__CharBuffer(array *CharArray) CharBuffer_I { CharBuffer_Init()
	return CharBuffer_Wrap_C1_I_I__CharBuffer(array, 0, int32(len(array.A)))
}
func (t *CharBuffer) Impl_Read_CharBuffer__I(this, target CharBuffer_I) int32 {
	var limit int32 = this.Limit__I(); var pos int32 = this.Position__I(); var remaining int32 = limit - pos


	if !A2g_AssertionsDisabled && !(remaining >= 0) { panic(Thrown(AssertionError_New())) }
	if remaining <= 0 { return -1 } else {

		var targetRemaining int32 = target.Remaining__I()
		if !A2g_AssertionsDisabled && !(targetRemaining >= 0) { panic(Thrown(AssertionError_New())) }
		if targetRemaining <= 0 { return 0 } else {

			var n int32 = Math_Min_I_I__I(remaining, targetRemaining)
			if targetRemaining < remaining { this.Limit_I__CharBuffer(pos + n) }; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
				if n > 0 { target.Put_CharBuffer__CharBuffer(this) }; return nil }(); this.Limit_I__CharBuffer(limit); if tmp1 != nil { panic(tmp1) }
//line :72:1
			return n
		}
	}
}

func CharBuffer_Wrap_CharSequence_I_I__CharBuffer(csq CharSequence, start, end int32) CharBuffer_I { CharBuffer_Init()
	var tmp1 CharBuffer_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = StringCharBuffer_New_CharSequence_I_I(csq, start, end); return nil }()
//line :78:1
	if tmp2 != nil { if IllegalArgumentException_InstanceOf(tmp2) { var x IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = x

		panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :78:1
			panic(tmp2) } }; return tmp1
}


func CharBuffer_Wrap_CharSequence__CharBuffer(csq CharSequence) CharBuffer_I { CharBuffer_Init()
	return CharBuffer_Wrap_CharSequence_I_I__CharBuffer(csq, 0, csq.Length__I())
}


















func (t *CharBuffer) Impl_Get_C1_I_I__CharBuffer(this CharBuffer_I, dst *CharArray, offset, length int32) CharBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var pos int32 = this.Position__I()
	if length > this.Limit__I()-pos {
		panic(Thrown(BufferUnderflowException_New())) }
	this.GetArray_I_C1_I_I__CharBuffer(pos, dst, offset, length)
	this.Position_I__CharBuffer(pos + length)
//line :105:1
	return this
}





func (t *CharBuffer) Impl_Get_C1__CharBuffer(this CharBuffer_I, dst *CharArray) CharBuffer_I {
	return this.Get_C1_I_I__CharBuffer(dst, 0, int32(len(dst.A)))
}
func (t *CharBuffer) Impl_Get_I_C1_I_I__CharBuffer(this CharBuffer_I, index int32, dst *CharArray, offset, length int32) CharBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	this.GetArray_I_C1_I_I__CharBuffer(index, dst, offset, length)
//line :115:1
	return this
}




func (t *CharBuffer) Impl_Get_I_C1__CharBuffer(this CharBuffer_I, index int32, dst *CharArray) CharBuffer_I {
	return this.Get_I_C1_I_I__CharBuffer(index, dst, 0, int32(len(dst.A)))
}
func (t *CharBuffer) Impl_GetArray_I_C1_I_I__CharBuffer(this CharBuffer_I, index int32, dst *CharArray, offset, length int32) CharBuffer_I {
	if !A2g_AssertionsDisabled && !this.IsAddressable__Z() { panic(Thrown(AssertionError_New())) }
	if int64(length)<<1 > 6 {
		var bufAddr int64 = t.F_address + int64(index)<<1; var dstOffset int64 = CharBuffer_ARRAY_BASE_OFFSET + int64(offset)<<1; var len_ int64 = int64(length) << 1; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)



			if !(this.Order__ByteOrder() == ByteOrder_NativeOrder__ByteOrder()) {
				var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp1).CopySwapMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J_J__V(this.Session__MemorySessionImpl(), nil, this.Base__O(), bufAddr, dst.Ref(), dstOffset, len_, 2) } else {








					var tmp2 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp2).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(this.Session__MemorySessionImpl(), nil, this.Base__O(), bufAddr, dst.Ref(), dstOffset, len_) }; return nil
		}()






		Reference_ReachabilityFence_O__V(this)
//line :130:1
		if tmp3 != nil { panic(tmp3)
		}
















	} else {

		var end int32 = offset + length; var i int32 = offset; var j int32 = index
	L1: for {

		if i < end {
			dst.A[i] = this.Get_I__C(j)
			i, j = i+1, j+1; continue L1 }
//line :151:1
		break L1 } }
//line :124:1
	return this
}
































func (t *CharBuffer) Impl_Put_CharBuffer__CharBuffer(this, src CharBuffer_I) CharBuffer_I {
	if src == this { panic(Thrown(Buffer_CreateSameBufferException__IllegalArgumentException())) }
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	var srcPos int32 = src.Position__I(); var srcLim int32 = src.Limit__I(); var srcRem int32

	if srcPos <= srcLim { srcRem = srcLim - srcPos } else { srcRem = 0 }
//line :161:1
	var pos int32 = this.Position__I(); var lim int32 = this.Limit__I(); var rem int32




	if pos <= lim { rem = lim - pos } else { rem = 0 }
	if srcRem > rem { panic(Thrown(BufferOverflowException_New())) }
	this.PutBuffer_I_CharBuffer_I_I__V(pos, src, srcPos, srcRem)
	this.Position_I__CharBuffer(pos + srcRem)
	src.Position_I__CharBuffer(srcPos + srcRem)
//line :161:1
	return this
}










func (t *CharBuffer) Impl_Put_I_CharBuffer_I_I__CharBuffer(this CharBuffer_I, index int32, src CharBuffer_I, offset, length int32) CharBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, src.Limit__I())
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	this.PutBuffer_I_CharBuffer_I_I__V(index, src, offset, length)
//line :173:1
	return this
}





func (t *CharBuffer) Impl_PutBuffer_I_CharBuffer_I_I__V(this CharBuffer_I, pos int32, src CharBuffer_I, srcPos, n int32) {
	var srcBase any = src.Base__O()
	if src.IsAddressable__Z() {
		var base any = this.Base__O(); var tmp1 bool; var tmp2 bool
		tmp2 = !(base == nil); if !tmp2 { tmp2 = this.IsDirect__Z() }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
		var srcAddr int64 = src.Self_Buffer().F_address + int64(srcPos)<<1; var addr int64 = t.F_address + int64(pos)<<1; var len_ int64 = int64(n) << 1; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)



			if !(this.Order__ByteOrder() == src.Order__ByteOrder()) {
				var tmp3 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp3).CopySwapMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J_J__V(src.Session__MemorySessionImpl(), this.Session__MemorySessionImpl(), srcBase, srcAddr, base, addr, len_, 2) } else {








					var tmp4 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp4).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(src.Session__MemorySessionImpl(), this.Session__MemorySessionImpl(), srcBase, srcAddr, base, addr, len_) }; return nil
		}()






		Reference_ReachabilityFence_O__V(src); Reference_ReachabilityFence_O__V(this)
//line :188:1
		if tmp5 != nil { panic(tmp5)
		}
















	} else {


		if !A2g_AssertionsDisabled && !StringCharBuffer_class.IsInstance_O__Z(src) { panic(Thrown(AssertionError_New())) }
		if !(t.F_hb == nil) {
			var tmp6 CharBuffer_I = src; if StringCharBuffer_InstanceOf(tmp6) { var scb *StringCharBuffer = StringCharBuffer_Cast(tmp6)
				NN(scb).GetArray_I_C1_I_I__CharBuffer(srcPos, t.F_hb, pos, n) } else {
					var posMax int32 = pos + n; var i int32 = pos; var j int32 = srcPos
				L1: for {

					if i < posMax {
						this.Put_I_C__CharBuffer(i, src.Get_I__C(j))
						i, j = i+1, j+1; continue L1 }
//line :214:1
					break L1
				}
				}
		} else {

			var posMax_2 int32 = pos + n; var i_2 int32 = pos; var j_2 int32 = srcPos
		L2: for {

			if i_2 < posMax_2 {
				this.Put_I_C__CharBuffer(i_2, src.Get_I__C(j_2))
				i_2, j_2 = i_2+1, j_2+1; continue L2 }
//line :220:1
			break L2
		}
		}
	}
}

func (t *CharBuffer) Impl_Put_C1_I_I__CharBuffer(this CharBuffer_I, src *CharArray, offset, length int32) CharBuffer_I {
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var pos int32 = this.Position__I()
	if length > this.Limit__I()-pos {
		panic(Thrown(BufferOverflowException_New())) }
	this.PutArray_I_C1_I_I__CharBuffer(pos, src, offset, length)
	this.Position_I__CharBuffer(pos + length)
//line :229:1
	return this
}





func (t *CharBuffer) Impl_Put_C1__CharBuffer(this CharBuffer_I, src *CharArray) CharBuffer_I {
	return this.Put_C1_I_I__CharBuffer(src, 0, int32(len(src.A)))
}
func (t *CharBuffer) Impl_Put_I_C1_I_I__CharBuffer(this CharBuffer_I, index int32, src *CharArray, offset, length int32) CharBuffer_I {
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	this.PutArray_I_C1_I_I__CharBuffer(index, src, offset, length)
//line :239:1
	return this
}





func (t *CharBuffer) Impl_Put_I_C1__CharBuffer(this CharBuffer_I, index int32, src *CharArray) CharBuffer_I {
	return this.Put_I_C1_I_I__CharBuffer(index, src, 0, int32(len(src.A)))
}
func (t *CharBuffer) Impl_PutArray_I_C1_I_I__CharBuffer(this CharBuffer_I, index int32, src *CharArray, offset, length int32) CharBuffer_I {
	var tmp1 bool; var tmp2 bool; tmp2 = this.IsAddressable__Z(); if tmp2 {
		tmp2 = int64(length)<<1 > 6 }
//line :250:1
	tmp1 = tmp2; if tmp1 {

		var bufAddr int64 = t.F_address + int64(index)<<1; var srcOffset int64 = CharBuffer_ARRAY_BASE_OFFSET + int64(offset)<<1; var len_ int64 = int64(length) << 1; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)



			if !(this.Order__ByteOrder() == ByteOrder_NativeOrder__ByteOrder()) {
				var tmp3 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp3).CopySwapMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J_J__V(nil, this.Session__MemorySessionImpl(), src.Ref(), srcOffset, this.Base__O(), bufAddr, len_, 2) } else {








					var tmp4 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp4).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(nil, this.Session__MemorySessionImpl(), src.Ref(), srcOffset, this.Base__O(), bufAddr, len_) }
//line :252:1
			return nil
		}()




















		Reference_ReachabilityFence_O__V(this)
//line :255:1
		if tmp5 != nil { panic(tmp5) } } else {



















			var end int32 = offset + length; var i int32 = offset; var j int32 = index
		L1: for {

			if i < end {
				this.Put_I_C__CharBuffer(j, src.A[i])
				i, j = i+1, j+1; continue L1 }
//line :276:1
			break L1 } }
//line :249:1
	return this
}
































func (t *CharBuffer) Impl_Put_String_I_I__CharBuffer(this CharBuffer_I, src *String, start, end int32) CharBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(start, end-start, NN(src).Length__I())
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	if end-start > this.Remaining__I() {
		panic(Thrown(BufferOverflowException_New())) }
	var i int32 = start; L1: for { if i < end { this.Put_C__CharBuffer(NN(src).CharAt_I__C(i)); i = i + 1; continue L1 }; break L1 }
//line :283:1
	return this
}






func (t *CharBuffer) Impl_Put_String__CharBuffer(this CharBuffer_I, src *String) CharBuffer_I {
	return this.Put_String_I_I__CharBuffer(src, 0, NN(src).Length__I())
}
func (t *CharBuffer) Impl_HasArray__Z(this CharBuffer_I) bool {
	var tmp1 bool; tmp1 = !(t.F_hb == nil); if tmp1 { tmp1 = !t.F_isReadOnly }; return tmp1
}
func (t *CharBuffer) Impl_Array__C1(this CharBuffer_I) *CharArray {
	if t.F_hb == nil { panic(Thrown(UnsupportedOperationException_New())) }
	if t.F_isReadOnly { panic(Thrown(ReadOnlyBufferException_New())) }
//line :297:1
	return t.F_hb
}



func (t *CharBuffer) Impl_ArrayOffset__I(this CharBuffer_I) int32 {
	if t.F_hb == nil { panic(Thrown(UnsupportedOperationException_New())) }
	if t.F_isReadOnly { panic(Thrown(ReadOnlyBufferException_New())) }
//line :302:1
	return t.F_offset
}



func (t *CharBuffer) Impl_Position_I__CharBuffer(this CharBuffer_I, newPosition int32) CharBuffer_I {
	t.Buffer.Impl_Position_I__Buffer(this, newPosition)
//line :307:1
	return this
}


func (t *CharBuffer) Impl_Limit_I__CharBuffer(this CharBuffer_I, newLimit int32) CharBuffer_I {
	t.Buffer.Impl_Limit_I__Buffer(this, newLimit)
//line :311:1
	return this
}


func (t *CharBuffer) Impl_Mark__CharBuffer(this CharBuffer_I) CharBuffer_I { t.Buffer.Impl_Mark__Buffer(this); return this }

func (t *CharBuffer) Impl_Reset__CharBuffer(this CharBuffer_I) CharBuffer_I { t.Buffer.Impl_Reset__Buffer(this); return this }

func (t *CharBuffer) Impl_Clear__CharBuffer(this CharBuffer_I) CharBuffer_I { t.Buffer.Impl_Clear__Buffer(this); return this }

func (t *CharBuffer) Impl_Flip__CharBuffer(this CharBuffer_I) CharBuffer_I { t.Buffer.Impl_Flip__Buffer(this); return this }

func (t *CharBuffer) Impl_Rewind__CharBuffer(this CharBuffer_I) CharBuffer_I { t.Buffer.Impl_Rewind__Buffer(this); return this }





func (t *CharBuffer) Impl_IsAddressable__Z(this CharBuffer_I) bool { return true }

func (t *CharBuffer) Impl_HashCode__I(this CharBuffer_I) int32 {
	var h int32 = 1; var p int32 = this.Position__I(); var i int32 = this.Limit__I() - 1

L1: for {
	if i >= p {
		h = 31*h + int32(this.Get_I__C(i))
		i = i - 1; continue L1 }
//line :334:1
	break L1 }
//line :332:1
	return h
}






func (t *CharBuffer) Impl_Equals_O__Z(this CharBuffer_I, ob any) bool {
	if any(this) == any(ob) { return true } else { if !CharBuffer_InstanceOf(ob) { return false } else {



		var that CharBuffer_I = CharBuffer_Cast(ob); var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var tmp1 bool; var tmp2 bool




		tmp2 = thisRem < 0; if !tmp2 { tmp2 = !(thisRem == thatRem) }; tmp1 = tmp2; if tmp1 { return false } else {

			return A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world") < 0
		} } } }
func (t *CharBuffer) Impl_CompareTo_CharBuffer__I(this, that CharBuffer_I) int32 {
	var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var length int32 = Math_Min_I_I__I(thisRem, thatRem)




	if length < 0 { return -1 } else {

		var i int32; i = A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world")
		if i >= 0 {
			return CharBuffer_Compare_C_C__I(this.Get_I__C(thisPos+i), that.Get_I__C(thatPos+i)) } else {

				return thisRem - thatRem
			} } }
func CharBuffer_Compare_C_C__I(x, y uint16) int32 { CharBuffer_Init()
	return Character_Compare_C_C__I(x, y)
}
func (t *CharBuffer) Impl_Mismatch_CharBuffer__I(this, that CharBuffer_I) int32 {
	var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var length int32 = Math_Min_I_I__I(thisRem, thatRem)




	if length < 0 { return -1 } else {

		var r int32; r = A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world")
		var tmp1 bool; var tmp2 bool; tmp2 = r == -1; if tmp2 { tmp2 = !(thisRem == thatRem) }; tmp1 = tmp2; if tmp1 { return length } else { return r
		} } }
func (t *CharBuffer) Impl_GetChars_I_I_C1_I__V(this CharBuffer_I, srcBegin, srcEnd int32, dst *CharArray, dstBegin int32) {
	var pos int32 = this.Position__I(); var lim int32 = this.Limit__I()

	Objects_CheckFromToIndex_I_I_I__I(srcBegin, srcEnd, lim-pos)
	this.Get_I_C1_I_I__CharBuffer(pos+srcBegin, dst, dstBegin, srcEnd-srcBegin)
}




func (t *CharBuffer) Impl_ToString__String(this CharBuffer_I) *String {
	return this.ToString_I_I__String(this.Position__I(), this.Limit__I())
}


func (t *CharBuffer) Impl_Length__I(this CharBuffer_I) int32 { return this.Remaining__I() }

func (t *CharBuffer) Impl_IsEmpty__Z(this CharBuffer_I) bool {
	return this.Remaining__I() == 0
}
func (t *CharBuffer) Impl_CharAt_I__C(this CharBuffer_I, index int32) uint16 {
	return this.Get_I__C(this.Position__I() + this.CheckIndex_I_I__I(index, 1))
}


func (t *CharBuffer) Impl_Append_CharSequence__CharBuffer(this CharBuffer_I, csq CharSequence) CharBuffer_I {
	if csq == nil {
		return this.Put_String__CharBuffer(Lit_95) } else {
			var tmp1 CharSequence = csq; if CharBuffer_InstanceOf(tmp1) { var cb CharBuffer_I = CharBuffer_Cast(tmp1); return this.Put_CharBuffer__CharBuffer(cb) } else { return this.Put_String__CharBuffer(csq.ToString__String())
			} } }
func (t *CharBuffer) Impl_Append_CharSequence_I_I__CharBuffer(this CharBuffer_I, csq CharSequence, start, end int32) CharBuffer_I {
	var tmp1 CharSequence = csq; if CharBuffer_InstanceOf(tmp1) { var cb CharBuffer_I = CharBuffer_Cast(tmp1)

		Objects_CheckFromToIndex_I_I_I__I(start, end, csq.Length__I())
		var length int32 = end - start; var pos int32 = this.Position__I(); var lim int32 = this.Limit__I(); var rem int32


		if pos <= lim { rem = lim - pos } else { rem = 0 }
		if length > rem { panic(Thrown(BufferOverflowException_New())) }
		this.Put_I_CharBuffer_I_I__CharBuffer(pos, cb, start, length)
		this.Position_I__CharBuffer(pos + length)
//line :416:1
		return this




	} else {


		var cs CharSequence; if csq == nil { cs = Lit_95 } else { cs = csq }
		return this.Put_String__CharBuffer(cs.SubSequence_I_I__CharSequence(start, end).ToString__String())
	} }
func (t *CharBuffer) Impl_Append_C__CharBuffer(this CharBuffer_I, c uint16) CharBuffer_I { return this.Put_C__CharBuffer(c) }





func (t *CharBuffer) Impl_ScaleShifts__I(this CharBuffer_I) int32 { panic(A2g_NotTranslated("java.nio.CharBuffer.scaleShifts()I")) }







func (t *CharBuffer) Impl_Chars__IntStream(this CharBuffer_I) IntStream {
	return StreamSupport_IntStream_Supplier_I_Z__IntStream(&Supplier_Fn{Fn: func() any { return A2g_Missing[Spliterator_OfInt]("class java.nio.CharBufferSpliterator is not in the closed world") }}, 16464, false)
}


type CharBuffer struct{ Buffer; F_hb *CharArray; F_offset int32; F_isReadOnly bool }

type CharBuffer_I interface{ Buffer_I; Comparable; Appendable; CharSequence; Self_CharBuffer() *CharBuffer; Base__O() any; Read_CharBuffer__I(p0 CharBuffer_I) int32; Slice__CharBuffer() CharBuffer_I; Slice_I_I__CharBuffer(p0, p1 int32) CharBuffer_I; Duplicate__CharBuffer() CharBuffer_I; AsReadOnlyBuffer__CharBuffer() CharBuffer_I; Get__C() uint16; Put_C__CharBuffer(p0 uint16) CharBuffer_I; Get_I__C(p0 int32) uint16; GetUnchecked_I__C(p0 int32) uint16; Put_I_C__CharBuffer(p0 int32, p1 uint16) CharBuffer_I; Get_C1_I_I__CharBuffer(p0 *CharArray, p1, p2 int32) CharBuffer_I; Get_C1__CharBuffer(p0 *CharArray) CharBuffer_I; Get_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I; Get_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I; GetArray_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I; Put_CharBuffer__CharBuffer(p0 CharBuffer_I) CharBuffer_I; Put_I_CharBuffer_I_I__CharBuffer(p0 int32, p1 CharBuffer_I, p2, p3 int32) CharBuffer_I; PutBuffer_I_CharBuffer_I_I__V(p0 int32, p1 CharBuffer_I, p2, p3 int32); Put_C1_I_I__CharBuffer(p0 *CharArray, p1, p2 int32) CharBuffer_I; Put_C1__CharBuffer(p0 *CharArray) CharBuffer_I; Put_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I; Put_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I; PutArray_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I; Put_String_I_I__CharBuffer(p0 *String, p1, p2 int32) CharBuffer_I; Put_String__CharBuffer(p0 *String) CharBuffer_I; HasArray__Z() bool; Array__C1() *CharArray; ArrayOffset__I() int32; Position_I__CharBuffer(p0 int32) CharBuffer_I; Limit_I__CharBuffer(p0 int32) CharBuffer_I; Mark__CharBuffer() CharBuffer_I; Reset__CharBuffer() CharBuffer_I; Clear__CharBuffer() CharBuffer_I; Flip__CharBuffer() CharBuffer_I; Rewind__CharBuffer() CharBuffer_I; Compact__CharBuffer() CharBuffer_I; IsDirect__Z() bool; IsAddressable__Z() bool; CompareTo_CharBuffer__I(p0 CharBuffer_I) int32; Mismatch_CharBuffer__I(p0 CharBuffer_I) int32; GetChars_I_I_C1_I__V(p0, p1 int32, p2 *CharArray, p3 int32); ToString_I_I__String(p0, p1 int32) *String; Length__I() int32; IsEmpty__Z() bool; CharAt_I__C(p0 int32) uint16; SubSequence_I_I__CharBuffer(p0, p1 int32) CharBuffer_I; Append_CharSequence__CharBuffer(p0 CharSequence) CharBuffer_I; Append_CharSequence_I_I__CharBuffer(p0 CharSequence, p1, p2 int32) CharBuffer_I; Append_C__CharBuffer(p0 uint16) CharBuffer_I; Order__ByteOrder() *ByteOrder; CharRegionOrder__ByteOrder() *ByteOrder; ScaleShifts__I() int32; Chars__IntStream() IntStream; Position_I__Buffer(p0 int32) Buffer_I; Limit_I__Buffer(p0 int32) Buffer_I; Mark__Buffer() Buffer_I; Reset__Buffer() Buffer_I; Clear__Buffer() Buffer_I; Flip__Buffer() Buffer_I; Rewind__Buffer() Buffer_I; Array__O() any; Slice__Buffer() Buffer_I; Slice_I_I__Buffer(p0, p1 int32) Buffer_I; Duplicate__Buffer() Buffer_I; CompareTo_O__I(p0 any) int32; Append_CharSequence__Appendable(p0 CharSequence) Appendable; Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable; Append_C__Appendable(p0 uint16) Appendable; SubSequence_I_I__CharSequence(p0, p1 int32) CharSequence }

func (t *CharBuffer) Self_CharBuffer() *CharBuffer { return t }

func (t *CharBuffer) Is_Comparable() {}

func (t *CharBuffer) Is_Appendable() {}

func (t *CharBuffer) Is_CharSequence() {}

var CharBuffer_ARRAY_BASE_OFFSET int64

var CharBuffer_init ClassInit

func CharBuffer_Init() { if !CharBuffer_init.Done() { CharBuffer_init.Run(CharBuffer_clinit) } }

func CharBuffer_clinit() { Buffer_Init(); CharBuffer_ARRAY_BASE_OFFSET = NN(Buffer_UNSAFE).ArrayBaseOffset_Class__J(Prim_char.ArrayClass()) }

func (t *CharBuffer) Impl_Position_I__Buffer(this CharBuffer_I, p0 int32) Buffer_I { return this.Position_I__CharBuffer(p0) }

func (t *CharBuffer) Impl_Limit_I__Buffer(this CharBuffer_I, p0 int32) Buffer_I { return this.Limit_I__CharBuffer(p0) }

func (t *CharBuffer) Impl_Mark__Buffer(this CharBuffer_I) Buffer_I { return this.Mark__CharBuffer() }

func (t *CharBuffer) Impl_Reset__Buffer(this CharBuffer_I) Buffer_I { return this.Reset__CharBuffer() }

func (t *CharBuffer) Impl_Clear__Buffer(this CharBuffer_I) Buffer_I { return this.Clear__CharBuffer() }

func (t *CharBuffer) Impl_Flip__Buffer(this CharBuffer_I) Buffer_I { return this.Flip__CharBuffer() }

func (t *CharBuffer) Impl_Rewind__Buffer(this CharBuffer_I) Buffer_I { return this.Rewind__CharBuffer() }

func (t *CharBuffer) Impl_Array__O(this CharBuffer_I) any { return this.Array__C1().Ref() }

func (t *CharBuffer) Impl_Slice__Buffer(this CharBuffer_I) Buffer_I { return this.Slice__CharBuffer() }

func (t *CharBuffer) Impl_Slice_I_I__Buffer(this CharBuffer_I, p0, p1 int32) Buffer_I { return this.Slice_I_I__CharBuffer(p0, p1) }

func (t *CharBuffer) Impl_Duplicate__Buffer(this CharBuffer_I) Buffer_I { return this.Duplicate__CharBuffer() }

func (t *CharBuffer) Impl_CompareTo_O__I(this CharBuffer_I, p0 any) int32 { return this.CompareTo_CharBuffer__I(CharBuffer_Cast(p0)) }

func (t *CharBuffer) Impl_Append_CharSequence__Appendable(this CharBuffer_I, p0 CharSequence) Appendable { return this.Append_CharSequence__CharBuffer(p0) }

func (t *CharBuffer) Impl_Append_CharSequence_I_I__Appendable(this CharBuffer_I, p0 CharSequence, p1, p2 int32) Appendable { return this.Append_CharSequence_I_I__CharBuffer(p0, p1, p2) }

func (t *CharBuffer) Impl_Append_C__Appendable(this CharBuffer_I, p0 uint16) Appendable { return this.Append_C__CharBuffer(p0) }

func (t *CharBuffer) Impl_SubSequence_I_I__CharSequence(this CharBuffer_I, p0, p1 int32) CharSequence { return this.SubSequence_I_I__CharBuffer(p0, p1) }

func CharBuffer_InstanceOf(x any) bool { _, ok := x.(CharBuffer_I); return ok }

func CharBuffer_Cast(x any) CharBuffer_I { if x == nil { return nil }; v, ok := x.(CharBuffer_I); if !ok { panic(ClassCast(x, CharBuffer_class)) }; return v }
