//line java_io_PushbackReader.ae:1
package jrt












func PushbackReader_New_Reader_I(p0 Reader_I, p1 int32) *PushbackReader { t := &PushbackReader{}; t.Ctor_Reader_I(t, p0, p1); return t }
//line :14:1
func (t *PushbackReader) Ctor_Reader_I(this PushbackReader_I, in Reader_I, size int32) { t.FilterReader.Ctor_Reader(this, in)

	if size <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_97))) }
	t.F_buf = NewCharArray(size)
	t.F_pos = size
}
func PushbackReader_New_Reader(p0 Reader_I) *PushbackReader { t := &PushbackReader{}; t.Ctor_Reader(t, p0); return t }
//line :20:1
func (t *PushbackReader) Ctor_Reader(this PushbackReader_I, in Reader_I) { t.Ctor_Reader_I(this, in, 1) }

func (t *PushbackReader) Impl_EnsureOpen__V(this PushbackReader_I) {
	if t.F_buf == nil { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *PushbackReader) Impl_Read__I(this PushbackReader_I) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
		var tmp3 int32 = t.F_pos; if tmp3 < int32(len(t.F_buf.A)) { var tmp4 uint16; var pos_1 int32 = t.F_pos
			t.F_pos = t.F_pos + 1; tmp4 = t.F_buf.A[pos_1]
//line :28:1
			tmp1 = int32(tmp4) } else {

				tmp1 = t.FilterReader.Impl_Read__I(this) } }()
//line :26:1
	return tmp1
}




func (t *PushbackReader) Impl_Read_C1_I_I__I(this PushbackReader_I, cbuf *CharArray, off, len_ int32) int32 {

	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

			Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
			if len_ == 0 { tmp1 = 0 } else {

				var avail int32 = int32(len(t.F_buf.A)) - t.F_pos
				if avail > 0 {
					if len_ < avail { avail = len_ }
					System_Arraycopy_O_I_O_I_I__V(t.F_buf.Ref(), t.F_pos, cbuf.Ref(), off, avail)
					t.F_pos = t.F_pos + avail
					off = off + avail
					len_ = len_ - avail }
				if len_ > 0 {

					len_ = t.FilterReader.Impl_Read_C1_I_I__I(this, cbuf, off, len_)
					if len_ == -1 { if avail == 0 { tmp1 = -1 } else { tmp1 = avail } } else { tmp1 = avail + len_ } } else {
//line :47:1
						tmp1 = avail
					}
			}
			return nil }()
//line :36:1
		if tmp3 != nil { if ArrayIndexOutOfBoundsException_InstanceOf(tmp3) { var e *ArrayIndexOutOfBoundsException = ArrayIndexOutOfBoundsException_Cast(tmp3); _ = e















			panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :36:1
				panic(tmp3) } } }()
//line :34:1
	return tmp1
}


















func (t *PushbackReader) Impl_Unread_I__V(this PushbackReader_I, c int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		if t.F_pos == 0 { panic(Thrown(IOException_New_String(Lit_98))) }
		var tmp2 *CharArray = t.F_buf; var tmp3 int32; var tmp4 int32 = t.F_pos - 1; t.F_pos = tmp4; tmp3 = tmp4; tmp2.A[tmp3] = uint16(c)
	}() }
func (t *PushbackReader) Impl_Unread_C1_I_I__V(this PushbackReader_I, cbuf *CharArray, off, len_ int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		if len_ > t.F_pos { panic(Thrown(IOException_New_String(Lit_98))) }
		t.F_pos = t.F_pos - len_
		System_Arraycopy_O_I_O_I_I__V(cbuf.Ref(), off, t.F_buf.Ref(), t.F_pos, len_)
	}() }
func (t *PushbackReader) Impl_Unread_C1__V(this PushbackReader_I, cbuf *CharArray) {
	this.Unread_C1_I_I__V(cbuf, 0, int32(len(cbuf.A)))
}
func (t *PushbackReader) Impl_Ready__Z(this PushbackReader_I) bool {
	var tmp1 bool; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); t.Impl_EnsureOpen__V(this); var tmp3 bool; var tmp4 int32 = t.F_pos; tmp3 = tmp4 < int32(len(t.F_buf.A)); if !tmp3 { tmp3 = t.FilterReader.Impl_Ready__Z(this) }; tmp1 = tmp3 }(); return tmp1
}
func (t *PushbackReader) Impl_Mark_I__V(this PushbackReader_I, readAheadLimit int32) {
	panic(Thrown(IOException_New_String(Lit_84)))
}
func (t *PushbackReader) Impl_Reset__V(this PushbackReader_I) {
	panic(Thrown(IOException_New_String(Lit_84)))
}
func (t *PushbackReader) Impl_MarkSupported__Z(this PushbackReader_I) bool { return false }

func (t *PushbackReader) Impl_Close__V(this PushbackReader_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.FilterReader.Impl_Close__V(this); t.F_buf = nil }()
}
func (t *PushbackReader) Impl_Skip_J__J(this PushbackReader_I, n int64) int64 {
	if n < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_51))) }
	var tmp1 int64; var tmp2 any = t.F_lock; MonitorEnter(tmp2); tmp3, tmp4 := func() (ctl int32, rv int64) { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
		{ var avail int32 = int32(len(t.F_buf.A)) - t.F_pos
			if avail > 0 {
				if n <= int64(avail) {
					t.F_pos = t.F_pos + int32(n); return 2, n } else {
						t.F_pos = int32(len(t.F_buf.A)); n = n - int64(avail) } }
			tmp1 = int64(avail) + t.FilterReader.Impl_Skip_J__J(this, n) }; return 0, 0 }()
//line :86:1
	switch tmp3 { case 2: { return tmp4 }}; return tmp1
}









type PushbackReader struct{ FilterReader; F_buf *CharArray; F_pos int32 }

type PushbackReader_I interface{ FilterReader_I; Closeable; AutoCloseable; Self_PushbackReader() *PushbackReader; Read__I() int32; Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32; Unread_I__V(p0 int32); Unread_C1_I_I__V(p0 *CharArray, p1, p2 int32); Unread_C1__V(p0 *CharArray); Ready__Z() bool; Mark_I__V(p0 int32); Reset__V(); MarkSupported__Z() bool; Close__V(); Skip_J__J(p0 int64) int64 }

func (t *PushbackReader) Self_PushbackReader() *PushbackReader { return t }

func (t *PushbackReader) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *PushbackReader) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *PushbackReader) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *PushbackReader) Unread_C1__V(p0 *CharArray) { t.Impl_Unread_C1__V(t, p0) }

func (t *PushbackReader) Unread_I__V(p0 int32) { t.Impl_Unread_I__V(t, p0) }

func (t *PushbackReader) Close__V() { t.Impl_Close__V(t) }

func (t *PushbackReader) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *PushbackReader) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *PushbackReader) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *PushbackReader) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *PushbackReader) Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32 { return t.Impl_Read_C1_I_I__I(t, p0, p1, p2) }

func (t *PushbackReader) Reset__V() { t.Impl_Reset__V(t) }

func (t *PushbackReader) Ready__Z() bool { return t.Impl_Ready__Z(t) }

func (t *PushbackReader) Unread_C1_I_I__V(p0 *CharArray, p1, p2 int32) { t.Impl_Unread_C1_I_I__V(t, p0, p1, p2) }

func (t *PushbackReader) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *PushbackReader) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *PushbackReader) Ref() any { if t == nil { return nil }; return t }

func (t *PushbackReader) GetClass__Class() *Class { return PushbackReader_class }

func (t *PushbackReader) ToString__String() *String { return Object_toString(t) }

func (t *PushbackReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PushbackReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func PushbackReader_InstanceOf(x any) bool { _, ok := x.(PushbackReader_I); return ok }

func PushbackReader_Cast(x any) PushbackReader_I { if x == nil { return nil }; v, ok := x.(PushbackReader_I); if !ok { panic(ClassCast(x, PushbackReader_class)) }; return v }
