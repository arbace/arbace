//line a2g_init.ae:1
package jrt




func init() { Boolean_Init(); Byte_Init(); Character_Init(); ClassNotFoundException_Init(); Double_Init(); ExceptionInInitializerError_Init(); Float_Init(); Integer_Init(); Long_Init(); Short_Init(); Void_Init(); TimeUnit_Init() }
