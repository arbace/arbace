//line java_util_Collection.ae:1
package jrt






















func Collection_ToArray_IntFunction__O1(this Collection, generator IntFunction) *RefArray {
	return this.ToArray_O1__O1(A2g_CastArray[*RefArray](generator.Apply_I__O(0), Object_class.ArrayClass()))
}










func Collection_RemoveIf_Predicate__Z(this Collection, filter Predicate) bool {
	Objects_RequireNonNull_O__O(filter)
	var removed bool = false; var each Iterator = this.Iterator__Iterator()

L1: for { if each.HasNext__Z() { if filter.Test_O__Z(each.Next__O()) { each.Remove__V(); removed = true }; continue L1 }; break L1 }
//line :39:1
	return removed
}











func Collection_Spliterator__Spliterator(this Collection) Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(this, 0)
}
func Collection_Stream__Stream(this Collection) Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(this.Spliterator__Spliterator(), false)
}
func Collection_ParallelStream__Stream(this Collection) Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(this.Spliterator__Spliterator(), true)
}


type Collection interface{ Object_I; Iterable; Is_Collection(); Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; Iterator__Iterator() Iterator; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; ToArray_IntFunction__O1(p0 IntFunction) *RefArray; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; AddAll_Collection__Z(p0 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; RemoveIf_Predicate__Z(p0 Predicate) bool; RetainAll_Collection__Z(p0 Collection) bool; Clear__V(); Spliterator__Spliterator() Spliterator; Stream__Stream() Stream; ParallelStream__Stream() Stream }

func Collection_InstanceOf(x any) bool { _, ok := x.(Collection); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Collection_class) } }; return ok }

func Collection_Cast(x any) Collection { if x == nil { return nil }; v, ok := x.(Collection); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Collection_class) } }; if !ok { panic(ClassCast(x, Collection_class)) }; return v }
