//line java_text_ChoiceFormat.ae:1
package jrt












func (t *ChoiceFormat) ApplyPattern_String__V(newPattern *String) {
	Objects_RequireNonNull_O_String__O(newPattern.Ref(), Lit_1708)
	t.ApplyPatternImpl_String__V(newPattern)
}
func (t *ChoiceFormat) ApplyPatternImpl_String__V(newPattern *String) {
	var limits *ArrayList = ArrayList_New(); var formats *ArrayList = ArrayList_New(); var segments *RefArray = RefArrayOf(StringBuilder_class, StringBuilder_New(), StringBuilder_New())
	var part int32 = 0
	var limit float64 = 0.0
	var inQuote bool = false
	var i int32 = 0


L1: for { if i < NN(newPattern).Length__I() {
	var ch uint16 = NN(newPattern).CharAt_I__C(i)
L2: switch { default:
	switch int32(ch) { case 39:

		var tmp1 bool; var tmp2 bool; tmp2 = i+1 < NN(newPattern).Length__I(); if tmp2 {
			tmp2 = int32(NN(newPattern).CharAt_I__C(i+1)) == int32(ch) }
//line :31:1
		tmp1 = tmp2; if tmp1 {

			NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch); i = i + 1 } else {
				inQuote = !inQuote }
//line :32:1
	case 60, 35, 8804:



		var tmp3 bool; var tmp4 bool; tmp4 = inQuote; if !tmp4 { tmp4 = part == 1 }; tmp3 = tmp4; if tmp3 {
			NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch) } else {

				if NN(As[*StringBuilder](segments.A[0])).IsEmpty__Z() {
					panic(Thrown(IllegalArgumentException_New_String(Lit_1709)))
				}
				limit = ChoiceFormat_StringToNum_String__D(NN(As[*StringBuilder](segments.A[0])).ToString__String())
				var tmp5 bool; var tmp6 bool; tmp6 = int32(ch) == 60; if tmp6 { tmp6 = Double_IsFinite_D__Z(limit) }; tmp5 = tmp6; if tmp5 {
					limit = ChoiceFormat_NextDouble_D__D(limit) }
				var tmp7 bool; var tmp8 bool; tmp8 = !NN(limits).IsEmpty__Z(); if tmp8 {
					tmp8 = limit <= NN(Double_Cast(NN(limits).GetLast__O())).DoubleValue__D() }
//line :45:1
				tmp7 = tmp8; if tmp7 {

					panic(Thrown(IllegalArgumentException_New_String(Lit_1710)))
				}
				NN(As[*StringBuilder](segments.A[0])).SetLength_I__V(0)
				part = 1 }; case 124:

		if inQuote {
			NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch) } else {

				if part == 1 { } else { break L2 }
				NN(limits).Add_O__Z(Double_ValueOf_D__Double(limit))
				NN(formats).Add_O__Z(NN(As[*StringBuilder](segments.A[1])).ToString__String().Ref())
				NN(As[*StringBuilder](segments.A[1])).SetLength_I__V(0)
				part = 0 }; default:
		NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch)}}
	i = i + 1
//line :26:1
	continue L1 }; break L1
}


































	if part == 1 { NN(limits).Add_O__Z(Double_ValueOf_D__Double(limit)); NN(formats).Add_O__Z(NN(As[*StringBuilder](segments.A[1])).ToString__String().Ref()) }
	t.F_choiceLimits = NN(limits).Stream__Stream().MapToDouble_ToDoubleFunction__DoubleStream(&ToDoubleFunction_Fn{Fn: func(p0 any) float64 { var d *Double = Double_Cast(p0); return NN(d).DoubleValue__D() }}).ToArray__D1()


	t.F_choiceFormats = A2g_CastArray[*RefArray](NN(formats).ToArray_O1__O1(NewRefArray(String_class, 0)).Ref(), String_class.ArrayClass())
}
func ChoiceFormat_StringToNum_String__D(str *String) float64 {
	{ var tmp1 *String = str; var tmp2 int32 = -1; switch NN(tmp1).HashCode__I() { case 8734: if tmp1.Equals_O__Z(Lit_1711) { tmp2 = 0 }; case 10129: if tmp1.Equals_O__Z(Lit_1712) { tmp2 = 1 }}; switch tmp2 { case 0: return PosInf64; case 1: return NegInf64; default: return Double_ParseDouble_String__D(str)} }; panic("a2g: unreachable")
}
func (t *ChoiceFormat) ToPattern__String() *String {
	var result *StringBuilder = StringBuilder_New(); var i int32 = 0
L1: for {
	if i < int32(len(t.F_choiceLimits.A)) {
		if i == 0 { } else { NN(result).Append_C__StringBuilder(124) }
		var less float64 = ChoiceFormat_PreviousDouble_D__D(t.F_choiceLimits.A[i]); var tryLessOrEqual float64 = Math_Abs_D__D(Math_IEEEremainder_D_D__D(t.F_choiceLimits.A[i], 1.0)); var tryLess float64 = Math_Abs_D__D(Math_IEEEremainder_D_D__D(less, 1.0))


		if tryLessOrEqual < tryLess {
			NN(result).Append_D__StringBuilder(t.F_choiceLimits.A[i]); NN(result).Append_C__StringBuilder(35) } else {

				if t.F_choiceLimits.A[i] == PosInf64 {
					NN(result).Append_String__StringBuilder(Lit_1711) } else {
//line :82:1
						if t.F_choiceLimits.A[i] == NegInf64 {

							NN(result).Append_String__StringBuilder(Lit_1712) } else {
								NN(result).Append_D__StringBuilder(less) } }
				NN(result).Append_C__StringBuilder(60) }
		var text *String = As[*String](t.F_choiceFormats.A[i]); var needQuote bool; var tmp1 bool; var tmp2 bool; var tmp3 bool
		tmp3 = NN(text).IndexOf_I__I(60) >= 0; if !tmp3 { tmp3 = NN(text).IndexOf_I__I(35) >= 0 }; tmp2 = tmp3; if !tmp2 {
			tmp2 = NN(text).IndexOf_I__I(8804) >= 0 }
//line :88:1
		tmp1 = tmp2; if !tmp1 {

			tmp1 = NN(text).IndexOf_I__I(124) >= 0 }
//line :88:1
		needQuote = tmp1


		if needQuote { NN(result).Append_C__StringBuilder(39) }
		if NN(text).IndexOf_I__I(39) < 0 {
			NN(result).Append_String__StringBuilder(text) } else {
				var j int32 = 0; L2: for {
					if j < NN(text).Length__I() {
						var c uint16 = NN(text).CharAt_I__C(j)
						NN(result).Append_C__StringBuilder(c)
						if int32(c) == 39 {
							NN(result).Append_C__StringBuilder(c); j = j + 1; continue L2 } else {
								j = j + 1; continue L2 } }
//line :94:1
					break L2
				}
			}




		if needQuote {
			NN(result).Append_C__StringBuilder(39); i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :73:1
	break L1
}





























	return NN(result).ToString__String()
}
func ChoiceFormat_New_String(p0 *String) *ChoiceFormat { t := &ChoiceFormat{}; t.Ctor_String(p0); return t }
//line :106:1
func (t *ChoiceFormat) Ctor_String(newPattern *String) { t.NumberFormat.Ctor(t)
	Objects_RequireNonNull_O_String__O(newPattern.Ref(), Lit_1708)
	t.ApplyPatternImpl_String__V(newPattern)
}
func ChoiceFormat_New_D1_String1(p0 *DoubleArray, p1 *RefArray) *ChoiceFormat { t := &ChoiceFormat{}; t.Ctor_D1_String1(p0, p1); return t }
//line :110:1
func (t *ChoiceFormat) Ctor_D1_String1(limits *DoubleArray, formats *RefArray) { t.NumberFormat.Ctor(t)
	t.SetChoicesImpl_D1_String1__V(limits, formats)
}
func (t *ChoiceFormat) SetChoices_D1_String1__V(limits *DoubleArray, formats *RefArray) {
	t.SetChoicesImpl_D1_String1__V(limits, formats)
}
func (t *ChoiceFormat) SetChoicesImpl_D1_String1__V(limits *DoubleArray, formats *RefArray) {
	var tmp1 int32 = int32(len(limits.A)); if tmp1 == int32(len(formats.A)) { } else {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1713))) }
	t.F_choiceLimits = Arrays_CopyOf_D1_I__D1(limits, int32(len(limits.A)))
	t.F_choiceFormats = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(formats, int32(len(formats.A))).Ref(), String_class.ArrayClass())
}
func (t *ChoiceFormat) GetLimits__D1() *DoubleArray {
	var tmp1 *DoubleArray = t.F_choiceLimits; return Arrays_CopyOf_D1_I__D1(tmp1, int32(len(t.F_choiceLimits.A)))
}
func (t *ChoiceFormat) GetFormats__O1() *RefArray {
	var tmp1 *RefArray = t.F_choiceFormats; return Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_choiceFormats.A)))
}
func (t *ChoiceFormat) Format_J_StringBuffer_FieldPosition__StringBuffer(number int64, toAppendTo *StringBuffer, status FieldPosition_I) *StringBuffer {

	return t.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(float64(number), StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo), status).AsStringBuffer__StringBuffer()
}
func (t *ChoiceFormat) Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(number int64, toAppendTo Format_StringBuf, status FieldPosition_I) Format_StringBuf {

	return t.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(float64(number), toAppendTo, status)
}
func (t *ChoiceFormat) Format_D_StringBuffer_FieldPosition__StringBuffer(number float64, toAppendTo *StringBuffer, status FieldPosition_I) *StringBuffer {

	return t.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(number, StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo), status).AsStringBuffer__StringBuffer()
}
func (t *ChoiceFormat) Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(number float64, toAppendTo Format_StringBuf, status FieldPosition_I) Format_StringBuf {

	var i int32 = 0
	i = 0
L1: for { if i < int32(len(t.F_choiceLimits.A)) {
	if number >= t.F_choiceLimits.A[i] { } else { break L1 }
	i = i + 1
//line :144:1
	continue L1 }; break L1
}

	i = i - 1
	if i < 0 { i = 0 }
	return toAppendTo.Append_String__Format_StringBuf(As[*String](t.F_choiceFormats.A[i]))
}
func (t *ChoiceFormat) Parse_String_ParsePosition__Number(text *String, status *ParsePosition) Number_I {
	var start int32 = status.F_index
	var furthest int32 = start
	var bestNumber float64 = NaN64
	var tempNumber float64 = 0.0; var i int32 = 0
L1: for {
	if i < int32(len(t.F_choiceFormats.A)) {
		var tempString *String = As[*String](t.F_choiceFormats.A[i])
		if NN(text).RegionMatches_I_String_I_I__Z(start, tempString, 0, NN(tempString).Length__I()) {

			status.F_index = start + NN(tempString).Length__I()
			tempNumber = t.F_choiceLimits.A[i]
			if status.F_index > furthest {

				furthest = status.F_index
				bestNumber = tempNumber
				if furthest == NN(text).Length__I() { } else { i = i + 1; continue L1 } } else {
					i = i + 1; continue L1 } } else {
						i = i + 1; continue L1 } }
//line :156:1
	break L1
}












	status.F_index = furthest
	if status.F_index == start { status.F_errorIndex = furthest }
	return Up_Double_Number(Double_ValueOf_D__Double(bestNumber))
}
func (t *ChoiceFormat) IsStrict__Z() bool {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_1714)))
}
func (t *ChoiceFormat) SetStrict_Z__V(strict bool) {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_1714)))
}
func ChoiceFormat_NextDouble_D__D(d float64) float64 {
	return Math_NextUp_D__D(d)
}
func ChoiceFormat_NextDouble_D_Z__D(d float64, positive bool) float64 {
	if positive { return Math_NextUp_D__D(d) } else { return Math_NextDown_D__D(d)
	} }
func ChoiceFormat_PreviousDouble_D__D(d float64) float64 {
	return Math_NextDown_D__D(d)
}
func (t *ChoiceFormat) Clone__O() any {
	var other *ChoiceFormat = ChoiceFormat_Cast(t.NumberFormat.Impl_Clone__O(t))
	other.F_choiceLimits = NN(t.F_choiceLimits).Copy()
	other.F_choiceFormats = NN(t.F_choiceFormats).Copy()
//line :190:1
	return other.Ref()
}



func (t *ChoiceFormat) HashCode__I() int32 {
	var result int32 = int32(len(t.F_choiceLimits.A))
	if int32(len(t.F_choiceFormats.A)) > 0 {
		var tmp1 *RefArray = t.F_choiceFormats; result = result ^ NN(As[*String](tmp1.A[int32(len(t.F_choiceFormats.A))-1])).HashCode__I() }
//line :196:1
	return result
}






func (t *ChoiceFormat) ToString__String() *String {
	return Lit_1715.Formatted_O1__String(RefArrayOf(Object_class, t.ToPattern__String().Ref()))
}
func (t *ChoiceFormat) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = obj == nil; if !tmp2 { tmp2 = !(t.GetClass__Class() == GetClass(obj)) }; tmp1 = tmp2
//line :208:1
		if tmp1 { return false } else {



			var other *ChoiceFormat = ChoiceFormat_Cast(obj); var tmp3 bool; var tmp4 *DoubleArray = t.F_choiceLimits
			tmp3 = Arrays_Equals_D1_D1__Z(tmp4, other.F_choiceLimits); if tmp3 {
				var tmp5 *RefArray = t.F_choiceFormats; tmp3 = Arrays_Equals_O1_O1__Z(tmp5, other.F_choiceFormats) }
//line :213:1
			return tmp3 } } }
type ChoiceFormat struct{ NumberFormat; F_choiceLimits *DoubleArray; F_choiceFormats *RefArray }

const ChoiceFormat_serialVersionUID int64 = 1795184449645032964

func (t *ChoiceFormat) Format_O__String(p0 any) *String { return t.Impl_Format_O__String(t, p0) }

func (t *ChoiceFormat) IsGroupingUsed__Z() bool { return t.Impl_IsGroupingUsed__Z(t) }

func (t *ChoiceFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(t, p0) }

func (t *ChoiceFormat) Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(p0 any, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf { return t.Impl_Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(t, p0, p1, p2) }

func (t *ChoiceFormat) GetMaximumFractionDigits__I() int32 { return t.Impl_GetMaximumFractionDigits__I(t) }

func (t *ChoiceFormat) GetMaximumIntegerDigits__I() int32 { return t.Impl_GetMaximumIntegerDigits__I(t) }

func (t *ChoiceFormat) Format_D__String(p0 float64) *String { return t.Impl_Format_D__String(t, p0) }

func (t *ChoiceFormat) ParseObject_String__O(p0 *String) any { return t.Impl_ParseObject_String__O(t, p0) }

func (t *ChoiceFormat) SetMaximumIntegerDigits_I__V(p0 int32) { t.Impl_SetMaximumIntegerDigits_I__V(t, p0) }

func (t *ChoiceFormat) GetCurrency__Currency() *Currency { return t.Impl_GetCurrency__Currency(t) }

func (t *ChoiceFormat) SetRoundingMode_RoundingMode__V(p0 *RoundingMode) { t.Impl_SetRoundingMode_RoundingMode__V(t, p0) }

func (t *ChoiceFormat) GetMinimumIntegerDigits__I() int32 { return t.Impl_GetMinimumIntegerDigits__I(t) }

func (t *ChoiceFormat) Format_O_StringBuffer_FieldPosition__StringBuffer(p0 any, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer { return t.Impl_Format_O_StringBuffer_FieldPosition__StringBuffer(t, p0, p1, p2) }

func (t *ChoiceFormat) FastFormat_D__String(p0 float64) *String { return t.Impl_FastFormat_D__String(t, p0) }

func (t *ChoiceFormat) SetCurrency_Currency__V(p0 *Currency) { t.Impl_SetCurrency_Currency__V(t, p0) }

func (t *ChoiceFormat) SetGroupingUsed_Z__V(p0 bool) { t.Impl_SetGroupingUsed_Z__V(t, p0) }

func (t *ChoiceFormat) ParseObject_String_ParsePosition__O(p0 *String, p1 *ParsePosition) any { return t.Impl_ParseObject_String_ParsePosition__O(t, p0, p1) }

func (t *ChoiceFormat) Parse_String__Number(p0 *String) Number_I { return t.Impl_Parse_String__Number(t, p0) }

func (t *ChoiceFormat) Format_J__String(p0 int64) *String { return t.Impl_Format_J__String(t, p0) }

func (t *ChoiceFormat) CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *ChoiceFormat) IsParseIntegerOnly__Z() bool { return t.Impl_IsParseIntegerOnly__Z(t) }

func (t *ChoiceFormat) SetParseIntegerOnly_Z__V(p0 bool) { t.Impl_SetParseIntegerOnly_Z__V(t, p0) }

func (t *ChoiceFormat) SetMaximumFractionDigits_I__V(p0 int32) { t.Impl_SetMaximumFractionDigits_I__V(t, p0) }

func (t *ChoiceFormat) CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(t, p0) }

func (t *ChoiceFormat) FormatToCharacterIterator_O__AttributedCharacterIterator(p0 any) AttributedCharacterIterator { return t.Impl_FormatToCharacterIterator_O__AttributedCharacterIterator(t, p0) }

func (t *ChoiceFormat) SetMinimumFractionDigits_I__V(p0 int32) { t.Impl_SetMinimumFractionDigits_I__V(t, p0) }

func (t *ChoiceFormat) GetMinimumFractionDigits__I() int32 { return t.Impl_GetMinimumFractionDigits__I(t) }

func (t *ChoiceFormat) SetMinimumIntegerDigits_I__V(p0 int32) { t.Impl_SetMinimumIntegerDigits_I__V(t, p0) }

func (t *ChoiceFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *ChoiceFormat) GetRoundingMode__RoundingMode() *RoundingMode { return t.Impl_GetRoundingMode__RoundingMode(t) }

func (t *ChoiceFormat) Ref() any { if t == nil { return nil }; return t }

func (t *ChoiceFormat) GetClass__Class() *Class { return ChoiceFormat_class }

func (t *ChoiceFormat) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func ChoiceFormat_InstanceOf(x any) bool { _, ok := x.(*ChoiceFormat); return ok }

func ChoiceFormat_Cast(x any) *ChoiceFormat { if x == nil { return nil }; v, ok := x.(*ChoiceFormat); if !ok { panic(ClassCast(x, ChoiceFormat_class)) }; return v }
