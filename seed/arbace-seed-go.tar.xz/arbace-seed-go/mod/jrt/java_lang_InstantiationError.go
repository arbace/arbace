//line java_lang_InstantiationError.ae:1
package jrt








func InstantiationError_New() *InstantiationError { t := &InstantiationError{}; t.Ctor(); return t }
//line :10:1
func (t *InstantiationError) Ctor() { t.IncompatibleClassChangeError.Ctor(t) }

func InstantiationError_New_String(p0 *String) *InstantiationError { t := &InstantiationError{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *InstantiationError) Ctor_String(s *String) { t.IncompatibleClassChangeError.Ctor_String(t, s) }







type InstantiationError struct{ IncompatibleClassChangeError }

const InstantiationError_serialVersionUID int64 = -4885810657349421204

func (t *InstantiationError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InstantiationError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InstantiationError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InstantiationError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InstantiationError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InstantiationError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InstantiationError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InstantiationError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InstantiationError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InstantiationError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InstantiationError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InstantiationError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InstantiationError) Ref() any { if t == nil { return nil }; return t }

func (t *InstantiationError) GetClass__Class() *Class { return InstantiationError_class }

func (t *InstantiationError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InstantiationError) CloneShallow() any { panic(CloneNotSupported(t)) }

func InstantiationError_InstanceOf(x any) bool { _, ok := x.(*InstantiationError); return ok }

func InstantiationError_Cast(x any) *InstantiationError { if x == nil { return nil }; v, ok := x.(*InstantiationError); if !ok { panic(ClassCast(x, InstantiationError_class)) }; return v }
