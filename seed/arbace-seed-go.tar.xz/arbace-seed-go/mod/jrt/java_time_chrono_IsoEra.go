//line java_time_chrono_IsoEra.ae:1
package jrt










func IsoEra_Of_I__IsoEra(isoEra int32) *IsoEra { IsoEra_Init()
	switch isoEra { case 0: return IsoEra_BCE; case 1: return IsoEra_CE; default: panic(Thrown(DateTimeException_New_String(Concat(Lit_2205, StrOfInt(isoEra)))))}; panic("a2g: unreachable")
}
func (t *IsoEra) GetValue__I() int32 { return t.Ordinal__I() }



type IsoEra struct{ Enum }

func (t *IsoEra) Is_Era() {}

func (t *IsoEra) Is_Constable() {}

func (t *IsoEra) Is_TemporalAccessor() {}

func (t *IsoEra) Is_TemporalAdjuster() {}

var IsoEra_BCE *IsoEra

var IsoEra_CE *IsoEra

var IsoEra__VALUES *RefArray

var IsoEra_init ClassInit

func IsoEra_Init() { if !IsoEra_init.Done() { IsoEra_init.Run(IsoEra_clinit) } }

func IsoEra_clinit() { IsoEra_BCE = IsoEra_New_String_I(Lit_2203, 0); IsoEra_CE = IsoEra_New_String_I(Lit_2204, 1); IsoEra__VALUES = IsoEra_X_values__IsoEra1() }

func IsoEra_New_String_I(p0 *String, p1 int32) *IsoEra { IsoEra_Init(); t := &IsoEra{}; t.Ctor_String_I(p0, p1); return t }

func (t *IsoEra) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func IsoEra_Values__IsoEra1() *RefArray { IsoEra_Init(); return IsoEra__VALUES.Copy() }

func IsoEra_ValueOf_String__IsoEra(p0 *String) *IsoEra { IsoEra_Init(); return IsoEra_Cast(Enum_ValueOf_Class_String__Enum(IsoEra_class, p0)) }

func IsoEra_X_values__IsoEra1() *RefArray { IsoEra_Init(); return RefArrayOf(IsoEra_class, IsoEra_BCE, IsoEra_CE) }

func (t *IsoEra) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.chrono.IsoEra.describeConstable()Ljava/util/Optional;")) }

func (t *IsoEra) Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange { return Era_Range_TemporalField__ValueRange(t, p0) }

func (t *IsoEra) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *IsoEra) IsSupported_TemporalField__Z(p0 TemporalField) bool { return Era_IsSupported_TemporalField__Z(t, p0) }

func (t *IsoEra) GetDisplayName_TextStyle_Locale__String(p0 *TextStyle, p1 *Locale) *String { return Era_GetDisplayName_TextStyle_Locale__String(t, p0, p1) }

func (t *IsoEra) AdjustInto_Temporal__Temporal(p0 Temporal) Temporal { return Era_AdjustInto_Temporal__Temporal(t, p0) }

func (t *IsoEra) Query_TemporalQuery__O(p0 TemporalQuery) any { return Era_Query_TemporalQuery__O(t, p0) }

func (t *IsoEra) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *IsoEra) GetLong_TemporalField__J(p0 TemporalField) int64 { return Era_GetLong_TemporalField__J(t, p0) }

func (t *IsoEra) Get_TemporalField__I(p0 TemporalField) int32 { return Era_Get_TemporalField__I(t, p0) }

func (t *IsoEra) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *IsoEra) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *IsoEra) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IsoEra) Ref() any { if t == nil { return nil }; return t }

func (t *IsoEra) GetClass__Class() *Class { return IsoEra_class }

func (t *IsoEra) CloneShallow() any { panic(CloneNotSupported(t)) }

func IsoEra_InstanceOf(x any) bool { _, ok := x.(*IsoEra); return ok }

func IsoEra_Cast(x any) *IsoEra { if x == nil { return nil }; v, ok := x.(*IsoEra); if !ok { panic(ClassCast(x, IsoEra_class)) }; return v }
