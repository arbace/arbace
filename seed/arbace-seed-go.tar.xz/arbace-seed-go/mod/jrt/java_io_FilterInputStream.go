//line java_io_FilterInputStream.ae:1
package jrt








func FilterInputStream_New_InputStream(p0 InputStream_I) *FilterInputStream { t := &FilterInputStream{}; t.Ctor_InputStream(t, p0); return t }
//line :10:1
func (t *FilterInputStream) Ctor_InputStream(this FilterInputStream_I, in InputStream_I) { t.InputStream.Ctor(this); t.F_in.Store(in) }

func (t *FilterInputStream) Impl_Read__I(this FilterInputStream_I) int32 { return t.F_in.Load().Read__I() }

func (t *FilterInputStream) Impl_Read_B1__I(this FilterInputStream_I, b *ByteArray) int32 {
	return this.Read_B1_I_I__I(b, 0, int32(len(b.A)))
}
func (t *FilterInputStream) Impl_Read_B1_I_I__I(this FilterInputStream_I, b *ByteArray, off, len_ int32) int32 {
	return t.F_in.Load().Read_B1_I_I__I(b, off, len_)
}
func (t *FilterInputStream) Impl_Skip_J__J(this FilterInputStream_I, n int64) int64 {
	return t.F_in.Load().Skip_J__J(n)
}
func (t *FilterInputStream) Impl_Available__I(this FilterInputStream_I) int32 {
	return t.F_in.Load().Available__I()
}
func (t *FilterInputStream) Impl_Close__V(this FilterInputStream_I) { t.F_in.Load().Close__V() }

func (t *FilterInputStream) Impl_Mark_I__V(this FilterInputStream_I, readlimit int32) { t.F_in.Load().Mark_I__V(readlimit) }

func (t *FilterInputStream) Impl_Reset__V(this FilterInputStream_I) { t.F_in.Load().Reset__V() }

func (t *FilterInputStream) Impl_MarkSupported__Z(this FilterInputStream_I) bool { return t.F_in.Load().MarkSupported__Z() }



type FilterInputStream struct{ InputStream; F_in Volatile[InputStream_I] }

type FilterInputStream_I interface{ InputStream_I; Closeable; AutoCloseable; Self_FilterInputStream() *FilterInputStream; Read__I() int32; Read_B1__I(p0 *ByteArray) int32; Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; Skip_J__J(p0 int64) int64; Available__I() int32; Close__V(); Mark_I__V(p0 int32); Reset__V(); MarkSupported__Z() bool }

func (t *FilterInputStream) Self_FilterInputStream() *FilterInputStream { return t }

func (t *FilterInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *FilterInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *FilterInputStream) Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_Read_B1_I_I__I(t, p0, p1, p2) }

func (t *FilterInputStream) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *FilterInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *FilterInputStream) Close__V() { t.Impl_Close__V(t) }

func (t *FilterInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *FilterInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *FilterInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *FilterInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *FilterInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *FilterInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *FilterInputStream) Available__I() int32 { return t.Impl_Available__I(t) }

func (t *FilterInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *FilterInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *FilterInputStream) GetClass__Class() *Class { return FilterInputStream_class }

func (t *FilterInputStream) ToString__String() *String { return Object_toString(t) }

func (t *FilterInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FilterInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func FilterInputStream_InstanceOf(x any) bool { _, ok := x.(FilterInputStream_I); return ok }

func FilterInputStream_Cast(x any) FilterInputStream_I { if x == nil { return nil }; v, ok := x.(FilterInputStream_I); if !ok { panic(ClassCast(x, FilterInputStream_class)) }; return v }
