//line hostfs.ae:1
package jrt








// HostFS is the file system calls of java.io.File beyond Host's: a Host may implement it.
type HostFS /*line :13:1*/ interface {
	// Access is access(2): mode 4 read, 2 write, 1 execute (0: exists).
	Access(name string, mode uint32) error
	// Chmod sets the Unix permission bits (07777) of name.
	Chmod(name string, mode uint32) error
	// Chtimes sets name's modification time, in milliseconds since the epoch; the access
	// time is kept.
	Chtimes(name string, mtimeMillis int64) error
	// Realpath is realpath(3): name with every symbolic link, . and .. resolved; an error
	// that is fs.ErrNotExist or fs.ErrPermission when a name of the path does not exist, is not a
	// directory, or cannot be searched.
	Realpath(name string) (string, error)
	// Statfs tells the space of the file system holding name, and its longest name.
	Statfs(name string) (HostFSInfo, error) }
// HostFSInfo is what Statfs tells: bytes in all, free, and free to the user; the longest name.
type HostFSInfo /*line :30:1*/ struct{ Total, Free, Usable, NameMax int64 }
// CurrentHostFS is the current host as a HostFS, or nil when it is not one.
func CurrentHostFS() HostFS {


	fs, ok := CurrentHost().(HostFS)
	if !ok {
		return nil
	}
	return fs
}
