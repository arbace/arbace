//line java_util_SortedSet.ae:1
package jrt



















func SortedSet_Spliterator__Spliterator(this SortedSet) Spliterator {
	return SortedSet_1_New_SortedSet_Collection_I(this, this, 21)
}




func (t *SortedSet_1) GetComparator__Comparator() Comparator {
	return t.F_this_0.Comparator__Comparator()
}
func SortedSet_AddFirst_O__V(this SortedSet, e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SortedSet_AddLast_O__V(this SortedSet, e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SortedSet_GetFirst__O(this SortedSet) any { return this.First__O() }

func SortedSet_GetLast__O(this SortedSet) any { return this.Last__O() }

func SortedSet_RemoveFirst__O(this SortedSet) any {
	var e any = this.First__O(); this.Remove_O__Z(e); return e
}
func SortedSet_RemoveLast__O(this SortedSet) any {
	var e any = this.Last__O(); this.Remove_O__Z(e); return e
}
func SortedSet_Reversed__SortedSet(this SortedSet) SortedSet {
	return ReverseOrderSortedSetView_Of_SortedSet__SortedSet(this)
}


type SortedSet interface{ Object_I; Set; SequencedSet; Collection; SequencedCollection; Iterable; Is_SortedSet(); Comparator__Comparator() Comparator; SubSet_O_O__SortedSet(p0, p1 any) SortedSet; HeadSet_O__SortedSet(p0 any) SortedSet; TailSet_O__SortedSet(p0 any) SortedSet; First__O() any; Last__O() any; Spliterator__Spliterator() Spliterator; AddFirst_O__V(p0 any); AddLast_O__V(p0 any); GetFirst__O() any; GetLast__O() any; RemoveFirst__O() any; RemoveLast__O() any; Reversed__SortedSet() SortedSet; Reversed__SequencedSet() SequencedSet; Reversed__SequencedCollection() SequencedCollection }

func SortedSet_Reversed__SequencedSet(this SortedSet) SequencedSet { return this.Reversed__SortedSet() }

func SortedSet_Reversed__SequencedCollection(this SortedSet) SequencedCollection { return this.Reversed__SortedSet() }

func SortedSet_InstanceOf(x any) bool { _, ok := x.(SortedSet); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SortedSet_class) } }; return ok }

func SortedSet_Cast(x any) SortedSet { if x == nil { return nil }; v, ok := x.(SortedSet); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SortedSet_class) } }; if !ok { panic(ClassCast(x, SortedSet_class)) }; return v }



type SortedSet_1 struct{ Spliterators_IteratorSpliterator; F_this_0 SortedSet }

func SortedSet_1_New_SortedSet_Collection_I(p0 SortedSet, p1 Collection, p2 int32) *SortedSet_1 { t := &SortedSet_1{}; t.Ctor_SortedSet_Collection_I(p0, p1, p2); return t }

func (t *SortedSet_1) Ctor_SortedSet_Collection_I(this_0 SortedSet, p Collection, p_2 int32) { A2g_NotNull[SortedSet](this_0); t.F_this_0 = this_0; t.Spliterators_IteratorSpliterator.Ctor_Collection_I(t, p, p_2) }

func (t *SortedSet_1) TrySplit__Spliterator() Spliterator { return t.Impl_TrySplit__Spliterator(t) }

func (t *SortedSet_1) ForEachRemaining_Consumer__V(p0 Consumer) { t.Impl_ForEachRemaining_Consumer__V(t, p0) }

func (t *SortedSet_1) TryAdvance_Consumer__Z(p0 Consumer) bool { return t.Impl_TryAdvance_Consumer__Z(t, p0) }

func (t *SortedSet_1) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *SortedSet_1) Characteristics__I() int32 { return t.Impl_Characteristics__I(t) }

func (t *SortedSet_1) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *SortedSet_1) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *SortedSet_1) Ref() any { if t == nil { return nil }; return t }

func (t *SortedSet_1) GetClass__Class() *Class { return SortedSet_1_class }

func (t *SortedSet_1) ToString__String() *String { return Object_toString(t) }

func (t *SortedSet_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SortedSet_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func SortedSet_1_InstanceOf(x any) bool { _, ok := x.(*SortedSet_1); return ok }

func SortedSet_1_Cast(x any) *SortedSet_1 { if x == nil { return nil }; v, ok := x.(*SortedSet_1); if !ok { panic(ClassCast(x, SortedSet_1_class)) }; return v }
