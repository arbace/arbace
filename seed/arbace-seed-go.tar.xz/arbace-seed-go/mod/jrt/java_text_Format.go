//line java_text_Format.ae:1
package jrt










func (t *Format) Ctor(this Format_I) {}

func (t *Format) Impl_Format_O__String(this Format_I, obj any) *String {
	if Lit_1775.Equals_O__Z(NN(this.GetClass__Class()).GetPackageName__String().Ref()) {
		return this.Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(obj, StringBufFactory_Of__Format_StringBuf(), FieldPosition_New_I(0)).ToString__String() } else {
			return NN(this.Format_O_StringBuffer_FieldPosition__StringBuffer(obj, StringBuffer_New(), FieldPosition_New_I(0))).ToString__String()
		}
}


func (t *Format) Impl_Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(this Format_I, obj any, toAppendTo Format_StringBuf, pos FieldPosition_I) Format_StringBuf {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_1850)))
}
func (t *Format) Impl_FormatToCharacterIterator_O__AttributedCharacterIterator(this Format_I, obj any) AttributedCharacterIterator {
	return this.CreateAttributedCharacterIterator_String__AttributedCharacterIterator(this.Format_O__String(obj))
}


func (t *Format) Impl_ParseObject_String__O(this Format_I, source *String) any {
	var pos *ParsePosition = ParsePosition_New_I(0); var result any = this.ParseObject_String_ParsePosition__O(source, pos)

	if pos.F_index == 0 {
		panic(Thrown(ParseException_New_String_I(Lit_1851, pos.F_errorIndex))) }
//line :31:1
	return result
}




func (t *Format) Impl_Clone__O(this Format_I) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = A2g_ObjectClone(this); return nil }(); if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2); panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else { panic(tmp2) } }; return tmp1
}
func (t *Format) Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(this Format_I, s *String) AttributedCharacterIterator {
	var as *AttributedString = AttributedString_New_String(s); return NN(as).GetIterator__AttributedCharacterIterator()
}
func (t *Format) Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(this Format_I, iterators *RefArray) AttributedCharacterIterator {

	var as *AttributedString = AttributedString_New_AttributedCharacterIterator1(iterators); return NN(as).GetIterator__AttributedCharacterIterator()
}
func (t *Format) Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(this Format_I, string_ *String, key AttributedCharacterIterator_Attribute_I, value any) AttributedCharacterIterator {


	var as *AttributedString = AttributedString_New_String(string_); NN(as).AddAttribute_AttributedCharacterIterator_Attribute_O__V(key, value); return NN(as).GetIterator__AttributedCharacterIterator()
}
func (t *Format) Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(this Format_I, iterator AttributedCharacterIterator, key AttributedCharacterIterator_Attribute_I, value any) AttributedCharacterIterator {



	var as *AttributedString = AttributedString_New_AttributedCharacterIterator(iterator); NN(as).AddAttribute_AttributedCharacterIterator_Attribute_O__V(key, value); return NN(as).GetIterator__AttributedCharacterIterator()
}





func Format_Field_New_String(p0 *String) *Format_Field { Format_Field_Init(); t := &Format_Field{}; t.Ctor_String(t, p0); return t }
//line :63:1
func (t *Format_Field) Ctor_String(this Format_Field_I, name *String) { t.AttributedCharacterIterator_Attribute.Ctor_String(this, name) }





type Format struct{ Object }

type Format_I interface{ Object_I; Serializable; Cloneable; Self_Format() *Format; Format_O__String(p0 any) *String; Format_O_StringBuffer_FieldPosition__StringBuffer(p0 any, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer; Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(p0 any, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf; FormatToCharacterIterator_O__AttributedCharacterIterator(p0 any) AttributedCharacterIterator; ParseObject_String_ParsePosition__O(p0 *String, p1 *ParsePosition) any; ParseObject_String__O(p0 *String) any; CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator; CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator; CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator; CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator }

func (t *Format) Self_Format() *Format { return t }

func (t *Format) Is_Serializable() {}

func (t *Format) Is_Cloneable() {}

const Format_serialVersionUID int64 = -299282585814624189

func Format_InstanceOf(x any) bool { _, ok := x.(Format_I); return ok }

func Format_Cast(x any) Format_I { if x == nil { return nil }; v, ok := x.(Format_I); if !ok { panic(ClassCast(x, Format_class)) }; return v }



type Format_Field struct{ AttributedCharacterIterator_Attribute }

type Format_Field_I interface{ AttributedCharacterIterator_Attribute_I; Serializable; Self_Format_Field() *Format_Field }

func (t *Format_Field) Self_Format_Field() *Format_Field { return t }

const Format_Field_serialVersionUID int64 = 276966692217360283

var Format_Field_init ClassInit

func Format_Field_Init() { if !Format_Field_init.Done() { Format_Field_init.Run(Format_Field_clinit) } }

func Format_Field_clinit() { AttributedCharacterIterator_Attribute_Init() }

func (t *Format_Field) GetName__String() *String { return t.Impl_GetName__String(t) }

func (t *Format_Field) ReadResolve__O() any { return t.Impl_ReadResolve__O(t) }

func (t *Format_Field) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Format_Field) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Format_Field) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Format_Field) Ref() any { if t == nil { return nil }; return t }

func (t *Format_Field) GetClass__Class() *Class { return Format_Field_class }

func (t *Format_Field) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Format_Field) CloneShallow() any { panic(CloneNotSupported(t)) }

func Format_Field_InstanceOf(x any) bool { _, ok := x.(Format_Field_I); return ok }

func Format_Field_Cast(x any) Format_Field_I { if x == nil { return nil }; v, ok := x.(Format_Field_I); if !ok { panic(ClassCast(x, Format_Field_class)) }; return v }



type Format_FieldDelegate interface{ Object_I; Is_Format_FieldDelegate(); Formatted_Format_Field_O_I_I_Format_StringBuf__V(p0 Format_Field_I, p1 any, p2, p3 int32, p4 Format_StringBuf); Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(p0 int32, p1 Format_Field_I, p2 any, p3, p4 int32, p5 Format_StringBuf) }

func Format_FieldDelegate_InstanceOf(x any) bool { _, ok := x.(Format_FieldDelegate); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Format_FieldDelegate_class) } }; return ok }

func Format_FieldDelegate_Cast(x any) Format_FieldDelegate { if x == nil { return nil }; v, ok := x.(Format_FieldDelegate); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Format_FieldDelegate_class) } }; if !ok { panic(ClassCast(x, Format_FieldDelegate_class)) }; return v }



type Format_StringBuf interface{ Object_I; Is_Format_StringBuf(); Length__I() int32; Substring_I_I__String(p0, p1 int32) *String; Substring_I__String(p0 int32) *String; Append_C__Format_StringBuf(p0 uint16) Format_StringBuf; Append_String__Format_StringBuf(p0 *String) Format_StringBuf; Append_I__Format_StringBuf(p0 int32) Format_StringBuf; Append_C1_I_I__Format_StringBuf(p0 *CharArray, p1, p2 int32) Format_StringBuf; Append_CharSequence_I_I__Format_StringBuf(p0 CharSequence, p1, p2 int32) Format_StringBuf; Append_StringBuffer__Format_StringBuf(p0 *StringBuffer) Format_StringBuf; IsProxyStringBuilder__Z() bool; AsStringBuffer__StringBuffer() *StringBuffer; AsStringBuilder__StringBuilder() *StringBuilder }

func Format_StringBuf_InstanceOf(x any) bool { _, ok := x.(Format_StringBuf); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Format_StringBuf_class) } }; return ok }

func Format_StringBuf_Cast(x any) Format_StringBuf { if x == nil { return nil }; v, ok := x.(Format_StringBuf); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Format_StringBuf_class) } }; if !ok { panic(ClassCast(x, Format_StringBuf_class)) }; return v }
