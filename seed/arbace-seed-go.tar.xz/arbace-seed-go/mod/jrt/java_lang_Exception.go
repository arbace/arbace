//line java_lang_Exception.ae:1
package jrt








func Exception_New() *Exception { t := &Exception{}; t.Ctor(t); return t }
//line :10:1
func (t *Exception) Ctor(this Exception_I) { t.Throwable.Ctor(this) }

func Exception_New_String(p0 *String) *Exception { t := &Exception{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *Exception) Ctor_String(this Exception_I, message *String) { t.Throwable.Ctor_String(this, message) }

func Exception_New_String_Throwable(p0 *String, p1 Throwable_I) *Exception { t := &Exception{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :14:1
func (t *Exception) Ctor_String_Throwable(this Exception_I, message *String, cause Throwable_I) { t.Throwable.Ctor_String_Throwable(this, message, cause) }


func Exception_New_Throwable(p0 Throwable_I) *Exception { t := &Exception{}; t.Ctor_Throwable(t, p0); return t }
//line :17:1
func (t *Exception) Ctor_Throwable(this Exception_I, cause Throwable_I) { t.Throwable.Ctor_Throwable(this, cause) }

func Exception_New_String_Throwable_Z_Z(p0 *String, p1 Throwable_I, p2, p3 bool) *Exception { t := &Exception{}; t.Ctor_String_Throwable_Z_Z(t, p0, p1, p2, p3); return t }
//line :19:1
func (t *Exception) Ctor_String_Throwable_Z_Z(this Exception_I, message *String, cause Throwable_I, enableSuppression, writableStackTrace bool) { t.Throwable.Ctor_String_Throwable_Z_Z(this, message, cause, enableSuppression, writableStackTrace) }












type Exception struct{ Throwable }

type Exception_I interface{ Throwable_I; Serializable; Self_Exception() *Exception }

func (t *Exception) Self_Exception() *Exception { return t }

const Exception_serialVersionUID int64 = -3387516993124229948

func (t *Exception) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *Exception) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *Exception) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *Exception) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *Exception) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *Exception) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *Exception) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *Exception) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *Exception) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *Exception) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *Exception) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *Exception) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Exception) Ref() any { if t == nil { return nil }; return t }

func (t *Exception) GetClass__Class() *Class { return Exception_class }

func (t *Exception) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Exception) CloneShallow() any { panic(CloneNotSupported(t)) }

func Exception_InstanceOf(x any) bool { _, ok := x.(Exception_I); return ok }

func Exception_Cast(x any) Exception_I { if x == nil { return nil }; v, ok := x.(Exception_I); if !ok { panic(ClassCast(x, Exception_class)) }; return v }
