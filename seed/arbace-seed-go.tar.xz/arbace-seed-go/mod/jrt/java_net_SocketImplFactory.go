//line java_net_SocketImplFactory.ae:1
package jrt






type SocketImplFactory interface{ Object_I; Is_SocketImplFactory(); CreateSocketImpl__SocketImpl() SocketImpl_I }

func SocketImplFactory_InstanceOf(x any) bool { _, ok := x.(SocketImplFactory); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SocketImplFactory_class) } }; return ok }

func SocketImplFactory_Cast(x any) SocketImplFactory { if x == nil { return nil }; v, ok := x.(SocketImplFactory); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SocketImplFactory_class) } }; if !ok { panic(ClassCast(x, SocketImplFactory_class)) }; return v }
