//line java_nio_ByteOrder.ae:1
package jrt











func ByteOrder_NativeOrder__ByteOrder() *ByteOrder { ByteOrder_Init(); return ByteOrder_NATIVE_ORDER }



type ByteOrder struct{ Enum }

func (t *ByteOrder) Is_Constable() {}

var ByteOrder_LITTLE_ENDIAN *ByteOrder

var ByteOrder_BIG_ENDIAN *ByteOrder

var ByteOrder__VALUES *RefArray

var ByteOrder_NATIVE_ORDER *ByteOrder

var ByteOrder_init ClassInit

func ByteOrder_Init() { if !ByteOrder_init.Done() { ByteOrder_init.Run(ByteOrder_clinit) } }

func ByteOrder_clinit() { ByteOrder_LITTLE_ENDIAN = ByteOrder_New_String_I(Lit_1493, 0); ByteOrder_BIG_ENDIAN = ByteOrder_New_String_I(Lit_1494, 1); ByteOrder__VALUES = ByteOrder_X_values__ByteOrder1(); var tmp1 *ByteOrder; if /*line :11:1*/ NN(Unsafe_GetUnsafe__Unsafe()).IsBigEndian__Z() { tmp1 = ByteOrder_BIG_ENDIAN } else { tmp1 = ByteOrder_LITTLE_ENDIAN
}; ByteOrder_NATIVE_ORDER = tmp1 }






















func ByteOrder_New_String_I(p0 *String, p1 int32) *ByteOrder { ByteOrder_Init(); t := &ByteOrder{}; t.Ctor_String_I(p0, p1); return t }

func (t *ByteOrder) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func ByteOrder_Values__ByteOrder1() *RefArray { ByteOrder_Init(); return ByteOrder__VALUES.Copy() }

func ByteOrder_ValueOf_String__ByteOrder(p0 *String) *ByteOrder { ByteOrder_Init(); return ByteOrder_Cast(Enum_ValueOf_Class_String__Enum(ByteOrder_class, p0)) }

func ByteOrder_X_values__ByteOrder1() *RefArray { ByteOrder_Init(); return RefArrayOf(ByteOrder_class, ByteOrder_LITTLE_ENDIAN, ByteOrder_BIG_ENDIAN) }

func (t *ByteOrder) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ByteOrder) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ByteOrder) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ByteOrder) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.nio.ByteOrder.describeConstable()Ljava/util/Optional;")) }

func (t *ByteOrder) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ByteOrder) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ByteOrder) Ref() any { if t == nil { return nil }; return t }

func (t *ByteOrder) GetClass__Class() *Class { return ByteOrder_class }

func (t *ByteOrder) CloneShallow() any { panic(CloneNotSupported(t)) }

func ByteOrder_InstanceOf(x any) bool { _, ok := x.(*ByteOrder); return ok }

func ByteOrder_Cast(x any) *ByteOrder { if x == nil { return nil }; v, ok := x.(*ByteOrder); if !ok { panic(ClassCast(x, ByteOrder_class)) }; return v }
