//line class.ae:1
package jrt

import (
	"reflect"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
)
// Kind is the kind of a class (ClassInfo.Kind).
type Kind uint8

const (
	KindClass Kind = iota
	KindInterface
	KindEnum
	KindRecord
	KindAnnotation
	KindArray
	KindPrimitive
)
const (
	AccPublic       int32 = 1
	AccPrivate      int32 = 2
	AccProtected    int32 = 4
	AccStatic       int32 = 8
	AccFinal        int32 = 16
	AccSynchronized int32 = 32
	AccVolatile     int32 = 64
	AccBridge       int32 = 64
	AccTransient    int32 = 128
	AccVarargs      int32 = 128; AccNative int32 = 256; AccInterface int32 = 512; AccAbstract int32 = 1024; AccSynthetic int32 = 4096; AccAnnotation int32 = 8192; AccEnum int32 = 16384)
// ClassInfo describes a class of the closed world (A2G-SPEC §5.11). a2g's a2g_classes.go
// registers one per class with Define at Go package initialization, giving Name, Modifiers,
// Kind, Super, Interfaces, Declaring, Simple and Go; the fields holding functions and member
// tables (IsInstance, Init, Enum, FromFn, Fields, Methods, Ctors) may refer to class variables
// of their own package and are therefore set in an init function, through Info (Go rejects
// initialization cycles that Java's classes have). Reflection's use of the member tables is
// phase 2's (JRT-NOTES.md).
type ClassInfo /*line :48:1*/ struct {
	// the binary name, "arbace.lang.PersistentVector$Node"
	Name string
	// java.lang.reflect.Modifier bits
	Modifiers int32
	Kind      Kind
	// the superclass; nil for Object, interfaces, primitive types
	Super /*line :52:1*/*Class
	// the direct superinterfaces, in declaration order
	Interfaces /*line :53:1*/[]*Class
	// the enclosing class of a member class
	Declaring /*line :54:1*/*Class
	// the simple name, when it is not the binary name's last part
	Simple string
	// the Go type's qualified name, "arbace/lang.PersistentVector_Node",
	// for stack traces (JRT-NOTES.md, "Stack traces")
	Go      string
	Fields  /*line :58:1*/[]FieldInfo
	Methods []MethodInfo
	Ctors   []CtorInfo
	// the member table as data, decoded into Fields, Methods and Ctors at their first use (EnsureMembers)
	Table /*line :61:1*/*MemberTable
	// C_InstanceOf
	IsInstance /*line :62:1*/ func(any) bool
	// C_Init, for Class.forName(name, true, ...)
	Init /*line :63:1*/ func()
	// the enum constants in order
	Enum /*line :64:1*/ func() *RefArray
	// for a functional interface: wraps an IFn into its adapter
	FromFn /*line :65:1*/ func(any) any }
// FieldInfo is one field of a member table (§5.11); Get and Set box and unbox as
// Field.get/set do.
//line :67:1
type FieldInfo /*line :70:1*/ struct{ Name string; Type *Class; Modifiers int32; Get /*line :71:1*/ func(any) any; Set func(any, any) }
// MethodInfo is one method of a member table (§5.11): Invoke calls it (virtually for an
// instance method) with boxed arguments and returns its boxed result (nil for void).
//line :73:1
type MethodInfo /*line :76:1*/ struct{ Name string; Params []*Class; Return *Class; Modifiers int32; Invoke /*line :77:1*/ func(any, []any) any }
// CtorInfo is one constructor of a member table (§5.11).
type CtorInfo /*line :80:1*/ struct{ Params []*Class; Modifiers int32; New func([]any) any }


// Class is java.lang.Class (final: *Class). Classes are created by Define (the closed world),
// by ArrayClass (array classes, on demand) and for the primitive types (Prim_int ...).
type Class /*line :88:1*/ struct{ Object; info /*line :89:1*/*ClassInfo; name /*line :90:1*/*String; comp /*line :91:1*/*Class; desc byte; array /*line :93:1*/ atomic.Pointer[Class] }

var registryMu sync.RWMutex
var registry map[string]*Class = make(map[string]*Class)
// Define registers a class of the closed world under its binary name and returns its Class
// object. A second class of the same name is an error.
//line :98:1
func Define(info /*line :101:1*/*ClassInfo) *Class {
	c := &Class{info: info}
	presetClassHash(c, info.Name)
	registryMu.Lock()
	if registry[info.Name] != nil {
		registryMu.Unlock()
		panic("jrt.Define: two classes named " + info.Name) }
	registry[info.Name] = c
	registryMu.Unlock()
	return c }
// Info returns the class's ClassInfo (for attaching member tables at init).
func (c /*line :113:1*/*Class) Info() *ClassInfo {
	return c.info }
// ForName looks a class up by its binary name, or an array class by its JVM name
// ("[I", "[Ljava.lang.String;"), as Class.forName names them; nil when the closed world has
// no such class (V9).
//line :116:1
func ForName(name string,



) *Class {
	if strings.HasPrefix(name, "[") {
		c, rest := parseArrayName(name)
		if c == nil || rest != "" {
			return nil }
		return c }
	registryMu.RLock()
	c := registry[name]
	registryMu.RUnlock()
	return c
}
func parseArrayName(s string) (c *Class, rest string) {
	if len(s) == 0 {
		return nil, "" }
	switch s[0] {
	case '[':
		e, r := parseArrayName(s[1:])
		if e == nil {
			return nil, "" }
		return e.ArrayClass(), r
	case 'L':
		i := strings.IndexByte(s, ';')
		if i < 0 {
			return nil, "" }
		registryMu.RLock()
		e := registry[s[1:i]]
		registryMu.RUnlock()
		return e, s[i+1:]
	default:
		for _, p := range primitives {
			if p.desc == s[0] && p.desc != 'V' {
				return p, s[1:] } }
		return nil, ""
	}
}

func defPrim(name string, desc byte) *Class {
	c := &Class{
		info:    &ClassInfo{Name: name, Kind: KindPrimitive,
				Modifiers:       AccPublic | AccFinal | AccAbstract,
		}, desc: desc}
	presetClassHash(c, name)
	return c
}
var (
	// Prim_boolean ... Prim_void are the primitive types' classes (Integer.TYPE ...).
	Prim_boolean = defPrim("boolean", 'Z')
	Prim_byte    = defPrim("byte", 'B')
	Prim_char    = defPrim("char", 'C')
	Prim_short   = defPrim("short", 'S')
	Prim_int     = defPrim("int", 'I')
	Prim_long    = defPrim("long", 'J')
	Prim_float   = defPrim("float", 'F')
	Prim_double  = defPrim("double", 'D')
	Prim_void    = defPrim("void", 'V')
)
var primitives []*Class =
	[]*Class{Prim_boolean, Prim_byte, Prim_char, Prim_short, Prim_int, Prim_long, Prim_float, Prim_double, Prim_void}

// Class_GetPrimitiveClass_String__Class is Class.getPrimitiveClass (package-private).
func Class_GetPrimitiveClass_String__Class(name /*line :182:1*/*String) *Class {
	n := NN(name).String()
	for _, p := range primitives {
		if p.info.Name == n {
			return p
		}
	}
	return nil
}
var Object_class =
	Define(&ClassInfo{Name: "java.lang.Object", Kind: KindClass, Modifiers: AccPublic, Go: "arbace/jrt.Object"})


var Class_class =
	Define(&ClassInfo{Name: "java.lang.Class", Kind: KindClass,
				Modifiers:               AccPublic | AccFinal, Super:      Object_class,
				Interfaces:              []*Class{Serializable_class}, Go: "arbace/jrt.Class",
	},
	)
// ArrayClass returns the class of arrays of c ("[I", "[Ljava.lang.String;"), created on
// first use and then shared.
func (c /*line :206:1*/*Class) ArrayClass() *Class {
	a := c.array.Load()
	if a != nil {
		return a }
	name := ""
	if
		c.info.Kind == KindArray { name = "[" + c.info.Name
		} else if c.info.Kind == KindPrimitive { name = "[" + string(rune(c.desc)) } else {
			name = "[L" + c.info.Name + ";" }
	mods := c.GetModifiers__I()&(AccPublic|AccPrivate|AccProtected) | AccAbstract | AccFinal

	n := &Class{
		info: &ClassInfo{Name: name, Kind: KindArray, Modifiers: mods, Super: Object_class,

				Interfaces: []*Class{Cloneable_class, Serializable_class},
		}, comp: c}
	presetClassHash(n, name)
	if c.array.CompareAndSwap(nil, n) {
		return n }
	return c.array.Load()
}



func (t *Class) Ref() any { if t == nil { return nil }; return t }
func (t *Class) GetClass__Class() *Class { return Class_class }
func (t *Class) Clone__O() any { panic(CloneNotSupported(t)) }
func (t *Class) Is_Serializable() {}
// GoName is the binary name as a Go string.
func (c /*line :236:1*/*Class) GoName() string {
	return c.info.Name }
// GetName__String is Class.getName (one String object per class).
func (c /*line :240:1*/*Class) GetName__String() *String {
	if c.name == nil {
		c.name = Intern(c.info.Name) }
	return c.name
}
func (c *Class) ToString__String() *String {
	if
		c.IsPrimitive__Z() { return c.GetName__String()
		} else if c.IsInterface__Z() { return Str("interface " + c.info.Name) } else {
			return Str("class " + c.info.Name)
		} }
func (c *Class) GetSimpleName__String() *String {
	if c.comp != nil {
		return Concat(c.comp.GetSimpleName__String(), Str("[]")) }
	if c.info.Simple != "" {
		return Str(c.info.Simple) }
	n := c.info.Name
	i := strings.LastIndexAny(n, ".$")
	return Str(n[i+1:])
}
func (c *Class) IsArray__Z() bool { return c.info.Kind == KindArray }
func (c *Class) IsPrimitive__Z() bool { return c.info.Kind == KindPrimitive }
func (c *Class) IsInterface__Z() bool {
	return c.info.Kind == KindInterface || c.info.Kind == KindAnnotation }
func (c *Class) IsEnum__Z() bool { return c.info.Kind == KindEnum }
func (c *Class) IsRecord__Z() bool { return c.info.Kind == KindRecord }
func (c *Class) IsAnnotation__Z() bool { return c.info.Kind == KindAnnotation }
func (c *Class) GetModifiers__I() int32 { return c.info.Modifiers }
func (c *Class) GetComponentType__Class() *Class { return c.comp }
func (c *Class) GetSuperclass__Class() *Class { return c.info.Super }
// DesiredAssertionStatus__Z is false: no class runs with assertions enabled (-ea) yet.
//line :270:1
func (c /*line :272:1*/*Class) DesiredAssertionStatus__Z() bool { return false }

func (c *Class) GetInterfaces__Class1() *RefArray {
	is := c.info.Interfaces
	a := NewRefArray(Class_class, int32(len(is)))
	for i, x := range is {
		a.A[i] = x
	}; return a }
// IsInstance_O__Z is Class.isInstance.
func (c /*line :282:1*/*Class) IsInstance_O__Z(x any) bool {
	if x == nil {
		return false }
	if c.info.IsInstance != nil {
		return c.info.IsInstance(x) }
	return c.IsAssignableFrom_Class__Z(GetClass(x)) }
// Cast_O__O is Class.cast.
func (c /*line :290:1*/*Class) Cast_O__O(x any) any {
	if x != nil && !c.IsInstance_O__Z(x) {
		panic(ClassCastException_New_String(
			Str("Cannot cast " + GetClass(x).GoName() + " to " + c.info.Name),
		)) }; return x }
// IsAssignableFrom_Class__Z is Class.isAssignableFrom.
func (c /*line :297:1*/*Class) IsAssignableFrom_Class__Z(o *Class) bool {
	return c.assignableFrom(NN(o))
}
func (c *Class) assignableFrom(o *Class) bool {
	if
		c == o { return true
		} else if c.IsPrimitive__Z() || o.IsPrimitive__Z() { return false
		} else if c == Object_class { return true
		} else if o.IsArray__Z() {

			if c.IsArray__Z() {
				cc := c.comp
				oc := o.comp
				if cc.IsPrimitive__Z() || oc.IsPrimitive__Z() {
					return cc == oc }
				return cc.assignableFrom(oc) }
			return c == Cloneable_class || c == Serializable_class
		} else if c.IsArray__Z() { return false }
	return o.inherits(c) }
// inherits: whether c is o or one of its supertypes (o not an array).
func (o /*line :318:1*/*Class) inherits(c *Class) bool {
	for s := o; s != nil; s = s.info.Super {
		if s == c {
			return true }
		for _, i := range s.info.Interfaces {
			if i.inherits(c) {
				return true } } }; return false }
// Class_ForName_String__Class is Class.forName(String): the class, initialized, or
// ClassNotFoundException (V9: the closed world's classes only).
func Class_ForName_String__Class(name /*line :330:1*/*String) *Class {
	c := ForName(NN(name).String())
	if c == nil || c.IsPrimitive__Z() {
		panic(ClassNotFoundException_New_String(name)) }
	if c.info.Init != nil {
		c.info.Init()
	}
	return c
}
// ClassInit is the initialization state of a class with non-trivial initialization
// (C_init); C_Init is (when (not (.Done C_init)) (.Run C_init C_clinit)).
type ClassInit /*line :344:1*/ struct{ state atomic.Uint32; mu sync.Mutex; cond /*line :346:1*/*sync.Cond; owner uint64; err Throwable_I }



const (
	initNone uint32 = iota
	initRunning
	initDone
	initFailed)
// Done reports whether the class is initialized: one atomic load.
func (c /*line :357:1*/*ClassInit) Done() bool {
	return c.state.Load() == initDone }
// Run initializes the class with clinit, its static initializer, as JVMS 5.5 says: done →
// return; in progress by the current thread → return (the class is seen half-initialized); in
// progress by another thread → wait for it; failed before → NoClassDefFoundError; otherwise run
// clinit, and on an exception mark the class failed and throw ExceptionInInitializerError
// wrapping it (the exception itself if it is an Error).
//line :360:1
func (c /*line :366:1*/*ClassInit) Run(clinit func()) {
	me := currentThreadID()
	c.mu.Lock()
	for {
		switch c.state.Load() {
		case initDone:
			c.mu.Unlock()
			return
		case initFailed:
			e := c.err
			c.mu.Unlock()
			ncdfe := NoClassDefFoundError_New_String(
				Str("Could not initialize class " + clinitClassName(clinit)))
			ncdfe.InitCause_Throwable__Throwable(e)
			panic(ncdfe)
		case initRunning:
			if c.owner == me {
				c.mu.Unlock()
				return }
			if c.cond == nil {
				c.cond = sync.NewCond(&c.mu) }
			c.cond.Wait()
		default:
			c.state.Store(initRunning)
			c.owner = me
			c.mu.Unlock()
			exc := runCatching(clinit)
			c.mu.Lock()
			c.owner = 0
			if exc == nil {
				c.state.Store(initDone) } else {

					c.state.Store(initFailed)
					c.err = exc }
			if c.cond != nil {
				c.cond.Broadcast() }
			c.mu.Unlock()
			if exc == nil {
				return }
			if Error_InstanceOf(exc) {
				panic(exc) }
			panic(ExceptionInInitializerError_New_Throwable(exc))
		} } }
func runCatching(f func()) (exc Throwable_I) {
	defer Catch(&exc)
	f()
	return }
// clinitClassName: the Java class whose static initializer clinit is, from its Go name
// ("arbace/lang.Util_clinit") through the frame table, or its Go name.
//line :414:1
func clinitClassName(clinit /*line :417:1*/ func()) string {
	f := runtime.FuncForPC(reflect.ValueOf(clinit).Pointer())
	if f == nil {
		return "?" }
	name := f.Name()
	fr, ok := lookupFrame(name)
	if ok {
		return fr.Class }
	return strings.TrimSuffix(name, "_clinit") }
// ClassCast is the ClassCastException of a failed cast of x to the class to, with the JVM's
// message: class X cannot be cast to class Y (X and Y are in module java.base of loader
// 'bootstrap'), the module and loader as the JVM names them for the JDK's classes (java.base,
// 'bootstrap') and Arbace's (unnamed module of loader 'app').
func ClassCast(x any, to /*line :435:1*/*Class) Throwable_I {
	from := GetClass(x).GoName()
	target := to.GoName()
	df := classPlace(GetClass(x))
	dt := classPlace(to)
	s := "class " + from + " cannot be cast to class " + target + " ("
	if df == dt {
		s = s + from + " and " + target + " are in " + df + ")" } else {
			s = s + from + " is in " + df + "; " + target + " is in " + dt + ")" }
	return ClassCastException_New_String(Str(s))
}
func classPlace(c *Class) string {
	for c.comp != nil {
		c = c.comp }
	n := c.info.Name
	if c.IsPrimitive__Z() || strings.HasPrefix(n, "java.") || strings.HasPrefix(n, "javax.") ||
		strings.HasPrefix(n, "jdk.") || strings.HasPrefix(n, "sun.") {
			return "module java.base of loader 'bootstrap'"
		}
	return "unnamed module of loader 'app'" }
func Class_InstanceOf(x any) bool { _, ok := x.(*Class); return ok }
func Class_Cast(x any) *Class {
	if x == nil { return nil }
	v, ok := x.(*Class)
	if !ok { panic(ClassCast(x, Class_class)) }; return v }
// init sets ClassInfo.IsInstance of jrt's hand-written classes (§5.11; after Go's variable
// initialization, which must not see the cycles).
func init() {



	Class_class.Info().IsInstance = Class_InstanceOf
	String_class.Info().IsInstance = String_InstanceOf
	StringBuilder_class.Info().IsInstance = StringBuilder_InstanceOf
	StringBuffer_class.Info().IsInstance = StringBuffer_InstanceOf
	Throwable_class.Info().IsInstance = Throwable_InstanceOf
	Enum_class.Info().IsInstance = Enum_InstanceOf
	Record_class.Info().IsInstance = Record_InstanceOf
}
