//line java_lang_NumberFormatException.ae:1
package jrt








func NumberFormatException_New() *NumberFormatException { t := &NumberFormatException{}; t.Ctor(); return t }
//line :10:1
func (t *NumberFormatException) Ctor() { t.IllegalArgumentException.Ctor(t) }

func NumberFormatException_New_String(p0 *String) *NumberFormatException { t := &NumberFormatException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NumberFormatException) Ctor_String(s *String) { t.IllegalArgumentException.Ctor_String(t, s) }

func NumberFormatException_ForInputString_String_I__NumberFormatException(s *String, radix int32) *NumberFormatException {
	var tmp1 *String



	if radix == 10 { tmp1 = Lit_69 } else { tmp1 = Concat(Lit_1140, StrOfInt(radix)) }
//line :15:1
	return NumberFormatException_New_String(Concat(Lit_1141, s, Lit_1142, tmp1))
}




func NumberFormatException_ForCharSequence_CharSequence_I_I_I__NumberFormatException(s CharSequence, beginIndex, endIndex, errorIndex int32) *NumberFormatException {

	return NumberFormatException_New_String(Concat(Lit_1143, StrOfInt(errorIndex-beginIndex), Lit_1144, StrOfObj(s.SubSequence_I_I__CharSequence(beginIndex, endIndex)), Lit_1142))
}


type NumberFormatException struct{ IllegalArgumentException }

const NumberFormatException_serialVersionUID int64 = -2848938806368998894

func (t *NumberFormatException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NumberFormatException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NumberFormatException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NumberFormatException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NumberFormatException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NumberFormatException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NumberFormatException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NumberFormatException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NumberFormatException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NumberFormatException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NumberFormatException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NumberFormatException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NumberFormatException) Ref() any { if t == nil { return nil }; return t }

func (t *NumberFormatException) GetClass__Class() *Class { return NumberFormatException_class }

func (t *NumberFormatException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NumberFormatException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NumberFormatException_InstanceOf(x any) bool { _, ok := x.(*NumberFormatException); return ok }

func NumberFormatException_Cast(x any) *NumberFormatException { if x == nil { return nil }; v, ok := x.(*NumberFormatException); if !ok { panic(ClassCast(x, NumberFormatException_class)) }; return v }
