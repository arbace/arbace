//line java_security_InvalidParameterException.ae:1
package jrt








func InvalidParameterException_New() *InvalidParameterException { t := &InvalidParameterException{}; t.Ctor(); return t }
//line :10:1
func (t *InvalidParameterException) Ctor() { t.IllegalArgumentException.Ctor(t) }

func InvalidParameterException_New_String(p0 *String) *InvalidParameterException { t := &InvalidParameterException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *InvalidParameterException) Ctor_String(msg *String) { t.IllegalArgumentException.Ctor_String(t, msg) }

func InvalidParameterException_New_String_Throwable(p0 *String, p1 Throwable_I) *InvalidParameterException { t := &InvalidParameterException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *InvalidParameterException) Ctor_String_Throwable(msg *String, cause Throwable_I) { t.IllegalArgumentException.Ctor_String_Throwable(t, msg, cause) }


func InvalidParameterException_New_Throwable(p0 Throwable_I) *InvalidParameterException { t := &InvalidParameterException{}; t.Ctor_Throwable(p0); return t }
//line :17:1
func (t *InvalidParameterException) Ctor_Throwable(cause Throwable_I) { t.IllegalArgumentException.Ctor_Throwable(t, cause) }










type InvalidParameterException struct{ IllegalArgumentException }

const InvalidParameterException_serialVersionUID int64 = -857968536935667808

func (t *InvalidParameterException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvalidParameterException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvalidParameterException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InvalidParameterException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvalidParameterException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvalidParameterException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InvalidParameterException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvalidParameterException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvalidParameterException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvalidParameterException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvalidParameterException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvalidParameterException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvalidParameterException) Ref() any { if t == nil { return nil }; return t }

func (t *InvalidParameterException) GetClass__Class() *Class { return InvalidParameterException_class }

func (t *InvalidParameterException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvalidParameterException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvalidParameterException_InstanceOf(x any) bool { _, ok := x.(*InvalidParameterException); return ok }

func InvalidParameterException_Cast(x any) *InvalidParameterException { if x == nil { return nil }; v, ok := x.(*InvalidParameterException); if !ok { panic(ClassCast(x, InvalidParameterException_class)) }; return v }
