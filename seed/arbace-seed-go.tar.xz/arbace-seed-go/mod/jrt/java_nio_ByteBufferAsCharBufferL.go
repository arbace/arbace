//line java_nio_ByteBufferAsCharBufferL.ae:1
package jrt














func ByteBufferAsCharBufferL_New_ByteBuffer_MemorySegment(p0 ByteBuffer_I, p1 MemorySegment) *ByteBufferAsCharBufferL { ByteBufferAsCharBufferL_Init(); t := &ByteBufferAsCharBufferL{}; t.Ctor_ByteBuffer_MemorySegment(p0, p1); return t }
//line :16:1
func (t *ByteBufferAsCharBufferL) Ctor_ByteBuffer_MemorySegment(bb ByteBuffer_I, segment MemorySegment) { panic(A2g_NotTranslated("java.nio.ByteBufferAsCharBufferL.<init>(Ljava/nio/ByteBuffer;Ljava/lang/foreign/MemorySegment;)V")) }










func ByteBufferAsCharBufferL_New_ByteBuffer_I_I_I_I_J_MemorySegment(p0 ByteBuffer_I, p1, p2, p3, p4 int32, p5 int64, p6 MemorySegment) *ByteBufferAsCharBufferL { ByteBufferAsCharBufferL_Init(); t := &ByteBufferAsCharBufferL{}; t.Ctor_ByteBuffer_I_I_I_I_J_MemorySegment(p0, p1, p2, p3, p4, p5, p6); return t }
//line :27:1
func (t *ByteBufferAsCharBufferL) Ctor_ByteBuffer_I_I_I_I_J_MemorySegment(bb ByteBuffer_I, mark, pos, lim, cap_ int32, addr int64, segment MemorySegment) { t.CharBuffer.Ctor_I_I_I_I_MemorySegment(t, mark, pos, lim, cap_, segment)


	t.F_bb = bb
	t.F_address = addr
	var tmp1 int64 = t.F_address; if !A2g_AssertionsDisabled && !(tmp1 >= bb.Self_Buffer().F_address) { panic(Thrown(AssertionError_New()))
	} }
func (t *ByteBufferAsCharBufferL) Base__O() any { return t.F_bb.Self_ByteBuffer().F_hb.Ref() }

func (t *ByteBufferAsCharBufferL) Slice__CharBuffer() CharBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32

	if pos <= lim { rem = lim - pos } else { rem = 0 }
//line :37:1
	var addr int64 = t.ByteOffset_J__J(int64(pos))



	return ByteBufferAsCharBufferL_New_ByteBuffer_I_I_I_I_J_MemorySegment(t.F_bb, -1, 0, rem, rem, addr, t.F_segment)
}
func (t *ByteBufferAsCharBufferL) Slice_I_I__CharBuffer(index, length int32) CharBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	var tmp1 ByteBuffer_I = t.F_bb; return ByteBufferAsCharBufferL_New_ByteBuffer_I_I_I_I_J_MemorySegment(tmp1, -1, 0, length, length, t.ByteOffset_J__J(int64(index)), t.F_segment)
}
func (t *ByteBufferAsCharBufferL) Duplicate__CharBuffer() CharBuffer_I {
	var tmp1 ByteBuffer_I = t.F_bb; return ByteBufferAsCharBufferL_New_ByteBuffer_I_I_I_I_J_MemorySegment(tmp1, t.MarkValue__I(), t.Position__I(), t.Limit__I(), t.Capacity__I(), t.F_address, t.F_segment)
}






func (t *ByteBufferAsCharBufferL) AsReadOnlyBuffer__CharBuffer() CharBuffer_I {
	return A2g_Missing[CharBuffer_I]("class java.nio.ByteBufferAsCharBufferRL is not in the closed world")
}






func (t *ByteBufferAsCharBufferL) Ix_I__I(i int32) int32 {
	var tmp1 int64 = t.F_address; var off int32 = int32(tmp1 - t.F_bb.Self_Buffer().F_address)
	return i<<1 + off
}
func (t *ByteBufferAsCharBufferL) ByteOffset_J__J(i int64) int64 {
	return i<<1 + t.F_address
}
func (t *ByteBufferAsCharBufferL) Get__C() uint16 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref(); var x uint16 = NN(tmp1).GetCharUnaligned_MemorySessionImpl_O_J_Z__C(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex__I())), false); return x
}





func (t *ByteBufferAsCharBufferL) Get_I__C(i int32) uint16 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref(); var x uint16 = NN(tmp1).GetCharUnaligned_MemorySessionImpl_O_J_Z__C(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I__I(i))), false); return x
}





func (t *ByteBufferAsCharBufferL) GetUnchecked_I__C(p0 int32) uint16 { panic(A2g_NotTranslated("java.nio.ByteBufferAsCharBufferL.getUnchecked(I)C")) }







func (t *ByteBufferAsCharBufferL) Put_C__CharBuffer(x uint16) CharBuffer_I {
	var y uint16 = x; var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref()
	NN(tmp1).PutCharUnaligned_MemorySessionImpl_O_J_C_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex__I())), y, false)
//line :97:1
	return t
}







func (t *ByteBufferAsCharBufferL) Put_I_C__CharBuffer(i int32, x uint16) CharBuffer_I {
	var y uint16 = x; var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref()
	NN(tmp1).PutCharUnaligned_MemorySessionImpl_O_J_C_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I__I(i))), y, false)
//line :107:1
	return t
}







func (t *ByteBufferAsCharBufferL) Compact__CharBuffer() CharBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I()

	if !A2g_AssertionsDisabled && !(pos <= lim) { panic(Thrown(AssertionError_New())) }
	var rem int32; if pos <= lim { rem = lim - pos } else { rem = 0 }; var db ByteBuffer_I = t.F_bb.Duplicate__ByteBuffer()

	db.Limit_I__ByteBuffer(t.Ix_I__I(lim))
	db.Position_I__ByteBuffer(t.Ix_I__I(0))
	var sb ByteBuffer_I = db.Slice__ByteBuffer()
	sb.Position_I__ByteBuffer(pos << 1)
	sb.Compact__ByteBuffer()
	t.Position_I__CharBuffer(rem)
	t.Limit_I__CharBuffer(t.Capacity__I())
	t.DiscardMark__V()
//line :124:1
	return t
}






func (t *ByteBufferAsCharBufferL) IsDirect__Z() bool { return t.F_bb.IsDirect__Z() }

func (t *ByteBufferAsCharBufferL) IsReadOnly__Z() bool { return false }

func (t *ByteBufferAsCharBufferL) ToString_I_I__String(start, end int32) *String {
	Objects_CheckFromToIndex_I_I_I__I(start, end, t.Limit__I())
	var len_ int32 = end - start; var ca *CharArray = NewCharArray(len_); var cb CharBuffer_I = CharBuffer_Wrap_C1__CharBuffer(ca); var db CharBuffer_I = t.Duplicate__CharBuffer()



	db.Position_I__CharBuffer(start)
	db.Limit_I__CharBuffer(end)
	cb.Put_CharBuffer__CharBuffer(db)
	return String_New_C1(ca)
}
func (t *ByteBufferAsCharBufferL) SubSequence_I_I__CharBuffer(start, end int32) CharBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I()

	if !A2g_AssertionsDisabled && !(pos <= lim) { panic(Thrown(AssertionError_New())) }
	var tmp1 int32; if pos <= lim { tmp1 = pos } else { tmp1 = lim }; pos = tmp1
	var len_ int32 = lim - pos
	Objects_CheckFromToIndex_I_I_I__I(start, end, len_)
	var tmp2 ByteBuffer_I = t.F_bb; return ByteBufferAsCharBufferL_New_ByteBuffer_I_I_I_I_J_MemorySegment(tmp2, -1, pos+start, pos+end, t.Capacity__I(), t.F_address, t.F_segment)
}






func (t *ByteBufferAsCharBufferL) ScaleShifts__I() int32 { panic(A2g_NotTranslated("java.nio.ByteBufferAsCharBufferL.scaleShifts()I")) }







func (t *ByteBufferAsCharBufferL) Order__ByteOrder() *ByteOrder { ByteOrder_Init(); return ByteOrder_LITTLE_ENDIAN }

func (t *ByteBufferAsCharBufferL) CharRegionOrder__ByteOrder() *ByteOrder { panic(A2g_NotTranslated("java.nio.ByteBufferAsCharBufferL.charRegionOrder()Ljava/nio/ByteOrder;")) }



type ByteBufferAsCharBufferL struct{ CharBuffer; F_bb ByteBuffer_I }

var ByteBufferAsCharBufferL_init ClassInit

func ByteBufferAsCharBufferL_Init() { if !ByteBufferAsCharBufferL_init.Done() { ByteBufferAsCharBufferL_init.Run(ByteBufferAsCharBufferL_clinit) } }

func ByteBufferAsCharBufferL_clinit() { CharBuffer_Init() }

func (t *ByteBufferAsCharBufferL) Slice__Buffer() Buffer_I { return t.Slice__CharBuffer() }

func (t *ByteBufferAsCharBufferL) Slice_I_I__Buffer(p0, p1 int32) Buffer_I { return t.Slice_I_I__CharBuffer(p0, p1) }

func (t *ByteBufferAsCharBufferL) Duplicate__Buffer() Buffer_I { return t.Duplicate__CharBuffer() }

func (t *ByteBufferAsCharBufferL) SubSequence_I_I__CharSequence(p0, p1 int32) CharSequence { return t.SubSequence_I_I__CharBuffer(p0, p1) }

func (t *ByteBufferAsCharBufferL) CharAt_I__C(p0 int32) uint16 { return t.Impl_CharAt_I__C(t, p0) }

func (t *ByteBufferAsCharBufferL) Get_C1_I_I__CharBuffer(p0 *CharArray, p1, p2 int32) CharBuffer_I { return t.Impl_Get_C1_I_I__CharBuffer(t, p0, p1, p2) }

func (t *ByteBufferAsCharBufferL) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return t.Impl_Append_CharSequence_I_I__Appendable(t, p0, p1, p2) }

func (t *ByteBufferAsCharBufferL) Array__O() any { return t.Impl_Array__O(t) }

func (t *ByteBufferAsCharBufferL) Append_CharSequence_I_I__CharBuffer(p0 CharSequence, p1, p2 int32) CharBuffer_I { return t.Impl_Append_CharSequence_I_I__CharBuffer(t, p0, p1, p2) }

func (t *ByteBufferAsCharBufferL) Get_C1__CharBuffer(p0 *CharArray) CharBuffer_I { return t.Impl_Get_C1__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Append_CharSequence__CharBuffer(p0 CharSequence) CharBuffer_I { return t.Impl_Append_CharSequence__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *ByteBufferAsCharBufferL) NextGetIndex__I() int32 { return t.Impl_NextGetIndex__I(t) }

func (t *ByteBufferAsCharBufferL) Put_CharBuffer__CharBuffer(p0 CharBuffer_I) CharBuffer_I { return t.Impl_Put_CharBuffer__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Clear__Buffer() Buffer_I { return t.Impl_Clear__Buffer(t) }

func (t *ByteBufferAsCharBufferL) Rewind__CharBuffer() CharBuffer_I { return t.Impl_Rewind__CharBuffer(t) }

func (t *ByteBufferAsCharBufferL) Clear__CharBuffer() CharBuffer_I { return t.Impl_Clear__CharBuffer(t) }

func (t *ByteBufferAsCharBufferL) Session__MemorySessionImpl() MemorySessionImpl_I { return t.Impl_Session__MemorySessionImpl(t) }

func (t *ByteBufferAsCharBufferL) Put_I_CharBuffer_I_I__CharBuffer(p0 int32, p1 CharBuffer_I, p2, p3 int32) CharBuffer_I { return t.Impl_Put_I_CharBuffer_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsCharBufferL) Put_String__CharBuffer(p0 *String) CharBuffer_I { return t.Impl_Put_String__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Array__C1() *CharArray { return t.Impl_Array__C1(t) }

func (t *ByteBufferAsCharBufferL) PutArray_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_PutArray_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsCharBufferL) Limit__I() int32 { return t.Impl_Limit__I(t) }

func (t *ByteBufferAsCharBufferL) Reset__CharBuffer() CharBuffer_I { return t.Impl_Reset__CharBuffer(t) }

func (t *ByteBufferAsCharBufferL) Remaining__I() int32 { return t.Impl_Remaining__I(t) }

func (t *ByteBufferAsCharBufferL) NextGetIndex_I__I(p0 int32) int32 { return t.Impl_NextGetIndex_I__I(t, p0) }

func (t *ByteBufferAsCharBufferL) NextPutIndex__I() int32 { return t.Impl_NextPutIndex__I(t) }

func (t *ByteBufferAsCharBufferL) GetChars_I_I_C1_I__V(p0, p1 int32, p2 *CharArray, p3 int32) { t.Impl_GetChars_I_I_C1_I__V(t, p0, p1, p2, p3) }

func (t *ByteBufferAsCharBufferL) DiscardMark__V() { t.Impl_DiscardMark__V(t) }

func (t *ByteBufferAsCharBufferL) Flip__Buffer() Buffer_I { return t.Impl_Flip__Buffer(t) }

func (t *ByteBufferAsCharBufferL) ArrayOffset__I() int32 { return t.Impl_ArrayOffset__I(t) }

func (t *ByteBufferAsCharBufferL) MarkValue__I() int32 { return t.Impl_MarkValue__I(t) }

func (t *ByteBufferAsCharBufferL) Put_C1__CharBuffer(p0 *CharArray) CharBuffer_I { return t.Impl_Put_C1__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Position_I__CharBuffer(p0 int32) CharBuffer_I { return t.Impl_Position_I__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Rewind__Buffer() Buffer_I { return t.Impl_Rewind__Buffer(t) }

func (t *ByteBufferAsCharBufferL) HasArray__Z() bool { return t.Impl_HasArray__Z(t) }

func (t *ByteBufferAsCharBufferL) Put_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_Put_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsCharBufferL) CodePoints__IntStream() IntStream { return CharSequence_CodePoints__IntStream(t) }

func (t *ByteBufferAsCharBufferL) Get_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I { return t.Impl_Get_I_C1__CharBuffer(t, p0, p1) }

func (t *ByteBufferAsCharBufferL) Limit_I__CharBuffer(p0 int32) CharBuffer_I { return t.Impl_Limit_I__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Append_C__CharBuffer(p0 uint16) CharBuffer_I { return t.Impl_Append_C__CharBuffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Chars__IntStream() IntStream { return t.Impl_Chars__IntStream(t) }

func (t *ByteBufferAsCharBufferL) Length__I() int32 { return t.Impl_Length__I(t) }

func (t *ByteBufferAsCharBufferL) Position__I() int32 { return t.Impl_Position__I(t) }

func (t *ByteBufferAsCharBufferL) Reset__Buffer() Buffer_I { return t.Impl_Reset__Buffer(t) }

func (t *ByteBufferAsCharBufferL) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return t.Impl_Append_CharSequence__Appendable(t, p0) }

func (t *ByteBufferAsCharBufferL) Append_C__Appendable(p0 uint16) Appendable { return t.Impl_Append_C__Appendable(t, p0) }

func (t *ByteBufferAsCharBufferL) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *ByteBufferAsCharBufferL) CheckIndex_I_I__I(p0, p1 int32) int32 { return t.Impl_CheckIndex_I_I__I(t, p0, p1) }

func (t *ByteBufferAsCharBufferL) CheckSession__V() { t.Impl_CheckSession__V(t) }

func (t *ByteBufferAsCharBufferL) Flip__CharBuffer() CharBuffer_I { return t.Impl_Flip__CharBuffer(t) }

func (t *ByteBufferAsCharBufferL) CheckIndex_I__I(p0 int32) int32 { return t.Impl_CheckIndex_I__I(t, p0) }

func (t *ByteBufferAsCharBufferL) Get_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_Get_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsCharBufferL) Position_I__Buffer(p0 int32) Buffer_I { return t.Impl_Position_I__Buffer(t, p0) }

func (t *ByteBufferAsCharBufferL) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ByteBufferAsCharBufferL) GetArray_I_C1_I_I__CharBuffer(p0 int32, p1 *CharArray, p2, p3 int32) CharBuffer_I { return t.Impl_GetArray_I_C1_I_I__CharBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsCharBufferL) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ByteBufferAsCharBufferL) Mark__Buffer() Buffer_I { return t.Impl_Mark__Buffer(t) }

func (t *ByteBufferAsCharBufferL) Mismatch_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Mismatch_CharBuffer__I(t, p0) }

func (t *ByteBufferAsCharBufferL) Put_I_C1__CharBuffer(p0 int32, p1 *CharArray) CharBuffer_I { return t.Impl_Put_I_C1__CharBuffer(t, p0, p1) }

func (t *ByteBufferAsCharBufferL) Put_String_I_I__CharBuffer(p0 *String, p1, p2 int32) CharBuffer_I { return t.Impl_Put_String_I_I__CharBuffer(t, p0, p1, p2) }

func (t *ByteBufferAsCharBufferL) CompareTo_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_CompareTo_CharBuffer__I(t, p0) }

func (t *ByteBufferAsCharBufferL) Put_C1_I_I__CharBuffer(p0 *CharArray, p1, p2 int32) CharBuffer_I { return t.Impl_Put_C1_I_I__CharBuffer(t, p0, p1, p2) }

func (t *ByteBufferAsCharBufferL) HasRemaining__Z() bool { return t.Impl_HasRemaining__Z(t) }

func (t *ByteBufferAsCharBufferL) Mark__CharBuffer() CharBuffer_I { return t.Impl_Mark__CharBuffer(t) }

func (t *ByteBufferAsCharBufferL) PutBuffer_I_CharBuffer_I_I__V(p0 int32, p1 CharBuffer_I, p2, p3 int32) { t.Impl_PutBuffer_I_CharBuffer_I_I__V(t, p0, p1, p2, p3) }

func (t *ByteBufferAsCharBufferL) NextPutIndex_I__I(p0 int32) int32 { return t.Impl_NextPutIndex_I__I(t, p0) }

func (t *ByteBufferAsCharBufferL) IsAddressable__Z() bool { return t.Impl_IsAddressable__Z(t) }

func (t *ByteBufferAsCharBufferL) Limit_I__Buffer(p0 int32) Buffer_I { return t.Impl_Limit_I__Buffer(t, p0) }

func (t *ByteBufferAsCharBufferL) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ByteBufferAsCharBufferL) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ByteBufferAsCharBufferL) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ByteBufferAsCharBufferL) Ref() any { if t == nil { return nil }; return t }

func (t *ByteBufferAsCharBufferL) GetClass__Class() *Class { return ByteBufferAsCharBufferL_class }

func (t *ByteBufferAsCharBufferL) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ByteBufferAsCharBufferL) CloneShallow() any { panic(CloneNotSupported(t)) }

func ByteBufferAsCharBufferL_InstanceOf(x any) bool { _, ok := x.(*ByteBufferAsCharBufferL); return ok }

func ByteBufferAsCharBufferL_Cast(x any) *ByteBufferAsCharBufferL { if x == nil { return nil }; v, ok := x.(*ByteBufferAsCharBufferL); if !ok { panic(ClassCast(x, ByteBufferAsCharBufferL_class)) }; return v }
