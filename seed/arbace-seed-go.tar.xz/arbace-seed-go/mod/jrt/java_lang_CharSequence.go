//line java_lang_CharSequence.ae:1
package jrt

















func CharSequence_IsEmpty__Z(this CharSequence) bool { return this.Length__I() == 0 }





func CharSequence_Chars__IntStream(this CharSequence) IntStream {


















	return StreamSupport_IntStream_Supplier_I_Z__IntStream(&Supplier_Fn{Fn: func() any { return Spliterators_Spliterator_PrimitiveIterator_OfInt_J_I__Spliterator_OfInt(CharSequence_1CharIterator_New_CharSequence(this), int64(this.Length__I()), 16) }}, 16464, false) }
//line :31:1
func (t *CharSequence_1CharIterator) HasNext__Z() bool {
	var tmp1 int32 = t.F_cur; return tmp1 < t.F_this_0.Length__I()
}
func (t *CharSequence_1CharIterator) NextInt__I() int32 {
	if t.HasNext__Z() { var tmp1 int32; var old_1 int32 = t.F_cur

		t.F_cur = t.F_cur + 1; tmp1 = old_1
//line :35:1
		return int32(t.F_this_0.CharAt_I__C(tmp1)) } else {


			panic(Thrown(NoSuchElementException_New()))
		} }
func (t *CharSequence_1CharIterator) ForEachRemaining_IntConsumer__V(block IntConsumer) {
L1: for { var tmp1 int32 = t.F_cur; if tmp1 < t.F_this_0.Length__I() {
	block.Accept_I__V(int32(t.F_this_0.CharAt_I__C(t.F_cur)))
	t.F_cur = t.F_cur + 1
//line :41:1
	continue L1 }; break L1
}
}






func CharSequence_CodePoints__IntStream(this CharSequence) IntStream {




































	return StreamSupport_IntStream_Supplier_I_Z__IntStream(&Supplier_Fn{Fn: func() any { return Spliterators_SpliteratorUnknownSize_PrimitiveIterator_OfInt_I__Spliterator_OfInt(CharSequence_1CodePointIterator_New_CharSequence(this), 16) }}, 16, false) }
//line :56:1
func (t *CharSequence_1CodePointIterator) ForEachRemaining_IntConsumer__V(block IntConsumer) {
	var length int32 = t.F_this_0.Length__I(); var i int32 = t.F_cur; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)


	L1: for { if i < length {
		var c1 uint16; var tmp1 int32; var old_2 int32 = i
		i = i + 1; tmp1 = old_2
//line :61:1
		c1 = t.F_this_0.CharAt_I__C(tmp1)

		var tmp2 bool; var tmp3 bool; tmp3 = !Character_IsHighSurrogate_C__Z(c1); if !tmp3 { tmp3 = i >= length }; tmp2 = tmp3; if tmp2 {
			block.Accept_I__V(int32(c1)) } else {
				var c2 uint16 = t.F_this_0.CharAt_I__C(i)
				if Character_IsLowSurrogate_C__Z(c2) {

					i = i + 1
					block.Accept_I__V(Character_ToCodePoint_C_C__I(c1, c2)) } else {
						block.Accept_I__V(int32(c1)) } }
//line :60:1
		continue L1 }; break L1
	}








		return nil }()
	t.F_cur = i
//line :59:1
	if tmp4 != nil { panic(tmp4)
	}
}











func (t *CharSequence_1CodePointIterator) HasNext__Z() bool {
	var tmp1 int32 = t.F_cur; return tmp1 < t.F_this_0.Length__I()
}
func (t *CharSequence_1CodePointIterator) NextInt__I() int32 { var tmp1 uint16; var length int32 = t.F_this_0.Length__I(); if

	t.F_cur >= length { panic(Thrown(NoSuchElementException_New())) }; var c1 uint16; var tmp2 int32; var old_3 int32 =
	t.F_cur;
	t.F_cur = t.F_cur + 1; tmp2 = old_3; c1 = /*line :79:1*/t.F_this_0.CharAt_I__C(tmp2); var tmp3 bool; var tmp4 bool; tmp4 =

	Character_IsHighSurrogate_C__Z(c1); if tmp4 { tmp4 = t.F_cur < length }; tmp3 = tmp4; if tmp3 {
		var c2 uint16 = t.F_this_0.CharAt_I__C(t.F_cur)
		if Character_IsLowSurrogate_C__Z(c2) {
			t.F_cur = t.F_cur + 1
			return Character_ToCodePoint_C_C__I(c1, c2) } }; tmp1 = c1; return /*line :76:1*/ int32(tmp1) }
















func CharSequence_Compare_CharSequence_CharSequence__I(cs1, cs2 CharSequence) int32 {
	if Objects_RequireNonNull_O__O(cs1) == Objects_RequireNonNull_O__O(cs2) { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = cs1.GetClass__Class() == cs2.GetClass__Class(); if tmp2 { tmp2 = Comparable_InstanceOf(cs1) }; tmp1 = tmp2
//line :94:1
		if tmp1 {


			return Comparable_Cast(cs1).CompareTo_O__I(cs2) } else {


				var i int32 = 0; var len_ int32 = Math_Min_I_I__I(cs1.Length__I(), cs2.Length__I()); L1: for {

					if i < len_ {
						var a uint16 = cs1.CharAt_I__C(i); var b uint16 = cs2.CharAt_I__C(i)

						if !(int32(a) == int32(b)) {
							return int32(a) - int32(b) } else {
								i, len_ = i+1, len_; continue L1 } }
//line :100:1
					break L1
				}






				return cs1.Length__I() - cs2.Length__I()
			} } }
func CharSequence_GetChars_I_I_C1_I__V(this CharSequence, srcBegin, srcEnd int32, dst *CharArray, dstBegin int32) {

	Objects_CheckFromToIndex_I_I_I__I(srcBegin, srcEnd, this.Length__I())
	Objects_CheckIndex_I_I__I(dstBegin, int32(len(dst.A))-(srcEnd-srcBegin)+1)





L1: for { if srcBegin < srcEnd {
	dst.A[dstBegin] = this.CharAt_I__C(srcBegin)
	dstBegin = dstBegin + 1
	srcBegin = srcBegin + 1
//line :119:1
	continue L1 }; break L1
}
}




type CharSequence interface{ Object_I; Is_CharSequence(); Length__I() int32; CharAt_I__C(p0 int32) uint16; IsEmpty__Z() bool; SubSequence_I_I__CharSequence(p0, p1 int32) CharSequence; Chars__IntStream() IntStream; CodePoints__IntStream() IntStream; GetChars_I_I_C1_I__V(p0, p1 int32, p2 *CharArray, p3 int32) }

func CharSequence_InstanceOf(x any) bool { _, ok := x.(CharSequence); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CharSequence_class) } }; return ok }

func CharSequence_Cast(x any) CharSequence { if x == nil { return nil }; v, ok := x.(CharSequence); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CharSequence_class) } }; if !ok { panic(ClassCast(x, CharSequence_class)) }; return v }



type CharSequence_1CharIterator struct{ Object; F_cur int32; F_this_0 CharSequence }

func (t *CharSequence_1CharIterator) Is_PrimitiveIterator_OfInt() {}

func (t *CharSequence_1CharIterator) Is_PrimitiveIterator() {}

func (t *CharSequence_1CharIterator) Is_Iterator() {}

func CharSequence_1CharIterator_New_CharSequence(p0 CharSequence) *CharSequence_1CharIterator { t := &CharSequence_1CharIterator{}; t.Ctor_CharSequence(p0); return t }

func (t *CharSequence_1CharIterator) Ctor_CharSequence(this_0 CharSequence) { A2g_NotNull[CharSequence](this_0); t.F_this_0 = this_0; t.F_cur = 0 }

func (t *CharSequence_1CharIterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func (t *CharSequence_1CharIterator) Next__Integer() *Integer { return PrimitiveIterator_OfInt_Next__Integer(t) }

func (t *CharSequence_1CharIterator) ForEachRemaining_Consumer__V(p0 Consumer) { PrimitiveIterator_OfInt_ForEachRemaining_Consumer__V(t, p0) }

func (t *CharSequence_1CharIterator) Next__O() any { return PrimitiveIterator_OfInt_Next__O(t) }

func (t *CharSequence_1CharIterator) Remove__V() { Iterator_Remove__V(t) }

func (t *CharSequence_1CharIterator) Ref() any { if t == nil { return nil }; return t }

func (t *CharSequence_1CharIterator) GetClass__Class() *Class { return CharSequence_1CharIterator_class }

func (t *CharSequence_1CharIterator) ToString__String() *String { return Object_toString(t) }

func (t *CharSequence_1CharIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharSequence_1CharIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharSequence_1CharIterator_InstanceOf(x any) bool { _, ok := x.(*CharSequence_1CharIterator); return ok }

func CharSequence_1CharIterator_Cast(x any) *CharSequence_1CharIterator { if x == nil { return nil }; v, ok := x.(*CharSequence_1CharIterator); if !ok { panic(ClassCast(x, CharSequence_1CharIterator_class)) }; return v }



type CharSequence_1CodePointIterator struct{ Object; F_cur int32; F_this_0 CharSequence }

func (t *CharSequence_1CodePointIterator) Is_PrimitiveIterator_OfInt() {}

func (t *CharSequence_1CodePointIterator) Is_PrimitiveIterator() {}

func (t *CharSequence_1CodePointIterator) Is_Iterator() {}

func CharSequence_1CodePointIterator_New_CharSequence(p0 CharSequence) *CharSequence_1CodePointIterator { t := &CharSequence_1CodePointIterator{}; t.Ctor_CharSequence(p0); return t }

func (t *CharSequence_1CodePointIterator) Ctor_CharSequence(this_0 CharSequence) { A2g_NotNull[CharSequence](this_0); t.F_this_0 = this_0; t.F_cur = 0 }

func (t *CharSequence_1CodePointIterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func (t *CharSequence_1CodePointIterator) Next__Integer() *Integer { return PrimitiveIterator_OfInt_Next__Integer(t) }

func (t *CharSequence_1CodePointIterator) ForEachRemaining_Consumer__V(p0 Consumer) { PrimitiveIterator_OfInt_ForEachRemaining_Consumer__V(t, p0) }

func (t *CharSequence_1CodePointIterator) Next__O() any { return PrimitiveIterator_OfInt_Next__O(t) }

func (t *CharSequence_1CodePointIterator) Remove__V() { Iterator_Remove__V(t) }

func (t *CharSequence_1CodePointIterator) Ref() any { if t == nil { return nil }; return t }

func (t *CharSequence_1CodePointIterator) GetClass__Class() *Class { return CharSequence_1CodePointIterator_class }

func (t *CharSequence_1CodePointIterator) ToString__String() *String { return Object_toString(t) }

func (t *CharSequence_1CodePointIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharSequence_1CodePointIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharSequence_1CodePointIterator_InstanceOf(x any) bool { _, ok := x.(*CharSequence_1CodePointIterator); return ok }

func CharSequence_1CodePointIterator_Cast(x any) *CharSequence_1CodePointIterator { if x == nil { return nil }; v, ok := x.(*CharSequence_1CodePointIterator); if !ok { panic(ClassCast(x, CharSequence_1CodePointIterator_class)) }; return v }
