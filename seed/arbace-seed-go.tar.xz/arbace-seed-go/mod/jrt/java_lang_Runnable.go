//line java_lang_Runnable.ae:1
package jrt






type Runnable interface{ Object_I; Is_Runnable(); Run__V() }

func Runnable_InstanceOf(x any) bool { _, ok := x.(Runnable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Runnable_class) } }; return ok }

func Runnable_Cast(x any) Runnable { if x == nil { return nil }; v, ok := x.(Runnable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Runnable_class) } }; if !ok { panic(ClassCast(x, Runnable_class)) }; return v }
