//line java_lang_ProcessBuilder.ae:1
package jrt












func (t *ProcessBuilder) Start_ProcessBuilder_Redirect1__Process(redirects *RefArray) Process_I {
	var tmp1 List = t.F_command; var cmdarray *RefArray = A2g_CastArray[*RefArray](tmp1.ToArray_O1__O1(NewRefArray(String_class, t.F_command.Size__I())).Ref(), String_class.ArrayClass())
	cmdarray = NN(cmdarray).Copy()
	var arr_101077 *RefArray = cmdarray; var len_101078 int32 = int32(len(arr_101077.A)); var i_101079 int32 = 0; for ; i_101079 < len_101078; i_101079++ { var arg *String = As[*String](arr_101077.A[i_101079]); if arg == nil { panic(Thrown(NullPointerException_New())) } }
	var prog *String = As[*String](cmdarray.A[0]); var dir *String
	if !(t.F_directory == nil) { dir = NN(t.F_directory).ToString__String() } else { dir = nil }
	var arr_101080 *RefArray = cmdarray; var len_101081 int32 = int32(len(arr_101080.A)); var i_101082 int32 = 0; for ; i_101082 < len_101081; i_101082++ { var s *String = As[*String](arr_101080.A[i_101082])
		if NN(s).IndexOf_I__I(0) >= 0 {
			panic(Thrown(IOException_New_String(Lit_1153))) } }
	var tmp2 Process_I; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp2 = ProcessImpl_Start_String1_Map_String_ProcessBuilder_Redirect1_Z__Process(cmdarray, t.F_environment, dir, redirects, t.F_redirectErrorStream); return nil }()
//line :23:1
	if tmp3 != nil { if IOException_InstanceOf(tmp3) || IllegalArgumentException_InstanceOf(tmp3) { var e Exception_I = Exception_Cast(tmp3); var tmp4 *String





		if dir == nil { tmp4 = Lit_69 } else {

			tmp4 = Concat(Lit_1154, dir, Lit_1155) }
//line :26:1
		panic(Thrown(IOException_New_String_Throwable(Concat(Lit_1156, prog, Lit_1142, tmp4, Lit_1157, e.GetMessage__String()), e))) } else {
//line :23:1
			panic(tmp3) } }; return tmp2 }
func ProcessBuilder_New_List(p0 List) *ProcessBuilder { ProcessBuilder_Init(); t := &ProcessBuilder{}; t.Ctor_List(p0); return t }
//line :24:1
func (t *ProcessBuilder) Ctor_List(command List) {
	if command == nil { panic(Thrown(NullPointerException_New())) }
	t.F_command = command
}
func ProcessBuilder_New_String1(p0 *RefArray) *ProcessBuilder { ProcessBuilder_Init(); t := &ProcessBuilder{}; t.Ctor_String1(p0); return t }
//line :28:1
func (t *ProcessBuilder) Ctor_String1(command *RefArray) {
	t.F_command = ArrayList_New_I(int32(len(command.A)))
	var arr_101067 *RefArray = command; var len_101068 int32 = int32(len(arr_101067.A)); var i_101069 int32 = 0; for ; i_101069 < len_101068; i_101069++ { var arg *String = As[*String](arr_101067.A[i_101069]); t.F_command.Add_O__Z(arg.Ref())
	} }
func (t *ProcessBuilder) Command_List__ProcessBuilder(command List) *ProcessBuilder {
	if command == nil { panic(Thrown(NullPointerException_New())) }
	t.F_command = command
//line :32:1
	return t
}



func (t *ProcessBuilder) Command_String1__ProcessBuilder(command *RefArray) *ProcessBuilder {
	t.F_command = ArrayList_New_I(int32(len(command.A)))
	var arr_101070 *RefArray = command; var len_101071 int32 = int32(len(arr_101070.A)); var i_101072 int32 = 0; for ; i_101072 < len_101071; i_101072++ { var arg *String = As[*String](arr_101070.A[i_101072]); t.F_command.Add_O__Z(arg.Ref()) }
//line :37:1
	return t
}



func (t *ProcessBuilder) Command__List() List { return t.F_command }

func (t *ProcessBuilder) Environment__Map() Map {
	if t.F_environment == nil { t.F_environment = ProcessEnvironment_Environment__Map() }
	if !A2g_AssertionsDisabled && !!(t.F_environment == nil) { panic(Thrown(AssertionError_New())) }
//line :44:1
	return t.F_environment
}



func (t *ProcessBuilder) Environment_String1__ProcessBuilder(p0 *RefArray) *ProcessBuilder { panic(A2g_NotTranslated("java.lang.ProcessBuilder.environment([Ljava/lang/String;)Ljava/lang/ProcessBuilder;")) }














func (t *ProcessBuilder) Directory__File() *File { return t.F_directory }

func (t *ProcessBuilder) Directory_File__ProcessBuilder(directory *File) *ProcessBuilder {
	t.F_directory = directory
//line :66:1
	return t
}







func ProcessBuilder_NullInputStream_New() *ProcessBuilder_NullInputStream { ProcessBuilder_NullInputStream_Init(); t := &ProcessBuilder_NullInputStream{}; t.Ctor(); return t }
//line :75:1
func (t *ProcessBuilder_NullInputStream) Ctor() { t.InputStream.Ctor(t) }

func (t *ProcessBuilder_NullInputStream) Read__I() int32 { return -1 }

func (t *ProcessBuilder_NullInputStream) Available__I() int32 { return 0 }






func ProcessBuilder_NullOutputStream_New() *ProcessBuilder_NullOutputStream { ProcessBuilder_NullOutputStream_Init(); t := &ProcessBuilder_NullOutputStream{}; t.Ctor(); return t }
//line :86:1
func (t *ProcessBuilder_NullOutputStream) Ctor() { t.OutputStream.Ctor(t) }

func (t *ProcessBuilder_NullOutputStream) Write_I__V(b int32) {
	panic(Thrown(IOException_New_String(Lit_48)))
}











func (t *ProcessBuilder_Redirect_1) Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_PIPE }

func (t *ProcessBuilder_Redirect_1) ToString__String() *String { return NN(t.Type__ProcessBuilder_Redirect_Type()).ToString__String() }



func (t *ProcessBuilder_Redirect_2) Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_INHERIT }

func (t *ProcessBuilder_Redirect_2) ToString__String() *String { return NN(t.Type__ProcessBuilder_Redirect_Type()).ToString__String() }



func (t *ProcessBuilder_Redirect_3) Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_WRITE }

func (t *ProcessBuilder_Redirect_3) ToString__String() *String { return NN(t.Type__ProcessBuilder_Redirect_Type()).ToString__String() }

func (t *ProcessBuilder_Redirect_3) File__File() *File { return ProcessBuilder_Redirect_NULL_FILE }

func (t *ProcessBuilder_Redirect_3) Append__Z() bool { return false }

func (t *ProcessBuilder_Redirect) Impl_File__File(this ProcessBuilder_Redirect_I) *File { return nil }

func (t *ProcessBuilder_Redirect) Impl_Append__Z(this ProcessBuilder_Redirect_I) bool { panic(Thrown(UnsupportedOperationException_New())) }

func ProcessBuilder_Redirect_From_File__ProcessBuilder_Redirect(file *File) ProcessBuilder_Redirect_I { ProcessBuilder_Redirect_Init()
	if file == nil { panic(Thrown(NullPointerException_New())) }
	return ProcessBuilder_Redirect_4_New_File(file) }
func (t *ProcessBuilder_Redirect_4) Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_READ }

func (t *ProcessBuilder_Redirect_4) File__File() *File { return t.F_val_file }

func (t *ProcessBuilder_Redirect_4) ToString__String() *String {
	return Concat(Lit_1161, StrOfObj(t.F_val_file.Ref()), Lit_1142)
}
func ProcessBuilder_Redirect_To_File__ProcessBuilder_Redirect(file *File) ProcessBuilder_Redirect_I { ProcessBuilder_Redirect_Init()
	if file == nil { panic(Thrown(NullPointerException_New())) }
	return ProcessBuilder_Redirect_5_New_File(file) }
func (t *ProcessBuilder_Redirect_5) Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_WRITE }

func (t *ProcessBuilder_Redirect_5) File__File() *File { return t.F_val_file }

func (t *ProcessBuilder_Redirect_5) ToString__String() *String {
	return Concat(Lit_1162, StrOfObj(t.F_val_file.Ref()), Lit_1142)
}
func (t *ProcessBuilder_Redirect_5) Append__Z() bool { return false }

func ProcessBuilder_Redirect_AppendTo_File__ProcessBuilder_Redirect(file *File) ProcessBuilder_Redirect_I { ProcessBuilder_Redirect_Init()
	if file == nil { panic(Thrown(NullPointerException_New())) }
	return ProcessBuilder_Redirect_6_New_File(file) }
func (t *ProcessBuilder_Redirect_6) Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_APPEND }

func (t *ProcessBuilder_Redirect_6) File__File() *File { return t.F_val_file }

func (t *ProcessBuilder_Redirect_6) ToString__String() *String {
	return Concat(Lit_1163, StrOfObj(t.F_val_file.Ref()), Lit_1142)
}
func (t *ProcessBuilder_Redirect_6) Append__Z() bool { return true }

func (t *ProcessBuilder_Redirect) Impl_Equals_O__Z(this ProcessBuilder_Redirect_I, obj any) bool {
	if any(obj) == any(this) { return true } else {

		var tmp1 any = obj; if ProcessBuilder_Redirect_InstanceOf(tmp1) { var r ProcessBuilder_Redirect_I = ProcessBuilder_Redirect_Cast(tmp1)
			if !(r.Type__ProcessBuilder_Redirect_Type() == this.Type__ProcessBuilder_Redirect_Type()) { return false } else {

				if !A2g_AssertionsDisabled && !!(this.File__File() == nil) { panic(Thrown(AssertionError_New())) }; return NN(this.File__File()).Equals_O__Z(r.File__File().Ref()) } } else {
//line :163:1
					return false
				}
	}
}


func (t *ProcessBuilder_Redirect) Impl_HashCode__I(this ProcessBuilder_Redirect_I) int32 {
	var file *File = this.File__File(); if file == nil { return IdentityHash(this) } else { return NN(file).HashCode__I()
	} }
func (t *ProcessBuilder_Redirect) Ctor(this ProcessBuilder_Redirect_I) {}






func ProcessBuilder_RedirectPipeImpl_New() *ProcessBuilder_RedirectPipeImpl { ProcessBuilder_RedirectPipeImpl_Init(); t := &ProcessBuilder_RedirectPipeImpl{}; t.Ctor(); return t }
//line :179:1
func (t *ProcessBuilder_RedirectPipeImpl) Ctor() { t.ProcessBuilder_Redirect.Ctor(t); t.F_fd = FileDescriptor_New() }

func (t *ProcessBuilder_RedirectPipeImpl) Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_PIPE }


func (t *ProcessBuilder_RedirectPipeImpl) ToString__String() *String { return NN(t.Type__ProcessBuilder_Redirect_Type()).ToString__String() }

func (t *ProcessBuilder_RedirectPipeImpl) GetFd__FileDescriptor() *FileDescriptor { return t.F_fd }

func (t *ProcessBuilder) Redirects__ProcessBuilder_Redirect1() *RefArray {
	if t.F_redirects == nil {
		var tmp1 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp1 = ProcessBuilder_Redirect_PIPE; var tmp2 any = tmp1; var tmp3 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp3 = ProcessBuilder_Redirect_PIPE; var tmp4 any = tmp3; var tmp5 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp5 = ProcessBuilder_Redirect_PIPE; t.F_redirects = RefArrayOf(ProcessBuilder_Redirect_class, tmp2, tmp4, tmp5) }
//line :188:1
	return t.F_redirects
}



func (t *ProcessBuilder) RedirectInput_ProcessBuilder_Redirect__ProcessBuilder(source ProcessBuilder_Redirect_I) *ProcessBuilder {
	var tmp1 bool; var tmp2 bool; var tmp3 *ProcessBuilder_Redirect_Type = source.Type__ProcessBuilder_Redirect_Type(); var tmp4 *ProcessBuilder_Redirect_Type; ProcessBuilder_Redirect_Type_Init(); tmp4 = ProcessBuilder_Redirect_Type_WRITE; tmp2 = tmp3 == tmp4; if !tmp2 {
		var tmp5 *ProcessBuilder_Redirect_Type = source.Type__ProcessBuilder_Redirect_Type(); var tmp6 *ProcessBuilder_Redirect_Type; ProcessBuilder_Redirect_Type_Init(); tmp6 = ProcessBuilder_Redirect_Type_APPEND; tmp2 = tmp5 == tmp6 }
//line :194:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1151, StrOfObj(source))))) }
	t.Redirects__ProcessBuilder_Redirect1().Store(0, source)
//line :193:1
	return t
}





func (t *ProcessBuilder) RedirectOutput_ProcessBuilder_Redirect__ProcessBuilder(destination ProcessBuilder_Redirect_I) *ProcessBuilder {
	var tmp1 *ProcessBuilder_Redirect_Type = destination.Type__ProcessBuilder_Redirect_Type(); var tmp2 *ProcessBuilder_Redirect_Type; ProcessBuilder_Redirect_Type_Init(); tmp2 = ProcessBuilder_Redirect_Type_READ; if tmp1 == tmp2 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1152, StrOfObj(destination))))) }
	t.Redirects__ProcessBuilder_Redirect1().Store(1, destination)
//line :200:1
	return t
}




func (t *ProcessBuilder) RedirectError_ProcessBuilder_Redirect__ProcessBuilder(destination ProcessBuilder_Redirect_I) *ProcessBuilder {
	var tmp1 *ProcessBuilder_Redirect_Type = destination.Type__ProcessBuilder_Redirect_Type(); var tmp2 *ProcessBuilder_Redirect_Type; ProcessBuilder_Redirect_Type_Init(); tmp2 = ProcessBuilder_Redirect_Type_READ; if tmp1 == tmp2 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1152, StrOfObj(destination))))) }
	t.Redirects__ProcessBuilder_Redirect1().Store(2, destination)
//line :206:1
	return t
}




func (t *ProcessBuilder) RedirectInput_File__ProcessBuilder(file *File) *ProcessBuilder {
	return t.RedirectInput_ProcessBuilder_Redirect__ProcessBuilder(ProcessBuilder_Redirect_From_File__ProcessBuilder_Redirect(file))
}
func (t *ProcessBuilder) RedirectOutput_File__ProcessBuilder(file *File) *ProcessBuilder {
	return t.RedirectOutput_ProcessBuilder_Redirect__ProcessBuilder(ProcessBuilder_Redirect_To_File__ProcessBuilder_Redirect(file))
}
func (t *ProcessBuilder) RedirectError_File__ProcessBuilder(file *File) *ProcessBuilder {
	return t.RedirectError_ProcessBuilder_Redirect__ProcessBuilder(ProcessBuilder_Redirect_To_File__ProcessBuilder_Redirect(file))
}
func (t *ProcessBuilder) RedirectInput__ProcessBuilder_Redirect() ProcessBuilder_Redirect_I {
	if t.F_redirects == nil { ProcessBuilder_Redirect_Init(); return ProcessBuilder_Redirect_PIPE } else { return As[ProcessBuilder_Redirect_I](t.F_redirects.A[0])
	} }
func (t *ProcessBuilder) RedirectOutput__ProcessBuilder_Redirect() ProcessBuilder_Redirect_I {
	if t.F_redirects == nil { ProcessBuilder_Redirect_Init(); return ProcessBuilder_Redirect_PIPE } else { return As[ProcessBuilder_Redirect_I](t.F_redirects.A[1])
	} }
func (t *ProcessBuilder) RedirectError__ProcessBuilder_Redirect() ProcessBuilder_Redirect_I {
	if t.F_redirects == nil { ProcessBuilder_Redirect_Init(); return ProcessBuilder_Redirect_PIPE } else { return As[ProcessBuilder_Redirect_I](t.F_redirects.A[2])
	} }
func (t *ProcessBuilder) InheritIO__ProcessBuilder() *ProcessBuilder {
	var tmp1 *RefArray = t.Redirects__ProcessBuilder_Redirect1(); var tmp2 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp2 = ProcessBuilder_Redirect_INHERIT; Arrays_Fill_O1_O__V(tmp1, tmp2)
//line :230:1
	return t
}


func (t *ProcessBuilder) RedirectErrorStream__Z() bool { return t.F_redirectErrorStream }


func (t *ProcessBuilder) RedirectErrorStream_Z__ProcessBuilder(redirectErrorStream bool) *ProcessBuilder {
	t.F_redirectErrorStream = redirectErrorStream
//line :237:1
	return t
}


func (t *ProcessBuilder) Start__Process() Process_I {
	return t.Start_ProcessBuilder_Redirect1__Process(t.F_redirects)
}

















































func ProcessBuilder_StartPipeline_List__List(builders List) List { ProcessBuilder_Init()
	var numBuilders int32 = builders.Size__I(); var processes List = ArrayList_New_I(numBuilders); tmp6 := func() (exc Throwable_I) { defer Catch(&exc)


		{ var prevOutput ProcessBuilder_Redirect_I; var index int32 = 0
		L1: for {
			if index < builders.Size__I() {
				var builder *ProcessBuilder = ProcessBuilder_Cast(builders.Get_I__O(index)); var redirects *RefArray = NN(builder).Redirects__ProcessBuilder_Redirect1()

				if index > 0 {
					var tmp1 ProcessBuilder_Redirect_I = NN(builder).RedirectInput__ProcessBuilder_Redirect(); var tmp2 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp2 = ProcessBuilder_Redirect_PIPE; if tmp1 == tmp2 { } else {
						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1158, StrOfObj(NN(builder).RedirectInput__ProcessBuilder_Redirect())))))
					}


					redirects.Store(0, prevOutput) }
				if index < numBuilders-1 {
					var tmp3 ProcessBuilder_Redirect_I = NN(builder).RedirectOutput__ProcessBuilder_Redirect(); var tmp4 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp4 = ProcessBuilder_Redirect_PIPE; if tmp3 == tmp4 { } else {
						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1159, StrOfObj(NN(builder).RedirectOutput__ProcessBuilder_Redirect())))))
					}


					redirects.Store(1, ProcessBuilder_RedirectPipeImpl_New()) }
				processes.Add_O__Z(NN(builder).Start_ProcessBuilder_Redirect1__Process(redirects))
				var tmp5 ProcessBuilder_Redirect_I = prevOutput; if ProcessBuilder_RedirectPipeImpl_InstanceOf(tmp5) { var redir *ProcessBuilder_RedirectPipeImpl = ProcessBuilder_RedirectPipeImpl_Cast(tmp5)
					Process_PipeInputStream_New_FileDescriptor(NN(redir).GetFd__FileDescriptor()).Close__V() } else { }
				prevOutput = As[ProcessBuilder_Redirect_I](redirects.A[1])
				index = index + 1; continue L1 }
//line :298:1
			break L1
		}
		}



















		return nil }()
//line :296:1
	if tmp6 != nil { if Exception_InstanceOf(tmp6) { var ex Exception_I = Exception_Cast(tmp6)

























		processes.ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0 any) { Process_Cast(p0).DestroyForcibly__Process() }})
		processes.ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0_2 any) { var p Process_I = Process_Cast(p0_2); tmp7 := func() (exc Throwable_I) { defer Catch(&exc)


			p.WaitFor__I()
//line :323:1
			return nil }(); if

			tmp7 != nil { if InterruptedException_InstanceOf(tmp7) { var ie *InterruptedException = InterruptedException_Cast(tmp7); _ = ie

				Thread_CurrentThread__Thread().Interrupt__V() } else {
//line :325:1
					panic(tmp7) } } },
		},
		)
		panic(Thrown(ex)) } else {
//line :296:1
			panic(tmp6) } }
//line :294:1
	return processes
}




























type ProcessBuilder struct{ Object; F_command List; F_directory *File; F_environment Map; F_redirectErrorStream bool; F_redirects *RefArray }

var ProcessBuilder_init ClassInit

func ProcessBuilder_Init() { if !ProcessBuilder_init.Done() { ProcessBuilder_init.Run(ProcessBuilder_clinit) } }

func ProcessBuilder_clinit() {}

func (t *ProcessBuilder) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder) GetClass__Class() *Class { return ProcessBuilder_class }

func (t *ProcessBuilder) ToString__String() *String { return Object_toString(t) }

func (t *ProcessBuilder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder); return ok }

func ProcessBuilder_Cast(x any) *ProcessBuilder { if x == nil { return nil }; v, ok := x.(*ProcessBuilder); if !ok { panic(ClassCast(x, ProcessBuilder_class)) }; return v }



type ProcessBuilder_NullInputStream struct{ InputStream }

var ProcessBuilder_NullInputStream_INSTANCE *ProcessBuilder_NullInputStream

var ProcessBuilder_NullInputStream_init ClassInit

func ProcessBuilder_NullInputStream_Init() { if !ProcessBuilder_NullInputStream_init.Done() { ProcessBuilder_NullInputStream_init.Run(ProcessBuilder_NullInputStream_clinit) } }

func ProcessBuilder_NullInputStream_clinit() { ProcessBuilder_NullInputStream_INSTANCE = ProcessBuilder_NullInputStream_New() }

func (t *ProcessBuilder_NullInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *ProcessBuilder_NullInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *ProcessBuilder_NullInputStream) Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_Read_B1_I_I__I(t, p0, p1, p2) }

func (t *ProcessBuilder_NullInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *ProcessBuilder_NullInputStream) Close__V() { t.Impl_Close__V(t) }

func (t *ProcessBuilder_NullInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *ProcessBuilder_NullInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *ProcessBuilder_NullInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *ProcessBuilder_NullInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *ProcessBuilder_NullInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *ProcessBuilder_NullInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *ProcessBuilder_NullInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *ProcessBuilder_NullInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_NullInputStream) GetClass__Class() *Class { return ProcessBuilder_NullInputStream_class }

func (t *ProcessBuilder_NullInputStream) ToString__String() *String { return Object_toString(t) }

func (t *ProcessBuilder_NullInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_NullInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_NullInputStream_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_NullInputStream); return ok }

func ProcessBuilder_NullInputStream_Cast(x any) *ProcessBuilder_NullInputStream { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_NullInputStream); if !ok { panic(ClassCast(x, ProcessBuilder_NullInputStream_class)) }; return v }



type ProcessBuilder_NullOutputStream struct{ OutputStream }

var ProcessBuilder_NullOutputStream_INSTANCE *ProcessBuilder_NullOutputStream

var ProcessBuilder_NullOutputStream_init ClassInit

func ProcessBuilder_NullOutputStream_Init() { if !ProcessBuilder_NullOutputStream_init.Done() { ProcessBuilder_NullOutputStream_init.Run(ProcessBuilder_NullOutputStream_clinit) } }

func ProcessBuilder_NullOutputStream_clinit() { ProcessBuilder_NullOutputStream_INSTANCE = ProcessBuilder_NullOutputStream_New() }

func (t *ProcessBuilder_NullOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *ProcessBuilder_NullOutputStream) Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_Write_B1_I_I__V(t, p0, p1, p2) }

func (t *ProcessBuilder_NullOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *ProcessBuilder_NullOutputStream) Close__V() { t.Impl_Close__V(t) }

func (t *ProcessBuilder_NullOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_NullOutputStream) GetClass__Class() *Class { return ProcessBuilder_NullOutputStream_class }

func (t *ProcessBuilder_NullOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *ProcessBuilder_NullOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_NullOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_NullOutputStream_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_NullOutputStream); return ok }

func ProcessBuilder_NullOutputStream_Cast(x any) *ProcessBuilder_NullOutputStream { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_NullOutputStream); if !ok { panic(ClassCast(x, ProcessBuilder_NullOutputStream_class)) }; return v }



type ProcessBuilder_Redirect struct{ Object }

type ProcessBuilder_Redirect_I interface{ Object_I; Self_ProcessBuilder_Redirect() *ProcessBuilder_Redirect; Type__ProcessBuilder_Redirect_Type() *ProcessBuilder_Redirect_Type; File__File() *File; Append__Z() bool }

func (t *ProcessBuilder_Redirect) Self_ProcessBuilder_Redirect() *ProcessBuilder_Redirect { return t }

var ProcessBuilder_Redirect_PIPE ProcessBuilder_Redirect_I

var ProcessBuilder_Redirect_INHERIT ProcessBuilder_Redirect_I

var ProcessBuilder_Redirect_DISCARD ProcessBuilder_Redirect_I

var ProcessBuilder_Redirect_NULL_FILE *File

var ProcessBuilder_Redirect_init ClassInit

func ProcessBuilder_Redirect_Init() { if !ProcessBuilder_Redirect_init.Done() { ProcessBuilder_Redirect_init.Run(ProcessBuilder_Redirect_clinit) } }

func ProcessBuilder_Redirect_clinit() { ProcessBuilder_Redirect_PIPE = ProcessBuilder_Redirect_1_New(); ProcessBuilder_Redirect_INHERIT = ProcessBuilder_Redirect_2_New(); ProcessBuilder_Redirect_DISCARD = ProcessBuilder_Redirect_3_New(); ProcessBuilder_Redirect_NULL_FILE = File_New_String(Lit_1160) }

func ProcessBuilder_Redirect_InstanceOf(x any) bool { _, ok := x.(ProcessBuilder_Redirect_I); return ok }

func ProcessBuilder_Redirect_Cast(x any) ProcessBuilder_Redirect_I { if x == nil { return nil }; v, ok := x.(ProcessBuilder_Redirect_I); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_class)) }; return v }



type ProcessBuilder_Redirect_1 struct{ ProcessBuilder_Redirect }

var ProcessBuilder_Redirect_1_init ClassInit

func ProcessBuilder_Redirect_1_Init() { if !ProcessBuilder_Redirect_1_init.Done() { ProcessBuilder_Redirect_1_init.Run(ProcessBuilder_Redirect_1_clinit) } }

func ProcessBuilder_Redirect_1_clinit() { ProcessBuilder_Redirect_Init() }

func ProcessBuilder_Redirect_1_New() *ProcessBuilder_Redirect_1 { ProcessBuilder_Redirect_1_Init(); t := &ProcessBuilder_Redirect_1{}; t.Ctor(); return t }

func (t *ProcessBuilder_Redirect_1) Ctor() { t.ProcessBuilder_Redirect.Ctor(t) }

func (t *ProcessBuilder_Redirect_1) File__File() *File { return t.Impl_File__File(t) }

func (t *ProcessBuilder_Redirect_1) Append__Z() bool { return t.Impl_Append__Z(t) }

func (t *ProcessBuilder_Redirect_1) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessBuilder_Redirect_1) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessBuilder_Redirect_1) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_Redirect_1) GetClass__Class() *Class { return ProcessBuilder_Redirect_1_class }

func (t *ProcessBuilder_Redirect_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_Redirect_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_Redirect_1_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_Redirect_1); return ok }

func ProcessBuilder_Redirect_1_Cast(x any) *ProcessBuilder_Redirect_1 { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_Redirect_1); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_1_class)) }; return v }



type ProcessBuilder_Redirect_2 struct{ ProcessBuilder_Redirect }

var ProcessBuilder_Redirect_2_init ClassInit

func ProcessBuilder_Redirect_2_Init() { if !ProcessBuilder_Redirect_2_init.Done() { ProcessBuilder_Redirect_2_init.Run(ProcessBuilder_Redirect_2_clinit) } }

func ProcessBuilder_Redirect_2_clinit() { ProcessBuilder_Redirect_Init() }

func ProcessBuilder_Redirect_2_New() *ProcessBuilder_Redirect_2 { ProcessBuilder_Redirect_2_Init(); t := &ProcessBuilder_Redirect_2{}; t.Ctor(); return t }

func (t *ProcessBuilder_Redirect_2) Ctor() { t.ProcessBuilder_Redirect.Ctor(t) }

func (t *ProcessBuilder_Redirect_2) File__File() *File { return t.Impl_File__File(t) }

func (t *ProcessBuilder_Redirect_2) Append__Z() bool { return t.Impl_Append__Z(t) }

func (t *ProcessBuilder_Redirect_2) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessBuilder_Redirect_2) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessBuilder_Redirect_2) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_Redirect_2) GetClass__Class() *Class { return ProcessBuilder_Redirect_2_class }

func (t *ProcessBuilder_Redirect_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_Redirect_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_Redirect_2_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_Redirect_2); return ok }

func ProcessBuilder_Redirect_2_Cast(x any) *ProcessBuilder_Redirect_2 { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_Redirect_2); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_2_class)) }; return v }



type ProcessBuilder_Redirect_3 struct{ ProcessBuilder_Redirect }

var ProcessBuilder_Redirect_3_init ClassInit

func ProcessBuilder_Redirect_3_Init() { if !ProcessBuilder_Redirect_3_init.Done() { ProcessBuilder_Redirect_3_init.Run(ProcessBuilder_Redirect_3_clinit) } }

func ProcessBuilder_Redirect_3_clinit() { ProcessBuilder_Redirect_Init() }

func ProcessBuilder_Redirect_3_New() *ProcessBuilder_Redirect_3 { ProcessBuilder_Redirect_3_Init(); t := &ProcessBuilder_Redirect_3{}; t.Ctor(); return t }

func (t *ProcessBuilder_Redirect_3) Ctor() { t.ProcessBuilder_Redirect.Ctor(t) }

func (t *ProcessBuilder_Redirect_3) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessBuilder_Redirect_3) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessBuilder_Redirect_3) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_Redirect_3) GetClass__Class() *Class { return ProcessBuilder_Redirect_3_class }

func (t *ProcessBuilder_Redirect_3) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_Redirect_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_Redirect_3_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_Redirect_3); return ok }

func ProcessBuilder_Redirect_3_Cast(x any) *ProcessBuilder_Redirect_3 { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_Redirect_3); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_3_class)) }; return v }



type ProcessBuilder_Redirect_4 struct{ ProcessBuilder_Redirect; F_val_file *File }

var ProcessBuilder_Redirect_4_init ClassInit

func ProcessBuilder_Redirect_4_Init() { if !ProcessBuilder_Redirect_4_init.Done() { ProcessBuilder_Redirect_4_init.Run(ProcessBuilder_Redirect_4_clinit) } }

func ProcessBuilder_Redirect_4_clinit() { ProcessBuilder_Redirect_Init() }

func ProcessBuilder_Redirect_4_New_File(p0 *File) *ProcessBuilder_Redirect_4 { ProcessBuilder_Redirect_4_Init(); t := &ProcessBuilder_Redirect_4{}; t.Ctor_File(p0); return t }

func (t *ProcessBuilder_Redirect_4) Ctor_File(val_file *File) { t.F_val_file = val_file; t.ProcessBuilder_Redirect.Ctor(t) }

func (t *ProcessBuilder_Redirect_4) Append__Z() bool { return t.Impl_Append__Z(t) }

func (t *ProcessBuilder_Redirect_4) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessBuilder_Redirect_4) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessBuilder_Redirect_4) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_Redirect_4) GetClass__Class() *Class { return ProcessBuilder_Redirect_4_class }

func (t *ProcessBuilder_Redirect_4) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_Redirect_4) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_Redirect_4_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_Redirect_4); return ok }

func ProcessBuilder_Redirect_4_Cast(x any) *ProcessBuilder_Redirect_4 { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_Redirect_4); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_4_class)) }; return v }



type ProcessBuilder_Redirect_5 struct{ ProcessBuilder_Redirect; F_val_file *File }

var ProcessBuilder_Redirect_5_init ClassInit

func ProcessBuilder_Redirect_5_Init() { if !ProcessBuilder_Redirect_5_init.Done() { ProcessBuilder_Redirect_5_init.Run(ProcessBuilder_Redirect_5_clinit) } }

func ProcessBuilder_Redirect_5_clinit() { ProcessBuilder_Redirect_Init() }

func ProcessBuilder_Redirect_5_New_File(p0 *File) *ProcessBuilder_Redirect_5 { ProcessBuilder_Redirect_5_Init(); t := &ProcessBuilder_Redirect_5{}; t.Ctor_File(p0); return t }

func (t *ProcessBuilder_Redirect_5) Ctor_File(val_file *File) { t.F_val_file = val_file; t.ProcessBuilder_Redirect.Ctor(t) }

func (t *ProcessBuilder_Redirect_5) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessBuilder_Redirect_5) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessBuilder_Redirect_5) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_Redirect_5) GetClass__Class() *Class { return ProcessBuilder_Redirect_5_class }

func (t *ProcessBuilder_Redirect_5) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_Redirect_5) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_Redirect_5_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_Redirect_5); return ok }

func ProcessBuilder_Redirect_5_Cast(x any) *ProcessBuilder_Redirect_5 { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_Redirect_5); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_5_class)) }; return v }



type ProcessBuilder_Redirect_6 struct{ ProcessBuilder_Redirect; F_val_file *File }

var ProcessBuilder_Redirect_6_init ClassInit

func ProcessBuilder_Redirect_6_Init() { if !ProcessBuilder_Redirect_6_init.Done() { ProcessBuilder_Redirect_6_init.Run(ProcessBuilder_Redirect_6_clinit) } }

func ProcessBuilder_Redirect_6_clinit() { ProcessBuilder_Redirect_Init() }

func ProcessBuilder_Redirect_6_New_File(p0 *File) *ProcessBuilder_Redirect_6 { ProcessBuilder_Redirect_6_Init(); t := &ProcessBuilder_Redirect_6{}; t.Ctor_File(p0); return t }

func (t *ProcessBuilder_Redirect_6) Ctor_File(val_file *File) { t.F_val_file = val_file; t.ProcessBuilder_Redirect.Ctor(t) }

func (t *ProcessBuilder_Redirect_6) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessBuilder_Redirect_6) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessBuilder_Redirect_6) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_Redirect_6) GetClass__Class() *Class { return ProcessBuilder_Redirect_6_class }

func (t *ProcessBuilder_Redirect_6) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_Redirect_6) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_Redirect_6_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_Redirect_6); return ok }

func ProcessBuilder_Redirect_6_Cast(x any) *ProcessBuilder_Redirect_6 { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_Redirect_6); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_6_class)) }; return v }



type ProcessBuilder_Redirect_Type struct{ Enum }

func (t *ProcessBuilder_Redirect_Type) Is_Constable() {}

var ProcessBuilder_Redirect_Type_PIPE *ProcessBuilder_Redirect_Type

var ProcessBuilder_Redirect_Type_INHERIT *ProcessBuilder_Redirect_Type

var ProcessBuilder_Redirect_Type_READ *ProcessBuilder_Redirect_Type

var ProcessBuilder_Redirect_Type_WRITE *ProcessBuilder_Redirect_Type

var ProcessBuilder_Redirect_Type_APPEND *ProcessBuilder_Redirect_Type

var ProcessBuilder_Redirect_Type__VALUES *RefArray

var ProcessBuilder_Redirect_Type_init ClassInit

func ProcessBuilder_Redirect_Type_Init() { if !ProcessBuilder_Redirect_Type_init.Done() { ProcessBuilder_Redirect_Type_init.Run(ProcessBuilder_Redirect_Type_clinit) } }

func ProcessBuilder_Redirect_Type_clinit() { ProcessBuilder_Redirect_Type_PIPE = ProcessBuilder_Redirect_Type_New_String_I(Lit_1164, 0); ProcessBuilder_Redirect_Type_INHERIT = ProcessBuilder_Redirect_Type_New_String_I(Lit_1165, 1); ProcessBuilder_Redirect_Type_READ = ProcessBuilder_Redirect_Type_New_String_I(Lit_1166, 2); ProcessBuilder_Redirect_Type_WRITE = ProcessBuilder_Redirect_Type_New_String_I(Lit_1167, 3); ProcessBuilder_Redirect_Type_APPEND = ProcessBuilder_Redirect_Type_New_String_I(Lit_1168, 4); ProcessBuilder_Redirect_Type__VALUES = ProcessBuilder_Redirect_Type_X_values__ProcessBuilder_Redirect_Type1() }

func ProcessBuilder_Redirect_Type_New_String_I(p0 *String, p1 int32) *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); t := &ProcessBuilder_Redirect_Type{}; t.Ctor_String_I(p0, p1); return t }

func (t *ProcessBuilder_Redirect_Type) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func ProcessBuilder_Redirect_Type_Values__ProcessBuilder_Redirect_Type1() *RefArray { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type__VALUES.Copy() }

func ProcessBuilder_Redirect_Type_ValueOf_String__ProcessBuilder_Redirect_Type(p0 *String) *ProcessBuilder_Redirect_Type { ProcessBuilder_Redirect_Type_Init(); return ProcessBuilder_Redirect_Type_Cast(Enum_ValueOf_Class_String__Enum(ProcessBuilder_Redirect_Type_class, p0)) }

func ProcessBuilder_Redirect_Type_X_values__ProcessBuilder_Redirect_Type1() *RefArray { ProcessBuilder_Redirect_Type_Init(); return RefArrayOf(ProcessBuilder_Redirect_Type_class, ProcessBuilder_Redirect_Type_PIPE, ProcessBuilder_Redirect_Type_INHERIT, ProcessBuilder_Redirect_Type_READ, ProcessBuilder_Redirect_Type_WRITE, ProcessBuilder_Redirect_Type_APPEND) }

func (t *ProcessBuilder_Redirect_Type) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ProcessBuilder_Redirect_Type) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ProcessBuilder_Redirect_Type) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ProcessBuilder_Redirect_Type) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.lang.ProcessBuilder$Redirect$Type.describeConstable()Ljava/util/Optional;")) }

func (t *ProcessBuilder_Redirect_Type) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ProcessBuilder_Redirect_Type) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessBuilder_Redirect_Type) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_Redirect_Type) GetClass__Class() *Class { return ProcessBuilder_Redirect_Type_class }

func (t *ProcessBuilder_Redirect_Type) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_Redirect_Type_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_Redirect_Type); return ok }

func ProcessBuilder_Redirect_Type_Cast(x any) *ProcessBuilder_Redirect_Type { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_Redirect_Type); if !ok { panic(ClassCast(x, ProcessBuilder_Redirect_Type_class)) }; return v }



type ProcessBuilder_RedirectPipeImpl struct{ ProcessBuilder_Redirect; F_fd *FileDescriptor }

var ProcessBuilder_RedirectPipeImpl_init ClassInit

func ProcessBuilder_RedirectPipeImpl_Init() { if !ProcessBuilder_RedirectPipeImpl_init.Done() { ProcessBuilder_RedirectPipeImpl_init.Run(ProcessBuilder_RedirectPipeImpl_clinit) } }

func ProcessBuilder_RedirectPipeImpl_clinit() { ProcessBuilder_Redirect_Init() }

func (t *ProcessBuilder_RedirectPipeImpl) File__File() *File { return t.Impl_File__File(t) }

func (t *ProcessBuilder_RedirectPipeImpl) Append__Z() bool { return t.Impl_Append__Z(t) }

func (t *ProcessBuilder_RedirectPipeImpl) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ProcessBuilder_RedirectPipeImpl) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ProcessBuilder_RedirectPipeImpl) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessBuilder_RedirectPipeImpl) GetClass__Class() *Class { return ProcessBuilder_RedirectPipeImpl_class }

func (t *ProcessBuilder_RedirectPipeImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessBuilder_RedirectPipeImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessBuilder_RedirectPipeImpl_InstanceOf(x any) bool { _, ok := x.(*ProcessBuilder_RedirectPipeImpl); return ok }

func ProcessBuilder_RedirectPipeImpl_Cast(x any) *ProcessBuilder_RedirectPipeImpl { if x == nil { return nil }; v, ok := x.(*ProcessBuilder_RedirectPipeImpl); if !ok { panic(ClassCast(x, ProcessBuilder_RedirectPipeImpl_class)) }; return v }
