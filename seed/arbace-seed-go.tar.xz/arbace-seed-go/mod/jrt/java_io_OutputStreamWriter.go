//line java_io_OutputStreamWriter.ae:1
package jrt





























func OutputStreamWriter_New_OutputStream_String(p0 OutputStream_I, p1 *String) *OutputStreamWriter { t := &OutputStreamWriter{}; t.Ctor_OutputStream_String(t, p0, p1); return t }
//line :31:1
func (t *OutputStreamWriter) Ctor_OutputStream_String(this OutputStreamWriter_I, out OutputStream_I, charsetName *String) { t.Writer.Ctor_O(this, out); t.F_bb = NewByteArray(8192)


	if charsetName == nil { panic(Thrown(NullPointerException_New_String(Lit_85))) }
	var c Charset_I; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		c = Charset_ForName_String__Charset(charsetName)
//line :35:1
		return nil }()
	if tmp1 != nil { if IllegalCharsetNameException_InstanceOf(tmp1) || UnsupportedCharsetException_InstanceOf(tmp1) { var x IllegalArgumentException_I = IllegalArgumentException_Cast(tmp1); _ = x


		panic(Thrown(UnsupportedEncodingException_New_String(charsetName))) } else {
//line :36:1
			panic(tmp1)
		}
	}

	t.F_out = out
	t.F_cs = c
	t.F_kind = OutputStreamWriter_KindOf_Charset__I(c)
}
func OutputStreamWriter_New_OutputStream(p0 OutputStream_I) *OutputStreamWriter { t := &OutputStreamWriter{}; t.Ctor_OutputStream(t, p0); return t }
//line :44:1
func (t *OutputStreamWriter) Ctor_OutputStream(this OutputStreamWriter_I, out OutputStream_I) { t.Writer.Ctor_O(this, out); t.F_bb = NewByteArray(8192)

	t.F_out = out
	var tmp1 Charset_I; var tmp2 OutputStream_I = out; if PrintStream_InstanceOf(tmp2) { var ps *PrintStream = PrintStream_Cast(tmp2); tmp1 = NN(ps).Charset__Charset() } else { tmp1 = Charset_DefaultCharset__Charset() }; t.F_cs = tmp1
	t.F_kind = OutputStreamWriter_KindOf_Charset__I(t.F_cs)
}
func OutputStreamWriter_New_OutputStream_Charset(p0 OutputStream_I, p1 Charset_I) *OutputStreamWriter { t := &OutputStreamWriter{}; t.Ctor_OutputStream_Charset(t, p0, p1); return t }
//line :50:1
func (t *OutputStreamWriter) Ctor_OutputStream_Charset(this OutputStreamWriter_I, out OutputStream_I, cs Charset_I) { t.Writer.Ctor_O(this, out); t.F_bb = NewByteArray(8192)

	if cs == nil { panic(Thrown(NullPointerException_New_String(Lit_86))) }
	t.F_out = out
	t.F_cs = cs
	t.F_kind = OutputStreamWriter_KindOf_Charset__I(cs)
}
func OutputStreamWriter_KindOf_Charset__I(cs Charset_I) int32 {
	var n *String = cs.Name__String()
	if NN(n).Equals_O__Z(Lit_87) { return 1 } else { if NN(n).Equals_O__Z(Lit_88) { return 2 } else { if NN(n).Equals_O__Z(Lit_89) { return 0 } else {



		panic(Thrown(UnsupportedOperationException_New_String(Concat(Lit_90, n))))
	} } } }
func (t *OutputStreamWriter) Impl_GetEncoding__String(this OutputStreamWriter_I) *String {
	var tmp1 *String; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); if t.F_closed { tmp1 = nil } else { switch t.F_kind { case 1: tmp1 = Lit_92; case 2: tmp1 = Lit_93; default: tmp1 = Lit_91} } }(); return tmp1
}
func (t *OutputStreamWriter) Impl_EnsureOpen__V(this OutputStreamWriter_I) {
	if t.F_closed { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *OutputStreamWriter) Impl_Put_I__V(this OutputStreamWriter_I, b int32) {
	var tmp1 int32 = t.F_count; if tmp1 == int32(len(t.F_bb.A)) { t.Impl_WriteBytes__V(this) }
	var tmp2 *ByteArray = t.F_bb; var tmp3 int32; var old_1 int32 = t.F_count; t.F_count = t.F_count + 1; tmp3 = old_1; tmp2.A[tmp3] = int8(b)
}
func (t *OutputStreamWriter) Impl_WriteBytes__V(this OutputStreamWriter_I) {
	if t.F_count > 0 { var n int32 = t.F_count; t.F_count = 0; t.F_out.Write_B1_I_I__V(t.F_bb, 0, n)
	} }
func (t *OutputStreamWriter) Impl_Encode_I__V(this OutputStreamWriter_I, cp int32) {
	var tmp1 bool; var tmp2 bool
	tmp2 = Character_IsSurrogate_C__Z(uint16(cp)); if tmp2 { tmp2 = cp <= 65535 }; tmp1 = tmp2
//line :79:1
	if tmp1 {
		t.Impl_Put_I__V(this, 63) } else {
//line :79:1
			if t.F_kind == 1 {

				var tmp3 int32; if cp <= 255 { tmp3 = cp } else { tmp3 = 63 }; t.Impl_Put_I__V(this, tmp3) } else {
//line :79:1
					if t.F_kind == 2 {


						var tmp4 int32; if cp <= 127 { tmp4 = cp } else { tmp4 = 63 }; t.Impl_Put_I__V(this, tmp4) } else {
//line :79:1
							if cp < 128 {



								t.Impl_Put_I__V(this, cp) } else {
//line :79:1
									if cp < 2048 {






										t.Impl_Put_I__V(this, 192|cp>>6)
										t.Impl_Put_I__V(this, 128|cp&63) } else {
//line :79:1
											if cp < 65536 {










												t.Impl_Put_I__V(this, 224|cp>>12)
												t.Impl_Put_I__V(this, 128|cp>>6&63)
												t.Impl_Put_I__V(this, 128|cp&63) } else {


													t.Impl_Put_I__V(this, 240|cp>>18)
													t.Impl_Put_I__V(this, 128|cp>>12&63)
													t.Impl_Put_I__V(this, 128|cp>>6&63)
													t.Impl_Put_I__V(this, 128|cp&63)
												} } } } } } }
func (t *OutputStreamWriter) Impl_EncodeChar_C__V(this OutputStreamWriter_I, c uint16) {
	if int32(t.F_leftover) == 0 { } else {
		var h uint16 = t.F_leftover
		t.F_leftover = 0
		if Character_IsLowSurrogate_C__Z(c) { t.Impl_Encode_I__V(this, Character_ToCodePoint_C_C__I(h, c)); return }
		t.Impl_Put_I__V(this, 63) }
	if Character_IsHighSurrogate_C__Z(c) { t.F_leftover = c } else { t.Impl_Encode_I__V(this, int32(c))
	} }
func (t *OutputStreamWriter) Impl_Write_I__V(this OutputStreamWriter_I, c int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Impl_EnsureOpen__V(this); t.Impl_EncodeChar_C__V(this, uint16(c)) }()
}
func (t *OutputStreamWriter) Impl_Write_C1_I_I__V(this OutputStreamWriter_I, cbuf *CharArray, off, len_ int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
		var i int32 = off; L1: for {
			if i < off+len_ {
				t.Impl_EncodeChar_C__V(this, cbuf.A[i])
				i = i + 1; continue L1 }
//line :115:1
			break L1
		}
	}()
}

func (t *OutputStreamWriter) Impl_Write_String_I_I__V(this OutputStreamWriter_I, str *String, off, len_ int32) {
	if len_ < 0 { panic(Thrown(IndexOutOfBoundsException_New())) }
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		Objects_CheckFromIndexSize_I_I_I__I(off, len_, NN(str).Length__I())
		var i int32 = off; L1: for {
			if i < off+len_ {
				t.Impl_EncodeChar_C__V(this, NN(str).CharAt_I__C(i))
				i = i + 1; continue L1 }
//line :125:1
			break L1
		}
	}()
}

func (t *OutputStreamWriter) Impl_Append_CharSequence_I_I__Writer(this OutputStreamWriter_I, csq CharSequence, start, end int32) Writer_I {

	if csq == nil { csq = Lit_95 }
	return this.Append_CharSequence__Writer(csq.SubSequence_I_I__CharSequence(start, end))
}
func (t *OutputStreamWriter) Impl_Append_CharSequence__Writer(this OutputStreamWriter_I, csq CharSequence) Writer_I {
	var s *String = String_ValueOf_O__String(csq); this.Write_String_I_I__V(s, 0, NN(s).Length__I()); return this
}
func (t *OutputStreamWriter) Impl_FlushBuffer__V(this OutputStreamWriter_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Impl_EnsureOpen__V(this); t.Impl_WriteBytes__V(this) }()
}
func (t *OutputStreamWriter) Impl_Flush__V(this OutputStreamWriter_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Impl_EnsureOpen__V(this); t.Impl_WriteBytes__V(this); t.F_out.Flush__V() }()
}
func (t *OutputStreamWriter) Impl_Close__V(this OutputStreamWriter_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if t.F_closed { } else { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

			if int32(t.F_leftover) == 0 { } else { t.F_leftover = 0; t.Impl_Put_I__V(this, 63) }
			t.Impl_WriteBytes__V(this)
			t.F_out.Close__V(); return nil }()
			t.F_closed = true
//line :147:1
			if tmp2 != nil { panic(tmp2)
			}
		}
	}()
}



type OutputStreamWriter struct{ Writer; F_out OutputStream_I; F_cs Charset_I; F_kind int32; F_bb *ByteArray; F_count int32; F_leftover uint16; F_closed bool }

type OutputStreamWriter_I interface{ Writer_I; Appendable; Closeable; Flushable; AutoCloseable; Self_OutputStreamWriter() *OutputStreamWriter; GetEncoding__String() *String; Write_I__V(p0 int32); Write_C1_I_I__V(p0 *CharArray, p1, p2 int32); Write_String_I_I__V(p0 *String, p1, p2 int32); Append_CharSequence_I_I__Writer(p0 CharSequence, p1, p2 int32) Writer_I; Append_CharSequence__Writer(p0 CharSequence) Writer_I; FlushBuffer__V(); Flush__V(); Close__V(); Append_CharSequence__Appendable(p0 CharSequence) Appendable; Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable }

func (t *OutputStreamWriter) Self_OutputStreamWriter() *OutputStreamWriter { return t }

const OutputStreamWriter_UTF8 int32 = 0

const OutputStreamWriter_LATIN1 int32 = 1

const OutputStreamWriter_ASCII int32 = 2

func (t *OutputStreamWriter) Impl_Append_CharSequence__Appendable(this OutputStreamWriter_I, p0 CharSequence) Appendable { return this.Append_CharSequence__Writer(p0) }

func (t *OutputStreamWriter) Impl_Append_CharSequence_I_I__Appendable(this OutputStreamWriter_I, p0 CharSequence, p1, p2 int32) Appendable { return this.Append_CharSequence_I_I__Writer(p0, p1, p2) }

func (t *OutputStreamWriter) Write_C1__V(p0 *CharArray) { t.Impl_Write_C1__V(t, p0) }

func (t *OutputStreamWriter) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return t.Impl_Append_CharSequence_I_I__Appendable(t, p0, p1, p2) }

func (t *OutputStreamWriter) Append_CharSequence_I_I__Writer(p0 CharSequence, p1, p2 int32) Writer_I { return t.Impl_Append_CharSequence_I_I__Writer(t, p0, p1, p2) }

func (t *OutputStreamWriter) Flush__V() { t.Impl_Flush__V(t) }

func (t *OutputStreamWriter) Append_C__Writer(p0 uint16) Writer_I { return t.Impl_Append_C__Writer(t, p0) }

func (t *OutputStreamWriter) Close__V() { t.Impl_Close__V(t) }

func (t *OutputStreamWriter) Write_String__V(p0 *String) { t.Impl_Write_String__V(t, p0) }

func (t *OutputStreamWriter) Write_C1_I_I__V(p0 *CharArray, p1, p2 int32) { t.Impl_Write_C1_I_I__V(t, p0, p1, p2) }

func (t *OutputStreamWriter) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return t.Impl_Append_CharSequence__Appendable(t, p0) }

func (t *OutputStreamWriter) FlushBuffer__V() { t.Impl_FlushBuffer__V(t) }

func (t *OutputStreamWriter) Append_C__Appendable(p0 uint16) Appendable { return t.Impl_Append_C__Appendable(t, p0) }

func (t *OutputStreamWriter) Append_CharSequence__Writer(p0 CharSequence) Writer_I { return t.Impl_Append_CharSequence__Writer(t, p0) }

func (t *OutputStreamWriter) Write_I__V(p0 int32) { t.Impl_Write_I__V(t, p0) }

func (t *OutputStreamWriter) GetEncoding__String() *String { return t.Impl_GetEncoding__String(t) }

func (t *OutputStreamWriter) Write_String_I_I__V(p0 *String, p1, p2 int32) { t.Impl_Write_String_I_I__V(t, p0, p1, p2) }

func (t *OutputStreamWriter) Ref() any { if t == nil { return nil }; return t }

func (t *OutputStreamWriter) GetClass__Class() *Class { return OutputStreamWriter_class }

func (t *OutputStreamWriter) ToString__String() *String { return Object_toString(t) }

func (t *OutputStreamWriter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OutputStreamWriter) CloneShallow() any { panic(CloneNotSupported(t)) }

func OutputStreamWriter_InstanceOf(x any) bool { _, ok := x.(OutputStreamWriter_I); return ok }

func OutputStreamWriter_Cast(x any) OutputStreamWriter_I { if x == nil { return nil }; v, ok := x.(OutputStreamWriter_I); if !ok { panic(ClassCast(x, OutputStreamWriter_class)) }; return v }
