//line java_io_BufferedReader.ae:1
package jrt

































func BufferedReader_New_Reader_I(p0 Reader_I, p1 int32) *BufferedReader { t := &BufferedReader{}; t.Ctor_Reader_I(t, p0, p1); return t }
//line :35:1
func (t *BufferedReader) Ctor_Reader_I(this BufferedReader_I, in Reader_I, sz int32) { t.Reader.Ctor_O(this, in); t.F_markedChar = -1; t.F_readAheadLimit = 0; t.F_skipLF = false; t.F_markedSkipLF = false

	if sz <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_47))) }
	t.F_in = in
	t.F_cb = NewCharArray(sz)
	var tmp1 int32; var tmp2 int32 = 0; t.F_nChars = tmp2; tmp1 = tmp2; t.F_nextChar = tmp1
}
func BufferedReader_New_Reader(p0 Reader_I) *BufferedReader { t := &BufferedReader{}; t.Ctor_Reader(t, p0); return t }
//line :42:1
func (t *BufferedReader) Ctor_Reader(this BufferedReader_I, in Reader_I) { t.Ctor_Reader_I(this, in, 8192) }


func (t *BufferedReader) Impl_EnsureOpen__V(this BufferedReader_I) {
	if t.F_in == nil { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *BufferedReader) Impl_Fill__V(this BufferedReader_I) {
	var dst int32 = 0
	if t.F_markedChar <= -1 {
		dst = 0 } else {
			var delta int32 = t.F_nextChar - t.F_markedChar
			if delta >= t.F_readAheadLimit {
				t.F_markedChar = -2; t.F_readAheadLimit = 0; dst = 0 } else {

					var tmp1 int32 = t.F_readAheadLimit; if tmp1 <= int32(len(t.F_cb.A)) {

						System_Arraycopy_O_I_O_I_I__V(t.F_cb.Ref(), t.F_markedChar, t.F_cb.Ref(), 0, delta)
						t.F_markedChar = 0
						dst = delta } else {
							var ncb *CharArray = NewCharArray(t.F_readAheadLimit)
							System_Arraycopy_O_I_O_I_I__V(t.F_cb.Ref(), t.F_markedChar, ncb.Ref(), 0, delta)
							t.F_cb = ncb
							t.F_markedChar = 0
							dst = delta }
					var tmp2 int32; var tmp3 int32 = delta; t.F_nChars = tmp3; tmp2 = tmp3; t.F_nextChar = tmp2 } }
	var n int32 = 0
L1: for {
	var tmp4 Reader_I = t.F_in; var tmp5 *CharArray = t.F_cb; n = tmp4.Read_C1_I_I__I(tmp5, dst, int32(len(t.F_cb.A))-dst)
	if n == 0 { continue L1 }
//line :68:1
	break L1
}

	if n > 0 { t.F_nChars = dst + n; t.F_nextChar = dst
	} }
func (t *BufferedReader) Impl_Read__I(this BufferedReader_I) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); tmp3, tmp4 := func() (ctl, rv int32) { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
	L1: for {
		if t.F_nextChar >= t.F_nChars { t.Impl_Fill__V(this); if t.F_nextChar >= t.F_nChars { return 2, -1 } }
		if t.F_skipLF {
			t.F_skipLF = false
			if int32(t.F_cb.A[t.F_nextChar]) == 10 {
				t.F_nextChar = t.F_nextChar + 1
				continue L1 } }
		var nextChar_1 int32 = t.F_nextChar
		t.F_nextChar = t.F_nextChar + 1; return 3, int32(t.F_cb.A[nextChar_1])
//line :76:1
		continue L1
	}






		return 0, 0 }()
//line :74:1
	switch tmp3 { case 2: { return tmp4 }; case 3: { return tmp4 }}; return tmp1
}











func (t *BufferedReader) Impl_Read1_C1_I_I__I(this BufferedReader_I, cbuf *CharArray, off, len_ int32) int32 {
	if t.F_nextChar >= t.F_nChars {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len_ >= int32(len(t.F_cb.A)); if tmp3 { tmp3 = t.F_markedChar <= -1 }; tmp2 = tmp3; if tmp2 { tmp2 = !t.F_skipLF }; tmp1 = tmp2; if tmp1 {
			return t.F_in.Read_C1_I_I__I(cbuf, off, len_) }
		t.Impl_Fill__V(this) }
	if t.F_nextChar >= t.F_nChars { return -1 } else {


		if t.F_skipLF {
			t.F_skipLF = false
			if int32(t.F_cb.A[t.F_nextChar]) == 10 {
				t.F_nextChar = t.F_nextChar + 1
				if t.F_nextChar >= t.F_nChars { t.Impl_Fill__V(this) }
				if t.F_nextChar >= t.F_nChars { return -1 } } }
		var n int32 = Math_Min_I_I__I(len_, t.F_nChars-t.F_nextChar)
		System_Arraycopy_O_I_O_I_I__V(t.F_cb.Ref(), t.F_nextChar, cbuf.Ref(), off, n)
		t.F_nextChar = t.F_nextChar + n
//line :101:1
		return n
	}
}


func (t *BufferedReader) Impl_Read_C1_I_I__I(this BufferedReader_I, cbuf *CharArray, off, len_ int32) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
		Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
		if len_ == 0 { tmp1 = 0 } else {

			var n int32 = t.Impl_Read1_C1_I_I__I(this, cbuf, off, len_)
			if n <= 0 { tmp1 = n } else {


			L1: for { var tmp3 bool; var tmp4 bool; tmp4 = n < len_; if tmp4 { tmp4 = t.F_in.Ready__Z() }; tmp3 = tmp4; if tmp3 {
				var n1 int32 = t.Impl_Read1_C1_I_I__I(this, cbuf, off+n, len_-n)



				if n1 <= 0 { break L1 }
				n = n + n1
//line :116:1
				continue L1 }; break L1 }
//line :115:1
				tmp1 = n } } }()
//line :107:1
	return tmp1
}
















func (t *BufferedReader) Impl_ReadLine_Z_Z1__String(this BufferedReader_I, ignoreLF bool, term *BooleanArray) *String {
	var tmp1 *String; var tmp2 any = t.F_lock; MonitorEnter(tmp2); tmp10, tmp11 := func() (ctl int32, rv *String) { defer MonitorExit(tmp2)
		{ var s *StringBuilder
			var startChar int32 = 0
			t.Impl_EnsureOpen__V(this)
			var omitLF bool; var tmp3 bool; tmp3 = ignoreLF; if !tmp3 { tmp3 = t.F_skipLF }; omitLF = tmp3
			if !(term == nil) { term.A[0] = false }
		L1: for {
			if t.F_nextChar >= t.F_nChars { t.Impl_Fill__V(this) }
			if t.F_nextChar >= t.F_nChars {
				var tmp4 bool; var tmp5 bool; tmp5 = !(s == nil); if tmp5 { tmp5 = NN(s).Length__I() > 0 }; tmp4 = tmp5; if tmp4 { return 2, NN(s).ToString__String() } else { return 3, nil } }
			var eol bool = false; var c uint16 = 0; var i int32 = 0; var tmp6 bool; var tmp7 bool


			tmp7 = omitLF; if tmp7 { tmp7 = int32(t.F_cb.A[t.F_nextChar]) == 10 }; tmp6 = tmp7; if tmp6 {
				t.F_nextChar = t.F_nextChar + 1 }
			t.F_skipLF = false
			omitLF = false
			i = t.F_nextChar
		L2: for { if i < t.F_nChars {
			c = t.F_cb.A[i]
			var tmp8 bool; var tmp9 bool; tmp9 = int32(c) == 10; if !tmp9 { tmp9 = int32(c) == 13 }; tmp8 = tmp9; if tmp8 {
				if !(term == nil) { term.A[0] = true }
				eol = true
				break L2 }
			i = i + 1
//line :144:1
			continue L2 }; break L2
		}





			startChar = t.F_nextChar
			t.F_nextChar = i
			if eol {
				var str *String
				if s == nil {
					str = String_New_C1_I_I(t.F_cb, startChar, i-startChar) } else {

						NN(s).Append_C1_I_I__StringBuilder(t.F_cb, startChar, i-startChar)
						str = NN(s).ToString__String() }
				t.F_nextChar = t.F_nextChar + 1
				if int32(c) == 13 { t.F_skipLF = true }; return 4, str
			}
			if s == nil { s = StringBuilder_New_I(80) }
			NN(s).Append_C1_I_I__StringBuilder(t.F_cb, startChar, i-startChar)
//line :132:1
			continue L1
		}
		}





























		return 0, nil }()
//line :126:1
	switch tmp10 { case 2: { return tmp11 }; case 3: { return tmp11 }; case 4: { return tmp11 }}; return tmp1
}






































func (t *BufferedReader) Impl_ReadLine__String(this BufferedReader_I) *String {
	return this.ReadLine_Z_Z1__String(false, nil)
}
func (t *BufferedReader) Impl_Skip_J__J(this BufferedReader_I, n int64) int64 {
	if n < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_51))) }
	var tmp1 int64; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
		var r int64 = n
	L1: for { if r > 0 {
		if t.F_nextChar >= t.F_nChars { t.Impl_Fill__V(this) }
		if t.F_nextChar >= t.F_nChars { break L1 }
		if t.F_skipLF {
			t.F_skipLF = false
			if int32(t.F_cb.A[t.F_nextChar]) == 10 { t.F_nextChar = t.F_nextChar + 1 } }
		var d int64 = int64(t.F_nChars - t.F_nextChar)
		if r <= d {

			t.F_nextChar = t.F_nextChar + int32(r)
			r = 0
			break L1 } else {
				r = r - d; t.F_nextChar = t.F_nChars }
//line :174:1
		continue L1 }; break L1
	}











		tmp1 = n - r }()
//line :171:1
	return tmp1
}
















func (t *BufferedReader) Impl_Ready__Z(this BufferedReader_I) bool {
	var tmp1 bool; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.Impl_EnsureOpen__V(this)
		if t.F_skipLF {
			var tmp3 bool; var tmp4 bool; tmp4 = t.F_nextChar >= t.F_nChars; if tmp4 { tmp4 = t.F_in.Ready__Z() }; tmp3 = tmp4; if tmp3 { t.Impl_Fill__V(this) }
			if t.F_nextChar < t.F_nChars {
				if int32(t.F_cb.A[t.F_nextChar]) == 10 { t.F_nextChar = t.F_nextChar + 1 }
				t.F_skipLF = false } }
		var tmp5 bool; tmp5 = t.F_nextChar < t.F_nChars; if !tmp5 { tmp5 = t.F_in.Ready__Z() }; tmp1 = tmp5 }()
//line :190:1
	return tmp1
}







func (t *BufferedReader) Impl_MarkSupported__Z(this BufferedReader_I) bool { return true }

func (t *BufferedReader) Impl_Mark_I__V(this BufferedReader_I, readAheadLimit int32) {
	if readAheadLimit < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_52))) }
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		t.F_readAheadLimit = readAheadLimit
		t.F_markedChar = t.F_nextChar
		t.F_markedSkipLF = t.F_skipLF
	}() }
func (t *BufferedReader) Impl_Reset__V(this BufferedReader_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.Impl_EnsureOpen__V(this)
		if t.F_markedChar < 0 {
			var tmp2 *String; if t.F_markedChar == -2 { tmp2 = Lit_53 } else { tmp2 = Lit_54 }; panic(Thrown(IOException_New_String(tmp2)))
		}

		t.F_nextChar = t.F_markedChar
		t.F_skipLF = t.F_markedSkipLF
	}() }
func (t *BufferedReader) Impl_Close__V(this BufferedReader_I) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if !(t.F_in == nil) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc); t.F_in.Close__V(); return nil }(); t.F_in = nil; t.F_cb = nil; if tmp2 != nil { panic(tmp2)
		} } }() }
func (t *BufferedReader) Impl_Lines__Stream(this BufferedReader_I) Stream {
	var iter Iterator = BufferedReader_1_New_BufferedReader(this)















	return StreamSupport_Stream_Spliterator_Z__Stream(Spliterators_SpliteratorUnknownSize_Iterator_I__Spliterator(iter, 272), false) }
//line :227:1
func (t *BufferedReader_1) HasNext__Z() bool {
	if !(t.F_nextLine == nil) { return true } else {

		var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
			t.F_nextLine = t.F_this_0.ReadLine__String()
			tmp1 = !(t.F_nextLine == nil)
//line :230:1
			return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var e IOException_I = IOException_Cast(tmp2)



				panic(Thrown(UncheckedIOException_New_IOException(e))) } else {
//line :230:1
					panic(tmp2) } }; return tmp1
	}
}



func (t *BufferedReader_1) Next__String() *String {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_nextLine == nil); if !tmp2 { tmp2 = t.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		var line *String = t.F_nextLine; t.F_nextLine = nil; return line } else {
			panic(Thrown(NoSuchElementException_New()))
		}
}






type BufferedReader struct{ Reader; F_in Reader_I; F_cb *CharArray; F_nChars, F_nextChar, F_markedChar, F_readAheadLimit int32; F_skipLF, F_markedSkipLF bool }

type BufferedReader_I interface{ Reader_I; Closeable; AutoCloseable; Self_BufferedReader() *BufferedReader; Read__I() int32; Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32; ReadLine_Z_Z1__String(p0 bool, p1 *BooleanArray) *String; ReadLine__String() *String; Skip_J__J(p0 int64) int64; Ready__Z() bool; MarkSupported__Z() bool; Mark_I__V(p0 int32); Reset__V(); Close__V(); Lines__Stream() Stream }

func (t *BufferedReader) Self_BufferedReader() *BufferedReader { return t }

const BufferedReader_INVALIDATED int32 = -2

const BufferedReader_UNMARKED int32 = -1

const BufferedReader_DEFAULT_CHAR_BUFFER_SIZE int32 = 8192

const BufferedReader_DEFAULT_EXPECTED_LINE_LENGTH int32 = 80

func (t *BufferedReader) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *BufferedReader) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *BufferedReader) Lines__Stream() Stream { return t.Impl_Lines__Stream(t) }

func (t *BufferedReader) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *BufferedReader) ReadLine_Z_Z1__String(p0 bool, p1 *BooleanArray) *String { return t.Impl_ReadLine_Z_Z1__String(t, p0, p1) }

func (t *BufferedReader) Close__V() { t.Impl_Close__V(t) }

func (t *BufferedReader) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *BufferedReader) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *BufferedReader) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *BufferedReader) ReadLine__String() *String { return t.Impl_ReadLine__String(t) }

func (t *BufferedReader) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *BufferedReader) Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32 { return t.Impl_Read_C1_I_I__I(t, p0, p1, p2) }

func (t *BufferedReader) Reset__V() { t.Impl_Reset__V(t) }

func (t *BufferedReader) Ready__Z() bool { return t.Impl_Ready__Z(t) }

func (t *BufferedReader) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *BufferedReader) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *BufferedReader) Ref() any { if t == nil { return nil }; return t }

func (t *BufferedReader) GetClass__Class() *Class { return BufferedReader_class }

func (t *BufferedReader) ToString__String() *String { return Object_toString(t) }

func (t *BufferedReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BufferedReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func BufferedReader_InstanceOf(x any) bool { _, ok := x.(BufferedReader_I); return ok }

func BufferedReader_Cast(x any) BufferedReader_I { if x == nil { return nil }; v, ok := x.(BufferedReader_I); if !ok { panic(ClassCast(x, BufferedReader_class)) }; return v }



type BufferedReader_1 struct{ Object; F_nextLine *String; F_this_0 BufferedReader_I }

func (t *BufferedReader_1) Is_Iterator() {}

func BufferedReader_1_New_BufferedReader(p0 BufferedReader_I) *BufferedReader_1 { t := &BufferedReader_1{}; t.Ctor_BufferedReader(p0); return t }

func (t *BufferedReader_1) Ctor_BufferedReader(this_0 BufferedReader_I) { A2g_NotNull[BufferedReader_I](this_0); t.F_this_0 = this_0; t.F_nextLine = nil }

func (t *BufferedReader_1) Next__O() any { return t.Next__String().Ref() }

func (t *BufferedReader_1) Remove__V() { Iterator_Remove__V(t) }

func (t *BufferedReader_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *BufferedReader_1) Ref() any { if t == nil { return nil }; return t }

func (t *BufferedReader_1) GetClass__Class() *Class { return BufferedReader_1_class }

func (t *BufferedReader_1) ToString__String() *String { return Object_toString(t) }

func (t *BufferedReader_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BufferedReader_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func BufferedReader_1_InstanceOf(x any) bool { _, ok := x.(*BufferedReader_1); return ok }

func BufferedReader_1_Cast(x any) *BufferedReader_1 { if x == nil { return nil }; v, ok := x.(*BufferedReader_1); if !ok { panic(ClassCast(x, BufferedReader_1_class)) }; return v }
