//line java_io_ByteArrayInputStream.ae:1
package jrt


















func ByteArrayInputStream_New_B1(p0 *ByteArray) *ByteArrayInputStream { ByteArrayInputStream_Init(); t := &ByteArrayInputStream{}; t.Ctor_B1(p0); return t }
//line :20:1
func (t *ByteArrayInputStream) Ctor_B1(buf *ByteArray) { t.InputStream.Ctor(t); t.F_mark = 0
	t.F_buf = buf
	t.F_pos = 0
	t.F_count = int32(len(buf.A))
}
func ByteArrayInputStream_New_B1_I_I(p0 *ByteArray, p1, p2 int32) *ByteArrayInputStream { ByteArrayInputStream_Init(); t := &ByteArrayInputStream{}; t.Ctor_B1_I_I(p0, p1, p2); return t }
//line :25:1
func (t *ByteArrayInputStream) Ctor_B1_I_I(buf *ByteArray, offset, length int32) { t.InputStream.Ctor(t); t.F_mark = 0
	t.F_buf = buf
	t.F_pos = offset
	t.F_count = Math_Min_I_I__I(offset+length, int32(len(buf.A)))
	t.F_mark = offset
}
func (t *ByteArrayInputStream) Read__I() int32 { MonitorEnter(t); defer MonitorExit(t)
	if t.F_pos < t.F_count {
		var tmp1 *ByteArray = t.F_buf; var tmp2 int32; var old_1 int32 = t.F_pos; t.F_pos = t.F_pos + 1; tmp2 = old_1; return int32(tmp1.A[tmp2]) & 255 } else {
//line :32:1
			return -1
		}
}

func (t *ByteArrayInputStream) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 { MonitorEnter(t); defer MonitorExit(t)
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	if t.F_pos >= t.F_count { return -1 } else {

		var avail int32 = t.F_count - t.F_pos
		if len_ > avail { len_ = avail }
		if len_ <= 0 { return 0 } else {

			System_Arraycopy_O_I_O_I_I__V(t.F_buf.Ref(), t.F_pos, b.Ref(), off, len_); t.F_pos = t.F_pos + len_; return len_
		} } }
func (t *ByteArrayInputStream) ReadAllBytes__B1() *ByteArray { MonitorEnter(t); defer MonitorExit(t)
	var result *ByteArray = Arrays_CopyOfRange_B1_I_I__B1(t.F_buf, t.F_pos, t.F_count); t.F_pos = t.F_count; return result
}
func (t *ByteArrayInputStream) ReadNBytes_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	var n int32 = t.Read_B1_I_I__I(b, off, len_); if n == -1 { return 0 } else { return n
	} }
func (t *ByteArrayInputStream) TransferTo_OutputStream__J(out OutputStream_I) int64 { MonitorEnter(t); defer MonitorExit(t); var tmp1 int32; var len_ int32 = t.F_count - t.F_pos; if

	len_ > 0 {
		var tmpbuf *ByteArray; var outClass *Class = out.GetClass__Class(); var tmp2 bool; var tmp3 bool; var tmp4 bool

		tmp4 = outClass == ByteArrayOutputStream_class; if !tmp4 {
			tmp4 = outClass == FileOutputStream_class }
//line :57:1
		tmp3 = tmp4; if !tmp3 {

			tmp3 = outClass == PipedOutputStream_class }
//line :57:1
		tmp2 = tmp3; if tmp2 {


			tmpbuf = nil } else {
				tmpbuf = NewByteArray(Integer_Min_I_I__I(len_, 131072)) }
		var nwritten int32 = 0
	L1: for { if nwritten < len_ {
		var nbyte int32 = Integer_Min_I_I__I(len_-nwritten, 131072)
		if !(tmpbuf == nil) {
			System_Arraycopy_O_I_O_I_I__V(t.F_buf.Ref(), t.F_pos, tmpbuf.Ref(), 0, nbyte); out.Write_B1_I_I__V(tmpbuf, 0, nbyte) } else {
				out.Write_B1_I_I__V(t.F_buf, t.F_pos, nbyte) }
		t.F_pos = t.F_pos + nbyte
		nwritten = nwritten + nbyte
//line :63:1
		continue L1 }; break L1
	}





		if !A2g_AssertionsDisabled && !(t.F_pos == t.F_count) { panic(Thrown(AssertionError_New())) } }; tmp1 = len_; return /*line :52:1*/ int64(tmp1) }




















func (t *ByteArrayInputStream) Skip_J__J(n int64) int64 { MonitorEnter(t); defer MonitorExit(t)
	var k int64 = int64(t.F_count - t.F_pos)
	if n < k { var tmp1 int64; if n < 0 { tmp1 = 0 } else { tmp1 = n }; k = tmp1 }
	t.F_pos = t.F_pos + int32(k)
//line :74:1
	return k
}



func (t *ByteArrayInputStream) Available__I() int32 { MonitorEnter(t); defer MonitorExit(t)
	return t.F_count - t.F_pos
}
func (t *ByteArrayInputStream) MarkSupported__Z() bool { return true }

func (t *ByteArrayInputStream) Mark_I__V(readAheadLimit int32) { t.F_mark = t.F_pos }

func (t *ByteArrayInputStream) Reset__V() { MonitorEnter(t); defer MonitorExit(t); t.F_pos = t.F_mark }

func (t *ByteArrayInputStream) Close__V() {}



type ByteArrayInputStream struct{ InputStream; F_buf *ByteArray; F_pos, F_mark, F_count int32 }

const ByteArrayInputStream_MAX_TRANSFER_SIZE int32 = 131072

var ByteArrayInputStream_init ClassInit

func ByteArrayInputStream_Init() { if !ByteArrayInputStream_init.Done() { ByteArrayInputStream_init.Run(ByteArrayInputStream_clinit) } }

func ByteArrayInputStream_clinit() {}

func (t *ByteArrayInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *ByteArrayInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *ByteArrayInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *ByteArrayInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *ByteArrayInputStream) GetClass__Class() *Class { return ByteArrayInputStream_class }

func (t *ByteArrayInputStream) ToString__String() *String { return Object_toString(t) }

func (t *ByteArrayInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ByteArrayInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func ByteArrayInputStream_InstanceOf(x any) bool { _, ok := x.(*ByteArrayInputStream); return ok }

func ByteArrayInputStream_Cast(x any) *ByteArrayInputStream { if x == nil { return nil }; v, ok := x.(*ByteArrayInputStream); if !ok { panic(ClassCast(x, ByteArrayInputStream_class)) }; return v }
