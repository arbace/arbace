//line java_security_NoSuchAlgorithmException.ae:1
package jrt








func NoSuchAlgorithmException_New() *NoSuchAlgorithmException { t := &NoSuchAlgorithmException{}; t.Ctor(); return t }
//line :10:1
func (t *NoSuchAlgorithmException) Ctor() { t.GeneralSecurityException.Ctor(t) }

func NoSuchAlgorithmException_New_String(p0 *String) *NoSuchAlgorithmException { t := &NoSuchAlgorithmException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NoSuchAlgorithmException) Ctor_String(msg *String) { t.GeneralSecurityException.Ctor_String(t, msg) }

func NoSuchAlgorithmException_New_String_Throwable(p0 *String, p1 Throwable_I) *NoSuchAlgorithmException { t := &NoSuchAlgorithmException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *NoSuchAlgorithmException) Ctor_String_Throwable(message *String, cause Throwable_I) { t.GeneralSecurityException.Ctor_String_Throwable(t, message, cause) }


func NoSuchAlgorithmException_New_Throwable(p0 Throwable_I) *NoSuchAlgorithmException { t := &NoSuchAlgorithmException{}; t.Ctor_Throwable(p0); return t }
//line :17:1
func (t *NoSuchAlgorithmException) Ctor_Throwable(cause Throwable_I) { t.GeneralSecurityException.Ctor_Throwable(t, cause) }










type NoSuchAlgorithmException struct{ GeneralSecurityException }

const NoSuchAlgorithmException_serialVersionUID int64 = -7443947487218346562

func (t *NoSuchAlgorithmException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoSuchAlgorithmException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoSuchAlgorithmException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoSuchAlgorithmException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoSuchAlgorithmException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoSuchAlgorithmException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoSuchAlgorithmException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoSuchAlgorithmException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoSuchAlgorithmException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoSuchAlgorithmException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoSuchAlgorithmException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoSuchAlgorithmException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoSuchAlgorithmException) Ref() any { if t == nil { return nil }; return t }

func (t *NoSuchAlgorithmException) GetClass__Class() *Class { return NoSuchAlgorithmException_class }

func (t *NoSuchAlgorithmException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoSuchAlgorithmException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoSuchAlgorithmException_InstanceOf(x any) bool { _, ok := x.(*NoSuchAlgorithmException); return ok }

func NoSuchAlgorithmException_Cast(x any) *NoSuchAlgorithmException { if x == nil { return nil }; v, ok := x.(*NoSuchAlgorithmException); if !ok { panic(ClassCast(x, NoSuchAlgorithmException_class)) }; return v }
