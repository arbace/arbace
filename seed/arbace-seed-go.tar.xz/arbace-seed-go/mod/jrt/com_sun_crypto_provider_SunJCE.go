//line com_sun_crypto_provider_SunJCE.ae:1
package jrt

import "sync/atomic"









func (t *SunJCE) PutEntries__V() {
	var attrs HashMap_I = HashMap_New_I(3)
	attrs.Put_O_O__O(Lit_31, Lit_32)
	t.Ps_String_String_String_List_HashMap__V(Lit_33, Lit_34, Lit_24, nil, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_35, Lit_19, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_36, Lit_20, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_37, Lit_21, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_38, Lit_22, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_39, Lit_23, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_40, Lit_17, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_41, Lit_18, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_42, Lit_25, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_43, Lit_26, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_44, Lit_27, attrs)
	t.PsA_String_String_String_HashMap__V(Lit_33, Lit_45, Lit_28, attrs) }
//line :24:1
func SunJCE_GetRandom__SecureRandom() *SecureRandom { SunJCE_Init(); panic(A2g_NotTranslated("com.sun.crypto.provider.SunJCE.getRandom()Ljava/security/SecureRandom;")) }

func (t *SunJCE) Ps_String_String_String__V(p0, p1, p2 *String) { panic(A2g_NotTranslated("com.sun.crypto.provider.SunJCE.ps(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V")) }


func (t *SunJCE) Ps_String_String_String_List_HashMap__V(type_, algo, cn *String, als List, attrs HashMap_I) {

	t.PutService_Provider_Service__V(Provider_Service_New_Provider_String_String_String_List_Map(t, type_, algo, cn, als, attrs))
}
func (t *SunJCE) PsA_String_String_String_HashMap__V(type_, algo, cn *String, attrs HashMap_I) {

	t.PutService_Provider_Service__V(Provider_Service_New_Provider_String_String_String_List_Map(t, type_, algo, cn, SecurityProviderConstants_GetAliases_String__List(algo), attrs))
}






func SunJCE_New() *SunJCE { SunJCE_Init(); t := &SunJCE{}; t.Ctor(); return t }
//line :43:1
func (t *SunJCE) Ctor() { var tmp1 *String; SecurityConstants_Init(); tmp1 = SecurityConstants_PROVIDER_VER; t.Provider.Ctor_String_String_String(t, Lit_29, tmp1, Lit_30);

	t.PutEntries__V(); if
	SunJCE_instance.Load() == nil { SunJCE_instance.Store(t) } }



















































































































































































































































































































































































































































































































































































































































































































































































func SunJCE_GetInstance__SunJCE() *SunJCE { SunJCE_Init(); panic(A2g_NotTranslated("com.sun.crypto.provider.SunJCE.getInstance()Lcom/sun/crypto/provider/SunJCE;")) }



type SunJCE struct{ Provider }

const SunJCE_serialVersionUID int64 = 6812507587804302833

var SunJCE_info *String = Lit_30

const SunJCE_debug bool = false

var SunJCE_instance atomic.Pointer[SunJCE]

var SunJCE_init ClassInit

func SunJCE_Init() { if !SunJCE_init.Done() { SunJCE_init.Run(SunJCE_clinit) } }

func SunJCE_clinit() { Provider_Init() }

func (t *SunJCE) LoadFromXML_InputStream__V(p0 InputStream_I) { t.Impl_LoadFromXML_InputStream__V(t, p0) }

func (t *SunJCE) PropertyNames__Enumeration() Enumeration { return t.Impl_PropertyNames__Enumeration(t) }

func (t *SunJCE) GetDefaultSecureRandomService__Provider_Service() *Provider_Service { return t.Impl_GetDefaultSecureRandomService__Provider_Service(t) }

func (t *SunJCE) Rehash__V() { t.Impl_Rehash__V(t) }

func (t *SunJCE) GetVersion__D() float64 { return t.Impl_GetVersion__D(t) }

func (t *SunJCE) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *SunJCE) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *SunJCE) CloneHashtable__Hashtable() Hashtable_I { return t.Impl_CloneHashtable__Hashtable(t) }

func (t *SunJCE) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *SunJCE) Clear__V() { t.Impl_Clear__V(t) }

func (t *SunJCE) Load_InputStream__V(p0 InputStream_I) { t.Impl_Load_InputStream__V(t, p0) }

func (t *SunJCE) GetVersionStr__String() *String { return t.Impl_GetVersionStr__String(t) }

func (t *SunJCE) SetProperty_String_String__O(p0, p1 *String) any { return t.Impl_SetProperty_String_String__O(t, p0, p1) }

func (t *SunJCE) RemoveService_Provider_Service__V(p0 *Provider_Service) { t.Impl_RemoveService_Provider_Service__V(t, p0) }

func (t *SunJCE) GetService_String_String__Provider_Service(p0, p1 *String) *Provider_Service { return t.Impl_GetService_String_String__Provider_Service(t, p0, p1) }

func (t *SunJCE) StoreToXML_OutputStream_String_Charset__V(p0 OutputStream_I, p1 *String, p2 Charset_I) { t.Impl_StoreToXML_OutputStream_String_Charset__V(t, p0, p1, p2) }

func (t *SunJCE) Keys__Enumeration() Enumeration { return t.Impl_Keys__Enumeration(t) }

func (t *SunJCE) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *SunJCE) StoreToXML_OutputStream_String_String__V(p0 OutputStream_I, p1, p2 *String) { t.Impl_StoreToXML_OutputStream_String_String__V(t, p0, p1, p2) }

func (t *SunJCE) GetProperty_String__String(p0 *String) *String { return t.Impl_GetProperty_String__String(t, p0) }

func (t *SunJCE) StringPropertyNames__Set() Set { return t.Impl_StringPropertyNames__Set(t) }

func (t *SunJCE) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *SunJCE) Save_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_Save_OutputStream_String__V(t, p0, p1) }

func (t *SunJCE) GetName__String() *String { return t.Impl_GetName__String(t) }

func (t *SunJCE) IsConfigured__Z() bool { return t.Impl_IsConfigured__Z(t) }

func (t *SunJCE) StoreToXML_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_StoreToXML_OutputStream_String__V(t, p0, p1) }

func (t *SunJCE) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *SunJCE) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *SunJCE) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *SunJCE) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *SunJCE) Store_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_Store_OutputStream_String__V(t, p0, p1) }

func (t *SunJCE) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *SunJCE) GetProperty_String_String__String(p0, p1 *String) *String { return t.Impl_GetProperty_String_String__String(t, p0, p1) }

func (t *SunJCE) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *SunJCE) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *SunJCE) Load_Reader__V(p0 Reader_I) { t.Impl_Load_Reader__V(t, p0) }

func (t *SunJCE) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *SunJCE) Configure_String__Provider(p0 *String) Provider_I { return t.Impl_Configure_String__Provider(t, p0) }

func (t *SunJCE) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *SunJCE) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *SunJCE) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *SunJCE) List_PrintStream__V(p0 *PrintStream) { t.Impl_List_PrintStream__V(t, p0) }

func (t *SunJCE) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *SunJCE) Store_Writer_String__V(p0 Writer_I, p1 *String) { t.Impl_Store_Writer_String__V(t, p0, p1) }

func (t *SunJCE) GetInfo__String() *String { return t.Impl_GetInfo__String(t) }

func (t *SunJCE) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *SunJCE) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *SunJCE) List_PrintWriter__V(p0 *PrintWriter) { t.Impl_List_PrintWriter__V(t, p0) }

func (t *SunJCE) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *SunJCE) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *SunJCE) GetServices__Set() Set { return t.Impl_GetServices__Set(t) }

func (t *SunJCE) Elements__Enumeration() Enumeration { return t.Impl_Elements__Enumeration(t) }

func (t *SunJCE) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *SunJCE) PutService_Provider_Service__V(p0 *Provider_Service) { t.Impl_PutService_Provider_Service__V(t, p0) }

func (t *SunJCE) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *SunJCE) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *SunJCE) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *SunJCE) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *SunJCE) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *SunJCE) Ref() any { if t == nil { return nil }; return t }

func (t *SunJCE) GetClass__Class() *Class { return SunJCE_class }

func (t *SunJCE) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func SunJCE_InstanceOf(x any) bool { _, ok := x.(*SunJCE); return ok }

func SunJCE_Cast(x any) *SunJCE { if x == nil { return nil }; v, ok := x.(*SunJCE); if !ok { panic(ClassCast(x, SunJCE_class)) }; return v }
