//line java_nio_ByteBufferAsIntBufferB.ae:1
package jrt














func ByteBufferAsIntBufferB_New_ByteBuffer_MemorySegment(p0 ByteBuffer_I, p1 MemorySegment) *ByteBufferAsIntBufferB { ByteBufferAsIntBufferB_Init(); t := &ByteBufferAsIntBufferB{}; t.Ctor_ByteBuffer_MemorySegment(p0, p1); return t }
//line :16:1
func (t *ByteBufferAsIntBufferB) Ctor_ByteBuffer_MemorySegment(bb ByteBuffer_I, segment MemorySegment) { panic(A2g_NotTranslated("java.nio.ByteBufferAsIntBufferB.<init>(Ljava/nio/ByteBuffer;Ljava/lang/foreign/MemorySegment;)V")) }










func ByteBufferAsIntBufferB_New_ByteBuffer_I_I_I_I_J_MemorySegment(p0 ByteBuffer_I, p1, p2, p3, p4 int32, p5 int64, p6 MemorySegment) *ByteBufferAsIntBufferB { ByteBufferAsIntBufferB_Init(); t := &ByteBufferAsIntBufferB{}; t.Ctor_ByteBuffer_I_I_I_I_J_MemorySegment(p0, p1, p2, p3, p4, p5, p6); return t }
//line :27:1
func (t *ByteBufferAsIntBufferB) Ctor_ByteBuffer_I_I_I_I_J_MemorySegment(bb ByteBuffer_I, mark, pos, lim, cap_ int32, addr int64, segment MemorySegment) { t.IntBuffer.Ctor_I_I_I_I_MemorySegment(t, mark, pos, lim, cap_, segment)


	t.F_bb = bb
	t.F_address = addr
	var tmp1 int64 = t.F_address; if !A2g_AssertionsDisabled && !(tmp1 >= bb.Self_Buffer().F_address) { panic(Thrown(AssertionError_New()))
	} }
func (t *ByteBufferAsIntBufferB) Base__O() any { return t.F_bb.Self_ByteBuffer().F_hb.Ref() }

func (t *ByteBufferAsIntBufferB) Slice__IntBuffer() IntBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32

	if pos <= lim { rem = lim - pos } else { rem = 0 }
//line :37:1
	var addr int64 = t.ByteOffset_J__J(int64(pos))



	return ByteBufferAsIntBufferB_New_ByteBuffer_I_I_I_I_J_MemorySegment(t.F_bb, -1, 0, rem, rem, addr, t.F_segment)
}
func (t *ByteBufferAsIntBufferB) Slice_I_I__IntBuffer(index, length int32) IntBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	var tmp1 ByteBuffer_I = t.F_bb; return ByteBufferAsIntBufferB_New_ByteBuffer_I_I_I_I_J_MemorySegment(tmp1, -1, 0, length, length, t.ByteOffset_J__J(int64(index)), t.F_segment)
}
func (t *ByteBufferAsIntBufferB) Duplicate__IntBuffer() IntBuffer_I {
	var tmp1 ByteBuffer_I = t.F_bb; return ByteBufferAsIntBufferB_New_ByteBuffer_I_I_I_I_J_MemorySegment(tmp1, t.MarkValue__I(), t.Position__I(), t.Limit__I(), t.Capacity__I(), t.F_address, t.F_segment)
}






func (t *ByteBufferAsIntBufferB) AsReadOnlyBuffer__IntBuffer() IntBuffer_I {
	return A2g_Missing[IntBuffer_I]("class java.nio.ByteBufferAsIntBufferRB is not in the closed world")
}






func (t *ByteBufferAsIntBufferB) Ix_I__I(i int32) int32 {
	var tmp1 int64 = t.F_address; var off int32 = int32(tmp1 - t.F_bb.Self_Buffer().F_address)
	return i<<2 + off
}
func (t *ByteBufferAsIntBufferB) ByteOffset_J__J(i int64) int64 {
	return i<<2 + t.F_address
}
func (t *ByteBufferAsIntBufferB) Get__I() int32 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref(); var x int32 = NN(tmp1).GetIntUnaligned_MemorySessionImpl_O_J_Z__I(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextGetIndex__I())), true); return x
}





func (t *ByteBufferAsIntBufferB) Get_I__I(i int32) int32 {
	var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref(); var x int32 = NN(tmp1).GetIntUnaligned_MemorySessionImpl_O_J_Z__I(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I__I(i))), true); return x
}





func (t *ByteBufferAsIntBufferB) Put_I__IntBuffer(x int32) IntBuffer_I {
	var y int32 = x; var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref()
	NN(tmp1).PutIntUnaligned_MemorySessionImpl_O_J_I_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.NextPutIndex__I())), y, true)
//line :89:1
	return t
}







func (t *ByteBufferAsIntBufferB) Put_I_I__IntBuffer(i, x int32) IntBuffer_I {
	var y int32 = x; var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; var tmp2 MemorySessionImpl_I = t.Session__MemorySessionImpl(); var tmp3 any = t.F_bb.Self_ByteBuffer().F_hb.Ref()
	NN(tmp1).PutIntUnaligned_MemorySessionImpl_O_J_I_Z__V(tmp2, tmp3, t.ByteOffset_J__J(int64(t.CheckIndex_I__I(i))), y, true)
//line :99:1
	return t
}







func (t *ByteBufferAsIntBufferB) Compact__IntBuffer() IntBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I()

	if !A2g_AssertionsDisabled && !(pos <= lim) { panic(Thrown(AssertionError_New())) }
	var rem int32; if pos <= lim { rem = lim - pos } else { rem = 0 }; var db ByteBuffer_I = t.F_bb.Duplicate__ByteBuffer()

	db.Limit_I__ByteBuffer(t.Ix_I__I(lim))
	db.Position_I__ByteBuffer(t.Ix_I__I(0))
	var sb ByteBuffer_I = db.Slice__ByteBuffer()
	sb.Position_I__ByteBuffer(pos << 2)
	sb.Compact__ByteBuffer()
	t.Position_I__IntBuffer(rem)
	t.Limit_I__IntBuffer(t.Capacity__I())
	t.DiscardMark__V()
//line :116:1
	return t
}






func (t *ByteBufferAsIntBufferB) IsDirect__Z() bool { return t.F_bb.IsDirect__Z() }

func (t *ByteBufferAsIntBufferB) IsReadOnly__Z() bool { return false }

func (t *ByteBufferAsIntBufferB) ScaleShifts__I() int32 { panic(A2g_NotTranslated("java.nio.ByteBufferAsIntBufferB.scaleShifts()I")) }







func (t *ByteBufferAsIntBufferB) Order__ByteOrder() *ByteOrder { ByteOrder_Init(); return ByteOrder_BIG_ENDIAN }



type ByteBufferAsIntBufferB struct{ IntBuffer; F_bb ByteBuffer_I }

var ByteBufferAsIntBufferB_init ClassInit

func ByteBufferAsIntBufferB_Init() { if !ByteBufferAsIntBufferB_init.Done() { ByteBufferAsIntBufferB_init.Run(ByteBufferAsIntBufferB_clinit) } }

func ByteBufferAsIntBufferB_clinit() { IntBuffer_Init() }

func (t *ByteBufferAsIntBufferB) Slice__Buffer() Buffer_I { return t.Slice__IntBuffer() }

func (t *ByteBufferAsIntBufferB) Slice_I_I__Buffer(p0, p1 int32) Buffer_I { return t.Slice_I_I__IntBuffer(p0, p1) }

func (t *ByteBufferAsIntBufferB) Duplicate__Buffer() Buffer_I { return t.Duplicate__IntBuffer() }

func (t *ByteBufferAsIntBufferB) Mark__IntBuffer() IntBuffer_I { return t.Impl_Mark__IntBuffer(t) }

func (t *ByteBufferAsIntBufferB) Array__O() any { return t.Impl_Array__O(t) }

func (t *ByteBufferAsIntBufferB) Put_I_IntBuffer_I_I__IntBuffer(p0 int32, p1 IntBuffer_I, p2, p3 int32) IntBuffer_I { return t.Impl_Put_I_IntBuffer_I_I__IntBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsIntBufferB) PutBuffer_I_IntBuffer_I_I__V(p0 int32, p1 IntBuffer_I, p2, p3 int32) { t.Impl_PutBuffer_I_IntBuffer_I_I__V(t, p0, p1, p2, p3) }

func (t *ByteBufferAsIntBufferB) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *ByteBufferAsIntBufferB) NextGetIndex__I() int32 { return t.Impl_NextGetIndex__I(t) }

func (t *ByteBufferAsIntBufferB) Limit_I__IntBuffer(p0 int32) IntBuffer_I { return t.Impl_Limit_I__IntBuffer(t, p0) }

func (t *ByteBufferAsIntBufferB) Clear__Buffer() Buffer_I { return t.Impl_Clear__Buffer(t) }

func (t *ByteBufferAsIntBufferB) Mismatch_IntBuffer__I(p0 IntBuffer_I) int32 { return t.Impl_Mismatch_IntBuffer__I(t, p0) }

func (t *ByteBufferAsIntBufferB) Position_I__IntBuffer(p0 int32) IntBuffer_I { return t.Impl_Position_I__IntBuffer(t, p0) }

func (t *ByteBufferAsIntBufferB) CompareTo_IntBuffer__I(p0 IntBuffer_I) int32 { return t.Impl_CompareTo_IntBuffer__I(t, p0) }

func (t *ByteBufferAsIntBufferB) Session__MemorySessionImpl() MemorySessionImpl_I { return t.Impl_Session__MemorySessionImpl(t) }

func (t *ByteBufferAsIntBufferB) Put_I_I1__IntBuffer(p0 int32, p1 *IntArray) IntBuffer_I { return t.Impl_Put_I_I1__IntBuffer(t, p0, p1) }

func (t *ByteBufferAsIntBufferB) Limit__I() int32 { return t.Impl_Limit__I(t) }

func (t *ByteBufferAsIntBufferB) Array__I1() *IntArray { return t.Impl_Array__I1(t) }

func (t *ByteBufferAsIntBufferB) Remaining__I() int32 { return t.Impl_Remaining__I(t) }

func (t *ByteBufferAsIntBufferB) NextGetIndex_I__I(p0 int32) int32 { return t.Impl_NextGetIndex_I__I(t, p0) }

func (t *ByteBufferAsIntBufferB) Clear__IntBuffer() IntBuffer_I { return t.Impl_Clear__IntBuffer(t) }

func (t *ByteBufferAsIntBufferB) Flip__IntBuffer() IntBuffer_I { return t.Impl_Flip__IntBuffer(t) }

func (t *ByteBufferAsIntBufferB) NextPutIndex__I() int32 { return t.Impl_NextPutIndex__I(t) }

func (t *ByteBufferAsIntBufferB) DiscardMark__V() { t.Impl_DiscardMark__V(t) }

func (t *ByteBufferAsIntBufferB) Flip__Buffer() Buffer_I { return t.Impl_Flip__Buffer(t) }

func (t *ByteBufferAsIntBufferB) ArrayOffset__I() int32 { return t.Impl_ArrayOffset__I(t) }

func (t *ByteBufferAsIntBufferB) MarkValue__I() int32 { return t.Impl_MarkValue__I(t) }

func (t *ByteBufferAsIntBufferB) Rewind__Buffer() Buffer_I { return t.Impl_Rewind__Buffer(t) }

func (t *ByteBufferAsIntBufferB) HasArray__Z() bool { return t.Impl_HasArray__Z(t) }

func (t *ByteBufferAsIntBufferB) Get_I1__IntBuffer(p0 *IntArray) IntBuffer_I { return t.Impl_Get_I1__IntBuffer(t, p0) }

func (t *ByteBufferAsIntBufferB) PutArray_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I { return t.Impl_PutArray_I_I1_I_I__IntBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsIntBufferB) Get_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I { return t.Impl_Get_I_I1_I_I__IntBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsIntBufferB) Reset__IntBuffer() IntBuffer_I { return t.Impl_Reset__IntBuffer(t) }

func (t *ByteBufferAsIntBufferB) Position__I() int32 { return t.Impl_Position__I(t) }

func (t *ByteBufferAsIntBufferB) Reset__Buffer() Buffer_I { return t.Impl_Reset__Buffer(t) }

func (t *ByteBufferAsIntBufferB) Put_I1__IntBuffer(p0 *IntArray) IntBuffer_I { return t.Impl_Put_I1__IntBuffer(t, p0) }

func (t *ByteBufferAsIntBufferB) Put_I1_I_I__IntBuffer(p0 *IntArray, p1, p2 int32) IntBuffer_I { return t.Impl_Put_I1_I_I__IntBuffer(t, p0, p1, p2) }

func (t *ByteBufferAsIntBufferB) CheckIndex_I_I__I(p0, p1 int32) int32 { return t.Impl_CheckIndex_I_I__I(t, p0, p1) }

func (t *ByteBufferAsIntBufferB) CheckSession__V() { t.Impl_CheckSession__V(t) }

func (t *ByteBufferAsIntBufferB) CheckIndex_I__I(p0 int32) int32 { return t.Impl_CheckIndex_I__I(t, p0) }

func (t *ByteBufferAsIntBufferB) Position_I__Buffer(p0 int32) Buffer_I { return t.Impl_Position_I__Buffer(t, p0) }

func (t *ByteBufferAsIntBufferB) Rewind__IntBuffer() IntBuffer_I { return t.Impl_Rewind__IntBuffer(t) }

func (t *ByteBufferAsIntBufferB) Get_I1_I_I__IntBuffer(p0 *IntArray, p1, p2 int32) IntBuffer_I { return t.Impl_Get_I1_I_I__IntBuffer(t, p0, p1, p2) }

func (t *ByteBufferAsIntBufferB) Get_I_I1__IntBuffer(p0 int32, p1 *IntArray) IntBuffer_I { return t.Impl_Get_I_I1__IntBuffer(t, p0, p1) }

func (t *ByteBufferAsIntBufferB) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ByteBufferAsIntBufferB) Mark__Buffer() Buffer_I { return t.Impl_Mark__Buffer(t) }

func (t *ByteBufferAsIntBufferB) Put_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I { return t.Impl_Put_I_I1_I_I__IntBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsIntBufferB) HasRemaining__Z() bool { return t.Impl_HasRemaining__Z(t) }

func (t *ByteBufferAsIntBufferB) NextPutIndex_I__I(p0 int32) int32 { return t.Impl_NextPutIndex_I__I(t, p0) }

func (t *ByteBufferAsIntBufferB) Limit_I__Buffer(p0 int32) Buffer_I { return t.Impl_Limit_I__Buffer(t, p0) }

func (t *ByteBufferAsIntBufferB) Put_IntBuffer__IntBuffer(p0 IntBuffer_I) IntBuffer_I { return t.Impl_Put_IntBuffer__IntBuffer(t, p0) }

func (t *ByteBufferAsIntBufferB) GetArray_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I { return t.Impl_GetArray_I_I1_I_I__IntBuffer(t, p0, p1, p2, p3) }

func (t *ByteBufferAsIntBufferB) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ByteBufferAsIntBufferB) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ByteBufferAsIntBufferB) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ByteBufferAsIntBufferB) Ref() any { if t == nil { return nil }; return t }

func (t *ByteBufferAsIntBufferB) GetClass__Class() *Class { return ByteBufferAsIntBufferB_class }

func (t *ByteBufferAsIntBufferB) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ByteBufferAsIntBufferB) CloneShallow() any { panic(CloneNotSupported(t)) }

func ByteBufferAsIntBufferB_InstanceOf(x any) bool { _, ok := x.(*ByteBufferAsIntBufferB); return ok }

func ByteBufferAsIntBufferB_Cast(x any) *ByteBufferAsIntBufferB { if x == nil { return nil }; v, ok := x.(*ByteBufferAsIntBufferB); if !ok { panic(ClassCast(x, ByteBufferAsIntBufferB_class)) }; return v }
