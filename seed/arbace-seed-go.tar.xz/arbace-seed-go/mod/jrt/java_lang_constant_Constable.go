//line java_lang_constant_Constable.ae:1
package jrt






type Constable interface{ Object_I; Is_Constable(); DescribeConstable__Optional() *Optional }

func Constable_InstanceOf(x any) bool { _, ok := x.(Constable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Constable_class) } }; return ok }

func Constable_Cast(x any) Constable { if x == nil { return nil }; v, ok := x.(Constable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Constable_class) } }; if !ok { panic(ClassCast(x, Constable_class)) }; return v }
