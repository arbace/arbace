//line java_util_SimpleTimeZone.ae:1
package jrt

import "sync/atomic"







func SimpleTimeZone_New_I_String(p0 int32, p1 *String) *SimpleTimeZone { SimpleTimeZone_Init(); t := &SimpleTimeZone{}; t.Ctor_I_String(p0, p1); return t }
//line :11:1
func (t *SimpleTimeZone) Ctor_I_String(rawOffset int32, ID_ *String) { t.TimeZone.Ctor(t); t.F_useDaylight = false; t.F_monthLength = SimpleTimeZone_staticMonthLength; t.F_serialVersionOnStream = 2
	t.F_rawOffset = rawOffset
	t.SetID_String__V(ID_)
	t.F_dstSavings = 3600000
}
func SimpleTimeZone_New_I_String_I_I_I_I_I_I_I_I(p0 int32, p1 *String, p2, p3, p4, p5, p6, p7, p8, p9 int32) *SimpleTimeZone { SimpleTimeZone_Init(); t := &SimpleTimeZone{}; t.Ctor_I_String_I_I_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :16:1
func (t *SimpleTimeZone) Ctor_I_String_I_I_I_I_I_I_I_I(rawOffset int32, ID_ *String, startMonth, startDay, startDayOfWeek, startTime, endMonth, endDay, endDayOfWeek, endTime int32) { t.Ctor_I_String_I_I_I_I_I_I_I_I_I_I_I(rawOffset, ID_, startMonth, startDay, startDayOfWeek, startTime, 0, endMonth, endDay, endDayOfWeek, endTime, 0, 3600000) }
















func SimpleTimeZone_New_I_String_I_I_I_I_I_I_I_I_I(p0 int32, p1 *String, p2, p3, p4, p5, p6, p7, p8, p9, p10 int32) *SimpleTimeZone { SimpleTimeZone_Init(); t := &SimpleTimeZone{}; t.Ctor_I_String_I_I_I_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10); return t }
//line :33:1
func (t *SimpleTimeZone) Ctor_I_String_I_I_I_I_I_I_I_I_I(rawOffset int32, ID_ *String, startMonth, startDay, startDayOfWeek, startTime, endMonth, endDay, endDayOfWeek, endTime, dstSavings int32) { t.Ctor_I_String_I_I_I_I_I_I_I_I_I_I_I(rawOffset, ID_, startMonth, startDay, startDayOfWeek, startTime, 0, endMonth, endDay, endDayOfWeek, endTime, 0, dstSavings) }
















func SimpleTimeZone_New_I_String_I_I_I_I_I_I_I_I_I_I_I(p0 int32, p1 *String, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12 int32) *SimpleTimeZone { SimpleTimeZone_Init(); t := &SimpleTimeZone{}; t.Ctor_I_String_I_I_I_I_I_I_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12); return t }
//line :50:1
func (t *SimpleTimeZone) Ctor_I_String_I_I_I_I_I_I_I_I_I_I_I(rawOffset int32, ID_ *String, startMonth, startDay, startDayOfWeek, startTime, startTimeMode, endMonth, endDay, endDayOfWeek, endTime, endTimeMode, dstSavings int32) { t.TimeZone.Ctor(t); t.F_useDaylight = false; t.F_monthLength = SimpleTimeZone_staticMonthLength; t.F_serialVersionOnStream = 2


	t.SetID_String__V(ID_)
	t.F_rawOffset = rawOffset
	t.F_startMonth = startMonth
	t.F_startDay = startDay
	t.F_startDayOfWeek = startDayOfWeek
	t.F_startTime = startTime
	t.F_startTimeMode = startTimeMode
	t.F_endMonth = endMonth
	t.F_endDay = endDay
	t.F_endDayOfWeek = endDayOfWeek
	t.F_endTime = endTime
	t.F_endTimeMode = endTimeMode
	t.F_dstSavings = dstSavings
	t.DecodeRules__V()
	if dstSavings <= 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2834, StrOfInt(dstSavings)))))
	} }
func (t *SimpleTimeZone) SetStartYear_I__V(year int32) {
	t.F_startYear = year
	t.InvalidateCache__V()
}
func (t *SimpleTimeZone) SetStartRule_I_I_I_I__V(startMonth, startDay, startDayOfWeek, startTime int32) {

	t.F_startMonth = startMonth
	t.F_startDay = startDay
	t.F_startDayOfWeek = startDayOfWeek
	t.F_startTime = startTime
	t.F_startTimeMode = 0
	t.DecodeStartRule__V()
	t.InvalidateCache__V()
}
func (t *SimpleTimeZone) SetStartRule_I_I_I__V(startMonth, startDay, startTime int32) {
	t.SetStartRule_I_I_I_I__V(startMonth, startDay, 0, startTime)
}
func (t *SimpleTimeZone) SetStartRule_I_I_I_I_Z__V(startMonth, startDay, startDayOfWeek, startTime int32, after bool) {

	if after {
		t.SetStartRule_I_I_I_I__V(startMonth, startDay, -startDayOfWeek, startTime) } else {
			t.SetStartRule_I_I_I_I__V(startMonth, -startDay, -startDayOfWeek, startTime)
		}
}



func (t *SimpleTimeZone) SetEndRule_I_I_I_I__V(endMonth, endDay, endDayOfWeek, endTime int32) {
	t.F_endMonth = endMonth
	t.F_endDay = endDay
	t.F_endDayOfWeek = endDayOfWeek
	t.F_endTime = endTime
	t.F_endTimeMode = 0
	t.DecodeEndRule__V()
	t.InvalidateCache__V()
}
func (t *SimpleTimeZone) SetEndRule_I_I_I__V(endMonth, endDay, endTime int32) {
	t.SetEndRule_I_I_I_I__V(endMonth, endDay, 0, endTime)
}
func (t *SimpleTimeZone) SetEndRule_I_I_I_I_Z__V(endMonth, endDay, endDayOfWeek, endTime int32, after bool) {

	if after {
		t.SetEndRule_I_I_I_I__V(endMonth, endDay, -endDayOfWeek, endTime) } else {
			t.SetEndRule_I_I_I_I__V(endMonth, -endDay, -endDayOfWeek, endTime)
		}
}



func (t *SimpleTimeZone) GetOffset_J__I(date int64) int32 {
	return t.GetOffsets_J_I1__I(date, nil)
}
func (t *SimpleTimeZone) GetOffsets_J_I1__I(date int64, offsets *IntArray) int32 {
	var offset int32 = t.F_rawOffset
L1: switch { default:
	if t.F_useDaylight {
		var cache *SimpleTimeZone_Cache = t.F_cache.Load()
		if !(cache == nil) {
			var tmp1 bool; var tmp2 bool; tmp2 = date >= cache.F_start; if tmp2 { tmp2 = date < cache.F_end }; tmp1 = tmp2; if tmp1 {
				offset = offset + t.F_dstSavings
				break L1 } }
		var cal BaseCalendar_I; if date >= -12219292800000 { cal = Up_Gregorian_BaseCalendar(SimpleTimeZone_gcal) } else {

			cal = BaseCalendar_Cast(CalendarSystem_ForName_String__CalendarSystem(Lit_2835)) }
//line :131:1
		var cdate BaseCalendar_Date_I = BaseCalendar_Date_Cast(cal.NewCalendarDate_TimeZone__CalendarDate(TimeZone_NO_TIMEZONE))



		cal.GetCalendarDate_J_CalendarDate__CalendarDate(date+int64(t.F_rawOffset), cdate)
		var year int32 = cdate.GetNormalizedYear__I()
		if year >= t.F_startYear {
			cdate.SetTimeOfDay_I_I_I_I__CalendarDate(0, 0, 0, 0)
			offset = t.GetOffset_BaseCalendar_BaseCalendar_Date_I_J__I(cal, cdate, year, date) } }}
	if !(offsets == nil) {
		offsets.A[0] = t.F_rawOffset
		offsets.A[1] = offset - t.F_rawOffset }
//line :123:1
	return offset
}




















func (t *SimpleTimeZone) GetOffset_I_I_I_I_I_I__I(era, year, month, day, dayOfWeek, millis int32) int32 {

	var tmp1 bool; var tmp2 bool; tmp2 = !(era == 1); if tmp2 { tmp2 = !(era == 0) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2836, StrOfInt(era))))) }
	var y int32 = year
	if era == 0 { y = 1 - y }
	if y >= 292278994 {
		y = 2800 + y%2800 } else {
//line :151:1
			if y <= -292269054 {

				y = int32(CalendarUtils_Mod_J_J__J(int64(y), 28)) } }
	var m int32 = month + 1; var cal BaseCalendar_I = Up_Gregorian_BaseCalendar(SimpleTimeZone_gcal); var cdate BaseCalendar_Date_I = BaseCalendar_Date_Cast(cal.NewCalendarDate_TimeZone__CalendarDate(TimeZone_NO_TIMEZONE))


	cdate.SetDate_I_I_I__CalendarDate(y, m, day)
	var time int64 = cal.GetTime_CalendarDate__J(cdate)
	time = time + int64(millis-t.F_rawOffset)
	if time < -12219292800000 {
		cal = BaseCalendar_Cast(CalendarSystem_ForName_String__CalendarSystem(Lit_2835))
		cdate = BaseCalendar_Date_Cast(cal.NewCalendarDate_TimeZone__CalendarDate(TimeZone_NO_TIMEZONE))
		cdate.SetNormalizedDate_I_I_I__BaseCalendar_Date(y, m, day)
		time = cal.GetTime_CalendarDate__J(cdate) + int64(millis) - int64(t.F_rawOffset) }
	var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = !(cdate.GetNormalizedYear__I() == y); if !tmp7 {
		tmp7 = !(cdate.GetMonth__I() == m) }
//line :165:1
	tmp6 = tmp7; if !tmp6 {

		tmp6 = !(cdate.GetDayOfMonth__I() == day) }
//line :165:1
	tmp5 = tmp6; if !tmp5 {


		var tmp8 bool; tmp8 = dayOfWeek < 1; if !tmp8 { tmp8 = dayOfWeek > 7 }; tmp5 = tmp8 }
//line :165:1
	tmp4 = tmp5; if !tmp4 {



		var tmp9 bool; tmp9 = millis < 0; if !tmp9 {
			tmp9 = millis >= 86400000 }
//line :169:1
		tmp4 = tmp9 }
//line :165:1
	tmp3 = tmp4; if tmp3 {








		panic(Thrown(IllegalArgumentException_New())) }
	var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = !t.F_useDaylight; if !tmp12 { tmp12 = year < t.F_startYear }; tmp11 = tmp12; if !tmp11 { tmp11 = !(era == 1) }; tmp10 = tmp11; if tmp10 { return t.F_rawOffset } else {

		return t.GetOffset_BaseCalendar_BaseCalendar_Date_I_J__I(cal, cdate, y, time)
	} }
func (t *SimpleTimeZone) GetOffset_BaseCalendar_BaseCalendar_Date_I_J__I(cal BaseCalendar_I, cdate BaseCalendar_Date_I, year int32, time int64) int32 {

	var cache *SimpleTimeZone_Cache = t.F_cache.Load()
	if !(cache == nil) {
		var tmp1 bool; var tmp2 bool; tmp2 = time >= cache.F_start; if tmp2 { tmp2 = time < cache.F_end }; tmp1 = tmp2; if tmp1 {
			return t.F_rawOffset + t.F_dstSavings }
		if int64(year) == cache.F_year { return t.F_rawOffset } }
	var start int64 = t.GetStart_BaseCalendar_BaseCalendar_Date_I__J(cal, cdate, year); var end int64 = t.GetEnd_BaseCalendar_BaseCalendar_Date_I__J(cal, cdate, year); var offset int32 = t.F_rawOffset


	if start <= end {

		var tmp3 bool; var tmp4 bool; tmp4 = time >= start; if tmp4 { tmp4 = time < end }; tmp3 = tmp4; if tmp3 {
			offset = offset + t.F_dstSavings }
		t.F_cache.Store(SimpleTimeZone_Cache_New_J_J_J(int64(year), start, end)) } else {

			if time < end {

				start = t.GetStart_BaseCalendar_BaseCalendar_Date_I__J(cal, cdate, year-1)
				if time >= start { offset = offset + t.F_dstSavings } } else {
					if time >= start {
						end = t.GetEnd_BaseCalendar_BaseCalendar_Date_I__J(cal, cdate, year+1)
						if time < end { offset = offset + t.F_dstSavings } } }
			if start <= end {
				t.F_cache.Store(SimpleTimeZone_Cache_New_J_J_J(int64(t.F_startYear)-1, start, end)) } }
//line :186:1
	return offset
}


















func (t *SimpleTimeZone) GetStart_BaseCalendar_BaseCalendar_Date_I__J(cal BaseCalendar_I, cdate BaseCalendar_Date_I, year int32) int64 {
	var time int32 = t.F_startTime
	if t.F_startTimeMode == 2 { } else { time = time - t.F_rawOffset }
	return t.GetTransition_BaseCalendar_BaseCalendar_Date_I_I_I_I_I_I__J(cal, cdate, t.F_startMode, year, t.F_startMonth, t.F_startDay, t.F_startDayOfWeek, time)
}
func (t *SimpleTimeZone) GetEnd_BaseCalendar_BaseCalendar_Date_I__J(cal BaseCalendar_I, cdate BaseCalendar_Date_I, year int32) int64 {
	var time int32 = t.F_endTime
	if t.F_endTimeMode == 2 { } else { time = time - t.F_rawOffset }
	if t.F_endTimeMode == 0 { time = time - t.F_dstSavings }
	return t.GetTransition_BaseCalendar_BaseCalendar_Date_I_I_I_I_I_I__J(cal, cdate, t.F_endMode, year, t.F_endMonth, t.F_endDay, t.F_endDayOfWeek, time)
}
func (t *SimpleTimeZone) GetTransition_BaseCalendar_BaseCalendar_Date_I_I_I_I_I_I__J(cal BaseCalendar_I, cdate BaseCalendar_Date_I, mode, year, month, dayOfMonth, dayOfWeek, timeOfDay int32) int64 {


	cdate.SetNormalizedYear_I__V(year)
	cdate.SetMonth_I__CalendarDate(month + 1)
	switch mode { case 1:
		cdate.SetDayOfMonth_I__CalendarDate(dayOfMonth); case 2:


		cdate.SetDayOfMonth_I__CalendarDate(1)
		if dayOfMonth < 0 { cdate.SetDayOfMonth_I__CalendarDate(cal.GetMonthLength_CalendarDate__I(cdate)) }
		cdate = BaseCalendar_Date_Cast(cal.GetNthDayOfWeek_I_I_CalendarDate__CalendarDate(dayOfMonth, dayOfWeek, cdate)); case 3:


		cdate.SetDayOfMonth_I__CalendarDate(dayOfMonth)
		cdate = BaseCalendar_Date_Cast(cal.GetNthDayOfWeek_I_I_CalendarDate__CalendarDate(1, dayOfWeek, cdate)); case 4:


		cdate.SetDayOfMonth_I__CalendarDate(dayOfMonth)
		cdate = BaseCalendar_Date_Cast(cal.GetNthDayOfWeek_I_I_CalendarDate__CalendarDate(-1, dayOfWeek, cdate)); default:}
	return cal.GetTime_CalendarDate__J(cdate) + int64(timeOfDay)
}
func (t *SimpleTimeZone) GetRawOffset__I() int32 { return t.F_rawOffset }

func (t *SimpleTimeZone) SetRawOffset_I__V(offsetMillis int32) {
	t.F_rawOffset = offsetMillis
}
func (t *SimpleTimeZone) SetDSTSavings_I__V(millisSavedDuringDST int32) {
	if millisSavedDuringDST <= 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2834, StrOfInt(millisSavedDuringDST)))))
	}
	t.F_dstSavings = millisSavedDuringDST
}
func (t *SimpleTimeZone) GetDSTSavings__I() int32 {
	if t.F_useDaylight { return t.F_dstSavings } else { return 0
	} }
func (t *SimpleTimeZone) UseDaylightTime__Z() bool { return t.F_useDaylight }

func (t *SimpleTimeZone) ObservesDaylightTime__Z() bool {
	return t.UseDaylightTime__Z()
}
func (t *SimpleTimeZone) InDaylightTime_Date__Z(date Date_I) bool {
	return !(t.GetOffset_J__I(date.GetTime__J()) == t.F_rawOffset)
}
func (t *SimpleTimeZone) Clone__O() any { return t.TimeZone.Impl_Clone__O(t) }

func (t *SimpleTimeZone) HashCode__I() int32 {
	var hash int32 = 31*NN(t.GetID__String()).HashCode__I() + t.F_rawOffset

	hash = 31*hash + Boolean_HashCode_Z__I(t.F_useDaylight)

	if t.F_useDaylight {
		hash = 31*hash + t.F_startMonth
		hash = 31*hash + t.F_startDay
		hash = 31*hash + t.F_startDayOfWeek
		hash = 31*hash + t.F_startTime
		hash = 31*hash + t.F_endMonth
		hash = 31*hash + t.F_endDay
		hash = 31*hash + t.F_endDayOfWeek
		hash = 31*hash + t.F_endTime }
//line :264:1
	return hash
}













func (t *SimpleTimeZone) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if SimpleTimeZone_InstanceOf(tmp1) { var that *SimpleTimeZone = SimpleTimeZone_Cast(tmp1)
			if NN(t.GetID__String()).Equals_O__Z(NN(that).GetID__String().Ref()) { return t.HasSameRules_TimeZone__Z(Up_SimpleTimeZone_TimeZone(that)) } else { return false } } else {
//line :282:1
				return false
			}
	}
}
func (t *SimpleTimeZone) HasSameRules_TimeZone__Z(other TimeZone_I) bool {
	if any(t) == any(other) { return true } else {

		var tmp1 TimeZone_I = other; if SimpleTimeZone_InstanceOf(tmp1) { var that *SimpleTimeZone = SimpleTimeZone_Cast(tmp1); var tmp2 int32 = t.F_rawOffset
			if tmp2 == that.F_rawOffset {
				var tmp3 bool = t.F_useDaylight; if tmp3 == that.F_useDaylight {
					var tmp4 bool; tmp4 = !t.F_useDaylight; if !tmp4 {
						var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 int32 = t.F_dstSavings








						tmp17 = tmp18 == that.F_dstSavings
//line :301:1
						if tmp17 {

							var tmp19 int32 = t.F_startMode; tmp17 = tmp19 == that.F_startMode }
//line :301:1
						tmp16 = tmp17
//line :300:1
						if tmp16 {



							var tmp20 int32 = t.F_startMonth; tmp16 = tmp20 == that.F_startMonth }
//line :300:1
						tmp15 = tmp16
//line :299:1
						if tmp15 {





							var tmp21 int32 = t.F_startDay; tmp15 = tmp21 == that.F_startDay }
//line :299:1
						tmp14 = tmp15
//line :298:1
						if tmp14 {







							var tmp22 int32 = t.F_startDayOfWeek; tmp14 = tmp22 == that.F_startDayOfWeek }
//line :298:1
						tmp13 = tmp14
//line :297:1
						if tmp13 {









							var tmp23 int32 = t.F_startTime; tmp13 = tmp23 == that.F_startTime }
//line :297:1
						tmp12 = tmp13
//line :296:1
						if tmp12 {











							var tmp24 int32 = t.F_startTimeMode; tmp12 = tmp24 == that.F_startTimeMode }
//line :296:1
						tmp11 = tmp12
//line :295:1
						if tmp11 {













							var tmp25 int32 = t.F_endMode; tmp11 = tmp25 == that.F_endMode }
//line :295:1
						tmp10 = tmp11
//line :294:1
						if tmp10 {















							var tmp26 int32 = t.F_endMonth; tmp10 = tmp26 == that.F_endMonth }
//line :294:1
						tmp9 = tmp10
//line :293:1
						if tmp9 {

















							var tmp27 int32 = t.F_endDay; tmp9 = tmp27 == that.F_endDay }
//line :293:1
						tmp8 = tmp9; if tmp8 {


















							var tmp28 int32 = t.F_endDayOfWeek; tmp8 = tmp28 == that.F_endDayOfWeek }
//line :293:1
						tmp7 = tmp8; if tmp7 {



















							var tmp29 int32 = t.F_endTime; tmp7 = tmp29 == that.F_endTime }
//line :293:1
						tmp6 = tmp7; if tmp6 {




















							var tmp30 int32 = t.F_endTimeMode; tmp6 = tmp30 == that.F_endTimeMode }
//line :293:1
						tmp5 = tmp6; if tmp5 {





















							var tmp31 int32 = t.F_startYear; tmp5 = tmp31 == that.F_startYear }
//line :293:1
						tmp4 = tmp5 }
//line :292:1
					return tmp4








				} else {
//line :291:1
					return false
				}








			} else {
//line :290:1
				return false
			}









		} else {
//line :289:1
			return false
		}
	}
}



























func (t *SimpleTimeZone) ToString__String() *String {
	return Concat(NN(t.GetClass__Class()).GetName__String(), Lit_2837, t.GetID__String(), Lit_2838, StrOfInt(t.F_rawOffset), Lit_2839, StrOfInt(t.F_dstSavings), Lit_2840, StrOfBool(t.F_useDaylight), Lit_2841, StrOfInt(t.F_startYear), Lit_2842, StrOfInt(t.F_startMode), Lit_2843, StrOfInt(t.F_startMonth), Lit_2844, StrOfInt(t.F_startDay), Lit_2845, StrOfInt(t.F_startDayOfWeek), Lit_2846, StrOfInt(t.F_startTime), Lit_2847, StrOfInt(t.F_startTimeMode), Lit_2848, StrOfInt(t.F_endMode), Lit_2849, StrOfInt(t.F_endMonth), Lit_2850, StrOfInt(t.F_endDay), Lit_2851, StrOfInt(t.F_endDayOfWeek), Lit_2852, StrOfInt(t.F_endTime), Lit_2853, StrOfInt(t.F_endTimeMode), Lit_1189)
}

























































































func SimpleTimeZone_Cache_New_J_J_J(p0, p1, p2 int64) *SimpleTimeZone_Cache { t := &SimpleTimeZone_Cache{}; t.Ctor_J_J_J(p0, p1, p2); return t }
//line :412:1
func (t *SimpleTimeZone_Cache) Ctor_J_J_J(year, start, end int64) {
	t.F_year = year
	t.F_start = start
	t.F_end = end
}
























func (t *SimpleTimeZone) InvalidateCache__V() { t.F_cache.Store(nil) }

func (t *SimpleTimeZone) DecodeRules__V() {
	t.DecodeStartRule__V()
	t.DecodeEndRule__V()
}
func (t *SimpleTimeZone) DecodeStartRule__V() {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_startDay == 0); if tmp2 { tmp2 = !(t.F_endDay == 0) }; tmp1 = tmp2; t.F_useDaylight = tmp1
	if t.F_startDay == 0 { } else {
		var tmp3 bool; var tmp4 bool; tmp4 = t.F_startMonth < 0; if !tmp4 { tmp4 = t.F_startMonth > 11 }; tmp3 = tmp4; if tmp3 {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2854, StrOfInt(t.F_startMonth))))) }
		var tmp5 bool; var tmp6 bool; tmp6 = t.F_startTime < 0; if !tmp6 { tmp6 = t.F_startTime > 86400000 }; tmp5 = tmp6; if tmp5 {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2855, StrOfInt(t.F_startTime))))) }
		if t.F_startDayOfWeek == 0 {
			t.F_startMode = 1 } else {

				if t.F_startDayOfWeek > 0 {
					t.F_startMode = 2 } else {

						t.F_startDayOfWeek = -t.F_startDayOfWeek
						if t.F_startDay > 0 {
							t.F_startMode = 3 } else {

								t.F_startDay = -t.F_startDay
								t.F_startMode = 4 } }
				if t.F_startDayOfWeek > 7 {
					panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2856, StrOfInt(t.F_startDayOfWeek)))))
				} }
		if t.F_startMode == 2 {

			var tmp7 bool; var tmp8 bool; tmp8 = t.F_startDay < -5; if !tmp8 { tmp8 = t.F_startDay > 5 }; tmp7 = tmp8; if tmp7 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2857, StrOfInt(t.F_startDay))))) } } else {
//line :469:1
					var tmp9 bool; var tmp10 bool




					tmp10 = t.F_startDay < 1; if !tmp10 { var tmp11 int32 = t.F_startDay; tmp10 = tmp11 > int32(SimpleTimeZone_staticMonthLength.A[t.F_startMonth]) }; tmp9 = tmp10
//line :469:1
					if tmp9 {





						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2858, StrOfInt(t.F_startDay)))))
					} } } }
func (t *SimpleTimeZone) DecodeEndRule__V() {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_startDay == 0); if tmp2 { tmp2 = !(t.F_endDay == 0) }; tmp1 = tmp2; t.F_useDaylight = tmp1
	if t.F_endDay == 0 { } else {
		var tmp3 bool; var tmp4 bool; tmp4 = t.F_endMonth < 0; if !tmp4 { tmp4 = t.F_endMonth > 11 }; tmp3 = tmp4; if tmp3 {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2859, StrOfInt(t.F_endMonth))))) }
		var tmp5 bool; var tmp6 bool; tmp6 = t.F_endTime < 0; if !tmp6 { tmp6 = t.F_endTime > 86400000 }; tmp5 = tmp6; if tmp5 {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2860, StrOfInt(t.F_endTime))))) }
		if t.F_endDayOfWeek == 0 {
			t.F_endMode = 1 } else {

				if t.F_endDayOfWeek > 0 {
					t.F_endMode = 2 } else {

						t.F_endDayOfWeek = -t.F_endDayOfWeek
						if t.F_endDay > 0 {
							t.F_endMode = 3 } else {

								t.F_endDay = -t.F_endDay
								t.F_endMode = 4 } }
				if t.F_endDayOfWeek > 7 {
					panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2861, StrOfInt(t.F_endDayOfWeek))))) } }
		if t.F_endMode == 2 {

			var tmp7 bool; var tmp8 bool; tmp8 = t.F_endDay < -5; if !tmp8 { tmp8 = t.F_endDay > 5 }; tmp7 = tmp8; if tmp7 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2862, StrOfInt(t.F_endDay))))) } } else {
//line :498:1
					var tmp9 bool; var tmp10 bool




					tmp10 = t.F_endDay < 1; if !tmp10 { var tmp11 int32 = t.F_endDay; tmp10 = tmp11 > int32(SimpleTimeZone_staticMonthLength.A[t.F_endMonth]) }; tmp9 = tmp10
//line :498:1
					if tmp9 {





						panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2863, StrOfInt(t.F_endDay)))))
					} } } }
func (t *SimpleTimeZone) MakeRulesCompatible__V() { panic(A2g_NotTranslated("java.util.SimpleTimeZone.makeRulesCompatible()V")) }










































func (t *SimpleTimeZone) PackRules__B1() *ByteArray { panic(A2g_NotTranslated("java.util.SimpleTimeZone.packRules()[B")) }









func (t *SimpleTimeZone) UnpackRules_B1__V(p0 *ByteArray) { panic(A2g_NotTranslated("java.util.SimpleTimeZone.unpackRules([B)V")) }








func (t *SimpleTimeZone) PackTimes__I1() *IntArray { panic(A2g_NotTranslated("java.util.SimpleTimeZone.packTimes()[I")) }


func (t *SimpleTimeZone) UnpackTimes_I1__V(p0 *IntArray) { panic(A2g_NotTranslated("java.util.SimpleTimeZone.unpackTimes([I)V")) }



type SimpleTimeZone struct{ TimeZone; F_startMonth, F_startDay, F_startDayOfWeek, F_startTime, F_startTimeMode, F_endMonth, F_endDay, F_endDayOfWeek, F_endTime, F_endTimeMode, F_startYear, F_rawOffset int32; F_useDaylight bool; F_monthLength *ByteArray; F_startMode, F_endMode, F_dstSavings int32; F_cache atomic.Pointer[SimpleTimeZone_Cache]; F_serialVersionOnStream int32 }

const SimpleTimeZone_millisPerHour int32 = 3600000

const SimpleTimeZone_millisPerDay int32 = 86400000

var SimpleTimeZone_staticMonthLength *ByteArray

var SimpleTimeZone_staticLeapMonthLength *ByteArray

var SimpleTimeZone_gcal *Gregorian

const SimpleTimeZone_DOM_MODE int32 = 1

const SimpleTimeZone_DOW_IN_MONTH_MODE int32 = 2

const SimpleTimeZone_DOW_GE_DOM_MODE int32 = 3

const SimpleTimeZone_DOW_LE_DOM_MODE int32 = 4

const SimpleTimeZone_WALL_TIME int32 = 0

const SimpleTimeZone_STANDARD_TIME int32 = 1

const SimpleTimeZone_UTC_TIME int32 = 2

const SimpleTimeZone_serialVersionUID int64 = -403250971215465050

const SimpleTimeZone_currentSerialVersion int32 = 2

const SimpleTimeZone_MAX_RULE_NUM int32 = 6

var SimpleTimeZone_init ClassInit

func SimpleTimeZone_Init() { if !SimpleTimeZone_init.Done() { SimpleTimeZone_init.Run(SimpleTimeZone_clinit) } }

func SimpleTimeZone_clinit() { TimeZone_Init(); SimpleTimeZone_staticMonthLength = ByteArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31); SimpleTimeZone_staticLeapMonthLength = ByteArrayOf(31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31); SimpleTimeZone_gcal = CalendarSystem_GetGregorianCalendar__Gregorian() }

func (t *SimpleTimeZone) GetDisplayName_Z_I__String(p0 bool, p1 int32) *String { return t.Impl_GetDisplayName_Z_I__String(t, p0, p1) }

func (t *SimpleTimeZone) GetDisplayName_Locale__String(p0 *Locale) *String { return t.Impl_GetDisplayName_Locale__String(t, p0) }

func (t *SimpleTimeZone) SetID_String__V(p0 *String) { t.Impl_SetID_String__V(t, p0) }

func (t *SimpleTimeZone) ToZoneId__ZoneId() ZoneId_I { return t.Impl_ToZoneId__ZoneId(t) }

func (t *SimpleTimeZone) GetDisplayName_Z_I_Locale__String(p0 bool, p1 int32, p2 *Locale) *String { return t.Impl_GetDisplayName_Z_I_Locale__String(t, p0, p1, p2) }

func (t *SimpleTimeZone) GetDisplayName__String() *String { return t.Impl_GetDisplayName__String(t) }

func (t *SimpleTimeZone) GetID__String() *String { return t.Impl_GetID__String(t) }

func (t *SimpleTimeZone) Ref() any { if t == nil { return nil }; return t }

func (t *SimpleTimeZone) GetClass__Class() *Class { return SimpleTimeZone_class }

func (t *SimpleTimeZone) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func SimpleTimeZone_InstanceOf(x any) bool { _, ok := x.(*SimpleTimeZone); return ok }

func SimpleTimeZone_Cast(x any) *SimpleTimeZone { if x == nil { return nil }; v, ok := x.(*SimpleTimeZone); if !ok { panic(ClassCast(x, SimpleTimeZone_class)) }; return v }



type SimpleTimeZone_Cache struct{ Object; F_year, F_start, F_end int64 }

func (t *SimpleTimeZone_Cache) Ref() any { if t == nil { return nil }; return t }

func (t *SimpleTimeZone_Cache) GetClass__Class() *Class { return SimpleTimeZone_Cache_class }

func (t *SimpleTimeZone_Cache) ToString__String() *String { return Object_toString(t) }

func (t *SimpleTimeZone_Cache) Clone__O() any { return A2g_ObjectClone(t) }

func (t *SimpleTimeZone_Cache) CloneShallow() any { panic(CloneNotSupported(t)) }

func SimpleTimeZone_Cache_InstanceOf(x any) bool { _, ok := x.(*SimpleTimeZone_Cache); return ok }

func SimpleTimeZone_Cache_Cast(x any) *SimpleTimeZone_Cache { if x == nil { return nil }; v, ok := x.(*SimpleTimeZone_Cache); if !ok { panic(ClassCast(x, SimpleTimeZone_Cache_class)) }; return v }
