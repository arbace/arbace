//line java_util_Arrays.ae:1
package jrt






















func Arrays_New() *Arrays { Arrays_Init(); t := &Arrays{}; t.Ctor(); return t }
//line :24:1
func (t *Arrays) Ctor() { panic(A2g_NotTranslated("java.util.Arrays.<init>()V")) }

func Arrays_Sort_I1__V(a *IntArray) { Arrays_Init()
	DualPivotQuicksort_Sort_I1_I_I_I__V(a, 0, 0, int32(len(a.A)))
}
func Arrays_Sort_I1_I_I__V(a *IntArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_I1_I_I_I__V(a, 0, fromIndex, toIndex)
}
func Arrays_Sort_J1__V(a *LongArray) { Arrays_Init()
	DualPivotQuicksort_Sort_J1_I_I_I__V(a, 0, 0, int32(len(a.A)))
}
func Arrays_Sort_J1_I_I__V(a *LongArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_J1_I_I_I__V(a, 0, fromIndex, toIndex)
}
func Arrays_Sort_S1__V(a *ShortArray) { Arrays_Init()
	DualPivotQuicksort_Sort_S1_I_I__V(a, 0, int32(len(a.A)))
}
func Arrays_Sort_S1_I_I__V(a *ShortArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_S1_I_I__V(a, fromIndex, toIndex)
}
func Arrays_Sort_C1__V(a *CharArray) { Arrays_Init()
	DualPivotQuicksort_Sort_C1_I_I__V(a, 0, int32(len(a.A)))
}
func Arrays_Sort_C1_I_I__V(a *CharArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_C1_I_I__V(a, fromIndex, toIndex)
}
func Arrays_Sort_B1__V(a *ByteArray) { Arrays_Init()
	DualPivotQuicksort_Sort_B1_I_I__V(a, 0, int32(len(a.A)))
}
func Arrays_Sort_B1_I_I__V(a *ByteArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_B1_I_I__V(a, fromIndex, toIndex)
}
func Arrays_Sort_F1__V(a *FloatArray) { Arrays_Init()
	DualPivotQuicksort_Sort_F1_I_I_I__V(a, 0, 0, int32(len(a.A)))
}
func Arrays_Sort_F1_I_I__V(a *FloatArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_F1_I_I_I__V(a, 0, fromIndex, toIndex)
}
func Arrays_Sort_D1__V(a *DoubleArray) { Arrays_Init()
	DualPivotQuicksort_Sort_D1_I_I_I__V(a, 0, 0, int32(len(a.A)))
}
func Arrays_Sort_D1_I_I__V(a *DoubleArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_D1_I_I_I__V(a, 0, fromIndex, toIndex)
}
func Arrays_ParallelSort_B1__V(a *ByteArray) { Arrays_Init()
	DualPivotQuicksort_Sort_B1_I_I__V(a, 0, int32(len(a.A)))
}
func Arrays_ParallelSort_B1_I_I__V(a *ByteArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_B1_I_I__V(a, fromIndex, toIndex)
}
func Arrays_ParallelSort_C1__V(a *CharArray) { Arrays_Init()
	DualPivotQuicksort_Sort_C1_I_I__V(a, 0, int32(len(a.A)))
}
func Arrays_ParallelSort_C1_I_I__V(a *CharArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_C1_I_I__V(a, fromIndex, toIndex)
}
func Arrays_ParallelSort_S1__V(a *ShortArray) { Arrays_Init()
	DualPivotQuicksort_Sort_S1_I_I__V(a, 0, int32(len(a.A)))
}
func Arrays_ParallelSort_S1_I_I__V(a *ShortArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_S1_I_I__V(a, fromIndex, toIndex)
}
func Arrays_ParallelSort_I1__V(a *IntArray) { Arrays_Init()
	DualPivotQuicksort_Sort_I1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), 0, int32(len(a.A)))
}
func Arrays_ParallelSort_I1_I_I__V(a *IntArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_I1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), fromIndex, toIndex)
}
func Arrays_ParallelSort_J1__V(a *LongArray) { Arrays_Init()
	DualPivotQuicksort_Sort_J1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), 0, int32(len(a.A)))
}
func Arrays_ParallelSort_J1_I_I__V(a *LongArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_J1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), fromIndex, toIndex)
}
func Arrays_ParallelSort_F1__V(a *FloatArray) { Arrays_Init()
	DualPivotQuicksort_Sort_F1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), 0, int32(len(a.A)))
}
func Arrays_ParallelSort_F1_I_I__V(a *FloatArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_F1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), fromIndex, toIndex)
}
func Arrays_ParallelSort_D1__V(a *DoubleArray) { Arrays_Init()
	DualPivotQuicksort_Sort_D1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), 0, int32(len(a.A)))
}
func Arrays_ParallelSort_D1_I_I__V(a *DoubleArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	DualPivotQuicksort_Sort_D1_I_I_I__V(a, ForkJoinPool_GetCommonPoolParallelism__I(), fromIndex, toIndex)
}
func Arrays_RangeCheck_I_I_I__V(arrayLength, fromIndex, toIndex int32) { Arrays_Init()
	if fromIndex > toIndex {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2593, StrOfInt(fromIndex), Lit_2594, StrOfInt(toIndex), Lit_1176))))
	}
	if fromIndex < 0 { panic(Thrown(ArrayIndexOutOfBoundsException_New_I(fromIndex))) }
	if toIndex > arrayLength { panic(Thrown(ArrayIndexOutOfBoundsException_New_I(toIndex)))
	}
}


func (t *Arrays_NaturalOrder) Compare_O_O__I(first, second any) int32 {
	return Comparable_Cast(first).CompareTo_O__I(second)
}




func Arrays_ParallelSort_Comparable1__V(a *RefArray) { Arrays_Init()
	var n int32 = int32(len(a.A)); var p int32 = 0; var g int32 = 0; var tmp1 bool; var tmp2 bool


	tmp2 = n <= 8192; if !tmp2 { var tmp3 int32; p = ForkJoinPool_GetCommonPoolParallelism__I(); tmp3 = p; tmp2 = tmp3 == 1 }; tmp1 = tmp2; if tmp1 {
		var tmp4 *Arrays_NaturalOrder; Arrays_NaturalOrder_Init(); tmp4 = Arrays_NaturalOrder_INSTANCE; TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a, 0, n, Up_Arrays_NaturalOrder_Comparator(tmp4), nil, 0, 0) } else {
			var tmp5 *RefArray = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), n), Comparable_class.ArrayClass()); var tmp6 int32; var tmp7 int32






			g = n / (p << 2); tmp7 = g; if tmp7 <= 8192 { tmp6 = 8192 } else { tmp6 = g }
//line :147:1
			var tmp8 int32 = tmp6; var tmp9 *Arrays_NaturalOrder; Arrays_NaturalOrder_Init(); tmp9 = Arrays_NaturalOrder_INSTANCE; ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(nil, a, tmp5, 0, n, 0, tmp8, Up_Arrays_NaturalOrder_Comparator(tmp9)).Invoke__O()
		}
}










func Arrays_ParallelSort_Comparable1_I_I__V(a *RefArray, fromIndex, toIndex int32) { Arrays_Init()


	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var n int32 = toIndex - fromIndex; var p int32 = 0; var g int32 = 0; var tmp1 bool; var tmp2 bool


	tmp2 = n <= 8192; if !tmp2 { var tmp3 int32; p = ForkJoinPool_GetCommonPoolParallelism__I(); tmp3 = p; tmp2 = tmp3 == 1 }; tmp1 = tmp2; if tmp1 {
		var tmp4 *Arrays_NaturalOrder; Arrays_NaturalOrder_Init(); tmp4 = Arrays_NaturalOrder_INSTANCE; TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a, fromIndex, toIndex, Up_Arrays_NaturalOrder_Comparator(tmp4), nil, 0, 0) } else {
			var tmp5 *RefArray = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), n), Comparable_class.ArrayClass()); var tmp6 int32; var tmp7 int32






			g = n / (p << 2); tmp7 = g; if tmp7 <= 8192 { tmp6 = 8192 } else { tmp6 = g }
//line :169:1
			var tmp8 int32 = tmp6; var tmp9 *Arrays_NaturalOrder; Arrays_NaturalOrder_Init(); tmp9 = Arrays_NaturalOrder_INSTANCE; ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(nil, a, tmp5, fromIndex, n, 0, tmp8, Up_Arrays_NaturalOrder_Comparator(tmp9)).Invoke__O()
		}
}










func Arrays_ParallelSort_O1_Comparator__V(a *RefArray, cmp Comparator) { Arrays_Init()

	if cmp == nil { var tmp1 *Arrays_NaturalOrder; Arrays_NaturalOrder_Init(); tmp1 = Arrays_NaturalOrder_INSTANCE; cmp = Up_Arrays_NaturalOrder_Comparator(tmp1) }
	var n int32 = int32(len(a.A)); var p int32 = 0; var g int32 = 0; var tmp2 bool; var tmp3 bool


	tmp3 = n <= 8192; if !tmp3 { var tmp4 int32; p = ForkJoinPool_GetCommonPoolParallelism__I(); tmp4 = p; tmp3 = tmp4 == 1 }; tmp2 = tmp3; if tmp2 {
		TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a, 0, n, cmp, nil, 0, 0) } else {
			var tmp5 *RefArray = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), n), Object_class.ArrayClass()); var tmp6 int32; var tmp7 int32






			g = n / (p << 2); tmp7 = g; if tmp7 <= 8192 { tmp6 = 8192 } else { tmp6 = g }
//line :190:1
			ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(nil, a, tmp5, 0, n, 0, tmp6, cmp).Invoke__O()
		}
}










func Arrays_ParallelSort_O1_I_I_Comparator__V(a *RefArray, fromIndex, toIndex int32, cmp Comparator) { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	if cmp == nil { var tmp1 *Arrays_NaturalOrder; Arrays_NaturalOrder_Init(); tmp1 = Arrays_NaturalOrder_INSTANCE; cmp = Up_Arrays_NaturalOrder_Comparator(tmp1) }
	var n int32 = toIndex - fromIndex; var p int32 = 0; var g int32 = 0; var tmp2 bool; var tmp3 bool


	tmp3 = n <= 8192; if !tmp3 { var tmp4 int32; p = ForkJoinPool_GetCommonPoolParallelism__I(); tmp4 = p; tmp3 = tmp4 == 1 }; tmp2 = tmp3; if tmp2 {
		TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a, fromIndex, toIndex, cmp, nil, 0, 0) } else {
			var tmp5 *RefArray = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), n), Object_class.ArrayClass()); var tmp6 int32; var tmp7 int32






			g = n / (p << 2); tmp7 = g; if tmp7 <= 8192 { tmp6 = 8192 } else { tmp6 = g }
//line :212:1
			ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(nil, a, tmp5, fromIndex, n, 0, tmp6, cmp).Invoke__O()
		}
}














func Arrays_Sort_O1__V(a *RefArray) { Arrays_Init()
	var tmp1 bool; Arrays_LegacyMergeSort_Init(); tmp1 = Arrays_LegacyMergeSort_userRequested; if tmp1 {
		Arrays_LegacyMergeSort_O1__V(a) } else {
			ComparableTimSort_Sort_O1_I_I_O1_I_I__V(a, 0, int32(len(a.A)), nil, 0, 0)
		} }
func Arrays_LegacyMergeSort_O1__V(a *RefArray) { Arrays_Init()
	var aux *RefArray = NN(a).Copy(); Arrays_MergeSort_O1_O1_I_I_I__V(aux, a, 0, int32(len(a.A)), 0)
}
func Arrays_Sort_O1_I_I__V(a *RefArray, fromIndex, toIndex int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var tmp1 bool; Arrays_LegacyMergeSort_Init(); tmp1 = Arrays_LegacyMergeSort_userRequested; if tmp1 {
		Arrays_LegacyMergeSort_O1_I_I__V(a, fromIndex, toIndex) } else {
			ComparableTimSort_Sort_O1_I_I_O1_I_I__V(a, fromIndex, toIndex, nil, 0, 0)
		} }
func Arrays_LegacyMergeSort_O1_I_I__V(a *RefArray, fromIndex, toIndex int32) { Arrays_Init()
	var aux *RefArray = Arrays_CopyOfRange_O1_I_I__O1(a, fromIndex, toIndex)
	Arrays_MergeSort_O1_O1_I_I_I__V(aux, a, fromIndex, toIndex, -fromIndex)
}


func Arrays_MergeSort_O1_O1_I_I_I__V(src, dest *RefArray, low, high, off int32) { Arrays_Init()

	var length int32 = high - low
	if length < 7 {
		var i int32 = low; L1: for {
			if i < high {
				var j int32 = i; L2: for {
					var tmp1 bool; var tmp2 bool; tmp2 = j > low; if tmp2 {
						var tmp3 Comparable = Comparable_Cast(dest.A[j-1]); tmp2 = tmp3.CompareTo_O__I(dest.A[j]) > 0 }
//line :256:1
					tmp1 = tmp2; if tmp1 {



						Arrays_Swap_O1_I_I__V(dest, j, j-1)
						j = j - 1; continue L2 }
//line :255:1
					break L2
				}





				i = i + 1; continue L1 }
//line :253:1
			break L1
		}






	} else {

		var destLow int32 = low
		var destHigh int32 = high
		low = low + off
		high = high + off
		var mid int32 = int32(uint32(low+high) >> 1)
		Arrays_MergeSort_O1_O1_I_I_I__V(dest, src, low, mid, -off)
		Arrays_MergeSort_O1_O1_I_I_I__V(dest, src, mid, high, -off)
		var tmp4 Comparable = Comparable_Cast(src.A[mid-1]); if tmp4.CompareTo_O__I(src.A[mid]) <= 0 {


			System_Arraycopy_O_I_O_I_I__V(src.Ref(), low, dest.Ref(), destLow, length) } else {
				var i_2 int32 = destLow
				var p int32 = low
				var q int32 = mid
			L3: for { if i_2 < destHigh {
				var tmp5 bool; var tmp6 bool; tmp6 = q >= high; if !tmp6 {
					var tmp7 bool; tmp7 = p < mid; if tmp7 {
						var tmp8 Comparable = Comparable_Cast(src.A[p]); tmp7 = tmp8.CompareTo_O__I(src.A[q]) <= 0 }
//line :279:1
					tmp6 = tmp7 }
//line :278:1
				tmp5 = tmp6; if tmp5 {


					dest.Store(i_2, src.A[p]); p = p + 1 } else {
						dest.Store(i_2, src.A[q]); q = q + 1 }
				i_2 = i_2 + 1
//line :277:1
				continue L3 }; break L3
			}
			}
	}
}



func Arrays_Swap_O1_I_I__V(x *RefArray, a, b int32) { Arrays_Init()
	var t_ any = x.A[a]; x.Store(a, x.A[b]); x.Store(b, t_)
}
func Arrays_Sort_O1_Comparator__V(a *RefArray, c Comparator) { Arrays_Init()
	if c == nil {
		Arrays_Sort_O1__V(a) } else {
//line :289:1
			var tmp1 bool; Arrays_LegacyMergeSort_Init(); tmp1 = Arrays_LegacyMergeSort_userRequested; if tmp1 {

				Arrays_LegacyMergeSort_O1_Comparator__V(a, c) } else {
					TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a, 0, int32(len(a.A)), c, nil, 0, 0)
				} } }
func Arrays_LegacyMergeSort_O1_Comparator__V(a *RefArray, c Comparator) { Arrays_Init()

	var aux *RefArray = NN(a).Copy()
	if c == nil {
		Arrays_MergeSort_O1_O1_I_I_I__V(aux, a, 0, int32(len(a.A)), 0) } else {
			Arrays_MergeSort_O1_O1_I_I_I_Comparator__V(aux, a, 0, int32(len(a.A)), 0, c)
		} }
func Arrays_Sort_O1_I_I_Comparator__V(a *RefArray, fromIndex, toIndex int32, c Comparator) { Arrays_Init()

	if c == nil {
		Arrays_Sort_O1_I_I__V(a, fromIndex, toIndex) } else {

			Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
			var tmp1 bool; Arrays_LegacyMergeSort_Init(); tmp1 = Arrays_LegacyMergeSort_userRequested; if tmp1 {
				Arrays_LegacyMergeSort_O1_I_I_Comparator__V(a, fromIndex, toIndex, c) } else {
					TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a, fromIndex, toIndex, c, nil, 0, 0)
				} } }
func Arrays_LegacyMergeSort_O1_I_I_Comparator__V(a *RefArray, fromIndex, toIndex int32, c Comparator) { Arrays_Init()


	var aux *RefArray = Arrays_CopyOfRange_O1_I_I__O1(a, fromIndex, toIndex)
	if c == nil {
		Arrays_MergeSort_O1_O1_I_I_I__V(aux, a, fromIndex, toIndex, -fromIndex) } else {
			Arrays_MergeSort_O1_O1_I_I_I_Comparator__V(aux, a, fromIndex, toIndex, -fromIndex, c)
		} }
func Arrays_MergeSort_O1_O1_I_I_I_Comparator__V(src, dest *RefArray, low, high, off int32, c Comparator) { Arrays_Init()

	var length int32 = high - low
	if length < 7 {
		var i int32 = low; L1: for {
			if i < high {
				var j int32 = i; L2: for {
					var tmp1 bool; var tmp2 bool
					tmp2 = j > low
//line :326:1
					if tmp2 {

						var tmp3 any = dest.A[j-1]; tmp2 = c.Compare_O_O__I(tmp3, dest.A[j]) > 0 }
//line :326:1
					tmp1 = tmp2; if tmp1 {


						Arrays_Swap_O1_I_I__V(dest, j, j-1)
						j = j - 1; continue L2 }
//line :325:1
					break L2
				}




				i = i + 1; continue L1 }
//line :323:1
			break L1
		}





	} else {

		var destLow int32 = low
		var destHigh int32 = high
		low = low + off
		high = high + off
		var mid int32 = int32(uint32(low+high) >> 1)
		Arrays_MergeSort_O1_O1_I_I_I_Comparator__V(dest, src, low, mid, -off, c)
		Arrays_MergeSort_O1_O1_I_I_I_Comparator__V(dest, src, mid, high, -off, c)
		var tmp4 any = src.A[mid-1]; if c.Compare_O_O__I(tmp4, src.A[mid]) <= 0 {
			System_Arraycopy_O_I_O_I_I__V(src.Ref(), low, dest.Ref(), destLow, length) } else {
				var i_2 int32 = destLow
				var p int32 = low
				var q int32 = mid
			L3: for { if i_2 < destHigh {
				var tmp5 bool; var tmp6 bool; tmp6 = q >= high; if !tmp6 {
					var tmp7 bool; tmp7 = p < mid; if tmp7 { var tmp8 any = src.A[p]; tmp7 = c.Compare_O_O__I(tmp8, src.A[q]) <= 0 }; tmp6 = tmp7 }
//line :345:1
				tmp5 = tmp6; if tmp5 {

					dest.Store(i_2, src.A[p]); p = p + 1 } else {
						dest.Store(i_2, src.A[q]); q = q + 1 }
				i_2 = i_2 + 1
//line :344:1
				continue L3 }; break L3
			}
			}
	}
}


func Arrays_ParallelPrefix_O1_BinaryOperator__V(array *RefArray, op BinaryOperator) { Arrays_Init()

	Objects_RequireNonNull_O__O(op)
	if int32(len(array.A)) > 0 {
		ArrayPrefixHelpers_CumulateTask_New_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I(nil, op, array, 0, int32(len(array.A))).Invoke__O()
	} }
func Arrays_ParallelPrefix_O1_I_I_BinaryOperator__V(array *RefArray, fromIndex, toIndex int32, op BinaryOperator) { Arrays_Init()


	Objects_RequireNonNull_O__O(op)
	Arrays_RangeCheck_I_I_I__V(int32(len(array.A)), fromIndex, toIndex)
	if fromIndex < toIndex {
		ArrayPrefixHelpers_CumulateTask_New_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I(nil, op, array, fromIndex, toIndex).Invoke__O()
	} }
func Arrays_ParallelPrefix_J1_LongBinaryOperator__V(array *LongArray, op LongBinaryOperator) { Arrays_Init()
	Objects_RequireNonNull_O__O(op)
	if int32(len(array.A)) > 0 {
		ArrayPrefixHelpers_LongCumulateTask_New_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I(nil, op, array, 0, int32(len(array.A))).Invoke__O()
	} }
func Arrays_ParallelPrefix_J1_I_I_LongBinaryOperator__V(array *LongArray, fromIndex, toIndex int32, op LongBinaryOperator) { Arrays_Init()

	Objects_RequireNonNull_O__O(op)
	Arrays_RangeCheck_I_I_I__V(int32(len(array.A)), fromIndex, toIndex)
	if fromIndex < toIndex {
		ArrayPrefixHelpers_LongCumulateTask_New_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I(nil, op, array, fromIndex, toIndex).Invoke__O()
	} }
func Arrays_ParallelPrefix_D1_DoubleBinaryOperator__V(array *DoubleArray, op DoubleBinaryOperator) { Arrays_Init()
	Objects_RequireNonNull_O__O(op)
	if int32(len(array.A)) > 0 {
		ArrayPrefixHelpers_DoubleCumulateTask_New_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I(nil, op, array, 0, int32(len(array.A))).Invoke__O()
	} }
func Arrays_ParallelPrefix_D1_I_I_DoubleBinaryOperator__V(array *DoubleArray, fromIndex, toIndex int32, op DoubleBinaryOperator) { Arrays_Init()

	Objects_RequireNonNull_O__O(op)
	Arrays_RangeCheck_I_I_I__V(int32(len(array.A)), fromIndex, toIndex)
	if fromIndex < toIndex {
		ArrayPrefixHelpers_DoubleCumulateTask_New_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I(nil, op, array, fromIndex, toIndex).Invoke__O()
	} }
func Arrays_ParallelPrefix_I1_IntBinaryOperator__V(array *IntArray, op IntBinaryOperator) { Arrays_Init()
	Objects_RequireNonNull_O__O(op)
	if int32(len(array.A)) > 0 {
		ArrayPrefixHelpers_IntCumulateTask_New_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I(nil, op, array, 0, int32(len(array.A))).Invoke__O()
	} }
func Arrays_ParallelPrefix_I1_I_I_IntBinaryOperator__V(array *IntArray, fromIndex, toIndex int32, op IntBinaryOperator) { Arrays_Init()

	Objects_RequireNonNull_O__O(op)
	Arrays_RangeCheck_I_I_I__V(int32(len(array.A)), fromIndex, toIndex)
	if fromIndex < toIndex {
		ArrayPrefixHelpers_IntCumulateTask_New_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I(nil, op, array, fromIndex, toIndex).Invoke__O()
	} }
func Arrays_BinarySearch_J1_J__I(a *LongArray, key int64) int32 { Arrays_Init()
	return Arrays_BinarySearch0_J1_I_I_J__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_J1_I_I_J__I(a *LongArray, fromIndex, toIndex int32, key int64) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_J1_I_I_J__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_J1_I_I_J__I(a *LongArray, fromIndex, toIndex int32, key int64) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal int64 = a.A[mid]

	if midVal < key {
		low = mid + 1 } else {
//line :414:1
			if midVal > key {

				high = mid - 1 } else {
					return mid } }
//line :411:1
	continue L1 }; break L1
}





	return -(low + 1)
}
func Arrays_BinarySearch_I1_I__I(a *IntArray, key int32) int32 { Arrays_Init()
	return Arrays_BinarySearch0_I1_I_I_I__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_I1_I_I_I__I(a *IntArray, fromIndex, toIndex, key int32) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_I1_I_I_I__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_I1_I_I_I__I(a *IntArray, fromIndex, toIndex, key int32) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal int32 = a.A[mid]

	if midVal < key {
		low = mid + 1 } else {
//line :433:1
			if midVal > key {

				high = mid - 1 } else {
					return mid } }
//line :430:1
	continue L1 }; break L1
}





	return -(low + 1)
}
func Arrays_BinarySearch_S1_S__I(a *ShortArray, key int16) int32 { Arrays_Init()
	return Arrays_BinarySearch0_S1_I_I_S__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_S1_I_I_S__I(a *ShortArray, fromIndex, toIndex int32, key int16) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_S1_I_I_S__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_S1_I_I_S__I(a *ShortArray, fromIndex, toIndex int32, key int16) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal int16 = a.A[mid]

	if int32(midVal) < int32(key) {
		low = mid + 1 } else {
//line :452:1
			if int32(midVal) > int32(key) {

				high = mid - 1 } else {
					return mid } }
//line :449:1
	continue L1 }; break L1
}





	return -(low + 1)
}
func Arrays_BinarySearch_C1_C__I(a *CharArray, key uint16) int32 { Arrays_Init()
	return Arrays_BinarySearch0_C1_I_I_C__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_C1_I_I_C__I(a *CharArray, fromIndex, toIndex int32, key uint16) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_C1_I_I_C__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_C1_I_I_C__I(a *CharArray, fromIndex, toIndex int32, key uint16) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal uint16 = a.A[mid]

	if int32(midVal) < int32(key) {
		low = mid + 1 } else {
//line :471:1
			if int32(midVal) > int32(key) {

				high = mid - 1 } else {
					return mid } }
//line :468:1
	continue L1 }; break L1
}





	return -(low + 1)
}
func Arrays_BinarySearch_B1_B__I(a *ByteArray, key int8) int32 { Arrays_Init()
	return Arrays_BinarySearch0_B1_I_I_B__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_B1_I_I_B__I(a *ByteArray, fromIndex, toIndex int32, key int8) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_B1_I_I_B__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_B1_I_I_B__I(a *ByteArray, fromIndex, toIndex int32, key int8) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal int8 = a.A[mid]

	if int32(midVal) < int32(key) {
		low = mid + 1 } else {
//line :490:1
			if int32(midVal) > int32(key) {

				high = mid - 1 } else {
					return mid } }
//line :487:1
	continue L1 }; break L1
}





	return -(low + 1)
}
func Arrays_BinarySearch_D1_D__I(a *DoubleArray, key float64) int32 { Arrays_Init()
	return Arrays_BinarySearch0_D1_I_I_D__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_D1_I_I_D__I(a *DoubleArray, fromIndex, toIndex int32, key float64) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_D1_I_I_D__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_D1_I_I_D__I(a *DoubleArray, fromIndex, toIndex int32, key float64) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal float64 = a.A[mid]

	if midVal < key {
		low = mid + 1 } else {
//line :509:1
			if midVal > key {

				high = mid - 1 } else {

					var midBits int64 = Double_DoubleToLongBits_D__J(midVal); var keyBits int64 = Double_DoubleToLongBits_D__J(key)

					if midBits == keyBits {
						return mid } else {
//line :515:1
							if midBits < keyBits {

								low = mid + 1 } else {
									high = mid - 1 } } } }
//line :506:1
	continue L1 }; break L1
}











	return -(low + 1)
}
func Arrays_BinarySearch_F1_F__I(a *FloatArray, key float32) int32 { Arrays_Init()
	return Arrays_BinarySearch0_F1_I_I_F__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_F1_I_I_F__I(a *FloatArray, fromIndex, toIndex int32, key float32) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_F1_I_I_F__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_F1_I_I_F__I(a *FloatArray, fromIndex, toIndex int32, key float32) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal float32 = a.A[mid]

	if midVal < key {
		low = mid + 1 } else {
//line :534:1
			if midVal > key {

				high = mid - 1 } else {

					var midBits int32 = Float_FloatToIntBits_F__I(midVal); var keyBits int32 = Float_FloatToIntBits_F__I(key)

					if midBits == keyBits {
						return mid } else {
//line :540:1
							if midBits < keyBits {

								low = mid + 1 } else {
									high = mid - 1 } } } }
//line :531:1
	continue L1 }; break L1
}











	return -(low + 1)
}
func Arrays_BinarySearch_O1_O__I(a *RefArray, key any) int32 { Arrays_Init()
	return Arrays_BinarySearch0_O1_I_I_O__I(a, 0, int32(len(a.A)), key)
}
func Arrays_BinarySearch_O1_I_I_O__I(a *RefArray, fromIndex, toIndex int32, key any) int32 { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_O1_I_I_O__I(a, fromIndex, toIndex, key)
}
func Arrays_BinarySearch0_O1_I_I_O__I(a *RefArray, fromIndex, toIndex int32, key any) int32 { Arrays_Init()
	var low int32 = fromIndex; var high int32 = toIndex - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal Comparable = Comparable_Cast(a.A[mid]); var cmp int32 = midVal.CompareTo_O__I(key)


	if cmp < 0 {
		low = mid + 1 } else {
//line :560:1
			if cmp > 0 {

				high = mid - 1 } else {
					return mid } }
//line :556:1
	continue L1 }; break L1
}






	return -(low + 1)
}
func Arrays_BinarySearch_O1_O_Comparator__I(a *RefArray, key any, c Comparator) int32 { Arrays_Init()

	return Arrays_BinarySearch0_O1_I_I_O_Comparator__I(a, 0, int32(len(a.A)), key, c)
}
func Arrays_BinarySearch_O1_I_I_O_Comparator__I(a *RefArray, fromIndex, toIndex int32, key any, c Comparator) int32 { Arrays_Init()


	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	return Arrays_BinarySearch0_O1_I_I_O_Comparator__I(a, fromIndex, toIndex, key, c)
}
func Arrays_BinarySearch0_O1_I_I_O_Comparator__I(a *RefArray, fromIndex, toIndex int32, key any, c Comparator) int32 { Arrays_Init()


	if c == nil {
		return Arrays_BinarySearch0_O1_I_I_O__I(a, fromIndex, toIndex, key) } else {
			var low int32 = fromIndex; var high int32 = toIndex - 1

		L1: for { if low <= high {
			var mid int32 = int32(uint32(low+high) >> 1); var midVal any = a.A[mid]; var cmp int32 = c.Compare_O_O__I(midVal, key)


			if cmp < 0 {
				low = mid + 1 } else {
//line :587:1
					if cmp > 0 {

						high = mid - 1 } else {
							return mid } }
//line :583:1
			continue L1 }; break L1
		}






			return -(low + 1)
		} }
func Arrays_Equals_J1_J1__Z(a, a2 *LongArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :594:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_J1_J1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_J1_I_I_J1_I_I__Z(a *LongArray, aFromIndex, aToIndex int32, b *LongArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_J1_I_J1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_I1_I1__Z(a, a2 *IntArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :612:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_I1_I1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_I1_I_I_I1_I_I__Z(a *IntArray, aFromIndex, aToIndex int32, b *IntArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_I1_I_I1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_S1_S1__Z(a, a2 *ShortArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :630:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_S1_S1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_S1_I_I_S1_I_I__Z(a *ShortArray, aFromIndex, aToIndex int32, b *ShortArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_S1_I_S1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_C1_C1__Z(a, a2 *CharArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :648:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_C1_C1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_C1_I_I_C1_I_I__Z(a *CharArray, aFromIndex, aToIndex int32, b *CharArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_C1_I_C1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_B1_B1__Z(a, a2 *ByteArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :666:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_B1_B1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_B1_I_I_B1_I_I__Z(a *ByteArray, aFromIndex, aToIndex int32, b *ByteArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_B1_I_B1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_Z1_Z1__Z(a, a2 *BooleanArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :684:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_Z1_Z1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_Z1_I_I_Z1_I_I__Z(a *BooleanArray, aFromIndex, aToIndex int32, b *BooleanArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_Z1_I_Z1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_D1_D1__Z(a, a2 *DoubleArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :702:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_D1_D1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_D1_I_I_D1_I_I__Z(a *DoubleArray, aFromIndex, aToIndex int32, b *DoubleArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_D1_I_D1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_F1_F1__Z(a, a2 *FloatArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :720:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else { return ArraysSupport_Mismatch_F1_F1_I__I(a, a2, length) < 0
			} } } }
func Arrays_Equals_F1_I_I_F1_I_I__Z(a *FloatArray, aFromIndex, aToIndex int32, b *FloatArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {

		return ArraysSupport_Mismatch_F1_I_F1_I_I__I(a, aFromIndex, b, bFromIndex, aLength) < 0
	} }
func Arrays_Equals_O1_O1__Z(a, a2 *RefArray) bool { Arrays_Init()
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :738:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else {


				var i int32 = 0; L1: for {
					if i < length {
						var tmp3 any = a.A[i]; if !Objects_Equals_O_O__Z(tmp3, a2.A[i]) {
							return false } else {
								i = i + 1; continue L1 } }
//line :746:1
					break L1 }
//line :745:1
				return true
			}
		}
	}
}




func Arrays_Equals_O1_I_I_O1_I_I__Z(a *RefArray, aFromIndex, aToIndex int32, b *RefArray, bFromIndex, bToIndex int32) bool { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {


		var i int32 = 0; L1: for {
			if i < aLength {
				var tmp1 int32
				var old_1 int32 = aFromIndex

				aFromIndex = aFromIndex + 1
//line :767:1
				tmp1 = old_1
//line :765:1
				var tmp2 any = a.A[tmp1]; var tmp3 int32
				var old_2 int32 = bFromIndex





				bFromIndex = bFromIndex + 1
//line :771:1
				tmp3 = old_2
//line :765:1
				if !Objects_Equals_O_O__Z(tmp2, b.A[tmp3]) {








					return false } else {
						i = i + 1; continue L1 } }
//line :763:1
			break L1 }
//line :762:1
		return true
	}
}














func Arrays_Equals_O1_O1_Comparator__Z(a, a2 *RefArray, cmp Comparator) bool { Arrays_Init()

	Objects_RequireNonNull_O__O(cmp)
	if a == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :782:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a.A))
			if !(int32(len(a2.A)) == length) { return false } else {


				var i int32 = 0; L1: for {
					if i < length {
						var tmp3 any = a.A[i]; if !(cmp.Compare_O_O__I(tmp3, a2.A[i]) == 0) {
							return false } else {
								i = i + 1; continue L1 } }
//line :790:1
					break L1 }
//line :789:1
				return true
			}
		}
	}
}




func Arrays_Equals_O1_I_I_O1_I_I_Comparator__Z(a *RefArray, aFromIndex, aToIndex int32, b *RefArray, bFromIndex, bToIndex int32, cmp Comparator) bool { Arrays_Init()




	Objects_RequireNonNull_O__O(cmp)
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex

	if !(aLength == bLength) { return false } else {


		var i int32 = 0; L1: for {
			if i < aLength {
				var tmp1 int32
				var old_3 int32 = aFromIndex

				aFromIndex = aFromIndex + 1
//line :815:1
				tmp1 = old_3
//line :813:1
				var tmp2 any = a.A[tmp1]; var tmp3 int32
				var old_4 int32 = bFromIndex





				bFromIndex = bFromIndex + 1
//line :819:1
				tmp3 = old_4
//line :813:1
				if !(cmp.Compare_O_O__I(tmp2, b.A[tmp3]) == 0) {









					return false } else {
						i = i + 1; continue L1 } }
//line :811:1
			break L1 }
//line :810:1
		return true
	}
}















func Arrays_Fill_J1_J__V(a *LongArray, val int64) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :829:1
		break L1
	}
}

func Arrays_Fill_J1_I_I_J__V(a *LongArray, fromIndex, toIndex int32, val int64) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_I1_I__V(a *IntArray, val int32) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :838:1
		break L1
	}
}

func Arrays_Fill_I1_I_I_I__V(a *IntArray, fromIndex, toIndex, val int32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_S1_S__V(a *ShortArray, val int16) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :847:1
		break L1
	}
}

func Arrays_Fill_S1_I_I_S__V(a *ShortArray, fromIndex, toIndex int32, val int16) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_C1_C__V(a *CharArray, val uint16) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :856:1
		break L1
	}
}

func Arrays_Fill_C1_I_I_C__V(a *CharArray, fromIndex, toIndex int32, val uint16) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_B1_B__V(a *ByteArray, val int8) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :865:1
		break L1
	}
}

func Arrays_Fill_B1_I_I_B__V(a *ByteArray, fromIndex, toIndex int32, val int8) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_Z1_Z__V(a *BooleanArray, val bool) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :874:1
		break L1
	}
}

func Arrays_Fill_Z1_I_I_Z__V(a *BooleanArray, fromIndex, toIndex int32, val bool) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_D1_D__V(a *DoubleArray, val float64) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :883:1
		break L1
	}
}

func Arrays_Fill_D1_I_I_D__V(a *DoubleArray, fromIndex, toIndex int32, val float64) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_F1_F__V(a *FloatArray, val float32) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.A[i] = val; i, len_ = i+1, len_; continue L1 }
//line :892:1
		break L1
	}
}

func Arrays_Fill_F1_I_I_F__V(a *FloatArray, fromIndex, toIndex int32, val float32) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.A[i] = val; i = i + 1; continue L1 }; break L1
	} }
func Arrays_Fill_O1_O__V(a *RefArray, val any) { Arrays_Init()
	var i int32 = 0; var len_ int32 = int32(len(a.A)); L1: for {

		if i < len_ { a.Store(i, val); i, len_ = i+1, len_; continue L1 }
//line :901:1
		break L1
	}
}

func Arrays_Fill_O1_I_I_O__V(a *RefArray, fromIndex, toIndex int32, val any) { Arrays_Init()
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), fromIndex, toIndex)
	var i int32 = fromIndex; L1: for { if i < toIndex { a.Store(i, val); i = i + 1; continue L1 }; break L1
	} }
func Arrays_CopyOf_O1_I__O1(original *RefArray, newLength int32) *RefArray { Arrays_Init()
	return Arrays_CopyOf_O1_I_Class__O1(original, newLength, GetClass(original.Ref()))
}
func Arrays_CopyOf_O1_I_Class__O1(original *RefArray, newLength int32, newType *Class) *RefArray { Arrays_Init()


	var copy_ *RefArray; if newType == Object_class.ArrayClass() {
		copy_ = NewRefArray(Object_class, newLength) } else {
			copy_ = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(newType).GetComponentType__Class(), newLength), Object_class.ArrayClass()) }
	System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :915:1
	return copy_
}




func Arrays_CopyOf_B1_I__B1(original *ByteArray, newLength int32) *ByteArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *ByteArray = NewByteArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :924:1
			return copy_
		}
}

func Arrays_CopyOf_S1_I__S1(original *ShortArray, newLength int32) *ShortArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *ShortArray = NewShortArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :931:1
			return copy_
		}
}

func Arrays_CopyOf_I1_I__I1(original *IntArray, newLength int32) *IntArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *IntArray = NewIntArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :938:1
			return copy_
		}
}

func Arrays_CopyOf_J1_I__J1(original *LongArray, newLength int32) *LongArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *LongArray = NewLongArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :945:1
			return copy_
		}
}

func Arrays_CopyOf_C1_I__C1(original *CharArray, newLength int32) *CharArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *CharArray = NewCharArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :952:1
			return copy_
		}
}

func Arrays_CopyOf_F1_I__F1(original *FloatArray, newLength int32) *FloatArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *FloatArray = NewFloatArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :959:1
			return copy_
		}
}

func Arrays_CopyOf_D1_I__D1(original *DoubleArray, newLength int32) *DoubleArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *DoubleArray = NewDoubleArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :966:1
			return copy_
		}
}

func Arrays_CopyOf_Z1_I__Z1(original *BooleanArray, newLength int32) *BooleanArray { Arrays_Init()
	if newLength == int32(len(original.A)) {
		return NN(original).Copy() } else {
			var copy_ *BooleanArray = NewBooleanArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), 0, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A)), newLength))
//line :973:1
			return copy_
		}
}

func Arrays_CopyOfRange_O1_I_I__O1(original *RefArray, from, to int32) *RefArray { Arrays_Init()
	return Arrays_CopyOfRange_O1_I_I_Class__O1(original, from, to, GetClass(original.Ref()))
}
func Arrays_CopyOfRange_O1_I_I_Class__O1(original *RefArray, from, to int32, newType *Class) *RefArray { Arrays_Init()



	var newLength int32 = to - from
	if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
	var copy_ *RefArray; if newType == Object_class.ArrayClass() {
		copy_ = NewRefArray(Object_class, newLength) } else {
			copy_ = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(newType).GetComponentType__Class(), newLength), Object_class.ArrayClass()) }
	System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :986:1
	return copy_
}








func Arrays_CopyOfRange_B1_I_I__B1(original *ByteArray, from, to int32) *ByteArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *ByteArray = NewByteArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1001:1
			return copy_
		}
}





func Arrays_CopyOfRange_S1_I_I__S1(original *ShortArray, from, to int32) *ShortArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *ShortArray = NewShortArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1014:1
			return copy_
		}
}





func Arrays_CopyOfRange_I1_I_I__I1(original *IntArray, from, to int32) *IntArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *IntArray = NewIntArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1027:1
			return copy_
		}
}





func Arrays_CopyOfRange_J1_I_I__J1(original *LongArray, from, to int32) *LongArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *LongArray = NewLongArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1040:1
			return copy_
		}
}





func Arrays_CopyOfRange_C1_I_I__C1(original *CharArray, from, to int32) *CharArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *CharArray = NewCharArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1053:1
			return copy_
		}
}





func Arrays_CopyOfRange_F1_I_I__F1(original *FloatArray, from, to int32) *FloatArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *FloatArray = NewFloatArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1066:1
			return copy_
		}
}





func Arrays_CopyOfRange_D1_I_I__D1(original *DoubleArray, from, to int32) *DoubleArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *DoubleArray = NewDoubleArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1079:1
			return copy_
		}
}





func Arrays_CopyOfRange_Z1_I_I__Z1(original *BooleanArray, from, to int32) *BooleanArray { Arrays_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = from == 0; if tmp2 { tmp2 = to == int32(len(original.A)) }; tmp1 = tmp2; if tmp1 {
		return NN(original).Copy() } else {
			var newLength int32 = to - from
			if newLength < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(from), Lit_1260, StrOfInt(to))))) }
			var copy_ *BooleanArray = NewBooleanArray(newLength)
			System_Arraycopy_O_I_O_I_I__V(original.Ref(), from, copy_.Ref(), 0, Math_Min_I_I__I(int32(len(original.A))-from, newLength))
//line :1092:1
			return copy_
		}
}





func Arrays_AsList_O1__List(a *RefArray) List { Arrays_Init()
	return Arrays_ArrayList_New_O1(a)
}









func Arrays_ArrayList_New_O1(p0 *RefArray) *Arrays_ArrayList { t := &Arrays_ArrayList{}; t.Ctor_O1(p0); return t }
//line :1112:1
func (t *Arrays_ArrayList) Ctor_O1(array *RefArray) { t.AbstractList.Ctor(t)
	t.F_a = A2g_CastArray[*RefArray](Objects_RequireNonNull_O__O(array.Ref()), Object_class.ArrayClass())
}
func (t *Arrays_ArrayList) Size__I() int32 { return int32(len(t.F_a.A)) }

func (t *Arrays_ArrayList) ToArray__O1() *RefArray {
	var tmp1 *RefArray = t.F_a; return Arrays_CopyOf_O1_I_Class__O1(tmp1, int32(len(t.F_a.A)), Object_class.ArrayClass())
}
func (t *Arrays_ArrayList) ToArray_O1__O1(a *RefArray) *RefArray {
	var size int32 = t.Size__I()
	if int32(len(a.A)) < size {
		var tmp1 *RefArray = t.F_a; return Arrays_CopyOf_O1_I_Class__O1(tmp1, size, GetClass(a.Ref())) } else {

			System_Arraycopy_O_I_O_I_I__V(t.F_a.Ref(), 0, a.Ref(), 0, size)
			if int32(len(a.A)) > size { a.Store(size, nil) }
//line :1124:1
			return a
		}
}


func (t *Arrays_ArrayList) Get_I__O(index int32) any { return t.F_a.A[index] }

func (t *Arrays_ArrayList) Set_I_O__O(index int32, element any) any {
	var oldValue any = t.F_a.A[index]; t.F_a.Store(index, element); return oldValue
}
func (t *Arrays_ArrayList) IndexOf_O__I(o any) int32 {
	var a *RefArray = t.F_a
	if o == nil {
		var i int32 = 0; L1: for {
			if i < int32(len(a.A)) {
				if a.A[i] == nil { return i } else { i = i + 1; continue L1 } }
//line :1137:1
			break L1
		} } else {


			var i_2 int32 = 0; L2: for {
				if i_2 < int32(len(a.A)) {
					if Equals(o, a.A[i_2]) { return i_2 } else { i_2 = i_2 + 1; continue L2 } }
//line :1141:1
				break L2 } }
//line :1135:1
	return -1
}










func (t *Arrays_ArrayList) Contains_O__Z(o any) bool { return t.IndexOf_O__I(o) >= 0 }

func (t *Arrays_ArrayList) Spliterator__Spliterator() Spliterator {
	return Spliterators_Spliterator_O1_I__Spliterator(t.F_a, 16)
}
func (t *Arrays_ArrayList) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var arr_101733 *RefArray = t.F_a; var len_101734 int32 = int32(len(arr_101733.A)); var i_101735 int32 = 0; for ; i_101735 < len_101734; i_101735++ { var e any = arr_101733.A[i_101735]; action.Accept_O__V(e)
	} }
func (t *Arrays_ArrayList) ReplaceAll_UnaryOperator__V(operator UnaryOperator) {
	Objects_RequireNonNull_O__O(operator)
	var a *RefArray = t.F_a; var i int32 = 0
L1: for {
	if i < int32(len(a.A)) {
		a.Store(i, operator.Apply_O__O(a.A[i]))
		i = i + 1; continue L1 }
//line :1159:1
	break L1
}
}


func (t *Arrays_ArrayList) Sort_Comparator__V(c Comparator) {
	Arrays_Sort_O1_Comparator__V(t.F_a, c)
}
func (t *Arrays_ArrayList) Iterator__Iterator() Iterator { return Arrays_ArrayItr_New_O1(t.F_a) }









func Arrays_ArrayItr_New_O1(p0 *RefArray) *Arrays_ArrayItr { t := &Arrays_ArrayItr{}; t.Ctor_O1(p0); return t }
//line :1177:1
func (t *Arrays_ArrayItr) Ctor_O1(a *RefArray) { t.F_a = a }

func (t *Arrays_ArrayItr) HasNext__Z() bool { var tmp1 int32 = t.F_cursor; return tmp1 < int32(len(t.F_a.A)) }

func (t *Arrays_ArrayItr) Next__O() any {
	var i int32 = t.F_cursor
	if i >= int32(len(t.F_a.A)) { panic(Thrown(NoSuchElementException_New())) }
	t.F_cursor = i + 1
	return t.F_a.A[i]
}
func Arrays_HashCode_J1__I(a *LongArray) int32 { Arrays_Init()
	if a == nil { return 0 } else {

		var result int32 = 1; var arr_101736 *LongArray = a; var len_101737 int32 = int32(len(arr_101736.A)); var i_101738 int32 = 0; for ; i_101738 < len_101737; i_101738++ {
			var element int64 = arr_101736.A[i_101738]
			result = 31*result + Long_HashCode_J__I(element) }
//line :1190:1
		return result
	}
}



func Arrays_HashCode_I1__I(a *IntArray) int32 { Arrays_Init()
	if a == nil { return 0 } else { return ArraysSupport_HashCode_I1_I_I_I__I(a, 0, int32(len(a.A)), 1)
	} }
func Arrays_HashCode_S1__I(a *ShortArray) int32 { Arrays_Init()
	if a == nil { return 0 } else { return ArraysSupport_HashCode_S1_I_I_I__I(a, 0, int32(len(a.A)), 1)
	} }
func Arrays_HashCode_C1__I(a *CharArray) int32 { Arrays_Init()
	if a == nil { return 0 } else { return ArraysSupport_HashCode_C1_I_I_I__I(a, 0, int32(len(a.A)), 1)
	} }
func Arrays_HashCode_B1__I(a *ByteArray) int32 { Arrays_Init()
	if a == nil { return 0 } else { return ArraysSupport_HashCode_B1_I_I_I__I(a, 0, int32(len(a.A)), 1)
	} }
func Arrays_HashCode_Z1__I(a *BooleanArray) int32 { Arrays_Init()
	if a == nil { return 0 } else {

		var result int32 = 1; var arr_101739 *BooleanArray = a; var len_101740 int32 = int32(len(arr_101739.A)); var i_101741 int32 = 0; for ; i_101741 < len_101740; i_101741++ {
			var element bool = arr_101739.A[i_101741]
			result = 31*result + Boolean_HashCode_Z__I(element) }
//line :1211:1
		return result
	}
}



func Arrays_HashCode_F1__I(a *FloatArray) int32 { Arrays_Init()
	if a == nil { return 0 } else {

		var result int32 = 1; var arr_101742 *FloatArray = a; var len_101743 int32 = int32(len(arr_101742.A)); var i_101744 int32 = 0; for ; i_101744 < len_101743; i_101744++ {
			var element float32 = arr_101742.A[i_101744]
			result = 31*result + Float_HashCode_F__I(element) }
//line :1220:1
		return result
	}
}



func Arrays_HashCode_D1__I(a *DoubleArray) int32 { Arrays_Init()
	if a == nil { return 0 } else {

		var result int32 = 1; var arr_101745 *DoubleArray = a; var len_101746 int32 = int32(len(arr_101745.A)); var i_101747 int32 = 0; for ; i_101747 < len_101746; i_101747++ {
			var element float64 = arr_101745.A[i_101747]
			result = 31*result + Double_HashCode_D__I(element) }
//line :1229:1
		return result
	}
}



func Arrays_HashCode_O1__I(a *RefArray) int32 { Arrays_Init()
	if a == nil { return 0 } else { return ArraysSupport_HashCode_O1_I_I_I__I(a, 0, int32(len(a.A)), 1)
	} }
func Arrays_DeepHashCode_O1__I(a *RefArray) int32 { Arrays_Init()
	if a == nil { return 0 } else {

		var result int32 = 1; var arr_101748 *RefArray = a; var len_101749 int32 = int32(len(arr_101748.A)); var i_101750 int32 = 0; for ; i_101750 < len_101749; i_101750++ {
			var element any = arr_101748.A[i_101750]; var elementHash int32 = 0; var cl *Class


			if element == nil {
				elementHash = 0 } else {
//line :1245:1
					var tmp1 *Class

					cl = NN(GetClass(element)).GetComponentType__Class(); tmp1 = cl
//line :1245:1
					if tmp1 == nil {


						elementHash = HashCode(element) } else {
//line :1245:1
							if Object_class.ArrayClass().IsInstance_O__Z(element) {




								elementHash = Arrays_DeepHashCode_O1__I(A2g_CastArray[*RefArray](element, Object_class.ArrayClass())) } else {
									elementHash = Arrays_PrimitiveArrayHashCode_O_Class__I(element, cl) } } }
			result = 31*result + elementHash }
//line :1241:1
		return result
	}
}











func Arrays_PrimitiveArrayHashCode_O_Class__I(a any, cl *Class) int32 { Arrays_Init()
	var tmp1 *Class; Byte_Init(); tmp1 = Byte_TYPE; if cl == tmp1 {
		return Arrays_HashCode_B1__I(A2g_CastArray[*ByteArray](a, Prim_byte.ArrayClass())) } else {
//line :1256:1
			var tmp2 *Class; Integer_Init(); tmp2 = Integer_TYPE; if cl == tmp2 {

				return Arrays_HashCode_I1__I(A2g_CastArray[*IntArray](a, Prim_int.ArrayClass())) } else {
//line :1256:1
					var tmp3 *Class; Long_Init(); tmp3 = Long_TYPE; if cl == tmp3 {


						return Arrays_HashCode_J1__I(A2g_CastArray[*LongArray](a, Prim_long.ArrayClass())) } else {
//line :1256:1
							var tmp4 *Class; Character_Init(); tmp4 = Character_TYPE; if cl == tmp4 {



								return Arrays_HashCode_C1__I(A2g_CastArray[*CharArray](a, Prim_char.ArrayClass())) } else {
//line :1256:1
									var tmp5 *Class; Short_Init(); tmp5 = Short_TYPE; if cl == tmp5 {




										return Arrays_HashCode_S1__I(A2g_CastArray[*ShortArray](a, Prim_short.ArrayClass())) } else {
//line :1256:1
											var tmp6 *Class; Boolean_Init(); tmp6 = Boolean_TYPE; if cl == tmp6 {





												return Arrays_HashCode_Z1__I(A2g_CastArray[*BooleanArray](a, Prim_boolean.ArrayClass())) } else {
//line :1256:1
													var tmp7 *Class; Double_Init(); tmp7 = Double_TYPE; if cl == tmp7 {






														return Arrays_HashCode_D1__I(A2g_CastArray[*DoubleArray](a, Prim_double.ArrayClass())) } else {
															return Arrays_HashCode_F1__I(A2g_CastArray[*FloatArray](a, Prim_float.ArrayClass()))
														} } } } } } } }
func Arrays_DeepEquals_O1_O1__Z(a1, a2 *RefArray) bool { Arrays_Init()
	if a1 == a2 { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = a1 == nil; if !tmp2 { tmp2 = a2 == nil }; tmp1 = tmp2
//line :1267:1
		if tmp1 { return false } else {



			var length int32 = int32(len(a1.A))
			if !(int32(len(a2.A)) == length) { return false } else {


				var i int32 = 0; L1: for {
					if i < length {
						var e1 any = a1.A[i]; var e2 any = a2.A[i]

						if e1 == e2 {
							i = i + 1; continue L1 } else {

								if e1 == nil { return false }
								var eq bool = Arrays_DeepEquals0_O_O__Z(e1, e2)
								if !eq { return false } else { i = i + 1; continue L1 } } }
//line :1275:1
					break L1 }
//line :1274:1
				return true
			}
		}
	}
}








func Arrays_DeepEquals0_O_O__Z(e1, e2 any) bool { Arrays_Init()
	if !A2g_AssertionsDisabled && !!(e1 == nil) { panic(Thrown(AssertionError_New())) }
	var eq bool; var tmp1 bool; var tmp2 bool
	tmp2 = Object_class.ArrayClass().IsInstance_O__Z(e1); if tmp2 { tmp2 = Object_class.ArrayClass().IsInstance_O__Z(e2) }; tmp1 = tmp2
//line :1289:1
	if tmp1 {

		eq = Arrays_DeepEquals_O1_O1__Z(A2g_CastArray[*RefArray](e1, Object_class.ArrayClass()), A2g_CastArray[*RefArray](e2, Object_class.ArrayClass())) } else {
//line :1289:1
			var tmp3 bool; var tmp4 bool


			tmp4 = Prim_byte.ArrayClass().IsInstance_O__Z(e1); if tmp4 { tmp4 = Prim_byte.ArrayClass().IsInstance_O__Z(e2) }; tmp3 = tmp4
//line :1289:1
			if tmp3 {



				eq = Arrays_Equals_B1_B1__Z(A2g_CastArray[*ByteArray](e1, Prim_byte.ArrayClass()), A2g_CastArray[*ByteArray](e2, Prim_byte.ArrayClass())) } else {
//line :1289:1
					var tmp5 bool; var tmp6 bool




					tmp6 = Prim_short.ArrayClass().IsInstance_O__Z(e1); if tmp6 { tmp6 = Prim_short.ArrayClass().IsInstance_O__Z(e2) }; tmp5 = tmp6
//line :1289:1
					if tmp5 {





						eq = Arrays_Equals_S1_S1__Z(A2g_CastArray[*ShortArray](e1, Prim_short.ArrayClass()), A2g_CastArray[*ShortArray](e2, Prim_short.ArrayClass())) } else {
//line :1289:1
							var tmp7 bool; var tmp8 bool






							tmp8 = Prim_int.ArrayClass().IsInstance_O__Z(e1); if tmp8 { tmp8 = Prim_int.ArrayClass().IsInstance_O__Z(e2) }; tmp7 = tmp8
//line :1289:1
							if tmp7 {







								eq = Arrays_Equals_I1_I1__Z(A2g_CastArray[*IntArray](e1, Prim_int.ArrayClass()), A2g_CastArray[*IntArray](e2, Prim_int.ArrayClass())) } else {
//line :1289:1
									var tmp9 bool; var tmp10 bool








									tmp10 = Prim_long.ArrayClass().IsInstance_O__Z(e1); if tmp10 { tmp10 = Prim_long.ArrayClass().IsInstance_O__Z(e2) }; tmp9 = tmp10
//line :1289:1
									if tmp9 {









										eq = Arrays_Equals_J1_J1__Z(A2g_CastArray[*LongArray](e1, Prim_long.ArrayClass()), A2g_CastArray[*LongArray](e2, Prim_long.ArrayClass())) } else {
//line :1289:1
											var tmp11 bool; var tmp12 bool










											tmp12 = Prim_char.ArrayClass().IsInstance_O__Z(e1); if tmp12 { tmp12 = Prim_char.ArrayClass().IsInstance_O__Z(e2) }; tmp11 = tmp12
//line :1289:1
											if tmp11 {











												eq = Arrays_Equals_C1_C1__Z(A2g_CastArray[*CharArray](e1, Prim_char.ArrayClass()), A2g_CastArray[*CharArray](e2, Prim_char.ArrayClass())) } else {
//line :1289:1
													var tmp13 bool; var tmp14 bool












													tmp14 = Prim_float.ArrayClass().IsInstance_O__Z(e1); if tmp14 { tmp14 = Prim_float.ArrayClass().IsInstance_O__Z(e2) }; tmp13 = tmp14
//line :1289:1
													if tmp13 {













														eq = Arrays_Equals_F1_F1__Z(A2g_CastArray[*FloatArray](e1, Prim_float.ArrayClass()), A2g_CastArray[*FloatArray](e2, Prim_float.ArrayClass())) } else {
//line :1289:1
															var tmp15 bool; var tmp16 bool














															tmp16 = Prim_double.ArrayClass().IsInstance_O__Z(e1); if tmp16 { tmp16 = Prim_double.ArrayClass().IsInstance_O__Z(e2) }; tmp15 = tmp16
//line :1289:1
															if tmp15 {















																eq = Arrays_Equals_D1_D1__Z(A2g_CastArray[*DoubleArray](e1, Prim_double.ArrayClass()), A2g_CastArray[*DoubleArray](e2, Prim_double.ArrayClass())) } else {
//line :1289:1
																	var tmp17 bool; var tmp18 bool
















																	tmp18 = Prim_boolean.ArrayClass().IsInstance_O__Z(e1); if tmp18 { tmp18 = Prim_boolean.ArrayClass().IsInstance_O__Z(e2) }; tmp17 = tmp18
//line :1289:1
																	if tmp17 {

















																		eq = Arrays_Equals_Z1_Z1__Z(A2g_CastArray[*BooleanArray](e1, Prim_boolean.ArrayClass()), A2g_CastArray[*BooleanArray](e2, Prim_boolean.ArrayClass())) } else {
																			eq = Equals(e1, e2) } } } } } } } } }
//line :1289:1
	return eq
}




















func Arrays_ToString_J1__String(a *LongArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_J__StringBuilder(a.A[i])
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_I1__String(a *IntArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_I__StringBuilder(a.A[i])
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_S1__String(a *ShortArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_I__StringBuilder(int32(a.A[i]))
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_C1__String(a *CharArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_C__StringBuilder(a.A[i])
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_B1__String(a *ByteArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_I__StringBuilder(int32(a.A[i]))
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_Z1__String(a *BooleanArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_Z__StringBuilder(a.A[i])
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_F1__String(a *FloatArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_F__StringBuilder(a.A[i])
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_D1__String(a *DoubleArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_D__StringBuilder(a.A[i])
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_ToString_O1__String(a *RefArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var iMax int32 = int32(len(a.A)) - 1
		if iMax == -1 { return Lit_2589 } else {

			var b *StringBuilder = StringBuilder_New()
			NN(b).Append_C__StringBuilder(91)
			var i int32 = 0; L1: for {
				NN(b).Append_String__StringBuilder(String_ValueOf_O__String(a.A[i]))
				if i == iMax { return NN(NN(b).Append_C__StringBuilder(93)).ToString__String() }
				NN(b).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func Arrays_DeepToString_O1__String(a *RefArray) *String { Arrays_Init()
	if a == nil { return Lit_95 } else {

		var bufLen int32 = 20 * int32(len(a.A)); var tmp1 bool; var tmp2 bool
		tmp2 = !(int32(len(a.A)) == 0); if tmp2 { tmp2 = bufLen <= 0 }; tmp1 = tmp2; if tmp1 { bufLen = 2147483647 }
		var buf *StringBuilder = StringBuilder_New_I(bufLen); Arrays_DeepToString_O1_StringBuilder_Set__V(a, buf, HashSet_New()); return NN(buf).ToString__String()
	} }
func Arrays_DeepToString_O1_StringBuilder_Set__V(a *RefArray, buf *StringBuilder, dejaVu Set) { Arrays_Init()

	if a == nil {
		NN(buf).Append_String__StringBuilder(Lit_95) } else {
			var iMax int32 = int32(len(a.A)) - 1
			if iMax == -1 {
				NN(buf).Append_String__StringBuilder(Lit_2589) } else {

					dejaVu.Add_O__Z(a.Ref())
					NN(buf).Append_C__StringBuilder(91)
					var i int32 = 0; L1: for {
						var element any = a.A[i]
						if element == nil {
							NN(buf).Append_String__StringBuilder(Lit_95) } else {
								var eClass *Class = GetClass(element)
								if NN(eClass).IsArray__Z() {
									if eClass == Prim_byte.ArrayClass() {

										NN(buf).Append_String__StringBuilder(Arrays_ToString_B1__String(A2g_CastArray[*ByteArray](element, Prim_byte.ArrayClass()))) } else {
//line :1460:1
											if eClass == Prim_short.ArrayClass() {



												NN(buf).Append_String__StringBuilder(Arrays_ToString_S1__String(A2g_CastArray[*ShortArray](element, Prim_short.ArrayClass()))) } else {
//line :1460:1
													if eClass == Prim_int.ArrayClass() {





														NN(buf).Append_String__StringBuilder(Arrays_ToString_I1__String(A2g_CastArray[*IntArray](element, Prim_int.ArrayClass()))) } else {
//line :1460:1
															if eClass == Prim_long.ArrayClass() {







																NN(buf).Append_String__StringBuilder(Arrays_ToString_J1__String(A2g_CastArray[*LongArray](element, Prim_long.ArrayClass()))) } else {
//line :1460:1
																	if eClass == Prim_char.ArrayClass() {









																		NN(buf).Append_String__StringBuilder(Arrays_ToString_C1__String(A2g_CastArray[*CharArray](element, Prim_char.ArrayClass()))) } else {
//line :1460:1
																			if eClass == Prim_float.ArrayClass() {











																				NN(buf).Append_String__StringBuilder(Arrays_ToString_F1__String(A2g_CastArray[*FloatArray](element, Prim_float.ArrayClass()))) } else {
//line :1460:1
																					if eClass == Prim_double.ArrayClass() {













																						NN(buf).Append_String__StringBuilder(Arrays_ToString_D1__String(A2g_CastArray[*DoubleArray](element, Prim_double.ArrayClass()))) } else {
//line :1460:1
																							if eClass == Prim_boolean.ArrayClass() {















																								NN(buf).Append_String__StringBuilder(Arrays_ToString_Z1__String(A2g_CastArray[*BooleanArray](element, Prim_boolean.ArrayClass()))) } else {
//line :1460:1
																									if dejaVu.Contains_O__Z(element) {
















																										NN(buf).Append_String__StringBuilder(Lit_2604) } else {
																											Arrays_DeepToString_O1_StringBuilder_Set__V(A2g_CastArray[*RefArray](element, Object_class.ArrayClass()), buf, dejaVu) } } } } } } } } } } else {
																												NN(buf).Append_String__StringBuilder(ToString(element)) } }
						if i == iMax { } else { NN(buf).Append_String__StringBuilder(Lit_1178); i = i + 1; continue L1 }
//line :1454:1
						break L1
					}

























					NN(buf).Append_C__StringBuilder(93)
					dejaVu.Remove_O__Z(a.Ref())
				} } }
func Arrays_SetAll_O1_IntFunction__V(array *RefArray, generator IntFunction) { Arrays_Init()

	Objects_RequireNonNull_O__O(generator)
	var i int32 = 0; L1: for {
		if i < int32(len(array.A)) { array.Store(i, generator.Apply_I__O(i)); i = i + 1; continue L1 }
//line :1487:1
		break L1
	}
}
func Arrays_ParallelSetAll_O1_IntFunction__V(array *RefArray, generator IntFunction) { Arrays_Init()

	Objects_RequireNonNull_O__O(generator)
	IntStream_Range_I_I__IntStream(0, int32(len(array.A))).Parallel__IntStream().ForEach_IntConsumer__V(&IntConsumer_Fn{Fn: func(p0 int32) { var i int32 = p0;
		array.Store(i, generator.Apply_I__O(i)) },
	}) }
func Arrays_SetAll_I1_IntUnaryOperator__V(array *IntArray, generator IntUnaryOperator) { Arrays_Init()
	Objects_RequireNonNull_O__O(generator)
	var i int32 = 0; L1: for {
		if i < int32(len(array.A)) {
			array.A[i] = generator.ApplyAsInt_I__I(i)
			i = i + 1; continue L1 }
//line :1498:1
		break L1
	}
}


func Arrays_ParallelSetAll_I1_IntUnaryOperator__V(array *IntArray, generator IntUnaryOperator) { Arrays_Init()
	Objects_RequireNonNull_O__O(generator)
	IntStream_Range_I_I__IntStream(0, int32(len(array.A))).Parallel__IntStream().ForEach_IntConsumer__V(&IntConsumer_Fn{Fn: func(p0 int32) { var i int32 = p0;
		array.A[i] = generator.ApplyAsInt_I__I(i) },
	}) }
func Arrays_SetAll_J1_IntToLongFunction__V(array *LongArray, generator IntToLongFunction) { Arrays_Init()
	Objects_RequireNonNull_O__O(generator)
	var i int32 = 0; L1: for {
		if i < int32(len(array.A)) {
			array.A[i] = generator.ApplyAsLong_I__J(i)
			i = i + 1; continue L1 }
//line :1510:1
		break L1
	}
}


func Arrays_ParallelSetAll_J1_IntToLongFunction__V(array *LongArray, generator IntToLongFunction) { Arrays_Init()
	Objects_RequireNonNull_O__O(generator)
	IntStream_Range_I_I__IntStream(0, int32(len(array.A))).Parallel__IntStream().ForEach_IntConsumer__V(&IntConsumer_Fn{Fn: func(p0 int32) { var i int32 = p0;
		array.A[i] = generator.ApplyAsLong_I__J(i) },
	}) }
func Arrays_SetAll_D1_IntToDoubleFunction__V(array *DoubleArray, generator IntToDoubleFunction) { Arrays_Init()
	Objects_RequireNonNull_O__O(generator)
	var i int32 = 0; L1: for {
		if i < int32(len(array.A)) {
			array.A[i] = generator.ApplyAsDouble_I__D(i)
			i = i + 1; continue L1 }
//line :1522:1
		break L1
	}
}


func Arrays_ParallelSetAll_D1_IntToDoubleFunction__V(array *DoubleArray, generator IntToDoubleFunction) { Arrays_Init()
	Objects_RequireNonNull_O__O(generator)
	IntStream_Range_I_I__IntStream(0, int32(len(array.A))).Parallel__IntStream().ForEach_IntConsumer__V(&IntConsumer_Fn{Fn: func(p0 int32) { var i int32 = p0;
		array.A[i] = generator.ApplyAsDouble_I__D(i) },
	}) }
func Arrays_Spliterator_O1__Spliterator(array *RefArray) Spliterator { Arrays_Init()
	return Spliterators_Spliterator_O1_I__Spliterator(array, 1040)
}
func Arrays_Spliterator_O1_I_I__Spliterator(array *RefArray, startInclusive, endExclusive int32) Spliterator { Arrays_Init()


	return Spliterators_Spliterator_O1_I_I_I__Spliterator(array, startInclusive, endExclusive, 1040)
}



func Arrays_Spliterator_I1__Spliterator_OfInt(array *IntArray) Spliterator_OfInt { Arrays_Init()
	return Spliterators_Spliterator_I1_I__Spliterator_OfInt(array, 1040)
}
func Arrays_Spliterator_I1_I_I__Spliterator_OfInt(array *IntArray, startInclusive, endExclusive int32) Spliterator_OfInt { Arrays_Init()

	return Spliterators_Spliterator_I1_I_I_I__Spliterator_OfInt(array, startInclusive, endExclusive, 1040)
}



func Arrays_Spliterator_J1__Spliterator_OfLong(array *LongArray) Spliterator_OfLong { Arrays_Init()
	return Spliterators_Spliterator_J1_I__Spliterator_OfLong(array, 1040)
}
func Arrays_Spliterator_J1_I_I__Spliterator_OfLong(array *LongArray, startInclusive, endExclusive int32) Spliterator_OfLong { Arrays_Init()

	return Spliterators_Spliterator_J1_I_I_I__Spliterator_OfLong(array, startInclusive, endExclusive, 1040)
}



func Arrays_Spliterator_D1__Spliterator_OfDouble(array *DoubleArray) Spliterator_OfDouble { Arrays_Init()
	return Spliterators_Spliterator_D1_I__Spliterator_OfDouble(array, 1040)
}
func Arrays_Spliterator_D1_I_I__Spliterator_OfDouble(array *DoubleArray, startInclusive, endExclusive int32) Spliterator_OfDouble { Arrays_Init()

	return Spliterators_Spliterator_D1_I_I_I__Spliterator_OfDouble(array, startInclusive, endExclusive, 1040)
}



func Arrays_Stream_O1__Stream(array *RefArray) Stream { Arrays_Init()
	return Arrays_Stream_O1_I_I__Stream(array, 0, int32(len(array.A)))
}
func Arrays_Stream_O1_I_I__Stream(array *RefArray, startInclusive, endExclusive int32) Stream { Arrays_Init()


	return StreamSupport_Stream_Spliterator_Z__Stream(Arrays_Spliterator_O1_I_I__Spliterator(array, startInclusive, endExclusive), false)
}
func Arrays_Stream_I1__IntStream(array *IntArray) IntStream { Arrays_Init()
	return Arrays_Stream_I1_I_I__IntStream(array, 0, int32(len(array.A)))
}
func Arrays_Stream_I1_I_I__IntStream(array *IntArray, startInclusive, endExclusive int32) IntStream { Arrays_Init()
	return StreamSupport_IntStream_Spliterator_OfInt_Z__IntStream(Arrays_Spliterator_I1_I_I__Spliterator_OfInt(array, startInclusive, endExclusive), false)
}
func Arrays_Stream_J1__LongStream(array *LongArray) LongStream { Arrays_Init()
	return Arrays_Stream_J1_I_I__LongStream(array, 0, int32(len(array.A)))
}
func Arrays_Stream_J1_I_I__LongStream(array *LongArray, startInclusive, endExclusive int32) LongStream { Arrays_Init()
	return StreamSupport_LongStream_Spliterator_OfLong_Z__LongStream(Arrays_Spliterator_J1_I_I__Spliterator_OfLong(array, startInclusive, endExclusive), false)
}
func Arrays_Stream_D1__DoubleStream(array *DoubleArray) DoubleStream { Arrays_Init()
	return Arrays_Stream_D1_I_I__DoubleStream(array, 0, int32(len(array.A)))
}
func Arrays_Stream_D1_I_I__DoubleStream(array *DoubleArray, startInclusive, endExclusive int32) DoubleStream { Arrays_Init()

	return StreamSupport_DoubleStream_Spliterator_OfDouble_Z__DoubleStream(Arrays_Spliterator_D1_I_I__Spliterator_OfDouble(array, startInclusive, endExclusive), false)
}
func Arrays_Compare_Z1_Z1__I(a, b *BooleanArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1601:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_Z1_Z1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 bool = a.A[i]; return Boolean_Compare_Z_Z__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_Z1_I_I_Z1_I_I__I(a *BooleanArray, aFromIndex, aToIndex int32, b *BooleanArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_Z1_I_Z1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 bool = a.A[aFromIndex+i]; return Boolean_Compare_Z_Z__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_B1_B1__I(a, b *ByteArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1623:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_B1_B1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int8 = a.A[i]; return Byte_Compare_B_B__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_B1_I_I_B1_I_I__I(a *ByteArray, aFromIndex, aToIndex int32, b *ByteArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_B1_I_B1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int8 = a.A[aFromIndex+i]; return Byte_Compare_B_B__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_CompareUnsigned_B1_B1__I(a, b *ByteArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1645:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_B1_B1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int8 = a.A[i]; return Byte_CompareUnsigned_B_B__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_CompareUnsigned_B1_I_I_B1_I_I__I(a *ByteArray, aFromIndex, aToIndex int32, b *ByteArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_B1_I_B1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int8 = a.A[aFromIndex+i]; return Byte_CompareUnsigned_B_B__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_S1_S1__I(a, b *ShortArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1667:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_S1_S1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int16 = a.A[i]; return Short_Compare_S_S__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_S1_I_I_S1_I_I__I(a *ShortArray, aFromIndex, aToIndex int32, b *ShortArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_S1_I_S1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int16 = a.A[aFromIndex+i]; return Short_Compare_S_S__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_CompareUnsigned_S1_S1__I(a, b *ShortArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1689:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_S1_S1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int16 = a.A[i]; return Short_CompareUnsigned_S_S__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_CompareUnsigned_S1_I_I_S1_I_I__I(a *ShortArray, aFromIndex, aToIndex int32, b *ShortArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_S1_I_S1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int16 = a.A[aFromIndex+i]; return Short_CompareUnsigned_S_S__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_C1_C1__I(a, b *CharArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1711:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_C1_C1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 uint16 = a.A[i]; return Character_Compare_C_C__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_C1_I_I_C1_I_I__I(a *CharArray, aFromIndex, aToIndex int32, b *CharArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_C1_I_C1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 uint16 = a.A[aFromIndex+i]; return Character_Compare_C_C__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_I1_I1__I(a, b *IntArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1733:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_I1_I1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int32 = a.A[i]; return Integer_Compare_I_I__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_I1_I_I_I1_I_I__I(a *IntArray, aFromIndex, aToIndex int32, b *IntArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_I1_I_I1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int32 = a.A[aFromIndex+i]; return Integer_Compare_I_I__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_CompareUnsigned_I1_I1__I(a, b *IntArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1755:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_I1_I1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int32 = a.A[i]; return Integer_CompareUnsigned_I_I__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_CompareUnsigned_I1_I_I_I1_I_I__I(a *IntArray, aFromIndex, aToIndex int32, b *IntArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_I1_I_I1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int32 = a.A[aFromIndex+i]; return Integer_CompareUnsigned_I_I__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_J1_J1__I(a, b *LongArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1777:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_J1_J1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int64 = a.A[i]; return Long_Compare_J_J__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_J1_I_I_J1_I_I__I(a *LongArray, aFromIndex, aToIndex int32, b *LongArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_J1_I_J1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int64 = a.A[aFromIndex+i]; return Long_Compare_J_J__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_CompareUnsigned_J1_J1__I(a, b *LongArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1799:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_J1_J1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 int64 = a.A[i]; return Long_CompareUnsigned_J_J__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_CompareUnsigned_J1_I_I_J1_I_I__I(a *LongArray, aFromIndex, aToIndex int32, b *LongArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_J1_I_J1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 int64 = a.A[aFromIndex+i]; return Long_CompareUnsigned_J_J__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_F1_F1__I(a, b *FloatArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1821:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_F1_F1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 float32 = a.A[i]; return Float_Compare_F_F__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_F1_I_I_F1_I_I__I(a *FloatArray, aFromIndex, aToIndex int32, b *FloatArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_F1_I_F1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 float32 = a.A[aFromIndex+i]; return Float_Compare_F_F__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_D1_D1__I(a, b *DoubleArray) int32 { Arrays_Init()
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1843:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var i int32 = ArraysSupport_Mismatch_D1_D1_I__I(a, b, Math_Min_I_I__I(tmp3, int32(len(b.A))))
				if i >= 0 {
					var tmp4 float64 = a.A[i]; return Double_Compare_D_D__I(tmp4, b.A[i]) } else {
						var tmp5 int32 = int32(len(a.A)); return tmp5 - int32(len(b.A))
					} } } }
func Arrays_Compare_D1_I_I_D1_I_I__I(a *DoubleArray, aFromIndex, aToIndex int32, b *DoubleArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var i int32 = ArraysSupport_Mismatch_D1_I_D1_I_I__I(a, aFromIndex, b, bFromIndex, Math_Min_I_I__I(aLength, bLength))


	if i >= 0 {
		var tmp1 float64 = a.A[aFromIndex+i]; return Double_Compare_D_D__I(tmp1, b.A[bFromIndex+i]) } else {

			return aLength - bLength
		} }
func Arrays_Compare_Comparable1_Comparable1__I(a, b *RefArray) int32 { Arrays_Init()

	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1866:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp3, int32(len(b.A))); var i int32 = 0
			L1: for {
				if i < length {
					var oa Comparable = As[Comparable](a.A[i]); var ob Comparable = As[Comparable](b.A[i])

					if !(oa == ob) {

						var tmp4 bool; var tmp5 bool; tmp5 = oa == nil; if !tmp5 { tmp5 = ob == nil }; tmp4 = tmp5; if tmp4 { var tmp6 int32; if oa == nil { tmp6 = -1 } else { tmp6 = 1 }; return tmp6 }
						var v int32 = oa.CompareTo_O__I(ob)
						if !(v == 0) { return v } else { i = i + 1; continue L1 } } else {
							i = i + 1; continue L1 } }
//line :1871:1
				break L1
			}








				var tmp7 int32 = int32(len(a.A)); return tmp7 - int32(len(b.A))
			} } }
func Arrays_Compare_Comparable1_I_I_Comparable1_I_I__I(a *RefArray, aFromIndex, aToIndex int32, b *RefArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()





	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength)
	var i int32 = 0

L1: for {
	if i < length {
		var oa Comparable; var tmp1 int32
		var old_5 int32 = aFromIndex
		aFromIndex = aFromIndex + 1
//line :1897:1
		tmp1 = old_5
//line :1896:1
		oa = As[Comparable](a.A[tmp1]); var ob Comparable; var tmp2 int32
		var old_6 int32 = bFromIndex




		bFromIndex = bFromIndex + 1
//line :1901:1
		tmp2 = old_6
//line :1900:1
		ob = As[Comparable](b.A[tmp2])



		if !(oa == ob) {

			var tmp3 bool; var tmp4 bool; tmp4 = oa == nil; if !tmp4 { tmp4 = ob == nil }; tmp3 = tmp4; if tmp3 { var tmp5 int32; if oa == nil { tmp5 = -1 } else { tmp5 = 1 }; return tmp5 }
			var v int32 = oa.CompareTo_O__I(ob)
			if !(v == 0) { return v } else { i = i + 1; continue L1 } } else {
				i = i + 1; continue L1 } }
//line :1894:1
	break L1
}














	return aLength - bLength
}
func Arrays_Compare_O1_O1_Comparator__I(a, b *RefArray, cmp Comparator) int32 { Arrays_Init()

	Objects_RequireNonNull_O__O(cmp)
	if a == b { return 0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2
//line :1915:1
		if tmp1 {

			if a == nil { return -1 } else { return 1 } } else {

				var tmp3 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp3, int32(len(b.A))); var i int32 = 0
			L1: for {
				if i < length {
					var oa any = a.A[i]; var ob any = b.A[i]

					if !(oa == ob) {
						var v int32 = cmp.Compare_O_O__I(oa, ob)
						if !(v == 0) { return v } else { i = i + 1; continue L1 } } else {
							i = i + 1; continue L1 } }
//line :1920:1
				break L1
			}






				var tmp4 int32 = int32(len(a.A)); return tmp4 - int32(len(b.A))
			} } }
func Arrays_Compare_O1_I_I_O1_I_I_Comparator__I(a *RefArray, aFromIndex, aToIndex int32, b *RefArray, bFromIndex, bToIndex int32, cmp Comparator) int32 { Arrays_Init()



	Objects_RequireNonNull_O__O(cmp)
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength)
	var i int32 = 0

L1: for {
	if i < length {
		var oa any; var tmp1 int32
		var old_7 int32 = aFromIndex
		aFromIndex = aFromIndex + 1
//line :1943:1
		tmp1 = old_7
//line :1942:1
		oa = a.A[tmp1]; var ob any; var tmp2 int32
		var old_8 int32 = bFromIndex




		bFromIndex = bFromIndex + 1
//line :1947:1
		tmp2 = old_8
//line :1946:1
		ob = b.A[tmp2]



		if !(oa == ob) {
			var v int32 = cmp.Compare_O_O__I(oa, ob)
			if !(v == 0) { return v } else { i = i + 1; continue L1 } } else {
				i = i + 1; continue L1 } }
//line :1940:1
	break L1
}












	return aLength - bLength
}
func Arrays_Mismatch_Z1_Z1__I(a, b *BooleanArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_Z1_Z1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_Z1_I_I_Z1_I_I__I(a *BooleanArray, aFromIndex, aToIndex int32, b *BooleanArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_Z1_I_Z1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_B1_B1__I(a, b *ByteArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_B1_B1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_B1_I_I_B1_I_I__I(a *ByteArray, aFromIndex, aToIndex int32, b *ByteArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_B1_I_B1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_C1_C1__I(a, b *CharArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_C1_C1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_C1_I_I_C1_I_I__I(a *CharArray, aFromIndex, aToIndex int32, b *CharArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_C1_I_C1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_S1_S1__I(a, b *ShortArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_S1_S1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_S1_I_I_S1_I_I__I(a *ShortArray, aFromIndex, aToIndex int32, b *ShortArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_S1_I_S1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_I1_I1__I(a, b *IntArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_I1_I1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_I1_I_I_I1_I_I__I(a *IntArray, aFromIndex, aToIndex int32, b *IntArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_I1_I_I1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_J1_J1__I(a, b *LongArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_J1_J1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_J1_I_I_J1_I_I__I(a *LongArray, aFromIndex, aToIndex int32, b *LongArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_J1_I_J1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_F1_F1__I(a, b *FloatArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_F1_F1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_F1_I_I_F1_I_I__I(a *FloatArray, aFromIndex, aToIndex int32, b *FloatArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_F1_I_F1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_D1_D1__I(a, b *DoubleArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {

		var i int32 = ArraysSupport_Mismatch_D1_D1_I__I(a, b, length); var tmp2 bool; var tmp3 bool
		tmp3 = i < 0; if tmp3 { var tmp4 int32 = int32(len(a.A)); tmp3 = !(tmp4 == int32(len(b.A))) }; tmp2 = tmp3; if tmp2 { return length } else { return i
		} } }
func Arrays_Mismatch_D1_I_I_D1_I_I__I(a *DoubleArray, aFromIndex, aToIndex int32, b *DoubleArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength); var i int32 = ArraysSupport_Mismatch_D1_I_D1_I_I__I(a, aFromIndex, b, bFromIndex, length); var tmp1 bool; var tmp2 bool



	tmp2 = i < 0; if tmp2 { tmp2 = !(aLength == bLength) }; tmp1 = tmp2; if tmp1 { return length } else { return i
	} }
func Arrays_Mismatch_O1_O1__I(a, b *RefArray) int32 { Arrays_Init()
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {


		var i int32 = 0; L1: for {
			if i < length {
				var tmp2 any = a.A[i]; if !Objects_Equals_O_O__Z(tmp2, b.A[i]) {
					return i } else {
						i = i + 1; continue L1 } }
//line :2097:1
			break L1
		}




		var tmp3 int32 = int32(len(a.A)); if !(tmp3 == int32(len(b.A))) { return length } else { return -1
		} } }
func Arrays_Mismatch_O1_I_I_O1_I_I__I(a *RefArray, aFromIndex, aToIndex int32, b *RefArray, bFromIndex, bToIndex int32) int32 { Arrays_Init()

	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength)
	var i int32 = 0

L1: for {
	if i < length {
		var tmp1 int32
		var old_9 int32 = aFromIndex

		aFromIndex = aFromIndex + 1
//line :2116:1
		tmp1 = old_9
//line :2114:1
		var tmp2 any = a.A[tmp1]; var tmp3 int32
		var old_10 int32 = bFromIndex





		bFromIndex = bFromIndex + 1
//line :2120:1
		tmp3 = old_10
//line :2114:1
		if !Objects_Equals_O_O__Z(tmp2, b.A[tmp3]) {








			return i } else {
				i = i + 1; continue L1 } }
//line :2112:1
	break L1
}












	if !(aLength == bLength) { return length } else { return -1
	} }
func Arrays_Mismatch_O1_O1_Comparator__I(a, b *RefArray, cmp Comparator) int32 { Arrays_Init()

	Objects_RequireNonNull_O__O(cmp)
	var tmp1 int32 = int32(len(a.A)); var length int32 = Math_Min_I_I__I(tmp1, int32(len(b.A)))
	if a == b { return -1 } else {


		var i int32 = 0; L1: for {
			if i < length {
				var oa any = a.A[i]; var ob any = b.A[i]

				if !(oa == ob) {
					var v int32 = cmp.Compare_O_O__I(oa, ob)
					if !(v == 0) { return i } else { i = i + 1; continue L1 } } else {
						i = i + 1; continue L1 } }
//line :2135:1
			break L1
		}






		var tmp2 int32 = int32(len(a.A)); if !(tmp2 == int32(len(b.A))) { return length } else { return -1
		} } }
func Arrays_Mismatch_O1_I_I_O1_I_I_Comparator__I(a *RefArray, aFromIndex, aToIndex int32, b *RefArray, bFromIndex, bToIndex int32, cmp Comparator) int32 { Arrays_Init()



	Objects_RequireNonNull_O__O(cmp)
	Arrays_RangeCheck_I_I_I__V(int32(len(a.A)), aFromIndex, aToIndex)
	Arrays_RangeCheck_I_I_I__V(int32(len(b.A)), bFromIndex, bToIndex)
	var aLength int32 = aToIndex - aFromIndex; var bLength int32 = bToIndex - bFromIndex; var length int32 = Math_Min_I_I__I(aLength, bLength)
	var i int32 = 0

L1: for {
	if i < length {
		var oa any; var tmp1 int32
		var old_11 int32 = aFromIndex
		aFromIndex = aFromIndex + 1
//line :2158:1
		tmp1 = old_11
//line :2157:1
		oa = a.A[tmp1]; var ob any; var tmp2 int32
		var old_12 int32 = bFromIndex




		bFromIndex = bFromIndex + 1
//line :2162:1
		tmp2 = old_12
//line :2161:1
		ob = b.A[tmp2]



		if !(oa == ob) {
			var v int32 = cmp.Compare_O_O__I(oa, ob)
			if !(v == 0) { return i } else { i = i + 1; continue L1 } } else {
				i = i + 1; continue L1 } }
//line :2155:1
	break L1
}












	if !(aLength == bLength) { return length } else { return -1
	}
}

type Arrays struct{ Object }

const Arrays_MIN_ARRAY_SORT_GRAN int32 = 8192

const Arrays_INSERTIONSORT_THRESHOLD int32 = 7

var Arrays_init ClassInit

func Arrays_Init() { if !Arrays_init.Done() { Arrays_init.Run(Arrays_clinit) } }

func Arrays_clinit() {}

func (t *Arrays) Ref() any { if t == nil { return nil }; return t }

func (t *Arrays) GetClass__Class() *Class { return Arrays_class }

func (t *Arrays) ToString__String() *String { return Object_toString(t) }

func (t *Arrays) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Arrays) CloneShallow() any { panic(CloneNotSupported(t)) }

func Arrays_InstanceOf(x any) bool { _, ok := x.(*Arrays); return ok }

func Arrays_Cast(x any) *Arrays { if x == nil { return nil }; v, ok := x.(*Arrays); if !ok { panic(ClassCast(x, Arrays_class)) }; return v }



type Arrays_ArrayItr struct{ Object; F_cursor int32; F_a *RefArray }

func (t *Arrays_ArrayItr) Is_Iterator() {}

func (t *Arrays_ArrayItr) Remove__V() { Iterator_Remove__V(t) }

func (t *Arrays_ArrayItr) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *Arrays_ArrayItr) Ref() any { if t == nil { return nil }; return t }

func (t *Arrays_ArrayItr) GetClass__Class() *Class { return Arrays_ArrayItr_class }

func (t *Arrays_ArrayItr) ToString__String() *String { return Object_toString(t) }

func (t *Arrays_ArrayItr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Arrays_ArrayItr) CloneShallow() any { panic(CloneNotSupported(t)) }

func Arrays_ArrayItr_InstanceOf(x any) bool { _, ok := x.(*Arrays_ArrayItr); return ok }

func Arrays_ArrayItr_Cast(x any) *Arrays_ArrayItr { if x == nil { return nil }; v, ok := x.(*Arrays_ArrayItr); if !ok { panic(ClassCast(x, Arrays_ArrayItr_class)) }; return v }



type Arrays_ArrayList struct{ AbstractList; F_a *RefArray }

func (t *Arrays_ArrayList) Is_RandomAccess() {}

func (t *Arrays_ArrayList) Is_Serializable() {}

const Arrays_ArrayList_serialVersionUID int64 = -2764017481108945198

func (t *Arrays_ArrayList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Arrays_ArrayList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *Arrays_ArrayList) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *Arrays_ArrayList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Arrays_ArrayList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Arrays_ArrayList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *Arrays_ArrayList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Arrays_ArrayList) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *Arrays_ArrayList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Arrays_ArrayList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Arrays_ArrayList) Reversed__List() List { return List_Reversed__List(t) }

func (t *Arrays_ArrayList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Arrays_ArrayList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Arrays_ArrayList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Arrays_ArrayList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Arrays_ArrayList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Arrays_ArrayList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Arrays_ArrayList) GetLast__O() any { return List_GetLast__O(t) }

func (t *Arrays_ArrayList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Arrays_ArrayList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Arrays_ArrayList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Arrays_ArrayList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Arrays_ArrayList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Arrays_ArrayList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Arrays_ArrayList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Arrays_ArrayList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Arrays_ArrayList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Arrays_ArrayList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Arrays_ArrayList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Arrays_ArrayList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Arrays_ArrayList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Arrays_ArrayList) Ref() any { if t == nil { return nil }; return t }

func (t *Arrays_ArrayList) GetClass__Class() *Class { return Arrays_ArrayList_class }

func (t *Arrays_ArrayList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Arrays_ArrayList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Arrays_ArrayList_InstanceOf(x any) bool { _, ok := x.(*Arrays_ArrayList); return ok }

func Arrays_ArrayList_Cast(x any) *Arrays_ArrayList { if x == nil { return nil }; v, ok := x.(*Arrays_ArrayList); if !ok { panic(ClassCast(x, Arrays_ArrayList_class)) }; return v }



type Arrays_LegacyMergeSort struct{ Object }

var Arrays_LegacyMergeSort_userRequested bool

var Arrays_LegacyMergeSort_init ClassInit

func Arrays_LegacyMergeSort_Init() { if !Arrays_LegacyMergeSort_init.Done() { Arrays_LegacyMergeSort_init.Run(Arrays_LegacyMergeSort_clinit) } }

func Arrays_LegacyMergeSort_clinit() { Arrays_LegacyMergeSort_userRequested = Boolean_GetBoolean_String__Z(Lit_2605) }

func Arrays_LegacyMergeSort_New() *Arrays_LegacyMergeSort { Arrays_LegacyMergeSort_Init(); t := &Arrays_LegacyMergeSort{}; t.Ctor(); return t }

func (t *Arrays_LegacyMergeSort) Ctor() {}

func (t *Arrays_LegacyMergeSort) Ref() any { if t == nil { return nil }; return t }

func (t *Arrays_LegacyMergeSort) GetClass__Class() *Class { return Arrays_LegacyMergeSort_class }

func (t *Arrays_LegacyMergeSort) ToString__String() *String { return Object_toString(t) }

func (t *Arrays_LegacyMergeSort) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Arrays_LegacyMergeSort) CloneShallow() any { panic(CloneNotSupported(t)) }

func Arrays_LegacyMergeSort_InstanceOf(x any) bool { _, ok := x.(*Arrays_LegacyMergeSort); return ok }

func Arrays_LegacyMergeSort_Cast(x any) *Arrays_LegacyMergeSort { if x == nil { return nil }; v, ok := x.(*Arrays_LegacyMergeSort); if !ok { panic(ClassCast(x, Arrays_LegacyMergeSort_class)) }; return v }



type Arrays_NaturalOrder struct{ Object }

func (t *Arrays_NaturalOrder) Is_Comparator() {}

var Arrays_NaturalOrder_INSTANCE *Arrays_NaturalOrder

var Arrays_NaturalOrder_init ClassInit

func Arrays_NaturalOrder_Init() { if !Arrays_NaturalOrder_init.Done() { Arrays_NaturalOrder_init.Run(Arrays_NaturalOrder_clinit) } }

func Arrays_NaturalOrder_clinit() { Arrays_NaturalOrder_INSTANCE = Arrays_NaturalOrder_New() }

func Arrays_NaturalOrder_New() *Arrays_NaturalOrder { Arrays_NaturalOrder_Init(); t := &Arrays_NaturalOrder{}; t.Ctor(); return t }

func (t *Arrays_NaturalOrder) Ctor() {}

func (t *Arrays_NaturalOrder) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *Arrays_NaturalOrder) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *Arrays_NaturalOrder) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *Arrays_NaturalOrder) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *Arrays_NaturalOrder) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *Arrays_NaturalOrder) Reversed__Comparator() Comparator { return Comparator_Reversed__Comparator(t) }

func (t *Arrays_NaturalOrder) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *Arrays_NaturalOrder) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *Arrays_NaturalOrder) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *Arrays_NaturalOrder) Ref() any { if t == nil { return nil }; return t }

func (t *Arrays_NaturalOrder) GetClass__Class() *Class { return Arrays_NaturalOrder_class }

func (t *Arrays_NaturalOrder) ToString__String() *String { return Object_toString(t) }

func (t *Arrays_NaturalOrder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Arrays_NaturalOrder) CloneShallow() any { panic(CloneNotSupported(t)) }

func Arrays_NaturalOrder_InstanceOf(x any) bool { _, ok := x.(*Arrays_NaturalOrder); return ok }

func Arrays_NaturalOrder_Cast(x any) *Arrays_NaturalOrder { if x == nil { return nil }; v, ok := x.(*Arrays_NaturalOrder); if !ok { panic(ClassCast(x, Arrays_NaturalOrder_class)) }; return v }
