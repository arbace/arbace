//line java_nio_IntBuffer.ae:1
package jrt



























func (t *IntBuffer) Ctor_I_I_I_I_I1_I_MemorySegment(this IntBuffer_I, mark, pos, lim, cap_ int32, hb *IntArray, offset int32, segment MemorySegment) { t.Buffer.Ctor_I_I_I_I_MemorySegment(this, mark, pos, lim, cap_, segment)


	t.F_hb = hb
	t.F_offset = offset
}
func (t *IntBuffer) Ctor_I_I_I_I_MemorySegment(this IntBuffer_I, mark, pos, lim, cap_ int32, segment MemorySegment) { t.Ctor_I_I_I_I_I1_I_MemorySegment(this, mark, pos, lim, cap_, nil, 0, segment) }


func (t *IntBuffer) Ctor_I1_J_I_MemorySegment(this IntBuffer_I, hb *IntArray, addr int64, cap_ int32, segment MemorySegment) { panic(A2g_NotTranslated("java.nio.IntBuffer.<init>([IJILjava/lang/foreign/MemorySegment;)V")) }




func (t *IntBuffer) Impl_Base__O(this IntBuffer_I) any { return t.F_hb.Ref() }

func IntBuffer_Allocate_I__IntBuffer(capacity int32) IntBuffer_I { IntBuffer_Init()
	if capacity < 0 { panic(Thrown(Buffer_CreateCapacityException_I__IllegalArgumentException(capacity))) }
	return HeapIntBuffer_New_I_I_MemorySegment(capacity, capacity, nil)
}
func IntBuffer_Wrap_I1_I_I__IntBuffer(array *IntArray, offset, length int32) IntBuffer_I { IntBuffer_Init()
	var tmp1 IntBuffer_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = HeapIntBuffer_New_I1_I_I_MemorySegment(array, offset, length, nil); return nil }()
//line :50:1
	if tmp2 != nil { if IllegalArgumentException_InstanceOf(tmp2) { var x IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = x

		panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :50:1
			panic(tmp2) } }; return tmp1
}


func IntBuffer_Wrap_I1__IntBuffer(array *IntArray) IntBuffer_I { IntBuffer_Init()
	return IntBuffer_Wrap_I1_I_I__IntBuffer(array, 0, int32(len(array.A)))
}
















func (t *IntBuffer) Impl_Get_I1_I_I__IntBuffer(this IntBuffer_I, dst *IntArray, offset, length int32) IntBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var pos int32 = this.Position__I()
	if length > this.Limit__I()-pos {
		panic(Thrown(BufferUnderflowException_New())) }
	this.GetArray_I_I1_I_I__IntBuffer(pos, dst, offset, length)
	this.Position_I__IntBuffer(pos + length)
//line :75:1
	return this
}





func (t *IntBuffer) Impl_Get_I1__IntBuffer(this IntBuffer_I, dst *IntArray) IntBuffer_I {
	return this.Get_I1_I_I__IntBuffer(dst, 0, int32(len(dst.A)))
}
func (t *IntBuffer) Impl_Get_I_I1_I_I__IntBuffer(this IntBuffer_I, index int32, dst *IntArray, offset, length int32) IntBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	this.GetArray_I_I1_I_I__IntBuffer(index, dst, offset, length)
//line :85:1
	return this
}




func (t *IntBuffer) Impl_Get_I_I1__IntBuffer(this IntBuffer_I, index int32, dst *IntArray) IntBuffer_I {
	return this.Get_I_I1_I_I__IntBuffer(index, dst, 0, int32(len(dst.A)))
}
func (t *IntBuffer) Impl_GetArray_I_I1_I_I__IntBuffer(this IntBuffer_I, index int32, dst *IntArray, offset, length int32) IntBuffer_I {
	if int64(length)<<2 > 6 {
		var bufAddr int64 = t.F_address + int64(index)<<2; var dstOffset int64 = IntBuffer_ARRAY_BASE_OFFSET + int64(offset)<<2; var len_ int64 = int64(length) << 2; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)



			if !(this.Order__ByteOrder() == ByteOrder_NativeOrder__ByteOrder()) {
				var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp1).CopySwapMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J_J__V(this.Session__MemorySessionImpl(), nil, this.Base__O(), bufAddr, dst.Ref(), dstOffset, len_, 4) } else {








					var tmp2 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp2).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(this.Session__MemorySessionImpl(), nil, this.Base__O(), bufAddr, dst.Ref(), dstOffset, len_) }; return nil
		}()






		Reference_ReachabilityFence_O__V(this)
//line :99:1
		if tmp3 != nil { panic(tmp3)
		}
















	} else {

		var end int32 = offset + length; var i int32 = offset; var j int32 = index
	L1: for {

		if i < end {
			dst.A[i] = this.Get_I__I(j)
			i, j = i+1, j+1; continue L1 }
//line :120:1
		break L1 } }
//line :94:1
	return this
}































func (t *IntBuffer) Impl_Put_IntBuffer__IntBuffer(this, src IntBuffer_I) IntBuffer_I {
	if src == this { panic(Thrown(Buffer_CreateSameBufferException__IllegalArgumentException())) }
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	var srcPos int32 = src.Position__I(); var srcLim int32 = src.Limit__I(); var srcRem int32

	if srcPos <= srcLim { srcRem = srcLim - srcPos } else { srcRem = 0 }
//line :130:1
	var pos int32 = this.Position__I(); var lim int32 = this.Limit__I(); var rem int32




	if pos <= lim { rem = lim - pos } else { rem = 0 }
	if srcRem > rem { panic(Thrown(BufferOverflowException_New())) }
	this.PutBuffer_I_IntBuffer_I_I__V(pos, src, srcPos, srcRem)
	this.Position_I__IntBuffer(pos + srcRem)
	src.Position_I__IntBuffer(srcPos + srcRem)
//line :130:1
	return this
}










func (t *IntBuffer) Impl_Put_I_IntBuffer_I_I__IntBuffer(this IntBuffer_I, index int32, src IntBuffer_I, offset, length int32) IntBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, src.Limit__I())
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	this.PutBuffer_I_IntBuffer_I_I__V(index, src, offset, length)
//line :142:1
	return this
}





func (t *IntBuffer) Impl_PutBuffer_I_IntBuffer_I_I__V(this IntBuffer_I, pos int32, src IntBuffer_I, srcPos, n int32) {
	var srcBase any = src.Base__O(); var tmp1 bool; var tmp2 bool
	tmp2 = !(srcBase == nil); if !tmp2 { tmp2 = src.IsDirect__Z() }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var base any = this.Base__O(); var tmp3 bool; var tmp4 bool
	tmp4 = !(base == nil); if !tmp4 { tmp4 = this.IsDirect__Z() }; tmp3 = tmp4; if !A2g_AssertionsDisabled && !tmp3 { panic(Thrown(AssertionError_New())) }
	var srcAddr int64 = src.Self_Buffer().F_address + int64(srcPos)<<2; var addr int64 = t.F_address + int64(pos)<<2; var len_ int64 = int64(n) << 2; tmp7 := func() (exc Throwable_I) { defer Catch(&exc)



		if !(this.Order__ByteOrder() == src.Order__ByteOrder()) {
			var tmp5 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp5).CopySwapMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J_J__V(src.Session__MemorySessionImpl(), this.Session__MemorySessionImpl(), srcBase, srcAddr, base, addr, len_, 4) } else {








				var tmp6 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp6).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(src.Session__MemorySessionImpl(), this.Session__MemorySessionImpl(), srcBase, srcAddr, base, addr, len_) }; return nil
	}()






	Reference_ReachabilityFence_O__V(src); Reference_ReachabilityFence_O__V(this)
//line :157:1
	if tmp7 != nil { panic(tmp7)
	}
}


















func (t *IntBuffer) Impl_Put_I1_I_I__IntBuffer(this IntBuffer_I, src *IntArray, offset, length int32) IntBuffer_I {
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var pos int32 = this.Position__I()
	if length > this.Limit__I()-pos {
		panic(Thrown(BufferOverflowException_New())) }
	this.PutArray_I_I1_I_I__IntBuffer(pos, src, offset, length)
	this.Position_I__IntBuffer(pos + length)
//line :181:1
	return this
}





func (t *IntBuffer) Impl_Put_I1__IntBuffer(this IntBuffer_I, src *IntArray) IntBuffer_I {
	return this.Put_I1_I_I__IntBuffer(src, 0, int32(len(src.A)))
}
func (t *IntBuffer) Impl_Put_I_I1_I_I__IntBuffer(this IntBuffer_I, index int32, src *IntArray, offset, length int32) IntBuffer_I {
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	this.PutArray_I_I1_I_I__IntBuffer(index, src, offset, length)
//line :191:1
	return this
}





func (t *IntBuffer) Impl_Put_I_I1__IntBuffer(this IntBuffer_I, index int32, src *IntArray) IntBuffer_I {
	return this.Put_I_I1_I_I__IntBuffer(index, src, 0, int32(len(src.A)))
}
func (t *IntBuffer) Impl_PutArray_I_I1_I_I__IntBuffer(this IntBuffer_I, index int32, src *IntArray, offset, length int32) IntBuffer_I {
	if int64(length)<<2 > 6 {
		var bufAddr int64 = t.F_address + int64(index)<<2; var srcOffset int64 = IntBuffer_ARRAY_BASE_OFFSET + int64(offset)<<2; var len_ int64 = int64(length) << 2; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)



			if !(this.Order__ByteOrder() == ByteOrder_NativeOrder__ByteOrder()) {
				var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp1).CopySwapMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J_J__V(nil, this.Session__MemorySessionImpl(), src.Ref(), srcOffset, this.Base__O(), bufAddr, len_, 4) } else {








					var tmp2 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp2).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(nil, this.Session__MemorySessionImpl(), src.Ref(), srcOffset, this.Base__O(), bufAddr, len_) }; return nil
		}()






		Reference_ReachabilityFence_O__V(this)
//line :206:1
		if tmp3 != nil { panic(tmp3)
		}
















	} else {

		var end int32 = offset + length; var i int32 = offset; var j int32 = index
	L1: for {

		if i < end {
			this.Put_I_I__IntBuffer(j, src.A[i])
			i, j = i+1, j+1; continue L1 }
//line :227:1
		break L1 } }
//line :201:1
	return this
}































func (t *IntBuffer) Impl_HasArray__Z(this IntBuffer_I) bool {
	var tmp1 bool; tmp1 = !(t.F_hb == nil); if tmp1 { tmp1 = !t.F_isReadOnly }; return tmp1
}
func (t *IntBuffer) Impl_Array__I1(this IntBuffer_I) *IntArray {
	if t.F_hb == nil { panic(Thrown(UnsupportedOperationException_New())) }
	if t.F_isReadOnly { panic(Thrown(ReadOnlyBufferException_New())) }
//line :237:1
	return t.F_hb
}



func (t *IntBuffer) Impl_ArrayOffset__I(this IntBuffer_I) int32 {
	if t.F_hb == nil { panic(Thrown(UnsupportedOperationException_New())) }
	if t.F_isReadOnly { panic(Thrown(ReadOnlyBufferException_New())) }
//line :242:1
	return t.F_offset
}



func (t *IntBuffer) Impl_Position_I__IntBuffer(this IntBuffer_I, newPosition int32) IntBuffer_I {
	t.Buffer.Impl_Position_I__Buffer(this, newPosition)
//line :247:1
	return this
}


func (t *IntBuffer) Impl_Limit_I__IntBuffer(this IntBuffer_I, newLimit int32) IntBuffer_I {
	t.Buffer.Impl_Limit_I__Buffer(this, newLimit)
//line :251:1
	return this
}


func (t *IntBuffer) Impl_Mark__IntBuffer(this IntBuffer_I) IntBuffer_I { t.Buffer.Impl_Mark__Buffer(this); return this }

func (t *IntBuffer) Impl_Reset__IntBuffer(this IntBuffer_I) IntBuffer_I { t.Buffer.Impl_Reset__Buffer(this); return this }

func (t *IntBuffer) Impl_Clear__IntBuffer(this IntBuffer_I) IntBuffer_I { t.Buffer.Impl_Clear__Buffer(this); return this }

func (t *IntBuffer) Impl_Flip__IntBuffer(this IntBuffer_I) IntBuffer_I { t.Buffer.Impl_Flip__Buffer(this); return this }

func (t *IntBuffer) Impl_Rewind__IntBuffer(this IntBuffer_I) IntBuffer_I { t.Buffer.Impl_Rewind__Buffer(this); return this }





func (t *IntBuffer) Impl_ToString__String(this IntBuffer_I) *String {
	return Concat(NN(this.GetClass__Class()).GetName__String(), Lit_1487, StrOfInt(this.Position__I()), Lit_1488, StrOfInt(this.Limit__I()), Lit_1489, StrOfInt(this.Capacity__I()), Lit_1189)
}







func (t *IntBuffer) Impl_HashCode__I(this IntBuffer_I) int32 {
	var h int32 = 1; var p int32 = this.Position__I(); var i int32 = this.Limit__I() - 1

L1: for {
	if i >= p {
		h = 31*h + this.Get_I__I(i)
		i = i - 1; continue L1 }
//line :282:1
	break L1 }
//line :280:1
	return h
}






func (t *IntBuffer) Impl_Equals_O__Z(this IntBuffer_I, ob any) bool {
	if any(this) == any(ob) { return true } else { if !IntBuffer_InstanceOf(ob) { return false } else {



		var that IntBuffer_I = IntBuffer_Cast(ob); var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var tmp1 bool; var tmp2 bool




		tmp2 = thisRem < 0; if !tmp2 { tmp2 = !(thisRem == thatRem) }; tmp1 = tmp2; if tmp1 { return false } else {

			return A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world") < 0
		} } } }
func (t *IntBuffer) Impl_CompareTo_IntBuffer__I(this, that IntBuffer_I) int32 {
	var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var length int32 = Math_Min_I_I__I(thisRem, thatRem)




	if length < 0 { return -1 } else {

		var i int32; i = A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world")
		if i >= 0 {
			return IntBuffer_Compare_I_I__I(this.Get_I__I(thisPos+i), that.Get_I__I(thatPos+i)) } else {

				return thisRem - thatRem
			} } }
func IntBuffer_Compare_I_I__I(x, y int32) int32 { IntBuffer_Init()
	return Integer_Compare_I_I__I(x, y)
}
func (t *IntBuffer) Impl_Mismatch_IntBuffer__I(this, that IntBuffer_I) int32 {
	var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var length int32 = Math_Min_I_I__I(thisRem, thatRem)




	if length < 0 { return -1 } else {

		var r int32; r = A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world")
		var tmp1 bool; var tmp2 bool; tmp2 = r == -1; if tmp2 { tmp2 = !(thisRem == thatRem) }; tmp1 = tmp2; if tmp1 { return length } else { return r
		}
	}
}
func (t *IntBuffer) Impl_ScaleShifts__I(this IntBuffer_I) int32 { panic(A2g_NotTranslated("java.nio.IntBuffer.scaleShifts()I")) }



type IntBuffer struct{ Buffer; F_hb *IntArray; F_offset int32; F_isReadOnly bool }

type IntBuffer_I interface{ Buffer_I; Comparable; Self_IntBuffer() *IntBuffer; Base__O() any; Slice__IntBuffer() IntBuffer_I; Slice_I_I__IntBuffer(p0, p1 int32) IntBuffer_I; Duplicate__IntBuffer() IntBuffer_I; AsReadOnlyBuffer__IntBuffer() IntBuffer_I; Get__I() int32; Put_I__IntBuffer(p0 int32) IntBuffer_I; Get_I__I(p0 int32) int32; Put_I_I__IntBuffer(p0, p1 int32) IntBuffer_I; Get_I1_I_I__IntBuffer(p0 *IntArray, p1, p2 int32) IntBuffer_I; Get_I1__IntBuffer(p0 *IntArray) IntBuffer_I; Get_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I; Get_I_I1__IntBuffer(p0 int32, p1 *IntArray) IntBuffer_I; GetArray_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I; Put_IntBuffer__IntBuffer(p0 IntBuffer_I) IntBuffer_I; Put_I_IntBuffer_I_I__IntBuffer(p0 int32, p1 IntBuffer_I, p2, p3 int32) IntBuffer_I; PutBuffer_I_IntBuffer_I_I__V(p0 int32, p1 IntBuffer_I, p2, p3 int32); Put_I1_I_I__IntBuffer(p0 *IntArray, p1, p2 int32) IntBuffer_I; Put_I1__IntBuffer(p0 *IntArray) IntBuffer_I; Put_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I; Put_I_I1__IntBuffer(p0 int32, p1 *IntArray) IntBuffer_I; PutArray_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I; HasArray__Z() bool; Array__I1() *IntArray; ArrayOffset__I() int32; Position_I__IntBuffer(p0 int32) IntBuffer_I; Limit_I__IntBuffer(p0 int32) IntBuffer_I; Mark__IntBuffer() IntBuffer_I; Reset__IntBuffer() IntBuffer_I; Clear__IntBuffer() IntBuffer_I; Flip__IntBuffer() IntBuffer_I; Rewind__IntBuffer() IntBuffer_I; Compact__IntBuffer() IntBuffer_I; IsDirect__Z() bool; CompareTo_IntBuffer__I(p0 IntBuffer_I) int32; Mismatch_IntBuffer__I(p0 IntBuffer_I) int32; Order__ByteOrder() *ByteOrder; ScaleShifts__I() int32; Position_I__Buffer(p0 int32) Buffer_I; Limit_I__Buffer(p0 int32) Buffer_I; Mark__Buffer() Buffer_I; Reset__Buffer() Buffer_I; Clear__Buffer() Buffer_I; Flip__Buffer() Buffer_I; Rewind__Buffer() Buffer_I; Array__O() any; Slice__Buffer() Buffer_I; Slice_I_I__Buffer(p0, p1 int32) Buffer_I; Duplicate__Buffer() Buffer_I; CompareTo_O__I(p0 any) int32 }

func (t *IntBuffer) Self_IntBuffer() *IntBuffer { return t }

func (t *IntBuffer) Is_Comparable() {}

var IntBuffer_ARRAY_BASE_OFFSET int64

var IntBuffer_init ClassInit

func IntBuffer_Init() { if !IntBuffer_init.Done() { IntBuffer_init.Run(IntBuffer_clinit) } }

func IntBuffer_clinit() { Buffer_Init(); IntBuffer_ARRAY_BASE_OFFSET = NN(Buffer_UNSAFE).ArrayBaseOffset_Class__J(Prim_int.ArrayClass()) }

func (t *IntBuffer) Impl_Position_I__Buffer(this IntBuffer_I, p0 int32) Buffer_I { return this.Position_I__IntBuffer(p0) }

func (t *IntBuffer) Impl_Limit_I__Buffer(this IntBuffer_I, p0 int32) Buffer_I { return this.Limit_I__IntBuffer(p0) }

func (t *IntBuffer) Impl_Mark__Buffer(this IntBuffer_I) Buffer_I { return this.Mark__IntBuffer() }

func (t *IntBuffer) Impl_Reset__Buffer(this IntBuffer_I) Buffer_I { return this.Reset__IntBuffer() }

func (t *IntBuffer) Impl_Clear__Buffer(this IntBuffer_I) Buffer_I { return this.Clear__IntBuffer() }

func (t *IntBuffer) Impl_Flip__Buffer(this IntBuffer_I) Buffer_I { return this.Flip__IntBuffer() }

func (t *IntBuffer) Impl_Rewind__Buffer(this IntBuffer_I) Buffer_I { return this.Rewind__IntBuffer() }

func (t *IntBuffer) Impl_Array__O(this IntBuffer_I) any { return this.Array__I1().Ref() }

func (t *IntBuffer) Impl_Slice__Buffer(this IntBuffer_I) Buffer_I { return this.Slice__IntBuffer() }

func (t *IntBuffer) Impl_Slice_I_I__Buffer(this IntBuffer_I, p0, p1 int32) Buffer_I { return this.Slice_I_I__IntBuffer(p0, p1) }

func (t *IntBuffer) Impl_Duplicate__Buffer(this IntBuffer_I) Buffer_I { return this.Duplicate__IntBuffer() }

func (t *IntBuffer) Impl_CompareTo_O__I(this IntBuffer_I, p0 any) int32 { return this.CompareTo_IntBuffer__I(IntBuffer_Cast(p0)) }

func IntBuffer_InstanceOf(x any) bool { _, ok := x.(IntBuffer_I); return ok }

func IntBuffer_Cast(x any) IntBuffer_I { if x == nil { return nil }; v, ok := x.(IntBuffer_I); if !ok { panic(ClassCast(x, IntBuffer_class)) }; return v }
