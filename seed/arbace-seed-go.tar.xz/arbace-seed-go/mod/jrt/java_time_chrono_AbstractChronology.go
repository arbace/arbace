//line java_time_chrono_AbstractChronology.ae:1
package jrt










func AbstractChronology_InitCache__Z() bool { AbstractChronology_Init()
	if NN(AbstractChronology_CHRONOS_BY_ID).Get_O__O(Lit_2175) == nil {

		var tmp1 *IsoChronology; IsoChronology_Init(); tmp1 = IsoChronology_INSTANCE; AbstractChronology_RegisterChrono_Chronology__Chronology(Up_IsoChronology_Chronology(tmp1))
//line :14:1
		return true } else {
//line :13:1
			return false
		}
}



func AbstractChronology_OfLocale_Locale__Chronology(locale *Locale) Chronology { AbstractChronology_Init()
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	var type_ *String = NN(locale).GetUnicodeLocaleType_String__String(Lit_2177); var tmp1 bool; var tmp2 bool
	tmp2 = type_ == nil; if !tmp2 { tmp2 = Lit_2178.Equals_O__Z(type_.Ref()); if !tmp2 { tmp2 = Lit_2179.Equals_O__Z(type_.Ref()) } }; tmp1 = tmp2; if tmp1 { IsoChronology_Init(); return Up_IsoChronology_Chronology(IsoChronology_INSTANCE) } else {


	L1: for {
		var chrono Chronology = Chronology_Cast(NN(AbstractChronology_CHRONOS_BY_TYPE).Get_O__O(type_.Ref()))
		if !(chrono == nil) {
			return chrono }
		if AbstractChronology_InitCache__Z() {
			continue L1 }
//line :25:1
		break L1
	}




		panic(Thrown(DateTimeException_New_String(Concat(Lit_2180, type_)))) } }
//line :28:1
func AbstractChronology_RegisterChrono_Chronology__Chronology(chrono Chronology) Chronology { AbstractChronology_Init()
	return AbstractChronology_RegisterChrono_Chronology_String__Chronology(chrono, chrono.GetId__String())
}
func AbstractChronology_RegisterChrono_Chronology_String__Chronology(chrono Chronology, id *String) Chronology { AbstractChronology_Init()
	var prev Chronology = Chronology_Cast(NN(AbstractChronology_CHRONOS_BY_ID).PutIfAbsent_O_O__O(id.Ref(), chrono))
	if prev == nil {
		var type_ *String = chrono.GetCalendarType__String()
		if !(type_ == nil) { NN(AbstractChronology_CHRONOS_BY_TYPE).PutIfAbsent_O_O__O(type_.Ref(), chrono) } }
//line :32:1
	return prev }
func AbstractChronology_Of_String__Chronology(id *String) Chronology { AbstractChronology_Init()
	Objects_RequireNonNull_O_String__O(id.Ref(), Lit_2181)
L1: for {
	var chrono Chronology = AbstractChronology_Of0_String__Chronology(id)
	if !(chrono == nil) {
		return chrono }
	if AbstractChronology_InitCache__Z() {
		continue L1 }
//line :35:1
	break L1
}




	panic(Thrown(DateTimeException_New_String(Concat(Lit_2182, id))))
}
func AbstractChronology_GetAvailableChronologies__Set() Set { AbstractChronology_Init()
	AbstractChronology_InitCache__Z()
	return HashSet_New_Collection(NN(AbstractChronology_CHRONOS_BY_ID).Values__Collection())
}







































func AbstractChronology_Of0_String__Chronology(id *String) Chronology { AbstractChronology_Init()
	var chrono Chronology = Chronology_Cast(NN(AbstractChronology_CHRONOS_BY_ID).Get_O__O(id.Ref()))
	if chrono == nil { chrono = Chronology_Cast(NN(AbstractChronology_CHRONOS_BY_TYPE).Get_O__O(id.Ref())) }
//line :87:1
	return chrono
}









func (t *AbstractChronology) Ctor(this AbstractChronology_I) {}

func (t *AbstractChronology) Impl_ResolveDate_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, fieldValues Map, resolverStyle *ResolverStyle) ChronoLocalDate {

	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; if fieldValues.ContainsKey_O__Z(tmp1.Ref()) {
		var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_EPOCH_DAY; return this.DateEpochDay_J__ChronoLocalDate(NN(Long_Cast(fieldValues.Remove_O__O(tmp2.Ref()))).LongValue__J()) } else {

			this.ResolveProlepticMonth_Map_ResolverStyle__V(fieldValues, resolverStyle)
			var resolved ChronoLocalDate = this.ResolveYearOfEra_Map_ResolverStyle__ChronoLocalDate(fieldValues, resolverStyle)
			if !(resolved == nil) { return resolved } else {


				var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; if fieldValues.ContainsKey_O__Z(tmp3.Ref()) {
					var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_MONTH_OF_YEAR; if fieldValues.ContainsKey_O__Z(tmp4.Ref()) {
						var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_DAY_OF_MONTH; if fieldValues.ContainsKey_O__Z(tmp5.Ref()) {
							return this.ResolveYMD_Map_ResolverStyle__ChronoLocalDate(fieldValues, resolverStyle) }
						var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_ALIGNED_WEEK_OF_MONTH; if fieldValues.ContainsKey_O__Z(tmp6.Ref()) {
							var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH; if fieldValues.ContainsKey_O__Z(tmp7.Ref()) {
								return this.ResolveYMAA_Map_ResolverStyle__ChronoLocalDate(fieldValues, resolverStyle) }
							var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_DAY_OF_WEEK; if fieldValues.ContainsKey_O__Z(tmp8.Ref()) {
								return this.ResolveYMAD_Map_ResolverStyle__ChronoLocalDate(fieldValues, resolverStyle) } } }
					var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_DAY_OF_YEAR; if fieldValues.ContainsKey_O__Z(tmp9.Ref()) {
						return this.ResolveYD_Map_ResolverStyle__ChronoLocalDate(fieldValues, resolverStyle) }
					var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_ALIGNED_WEEK_OF_YEAR; if fieldValues.ContainsKey_O__Z(tmp10.Ref()) {
						var tmp11 *ChronoField; ChronoField_Init(); tmp11 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR; if fieldValues.ContainsKey_O__Z(tmp11.Ref()) {
							return this.ResolveYAA_Map_ResolverStyle__ChronoLocalDate(fieldValues, resolverStyle) }
						var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_DAY_OF_WEEK; if fieldValues.ContainsKey_O__Z(tmp12.Ref()) {
							return this.ResolveYAD_Map_ResolverStyle__ChronoLocalDate(fieldValues, resolverStyle) } } }
//line :109:1
				return nil
			}
		}
}















func (t *AbstractChronology) Impl_ResolveProlepticMonth_Map_ResolverStyle__V(this AbstractChronology_I, p0 Map, p1 *ResolverStyle) { panic(A2g_NotTranslated("java.time.chrono.AbstractChronology.resolveProlepticMonth(Ljava/util/Map;Ljava/time/format/ResolverStyle;)V")) }














func (t *AbstractChronology) Impl_ResolveYearOfEra_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, p0 Map, p1 *ResolverStyle) ChronoLocalDate { panic(A2g_NotTranslated("java.time.chrono.AbstractChronology.resolveYearOfEra(Ljava/util/Map;Ljava/time/format/ResolverStyle;)Ljava/time/chrono/ChronoLocalDate;")) }

















































func (t *AbstractChronology) Impl_ResolveYMD_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, p0 Map, p1 *ResolverStyle) ChronoLocalDate { panic(A2g_NotTranslated("java.time.chrono.AbstractChronology.resolveYMD(Ljava/util/Map;Ljava/time/format/ResolverStyle;)Ljava/time/chrono/ChronoLocalDate;")) }
































func (t *AbstractChronology) Impl_ResolveYD_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, fieldValues Map, resolverStyle *ResolverStyle) ChronoLocalDate {

	var y int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ValueRange = this.Range_ChronoField__ValueRange(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; var tmp4 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp3.Ref()))).LongValue__J(); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; y = NN(tmp2).CheckValidIntValue_J_TemporalField__I(tmp4, Up_ChronoField_TemporalField(tmp5))


	var tmp6 *ResolverStyle; ResolverStyle_Init(); tmp6 = ResolverStyle_LENIENT; if resolverStyle == tmp6 {
		var days int64; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_DAY_OF_YEAR; days = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp7.Ref()))).LongValue__J(), 1)


		var tmp8 ChronoLocalDate = this.DateYearDay_I_I__ChronoLocalDate(y, 1); var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_DAYS; return tmp8.Plus_J_TemporalUnit__ChronoLocalDate(days, Up_ChronoUnit_TemporalUnit(tmp9)) } else {
			var doy int32; var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_DAY_OF_YEAR; var tmp11 *ValueRange = this.Range_ChronoField__ValueRange(tmp10); var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_DAY_OF_YEAR; var tmp13 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp12.Ref()))).LongValue__J(); var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_DAY_OF_YEAR; doy = NN(tmp11).CheckValidIntValue_J_TemporalField__I(tmp13, Up_ChronoField_TemporalField(tmp14))



			return this.DateYearDay_I_I__ChronoLocalDate(y, doy)
		} }
func (t *AbstractChronology) Impl_ResolveYMAA_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, fieldValues Map, resolverStyle *ResolverStyle) ChronoLocalDate {

	var y int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ValueRange = this.Range_ChronoField__ValueRange(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; var tmp4 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp3.Ref()))).LongValue__J(); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; y = NN(tmp2).CheckValidIntValue_J_TemporalField__I(tmp4, Up_ChronoField_TemporalField(tmp5))


	var tmp6 *ResolverStyle; ResolverStyle_Init(); tmp6 = ResolverStyle_LENIENT; if resolverStyle == tmp6 {
		var months int64; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_MONTH_OF_YEAR; months = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp7.Ref()))).LongValue__J(), 1); var weeks int64; var tmp8 *ChronoField


		ChronoField_Init(); tmp8 = ChronoField_ALIGNED_WEEK_OF_MONTH; weeks = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp8.Ref()))).LongValue__J(), 1)
//line :248:1
		var days int64; var tmp9 *ChronoField






		ChronoField_Init(); tmp9 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH; days = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp9.Ref()))).LongValue__J(), 1)





		var tmp10 ChronoLocalDate = this.Date_I_I_I__ChronoLocalDate(y, 1, 1); var tmp11 *ChronoUnit; ChronoUnit_Init(); tmp11 = ChronoUnit_MONTHS; var tmp12 ChronoLocalDate = tmp10.Plus_J_TemporalUnit__ChronoLocalDate(months, Up_ChronoUnit_TemporalUnit(tmp11)); var tmp13 *ChronoUnit; ChronoUnit_Init(); tmp13 = ChronoUnit_WEEKS; var tmp14 ChronoLocalDate = tmp12.Plus_J_TemporalUnit__ChronoLocalDate(weeks, Up_ChronoUnit_TemporalUnit(tmp13)); var tmp15 *ChronoUnit; ChronoUnit_Init(); tmp15 = ChronoUnit_DAYS; return tmp14.Plus_J_TemporalUnit__ChronoLocalDate(days, Up_ChronoUnit_TemporalUnit(tmp15)) } else {




			var moy int32; var tmp16 *ChronoField; ChronoField_Init(); tmp16 = ChronoField_MONTH_OF_YEAR; var tmp17 *ValueRange = this.Range_ChronoField__ValueRange(tmp16); var tmp18 *ChronoField; ChronoField_Init(); tmp18 = ChronoField_MONTH_OF_YEAR; var tmp19 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp18.Ref()))).LongValue__J(); var tmp20 *ChronoField; ChronoField_Init(); tmp20 = ChronoField_MONTH_OF_YEAR; moy = NN(tmp17).CheckValidIntValue_J_TemporalField__I(tmp19, Up_ChronoField_TemporalField(tmp20)); var aw int32; var tmp21 *ChronoField





			ChronoField_Init(); tmp21 = ChronoField_ALIGNED_WEEK_OF_MONTH; var tmp22 *ValueRange = this.Range_ChronoField__ValueRange(tmp21); var tmp23 *ChronoField; ChronoField_Init(); tmp23 = ChronoField_ALIGNED_WEEK_OF_MONTH; var tmp24 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp23.Ref()))).LongValue__J(); var tmp25 *ChronoField; ChronoField_Init(); tmp25 = ChronoField_ALIGNED_WEEK_OF_MONTH; aw = NN(tmp22).CheckValidIntValue_J_TemporalField__I(tmp24, Up_ChronoField_TemporalField(tmp25))
//line :266:1
			var ad int32; var tmp26 *ChronoField












			ChronoField_Init(); tmp26 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH; var tmp27 *ValueRange = this.Range_ChronoField__ValueRange(tmp26); var tmp28 *ChronoField; ChronoField_Init(); tmp28 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH; var tmp29 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp28.Ref()))).LongValue__J(); var tmp30 *ChronoField; ChronoField_Init(); tmp30 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH; ad = NN(tmp27).CheckValidIntValue_J_TemporalField__I(tmp29, Up_ChronoField_TemporalField(tmp30))
//line :266:1
			var date ChronoLocalDate; var tmp31 ChronoLocalDate = this.Date_I_I_I__ChronoLocalDate(y, moy, 1); var tmp32 int64 = int64((aw-1)*7 + (ad - 1)); var tmp33 *ChronoUnit



















			ChronoUnit_Init(); tmp33 = ChronoUnit_DAYS; date = tmp31.Plus_J_TemporalUnit__ChronoLocalDate(tmp32, Up_ChronoUnit_TemporalUnit(tmp33))




			var tmp34 bool; var tmp35 bool; var tmp36 *ResolverStyle; ResolverStyle_Init(); tmp36 = ResolverStyle_STRICT; tmp35 = resolverStyle == tmp36; if tmp35 {
				var tmp37 *ChronoField; ChronoField_Init(); tmp37 = ChronoField_MONTH_OF_YEAR; tmp35 = !(date.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp37)) == moy) }
//line :291:1
			tmp34 = tmp35; if tmp34 {

				panic(Thrown(DateTimeException_New_String(Lit_2183))) }
//line :266:1
			return date
		}
}




























func (t *AbstractChronology) Impl_ResolveYMAD_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, fieldValues Map, resolverStyle *ResolverStyle) ChronoLocalDate {

	var y int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ValueRange = this.Range_ChronoField__ValueRange(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; var tmp4 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp3.Ref()))).LongValue__J(); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; y = NN(tmp2).CheckValidIntValue_J_TemporalField__I(tmp4, Up_ChronoField_TemporalField(tmp5))


	var tmp6 *ResolverStyle; ResolverStyle_Init(); tmp6 = ResolverStyle_LENIENT; if resolverStyle == tmp6 {
		var months int64; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_MONTH_OF_YEAR; months = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp7.Ref()))).LongValue__J(), 1); var weeks int64; var tmp8 *ChronoField


		ChronoField_Init(); tmp8 = ChronoField_ALIGNED_WEEK_OF_MONTH; weeks = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp8.Ref()))).LongValue__J(), 1)
//line :303:1
		var dow int64; var tmp9 *ChronoField






		ChronoField_Init(); tmp9 = ChronoField_DAY_OF_WEEK; dow = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp9.Ref()))).LongValue__J(), 1)


		return this.ResolveAligned_ChronoLocalDate_J_J_J__ChronoLocalDate(this.Date_I_I_I__ChronoLocalDate(y, 1, 1), months, weeks, dow) } else {
			var moy int32; var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_MONTH_OF_YEAR; var tmp11 *ValueRange = this.Range_ChronoField__ValueRange(tmp10); var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_MONTH_OF_YEAR; var tmp13 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp12.Ref()))).LongValue__J(); var tmp14 *ChronoField; ChronoField_Init(); tmp14 = ChronoField_MONTH_OF_YEAR; moy = NN(tmp11).CheckValidIntValue_J_TemporalField__I(tmp13, Up_ChronoField_TemporalField(tmp14)); var aw int32; var tmp15 *ChronoField





			ChronoField_Init(); tmp15 = ChronoField_ALIGNED_WEEK_OF_MONTH; var tmp16 *ValueRange = this.Range_ChronoField__ValueRange(tmp15); var tmp17 *ChronoField; ChronoField_Init(); tmp17 = ChronoField_ALIGNED_WEEK_OF_MONTH; var tmp18 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp17.Ref()))).LongValue__J(); var tmp19 *ChronoField; ChronoField_Init(); tmp19 = ChronoField_ALIGNED_WEEK_OF_MONTH; aw = NN(tmp16).CheckValidIntValue_J_TemporalField__I(tmp18, Up_ChronoField_TemporalField(tmp19))
//line :314:1
			var dow_2 int32; var tmp20 *ChronoField












			ChronoField_Init(); tmp20 = ChronoField_DAY_OF_WEEK; var tmp21 *ValueRange = this.Range_ChronoField__ValueRange(tmp20); var tmp22 *ChronoField; ChronoField_Init(); tmp22 = ChronoField_DAY_OF_WEEK; var tmp23 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp22.Ref()))).LongValue__J(); var tmp24 *ChronoField; ChronoField_Init(); tmp24 = ChronoField_DAY_OF_WEEK; dow_2 = NN(tmp21).CheckValidIntValue_J_TemporalField__I(tmp23, Up_ChronoField_TemporalField(tmp24))
//line :314:1
			var date ChronoLocalDate; var tmp25 ChronoLocalDate = this.Date_I_I_I__ChronoLocalDate(y, moy, 1); var tmp26 int64 = int64((aw - 1) * 7); var tmp27 *ChronoUnit
















			ChronoUnit_Init(); tmp27 = ChronoUnit_DAYS; date = tmp25.Plus_J_TemporalUnit__ChronoLocalDate(tmp26, Up_ChronoUnit_TemporalUnit(tmp27)).With_TemporalAdjuster__ChronoLocalDate(TemporalAdjusters_NextOrSame_DayOfWeek__TemporalAdjuster(DayOfWeek_Of_I__DayOfWeek(dow_2)))



			var tmp28 bool; var tmp29 bool; var tmp30 *ResolverStyle; ResolverStyle_Init(); tmp30 = ResolverStyle_STRICT; tmp29 = resolverStyle == tmp30; if tmp29 {
				var tmp31 *ChronoField; ChronoField_Init(); tmp31 = ChronoField_MONTH_OF_YEAR; tmp29 = !(date.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp31)) == moy) }
//line :335:1
			tmp28 = tmp29; if tmp28 {

				panic(Thrown(DateTimeException_New_String(Lit_2183))) }
//line :314:1
			return date
		}
}
























func (t *AbstractChronology) Impl_ResolveYAA_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, fieldValues Map, resolverStyle *ResolverStyle) ChronoLocalDate {

	var y int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ValueRange = this.Range_ChronoField__ValueRange(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; var tmp4 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp3.Ref()))).LongValue__J(); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; y = NN(tmp2).CheckValidIntValue_J_TemporalField__I(tmp4, Up_ChronoField_TemporalField(tmp5))


	var tmp6 *ResolverStyle; ResolverStyle_Init(); tmp6 = ResolverStyle_LENIENT; if resolverStyle == tmp6 {
		var weeks int64; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_ALIGNED_WEEK_OF_YEAR; weeks = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp7.Ref()))).LongValue__J(), 1); var days int64; var tmp8 *ChronoField



		ChronoField_Init(); tmp8 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR; days = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp8.Ref()))).LongValue__J(), 1)





		var tmp9 ChronoLocalDate = this.DateYearDay_I_I__ChronoLocalDate(y, 1); var tmp10 *ChronoUnit; ChronoUnit_Init(); tmp10 = ChronoUnit_WEEKS; var tmp11 ChronoLocalDate = tmp9.Plus_J_TemporalUnit__ChronoLocalDate(weeks, Up_ChronoUnit_TemporalUnit(tmp10)); var tmp12 *ChronoUnit; ChronoUnit_Init(); tmp12 = ChronoUnit_DAYS; return tmp11.Plus_J_TemporalUnit__ChronoLocalDate(days, Up_ChronoUnit_TemporalUnit(tmp12)) } else {
			var aw int32; var tmp13 *ChronoField; ChronoField_Init(); tmp13 = ChronoField_ALIGNED_WEEK_OF_YEAR; var tmp14 *ValueRange = this.Range_ChronoField__ValueRange(tmp13); var tmp15 *ChronoField; ChronoField_Init(); tmp15 = ChronoField_ALIGNED_WEEK_OF_YEAR; var tmp16 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp15.Ref()))).LongValue__J(); var tmp17 *ChronoField; ChronoField_Init(); tmp17 = ChronoField_ALIGNED_WEEK_OF_YEAR; aw = NN(tmp14).CheckValidIntValue_J_TemporalField__I(tmp16, Up_ChronoField_TemporalField(tmp17)); var ad int32; var tmp18 *ChronoField






			ChronoField_Init(); tmp18 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR; var tmp19 *ValueRange = this.Range_ChronoField__ValueRange(tmp18); var tmp20 *ChronoField; ChronoField_Init(); tmp20 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR; var tmp21 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp20.Ref()))).LongValue__J(); var tmp22 *ChronoField; ChronoField_Init(); tmp22 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR; ad = NN(tmp19).CheckValidIntValue_J_TemporalField__I(tmp21, Up_ChronoField_TemporalField(tmp22))
//line :358:1
			var date ChronoLocalDate; var tmp23 ChronoLocalDate = this.DateYearDay_I_I__ChronoLocalDate(y, 1); var tmp24 int64 = int64((aw-1)*7 + (ad - 1)); var tmp25 *ChronoUnit













			ChronoUnit_Init(); tmp25 = ChronoUnit_DAYS; date = tmp23.Plus_J_TemporalUnit__ChronoLocalDate(tmp24, Up_ChronoUnit_TemporalUnit(tmp25))




			var tmp26 bool; var tmp27 bool; var tmp28 *ResolverStyle; ResolverStyle_Init(); tmp28 = ResolverStyle_STRICT; tmp27 = resolverStyle == tmp28; if tmp27 {
				var tmp29 *ChronoField; ChronoField_Init(); tmp29 = ChronoField_YEAR; tmp27 = !(date.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp29)) == y) }
//line :377:1
			tmp26 = tmp27; if tmp26 {

				panic(Thrown(DateTimeException_New_String(Lit_2184))) }
//line :358:1
			return date
		}
}






















func (t *AbstractChronology) Impl_ResolveYAD_Map_ResolverStyle__ChronoLocalDate(this AbstractChronology_I, fieldValues Map, resolverStyle *ResolverStyle) ChronoLocalDate {

	var y int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ValueRange = this.Range_ChronoField__ValueRange(tmp1); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_YEAR; var tmp4 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp3.Ref()))).LongValue__J(); var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_YEAR; y = NN(tmp2).CheckValidIntValue_J_TemporalField__I(tmp4, Up_ChronoField_TemporalField(tmp5))


	var tmp6 *ResolverStyle; ResolverStyle_Init(); tmp6 = ResolverStyle_LENIENT; if resolverStyle == tmp6 {
		var weeks int64; var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_ALIGNED_WEEK_OF_YEAR; weeks = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp7.Ref()))).LongValue__J(), 1); var dow int64; var tmp8 *ChronoField



		ChronoField_Init(); tmp8 = ChronoField_DAY_OF_WEEK; dow = Math_SubtractExact_J_J__J(NN(Long_Cast(fieldValues.Remove_O__O(tmp8.Ref()))).LongValue__J(), 1)


		return this.ResolveAligned_ChronoLocalDate_J_J_J__ChronoLocalDate(this.DateYearDay_I_I__ChronoLocalDate(y, 1), 0, weeks, dow) } else {
			var aw int32; var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_ALIGNED_WEEK_OF_YEAR; var tmp10 *ValueRange = this.Range_ChronoField__ValueRange(tmp9); var tmp11 *ChronoField; ChronoField_Init(); tmp11 = ChronoField_ALIGNED_WEEK_OF_YEAR; var tmp12 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp11.Ref()))).LongValue__J(); var tmp13 *ChronoField; ChronoField_Init(); tmp13 = ChronoField_ALIGNED_WEEK_OF_YEAR; aw = NN(tmp10).CheckValidIntValue_J_TemporalField__I(tmp12, Up_ChronoField_TemporalField(tmp13)); var dow_2 int32; var tmp14 *ChronoField






			ChronoField_Init(); tmp14 = ChronoField_DAY_OF_WEEK; var tmp15 *ValueRange = this.Range_ChronoField__ValueRange(tmp14); var tmp16 *ChronoField; ChronoField_Init(); tmp16 = ChronoField_DAY_OF_WEEK; var tmp17 int64 = NN(Long_Cast(fieldValues.Remove_O__O(tmp16.Ref()))).LongValue__J(); var tmp18 *ChronoField; ChronoField_Init(); tmp18 = ChronoField_DAY_OF_WEEK; dow_2 = NN(tmp15).CheckValidIntValue_J_TemporalField__I(tmp17, Up_ChronoField_TemporalField(tmp18))
//line :397:1
			var date ChronoLocalDate; var tmp19 ChronoLocalDate = this.DateYearDay_I_I__ChronoLocalDate(y, 1); var tmp20 int64 = int64((aw - 1) * 7); var tmp21 *ChronoUnit










			ChronoUnit_Init(); tmp21 = ChronoUnit_DAYS; date = tmp19.Plus_J_TemporalUnit__ChronoLocalDate(tmp20, Up_ChronoUnit_TemporalUnit(tmp21)).With_TemporalAdjuster__ChronoLocalDate(TemporalAdjusters_NextOrSame_DayOfWeek__TemporalAdjuster(DayOfWeek_Of_I__DayOfWeek(dow_2)))



			var tmp22 bool; var tmp23 bool; var tmp24 *ResolverStyle; ResolverStyle_Init(); tmp24 = ResolverStyle_STRICT; tmp23 = resolverStyle == tmp24; if tmp23 {
				var tmp25 *ChronoField; ChronoField_Init(); tmp25 = ChronoField_YEAR; tmp23 = !(date.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp25)) == y) }
//line :412:1
			tmp22 = tmp23; if tmp22 {

				panic(Thrown(DateTimeException_New_String(Lit_2184))) }
//line :397:1
			return date
		}
}


















func (t *AbstractChronology) Impl_ResolveAligned_ChronoLocalDate_J_J_J__ChronoLocalDate(this AbstractChronology_I, base ChronoLocalDate, months, weeks, dow int64) ChronoLocalDate {

	var date ChronoLocalDate; var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_MONTHS; var tmp2 ChronoLocalDate = base.Plus_J_TemporalUnit__ChronoLocalDate(months, Up_ChronoUnit_TemporalUnit(tmp1)); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_WEEKS; date = tmp2.Plus_J_TemporalUnit__ChronoLocalDate(weeks, Up_ChronoUnit_TemporalUnit(tmp3))
	if dow > 7 {

		var tmp4 ChronoLocalDate = date; var tmp5 int64 = (dow - 1) / 7; var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_WEEKS; date = tmp4.Plus_J_TemporalUnit__ChronoLocalDate(tmp5, Up_ChronoUnit_TemporalUnit(tmp6))

		dow = (dow-1)%7 + 1 } else {
			if dow < 1 {
				var tmp7 ChronoLocalDate = date; var tmp8 int64 = Math_SubtractExact_J_J__J(dow, 7) / 7; var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_WEEKS; date = tmp7.Plus_J_TemporalUnit__ChronoLocalDate(tmp8, Up_ChronoUnit_TemporalUnit(tmp9))

				dow = (dow+6)%7 + 1 } }
	return date.With_TemporalAdjuster__ChronoLocalDate(TemporalAdjusters_NextOrSame_DayOfWeek__TemporalAdjuster(DayOfWeek_Of_I__DayOfWeek(int32(dow))))
}
func (t *AbstractChronology) Impl_AddFieldValue_Map_ChronoField_J__V(this AbstractChronology_I, fieldValues Map, field *ChronoField, value int64) {

	var old *Long = Long_Cast(fieldValues.Get_O__O(field.Ref())); var tmp1 bool; var tmp2 bool
	tmp2 = !(old == nil); if tmp2 { tmp2 = !(NN(old).LongValue__J() == value) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2185, StrOfObj(field.Ref()), Lit_115, StrOfObj(old.Ref()), Lit_2186, StrOfObj(field.Ref()), Lit_115, StrOfLong(value)))))
	}
	fieldValues.Put_O_O__O(field.Ref(), Long_ValueOf_J__Long(value))
}
func (t *AbstractChronology) Impl_CompareTo_Chronology__I(this AbstractChronology_I, other Chronology) int32 {
	return NN(this.GetId__String()).CompareTo_String__I(other.GetId__String())
}
func (t *AbstractChronology) Impl_Equals_O__Z(this AbstractChronology_I, obj any) bool {
	if any(this) == any(obj) { return true } else { if AbstractChronology_InstanceOf(obj) {

		return this.CompareTo_Chronology__I(AbstractChronology_Cast(obj)) == 0 } else {
//line :444:1
			return false
		}
	}
}

func (t *AbstractChronology) Impl_HashCode__I(this AbstractChronology_I) int32 {
	return NN(this.GetClass__Class()).HashCode__I() ^ NN(this.GetId__String()).HashCode__I()
}
func (t *AbstractChronology) Impl_ToString__String(this AbstractChronology_I) *String { return this.GetId__String() }

func (t *AbstractChronology) Impl_WriteReplace__O(this AbstractChronology_I) any { panic(A2g_NotTranslated("java.time.chrono.AbstractChronology.writeReplace()Ljava/lang/Object;")) }








func AbstractChronology_ReadExternal_DataInput__Chronology(p0 DataInput) Chronology { AbstractChronology_Init(); panic(A2g_NotTranslated("java.time.chrono.AbstractChronology.readExternal(Ljava/io/DataInput;)Ljava/time/chrono/Chronology;")) }



type AbstractChronology struct{ Object }

type AbstractChronology_I interface{ Object_I; Chronology; Comparable; Self_AbstractChronology() *AbstractChronology; ResolveDate_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveProlepticMonth_Map_ResolverStyle__V(p0 Map, p1 *ResolverStyle); ResolveYearOfEra_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveYMD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveYD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveYMAA_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveYMAD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveYAA_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveYAD_Map_ResolverStyle__ChronoLocalDate(p0 Map, p1 *ResolverStyle) ChronoLocalDate; ResolveAligned_ChronoLocalDate_J_J_J__ChronoLocalDate(p0 ChronoLocalDate, p1, p2, p3 int64) ChronoLocalDate; AddFieldValue_Map_ChronoField_J__V(p0 Map, p1 *ChronoField, p2 int64); CompareTo_Chronology__I(p0 Chronology) int32; WriteReplace__O() any; CompareTo_O__I(p0 any) int32 }

func (t *AbstractChronology) Self_AbstractChronology() *AbstractChronology { return t }

func (t *AbstractChronology) Is_Chronology() {}

func (t *AbstractChronology) Is_Comparable() {}

var AbstractChronology_CHRONOS_BY_ID *ConcurrentHashMap

var AbstractChronology_CHRONOS_BY_TYPE *ConcurrentHashMap

var AbstractChronology_init ClassInit

func AbstractChronology_Init() { if !AbstractChronology_init.Done() { AbstractChronology_init.Run(AbstractChronology_clinit) } }

func AbstractChronology_clinit() { AbstractChronology_CHRONOS_BY_ID = ConcurrentHashMap_New(); AbstractChronology_CHRONOS_BY_TYPE = ConcurrentHashMap_New() }

func (t *AbstractChronology) Impl_CompareTo_O__I(this AbstractChronology_I, p0 any) int32 { return this.CompareTo_Chronology__I(Chronology_Cast(p0)) }

func AbstractChronology_InstanceOf(x any) bool { _, ok := x.(AbstractChronology_I); return ok }

func AbstractChronology_Cast(x any) AbstractChronology_I { if x == nil { return nil }; v, ok := x.(AbstractChronology_I); if !ok { panic(ClassCast(x, AbstractChronology_class)) }; return v }
