//line java_util_Hashtable.ae:1
package jrt






























func Hashtable_New_I_F(p0 int32, p1 float32) *Hashtable { t := &Hashtable{}; t.Ctor_I_F(t, p0, p1); return t }
//line :32:1
func (t *Hashtable) Ctor_I_F(this Hashtable_I, initialCapacity int32, loadFactor float32) { t.Dictionary.Ctor(this); t.F_modCount = 0
	if initialCapacity < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2601, StrOfInt(initialCapacity))))) }
	var tmp1 bool; var tmp2 bool; tmp2 = loadFactor <= 0.0; if !tmp2 { tmp2 = Float_IsNaN_F__Z(loadFactor) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2695, StrOfFloat(loadFactor))))) }
	if initialCapacity == 0 { initialCapacity = 1 }
	t.F_loadFactor = loadFactor
	t.F_table = NewRefArray(Hashtable_Entry_class, initialCapacity)
	t.F_threshold = F2I(Math_Min_F_F__F(float32(float32(initialCapacity)*loadFactor), 2.1474836e9))
}



func Hashtable_New_I(p0 int32) *Hashtable { t := &Hashtable{}; t.Ctor_I(t, p0); return t }
//line :45:1
func (t *Hashtable) Ctor_I(this Hashtable_I, initialCapacity int32) { t.Ctor_I_F(this, initialCapacity, 0.75) }


func Hashtable_New() *Hashtable { t := &Hashtable{}; t.Ctor(t); return t }
//line :48:1
func (t *Hashtable) Ctor(this Hashtable_I) { t.Ctor_I_F(this, 11, 0.75) }

func Hashtable_New_Map(p0 Map) *Hashtable { t := &Hashtable{}; t.Ctor_Map(t, p0); return t }
//line :50:1
func (t *Hashtable) Ctor_Map(this Hashtable_I, t_ Map) { t.Ctor_I_F(this, Math_Max_I_I__I(2*t_.Size__I(), 11), 0.75)

	this.PutAll_Map__V(t_)
}
func Hashtable_New_Void(p0 *Void) *Hashtable { t := &Hashtable{}; t.Ctor_Void(t, p0); return t }
//line :54:1
func (t *Hashtable) Ctor_Void(this Hashtable_I, dummy *Void) { t.Dictionary.Ctor(this); t.F_modCount = 0 }

func (t *Hashtable) Impl_Size__I(this Hashtable_I) int32 { MonitorEnter(this); defer MonitorExit(this); return t.F_count }

func (t *Hashtable) Impl_IsEmpty__Z(this Hashtable_I) bool { MonitorEnter(this); defer MonitorExit(this); return t.F_count == 0 }

func (t *Hashtable) Impl_Keys__Enumeration(this Hashtable_I) Enumeration { MonitorEnter(this); defer MonitorExit(this)
	return t.Impl_GetEnumeration_I__Enumeration(this, 0)
}
func (t *Hashtable) Impl_Elements__Enumeration(this Hashtable_I) Enumeration { MonitorEnter(this); defer MonitorExit(this)
	return t.Impl_GetEnumeration_I__Enumeration(this, 1)
}
func (t *Hashtable) Impl_Contains_O__Z(this Hashtable_I, value any) bool { MonitorEnter(this); defer MonitorExit(this)
	if value == nil { panic(Thrown(NullPointerException_New())) }
	var tab *RefArray = t.F_table; var i int32 = int32(len(tab.A))

L1: for { var tmp1 int32; var old_1 int32 = i; i = i - 1; tmp1 = old_1; if tmp1 > 0 {
	var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[i]); L2: for {
		if !(e == nil) { if Equals(e.F_value, value) { return true } else { e = e.F_next; continue L2 } }
//line :71:1
		break L2 }
//line :70:1
	continue L1 }; break L1 }
//line :68:1
	return false
}





func (t *Hashtable) Impl_ContainsValue_O__Z(this Hashtable_I, value any) bool {
	return this.Contains_O__Z(value)
}
func (t *Hashtable) Impl_ContainsKey_O__Z(this Hashtable_I, key any) bool { MonitorEnter(this); defer MonitorExit(this)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])


L1: for {
	if !(e == nil) {
		var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 { return true } else { e = e.F_next; continue L1 } }
//line :82:1
	break L1 }
//line :79:1
	return false
}







func (t *Hashtable) Impl_Get_O__O(this Hashtable_I, key any) any { MonitorEnter(this); defer MonitorExit(this)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])


L1: for {
	if !(e == nil) {
		var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 {
			return e.F_value } else {
				e = e.F_next; continue L1 } }
//line :92:1
	break L1 }
//line :89:1
	return nil
}











func (t *Hashtable) Impl_Rehash__V(this Hashtable_I) {
	var oldCapacity int32 = int32(len(t.F_table.A)); var oldMap *RefArray = t.F_table; var newCapacity int32 = oldCapacity<<1 + 1


	if newCapacity-2147483639 > 0 {
		if oldCapacity == 2147483639 { return }
		newCapacity = 2147483639 }
	var newMap *RefArray = NewRefArray(Hashtable_Entry_class, newCapacity)
	t.F_modCount = t.F_modCount + 1
	t.F_threshold = F2I(Math_Min_F_F__F(float32(float32(newCapacity)*t.F_loadFactor), 2.1474836e9))



	t.F_table = newMap
	var i int32 = oldCapacity
L1: for { var tmp1 int32; var old_2 int32 = i; i = i - 1; tmp1 = old_2; if tmp1 > 0 {
	var old *Hashtable_Entry = As[*Hashtable_Entry](oldMap.A[i])
L2: for { if !(old == nil) {
	var e *Hashtable_Entry = old
	old = old.F_next
	var index int32 = e.F_hash & 2147483647 % newCapacity


	e.F_next = As[*Hashtable_Entry](newMap.A[index])
	newMap.Store(index, e.Ref())
//line :119:1
	continue L2 }; break L2 }
//line :117:1
	continue L1 }; break L1
}
}








func (t *Hashtable) Impl_AddEntry_I_O_O_I__V(this Hashtable_I, hash int32, key, value any, index int32) {
	var tab *RefArray = t.F_table
	if t.F_count >= t.F_threshold {
		this.Rehash__V()
		tab = t.F_table
		hash = HashCode(key)
		index = hash & 2147483647 % int32(len(tab.A)) }
	var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])
	tab.Store(index, Hashtable_Entry_New_I_O_O_Hashtable_Entry(hash, key, value, e))
	t.F_count = t.F_count + 1
	t.F_modCount = t.F_modCount + 1
}
func (t *Hashtable) Impl_Put_O_O__O(this Hashtable_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	if value == nil { panic(Thrown(NullPointerException_New())) }
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var entry *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])



L1: for { if !(entry == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = entry.F_hash == hash; if tmp2 { tmp2 = Equals(entry.F_key, key) }; tmp1 = tmp2; if tmp1 {
		var old any = entry.F_value; entry.F_value = value; return old }
	entry = entry.F_next
//line :146:1
	continue L1 }; break L1
}


	t.Impl_AddEntry_I_O_O_I__V(this, hash, key, value, index)
//line :142:1
	return nil
}









func (t *Hashtable) Impl_Remove_O__O(this Hashtable_I, key any) any { MonitorEnter(this); defer MonitorExit(this)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index]); var prev *Hashtable_Entry




L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 {
		if !(prev == nil) { prev.F_next = e.F_next } else { tab.Store(index, e.F_next.Ref()) }
		t.F_modCount = t.F_modCount + 1
		t.F_count = t.F_count - 1
		var oldValue any = e.F_value; e.F_value = nil; return oldValue }
	prev = e
	e = e.F_next
//line :159:1
	continue L1 }; break L1 }
//line :154:1
	return nil
}













func (t *Hashtable) Impl_PutAll_Map__V(this Hashtable_I, t_ Map) { MonitorEnter(this); defer MonitorExit(this)
	var i_101886 Iterator = t_.EntrySet__Set().Iterator__Iterator(); for i_101886.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101886.Next__O())
		this.Put_O_O__O(e.GetKey__O(), e.GetValue__O())
	} }
func (t *Hashtable) Impl_Clear__V(this Hashtable_I) { MonitorEnter(this); defer MonitorExit(this)
	var tab *RefArray = t.F_table; var index int32 = int32(len(tab.A))

L1: for { var tmp1 int32; index = index - 1; tmp1 = index; if tmp1 >= 0 { tab.Store(index, nil); continue L1 }; break L1 }
	t.F_modCount = t.F_modCount + 1
	t.F_count = 0
}
func (t *Hashtable) Impl_Clone__O(this Hashtable_I) any { MonitorEnter(this); defer MonitorExit(this)
	var t_ Hashtable_I = this.CloneHashtable__Hashtable()
	t_.Self_Hashtable().F_table = NewRefArray(Hashtable_Entry_class, int32(len(t.F_table.A)))
	var i int32 = int32(len(t.F_table.A))
L1: for { var tmp1 int32; var old_3 int32 = i; i = i - 1; tmp1 = old_3; if tmp1 > 0 {
	var tmp2 *RefArray = t_.Self_Hashtable().F_table; var tmp3 int32 = i; var tmp4 *Hashtable_Entry; if !(As[*Hashtable_Entry](t.F_table.A[i]) == nil) { tmp4 = Hashtable_Entry_Cast(NN(As[*Hashtable_Entry](t.F_table.A[i])).Clone__O()) } else { tmp4 = nil }; tmp2.Store(tmp3, tmp4.Ref())
//line :184:1
	continue L1 }; break L1
}
	t_.Self_Hashtable().F_keySet.Store(nil)
	t_.Self_Hashtable().F_entrySet.Store(nil)
	t_.Self_Hashtable().F_values.Store(nil)
	t_.Self_Hashtable().F_modCount = 0
//line :181:1
	return t_
}









func (t *Hashtable) Impl_CloneHashtable__Hashtable(this Hashtable_I) Hashtable_I {
	var tmp1 Hashtable_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = Hashtable_Cast(A2g_ObjectClone(this)); return nil }()
//line :193:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :193:1
			panic(tmp2) } }; return tmp1
}


func (t *Hashtable) Impl_ToString__String(this Hashtable_I) *String { MonitorEnter(this); defer MonitorExit(this)
	{ var max_ int32 = this.Size__I() - 1
		if max_ == -1 { return Lit_2597 } else {

			var sb *StringBuilder = StringBuilder_New(); var it Iterator = this.EntrySet__Set().Iterator__Iterator()

			NN(sb).Append_C__StringBuilder(123)
			var i int32 = 0; L1: for {
				var e Map_Entry = Map_Entry_Cast(it.Next__O()); var key any = e.GetKey__O(); var value any = e.GetValue__O(); var tmp1 *String


				if any(key) == any(this) { tmp1 = Lit_2598 } else { tmp1 = ToString(key) }; NN(sb).Append_String__StringBuilder(tmp1)
				NN(sb).Append_C__StringBuilder(61)
				var tmp2 *String; if any(value) == any(this) { tmp2 = Lit_2598 } else { tmp2 = ToString(value) }; NN(sb).Append_String__StringBuilder(tmp2)
				if i == max_ { return NN(NN(sb).Append_C__StringBuilder(125)).ToString__String() }
				NN(sb).Append_String__StringBuilder(Lit_1178)
				i = i + 1; continue L1 } } }; panic("a2g: unreachable")
}
func (t *Hashtable) Impl_GetEnumeration_I__Enumeration(this Hashtable_I, type_ int32) Enumeration {
	if t.F_count == 0 { return Collections_EmptyEnumeration__Enumeration() } else { return Hashtable_Enumerator_New_Hashtable_I_Z(this, type_, false)
	} }
func (t *Hashtable) Impl_GetIterator_I__Iterator(this Hashtable_I, type_ int32) Iterator {
	if t.F_count == 0 { return Collections_EmptyIterator__Iterator() } else { return Hashtable_Enumerator_New_Hashtable_I_Z(this, type_, true)
	}
}





func (t *Hashtable) Impl_KeySet__Set(this Hashtable_I) Set {
	if t.F_keySet.Load() == nil { t.F_keySet.Store(Collections_SynchronizedSet_Set_O__Set(Hashtable_KeySet_New_Hashtable(this), this)) }
//line :227:1
	return t.F_keySet.Load()
}





func (t *Hashtable_KeySet) Iterator__Iterator() Iterator {
	return t.F_this_0.Self_Hashtable().Impl_GetIterator_I__Iterator(t.F_this_0, 0)
}
func (t *Hashtable_KeySet) Size__I() int32 { return t.F_this_0.Self_Hashtable().F_count }

func (t *Hashtable_KeySet) Contains_O__Z(o any) bool {
	return t.F_this_0.ContainsKey_O__Z(o)
}
func (t *Hashtable_KeySet) Remove_O__Z(o any) bool {
	return !(t.F_this_0.Remove_O__O(o) == nil)
}
func (t *Hashtable_KeySet) Clear__V() { t.F_this_0.Clear__V() }

func (t *Hashtable) Impl_EntrySet__Set(this Hashtable_I) Set {
	if t.F_entrySet.Load() == nil { t.F_entrySet.Store(Collections_SynchronizedSet_Set_O__Set(Hashtable_EntrySet_New_Hashtable(this), this)) }
//line :247:1
	return t.F_entrySet.Load()
}





func (t *Hashtable_EntrySet) Iterator__Iterator() Iterator {
	return t.F_this_0.Self_Hashtable().Impl_GetIterator_I__Iterator(t.F_this_0, 2)
}
func (t *Hashtable_EntrySet) Add_Map_Entry__Z(o Map_Entry) bool {
	return t.AbstractSet.Impl_Add_O__Z(t, o)
}
func (t *Hashtable_EntrySet) Contains_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var entry Map_Entry = Map_Entry_Cast(tmp1); var key any = entry.GetKey__O(); var tab *RefArray = t.F_this_0.Self_Hashtable().F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])




	L1: for {
		if !(e == nil) {
			var tmp2 bool; var tmp3 bool; tmp3 = e.F_hash == hash; if tmp3 { tmp3 = NN(e).Equals_O__Z(entry) }; tmp2 = tmp3; if tmp2 { return true } else { e = e.F_next; continue L1 } }
//line :266:1
		break L1 }
//line :262:1
		return false




	} else {
//line :261:1
		return false
	}
}









func (t *Hashtable_EntrySet) Remove_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var entry Map_Entry = Map_Entry_Cast(tmp1); var key any = entry.GetKey__O(); var tab *RefArray = t.F_this_0.Self_Hashtable().F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index]); var prev *Hashtable_Entry






	L1: for { if !(e == nil) {
		var tmp2 bool; var tmp3 bool; tmp3 = e.F_hash == hash; if tmp3 { tmp3 = NN(e).Equals_O__Z(entry) }; tmp2 = tmp3; if tmp2 {
			if !(prev == nil) { prev.F_next = e.F_next } else { tab.Store(index, e.F_next.Ref()) }
			e.F_value = nil
			t.F_this_0.Self_Hashtable().F_modCount = t.F_this_0.Self_Hashtable().F_modCount + 1
			t.F_this_0.Self_Hashtable().F_count = t.F_this_0.Self_Hashtable().F_count - 1
			return true }
		prev = e
		e = e.F_next
//line :281:1
		continue L1 }; break L1 }
//line :275:1
		return false












	} else {
//line :274:1
		return false
	}
}
















func (t *Hashtable_EntrySet) Size__I() int32 { return t.F_this_0.Self_Hashtable().F_count }

func (t *Hashtable_EntrySet) Clear__V() { t.F_this_0.Clear__V() }

func (t *Hashtable) Impl_Values__Collection(this Hashtable_I) Collection {
	if t.F_values.Load() == nil { t.F_values.Store(Collections_SynchronizedCollection_Collection_O__Collection(Hashtable_ValueCollection_New_Hashtable(this), this)) }
//line :297:1
	return t.F_values.Load()
}





func (t *Hashtable_ValueCollection) Iterator__Iterator() Iterator {
	return t.F_this_0.Self_Hashtable().Impl_GetIterator_I__Iterator(t.F_this_0, 1)
}
func (t *Hashtable_ValueCollection) Size__I() int32 { return t.F_this_0.Self_Hashtable().F_count }

func (t *Hashtable_ValueCollection) Contains_O__Z(o any) bool {
	return t.F_this_0.ContainsValue_O__Z(o)
}
func (t *Hashtable_ValueCollection) Clear__V() { t.F_this_0.Clear__V() }

func (t *Hashtable) Impl_Equals_O__Z(this Hashtable_I, o any) bool { MonitorEnter(this); defer MonitorExit(this)
	if any(o) == any(this) { return true } else {

		var tmp1 any = o; if Map_InstanceOf(tmp1) { var t_ Map = Map_Cast(tmp1)
			if !(t_.Size__I() == this.Size__I()) { return false } else { tmp4, tmp5, tmp6 := func() (ctl int32, rv bool, exc Throwable_I) { defer Catch(&exc)



				{ var i_101890 Iterator = this.EntrySet__Set().Iterator__Iterator(); for i_101890.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101890.Next__O()); var key any = e.GetKey__O(); var value any = e.GetValue__O()


					if value == nil {
						var tmp2 bool; var tmp3 bool; tmp3 = t_.Get_O__O(key) == nil; if tmp3 { tmp3 = t_.ContainsKey_O__Z(key) }; tmp2 = tmp3; if tmp2 { } else { return 2, false, nil } } else {
							if Equals(value, t_.Get_O__O(key)) { } else { return 3, false, nil } } } }; return 0, false, nil }()
//line :321:1
				if tmp6 != nil { if ClassCastException_InstanceOf(tmp6) || NullPointerException_InstanceOf(tmp6) { var unused RuntimeException_I = RuntimeException_Cast(tmp6); _ = unused






					return false } else {
//line :321:1
						panic(tmp6) } }; switch tmp4 { case 2: { return tmp5 }; case 3: { return tmp5 }}
//line :320:1
				return true
			}




		} else {
//line :317:1
			return false
		}
	}
}











func (t *Hashtable) Impl_HashCode__I(this Hashtable_I) int32 { MonitorEnter(this); defer MonitorExit(this)
	var h int32 = 0; var tmp1 bool; var tmp2 bool
	tmp2 = t.F_count == 0; if !tmp2 { tmp2 = t.F_loadFactor < 0.0 }; tmp1 = tmp2; if tmp1 { return h } else {


		t.F_loadFactor = -t.F_loadFactor
		var tab *RefArray = t.F_table; var arr_101891 *RefArray = tab; var len_101892 int32 = int32(len(arr_101891.A)); var i_101893 int32 = 0; for ; i_101893 < len_101892; i_101893++ {
			var entry *Hashtable_Entry = As[*Hashtable_Entry](arr_101891.A[i_101893])
		L2: for { if !(entry == nil) {
			h = h + NN(entry).HashCode__I()
			entry = entry.F_next
//line :340:1
			continue L2 }; break L2
		}
		}
		t.F_loadFactor = -t.F_loadFactor
//line :338:1
		return h
	}
}





func (t *Hashtable) Impl_GetOrDefault_O_O__O(this Hashtable_I, key, defaultValue any) any { MonitorEnter(this); defer MonitorExit(this)
	var result any = this.Get_O__O(key); if result == nil { return defaultValue } else { return result
	} }
func (t *Hashtable) Impl_ForEach_BiConsumer__V(this Hashtable_I, action BiConsumer) { MonitorEnter(this); defer MonitorExit(this)

	Objects_RequireNonNull_O__O(action)
	var expectedModCount int32 = t.F_modCount; var tab *RefArray = t.F_table; var arr_101894 *RefArray = tab; var len_101895 int32 = int32(len(arr_101894.A)); var i_101896 int32 = 0; for ; i_101896 < len_101895; i_101896++ {

		var entry *Hashtable_Entry = As[*Hashtable_Entry](arr_101894.A[i_101896])
	L2: for { if !(entry == nil) {
		var tmp1 any = entry.F_key; action.Accept_O_O__V(tmp1, entry.F_value)
		entry = entry.F_next
		if expectedModCount == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
//line :355:1
		continue L2 }; break L2
	}
	}
}

func (t *Hashtable) Impl_ReplaceAll_BiFunction__V(this Hashtable_I, function BiFunction) { MonitorEnter(this); defer MonitorExit(this)

	Objects_RequireNonNull_O__O(function)
	var expectedModCount int32 = t.F_modCount; var tab *RefArray = t.F_table; var arr_101897 *RefArray = tab; var len_101898 int32 = int32(len(arr_101897.A)); var i_101899 int32 = 0; for ; i_101899 < len_101898; i_101899++ {

		var entry *Hashtable_Entry = As[*Hashtable_Entry](arr_101897.A[i_101899])
	L2: for { if !(entry == nil) {
		var tmp1 any = entry.F_key; entry.F_value = Objects_RequireNonNull_O__O(function.Apply_O_O__O(tmp1, entry.F_value))

		entry = entry.F_next
		if expectedModCount == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
//line :366:1
		continue L2 }; break L2
	}
	}
}


func (t *Hashtable) Impl_PutIfAbsent_O_O__O(this Hashtable_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	Objects_RequireNonNull_O__O(value)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var entry *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])



L1: for { if !(entry == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = entry.F_hash == hash; if tmp2 { tmp2 = Equals(entry.F_key, key) }; tmp1 = tmp2; if tmp1 {
		var old any = entry.F_value; if old == nil { entry.F_value = value }; return old }
	entry = entry.F_next
//line :378:1
	continue L1 }; break L1
}


	t.Impl_AddEntry_I_O_O_I__V(this, hash, key, value, index)
//line :374:1
	return nil
}









func (t *Hashtable) Impl_Remove_O_O__Z(this Hashtable_I, key, value any) bool { MonitorEnter(this); defer MonitorExit(this)
	Objects_RequireNonNull_O__O(value)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index]); var prev *Hashtable_Entry




L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = e.F_hash == hash; if tmp3 { tmp3 = Equals(e.F_key, key) }; tmp2 = tmp3; if tmp2 { tmp2 = Equals(e.F_value, value) }; tmp1 = tmp2; if tmp1 {
		if !(prev == nil) { prev.F_next = e.F_next } else { tab.Store(index, e.F_next.Ref()) }
		e.F_value = nil
		t.F_modCount = t.F_modCount + 1
		t.F_count = t.F_count - 1
		return true }
	prev = e
	e = e.F_next
//line :392:1
	continue L1 }; break L1 }
//line :387:1
	return false
}














func (t *Hashtable) Impl_Replace_O_O_O__Z(this Hashtable_I, key, oldValue, newValue any) bool { MonitorEnter(this); defer MonitorExit(this)
	Objects_RequireNonNull_O__O(oldValue)
	Objects_RequireNonNull_O__O(newValue)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])



L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 {
		if Equals(e.F_value, oldValue) {
			e.F_value = newValue; return true } else {
				return false } }
	e = e.F_next
//line :410:1
	continue L1 }; break L1 }
//line :406:1
	return false
}










func (t *Hashtable) Impl_Replace_O_O__O(this Hashtable_I, key, value any) any { MonitorEnter(this); defer MonitorExit(this)
	Objects_RequireNonNull_O__O(value)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])



L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 {
		var oldValue any = e.F_value; e.F_value = value; return oldValue }
	e = e.F_next
//line :424:1
	continue L1 }; break L1 }
//line :420:1
	return nil
}








func (t *Hashtable) Impl_ComputeIfAbsent_O_Function__O(this Hashtable_I, key any, mappingFunction Function) any { MonitorEnter(this); defer MonitorExit(this)

	Objects_RequireNonNull_O__O(mappingFunction)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index])



L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 { return e.F_value }
	e = e.F_next
//line :437:1
	continue L1 }; break L1
}

	var mc int32 = t.F_modCount; var newValue any = mappingFunction.Apply_O__O(key)

	if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	if !(newValue == nil) { t.Impl_AddEntry_I_O_O_I__V(this, hash, key, newValue, index) }
//line :440:1
	return newValue
}




func (t *Hashtable) Impl_ComputeIfPresent_O_BiFunction__O(this Hashtable_I, key any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	Objects_RequireNonNull_O__O(remappingFunction)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index]); var prev *Hashtable_Entry




L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_modCount; var newValue any = remappingFunction.Apply_O_O__O(key, e.F_value)

		if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
		if newValue == nil {

			if !(prev == nil) { prev.F_next = e.F_next } else { tab.Store(index, e.F_next.Ref()) }
			t.F_modCount = mc + 1
			t.F_count = t.F_count - 1 } else {
				e.F_value = newValue }
		return newValue }
	prev = e
	e = e.F_next
//line :454:1
	continue L1 }; break L1 }
//line :449:1
	return nil
}



















func (t *Hashtable) Impl_Compute_O_BiFunction__O(this Hashtable_I, key any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	Objects_RequireNonNull_O__O(remappingFunction)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index]); var prev *Hashtable_Entry




L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Objects_Equals_O_O__Z(e.F_key, key) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_modCount; var newValue any = remappingFunction.Apply_O_O__O(key, e.F_value)

		if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
		if newValue == nil {

			if !(prev == nil) { prev.F_next = e.F_next } else { tab.Store(index, e.F_next.Ref()) }
			t.F_modCount = mc + 1
			t.F_count = t.F_count - 1 } else {
				e.F_value = newValue }
		return newValue }
	prev = e
	e = e.F_next
//line :478:1
	continue L1 }; break L1
}












	var mc_2 int32 = t.F_modCount; var newValue_2 any = remappingFunction.Apply_O_O__O(key, nil)

	if mc_2 == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	if !(newValue_2 == nil) { t.Impl_AddEntry_I_O_O_I__V(this, hash, key, newValue_2, index) }
//line :492:1
	return newValue_2
}




func (t *Hashtable) Impl_Merge_O_O_BiFunction__O(this Hashtable_I, key, value any, remappingFunction BiFunction) any { MonitorEnter(this); defer MonitorExit(this)

	Objects_RequireNonNull_O__O(remappingFunction)
	var tab *RefArray = t.F_table; var hash int32 = HashCode(key); var index int32 = hash & 2147483647 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index]); var prev *Hashtable_Entry




L1: for { if !(e == nil) {
	var tmp1 bool; var tmp2 bool; tmp2 = e.F_hash == hash; if tmp2 { tmp2 = Equals(e.F_key, key) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_modCount; var newValue any = remappingFunction.Apply_O_O__O(e.F_value, value)

		if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
		if newValue == nil {

			if !(prev == nil) { prev.F_next = e.F_next } else { tab.Store(index, e.F_next.Ref()) }
			t.F_modCount = mc + 1
			t.F_count = t.F_count - 1 } else {
				e.F_value = newValue }
		return newValue }
	prev = e
	e = e.F_next
//line :506:1
	continue L1 }; break L1
}












	if !(value == nil) { t.Impl_AddEntry_I_O_O_I__V(this, hash, key, value, index) }
//line :501:1
	return value
}


























































































func Hashtable_UnsafeHolder_New() *Hashtable_UnsafeHolder { Hashtable_UnsafeHolder_Init(); t := &Hashtable_UnsafeHolder{}; t.Ctor(); return t }
//line :593:1
func (t *Hashtable_UnsafeHolder) Ctor() { panic(A2g_NotTranslated("java.util.Hashtable$UnsafeHolder.<init>()V")) }






func Hashtable_UnsafeHolder_PutLoadFactor_Hashtable_F__V(p0 Hashtable_I, p1 float32) { Hashtable_UnsafeHolder_Init(); panic(A2g_NotTranslated("java.util.Hashtable$UnsafeHolder.putLoadFactor(Ljava/util/Hashtable;F)V")) }


func (t *Hashtable) Impl_ReconstitutionPut_Hashtable_Entry1_O_O__V(this Hashtable_I, p0 *RefArray, p1, p2 any) { panic(A2g_NotTranslated("java.util.Hashtable.reconstitutionPut([Ljava/util/Hashtable$Entry;Ljava/lang/Object;Ljava/lang/Object;)V")) }



























func Hashtable_Entry_New_I_O_O_Hashtable_Entry(p0 int32, p1, p2 any, p3 *Hashtable_Entry) *Hashtable_Entry { t := &Hashtable_Entry{}; t.Ctor_I_O_O_Hashtable_Entry(p0, p1, p2, p3); return t }
//line :631:1
func (t *Hashtable_Entry) Ctor_I_O_O_Hashtable_Entry(hash int32, key, value any, next *Hashtable_Entry) {
	t.F_hash = hash
	t.F_key = key
	t.F_value = value
	t.F_next = next
}
func (t *Hashtable_Entry) Clone__O() any {
	var tmp1 int32 = t.F_hash; var tmp2 any = t.F_key; var tmp3 any = t.F_value; var tmp4 *Hashtable_Entry; if !(t.F_next == nil) { tmp4 = Hashtable_Entry_Cast(NN(t.F_next).Clone__O()) } else { tmp4 = nil }; return Hashtable_Entry_New_I_O_O_Hashtable_Entry(tmp1, tmp2, tmp3, tmp4)
}
func (t *Hashtable_Entry) GetKey__O() any { return t.F_key }

func (t *Hashtable_Entry) GetValue__O() any { return t.F_value }

func (t *Hashtable_Entry) SetValue_O__O(value any) any {
	if value == nil { panic(Thrown(NullPointerException_New())) }
	var oldValue any = t.F_value; t.F_value = value; return oldValue
}
func (t *Hashtable_Entry) Equals_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var tmp2 bool
		if t.F_key == nil { tmp2 = e.GetKey__O() == nil } else { var tmp3 any = t.F_key; tmp2 = Equals(tmp3, e.GetKey__O()) }; if tmp2 {
			if t.F_value == nil { tmp2 = e.GetValue__O() == nil } else { var tmp4 any = t.F_value; tmp2 = Equals(tmp4, e.GetValue__O()) } }
//line :650:1
		return tmp2 } else {
//line :649:1
			return false
		}
}


func (t *Hashtable_Entry) HashCode__I() int32 {
	var tmp1 int32 = t.F_hash; return tmp1 ^ Objects_HashCode_O__I(t.F_value)
}
func (t *Hashtable_Entry) ToString__String() *String {
	return Concat(ToString(t.F_key), Lit_1171, ToString(t.F_value))
}
























func Hashtable_Enumerator_New_Hashtable_I_Z(p0 Hashtable_I, p1 int32, p2 bool) *Hashtable_Enumerator { t := &Hashtable_Enumerator{}; t.Ctor_Hashtable_I_Z(p0, p1, p2); return t }
//line :684:1
func (t *Hashtable_Enumerator) Ctor_Hashtable_I_Z(this_0 Hashtable_I, type_ int32, iterator bool) { A2g_NotNull[Hashtable_I](this_0); t.F_this_0 = this_0; t.F_table = this_0.Self_Hashtable().F_table; t.F_index = int32(len(t.F_table.A)); t.F_expectedModCount = this_0.Self_Hashtable().F_modCount
	t.F_type = type_
	t.F_iterator = iterator
}
func (t *Hashtable_Enumerator) HasMoreElements__Z() bool {
	var e *Hashtable_Entry = t.F_entry; var i int32 = t.F_index; var t_ *RefArray = t.F_table


L1: for { var tmp1 bool; var tmp2 bool; tmp2 = e == nil; if tmp2 { tmp2 = i > 0 }; tmp1 = tmp2; if tmp1 { var tmp3 int32; i = i - 1; tmp3 = i; e = As[*Hashtable_Entry](t_.A[tmp3]); continue L1 }; break L1 }
	t.F_entry = e
	t.F_index = i
	return !(e == nil)
}
func (t *Hashtable_Enumerator) NextElement__O() any {
	var et *Hashtable_Entry = t.F_entry; var i int32 = t.F_index; var t_ *RefArray = t.F_table


L1: for { var tmp1 bool; var tmp2 bool; tmp2 = et == nil; if tmp2 { tmp2 = i > 0 }; tmp1 = tmp2; if tmp1 { var tmp3 int32; i = i - 1; tmp3 = i; et = As[*Hashtable_Entry](t_.A[tmp3]); continue L1 }; break L1 }
	t.F_entry = et
	t.F_index = i
	if !(et == nil) {
		var e *Hashtable_Entry; var tmp4 *Hashtable_Entry = t.F_entry; t.F_lastReturned = tmp4; e = tmp4
		t.F_entry = e.F_next
		if t.F_type == 0 { return e.F_key } else { if t.F_type == 1 { return e.F_value } else { return e.Ref() } } } else {
			panic(Thrown(NoSuchElementException_New_String(Lit_2696)))
		} }
func (t *Hashtable_Enumerator) HasNext__Z() bool { return t.HasMoreElements__Z() }

func (t *Hashtable_Enumerator) Next__O() any {
	if t.F_this_0.Self_Hashtable().F_modCount == t.F_expectedModCount { } else {
		panic(Thrown(ConcurrentModificationException_New())) }
	return t.NextElement__O()
}
func (t *Hashtable_Enumerator) Remove__V() {
	if t.F_iterator { } else { panic(Thrown(UnsupportedOperationException_New())) }
	if t.F_lastReturned == nil { panic(Thrown(IllegalStateException_New_String(Lit_2696))) }
	if t.F_this_0.Self_Hashtable().F_modCount == t.F_expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	var tmp1 any = t.F_this_0; MonitorEnter(tmp1); tmp3, tmp4 := func() (ctl int32, rv bool) { defer MonitorExit(tmp1)
		{ var tab *RefArray = t.F_this_0.Self_Hashtable().F_table; var tmp2 int32 = t.F_lastReturned.F_hash & 2147483647; var index int32 = tmp2 % int32(len(tab.A)); var e *Hashtable_Entry = As[*Hashtable_Entry](tab.A[index]); var prev *Hashtable_Entry




		L1: for { if !(e == nil) {
			if e == t.F_lastReturned {
				if prev == nil { tab.Store(index, e.F_next.Ref()) } else { prev.F_next = e.F_next }
				t.F_expectedModCount = t.F_expectedModCount + 1
				t.F_lastReturned = nil
				t.F_this_0.Self_Hashtable().F_modCount = t.F_this_0.Self_Hashtable().F_modCount + 1
				t.F_this_0.Self_Hashtable().F_count = t.F_this_0.Self_Hashtable().F_count - 1; return 2, false
			}
			prev = e
			e = e.F_next
//line :727:1
			continue L1 }; break L1
		}








			panic(Thrown(ConcurrentModificationException_New())) }; return 0, false }(); _ = tmp4
//line :721:1
	switch tmp3 { case 2: { return
	}
	}
}
















type Hashtable struct{ Dictionary; F_table *RefArray; F_count, F_threshold int32; F_loadFactor float32; F_modCount int32; F_keySet, F_entrySet Volatile[Set]; F_values Volatile[Collection] }

type Hashtable_I interface{ Dictionary_I; Map; Cloneable; Serializable; Self_Hashtable() *Hashtable; Size__I() int32; IsEmpty__Z() bool; Keys__Enumeration() Enumeration; Elements__Enumeration() Enumeration; Contains_O__Z(p0 any) bool; ContainsValue_O__Z(p0 any) bool; ContainsKey_O__Z(p0 any) bool; Get_O__O(p0 any) any; Rehash__V(); Put_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; PutAll_Map__V(p0 Map); Clear__V(); CloneHashtable__Hashtable() Hashtable_I; KeySet__Set() Set; EntrySet__Set() Set; Values__Collection() Collection; GetOrDefault_O_O__O(p0, p1 any) any; ForEach_BiConsumer__V(p0 BiConsumer); ReplaceAll_BiFunction__V(p0 BiFunction); PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any }

func (t *Hashtable) Self_Hashtable() *Hashtable { return t }

func (t *Hashtable) Is_Map() {}

func (t *Hashtable) Is_Cloneable() {}

func (t *Hashtable) Is_Serializable() {}

const Hashtable_serialVersionUID int64 = 1421746759512286392

const Hashtable_MAX_ARRAY_SIZE int32 = 2147483639

const Hashtable_KEYS int32 = 0

const Hashtable_VALUES int32 = 1

const Hashtable_ENTRIES int32 = 2

func (t *Hashtable) Rehash__V() { t.Impl_Rehash__V(t) }

func (t *Hashtable) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Hashtable) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Hashtable) CloneHashtable__Hashtable() Hashtable_I { return t.Impl_CloneHashtable__Hashtable(t) }

func (t *Hashtable) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Hashtable) Clear__V() { t.Impl_Clear__V(t) }

func (t *Hashtable) Keys__Enumeration() Enumeration { return t.Impl_Keys__Enumeration(t) }

func (t *Hashtable) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Hashtable) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Hashtable) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Hashtable) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Hashtable) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Hashtable) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Hashtable) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Hashtable) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Hashtable) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Hashtable) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Hashtable) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Hashtable) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Hashtable) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Hashtable) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Hashtable) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Hashtable) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Hashtable) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Hashtable) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Hashtable) Elements__Enumeration() Enumeration { return t.Impl_Elements__Enumeration(t) }

func (t *Hashtable) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Hashtable) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Hashtable) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Hashtable) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Hashtable) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Hashtable) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Hashtable) Ref() any { if t == nil { return nil }; return t }

func (t *Hashtable) GetClass__Class() *Class { return Hashtable_class }

func (t *Hashtable) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func Hashtable_InstanceOf(x any) bool { _, ok := x.(Hashtable_I); return ok }

func Hashtable_Cast(x any) Hashtable_I { if x == nil { return nil }; v, ok := x.(Hashtable_I); if !ok { panic(ClassCast(x, Hashtable_class)) }; return v }



type Hashtable_Entry struct{ Object; F_hash int32; F_key, F_value any; F_next *Hashtable_Entry }

func (t *Hashtable_Entry) Is_Map_Entry() {}

func (t *Hashtable_Entry) Ref() any { if t == nil { return nil }; return t }

func (t *Hashtable_Entry) GetClass__Class() *Class { return Hashtable_Entry_class }

func (t *Hashtable_Entry) CloneShallow() any { panic(CloneNotSupported(t)) }

func Hashtable_Entry_InstanceOf(x any) bool { _, ok := x.(*Hashtable_Entry); return ok }

func Hashtable_Entry_Cast(x any) *Hashtable_Entry { if x == nil { return nil }; v, ok := x.(*Hashtable_Entry); if !ok { panic(ClassCast(x, Hashtable_Entry_class)) }; return v }



type Hashtable_EntrySet struct{ AbstractSet; F_this_0 Hashtable_I }

func Hashtable_EntrySet_New_Hashtable(p0 Hashtable_I) *Hashtable_EntrySet { t := &Hashtable_EntrySet{}; t.Ctor_Hashtable(p0); return t }

func (t *Hashtable_EntrySet) Ctor_Hashtable(this_0 Hashtable_I) { A2g_NotNull[Hashtable_I](this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *Hashtable_EntrySet) Add_O__Z(p0 any) bool { return t.Add_Map_Entry__Z(Map_Entry_Cast(p0)) }

func (t *Hashtable_EntrySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *Hashtable_EntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *Hashtable_EntrySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Hashtable_EntrySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Hashtable_EntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Hashtable_EntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Hashtable_EntrySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Hashtable_EntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Hashtable_EntrySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Hashtable_EntrySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Hashtable_EntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Hashtable_EntrySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *Hashtable_EntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Hashtable_EntrySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Hashtable_EntrySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Hashtable_EntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Hashtable_EntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *Hashtable_EntrySet) GetClass__Class() *Class { return Hashtable_EntrySet_class }

func (t *Hashtable_EntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Hashtable_EntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Hashtable_EntrySet_InstanceOf(x any) bool { _, ok := x.(*Hashtable_EntrySet); return ok }

func Hashtable_EntrySet_Cast(x any) *Hashtable_EntrySet { if x == nil { return nil }; v, ok := x.(*Hashtable_EntrySet); if !ok { panic(ClassCast(x, Hashtable_EntrySet_class)) }; return v }



type Hashtable_Enumerator struct{ Object; F_table *RefArray; F_index int32; F_entry, F_lastReturned *Hashtable_Entry; F_type int32; F_iterator bool; F_expectedModCount int32; F_this_0 Hashtable_I }

func (t *Hashtable_Enumerator) Is_Enumeration() {}

func (t *Hashtable_Enumerator) Is_Iterator() {}

func (t *Hashtable_Enumerator) AsIterator__Iterator() Iterator { return Enumeration_AsIterator__Iterator(t) }

func (t *Hashtable_Enumerator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *Hashtable_Enumerator) Ref() any { if t == nil { return nil }; return t }

func (t *Hashtable_Enumerator) GetClass__Class() *Class { return Hashtable_Enumerator_class }

func (t *Hashtable_Enumerator) ToString__String() *String { return Object_toString(t) }

func (t *Hashtable_Enumerator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Hashtable_Enumerator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Hashtable_Enumerator_InstanceOf(x any) bool { _, ok := x.(*Hashtable_Enumerator); return ok }

func Hashtable_Enumerator_Cast(x any) *Hashtable_Enumerator { if x == nil { return nil }; v, ok := x.(*Hashtable_Enumerator); if !ok { panic(ClassCast(x, Hashtable_Enumerator_class)) }; return v }



type Hashtable_KeySet struct{ AbstractSet; F_this_0 Hashtable_I }

func Hashtable_KeySet_New_Hashtable(p0 Hashtable_I) *Hashtable_KeySet { t := &Hashtable_KeySet{}; t.Ctor_Hashtable(p0); return t }

func (t *Hashtable_KeySet) Ctor_Hashtable(this_0 Hashtable_I) { A2g_NotNull[Hashtable_I](this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *Hashtable_KeySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *Hashtable_KeySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *Hashtable_KeySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Hashtable_KeySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Hashtable_KeySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Hashtable_KeySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Hashtable_KeySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Hashtable_KeySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Hashtable_KeySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Hashtable_KeySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Hashtable_KeySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Hashtable_KeySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *Hashtable_KeySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Hashtable_KeySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Hashtable_KeySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Hashtable_KeySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Hashtable_KeySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Hashtable_KeySet) Ref() any { if t == nil { return nil }; return t }

func (t *Hashtable_KeySet) GetClass__Class() *Class { return Hashtable_KeySet_class }

func (t *Hashtable_KeySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Hashtable_KeySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Hashtable_KeySet_InstanceOf(x any) bool { _, ok := x.(*Hashtable_KeySet); return ok }

func Hashtable_KeySet_Cast(x any) *Hashtable_KeySet { if x == nil { return nil }; v, ok := x.(*Hashtable_KeySet); if !ok { panic(ClassCast(x, Hashtable_KeySet_class)) }; return v }



type Hashtable_UnsafeHolder struct{ Object }

var Hashtable_UnsafeHolder_unsafe *Unsafe

var Hashtable_UnsafeHolder_LF_OFFSET int64

var Hashtable_UnsafeHolder_init ClassInit

func Hashtable_UnsafeHolder_Init() { if !Hashtable_UnsafeHolder_init.Done() { Hashtable_UnsafeHolder_init.Run(Hashtable_UnsafeHolder_clinit) } }

func Hashtable_UnsafeHolder_clinit() { Hashtable_UnsafeHolder_unsafe = Unsafe_GetUnsafe__Unsafe(); Hashtable_UnsafeHolder_LF_OFFSET = NN(Hashtable_UnsafeHolder_unsafe).ObjectFieldOffset_Class_String__J(Hashtable_class, Lit_2693) }

func (t *Hashtable_UnsafeHolder) Ref() any { if t == nil { return nil }; return t }

func (t *Hashtable_UnsafeHolder) GetClass__Class() *Class { return Hashtable_UnsafeHolder_class }

func (t *Hashtable_UnsafeHolder) ToString__String() *String { return Object_toString(t) }

func (t *Hashtable_UnsafeHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Hashtable_UnsafeHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func Hashtable_UnsafeHolder_InstanceOf(x any) bool { _, ok := x.(*Hashtable_UnsafeHolder); return ok }

func Hashtable_UnsafeHolder_Cast(x any) *Hashtable_UnsafeHolder { if x == nil { return nil }; v, ok := x.(*Hashtable_UnsafeHolder); if !ok { panic(ClassCast(x, Hashtable_UnsafeHolder_class)) }; return v }



type Hashtable_ValueCollection struct{ AbstractCollection; F_this_0 Hashtable_I }

func Hashtable_ValueCollection_New_Hashtable(p0 Hashtable_I) *Hashtable_ValueCollection { t := &Hashtable_ValueCollection{}; t.Ctor_Hashtable(p0); return t }

func (t *Hashtable_ValueCollection) Ctor_Hashtable(this_0 Hashtable_I) { A2g_NotNull[Hashtable_I](this_0); t.F_this_0 = this_0; t.AbstractCollection.Ctor(t) }

func (t *Hashtable_ValueCollection) Spliterator__Spliterator() Spliterator { return Collection_Spliterator__Spliterator(t) }

func (t *Hashtable_ValueCollection) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *Hashtable_ValueCollection) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Hashtable_ValueCollection) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Hashtable_ValueCollection) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Hashtable_ValueCollection) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Hashtable_ValueCollection) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Hashtable_ValueCollection) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Hashtable_ValueCollection) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Hashtable_ValueCollection) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Hashtable_ValueCollection) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Hashtable_ValueCollection) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Hashtable_ValueCollection) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *Hashtable_ValueCollection) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Hashtable_ValueCollection) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Hashtable_ValueCollection) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Hashtable_ValueCollection) Ref() any { if t == nil { return nil }; return t }

func (t *Hashtable_ValueCollection) GetClass__Class() *Class { return Hashtable_ValueCollection_class }

func (t *Hashtable_ValueCollection) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Hashtable_ValueCollection) CloneShallow() any { panic(CloneNotSupported(t)) }

func Hashtable_ValueCollection_InstanceOf(x any) bool { _, ok := x.(*Hashtable_ValueCollection); return ok }

func Hashtable_ValueCollection_Cast(x any) *Hashtable_ValueCollection { if x == nil { return nil }; v, ok := x.(*Hashtable_ValueCollection); if !ok { panic(ClassCast(x, Hashtable_ValueCollection_class)) }; return v }
