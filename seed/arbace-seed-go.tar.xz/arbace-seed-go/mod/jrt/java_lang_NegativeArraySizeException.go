//line java_lang_NegativeArraySizeException.ae:1
package jrt








func NegativeArraySizeException_New() *NegativeArraySizeException { t := &NegativeArraySizeException{}; t.Ctor(); return t }
//line :10:1
func (t *NegativeArraySizeException) Ctor() { t.RuntimeException.Ctor(t) }

func NegativeArraySizeException_New_String(p0 *String) *NegativeArraySizeException { t := &NegativeArraySizeException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NegativeArraySizeException) Ctor_String(s *String) { t.RuntimeException.Ctor_String(t, s) }







type NegativeArraySizeException struct{ RuntimeException }

const NegativeArraySizeException_serialVersionUID int64 = -8960118058596991861

func (t *NegativeArraySizeException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NegativeArraySizeException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NegativeArraySizeException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NegativeArraySizeException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NegativeArraySizeException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NegativeArraySizeException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NegativeArraySizeException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NegativeArraySizeException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NegativeArraySizeException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NegativeArraySizeException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NegativeArraySizeException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NegativeArraySizeException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NegativeArraySizeException) Ref() any { if t == nil { return nil }; return t }

func (t *NegativeArraySizeException) GetClass__Class() *Class { return NegativeArraySizeException_class }

func (t *NegativeArraySizeException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NegativeArraySizeException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NegativeArraySizeException_InstanceOf(x any) bool { _, ok := x.(*NegativeArraySizeException); return ok }

func NegativeArraySizeException_Cast(x any) *NegativeArraySizeException { if x == nil { return nil }; v, ok := x.(*NegativeArraySizeException); if !ok { panic(ClassCast(x, NegativeArraySizeException_class)) }; return v }
