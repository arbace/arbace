//line java_nio_file_AccessDeniedException.ae:1
package jrt








func AccessDeniedException_New_String(p0 *String) *AccessDeniedException { t := &AccessDeniedException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *AccessDeniedException) Ctor_String(file *String) { t.FileSystemException.Ctor_String(t, file) }

func AccessDeniedException_New_String_String_String(p0, p1, p2 *String) *AccessDeniedException { t := &AccessDeniedException{}; t.Ctor_String_String_String(p0, p1, p2); return t }
//line :12:1
func (t *AccessDeniedException) Ctor_String_String_String(file, other, reason *String) { t.FileSystemException.Ctor_String_String_String(t, file, other, reason) }







type AccessDeniedException struct{ FileSystemException }

const AccessDeniedException_serialVersionUID int64 = 4943049599949219617

func (t *AccessDeniedException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *AccessDeniedException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *AccessDeniedException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *AccessDeniedException) GetFile__String() *String { return t.Impl_GetFile__String(t) }

func (t *AccessDeniedException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *AccessDeniedException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *AccessDeniedException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *AccessDeniedException) GetReason__String() *String { return t.Impl_GetReason__String(t) }

func (t *AccessDeniedException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *AccessDeniedException) GetOtherFile__String() *String { return t.Impl_GetOtherFile__String(t) }

func (t *AccessDeniedException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *AccessDeniedException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *AccessDeniedException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *AccessDeniedException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *AccessDeniedException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AccessDeniedException) Ref() any { if t == nil { return nil }; return t }

func (t *AccessDeniedException) GetClass__Class() *Class { return AccessDeniedException_class }

func (t *AccessDeniedException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AccessDeniedException) CloneShallow() any { panic(CloneNotSupported(t)) }

func AccessDeniedException_InstanceOf(x any) bool { _, ok := x.(*AccessDeniedException); return ok }

func AccessDeniedException_Cast(x any) *AccessDeniedException { if x == nil { return nil }; v, ok := x.(*AccessDeniedException); if !ok { panic(ClassCast(x, AccessDeniedException_class)) }; return v }
