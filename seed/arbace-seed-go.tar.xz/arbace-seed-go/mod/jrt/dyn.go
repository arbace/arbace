//line dyn.ae:1
package jrt

import "strings"





// Dynamic is an object of a class made at run time (a2g's Dyn): DynImplements says whether
// its class implements the interface c (directly or through its superinterfaces).
type Dynamic /*line :14:1*/ interface {
	DynImplements(c *Class) bool }
// dynNominal is the nominal check of jrt's hand-written interfaces (as a2g's instanceof and
// checkcast make it for the translated ones): ok, the Go assertion's result, unless x is an
// object of a class made at run time (Dyn implements every interface of the world), whose class
// must implement c.
//line :17:1
func dynNominal(x any, c /*line :22:1*/*Class, ok bool) bool {
	if ok {
		d, dyn := x.(Dynamic)
		if dyn {
			return d.DynImplements(c)
		} }; return ok }
// dynamicClasses are the classes DefineDynamic made (under registryMu).
var dynamicClasses map[*Class]bool =

	make(map[*Class]bool)
// DefineDynamic registers a class made at run time under its binary name and returns its
// Class object. Unlike Define, it may replace a class DefineDynamic made before under the same
// name (deftype evaluated again at the REPL); a class of the closed world cannot be replaced.
//line :33:1
func DefineDynamic(info /*line :37:1*/*ClassInfo) *Class {
	c := &Class{info: info}
	presetClassHash(c, info.Name)
	registryMu.Lock()
	{ old := registry[info.Name]
		if old != nil && !dynamicClasses[old] {
			registryMu.Unlock()
			panic(Thrown(IllegalArgumentException_New_String(
				Str("duplicate class definition: " + info.Name)))) }
		if old != nil {
			delete(dynamicClasses, old) } }
	registry[info.Name] = c
	dynamicClasses[c] = true
	registryMu.Unlock(); return c }
// Descriptor is the class's JVM descriptor: I, [Ljava/lang/String;, Ljava/lang/Object; (the
// evaluator's method keys).
func (c /*line :56:1*/*Class) Descriptor() string {
	if c.desc != 0 {
		return string(rune(c.desc)) }
	if strings.HasPrefix(c.info.Name, "[") {
		return strings.ReplaceAll(c.info.Name, ".", "/") }
	return "L" + strings.ReplaceAll(c.info.Name, ".", "/") + ";"
}
