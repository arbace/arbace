//line java_time_chrono_ChronoPeriod.ae:1
package jrt









func ChronoPeriod_Between_ChronoLocalDate_ChronoLocalDate__ChronoPeriod(startDateInclusive, endDateExclusive ChronoLocalDate) ChronoPeriod {

	Objects_RequireNonNull_O_String__O(startDateInclusive, Lit_2194)
	Objects_RequireNonNull_O_String__O(endDateExclusive, Lit_2195)
	return startDateInclusive.Until_ChronoLocalDate__ChronoPeriod(endDateExclusive)
}






func ChronoPeriod_IsZero__Z(this ChronoPeriod) bool {
	var i_101559 Iterator = this.GetUnits__List().Iterator__Iterator(); for i_101559.HasNext__Z() { var unit TemporalUnit = TemporalUnit_Cast(i_101559.Next__O())
		if this.Get_TemporalUnit__J(unit) == 0 { } else { return false } }
//line :23:1
	return true
}



func ChronoPeriod_IsNegative__Z(this ChronoPeriod) bool {
	var i_101560 Iterator = this.GetUnits__List().Iterator__Iterator(); for i_101560.HasNext__Z() { var unit TemporalUnit = TemporalUnit_Cast(i_101560.Next__O()); if this.Get_TemporalUnit__J(unit) < 0 { return true } }
//line :28:1
	return false
}








func ChronoPeriod_Negated__ChronoPeriod(this ChronoPeriod) ChronoPeriod { return this.MultipliedBy_I__ChronoPeriod(-1) }



type ChronoPeriod interface{ Object_I; TemporalAmount; Is_ChronoPeriod(); Get_TemporalUnit__J(p0 TemporalUnit) int64; GetUnits__List() List; GetChronology__Chronology() Chronology; IsZero__Z() bool; IsNegative__Z() bool; Plus_TemporalAmount__ChronoPeriod(p0 TemporalAmount) ChronoPeriod; Minus_TemporalAmount__ChronoPeriod(p0 TemporalAmount) ChronoPeriod; MultipliedBy_I__ChronoPeriod(p0 int32) ChronoPeriod; Negated__ChronoPeriod() ChronoPeriod; Normalized__ChronoPeriod() ChronoPeriod; AddTo_Temporal__Temporal(p0 Temporal) Temporal; SubtractFrom_Temporal__Temporal(p0 Temporal) Temporal }

func ChronoPeriod_InstanceOf(x any) bool { _, ok := x.(ChronoPeriod); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoPeriod_class) } }; return ok }

func ChronoPeriod_Cast(x any) ChronoPeriod { if x == nil { return nil }; v, ok := x.(ChronoPeriod); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoPeriod_class) } }; if !ok { panic(ClassCast(x, ChronoPeriod_class)) }; return v }
