//line java_net_InetAddress.ae:1
package jrt

import "sync/atomic"


























func InetAddress_IsIPv4Available__Z() bool { InetAddress_Init()
	return HostNet_HasFamily0_Z__Z(false)
}
func InetAddress_IsIPv6Supported__Z() bool { InetAddress_Init()
	return HostNet_HasFamily0_Z__Z(true)
}
func InetAddress_Resolver__InetAddressResolver() InetAddressResolver { InetAddress_Init(); return InetAddress_BUILTIN_RESOLVER }




func InetAddress_GetAllByName0_String_Z__InetAddress1(host *String, useCache bool) *RefArray { InetAddress_Init()

	var now int64 = System_NanoTime__J(); var c any
	if useCache { c = InetAddress_cache.Get_O__O(host.Ref()) } else { c = nil }
	var tmp1 bool; var tmp2 bool; tmp2 = InetAddress_CachedLookup_InstanceOf(c); if tmp2 {
		tmp2 = InetAddress_CachedLookup_Cast(c).Self_InetAddress_CachedLookup().F_expiryTime.Load()-now >= 0 }
//line :45:1
	tmp1 = tmp2; if tmp1 {

		return NN(InetAddress_CachedLookup_Cast(c).Get__InetAddress1()).Copy() } else {
			var addrs *RefArray; var ex *UnknownHostException; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)


				addrs = InetAddress_GetAddressesFromNameService_String__InetAddress1(host)
//line :48:1
				return nil
			}()
			if tmp3 != nil { if UnknownHostException_InstanceOf(tmp3) { var e *UnknownHostException = UnknownHostException_Cast(tmp3)

				ex = e } else {
//line :50:1
					panic(tmp3)
				}
			}
			var tmp4 ConcurrentMap = InetAddress_cache; var tmp5 *RefArray = addrs; var tmp6 int64
			if ex == nil { tmp6 = 30000000000 } else { tmp6 = 10000000000 }
//line :53:1
			tmp4.Put_O_O__O(host.Ref(), InetAddress_CachedLookup_New_String_InetAddress1_J(host, tmp5, now+tmp6))

			if !(ex == nil) { panic(Thrown(Up_UnknownHostException_Throwable(ex))) }
			return NN(addrs).Copy() } }
//line :44:1
func InetAddress_InetAddressHolder_New() *InetAddress_InetAddressHolder { t := &InetAddress_InetAddressHolder{}; t.Ctor(); return t }
//line :44:1
func (t *InetAddress_InetAddressHolder) Ctor() {}

func InetAddress_InetAddressHolder_New_String_I_I(p0 *String, p1, p2 int32) *InetAddress_InetAddressHolder { t := &InetAddress_InetAddressHolder{}; t.Ctor_String_I_I(p0, p1, p2); return t }
//line :46:1
func (t *InetAddress_InetAddressHolder) Ctor_String_I_I(hostName *String, address, family int32) { panic(A2g_NotTranslated("java.net.InetAddress$InetAddressHolder.<init>(Ljava/lang/String;II)V")) }





func (t *InetAddress_InetAddressHolder) Init_String_I__V(hostName *String, family int32) {
	t.F_originalHostName = hostName
	t.F_hostName = hostName
	if family == -1 { } else { t.F_family = family
	}
}

func (t *InetAddress_CachedLookup) Impl_TryRemoveExpiredAddress_J__Z(this InetAddress_CachedLookup_I, now int64) bool {
	if t.F_expiryTime.Load()-now < 0 {
		var tmp1 ConcurrentMap; InetAddress_Init(); tmp1 = InetAddress_cache; tmp1.Remove_O_O__Z(t.F_host.Ref(), this)
		return true }
//line :59:1
	return false }
//line :59:1
func (t *InetAddress_InetAddressHolder) GetHostName__String() *String { return t.F_hostName }

func (t *InetAddress_InetAddressHolder) GetOriginalHostName__String() *String { panic(A2g_NotTranslated("java.net.InetAddress$InetAddressHolder.getOriginalHostName()Ljava/lang/String;")) }



func (t *InetAddress_InetAddressHolder) GetAddress__I() int32 { return t.F_address }
func (t *InetAddress_ValidCachedLookup) TryRemoveExpiredAddress_J__Z(now int64) bool { return false }


func (t *InetAddress_InetAddressHolder) GetFamily__I() int32 { panic(A2g_NotTranslated("java.net.InetAddress$InetAddressHolder.getFamily()I")) }
func (t *InetAddress_PlatformResolver) LookupByName_String_InetAddressResolver_LookupPolicy__Stream(host *String, policy *InetAddressResolver_LookupPolicy) Stream {


	Objects_RequireNonNull_O__O(host.Ref())
	Objects_RequireNonNull_O__O(policy.Ref())
	InetAddress_Validate_String__V(host)
	var tmp1 InetAddressImpl; InetAddress_Init(); tmp1 = InetAddress_impl; return Arrays_Stream_O1__Stream(tmp1.LookupAllHostAddr_String_InetAddressResolver_LookupPolicy__InetAddress1(host, policy)) }
//line :73:1
func (t *InetAddress) Impl_Holder__InetAddress_InetAddressHolder(this InetAddress_I) *InetAddress_InetAddressHolder { return t.F_holder }




func (t *InetAddress_PlatformResolver) LookupByAddress_B1__String(addr *ByteArray) *String {
	Objects_RequireNonNull_O__O(addr.Ref())
	var tmp1 bool; var tmp2 bool; tmp2 = !(int32(len(addr.A)) == 4); if tmp2 {
		tmp2 = !(int32(len(addr.A)) == 16) }
//line :80:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1321))) }
	var tmp3 InetAddressImpl; InetAddress_Init(); tmp3 = InetAddress_impl; return tmp3.GetHostByAddr_B1__String(addr)
}


func (t *InetAddress_NameServiceAddresses) Get__InetAddress1() *RefArray {
	return InetAddress_GetAddressesFromNameService_String__InetAddress1(t.F_host)
}

















func InetAddress_InitializePlatformLookupPolicy__InetAddressResolver_LookupPolicy() *InetAddressResolver_LookupPolicy { InetAddress_Init()
	var ipv4Available bool = InetAddress_IsIPv4Available__Z(); var tmp1 bool; var tmp2 bool

	tmp2 = Lit_107.Equals_O__Z(InetAddress_PREFER_IPV4_STACK_VALUE.Ref()); if tmp2 { tmp2 = ipv4Available }; tmp1 = tmp2
//line :109:1
	if tmp1 {

		return InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(1) } else {
//line :109:1
			if Inet4AddressImpl_InstanceOf(InetAddress_impl) {



				return InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(1) } else {
//line :109:1
					if !ipv4Available {





						return InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(2) } else {


							if !(InetAddress_PREFER_IPV6_ADDRESSES_VALUE == nil) {
								if NN(InetAddress_PREFER_IPV6_ADDRESSES_VALUE).EqualsIgnoreCase_String__Z(Lit_107) {
									return InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(11)
								}



								if NN(InetAddress_PREFER_IPV6_ADDRESSES_VALUE).EqualsIgnoreCase_String__Z(Lit_1316) {
									return InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(7)
								}



								if NN(InetAddress_PREFER_IPV6_ADDRESSES_VALUE).EqualsIgnoreCase_String__Z(Lit_1317) {
									return InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(3)
								}
							}
							return InetAddressResolver_LookupPolicy_Of_I__InetAddressResolver_LookupPolicy(7)
						}
				}
		}
}
func InetAddress_SystemAddressesOrder_I__Z(lookupCharacteristics int32) bool { InetAddress_Init()
	return lookupCharacteristics&12 == 0
}



func InetAddress_Ipv4AddressesFirst_I__Z(lookupCharacteristics int32) bool { InetAddress_Init()
	return !(lookupCharacteristics&4 == 0)
}
func InetAddress_Ipv6AddressesFirst_I__Z(lookupCharacteristics int32) bool { InetAddress_Init()
	return !(lookupCharacteristics&8 == 0)
}

































func InetAddress_LoadResolver__InetAddressResolver() InetAddressResolver { InetAddress_Init(); panic(A2g_NotTranslated("java.net.InetAddress.loadResolver()Ljava/net/spi/InetAddressResolver;")) }














func InetAddress_New() *InetAddress { InetAddress_Init(); t := &InetAddress{}; t.Ctor(t); return t }
//line :200:1
func (t *InetAddress) Ctor(this InetAddress_I) { t.F_canonicalHostName = nil; t.F_holder = InetAddress_InetAddressHolder_New() }

func (t *InetAddress) Impl_ReadResolve__O(this InetAddress_I) any { panic(A2g_NotTranslated("java.net.InetAddress.readResolve()Ljava/lang/Object;")) }


func (t *InetAddress) Impl_IsMulticastAddress__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsAnyLocalAddress__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsLoopbackAddress__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsLinkLocalAddress__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsSiteLocalAddress__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsMCGlobal__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsMCNodeLocal__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsMCLinkLocal__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsMCSiteLocal__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsMCOrgLocal__Z(this InetAddress_I) bool { return false }

func (t *InetAddress) Impl_IsReachable_I__Z(this InetAddress_I, timeout int32) bool {
	return A2g_Missing[bool]("class java.net.NetworkInterface is not in the closed world")
}






func (t *InetAddress) Impl_GetHostName__String(this InetAddress_I) *String {
	if NN(this.Holder__InetAddress_InetAddressHolder()).GetHostName__String() == nil {
		this.Holder__InetAddress_InetAddressHolder().F_hostName = InetAddress_GetHostFromNameService_InetAddress__String(this) }
	return NN(this.Holder__InetAddress_InetAddressHolder()).GetHostName__String()
}
func (t *InetAddress) Impl_GetCanonicalHostName__String(this InetAddress_I) *String {
	var value *String = t.F_canonicalHostName
	if value == nil {
		var tmp1 *String; value = InetAddress_GetHostFromNameService_InetAddress__String(this); tmp1 = value; t.F_canonicalHostName = tmp1 }
//line :240:1
	return value
}



func InetAddress_GetHostFromNameService_InetAddress__String(addr InetAddress_I) *String { InetAddress_Init()
	var host *String; var resolver InetAddressResolver = InetAddress_Resolver__InetAddressResolver(); tmp3, tmp4, tmp5 := func() (ctl int32, rv *String, exc Throwable_I) { defer Catch(&exc)


		host = resolver.LookupByAddress_B1__String(addr.GetAddress__B1())
		{ var arr *RefArray = InetAddress_GetAllByName0_String__InetAddress1(host)
			var ok bool = false
			if !(arr == nil) {
				var i int32 = 0; L1: for {
					var tmp1 bool; var tmp2 bool; tmp2 = !ok; if tmp2 { tmp2 = i < int32(len(arr.A)) }; tmp1 = tmp2; if tmp1 {
						ok = addr.Equals_O__Z(As[InetAddress_I](arr.A[i]))
						i = i + 1; continue L1 }
//line :253:1
					break L1
				}
			}

			if ok { } else { host = addr.GetHostAddress__String(); return 2, host, nil } }; return 0, nil, nil }()
//line :248:1
	if tmp5 != nil { if RuntimeException_InstanceOf(tmp5) || UnknownHostException_InstanceOf(tmp5) { var e Exception_I = Exception_Cast(tmp5); _ = e









		host = addr.GetHostAddress__String() } else {
//line :248:1
			panic(tmp5) } }; switch tmp3 { case 2: { return tmp4 }}
//line :246:1
	return host
}













func (t *InetAddress) Impl_GetAddress__B1(this InetAddress_I) *ByteArray { return nil }

func (t *InetAddress) Impl_GetHostAddress__String(this InetAddress_I) *String { return nil }

func (t *InetAddress) Impl_HashCode__I(this InetAddress_I) int32 { return -1 }

func (t *InetAddress) Impl_Equals_O__Z(this InetAddress_I, obj any) bool { return false }

func (t *InetAddress) Impl_ToString__String(this InetAddress_I) *String {
	var hostName *String = NN(this.Holder__InetAddress_InetAddressHolder()).GetHostName__String()
	return Concat(Objects_ToString_O_String__String(hostName.Ref(), Lit_69), Lit_68, this.GetHostAddress__String())
}






















func InetAddress_CachedLookup_New_String_InetAddress1_J(p0 *String, p1 *RefArray, p2 int64) *InetAddress_CachedLookup { InetAddress_CachedLookup_Init(); t := &InetAddress_CachedLookup{}; t.Ctor_String_InetAddress1_J(t, p0, p1, p2); return t }
//line :295:1
func (t *InetAddress_CachedLookup) Ctor_String_InetAddress1_J(this InetAddress_CachedLookup_I, host *String, inetAddresses *RefArray, expiryTime int64) { t.F_id = NN(InetAddress_CachedLookup_seq).IncrementAndGet__J()
	t.F_host = host
	t.F_inetAddresses.Store(inetAddresses)
	t.F_expiryTime.Store(expiryTime)
}
func (t *InetAddress_CachedLookup) Impl_Get__InetAddress1(this InetAddress_CachedLookup_I) *RefArray {
	if t.F_inetAddresses.Load() == nil {
		panic(Thrown(UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_host)))))) }
//line :300:1
	return t.F_inetAddresses.Load()
}






func (t *InetAddress_CachedLookup) Impl_CompareTo_InetAddress_CachedLookup__I(this, other InetAddress_CachedLookup_I) int32 {
	var tmp1 int64 = t.F_expiryTime.Load(); var diff int64 = tmp1 - other.Self_InetAddress_CachedLookup().F_expiryTime.Load()
	if diff < 0 { return -1 } else { if diff > 0 { return 1 } else { var tmp2 int64 = t.F_id; return Long_Compare_J_J__I(tmp2, other.Self_InetAddress_CachedLookup().F_id)
	}
	}
}












func InetAddress_ValidCachedLookup_New_String_InetAddress1_J_J(p0 *String, p1 *RefArray, p2, p3 int64) *InetAddress_ValidCachedLookup { InetAddress_ValidCachedLookup_Init(); t := &InetAddress_ValidCachedLookup{}; t.Ctor_String_InetAddress1_J_J(p0, p1, p2, p3); return t }
//line :326:1
func (t *InetAddress_ValidCachedLookup) Ctor_String_InetAddress1_J_J(host *String, inetAddresses *RefArray, staleTime, refreshTime int64) { panic(A2g_NotTranslated("java.net.InetAddress$ValidCachedLookup.<init>(Ljava/lang/String;[Ljava/net/InetAddress;JJ)V")) }




func (t *InetAddress_ValidCachedLookup) Get__InetAddress1() *RefArray {
	var now int64 = System_NanoTime__J(); var tmp1 bool; var tmp2 bool
	tmp2 = t.F_refreshTime.Load()-now < 0; if tmp2 { tmp2 = t.F_lookupLock.TryLock__Z() }; tmp1 = tmp2; if tmp1 { tmp5 := func() (exc Throwable_I) { defer Catch(&exc); { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_refreshTime.Store(now + int64(A2g_Missing[int32]("class sun.net.InetAddressCachePolicy is not in the closed world"))*1000000000)

		t.F_inetAddresses.Store(InetAddress_GetAddressesFromNameService_String__InetAddress1(t.F_host))
		{ var tmp3 int64 = t.F_refreshTime.Load(); t.F_staleTime.Store(tmp3 + int64(A2g_Missing[int32]("class sun.net.InetAddressCachePolicy is not in the closed world"))*1000000000) }; return nil }()
//line :334:1
		if tmp4 != nil { if UnknownHostException_InstanceOf(tmp4) { var ignore *UnknownHostException = UnknownHostException_Cast(tmp4); _ = ignore } else { panic(tmp4)
		}
		}
	}
		return nil
	}()


		t.F_lookupLock.Unlock__V()
//line :334:1
		if tmp5 != nil { panic(tmp5)
		}
	}






	return t.F_inetAddresses.Load()
}














func InetAddress_NameServiceAddresses_New_String(p0 *String) *InetAddress_NameServiceAddresses { t := &InetAddress_NameServiceAddresses{}; t.Ctor_String(p0); return t }
//line :359:1
func (t *InetAddress_NameServiceAddresses) Ctor_String(host *String) { panic(A2g_NotTranslated("java.net.InetAddress$NameServiceAddresses.<init>(Ljava/lang/String;)V")) }

















































































func InetAddress_HostsFileResolver_New_String(p0 *String) *InetAddress_HostsFileResolver { InetAddress_HostsFileResolver_Init(); t := &InetAddress_HostsFileResolver{}; t.Ctor_String(p0); return t }
//line :441:1
func (t *InetAddress_HostsFileResolver) Ctor_String(hostsFileName *String) {
	t.F_hostsFile = hostsFileName
}
func (t *InetAddress_HostsFileResolver) LookupByAddress_B1__String(addr *ByteArray) *String {
	var hostEntry *String; var host *String

	Objects_RequireNonNull_O__O(addr.Ref())
	var tmp1 bool; var tmp2 bool; tmp2 = !(int32(len(addr.A)) == 4); if tmp2 {
		tmp2 = !(int32(len(addr.A)) == 16) }
//line :448:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1321))) }
//line :449:1
	tmp7 := func() (exc Throwable_I) { defer Catch(&exc)


		{ var hostsFileScanner any; _ = hostsFileScanner; hostsFileScanner = A2g_Missing[any]("class java.util.Scanner is not in the closed world"); tmp5 := func() (exc Throwable_I) { defer Catch(&exc)
		L1: for { if A2g_Missing[bool]("class java.util.Scanner is not in the closed world") {
			hostEntry = A2g_Missing[*String]("class java.util.Scanner is not in the closed world")
			if NN(hostEntry).StartsWith_String__Z(Lit_1132) { } else {
				hostEntry = t.RemoveComments_String__String(hostEntry)
				var mapping *RefArray = NN(hostEntry).Split_String__String1(Lit_1322); var tmp3 bool; var tmp4 bool
				tmp4 = int32(len(mapping.A)) >= 2; if tmp4 {
					tmp4 = Arrays_Equals_B1_B1__Z(addr, t.CreateAddressByteArray_String__B1(As[*String](mapping.A[0]))) }
//line :458:1
				tmp3 = tmp4; if tmp3 {

					host = As[*String](mapping.A[1])
					break L1 } }
//line :453:1
			continue L1 }; break L1
		}




			return nil }()
//line :452:1
			if tmp5 == nil { A2g_Missing[bool]("class java.util.Scanner is not in the closed world") }; if tmp5 != nil { if true { var t_101120 Throwable_I = tmp5; tmp6 := func() (exc Throwable_I) { defer Catch(&exc); A2g_Missing[bool]("class java.util.Scanner is not in the closed world"); return nil }(); if tmp6 != nil { if true { var x_101121 Throwable_I = tmp6; t_101120.AddSuppressed_Throwable__V(x_101121) } }; panic(Thrown(t_101120))
			}
			}
		}



		return nil }()
//line :451:1
	if tmp7 != nil { if IOException_InstanceOf(tmp7) { var e IOException_I = IOException_Cast(tmp7); _ = e











		panic(Thrown(UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1323, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(Arrays_ToString_B1__String(addr)), Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_hostsFile).ReplaceWith_String__Exceptions_SensitiveInfo(Lit_1324)))))) } else {
//line :451:1
			panic(tmp7)
		}
	}

















	var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = host == nil; if !tmp10 { tmp10 = NN(host).IsEmpty__Z() }; tmp9 = tmp10; if !tmp9 { tmp9 = NN(host).Equals_O__Z(Lit_115) }; tmp8 = tmp9; if tmp8 {
		panic(Thrown(UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1325, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(Arrays_ToString_B1__String(addr)), Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_hostsFile).ReplaceWith_String__Exceptions_SensitiveInfo(Lit_1324)))))) }
//line :445:1
	return host
}


































func (t *InetAddress_HostsFileResolver) LookupByName_String_InetAddressResolver_LookupPolicy__Stream(host *String, lookupPolicy *InetAddressResolver_LookupPolicy) Stream {


	var hostEntry *String; var addrStr *String; var addr *ByteArray


	Objects_RequireNonNull_O__O(host.Ref())
	Objects_RequireNonNull_O__O(lookupPolicy.Ref())
	var inetAddresses List = ArrayList_New(); var inet4Addresses List = ArrayList_New(); var inet6Addresses List = ArrayList_New(); var flags int32 = NN(lookupPolicy).Characteristics__I(); var needIPv4 bool = !(flags&1 == 0); var needIPv6 bool = !(flags&2 == 0); tmp9 := func() (exc Throwable_I) { defer Catch(&exc)






		{ var hostsFileScanner any; _ = hostsFileScanner; hostsFileScanner = A2g_Missing[any]("class java.util.Scanner is not in the closed world"); tmp7 := func() (exc Throwable_I) { defer Catch(&exc)
		L1: for { if A2g_Missing[bool]("class java.util.Scanner is not in the closed world") {
			hostEntry = A2g_Missing[*String]("class java.util.Scanner is not in the closed world")
			if NN(hostEntry).StartsWith_String__Z(Lit_1132) { } else {
				hostEntry = t.RemoveComments_String__String(hostEntry)
				if NN(hostEntry).Contains_CharSequence__Z(Up_String_CharSequence(host)) {
					addrStr = t.ExtractHostAddr_String_String__String(hostEntry, host)
					var tmp1 bool; var tmp2 bool; tmp2 = !(addrStr == nil); if tmp2 { tmp2 = !NN(addrStr).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
						addr = t.CreateAddressByteArray_String__B1(addrStr)
						if !(addr == nil) {
							var address InetAddress_I = InetAddress_GetByAddress_String_B1__InetAddress(host, addr)
							inetAddresses.Add_O__Z(address)
							var tmp3 bool; var tmp4 bool; tmp4 = Inet4Address_InstanceOf(address); if tmp4 { tmp4 = needIPv4 }; tmp3 = tmp4; if tmp3 {
								inet4Addresses.Add_O__Z(address) }
							var tmp5 bool; var tmp6 bool; tmp6 = Inet6Address_InstanceOf(address); if tmp6 { tmp6 = needIPv6 }; tmp5 = tmp6; if tmp5 {
								inet6Addresses.Add_O__Z(address) } } } } }
//line :497:1
			continue L1 }; break L1
		}












			return nil }()
//line :496:1
			if tmp7 == nil { A2g_Missing[bool]("class java.util.Scanner is not in the closed world") }; if tmp7 != nil { if true { var t_101122 Throwable_I = tmp7; tmp8 := func() (exc Throwable_I) { defer Catch(&exc); A2g_Missing[bool]("class java.util.Scanner is not in the closed world"); return nil }(); if tmp8 != nil { if true { var x_101123 Throwable_I = tmp8; t_101122.AddSuppressed_Throwable__V(x_101123) } }; panic(Thrown(t_101122))
			}
			}
		}











		return nil }()
//line :495:1
	if tmp9 != nil { if IOException_InstanceOf(tmp9) { var e IOException_I = IOException_Cast(tmp9); _ = e

















		panic(Thrown(UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1326, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(host), Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_hostsFile).ReplaceWith_String__Exceptions_SensitiveInfo(Lit_1324)))))) } else {
//line :495:1
			panic(tmp9)
		}
	}























	var tmp10 bool; var tmp11 bool
	tmp11 = needIPv4; if tmp11 { tmp11 = !needIPv6 }; tmp10 = tmp11
//line :521:1
	if tmp10 {

		t.CheckResultsList_List_String__V(inet4Addresses, host); return inet4Addresses.Stream__Stream() } else {
//line :521:1
			var tmp12 bool; var tmp13 bool


			tmp13 = !needIPv4; if tmp13 { tmp13 = needIPv6 }; tmp12 = tmp13
//line :521:1
			if tmp12 {



				t.CheckResultsList_List_String__V(inet6Addresses, host); return inet6Addresses.Stream__Stream() } else {


					t.CheckResultsList_List_String__V(inetAddresses, host)
					if InetAddress_Ipv6AddressesFirst_I__Z(flags) {

						return Stream_Concat_Stream_Stream__Stream(inet6Addresses.Stream__Stream(), inet4Addresses.Stream__Stream()) } else {
//line :529:1
							if InetAddress_Ipv4AddressesFirst_I__Z(flags) {



								return Stream_Concat_Stream_Stream__Stream(inet4Addresses.Stream__Stream(), inet6Addresses.Stream__Stream()) } else {


									if !A2g_AssertionsDisabled && !InetAddress_SystemAddressesOrder_I__Z(flags) { panic(Thrown(AssertionError_New())) }
									return inetAddresses.Stream__Stream()
								} } } } }
func (t *InetAddress_HostsFileResolver) CheckResultsList_List_String__V(addressesList List, hostName *String) {


	if addressesList.IsEmpty__Z() {
		panic(Thrown(UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1327, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(hostName), Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_hostsFile).ReplaceWith_String__Exceptions_SensitiveInfo(Lit_1324))))))
	}
}





func (t *InetAddress_HostsFileResolver) RemoveComments_String__String(hostsEntry *String) *String {
	var filteredEntry *String = hostsEntry; var hashIndex int32 = 0; var tmp1 int32

	hashIndex = NN(hostsEntry).IndexOf_String__I(Lit_1132); tmp1 = hashIndex; if tmp1 == -1 { } else {
		filteredEntry = NN(hostsEntry).Substring_I_I__String(0, hashIndex) }
//line :552:1
	return filteredEntry
}




func (t *InetAddress_HostsFileResolver) CreateAddressByteArray_String__B1(addrStr *String) *ByteArray {
	var addrArray *ByteArray; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		addrArray = IPAddressUtil_ValidateNumericFormatV4_String_Z__B1(addrStr, false); return nil }()
//line :560:1
	if tmp1 != nil { if IllegalArgumentException_InstanceOf(tmp1) { var iae IllegalArgumentException_I = IllegalArgumentException_Cast(tmp1); _ = iae

		return nil } else {
//line :560:1
			panic(tmp1)
		}
	}
	if addrArray == nil { addrArray = IPAddressUtil_TextToNumericFormatV6_String__B1(addrStr) }
//line :559:1
	return addrArray
}





func (t *InetAddress_HostsFileResolver) ExtractHostAddr_String_String__String(hostEntry, host *String) *String {
	var mapping *RefArray = NN(hostEntry).Split_String__String1(Lit_1322); var hostAddr *String

	if int32(len(mapping.A)) >= 2 {
		var i int32 = 1; L1: for {
			if i < int32(len(mapping.A)) {
				if NN(As[*String](mapping.A[i])).EqualsIgnoreCase_String__Z(host) {
					hostAddr = As[*String](mapping.A[0]); i = i + 1; continue L1 } else {
						i = i + 1; continue L1 } }
//line :570:1
			break L1 } }
//line :567:1
	return hostAddr
}





















func InetAddress_CreateBuiltinInetAddressResolver__InetAddressResolver() InetAddressResolver { InetAddress_Init()
	var theResolver InetAddressResolver; if !(InetAddress_HOSTS_FILE_NAME == nil) {
		theResolver = InetAddress_HostsFileResolver_New_String(InetAddress_HOSTS_FILE_NAME) } else {
			theResolver = InetAddress_PlatformResolver_New() }
//line :591:1
	return theResolver
}



func InetAddress_GetByAddress_String_B1__InetAddress(host *String, addr *ByteArray) InetAddress_I { InetAddress_Init()

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !(host == nil); if tmp3 { tmp3 = !NN(host).IsEmpty__Z() }; tmp2 = tmp3; if tmp2 { tmp2 = int32(NN(host).CharAt_I__C(0)) == 91 }; tmp1 = tmp2; if tmp1 {
		if int32(NN(host).CharAt_I__C(NN(host).Length__I()-1)) == 93 {
			host = NN(host).Substring_I_I__String(1, NN(host).Length__I()-1) } }
	if !(addr == nil) {
		if int32(len(addr.A)) == 4 {
			return Inet4Address_New_String_B1(host, addr) } else {
//line :602:1
				if int32(len(addr.A)) == 16 {


					var newAddr *ByteArray = IPAddressUtil_ConvertFromIPv4MappedAddress_B1__B1(addr)
					if !(newAddr == nil) {
						return Inet4Address_New_String_B1(host, newAddr) } else {
							return Inet6Address_New_String_B1(host, addr) } } } }
	panic(Thrown(UnknownHostException_New_String(Lit_1305)))
}
func InetAddress_GetByName_String__InetAddress(host *String) InetAddress_I { InetAddress_Init()
	return As[InetAddress_I](InetAddress_GetAllByName_String__InetAddress1(host).A[0])
}
func InetAddress_GetAllByName_String__InetAddress1(host *String) *RefArray { InetAddress_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = host == nil; if !tmp2 { tmp2 = NN(host).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		var ret *RefArray = NewRefArray(InetAddress_class, 1); ret.Store(0, InetAddress_impl.LoopbackAddress__InetAddress()); return ret } else {

			InetAddress_Validate_String__V(host)
			var ipv6Expected bool = false
			if int32(NN(host).CharAt_I__C(0)) == 91 {
				var tmp3 bool; var tmp4 bool; tmp4 = NN(host).Length__I() > 2; if tmp4 {
					tmp4 = int32(NN(host).CharAt_I__C(NN(host).Length__I()-1)) == 93 }
//line :621:1
				tmp3 = tmp4; if tmp3 {


					host = NN(host).Substring_I_I__String(1, NN(host).Length__I()-1)
					ipv6Expected = true } else {
						panic(Thrown(Up_UnknownHostException_Throwable(InetAddress_InvalidIPv6LiteralException_String_Z__UnknownHostException(host, false)))) } }
			var tmp5 bool; var tmp6 bool
			tmp6 = !(IPAddressUtil_Digit_C_I__I(NN(host).CharAt_I__C(0), 16) == -1); if !tmp6 { tmp6 = int32(NN(host).CharAt_I__C(0)) == 58 }; tmp5 = tmp6
//line :627:1
			if tmp5 {

				var inetAddress InetAddress_I
				if ipv6Expected { } else { tmp7 := func() (exc Throwable_I) { defer Catch(&exc)

					inetAddress = Up_Inet4Address_InetAddress(Inet4Address_ParseAddressString_String_Z__Inet4Address(host, false))
//line :630:1
					return nil }()
					if tmp7 != nil { if IllegalArgumentException_InstanceOf(tmp7) { var iae IllegalArgumentException_I = IllegalArgumentException_Cast(tmp7); var uhe *UnknownHostException = UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(host))))







						NN(uhe).InitCause_Throwable__Throwable(iae)
						panic(Thrown(Up_UnknownHostException_Throwable(uhe))) } else {
//line :631:1
							panic(tmp7)
						}
					}
				}






				if inetAddress == nil {
					var tmp8 bool; var tmp9 bool; var tmp10 InetAddress_I
					inetAddress = Inet6Address_ParseAddressString_String_Z__InetAddress(host, false); tmp10 = inetAddress
//line :642:1
					tmp9 = tmp10 == nil; if tmp9 {

						var tmp11 bool; tmp11 = NN(host).Contains_CharSequence__Z(Lit_1309); if !tmp11 { tmp11 = ipv6Expected }; tmp9 = tmp11 }
//line :642:1
					tmp8 = tmp9; if tmp8 {


						panic(Thrown(Up_UnknownHostException_Throwable(InetAddress_InvalidIPv6LiteralException_String_Z__UnknownHostException(host, ipv6Expected)))) } }
				if !(inetAddress == nil) { return RefArrayOf(InetAddress_class, inetAddress) } } else {
//line :627:1
					if ipv6Expected {



















						panic(Thrown(Up_UnknownHostException_Throwable(InetAddress_InvalidIPv6LiteralException_String_Z__UnknownHostException(host, true)))) } }
			return InetAddress_GetAllByName0_String_Z__InetAddress1(host, true)
		} }
func InetAddress_InvalidIPv6LiteralException_String_Z__UnknownHostException(host *String, wrapInBrackets bool) *UnknownHostException { InetAddress_Init()

	var hostString *String; if wrapInBrackets { hostString = Concat(Lit_1318, host, Lit_1189) } else { hostString = host }
	return UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1319, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(hostString).SuffixWith_String__Exceptions_SensitiveInfo(Lit_1157))))
}




func InetAddress_GetLoopbackAddress__InetAddress() InetAddress_I { InetAddress_Init()
	return InetAddress_impl.LoopbackAddress__InetAddress()
}
func InetAddress_GetAllByName0_String__InetAddress1(host *String) *RefArray { InetAddress_Init()
	return InetAddress_GetAllByName0_String_Z__InetAddress1(host, true)
}
func InetAddress_OfLiteral_String__InetAddress(ipAddressLiteral *String) InetAddress_I { InetAddress_Init()
	Objects_RequireNonNull_O__O(ipAddressLiteral.Ref())
	if NN(ipAddressLiteral).IsEmpty__Z() {
		panic(Thrown(IPAddressUtil_InvalidIpAddressLiteral_String__IllegalArgumentException(ipAddressLiteral))) }
	var inetAddress InetAddress_I; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		inetAddress = Up_Inet4Address_InetAddress(Inet4Address_OfLiteral_String__Inet4Address(ipAddressLiteral)); return nil }()
//line :670:1
	if tmp1 != nil { if IllegalArgumentException_InstanceOf(tmp1) { var iae IllegalArgumentException_I = IllegalArgumentException_Cast(tmp1); _ = iae


		inetAddress = Inet6Address_OfLiteral_String__InetAddress(ipAddressLiteral) } else {
//line :670:1
			panic(tmp1) } }
//line :669:1
	return inetAddress
}
























func InetAddress_GetAddressesFromNameService_String__InetAddress1(host *String) *RefArray { InetAddress_Init()
	var addresses Stream; var ex *UnknownHostException; var resolver InetAddressResolver = InetAddress_Resolver__InetAddressResolver(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)



		addresses = resolver.LookupByName_String_InetAddressResolver_LookupPolicy__Stream(host, InetAddress_PLATFORM_LOOKUP_POLICY); return nil }()
//line :699:1
	if tmp1 != nil { if RuntimeException_InstanceOf(tmp1) || UnknownHostException_InstanceOf(tmp1) { var x Exception_I = Exception_Cast(tmp1)


		if NN(host).EqualsIgnoreCase_String__Z(Lit_1303) {
			addresses = Stream_Of_O__Stream(InetAddress_impl.LoopbackAddress__InetAddress()) } else {
				var tmp2 Exception_I = x; if UnknownHostException_InstanceOf(tmp2) { var uhe *UnknownHostException = UnknownHostException_Cast(tmp2)
					ex = uhe } else {
						ex = UnknownHostException_New(); NN(ex).InitCause_Throwable__Throwable(x) } } } else {
//line :699:1
							panic(tmp1)
						}
	}





	var result *RefArray; if !(addresses == nil) {
		result = A2g_CastArray[*RefArray](addresses.ToArray_IntFunction__O1(&IntFunction_Fn{Fn: func(p0 int32) any { var n_1 int32 = p0; return NewRefArray(InetAddress_class, n_1).Ref() }}).Ref(), InetAddress_class.ArrayClass()) } else {
//line :707:1
			result = nil
		}





	var tmp3 bool; var tmp4 bool; tmp4 = result == nil; if !tmp4 { tmp4 = int32(len(result.A)) == 0 }; tmp3 = tmp4; if tmp3 {
		var tmp5 *UnknownHostException; if ex == nil {
			tmp5 = UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(host)))) } else {
//line :715:1
				tmp5 = ex }; panic(Thrown(Up_UnknownHostException_Throwable(tmp5))) }
//line :707:1
	return result
}















func InetAddress_GetByAddress_B1__InetAddress(addr *ByteArray) InetAddress_I { InetAddress_Init()
	return InetAddress_GetByAddress_String_B1__InetAddress(nil, addr)
}







func InetAddress_CachedLocalHost_New_String_InetAddress(p0 *String, p1 InetAddress_I) *InetAddress_CachedLocalHost { t := &InetAddress_CachedLocalHost{}; t.Ctor_String_InetAddress(p0, p1); return t }
//line :734:1
func (t *InetAddress_CachedLocalHost) Ctor_String_InetAddress(host *String, addr InetAddress_I) { t.F_expiryTime = System_NanoTime__J() + 5000000000
	t.F_host = host
	t.F_addr = addr
}


func InetAddress_GetLocalHost__InetAddress() InetAddress_I { InetAddress_Init()
	var clh *InetAddress_CachedLocalHost = InetAddress_cachedLocalHost.Load(); var tmp1 bool; var tmp2 bool
	tmp2 = !(clh == nil); if tmp2 { var tmp3 int64 = clh.F_expiryTime; tmp2 = tmp3-System_NanoTime__J() >= 0 }; tmp1 = tmp2; if tmp1 {
		return clh.F_addr } else {
			var local *String = InetAddress_impl.GetLocalHostName__String(); var localAddr InetAddress_I

			if NN(local).Equals_O__Z(Lit_1303) {
				localAddr = InetAddress_impl.LoopbackAddress__InetAddress() } else { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

					localAddr = As[InetAddress_I](InetAddress_GetAllByName0_String_Z__InetAddress1(local, false).A[0]); return nil }()
//line :748:1
					if tmp4 != nil { if UnknownHostException_InstanceOf(tmp4) { var uhe *UnknownHostException = UnknownHostException_Cast(tmp4); var uhe2 *UnknownHostException = UnknownHostException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Concat(StrOfObj(Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(local).SuffixWith_String__Exceptions_SensitiveInfo(Lit_1157)), NN(uhe).GetMessage__String()), RefArrayOf(Exceptions_SensitiveInfo_class)))









						NN(uhe2).InitCause_Throwable__Throwable(Up_UnknownHostException_Throwable(uhe))
						panic(Thrown(Up_UnknownHostException_Throwable(uhe2))) } else {
//line :748:1
							panic(tmp4)
						}
					}
				}








			InetAddress_cachedLocalHost.Store(InetAddress_CachedLocalHost_New_String_InetAddress(local, localAddr))
//line :744:1
			return localAddr
		}
}


















func InetAddress_AnyLocalAddress__InetAddress() InetAddress_I { InetAddress_Init()
	return InetAddress_impl.AnyLocalAddress__InetAddress()
}




























func InetAddress_Validate_String__V(host *String) { InetAddress_Init()
	if NN(host).IndexOf_I__I(0) == -1 { } else {
		panic(Thrown(UnknownHostException_New_String(Lit_1320)))
	}
}

type InetAddress struct{ Object; F_holder *InetAddress_InetAddressHolder; F_canonicalHostName *String }

type InetAddress_I interface{ Object_I; Serializable; Self_InetAddress() *InetAddress; Holder__InetAddress_InetAddressHolder() *InetAddress_InetAddressHolder; IsMulticastAddress__Z() bool; IsAnyLocalAddress__Z() bool; IsLoopbackAddress__Z() bool; IsLinkLocalAddress__Z() bool; IsSiteLocalAddress__Z() bool; IsMCGlobal__Z() bool; IsMCNodeLocal__Z() bool; IsMCLinkLocal__Z() bool; IsMCSiteLocal__Z() bool; IsMCOrgLocal__Z() bool; IsReachable_I__Z(p0 int32) bool; GetHostName__String() *String; GetCanonicalHostName__String() *String; GetAddress__B1() *ByteArray; GetHostAddress__String() *String }

func (t *InetAddress) Self_InetAddress() *InetAddress { return t }

func (t *InetAddress) Is_Serializable() {}

const InetAddress_IPv4 int32 = 1

const InetAddress_IPv6 int32 = 2

var InetAddress_resolver Volatile[InetAddressResolver]

var InetAddress_BUILTIN_RESOLVER InetAddressResolver

const InetAddress_serialVersionUID int64 = 3286316764910316507

var InetAddress_PREFER_IPV4_STACK_VALUE *String

var InetAddress_PREFER_IPV6_ADDRESSES_VALUE *String

var InetAddress_HOSTS_FILE_NAME *String

var InetAddress_RESOLVER_LOCK *ReentrantLock

var InetAddress_bootstrapResolver Volatile[InetAddressResolver]

var InetAddress_cache ConcurrentMap

var InetAddress_impl InetAddressImpl

var InetAddress_PLATFORM_LOOKUP_POLICY *InetAddressResolver_LookupPolicy

var InetAddress_cachedLocalHost atomic.Pointer[InetAddress_CachedLocalHost]

var InetAddress_UNSAFE *Unsafe

var InetAddress_FIELDS_OFFSET int64

var InetAddress_init ClassInit

func InetAddress_Init() { if !InetAddress_init.Done() { InetAddress_init.Run(InetAddress_clinit) } }

func InetAddress_clinit() {
//line :24:1
	InetAddress_PREFER_IPV4_STACK_VALUE = System_GetProperty_String__String(Lit_1312)
	InetAddress_PREFER_IPV6_ADDRESSES_VALUE = System_GetProperty_String__String(Lit_1313)
	InetAddress_HOSTS_FILE_NAME = System_GetProperty_String__String(Lit_1314)



















































































































































































































































































































































































































































































































































































































































































































































































































































	InetAddress_RESOLVER_LOCK = ReentrantLock_New(); InetAddress_cache = ConcurrentHashMap_New()
//line :583:1
	var tmp1 InetAddressImpl
	if InetAddress_IsIPv6Supported__Z() {
		tmp1 = Inet6AddressImpl_New() } else {
			tmp1 = Inet4AddressImpl_New() }
//line :583:1
	InetAddress_impl = tmp1



	InetAddress_PLATFORM_LOOKUP_POLICY = InetAddress_InitializePlatformLookupPolicy__InetAddressResolver_LookupPolicy()
	InetAddress_BUILTIN_RESOLVER = InetAddress_CreateBuiltinInetAddressResolver__InetAddressResolver()
//line :583:1
	InetAddress_UNSAFE = Unsafe_GetUnsafe__Unsafe(); InetAddress_FIELDS_OFFSET = NN(InetAddress_UNSAFE).ObjectFieldOffset_Class_String__J(InetAddress_class, Lit_1315)
}







































































































































































































































































func (t *InetAddress) IsAnyLocalAddress__Z() bool { return t.Impl_IsAnyLocalAddress__Z(t) }

func (t *InetAddress) IsMCGlobal__Z() bool { return t.Impl_IsMCGlobal__Z(t) }

func (t *InetAddress) IsLoopbackAddress__Z() bool { return t.Impl_IsLoopbackAddress__Z(t) }

func (t *InetAddress) IsMulticastAddress__Z() bool { return t.Impl_IsMulticastAddress__Z(t) }

func (t *InetAddress) Holder__InetAddress_InetAddressHolder() *InetAddress_InetAddressHolder { return t.Impl_Holder__InetAddress_InetAddressHolder(t) }

func (t *InetAddress) GetAddress__B1() *ByteArray { return t.Impl_GetAddress__B1(t) }

func (t *InetAddress) IsLinkLocalAddress__Z() bool { return t.Impl_IsLinkLocalAddress__Z(t) }

func (t *InetAddress) IsReachable_I__Z(p0 int32) bool { return t.Impl_IsReachable_I__Z(t, p0) }

func (t *InetAddress) GetHostAddress__String() *String { return t.Impl_GetHostAddress__String(t) }

func (t *InetAddress) IsMCOrgLocal__Z() bool { return t.Impl_IsMCOrgLocal__Z(t) }

func (t *InetAddress) GetHostName__String() *String { return t.Impl_GetHostName__String(t) }

func (t *InetAddress) IsMCNodeLocal__Z() bool { return t.Impl_IsMCNodeLocal__Z(t) }

func (t *InetAddress) IsMCLinkLocal__Z() bool { return t.Impl_IsMCLinkLocal__Z(t) }

func (t *InetAddress) IsMCSiteLocal__Z() bool { return t.Impl_IsMCSiteLocal__Z(t) }

func (t *InetAddress) IsSiteLocalAddress__Z() bool { return t.Impl_IsSiteLocalAddress__Z(t) }

func (t *InetAddress) GetCanonicalHostName__String() *String { return t.Impl_GetCanonicalHostName__String(t) }

func (t *InetAddress) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *InetAddress) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *InetAddress) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InetAddress) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress) GetClass__Class() *Class { return InetAddress_class }

func (t *InetAddress) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_InstanceOf(x any) bool { _, ok := x.(InetAddress_I); return ok }

func InetAddress_Cast(x any) InetAddress_I { if x == nil { return nil }; v, ok := x.(InetAddress_I); if !ok { panic(ClassCast(x, InetAddress_class)) }; return v }



type InetAddress_Addresses interface{ Object_I; Is_InetAddress_Addresses(); Get__InetAddress1() *RefArray }

func InetAddress_Addresses_InstanceOf(x any) bool { _, ok := x.(InetAddress_Addresses); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InetAddress_Addresses_class) } }; return ok }

func InetAddress_Addresses_Cast(x any) InetAddress_Addresses { if x == nil { return nil }; v, ok := x.(InetAddress_Addresses); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InetAddress_Addresses_class) } }; if !ok { panic(ClassCast(x, InetAddress_Addresses_class)) }; return v }



type InetAddress_CachedLocalHost struct{ Object; F_host *String; F_addr InetAddress_I; F_expiryTime int64 }

func (t *InetAddress_CachedLocalHost) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress_CachedLocalHost) GetClass__Class() *Class { return InetAddress_CachedLocalHost_class }

func (t *InetAddress_CachedLocalHost) ToString__String() *String { return Object_toString(t) }

func (t *InetAddress_CachedLocalHost) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress_CachedLocalHost) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_CachedLocalHost_InstanceOf(x any) bool { _, ok := x.(*InetAddress_CachedLocalHost); return ok }

func InetAddress_CachedLocalHost_Cast(x any) *InetAddress_CachedLocalHost { if x == nil { return nil }; v, ok := x.(*InetAddress_CachedLocalHost); if !ok { panic(ClassCast(x, InetAddress_CachedLocalHost_class)) }; return v }



type InetAddress_CachedLookup struct{ Object; F_host *String; F_inetAddresses atomic.Pointer[RefArray]; F_expiryTime atomic.Int64; F_id int64 }

type InetAddress_CachedLookup_I interface{ Object_I; InetAddress_Addresses; Comparable; Self_InetAddress_CachedLookup() *InetAddress_CachedLookup; Get__InetAddress1() *RefArray; CompareTo_InetAddress_CachedLookup__I(p0 InetAddress_CachedLookup_I) int32; TryRemoveExpiredAddress_J__Z(p0 int64) bool; CompareTo_O__I(p0 any) int32 }

func (t *InetAddress_CachedLookup) Self_InetAddress_CachedLookup() *InetAddress_CachedLookup { return t }

func (t *InetAddress_CachedLookup) Is_InetAddress_Addresses() {}

func (t *InetAddress_CachedLookup) Is_Comparable() {}

var InetAddress_CachedLookup_seq *AtomicLong

var InetAddress_CachedLookup_init ClassInit

func InetAddress_CachedLookup_Init() { if !InetAddress_CachedLookup_init.Done() { InetAddress_CachedLookup_init.Run(InetAddress_CachedLookup_clinit) } }

func InetAddress_CachedLookup_clinit() { InetAddress_CachedLookup_seq = AtomicLong_New() }

func (t *InetAddress_CachedLookup) Impl_CompareTo_O__I(this InetAddress_CachedLookup_I, p0 any) int32 { return this.CompareTo_InetAddress_CachedLookup__I(InetAddress_CachedLookup_Cast(p0)) }

func (t *InetAddress_CachedLookup) Get__InetAddress1() *RefArray { return t.Impl_Get__InetAddress1(t) }

func (t *InetAddress_CachedLookup) CompareTo_InetAddress_CachedLookup__I(p0 InetAddress_CachedLookup_I) int32 { return t.Impl_CompareTo_InetAddress_CachedLookup__I(t, p0) }

func (t *InetAddress_CachedLookup) TryRemoveExpiredAddress_J__Z(p0 int64) bool { return t.Impl_TryRemoveExpiredAddress_J__Z(t, p0) }

func (t *InetAddress_CachedLookup) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *InetAddress_CachedLookup) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress_CachedLookup) GetClass__Class() *Class { return InetAddress_CachedLookup_class }

func (t *InetAddress_CachedLookup) ToString__String() *String { return Object_toString(t) }

func (t *InetAddress_CachedLookup) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress_CachedLookup) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_CachedLookup_InstanceOf(x any) bool { _, ok := x.(InetAddress_CachedLookup_I); return ok }

func InetAddress_CachedLookup_Cast(x any) InetAddress_CachedLookup_I { if x == nil { return nil }; v, ok := x.(InetAddress_CachedLookup_I); if !ok { panic(ClassCast(x, InetAddress_CachedLookup_class)) }; return v }



type InetAddress_HostsFileResolver struct{ Object; F_hostsFile *String }

func (t *InetAddress_HostsFileResolver) Is_InetAddressResolver() {}

var InetAddress_HostsFileResolver_init ClassInit

func InetAddress_HostsFileResolver_Init() { if !InetAddress_HostsFileResolver_init.Done() { InetAddress_HostsFileResolver_init.Run(InetAddress_HostsFileResolver_clinit) } }

func InetAddress_HostsFileResolver_clinit() {}

func (t *InetAddress_HostsFileResolver) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress_HostsFileResolver) GetClass__Class() *Class { return InetAddress_HostsFileResolver_class }

func (t *InetAddress_HostsFileResolver) ToString__String() *String { return Object_toString(t) }

func (t *InetAddress_HostsFileResolver) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress_HostsFileResolver) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_HostsFileResolver_InstanceOf(x any) bool { _, ok := x.(*InetAddress_HostsFileResolver); return ok }

func InetAddress_HostsFileResolver_Cast(x any) *InetAddress_HostsFileResolver { if x == nil { return nil }; v, ok := x.(*InetAddress_HostsFileResolver); if !ok { panic(ClassCast(x, InetAddress_HostsFileResolver_class)) }; return v }



type InetAddress_InetAddressHolder struct{ Object; F_originalHostName, F_hostName *String; F_address, F_family int32 }

func (t *InetAddress_InetAddressHolder) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress_InetAddressHolder) GetClass__Class() *Class { return InetAddress_InetAddressHolder_class }

func (t *InetAddress_InetAddressHolder) ToString__String() *String { return Object_toString(t) }

func (t *InetAddress_InetAddressHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress_InetAddressHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_InetAddressHolder_InstanceOf(x any) bool { _, ok := x.(*InetAddress_InetAddressHolder); return ok }

func InetAddress_InetAddressHolder_Cast(x any) *InetAddress_InetAddressHolder { if x == nil { return nil }; v, ok := x.(*InetAddress_InetAddressHolder); if !ok { panic(ClassCast(x, InetAddress_InetAddressHolder_class)) }; return v }



type InetAddress_NameServiceAddresses struct{ Object; F_host *String; F_lookupLock *ReentrantLock }

func (t *InetAddress_NameServiceAddresses) Is_InetAddress_Addresses() {}

func (t *InetAddress_NameServiceAddresses) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress_NameServiceAddresses) GetClass__Class() *Class { return InetAddress_NameServiceAddresses_class }

func (t *InetAddress_NameServiceAddresses) ToString__String() *String { return Object_toString(t) }

func (t *InetAddress_NameServiceAddresses) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress_NameServiceAddresses) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_NameServiceAddresses_InstanceOf(x any) bool { _, ok := x.(*InetAddress_NameServiceAddresses); return ok }

func InetAddress_NameServiceAddresses_Cast(x any) *InetAddress_NameServiceAddresses { if x == nil { return nil }; v, ok := x.(*InetAddress_NameServiceAddresses); if !ok { panic(ClassCast(x, InetAddress_NameServiceAddresses_class)) }; return v }



type InetAddress_PlatformResolver struct{ Object }

func (t *InetAddress_PlatformResolver) Is_InetAddressResolver() {}

func InetAddress_PlatformResolver_New() *InetAddress_PlatformResolver { t := &InetAddress_PlatformResolver{}; t.Ctor(); return t }

func (t *InetAddress_PlatformResolver) Ctor() {}

func (t *InetAddress_PlatformResolver) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress_PlatformResolver) GetClass__Class() *Class { return InetAddress_PlatformResolver_class }

func (t *InetAddress_PlatformResolver) ToString__String() *String { return Object_toString(t) }

func (t *InetAddress_PlatformResolver) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress_PlatformResolver) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_PlatformResolver_InstanceOf(x any) bool { _, ok := x.(*InetAddress_PlatformResolver); return ok }

func InetAddress_PlatformResolver_Cast(x any) *InetAddress_PlatformResolver { if x == nil { return nil }; v, ok := x.(*InetAddress_PlatformResolver); if !ok { panic(ClassCast(x, InetAddress_PlatformResolver_class)) }; return v }



type InetAddress_ValidCachedLookup struct{ InetAddress_CachedLookup; F_refreshTime, F_staleTime atomic.Int64; F_lookupLock Lock }

var InetAddress_ValidCachedLookup_init ClassInit

func InetAddress_ValidCachedLookup_Init() { if !InetAddress_ValidCachedLookup_init.Done() { InetAddress_ValidCachedLookup_init.Run(InetAddress_ValidCachedLookup_clinit) } }

func InetAddress_ValidCachedLookup_clinit() { InetAddress_CachedLookup_Init() }

func (t *InetAddress_ValidCachedLookup) CompareTo_InetAddress_CachedLookup__I(p0 InetAddress_CachedLookup_I) int32 { return t.Impl_CompareTo_InetAddress_CachedLookup__I(t, p0) }

func (t *InetAddress_ValidCachedLookup) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *InetAddress_ValidCachedLookup) Ref() any { if t == nil { return nil }; return t }

func (t *InetAddress_ValidCachedLookup) GetClass__Class() *Class { return InetAddress_ValidCachedLookup_class }

func (t *InetAddress_ValidCachedLookup) ToString__String() *String { return Object_toString(t) }

func (t *InetAddress_ValidCachedLookup) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InetAddress_ValidCachedLookup) CloneShallow() any { panic(CloneNotSupported(t)) }

func InetAddress_ValidCachedLookup_InstanceOf(x any) bool { _, ok := x.(*InetAddress_ValidCachedLookup); return ok }

func InetAddress_ValidCachedLookup_Cast(x any) *InetAddress_ValidCachedLookup { if x == nil { return nil }; v, ok := x.(*InetAddress_ValidCachedLookup); if !ok { panic(ClassCast(x, InetAddress_ValidCachedLookup_class)) }; return v }
