//line java_util_Optional.ae:1
package jrt















func Optional_Empty__Optional() *Optional { Optional_Init()
	var t_ *Optional = Optional_EMPTY; return t_
}
func Optional_New_O(p0 any) *Optional { Optional_Init(); t := &Optional{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *Optional) Ctor_O(value any) { t.F_value = value }

func Optional_Of_O__Optional(value any) *Optional {
	return Optional_New_O(Objects_RequireNonNull_O__O(value))
}
func Optional_OfNullable_O__Optional(value any) *Optional { Optional_Init()
	if value == nil { return Optional_EMPTY } else { return Optional_New_O(value)
	} }
func (t *Optional) Get__O() any {
	if t.F_value == nil { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :28:1
	return t.F_value
}


func (t *Optional) IsPresent__Z() bool { return !(t.F_value == nil) }

func (t *Optional) IsEmpty__Z() bool { return t.F_value == nil }

func (t *Optional) IfPresent_Consumer__V(action Consumer) {
	if !(t.F_value == nil) { action.Accept_O__V(t.F_value)
	} }
func (t *Optional) IfPresentOrElse_Consumer_Runnable__V(action Consumer, emptyAction Runnable) {

	if !(t.F_value == nil) { action.Accept_O__V(t.F_value) } else { emptyAction.Run__V()
	} }
func (t *Optional) Filter_Predicate__Optional(predicate Predicate) *Optional {
	Objects_RequireNonNull_O__O(predicate)
	if t.IsEmpty__Z() { return t } else { if predicate.Test_O__Z(t.F_value) { return t } else { return Optional_Empty__Optional()
	} } }
func (t *Optional) Map_Function__Optional(mapper Function) *Optional {

	Objects_RequireNonNull_O__O(mapper)
	if t.IsEmpty__Z() { return Optional_Empty__Optional() } else { return Optional_OfNullable_O__Optional(mapper.Apply_O__O(t.F_value))
	} }
func (t *Optional) FlatMap_Function__Optional(mapper Function) *Optional {

	Objects_RequireNonNull_O__O(mapper)
	if t.IsEmpty__Z() {
		return Optional_Empty__Optional() } else {
			var r *Optional = Optional_Cast(mapper.Apply_O__O(t.F_value))
			return Optional_Cast(Objects_RequireNonNull_O__O(r.Ref()))
		} }
func (t *Optional) Or_Supplier__Optional(supplier Supplier) *Optional {

	Objects_RequireNonNull_O__O(supplier)
	if t.IsPresent__Z() { return t } else {

		var r *Optional = Optional_Cast(supplier.Get__O())
		return Optional_Cast(Objects_RequireNonNull_O__O(r.Ref()))
	} }
func (t *Optional) Stream__Stream() Stream {
	if t.IsEmpty__Z() { return Stream_Empty__Stream() } else { return Stream_Of_O__Stream(t.F_value)
	} }
func (t *Optional) OrElse_O__O(other any) any {
	if !(t.F_value == nil) { return t.F_value } else { return other
	} }
func (t *Optional) OrElseGet_Supplier__O(supplier Supplier) any {
	if !(t.F_value == nil) { return t.F_value } else { return supplier.Get__O()
	} }
func (t *Optional) OrElseThrow__O() any {
	if t.F_value == nil { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :77:1
	return t.F_value
}


func (t *Optional) OrElseThrow_Supplier__O(exceptionSupplier Supplier) any {

	if !(t.F_value == nil) { return t.F_value } else { panic(Thrown(Throwable_Cast(exceptionSupplier.Get__O())))
	} }
func (t *Optional) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if Optional_InstanceOf(tmp1) { var other *Optional = Optional_Cast(tmp1); var tmp2 any = t.F_value; return Objects_Equals_O_O__Z(tmp2, other.F_value) } else { return false
		} } }
func (t *Optional) HashCode__I() int32 { return Objects_HashCode_O__I(t.F_value) }

func (t *Optional) ToString__String() *String {
	if !(t.F_value == nil) { return Concat(Lit_2794, StrOfObj(t.F_value), Lit_1189) } else { return Lit_2795
	}
}

type Optional struct{ Object; F_value any }

var Optional_EMPTY *Optional

var Optional_init ClassInit

func Optional_Init() { if !Optional_init.Done() { Optional_init.Run(Optional_clinit) } }

func Optional_clinit() { Optional_EMPTY = Optional_New_O(nil) }

func (t *Optional) Ref() any { if t == nil { return nil }; return t }

func (t *Optional) GetClass__Class() *Class { return Optional_class }

func (t *Optional) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Optional) CloneShallow() any { panic(CloneNotSupported(t)) }

func Optional_InstanceOf(x any) bool { _, ok := x.(*Optional); return ok }

func Optional_Cast(x any) *Optional { if x == nil { return nil }; v, ok := x.(*Optional); if !ok { panic(ClassCast(x, Optional_class)) }; return v }
