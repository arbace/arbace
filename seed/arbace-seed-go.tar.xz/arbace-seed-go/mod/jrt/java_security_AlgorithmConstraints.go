//line java_security_AlgorithmConstraints.ae:1
package jrt






type AlgorithmConstraints interface{ Object_I; Is_AlgorithmConstraints(); Permits_Set_Key__Z(p0 Set, p1 Key) bool }

func AlgorithmConstraints_InstanceOf(x any) bool { _, ok := x.(AlgorithmConstraints); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AlgorithmConstraints_class) } }; return ok }

func AlgorithmConstraints_Cast(x any) AlgorithmConstraints { if x == nil { return nil }; v, ok := x.(AlgorithmConstraints); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AlgorithmConstraints_class) } }; if !ok { panic(ClassCast(x, AlgorithmConstraints_class)) }; return v }
