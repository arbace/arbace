//line java_util_NavigableMap.ae:1
package jrt


















































func NavigableMap_Reversed__NavigableMap(this NavigableMap) NavigableMap {
	return this.DescendingMap__NavigableMap()
}


type NavigableMap interface{ Object_I; SortedMap; SequencedMap; Map; Is_NavigableMap(); LowerEntry_O__Map_Entry(p0 any) Map_Entry; LowerKey_O__O(p0 any) any; FloorEntry_O__Map_Entry(p0 any) Map_Entry; FloorKey_O__O(p0 any) any; CeilingEntry_O__Map_Entry(p0 any) Map_Entry; CeilingKey_O__O(p0 any) any; HigherEntry_O__Map_Entry(p0 any) Map_Entry; HigherKey_O__O(p0 any) any; FirstEntry__Map_Entry() Map_Entry; LastEntry__Map_Entry() Map_Entry; PollFirstEntry__Map_Entry() Map_Entry; PollLastEntry__Map_Entry() Map_Entry; DescendingMap__NavigableMap() NavigableMap; NavigableKeySet__NavigableSet() NavigableSet; DescendingKeySet__NavigableSet() NavigableSet; SubMap_O_Z_O_Z__NavigableMap(p0 any, p1 bool, p2 any, p3 bool) NavigableMap; HeadMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap; TailMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap; SubMap_O_O__SortedMap(p0, p1 any) SortedMap; HeadMap_O__SortedMap(p0 any) SortedMap; TailMap_O__SortedMap(p0 any) SortedMap; Reversed__NavigableMap() NavigableMap; Reversed__SortedMap() SortedMap; Reversed__SequencedMap() SequencedMap }

func NavigableMap_Reversed__SortedMap(this NavigableMap) SortedMap { return this.Reversed__NavigableMap() }

func NavigableMap_Reversed__SequencedMap(this NavigableMap) SequencedMap { return this.Reversed__NavigableMap() }

func NavigableMap_InstanceOf(x any) bool { _, ok := x.(NavigableMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(NavigableMap_class) } }; return ok }

func NavigableMap_Cast(x any) NavigableMap { if x == nil { return nil }; v, ok := x.(NavigableMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(NavigableMap_class) } }; if !ok { panic(ClassCast(x, NavigableMap_class)) }; return v }
