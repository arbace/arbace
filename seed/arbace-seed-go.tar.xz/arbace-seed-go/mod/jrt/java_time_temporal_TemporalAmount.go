//line java_time_temporal_TemporalAmount.ae:1
package jrt






type TemporalAmount interface{ Object_I; Is_TemporalAmount(); Get_TemporalUnit__J(p0 TemporalUnit) int64; GetUnits__List() List; AddTo_Temporal__Temporal(p0 Temporal) Temporal; SubtractFrom_Temporal__Temporal(p0 Temporal) Temporal }

func TemporalAmount_InstanceOf(x any) bool { _, ok := x.(TemporalAmount); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalAmount_class) } }; return ok }

func TemporalAmount_Cast(x any) TemporalAmount { if x == nil { return nil }; v, ok := x.(TemporalAmount); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalAmount_class) } }; if !ok { panic(ClassCast(x, TemporalAmount_class)) }; return v }
