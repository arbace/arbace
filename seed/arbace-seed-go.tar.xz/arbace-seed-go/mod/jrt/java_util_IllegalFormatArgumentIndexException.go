//line java_util_IllegalFormatArgumentIndexException.ae:1
package jrt










func IllegalFormatArgumentIndexException_New_I(p0 int32) *IllegalFormatArgumentIndexException { t := &IllegalFormatArgumentIndexException{}; t.Ctor_I(p0); return t }
//line :12:1
func (t *IllegalFormatArgumentIndexException) Ctor_I(index int32) { t.IllegalFormatException.Ctor(t); t.F_illegalIndex = index }

func (t *IllegalFormatArgumentIndexException) GetIndex__I() int32 { return t.F_illegalIndex }

func (t *IllegalFormatArgumentIndexException) GetMessage__String() *String {
	var index int32 = t.GetIndex__I()
	if index == -2147483648 { return Lit_2725 } else {

		return String_Format_String_O1__String(Lit_2726, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(t.GetIndex__I())))
	} }
type IllegalFormatArgumentIndexException struct{ IllegalFormatException; F_illegalIndex int32 }

const IllegalFormatArgumentIndexException_serialVersionUID int64 = 4191767811181838112

func (t *IllegalFormatArgumentIndexException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalFormatArgumentIndexException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalFormatArgumentIndexException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalFormatArgumentIndexException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalFormatArgumentIndexException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalFormatArgumentIndexException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalFormatArgumentIndexException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalFormatArgumentIndexException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalFormatArgumentIndexException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalFormatArgumentIndexException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalFormatArgumentIndexException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalFormatArgumentIndexException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalFormatArgumentIndexException) GetClass__Class() *Class { return IllegalFormatArgumentIndexException_class }

func (t *IllegalFormatArgumentIndexException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalFormatArgumentIndexException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalFormatArgumentIndexException_InstanceOf(x any) bool { _, ok := x.(*IllegalFormatArgumentIndexException); return ok }

func IllegalFormatArgumentIndexException_Cast(x any) *IllegalFormatArgumentIndexException { if x == nil { return nil }; v, ok := x.(*IllegalFormatArgumentIndexException); if !ok { panic(ClassCast(x, IllegalFormatArgumentIndexException_class)) }; return v }
