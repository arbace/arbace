//line java_security_SecureRandomParameters.ae:1
package jrt






type SecureRandomParameters interface{ Object_I; Is_SecureRandomParameters() }

func SecureRandomParameters_InstanceOf(x any) bool { _, ok := x.(SecureRandomParameters); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SecureRandomParameters_class) } }; return ok }

func SecureRandomParameters_Cast(x any) SecureRandomParameters { if x == nil { return nil }; v, ok := x.(SecureRandomParameters); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SecureRandomParameters_class) } }; if !ok { panic(ClassCast(x, SecureRandomParameters_class)) }; return v }
