//line java_util_SortedMap.ae:1
package jrt

























func SortedMap_PutFirst_O_O__O(this SortedMap, k, v any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SortedMap_PutLast_O_O__O(this SortedMap, k, v any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SortedMap_Reversed__SortedMap(this SortedMap) SortedMap {
	return ReverseOrderSortedMapView_Of_SortedMap__SortedMap(this)
}


type SortedMap interface{ Object_I; SequencedMap; Map; Is_SortedMap(); Comparator__Comparator() Comparator; SubMap_O_O__SortedMap(p0, p1 any) SortedMap; HeadMap_O__SortedMap(p0 any) SortedMap; TailMap_O__SortedMap(p0 any) SortedMap; FirstKey__O() any; LastKey__O() any; KeySet__Set() Set; Values__Collection() Collection; EntrySet__Set() Set; PutFirst_O_O__O(p0, p1 any) any; PutLast_O_O__O(p0, p1 any) any; Reversed__SortedMap() SortedMap; Reversed__SequencedMap() SequencedMap }

func SortedMap_Reversed__SequencedMap(this SortedMap) SequencedMap { return this.Reversed__SortedMap() }

func SortedMap_InstanceOf(x any) bool { _, ok := x.(SortedMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SortedMap_class) } }; return ok }

func SortedMap_Cast(x any) SortedMap { if x == nil { return nil }; v, ok := x.(SortedMap); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SortedMap_class) } }; if !ok { panic(ClassCast(x, SortedMap_class)) }; return v }
