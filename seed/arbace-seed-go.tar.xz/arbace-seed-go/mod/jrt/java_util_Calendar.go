//line java_util_Calendar.ae:1
package jrt























































































































































func (t *Calendar) Ctor(this Calendar_I) { panic(A2g_NotTranslated("java.util.Calendar.<init>()V")) }


func (t *Calendar) Ctor_TimeZone_Locale(this Calendar_I, zone TimeZone_I, aLocale *Locale) { t.F_nextStamp = 2; t.F_lenient = true
	t.F_fields = NewIntArray(17)
	t.F_isSet = NewBooleanArray(17)
	t.F_stamp = NewIntArray(17)
	t.F_zone = zone
	t.Impl_SetWeekCountData_Locale__V(this, aLocale)
}



func (t *Calendar) Impl_SetWeekCountData_Locale__V(this Calendar_I, desiredLocale *Locale) {
	var data *IntArray = A2g_CastArray[*IntArray](Calendar_cachedLocaleData.Get_O__O(desiredLocale.Ref()), Prim_int.ArrayClass())
	if data == nil {
		data = NewIntArray(2)
		data.A[0] = CalendarDataUtility_RetrieveFirstDayOfWeek_Locale__I(desiredLocale)
		data.A[1] = CalendarDataUtility_RetrieveMinimalDaysInFirstWeek_Locale__I(desiredLocale)
		Calendar_cachedLocaleData.PutIfAbsent_O_O__O(desiredLocale.Ref(), data.Ref()) }
	t.F_firstDayOfWeek = data.A[0]
	t.F_minimalDaysInFirstWeek = data.A[1]
}
func Calendar_GetInstance__Calendar() Calendar_I { Calendar_Init(); return GregorianCalendar_New() }

func Calendar_GetInstance_TimeZone__Calendar(zone TimeZone_I) Calendar_I { Calendar_Init()
	return GregorianCalendar_New_TimeZone(zone)
}
func Calendar_GetInstance_Locale__Calendar(aLocale *Locale) Calendar_I { Calendar_Init()
	return GregorianCalendar_New_Locale(aLocale)
}
func Calendar_GetInstance_TimeZone_Locale__Calendar(zone TimeZone_I, aLocale *Locale) Calendar_I { Calendar_Init()
	return GregorianCalendar_New_TimeZone_Locale(zone, aLocale)
}
func Calendar_GetAvailableLocales__Locale1() *RefArray { Calendar_Init(); MonitorEnter(Calendar_class); defer MonitorExit(Calendar_class)
	return DateFormat_GetAvailableLocales__Locale1()
}
func Calendar_GetAvailableCalendarTypes__Set() Set { Calendar_Init()
	var s Set = HashSet_New(); s.Add_O__Z(Lit_2313); return Collections_UnmodifiableSet_Set__Set(s)
}




func (t *Calendar) Impl_GetTime__Date(this Calendar_I) Date_I {
	return Date_New_J(this.GetTimeInMillis__J())
}
func (t *Calendar) Impl_SetTime_Date__V(this Calendar_I, date Date_I) {
	this.SetTimeInMillis_J__V(date.GetTime__J())
}
func (t *Calendar) Impl_GetTimeInMillis__J(this Calendar_I) int64 {
	if t.F_isTimeSet { } else { t.Impl_UpdateTime__V(this) }
//line :203:1
	return t.F_time
}


func (t *Calendar) Impl_SetTimeInMillis_J__V(this Calendar_I, millis int64) {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = t.F_time == millis; if tmp4 { tmp4 = t.F_isTimeSet }; tmp3 = tmp4; if tmp3 { tmp3 = t.F_areFieldsSet }; tmp2 = tmp3; if tmp2 { tmp2 = t.F_areAllFieldsSet }; tmp1 = tmp2; if tmp1 { } else {
		t.F_time = millis
		t.F_isTimeSet = true
		t.F_areFieldsSet = false
		this.ComputeFields__V()
		t.Impl_MarkFieldsComputed__V(this)
	} }
func (t *Calendar) Impl_ToInstant__Instant(this Calendar_I) *Instant {
	return Instant_OfEpochMilli_J__Instant(this.GetTimeInMillis__J())
}
func (t *Calendar) Impl_Get_I__I(this Calendar_I, field int32) int32 {
	this.Complete__V()
	return this.InternalGet_I__I(field)
}
func (t *Calendar) Impl_InternalGet_I__I(this Calendar_I, field int32) int32 {
	return t.F_fields.A[field]
}
func (t *Calendar) Impl_InternalSet_I_I__V(this Calendar_I, field, value int32) {
	t.F_fields.A[field] = value
}
func (t *Calendar) Impl_Set_I_I__V(this Calendar_I, field, value int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_areFieldsSet; if tmp2 { tmp2 = !t.F_areAllFieldsSet }; tmp1 = tmp2; if tmp1 { this.ComputeFields__V(); t.Impl_MarkFieldsComputed__V(this) }
	this.InternalSet_I_I__V(field, value)
	t.F_isTimeSet = false
	t.F_areFieldsSet = false
	t.F_isSet.A[field] = true
	var tmp3 *IntArray = t.F_stamp; var tmp4 int32; var old_1 int32 = t.F_nextStamp; t.F_nextStamp = t.F_nextStamp + 1; tmp4 = old_1; tmp3.A[field] = tmp4
	if t.F_nextStamp == 2147483647 { t.Impl_AdjustStamp__V(this)
	} }
func (t *Calendar) Impl_Set_I_I_I__V(this Calendar_I, year, month, date int32) {
	this.Set_I_I__V(1, year)
	this.Set_I_I__V(2, month)
	this.Set_I_I__V(5, date)
}
func (t *Calendar) Impl_Set_I_I_I_I_I__V(this Calendar_I, year, month, date, hourOfDay, minute int32) {
	this.Set_I_I__V(1, year)
	this.Set_I_I__V(2, month)
	this.Set_I_I__V(5, date)
	this.Set_I_I__V(11, hourOfDay)
	this.Set_I_I__V(12, minute)
}
func (t *Calendar) Impl_Set_I_I_I_I_I_I__V(this Calendar_I, year, month, date, hourOfDay, minute, second int32) {

	this.Set_I_I__V(1, year)
	this.Set_I_I__V(2, month)
	this.Set_I_I__V(5, date)
	this.Set_I_I__V(11, hourOfDay)
	this.Set_I_I__V(12, minute)
	this.Set_I_I__V(13, second)
}
func (t *Calendar) Impl_Clear__V(this Calendar_I) {
	var i int32 = 0
L1: for { if i < int32(len(t.F_fields.A)) {
	var tmp1 *IntArray = t.F_stamp; var tmp2 int32 = i; var tmp3 int32; var tmp4 int32 = 0; t.F_fields.A[i] = tmp4; tmp3 = tmp4; tmp1.A[tmp2] = tmp3
	t.F_isSet.A[i] = false
	i = i + 1
//line :260:1
	continue L1 }; break L1
}


	var tmp5 bool; var tmp6 bool = false; t.F_areFieldsSet = tmp6; tmp5 = tmp6; t.F_areAllFieldsSet = tmp5
	t.F_isTimeSet = false
}
func (t *Calendar) Impl_Clear_I__V(this Calendar_I, field int32) {
	t.F_fields.A[field] = 0
	t.F_stamp.A[field] = 0
	t.F_isSet.A[field] = false
	var tmp1 bool; var tmp2 bool = false; t.F_areFieldsSet = tmp2; tmp1 = tmp2; t.F_areAllFieldsSet = tmp1
	t.F_isTimeSet = false
}
func (t *Calendar) Impl_IsSet_I__Z(this Calendar_I, field int32) bool {
	return !(t.F_stamp.A[field] == 0)
}








func (t *Calendar) Impl_GetDisplayName_I_I_Locale__String(this Calendar_I, field, style int32, locale *Locale) *String {
	if !this.CheckDisplayNameParams_I_I_I_I_Locale_I__Z(field, style, 1, 4, locale, 645) { return nil } else {










		var calendarType *String = this.GetCalendarType__String(); var fieldValue int32 = this.Get_I__I(field); var tmp1 bool; var tmp2 bool; var tmp3 bool

		tmp3 = t.Impl_IsStandaloneStyle_I__Z(this, style); if !tmp3 { tmp3 = t.Impl_IsNarrowFormatStyle_I__Z(this, style) }; tmp2 = tmp3; if !tmp2 {
			var tmp4 bool; tmp4 = field == 0; if tmp4 { tmp4 = style&1 == 1 }; tmp2 = tmp4 }
//line :299:1
		tmp1 = tmp2; if tmp1 {

			var val *String = CalendarDataUtility_RetrieveFieldValueName_String_I_I_I_Locale__String(calendarType, field, fieldValue, style, locale)





			if val == nil {
				if t.Impl_IsNarrowFormatStyle_I__Z(this, style) {

					val = CalendarDataUtility_RetrieveFieldValueName_String_I_I_I_Locale__String(calendarType, field, fieldValue, t.Impl_ToStandaloneStyle_I__I(this, style), locale) } else {
//line :308:1
						if t.Impl_IsStandaloneStyle_I__Z(this, style) {









							val = CalendarDataUtility_RetrieveFieldValueName_String_I_I_I_Locale__String(calendarType, field, fieldValue, this.GetBaseStyle_I__I(style), locale) } } }
//line :301:1
			return val } else {
























				var symbols *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(locale); var strings *RefArray = t.Impl_GetFieldStrings_I_I_DateFormatSymbols__String1(this, field, style, symbols)

				if !(strings == nil) {
					if fieldValue < int32(len(strings.A)) { return As[*String](strings.A[fieldValue]) } }
//line :326:1
				return nil
			}
	}
}


func (t *Calendar) Impl_GetDisplayNames_I_I_Locale__Map(this Calendar_I, field, style int32, locale *Locale) Map {

	if !this.CheckDisplayNameParams_I_I_I_I_Locale_I__Z(field, style, 0, 4, locale, 645) { return nil } else {










		var calendarType *String = this.GetCalendarType__String(); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool
		tmp4 = style == 0; if !tmp4 { tmp4 = t.Impl_IsStandaloneStyle_I__Z(this, style) }; tmp3 = tmp4; if !tmp3 {
			tmp3 = t.Impl_IsNarrowFormatStyle_I__Z(this, style) }
//line :346:1
		tmp2 = tmp3; if !tmp2 {

			var tmp5 bool; tmp5 = field == 0; if tmp5 { tmp5 = style&1 == 1 }; tmp2 = tmp5 }
//line :346:1
		tmp1 = tmp2; if tmp1 {


			var map_ Map
			map_ = CalendarDataUtility_RetrieveFieldValueNames_String_I_I_Locale__Map(calendarType, field, style, locale)

			if map_ == nil {
				if t.Impl_IsNarrowFormatStyle_I__Z(this, style) {
					map_ = CalendarDataUtility_RetrieveFieldValueNames_String_I_I_Locale__Map(calendarType, field, t.Impl_ToStandaloneStyle_I__I(this, style), locale) } else {





						if style == 0 { } else {
							map_ = CalendarDataUtility_RetrieveFieldValueNames_String_I_I_Locale__Map(calendarType, field, this.GetBaseStyle_I__I(style), locale) } } }
//line :349:1
			return map_ } else {


















				return t.Impl_GetDisplayNamesImpl_I_I_Locale__Map(this, field, style, locale)
			} } }
func (t *Calendar) Impl_GetDisplayNamesImpl_I_I_Locale__Map(this Calendar_I, field, style int32, locale *Locale) Map {

	var symbols *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(locale); var strings *RefArray = t.Impl_GetFieldStrings_I_I_DateFormatSymbols__String1(this, field, style, symbols)

	if !(strings == nil) {
		var names Map = HashMap_New(); var i int32 = 0
	L1: for {
		if i < int32(len(strings.A)) {
			if NN(As[*String](strings.A[i])).IsEmpty__Z() {
				i = i + 1; continue L1 } else {

					names.Put_O_O__O(As[*String](strings.A[i]).Ref(), Integer_ValueOf_I__Integer(i))
					i = i + 1; continue L1 } }
//line :376:1
		break L1 }
//line :375:1
		return names





	} else {
//line :374:1
		return nil
	}
}









func (t *Calendar) Impl_CheckDisplayNameParams_I_I_I_I_Locale_I__Z(this Calendar_I, field, style, minStyle, maxStyle int32, locale *Locale, fieldMask int32) bool {

	var baseStyle int32 = this.GetBaseStyle_I__I(style); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool
	tmp5 = field < 0; if !tmp5 { tmp5 = field >= int32(len(t.F_fields.A)) }; tmp4 = tmp5; if !tmp4 { tmp4 = baseStyle < minStyle }; tmp3 = tmp4; if !tmp3 {
		tmp3 = baseStyle > maxStyle }
//line :389:1
	tmp2 = tmp3; if !tmp2 {

		tmp2 = baseStyle == 3 }
//line :389:1
	tmp1 = tmp2; if tmp1 {


		panic(Thrown(IllegalArgumentException_New())) }
	if locale == nil { panic(Thrown(NullPointerException_New())) }
	return Calendar_IsFieldSet_I_I__Z(fieldMask, field)
}
func (t *Calendar) Impl_GetFieldStrings_I_I_DateFormatSymbols__String1(this Calendar_I, field, style int32, symbols *DateFormatSymbols) *RefArray {
	{ var baseStyle int32 = this.GetBaseStyle_I__I(style)
		if baseStyle == 4 { return nil } else {
			switch field { case 0:
				return NN(symbols).GetEras__String1(); case 2:
				if baseStyle == 2 { return NN(symbols).GetMonths__String1() } else { return NN(symbols).GetShortMonths__String1() }; case 7:
				if baseStyle == 2 { return NN(symbols).GetWeekdays__String1() } else { return NN(symbols).GetShortWeekdays__String1() }; case 9:
				return NN(symbols).GetAmPmStrings__String1(); default:
//line :399:1
				return nil
			}
		}
	}
	panic("a2g: unreachable")
}

func (t *Calendar) Impl_GetBaseStyle_I__I(this Calendar_I, style int32) int32 {
	return style & -32769
}
func (t *Calendar) Impl_ToStandaloneStyle_I__I(this Calendar_I, style int32) int32 {
	return style | 32768
}
func (t *Calendar) Impl_IsStandaloneStyle_I__Z(this Calendar_I, style int32) bool {
	return !(style&32768 == 0)
}
func (t *Calendar) Impl_IsNarrowStyle_I__Z(this Calendar_I, p0 int32) bool { panic(A2g_NotTranslated("java.util.Calendar.isNarrowStyle(I)Z")) }


func (t *Calendar) Impl_IsNarrowFormatStyle_I__Z(this Calendar_I, style int32) bool {
	return style == 4
}
func (t *Calendar) Impl_Complete__V(this Calendar_I) {
	if t.F_isTimeSet { } else { t.Impl_UpdateTime__V(this) }
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_areFieldsSet; if !tmp2 { tmp2 = !t.F_areAllFieldsSet }; tmp1 = tmp2; if tmp1 {
		this.ComputeFields__V()
		t.Impl_MarkFieldsComputed__V(this)
	} }
func (t *Calendar) Impl_MarkFieldsComputed__V(this Calendar_I) {
	var i int32 = 0; L1: for {
		if i < int32(len(t.F_fields.A)) {
			t.F_stamp.A[i] = 1
			t.F_isSet.A[i] = true
			i = i + 1; continue L1 }
//line :428:1
		break L1
	}



	var tmp1 bool; var tmp2 bool = true; t.F_areAllFieldsSet = tmp2; tmp1 = tmp2; t.F_areFieldsSet = tmp1
}
func (t *Calendar) Impl_SelectFields__I(this Calendar_I) int32 {
	var fieldMask int32 = 2
	if t.F_stamp.A[0] == 0 { } else {
		fieldMask = fieldMask | 1 }
	var dowStamp int32 = t.F_stamp.A[7]; var monthStamp int32 = t.F_stamp.A[2]; var domStamp int32 = t.F_stamp.A[5]; var womStamp int32 = Calendar_AggregateStamp_I_I__I(t.F_stamp.A[4], dowStamp); var dowimStamp int32 = Calendar_AggregateStamp_I_I__I(t.F_stamp.A[8], dowStamp); var doyStamp int32 = t.F_stamp.A[6]; var woyStamp int32 = Calendar_AggregateStamp_I_I__I(t.F_stamp.A[3], dowStamp)
	var bestStamp int32 = domStamp








	if womStamp > bestStamp { bestStamp = womStamp }
	if dowimStamp > bestStamp { bestStamp = dowimStamp }
	if doyStamp > bestStamp { bestStamp = doyStamp }
	if woyStamp > bestStamp { bestStamp = woyStamp }
	if bestStamp == 0 {
		womStamp = t.F_stamp.A[4]
		dowimStamp = Math_Max_I_I__I(t.F_stamp.A[8], dowStamp)
		woyStamp = t.F_stamp.A[3]
		bestStamp = Math_Max_I_I__I(Math_Max_I_I__I(womStamp, dowimStamp), woyStamp)
		if bestStamp == 0 { var tmp1 int32; domStamp = monthStamp; tmp1 = domStamp; bestStamp = tmp1 } }
	var tmp2 bool; var tmp3 bool; var tmp4 bool
	tmp4 = bestStamp == domStamp; if !tmp4 {
		var tmp5 bool; tmp5 = bestStamp == womStamp; if tmp5 {
			var tmp6 int32 = t.F_stamp.A[4]; tmp5 = tmp6 >= t.F_stamp.A[3] }
//line :461:1
		tmp4 = tmp5 }
//line :460:1
	tmp3 = tmp4; if !tmp3 {


		var tmp7 bool; tmp7 = bestStamp == dowimStamp; if tmp7 {
			var tmp8 int32 = t.F_stamp.A[8]; tmp7 = tmp8 >= t.F_stamp.A[3] }
//line :463:1
		tmp3 = tmp7 }
//line :460:1
	tmp2 = tmp3
//line :459:1
	if tmp2 {






		fieldMask = fieldMask | 4
		if bestStamp == domStamp {
			fieldMask = fieldMask | 32 } else {

				if dowStamp == 0 { } else {
					fieldMask = fieldMask | 128 }
				if womStamp == dowimStamp {

					var tmp9 int32 = t.F_stamp.A[4]; if tmp9 >= t.F_stamp.A[8] {
						fieldMask = fieldMask | 16 } else {

							fieldMask = fieldMask | 256 } } else {
//line :472:1
								if bestStamp == womStamp {








									fieldMask = fieldMask | 16 } else {

										if t.F_stamp.A[8] == 0 { } else {
											fieldMask = fieldMask | 256 } } } } } else {
//line :459:1
												if bestStamp == doyStamp {



























													fieldMask = fieldMask | 64 } else {


														if dowStamp == 0 { } else {
															fieldMask = fieldMask | 128 }
														fieldMask = fieldMask | 8 } }
	var hourOfDayStamp int32 = t.F_stamp.A[11]; var tmp10 int32 = t.F_stamp.A[10]; var hourStamp int32 = Calendar_AggregateStamp_I_I__I(tmp10, t.F_stamp.A[9]); var tmp11 int32

	if hourStamp > hourOfDayStamp { tmp11 = hourStamp } else { tmp11 = hourOfDayStamp }; bestStamp = tmp11
	if bestStamp == 0 {
		var tmp12 int32 = t.F_stamp.A[10]; bestStamp = Math_Max_I_I__I(tmp12, t.F_stamp.A[9]) }
	if bestStamp == 0 { } else {
		if bestStamp == hourOfDayStamp {
			fieldMask = fieldMask | 2048 } else {

				fieldMask = fieldMask | 1024
				if t.F_stamp.A[9] == 0 { } else {
					fieldMask = fieldMask | 512 } } }
	if t.F_stamp.A[12] == 0 { } else {
		fieldMask = fieldMask | 4096 }
	if t.F_stamp.A[13] == 0 { } else {
		fieldMask = fieldMask | 8192 }
	if t.F_stamp.A[14] == 0 { } else {
		fieldMask = fieldMask | 16384 }
	if t.F_stamp.A[15] >= 2 {
		fieldMask = fieldMask | 32768 }
	if t.F_stamp.A[16] >= 2 {
		fieldMask = fieldMask | 65536 }
//line :493:1
	return fieldMask
}






















func Calendar_AggregateStamp_I_I__I(stampA, stampB int32) int32 { Calendar_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = stampA == 0; if !tmp2 { tmp2 = stampB == 0 }; tmp1 = tmp2; if tmp1 { return 0 } else { return Math_Max_I_I__I(stampA, stampB)
	} }
func Calendar_IsFieldSet_I_I__Z(fieldMask, field int32) bool { Calendar_Init()
	return !(fieldMask&(1<<(field&31)) == 0)
}
func (t *Calendar) Impl_IsExternallySet_I__Z(this Calendar_I, field int32) bool {
	return t.F_stamp.A[field] >= 2
}
func Calendar_GetFieldName_I__String(field int32) *String { Calendar_Init()
	return As[*String](Calendar_FIELD_NAME.A[field])
}
func (t *Calendar) Impl_UpdateTime__V(this Calendar_I) {
	this.ComputeTime__V()
	t.F_isTimeSet = true
	if t.F_areFieldsSet { t.Impl_MarkFieldsComputed__V(this)
	} }
func (t *Calendar) Impl_AdjustStamp__V(this Calendar_I) {
	var max_ int32 = 2
	var newStamp int32 = 2
L1: for {
	var min_ int32 = 2147483647; var arr_101760 *IntArray = t.F_stamp; var len_101761 int32 = int32(len(arr_101760.A)); var i_101762 int32 = 0; for ; i_101762 < len_101761; i_101762++ {
		var v int32 = arr_101760.A[i_101762]; var tmp1 bool; var tmp2 bool
		tmp2 = v >= newStamp; if tmp2 { tmp2 = min_ > v }; tmp1 = tmp2; if tmp1 { min_ = v }
		if max_ < v { max_ = v } }
	var tmp3 bool; var tmp4 bool; tmp4 = !(max_ == min_); if tmp4 { tmp4 = min_ == 2147483647 }; tmp3 = tmp4; if tmp3 { break L1 }
	var i int32 = 0; L3: for {
		if i < int32(len(t.F_stamp.A)) {
			if t.F_stamp.A[i] == min_ {
				t.F_stamp.A[i] = newStamp; i = i + 1; continue L3 } else {
					i = i + 1; continue L3 } }
//line :543:1
		break L3
	}




	newStamp = newStamp + 1
	if min_ == max_ { break L1 }
//line :537:1
	continue L1
}












	t.F_nextStamp = newStamp
}
func (t *Calendar) Impl_GetCalendarType__String(this Calendar_I) *String { return Lit_2313 }

func (t *Calendar) Impl_Equals_O__Z(this Calendar_I, obj any) bool {
	if any(this) == any(obj) { return true } else {

		var tmp1 bool; tmp10 := func() (exc Throwable_I) { defer Catch(&exc)
			{ var that Calendar_I = Calendar_Cast(obj); var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool
				tmp5 = t.Impl_CompareTo_J__I(this, Calendar_GetMillisOf_Calendar__J(that)) == 0; if tmp5 {
					var tmp6 bool = t.F_lenient; tmp5 = tmp6 == that.Self_Calendar().F_lenient }
//line :560:1
				tmp4 = tmp5; if tmp4 {

					var tmp7 int32 = t.F_firstDayOfWeek; tmp4 = tmp7 == that.Self_Calendar().F_firstDayOfWeek }
//line :560:1
				tmp3 = tmp4; if tmp3 {


					var tmp8 int32 = t.F_minimalDaysInFirstWeek; tmp3 = tmp8 == that.Self_Calendar().F_minimalDaysInFirstWeek }
//line :560:1
				tmp2 = tmp3; if tmp2 {



					var tmp9 TimeZone_I = t.F_zone; tmp2 = tmp9.Equals_O__Z(that.Self_Calendar().F_zone) }
//line :560:1
				tmp1 = tmp2 }
			return nil }()
//line :558:1
		if tmp10 != nil { if Exception_InstanceOf(tmp10) { var e Exception_I = Exception_Cast(tmp10); _ = e; tmp1 = false } else { panic(tmp10) } }; return tmp1
	}
}






func (t *Calendar) Impl_HashCode__I(this Calendar_I) int32 {
	var otheritems int32; var tmp1 int32
	if t.F_lenient { tmp1 = 1 } else { tmp1 = 0 }
//line :568:1
	var tmp2 int32 = tmp1 | t.F_firstDayOfWeek<<1 | t.F_minimalDaysInFirstWeek<<4; otheritems = tmp2 | t.F_zone.HashCode__I()<<7; var t_ int64 = Calendar_GetMillisOf_Calendar__J(this)





	return int32(t_) ^ int32(t_>>32) ^ otheritems
}

func (t *Calendar) Impl_Before_O__Z(this Calendar_I, when any) bool {
	var tmp1 bool; tmp1 = Calendar_InstanceOf(when); if tmp1 { tmp1 = this.CompareTo_Calendar__I(Calendar_Cast(when)) < 0 }; return tmp1
}
func (t *Calendar) Impl_After_O__Z(this Calendar_I, when any) bool {
	var tmp1 bool; tmp1 = Calendar_InstanceOf(when); if tmp1 { tmp1 = this.CompareTo_Calendar__I(Calendar_Cast(when)) > 0 }; return tmp1
}
func (t *Calendar) Impl_CompareTo_Calendar__I(this, anotherCalendar Calendar_I) int32 {
	return t.Impl_CompareTo_J__I(this, Calendar_GetMillisOf_Calendar__J(anotherCalendar))
}
func (t *Calendar) Impl_CompareTo_J__I(this Calendar_I, t_ int64) int32 {
	var thisTime int64 = Calendar_GetMillisOf_Calendar__J(this); if thisTime > t_ { return 1 } else { if thisTime == t_ { return 0 } else { return -1
	} } }
func Calendar_GetMillisOf_Calendar__J(calendar Calendar_I) int64 { Calendar_Init()
	if calendar.Self_Calendar().F_isTimeSet {
		return calendar.Self_Calendar().F_time } else {
			var cal Calendar_I = Calendar_Cast(calendar.Clone__O()); cal.SetLenient_Z__V(true); return cal.GetTimeInMillis__J()
		}
}



func (t *Calendar) Impl_Roll_I_I__V(this Calendar_I, field, amount int32) {
L1: for { if amount > 0 { this.Roll_I_Z__V(field, true); amount = amount - 1; continue L1 }; break L1 }
L2: for { if amount < 0 { this.Roll_I_Z__V(field, false); amount = amount + 1; continue L2 }; break L2
} }
func (t *Calendar) Impl_SetTimeZone_TimeZone__V(this Calendar_I, value TimeZone_I) {
	t.F_zone = value
	var tmp1 bool; var tmp2 bool = false; t.F_areFieldsSet = tmp2; tmp1 = tmp2; t.F_areAllFieldsSet = tmp1
}
func (t *Calendar) Impl_GetTimeZone__TimeZone(this Calendar_I) TimeZone_I { return t.F_zone }

func (t *Calendar) Impl_SetLenient_Z__V(this Calendar_I, lenient bool) {
	t.F_lenient = lenient
}
func (t *Calendar) Impl_IsLenient__Z(this Calendar_I) bool { return t.F_lenient }

func (t *Calendar) Impl_SetFirstDayOfWeek_I__V(this Calendar_I, value int32) {
	if t.F_firstDayOfWeek == value { } else {
		t.F_firstDayOfWeek = value
		var tmp1 bool; var tmp2 bool = false; t.F_areFieldsSet = tmp2; tmp1 = tmp2; t.F_areAllFieldsSet = tmp1
	} }
func (t *Calendar) Impl_GetFirstDayOfWeek__I(this Calendar_I) int32 { return t.F_firstDayOfWeek }

func (t *Calendar) Impl_SetMinimalDaysInFirstWeek_I__V(this Calendar_I, value int32) {
	if t.F_minimalDaysInFirstWeek == value { } else {
		t.F_minimalDaysInFirstWeek = value
		var tmp1 bool; var tmp2 bool = false; t.F_areFieldsSet = tmp2; tmp1 = tmp2; t.F_areAllFieldsSet = tmp1
	} }
func (t *Calendar) Impl_GetMinimalDaysInFirstWeek__I(this Calendar_I) int32 { return t.F_minimalDaysInFirstWeek }


func (t *Calendar) Impl_IsWeekDateSupported__Z(this Calendar_I) bool { return false }

func (t *Calendar) Impl_GetWeekYear__I(this Calendar_I) int32 {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Calendar) Impl_SetWeekDate_I_I_I__V(this Calendar_I, weekYear, weekOfYear, dayOfWeek int32) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Calendar) Impl_GetWeeksInWeekYear__I(this Calendar_I) int32 {
	panic(Thrown(UnsupportedOperationException_New()))
}








func (t *Calendar) Impl_GetActualMinimum_I__I(this Calendar_I, field int32) int32 {
	return this.GetMinimum_I__I(field)
}
func (t *Calendar) Impl_GetActualMaximum_I__I(this Calendar_I, field int32) int32 {
	return this.GetMaximum_I__I(field)
}
func (t *Calendar) Impl_Clone__O(this Calendar_I) any {
	var tmp1 any; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var other Calendar_I = Calendar_Cast(A2g_ObjectClone(this))
			other.Self_Calendar().F_fields = NewIntArray(17)
			other.Self_Calendar().F_isSet = NewBooleanArray(17)
			other.Self_Calendar().F_stamp = NewIntArray(17)
			var i int32 = 0; L1: for {
				if i < 17 {
					var tmp2 *IntArray = other.Self_Calendar().F_fields; tmp2.A[i] = t.F_fields.A[i]
					var tmp3 *IntArray = other.Self_Calendar().F_stamp; tmp3.A[i] = t.F_stamp.A[i]
					var tmp4 *BooleanArray = other.Self_Calendar().F_isSet; tmp4.A[i] = t.F_isSet.A[i]
					i = i + 1; continue L1 }
//line :659:1
				break L1
			}




			other.Self_Calendar().F_zone = TimeZone_Cast(t.F_zone.Clone__O())
//line :655:1
			tmp1 = other
		}








		return nil }()
//line :654:1
	if tmp5 != nil { if CloneNotSupportedException_InstanceOf(tmp5) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp5)












		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :654:1
			panic(tmp5) } }; return tmp1
}













func (t *Calendar) Impl_ToString__String(this Calendar_I) *String {
	var buffer *StringBuilder = StringBuilder_New_I(800)
	NN(NN(buffer).Append_String__StringBuilder(NN(this.GetClass__Class()).GetName__String())).Append_C__StringBuilder(91)
	Calendar_AppendValue_StringBuilder_String_Z_J__V(buffer, Lit_2051, t.F_isTimeSet, t.F_time)
	NN(NN(buffer).Append_String__StringBuilder(Lit_2626)).Append_Z__StringBuilder(t.F_areFieldsSet)
	NN(NN(buffer).Append_String__StringBuilder(Lit_2627)).Append_Z__StringBuilder(t.F_areAllFieldsSet)
	NN(NN(buffer).Append_String__StringBuilder(Lit_2628)).Append_Z__StringBuilder(t.F_lenient)
	NN(NN(buffer).Append_String__StringBuilder(Lit_2629)).Append_O__StringBuilder(t.F_zone)
	Calendar_AppendValue_StringBuilder_String_Z_J__V(buffer, Lit_2630, true, int64(t.F_firstDayOfWeek))
	Calendar_AppendValue_StringBuilder_String_Z_J__V(buffer, Lit_2631, true, int64(t.F_minimalDaysInFirstWeek))
	var i int32 = 0; L1: for {
		if i < 17 {
			NN(buffer).Append_C__StringBuilder(44)
			Calendar_AppendValue_StringBuilder_String_Z_J__V(buffer, Calendar_GetFieldName_I__String(i), this.IsSet_I__Z(i), int64(t.F_fields.A[i]))



			i = i + 1; continue L1 }
//line :679:1
		break L1
	}






	NN(buffer).Append_C__StringBuilder(93)
	return NN(buffer).ToString__String()
}
func Calendar_AppendValue_StringBuilder_String_Z_J__V(sb *StringBuilder, item *String, valid bool, value int64) { Calendar_Init()

	NN(NN(sb).Append_String__StringBuilder(item)).Append_C__StringBuilder(61)
	if valid { NN(sb).Append_J__StringBuilder(value) } else { NN(sb).Append_C__StringBuilder(63)
	}
}

type Calendar struct{ Object; F_fields *IntArray; F_isSet *BooleanArray; F_time int64; F_isTimeSet, F_areFieldsSet, F_areAllFieldsSet bool; F_stamp *IntArray; F_nextStamp int32; F_lenient bool; F_zone TimeZone_I; F_firstDayOfWeek, F_minimalDaysInFirstWeek int32 }

type Calendar_I interface{ Object_I; Serializable; Cloneable; Comparable; Self_Calendar() *Calendar; ComputeTime__V(); ComputeFields__V(); GetTime__Date() Date_I; SetTime_Date__V(p0 Date_I); GetTimeInMillis__J() int64; SetTimeInMillis_J__V(p0 int64); ToInstant__Instant() *Instant; Get_I__I(p0 int32) int32; InternalGet_I__I(p0 int32) int32; InternalSet_I_I__V(p0, p1 int32); Set_I_I__V(p0, p1 int32); Set_I_I_I__V(p0, p1, p2 int32); Set_I_I_I_I_I__V(p0, p1, p2, p3, p4 int32); Set_I_I_I_I_I_I__V(p0, p1, p2, p3, p4, p5 int32); Clear__V(); Clear_I__V(p0 int32); IsSet_I__Z(p0 int32) bool; GetDisplayName_I_I_Locale__String(p0, p1 int32, p2 *Locale) *String; GetDisplayNames_I_I_Locale__Map(p0, p1 int32, p2 *Locale) Map; CheckDisplayNameParams_I_I_I_I_Locale_I__Z(p0, p1, p2, p3 int32, p4 *Locale, p5 int32) bool; GetBaseStyle_I__I(p0 int32) int32; Complete__V(); SelectFields__I() int32; IsExternallySet_I__Z(p0 int32) bool; GetCalendarType__String() *String; Before_O__Z(p0 any) bool; After_O__Z(p0 any) bool; CompareTo_Calendar__I(p0 Calendar_I) int32; Add_I_I__V(p0, p1 int32); Roll_I_Z__V(p0 int32, p1 bool); Roll_I_I__V(p0, p1 int32); SetTimeZone_TimeZone__V(p0 TimeZone_I); GetTimeZone__TimeZone() TimeZone_I; SetLenient_Z__V(p0 bool); IsLenient__Z() bool; SetFirstDayOfWeek_I__V(p0 int32); GetFirstDayOfWeek__I() int32; SetMinimalDaysInFirstWeek_I__V(p0 int32); GetMinimalDaysInFirstWeek__I() int32; IsWeekDateSupported__Z() bool; GetWeekYear__I() int32; SetWeekDate_I_I_I__V(p0, p1, p2 int32); GetWeeksInWeekYear__I() int32; GetMinimum_I__I(p0 int32) int32; GetMaximum_I__I(p0 int32) int32; GetGreatestMinimum_I__I(p0 int32) int32; GetLeastMaximum_I__I(p0 int32) int32; GetActualMinimum_I__I(p0 int32) int32; GetActualMaximum_I__I(p0 int32) int32; CompareTo_O__I(p0 any) int32 }

func (t *Calendar) Self_Calendar() *Calendar { return t }

func (t *Calendar) Is_Serializable() {}

func (t *Calendar) Is_Cloneable() {}

func (t *Calendar) Is_Comparable() {}

const Calendar_ERA int32 = 0

const Calendar_YEAR int32 = 1

const Calendar_MONTH int32 = 2

const Calendar_WEEK_OF_YEAR int32 = 3

const Calendar_WEEK_OF_MONTH int32 = 4

const Calendar_DATE int32 = 5

const Calendar_DAY_OF_MONTH int32 = 5

const Calendar_DAY_OF_YEAR int32 = 6

const Calendar_DAY_OF_WEEK int32 = 7

const Calendar_DAY_OF_WEEK_IN_MONTH int32 = 8

const Calendar_AM_PM int32 = 9

const Calendar_HOUR int32 = 10

const Calendar_HOUR_OF_DAY int32 = 11

const Calendar_MINUTE int32 = 12

const Calendar_SECOND int32 = 13

const Calendar_MILLISECOND int32 = 14

const Calendar_ZONE_OFFSET int32 = 15

const Calendar_DST_OFFSET int32 = 16

const Calendar_FIELD_COUNT int32 = 17

const Calendar_SUNDAY int32 = 1

const Calendar_MONDAY int32 = 2

const Calendar_TUESDAY int32 = 3

const Calendar_WEDNESDAY int32 = 4

const Calendar_THURSDAY int32 = 5

const Calendar_FRIDAY int32 = 6

const Calendar_SATURDAY int32 = 7

const Calendar_JANUARY int32 = 0

const Calendar_FEBRUARY int32 = 1

const Calendar_MARCH int32 = 2

const Calendar_APRIL int32 = 3

const Calendar_MAY int32 = 4

const Calendar_JUNE int32 = 5

const Calendar_JULY int32 = 6

const Calendar_AUGUST int32 = 7

const Calendar_SEPTEMBER int32 = 8

const Calendar_OCTOBER int32 = 9

const Calendar_NOVEMBER int32 = 10

const Calendar_DECEMBER int32 = 11

const Calendar_UNDECIMBER int32 = 12

const Calendar_AM int32 = 0

const Calendar_PM int32 = 1

const Calendar_ALL_STYLES int32 = 0

const Calendar_STANDALONE_MASK int32 = 32768

const Calendar_SHORT int32 = 1

const Calendar_LONG int32 = 2

const Calendar_NARROW_FORMAT int32 = 4

const Calendar_NARROW_STANDALONE int32 = 32772

const Calendar_SHORT_FORMAT int32 = 1

const Calendar_LONG_FORMAT int32 = 2

const Calendar_SHORT_STANDALONE int32 = 32769

const Calendar_LONG_STANDALONE int32 = 32770

var Calendar_FIELD_NAME *RefArray

const Calendar_UNSET int32 = 0

const Calendar_COMPUTED int32 = 1

const Calendar_MINIMUM_USER_STAMP int32 = 2

var Calendar_cachedLocaleData ConcurrentMap

const Calendar_ERA_MASK int32 = 1

const Calendar_MONTH_MASK int32 = 4

const Calendar_DAY_OF_WEEK_MASK int32 = 128

const Calendar_AM_PM_MASK int32 = 512

var Calendar_init ClassInit

func Calendar_Init() { if !Calendar_init.Done() { Calendar_init.Run(Calendar_clinit) } }

func Calendar_clinit() { Calendar_FIELD_NAME = ConstRefArray("[0,17,s3:ERAs4:YEARs5:MONTHs12:WEEK_OF_YEARs13:WEEK_OF_MONTHs12:DAY_OF_MONTHs11:DAY_OF_YEARs11:DAY_OF_WEEKs20:DAY_OF_WEEK_IN_MONTHs5:AM_PMs4:HOURs11:HOUR_OF_DAYs6:MINUTEs6:SECONDs11:MILLISECONDs11:ZONE_OFFSETs10:DST_OFFSET", []*Class{String_class}); Calendar_cachedLocaleData = ConcurrentHashMap_New_I(3) }

func (t *Calendar) Impl_CompareTo_O__I(this Calendar_I, p0 any) int32 { return this.CompareTo_Calendar__I(Calendar_Cast(p0)) }

func Calendar_InstanceOf(x any) bool { _, ok := x.(Calendar_I); return ok }

func Calendar_Cast(x any) Calendar_I { if x == nil { return nil }; v, ok := x.(Calendar_I); if !ok { panic(ClassCast(x, Calendar_class)) }; return v }
