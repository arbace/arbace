//line java_time_Instant.ae:1
package jrt












































func Instant_Now__Instant() *Instant { Instant_Init(); return Clock_CurrentInstant__Instant() }

func Instant_Now_Clock__Instant(clock Clock_I) *Instant { Instant_Init()
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	return clock.Instant__Instant()
}
func Instant_OfEpochSecond_J__Instant(epochSecond int64) *Instant { Instant_Init()
	return Instant_Create_J_I__Instant(epochSecond, 0)
}
func Instant_OfEpochSecond_J_J__Instant(epochSecond, nanoAdjustment int64) *Instant { Instant_Init()
	var secs int64 = Math_AddExact_J_J__J(epochSecond, Math_FloorDiv_J_J__J(nanoAdjustment, 1000000000)); var nos int32 = int32(Math_FloorMod_J_J__J(nanoAdjustment, 1000000000))

	return Instant_Create_J_I__Instant(secs, nos)
}
func Instant_OfEpochMilli_J__Instant(epochMilli int64) *Instant { Instant_Init()
	var secs int64 = Math_FloorDiv_J_I__J(epochMilli, 1000); var mos int32 = Math_FloorMod_J_I__I(epochMilli, 1000)

	return Instant_Create_J_I__Instant(secs, mos*1000000)
}
func Instant_From_TemporalAccessor__Instant(temporal TemporalAccessor) *Instant { Instant_Init()
	if Instant_InstanceOf(temporal) {
		return Instant_Cast(temporal) } else {

			Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
			var tmp1 *Instant; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var instantSecs int64; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_INSTANT_SECONDS; instantSecs = temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2)); var nanoOfSecond int32; var tmp3 *ChronoField
					ChronoField_Init(); tmp3 = ChronoField_NANO_OF_SECOND; nanoOfSecond = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp3))
					tmp1 = Instant_OfEpochSecond_J_J__Instant(instantSecs, int64(nanoOfSecond)) }; return nil }()
//line :70:1
			if tmp4 != nil { if DateTimeException_InstanceOf(tmp4) { var ex DateTimeException_I = DateTimeException_Cast(tmp4)




				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2033, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :70:1
					panic(tmp4) } }; return tmp1
		}
}









func Instant_Parse_CharSequence__Instant(text CharSequence) *Instant { Instant_Init()
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_INSTANT; var tmp2 *DateTimeFormatter = tmp1; return Instant_Cast(NN(tmp2).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return Instant_From_TemporalAccessor__Instant(p0).Ref() }}))
}



func Instant_Create_J_I__Instant(seconds int64, nanoOfSecond int32) *Instant { Instant_Init()
	if seconds|int64(nanoOfSecond) == 0 { return Instant_EPOCH } else {


		var tmp1 bool; var tmp2 bool; tmp2 = seconds < -31557014167219200; if !tmp2 { tmp2 = seconds > 31556889864403199 }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(DateTimeException_New_String(Lit_2034))) }
		return Instant_New_J_I(seconds, nanoOfSecond)
	} }
func Instant_New_J_I(p0 int64, p1 int32) *Instant { Instant_Init(); t := &Instant{}; t.Ctor_J_I(p0, p1); return t }
//line :96:1
func (t *Instant) Ctor_J_I(epochSecond int64, nanos int32) {
	t.F_seconds = epochSecond
	t.F_nanos = nanos
}
func (t *Instant) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_INSTANT_SECONDS; tmp3 = any(field) == any(tmp4.Ref()); if !tmp3 {
			var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_NANO_OF_SECOND; tmp3 = any(field) == any(tmp5.Ref()) }
//line :102:1
		tmp2 = tmp3; if !tmp2 {

			var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_MICRO_OF_SECOND; tmp2 = any(field) == any(tmp6.Ref()) }
//line :102:1
		tmp1 = tmp2; if !tmp1 {


			var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_MILLI_OF_SECOND; tmp1 = any(field) == any(tmp7.Ref()) }
//line :102:1
		return tmp1 } else {



			var tmp8 bool; tmp8 = !(field == nil); if tmp8 { tmp8 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp8
		} }
func (t *Instant) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		var tmp1 bool; tmp1 = unit.IsTimeBased__Z(); if !tmp1 { var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_DAYS; tmp1 = any(unit) == any(tmp2.Ref()) }; return tmp1 } else {
			var tmp3 bool; tmp3 = !(unit == nil); if tmp3 { tmp3 = unit.IsSupportedBy_Temporal__Z(t) }; return tmp3
		} }
func (t *Instant) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
}
func (t *Instant) Get_TemporalField__I(field TemporalField) int32 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 0: return t.F_nanos; case 2:

			return t.F_nanos / 1000; case 4:
			return t.F_nanos / 1000000; default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return NN(t.Range_TemporalField__ValueRange(field)).CheckValidIntValue_J_TemporalField__I(field.GetFrom_TemporalAccessor__J(t), field) } }; panic("a2g: unreachable")
}
func (t *Instant) GetLong_TemporalField__J(field TemporalField) int64 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 0:
			return int64(t.F_nanos); case 2:
			return int64(t.F_nanos / 1000); case 4:
			return int64(t.F_nanos / 1000000); case 28:
//line :127:1
			return t.F_seconds


		default:

			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return field.GetFrom_TemporalAccessor__J(t) } }; panic("a2g: unreachable")
}
func (t *Instant) GetEpochSecond__J() int64 { return t.F_seconds }

func (t *Instant) GetNano__I() int32 { return t.F_nanos }

func (t *Instant) With_TemporalAdjuster__Instant(adjuster TemporalAdjuster) *Instant {
	return Instant_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
}
func (t *Instant) With_TemporalField_J__Instant(field TemporalField, newValue int64) *Instant {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)

		NN(chronoField).CheckValidValue_J__J(newValue)
		switch NN(chronoField).F_ordinal { case 4:

			var nval int32 = int32(newValue) * 1000000
			if !(nval == t.F_nanos) { return Instant_Create_J_I__Instant(t.F_seconds, nval) } else { return t }; case 2:

			var nval_2 int32 = int32(newValue) * 1000
			if !(nval_2 == t.F_nanos) { return Instant_Create_J_I__Instant(t.F_seconds, nval_2) } else { return t }; case 0:

			if !(newValue == int64(t.F_nanos)) { return Instant_Create_J_I__Instant(t.F_seconds, int32(newValue)) } else { return t }; case 28:
			if !(newValue == t.F_seconds) { return Instant_Create_J_I__Instant(newValue, t.F_nanos) } else { return t }; default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return Instant_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue)) } }; panic("a2g: unreachable")
}
func (t *Instant) TruncatedTo_TemporalUnit__Instant(unit TemporalUnit) *Instant {
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_NANOS; if any(unit) == any(tmp1.Ref()) { return t } else {

		var unitDur *Duration = unit.GetDuration__Duration()
		if NN(unitDur).GetSeconds__J() > 86400 {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2025)))
		}
		var dur int64 = NN(unitDur).ToNanos__J()
		if 86400000000000%dur == 0 { } else {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2026)))
		}
		var nod int64 = t.F_seconds%86400*1000000000 + int64(t.F_nanos); var result int64 = Math_FloorDiv_J_J__J(nod, dur) * dur




		return t.PlusNanos_J__Instant(result - nod)
	} }
func (t *Instant) Plus_TemporalAmount__Instant(amountToAdd TemporalAmount) *Instant {
	return Instant_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
}
func (t *Instant) PlusSaturating_Duration__Instant(duration *Duration) *Instant {
	if NN(duration).IsNegative__Z() {

		if NN(t.Until_Instant__Duration(Instant_MIN)).CompareTo_Duration__I(duration) >= 0 { return Instant_MIN } else {

			return t.Plus_TemporalAmount__Instant(Up_Duration_TemporalAmount(duration)) } } else {
//line :181:1
				if NN(t.Until_Instant__Duration(Instant_MAX)).CompareTo_Duration__I(duration) <= 0 { return Instant_MAX } else {





					return t.Plus_TemporalAmount__Instant(Up_Duration_TemporalAmount(duration))
				} } }
func (t *Instant) Plus_J_TemporalUnit__Instant(amountToAdd int64, unit TemporalUnit) *Instant {
	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 0:
			return t.PlusNanos_J__Instant(amountToAdd); case 1:

			var tmp2 int64 = amountToAdd / 1000000; return t.Plus_J_J__Instant(tmp2, amountToAdd%1000000*1000); case 2:


			return t.PlusMillis_J__Instant(amountToAdd); case 3:
			return t.PlusSeconds_J__Instant(amountToAdd); case 4:
			return t.PlusSeconds_J__Instant(Math_MultiplyExact_J_I__J(amountToAdd, 60)); case 5:
			return t.PlusSeconds_J__Instant(Math_MultiplyExact_J_I__J(amountToAdd, 3600)); case 6:

			return t.PlusSeconds_J__Instant(Math_MultiplyExact_J_I__J(amountToAdd, 43200)); case 7:


			return t.PlusSeconds_J__Instant(Math_MultiplyExact_J_I__J(amountToAdd, 86400)); default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
				return Instant_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd)) } }; panic("a2g: unreachable")
}
func (t *Instant) PlusSeconds_J__Instant(secondsToAdd int64) *Instant {
	if secondsToAdd == 0 { return t } else {

		var epochSec int64 = Math_AddExact_J_J__J(t.F_seconds, secondsToAdd); return Instant_Create_J_I__Instant(epochSec, t.F_nanos)
	} }
func (t *Instant) PlusMillis_J__Instant(millisToAdd int64) *Instant {
	var tmp1 int64 = millisToAdd / 1000; return t.Plus_J_J__Instant(tmp1, millisToAdd%1000*1000000)
}


func (t *Instant) PlusNanos_J__Instant(nanosToAdd int64) *Instant {
	return t.Plus_J_J__Instant(0, nanosToAdd)
}
func (t *Instant) Plus_J_J__Instant(secondsToAdd, nanosToAdd int64) *Instant {
	if secondsToAdd|nanosToAdd == 0 { return t } else {

		var epochSec int64 = Math_AddExact_J_J__J(t.F_seconds, secondsToAdd)
		epochSec = Math_AddExact_J_J__J(epochSec, nanosToAdd/1000000000)

		nanosToAdd = nanosToAdd % 1000000000
		var nanoAdjustment int64 = int64(t.F_nanos) + nanosToAdd
		return Instant_OfEpochSecond_J_J__Instant(epochSec, nanoAdjustment)
	} }
func (t *Instant) Minus_TemporalAmount__Instant(amountToSubtract TemporalAmount) *Instant {
	return Instant_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
}
func (t *Instant) Minus_J_TemporalUnit__Instant(amountToSubtract int64, unit TemporalUnit) *Instant {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__Instant(9223372036854775807, unit)).Plus_J_TemporalUnit__Instant(1, unit) } else {
			return t.Plus_J_TemporalUnit__Instant(-amountToSubtract, unit)
		} }
func (t *Instant) MinusSeconds_J__Instant(secondsToSubtract int64) *Instant {
	if secondsToSubtract == -9223372036854775808 {
		return NN(t.PlusSeconds_J__Instant(9223372036854775807)).PlusSeconds_J__Instant(1) } else {
			return t.PlusSeconds_J__Instant(-secondsToSubtract)
		} }
func (t *Instant) MinusMillis_J__Instant(millisToSubtract int64) *Instant {
	if millisToSubtract == -9223372036854775808 {
		return NN(t.PlusMillis_J__Instant(9223372036854775807)).PlusMillis_J__Instant(1) } else {
			return t.PlusMillis_J__Instant(-millisToSubtract)
		} }
func (t *Instant) MinusNanos_J__Instant(nanosToSubtract int64) *Instant {
	if nanosToSubtract == -9223372036854775808 {
		return NN(t.PlusNanos_J__Instant(9223372036854775807)).PlusNanos_J__Instant(1) } else {
			return t.PlusNanos_J__Instant(-nanosToSubtract)
		} }
func (t *Instant) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_NANOS.Ref() } else {

		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = query == TemporalQueries_Chronology__TemporalQuery(); if !tmp6 {
			tmp6 = query == TemporalQueries_ZoneId__TemporalQuery() }
//line :258:1
		tmp5 = tmp6; if !tmp5 {

			tmp5 = query == TemporalQueries_Zone__TemporalQuery() }
//line :258:1
		tmp4 = tmp5; if !tmp4 {


			tmp4 = query == TemporalQueries_Offset__TemporalQuery() }
//line :258:1
		tmp3 = tmp4; if !tmp3 {



			tmp3 = query == TemporalQueries_LocalDate__TemporalQuery() }
//line :258:1
		tmp2 = tmp3; if !tmp2 {




			tmp2 = query == TemporalQueries_LocalTime__TemporalQuery() }
//line :258:1
		tmp1 = tmp2; if tmp1 { return nil } else {





			return query.QueryFrom_TemporalAccessor__O(t)
		} } }
func (t *Instant) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_INSTANT_SECONDS; var tmp2 Temporal = temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp1), t.F_seconds); var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_NANO_OF_SECOND; return tmp2.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp3), int64(t.F_nanos))
}
func (t *Instant) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	{ var end *Instant = Instant_From_TemporalAccessor__Instant(endExclusive); var tmp1 TemporalUnit = unit
		if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
			switch NN(chronoUnit).F_ordinal { case 0:
				return t.NanosUntil_Instant__J(end); case 1:
				return t.MicrosUntil_Instant__J(end); case 2:
				return t.MillisUntil_Instant__J(end); case 3:
				return t.SecondsUntil_Instant__J(end); case 4:
				return t.SecondsUntil_Instant__J(end) / 60; case 5:
				return t.SecondsUntil_Instant__J(end) / 3600; case 6:

				return t.SecondsUntil_Instant__J(end) / 43200; case 7:

				return t.SecondsUntil_Instant__J(end) / 86400; default:
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
					return unit.Between_Temporal_Temporal__J(t, Up_Instant_Temporal(end)) } }; panic("a2g: unreachable")
}
func (t *Instant) Until_Instant__Duration(endExclusive *Instant) *Duration {
	Objects_RequireNonNull_O_String__O(endExclusive.Ref(), Lit_2035)
	var secsDiff int64 = Math_SubtractExact_J_J__J(endExclusive.F_seconds, t.F_seconds); var nanosDiff int32 = endExclusive.F_nanos - t.F_nanos

	return Duration_OfSeconds_J_J__Duration(secsDiff, int64(nanosDiff))
}
func (t *Instant) NanosUntil_Instant__J(end *Instant) int64 {
	var secsDiff int64 = Math_SubtractExact_J_J__J(end.F_seconds, t.F_seconds); var totalNanos int64 = Math_MultiplyExact_J_J__J(secsDiff, 1000000000)

	return Math_AddExact_J_J__J(totalNanos, int64(end.F_nanos-t.F_nanos))
}
func (t *Instant) MicrosUntil_Instant__J(end *Instant) int64 {
	var microsDiff int64 = Math_MultiplyExact_J_J__J(end.F_seconds-t.F_seconds, 1000000); var nanosDiff int32 = end.F_nanos - t.F_nanos; var tmp1 bool; var tmp2 bool



	tmp2 = microsDiff > 0; if tmp2 { tmp2 = nanosDiff < 0 }; tmp1 = tmp2
//line :301:1
	if tmp1 {

		return microsDiff - 1000000 + int64((nanosDiff+1000000000)/1000) } else {
//line :301:1
			var tmp3 bool; var tmp4 bool



			tmp4 = microsDiff < 0; if tmp4 { tmp4 = nanosDiff > 0 }; tmp3 = tmp4
//line :301:1
			if tmp3 {




				return microsDiff + 1000000 + int64((nanosDiff-1000000000)/1000) } else {

					return Math_AddExact_J_J__J(microsDiff, int64(nanosDiff/1000))
				} } }
func (t *Instant) MillisUntil_Instant__J(end *Instant) int64 {
	var millisDiff int64 = Math_MultiplyExact_J_J__J(end.F_seconds-t.F_seconds, 1000); var nanosDiff int32 = end.F_nanos - t.F_nanos; var tmp1 bool; var tmp2 bool



	tmp2 = millisDiff > 0; if tmp2 { tmp2 = nanosDiff < 0 }; tmp1 = tmp2
//line :314:1
	if tmp1 {

		return millisDiff - 1000 + int64((nanosDiff+1000000000)/1000000) } else {
//line :314:1
			var tmp3 bool; var tmp4 bool



			tmp4 = millisDiff < 0; if tmp4 { tmp4 = nanosDiff > 0 }; tmp3 = tmp4
//line :314:1
			if tmp3 {




				return millisDiff + 1000 + int64((nanosDiff-1000000000)/1000000) } else {


					return Math_AddExact_J_J__J(millisDiff, int64(nanosDiff/1000000))
				} } }
func (t *Instant) SecondsUntil_Instant__J(end *Instant) int64 {
	var secsDiff int64 = Math_SubtractExact_J_J__J(end.F_seconds, t.F_seconds); var nanosDiff int32 = end.F_nanos - t.F_nanos; var tmp1 bool; var tmp2 bool


	tmp2 = secsDiff > 0; if tmp2 { tmp2 = nanosDiff < 0 }; tmp1 = tmp2
//line :327:1
	if tmp1 {
		secsDiff = secsDiff - 1 } else {
//line :327:1
			var tmp3 bool; var tmp4 bool

			tmp4 = secsDiff < 0; if tmp4 { tmp4 = nanosDiff > 0 }; tmp3 = tmp4
//line :327:1
			if tmp3 {

				secsDiff = secsDiff + 1 } }
//line :325:1
	return secsDiff
}





func (t *Instant) AtOffset_ZoneOffset__OffsetDateTime(offset *ZoneOffset) *OffsetDateTime {
	return OffsetDateTime_OfInstant_Instant_ZoneId__OffsetDateTime(t, Up_ZoneOffset_ZoneId(offset))
}
func (t *Instant) AtZone_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_OfInstant_Instant_ZoneId__ZonedDateTime(t, zone)
}
func (t *Instant) ToEpochMilli__J() int64 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_seconds < 0; if tmp2 { tmp2 = t.F_nanos > 0 }; tmp1 = tmp2; if tmp1 {
		var millis int64 = Math_MultiplyExact_J_I__J(t.F_seconds+1, 1000); var adjustment int64 = int64(t.F_nanos/1000000 - 1000)

		return Math_AddExact_J_J__J(millis, adjustment) } else {
			var millis_2 int64 = Math_MultiplyExact_J_I__J(t.F_seconds, 1000)
			return Math_AddExact_J_J__J(millis_2, int64(t.F_nanos/1000000))
		} }
func (t *Instant) CompareTo_Instant__I(otherInstant *Instant) int32 {
	var tmp1 int64 = t.F_seconds; var cmp int32 = Long_Compare_J_J__I(tmp1, otherInstant.F_seconds)
	if !(cmp == 0) { return cmp } else { var tmp2 int32 = t.F_nanos; return tmp2 - otherInstant.F_nanos
	} }
func (t *Instant) IsAfter_Instant__Z(otherInstant *Instant) bool {
	return t.CompareTo_Instant__I(otherInstant) > 0
}
func (t *Instant) IsBefore_Instant__Z(otherInstant *Instant) bool {
	return t.CompareTo_Instant__I(otherInstant) < 0
}
func (t *Instant) Equals_O__Z(other any) bool {
	if any(t) == any(other) { return true } else {

		var tmp1 any = other; if Instant_InstanceOf(tmp1) { var otherInstant *Instant = Instant_Cast(tmp1); var tmp2 int64 = t.F_seconds
			if tmp2 == otherInstant.F_seconds {
				var tmp3 int32 = t.F_nanos; return tmp3 == otherInstant.F_nanos } else {
//line :360:1
					return false } } else {
//line :359:1
						return false
					}
	}
}


func (t *Instant) HashCode__I() int32 {
	return Long_HashCode_J__I(t.F_seconds) + 51*t.F_nanos
}
func (t *Instant) ToString__String() *String {
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_INSTANT; return NN(tmp1).Format_TemporalAccessor__String(t)
}
func (t *Instant) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.Instant.writeReplace()Ljava/lang/Object;")) }








func Instant_ReadExternal_DataInput__Instant(p0 DataInput) *Instant { Instant_Init(); panic(A2g_NotTranslated("java.time.Instant.readExternal(Ljava/io/DataInput;)Ljava/time/Instant;")) }



type Instant struct{ Object; F_seconds int64; F_nanos int32 }

func (t *Instant) Is_Temporal() {}

func (t *Instant) Is_TemporalAdjuster() {}

func (t *Instant) Is_Comparable() {}

func (t *Instant) Is_Serializable() {}

func (t *Instant) Is_TemporalAccessor() {}

var Instant_EPOCH *Instant

const Instant_MIN_SECOND int64 = -31557014167219200

const Instant_MAX_SECOND int64 = 31556889864403199

var Instant_MIN *Instant

var Instant_MAX *Instant

const Instant_serialVersionUID int64 = -665713676816604388

var Instant_init ClassInit

func Instant_Init() { if !Instant_init.Done() { Instant_init.Run(Instant_clinit) } }

func Instant_clinit() { Instant_EPOCH = Instant_New_J_I(0, 0); Instant_MIN = Instant_OfEpochSecond_J_J__Instant(-31557014167219200, 0); Instant_MAX = Instant_OfEpochSecond_J_J__Instant(31556889864403199, 999999999) }

func (t *Instant) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_Instant_Temporal(t.With_TemporalAdjuster__Instant(p0)) }

func (t *Instant) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_Instant_Temporal(t.With_TemporalField_J__Instant(p0, p1)) }

func (t *Instant) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_Instant_Temporal(t.Plus_TemporalAmount__Instant(p0)) }

func (t *Instant) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_Instant_Temporal(t.Plus_J_TemporalUnit__Instant(p0, p1)) }

func (t *Instant) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_Instant_Temporal(t.Minus_TemporalAmount__Instant(p0)) }

func (t *Instant) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_Instant_Temporal(t.Minus_J_TemporalUnit__Instant(p0, p1)) }

func (t *Instant) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Instant__I(Instant_Cast(p0)) }

func (t *Instant) Ref() any { if t == nil { return nil }; return t }

func (t *Instant) GetClass__Class() *Class { return Instant_class }

func (t *Instant) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Instant) CloneShallow() any { panic(CloneNotSupported(t)) }

func Instant_InstanceOf(x any) bool { _, ok := x.(*Instant); return ok }

func Instant_Cast(x any) *Instant { if x == nil { return nil }; v, ok := x.(*Instant); if !ok { panic(ClassCast(x, Instant_class)) }; return v }
