//line java_lang_IllegalStateException.ae:1
package jrt






func IllegalStateException_New() *IllegalStateException { t := &IllegalStateException{}; t.Ctor(t); return t }
//line :8:1
func (t *IllegalStateException) Ctor(this IllegalStateException_I) { t.RuntimeException.Ctor(this) }

func IllegalStateException_New_String(p0 *String) *IllegalStateException { t := &IllegalStateException{}; t.Ctor_String(t, p0); return t }
//line :10:1
func (t *IllegalStateException) Ctor_String(this IllegalStateException_I, s *String) { t.RuntimeException.Ctor_String(this, s) }

func IllegalStateException_New_String_Throwable(p0 *String, p1 Throwable_I) *IllegalStateException { t := &IllegalStateException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :12:1
func (t *IllegalStateException) Ctor_String_Throwable(this IllegalStateException_I, message *String, cause Throwable_I) { t.RuntimeException.Ctor_String_Throwable(this, message, cause) }


func IllegalStateException_New_Throwable(p0 Throwable_I) *IllegalStateException { t := &IllegalStateException{}; t.Ctor_Throwable(t, p0); return t }
//line :15:1
func (t *IllegalStateException) Ctor_Throwable(this IllegalStateException_I, cause Throwable_I) { t.RuntimeException.Ctor_Throwable(this, cause) }










type IllegalStateException struct{ RuntimeException }

type IllegalStateException_I interface{ RuntimeException_I; Serializable; Self_IllegalStateException() *IllegalStateException }

func (t *IllegalStateException) Self_IllegalStateException() *IllegalStateException { return t }

const IllegalStateException_serialVersionUID int64 = -1848914673093119416

func (t *IllegalStateException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalStateException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalStateException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalStateException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalStateException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalStateException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalStateException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalStateException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalStateException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalStateException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalStateException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalStateException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalStateException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalStateException) GetClass__Class() *Class { return IllegalStateException_class }

func (t *IllegalStateException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalStateException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalStateException_InstanceOf(x any) bool { _, ok := x.(IllegalStateException_I); return ok }

func IllegalStateException_Cast(x any) IllegalStateException_I { if x == nil { return nil }; v, ok := x.(IllegalStateException_I); if !ok { panic(ClassCast(x, IllegalStateException_class)) }; return v }
