//line java_time_chrono_Era.ae:1
package jrt





















func Era_IsSupported_TemporalField__Z(this Era, field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_ERA; return any(field) == any(tmp1.Ref()) } else {
			var tmp2 bool; tmp2 = !(field == nil); if tmp2 { tmp2 = field.IsSupportedBy_TemporalAccessor__Z(this) }; return tmp2
		} }
func Era_Range_TemporalField__ValueRange(this Era, field TemporalField) *ValueRange {
	return TemporalAccessor_Range_TemporalField__ValueRange(this, field)
}
func Era_Get_TemporalField__I(this Era, field TemporalField) int32 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_ERA; if any(field) == any(tmp1.Ref()) { return this.GetValue__I() } else { return TemporalAccessor_Get_TemporalField__I(this, field)
	} }
func Era_GetLong_TemporalField__J(this Era, field TemporalField) int64 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_ERA; if any(field) == any(tmp1.Ref()) { return int64(this.GetValue__I()) } else {


		if ChronoField_InstanceOf(field) {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
		return field.GetFrom_TemporalAccessor__J(this)
	} }
func Era_Query_TemporalQuery__O(this Era, query TemporalQuery) any {
	if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_ERAS.Ref() } else {

		return TemporalAccessor_Query_TemporalQuery__O(this, query)
	} }
func Era_AdjustInto_Temporal__Temporal(this Era, temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_ERA; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); return temporal.With_TemporalField_J__Temporal(tmp2, int64(this.GetValue__I()))
}
func Era_GetDisplayName_TextStyle_Locale__String(this Era, style *TextStyle, locale *Locale) *String {
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; return NN(NN(tmp1.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp2), style)).ToFormatter_Locale__DateTimeFormatter(locale)).Format_TemporalAccessor__String(this)
}


type Era interface{ Object_I; TemporalAccessor; TemporalAdjuster; Is_Era(); GetValue__I() int32; IsSupported_TemporalField__Z(p0 TemporalField) bool; Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange; Get_TemporalField__I(p0 TemporalField) int32; GetLong_TemporalField__J(p0 TemporalField) int64; Query_TemporalQuery__O(p0 TemporalQuery) any; AdjustInto_Temporal__Temporal(p0 Temporal) Temporal; GetDisplayName_TextStyle_Locale__String(p0 *TextStyle, p1 *Locale) *String }

func Era_InstanceOf(x any) bool { _, ok := x.(Era); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Era_class) } }; return ok }

func Era_Cast(x any) Era { if x == nil { return nil }; v, ok := x.(Era); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Era_class) } }; if !ok { panic(ClassCast(x, Era_class)) }; return v }
