//line java_time_temporal_ChronoField.ae:1
package jrt





































































































func ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(p0 *String, p1 int32, p2 *String, p3, p4 TemporalUnit, p5 *ValueRange) *ChronoField { ChronoField_Init(); t := &ChronoField{}; t.Ctor_String_I_String_TemporalUnit_TemporalUnit_ValueRange(p0, p1, p2, p3, p4, p5); return t }
//line :103:1
func (t *ChronoField) Ctor_String_I_String_TemporalUnit_TemporalUnit_ValueRange(enumName *String, enumOrdinal int32, name *String, baseUnit, rangeUnit TemporalUnit, range_ *ValueRange) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)

	t.F_name = name
	t.F_baseUnit = baseUnit
	t.F_rangeUnit = rangeUnit
	t.F_range = range_
	t.F_displayNameKey = nil
}
func ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(p0 *String, p1 int32, p2 *String, p3, p4 TemporalUnit, p5 *ValueRange, p6 *String) *ChronoField { ChronoField_Init(); t := &ChronoField{}; t.Ctor_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(p0, p1, p2, p3, p4, p5, p6); return t }
//line :111:1
func (t *ChronoField) Ctor_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(enumName *String, enumOrdinal int32, name *String, baseUnit, rangeUnit TemporalUnit, range_ *ValueRange, displayNameKey *String) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)

	t.F_name = name
	t.F_baseUnit = baseUnit
	t.F_rangeUnit = rangeUnit
	t.F_range = range_
	t.F_displayNameKey = displayNameKey
}
func (t *ChronoField) GetDisplayName_Locale__String(locale *Locale) *String {
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	if t.F_displayNameKey == nil { return t.F_name } else {

		var lr *LocaleResources = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(CalendarDataUtility_FindRegionOverride_Locale__Locale(locale)); var rb ResourceBundle_I = NN(lr).GetJavaTimeFormatData__ResourceBundle(); var key *String = Concat(Lit_2458, t.F_displayNameKey)



		if rb.ContainsKey_String__Z(key) { return rb.GetString_String__String(key) } else { return t.F_name
		} } }
func (t *ChronoField) GetBaseUnit__TemporalUnit() TemporalUnit { return t.F_baseUnit }

func (t *ChronoField) GetRangeUnit__TemporalUnit() TemporalUnit { return t.F_rangeUnit }

func (t *ChronoField) Range__ValueRange() *ValueRange { return t.F_range }

func (t *ChronoField) IsDateBased__Z() bool {
	var tmp1 bool; tmp1 = t.Ordinal__I() >= NN(ChronoField_DAY_OF_WEEK).Ordinal__I(); if tmp1 { tmp1 = t.Ordinal__I() <= NN(ChronoField_ERA).Ordinal__I() }; return tmp1
}
func (t *ChronoField) IsTimeBased__Z() bool {
	return t.Ordinal__I() < NN(ChronoField_DAY_OF_WEEK).Ordinal__I()
}
func (t *ChronoField) CheckValidValue_J__J(value int64) int64 {
	return NN(t.Range__ValueRange()).CheckValidValue_J_TemporalField__J(value, t)
}
func (t *ChronoField) CheckValidIntValue_J__I(value int64) int32 {
	return NN(t.Range__ValueRange()).CheckValidIntValue_J_TemporalField__I(value, t)
}
func (t *ChronoField) IsSupportedBy_TemporalAccessor__Z(temporal TemporalAccessor) bool {
	return temporal.IsSupported_TemporalField__Z(t)
}
func (t *ChronoField) RangeRefinedBy_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	return temporal.Range_TemporalField__ValueRange(t)
}
func (t *ChronoField) GetFrom_TemporalAccessor__J(temporal TemporalAccessor) int64 {
	return temporal.GetLong_TemporalField__J(t)
}
func (t *ChronoField) AdjustInto_Temporal_J__Temporal(temporal Temporal, newValue int64) Temporal {

	return temporal.With_TemporalField_J__Temporal(t, newValue)
}
func (t *ChronoField) ToString__String() *String { return t.F_name }



type ChronoField struct{ Enum; F_name *String; F_baseUnit, F_rangeUnit TemporalUnit; F_range *ValueRange; F_displayNameKey *String }

func (t *ChronoField) Is_TemporalField() {}

func (t *ChronoField) Is_Constable() {}

var ChronoField_NANO_OF_SECOND *ChronoField

var ChronoField_NANO_OF_DAY *ChronoField

var ChronoField_MICRO_OF_SECOND *ChronoField

var ChronoField_MICRO_OF_DAY *ChronoField

var ChronoField_MILLI_OF_SECOND *ChronoField

var ChronoField_MILLI_OF_DAY *ChronoField

var ChronoField_SECOND_OF_MINUTE *ChronoField

var ChronoField_SECOND_OF_DAY *ChronoField

var ChronoField_MINUTE_OF_HOUR *ChronoField

var ChronoField_MINUTE_OF_DAY *ChronoField

var ChronoField_HOUR_OF_AMPM *ChronoField

var ChronoField_CLOCK_HOUR_OF_AMPM *ChronoField

var ChronoField_HOUR_OF_DAY *ChronoField

var ChronoField_CLOCK_HOUR_OF_DAY *ChronoField

var ChronoField_AMPM_OF_DAY *ChronoField

var ChronoField_DAY_OF_WEEK *ChronoField

var ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH *ChronoField

var ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR *ChronoField

var ChronoField_DAY_OF_MONTH *ChronoField

var ChronoField_DAY_OF_YEAR *ChronoField

var ChronoField_EPOCH_DAY *ChronoField

var ChronoField_ALIGNED_WEEK_OF_MONTH *ChronoField

var ChronoField_ALIGNED_WEEK_OF_YEAR *ChronoField

var ChronoField_MONTH_OF_YEAR *ChronoField

var ChronoField_PROLEPTIC_MONTH *ChronoField

var ChronoField_YEAR_OF_ERA *ChronoField

var ChronoField_YEAR *ChronoField

var ChronoField_ERA *ChronoField

var ChronoField_INSTANT_SECONDS *ChronoField

var ChronoField_OFFSET_SECONDS *ChronoField

var ChronoField__VALUES *RefArray

var ChronoField_init ClassInit

func ChronoField_Init() { if !ChronoField_init.Done() { ChronoField_init.Run(ChronoField_clinit) } }

func ChronoField_clinit() { var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_NANOS; var tmp2 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp1); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_SECONDS; var tmp4 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp3); ChronoField_NANO_OF_SECOND = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2397, 0, Lit_2396, tmp2, tmp4, ValueRange_Of_J_J__ValueRange(0, 999999999)); var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_NANOS; var tmp6 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp5); var tmp7 *ChronoUnit; ChronoUnit_Init(); tmp7 = ChronoUnit_DAYS; var tmp8 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp7); ChronoField_NANO_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2399, 1, Lit_2398, tmp6, tmp8, ValueRange_Of_J_J__ValueRange(0, 86399999999999)); var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_MICROS; var tmp10 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp9); var tmp11 *ChronoUnit; ChronoUnit_Init(); tmp11 = ChronoUnit_SECONDS; var tmp12 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp11); ChronoField_MICRO_OF_SECOND = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2401, 2, Lit_2400, tmp10, tmp12, ValueRange_Of_J_J__ValueRange(0, 999999)); var tmp13 *ChronoUnit; ChronoUnit_Init(); tmp13 = ChronoUnit_MICROS; var tmp14 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp13); var tmp15 *ChronoUnit; ChronoUnit_Init(); tmp15 = ChronoUnit_DAYS; var tmp16 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp15); ChronoField_MICRO_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2403, 3, Lit_2402, tmp14, tmp16, ValueRange_Of_J_J__ValueRange(0, 86399999999)); var tmp17 *ChronoUnit; ChronoUnit_Init(); tmp17 = ChronoUnit_MILLIS; var tmp18 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp17); var tmp19 *ChronoUnit; ChronoUnit_Init(); tmp19 = ChronoUnit_SECONDS; var tmp20 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp19); ChronoField_MILLI_OF_SECOND = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2405, 4, Lit_2404, tmp18, tmp20, ValueRange_Of_J_J__ValueRange(0, 999)); var tmp21 *ChronoUnit; ChronoUnit_Init(); tmp21 = ChronoUnit_MILLIS; var tmp22 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp21); var tmp23 *ChronoUnit; ChronoUnit_Init(); tmp23 = ChronoUnit_DAYS; var tmp24 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp23); ChronoField_MILLI_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2407, 5, Lit_2406, tmp22, tmp24, ValueRange_Of_J_J__ValueRange(0, 86399999)); var tmp25 *ChronoUnit; ChronoUnit_Init(); tmp25 = ChronoUnit_SECONDS; var tmp26 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp25); var tmp27 *ChronoUnit; ChronoUnit_Init(); tmp27 = ChronoUnit_MINUTES; var tmp28 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp27); ChronoField_SECOND_OF_MINUTE = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2409, 6, Lit_2408, tmp26, tmp28, ValueRange_Of_J_J__ValueRange(0, 59), Lit_1786); var tmp29 *ChronoUnit; ChronoUnit_Init(); tmp29 = ChronoUnit_SECONDS; var tmp30 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp29); var tmp31 *ChronoUnit; ChronoUnit_Init(); tmp31 = ChronoUnit_DAYS; var tmp32 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp31); ChronoField_SECOND_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2411, 7, Lit_2410, tmp30, tmp32, ValueRange_Of_J_J__ValueRange(0, 86399)); var tmp33 *ChronoUnit; ChronoUnit_Init(); tmp33 = ChronoUnit_MINUTES; var tmp34 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp33); var tmp35 *ChronoUnit; ChronoUnit_Init(); tmp35 = ChronoUnit_HOURS; var tmp36 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp35); ChronoField_MINUTE_OF_HOUR = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2413, 8, Lit_2412, tmp34, tmp36, ValueRange_Of_J_J__ValueRange(0, 59), Lit_1785); var tmp37 *ChronoUnit; ChronoUnit_Init(); tmp37 = ChronoUnit_MINUTES; var tmp38 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp37); var tmp39 *ChronoUnit; ChronoUnit_Init(); tmp39 = ChronoUnit_DAYS; var tmp40 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp39); ChronoField_MINUTE_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2415, 9, Lit_2414, tmp38, tmp40, ValueRange_Of_J_J__ValueRange(0, 1439)); var tmp41 *ChronoUnit; ChronoUnit_Init(); tmp41 = ChronoUnit_HOURS; var tmp42 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp41); var tmp43 *ChronoUnit; ChronoUnit_Init(); tmp43 = ChronoUnit_HALF_DAYS; var tmp44 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp43); ChronoField_HOUR_OF_AMPM = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2417, 10, Lit_2416, tmp42, tmp44, ValueRange_Of_J_J__ValueRange(0, 11)); var tmp45 *ChronoUnit; ChronoUnit_Init(); tmp45 = ChronoUnit_HOURS; var tmp46 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp45); var tmp47 *ChronoUnit; ChronoUnit_Init(); tmp47 = ChronoUnit_HALF_DAYS; var tmp48 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp47); ChronoField_CLOCK_HOUR_OF_AMPM = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2419, 11, Lit_2418, tmp46, tmp48, ValueRange_Of_J_J__ValueRange(1, 12)); var tmp49 *ChronoUnit; ChronoUnit_Init(); tmp49 = ChronoUnit_HOURS; var tmp50 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp49); var tmp51 *ChronoUnit; ChronoUnit_Init(); tmp51 = ChronoUnit_DAYS; var tmp52 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp51); ChronoField_HOUR_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2421, 12, Lit_2420, tmp50, tmp52, ValueRange_Of_J_J__ValueRange(0, 23), Lit_1795); var tmp53 *ChronoUnit; ChronoUnit_Init(); tmp53 = ChronoUnit_HOURS; var tmp54 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp53); var tmp55 *ChronoUnit; ChronoUnit_Init(); tmp55 = ChronoUnit_DAYS; var tmp56 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp55); ChronoField_CLOCK_HOUR_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2423, 13, Lit_2422, tmp54, tmp56, ValueRange_Of_J_J__ValueRange(1, 24)); var tmp57 *ChronoUnit; ChronoUnit_Init(); tmp57 = ChronoUnit_HALF_DAYS; var tmp58 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp57); var tmp59 *ChronoUnit; ChronoUnit_Init(); tmp59 = ChronoUnit_DAYS; var tmp60 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp59); ChronoField_AMPM_OF_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2426, 14, Lit_2424, tmp58, tmp60, ValueRange_Of_J_J__ValueRange(0, 1), Lit_2425); var tmp61 *ChronoUnit; ChronoUnit_Init(); tmp61 = ChronoUnit_DAYS; var tmp62 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp61); var tmp63 *ChronoUnit; ChronoUnit_Init(); tmp63 = ChronoUnit_WEEKS; var tmp64 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp63); ChronoField_DAY_OF_WEEK = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2428, 15, Lit_2358, tmp62, tmp64, ValueRange_Of_J_J__ValueRange(1, 7), Lit_2427); var tmp65 *ChronoUnit; ChronoUnit_Init(); tmp65 = ChronoUnit_DAYS; var tmp66 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp65); var tmp67 *ChronoUnit; ChronoUnit_Init(); tmp67 = ChronoUnit_WEEKS; var tmp68 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp67); ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2430, 16, Lit_2429, tmp66, tmp68, ValueRange_Of_J_J__ValueRange(1, 7)); var tmp69 *ChronoUnit; ChronoUnit_Init(); tmp69 = ChronoUnit_DAYS; var tmp70 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp69); var tmp71 *ChronoUnit; ChronoUnit_Init(); tmp71 = ChronoUnit_WEEKS; var tmp72 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp71); ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2432, 17, Lit_2431, tmp70, tmp72, ValueRange_Of_J_J__ValueRange(1, 7)); var tmp73 *ChronoUnit; ChronoUnit_Init(); tmp73 = ChronoUnit_DAYS; var tmp74 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp73); var tmp75 *ChronoUnit; ChronoUnit_Init(); tmp75 = ChronoUnit_MONTHS; var tmp76 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp75); ChronoField_DAY_OF_MONTH = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2435, 18, Lit_2433, tmp74, tmp76, ValueRange_Of_J_J_J__ValueRange(1, 28, 31), Lit_2434); var tmp77 *ChronoUnit; ChronoUnit_Init(); tmp77 = ChronoUnit_DAYS; var tmp78 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp77); var tmp79 *ChronoUnit; ChronoUnit_Init(); tmp79 = ChronoUnit_YEARS; var tmp80 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp79); ChronoField_DAY_OF_YEAR = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2437, 19, Lit_2436, tmp78, tmp80, ValueRange_Of_J_J_J__ValueRange(1, 365, 366)); var tmp81 *ChronoUnit; ChronoUnit_Init(); tmp81 = ChronoUnit_DAYS; var tmp82 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp81); var tmp83 *ChronoUnit; ChronoUnit_Init(); tmp83 = ChronoUnit_FOREVER; var tmp84 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp83); ChronoField_EPOCH_DAY = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2439, 20, Lit_2438, tmp82, tmp84, ValueRange_Of_J_J__ValueRange(-365243219162, 365241780471)); var tmp85 *ChronoUnit; ChronoUnit_Init(); tmp85 = ChronoUnit_WEEKS; var tmp86 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp85); var tmp87 *ChronoUnit; ChronoUnit_Init(); tmp87 = ChronoUnit_MONTHS; var tmp88 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp87); ChronoField_ALIGNED_WEEK_OF_MONTH = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2441, 21, Lit_2440, tmp86, tmp88, ValueRange_Of_J_J_J__ValueRange(1, 4, 5)); var tmp89 *ChronoUnit; ChronoUnit_Init(); tmp89 = ChronoUnit_WEEKS; var tmp90 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp89); var tmp91 *ChronoUnit; ChronoUnit_Init(); tmp91 = ChronoUnit_YEARS; var tmp92 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp91); ChronoField_ALIGNED_WEEK_OF_YEAR = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2443, 22, Lit_2442, tmp90, tmp92, ValueRange_Of_J_J__ValueRange(1, 53)); var tmp93 *ChronoUnit; ChronoUnit_Init(); tmp93 = ChronoUnit_MONTHS; var tmp94 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp93); var tmp95 *ChronoUnit; ChronoUnit_Init(); tmp95 = ChronoUnit_YEARS; var tmp96 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp95); ChronoField_MONTH_OF_YEAR = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2445, 23, Lit_2444, tmp94, tmp96, ValueRange_Of_J_J__ValueRange(1, 12), Lit_1781); var tmp97 *ChronoUnit; ChronoUnit_Init(); tmp97 = ChronoUnit_MONTHS; var tmp98 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp97); var tmp99 *ChronoUnit; ChronoUnit_Init(); tmp99 = ChronoUnit_FOREVER; var tmp100 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp99); ChronoField_PROLEPTIC_MONTH = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2447, 24, Lit_2446, tmp98, tmp100, ValueRange_Of_J_J__ValueRange(-11999999988, 11999999999)); var tmp101 *ChronoUnit; ChronoUnit_Init(); tmp101 = ChronoUnit_YEARS; var tmp102 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp101); var tmp103 *ChronoUnit; ChronoUnit_Init(); tmp103 = ChronoUnit_FOREVER; var tmp104 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp103); ChronoField_YEAR_OF_ERA = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2449, 25, Lit_2448, tmp102, tmp104, ValueRange_Of_J_J_J__ValueRange(1, 999999999, 1000000000)); var tmp105 *ChronoUnit; ChronoUnit_Init(); tmp105 = ChronoUnit_YEARS; var tmp106 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp105); var tmp107 *ChronoUnit; ChronoUnit_Init(); tmp107 = ChronoUnit_FOREVER; var tmp108 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp107); ChronoField_YEAR = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2451, 26, Lit_2450, tmp106, tmp108, ValueRange_Of_J_J__ValueRange(-999999999, 999999999), Lit_1780); var tmp109 *ChronoUnit; ChronoUnit_Init(); tmp109 = ChronoUnit_ERAS; var tmp110 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp109); var tmp111 *ChronoUnit; ChronoUnit_Init(); tmp111 = ChronoUnit_FOREVER; var tmp112 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp111); ChronoField_ERA = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange_String(Lit_2453, 27, Lit_2452, tmp110, tmp112, ValueRange_Of_J_J__ValueRange(0, 1), Lit_1779); var tmp113 *ChronoUnit; ChronoUnit_Init(); tmp113 = ChronoUnit_SECONDS; var tmp114 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp113); var tmp115 *ChronoUnit; ChronoUnit_Init(); tmp115 = ChronoUnit_FOREVER; var tmp116 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp115); var tmp117 *Instant; Instant_Init(); tmp117 = Instant_MIN; var tmp118 int64 = NN(tmp117).GetEpochSecond__J(); var tmp119 *Instant; Instant_Init(); tmp119 = Instant_MAX; ChronoField_INSTANT_SECONDS = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2455, 28, Lit_2454, tmp114, tmp116, ValueRange_Of_J_J__ValueRange(tmp118, NN(tmp119).GetEpochSecond__J())); var tmp120 *ChronoUnit; ChronoUnit_Init(); tmp120 = ChronoUnit_SECONDS; var tmp121 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp120); var tmp122 *ChronoUnit; ChronoUnit_Init(); tmp122 = ChronoUnit_FOREVER; var tmp123 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp122); ChronoField_OFFSET_SECONDS = ChronoField_New_String_I_String_TemporalUnit_TemporalUnit_ValueRange(Lit_2457, 29, Lit_2456, tmp121, tmp123, ValueRange_Of_J_J__ValueRange(-64800, 64800)); ChronoField__VALUES = ChronoField_X_values__ChronoField1() }

func ChronoField_Values__ChronoField1() *RefArray { ChronoField_Init(); return ChronoField__VALUES.Copy() }

func ChronoField_ValueOf_String__ChronoField(p0 *String) *ChronoField { ChronoField_Init(); return ChronoField_Cast(Enum_ValueOf_Class_String__Enum(ChronoField_class, p0)) }

func ChronoField_X_values__ChronoField1() *RefArray { ChronoField_Init(); return RefArrayOf(ChronoField_class, ChronoField_NANO_OF_SECOND, ChronoField_NANO_OF_DAY, ChronoField_MICRO_OF_SECOND, ChronoField_MICRO_OF_DAY, ChronoField_MILLI_OF_SECOND, ChronoField_MILLI_OF_DAY, ChronoField_SECOND_OF_MINUTE, ChronoField_SECOND_OF_DAY, ChronoField_MINUTE_OF_HOUR, ChronoField_MINUTE_OF_DAY, ChronoField_HOUR_OF_AMPM, ChronoField_CLOCK_HOUR_OF_AMPM, ChronoField_HOUR_OF_DAY, ChronoField_CLOCK_HOUR_OF_DAY, ChronoField_AMPM_OF_DAY, ChronoField_DAY_OF_WEEK, ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH, ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR, ChronoField_DAY_OF_MONTH, ChronoField_DAY_OF_YEAR, ChronoField_EPOCH_DAY, ChronoField_ALIGNED_WEEK_OF_MONTH, ChronoField_ALIGNED_WEEK_OF_YEAR, ChronoField_MONTH_OF_YEAR, ChronoField_PROLEPTIC_MONTH, ChronoField_YEAR_OF_ERA, ChronoField_YEAR, ChronoField_ERA, ChronoField_INSTANT_SECONDS, ChronoField_OFFSET_SECONDS) }

func (t *ChronoField) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.ChronoField.describeConstable()Ljava/util/Optional;")) }

func (t *ChronoField) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ChronoField) Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor { return TemporalField_Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(t, p0, p1, p2) }

func (t *ChronoField) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ChronoField) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ChronoField) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ChronoField) Ref() any { if t == nil { return nil }; return t }

func (t *ChronoField) GetClass__Class() *Class { return ChronoField_class }

func (t *ChronoField) CloneShallow() any { panic(CloneNotSupported(t)) }

func ChronoField_InstanceOf(x any) bool { _, ok := x.(*ChronoField); return ok }

func ChronoField_Cast(x any) *ChronoField { if x == nil { return nil }; v, ok := x.(*ChronoField); if !ok { panic(ClassCast(x, ChronoField_class)) }; return v }
