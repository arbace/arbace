//line java_security_MessageDigest.ae:1
package jrt




























func (t *MessageDigest) Ctor_String(this MessageDigest_I, algorithm *String) { panic(A2g_NotTranslated("java.security.MessageDigest.<init>(Ljava/lang/String;)V")) }


func (t *MessageDigest) Ctor_String_Provider(this MessageDigest_I, algorithm *String, p Provider_I) { t.MessageDigestSpi.Ctor(this); t.F_state = 0
	t.F_algorithm = algorithm
	t.F_provider = p
}
func MessageDigest_GetInstance_String__MessageDigest(algorithm *String) MessageDigest_I { MessageDigest_Init()
	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	if CryptoAlgorithmConstraints_Permits_String_String__Z(Lit_1538, algorithm) { } else {
		panic(Thrown(NoSuchAlgorithmException_New_String(Concat(algorithm, Lit_1539)))) }
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String__GetInstance_Instance(Lit_1538, MessageDigestSpi_class, algorithm); var md MessageDigest_I; var tmp1 any = instance.F_impl

	if MessageDigest_InstanceOf(tmp1) { var messageDigest MessageDigest_I = MessageDigest_Cast(tmp1)
		md = messageDigest; md.Self_MessageDigest().F_provider = instance.F_provider } else {
			var tmp2 MessageDigestSpi_I = MessageDigestSpi_Cast(instance.F_impl); md = MessageDigest_Delegate_Of_MessageDigestSpi_String_Provider__MessageDigest_Delegate(tmp2, algorithm, instance.F_provider)
		}


	var tmp3 bool; var tmp4 bool; tmp4 = !MessageDigest_skipDebug; if tmp4 { tmp4 = !(MessageDigest_pdebug == nil) }; tmp3 = tmp4; if tmp3 {
		var tmp5 *Debug = MessageDigest_pdebug; NN(tmp5).Println_String__V(Concat(Lit_1540, algorithm, Lit_1541, md.Self_MessageDigest().F_provider.GetName__String())) }
//line :41:1
	return md
}














func MessageDigest_GetInstance_String_String__MessageDigest(algorithm, provider *String) MessageDigest_I { MessageDigest_Init()

	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	var tmp1 bool; var tmp2 bool; tmp2 = provider == nil; if !tmp2 { tmp2 = NN(provider).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1542))) }
	if CryptoAlgorithmConstraints_Permits_String_String__Z(Lit_1538, algorithm) { } else {
		panic(Thrown(NoSuchAlgorithmException_New_String(Concat(algorithm, Lit_1539)))) }
	var instance *GetInstance_Instance = GetInstance_GetInstance_String_Class_String_String__GetInstance_Instance(Lit_1538, MessageDigestSpi_class, algorithm, provider); var md MessageDigest_I; var tmp3 any = instance.F_impl

	if MessageDigest_InstanceOf(tmp3) { var messageDigest MessageDigest_I = MessageDigest_Cast(tmp3)
		md = messageDigest; md.Self_MessageDigest().F_provider = instance.F_provider } else {
			var tmp4 MessageDigestSpi_I = MessageDigestSpi_Cast(instance.F_impl); md = MessageDigest_Delegate_Of_MessageDigestSpi_String_Provider__MessageDigest_Delegate(tmp4, algorithm, instance.F_provider) }
//line :64:1
	return md
}








func MessageDigest_GetInstance_String_Provider__MessageDigest(algorithm *String, provider Provider_I) MessageDigest_I { MessageDigest_Init()

	Objects_RequireNonNull_O_String__O(algorithm.Ref(), Lit_1537)
	if provider == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1542))) }
	if CryptoAlgorithmConstraints_Permits_String_String__Z(Lit_1538, algorithm) { } else {
		panic(Thrown(NoSuchAlgorithmException_New_String(Concat(algorithm, Lit_1539)))) }
	var objs *RefArray = Security_GetImpl_String_String_Provider__O1(algorithm, Lit_1538, provider); var tmp1 any = objs.A[0]
	if MessageDigest_InstanceOf(tmp1) { var md MessageDigest_I = MessageDigest_Cast(tmp1)
		md.Self_MessageDigest().F_provider = Provider_Cast(objs.A[1]); return md } else {
			var tmp2 MessageDigestSpi_I = MessageDigestSpi_Cast(objs.A[0]); return MessageDigest_Delegate_Of_MessageDigestSpi_String_Provider__MessageDigest_Delegate(tmp2, algorithm, Provider_Cast(objs.A[1]))
		} }
func (t *MessageDigest) Impl_GetProvider__Provider(this MessageDigest_I) Provider_I { return t.F_provider }

func (t *MessageDigest) Impl_Update_B__V(this MessageDigest_I, input int8) {
	this.EngineUpdate_B__V(input)
	t.F_state = 1
}
func (t *MessageDigest) Impl_Update_B1_I_I__V(this MessageDigest_I, input *ByteArray, offset, len_ int32) {
	if input == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1543))) }
	if int32(len(input.A))-offset < len_ {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1544))) }
	this.EngineUpdate_B1_I_I__V(input, offset, len_)
	t.F_state = 1
}
func (t *MessageDigest) Impl_Update_B1__V(this MessageDigest_I, input *ByteArray) {
	this.EngineUpdate_B1_I_I__V(input, 0, int32(len(input.A)))
	t.F_state = 1
}
func (t *MessageDigest) Impl_Update_ByteBuffer__V(this MessageDigest_I, input ByteBuffer_I) {
	if input == nil { panic(Thrown(NullPointerException_New())) }
	this.EngineUpdate_ByteBuffer__V(input)
	t.F_state = 1
}
func (t *MessageDigest) Impl_Digest__B1(this MessageDigest_I) *ByteArray {
	var result *ByteArray = this.EngineDigest__B1(); t.F_state = 0; return result
}
func (t *MessageDigest) Impl_Digest_B1_I_I__I(this MessageDigest_I, buf *ByteArray, offset, len_ int32) int32 {
	if buf == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1545))) }
	if int32(len(buf.A))-offset < len_ {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1546))) }
	var numBytes int32 = this.EngineDigest_B1_I_I__I(buf, offset, len_); t.F_state = 0; return numBytes
}
func (t *MessageDigest) Impl_Digest_B1__B1(this MessageDigest_I, input *ByteArray) *ByteArray {
	this.Update_B1__V(input)
	return this.Digest__B1()
}
func (t *MessageDigest) Impl_GetProviderName__String(this MessageDigest_I) *String {
	if t.F_provider == nil { return Lit_1547 } else { return t.F_provider.GetName__String()
	} }
func (t *MessageDigest) Impl_ToString__String(this MessageDigest_I) *String {
	var baos *ByteArrayOutputStream = ByteArrayOutputStream_New(); var p *PrintStream = PrintStream_New_OutputStream(Up_ByteArrayOutputStream_OutputStream(baos)); var tmp1 *String = t.F_algorithm

	NN(p).Print_String__V(Concat(tmp1, Lit_1548, t.Impl_GetProviderName__String(this), Lit_1178))
	switch t.F_state { case 0: NN(p).Print_String__V(Lit_1549); case 1: NN(p).Print_String__V(Lit_1550); default:}
	NN(p).Println__V()
	return NN(baos).ToString__String()
}
func MessageDigest_IsEqual_B1_B1__Z(digesta, digestb *ByteArray) bool { MessageDigest_Init()
	if digesta == digestb { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = digesta == nil; if !tmp2 { tmp2 = digestb == nil }; tmp1 = tmp2
//line :132:1
		if tmp1 { return false } else {



			var lenA int32 = int32(len(digesta.A)); var lenB int32 = int32(len(digestb.A))

			if lenB == 0 {
				return lenA == 0 } else {
					var result int32 = 0
					result = result | (lenA - lenB)
					var i int32 = 0; L1: for {
						if i < lenA {
							var indexB int32 = int32(uint32(i-lenB)>>31) * i; var tmp3 int32 = int32(digesta.A[i])


							result = result | (tmp3 ^ int32(digestb.A[indexB]))


							i = i + 1; continue L1 }
//line :142:1
						break L1
					}







					return result == 0
				} } } }
func (t *MessageDigest) Impl_Reset__V(this MessageDigest_I) {
	this.EngineReset__V()
	t.F_state = 0
}
func (t *MessageDigest) Impl_GetAlgorithm__String(this MessageDigest_I) *String { return t.F_algorithm }

func (t *MessageDigest) Impl_GetDigestLength__I(this MessageDigest_I) int32 {
	var digestLen int32 = this.EngineGetDigestLength__I()
	if digestLen == 0 { tmp1, tmp2, tmp3 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc)

		{ var md MessageDigest_I = MessageDigest_Cast(this.Clone__O()); var digest *ByteArray = md.Digest__B1(); return 2, int32(len(digest.A)), nil }; return 0, 0, nil }()
//line :162:1
		if tmp3 != nil { if CloneNotSupportedException_InstanceOf(tmp3) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp3); _ = e



			return digestLen } else {
//line :162:1
				panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }} }
//line :160:1
	return digestLen
}







func (t *MessageDigest) Impl_Clone__O(this MessageDigest_I) any {
	if Cloneable_InstanceOf(this) { return t.MessageDigestSpi.Impl_Clone__O(this) } else { panic(Thrown(CloneNotSupportedException_New()))
	}
}







func MessageDigest_Delegate_CloneableDelegate_New_MessageDigestSpi_String_Provider(p0 MessageDigestSpi_I, p1 *String, p2 Provider_I) *MessageDigest_Delegate_CloneableDelegate { MessageDigest_Delegate_CloneableDelegate_Init(); t := &MessageDigest_Delegate_CloneableDelegate{}; t.Ctor_MessageDigestSpi_String_Provider(p0, p1, p2); return t }
//line :180:1
func (t *MessageDigest_Delegate_CloneableDelegate) Ctor_MessageDigestSpi_String_Provider(digestSpi MessageDigestSpi_I, algorithm *String, p Provider_I) { t.MessageDigest_Delegate.Ctor_MessageDigestSpi_String_Provider(t, digestSpi, algorithm, p) }




func MessageDigest_Delegate_Of_MessageDigestSpi_String_Provider__MessageDigest_Delegate(digestSpi MessageDigestSpi_I, algo *String, p Provider_I) MessageDigest_Delegate_I { MessageDigest_Delegate_Init()
	Objects_RequireNonNull_O__O(digestSpi)
	var isCloneable bool = Cloneable_InstanceOf(digestSpi); var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = isCloneable; if tmp3 { tmp3 = NN(p.GetName__String()).StartsWith_String__Z(Lit_1551) }; tmp2 = tmp3; if tmp2 {
		tmp2 = NN(A2g_Missing[*String]("class java.lang.Module is not in the closed world")).Equals_O__Z(Lit_1552) }
//line :188:1
	tmp1 = tmp2; if tmp1 { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

		digestSpi.Clone__O()
//line :188:1
		return nil
	}()
		if tmp4 != nil { if CloneNotSupportedException_InstanceOf(tmp4) { var cnse *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp4); _ = cnse; isCloneable = false } else { panic(tmp4) } } }
	if isCloneable {
		return MessageDigest_Delegate_CloneableDelegate_New_MessageDigestSpi_String_Provider(digestSpi, algo, p) } else {
			return MessageDigest_Delegate_New_MessageDigestSpi_String_Provider(digestSpi, algo, p)
		} }
func MessageDigest_Delegate_New_MessageDigestSpi_String_Provider(p0 MessageDigestSpi_I, p1 *String, p2 Provider_I) *MessageDigest_Delegate { MessageDigest_Delegate_Init(); t := &MessageDigest_Delegate{}; t.Ctor_MessageDigestSpi_String_Provider(t, p0, p1, p2); return t }
//line :195:1
func (t *MessageDigest_Delegate) Ctor_MessageDigestSpi_String_Provider(this MessageDigest_Delegate_I, digestSpi MessageDigestSpi_I, algorithm *String, p Provider_I) { t.MessageDigest.Ctor_String_Provider(this, algorithm, p)

	t.F_digestSpi = digestSpi
}
func (t *MessageDigest_Delegate) Impl_Clone__O(this MessageDigest_Delegate_I) any {
	if Cloneable_InstanceOf(this) {
		var that MessageDigest_I = MessageDigest_Delegate_CloneableDelegate_New_MessageDigestSpi_String_Provider(MessageDigestSpi_Cast(t.F_digestSpi.Clone__O()), t.F_algorithm, t.F_provider)



		that.Self_MessageDigest().F_state = t.F_state
//line :201:1
		return that


	} else {


		panic(Thrown(CloneNotSupportedException_New()))
	} }
func (t *MessageDigest_Delegate) Impl_EngineGetDigestLength__I(this MessageDigest_Delegate_I) int32 {
	return t.F_digestSpi.EngineGetDigestLength__I()
}
func (t *MessageDigest_Delegate) Impl_EngineUpdate_B__V(this MessageDigest_Delegate_I, input int8) {
	t.F_digestSpi.EngineUpdate_B__V(input)
}
func (t *MessageDigest_Delegate) Impl_EngineUpdate_B1_I_I__V(this MessageDigest_Delegate_I, input *ByteArray, offset, len_ int32) {
	t.F_digestSpi.EngineUpdate_B1_I_I__V(input, offset, len_)
}
func (t *MessageDigest_Delegate) Impl_EngineUpdate_ByteBuffer__V(this MessageDigest_Delegate_I, input ByteBuffer_I) {
	t.F_digestSpi.EngineUpdate_ByteBuffer__V(input)
}
func (t *MessageDigest_Delegate) Impl_EngineUpdate_SecretKey__V(this MessageDigest_Delegate_I, key SecretKey) {
	if MessageDigestSpi2_InstanceOf(t.F_digestSpi) {
		MessageDigestSpi2_Cast(t.F_digestSpi).EngineUpdate_SecretKey__V(key) } else {
			panic(Thrown(UnsupportedOperationException_New_String(Lit_1553)))
		}
}
func (t *MessageDigest_Delegate) Impl_EngineDigest__B1(this MessageDigest_Delegate_I) *ByteArray {
	return t.F_digestSpi.EngineDigest__B1()
}
func (t *MessageDigest_Delegate) Impl_EngineDigest_B1_I_I__I(this MessageDigest_Delegate_I, buf *ByteArray, offset, len_ int32) int32 {

	return t.F_digestSpi.EngineDigest_B1_I_I__I(buf, offset, len_)
}
func (t *MessageDigest_Delegate) Impl_EngineReset__V(this MessageDigest_Delegate_I) { t.F_digestSpi.EngineReset__V() }



type MessageDigest struct{ MessageDigestSpi; F_algorithm *String; F_state int32; F_provider Provider_I }

type MessageDigest_I interface{ MessageDigestSpi_I; Self_MessageDigest() *MessageDigest; GetProvider__Provider() Provider_I; Update_B__V(p0 int8); Update_B1_I_I__V(p0 *ByteArray, p1, p2 int32); Update_B1__V(p0 *ByteArray); Update_ByteBuffer__V(p0 ByteBuffer_I); Digest__B1() *ByteArray; Digest_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; Digest_B1__B1(p0 *ByteArray) *ByteArray; Reset__V(); GetAlgorithm__String() *String; GetDigestLength__I() int32 }

func (t *MessageDigest) Self_MessageDigest() *MessageDigest { return t }

var MessageDigest_pdebug *Debug

var MessageDigest_skipDebug bool

const MessageDigest_INITIAL int32 = 0

const MessageDigest_IN_PROGRESS int32 = 1

var MessageDigest_init ClassInit

func MessageDigest_Init() { if !MessageDigest_init.Done() { MessageDigest_init.Run(MessageDigest_clinit) } }

func MessageDigest_clinit() { MessageDigest_pdebug = Debug_GetInstance_String_String__Debug(Lit_1533, Lit_1534)
//line :18:1
	var tmp1 bool; var tmp2 bool; tmp2 = Debug_IsOn_String__Z(Lit_1535); if tmp2 { tmp2 = !Debug_IsOn_String__Z(Lit_1536) }; tmp1 = tmp2; MessageDigest_skipDebug = tmp1
}














































































































































































































































func MessageDigest_InstanceOf(x any) bool { _, ok := x.(MessageDigest_I); return ok }

func MessageDigest_Cast(x any) MessageDigest_I { if x == nil { return nil }; v, ok := x.(MessageDigest_I); if !ok { panic(ClassCast(x, MessageDigest_class)) }; return v }



type MessageDigest_Delegate struct{ MessageDigest; F_digestSpi MessageDigestSpi_I }

type MessageDigest_Delegate_I interface{ MessageDigest_I; MessageDigestSpi2; Self_MessageDigest_Delegate() *MessageDigest_Delegate; EngineGetDigestLength__I() int32; EngineUpdate_B__V(p0 int8); EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32); EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I); EngineUpdate_SecretKey__V(p0 SecretKey); EngineDigest__B1() *ByteArray; EngineDigest_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; EngineReset__V() }

func (t *MessageDigest_Delegate) Self_MessageDigest_Delegate() *MessageDigest_Delegate { return t }

func (t *MessageDigest_Delegate) Is_MessageDigestSpi2() {}

var MessageDigest_Delegate_init ClassInit

func MessageDigest_Delegate_Init() { if !MessageDigest_Delegate_init.Done() { MessageDigest_Delegate_init.Run(MessageDigest_Delegate_clinit) } }

func MessageDigest_Delegate_clinit() { MessageDigest_Init() }

func (t *MessageDigest_Delegate) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *MessageDigest_Delegate) EngineDigest__B1() *ByteArray { return t.Impl_EngineDigest__B1(t) }

func (t *MessageDigest_Delegate) Update_B1__V(p0 *ByteArray) { t.Impl_Update_B1__V(t, p0) }

func (t *MessageDigest_Delegate) Update_B__V(p0 int8) { t.Impl_Update_B__V(t, p0) }

func (t *MessageDigest_Delegate) GetAlgorithm__String() *String { return t.Impl_GetAlgorithm__String(t) }

func (t *MessageDigest_Delegate) GetDigestLength__I() int32 { return t.Impl_GetDigestLength__I(t) }

func (t *MessageDigest_Delegate) Digest_B1__B1(p0 *ByteArray) *ByteArray { return t.Impl_Digest_B1__B1(t, p0) }

func (t *MessageDigest_Delegate) Update_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_Update_ByteBuffer__V(t, p0) }

func (t *MessageDigest_Delegate) EngineUpdate_SecretKey__V(p0 SecretKey) { t.Impl_EngineUpdate_SecretKey__V(t, p0) }

func (t *MessageDigest_Delegate) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *MessageDigest_Delegate) Digest_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_Digest_B1_I_I__I(t, p0, p1, p2) }

func (t *MessageDigest_Delegate) Digest__B1() *ByteArray { return t.Impl_Digest__B1(t) }

func (t *MessageDigest_Delegate) Update_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_Update_B1_I_I__V(t, p0, p1, p2) }

func (t *MessageDigest_Delegate) Reset__V() { t.Impl_Reset__V(t) }

func (t *MessageDigest_Delegate) EngineGetDigestLength__I() int32 { return t.Impl_EngineGetDigestLength__I(t) }

func (t *MessageDigest_Delegate) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *MessageDigest_Delegate) GetProvider__Provider() Provider_I { return t.Impl_GetProvider__Provider(t) }

func (t *MessageDigest_Delegate) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *MessageDigest_Delegate) EngineDigest_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_EngineDigest_B1_I_I__I(t, p0, p1, p2) }

func (t *MessageDigest_Delegate) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *MessageDigest_Delegate) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MessageDigest_Delegate) Ref() any { if t == nil { return nil }; return t }

func (t *MessageDigest_Delegate) GetClass__Class() *Class { return MessageDigest_Delegate_class }

func (t *MessageDigest_Delegate) CloneShallow() any { panic(CloneNotSupported(t)) }

func MessageDigest_Delegate_InstanceOf(x any) bool { _, ok := x.(MessageDigest_Delegate_I); return ok }

func MessageDigest_Delegate_Cast(x any) MessageDigest_Delegate_I { if x == nil { return nil }; v, ok := x.(MessageDigest_Delegate_I); if !ok { panic(ClassCast(x, MessageDigest_Delegate_class)) }; return v }



type MessageDigest_Delegate_CloneableDelegate struct{ MessageDigest_Delegate }

func (t *MessageDigest_Delegate_CloneableDelegate) Is_Cloneable() {}

var MessageDigest_Delegate_CloneableDelegate_init ClassInit

func MessageDigest_Delegate_CloneableDelegate_Init() { if !MessageDigest_Delegate_CloneableDelegate_init.Done() { MessageDigest_Delegate_CloneableDelegate_init.Run(MessageDigest_Delegate_CloneableDelegate_clinit) } }

func MessageDigest_Delegate_CloneableDelegate_clinit() { MessageDigest_Delegate_Init() }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineDigest__B1() *ByteArray { return t.Impl_EngineDigest__B1(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) Update_B1__V(p0 *ByteArray) { t.Impl_Update_B1__V(t, p0) }

func (t *MessageDigest_Delegate_CloneableDelegate) Update_B__V(p0 int8) { t.Impl_Update_B__V(t, p0) }

func (t *MessageDigest_Delegate_CloneableDelegate) GetAlgorithm__String() *String { return t.Impl_GetAlgorithm__String(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) GetDigestLength__I() int32 { return t.Impl_GetDigestLength__I(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) Digest_B1__B1(p0 *ByteArray) *ByteArray { return t.Impl_Digest_B1__B1(t, p0) }

func (t *MessageDigest_Delegate_CloneableDelegate) Update_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_Update_ByteBuffer__V(t, p0) }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineUpdate_SecretKey__V(p0 SecretKey) { t.Impl_EngineUpdate_SecretKey__V(t, p0) }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *MessageDigest_Delegate_CloneableDelegate) Digest_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_Digest_B1_I_I__I(t, p0, p1, p2) }

func (t *MessageDigest_Delegate_CloneableDelegate) Digest__B1() *ByteArray { return t.Impl_Digest__B1(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) Update_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_Update_B1_I_I__V(t, p0, p1, p2) }

func (t *MessageDigest_Delegate_CloneableDelegate) Reset__V() { t.Impl_Reset__V(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineGetDigestLength__I() int32 { return t.Impl_EngineGetDigestLength__I(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *MessageDigest_Delegate_CloneableDelegate) GetProvider__Provider() Provider_I { return t.Impl_GetProvider__Provider(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *MessageDigest_Delegate_CloneableDelegate) EngineDigest_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_EngineDigest_B1_I_I__I(t, p0, p1, p2) }

func (t *MessageDigest_Delegate_CloneableDelegate) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MessageDigest_Delegate_CloneableDelegate) Ref() any { if t == nil { return nil }; return t }

func (t *MessageDigest_Delegate_CloneableDelegate) GetClass__Class() *Class { return MessageDigest_Delegate_CloneableDelegate_class }

func (t *MessageDigest_Delegate_CloneableDelegate) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func MessageDigest_Delegate_CloneableDelegate_InstanceOf(x any) bool { _, ok := x.(*MessageDigest_Delegate_CloneableDelegate); return ok }

func MessageDigest_Delegate_CloneableDelegate_Cast(x any) *MessageDigest_Delegate_CloneableDelegate { if x == nil { return nil }; v, ok := x.(*MessageDigest_Delegate_CloneableDelegate); if !ok { panic(ClassCast(x, MessageDigest_Delegate_CloneableDelegate_class)) }; return v }
