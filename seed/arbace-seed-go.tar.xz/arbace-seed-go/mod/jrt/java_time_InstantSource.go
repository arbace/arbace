//line java_time_InstantSource.ae:1
package jrt






func InstantSource_System__InstantSource() InstantSource { Clock_SystemInstantSource_Init(); return Up_Clock_SystemInstantSource_InstantSource(Clock_SystemInstantSource_INSTANCE) }


func InstantSource_Tick_InstantSource_Duration__InstantSource(baseSource InstantSource, tickDuration *Duration) InstantSource {
	Objects_RequireNonNull_O_String__O(baseSource, Lit_2036)
	var tmp1 *ZoneOffset; ZoneOffset_Init(); tmp1 = ZoneOffset_UTC; return Clock_Tick_Clock_Duration__Clock(baseSource.WithZone_ZoneId__Clock(Up_ZoneOffset_ZoneId(tmp1)), tickDuration)
}
func InstantSource_Fixed_Instant__InstantSource(fixedInstant *Instant) InstantSource {
	var tmp1 *ZoneOffset; ZoneOffset_Init(); tmp1 = ZoneOffset_UTC; return Clock_Fixed_Instant_ZoneId__Clock(fixedInstant, Up_ZoneOffset_ZoneId(tmp1))
}
func InstantSource_Offset_InstantSource_Duration__InstantSource(baseSource InstantSource, offsetDuration *Duration) InstantSource {
	Objects_RequireNonNull_O_String__O(baseSource, Lit_2036)
	var tmp1 *ZoneOffset; ZoneOffset_Init(); tmp1 = ZoneOffset_UTC; return Clock_Offset_Clock_Duration__Clock(baseSource.WithZone_ZoneId__Clock(Up_ZoneOffset_ZoneId(tmp1)), offsetDuration)
}


func InstantSource_Millis__J(this InstantSource) int64 { return NN(this.Instant__Instant()).ToEpochMilli__J() }

func InstantSource_WithZone_ZoneId__Clock(this InstantSource, zone ZoneId_I) Clock_I {
	return Clock_SourceClock_New_InstantSource_ZoneId(this, zone)
}


type InstantSource interface{ Object_I; Is_InstantSource(); Instant__Instant() *Instant; Millis__J() int64; WithZone_ZoneId__Clock(p0 ZoneId_I) Clock_I }

func InstantSource_InstanceOf(x any) bool { _, ok := x.(InstantSource); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InstantSource_class) } }; return ok }

func InstantSource_Cast(x any) InstantSource { if x == nil { return nil }; v, ok := x.(InstantSource); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(InstantSource_class) } }; if !ok { panic(ClassCast(x, InstantSource_class)) }; return v }
