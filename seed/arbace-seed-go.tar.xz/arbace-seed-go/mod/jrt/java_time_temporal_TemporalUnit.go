//line java_time_temporal_TemporalUnit.ae:1
package jrt















func TemporalUnit_IsSupportedBy_Temporal__Z(this TemporalUnit, temporal Temporal) bool {
	if LocalTime_InstanceOf(temporal) {
		return this.IsTimeBased__Z() } else {
//line :18:1
			if ChronoLocalDate_InstanceOf(temporal) {

				return this.IsDateBased__Z() } else {
//line :18:1
					var tmp1 bool; var tmp2 bool


					tmp2 = ChronoLocalDateTime_InstanceOf(temporal); if !tmp2 { tmp2 = ChronoZonedDateTime_InstanceOf(temporal) }; tmp1 = tmp2
//line :18:1
					if tmp1 { return true } else {




						var tmp3 bool; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
							temporal.Plus_J_TemporalUnit__Temporal(1, this)
//line :23:1
							tmp3 = true; return nil }(); if tmp4 != nil { if UnsupportedTemporalTypeException_InstanceOf(tmp4) { var ex *UnsupportedTemporalTypeException = UnsupportedTemporalTypeException_Cast(tmp4); _ = ex; tmp3 = false } else if RuntimeException_InstanceOf(tmp4) { var ex_2 RuntimeException_I = RuntimeException_Cast(tmp4); tmp5 := func() (exc Throwable_I) { defer Catch(&exc)




								temporal.Plus_J_TemporalUnit__Temporal(-1, this); tmp3 = true
//line :23:1
								return nil }(); _ = ex_2




								if tmp5 != nil { if RuntimeException_InstanceOf(tmp5) { var ex2 RuntimeException_I = RuntimeException_Cast(tmp5); _ = ex2; tmp3 = false } else { panic(tmp5) } } } else {
//line :23:1
									panic(tmp4) } }; return tmp3 } } } }
//line :23:1
type TemporalUnit interface{ Object_I; Is_TemporalUnit(); GetDuration__Duration() *Duration; IsDurationEstimated__Z() bool; IsDateBased__Z() bool; IsTimeBased__Z() bool; IsSupportedBy_Temporal__Z(p0 Temporal) bool; AddTo_Temporal_J__Temporal(p0 Temporal, p1 int64) Temporal; Between_Temporal_Temporal__J(p0, p1 Temporal) int64 }

func TemporalUnit_InstanceOf(x any) bool { _, ok := x.(TemporalUnit); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalUnit_class) } }; return ok }

func TemporalUnit_Cast(x any) TemporalUnit { if x == nil { return nil }; v, ok := x.(TemporalUnit); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalUnit_class) } }; if !ok { panic(ClassCast(x, TemporalUnit_class)) }; return v }
