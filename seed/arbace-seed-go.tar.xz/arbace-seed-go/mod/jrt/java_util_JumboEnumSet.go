//line java_util_JumboEnumSet.ae:1
package jrt













func JumboEnumSet_New_Class_Enum1(p0 *Class, p1 *RefArray) *JumboEnumSet { t := &JumboEnumSet{}; t.Ctor_Class_Enum1(p0, p1); return t }
//line :15:1
func (t *JumboEnumSet) Ctor_Class_Enum1(elementType *Class, universe *RefArray) { t.EnumSet.Ctor_Class_Enum1(t, elementType, universe); t.F_size = 0

	t.F_elements = NewLongArray(int32(uint32(int32(len(universe.A))+63) >> 6))
}

func (t *JumboEnumSet) AddRange_Enum_Enum__V(from, to Enum_I) {
	var fromIndex int32 = int32(uint32(from.Ordinal__I()) >> 6); var toIndex int32 = int32(uint32(to.Ordinal__I()) >> 6)

	if fromIndex == toIndex {
		var tmp1 *LongArray = t.F_elements; tmp1.A[fromIndex] = int64(uint64(18446744073709551615)>>((from.Ordinal__I()-to.Ordinal__I()-1)&63)) << (from.Ordinal__I() & 63) } else {








			var tmp2 *LongArray = t.F_elements; tmp2.A[fromIndex] = -1 << (from.Ordinal__I() & 63)
			var i int32 = fromIndex + 1; L1: for {
				if i < toIndex { t.F_elements.A[i] = -1; i = i + 1; continue L1 }
//line :34:1
				break L1
			}
			var tmp3 *LongArray = t.F_elements; tmp3.A[toIndex] = int64(uint64(18446744073709551615) >> ((63 - to.Ordinal__I()) & 63))
		}

	t.F_size = to.Ordinal__I() - from.Ordinal__I() + 1
}
func (t *JumboEnumSet) AddAll__V() {
	var i int32 = 0; L1: for {
		if i < int32(len(t.F_elements.A)) { t.F_elements.A[i] = -1; i = i + 1; continue L1 }
//line :42:1
		break L1
	}
	var i_1 int32 = int32(len(t.F_elements.A)) - 1; var tmp1 *LongArray = t.F_elements; var tmp2 int64 = t.F_elements.A[i_1]
	tmp1.A[i_1] = int64(uint64(tmp2) >> (-int32(len(t.F_universe.A)) & 63))



	t.F_size = int32(len(t.F_universe.A))
}
func (t *JumboEnumSet) Complement__V() {
	var i int32 = 0; L1: for {
		if i < int32(len(t.F_elements.A)) {
			var tmp1 *LongArray = t.F_elements; tmp1.A[i] = ^t.F_elements.A[i]
			i = i + 1; continue L1 }
//line :52:1
		break L1
	}


	var i_2 int32 = int32(len(t.F_elements.A)) - 1; var tmp2 *LongArray = t.F_elements; var tmp3 int64 = t.F_elements.A[i_2]
	tmp2.A[i_2] = tmp3 & int64(uint64(18446744073709551615)>>(-int32(len(t.F_universe.A))&63))




	t.F_size = int32(len(t.F_universe.A)) - t.F_size
}
func (t *JumboEnumSet) Iterator__Iterator() Iterator {
	return JumboEnumSet_EnumSetIterator_New_JumboEnumSet(t)
}












func JumboEnumSet_EnumSetIterator_New_JumboEnumSet(p0 *JumboEnumSet) *JumboEnumSet_EnumSetIterator { t := &JumboEnumSet_EnumSetIterator{}; t.Ctor_JumboEnumSet(p0); return t }
//line :79:1
func (t *JumboEnumSet_EnumSetIterator) Ctor_JumboEnumSet(this_0 *JumboEnumSet) { NN(this_0); t.F_this_0 = this_0; t.F_unseenIndex = 0; t.F_lastReturned = 0; t.F_lastReturnedIndex = 0; t.F_unseen = this_0.F_elements.A[0] }

func (t *JumboEnumSet_EnumSetIterator) HasNext__Z() bool {
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = t.F_unseen == 0; if tmp2 { var tmp3 int32 = t.F_unseenIndex; tmp2 = tmp3 < int32(len(t.F_this_0.F_elements.A))-1 }; tmp1 = tmp2; if tmp1 {
	var tmp4 *LongArray = t.F_this_0.F_elements; var tmp5 int32; var tmp6 int32 = t.F_unseenIndex + 1; t.F_unseenIndex = tmp6; tmp5 = tmp6; t.F_unseen = tmp4.A[tmp5]
//line :82:1
	continue L1 }; break L1
}
	return !(t.F_unseen == 0)
}
func (t *JumboEnumSet_EnumSetIterator) Next__Enum() Enum_I {
	if t.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	t.F_lastReturned = t.F_unseen & -t.F_unseen
	t.F_lastReturnedIndex = t.F_unseenIndex
	t.F_unseen = t.F_unseen - t.F_lastReturned
	var tmp1 *RefArray = t.F_this_0.F_universe; var tmp2 int32 = t.F_lastReturnedIndex << 6; return As[Enum_I](tmp1.A[tmp2+Long_NumberOfTrailingZeros_J__I(t.F_lastReturned)])
}


func (t *JumboEnumSet_EnumSetIterator) Remove__V() {
	if t.F_lastReturned == 0 { panic(Thrown(IllegalStateException_New())) }
	var oldElements int64 = t.F_this_0.F_elements.A[t.F_lastReturnedIndex]; var tmp1 *LongArray = t.F_this_0.F_elements; var tmp2 int32 = t.F_lastReturnedIndex
	tmp1.A[tmp2] = t.F_this_0.F_elements.A[t.F_lastReturnedIndex] & ^t.F_lastReturned


	if oldElements == t.F_this_0.F_elements.A[t.F_lastReturnedIndex] { } else {
		t.F_this_0.F_size = t.F_this_0.F_size - 1 }
	t.F_lastReturned = 0
}
func (t *JumboEnumSet) Size__I() int32 { return t.F_size }

func (t *JumboEnumSet) IsEmpty__Z() bool { return t.F_size == 0 }

func (t *JumboEnumSet) Contains_O__Z(e any) bool {
	if e == nil { return false } else {

		var eClass *Class = GetClass(e); var tmp1 bool; var tmp2 bool
		tmp2 = !(eClass == t.F_elementType); if tmp2 {
			tmp2 = !(NN(eClass).GetSuperclass__Class() == t.F_elementType) }
//line :113:1
		tmp1 = tmp2; if tmp1 { return false } else {


			var eOrdinal int32 = Enum_Cast(e).Ordinal__I()
			return !(t.F_elements.A[int32(uint32(eOrdinal)>>6)]&(1<<(eOrdinal&63)) == 0)
		}
	}
}
func (t *JumboEnumSet) Add_Enum__Z(e Enum_I) bool {
	t.TypeCheck_Enum__V(e)
	var eOrdinal int32 = e.Ordinal__I(); var eWordNum int32 = int32(uint32(eOrdinal) >> 6); var oldElements int64 = t.F_elements.A[eWordNum]; var tmp1 *LongArray = t.F_elements


	tmp1.A[eWordNum] = t.F_elements.A[eWordNum] | 1<<(eOrdinal&63)
	var result bool = !(t.F_elements.A[eWordNum] == oldElements)
	if result { t.F_size = t.F_size + 1 }
//line :127:1
	return result
}


func (t *JumboEnumSet) Remove_O__Z(e any) bool {
	if e == nil { return false } else {

		var eClass *Class = GetClass(e); var tmp1 bool; var tmp2 bool
		tmp2 = !(eClass == t.F_elementType); if tmp2 {
			tmp2 = !(NN(eClass).GetSuperclass__Class() == t.F_elementType) }
//line :135:1
		tmp1 = tmp2; if tmp1 { return false } else {


			var eOrdinal int32 = Enum_Cast(e).Ordinal__I(); var eWordNum int32 = int32(uint32(eOrdinal) >> 6); var oldElements int64 = t.F_elements.A[eWordNum]; var tmp3 *LongArray = t.F_elements


			tmp3.A[eWordNum] = t.F_elements.A[eWordNum] & ^(1 << (eOrdinal & 63))


			var result bool = !(t.F_elements.A[eWordNum] == oldElements)
			if result { t.F_size = t.F_size - 1 }
//line :144:1
			return result
		}
	}
}
func (t *JumboEnumSet) ContainsAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if JumboEnumSet_InstanceOf(tmp1) { var es *JumboEnumSet = JumboEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			return NN(es).IsEmpty__Z() } else {

				var i int32 = 0; L1: for {
					if i < int32(len(t.F_elements.A)) {
						var tmp2 int64 = es.F_elements.A[i]; if !(tmp2 & ^t.F_elements.A[i] == 0) {
							return false } else {
								i = i + 1; continue L1 } }
//line :153:1
					break L1 }
//line :152:1
				return true
			}


	} else {



		return t.EnumSet.Impl_ContainsAll_Collection__Z(t, c)
	} }
func (t *JumboEnumSet) AddAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if JumboEnumSet_InstanceOf(tmp1) { var es *JumboEnumSet = JumboEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			if NN(es).IsEmpty__Z() { return false } else {

				panic(Thrown(ClassCastException_New_String(Concat(StrOfObj(es.F_elementType.Ref()), Lit_2668, StrOfObj(t.F_elementType.Ref()))))) } } else {


					var i int32 = 0; L1: for {
						if i < int32(len(t.F_elements.A)) {
							var tmp2 *LongArray = t.F_elements; var tmp3 int64 = t.F_elements.A[i]; tmp2.A[i] = tmp3 | es.F_elements.A[i]
							i = i + 1; continue L1 }
//line :170:1
						break L1
					}


					return t.RecalculateSize__Z() } } else {
						return t.EnumSet.Impl_AddAll_Collection__Z(t, c)
					} }
func (t *JumboEnumSet) RemoveAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if JumboEnumSet_InstanceOf(tmp1) { var es *JumboEnumSet = JumboEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) { return false } else {


			var i int32 = 0; L1: for {
				if i < int32(len(t.F_elements.A)) {
					var tmp2 *LongArray = t.F_elements; var tmp3 int64 = t.F_elements.A[i]; tmp2.A[i] = tmp3 & ^es.F_elements.A[i]
					i = i + 1; continue L1 }
//line :182:1
				break L1
			}


			return t.RecalculateSize__Z() } } else {
				return t.EnumSet.Impl_RemoveAll_Collection__Z(t, c)
			} }
func (t *JumboEnumSet) RetainAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if JumboEnumSet_InstanceOf(tmp1) { var es *JumboEnumSet = JumboEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			var changed bool = !(t.F_size == 0); t.Clear__V(); return changed } else {

				var i int32 = 0; L1: for {
					if i < int32(len(t.F_elements.A)) {
						var tmp2 *LongArray = t.F_elements; var tmp3 int64 = t.F_elements.A[i]; tmp2.A[i] = tmp3 & es.F_elements.A[i]
						i = i + 1; continue L1 }
//line :194:1
					break L1
				}


				return t.RecalculateSize__Z() } } else {
					return t.EnumSet.Impl_RetainAll_Collection__Z(t, c)
				} }
func (t *JumboEnumSet) Clear__V() {
	Arrays_Fill_J1_J__V(t.F_elements, 0)
	t.F_size = 0
}
func (t *JumboEnumSet) Equals_O__Z(o any) bool {
	var tmp1 any = o; if JumboEnumSet_InstanceOf(tmp1) { var es *JumboEnumSet = JumboEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			var tmp2 bool; tmp2 = t.F_size == 0; if tmp2 { tmp2 = es.F_size == 0 }; return tmp2 } else {
				return Arrays_Equals_J1_J1__Z(es.F_elements, t.F_elements) } } else {
					return t.EnumSet.Impl_Equals_O__Z(t, o)
				} }
func (t *JumboEnumSet) RecalculateSize__Z() bool {
	var oldSize int32 = t.F_size
	t.F_size = 0
	var arr_101932 *LongArray = t.F_elements; var len_101933 int32 = int32(len(arr_101932.A)); var i_101934 int32 = 0; for ; i_101934 < len_101933; i_101934++ { var elt int64 = arr_101932.A[i_101934]; var tmp1 int32 = t.F_size; t.F_size = tmp1 + Long_BitCount_J__I(elt) }
	return !(t.F_size == oldSize)
}
func (t *JumboEnumSet) Clone__EnumSet() EnumSet_I {
	var result *JumboEnumSet = JumboEnumSet_Cast(t.EnumSet.Impl_Clone__EnumSet(t))
	result.F_elements = NN(result.F_elements).Copy()
//line :219:1
	return Up_JumboEnumSet_EnumSet(result)
}



type JumboEnumSet struct{ EnumSet; F_elements *LongArray; F_size int32 }

const JumboEnumSet_serialVersionUID int64 = 334349849919042784

func (t *JumboEnumSet) Clone__O() any { return t.Clone__EnumSet() }

func (t *JumboEnumSet) Add_O__Z(p0 any) bool { return t.Add_Enum__Z(Enum_Cast(p0)) }

func (t *JumboEnumSet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *JumboEnumSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *JumboEnumSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *JumboEnumSet) TypeCheck_Enum__V(p0 Enum_I) { t.Impl_TypeCheck_Enum__V(t, p0) }

func (t *JumboEnumSet) WriteReplace__O() any { return t.Impl_WriteReplace__O(t) }

func (t *JumboEnumSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *JumboEnumSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *JumboEnumSet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *JumboEnumSet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *JumboEnumSet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *JumboEnumSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *JumboEnumSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *JumboEnumSet) Ref() any { if t == nil { return nil }; return t }

func (t *JumboEnumSet) GetClass__Class() *Class { return JumboEnumSet_class }

func (t *JumboEnumSet) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func JumboEnumSet_InstanceOf(x any) bool { _, ok := x.(*JumboEnumSet); return ok }

func JumboEnumSet_Cast(x any) *JumboEnumSet { if x == nil { return nil }; v, ok := x.(*JumboEnumSet); if !ok { panic(ClassCast(x, JumboEnumSet_class)) }; return v }



type JumboEnumSet_EnumSetIterator struct{ Object; F_unseen int64; F_unseenIndex int32; F_lastReturned int64; F_lastReturnedIndex int32; F_this_0 *JumboEnumSet }

func (t *JumboEnumSet_EnumSetIterator) Is_Iterator() {}

func (t *JumboEnumSet_EnumSetIterator) Next__O() any { return t.Next__Enum() }

func (t *JumboEnumSet_EnumSetIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *JumboEnumSet_EnumSetIterator) Ref() any { if t == nil { return nil }; return t }

func (t *JumboEnumSet_EnumSetIterator) GetClass__Class() *Class { return JumboEnumSet_EnumSetIterator_class }

func (t *JumboEnumSet_EnumSetIterator) ToString__String() *String { return Object_toString(t) }

func (t *JumboEnumSet_EnumSetIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *JumboEnumSet_EnumSetIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func JumboEnumSet_EnumSetIterator_InstanceOf(x any) bool { _, ok := x.(*JumboEnumSet_EnumSetIterator); return ok }

func JumboEnumSet_EnumSetIterator_Cast(x any) *JumboEnumSet_EnumSetIterator { if x == nil { return nil }; v, ok := x.(*JumboEnumSet_EnumSetIterator); if !ok { panic(ClassCast(x, JumboEnumSet_EnumSetIterator_class)) }; return v }
