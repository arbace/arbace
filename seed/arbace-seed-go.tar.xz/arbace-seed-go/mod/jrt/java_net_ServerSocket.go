//line java_net_ServerSocket.ae:1
package jrt

import "sync/atomic"







func (t *ServerSocket) ImplAccept_Socket__V(s Socket_I) {
	var si SocketImpl_I = s.Impl__SocketImpl()
	if si == nil {

		si = t.ImplAccept__SocketImpl(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
			s.SetConnectedImpl_SocketImpl__V(si); return nil }(); if tmp1 != nil { if SocketException_InstanceOf(tmp1) { var e SocketException_I = SocketException_Cast(tmp1); si.CloseQuietly__V(); panic(Thrown(e)) } else { panic(tmp1) } } } else {

				t.EnsureCompatible_SocketImpl__V(si)
				if PlatformSocketImpl_InstanceOf(t.F_impl) {
					var psi SocketImpl_I = t.PlatformImplAccept__SocketImpl()
					si.CopyOptionsTo_SocketImpl__V(psi); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

						s.SetConnectedImpl_SocketImpl__V(psi); return nil }()
//line :22:1
					if tmp2 != nil { if SocketException_InstanceOf(tmp2) { var e_2 SocketException_I = SocketException_Cast(tmp2)

						psi.CloseQuietly__V(); panic(Thrown(e_2)) } else {
//line :22:1
							panic(tmp2) } } } else {



								s.SetImpl_SocketImpl__V(nil); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
									t.CustomImplAccept_SocketImpl__V(si); return nil }(); s.SetImpl_SocketImpl__V(si); if tmp3 != nil { panic(tmp3) }
								s.SetConnected__V() } } }
//line :23:1
func ServerSocket_New_SocketImpl(p0 SocketImpl_I) *ServerSocket { ServerSocket_Init(); t := &ServerSocket{}; t.Ctor_SocketImpl(p0); return t }
//line :23:1
func (t *ServerSocket) Ctor_SocketImpl(impl SocketImpl_I) { panic(A2g_NotTranslated("java.net.ServerSocket.<init>(Ljava/net/SocketImpl;)V")) }


func ServerSocket_New() *ServerSocket { ServerSocket_Init(); t := &ServerSocket{}; t.Ctor(); return t }
//line :26:1
func (t *ServerSocket) Ctor() { t.F_socketLock = Object_New()
	t.F_impl = ServerSocket_CreateImpl__SocketImpl()
}
func ServerSocket_New_I(p0 int32) *ServerSocket { ServerSocket_Init(); t := &ServerSocket{}; t.Ctor_I(p0); return t }
//line :29:1
func (t *ServerSocket) Ctor_I(port int32) { t.Ctor_I_I_InetAddress(port, 50, nil) }


func ServerSocket_New_I_I(p0, p1 int32) *ServerSocket { ServerSocket_Init(); t := &ServerSocket{}; t.Ctor_I_I(p0, p1); return t }
//line :32:1
func (t *ServerSocket) Ctor_I_I(port, backlog int32) { t.Ctor_I_I_InetAddress(port, backlog, nil) }


func ServerSocket_New_I_I_InetAddress(p0, p1 int32, p2 InetAddress_I) *ServerSocket { ServerSocket_Init(); t := &ServerSocket{}; t.Ctor_I_I_InetAddress(p0, p1, p2); return t }
//line :35:1
func (t *ServerSocket) Ctor_I_I_InetAddress(port, backlog int32, bindAddr InetAddress_I) { t.F_socketLock = Object_New()

	var tmp1 bool; var tmp2 bool; tmp2 = port < 0; if !tmp2 { tmp2 = port > 65535 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1331, StrOfInt(port))))) }
	if backlog < 1 { backlog = 50 }
	t.F_impl = ServerSocket_CreateImpl__SocketImpl()
//line :37:1
	tmp3 := func() (exc Throwable_I) { defer Catch(&exc)




		t.Bind_SocketAddress_I__V(InetSocketAddress_New_InetAddress_I(bindAddr, port), backlog)
//line :37:1
		return nil
	}()


	if tmp3 != nil { if IOException_InstanceOf(tmp3) { var e IOException_I = IOException_Cast(tmp3)

		t.Close__V(); panic(Thrown(e)) } else {
//line :41:1
			panic(tmp3)
		}
	}
}
func ServerSocket_CreateImpl__SocketImpl() SocketImpl_I { ServerSocket_Init()
	var factory SocketImplFactory = ServerSocket_factory.Load()
	if !(factory == nil) { return factory.CreateSocketImpl__SocketImpl() } else { return SocketImpl_CreatePlatformSocketImpl_Z__SocketImpl(true)
	} }
func (t *ServerSocket) GetImpl__SocketImpl() SocketImpl_I {
	if t.F_created.Load() { } else {
		var tmp1 any = t.F_socketLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
			if t.F_created.Load() { } else {
				if t.F_closed.Load() { panic(Thrown(SocketException_New_String(Lit_1332))) }
//line :52:1
				tmp2 := func() (exc Throwable_I) { defer Catch(&exc)


					t.F_impl.Create_Z__V(true)
//line :52:1
					return nil
				}()
				if tmp2 != nil { if SocketException_InstanceOf(tmp2) { var e SocketException_I = SocketException_Cast(tmp2)

					panic(Thrown(e)) } else if /*line :54:1*/ IOException_InstanceOf(tmp2) { var e_2 IOException_I = IOException_Cast(tmp2)


						panic(Thrown(SocketException_New_String_Throwable(e_2.GetMessage__String(), e_2))) } else {
//line :54:1
							panic(tmp2)
						}
				}

				t.F_created.Store(true) } }() }
//line :49:1
	return t.F_impl
}










func (t *ServerSocket) Bind_SocketAddress__V(endpoint SocketAddress_I) {
	t.Bind_SocketAddress_I__V(endpoint, 50)
}
func (t *ServerSocket) Bind_SocketAddress_I__V(endpoint SocketAddress_I, backlog int32) {

	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if t.IsBound__Z() { panic(Thrown(SocketException_New_String(Lit_1333))) }
	if endpoint == nil { endpoint = InetSocketAddress_New_I(0) }
	var tmp1 SocketAddress_I = endpoint; if InetSocketAddress_InstanceOf(tmp1) { var epoint *InetSocketAddress = InetSocketAddress_Cast(tmp1)

		if NN(epoint).IsUnresolved__Z() { panic(Thrown(SocketException_New_String(Lit_1334))) }
		if backlog < 1 { backlog = 50 }
		var impl SocketImpl_I = t.GetImpl__SocketImpl()
		impl.Bind_InetAddress_I__V(NN(epoint).GetAddress__InetAddress(), NN(epoint).GetPort__I())
		impl.Listen_I__V(backlog)
		t.F_bound.Store(true) } else {
			panic(Thrown(IllegalArgumentException_New_String(Lit_1335)))
		} }
func (t *ServerSocket) GetInetAddress__InetAddress() InetAddress_I {
	if !t.IsBound__Z() { return nil } else { tmp1, tmp2, tmp3 := func() (ctl int32, rv InetAddress_I, exc Throwable_I) { defer Catch(&exc); return 2, t.GetImpl__SocketImpl().GetInetAddress__InetAddress(), nil; return 0, nil, nil }()
		if tmp3 != nil { if SocketException_InstanceOf(tmp3) { var e SocketException_I = SocketException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }}
//line :80:1
		return nil
	}
}

func (t *ServerSocket) GetLocalPort__I() int32 {
	if !t.IsBound__Z() { return -1 } else { tmp1, tmp2, tmp3 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc); return 2, t.GetImpl__SocketImpl().GetLocalPort__I(), nil; return 0, 0, nil }()

		if tmp3 != nil { if SocketException_InstanceOf(tmp3) { var e SocketException_I = SocketException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }}; return -1
	} }
func (t *ServerSocket) GetLocalSocketAddress__SocketAddress() SocketAddress_I {
	if !t.IsBound__Z() { return nil } else {
		return InetSocketAddress_New_InetAddress_I(t.GetInetAddress__InetAddress(), t.GetLocalPort__I())
	} }
func (t *ServerSocket) Accept__Socket() Socket_I {
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if t.IsBound__Z() { } else { panic(Thrown(SocketException_New_String(Lit_1336))) }
	var s Socket_I = Socket_New_SocketImpl(nil); t.ImplAccept_Socket__V(s); return s
}






















func (t *ServerSocket) ImplAccept__SocketImpl() SocketImpl_I {
	if PlatformSocketImpl_InstanceOf(t.F_impl) {
		return t.PlatformImplAccept__SocketImpl() } else {
			var factory SocketImplFactory = Socket_SocketImplFactory__SocketImplFactory()
			if factory == nil {
				panic(Thrown(IOException_New_String(Concat(Lit_1337, StrOfObj(t.F_impl.GetClass__Class().Ref()), Lit_1338))))
			}




			var si SocketImpl_I = factory.CreateSocketImpl__SocketImpl(); t.CustomImplAccept_SocketImpl__V(si); return si
		} }
func (t *ServerSocket) PlatformImplAccept__SocketImpl() SocketImpl_I {
	if !A2g_AssertionsDisabled && !PlatformSocketImpl_InstanceOf(t.F_impl) { panic(Thrown(AssertionError_New())) }
	var psi SocketImpl_I = SocketImpl_CreatePlatformSocketImpl_Z__SocketImpl(false); t.ImplAccept_SocketImpl__V(psi); return psi
}
func (t *ServerSocket) CustomImplAccept_SocketImpl__V(si SocketImpl_I) {
	var tmp1 bool; var tmp2 bool; tmp2 = !PlatformSocketImpl_InstanceOf(t.F_impl); if tmp2 {
		tmp2 = !PlatformSocketImpl_InstanceOf(si) }
//line :138:1
	tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New()))
	}
	si.Reset__V(); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

		si.Self_SocketImpl().F_fd = FileDescriptor_New()
		si.Self_SocketImpl().F_address = InetAddress_New()
		t.ImplAccept_SocketImpl__V(si); return nil }()
//line :141:1
	if tmp3 != nil { if Exception_InstanceOf(tmp3) { var e Exception_I = Exception_Cast(tmp3)



		si.Reset__V(); panic(Thrown(e)) } else {
//line :141:1
			panic(tmp3)
		}
	}
}


func (t *ServerSocket) ImplAccept_SocketImpl__V(si SocketImpl_I) {
	if !A2g_AssertionsDisabled && !!A2g_Discard(si) { panic(Thrown(AssertionError_New())) }; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_impl.Accept_SocketImpl__V(si); return nil }()
//line :149:1
	if tmp1 != nil { if SocketTimeoutException_InstanceOf(tmp1) { var e *SocketTimeoutException = SocketTimeoutException_Cast(tmp1)

		panic(Thrown(Up_SocketTimeoutException_Throwable(e))) } else if /*line :149:1*/ InterruptedIOException_InstanceOf(tmp1) { var e_2 InterruptedIOException_I = InterruptedIOException_Cast(tmp1); var thread Thread_I = Thread_CurrentThread__Thread(); var tmp2 bool; var tmp3 bool




			tmp3 = thread.IsVirtual__Z(); if tmp3 { tmp3 = thread.IsInterrupted__Z() }; tmp2 = tmp3; if tmp2 {
				t.Close__V()
				panic(Thrown(SocketException_New_String(Lit_1339))) }
			panic(Thrown(e_2)) } else {
//line :149:1
				panic(tmp1)
			}
	}
}






func (t *ServerSocket) EnsureCompatible_SocketImpl__V(si SocketImpl_I) {
	if PlatformSocketImpl_InstanceOf(t.F_impl) == PlatformSocketImpl_InstanceOf(si) { } else {
		panic(Thrown(IOException_New_String(Concat(Lit_1337, StrOfObj(t.F_impl.GetClass__Class().Ref()), Lit_1340, StrOfObj(si.GetClass__Class().Ref())))))
	}
}


func (t *ServerSocket) Close__V() {
	var tmp1 any = t.F_socketLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); if t.F_closed.Load() { } else { t.F_closed.Store(true); if t.F_created.Load() { t.F_impl.Close__V() } } }()
}


func (t *ServerSocket) IsBound__Z() bool { return t.F_bound.Load() }

func (t *ServerSocket) IsClosed__Z() bool { return t.F_closed.Load() }

func (t *ServerSocket) SetSoTimeout_I__V(timeout int32) {
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if timeout < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1341))) }
	t.GetImpl__SocketImpl().SetOption_I_O__V(4102, Integer_ValueOf_I__Integer(timeout))
}
func (t *ServerSocket) GetSoTimeout__I() int32 {
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	var o any = t.GetImpl__SocketImpl().GetOption_I__O(4102); var tmp1 any = o
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1); return NN(i).IntValue__I() } else { return 0
	} }
func (t *ServerSocket) SetReuseAddress_Z__V(on bool) {
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.GetImpl__SocketImpl().SetOption_I_O__V(4, Boolean_ValueOf_Z__Boolean(on).Ref())
}
func (t *ServerSocket) GetReuseAddress__Z() bool {
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	return NN(Boolean_Cast(t.GetImpl__SocketImpl().GetOption_I__O(4))).BooleanValue__Z()
}
func (t *ServerSocket) ToString__String() *String {
	if !t.IsBound__Z() { return Lit_1342 } else {

		var in InetAddress_I = t.F_impl.GetInetAddress__InetAddress()
		return Concat(Lit_1343, StrOfObj(in), Lit_1344, StrOfInt(t.F_impl.GetLocalPort__I()), Lit_1189)
	}
}

func ServerSocket_SetSocketFactory_SocketImplFactory__V(fac SocketImplFactory) { ServerSocket_Init(); MonitorEnter(ServerSocket_class); defer MonitorExit(ServerSocket_class)
	if !(ServerSocket_factory.Load() == nil) { panic(Thrown(SocketException_New_String(Lit_1345))) }
	ServerSocket_factory.Store(fac)
}
func (t *ServerSocket) SetReceiveBufferSize_I__V(size int32) {
	if size <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1346))) }
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.GetImpl__SocketImpl().SetOption_I_O__V(4098, Integer_ValueOf_I__Integer(size))
}
func (t *ServerSocket) GetReceiveBufferSize__I() int32 {
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	var result int32 = 0; var o any = t.GetImpl__SocketImpl().GetOption_I__O(4098)

	if Integer_InstanceOf(o) { result = NN(Integer_Cast(o)).IntValue__I() }
//line :212:1
	return result
}



func (t *ServerSocket) SetPerformancePreferences_I_I_I__V(p0, p1, p2 int32) {}




func (t *ServerSocket) SetOption_SocketOption_O__ServerSocket(name SocketOption, value any) *ServerSocket {


	Objects_RequireNonNull_O__O(name)
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.GetImpl__SocketImpl().SetOption_SocketOption_O__V(name, value)
//line :222:1
	return t
}






func (t *ServerSocket) GetOption_SocketOption__O(name SocketOption) any {

	Objects_RequireNonNull_O__O(name)
	if t.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	return t.GetImpl__SocketImpl().GetOption_SocketOption__O(name)
}


func (t *ServerSocket) SupportedOptions__Set() Set {
	var so Set = t.F_options.Load()
	if !(so == nil) { return so } else { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)



		{ var impl SocketImpl_I = t.GetImpl__SocketImpl()
			t.F_options.Store(Collections_UnmodifiableSet_Set__Set(impl.SupportedOptions__Set())) }; return nil }()
//line :243:1
		if tmp1 != nil { if IOException_InstanceOf(tmp1) { var e IOException_I = IOException_Cast(tmp1); _ = e


			t.F_options.Store(Collections_EmptySet__Set()) } else {
//line :243:1
				panic(tmp1) } }
//line :242:1
		return t.F_options.Load()
	}
}




type ServerSocket struct{ Object; F_impl SocketImpl_I; F_created, F_bound, F_closed atomic.Bool; F_socketLock any; F_options Volatile[Set] }

func (t *ServerSocket) Is_Closeable() {}

func (t *ServerSocket) Is_AutoCloseable() {}

var ServerSocket_factory Volatile[SocketImplFactory]

var ServerSocket_init ClassInit

func ServerSocket_Init() { if !ServerSocket_init.Done() { ServerSocket_init.Run(ServerSocket_clinit) } }

func ServerSocket_clinit() {}

func (t *ServerSocket) Ref() any { if t == nil { return nil }; return t }

func (t *ServerSocket) GetClass__Class() *Class { return ServerSocket_class }

func (t *ServerSocket) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ServerSocket) CloneShallow() any { panic(CloneNotSupported(t)) }

func ServerSocket_InstanceOf(x any) bool { _, ok := x.(*ServerSocket); return ok }

func ServerSocket_Cast(x any) *ServerSocket { if x == nil { return nil }; v, ok := x.(*ServerSocket); if !ok { panic(ClassCast(x, ServerSocket_class)) }; return v }
