//line java_util_ReverseOrderSortedMapView.ae:1
package jrt












func ReverseOrderSortedMapView_New_SortedMap(p0 SortedMap) *ReverseOrderSortedMapView { t := &ReverseOrderSortedMapView{}; t.Ctor_SortedMap(p0); return t }
//line :14:1
func (t *ReverseOrderSortedMapView) Ctor_SortedMap(map_ SortedMap) { t.AbstractMap.Ctor(t)
	t.F_base = map_
	t.F_cmp = Collections_ReverseOrder_Comparator__Comparator(map_.Comparator__Comparator())
}
func ReverseOrderSortedMapView_Of_SortedMap__SortedMap(map_ SortedMap) SortedMap {
	var tmp1 SortedMap = map_; if ReverseOrderSortedMapView_InstanceOf(tmp1) { var rosmv *ReverseOrderSortedMapView = ReverseOrderSortedMapView_Cast(tmp1)
		return rosmv.F_base } else {
			return ReverseOrderSortedMapView_New_SortedMap(map_)
		} }
func (t *ReverseOrderSortedMapView) ToString__String() *String {
	return ReverseOrderSortedMapView_ToString_Map_Iterator__String(t, ReverseOrderSortedMapView_DescendingEntryIterator_SortedMap__Iterator(t.F_base))
}

func (t *ReverseOrderSortedMapView) Clear__V() { t.F_base.Clear__V() }

func (t *ReverseOrderSortedMapView) ContainsKey_O__Z(key any) bool {
	return t.F_base.ContainsKey_O__Z(key)
}
func (t *ReverseOrderSortedMapView) ContainsValue_O__Z(value any) bool {
	return t.F_base.ContainsValue_O__Z(value)
}
func (t *ReverseOrderSortedMapView) Get_O__O(key any) any { return t.F_base.Get_O__O(key) }

func (t *ReverseOrderSortedMapView) IsEmpty__Z() bool { return t.F_base.IsEmpty__Z() }

func (t *ReverseOrderSortedMapView) Put_O_O__O(key, value any) any { return t.F_base.Put_O_O__O(key, value) }

func (t *ReverseOrderSortedMapView) PutAll_Map__V(m Map) {
	t.F_base.PutAll_Map__V(m)
}
func (t *ReverseOrderSortedMapView) Remove_O__O(key any) any { return t.F_base.Remove_O__O(key) }

func (t *ReverseOrderSortedMapView) Size__I() int32 { return t.F_base.Size__I() }

func (t *ReverseOrderSortedMapView) KeySet__Set() Set {
	return ReverseOrderSortedMapView_1_New_ReverseOrderSortedMapView(t) }
func (t *ReverseOrderSortedMapView_1) Iterator__Iterator() Iterator {
	return ReverseOrderSortedMapView_DescendingKeyIterator_SortedMap__Iterator(t.F_this_0.F_base)
}
func (t *ReverseOrderSortedMapView_1) Size__I() int32 { return t.F_this_0.F_base.Size__I() }

func (t *ReverseOrderSortedMapView_1) Clear__V() { t.F_this_0.F_base.KeySet__Set().Clear__V() }

func (t *ReverseOrderSortedMapView_1) Contains_O__Z(o any) bool {
	return t.F_this_0.F_base.KeySet__Set().Contains_O__Z(o)
}
func (t *ReverseOrderSortedMapView_1) Remove_O__Z(o any) bool { return t.F_this_0.F_base.KeySet__Set().Remove_O__Z(o) }

func (t *ReverseOrderSortedMapView) Values__Collection() Collection {
	return ReverseOrderSortedMapView_2_New_ReverseOrderSortedMapView(t) }
func (t *ReverseOrderSortedMapView_2) Iterator__Iterator() Iterator {
	return ReverseOrderSortedMapView_DescendingValueIterator_SortedMap__Iterator(t.F_this_0.F_base)
}
func (t *ReverseOrderSortedMapView_2) Size__I() int32 { return t.F_this_0.F_base.Size__I() }

func (t *ReverseOrderSortedMapView_2) Clear__V() { t.F_this_0.F_base.Values__Collection().Clear__V() }

func (t *ReverseOrderSortedMapView_2) Contains_O__Z(o any) bool {
	return t.F_this_0.F_base.Values__Collection().Contains_O__Z(o)
}
func (t *ReverseOrderSortedMapView_2) Remove_O__Z(o any) bool { return t.F_this_0.F_base.Values__Collection().Remove_O__Z(o) }

func (t *ReverseOrderSortedMapView) EntrySet__Set() Set {
	return ReverseOrderSortedMapView_3_New_ReverseOrderSortedMapView(t) }
func (t *ReverseOrderSortedMapView_3) Iterator__Iterator() Iterator {
	return ReverseOrderSortedMapView_DescendingEntryIterator_SortedMap__Iterator(t.F_this_0.F_base)
}
func (t *ReverseOrderSortedMapView_3) Size__I() int32 { return t.F_this_0.F_base.Size__I() }

func (t *ReverseOrderSortedMapView_3) Clear__V() { t.F_this_0.F_base.EntrySet__Set().Clear__V() }

func (t *ReverseOrderSortedMapView_3) Contains_O__Z(o any) bool {
	return t.F_this_0.F_base.EntrySet__Set().Contains_O__Z(o)
}
func (t *ReverseOrderSortedMapView_3) Remove_O__Z(o any) bool { return t.F_this_0.F_base.EntrySet__Set().Remove_O__Z(o) }

func (t *ReverseOrderSortedMapView) Reversed__SortedMap() SortedMap { return t.F_base }

func (t *ReverseOrderSortedMapView) FirstKey__O() any { return t.F_base.LastKey__O() }

func (t *ReverseOrderSortedMapView) LastKey__O() any { return t.F_base.FirstKey__O() }

func (t *ReverseOrderSortedMapView) FirstEntry__Map_Entry() Map_Entry {
	return t.F_base.LastEntry__Map_Entry()
}
func (t *ReverseOrderSortedMapView) LastEntry__Map_Entry() Map_Entry {
	return t.F_base.FirstEntry__Map_Entry()
}
func (t *ReverseOrderSortedMapView) PollFirstEntry__Map_Entry() Map_Entry {
	return t.F_base.PollLastEntry__Map_Entry()
}
func (t *ReverseOrderSortedMapView) PollLastEntry__Map_Entry() Map_Entry {
	return t.F_base.PollFirstEntry__Map_Entry()
}
func (t *ReverseOrderSortedMapView) PutFirst_O_O__O(k, v any) any { return t.F_base.PutLast_O_O__O(k, v) }

func (t *ReverseOrderSortedMapView) PutLast_O_O__O(k, v any) any { return t.F_base.PutFirst_O_O__O(k, v) }

func (t *ReverseOrderSortedMapView) Comparator__Comparator() Comparator { return t.F_cmp }

func (t *ReverseOrderSortedMapView) SubMap_O_O__SortedMap(fromKey, toKey any) SortedMap {
	if t.F_cmp.Compare_O_O__I(fromKey, toKey) <= 0 {
		return ReverseOrderSortedMapView_Submap_New_ReverseOrderSortedMapView_O_O(t, fromKey, toKey) } else {
			panic(Thrown(IllegalArgumentException_New()))
		} }
func (t *ReverseOrderSortedMapView) HeadMap_O__SortedMap(toKey any) SortedMap {
	return ReverseOrderSortedMapView_Submap_New_ReverseOrderSortedMapView_O_O(t, nil, toKey)
}
func (t *ReverseOrderSortedMapView) TailMap_O__SortedMap(fromKey any) SortedMap {
	return ReverseOrderSortedMapView_Submap_New_ReverseOrderSortedMapView_O_O(t, fromKey, nil)
}
func ReverseOrderSortedMapView_DescendingKeyIterator_SortedMap__Iterator(map_ SortedMap) Iterator {
	return ReverseOrderSortedMapView_4_New_SortedMap(map_)
}





func (t *ReverseOrderSortedMapView_4) HasNext__Z() bool { return !t.F_view.IsEmpty__Z() }

func (t *ReverseOrderSortedMapView_4) Next__O() any {
	if t.F_view.IsEmpty__Z() { panic(Thrown(NoSuchElementException_New())) }
	var k any; var tmp1 any = t.F_view.LastKey__O(); t.F_prev = tmp1; k = tmp1; t.F_view = t.F_root.HeadMap_O__SortedMap(k); return k
}
func (t *ReverseOrderSortedMapView_4) Remove__V() {
	if t.F_prev == nil { panic(Thrown(IllegalStateException_New())) } else { t.F_root.Remove_O__O(t.F_prev); t.F_prev = nil
	} }
func ReverseOrderSortedMapView_DescendingValueIterator_SortedMap__Iterator(map_ SortedMap) Iterator {
	return ReverseOrderSortedMapView_5_New_SortedMap(map_)
}

func (t *ReverseOrderSortedMapView_5) HasNext__Z() bool { return t.F_keyIterator.HasNext__Z() }

func (t *ReverseOrderSortedMapView_5) Next__O() any { return t.F_val_map.Get_O__O(t.F_keyIterator.Next__O()) }

func (t *ReverseOrderSortedMapView_5) Remove__V() { t.F_keyIterator.Remove__V() }

func ReverseOrderSortedMapView_DescendingEntryIterator_SortedMap__Iterator(map_ SortedMap) Iterator {
	return ReverseOrderSortedMapView_6_New_SortedMap(map_)
}

func (t *ReverseOrderSortedMapView_6) HasNext__Z() bool { return t.F_keyIterator.HasNext__Z() }

func (t *ReverseOrderSortedMapView_6) Next__Map_Entry() Map_Entry {
	var key any = t.F_keyIterator.Next__O(); return ReverseOrderSortedMapView_ViewEntry_New_Map_O_O(t.F_val_map, key, t.F_val_map.Get_O__O(key))
}
func (t *ReverseOrderSortedMapView_6) Remove__V() { t.F_keyIterator.Remove__V() }











func ReverseOrderSortedMapView_ViewEntry_New_Map_O_O(p0 Map, p1, p2 any) *ReverseOrderSortedMapView_ViewEntry { t := &ReverseOrderSortedMapView_ViewEntry{}; t.Ctor_Map_O_O(p0, p1, p2); return t }
//line :173:1
func (t *ReverseOrderSortedMapView_ViewEntry) Ctor_Map_O_O(map_ Map, key, value any) {
	t.F_map = map_
	t.F_key = key
	t.F_value = value
}
func (t *ReverseOrderSortedMapView_ViewEntry) GetKey__O() any { return t.F_key }

func (t *ReverseOrderSortedMapView_ViewEntry) GetValue__O() any { return t.F_value }

func (t *ReverseOrderSortedMapView_ViewEntry) SetValue_O__O(newValue any) any { return t.F_map.Put_O_O__O(t.F_key, newValue) }

func (t *ReverseOrderSortedMapView_ViewEntry) Equals_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var tmp2 any = t.F_key
		if Objects_Equals_O_O__Z(tmp2, e.GetKey__O()) { var tmp3 any = t.F_value; return Objects_Equals_O_O__Z(tmp3, e.GetValue__O()) } else { return false } } else {
//line :185:1
			return false
		}
}

func (t *ReverseOrderSortedMapView_ViewEntry) HashCode__I() int32 {
	return Objects_HashCode_O__I(t.F_key) ^ Objects_HashCode_O__I(t.F_value)
}
func (t *ReverseOrderSortedMapView_ViewEntry) ToString__String() *String { return Concat(StrOfObj(t.F_key), Lit_1171, StrOfObj(t.F_value)) }

func ReverseOrderSortedMapView_ToString_Map_Iterator__String(thisMap Map, i Iterator) *String {

	if !i.HasNext__Z() { return Lit_2597 } else {

		var sb *StringBuilder = StringBuilder_New()
		NN(sb).Append_C__StringBuilder(123)
	L1: for {
		var e Map_Entry = Map_Entry_Cast(i.Next__O()); var key any = e.GetKey__O(); var value any = e.GetValue__O(); var tmp1 any


		if any(key) == any(thisMap) { tmp1 = Lit_2598 } else { tmp1 = key }; NN(sb).Append_O__StringBuilder(tmp1)
		NN(sb).Append_C__StringBuilder(61)
		var tmp2 any; if any(value) == any(thisMap) { tmp2 = Lit_2598 } else { tmp2 = value }; NN(sb).Append_O__StringBuilder(tmp2)
		if i.HasNext__Z() { } else { return NN(NN(sb).Append_C__StringBuilder(125)).ToString__String() }
		NN(NN(sb).Append_C__StringBuilder(44)).Append_C__StringBuilder(32)
//line :200:1
		continue L1
	}
	}





	panic("a2g: unreachable")
}








func ReverseOrderSortedMapView_Submap_New_ReverseOrderSortedMapView_O_O(p0 *ReverseOrderSortedMapView, p1, p2 any) *ReverseOrderSortedMapView_Submap { t := &ReverseOrderSortedMapView_Submap{}; t.Ctor_ReverseOrderSortedMapView_O_O(p0, p1, p2); return t }
//line :218:1
func (t *ReverseOrderSortedMapView_Submap) Ctor_ReverseOrderSortedMapView_O_O(this_0 *ReverseOrderSortedMapView, head, tail any) { NN(this_0); t.F_this_0 = this_0; t.AbstractMap.Ctor(t)
	t.F_head = head
	t.F_tail = tail
}
func (t *ReverseOrderSortedMapView_Submap) AboveHead_O__Z(k any) bool {
	var tmp1 bool; tmp1 = t.F_head == nil; if !tmp1 { tmp1 = t.F_this_0.F_cmp.Compare_O_O__I(k, t.F_head) >= 0 }; return tmp1
}
func (t *ReverseOrderSortedMapView_Submap) BelowTail_O__Z(k any) bool {
	var tmp1 bool; tmp1 = t.F_tail == nil; if !tmp1 { tmp1 = t.F_this_0.F_cmp.Compare_O_O__I(k, t.F_tail) < 0 }; return tmp1
}
func (t *ReverseOrderSortedMapView_Submap) EntryIterator__Iterator() Iterator {
	return ReverseOrderSortedMapView_Submap_1_New_ReverseOrderSortedMapView_Submap(t)
}








func (t *ReverseOrderSortedMapView_Submap_1) HasNext__Z() bool {
	if t.F_dead { return false } else { if !(t.F_cache == nil) { return true } else {




	L1: for { if t.F_it.HasNext__Z() {
		var e Map_Entry = Map_Entry_Cast(t.F_it.Next__O())
		if !NN(t.F_this_1).AboveHead_O__Z(e.GetKey__O()) { } else {
			if NN(t.F_this_1).BelowTail_O__Z(e.GetKey__O()) { } else {
				t.F_dead = true
				return false }
			t.F_cache = e
			return true }
//line :245:1
		continue L1 }; break L1 }
//line :244:1
		return false
	}
	}
}







func (t *ReverseOrderSortedMapView_Submap_1) Next__Map_Entry() Map_Entry {
	if t.HasNext__Z() {
		var e Map_Entry = t.F_cache; t.F_cache = nil; t.F_prevKey = e.GetKey__O(); return e } else {
			panic(Thrown(NoSuchElementException_New()))
		} }
func (t *ReverseOrderSortedMapView_Submap_1) Remove__V() {
	if t.F_prevKey == nil { panic(Thrown(IllegalStateException_New())) } else { t.F_this_1.F_this_0.F_base.Remove_O__O(t.F_prevKey)
	} }
func (t *ReverseOrderSortedMapView_Submap) ToString__String() *String {
	return ReverseOrderSortedMapView_ToString_Map_Iterator__String(t, t.EntryIterator__Iterator())
}
func (t *ReverseOrderSortedMapView_Submap) EntrySet__Set() Set {
	return ReverseOrderSortedMapView_Submap_2_New_ReverseOrderSortedMapView_Submap(t) }
func (t *ReverseOrderSortedMapView_Submap_2) Iterator__Iterator() Iterator {
	return NN(t.F_this_1).EntryIterator__Iterator()
}
func (t *ReverseOrderSortedMapView_Submap_2) Size__I() int32 {
	var sz int32 = 0; var it Iterator = NN(t.F_this_1).EntryIterator__Iterator()
L1: for {
	if it.HasNext__Z() { it.Next__O(); sz = sz + 1; it = it; continue L1 }
//line :273:1
	break L1 }
//line :272:1
	return sz
}



func (t *ReverseOrderSortedMapView_Submap) Put_O_O__O(key, value any) any {
	var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(key); if tmp2 { tmp2 = t.BelowTail_O__Z(key) }; tmp1 = tmp2; if tmp1 {
		return t.F_this_0.F_base.Put_O_O__O(key, value) } else {
			panic(Thrown(IllegalArgumentException_New()))
		} }
func (t *ReverseOrderSortedMapView_Submap) Remove_O__O(o any) any {
	var key any = o; var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(key); if tmp2 { tmp2 = t.BelowTail_O__Z(key) }; tmp1 = tmp2; if tmp1 { return t.F_this_0.F_base.Remove_O__O(o) } else { return nil
	} }
func (t *ReverseOrderSortedMapView_Submap) Size__I() int32 { return t.EntrySet__Set().Size__I() }

func (t *ReverseOrderSortedMapView_Submap) Comparator__Comparator() Comparator { return t.F_this_0.F_cmp }

func (t *ReverseOrderSortedMapView_Submap) FirstKey__O() any {
	return Map_Entry_Cast(t.EntryIterator__Iterator().Next__O()).GetKey__O()
}
func (t *ReverseOrderSortedMapView_Submap) LastKey__O() any {
	var it Iterator = t.EntryIterator__Iterator()
	if it.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	var last Map_Entry = Map_Entry_Cast(it.Next__O())
L1: for { if it.HasNext__Z() { last = Map_Entry_Cast(it.Next__O()); continue L1 }; break L1 }
	return last.GetKey__O()
}
func (t *ReverseOrderSortedMapView_Submap) SubMap_O_O__SortedMap(from, to any) SortedMap {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = t.AboveHead_O__Z(from); if tmp5 { tmp5 = t.BelowTail_O__Z(from) }; tmp4 = tmp5; if tmp4 { tmp4 = t.AboveHead_O__Z(to) }; tmp3 = tmp4; if tmp3 {
		tmp3 = t.BelowTail_O__Z(to) }
//line :300:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = t.F_this_0.F_cmp.Compare_O_O__I(from, to) <= 0 }
//line :300:1
	tmp1 = tmp2; if tmp1 {


		return ReverseOrderSortedMapView_Submap_New_ReverseOrderSortedMapView_O_O(t.F_this_0, from, to) } else {
			panic(Thrown(IllegalArgumentException_New()))
		} }
func (t *ReverseOrderSortedMapView_Submap) HeadMap_O__SortedMap(to any) SortedMap {
	var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(to); if tmp2 { tmp2 = t.BelowTail_O__Z(to) }; tmp1 = tmp2; if tmp1 {
		return ReverseOrderSortedMapView_Submap_New_ReverseOrderSortedMapView_O_O(t.F_this_0, t.F_head, to) } else {
			panic(Thrown(IllegalArgumentException_New()))
		} }
func (t *ReverseOrderSortedMapView_Submap) TailMap_O__SortedMap(from any) SortedMap {
	var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(from); if tmp2 { tmp2 = t.BelowTail_O__Z(from) }; tmp1 = tmp2; if tmp1 {
		return ReverseOrderSortedMapView_Submap_New_ReverseOrderSortedMapView_O_O(t.F_this_0, from, t.F_tail) } else {
			panic(Thrown(IllegalArgumentException_New()))
		}
}

type ReverseOrderSortedMapView struct{ AbstractMap; F_base SortedMap; F_cmp Comparator }

func (t *ReverseOrderSortedMapView) Is_SortedMap() {}

func (t *ReverseOrderSortedMapView) Is_SequencedMap() {}

func (t *ReverseOrderSortedMapView) Reversed__SequencedMap() SequencedMap { return t.Reversed__SortedMap() }

func (t *ReverseOrderSortedMapView) Replace_O_O__O(p0, p1 any) any { return Map_Replace_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *ReverseOrderSortedMapView) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *ReverseOrderSortedMapView) Remove_O_O__Z(p0, p1 any) bool { return Map_Remove_O_O__Z(t, p0, p1) }

func (t *ReverseOrderSortedMapView) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *ReverseOrderSortedMapView) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView) ReplaceAll_BiFunction__V(p0 BiFunction) { Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *ReverseOrderSortedMapView) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *ReverseOrderSortedMapView) PutIfAbsent_O_O__O(p0, p1 any) any { return Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView) ForEach_BiConsumer__V(p0 BiConsumer) { Map_ForEach_BiConsumer__V(t, p0) }

func (t *ReverseOrderSortedMapView) Replace_O_O_O__Z(p0, p1, p2 any) bool { return Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *ReverseOrderSortedMapView) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ReverseOrderSortedMapView) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderSortedMapView) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView) GetClass__Class() *Class { return ReverseOrderSortedMapView_class }

func (t *ReverseOrderSortedMapView) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView); return ok }

func ReverseOrderSortedMapView_Cast(x any) *ReverseOrderSortedMapView { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_class)) }; return v }



type ReverseOrderSortedMapView_1 struct{ AbstractSet; F_this_0 *ReverseOrderSortedMapView }

func ReverseOrderSortedMapView_1_New_ReverseOrderSortedMapView(p0 *ReverseOrderSortedMapView) *ReverseOrderSortedMapView_1 { t := &ReverseOrderSortedMapView_1{}; t.Ctor_ReverseOrderSortedMapView(p0); return t }

func (t *ReverseOrderSortedMapView_1) Ctor_ReverseOrderSortedMapView(this_0 *ReverseOrderSortedMapView) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *ReverseOrderSortedMapView_1) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *ReverseOrderSortedMapView_1) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderSortedMapView_1) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ReverseOrderSortedMapView_1) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_1) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ReverseOrderSortedMapView_1) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_1) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ReverseOrderSortedMapView_1) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ReverseOrderSortedMapView_1) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_1) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderSortedMapView_1) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ReverseOrderSortedMapView_1) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_1) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_1) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_1) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_1) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderSortedMapView_1) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReverseOrderSortedMapView_1) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_1) GetClass__Class() *Class { return ReverseOrderSortedMapView_1_class }

func (t *ReverseOrderSortedMapView_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_1_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_1); return ok }

func ReverseOrderSortedMapView_1_Cast(x any) *ReverseOrderSortedMapView_1 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_1); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_1_class)) }; return v }



type ReverseOrderSortedMapView_2 struct{ AbstractCollection; F_this_0 *ReverseOrderSortedMapView }

func ReverseOrderSortedMapView_2_New_ReverseOrderSortedMapView(p0 *ReverseOrderSortedMapView) *ReverseOrderSortedMapView_2 { t := &ReverseOrderSortedMapView_2{}; t.Ctor_ReverseOrderSortedMapView(p0); return t }

func (t *ReverseOrderSortedMapView_2) Ctor_ReverseOrderSortedMapView(this_0 *ReverseOrderSortedMapView) { NN(this_0); t.F_this_0 = this_0; t.AbstractCollection.Ctor(t) }

func (t *ReverseOrderSortedMapView_2) Spliterator__Spliterator() Spliterator { return Collection_Spliterator__Spliterator(t) }

func (t *ReverseOrderSortedMapView_2) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderSortedMapView_2) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ReverseOrderSortedMapView_2) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_2) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ReverseOrderSortedMapView_2) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_2) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ReverseOrderSortedMapView_2) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ReverseOrderSortedMapView_2) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_2) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderSortedMapView_2) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ReverseOrderSortedMapView_2) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_2) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_2) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_2) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReverseOrderSortedMapView_2) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_2) GetClass__Class() *Class { return ReverseOrderSortedMapView_2_class }

func (t *ReverseOrderSortedMapView_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_2_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_2); return ok }

func ReverseOrderSortedMapView_2_Cast(x any) *ReverseOrderSortedMapView_2 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_2); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_2_class)) }; return v }



type ReverseOrderSortedMapView_3 struct{ AbstractSet; F_this_0 *ReverseOrderSortedMapView }

func ReverseOrderSortedMapView_3_New_ReverseOrderSortedMapView(p0 *ReverseOrderSortedMapView) *ReverseOrderSortedMapView_3 { t := &ReverseOrderSortedMapView_3{}; t.Ctor_ReverseOrderSortedMapView(p0); return t }

func (t *ReverseOrderSortedMapView_3) Ctor_ReverseOrderSortedMapView(this_0 *ReverseOrderSortedMapView) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *ReverseOrderSortedMapView_3) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *ReverseOrderSortedMapView_3) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderSortedMapView_3) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ReverseOrderSortedMapView_3) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_3) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ReverseOrderSortedMapView_3) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_3) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ReverseOrderSortedMapView_3) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ReverseOrderSortedMapView_3) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_3) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderSortedMapView_3) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ReverseOrderSortedMapView_3) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_3) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_3) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_3) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_3) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderSortedMapView_3) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReverseOrderSortedMapView_3) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_3) GetClass__Class() *Class { return ReverseOrderSortedMapView_3_class }

func (t *ReverseOrderSortedMapView_3) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_3_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_3); return ok }

func ReverseOrderSortedMapView_3_Cast(x any) *ReverseOrderSortedMapView_3 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_3); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_3_class)) }; return v }



type ReverseOrderSortedMapView_4 struct{ Object; F_root, F_view SortedMap; F_prev any; F_val_map SortedMap }

func (t *ReverseOrderSortedMapView_4) Is_Iterator() {}

func ReverseOrderSortedMapView_4_New_SortedMap(p0 SortedMap) *ReverseOrderSortedMapView_4 { t := &ReverseOrderSortedMapView_4{}; t.Ctor_SortedMap(p0); return t }

func (t *ReverseOrderSortedMapView_4) Ctor_SortedMap(val_map SortedMap) { t.F_val_map = val_map; t.F_root = t.F_val_map; t.F_view = t.F_val_map; t.F_prev = nil }

func (t *ReverseOrderSortedMapView_4) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_4) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_4) GetClass__Class() *Class { return ReverseOrderSortedMapView_4_class }

func (t *ReverseOrderSortedMapView_4) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderSortedMapView_4) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_4) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_4_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_4); return ok }

func ReverseOrderSortedMapView_4_Cast(x any) *ReverseOrderSortedMapView_4 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_4); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_4_class)) }; return v }



type ReverseOrderSortedMapView_5 struct{ Object; F_keyIterator Iterator; F_val_map SortedMap }

func (t *ReverseOrderSortedMapView_5) Is_Iterator() {}

func ReverseOrderSortedMapView_5_New_SortedMap(p0 SortedMap) *ReverseOrderSortedMapView_5 { t := &ReverseOrderSortedMapView_5{}; t.Ctor_SortedMap(p0); return t }

func (t *ReverseOrderSortedMapView_5) Ctor_SortedMap(val_map SortedMap) { t.F_val_map = val_map; t.F_keyIterator = ReverseOrderSortedMapView_DescendingKeyIterator_SortedMap__Iterator(t.F_val_map) }

func (t *ReverseOrderSortedMapView_5) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_5) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_5) GetClass__Class() *Class { return ReverseOrderSortedMapView_5_class }

func (t *ReverseOrderSortedMapView_5) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderSortedMapView_5) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_5) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_5_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_5); return ok }

func ReverseOrderSortedMapView_5_Cast(x any) *ReverseOrderSortedMapView_5 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_5); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_5_class)) }; return v }



type ReverseOrderSortedMapView_6 struct{ Object; F_keyIterator Iterator; F_val_map SortedMap }

func (t *ReverseOrderSortedMapView_6) Is_Iterator() {}

func ReverseOrderSortedMapView_6_New_SortedMap(p0 SortedMap) *ReverseOrderSortedMapView_6 { t := &ReverseOrderSortedMapView_6{}; t.Ctor_SortedMap(p0); return t }

func (t *ReverseOrderSortedMapView_6) Ctor_SortedMap(val_map SortedMap) { t.F_val_map = val_map; t.F_keyIterator = ReverseOrderSortedMapView_DescendingKeyIterator_SortedMap__Iterator(t.F_val_map) }

func (t *ReverseOrderSortedMapView_6) Next__O() any { return t.Next__Map_Entry() }

func (t *ReverseOrderSortedMapView_6) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_6) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_6) GetClass__Class() *Class { return ReverseOrderSortedMapView_6_class }

func (t *ReverseOrderSortedMapView_6) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderSortedMapView_6) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_6) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_6_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_6); return ok }

func ReverseOrderSortedMapView_6_Cast(x any) *ReverseOrderSortedMapView_6 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_6); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_6_class)) }; return v }



type ReverseOrderSortedMapView_Submap struct{ AbstractMap; F_head, F_tail any; F_this_0 *ReverseOrderSortedMapView }

func (t *ReverseOrderSortedMapView_Submap) Is_SortedMap() {}

func (t *ReverseOrderSortedMapView_Submap) Is_SequencedMap() {}

func (t *ReverseOrderSortedMapView_Submap) Replace_O_O__O(p0, p1 any) any { return Map_Replace_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *ReverseOrderSortedMapView_Submap) Clear__V() { t.Impl_Clear__V(t) }

func (t *ReverseOrderSortedMapView_Submap) PollFirstEntry__Map_Entry() Map_Entry { return SequencedMap_PollFirstEntry__Map_Entry(t) }

func (t *ReverseOrderSortedMapView_Submap) FirstEntry__Map_Entry() Map_Entry { return SequencedMap_FirstEntry__Map_Entry(t) }

func (t *ReverseOrderSortedMapView_Submap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *ReverseOrderSortedMapView_Submap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *ReverseOrderSortedMapView_Submap) Remove_O_O__Z(p0, p1 any) bool { return Map_Remove_O_O__Z(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) Reversed__SortedMap() SortedMap { return SortedMap_Reversed__SortedMap(t) }

func (t *ReverseOrderSortedMapView_Submap) LastEntry__Map_Entry() Map_Entry { return SequencedMap_LastEntry__Map_Entry(t) }

func (t *ReverseOrderSortedMapView_Submap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *ReverseOrderSortedMapView_Submap) Reversed__SequencedMap() SequencedMap { return SortedMap_Reversed__SequencedMap(t) }

func (t *ReverseOrderSortedMapView_Submap) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *ReverseOrderSortedMapView_Submap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) ReplaceAll_BiFunction__V(p0 BiFunction) { Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *ReverseOrderSortedMapView_Submap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *ReverseOrderSortedMapView_Submap) PutIfAbsent_O_O__O(p0, p1 any) any { return Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderSortedMapView_Submap) PollLastEntry__Map_Entry() Map_Entry { return SequencedMap_PollLastEntry__Map_Entry(t) }

func (t *ReverseOrderSortedMapView_Submap) ForEach_BiConsumer__V(p0 BiConsumer) { Map_ForEach_BiConsumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_Submap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *ReverseOrderSortedMapView_Submap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *ReverseOrderSortedMapView_Submap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *ReverseOrderSortedMapView_Submap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *ReverseOrderSortedMapView_Submap) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ReverseOrderSortedMapView_Submap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderSortedMapView_Submap) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_Submap) GetClass__Class() *Class { return ReverseOrderSortedMapView_Submap_class }

func (t *ReverseOrderSortedMapView_Submap) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_Submap_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_Submap); return ok }

func ReverseOrderSortedMapView_Submap_Cast(x any) *ReverseOrderSortedMapView_Submap { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_Submap); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_Submap_class)) }; return v }



type ReverseOrderSortedMapView_Submap_1 struct{ Object; F_cache Map_Entry; F_prevKey any; F_dead bool; F_it Iterator; F_this_1 *ReverseOrderSortedMapView_Submap }

func (t *ReverseOrderSortedMapView_Submap_1) Is_Iterator() {}

func ReverseOrderSortedMapView_Submap_1_New_ReverseOrderSortedMapView_Submap(p0 *ReverseOrderSortedMapView_Submap) *ReverseOrderSortedMapView_Submap_1 { t := &ReverseOrderSortedMapView_Submap_1{}; t.Ctor_ReverseOrderSortedMapView_Submap(p0); return t }

func (t *ReverseOrderSortedMapView_Submap_1) Ctor_ReverseOrderSortedMapView_Submap(this_0 *ReverseOrderSortedMapView_Submap) { NN(this_0); t.F_this_1 = this_0; t.F_cache = nil; t.F_prevKey = nil; t.F_dead = false; t.F_it = ReverseOrderSortedMapView_DescendingEntryIterator_SortedMap__Iterator(this_0.F_this_0.F_base) }

func (t *ReverseOrderSortedMapView_Submap_1) Next__O() any { return t.Next__Map_Entry() }

func (t *ReverseOrderSortedMapView_Submap_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_1) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_Submap_1) GetClass__Class() *Class { return ReverseOrderSortedMapView_Submap_1_class }

func (t *ReverseOrderSortedMapView_Submap_1) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderSortedMapView_Submap_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_Submap_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_Submap_1_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_Submap_1); return ok }

func ReverseOrderSortedMapView_Submap_1_Cast(x any) *ReverseOrderSortedMapView_Submap_1 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_Submap_1); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_Submap_1_class)) }; return v }



type ReverseOrderSortedMapView_Submap_2 struct{ AbstractSet; F_this_1 *ReverseOrderSortedMapView_Submap }

func ReverseOrderSortedMapView_Submap_2_New_ReverseOrderSortedMapView_Submap(p0 *ReverseOrderSortedMapView_Submap) *ReverseOrderSortedMapView_Submap_2 { t := &ReverseOrderSortedMapView_Submap_2{}; t.Ctor_ReverseOrderSortedMapView_Submap(p0); return t }

func (t *ReverseOrderSortedMapView_Submap_2) Ctor_ReverseOrderSortedMapView_Submap(this_0 *ReverseOrderSortedMapView_Submap) { NN(this_0); t.F_this_1 = this_0; t.AbstractSet.Ctor(t) }

func (t *ReverseOrderSortedMapView_Submap_2) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *ReverseOrderSortedMapView_Submap_2) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) Clear__V() { t.Impl_Clear__V(t) }

func (t *ReverseOrderSortedMapView_Submap_2) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ReverseOrderSortedMapView_Submap_2) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ReverseOrderSortedMapView_Submap_2) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderSortedMapView_Submap_2) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ReverseOrderSortedMapView_Submap_2) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderSortedMapView_Submap_2) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderSortedMapView_Submap_2) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReverseOrderSortedMapView_Submap_2) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_Submap_2) GetClass__Class() *Class { return ReverseOrderSortedMapView_Submap_2_class }

func (t *ReverseOrderSortedMapView_Submap_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_Submap_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_Submap_2_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_Submap_2); return ok }

func ReverseOrderSortedMapView_Submap_2_Cast(x any) *ReverseOrderSortedMapView_Submap_2 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_Submap_2); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_Submap_2_class)) }; return v }



type ReverseOrderSortedMapView_ViewEntry struct{ Object; F_map Map; F_key, F_value any }

func (t *ReverseOrderSortedMapView_ViewEntry) Is_Map_Entry() {}

func (t *ReverseOrderSortedMapView_ViewEntry) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedMapView_ViewEntry) GetClass__Class() *Class { return ReverseOrderSortedMapView_ViewEntry_class }

func (t *ReverseOrderSortedMapView_ViewEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedMapView_ViewEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedMapView_ViewEntry_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedMapView_ViewEntry); return ok }

func ReverseOrderSortedMapView_ViewEntry_Cast(x any) *ReverseOrderSortedMapView_ViewEntry { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedMapView_ViewEntry); if !ok { panic(ClassCast(x, ReverseOrderSortedMapView_ViewEntry_class)) }; return v }
