//line date.ae:1
package jrt

import (
	"strconv"
	"time"
)










// Date_I is java.util.Date's class interface (a non-leaf class since java.sql.Timestamp, which
// a2g translates, extends it: Impl_ methods, A2G-SPEC §5.3, §5.4).
type Date_I /*line :22:1*/ interface { Object_I
	Self_Date() *Date
	Is_Serializable()
	Is_Cloneable()
	Is_Comparable()
	GetTime__J() int64
	SetTime_J__V(ms int64)
	Before_Date__Z(o Date_I) bool
	After_Date__Z(o Date_I) bool
	CompareTo_Date__I(o Date_I) int32
	CompareTo_O__I(o any) int32
	GetYear__I() int32
	GetMonth__I() int32
	GetDate__I() int32
	GetDay__I() int32
	GetHours__I() int32
	GetMinutes__I() int32
	GetSeconds__I() int32
	GetTimezoneOffset__I() int32
	ToGMTString__String() *String }
// Date is java.util.Date's struct: milliseconds since the epoch.
type Date /*line :45:1*/ struct{ Object; F_fastTime int64 }

var Date_class =
	Define(&ClassInfo{Name: "java.util.Date", Kind: KindClass, Modifiers: AccPublic, Super: Object_class,

		Interfaces: []*Class{Serializable_class, Cloneable_class, Comparable_class}, Go: "arbace/jrt.Date",
	})
// Date_New is new Date(): now, from Go's clock.
func Date_New() *Date {
	t := &Date{}; t.Ctor(t); return t }
func Date_New_J(ms int64) *Date { t := &Date{}; t.Ctor_J(t, ms); return t }
// Date_New_I_I_I is the deprecated new Date(year - 1900, month, date), in the default zone.
//line :56:1
func Date_New_I_I_I(y, m, d int32,

) *Date {
	t := &Date{}; t.Ctor_I_I_I(t, y, m, d); return t }
func Date_New_I_I_I_I_I(y, m, d, h, mi int32) *Date {
	t := &Date{}; t.Ctor_I_I_I_I_I(t, y, m, d, h, mi); return t }
func Date_New_I_I_I_I_I_I(y, m, d, h, mi, s int32) *Date {
	t := &Date{}; t.Ctor_I_I_I_I_I_I(t, y, m, d, h, mi, s); return t }
// Ctor is Date(): now, from Go's clock.
func (t *Date) Ctor(this Date_I) {
	t.F_fastTime = time.Now().UnixMilli() }
func (t *Date) Ctor_J(this Date_I, ms int64) { t.F_fastTime = ms }
func (t *Date) Ctor_I_I_I(this Date_I, y, m, d int32) {
	t.F_fastTime = utcOfLocal(Date_UTC_I_I_I_I_I_I__J(y, m, d, 0, 0, 0)) }
func (t *Date) Ctor_I_I_I_I_I(this Date_I, y, m, d, h, mi int32) {
	t.F_fastTime = utcOfLocal(Date_UTC_I_I_I_I_I_I__J(y, m, d, h, mi, 0)) }
func (t *Date) Ctor_I_I_I_I_I_I(this Date_I, y, m, d, h, mi, s int32) {
	t.F_fastTime = utcOfLocal(Date_UTC_I_I_I_I_I_I__J(y, m, d, h, mi, s))
}


func (t *Date) Impl_GetTime__J(this Date_I) int64 { return t.F_fastTime }
func (t *Date) Impl_SetTime_J__V(this Date_I, ms int64) { t.F_fastTime = ms }
func (t *Date) Impl_Before_Date__Z(this, o Date_I) bool {
	return this.GetTime__J() < o.GetTime__J() }
func (t *Date) Impl_After_Date__Z(this, o Date_I) bool {
	return this.GetTime__J() > o.GetTime__J() }
func (t *Date) Impl_Equals_O__Z(this Date_I, o any) bool {
	x, ok := o.(Date_I)
	return ok && this.GetTime__J() == x.GetTime__J() }
// Impl_HashCode__I is Date.hashCode: (int) ht ^ (int) (ht >> 32), ht = getTime().
//line :86:1
func (t /*line :87:1*/*Date) Impl_HashCode__I(this Date_I) int32 {
	ht := this.GetTime__J()
	return int32(ht) ^ int32(ht>>32) }
func (t *Date) Impl_CompareTo_Date__I(this, o Date_I) int32 {
	a := this.GetTime__J()
	b := o.GetTime__J()
	if a < b { return -1 } else if a == b { return 0 } else { return 1 } }
func (t *Date) Impl_CompareTo_O__I(this Date_I, o any) int32 {
	return this.CompareTo_Date__I(Date_Cast(o)) }
// dateCloner: a translated subclass's shallow copy (a2g's CloneShallow).
//line :96:1
type dateCloner /*line :97:1*/ interface{ CloneShallow() any }
// Impl_Clone__O is Date.clone: a copy of the whole object.
//line :98:1
func (t /*line :99:1*/*Date) Impl_Clone__O(this Date_I) any {
	{ d, ok := this.(*Date)
		if ok { return Date_New_J(d.F_fastTime) } }
	return this.(dateCloner).CloneShallow()
}

func (t *Date) GetTime__J() int64 { return t.Impl_GetTime__J(t) }
func (t *Date) SetTime_J__V(ms int64) { t.Impl_SetTime_J__V(t, ms) }
func (t *Date) Before_Date__Z(o Date_I) bool { return t.Impl_Before_Date__Z(t, o) }
func (t *Date) After_Date__Z(o Date_I) bool { return t.Impl_After_Date__Z(t, o) }
func (t *Date) Equals_O__Z(o any) bool { return t.Impl_Equals_O__Z(t, o) }
func (t *Date) HashCode__I() int32 { return t.Impl_HashCode__I(t) }
func (t *Date) CompareTo_Date__I(o Date_I) int32 { return t.Impl_CompareTo_Date__I(t, o) }
func (t *Date) CompareTo_O__I(o any) int32 { return t.Impl_CompareTo_O__I(t, o) }
func (t *Date) Clone__O() any { return t.Impl_Clone__O(t) }
func (t *Date) ToString__String() *String { return t.Impl_ToString__String(t) }
func (t *Date) ToGMTString__String() *String { return t.Impl_ToGMTString__String(t) }
func (t *Date) GetYear__I() int32 { return t.Impl_GetYear__I(t) }
func (t *Date) GetMonth__I() int32 { return t.Impl_GetMonth__I(t) }
func (t *Date) GetDate__I() int32 { return t.Impl_GetDate__I(t) }
func (t *Date) GetDay__I() int32 { return t.Impl_GetDay__I(t) }
func (t *Date) GetHours__I() int32 { return t.Impl_GetHours__I(t) }
func (t *Date) GetMinutes__I() int32 { return t.Impl_GetMinutes__I(t) }
func (t *Date) GetSeconds__I() int32 { return t.Impl_GetSeconds__I(t) }
func (t *Date) GetTimezoneOffset__I() int32 { return t.Impl_GetTimezoneOffset__I(t) }

func (t *Date) Self_Date() *Date { return t }
func (t *Date) Ref() any { if t == nil { return nil }; return t }
func (t *Date) GetClass__Class() *Class { return Date_class }
func (t *Date) Is_Serializable() {}
func (t *Date) Is_Cloneable() {}
func (t *Date) Is_Comparable() {}
func Date_InstanceOf(x any) bool { _, ok := x.(Date_I); return ok }
func Date_Cast(x any) Date_I {
	if x == nil { return nil }
	v, ok := x.(Date_I)
	if !ok { panic(ClassCast(x, Date_class))
	}
	return v
}


const (
	dayMillis int64 = 86400000
	// the Gregorian cutover, 1582-10-15T00:00Z
	gregorianCutover int64 = -12219292800000
	cutoverDay       int64 = -141427
)
func floorDiv(a, b int64) int64 {
	q := a / b
	if q*b != a && a < 0 != (b < 0) {
		q--
	}
	return q }
func floorMod(a, b int64) int64 { return a - floorDiv(a, b)*b }
// gregorianDays: the days since 1970-01-01 of the proleptic Gregorian y-m-d (m 1..12, d any:
// days beyond the month count on).
//line :155:1
func gregorianDays(y, m, d int64) int64 {



	if m <= 2 {
		y-- }
	era := floorDiv(y, 400)
	yoe := y - era*400
	mp := floorMod(m+9, 12)
	doy := (153*mp+2)/5 + (d - 1)
	doe := yoe*365 + yoe/4 + -(yoe / 100) + doy
	return era*146097 + doe + -719468 }
// julianDays: the days since 1970-01-01 of the Julian y-m-d (astronomical years: 0 is 1 BC).
func julianDays(y, m, d int64) int64 {


	a := floorDiv(14-m, 12)
	yy := y + 4800 - a
	mm := m + 12*a - 3
	return d + floorDiv(153*mm+2, 5) + 365*yy + floorDiv(yy, 4) + -32083 - 2440588 }
// civilOfDays: the date of a day count in the calendar Date uses for it (Julian before the
// cutover): astronomical year, month 1..12, day.
//line :176:1
func civilOfDays(days int64) (y, m, d int64) {



	if days >= cutoverDay {
		z := days + 719468
		era := floorDiv(z, 146097)
		doe := z - era*146097
		yoe := (doe - doe/1460 - -(doe / 36524) - doe/146096) / 365
		doy := doe - (365*yoe + yoe/4 + -(yoe / 100))
		mp := (5*doy + 2) / 153
		d = doy - (153*mp+2)/5 + 1
		m = mp + 3
		if m > 12 {
			m = m - 12 }
		y = yoe + era*400
		if m <= 2 {
			y++ }
		return } else {
			c := days + 2440588 + 32082
			dd := floorDiv(4*c+3, 1461)
			e := c - floorDiv(1461*dd, 4)
			mm := floorDiv(5*e+2, 153)
			d = e - floorDiv(153*mm+2, 5) + 1
			m = mm + 3 - 12*floorDiv(mm, 10)
			y = dd - 4800 + floorDiv(mm, 10)
			return } }
// dateFields are a Date's fields in a zone: the astronomical year, month 1..12, day, hours,
// minutes, seconds, milliseconds, day of the week (1 Sunday ... 7 Saturday), and whether the
// date is Julian.
//line :204:1
type dateFields /*line :208:1*/ struct{ year, month, day, hour, minute, second, millis, weekday int64; julian bool }


var (
	// DateZoneOffset is the default zone's offset in milliseconds at an instant (TimeZone.getOffset), or nil: GMT.
	DateZoneOffset /*line :212:1*/ func(int64) int32 = nil
	// DateZoneOffsetByWall is the default zone's offset in milliseconds at a local time, as the JDK's calendars resolve one (ZoneInfo.getOffsetsByWall), or nil: GMT.
	DateZoneOffsetByWall /*line :215:1*/ func(int64) int32 = nil
	// DateZoneName is the default zone's short name at an instant, as Date.toString writes it (US English), or nil: GMT.
	DateZoneName /*line :218:1*/ func(int64) string = nil
)

// localOffset is the default zone's offset at the instant ms (0 without the hooks).
func localOffset(ms int64) int64 {

	if DateZoneOffset == nil {
		return 0 }
	return int64(DateZoneOffset(ms)) }
// utcOfLocal is the instant of the local time local in the default zone.
func utcOfLocal(local int64) int64 {

	if DateZoneOffsetByWall == nil {
		return local }
	return local - int64(DateZoneOffsetByWall(local)) }
// fields are the date's fields in the default zone.
func (t *Date) fields() dateFields {
	return t.fieldsAt(localOffset(t.F_fastTime)) }
// fieldsAt are the date's fields at the offset off (milliseconds).
func (t /*line :238:1*/*Date) fieldsAt(off int64) dateFields {
	ms := t.F_fastTime + off
	days := floorDiv(ms, dayMillis)
	tod := floorMod(ms, dayMillis)
	y, m, d := civilOfDays(days)
	return dateFields{year: y, month: m, day:                  d, hour:             tod / 3600000, minute: tod / 60000 % 60,
				second:   tod / 1000 % 60, millis: tod % 1000, weekday: floorMod(days+4, 7) + 1,
				julian:   days < cutoverDay} }
// yearOfEra: the year as Java prints a calendar date's year (y, or 1 - y before 1 AD in the
// Julian calendar).
//line :247:1
func (f dateFields) yearOfEra() int64 {



	if f.julian && f.year <= 0 {
		return 1 - f.year }
	return f.year }
// Date_UTC_I_I_I_I_I_I__J is the deprecated Date.UTC(year - 1900, month, date, hrs, min,
// sec): the milliseconds of those GMT fields, normalized as Date.normalize does (out-of-range
// fields count on; the calendar of the year, Julian before 1582, and the other one when the
// result falls on its side of the cutover; in 1582 GregorianCalendar's rule).
//line :255:1
func Date_UTC_I_I_I_I_I_I__J(year, month, date, hrs, mi, sec int32) int64 {





	y := int64(year) + 1900
	mo := int64(month)
	y = y + floorDiv(mo, 12)
	mo = floorMod(mo, 12) + 1
	tod := ((int64(hrs)*60+int64(mi))*60 + int64(sec)) * 1000
	d := int64(date)
	g := gregorianDays(y, mo, d)*dayMillis + tod
	j := julianDays(y, mo, d)*dayMillis + tod
	if y == 1582 {
		if floorDiv(g, dayMillis) >= cutoverDay {
			return g }
		return j }
	if y >= 1582 {

		if g >= gregorianCutover {
			return g }
		return j } else {

			if j < gregorianCutover {
				return j }
			return g } }
// Impl_GetYear__I is the deprecated getYear: the year minus 1900.
func (t /*line :284:1*/*Date) Impl_GetYear__I(this Date_I) int32 {
	f := t.fields()
	return int32(f.yearOfEra() - 1900) }
func (t *Date) Impl_GetMonth__I(this Date_I) int32 { return int32(t.fields().month - 1) }
func (t *Date) Impl_GetDate__I(this Date_I) int32 { return int32(t.fields().day) }
func (t *Date) Impl_GetDay__I(this Date_I) int32 { return int32(t.fields().weekday - 1) }
func (t *Date) Impl_GetHours__I(this Date_I) int32 { return int32(t.fields().hour) }
func (t *Date) Impl_GetMinutes__I(this Date_I) int32 { return int32(t.fields().minute) }
func (t *Date) Impl_GetSeconds__I(this Date_I) int32 { return int32(t.fields().second) }
// Impl_GetTimezoneOffset__I is the deprecated getTimezoneOffset: minutes to add to the local
// time for UTC.
//line :293:1
func (t /*line :296:1*/*Date) Impl_GetTimezoneOffset__I(this Date_I) int32 {
	return int32(-localOffset(t.F_fastTime) / 60000)
}
var (
	dayNames []string = []string{"", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}

	monthNames /*line :301:1*/[]string =
	[]string{"", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"})
// pad: v in decimal, zero-padded to n digits (a minus sign before them).
func pad(v int64, n int) string {


	neg := v < 0
	if neg {
		v = -v }
	s := strconv.FormatInt(v, 10)
	for len(s) < n {
		s = "0" + s }
	if neg {
		s = "-" + s
	}; return s }
// Impl_ToString__String is Date.toString in the default zone: Thu Jan 01 01:00:00 CET 1970.
func (t /*line :319:1*/*Date) Impl_ToString__String(this Date_I) *String {
	f := t.fields()
	zone := "GMT"
	if DateZoneName != nil {
		zone = DateZoneName(t.F_fastTime) }
	return Str(dayNames[f.weekday] + " " + monthNames[f.month] + " " + pad(f.day, 2) + " " +
		pad(f.hour, 2) + ":" + pad(f.minute, 2) + ":" + pad(f.second, 2) + " " + zone + " " +
		strconv.FormatInt(f.yearOfEra(), 10)) }
// Impl_ToGMTString__String is the deprecated Date.toGMTString: 1 Jan 1970 00:00:00 GMT.
func (t /*line :330:1*/*Date) Impl_ToGMTString__String(this Date_I) *String {
	f := t.fieldsAt(0)
	return Str(strconv.FormatInt(f.day, 10) + " " + monthNames[f.month] + " " +
		strconv.FormatInt(f.yearOfEra(), 10) + " " + pad(f.hour, 2) + ":" + pad(f.minute, 2) + ":" +
		pad(f.second, 2) + " GMT") }
// InstantText is the text #inst prints for the date, as arbace.instant's SimpleDateFormat
// "yyyy-MM-dd'T'HH:mm:ss.SSS-00:00" in GMT writes it (the year of the era, at least four
// digits): what the reworked arbace.instant needs (JRT-NOTES.md, "#inst").
//line :336:1
func (t /*line :340:1*/*Date) InstantText() string {
	f := t.fieldsAt(0)
	return pad(f.yearOfEra(), 4) + "-" + pad(f.month, 2) + "-" + pad(f.day, 2) + "T" + pad(f.hour, 2) + ":" +
		pad(f.minute, 2) + ":" + pad(f.second, 2) + "." + pad(f.millis, 3) + "-00:00"
}
func init() {
	Date_class.Info().IsInstance = Date_InstanceOf
}
