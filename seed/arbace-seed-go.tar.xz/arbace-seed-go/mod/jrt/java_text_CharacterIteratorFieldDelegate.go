//line java_text_CharacterIteratorFieldDelegate.ae:1
package jrt












func CharacterIteratorFieldDelegate_New() *CharacterIteratorFieldDelegate { t := &CharacterIteratorFieldDelegate{}; t.Ctor(); return t }
//line :14:1
func (t *CharacterIteratorFieldDelegate) Ctor() { t.F_attributedStrings = ArrayList_New() }

func (t *CharacterIteratorFieldDelegate) Formatted_Format_Field_O_I_I_Format_StringBuf__V(attr Format_Field_I, value any, start, end int32, buffer Format_StringBuf) {

	if start == end { } else {
		if start < t.F_size {
			var index int32 = t.F_size; var asIndex int32 = NN(t.F_attributedStrings).Size__I() - 1

		L1: for { if start < index {
			var as *AttributedString; var tmp1 *ArrayList = t.F_attributedStrings; var tmp2 int32
			var old_1 int32 = asIndex

			asIndex = asIndex - 1
//line :25:1
			tmp2 = old_1
//line :23:1
			as = AttributedString_Cast(NN(tmp1).Get_I__O(tmp2)); var newIndex int32 = index - NN(as).Length__I(); var aStart int32 = Math_Max_I_I__I(0, start-newIndex)






			NN(as).AddAttribute_AttributedCharacterIterator_Attribute_O_I_I__V(attr, value, aStart, Math_Min_I_I__I(end-start, NN(as).Length__I()-aStart)+aStart)







			index = newIndex
//line :22:1
			continue L1 }; break L1
		}
		}














		if t.F_size < start {
			var tmp3 *ArrayList = t.F_attributedStrings; NN(tmp3).Add_O__Z(AttributedString_New_String(buffer.Substring_I_I__String(t.F_size, start)))
			t.F_size = start }
		if t.F_size < end {
			var aStart_2 int32 = Math_Max_I_I__I(start, t.F_size); var string_ *AttributedString = AttributedString_New_String(buffer.Substring_I_I__String(aStart_2, end))

			NN(string_).AddAttribute_AttributedCharacterIterator_Attribute_O__V(attr, value)
			NN(t.F_attributedStrings).Add_O__Z(string_.Ref())
			t.F_size = end
		} } }
func (t *CharacterIteratorFieldDelegate) Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(fieldID int32, attr Format_Field_I, value any, start, end int32, buffer Format_StringBuf) {

	t.Formatted_Format_Field_O_I_I_Format_StringBuf__V(attr, value, start, end, buffer)
}
func (t *CharacterIteratorFieldDelegate) GetIterator_String__AttributedCharacterIterator(string_ *String) AttributedCharacterIterator {
	if NN(string_).Length__I() > t.F_size {
		var tmp1 *ArrayList = t.F_attributedStrings; NN(tmp1).Add_O__Z(AttributedString_New_String(NN(string_).Substring_I__String(t.F_size)))
		t.F_size = NN(string_).Length__I() }
	var iCount int32 = NN(t.F_attributedStrings).Size__I(); var iterators *RefArray = NewRefArray(AttributedCharacterIterator_class, iCount)
	var counter int32 = 0
L1: for {
	if counter < iCount {
		iterators.Store(counter, NN(AttributedString_Cast(NN(t.F_attributedStrings).Get_I__O(counter))).GetIterator__AttributedCharacterIterator())


		counter = counter + 1; continue L1 }
//line :59:1
	break L1
}




	return AttributedString_New_AttributedCharacterIterator1(iterators).GetIterator__AttributedCharacterIterator()
}


type CharacterIteratorFieldDelegate struct{ Object; F_attributedStrings *ArrayList; F_size int32 }

func (t *CharacterIteratorFieldDelegate) Is_Format_FieldDelegate() {}

func (t *CharacterIteratorFieldDelegate) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterIteratorFieldDelegate) GetClass__Class() *Class { return CharacterIteratorFieldDelegate_class }

func (t *CharacterIteratorFieldDelegate) ToString__String() *String { return Object_toString(t) }

func (t *CharacterIteratorFieldDelegate) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterIteratorFieldDelegate) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterIteratorFieldDelegate_InstanceOf(x any) bool { _, ok := x.(*CharacterIteratorFieldDelegate); return ok }

func CharacterIteratorFieldDelegate_Cast(x any) *CharacterIteratorFieldDelegate { if x == nil { return nil }; v, ok := x.(*CharacterIteratorFieldDelegate); if !ok { panic(ClassCast(x, CharacterIteratorFieldDelegate_class)) }; return v }
