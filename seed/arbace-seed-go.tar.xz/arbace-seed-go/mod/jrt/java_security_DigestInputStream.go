//line java_security_DigestInputStream.ae:1
package jrt












func DigestInputStream_New_InputStream_MessageDigest(p0 InputStream_I, p1 MessageDigest_I) *DigestInputStream { t := &DigestInputStream{}; t.Ctor_InputStream_MessageDigest(p0, p1); return t }
//line :14:1
func (t *DigestInputStream) Ctor_InputStream_MessageDigest(stream InputStream_I, digest MessageDigest_I) { t.FilterInputStream.Ctor_InputStream(t, stream); t.F_on = true

	t.SetMessageDigest_MessageDigest__V(digest)
}
func (t *DigestInputStream) GetMessageDigest__MessageDigest() MessageDigest_I { return t.F_digest }

func (t *DigestInputStream) SetMessageDigest_MessageDigest__V(digest MessageDigest_I) {
	t.F_digest = digest
}
func (t *DigestInputStream) Read__I() int32 {
	var ch int32 = t.F_in.Load().Read__I(); var tmp1 bool; var tmp2 bool
	tmp2 = t.F_on; if tmp2 { tmp2 = !(ch == -1) }; tmp1 = tmp2; if tmp1 { t.F_digest.Update_B__V(int8(ch)) }
//line :24:1
	return ch
}


func (t *DigestInputStream) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	var result int32 = t.F_in.Load().Read_B1_I_I__I(b, off, len_); var tmp1 bool; var tmp2 bool
	tmp2 = t.F_on; if tmp2 { tmp2 = !(result == -1) }; tmp1 = tmp2; if tmp1 { t.F_digest.Update_B1_I_I__V(b, off, result) }
//line :29:1
	return result
}


func (t *DigestInputStream) On_Z__V(on bool) { t.F_on = on }

func (t *DigestInputStream) ToString__String() *String {
	return Concat(Lit_1526, t.F_digest.ToString__String())
}


type DigestInputStream struct{ FilterInputStream; F_on bool; F_digest MessageDigest_I }

func (t *DigestInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *DigestInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *DigestInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *DigestInputStream) Close__V() { t.Impl_Close__V(t) }

func (t *DigestInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *DigestInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *DigestInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *DigestInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *DigestInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *DigestInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *DigestInputStream) Available__I() int32 { return t.Impl_Available__I(t) }

func (t *DigestInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *DigestInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *DigestInputStream) GetClass__Class() *Class { return DigestInputStream_class }

func (t *DigestInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DigestInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func DigestInputStream_InstanceOf(x any) bool { _, ok := x.(*DigestInputStream); return ok }

func DigestInputStream_Cast(x any) *DigestInputStream { if x == nil { return nil }; v, ok := x.(*DigestInputStream); if !ok { panic(ClassCast(x, DigestInputStream_class)) }; return v }
