//line java_io_FileDescriptor.ae:1
package jrt








func FileDescriptor_New() *FileDescriptor { FileDescriptor_Init(); t := &FileDescriptor{}; t.Ctor(); return t }
//line :10:1
func (t *FileDescriptor) Ctor() { t.F_fd = -1 }

func FileDescriptor_New_I(p0 int32) *FileDescriptor { FileDescriptor_Init(); t := &FileDescriptor{}; t.Ctor_I(p0); return t }
//line :12:1
func (t *FileDescriptor) Ctor_I(fd int32) { t.F_fd = fd }










func (t *FileDescriptor_1) Set_FileDescriptor_I__V(fd *FileDescriptor, h int32) { NN(fd).Set_I__V(h) }

func (t *FileDescriptor) Valid__Z() bool { return !(t.F_fd == -1) }

func (t *FileDescriptor) Sync__V() {}

func (t *FileDescriptor) Set_I__V(fd int32) { MonitorEnter(t); defer MonitorExit(t)
	t.F_fd = fd
	HostFiles_Register_FileDescriptor_I__V(t, fd)
}
func (t *FileDescriptor) Close__V() { MonitorEnter(t); defer MonitorExit(t)
	var n int32 = t.F_fd; if n == -1 { } else { t.Set_I__V(-1); if n > 2 { HostFiles_Close_I__V(n)
	}
	}
}
type FileDescriptor struct{ Object; F_fd int32 }

var FileDescriptor_in *FileDescriptor

var FileDescriptor_out *FileDescriptor

var FileDescriptor_err *FileDescriptor

var FileDescriptor_init ClassInit

func FileDescriptor_Init() { if !FileDescriptor_init.Done() { FileDescriptor_init.Run(FileDescriptor_clinit) } }

func FileDescriptor_clinit() { FileDescriptor_in = FileDescriptor_New_I(0); FileDescriptor_out = FileDescriptor_New_I(1); FileDescriptor_err = FileDescriptor_New_I(2)
//line :21:1
	HostFiles_SetDescriptorAccess_HostFiles_DescriptorAccess__V(FileDescriptor_1_New())
}





























func (t *FileDescriptor) Ref() any { if t == nil { return nil }; return t }

func (t *FileDescriptor) GetClass__Class() *Class { return FileDescriptor_class }

func (t *FileDescriptor) ToString__String() *String { return Object_toString(t) }

func (t *FileDescriptor) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileDescriptor) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileDescriptor_InstanceOf(x any) bool { _, ok := x.(*FileDescriptor); return ok }

func FileDescriptor_Cast(x any) *FileDescriptor { if x == nil { return nil }; v, ok := x.(*FileDescriptor); if !ok { panic(ClassCast(x, FileDescriptor_class)) }; return v }



type FileDescriptor_1 struct{ Object }

func (t *FileDescriptor_1) Is_HostFiles_DescriptorAccess() {}

func FileDescriptor_1_New() *FileDescriptor_1 { t := &FileDescriptor_1{}; t.Ctor(); return t }

func (t *FileDescriptor_1) Ctor() {}

func (t *FileDescriptor_1) Ref() any { if t == nil { return nil }; return t }

func (t *FileDescriptor_1) GetClass__Class() *Class { return FileDescriptor_1_class }

func (t *FileDescriptor_1) ToString__String() *String { return Object_toString(t) }

func (t *FileDescriptor_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileDescriptor_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileDescriptor_1_InstanceOf(x any) bool { _, ok := x.(*FileDescriptor_1); return ok }

func FileDescriptor_1_Cast(x any) *FileDescriptor_1 { if x == nil { return nil }; v, ok := x.(*FileDescriptor_1); if !ok { panic(ClassCast(x, FileDescriptor_1_class)) }; return v }
