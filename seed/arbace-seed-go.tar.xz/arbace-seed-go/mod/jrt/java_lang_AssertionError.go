//line java_lang_AssertionError.ae:1
package jrt








func AssertionError_New() *AssertionError { t := &AssertionError{}; t.Ctor(); return t }
//line :10:1
func (t *AssertionError) Ctor() { t.Error.Ctor(t) }

func AssertionError_New_String(p0 *String) *AssertionError { t := &AssertionError{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *AssertionError) Ctor_String(detailMessage *String) { t.Error.Ctor_String(t, detailMessage) }


func AssertionError_New_O(p0 any) *AssertionError { t := &AssertionError{}; t.Ctor_O(p0); return t }
//line :15:1
func (t *AssertionError) Ctor_O(detailMessage any) { t.Ctor_String(String_ValueOf_O__String(detailMessage))

	if Throwable_InstanceOf(detailMessage) { t.InitCause_Throwable__Throwable(Throwable_Cast(detailMessage))
	} }
func AssertionError_New_Z(p0 bool) *AssertionError { t := &AssertionError{}; t.Ctor_Z(p0); return t }
//line :19:1
func (t *AssertionError) Ctor_Z(detailMessage bool) { t.Ctor_String(String_ValueOf_Z__String(detailMessage)) }


func AssertionError_New_C(p0 uint16) *AssertionError { t := &AssertionError{}; t.Ctor_C(p0); return t }
//line :22:1
func (t *AssertionError) Ctor_C(detailMessage uint16) { t.Ctor_String(String_ValueOf_C__String(detailMessage)) }


func AssertionError_New_I(p0 int32) *AssertionError { t := &AssertionError{}; t.Ctor_I(p0); return t }
//line :25:1
func (t *AssertionError) Ctor_I(detailMessage int32) { t.Ctor_String(String_ValueOf_I__String(detailMessage)) }


func AssertionError_New_J(p0 int64) *AssertionError { t := &AssertionError{}; t.Ctor_J(p0); return t }
//line :28:1
func (t *AssertionError) Ctor_J(detailMessage int64) { t.Ctor_String(String_ValueOf_J__String(detailMessage)) }


func AssertionError_New_F(p0 float32) *AssertionError { t := &AssertionError{}; t.Ctor_F(p0); return t }
//line :31:1
func (t *AssertionError) Ctor_F(detailMessage float32) { t.Ctor_String(String_ValueOf_F__String(detailMessage)) }


func AssertionError_New_D(p0 float64) *AssertionError { t := &AssertionError{}; t.Ctor_D(p0); return t }
//line :34:1
func (t *AssertionError) Ctor_D(detailMessage float64) { t.Ctor_String(String_ValueOf_D__String(detailMessage)) }


func AssertionError_New_String_Throwable(p0 *String, p1 Throwable_I) *AssertionError { t := &AssertionError{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :37:1
func (t *AssertionError) Ctor_String_Throwable(message *String, cause Throwable_I) { t.Error.Ctor_String_Throwable(t, message, cause) }














type AssertionError struct{ Error }

const AssertionError_serialVersionUID int64 = -5013299493970297370

func (t *AssertionError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *AssertionError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *AssertionError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *AssertionError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *AssertionError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *AssertionError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *AssertionError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *AssertionError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *AssertionError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *AssertionError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *AssertionError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *AssertionError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AssertionError) Ref() any { if t == nil { return nil }; return t }

func (t *AssertionError) GetClass__Class() *Class { return AssertionError_class }

func (t *AssertionError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AssertionError) CloneShallow() any { panic(CloneNotSupported(t)) }

func AssertionError_InstanceOf(x any) bool { _, ok := x.(*AssertionError); return ok }

func AssertionError_Cast(x any) *AssertionError { if x == nil { return nil }; v, ok := x.(*AssertionError); if !ok { panic(ClassCast(x, AssertionError_class)) }; return v }
