//line java_io_FilenameFilter.ae:1
package jrt






type FilenameFilter interface{ Object_I; Is_FilenameFilter(); Accept_File_String__Z(p0 *File, p1 *String) bool }

func FilenameFilter_InstanceOf(x any) bool { _, ok := x.(FilenameFilter); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FilenameFilter_class) } }; return ok }

func FilenameFilter_Cast(x any) FilenameFilter { if x == nil { return nil }; v, ok := x.(FilenameFilter); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FilenameFilter_class) } }; if !ok { panic(ClassCast(x, FilenameFilter_class)) }; return v }
