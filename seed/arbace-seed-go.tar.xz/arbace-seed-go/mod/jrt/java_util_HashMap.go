//line java_util_HashMap.ae:1
package jrt












































func HashMap_Node_New_I_O_O_HashMap_Node(p0 int32, p1, p2 any, p3 HashMap_Node_I) *HashMap_Node { t := &HashMap_Node{}; t.Ctor_I_O_O_HashMap_Node(t, p0, p1, p2, p3); return t }
//line :46:1
func (t *HashMap_Node) Ctor_I_O_O_HashMap_Node(this HashMap_Node_I, hash int32, key, value any, next HashMap_Node_I) {
	t.F_hash = hash
	t.F_key = key
	t.F_value = value
	t.F_next = next
}
func (t *HashMap_Node) Impl_GetKey__O(this HashMap_Node_I) any { return t.F_key }

func (t *HashMap_Node) Impl_GetValue__O(this HashMap_Node_I) any { return t.F_value }

func (t *HashMap_Node) Impl_ToString__String(this HashMap_Node_I) *String {
	return Concat(StrOfObj(t.F_key), Lit_1171, StrOfObj(t.F_value))
}
func (t *HashMap_Node) Impl_HashCode__I(this HashMap_Node_I) int32 {
	return Objects_HashCode_O__I(t.F_key) ^ Objects_HashCode_O__I(t.F_value)
}
func (t *HashMap_Node) Impl_SetValue_O__O(this HashMap_Node_I, newValue any) any {
	var oldValue any = t.F_value; t.F_value = newValue; return oldValue
}
func (t *HashMap_Node) Impl_Equals_O__Z(this HashMap_Node_I, o any) bool {
	if any(o) == any(this) { return true } else {

		var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var tmp2 any = t.F_key
			if Objects_Equals_O_O__Z(tmp2, e.GetKey__O()) { var tmp3 any = t.F_value; return Objects_Equals_O_O__Z(tmp3, e.GetValue__O()) } else { return false } } else {
//line :68:1
				return false
			}
	}
}
func HashMap_Hash_O__I(key any) int32 {
	var h int32 = 0
	if key == nil { return 0 } else { var tmp1 int32; h = HashCode(key); tmp1 = h; return tmp1 ^ int32(uint32(h)>>16)
	} }
func HashMap_ComparableClassFor_O__Class(x any) *Class {
	if Comparable_InstanceOf(x) {
		var c *Class; var ts *RefArray; var as *RefArray; var p any; var tmp1 *Class; _ = p



		c = GetClass(x); tmp1 = c; if tmp1 == String_class { return c }
		var tmp2 *RefArray; ts = NN(c).GetGenericInterfaces__Type1(); tmp2 = ts; if !(tmp2 == nil) {
			var arr_101852 *RefArray = ts; var len_101853 int32 = int32(len(arr_101852.A)); var i_101854 int32 = 0; for ; i_101854 < len_101853; i_101854++ { var t_ Type = As[Type](arr_101852.A[i_101854]); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool
				tmp7 = A2g_Discard(t_); if tmp7 {
					tmp7 = any(A2g_Missing[Type]("class java.lang.reflect.ParameterizedType is not in the closed world")) == any(Comparable_class) }
//line :85:1
				tmp6 = tmp7; if tmp6 {



					var tmp8 *RefArray; as = A2g_Missing[*RefArray]("class java.lang.reflect.ParameterizedType is not in the closed world"); tmp8 = as; tmp6 = !(tmp8 == nil) }
//line :85:1
				tmp5 = tmp6; if tmp5 {




					tmp5 = int32(len(as.A)) == 1 }
//line :85:1
				tmp4 = tmp5; if tmp4 {





					tmp4 = any(As[Type](as.A[0])) == any(c.Ref()) }
//line :85:1
				tmp3 = tmp4; if tmp3 {






					return c } } } }
//line :76:1
	return nil
}

















func HashMap_CompareComparables_Class_O_O__I(kc *Class, k, x any) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = x == nil; if !tmp2 { tmp2 = !(GetClass(x) == kc) }; tmp1 = tmp2; if tmp1 { return 0 } else { return Comparable_Cast(k).CompareTo_O__I(x)
	} }
func HashMap_TableSizeFor_I__I(cap_ int32) int32 {
	var n int32 = int32(uint32(4294967295) >> (Integer_NumberOfLeadingZeros_I__I(cap_-1) & 31))


	if n < 0 { return 1 } else { if n >= 1073741824 { return 1073741824 } else { return n + 1
	}
	}
}










func HashMap_New_I_F(p0 int32, p1 float32) *HashMap { t := &HashMap{}; t.Ctor_I_F(t, p0, p1); return t }
//line :116:1
func (t *HashMap) Ctor_I_F(this HashMap_I, initialCapacity int32, loadFactor float32) { t.AbstractMap.Ctor(this)
	if initialCapacity < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2690, StrOfInt(initialCapacity))))) }
	if initialCapacity > 1073741824 { initialCapacity = 1073741824 }
	var tmp1 bool; var tmp2 bool; tmp2 = loadFactor <= 0.0; if !tmp2 { tmp2 = Float_IsNaN_F__Z(loadFactor) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2691, StrOfFloat(loadFactor))))) }
	t.F_loadFactor = loadFactor
	t.F_threshold = HashMap_TableSizeFor_I__I(initialCapacity)
}
func HashMap_New_I(p0 int32) *HashMap { t := &HashMap{}; t.Ctor_I(t, p0); return t }
//line :125:1
func (t *HashMap) Ctor_I(this HashMap_I, initialCapacity int32) { t.Ctor_I_F(this, initialCapacity, 0.75) }


func HashMap_New() *HashMap { t := &HashMap{}; t.Ctor(t); return t }
//line :128:1
func (t *HashMap) Ctor(this HashMap_I) { t.AbstractMap.Ctor(this)
	t.F_loadFactor = 0.75
}
func HashMap_New_Map(p0 Map) *HashMap { t := &HashMap{}; t.Ctor_Map(t, p0); return t }
//line :131:1
func (t *HashMap) Ctor_Map(this HashMap_I, m Map) { t.AbstractMap.Ctor(this)
	t.F_loadFactor = 0.75
	this.PutMapEntries_Map_Z__V(m, false)
}
func (t *HashMap) Impl_PutMapEntries_Map_Z__V(this HashMap_I, m Map, evict bool) {

	var s int32 = m.Size__I()
	if s > 0 {
		if t.F_table == nil {
			var dt float64 = Math_Ceil_D__D(float64(s) / float64(t.F_loadFactor)); var t_ int32
			if dt < 1.073741824e9 { t_ = D2I(dt) } else { t_ = 1073741824 }
			if t_ > t.F_threshold { t.F_threshold = HashMap_TableSizeFor_I__I(t_) } } else {
			L1: for { var tmp1 bool; var tmp2 bool; tmp2 = s > t.F_threshold; if tmp2 { tmp2 = int32(len(t.F_table.A)) < 1073741824 }; tmp1 = tmp2; if tmp1 { this.Resize__HashMap_Node1(); continue L1 }; break L1 } }
		var i_101855 Iterator = m.EntrySet__Set().Iterator__Iterator(); for i_101855.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101855.Next__O()); var key any = e.GetKey__O(); var value any = e.GetValue__O()


			this.PutVal_I_O_O_Z_Z__O(HashMap_Hash_O__I(key), key, value, false, evict)
		} } }
func (t *HashMap) Impl_Size__I(this HashMap_I) int32 { return t.F_size }

func (t *HashMap) Impl_IsEmpty__Z(this HashMap_I) bool { return t.F_size == 0 }

func (t *HashMap) Impl_Get_O__O(this HashMap_I, key any) any {
	var e HashMap_Node_I; var tmp1 HashMap_Node_I
	e = this.GetNode_O__HashMap_Node(key); tmp1 = e; if !(tmp1 == nil) { return e.Self_HashMap_Node().F_value } else { return nil
	} }
func (t *HashMap) Impl_GetNode_O__HashMap_Node(this HashMap_I, key any) HashMap_Node_I {
	var tab *RefArray; var first HashMap_Node_I; var e HashMap_Node_I; var n int32 = 0; var hash int32 = 0; var k any; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *RefArray





	tab = t.F_table; tmp4 = tab; tmp3 = !(tmp4 == nil); if tmp3 { var tmp5 int32; n = int32(len(tab.A)); tmp5 = n; tmp3 = tmp5 > 0 }; tmp2 = tmp3; if tmp2 {
		var tmp6 HashMap_Node_I; var tmp7 *RefArray = tab; var tmp8 int32 = n - 1; var tmp9 int32



		hash = HashMap_Hash_O__I(key); tmp9 = hash
//line :165:1
		first = As[HashMap_Node_I](tmp7.A[tmp8&tmp9]); tmp6 = first; tmp2 = !(tmp6 == nil) }
//line :164:1
	tmp1 = tmp2; if tmp1 {





		var tmp10 bool; var tmp11 bool; tmp11 = first.Self_HashMap_Node().F_hash == hash; if tmp11 {
			var tmp12 bool; var tmp13 any; k = first.Self_HashMap_Node().F_key; tmp13 = k; tmp12 = tmp13 == key; if !tmp12 { var tmp14 bool; tmp14 = !(key == nil); if tmp14 { tmp14 = Equals(key, k) }; tmp12 = tmp14 }; tmp11 = tmp12 }
//line :170:1
		tmp10 = tmp11; if tmp10 {

			return first }
		var tmp15 HashMap_Node_I; e = first.Self_HashMap_Node().F_next; tmp15 = e; if !(tmp15 == nil) {
			if HashMap_TreeNode_InstanceOf(first) { return Up_HashMap_TreeNode_HashMap_Node(NN(HashMap_TreeNode_Cast(first)).GetTreeNode_I_O__HashMap_TreeNode(hash, key)) }
		L1: for {
			var tmp16 bool; var tmp17 bool; tmp17 = e.Self_HashMap_Node().F_hash == hash; if tmp17 {
				var tmp18 bool; var tmp19 any; k = e.Self_HashMap_Node().F_key; tmp19 = k; tmp18 = tmp19 == key; if !tmp18 { var tmp20 bool; tmp20 = !(key == nil); if tmp20 { tmp20 = Equals(key, k) }; tmp18 = tmp20 }; tmp17 = tmp18 }
//line :176:1
			tmp16 = tmp17; if tmp16 {

				return e }
			var tmp21 HashMap_Node_I; e = e.Self_HashMap_Node().F_next; tmp21 = e; if !(tmp21 == nil) { continue L1 }
//line :175:1
			break L1 } } }
//line :158:1
	return nil
}






















func (t *HashMap) Impl_ContainsKey_O__Z(this HashMap_I, key any) bool {
	return !(this.GetNode_O__HashMap_Node(key) == nil)
}
func (t *HashMap) Impl_Put_O_O__O(this HashMap_I, key, value any) any {
	return this.PutVal_I_O_O_Z_Z__O(HashMap_Hash_O__I(key), key, value, false, true)
}
func (t *HashMap) Impl_PutVal_I_O_O_Z_Z__O(this HashMap_I, hash int32, key, value any, onlyIfAbsent, evict bool) any {
	var tab *RefArray; var p HashMap_Node_I; var n int32 = 0; var i int32 = 0; var tmp1 bool; var tmp2 bool; var tmp3 *RefArray



	tab = t.F_table; tmp3 = tab; tmp2 = tmp3 == nil; if !tmp2 { var tmp4 int32; n = int32(len(tab.A)); tmp4 = n; tmp2 = tmp4 == 0 }; tmp1 = tmp2; if tmp1 {
		var tmp5 *RefArray; tab = this.Resize__HashMap_Node1(); tmp5 = tab; n = int32(len(tmp5.A)) }
	var tmp6 HashMap_Node_I; var tmp7 *RefArray = tab; var tmp8 int32; i = (n - 1) & hash; tmp8 = i; p = As[HashMap_Node_I](tmp7.A[tmp8]); tmp6 = p; if tmp6 == nil {
		tab.Store(i, this.NewNode_I_O_O_HashMap_Node__HashMap_Node(hash, key, value, nil)) } else {
			var e HashMap_Node_I; var k any; var tmp9 bool; var tmp10 bool


			tmp10 = p.Self_HashMap_Node().F_hash == hash; if tmp10 {
				var tmp11 bool; var tmp12 any; k = p.Self_HashMap_Node().F_key; tmp12 = k; tmp11 = tmp12 == key; if !tmp11 { var tmp13 bool; tmp13 = !(key == nil); if tmp13 { tmp13 = Equals(key, k) }; tmp11 = tmp13 }; tmp10 = tmp11 }
//line :200:1
			tmp9 = tmp10
//line :199:1
			if tmp9 {


				e = p } else {
//line :199:1
					if HashMap_TreeNode_InstanceOf(p) {




						e = Up_HashMap_TreeNode_HashMap_Node(NN(HashMap_TreeNode_Cast(p)).PutTreeVal_HashMap_HashMap_Node1_I_O_O__HashMap_TreeNode(this, tab, hash, key, value)) } else {

							var binCount int32 = 0; L1: for {
								var tmp14 HashMap_Node_I; e = p.Self_HashMap_Node().F_next; tmp14 = e; if tmp14 == nil {

									p.Self_HashMap_Node().F_next = this.NewNode_I_O_O_HashMap_Node__HashMap_Node(hash, key, value, nil)
									if binCount >= 7 {
										this.TreeifyBin_HashMap_Node1_I__V(tab, hash) } } else {
											var tmp15 bool; var tmp16 bool; tmp16 = e.Self_HashMap_Node().F_hash == hash; if tmp16 {
												var tmp17 bool; var tmp18 any; k = e.Self_HashMap_Node().F_key; tmp18 = k; tmp17 = tmp18 == key; if !tmp17 {
													var tmp19 bool; tmp19 = !(key == nil); if tmp19 { tmp19 = Equals(key, k) }; tmp17 = tmp19 }
//line :213:1
												tmp16 = tmp17 }
//line :212:1
											tmp15 = tmp16; if tmp15 { } else {


												p = e
												binCount = binCount + 1; continue L1 } }
//line :206:1
								break L1
							}
						}
				}







			if !(e == nil) {
				var oldValue any = e.Self_HashMap_Node().F_value; var tmp20 bool; var tmp21 bool
				tmp21 = !onlyIfAbsent; if !tmp21 { tmp21 = oldValue == nil }; tmp20 = tmp21; if tmp20 { e.Self_HashMap_Node().F_value = value }
				this.AfterNodeAccess_HashMap_Node__V(e)
				return oldValue } }
	t.F_modCount = t.F_modCount + 1
	var tmp22 int32; var tmp23 int32 = t.F_size + 1; t.F_size = tmp23; tmp22 = tmp23; if tmp22 > t.F_threshold { this.Resize__HashMap_Node1() }
	this.AfterNodeInsertion_Z__V(evict)
//line :189:1
	return nil
}




































func (t *HashMap) Impl_Resize__HashMap_Node1(this HashMap_I) *RefArray {
	var oldTab *RefArray = t.F_table; var oldCap int32
	if oldTab == nil { oldCap = 0 } else { oldCap = int32(len(oldTab.A)) }
//line :228:1
	var oldThr int32 = t.F_threshold
	var newCap int32 = 0
	var newThr int32 = 0


	if oldCap > 0 {

		if oldCap >= 1073741824 {
			t.F_threshold = 2147483647; return oldTab } else {
//line :235:1
				var tmp1 bool; var tmp2 bool; var tmp3 int32

				newCap = oldCap << 1; tmp3 = newCap; tmp2 = tmp3 < 1073741824; if tmp2 {
					tmp2 = oldCap >= 16 }
//line :237:1
				tmp1 = tmp2
//line :235:1
				if tmp1 {



					newThr = oldThr << 1 } } } else {
//line :233:1
						if oldThr > 0 {






							newCap = oldThr } else {


								newCap = 16
								newThr = 12
							}
					}
	if newThr == 0 {
		var ft float32 = float32(float32(newCap) * t.F_loadFactor); var tmp4 int32; var tmp5 bool; var tmp6 bool

		tmp6 = newCap < 1073741824; if tmp6 { tmp6 = ft < 1.0737418e9 }; tmp5 = tmp6; if tmp5 {
			tmp4 = F2I(ft) } else {
//line :250:1
				tmp4 = 2147483647 }
//line :249:1
		newThr = tmp4
	}


	t.F_threshold = newThr
	var newTab *RefArray = NewRefArray(HashMap_Node_class, newCap)
	t.F_table = newTab
	if !(oldTab == nil) {
		var j int32 = 0; L1: for {
			if j < oldCap {
				var e HashMap_Node_I; var tmp7 HashMap_Node_I
				e = As[HashMap_Node_I](oldTab.A[j]); tmp7 = e; if !(tmp7 == nil) {

					oldTab.Store(j, nil)
					if e.Self_HashMap_Node().F_next == nil {


						newTab.Store(e.Self_HashMap_Node().F_hash&(newCap-1), e)


						j = j + 1; continue L1 } else {
//line :263:1
							if HashMap_TreeNode_InstanceOf(e) {








								NN(HashMap_TreeNode_Cast(e)).Split_HashMap_HashMap_Node1_I_I__V(this, newTab, j, oldCap)
								j = j + 1; continue L1 } else {

									var loHead HashMap_Node_I; var loTail HashMap_Node_I; var hiHead HashMap_Node_I; var hiTail HashMap_Node_I; var next HashMap_Node_I




								L2: for {
									next = e.Self_HashMap_Node().F_next
									if e.Self_HashMap_Node().F_hash&oldCap == 0 {

										if loTail == nil { loHead = e } else { loTail.Self_HashMap_Node().F_next = e }
										loTail = e } else {

											if hiTail == nil { hiHead = e } else { hiTail.Self_HashMap_Node().F_next = e }
											hiTail = e }
									var tmp8 HashMap_Node_I; e = next; tmp8 = e; if !(tmp8 == nil) { continue L2 }
//line :280:1
									break L2
								}








									if !(loTail == nil) { loTail.Self_HashMap_Node().F_next = nil; newTab.Store(j, loHead) }
									if !(hiTail == nil) {

										hiTail.Self_HashMap_Node().F_next = nil
										newTab.Store(j+oldCap, hiHead)
										j = j + 1; continue L1 } else {
											j = j + 1; continue L1 } } } } else {
												j = j + 1; continue L1 } }
//line :257:1
			break L1 } }
//line :254:1
	return newTab
}












































func (t *HashMap) Impl_TreeifyBin_HashMap_Node1_I__V(this HashMap_I, tab *RefArray, hash int32) {
	var n int32 = 0; var index int32 = 0; var e HashMap_Node_I; var tmp1 bool; var tmp2 bool



	tmp2 = tab == nil; if !tmp2 { var tmp3 int32; n = int32(len(tab.A)); tmp3 = n; tmp2 = tmp3 < 64 }; tmp1 = tmp2
//line :304:1
	if tmp1 {
		this.Resize__HashMap_Node1() } else {
//line :304:1
			var tmp4 HashMap_Node_I; var tmp5 int32

			index = (n - 1) & hash; tmp5 = index; e = As[HashMap_Node_I](tab.A[tmp5]); tmp4 = e
//line :304:1
			if !(tmp4 == nil) {


				var hd *HashMap_TreeNode; var tl *HashMap_TreeNode

			L1: for {
				var p *HashMap_TreeNode = this.ReplacementTreeNode_HashMap_Node_HashMap_Node__HashMap_TreeNode(e, nil)
				if tl == nil { hd = p } else { p.F_prev = tl; tl.F_next = Up_HashMap_TreeNode_HashMap_Node(p) }
				tl = p
				var tmp6 HashMap_Node_I; e = e.Self_HashMap_Node().F_next; tmp6 = e; if !(tmp6 == nil) { continue L1 }
//line :309:1
				break L1
			}



				var tmp7 HashMap_Node_I; var tmp8 HashMap_Node_I = Up_HashMap_TreeNode_HashMap_Node(hd); tab.Store(index, tmp8); tmp7 = tmp8; if !(tmp7 == nil) { NN(hd).Treeify_HashMap_Node1__V(tab)
				} } } }
func (t *HashMap) Impl_PutAll_Map__V(this HashMap_I, m Map) {
	this.PutMapEntries_Map_Z__V(m, true)
}
func (t *HashMap) Impl_Remove_O__O(this HashMap_I, key any) any {
	var e HashMap_Node_I; var tmp1 HashMap_Node_I
	e = this.RemoveNode_I_O_O_Z_Z__HashMap_Node(HashMap_Hash_O__I(key), key, nil, false, true); tmp1 = e; if !(tmp1 == nil) { return e.Self_HashMap_Node().F_value } else { return nil
	} }
func (t *HashMap) Impl_RemoveNode_I_O_O_Z_Z__HashMap_Node(this HashMap_I, hash int32, key, value any, matchValue, movable bool) HashMap_Node_I {

	var tab *RefArray; var p HashMap_Node_I; var n int32 = 0; var index int32 = 0; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *RefArray



	tab = t.F_table; tmp4 = tab; tmp3 = !(tmp4 == nil); if tmp3 { var tmp5 int32; n = int32(len(tab.A)); tmp5 = n; tmp3 = tmp5 > 0 }; tmp2 = tmp3; if tmp2 {
		var tmp6 HashMap_Node_I; var tmp7 *RefArray = tab; var tmp8 int32

		index = (n - 1) & hash; tmp8 = index
//line :330:1
		p = As[HashMap_Node_I](tmp7.A[tmp8]); tmp6 = p; tmp2 = !(tmp6 == nil) }
//line :329:1
	tmp1 = tmp2; if tmp1 {



		var node HashMap_Node_I; var e HashMap_Node_I; var k any; var v any; var tmp9 bool; var tmp10 bool




		tmp10 = p.Self_HashMap_Node().F_hash == hash; if tmp10 {
			var tmp11 bool; var tmp12 any; k = p.Self_HashMap_Node().F_key; tmp12 = k; tmp11 = tmp12 == key; if !tmp11 { var tmp13 bool; tmp13 = !(key == nil); if tmp13 { tmp13 = Equals(key, k) }; tmp11 = tmp13 }; tmp10 = tmp11 }
//line :338:1
		tmp9 = tmp10
//line :337:1
		if tmp9 {


			node = p } else {
//line :337:1
				var tmp14 HashMap_Node_I



				e = p.Self_HashMap_Node().F_next; tmp14 = e
//line :337:1
				if !(tmp14 == nil) {




					if HashMap_TreeNode_InstanceOf(p) {
						node = Up_HashMap_TreeNode_HashMap_Node(NN(HashMap_TreeNode_Cast(p)).GetTreeNode_I_O__HashMap_TreeNode(hash, key)) } else {
						L1: for {
							var tmp15 bool; var tmp16 bool; tmp16 = e.Self_HashMap_Node().F_hash == hash; if tmp16 {
								var tmp17 bool; var tmp18 any; k = e.Self_HashMap_Node().F_key; tmp18 = k; tmp17 = tmp18 == key; if !tmp17 {
									var tmp19 bool; tmp19 = !(key == nil); if tmp19 { tmp19 = Equals(key, k) }; tmp17 = tmp19 }
//line :346:1
								tmp16 = tmp17 }
//line :345:1
							tmp15 = tmp16; if tmp15 {


								node = e
								break L1 }
							p = e
							var tmp20 HashMap_Node_I; e = e.Self_HashMap_Node().F_next; tmp20 = e; if !(tmp20 == nil) { continue L1 }
//line :344:1
							break L1
						}
						}
				}
			}



		var tmp21 bool; var tmp22 bool; tmp22 = !(node == nil); if tmp22 {
			var tmp23 bool; var tmp24 bool; tmp24 = !matchValue; if !tmp24 { var tmp25 any; v = node.Self_HashMap_Node().F_value; tmp25 = v; tmp24 = tmp25 == value }; tmp23 = tmp24; if !tmp23 {
				var tmp26 bool; tmp26 = !(value == nil); if tmp26 { tmp26 = Equals(value, v) }; tmp23 = tmp26 }
//line :353:1
			tmp22 = tmp23 }
//line :352:1
		tmp21 = tmp22; if tmp21 {


			if HashMap_TreeNode_InstanceOf(node) {
				NN(HashMap_TreeNode_Cast(node)).RemoveTreeNode_HashMap_HashMap_Node1_Z__V(this, tab, movable) } else {
//line :355:1
					if node == p {

						tab.Store(index, node.Self_HashMap_Node().F_next) } else {
							p.Self_HashMap_Node().F_next = node.Self_HashMap_Node().F_next } }
			t.F_modCount = t.F_modCount + 1
			t.F_size = t.F_size - 1
			this.AfterNodeRemoval_HashMap_Node__V(node)
			return node } }
//line :325:1
	return nil
}






































func (t *HashMap) Impl_Clear__V(this HashMap_I) {
	var tab *RefArray
	t.F_modCount = t.F_modCount + 1
	var tmp1 bool; var tmp2 bool; var tmp3 *RefArray; tab = t.F_table; tmp3 = tab; tmp2 = !(tmp3 == nil); if tmp2 { tmp2 = t.F_size > 0 }; tmp1 = tmp2; if tmp1 {
		t.F_size = 0
		var i int32 = 0; L1: for { if i < int32(len(tab.A)) { tab.Store(i, nil); i = i + 1; continue L1 }; break L1
		} } }
func (t *HashMap) Impl_ContainsValue_O__Z(this HashMap_I, value any) bool {
	var tab *RefArray; var v any; var tmp1 bool; var tmp2 bool; var tmp3 *RefArray

	tab = t.F_table; tmp3 = tab; tmp2 = !(tmp3 == nil); if tmp2 { tmp2 = t.F_size > 0 }; tmp1 = tmp2; if tmp1 {
		var arr_101856 *RefArray = tab; var len_101857 int32 = int32(len(arr_101856.A)); var i_101858 int32 = 0; for ; i_101858 < len_101857; i_101858++ { var e HashMap_Node_I = As[HashMap_Node_I](arr_101856.A[i_101858])
		L2: for { if !(e == nil) {
			var tmp4 bool; var tmp5 bool; var tmp6 any; v = e.Self_HashMap_Node().F_value; tmp6 = v; tmp5 = tmp6 == value; if !tmp5 { var tmp7 bool; tmp7 = !(value == nil); if tmp7 { tmp7 = Equals(value, v) }; tmp5 = tmp7 }; tmp4 = tmp5; if tmp4 {
				return true }
			e = e.Self_HashMap_Node().F_next
//line :377:1
			continue L2 }; break L2 } } }
//line :373:1
	return false
}








func (t *HashMap) Impl_KeySet__Set(this HashMap_I) Set {
	var ks Set = t.F_keySet
	if ks == nil { ks = HashMap_KeySet_New_HashMap(this); t.F_keySet = ks }
//line :384:1
	return ks
}


func (t *HashMap) Impl_PrepareArray_O1__O1(this HashMap_I, a *RefArray) *RefArray {
	var size int32 = t.F_size
	if int32(len(a.A)) < size {
		return A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass()) } else {
			if int32(len(a.A)) > size { a.Store(size, nil) }; return a
		} }
func (t *HashMap) Impl_KeysToArray_O1__O1(this HashMap_I, a *RefArray) *RefArray {
	var r *RefArray = a; var tab *RefArray; var idx int32 = 0; var tmp1 bool; var tmp2 bool


	tmp2 = t.F_size > 0; if tmp2 { var tmp3 *RefArray; tab = t.F_table; tmp3 = tab; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var arr_101859 *RefArray = tab; var len_101860 int32 = int32(len(arr_101859.A)); var i_101861 int32 = 0; for ; i_101861 < len_101860; i_101861++ { var e HashMap_Node_I = As[HashMap_Node_I](arr_101859.A[i_101861])
		L2: for { if !(e == nil) {
			r.Store(idx, e.Self_HashMap_Node().F_key)
			idx = idx + 1
			e = e.Self_HashMap_Node().F_next
//line :400:1
			continue L2 }; break L2 } } }
//line :395:1
	return a
}









func (t *HashMap) Impl_ValuesToArray_O1__O1(this HashMap_I, a *RefArray) *RefArray {
	var r *RefArray = a; var tab *RefArray; var idx int32 = 0; var tmp1 bool; var tmp2 bool


	tmp2 = t.F_size > 0; if tmp2 { var tmp3 *RefArray; tab = t.F_table; tmp3 = tab; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var arr_101862 *RefArray = tab; var len_101863 int32 = int32(len(arr_101862.A)); var i_101864 int32 = 0; for ; i_101864 < len_101863; i_101864++ { var e HashMap_Node_I = As[HashMap_Node_I](arr_101862.A[i_101864])
		L2: for { if !(e == nil) {
			r.Store(idx, e.Self_HashMap_Node().F_value)
			idx = idx + 1
			e = e.Self_HashMap_Node().F_next
//line :412:1
			continue L2 }; break L2 } } }
//line :407:1
	return a
}












func (t *HashMap_KeySet) Size__I() int32 { return t.F_this_0.Self_HashMap().F_size }

func (t *HashMap_KeySet) Clear__V() { t.F_this_0.Clear__V() }

func (t *HashMap_KeySet) Iterator__Iterator() Iterator {
	return HashMap_KeyIterator_New_HashMap(t.F_this_0)
}
func (t *HashMap_KeySet) Contains_O__Z(o any) bool {
	return t.F_this_0.ContainsKey_O__Z(o)
}
func (t *HashMap_KeySet) Remove_O__Z(key any) bool {
	return !(t.F_this_0.RemoveNode_I_O_O_Z_Z__HashMap_Node(HashMap_Hash_O__I(key), key, nil, false, true) == nil)
}
func (t *HashMap_KeySet) Spliterator__Spliterator() Spliterator {
	return HashMap_KeySpliterator_New_HashMap_I_I_I_I(t.F_this_0, 0, -1, 0, 0)
}
func (t *HashMap_KeySet) ToArray__O1() *RefArray {
	return t.F_this_0.KeysToArray_O1__O1(NewRefArray(Object_class, t.F_this_0.Self_HashMap().F_size))
}
func (t *HashMap_KeySet) ToArray_O1__O1(a *RefArray) *RefArray {
	return t.F_this_0.KeysToArray_O1__O1(t.F_this_0.PrepareArray_O1__O1(a))
}
func (t *HashMap_KeySet) ForEach_Consumer__V(action Consumer) {
	var tab *RefArray
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_this_0.Self_HashMap().F_size > 0; if tmp2 { var tmp3 *RefArray; tab = t.F_this_0.Self_HashMap().F_table; tmp3 = tab; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_this_0.Self_HashMap().F_modCount; var arr_101865 *RefArray = tab; var len_101866 int32 = int32(len(arr_101865.A)); var i_101867 int32 = 0; for ; i_101867 < len_101866; i_101867++ {
			var e HashMap_Node_I = As[HashMap_Node_I](arr_101865.A[i_101867])
		L2: for { if !(e == nil) { action.Accept_O__V(e.Self_HashMap_Node().F_key); e = e.Self_HashMap_Node().F_next; continue L2 }; break L2 } }
		if t.F_this_0.Self_HashMap().F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap) Impl_Values__Collection(this HashMap_I) Collection {
	var vs Collection = t.F_values
	if vs == nil { vs = HashMap_Values_New_HashMap(this); t.F_values = vs }
//line :453:1
	return vs
}





func (t *HashMap_Values) Size__I() int32 { return t.F_this_0.Self_HashMap().F_size }

func (t *HashMap_Values) Clear__V() { t.F_this_0.Clear__V() }

func (t *HashMap_Values) Iterator__Iterator() Iterator {
	return HashMap_ValueIterator_New_HashMap(t.F_this_0)
}
func (t *HashMap_Values) Contains_O__Z(o any) bool {
	return t.F_this_0.ContainsValue_O__Z(o)
}
func (t *HashMap_Values) Spliterator__Spliterator() Spliterator {
	return HashMap_ValueSpliterator_New_HashMap_I_I_I_I(t.F_this_0, 0, -1, 0, 0)
}
func (t *HashMap_Values) ToArray__O1() *RefArray {
	return t.F_this_0.ValuesToArray_O1__O1(NewRefArray(Object_class, t.F_this_0.Self_HashMap().F_size))
}
func (t *HashMap_Values) ToArray_O1__O1(a *RefArray) *RefArray {
	return t.F_this_0.ValuesToArray_O1__O1(t.F_this_0.PrepareArray_O1__O1(a))
}
func (t *HashMap_Values) ForEach_Consumer__V(action Consumer) {
	var tab *RefArray
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_this_0.Self_HashMap().F_size > 0; if tmp2 { var tmp3 *RefArray; tab = t.F_this_0.Self_HashMap().F_table; tmp3 = tab; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_this_0.Self_HashMap().F_modCount; var arr_101868 *RefArray = tab; var len_101869 int32 = int32(len(arr_101868.A)); var i_101870 int32 = 0; for ; i_101870 < len_101869; i_101870++ {
			var e HashMap_Node_I = As[HashMap_Node_I](arr_101868.A[i_101870])
		L2: for { if !(e == nil) { action.Accept_O__V(e.Self_HashMap_Node().F_value); e = e.Self_HashMap_Node().F_next; continue L2 }; break L2 } }
		if t.F_this_0.Self_HashMap().F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap) Impl_EntrySet__Set(this HashMap_I) Set {
	var es Set; var tmp1 Set
	es = t.F_entrySet; tmp1 = es; if tmp1 == nil { var tmp2 Set = HashMap_EntrySet_New_HashMap(this); t.F_entrySet = tmp2; return tmp2 } else { return es
	}
}


func (t *HashMap_EntrySet) Size__I() int32 { return t.F_this_0.Self_HashMap().F_size }

func (t *HashMap_EntrySet) Clear__V() { t.F_this_0.Clear__V() }

func (t *HashMap_EntrySet) Iterator__Iterator() Iterator {
	return HashMap_EntryIterator_New_HashMap(t.F_this_0)
}
func (t *HashMap_EntrySet) Contains_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var key any = e.GetKey__O(); var candidate HashMap_Node_I = t.F_this_0.GetNode_O__HashMap_Node(key); var tmp2 bool


		tmp2 = !(candidate == nil); if tmp2 { tmp2 = candidate.Equals_O__Z(e) }; return tmp2 } else {
//line :503:1
			return false
		}
}



func (t *HashMap_EntrySet) Remove_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var key any = e.GetKey__O(); var value any = e.GetValue__O()


		return !(t.F_this_0.RemoveNode_I_O_O_Z_Z__HashMap_Node(HashMap_Hash_O__I(key), key, value, true, true) == nil) } else {
//line :510:1
			return false
		}
}



func (t *HashMap_EntrySet) Spliterator__Spliterator() Spliterator {
	return HashMap_EntrySpliterator_New_HashMap_I_I_I_I(t.F_this_0, 0, -1, 0, 0)
}
func (t *HashMap_EntrySet) ForEach_Consumer__V(action Consumer) {
	var tab *RefArray
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_this_0.Self_HashMap().F_size > 0; if tmp2 { var tmp3 *RefArray; tab = t.F_this_0.Self_HashMap().F_table; tmp3 = tab; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_this_0.Self_HashMap().F_modCount; var arr_101873 *RefArray = tab; var len_101874 int32 = int32(len(arr_101873.A)); var i_101875 int32 = 0; for ; i_101875 < len_101874; i_101875++ {
			var e HashMap_Node_I = As[HashMap_Node_I](arr_101873.A[i_101875])
		L2: for { if !(e == nil) { action.Accept_O__V(e); e = e.Self_HashMap_Node().F_next; continue L2 }; break L2 } }
		if t.F_this_0.Self_HashMap().F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap) Impl_GetOrDefault_O_O__O(this HashMap_I, key, defaultValue any) any {
	var e HashMap_Node_I; var tmp1 HashMap_Node_I
	e = this.GetNode_O__HashMap_Node(key); tmp1 = e; if tmp1 == nil { return defaultValue } else { return e.Self_HashMap_Node().F_value
	} }
func (t *HashMap) Impl_PutIfAbsent_O_O__O(this HashMap_I, key, value any) any {
	return this.PutVal_I_O_O_Z_Z__O(HashMap_Hash_O__I(key), key, value, true, true)
}
func (t *HashMap) Impl_Remove_O_O__Z(this HashMap_I, key, value any) bool {
	return !(this.RemoveNode_I_O_O_Z_Z__HashMap_Node(HashMap_Hash_O__I(key), key, value, true, true) == nil)
}
func (t *HashMap) Impl_Replace_O_O_O__Z(this HashMap_I, key, oldValue, newValue any) bool {
	var e HashMap_Node_I; var v any; var tmp1 bool; var tmp2 bool; var tmp3 HashMap_Node_I

	e = this.GetNode_O__HashMap_Node(key); tmp3 = e; tmp2 = !(tmp3 == nil); if tmp2 {
		var tmp4 bool; var tmp5 any; v = e.Self_HashMap_Node().F_value; tmp5 = v; tmp4 = tmp5 == oldValue; if !tmp4 { var tmp6 bool; tmp6 = !(v == nil); if tmp6 { tmp6 = Equals(v, oldValue) }; tmp4 = tmp6 }; tmp2 = tmp4 }
//line :541:1
	tmp1 = tmp2; if tmp1 {

		e.Self_HashMap_Node().F_value = newValue; this.AfterNodeAccess_HashMap_Node__V(e); return true } else {
//line :541:1
			return false
		}
}


func (t *HashMap) Impl_Replace_O_O__O(this HashMap_I, key, value any) any {
	var e HashMap_Node_I; var tmp1 HashMap_Node_I
	e = this.GetNode_O__HashMap_Node(key); tmp1 = e; if !(tmp1 == nil) {
		var oldValue any = e.Self_HashMap_Node().F_value; e.Self_HashMap_Node().F_value = value; this.AfterNodeAccess_HashMap_Node__V(e); return oldValue } else {
//line :548:1
			return nil
		}
}
func (t *HashMap) Impl_ComputeIfAbsent_O_Function__O(this HashMap_I, key any, mappingFunction Function) any {

	if mappingFunction == nil { panic(Thrown(NullPointerException_New())) }
	var hash int32 = HashMap_Hash_O__I(key); var tab *RefArray; var first HashMap_Node_I; var n int32 = 0; var i int32 = 0; var binCount int32 = 0; var t_ *HashMap_TreeNode; var old HashMap_Node_I; var tmp1 bool; var tmp2 bool; var tmp3 bool







	tmp3 = t.F_size > t.F_threshold; if !tmp3 { var tmp4 *RefArray; tab = t.F_table; tmp4 = tab; tmp3 = tmp4 == nil }; tmp2 = tmp3; if !tmp2 { var tmp5 int32; n = int32(len(tab.A)); tmp5 = n; tmp2 = tmp5 == 0 }; tmp1 = tmp2; if tmp1 {
		var tmp6 *RefArray; tab = this.Resize__HashMap_Node1(); tmp6 = tab; n = int32(len(tmp6.A)) }
	var tmp7 HashMap_Node_I; var tmp8 *RefArray = tab; var tmp9 int32; i = (n - 1) & hash; tmp9 = i; first = As[HashMap_Node_I](tmp8.A[tmp9]); tmp7 = first; if !(tmp7 == nil) {
		if HashMap_TreeNode_InstanceOf(first) {
			var tmp10 *HashMap_TreeNode; t_ = HashMap_TreeNode_Cast(first); tmp10 = t_; old = Up_HashMap_TreeNode_HashMap_Node(NN(tmp10).GetTreeNode_I_O__HashMap_TreeNode(hash, key)) } else {
				var e HashMap_Node_I = first; var k any

			L1: for {
				var tmp11 bool; var tmp12 bool; tmp12 = e.Self_HashMap_Node().F_hash == hash; if tmp12 {
					var tmp13 bool; var tmp14 any; k = e.Self_HashMap_Node().F_key; tmp14 = k; tmp13 = tmp14 == key; if !tmp13 {
						var tmp15 bool; tmp15 = !(key == nil); if tmp15 { tmp15 = Equals(key, k) }; tmp13 = tmp15 }
//line :571:1
					tmp12 = tmp13 }
//line :570:1
				tmp11 = tmp12; if tmp11 {


					old = e
					break L1 }
				binCount = binCount + 1
				var tmp16 HashMap_Node_I; e = e.Self_HashMap_Node().F_next; tmp16 = e; if !(tmp16 == nil) { continue L1 }
//line :569:1
				break L1
			}
			}





		var oldValue any; var tmp17 bool; var tmp18 bool
		tmp18 = !(old == nil); if tmp18 { var tmp19 any; oldValue = old.Self_HashMap_Node().F_value; tmp19 = oldValue; tmp18 = !(tmp19 == nil) }; tmp17 = tmp18; if tmp17 {
			this.AfterNodeAccess_HashMap_Node__V(old)
			return oldValue } }
	var mc int32 = t.F_modCount; var v any = mappingFunction.Apply_O__O(key)

	if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	if !(v == nil) {
		if !(old == nil) {
			old.Self_HashMap_Node().F_value = v; this.AfterNodeAccess_HashMap_Node__V(old); return v } else {

				if !(t_ == nil) {
					NN(t_).PutTreeVal_HashMap_HashMap_Node1_I_O_O__HashMap_TreeNode(this, tab, hash, key, v) } else {

						tab.Store(i, this.NewNode_I_O_O_HashMap_Node__HashMap_Node(hash, key, v, first))
						if binCount >= 7 {
							this.TreeifyBin_HashMap_Node1_I__V(tab, hash) } }
				t.F_modCount = mc + 1
				t.F_size = t.F_size + 1
				this.AfterNodeInsertion_Z__V(true)
//line :587:1
				return v
			}






	} else {
//line :584:1
		return nil
	}
}












func (t *HashMap) Impl_ComputeIfPresent_O_BiFunction__O(this HashMap_I, key any, remappingFunction BiFunction) any {

	if remappingFunction == nil { panic(Thrown(NullPointerException_New())) }
	var e HashMap_Node_I; var oldValue any; var tmp1 bool; var tmp2 bool; var tmp3 HashMap_Node_I

	e = this.GetNode_O__HashMap_Node(key); tmp3 = e; tmp2 = !(tmp3 == nil); if tmp2 { var tmp4 any; oldValue = e.Self_HashMap_Node().F_value; tmp4 = oldValue; tmp2 = !(tmp4 == nil) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_modCount; var v any = remappingFunction.Apply_O_O__O(key, oldValue)

		if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
		if !(v == nil) {
			e.Self_HashMap_Node().F_value = v; this.AfterNodeAccess_HashMap_Node__V(e); return v } else {
				var hash int32 = HashMap_Hash_O__I(key); this.RemoveNode_I_O_O_Z_Z__HashMap_Node(hash, key, nil, false, true) } }
//line :602:1
	return nil
}









func (t *HashMap) Impl_Compute_O_BiFunction__O(this HashMap_I, key any, remappingFunction BiFunction) any {

	if remappingFunction == nil { panic(Thrown(NullPointerException_New())) }
	var hash int32 = HashMap_Hash_O__I(key); var tab *RefArray; var first HashMap_Node_I; var n int32 = 0; var i int32 = 0; var binCount int32 = 0; var t_ *HashMap_TreeNode; var old HashMap_Node_I; var tmp1 bool; var tmp2 bool; var tmp3 bool







	tmp3 = t.F_size > t.F_threshold; if !tmp3 { var tmp4 *RefArray; tab = t.F_table; tmp4 = tab; tmp3 = tmp4 == nil }; tmp2 = tmp3; if !tmp2 { var tmp5 int32; n = int32(len(tab.A)); tmp5 = n; tmp2 = tmp5 == 0 }; tmp1 = tmp2; if tmp1 {
		var tmp6 *RefArray; tab = this.Resize__HashMap_Node1(); tmp6 = tab; n = int32(len(tmp6.A)) }
	var tmp7 HashMap_Node_I; var tmp8 *RefArray = tab; var tmp9 int32; i = (n - 1) & hash; tmp9 = i; first = As[HashMap_Node_I](tmp8.A[tmp9]); tmp7 = first; if !(tmp7 == nil) {
		if HashMap_TreeNode_InstanceOf(first) {
			var tmp10 *HashMap_TreeNode; t_ = HashMap_TreeNode_Cast(first); tmp10 = t_; old = Up_HashMap_TreeNode_HashMap_Node(NN(tmp10).GetTreeNode_I_O__HashMap_TreeNode(hash, key)) } else {
				var e HashMap_Node_I = first; var k any

			L1: for {
				var tmp11 bool; var tmp12 bool; tmp12 = e.Self_HashMap_Node().F_hash == hash; if tmp12 {
					var tmp13 bool; var tmp14 any; k = e.Self_HashMap_Node().F_key; tmp14 = k; tmp13 = tmp14 == key; if !tmp13 {
						var tmp15 bool; tmp15 = !(key == nil); if tmp15 { tmp15 = Equals(key, k) }; tmp13 = tmp15 }
//line :633:1
					tmp12 = tmp13 }
//line :632:1
				tmp11 = tmp12; if tmp11 {


					old = e
					break L1 }
				binCount = binCount + 1
				var tmp16 HashMap_Node_I; e = e.Self_HashMap_Node().F_next; tmp16 = e; if !(tmp16 == nil) { continue L1 }
//line :631:1
				break L1
			}
			}
	}




	var oldValue any; if !(old == nil) { oldValue = old.Self_HashMap_Node().F_value } else { oldValue = nil }; var mc int32 = t.F_modCount; var v any = remappingFunction.Apply_O_O__O(key, oldValue)


	if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	if !(old == nil) {
		if !(v == nil) {
			old.Self_HashMap_Node().F_value = v; this.AfterNodeAccess_HashMap_Node__V(old) } else {
				this.RemoveNode_I_O_O_Z_Z__HashMap_Node(hash, key, nil, false, true) } } else {
					if !(v == nil) {
						if !(t_ == nil) {
							NN(t_).PutTreeVal_HashMap_HashMap_Node1_I_O_O__HashMap_TreeNode(this, tab, hash, key, v) } else {

								tab.Store(i, this.NewNode_I_O_O_HashMap_Node__HashMap_Node(hash, key, v, first))
								if binCount >= 7 {
									this.TreeifyBin_HashMap_Node1_I__V(tab, hash) } }
						t.F_modCount = mc + 1
						t.F_size = t.F_size + 1
						this.AfterNodeInsertion_Z__V(true) } }
//line :639:1
	return v
}


















func (t *HashMap) Impl_Merge_O_O_BiFunction__O(this HashMap_I, key, value any, remappingFunction BiFunction) any {

	var tmp1 bool; var tmp2 bool; tmp2 = value == nil; if !tmp2 { tmp2 = remappingFunction == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	var hash int32 = HashMap_Hash_O__I(key); var tab *RefArray; var first HashMap_Node_I; var n int32 = 0; var i int32 = 0; var binCount int32 = 0; var t_ *HashMap_TreeNode; var old HashMap_Node_I; var tmp3 bool; var tmp4 bool; var tmp5 bool







	tmp5 = t.F_size > t.F_threshold; if !tmp5 { var tmp6 *RefArray; tab = t.F_table; tmp6 = tab; tmp5 = tmp6 == nil }; tmp4 = tmp5; if !tmp4 { var tmp7 int32; n = int32(len(tab.A)); tmp7 = n; tmp4 = tmp7 == 0 }; tmp3 = tmp4; if tmp3 {
		var tmp8 *RefArray; tab = this.Resize__HashMap_Node1(); tmp8 = tab; n = int32(len(tmp8.A)) }
	var tmp9 HashMap_Node_I; var tmp10 *RefArray = tab; var tmp11 int32; i = (n - 1) & hash; tmp11 = i; first = As[HashMap_Node_I](tmp10.A[tmp11]); tmp9 = first; if !(tmp9 == nil) {
		if HashMap_TreeNode_InstanceOf(first) {
			var tmp12 *HashMap_TreeNode; t_ = HashMap_TreeNode_Cast(first); tmp12 = t_; old = Up_HashMap_TreeNode_HashMap_Node(NN(tmp12).GetTreeNode_I_O__HashMap_TreeNode(hash, key)) } else {
				var e HashMap_Node_I = first; var k any

			L1: for {
				var tmp13 bool; var tmp14 bool; tmp14 = e.Self_HashMap_Node().F_hash == hash; if tmp14 {
					var tmp15 bool; var tmp16 any; k = e.Self_HashMap_Node().F_key; tmp16 = k; tmp15 = tmp16 == key; if !tmp15 {
						var tmp17 bool; tmp17 = !(key == nil); if tmp17 { tmp17 = Equals(key, k) }; tmp15 = tmp17 }
//line :679:1
					tmp14 = tmp15 }
//line :678:1
				tmp13 = tmp14; if tmp13 {


					old = e
					break L1 }
				binCount = binCount + 1
				var tmp18 HashMap_Node_I; e = e.Self_HashMap_Node().F_next; tmp18 = e; if !(tmp18 == nil) { continue L1 }
//line :677:1
				break L1
			}
			}
	}




	if !(old == nil) {
		var v any
		if !(old.Self_HashMap_Node().F_value == nil) {
			var mc int32 = t.F_modCount
			v = remappingFunction.Apply_O_O__O(old.Self_HashMap_Node().F_value, value)
			if mc == t.F_modCount { } else { panic(Thrown(ConcurrentModificationException_New())) } } else {
				v = value }
		if !(v == nil) {
			old.Self_HashMap_Node().F_value = v; this.AfterNodeAccess_HashMap_Node__V(old) } else {
				this.RemoveNode_I_O_O_Z_Z__HashMap_Node(hash, key, nil, false, true) }
//line :686:1
		return v






	} else {



		if !(t_ == nil) {
			NN(t_).PutTreeVal_HashMap_HashMap_Node1_I_O_O__HashMap_TreeNode(this, tab, hash, key, value) } else {

				tab.Store(i, this.NewNode_I_O_O_HashMap_Node__HashMap_Node(hash, key, value, first))
				if binCount >= 7 {
					this.TreeifyBin_HashMap_Node1_I__V(tab, hash) } }
		t.F_modCount = t.F_modCount + 1
		t.F_size = t.F_size + 1
		this.AfterNodeInsertion_Z__V(true)
//line :696:1
		return value
	}
}









func (t *HashMap) Impl_ForEach_BiConsumer__V(this HashMap_I, action BiConsumer) {
	var tab *RefArray
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_size > 0; if tmp2 { var tmp3 *RefArray; tab = t.F_table; tmp3 = tab; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_modCount; var arr_101876 *RefArray = tab; var len_101877 int32 = int32(len(arr_101876.A)); var i_101878 int32 = 0; for ; i_101878 < len_101877; i_101878++ {
			var e HashMap_Node_I = As[HashMap_Node_I](arr_101876.A[i_101878])
		L2: for { if !(e == nil) { var tmp4 any = e.Self_HashMap_Node().F_key; action.Accept_O_O__V(tmp4, e.Self_HashMap_Node().F_value); e = e.Self_HashMap_Node().F_next; continue L2 }; break L2 } }
		if t.F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap) Impl_ReplaceAll_BiFunction__V(this HashMap_I, function BiFunction) {

	var tab *RefArray
	if function == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_size > 0; if tmp2 { var tmp3 *RefArray; tab = t.F_table; tmp3 = tab; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var mc int32 = t.F_modCount; var arr_101879 *RefArray = tab; var len_101880 int32 = int32(len(arr_101879.A)); var i_101881 int32 = 0; for ; i_101881 < len_101880; i_101881++ {
			var e HashMap_Node_I = As[HashMap_Node_I](arr_101879.A[i_101881])
		L2: for { if !(e == nil) {
			var tmp4 any = e.Self_HashMap_Node().F_key; e.Self_HashMap_Node().F_value = function.Apply_O_O__O(tmp4, e.Self_HashMap_Node().F_value)
			e = e.Self_HashMap_Node().F_next
//line :724:1
			continue L2 }; break L2
		}
		}
		if t.F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap) Impl_Clone__O(this HashMap_I) any {
	var result HashMap_I; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		result = HashMap_Cast(t.AbstractMap.Impl_Clone__O(this)); return nil }()
//line :731:1
	if tmp1 != nil { if CloneNotSupportedException_InstanceOf(tmp1) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp1)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :731:1
			panic(tmp1)
		}
	}
	result.Reinitialize__V()
	result.PutMapEntries_Map_Z__V(this, false)
//line :730:1
	return result
}






func (t *HashMap) Impl_LoadFactor__F(this HashMap_I) float32 { panic(A2g_NotTranslated("java.util.HashMap.loadFactor()F")) }

func (t *HashMap) Impl_Capacity__I(this HashMap_I) int32 { panic(A2g_NotTranslated("java.util.HashMap.capacity()I")) }













































func HashMap_UnsafeHolder_New() *HashMap_UnsafeHolder { HashMap_UnsafeHolder_Init(); t := &HashMap_UnsafeHolder{}; t.Ctor(); return t }
//line :786:1
func (t *HashMap_UnsafeHolder) Ctor() { panic(A2g_NotTranslated("java.util.HashMap$UnsafeHolder.<init>()V")) }






func HashMap_UnsafeHolder_PutLoadFactor_HashMap_F__V(p0 HashMap_I, p1 float32) { HashMap_UnsafeHolder_Init(); panic(A2g_NotTranslated("java.util.HashMap$UnsafeHolder.putLoadFactor(Ljava/util/HashMap;F)V")) }











func (t *HashMap_HashIterator) Ctor_HashMap(this HashMap_HashIterator_I, this_0 HashMap_I) { A2g_NotNull[HashMap_I](this_0); t.F_this_0 = this_0
	t.F_expectedModCount = this_0.Self_HashMap().F_modCount
	var t_ *RefArray = this_0.Self_HashMap().F_table; var tmp1 HashMap_Node_I; var tmp2 HashMap_Node_I
	t.F_next = tmp2; tmp1 = tmp2; t.F_current = tmp1
	t.F_index = 0
	var tmp3 bool; var tmp4 bool; tmp4 = !(t_ == nil); if tmp4 { tmp4 = this_0.Self_HashMap().F_size > 0 }; tmp3 = tmp4; if tmp3 {
	L1: for {
		var tmp5 bool; var tmp6 bool; var tmp7 int32 = t.F_index; tmp6 = tmp7 < int32(len(t_.A)); if tmp6 {
			var tmp8 HashMap_Node_I; var tmp9 int32; var old_1 int32 = t.F_index


			t.F_index = t.F_index + 1
//line :815:1
			tmp9 = old_1
//line :813:1
			var tmp10 HashMap_Node_I = As[HashMap_Node_I](t_.A[tmp9]); t.F_next = tmp10; tmp8 = tmp10; tmp6 = tmp8 == nil }
//line :812:1
		tmp5 = tmp6; if tmp5 {





			continue L1 }
//line :811:1
		break L1
	}
	}
}





func (t *HashMap_HashIterator) Impl_HasNext__Z(this HashMap_HashIterator_I) bool { return !(t.F_next == nil) }

func (t *HashMap_HashIterator) Impl_NextNode__HashMap_Node(this HashMap_HashIterator_I) HashMap_Node_I {
	var t_ *RefArray; var e HashMap_Node_I = t.F_next

	if t.F_this_0.Self_HashMap().F_modCount == t.F_expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	if e == nil { panic(Thrown(NoSuchElementException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 HashMap_Node_I; var tmp4 HashMap_Node_I; var tmp5 HashMap_Node_I = e; t.F_current = tmp5; tmp4 = tmp5; var tmp6 HashMap_Node_I = tmp4.Self_HashMap_Node().F_next; t.F_next = tmp6; tmp3 = tmp6; tmp2 = tmp3 == nil; if tmp2 { var tmp7 *RefArray; t_ = t.F_this_0.Self_HashMap().F_table; tmp7 = t_; tmp2 = !(tmp7 == nil) }; tmp1 = tmp2; if tmp1 {
	L1: for {
		var tmp8 bool; var tmp9 bool; var tmp10 int32 = t.F_index; tmp9 = tmp10 < int32(len(t_.A)); if tmp9 {
			var tmp11 HashMap_Node_I; var tmp12 *RefArray = t_; var tmp13 int32; var old_2 int32 = t.F_index


			t.F_index = t.F_index + 1
//line :832:1
			tmp13 = old_2
//line :830:1
			var tmp14 HashMap_Node_I = As[HashMap_Node_I](tmp12.A[tmp13]); t.F_next = tmp14; tmp11 = tmp14; tmp9 = tmp11 == nil }
//line :829:1
		tmp8 = tmp9; if tmp8 {





			continue L1 }
//line :828:1
		break L1 } }
//line :823:1
	return e
}













func (t *HashMap_HashIterator) Impl_Remove__V(this HashMap_HashIterator_I) {
	var p HashMap_Node_I = t.F_current
	if p == nil { panic(Thrown(IllegalStateException_New())) }
	if t.F_this_0.Self_HashMap().F_modCount == t.F_expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	t.F_current = nil
	var tmp1 int32 = p.Self_HashMap_Node().F_hash; t.F_this_0.RemoveNode_I_O_O_Z_Z__HashMap_Node(tmp1, p.Self_HashMap_Node().F_key, nil, false, false)
	t.F_expectedModCount = t.F_this_0.Self_HashMap().F_modCount
}




func (t *HashMap_KeyIterator) Next__O() any { return t.NextNode__HashMap_Node().Self_HashMap_Node().F_key }





func (t *HashMap_ValueIterator) Next__O() any { return t.NextNode__HashMap_Node().Self_HashMap_Node().F_value }





func (t *HashMap_EntryIterator) Next__Map_Entry() Map_Entry {
	return t.NextNode__HashMap_Node()
}















func HashMap_HashMapSpliterator_New_HashMap_I_I_I_I(p0 HashMap_I, p1, p2, p3, p4 int32) *HashMap_HashMapSpliterator { t := &HashMap_HashMapSpliterator{}; t.Ctor_HashMap_I_I_I_I(t, p0, p1, p2, p3, p4); return t }
//line :880:1
func (t *HashMap_HashMapSpliterator) Ctor_HashMap_I_I_I_I(this HashMap_HashMapSpliterator_I, m HashMap_I, origin, fence, est, expectedModCount int32) {
	t.F_map = m
	t.F_index = origin
	t.F_fence = fence
	t.F_est = est
	t.F_expectedModCount = expectedModCount
}
func (t *HashMap_HashMapSpliterator) Impl_GetFence__I(this HashMap_HashMapSpliterator_I) int32 {
	var hi int32 = 0; var tmp1 int32
	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {
		var m HashMap_I = t.F_map
		t.F_est = m.Self_HashMap().F_size
		t.F_expectedModCount = m.Self_HashMap().F_modCount
		var tab *RefArray = m.Self_HashMap().F_table; var tmp2 int32; var tmp3 int32
		if tab == nil { tmp3 = 0 } else { tmp3 = int32(len(tab.A)) }; var tmp4 int32 = tmp3; t.F_fence = tmp4; tmp2 = tmp4; hi = tmp2 }
//line :888:1
	return hi
}







func (t *HashMap_HashMapSpliterator) Impl_EstimateSize__J(this HashMap_HashMapSpliterator_I) int64 {
	this.GetFence__I()
	return int64(t.F_est)
}





func HashMap_KeySpliterator_New_HashMap_I_I_I_I(p0 HashMap_I, p1, p2, p3, p4 int32) *HashMap_KeySpliterator { t := &HashMap_KeySpliterator{}; t.Ctor_HashMap_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :906:1
func (t *HashMap_KeySpliterator) Ctor_HashMap_I_I_I_I(m HashMap_I, origin, fence, est, expectedModCount int32) { t.HashMap_HashMapSpliterator.Ctor_HashMap_I_I_I_I(t, m, origin, fence, est, expectedModCount) }


func (t *HashMap_KeySpliterator) TrySplit__HashMap_KeySpliterator() *HashMap_KeySpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi) >> 1); var tmp1 bool; var tmp2 bool


	tmp2 = lo >= mid; if !tmp2 { tmp2 = !(t.F_current == nil) }; tmp1 = tmp2; if tmp1 { return nil } else {
		var tmp3 HashMap_I = t.F_map; var tmp4 int32
		var tmp5 int32 = mid
		t.F_index = tmp5; tmp4 = tmp5
//line :914:1
		var tmp6 int32 = tmp4; var tmp7 int32; var tmp8 int32 = int32(uint32(t.F_est) >> 1)


		t.F_est = tmp8; tmp7 = tmp8
//line :914:1
		return HashMap_KeySpliterator_New_HashMap_I_I_I_I(tmp3, lo, tmp6, tmp7, t.F_expectedModCount)
	}
}



func (t *HashMap_KeySpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	var i int32 = 0
	var hi int32 = 0
	var mc int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var m HashMap_I = t.F_map; var tab *RefArray = m.Self_HashMap().F_table; var tmp1 int32

	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {

		var tmp2 int32; var tmp3 int32 = m.Self_HashMap().F_modCount; t.F_expectedModCount = tmp3; tmp2 = tmp3; mc = tmp2
		var tmp4 int32; var tmp5 int32; if tab == nil { tmp5 = 0 } else { tmp5 = int32(len(tab.A)) }; var tmp6 int32 = tmp5; t.F_fence = tmp6; tmp4 = tmp6; hi = tmp4 } else {
			mc = t.F_expectedModCount }
	var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = !(tab == nil); if tmp10 { tmp10 = int32(len(tab.A)) >= hi }; tmp9 = tmp10; if tmp9 { var tmp11 int32; i = t.F_index; tmp11 = i; tmp9 = tmp11 >= 0 }; tmp8 = tmp9; if tmp8 {
		var tmp12 bool; var tmp13 int32 = i; var tmp14 int32; var tmp15 int32 = hi; t.F_index = tmp15; tmp14 = tmp15; tmp12 = tmp13 < tmp14; if !tmp12 { tmp12 = !(t.F_current == nil) }; tmp8 = tmp12 }
//line :932:1
	tmp7 = tmp8; if tmp7 {

		var p HashMap_Node_I = t.F_current
		t.F_current = nil
	L1: for {
		if p == nil {
			p = As[HashMap_Node_I](tab.A[i]); i = i + 1 } else {
				action.Accept_O__V(p.Self_HashMap_Node().F_key); p = p.Self_HashMap_Node().F_next }
		var tmp16 bool; var tmp17 bool; tmp17 = !(p == nil); if !tmp17 { tmp17 = i < hi }; tmp16 = tmp17; if tmp16 { continue L1 }
//line :936:1
		break L1
	}



		if m.Self_HashMap().F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap_KeySpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	var hi int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tab *RefArray = t.F_map.Self_HashMap().F_table; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = !(tab == nil); if tmp3 { var tmp4 int32 = int32(len(tab.A)); var tmp5 int32; hi = t.GetFence__I(); tmp5 = hi; tmp3 = tmp4 >= tmp5 }; tmp2 = tmp3; if tmp2 {
		tmp2 = t.F_index >= 0 }
//line :947:1
	tmp1 = tmp2; if tmp1 {

	L1: for { var tmp6 bool; var tmp7 bool; tmp7 = !(t.F_current == nil); if !tmp7 { tmp7 = t.F_index < hi }; tmp6 = tmp7; if tmp6 {
		if t.F_current == nil {
			var tmp8 int32; var old_3 int32 = t.F_index


			t.F_index = t.F_index + 1
//line :953:1
			tmp8 = old_3
//line :951:1
			t.F_current = As[HashMap_Node_I](tab.A[tmp8]) } else {




				var k any = t.F_current.Self_HashMap_Node().F_key
				t.F_current = t.F_current.Self_HashMap_Node().F_next
				action.Accept_O__V(k)
				if t.F_map.Self_HashMap().F_modCount == t.F_expectedModCount { } else {
					panic(Thrown(ConcurrentModificationException_New())) }
				return true }
//line :949:1
		continue L1 }; break L1 } }
//line :946:1
	return false
}
















func (t *HashMap_KeySpliterator) Characteristics__I() int32 {
	var tmp1 int32; var tmp2 bool; var tmp3 bool; tmp3 = t.F_fence < 0; if !tmp3 { var tmp4 int32 = t.F_est; tmp3 = tmp4 == t.F_map.Self_HashMap().F_size }; tmp2 = tmp3; if tmp2 { tmp1 = 64 } else { tmp1 = 0 }; return tmp1 | 1
}








func HashMap_ValueSpliterator_New_HashMap_I_I_I_I(p0 HashMap_I, p1, p2, p3, p4 int32) *HashMap_ValueSpliterator { t := &HashMap_ValueSpliterator{}; t.Ctor_HashMap_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :975:1
func (t *HashMap_ValueSpliterator) Ctor_HashMap_I_I_I_I(m HashMap_I, origin, fence, est, expectedModCount int32) { t.HashMap_HashMapSpliterator.Ctor_HashMap_I_I_I_I(t, m, origin, fence, est, expectedModCount) }


func (t *HashMap_ValueSpliterator) TrySplit__HashMap_ValueSpliterator() *HashMap_ValueSpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi) >> 1); var tmp1 bool; var tmp2 bool


	tmp2 = lo >= mid; if !tmp2 { tmp2 = !(t.F_current == nil) }; tmp1 = tmp2; if tmp1 { return nil } else {
		var tmp3 HashMap_I = t.F_map; var tmp4 int32
		var tmp5 int32 = mid
		t.F_index = tmp5; tmp4 = tmp5
//line :983:1
		var tmp6 int32 = tmp4; var tmp7 int32; var tmp8 int32 = int32(uint32(t.F_est) >> 1)


		t.F_est = tmp8; tmp7 = tmp8
//line :983:1
		return HashMap_ValueSpliterator_New_HashMap_I_I_I_I(tmp3, lo, tmp6, tmp7, t.F_expectedModCount)
	}
}



func (t *HashMap_ValueSpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	var i int32 = 0
	var hi int32 = 0
	var mc int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var m HashMap_I = t.F_map; var tab *RefArray = m.Self_HashMap().F_table; var tmp1 int32

	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {

		var tmp2 int32; var tmp3 int32 = m.Self_HashMap().F_modCount; t.F_expectedModCount = tmp3; tmp2 = tmp3; mc = tmp2
		var tmp4 int32; var tmp5 int32; if tab == nil { tmp5 = 0 } else { tmp5 = int32(len(tab.A)) }; var tmp6 int32 = tmp5; t.F_fence = tmp6; tmp4 = tmp6; hi = tmp4 } else {
			mc = t.F_expectedModCount }
	var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = !(tab == nil); if tmp10 { tmp10 = int32(len(tab.A)) >= hi }; tmp9 = tmp10; if tmp9 { var tmp11 int32; i = t.F_index; tmp11 = i; tmp9 = tmp11 >= 0 }; tmp8 = tmp9; if tmp8 {
		var tmp12 bool; var tmp13 int32 = i; var tmp14 int32; var tmp15 int32 = hi; t.F_index = tmp15; tmp14 = tmp15; tmp12 = tmp13 < tmp14; if !tmp12 { tmp12 = !(t.F_current == nil) }; tmp8 = tmp12 }
//line :1001:1
	tmp7 = tmp8; if tmp7 {

		var p HashMap_Node_I = t.F_current
		t.F_current = nil
	L1: for {
		if p == nil {
			p = As[HashMap_Node_I](tab.A[i]); i = i + 1 } else {
				action.Accept_O__V(p.Self_HashMap_Node().F_value); p = p.Self_HashMap_Node().F_next }
		var tmp16 bool; var tmp17 bool; tmp17 = !(p == nil); if !tmp17 { tmp17 = i < hi }; tmp16 = tmp17; if tmp16 { continue L1 }
//line :1005:1
		break L1
	}



		if m.Self_HashMap().F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap_ValueSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	var hi int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tab *RefArray = t.F_map.Self_HashMap().F_table; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = !(tab == nil); if tmp3 { var tmp4 int32 = int32(len(tab.A)); var tmp5 int32; hi = t.GetFence__I(); tmp5 = hi; tmp3 = tmp4 >= tmp5 }; tmp2 = tmp3; if tmp2 {
		tmp2 = t.F_index >= 0 }
//line :1016:1
	tmp1 = tmp2; if tmp1 {

	L1: for { var tmp6 bool; var tmp7 bool; tmp7 = !(t.F_current == nil); if !tmp7 { tmp7 = t.F_index < hi }; tmp6 = tmp7; if tmp6 {
		if t.F_current == nil {
			var tmp8 int32; var old_4 int32 = t.F_index


			t.F_index = t.F_index + 1
//line :1022:1
			tmp8 = old_4
//line :1020:1
			t.F_current = As[HashMap_Node_I](tab.A[tmp8]) } else {




				var v any = t.F_current.Self_HashMap_Node().F_value
				t.F_current = t.F_current.Self_HashMap_Node().F_next
				action.Accept_O__V(v)
				if t.F_map.Self_HashMap().F_modCount == t.F_expectedModCount { } else {
					panic(Thrown(ConcurrentModificationException_New())) }
				return true }
//line :1018:1
		continue L1 }; break L1 } }
//line :1015:1
	return false
}
















func (t *HashMap_ValueSpliterator) Characteristics__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_fence < 0; if !tmp2 { var tmp3 int32 = t.F_est; tmp2 = tmp3 == t.F_map.Self_HashMap().F_size }; tmp1 = tmp2; if tmp1 { return 64 } else { return 0
	}
}




func HashMap_EntrySpliterator_New_HashMap_I_I_I_I(p0 HashMap_I, p1, p2, p3, p4 int32) *HashMap_EntrySpliterator { t := &HashMap_EntrySpliterator{}; t.Ctor_HashMap_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :1041:1
func (t *HashMap_EntrySpliterator) Ctor_HashMap_I_I_I_I(m HashMap_I, origin, fence, est, expectedModCount int32) { t.HashMap_HashMapSpliterator.Ctor_HashMap_I_I_I_I(t, m, origin, fence, est, expectedModCount) }


func (t *HashMap_EntrySpliterator) TrySplit__HashMap_EntrySpliterator() *HashMap_EntrySpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi) >> 1); var tmp1 bool; var tmp2 bool


	tmp2 = lo >= mid; if !tmp2 { tmp2 = !(t.F_current == nil) }; tmp1 = tmp2; if tmp1 { return nil } else {
		var tmp3 HashMap_I = t.F_map; var tmp4 int32
		var tmp5 int32 = mid
		t.F_index = tmp5; tmp4 = tmp5
//line :1049:1
		var tmp6 int32 = tmp4; var tmp7 int32; var tmp8 int32 = int32(uint32(t.F_est) >> 1)


		t.F_est = tmp8; tmp7 = tmp8
//line :1049:1
		return HashMap_EntrySpliterator_New_HashMap_I_I_I_I(tmp3, lo, tmp6, tmp7, t.F_expectedModCount)
	}
}



func (t *HashMap_EntrySpliterator) ForEachRemaining_Consumer__V(action Consumer) {

	var i int32 = 0
	var hi int32 = 0
	var mc int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var m HashMap_I = t.F_map; var tab *RefArray = m.Self_HashMap().F_table; var tmp1 int32

	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {

		var tmp2 int32; var tmp3 int32 = m.Self_HashMap().F_modCount; t.F_expectedModCount = tmp3; tmp2 = tmp3; mc = tmp2
		var tmp4 int32; var tmp5 int32; if tab == nil { tmp5 = 0 } else { tmp5 = int32(len(tab.A)) }; var tmp6 int32 = tmp5; t.F_fence = tmp6; tmp4 = tmp6; hi = tmp4 } else {
			mc = t.F_expectedModCount }
	var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = !(tab == nil); if tmp10 { tmp10 = int32(len(tab.A)) >= hi }; tmp9 = tmp10; if tmp9 { var tmp11 int32; i = t.F_index; tmp11 = i; tmp9 = tmp11 >= 0 }; tmp8 = tmp9; if tmp8 {
		var tmp12 bool; var tmp13 int32 = i; var tmp14 int32; var tmp15 int32 = hi; t.F_index = tmp15; tmp14 = tmp15; tmp12 = tmp13 < tmp14; if !tmp12 { tmp12 = !(t.F_current == nil) }; tmp8 = tmp12 }
//line :1068:1
	tmp7 = tmp8; if tmp7 {

		var p HashMap_Node_I = t.F_current
		t.F_current = nil
	L1: for {
		if p == nil {
			p = As[HashMap_Node_I](tab.A[i]); i = i + 1 } else {
				action.Accept_O__V(p); p = p.Self_HashMap_Node().F_next }
		var tmp16 bool; var tmp17 bool; tmp17 = !(p == nil); if !tmp17 { tmp17 = i < hi }; tmp16 = tmp17; if tmp16 { continue L1 }
//line :1072:1
		break L1
	}



		if m.Self_HashMap().F_modCount == mc { } else { panic(Thrown(ConcurrentModificationException_New()))
		} } }
func (t *HashMap_EntrySpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	var hi int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tab *RefArray = t.F_map.Self_HashMap().F_table; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = !(tab == nil); if tmp3 { var tmp4 int32 = int32(len(tab.A)); var tmp5 int32; hi = t.GetFence__I(); tmp5 = hi; tmp3 = tmp4 >= tmp5 }; tmp2 = tmp3; if tmp2 {
		tmp2 = t.F_index >= 0 }
//line :1083:1
	tmp1 = tmp2; if tmp1 {

	L1: for { var tmp6 bool; var tmp7 bool; tmp7 = !(t.F_current == nil); if !tmp7 { tmp7 = t.F_index < hi }; tmp6 = tmp7; if tmp6 {
		if t.F_current == nil {
			var tmp8 int32; var old_5 int32 = t.F_index


			t.F_index = t.F_index + 1
//line :1089:1
			tmp8 = old_5
//line :1087:1
			t.F_current = As[HashMap_Node_I](tab.A[tmp8]) } else {




				var e HashMap_Node_I = t.F_current
				t.F_current = t.F_current.Self_HashMap_Node().F_next
				action.Accept_O__V(e)
				if t.F_map.Self_HashMap().F_modCount == t.F_expectedModCount { } else {
					panic(Thrown(ConcurrentModificationException_New())) }
				return true }
//line :1085:1
		continue L1 }; break L1 } }
//line :1082:1
	return false
}
















func (t *HashMap_EntrySpliterator) Characteristics__I() int32 {
	var tmp1 int32; var tmp2 bool; var tmp3 bool; tmp3 = t.F_fence < 0; if !tmp3 { var tmp4 int32 = t.F_est; tmp3 = tmp4 == t.F_map.Self_HashMap().F_size }; tmp2 = tmp3; if tmp2 { tmp1 = 64 } else { tmp1 = 0 }; return tmp1 | 1
}



func (t *HashMap) Impl_NewNode_I_O_O_HashMap_Node__HashMap_Node(this HashMap_I, hash int32, key, value any, next HashMap_Node_I) HashMap_Node_I {
	return HashMap_Node_New_I_O_O_HashMap_Node(hash, key, value, next)
}
func (t *HashMap) Impl_ReplacementNode_HashMap_Node_HashMap_Node__HashMap_Node(this HashMap_I, p, next HashMap_Node_I) HashMap_Node_I {
	var tmp1 int32 = p.Self_HashMap_Node().F_hash; var tmp2 any = p.Self_HashMap_Node().F_key; return HashMap_Node_New_I_O_O_HashMap_Node(tmp1, tmp2, p.Self_HashMap_Node().F_value, next)
}
func (t *HashMap) Impl_NewTreeNode_I_O_O_HashMap_Node__HashMap_TreeNode(this HashMap_I, hash int32, key, value any, next HashMap_Node_I) *HashMap_TreeNode {
	return HashMap_TreeNode_New_I_O_O_HashMap_Node(hash, key, value, next)
}
func (t *HashMap) Impl_ReplacementTreeNode_HashMap_Node_HashMap_Node__HashMap_TreeNode(this HashMap_I, p, next HashMap_Node_I) *HashMap_TreeNode {

	var tmp1 int32 = p.Self_HashMap_Node().F_hash; var tmp2 any = p.Self_HashMap_Node().F_key; return HashMap_TreeNode_New_I_O_O_HashMap_Node(tmp1, tmp2, p.Self_HashMap_Node().F_value, next)
}
func (t *HashMap) Impl_Reinitialize__V(this HashMap_I) {
	t.F_table = nil
	t.F_entrySet = nil
	t.F_keySet = nil
	t.F_values = nil
	t.F_modCount = 0
	t.F_threshold = 0
	t.F_size = 0
}
func (t *HashMap) Impl_AfterNodeAccess_HashMap_Node__V(this HashMap_I, p0 HashMap_Node_I) {}

func (t *HashMap) Impl_AfterNodeInsertion_Z__V(this HashMap_I, p0 bool) {}

func (t *HashMap) Impl_AfterNodeRemoval_HashMap_Node__V(this HashMap_I, p0 HashMap_Node_I) {}
























func HashMap_TreeNode_New_I_O_O_HashMap_Node(p0 int32, p1, p2 any, p3 HashMap_Node_I) *HashMap_TreeNode { HashMap_TreeNode_Init(); t := &HashMap_TreeNode{}; t.Ctor_I_O_O_HashMap_Node(p0, p1, p2, p3); return t }
//line :1157:1
func (t *HashMap_TreeNode) Ctor_I_O_O_HashMap_Node(hash int32, key, val any, next HashMap_Node_I) { t.LinkedHashMap_Entry.Ctor_I_O_O_HashMap_Node(t, hash, key, val, next) }


func (t *HashMap_TreeNode) Root__HashMap_TreeNode() *HashMap_TreeNode {
	{ var r *HashMap_TreeNode = t; var p *HashMap_TreeNode

	L1: for { var tmp1 *HashMap_TreeNode; p = r.F_parent; tmp1 = p; if tmp1 == nil { return r }; r = p; continue L1 } }; panic("a2g: unreachable")
}
func HashMap_TreeNode_MoveRootToFront_HashMap_Node1_HashMap_TreeNode__V(tab *RefArray, root *HashMap_TreeNode) { HashMap_TreeNode_Init()

	var n int32 = 0; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = !(root == nil); if tmp3 { tmp3 = !(tab == nil) }; tmp2 = tmp3; if tmp2 { var tmp4 int32; n = int32(len(tab.A)); tmp4 = n; tmp2 = tmp4 > 0 }; tmp1 = tmp2; if tmp1 {
		var index int32 = (n - 1) & root.F_hash; var first *HashMap_TreeNode = HashMap_TreeNode_Cast(As[HashMap_Node_I](tab.A[index]))

		if root == first { } else {
			var rn HashMap_Node_I
			tab.Store(index, root.Ref())
			var rp *HashMap_TreeNode = root.F_prev; var tmp5 HashMap_Node_I
			rn = root.F_next; tmp5 = rn; if !(tmp5 == nil) { HashMap_TreeNode_Cast(rn).F_prev = rp }
			if !(rp == nil) { rp.F_next = rn }
			if !(first == nil) { first.F_prev = root }
			root.F_next = Up_HashMap_TreeNode_HashMap_Node(first)
			root.F_prev = nil }
		if !A2g_AssertionsDisabled && !HashMap_TreeNode_CheckInvariants_HashMap_TreeNode__Z(root) { panic(Thrown(AssertionError_New()))
		} } }
func (t *HashMap_TreeNode) Find_I_O_Class__HashMap_TreeNode(h int32, k any, kc *Class) *HashMap_TreeNode {
	var p *HashMap_TreeNode = t
L1: for {
	var ph int32 = 0; var dir int32 = 0; var pk any; var pl *HashMap_TreeNode = p.F_left; var pr *HashMap_TreeNode = p.F_right; var q *HashMap_TreeNode; var tmp1 int32






	ph = p.F_hash; tmp1 = ph
//line :1191:1
	if tmp1 > h {
		p = pl } else {
//line :1191:1
			if ph < h {

				p = pr } else {
//line :1191:1
					var tmp2 bool; var tmp3 bool; var tmp4 any


					pk = p.F_key; tmp4 = pk; tmp3 = tmp4 == k; if !tmp3 { var tmp5 bool; tmp5 = !(k == nil); if tmp5 { tmp5 = Equals(k, pk) }; tmp3 = tmp5 }; tmp2 = tmp3
//line :1191:1
					if tmp2 {


						return p } else {
//line :1191:1
							if pl == nil {



								p = pr } else {
//line :1191:1
									if pr == nil {




										p = pl } else {
//line :1191:1
											var tmp6 bool; var tmp7 bool; var tmp8 bool





											tmp8 = !(kc == nil); if !tmp8 { var tmp9 *Class; kc = HashMap_ComparableClassFor_O__Class(k); tmp9 = kc; tmp8 = !(tmp9 == nil) }; tmp7 = tmp8; if tmp7 {
												var tmp10 int32; dir = HashMap_CompareComparables_Class_O_O__I(kc, k, pk); tmp10 = dir; tmp7 = !(tmp10 == 0) }
//line :1197:1
											tmp6 = tmp7
//line :1191:1
											if tmp6 {







												var tmp11 *HashMap_TreeNode; if dir < 0 { tmp11 = pl } else { tmp11 = pr }; p = tmp11 } else {
//line :1191:1
													var tmp12 *HashMap_TreeNode








													q = NN(pr).Find_I_O_Class__HashMap_TreeNode(h, k, kc); tmp12 = q
//line :1191:1
													if !(tmp12 == nil) {








														return q } else {
															p = pl } } } } } } }
	if !(p == nil) { continue L1 }
//line :1184:1
	break L1 }
//line :1183:1
	return nil
}




















func (t *HashMap_TreeNode) GetTreeNode_I_O__HashMap_TreeNode(h int32, k any) *HashMap_TreeNode {
	var tmp1 *HashMap_TreeNode; if !(t.F_parent == nil) { tmp1 = t.Root__HashMap_TreeNode() } else { tmp1 = t }; return NN(tmp1).Find_I_O_Class__HashMap_TreeNode(h, k, nil)
}
func HashMap_TreeNode_TieBreakOrder_O_O__I(a, b any) int32 { HashMap_TreeNode_Init()
	var d int32 = 0; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = a == nil; if !tmp3 { tmp3 = b == nil }; tmp2 = tmp3; if !tmp2 {
		var tmp4 int32; d = NN(NN(GetClass(a)).GetName__String()).CompareTo_String__I(NN(GetClass(b)).GetName__String()); tmp4 = d; tmp2 = tmp4 == 0 }
//line :1210:1
	tmp1 = tmp2; if tmp1 {

		var tmp5 int32; if System_IdentityHashCode_O__I(a) <= System_IdentityHashCode_O__I(b) { tmp5 = -1 } else { tmp5 = 1 }; d = tmp5 }
//line :1209:1
	return d
}




func (t *HashMap_TreeNode) Treeify_HashMap_Node1__V(tab *RefArray) {
	var root *HashMap_TreeNode; var x *HashMap_TreeNode = t; var next *HashMap_TreeNode


L1: for { if !(x == nil) {
	next = HashMap_TreeNode_Cast(x.F_next)
	var tmp1 *HashMap_TreeNode = x; var tmp2 *HashMap_TreeNode; var tmp3 *HashMap_TreeNode; x.F_right = tmp3; tmp2 = tmp3; tmp1.F_left = tmp2
	if root == nil {
		x.F_parent = nil; x.F_red = false; root = x } else {
			var k any = x.F_key; var h int32 = x.F_hash; var kc *Class
			var p /*line :1224:1*/*HashMap_TreeNode = root



		L2: for {
			var dir int32 = 0; var ph int32 = 0; var pk any = p.F_key; var tmp4 int32



			ph = p.F_hash; tmp4 = ph
//line :1232:1
			if tmp4 > h {
				dir = -1 } else {
//line :1232:1
					if ph < h {

						dir = 1 } else {
//line :1232:1
							var tmp5 bool; var tmp6 bool; var tmp7 bool


							tmp7 = kc == nil; if tmp7 { var tmp8 *Class; kc = HashMap_ComparableClassFor_O__Class(k); tmp8 = kc; tmp7 = tmp8 == nil }; tmp6 = tmp7; if !tmp6 {
								var tmp9 int32; dir = HashMap_CompareComparables_Class_O_O__I(kc, k, pk); tmp9 = dir; tmp6 = tmp9 == 0 }
//line :1235:1
							tmp5 = tmp6
//line :1232:1
							if tmp5 {




								dir = HashMap_TreeNode_TieBreakOrder_O_O__I(k, pk) } } }
			var xp *HashMap_TreeNode = p; var tmp10 *HashMap_TreeNode; var tmp11 *HashMap_TreeNode
			if dir <= 0 { tmp11 = p.F_left } else { tmp11 = p.F_right }; p = tmp11; tmp10 = p; if tmp10 == nil {
				x.F_parent = xp
				if dir <= 0 { xp.F_left = x } else { xp.F_right = x }
				root = HashMap_TreeNode_BalanceInsertion_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, x)
				break L2 }
//line :1228:1
			continue L2
		}
		}













	x = next
//line :1219:1
	continue L1 }; break L1
}
























	HashMap_TreeNode_MoveRootToFront_HashMap_Node1_HashMap_TreeNode__V(tab, root)
}
func (t *HashMap_TreeNode) Untreeify_HashMap__HashMap_Node(map_ HashMap_I) HashMap_Node_I {
	var hd HashMap_Node_I; var tl HashMap_Node_I
	var q HashMap_Node_I = t
L1: for {
	if !(q == nil) {
		var p HashMap_Node_I = map_.ReplacementNode_HashMap_Node_HashMap_Node__HashMap_Node(q, nil)
		if tl == nil { hd = p } else { tl.Self_HashMap_Node().F_next = p }
		tl = p
		q = q.Self_HashMap_Node().F_next; continue L1 }
//line :1250:1
	break L1 }
//line :1248:1
	return hd
}








func (t *HashMap_TreeNode) PutTreeVal_HashMap_HashMap_Node1_I_O_O__HashMap_TreeNode(map_ HashMap_I, tab *RefArray, h int32, k, v any) *HashMap_TreeNode {


	{ var kc *Class; var searched bool = false; var root *HashMap_TreeNode

		if !(t.F_parent == nil) { root = t.Root__HashMap_TreeNode() } else { root = t }
//line :1261:1
		var p *HashMap_TreeNode = root



	L1: for {
		var dir int32 = 0; var ph int32 = 0; var pk any; var tmp1 int32



		ph = p.F_hash; tmp1 = ph
//line :1269:1
		if tmp1 > h {
			dir = -1 } else {
//line :1269:1
				if ph < h {

					dir = 1 } else {
//line :1269:1
						var tmp2 bool; var tmp3 bool; var tmp4 any


						pk = p.F_key; tmp4 = pk; tmp3 = tmp4 == k; if !tmp3 { var tmp5 bool; tmp5 = !(k == nil); if tmp5 { tmp5 = Equals(k, pk) }; tmp3 = tmp5 }; tmp2 = tmp3
//line :1269:1
						if tmp2 {


							return p } else {

								var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = kc == nil; if tmp8 { var tmp9 *Class; kc = HashMap_ComparableClassFor_O__Class(k); tmp9 = kc; tmp8 = tmp9 == nil }; tmp7 = tmp8; if !tmp7 {
									var tmp10 int32; dir = HashMap_CompareComparables_Class_O_O__I(kc, k, pk); tmp10 = dir; tmp7 = tmp10 == 0 }
//line :1274:1
								tmp6 = tmp7; if tmp6 {

									if searched { } else {
										var q *HashMap_TreeNode; var ch *HashMap_TreeNode

										searched = true
										var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 *HashMap_TreeNode; ch = p.F_left; tmp14 = ch; tmp13 = !(tmp14 == nil); if tmp13 {
											var tmp15 *HashMap_TreeNode; q = NN(ch).Find_I_O_Class__HashMap_TreeNode(h, k, kc); tmp15 = q; tmp13 = !(tmp15 == nil) }
//line :1280:1
										tmp12 = tmp13; if !tmp12 {

											var tmp16 bool; var tmp17 *HashMap_TreeNode; ch = p.F_right; tmp17 = ch; tmp16 = !(tmp17 == nil); if tmp16 {
												var tmp18 *HashMap_TreeNode; q = NN(ch).Find_I_O_Class__HashMap_TreeNode(h, k, kc); tmp18 = q; tmp16 = !(tmp18 == nil) }
//line :1282:1
											tmp12 = tmp16 }
//line :1280:1
										tmp11 = tmp12; if tmp11 {



											return q } }
									dir = HashMap_TreeNode_TieBreakOrder_O_O__I(k, pk) } } } }
		var xp *HashMap_TreeNode = p; var tmp19 *HashMap_TreeNode; var tmp20 *HashMap_TreeNode
		if dir <= 0 { tmp20 = p.F_left } else { tmp20 = p.F_right }; p = tmp20; tmp19 = p; if tmp19 == nil {
			var xpn HashMap_Node_I = xp.F_next; var x *HashMap_TreeNode = map_.NewTreeNode_I_O_O_HashMap_Node__HashMap_TreeNode(h, k, v, xpn)

			if dir <= 0 { xp.F_left = x } else { xp.F_right = x }
			xp.F_next = Up_HashMap_TreeNode_HashMap_Node(x)
			var tmp21 *HashMap_TreeNode; var tmp22 *HashMap_TreeNode = xp; x.F_prev = tmp22; tmp21 = tmp22; x.F_parent = tmp21
			if !(xpn == nil) { HashMap_TreeNode_Cast(xpn).F_prev = x }
			HashMap_TreeNode_MoveRootToFront_HashMap_Node1_HashMap_TreeNode__V(tab, HashMap_TreeNode_BalanceInsertion_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, x))
			return nil }
//line :1265:1
		continue L1 } }
//line :1263:1
	panic("a2g: unreachable")
}
































func (t *HashMap_TreeNode) RemoveTreeNode_HashMap_HashMap_Node1_Z__V(map_ HashMap_I, tab *RefArray, movable bool) {

	var n int32 = 0; var tmp1 bool; var tmp2 bool
	tmp2 = tab == nil; if !tmp2 { var tmp3 int32; n = int32(len(tab.A)); tmp3 = n; tmp2 = tmp3 == 0 }; tmp1 = tmp2; if tmp1 { } else {
		var index int32 = (n - 1) & t.F_hash; var first *HashMap_TreeNode = HashMap_TreeNode_Cast(As[HashMap_Node_I](tab.A[index])); var root *HashMap_TreeNode = first; var rl *HashMap_TreeNode; var succ *HashMap_TreeNode = HashMap_TreeNode_Cast(t.F_next); var pred *HashMap_TreeNode = t.F_prev





		if pred == nil { var tmp4 *HashMap_TreeNode; first = succ; tmp4 = first; tab.Store(index, tmp4.Ref()) } else { pred.F_next = Up_HashMap_TreeNode_HashMap_Node(succ) }
		if !(succ == nil) { succ.F_prev = pred }
		if !(first == nil) {
			if !(root.F_parent == nil) { root = NN(root).Root__HashMap_TreeNode() }
			var tmp5 bool; var tmp6 bool; tmp6 = root == nil; if !tmp6 {
				var tmp7 bool; tmp7 = movable; if tmp7 {
					var tmp8 bool; var tmp9 bool; tmp9 = root.F_right == nil; if !tmp9 { var tmp10 *HashMap_TreeNode; rl = root.F_left; tmp10 = rl; tmp9 = tmp10 == nil }; tmp8 = tmp9; if !tmp8 {
						tmp8 = rl.F_left == nil }
//line :1313:1
					tmp7 = tmp8 }
//line :1312:1
				tmp6 = tmp7 }
//line :1311:1
			tmp5 = tmp6; if tmp5 {



				tab.Store(index, NN(first).Untreeify_HashMap__HashMap_Node(map_)) } else {
					var p *HashMap_TreeNode = t; var pl *HashMap_TreeNode = t.F_left; var pr *HashMap_TreeNode = t.F_right; var replacement *HashMap_TreeNode; var tmp11 bool; var tmp12 bool




					tmp12 = !(pl == nil); if tmp12 { tmp12 = !(pr == nil) }; tmp11 = tmp12
//line :1320:1
					if tmp11 {

						var s *HashMap_TreeNode = pr; var sl *HashMap_TreeNode

					L1: for { var tmp13 *HashMap_TreeNode; sl = s.F_left; tmp13 = sl; if !(tmp13 == nil) { s = sl; continue L1 }; break L1 }
						var c bool = s.F_red
						s.F_red = p.F_red
						p.F_red = c
						var sr *HashMap_TreeNode = s.F_right; var pp *HashMap_TreeNode = p.F_parent

						if s == pr {
							p.F_parent = s; s.F_right = p } else {
								var sp *HashMap_TreeNode = s.F_parent; var tmp14 *HashMap_TreeNode; var tmp15 *HashMap_TreeNode = sp
								p.F_parent = tmp15; tmp14 = tmp15; if !(tmp14 == nil) {
									if s == sp.F_left {
										sp.F_left = p } else {
											sp.F_right = p } }
								var tmp16 *HashMap_TreeNode; var tmp17 *HashMap_TreeNode = pr; s.F_right = tmp17; tmp16 = tmp17; if !(tmp16 == nil) { pr.F_parent = s } }
						p.F_left = nil
						var tmp18 *HashMap_TreeNode; var tmp19 *HashMap_TreeNode = sr; p.F_right = tmp19; tmp18 = tmp19; if !(tmp18 == nil) { sr.F_parent = p }
						var tmp20 *HashMap_TreeNode; var tmp21 *HashMap_TreeNode = pl; s.F_left = tmp21; tmp20 = tmp21; if !(tmp20 == nil) { pl.F_parent = s }
						var tmp22 *HashMap_TreeNode; var tmp23 *HashMap_TreeNode = pp
						s.F_parent = tmp23; tmp22 = tmp23
//line :1341:1
						if tmp22 == nil {
							root = s } else {
//line :1341:1
								if p == pp.F_left {

									pp.F_left = s } else {
										pp.F_right = s } }
						if !(sr == nil) { replacement = sr } else { replacement = p } } else {
//line :1320:1
							if !(pl == nil) {

























								replacement = pl } else {
//line :1320:1
									if !(pr == nil) {


























										replacement = pr } else {
											replacement = p } } }
					if replacement == p { } else {
						var pp_2 *HashMap_TreeNode; var tmp24 *HashMap_TreeNode = p.F_parent; replacement.F_parent = tmp24; pp_2 = tmp24
						if pp_2 == nil {
							var tmp25 *HashMap_TreeNode; root = replacement; tmp25 = root; tmp25.F_red = false } else {
//line :1351:1
								if p == pp_2.F_left {

									pp_2.F_left = replacement } else {
										pp_2.F_right = replacement } }
						var tmp26 *HashMap_TreeNode; var tmp27 *HashMap_TreeNode; var tmp28 *HashMap_TreeNode; p.F_parent = tmp28; tmp27 = tmp28; var tmp29 *HashMap_TreeNode = tmp27; p.F_right = tmp29; tmp26 = tmp29; p.F_left = tmp26 }
					var r *HashMap_TreeNode; if p.F_red { r = root } else {

						r = HashMap_TreeNode_BalanceDeletion_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, replacement) }
					if replacement == p {
						var pp_3 *HashMap_TreeNode = p.F_parent
						p.F_parent = nil
						if !(pp_3 == nil) {
							if p == pp_3.F_left {
								pp_3.F_left = nil } else {
//line :1363:1
									if p == pp_3.F_right {

										pp_3.F_right = nil } } } }
					if movable { HashMap_TreeNode_MoveRootToFront_HashMap_Node1_HashMap_TreeNode__V(tab, r)
					} } } } }
func (t *HashMap_TreeNode) Split_HashMap_HashMap_Node1_I_I__V(map_ HashMap_I, tab *RefArray, index, bit int32) {

	var b *HashMap_TreeNode = t; var loHead *HashMap_TreeNode; var loTail *HashMap_TreeNode; var hiHead *HashMap_TreeNode; var hiTail *HashMap_TreeNode; var lc int32 = 0; var hc int32 = 0; var e *HashMap_TreeNode = b; var next *HashMap_TreeNode








L1: for { if !(e == nil) {
	next = HashMap_TreeNode_Cast(e.F_next)
	e.F_next = nil
	if e.F_hash&bit == 0 {

		var tmp1 *HashMap_TreeNode; var tmp2 *HashMap_TreeNode = loTail; e.F_prev = tmp2; tmp1 = tmp2; if tmp1 == nil { loHead = e } else { loTail.F_next = Up_HashMap_TreeNode_HashMap_Node(e) }
		loTail = e
		lc = lc + 1 } else {

			var tmp3 *HashMap_TreeNode; var tmp4 *HashMap_TreeNode = hiTail; e.F_prev = tmp4; tmp3 = tmp4; if tmp3 == nil { hiHead = e } else { hiTail.F_next = Up_HashMap_TreeNode_HashMap_Node(e) }
			hiTail = e
			hc = hc + 1 }
	e = next
//line :1379:1
	continue L1 }; break L1
}











	if !(loHead == nil) {
		if lc <= 6 {
			tab.Store(index, NN(loHead).Untreeify_HashMap__HashMap_Node(map_)) } else {
				tab.Store(index, loHead.Ref()); if !(hiHead == nil) { NN(loHead).Treeify_HashMap_Node1__V(tab) } } }
	if !(hiHead == nil) {
		if hc <= 6 {
			tab.Store(index+bit, NN(hiHead).Untreeify_HashMap__HashMap_Node(map_)) } else {

				tab.Store(index+bit, hiHead.Ref())
				if !(loHead == nil) { NN(hiHead).Treeify_HashMap_Node1__V(tab)
				} } } }
func HashMap_TreeNode_RotateLeft_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, p *HashMap_TreeNode) *HashMap_TreeNode { HashMap_TreeNode_Init()

	var r *HashMap_TreeNode; var pp *HashMap_TreeNode; var rl *HashMap_TreeNode; var tmp1 bool; var tmp2 bool


	tmp2 = !(p == nil); if tmp2 { var tmp3 *HashMap_TreeNode; r = p.F_right; tmp3 = r; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp4 *HashMap_TreeNode; var tmp5 *HashMap_TreeNode; var tmp6 *HashMap_TreeNode = r.F_left; p.F_right = tmp6; tmp5 = tmp6; rl = tmp5; tmp4 = rl; if !(tmp4 == nil) { rl.F_parent = p }
		var tmp7 *HashMap_TreeNode; var tmp8 *HashMap_TreeNode; var tmp9 *HashMap_TreeNode = p.F_parent
		r.F_parent = tmp9; tmp8 = tmp9; pp = tmp8; tmp7 = pp
//line :1410:1
		if tmp7 == nil {
			var tmp10 *HashMap_TreeNode; root = r; tmp10 = root; tmp10.F_red = false } else {
//line :1410:1
				if pp.F_left == p {

					pp.F_left = r } else {
						pp.F_right = r } }
		r.F_left = p
		p.F_parent = r }
//line :1405:1
	return root
}











func HashMap_TreeNode_RotateRight_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, p *HashMap_TreeNode) *HashMap_TreeNode { HashMap_TreeNode_Init()

	var l *HashMap_TreeNode; var pp *HashMap_TreeNode; var lr *HashMap_TreeNode; var tmp1 bool; var tmp2 bool


	tmp2 = !(p == nil); if tmp2 { var tmp3 *HashMap_TreeNode; l = p.F_left; tmp3 = l; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp4 *HashMap_TreeNode; var tmp5 *HashMap_TreeNode; var tmp6 *HashMap_TreeNode = l.F_right; p.F_left = tmp6; tmp5 = tmp6; lr = tmp5; tmp4 = lr; if !(tmp4 == nil) { lr.F_parent = p }
		var tmp7 *HashMap_TreeNode; var tmp8 *HashMap_TreeNode; var tmp9 *HashMap_TreeNode = p.F_parent
		l.F_parent = tmp9; tmp8 = tmp9; pp = tmp8; tmp7 = pp
//line :1425:1
		if tmp7 == nil {
			var tmp10 *HashMap_TreeNode; root = l; tmp10 = root; tmp10.F_red = false } else {
//line :1425:1
				if pp.F_right == p {

					pp.F_right = l } else {
						pp.F_left = l } }
		l.F_right = p
		p.F_parent = l }
//line :1420:1
	return root
}











func HashMap_TreeNode_BalanceInsertion_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, x *HashMap_TreeNode) *HashMap_TreeNode { HashMap_TreeNode_Init()

	x.F_red = true
	{ var xp *HashMap_TreeNode; var xpp *HashMap_TreeNode; var xppl *HashMap_TreeNode; var xppr *HashMap_TreeNode



	L1: for {
		var tmp1 *HashMap_TreeNode
		xp = x.F_parent; tmp1 = xp
//line :1441:1
		if tmp1 == nil {
			x.F_red = false; return x } else {
//line :1441:1
				var tmp2 bool; var tmp3 bool

				tmp3 = !xp.F_red; if !tmp3 { var tmp4 *HashMap_TreeNode; xpp = xp.F_parent; tmp4 = xpp; tmp3 = tmp4 == nil }; tmp2 = tmp3
//line :1441:1
				if tmp2 {

					return root } }
		var tmp5 *HashMap_TreeNode = xp; var tmp6 *HashMap_TreeNode
		xppl = xpp.F_left; tmp6 = xppl
//line :1444:1
		if tmp5 == tmp6 {

			var tmp7 bool; var tmp8 bool; var tmp9 *HashMap_TreeNode; xppr = xpp.F_right; tmp9 = xppr; tmp8 = !(tmp9 == nil); if tmp8 { tmp8 = xppr.F_red }; tmp7 = tmp8; if tmp7 {

				xppr.F_red = false
				xp.F_red = false
				xpp.F_red = true
				x = xpp } else {

					if x == xp.F_right {
						var tmp10 *HashMap_TreeNode = root; var tmp11 *HashMap_TreeNode; x = xp; tmp11 = x; root = HashMap_TreeNode_RotateLeft_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(tmp10, tmp11)
						var tmp12 *HashMap_TreeNode; var tmp13 *HashMap_TreeNode; xp = x.F_parent; tmp13 = xp; if !(tmp13 == nil) { tmp12 = xp.F_parent } else { tmp12 = nil }; xpp = tmp12 }
					if !(xp == nil) {
						xp.F_red = false
						if !(xpp == nil) {
							xpp.F_red = true
							root = HashMap_TreeNode_RotateRight_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xpp) } } } } else {
//line :1444:1
								var tmp14 bool; var tmp15 bool
















								tmp15 = !(xppl == nil); if tmp15 { tmp15 = xppl.F_red }; tmp14 = tmp15
//line :1444:1
								if tmp14 {


















									xppl.F_red = false
									xp.F_red = false
									xpp.F_red = true
									x = xpp } else {


										if x == xp.F_left {
											var tmp16 *HashMap_TreeNode = root; var tmp17 *HashMap_TreeNode; x = xp; tmp17 = x; root = HashMap_TreeNode_RotateRight_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(tmp16, tmp17)
											var tmp18 *HashMap_TreeNode; var tmp19 *HashMap_TreeNode; xp = x.F_parent; tmp19 = xp; if !(tmp19 == nil) { tmp18 = xp.F_parent } else { tmp18 = nil }; xpp = tmp18 }
										if !(xp == nil) {
											xp.F_red = false
											if !(xpp == nil) {
												xpp.F_red = true
												root = HashMap_TreeNode_RotateLeft_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xpp) } } } }
//line :1440:1
		continue L1
	}
	}


	panic("a2g: unreachable")
}































func HashMap_TreeNode_BalanceDeletion_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, x *HashMap_TreeNode) *HashMap_TreeNode { HashMap_TreeNode_Init()

	{ var xp *HashMap_TreeNode; var xpl *HashMap_TreeNode; var xpr *HashMap_TreeNode


	L1: for {
		var tmp1 bool; var tmp2 bool
		tmp2 = x == nil; if !tmp2 { tmp2 = x == root }; tmp1 = tmp2
//line :1484:1
		if tmp1 {
			return root } else {
//line :1484:1
				var tmp3 *HashMap_TreeNode

				xp = x.F_parent; tmp3 = xp
//line :1484:1
				if tmp3 == nil {

					x.F_red = false; return x } else {
//line :1484:1
						if x.F_red {


							x.F_red = false; return root } else {
//line :1484:1
								var tmp4 *HashMap_TreeNode



								xpl = xp.F_left; tmp4 = xpl
//line :1484:1
								if tmp4 == x {





									var tmp5 bool; var tmp6 bool; var tmp7 *HashMap_TreeNode; xpr = xp.F_right; tmp7 = xpr; tmp6 = !(tmp7 == nil); if tmp6 { tmp6 = xpr.F_red }; tmp5 = tmp6; if tmp5 {
										xpr.F_red = false
										xp.F_red = true
										root = HashMap_TreeNode_RotateLeft_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xp)
										var tmp8 *HashMap_TreeNode; var tmp9 *HashMap_TreeNode; xp = x.F_parent; tmp9 = xp; if !(tmp9 == nil) { tmp8 = xp.F_right } else { tmp8 = nil }; xpr = tmp8 }
									if xpr == nil {
										x = xp } else {
											var sl *HashMap_TreeNode = xpr.F_left; var sr *HashMap_TreeNode = xpr.F_right; var tmp10 bool; var tmp11 bool; var tmp12 bool

											tmp12 = sr == nil; if !tmp12 { tmp12 = !sr.F_red }; tmp11 = tmp12; if tmp11 { var tmp13 bool; tmp13 = sl == nil; if !tmp13 { tmp13 = !sl.F_red }; tmp11 = tmp13 }; tmp10 = tmp11; if tmp10 {
												xpr.F_red = true; x = xp } else {

													var tmp14 bool; var tmp15 bool; tmp15 = sr == nil; if !tmp15 { tmp15 = !sr.F_red }; tmp14 = tmp15; if tmp14 {
														if !(sl == nil) { sl.F_red = false }
														xpr.F_red = true
														root = HashMap_TreeNode_RotateRight_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xpr)
														var tmp16 *HashMap_TreeNode; var tmp17 *HashMap_TreeNode; xp = x.F_parent; tmp17 = xp; if !(tmp17 == nil) { tmp16 = xp.F_right } else { tmp16 = nil }; xpr = tmp16 }
													if !(xpr == nil) {
														var tmp18 *HashMap_TreeNode = xpr; var tmp19 bool; if xp == nil { tmp19 = false } else { tmp19 = xp.F_red }; tmp18.F_red = tmp19
														var tmp20 *HashMap_TreeNode; sr = xpr.F_right; tmp20 = sr; if !(tmp20 == nil) { sr.F_red = false } }
													if !(xp == nil) {
														xp.F_red = false
														root = HashMap_TreeNode_RotateLeft_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xp) }
													x = root } } } else {


														var tmp21 bool; var tmp22 bool; tmp22 = !(xpl == nil); if tmp22 { tmp22 = xpl.F_red }; tmp21 = tmp22; if tmp21 {
															xpl.F_red = false
															xp.F_red = true
															root = HashMap_TreeNode_RotateRight_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xp)
															var tmp23 *HashMap_TreeNode; var tmp24 *HashMap_TreeNode; xp = x.F_parent; tmp24 = xp; if !(tmp24 == nil) { tmp23 = xp.F_left } else { tmp23 = nil }; xpl = tmp23 }
														if xpl == nil {
															x = xp } else {
																var sl_2 *HashMap_TreeNode = xpl.F_left; var sr_2 *HashMap_TreeNode = xpl.F_right; var tmp25 bool; var tmp26 bool; var tmp27 bool

																tmp27 = sl_2 == nil; if !tmp27 { tmp27 = !sl_2.F_red }; tmp26 = tmp27; if tmp26 { var tmp28 bool; tmp28 = sr_2 == nil; if !tmp28 { tmp28 = !sr_2.F_red }; tmp26 = tmp28 }; tmp25 = tmp26; if tmp25 {
																	xpl.F_red = true; x = xp } else {

																		var tmp29 bool; var tmp30 bool; tmp30 = sl_2 == nil; if !tmp30 { tmp30 = !sl_2.F_red }; tmp29 = tmp30; if tmp29 {
																			if !(sr_2 == nil) { sr_2.F_red = false }
																			xpl.F_red = true
																			root = HashMap_TreeNode_RotateLeft_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xpl)
																			var tmp31 *HashMap_TreeNode; var tmp32 *HashMap_TreeNode; xp = x.F_parent; tmp32 = xp; if !(tmp32 == nil) { tmp31 = xp.F_left } else { tmp31 = nil }; xpl = tmp31 }
																		if !(xpl == nil) {
																			var tmp33 *HashMap_TreeNode = xpl; var tmp34 bool; if xp == nil { tmp34 = false } else { tmp34 = xp.F_red }; tmp33.F_red = tmp34
																			var tmp35 *HashMap_TreeNode; sl_2 = xpl.F_left; tmp35 = sl_2; if !(tmp35 == nil) { sl_2.F_red = false } }
																		if !(xp == nil) {
																			xp.F_red = false
																			root = HashMap_TreeNode_RotateRight_HashMap_TreeNode_HashMap_TreeNode__HashMap_TreeNode(root, xp) }
																		x = root } } } } } }
//line :1483:1
		continue L1
	} }
	panic("a2g: unreachable")
}






















































func HashMap_TreeNode_CheckInvariants_HashMap_TreeNode__Z(t_ *HashMap_TreeNode) bool { HashMap_TreeNode_Init()
	var tp *HashMap_TreeNode = t_.F_parent; var tl *HashMap_TreeNode = t_.F_left; var tr *HashMap_TreeNode = t_.F_right; var tb *HashMap_TreeNode = t_.F_prev; var tn *HashMap_TreeNode = HashMap_TreeNode_Cast(t_.F_next); var tmp1 bool; var tmp2 bool





	tmp2 = !(tb == nil); if tmp2 { tmp2 = !(any(tb.F_next) == any(t_.Ref())) }; tmp1 = tmp2
//line :1547:1
	if tmp1 { return false } else { var tmp3 bool; var tmp4 bool

		tmp4 = !(tn == nil); if tmp4 { tmp4 = !(tn.F_prev == t_) }; tmp3 = tmp4
//line :1547:1
		if tmp3 { return false } else { var tmp5 bool; var tmp6 bool; var tmp7 bool


			tmp7 = !(tp == nil); if tmp7 { tmp7 = !(t_ == tp.F_left) }; tmp6 = tmp7; if tmp6 { tmp6 = !(t_ == tp.F_right) }; tmp5 = tmp6
//line :1547:1
			if tmp5 { return false } else { var tmp8 bool; var tmp9 bool




				tmp9 = !(tl == nil); if tmp9 { var tmp10 bool; tmp10 = !(tl.F_parent == t_); if !tmp10 { var tmp11 int32 = tl.F_hash; tmp10 = tmp11 > t_.F_hash }; tmp9 = tmp10 }; tmp8 = tmp9
//line :1547:1
				if tmp8 { return false } else { var tmp12 bool; var tmp13 bool





					tmp13 = !(tr == nil); if tmp13 { var tmp14 bool; tmp14 = !(tr.F_parent == t_); if !tmp14 { var tmp15 int32 = tr.F_hash; tmp14 = tmp15 < t_.F_hash }; tmp13 = tmp14 }; tmp12 = tmp13
//line :1547:1
					if tmp12 { return false } else { var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 bool; var tmp20 bool






						tmp20 = t_.F_red; if tmp20 { tmp20 = !(tl == nil) }; tmp19 = tmp20; if tmp19 { tmp19 = tl.F_red }; tmp18 = tmp19; if tmp18 { tmp18 = !(tr == nil) }; tmp17 = tmp18; if tmp17 { tmp17 = tr.F_red }; tmp16 = tmp17
//line :1547:1
						if tmp16 { return false } else { var tmp21 bool; var tmp22 bool







							tmp22 = !(tl == nil); if tmp22 { tmp22 = !HashMap_TreeNode_CheckInvariants_HashMap_TreeNode__Z(tl) }; tmp21 = tmp22
//line :1547:1
							if tmp21 { return false } else { var tmp23 bool; var tmp24 bool








								tmp24 = !(tr == nil); if tmp24 { tmp24 = !HashMap_TreeNode_CheckInvariants_HashMap_TreeNode__Z(tr) }; tmp23 = tmp24
//line :1547:1
								if tmp23 { return false } else { return true
								}
							}
						}
					}
				}
			}
		}
	}
}


func HashMap_CalculateHashMapCapacity_I__I(numMappings int32) int32 {
	return D2I(Math_Ceil_D__D(float64(numMappings) / 0.75))
}
func HashMap_NewHashMap_I__HashMap(numMappings int32) HashMap_I {
	if numMappings < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2692, StrOfInt(numMappings))))) }
	return HashMap_New_I(HashMap_CalculateHashMapCapacity_I__I(numMappings))
}


type HashMap struct{ AbstractMap; F_table *RefArray; F_entrySet Set; F_size, F_modCount, F_threshold int32; F_loadFactor float32 }

type HashMap_I interface{ AbstractMap_I; Map; Cloneable; Serializable; Self_HashMap() *HashMap; PutMapEntries_Map_Z__V(p0 Map, p1 bool); Size__I() int32; IsEmpty__Z() bool; Get_O__O(p0 any) any; GetNode_O__HashMap_Node(p0 any) HashMap_Node_I; ContainsKey_O__Z(p0 any) bool; Put_O_O__O(p0, p1 any) any; PutVal_I_O_O_Z_Z__O(p0 int32, p1, p2 any, p3, p4 bool) any; Resize__HashMap_Node1() *RefArray; TreeifyBin_HashMap_Node1_I__V(p0 *RefArray, p1 int32); PutAll_Map__V(p0 Map); Remove_O__O(p0 any) any; RemoveNode_I_O_O_Z_Z__HashMap_Node(p0 int32, p1, p2 any, p3, p4 bool) HashMap_Node_I; Clear__V(); ContainsValue_O__Z(p0 any) bool; KeySet__Set() Set; PrepareArray_O1__O1(p0 *RefArray) *RefArray; KeysToArray_O1__O1(p0 *RefArray) *RefArray; ValuesToArray_O1__O1(p0 *RefArray) *RefArray; Values__Collection() Collection; EntrySet__Set() Set; GetOrDefault_O_O__O(p0, p1 any) any; PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any; ForEach_BiConsumer__V(p0 BiConsumer); ReplaceAll_BiFunction__V(p0 BiFunction); LoadFactor__F() float32; Capacity__I() int32; NewNode_I_O_O_HashMap_Node__HashMap_Node(p0 int32, p1, p2 any, p3 HashMap_Node_I) HashMap_Node_I; ReplacementNode_HashMap_Node_HashMap_Node__HashMap_Node(p0, p1 HashMap_Node_I) HashMap_Node_I; NewTreeNode_I_O_O_HashMap_Node__HashMap_TreeNode(p0 int32, p1, p2 any, p3 HashMap_Node_I) *HashMap_TreeNode; ReplacementTreeNode_HashMap_Node_HashMap_Node__HashMap_TreeNode(p0, p1 HashMap_Node_I) *HashMap_TreeNode; Reinitialize__V(); AfterNodeAccess_HashMap_Node__V(p0 HashMap_Node_I); AfterNodeInsertion_Z__V(p0 bool); AfterNodeRemoval_HashMap_Node__V(p0 HashMap_Node_I) }

func (t *HashMap) Self_HashMap() *HashMap { return t }

func (t *HashMap) Is_Cloneable() {}

func (t *HashMap) Is_Serializable() {}

const HashMap_serialVersionUID int64 = 362498820763181265

const HashMap_DEFAULT_INITIAL_CAPACITY int32 = 16

const HashMap_MAXIMUM_CAPACITY int32 = 1073741824

const HashMap_DEFAULT_LOAD_FACTOR float32 = 0.75

const HashMap_TREEIFY_THRESHOLD int32 = 8

const HashMap_UNTREEIFY_THRESHOLD int32 = 6

const HashMap_MIN_TREEIFY_CAPACITY int32 = 64

func (t *HashMap) PutMapEntries_Map_Z__V(p0 Map, p1 bool) { t.Impl_PutMapEntries_Map_Z__V(t, p0, p1) }

func (t *HashMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *HashMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *HashMap) PutVal_I_O_O_Z_Z__O(p0 int32, p1, p2 any, p3, p4 bool) any { return t.Impl_PutVal_I_O_O_Z_Z__O(t, p0, p1, p2, p3, p4) }

func (t *HashMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *HashMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *HashMap) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *HashMap) TreeifyBin_HashMap_Node1_I__V(p0 *RefArray, p1 int32) { t.Impl_TreeifyBin_HashMap_Node1_I__V(t, p0, p1) }

func (t *HashMap) NewNode_I_O_O_HashMap_Node__HashMap_Node(p0 int32, p1, p2 any, p3 HashMap_Node_I) HashMap_Node_I { return t.Impl_NewNode_I_O_O_HashMap_Node__HashMap_Node(t, p0, p1, p2, p3) }

func (t *HashMap) AfterNodeRemoval_HashMap_Node__V(p0 HashMap_Node_I) { t.Impl_AfterNodeRemoval_HashMap_Node__V(t, p0) }

func (t *HashMap) ReplacementTreeNode_HashMap_Node_HashMap_Node__HashMap_TreeNode(p0, p1 HashMap_Node_I) *HashMap_TreeNode { return t.Impl_ReplacementTreeNode_HashMap_Node_HashMap_Node__HashMap_TreeNode(t, p0, p1) }

func (t *HashMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *HashMap) Reinitialize__V() { t.Impl_Reinitialize__V(t) }

func (t *HashMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *HashMap) RemoveNode_I_O_O_Z_Z__HashMap_Node(p0 int32, p1, p2 any, p3, p4 bool) HashMap_Node_I { return t.Impl_RemoveNode_I_O_O_Z_Z__HashMap_Node(t, p0, p1, p2, p3, p4) }

func (t *HashMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *HashMap) AfterNodeInsertion_Z__V(p0 bool) { t.Impl_AfterNodeInsertion_Z__V(t, p0) }

func (t *HashMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *HashMap) KeysToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_KeysToArray_O1__O1(t, p0) }

func (t *HashMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *HashMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *HashMap) Resize__HashMap_Node1() *RefArray { return t.Impl_Resize__HashMap_Node1(t) }

func (t *HashMap) ReplacementNode_HashMap_Node_HashMap_Node__HashMap_Node(p0, p1 HashMap_Node_I) HashMap_Node_I { return t.Impl_ReplacementNode_HashMap_Node_HashMap_Node__HashMap_Node(t, p0, p1) }

func (t *HashMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *HashMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *HashMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *HashMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *HashMap) AfterNodeAccess_HashMap_Node__V(p0 HashMap_Node_I) { t.Impl_AfterNodeAccess_HashMap_Node__V(t, p0) }

func (t *HashMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *HashMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *HashMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *HashMap) ValuesToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ValuesToArray_O1__O1(t, p0) }

func (t *HashMap) GetNode_O__HashMap_Node(p0 any) HashMap_Node_I { return t.Impl_GetNode_O__HashMap_Node(t, p0) }

func (t *HashMap) LoadFactor__F() float32 { return t.Impl_LoadFactor__F(t) }

func (t *HashMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *HashMap) NewTreeNode_I_O_O_HashMap_Node__HashMap_TreeNode(p0 int32, p1, p2 any, p3 HashMap_Node_I) *HashMap_TreeNode { return t.Impl_NewTreeNode_I_O_O_HashMap_Node__HashMap_TreeNode(t, p0, p1, p2, p3) }

func (t *HashMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *HashMap) PrepareArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_PrepareArray_O1__O1(t, p0) }

func (t *HashMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *HashMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *HashMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *HashMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *HashMap) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *HashMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HashMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HashMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HashMap) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap) GetClass__Class() *Class { return HashMap_class }

func (t *HashMap) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HashMap_InstanceOf(x any) bool { _, ok := x.(HashMap_I); return ok }

func HashMap_Cast(x any) HashMap_I { if x == nil { return nil }; v, ok := x.(HashMap_I); if !ok { panic(ClassCast(x, HashMap_class)) }; return v }



type HashMap_EntryIterator struct{ HashMap_HashIterator; F_this_0 HashMap_I }

func (t *HashMap_EntryIterator) Is_Iterator() {}

func HashMap_EntryIterator_New_HashMap(p0 HashMap_I) *HashMap_EntryIterator { t := &HashMap_EntryIterator{}; t.Ctor_HashMap(p0); return t }

func (t *HashMap_EntryIterator) Ctor_HashMap(this_0 HashMap_I) { A2g_NotNull[HashMap_I](this_0); t.F_this_0 = this_0; t.HashMap_HashIterator.Ctor_HashMap(t, this_0) }

func (t *HashMap_EntryIterator) Next__O() any { return t.Next__Map_Entry() }

func (t *HashMap_EntryIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *HashMap_EntryIterator) NextNode__HashMap_Node() HashMap_Node_I { return t.Impl_NextNode__HashMap_Node(t) }

func (t *HashMap_EntryIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *HashMap_EntryIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *HashMap_EntryIterator) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_EntryIterator) GetClass__Class() *Class { return HashMap_EntryIterator_class }

func (t *HashMap_EntryIterator) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_EntryIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_EntryIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_EntryIterator_InstanceOf(x any) bool { _, ok := x.(*HashMap_EntryIterator); return ok }

func HashMap_EntryIterator_Cast(x any) *HashMap_EntryIterator { if x == nil { return nil }; v, ok := x.(*HashMap_EntryIterator); if !ok { panic(ClassCast(x, HashMap_EntryIterator_class)) }; return v }



type HashMap_EntrySet struct{ AbstractSet; F_this_0 HashMap_I }

func HashMap_EntrySet_New_HashMap(p0 HashMap_I) *HashMap_EntrySet { t := &HashMap_EntrySet{}; t.Ctor_HashMap(p0); return t }

func (t *HashMap_EntrySet) Ctor_HashMap(this_0 HashMap_I) { A2g_NotNull[HashMap_I](this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *HashMap_EntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *HashMap_EntrySet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *HashMap_EntrySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *HashMap_EntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *HashMap_EntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *HashMap_EntrySet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *HashMap_EntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *HashMap_EntrySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *HashMap_EntrySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *HashMap_EntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *HashMap_EntrySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *HashMap_EntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *HashMap_EntrySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HashMap_EntrySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HashMap_EntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HashMap_EntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_EntrySet) GetClass__Class() *Class { return HashMap_EntrySet_class }

func (t *HashMap_EntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_EntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_EntrySet_InstanceOf(x any) bool { _, ok := x.(*HashMap_EntrySet); return ok }

func HashMap_EntrySet_Cast(x any) *HashMap_EntrySet { if x == nil { return nil }; v, ok := x.(*HashMap_EntrySet); if !ok { panic(ClassCast(x, HashMap_EntrySet_class)) }; return v }



type HashMap_EntrySpliterator struct{ HashMap_HashMapSpliterator }

func (t *HashMap_EntrySpliterator) Is_Spliterator() {}

func (t *HashMap_EntrySpliterator) TrySplit__Spliterator() Spliterator { return Up_HashMap_EntrySpliterator_Spliterator(t.TrySplit__HashMap_EntrySpliterator()) }

func (t *HashMap_EntrySpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *HashMap_EntrySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *HashMap_EntrySpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *HashMap_EntrySpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *HashMap_EntrySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *HashMap_EntrySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_EntrySpliterator) GetClass__Class() *Class { return HashMap_EntrySpliterator_class }

func (t *HashMap_EntrySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_EntrySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_EntrySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_EntrySpliterator_InstanceOf(x any) bool { _, ok := x.(*HashMap_EntrySpliterator); return ok }

func HashMap_EntrySpliterator_Cast(x any) *HashMap_EntrySpliterator { if x == nil { return nil }; v, ok := x.(*HashMap_EntrySpliterator); if !ok { panic(ClassCast(x, HashMap_EntrySpliterator_class)) }; return v }



type HashMap_HashIterator struct{ Object; F_next, F_current HashMap_Node_I; F_expectedModCount, F_index int32; F_this_0 HashMap_I }

type HashMap_HashIterator_I interface{ Object_I; Self_HashMap_HashIterator() *HashMap_HashIterator; HasNext__Z() bool; NextNode__HashMap_Node() HashMap_Node_I; Remove__V() }

func (t *HashMap_HashIterator) Self_HashMap_HashIterator() *HashMap_HashIterator { return t }

func HashMap_HashIterator_InstanceOf(x any) bool { _, ok := x.(HashMap_HashIterator_I); return ok }

func HashMap_HashIterator_Cast(x any) HashMap_HashIterator_I { if x == nil { return nil }; v, ok := x.(HashMap_HashIterator_I); if !ok { panic(ClassCast(x, HashMap_HashIterator_class)) }; return v }



type HashMap_HashMapSpliterator struct{ Object; F_map HashMap_I; F_current HashMap_Node_I; F_index, F_fence, F_est, F_expectedModCount int32 }

type HashMap_HashMapSpliterator_I interface{ Object_I; Self_HashMap_HashMapSpliterator() *HashMap_HashMapSpliterator; GetFence__I() int32; EstimateSize__J() int64 }

func (t *HashMap_HashMapSpliterator) Self_HashMap_HashMapSpliterator() *HashMap_HashMapSpliterator { return t }

func (t *HashMap_HashMapSpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *HashMap_HashMapSpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *HashMap_HashMapSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_HashMapSpliterator) GetClass__Class() *Class { return HashMap_HashMapSpliterator_class }

func (t *HashMap_HashMapSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_HashMapSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_HashMapSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_HashMapSpliterator_InstanceOf(x any) bool { _, ok := x.(HashMap_HashMapSpliterator_I); return ok }

func HashMap_HashMapSpliterator_Cast(x any) HashMap_HashMapSpliterator_I { if x == nil { return nil }; v, ok := x.(HashMap_HashMapSpliterator_I); if !ok { panic(ClassCast(x, HashMap_HashMapSpliterator_class)) }; return v }



type HashMap_KeyIterator struct{ HashMap_HashIterator; F_this_0 HashMap_I }

func (t *HashMap_KeyIterator) Is_Iterator() {}

func HashMap_KeyIterator_New_HashMap(p0 HashMap_I) *HashMap_KeyIterator { t := &HashMap_KeyIterator{}; t.Ctor_HashMap(p0); return t }

func (t *HashMap_KeyIterator) Ctor_HashMap(this_0 HashMap_I) { A2g_NotNull[HashMap_I](this_0); t.F_this_0 = this_0; t.HashMap_HashIterator.Ctor_HashMap(t, this_0) }

func (t *HashMap_KeyIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *HashMap_KeyIterator) NextNode__HashMap_Node() HashMap_Node_I { return t.Impl_NextNode__HashMap_Node(t) }

func (t *HashMap_KeyIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *HashMap_KeyIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *HashMap_KeyIterator) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_KeyIterator) GetClass__Class() *Class { return HashMap_KeyIterator_class }

func (t *HashMap_KeyIterator) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_KeyIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_KeyIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_KeyIterator_InstanceOf(x any) bool { _, ok := x.(*HashMap_KeyIterator); return ok }

func HashMap_KeyIterator_Cast(x any) *HashMap_KeyIterator { if x == nil { return nil }; v, ok := x.(*HashMap_KeyIterator); if !ok { panic(ClassCast(x, HashMap_KeyIterator_class)) }; return v }



type HashMap_KeySet struct{ AbstractSet; F_this_0 HashMap_I }

func HashMap_KeySet_New_HashMap(p0 HashMap_I) *HashMap_KeySet { t := &HashMap_KeySet{}; t.Ctor_HashMap(p0); return t }

func (t *HashMap_KeySet) Ctor_HashMap(this_0 HashMap_I) { A2g_NotNull[HashMap_I](this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *HashMap_KeySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *HashMap_KeySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *HashMap_KeySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *HashMap_KeySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *HashMap_KeySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *HashMap_KeySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *HashMap_KeySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *HashMap_KeySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *HashMap_KeySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *HashMap_KeySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *HashMap_KeySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HashMap_KeySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HashMap_KeySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HashMap_KeySet) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_KeySet) GetClass__Class() *Class { return HashMap_KeySet_class }

func (t *HashMap_KeySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_KeySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_KeySet_InstanceOf(x any) bool { _, ok := x.(*HashMap_KeySet); return ok }

func HashMap_KeySet_Cast(x any) *HashMap_KeySet { if x == nil { return nil }; v, ok := x.(*HashMap_KeySet); if !ok { panic(ClassCast(x, HashMap_KeySet_class)) }; return v }



type HashMap_KeySpliterator struct{ HashMap_HashMapSpliterator }

func (t *HashMap_KeySpliterator) Is_Spliterator() {}

func (t *HashMap_KeySpliterator) TrySplit__Spliterator() Spliterator { return Up_HashMap_KeySpliterator_Spliterator(t.TrySplit__HashMap_KeySpliterator()) }

func (t *HashMap_KeySpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *HashMap_KeySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *HashMap_KeySpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *HashMap_KeySpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *HashMap_KeySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *HashMap_KeySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_KeySpliterator) GetClass__Class() *Class { return HashMap_KeySpliterator_class }

func (t *HashMap_KeySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_KeySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_KeySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_KeySpliterator_InstanceOf(x any) bool { _, ok := x.(*HashMap_KeySpliterator); return ok }

func HashMap_KeySpliterator_Cast(x any) *HashMap_KeySpliterator { if x == nil { return nil }; v, ok := x.(*HashMap_KeySpliterator); if !ok { panic(ClassCast(x, HashMap_KeySpliterator_class)) }; return v }



type HashMap_Node struct{ Object; F_hash int32; F_key, F_value any; F_next HashMap_Node_I }

type HashMap_Node_I interface{ Object_I; Map_Entry; Self_HashMap_Node() *HashMap_Node; GetKey__O() any; GetValue__O() any; SetValue_O__O(p0 any) any }

func (t *HashMap_Node) Self_HashMap_Node() *HashMap_Node { return t }

func (t *HashMap_Node) Is_Map_Entry() {}

func (t *HashMap_Node) GetKey__O() any { return t.Impl_GetKey__O(t) }

func (t *HashMap_Node) GetValue__O() any { return t.Impl_GetValue__O(t) }

func (t *HashMap_Node) SetValue_O__O(p0 any) any { return t.Impl_SetValue_O__O(t, p0) }

func (t *HashMap_Node) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HashMap_Node) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HashMap_Node) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HashMap_Node) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_Node) GetClass__Class() *Class { return HashMap_Node_class }

func (t *HashMap_Node) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_Node) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_Node_InstanceOf(x any) bool { _, ok := x.(HashMap_Node_I); return ok }

func HashMap_Node_Cast(x any) HashMap_Node_I { if x == nil { return nil }; v, ok := x.(HashMap_Node_I); if !ok { panic(ClassCast(x, HashMap_Node_class)) }; return v }



type HashMap_TreeNode struct{ LinkedHashMap_Entry; F_parent, F_left, F_right, F_prev *HashMap_TreeNode; F_red bool }

var HashMap_TreeNode_init ClassInit

func HashMap_TreeNode_Init() { if !HashMap_TreeNode_init.Done() { HashMap_TreeNode_init.Run(HashMap_TreeNode_clinit) } }

func HashMap_TreeNode_clinit() {}

func (t *HashMap_TreeNode) GetKey__O() any { return t.Impl_GetKey__O(t) }

func (t *HashMap_TreeNode) GetValue__O() any { return t.Impl_GetValue__O(t) }

func (t *HashMap_TreeNode) SetValue_O__O(p0 any) any { return t.Impl_SetValue_O__O(t, p0) }

func (t *HashMap_TreeNode) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HashMap_TreeNode) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HashMap_TreeNode) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HashMap_TreeNode) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_TreeNode) GetClass__Class() *Class { return HashMap_TreeNode_class }

func (t *HashMap_TreeNode) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_TreeNode) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_TreeNode_InstanceOf(x any) bool { _, ok := x.(*HashMap_TreeNode); return ok }

func HashMap_TreeNode_Cast(x any) *HashMap_TreeNode { if x == nil { return nil }; v, ok := x.(*HashMap_TreeNode); if !ok { panic(ClassCast(x, HashMap_TreeNode_class)) }; return v }



type HashMap_UnsafeHolder struct{ Object }

var HashMap_UnsafeHolder_unsafe *Unsafe

var HashMap_UnsafeHolder_LF_OFFSET int64

var HashMap_UnsafeHolder_init ClassInit

func HashMap_UnsafeHolder_Init() { if !HashMap_UnsafeHolder_init.Done() { HashMap_UnsafeHolder_init.Run(HashMap_UnsafeHolder_clinit) } }

func HashMap_UnsafeHolder_clinit() { HashMap_UnsafeHolder_unsafe = Unsafe_GetUnsafe__Unsafe(); HashMap_UnsafeHolder_LF_OFFSET = NN(HashMap_UnsafeHolder_unsafe).ObjectFieldOffset_Class_String__J(HashMap_class, Lit_2693) }

func (t *HashMap_UnsafeHolder) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_UnsafeHolder) GetClass__Class() *Class { return HashMap_UnsafeHolder_class }

func (t *HashMap_UnsafeHolder) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_UnsafeHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_UnsafeHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_UnsafeHolder_InstanceOf(x any) bool { _, ok := x.(*HashMap_UnsafeHolder); return ok }

func HashMap_UnsafeHolder_Cast(x any) *HashMap_UnsafeHolder { if x == nil { return nil }; v, ok := x.(*HashMap_UnsafeHolder); if !ok { panic(ClassCast(x, HashMap_UnsafeHolder_class)) }; return v }



type HashMap_ValueIterator struct{ HashMap_HashIterator; F_this_0 HashMap_I }

func (t *HashMap_ValueIterator) Is_Iterator() {}

func HashMap_ValueIterator_New_HashMap(p0 HashMap_I) *HashMap_ValueIterator { t := &HashMap_ValueIterator{}; t.Ctor_HashMap(p0); return t }

func (t *HashMap_ValueIterator) Ctor_HashMap(this_0 HashMap_I) { A2g_NotNull[HashMap_I](this_0); t.F_this_0 = this_0; t.HashMap_HashIterator.Ctor_HashMap(t, this_0) }

func (t *HashMap_ValueIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *HashMap_ValueIterator) NextNode__HashMap_Node() HashMap_Node_I { return t.Impl_NextNode__HashMap_Node(t) }

func (t *HashMap_ValueIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *HashMap_ValueIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *HashMap_ValueIterator) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_ValueIterator) GetClass__Class() *Class { return HashMap_ValueIterator_class }

func (t *HashMap_ValueIterator) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_ValueIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_ValueIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_ValueIterator_InstanceOf(x any) bool { _, ok := x.(*HashMap_ValueIterator); return ok }

func HashMap_ValueIterator_Cast(x any) *HashMap_ValueIterator { if x == nil { return nil }; v, ok := x.(*HashMap_ValueIterator); if !ok { panic(ClassCast(x, HashMap_ValueIterator_class)) }; return v }



type HashMap_ValueSpliterator struct{ HashMap_HashMapSpliterator }

func (t *HashMap_ValueSpliterator) Is_Spliterator() {}

func (t *HashMap_ValueSpliterator) TrySplit__Spliterator() Spliterator { return Up_HashMap_ValueSpliterator_Spliterator(t.TrySplit__HashMap_ValueSpliterator()) }

func (t *HashMap_ValueSpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *HashMap_ValueSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *HashMap_ValueSpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *HashMap_ValueSpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *HashMap_ValueSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *HashMap_ValueSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_ValueSpliterator) GetClass__Class() *Class { return HashMap_ValueSpliterator_class }

func (t *HashMap_ValueSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *HashMap_ValueSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_ValueSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_ValueSpliterator_InstanceOf(x any) bool { _, ok := x.(*HashMap_ValueSpliterator); return ok }

func HashMap_ValueSpliterator_Cast(x any) *HashMap_ValueSpliterator { if x == nil { return nil }; v, ok := x.(*HashMap_ValueSpliterator); if !ok { panic(ClassCast(x, HashMap_ValueSpliterator_class)) }; return v }



type HashMap_Values struct{ AbstractCollection; F_this_0 HashMap_I }

func HashMap_Values_New_HashMap(p0 HashMap_I) *HashMap_Values { t := &HashMap_Values{}; t.Ctor_HashMap(p0); return t }

func (t *HashMap_Values) Ctor_HashMap(this_0 HashMap_I) { A2g_NotNull[HashMap_I](this_0); t.F_this_0 = this_0; t.AbstractCollection.Ctor(t) }

func (t *HashMap_Values) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *HashMap_Values) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *HashMap_Values) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *HashMap_Values) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *HashMap_Values) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *HashMap_Values) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *HashMap_Values) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *HashMap_Values) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *HashMap_Values) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *HashMap_Values) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *HashMap_Values) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *HashMap_Values) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HashMap_Values) Ref() any { if t == nil { return nil }; return t }

func (t *HashMap_Values) GetClass__Class() *Class { return HashMap_Values_class }

func (t *HashMap_Values) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HashMap_Values) CloneShallow() any { panic(CloneNotSupported(t)) }

func HashMap_Values_InstanceOf(x any) bool { _, ok := x.(*HashMap_Values); return ok }

func HashMap_Values_Cast(x any) *HashMap_Values { if x == nil { return nil }; v, ok := x.(*HashMap_Values); if !ok { panic(ClassCast(x, HashMap_Values_class)) }; return v }
