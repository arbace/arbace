//line a2g_lambdas.ae:1
package jrt






type ObjLongConsumer_Fn struct{ Object; Fn func(any, int64) }

func (t *ObjLongConsumer_Fn) Accept_O_J__V(p0 any, p1 int64) { t.Fn(p0, p1) }

func (t *ObjLongConsumer_Fn) Is_ObjLongConsumer() {}

func (t *ObjLongConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ObjLongConsumer_Fn) GetClass__Class() *Class { return ObjLongConsumer_Fn_class }

func (t *ObjLongConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ObjLongConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ObjLongConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.ObjLongConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ObjLongConsumer_class}, Go: "arbace/jrt.ObjLongConsumer_Fn"})



type Pattern_CharPredicate_Fn struct{ Object; Fn func(int32) bool }

func (t *Pattern_CharPredicate_Fn) Is_I__Z(p0 int32) bool { return t.Fn(p0) }

func (t *Pattern_CharPredicate_Fn) Is_Pattern_CharPredicate() {}

func (t *Pattern_CharPredicate_Fn) And_Pattern_CharPredicate__Pattern_CharPredicate(p0 Pattern_CharPredicate) Pattern_CharPredicate { return Pattern_CharPredicate_And_Pattern_CharPredicate__Pattern_CharPredicate(t, p0) }

func (t *Pattern_CharPredicate_Fn) Union_Pattern_CharPredicate__Pattern_CharPredicate(p0 Pattern_CharPredicate) Pattern_CharPredicate { return Pattern_CharPredicate_Union_Pattern_CharPredicate__Pattern_CharPredicate(t, p0) }

func (t *Pattern_CharPredicate_Fn) Union_Pattern_CharPredicate_Pattern_CharPredicate__Pattern_CharPredicate(p0, p1 Pattern_CharPredicate) Pattern_CharPredicate { return Pattern_CharPredicate_Union_Pattern_CharPredicate_Pattern_CharPredicate__Pattern_CharPredicate(t, p0, p1) }

func (t *Pattern_CharPredicate_Fn) Negate__Pattern_CharPredicate() Pattern_CharPredicate { return Pattern_CharPredicate_Negate__Pattern_CharPredicate(t) }

func (t *Pattern_CharPredicate_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Pattern_CharPredicate_Fn) GetClass__Class() *Class { return Pattern_CharPredicate_Fn_class }

func (t *Pattern_CharPredicate_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Pattern_CharPredicate_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Pattern_CharPredicate_Fn_class = Define(&ClassInfo{Name: "java.util.regex.Pattern$CharPredicate$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Pattern_CharPredicate_class}, Go: "arbace/jrt.Pattern_CharPredicate_Fn"})



type BiFunction_Fn struct{ Object; Fn func(any, any) any }

func (t *BiFunction_Fn) Apply_O_O__O(p0, p1 any) any { return t.Fn(p0, p1) }

func (t *BiFunction_Fn) Is_BiFunction() {}

func (t *BiFunction_Fn) AndThen_Function__BiFunction(p0 Function) BiFunction { return BiFunction_AndThen_Function__BiFunction(t, p0) }

func (t *BiFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *BiFunction_Fn) GetClass__Class() *Class { return BiFunction_Fn_class }

func (t *BiFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *BiFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var BiFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.BiFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{BiFunction_class}, Go: "arbace/jrt.BiFunction_Fn"})



type Sink_Fn struct{ Object; Fn func(any) }

func (t *Sink_Fn) Accept_O__V(p0 any) { t.Fn(p0) }

func (t *Sink_Fn) Is_Sink() {}

func (t *Sink_Fn) Is_Consumer() {}

func (t *Sink_Fn) Begin_J__V(p0 int64) { Sink_Begin_J__V(t, p0) }

func (t *Sink_Fn) End__V() { Sink_End__V(t) }

func (t *Sink_Fn) CancellationRequested__Z() bool { return Sink_CancellationRequested__Z(t) }

func (t *Sink_Fn) Accept_I__V(p0 int32) { Sink_Accept_I__V(t, p0) }

func (t *Sink_Fn) Accept_J__V(p0 int64) { Sink_Accept_J__V(t, p0) }

func (t *Sink_Fn) Accept_D__V(p0 float64) { Sink_Accept_D__V(t, p0) }

func (t *Sink_Fn) AndThen_Consumer__Consumer(p0 Consumer) Consumer { return Consumer_AndThen_Consumer__Consumer(t, p0) }

func (t *Sink_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Sink_Fn) GetClass__Class() *Class { return Sink_Fn_class }

func (t *Sink_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Sink_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Sink_Fn_class = Define(&ClassInfo{Name: "java.util.stream.Sink$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Sink_class}, Go: "arbace/jrt.Sink_Fn"})



type Supplier_Fn struct{ Object; Fn func() any }

func (t *Supplier_Fn) Get__O() any { return t.Fn() }

func (t *Supplier_Fn) Is_Supplier() {}

func (t *Supplier_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Supplier_Fn) GetClass__Class() *Class { return Supplier_Fn_class }

func (t *Supplier_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Supplier_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Supplier_Fn_class = Define(&ClassInfo{Name: "java.util.function.Supplier$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Supplier_class}, Go: "arbace/jrt.Supplier_Fn"})



type LongBinaryOperator_Fn struct{ Object; Fn func(int64, int64) int64 }

func (t *LongBinaryOperator_Fn) ApplyAsLong_J_J__J(p0, p1 int64) int64 { return t.Fn(p0, p1) }

func (t *LongBinaryOperator_Fn) Is_LongBinaryOperator() {}

func (t *LongBinaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongBinaryOperator_Fn) GetClass__Class() *Class { return LongBinaryOperator_Fn_class }

func (t *LongBinaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongBinaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongBinaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongBinaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongBinaryOperator_class}, Go: "arbace/jrt.LongBinaryOperator_Fn"})



type BooleanSupplier_Fn struct{ Object; Fn func() bool }

func (t *BooleanSupplier_Fn) GetAsBoolean__Z() bool { return t.Fn() }

func (t *BooleanSupplier_Fn) Is_BooleanSupplier() {}

func (t *BooleanSupplier_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *BooleanSupplier_Fn) GetClass__Class() *Class { return BooleanSupplier_Fn_class }

func (t *BooleanSupplier_Fn) ToString__String() *String { return Object_toString(t) }

func (t *BooleanSupplier_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var BooleanSupplier_Fn_class = Define(&ClassInfo{Name: "java.util.function.BooleanSupplier$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{BooleanSupplier_class}, Go: "arbace/jrt.BooleanSupplier_Fn"})



type DoubleUnaryOperator_Fn struct{ Object; Fn func(float64) float64 }

func (t *DoubleUnaryOperator_Fn) ApplyAsDouble_D__D(p0 float64) float64 { return t.Fn(p0) }

func (t *DoubleUnaryOperator_Fn) Is_DoubleUnaryOperator() {}

func (t *DoubleUnaryOperator_Fn) Compose_DoubleUnaryOperator__DoubleUnaryOperator(p0 DoubleUnaryOperator) DoubleUnaryOperator { return DoubleUnaryOperator_Compose_DoubleUnaryOperator__DoubleUnaryOperator(t, p0) }

func (t *DoubleUnaryOperator_Fn) AndThen_DoubleUnaryOperator__DoubleUnaryOperator(p0 DoubleUnaryOperator) DoubleUnaryOperator { return DoubleUnaryOperator_AndThen_DoubleUnaryOperator__DoubleUnaryOperator(t, p0) }

func (t *DoubleUnaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleUnaryOperator_Fn) GetClass__Class() *Class { return DoubleUnaryOperator_Fn_class }

func (t *DoubleUnaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleUnaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleUnaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoubleUnaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleUnaryOperator_class}, Go: "arbace/jrt.DoubleUnaryOperator_Fn"})



type BiConsumer_Fn struct{ Object; Fn func(any, any) }

func (t *BiConsumer_Fn) Accept_O_O__V(p0, p1 any) { t.Fn(p0, p1) }

func (t *BiConsumer_Fn) Is_BiConsumer() {}

func (t *BiConsumer_Fn) AndThen_BiConsumer__BiConsumer(p0 BiConsumer) BiConsumer { return BiConsumer_AndThen_BiConsumer__BiConsumer(t, p0) }

func (t *BiConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *BiConsumer_Fn) GetClass__Class() *Class { return BiConsumer_Fn_class }

func (t *BiConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *BiConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var BiConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.BiConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{BiConsumer_class}, Go: "arbace/jrt.BiConsumer_Fn"})



type IntFunction_Fn struct{ Object; Fn func(int32) any }

func (t *IntFunction_Fn) Apply_I__O(p0 int32) any { return t.Fn(p0) }

func (t *IntFunction_Fn) Is_IntFunction() {}

func (t *IntFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntFunction_Fn) GetClass__Class() *Class { return IntFunction_Fn_class }

func (t *IntFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntFunction_class}, Go: "arbace/jrt.IntFunction_Fn"})



type Pattern_BmpCharPredicate_Fn struct{ Object; Fn func(int32) bool }

func (t *Pattern_BmpCharPredicate_Fn) Is_I__Z(p0 int32) bool { return t.Fn(p0) }

func (t *Pattern_BmpCharPredicate_Fn) Is_Pattern_BmpCharPredicate() {}

func (t *Pattern_BmpCharPredicate_Fn) Is_Pattern_CharPredicate() {}

func (t *Pattern_BmpCharPredicate_Fn) And_Pattern_CharPredicate__Pattern_CharPredicate(p0 Pattern_CharPredicate) Pattern_CharPredicate { return Pattern_BmpCharPredicate_And_Pattern_CharPredicate__Pattern_CharPredicate(t, p0) }

func (t *Pattern_BmpCharPredicate_Fn) Union_Pattern_CharPredicate__Pattern_CharPredicate(p0 Pattern_CharPredicate) Pattern_CharPredicate { return Pattern_BmpCharPredicate_Union_Pattern_CharPredicate__Pattern_CharPredicate(t, p0) }

func (t *Pattern_BmpCharPredicate_Fn) Union_Pattern_CharPredicate_Pattern_CharPredicate__Pattern_CharPredicate(p0, p1 Pattern_CharPredicate) Pattern_CharPredicate { return Pattern_BmpCharPredicate_Union_Pattern_CharPredicate_Pattern_CharPredicate__Pattern_CharPredicate(t, p0, p1) }

func (t *Pattern_BmpCharPredicate_Fn) Negate__Pattern_CharPredicate() Pattern_CharPredicate { return Pattern_CharPredicate_Negate__Pattern_CharPredicate(t) }

func (t *Pattern_BmpCharPredicate_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Pattern_BmpCharPredicate_Fn) GetClass__Class() *Class { return Pattern_BmpCharPredicate_Fn_class }

func (t *Pattern_BmpCharPredicate_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Pattern_BmpCharPredicate_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Pattern_BmpCharPredicate_Fn_class = Define(&ClassInfo{Name: "java.util.regex.Pattern$BmpCharPredicate$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Pattern_BmpCharPredicate_class}, Go: "arbace/jrt.Pattern_BmpCharPredicate_Fn"})



type LongFunction_Fn struct{ Object; Fn func(int64) any }

func (t *LongFunction_Fn) Apply_J__O(p0 int64) any { return t.Fn(p0) }

func (t *LongFunction_Fn) Is_LongFunction() {}

func (t *LongFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongFunction_Fn) GetClass__Class() *Class { return LongFunction_Fn_class }

func (t *LongFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongFunction_class}, Go: "arbace/jrt.LongFunction_Fn"})



type LongConsumer_Fn struct{ Object; Fn func(int64) }

func (t *LongConsumer_Fn) Accept_J__V(p0 int64) { t.Fn(p0) }

func (t *LongConsumer_Fn) Is_LongConsumer() {}

func (t *LongConsumer_Fn) AndThen_LongConsumer__LongConsumer(p0 LongConsumer) LongConsumer { return LongConsumer_AndThen_LongConsumer__LongConsumer(t, p0) }

func (t *LongConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongConsumer_Fn) GetClass__Class() *Class { return LongConsumer_Fn_class }

func (t *LongConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongConsumer_class}, Go: "arbace/jrt.LongConsumer_Fn"})



type Comparator_Fn_Serializable struct{ Object; Fn func(any, any) int32 }

func (t *Comparator_Fn_Serializable) Compare_O_O__I(p0, p1 any) int32 { return t.Fn(p0, p1) }

func (t *Comparator_Fn_Serializable) Is_Comparator() {}

func (t *Comparator_Fn_Serializable) Is_Serializable() {}

func (t *Comparator_Fn_Serializable) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *Comparator_Fn_Serializable) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *Comparator_Fn_Serializable) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *Comparator_Fn_Serializable) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *Comparator_Fn_Serializable) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *Comparator_Fn_Serializable) Reversed__Comparator() Comparator { return Comparator_Reversed__Comparator(t) }

func (t *Comparator_Fn_Serializable) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *Comparator_Fn_Serializable) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *Comparator_Fn_Serializable) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *Comparator_Fn_Serializable) Ref() any { if t == nil { return nil }; return t }

func (t *Comparator_Fn_Serializable) GetClass__Class() *Class { return Comparator_Fn_Serializable_class }

func (t *Comparator_Fn_Serializable) ToString__String() *String { return Object_toString(t) }

func (t *Comparator_Fn_Serializable) Clone__O() any { panic(CloneNotSupported(t)) }

var Comparator_Fn_Serializable_class = Define(&ClassInfo{Name: "java.util.Comparator$$Lambda$Serializable", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Comparator_class, Serializable_class}, Go: "arbace/jrt.Comparator_Fn_Serializable"})



type TemporalAdjuster_Fn struct{ Object; Fn func(Temporal) Temporal }

func (t *TemporalAdjuster_Fn) AdjustInto_Temporal__Temporal(p0 Temporal) Temporal { return t.Fn(p0) }

func (t *TemporalAdjuster_Fn) Is_TemporalAdjuster() {}

func (t *TemporalAdjuster_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalAdjuster_Fn) GetClass__Class() *Class { return TemporalAdjuster_Fn_class }

func (t *TemporalAdjuster_Fn) ToString__String() *String { return Object_toString(t) }

func (t *TemporalAdjuster_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var TemporalAdjuster_Fn_class = Define(&ClassInfo{Name: "java.time.temporal.TemporalAdjuster$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{TemporalAdjuster_class}, Go: "arbace/jrt.TemporalAdjuster_Fn"})



type ObjIntConsumer_Fn struct{ Object; Fn func(any, int32) }

func (t *ObjIntConsumer_Fn) Accept_O_I__V(p0 any, p1 int32) { t.Fn(p0, p1) }

func (t *ObjIntConsumer_Fn) Is_ObjIntConsumer() {}

func (t *ObjIntConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ObjIntConsumer_Fn) GetClass__Class() *Class { return ObjIntConsumer_Fn_class }

func (t *ObjIntConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ObjIntConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ObjIntConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.ObjIntConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ObjIntConsumer_class}, Go: "arbace/jrt.ObjIntConsumer_Fn"})



type DualPivotQuicksort_SortOperation_Fn struct{ Object; Fn func(any, int32, int32) }

func (t *DualPivotQuicksort_SortOperation_Fn) Sort_O_I_I__V(p0 any, p1, p2 int32) { t.Fn(p0, p1, p2) }

func (t *DualPivotQuicksort_SortOperation_Fn) Is_DualPivotQuicksort_SortOperation() {}

func (t *DualPivotQuicksort_SortOperation_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DualPivotQuicksort_SortOperation_Fn) GetClass__Class() *Class { return DualPivotQuicksort_SortOperation_Fn_class }

func (t *DualPivotQuicksort_SortOperation_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DualPivotQuicksort_SortOperation_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DualPivotQuicksort_SortOperation_Fn_class = Define(&ClassInfo{Name: "java.util.DualPivotQuicksort$SortOperation$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DualPivotQuicksort_SortOperation_class}, Go: "arbace/jrt.DualPivotQuicksort_SortOperation_Fn"})



type DoubleBinaryOperator_Fn struct{ Object; Fn func(float64, float64) float64 }

func (t *DoubleBinaryOperator_Fn) ApplyAsDouble_D_D__D(p0, p1 float64) float64 { return t.Fn(p0, p1) }

func (t *DoubleBinaryOperator_Fn) Is_DoubleBinaryOperator() {}

func (t *DoubleBinaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleBinaryOperator_Fn) GetClass__Class() *Class { return DoubleBinaryOperator_Fn_class }

func (t *DoubleBinaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleBinaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleBinaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoubleBinaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleBinaryOperator_class}, Go: "arbace/jrt.DoubleBinaryOperator_Fn"})



type DoublePredicate_Fn struct{ Object; Fn func(float64) bool }

func (t *DoublePredicate_Fn) Test_D__Z(p0 float64) bool { return t.Fn(p0) }

func (t *DoublePredicate_Fn) Is_DoublePredicate() {}

func (t *DoublePredicate_Fn) And_DoublePredicate__DoublePredicate(p0 DoublePredicate) DoublePredicate { return DoublePredicate_And_DoublePredicate__DoublePredicate(t, p0) }

func (t *DoublePredicate_Fn) Negate__DoublePredicate() DoublePredicate { return DoublePredicate_Negate__DoublePredicate(t) }

func (t *DoublePredicate_Fn) Or_DoublePredicate__DoublePredicate(p0 DoublePredicate) DoublePredicate { return DoublePredicate_Or_DoublePredicate__DoublePredicate(t, p0) }

func (t *DoublePredicate_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoublePredicate_Fn) GetClass__Class() *Class { return DoublePredicate_Fn_class }

func (t *DoublePredicate_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoublePredicate_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoublePredicate_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoublePredicate$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoublePredicate_class}, Go: "arbace/jrt.DoublePredicate_Fn"})



type IntBinaryOperator_Fn struct{ Object; Fn func(int32, int32) int32 }

func (t *IntBinaryOperator_Fn) ApplyAsInt_I_I__I(p0, p1 int32) int32 { return t.Fn(p0, p1) }

func (t *IntBinaryOperator_Fn) Is_IntBinaryOperator() {}

func (t *IntBinaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntBinaryOperator_Fn) GetClass__Class() *Class { return IntBinaryOperator_Fn_class }

func (t *IntBinaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntBinaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntBinaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntBinaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntBinaryOperator_class}, Go: "arbace/jrt.IntBinaryOperator_Fn"})



type Function_Fn struct{ Object; Fn func(any) any }

func (t *Function_Fn) Apply_O__O(p0 any) any { return t.Fn(p0) }

func (t *Function_Fn) Is_Function() {}

func (t *Function_Fn) Compose_Function__Function(p0 Function) Function { return Function_Compose_Function__Function(t, p0) }

func (t *Function_Fn) AndThen_Function__Function(p0 Function) Function { return Function_AndThen_Function__Function(t, p0) }

func (t *Function_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Function_Fn) GetClass__Class() *Class { return Function_Fn_class }

func (t *Function_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Function_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Function_Fn_class = Define(&ClassInfo{Name: "java.util.function.Function$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Function_class}, Go: "arbace/jrt.Function_Fn"})



type DoubleFunction_Fn struct{ Object; Fn func(float64) any }

func (t *DoubleFunction_Fn) Apply_D__O(p0 float64) any { return t.Fn(p0) }

func (t *DoubleFunction_Fn) Is_DoubleFunction() {}

func (t *DoubleFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleFunction_Fn) GetClass__Class() *Class { return DoubleFunction_Fn_class }

func (t *DoubleFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoubleFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleFunction_class}, Go: "arbace/jrt.DoubleFunction_Fn"})



type Gatherer_Integrator_Greedy_Fn struct{ Object; Fn func(any, any, Gatherer_Downstream) bool }

func (t *Gatherer_Integrator_Greedy_Fn) Integrate_O_O_Gatherer_Downstream__Z(p0, p1 any, p2 Gatherer_Downstream) bool { return t.Fn(p0, p1, p2) }

func (t *Gatherer_Integrator_Greedy_Fn) Is_Gatherer_Integrator_Greedy() {}

func (t *Gatherer_Integrator_Greedy_Fn) Is_Gatherer_Integrator() {}

func (t *Gatherer_Integrator_Greedy_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Gatherer_Integrator_Greedy_Fn) GetClass__Class() *Class { return Gatherer_Integrator_Greedy_Fn_class }

func (t *Gatherer_Integrator_Greedy_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Gatherer_Integrator_Greedy_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Gatherer_Integrator_Greedy_Fn_class = Define(&ClassInfo{Name: "java.util.stream.Gatherer$Integrator$Greedy$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Gatherer_Integrator_Greedy_class}, Go: "arbace/jrt.Gatherer_Integrator_Greedy_Fn"})



type BinaryOperator_Fn struct{ Object; Fn func(any, any) any }

func (t *BinaryOperator_Fn) Apply_O_O__O(p0, p1 any) any { return t.Fn(p0, p1) }

func (t *BinaryOperator_Fn) Is_BinaryOperator() {}

func (t *BinaryOperator_Fn) Is_BiFunction() {}

func (t *BinaryOperator_Fn) AndThen_Function__BiFunction(p0 Function) BiFunction { return BiFunction_AndThen_Function__BiFunction(t, p0) }

func (t *BinaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *BinaryOperator_Fn) GetClass__Class() *Class { return BinaryOperator_Fn_class }

func (t *BinaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *BinaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var BinaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.BinaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{BinaryOperator_class}, Go: "arbace/jrt.BinaryOperator_Fn"})



type Sink_OfInt_Fn struct{ Object; Fn func(int32) }

func (t *Sink_OfInt_Fn) Accept_I__V(p0 int32) { t.Fn(p0) }

func (t *Sink_OfInt_Fn) Is_Sink_OfInt() {}

func (t *Sink_OfInt_Fn) Is_Sink() {}

func (t *Sink_OfInt_Fn) Is_IntConsumer() {}

func (t *Sink_OfInt_Fn) Is_Consumer() {}

func (t *Sink_OfInt_Fn) Begin_J__V(p0 int64) { Sink_Begin_J__V(t, p0) }

func (t *Sink_OfInt_Fn) Accept_O__V(p0 any) { Sink_OfInt_Accept_O__V(t, p0) }

func (t *Sink_OfInt_Fn) Accept_J__V(p0 int64) { Sink_Accept_J__V(t, p0) }

func (t *Sink_OfInt_Fn) AndThen_IntConsumer__IntConsumer(p0 IntConsumer) IntConsumer { return IntConsumer_AndThen_IntConsumer__IntConsumer(t, p0) }

func (t *Sink_OfInt_Fn) Accept_D__V(p0 float64) { Sink_Accept_D__V(t, p0) }

func (t *Sink_OfInt_Fn) AndThen_Consumer__Consumer(p0 Consumer) Consumer { return Consumer_AndThen_Consumer__Consumer(t, p0) }

func (t *Sink_OfInt_Fn) End__V() { Sink_End__V(t) }

func (t *Sink_OfInt_Fn) Accept_Integer__V(p0 *Integer) { Sink_OfInt_Accept_Integer__V(t, p0) }

func (t *Sink_OfInt_Fn) CancellationRequested__Z() bool { return Sink_CancellationRequested__Z(t) }

func (t *Sink_OfInt_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Sink_OfInt_Fn) GetClass__Class() *Class { return Sink_OfInt_Fn_class }

func (t *Sink_OfInt_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Sink_OfInt_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Sink_OfInt_Fn_class = Define(&ClassInfo{Name: "java.util.stream.Sink$OfInt$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Sink_OfInt_class}, Go: "arbace/jrt.Sink_OfInt_Fn"})



type Comparator_Fn struct{ Object; Fn func(any, any) int32 }

func (t *Comparator_Fn) Compare_O_O__I(p0, p1 any) int32 { return t.Fn(p0, p1) }

func (t *Comparator_Fn) Is_Comparator() {}

func (t *Comparator_Fn) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *Comparator_Fn) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *Comparator_Fn) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *Comparator_Fn) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *Comparator_Fn) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *Comparator_Fn) Reversed__Comparator() Comparator { return Comparator_Reversed__Comparator(t) }

func (t *Comparator_Fn) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *Comparator_Fn) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *Comparator_Fn) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *Comparator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Comparator_Fn) GetClass__Class() *Class { return Comparator_Fn_class }

func (t *Comparator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Comparator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Comparator_Fn_class = Define(&ClassInfo{Name: "java.util.Comparator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Comparator_class}, Go: "arbace/jrt.Comparator_Fn"})



type ObjDoubleConsumer_Fn struct{ Object; Fn func(any, float64) }

func (t *ObjDoubleConsumer_Fn) Accept_O_D__V(p0 any, p1 float64) { t.Fn(p0, p1) }

func (t *ObjDoubleConsumer_Fn) Is_ObjDoubleConsumer() {}

func (t *ObjDoubleConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ObjDoubleConsumer_Fn) GetClass__Class() *Class { return ObjDoubleConsumer_Fn_class }

func (t *ObjDoubleConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ObjDoubleConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ObjDoubleConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.ObjDoubleConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ObjDoubleConsumer_class}, Go: "arbace/jrt.ObjDoubleConsumer_Fn"})



type DualPivotQuicksort_PartitionOperation_Fn struct{ Object; Fn func(any, int32, int32, int32, int32) *IntArray }

func (t *DualPivotQuicksort_PartitionOperation_Fn) Partition_O_I_I_I_I__I1(p0 any, p1, p2, p3, p4 int32) *IntArray { return t.Fn(p0, p1, p2, p3, p4) }

func (t *DualPivotQuicksort_PartitionOperation_Fn) Is_DualPivotQuicksort_PartitionOperation() {}

func (t *DualPivotQuicksort_PartitionOperation_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DualPivotQuicksort_PartitionOperation_Fn) GetClass__Class() *Class { return DualPivotQuicksort_PartitionOperation_Fn_class }

func (t *DualPivotQuicksort_PartitionOperation_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DualPivotQuicksort_PartitionOperation_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DualPivotQuicksort_PartitionOperation_Fn_class = Define(&ClassInfo{Name: "java.util.DualPivotQuicksort$PartitionOperation$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DualPivotQuicksort_PartitionOperation_class}, Go: "arbace/jrt.DualPivotQuicksort_PartitionOperation_Fn"})



type Predicate_Fn struct{ Object; Fn func(any) bool }

func (t *Predicate_Fn) Test_O__Z(p0 any) bool { return t.Fn(p0) }

func (t *Predicate_Fn) Is_Predicate() {}

func (t *Predicate_Fn) And_Predicate__Predicate(p0 Predicate) Predicate { return Predicate_And_Predicate__Predicate(t, p0) }

func (t *Predicate_Fn) Negate__Predicate() Predicate { return Predicate_Negate__Predicate(t) }

func (t *Predicate_Fn) Or_Predicate__Predicate(p0 Predicate) Predicate { return Predicate_Or_Predicate__Predicate(t, p0) }

func (t *Predicate_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Predicate_Fn) GetClass__Class() *Class { return Predicate_Fn_class }

func (t *Predicate_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Predicate_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Predicate_Fn_class = Define(&ClassInfo{Name: "java.util.function.Predicate$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Predicate_class}, Go: "arbace/jrt.Predicate_Fn"})



type LongPredicate_Fn struct{ Object; Fn func(int64) bool }

func (t *LongPredicate_Fn) Test_J__Z(p0 int64) bool { return t.Fn(p0) }

func (t *LongPredicate_Fn) Is_LongPredicate() {}

func (t *LongPredicate_Fn) And_LongPredicate__LongPredicate(p0 LongPredicate) LongPredicate { return LongPredicate_And_LongPredicate__LongPredicate(t, p0) }

func (t *LongPredicate_Fn) Negate__LongPredicate() LongPredicate { return LongPredicate_Negate__LongPredicate(t) }

func (t *LongPredicate_Fn) Or_LongPredicate__LongPredicate(p0 LongPredicate) LongPredicate { return LongPredicate_Or_LongPredicate__LongPredicate(t, p0) }

func (t *LongPredicate_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongPredicate_Fn) GetClass__Class() *Class { return LongPredicate_Fn_class }

func (t *LongPredicate_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongPredicate_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongPredicate_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongPredicate$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongPredicate_class}, Go: "arbace/jrt.LongPredicate_Fn"})



type Consumer_Fn struct{ Object; Fn func(any) }

func (t *Consumer_Fn) Accept_O__V(p0 any) { t.Fn(p0) }

func (t *Consumer_Fn) Is_Consumer() {}

func (t *Consumer_Fn) AndThen_Consumer__Consumer(p0 Consumer) Consumer { return Consumer_AndThen_Consumer__Consumer(t, p0) }

func (t *Consumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Consumer_Fn) GetClass__Class() *Class { return Consumer_Fn_class }

func (t *Consumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Consumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Consumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.Consumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Consumer_class}, Go: "arbace/jrt.Consumer_Fn"})



type LongSupplier_Fn struct{ Object; Fn func() int64 }

func (t *LongSupplier_Fn) GetAsLong__J() int64 { return t.Fn() }

func (t *LongSupplier_Fn) Is_LongSupplier() {}

func (t *LongSupplier_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongSupplier_Fn) GetClass__Class() *Class { return LongSupplier_Fn_class }

func (t *LongSupplier_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongSupplier_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongSupplier_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongSupplier$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongSupplier_class}, Go: "arbace/jrt.LongSupplier_Fn"})



type UnaryOperator_Fn struct{ Object; Fn func(any) any }

func (t *UnaryOperator_Fn) Apply_O__O(p0 any) any { return t.Fn(p0) }

func (t *UnaryOperator_Fn) Is_UnaryOperator() {}

func (t *UnaryOperator_Fn) Is_Function() {}

func (t *UnaryOperator_Fn) Compose_Function__Function(p0 Function) Function { return Function_Compose_Function__Function(t, p0) }

func (t *UnaryOperator_Fn) AndThen_Function__Function(p0 Function) Function { return Function_AndThen_Function__Function(t, p0) }

func (t *UnaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *UnaryOperator_Fn) GetClass__Class() *Class { return UnaryOperator_Fn_class }

func (t *UnaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *UnaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var UnaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.UnaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{UnaryOperator_class}, Go: "arbace/jrt.UnaryOperator_Fn"})



type Runnable_Fn struct{ Object; Fn func() }

func (t *Runnable_Fn) Run__V() { t.Fn() }

func (t *Runnable_Fn) Is_Runnable() {}

func (t *Runnable_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Runnable_Fn) GetClass__Class() *Class { return Runnable_Fn_class }

func (t *Runnable_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Runnable_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Runnable_Fn_class = Define(&ClassInfo{Name: "java.lang.Runnable$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Runnable_class}, Go: "arbace/jrt.Runnable_Fn"})



type Gatherer_Integrator_Fn struct{ Object; Fn func(any, any, Gatherer_Downstream) bool }

func (t *Gatherer_Integrator_Fn) Integrate_O_O_Gatherer_Downstream__Z(p0, p1 any, p2 Gatherer_Downstream) bool { return t.Fn(p0, p1, p2) }

func (t *Gatherer_Integrator_Fn) Is_Gatherer_Integrator() {}

func (t *Gatherer_Integrator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Gatherer_Integrator_Fn) GetClass__Class() *Class { return Gatherer_Integrator_Fn_class }

func (t *Gatherer_Integrator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Gatherer_Integrator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Gatherer_Integrator_Fn_class = Define(&ClassInfo{Name: "java.util.stream.Gatherer$Integrator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Gatherer_Integrator_class}, Go: "arbace/jrt.Gatherer_Integrator_Fn"})



type BiPredicate_Fn struct{ Object; Fn func(any, any) bool }

func (t *BiPredicate_Fn) Test_O_O__Z(p0, p1 any) bool { return t.Fn(p0, p1) }

func (t *BiPredicate_Fn) Is_BiPredicate() {}

func (t *BiPredicate_Fn) And_BiPredicate__BiPredicate(p0 BiPredicate) BiPredicate { return BiPredicate_And_BiPredicate__BiPredicate(t, p0) }

func (t *BiPredicate_Fn) Negate__BiPredicate() BiPredicate { return BiPredicate_Negate__BiPredicate(t) }

func (t *BiPredicate_Fn) Or_BiPredicate__BiPredicate(p0 BiPredicate) BiPredicate { return BiPredicate_Or_BiPredicate__BiPredicate(t, p0) }

func (t *BiPredicate_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *BiPredicate_Fn) GetClass__Class() *Class { return BiPredicate_Fn_class }

func (t *BiPredicate_Fn) ToString__String() *String { return Object_toString(t) }

func (t *BiPredicate_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var BiPredicate_Fn_class = Define(&ClassInfo{Name: "java.util.function.BiPredicate$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{BiPredicate_class}, Go: "arbace/jrt.BiPredicate_Fn"})



type IntUnaryOperator_Fn struct{ Object; Fn func(int32) int32 }

func (t *IntUnaryOperator_Fn) ApplyAsInt_I__I(p0 int32) int32 { return t.Fn(p0) }

func (t *IntUnaryOperator_Fn) Is_IntUnaryOperator() {}

func (t *IntUnaryOperator_Fn) Compose_IntUnaryOperator__IntUnaryOperator(p0 IntUnaryOperator) IntUnaryOperator { return IntUnaryOperator_Compose_IntUnaryOperator__IntUnaryOperator(t, p0) }

func (t *IntUnaryOperator_Fn) AndThen_IntUnaryOperator__IntUnaryOperator(p0 IntUnaryOperator) IntUnaryOperator { return IntUnaryOperator_AndThen_IntUnaryOperator__IntUnaryOperator(t, p0) }

func (t *IntUnaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntUnaryOperator_Fn) GetClass__Class() *Class { return IntUnaryOperator_Fn_class }

func (t *IntUnaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntUnaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntUnaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntUnaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntUnaryOperator_class}, Go: "arbace/jrt.IntUnaryOperator_Fn"})



type DoubleConsumer_Fn struct{ Object; Fn func(float64) }

func (t *DoubleConsumer_Fn) Accept_D__V(p0 float64) { t.Fn(p0) }

func (t *DoubleConsumer_Fn) Is_DoubleConsumer() {}

func (t *DoubleConsumer_Fn) AndThen_DoubleConsumer__DoubleConsumer(p0 DoubleConsumer) DoubleConsumer { return DoubleConsumer_AndThen_DoubleConsumer__DoubleConsumer(t, p0) }

func (t *DoubleConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleConsumer_Fn) GetClass__Class() *Class { return DoubleConsumer_Fn_class }

func (t *DoubleConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoubleConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleConsumer_class}, Go: "arbace/jrt.DoubleConsumer_Fn"})



type IntSupplier_Fn struct{ Object; Fn func() int32 }

func (t *IntSupplier_Fn) GetAsInt__I() int32 { return t.Fn() }

func (t *IntSupplier_Fn) Is_IntSupplier() {}

func (t *IntSupplier_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntSupplier_Fn) GetClass__Class() *Class { return IntSupplier_Fn_class }

func (t *IntSupplier_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntSupplier_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntSupplier_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntSupplier$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntSupplier_class}, Go: "arbace/jrt.IntSupplier_Fn"})



type IntPredicate_Fn struct{ Object; Fn func(int32) bool }

func (t *IntPredicate_Fn) Test_I__Z(p0 int32) bool { return t.Fn(p0) }

func (t *IntPredicate_Fn) Is_IntPredicate() {}

func (t *IntPredicate_Fn) And_IntPredicate__IntPredicate(p0 IntPredicate) IntPredicate { return IntPredicate_And_IntPredicate__IntPredicate(t, p0) }

func (t *IntPredicate_Fn) Negate__IntPredicate() IntPredicate { return IntPredicate_Negate__IntPredicate(t) }

func (t *IntPredicate_Fn) Or_IntPredicate__IntPredicate(p0 IntPredicate) IntPredicate { return IntPredicate_Or_IntPredicate__IntPredicate(t, p0) }

func (t *IntPredicate_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntPredicate_Fn) GetClass__Class() *Class { return IntPredicate_Fn_class }

func (t *IntPredicate_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntPredicate_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntPredicate_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntPredicate$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntPredicate_class}, Go: "arbace/jrt.IntPredicate_Fn"})



type Gatherer_Downstream_Fn struct{ Object; Fn func(any) bool }

func (t *Gatherer_Downstream_Fn) Push_O__Z(p0 any) bool { return t.Fn(p0) }

func (t *Gatherer_Downstream_Fn) Is_Gatherer_Downstream() {}

func (t *Gatherer_Downstream_Fn) IsRejecting__Z() bool { return Gatherer_Downstream_IsRejecting__Z(t) }

func (t *Gatherer_Downstream_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Gatherer_Downstream_Fn) GetClass__Class() *Class { return Gatherer_Downstream_Fn_class }

func (t *Gatherer_Downstream_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Gatherer_Downstream_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Gatherer_Downstream_Fn_class = Define(&ClassInfo{Name: "java.util.stream.Gatherer$Downstream$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Gatherer_Downstream_class}, Go: "arbace/jrt.Gatherer_Downstream_Fn"})



type ToLongFunction_Fn struct{ Object; Fn func(any) int64 }

func (t *ToLongFunction_Fn) ApplyAsLong_O__J(p0 any) int64 { return t.Fn(p0) }

func (t *ToLongFunction_Fn) Is_ToLongFunction() {}

func (t *ToLongFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ToLongFunction_Fn) GetClass__Class() *Class { return ToLongFunction_Fn_class }

func (t *ToLongFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ToLongFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ToLongFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.ToLongFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ToLongFunction_class}, Go: "arbace/jrt.ToLongFunction_Fn"})



type Sink_OfLong_Fn struct{ Object; Fn func(int64) }

func (t *Sink_OfLong_Fn) Accept_J__V(p0 int64) { t.Fn(p0) }

func (t *Sink_OfLong_Fn) Is_Sink_OfLong() {}

func (t *Sink_OfLong_Fn) Is_Sink() {}

func (t *Sink_OfLong_Fn) Is_LongConsumer() {}

func (t *Sink_OfLong_Fn) Is_Consumer() {}

func (t *Sink_OfLong_Fn) Begin_J__V(p0 int64) { Sink_Begin_J__V(t, p0) }

func (t *Sink_OfLong_Fn) Accept_O__V(p0 any) { Sink_OfLong_Accept_O__V(t, p0) }

func (t *Sink_OfLong_Fn) Accept_I__V(p0 int32) { Sink_Accept_I__V(t, p0) }

func (t *Sink_OfLong_Fn) Accept_Long__V(p0 *Long) { Sink_OfLong_Accept_Long__V(t, p0) }

func (t *Sink_OfLong_Fn) Accept_D__V(p0 float64) { Sink_Accept_D__V(t, p0) }

func (t *Sink_OfLong_Fn) AndThen_Consumer__Consumer(p0 Consumer) Consumer { return Consumer_AndThen_Consumer__Consumer(t, p0) }

func (t *Sink_OfLong_Fn) AndThen_LongConsumer__LongConsumer(p0 LongConsumer) LongConsumer { return LongConsumer_AndThen_LongConsumer__LongConsumer(t, p0) }

func (t *Sink_OfLong_Fn) End__V() { Sink_End__V(t) }

func (t *Sink_OfLong_Fn) CancellationRequested__Z() bool { return Sink_CancellationRequested__Z(t) }

func (t *Sink_OfLong_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Sink_OfLong_Fn) GetClass__Class() *Class { return Sink_OfLong_Fn_class }

func (t *Sink_OfLong_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Sink_OfLong_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Sink_OfLong_Fn_class = Define(&ClassInfo{Name: "java.util.stream.Sink$OfLong$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Sink_OfLong_class}, Go: "arbace/jrt.Sink_OfLong_Fn"})



type ToDoubleFunction_Fn struct{ Object; Fn func(any) float64 }

func (t *ToDoubleFunction_Fn) ApplyAsDouble_O__D(p0 any) float64 { return t.Fn(p0) }

func (t *ToDoubleFunction_Fn) Is_ToDoubleFunction() {}

func (t *ToDoubleFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ToDoubleFunction_Fn) GetClass__Class() *Class { return ToDoubleFunction_Fn_class }

func (t *ToDoubleFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ToDoubleFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ToDoubleFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.ToDoubleFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ToDoubleFunction_class}, Go: "arbace/jrt.ToDoubleFunction_Fn"})



type Sink_OfDouble_Fn struct{ Object; Fn func(float64) }

func (t *Sink_OfDouble_Fn) Accept_D__V(p0 float64) { t.Fn(p0) }

func (t *Sink_OfDouble_Fn) Is_Sink_OfDouble() {}

func (t *Sink_OfDouble_Fn) Is_Sink() {}

func (t *Sink_OfDouble_Fn) Is_DoubleConsumer() {}

func (t *Sink_OfDouble_Fn) Is_Consumer() {}

func (t *Sink_OfDouble_Fn) Begin_J__V(p0 int64) { Sink_Begin_J__V(t, p0) }

func (t *Sink_OfDouble_Fn) Accept_O__V(p0 any) { Sink_OfDouble_Accept_O__V(t, p0) }

func (t *Sink_OfDouble_Fn) Accept_J__V(p0 int64) { Sink_Accept_J__V(t, p0) }

func (t *Sink_OfDouble_Fn) Accept_I__V(p0 int32) { Sink_Accept_I__V(t, p0) }

func (t *Sink_OfDouble_Fn) AndThen_Consumer__Consumer(p0 Consumer) Consumer { return Consumer_AndThen_Consumer__Consumer(t, p0) }

func (t *Sink_OfDouble_Fn) AndThen_DoubleConsumer__DoubleConsumer(p0 DoubleConsumer) DoubleConsumer { return DoubleConsumer_AndThen_DoubleConsumer__DoubleConsumer(t, p0) }

func (t *Sink_OfDouble_Fn) End__V() { Sink_End__V(t) }

func (t *Sink_OfDouble_Fn) CancellationRequested__Z() bool { return Sink_CancellationRequested__Z(t) }

func (t *Sink_OfDouble_Fn) Accept_Double__V(p0 *Double) { Sink_OfDouble_Accept_Double__V(t, p0) }

func (t *Sink_OfDouble_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Sink_OfDouble_Fn) GetClass__Class() *Class { return Sink_OfDouble_Fn_class }

func (t *Sink_OfDouble_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Sink_OfDouble_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Sink_OfDouble_Fn_class = Define(&ClassInfo{Name: "java.util.stream.Sink$OfDouble$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Sink_OfDouble_class}, Go: "arbace/jrt.Sink_OfDouble_Fn"})



type LongUnaryOperator_Fn struct{ Object; Fn func(int64) int64 }

func (t *LongUnaryOperator_Fn) ApplyAsLong_J__J(p0 int64) int64 { return t.Fn(p0) }

func (t *LongUnaryOperator_Fn) Is_LongUnaryOperator() {}

func (t *LongUnaryOperator_Fn) Compose_LongUnaryOperator__LongUnaryOperator(p0 LongUnaryOperator) LongUnaryOperator { return LongUnaryOperator_Compose_LongUnaryOperator__LongUnaryOperator(t, p0) }

func (t *LongUnaryOperator_Fn) AndThen_LongUnaryOperator__LongUnaryOperator(p0 LongUnaryOperator) LongUnaryOperator { return LongUnaryOperator_AndThen_LongUnaryOperator__LongUnaryOperator(t, p0) }

func (t *LongUnaryOperator_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongUnaryOperator_Fn) GetClass__Class() *Class { return LongUnaryOperator_Fn_class }

func (t *LongUnaryOperator_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongUnaryOperator_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongUnaryOperator_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongUnaryOperator$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongUnaryOperator_class}, Go: "arbace/jrt.LongUnaryOperator_Fn"})



type ToIntFunction_Fn struct{ Object; Fn func(any) int32 }

func (t *ToIntFunction_Fn) ApplyAsInt_O__I(p0 any) int32 { return t.Fn(p0) }

func (t *ToIntFunction_Fn) Is_ToIntFunction() {}

func (t *ToIntFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ToIntFunction_Fn) GetClass__Class() *Class { return ToIntFunction_Fn_class }

func (t *ToIntFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ToIntFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ToIntFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.ToIntFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ToIntFunction_class}, Go: "arbace/jrt.ToIntFunction_Fn"})



type IntConsumer_Fn struct{ Object; Fn func(int32) }

func (t *IntConsumer_Fn) Accept_I__V(p0 int32) { t.Fn(p0) }

func (t *IntConsumer_Fn) Is_IntConsumer() {}

func (t *IntConsumer_Fn) AndThen_IntConsumer__IntConsumer(p0 IntConsumer) IntConsumer { return IntConsumer_AndThen_IntConsumer__IntConsumer(t, p0) }

func (t *IntConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntConsumer_Fn) GetClass__Class() *Class { return IntConsumer_Fn_class }

func (t *IntConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntConsumer_class}, Go: "arbace/jrt.IntConsumer_Fn"})



type DoubleSupplier_Fn struct{ Object; Fn func() float64 }

func (t *DoubleSupplier_Fn) GetAsDouble__D() float64 { return t.Fn() }

func (t *DoubleSupplier_Fn) Is_DoubleSupplier() {}

func (t *DoubleSupplier_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleSupplier_Fn) GetClass__Class() *Class { return DoubleSupplier_Fn_class }

func (t *DoubleSupplier_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleSupplier_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleSupplier_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoubleSupplier$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleSupplier_class}, Go: "arbace/jrt.DoubleSupplier_Fn"})



type EntropySource_Fn struct{ Object; Fn func(int32, int32, int32, bool) *ByteArray }

func (t *EntropySource_Fn) GetEntropy_I_I_I_Z__B1(p0, p1, p2 int32, p3 bool) *ByteArray { return t.Fn(p0, p1, p2, p3) }

func (t *EntropySource_Fn) Is_EntropySource() {}

func (t *EntropySource_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *EntropySource_Fn) GetClass__Class() *Class { return EntropySource_Fn_class }

func (t *EntropySource_Fn) ToString__String() *String { return Object_toString(t) }

func (t *EntropySource_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var EntropySource_Fn_class = Define(&ClassInfo{Name: "sun.security.provider.EntropySource$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{EntropySource_class}, Go: "arbace/jrt.EntropySource_Fn"})



type TemporalQuery_Fn struct{ Object; Fn func(TemporalAccessor) any }

func (t *TemporalQuery_Fn) QueryFrom_TemporalAccessor__O(p0 TemporalAccessor) any { return t.Fn(p0) }

func (t *TemporalQuery_Fn) Is_TemporalQuery() {}

func (t *TemporalQuery_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *TemporalQuery_Fn) GetClass__Class() *Class { return TemporalQuery_Fn_class }

func (t *TemporalQuery_Fn) ToString__String() *String { return Object_toString(t) }

func (t *TemporalQuery_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var TemporalQuery_Fn_class = Define(&ClassInfo{Name: "java.time.temporal.TemporalQuery$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{TemporalQuery_class}, Go: "arbace/jrt.TemporalQuery_Fn"})



type ThreadFactory_Fn struct{ Object; Fn func(Runnable) Thread_I }

func (t *ThreadFactory_Fn) NewThread_Runnable__Thread(p0 Runnable) Thread_I { return t.Fn(p0) }

func (t *ThreadFactory_Fn) Is_ThreadFactory() {}

func (t *ThreadFactory_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ThreadFactory_Fn) GetClass__Class() *Class { return ThreadFactory_Fn_class }

func (t *ThreadFactory_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ThreadFactory_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ThreadFactory_Fn_class = Define(&ClassInfo{Name: "java.util.concurrent.ThreadFactory$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ThreadFactory_class}, Go: "arbace/jrt.ThreadFactory_Fn"})



type ToDoubleBiFunction_Fn struct{ Object; Fn func(any, any) float64 }

func (t *ToDoubleBiFunction_Fn) ApplyAsDouble_O_O__D(p0, p1 any) float64 { return t.Fn(p0, p1) }

func (t *ToDoubleBiFunction_Fn) Is_ToDoubleBiFunction() {}

func (t *ToDoubleBiFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ToDoubleBiFunction_Fn) GetClass__Class() *Class { return ToDoubleBiFunction_Fn_class }

func (t *ToDoubleBiFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ToDoubleBiFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ToDoubleBiFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.ToDoubleBiFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ToDoubleBiFunction_class}, Go: "arbace/jrt.ToDoubleBiFunction_Fn"})



type FilenameFilter_Fn struct{ Object; Fn func(*File, *String) bool }

func (t *FilenameFilter_Fn) Accept_File_String__Z(p0 *File, p1 *String) bool { return t.Fn(p0, p1) }

func (t *FilenameFilter_Fn) Is_FilenameFilter() {}

func (t *FilenameFilter_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *FilenameFilter_Fn) GetClass__Class() *Class { return FilenameFilter_Fn_class }

func (t *FilenameFilter_Fn) ToString__String() *String { return Object_toString(t) }

func (t *FilenameFilter_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var FilenameFilter_Fn_class = Define(&ClassInfo{Name: "java.io.FilenameFilter$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{FilenameFilter_class}, Go: "arbace/jrt.FilenameFilter_Fn"})



type DoubleToIntFunction_Fn struct{ Object; Fn func(float64) int32 }

func (t *DoubleToIntFunction_Fn) ApplyAsInt_D__I(p0 float64) int32 { return t.Fn(p0) }

func (t *DoubleToIntFunction_Fn) Is_DoubleToIntFunction() {}

func (t *DoubleToIntFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleToIntFunction_Fn) GetClass__Class() *Class { return DoubleToIntFunction_Fn_class }

func (t *DoubleToIntFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleToIntFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleToIntFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoubleToIntFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleToIntFunction_class}, Go: "arbace/jrt.DoubleToIntFunction_Fn"})



type Flow_Publisher_Fn struct{ Object; Fn func(Flow_Subscriber) }

func (t *Flow_Publisher_Fn) Subscribe_Flow_Subscriber__V(p0 Flow_Subscriber) { t.Fn(p0) }

func (t *Flow_Publisher_Fn) Is_Flow_Publisher() {}

func (t *Flow_Publisher_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Flow_Publisher_Fn) GetClass__Class() *Class { return Flow_Publisher_Fn_class }

func (t *Flow_Publisher_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Flow_Publisher_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Flow_Publisher_Fn_class = Define(&ClassInfo{Name: "java.util.concurrent.Flow$Publisher$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Flow_Publisher_class}, Go: "arbace/jrt.Flow_Publisher_Fn"})



type LongStream_LongMapMultiConsumer_Fn struct{ Object; Fn func(int64, LongConsumer) }

func (t *LongStream_LongMapMultiConsumer_Fn) Accept_J_LongConsumer__V(p0 int64, p1 LongConsumer) { t.Fn(p0, p1) }

func (t *LongStream_LongMapMultiConsumer_Fn) Is_LongStream_LongMapMultiConsumer() {}

func (t *LongStream_LongMapMultiConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongStream_LongMapMultiConsumer_Fn) GetClass__Class() *Class { return LongStream_LongMapMultiConsumer_Fn_class }

func (t *LongStream_LongMapMultiConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongStream_LongMapMultiConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongStream_LongMapMultiConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.stream.LongStream$LongMapMultiConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongStream_LongMapMultiConsumer_class}, Go: "arbace/jrt.LongStream_LongMapMultiConsumer_Fn"})



type ToLongBiFunction_Fn struct{ Object; Fn func(any, any) int64 }

func (t *ToLongBiFunction_Fn) ApplyAsLong_O_O__J(p0, p1 any) int64 { return t.Fn(p0, p1) }

func (t *ToLongBiFunction_Fn) Is_ToLongBiFunction() {}

func (t *ToLongBiFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ToLongBiFunction_Fn) GetClass__Class() *Class { return ToLongBiFunction_Fn_class }

func (t *ToLongBiFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ToLongBiFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ToLongBiFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.ToLongBiFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ToLongBiFunction_class}, Go: "arbace/jrt.ToLongBiFunction_Fn"})



type IntStream_IntMapMultiConsumer_Fn struct{ Object; Fn func(int32, IntConsumer) }

func (t *IntStream_IntMapMultiConsumer_Fn) Accept_I_IntConsumer__V(p0 int32, p1 IntConsumer) { t.Fn(p0, p1) }

func (t *IntStream_IntMapMultiConsumer_Fn) Is_IntStream_IntMapMultiConsumer() {}

func (t *IntStream_IntMapMultiConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntStream_IntMapMultiConsumer_Fn) GetClass__Class() *Class { return IntStream_IntMapMultiConsumer_Fn_class }

func (t *IntStream_IntMapMultiConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntStream_IntMapMultiConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntStream_IntMapMultiConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.stream.IntStream$IntMapMultiConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntStream_IntMapMultiConsumer_class}, Go: "arbace/jrt.IntStream_IntMapMultiConsumer_Fn"})



type LongToDoubleFunction_Fn struct{ Object; Fn func(int64) float64 }

func (t *LongToDoubleFunction_Fn) ApplyAsDouble_J__D(p0 int64) float64 { return t.Fn(p0) }

func (t *LongToDoubleFunction_Fn) Is_LongToDoubleFunction() {}

func (t *LongToDoubleFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongToDoubleFunction_Fn) GetClass__Class() *Class { return LongToDoubleFunction_Fn_class }

func (t *LongToDoubleFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongToDoubleFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongToDoubleFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongToDoubleFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongToDoubleFunction_class}, Go: "arbace/jrt.LongToDoubleFunction_Fn"})



type LongToIntFunction_Fn struct{ Object; Fn func(int64) int32 }

func (t *LongToIntFunction_Fn) ApplyAsInt_J__I(p0 int64) int32 { return t.Fn(p0) }

func (t *LongToIntFunction_Fn) Is_LongToIntFunction() {}

func (t *LongToIntFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *LongToIntFunction_Fn) GetClass__Class() *Class { return LongToIntFunction_Fn_class }

func (t *LongToIntFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *LongToIntFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var LongToIntFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.LongToIntFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{LongToIntFunction_class}, Go: "arbace/jrt.LongToIntFunction_Fn"})



type IntToDoubleFunction_Fn struct{ Object; Fn func(int32) float64 }

func (t *IntToDoubleFunction_Fn) ApplyAsDouble_I__D(p0 int32) float64 { return t.Fn(p0) }

func (t *IntToDoubleFunction_Fn) Is_IntToDoubleFunction() {}

func (t *IntToDoubleFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntToDoubleFunction_Fn) GetClass__Class() *Class { return IntToDoubleFunction_Fn_class }

func (t *IntToDoubleFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntToDoubleFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntToDoubleFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntToDoubleFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntToDoubleFunction_class}, Go: "arbace/jrt.IntToDoubleFunction_Fn"})



type Callable_Fn struct{ Object; Fn func() any }

func (t *Callable_Fn) Call__O() any { return t.Fn() }

func (t *Callable_Fn) Is_Callable() {}

func (t *Callable_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *Callable_Fn) GetClass__Class() *Class { return Callable_Fn_class }

func (t *Callable_Fn) ToString__String() *String { return Object_toString(t) }

func (t *Callable_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var Callable_Fn_class = Define(&ClassInfo{Name: "java.util.concurrent.Callable$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{Callable_class}, Go: "arbace/jrt.Callable_Fn"})



type DirectoryStream_Filter_Fn struct{ Object; Fn func(any) bool }

func (t *DirectoryStream_Filter_Fn) Accept_O__Z(p0 any) bool { return t.Fn(p0) }

func (t *DirectoryStream_Filter_Fn) Is_DirectoryStream_Filter() {}

func (t *DirectoryStream_Filter_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DirectoryStream_Filter_Fn) GetClass__Class() *Class { return DirectoryStream_Filter_Fn_class }

func (t *DirectoryStream_Filter_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DirectoryStream_Filter_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DirectoryStream_Filter_Fn_class = Define(&ClassInfo{Name: "java.nio.file.DirectoryStream$Filter$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DirectoryStream_Filter_class}, Go: "arbace/jrt.DirectoryStream_Filter_Fn"})



type IntToLongFunction_Fn struct{ Object; Fn func(int32) int64 }

func (t *IntToLongFunction_Fn) ApplyAsLong_I__J(p0 int32) int64 { return t.Fn(p0) }

func (t *IntToLongFunction_Fn) Is_IntToLongFunction() {}

func (t *IntToLongFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *IntToLongFunction_Fn) GetClass__Class() *Class { return IntToLongFunction_Fn_class }

func (t *IntToLongFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *IntToLongFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var IntToLongFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.IntToLongFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{IntToLongFunction_class}, Go: "arbace/jrt.IntToLongFunction_Fn"})



type DoubleToLongFunction_Fn struct{ Object; Fn func(float64) int64 }

func (t *DoubleToLongFunction_Fn) ApplyAsLong_D__J(p0 float64) int64 { return t.Fn(p0) }

func (t *DoubleToLongFunction_Fn) Is_DoubleToLongFunction() {}

func (t *DoubleToLongFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleToLongFunction_Fn) GetClass__Class() *Class { return DoubleToLongFunction_Fn_class }

func (t *DoubleToLongFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleToLongFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleToLongFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.DoubleToLongFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleToLongFunction_class}, Go: "arbace/jrt.DoubleToLongFunction_Fn"})



type FileFilter_Fn struct{ Object; Fn func(*File) bool }

func (t *FileFilter_Fn) Accept_File__Z(p0 *File) bool { return t.Fn(p0) }

func (t *FileFilter_Fn) Is_FileFilter() {}

func (t *FileFilter_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *FileFilter_Fn) GetClass__Class() *Class { return FileFilter_Fn_class }

func (t *FileFilter_Fn) ToString__String() *String { return Object_toString(t) }

func (t *FileFilter_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var FileFilter_Fn_class = Define(&ClassInfo{Name: "java.io.FileFilter$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{FileFilter_class}, Go: "arbace/jrt.FileFilter_Fn"})



type DoubleStream_DoubleMapMultiConsumer_Fn struct{ Object; Fn func(float64, DoubleConsumer) }

func (t *DoubleStream_DoubleMapMultiConsumer_Fn) Accept_D_DoubleConsumer__V(p0 float64, p1 DoubleConsumer) { t.Fn(p0, p1) }

func (t *DoubleStream_DoubleMapMultiConsumer_Fn) Is_DoubleStream_DoubleMapMultiConsumer() {}

func (t *DoubleStream_DoubleMapMultiConsumer_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleStream_DoubleMapMultiConsumer_Fn) GetClass__Class() *Class { return DoubleStream_DoubleMapMultiConsumer_Fn_class }

func (t *DoubleStream_DoubleMapMultiConsumer_Fn) ToString__String() *String { return Object_toString(t) }

func (t *DoubleStream_DoubleMapMultiConsumer_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var DoubleStream_DoubleMapMultiConsumer_Fn_class = Define(&ClassInfo{Name: "java.util.stream.DoubleStream$DoubleMapMultiConsumer$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{DoubleStream_DoubleMapMultiConsumer_class}, Go: "arbace/jrt.DoubleStream_DoubleMapMultiConsumer_Fn"})



type ToIntBiFunction_Fn struct{ Object; Fn func(any, any) int32 }

func (t *ToIntBiFunction_Fn) ApplyAsInt_O_O__I(p0, p1 any) int32 { return t.Fn(p0, p1) }

func (t *ToIntBiFunction_Fn) Is_ToIntBiFunction() {}

func (t *ToIntBiFunction_Fn) Ref() any { if t == nil { return nil }; return t }

func (t *ToIntBiFunction_Fn) GetClass__Class() *Class { return ToIntBiFunction_Fn_class }

func (t *ToIntBiFunction_Fn) ToString__String() *String { return Object_toString(t) }

func (t *ToIntBiFunction_Fn) Clone__O() any { panic(CloneNotSupported(t)) }

var ToIntBiFunction_Fn_class = Define(&ClassInfo{Name: "java.util.function.ToIntBiFunction$$Lambda", Modifiers: 4112, Kind: KindClass, Super: Object_class, Interfaces: []*Class{ToIntBiFunction_class}, Go: "arbace/jrt.ToIntBiFunction_Fn"})
