//line java_util_DualPivotQuicksort.ae:1
package jrt








func DualPivotQuicksort_New() *DualPivotQuicksort { t := &DualPivotQuicksort{}; t.Ctor(); return t }
//line :10:1
func (t *DualPivotQuicksort) Ctor() { panic(A2g_NotTranslated("java.util.DualPivotQuicksort.<init>()V")) }
































func DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(elemType *Class, array any, offset int64, low, high int32, so DualPivotQuicksort_SortOperation) {





	so.Sort_O_I_I__V(array, low, high)
}





func DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(elemType *Class, array any, offset int64, low, high, pivotIndex1, pivotIndex2 int32, po DualPivotQuicksort_PartitionOperation) *IntArray {







	return po.Partition_O_I_I_I_I__I1(array, low, high, pivotIndex1, pivotIndex2)
}
func DualPivotQuicksort_GetDepth_I_I__I(parallelism, size int32) int32 {
	var depth int32 = 0
L1: for { var tmp1 bool; var tmp2 bool; var tmp3 int32; parallelism = parallelism >> 3; tmp3 = parallelism; tmp2 = tmp3 > 0; if tmp2 {
	var tmp4 int32; size = size >> 2; tmp4 = size; tmp2 = tmp4 > 0 }
//line :68:1
	tmp1 = tmp2; if tmp1 {

		depth = depth - 2
//line :68:1
		continue L1 }; break L1 }
//line :67:1
	return depth
}




func DualPivotQuicksort_Sort_I1_I_I_I__V(a *IntArray, parallelism, low, high int32) {
	var size int32 = high - low; var tmp1 bool; var tmp2 bool
	tmp2 = parallelism > 1; if tmp2 { tmp2 = size > 4096 }; tmp1 = tmp2; if tmp1 {
		var depth int32 = DualPivotQuicksort_GetDepth_I_I__I(parallelism, size>>12); var b *IntArray
		if depth == 0 { b = nil } else { b = NewIntArray(size) }
		DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(nil, a.Ref(), b.Ref(), low, size, low, depth).Invoke__O() } else {
			DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_I1_I_I_I__V(nil, a, 0, low, high)
		} }
func DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_I1_I_I_I__V(sorter *DualPivotQuicksort_Sorter, a *IntArray, bits, low, high int32) {

L1: for {
	var end int32 = high - 1; var size int32 = high - low; var tmp1 bool; var tmp2 bool

	tmp2 = size < 65+bits; if tmp2 {
		tmp2 = bits&1 > 0 }
//line :86:1
	tmp1 = tmp2; if tmp1 {

		var tmp3 *Class; Integer_Init(); tmp3 = Integer_TYPE; var tmp4 *Class = tmp3; var tmp5 int64 = Unsafe_ARRAY_INT_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp4, a.Ref(), tmp5, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0 any, p1, p2 int32) { DualPivotQuicksort_MixedInsertionSort_I1_I_I__V(A2g_CastArray[*IntArray](p0, Prim_int.ArrayClass()), p1, p2) }})







		return }
	if size < 44 {
		var tmp6 *Class; Integer_Init(); tmp6 = Integer_TYPE; var tmp7 *Class = tmp6; var tmp8 int64 = Unsafe_ARRAY_INT_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp7, a.Ref(), tmp8, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0_2 any, p1_2, p2_2 int32) { DualPivotQuicksort_InsertionSort_I1_I_I__V(A2g_CastArray[*IntArray](p0_2, Prim_int.ArrayClass()), p1_2, p2_2) }})







		return }
	var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = bits == 0; if !tmp11 { var tmp12 bool; tmp12 = size > 4096; if tmp12 { tmp12 = bits&1 > 0 }; tmp11 = tmp12 }; tmp10 = tmp11; if tmp10 {
		tmp10 = DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_I1_I_I__Z(sorter, a, low, size) }
//line :107:1
	tmp9 = tmp10; if tmp9 {

		return }
	var tmp13 int32; bits = bits + 6; tmp13 = bits; if tmp13 > 384 {
		DualPivotQuicksort_HeapSort_I1_I_I__V(a, low, high)
		return }
	var step int32 = size>>3*3 + 3; var e1 int32 = low + step; var e5 int32 = end - step; var e3 int32 = int32(uint32(e1+e5) >> 1); var e2 int32 = int32(uint32(e1+e3) >> 1); var e4 int32 = int32(uint32(e3+e5) >> 1); var a3 int32 = a.A[e3]; var tmp14 int32 = a.A[e5]






	if tmp14 < a.A[e2] {
		var t_ int32 = a.A[e5]; a.A[e5] = a.A[e2]; a.A[e2] = t_ }
	var tmp15 int32 = a.A[e4]; if tmp15 < a.A[e1] {
		var t__2 int32 = a.A[e4]; a.A[e4] = a.A[e1]; a.A[e1] = t__2 }
	var tmp16 int32 = a.A[e5]; if tmp16 < a.A[e4] {
		var t__3 int32 = a.A[e5]; a.A[e5] = a.A[e4]; a.A[e4] = t__3 }
	var tmp17 int32 = a.A[e2]; if tmp17 < a.A[e1] {
		var t__4 int32 = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = t__4 }
	var tmp18 int32 = a.A[e4]; if tmp18 < a.A[e2] {
		var t__5 int32 = a.A[e4]; a.A[e4] = a.A[e2]; a.A[e2] = t__5 }
	if a3 < a.A[e2] {

		if a3 < a.A[e1] {
			a.A[e3] = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = a3 } else {
				a.A[e3] = a.A[e2]; a.A[e2] = a3 } } else {
//line :130:1
					if a3 > a.A[e4] {





						if a3 > a.A[e5] {
							a.A[e3] = a.A[e4]; a.A[e4] = a.A[e5]; a.A[e5] = a3 } else {
								a.A[e3] = a.A[e4]; a.A[e4] = a3 } } }
	var lower int32 = 0; var upper int32 = 0; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; var tmp23 int32 = a.A[e1]

	tmp22 = tmp23 < a.A[e2]; if tmp22 { var tmp24 int32 = a.A[e2]; tmp22 = tmp24 < a.A[e3] }; tmp21 = tmp22; if tmp21 {
		var tmp25 int32 = a.A[e3]; tmp21 = tmp25 < a.A[e4] }
//line :141:1
	tmp20 = tmp21; if tmp20 {

		var tmp26 int32 = a.A[e4]; tmp20 = tmp26 < a.A[e5] }
//line :141:1
	tmp19 = tmp20; if tmp19 {


		var pivotIndices *IntArray; var tmp27 *Class; Integer_Init(); tmp27 = Integer_TYPE; var tmp28 *Class = tmp27; var tmp29 int64 = Unsafe_ARRAY_INT_BASE_OFFSET; pivotIndices = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp28, a.Ref(), tmp29, low, high, e1, e5, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_3 any, p1_3, p2_3, p3, p4 int32) *IntArray { return DualPivotQuicksort_PartitionDualPivot_I1_I_I_I_I__I1(A2g_CastArray[*IntArray](p0_3, Prim_int.ArrayClass()), p1_3, p2_3, p3, p4) }})











		lower = pivotIndices.A[0]
		upper = pivotIndices.A[1]
		var tmp30 bool; var tmp31 bool; tmp31 = size > 4096; if tmp31 { tmp31 = !(sorter == nil) }; tmp30 = tmp31; if tmp30 {

			NN(sorter).ForkSorter_I_I_I__V(bits|1, lower+1, upper)
			NN(sorter).ForkSorter_I_I_I__V(bits|1, upper+1, high) } else {

				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_I1_I_I_I__V(sorter, a, bits|1, lower+1, upper)





				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_I1_I_I_I__V(sorter, a, bits|1, upper+1, high) } } else {





					var pivotIndices_2 *IntArray; var tmp32 *Class; Integer_Init(); tmp32 = Integer_TYPE; var tmp33 *Class = tmp32; var tmp34 int64 = Unsafe_ARRAY_INT_BASE_OFFSET; pivotIndices_2 = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp33, a.Ref(), tmp34, low, high, e3, e3, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_4 any, p1_4, p2_4, p3_2, p4_2 int32) *IntArray { return DualPivotQuicksort_PartitionSinglePivot_I1_I_I_I_I__I1(A2g_CastArray[*IntArray](p0_4, Prim_int.ArrayClass()), p1_4, p2_4, p3_2, p4_2) }})











					lower = pivotIndices_2.A[0]
					upper = pivotIndices_2.A[1]
					var tmp35 bool; var tmp36 bool; tmp36 = size > 4096; if tmp36 { tmp36 = !(sorter == nil) }; tmp35 = tmp36; if tmp35 {
						NN(sorter).ForkSorter_I_I_I__V(bits|1, upper, high) } else {
							DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_I1_I_I_I__V(sorter, a, bits|1, upper, high) } }
	high = lower
//line :83:1
	continue L1
}
}












































































































func DualPivotQuicksort_PartitionDualPivot_I1_I_I_I_I__I1(a *IntArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e1 int32 = pivotIndex1; var e5 int32 = pivotIndex2; var pivot1 int32 = a.A[e1]; var pivot2 int32 = a.A[e5]






	a.A[e1] = a.A[lower]
	a.A[e5] = a.A[upper]
L1: for { var tmp1 int32; lower = lower + 1; tmp1 = lower; if a.A[tmp1] < pivot1 { continue L1 }; break L1 }
L2: for { var tmp2 int32; upper = upper - 1; tmp2 = upper; if a.A[tmp2] > pivot2 { continue L2 }; break L2 }
	var unused int32; _ = unused; lower = lower - 1; unused = lower; var k int32
	upper = upper + 1; k = upper
L3: for { var tmp3 int32; k = k - 1; tmp3 = k; if tmp3 > lower {
	var ak int32 = a.A[k]
	if ak < pivot1 {
	L4: for { if lower < k {
		var tmp4 int32; lower = lower + 1; tmp4 = lower; if a.A[tmp4] >= pivot1 {
			if a.A[lower] > pivot2 {

				var tmp5 int32 = k; var tmp6 int32; upper = upper - 1; tmp6 = upper; a.A[tmp5] = a.A[tmp6]
				a.A[upper] = a.A[lower] } else {
					a.A[k] = a.A[lower] }
			a.A[lower] = ak
			break L4 }
//line :214:1
		continue L4 }; break L4
	}





	} else {

		if ak > pivot2 {
			var tmp7 int32 = k; var tmp8 int32; upper = upper - 1; tmp8 = upper; a.A[tmp7] = a.A[tmp8]
			a.A[upper] = ak } }
//line :211:1
	continue L3 }; break L3
}













	a.A[low] = a.A[lower]
	a.A[lower] = pivot1
	a.A[end] = a.A[upper]
	a.A[upper] = pivot2
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_PartitionSinglePivot_I1_I_I_I_I__I1(a *IntArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e3 int32 = pivotIndex1; var pivot int32 = a.A[e3]




	a.A[e3] = a.A[lower]
	var k int32; upper = upper + 1; k = upper
L1: for { var tmp1 int32; k = k - 1; tmp1 = k; if tmp1 > lower {
	var ak int32 = a.A[k]
	if ak == pivot { } else {
		a.A[k] = pivot
		if ak < pivot {

		L2: for { var tmp2 int32; lower = lower + 1; tmp2 = lower; if a.A[tmp2] < pivot { continue L2 }; break L2 }
			if a.A[lower] > pivot {
				var tmp3 int32; upper = upper - 1; tmp3 = upper; a.A[tmp3] = a.A[lower] }
			a.A[lower] = ak } else {
				var tmp4 int32; upper = upper - 1; tmp4 = upper; a.A[tmp4] = ak } }
//line :243:1
	continue L1 }; break L1
}









	a.A[low] = a.A[lower]
	a.A[lower] = pivot
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_MixedInsertionSort_I1_I_I__V(a *IntArray, low, high int32) {
	var size int32 = high - low; var end int32 = high - 3*(size>>5<<3)




	if end == high {
		var i int32 = 0
	L1: for { var tmp1 int32; low = low + 1; tmp1 = low; if tmp1 < end {
		var ai int32; var tmp2 int32; i = low; tmp2 = i; ai = a.A[tmp2]
	L2: for { var tmp3 int32; i = i - 1; tmp3 = i; if ai < a.A[tmp3] {
		a.A[i+1] = a.A[i]
//line :268:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai
//line :266:1
		continue L1 }; break L1
	}

	} else {

		var pin int32 = a.A[end]
		var i_2 int32 = 0
		var p int32 = high
	L3: for { var tmp4 int32; low = low + 1; tmp4 = low; if tmp4 < end {
		var ai_2 int32; var tmp5 int32; i_2 = low; tmp5 = i_2; ai_2 = a.A[tmp5]
		if ai_2 < a.A[i_2-1] {

			var tmp6 int32 = i_2; var tmp7 int32; i_2 = i_2 - 1; tmp7 = i_2; a.A[tmp6] = a.A[tmp7]
		L4: for { var tmp8 int32 = ai_2; var tmp9 int32; i_2 = i_2 - 1; tmp9 = i_2; if tmp8 < a.A[tmp9] {
			a.A[i_2+1] = a.A[i_2]
//line :279:1
			continue L4 }; break L4
		}
			a.A[i_2+1] = ai_2 } else {
				var tmp10 bool; var tmp11 bool; tmp11 = p > i_2; if tmp11 { tmp11 = ai_2 > pin }; tmp10 = tmp11; if tmp10 {
				L5: for { var tmp12 int32; p = p - 1; tmp12 = p; if a.A[tmp12] > pin { continue L5 }; break L5 }
					if p > i_2 { ai_2 = a.A[p]; a.A[p] = a.A[i_2] }
				L6: for { var tmp13 int32 = ai_2; var tmp14 int32; i_2 = i_2 - 1; tmp14 = i_2; if tmp13 < a.A[tmp14] {
					a.A[i_2+1] = a.A[i_2]
//line :285:1
					continue L6 }; break L6
				}
					a.A[i_2+1] = ai_2 } }
//line :274:1
		continue L3 }; break L3
	}












		var i_3 int32 = 0
	L7: for { if low < high {
		var a1 int32; var tmp15 int32; i_3 = low; tmp15 = i_3; a1 = a.A[tmp15]; var a2 int32; var tmp16 int32
		low = low + 1; tmp16 = low; a2 = a.A[tmp16]
		if a1 > a2 {

		L8: for { var tmp17 int32; i_3 = i_3 - 1; tmp17 = i_3; if a1 < a.A[tmp17] {
			a.A[i_3+2] = a.A[i_3]
//line :294:1
			continue L8 }; break L8
		}
			var tmp18 int32; i_3 = i_3 + 1; tmp18 = i_3; a.A[tmp18+1] = a1
		L9: for { var tmp19 int32; i_3 = i_3 - 1; tmp19 = i_3; if a2 < a.A[tmp19] {
			a.A[i_3+1] = a.A[i_3]
//line :297:1
			continue L9 }; break L9
		}
			a.A[i_3+1] = a2 } else {
				if a1 < a.A[i_3-1] {
				L10: for { var tmp20 int32; i_3 = i_3 - 1; tmp20 = i_3; if a2 < a.A[tmp20] {
					a.A[i_3+2] = a.A[i_3]
//line :301:1
					continue L10 }; break L10
				}
					var tmp21 int32; i_3 = i_3 + 1; tmp21 = i_3; a.A[tmp21+1] = a2
				L11: for { var tmp22 int32; i_3 = i_3 - 1; tmp22 = i_3; if a1 < a.A[tmp22] {
					a.A[i_3+1] = a.A[i_3]
//line :304:1
					continue L11 }; break L11
				}
					a.A[i_3+1] = a1 } }
		low = low + 1
//line :289:1
		continue L7 }; break L7
	}
	}
}
















func DualPivotQuicksort_InsertionSort_I1_I_I__V(a *IntArray, low, high int32) {
	var i int32 = 0
	var k int32 = low
L1: for { var tmp1 int32; k = k + 1; tmp1 = k; if tmp1 < high {
	var ai int32; var tmp2 int32; i = k; tmp2 = i; ai = a.A[tmp2]
	if ai < a.A[i-1] {
	L2: for { var tmp3 bool; var tmp4 bool; var tmp5 int32; i = i - 1; tmp5 = i; tmp4 = tmp5 >= low; if tmp4 { tmp4 = ai < a.A[i] }; tmp3 = tmp4; if tmp3 {
		a.A[i+1] = a.A[i]
//line :315:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai }
//line :312:1
	continue L1 }; break L1
}
}




func DualPivotQuicksort_HeapSort_I1_I_I__V(a *IntArray, low, high int32) {
	var k int32 = int32(uint32(low+high) >> 1)
L1: for { if k > low {
	var tmp1 int32; k = k - 1; tmp1 = k; DualPivotQuicksort_PushDown_I1_I_I_I_I__V(a, tmp1, a.A[k], low, high)
//line :321:1
	continue L1 }; break L1
}
L2: for { var tmp2 int32; high = high - 1; tmp2 = high; if tmp2 > low {
	var max_ int32 = a.A[low]
	DualPivotQuicksort_PushDown_I1_I_I_I_I__V(a, low, a.A[high], low, high)
	a.A[high] = max_
//line :323:1
	continue L2 }; break L2
}
}


func DualPivotQuicksort_PushDown_I1_I_I_I_I__V(a *IntArray, p, value, low, high int32) {
	var k int32 = 0
L1: for {
	k = p<<1 - low + 2
	if k > high { break L1 }
	var tmp1 bool; var tmp2 bool; tmp2 = k == high; if !tmp2 { var tmp3 int32 = a.A[k]; tmp2 = tmp3 < a.A[k-1] }; tmp1 = tmp2; if tmp1 {
		k = k - 1 }
	if a.A[k] <= value { break L1 }
	var tmp4 int32 = p; var tmp5 int32; p = k; tmp5 = p; a.A[tmp4] = a.A[tmp5]
//line :330:1
	continue L1
}





	a.A[p] = value
}
func DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_I1_I_I__Z(sorter *DualPivotQuicksort_Sorter, a *IntArray, low, size int32) bool {
	var run *IntArray; var high int32 = low + size; var count int32 = 1; var last int32 = low; var k int32 = low + 1




L1: for { if k < high {
	var tmp1 int32 = a.A[k-1]; if tmp1 < a.A[k] {

	L2: for { var tmp2 bool; var tmp3 bool; var tmp4 int32; k = k + 1; tmp4 = k; tmp3 = tmp4 < high; if tmp3 {
		var tmp5 int32 = a.A[k-1]; tmp3 = tmp5 <= a.A[k] }
//line :348:1
		tmp2 = tmp3; if tmp2 { continue L2 }; break L2 } } else {
//line :346:1
			var tmp6 int32 = a.A[k-1]; if tmp6 > a.A[k] {





			L3: for { var tmp7 bool; var tmp8 bool; var tmp9 int32; k = k + 1; tmp9 = k; tmp8 = tmp9 < high; if tmp8 {
				var tmp10 int32 = a.A[k-1]; tmp8 = tmp10 >= a.A[k] }
//line :352:1
				tmp7 = tmp8; if tmp7 { continue L3 }; break L3
			}
				var i int32 = last - 1
				var j int32 = k
			L4: for { var tmp11 bool; var tmp12 bool; var tmp13 int32; i = i + 1; tmp13 = i; var tmp14 int32 = tmp13; var tmp15 int32; j = j - 1; tmp15 = j; tmp12 = tmp14 < tmp15; if tmp12 {
				var tmp16 int32 = a.A[i]; tmp12 = tmp16 > a.A[j] }
//line :356:1
				tmp11 = tmp12; if tmp11 {

					var ai int32 = a.A[i]; a.A[i] = a.A[j]; a.A[j] = ai
//line :356:1
					continue L4 }; break L4 } } else {




						var ak int32 = a.A[k]; L5: for {
							var tmp17 bool; var tmp18 bool; var tmp19 int32; k = k + 1; tmp19 = k; tmp18 = tmp19 < high; if tmp18 { tmp18 = ak == a.A[k] }; tmp17 = tmp18; if tmp17 { ak = ak; continue L5 }
//line :361:1
							break L5
						}
						if k < high { continue L1 } } }
	if run == nil {

		if k == high { return true }
		if k-low < 16 { return false }
		run = NewIntArray((size>>10 | 127) & 1023)


		run.A[0] = low } else {
			var tmp20 int32 = a.A[last-1]; if tmp20 > a.A[last] {
				if count > (k-low)>>7 {

					return false }
				var tmp21 int32; count = count + 1; tmp21 = count; if tmp21 == 5120 { return false }
				if count == int32(len(run.A)) {
					run = Arrays_CopyOf_I1_I__I1(run, count<<1) } } }
	var tmp22 *IntArray = run; var tmp23 int32 = count; var tmp24 int32; last = k; tmp24 = last; tmp22.A[tmp23] = tmp24
//line :345:1
	continue L1 }; break L1
}

































	if count > 1 {
		var b *IntArray; var offset int32 = low; var tmp25 bool; var tmp26 bool

		tmp26 = sorter == nil; if !tmp26 { var tmp27 *IntArray; b = A2g_CastArray[*IntArray](sorter.F_b, Prim_int.ArrayClass()); tmp27 = b; tmp26 = tmp27 == nil }; tmp25 = tmp26; if tmp25 {
			b = NewIntArray(size) } else {
				offset = sorter.F_offset }
		DualPivotQuicksort_MergeRuns_I1_I1_I_I_Z_I1_I_I__I1(a, b, offset, 1, !(sorter == nil), run, 0, count) }
//line :340:1
	return true
}















































func DualPivotQuicksort_MergeRuns_I1_I1_I_I_Z_I1_I_I__I1(a, b *IntArray, offset, aim int32, parallel bool, run *IntArray, lo, hi int32) *IntArray {

	if hi-lo == 1 {
		if aim >= 0 { return a } else {


			var i int32 = run.A[hi]; var j int32 = i - offset; var low int32 = run.A[lo]


		L1: for { if i > low {
			var tmp1 int32; j = j - 1; tmp1 = j; var tmp2 int32 = tmp1; var tmp3 int32; i = i - 1; tmp3 = i; b.A[tmp2] = a.A[tmp3]
//line :398:1
			continue L1 }; break L1 }
//line :394:1
			return b
		}


	} else {


		var mi int32 = lo; var tmp4 int32 = run.A[lo]; var rmi int32 = int32(uint32(tmp4+run.A[hi]) >> 1)

	L2: for { var tmp5 int32; mi = mi + 1; tmp5 = mi; if run.A[tmp5+1] <= rmi { continue L2 }; break L2 }
		var a1 *IntArray; var a2 *IntArray; var tmp6 bool; var tmp7 bool

		tmp7 = parallel; if tmp7 { tmp7 = hi-lo > 4 }; tmp6 = tmp7; if tmp6 {
			var merger *DualPivotQuicksort_RunMerger = DualPivotQuicksort_RunMerger_New_O_O_I_I_I1_I_I(a.Ref(), b.Ref(), offset, 0, run, mi, hi).ForkMe__DualPivotQuicksort_RunMerger()
			a1 = DualPivotQuicksort_MergeRuns_I1_I1_I_I_Z_I1_I_I__I1(a, b, offset, -aim, true, run, lo, mi)









			a2 = A2g_CastArray[*IntArray](NN(merger).GetDestination__O(), Prim_int.ArrayClass()) } else {

				a1 = DualPivotQuicksort_MergeRuns_I1_I1_I_I_Z_I1_I_I__I1(a, b, offset, -aim, false, run, lo, mi)









				a2 = DualPivotQuicksort_MergeRuns_I1_I1_I_I_Z_I1_I_I__I1(a, b, offset, 0, false, run, mi, hi) }
		var dst *IntArray; if a1 == a { dst = b } else { dst = a }; var k int32
		if a1 == a {
			k = run.A[lo] - offset } else {
				k = run.A[lo] }
//line :431:1
		var lo1 int32



		if a1 == b {
			lo1 = run.A[lo] - offset } else {
				lo1 = run.A[lo] }
//line :431:1
		var hi1 int32






		if a1 == b {
			hi1 = run.A[mi] - offset } else {
				hi1 = run.A[mi] }
//line :431:1
		var lo2 int32









		if a2 == b {
			lo2 = run.A[mi] - offset } else {
				lo2 = run.A[mi] }
//line :431:1
		var hi2 int32












		if a2 == b {
			hi2 = run.A[hi] - offset } else {
				hi2 = run.A[hi] }
		if parallel {
			DualPivotQuicksort_Merger_New_CountedCompleter_O_I_O_I_I_O_I_I(nil, dst.Ref(), k, a1.Ref(), lo1, hi1, a2.Ref(), lo2, hi2).Invoke__O() } else {
				DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_I1_I_I1_I_I_I1_I_I__V(nil, dst, k, a1, lo1, hi1, a2, lo2, hi2) }
//line :431:1
		return dst
	}
}


















func DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_I1_I_I1_I_I_I1_I_I__V(merger *DualPivotQuicksort_Merger, dst *IntArray, k int32, a1 *IntArray, lo1, hi1 int32, a2 *IntArray, lo2, hi2 int32) {


	var tmp1 bool; var tmp2 bool; tmp2 = !(merger == nil); if tmp2 { tmp2 = a1 == a2 }; tmp1 = tmp2; if tmp1 {
	L1: for {
		if hi1-lo1 < hi2-lo2 {
			var lo int32 = lo1; lo1 = lo2; lo2 = lo; var hi int32 = hi1; hi1 = hi2; hi2 = hi }
		if hi1-lo1 < 4096 { break L1 }
		var mi1 int32 = int32(uint32(lo1+hi1) >> 1); var key int32 = a1.A[mi1]
		var mi2 int32 = hi2
		var loo int32 = lo2

	L2: for { if loo < mi2 {
		var t_ int32 = int32(uint32(loo+mi2) >> 1)
		if key > a2.A[t_] { loo = t_ + 1 } else { mi2 = t_ }
//line :464:1
		continue L2 }; break L2
	}

		var d int32 = mi2 - lo2 + mi1 - lo1

		NN(merger).ForkMerger_O_I_O_I_I_O_I_I__V(dst.Ref(), k+d, a1.Ref(), mi1, hi1, a2.Ref(), mi2, hi2)
		hi1 = mi1
		hi2 = mi2
//line :456:1
		continue L1
	}
	}













L3: for { var tmp3 bool; var tmp4 bool; tmp4 = lo1 < hi1; if tmp4 { tmp4 = lo2 < hi2 }; tmp3 = tmp4; if tmp3 {
	var tmp5 int32 = k; var tmp6 int32; var tmp7 int32 = a1.A[lo1]

	if tmp7 < a2.A[lo2] {
		var tmp8 int32; var old_1 int32 = lo1; lo1 = lo1 + 1; tmp8 = old_1; tmp6 = a1.A[tmp8] } else {
			var tmp9 int32; var old_2 int32 = lo2; lo2 = lo2 + 1; tmp9 = old_2; tmp6 = a2.A[tmp9] }
//line :473:1
	dst.A[tmp5] = tmp6




	k = k + 1
//line :472:1
	continue L3 }; break L3
}





	var tmp10 bool; var tmp11 bool; tmp11 = !(dst == a1); if !tmp11 { tmp11 = k < lo1 }; tmp10 = tmp11; if tmp10 {
	L4: for { if lo1 < hi1 {
		dst.A[k] = a1.A[lo1]
		k = k + 1
		lo1 = lo1 + 1
//line :480:1
		continue L4 }; break L4
	}
	}

	var tmp12 bool; var tmp13 bool; tmp13 = !(dst == a2); if !tmp13 { tmp13 = k < lo2 }; tmp12 = tmp13; if tmp12 {
	L5: for { if lo2 < hi2 {
		dst.A[k] = a2.A[lo2]
		k = k + 1
		lo2 = lo2 + 1
//line :485:1
		continue L5 }; break L5
	}
	}
}

func DualPivotQuicksort_Sort_J1_I_I_I__V(a *LongArray, parallelism, low, high int32) {
	var size int32 = high - low; var tmp1 bool; var tmp2 bool
	tmp2 = parallelism > 1; if tmp2 { tmp2 = size > 4096 }; tmp1 = tmp2; if tmp1 {
		var depth int32 = DualPivotQuicksort_GetDepth_I_I__I(parallelism, size>>12); var b *LongArray
		if depth == 0 { b = nil } else { b = NewLongArray(size) }
		DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(nil, a.Ref(), b.Ref(), low, size, low, depth).Invoke__O() } else {
			DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_J1_I_I_I__V(nil, a, 0, low, high)
		} }
func DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_J1_I_I_I__V(sorter *DualPivotQuicksort_Sorter, a *LongArray, bits, low, high int32) {

L1: for {
	var end int32 = high - 1; var size int32 = high - low; var tmp1 bool; var tmp2 bool

	tmp2 = size < 65+bits; if tmp2 {
		tmp2 = bits&1 > 0 }
//line :503:1
	tmp1 = tmp2; if tmp1 {

		var tmp3 *Class; Long_Init(); tmp3 = Long_TYPE; var tmp4 *Class = tmp3; var tmp5 int64 = Unsafe_ARRAY_LONG_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp4, a.Ref(), tmp5, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0 any, p1, p2 int32) { DualPivotQuicksort_MixedInsertionSort_J1_I_I__V(A2g_CastArray[*LongArray](p0, Prim_long.ArrayClass()), p1, p2) }})







		return }
	if size < 44 {
		var tmp6 *Class; Long_Init(); tmp6 = Long_TYPE; var tmp7 *Class = tmp6; var tmp8 int64 = Unsafe_ARRAY_LONG_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp7, a.Ref(), tmp8, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0_2 any, p1_2, p2_2 int32) { DualPivotQuicksort_InsertionSort_J1_I_I__V(A2g_CastArray[*LongArray](p0_2, Prim_long.ArrayClass()), p1_2, p2_2) }})







		return }
	var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = bits == 0; if !tmp11 { var tmp12 bool; tmp12 = size > 4096; if tmp12 { tmp12 = bits&1 > 0 }; tmp11 = tmp12 }; tmp10 = tmp11; if tmp10 {
		tmp10 = DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_J1_I_I__Z(sorter, a, low, size) }
//line :524:1
	tmp9 = tmp10; if tmp9 {

		return }
	var tmp13 int32; bits = bits + 6; tmp13 = bits; if tmp13 > 384 {
		DualPivotQuicksort_HeapSort_J1_I_I__V(a, low, high)
		return }
	var step int32 = size>>3*3 + 3; var e1 int32 = low + step; var e5 int32 = end - step; var e3 int32 = int32(uint32(e1+e5) >> 1); var e2 int32 = int32(uint32(e1+e3) >> 1); var e4 int32 = int32(uint32(e3+e5) >> 1); var a3 int64 = a.A[e3]; var tmp14 int64 = a.A[e5]






	if tmp14 < a.A[e2] {
		var t_ int64 = a.A[e5]; a.A[e5] = a.A[e2]; a.A[e2] = t_ }
	var tmp15 int64 = a.A[e4]; if tmp15 < a.A[e1] {
		var t__2 int64 = a.A[e4]; a.A[e4] = a.A[e1]; a.A[e1] = t__2 }
	var tmp16 int64 = a.A[e5]; if tmp16 < a.A[e4] {
		var t__3 int64 = a.A[e5]; a.A[e5] = a.A[e4]; a.A[e4] = t__3 }
	var tmp17 int64 = a.A[e2]; if tmp17 < a.A[e1] {
		var t__4 int64 = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = t__4 }
	var tmp18 int64 = a.A[e4]; if tmp18 < a.A[e2] {
		var t__5 int64 = a.A[e4]; a.A[e4] = a.A[e2]; a.A[e2] = t__5 }
	if a3 < a.A[e2] {

		if a3 < a.A[e1] {
			a.A[e3] = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = a3 } else {
				a.A[e3] = a.A[e2]; a.A[e2] = a3 } } else {
//line :547:1
					if a3 > a.A[e4] {





						if a3 > a.A[e5] {
							a.A[e3] = a.A[e4]; a.A[e4] = a.A[e5]; a.A[e5] = a3 } else {
								a.A[e3] = a.A[e4]; a.A[e4] = a3 } } }
	var lower int32 = 0; var upper int32 = 0; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; var tmp23 int64 = a.A[e1]

	tmp22 = tmp23 < a.A[e2]; if tmp22 { var tmp24 int64 = a.A[e2]; tmp22 = tmp24 < a.A[e3] }; tmp21 = tmp22; if tmp21 {
		var tmp25 int64 = a.A[e3]; tmp21 = tmp25 < a.A[e4] }
//line :558:1
	tmp20 = tmp21; if tmp20 {

		var tmp26 int64 = a.A[e4]; tmp20 = tmp26 < a.A[e5] }
//line :558:1
	tmp19 = tmp20; if tmp19 {


		var pivotIndices *IntArray; var tmp27 *Class; Long_Init(); tmp27 = Long_TYPE; var tmp28 *Class = tmp27; var tmp29 int64 = Unsafe_ARRAY_LONG_BASE_OFFSET; pivotIndices = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp28, a.Ref(), tmp29, low, high, e1, e5, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_3 any, p1_3, p2_3, p3, p4 int32) *IntArray { return DualPivotQuicksort_PartitionDualPivot_J1_I_I_I_I__I1(A2g_CastArray[*LongArray](p0_3, Prim_long.ArrayClass()), p1_3, p2_3, p3, p4) }})











		lower = pivotIndices.A[0]
		upper = pivotIndices.A[1]
		var tmp30 bool; var tmp31 bool; tmp31 = size > 4096; if tmp31 { tmp31 = !(sorter == nil) }; tmp30 = tmp31; if tmp30 {

			NN(sorter).ForkSorter_I_I_I__V(bits|1, lower+1, upper)
			NN(sorter).ForkSorter_I_I_I__V(bits|1, upper+1, high) } else {

				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_J1_I_I_I__V(sorter, a, bits|1, lower+1, upper)





				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_J1_I_I_I__V(sorter, a, bits|1, upper+1, high) } } else {





					var pivotIndices_2 *IntArray; var tmp32 *Class; Long_Init(); tmp32 = Long_TYPE; var tmp33 *Class = tmp32; var tmp34 int64 = Unsafe_ARRAY_LONG_BASE_OFFSET; pivotIndices_2 = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp33, a.Ref(), tmp34, low, high, e3, e3, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_4 any, p1_4, p2_4, p3_2, p4_2 int32) *IntArray { return DualPivotQuicksort_PartitionSinglePivot_J1_I_I_I_I__I1(A2g_CastArray[*LongArray](p0_4, Prim_long.ArrayClass()), p1_4, p2_4, p3_2, p4_2) }})











					lower = pivotIndices_2.A[0]
					upper = pivotIndices_2.A[1]
					var tmp35 bool; var tmp36 bool; tmp36 = size > 4096; if tmp36 { tmp36 = !(sorter == nil) }; tmp35 = tmp36; if tmp35 {
						NN(sorter).ForkSorter_I_I_I__V(bits|1, upper, high) } else {
							DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_J1_I_I_I__V(sorter, a, bits|1, upper, high) } }
	high = lower
//line :500:1
	continue L1
}
}












































































































func DualPivotQuicksort_PartitionDualPivot_J1_I_I_I_I__I1(a *LongArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e1 int32 = pivotIndex1; var e5 int32 = pivotIndex2; var pivot1 int64 = a.A[e1]; var pivot2 int64 = a.A[e5]






	a.A[e1] = a.A[lower]
	a.A[e5] = a.A[upper]
L1: for { var tmp1 int32; lower = lower + 1; tmp1 = lower; if a.A[tmp1] < pivot1 { continue L1 }; break L1 }
L2: for { var tmp2 int32; upper = upper - 1; tmp2 = upper; if a.A[tmp2] > pivot2 { continue L2 }; break L2 }
	var unused int32; _ = unused; lower = lower - 1; unused = lower; var k int32
	upper = upper + 1; k = upper
L3: for { var tmp3 int32; k = k - 1; tmp3 = k; if tmp3 > lower {
	var ak int64 = a.A[k]
	if ak < pivot1 {
	L4: for { if lower < k {
		var tmp4 int32; lower = lower + 1; tmp4 = lower; if a.A[tmp4] >= pivot1 {
			if a.A[lower] > pivot2 {

				var tmp5 int32 = k; var tmp6 int32; upper = upper - 1; tmp6 = upper; a.A[tmp5] = a.A[tmp6]
				a.A[upper] = a.A[lower] } else {
					a.A[k] = a.A[lower] }
			a.A[lower] = ak
			break L4 }
//line :631:1
		continue L4 }; break L4
	}





	} else {

		if ak > pivot2 {
			var tmp7 int32 = k; var tmp8 int32; upper = upper - 1; tmp8 = upper; a.A[tmp7] = a.A[tmp8]
			a.A[upper] = ak } }
//line :628:1
	continue L3 }; break L3
}













	a.A[low] = a.A[lower]
	a.A[lower] = pivot1
	a.A[end] = a.A[upper]
	a.A[upper] = pivot2
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_PartitionSinglePivot_J1_I_I_I_I__I1(a *LongArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e3 int32 = pivotIndex1; var pivot int64 = a.A[e3]




	a.A[e3] = a.A[lower]
	var k int32; upper = upper + 1; k = upper
L1: for { var tmp1 int32; k = k - 1; tmp1 = k; if tmp1 > lower {
	var ak int64 = a.A[k]
	if ak == pivot { } else {
		a.A[k] = pivot
		if ak < pivot {

		L2: for { var tmp2 int32; lower = lower + 1; tmp2 = lower; if a.A[tmp2] < pivot { continue L2 }; break L2 }
			if a.A[lower] > pivot {
				var tmp3 int32; upper = upper - 1; tmp3 = upper; a.A[tmp3] = a.A[lower] }
			a.A[lower] = ak } else {
				var tmp4 int32; upper = upper - 1; tmp4 = upper; a.A[tmp4] = ak } }
//line :660:1
	continue L1 }; break L1
}









	a.A[low] = a.A[lower]
	a.A[lower] = pivot
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_MixedInsertionSort_J1_I_I__V(a *LongArray, low, high int32) {
	var size int32 = high - low; var end int32 = high - 3*(size>>5<<3)




	if end == high {
		var i int32 = 0
	L1: for { var tmp1 int32; low = low + 1; tmp1 = low; if tmp1 < end {
		var ai int64; var tmp2 int32; i = low; tmp2 = i; ai = a.A[tmp2]
	L2: for { var tmp3 int32; i = i - 1; tmp3 = i; if ai < a.A[tmp3] {
		a.A[i+1] = a.A[i]
//line :685:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai
//line :683:1
		continue L1 }; break L1
	}

	} else {

		var pin int64 = a.A[end]
		var i_2 int32 = 0
		var p int32 = high
	L3: for { var tmp4 int32; low = low + 1; tmp4 = low; if tmp4 < end {
		var ai_2 int64; var tmp5 int32; i_2 = low; tmp5 = i_2; ai_2 = a.A[tmp5]
		if ai_2 < a.A[i_2-1] {

			var tmp6 int32 = i_2; var tmp7 int32; i_2 = i_2 - 1; tmp7 = i_2; a.A[tmp6] = a.A[tmp7]
		L4: for { var tmp8 int64 = ai_2; var tmp9 int32; i_2 = i_2 - 1; tmp9 = i_2; if tmp8 < a.A[tmp9] {
			a.A[i_2+1] = a.A[i_2]
//line :696:1
			continue L4 }; break L4
		}
			a.A[i_2+1] = ai_2 } else {
				var tmp10 bool; var tmp11 bool; tmp11 = p > i_2; if tmp11 { tmp11 = ai_2 > pin }; tmp10 = tmp11; if tmp10 {
				L5: for { var tmp12 int32; p = p - 1; tmp12 = p; if a.A[tmp12] > pin { continue L5 }; break L5 }
					if p > i_2 { ai_2 = a.A[p]; a.A[p] = a.A[i_2] }
				L6: for { var tmp13 int64 = ai_2; var tmp14 int32; i_2 = i_2 - 1; tmp14 = i_2; if tmp13 < a.A[tmp14] {
					a.A[i_2+1] = a.A[i_2]
//line :702:1
					continue L6 }; break L6
				}
					a.A[i_2+1] = ai_2 } }
//line :691:1
		continue L3 }; break L3
	}












		var i_3 int32 = 0
	L7: for { if low < high {
		var a1 int64; var tmp15 int32; i_3 = low; tmp15 = i_3; a1 = a.A[tmp15]; var a2 int64; var tmp16 int32
		low = low + 1; tmp16 = low; a2 = a.A[tmp16]
		if a1 > a2 {

		L8: for { var tmp17 int32; i_3 = i_3 - 1; tmp17 = i_3; if a1 < a.A[tmp17] {
			a.A[i_3+2] = a.A[i_3]
//line :711:1
			continue L8 }; break L8
		}
			var tmp18 int32; i_3 = i_3 + 1; tmp18 = i_3; a.A[tmp18+1] = a1
		L9: for { var tmp19 int32; i_3 = i_3 - 1; tmp19 = i_3; if a2 < a.A[tmp19] {
			a.A[i_3+1] = a.A[i_3]
//line :714:1
			continue L9 }; break L9
		}
			a.A[i_3+1] = a2 } else {
				if a1 < a.A[i_3-1] {
				L10: for { var tmp20 int32; i_3 = i_3 - 1; tmp20 = i_3; if a2 < a.A[tmp20] {
					a.A[i_3+2] = a.A[i_3]
//line :718:1
					continue L10 }; break L10
				}
					var tmp21 int32; i_3 = i_3 + 1; tmp21 = i_3; a.A[tmp21+1] = a2
				L11: for { var tmp22 int32; i_3 = i_3 - 1; tmp22 = i_3; if a1 < a.A[tmp22] {
					a.A[i_3+1] = a.A[i_3]
//line :721:1
					continue L11 }; break L11
				}
					a.A[i_3+1] = a1 } }
		low = low + 1
//line :706:1
		continue L7 }; break L7
	}
	}
}
















func DualPivotQuicksort_InsertionSort_J1_I_I__V(a *LongArray, low, high int32) {
	var i int32 = 0
	var k int32 = low
L1: for { var tmp1 int32; k = k + 1; tmp1 = k; if tmp1 < high {
	var ai int64; var tmp2 int32; i = k; tmp2 = i; ai = a.A[tmp2]
	if ai < a.A[i-1] {
	L2: for { var tmp3 bool; var tmp4 bool; var tmp5 int32; i = i - 1; tmp5 = i; tmp4 = tmp5 >= low; if tmp4 { tmp4 = ai < a.A[i] }; tmp3 = tmp4; if tmp3 {
		a.A[i+1] = a.A[i]
//line :732:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai }
//line :729:1
	continue L1 }; break L1
}
}




func DualPivotQuicksort_HeapSort_J1_I_I__V(a *LongArray, low, high int32) {
	var k int32 = int32(uint32(low+high) >> 1)
L1: for { if k > low {
	var tmp1 int32; k = k - 1; tmp1 = k; DualPivotQuicksort_PushDown_J1_I_J_I_I__V(a, tmp1, a.A[k], low, high)
//line :738:1
	continue L1 }; break L1
}
L2: for { var tmp2 int32; high = high - 1; tmp2 = high; if tmp2 > low {
	var max_ int64 = a.A[low]
	DualPivotQuicksort_PushDown_J1_I_J_I_I__V(a, low, a.A[high], low, high)
	a.A[high] = max_
//line :740:1
	continue L2 }; break L2
}
}


func DualPivotQuicksort_PushDown_J1_I_J_I_I__V(a *LongArray, p int32, value int64, low, high int32) {

	var k int32 = 0
L1: for {
	k = p<<1 - low + 2
	if k > high { break L1 }
	var tmp1 bool; var tmp2 bool; tmp2 = k == high; if !tmp2 { var tmp3 int64 = a.A[k]; tmp2 = tmp3 < a.A[k-1] }; tmp1 = tmp2; if tmp1 {
		k = k - 1 }
	if a.A[k] <= value { break L1 }
	var tmp4 int32 = p; var tmp5 int32; p = k; tmp5 = p; a.A[tmp4] = a.A[tmp5]
//line :748:1
	continue L1
}





	a.A[p] = value
}
func DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_J1_I_I__Z(sorter *DualPivotQuicksort_Sorter, a *LongArray, low, size int32) bool {
	var run *IntArray; var high int32 = low + size; var count int32 = 1; var last int32 = low; var k int32 = low + 1




L1: for { if k < high {
	var tmp1 int64 = a.A[k-1]; if tmp1 < a.A[k] {

	L2: for { var tmp2 bool; var tmp3 bool; var tmp4 int32; k = k + 1; tmp4 = k; tmp3 = tmp4 < high; if tmp3 {
		var tmp5 int64 = a.A[k-1]; tmp3 = tmp5 <= a.A[k] }
//line :766:1
		tmp2 = tmp3; if tmp2 { continue L2 }; break L2 } } else {
//line :764:1
			var tmp6 int64 = a.A[k-1]; if tmp6 > a.A[k] {





			L3: for { var tmp7 bool; var tmp8 bool; var tmp9 int32; k = k + 1; tmp9 = k; tmp8 = tmp9 < high; if tmp8 {
				var tmp10 int64 = a.A[k-1]; tmp8 = tmp10 >= a.A[k] }
//line :770:1
				tmp7 = tmp8; if tmp7 { continue L3 }; break L3
			}
				var i int32 = last - 1
				var j int32 = k
			L4: for { var tmp11 bool; var tmp12 bool; var tmp13 int32; i = i + 1; tmp13 = i; var tmp14 int32 = tmp13; var tmp15 int32; j = j - 1; tmp15 = j; tmp12 = tmp14 < tmp15; if tmp12 {
				var tmp16 int64 = a.A[i]; tmp12 = tmp16 > a.A[j] }
//line :774:1
				tmp11 = tmp12; if tmp11 {

					var ai int64 = a.A[i]; a.A[i] = a.A[j]; a.A[j] = ai
//line :774:1
					continue L4 }; break L4 } } else {




						var ak int64 = a.A[k]; L5: for {
							var tmp17 bool; var tmp18 bool; var tmp19 int32; k = k + 1; tmp19 = k; tmp18 = tmp19 < high; if tmp18 { tmp18 = ak == a.A[k] }; tmp17 = tmp18; if tmp17 { ak = ak; continue L5 }
//line :779:1
							break L5
						}
						if k < high { continue L1 } } }
	if run == nil {

		if k == high { return true }
		if k-low < 16 { return false }
		run = NewIntArray((size>>10 | 127) & 1023)


		run.A[0] = low } else {
			var tmp20 int64 = a.A[last-1]; if tmp20 > a.A[last] {
				if count > (k-low)>>7 {

					return false }
				var tmp21 int32; count = count + 1; tmp21 = count; if tmp21 == 5120 { return false }
				if count == int32(len(run.A)) {
					run = Arrays_CopyOf_I1_I__I1(run, count<<1) } } }
	var tmp22 *IntArray = run; var tmp23 int32 = count; var tmp24 int32; last = k; tmp24 = last; tmp22.A[tmp23] = tmp24
//line :763:1
	continue L1 }; break L1
}

































	if count > 1 {
		var b *LongArray; var offset int32 = low; var tmp25 bool; var tmp26 bool

		tmp26 = sorter == nil; if !tmp26 { var tmp27 *LongArray; b = A2g_CastArray[*LongArray](sorter.F_b, Prim_long.ArrayClass()); tmp27 = b; tmp26 = tmp27 == nil }; tmp25 = tmp26; if tmp25 {
			b = NewLongArray(size) } else {
				offset = sorter.F_offset }
		DualPivotQuicksort_MergeRuns_J1_J1_I_I_Z_I1_I_I__J1(a, b, offset, 1, !(sorter == nil), run, 0, count) }
//line :758:1
	return true
}















































func DualPivotQuicksort_MergeRuns_J1_J1_I_I_Z_I1_I_I__J1(a, b *LongArray, offset, aim int32, parallel bool, run *IntArray, lo, hi int32) *LongArray {

	if hi-lo == 1 {
		if aim >= 0 { return a } else {


			var i int32 = run.A[hi]; var j int32 = i - offset; var low int32 = run.A[lo]


		L1: for { if i > low {
			var tmp1 int32; j = j - 1; tmp1 = j; var tmp2 int32 = tmp1; var tmp3 int32; i = i - 1; tmp3 = i; b.A[tmp2] = a.A[tmp3]
//line :816:1
			continue L1 }; break L1 }
//line :812:1
			return b
		}


	} else {


		var mi int32 = lo; var tmp4 int32 = run.A[lo]; var rmi int32 = int32(uint32(tmp4+run.A[hi]) >> 1)

	L2: for { var tmp5 int32; mi = mi + 1; tmp5 = mi; if run.A[tmp5+1] <= rmi { continue L2 }; break L2 }
		var a1 *LongArray; var a2 *LongArray; var tmp6 bool; var tmp7 bool

		tmp7 = parallel; if tmp7 { tmp7 = hi-lo > 4 }; tmp6 = tmp7; if tmp6 {
			var merger *DualPivotQuicksort_RunMerger = DualPivotQuicksort_RunMerger_New_O_O_I_I_I1_I_I(a.Ref(), b.Ref(), offset, 0, run, mi, hi).ForkMe__DualPivotQuicksort_RunMerger()
			a1 = DualPivotQuicksort_MergeRuns_J1_J1_I_I_Z_I1_I_I__J1(a, b, offset, -aim, true, run, lo, mi)









			a2 = A2g_CastArray[*LongArray](NN(merger).GetDestination__O(), Prim_long.ArrayClass()) } else {

				a1 = DualPivotQuicksort_MergeRuns_J1_J1_I_I_Z_I1_I_I__J1(a, b, offset, -aim, false, run, lo, mi)









				a2 = DualPivotQuicksort_MergeRuns_J1_J1_I_I_Z_I1_I_I__J1(a, b, offset, 0, false, run, mi, hi) }
		var dst *LongArray; if a1 == a { dst = b } else { dst = a }; var k int32
		if a1 == a {
			k = run.A[lo] - offset } else {
				k = run.A[lo] }
//line :849:1
		var lo1 int32



		if a1 == b {
			lo1 = run.A[lo] - offset } else {
				lo1 = run.A[lo] }
//line :849:1
		var hi1 int32






		if a1 == b {
			hi1 = run.A[mi] - offset } else {
				hi1 = run.A[mi] }
//line :849:1
		var lo2 int32









		if a2 == b {
			lo2 = run.A[mi] - offset } else {
				lo2 = run.A[mi] }
//line :849:1
		var hi2 int32












		if a2 == b {
			hi2 = run.A[hi] - offset } else {
				hi2 = run.A[hi] }
		if parallel {
			DualPivotQuicksort_Merger_New_CountedCompleter_O_I_O_I_I_O_I_I(nil, dst.Ref(), k, a1.Ref(), lo1, hi1, a2.Ref(), lo2, hi2).Invoke__O() } else {
				DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_J1_I_J1_I_I_J1_I_I__V(nil, dst, k, a1, lo1, hi1, a2, lo2, hi2) }
//line :849:1
		return dst
	}
}


















func DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_J1_I_J1_I_I_J1_I_I__V(merger *DualPivotQuicksort_Merger, dst *LongArray, k int32, a1 *LongArray, lo1, hi1 int32, a2 *LongArray, lo2, hi2 int32) {


	var tmp1 bool; var tmp2 bool; tmp2 = !(merger == nil); if tmp2 { tmp2 = a1 == a2 }; tmp1 = tmp2; if tmp1 {
	L1: for {
		if hi1-lo1 < hi2-lo2 {
			var lo int32 = lo1; lo1 = lo2; lo2 = lo; var hi int32 = hi1; hi1 = hi2; hi2 = hi }
		if hi1-lo1 < 4096 { break L1 }
		var mi1 int32 = int32(uint32(lo1+hi1) >> 1); var key int64 = a1.A[mi1]
		var mi2 int32 = hi2
		var loo int32 = lo2

	L2: for { if loo < mi2 {
		var t_ int32 = int32(uint32(loo+mi2) >> 1)
		if key > a2.A[t_] { loo = t_ + 1 } else { mi2 = t_ }
//line :882:1
		continue L2 }; break L2
	}

		var d int32 = mi2 - lo2 + mi1 - lo1

		NN(merger).ForkMerger_O_I_O_I_I_O_I_I__V(dst.Ref(), k+d, a1.Ref(), mi1, hi1, a2.Ref(), mi2, hi2)
		hi1 = mi1
		hi2 = mi2
//line :874:1
		continue L1
	}
	}













L3: for { var tmp3 bool; var tmp4 bool; tmp4 = lo1 < hi1; if tmp4 { tmp4 = lo2 < hi2 }; tmp3 = tmp4; if tmp3 {
	var tmp5 int32 = k; var tmp6 int64; var tmp7 int64 = a1.A[lo1]

	if tmp7 < a2.A[lo2] {
		var tmp8 int32; var old_3 int32 = lo1; lo1 = lo1 + 1; tmp8 = old_3; tmp6 = a1.A[tmp8] } else {
			var tmp9 int32; var old_4 int32 = lo2; lo2 = lo2 + 1; tmp9 = old_4; tmp6 = a2.A[tmp9] }
//line :891:1
	dst.A[tmp5] = tmp6




	k = k + 1
//line :890:1
	continue L3 }; break L3
}





	var tmp10 bool; var tmp11 bool; tmp11 = !(dst == a1); if !tmp11 { tmp11 = k < lo1 }; tmp10 = tmp11; if tmp10 {
	L4: for { if lo1 < hi1 {
		dst.A[k] = a1.A[lo1]
		k = k + 1
		lo1 = lo1 + 1
//line :898:1
		continue L4 }; break L4
	}
	}

	var tmp12 bool; var tmp13 bool; tmp13 = !(dst == a2); if !tmp13 { tmp13 = k < lo2 }; tmp12 = tmp13; if tmp12 {
	L5: for { if lo2 < hi2 {
		dst.A[k] = a2.A[lo2]
		k = k + 1
		lo2 = lo2 + 1
//line :903:1
		continue L5 }; break L5
	}
	}
}

func DualPivotQuicksort_Sort_B1_I_I__V(a *ByteArray, low, high int32) {
	if high-low > 64 {
		DualPivotQuicksort_CountingSort_B1_I_I__V(a, low, high) } else {
			DualPivotQuicksort_InsertionSort_B1_I_I__V(a, low, high)
		} }
func DualPivotQuicksort_InsertionSort_B1_I_I__V(a *ByteArray, low, high int32) {
	var i int32 = 0
	var k int32 = low
L1: for { var tmp1 int32; k = k + 1; tmp1 = k; if tmp1 < high {
	var ai int8; var tmp2 int32; i = k; tmp2 = i; ai = a.A[tmp2]
	if int32(ai) < int32(a.A[i-1]) {
	L2: for { var tmp3 bool; var tmp4 bool; var tmp5 int32; i = i - 1; tmp5 = i; tmp4 = tmp5 >= low; if tmp4 { tmp4 = int32(ai) < int32(a.A[i]) }; tmp3 = tmp4; if tmp3 {
		a.A[i+1] = a.A[i]
//line :919:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai }
//line :916:1
	continue L1 }; break L1
}
}









func DualPivotQuicksort_CountingSort_B1_I_I__V(a *ByteArray, low, high int32) {
	var count *IntArray = NewIntArray(256)
	var i int32 = high
L1: for { if i > low {
	var i_5 int32; var tmp1 int32; i = i - 1; tmp1 = i; i_5 = int32(a.A[tmp1]) & 255
	count.A[i_5] = count.A[i_5] + 1
//line :931:1
	continue L1 }; break L1
}

	if high-low > 256 {
		var i_2 int32 = 384
	L2: for { var tmp2 int32; i_2 = i_2 - 1; tmp2 = i_2; if tmp2 > 127 {
		var value int32 = i_2 & 255
		low = high - count.A[value]
	L3: for { if high > low {
		var tmp3 int32; high = high - 1; tmp3 = high; a.A[tmp3] = int8(value)
//line :939:1
		continue L3 }; break L3 }
//line :936:1
		continue L2 }; break L2
	}

	} else {

		var i_3 int32 = 384
	L4: for { if high > low {
	L5: for { var tmp4 int32; i_3 = i_3 - 1; tmp4 = i_3; if count.A[tmp4&255] == 0 { continue L5 }; break L5 }
		var value_2 int32 = i_3 & 255; var c int32 = count.A[value_2]

	L6: for {
		var tmp5 int32; high = high - 1; tmp5 = high; a.A[tmp5] = int8(value_2)
		var tmp6 int32; c = c - 1; tmp6 = c; if tmp6 > 0 { continue L6 }
//line :946:1
		break L6 }
//line :942:1
		continue L4 }; break L4
	}
	}
}




func DualPivotQuicksort_Sort_C1_I_I__V(a *CharArray, low, high int32) {
	if high-low > 1750 {
		DualPivotQuicksort_CountingSort_C1_I_I__V(a, low, high) } else {
			DualPivotQuicksort_Sort_C1_I_I_I__V(a, 0, low, high)
		} }
func DualPivotQuicksort_Sort_C1_I_I_I__V(a *CharArray, bits, low, high int32) {
L1: for {
	var end int32 = high - 1; var size int32 = high - low

	if size < 44 {
		DualPivotQuicksort_InsertionSort_C1_I_I__V(a, low, high)
		return }
	var tmp1 int32; bits = bits + 6; tmp1 = bits; if tmp1 > 384 {
		DualPivotQuicksort_CountingSort_C1_I_I__V(a, low, high)
		return }
	var step int32 = size>>3*3 + 3; var e1 int32 = low + step; var e5 int32 = end - step; var e3 int32 = int32(uint32(e1+e5) >> 1); var e2 int32 = int32(uint32(e1+e3) >> 1); var e4 int32 = int32(uint32(e3+e5) >> 1); var a3 uint16 = a.A[e3]; var tmp2 int32 = int32(a.A[e5])






	if tmp2 < int32(a.A[e2]) {
		var t_ uint16 = a.A[e5]; a.A[e5] = a.A[e2]; a.A[e2] = t_ }
	var tmp3 int32 = int32(a.A[e4]); if tmp3 < int32(a.A[e1]) {
		var t__2 uint16 = a.A[e4]; a.A[e4] = a.A[e1]; a.A[e1] = t__2 }
	var tmp4 int32 = int32(a.A[e5]); if tmp4 < int32(a.A[e4]) {
		var t__3 uint16 = a.A[e5]; a.A[e5] = a.A[e4]; a.A[e4] = t__3 }
	var tmp5 int32 = int32(a.A[e2]); if tmp5 < int32(a.A[e1]) {
		var t__4 uint16 = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = t__4 }
	var tmp6 int32 = int32(a.A[e4]); if tmp6 < int32(a.A[e2]) {
		var t__5 uint16 = a.A[e4]; a.A[e4] = a.A[e2]; a.A[e2] = t__5 }
	if int32(a3) < int32(a.A[e2]) {

		if int32(a3) < int32(a.A[e1]) {
			a.A[e3] = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = a3 } else {
				a.A[e3] = a.A[e2]; a.A[e2] = a3 } } else {
//line :982:1
					if int32(a3) > int32(a.A[e4]) {





						if int32(a3) > int32(a.A[e5]) {
							a.A[e3] = a.A[e4]; a.A[e4] = a.A[e5]; a.A[e5] = a3 } else {
								a.A[e3] = a.A[e4]; a.A[e4] = a3 } } }
	var lower int32 = low; var upper int32 = end; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 int32 = int32(a.A[e1])

	tmp10 = tmp11 < int32(a.A[e2]); if tmp10 { var tmp12 int32 = int32(a.A[e2]); tmp10 = tmp12 < int32(a.A[e3]) }; tmp9 = tmp10; if tmp9 {
		var tmp13 int32 = int32(a.A[e3]); tmp9 = tmp13 < int32(a.A[e4]) }
//line :993:1
	tmp8 = tmp9; if tmp8 {

		var tmp14 int32 = int32(a.A[e4]); tmp8 = tmp14 < int32(a.A[e5]) }
//line :993:1
	tmp7 = tmp8; if tmp7 {


		var pivot1 uint16 = a.A[e1]; var pivot2 uint16 = a.A[e5]

		a.A[e1] = a.A[lower]
		a.A[e5] = a.A[upper]
	L2: for { var tmp15 int32; lower = lower + 1; tmp15 = lower; if int32(a.A[tmp15]) < int32(pivot1) { continue L2 }; break L2 }
	L3: for { var tmp16 int32; upper = upper - 1; tmp16 = upper; if int32(a.A[tmp16]) > int32(pivot2) { continue L3 }; break L3 }
		var unused int32; _ = unused; lower = lower - 1; unused = lower; var k int32
		upper = upper + 1; k = upper
	L4: for { var tmp17 int32; k = k - 1; tmp17 = k; if tmp17 > lower {
		var ak uint16 = a.A[k]
		if int32(ak) < int32(pivot1) {
		L5: for { if lower < k {
			var tmp18 int32; lower = lower + 1; tmp18 = lower; if int32(a.A[tmp18]) >= int32(pivot1) {
				if int32(a.A[lower]) > int32(pivot2) {

					var tmp19 int32 = k; var tmp20 int32; upper = upper - 1; tmp20 = upper; a.A[tmp19] = a.A[tmp20]
					a.A[upper] = a.A[lower] } else {
						a.A[k] = a.A[lower] }
				a.A[lower] = ak
				break L5 }
//line :1007:1
			continue L5 }; break L5 } } else {








				if int32(ak) > int32(pivot2) {
					var tmp21 int32 = k; var tmp22 int32; upper = upper - 1; tmp22 = upper; a.A[tmp21] = a.A[tmp22]
					a.A[upper] = ak } }
//line :1004:1
		continue L4 }; break L4
	}













		a.A[low] = a.A[lower]
		a.A[lower] = pivot1
		a.A[end] = a.A[upper]
		a.A[upper] = pivot2
		DualPivotQuicksort_Sort_C1_I_I_I__V(a, bits|1, lower+1, upper)
		DualPivotQuicksort_Sort_C1_I_I_I__V(a, bits|1, upper+1, high) } else {
			var pivot uint16 = a.A[e3]
			a.A[e3] = a.A[lower]
			var k_2 int32; upper = upper + 1; k_2 = upper
		L6: for { var tmp23 int32; k_2 = k_2 - 1; tmp23 = k_2; if tmp23 > lower {
			var ak_2 uint16 = a.A[k_2]
			if int32(ak_2) == int32(pivot) { } else {
				a.A[k_2] = pivot
				if int32(ak_2) < int32(pivot) {

				L7: for { var tmp24 int32; lower = lower + 1; tmp24 = lower; if int32(a.A[tmp24]) < int32(pivot) { continue L7 }; break L7 }
					if int32(a.A[lower]) > int32(pivot) {
						var tmp25 int32; upper = upper - 1; tmp25 = upper; a.A[tmp25] = a.A[lower] }
					a.A[lower] = ak_2 } else {
						var tmp26 int32; upper = upper - 1; tmp26 = upper; a.A[tmp26] = ak_2 } }
//line :1028:1
			continue L6 }; break L6
		}









			a.A[low] = a.A[lower]
			a.A[lower] = pivot
			DualPivotQuicksort_Sort_C1_I_I_I__V(a, bits|1, upper, high) }
	high = lower
//line :956:1
	continue L1
}
}





















































































func DualPivotQuicksort_InsertionSort_C1_I_I__V(a *CharArray, low, high int32) {
	var i int32 = 0
	var k int32 = low
L1: for { var tmp1 int32; k = k + 1; tmp1 = k; if tmp1 < high {
	var ai uint16; var tmp2 int32; i = k; tmp2 = i; ai = a.A[tmp2]
	if int32(ai) < int32(a.A[i-1]) {
	L2: for { var tmp3 bool; var tmp4 bool; var tmp5 int32; i = i - 1; tmp5 = i; tmp4 = tmp5 >= low; if tmp4 { tmp4 = int32(ai) < int32(a.A[i]) }; tmp3 = tmp4; if tmp3 {
		a.A[i+1] = a.A[i]
//line :1050:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai }
//line :1047:1
	continue L1 }; break L1
}
}






func DualPivotQuicksort_CountingSort_C1_I_I__V(a *CharArray, low, high int32) {
	var count *IntArray = NewIntArray(65536)
	var i int32 = high
L1: for { if i > low {
	var i_6 uint16; var tmp1 int32; i = i - 1; tmp1 = i; i_6 = a.A[tmp1]
	count.A[int32(i_6)] = count.A[int32(i_6)] + 1
//line :1059:1
	continue L1 }; break L1
}

	if high-low > 65536 {
		var i_2 int32 = 65536
	L2: for { if i_2 > 0 {
		var tmp2 int32 = high; var tmp3 int32; i_2 = i_2 - 1; tmp3 = i_2; low = tmp2 - count.A[tmp3]
	L3: for { if high > low { var tmp4 int32; high = high - 1; tmp4 = high; a.A[tmp4] = uint16(i_2); continue L3 }; break L3 }
//line :1064:1
		continue L2 }; break L2
	} } else {

		var i_3 int32 = 65536
	L4: for { if high > low {
	L5: for { var tmp5 int32; i_3 = i_3 - 1; tmp5 = i_3; if count.A[tmp5] == 0 { continue L5 }; break L5 }
		var c int32 = count.A[i_3]
	L6: for {
		var tmp6 int32; high = high - 1; tmp6 = high; a.A[tmp6] = uint16(i_3)
		var tmp7 int32; c = c - 1; tmp7 = c; if tmp7 > 0 { continue L6 }
//line :1071:1
		break L6 }
//line :1068:1
		continue L4 }; break L4
	}
	}
}



func DualPivotQuicksort_Sort_S1_I_I__V(a *ShortArray, low, high int32) {
	if high-low > 1750 {
		DualPivotQuicksort_CountingSort_S1_I_I__V(a, low, high) } else {
			DualPivotQuicksort_Sort_S1_I_I_I__V(a, 0, low, high)
		} }
func DualPivotQuicksort_Sort_S1_I_I_I__V(a *ShortArray, bits, low, high int32) {
L1: for {
	var end int32 = high - 1; var size int32 = high - low

	if size < 44 {
		DualPivotQuicksort_InsertionSort_S1_I_I__V(a, low, high)
		return }
	var tmp1 int32; bits = bits + 6; tmp1 = bits; if tmp1 > 384 {
		DualPivotQuicksort_CountingSort_S1_I_I__V(a, low, high)
		return }
	var step int32 = size>>3*3 + 3; var e1 int32 = low + step; var e5 int32 = end - step; var e3 int32 = int32(uint32(e1+e5) >> 1); var e2 int32 = int32(uint32(e1+e3) >> 1); var e4 int32 = int32(uint32(e3+e5) >> 1); var a3 int16 = a.A[e3]; var tmp2 int32 = int32(a.A[e5])






	if tmp2 < int32(a.A[e2]) {
		var t_ int16 = a.A[e5]; a.A[e5] = a.A[e2]; a.A[e2] = t_ }
	var tmp3 int32 = int32(a.A[e4]); if tmp3 < int32(a.A[e1]) {
		var t__2 int16 = a.A[e4]; a.A[e4] = a.A[e1]; a.A[e1] = t__2 }
	var tmp4 int32 = int32(a.A[e5]); if tmp4 < int32(a.A[e4]) {
		var t__3 int16 = a.A[e5]; a.A[e5] = a.A[e4]; a.A[e4] = t__3 }
	var tmp5 int32 = int32(a.A[e2]); if tmp5 < int32(a.A[e1]) {
		var t__4 int16 = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = t__4 }
	var tmp6 int32 = int32(a.A[e4]); if tmp6 < int32(a.A[e2]) {
		var t__5 int16 = a.A[e4]; a.A[e4] = a.A[e2]; a.A[e2] = t__5 }
	if int32(a3) < int32(a.A[e2]) {

		if int32(a3) < int32(a.A[e1]) {
			a.A[e3] = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = a3 } else {
				a.A[e3] = a.A[e2]; a.A[e2] = a3 } } else {
//line :1107:1
					if int32(a3) > int32(a.A[e4]) {





						if int32(a3) > int32(a.A[e5]) {
							a.A[e3] = a.A[e4]; a.A[e4] = a.A[e5]; a.A[e5] = a3 } else {
								a.A[e3] = a.A[e4]; a.A[e4] = a3 } } }
	var lower int32 = low; var upper int32 = end; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 int32 = int32(a.A[e1])

	tmp10 = tmp11 < int32(a.A[e2]); if tmp10 { var tmp12 int32 = int32(a.A[e2]); tmp10 = tmp12 < int32(a.A[e3]) }; tmp9 = tmp10; if tmp9 {
		var tmp13 int32 = int32(a.A[e3]); tmp9 = tmp13 < int32(a.A[e4]) }
//line :1118:1
	tmp8 = tmp9; if tmp8 {

		var tmp14 int32 = int32(a.A[e4]); tmp8 = tmp14 < int32(a.A[e5]) }
//line :1118:1
	tmp7 = tmp8; if tmp7 {


		var pivot1 int16 = a.A[e1]; var pivot2 int16 = a.A[e5]

		a.A[e1] = a.A[lower]
		a.A[e5] = a.A[upper]
	L2: for { var tmp15 int32; lower = lower + 1; tmp15 = lower; if int32(a.A[tmp15]) < int32(pivot1) { continue L2 }; break L2 }
	L3: for { var tmp16 int32; upper = upper - 1; tmp16 = upper; if int32(a.A[tmp16]) > int32(pivot2) { continue L3 }; break L3 }
		var unused int32; _ = unused; lower = lower - 1; unused = lower; var k int32
		upper = upper + 1; k = upper
	L4: for { var tmp17 int32; k = k - 1; tmp17 = k; if tmp17 > lower {
		var ak int16 = a.A[k]
		if int32(ak) < int32(pivot1) {
		L5: for { if lower < k {
			var tmp18 int32; lower = lower + 1; tmp18 = lower; if int32(a.A[tmp18]) >= int32(pivot1) {
				if int32(a.A[lower]) > int32(pivot2) {

					var tmp19 int32 = k; var tmp20 int32; upper = upper - 1; tmp20 = upper; a.A[tmp19] = a.A[tmp20]
					a.A[upper] = a.A[lower] } else {
						a.A[k] = a.A[lower] }
				a.A[lower] = ak
				break L5 }
//line :1132:1
			continue L5 }; break L5 } } else {








				if int32(ak) > int32(pivot2) {
					var tmp21 int32 = k; var tmp22 int32; upper = upper - 1; tmp22 = upper; a.A[tmp21] = a.A[tmp22]
					a.A[upper] = ak } }
//line :1129:1
		continue L4 }; break L4
	}













		a.A[low] = a.A[lower]
		a.A[lower] = pivot1
		a.A[end] = a.A[upper]
		a.A[upper] = pivot2
		DualPivotQuicksort_Sort_S1_I_I_I__V(a, bits|1, lower+1, upper)
		DualPivotQuicksort_Sort_S1_I_I_I__V(a, bits|1, upper+1, high) } else {
			var pivot int16 = a.A[e3]
			a.A[e3] = a.A[lower]
			var k_2 int32; upper = upper + 1; k_2 = upper
		L6: for { var tmp23 int32; k_2 = k_2 - 1; tmp23 = k_2; if tmp23 > lower {
			var ak_2 int16 = a.A[k_2]
			if int32(ak_2) == int32(pivot) { } else {
				a.A[k_2] = pivot
				if int32(ak_2) < int32(pivot) {

				L7: for { var tmp24 int32; lower = lower + 1; tmp24 = lower; if int32(a.A[tmp24]) < int32(pivot) { continue L7 }; break L7 }
					if int32(a.A[lower]) > int32(pivot) {
						var tmp25 int32; upper = upper - 1; tmp25 = upper; a.A[tmp25] = a.A[lower] }
					a.A[lower] = ak_2 } else {
						var tmp26 int32; upper = upper - 1; tmp26 = upper; a.A[tmp26] = ak_2 } }
//line :1153:1
			continue L6 }; break L6
		}









			a.A[low] = a.A[lower]
			a.A[lower] = pivot
			DualPivotQuicksort_Sort_S1_I_I_I__V(a, bits|1, upper, high) }
	high = lower
//line :1081:1
	continue L1
}
}





















































































func DualPivotQuicksort_InsertionSort_S1_I_I__V(a *ShortArray, low, high int32) {
	var i int32 = 0
	var k int32 = low
L1: for { var tmp1 int32; k = k + 1; tmp1 = k; if tmp1 < high {
	var ai int16; var tmp2 int32; i = k; tmp2 = i; ai = a.A[tmp2]
	if int32(ai) < int32(a.A[i-1]) {
	L2: for { var tmp3 bool; var tmp4 bool; var tmp5 int32; i = i - 1; tmp5 = i; tmp4 = tmp5 >= low; if tmp4 { tmp4 = int32(ai) < int32(a.A[i]) }; tmp3 = tmp4; if tmp3 {
		a.A[i+1] = a.A[i]
//line :1175:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai }
//line :1172:1
	continue L1 }; break L1
}
}









func DualPivotQuicksort_CountingSort_S1_I_I__V(a *ShortArray, low, high int32) {
	var count *IntArray = NewIntArray(65536)
	var i int32 = high
L1: for { if i > low {
	var i_7 int32; var tmp1 int32; i = i - 1; tmp1 = i; i_7 = int32(a.A[tmp1]) & 65535
	count.A[i_7] = count.A[i_7] + 1
//line :1187:1
	continue L1 }; break L1
}

	if high-low > 65536 {
		var i_2 int32 = 98304
	L2: for { var tmp2 int32; i_2 = i_2 - 1; tmp2 = i_2; if tmp2 > 32767 {
		var value int32 = i_2 & 65535
		low = high - count.A[value]
	L3: for { if high > low {
		var tmp3 int32; high = high - 1; tmp3 = high; a.A[tmp3] = int16(value)
//line :1195:1
		continue L3 }; break L3 }
//line :1192:1
		continue L2 }; break L2
	}

	} else {

		var i_3 int32 = 98304
	L4: for { if high > low {
	L5: for { var tmp4 int32; i_3 = i_3 - 1; tmp4 = i_3; if count.A[tmp4&65535] == 0 { continue L5 }; break L5 }
		var value_2 int32 = i_3 & 65535; var c int32 = count.A[value_2]

	L6: for {
		var tmp5 int32; high = high - 1; tmp5 = high; a.A[tmp5] = int16(value_2)
		var tmp6 int32; c = c - 1; tmp6 = c; if tmp6 > 0 { continue L6 }
//line :1202:1
		break L6 }
//line :1198:1
		continue L4 }; break L4
	}
	}
}




func DualPivotQuicksort_Sort_F1_I_I_I__V(a *FloatArray, parallelism, low, high int32) {
	var numNegativeZero int32 = 0
	var k int32 = high
L1: for { if k > low {
	var ak float32; var tmp1 int32; k = k - 1; tmp1 = k; ak = a.A[tmp1]
	var tmp2 bool; var tmp3 bool; tmp3 = ak == 0.0; if tmp3 { tmp3 = Float_FloatToRawIntBits_F__I(ak) < 0 }; tmp2 = tmp3; if tmp2 {

		numNegativeZero = numNegativeZero + 1
		a.A[k] = 0.0 } else {
			if ak == ak { } else {
				var tmp4 int32 = k; var tmp5 int32; high = high - 1; tmp5 = high; a.A[tmp4] = a.A[tmp5]
				a.A[high] = ak } }
//line :1209:1
	continue L1 }; break L1
}







	var size int32 = high - low; var tmp6 bool; var tmp7 bool
	tmp7 = parallelism > 1; if tmp7 { tmp7 = size > 4096 }; tmp6 = tmp7; if tmp6 {
		var depth int32 = DualPivotQuicksort_GetDepth_I_I__I(parallelism, size>>12); var b *FloatArray
		if depth == 0 { b = nil } else { b = NewFloatArray(size) }
		DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(nil, a.Ref(), b.Ref(), low, size, low, depth).Invoke__O() } else {
			DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_F1_I_I_I__V(nil, a, 0, low, high) }
	var tmp8 int32; numNegativeZero = numNegativeZero + 1; tmp8 = numNegativeZero; if tmp8 == 1 { } else {
	L2: for { if low <= high {
		var middle int32 = int32(uint32(low+high) >> 1)
		if a.A[middle] < 0.0 {
			low = middle + 1 } else {
				high = middle - 1 }
//line :1225:1
		continue L2 }; break L2
	}



	L3: for { var tmp9 int32; numNegativeZero = numNegativeZero - 1; tmp9 = numNegativeZero; if tmp9 > 0 {
		var tmp10 int32; high = high + 1; tmp10 = high; a.A[tmp10] = NegZero32
//line :1230:1
		continue L3 }; break L3
	}
	} }
func DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_F1_I_I_I__V(sorter *DualPivotQuicksort_Sorter, a *FloatArray, bits, low, high int32) {

L1: for {
	var end int32 = high - 1; var size int32 = high - low; var tmp1 bool; var tmp2 bool

	tmp2 = size < 65+bits; if tmp2 {
		tmp2 = bits&1 > 0 }
//line :1238:1
	tmp1 = tmp2; if tmp1 {

		var tmp3 *Class; Float_Init(); tmp3 = Float_TYPE; var tmp4 *Class = tmp3; var tmp5 int64 = Unsafe_ARRAY_FLOAT_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp4, a.Ref(), tmp5, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0 any, p1, p2 int32) { DualPivotQuicksort_MixedInsertionSort_F1_I_I__V(A2g_CastArray[*FloatArray](p0, Prim_float.ArrayClass()), p1, p2) }})







		return }
	if size < 44 {
		var tmp6 *Class; Float_Init(); tmp6 = Float_TYPE; var tmp7 *Class = tmp6; var tmp8 int64 = Unsafe_ARRAY_FLOAT_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp7, a.Ref(), tmp8, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0_2 any, p1_2, p2_2 int32) { DualPivotQuicksort_InsertionSort_F1_I_I__V(A2g_CastArray[*FloatArray](p0_2, Prim_float.ArrayClass()), p1_2, p2_2) }})







		return }
	var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = bits == 0; if !tmp11 { var tmp12 bool; tmp12 = size > 4096; if tmp12 { tmp12 = bits&1 > 0 }; tmp11 = tmp12 }; tmp10 = tmp11; if tmp10 {
		tmp10 = DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_F1_I_I__Z(sorter, a, low, size) }
//line :1259:1
	tmp9 = tmp10; if tmp9 {

		return }
	var tmp13 int32; bits = bits + 6; tmp13 = bits; if tmp13 > 384 {
		DualPivotQuicksort_HeapSort_F1_I_I__V(a, low, high)
		return }
	var step int32 = size>>3*3 + 3; var e1 int32 = low + step; var e5 int32 = end - step; var e3 int32 = int32(uint32(e1+e5) >> 1); var e2 int32 = int32(uint32(e1+e3) >> 1); var e4 int32 = int32(uint32(e3+e5) >> 1); var a3 float32 = a.A[e3]; var tmp14 float32 = a.A[e5]






	if tmp14 < a.A[e2] {
		var t_ float32 = a.A[e5]; a.A[e5] = a.A[e2]; a.A[e2] = t_ }
	var tmp15 float32 = a.A[e4]; if tmp15 < a.A[e1] {
		var t__2 float32 = a.A[e4]; a.A[e4] = a.A[e1]; a.A[e1] = t__2 }
	var tmp16 float32 = a.A[e5]; if tmp16 < a.A[e4] {
		var t__3 float32 = a.A[e5]; a.A[e5] = a.A[e4]; a.A[e4] = t__3 }
	var tmp17 float32 = a.A[e2]; if tmp17 < a.A[e1] {
		var t__4 float32 = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = t__4 }
	var tmp18 float32 = a.A[e4]; if tmp18 < a.A[e2] {
		var t__5 float32 = a.A[e4]; a.A[e4] = a.A[e2]; a.A[e2] = t__5 }
	if a3 < a.A[e2] {

		if a3 < a.A[e1] {
			a.A[e3] = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = a3 } else {
				a.A[e3] = a.A[e2]; a.A[e2] = a3 } } else {
//line :1282:1
					if a3 > a.A[e4] {





						if a3 > a.A[e5] {
							a.A[e3] = a.A[e4]; a.A[e4] = a.A[e5]; a.A[e5] = a3 } else {
								a.A[e3] = a.A[e4]; a.A[e4] = a3 } } }
	var lower int32 = 0; var upper int32 = 0; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; var tmp23 float32 = a.A[e1]

	tmp22 = tmp23 < a.A[e2]; if tmp22 { var tmp24 float32 = a.A[e2]; tmp22 = tmp24 < a.A[e3] }; tmp21 = tmp22; if tmp21 {
		var tmp25 float32 = a.A[e3]; tmp21 = tmp25 < a.A[e4] }
//line :1293:1
	tmp20 = tmp21; if tmp20 {

		var tmp26 float32 = a.A[e4]; tmp20 = tmp26 < a.A[e5] }
//line :1293:1
	tmp19 = tmp20; if tmp19 {


		var pivotIndices *IntArray; var tmp27 *Class; Float_Init(); tmp27 = Float_TYPE; var tmp28 *Class = tmp27; var tmp29 int64 = Unsafe_ARRAY_FLOAT_BASE_OFFSET; pivotIndices = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp28, a.Ref(), tmp29, low, high, e1, e5, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_3 any, p1_3, p2_3, p3, p4 int32) *IntArray { return DualPivotQuicksort_PartitionDualPivot_F1_I_I_I_I__I1(A2g_CastArray[*FloatArray](p0_3, Prim_float.ArrayClass()), p1_3, p2_3, p3, p4) }})











		lower = pivotIndices.A[0]
		upper = pivotIndices.A[1]
		var tmp30 bool; var tmp31 bool; tmp31 = size > 4096; if tmp31 { tmp31 = !(sorter == nil) }; tmp30 = tmp31; if tmp30 {

			NN(sorter).ForkSorter_I_I_I__V(bits|1, lower+1, upper)
			NN(sorter).ForkSorter_I_I_I__V(bits|1, upper+1, high) } else {

				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_F1_I_I_I__V(sorter, a, bits|1, lower+1, upper)





				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_F1_I_I_I__V(sorter, a, bits|1, upper+1, high) } } else {





					var pivotIndices_2 *IntArray; var tmp32 *Class; Float_Init(); tmp32 = Float_TYPE; var tmp33 *Class = tmp32; var tmp34 int64 = Unsafe_ARRAY_FLOAT_BASE_OFFSET; pivotIndices_2 = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp33, a.Ref(), tmp34, low, high, e3, e3, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_4 any, p1_4, p2_4, p3_2, p4_2 int32) *IntArray { return DualPivotQuicksort_PartitionSinglePivot_F1_I_I_I_I__I1(A2g_CastArray[*FloatArray](p0_4, Prim_float.ArrayClass()), p1_4, p2_4, p3_2, p4_2) }})











					lower = pivotIndices_2.A[0]
					upper = pivotIndices_2.A[1]
					var tmp35 bool; var tmp36 bool; tmp36 = size > 4096; if tmp36 { tmp36 = !(sorter == nil) }; tmp35 = tmp36; if tmp35 {
						NN(sorter).ForkSorter_I_I_I__V(bits|1, upper, high) } else {
							DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_F1_I_I_I__V(sorter, a, bits|1, upper, high) } }
	high = lower
//line :1235:1
	continue L1
}
}












































































































func DualPivotQuicksort_PartitionDualPivot_F1_I_I_I_I__I1(a *FloatArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e1 int32 = pivotIndex1; var e5 int32 = pivotIndex2; var pivot1 float32 = a.A[e1]; var pivot2 float32 = a.A[e5]






	a.A[e1] = a.A[lower]
	a.A[e5] = a.A[upper]
L1: for { var tmp1 int32; lower = lower + 1; tmp1 = lower; if a.A[tmp1] < pivot1 { continue L1 }; break L1 }
L2: for { var tmp2 int32; upper = upper - 1; tmp2 = upper; if a.A[tmp2] > pivot2 { continue L2 }; break L2 }
	var unused int32; _ = unused; lower = lower - 1; unused = lower; var k int32
	upper = upper + 1; k = upper
L3: for { var tmp3 int32; k = k - 1; tmp3 = k; if tmp3 > lower {
	var ak float32 = a.A[k]
	if ak < pivot1 {
	L4: for { if lower < k {
		var tmp4 int32; lower = lower + 1; tmp4 = lower; if a.A[tmp4] >= pivot1 {
			if a.A[lower] > pivot2 {

				var tmp5 int32 = k; var tmp6 int32; upper = upper - 1; tmp6 = upper; a.A[tmp5] = a.A[tmp6]
				a.A[upper] = a.A[lower] } else {
					a.A[k] = a.A[lower] }
			a.A[lower] = ak
			break L4 }
//line :1366:1
		continue L4 }; break L4
	}





	} else {

		if ak > pivot2 {
			var tmp7 int32 = k; var tmp8 int32; upper = upper - 1; tmp8 = upper; a.A[tmp7] = a.A[tmp8]
			a.A[upper] = ak } }
//line :1363:1
	continue L3 }; break L3
}













	a.A[low] = a.A[lower]
	a.A[lower] = pivot1
	a.A[end] = a.A[upper]
	a.A[upper] = pivot2
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_PartitionSinglePivot_F1_I_I_I_I__I1(a *FloatArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e3 int32 = pivotIndex1; var pivot float32 = a.A[e3]




	a.A[e3] = a.A[lower]
	var k int32; upper = upper + 1; k = upper
L1: for { var tmp1 int32; k = k - 1; tmp1 = k; if tmp1 > lower {
	var ak float32 = a.A[k]
	if ak == pivot { } else {
		a.A[k] = pivot
		if ak < pivot {

		L2: for { var tmp2 int32; lower = lower + 1; tmp2 = lower; if a.A[tmp2] < pivot { continue L2 }; break L2 }
			if a.A[lower] > pivot {
				var tmp3 int32; upper = upper - 1; tmp3 = upper; a.A[tmp3] = a.A[lower] }
			a.A[lower] = ak } else {
				var tmp4 int32; upper = upper - 1; tmp4 = upper; a.A[tmp4] = ak } }
//line :1395:1
	continue L1 }; break L1
}









	a.A[low] = a.A[lower]
	a.A[lower] = pivot
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_MixedInsertionSort_F1_I_I__V(a *FloatArray, low, high int32) {
	var size int32 = high - low; var end int32 = high - 3*(size>>5<<3)




	if end == high {
		var i int32 = 0
	L1: for { var tmp1 int32; low = low + 1; tmp1 = low; if tmp1 < end {
		var ai float32; var tmp2 int32; i = low; tmp2 = i; ai = a.A[tmp2]
	L2: for { var tmp3 int32; i = i - 1; tmp3 = i; if ai < a.A[tmp3] {
		a.A[i+1] = a.A[i]
//line :1420:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai
//line :1418:1
		continue L1 }; break L1
	}

	} else {

		var pin float32 = a.A[end]
		var i_2 int32 = 0
		var p int32 = high
	L3: for { var tmp4 int32; low = low + 1; tmp4 = low; if tmp4 < end {
		var ai_2 float32; var tmp5 int32; i_2 = low; tmp5 = i_2; ai_2 = a.A[tmp5]
		if ai_2 < a.A[i_2-1] {

			var tmp6 int32 = i_2; var tmp7 int32; i_2 = i_2 - 1; tmp7 = i_2; a.A[tmp6] = a.A[tmp7]
		L4: for { var tmp8 float32 = ai_2; var tmp9 int32; i_2 = i_2 - 1; tmp9 = i_2; if tmp8 < a.A[tmp9] {
			a.A[i_2+1] = a.A[i_2]
//line :1431:1
			continue L4 }; break L4
		}
			a.A[i_2+1] = ai_2 } else {
				var tmp10 bool; var tmp11 bool; tmp11 = p > i_2; if tmp11 { tmp11 = ai_2 > pin }; tmp10 = tmp11; if tmp10 {
				L5: for { var tmp12 int32; p = p - 1; tmp12 = p; if a.A[tmp12] > pin { continue L5 }; break L5 }
					if p > i_2 { ai_2 = a.A[p]; a.A[p] = a.A[i_2] }
				L6: for { var tmp13 float32 = ai_2; var tmp14 int32; i_2 = i_2 - 1; tmp14 = i_2; if tmp13 < a.A[tmp14] {
					a.A[i_2+1] = a.A[i_2]
//line :1437:1
					continue L6 }; break L6
				}
					a.A[i_2+1] = ai_2 } }
//line :1426:1
		continue L3 }; break L3
	}












		var i_3 int32 = 0
	L7: for { if low < high {
		var a1 float32; var tmp15 int32; i_3 = low; tmp15 = i_3; a1 = a.A[tmp15]; var a2 float32; var tmp16 int32
		low = low + 1; tmp16 = low; a2 = a.A[tmp16]
		if a1 > a2 {

		L8: for { var tmp17 int32; i_3 = i_3 - 1; tmp17 = i_3; if a1 < a.A[tmp17] {
			a.A[i_3+2] = a.A[i_3]
//line :1446:1
			continue L8 }; break L8
		}
			var tmp18 int32; i_3 = i_3 + 1; tmp18 = i_3; a.A[tmp18+1] = a1
		L9: for { var tmp19 int32; i_3 = i_3 - 1; tmp19 = i_3; if a2 < a.A[tmp19] {
			a.A[i_3+1] = a.A[i_3]
//line :1449:1
			continue L9 }; break L9
		}
			a.A[i_3+1] = a2 } else {
				if a1 < a.A[i_3-1] {
				L10: for { var tmp20 int32; i_3 = i_3 - 1; tmp20 = i_3; if a2 < a.A[tmp20] {
					a.A[i_3+2] = a.A[i_3]
//line :1453:1
					continue L10 }; break L10
				}
					var tmp21 int32; i_3 = i_3 + 1; tmp21 = i_3; a.A[tmp21+1] = a2
				L11: for { var tmp22 int32; i_3 = i_3 - 1; tmp22 = i_3; if a1 < a.A[tmp22] {
					a.A[i_3+1] = a.A[i_3]
//line :1456:1
					continue L11 }; break L11
				}
					a.A[i_3+1] = a1 } }
		low = low + 1
//line :1441:1
		continue L7 }; break L7
	}
	}
}
















func DualPivotQuicksort_InsertionSort_F1_I_I__V(a *FloatArray, low, high int32) {
	var i int32 = 0
	var k int32 = low
L1: for { var tmp1 int32; k = k + 1; tmp1 = k; if tmp1 < high {
	var ai float32; var tmp2 int32; i = k; tmp2 = i; ai = a.A[tmp2]
	if ai < a.A[i-1] {
	L2: for { var tmp3 bool; var tmp4 bool; var tmp5 int32; i = i - 1; tmp5 = i; tmp4 = tmp5 >= low; if tmp4 { tmp4 = ai < a.A[i] }; tmp3 = tmp4; if tmp3 {
		a.A[i+1] = a.A[i]
//line :1467:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai }
//line :1464:1
	continue L1 }; break L1
}
}




func DualPivotQuicksort_HeapSort_F1_I_I__V(a *FloatArray, low, high int32) {
	var k int32 = int32(uint32(low+high) >> 1)
L1: for { if k > low {
	var tmp1 int32; k = k - 1; tmp1 = k; DualPivotQuicksort_PushDown_F1_I_F_I_I__V(a, tmp1, a.A[k], low, high)
//line :1473:1
	continue L1 }; break L1
}
L2: for { var tmp2 int32; high = high - 1; tmp2 = high; if tmp2 > low {
	var max_ float32 = a.A[low]
	DualPivotQuicksort_PushDown_F1_I_F_I_I__V(a, low, a.A[high], low, high)
	a.A[high] = max_
//line :1475:1
	continue L2 }; break L2
}
}


func DualPivotQuicksort_PushDown_F1_I_F_I_I__V(a *FloatArray, p int32, value float32, low, high int32) {

	var k int32 = 0
L1: for {
	k = p<<1 - low + 2
	if k > high { break L1 }
	var tmp1 bool; var tmp2 bool; tmp2 = k == high; if !tmp2 { var tmp3 float32 = a.A[k]; tmp2 = tmp3 < a.A[k-1] }; tmp1 = tmp2; if tmp1 {
		k = k - 1 }
	if a.A[k] <= value { break L1 }
	var tmp4 int32 = p; var tmp5 int32; p = k; tmp5 = p; a.A[tmp4] = a.A[tmp5]
//line :1483:1
	continue L1
}





	a.A[p] = value
}
func DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_F1_I_I__Z(sorter *DualPivotQuicksort_Sorter, a *FloatArray, low, size int32) bool {
	var run *IntArray; var high int32 = low + size; var count int32 = 1; var last int32 = low; var k int32 = low + 1




L1: for { if k < high {
	var tmp1 float32 = a.A[k-1]; if tmp1 < a.A[k] {

	L2: for { var tmp2 bool; var tmp3 bool; var tmp4 int32; k = k + 1; tmp4 = k; tmp3 = tmp4 < high; if tmp3 {
		var tmp5 float32 = a.A[k-1]; tmp3 = tmp5 <= a.A[k] }
//line :1501:1
		tmp2 = tmp3; if tmp2 { continue L2 }; break L2 } } else {
//line :1499:1
			var tmp6 float32 = a.A[k-1]; if tmp6 > a.A[k] {





			L3: for { var tmp7 bool; var tmp8 bool; var tmp9 int32; k = k + 1; tmp9 = k; tmp8 = tmp9 < high; if tmp8 {
				var tmp10 float32 = a.A[k-1]; tmp8 = tmp10 >= a.A[k] }
//line :1505:1
				tmp7 = tmp8; if tmp7 { continue L3 }; break L3
			}
				var i int32 = last - 1
				var j int32 = k
			L4: for { var tmp11 bool; var tmp12 bool; var tmp13 int32; i = i + 1; tmp13 = i; var tmp14 int32 = tmp13; var tmp15 int32; j = j - 1; tmp15 = j; tmp12 = tmp14 < tmp15; if tmp12 {
				var tmp16 float32 = a.A[i]; tmp12 = tmp16 > a.A[j] }
//line :1509:1
				tmp11 = tmp12; if tmp11 {

					var ai float32 = a.A[i]; a.A[i] = a.A[j]; a.A[j] = ai
//line :1509:1
					continue L4 }; break L4 } } else {




						var ak float32 = a.A[k]; L5: for {
							var tmp17 bool; var tmp18 bool; var tmp19 int32; k = k + 1; tmp19 = k; tmp18 = tmp19 < high; if tmp18 { tmp18 = ak == a.A[k] }; tmp17 = tmp18; if tmp17 { ak = ak; continue L5 }
//line :1514:1
							break L5
						}
						if k < high { continue L1 } } }
	if run == nil {

		if k == high { return true }
		if k-low < 16 { return false }
		run = NewIntArray((size>>10 | 127) & 1023)


		run.A[0] = low } else {
			var tmp20 float32 = a.A[last-1]; if tmp20 > a.A[last] {
				if count > (k-low)>>7 {

					return false }
				var tmp21 int32; count = count + 1; tmp21 = count; if tmp21 == 5120 { return false }
				if count == int32(len(run.A)) {
					run = Arrays_CopyOf_I1_I__I1(run, count<<1) } } }
	var tmp22 *IntArray = run; var tmp23 int32 = count; var tmp24 int32; last = k; tmp24 = last; tmp22.A[tmp23] = tmp24
//line :1498:1
	continue L1 }; break L1
}

































	if count > 1 {
		var b *FloatArray; var offset int32 = low; var tmp25 bool; var tmp26 bool

		tmp26 = sorter == nil; if !tmp26 { var tmp27 *FloatArray; b = A2g_CastArray[*FloatArray](sorter.F_b, Prim_float.ArrayClass()); tmp27 = b; tmp26 = tmp27 == nil }; tmp25 = tmp26; if tmp25 {
			b = NewFloatArray(size) } else {
				offset = sorter.F_offset }
		DualPivotQuicksort_MergeRuns_F1_F1_I_I_Z_I1_I_I__F1(a, b, offset, 1, !(sorter == nil), run, 0, count) }
//line :1493:1
	return true
}















































func DualPivotQuicksort_MergeRuns_F1_F1_I_I_Z_I1_I_I__F1(a, b *FloatArray, offset, aim int32, parallel bool, run *IntArray, lo, hi int32) *FloatArray {

	if hi-lo == 1 {
		if aim >= 0 { return a } else {


			var i int32 = run.A[hi]; var j int32 = i - offset; var low int32 = run.A[lo]


		L1: for { if i > low {
			var tmp1 int32; j = j - 1; tmp1 = j; var tmp2 int32 = tmp1; var tmp3 int32; i = i - 1; tmp3 = i; b.A[tmp2] = a.A[tmp3]
//line :1551:1
			continue L1 }; break L1 }
//line :1547:1
			return b
		}


	} else {


		var mi int32 = lo; var tmp4 int32 = run.A[lo]; var rmi int32 = int32(uint32(tmp4+run.A[hi]) >> 1)

	L2: for { var tmp5 int32; mi = mi + 1; tmp5 = mi; if run.A[tmp5+1] <= rmi { continue L2 }; break L2 }
		var a1 *FloatArray; var a2 *FloatArray; var tmp6 bool; var tmp7 bool

		tmp7 = parallel; if tmp7 { tmp7 = hi-lo > 4 }; tmp6 = tmp7; if tmp6 {
			var merger *DualPivotQuicksort_RunMerger = DualPivotQuicksort_RunMerger_New_O_O_I_I_I1_I_I(a.Ref(), b.Ref(), offset, 0, run, mi, hi).ForkMe__DualPivotQuicksort_RunMerger()
			a1 = DualPivotQuicksort_MergeRuns_F1_F1_I_I_Z_I1_I_I__F1(a, b, offset, -aim, true, run, lo, mi)









			a2 = A2g_CastArray[*FloatArray](NN(merger).GetDestination__O(), Prim_float.ArrayClass()) } else {

				a1 = DualPivotQuicksort_MergeRuns_F1_F1_I_I_Z_I1_I_I__F1(a, b, offset, -aim, false, run, lo, mi)









				a2 = DualPivotQuicksort_MergeRuns_F1_F1_I_I_Z_I1_I_I__F1(a, b, offset, 0, false, run, mi, hi) }
		var dst *FloatArray; if a1 == a { dst = b } else { dst = a }; var k int32
		if a1 == a {
			k = run.A[lo] - offset } else {
				k = run.A[lo] }
//line :1584:1
		var lo1 int32



		if a1 == b {
			lo1 = run.A[lo] - offset } else {
				lo1 = run.A[lo] }
//line :1584:1
		var hi1 int32






		if a1 == b {
			hi1 = run.A[mi] - offset } else {
				hi1 = run.A[mi] }
//line :1584:1
		var lo2 int32









		if a2 == b {
			lo2 = run.A[mi] - offset } else {
				lo2 = run.A[mi] }
//line :1584:1
		var hi2 int32












		if a2 == b {
			hi2 = run.A[hi] - offset } else {
				hi2 = run.A[hi] }
		if parallel {
			DualPivotQuicksort_Merger_New_CountedCompleter_O_I_O_I_I_O_I_I(nil, dst.Ref(), k, a1.Ref(), lo1, hi1, a2.Ref(), lo2, hi2).Invoke__O() } else {
				DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_F1_I_F1_I_I_F1_I_I__V(nil, dst, k, a1, lo1, hi1, a2, lo2, hi2) }
//line :1584:1
		return dst
	}
}


















func DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_F1_I_F1_I_I_F1_I_I__V(merger *DualPivotQuicksort_Merger, dst *FloatArray, k int32, a1 *FloatArray, lo1, hi1 int32, a2 *FloatArray, lo2, hi2 int32) {


	var tmp1 bool; var tmp2 bool; tmp2 = !(merger == nil); if tmp2 { tmp2 = a1 == a2 }; tmp1 = tmp2; if tmp1 {
	L1: for {
		if hi1-lo1 < hi2-lo2 {
			var lo int32 = lo1; lo1 = lo2; lo2 = lo; var hi int32 = hi1; hi1 = hi2; hi2 = hi }
		if hi1-lo1 < 4096 { break L1 }
		var mi1 int32 = int32(uint32(lo1+hi1) >> 1); var key float32 = a1.A[mi1]
		var mi2 int32 = hi2
		var loo int32 = lo2

	L2: for { if loo < mi2 {
		var t_ int32 = int32(uint32(loo+mi2) >> 1)
		if key > a2.A[t_] { loo = t_ + 1 } else { mi2 = t_ }
//line :1617:1
		continue L2 }; break L2
	}

		var d int32 = mi2 - lo2 + mi1 - lo1

		NN(merger).ForkMerger_O_I_O_I_I_O_I_I__V(dst.Ref(), k+d, a1.Ref(), mi1, hi1, a2.Ref(), mi2, hi2)
		hi1 = mi1
		hi2 = mi2
//line :1609:1
		continue L1
	}
	}













L3: for { var tmp3 bool; var tmp4 bool; tmp4 = lo1 < hi1; if tmp4 { tmp4 = lo2 < hi2 }; tmp3 = tmp4; if tmp3 {
	var tmp5 int32 = k; var tmp6 float32; var tmp7 float32 = a1.A[lo1]

	if tmp7 < a2.A[lo2] {
		var tmp8 int32; var old_8 int32 = lo1; lo1 = lo1 + 1; tmp8 = old_8; tmp6 = a1.A[tmp8] } else {
			var tmp9 int32; var old_9 int32 = lo2; lo2 = lo2 + 1; tmp9 = old_9; tmp6 = a2.A[tmp9] }
//line :1626:1
	dst.A[tmp5] = tmp6




	k = k + 1
//line :1625:1
	continue L3 }; break L3
}





	var tmp10 bool; var tmp11 bool; tmp11 = !(dst == a1); if !tmp11 { tmp11 = k < lo1 }; tmp10 = tmp11; if tmp10 {
	L4: for { if lo1 < hi1 {
		dst.A[k] = a1.A[lo1]
		k = k + 1
		lo1 = lo1 + 1
//line :1633:1
		continue L4 }; break L4
	}
	}

	var tmp12 bool; var tmp13 bool; tmp13 = !(dst == a2); if !tmp13 { tmp13 = k < lo2 }; tmp12 = tmp13; if tmp12 {
	L5: for { if lo2 < hi2 {
		dst.A[k] = a2.A[lo2]
		k = k + 1
		lo2 = lo2 + 1
//line :1638:1
		continue L5 }; break L5
	}
	}
}

func DualPivotQuicksort_Sort_D1_I_I_I__V(a *DoubleArray, parallelism, low, high int32) {
	var numNegativeZero int32 = 0
	var k int32 = high
L1: for { if k > low {
	var ak float64; var tmp1 int32; k = k - 1; tmp1 = k; ak = a.A[tmp1]
	var tmp2 bool; var tmp3 bool; tmp3 = ak == 0.0; if tmp3 { tmp3 = Double_DoubleToRawLongBits_D__J(ak) < 0 }; tmp2 = tmp3; if tmp2 {
		numNegativeZero = numNegativeZero + 1; a.A[k] = 0.0 } else {
			if ak == ak { } else {
				var tmp4 int32 = k; var tmp5 int32; high = high - 1; tmp5 = high; a.A[tmp4] = a.A[tmp5]
				a.A[high] = ak } }
//line :1646:1
	continue L1 }; break L1
}





	var size int32 = high - low; var tmp6 bool; var tmp7 bool
	tmp7 = parallelism > 1; if tmp7 { tmp7 = size > 4096 }; tmp6 = tmp7; if tmp6 {
		var depth int32 = DualPivotQuicksort_GetDepth_I_I__I(parallelism, size>>12); var b *DoubleArray
		if depth == 0 { b = nil } else { b = NewDoubleArray(size) }
		DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(nil, a.Ref(), b.Ref(), low, size, low, depth).Invoke__O() } else {
			DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_D1_I_I_I__V(nil, a, 0, low, high) }
	var tmp8 int32; numNegativeZero = numNegativeZero + 1; tmp8 = numNegativeZero; if tmp8 == 1 { } else {
	L2: for { if low <= high {
		var middle int32 = int32(uint32(low+high) >> 1)
		if a.A[middle] < 0.0 {
			low = middle + 1 } else {
				high = middle - 1 }
//line :1660:1
		continue L2 }; break L2
	}



	L3: for { var tmp9 int32; numNegativeZero = numNegativeZero - 1; tmp9 = numNegativeZero; if tmp9 > 0 {
		var tmp10 int32; high = high + 1; tmp10 = high; a.A[tmp10] = NegZero64
//line :1665:1
		continue L3 }; break L3
	}
	} }
func DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_D1_I_I_I__V(sorter *DualPivotQuicksort_Sorter, a *DoubleArray, bits, low, high int32) {

L1: for {
	var end int32 = high - 1; var size int32 = high - low; var tmp1 bool; var tmp2 bool

	tmp2 = size < 65+bits; if tmp2 {
		tmp2 = bits&1 > 0 }
//line :1673:1
	tmp1 = tmp2; if tmp1 {

		var tmp3 *Class; Double_Init(); tmp3 = Double_TYPE; var tmp4 *Class = tmp3; var tmp5 int64 = Unsafe_ARRAY_DOUBLE_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp4, a.Ref(), tmp5, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0 any, p1, p2 int32) { DualPivotQuicksort_MixedInsertionSort_D1_I_I__V(A2g_CastArray[*DoubleArray](p0, Prim_double.ArrayClass()), p1, p2) }})







		return }
	if size < 44 {
		var tmp6 *Class; Double_Init(); tmp6 = Double_TYPE; var tmp7 *Class = tmp6; var tmp8 int64 = Unsafe_ARRAY_DOUBLE_BASE_OFFSET; DualPivotQuicksort_Sort_Class_O_J_I_I_DualPivotQuicksort_SortOperation__V(tmp7, a.Ref(), tmp8, low, high, &DualPivotQuicksort_SortOperation_Fn{Fn: func(p0_2 any, p1_2, p2_2 int32) { DualPivotQuicksort_InsertionSort_D1_I_I__V(A2g_CastArray[*DoubleArray](p0_2, Prim_double.ArrayClass()), p1_2, p2_2) }})







		return }
	var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = bits == 0; if !tmp11 { var tmp12 bool; tmp12 = size > 4096; if tmp12 { tmp12 = bits&1 > 0 }; tmp11 = tmp12 }; tmp10 = tmp11; if tmp10 {
		tmp10 = DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_D1_I_I__Z(sorter, a, low, size) }
//line :1694:1
	tmp9 = tmp10; if tmp9 {

		return }
	var tmp13 int32; bits = bits + 6; tmp13 = bits; if tmp13 > 384 {
		DualPivotQuicksort_HeapSort_D1_I_I__V(a, low, high)
		return }
	var step int32 = size>>3*3 + 3; var e1 int32 = low + step; var e5 int32 = end - step; var e3 int32 = int32(uint32(e1+e5) >> 1); var e2 int32 = int32(uint32(e1+e3) >> 1); var e4 int32 = int32(uint32(e3+e5) >> 1); var a3 float64 = a.A[e3]; var tmp14 float64 = a.A[e5]






	if tmp14 < a.A[e2] {
		var t_ float64 = a.A[e5]; a.A[e5] = a.A[e2]; a.A[e2] = t_ }
	var tmp15 float64 = a.A[e4]; if tmp15 < a.A[e1] {
		var t__2 float64 = a.A[e4]; a.A[e4] = a.A[e1]; a.A[e1] = t__2 }
	var tmp16 float64 = a.A[e5]; if tmp16 < a.A[e4] {
		var t__3 float64 = a.A[e5]; a.A[e5] = a.A[e4]; a.A[e4] = t__3 }
	var tmp17 float64 = a.A[e2]; if tmp17 < a.A[e1] {
		var t__4 float64 = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = t__4 }
	var tmp18 float64 = a.A[e4]; if tmp18 < a.A[e2] {
		var t__5 float64 = a.A[e4]; a.A[e4] = a.A[e2]; a.A[e2] = t__5 }
	if a3 < a.A[e2] {

		if a3 < a.A[e1] {
			a.A[e3] = a.A[e2]; a.A[e2] = a.A[e1]; a.A[e1] = a3 } else {
				a.A[e3] = a.A[e2]; a.A[e2] = a3 } } else {
//line :1717:1
					if a3 > a.A[e4] {





						if a3 > a.A[e5] {
							a.A[e3] = a.A[e4]; a.A[e4] = a.A[e5]; a.A[e5] = a3 } else {
								a.A[e3] = a.A[e4]; a.A[e4] = a3 } } }
	var lower int32 = 0; var upper int32 = 0; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; var tmp23 float64 = a.A[e1]

	tmp22 = tmp23 < a.A[e2]; if tmp22 { var tmp24 float64 = a.A[e2]; tmp22 = tmp24 < a.A[e3] }; tmp21 = tmp22; if tmp21 {
		var tmp25 float64 = a.A[e3]; tmp21 = tmp25 < a.A[e4] }
//line :1728:1
	tmp20 = tmp21; if tmp20 {

		var tmp26 float64 = a.A[e4]; tmp20 = tmp26 < a.A[e5] }
//line :1728:1
	tmp19 = tmp20; if tmp19 {


		var pivotIndices *IntArray; var tmp27 *Class; Double_Init(); tmp27 = Double_TYPE; var tmp28 *Class = tmp27; var tmp29 int64 = Unsafe_ARRAY_DOUBLE_BASE_OFFSET; pivotIndices = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp28, a.Ref(), tmp29, low, high, e1, e5, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_3 any, p1_3, p2_3, p3, p4 int32) *IntArray { return DualPivotQuicksort_PartitionDualPivot_D1_I_I_I_I__I1(A2g_CastArray[*DoubleArray](p0_3, Prim_double.ArrayClass()), p1_3, p2_3, p3, p4) }})











		lower = pivotIndices.A[0]
		upper = pivotIndices.A[1]
		var tmp30 bool; var tmp31 bool; tmp31 = size > 4096; if tmp31 { tmp31 = !(sorter == nil) }; tmp30 = tmp31; if tmp30 {

			NN(sorter).ForkSorter_I_I_I__V(bits|1, lower+1, upper)
			NN(sorter).ForkSorter_I_I_I__V(bits|1, upper+1, high) } else {

				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_D1_I_I_I__V(sorter, a, bits|1, lower+1, upper)





				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_D1_I_I_I__V(sorter, a, bits|1, upper+1, high) } } else {





					var pivotIndices_2 *IntArray; var tmp32 *Class; Double_Init(); tmp32 = Double_TYPE; var tmp33 *Class = tmp32; var tmp34 int64 = Unsafe_ARRAY_DOUBLE_BASE_OFFSET; pivotIndices_2 = DualPivotQuicksort_Partition_Class_O_J_I_I_I_I_DualPivotQuicksort_PartitionOperation__I1(tmp33, a.Ref(), tmp34, low, high, e3, e3, &DualPivotQuicksort_PartitionOperation_Fn{Fn: func(p0_4 any, p1_4, p2_4, p3_2, p4_2 int32) *IntArray { return DualPivotQuicksort_PartitionSinglePivot_D1_I_I_I_I__I1(A2g_CastArray[*DoubleArray](p0_4, Prim_double.ArrayClass()), p1_4, p2_4, p3_2, p4_2) }})











					lower = pivotIndices_2.A[0]
					upper = pivotIndices_2.A[1]
					var tmp35 bool; var tmp36 bool; tmp36 = size > 4096; if tmp36 { tmp36 = !(sorter == nil) }; tmp35 = tmp36; if tmp35 {
						NN(sorter).ForkSorter_I_I_I__V(bits|1, upper, high) } else {
							DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_D1_I_I_I__V(sorter, a, bits|1, upper, high) } }
	high = lower
//line :1670:1
	continue L1
}
}












































































































func DualPivotQuicksort_PartitionDualPivot_D1_I_I_I_I__I1(a *DoubleArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e1 int32 = pivotIndex1; var e5 int32 = pivotIndex2; var pivot1 float64 = a.A[e1]; var pivot2 float64 = a.A[e5]






	a.A[e1] = a.A[lower]
	a.A[e5] = a.A[upper]
L1: for { var tmp1 int32; lower = lower + 1; tmp1 = lower; if a.A[tmp1] < pivot1 { continue L1 }; break L1 }
L2: for { var tmp2 int32; upper = upper - 1; tmp2 = upper; if a.A[tmp2] > pivot2 { continue L2 }; break L2 }
	var unused int32; _ = unused; lower = lower - 1; unused = lower; var k int32
	upper = upper + 1; k = upper
L3: for { var tmp3 int32; k = k - 1; tmp3 = k; if tmp3 > lower {
	var ak float64 = a.A[k]
	if ak < pivot1 {
	L4: for { if lower < k {
		var tmp4 int32; lower = lower + 1; tmp4 = lower; if a.A[tmp4] >= pivot1 {
			if a.A[lower] > pivot2 {

				var tmp5 int32 = k; var tmp6 int32; upper = upper - 1; tmp6 = upper; a.A[tmp5] = a.A[tmp6]
				a.A[upper] = a.A[lower] } else {
					a.A[k] = a.A[lower] }
			a.A[lower] = ak
			break L4 }
//line :1801:1
		continue L4 }; break L4
	}





	} else {

		if ak > pivot2 {
			var tmp7 int32 = k; var tmp8 int32; upper = upper - 1; tmp8 = upper; a.A[tmp7] = a.A[tmp8]
			a.A[upper] = ak } }
//line :1798:1
	continue L3 }; break L3
}













	a.A[low] = a.A[lower]
	a.A[lower] = pivot1
	a.A[end] = a.A[upper]
	a.A[upper] = pivot2
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_PartitionSinglePivot_D1_I_I_I_I__I1(a *DoubleArray, low, high, pivotIndex1, pivotIndex2 int32) *IntArray {



	var end int32 = high - 1; var lower int32 = low; var upper int32 = end; var e3 int32 = pivotIndex1; var pivot float64 = a.A[e3]




	a.A[e3] = a.A[lower]
	var k int32; upper = upper + 1; k = upper
L1: for { var tmp1 int32; k = k - 1; tmp1 = k; if tmp1 > lower {
	var ak float64 = a.A[k]
	if ak == pivot { } else {
		a.A[k] = pivot
		if ak < pivot {

		L2: for { var tmp2 int32; lower = lower + 1; tmp2 = lower; if a.A[tmp2] < pivot { continue L2 }; break L2 }
			if a.A[lower] > pivot {
				var tmp3 int32; upper = upper - 1; tmp3 = upper; a.A[tmp3] = a.A[lower] }
			a.A[lower] = ak } else {
				var tmp4 int32; upper = upper - 1; tmp4 = upper; a.A[tmp4] = ak } }
//line :1830:1
	continue L1 }; break L1
}









	a.A[low] = a.A[lower]
	a.A[lower] = pivot
	return IntArrayOf(lower, upper)
}
func DualPivotQuicksort_MixedInsertionSort_D1_I_I__V(a *DoubleArray, low, high int32) {
	var size int32 = high - low; var end int32 = high - 3*(size>>5<<3)




	if end == high {
		var i int32 = 0
	L1: for { var tmp1 int32; low = low + 1; tmp1 = low; if tmp1 < end {
		var ai float64; var tmp2 int32; i = low; tmp2 = i; ai = a.A[tmp2]
	L2: for { var tmp3 int32; i = i - 1; tmp3 = i; if ai < a.A[tmp3] {
		a.A[i+1] = a.A[i]
//line :1855:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai
//line :1853:1
		continue L1 }; break L1
	}

	} else {

		var pin float64 = a.A[end]
		var i_2 int32 = 0
		var p int32 = high
	L3: for { var tmp4 int32; low = low + 1; tmp4 = low; if tmp4 < end {
		var ai_2 float64; var tmp5 int32; i_2 = low; tmp5 = i_2; ai_2 = a.A[tmp5]
		if ai_2 < a.A[i_2-1] {

			var tmp6 int32 = i_2; var tmp7 int32; i_2 = i_2 - 1; tmp7 = i_2; a.A[tmp6] = a.A[tmp7]
		L4: for { var tmp8 float64 = ai_2; var tmp9 int32; i_2 = i_2 - 1; tmp9 = i_2; if tmp8 < a.A[tmp9] {
			a.A[i_2+1] = a.A[i_2]
//line :1866:1
			continue L4 }; break L4
		}
			a.A[i_2+1] = ai_2 } else {
				var tmp10 bool; var tmp11 bool; tmp11 = p > i_2; if tmp11 { tmp11 = ai_2 > pin }; tmp10 = tmp11; if tmp10 {
				L5: for { var tmp12 int32; p = p - 1; tmp12 = p; if a.A[tmp12] > pin { continue L5 }; break L5 }
					if p > i_2 { ai_2 = a.A[p]; a.A[p] = a.A[i_2] }
				L6: for { var tmp13 float64 = ai_2; var tmp14 int32; i_2 = i_2 - 1; tmp14 = i_2; if tmp13 < a.A[tmp14] {
					a.A[i_2+1] = a.A[i_2]
//line :1872:1
					continue L6 }; break L6
				}
					a.A[i_2+1] = ai_2 } }
//line :1861:1
		continue L3 }; break L3
	}












		var i_3 int32 = 0
	L7: for { if low < high {
		var a1 float64; var tmp15 int32; i_3 = low; tmp15 = i_3; a1 = a.A[tmp15]; var a2 float64; var tmp16 int32
		low = low + 1; tmp16 = low; a2 = a.A[tmp16]
		if a1 > a2 {

		L8: for { var tmp17 int32; i_3 = i_3 - 1; tmp17 = i_3; if a1 < a.A[tmp17] {
			a.A[i_3+2] = a.A[i_3]
//line :1881:1
			continue L8 }; break L8
		}
			var tmp18 int32; i_3 = i_3 + 1; tmp18 = i_3; a.A[tmp18+1] = a1
		L9: for { var tmp19 int32; i_3 = i_3 - 1; tmp19 = i_3; if a2 < a.A[tmp19] {
			a.A[i_3+1] = a.A[i_3]
//line :1884:1
			continue L9 }; break L9
		}
			a.A[i_3+1] = a2 } else {
				if a1 < a.A[i_3-1] {
				L10: for { var tmp20 int32; i_3 = i_3 - 1; tmp20 = i_3; if a2 < a.A[tmp20] {
					a.A[i_3+2] = a.A[i_3]
//line :1888:1
					continue L10 }; break L10
				}
					var tmp21 int32; i_3 = i_3 + 1; tmp21 = i_3; a.A[tmp21+1] = a2
				L11: for { var tmp22 int32; i_3 = i_3 - 1; tmp22 = i_3; if a1 < a.A[tmp22] {
					a.A[i_3+1] = a.A[i_3]
//line :1891:1
					continue L11 }; break L11
				}
					a.A[i_3+1] = a1 } }
		low = low + 1
//line :1876:1
		continue L7 }; break L7
	}
	}
}
















func DualPivotQuicksort_InsertionSort_D1_I_I__V(a *DoubleArray, low, high int32) {
	var i int32 = 0
	var k int32 = low
L1: for { var tmp1 int32; k = k + 1; tmp1 = k; if tmp1 < high {
	var ai float64; var tmp2 int32; i = k; tmp2 = i; ai = a.A[tmp2]
	if ai < a.A[i-1] {
	L2: for { var tmp3 bool; var tmp4 bool; var tmp5 int32; i = i - 1; tmp5 = i; tmp4 = tmp5 >= low; if tmp4 { tmp4 = ai < a.A[i] }; tmp3 = tmp4; if tmp3 {
		a.A[i+1] = a.A[i]
//line :1902:1
		continue L2 }; break L2
	}
		a.A[i+1] = ai }
//line :1899:1
	continue L1 }; break L1
}
}




func DualPivotQuicksort_HeapSort_D1_I_I__V(a *DoubleArray, low, high int32) {
	var k int32 = int32(uint32(low+high) >> 1)
L1: for { if k > low {
	var tmp1 int32; k = k - 1; tmp1 = k; DualPivotQuicksort_PushDown_D1_I_D_I_I__V(a, tmp1, a.A[k], low, high)
//line :1908:1
	continue L1 }; break L1
}
L2: for { var tmp2 int32; high = high - 1; tmp2 = high; if tmp2 > low {
	var max_ float64 = a.A[low]
	DualPivotQuicksort_PushDown_D1_I_D_I_I__V(a, low, a.A[high], low, high)
	a.A[high] = max_
//line :1910:1
	continue L2 }; break L2
}
}


func DualPivotQuicksort_PushDown_D1_I_D_I_I__V(a *DoubleArray, p int32, value float64, low, high int32) {

	var k int32 = 0
L1: for {
	k = p<<1 - low + 2
	if k > high { break L1 }
	var tmp1 bool; var tmp2 bool; tmp2 = k == high; if !tmp2 { var tmp3 float64 = a.A[k]; tmp2 = tmp3 < a.A[k-1] }; tmp1 = tmp2; if tmp1 {
		k = k - 1 }
	if a.A[k] <= value { break L1 }
	var tmp4 int32 = p; var tmp5 int32; p = k; tmp5 = p; a.A[tmp4] = a.A[tmp5]
//line :1918:1
	continue L1
}





	a.A[p] = value
}
func DualPivotQuicksort_TryMergeRuns_DualPivotQuicksort_Sorter_D1_I_I__Z(sorter *DualPivotQuicksort_Sorter, a *DoubleArray, low, size int32) bool {
	var run *IntArray; var high int32 = low + size; var count int32 = 1; var last int32 = low; var k int32 = low + 1




L1: for { if k < high {
	var tmp1 float64 = a.A[k-1]; if tmp1 < a.A[k] {

	L2: for { var tmp2 bool; var tmp3 bool; var tmp4 int32; k = k + 1; tmp4 = k; tmp3 = tmp4 < high; if tmp3 {
		var tmp5 float64 = a.A[k-1]; tmp3 = tmp5 <= a.A[k] }
//line :1936:1
		tmp2 = tmp3; if tmp2 { continue L2 }; break L2 } } else {
//line :1934:1
			var tmp6 float64 = a.A[k-1]; if tmp6 > a.A[k] {





			L3: for { var tmp7 bool; var tmp8 bool; var tmp9 int32; k = k + 1; tmp9 = k; tmp8 = tmp9 < high; if tmp8 {
				var tmp10 float64 = a.A[k-1]; tmp8 = tmp10 >= a.A[k] }
//line :1940:1
				tmp7 = tmp8; if tmp7 { continue L3 }; break L3
			}
				var i int32 = last - 1
				var j int32 = k
			L4: for { var tmp11 bool; var tmp12 bool; var tmp13 int32; i = i + 1; tmp13 = i; var tmp14 int32 = tmp13; var tmp15 int32; j = j - 1; tmp15 = j; tmp12 = tmp14 < tmp15; if tmp12 {
				var tmp16 float64 = a.A[i]; tmp12 = tmp16 > a.A[j] }
//line :1944:1
				tmp11 = tmp12; if tmp11 {

					var ai float64 = a.A[i]; a.A[i] = a.A[j]; a.A[j] = ai
//line :1944:1
					continue L4 }; break L4 } } else {




						var ak float64 = a.A[k]; L5: for {
							var tmp17 bool; var tmp18 bool; var tmp19 int32; k = k + 1; tmp19 = k; tmp18 = tmp19 < high; if tmp18 { tmp18 = ak == a.A[k] }; tmp17 = tmp18; if tmp17 { ak = ak; continue L5 }
//line :1949:1
							break L5
						}
						if k < high { continue L1 } } }
	if run == nil {

		if k == high { return true }
		if k-low < 16 { return false }
		run = NewIntArray((size>>10 | 127) & 1023)


		run.A[0] = low } else {
			var tmp20 float64 = a.A[last-1]; if tmp20 > a.A[last] {
				if count > (k-low)>>7 {

					return false }
				var tmp21 int32; count = count + 1; tmp21 = count; if tmp21 == 5120 { return false }
				if count == int32(len(run.A)) {
					run = Arrays_CopyOf_I1_I__I1(run, count<<1) } } }
	var tmp22 *IntArray = run; var tmp23 int32 = count; var tmp24 int32; last = k; tmp24 = last; tmp22.A[tmp23] = tmp24
//line :1933:1
	continue L1 }; break L1
}

































	if count > 1 {
		var b *DoubleArray; var offset int32 = low; var tmp25 bool; var tmp26 bool

		tmp26 = sorter == nil; if !tmp26 { var tmp27 *DoubleArray; b = A2g_CastArray[*DoubleArray](sorter.F_b, Prim_double.ArrayClass()); tmp27 = b; tmp26 = tmp27 == nil }; tmp25 = tmp26; if tmp25 {
			b = NewDoubleArray(size) } else {
				offset = sorter.F_offset }
		DualPivotQuicksort_MergeRuns_D1_D1_I_I_Z_I1_I_I__D1(a, b, offset, 1, !(sorter == nil), run, 0, count) }
//line :1928:1
	return true
}















































func DualPivotQuicksort_MergeRuns_D1_D1_I_I_Z_I1_I_I__D1(a, b *DoubleArray, offset, aim int32, parallel bool, run *IntArray, lo, hi int32) *DoubleArray {

	if hi-lo == 1 {
		if aim >= 0 { return a } else {


			var i int32 = run.A[hi]; var j int32 = i - offset; var low int32 = run.A[lo]


		L1: for { if i > low {
			var tmp1 int32; j = j - 1; tmp1 = j; var tmp2 int32 = tmp1; var tmp3 int32; i = i - 1; tmp3 = i; b.A[tmp2] = a.A[tmp3]
//line :1986:1
			continue L1 }; break L1 }
//line :1982:1
			return b
		}


	} else {


		var mi int32 = lo; var tmp4 int32 = run.A[lo]; var rmi int32 = int32(uint32(tmp4+run.A[hi]) >> 1)

	L2: for { var tmp5 int32; mi = mi + 1; tmp5 = mi; if run.A[tmp5+1] <= rmi { continue L2 }; break L2 }
		var a1 *DoubleArray; var a2 *DoubleArray; var tmp6 bool; var tmp7 bool

		tmp7 = parallel; if tmp7 { tmp7 = hi-lo > 4 }; tmp6 = tmp7; if tmp6 {
			var merger *DualPivotQuicksort_RunMerger = DualPivotQuicksort_RunMerger_New_O_O_I_I_I1_I_I(a.Ref(), b.Ref(), offset, 0, run, mi, hi).ForkMe__DualPivotQuicksort_RunMerger()
			a1 = DualPivotQuicksort_MergeRuns_D1_D1_I_I_Z_I1_I_I__D1(a, b, offset, -aim, true, run, lo, mi)









			a2 = A2g_CastArray[*DoubleArray](NN(merger).GetDestination__O(), Prim_double.ArrayClass()) } else {

				a1 = DualPivotQuicksort_MergeRuns_D1_D1_I_I_Z_I1_I_I__D1(a, b, offset, -aim, false, run, lo, mi)









				a2 = DualPivotQuicksort_MergeRuns_D1_D1_I_I_Z_I1_I_I__D1(a, b, offset, 0, false, run, mi, hi) }
		var dst *DoubleArray; if a1 == a { dst = b } else { dst = a }; var k int32
		if a1 == a {
			k = run.A[lo] - offset } else {
				k = run.A[lo] }
//line :2019:1
		var lo1 int32



		if a1 == b {
			lo1 = run.A[lo] - offset } else {
				lo1 = run.A[lo] }
//line :2019:1
		var hi1 int32






		if a1 == b {
			hi1 = run.A[mi] - offset } else {
				hi1 = run.A[mi] }
//line :2019:1
		var lo2 int32









		if a2 == b {
			lo2 = run.A[mi] - offset } else {
				lo2 = run.A[mi] }
//line :2019:1
		var hi2 int32












		if a2 == b {
			hi2 = run.A[hi] - offset } else {
				hi2 = run.A[hi] }
		if parallel {
			DualPivotQuicksort_Merger_New_CountedCompleter_O_I_O_I_I_O_I_I(nil, dst.Ref(), k, a1.Ref(), lo1, hi1, a2.Ref(), lo2, hi2).Invoke__O() } else {
				DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_D1_I_D1_I_I_D1_I_I__V(nil, dst, k, a1, lo1, hi1, a2, lo2, hi2) }
//line :2019:1
		return dst
	}
}


















func DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_D1_I_D1_I_I_D1_I_I__V(merger *DualPivotQuicksort_Merger, dst *DoubleArray, k int32, a1 *DoubleArray, lo1, hi1 int32, a2 *DoubleArray, lo2, hi2 int32) {


	var tmp1 bool; var tmp2 bool; tmp2 = !(merger == nil); if tmp2 { tmp2 = a1 == a2 }; tmp1 = tmp2; if tmp1 {
	L1: for {
		if hi1-lo1 < hi2-lo2 {
			var lo int32 = lo1; lo1 = lo2; lo2 = lo; var hi int32 = hi1; hi1 = hi2; hi2 = hi }
		if hi1-lo1 < 4096 { break L1 }
		var mi1 int32 = int32(uint32(lo1+hi1) >> 1); var key float64 = a1.A[mi1]
		var mi2 int32 = hi2
		var loo int32 = lo2

	L2: for { if loo < mi2 {
		var t_ int32 = int32(uint32(loo+mi2) >> 1)
		if key > a2.A[t_] { loo = t_ + 1 } else { mi2 = t_ }
//line :2052:1
		continue L2 }; break L2
	}

		var d int32 = mi2 - lo2 + mi1 - lo1

		NN(merger).ForkMerger_O_I_O_I_I_O_I_I__V(dst.Ref(), k+d, a1.Ref(), mi1, hi1, a2.Ref(), mi2, hi2)
		hi1 = mi1
		hi2 = mi2
//line :2044:1
		continue L1
	}
	}













L3: for { var tmp3 bool; var tmp4 bool; tmp4 = lo1 < hi1; if tmp4 { tmp4 = lo2 < hi2 }; tmp3 = tmp4; if tmp3 {
	var tmp5 int32 = k; var tmp6 float64; var tmp7 float64 = a1.A[lo1]

	if tmp7 < a2.A[lo2] {
		var tmp8 int32; var old_10 int32 = lo1; lo1 = lo1 + 1; tmp8 = old_10; tmp6 = a1.A[tmp8] } else {
			var tmp9 int32; var old_11 int32 = lo2; lo2 = lo2 + 1; tmp9 = old_11; tmp6 = a2.A[tmp9] }
//line :2061:1
	dst.A[tmp5] = tmp6




	k = k + 1
//line :2060:1
	continue L3 }; break L3
}





	var tmp10 bool; var tmp11 bool; tmp11 = !(dst == a1); if !tmp11 { tmp11 = k < lo1 }; tmp10 = tmp11; if tmp10 {
	L4: for { if lo1 < hi1 {
		dst.A[k] = a1.A[lo1]
		k = k + 1
		lo1 = lo1 + 1
//line :2068:1
		continue L4 }; break L4
	}
	}

	var tmp12 bool; var tmp13 bool; tmp13 = !(dst == a2); if !tmp13 { tmp13 = k < lo2 }; tmp12 = tmp13; if tmp12 {
	L5: for { if lo2 < hi2 {
		dst.A[k] = a2.A[lo2]
		k = k + 1
		lo2 = lo2 + 1
//line :2073:1
		continue L5 }; break L5
	}
	}
}


















func DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(p0 CountedCompleter_I, p1, p2 any, p3, p4, p5, p6 int32) *DualPivotQuicksort_Sorter { DualPivotQuicksort_Sorter_Init(); t := &DualPivotQuicksort_Sorter{}; t.Ctor_CountedCompleter_O_O_I_I_I_I(p0, p1, p2, p3, p4, p5, p6); return t }
//line :2095:1
func (t *DualPivotQuicksort_Sorter) Ctor_CountedCompleter_O_O_I_I_I_I(parent CountedCompleter_I, a, b any, low, size, offset, depth int32) { t.CountedCompleter.Ctor_CountedCompleter(t, parent)


	t.F_a = a
	t.F_b = b
	t.F_low = low
	t.F_size = size
	t.F_offset = offset
	t.F_depth = depth
}
func (t *DualPivotQuicksort_Sorter) Compute__V() {
	if t.F_depth < 0 {


		t.SetPendingCount_I__V(2)
		var half int32 = t.F_size >> 1
		DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(t, t.F_b, t.F_a, t.F_low, half, t.F_offset, t.F_depth+1).Fork__ForkJoinTask()
		DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(t, t.F_b, t.F_a, t.F_low+half, t.F_size-half, t.F_offset, t.F_depth+1).Compute__V() } else {
//line :2106:1
			if Prim_int.ArrayClass().IsInstance_O__Z(t.F_a) {













				DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_I1_I_I_I__V(t, A2g_CastArray[*IntArray](t.F_a, Prim_int.ArrayClass()), t.F_depth, t.F_low, t.F_low+t.F_size) } else {
//line :2106:1
					if Prim_long.ArrayClass().IsInstance_O__Z(t.F_a) {















						DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_J1_I_I_I__V(t, A2g_CastArray[*LongArray](t.F_a, Prim_long.ArrayClass()), t.F_depth, t.F_low, t.F_low+t.F_size) } else {
//line :2106:1
							if Prim_float.ArrayClass().IsInstance_O__Z(t.F_a) {

















								DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_F1_I_I_I__V(t, A2g_CastArray[*FloatArray](t.F_a, Prim_float.ArrayClass()), t.F_depth, t.F_low, t.F_low+t.F_size) } else {
//line :2106:1
									if Prim_double.ArrayClass().IsInstance_O__Z(t.F_a) {



















										DualPivotQuicksort_Sort_DualPivotQuicksort_Sorter_D1_I_I_I__V(t, A2g_CastArray[*DoubleArray](t.F_a, Prim_double.ArrayClass()), t.F_depth, t.F_low, t.F_low+t.F_size) } else {

											panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2665, NN(GetClass(t.F_a)).GetName__String()))))
										} } } } }
	t.TryComplete__V()
}
func (t *DualPivotQuicksort_Sorter) OnCompletion_CountedCompleter__V(caller CountedCompleter_I) {
	if t.F_depth < 0 {
		var mi int32 = t.F_low + t.F_size>>1; var src bool = t.F_depth&1 == 0; var tmp1 any = t.F_a; var tmp2 int32



		if src { tmp2 = t.F_low } else { tmp2 = t.F_low - t.F_offset }
//line :2136:1
		var tmp3 int32 = tmp2; var tmp4 any = t.F_b; var tmp5 int32



		if src { tmp5 = t.F_low - t.F_offset } else { tmp5 = t.F_low }
//line :2136:1
		var tmp6 int32 = tmp5; var tmp7 int32




		if src { tmp7 = mi - t.F_offset } else { tmp7 = mi }
//line :2136:1
		var tmp8 int32 = tmp7; var tmp9 any = t.F_b; var tmp10 int32






		if src { tmp10 = mi - t.F_offset } else { tmp10 = mi }
//line :2136:1
		var tmp11 int32 = tmp10; var tmp12 int32







		if src {
			tmp12 = t.F_low + t.F_size - t.F_offset } else {
				tmp12 = t.F_low + t.F_size }
//line :2136:1
		DualPivotQuicksort_Merger_New_CountedCompleter_O_I_O_I_I_O_I_I(nil, tmp1, tmp3, tmp4, tmp6, tmp8, tmp9, tmp11, tmp12).Invoke__O()
	}
}









func (t *DualPivotQuicksort_Sorter) ForkSorter_I_I_I__V(depth, low, high int32) {
	t.AddToPendingCount_I__V(1)
	var a any = t.F_a
	DualPivotQuicksort_Sorter_New_CountedCompleter_O_O_I_I_I_I(t, a, t.F_b, low, high-low, t.F_offset, depth).Fork__ForkJoinTask()
}





















func DualPivotQuicksort_Merger_New_CountedCompleter_O_I_O_I_I_O_I_I(p0 CountedCompleter_I, p1 any, p2 int32, p3 any, p4, p5 int32, p6 any, p7, p8 int32) *DualPivotQuicksort_Merger { DualPivotQuicksort_Merger_Init(); t := &DualPivotQuicksort_Merger{}; t.Ctor_CountedCompleter_O_I_O_I_I_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :2174:1
func (t *DualPivotQuicksort_Merger) Ctor_CountedCompleter_O_I_O_I_I_O_I_I(parent CountedCompleter_I, dst any, k int32, a1 any, lo1, hi1 int32, a2 any, lo2, hi2 int32) { t.CountedCompleter.Ctor_CountedCompleter(t, parent)


	t.F_dst = dst
	t.F_k = k
	t.F_a1 = a1
	t.F_lo1 = lo1
	t.F_hi1 = hi1
	t.F_a2 = a2
	t.F_lo2 = lo2
	t.F_hi2 = hi2
}
func (t *DualPivotQuicksort_Merger) Compute__V() {
	if Prim_int.ArrayClass().IsInstance_O__Z(t.F_dst) {

		var tmp1 *IntArray = A2g_CastArray[*IntArray](t.F_dst, Prim_int.ArrayClass()); var tmp2 int32 = t.F_k; var tmp3 *IntArray = A2g_CastArray[*IntArray](t.F_a1, Prim_int.ArrayClass()); var tmp4 int32 = t.F_lo1; var tmp5 int32 = t.F_hi1; DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_I1_I_I1_I_I_I1_I_I__V(t, tmp1, tmp2, tmp3, tmp4, tmp5, A2g_CastArray[*IntArray](t.F_a2, Prim_int.ArrayClass()), t.F_lo2, t.F_hi2) } else {
//line :2187:1
			if Prim_long.ArrayClass().IsInstance_O__Z(t.F_dst) {











				var tmp6 *LongArray = A2g_CastArray[*LongArray](t.F_dst, Prim_long.ArrayClass()); var tmp7 int32 = t.F_k; var tmp8 *LongArray = A2g_CastArray[*LongArray](t.F_a1, Prim_long.ArrayClass()); var tmp9 int32 = t.F_lo1; var tmp10 int32 = t.F_hi1; DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_J1_I_J1_I_I_J1_I_I__V(t, tmp6, tmp7, tmp8, tmp9, tmp10, A2g_CastArray[*LongArray](t.F_a2, Prim_long.ArrayClass()), t.F_lo2, t.F_hi2) } else {
//line :2187:1
					if Prim_float.ArrayClass().IsInstance_O__Z(t.F_dst) {





















						var tmp11 *FloatArray = A2g_CastArray[*FloatArray](t.F_dst, Prim_float.ArrayClass()); var tmp12 int32 = t.F_k; var tmp13 *FloatArray = A2g_CastArray[*FloatArray](t.F_a1, Prim_float.ArrayClass()); var tmp14 int32 = t.F_lo1; var tmp15 int32 = t.F_hi1; DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_F1_I_F1_I_I_F1_I_I__V(t, tmp11, tmp12, tmp13, tmp14, tmp15, A2g_CastArray[*FloatArray](t.F_a2, Prim_float.ArrayClass()), t.F_lo2, t.F_hi2) } else {
//line :2187:1
							if Prim_double.ArrayClass().IsInstance_O__Z(t.F_dst) {































								var tmp16 *DoubleArray = A2g_CastArray[*DoubleArray](t.F_dst, Prim_double.ArrayClass()); var tmp17 int32 = t.F_k; var tmp18 *DoubleArray = A2g_CastArray[*DoubleArray](t.F_a1, Prim_double.ArrayClass()); var tmp19 int32 = t.F_lo1; var tmp20 int32 = t.F_hi1; DualPivotQuicksort_MergeParts_DualPivotQuicksort_Merger_D1_I_D1_I_I_D1_I_I__V(t, tmp16, tmp17, tmp18, tmp19, tmp20, A2g_CastArray[*DoubleArray](t.F_a2, Prim_double.ArrayClass()), t.F_lo2, t.F_hi2) } else {









									panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2665, NN(GetClass(t.F_dst)).GetName__String()))))
								} } } }
	t.PropagateCompletion__V()
}
func (t *DualPivotQuicksort_Merger) ForkMerger_O_I_O_I_I_O_I_I__V(dst any, k int32, a1 any, lo1, hi1 int32, a2 any, lo2, hi2 int32) {
	t.AddToPendingCount_I__V(1)
	DualPivotQuicksort_Merger_New_CountedCompleter_O_I_O_I_I_O_I_I(t, dst, k, a1, lo1, hi1, a2, lo2, hi2).Fork__ForkJoinTask()
}



















func DualPivotQuicksort_RunMerger_New_O_O_I_I_I1_I_I(p0, p1 any, p2, p3 int32, p4 *IntArray, p5, p6 int32) *DualPivotQuicksort_RunMerger { t := &DualPivotQuicksort_RunMerger{}; t.Ctor_O_O_I_I_I1_I_I(p0, p1, p2, p3, p4, p5, p6); return t }
//line :2256:1
func (t *DualPivotQuicksort_RunMerger) Ctor_O_O_I_I_I1_I_I(a, b any, offset, aim int32, run *IntArray, lo, hi int32) { t.RecursiveTask.Ctor(t)
	t.F_a = a
	t.F_b = b
	t.F_offset = offset
	t.F_aim = aim
	t.F_run = run
	t.F_lo = lo
	t.F_hi = hi
}
func (t *DualPivotQuicksort_RunMerger) Compute__O() any {
	if Prim_int.ArrayClass().IsInstance_O__Z(t.F_a) {

		var tmp1 *IntArray = A2g_CastArray[*IntArray](t.F_a, Prim_int.ArrayClass()); return DualPivotQuicksort_MergeRuns_I1_I1_I_I_Z_I1_I_I__I1(tmp1, A2g_CastArray[*IntArray](t.F_b, Prim_int.ArrayClass()), t.F_offset, t.F_aim, true, t.F_run, t.F_lo, t.F_hi).Ref() } else {
//line :2266:1
			if Prim_long.ArrayClass().IsInstance_O__Z(t.F_a) {



				var tmp2 *LongArray = A2g_CastArray[*LongArray](t.F_a, Prim_long.ArrayClass()); return DualPivotQuicksort_MergeRuns_J1_J1_I_I_Z_I1_I_I__J1(tmp2, A2g_CastArray[*LongArray](t.F_b, Prim_long.ArrayClass()), t.F_offset, t.F_aim, true, t.F_run, t.F_lo, t.F_hi).Ref() } else {
//line :2266:1
					if Prim_float.ArrayClass().IsInstance_O__Z(t.F_a) {





						var tmp3 *FloatArray = A2g_CastArray[*FloatArray](t.F_a, Prim_float.ArrayClass()); return DualPivotQuicksort_MergeRuns_F1_F1_I_I_Z_I1_I_I__F1(tmp3, A2g_CastArray[*FloatArray](t.F_b, Prim_float.ArrayClass()), t.F_offset, t.F_aim, true, t.F_run, t.F_lo, t.F_hi).Ref() } else {
//line :2266:1
							if Prim_double.ArrayClass().IsInstance_O__Z(t.F_a) {







								var tmp4 *DoubleArray = A2g_CastArray[*DoubleArray](t.F_a, Prim_double.ArrayClass()); return DualPivotQuicksort_MergeRuns_D1_D1_I_I_Z_I1_I_I__D1(tmp4, A2g_CastArray[*DoubleArray](t.F_b, Prim_double.ArrayClass()), t.F_offset, t.F_aim, true, t.F_run, t.F_lo, t.F_hi).Ref() } else {








									panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2665, NN(GetClass(t.F_a)).GetName__String()))))
								}
						} } } }
func (t *DualPivotQuicksort_RunMerger) ForkMe__DualPivotQuicksort_RunMerger() *DualPivotQuicksort_RunMerger { t.Fork__ForkJoinTask(); return t }

func (t *DualPivotQuicksort_RunMerger) GetDestination__O() any {
	t.Join__O()
	return t.GetRawResult__O()
}


type DualPivotQuicksort struct{ Object }

const DualPivotQuicksort_MAX_MIXED_INSERTION_SORT_SIZE int32 = 65

const DualPivotQuicksort_MAX_INSERTION_SORT_SIZE int32 = 44

const DualPivotQuicksort_MIN_PARALLEL_SORT_SIZE int32 = 4096

const DualPivotQuicksort_MIN_TRY_MERGE_SIZE int32 = 4096

const DualPivotQuicksort_MIN_FIRST_RUN_SIZE int32 = 16

const DualPivotQuicksort_MIN_FIRST_RUNS_FACTOR int32 = 7

const DualPivotQuicksort_MAX_RUN_CAPACITY int32 = 5120

const DualPivotQuicksort_MIN_RUN_COUNT int32 = 4

const DualPivotQuicksort_MIN_PARALLEL_MERGE_PARTS_SIZE int32 = 4096

const DualPivotQuicksort_MIN_BYTE_COUNTING_SORT_SIZE int32 = 64

const DualPivotQuicksort_MIN_SHORT_OR_CHAR_COUNTING_SORT_SIZE int32 = 1750

const DualPivotQuicksort_DELTA int32 = 6

const DualPivotQuicksort_MAX_RECURSION_DEPTH int32 = 384

const DualPivotQuicksort_NUM_BYTE_VALUES int32 = 256

const DualPivotQuicksort_MAX_BYTE_INDEX int32 = 384

const DualPivotQuicksort_NUM_CHAR_VALUES int32 = 65536

const DualPivotQuicksort_NUM_SHORT_VALUES int32 = 65536

const DualPivotQuicksort_MAX_SHORT_INDEX int32 = 98304

func (t *DualPivotQuicksort) Ref() any { if t == nil { return nil }; return t }

func (t *DualPivotQuicksort) GetClass__Class() *Class { return DualPivotQuicksort_class }

func (t *DualPivotQuicksort) ToString__String() *String { return Object_toString(t) }

func (t *DualPivotQuicksort) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DualPivotQuicksort) CloneShallow() any { panic(CloneNotSupported(t)) }

func DualPivotQuicksort_InstanceOf(x any) bool { _, ok := x.(*DualPivotQuicksort); return ok }

func DualPivotQuicksort_Cast(x any) *DualPivotQuicksort { if x == nil { return nil }; v, ok := x.(*DualPivotQuicksort); if !ok { panic(ClassCast(x, DualPivotQuicksort_class)) }; return v }



type DualPivotQuicksort_Merger struct{ CountedCompleter; F_dst, F_a1, F_a2 any; F_k, F_lo1, F_hi1, F_lo2, F_hi2 int32 }

const DualPivotQuicksort_Merger_serialVersionUID int64 = 20180818

var DualPivotQuicksort_Merger_init ClassInit

func DualPivotQuicksort_Merger_Init() { if !DualPivotQuicksort_Merger_init.Done() { DualPivotQuicksort_Merger_init.Run(DualPivotQuicksort_Merger_clinit) } }

func DualPivotQuicksort_Merger_clinit() { CountedCompleter_Init() }

func (t *DualPivotQuicksort_Merger) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *DualPivotQuicksort_Merger) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *DualPivotQuicksort_Merger) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *DualPivotQuicksort_Merger) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *DualPivotQuicksort_Merger) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *DualPivotQuicksort_Merger) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *DualPivotQuicksort_Merger) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *DualPivotQuicksort_Merger) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *DualPivotQuicksort_Merger) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *DualPivotQuicksort_Merger) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *DualPivotQuicksort_Merger) Get__O() any { return t.Impl_Get__O(t) }

func (t *DualPivotQuicksort_Merger) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *DualPivotQuicksort_Merger) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *DualPivotQuicksort_Merger) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *DualPivotQuicksort_Merger) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *DualPivotQuicksort_Merger) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *DualPivotQuicksort_Merger) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *DualPivotQuicksort_Merger) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *DualPivotQuicksort_Merger) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *DualPivotQuicksort_Merger) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *DualPivotQuicksort_Merger) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *DualPivotQuicksort_Merger) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *DualPivotQuicksort_Merger) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *DualPivotQuicksort_Merger) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *DualPivotQuicksort_Merger) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *DualPivotQuicksort_Merger) Join__O() any { return t.Impl_Join__O(t) }

func (t *DualPivotQuicksort_Merger) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *DualPivotQuicksort_Merger) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *DualPivotQuicksort_Merger) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *DualPivotQuicksort_Merger) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *DualPivotQuicksort_Merger) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *DualPivotQuicksort_Merger) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *DualPivotQuicksort_Merger) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *DualPivotQuicksort_Merger) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *DualPivotQuicksort_Merger) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *DualPivotQuicksort_Merger) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *DualPivotQuicksort_Merger) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *DualPivotQuicksort_Merger) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *DualPivotQuicksort_Merger) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *DualPivotQuicksort_Merger) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *DualPivotQuicksort_Merger) Ref() any { if t == nil { return nil }; return t }

func (t *DualPivotQuicksort_Merger) GetClass__Class() *Class { return DualPivotQuicksort_Merger_class }

func (t *DualPivotQuicksort_Merger) ToString__String() *String { return Object_toString(t) }

func (t *DualPivotQuicksort_Merger) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DualPivotQuicksort_Merger) CloneShallow() any { panic(CloneNotSupported(t)) }

func DualPivotQuicksort_Merger_InstanceOf(x any) bool { _, ok := x.(*DualPivotQuicksort_Merger); return ok }

func DualPivotQuicksort_Merger_Cast(x any) *DualPivotQuicksort_Merger { if x == nil { return nil }; v, ok := x.(*DualPivotQuicksort_Merger); if !ok { panic(ClassCast(x, DualPivotQuicksort_Merger_class)) }; return v }



type DualPivotQuicksort_PartitionOperation interface{ Object_I; Is_DualPivotQuicksort_PartitionOperation(); Partition_O_I_I_I_I__I1(p0 any, p1, p2, p3, p4 int32) *IntArray }

func DualPivotQuicksort_PartitionOperation_InstanceOf(x any) bool { _, ok := x.(DualPivotQuicksort_PartitionOperation); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DualPivotQuicksort_PartitionOperation_class) } }; return ok }

func DualPivotQuicksort_PartitionOperation_Cast(x any) DualPivotQuicksort_PartitionOperation { if x == nil { return nil }; v, ok := x.(DualPivotQuicksort_PartitionOperation); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DualPivotQuicksort_PartitionOperation_class) } }; if !ok { panic(ClassCast(x, DualPivotQuicksort_PartitionOperation_class)) }; return v }



type DualPivotQuicksort_RunMerger struct{ RecursiveTask; F_a, F_b any; F_run *IntArray; F_offset, F_aim, F_lo, F_hi int32 }

const DualPivotQuicksort_RunMerger_serialVersionUID int64 = 20180818

func (t *DualPivotQuicksort_RunMerger) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *DualPivotQuicksort_RunMerger) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *DualPivotQuicksort_RunMerger) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *DualPivotQuicksort_RunMerger) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *DualPivotQuicksort_RunMerger) Get__O() any { return t.Impl_Get__O(t) }

func (t *DualPivotQuicksort_RunMerger) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *DualPivotQuicksort_RunMerger) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *DualPivotQuicksort_RunMerger) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *DualPivotQuicksort_RunMerger) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *DualPivotQuicksort_RunMerger) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *DualPivotQuicksort_RunMerger) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *DualPivotQuicksort_RunMerger) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *DualPivotQuicksort_RunMerger) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *DualPivotQuicksort_RunMerger) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *DualPivotQuicksort_RunMerger) Join__O() any { return t.Impl_Join__O(t) }

func (t *DualPivotQuicksort_RunMerger) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *DualPivotQuicksort_RunMerger) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *DualPivotQuicksort_RunMerger) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *DualPivotQuicksort_RunMerger) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *DualPivotQuicksort_RunMerger) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *DualPivotQuicksort_RunMerger) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *DualPivotQuicksort_RunMerger) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *DualPivotQuicksort_RunMerger) Ref() any { if t == nil { return nil }; return t }

func (t *DualPivotQuicksort_RunMerger) GetClass__Class() *Class { return DualPivotQuicksort_RunMerger_class }

func (t *DualPivotQuicksort_RunMerger) ToString__String() *String { return Object_toString(t) }

func (t *DualPivotQuicksort_RunMerger) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DualPivotQuicksort_RunMerger) CloneShallow() any { panic(CloneNotSupported(t)) }

func DualPivotQuicksort_RunMerger_InstanceOf(x any) bool { _, ok := x.(*DualPivotQuicksort_RunMerger); return ok }

func DualPivotQuicksort_RunMerger_Cast(x any) *DualPivotQuicksort_RunMerger { if x == nil { return nil }; v, ok := x.(*DualPivotQuicksort_RunMerger); if !ok { panic(ClassCast(x, DualPivotQuicksort_RunMerger_class)) }; return v }



type DualPivotQuicksort_SortOperation interface{ Object_I; Is_DualPivotQuicksort_SortOperation(); Sort_O_I_I__V(p0 any, p1, p2 int32) }

func DualPivotQuicksort_SortOperation_InstanceOf(x any) bool { _, ok := x.(DualPivotQuicksort_SortOperation); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DualPivotQuicksort_SortOperation_class) } }; return ok }

func DualPivotQuicksort_SortOperation_Cast(x any) DualPivotQuicksort_SortOperation { if x == nil { return nil }; v, ok := x.(DualPivotQuicksort_SortOperation); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DualPivotQuicksort_SortOperation_class) } }; if !ok { panic(ClassCast(x, DualPivotQuicksort_SortOperation_class)) }; return v }



type DualPivotQuicksort_Sorter struct{ CountedCompleter; F_a, F_b any; F_low, F_size, F_offset, F_depth int32 }

const DualPivotQuicksort_Sorter_serialVersionUID int64 = 20180818

var DualPivotQuicksort_Sorter_init ClassInit

func DualPivotQuicksort_Sorter_Init() { if !DualPivotQuicksort_Sorter_init.Done() { DualPivotQuicksort_Sorter_init.Run(DualPivotQuicksort_Sorter_clinit) } }

func DualPivotQuicksort_Sorter_clinit() { CountedCompleter_Init() }

func (t *DualPivotQuicksort_Sorter) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *DualPivotQuicksort_Sorter) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *DualPivotQuicksort_Sorter) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *DualPivotQuicksort_Sorter) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *DualPivotQuicksort_Sorter) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *DualPivotQuicksort_Sorter) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *DualPivotQuicksort_Sorter) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *DualPivotQuicksort_Sorter) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *DualPivotQuicksort_Sorter) Get__O() any { return t.Impl_Get__O(t) }

func (t *DualPivotQuicksort_Sorter) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *DualPivotQuicksort_Sorter) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *DualPivotQuicksort_Sorter) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *DualPivotQuicksort_Sorter) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *DualPivotQuicksort_Sorter) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *DualPivotQuicksort_Sorter) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *DualPivotQuicksort_Sorter) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *DualPivotQuicksort_Sorter) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *DualPivotQuicksort_Sorter) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *DualPivotQuicksort_Sorter) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *DualPivotQuicksort_Sorter) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *DualPivotQuicksort_Sorter) Join__O() any { return t.Impl_Join__O(t) }

func (t *DualPivotQuicksort_Sorter) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *DualPivotQuicksort_Sorter) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *DualPivotQuicksort_Sorter) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *DualPivotQuicksort_Sorter) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *DualPivotQuicksort_Sorter) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *DualPivotQuicksort_Sorter) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *DualPivotQuicksort_Sorter) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *DualPivotQuicksort_Sorter) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *DualPivotQuicksort_Sorter) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *DualPivotQuicksort_Sorter) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *DualPivotQuicksort_Sorter) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *DualPivotQuicksort_Sorter) Ref() any { if t == nil { return nil }; return t }

func (t *DualPivotQuicksort_Sorter) GetClass__Class() *Class { return DualPivotQuicksort_Sorter_class }

func (t *DualPivotQuicksort_Sorter) ToString__String() *String { return Object_toString(t) }

func (t *DualPivotQuicksort_Sorter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DualPivotQuicksort_Sorter) CloneShallow() any { panic(CloneNotSupported(t)) }

func DualPivotQuicksort_Sorter_InstanceOf(x any) bool { _, ok := x.(*DualPivotQuicksort_Sorter); return ok }

func DualPivotQuicksort_Sorter_Cast(x any) *DualPivotQuicksort_Sorter { if x == nil { return nil }; v, ok := x.(*DualPivotQuicksort_Sorter); if !ok { panic(ClassCast(x, DualPivotQuicksort_Sorter_class)) }; return v }
