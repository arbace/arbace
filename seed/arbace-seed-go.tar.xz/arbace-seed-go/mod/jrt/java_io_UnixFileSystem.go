//line java_io_UnixFileSystem.ae:1
package jrt












func UnixFileSystem_New() *UnixFileSystem { t := &UnixFileSystem{}; t.Ctor(); return t }
//line :14:1
func (t *UnixFileSystem) Ctor() { t.FileSystem.Ctor(t)
	t.F_slash = NN(System_GetProperty_String__String(Lit_102)).CharAt_I__C(0)
	t.F_colon = NN(System_GetProperty_String__String(Lit_103)).CharAt_I__C(0)
	t.F_userDir = System_GetProperty_String__String(Lit_104) }
//line :16:1
func (t *UnixFileSystem) GetPathForSysCalls_String__String(path *String) *String {
	if NN(path).IsEmpty__Z() { return NN(FileSystem_GetCWD__File()).GetPath__String() } else { return path
	} }
func (t *UnixFileSystem) GetFileForSysCalls_File__File(file *File) *File {
	if NN(NN(file).GetPath__String()).IsEmpty__Z() { return FileSystem_GetCWD__File() } else { return file } }
//line :19:1
func (t *UnixFileSystem) Canonicalize0_String__String(path *String) *String {
	return UnixFileSystem_HostCanonicalize_String__String(path) }
func (t *UnixFileSystem) GetBooleanAttributes0_File__I(f *File) int32 {
	return UnixFileSystem_HostBooleanAttributes_String__I(NN(f).GetPath__String()) }
func (t *UnixFileSystem) CheckAccess0_File_I__Z(f *File, access int32) bool {
	return UnixFileSystem_HostCheckAccess_String_I__Z(NN(f).GetPath__String(), access) }
func (t *UnixFileSystem) GetLastModifiedTime0_File__J(f *File) int64 {
	return UnixFileSystem_HostLastModifiedTime_String__J(NN(f).GetPath__String()) }
func (t *UnixFileSystem) GetLength0_File__J(f *File) int64 {
	return UnixFileSystem_HostLength_String__J(NN(f).GetPath__String()) }
//line :28:1
func (t *UnixFileSystem) GetSeparator__C() uint16 { return t.F_slash }
func (t *UnixFileSystem) SetPermission0_File_I_Z_Z__Z(f *File, access int32, enable, owneronly bool) bool {
	return UnixFileSystem_HostSetPermission_String_I_Z_Z__Z(NN(f).GetPath__String(), access, enable, owneronly) }
//line :30:1
func (t *UnixFileSystem) GetPathSeparator__C() uint16 { return t.F_colon }
func (t *UnixFileSystem) CreateFileExclusively0_String__Z(path *String) bool {
	return UnixFileSystem_HostCreateFileExclusively_String__Z(path) }
//line :32:1
func (t *UnixFileSystem) Normalize_String_I__String(pathname *String, off int32) *String {
	var n int32 = NN(pathname).Length__I()
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = n > off; if tmp2 { tmp2 = int32(NN(pathname).CharAt_I__C(n-1)) == 47 }; tmp1 = tmp2; if tmp1 {
	n = n - 1
//line :34:1
	continue L1 }; break L1
}
	if n == 0 { return Lit_68 } else { if n == off {

		return NN(pathname).Substring_I_I__String(0, off) } else {

			var sb *StringBuilder = StringBuilder_New_I(n)
			if off > 0 { NN(sb).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(pathname), 0, off) }
			var prevChar uint16 = 0; var i int32 = off
		L2: for {
			if i < n {
				var c uint16 = NN(pathname).CharAt_I__C(i); var tmp3 bool; var tmp4 bool
				tmp4 = int32(prevChar) == 47; if tmp4 { tmp4 = int32(c) == 47 }; tmp3 = tmp4; if tmp3 {
					i = i + 1; continue L2 } else {
						NN(sb).Append_C__StringBuilder(c); prevChar = c; i = i + 1; continue L2 } }
//line :43:1
			break L2
		}




			return NN(sb).ToString__String() } } }
//line :33:1
func (t *UnixFileSystem) Delete0_File__Z(f *File) bool {
	return UnixFileSystem_HostDelete_String__Z(NN(f).GetPath__String()) }
func (t *UnixFileSystem) List0_File__String1(f *File) *RefArray {
	return UnixFileSystem_HostList_String__String1(NN(f).GetPath__String()) }
func (t *UnixFileSystem) CreateDirectory0_File__Z(f *File) bool {
	return UnixFileSystem_HostCreateDirectory_String__Z(NN(f).GetPath__String()) }
func (t *UnixFileSystem) Rename0_File_File__Z(f1, f2 *File) bool {
	return UnixFileSystem_HostRename_String_String__Z(NN(f1).GetPath__String(), NN(f2).GetPath__String()) }
func (t *UnixFileSystem) SetLastModifiedTime0_File_J__Z(f *File, time int64) bool {
	return UnixFileSystem_HostSetLastModifiedTime_String_J__Z(NN(f).GetPath__String(), time) }
func (t *UnixFileSystem) SetReadOnly0_File__Z(f *File) bool {
	return UnixFileSystem_HostSetReadOnly_String__Z(NN(f).GetPath__String()) }
func (t *UnixFileSystem) GetSpace0_File_I__J(f *File, t_ int32) int64 {
	return UnixFileSystem_HostSpace_String_I__J(NN(f).GetPath__String(), t_) }
func (t *UnixFileSystem) GetNameMax0_String__J(path *String) int64 {
	return UnixFileSystem_HostNameMax_String__J(path)
}

func (t *UnixFileSystem) Normalize_String__String(pathname *String) *String {
	var doubleSlash int32 = NN(pathname).IndexOf_String__I(Lit_70)
	if doubleSlash >= 0 {
		return t.Normalize_String_I__String(pathname, doubleSlash) } else {
//line :53:1
			if NN(pathname).EndsWith_String__Z(Lit_68) {


				return t.Normalize_String_I__String(pathname, NN(pathname).Length__I()-1) } else {
//line :53:1
					return pathname } } }
//line :53:1
func UnixFileSystem_HostCanonicalize_String__String(p0 *String) *String { return UnixFileSystem_HostCanonicalize_String__String_native(p0) }
func UnixFileSystem_HostBooleanAttributes_String__I(p0 *String) int32 { return UnixFileSystem_HostBooleanAttributes_String__I_native(p0) }
func UnixFileSystem_HostCheckAccess_String_I__Z(p0 *String, p1 int32) bool { return UnixFileSystem_HostCheckAccess_String_I__Z_native(p0, p1) }
func UnixFileSystem_HostLastModifiedTime_String__J(p0 *String) int64 { return UnixFileSystem_HostLastModifiedTime_String__J_native(p0) }
func UnixFileSystem_HostLength_String__J(p0 *String) int64 { return UnixFileSystem_HostLength_String__J_native(p0) }
func UnixFileSystem_HostSetPermission_String_I_Z_Z__Z(p0 *String, p1 int32, p2, p3 bool) bool { return UnixFileSystem_HostSetPermission_String_I_Z_Z__Z_native(p0, p1, p2, p3) }
func (t *UnixFileSystem) PrefixLength_String__I(pathname *String) int32 {
	if NN(pathname).StartsWith_String__Z(Lit_68) { return 1 } else { return 0 } }
//line :60:1
func UnixFileSystem_HostCreateFileExclusively_String__Z(p0 *String) bool { return UnixFileSystem_HostCreateFileExclusively_String__Z_native(p0) }
func UnixFileSystem_HostDelete_String__Z(p0 *String) bool { return UnixFileSystem_HostDelete_String__Z_native(p0) }
func UnixFileSystem_TrimSeparator_String__String(s *String) *String {
	var len_ int32 = NN(s).Length__I(); var tmp1 bool; var tmp2 bool
	tmp2 = len_ > 1; if tmp2 { tmp2 = int32(NN(s).CharAt_I__C(len_-1)) == 47 }; tmp1 = tmp2; if tmp1 {
		return NN(s).Substring_I_I__String(0, len_-1) } else {
//line :64:1
			return s } }
//line :62:1
func UnixFileSystem_HostList_String__String1(p0 *String) *RefArray { return UnixFileSystem_HostList_String__String1_native(p0) }
func UnixFileSystem_HostCreateDirectory_String__Z(p0 *String) bool { return UnixFileSystem_HostCreateDirectory_String__Z_native(p0) }
func UnixFileSystem_HostRename_String_String__Z(p0, p1 *String) bool { return UnixFileSystem_HostRename_String_String__Z_native(p0, p1) }
func UnixFileSystem_HostSetLastModifiedTime_String_J__Z(p0 *String, p1 int64) bool { return UnixFileSystem_HostSetLastModifiedTime_String_J__Z_native(p0, p1) }
func UnixFileSystem_HostSetReadOnly_String__Z(p0 *String) bool { return UnixFileSystem_HostSetReadOnly_String__Z_native(p0) }
func UnixFileSystem_HostSpace_String_I__J(p0 *String, p1 int32) int64 { return UnixFileSystem_HostSpace_String_I__J_native(p0, p1) }
func (t *UnixFileSystem) Resolve_String_String__String(parent, child *String) *String {
	if NN(child).IsEmpty__Z() { return parent } else { if int32(NN(child).CharAt_I__C(0)) == 47 {


		if NN(parent).Equals_O__Z(Lit_68) { return child } else { return UnixFileSystem_TrimSeparator_String__String(Concat(parent, child)) } } else {
//line :69:1
			if NN(parent).Equals_O__Z(Lit_68) {



				return UnixFileSystem_TrimSeparator_String__String(Concat(parent, child)) } else {
					return UnixFileSystem_TrimSeparator_String__String(Concat(parent, Lit_68, child)) } } } }
//line :68:1
func UnixFileSystem_HostNameMax_String__J(p0 *String) int64 { return UnixFileSystem_HostNameMax_String__J_native(p0) }







func (t *UnixFileSystem) GetDefaultParent__String() *String { return Lit_68 }

func (t *UnixFileSystem) FromURIPath_String__String(path *String) *String {
	var p *String = path; var tmp1 bool; var tmp2 bool
	tmp2 = NN(p).EndsWith_String__Z(Lit_68); if tmp2 { tmp2 = NN(p).Length__I() > 1 }; tmp1 = tmp2; if tmp1 {
		p = NN(p).Substring_I_I__String(0, NN(p).Length__I()-1) }
//line :79:1
	return p
}



func (t *UnixFileSystem) IsAbsolute_File__Z(f *File) bool {
	return !(NN(f).GetPrefixLength__I() == 0)
}
func (t *UnixFileSystem) IsInvalid_File__Z(f *File) bool {
	return NN(NN(f).GetPath__String()).IndexOf_I__I(0) >= 0
}
func (t *UnixFileSystem) Resolve_File__String(f *File) *String {
	if t.IsAbsolute_File__Z(f) { return NN(f).GetPath__String() } else { var tmp1 *String = t.F_userDir; return t.Resolve_String_String__String(tmp1, NN(f).GetPath__String())
	} }
func (t *UnixFileSystem) Canonicalize_String__String(path *String) *String {
	return t.Canonicalize0_String__String(t.GetPathForSysCalls_String__String(path))
}




func (t *UnixFileSystem) GetBooleanAttributes_File__I(f *File) int32 {
	var rv_ int32 = t.GetBooleanAttributes0_File__I(t.GetFileForSysCalls_File__File(f))
	return rv_ | UnixFileSystem_IsHidden_File__I(f)
}
func (t *UnixFileSystem) HasBooleanAttributes_File_I__Z(f *File, attributes int32) bool {
	var rv_ int32 = t.GetBooleanAttributes0_File__I(t.GetFileForSysCalls_File__File(f))
	if attributes&8 == 0 { } else {
		rv_ = rv_ | UnixFileSystem_IsHidden_File__I(f) }
	return rv_&attributes == attributes
}
func UnixFileSystem_IsHidden_File__I(f *File) int32 {
	if NN(NN(f).GetName__String()).StartsWith_String__Z(Lit_79) { return 8 } else { return 0
	} }
func (t *UnixFileSystem) CheckAccess_File_I__Z(f *File, access int32) bool {
	return t.CheckAccess0_File_I__Z(t.GetFileForSysCalls_File__File(f), access)
}


func (t *UnixFileSystem) GetLastModifiedTime_File__J(f *File) int64 {
	return t.GetLastModifiedTime0_File__J(t.GetFileForSysCalls_File__File(f))
}


func (t *UnixFileSystem) GetLength_File__J(f *File) int64 {
	return t.GetLength0_File__J(t.GetFileForSysCalls_File__File(f))
}


func (t *UnixFileSystem) SetPermission_File_I_Z_Z__Z(f *File, access int32, enable, owneronly bool) bool {

	return t.SetPermission0_File_I_Z_Z__Z(t.GetFileForSysCalls_File__File(f), access, enable, owneronly)
}



func (t *UnixFileSystem) CreateFileExclusively_String__Z(path *String) bool {
	return t.CreateFileExclusively0_String__Z(path)
}



func (t *UnixFileSystem) Delete_File__Z(f *File) bool {
	return t.Delete0_File__Z(t.GetFileForSysCalls_File__File(f))
}


func (t *UnixFileSystem) List_File__String1(f *File) *RefArray {
	return t.List0_File__String1(t.GetFileForSysCalls_File__File(f))
}


func (t *UnixFileSystem) CreateDirectory_File__Z(f *File) bool {
	return t.CreateDirectory0_File__Z(t.GetFileForSysCalls_File__File(f))
}


func (t *UnixFileSystem) Rename_File_File__Z(f1, f2 *File) bool {
	return t.Rename0_File_File__Z(t.GetFileForSysCalls_File__File(f1), t.GetFileForSysCalls_File__File(f2))
}


func (t *UnixFileSystem) SetLastModifiedTime_File_J__Z(f *File, time int64) bool {
	return t.SetLastModifiedTime0_File_J__Z(t.GetFileForSysCalls_File__File(f), time)
}


func (t *UnixFileSystem) SetReadOnly_File__Z(f *File) bool {
	return t.SetReadOnly0_File__Z(t.GetFileForSysCalls_File__File(f))
}


func (t *UnixFileSystem) ListRoots__File1() *RefArray { return RefArrayOf(File_class, File_New_String(Lit_68)) }

func (t *UnixFileSystem) GetSpace_File_I__J(f *File, t_ int32) int64 {
	return t.GetSpace0_File_I__J(t.GetFileForSysCalls_File__File(f), t_)
}




func (t *UnixFileSystem) GetNameMax_String__I(path *String) int32 {
	var nameMax int64 = t.GetNameMax0_String__J(t.GetPathForSysCalls_String__String(path))
	if nameMax > 2147483647 { nameMax = 2147483647 }
	return int32(nameMax)
}
func (t *UnixFileSystem) Compare_File_File__I(f1, f2 *File) int32 {
	return NN(NN(f1).GetPath__String()).CompareTo_String__I(NN(f2).GetPath__String())
}
func (t *UnixFileSystem) HashCode_File__I(f *File) int32 {
	return NN(NN(f).GetPath__String()).HashCode__I() ^ 1234321
}


type UnixFileSystem struct{ FileSystem; F_slash, F_colon uint16; F_userDir *String }

func (t *UnixFileSystem) Ref() any { if t == nil { return nil }; return t }

func (t *UnixFileSystem) GetClass__Class() *Class { return UnixFileSystem_class }

func (t *UnixFileSystem) ToString__String() *String { return Object_toString(t) }

func (t *UnixFileSystem) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UnixFileSystem) CloneShallow() any { panic(CloneNotSupported(t)) }

func UnixFileSystem_InstanceOf(x any) bool { _, ok := x.(*UnixFileSystem); return ok }

func UnixFileSystem_Cast(x any) *UnixFileSystem { if x == nil { return nil }; v, ok := x.(*UnixFileSystem); if !ok { panic(ClassCast(x, UnixFileSystem_class)) }; return v }
