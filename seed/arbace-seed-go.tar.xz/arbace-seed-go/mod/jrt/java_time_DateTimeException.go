//line java_time_DateTimeException.ae:1
package jrt








func DateTimeException_New_String(p0 *String) *DateTimeException { t := &DateTimeException{}; t.Ctor_String(t, p0); return t }
//line :10:1
func (t *DateTimeException) Ctor_String(this DateTimeException_I, message *String) { t.RuntimeException.Ctor_String(this, message) }

func DateTimeException_New_String_Throwable(p0 *String, p1 Throwable_I) *DateTimeException { t := &DateTimeException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :12:1
func (t *DateTimeException) Ctor_String_Throwable(this DateTimeException_I, message *String, cause Throwable_I) { t.RuntimeException.Ctor_String_Throwable(this, message, cause) }







type DateTimeException struct{ RuntimeException }

type DateTimeException_I interface{ RuntimeException_I; Serializable; Self_DateTimeException() *DateTimeException }

func (t *DateTimeException) Self_DateTimeException() *DateTimeException { return t }

const DateTimeException_serialVersionUID int64 = -1632418723876261839

func (t *DateTimeException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *DateTimeException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *DateTimeException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *DateTimeException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *DateTimeException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *DateTimeException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *DateTimeException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *DateTimeException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *DateTimeException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *DateTimeException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *DateTimeException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *DateTimeException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DateTimeException) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeException) GetClass__Class() *Class { return DateTimeException_class }

func (t *DateTimeException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeException) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeException_InstanceOf(x any) bool { _, ok := x.(DateTimeException_I); return ok }

func DateTimeException_Cast(x any) DateTimeException_I { if x == nil { return nil }; v, ok := x.(DateTimeException_I); if !ok { panic(ClassCast(x, DateTimeException_class)) }; return v }
