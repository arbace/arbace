//line java_util_IdentityHashMap.ae:1
package jrt































func IdentityHashMap_MaskNull_O__O(key any) any { IdentityHashMap_Init(); if key == nil { return IdentityHashMap_NULL_KEY } else { return key } }

func IdentityHashMap_UnmaskNull_O__O(key any) any { IdentityHashMap_Init()
	if key == IdentityHashMap_NULL_KEY { return nil } else { return key
	} }
func IdentityHashMap_New() *IdentityHashMap { IdentityHashMap_Init(); t := &IdentityHashMap{}; t.Ctor(); return t }
//line :38:1
func (t *IdentityHashMap) Ctor() { t.AbstractMap.Ctor(t); t.Init_I__V(32) }

func IdentityHashMap_New_I(p0 int32) *IdentityHashMap { IdentityHashMap_Init(); t := &IdentityHashMap{}; t.Ctor_I(p0); return t }
//line :40:1
func (t *IdentityHashMap) Ctor_I(expectedMaxSize int32) { t.AbstractMap.Ctor(t)
	if expectedMaxSize < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2723, StrOfInt(expectedMaxSize))))) }
	t.Init_I__V(IdentityHashMap_Capacity_I__I(expectedMaxSize))
}
func IdentityHashMap_Capacity_I__I(expectedMaxSize int32) int32 {
	if expectedMaxSize > 178956970 { return 536870912 } else { if expectedMaxSize <= 2 { return 4 } else {




		return Integer_HighestOneBit_I__I(expectedMaxSize + expectedMaxSize<<1)
	}
	} }
func (t *IdentityHashMap) Init_I__V(initCapacity int32) {
	t.F_table = NewRefArray(Object_class, 2*initCapacity)
}
func IdentityHashMap_New_Map(p0 Map) *IdentityHashMap { IdentityHashMap_Init(); t := &IdentityHashMap{}; t.Ctor_Map(p0); return t }
//line :57:1
func (t *IdentityHashMap) Ctor_Map(m Map) { t.Ctor_I(D2I(float64(float64(1+m.Size__I()) * 1.1)))

	t.PutAll_Map__V(m)
}
func (t *IdentityHashMap) Size__I() int32 { return t.F_size }

func (t *IdentityHashMap) IsEmpty__Z() bool { return t.F_size == 0 }

func IdentityHashMap_Hash_O_I__I(x any, length int32) int32 {
	var h int32 = System_IdentityHashCode_O__I(x)
	return (h<<1 - h<<8) & (length - 1)
}

func IdentityHashMap_NextKeyIndex_I_I__I(i, len_ int32) int32 {
	if i+2 < len_ { return i + 2 } else { return 0
	} }
func (t *IdentityHashMap) Get_O__O(key any) any {
	{ var k any = IdentityHashMap_MaskNull_O__O(key); var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var i int32 = IdentityHashMap_Hash_O_I__I(k, len_)



	L1: for {
		var item any = tab.A[i]
		if item == k { return tab.A[i+1] }
		if item == nil { return nil }
		i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_)
//line :78:1
		continue L1
	}
	}

	panic("a2g: unreachable")
}
func (t *IdentityHashMap) ContainsKey_O__Z(key any) bool {
	{ var k any = IdentityHashMap_MaskNull_O__O(key); var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var i int32 = IdentityHashMap_Hash_O_I__I(k, len_)



	L1: for {
		var item any = tab.A[i]
		if item == k { return true }
		if item == nil { return false }
		i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_)
//line :89:1
		continue L1
	}
	}

	panic("a2g: unreachable")
}
func (t *IdentityHashMap) ContainsValue_O__Z(value any) bool {
	var tab *RefArray = t.F_table; var i int32 = 1
L1: for {
	if i < int32(len(tab.A)) {
		var tmp1 bool; var tmp2 bool; tmp2 = tab.A[i] == value; if tmp2 {
			tmp2 = !(tab.A[i-1] == nil) }
//line :99:1
		tmp1 = tmp2; if tmp1 {

			return true } else {
				i = i + 2; continue L1 } }
//line :97:1
	break L1 }
//line :96:1
	return false
}








func (t *IdentityHashMap) ContainsMapping_O_O__Z(key, value any) bool {
	{ var k any = IdentityHashMap_MaskNull_O__O(key); var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var i int32 = IdentityHashMap_Hash_O_I__I(k, len_)



	L1: for {
		var item any = tab.A[i]
		if item == k { return tab.A[i+1] == value }
		if item == nil { return false }
		i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_)
//line :111:1
		continue L1
	}
	}

	panic("a2g: unreachable")
}
func (t *IdentityHashMap) Put_O_O__O(key, value any) any {
	{ var k any = IdentityHashMap_MaskNull_O__O(key)
	L1: for {
		var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var i int32 = IdentityHashMap_Hash_O_I__I(k, len_); var item any



	L2: for { var tmp1 any; item = tab.A[i]; tmp1 = item; if !(tmp1 == nil) {
		if item == k {
			var oldValue any = tab.A[i+1]
			tab.Store(i+1, value)
			return oldValue }
		i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_)
//line :124:1
		continue L2 }; break L2
	}




		var s int32 = t.F_size + 1; var tmp2 bool; var tmp3 bool
		tmp3 = s+s<<1 > len_; if tmp3 {
			tmp3 = t.Resize_I__Z(len_) }
//line :131:1
		tmp2 = tmp3; if tmp2 { } else {

			t.F_modCount = t.F_modCount + 1
			tab.Store(i, k)
			tab.Store(i+1, value)
			t.F_size = s
			return nil }
//line :119:1
		continue L1
	}
	}










	panic("a2g: unreachable")
}





func (t *IdentityHashMap) Resize_I__Z(newCapacity int32) bool {
	var newLength int32 = newCapacity * 2; var oldTable *RefArray = t.F_table; var oldLength int32 = int32(len(oldTable.A))


	if oldLength == 1073741824 {


		if t.F_size == 536870911 {
			panic(Thrown(IllegalStateException_New_String(Lit_2724))) }
//line :145:1
		return false
	} else {
//line :143:1
		if oldLength >= newLength { return false } else {







			var newTable *RefArray = NewRefArray(Object_class, newLength); var j int32 = 0
		L1: for {
			if j < oldLength {
				var key any = oldTable.A[j]
				if !(key == nil) {
					var value any = oldTable.A[j+1]
					oldTable.Store(j, nil)
					oldTable.Store(j+1, nil)
					var i int32 = IdentityHashMap_Hash_O_I__I(key, newLength)
				L2: for { if !(newTable.A[i] == nil) {
					i = IdentityHashMap_NextKeyIndex_I_I__I(i, newLength)
//line :160:1
					continue L2 }; break L2
				}
					newTable.Store(i, key)
					newTable.Store(i+1, value)
					j = j + 2; continue L1 } else {
						j = j + 2; continue L1 } }
//line :152:1
			break L1
		}












			t.F_table = newTable
//line :151:1
			return true
		}
	}
}














func (t *IdentityHashMap) PutAll_Map__V(m Map) {
	var n int32 = m.Size__I()
	if n == 0 { } else {
		if n > t.F_size { t.Resize_I__Z(IdentityHashMap_Capacity_I__I(n)) }
		var i_101904 Iterator = m.EntrySet__Set().Iterator__Iterator(); for i_101904.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101904.Next__O())
			t.Put_O_O__O(e.GetKey__O(), e.GetValue__O())
		} } }
func (t *IdentityHashMap) Remove_O__O(key any) any {
	{ var k any = IdentityHashMap_MaskNull_O__O(key); var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var i int32 = IdentityHashMap_Hash_O_I__I(k, len_)



	L1: for {
		var item any = tab.A[i]
		if item == k {
			t.F_modCount = t.F_modCount + 1
			t.F_size = t.F_size - 1
			var oldValue any = tab.A[i+1]
			tab.Store(i+1, nil)
			tab.Store(i, nil)
			t.CloseDeletion_I__V(i)
			return oldValue }
		if item == nil { return nil }
		i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_)
//line :181:1
		continue L1
	}
	}








	panic("a2g: unreachable")
}
func (t *IdentityHashMap) RemoveMapping_O_O__Z(key, value any) bool {
	{ var k any = IdentityHashMap_MaskNull_O__O(key); var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var i int32 = IdentityHashMap_Hash_O_I__I(k, len_)



	L1: for {
		var item any = tab.A[i]
		if item == k {
			if tab.A[i+1] == value { } else { return false }
			t.F_modCount = t.F_modCount + 1
			t.F_size = t.F_size - 1
			tab.Store(i, nil)
			tab.Store(i+1, nil)
			t.CloseDeletion_I__V(i)
			return true }
		if item == nil { return false }
		i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_)
//line :199:1
		continue L1
	}
	}








	panic("a2g: unreachable")
}
func (t *IdentityHashMap) CloseDeletion_I__V(d int32) {
	var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var item any; var i int32 = IdentityHashMap_NextKeyIndex_I_I__I(d, len_)


L1: for {
	var tmp1 any; item = tab.A[i]; tmp1 = item; if !(tmp1 == nil) {
		var r int32 = IdentityHashMap_Hash_O_I__I(item, len_); var tmp2 bool; var tmp3 bool; var tmp4 bool
		tmp4 = i < r; if tmp4 { var tmp5 bool; tmp5 = r <= d; if !tmp5 { tmp5 = d <= i }; tmp4 = tmp5 }; tmp3 = tmp4; if !tmp3 { var tmp6 bool; tmp6 = r <= d; if tmp6 { tmp6 = d <= i }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 {

			tab.Store(d, item)
			tab.Store(d+1, tab.A[i+1])
			tab.Store(i, nil)
			tab.Store(i+1, nil)
			d = i
			i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_); continue L1 } else {
				i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_); continue L1 } }
//line :216:1
	break L1
}
}










func (t *IdentityHashMap) Clear__V() {
	t.F_modCount = t.F_modCount + 1
	var tab *RefArray = t.F_table; var i int32 = 0
L1: for { if i < int32(len(tab.A)) { tab.Store(i, nil); i = i + 1; continue L1 }; break L1 }
	t.F_size = 0
}
func (t *IdentityHashMap) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else {

		var tmp1 any = o; if IdentityHashMap_InstanceOf(tmp1) { var m *IdentityHashMap = IdentityHashMap_Cast(tmp1)
			if !(NN(m).Size__I() == t.F_size) { return false } else {

				var tab *RefArray = m.F_table; var i int32 = 0
			L1: for {
				if i < int32(len(tab.A)) {
					var k any = tab.A[i]; var tmp2 bool; var tmp3 bool
					tmp3 = !(k == nil); if tmp3 {
						tmp3 = !t.ContainsMapping_O_O__Z(k, tab.A[i+1]) }
//line :245:1
					tmp2 = tmp3; if tmp2 {

						return false } else {
							i = i + 2; continue L1 } }
//line :242:1
				break L1 }
//line :241:1
				return true
			}


		} else {




			var tmp4 any = o; if Map_InstanceOf(tmp4) { var m_2 Map = Map_Cast(tmp4); return t.EntrySet__Set().Equals_O__Z(m_2.EntrySet__Set()) } else { return false
			} } } }
func (t *IdentityHashMap) HashCode__I() int32 {
	var result int32 = 0; var tab *RefArray = t.F_table
	var i int32 = 0
L1: for {
	if i < int32(len(tab.A)) {
		var key any = tab.A[i]
		if !(key == nil) {
			var k any = IdentityHashMap_UnmaskNull_O__O(key)
			result = result + (System_IdentityHashCode_O__I(k) ^ System_IdentityHashCode_O__I(tab.A[i+1]))





			i = i + 2; continue L1 } else {
				i = i + 2; continue L1 } }
//line :255:1
	break L1 }
//line :253:1
	return result
}















func (t *IdentityHashMap) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var m *IdentityHashMap = IdentityHashMap_Cast(t.AbstractMap.Impl_Clone__O(t))
			m.F_entrySet = nil
			m.F_table = NN(t.F_table).Copy()
//line :272:1
			tmp1 = m.Ref()
		}
		return nil }()
//line :271:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)




		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :271:1
			panic(tmp2) } }; return tmp1
}



















func (t *IdentityHashMap_IdentityHashMapIterator) Impl_HasNext__Z(this IdentityHashMap_IdentityHashMapIterator_I) bool {
	var tab *RefArray = t.F_traversalTable; var i int32 = t.F_index
L1: for {
	if i < int32(len(tab.A)) {
		var key any = tab.A[i]
		if !(key == nil) {
			t.F_index = i; var tmp1 bool; var tmp2 bool = true; t.F_indexValid = tmp2; tmp1 = tmp2; return tmp1 } else {
				i = i + 2; continue L1 } }
//line :294:1
	break L1
}




	t.F_index = int32(len(tab.A))
//line :293:1
	return false
}








func (t *IdentityHashMap_IdentityHashMapIterator) Impl_NextIndex__I(this IdentityHashMap_IdentityHashMapIterator_I) int32 {
	if t.F_this_0.F_modCount == t.F_expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_indexValid; if tmp2 { tmp2 = !this.HasNext__Z() }; tmp1 = tmp2; if tmp1 { panic(Thrown(NoSuchElementException_New())) }
	t.F_indexValid = false
	t.F_lastReturnedIndex = t.F_index
	t.F_index = t.F_index + 2
//line :303:1
	return t.F_lastReturnedIndex
}






func (t *IdentityHashMap_IdentityHashMapIterator) Impl_Remove__V(this IdentityHashMap_IdentityHashMapIterator_I) {
	if t.F_lastReturnedIndex == -1 { panic(Thrown(IllegalStateException_New())) }
	if t.F_this_0.F_modCount == t.F_expectedModCount { } else { panic(Thrown(ConcurrentModificationException_New())) }
	var tmp1 int32; var tmp2 int32 = t.F_this_0.F_modCount + 1; t.F_this_0.F_modCount = tmp2; tmp1 = tmp2; t.F_expectedModCount = tmp1
	var deletedSlot int32 = t.F_lastReturnedIndex
	t.F_lastReturnedIndex = -1
	t.F_index = deletedSlot
	t.F_indexValid = false
	var tab *RefArray = t.F_traversalTable; var len_ int32 = int32(len(tab.A)); var d int32 = deletedSlot; var key any = tab.A[d]



	tab.Store(d, nil)
	tab.Store(d+1, nil)
	if !(tab == t.F_this_0.F_table) {
		NN(t.F_this_0).Remove_O__O(key); t.F_expectedModCount = t.F_this_0.F_modCount } else {

			t.F_this_0.F_size = t.F_this_0.F_size - 1
			var item any; var i int32 = IdentityHashMap_NextKeyIndex_I_I__I(d, len_)
		L1: for {
			var tmp3 any; item = tab.A[i]; tmp3 = item; if !(tmp3 == nil) {
				var r int32 = IdentityHashMap_Hash_O_I__I(item, len_); var tmp4 bool; var tmp5 bool; var tmp6 bool
				tmp6 = i < r; if tmp6 { var tmp7 bool; tmp7 = r <= d; if !tmp7 { tmp7 = d <= i }; tmp6 = tmp7 }; tmp5 = tmp6; if !tmp5 { var tmp8 bool; tmp8 = r <= d; if tmp8 { tmp8 = d <= i }; tmp5 = tmp8 }; tmp4 = tmp5; if tmp4 {

					var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = i < deletedSlot; if tmp11 { tmp11 = d >= deletedSlot }; tmp10 = tmp11; if tmp10 {
						tmp10 = t.F_traversalTable == t.F_this_0.F_table }
//line :335:1
					tmp9 = tmp10; if tmp9 {

						var remaining int32 = len_ - deletedSlot; var newTable *RefArray = NewRefArray(Object_class, remaining)

						System_Arraycopy_O_I_O_I_I__V(tab.Ref(), deletedSlot, newTable.Ref(), 0, remaining)
						t.F_traversalTable = newTable
						t.F_index = 0 }
					tab.Store(d, item)
					tab.Store(d+1, tab.A[i+1])
					tab.Store(i, nil)
					tab.Store(i+1, nil)
					d = i
					i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_); continue L1 } else {
						i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_); continue L1 } }
//line :330:1
			break L1
		}
		}
}



















func (t *IdentityHashMap_KeyIterator) Next__O() any {
	var tmp1 *RefArray = t.F_traversalTable; return IdentityHashMap_UnmaskNull_O__O(tmp1.A[t.NextIndex__I()])
}



func (t *IdentityHashMap_ValueIterator) Next__O() any {
	var tmp1 *RefArray = t.F_traversalTable; return tmp1.A[t.NextIndex__I()+1]
}





func (t *IdentityHashMap_EntryIterator) Next__Map_Entry() Map_Entry {
	t.F_lastReturnedEntry = IdentityHashMap_EntryIterator_Entry_New_IdentityHashMap_EntryIterator_I(t, t.NextIndex__I())
//line :367:1
	return Up_IdentityHashMap_EntryIterator_Entry_Map_Entry(t.F_lastReturnedEntry)
}


func (t *IdentityHashMap_EntryIterator) Remove__V() {
	var tmp1 int32; if t.F_lastReturnedEntry == nil { tmp1 = -1 } else { tmp1 = t.F_lastReturnedEntry.F_index }; t.F_lastReturnedIndex = tmp1
	t.IdentityHashMap_IdentityHashMapIterator.Impl_Remove__V(t)
	t.F_lastReturnedEntry.F_index = t.F_lastReturnedIndex
	t.F_lastReturnedEntry = nil
}





func IdentityHashMap_EntryIterator_Entry_New_IdentityHashMap_EntryIterator_I(p0 *IdentityHashMap_EntryIterator, p1 int32) *IdentityHashMap_EntryIterator_Entry { t := &IdentityHashMap_EntryIterator_Entry{}; t.Ctor_IdentityHashMap_EntryIterator_I(p0, p1); return t }
//line :382:1
func (t *IdentityHashMap_EntryIterator_Entry) Ctor_IdentityHashMap_EntryIterator_I(this_0 *IdentityHashMap_EntryIterator, index int32) { NN(this_0); t.F_this_1 = this_0; t.F_index = index }

func (t *IdentityHashMap_EntryIterator_Entry) GetKey__O() any {
	t.CheckIndexForEntryUse__V()
	return IdentityHashMap_UnmaskNull_O__O(t.F_this_1.F_traversalTable.A[t.F_index])
}
func (t *IdentityHashMap_EntryIterator_Entry) GetValue__O() any {
	t.CheckIndexForEntryUse__V()
	return t.F_this_1.F_traversalTable.A[t.F_index+1]
}
func (t *IdentityHashMap_EntryIterator_Entry) SetValue_O__O(value any) any {
	t.CheckIndexForEntryUse__V()
	var oldValue any = t.F_this_1.F_traversalTable.A[t.F_index+1]
	t.F_this_1.F_traversalTable.Store(t.F_index+1, value)
	if t.F_this_1.F_traversalTable == t.F_this_1.F_this_0.F_table { } else {

		NN(t.F_this_1.F_this_0).Put_O_O__O(t.F_this_1.F_traversalTable.A[t.F_index], value) }
//line :394:1
	return oldValue
}





func (t *IdentityHashMap_EntryIterator_Entry) Equals_O__Z(o any) bool {
	if t.F_index < 0 {
		return t == o } else {
			var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1)
				if e.GetKey__O() == IdentityHashMap_UnmaskNull_O__O(t.F_this_1.F_traversalTable.A[t.F_index]) {


					return e.GetValue__O() == t.F_this_1.F_traversalTable.A[t.F_index+1] } else {
//line :405:1
						return false
					}
			} else {
//line :404:1
				return false
			}
		}
}






func (t *IdentityHashMap_EntryIterator_Entry) HashCode__I() int32 {
	if t.F_this_1.F_lastReturnedIndex < 0 {
		return IdentityHash(t) } else {
			return System_IdentityHashCode_O__I(IdentityHashMap_UnmaskNull_O__O(t.F_this_1.F_traversalTable.A[t.F_index])) ^ System_IdentityHashCode_O__I(t.F_this_1.F_traversalTable.A[t.F_index+1])
		}
}



func (t *IdentityHashMap_EntryIterator_Entry) ToString__String() *String {
	if t.F_index < 0 {
		return Object_toString(t) } else {
			return Concat(StrOfObj(IdentityHashMap_UnmaskNull_O__O(t.F_this_1.F_traversalTable.A[t.F_index])), Lit_1171, StrOfObj(t.F_this_1.F_traversalTable.A[t.F_index+1]))
		}
}


func (t *IdentityHashMap_EntryIterator_Entry) CheckIndexForEntryUse__V() {
	if t.F_index < 0 { panic(Thrown(IllegalStateException_New_String(Lit_2670)))
	}
}

func (t *IdentityHashMap) KeySet__Set() Set {
	var ks Set = t.F_keySet
	if ks == nil { ks = IdentityHashMap_KeySet_New_IdentityHashMap(t); t.F_keySet = ks }
//line :437:1
	return ks
}





func (t *IdentityHashMap_KeySet) Iterator__Iterator() Iterator { return IdentityHashMap_KeyIterator_New_IdentityHashMap(t.F_this_0) }

func (t *IdentityHashMap_KeySet) Size__I() int32 { return t.F_this_0.F_size }

func (t *IdentityHashMap_KeySet) Contains_O__Z(o any) bool {
	return NN(t.F_this_0).ContainsKey_O__Z(o)
}
func (t *IdentityHashMap_KeySet) Remove_O__Z(o any) bool {
	var oldSize int32 = t.F_this_0.F_size; NN(t.F_this_0).Remove_O__O(o); return !(t.F_this_0.F_size == oldSize)
}
func (t *IdentityHashMap_KeySet) RemoveAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var i Iterator = t.Iterator__Iterator()
L1: for {
	if i.HasNext__Z() {
		if c.Contains_O__Z(i.Next__O()) { i.Remove__V(); modified = true; i = i; continue L1 } else { i = i; continue L1 } }
//line :457:1
	break L1 }
//line :456:1
	return modified
}





func (t *IdentityHashMap_KeySet) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *IdentityHashMap_KeySet) HashCode__I() int32 {
	var result int32 = 0; var i_101908 Iterator = t.Iterator__Iterator(); for i_101908.HasNext__Z() {
		var key any = i_101908.Next__O(); result = result + System_IdentityHashCode_O__I(key) }
//line :466:1
	return result
}


func (t *IdentityHashMap_KeySet) ToArray__O1() *RefArray {
	return t.ToArray_O1__O1(NewRefArray(Object_class, 0))
}
func (t *IdentityHashMap_KeySet) ToArray_O1__O1(a *RefArray) *RefArray {
	var expectedModCount int32 = t.F_this_0.F_modCount; var size int32 = t.Size__I()

	if int32(len(a.A)) < size {
		a = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass()) }
	var tab *RefArray = t.F_this_0.F_table
	var ti int32 = 0; var si int32 = 0
L1: for {
	if si < int32(len(tab.A)) {
		var key any; var tmp1 any
		key = tab.A[si]; tmp1 = key; if !(tmp1 == nil) {

			if ti >= size { panic(Thrown(ConcurrentModificationException_New())) }
			a.Store(ti, IdentityHashMap_UnmaskNull_O__O(key))
			ti = ti + 1
			si = si + 2; continue L1 } else {
				si = si + 2; continue L1 } }
//line :480:1
	break L1
}








	var tmp2 bool; var tmp3 bool; tmp3 = ti < size; if !tmp3 { tmp3 = !(expectedModCount == t.F_this_0.F_modCount) }; tmp2 = tmp3; if tmp2 {
		panic(Thrown(ConcurrentModificationException_New())) }
	if ti < int32(len(a.A)) { a.Store(ti, nil) }
//line :478:1
	return a
}















func (t *IdentityHashMap_KeySet) Spliterator__Spliterator() Spliterator {
	return IdentityHashMap_KeySpliterator_New_IdentityHashMap_I_I_I_I(t.F_this_0, 0, -1, 0, 0)
}
func (t *IdentityHashMap) Values__Collection() Collection {
	var vs Collection = t.F_values
	if vs == nil { vs = IdentityHashMap_Values_New_IdentityHashMap(t); t.F_values = vs }
//line :499:1
	return vs
}





func (t *IdentityHashMap_Values) Iterator__Iterator() Iterator { return IdentityHashMap_ValueIterator_New_IdentityHashMap(t.F_this_0) }

func (t *IdentityHashMap_Values) Size__I() int32 { return t.F_this_0.F_size }

func (t *IdentityHashMap_Values) Contains_O__Z(o any) bool {
	return NN(t.F_this_0).ContainsValue_O__Z(o)
}
func (t *IdentityHashMap_Values) Remove_O__Z(o any) bool {
	var i Iterator = t.Iterator__Iterator(); L1: for {
		if i.HasNext__Z() { if i.Next__O() == o { i.Remove__V(); return true } else { i = i; continue L1 } }
//line :514:1
		break L1 }
//line :513:1
	return false
}



func (t *IdentityHashMap_Values) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *IdentityHashMap_Values) ToArray__O1() *RefArray {
	return t.ToArray_O1__O1(NewRefArray(Object_class, 0))
}
func (t *IdentityHashMap_Values) ToArray_O1__O1(a *RefArray) *RefArray {
	var expectedModCount int32 = t.F_this_0.F_modCount; var size int32 = t.Size__I()

	if int32(len(a.A)) < size {
		a = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass()) }
	var tab *RefArray = t.F_this_0.F_table
	var ti int32 = 0; var si int32 = 0
L1: for {
	if si < int32(len(tab.A)) {
		if !(tab.A[si] == nil) {

			if ti >= size { panic(Thrown(ConcurrentModificationException_New())) }
			a.Store(ti, tab.A[si+1])
			ti = ti + 1
			si = si + 2; continue L1 } else {
				si = si + 2; continue L1 } }
//line :530:1
	break L1
}








	var tmp1 bool; var tmp2 bool; tmp2 = ti < size; if !tmp2 { tmp2 = !(expectedModCount == t.F_this_0.F_modCount) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(ConcurrentModificationException_New())) }
	if ti < int32(len(a.A)) { a.Store(ti, nil) }
//line :528:1
	return a
}















func (t *IdentityHashMap_Values) Spliterator__Spliterator() Spliterator {
	return IdentityHashMap_ValueSpliterator_New_IdentityHashMap_I_I_I_I(t.F_this_0, 0, -1, 0, 0)
}
func (t *IdentityHashMap) EntrySet__Set() Set {
	var es Set = t.F_entrySet; if !(es == nil) { return es } else { var tmp1 Set = IdentityHashMap_EntrySet_New_IdentityHashMap(t); t.F_entrySet = tmp1; return tmp1
	}
}


func (t *IdentityHashMap_EntrySet) Iterator__Iterator() Iterator {
	return IdentityHashMap_EntryIterator_New_IdentityHashMap(t.F_this_0)
}
func (t *IdentityHashMap_EntrySet) Contains_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var entry Map_Entry = Map_Entry_Cast(tmp1)
		return NN(t.F_this_0).ContainsMapping_O_O__Z(entry.GetKey__O(), entry.GetValue__O()) } else {
//line :558:1
			return false
		}
}

func (t *IdentityHashMap_EntrySet) Remove_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var entry Map_Entry = Map_Entry_Cast(tmp1)
		return NN(t.F_this_0).RemoveMapping_O_O__Z(entry.GetKey__O(), entry.GetValue__O()) } else {
//line :563:1
			return false
		}
}

func (t *IdentityHashMap_EntrySet) Size__I() int32 { return t.F_this_0.F_size }

func (t *IdentityHashMap_EntrySet) Clear__V() { NN(t.F_this_0).Clear__V() }

func (t *IdentityHashMap_EntrySet) RemoveAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var i Iterator = t.Iterator__Iterator()
L1: for {
	if i.HasNext__Z() {
		if c.Contains_O__Z(i.Next__O()) { i.Remove__V(); modified = true; i = i; continue L1 } else { i = i; continue L1 } }
//line :574:1
	break L1 }
//line :573:1
	return modified
}





func (t *IdentityHashMap_EntrySet) ToArray__O1() *RefArray {
	return t.ToArray_O1__O1(NewRefArray(Object_class, 0))
}
func (t *IdentityHashMap_EntrySet) ToArray_O1__O1(a *RefArray) *RefArray {
	var expectedModCount int32 = t.F_this_0.F_modCount; var size int32 = t.Size__I()

	if int32(len(a.A)) < size {
		a = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass()) }
	var tab *RefArray = t.F_this_0.F_table
	var ti int32 = 0; var si int32 = 0
L1: for {
	if si < int32(len(tab.A)) {
		var key any; var tmp1 any
		key = tab.A[si]; tmp1 = key; if !(tmp1 == nil) {

			if ti >= size { panic(Thrown(ConcurrentModificationException_New())) }
			a.Store(ti, AbstractMap_SimpleEntry_New_O_O(IdentityHashMap_UnmaskNull_O__O(key), tab.A[si+1]))




			ti = ti + 1
			si = si + 2; continue L1 } else {
				si = si + 2; continue L1 } }
//line :590:1
	break L1
}












	var tmp2 bool; var tmp3 bool; tmp3 = ti < size; if !tmp3 { tmp3 = !(expectedModCount == t.F_this_0.F_modCount) }; tmp2 = tmp3; if tmp2 {
		panic(Thrown(ConcurrentModificationException_New())) }
	if ti < int32(len(a.A)) { a.Store(ti, nil) }
//line :588:1
	return a
}



















func (t *IdentityHashMap_EntrySet) Spliterator__Spliterator() Spliterator {
	return IdentityHashMap_EntrySpliterator_New_IdentityHashMap_I_I_I_I(t.F_this_0, 0, -1, 0, 0)
}




































func (t *IdentityHashMap) PutForCreate_O_O__V(p0, p1 any) { panic(A2g_NotTranslated("java.util.IdentityHashMap.putForCreate(Ljava/lang/Object;Ljava/lang/Object;)V")) }











func (t *IdentityHashMap) ForEach_BiConsumer__V(action BiConsumer) {
	Objects_RequireNonNull_O__O(action)
	var expectedModCount int32 = t.F_modCount; var t_ *RefArray = t.F_table
	var index int32 = 0
L1: for {
	if index < int32(len(t_.A)) {
		var k any = t_.A[index]
		if !(k == nil) {
			action.Accept_O_O__V(IdentityHashMap_UnmaskNull_O__O(k), t_.A[index+1]) }
		if !(t.F_modCount == expectedModCount) {
			panic(Thrown(ConcurrentModificationException_New())) } else {
				index = index + 2; continue L1 } }
//line :664:1
	break L1
}
}






func (t *IdentityHashMap) ReplaceAll_BiFunction__V(function BiFunction) {

	Objects_RequireNonNull_O__O(function)
	var expectedModCount int32 = t.F_modCount; var t_ *RefArray = t.F_table
	var index int32 = 0
L1: for {
	if index < int32(len(t_.A)) {
		var k any = t_.A[index]
		if !(k == nil) {
			t_.Store(index+1, function.Apply_O_O__O(IdentityHashMap_UnmaskNull_O__O(k), t_.A[index+1]))
		}



		if !(t.F_modCount == expectedModCount) {
			panic(Thrown(ConcurrentModificationException_New())) } else {
				index = index + 2; continue L1 } }
//line :678:1
	break L1
}
}










func (t *IdentityHashMap) Remove_O_O__Z(key, value any) bool {
	return t.RemoveMapping_O_O__Z(key, value)
}
func (t *IdentityHashMap) Replace_O_O_O__Z(key, oldValue, newValue any) bool {
	{ var k any = IdentityHashMap_MaskNull_O__O(key); var tab *RefArray = t.F_table; var len_ int32 = int32(len(tab.A)); var i int32 = IdentityHashMap_Hash_O_I__I(k, len_)



	L1: for {
		var item any = tab.A[i]
		if item == k {
			if tab.A[i+1] == oldValue { } else { return false }
			tab.Store(i+1, newValue)
			return true }
		if item == nil { return false }
		i = IdentityHashMap_NextKeyIndex_I_I__I(i, len_)
//line :699:1
		continue L1
	}
	}




	panic("a2g: unreachable")
}













func IdentityHashMap_IdentityHashMapSpliterator_New_IdentityHashMap_I_I_I_I(p0 *IdentityHashMap, p1, p2, p3, p4 int32) *IdentityHashMap_IdentityHashMapSpliterator { t := &IdentityHashMap_IdentityHashMapSpliterator{}; t.Ctor_IdentityHashMap_I_I_I_I(t, p0, p1, p2, p3, p4); return t }
//line :721:1
func (t *IdentityHashMap_IdentityHashMapSpliterator) Ctor_IdentityHashMap_I_I_I_I(this IdentityHashMap_IdentityHashMapSpliterator_I, map_ *IdentityHashMap, origin, fence, est, expectedModCount int32) {

	t.F_map = map_
	t.F_index = origin
	t.F_fence = fence
	t.F_est = est
	t.F_expectedModCount = expectedModCount
}
func (t *IdentityHashMap_IdentityHashMapSpliterator) Impl_GetFence__I(this IdentityHashMap_IdentityHashMapSpliterator_I) int32 {
	var hi int32 = 0; var tmp1 int32
	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {
		t.F_est = t.F_map.F_size
		t.F_expectedModCount = t.F_map.F_modCount
		var tmp2 int32; var tmp3 int32 = int32(len(t.F_map.F_table.A)); t.F_fence = tmp3; tmp2 = tmp3; hi = tmp2 }
//line :730:1
	return hi
}





func (t *IdentityHashMap_IdentityHashMapSpliterator) Impl_EstimateSize__J(this IdentityHashMap_IdentityHashMapSpliterator_I) int64 {
	this.GetFence__I()
	return int64(t.F_est)
}





func IdentityHashMap_KeySpliterator_New_IdentityHashMap_I_I_I_I(p0 *IdentityHashMap, p1, p2, p3, p4 int32) *IdentityHashMap_KeySpliterator { t := &IdentityHashMap_KeySpliterator{}; t.Ctor_IdentityHashMap_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :746:1
func (t *IdentityHashMap_KeySpliterator) Ctor_IdentityHashMap_I_I_I_I(map_ *IdentityHashMap, origin, fence, est, expectedModCount int32) { t.IdentityHashMap_IdentityHashMapSpliterator.Ctor_IdentityHashMap_I_I_I_I(t, map_, origin, fence, est, expectedModCount) }



func (t *IdentityHashMap_KeySpliterator) TrySplit__IdentityHashMap_KeySpliterator() *IdentityHashMap_KeySpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi)>>1) & -2



	if lo >= mid { return nil } else {
		var tmp1 *IdentityHashMap = t.F_map; var tmp2 int32
		var tmp3 int32 = mid
		t.F_index = tmp3; tmp2 = tmp3
//line :756:1
		var tmp4 int32 = tmp2; var tmp5 int32; var tmp6 int32 = int32(uint32(t.F_est) >> 1)


		t.F_est = tmp6; tmp5 = tmp6
//line :756:1
		return IdentityHashMap_KeySpliterator_New_IdentityHashMap_I_I_I_I(tmp1, lo, tmp4, tmp5, t.F_expectedModCount)
	}
}



func (t *IdentityHashMap_KeySpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var i int32 = 0; var hi int32 = 0; var mc int32 = 0; var key any; var m *IdentityHashMap; var a *RefArray; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 *IdentityHashMap; _ = mc





	m = t.F_map; tmp5 = m; tmp4 = !(tmp5 == nil); if tmp4 { var tmp6 *RefArray; a = m.F_table; tmp6 = a; tmp4 = !(tmp6 == nil) }; tmp3 = tmp4; if tmp3 {
		var tmp7 int32; i = t.F_index; tmp7 = i; tmp3 = tmp7 >= 0 }
//line :770:1
	tmp2 = tmp3; if tmp2 {

		var tmp8 int32; var tmp9 int32; hi = t.GetFence__I(); tmp9 = hi; var tmp10 int32 = tmp9; t.F_index = tmp10; tmp8 = tmp10; tmp2 = tmp8 <= int32(len(a.A)) }
//line :770:1
	tmp1 = tmp2; if tmp1 {


	L1: for { if i < hi {
		var tmp11 any; key = a.A[i]; tmp11 = key; if !(tmp11 == nil) { action.Accept_O__V(IdentityHashMap_UnmaskNull_O__O(key)) }
		i = i + 2
//line :773:1
		continue L1 }; break L1
	}

		if m.F_modCount == t.F_expectedModCount { return } }
	panic(Thrown(ConcurrentModificationException_New()))
}
func (t *IdentityHashMap_KeySpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var a *RefArray = t.F_map.F_table; var hi int32 = t.GetFence__I()

L1: for { if t.F_index < hi {
	var key any = a.A[t.F_index]
	t.F_index = t.F_index + 2
	if !(key == nil) {
		action.Accept_O__V(IdentityHashMap_UnmaskNull_O__O(key))
		if t.F_map.F_modCount == t.F_expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
		return true }
//line :783:1
	continue L1 }; break L1 }
//line :781:1
	return false
}










func (t *IdentityHashMap_KeySpliterator) Characteristics__I() int32 {
	var tmp1 int32; var tmp2 bool; var tmp3 bool; tmp3 = t.F_fence < 0; if !tmp3 { var tmp4 int32 = t.F_est; tmp3 = tmp4 == t.F_map.F_size }; tmp2 = tmp3; if tmp2 { tmp1 = 64 } else { tmp1 = 0 }; return tmp1 | 1
}








func IdentityHashMap_ValueSpliterator_New_IdentityHashMap_I_I_I_I(p0 *IdentityHashMap, p1, p2, p3, p4 int32) *IdentityHashMap_ValueSpliterator { t := &IdentityHashMap_ValueSpliterator{}; t.Ctor_IdentityHashMap_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :804:1
func (t *IdentityHashMap_ValueSpliterator) Ctor_IdentityHashMap_I_I_I_I(m *IdentityHashMap, origin, fence, est, expectedModCount int32) { t.IdentityHashMap_IdentityHashMapSpliterator.Ctor_IdentityHashMap_I_I_I_I(t, m, origin, fence, est, expectedModCount) }



func (t *IdentityHashMap_ValueSpliterator) TrySplit__IdentityHashMap_ValueSpliterator() *IdentityHashMap_ValueSpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi)>>1) & -2



	if lo >= mid { return nil } else {
		var tmp1 *IdentityHashMap = t.F_map; var tmp2 int32
		var tmp3 int32 = mid
		t.F_index = tmp3; tmp2 = tmp3
//line :814:1
		var tmp4 int32 = tmp2; var tmp5 int32; var tmp6 int32 = int32(uint32(t.F_est) >> 1)


		t.F_est = tmp6; tmp5 = tmp6
//line :814:1
		return IdentityHashMap_ValueSpliterator_New_IdentityHashMap_I_I_I_I(tmp1, lo, tmp4, tmp5, t.F_expectedModCount)
	}
}



func (t *IdentityHashMap_ValueSpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var i int32 = 0; var hi int32 = 0; var mc int32 = 0; var m *IdentityHashMap; var a *RefArray; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 *IdentityHashMap; _ = mc




	m = t.F_map; tmp5 = m; tmp4 = !(tmp5 == nil); if tmp4 { var tmp6 *RefArray; a = m.F_table; tmp6 = a; tmp4 = !(tmp6 == nil) }; tmp3 = tmp4; if tmp3 {
		var tmp7 int32; i = t.F_index; tmp7 = i; tmp3 = tmp7 >= 0 }
//line :827:1
	tmp2 = tmp3; if tmp2 {

		var tmp8 int32; var tmp9 int32; hi = t.GetFence__I(); tmp9 = hi; var tmp10 int32 = tmp9; t.F_index = tmp10; tmp8 = tmp10; tmp2 = tmp8 <= int32(len(a.A)) }
//line :827:1
	tmp1 = tmp2; if tmp1 {


	L1: for { if i < hi {
		if !(a.A[i] == nil) {
			var v any = a.A[i+1]; action.Accept_O__V(v) }
		i = i + 2
//line :830:1
		continue L1 }; break L1
	}


		if m.F_modCount == t.F_expectedModCount { return } }
	panic(Thrown(ConcurrentModificationException_New()))
}
func (t *IdentityHashMap_ValueSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var a *RefArray = t.F_map.F_table; var hi int32 = t.GetFence__I()

L1: for { if t.F_index < hi {
	var key any = a.A[t.F_index]; var v any = a.A[t.F_index+1]

	t.F_index = t.F_index + 2
	if !(key == nil) {
		action.Accept_O__V(v)
		if t.F_map.F_modCount == t.F_expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
		return true }
//line :841:1
	continue L1 }; break L1 }
//line :839:1
	return false
}











func (t *IdentityHashMap_ValueSpliterator) Characteristics__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_fence < 0; if !tmp2 { var tmp3 int32 = t.F_est; tmp2 = tmp3 == t.F_map.F_size }; tmp1 = tmp2; if tmp1 { return 64 } else { return 0
	}
}






func IdentityHashMap_EntrySpliterator_New_IdentityHashMap_I_I_I_I(p0 *IdentityHashMap, p1, p2, p3, p4 int32) *IdentityHashMap_EntrySpliterator { t := &IdentityHashMap_EntrySpliterator{}; t.Ctor_IdentityHashMap_I_I_I_I(p0, p1, p2, p3, p4); return t }
//line :862:1
func (t *IdentityHashMap_EntrySpliterator) Ctor_IdentityHashMap_I_I_I_I(m *IdentityHashMap, origin, fence, est, expectedModCount int32) { t.IdentityHashMap_IdentityHashMapSpliterator.Ctor_IdentityHashMap_I_I_I_I(t, m, origin, fence, est, expectedModCount) }



func (t *IdentityHashMap_EntrySpliterator) TrySplit__IdentityHashMap_EntrySpliterator() *IdentityHashMap_EntrySpliterator {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index; var mid int32 = int32(uint32(lo+hi)>>1) & -2



	if lo >= mid { return nil } else {
		var tmp1 *IdentityHashMap = t.F_map; var tmp2 int32
		var tmp3 int32 = mid
		t.F_index = tmp3; tmp2 = tmp3
//line :872:1
		var tmp4 int32 = tmp2; var tmp5 int32; var tmp6 int32 = int32(uint32(t.F_est) >> 1)


		t.F_est = tmp6; tmp5 = tmp6
//line :872:1
		return IdentityHashMap_EntrySpliterator_New_IdentityHashMap_I_I_I_I(tmp1, lo, tmp4, tmp5, t.F_expectedModCount)
	}
}



func (t *IdentityHashMap_EntrySpliterator) ForEachRemaining_Consumer__V(action Consumer) {

	if action == nil { panic(Thrown(NullPointerException_New())) }
	var i int32 = 0; var hi int32 = 0; var mc int32 = 0; var m *IdentityHashMap; var a *RefArray; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 *IdentityHashMap; _ = mc




	m = t.F_map; tmp5 = m; tmp4 = !(tmp5 == nil); if tmp4 { var tmp6 *RefArray; a = m.F_table; tmp6 = a; tmp4 = !(tmp6 == nil) }; tmp3 = tmp4; if tmp3 {
		var tmp7 int32; i = t.F_index; tmp7 = i; tmp3 = tmp7 >= 0 }
//line :886:1
	tmp2 = tmp3; if tmp2 {

		var tmp8 int32; var tmp9 int32; hi = t.GetFence__I(); tmp9 = hi; var tmp10 int32 = tmp9; t.F_index = tmp10; tmp8 = tmp10; tmp2 = tmp8 <= int32(len(a.A)) }
//line :886:1
	tmp1 = tmp2; if tmp1 {


	L1: for { if i < hi {
		var key any = a.A[i]
		if !(key == nil) {
			var k any = IdentityHashMap_UnmaskNull_O__O(key); var v any = a.A[i+1]

			action.Accept_O__V(AbstractMap_SimpleImmutableEntry_New_O_O(k, v)) }
		i = i + 2
//line :889:1
		continue L1 }; break L1
	}





		if m.F_modCount == t.F_expectedModCount { return } }
	panic(Thrown(ConcurrentModificationException_New()))
}
func (t *IdentityHashMap_EntrySpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var a *RefArray = t.F_map.F_table; var hi int32 = t.GetFence__I()

L1: for { if t.F_index < hi {
	var key any = a.A[t.F_index]; var v any = a.A[t.F_index+1]

	t.F_index = t.F_index + 2
	if !(key == nil) {
		var k any = IdentityHashMap_UnmaskNull_O__O(key)
		action.Accept_O__V(AbstractMap_SimpleImmutableEntry_New_O_O(k, v))
		if t.F_map.F_modCount == t.F_expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
		return true }
//line :903:1
	continue L1 }; break L1 }
//line :901:1
	return false
}












func (t *IdentityHashMap_EntrySpliterator) Characteristics__I() int32 {
	var tmp1 int32; var tmp2 bool; var tmp3 bool; tmp3 = t.F_fence < 0; if !tmp3 { var tmp4 int32 = t.F_est; tmp3 = tmp4 == t.F_map.F_size }; tmp2 = tmp3; if tmp2 { tmp1 = 64 } else { tmp1 = 0 }; return tmp1 | 1
}


type IdentityHashMap struct{ AbstractMap; F_table *RefArray; F_size, F_modCount int32; F_entrySet Set }

func (t *IdentityHashMap) Is_Serializable() {}

func (t *IdentityHashMap) Is_Cloneable() {}

const IdentityHashMap_DEFAULT_CAPACITY int32 = 32

const IdentityHashMap_MINIMUM_CAPACITY int32 = 4

const IdentityHashMap_MAXIMUM_CAPACITY int32 = 536870912

var IdentityHashMap_NULL_KEY any

const IdentityHashMap_serialVersionUID int64 = 8188218128353913216

var IdentityHashMap_init ClassInit

func IdentityHashMap_Init() { if !IdentityHashMap_init.Done() { IdentityHashMap_init.Run(IdentityHashMap_clinit) } }

func IdentityHashMap_clinit() { IdentityHashMap_NULL_KEY = Object_New() }

func (t *IdentityHashMap) Replace_O_O__O(p0, p1 any) any { return Map_Replace_O_O__O(t, p0, p1) }

func (t *IdentityHashMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *IdentityHashMap) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *IdentityHashMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *IdentityHashMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *IdentityHashMap) PutIfAbsent_O_O__O(p0, p1 any) any { return Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *IdentityHashMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *IdentityHashMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IdentityHashMap) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap) GetClass__Class() *Class { return IdentityHashMap_class }

func (t *IdentityHashMap) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func IdentityHashMap_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap); return ok }

func IdentityHashMap_Cast(x any) *IdentityHashMap { if x == nil { return nil }; v, ok := x.(*IdentityHashMap); if !ok { panic(ClassCast(x, IdentityHashMap_class)) }; return v }



type IdentityHashMap_EntryIterator struct{ IdentityHashMap_IdentityHashMapIterator; F_lastReturnedEntry *IdentityHashMap_EntryIterator_Entry; F_this_0 *IdentityHashMap }

func IdentityHashMap_EntryIterator_New_IdentityHashMap(p0 *IdentityHashMap) *IdentityHashMap_EntryIterator { t := &IdentityHashMap_EntryIterator{}; t.Ctor_IdentityHashMap(p0); return t }

func (t *IdentityHashMap_EntryIterator) Ctor_IdentityHashMap(this_0 *IdentityHashMap) { NN(this_0); t.F_this_0 = this_0; t.IdentityHashMap_IdentityHashMapIterator.Ctor_IdentityHashMap(t, this_0) }

func (t *IdentityHashMap_EntryIterator) Next__O() any { return t.Next__Map_Entry() }

func (t *IdentityHashMap_EntryIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *IdentityHashMap_EntryIterator) NextIndex__I() int32 { return t.Impl_NextIndex__I(t) }

func (t *IdentityHashMap_EntryIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *IdentityHashMap_EntryIterator) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_EntryIterator) GetClass__Class() *Class { return IdentityHashMap_EntryIterator_class }

func (t *IdentityHashMap_EntryIterator) ToString__String() *String { return Object_toString(t) }

func (t *IdentityHashMap_EntryIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_EntryIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_EntryIterator_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_EntryIterator); return ok }

func IdentityHashMap_EntryIterator_Cast(x any) *IdentityHashMap_EntryIterator { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_EntryIterator); if !ok { panic(ClassCast(x, IdentityHashMap_EntryIterator_class)) }; return v }



type IdentityHashMap_EntryIterator_Entry struct{ Object; F_index int32; F_this_1 *IdentityHashMap_EntryIterator }

func (t *IdentityHashMap_EntryIterator_Entry) Is_Map_Entry() {}

func (t *IdentityHashMap_EntryIterator_Entry) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_EntryIterator_Entry) GetClass__Class() *Class { return IdentityHashMap_EntryIterator_Entry_class }

func (t *IdentityHashMap_EntryIterator_Entry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_EntryIterator_Entry) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_EntryIterator_Entry_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_EntryIterator_Entry); return ok }

func IdentityHashMap_EntryIterator_Entry_Cast(x any) *IdentityHashMap_EntryIterator_Entry { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_EntryIterator_Entry); if !ok { panic(ClassCast(x, IdentityHashMap_EntryIterator_Entry_class)) }; return v }



type IdentityHashMap_EntrySet struct{ AbstractSet; F_this_0 *IdentityHashMap }

func IdentityHashMap_EntrySet_New_IdentityHashMap(p0 *IdentityHashMap) *IdentityHashMap_EntrySet { t := &IdentityHashMap_EntrySet{}; t.Ctor_IdentityHashMap(p0); return t }

func (t *IdentityHashMap_EntrySet) Ctor_IdentityHashMap(this_0 *IdentityHashMap) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *IdentityHashMap_EntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *IdentityHashMap_EntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *IdentityHashMap_EntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_EntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *IdentityHashMap_EntrySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_EntrySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *IdentityHashMap_EntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *IdentityHashMap_EntrySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *IdentityHashMap_EntrySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *IdentityHashMap_EntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_EntrySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *IdentityHashMap_EntrySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *IdentityHashMap_EntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IdentityHashMap_EntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_EntrySet) GetClass__Class() *Class { return IdentityHashMap_EntrySet_class }

func (t *IdentityHashMap_EntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_EntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_EntrySet_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_EntrySet); return ok }

func IdentityHashMap_EntrySet_Cast(x any) *IdentityHashMap_EntrySet { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_EntrySet); if !ok { panic(ClassCast(x, IdentityHashMap_EntrySet_class)) }; return v }



type IdentityHashMap_EntrySpliterator struct{ IdentityHashMap_IdentityHashMapSpliterator }

func (t *IdentityHashMap_EntrySpliterator) Is_Spliterator() {}

func (t *IdentityHashMap_EntrySpliterator) TrySplit__Spliterator() Spliterator { return Up_IdentityHashMap_EntrySpliterator_Spliterator(t.TrySplit__IdentityHashMap_EntrySpliterator()) }

func (t *IdentityHashMap_EntrySpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *IdentityHashMap_EntrySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *IdentityHashMap_EntrySpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *IdentityHashMap_EntrySpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *IdentityHashMap_EntrySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *IdentityHashMap_EntrySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_EntrySpliterator) GetClass__Class() *Class { return IdentityHashMap_EntrySpliterator_class }

func (t *IdentityHashMap_EntrySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *IdentityHashMap_EntrySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_EntrySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_EntrySpliterator_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_EntrySpliterator); return ok }

func IdentityHashMap_EntrySpliterator_Cast(x any) *IdentityHashMap_EntrySpliterator { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_EntrySpliterator); if !ok { panic(ClassCast(x, IdentityHashMap_EntrySpliterator_class)) }; return v }



type IdentityHashMap_IdentityHashMapIterator struct{ Object; F_index, F_expectedModCount, F_lastReturnedIndex int32; F_indexValid bool; F_traversalTable *RefArray; F_this_0 *IdentityHashMap }

type IdentityHashMap_IdentityHashMapIterator_I interface{ Object_I; Iterator; Self_IdentityHashMap_IdentityHashMapIterator() *IdentityHashMap_IdentityHashMapIterator; HasNext__Z() bool; NextIndex__I() int32; Remove__V() }

func (t *IdentityHashMap_IdentityHashMapIterator) Self_IdentityHashMap_IdentityHashMapIterator() *IdentityHashMap_IdentityHashMapIterator { return t }

func (t *IdentityHashMap_IdentityHashMapIterator) Is_Iterator() {}

func (t *IdentityHashMap_IdentityHashMapIterator) Ctor_IdentityHashMap(this IdentityHashMap_IdentityHashMapIterator_I, this_0 *IdentityHashMap) { NN(this_0); t.F_this_0 = this_0; var tmp1 int32; if /*line :282:1*/!(this_0.F_size == 0) { tmp1 = 0 } else { tmp1 = int32(len(this_0.F_table.A))
};




















































































































































































































































































































































































































































































































































































































































































































































































































































	t.F_index = tmp1; t.F_expectedModCount = this_0.F_modCount; t.F_lastReturnedIndex = -1; t.F_traversalTable = this_0.F_table }

func IdentityHashMap_IdentityHashMapIterator_InstanceOf(x any) bool { _, ok := x.(IdentityHashMap_IdentityHashMapIterator_I); return ok }

func IdentityHashMap_IdentityHashMapIterator_Cast(x any) IdentityHashMap_IdentityHashMapIterator_I { if x == nil { return nil }; v, ok := x.(IdentityHashMap_IdentityHashMapIterator_I); if !ok { panic(ClassCast(x, IdentityHashMap_IdentityHashMapIterator_class)) }; return v }



type IdentityHashMap_IdentityHashMapSpliterator struct{ Object; F_map *IdentityHashMap; F_index, F_fence, F_est, F_expectedModCount int32 }

type IdentityHashMap_IdentityHashMapSpliterator_I interface{ Object_I; Self_IdentityHashMap_IdentityHashMapSpliterator() *IdentityHashMap_IdentityHashMapSpliterator; GetFence__I() int32; EstimateSize__J() int64 }

func (t *IdentityHashMap_IdentityHashMapSpliterator) Self_IdentityHashMap_IdentityHashMapSpliterator() *IdentityHashMap_IdentityHashMapSpliterator { return t }

func (t *IdentityHashMap_IdentityHashMapSpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *IdentityHashMap_IdentityHashMapSpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *IdentityHashMap_IdentityHashMapSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_IdentityHashMapSpliterator) GetClass__Class() *Class { return IdentityHashMap_IdentityHashMapSpliterator_class }

func (t *IdentityHashMap_IdentityHashMapSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *IdentityHashMap_IdentityHashMapSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_IdentityHashMapSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_IdentityHashMapSpliterator_InstanceOf(x any) bool { _, ok := x.(IdentityHashMap_IdentityHashMapSpliterator_I); return ok }

func IdentityHashMap_IdentityHashMapSpliterator_Cast(x any) IdentityHashMap_IdentityHashMapSpliterator_I { if x == nil { return nil }; v, ok := x.(IdentityHashMap_IdentityHashMapSpliterator_I); if !ok { panic(ClassCast(x, IdentityHashMap_IdentityHashMapSpliterator_class)) }; return v }



type IdentityHashMap_KeyIterator struct{ IdentityHashMap_IdentityHashMapIterator; F_this_0 *IdentityHashMap }

func IdentityHashMap_KeyIterator_New_IdentityHashMap(p0 *IdentityHashMap) *IdentityHashMap_KeyIterator { t := &IdentityHashMap_KeyIterator{}; t.Ctor_IdentityHashMap(p0); return t }

func (t *IdentityHashMap_KeyIterator) Ctor_IdentityHashMap(this_0 *IdentityHashMap) { NN(this_0); t.F_this_0 = this_0; t.IdentityHashMap_IdentityHashMapIterator.Ctor_IdentityHashMap(t, this_0) }

func (t *IdentityHashMap_KeyIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *IdentityHashMap_KeyIterator) NextIndex__I() int32 { return t.Impl_NextIndex__I(t) }

func (t *IdentityHashMap_KeyIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *IdentityHashMap_KeyIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *IdentityHashMap_KeyIterator) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_KeyIterator) GetClass__Class() *Class { return IdentityHashMap_KeyIterator_class }

func (t *IdentityHashMap_KeyIterator) ToString__String() *String { return Object_toString(t) }

func (t *IdentityHashMap_KeyIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_KeyIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_KeyIterator_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_KeyIterator); return ok }

func IdentityHashMap_KeyIterator_Cast(x any) *IdentityHashMap_KeyIterator { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_KeyIterator); if !ok { panic(ClassCast(x, IdentityHashMap_KeyIterator_class)) }; return v }



type IdentityHashMap_KeySet struct{ AbstractSet; F_this_0 *IdentityHashMap }

func IdentityHashMap_KeySet_New_IdentityHashMap(p0 *IdentityHashMap) *IdentityHashMap_KeySet { t := &IdentityHashMap_KeySet{}; t.Ctor_IdentityHashMap(p0); return t }

func (t *IdentityHashMap_KeySet) Ctor_IdentityHashMap(this_0 *IdentityHashMap) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *IdentityHashMap_KeySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *IdentityHashMap_KeySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *IdentityHashMap_KeySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_KeySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *IdentityHashMap_KeySet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_KeySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *IdentityHashMap_KeySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *IdentityHashMap_KeySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *IdentityHashMap_KeySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *IdentityHashMap_KeySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_KeySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *IdentityHashMap_KeySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IdentityHashMap_KeySet) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_KeySet) GetClass__Class() *Class { return IdentityHashMap_KeySet_class }

func (t *IdentityHashMap_KeySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_KeySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_KeySet_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_KeySet); return ok }

func IdentityHashMap_KeySet_Cast(x any) *IdentityHashMap_KeySet { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_KeySet); if !ok { panic(ClassCast(x, IdentityHashMap_KeySet_class)) }; return v }



type IdentityHashMap_KeySpliterator struct{ IdentityHashMap_IdentityHashMapSpliterator }

func (t *IdentityHashMap_KeySpliterator) Is_Spliterator() {}

func (t *IdentityHashMap_KeySpliterator) TrySplit__Spliterator() Spliterator { return Up_IdentityHashMap_KeySpliterator_Spliterator(t.TrySplit__IdentityHashMap_KeySpliterator()) }

func (t *IdentityHashMap_KeySpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *IdentityHashMap_KeySpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *IdentityHashMap_KeySpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *IdentityHashMap_KeySpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *IdentityHashMap_KeySpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *IdentityHashMap_KeySpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_KeySpliterator) GetClass__Class() *Class { return IdentityHashMap_KeySpliterator_class }

func (t *IdentityHashMap_KeySpliterator) ToString__String() *String { return Object_toString(t) }

func (t *IdentityHashMap_KeySpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_KeySpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_KeySpliterator_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_KeySpliterator); return ok }

func IdentityHashMap_KeySpliterator_Cast(x any) *IdentityHashMap_KeySpliterator { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_KeySpliterator); if !ok { panic(ClassCast(x, IdentityHashMap_KeySpliterator_class)) }; return v }



type IdentityHashMap_ValueIterator struct{ IdentityHashMap_IdentityHashMapIterator; F_this_0 *IdentityHashMap }

func IdentityHashMap_ValueIterator_New_IdentityHashMap(p0 *IdentityHashMap) *IdentityHashMap_ValueIterator { t := &IdentityHashMap_ValueIterator{}; t.Ctor_IdentityHashMap(p0); return t }

func (t *IdentityHashMap_ValueIterator) Ctor_IdentityHashMap(this_0 *IdentityHashMap) { NN(this_0); t.F_this_0 = this_0; t.IdentityHashMap_IdentityHashMapIterator.Ctor_IdentityHashMap(t, this_0) }

func (t *IdentityHashMap_ValueIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *IdentityHashMap_ValueIterator) NextIndex__I() int32 { return t.Impl_NextIndex__I(t) }

func (t *IdentityHashMap_ValueIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *IdentityHashMap_ValueIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *IdentityHashMap_ValueIterator) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_ValueIterator) GetClass__Class() *Class { return IdentityHashMap_ValueIterator_class }

func (t *IdentityHashMap_ValueIterator) ToString__String() *String { return Object_toString(t) }

func (t *IdentityHashMap_ValueIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_ValueIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_ValueIterator_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_ValueIterator); return ok }

func IdentityHashMap_ValueIterator_Cast(x any) *IdentityHashMap_ValueIterator { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_ValueIterator); if !ok { panic(ClassCast(x, IdentityHashMap_ValueIterator_class)) }; return v }



type IdentityHashMap_ValueSpliterator struct{ IdentityHashMap_IdentityHashMapSpliterator }

func (t *IdentityHashMap_ValueSpliterator) Is_Spliterator() {}

func (t *IdentityHashMap_ValueSpliterator) TrySplit__Spliterator() Spliterator { return Up_IdentityHashMap_ValueSpliterator_Spliterator(t.TrySplit__IdentityHashMap_ValueSpliterator()) }

func (t *IdentityHashMap_ValueSpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *IdentityHashMap_ValueSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *IdentityHashMap_ValueSpliterator) GetFence__I() int32 { return t.Impl_GetFence__I(t) }

func (t *IdentityHashMap_ValueSpliterator) EstimateSize__J() int64 { return t.Impl_EstimateSize__J(t) }

func (t *IdentityHashMap_ValueSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *IdentityHashMap_ValueSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_ValueSpliterator) GetClass__Class() *Class { return IdentityHashMap_ValueSpliterator_class }

func (t *IdentityHashMap_ValueSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *IdentityHashMap_ValueSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_ValueSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_ValueSpliterator_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_ValueSpliterator); return ok }

func IdentityHashMap_ValueSpliterator_Cast(x any) *IdentityHashMap_ValueSpliterator { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_ValueSpliterator); if !ok { panic(ClassCast(x, IdentityHashMap_ValueSpliterator_class)) }; return v }



type IdentityHashMap_Values struct{ AbstractCollection; F_this_0 *IdentityHashMap }

func IdentityHashMap_Values_New_IdentityHashMap(p0 *IdentityHashMap) *IdentityHashMap_Values { t := &IdentityHashMap_Values{}; t.Ctor_IdentityHashMap(p0); return t }

func (t *IdentityHashMap_Values) Ctor_IdentityHashMap(this_0 *IdentityHashMap) { NN(this_0); t.F_this_0 = this_0; t.AbstractCollection.Ctor(t) }

func (t *IdentityHashMap_Values) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *IdentityHashMap_Values) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_Values) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *IdentityHashMap_Values) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_Values) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *IdentityHashMap_Values) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_Values) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *IdentityHashMap_Values) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *IdentityHashMap_Values) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *IdentityHashMap_Values) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *IdentityHashMap_Values) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *IdentityHashMap_Values) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IdentityHashMap_Values) Ref() any { if t == nil { return nil }; return t }

func (t *IdentityHashMap_Values) GetClass__Class() *Class { return IdentityHashMap_Values_class }

func (t *IdentityHashMap_Values) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IdentityHashMap_Values) CloneShallow() any { panic(CloneNotSupported(t)) }

func IdentityHashMap_Values_InstanceOf(x any) bool { _, ok := x.(*IdentityHashMap_Values); return ok }

func IdentityHashMap_Values_Cast(x any) *IdentityHashMap_Values { if x == nil { return nil }; v, ok := x.(*IdentityHashMap_Values); if !ok { panic(ClassCast(x, IdentityHashMap_Values_class)) }; return v }
