//line fdlibm.ae:1
package jrt

import "math"












var (
	fdksS1          = math.Float64frombits(13818544856648471881)
	fdksS2          = math.Float64frombits(4575957461383575718)
	fdksS3          = math.Float64frombits(13774824197404582357)
	fdksS4          = math.Float64frombits(4523617212983017085)
	fdksS5          = math.Float64frombits(13716528393433619691)
	fdksS6          = math.Float64frombits(4460209850635244924)
	fdkcC1          = math.Float64frombits(4586165620538955084)
	fdkcC2          = math.Float64frombits(13787419979223748983)
	fdkcC3          = math.Float64frombits(4537941361668330896)
	fdkcC4          = math.Float64frombits(13732177093731308205)
	fdkcC5          = math.Float64frombits(4477121870137962948)
	fdkcC6          = math.Float64frombits(13666448951086692564)
	fdktPio4        = math.Float64frombits(4605249457297304856)
	fdktPio4lo      = math.Float64frombits(4359948597267291143)
	fdktT0          = math.Float64frombits(4599676419421066595)
	fdktT1          = math.Float64frombits(4593971859893059194)
	fdktT2          = math.Float64frombits(4587938466107703806)
	fdktT3          = math.Float64frombits(4581960672245896759)
	fdktT4          = math.Float64frombits(4576262931677611155)
	fdktT5          = math.Float64frombits(4570429193025094440)
	fdktT6          = math.Float64frombits(4564358403679355669)
	fdktT7          = math.Float64frombits(4558562946408670465)
	fdktT8          = math.Float64frombits(4553182066015801448)
	fdktT9          = math.Float64frombits(4545397049192321702)
	fdktT10         = math.Float64frombits(4544897349388904425)
	fdktT11         = math.Float64frombits(13759470804966331251)
	fdktT12         = math.Float64frombits(4538267711989316308)
	fdrpInvpio2     = math.Float64frombits(4603909380684499075)
	fdrpPio2_1      = math.Float64frombits(4609753056924401664)
	fdrpPio2_1t     = math.Float64frombits(4454258360616903473)
	fdrpPio2_2      = math.Float64frombits(4454258360616747008)
	fdrpPio2_2t     = math.Float64frombits(4297306550709743731)
	fdrpPio2_3      = math.Float64frombits(4297306550709518336)
	fdrpPio2_3t     = math.Float64frombits(4142048980368378305)
	fdrpTWO24       = math.Float64frombits(4715268809856909312)
	fdrpTwon24      = math.Float64frombits(4499096027743125504)
	fdasPio2_hi     = math.Float64frombits(4609753056924675352)
	fdasPio2_lo     = math.Float64frombits(4364452196894661639)
	fdasPio4_hi     = math.Float64frombits(4605249457297304856)
	fdasPS0         = math.Float64frombits(4595172819793696085)
	fdasPS1         = math.Float64frombits(13822908529170411389)
	fdasPS2         = math.Float64frombits(4596417465768494165)
	fdasPS3         = math.Float64frombits(13809305468778614587)
	fdasPS4         = math.Float64frombits(4560439845004096136)
	fdasPS5         = math.Float64frombits(4540259411154564873)
	fdasQS1         = math.Float64frombits(13835966419869248843)
	fdasQS2         = math.Float64frombits(4611733184086379208)
	fdasQS3         = math.Float64frombits(13827746767276147033)
	fdasQS4         = math.Float64frombits(4590215604441354882)
	fdatAT0         = math.Float64frombits(4599676419421066509)
	fdatAT1         = math.Float64frombits(13819745816549059524)
	fdatAT2         = math.Float64frombits(4594314991288484863)
	fdatAT3         = math.Float64frombits(13816042856347014769)
	fdatAT4         = math.Float64frombits(4591215095208222830)
	fdatAT5         = math.Float64frombits(13813579038447671917)
	fdatAT6         = math.Float64frombits(4589464229703073105)
	fdatAT7         = math.Float64frombits(13811939918460419482)
	fdatAT8         = math.Float64frombits(4587333258118041067)
	fdatAT9         = math.Float64frombits(13808797612367309871)
	fdatAT10        = math.Float64frombits(4580351289466214929)
	fda2Pi_o_4      = math.Float64frombits(4605249457297304856)
	fda2Pi_o_2      = math.Float64frombits(4609753056924675352)
	fda2Pi_lo       = math.Float64frombits(4368955796522032135)
	fdhyTWOm600     = math.Float64frombits(1905022642377719808)
	fdhyTWO600      = math.Float64frombits(7309342195222315008)
	fdhyLarge       = math.Float64frombits(6858982236780232703)
	fdhyTWOm500     = math.Float64frombits(2355382605114769408)
	fdhyTWO1022     = math.Float64frombits(9209861237972664320)
	fdexTwom1000    = math.Float64frombits(103582791429521408)
	fdexO_threshold = math.Float64frombits(4649454530587146735)
	fdexU_threshold = math.Float64frombits(13873137513782915153)
	fdexLn2HI       = math.Float64frombits(4604418534311723008)
	fdexLn2LO0      = math.Float64frombits(4461442080421002358)
	fdexLn2LO1      = math.Float64frombits(13684814117275778166)
	fdexInvln2      = math.Float64frombits(4609176140021203710)
	fdexP1          = math.Float64frombits(4595172819793696062)
	fdexP2          = math.Float64frombits(13791923578850950547)
	fdexP3          = math.Float64frombits(4544508515198557740)
	fdexP4          = math.Float64frombits(13743786778040626161)
	fdexP5          = math.Float64frombits(4496342204012209360)
	fdlgIvln10      = math.Float64frombits(4601495173785380110)
	fdlgLog10_2hi   = math.Float64frombits(4599094494223097856)
	fdlgLog10_2lo   = math.Float64frombits(4420844829172378422)
	fdl1Ln2_hi      = math.Float64frombits(4604418534311723008)
	fdl1Ln2_lo      = math.Float64frombits(4461442080421002358)
	fdl1Lp1         = math.Float64frombits(4604180019048437139)
	fdl1Lp2         = math.Float64frombits(4600877379321592324)
	fdl1Lp3         = math.Float64frombits(4598818590951641945)
	fdl1Lp4         = math.Float64frombits(4597174411056806063)
	fdl1Lp5         = math.Float64frombits(4595719342595441630)
	fdl1Lp6         = math.Float64frombits(4594685411790997151)
	fdl1Lp7         = math.Float64frombits(4594499633228436036)
	fdemO_threshold = math.Float64frombits(4649454530587146735)
	fdemLn2_hi      = math.Float64frombits(4604418534311723008)
	fdemLn2_lo      = math.Float64frombits(4461442080421002358)
	fdemInvln2      = math.Float64frombits(4609176140021203710)
	fdemQ1          = math.Float64frombits(13808336697493098740)
	fdemQ2          = math.Float64frombits(4564962959435912581)
	fdemQ3          = math.Float64frombits(13768856570209950647)
	fdemQ4          = math.Float64frombits(4526346094260933177)
	fdemQ5          = math.Float64frombits(13730065378259354413)
	fdPIo2          = []float64{math.Float64frombits(4609753056584663040), math.Float64frombits(4500296887714185216), math.Float64frombits(4393339057296375808), math.Float64frombits(4285399695318056960), math.Float64frombits(4174867106174599168), math.Float64frombits(4069606033725587456), math.Float64frombits(3955147982449410048), math.Float64frombits(3848874662444400640)}
)
var (
	fdTwoOverPi = []int32{10680707, 7228996, 1387004, 2578385, 16069853, 12639074, 9804092, 4427841, 16666979, 11263675, 12935607, 2387514, 4345298, 14681673, 3074569, 13734428, 16653803, 1880361, 10960616, 8533493, 3062596, 8710556, 7349940, 6258241, 3772886, 3769171, 3798172, 8675211, 12450088, 3874808, 9961438, 366607, 15675153, 9132554, 7151469, 3571407, 2607881, 12013382, 4155038, 6285869, 7677882, 13102053, 15825725, 473591, 9065106, 15363067, 6271263, 9264392, 5636912, 4652155, 7056368, 13614112, 10155062, 1944035, 9527646, 15080200, 6658437, 6231200, 6832269, 16767104, 5075751, 3212806, 1398474, 7579849, 6349435, 12618859}

	fdNpio2Hw = []int32{1073291771, 1074340347, 1074977148, 1075388923, 1075800698, 1076025724, 1076231611, 1076437499, 1076643386, 1076849274, 1076971356, 1077074300, 1077177244, 1077280187, 1077383131, 1077486075, 1077589019, 1077691962, 1077794906, 1077897850, 1077968460, 1078019932, 1078071404, 1078122876, 1078174348, 1078225820, 1078277292, 1078328763, 1078380235, 1078431707, 1078483179, 1078534651}
)



// fdHiLo is FdLibm.__HI_LO: the double of the two 32-bit words.
func fdHiLo(hi, lo int32) float64 {
	return math.Float64frombits(uint64(uint32(hi))<<32 | uint64(uint32(lo))) }
// fdUshr is Java's x >>> n on an int (n in 0..31).
func fdUshr(x, n int32) int32 {
	return int32(uint32(x) >> n)
}


// fdKernelSin is FdLibm.Sin.__kernel_sin.
func fdKernelSin(x, y float64, iy int32) float64 {
	ix := fdHi(x) & 2147483647
	if ix < 1044381696 && D2I(x) == 0 {
		return x }
	z := fmul(x, x)
	v := fmul(z, x)
	r := fdksS2 + fmul(z, fdksS3+fmul(z, fdksS4+fmul(z, fdksS5+fmul(z, fdksS6))))
	if iy == 0 {
		return x + fmul(v, fdksS1+fmul(z, r)) }
	return x - (fmul(z, fmul(0.5, y)-fmul(v, r)) - y - fmul(v, fdksS1)) }
// fdKernelCos is FdLibm.Cos.__kernel_cos.
func fdKernelCos(x, y float64) float64 {
	ix := fdHi(x) & 2147483647
	if ix < 1044381696 && D2I(x) == 0 {
		return 1.0 }
	z := fmul(x, x)
	r := fmul(z, fdkcC1+fmul(z, fdkcC2+fmul(z, fdkcC3+fmul(z, fdkcC4+fmul(z, fdkcC5+fmul(z, fdkcC6))))))
	if ix < 1070805811 {
		return 1.0 - (fmul(0.5, z) - (fmul(z, r) - fmul(x, y))) }
	qx := 0.28125
	if ix <= 1072234496 {
		qx = fdHiLo(ix-2097152, 0) }
	hz := fmul(0.5, z) - qx
	a := 1.0 - qx
	return a - (hz - (fmul(z, r) - fmul(x, y))) }
// fdKernelTan is FdLibm.Tan.__kernel_tan.
func fdKernelTan(x, y float64, iy int32) float64 {
	hx := fdHi(x)
	ix := hx & 2147483647
	if ix < 1043333120 && D2I(x) == 0 {
		if ix|fdLo(x)|(iy+1) == 0 {
			return 1.0 / math.Abs(x) }
		if iy == 1 {
			return x }
		w := x + y
		z := fdSetLo(w, 0)
		v := y - (z - x)
		a := -1.0 / w
		t := fdSetLo(a, 0)
		s := 1.0 + fmul(t, z)
		return t + fmul(a, s+fmul(t, v)) }
	if ix >= 1072010280 {
		if hx < 0 {
			x = -x
			y = -y }
		z := fdktPio4 - x
		w := fdktPio4lo - y
		x = z + w
		y = 0.0 }
	z := fmul(x, x)
	w := fmul(z, z)
	r := fdktT1 + fmul(w, fdktT3+fmul(w, fdktT5+fmul(w, fdktT7+fmul(w, fdktT9+fmul(w, fdktT11)))))
	v := fmul(z, fdktT2+fmul(w, fdktT4+fmul(w, fdktT6+fmul(w, fdktT8+fmul(w, fdktT10+fmul(w, fdktT12))))))
	s := fmul(z, x)
	r = y + fmul(z, fmul(s, r+v)+y)
	r = r + fmul(fdktT0, s)
	w = x + r
	if ix >= 1072010280 {
		v = float64(iy)
		return fmul(float64(1-hx>>30&2),
			v-fmul(2.0, x-(fmul(w, w)/(w+v)-r))) }
	if iy == 1 {
		return w }
	z2 := fdSetLo(w, 0)
	v2 := r - (z2 - x)
	a := -1.0 / w
	t := fdSetLo(a, 0)
	s2 := 1.0 + fmul(t, z2)
	return t + fmul(a, s2+fmul(t, v2)) }
// fdRemPio2 is FdLibm.RemPio2.__ieee754_rem_pio2: n and x - n*pi/2 as y0 + y1.
func fdRemPio2(x float64) (int32, float64, float64) {


	hx := fdHi(x)
	ix := hx & 2147483647
	if ix <= 1072243195 {
		return 0, x, 0.0 }
	if ix < 1073928572 {
		if hx > 0 {
			z := x - fdrpPio2_1
			if ix != 1073291771 {
				y0 := z - fdrpPio2_1t
				return 1, y0, z - y0 - fdrpPio2_1t }
			z = z - fdrpPio2_2
			y0 := z - fdrpPio2_2t
			return 1, y0, z - y0 - fdrpPio2_2t }
		z := x + fdrpPio2_1
		if ix != 1073291771 {
			y0 := z + fdrpPio2_1t
			return -1, y0, z - y0 + fdrpPio2_1t }
		z = z + fdrpPio2_2
		y0 := z + fdrpPio2_2t
		return -1, y0, z - y0 + fdrpPio2_2t }
	if ix <= 1094263291 {
		t := math.Abs(x)
		n := D2I(fmul(t, fdrpInvpio2) + 0.5)
		fnn := float64(n)
		r := t - fmul(fnn, fdrpPio2_1)
		w := fmul(fnn, fdrpPio2_1t)
		y0 := 0.0
		if n < 32 && ix != fdNpio2Hw[n-1] {
			y0 = r - w } else {
				j := ix >> 20
				y0 = r - w
				i := j - fdHi(y0)>>20&2047
				if i > 16 {
					t = r
					w = fmul(fnn, fdrpPio2_2)
					r = t - w
					w = fmul(fnn, fdrpPio2_2t) - (t - r - w)
					y0 = r - w
					i = j - fdHi(y0)>>20&2047
					if i > 49 {
						t = r
						w = fmul(fnn, fdrpPio2_3)
						r = t - w
						w = fmul(fnn, fdrpPio2_3t) - (t - r - w)
						y0 = r - w } } }
		y1 := r - y0 - w
		if hx < 0 {
			return -n, -y0, -y1 }
		return n, y0, y1 }
	if ix >= 2146435072 {
		d := x - x
		return 0, d, d }
	e0 := ix>>20 - 1046
	z := fdSetHi(fdSetLo(0.0, fdLo(x)), ix-e0<<20)
	tx := make([]float64, 3)
	for i := 0; i < 2; i++ {
		tx[i] = float64(D2I(z))
		z = fmul(z-tx[i], fdrpTWO24) }
	tx[2] = z
	nx := 3
	for tx[nx-1] == 0.0 {
		nx-- }
	n, y0, y1 := fdKernelRemPio2(tx[:nx], e0)
	if hx < 0 {
		return -n, -y0, -y1 }
	return n, y0, y1 }
// fdKernelRemPio2 is FdLibm.KernelRemPio2.__kernel_rem_pio2 with prec 2 (the one
// RemPio2 uses) and ipio2 two_over_pi: x the 24-bit chunks of the argument.
//line :278:1
func fdKernelRemPio2(x /*line :281:1*/[]float64, e0 int32) (int32, float64, float64) {
	iq := [20]int32{}
	f := [20]float64{}
	fq := [20]float64{}
	q := [20]float64{}
	jk := int32(4)
	jp := jk
	jx := int32(len(x)) - 1
	jv := (e0 - 3) / 24
	if jv < 0 {
		jv = 0 }
	q0 := e0 - 24*(jv+1)
	j := jv - jx
	m := jx + jk
	z := 0.0
	fw := 0.0
	jz := jk
	n := int32(0)
	ih := int32(0)
	carry := int32(0)
	k := int32(0)
	for i := int32(0); i <= m; i++ {
		if j < 0 {
			f[i] = 0.0 } else {
				f[i] = float64(fdTwoOverPi[j]) }
		j++ }
	for i := int32(0); i <= jk; i++ {
		fw = 0.0
		for jj := int32(0); jj <= jx; jj++ {
			fw = fw + fmul(x[jj], f[jx+i-jj]) }
		q[i] = fw }
	for {
		z = q[jz]
		{ i := int32(0)
			for jj := jz; jj > 0; jj-- {
				fw = float64(D2I(fmul(fdrpTwon24, z)))
				iq[i] = D2I(z - fmul(fdrpTWO24, fw))
				z = q[jj-1] + fw
				i++ } }
		z = Math_Scalb_D_I__D(z, q0)
		z = z - fmul(8.0, math.Floor(fmul(z, 0.125)))
		n = D2I(z)
		z = z - float64(n)
		ih = 0
		if
			q0 > 0 { i := iq[jz-1] >> (24 - q0)
				n = n + i
				iq[jz-1] = iq[jz-1] - i<<(24-q0)
				ih = iq[jz-1] >> (23 - q0)
			} else if q0 == 0 { ih = iq[jz-1] >> 23
			} else if z >= 0.5 { ih = 2 }
		if ih > 0 {
			n++
			carry = 0
			for i := int32(0); i < jz; i++ {
				jj := iq[i]
				if carry == 0 {
					if jj != 0 {
						carry = 1
						iq[i] = 16777216 - jj } } else {
							iq[i] = 16777215 - jj } }
			if q0 > 0 {
				if
					q0 == 1 { iq[jz-1] = iq[jz-1] & 8388607
					} else if q0 == 2 { iq[jz-1] = iq[jz-1] & 4194303 } }
			if ih == 2 {
				z = 1.0 - z
				if carry != 0 {
					z = z - Math_Scalb_D_I__D(1.0, q0) } } }
		if z != 0.0 {
			break }
		{ jj := int32(0)
			for i := jz - 1; i >= jk; i-- {
				jj = jj | iq[i] }
			if jj != 0 {
				break
			} }
		k = 1
		for iq[jk-k] == 0 {
			k++ }
		for i := jz + 1; i <= jz+k; i++ {
			f[jx+i] = float64(fdTwoOverPi[jv+i])
			fw = 0.0
			for jj := int32(0); jj <= jx; jj++ {
				fw = fw + fmul(x[jj], f[jx+i-jj]) }
			q[i] = fw }
		jz = jz + k }
	if z == 0.0 {

		jz = jz - 1
		q0 = q0 - 24
		for iq[jz] == 0 {
			jz--
			q0 = q0 - 24 } } else {

				z = Math_Scalb_D_I__D(z, -q0)
				if z >= fdrpTWO24 {

					fw = float64(D2I(fmul(fdrpTwon24, z)))
					iq[jz] = D2I(z - fmul(fdrpTWO24, fw))
					jz++
					q0 = q0 + 24
					iq[jz] = D2I(fw) } else {
						iq[jz] = D2I(z) } }
	fw = Math_Scalb_D_I__D(1.0, q0)
	for i := jz; i >= 0; i-- {
		q[i] = fmul(fw, float64(iq[i]))
		fw = fmul(fw, fdrpTwon24) }
	for i := jz; i >= 0; i-- {
		fw = 0.0
		for kk := int32(0); kk <= jp && kk <= jz-i; kk++ {
			fw = fw + fmul(fdPIo2[kk], q[i+kk]) }
		fq[jz-i] = fw }
	fw = 0.0
	for i := jz; i >= 0; i-- {
		fw = fw + fq[i] }
	y0 := fw
	if ih != 0 {
		y0 = -fw }
	fw = fq[0] - fw
	for i := int32(1); i <= jz; i++ {
		fw = fw + fq[i] }
	y1 := fw
	if ih != 0 {
		y1 = -fw }
	return n & 7, y0, y1 }
// fdSin is FdLibm.Sin.compute (StrictMath.sin).
func fdSin(x float64) float64 {
	ix := fdHi(x) & 2147483647
	if ix <= 1072243195 {
		return fdKernelSin(x, 0.0, 0) }
	if ix >= 2146435072 {
		return x - x }
	n, y0, y1 := fdRemPio2(x)
	switch n & 3 {
	case 0: return fdKernelSin(y0, y1, 1)
	case 1: return fdKernelCos(y0, y1)
	case 2: return -fdKernelSin(y0, y1, 1)}
	return -fdKernelCos(y0, y1) }
// fdCos is FdLibm.Cos.compute (StrictMath.cos).
func fdCos(x float64) float64 {
	ix := fdHi(x) & 2147483647
	if ix <= 1072243195 {
		return fdKernelCos(x, 0.0) }
	if ix >= 2146435072 {
		return x - x }
	n, y0, y1 := fdRemPio2(x)
	switch n & 3 {
	case 0: return fdKernelCos(y0, y1)
	case 1: return -fdKernelSin(y0, y1, 1)
	case 2: return -fdKernelCos(y0, y1)}
	return fdKernelSin(y0, y1, 1) }
// fdTan is FdLibm.Tan.compute (StrictMath.tan).
func fdTan(x float64) float64 {
	ix := fdHi(x) & 2147483647
	if ix <= 1072243195 {
		return fdKernelTan(x, 0.0, 1) }
	if ix >= 2146435072 {
		return x - x }
	n, y0, y1 := fdRemPio2(x)
	return fdKernelTan(y0, y1, 1-n&1<<1)
}


// fdAsP is Asin's and Acos's numerator polynomial p(t).
func fdAsP(t float64) float64 {
	return fmul(t, fdasPS0+fmul(t, fdasPS1+fmul(t, fdasPS2+fmul(t, fdasPS3+fmul(t, fdasPS4+fmul(t, fdasPS5)))))) }
// fdAsQ is Asin's and Acos's denominator polynomial q(t).
func fdAsQ(t float64) float64 {
	return 1.0 + fmul(t, fdasQS1+fmul(t, fdasQS2+fmul(t, fdasQS3+fmul(t, fdasQS4)))) }
// fdAsin is FdLibm.Asin.compute (StrictMath.asin).
func fdAsin(x float64) float64 {
	hx := fdHi(x)
	ix := hx & 2147483647
	t := 0.0
	if ix >= 1072693248 {
		if ix-1072693248|fdLo(x) == 0 {
			return fmul(x, fdasPio2_hi) + fmul(x, fdasPio2_lo) }
		return (x - x) / (x - x) }
	if ix < 1071644672 {
		if ix < 1044381696 {
			if 1.0e300+x > 1.0 {
				return x } } else {
					t = fmul(x, x) }
		w := fdAsP(t) / fdAsQ(t)
		return x + fmul(x, w) }
	w := 1.0 - math.Abs(x)
	t = fmul(w, 0.5)
	p := fdAsP(t)
	q := fdAsQ(t)
	s := math.Sqrt(t)
	if ix >= 1072640819 {

		w = p / q
		t = fdasPio2_hi - (fmul(2.0, s+fmul(s, w)) - fdasPio2_lo) } else {

			w = fdSetLo(s, 0)
			c := (t - fmul(w, w)) / (s + w)
			r := p / q
			p2 := fmul(fmul(2.0, s), r) - (fdasPio2_lo - fmul(2.0, c))
			q2 := fdasPio4_hi - fmul(2.0, w)
			t = fdasPio4_hi - (p2 - q2) }
	if hx > 0 {
		return t }
	return -t }
// fdAcos is FdLibm.Acos.compute (StrictMath.acos).
func fdAcos(x float64) float64 {
	hx := fdHi(x)
	ix := hx & 2147483647
	if ix >= 1072693248 {
		if ix-1072693248|fdLo(x) == 0 {
			if hx > 0 {
				return 0.0 }
			return Math_PI + fmul(2.0, fdasPio2_lo) }
		return (x - x) / (x - x) }
	if ix < 1071644672 {
		if ix <= 1012924416 {
			return fdasPio2_hi + fdasPio2_lo }
		z := fmul(x, x)
		r := fdAsP(z) / fdAsQ(z)
		return fdasPio2_hi - (x - (fdasPio2_lo - fmul(x, r))) }
	if hx < 0 {
		z := fmul(1.0+x, 0.5)
		p := fdAsP(z)
		q := fdAsQ(z)
		s := math.Sqrt(z)
		r := p / q
		w := fmul(r, s) - fdasPio2_lo
		return Math_PI - fmul(2.0, s+w) }
	z := fmul(1.0-x, 0.5)
	s := math.Sqrt(z)
	df := fdSetLo(s, 0)
	c := (z - fmul(df, df)) / (s + df)
	p := fdAsP(z)
	q := fdAsQ(z)
	r := p / q
	w := fmul(r, s) + c
	return fmul(2.0, df+w)
}
var (
	fdAtanHi    = []float64{math.Float64frombits(4602023952714414927), math.Float64frombits(4605249457297304856),
			math.Float64frombits(4607027438436873883), math.Float64frombits(4609753056924675352),
	}; fdAtanLo = []float64{math.Float64frombits(4357843414468748770), math.Float64frombits(4359948597267291143),
			math.Float64frombits(4354989122426817469), math.Float64frombits(4364452196894661639)})
// fdAtan is FdLibm.Atan.compute (StrictMath.atan).
func fdAtan(x float64) float64 {
	hx := fdHi(x)
	ix := hx & 2147483647
	id := int32(0)
	if ix >= 1141899264 {
		if ix > 2146435072 || ix == 2146435072 && fdLo(x) != 0 {
			return x + x }
		if hx > 0 {
			return fdAtanHi[3] + fdAtanLo[3] }
		return -fdAtanHi[3] - fdAtanLo[3] }
	if ix < 1071382528 {

		if ix < 1042284544 && 1.0e300+x > 1.0 {
			return x }
		id = -1 } else {

			x = math.Abs(x)
			if ix < 1072889856 {
				if ix < 1072037888 {
					id = 0; x = (fmul(2.0, x) - 1.0) / (2.0 + x) } else {
						id = 1; x = (x - 1.0) / (x + 1.0) }
			} else if ix < 1073971200 {
				id = 2; x = (x - 1.5) / (1.0 + fmul(1.5, x)) } else {
					id = 3; x = -1.0 / x } }
	z := fmul(x, x)
	w := fmul(z, z)
	s1 := fmul(z, fdatAT0+fmul(w, fdatAT2+fmul(w, fdatAT4+fmul(w, fdatAT6+fmul(w, fdatAT8+fmul(w, fdatAT10))))))
	s2 := fmul(w, fdatAT1+fmul(w, fdatAT3+fmul(w, fdatAT5+fmul(w, fdatAT7+fmul(w, fdatAT9)))))
	if id < 0 {
		return x - fmul(x, s1+s2) }
	z = fdAtanHi[id] - (fmul(x, s1+s2) - fdAtanLo[id] - x)
	if hx < 0 {
		return -z
	}; return z }
// fdAtan2 is FdLibm.Atan2.compute (StrictMath.atan2).
func fdAtan2(y, x float64) float64 {
	hx := fdHi(x)
	ix := hx & 2147483647
	lx := fdLo(x)
	hy := fdHi(y)
	iy := hy & 2147483647
	ly := fdLo(y)
	tiny := 1.0e-300
	if math.IsNaN(x) || math.IsNaN(y) {
		return x + y }
	if hx-1072693248|lx == 0 {
		return fdAtan(y) }
	m := hy>>31&1 | hx>>30&2
	if iy|ly == 0 {
		switch m {
		case 0, 1: return y
		case 2: return Math_PI + tiny
		case 3: return -Math_PI - tiny} }
	if ix|lx == 0 {
		if hy < 0 {
			return -fda2Pi_o_2 - tiny }
		return fda2Pi_o_2 + tiny }
	if ix == 2146435072 {
		if iy == 2146435072 {
			switch m {
			case 0: return fda2Pi_o_4 + tiny
			case 1: return -fda2Pi_o_4 - tiny
			case 2: return fmul(3.0, fda2Pi_o_4) + tiny
			case 3: return fmul(-3.0, fda2Pi_o_4) - tiny} } else {
				switch m {
				case 0: return 0.0
				case 1: return NegZero64
				case 2: return Math_PI + tiny
				case 3: return -Math_PI - tiny} } }
	if iy == 2146435072 {
		if hy < 0 {
			return -fda2Pi_o_2 - tiny }
		return fda2Pi_o_2 + tiny }
	k := (iy - ix) >> 20
	z := 0.0
	if
		k > 60 { z = fda2Pi_o_2 + fmul(0.5, fda2Pi_lo)
		} else if hx < 0 && k < -60 { z = 0.0 } else {
			z = fdAtan(math.Abs(y / x)) }
	switch m {
	case 0: return z
	case 1: return -z
	case 2: return Math_PI - (z - fda2Pi_lo)}
	return z - fda2Pi_lo - Math_PI
}


// fdHypot is FdLibm.Hypot.compute (StrictMath.hypot).
func fdHypot(x, y float64) float64 {
	a := math.Abs(x)
	b := math.Abs(y)
	if math.IsInf(a, 0) || math.IsNaN(a) || math.IsInf(b, 0) || math.IsNaN(b) {
		if a == PosInf64 || b == PosInf64 {
			return PosInf64 }
		return a + b }
	if b > a {
		a, b = b, a }
	ha := fdHi(a)
	hb := fdHi(b)
	if ha-hb > 62914560 {
		return a + b }
	k := int32(0)
	t1 := 0.0
	t2 := 0.0
	if a > fdhyLarge {
		ha = ha - 629145600
		hb = hb - 629145600
		a = fmul(a, fdhyTWOm600)
		b = fmul(b, fdhyTWOm600)
		k = k + 600 }
	if b < fdhyTWOm500 {
		if b < 2.2250738585072014e-308 {

			if b == 0.0 {
				return a }
			t1 = fdhyTWO1022
			b = fmul(b, t1)
			a = fmul(a, t1)
			k = k - 1022 } else {

				ha = ha + 629145600
				hb = hb + 629145600
				a = fmul(a, fdhyTWO600)
				b = fmul(b, fdhyTWO600)
				k = k - 600 } }
	w := a - b
	if w > b {

		t1 = fdSetHi(0.0, ha)
		t2 = a - t1
		w = math.Sqrt(fmul(t1, t1) - (fmul(b, -b) - fmul(t2, a+t1))) } else {

			a = a + a
			y1 := fdSetHi(0.0, hb)
			y2 := b - y1
			t1 = fdSetHi(0.0, ha+1048576)
			t2 = a - t1
			w = math.Sqrt(fmul(t1, y1) - (fmul(w, -w) - (fmul(t1, y2) + fmul(t2, b)))) }
	if k != 0 {
		return fmul(powerOfTwoD(k), w)
	}
	return w
}

// fdExp is FdLibm.Exp.compute (StrictMath.exp).
func fdExp(x float64) float64 {
	hx := fdHi(x)
	xsb := hx >> 31 & 1
	hi := 0.0
	lo := 0.0
	k := int32(0)
	hx = hx & 2147483647
	if hx >= 1082535490 {
		if hx >= 2146435072 {
			if hx&1048575|fdLo(x) != 0 {
				return x + x }
			if xsb == 0 {
				return x }
			return 0.0 }
		if x > fdexO_threshold {
			return PosInf64 }
		if x < fdexU_threshold {
			return fmul(fdexTwom1000, fdexTwom1000) } }
	if
		hx > 1071001154 {

			if hx < 1072734898 {

				hi = x - fmul(fdexLn2HI, float64(1-2*xsb))
				if xsb == 0 { lo = fdexLn2LO0 } else { lo = fdexLn2LO1 }
				k = 1 - xsb - xsb } else {

					k = D2I(fmul(fdexInvln2, x) + fmul(0.5, float64(1-2*xsb)))
					t := float64(k)
					hi = x - fmul(t, fdexLn2HI)
					lo = fmul(t, fdexLn2LO0) }
			x = hi - lo
		} else if hx < 1043333120 {
			if 1.0e300+x > 1.0 {
				return 1.0 + x } } else {
					k = 0 }
	t := fmul(x, x)
	c := x - fmul(t, fdexP1+fmul(t, fdexP2+fmul(t, fdexP3+fmul(t, fdexP4+fmul(t, fdexP5)))))
	if k == 0 {
		return 1.0 - (fmul(x, c)/(c-2.0) - x) }
	y := 1.0 - (lo - fmul(x, c)/(2.0-c) - hi)
	if k >= -1021 {
		return fdSetHi(y, fdHi(y)+k<<20) }
	y = fdSetHi(y, fdHi(y)+(k+1000)<<20)
	return fmul(y, fdexTwom1000) }
// fdLog10 is FdLibm.Log10.compute (StrictMath.log10).
func fdLog10(x float64) float64 {
	hx := fdHi(x)
	lx := fdLo(x)
	k := int32(0)
	if hx < 1048576 {
		if hx&2147483647|lx == 0 {
			return NegInf64 }
		if hx < 0 {
			return NaN64 }
		k = k - 54
		x = fmul(x, fdTWO54)
		hx = fdHi(x) }
	if hx >= 2146435072 {
		return x + x }
	k = k + (hx>>20 - 1023)
	i := fdUshr(k, 31)
	y := float64(k + i)
	hx = hx&1048575 | (1023-i)<<20
	x = fdSetHi(x, hx)
	z := fmul(y, fdlgLog10_2lo) + fmul(fdlgIvln10, fdLog(x))
	return z + fmul(y, fdlgLog10_2hi) }
// fdLog1p is FdLibm.Log1p.compute (StrictMath.log1p).
func fdLog1p(x float64) float64 {
	f := 0.0
	c := 0.0
	u := 0.0
	hx := fdHi(x)
	ax := hx & 2147483647
	k := int32(1)
	hu := int32(0)
	if hx < 1071284858 {
		if ax >= 1072693248 {
			if x == -1.0 {
				return NegInf64 }
			return NaN64 }
		if ax < 1042284544 {
			if fdTWO54+x > 0.0 && ax < 1016070144 {
				return x }
			return x - fmul(fmul(x, x), 0.5) }
		if hx > 0 || hx <= -1076707645 {
			k = 0
			f = x
			hu = 1 } }
	if hx >= 2146435072 {
		return x + x }
	if k != 0 {
		if hx < 1128267776 {

			u = 1.0 + x
			hu = fdHi(u)
			k = hu>>20 - 1023
			if k > 0 {
				c = 1.0 - (u - x) } else {
					c = x - (u - 1.0) }
			c = c / u } else {

				u = x
				hu = fdHi(u)
				k = hu>>20 - 1023
				c = 0.0 }
		hu = hu & 1048575
		if hu < 434334 {
			u = fdSetHi(u, hu|1072693248) } else {

				k++
				u = fdSetHi(u, hu|1071644672)
				hu = (1048576 - hu) >> 2 }
		f = u - 1.0 }
	hfsq := fmul(fmul(0.5, f), f)
	dk := float64(k)
	if hu == 0 {
		if f == 0.0 {
			if k == 0 {
				return 0.0 }
			c = c + fmul(dk, fdl1Ln2_lo)
			return fmul(dk, fdl1Ln2_hi) + c }
		R := fmul(hfsq, 1.0-fmul(0.6666666666666666, f))
		if k == 0 {
			return f - R }
		return fmul(dk, fdl1Ln2_hi) - (R - (fmul(dk, fdl1Ln2_lo) + c) - f) }
	s := f / (2.0 + f)
	z := fmul(s, s)
	R := fmul(z, fdl1Lp1+fmul(z, fdl1Lp2+fmul(z, fdl1Lp3+fmul(z, fdl1Lp4+fmul(z, fdl1Lp5+fmul(z, fdl1Lp6+fmul(z, fdl1Lp7)))))))
	if k == 0 {
		return f - (hfsq - fmul(s, hfsq+R)) }
	return fmul(dk, fdl1Ln2_hi) - (hfsq - (fmul(s, hfsq+R) + (fmul(dk, fdl1Ln2_lo) + c)) - f) }
// fdExpm1 is FdLibm.Expm1.compute (StrictMath.expm1).
func fdExpm1(x float64) float64 {
	hx := fdHi(x)
	xsb := hx & int32(-2147483648)
	k := int32(0)
	c := 0.0
	hi := 0.0
	lo := 0.0
	y := 0.0
	hx = hx & 2147483647
	if hx >= 1078159482 {
		if hx >= 1082535490 {
			if hx >= 2146435072 {
				if hx&1048575|fdLo(x) != 0 {
					return x + x }
				if xsb == 0 {
					return x }
				return -1.0 }
			if x > fdemO_threshold {
				return PosInf64 } }
		if xsb != 0 && x+1.0e-300 < 0.0 {
			return -1.0 } }
	if
		hx > 1071001154 {

			if hx < 1072734898 {
				if xsb == 0 {
					hi = x - fdemLn2_hi; lo = fdemLn2_lo; k = 1 } else {
						hi = x + fdemLn2_hi; lo = -fdemLn2_lo; k = -1 } } else {

							if xsb == 0 {
								k = D2I(fmul(fdemInvln2, x) + 0.5) } else {
									k = D2I(fmul(fdemInvln2, x) + -0.5) }
							t := float64(k)
							hi = x - fmul(t, fdemLn2_hi)
							lo = fmul(t, fdemLn2_lo) }
			x = hi - lo
			c = hi - x - lo
		} else if hx < 1016070144 {
			t := 1.0e300 + x
			return x - (t - (1.0e300 + x)) } else {
				k = 0 }
	hfx := fmul(0.5, x)
	hxs := fmul(x, hfx)
	r1 := 1.0 + fmul(hxs, fdemQ1+fmul(hxs, fdemQ2+fmul(hxs, fdemQ3+fmul(hxs, fdemQ4+fmul(hxs, fdemQ5)))))
	t := 3.0 - fmul(r1, hfx)
	e := fmul(hxs, (r1-t)/(6.0-fmul(x, t)))
	if k == 0 {
		return x - (fmul(x, e) - hxs) }
	e = fmul(x, e-c) - c
	e = e - hxs
	if k == -1 {
		return fmul(0.5, x-e) - 0.5 }
	if k == 1 {
		if x < -0.25 {
			return fmul(-2.0, e-(x+0.5)) }
		return 1.0 + fmul(2.0, x-e) }
	if k <= -2 || k > 56 {
		y = 1.0 - (e - x)
		y = fdSetHi(y, fdHi(y)+k<<20)
		return y - 1.0 }
	t = 1.0
	if k < 20 {

		t = fdSetHi(t, 1072693248-int32(2097152)>>k)
		y = t - (e - x)
		y = fdSetHi(y, fdHi(y)+k<<20) } else {

			t = fdSetHi(t, (1023-k)<<20)
			y = x - (e + t)
			y = y + 1.0
			y = fdSetHi(y, fdHi(y)+k<<20)
		}
	return y
}

// fdSinh is FdLibm.Sinh.compute (StrictMath.sinh).
func fdSinh(x float64) float64 {
	jx := fdHi(x)
	ix := jx & 2147483647
	h := 0.5
	if ix >= 2146435072 {
		return x + x }
	if jx < 0 {
		h = -h }
	if ix < 1077280768 {
		if ix < 1043333120 && 1.0e307+x > 1.0 {
			return x }
		t := fdExpm1(math.Abs(x))
		if ix < 1072693248 {
			return fmul(h, fmul(2.0, t)-fmul(t, t)/(t+1.0)) }
		return fmul(h, t+t/(t+1.0)) }
	if ix < 1082535490 {
		return fmul(h, fdExp(math.Abs(x))) }
	if ix < 1082536910 || ix == 1082536910 && uint32(fdLo(x)) <= 2411329661 {
		w := fdExp(fmul(0.5, math.Abs(x)))
		t := fmul(h, w)
		return fmul(t, w) }
	return fmul(x, 1.0e307) }
// fdCosh is FdLibm.Cosh.compute (StrictMath.cosh).
func fdCosh(x float64) float64 {
	ix := fdHi(x) & 2147483647
	if ix >= 2146435072 {
		return fmul(x, x) }
	if ix < 1071001155 {
		t := fdExpm1(math.Abs(x))
		w := 1.0 + t
		if ix < 1015021568 {
			return w }
		return 1.0 + fmul(t, t)/(w+w) }
	if ix < 1077280768 {
		t := fdExp(math.Abs(x))
		return fmul(0.5, t) + 0.5/t }
	if ix < 1082535490 {
		return fmul(0.5, fdExp(math.Abs(x))) }
	if ix < 1082536910 || ix == 1082536910 && uint32(fdLo(x)) <= 2411329661 {
		w := fdExp(fmul(0.5, math.Abs(x)))
		t := fmul(0.5, w)
		return fmul(t, w)
	}; return PosInf64 }
// fdTanh is FdLibm.Tanh.compute (StrictMath.tanh).
func fdTanh(x float64) float64 {
	jx := fdHi(x)
	ix := jx & 2147483647
	z := 0.0
	if ix >= 2146435072 {
		if jx >= 0 {
			return 1.0/x + 1.0 }
		return 1.0/x - 1.0 }
	if ix < 1077280768 {

		if ix < 1015021568 {
			return fmul(x, 1.0+x) }
		if ix >= 1072693248 {
			t := fdExpm1(fmul(2.0, math.Abs(x)))
			z = 1.0 - 2.0/(t+2.0) } else {
				t := fdExpm1(fmul(-2.0, math.Abs(x)))
				z = -t / (t + 2.0) } } else {
					z = 1.0 }
	if jx >= 0 {
		return z }
	return -z
}



func fdSignedZero(sign int32) float64 { return fmul(0.0, float64(sign)) }

func fdIlogb(hz, lz int32) int32 {
	iz := int32(0)
	if hz < 1048576 {
		if hz == 0 {

			iz = -1043
			for i := lz; i > 0; i = i << 1 {
				iz = iz - 1 } } else {

					iz = -1022
					for i := hz << 11; i > 0; i = i << 1 {
						iz = iz - 1 } } } else {
							iz = hz>>20 - 1023
						}; return iz }
// fdFmod is FdLibm.IEEEremainder.__ieee754_fmod.
func fdFmod(x, y float64) float64 {
	hx := fdHi(x)
	lx := fdLo(x)
	hy := fdHi(y)
	ly := fdLo(y)
	sx := hx & int32(-2147483648)
	n := int32(0)
	hz := int32(0)
	lz := int32(0)
	hx = hx ^ sx
	hy = hy & 2147483647
	if hy|ly == 0 || hx >= 2146435072 ||
		hy|fdUshr(ly|-ly, 31) > 2146435072 {
			return fmul(x, y) / fmul(x, y) }
	if hx <= hy {
		if hx < hy || uint32(lx) < uint32(ly) {
			return x }
		if lx == ly {
			return fdSignedZero(sx) } }
	ix := fdIlogb(hx, lx)
	iy := fdIlogb(hy, ly)
	if ix >= -1022 {
		hx = 1048576 | 1048575&hx } else {

			n = -1022 - ix
			if n <= 31 {

				hx = hx<<n | fdUshr(lx, 32-n)
				lx = lx << n } else {

					hx = lx << (n - 32)
					lx = 0 } }
	if iy >= -1022 {
		hy = 1048576 | 1048575&hy } else {

			n = -1022 - iy
			if n <= 31 {

				hy = hy<<n | fdUshr(ly, 32-n)
				ly = ly << n } else {

					hy = ly << (n - 32)
					ly = 0 } }
	n = ix - iy
	for n != 0 {
		n--
		hz = hx - hy
		lz = lx - ly
		if uint32(lx) < uint32(ly) {
			hz = hz - 1 }
		if hz < 0 {

			hx = hx + hx + fdUshr(lx, 31)
			lx = lx + lx } else {

				if hz|lz == 0 {
					return fdSignedZero(sx) }
				hx = hz + hz + fdUshr(lz, 31)
				lx = lz + lz } }
	hz = hx - hy
	lz = lx - ly
	if uint32(lx) < uint32(ly) {
		hz = hz - 1 }
	if hz >= 0 {
		hx = hz
		lx = lz }
	if hx|lx == 0 {
		return fdSignedZero(sx) }
	for hx < 1048576 {
		hx = hx + hx + fdUshr(lx, 31)
		lx = lx + lx
		iy = iy - 1 }
	if iy >= -1022 {

		hx = hx - 1048576 | (iy+1023)<<20
		x = fdHiLo(hx|sx, lx) } else {

			n = -1022 - iy
			if
				n <= 20 {
					lx = fdUshr(lx, n) | hx<<(32-n)
					hx = hx >> n
				} else if n <= 31 {
					lx = hx<<(32-n) | fdUshr(lx, n)
					hx = sx
				} else {
					lx = hx >> (n - 32)
					hx = sx }
			x = fdHiLo(hx|sx, lx)
			x = fmul(x, 1.0)
		}; return x }
// fdIEEEremainder is FdLibm.IEEEremainder.compute (StrictMath.IEEEremainder).
func fdIEEEremainder(x, p float64) float64 {

	hx := fdHi(x)
	lx := fdLo(x)
	hp := fdHi(p)
	lp := fdLo(p)
	sx := hx & int32(-2147483648)
	hp = hp & 2147483647
	hx = hx & 2147483647
	if hp|lp == 0 {
		return fmul(x, p) / fmul(x, p) }
	if hx >= 2146435072 || hp >= 2146435072 && hp-2146435072|lp != 0 {
		return fmul(x, p) / fmul(x, p) }
	if hp <= 2145386495 {
		x = fdFmod(x, p+p) }
	if hx-hp|(lx-lp) == 0 {
		return fmul(0.0, x) }
	x = math.Abs(x)
	p = math.Abs(p)
	if hp < 2097152 {
		if x+x > p {
			x = x - p
			if x+x >= p {
				x = x - p } } } else {
					pHalf := fmul(0.5, p)
					if x > pHalf {
						x = x - p
						if x >= pHalf {
							x = x - p } } }
	return fdSetHi(x, fdHi(x)^sx)
}
