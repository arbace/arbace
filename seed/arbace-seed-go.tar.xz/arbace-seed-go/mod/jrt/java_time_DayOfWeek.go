//line java_time_DayOfWeek.ae:1
package jrt























func DayOfWeek_Of_I__DayOfWeek(dayOfWeek int32) *DayOfWeek { DayOfWeek_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = dayOfWeek < 1; if !tmp2 { tmp2 = dayOfWeek > 7 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2006, StrOfInt(dayOfWeek))))) }
	return As[*DayOfWeek](DayOfWeek_ENUMS.A[dayOfWeek-1])
}
func DayOfWeek_From_TemporalAccessor__DayOfWeek(temporal TemporalAccessor) *DayOfWeek { DayOfWeek_Init()
	if DayOfWeek_InstanceOf(temporal) {
		return DayOfWeek_Cast(temporal) } else {
			var tmp1 *DayOfWeek; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_DAY_OF_WEEK; tmp1 = DayOfWeek_Of_I__DayOfWeek(temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2))) }; return nil }()
//line :33:1
			if tmp3 != nil { if DateTimeException_InstanceOf(tmp3) { var ex DateTimeException_I = DateTimeException_Cast(tmp3)


				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2007, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :33:1
					panic(tmp3) } }; return tmp1
		}
}







func (t *DayOfWeek) GetValue__I() int32 {
	return t.Ordinal__I() + 1
}
func (t *DayOfWeek) GetDisplayName_TextStyle_Locale__String(style *TextStyle, locale *Locale) *String {
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_DAY_OF_WEEK; return NN(NN(tmp1.AppendText_TemporalField_TextStyle__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp2), style)).ToFormatter_Locale__DateTimeFormatter(locale)).Format_TemporalAccessor__String(t)
}


func (t *DayOfWeek) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; return any(field) == any(tmp1.Ref()) } else {
			var tmp2 bool; tmp2 = !(field == nil); if tmp2 { tmp2 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp2
		} }
func (t *DayOfWeek) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; if any(field) == any(tmp1.Ref()) {
		return field.Range__ValueRange() } else {
			return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
		} }
func (t *DayOfWeek) Get_TemporalField__I(field TemporalField) int32 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; if any(field) == any(tmp1.Ref()) {
		return t.GetValue__I() } else {
			return TemporalAccessor_Get_TemporalField__I(t, field)
		} }
func (t *DayOfWeek) GetLong_TemporalField__J(field TemporalField) int64 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; if any(field) == any(tmp1.Ref()) { return int64(t.GetValue__I()) } else {


		if ChronoField_InstanceOf(field) {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
		return field.GetFrom_TemporalAccessor__J(t)
	} }
func (t *DayOfWeek) Plus_J__DayOfWeek(days int64) *DayOfWeek {
	var amount int32 = int32(days % 7); var tmp1 *RefArray = DayOfWeek_ENUMS
	return As[*DayOfWeek](tmp1.A[(t.Ordinal__I()+(amount+7))%7])
}



func (t *DayOfWeek) Minus_J__DayOfWeek(days int64) *DayOfWeek {
	return t.Plus_J__DayOfWeek(-(days % 7))
}
func (t *DayOfWeek) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_DAYS.Ref() } else {

		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	} }
func (t *DayOfWeek) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_DAY_OF_WEEK; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); return temporal.With_TemporalField_J__Temporal(tmp2, int64(t.GetValue__I()))
}


type DayOfWeek struct{ Enum }

func (t *DayOfWeek) Is_TemporalAccessor() {}

func (t *DayOfWeek) Is_TemporalAdjuster() {}

func (t *DayOfWeek) Is_Constable() {}

var DayOfWeek_MONDAY *DayOfWeek

var DayOfWeek_TUESDAY *DayOfWeek

var DayOfWeek_WEDNESDAY *DayOfWeek

var DayOfWeek_THURSDAY *DayOfWeek

var DayOfWeek_FRIDAY *DayOfWeek

var DayOfWeek_SATURDAY *DayOfWeek

var DayOfWeek_SUNDAY *DayOfWeek

var DayOfWeek__VALUES *RefArray

var DayOfWeek_ENUMS *RefArray

var DayOfWeek_init ClassInit

func DayOfWeek_Init() { if !DayOfWeek_init.Done() { DayOfWeek_init.Run(DayOfWeek_clinit) } }

func DayOfWeek_clinit() { DayOfWeek_MONDAY = DayOfWeek_New_String_I(Lit_1999, 0); DayOfWeek_TUESDAY = DayOfWeek_New_String_I(Lit_2000, 1); DayOfWeek_WEDNESDAY = DayOfWeek_New_String_I(Lit_2001, 2); DayOfWeek_THURSDAY = DayOfWeek_New_String_I(Lit_2002, 3); DayOfWeek_FRIDAY = DayOfWeek_New_String_I(Lit_2003, 4); DayOfWeek_SATURDAY = DayOfWeek_New_String_I(Lit_2004, 5); DayOfWeek_SUNDAY = DayOfWeek_New_String_I(Lit_2005, 6); DayOfWeek__VALUES = DayOfWeek_X_values__DayOfWeek1(); DayOfWeek_ENUMS = DayOfWeek_Values__DayOfWeek1() }

func DayOfWeek_New_String_I(p0 *String, p1 int32) *DayOfWeek { DayOfWeek_Init(); t := &DayOfWeek{}; t.Ctor_String_I(p0, p1); return t }

func (t *DayOfWeek) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func DayOfWeek_Values__DayOfWeek1() *RefArray { DayOfWeek_Init(); return DayOfWeek__VALUES.Copy() }

func DayOfWeek_ValueOf_String__DayOfWeek(p0 *String) *DayOfWeek { DayOfWeek_Init(); return DayOfWeek_Cast(Enum_ValueOf_Class_String__Enum(DayOfWeek_class, p0)) }

func DayOfWeek_X_values__DayOfWeek1() *RefArray { DayOfWeek_Init(); return RefArrayOf(DayOfWeek_class, DayOfWeek_MONDAY, DayOfWeek_TUESDAY, DayOfWeek_WEDNESDAY, DayOfWeek_THURSDAY, DayOfWeek_FRIDAY, DayOfWeek_SATURDAY, DayOfWeek_SUNDAY) }

func (t *DayOfWeek) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.DayOfWeek.describeConstable()Ljava/util/Optional;")) }

func (t *DayOfWeek) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *DayOfWeek) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *DayOfWeek) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *DayOfWeek) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *DayOfWeek) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DayOfWeek) Ref() any { if t == nil { return nil }; return t }

func (t *DayOfWeek) GetClass__Class() *Class { return DayOfWeek_class }

func (t *DayOfWeek) CloneShallow() any { panic(CloneNotSupported(t)) }

func DayOfWeek_InstanceOf(x any) bool { _, ok := x.(*DayOfWeek); return ok }

func DayOfWeek_Cast(x any) *DayOfWeek { if x == nil { return nil }; v, ok := x.(*DayOfWeek); if !ok { panic(ClassCast(x, DayOfWeek_class)) }; return v }
