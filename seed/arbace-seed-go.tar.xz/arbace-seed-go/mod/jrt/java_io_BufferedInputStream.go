//line java_io_BufferedInputStream.ae:1
package jrt

import "sync/atomic"





























func (t *BufferedInputStream) Impl_GetInIfOpen__InputStream(this BufferedInputStream_I) InputStream_I {
	var input InputStream_I = t.F_in.Load(); if input == nil { panic(Thrown(IOException_New_String(Lit_48))) }; return input
}
func (t *BufferedInputStream) Impl_GetBufIfOpen_Z__B1(this BufferedInputStream_I, allocateIfEmpty bool) *ByteArray {
	var buffer *ByteArray = t.F_buf.Load(); var tmp1 bool; var tmp2 bool
	tmp2 = allocateIfEmpty; if tmp2 { tmp2 = buffer == BufferedInputStream_EMPTY }; tmp1 = tmp2; if tmp1 {
		buffer = NewByteArray(t.F_initialSize)
		if NN(BufferedInputStream_U).CompareAndSetReference_O_J_O_O__Z(this, BufferedInputStream_BUF_OFFSET, BufferedInputStream_EMPTY.Ref(), buffer.Ref()) { } else { buffer = t.F_buf.Load() } }
	if buffer == nil { panic(Thrown(IOException_New_String(Lit_48))) }
//line :37:1
	return buffer
}





func (t *BufferedInputStream) Impl_GetBufIfOpen__B1(this BufferedInputStream_I) *ByteArray {
	return t.Impl_GetBufIfOpen_Z__B1(this, true)
}
func (t *BufferedInputStream) Impl_EnsureOpen__V(this BufferedInputStream_I) {
	if t.F_buf.Load() == nil { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func BufferedInputStream_New_InputStream(p0 InputStream_I) *BufferedInputStream { BufferedInputStream_Init(); t := &BufferedInputStream{}; t.Ctor_InputStream(t, p0); return t }
//line :50:1
func (t *BufferedInputStream) Ctor_InputStream(this BufferedInputStream_I, in InputStream_I) { t.Ctor_InputStream_I(this, in, 8192) }


func BufferedInputStream_New_InputStream_I(p0 InputStream_I, p1 int32) *BufferedInputStream { BufferedInputStream_Init(); t := &BufferedInputStream{}; t.Ctor_InputStream_I(t, p0, p1); return t }
//line :53:1
func (t *BufferedInputStream) Ctor_InputStream_I(this BufferedInputStream_I, in InputStream_I, size int32) { t.FilterInputStream.Ctor_InputStream(this, in); t.F_markpos = -1

	if size <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_47))) }
	t.F_initialSize = size
	if this.GetClass__Class() == BufferedInputStream_class {
		t.F_buf.Store(BufferedInputStream_EMPTY) } else {
			t.F_buf.Store(NewByteArray(size))
		} }
func (t *BufferedInputStream) Impl_Fill__V(this BufferedInputStream_I) {
	var buffer *ByteArray = t.Impl_GetBufIfOpen__B1(this)
	if t.F_markpos == -1 {
		t.F_pos = 0 } else {
//line :63:1
			var tmp1 int32 = t.F_pos; if tmp1 >= int32(len(buffer.A)) {


				if t.F_markpos > 0 {

					var sz int32 = t.F_pos - t.F_markpos
					System_Arraycopy_O_I_O_I_I__V(buffer.Ref(), t.F_markpos, buffer.Ref(), 0, sz)
					t.F_pos = sz
					t.F_markpos = 0 } else {
//line :66:1
						if int32(len(buffer.A)) >= t.F_marklimit {





							t.F_markpos = -1; t.F_pos = 0 } else {

								var nsz int32 = ArraysSupport_NewLength_I_I_I__I(t.F_pos, 1, t.F_pos)
								if nsz > t.F_marklimit { nsz = t.F_marklimit }
								var nbuf *ByteArray = NewByteArray(nsz)
								System_Arraycopy_O_I_O_I_I__V(buffer.Ref(), 0, nbuf.Ref(), 0, t.F_pos)
								if NN(BufferedInputStream_U).CompareAndSetReference_O_J_O_O__Z(this, BufferedInputStream_BUF_OFFSET, buffer.Ref(), nbuf.Ref()) { } else {
									panic(Thrown(IOException_New_String(Lit_48))) }
								buffer = nbuf } } } }
	t.F_count = t.F_pos
	var tmp2 InputStream_I = t.Impl_GetInIfOpen__InputStream(this); var tmp3 *ByteArray = buffer; var tmp4 int32 = t.F_pos; var n int32 = tmp2.Read_B1_I_I__I(tmp3, tmp4, int32(len(buffer.A))-t.F_pos)
	if n > 0 { t.F_count = n + t.F_pos
	} }
func (t *BufferedInputStream) Impl_Read__I(this BufferedInputStream_I) int32 { MonitorEnter(this); defer MonitorExit(this)
	if t.F_pos >= t.F_count { t.Impl_Fill__V(this); if t.F_pos >= t.F_count { return -1 } }
	var tmp1 *ByteArray = t.Impl_GetBufIfOpen__B1(this); var tmp2 int32; var old_1 int32 = t.F_pos
	t.F_pos = t.F_pos + 1; tmp2 = old_1
//line :87:1
	return int32(tmp1.A[tmp2]) & 255
}


func (t *BufferedInputStream) Impl_Read1_B1_I_I__I(this BufferedInputStream_I, b *ByteArray, off, len_ int32) int32 {
	var avail int32 = t.F_count - t.F_pos
	if avail <= 0 {
		var size int32 = Math_Max_I_I__I(int32(len(t.Impl_GetBufIfOpen_Z__B1(this, false).A)), t.F_initialSize); var tmp1 bool; var tmp2 bool
		tmp2 = len_ >= size; if tmp2 { tmp2 = t.F_markpos == -1 }; tmp1 = tmp2; if tmp1 { return t.Impl_GetInIfOpen__InputStream(this).Read_B1_I_I__I(b, off, len_) }
		t.Impl_Fill__V(this)
		avail = t.F_count - t.F_pos
		if avail <= 0 { return -1 } }
	var cnt int32; if avail < len_ { cnt = avail } else { cnt = len_ }
	System_Arraycopy_O_I_O_I_I__V(t.Impl_GetBufIfOpen__B1(this).Ref(), t.F_pos, b.Ref(), off, cnt)
	t.F_pos = t.F_pos + cnt
//line :99:1
	return cnt
}



func (t *BufferedInputStream) Impl_Read_B1_I_I__I(this BufferedInputStream_I, b *ByteArray, off, len_ int32) int32 { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_EnsureOpen__V(this)
	if off|len_|(off+len_)|(int32(len(b.A))-(off+len_)) < 0 {



		panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :106:1
			if len_ == 0 {




				return 0 } }
	{ var n int32 = 0
	L1: for {
		var nread int32 = t.Impl_Read1_B1_I_I__I(this, b, off+n, len_-n)
		if nread <= 0 { var tmp1 int32; if n == 0 { tmp1 = nread } else { tmp1 = n }; return tmp1 }
		n = n + nread
		if n >= len_ { return n }
		var input InputStream_I = t.F_in.Load(); var tmp2 bool; var tmp3 bool; tmp3 = !(input == nil); if tmp3 { tmp3 = input.Available__I() <= 0 }; tmp2 = tmp3; if tmp2 { return n }
//line :113:1
		continue L1
	}
	}


	panic("a2g: unreachable")
}
func (t *BufferedInputStream) Impl_Skip_J__J(this BufferedInputStream_I, n int64) int64 { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_EnsureOpen__V(this)
	if n <= 0 { return 0 } else {

		var avail int64 = int64(t.F_count - t.F_pos)
		if avail <= 0 {
			if t.F_markpos == -1 { return t.Impl_GetInIfOpen__InputStream(this).Skip_J__J(n) }
			t.Impl_Fill__V(this)
			avail = int64(t.F_count - t.F_pos)
			if avail <= 0 { return 0 } }
		var skipped int64; if avail < n { skipped = avail } else { skipped = n }
		t.F_pos = t.F_pos + int32(skipped)
//line :130:1
		return skipped
	}
}

func (t *BufferedInputStream) Impl_Available__I(this BufferedInputStream_I) int32 { MonitorEnter(this); defer MonitorExit(this)
	var n int32 = t.F_count - t.F_pos; var avail int32 = t.Impl_GetInIfOpen__InputStream(this).Available__I()

	if n > 2147483647-avail { return 2147483647 } else {

		return n + avail
	} }
func (t *BufferedInputStream) Impl_Mark_I__V(this BufferedInputStream_I, readlimit int32) { MonitorEnter(this); defer MonitorExit(this)
	t.F_marklimit = readlimit
	t.F_markpos = t.F_pos
}
func (t *BufferedInputStream) Impl_Reset__V(this BufferedInputStream_I) { MonitorEnter(this); defer MonitorExit(this)
	t.Impl_EnsureOpen__V(this)
	if t.F_markpos < 0 { panic(Thrown(IOException_New_String(Lit_49))) }
	t.F_pos = t.F_markpos
}
func (t *BufferedInputStream) Impl_MarkSupported__Z(this BufferedInputStream_I) bool { return true }

func (t *BufferedInputStream) Impl_Close__V(this BufferedInputStream_I) {
	var buffer *ByteArray
L1: for { var tmp1 *ByteArray; buffer = t.F_buf.Load(); tmp1 = buffer; if !(tmp1 == nil) {
	if NN(BufferedInputStream_U).CompareAndSetReference_O_J_O_O__Z(this, BufferedInputStream_BUF_OFFSET, buffer.Ref(), nil) {
		var input InputStream_I = t.F_in.Load()
		t.F_in.Store(nil)
		if !(input == nil) { input.Close__V() }
		return }
//line :154:1
	continue L1 }; break L1
}
}




func (t *BufferedInputStream) Impl_TransferTo_OutputStream__J(this BufferedInputStream_I, out OutputStream_I) int64 { MonitorEnter(this); defer MonitorExit(this)
	Objects_RequireNonNull_O_String__O(out, Lit_50)
	var tmp1 bool; var tmp2 bool; tmp2 = this.GetClass__Class() == BufferedInputStream_class; if tmp2 { tmp2 = t.F_markpos == -1 }; tmp1 = tmp2; if tmp1 {
		var avail int32 = t.F_count - t.F_pos
		if avail > 0 {
			if BufferedInputStream_IsTrusted_OutputStream__Z(out) {
				out.Write_B1_I_I__V(t.Impl_GetBufIfOpen__B1(this), t.F_pos, avail) } else {
					var buffer *ByteArray = Arrays_CopyOfRange_B1_I_I__B1(t.Impl_GetBufIfOpen__B1(this), t.F_pos, t.F_count)
					out.Write_B1__V(buffer) }
			t.F_pos = t.F_count }
		var tmp3 int64; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
			tmp3 = Math_AddExact_J_J__J(int64(avail), t.Impl_GetInIfOpen__InputStream(this).TransferTo_OutputStream__J(out)); return nil }()
//line :171:1
		if tmp4 != nil { if ArithmeticException_InstanceOf(tmp4) { var ignore *ArithmeticException = ArithmeticException_Cast(tmp4); _ = ignore; tmp3 = 9223372036854775807 } else { panic(tmp4) } }; return tmp3 } else {


			return t.FilterInputStream.Impl_TransferTo_OutputStream__J(this, out)
		} }
func BufferedInputStream_IsTrusted_OutputStream__Z(os OutputStream_I) bool { BufferedInputStream_Init()
	var clazz *Class = os.GetClass__Class(); var tmp1 bool; var tmp2 bool
	tmp2 = clazz == ByteArrayOutputStream_class; if !tmp2 { tmp2 = clazz == FileOutputStream_class }; tmp1 = tmp2; if !tmp1 {
		tmp1 = clazz == PipedOutputStream_class }
//line :178:1
	return tmp1
}



type BufferedInputStream struct{ FilterInputStream; F_initialSize int32; F_buf atomic.Pointer[ByteArray]; F_count, F_pos, F_markpos, F_marklimit int32 }

type BufferedInputStream_I interface{ FilterInputStream_I; Closeable; AutoCloseable; Self_BufferedInputStream() *BufferedInputStream; Read__I() int32; Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32; Skip_J__J(p0 int64) int64; Available__I() int32; Mark_I__V(p0 int32); Reset__V(); MarkSupported__Z() bool; Close__V(); TransferTo_OutputStream__J(p0 OutputStream_I) int64 }

func (t *BufferedInputStream) Self_BufferedInputStream() *BufferedInputStream { return t }

const BufferedInputStream_DEFAULT_BUFFER_SIZE int32 = 8192

var BufferedInputStream_EMPTY *ByteArray

var BufferedInputStream_U *Unsafe

var BufferedInputStream_BUF_OFFSET int64

var BufferedInputStream_init ClassInit

func BufferedInputStream_Init() { if !BufferedInputStream_init.Done() { BufferedInputStream_init.Run(BufferedInputStream_clinit) } }

func BufferedInputStream_clinit() { BufferedInputStream_EMPTY = NewByteArray(0); BufferedInputStream_U = Unsafe_GetUnsafe__Unsafe(); BufferedInputStream_BUF_OFFSET = NN(BufferedInputStream_U).ObjectFieldOffset_Class_String__J(BufferedInputStream_class, Lit_46) }

func (t *BufferedInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *BufferedInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *BufferedInputStream) Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_Read_B1_I_I__I(t, p0, p1, p2) }

func (t *BufferedInputStream) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *BufferedInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *BufferedInputStream) Close__V() { t.Impl_Close__V(t) }

func (t *BufferedInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *BufferedInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *BufferedInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *BufferedInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *BufferedInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *BufferedInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *BufferedInputStream) Available__I() int32 { return t.Impl_Available__I(t) }

func (t *BufferedInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *BufferedInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *BufferedInputStream) GetClass__Class() *Class { return BufferedInputStream_class }

func (t *BufferedInputStream) ToString__String() *String { return Object_toString(t) }

func (t *BufferedInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BufferedInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func BufferedInputStream_InstanceOf(x any) bool { _, ok := x.(BufferedInputStream_I); return ok }

func BufferedInputStream_Cast(x any) BufferedInputStream_I { if x == nil { return nil }; v, ok := x.(BufferedInputStream_I); if !ok { panic(ClassCast(x, BufferedInputStream_class)) }; return v }
