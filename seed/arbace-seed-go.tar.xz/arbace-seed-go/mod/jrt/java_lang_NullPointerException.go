//line java_lang_NullPointerException.ae:1
package jrt








func NullPointerException_New() *NullPointerException { t := &NullPointerException{}; t.Ctor(); return t }
//line :10:1
func (t *NullPointerException) Ctor() { t.RuntimeException.Ctor(t) }

func NullPointerException_New_String(p0 *String) *NullPointerException { t := &NullPointerException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NullPointerException) Ctor_String(s *String) { t.RuntimeException.Ctor_String(t, s) }





func (t *NullPointerException) FillInStackTrace__Throwable() Throwable_I { MonitorEnter(t); defer MonitorExit(t)
	if t.F_extendedMessageState == 0 {
		t.F_extendedMessageState = 1 } else {
			if t.F_extendedMessageState == 1 {
				t.F_extendedMessage = t.GetExtendedNPEMessage__String()
				t.F_extendedMessageState = 2 } }
	return t.RuntimeException.Impl_FillInStackTrace__Throwable(t)
}
func (t *NullPointerException) GetMessage__String() *String {
	var message *String = t.RuntimeException.Impl_GetMessage__String(t)
	if message == nil {
		var tmp1 any = t; MonitorEnter(tmp1); tmp2, tmp3 := func() (ctl int32, rv *String) { defer MonitorExit(tmp1)
			if t.F_extendedMessageState == 1 {
				t.F_extendedMessage = t.GetExtendedNPEMessage__String()
				t.F_extendedMessageState = 2 }; return 2, t.F_extendedMessage; return 0, nil }()
//line :29:1
		switch tmp2 { case 2: { return tmp3 }} }
//line :27:1
	return message
}







func (t *NullPointerException) GetExtendedNPEMessage__String() *String { return NullPointerException_GetExtendedNPEMessage__String_native(t) }



type NullPointerException struct{ RuntimeException; F_extendedMessageState int32; F_extendedMessage *String }

const NullPointerException_serialVersionUID int64 = 5162710183389028792

func (t *NullPointerException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NullPointerException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NullPointerException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NullPointerException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NullPointerException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NullPointerException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NullPointerException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NullPointerException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NullPointerException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NullPointerException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NullPointerException) Ref() any { if t == nil { return nil }; return t }

func (t *NullPointerException) GetClass__Class() *Class { return NullPointerException_class }

func (t *NullPointerException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NullPointerException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NullPointerException_InstanceOf(x any) bool { _, ok := x.(*NullPointerException); return ok }

func NullPointerException_Cast(x any) *NullPointerException { if x == nil { return nil }; v, ok := x.(*NullPointerException); if !ok { panic(ClassCast(x, NullPointerException_class)) }; return v }
