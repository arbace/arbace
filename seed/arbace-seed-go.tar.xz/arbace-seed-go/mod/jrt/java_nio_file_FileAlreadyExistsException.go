//line java_nio_file_FileAlreadyExistsException.ae:1
package jrt








func FileAlreadyExistsException_New_String(p0 *String) *FileAlreadyExistsException { t := &FileAlreadyExistsException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *FileAlreadyExistsException) Ctor_String(file *String) { t.FileSystemException.Ctor_String(t, file) }

func FileAlreadyExistsException_New_String_String_String(p0, p1, p2 *String) *FileAlreadyExistsException { t := &FileAlreadyExistsException{}; t.Ctor_String_String_String(p0, p1, p2); return t }
//line :12:1
func (t *FileAlreadyExistsException) Ctor_String_String_String(file, other, reason *String) { t.FileSystemException.Ctor_String_String_String(t, file, other, reason) }







type FileAlreadyExistsException struct{ FileSystemException }

const FileAlreadyExistsException_serialVersionUID int64 = 7579540934498831181

func (t *FileAlreadyExistsException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *FileAlreadyExistsException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *FileAlreadyExistsException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *FileAlreadyExistsException) GetFile__String() *String { return t.Impl_GetFile__String(t) }

func (t *FileAlreadyExistsException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *FileAlreadyExistsException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *FileAlreadyExistsException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *FileAlreadyExistsException) GetReason__String() *String { return t.Impl_GetReason__String(t) }

func (t *FileAlreadyExistsException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *FileAlreadyExistsException) GetOtherFile__String() *String { return t.Impl_GetOtherFile__String(t) }

func (t *FileAlreadyExistsException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *FileAlreadyExistsException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *FileAlreadyExistsException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *FileAlreadyExistsException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *FileAlreadyExistsException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *FileAlreadyExistsException) Ref() any { if t == nil { return nil }; return t }

func (t *FileAlreadyExistsException) GetClass__Class() *Class { return FileAlreadyExistsException_class }

func (t *FileAlreadyExistsException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileAlreadyExistsException) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileAlreadyExistsException_InstanceOf(x any) bool { _, ok := x.(*FileAlreadyExistsException); return ok }

func FileAlreadyExistsException_Cast(x any) *FileAlreadyExistsException { if x == nil { return nil }; v, ok := x.(*FileAlreadyExistsException); if !ok { panic(ClassCast(x, FileAlreadyExistsException_class)) }; return v }
