//line java_util_ComparableTimSort.ae:1
package jrt


























func ComparableTimSort_New_O1_O1_I_I(p0, p1 *RefArray, p2, p3 int32) *ComparableTimSort { ComparableTimSort_Init(); t := &ComparableTimSort{}; t.Ctor_O1_O1_I_I(p0, p1, p2, p3); return t }
//line :28:1
func (t *ComparableTimSort) Ctor_O1_O1_I_I(a, work *RefArray, workBase, workLen int32) { t.F_minGallop = 7; t.F_stackSize = 0
	t.F_a = a
	var len_ int32 = int32(len(a.A)); var tlen int32
	if len_ < 512 {
		tlen = int32(uint32(len_) >> 1) } else {
//line :31:1
			tlen = 256
		}

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = work == nil; if !tmp3 { tmp3 = workLen < tlen }; tmp2 = tmp3; if !tmp2 {
		tmp2 = workBase+tlen > int32(len(work.A)) }
//line :34:1
	tmp1 = tmp2; if tmp1 {

		t.F_tmp = NewRefArray(Object_class, tlen); t.F_tmpBase = 0; t.F_tmpLen = tlen } else {
			t.F_tmp = work; t.F_tmpBase = workBase; t.F_tmpLen = workLen }
	var stackLen int32; if len_ < 120 { stackLen = 5 } else { if len_ < 1542 { stackLen = 10 } else { if len_ < 119151 { stackLen = 24 } else { stackLen = 49 } } }
	t.F_runBase = NewIntArray(stackLen)
	t.F_runLen = NewIntArray(stackLen)
}
func ComparableTimSort_Sort_O1_I_I_O1_I_I__V(a *RefArray, lo, hi int32, work *RefArray, workBase, workLen int32) { ComparableTimSort_Init()

	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = !(a == nil); if tmp4 { tmp4 = lo >= 0 }; tmp3 = tmp4; if tmp3 { tmp3 = lo <= hi }; tmp2 = tmp3; if tmp2 { tmp2 = hi <= int32(len(a.A)) }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var nRemaining int32 = hi - lo
	if nRemaining < 2 { } else {
		if nRemaining < 32 {
			var initRunLen int32 = ComparableTimSort_CountRunAndMakeAscending_O1_I_I__I(a, lo, hi)
			ComparableTimSort_BinarySort_O1_I_I_I__V(a, lo, hi, lo+initRunLen) } else {
				var ts *ComparableTimSort = ComparableTimSort_New_O1_O1_I_I(a, work, workBase, workLen); var minRun int32 = ComparableTimSort_MinRunLength_I__I(nRemaining)

			L1: for {
				var runLen int32 = ComparableTimSort_CountRunAndMakeAscending_O1_I_I__I(a, lo, hi)
				if runLen < minRun {
					var force int32; if nRemaining <= minRun { force = nRemaining } else { force = minRun }
					ComparableTimSort_BinarySort_O1_I_I_I__V(a, lo, lo+force, lo+runLen)




					runLen = force }
				NN(ts).PushRun_I_I__V(lo, runLen)
				NN(ts).MergeCollapse__V()
				lo = lo + runLen
				nRemaining = nRemaining - runLen
				if nRemaining == 0 { } else { continue L1 }
//line :52:1
				break L1
			}













				if !A2g_AssertionsDisabled && !(lo == hi) { panic(Thrown(AssertionError_New())) }
				NN(ts).MergeForceCollapse__V()
				if !A2g_AssertionsDisabled && !(ts.F_stackSize == 1) { panic(Thrown(AssertionError_New()))
				} } } }
func ComparableTimSort_BinarySort_O1_I_I_I__V(a *RefArray, lo, hi, start int32) { ComparableTimSort_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = lo <= start; if tmp2 { tmp2 = start <= hi }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	if start == lo { start = start + 1 }
L1: for { if start < hi {
	var pivot Comparable = Comparable_Cast(a.A[start])
	var left int32 = lo
	var right int32 = start
	if !A2g_AssertionsDisabled && !(left <= right) { panic(Thrown(AssertionError_New())) }
L2: for { if left < right {
	var mid int32 = int32(uint32(left+right) >> 1)
	if pivot.CompareTo_O__I(a.A[mid]) < 0 {
		right = mid } else {
			left = mid + 1 }
//line :79:1
	continue L2 }; break L2
}



	if !A2g_AssertionsDisabled && !(left == right) { panic(Thrown(AssertionError_New())) }
	var n int32 = start - left
	switch n { case 2:


		a.Store(left+2, a.A[left+1])
		a.Store(left+1, a.A[left]); case 1:
		a.Store(left+1, a.A[left]); default:
		System_Arraycopy_O_I_O_I_I__V(a.Ref(), left, a.Ref(), left+1, n)}
	a.Store(left, pivot)
	start = start + 1
//line :74:1
	continue L1 }; break L1
}
}



















func ComparableTimSort_CountRunAndMakeAscending_O1_I_I__I(a *RefArray, lo, hi int32) int32 { ComparableTimSort_Init()
	if !A2g_AssertionsDisabled && !(lo < hi) { panic(Thrown(AssertionError_New())) }
	var runHi int32 = lo + 1
	if runHi == hi { return 1 } else {


		var tmp1 int32
		var old_1 int32 = runHi

		runHi = runHi + 1
//line :104:1
		tmp1 = old_1
//line :102:1
		var tmp2 Comparable = Comparable_Cast(a.A[tmp1]); if tmp2.CompareTo_O__I(a.A[lo]) < 0 {







		L1: for { var tmp3 bool; var tmp4 bool; tmp4 = runHi < hi; if tmp4 {
			var tmp5 Comparable = Comparable_Cast(a.A[runHi]); tmp4 = tmp5.CompareTo_O__I(a.A[runHi-1]) < 0 }
//line :110:1
			tmp3 = tmp4; if tmp3 {



				runHi = runHi + 1
//line :110:1
				continue L1 }; break L1
		}



			ComparableTimSort_ReverseRange_O1_I_I__V(a, lo, runHi) } else {
			L2: for { var tmp6 bool; var tmp7 bool; tmp7 = runHi < hi; if tmp7 {
				var tmp8 Comparable = Comparable_Cast(a.A[runHi]); tmp7 = tmp8.CompareTo_O__I(a.A[runHi-1]) >= 0 }
//line :116:1
				tmp6 = tmp7; if tmp6 {



					runHi = runHi + 1
//line :116:1
					continue L2 }; break L2
			}
			}


		return runHi - lo
	} }
func ComparableTimSort_ReverseRange_O1_I_I__V(a *RefArray, lo, hi int32) { ComparableTimSort_Init()
	hi = hi - 1
L1: for { if lo < hi {
	var t_ any = a.A[lo]
	a.Store(lo, a.A[hi])
	lo = lo + 1
	a.Store(hi, t_)
	hi = hi - 1
//line :125:1
	continue L1 }; break L1
}
}




func ComparableTimSort_MinRunLength_I__I(n int32) int32 { ComparableTimSort_Init()
	if !A2g_AssertionsDisabled && !(n >= 0) { panic(Thrown(AssertionError_New())) }
	var r int32 = 0
L1: for { if n >= 32 {
	r = r | n&1
	n = n >> 1
//line :135:1
	continue L1 }; break L1
}

	return n + r
}
func (t *ComparableTimSort) PushRun_I_I__V(runBase, runLen int32) {
	t.F_runBase.A[t.F_stackSize] = runBase
	t.F_runLen.A[t.F_stackSize] = runLen
	t.F_stackSize = t.F_stackSize + 1
}
func (t *ComparableTimSort) MergeCollapse__V() {
L1: for { if t.F_stackSize > 1 {
	var n int32 = t.F_stackSize - 2; var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = n > 0; if tmp3 {
		var tmp4 int32 = t.F_runLen.A[n-1]; var tmp5 int32 = t.F_runLen.A[n]; tmp3 = tmp4 <= tmp5+t.F_runLen.A[n+1] }
//line :149:1
	tmp2 = tmp3; if !tmp2 {


		var tmp6 bool; tmp6 = n > 1; if tmp6 {
			var tmp7 int32 = t.F_runLen.A[n-2]; var tmp8 int32 = t.F_runLen.A[n]; tmp6 = tmp7 <= tmp8+t.F_runLen.A[n-1] }
//line :152:1
		tmp2 = tmp6 }
//line :149:1
	tmp1 = tmp2
//line :148:1
	if tmp1 {







		var tmp9 int32 = t.F_runLen.A[n-1]; if tmp9 < t.F_runLen.A[n+1] {

			n = n - 1 } } else {
//line :148:1
				var tmp10 bool; var tmp11 bool










				tmp11 = n < 0; if !tmp11 { var tmp12 int32 = t.F_runLen.A[n]; tmp11 = tmp12 > t.F_runLen.A[n+1] }; tmp10 = tmp11
//line :148:1
				if tmp10 {










					break L1 } }
	t.MergeAt_I__V(n)
//line :146:1
	continue L1 }; break L1
}
}













func (t *ComparableTimSort) MergeForceCollapse__V() {
L1: for { if t.F_stackSize > 1 {
	var n int32 = t.F_stackSize - 2; var tmp1 bool; var tmp2 bool
	tmp2 = n > 0; if tmp2 {
		var tmp3 int32 = t.F_runLen.A[n-1]; tmp2 = tmp3 < t.F_runLen.A[n+1] }
//line :165:1
	tmp1 = tmp2; if tmp1 {


		n = n - 1 }
	t.MergeAt_I__V(n)
//line :163:1
	continue L1 }; break L1
}
}





func (t *ComparableTimSort) MergeAt_I__V(i int32) {
	if !A2g_AssertionsDisabled && !(t.F_stackSize >= 2) { panic(Thrown(AssertionError_New())) }
	if !A2g_AssertionsDisabled && !(i >= 0) { panic(Thrown(AssertionError_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = i == t.F_stackSize-2; if !tmp2 {
		tmp2 = i == t.F_stackSize-3 }
//line :174:1
	tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New()))
	}
	var base1 int32 = t.F_runBase.A[i]; var len1 int32 = t.F_runLen.A[i]; var base2 int32 = t.F_runBase.A[i+1]; var len2 int32 = t.F_runLen.A[i+1]; var tmp3 bool; var tmp4 bool



	tmp4 = len1 > 0; if tmp4 { tmp4 = len2 > 0 }; tmp3 = tmp4; if !A2g_AssertionsDisabled && !tmp3 { panic(Thrown(AssertionError_New())) }
	if !A2g_AssertionsDisabled && !(base1+len1 == base2) { panic(Thrown(AssertionError_New())) }
	t.F_runLen.A[i] = len1 + len2
	if i == t.F_stackSize-3 {
		var tmp5 *IntArray = t.F_runBase; tmp5.A[i+1] = t.F_runBase.A[i+2]
		var tmp6 *IntArray = t.F_runLen; tmp6.A[i+1] = t.F_runLen.A[i+2] }
	t.F_stackSize = t.F_stackSize - 1
	var k int32 = ComparableTimSort_GallopRight_Comparable_O1_I_I_I__I(Comparable_Cast(t.F_a.A[base2]), t.F_a, base1, len1, 0)
	if !A2g_AssertionsDisabled && !(k >= 0) { panic(Thrown(AssertionError_New())) }
	base1 = base1 + k
	len1 = len1 - k
	if len1 == 0 { } else {
		len2 = ComparableTimSort_GallopLeft_Comparable_O1_I_I_I__I(Comparable_Cast(t.F_a.A[base1+len1-1]), t.F_a, base2, len2, len2-1)







		if !A2g_AssertionsDisabled && !(len2 >= 0) { panic(Thrown(AssertionError_New())) }
		if len2 == 0 { } else {
			if len1 <= len2 {
				t.MergeLo_I_I_I_I__V(base1, len1, base2, len2) } else {
					t.MergeHi_I_I_I_I__V(base1, len1, base2, len2)
				} } } }
func ComparableTimSort_GallopLeft_Comparable_O1_I_I_I__I(key Comparable, a *RefArray, base, len_, hint int32) int32 { ComparableTimSort_Init()

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len_ > 0; if tmp3 { tmp3 = hint >= 0 }; tmp2 = tmp3; if tmp2 { tmp2 = hint < len_ }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var lastOfs int32 = 0
	var ofs int32 = 1
	if key.CompareTo_O__I(a.A[base+hint]) > 0 {
		var maxOfs int32 = len_ - hint
	L1: for { var tmp4 bool; var tmp5 bool; tmp5 = ofs < maxOfs; if tmp5 {
		tmp5 = key.CompareTo_O__I(a.A[base+hint+ofs]) > 0 }
//line :213:1
		tmp4 = tmp5; if tmp4 {




			lastOfs = ofs
			ofs = ofs<<1 + 1
			if ofs <= 0 { ofs = maxOfs }
//line :213:1
			continue L1 }; break L1
	}






		if ofs > maxOfs { ofs = maxOfs }
		lastOfs = lastOfs + hint
		ofs = ofs + hint } else {
			var maxOfs_2 int32 = hint + 1
		L2: for { var tmp6 bool; var tmp7 bool; tmp7 = ofs < maxOfs_2; if tmp7 {
			tmp7 = key.CompareTo_O__I(a.A[base+hint-ofs]) <= 0 }
//line :225:1
			tmp6 = tmp7; if tmp6 {






				lastOfs = ofs
				ofs = ofs<<1 + 1
				if ofs <= 0 { ofs = maxOfs_2 }
//line :225:1
				continue L2 }; break L2
		}








			if ofs > maxOfs_2 { ofs = maxOfs_2 }
			var tmp int32 = lastOfs
			lastOfs = hint - ofs
			ofs = hint - tmp }
	var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = -1 <= lastOfs; if tmp10 { tmp10 = lastOfs < ofs }; tmp9 = tmp10; if tmp9 { tmp9 = ofs <= len_ }; tmp8 = tmp9; if !A2g_AssertionsDisabled && !tmp8 { panic(Thrown(AssertionError_New())) }
	lastOfs = lastOfs + 1
L3: for { if lastOfs < ofs {
	var m int32 = lastOfs + int32(uint32(ofs-lastOfs)>>1)



	if key.CompareTo_O__I(a.A[base+m]) > 0 {
		lastOfs = m + 1 } else {
			ofs = m }
//line :241:1
	continue L3 }; break L3
}






	if !A2g_AssertionsDisabled && !(lastOfs == ofs) { panic(Thrown(AssertionError_New())) }
//line :209:1
	return ofs
}









































func ComparableTimSort_GallopRight_Comparable_O1_I_I_I__I(key Comparable, a *RefArray, base, len_, hint int32) int32 { ComparableTimSort_Init()

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len_ > 0; if tmp3 { tmp3 = hint >= 0 }; tmp2 = tmp3; if tmp2 { tmp2 = hint < len_ }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var ofs int32 = 1
	var lastOfs int32 = 0
	if key.CompareTo_O__I(a.A[base+hint]) < 0 {
		var maxOfs int32 = hint + 1
	L1: for { var tmp4 bool; var tmp5 bool; tmp5 = ofs < maxOfs; if tmp5 {
		tmp5 = key.CompareTo_O__I(a.A[base+hint-ofs]) < 0 }
//line :259:1
		tmp4 = tmp5; if tmp4 {






			lastOfs = ofs
			ofs = ofs<<1 + 1
			if ofs <= 0 { ofs = maxOfs }
//line :259:1
			continue L1 }; break L1
	}








		if ofs > maxOfs { ofs = maxOfs }
		var tmp int32 = lastOfs
		lastOfs = hint - ofs
		ofs = hint - tmp } else {
			var maxOfs_2 int32 = len_ - hint
		L2: for { var tmp6 bool; var tmp7 bool; tmp7 = ofs < maxOfs_2; if tmp7 {
			tmp7 = key.CompareTo_O__I(a.A[base+hint+ofs]) >= 0 }
//line :274:1
			tmp6 = tmp7; if tmp6 {




				lastOfs = ofs
				ofs = ofs<<1 + 1
				if ofs <= 0 { ofs = maxOfs_2 }
//line :274:1
				continue L2 }; break L2
		}






			if ofs > maxOfs_2 { ofs = maxOfs_2 }
			lastOfs = lastOfs + hint
			ofs = ofs + hint }
	var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = -1 <= lastOfs; if tmp10 { tmp10 = lastOfs < ofs }; tmp9 = tmp10; if tmp9 { tmp9 = ofs <= len_ }; tmp8 = tmp9; if !A2g_AssertionsDisabled && !tmp8 { panic(Thrown(AssertionError_New())) }
	lastOfs = lastOfs + 1
L3: for { if lastOfs < ofs {
	var m int32 = lastOfs + int32(uint32(ofs-lastOfs)>>1)



	if key.CompareTo_O__I(a.A[base+m]) < 0 {
		ofs = m } else {
			lastOfs = m + 1 }
//line :287:1
	continue L3 }; break L3
}






	if !A2g_AssertionsDisabled && !(lastOfs == ofs) { panic(Thrown(AssertionError_New())) }
//line :255:1
	return ofs
}









































func (t *ComparableTimSort) MergeLo_I_I_I_I__V(base1, len1, base2, len2 int32) {

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len1 > 0; if tmp3 { tmp3 = len2 > 0 }; tmp2 = tmp3; if tmp2 { tmp2 = base1+len1 == base2 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var a *RefArray = t.F_a; var tmp *RefArray = t.EnsureCapacity_I__O1(len1); var cursor1 int32 = t.F_tmpBase
	var cursor2 int32 = base2
	var dest int32 = base1


	System_Arraycopy_O_I_O_I_I__V(a.Ref(), base1, tmp.Ref(), cursor1, len1)
	a.Store(dest, a.A[cursor2])
	dest = dest + 1
	cursor2 = cursor2 + 1
	var tmp4 int32
	len2 = len2 - 1; tmp4 = len2
//line :310:1
	if tmp4 == 0 {
		System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor1, a.Ref(), dest, len1) } else {
//line :310:1
			if len1 == 1 {



				System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor2, a.Ref(), dest, len2)
				a.Store(dest+len2, tmp.A[cursor1]) } else {

					var minGallop int32 = t.F_minGallop
				L1: switch { default: L2: for {

					var count1 int32 = 0
					var count2 int32 = 0
				L3: for {
					var tmp5 bool; var tmp6 bool; tmp6 = len1 > 1; if tmp6 { tmp6 = len2 > 0 }; tmp5 = tmp6; if !A2g_AssertionsDisabled && !tmp5 { panic(Thrown(AssertionError_New())) }
					var tmp7 Comparable = Comparable_Cast(a.A[cursor2]); if tmp7.CompareTo_O__I(tmp.A[cursor1]) < 0 {

						a.Store(dest, a.A[cursor2])
						dest = dest + 1
						cursor2 = cursor2 + 1
						count2 = count2 + 1
						count1 = 0
						var tmp8 int32; len2 = len2 - 1; tmp8 = len2; if tmp8 == 0 { break L1 } } else {

							a.Store(dest, tmp.A[cursor1])
							dest = dest + 1
							cursor1 = cursor1 + 1
							count1 = count1 + 1
							count2 = 0
							var tmp9 int32; len1 = len1 - 1; tmp9 = len1; if tmp9 == 1 { break L1 } }
					if count1|count2 < minGallop { continue L3 }
//line :322:1
					break L3
				}
















				L4: for {
					var tmp10 bool; var tmp11 bool; tmp11 = len1 > 1; if tmp11 { tmp11 = len2 > 0 }; tmp10 = tmp11; if !A2g_AssertionsDisabled && !tmp10 { panic(Thrown(AssertionError_New())) }
					count1 = ComparableTimSort_GallopRight_Comparable_O1_I_I_I__I(Comparable_Cast(a.A[cursor2]), tmp, cursor1, len1, 0)






					if count1 == 0 { } else {
						System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor1, a.Ref(), dest, count1)
						dest = dest + count1
						cursor1 = cursor1 + count1
						len1 = len1 - count1
						if len1 <= 1 { break L1 } }
					a.Store(dest, a.A[cursor2])
					dest = dest + 1
					cursor2 = cursor2 + 1
					var tmp12 int32; len2 = len2 - 1; tmp12 = len2; if tmp12 == 0 { break L1 }
					count2 = ComparableTimSort_GallopLeft_Comparable_O1_I_I_I__I(Comparable_Cast(tmp.A[cursor1]), a, cursor2, len2, 0)






					if count2 == 0 { } else {
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor2, a.Ref(), dest, count2)
						dest = dest + count2
						cursor2 = cursor2 + count2
						len2 = len2 - count2
						if len2 == 0 { break L1 } }
					a.Store(dest, tmp.A[cursor1])
					dest = dest + 1
					cursor1 = cursor1 + 1
					var tmp13 int32; len1 = len1 - 1; tmp13 = len1; if tmp13 == 1 { break L1 }
					minGallop = minGallop - 1
					var tmp14 bool; var a_2 bool = count1 >= 7; var b_3 bool = count2 >= 7; var tmp15 bool; tmp15 = a_2; if !tmp15 { tmp15 = b_3 }; tmp14 = tmp15; if tmp14 {
						continue L4 }
//line :340:1
					break L4
				}





































					if minGallop < 0 { minGallop = 0 }
					minGallop = minGallop + 2
//line :318:1
					continue L2
				}
				}




























































					var tmp16 int32; if minGallop < 1 { tmp16 = 1 } else { tmp16 = minGallop }; t.F_minGallop = tmp16
					if len1 == 1 {


						if !A2g_AssertionsDisabled && !(len2 > 0) { panic(Thrown(AssertionError_New())) }
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor2, a.Ref(), dest, len2)
						a.Store(dest+len2, tmp.A[cursor1]) } else {
//line :382:1
							if len1 == 0 {






								panic(Thrown(IllegalArgumentException_New_String(Lit_2641))) } else {



									if !A2g_AssertionsDisabled && !(len2 == 0) { panic(Thrown(AssertionError_New())) }
									if !A2g_AssertionsDisabled && !(len1 > 1) { panic(Thrown(AssertionError_New())) }
									System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor1, a.Ref(), dest, len1)
								} } } } }
func (t *ComparableTimSort) MergeHi_I_I_I_I__V(base1, len1, base2, len2 int32) {

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = len1 > 0; if tmp3 { tmp3 = len2 > 0 }; tmp2 = tmp3; if tmp2 { tmp2 = base1+len1 == base2 }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var a *RefArray = t.F_a; var tmp *RefArray = t.EnsureCapacity_I__O1(len2); var tmpBase int32 = t.F_tmpBase


	System_Arraycopy_O_I_O_I_I__V(a.Ref(), base2, tmp.Ref(), tmpBase, len2)
	var cursor1 int32 = base1 + len1 - 1; var cursor2 int32 = tmpBase + len2 - 1; var dest int32 = base2 + len2 - 1


	a.Store(dest, a.A[cursor1])
	dest = dest - 1
	cursor1 = cursor1 - 1
	var tmp4 int32
	len1 = len1 - 1; tmp4 = len1
//line :410:1
	if tmp4 == 0 {

		System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), tmpBase, a.Ref(), dest-(len2-1), len2) } else {
//line :410:1
			if len2 == 1 {








				dest = dest - len1
				cursor1 = cursor1 - len1
				System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor1+1, a.Ref(), dest+1, len1)
				a.Store(dest, tmp.A[cursor2]) } else {

					var minGallop int32 = t.F_minGallop
				L1: switch { default: L2: for {

					var count1 int32 = 0
					var count2 int32 = 0
				L3: for {
					var tmp5 bool; var tmp6 bool; tmp6 = len1 > 0; if tmp6 { tmp6 = len2 > 1 }; tmp5 = tmp6; if !A2g_AssertionsDisabled && !tmp5 { panic(Thrown(AssertionError_New())) }
					var tmp7 Comparable = Comparable_Cast(tmp.A[cursor2]); if tmp7.CompareTo_O__I(a.A[cursor1]) < 0 {

						a.Store(dest, a.A[cursor1])
						dest = dest - 1
						cursor1 = cursor1 - 1
						count1 = count1 + 1
						count2 = 0
						var tmp8 int32; len1 = len1 - 1; tmp8 = len1; if tmp8 == 0 { break L1 } } else {

							a.Store(dest, tmp.A[cursor2])
							dest = dest - 1
							cursor2 = cursor2 - 1
							count2 = count2 + 1
							count1 = 0
							var tmp9 int32; len2 = len2 - 1; tmp9 = len2; if tmp9 == 1 { break L1 } }
					if count1|count2 < minGallop { continue L3 }
//line :429:1
					break L3
				}
















				L4: for {
					var tmp10 bool; var tmp11 bool; tmp11 = len1 > 0; if tmp11 { tmp11 = len2 > 1 }; tmp10 = tmp11; if !A2g_AssertionsDisabled && !tmp10 { panic(Thrown(AssertionError_New())) }
					count1 = len1 - ComparableTimSort_GallopRight_Comparable_O1_I_I_I__I(Comparable_Cast(tmp.A[cursor2]), a, base1, len1, len1-1)








					if count1 == 0 { } else {
						dest = dest - count1
						cursor1 = cursor1 - count1
						len1 = len1 - count1
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor1+1, a.Ref(), dest+1, count1)




						if len1 == 0 { break L1 } }
					a.Store(dest, tmp.A[cursor2])
					dest = dest - 1
					cursor2 = cursor2 - 1
					var tmp12 int32; len2 = len2 - 1; tmp12 = len2; if tmp12 == 1 { break L1 }
					count2 = len2 - ComparableTimSort_GallopLeft_Comparable_O1_I_I_I__I(Comparable_Cast(a.A[cursor1]), tmp, tmpBase, len2, len2-1)








					if count2 == 0 { } else {
						dest = dest - count2
						cursor2 = cursor2 - count2
						len2 = len2 - count2
						System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), cursor2+1, a.Ref(), dest+1, count2)




						if len2 <= 1 { break L1 } }
					a.Store(dest, a.A[cursor1])
					dest = dest - 1
					cursor1 = cursor1 - 1
					var tmp13 int32; len1 = len1 - 1; tmp13 = len1; if tmp13 == 0 { break L1 }
					minGallop = minGallop - 1
					var tmp14 bool; var a_4 bool = count1 >= 7; var b_5 bool = count2 >= 7; var tmp15 bool

					tmp15 = a_4; if !tmp15 { tmp15 = b_5 }; tmp14 = tmp15
//line :496:1
					if tmp14 {


						continue L4 }
//line :447:1
					break L4
				}



















































					if minGallop < 0 { minGallop = 0 }
					minGallop = minGallop + 2
//line :425:1
					continue L2
				}
				}










































































					var tmp16 int32; if minGallop < 1 { tmp16 = 1 } else { tmp16 = minGallop }; t.F_minGallop = tmp16
					if len2 == 1 {


						if !A2g_AssertionsDisabled && !(len1 > 0) { panic(Thrown(AssertionError_New())) }
						dest = dest - len1
						cursor1 = cursor1 - len1
						System_Arraycopy_O_I_O_I_I__V(a.Ref(), cursor1+1, a.Ref(), dest+1, len1)




						a.Store(dest, tmp.A[cursor2]) } else {
//line :503:1
							if len2 == 0 {












								panic(Thrown(IllegalArgumentException_New_String(Lit_2641))) } else {



									if !A2g_AssertionsDisabled && !(len1 == 0) { panic(Thrown(AssertionError_New())) }
									if !A2g_AssertionsDisabled && !(len2 > 0) { panic(Thrown(AssertionError_New())) }
									System_Arraycopy_O_I_O_I_I__V(tmp.Ref(), tmpBase, a.Ref(), dest-(len2-1), len2)
								}
						}
				}
		}
}
func (t *ComparableTimSort) EnsureCapacity_I__O1(minCapacity int32) *RefArray {
	if t.F_tmpLen < minCapacity {
		var newSize int32 = int32(uint32(4294967295) >> (Integer_NumberOfLeadingZeros_I__I(minCapacity) & 31))


		newSize = newSize + 1
		if newSize < 0 {
			newSize = minCapacity } else {
				newSize = Math_Min_I_I__I(newSize, int32(uint32(int32(len(t.F_a.A)))>>1)) }
		var newArray *RefArray = NewRefArray(Object_class, newSize)
		t.F_tmp = newArray
		t.F_tmpLen = newSize
		t.F_tmpBase = 0 }
//line :528:1
	return t.F_tmp
}














type ComparableTimSort struct{ Object; F_a *RefArray; F_minGallop int32; F_tmp *RefArray; F_tmpBase, F_tmpLen, F_stackSize int32; F_runBase, F_runLen *IntArray }

const ComparableTimSort_MIN_MERGE int32 = 32

const ComparableTimSort_MIN_GALLOP int32 = 7

const ComparableTimSort_INITIAL_TMP_STORAGE_LENGTH int32 = 256

var ComparableTimSort_init ClassInit

func ComparableTimSort_Init() { if !ComparableTimSort_init.Done() { ComparableTimSort_init.Run(ComparableTimSort_clinit) } }

func ComparableTimSort_clinit() {}

func (t *ComparableTimSort) Ref() any { if t == nil { return nil }; return t }

func (t *ComparableTimSort) GetClass__Class() *Class { return ComparableTimSort_class }

func (t *ComparableTimSort) ToString__String() *String { return Object_toString(t) }

func (t *ComparableTimSort) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ComparableTimSort) CloneShallow() any { panic(CloneNotSupported(t)) }

func ComparableTimSort_InstanceOf(x any) bool { _, ok := x.(*ComparableTimSort); return ok }

func ComparableTimSort_Cast(x any) *ComparableTimSort { if x == nil { return nil }; v, ok := x.(*ComparableTimSort); if !ok { panic(ClassCast(x, ComparableTimSort_class)) }; return v }
