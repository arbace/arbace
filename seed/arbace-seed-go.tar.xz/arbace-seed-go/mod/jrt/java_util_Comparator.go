//line java_util_Comparator.ae:1
package jrt













func Comparator_Reversed__Comparator(this Comparator) Comparator {
	return Collections_ReverseOrder_Comparator__Comparator(this)
}
func Comparator_Max_O_O__O(this Comparator, o1, o2 any) any {
	if this.Compare_O_O__I(o1, o2) >= 0 { return o1 } else { return o2
	} }
func Comparator_Min_O_O__O(this Comparator, o1, o2 any) any {
	if this.Compare_O_O__I(o1, o2) <= 0 { return o1 } else { return o2
	} }
func Comparator_ThenComparing_Comparator__Comparator(this, other Comparator) Comparator {

	Objects_RequireNonNull_O__O(other)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 any = p0; var c2 any = p1; var tmp1 int32; var res int32 = this.Compare_O_O__I(c1, c2); if



		!(res == 0) { tmp1 = res } else { tmp1 = other.Compare_O_O__I(c1, c2) }; return tmp1 },
	})) }
func Comparator_ThenComparing_Function_Comparator__Comparator(this Comparator, keyExtractor Function, keyComparator Comparator) Comparator {


	return this.ThenComparing_Comparator__Comparator(Comparator_Comparing_Function_Comparator__Comparator(keyExtractor, keyComparator))
}
func Comparator_ThenComparing_Function__Comparator(this Comparator, keyExtractor Function) Comparator {

	return this.ThenComparing_Comparator__Comparator(Comparator_Comparing_Function__Comparator(keyExtractor))
}
func Comparator_ThenComparingInt_ToIntFunction__Comparator(this Comparator, keyExtractor ToIntFunction) Comparator {

	return this.ThenComparing_Comparator__Comparator(Comparator_ComparingInt_ToIntFunction__Comparator(keyExtractor))
}
func Comparator_ThenComparingLong_ToLongFunction__Comparator(this Comparator, keyExtractor ToLongFunction) Comparator {

	return this.ThenComparing_Comparator__Comparator(Comparator_ComparingLong_ToLongFunction__Comparator(keyExtractor))
}
func Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(this Comparator, keyExtractor ToDoubleFunction) Comparator {

	return this.ThenComparing_Comparator__Comparator(Comparator_ComparingDouble_ToDoubleFunction__Comparator(keyExtractor))
}
func Comparator_ReverseOrder__Comparator() Comparator {
	return Collections_ReverseOrder__Comparator()
}
func Comparator_NaturalOrder__Comparator() Comparator { Comparators_NaturalOrderComparator_Init(); return Up_Comparators_NaturalOrderComparator_Comparator(Comparators_NaturalOrderComparator_INSTANCE) }


func Comparator_NullsFirst_Comparator__Comparator(comparator Comparator) Comparator {
	return Comparators_NullComparator_New_Z_Comparator(true, comparator)
}
func Comparator_NullsLast_Comparator__Comparator(comparator Comparator) Comparator {
	return Comparators_NullComparator_New_Z_Comparator(false, comparator)
}
func Comparator_Comparing_Function_Comparator__Comparator(keyExtractor Function, keyComparator Comparator) Comparator {

	Objects_RequireNonNull_O__O(keyExtractor)
	Objects_RequireNonNull_O__O(keyComparator)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 any = p0; var c2 any = p1; return keyComparator.Compare_O_O__I(keyExtractor.Apply_O__O(c1), keyExtractor.Apply_O__O(c2)) }}))
}



func Comparator_Comparing_Function__Comparator(keyExtractor Function) Comparator {
	Objects_RequireNonNull_O__O(keyExtractor)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 any = p0; var c2 any = p1; return Comparable_Cast(keyExtractor.Apply_O__O(c1)).CompareTo_O__I(keyExtractor.Apply_O__O(c2)) }}))
}




func Comparator_ComparingInt_ToIntFunction__Comparator(keyExtractor ToIntFunction) Comparator {
	Objects_RequireNonNull_O__O(keyExtractor)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 any = p0; var c2 any = p1; return Integer_Compare_I_I__I(keyExtractor.ApplyAsInt_O__I(c1), keyExtractor.ApplyAsInt_O__I(c2)) }}))
}



func Comparator_ComparingLong_ToLongFunction__Comparator(keyExtractor ToLongFunction) Comparator {
	Objects_RequireNonNull_O__O(keyExtractor)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 any = p0; var c2 any = p1; return Long_Compare_J_J__I(keyExtractor.ApplyAsLong_O__J(c1), keyExtractor.ApplyAsLong_O__J(c2)) }}))
}



func Comparator_ComparingDouble_ToDoubleFunction__Comparator(keyExtractor ToDoubleFunction) Comparator {
	Objects_RequireNonNull_O__O(keyExtractor)
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var c1 any = p0; var c2 any = p1; return Double_Compare_D_D__I(keyExtractor.ApplyAsDouble_O__D(c1), keyExtractor.ApplyAsDouble_O__D(c2)) }}))
}


type Comparator interface{ Object_I; Is_Comparator(); Compare_O_O__I(p0, p1 any) int32; Reversed__Comparator() Comparator; Max_O_O__O(p0, p1 any) any; Min_O_O__O(p0, p1 any) any; ThenComparing_Comparator__Comparator(p0 Comparator) Comparator; ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator; ThenComparing_Function__Comparator(p0 Function) Comparator; ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator; ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator; ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator }

func Comparator_InstanceOf(x any) bool { _, ok := x.(Comparator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Comparator_class) } }; return ok }

func Comparator_Cast(x any) Comparator { if x == nil { return nil }; v, ok := x.(Comparator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Comparator_class) } }; if !ok { panic(ClassCast(x, Comparator_class)) }; return v }
