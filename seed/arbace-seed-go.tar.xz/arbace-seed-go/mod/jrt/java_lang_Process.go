//line java_lang_Process.ae:1
package jrt










func (t *Process_PipeInputStream) Read__I() int32 {
	return t.FileInputStream.Impl_Read__I(t)
}
func (t *Process_PipeInputStream) Read_B1__I(b *ByteArray) int32 {
	return t.FileInputStream.Impl_Read_B1__I(t, b)
}
func (t *Process_PipeInputStream) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	return t.FileInputStream.Impl_Read_B1_I_I__I(t, b, off, len_)
}

func (t *Process_PipeOutputStream) Write_I__V(b int32) {
	t.FileOutputStream.Impl_Write_I__V(t, b)
}
func (t *Process_PipeOutputStream) Write_B1__V(b *ByteArray) {
	t.FileOutputStream.Impl_Write_B1__V(t, b)
}
func (t *Process_PipeOutputStream) Write_B1_I_I__V(b *ByteArray, off, len_ int32) {
	t.FileOutputStream.Impl_Write_B1_I_I__V(t, b, off, len_)
}











func (t *Process) Ctor(this Process_I) {}

func (t *Process) Impl_Close__V(this Process_I) {
	var tmp1 any = this; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if t.F_closed { } else {
			t.F_closed = true
			var ioe IOException_I; var tmp2 Closeable
			if !(t.F_outputWriter == nil) { tmp2 = t.F_outputWriter } else {

				tmp2 = this.GetOutputStream__OutputStream() }
//line :48:1
			ioe = Process_QuietClose_Closeable_IOException__IOException(tmp2, nil)




			var tmp3 Closeable

			if !(t.F_inputReader == nil) { tmp3 = t.F_inputReader } else {

				tmp3 = this.GetInputStream__InputStream() }
//line :53:1
			ioe = Process_QuietClose_Closeable_IOException__IOException(tmp3, ioe)





			var tmp4 Closeable

			if !(t.F_errorReader == nil) { tmp4 = t.F_errorReader } else {

				tmp4 = this.GetErrorStream__InputStream() }
//line :59:1
			ioe = Process_QuietClose_Closeable_IOException__IOException(tmp4, ioe)





			if t.Impl_TryWait__Z(this) { } else {
				this.DestroyForcibly__Process()
			L1: for { if !t.Impl_TryWait__Z(this) { continue L1 }; break L1 }
				Thread_CurrentThread__Thread().Interrupt__V() }
			if !(ioe == nil) { panic(Thrown(ioe))
			} } }() }
func (t *Process) Impl_TryWait__Z(this Process_I) bool {
	var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); this.WaitFor__I(); tmp1 = true; return nil }(); if tmp2 != nil { if InterruptedException_InstanceOf(tmp2) { var ie *InterruptedException = InterruptedException_Cast(tmp2); _ = ie; tmp1 = false } else { panic(tmp2) } }; return tmp1
}
func Process_QuietClose_Closeable_IOException__IOException(c Closeable, firstIOE IOException_I) IOException_I {
	var tmp1 IOException_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		c.Close__V()
//line :75:1
		tmp1 = firstIOE
		return nil }()
//line :75:1
	if tmp2 != nil { if true { var th Throwable_I = tmp2



		if firstIOE == nil {

			var tmp3 Throwable_I = th; if IOException_InstanceOf(tmp3) { var ioe IOException_I = IOException_Cast(tmp3)
				return ioe } else {
					if firstIOE == nil { firstIOE = IOException_New_Throwable(th) } else { firstIOE.AddSuppressed_Throwable__V(th) } } } else {
//line :79:1
						if firstIOE == nil {




							firstIOE = IOException_New_Throwable(th) } else {
								firstIOE.AddSuppressed_Throwable__V(th) } }
//line :75:1
		tmp1 = firstIOE } }; return tmp1
}

















func (t *Process) Impl_InputReader__BufferedReader(this Process_I) BufferedReader_I {
	return this.InputReader_Charset__BufferedReader(Process_CharsetHolder_NativeCharset__Charset())
}
func (t *Process) Impl_InputReader_Charset__BufferedReader(this Process_I, charset Charset_I) BufferedReader_I {
	Objects_RequireNonNull_O_String__O(charset, Lit_86)
	var tmp1 BufferedReader_I; var tmp2 any = this; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		if t.F_inputReader == nil {

			t.F_inputCharset = charset
			t.F_inputReader = BufferedReader_New_Reader(InputStreamReader_New_InputStream_Charset(this.GetInputStream__InputStream(), charset)) } else {
				if t.F_inputCharset.Equals_O__Z(charset) { } else {
					panic(Thrown(IllegalStateException_New_String(Concat(Lit_1145, StrOfObj(t.F_inputCharset))))) } }
//line :99:1
		tmp1 = t.F_inputReader }(); return tmp1
}








func (t *Process) Impl_ErrorReader__BufferedReader(this Process_I) BufferedReader_I {
	return this.ErrorReader_Charset__BufferedReader(Process_CharsetHolder_NativeCharset__Charset())
}
func (t *Process) Impl_ErrorReader_Charset__BufferedReader(this Process_I, charset Charset_I) BufferedReader_I {
	Objects_RequireNonNull_O_String__O(charset, Lit_86)
	var tmp1 BufferedReader_I; var tmp2 any = this; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		if t.F_errorReader == nil {

			t.F_errorCharset = charset
			t.F_errorReader = BufferedReader_New_Reader(InputStreamReader_New_InputStream_Charset(this.GetErrorStream__InputStream(), charset)) } else {
				if t.F_errorCharset.Equals_O__Z(charset) { } else {
					panic(Thrown(IllegalStateException_New_String(Concat(Lit_1145, StrOfObj(t.F_errorCharset))))) } }
//line :114:1
		tmp1 = t.F_errorReader }(); return tmp1
}








func (t *Process) Impl_OutputWriter__BufferedWriter(this Process_I) BufferedWriter_I {
	return this.OutputWriter_Charset__BufferedWriter(Process_CharsetHolder_NativeCharset__Charset())
}
func (t *Process) Impl_OutputWriter_Charset__BufferedWriter(this Process_I, charset Charset_I) BufferedWriter_I {
	Objects_RequireNonNull_O_String__O(charset, Lit_86)
	var tmp1 BufferedWriter_I; var tmp2 any = this; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		if t.F_outputWriter == nil {

			t.F_outputCharset = charset
			t.F_outputWriter = BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_Charset(this.GetOutputStream__OutputStream(), charset)) } else {

				if t.F_outputCharset.Equals_O__Z(charset) { } else {
					panic(Thrown(IllegalStateException_New_String(Concat(Lit_1146, StrOfObj(t.F_outputCharset))))) } }
//line :129:1
		tmp1 = t.F_outputWriter }(); return tmp1
}











func (t *Process) Impl_WaitFor_J_TimeUnit__Z(this Process_I, timeout int64, unit *TimeUnit) bool {

	var remainingNanos int64 = NN(unit).ToNanos_J__J(timeout)
	if t.Impl_HasExited__Z(this) { return true } else { if timeout <= 0 { return false } else {



		var deadline int64 = System_NanoTime__J() + remainingNanos
	L1: for {
		var tmp1 *TimeUnit; TimeUnit_Init(); tmp1 = TimeUnit_NANOSECONDS; Thread_Sleep_J__V(Math_Min_J_J__J(NN(tmp1).ToMillis_J__J(remainingNanos)+1, 100))



		if t.Impl_HasExited__Z(this) { return true }
		remainingNanos = deadline - System_NanoTime__J()
		if remainingNanos > 0 { continue L1 }
//line :150:1
		break L1 }
//line :149:1
		return false
	}
	}
}







func (t *Process) Impl_WaitFor_Duration__Z(this Process_I, duration *Duration) bool {
	Objects_RequireNonNull_O_String__O(duration.Ref(), Lit_1147)
	var tmp1 *TimeUnit; TimeUnit_Init(); tmp1 = TimeUnit_NANOSECONDS; var tmp2 int64 = NN(tmp1).Convert_Duration__J(duration); var tmp3 *TimeUnit; TimeUnit_Init(); tmp3 = TimeUnit_NANOSECONDS; return this.WaitFor_J_TimeUnit__Z(tmp2, tmp3)
}




func (t *Process) Impl_DestroyForcibly__Process(this Process_I) Process_I { this.Destroy__V(); return this }

func (t *Process) Impl_SupportsNormalTermination__Z(this Process_I) bool {
	panic(Thrown(UnsupportedOperationException_New_String(Concat(StrOfObj(this.GetClass__Class().Ref()), Lit_1148))))
}

func (t *Process) Impl_IsAlive__Z(this Process_I) bool { return !t.Impl_HasExited__Z(this) }

func (t *Process) Impl_HasExited__Z(this Process_I) bool {
	var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); this.ExitValue__I(); tmp1 = true; return nil }(); if tmp2 != nil { if IllegalThreadStateException_InstanceOf(tmp2) { var e *IllegalThreadStateException = IllegalThreadStateException_Cast(tmp2); _ = e; tmp1 = false } else { panic(tmp2) } }; return tmp1
}
func (t *Process) Impl_Pid__J(this Process_I) int64 { return this.ToHandle__ProcessHandle().Pid__J() }

func (t *Process) Impl_OnExit__CompletableFuture(this Process_I) CompletableFuture_I {
	var tmp1 Supplier; var tmp2 Process_I = this; tmp1 = &Supplier_Fn{Fn: func() any { return tmp2.Self_Process().Impl_WaitForInternal__Process(tmp2) }}; return CompletableFuture_SupplyAsync_Supplier__CompletableFuture(tmp1)
}
func (t *Process) Impl_WaitForInternal__Process(this Process_I) Process_I {
	var interrupted bool = false
L1: for { tmp1, tmp2, tmp3 := func() (ctl int32, rv bool, exc Throwable_I) { defer Catch(&exc)

	ForkJoinPool_ManagedBlock_ForkJoinPool_ManagedBlocker__V(Process_1_New_Process(this)); return 2, false, nil; return 0, false, nil }(); _ = tmp2
//line :187:1
	if tmp3 != nil { if InterruptedException_InstanceOf(tmp3) { var x *InterruptedException = InterruptedException_Cast(tmp3); _ = x









		interrupted = true } else {
//line :187:1
			panic(tmp3) } }; switch tmp1 { case 2: { break L1 }}
//line :186:1
	continue L1
}










	if interrupted { Thread_CurrentThread__Thread().Interrupt__V() }
//line :185:1
	return this
}



func (t *Process_1) Block__Z() bool {
	t.F_this_0.WaitFor__I()
//line :190:1
	return true
}


func (t *Process_1) IsReleasable__Z() bool {
	return !t.F_this_0.IsAlive__Z()
}




func (t *Process) Impl_ToHandle__ProcessHandle(this Process_I) ProcessHandle {
	panic(Thrown(UnsupportedOperationException_New_String(Concat(StrOfObj(this.GetClass__Class().Ref()), Lit_1149))))
}
func (t *Process) Impl_Info__ProcessHandle_Info(this Process_I) ProcessHandle_Info {
	return this.ToHandle__ProcessHandle().Info__ProcessHandle_Info()
}
func (t *Process) Impl_Children__Stream(this Process_I) Stream {
	return this.ToHandle__ProcessHandle().Children__Stream()
}
func (t *Process) Impl_Descendants__Stream(this Process_I) Stream {
	return this.ToHandle__ProcessHandle().Descendants__Stream()
}



func Process_PipeInputStream_New_FileDescriptor(p0 *FileDescriptor) *Process_PipeInputStream { t := &Process_PipeInputStream{}; t.Ctor_FileDescriptor(p0); return t }
//line :216:1
func (t *Process_PipeInputStream) Ctor_FileDescriptor(fd *FileDescriptor) { t.FileInputStream.Ctor_FileDescriptor(t, fd) }

func (t *Process_PipeInputStream) Skip_J__J(n int64) int64 {
	var remaining int64 = n
	var nr int32 = 0
	if n <= 0 { return 0 } else {

		var size int32 = int32(Math_Min_J_J__J(2048, remaining)); var skipBuffer *ByteArray = NewByteArray(size)

	L1: for { if remaining > 0 {
		nr = t.Read_B1_I_I__I(skipBuffer, 0, int32(Math_Min_J_J__J(int64(size), remaining)))
		if nr < 0 { break L1 }
		remaining = remaining - int64(nr)
//line :225:1
		continue L1 }; break L1
	}


		return n - remaining
	}
}












func Process_PipeOutputStream_New_FileDescriptor(p0 *FileDescriptor) *Process_PipeOutputStream { t := &Process_PipeOutputStream{}; t.Ctor_FileDescriptor(p0); return t }
//line :244:1
func (t *Process_PipeOutputStream) Ctor_FileDescriptor(fd *FileDescriptor) { t.FileOutputStream.Ctor_FileDescriptor(t, fd) }





















func Process_CharsetHolder_NativeCharset__Charset() Charset_I { Process_CharsetHolder_Init(); return Process_CharsetHolder_nativeCharset }



type Process struct{ Object; F_outputWriter BufferedWriter_I; F_outputCharset Charset_I; F_inputReader BufferedReader_I; F_inputCharset Charset_I; F_errorReader BufferedReader_I; F_errorCharset Charset_I; F_closed bool }

type Process_I interface{ Object_I; Closeable; AutoCloseable; Self_Process() *Process; Close__V(); GetOutputStream__OutputStream() OutputStream_I; GetInputStream__InputStream() InputStream_I; GetErrorStream__InputStream() InputStream_I; InputReader__BufferedReader() BufferedReader_I; InputReader_Charset__BufferedReader(p0 Charset_I) BufferedReader_I; ErrorReader__BufferedReader() BufferedReader_I; ErrorReader_Charset__BufferedReader(p0 Charset_I) BufferedReader_I; OutputWriter__BufferedWriter() BufferedWriter_I; OutputWriter_Charset__BufferedWriter(p0 Charset_I) BufferedWriter_I; WaitFor__I() int32; WaitFor_J_TimeUnit__Z(p0 int64, p1 *TimeUnit) bool; WaitFor_Duration__Z(p0 *Duration) bool; ExitValue__I() int32; Destroy__V(); DestroyForcibly__Process() Process_I; SupportsNormalTermination__Z() bool; IsAlive__Z() bool; Pid__J() int64; OnExit__CompletableFuture() CompletableFuture_I; ToHandle__ProcessHandle() ProcessHandle; Info__ProcessHandle_Info() ProcessHandle_Info; Children__Stream() Stream; Descendants__Stream() Stream }

func (t *Process) Self_Process() *Process { return t }

func (t *Process) Is_Closeable() {}

func (t *Process) Is_AutoCloseable() {}

func Process_InstanceOf(x any) bool { _, ok := x.(Process_I); return ok }

func Process_Cast(x any) Process_I { if x == nil { return nil }; v, ok := x.(Process_I); if !ok { panic(ClassCast(x, Process_class)) }; return v }



type Process_1 struct{ Object; F_this_0 Process_I }

func (t *Process_1) Is_ForkJoinPool_ManagedBlocker() {}

func Process_1_New_Process(p0 Process_I) *Process_1 { t := &Process_1{}; t.Ctor_Process(p0); return t }

func (t *Process_1) Ctor_Process(this_0 Process_I) { A2g_NotNull[Process_I](this_0); t.F_this_0 = this_0 }

func (t *Process_1) Ref() any { if t == nil { return nil }; return t }

func (t *Process_1) GetClass__Class() *Class { return Process_1_class }

func (t *Process_1) ToString__String() *String { return Object_toString(t) }

func (t *Process_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Process_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Process_1_InstanceOf(x any) bool { _, ok := x.(*Process_1); return ok }

func Process_1_Cast(x any) *Process_1 { if x == nil { return nil }; v, ok := x.(*Process_1); if !ok { panic(ClassCast(x, Process_1_class)) }; return v }



type Process_CharsetHolder struct{ Object }

var Process_CharsetHolder_nativeCharset Charset_I

var Process_CharsetHolder_init ClassInit

func Process_CharsetHolder_Init() { if !Process_CharsetHolder_init.Done() { Process_CharsetHolder_init.Run(Process_CharsetHolder_clinit) } }

func Process_CharsetHolder_clinit() {
//line :33:1
	var cs Charset_I; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		cs = Charset_ForName_String__Charset(System_GetProperty_String__String(Lit_1150))
//line :33:1
		return nil }()
	if tmp1 != nil { if UnsupportedCharsetException_InstanceOf(tmp1) { var uce *UnsupportedCharsetException = UnsupportedCharsetException_Cast(tmp1); _ = uce


		cs = Charset_DefaultCharset__Charset() } else {
//line :34:1
			panic(tmp1)
		}
	}

	Process_CharsetHolder_nativeCharset = cs
}
























































































































































































































































































func Process_CharsetHolder_New() *Process_CharsetHolder { Process_CharsetHolder_Init(); t := &Process_CharsetHolder{}; t.Ctor(); return t }

func (t *Process_CharsetHolder) Ctor() {}

func (t *Process_CharsetHolder) Ref() any { if t == nil { return nil }; return t }

func (t *Process_CharsetHolder) GetClass__Class() *Class { return Process_CharsetHolder_class }

func (t *Process_CharsetHolder) ToString__String() *String { return Object_toString(t) }

func (t *Process_CharsetHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Process_CharsetHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func Process_CharsetHolder_InstanceOf(x any) bool { _, ok := x.(*Process_CharsetHolder); return ok }

func Process_CharsetHolder_Cast(x any) *Process_CharsetHolder { if x == nil { return nil }; v, ok := x.(*Process_CharsetHolder); if !ok { panic(ClassCast(x, Process_CharsetHolder_class)) }; return v }



type Process_PipeInputStream struct{ FileInputStream }

func (t *Process_PipeInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *Process_PipeInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *Process_PipeInputStream) Close__V() { t.Impl_Close__V(t) }

func (t *Process_PipeInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *Process_PipeInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *Process_PipeInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *Process_PipeInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *Process_PipeInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *Process_PipeInputStream) GetFD__FileDescriptor() *FileDescriptor { return t.Impl_GetFD__FileDescriptor(t) }

func (t *Process_PipeInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *Process_PipeInputStream) Available__I() int32 { return t.Impl_Available__I(t) }

func (t *Process_PipeInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *Process_PipeInputStream) GetClass__Class() *Class { return Process_PipeInputStream_class }

func (t *Process_PipeInputStream) ToString__String() *String { return Object_toString(t) }

func (t *Process_PipeInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Process_PipeInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func Process_PipeInputStream_InstanceOf(x any) bool { _, ok := x.(*Process_PipeInputStream); return ok }

func Process_PipeInputStream_Cast(x any) *Process_PipeInputStream { if x == nil { return nil }; v, ok := x.(*Process_PipeInputStream); if !ok { panic(ClassCast(x, Process_PipeInputStream_class)) }; return v }



type Process_PipeOutputStream struct{ FileOutputStream }

func (t *Process_PipeOutputStream) Close__V() { t.Impl_Close__V(t) }

func (t *Process_PipeOutputStream) GetFD__FileDescriptor() *FileDescriptor { return t.Impl_GetFD__FileDescriptor(t) }

func (t *Process_PipeOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *Process_PipeOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *Process_PipeOutputStream) GetClass__Class() *Class { return Process_PipeOutputStream_class }

func (t *Process_PipeOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *Process_PipeOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Process_PipeOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func Process_PipeOutputStream_InstanceOf(x any) bool { _, ok := x.(*Process_PipeOutputStream); return ok }

func Process_PipeOutputStream_Cast(x any) *Process_PipeOutputStream { if x == nil { return nil }; v, ok := x.(*Process_PipeOutputStream); if !ok { panic(ClassCast(x, Process_PipeOutputStream_class)) }; return v }
