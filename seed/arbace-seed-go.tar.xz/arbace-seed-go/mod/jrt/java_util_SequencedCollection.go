//line java_util_SequencedCollection.ae:1
package jrt









func SequencedCollection_AddFirst_O__V(this SequencedCollection, e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SequencedCollection_AddLast_O__V(this SequencedCollection, e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func SequencedCollection_GetFirst__O(this SequencedCollection) any { return this.Iterator__Iterator().Next__O() }

func SequencedCollection_GetLast__O(this SequencedCollection) any {
	return this.Reversed__SequencedCollection().Iterator__Iterator().Next__O()
}
func SequencedCollection_RemoveFirst__O(this SequencedCollection) any {
	var it Iterator = this.Iterator__Iterator(); var e any = it.Next__O(); it.Remove__V(); return e
}
func SequencedCollection_RemoveLast__O(this SequencedCollection) any {
	var it Iterator = this.Reversed__SequencedCollection().Iterator__Iterator(); var e any = it.Next__O(); it.Remove__V(); return e
}


type SequencedCollection interface{ Object_I; Collection; Iterable; Is_SequencedCollection(); Reversed__SequencedCollection() SequencedCollection; AddFirst_O__V(p0 any); AddLast_O__V(p0 any); GetFirst__O() any; GetLast__O() any; RemoveFirst__O() any; RemoveLast__O() any }

func SequencedCollection_InstanceOf(x any) bool { _, ok := x.(SequencedCollection); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SequencedCollection_class) } }; return ok }

func SequencedCollection_Cast(x any) SequencedCollection { if x == nil { return nil }; v, ok := x.(SequencedCollection); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SequencedCollection_class) } }; if !ok { panic(ClassCast(x, SequencedCollection_class)) }; return v }
