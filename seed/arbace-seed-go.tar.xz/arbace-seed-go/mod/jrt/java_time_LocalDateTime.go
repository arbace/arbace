//line java_time_LocalDateTime.ae:1
package jrt









































func LocalDateTime_Now__LocalDateTime() *LocalDateTime { LocalDateTime_Init()
	return LocalDateTime_Now_Clock__LocalDateTime(Clock_SystemDefaultZone__Clock())
}
func LocalDateTime_Now_ZoneId__LocalDateTime(zone ZoneId_I) *LocalDateTime { LocalDateTime_Init()
	return LocalDateTime_Now_Clock__LocalDateTime(Clock_System_ZoneId__Clock(zone))
}
func LocalDateTime_Now_Clock__LocalDateTime(clock Clock_I) *LocalDateTime { LocalDateTime_Init()
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	var now *Instant = clock.Instant__Instant(); var offset *ZoneOffset = NN(clock.GetZone__ZoneId().GetRules__ZoneRules()).GetOffset_Instant__ZoneOffset(now)

	return LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(NN(now).GetEpochSecond__J(), NN(now).GetNano__I(), offset)
}
func LocalDateTime_Of_I_Month_I_I_I__LocalDateTime(year int32, month *Month, dayOfMonth, hour, minute int32) *LocalDateTime { LocalDateTime_Init()

	var date *LocalDate = LocalDate_Of_I_Month_I__LocalDate(year, month, dayOfMonth); var time *LocalTime = LocalTime_Of_I_I__LocalTime(hour, minute)

	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_Of_I_Month_I_I_I_I__LocalDateTime(year int32, month *Month, dayOfMonth, hour, minute, second int32) *LocalDateTime { LocalDateTime_Init()

	var date *LocalDate = LocalDate_Of_I_Month_I__LocalDate(year, month, dayOfMonth); var time *LocalTime = LocalTime_Of_I_I_I__LocalTime(hour, minute, second)

	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_Of_I_Month_I_I_I_I_I__LocalDateTime(year int32, month *Month, dayOfMonth, hour, minute, second, nanoOfSecond int32) *LocalDateTime { LocalDateTime_Init()

	var date *LocalDate = LocalDate_Of_I_Month_I__LocalDate(year, month, dayOfMonth); var time *LocalTime = LocalTime_Of_I_I_I_I__LocalTime(hour, minute, second, nanoOfSecond)

	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_Of_I_I_I_I_I__LocalDateTime(year, month, dayOfMonth, hour, minute int32) *LocalDateTime { LocalDateTime_Init()

	var date *LocalDate = LocalDate_Of_I_I_I__LocalDate(year, month, dayOfMonth); var time *LocalTime = LocalTime_Of_I_I__LocalTime(hour, minute)

	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_Of_I_I_I_I_I_I__LocalDateTime(year, month, dayOfMonth, hour, minute, second int32) *LocalDateTime { LocalDateTime_Init()

	var date *LocalDate = LocalDate_Of_I_I_I__LocalDate(year, month, dayOfMonth); var time *LocalTime = LocalTime_Of_I_I_I__LocalTime(hour, minute, second)

	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_Of_I_I_I_I_I_I_I__LocalDateTime(year, month, dayOfMonth, hour, minute, second, nanoOfSecond int32) *LocalDateTime { LocalDateTime_Init()

	var date *LocalDate = LocalDate_Of_I_I_I__LocalDate(year, month, dayOfMonth); var time *LocalTime = LocalTime_Of_I_I_I_I__LocalTime(hour, minute, second, nanoOfSecond)

	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(date *LocalDate, time *LocalTime) *LocalDateTime { LocalDateTime_Init()
	Objects_RequireNonNull_O_String__O(date.Ref(), Lit_1440)
	Objects_RequireNonNull_O_String__O(time.Ref(), Lit_2051)
	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_OfInstant_Instant_ZoneId__LocalDateTime(instant *Instant, zone ZoneId_I) *LocalDateTime { LocalDateTime_Init()
	Objects_RequireNonNull_O_String__O(instant.Ref(), Lit_2039)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var rules *ZoneRules = zone.GetRules__ZoneRules(); var offset *ZoneOffset = NN(rules).GetOffset_Instant__ZoneOffset(instant)

	return LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(NN(instant).GetEpochSecond__J(), NN(instant).GetNano__I(), offset)
}
func LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(epochSecond int64, nanoOfSecond int32, offset *ZoneOffset) *LocalDateTime { LocalDateTime_Init()

	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_SECOND; NN(tmp1).CheckValidValue_J__J(int64(nanoOfSecond))
	var localSecond int64 = epochSecond + int64(NN(offset).GetTotalSeconds__I()); var localEpochDay int64 = Math_FloorDiv_J_I__J(localSecond, 86400); var secsOfDay int32 = Math_FloorMod_J_I__I(localSecond, 86400); var date *LocalDate = LocalDate_OfEpochDay_J__LocalDate(localEpochDay); var time *LocalTime = LocalTime_OfNanoOfDay_J__LocalTime(int64(secsOfDay)*1000000000 + int64(nanoOfSecond))






	return LocalDateTime_New_LocalDate_LocalTime(date, time)
}
func LocalDateTime_From_TemporalAccessor__LocalDateTime(temporal TemporalAccessor) *LocalDateTime { LocalDateTime_Init()
	if LocalDateTime_InstanceOf(temporal) {
		return LocalDateTime_Cast(temporal) } else {
//line :117:1
			if ZonedDateTime_InstanceOf(temporal) {

				return NN(ZonedDateTime_Cast(temporal)).ToLocalDateTime__LocalDateTime() } else {
//line :117:1
					if OffsetDateTime_InstanceOf(temporal) {


						return NN(OffsetDateTime_Cast(temporal)).ToLocalDateTime__LocalDateTime() } else {

							var tmp1 *LocalDateTime; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
								{ var date *LocalDate = LocalDate_From_TemporalAccessor__LocalDate(temporal); var time *LocalTime = LocalTime_From_TemporalAccessor__LocalTime(temporal)

									tmp1 = LocalDateTime_New_LocalDate_LocalTime(date, time) }
//line :122:1
								return nil }(); if tmp2 != nil { if DateTimeException_InstanceOf(tmp2) { var ex DateTimeException_I = DateTimeException_Cast(tmp2)




									panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2053, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :122:1
										panic(tmp2) } }; return tmp1
						}
				}
		}
}







func LocalDateTime_Parse_CharSequence__LocalDateTime(text CharSequence) *LocalDateTime { LocalDateTime_Init()
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_LOCAL_DATE_TIME; return LocalDateTime_Parse_CharSequence_DateTimeFormatter__LocalDateTime(text, tmp1)
}
func LocalDateTime_Parse_CharSequence_DateTimeFormatter__LocalDateTime(text CharSequence, formatter *DateTimeFormatter) *LocalDateTime { LocalDateTime_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return LocalDateTime_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return LocalDateTime_From_TemporalAccessor__LocalDateTime(p0).Ref() }}))
}



func LocalDateTime_New_LocalDate_LocalTime(p0 *LocalDate, p1 *LocalTime) *LocalDateTime { LocalDateTime_Init(); t := &LocalDateTime{}; t.Ctor_LocalDate_LocalTime(p0, p1); return t }
//line :144:1
func (t *LocalDateTime) Ctor_LocalDate_LocalTime(date *LocalDate, time *LocalTime) {
	t.F_date = date
	t.F_time = time
}
func (t *LocalDateTime) With_LocalDate_LocalTime__LocalDateTime(newDate *LocalDate, newTime *LocalTime) *LocalDateTime {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_date == newDate; if tmp2 { tmp2 = t.F_time == newTime }; tmp1 = tmp2; if tmp1 { return t } else {

		return LocalDateTime_New_LocalDate_LocalTime(newDate, newTime)
	} }
func (t *LocalDateTime) IsSupported_TemporalField__Z(field TemporalField) bool {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1); var tmp2 bool
		tmp2 = NN(chronoField).IsDateBased__Z(); if !tmp2 { tmp2 = NN(chronoField).IsTimeBased__Z() }; return tmp2 } else {
			var tmp3 bool; tmp3 = !(field == nil); if tmp3 { tmp3 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp3
		} }
func (t *LocalDateTime) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	return ChronoLocalDateTime_IsSupported_TemporalUnit__Z(t, unit)
}
func (t *LocalDateTime) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() { return NN(t.F_time).Range_TemporalField__ValueRange(field) } else { return NN(t.F_date).Range_TemporalField__ValueRange(field) } } else {
			return field.RangeRefinedBy_TemporalAccessor__ValueRange(t)
		} }
func (t *LocalDateTime) Get_TemporalField__I(field TemporalField) int32 {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() { return NN(t.F_time).Get_TemporalField__I(field) } else { return NN(t.F_date).Get_TemporalField__I(field) } } else {
			return TemporalAccessor_Get_TemporalField__I(t, field)
		} }
func (t *LocalDateTime) GetLong_TemporalField__J(field TemporalField) int64 {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() { return NN(t.F_time).GetLong_TemporalField__J(field) } else { return NN(t.F_date).GetLong_TemporalField__J(field) } } else {
			return field.GetFrom_TemporalAccessor__J(t)
		} }
func (t *LocalDateTime) ToLocalDate__LocalDate() *LocalDate { return t.F_date }

func (t *LocalDateTime) GetYear__I() int32 { return NN(t.F_date).GetYear__I() }

func (t *LocalDateTime) GetMonthValue__I() int32 { return NN(t.F_date).GetMonthValue__I() }

func (t *LocalDateTime) GetMonth__Month() *Month { return NN(t.F_date).GetMonth__Month() }

func (t *LocalDateTime) GetDayOfMonth__I() int32 { return NN(t.F_date).GetDayOfMonth__I() }

func (t *LocalDateTime) GetDayOfYear__I() int32 { return NN(t.F_date).GetDayOfYear__I() }

func (t *LocalDateTime) GetDayOfWeek__DayOfWeek() *DayOfWeek { return NN(t.F_date).GetDayOfWeek__DayOfWeek() }

func (t *LocalDateTime) ToLocalTime__LocalTime() *LocalTime { return t.F_time }

func (t *LocalDateTime) GetHour__I() int32 { return NN(t.F_time).GetHour__I() }

func (t *LocalDateTime) GetMinute__I() int32 { return NN(t.F_time).GetMinute__I() }

func (t *LocalDateTime) GetSecond__I() int32 { return NN(t.F_time).GetSecond__I() }

func (t *LocalDateTime) GetNano__I() int32 { return NN(t.F_time).GetNano__I() }

func (t *LocalDateTime) With_TemporalAdjuster__LocalDateTime(adjuster TemporalAdjuster) *LocalDateTime {
	if LocalDate_InstanceOf(adjuster) {
		return t.With_LocalDate_LocalTime__LocalDateTime(LocalDate_Cast(adjuster), t.F_time) } else {
//line :201:1
			if LocalTime_InstanceOf(adjuster) {

				var tmp1 *LocalDate = t.F_date; return t.With_LocalDate_LocalTime__LocalDateTime(tmp1, LocalTime_Cast(adjuster)) } else {
//line :201:1
					if LocalDateTime_InstanceOf(adjuster) {


						return LocalDateTime_Cast(adjuster) } else {
							return LocalDateTime_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
						} } } }
func (t *LocalDateTime) With_TemporalField_J__LocalDateTime(field TemporalField, newValue int64) *LocalDateTime {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsTimeBased__Z() {
			var tmp2 *LocalDate = t.F_date; return t.With_LocalDate_LocalTime__LocalDateTime(tmp2, NN(t.F_time).With_TemporalField_J__LocalTime(field, newValue)) } else {
				return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).With_TemporalField_J__LocalDate(field, newValue), t.F_time) } } else {
					return LocalDateTime_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue))
				} }
func (t *LocalDateTime) WithYear_I__LocalDateTime(year int32) *LocalDateTime {
	return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).WithYear_I__LocalDate(year), t.F_time)
}
func (t *LocalDateTime) WithMonth_I__LocalDateTime(month int32) *LocalDateTime {
	return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).WithMonth_I__LocalDate(month), t.F_time)
}
func (t *LocalDateTime) WithDayOfMonth_I__LocalDateTime(dayOfMonth int32) *LocalDateTime {
	return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).WithDayOfMonth_I__LocalDate(dayOfMonth), t.F_time)
}
func (t *LocalDateTime) WithDayOfYear_I__LocalDateTime(dayOfYear int32) *LocalDateTime {
	return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).WithDayOfYear_I__LocalDate(dayOfYear), t.F_time)
}
func (t *LocalDateTime) WithHour_I__LocalDateTime(hour int32) *LocalDateTime {
	var newTime *LocalTime = NN(t.F_time).WithHour_I__LocalTime(hour); return t.With_LocalDate_LocalTime__LocalDateTime(t.F_date, newTime)
}
func (t *LocalDateTime) WithMinute_I__LocalDateTime(minute int32) *LocalDateTime {
	var newTime *LocalTime = NN(t.F_time).WithMinute_I__LocalTime(minute); return t.With_LocalDate_LocalTime__LocalDateTime(t.F_date, newTime)
}
func (t *LocalDateTime) WithSecond_I__LocalDateTime(second int32) *LocalDateTime {
	var newTime *LocalTime = NN(t.F_time).WithSecond_I__LocalTime(second); return t.With_LocalDate_LocalTime__LocalDateTime(t.F_date, newTime)
}
func (t *LocalDateTime) WithNano_I__LocalDateTime(nanoOfSecond int32) *LocalDateTime {
	var newTime *LocalTime = NN(t.F_time).WithNano_I__LocalTime(nanoOfSecond); return t.With_LocalDate_LocalTime__LocalDateTime(t.F_date, newTime)
}
func (t *LocalDateTime) TruncatedTo_TemporalUnit__LocalDateTime(unit TemporalUnit) *LocalDateTime {
	var tmp1 *LocalDate = t.F_date; return t.With_LocalDate_LocalTime__LocalDateTime(tmp1, NN(t.F_time).TruncatedTo_TemporalUnit__LocalTime(unit))
}
func (t *LocalDateTime) Plus_TemporalAmount__LocalDateTime(amountToAdd TemporalAmount) *LocalDateTime {
	var tmp1 TemporalAmount = amountToAdd; if Period_InstanceOf(tmp1) { var periodToAdd *Period = Period_Cast(tmp1)
		return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).Plus_TemporalAmount__LocalDate(Up_Period_TemporalAmount(periodToAdd)), t.F_time) } else {

			Objects_RequireNonNull_O_String__O(amountToAdd, Lit_2046)
			return LocalDateTime_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
		} }
func (t *LocalDateTime) Plus_J_TemporalUnit__LocalDateTime(amountToAdd int64, unit TemporalUnit) *LocalDateTime {
	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 0:
			return t.PlusNanos_J__LocalDateTime(amountToAdd); case 1:

			return NN(t.PlusDays_J__LocalDateTime(amountToAdd / 86400000000)).PlusNanos_J__LocalDateTime(amountToAdd % 86400000000 * 1000); case 2:



			return NN(t.PlusDays_J__LocalDateTime(amountToAdd / 86400000)).PlusNanos_J__LocalDateTime(amountToAdd % 86400000 * 1000000); case 3:


			return t.PlusSeconds_J__LocalDateTime(amountToAdd); case 4:
			return t.PlusMinutes_J__LocalDateTime(amountToAdd); case 5:
			return t.PlusHours_J__LocalDateTime(amountToAdd); case 6:

			return NN(t.PlusDays_J__LocalDateTime(amountToAdd / 256)).PlusHours_J__LocalDateTime(amountToAdd % 256 * 12); default:

			return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).Plus_J_TemporalUnit__LocalDate(amountToAdd, unit), t.F_time)} } else {
				return LocalDateTime_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd)) } }; panic("a2g: unreachable")
}
func (t *LocalDateTime) PlusYears_J__LocalDateTime(years int64) *LocalDateTime {
	var newDate *LocalDate = NN(t.F_date).PlusYears_J__LocalDate(years); return t.With_LocalDate_LocalTime__LocalDateTime(newDate, t.F_time)
}
func (t *LocalDateTime) PlusMonths_J__LocalDateTime(months int64) *LocalDateTime {
	var newDate *LocalDate = NN(t.F_date).PlusMonths_J__LocalDate(months); return t.With_LocalDate_LocalTime__LocalDateTime(newDate, t.F_time)
}
func (t *LocalDateTime) PlusWeeks_J__LocalDateTime(weeks int64) *LocalDateTime {
	var newDate *LocalDate = NN(t.F_date).PlusWeeks_J__LocalDate(weeks); return t.With_LocalDate_LocalTime__LocalDateTime(newDate, t.F_time)
}
func (t *LocalDateTime) PlusDays_J__LocalDateTime(days int64) *LocalDateTime {
	var newDate *LocalDate = NN(t.F_date).PlusDays_J__LocalDate(days); return t.With_LocalDate_LocalTime__LocalDateTime(newDate, t.F_time)
}
func (t *LocalDateTime) PlusHours_J__LocalDateTime(hours int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, hours, 0, 0, 0, 1)
}
func (t *LocalDateTime) PlusMinutes_J__LocalDateTime(minutes int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, 0, minutes, 0, 0, 1)
}
func (t *LocalDateTime) PlusSeconds_J__LocalDateTime(seconds int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, 0, 0, seconds, 0, 1)
}
func (t *LocalDateTime) PlusNanos_J__LocalDateTime(nanos int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, 0, 0, 0, nanos, 1)
}
func (t *LocalDateTime) Minus_TemporalAmount__LocalDateTime(amountToSubtract TemporalAmount) *LocalDateTime {
	var tmp1 TemporalAmount = amountToSubtract; if Period_InstanceOf(tmp1) { var periodToSubtract *Period = Period_Cast(tmp1)
		return t.With_LocalDate_LocalTime__LocalDateTime(NN(t.F_date).Minus_TemporalAmount__LocalDate(Up_Period_TemporalAmount(periodToSubtract)), t.F_time) } else {

			Objects_RequireNonNull_O_String__O(amountToSubtract, Lit_2047)
			return LocalDateTime_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
		} }
func (t *LocalDateTime) Minus_J_TemporalUnit__LocalDateTime(amountToSubtract int64, unit TemporalUnit) *LocalDateTime {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__LocalDateTime(9223372036854775807, unit)).Plus_J_TemporalUnit__LocalDateTime(1, unit) } else {
			return t.Plus_J_TemporalUnit__LocalDateTime(-amountToSubtract, unit)
		} }
func (t *LocalDateTime) MinusYears_J__LocalDateTime(years int64) *LocalDateTime {
	if years == -9223372036854775808 {
		return NN(t.PlusYears_J__LocalDateTime(9223372036854775807)).PlusYears_J__LocalDateTime(1) } else {
			return t.PlusYears_J__LocalDateTime(-years)
		} }
func (t *LocalDateTime) MinusMonths_J__LocalDateTime(months int64) *LocalDateTime {
	if months == -9223372036854775808 {
		return NN(t.PlusMonths_J__LocalDateTime(9223372036854775807)).PlusMonths_J__LocalDateTime(1) } else {
			return t.PlusMonths_J__LocalDateTime(-months)
		} }
func (t *LocalDateTime) MinusWeeks_J__LocalDateTime(weeks int64) *LocalDateTime {
	if weeks == -9223372036854775808 {
		return NN(t.PlusWeeks_J__LocalDateTime(9223372036854775807)).PlusWeeks_J__LocalDateTime(1) } else {
			return t.PlusWeeks_J__LocalDateTime(-weeks)
		} }
func (t *LocalDateTime) MinusDays_J__LocalDateTime(days int64) *LocalDateTime {
	if days == -9223372036854775808 {
		return NN(t.PlusDays_J__LocalDateTime(9223372036854775807)).PlusDays_J__LocalDateTime(1) } else {
			return t.PlusDays_J__LocalDateTime(-days)
		} }
func (t *LocalDateTime) MinusHours_J__LocalDateTime(hours int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, hours, 0, 0, 0, -1)
}
func (t *LocalDateTime) MinusMinutes_J__LocalDateTime(minutes int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, 0, minutes, 0, 0, -1)
}
func (t *LocalDateTime) MinusSeconds_J__LocalDateTime(seconds int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, 0, 0, seconds, 0, -1)
}
func (t *LocalDateTime) MinusNanos_J__LocalDateTime(nanos int64) *LocalDateTime {
	return t.PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(t.F_date, 0, 0, 0, nanos, -1)
}
func (t *LocalDateTime) PlusWithOverflow_LocalDate_J_J_J_J_I__LocalDateTime(newDate *LocalDate, hours, minutes, seconds, nanos int64, sign int32) *LocalDateTime {


	if hours|minutes|seconds|nanos == 0 {
		return t.With_LocalDate_LocalTime__LocalDateTime(newDate, t.F_time) } else {
			var tmp1 int64 = nanos / 86400000000000; var tmp2 int64 = tmp1 + seconds/86400; var tmp3 int64 = tmp2 + minutes/1440; var totDays int64 = tmp3 + hours/24






			totDays = totDays * int64(sign)
			var tmp4 int64 = nanos % 86400000000000; var tmp5 int64 = tmp4 + seconds%86400*1000000000; var tmp6 int64 = tmp5 + minutes%1440*60000000000; var totNanos int64 = tmp6 + hours%24*3600000000000; var curNoD int64 = NN(t.F_time).ToNanoOfDay__J()













			totNanos = totNanos*int64(sign) + curNoD
			totDays = totDays + Math_FloorDiv_J_J__J(totNanos, 86400000000000)
			var newNoD int64 = Math_FloorMod_J_J__J(totNanos, 86400000000000); var newTime *LocalTime
			if newNoD == curNoD { newTime = t.F_time } else { newTime = LocalTime_OfNanoOfDay_J__LocalTime(newNoD) }
			return t.With_LocalDate_LocalTime__LocalDateTime(NN(newDate).PlusDays_J__LocalDate(totDays), newTime)
		} }
func (t *LocalDateTime) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_LocalDate__TemporalQuery() { return t.F_date.Ref() } else {

		return ChronoLocalDateTime_Query_TemporalQuery__O(t, query)
	} }
func (t *LocalDateTime) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	return ChronoLocalDateTime_AdjustInto_Temporal__Temporal(t, temporal)
}
func (t *LocalDateTime) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	var end *LocalDateTime = LocalDateTime_From_TemporalAccessor__LocalDateTime(endExclusive); var tmp1 TemporalUnit = unit
	if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		if unit.IsTimeBased__Z() {
			var tmp2 *LocalDate = t.F_date; var amount int64 = NN(tmp2).DaysUntil_LocalDate__J(end.F_date)
			if amount == 0 {
				var tmp3 *LocalTime = t.F_time; return NN(tmp3).Until_Temporal_TemporalUnit__J(Up_LocalTime_Temporal(end.F_time), unit) } else {
					var timePart int64 = NN(end.F_time).ToNanoOfDay__J() - NN(t.F_time).ToNanoOfDay__J()


					if amount > 0 {

						amount = amount - 1
						timePart = timePart + 86400000000000 } else {

							amount = amount + 1
							timePart = timePart - 86400000000000 }
					switch NN(chronoUnit).F_ordinal { case 0:
						amount = Math_MultiplyExact_J_J__J(amount, 86400000000000); case 1:


						amount = Math_MultiplyExact_J_J__J(amount, 86400000000)
						timePart = timePart / 1000; case 2:


						amount = Math_MultiplyExact_J_J__J(amount, 86400000)
						timePart = timePart / 1000000; case 3:


						amount = Math_MultiplyExact_J_I__J(amount, 86400)
						timePart = timePart / 1000000000; case 4:


						amount = Math_MultiplyExact_J_I__J(amount, 1440)
						timePart = timePart / 60000000000; case 5:


						amount = Math_MultiplyExact_J_I__J(amount, 24)
						timePart = timePart / 3600000000000; case 6:


						amount = Math_MultiplyExact_J_I__J(amount, 2)
						timePart = timePart / 43200000000000; default:
					}


					return Math_AddExact_J_J__J(amount, timePart) } } else {
						var endDate *LocalDate = end.F_date; var tmp4 bool; var tmp5 bool

						tmp5 = NN(endDate).IsAfter_ChronoLocalDate__Z(Up_LocalDate_ChronoLocalDate(t.F_date)); if tmp5 { tmp5 = NN(end.F_time).IsBefore_LocalTime__Z(t.F_time) }; tmp4 = tmp5
//line :426:1
						if tmp4 {

							endDate = NN(endDate).MinusDays_J__LocalDate(1) } else {
//line :426:1
								var tmp6 bool; var tmp7 bool


								tmp7 = NN(endDate).IsBefore_ChronoLocalDate__Z(Up_LocalDate_ChronoLocalDate(t.F_date)); if tmp7 { tmp7 = NN(end.F_time).IsAfter_LocalTime__Z(t.F_time) }; tmp6 = tmp7
//line :426:1
								if tmp6 {



									endDate = NN(endDate).PlusDays_J__LocalDate(1) } }
						return NN(t.F_date).Until_Temporal_TemporalUnit__J(Up_LocalDate_Temporal(endDate), unit) } } else {
							return unit.Between_Temporal_Temporal__J(t, Up_LocalDateTime_Temporal(end))
						} }
func (t *LocalDateTime) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *LocalDateTime) AtOffset_ZoneOffset__OffsetDateTime(offset *ZoneOffset) *OffsetDateTime {
	return OffsetDateTime_Of_LocalDateTime_ZoneOffset__OffsetDateTime(t, offset)
}
func (t *LocalDateTime) AtZone_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_Of_LocalDateTime_ZoneId__ZonedDateTime(t, zone)
}
func (t *LocalDateTime) CompareTo_ChronoLocalDateTime__I(other ChronoLocalDateTime) int32 {
	if LocalDateTime_InstanceOf(other) {
		return t.CompareTo0_LocalDateTime__I(LocalDateTime_Cast(other)) } else {
			return ChronoLocalDateTime_CompareTo_ChronoLocalDateTime__I(t, other)
		} }
func (t *LocalDateTime) CompareTo0_LocalDateTime__I(other *LocalDateTime) int32 {
	var tmp1 *LocalDate = t.F_date; var cmp int32 = NN(tmp1).CompareTo0_LocalDate__I(NN(other).ToLocalDate__LocalDate())
	if cmp == 0 { var tmp2 *LocalTime = t.F_time; cmp = NN(tmp2).CompareTo_LocalTime__I(NN(other).ToLocalTime__LocalTime()) }
//line :450:1
	return cmp
}


func (t *LocalDateTime) IsAfter_ChronoLocalDateTime__Z(other ChronoLocalDateTime) bool {
	if LocalDateTime_InstanceOf(other) {
		return t.CompareTo0_LocalDateTime__I(LocalDateTime_Cast(other)) > 0 } else {
			return ChronoLocalDateTime_IsAfter_ChronoLocalDateTime__Z(t, other)
		} }
func (t *LocalDateTime) IsBefore_ChronoLocalDateTime__Z(other ChronoLocalDateTime) bool {
	if LocalDateTime_InstanceOf(other) {
		return t.CompareTo0_LocalDateTime__I(LocalDateTime_Cast(other)) < 0 } else {
			return ChronoLocalDateTime_IsBefore_ChronoLocalDateTime__Z(t, other)
		} }
func (t *LocalDateTime) IsEqual_ChronoLocalDateTime__Z(other ChronoLocalDateTime) bool {
	if LocalDateTime_InstanceOf(other) {
		return t.CompareTo0_LocalDateTime__I(LocalDateTime_Cast(other)) == 0 } else {
			return ChronoLocalDateTime_IsEqual_ChronoLocalDateTime__Z(t, other)
		} }
func (t *LocalDateTime) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if LocalDateTime_InstanceOf(tmp1) { var other *LocalDateTime = LocalDateTime_Cast(tmp1); var tmp2 *LocalDate = t.F_date
			if NN(tmp2).Equals_O__Z(other.F_date.Ref()) { var tmp3 *LocalTime = t.F_time; return NN(tmp3).Equals_O__Z(other.F_time.Ref()) } else { return false } } else {
//line :472:1
				return false
			}
	}
}
func (t *LocalDateTime) HashCode__I() int32 {
	return NN(t.F_date).HashCode__I() ^ NN(t.F_time).HashCode__I()
}
func (t *LocalDateTime) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New_I(29); DateTimeHelper_FormatTo_StringBuilder_LocalDateTime__V(buf, t); return NN(buf).ToString__String()
}
func (t *LocalDateTime) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.LocalDateTime.writeReplace()Ljava/lang/Object;")) }









func LocalDateTime_ReadExternal_DataInput__LocalDateTime(p0 DataInput) *LocalDateTime { LocalDateTime_Init(); panic(A2g_NotTranslated("java.time.LocalDateTime.readExternal(Ljava/io/DataInput;)Ljava/time/LocalDateTime;")) }



type LocalDateTime struct{ Object; F_date *LocalDate; F_time *LocalTime }

func (t *LocalDateTime) Is_Temporal() {}

func (t *LocalDateTime) Is_TemporalAdjuster() {}

func (t *LocalDateTime) Is_ChronoLocalDateTime() {}

func (t *LocalDateTime) Is_Serializable() {}

func (t *LocalDateTime) Is_TemporalAccessor() {}

func (t *LocalDateTime) Is_Comparable() {}

var LocalDateTime_MIN *LocalDateTime

var LocalDateTime_MAX *LocalDateTime

const LocalDateTime_serialVersionUID int64 = 6207766400415563566

var LocalDateTime_init ClassInit

func LocalDateTime_Init() { if !LocalDateTime_init.Done() { LocalDateTime_init.Run(LocalDateTime_clinit) } }

func LocalDateTime_clinit() { var tmp1 *LocalDate; LocalDate_Init(); tmp1 = LocalDate_MIN; var tmp2 *LocalDate = tmp1; var tmp3 *LocalTime; LocalTime_Init(); tmp3 = LocalTime_MIN; LocalDateTime_MIN = LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(tmp2, tmp3); var tmp4 *LocalDate; LocalDate_Init(); tmp4 = LocalDate_MAX; var tmp5 *LocalDate = tmp4; var tmp6 *LocalTime; LocalTime_Init(); tmp6 = LocalTime_MAX; LocalDateTime_MAX = LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(tmp5, tmp6) }

func (t *LocalDateTime) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_LocalDateTime_Temporal(t.With_TemporalAdjuster__LocalDateTime(p0)) }

func (t *LocalDateTime) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_LocalDateTime_Temporal(t.With_TemporalField_J__LocalDateTime(p0, p1)) }

func (t *LocalDateTime) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_LocalDateTime_Temporal(t.Plus_TemporalAmount__LocalDateTime(p0)) }

func (t *LocalDateTime) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_LocalDateTime_Temporal(t.Plus_J_TemporalUnit__LocalDateTime(p0, p1)) }

func (t *LocalDateTime) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_LocalDateTime_Temporal(t.Minus_TemporalAmount__LocalDateTime(p0)) }

func (t *LocalDateTime) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_LocalDateTime_Temporal(t.Minus_J_TemporalUnit__LocalDateTime(p0, p1)) }

func (t *LocalDateTime) ToLocalDate__ChronoLocalDate() ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.ToLocalDate__LocalDate()) }

func (t *LocalDateTime) With_TemporalAdjuster__ChronoLocalDateTime(p0 TemporalAdjuster) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.With_TemporalAdjuster__LocalDateTime(p0)) }

func (t *LocalDateTime) With_TemporalField_J__ChronoLocalDateTime(p0 TemporalField, p1 int64) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.With_TemporalField_J__LocalDateTime(p0, p1)) }

func (t *LocalDateTime) Plus_TemporalAmount__ChronoLocalDateTime(p0 TemporalAmount) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.Plus_TemporalAmount__LocalDateTime(p0)) }

func (t *LocalDateTime) Plus_J_TemporalUnit__ChronoLocalDateTime(p0 int64, p1 TemporalUnit) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.Plus_J_TemporalUnit__LocalDateTime(p0, p1)) }

func (t *LocalDateTime) Minus_TemporalAmount__ChronoLocalDateTime(p0 TemporalAmount) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.Minus_TemporalAmount__LocalDateTime(p0)) }

func (t *LocalDateTime) Minus_J_TemporalUnit__ChronoLocalDateTime(p0 int64, p1 TemporalUnit) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.Minus_J_TemporalUnit__LocalDateTime(p0, p1)) }

func (t *LocalDateTime) AtZone_ZoneId__ChronoZonedDateTime(p0 ZoneId_I) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.AtZone_ZoneId__ZonedDateTime(p0)) }

func (t *LocalDateTime) CompareTo_O__I(p0 any) int32 { return t.CompareTo_ChronoLocalDateTime__I(ChronoLocalDateTime_Cast(p0)) }

func (t *LocalDateTime) ToInstant_ZoneOffset__Instant(p0 *ZoneOffset) *Instant { return ChronoLocalDateTime_ToInstant_ZoneOffset__Instant(t, p0) }

func (t *LocalDateTime) ToEpochSecond_ZoneOffset__J(p0 *ZoneOffset) int64 { return ChronoLocalDateTime_ToEpochSecond_ZoneOffset__J(t, p0) }

func (t *LocalDateTime) GetChronology__Chronology() Chronology { return ChronoLocalDateTime_GetChronology__Chronology(t) }

func (t *LocalDateTime) Ref() any { if t == nil { return nil }; return t }

func (t *LocalDateTime) GetClass__Class() *Class { return LocalDateTime_class }

func (t *LocalDateTime) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocalDateTime) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocalDateTime_InstanceOf(x any) bool { _, ok := x.(*LocalDateTime); return ok }

func LocalDateTime_Cast(x any) *LocalDateTime { if x == nil { return nil }; v, ok := x.(*LocalDateTime); if !ok { panic(ClassCast(x, LocalDateTime_class)) }; return v }
