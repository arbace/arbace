//line java_util_EmptyStackException.ae:1
package jrt








func EmptyStackException_New() *EmptyStackException { t := &EmptyStackException{}; t.Ctor(); return t }
//line :10:1
func (t *EmptyStackException) Ctor() { t.RuntimeException.Ctor(t) }





type EmptyStackException struct{ RuntimeException }

const EmptyStackException_serialVersionUID int64 = 5084686378493302095

func (t *EmptyStackException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *EmptyStackException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *EmptyStackException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *EmptyStackException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *EmptyStackException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *EmptyStackException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *EmptyStackException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *EmptyStackException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *EmptyStackException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *EmptyStackException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *EmptyStackException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *EmptyStackException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *EmptyStackException) Ref() any { if t == nil { return nil }; return t }

func (t *EmptyStackException) GetClass__Class() *Class { return EmptyStackException_class }

func (t *EmptyStackException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EmptyStackException) CloneShallow() any { panic(CloneNotSupported(t)) }

func EmptyStackException_InstanceOf(x any) bool { _, ok := x.(*EmptyStackException); return ok }

func EmptyStackException_Cast(x any) *EmptyStackException { if x == nil { return nil }; v, ok := x.(*EmptyStackException); if !ok { panic(ClassCast(x, EmptyStackException_class)) }; return v }
