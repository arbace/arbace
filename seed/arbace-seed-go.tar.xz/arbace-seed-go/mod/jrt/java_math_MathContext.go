//line java_math_MathContext.ae:1
package jrt


























func MathContext_New_I(p0 int32) *MathContext { MathContext_Init(); t := &MathContext{}; t.Ctor_I(p0); return t }
//line :28:1
func (t *MathContext) Ctor_I(setPrecision int32) { t.Ctor_I_RoundingMode(setPrecision, MathContext_DEFAULT_ROUNDINGMODE) }


func MathContext_New_I_RoundingMode(p0 int32, p1 *RoundingMode) *MathContext { MathContext_Init(); t := &MathContext{}; t.Ctor_I_RoundingMode(p0, p1); return t }
//line :31:1
func (t *MathContext) Ctor_I_RoundingMode(setPrecision int32, setRoundingMode *RoundingMode) {
	if setPrecision < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1280))) }
	if setRoundingMode == nil { panic(Thrown(NullPointerException_New_String(Lit_1281))) }
	t.F_precision = setPrecision
	t.F_roundingMode = setRoundingMode
}
func MathContext_New_String(p0 *String) *MathContext { MathContext_Init(); t := &MathContext{}; t.Ctor_String(p0); return t }
//line :37:1
func (t *MathContext) Ctor_String(val *String) {
	var setPrecision int32 = 0
	if val == nil { panic(Thrown(NullPointerException_New_String(Lit_1282))) }
//line :38:1
	tmp1 := func() (exc Throwable_I) { defer Catch(&exc)


		if NN(val).StartsWith_String__Z(Lit_1283) { } else { panic(Thrown(RuntimeException_New())) }
		{ var fence int32 = NN(val).IndexOf_I__I(32)
			var off int32 = 10
			setPrecision = Integer_ParseInt_String__I(NN(val).Substring_I_I__String(10, fence))
			if NN(val).StartsWith_String_I__Z(Lit_1284, fence+1) { } else {
				panic(Thrown(RuntimeException_New())) }
			off = fence + 1 + 13
			var str *String = NN(val).Substring_I_I__String(off, NN(val).Length__I())
			t.F_roundingMode = RoundingMode_ValueOf_String__RoundingMode(str) }
//line :38:1
		return nil
	}()
	if tmp1 != nil { if RuntimeException_InstanceOf(tmp1) { var re RuntimeException_I = RuntimeException_Cast(tmp1); _ = re









		panic(Thrown(IllegalArgumentException_New_String(Lit_1285))) } else {
//line :40:1
			panic(tmp1)
		}
	}








	if setPrecision < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1280))) }
	t.F_precision = setPrecision
}
func (t *MathContext) GetPrecision__I() int32 { return t.F_precision }

func (t *MathContext) GetRoundingMode__RoundingMode() *RoundingMode { return t.F_roundingMode }

func (t *MathContext) Equals_O__Z(x any) bool {
	var tmp1 any = x; if MathContext_InstanceOf(tmp1) { var mc *MathContext = MathContext_Cast(tmp1); var tmp2 bool
		tmp2 = mc.F_precision == t.F_precision; if tmp2 {
			tmp2 = mc.F_roundingMode == t.F_roundingMode }
//line :60:1
		return tmp2 } else {
//line :59:1
			return false
		}
}


func (t *MathContext) HashCode__I() int32 {
	var tmp1 int32 = t.F_precision; return tmp1 + NN(t.F_roundingMode).HashCode__I()*59
}
func (t *MathContext) ToString__String() *String {
	var tmp1 int32 = t.F_precision; return Concat(Lit_1283, StrOfInt(tmp1), Lit_1286, NN(t.F_roundingMode).ToString__String())
}


type MathContext struct{ Object; F_precision int32; F_roundingMode *RoundingMode }

func (t *MathContext) Is_Serializable() {}

var MathContext_DEFAULT_ROUNDINGMODE *RoundingMode

const MathContext_MIN_DIGITS int32 = 0

const MathContext_serialVersionUID int64 = 5579720004786848255

var MathContext_UNLIMITED *MathContext

var MathContext_DECIMAL32 *MathContext

var MathContext_DECIMAL64 *MathContext

var MathContext_DECIMAL128 *MathContext

var MathContext_init ClassInit

func MathContext_Init() { if !MathContext_init.Done() { MathContext_init.Run(MathContext_clinit) } }

func MathContext_clinit() { var tmp1 *RoundingMode; RoundingMode_Init(); tmp1 = RoundingMode_HALF_UP; MathContext_DEFAULT_ROUNDINGMODE = tmp1; var tmp2 *RoundingMode; RoundingMode_Init(); tmp2 = RoundingMode_HALF_UP; MathContext_UNLIMITED = MathContext_New_I_RoundingMode(0, tmp2); var tmp3 *RoundingMode; RoundingMode_Init(); tmp3 = RoundingMode_HALF_EVEN; MathContext_DECIMAL32 = MathContext_New_I_RoundingMode(7, tmp3); var tmp4 *RoundingMode; RoundingMode_Init(); tmp4 = RoundingMode_HALF_EVEN; MathContext_DECIMAL64 = MathContext_New_I_RoundingMode(16, tmp4); var tmp5 *RoundingMode; RoundingMode_Init(); tmp5 = RoundingMode_HALF_EVEN; MathContext_DECIMAL128 = MathContext_New_I_RoundingMode(34, tmp5) }

func (t *MathContext) Ref() any { if t == nil { return nil }; return t }

func (t *MathContext) GetClass__Class() *Class { return MathContext_class }

func (t *MathContext) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MathContext) CloneShallow() any { panic(CloneNotSupported(t)) }

func MathContext_InstanceOf(x any) bool { _, ok := x.(*MathContext); return ok }

func MathContext_Cast(x any) *MathContext { if x == nil { return nil }; v, ok := x.(*MathContext); if !ok { panic(ClassCast(x, MathContext_class)) }; return v }
