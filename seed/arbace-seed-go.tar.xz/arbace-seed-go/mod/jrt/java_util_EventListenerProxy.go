//line java_util_EventListenerProxy.ae:1
package jrt









func (t *EventListenerProxy) Ctor_EventListener(this EventListenerProxy_I, listener EventListener) {
	t.F_listener = listener
}
func (t *EventListenerProxy) Impl_GetListener__EventListener(this EventListenerProxy_I) EventListener { return t.F_listener }



type EventListenerProxy struct{ Object; F_listener EventListener }

type EventListenerProxy_I interface{ Object_I; EventListener; Self_EventListenerProxy() *EventListenerProxy; GetListener__EventListener() EventListener }

func (t *EventListenerProxy) Self_EventListenerProxy() *EventListenerProxy { return t }

func (t *EventListenerProxy) Is_EventListener() {}

func EventListenerProxy_InstanceOf(x any) bool { _, ok := x.(EventListenerProxy_I); return ok }

func EventListenerProxy_Cast(x any) EventListenerProxy_I { if x == nil { return nil }; v, ok := x.(EventListenerProxy_I); if !ok { panic(ClassCast(x, EventListenerProxy_class)) }; return v }
