//line java_time_zone_ZoneRulesProvider.ae:1
package jrt





















































func ZoneRulesProvider_GetAvailableZoneIds__Set() Set { ZoneRulesProvider_Init(); return ZoneRulesProvider_ZONE_IDS.Load() }


func ZoneRulesProvider_GetRules_String_Z__ZoneRules(zoneId *String, forCaching bool) *ZoneRules { ZoneRulesProvider_Init()
	Objects_RequireNonNull_O_String__O(zoneId.Ref(), Lit_2143)
	return ZoneRulesProvider_GetProvider_String__ZoneRulesProvider(zoneId).ProvideRules_String_Z__ZoneRules(zoneId, forCaching)
}
func ZoneRulesProvider_GetVersions_String__NavigableMap(zoneId *String) NavigableMap { ZoneRulesProvider_Init()
	Objects_RequireNonNull_O_String__O(zoneId.Ref(), Lit_2143)
	return ZoneRulesProvider_GetProvider_String__ZoneRulesProvider(zoneId).ProvideVersions_String__NavigableMap(zoneId)
}
func ZoneRulesProvider_GetProvider_String__ZoneRulesProvider(zoneId *String) ZoneRulesProvider_I { ZoneRulesProvider_Init()
	var provider ZoneRulesProvider_I = ZoneRulesProvider_Cast(ZoneRulesProvider_ZONES.Get_O__O(zoneId.Ref()))
	if provider == nil {
		if ZoneRulesProvider_ZONES.IsEmpty__Z() { panic(Thrown(ZoneRulesException_New_String(Lit_2586))) }
		panic(Thrown(ZoneRulesException_New_String(Concat(Lit_2546, zoneId)))) }
//line :67:1
	return provider
}




func ZoneRulesProvider_RegisterProvider_ZoneRulesProvider__V(provider ZoneRulesProvider_I) { ZoneRulesProvider_Init()
	Objects_RequireNonNull_O_String__O(provider, Lit_1533)
	ZoneRulesProvider_RegisterProvider0_ZoneRulesProvider__V(provider)
	ZoneRulesProvider_PROVIDERS.Add_O__Z(provider)
}
func ZoneRulesProvider_RegisterProvider0_ZoneRulesProvider__V(provider ZoneRulesProvider_I) { ZoneRulesProvider_Init(); MonitorEnter(ZoneRulesProvider_class); defer MonitorExit(ZoneRulesProvider_class)
	var i_101718 Iterator = provider.ProvideZoneIds__Set().Iterator__Iterator(); for i_101718.HasNext__Z() { var zoneId *String = String_Cast(i_101718.Next__O())
		Objects_RequireNonNull_O_String__O(zoneId.Ref(), Lit_2143)
		var old ZoneRulesProvider_I = ZoneRulesProvider_Cast(ZoneRulesProvider_ZONES.PutIfAbsent_O_O__O(zoneId.Ref(), provider))
		if !(old == nil) {
			if old.Equals_O__Z(provider) { } else {
				ZoneRulesProvider_ZONES.Put_O_O__O(zoneId.Ref(), old)
				provider.ProvideZoneIds__Set().ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0 any) { var id *String = String_Cast(p0);
					ZoneRulesProvider_ZONES.Remove_O_O__Z(id.Ref(), provider) }}) }
			panic(Thrown(ZoneRulesException_New_String(Concat(Lit_2587, zoneId, Lit_2588, StrOfObj(provider)))))
		}
	}


	var combinedSet Set = HashSet_New_Collection(ZoneRulesProvider_ZONES.KeySet__Set())
	ZoneRulesProvider_ZONE_IDS.Store(Collections_UnmodifiableSet_Set__Set(combinedSet))
}
func ZoneRulesProvider_Refresh__Z() bool { ZoneRulesProvider_Init()
	var changed bool = false; var i_101719 Iterator = ZoneRulesProvider_PROVIDERS.Iterator__Iterator(); for i_101719.HasNext__Z() {
		var provider ZoneRulesProvider_I = ZoneRulesProvider_Cast(i_101719.Next__O()); var tmp1 bool; var a_1 bool = changed; var b_2 bool = provider.ProvideRefresh__Z(); var tmp2 bool
		tmp2 = a_1; if !tmp2 { tmp2 = b_2 }; tmp1 = tmp2; changed = tmp1 }
//line :96:1
	return changed
}



func (t *ZoneRulesProvider) Ctor(this ZoneRulesProvider_I) {}








func (t *ZoneRulesProvider) Impl_ProvideRefresh__Z(this ZoneRulesProvider_I) bool { return false }



type ZoneRulesProvider struct{ Object }

type ZoneRulesProvider_I interface{ Object_I; Self_ZoneRulesProvider() *ZoneRulesProvider; ProvideZoneIds__Set() Set; ProvideRules_String_Z__ZoneRules(p0 *String, p1 bool) *ZoneRules; ProvideVersions_String__NavigableMap(p0 *String) NavigableMap; ProvideRefresh__Z() bool }

func (t *ZoneRulesProvider) Self_ZoneRulesProvider() *ZoneRulesProvider { return t }

var ZoneRulesProvider_PROVIDERS List

var ZoneRulesProvider_ZONES ConcurrentMap

var ZoneRulesProvider_ZONE_IDS Volatile[Set]

var ZoneRulesProvider_init ClassInit

func ZoneRulesProvider_Init() { if !ZoneRulesProvider_init.Done() { ZoneRulesProvider_init.Run(ZoneRulesProvider_clinit) } }

func ZoneRulesProvider_clinit() { ZoneRulesProvider_PROVIDERS = Collections_SynchronizedList_List__List(ArrayList_New()); ZoneRulesProvider_ZONES = ConcurrentHashMap_New_I_F_I(512, 0.75, 2)
//line :15:1
	ZoneRulesProvider_RegisterProvider_ZoneRulesProvider__V(TzdbZoneRulesProvider_New())
}



















































































































func ZoneRulesProvider_InstanceOf(x any) bool { _, ok := x.(ZoneRulesProvider_I); return ok }

func ZoneRulesProvider_Cast(x any) ZoneRulesProvider_I { if x == nil { return nil }; v, ok := x.(ZoneRulesProvider_I); if !ok { panic(ClassCast(x, ZoneRulesProvider_class)) }; return v }
