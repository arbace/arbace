//line java_time_Clock.ae:1
package jrt










func Clock_SystemUTC__Clock() Clock_I { Clock_Init(); Clock_SystemClock_Init(); return Up_Clock_SystemClock_Clock(Clock_SystemClock_UTC) }

func Clock_SystemDefaultZone__Clock() Clock_I { Clock_Init()
	return Clock_SystemClock_New_ZoneId(ZoneId_SystemDefault__ZoneId())
}
func Clock_System_ZoneId__Clock(zone ZoneId_I) Clock_I { Clock_Init()
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var tmp1 *ZoneOffset; ZoneOffset_Init(); tmp1 = ZoneOffset_UTC; if any(zone) == any(tmp1.Ref()) { Clock_SystemClock_Init(); return Up_Clock_SystemClock_Clock(Clock_SystemClock_UTC) } else { return Clock_SystemClock_New_ZoneId(zone)
	} }
func Clock_TickMillis_ZoneId__Clock(zone ZoneId_I) Clock_I { Clock_Init()
	return Clock_TickClock_New_Clock_J(Clock_System_ZoneId__Clock(zone), 1000000)
}
func Clock_TickSeconds_ZoneId__Clock(zone ZoneId_I) Clock_I { Clock_Init()
	return Clock_TickClock_New_Clock_J(Clock_System_ZoneId__Clock(zone), 1000000000)
}
func Clock_TickMinutes_ZoneId__Clock(zone ZoneId_I) Clock_I { Clock_Init()
	return Clock_TickClock_New_Clock_J(Clock_System_ZoneId__Clock(zone), 60000000000)
}
func Clock_Tick_Clock_Duration__Clock(baseClock Clock_I, tickDuration *Duration) Clock_I { Clock_Init()
	Objects_RequireNonNull_O_String__O(baseClock, Lit_1985)
	Objects_RequireNonNull_O_String__O(tickDuration.Ref(), Lit_1986)
	if NN(tickDuration).IsNegative__Z() {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1987))) }
	var tickNanos int64 = NN(tickDuration).ToNanos__J()
	if tickNanos%1000000 == 0 { } else {
		if 1000000000%tickNanos == 0 { } else {
			panic(Thrown(IllegalArgumentException_New_String(Lit_1988))) } }
	if tickNanos <= 1 { return baseClock } else { return Clock_TickClock_New_Clock_J(baseClock, tickNanos)
	} }
func Clock_Fixed_Instant_ZoneId__Clock(fixedInstant *Instant, zone ZoneId_I) Clock_I { Clock_Init()
	Objects_RequireNonNull_O_String__O(fixedInstant.Ref(), Lit_1989)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	return Clock_FixedClock_New_Instant_ZoneId(fixedInstant, zone)
}
func Clock_Offset_Clock_Duration__Clock(baseClock Clock_I, offsetDuration *Duration) Clock_I { Clock_Init()
	Objects_RequireNonNull_O_String__O(baseClock, Lit_1985)
	Objects_RequireNonNull_O_String__O(offsetDuration.Ref(), Lit_1990)
	var tmp1 *Duration; Duration_Init(); tmp1 = Duration_ZERO; if NN(offsetDuration).Equals_O__Z(tmp1.Ref()) { return baseClock } else { return Clock_OffsetClock_New_Clock_Duration(baseClock, offsetDuration)
	} }
func (t *Clock) Ctor(this Clock_I) {}





func (t *Clock) Impl_Millis__J(this Clock_I) int64 { return NN(this.Instant__Instant()).ToEpochMilli__J() }



func (t *Clock) Impl_Equals_O__Z(this Clock_I, obj any) bool { return this == obj }

func (t *Clock) Impl_HashCode__I(this Clock_I) int32 { return IdentityHash(this) }






func Clock_CurrentInstant__Instant() *Instant { Clock_Init()
	var localOffset int64 = Clock_offset; var adjustment int64 = VM_GetNanoTimeAdjustment_J__J(localOffset)

	if adjustment == -1 {
		localOffset = System_CurrentTimeMillis__J()/1000 - 1024

		adjustment = VM_GetNanoTimeAdjustment_J__J(localOffset)
		if adjustment == -1 {
			panic(Thrown(InternalError_New_String(Concat(Lit_1991, StrOfLong(localOffset), Lit_1992)))) } else {
				Clock_offset = localOffset } }
	return Instant_OfEpochSecond_J_J__Instant(localOffset, adjustment)
}







func Clock_SystemInstantSource_New() *Clock_SystemInstantSource { Clock_SystemInstantSource_Init(); t := &Clock_SystemInstantSource{}; t.Ctor(); return t }
//line :89:1
func (t *Clock_SystemInstantSource) Ctor() {}

func (t *Clock_SystemInstantSource) WithZone_ZoneId__Clock(zone ZoneId_I) Clock_I {
	return Clock_System_ZoneId__Clock(zone)
}
func (t *Clock_SystemInstantSource) Millis__J() int64 { return System_CurrentTimeMillis__J() }

func (t *Clock_SystemInstantSource) Instant__Instant() *Instant { return Clock_CurrentInstant__Instant() }

func (t *Clock_SystemInstantSource) Equals_O__Z(obj any) bool {
	return Clock_SystemInstantSource_InstanceOf(obj)
}
func (t *Clock_SystemInstantSource) HashCode__I() int32 { return Clock_SystemInstantSource_class.HashCode__I() }

func (t *Clock_SystemInstantSource) ToString__String() *String { return Lit_1997 }

func (t *Clock_SystemInstantSource) ReadResolve__O() any { panic(A2g_NotTranslated("java.time.Clock$SystemInstantSource.readResolve()Ljava/lang/Object;")) }












func Clock_SystemClock_New_ZoneId(p0 ZoneId_I) *Clock_SystemClock { Clock_SystemClock_Init(); t := &Clock_SystemClock{}; t.Ctor_ZoneId(p0); return t }
//line :118:1
func (t *Clock_SystemClock) Ctor_ZoneId(zone ZoneId_I) { t.Clock.Ctor(t); t.F_zone = zone }

func (t *Clock_SystemClock) GetZone__ZoneId() ZoneId_I { return t.F_zone }

func (t *Clock_SystemClock) WithZone_ZoneId__Clock(zone ZoneId_I) Clock_I {
	if zone.Equals_O__Z(t.F_zone) { return t } else { return Clock_SystemClock_New_ZoneId(zone)
	} }
func (t *Clock_SystemClock) Millis__J() int64 { return System_CurrentTimeMillis__J() }

func (t *Clock_SystemClock) Instant__Instant() *Instant { return Clock_CurrentInstant__Instant() }

func (t *Clock_SystemClock) Equals_O__Z(obj any) bool {
	if Clock_SystemClock_InstanceOf(obj) { var tmp1 ZoneId_I = t.F_zone; return tmp1.Equals_O__Z(Clock_SystemClock_Cast(obj).F_zone) } else { return false
	} }
func (t *Clock_SystemClock) HashCode__I() int32 {
	return t.F_zone.HashCode__I() + 1
}
func (t *Clock_SystemClock) ToString__String() *String {
	return Concat(Lit_1996, StrOfObj(t.F_zone), Lit_1189)
}










func Clock_FixedClock_New_Instant_ZoneId(p0 *Instant, p1 ZoneId_I) *Clock_FixedClock { Clock_FixedClock_Init(); t := &Clock_FixedClock{}; t.Ctor_Instant_ZoneId(p0, p1); return t }
//line :148:1
func (t *Clock_FixedClock) Ctor_Instant_ZoneId(fixedInstant *Instant, zone ZoneId_I) { t.Clock.Ctor(t)
	t.F_instant = fixedInstant
	t.F_zone = zone
}
func (t *Clock_FixedClock) GetZone__ZoneId() ZoneId_I { return t.F_zone }

func (t *Clock_FixedClock) WithZone_ZoneId__Clock(zone ZoneId_I) Clock_I {
	if zone.Equals_O__Z(t.F_zone) { return t } else { return Clock_FixedClock_New_Instant_ZoneId(t.F_instant, zone)
	} }
func (t *Clock_FixedClock) Millis__J() int64 { return NN(t.F_instant).ToEpochMilli__J() }

func (t *Clock_FixedClock) Instant__Instant() *Instant { return t.F_instant }

func (t *Clock_FixedClock) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Clock_FixedClock_InstanceOf(tmp1) { var other *Clock_FixedClock = Clock_FixedClock_Cast(tmp1); var tmp2 *Instant = t.F_instant
		if NN(tmp2).Equals_O__Z(other.F_instant.Ref()) { var tmp3 ZoneId_I = t.F_zone; return tmp3.Equals_O__Z(other.F_zone) } else { return false } } else {
//line :162:1
			return false
		}
}

func (t *Clock_FixedClock) HashCode__I() int32 {
	return NN(t.F_instant).HashCode__I() ^ t.F_zone.HashCode__I()
}
func (t *Clock_FixedClock) ToString__String() *String {
	return Concat(Lit_1993, StrOfObj(t.F_instant.Ref()), Lit_1532, StrOfObj(t.F_zone), Lit_1189)
}










func Clock_OffsetClock_New_Clock_Duration(p0 Clock_I, p1 *Duration) *Clock_OffsetClock { Clock_OffsetClock_Init(); t := &Clock_OffsetClock{}; t.Ctor_Clock_Duration(p0, p1); return t }
//line :182:1
func (t *Clock_OffsetClock) Ctor_Clock_Duration(baseClock Clock_I, offset *Duration) { t.Clock.Ctor(t)
	t.F_baseClock = baseClock
	t.F_offset = offset
}
func (t *Clock_OffsetClock) GetZone__ZoneId() ZoneId_I { return t.F_baseClock.GetZone__ZoneId() }

func (t *Clock_OffsetClock) WithZone_ZoneId__Clock(zone ZoneId_I) Clock_I {
	if zone.Equals_O__Z(t.F_baseClock.GetZone__ZoneId()) { return t } else { return Clock_OffsetClock_New_Clock_Duration(t.F_baseClock.WithZone_ZoneId__Clock(zone), t.F_offset)
	} }
func (t *Clock_OffsetClock) Millis__J() int64 {
	return Math_AddExact_J_J__J(t.F_baseClock.Millis__J(), NN(t.F_offset).ToMillis__J())
}
func (t *Clock_OffsetClock) Instant__Instant() *Instant {
	return NN(t.F_baseClock.Instant__Instant()).Plus_TemporalAmount__Instant(Up_Duration_TemporalAmount(t.F_offset))
}
func (t *Clock_OffsetClock) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Clock_OffsetClock_InstanceOf(tmp1) { var other *Clock_OffsetClock = Clock_OffsetClock_Cast(tmp1); var tmp2 Clock_I = t.F_baseClock
		if tmp2.Equals_O__Z(other.F_baseClock) { var tmp3 *Duration = t.F_offset; return NN(tmp3).Equals_O__Z(other.F_offset.Ref()) } else { return false } } else {
//line :198:1
			return false
		}
}

func (t *Clock_OffsetClock) HashCode__I() int32 {
	return t.F_baseClock.HashCode__I() ^ NN(t.F_offset).HashCode__I()
}
func (t *Clock_OffsetClock) ToString__String() *String {
	return Concat(Lit_1994, StrOfObj(t.F_baseClock), Lit_1532, StrOfObj(t.F_offset.Ref()), Lit_1189)
}










func Clock_TickClock_New_Clock_J(p0 Clock_I, p1 int64) *Clock_TickClock { Clock_TickClock_Init(); t := &Clock_TickClock{}; t.Ctor_Clock_J(p0, p1); return t }
//line :218:1
func (t *Clock_TickClock) Ctor_Clock_J(baseClock Clock_I, tickNanos int64) { t.Clock.Ctor(t)
	t.F_baseClock = baseClock
	t.F_tickNanos = tickNanos
}
func (t *Clock_TickClock) GetZone__ZoneId() ZoneId_I { return t.F_baseClock.GetZone__ZoneId() }

func (t *Clock_TickClock) WithZone_ZoneId__Clock(zone ZoneId_I) Clock_I {
	if zone.Equals_O__Z(t.F_baseClock.GetZone__ZoneId()) { return t } else {

		return Clock_TickClock_New_Clock_J(t.F_baseClock.WithZone_ZoneId__Clock(zone), t.F_tickNanos)
	} }
func (t *Clock_TickClock) Millis__J() int64 {
	var millis int64 = t.F_baseClock.Millis__J()
	if t.F_tickNanos < 1000000 { return millis } else {

		return millis - Math_FloorMod_J_J__J(millis, t.F_tickNanos/1000000)
	} }
func (t *Clock_TickClock) Instant__Instant() *Instant {
	if t.F_tickNanos%1000000 == 0 {
		var millis int64 = t.F_baseClock.Millis__J()
		return Instant_OfEpochMilli_J__Instant(millis - Math_FloorMod_J_J__J(millis, t.F_tickNanos/1000000)) } else {


			var instant *Instant = t.F_baseClock.Instant__Instant(); var nanos int64 = int64(NN(instant).GetNano__I()); var adjust int64 = Math_FloorMod_J_J__J(nanos, t.F_tickNanos)


			return NN(instant).MinusNanos_J__Instant(adjust)
		} }
func (t *Clock_TickClock) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Clock_TickClock_InstanceOf(tmp1) { var other *Clock_TickClock = Clock_TickClock_Cast(tmp1); var tmp2 int64 = t.F_tickNanos
		if tmp2 == other.F_tickNanos { var tmp3 Clock_I = t.F_baseClock; return tmp3.Equals_O__Z(other.F_baseClock) } else { return false } } else {
//line :247:1
			return false
		}
}

func (t *Clock_TickClock) HashCode__I() int32 {
	return t.F_baseClock.HashCode__I() ^ Long_HashCode_J__I(t.F_tickNanos)
}
func (t *Clock_TickClock) ToString__String() *String {
	var tmp1 Clock_I = t.F_baseClock; return Concat(Lit_1998, StrOfObj(tmp1), Lit_1532, StrOfObj(Duration_OfNanos_J__Duration(t.F_tickNanos).Ref()), Lit_1189)
}










func Clock_SourceClock_New_InstantSource_ZoneId(p0 InstantSource, p1 ZoneId_I) *Clock_SourceClock { Clock_SourceClock_Init(); t := &Clock_SourceClock{}; t.Ctor_InstantSource_ZoneId(p0, p1); return t }
//line :267:1
func (t *Clock_SourceClock) Ctor_InstantSource_ZoneId(baseSource InstantSource, zone ZoneId_I) { t.Clock.Ctor(t)
	t.F_baseSource = baseSource
	t.F_zone = zone
}
func (t *Clock_SourceClock) GetZone__ZoneId() ZoneId_I { return t.F_zone }

func (t *Clock_SourceClock) WithZone_ZoneId__Clock(zone ZoneId_I) Clock_I {
	if zone.Equals_O__Z(t.F_zone) { return t } else { return Clock_SourceClock_New_InstantSource_ZoneId(t.F_baseSource, zone)
	} }
func (t *Clock_SourceClock) Millis__J() int64 { return t.F_baseSource.Millis__J() }

func (t *Clock_SourceClock) Instant__Instant() *Instant { return t.F_baseSource.Instant__Instant() }

func (t *Clock_SourceClock) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Clock_SourceClock_InstanceOf(tmp1) { var other *Clock_SourceClock = Clock_SourceClock_Cast(tmp1); var tmp2 ZoneId_I = t.F_zone
		if tmp2.Equals_O__Z(other.F_zone) { var tmp3 InstantSource = t.F_baseSource; return tmp3.Equals_O__Z(other.F_baseSource) } else { return false } } else {
//line :281:1
			return false
		}
}

func (t *Clock_SourceClock) HashCode__I() int32 {
	return t.F_baseSource.HashCode__I() ^ t.F_zone.HashCode__I()
}
func (t *Clock_SourceClock) ToString__String() *String {
	return Concat(Lit_1995, StrOfObj(t.F_baseSource), Lit_1532, StrOfObj(t.F_zone), Lit_1189)
}


type Clock struct{ Object }

type Clock_I interface{ Object_I; InstantSource; Self_Clock() *Clock; GetZone__ZoneId() ZoneId_I; WithZone_ZoneId__Clock(p0 ZoneId_I) Clock_I; Millis__J() int64; Instant__Instant() *Instant }

func (t *Clock) Self_Clock() *Clock { return t }

func (t *Clock) Is_InstantSource() {}

var Clock_OFFSET_SEED int64

var Clock_offset int64

var Clock_init ClassInit

func Clock_Init() { if !Clock_init.Done() { Clock_init.Run(Clock_clinit) } }

func Clock_clinit() { Clock_OFFSET_SEED = System_CurrentTimeMillis__J()/1000 - 1024; Clock_offset = Clock_OFFSET_SEED }

func Clock_InstanceOf(x any) bool { _, ok := x.(Clock_I); return ok }

func Clock_Cast(x any) Clock_I { if x == nil { return nil }; v, ok := x.(Clock_I); if !ok { panic(ClassCast(x, Clock_class)) }; return v }



type Clock_FixedClock struct{ Clock; F_instant *Instant; F_zone ZoneId_I }

func (t *Clock_FixedClock) Is_Serializable() {}

const Clock_FixedClock_serialVersionUID int64 = 7430389292664866958

var Clock_FixedClock_init ClassInit

func Clock_FixedClock_Init() { if !Clock_FixedClock_init.Done() { Clock_FixedClock_init.Run(Clock_FixedClock_clinit) } }

func Clock_FixedClock_clinit() { Clock_Init() }

func (t *Clock_FixedClock) Ref() any { if t == nil { return nil }; return t }

func (t *Clock_FixedClock) GetClass__Class() *Class { return Clock_FixedClock_class }

func (t *Clock_FixedClock) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Clock_FixedClock) CloneShallow() any { panic(CloneNotSupported(t)) }

func Clock_FixedClock_InstanceOf(x any) bool { _, ok := x.(*Clock_FixedClock); return ok }

func Clock_FixedClock_Cast(x any) *Clock_FixedClock { if x == nil { return nil }; v, ok := x.(*Clock_FixedClock); if !ok { panic(ClassCast(x, Clock_FixedClock_class)) }; return v }



type Clock_OffsetClock struct{ Clock; F_baseClock Clock_I; F_offset *Duration }

func (t *Clock_OffsetClock) Is_Serializable() {}

const Clock_OffsetClock_serialVersionUID int64 = 2007484719125426256

var Clock_OffsetClock_init ClassInit

func Clock_OffsetClock_Init() { if !Clock_OffsetClock_init.Done() { Clock_OffsetClock_init.Run(Clock_OffsetClock_clinit) } }

func Clock_OffsetClock_clinit() { Clock_Init() }

func (t *Clock_OffsetClock) Ref() any { if t == nil { return nil }; return t }

func (t *Clock_OffsetClock) GetClass__Class() *Class { return Clock_OffsetClock_class }

func (t *Clock_OffsetClock) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Clock_OffsetClock) CloneShallow() any { panic(CloneNotSupported(t)) }

func Clock_OffsetClock_InstanceOf(x any) bool { _, ok := x.(*Clock_OffsetClock); return ok }

func Clock_OffsetClock_Cast(x any) *Clock_OffsetClock { if x == nil { return nil }; v, ok := x.(*Clock_OffsetClock); if !ok { panic(ClassCast(x, Clock_OffsetClock_class)) }; return v }



type Clock_SourceClock struct{ Clock; F_baseSource InstantSource; F_zone ZoneId_I }

func (t *Clock_SourceClock) Is_Serializable() {}

const Clock_SourceClock_serialVersionUID int64 = 235386528762398

var Clock_SourceClock_init ClassInit

func Clock_SourceClock_Init() { if !Clock_SourceClock_init.Done() { Clock_SourceClock_init.Run(Clock_SourceClock_clinit) } }

func Clock_SourceClock_clinit() { Clock_Init() }

func (t *Clock_SourceClock) Ref() any { if t == nil { return nil }; return t }

func (t *Clock_SourceClock) GetClass__Class() *Class { return Clock_SourceClock_class }

func (t *Clock_SourceClock) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Clock_SourceClock) CloneShallow() any { panic(CloneNotSupported(t)) }

func Clock_SourceClock_InstanceOf(x any) bool { _, ok := x.(*Clock_SourceClock); return ok }

func Clock_SourceClock_Cast(x any) *Clock_SourceClock { if x == nil { return nil }; v, ok := x.(*Clock_SourceClock); if !ok { panic(ClassCast(x, Clock_SourceClock_class)) }; return v }



type Clock_SystemClock struct{ Clock; F_zone ZoneId_I }

func (t *Clock_SystemClock) Is_Serializable() {}

const Clock_SystemClock_serialVersionUID int64 = 6740630888130243051

var Clock_SystemClock_UTC *Clock_SystemClock

var Clock_SystemClock_init ClassInit

func Clock_SystemClock_Init() { if !Clock_SystemClock_init.Done() { Clock_SystemClock_init.Run(Clock_SystemClock_clinit) } }

func Clock_SystemClock_clinit() { Clock_Init(); var tmp1 *ZoneOffset; ZoneOffset_Init(); tmp1 = ZoneOffset_UTC; Clock_SystemClock_UTC = Clock_SystemClock_New_ZoneId(Up_ZoneOffset_ZoneId(tmp1)) }

func (t *Clock_SystemClock) Ref() any { if t == nil { return nil }; return t }

func (t *Clock_SystemClock) GetClass__Class() *Class { return Clock_SystemClock_class }

func (t *Clock_SystemClock) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Clock_SystemClock) CloneShallow() any { panic(CloneNotSupported(t)) }

func Clock_SystemClock_InstanceOf(x any) bool { _, ok := x.(*Clock_SystemClock); return ok }

func Clock_SystemClock_Cast(x any) *Clock_SystemClock { if x == nil { return nil }; v, ok := x.(*Clock_SystemClock); if !ok { panic(ClassCast(x, Clock_SystemClock_class)) }; return v }



type Clock_SystemInstantSource struct{ Object }

func (t *Clock_SystemInstantSource) Is_InstantSource() {}

func (t *Clock_SystemInstantSource) Is_Serializable() {}

const Clock_SystemInstantSource_serialVersionUID int64 = 3232399674412

var Clock_SystemInstantSource_INSTANCE *Clock_SystemInstantSource

var Clock_SystemInstantSource_init ClassInit

func Clock_SystemInstantSource_Init() { if !Clock_SystemInstantSource_init.Done() { Clock_SystemInstantSource_init.Run(Clock_SystemInstantSource_clinit) } }

func Clock_SystemInstantSource_clinit() { Clock_SystemInstantSource_INSTANCE = Clock_SystemInstantSource_New() }

func (t *Clock_SystemInstantSource) Ref() any { if t == nil { return nil }; return t }

func (t *Clock_SystemInstantSource) GetClass__Class() *Class { return Clock_SystemInstantSource_class }

func (t *Clock_SystemInstantSource) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Clock_SystemInstantSource) CloneShallow() any { panic(CloneNotSupported(t)) }

func Clock_SystemInstantSource_InstanceOf(x any) bool { _, ok := x.(*Clock_SystemInstantSource); return ok }

func Clock_SystemInstantSource_Cast(x any) *Clock_SystemInstantSource { if x == nil { return nil }; v, ok := x.(*Clock_SystemInstantSource); if !ok { panic(ClassCast(x, Clock_SystemInstantSource_class)) }; return v }



type Clock_TickClock struct{ Clock; F_baseClock Clock_I; F_tickNanos int64 }

func (t *Clock_TickClock) Is_Serializable() {}

const Clock_TickClock_serialVersionUID int64 = 6504659149906368850

var Clock_TickClock_init ClassInit

func Clock_TickClock_Init() { if !Clock_TickClock_init.Done() { Clock_TickClock_init.Run(Clock_TickClock_clinit) } }

func Clock_TickClock_clinit() { Clock_Init() }

func (t *Clock_TickClock) Ref() any { if t == nil { return nil }; return t }

func (t *Clock_TickClock) GetClass__Class() *Class { return Clock_TickClock_class }

func (t *Clock_TickClock) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Clock_TickClock) CloneShallow() any { panic(CloneNotSupported(t)) }

func Clock_TickClock_InstanceOf(x any) bool { _, ok := x.(*Clock_TickClock); return ok }

func Clock_TickClock_Cast(x any) *Clock_TickClock { if x == nil { return nil }; v, ok := x.(*Clock_TickClock); if !ok { panic(ClassCast(x, Clock_TickClock_class)) }; return v }
