//line java_lang_StackOverflowError.ae:1
package jrt








func StackOverflowError_New() *StackOverflowError { t := &StackOverflowError{}; t.Ctor(); return t }
//line :10:1
func (t *StackOverflowError) Ctor() { t.VirtualMachineError.Ctor(t) }

func StackOverflowError_New_String(p0 *String) *StackOverflowError { t := &StackOverflowError{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *StackOverflowError) Ctor_String(s *String) { t.VirtualMachineError.Ctor_String(t, s) }







type StackOverflowError struct{ VirtualMachineError }

const StackOverflowError_serialVersionUID int64 = 8609175038441759607

func (t *StackOverflowError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *StackOverflowError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *StackOverflowError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *StackOverflowError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *StackOverflowError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *StackOverflowError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *StackOverflowError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *StackOverflowError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *StackOverflowError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *StackOverflowError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *StackOverflowError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *StackOverflowError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *StackOverflowError) Ref() any { if t == nil { return nil }; return t }

func (t *StackOverflowError) GetClass__Class() *Class { return StackOverflowError_class }

func (t *StackOverflowError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StackOverflowError) CloneShallow() any { panic(CloneNotSupported(t)) }

func StackOverflowError_InstanceOf(x any) bool { _, ok := x.(*StackOverflowError); return ok }

func StackOverflowError_Cast(x any) *StackOverflowError { if x == nil { return nil }; v, ok := x.(*StackOverflowError); if !ok { panic(ClassCast(x, StackOverflowError_class)) }; return v }
