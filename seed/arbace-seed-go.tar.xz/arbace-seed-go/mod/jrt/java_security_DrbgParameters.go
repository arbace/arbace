//line java_security_DrbgParameters.ae:1
package jrt






func DrbgParameters_New() *DrbgParameters { t := &DrbgParameters{}; t.Ctor(); return t }
//line :8:1
func (t *DrbgParameters) Ctor() { panic(A2g_NotTranslated("java.security.DrbgParameters.<init>()V")) }




func (t *DrbgParameters_Capability) ToString__String() *String {
	var tmp1 *String = t.Name__String(); var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; return NN(tmp1).ToLowerCase_Locale__String(tmp2)
}
func (t *DrbgParameters_Capability) SupportsReseeding__Z() bool {
	return !(t == DrbgParameters_Capability_NONE)
}
func (t *DrbgParameters_Capability) SupportsPredictionResistance__Z() bool {
	return t == DrbgParameters_Capability_PR_AND_RESEED
}









func (t *DrbgParameters_Instantiation) GetStrength__I() int32 { return t.F_strength }

func (t *DrbgParameters_Instantiation) GetCapability__DrbgParameters_Capability() *DrbgParameters_Capability { return t.F_capability }

func (t *DrbgParameters_Instantiation) GetPersonalizationString__B1() *ByteArray {
	if !(t.F_personalizationString == nil) { return NN(t.F_personalizationString).Copy() } else { return nil
	} }
func DrbgParameters_Instantiation_New_I_DrbgParameters_Capability_B1(p0 int32, p1 *DrbgParameters_Capability, p2 *ByteArray) *DrbgParameters_Instantiation { t := &DrbgParameters_Instantiation{}; t.Ctor_I_DrbgParameters_Capability_B1(p0, p1, p2); return t }
//line :38:1
func (t *DrbgParameters_Instantiation) Ctor_I_DrbgParameters_Capability_B1(strength int32, capability *DrbgParameters_Capability, personalizationString *ByteArray) {
	if strength < -1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1531, StrOfInt(strength))))) }
	t.F_strength = strength
	t.F_capability = capability
	var tmp1 *ByteArray
	if !(personalizationString == nil) { tmp1 = NN(personalizationString).Copy() } else { tmp1 = nil }
//line :43:1
	t.F_personalizationString = tmp1
}

func (t *DrbgParameters_Instantiation) ToString__String() *String {
	var tmp1 int32 = t.F_strength; var tmp2 *DrbgParameters_Capability = t.F_capability; return Concat(StrOfInt(tmp1), Lit_1532, StrOfObj(tmp2.Ref()), Lit_1532, Arrays_ToString_B1__String(t.F_personalizationString))
}









func (t *DrbgParameters_NextBytes) GetStrength__I() int32 { return t.F_strength }

func (t *DrbgParameters_NextBytes) GetPredictionResistance__Z() bool { return t.F_predictionResistance }


func (t *DrbgParameters_NextBytes) GetAdditionalInput__B1() *ByteArray {
	if !(t.F_additionalInput == nil) { return NN(t.F_additionalInput).Copy() } else { return nil
	} }
func DrbgParameters_NextBytes_New_I_Z_B1(p0 int32, p1 bool, p2 *ByteArray) *DrbgParameters_NextBytes { t := &DrbgParameters_NextBytes{}; t.Ctor_I_Z_B1(p0, p1, p2); return t }
//line :66:1
func (t *DrbgParameters_NextBytes) Ctor_I_Z_B1(strength int32, predictionResistance bool, additionalInput *ByteArray) {
	if strength < -1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1531, StrOfInt(strength))))) }
	t.F_strength = strength
	t.F_predictionResistance = predictionResistance
	var tmp1 *ByteArray; if !(additionalInput == nil) { tmp1 = NN(additionalInput).Copy() } else { tmp1 = nil }; t.F_additionalInput = tmp1
}







func (t *DrbgParameters_Reseed) GetPredictionResistance__Z() bool { return t.F_predictionResistance }


func (t *DrbgParameters_Reseed) GetAdditionalInput__B1() *ByteArray {
	if !(t.F_additionalInput == nil) { return NN(t.F_additionalInput).Copy() } else { return nil
	} }
func DrbgParameters_Reseed_New_Z_B1(p0 bool, p1 *ByteArray) *DrbgParameters_Reseed { t := &DrbgParameters_Reseed{}; t.Ctor_Z_B1(p0, p1); return t }
//line :86:1
func (t *DrbgParameters_Reseed) Ctor_Z_B1(predictionResistance bool, additionalInput *ByteArray) {
	t.F_predictionResistance = predictionResistance
	var tmp1 *ByteArray; if !(additionalInput == nil) { tmp1 = NN(additionalInput).Copy() } else { tmp1 = nil }; t.F_additionalInput = tmp1
}
func DrbgParameters_Instantiation_I_DrbgParameters_Capability_B1__DrbgParameters_Instantiation(strength int32, capability *DrbgParameters_Capability, personalizationString *ByteArray) *DrbgParameters_Instantiation {

	return DrbgParameters_Instantiation_New_I_DrbgParameters_Capability_B1(strength, DrbgParameters_Capability_Cast(Objects_RequireNonNull_O__O(capability.Ref())), personalizationString)
}


func DrbgParameters_NextBytes_I_Z_B1__DrbgParameters_NextBytes(strength int32, predictionResistance bool, additionalInput *ByteArray) *DrbgParameters_NextBytes {

	return DrbgParameters_NextBytes_New_I_Z_B1(strength, predictionResistance, additionalInput)
}
func DrbgParameters_Reseed_Z_B1__DrbgParameters_Reseed(predictionResistance bool, additionalInput *ByteArray) *DrbgParameters_Reseed {
	return DrbgParameters_Reseed_New_Z_B1(predictionResistance, additionalInput)
}


type DrbgParameters struct{ Object }

func (t *DrbgParameters) Ref() any { if t == nil { return nil }; return t }

func (t *DrbgParameters) GetClass__Class() *Class { return DrbgParameters_class }

func (t *DrbgParameters) ToString__String() *String { return Object_toString(t) }

func (t *DrbgParameters) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DrbgParameters) CloneShallow() any { panic(CloneNotSupported(t)) }

func DrbgParameters_InstanceOf(x any) bool { _, ok := x.(*DrbgParameters); return ok }

func DrbgParameters_Cast(x any) *DrbgParameters { if x == nil { return nil }; v, ok := x.(*DrbgParameters); if !ok { panic(ClassCast(x, DrbgParameters_class)) }; return v }



type DrbgParameters_Capability struct{ Enum }

func (t *DrbgParameters_Capability) Is_Constable() {}

var DrbgParameters_Capability_PR_AND_RESEED *DrbgParameters_Capability

var DrbgParameters_Capability_RESEED_ONLY *DrbgParameters_Capability

var DrbgParameters_Capability_NONE *DrbgParameters_Capability

var DrbgParameters_Capability__VALUES *RefArray

var DrbgParameters_Capability_init ClassInit

func DrbgParameters_Capability_Init() { if !DrbgParameters_Capability_init.Done() { DrbgParameters_Capability_init.Run(DrbgParameters_Capability_clinit) } }

func DrbgParameters_Capability_clinit() { DrbgParameters_Capability_PR_AND_RESEED = DrbgParameters_Capability_New_String_I(Lit_1528, 0); DrbgParameters_Capability_RESEED_ONLY = DrbgParameters_Capability_New_String_I(Lit_1529, 1); DrbgParameters_Capability_NONE = DrbgParameters_Capability_New_String_I(Lit_1530, 2); DrbgParameters_Capability__VALUES = DrbgParameters_Capability_X_values__DrbgParameters_Capability1() }

func DrbgParameters_Capability_New_String_I(p0 *String, p1 int32) *DrbgParameters_Capability { DrbgParameters_Capability_Init(); t := &DrbgParameters_Capability{}; t.Ctor_String_I(p0, p1); return t }

func (t *DrbgParameters_Capability) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func DrbgParameters_Capability_Values__DrbgParameters_Capability1() *RefArray { DrbgParameters_Capability_Init(); return DrbgParameters_Capability__VALUES.Copy() }

func DrbgParameters_Capability_ValueOf_String__DrbgParameters_Capability(p0 *String) *DrbgParameters_Capability { DrbgParameters_Capability_Init(); return DrbgParameters_Capability_Cast(Enum_ValueOf_Class_String__Enum(DrbgParameters_Capability_class, p0)) }

func DrbgParameters_Capability_X_values__DrbgParameters_Capability1() *RefArray { DrbgParameters_Capability_Init(); return RefArrayOf(DrbgParameters_Capability_class, DrbgParameters_Capability_PR_AND_RESEED, DrbgParameters_Capability_RESEED_ONLY, DrbgParameters_Capability_NONE) }

func (t *DrbgParameters_Capability) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *DrbgParameters_Capability) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *DrbgParameters_Capability) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *DrbgParameters_Capability) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.security.DrbgParameters$Capability.describeConstable()Ljava/util/Optional;")) }

func (t *DrbgParameters_Capability) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *DrbgParameters_Capability) Ref() any { if t == nil { return nil }; return t }

func (t *DrbgParameters_Capability) GetClass__Class() *Class { return DrbgParameters_Capability_class }

func (t *DrbgParameters_Capability) CloneShallow() any { panic(CloneNotSupported(t)) }

func DrbgParameters_Capability_InstanceOf(x any) bool { _, ok := x.(*DrbgParameters_Capability); return ok }

func DrbgParameters_Capability_Cast(x any) *DrbgParameters_Capability { if x == nil { return nil }; v, ok := x.(*DrbgParameters_Capability); if !ok { panic(ClassCast(x, DrbgParameters_Capability_class)) }; return v }



type DrbgParameters_Instantiation struct{ Object; F_strength int32; F_capability *DrbgParameters_Capability; F_personalizationString *ByteArray }

func (t *DrbgParameters_Instantiation) Is_SecureRandomParameters() {}

func (t *DrbgParameters_Instantiation) Ref() any { if t == nil { return nil }; return t }

func (t *DrbgParameters_Instantiation) GetClass__Class() *Class { return DrbgParameters_Instantiation_class }

func (t *DrbgParameters_Instantiation) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DrbgParameters_Instantiation) CloneShallow() any { panic(CloneNotSupported(t)) }

func DrbgParameters_Instantiation_InstanceOf(x any) bool { _, ok := x.(*DrbgParameters_Instantiation); return ok }

func DrbgParameters_Instantiation_Cast(x any) *DrbgParameters_Instantiation { if x == nil { return nil }; v, ok := x.(*DrbgParameters_Instantiation); if !ok { panic(ClassCast(x, DrbgParameters_Instantiation_class)) }; return v }



type DrbgParameters_NextBytes struct{ Object; F_strength int32; F_predictionResistance bool; F_additionalInput *ByteArray }

func (t *DrbgParameters_NextBytes) Is_SecureRandomParameters() {}

func (t *DrbgParameters_NextBytes) Ref() any { if t == nil { return nil }; return t }

func (t *DrbgParameters_NextBytes) GetClass__Class() *Class { return DrbgParameters_NextBytes_class }

func (t *DrbgParameters_NextBytes) ToString__String() *String { return Object_toString(t) }

func (t *DrbgParameters_NextBytes) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DrbgParameters_NextBytes) CloneShallow() any { panic(CloneNotSupported(t)) }

func DrbgParameters_NextBytes_InstanceOf(x any) bool { _, ok := x.(*DrbgParameters_NextBytes); return ok }

func DrbgParameters_NextBytes_Cast(x any) *DrbgParameters_NextBytes { if x == nil { return nil }; v, ok := x.(*DrbgParameters_NextBytes); if !ok { panic(ClassCast(x, DrbgParameters_NextBytes_class)) }; return v }



type DrbgParameters_Reseed struct{ Object; F_additionalInput *ByteArray; F_predictionResistance bool }

func (t *DrbgParameters_Reseed) Is_SecureRandomParameters() {}

func (t *DrbgParameters_Reseed) Ref() any { if t == nil { return nil }; return t }

func (t *DrbgParameters_Reseed) GetClass__Class() *Class { return DrbgParameters_Reseed_class }

func (t *DrbgParameters_Reseed) ToString__String() *String { return Object_toString(t) }

func (t *DrbgParameters_Reseed) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DrbgParameters_Reseed) CloneShallow() any { panic(CloneNotSupported(t)) }

func DrbgParameters_Reseed_InstanceOf(x any) bool { _, ok := x.(*DrbgParameters_Reseed); return ok }

func DrbgParameters_Reseed_Cast(x any) *DrbgParameters_Reseed { if x == nil { return nil }; v, ok := x.(*DrbgParameters_Reseed); if !ok { panic(ClassCast(x, DrbgParameters_Reseed_class)) }; return v }
