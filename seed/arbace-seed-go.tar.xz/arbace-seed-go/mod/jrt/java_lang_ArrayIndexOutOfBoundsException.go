//line java_lang_ArrayIndexOutOfBoundsException.ae:1
package jrt








func ArrayIndexOutOfBoundsException_New() *ArrayIndexOutOfBoundsException { t := &ArrayIndexOutOfBoundsException{}; t.Ctor(); return t }
//line :10:1
func (t *ArrayIndexOutOfBoundsException) Ctor() { t.IndexOutOfBoundsException.Ctor(t) }

func ArrayIndexOutOfBoundsException_New_String(p0 *String) *ArrayIndexOutOfBoundsException { t := &ArrayIndexOutOfBoundsException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *ArrayIndexOutOfBoundsException) Ctor_String(s *String) { t.IndexOutOfBoundsException.Ctor_String(t, s) }

func ArrayIndexOutOfBoundsException_New_I(p0 int32) *ArrayIndexOutOfBoundsException { t := &ArrayIndexOutOfBoundsException{}; t.Ctor_I(p0); return t }
//line :14:1
func (t *ArrayIndexOutOfBoundsException) Ctor_I(index int32) { t.IndexOutOfBoundsException.Ctor_String(t, Concat(Lit_105, StrOfInt(index))) }









type ArrayIndexOutOfBoundsException struct{ IndexOutOfBoundsException }

const ArrayIndexOutOfBoundsException_serialVersionUID int64 = -5116101128118950844

func (t *ArrayIndexOutOfBoundsException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ArrayIndexOutOfBoundsException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ArrayIndexOutOfBoundsException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ArrayIndexOutOfBoundsException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ArrayIndexOutOfBoundsException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ArrayIndexOutOfBoundsException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ArrayIndexOutOfBoundsException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ArrayIndexOutOfBoundsException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ArrayIndexOutOfBoundsException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ArrayIndexOutOfBoundsException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ArrayIndexOutOfBoundsException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ArrayIndexOutOfBoundsException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ArrayIndexOutOfBoundsException) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayIndexOutOfBoundsException) GetClass__Class() *Class { return ArrayIndexOutOfBoundsException_class }

func (t *ArrayIndexOutOfBoundsException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayIndexOutOfBoundsException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayIndexOutOfBoundsException_InstanceOf(x any) bool { _, ok := x.(*ArrayIndexOutOfBoundsException); return ok }

func ArrayIndexOutOfBoundsException_Cast(x any) *ArrayIndexOutOfBoundsException { if x == nil { return nil }; v, ok := x.(*ArrayIndexOutOfBoundsException); if !ok { panic(ClassCast(x, ArrayIndexOutOfBoundsException_class)) }; return v }
