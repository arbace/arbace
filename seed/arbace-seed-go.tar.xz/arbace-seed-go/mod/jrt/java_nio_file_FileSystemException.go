//line java_nio_file_FileSystemException.ae:1
package jrt














func FileSystemException_New_String(p0 *String) *FileSystemException { t := &FileSystemException{}; t.Ctor_String(t, p0); return t }
//line :16:1
func (t *FileSystemException) Ctor_String(this FileSystemException_I, file *String) { t.IOException.Ctor_String(this, nil)

	t.F_file = file
	t.F_other = nil
}
func FileSystemException_New_String_String_String(p0, p1, p2 *String) *FileSystemException { t := &FileSystemException{}; t.Ctor_String_String_String(t, p0, p1, p2); return t }
//line :21:1
func (t *FileSystemException) Ctor_String_String_String(this FileSystemException_I, file, other, reason *String) { t.IOException.Ctor_String(this, reason)

	t.F_file = file
	t.F_other = other
}
func (t *FileSystemException) Impl_GetFile__String(this FileSystemException_I) *String { return t.F_file }

func (t *FileSystemException) Impl_GetOtherFile__String(this FileSystemException_I) *String { return t.F_other }

func (t *FileSystemException) Impl_GetReason__String(this FileSystemException_I) *String { return t.IOException.Impl_GetMessage__String(this) }

func (t *FileSystemException) Impl_GetMessage__String(this FileSystemException_I) *String {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_file == nil; if tmp2 { tmp2 = t.F_other == nil }; tmp1 = tmp2; if tmp1 {
		return this.GetReason__String() } else {
			var sb *StringBuilder = StringBuilder_New()
			if !(t.F_file == nil) { NN(sb).Append_String__StringBuilder(t.F_file) }
			if !(t.F_other == nil) { NN(sb).Append_String__StringBuilder(Lit_1495); NN(sb).Append_String__StringBuilder(t.F_other) }
			if !(this.GetReason__String() == nil) { NN(sb).Append_String__StringBuilder(Lit_1157); NN(sb).Append_String__StringBuilder(this.GetReason__String()) }
			return NN(sb).ToString__String()
		}
}

type FileSystemException struct{ IOException; F_file, F_other *String }

type FileSystemException_I interface{ IOException_I; Serializable; Self_FileSystemException() *FileSystemException; GetFile__String() *String; GetOtherFile__String() *String; GetReason__String() *String; GetMessage__String() *String }

func (t *FileSystemException) Self_FileSystemException() *FileSystemException { return t }

const FileSystemException_serialVersionUID int64 = -3055425747967319812

func (t *FileSystemException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *FileSystemException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *FileSystemException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *FileSystemException) GetFile__String() *String { return t.Impl_GetFile__String(t) }

func (t *FileSystemException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *FileSystemException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *FileSystemException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *FileSystemException) GetReason__String() *String { return t.Impl_GetReason__String(t) }

func (t *FileSystemException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *FileSystemException) GetOtherFile__String() *String { return t.Impl_GetOtherFile__String(t) }

func (t *FileSystemException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *FileSystemException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *FileSystemException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *FileSystemException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *FileSystemException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *FileSystemException) Ref() any { if t == nil { return nil }; return t }

func (t *FileSystemException) GetClass__Class() *Class { return FileSystemException_class }

func (t *FileSystemException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileSystemException) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileSystemException_InstanceOf(x any) bool { _, ok := x.(FileSystemException_I); return ok }

func FileSystemException_Cast(x any) FileSystemException_I { if x == nil { return nil }; v, ok := x.(FileSystemException_I); if !ok { panic(ClassCast(x, FileSystemException_class)) }; return v }
