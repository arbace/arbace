//line image.ae:1
package jrt

import (
	"sync/atomic"
	"unicode/utf16"
)
// ImageHooks is the program's image of prepared namespaces (Compiler$Image's natives): set by
// the main package when it has one; without it nothing is recorded or replayed.
type ImageHooks /*line :12:1*/ interface {
	Mode() int32
	Begin(name string) bool
	Unit(name string, u *RefArray)
	End(name string, ok bool)
	Has(name string) bool
	Next(name string) *RefArray
	Resolve(name string, k int32, strict bool)
	Started() }
// Image is the program's image hooks, or nil.
var Image ImageHooks

func Compiler_Image_Mode__I_native() int32 {
	if Image == nil {
		return 0 }
	return Image.Mode()
}
func Compiler_Image_Begin_String__Z_native(name *String) bool {
	if Image == nil {
		return false }
	return Image.Begin(NN(name).String())
}
func Compiler_Image_Unit_String_O1__V_native(name *String, u *RefArray) {
	if Image != nil {
		Image.Unit(NN(name).String(), u)
	} }
func Compiler_Image_End_String_Z__V_native(name *String, ok bool) {
	if Image != nil {
		Image.End(NN(name).String(), ok)
	} }
func Compiler_Image_Has_String__Z_native(name *String) bool {
	if Image == nil {
		return false }
	return Image.Has(NN(name).String())
}
func Compiler_Image_Next_String__O1_native(name *String) *RefArray {
	if Image == nil {
		return nil }
	return Image.Next(NN(name).String())
}
func Compiler_Image_Resolve_String_I_Z__V_native(name *String, k int32, strict bool) {
	if Image != nil {
		Image.Resolve(NN(name).String(), k, strict)
	} }
func Compiler_Image_Started__V_native() {
	if Image != nil {
		Image.Started()
	}
}


// PeekIdentityHash is the identity hash x's header holds, 0 when none was assigned yet.
func PeekIdentityHash(x any) int32 {


	o, ok := x.(Object_I)
	if !ok {
		return 0 }
	return int32(uint32(atomic.LoadUint64(&o.Self_Object().hdr))) }
// SetIdentityHash gives the fresh object x the identity hash h (decoding: the hash it had
// when it was encoded, so that hashed collections of it keep their layout).
//line :72:1
func SetIdentityHash(x any, h int32) {



	o, ok := x.(Object_I)
	if ok {
		atomic.StoreUint64(&o.Self_Object().hdr, uint64(uint32(h))) } }
// presetClassHash gives a new Class the identity hash of its name (String.hashCode's, 31
// bits, never 0): classes hash alike in every run of the program, so that the hashed collections
// of the image of prepared namespaces keep their layout where classes are keys (EXEC-NOTES.md).
//line :80:1
func presetClassHash(c /*line :84:1*/*Class, name string) {
	var h uint32 = 0
	for _, u := range utf16.Encode([]rune(name)) {
		h = 31*h + uint32(u) }
	h = h & 2147483647
	if h == 0 {
		h = 1 }
	atomic.StoreUint64(&c.Object.hdr, uint64(h))
}
