//line java_nio_file_NoSuchFileException.ae:1
package jrt








func NoSuchFileException_New_String(p0 *String) *NoSuchFileException { t := &NoSuchFileException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *NoSuchFileException) Ctor_String(file *String) { t.FileSystemException.Ctor_String(t, file) }

func NoSuchFileException_New_String_String_String(p0, p1, p2 *String) *NoSuchFileException { t := &NoSuchFileException{}; t.Ctor_String_String_String(p0, p1, p2); return t }
//line :12:1
func (t *NoSuchFileException) Ctor_String_String_String(file, other, reason *String) { t.FileSystemException.Ctor_String_String_String(t, file, other, reason) }







type NoSuchFileException struct{ FileSystemException }

const NoSuchFileException_serialVersionUID int64 = -1390291775875351931

func (t *NoSuchFileException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoSuchFileException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoSuchFileException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoSuchFileException) GetFile__String() *String { return t.Impl_GetFile__String(t) }

func (t *NoSuchFileException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoSuchFileException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoSuchFileException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoSuchFileException) GetReason__String() *String { return t.Impl_GetReason__String(t) }

func (t *NoSuchFileException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoSuchFileException) GetOtherFile__String() *String { return t.Impl_GetOtherFile__String(t) }

func (t *NoSuchFileException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoSuchFileException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoSuchFileException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoSuchFileException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoSuchFileException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoSuchFileException) Ref() any { if t == nil { return nil }; return t }

func (t *NoSuchFileException) GetClass__Class() *Class { return NoSuchFileException_class }

func (t *NoSuchFileException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoSuchFileException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoSuchFileException_InstanceOf(x any) bool { _, ok := x.(*NoSuchFileException); return ok }

func NoSuchFileException_Cast(x any) *NoSuchFileException { if x == nil { return nil }; v, ok := x.(*NoSuchFileException); if !ok { panic(ClassCast(x, NoSuchFileException_class)) }; return v }
