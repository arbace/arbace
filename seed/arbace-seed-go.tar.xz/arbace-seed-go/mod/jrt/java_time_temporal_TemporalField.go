//line java_time_temporal_TemporalField.ae:1
package jrt







func TemporalField_GetDisplayName_Locale__String(this TemporalField, locale *Locale) *String {
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176)
	return this.ToString__String()
}


















func TemporalField_Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(this TemporalField, fieldValues Map, partialTemporal TemporalAccessor, resolverStyle *ResolverStyle) TemporalAccessor { return nil }



type TemporalField interface{ Object_I; Is_TemporalField(); GetDisplayName_Locale__String(p0 *Locale) *String; GetBaseUnit__TemporalUnit() TemporalUnit; GetRangeUnit__TemporalUnit() TemporalUnit; Range__ValueRange() *ValueRange; IsDateBased__Z() bool; IsTimeBased__Z() bool; IsSupportedBy_TemporalAccessor__Z(p0 TemporalAccessor) bool; RangeRefinedBy_TemporalAccessor__ValueRange(p0 TemporalAccessor) *ValueRange; GetFrom_TemporalAccessor__J(p0 TemporalAccessor) int64; AdjustInto_Temporal_J__Temporal(p0 Temporal, p1 int64) Temporal; Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor }

func TemporalField_InstanceOf(x any) bool { _, ok := x.(TemporalField); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalField_class) } }; return ok }

func TemporalField_Cast(x any) TemporalField { if x == nil { return nil }; v, ok := x.(TemporalField); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(TemporalField_class) } }; if !ok { panic(ClassCast(x, TemporalField_class)) }; return v }
