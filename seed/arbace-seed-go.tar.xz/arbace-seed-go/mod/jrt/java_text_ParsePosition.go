//line java_text_ParsePosition.ae:1
package jrt








func (t *ParsePosition) GetIndex__I() int32 { return t.F_index }

func (t *ParsePosition) SetIndex_I__V(index int32) {
	t.F_index = index
}
func ParsePosition_New_I(p0 int32) *ParsePosition { t := &ParsePosition{}; t.Ctor_I(p0); return t }
//line :15:1
func (t *ParsePosition) Ctor_I(index int32) { t.F_index = 0; t.F_errorIndex = -1; t.F_index = index }

func (t *ParsePosition) SetErrorIndex_I__V(ei int32) {
	t.F_errorIndex = ei
}
func (t *ParsePosition) GetErrorIndex__I() int32 { return t.F_errorIndex }

func (t *ParsePosition) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if ParsePosition_InstanceOf(tmp1) { var other *ParsePosition = ParsePosition_Cast(tmp1); var tmp2 int32 = t.F_index
		if tmp2 == other.F_index { var tmp3 int32 = t.F_errorIndex; return tmp3 == other.F_errorIndex } else { return false } } else {
//line :23:1
			return false
		}
}

func (t *ParsePosition) HashCode__I() int32 {
	return t.F_errorIndex<<16 | t.F_index
}
func (t *ParsePosition) ToString__String() *String {
	return Concat(NN(t.GetClass__Class()).GetName__String(), Lit_1962, StrOfInt(t.F_index), Lit_1963, StrOfInt(t.F_errorIndex), Lit_1189)
}


type ParsePosition struct{ Object; F_index, F_errorIndex int32 }

func (t *ParsePosition) Ref() any { if t == nil { return nil }; return t }

func (t *ParsePosition) GetClass__Class() *Class { return ParsePosition_class }

func (t *ParsePosition) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ParsePosition) CloneShallow() any { panic(CloneNotSupported(t)) }

func ParsePosition_InstanceOf(x any) bool { _, ok := x.(*ParsePosition); return ok }

func ParsePosition_Cast(x any) *ParsePosition { if x == nil { return nil }; v, ok := x.(*ParsePosition); if !ok { panic(ClassCast(x, ParsePosition_class)) }; return v }
