//line java_util_LinkedHashSet.ae:1
package jrt












func LinkedHashSet_New_I_F(p0 int32, p1 float32) *LinkedHashSet { LinkedHashSet_Init(); t := &LinkedHashSet{}; t.Ctor_I_F(p0, p1); return t }
//line :14:1
func (t *LinkedHashSet) Ctor_I_F(initialCapacity int32, loadFactor float32) { t.HashSet.Ctor_I_F_Z(t, initialCapacity, loadFactor, true) }


func LinkedHashSet_New_I(p0 int32) *LinkedHashSet { LinkedHashSet_Init(); t := &LinkedHashSet{}; t.Ctor_I(p0); return t }
//line :17:1
func (t *LinkedHashSet) Ctor_I(initialCapacity int32) { t.HashSet.Ctor_I_F_Z(t, initialCapacity, 0.75, true) }


func LinkedHashSet_New() *LinkedHashSet { LinkedHashSet_Init(); t := &LinkedHashSet{}; t.Ctor(); return t }
//line :20:1
func (t *LinkedHashSet) Ctor() { t.HashSet.Ctor_I_F_Z(t, 16, 0.75, true) }

func LinkedHashSet_New_Collection(p0 Collection) *LinkedHashSet { LinkedHashSet_Init(); t := &LinkedHashSet{}; t.Ctor_Collection(p0); return t }
//line :22:1
func (t *LinkedHashSet) Ctor_Collection(c Collection) { t.HashSet.Ctor_I_F_Z(t, HashMap_CalculateHashMapCapacity_I__I(Math_Max_I_I__I(c.Size__I(), 12)), 0.75, true)

	t.AddAll_Collection__Z(c)
}
func (t *LinkedHashSet) Spliterator__Spliterator() Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(t, 17)
}
func LinkedHashSet_NewLinkedHashSet_I__LinkedHashSet(numElements int32) *LinkedHashSet {
	if numElements < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2694, StrOfInt(numElements))))) }
	return LinkedHashSet_New_I(HashMap_CalculateHashMapCapacity_I__I(numElements))
}
func (t *LinkedHashSet) Map__LinkedHashMap() *LinkedHashMap {
	return LinkedHashMap_Cast(t.F_map)
}
func (t *LinkedHashSet) AddFirst_O__V(e any) {
	NN(t.Map__LinkedHashMap()).PutFirst_O_O__O(e, HashSet_PRESENT)
}
func (t *LinkedHashSet) AddLast_O__V(e any) {
	NN(t.Map__LinkedHashMap()).PutLast_O_O__O(e, HashSet_PRESENT)
}
func (t *LinkedHashSet) GetFirst__O() any {
	return NN(t.Map__LinkedHashMap()).SequencedKeySet__SequencedSet().GetFirst__O()
}
func (t *LinkedHashSet) GetLast__O() any {
	return NN(t.Map__LinkedHashMap()).SequencedKeySet__SequencedSet().GetLast__O()
}
func (t *LinkedHashSet) RemoveFirst__O() any {
	return NN(t.Map__LinkedHashMap()).SequencedKeySet__SequencedSet().RemoveFirst__O()
}
func (t *LinkedHashSet) RemoveLast__O() any {
	return NN(t.Map__LinkedHashMap()).SequencedKeySet__SequencedSet().RemoveLast__O()
}
func (t *LinkedHashSet) Reversed__SequencedSet() SequencedSet {





































	return LinkedHashSet_1ReverseLinkedHashSetView_New_LinkedHashSet(t) }
//line :60:1
func (t *LinkedHashSet_1ReverseLinkedHashSetView) Size__I() int32 { return NN(t.F_this_0).Size__I() }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Iterator__Iterator() Iterator {
	return NN(NN(t.F_this_0).Map__LinkedHashMap()).SequencedKeySet__SequencedSet().Reversed__SequencedSet().Iterator__Iterator()
}
func (t *LinkedHashSet_1ReverseLinkedHashSetView) Add_O__Z(e any) bool { return NN(t.F_this_0).Add_O__Z(e) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) AddFirst_O__V(e any) {
	NN(t.F_this_0).AddLast_O__V(e)
}
func (t *LinkedHashSet_1ReverseLinkedHashSetView) AddLast_O__V(e any) {
	NN(t.F_this_0).AddFirst_O__V(e)
}
func (t *LinkedHashSet_1ReverseLinkedHashSetView) GetFirst__O() any { return NN(t.F_this_0).GetLast__O() }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) GetLast__O() any { return NN(t.F_this_0).GetFirst__O() }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) RemoveFirst__O() any { return NN(t.F_this_0).RemoveLast__O() }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) RemoveLast__O() any { return NN(t.F_this_0).RemoveFirst__O() }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Reversed__SequencedSet() SequencedSet { return Up_LinkedHashSet_SequencedSet(t.F_this_0) }


func (t *LinkedHashSet_1ReverseLinkedHashSetView) ToArray__O1() *RefArray {
	return NN(NN(t.F_this_0).Map__LinkedHashMap()).KeysToArray_O1_Z__O1(NewRefArray(Object_class, t.F_this_0.F_map.Size__I()), true)
}


func (t *LinkedHashSet_1ReverseLinkedHashSetView) ToArray_O1__O1(a *RefArray) *RefArray {
	return NN(NN(t.F_this_0).Map__LinkedHashMap()).KeysToArray_O1_Z__O1(t.F_this_0.F_map.PrepareArray_O1__O1(a), true)
}





























type LinkedHashSet struct{ HashSet }

func (t *LinkedHashSet) Is_SequencedSet() {}

func (t *LinkedHashSet) Is_SequencedCollection() {}

const LinkedHashSet_serialVersionUID int64 = -2851667679971038690

var LinkedHashSet_init ClassInit

func LinkedHashSet_Init() { if !LinkedHashSet_init.Done() { LinkedHashSet_init.Run(LinkedHashSet_clinit) } }

func LinkedHashSet_clinit() { HashSet_Init() }

func (t *LinkedHashSet) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *LinkedHashSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *LinkedHashSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *LinkedHashSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *LinkedHashSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *LinkedHashSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *LinkedHashSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *LinkedHashSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *LinkedHashSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *LinkedHashSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *LinkedHashSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *LinkedHashSet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *LinkedHashSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *LinkedHashSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *LinkedHashSet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *LinkedHashSet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *LinkedHashSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *LinkedHashSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *LinkedHashSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *LinkedHashSet) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *LinkedHashSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *LinkedHashSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *LinkedHashSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashSet) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashSet) GetClass__Class() *Class { return LinkedHashSet_class }

func (t *LinkedHashSet) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func LinkedHashSet_InstanceOf(x any) bool { _, ok := x.(*LinkedHashSet); return ok }

func LinkedHashSet_Cast(x any) *LinkedHashSet { if x == nil { return nil }; v, ok := x.(*LinkedHashSet); if !ok { panic(ClassCast(x, LinkedHashSet_class)) }; return v }



type LinkedHashSet_1ReverseLinkedHashSetView struct{ AbstractSet; F_this_0 *LinkedHashSet }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Is_SequencedSet() {}

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Is_SequencedCollection() {}

func LinkedHashSet_1ReverseLinkedHashSetView_New_LinkedHashSet(p0 *LinkedHashSet) *LinkedHashSet_1ReverseLinkedHashSetView { t := &LinkedHashSet_1ReverseLinkedHashSetView{}; t.Ctor_LinkedHashSet(p0); return t }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Ctor_LinkedHashSet(this_0 *LinkedHashSet) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Clear__V() { t.Impl_Clear__V(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) GetClass__Class() *Class { return LinkedHashSet_1ReverseLinkedHashSetView_class }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedHashSet_1ReverseLinkedHashSetView) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedHashSet_1ReverseLinkedHashSetView_InstanceOf(x any) bool { _, ok := x.(*LinkedHashSet_1ReverseLinkedHashSetView); return ok }

func LinkedHashSet_1ReverseLinkedHashSetView_Cast(x any) *LinkedHashSet_1ReverseLinkedHashSetView { if x == nil { return nil }; v, ok := x.(*LinkedHashSet_1ReverseLinkedHashSetView); if !ok { panic(ClassCast(x, LinkedHashSet_1ReverseLinkedHashSetView_class)) }; return v }
