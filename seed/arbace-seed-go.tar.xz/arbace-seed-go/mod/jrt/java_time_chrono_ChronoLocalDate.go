//line java_time_chrono_ChronoLocalDate.ae:1
package jrt






















func ChronoLocalDate_TimeLineOrder__Comparator() Comparator {
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var date1 ChronoLocalDate = ChronoLocalDate_Cast(p0); var date2 ChronoLocalDate = ChronoLocalDate_Cast(p1); return Long_Compare_J_J__I(date1.ToEpochDay__J(), date2.ToEpochDay__J()) }}))
}




func ChronoLocalDate_From_TemporalAccessor__ChronoLocalDate(temporal TemporalAccessor) ChronoLocalDate {
	if ChronoLocalDate_InstanceOf(temporal) {
		return ChronoLocalDate_Cast(temporal) } else {

			Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
			var chrono Chronology = Chronology_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery()))
			if chrono == nil {
				panic(Thrown(DateTimeException_New_String(Concat(Lit_2187, StrOfObj(temporal.GetClass__Class().Ref())))))
			}

			return chrono.Date_TemporalAccessor__ChronoLocalDate(temporal)
		}
}

func ChronoLocalDate_GetEra__Era(this ChronoLocalDate) Era {
	var tmp1 Chronology = this.GetChronology__Chronology(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; return tmp1.EraOf_I__Era(this.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2)))
}
func ChronoLocalDate_IsLeapYear__Z(this ChronoLocalDate) bool {
	var tmp1 Chronology = this.GetChronology__Chronology(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_YEAR; return tmp1.IsLeapYear_J__Z(this.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2)))
}


func ChronoLocalDate_LengthOfYear__I(this ChronoLocalDate) int32 {
	if this.IsLeapYear__Z() { return 366 } else { return 365
	} }
func ChronoLocalDate_IsSupported_TemporalField__Z(this ChronoLocalDate, field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		return field.IsDateBased__Z() } else {
			var tmp1 bool; tmp1 = !(field == nil); if tmp1 { tmp1 = field.IsSupportedBy_TemporalAccessor__Z(this) }; return tmp1
		} }
func ChronoLocalDate_IsSupported_TemporalUnit__Z(this ChronoLocalDate, unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		return unit.IsDateBased__Z() } else {
			var tmp1 bool; tmp1 = !(unit == nil); if tmp1 { tmp1 = unit.IsSupportedBy_Temporal__Z(this) }; return tmp1
		} }
func ChronoLocalDate_With_TemporalAdjuster__ChronoLocalDate(this ChronoLocalDate, adjuster TemporalAdjuster) ChronoLocalDate {
	return ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(this.GetChronology__Chronology(), Temporal_With_TemporalAdjuster__Temporal(this, adjuster))
}
func ChronoLocalDate_With_TemporalField_J__ChronoLocalDate(this ChronoLocalDate, field TemporalField, newValue int64) ChronoLocalDate {
	if ChronoField_InstanceOf(field) {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
	return ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(this.GetChronology__Chronology(), field.AdjustInto_Temporal_J__Temporal(this, newValue))
}
func ChronoLocalDate_Plus_TemporalAmount__ChronoLocalDate(this ChronoLocalDate, amount TemporalAmount) ChronoLocalDate {
	return ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(this.GetChronology__Chronology(), Temporal_Plus_TemporalAmount__Temporal(this, amount))
}
func ChronoLocalDate_Plus_J_TemporalUnit__ChronoLocalDate(this ChronoLocalDate, amountToAdd int64, unit TemporalUnit) ChronoLocalDate {
	if ChronoUnit_InstanceOf(unit) {
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit))))) }
	return ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(this.GetChronology__Chronology(), unit.AddTo_Temporal_J__Temporal(this, amountToAdd))
}
func ChronoLocalDate_Minus_TemporalAmount__ChronoLocalDate(this ChronoLocalDate, amount TemporalAmount) ChronoLocalDate {
	return ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(this.GetChronology__Chronology(), Temporal_Minus_TemporalAmount__Temporal(this, amount))
}
func ChronoLocalDate_Minus_J_TemporalUnit__ChronoLocalDate(this ChronoLocalDate, amountToSubtract int64, unit TemporalUnit) ChronoLocalDate {
	return ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(this.GetChronology__Chronology(), Temporal_Minus_J_TemporalUnit__Temporal(this, amountToSubtract, unit))
}

func ChronoLocalDate_Query_TemporalQuery__O(this ChronoLocalDate, query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = query == TemporalQueries_ZoneId__TemporalQuery(); if !tmp3 {
		tmp3 = query == TemporalQueries_Zone__TemporalQuery() }
//line :90:1
	tmp2 = tmp3; if !tmp2 {

		tmp2 = query == TemporalQueries_Offset__TemporalQuery() }
//line :90:1
	tmp1 = tmp2; if tmp1 { return nil } else {


		if query == TemporalQueries_LocalTime__TemporalQuery() { return nil } else {
			if query == TemporalQueries_Chronology__TemporalQuery() {
				return this.GetChronology__Chronology() } else {
//line :94:1
					if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_DAYS.Ref() } else {


						return query.QueryFrom_TemporalAccessor__O(this)
					} } } } }
func ChronoLocalDate_AdjustInto_Temporal__Temporal(this ChronoLocalDate, temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); return temporal.With_TemporalField_J__Temporal(tmp2, this.ToEpochDay__J())
}




func ChronoLocalDate_Format_DateTimeFormatter__String(this ChronoLocalDate, formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(this)
}
func ChronoLocalDate_AtTime_LocalTime__ChronoLocalDateTime(this ChronoLocalDate, localTime *LocalTime) ChronoLocalDateTime {
	return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(ChronoLocalDateTimeImpl_Of_ChronoLocalDate_LocalTime__ChronoLocalDateTimeImpl(this, localTime))
}
func ChronoLocalDate_ToEpochDay__J(this ChronoLocalDate) int64 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; return this.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp1))
}
func ChronoLocalDate_CompareTo_ChronoLocalDate__I(this, other ChronoLocalDate) int32 {
	var cmp int32 = Long_Compare_J_J__I(this.ToEpochDay__J(), other.ToEpochDay__J())
	if cmp == 0 { cmp = this.GetChronology__Chronology().CompareTo_Chronology__I(other.GetChronology__Chronology()) }
//line :117:1
	return cmp
}


func ChronoLocalDate_IsAfter_ChronoLocalDate__Z(this, other ChronoLocalDate) bool {
	return this.ToEpochDay__J() > other.ToEpochDay__J()
}
func ChronoLocalDate_IsBefore_ChronoLocalDate__Z(this, other ChronoLocalDate) bool {
	return this.ToEpochDay__J() < other.ToEpochDay__J()
}
func ChronoLocalDate_IsEqual_ChronoLocalDate__Z(this, other ChronoLocalDate) bool {
	return this.ToEpochDay__J() == other.ToEpochDay__J()
}


type ChronoLocalDate interface{ Object_I; Temporal; TemporalAdjuster; Comparable; TemporalAccessor; Is_ChronoLocalDate(); GetChronology__Chronology() Chronology; GetEra__Era() Era; IsLeapYear__Z() bool; LengthOfMonth__I() int32; LengthOfYear__I() int32; IsSupported_TemporalField__Z(p0 TemporalField) bool; IsSupported_TemporalUnit__Z(p0 TemporalUnit) bool; With_TemporalAdjuster__ChronoLocalDate(p0 TemporalAdjuster) ChronoLocalDate; With_TemporalField_J__ChronoLocalDate(p0 TemporalField, p1 int64) ChronoLocalDate; Plus_TemporalAmount__ChronoLocalDate(p0 TemporalAmount) ChronoLocalDate; Plus_J_TemporalUnit__ChronoLocalDate(p0 int64, p1 TemporalUnit) ChronoLocalDate; Minus_TemporalAmount__ChronoLocalDate(p0 TemporalAmount) ChronoLocalDate; Minus_J_TemporalUnit__ChronoLocalDate(p0 int64, p1 TemporalUnit) ChronoLocalDate; Query_TemporalQuery__O(p0 TemporalQuery) any; AdjustInto_Temporal__Temporal(p0 Temporal) Temporal; Until_Temporal_TemporalUnit__J(p0 Temporal, p1 TemporalUnit) int64; Until_ChronoLocalDate__ChronoPeriod(p0 ChronoLocalDate) ChronoPeriod; Format_DateTimeFormatter__String(p0 *DateTimeFormatter) *String; AtTime_LocalTime__ChronoLocalDateTime(p0 *LocalTime) ChronoLocalDateTime; ToEpochDay__J() int64; CompareTo_ChronoLocalDate__I(p0 ChronoLocalDate) int32; IsAfter_ChronoLocalDate__Z(p0 ChronoLocalDate) bool; IsBefore_ChronoLocalDate__Z(p0 ChronoLocalDate) bool; IsEqual_ChronoLocalDate__Z(p0 ChronoLocalDate) bool; With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal; With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal; Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; CompareTo_O__I(p0 any) int32 }

func ChronoLocalDate_With_TemporalAdjuster__Temporal(this ChronoLocalDate, p0 TemporalAdjuster) Temporal { return this.With_TemporalAdjuster__ChronoLocalDate(p0) }

func ChronoLocalDate_With_TemporalField_J__Temporal(this ChronoLocalDate, p0 TemporalField, p1 int64) Temporal { return this.With_TemporalField_J__ChronoLocalDate(p0, p1) }

func ChronoLocalDate_Plus_TemporalAmount__Temporal(this ChronoLocalDate, p0 TemporalAmount) Temporal { return this.Plus_TemporalAmount__ChronoLocalDate(p0) }

func ChronoLocalDate_Plus_J_TemporalUnit__Temporal(this ChronoLocalDate, p0 int64, p1 TemporalUnit) Temporal { return this.Plus_J_TemporalUnit__ChronoLocalDate(p0, p1) }

func ChronoLocalDate_Minus_TemporalAmount__Temporal(this ChronoLocalDate, p0 TemporalAmount) Temporal { return this.Minus_TemporalAmount__ChronoLocalDate(p0) }

func ChronoLocalDate_Minus_J_TemporalUnit__Temporal(this ChronoLocalDate, p0 int64, p1 TemporalUnit) Temporal { return this.Minus_J_TemporalUnit__ChronoLocalDate(p0, p1) }

func ChronoLocalDate_CompareTo_O__I(this ChronoLocalDate, p0 any) int32 { return this.CompareTo_ChronoLocalDate__I(ChronoLocalDate_Cast(p0)) }

func ChronoLocalDate_InstanceOf(x any) bool { _, ok := x.(ChronoLocalDate); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoLocalDate_class) } }; return ok }

func ChronoLocalDate_Cast(x any) ChronoLocalDate { if x == nil { return nil }; v, ok := x.(ChronoLocalDate); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoLocalDate_class) } }; if !ok { panic(ClassCast(x, ChronoLocalDate_class)) }; return v }
