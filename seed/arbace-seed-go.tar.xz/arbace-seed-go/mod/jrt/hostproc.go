//line hostproc.ae:1
package jrt









const (
	// StdioPipe: a pipe between the program and the child (ProcessBuilder.Redirect.PIPE).
	StdioPipe int = 0
	// StdioInherit: the program's own stream (Redirect.INHERIT).
	StdioInherit int = 1
	// StdioFile: an open file of the host (a redirection to or from a file).
	StdioFile int = 2)
// HostStdio is what a child's standard stream is: Kind StdioPipe, StdioInherit, or StdioFile with
// File, an open file of the host (Host.Open's, or a pipe end Start gave).
//line :19:1
type HostStdio /*line :22:1*/ struct{ Kind int; File HostFile }
// HostProc is the processes of a host (java.lang.Process, ProcessHandle). A Host implements it to
// let the program start programs and see processes.
//line :24:1
type HostProc /*line :27:1*/ interface {
	// Start starts the program at path (a path, not searched) with the arguments argv
	// (argv[0] first), the environment env ("NAME=value"; nil: the program's own), in the directory
	// dir ("": the program's), and its standard input, output and error as stdio says; error output
	// goes where standard output goes when errToOut (a pipe of stdio[2] is still made, as the JDK
	// makes it: its child's end closed). It returns the child and, for each StdioPipe of
	// stdio, the program's end of the pipe (writing for the input, reading for the outputs; nil
	// otherwise). An error is a *HostProcError.
	Start(path string, argv, env []string, dir string, stdio /*line :36:1*/[]HostStdio, errToOut bool) (HostChild,
		[]HostFile, error)
	// Pid is the program's own process ID.
	Pid() int
	// ProcStat is what the host tells of process pid: its parent, its CPU time and its start
	// (ProcessHandleImpl_linux.c's os_getParentPidAndTimings); false when there is no such process.
	ProcStat(pid int) (HostProcStat, bool)
	// ProcInfo is the command, arguments and user of process pid, as far as the host tells
	// (os_getCmdlineAndUserInfo).
	ProcInfo(pid int) HostProcInfo
	// Pids is the IDs of the host's processes.
	Pids() []int
	// Kill sends process pid SIGTERM, or SIGKILL when force.
	Kill(pid int, force bool) error }
// HostChild is a process Start started. Its end is waited for by the host, so that it leaves no
// zombie: Wait blocks until it has ended.
//line :51:1
type HostChild /*line :54:1*/ interface {
	// Pid is the child's process ID.
	Pid() int
	// Wait waits for the child's end: its exit status, or 0x80 plus the signal that ended
	// it (the JDK's encoding, WTERMSIG_RETURN).
	Wait() int
	// Signal sends the child SIGTERM, or SIGKILL when force, unless it has ended (an error
	// then).
	Signal(force bool) error }
// HostProcStat is a process's parent ID, CPU time (user and system, in nanoseconds) and start
// (milliseconds since the epoch; 0 when unknown).
//line :64:1
type HostProcStat /*line :67:1*/ struct{ Ppid int; TotalNanos, StartMillis int64 }
// HostProcInfo is a process's command (the executable's path), arguments (after the command;
// HasArgs false when unknown), command line (when the command or the arguments are not known
// exactly) and user name; empty strings when unknown.
//line :69:1
type HostProcInfo /*line :73:1*/ struct{ Command string; Args []string; HasArgs bool; CommandLine, User string }
// HostProcError is why Start failed: Errno (Linux's number), at the change of directory (Chdir) or
// at exec.
//line :75:1
type HostProcError /*line :77:1*/ struct{ Chdir bool; Errno int }

func (e *HostProcError) Error() string {
	return ErrnoText(e.Errno) }
// CurrentHostProc is the current host as a HostProc, or nil when it is not one.
func CurrentHostProc() HostProc {


	hp, ok := CurrentHost().(HostProc)
	if !ok {
		return nil
	}
	return hp
}
