//line java_time_OffsetDateTime.ae:1
package jrt


































func OffsetDateTime_TimeLineOrder__Comparator() Comparator { OffsetDateTime_Init()
	return &Comparator_Fn{Fn: func(p0, p1 any) int32 { return OffsetDateTime_CompareInstant_OffsetDateTime_OffsetDateTime__I(OffsetDateTime_Cast(p0), OffsetDateTime_Cast(p1)) }}
}
func OffsetDateTime_CompareInstant_OffsetDateTime_OffsetDateTime__I(datetime1, datetime2 *OffsetDateTime) int32 { OffsetDateTime_Init()

	if NN(NN(datetime1).GetOffset__ZoneOffset()).Equals_O__Z(NN(datetime2).GetOffset__ZoneOffset().Ref()) {
		return NN(NN(datetime1).ToLocalDateTime__LocalDateTime()).CompareTo_ChronoLocalDateTime__I(Up_LocalDateTime_ChronoLocalDateTime(NN(datetime2).ToLocalDateTime__LocalDateTime())) } else {
			var cmp int32 = Long_Compare_J_J__I(NN(datetime1).ToEpochSecond__J(), NN(datetime2).ToEpochSecond__J())
			if cmp == 0 {
				cmp = NN(NN(datetime1).ToLocalTime__LocalTime()).GetNano__I() - NN(NN(datetime2).ToLocalTime__LocalTime()).GetNano__I() }
//line :43:1
			return cmp
		}
}










func OffsetDateTime_Now__OffsetDateTime() *OffsetDateTime { OffsetDateTime_Init()
	return OffsetDateTime_Now_Clock__OffsetDateTime(Clock_SystemDefaultZone__Clock())
}
func OffsetDateTime_Now_ZoneId__OffsetDateTime(zone ZoneId_I) *OffsetDateTime { OffsetDateTime_Init()
	return OffsetDateTime_Now_Clock__OffsetDateTime(Clock_System_ZoneId__Clock(zone))
}
func OffsetDateTime_Now_Clock__OffsetDateTime(clock Clock_I) *OffsetDateTime { OffsetDateTime_Init()
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	var now *Instant = clock.Instant__Instant()
	return OffsetDateTime_OfInstant_Instant_ZoneId__OffsetDateTime(now, Up_ZoneOffset_ZoneId(NN(clock.GetZone__ZoneId().GetRules__ZoneRules()).GetOffset_Instant__ZoneOffset(now)))
}
func OffsetDateTime_Of_LocalDate_LocalTime_ZoneOffset__OffsetDateTime(date *LocalDate, time *LocalTime, offset *ZoneOffset) *OffsetDateTime { OffsetDateTime_Init()
	var dt *LocalDateTime = LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(date, time); return OffsetDateTime_New_LocalDateTime_ZoneOffset(dt, offset)
}
func OffsetDateTime_Of_LocalDateTime_ZoneOffset__OffsetDateTime(dateTime *LocalDateTime, offset *ZoneOffset) *OffsetDateTime { OffsetDateTime_Init()
	return OffsetDateTime_New_LocalDateTime_ZoneOffset(dateTime, offset)
}
func OffsetDateTime_Of_I_I_I_I_I_I_I_ZoneOffset__OffsetDateTime(year, month, dayOfMonth, hour, minute, second, nanoOfSecond int32, offset *ZoneOffset) *OffsetDateTime { OffsetDateTime_Init()


	var dt *LocalDateTime = LocalDateTime_Of_I_I_I_I_I_I_I__LocalDateTime(year, month, dayOfMonth, hour, minute, second, nanoOfSecond)
	return OffsetDateTime_New_LocalDateTime_ZoneOffset(dt, offset)
}
func OffsetDateTime_OfInstant_Instant_ZoneId__OffsetDateTime(instant *Instant, zone ZoneId_I) *OffsetDateTime { OffsetDateTime_Init()
	Objects_RequireNonNull_O_String__O(instant.Ref(), Lit_2039)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var rules *ZoneRules = zone.GetRules__ZoneRules(); var offset *ZoneOffset = NN(rules).GetOffset_Instant__ZoneOffset(instant); var ldt *LocalDateTime = LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(NN(instant).GetEpochSecond__J(), NN(instant).GetNano__I(), offset)


	return OffsetDateTime_New_LocalDateTime_ZoneOffset(ldt, offset)
}
func OffsetDateTime_From_TemporalAccessor__OffsetDateTime(temporal TemporalAccessor) *OffsetDateTime { OffsetDateTime_Init()
	if OffsetDateTime_InstanceOf(temporal) {
		return OffsetDateTime_Cast(temporal) } else {
			var tmp1 *OffsetDateTime; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var offset *ZoneOffset = ZoneOffset_From_TemporalAccessor__ZoneOffset(temporal); var date *LocalDate = LocalDate_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_LocalDate__TemporalQuery())); var time *LocalTime = LocalTime_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_LocalTime__TemporalQuery())); var tmp2 bool; var tmp3 bool


					tmp3 = !(date == nil); if tmp3 { tmp3 = !(time == nil) }; tmp2 = tmp3; if tmp2 {
						tmp1 = OffsetDateTime_Of_LocalDate_LocalTime_ZoneOffset__OffsetDateTime(date, time, offset) } else {
							var instant *Instant = Instant_From_TemporalAccessor__Instant(temporal); tmp1 = OffsetDateTime_OfInstant_Instant_ZoneId__OffsetDateTime(instant, Up_ZoneOffset_ZoneId(offset)) } }; return nil }()
//line :90:1
			if tmp4 != nil { if DateTimeException_InstanceOf(tmp4) { var ex DateTimeException_I = DateTimeException_Cast(tmp4)







				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2077, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :90:1
					panic(tmp4) } }; return tmp1
		}
}












func OffsetDateTime_Parse_CharSequence__OffsetDateTime(text CharSequence) *OffsetDateTime { OffsetDateTime_Init()
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_OFFSET_DATE_TIME; return OffsetDateTime_Parse_CharSequence_DateTimeFormatter__OffsetDateTime(text, tmp1)
}
func OffsetDateTime_Parse_CharSequence_DateTimeFormatter__OffsetDateTime(text CharSequence, formatter *DateTimeFormatter) *OffsetDateTime { OffsetDateTime_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return OffsetDateTime_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return OffsetDateTime_From_TemporalAccessor__OffsetDateTime(p0).Ref() }}))
}




func OffsetDateTime_New_LocalDateTime_ZoneOffset(p0 *LocalDateTime, p1 *ZoneOffset) *OffsetDateTime { OffsetDateTime_Init(); t := &OffsetDateTime{}; t.Ctor_LocalDateTime_ZoneOffset(p0, p1); return t }
//line :116:1
func (t *OffsetDateTime) Ctor_LocalDateTime_ZoneOffset(dateTime *LocalDateTime, offset *ZoneOffset) {
	t.F_dateTime = LocalDateTime_Cast(Objects_RequireNonNull_O_String__O(dateTime.Ref(), Lit_2076))
	t.F_offset = ZoneOffset_Cast(Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052))
}
func (t *OffsetDateTime) With_LocalDateTime_ZoneOffset__OffsetDateTime(dateTime *LocalDateTime, offset *ZoneOffset) *OffsetDateTime {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_dateTime == dateTime; if tmp2 { tmp2 = NN(t.F_offset).Equals_O__Z(offset.Ref()) }; tmp1 = tmp2; if tmp1 { return t } else {

		return OffsetDateTime_New_LocalDateTime_ZoneOffset(dateTime, offset)
	} }
func (t *OffsetDateTime) IsSupported_TemporalField__Z(field TemporalField) bool {
	var tmp1 bool; tmp1 = ChronoField_InstanceOf(field); if !tmp1 { var tmp2 bool; tmp2 = !(field == nil); if tmp2 { tmp2 = field.IsSupportedBy_TemporalAccessor__Z(t) }; tmp1 = tmp2 }; return tmp1
}
func (t *OffsetDateTime) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_FOREVER; return !(any(unit) == any(tmp1.Ref())) } else {
			var tmp2 bool; tmp2 = !(unit == nil); if tmp2 { tmp2 = unit.IsSupportedBy_Temporal__Z(t) }; return tmp2
		} }
func (t *OffsetDateTime) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; var tmp2 bool; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_INSTANT_SECONDS; tmp2 = any(field) == any(tmp3.Ref()); if !tmp2 {
			var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_OFFSET_SECONDS; tmp2 = any(field) == any(tmp4.Ref()) }
//line :135:1
		tmp1 = tmp2; if tmp1 {

			return field.Range__ValueRange() } else {
				return NN(t.F_dateTime).Range_TemporalField__ValueRange(field) } } else {
					return field.RangeRefinedBy_TemporalAccessor__ValueRange(t)
				} }
func (t *OffsetDateTime) Get_TemporalField__I(field TemporalField) int32 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:

			panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2078))); case 29:

			return NN(t.GetOffset__ZoneOffset()).GetTotalSeconds__I(); default:
			return NN(t.F_dateTime).Get_TemporalField__I(field)} } else {
				return TemporalAccessor_Get_TemporalField__I(t, field) } }; panic("a2g: unreachable")
}
func (t *OffsetDateTime) GetLong_TemporalField__J(field TemporalField) int64 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:
			return t.ToEpochSecond__J(); case 29:
			return int64(NN(t.GetOffset__ZoneOffset()).GetTotalSeconds__I()); default:
			return NN(t.F_dateTime).GetLong_TemporalField__J(field)} } else {
				return field.GetFrom_TemporalAccessor__J(t) } }; panic("a2g: unreachable")
}
func (t *OffsetDateTime) GetOffset__ZoneOffset() *ZoneOffset { return t.F_offset }

func (t *OffsetDateTime) WithOffsetSameLocal_ZoneOffset__OffsetDateTime(offset *ZoneOffset) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(t.F_dateTime, offset)
}
func (t *OffsetDateTime) WithOffsetSameInstant_ZoneOffset__OffsetDateTime(offset *ZoneOffset) *OffsetDateTime {
	if NN(offset).Equals_O__Z(t.F_offset.Ref()) { return t } else {

		var difference int32 = NN(offset).GetTotalSeconds__I() - NN(t.F_offset).GetTotalSeconds__I(); var adjusted *LocalDateTime = NN(t.F_dateTime).PlusSeconds_J__LocalDateTime(int64(difference))



		return OffsetDateTime_New_LocalDateTime_ZoneOffset(adjusted, offset)
	} }
func (t *OffsetDateTime) ToLocalDateTime__LocalDateTime() *LocalDateTime { return t.F_dateTime }

func (t *OffsetDateTime) ToLocalDate__LocalDate() *LocalDate { return NN(t.F_dateTime).ToLocalDate__LocalDate() }

func (t *OffsetDateTime) GetYear__I() int32 { return NN(t.F_dateTime).GetYear__I() }

func (t *OffsetDateTime) GetMonthValue__I() int32 { return NN(t.F_dateTime).GetMonthValue__I() }

func (t *OffsetDateTime) GetMonth__Month() *Month { return NN(t.F_dateTime).GetMonth__Month() }

func (t *OffsetDateTime) GetDayOfMonth__I() int32 { return NN(t.F_dateTime).GetDayOfMonth__I() }

func (t *OffsetDateTime) GetDayOfYear__I() int32 { return NN(t.F_dateTime).GetDayOfYear__I() }

func (t *OffsetDateTime) GetDayOfWeek__DayOfWeek() *DayOfWeek {
	return NN(t.F_dateTime).GetDayOfWeek__DayOfWeek()
}
func (t *OffsetDateTime) ToLocalTime__LocalTime() *LocalTime { return NN(t.F_dateTime).ToLocalTime__LocalTime() }

func (t *OffsetDateTime) GetHour__I() int32 { return NN(t.F_dateTime).GetHour__I() }

func (t *OffsetDateTime) GetMinute__I() int32 { return NN(t.F_dateTime).GetMinute__I() }

func (t *OffsetDateTime) GetSecond__I() int32 { return NN(t.F_dateTime).GetSecond__I() }

func (t *OffsetDateTime) GetNano__I() int32 { return NN(t.F_dateTime).GetNano__I() }

func (t *OffsetDateTime) With_TemporalAdjuster__OffsetDateTime(adjuster TemporalAdjuster) *OffsetDateTime {
	var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = LocalDate_InstanceOf(adjuster); if !tmp3 { tmp3 = LocalTime_InstanceOf(adjuster) }; tmp2 = tmp3; if !tmp2 {
		tmp2 = LocalDateTime_InstanceOf(adjuster) }
//line :202:1
	tmp1 = tmp2
//line :201:1
	if tmp1 {


		return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).With_TemporalAdjuster__LocalDateTime(adjuster), t.F_offset) } else {
//line :201:1
			if Instant_InstanceOf(adjuster) {



				return OffsetDateTime_OfInstant_Instant_ZoneId__OffsetDateTime(Instant_Cast(adjuster), Up_ZoneOffset_ZoneId(t.F_offset)) } else {
//line :201:1
					if ZoneOffset_InstanceOf(adjuster) {




						var tmp4 *LocalDateTime = t.F_dateTime; return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(tmp4, ZoneOffset_Cast(adjuster)) } else {
//line :201:1
							if OffsetDateTime_InstanceOf(adjuster) {





								return OffsetDateTime_Cast(adjuster) } else {
									return OffsetDateTime_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
								} } } } }
func (t *OffsetDateTime) With_TemporalField_J__OffsetDateTime(field TemporalField, newValue int64) *OffsetDateTime {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:

			return OffsetDateTime_OfInstant_Instant_ZoneId__OffsetDateTime(Instant_OfEpochSecond_J_J__Instant(newValue, int64(t.GetNano__I())), Up_ZoneOffset_ZoneId(t.F_offset)); case 29:

			var tmp2 *LocalDateTime = t.F_dateTime; return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(tmp2, ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(chronoField).CheckValidIntValue_J__I(newValue))); default:


			return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).With_TemporalField_J__LocalDateTime(field, newValue), t.F_offset)} } else {
				return OffsetDateTime_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue)) } }; panic("a2g: unreachable")
}
func (t *OffsetDateTime) WithYear_I__OffsetDateTime(year int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithYear_I__LocalDateTime(year), t.F_offset)
}
func (t *OffsetDateTime) WithMonth_I__OffsetDateTime(month int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithMonth_I__LocalDateTime(month), t.F_offset)
}
func (t *OffsetDateTime) WithDayOfMonth_I__OffsetDateTime(dayOfMonth int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithDayOfMonth_I__LocalDateTime(dayOfMonth), t.F_offset)
}
func (t *OffsetDateTime) WithDayOfYear_I__OffsetDateTime(dayOfYear int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithDayOfYear_I__LocalDateTime(dayOfYear), t.F_offset)
}
func (t *OffsetDateTime) WithHour_I__OffsetDateTime(hour int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithHour_I__LocalDateTime(hour), t.F_offset)
}
func (t *OffsetDateTime) WithMinute_I__OffsetDateTime(minute int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithMinute_I__LocalDateTime(minute), t.F_offset)
}
func (t *OffsetDateTime) WithSecond_I__OffsetDateTime(second int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithSecond_I__LocalDateTime(second), t.F_offset)
}
func (t *OffsetDateTime) WithNano_I__OffsetDateTime(nanoOfSecond int32) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).WithNano_I__LocalDateTime(nanoOfSecond), t.F_offset)
}
func (t *OffsetDateTime) TruncatedTo_TemporalUnit__OffsetDateTime(unit TemporalUnit) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).TruncatedTo_TemporalUnit__LocalDateTime(unit), t.F_offset)
}
func (t *OffsetDateTime) Plus_TemporalAmount__OffsetDateTime(amountToAdd TemporalAmount) *OffsetDateTime {
	return OffsetDateTime_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
}
func (t *OffsetDateTime) Plus_J_TemporalUnit__OffsetDateTime(amountToAdd int64, unit TemporalUnit) *OffsetDateTime {
	if ChronoUnit_InstanceOf(unit) {
		return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).Plus_J_TemporalUnit__LocalDateTime(amountToAdd, unit), t.F_offset) } else {
			return OffsetDateTime_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd))
		} }
func (t *OffsetDateTime) PlusYears_J__OffsetDateTime(years int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusYears_J__LocalDateTime(years), t.F_offset)
}
func (t *OffsetDateTime) PlusMonths_J__OffsetDateTime(months int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusMonths_J__LocalDateTime(months), t.F_offset)
}
func (t *OffsetDateTime) PlusWeeks_J__OffsetDateTime(weeks int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusWeeks_J__LocalDateTime(weeks), t.F_offset)
}
func (t *OffsetDateTime) PlusDays_J__OffsetDateTime(days int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusDays_J__LocalDateTime(days), t.F_offset)
}
func (t *OffsetDateTime) PlusHours_J__OffsetDateTime(hours int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusHours_J__LocalDateTime(hours), t.F_offset)
}
func (t *OffsetDateTime) PlusMinutes_J__OffsetDateTime(minutes int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusMinutes_J__LocalDateTime(minutes), t.F_offset)
}
func (t *OffsetDateTime) PlusSeconds_J__OffsetDateTime(seconds int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusSeconds_J__LocalDateTime(seconds), t.F_offset)
}
func (t *OffsetDateTime) PlusNanos_J__OffsetDateTime(nanos int64) *OffsetDateTime {
	return t.With_LocalDateTime_ZoneOffset__OffsetDateTime(NN(t.F_dateTime).PlusNanos_J__LocalDateTime(nanos), t.F_offset)
}
func (t *OffsetDateTime) Minus_TemporalAmount__OffsetDateTime(amountToSubtract TemporalAmount) *OffsetDateTime {
	return OffsetDateTime_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
}
func (t *OffsetDateTime) Minus_J_TemporalUnit__OffsetDateTime(amountToSubtract int64, unit TemporalUnit) *OffsetDateTime {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__OffsetDateTime(9223372036854775807, unit)).Plus_J_TemporalUnit__OffsetDateTime(1, unit) } else {
			return t.Plus_J_TemporalUnit__OffsetDateTime(-amountToSubtract, unit)
		} }
func (t *OffsetDateTime) MinusYears_J__OffsetDateTime(years int64) *OffsetDateTime {
	if years == -9223372036854775808 {
		return NN(t.PlusYears_J__OffsetDateTime(9223372036854775807)).PlusYears_J__OffsetDateTime(1) } else {
			return t.PlusYears_J__OffsetDateTime(-years)
		} }
func (t *OffsetDateTime) MinusMonths_J__OffsetDateTime(months int64) *OffsetDateTime {
	if months == -9223372036854775808 {
		return NN(t.PlusMonths_J__OffsetDateTime(9223372036854775807)).PlusMonths_J__OffsetDateTime(1) } else {
			return t.PlusMonths_J__OffsetDateTime(-months)
		} }
func (t *OffsetDateTime) MinusWeeks_J__OffsetDateTime(weeks int64) *OffsetDateTime {
	if weeks == -9223372036854775808 {
		return NN(t.PlusWeeks_J__OffsetDateTime(9223372036854775807)).PlusWeeks_J__OffsetDateTime(1) } else {
			return t.PlusWeeks_J__OffsetDateTime(-weeks)
		} }
func (t *OffsetDateTime) MinusDays_J__OffsetDateTime(days int64) *OffsetDateTime {
	if days == -9223372036854775808 {
		return NN(t.PlusDays_J__OffsetDateTime(9223372036854775807)).PlusDays_J__OffsetDateTime(1) } else {
			return t.PlusDays_J__OffsetDateTime(-days)
		} }
func (t *OffsetDateTime) MinusHours_J__OffsetDateTime(hours int64) *OffsetDateTime {
	if hours == -9223372036854775808 {
		return NN(t.PlusHours_J__OffsetDateTime(9223372036854775807)).PlusHours_J__OffsetDateTime(1) } else {
			return t.PlusHours_J__OffsetDateTime(-hours)
		} }
func (t *OffsetDateTime) MinusMinutes_J__OffsetDateTime(minutes int64) *OffsetDateTime {
	if minutes == -9223372036854775808 {
		return NN(t.PlusMinutes_J__OffsetDateTime(9223372036854775807)).PlusMinutes_J__OffsetDateTime(1) } else {
			return t.PlusMinutes_J__OffsetDateTime(-minutes)
		} }
func (t *OffsetDateTime) MinusSeconds_J__OffsetDateTime(seconds int64) *OffsetDateTime {
	if seconds == -9223372036854775808 {
		return NN(t.PlusSeconds_J__OffsetDateTime(9223372036854775807)).PlusSeconds_J__OffsetDateTime(1) } else {
			return t.PlusSeconds_J__OffsetDateTime(-seconds)
		} }
func (t *OffsetDateTime) MinusNanos_J__OffsetDateTime(nanos int64) *OffsetDateTime {
	if nanos == -9223372036854775808 {
		return NN(t.PlusNanos_J__OffsetDateTime(9223372036854775807)).PlusNanos_J__OffsetDateTime(1) } else {
			return t.PlusNanos_J__OffsetDateTime(-nanos)
		} }
func (t *OffsetDateTime) Query_TemporalQuery__O(query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool; tmp2 = query == TemporalQueries_Offset__TemporalQuery(); if !tmp2 { tmp2 = query == TemporalQueries_Zone__TemporalQuery() }; tmp1 = tmp2; if tmp1 {
		return t.GetOffset__ZoneOffset().Ref() } else {
			if query == TemporalQueries_ZoneId__TemporalQuery() { return nil } else {
				if query == TemporalQueries_LocalDate__TemporalQuery() {
					return t.ToLocalDate__LocalDate().Ref() } else {
//line :333:1
						if query == TemporalQueries_LocalTime__TemporalQuery() {

							return t.ToLocalTime__LocalTime().Ref() } else {
//line :333:1
								if query == TemporalQueries_Chronology__TemporalQuery() { IsoChronology_Init(); return IsoChronology_INSTANCE.Ref() } else { if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_NANOS.Ref() } else {




									return query.QueryFrom_TemporalAccessor__O(t)
								} } } } } } }
func (t *OffsetDateTime) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 Temporal = temporal.With_TemporalField_J__Temporal(tmp2, NN(t.ToLocalDate__LocalDate()).ToEpochDay__J()); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_NANO_OF_DAY; var tmp5 TemporalField = Up_ChronoField_TemporalField(tmp4); var tmp6 Temporal = tmp3.With_TemporalField_J__Temporal(tmp5, NN(t.ToLocalTime__LocalTime()).ToNanoOfDay__J()); var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_OFFSET_SECONDS; var tmp8 TemporalField = Up_ChronoField_TemporalField(tmp7); return tmp6.With_TemporalField_J__Temporal(tmp8, int64(NN(t.GetOffset__ZoneOffset()).GetTotalSeconds__I()))
}




func (t *OffsetDateTime) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	var end *OffsetDateTime = OffsetDateTime_From_TemporalAccessor__OffsetDateTime(endExclusive)
	if ChronoUnit_InstanceOf(unit) {
		var start *OffsetDateTime = t; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

			end = NN(end).WithOffsetSameInstant_ZoneOffset__OffsetDateTime(t.F_offset); return nil }()
//line :351:1
		if tmp1 != nil { if DateTimeException_InstanceOf(tmp1) { var ex DateTimeException_I = DateTimeException_Cast(tmp1); _ = ex

			start = t.WithOffsetSameInstant_ZoneOffset__OffsetDateTime(end.F_offset) } else {
//line :351:1
				panic(tmp1)
			}
		}
		var tmp2 *LocalDateTime = start.F_dateTime; return NN(tmp2).Until_Temporal_TemporalUnit__J(Up_LocalDateTime_Temporal(end.F_dateTime), unit) } else {
			return unit.Between_Temporal_Temporal__J(t, Up_OffsetDateTime_Temporal(end))
		} }
func (t *OffsetDateTime) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *OffsetDateTime) AtZoneSameInstant_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_OfInstant_LocalDateTime_ZoneOffset_ZoneId__ZonedDateTime(t.F_dateTime, t.F_offset, zone)
}
func (t *OffsetDateTime) AtZoneSimilarLocal_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_OfLocal_LocalDateTime_ZoneId_ZoneOffset__ZonedDateTime(t.F_dateTime, zone, t.F_offset)
}
func (t *OffsetDateTime) ToOffsetTime__OffsetTime() *OffsetTime {
	return OffsetTime_Of_LocalTime_ZoneOffset__OffsetTime(NN(t.F_dateTime).ToLocalTime__LocalTime(), t.F_offset)
}
func (t *OffsetDateTime) ToZonedDateTime__ZonedDateTime() *ZonedDateTime {
	return ZonedDateTime_Of_LocalDateTime_ZoneId__ZonedDateTime(t.F_dateTime, Up_ZoneOffset_ZoneId(t.F_offset))
}
func (t *OffsetDateTime) ToInstant__Instant() *Instant { return NN(t.F_dateTime).ToInstant_ZoneOffset__Instant(t.F_offset) }

func (t *OffsetDateTime) ToEpochSecond__J() int64 {
	return NN(t.F_dateTime).ToEpochSecond_ZoneOffset__J(t.F_offset)
}
func (t *OffsetDateTime) CompareTo_OffsetDateTime__I(other *OffsetDateTime) int32 {
	var cmp int32 = NN(t.GetOffset__ZoneOffset()).CompareTo_ZoneOffset__I(NN(other).GetOffset__ZoneOffset())
	if cmp == 0 { } else {
		cmp = Long_Compare_J_J__I(t.ToEpochSecond__J(), NN(other).ToEpochSecond__J())
		if cmp == 0 {
			cmp = NN(t.ToLocalTime__LocalTime()).GetNano__I() - NN(NN(other).ToLocalTime__LocalTime()).GetNano__I()
		}
	}
	if cmp == 0 { cmp = NN(t.ToLocalDateTime__LocalDateTime()).CompareTo_ChronoLocalDateTime__I(Up_LocalDateTime_ChronoLocalDateTime(NN(other).ToLocalDateTime__LocalDateTime())) }
//line :379:1
	return cmp
}








func (t *OffsetDateTime) IsAfter_OffsetDateTime__Z(other *OffsetDateTime) bool {
	var thisEpochSec int64 = t.ToEpochSecond__J(); var otherEpochSec int64 = NN(other).ToEpochSecond__J(); var tmp1 bool

	tmp1 = thisEpochSec > otherEpochSec; if !tmp1 {
		var tmp2 bool; tmp2 = thisEpochSec == otherEpochSec; if tmp2 {
			tmp2 = NN(t.ToLocalTime__LocalTime()).GetNano__I() > NN(NN(other).ToLocalTime__LocalTime()).GetNano__I() }
//line :393:1
		tmp1 = tmp2 }
//line :392:1
	return tmp1
}


func (t *OffsetDateTime) IsBefore_OffsetDateTime__Z(other *OffsetDateTime) bool {
	var thisEpochSec int64 = t.ToEpochSecond__J(); var otherEpochSec int64 = NN(other).ToEpochSecond__J(); var tmp1 bool

	tmp1 = thisEpochSec < otherEpochSec; if !tmp1 {
		var tmp2 bool; tmp2 = thisEpochSec == otherEpochSec; if tmp2 {
			tmp2 = NN(t.ToLocalTime__LocalTime()).GetNano__I() < NN(NN(other).ToLocalTime__LocalTime()).GetNano__I() }
//line :400:1
		tmp1 = tmp2 }
//line :399:1
	return tmp1
}


func (t *OffsetDateTime) IsEqual_OffsetDateTime__Z(other *OffsetDateTime) bool {
	var tmp1 bool; tmp1 = t.ToEpochSecond__J() == NN(other).ToEpochSecond__J(); if tmp1 {
		tmp1 = NN(t.ToLocalTime__LocalTime()).GetNano__I() == NN(NN(other).ToLocalTime__LocalTime()).GetNano__I() }
//line :404:1
	return tmp1
}

func (t *OffsetDateTime) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if OffsetDateTime_InstanceOf(tmp1) { var other *OffsetDateTime = OffsetDateTime_Cast(tmp1); var tmp2 *LocalDateTime = t.F_dateTime
			if NN(tmp2).Equals_O__Z(other.F_dateTime.Ref()) { var tmp3 *ZoneOffset = t.F_offset; return NN(tmp3).Equals_O__Z(other.F_offset.Ref()) } else { return false } } else {
//line :410:1
				return false
			}
	}
}
func (t *OffsetDateTime) HashCode__I() int32 {
	return NN(t.F_dateTime).HashCode__I() ^ NN(t.F_offset).HashCode__I()
}
func (t *OffsetDateTime) ToString__String() *String {
	var offsetStr *String = NN(t.F_offset).ToString__String(); var buf *StringBuilder = StringBuilder_New_I(29 + NN(offsetStr).Length__I())

	DateTimeHelper_FormatTo_StringBuilder_LocalDateTime__V(buf, t.F_dateTime)
	return NN(NN(buf).Append_String__StringBuilder(offsetStr)).ToString__String()
}
func (t *OffsetDateTime) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.OffsetDateTime.writeReplace()Ljava/lang/Object;")) }



type OffsetDateTime struct{ Object; F_dateTime *LocalDateTime; F_offset *ZoneOffset }

func (t *OffsetDateTime) Is_Temporal() {}

func (t *OffsetDateTime) Is_TemporalAdjuster() {}

func (t *OffsetDateTime) Is_Comparable() {}

func (t *OffsetDateTime) Is_Serializable() {}

func (t *OffsetDateTime) Is_TemporalAccessor() {}

var OffsetDateTime_MIN *OffsetDateTime

var OffsetDateTime_MAX *OffsetDateTime

const OffsetDateTime_serialVersionUID int64 = 2287754244819255394

var OffsetDateTime_init ClassInit

func OffsetDateTime_Init() { if !OffsetDateTime_init.Done() { OffsetDateTime_init.Run(OffsetDateTime_clinit) } }

func OffsetDateTime_clinit() { var tmp1 *LocalDateTime; LocalDateTime_Init(); tmp1 = LocalDateTime_MIN; var tmp2 *LocalDateTime = tmp1; var tmp3 *ZoneOffset; ZoneOffset_Init(); tmp3 = ZoneOffset_MAX; OffsetDateTime_MIN = NN(tmp2).AtOffset_ZoneOffset__OffsetDateTime(tmp3); var tmp4 *LocalDateTime; LocalDateTime_Init(); tmp4 = LocalDateTime_MAX; var tmp5 *LocalDateTime = tmp4; var tmp6 *ZoneOffset; ZoneOffset_Init(); tmp6 = ZoneOffset_MIN; OffsetDateTime_MAX = NN(tmp5).AtOffset_ZoneOffset__OffsetDateTime(tmp6) }

func (t *OffsetDateTime) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_OffsetDateTime_Temporal(t.With_TemporalAdjuster__OffsetDateTime(p0)) }

func (t *OffsetDateTime) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_OffsetDateTime_Temporal(t.With_TemporalField_J__OffsetDateTime(p0, p1)) }

func (t *OffsetDateTime) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_OffsetDateTime_Temporal(t.Plus_TemporalAmount__OffsetDateTime(p0)) }

func (t *OffsetDateTime) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_OffsetDateTime_Temporal(t.Plus_J_TemporalUnit__OffsetDateTime(p0, p1)) }

func (t *OffsetDateTime) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_OffsetDateTime_Temporal(t.Minus_TemporalAmount__OffsetDateTime(p0)) }

func (t *OffsetDateTime) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_OffsetDateTime_Temporal(t.Minus_J_TemporalUnit__OffsetDateTime(p0, p1)) }

func (t *OffsetDateTime) CompareTo_O__I(p0 any) int32 { return t.CompareTo_OffsetDateTime__I(OffsetDateTime_Cast(p0)) }

func (t *OffsetDateTime) Ref() any { if t == nil { return nil }; return t }

func (t *OffsetDateTime) GetClass__Class() *Class { return OffsetDateTime_class }

func (t *OffsetDateTime) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OffsetDateTime) CloneShallow() any { panic(CloneNotSupported(t)) }

func OffsetDateTime_InstanceOf(x any) bool { _, ok := x.(*OffsetDateTime); return ok }

func OffsetDateTime_Cast(x any) *OffsetDateTime { if x == nil { return nil }; v, ok := x.(*OffsetDateTime); if !ok { panic(ClassCast(x, OffsetDateTime_class)) }; return v }
