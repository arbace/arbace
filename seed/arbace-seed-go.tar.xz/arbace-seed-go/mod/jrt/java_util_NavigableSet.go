//line java_util_NavigableSet.ae:1
package jrt






































func NavigableSet_RemoveFirst__O(this NavigableSet) any {
	if this.IsEmpty__Z() { panic(Thrown(NoSuchElementException_New())) } else { return this.PollFirst__O()
	} }
func NavigableSet_RemoveLast__O(this NavigableSet) any {
	if this.IsEmpty__Z() { panic(Thrown(NoSuchElementException_New())) } else { return this.PollLast__O()
	} }
func NavigableSet_Reversed__NavigableSet(this NavigableSet) NavigableSet {
	return this.DescendingSet__NavigableSet()
}


type NavigableSet interface{ Object_I; SortedSet; Set; SequencedSet; Collection; SequencedCollection; Iterable; Is_NavigableSet(); Lower_O__O(p0 any) any; Floor_O__O(p0 any) any; Ceiling_O__O(p0 any) any; Higher_O__O(p0 any) any; PollFirst__O() any; PollLast__O() any; Iterator__Iterator() Iterator; DescendingSet__NavigableSet() NavigableSet; DescendingIterator__Iterator() Iterator; SubSet_O_Z_O_Z__NavigableSet(p0 any, p1 bool, p2 any, p3 bool) NavigableSet; HeadSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet; TailSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet; SubSet_O_O__SortedSet(p0, p1 any) SortedSet; HeadSet_O__SortedSet(p0 any) SortedSet; TailSet_O__SortedSet(p0 any) SortedSet; RemoveFirst__O() any; RemoveLast__O() any; Reversed__NavigableSet() NavigableSet; Reversed__SortedSet() SortedSet; Reversed__SequencedSet() SequencedSet; Reversed__SequencedCollection() SequencedCollection }

func NavigableSet_Reversed__SortedSet(this NavigableSet) SortedSet { return this.Reversed__NavigableSet() }

func NavigableSet_Reversed__SequencedSet(this NavigableSet) SequencedSet { return this.Reversed__NavigableSet() }

func NavigableSet_Reversed__SequencedCollection(this NavigableSet) SequencedCollection { return this.Reversed__NavigableSet() }

func NavigableSet_InstanceOf(x any) bool { _, ok := x.(NavigableSet); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(NavigableSet_class) } }; return ok }

func NavigableSet_Cast(x any) NavigableSet { if x == nil { return nil }; v, ok := x.(NavigableSet); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(NavigableSet_class) } }; if !ok { panic(ClassCast(x, NavigableSet_class)) }; return v }
