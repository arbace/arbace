//line java_io_UnsupportedEncodingException.ae:1
package jrt








func UnsupportedEncodingException_New() *UnsupportedEncodingException { t := &UnsupportedEncodingException{}; t.Ctor(); return t }
//line :10:1
func (t *UnsupportedEncodingException) Ctor() { t.IOException.Ctor(t) }

func UnsupportedEncodingException_New_String(p0 *String) *UnsupportedEncodingException { t := &UnsupportedEncodingException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *UnsupportedEncodingException) Ctor_String(s *String) { t.IOException.Ctor_String(t, s) }







type UnsupportedEncodingException struct{ IOException }

const UnsupportedEncodingException_serialVersionUID int64 = -4274276298326136670

func (t *UnsupportedEncodingException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *UnsupportedEncodingException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *UnsupportedEncodingException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *UnsupportedEncodingException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *UnsupportedEncodingException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *UnsupportedEncodingException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *UnsupportedEncodingException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *UnsupportedEncodingException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *UnsupportedEncodingException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *UnsupportedEncodingException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *UnsupportedEncodingException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *UnsupportedEncodingException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *UnsupportedEncodingException) Ref() any { if t == nil { return nil }; return t }

func (t *UnsupportedEncodingException) GetClass__Class() *Class { return UnsupportedEncodingException_class }

func (t *UnsupportedEncodingException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UnsupportedEncodingException) CloneShallow() any { panic(CloneNotSupported(t)) }

func UnsupportedEncodingException_InstanceOf(x any) bool { _, ok := x.(*UnsupportedEncodingException); return ok }

func UnsupportedEncodingException_Cast(x any) *UnsupportedEncodingException { if x == nil { return nil }; v, ok := x.(*UnsupportedEncodingException); if !ok { panic(ClassCast(x, UnsupportedEncodingException_class)) }; return v }
