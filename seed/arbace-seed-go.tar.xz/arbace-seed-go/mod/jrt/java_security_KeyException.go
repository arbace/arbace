//line java_security_KeyException.ae:1
package jrt








func KeyException_New() *KeyException { t := &KeyException{}; t.Ctor(t); return t }
//line :10:1
func (t *KeyException) Ctor(this KeyException_I) { t.GeneralSecurityException.Ctor(this) }

func KeyException_New_String(p0 *String) *KeyException { t := &KeyException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *KeyException) Ctor_String(this KeyException_I, msg *String) { t.GeneralSecurityException.Ctor_String(this, msg) }

func KeyException_New_String_Throwable(p0 *String, p1 Throwable_I) *KeyException { t := &KeyException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :14:1
func (t *KeyException) Ctor_String_Throwable(this KeyException_I, message *String, cause Throwable_I) { t.GeneralSecurityException.Ctor_String_Throwable(this, message, cause) }


func KeyException_New_Throwable(p0 Throwable_I) *KeyException { t := &KeyException{}; t.Ctor_Throwable(t, p0); return t }
//line :17:1
func (t *KeyException) Ctor_Throwable(this KeyException_I, cause Throwable_I) { t.GeneralSecurityException.Ctor_Throwable(this, cause) }










type KeyException struct{ GeneralSecurityException }

type KeyException_I interface{ GeneralSecurityException_I; Serializable; Self_KeyException() *KeyException }

func (t *KeyException) Self_KeyException() *KeyException { return t }

const KeyException_serialVersionUID int64 = -7483676942812432108

func (t *KeyException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *KeyException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *KeyException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *KeyException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *KeyException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *KeyException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *KeyException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *KeyException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *KeyException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *KeyException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *KeyException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *KeyException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *KeyException) Ref() any { if t == nil { return nil }; return t }

func (t *KeyException) GetClass__Class() *Class { return KeyException_class }

func (t *KeyException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *KeyException) CloneShallow() any { panic(CloneNotSupported(t)) }

func KeyException_InstanceOf(x any) bool { _, ok := x.(KeyException_I); return ok }

func KeyException_Cast(x any) KeyException_I { if x == nil { return nil }; v, ok := x.(KeyException_I); if !ok { panic(ClassCast(x, KeyException_class)) }; return v }
