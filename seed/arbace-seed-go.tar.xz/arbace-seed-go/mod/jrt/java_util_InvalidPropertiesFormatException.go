//line java_util_InvalidPropertiesFormatException.ae:1
package jrt










func InvalidPropertiesFormatException_New_Throwable(p0 Throwable_I) *InvalidPropertiesFormatException { t := &InvalidPropertiesFormatException{}; t.Ctor_Throwable(p0); return t }
//line :12:1
func (t *InvalidPropertiesFormatException) Ctor_Throwable(cause Throwable_I) { var tmp1 *String; if
										!(cause == nil) { tmp1 = cause.ToString__String() } else { tmp1 = nil }; /*line :12:1*/t.IOException.Ctor_String(t, tmp1);

	t.InitCause_Throwable__Throwable(cause) }

func InvalidPropertiesFormatException_New_String(p0 *String) *InvalidPropertiesFormatException { t := &InvalidPropertiesFormatException{}; t.Ctor_String(p0); return t }
//line :16:1
func (t *InvalidPropertiesFormatException) Ctor_String(message *String) { t.IOException.Ctor_String(t, message) }





type InvalidPropertiesFormatException struct{ IOException }

const InvalidPropertiesFormatException_serialVersionUID int64 = 7763056076009360219

func (t *InvalidPropertiesFormatException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvalidPropertiesFormatException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvalidPropertiesFormatException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InvalidPropertiesFormatException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvalidPropertiesFormatException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvalidPropertiesFormatException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InvalidPropertiesFormatException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvalidPropertiesFormatException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvalidPropertiesFormatException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvalidPropertiesFormatException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvalidPropertiesFormatException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvalidPropertiesFormatException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvalidPropertiesFormatException) Ref() any { if t == nil { return nil }; return t }

func (t *InvalidPropertiesFormatException) GetClass__Class() *Class { return InvalidPropertiesFormatException_class }

func (t *InvalidPropertiesFormatException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvalidPropertiesFormatException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvalidPropertiesFormatException_InstanceOf(x any) bool { _, ok := x.(*InvalidPropertiesFormatException); return ok }

func InvalidPropertiesFormatException_Cast(x any) *InvalidPropertiesFormatException { if x == nil { return nil }; v, ok := x.(*InvalidPropertiesFormatException); if !ok { panic(ClassCast(x, InvalidPropertiesFormatException_class)) }; return v }
