//line java_util_LongSummaryStatistics.ae:1
package jrt
















func LongSummaryStatistics_New() *LongSummaryStatistics { t := &LongSummaryStatistics{}; t.Ctor(); return t }
//line :18:1
func (t *LongSummaryStatistics) Ctor() { t.F_min = 9223372036854775807; t.F_max = -9223372036854775808 }

func LongSummaryStatistics_New_J_J_J_J(p0, p1, p2, p3 int64) *LongSummaryStatistics { t := &LongSummaryStatistics{}; t.Ctor_J_J_J_J(p0, p1, p2, p3); return t }
//line :20:1
func (t *LongSummaryStatistics) Ctor_J_J_J_J(count, min_, max_, sum int64) { t.F_min = 9223372036854775807; t.F_max = -9223372036854775808

	if count < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2661))) } else {
			if count > 0 {
				if min_ > max_ { panic(Thrown(IllegalArgumentException_New_String(Lit_2662))) }
				t.F_count = count
				t.F_sum = sum
				t.F_min = min_
				t.F_max = max_
			} } }
func (t *LongSummaryStatistics) Accept_I__V(value int32) {
	t.Accept_J__V(int64(value))
}
func (t *LongSummaryStatistics) Accept_J__V(value int64) {
	t.F_count = t.F_count + 1
	t.F_sum = t.F_sum + value
	t.F_min = Math_Min_J_J__J(t.F_min, value)
	t.F_max = Math_Max_J_J__J(t.F_max, value)
}
func (t *LongSummaryStatistics) Combine_LongSummaryStatistics__V(other *LongSummaryStatistics) {
	var tmp1 int64 = t.F_count; t.F_count = tmp1 + other.F_count
	var tmp2 int64 = t.F_sum; t.F_sum = tmp2 + other.F_sum
	var tmp3 int64 = t.F_min; t.F_min = Math_Min_J_J__J(tmp3, other.F_min)
	var tmp4 int64 = t.F_max; t.F_max = Math_Max_J_J__J(tmp4, other.F_max)
}
func (t *LongSummaryStatistics) GetCount__J() int64 { return t.F_count }

func (t *LongSummaryStatistics) GetSum__J() int64 { return t.F_sum }

func (t *LongSummaryStatistics) GetMin__J() int64 { return t.F_min }

func (t *LongSummaryStatistics) GetMax__J() int64 { return t.F_max }

func (t *LongSummaryStatistics) GetAverage__D() float64 {
	if t.GetCount__J() > 0 { return float64(t.GetSum__J()) / float64(t.GetCount__J()) } else { return 0.0
	} }
func (t *LongSummaryStatistics) ToString__String() *String {
	return String_Format_String_O1__String(Lit_2735, RefArrayOf(Object_class, NN(t.GetClass__Class()).GetSimpleName__String().Ref(), Long_ValueOf_J__Long(t.GetCount__J()), Long_ValueOf_J__Long(t.GetSum__J()), Long_ValueOf_J__Long(t.GetMin__J()), Double_ValueOf_D__Double(t.GetAverage__D()), Long_ValueOf_J__Long(t.GetMax__J())))
}


type LongSummaryStatistics struct{ Object; F_count, F_sum, F_min, F_max int64 }

func (t *LongSummaryStatistics) Is_LongConsumer() {}

func (t *LongSummaryStatistics) Is_IntConsumer() {}

func (t *LongSummaryStatistics) AndThen_IntConsumer__IntConsumer(p0 IntConsumer) IntConsumer { return IntConsumer_AndThen_IntConsumer__IntConsumer(t, p0) }

func (t *LongSummaryStatistics) AndThen_LongConsumer__LongConsumer(p0 LongConsumer) LongConsumer { return LongConsumer_AndThen_LongConsumer__LongConsumer(t, p0) }

func (t *LongSummaryStatistics) Ref() any { if t == nil { return nil }; return t }

func (t *LongSummaryStatistics) GetClass__Class() *Class { return LongSummaryStatistics_class }

func (t *LongSummaryStatistics) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LongSummaryStatistics) CloneShallow() any { panic(CloneNotSupported(t)) }

func LongSummaryStatistics_InstanceOf(x any) bool { _, ok := x.(*LongSummaryStatistics); return ok }

func LongSummaryStatistics_Cast(x any) *LongSummaryStatistics { if x == nil { return nil }; v, ok := x.(*LongSummaryStatistics); if !ok { panic(ClassCast(x, LongSummaryStatistics_class)) }; return v }
