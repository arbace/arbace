//line java_lang_reflect_Type.ae:1
package jrt




func Type_GetTypeName__String(this Type) *String { return this.ToString__String() }



type Type interface{ Object_I; Is_Type(); GetTypeName__String() *String }

func Type_InstanceOf(x any) bool { _, ok := x.(Type); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Type_class) } }; return ok }

func Type_Cast(x any) Type { if x == nil { return nil }; v, ok := x.(Type); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Type_class) } }; if !ok { panic(ClassCast(x, Type_class)) }; return v }
