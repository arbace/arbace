//line java_net_URLClassLoader.ae:1
package jrt

















func URLClassLoader_New_URL1_ClassLoader(p0 *RefArray, p1 ClassLoader_I) *URLClassLoader { t := &URLClassLoader{}; t.Ctor_URL1_ClassLoader(p0, p1); return t }
//line :19:1
func (t *URLClassLoader) Ctor_URL1_ClassLoader(urls *RefArray, parent ClassLoader_I) { t.Ctor_String_URL1_ClassLoader(nil, urls, parent) }


func URLClassLoader_New_URL1(p0 *RefArray) *URLClassLoader { t := &URLClassLoader{}; t.Ctor_URL1(p0); return t }
//line :22:1
func (t *URLClassLoader) Ctor_URL1(urls *RefArray) { t.Ctor_String_URL1_ClassLoader(nil, urls, ClassLoader_GetSystemClassLoader__ClassLoader()) }


func URLClassLoader_New_URL1_ClassLoader_URLStreamHandlerFactory(p0 *RefArray, p1 ClassLoader_I, p2 URLStreamHandlerFactory) *URLClassLoader { t := &URLClassLoader{}; t.Ctor_URL1_ClassLoader_URLStreamHandlerFactory(p0, p1, p2); return t }
//line :25:1
func (t *URLClassLoader) Ctor_URL1_ClassLoader_URLStreamHandlerFactory(urls *RefArray, parent ClassLoader_I, factory URLStreamHandlerFactory) { t.Ctor_String_URL1_ClassLoader(nil, urls, parent) }


func URLClassLoader_New_String_URL1_ClassLoader(p0 *String, p1 *RefArray, p2 ClassLoader_I) *URLClassLoader { t := &URLClassLoader{}; t.Ctor_String_URL1_ClassLoader(p0, p1, p2); return t }
//line :28:1
func (t *URLClassLoader) Ctor_String_URL1_ClassLoader(name *String, urls *RefArray, parent ClassLoader_I) { t.ClassLoader.Ctor_ClassLoader(t, parent); t.F_urls = ArrayList_New()

	t.F_name = name
	var arr_101138 *RefArray = urls; var len_101139 int32 = int32(len(arr_101138.A)); var i_101140 int32 = 0; for ; i_101140 < len_101139; i_101140++ { var u *URL = As[*URL](arr_101138.A[i_101140]); if u == nil { panic(Thrown(NullPointerException_New())) }; t.F_urls.Add_O__Z(u.Ref())
	} }
func URLClassLoader_New_String_URL1_ClassLoader_URLStreamHandlerFactory(p0 *String, p1 *RefArray, p2 ClassLoader_I, p3 URLStreamHandlerFactory) *URLClassLoader { t := &URLClassLoader{}; t.Ctor_String_URL1_ClassLoader_URLStreamHandlerFactory(p0, p1, p2, p3); return t }
//line :33:1
func (t *URLClassLoader) Ctor_String_URL1_ClassLoader_URLStreamHandlerFactory(name *String, urls *RefArray, parent ClassLoader_I, factory URLStreamHandlerFactory) { t.Ctor_String_URL1_ClassLoader(name, urls, parent) }



func URLClassLoader_NewInstance_URL1_ClassLoader__URLClassLoader(urls *RefArray, parent ClassLoader_I) *URLClassLoader {
	return URLClassLoader_New_URL1_ClassLoader(urls, parent)
}
func URLClassLoader_NewInstance_URL1__URLClassLoader(urls *RefArray) *URLClassLoader {
	return URLClassLoader_New_URL1(urls)
}
func (t *URLClassLoader) GetName__String() *String { return t.F_name }

func (t *URLClassLoader) GetURLs__URL1() *RefArray {
	var tmp1 *RefArray; var tmp2 any = t.F_urls; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); var tmp3 List = t.F_urls; tmp1 = A2g_CastArray[*RefArray](tmp3.ToArray_O1__O1(NewRefArray(URL_class, 0)).Ref(), URL_class.ArrayClass()) }(); return tmp1
}
func (t *URLClassLoader) AddURL_URL__V(p0 *URL) { panic(A2g_NotTranslated("java.net.URLClassLoader.addURL(Ljava/net/URL;)V")) }


func (t *URLClassLoader) Close__V() {
	var tmp1 any = t.F_urls; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_closed = true }()
}
func (t *URLClassLoader) FindResource_String__URL(name *String) *URL {
	var arr_101141 *RefArray = t.GetURLs__URL1(); var len_101142 int32 = int32(len(arr_101141.A)); var i_101143 int32 = 0; for ; i_101143 < len_101142; i_101143++ { var base *URL = As[*URL](arr_101141.A[i_101143]); var u *URL = t.InURL_URL_String__URL(base, name)
		if !(u == nil) { return u } }
//line :54:1
	return nil
}



func (t *URLClassLoader) FindResources_String__Enumeration(name *String) Enumeration {
	var found List = ArrayList_New(); var arr_101144 *RefArray = t.GetURLs__URL1(); var len_101145 int32 = int32(len(arr_101144.A)); var i_101146 int32 = 0; for ; i_101146 < len_101145; i_101146++ {
		var base *URL = As[*URL](arr_101144.A[i_101146]); var u *URL = t.InURL_URL_String__URL(base, name)
		if !(u == nil) { found.Add_O__Z(u.Ref()) } }
	return Collections_Enumeration_Collection__Enumeration(found)
}
func (t *URLClassLoader) InURL_URL_String__URL(base *URL, name *String) *URL {
	var tmp1 any = t.F_urls; MonitorEnter(tmp1); tmp2, tmp3 := func() (ctl int32, rv *URL) { defer MonitorExit(tmp1); if t.F_closed { return 2, nil }; return 0, nil }(); switch tmp2 { case 2: { return tmp3 }}
	var tmp4 bool; var tmp5 bool; tmp5 = Lit_61.Equals_O__Z(NN(base).GetProtocol__String().Ref()); if tmp5 { tmp5 = NN(NN(base).GetFile__String()).EndsWith_String__Z(Lit_68) }; tmp4 = tmp5; if tmp4 {
		return ClassPathResources_InDirectory_URL_String__URL(base, name) } else {
//line :67:1
			return nil
		}
}
func (t *URLClassLoader) GetResource_String__URL(name *String) *URL {
	var parent ClassLoader_I = t.GetParent__ClassLoader(); var url *URL
	if !(parent == nil) { url = ClassPathResources_GetResource_ClassLoader_String__URL(parent, name) } else { url = nil }
	if url == nil { url = t.FindResource_String__URL(name) }
//line :71:1
	return url
}



func (t *URLClassLoader) GetResources_String__Enumeration(name *String) Enumeration {
	var all List = ArrayList_New(); var parent ClassLoader_I = t.GetParent__ClassLoader()

	if !(parent == nil) {
		all.AddAll_Collection__Z(Up_ArrayList_Collection(Collections_List_Enumeration__ArrayList(ClassPathResources_GetResources_ClassLoader_String__Enumeration(parent, name)))) }
	all.AddAll_Collection__Z(Up_ArrayList_Collection(Collections_List_Enumeration__ArrayList(t.FindResources_String__Enumeration(name))))
	return Collections_Enumeration_Collection__Enumeration(all)
}
func (t *URLClassLoader) GetResourceAsStream_String__InputStream(name *String) InputStream_I {
	var url *URL = t.GetResource_String__URL(name); var tmp1 InputStream_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		if !(url == nil) { tmp1 = NN(url).OpenStream__InputStream() } else { tmp1 = nil }; return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var e IOException_I = IOException_Cast(tmp2); _ = e; tmp1 = nil } else { panic(tmp2) } }; return tmp1
}


type URLClassLoader struct{ ClassLoader; F_urls List; F_name *String; F_closed bool }

func (t *URLClassLoader) Is_Closeable() {}

func (t *URLClassLoader) Is_AutoCloseable() {}

func (t *URLClassLoader) Ref() any { if t == nil { return nil }; return t }

func (t *URLClassLoader) GetClass__Class() *Class { return URLClassLoader_class }

func (t *URLClassLoader) ToString__String() *String { return Object_toString(t) }

func (t *URLClassLoader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URLClassLoader) CloneShallow() any { panic(CloneNotSupported(t)) }

func URLClassLoader_InstanceOf(x any) bool { _, ok := x.(*URLClassLoader); return ok }

func URLClassLoader_Cast(x any) *URLClassLoader { if x == nil { return nil }; v, ok := x.(*URLClassLoader); if !ok { panic(ClassCast(x, URLClassLoader_class)) }; return v }
