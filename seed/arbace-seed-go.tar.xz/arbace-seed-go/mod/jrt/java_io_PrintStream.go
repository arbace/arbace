//line java_io_PrintStream.ae:1
package jrt






















func PrintStream_RequireNonNull_O_String__O(obj any, message *String) any {
	if obj == nil { panic(Thrown(NullPointerException_New_String(message))) }
//line :24:1
	return obj
}


func PrintStream_ToCharset_String__Charset(csn *String) Charset_I {
	PrintStream_RequireNonNull_O_String__O(csn.Ref(), Lit_85)
	var tmp1 Charset_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = Charset_ForName_String__Charset(csn); return nil }()
//line :30:1
	if tmp2 != nil { if IllegalCharsetNameException_InstanceOf(tmp2) || UnsupportedCharsetException_InstanceOf(tmp2) { var unused IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = unused


		panic(Thrown(UnsupportedEncodingException_New_String(csn))) } else {
//line :30:1
			panic(tmp2) } }; return tmp1
}



func PrintStream_New_Z_OutputStream(p0 bool, p1 OutputStream_I) *PrintStream { t := &PrintStream{}; t.Ctor_Z_OutputStream(p0, p1); return t }
//line :35:1
func (t *PrintStream) Ctor_Z_OutputStream(autoFlush bool, out OutputStream_I) { t.FilterOutputStream.Ctor_OutputStream(t, out); t.F_trouble = false; t.F_closing = false

	t.F_autoFlush = autoFlush
	var tmp1 Charset_I; var tmp2 OutputStream_I = out
	if PrintStream_InstanceOf(tmp2) { var ps *PrintStream = PrintStream_Cast(tmp2); tmp1 = NN(ps).Charset__Charset() } else { tmp1 = Charset_DefaultCharset__Charset() }
//line :38:1
	t.F_charset = tmp1

	t.F_charOut = OutputStreamWriter_New_OutputStream_Charset(t, t.F_charset)
	t.F_textOut = BufferedWriter_New_Writer(t.F_charOut)
}
func PrintStream_New_Z_Charset_OutputStream(p0 bool, p1 Charset_I, p2 OutputStream_I) *PrintStream { t := &PrintStream{}; t.Ctor_Z_Charset_OutputStream(p0, p1, p2); return t }
//line :43:1
func (t *PrintStream) Ctor_Z_Charset_OutputStream(autoFlush bool, charset Charset_I, out OutputStream_I) { t.Ctor_OutputStream_Z_Charset(out, autoFlush, charset) }


func PrintStream_New_OutputStream(p0 OutputStream_I) *PrintStream { t := &PrintStream{}; t.Ctor_OutputStream(p0); return t }
//line :46:1
func (t *PrintStream) Ctor_OutputStream(out OutputStream_I) { t.Ctor_OutputStream_Z(out, false) }

func PrintStream_New_OutputStream_Z(p0 OutputStream_I, p1 bool) *PrintStream { t := &PrintStream{}; t.Ctor_OutputStream_Z(p0, p1); return t }
//line :48:1
func (t *PrintStream) Ctor_OutputStream_Z(out OutputStream_I, autoFlush bool) { t.Ctor_Z_OutputStream(autoFlush, OutputStream_Cast(PrintStream_RequireNonNull_O_String__O(out, Lit_96))) }


func PrintStream_New_OutputStream_Z_String(p0 OutputStream_I, p1 bool, p2 *String) *PrintStream { t := &PrintStream{}; t.Ctor_OutputStream_Z_String(p0, p1, p2); return t }
//line :51:1
func (t *PrintStream) Ctor_OutputStream_Z_String(out OutputStream_I, autoFlush bool, encoding *String) { t.Ctor_OutputStream_Z_Charset(OutputStream_Cast(PrintStream_RequireNonNull_O_String__O(out, Lit_96)), autoFlush, PrintStream_ToCharset_String__Charset(encoding)) }





func PrintStream_New_OutputStream_Z_Charset(p0 OutputStream_I, p1 bool, p2 Charset_I) *PrintStream { t := &PrintStream{}; t.Ctor_OutputStream_Z_Charset(p0, p1, p2); return t }
//line :57:1
func (t *PrintStream) Ctor_OutputStream_Z_Charset(out OutputStream_I, autoFlush bool, charset Charset_I) { t.FilterOutputStream.Ctor_OutputStream(t, out); t.F_trouble = false; t.F_closing = false

	t.F_autoFlush = autoFlush
	t.F_charOut = OutputStreamWriter_New_OutputStream_Charset(t, charset)
	t.F_textOut = BufferedWriter_New_Writer(t.F_charOut)
	t.F_charset = charset
}
func PrintStream_New_String(p0 *String) *PrintStream { t := &PrintStream{}; t.Ctor_String(p0); return t }
//line :64:1
func (t *PrintStream) Ctor_String(fileName *String) { t.Ctor_Z_OutputStream(false, FileOutputStream_New_String(fileName)) }


func PrintStream_New_String_String(p0, p1 *String) *PrintStream { t := &PrintStream{}; t.Ctor_String_String(p0, p1); return t }
//line :67:1
func (t *PrintStream) Ctor_String_String(fileName, csn *String) { t.Ctor_Z_Charset_OutputStream(false, PrintStream_ToCharset_String__Charset(csn), FileOutputStream_New_String(fileName)) }




func PrintStream_New_String_Charset(p0 *String, p1 Charset_I) *PrintStream { t := &PrintStream{}; t.Ctor_String_Charset(p0, p1); return t }
//line :72:1
func (t *PrintStream) Ctor_String_Charset(fileName *String, charset Charset_I) { t.Ctor_Z_Charset_OutputStream(false, Charset_Cast(PrintStream_RequireNonNull_O_String__O(charset, Lit_86)), FileOutputStream_New_String(fileName)) }




func PrintStream_New_File(p0 *File) *PrintStream { t := &PrintStream{}; t.Ctor_File(p0); return t }
//line :77:1
func (t *PrintStream) Ctor_File(file *File) { t.Ctor_Z_OutputStream(false, FileOutputStream_New_File(file)) }


func PrintStream_New_File_String(p0 *File, p1 *String) *PrintStream { t := &PrintStream{}; t.Ctor_File_String(p0, p1); return t }
//line :80:1
func (t *PrintStream) Ctor_File_String(file *File, csn *String) { t.Ctor_Z_Charset_OutputStream(false, PrintStream_ToCharset_String__Charset(csn), FileOutputStream_New_File(file)) }




func PrintStream_New_File_Charset(p0 *File, p1 Charset_I) *PrintStream { t := &PrintStream{}; t.Ctor_File_Charset(p0, p1); return t }
//line :85:1
func (t *PrintStream) Ctor_File_Charset(file *File, charset Charset_I) { t.Ctor_Z_Charset_OutputStream(false, Charset_Cast(PrintStream_RequireNonNull_O_String__O(charset, Lit_86)), FileOutputStream_New_File(file)) }




func (t *PrintStream) EnsureOpen__V() {
	if t.F_out == nil { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *PrintStream) Flush__V() {
	var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		t.EnsureOpen__V(); t.F_out.Flush__V(); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; t.F_trouble = true } else { panic(tmp2) } } }()
}


func (t *PrintStream) Close__V() {
	var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if t.F_closing { } else {
			t.F_closing = true; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
				t.F_textOut.Close__V(); t.F_out.Close__V(); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x; t.F_trouble = true } else { panic(tmp2) } }
			t.F_textOut = nil
			t.F_charOut = nil
			t.F_out = nil
		} }() }
func (t *PrintStream) CheckError__Z() bool {
	if !(t.F_out == nil) { t.Flush__V() }
	var tmp1 OutputStream_I = t.F_out; if PrintStream_InstanceOf(tmp1) { var ps *PrintStream = PrintStream_Cast(tmp1); return NN(ps).CheckError__Z() } else { return t.F_trouble
	} }
func (t *PrintStream) SetError__V() { panic(A2g_NotTranslated("java.io.PrintStream.setError()V")) }

func (t *PrintStream) ClearError__V() { panic(A2g_NotTranslated("java.io.PrintStream.clearError()V")) }

func (t *PrintStream) Write_I__V(b int32) { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		t.F_out.Write_I__V(b)
		var tmp2 bool; var tmp3 bool; tmp3 = b == 10; if tmp3 { tmp3 = t.F_autoFlush }; tmp2 = tmp3; if tmp2 { t.F_out.Flush__V() } }() }; return nil }(); if /*line :117:1*/ tmp4 != nil { if IOException_InstanceOf(tmp4) { var x IOException_I = IOException_Cast(tmp4); _ = x




			t.F_trouble = true } else {
//line :117:1
				panic(tmp4) } } }






func (t *PrintStream) Write_B1_I_I__V(buf *ByteArray, off, len_ int32) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		t.F_out.Write_B1_I_I__V(buf, off, len_)
		if t.F_autoFlush { t.F_out.Flush__V() } }() }; return nil }(); if /*line :125:1*/ tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x




			t.F_trouble = true } else {
//line :125:1
				panic(tmp2) } } }






func (t *PrintStream) Write_B1__V(buf *ByteArray) {
	t.Write_B1_I_I__V(buf, 0, int32(len(buf.A)))
}
func (t *PrintStream) WriteBytes_B1__V(buf *ByteArray) {
	t.Write_B1_I_I__V(buf, 0, int32(len(buf.A)))
}
func (t *PrintStream) Write_C1__V(buf *CharArray) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		t.F_textOut.Write_C1__V(buf)
		t.F_textOut.FlushBuffer__V()
		t.F_charOut.FlushBuffer__V()
		if t.F_autoFlush {
			var i int32 = 0; L1: for {
				if i < int32(len(buf.A)) {
					if int32(buf.A[i]) == 10 { t.F_out.Flush__V() } else { i = i + 1; continue L1 } }
//line :146:1
				break L1
			} } }() }
	return nil }(); if /*line :139:1*/ tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x










		t.F_trouble = true } else {
//line :139:1
			panic(tmp2) } } }












func (t *PrintStream) Writeln_C1__V(buf *CharArray) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		t.F_textOut.Write_C1__V(buf)
		t.F_textOut.NewLine__V()
		t.F_textOut.FlushBuffer__V()
		t.F_charOut.FlushBuffer__V()
		if t.F_autoFlush { t.F_out.Flush__V() } }() }; return nil }(); if /*line :153:1*/ tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x







			t.F_trouble = true } else {
//line :153:1
				panic(tmp2) } } }









func (t *PrintStream) Write_String__V(s *String) { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		t.F_textOut.Write_String__V(s)
		t.F_textOut.FlushBuffer__V()
		t.F_charOut.FlushBuffer__V()
		var tmp2 bool; var tmp3 bool; tmp3 = t.F_autoFlush; if tmp3 { tmp3 = NN(s).IndexOf_I__I(10) >= 0 }; tmp2 = tmp3; if tmp2 { t.F_out.Flush__V() } }() }; return nil }(); if /*line :164:1*/ tmp4 != nil { if IOException_InstanceOf(tmp4) { var x IOException_I = IOException_Cast(tmp4); _ = x






			t.F_trouble = true } else {
//line :164:1
				panic(tmp4) } } }








func (t *PrintStream) Writeln_String__V(s *String) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		t.F_textOut.Write_String__V(s)
		t.F_textOut.NewLine__V()
		t.F_textOut.FlushBuffer__V()
		t.F_charOut.FlushBuffer__V()
		if t.F_autoFlush { t.F_out.Flush__V() } }() }; return nil }(); if /*line :174:1*/ tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x







			t.F_trouble = true } else {
//line :174:1
				panic(tmp2) } } }









func (t *PrintStream) NewLine__V() { tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		t.F_textOut.NewLine__V()
		t.F_textOut.FlushBuffer__V()
		t.F_charOut.FlushBuffer__V()
		if t.F_autoFlush { t.F_out.Flush__V() } }() }; return nil }(); if /*line :185:1*/ tmp2 != nil { if IOException_InstanceOf(tmp2) { var x IOException_I = IOException_Cast(tmp2); _ = x






			t.F_trouble = true } else {
//line :185:1
				panic(tmp2) } } }








func (t *PrintStream) Print_Z__V(b bool) {
	t.Write_String__V(String_ValueOf_Z__String(b))
}
func (t *PrintStream) Print_C__V(c uint16) {
	t.Write_String__V(String_ValueOf_C__String(c))
}
func (t *PrintStream) Print_I__V(i int32) {
	t.Write_String__V(String_ValueOf_I__String(i))
}
func (t *PrintStream) Print_J__V(l int64) {
	t.Write_String__V(String_ValueOf_J__String(l))
}
func (t *PrintStream) Print_F__V(f float32) {
	t.Write_String__V(String_ValueOf_F__String(f))
}
func (t *PrintStream) Print_D__V(d float64) {
	t.Write_String__V(String_ValueOf_D__String(d))
}
func (t *PrintStream) Print_C1__V(s *CharArray) { t.Write_C1__V(s) }

func (t *PrintStream) Print_String__V(s *String) {
	t.Write_String__V(String_ValueOf_O__String(s.Ref()))
}
func (t *PrintStream) Print_O__V(obj any) {
	t.Write_String__V(String_ValueOf_O__String(obj))
}
func (t *PrintStream) Println__V() { t.NewLine__V() }

func (t *PrintStream) Println_Z__V(x bool) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_Z__String(x)) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_Z__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_C__V(x uint16) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_C__String(x)) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_C__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_I__V(x int32) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_I__String(x)) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_I__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_J__V(x int64) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_J__String(x)) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_J__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_F__V(x float32) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_F__String(x)) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_F__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_D__V(x float64) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_D__String(x)) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_D__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_C1__V(x *CharArray) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_C1__V(x) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_C1__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_String__V(x *String) {
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_O__String(x.Ref())) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_String__V(x); t.NewLine__V() }()
		} }
func (t *PrintStream) Println_O__V(x any) {
	var s *String = String_ValueOf_O__String(x)
	if t.GetClass__Class() == PrintStream_class {
		t.Writeln_String__V(String_ValueOf_O__String(s.Ref())) } else {
			var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.Print_String__V(s); t.NewLine__V() }()
		} }
func (t *PrintStream) Printf_String_O1__PrintStream(format *String, args *RefArray) *PrintStream {
	return t.Format_String_O1__PrintStream(format, args)
}
func (t *PrintStream) Printf_Locale_String_O1__PrintStream(l *Locale, format *String, args *RefArray) *PrintStream {
	return t.Format_Locale_String_O1__PrintStream(l, format, args)
}
func (t *PrintStream) Format_String_O1__PrintStream(format *String, args *RefArray) *PrintStream { tmp8 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		var tmp2 bool; var tmp3 bool; tmp3 = t.F_formatter == nil; if !tmp3 {
			var tmp4 *Locale = NN(t.F_formatter).Locale__Locale(); var tmp5 *Locale_Category; Locale_Category_Init(); tmp5 = Locale_Category_FORMAT; tmp3 = !(tmp4 == Locale_GetDefault_Locale_Category__Locale(tmp5)) }
//line :278:1
		tmp2 = tmp3; if tmp2 {

			t.F_formatter = Formatter_New_Appendable(t) }
		var tmp6 *Formatter = t.F_formatter; var tmp7 *Locale_Category; Locale_Category_Init(); tmp7 = Locale_Category_FORMAT; NN(tmp6).Format_Locale_String_O1__Formatter(Locale_GetDefault_Locale_Category__Locale(tmp7), format, args) }() }; return nil }(); if /*line :275:1*/ tmp8 != nil { if IOException_InstanceOf(tmp8) { var x IOException_I = IOException_Cast(tmp8); _ = x






			t.F_trouble = true } else {
//line :275:1
				panic(tmp8) } }; return t }









func (t *PrintStream) Format_Locale_String_O1__PrintStream(l *Locale, format *String, args *RefArray) *PrintStream { tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 any = t; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.EnsureOpen__V()
		var tmp2 bool; var tmp3 bool; tmp3 = t.F_formatter == nil; if !tmp3 { tmp3 = !(NN(t.F_formatter).Locale__Locale() == l) }; tmp2 = tmp3; if tmp2 {
			t.F_formatter = Formatter_New_Appendable_Locale(t, l) }
		NN(t.F_formatter).Format_Locale_String_O1__Formatter(l, format, args) }() }; return nil }(); if /*line :286:1*/ tmp4 != nil { if IOException_InstanceOf(tmp4) { var x IOException_I = IOException_Cast(tmp4); _ = x





			t.F_trouble = true } else {
//line :286:1
				panic(tmp4) } }; return t }








func (t *PrintStream) Append_CharSequence__PrintStream(csq CharSequence) *PrintStream {
	t.Print_String__V(String_ValueOf_O__String(csq))
//line :295:1
	return t
}


func (t *PrintStream) Append_CharSequence_I_I__PrintStream(csq CharSequence, start, end int32) *PrintStream {
	if csq == nil { csq = Lit_95 }
	return t.Append_CharSequence__PrintStream(csq.SubSequence_I_I__CharSequence(start, end))
}
func (t *PrintStream) Append_C__PrintStream(c uint16) *PrintStream {
	t.Print_C__V(c)
//line :303:1
	return t
}


func (t *PrintStream) Charset__Charset() Charset_I { return t.F_charset }



type PrintStream struct{ FilterOutputStream; F_autoFlush, F_trouble bool; F_formatter *Formatter; F_charset Charset_I; F_textOut BufferedWriter_I; F_charOut OutputStreamWriter_I; F_closing bool }

func (t *PrintStream) Is_Appendable() {}

func (t *PrintStream) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return Up_PrintStream_Appendable(t.Append_CharSequence__PrintStream(p0)) }

func (t *PrintStream) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return Up_PrintStream_Appendable(t.Append_CharSequence_I_I__PrintStream(p0, p1, p2)) }

func (t *PrintStream) Append_C__Appendable(p0 uint16) Appendable { return Up_PrintStream_Appendable(t.Append_C__PrintStream(p0)) }

func (t *PrintStream) Ref() any { if t == nil { return nil }; return t }

func (t *PrintStream) GetClass__Class() *Class { return PrintStream_class }

func (t *PrintStream) ToString__String() *String { return Object_toString(t) }

func (t *PrintStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PrintStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func PrintStream_InstanceOf(x any) bool { _, ok := x.(*PrintStream); return ok }

func PrintStream_Cast(x any) *PrintStream { if x == nil { return nil }; v, ok := x.(*PrintStream); if !ok { panic(ClassCast(x, PrintStream_class)) }; return v }
