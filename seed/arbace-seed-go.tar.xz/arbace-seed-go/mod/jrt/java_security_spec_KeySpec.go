//line java_security_spec_KeySpec.ae:1
package jrt






type KeySpec interface{ Object_I; Is_KeySpec() }

func KeySpec_InstanceOf(x any) bool { _, ok := x.(KeySpec); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(KeySpec_class) } }; return ok }

func KeySpec_Cast(x any) KeySpec { if x == nil { return nil }; v, ok := x.(KeySpec); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(KeySpec_class) } }; if !ok { panic(ClassCast(x, KeySpec_class)) }; return v }
