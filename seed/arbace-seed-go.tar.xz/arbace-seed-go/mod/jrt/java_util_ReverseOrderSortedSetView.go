//line java_util_ReverseOrderSortedSetView.ae:1
package jrt















func ReverseOrderSortedSetView_New_SortedSet(p0 SortedSet) *ReverseOrderSortedSetView { t := &ReverseOrderSortedSetView{}; t.Ctor_SortedSet(p0); return t }
//line :17:1
func (t *ReverseOrderSortedSetView) Ctor_SortedSet(set SortedSet) {
	t.F_base = set
	t.F_comp = Collections_ReverseOrder_Comparator__Comparator(set.Comparator__Comparator())
}
func ReverseOrderSortedSetView_Of_SortedSet__SortedSet(set SortedSet) SortedSet {
	var tmp1 SortedSet = set; if ReverseOrderSortedSetView_InstanceOf(tmp1) { var rossv *ReverseOrderSortedSetView = ReverseOrderSortedSetView_Cast(tmp1)
		return rossv.F_base } else {
			return ReverseOrderSortedSetView_New_SortedSet(set)
		} }
func (t *ReverseOrderSortedSetView) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else { if !Set_InstanceOf(o) { return false } else {



		var c Collection = Collection_Cast(o)
		if !(c.Size__I() == t.Size__I()) { return false } else {

			var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
				tmp1 = t.ContainsAll_Collection__Z(c); return nil }()
//line :34:1
			if tmp2 != nil { if ClassCastException_InstanceOf(tmp2) || NullPointerException_InstanceOf(tmp2) { var unused RuntimeException_I = RuntimeException_Cast(tmp2); _ = unused; tmp1 = false } else { panic(tmp2) } }; return tmp1
		}
	}
	} }
func (t *ReverseOrderSortedSetView) HashCode__I() int32 {
	var h int32 = 0; var i Iterator = t.Iterator__Iterator()

L1: for { if i.HasNext__Z() {
	var obj any = i.Next__O(); if !(obj == nil) { h = h + HashCode(obj) }
//line :41:1
	continue L1 }; break L1 }
//line :39:1
	return h
}




func (t *ReverseOrderSortedSetView) ToString__String() *String {
	{ var it Iterator = t.Iterator__Iterator()
		if !it.HasNext__Z() { return Lit_2589 } else {

			var sb *StringBuilder = StringBuilder_New()
			NN(sb).Append_C__StringBuilder(91)
		L1: for {
			var e any = it.Next__O(); var tmp1 any
			if any(e) == any(t) { tmp1 = Lit_2590 } else { tmp1 = e }; NN(sb).Append_O__StringBuilder(tmp1)
			if it.HasNext__Z() { } else { return NN(NN(sb).Append_C__StringBuilder(93)).ToString__String() }
			NN(NN(sb).Append_C__StringBuilder(44)).Append_C__StringBuilder(32)
//line :51:1
			continue L1
		}
		}
	}
	panic("a2g: unreachable")
}
func (t *ReverseOrderSortedSetView) ForEach_Consumer__V(action Consumer) {
	var i_102014 Iterator = t.Iterator__Iterator(); for i_102014.HasNext__Z() { var e any = i_102014.Next__O(); action.Accept_O__V(e)
	} }
func (t *ReverseOrderSortedSetView) Iterator__Iterator() Iterator {
	return ReverseOrderSortedSetView_DescendingIterator_SortedSet__Iterator(t.F_base)
}
func (t *ReverseOrderSortedSetView) Spliterator__Spliterator() Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(t, 16)
}
func (t *ReverseOrderSortedSetView) Add_O__Z(e any) bool { t.F_base.Add_O__Z(e); return true }

func (t *ReverseOrderSortedSetView) AddAll_Collection__Z(c Collection) bool {
	return t.F_base.AddAll_Collection__Z(c)
}
func (t *ReverseOrderSortedSetView) Clear__V() { t.F_base.Clear__V() }

func (t *ReverseOrderSortedSetView) Contains_O__Z(o any) bool { return t.F_base.Contains_O__Z(o) }

func (t *ReverseOrderSortedSetView) ContainsAll_Collection__Z(c Collection) bool {
	return t.F_base.ContainsAll_Collection__Z(c)
}
func (t *ReverseOrderSortedSetView) IsEmpty__Z() bool { return t.F_base.IsEmpty__Z() }

func (t *ReverseOrderSortedSetView) ParallelStream__Stream() Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(t.Spliterator__Spliterator(), true)
}
func (t *ReverseOrderSortedSetView) Remove_O__Z(o any) bool { return t.F_base.Remove_O__Z(o) }

func (t *ReverseOrderSortedSetView) RemoveAll_Collection__Z(c Collection) bool {
	return t.F_base.RemoveAll_Collection__Z(c)
}
func (t *ReverseOrderSortedSetView) RetainAll_Collection__Z(c Collection) bool {
	return t.F_base.RetainAll_Collection__Z(c)
}
func (t *ReverseOrderSortedSetView) Size__I() int32 { return t.F_base.Size__I() }

func (t *ReverseOrderSortedSetView) Stream__Stream() Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(t.Spliterator__Spliterator(), false)
}
func (t *ReverseOrderSortedSetView) ToArray__O1() *RefArray {
	return ArraysSupport_Reverse_O1__O1(t.F_base.ToArray__O1())
}
func (t *ReverseOrderSortedSetView) ToArray_O1__O1(a *RefArray) *RefArray {
	return ArraysSupport_ToArrayReversed_Collection_O1__O1(t.F_base, a)
}
func (t *ReverseOrderSortedSetView) ToArray_IntFunction__O1(generator IntFunction) *RefArray {
	return ArraysSupport_Reverse_O1__O1(t.F_base.ToArray_IntFunction__O1(generator))
}
func (t *ReverseOrderSortedSetView) Comparator__Comparator() Comparator { return t.F_comp }


func (t *ReverseOrderSortedSetView) First__O() any { return t.F_base.Last__O() }

func (t *ReverseOrderSortedSetView) Last__O() any { return t.F_base.First__O() }

func (t *ReverseOrderSortedSetView) HeadSet_O__SortedSet(to any) SortedSet {
	return ReverseOrderSortedSetView_Subset_New_ReverseOrderSortedSetView_O_O(t, nil, to)
}
func (t *ReverseOrderSortedSetView) SubSet_O_O__SortedSet(from, to any) SortedSet {
	return ReverseOrderSortedSetView_Subset_New_ReverseOrderSortedSetView_O_O(t, from, to)
}
func (t *ReverseOrderSortedSetView) TailSet_O__SortedSet(from any) SortedSet {
	return ReverseOrderSortedSetView_Subset_New_ReverseOrderSortedSetView_O_O(t, from, nil)
}
func ReverseOrderSortedSetView_DescendingIterator_SortedSet__Iterator(set SortedSet) Iterator {
	return ReverseOrderSortedSetView_1_New_SortedSet(set)
}





func (t *ReverseOrderSortedSetView_1) HasNext__Z() bool { return !t.F_view.IsEmpty__Z() }

func (t *ReverseOrderSortedSetView_1) Next__O() any {
	if t.F_view.IsEmpty__Z() { panic(Thrown(NoSuchElementException_New())) }
	var t_ any; var tmp1 any = t.F_view.Last__O(); t.F_prev = tmp1; t_ = tmp1; t.F_view = t.F_root.HeadSet_O__SortedSet(t_); return t_
}
func (t *ReverseOrderSortedSetView_1) Remove__V() {
	if t.F_prev == nil { panic(Thrown(IllegalStateException_New())) } else { t.F_root.Remove_O__Z(t.F_prev); t.F_prev = nil
	}
}









func ReverseOrderSortedSetView_Subset_New_ReverseOrderSortedSetView_O_O(p0 *ReverseOrderSortedSetView, p1, p2 any) *ReverseOrderSortedSetView_Subset { t := &ReverseOrderSortedSetView_Subset{}; t.Ctor_ReverseOrderSortedSetView_O_O(p0, p1, p2); return t }
//line :148:1
func (t *ReverseOrderSortedSetView_Subset) Ctor_ReverseOrderSortedSetView_O_O(this_0 *ReverseOrderSortedSetView, head, tail any) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t)
	t.F_head = head
	t.F_tail = tail
	var c Comparator = NN(this_0).Comparator__Comparator()
	if c == nil { c = Comparator_NaturalOrder__Comparator() }
	t.F_cmp = c
}
func (t *ReverseOrderSortedSetView_Subset) AboveHead_O__Z(e any) bool {
	var tmp1 bool; tmp1 = t.F_head == nil; if !tmp1 { tmp1 = t.F_cmp.Compare_O_O__I(e, t.F_head) >= 0 }; return tmp1
}
func (t *ReverseOrderSortedSetView_Subset) BelowTail_O__Z(e any) bool {
	var tmp1 bool; tmp1 = t.F_tail == nil; if !tmp1 { tmp1 = t.F_cmp.Compare_O_O__I(e, t.F_tail) < 0 }; return tmp1
}
func (t *ReverseOrderSortedSetView_Subset) Iterator__Iterator() Iterator {
	return ReverseOrderSortedSetView_Subset_1_New_ReverseOrderSortedSetView_Subset(t)
}





func (t *ReverseOrderSortedSetView_Subset_1) HasNext__Z() bool {
	if t.F_dead { return false } else { if !(t.F_cache == nil) { return true } else {




	L1: for { if t.F_it.HasNext__Z() {
		var e any = t.F_it.Next__O()
		if !NN(t.F_this_1).AboveHead_O__Z(e) { } else {
			if NN(t.F_this_1).BelowTail_O__Z(e) { } else { t.F_dead = true; return false }
			t.F_cache = e
			return true }
//line :175:1
		continue L1 }; break L1 }
//line :174:1
		return false
	}
	}
}





func (t *ReverseOrderSortedSetView_Subset_1) Next__O() any {
	if t.HasNext__Z() {
		var e any = t.F_cache; t.F_cache = nil; return e } else {
			panic(Thrown(NoSuchElementException_New()))
		} }
func (t *ReverseOrderSortedSetView_Subset) Add_O__Z(e any) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(e); if tmp2 { tmp2 = t.BelowTail_O__Z(e) }; tmp1 = tmp2; if tmp1 {
		return t.F_this_0.F_base.Add_O__Z(e) } else {
			panic(Thrown(IllegalArgumentException_New()))
		} }
func (t *ReverseOrderSortedSetView_Subset) Remove_O__Z(o any) bool {
	var e any = o; var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(e); if tmp2 { tmp2 = t.BelowTail_O__Z(e) }; tmp1 = tmp2; if tmp1 { return t.F_this_0.F_base.Remove_O__Z(o) } else { return false
	} }
func (t *ReverseOrderSortedSetView_Subset) Size__I() int32 {
	var sz int32 = 0; var i_102015 Iterator = t.Iterator__Iterator(); for i_102015.HasNext__Z() { var e any = i_102015.Next__O(); _ = e; sz = sz + 1 }; return sz
}
func (t *ReverseOrderSortedSetView_Subset) Comparator__Comparator() Comparator {
	return NN(t.F_this_0).Comparator__Comparator()
}
func (t *ReverseOrderSortedSetView_Subset) First__O() any { return t.Iterator__Iterator().Next__O() }

func (t *ReverseOrderSortedSetView_Subset) Last__O() any {
	var it Iterator = t.Iterator__Iterator()
	if it.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	var last any = it.Next__O(); L1: for { if it.HasNext__Z() { last = it.Next__O(); continue L1 }; break L1 }; return last
}
func (t *ReverseOrderSortedSetView_Subset) SubSet_O_O__SortedSet(from, to any) SortedSet {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = t.AboveHead_O__Z(from); if tmp5 { tmp5 = t.BelowTail_O__Z(from) }; tmp4 = tmp5; if tmp4 { tmp4 = t.AboveHead_O__Z(to) }; tmp3 = tmp4; if tmp3 {
		tmp3 = t.BelowTail_O__Z(to) }
//line :210:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = t.F_cmp.Compare_O_O__I(from, to) <= 0 }
//line :210:1
	tmp1 = tmp2; if tmp1 {


		return ReverseOrderSortedSetView_Subset_New_ReverseOrderSortedSetView_O_O(NN(t.F_this_0), from, to) } else {
			panic(Thrown(IllegalArgumentException_New()))
		} }
func (t *ReverseOrderSortedSetView_Subset) HeadSet_O__SortedSet(to any) SortedSet {
	var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(to); if tmp2 { tmp2 = t.BelowTail_O__Z(to) }; tmp1 = tmp2; if tmp1 {
		return ReverseOrderSortedSetView_Subset_New_ReverseOrderSortedSetView_O_O(NN(t.F_this_0), t.F_head, to) } else {
			panic(Thrown(IllegalArgumentException_New()))
		} }
func (t *ReverseOrderSortedSetView_Subset) TailSet_O__SortedSet(from any) SortedSet {
	var tmp1 bool; var tmp2 bool; tmp2 = t.AboveHead_O__Z(from); if tmp2 { tmp2 = t.BelowTail_O__Z(from) }; tmp1 = tmp2; if tmp1 {
		return ReverseOrderSortedSetView_Subset_New_ReverseOrderSortedSetView_O_O(NN(t.F_this_0), nil, t.F_tail) } else {
			panic(Thrown(IllegalArgumentException_New()))
		}
}

type ReverseOrderSortedSetView struct{ Object; F_base SortedSet; F_comp Comparator }

func (t *ReverseOrderSortedSetView) Is_SortedSet() {}

func (t *ReverseOrderSortedSetView) Is_Set() {}

func (t *ReverseOrderSortedSetView) Is_SequencedSet() {}

func (t *ReverseOrderSortedSetView) Is_Collection() {}

func (t *ReverseOrderSortedSetView) Is_SequencedCollection() {}

func (t *ReverseOrderSortedSetView) Is_Iterable() {}

func (t *ReverseOrderSortedSetView) Reversed__SequencedSet() SequencedSet { return SortedSet_Reversed__SequencedSet(t) }

func (t *ReverseOrderSortedSetView) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderSortedSetView) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *ReverseOrderSortedSetView) Reversed__SequencedCollection() SequencedCollection { return SortedSet_Reversed__SequencedCollection(t) }

func (t *ReverseOrderSortedSetView) Reversed__SortedSet() SortedSet { return SortedSet_Reversed__SortedSet(t) }

func (t *ReverseOrderSortedSetView) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *ReverseOrderSortedSetView) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *ReverseOrderSortedSetView) RemoveLast__O() any { return SortedSet_RemoveLast__O(t) }

func (t *ReverseOrderSortedSetView) RemoveFirst__O() any { return SortedSet_RemoveFirst__O(t) }

func (t *ReverseOrderSortedSetView) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *ReverseOrderSortedSetView) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedSetView) GetClass__Class() *Class { return ReverseOrderSortedSetView_class }

func (t *ReverseOrderSortedSetView) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedSetView) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedSetView_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedSetView); return ok }

func ReverseOrderSortedSetView_Cast(x any) *ReverseOrderSortedSetView { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedSetView); if !ok { panic(ClassCast(x, ReverseOrderSortedSetView_class)) }; return v }



type ReverseOrderSortedSetView_1 struct{ Object; F_root, F_view SortedSet; F_prev any; F_val_set SortedSet }

func (t *ReverseOrderSortedSetView_1) Is_Iterator() {}

func ReverseOrderSortedSetView_1_New_SortedSet(p0 SortedSet) *ReverseOrderSortedSetView_1 { t := &ReverseOrderSortedSetView_1{}; t.Ctor_SortedSet(p0); return t }

func (t *ReverseOrderSortedSetView_1) Ctor_SortedSet(val_set SortedSet) { t.F_val_set = val_set; t.F_root = t.F_val_set; t.F_view = t.F_val_set; t.F_prev = nil }

func (t *ReverseOrderSortedSetView_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderSortedSetView_1) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedSetView_1) GetClass__Class() *Class { return ReverseOrderSortedSetView_1_class }

func (t *ReverseOrderSortedSetView_1) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderSortedSetView_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedSetView_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedSetView_1_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedSetView_1); return ok }

func ReverseOrderSortedSetView_1_Cast(x any) *ReverseOrderSortedSetView_1 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedSetView_1); if !ok { panic(ClassCast(x, ReverseOrderSortedSetView_1_class)) }; return v }



type ReverseOrderSortedSetView_Subset struct{ AbstractSet; F_head, F_tail any; F_cmp Comparator; F_this_0 *ReverseOrderSortedSetView }

func (t *ReverseOrderSortedSetView_Subset) Is_SortedSet() {}

func (t *ReverseOrderSortedSetView_Subset) Is_SequencedSet() {}

func (t *ReverseOrderSortedSetView_Subset) Is_SequencedCollection() {}

func (t *ReverseOrderSortedSetView_Subset) Reversed__SequencedSet() SequencedSet { return SortedSet_Reversed__SequencedSet(t) }

func (t *ReverseOrderSortedSetView_Subset) Spliterator__Spliterator() Spliterator { return SortedSet_Spliterator__Spliterator(t) }

func (t *ReverseOrderSortedSetView_Subset) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) Clear__V() { t.Impl_Clear__V(t) }

func (t *ReverseOrderSortedSetView_Subset) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *ReverseOrderSortedSetView_Subset) Reversed__SequencedCollection() SequencedCollection { return SortedSet_Reversed__SequencedCollection(t) }

func (t *ReverseOrderSortedSetView_Subset) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) Reversed__SortedSet() SortedSet { return SortedSet_Reversed__SortedSet(t) }

func (t *ReverseOrderSortedSetView_Subset) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ReverseOrderSortedSetView_Subset) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ReverseOrderSortedSetView_Subset) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *ReverseOrderSortedSetView_Subset) RemoveLast__O() any { return SortedSet_RemoveLast__O(t) }

func (t *ReverseOrderSortedSetView_Subset) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderSortedSetView_Subset) RemoveFirst__O() any { return SortedSet_RemoveFirst__O(t) }

func (t *ReverseOrderSortedSetView_Subset) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ReverseOrderSortedSetView_Subset) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderSortedSetView_Subset) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderSortedSetView_Subset) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReverseOrderSortedSetView_Subset) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedSetView_Subset) GetClass__Class() *Class { return ReverseOrderSortedSetView_Subset_class }

func (t *ReverseOrderSortedSetView_Subset) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedSetView_Subset) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedSetView_Subset_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedSetView_Subset); return ok }

func ReverseOrderSortedSetView_Subset_Cast(x any) *ReverseOrderSortedSetView_Subset { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedSetView_Subset); if !ok { panic(ClassCast(x, ReverseOrderSortedSetView_Subset_class)) }; return v }



type ReverseOrderSortedSetView_Subset_1 struct{ Object; F_cache any; F_dead bool; F_it Iterator; F_this_1 *ReverseOrderSortedSetView_Subset }

func (t *ReverseOrderSortedSetView_Subset_1) Is_Iterator() {}

func ReverseOrderSortedSetView_Subset_1_New_ReverseOrderSortedSetView_Subset(p0 *ReverseOrderSortedSetView_Subset) *ReverseOrderSortedSetView_Subset_1 { t := &ReverseOrderSortedSetView_Subset_1{}; t.Ctor_ReverseOrderSortedSetView_Subset(p0); return t }

func (t *ReverseOrderSortedSetView_Subset_1) Ctor_ReverseOrderSortedSetView_Subset(this_0 *ReverseOrderSortedSetView_Subset) { NN(this_0); t.F_this_1 = this_0; t.F_cache = nil; t.F_dead = false; t.F_it = ReverseOrderSortedSetView_DescendingIterator_SortedSet__Iterator(this_0.F_this_0.F_base) }

func (t *ReverseOrderSortedSetView_Subset_1) Remove__V() { Iterator_Remove__V(t) }

func (t *ReverseOrderSortedSetView_Subset_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderSortedSetView_Subset_1) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderSortedSetView_Subset_1) GetClass__Class() *Class { return ReverseOrderSortedSetView_Subset_1_class }

func (t *ReverseOrderSortedSetView_Subset_1) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderSortedSetView_Subset_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderSortedSetView_Subset_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderSortedSetView_Subset_1_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderSortedSetView_Subset_1); return ok }

func ReverseOrderSortedSetView_Subset_1_Cast(x any) *ReverseOrderSortedSetView_Subset_1 { if x == nil { return nil }; v, ok := x.(*ReverseOrderSortedSetView_Subset_1); if !ok { panic(ClassCast(x, ReverseOrderSortedSetView_Subset_1_class)) }; return v }
