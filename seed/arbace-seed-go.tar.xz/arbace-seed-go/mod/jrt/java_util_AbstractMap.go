//line java_util_AbstractMap.ae:1
package jrt












func (t *AbstractMap) Ctor(this AbstractMap_I) {}

func (t *AbstractMap) Impl_Size__I(this AbstractMap_I) int32 { return this.EntrySet__Set().Size__I() }

func (t *AbstractMap) Impl_IsEmpty__Z(this AbstractMap_I) bool { return this.Size__I() == 0 }

func (t *AbstractMap) Impl_ContainsValue_O__Z(this AbstractMap_I, value any) bool {
	var i Iterator = this.EntrySet__Set().Iterator__Iterator()
	if value == nil {
	L1: for { if i.HasNext__Z() {
		var e Map_Entry = Map_Entry_Cast(i.Next__O())
		if e.GetValue__O() == nil { return true }
//line :23:1
		continue L1 }; break L1
	} } else {

	L2: for { if i.HasNext__Z() {
		var e_2 Map_Entry = Map_Entry_Cast(i.Next__O())
		if Equals(value, e_2.GetValue__O()) { return true }
//line :26:1
		continue L2 }; break L2 } }
//line :21:1
	return false
}








func (t *AbstractMap) Impl_ContainsKey_O__Z(this AbstractMap_I, key any) bool {
	var i Iterator = this.EntrySet__Set().Iterator__Iterator()
	if key == nil {
	L1: for { if i.HasNext__Z() {
		var e Map_Entry = Map_Entry_Cast(i.Next__O())
		if e.GetKey__O() == nil { return true }
//line :34:1
		continue L1 }; break L1
	} } else {

	L2: for { if i.HasNext__Z() {
		var e_2 Map_Entry = Map_Entry_Cast(i.Next__O())
		if Equals(key, e_2.GetKey__O()) { return true }
//line :37:1
		continue L2 }; break L2 } }
//line :32:1
	return false
}








func (t *AbstractMap) Impl_Get_O__O(this AbstractMap_I, key any) any {
	var i Iterator = this.EntrySet__Set().Iterator__Iterator()
	if key == nil {
	L1: for { if i.HasNext__Z() {
		var e Map_Entry = Map_Entry_Cast(i.Next__O())
		if e.GetKey__O() == nil { return e.GetValue__O() }
//line :45:1
		continue L1 }; break L1
	} } else {

	L2: for { if i.HasNext__Z() {
		var e_2 Map_Entry = Map_Entry_Cast(i.Next__O())
		if Equals(key, e_2.GetKey__O()) { return e_2.GetValue__O() }
//line :48:1
		continue L2 }; break L2 } }
//line :43:1
	return nil
}








func (t *AbstractMap) Impl_Put_O_O__O(this AbstractMap_I, key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *AbstractMap) Impl_Remove_O__O(this AbstractMap_I, key any) any {
	var i Iterator = this.EntrySet__Set().Iterator__Iterator(); var correctEntry Map_Entry

	if key == nil {
	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = correctEntry == nil; if tmp2 { tmp2 = i.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		var e Map_Entry = Map_Entry_Cast(i.Next__O())
		if e.GetKey__O() == nil { correctEntry = e }
//line :60:1
		continue L1 }; break L1
	} } else {

	L2: for { var tmp3 bool; var tmp4 bool; tmp4 = correctEntry == nil; if tmp4 { tmp4 = i.HasNext__Z() }; tmp3 = tmp4; if tmp3 {
		var e_2 Map_Entry = Map_Entry_Cast(i.Next__O())
		if Equals(key, e_2.GetKey__O()) { correctEntry = e_2 }
//line :63:1
		continue L2 }; break L2
	}
	}
	var oldValue any
	if !(correctEntry == nil) { oldValue = correctEntry.GetValue__O(); i.Remove__V() }
//line :66:1
	return oldValue
}


func (t *AbstractMap) Impl_PutAll_Map__V(this AbstractMap_I, m Map) {
	var i_101724 Iterator = m.EntrySet__Set().Iterator__Iterator(); for i_101724.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101724.Next__O())
		this.Put_O_O__O(e.GetKey__O(), e.GetValue__O())
	} }
func (t *AbstractMap) Impl_Clear__V(this AbstractMap_I) { this.EntrySet__Set().Clear__V() }





func (t *AbstractMap) Impl_KeySet__Set(this AbstractMap_I) Set {
	var ks Set = t.F_keySet
	if ks == nil {
		ks = AbstractMap_1_New_AbstractMap(this)











		t.F_keySet = ks }
//line :81:1
	return ks
}


func (t *AbstractMap_1) Iterator__Iterator() Iterator { return AbstractMap_KeyIterator_New_AbstractMap(t.F_this_0) }

func (t *AbstractMap_1) Size__I() int32 { return t.F_this_0.Size__I() }

func (t *AbstractMap_1) IsEmpty__Z() bool { return t.F_this_0.IsEmpty__Z() }

func (t *AbstractMap_1) Clear__V() { t.F_this_0.Clear__V() }

func (t *AbstractMap_1) Contains_O__Z(k any) bool {
	return t.F_this_0.ContainsKey_O__Z(k)
}


func (t *AbstractMap) Impl_Values__Collection(this AbstractMap_I) Collection {
	var vals Collection = t.F_values
	if vals == nil {
		vals = AbstractMap_2_New_AbstractMap(this)











		t.F_values = vals }
//line :99:1
	return vals
}


func (t *AbstractMap_2) Iterator__Iterator() Iterator { return AbstractMap_ValueIterator_New_AbstractMap(t.F_this_0) }

func (t *AbstractMap_2) Size__I() int32 { return t.F_this_0.Size__I() }

func (t *AbstractMap_2) IsEmpty__Z() bool { return t.F_this_0.IsEmpty__Z() }

func (t *AbstractMap_2) Clear__V() { t.F_this_0.Clear__V() }

func (t *AbstractMap_2) Contains_O__Z(v any) bool {
	return t.F_this_0.ContainsValue_O__Z(v)
}




func (t *AbstractMap) Impl_Equals_O__Z(this AbstractMap_I, o any) bool {
	if any(o) == any(this) { return true } else {

		var tmp1 any = o; if Map_InstanceOf(tmp1) { var m Map = Map_Cast(tmp1)
			if !(m.Size__I() == this.Size__I()) { return false } else { tmp4, tmp5, tmp6 := func() (ctl int32, rv bool, exc Throwable_I) { defer Catch(&exc)



				{ var i_101726 Iterator = this.EntrySet__Set().Iterator__Iterator(); for i_101726.HasNext__Z() { var e Map_Entry = Map_Entry_Cast(i_101726.Next__O()); var key any = e.GetKey__O(); var value any = e.GetValue__O()


					if value == nil {
						var tmp2 bool; var tmp3 bool; tmp3 = m.Get_O__O(key) == nil; if tmp3 { tmp3 = m.ContainsKey_O__Z(key) }; tmp2 = tmp3; if tmp2 { } else { return 2, false, nil } } else {
							if Equals(value, m.Get_O__O(key)) { } else { return 3, false, nil } } } }; return 0, false, nil }()
//line :125:1
				if tmp6 != nil { if ClassCastException_InstanceOf(tmp6) || NullPointerException_InstanceOf(tmp6) { var unused RuntimeException_I = RuntimeException_Cast(tmp6); _ = unused






					return false } else {
//line :125:1
						panic(tmp6) } }; switch tmp4 { case 2: { return tmp5 }; case 3: { return tmp5 }}
//line :124:1
				return true
			}




		} else {
//line :121:1
			return false
		}
	}
}











func (t *AbstractMap) Impl_HashCode__I(this AbstractMap_I) int32 {
	var h int32 = 0; var i_101727 Iterator = this.EntrySet__Set().Iterator__Iterator(); for i_101727.HasNext__Z() {
		var entry Map_Entry = Map_Entry_Cast(i_101727.Next__O())
		h = h + entry.HashCode__I() }
//line :137:1
	return h
}



func (t *AbstractMap) Impl_ToString__String(this AbstractMap_I) *String {
	{ var i Iterator = this.EntrySet__Set().Iterator__Iterator()
		if !i.HasNext__Z() { return Lit_2597 } else {

			var sb *StringBuilder = StringBuilder_New()
			NN(sb).Append_C__StringBuilder(123)
		L1: for {
			var e Map_Entry = Map_Entry_Cast(i.Next__O()); var key any = e.GetKey__O(); var value any = e.GetValue__O(); var tmp1 any


			if any(key) == any(this) { tmp1 = Lit_2598 } else { tmp1 = key }; NN(sb).Append_O__StringBuilder(tmp1)
			NN(sb).Append_C__StringBuilder(61)
			var tmp2 any; if any(value) == any(this) { tmp2 = Lit_2598 } else { tmp2 = value }; NN(sb).Append_O__StringBuilder(tmp2)
			if i.HasNext__Z() { } else { return NN(NN(sb).Append_C__StringBuilder(125)).ToString__String() }
			NN(NN(sb).Append_C__StringBuilder(44)).Append_C__StringBuilder(32)
//line :148:1
			continue L1
		}
		}
	}




	panic("a2g: unreachable")
}
func (t *AbstractMap) Impl_Clone__O(this AbstractMap_I) any {
	var result AbstractMap_I = AbstractMap_Cast(A2g_ObjectClone(this))
	result.Self_AbstractMap().F_keySet = nil
	result.Self_AbstractMap().F_values = nil
//line :159:1
	return result
}



func AbstractMap_Eq_O_O__Z(o1, o2 any) bool {
	if o1 == nil { return o2 == nil } else { return Equals(o1, o2)
	}
}









func AbstractMap_SimpleEntry_New_O_O(p0, p1 any) *AbstractMap_SimpleEntry { t := &AbstractMap_SimpleEntry{}; t.Ctor_O_O(p0, p1); return t }
//line :177:1
func (t *AbstractMap_SimpleEntry) Ctor_O_O(key, value any) {
	t.F_key = key
	t.F_value = value
}
func AbstractMap_SimpleEntry_New_Map_Entry(p0 Map_Entry) *AbstractMap_SimpleEntry { t := &AbstractMap_SimpleEntry{}; t.Ctor_Map_Entry(p0); return t }
//line :181:1
func (t *AbstractMap_SimpleEntry) Ctor_Map_Entry(entry Map_Entry) {
	t.F_key = entry.GetKey__O()
	t.F_value = entry.GetValue__O()
}
func (t *AbstractMap_SimpleEntry) GetKey__O() any { return t.F_key }

func (t *AbstractMap_SimpleEntry) GetValue__O() any { return t.F_value }

func (t *AbstractMap_SimpleEntry) SetValue_O__O(value any) any {
	var oldValue any = t.F_value; t.F_value = value; return oldValue
}
func (t *AbstractMap_SimpleEntry) Equals_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var tmp2 any = t.F_key
		if AbstractMap_Eq_O_O__Z(tmp2, e.GetKey__O()) { var tmp3 any = t.F_value; return AbstractMap_Eq_O_O__Z(tmp3, e.GetValue__O()) } else { return false } } else {
//line :193:1
			return false
		}
}

func (t *AbstractMap_SimpleEntry) HashCode__I() int32 {
	var tmp1 int32; if t.F_key == nil { tmp1 = 0 } else { tmp1 = HashCode(t.F_key) }; var tmp2 int32 = tmp1; var tmp3 int32; if t.F_value == nil { tmp3 = 0 } else { tmp3 = HashCode(t.F_value) }; return tmp2 ^ tmp3
}
func (t *AbstractMap_SimpleEntry) ToString__String() *String { return Concat(StrOfObj(t.F_key), Lit_1171, StrOfObj(t.F_value)) }











func AbstractMap_SimpleImmutableEntry_New_O_O(p0, p1 any) *AbstractMap_SimpleImmutableEntry { t := &AbstractMap_SimpleImmutableEntry{}; t.Ctor_O_O(p0, p1); return t }
//line :212:1
func (t *AbstractMap_SimpleImmutableEntry) Ctor_O_O(key, value any) {
	t.F_key = key
	t.F_value = value
}
func AbstractMap_SimpleImmutableEntry_New_Map_Entry(p0 Map_Entry) *AbstractMap_SimpleImmutableEntry { t := &AbstractMap_SimpleImmutableEntry{}; t.Ctor_Map_Entry(p0); return t }
//line :216:1
func (t *AbstractMap_SimpleImmutableEntry) Ctor_Map_Entry(entry Map_Entry) {
	t.F_key = entry.GetKey__O()
	t.F_value = entry.GetValue__O()
}
func (t *AbstractMap_SimpleImmutableEntry) GetKey__O() any { return t.F_key }

func (t *AbstractMap_SimpleImmutableEntry) GetValue__O() any { return t.F_value }

func (t *AbstractMap_SimpleImmutableEntry) SetValue_O__O(value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *AbstractMap_SimpleImmutableEntry) Equals_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var tmp2 any = t.F_key
		if AbstractMap_Eq_O_O__Z(tmp2, e.GetKey__O()) { var tmp3 any = t.F_value; return AbstractMap_Eq_O_O__Z(tmp3, e.GetValue__O()) } else { return false } } else {
//line :228:1
			return false
		}
}

func (t *AbstractMap_SimpleImmutableEntry) HashCode__I() int32 {
	var tmp1 int32; if t.F_key == nil { tmp1 = 0 } else { tmp1 = HashCode(t.F_key) }; var tmp2 int32 = tmp1; var tmp3 int32; if t.F_value == nil { tmp3 = 0 } else { tmp3 = HashCode(t.F_value) }; return tmp2 ^ tmp3
}
func (t *AbstractMap_SimpleImmutableEntry) ToString__String() *String { return Concat(StrOfObj(t.F_key), Lit_1171, StrOfObj(t.F_value)) }





func (t *AbstractMap_ViewCollection) Impl_Uoe__UnsupportedOperationException(this AbstractMap_ViewCollection_I) UnsupportedOperationException_I {
	return UnsupportedOperationException_New()
}
func AbstractMap_ViewCollection_Nsee_Map_Entry__Map_Entry(entry Map_Entry) Map_Entry {
	if entry == nil { panic(Thrown(NoSuchElementException_New())) } else { return entry
	}
}

func (t *AbstractMap_ViewCollection) Impl_Add_O__Z(this AbstractMap_ViewCollection_I, t_ any) bool { panic(Thrown(this.Uoe__UnsupportedOperationException())) }

func (t *AbstractMap_ViewCollection) Impl_AddAll_Collection__Z(this AbstractMap_ViewCollection_I, c Collection) bool {
	panic(Thrown(this.Uoe__UnsupportedOperationException()))
}
func (t *AbstractMap_ViewCollection) Impl_Clear__V(this AbstractMap_ViewCollection_I) { this.View__Collection().Clear__V() }

func (t *AbstractMap_ViewCollection) Impl_Contains_O__Z(this AbstractMap_ViewCollection_I, o any) bool { return this.View__Collection().Contains_O__Z(o) }

func (t *AbstractMap_ViewCollection) Impl_ContainsAll_Collection__Z(this AbstractMap_ViewCollection_I, c Collection) bool {
	return this.View__Collection().ContainsAll_Collection__Z(c)
}
func (t *AbstractMap_ViewCollection) Impl_ForEach_Consumer__V(this AbstractMap_ViewCollection_I, c Consumer) {
	this.View__Collection().ForEach_Consumer__V(c)
}
func (t *AbstractMap_ViewCollection) Impl_IsEmpty__Z(this AbstractMap_ViewCollection_I) bool { return this.View__Collection().IsEmpty__Z() }

func (t *AbstractMap_ViewCollection) Impl_Iterator__Iterator(this AbstractMap_ViewCollection_I) Iterator {
	return this.View__Collection().Iterator__Iterator()
}
func (t *AbstractMap_ViewCollection) Impl_ParallelStream__Stream(this AbstractMap_ViewCollection_I) Stream {
	return this.View__Collection().ParallelStream__Stream()
}
func (t *AbstractMap_ViewCollection) Impl_Remove_O__Z(this AbstractMap_ViewCollection_I, o any) bool { return this.View__Collection().Remove_O__Z(o) }

func (t *AbstractMap_ViewCollection) Impl_RemoveAll_Collection__Z(this AbstractMap_ViewCollection_I, c Collection) bool {
	return this.View__Collection().RemoveAll_Collection__Z(c)
}
func (t *AbstractMap_ViewCollection) Impl_RemoveIf_Predicate__Z(this AbstractMap_ViewCollection_I, filter Predicate) bool {
	return this.View__Collection().RemoveIf_Predicate__Z(filter)
}
func (t *AbstractMap_ViewCollection) Impl_RetainAll_Collection__Z(this AbstractMap_ViewCollection_I, c Collection) bool {
	return this.View__Collection().RetainAll_Collection__Z(c)
}
func (t *AbstractMap_ViewCollection) Impl_Size__I(this AbstractMap_ViewCollection_I) int32 { return this.View__Collection().Size__I() }

func (t *AbstractMap_ViewCollection) Impl_Spliterator__Spliterator(this AbstractMap_ViewCollection_I) Spliterator {
	return this.View__Collection().Spliterator__Spliterator()
}
func (t *AbstractMap_ViewCollection) Impl_Stream__Stream(this AbstractMap_ViewCollection_I) Stream {
	return this.View__Collection().Stream__Stream()
}
func (t *AbstractMap_ViewCollection) Impl_ToArray__O1(this AbstractMap_ViewCollection_I) *RefArray { return this.View__Collection().ToArray__O1() }

func (t *AbstractMap_ViewCollection) Impl_ToArray_IntFunction__O1(this AbstractMap_ViewCollection_I, generator IntFunction) *RefArray {
	return this.View__Collection().ToArray_IntFunction__O1(generator)
}
func (t *AbstractMap_ViewCollection) Impl_ToArray_O1__O1(this AbstractMap_ViewCollection_I, a *RefArray) *RefArray {
	return this.View__Collection().ToArray_O1__O1(a)
}
func (t *AbstractMap_ViewCollection) Impl_ToString__String(this AbstractMap_ViewCollection_I) *String { return this.View__Collection().ToString__String() }







func (t *AbstractMap_KeyIterator) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *AbstractMap_KeyIterator) Remove__V() { t.F_i.Remove__V() }

func (t *AbstractMap_KeyIterator) Next__O() any { return Map_Entry_Cast(t.F_i.Next__O()).GetKey__O() }







func (t *AbstractMap_ValueIterator) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *AbstractMap_ValueIterator) Remove__V() { t.F_i.Remove__V() }

func (t *AbstractMap_ValueIterator) Next__O() any { return Map_Entry_Cast(t.F_i.Next__O()).GetValue__O() }



type AbstractMap struct{ Object; F_keySet Set; F_values Collection }

type AbstractMap_I interface{ Object_I; Map; Self_AbstractMap() *AbstractMap; Size__I() int32; IsEmpty__Z() bool; ContainsValue_O__Z(p0 any) bool; ContainsKey_O__Z(p0 any) bool; Get_O__O(p0 any) any; Put_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; PutAll_Map__V(p0 Map); Clear__V(); KeySet__Set() Set; Values__Collection() Collection; EntrySet__Set() Set }

func (t *AbstractMap) Self_AbstractMap() *AbstractMap { return t }

func (t *AbstractMap) Is_Map() {}

func AbstractMap_InstanceOf(x any) bool { _, ok := x.(AbstractMap_I); return ok }

func AbstractMap_Cast(x any) AbstractMap_I { if x == nil { return nil }; v, ok := x.(AbstractMap_I); if !ok { panic(ClassCast(x, AbstractMap_class)) }; return v }



type AbstractMap_1 struct{ AbstractSet; F_this_0 AbstractMap_I }

func AbstractMap_1_New_AbstractMap(p0 AbstractMap_I) *AbstractMap_1 { t := &AbstractMap_1{}; t.Ctor_AbstractMap(p0); return t }

func (t *AbstractMap_1) Ctor_AbstractMap(this_0 AbstractMap_I) { A2g_NotNull[AbstractMap_I](this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *AbstractMap_1) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *AbstractMap_1) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *AbstractMap_1) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *AbstractMap_1) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *AbstractMap_1) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *AbstractMap_1) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *AbstractMap_1) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *AbstractMap_1) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *AbstractMap_1) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *AbstractMap_1) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *AbstractMap_1) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *AbstractMap_1) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *AbstractMap_1) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *AbstractMap_1) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *AbstractMap_1) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *AbstractMap_1) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *AbstractMap_1) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AbstractMap_1) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractMap_1) GetClass__Class() *Class { return AbstractMap_1_class }

func (t *AbstractMap_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractMap_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractMap_1_InstanceOf(x any) bool { _, ok := x.(*AbstractMap_1); return ok }

func AbstractMap_1_Cast(x any) *AbstractMap_1 { if x == nil { return nil }; v, ok := x.(*AbstractMap_1); if !ok { panic(ClassCast(x, AbstractMap_1_class)) }; return v }



type AbstractMap_2 struct{ AbstractCollection; F_this_0 AbstractMap_I }

func AbstractMap_2_New_AbstractMap(p0 AbstractMap_I) *AbstractMap_2 { t := &AbstractMap_2{}; t.Ctor_AbstractMap(p0); return t }

func (t *AbstractMap_2) Ctor_AbstractMap(this_0 AbstractMap_I) { A2g_NotNull[AbstractMap_I](this_0); t.F_this_0 = this_0; t.AbstractCollection.Ctor(t) }

func (t *AbstractMap_2) Spliterator__Spliterator() Spliterator { return Collection_Spliterator__Spliterator(t) }

func (t *AbstractMap_2) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *AbstractMap_2) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *AbstractMap_2) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *AbstractMap_2) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *AbstractMap_2) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *AbstractMap_2) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *AbstractMap_2) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *AbstractMap_2) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *AbstractMap_2) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *AbstractMap_2) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *AbstractMap_2) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *AbstractMap_2) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *AbstractMap_2) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *AbstractMap_2) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AbstractMap_2) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractMap_2) GetClass__Class() *Class { return AbstractMap_2_class }

func (t *AbstractMap_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractMap_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractMap_2_InstanceOf(x any) bool { _, ok := x.(*AbstractMap_2); return ok }

func AbstractMap_2_Cast(x any) *AbstractMap_2 { if x == nil { return nil }; v, ok := x.(*AbstractMap_2); if !ok { panic(ClassCast(x, AbstractMap_2_class)) }; return v }



type AbstractMap_KeyIterator struct{ Object; F_i Iterator; F_this_0 AbstractMap_I }

func (t *AbstractMap_KeyIterator) Is_Iterator() {}

func AbstractMap_KeyIterator_New_AbstractMap(p0 AbstractMap_I) *AbstractMap_KeyIterator { t := &AbstractMap_KeyIterator{}; t.Ctor_AbstractMap(p0); return t }

func (t *AbstractMap_KeyIterator) Ctor_AbstractMap(this_0 AbstractMap_I) { A2g_NotNull[AbstractMap_I](this_0); t.F_this_0 = this_0; t.F_i = this_0.EntrySet__Set().Iterator__Iterator() }

func (t *AbstractMap_KeyIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *AbstractMap_KeyIterator) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractMap_KeyIterator) GetClass__Class() *Class { return AbstractMap_KeyIterator_class }

func (t *AbstractMap_KeyIterator) ToString__String() *String { return Object_toString(t) }

func (t *AbstractMap_KeyIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractMap_KeyIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractMap_KeyIterator_InstanceOf(x any) bool { _, ok := x.(*AbstractMap_KeyIterator); return ok }

func AbstractMap_KeyIterator_Cast(x any) *AbstractMap_KeyIterator { if x == nil { return nil }; v, ok := x.(*AbstractMap_KeyIterator); if !ok { panic(ClassCast(x, AbstractMap_KeyIterator_class)) }; return v }



type AbstractMap_SimpleEntry struct{ Object; F_key, F_value any }

func (t *AbstractMap_SimpleEntry) Is_Map_Entry() {}

func (t *AbstractMap_SimpleEntry) Is_Serializable() {}

const AbstractMap_SimpleEntry_serialVersionUID int64 = -8499721149061103585

func (t *AbstractMap_SimpleEntry) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractMap_SimpleEntry) GetClass__Class() *Class { return AbstractMap_SimpleEntry_class }

func (t *AbstractMap_SimpleEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractMap_SimpleEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractMap_SimpleEntry_InstanceOf(x any) bool { _, ok := x.(*AbstractMap_SimpleEntry); return ok }

func AbstractMap_SimpleEntry_Cast(x any) *AbstractMap_SimpleEntry { if x == nil { return nil }; v, ok := x.(*AbstractMap_SimpleEntry); if !ok { panic(ClassCast(x, AbstractMap_SimpleEntry_class)) }; return v }



type AbstractMap_SimpleImmutableEntry struct{ Object; F_key, F_value any }

func (t *AbstractMap_SimpleImmutableEntry) Is_Map_Entry() {}

func (t *AbstractMap_SimpleImmutableEntry) Is_Serializable() {}

const AbstractMap_SimpleImmutableEntry_serialVersionUID int64 = 7138329143949025153

func (t *AbstractMap_SimpleImmutableEntry) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractMap_SimpleImmutableEntry) GetClass__Class() *Class { return AbstractMap_SimpleImmutableEntry_class }

func (t *AbstractMap_SimpleImmutableEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractMap_SimpleImmutableEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractMap_SimpleImmutableEntry_InstanceOf(x any) bool { _, ok := x.(*AbstractMap_SimpleImmutableEntry); return ok }

func AbstractMap_SimpleImmutableEntry_Cast(x any) *AbstractMap_SimpleImmutableEntry { if x == nil { return nil }; v, ok := x.(*AbstractMap_SimpleImmutableEntry); if !ok { panic(ClassCast(x, AbstractMap_SimpleImmutableEntry_class)) }; return v }



type AbstractMap_ValueIterator struct{ Object; F_i Iterator; F_this_0 AbstractMap_I }

func (t *AbstractMap_ValueIterator) Is_Iterator() {}

func AbstractMap_ValueIterator_New_AbstractMap(p0 AbstractMap_I) *AbstractMap_ValueIterator { t := &AbstractMap_ValueIterator{}; t.Ctor_AbstractMap(p0); return t }

func (t *AbstractMap_ValueIterator) Ctor_AbstractMap(this_0 AbstractMap_I) { A2g_NotNull[AbstractMap_I](this_0); t.F_this_0 = this_0; t.F_i = this_0.EntrySet__Set().Iterator__Iterator() }

func (t *AbstractMap_ValueIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *AbstractMap_ValueIterator) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractMap_ValueIterator) GetClass__Class() *Class { return AbstractMap_ValueIterator_class }

func (t *AbstractMap_ValueIterator) ToString__String() *String { return Object_toString(t) }

func (t *AbstractMap_ValueIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractMap_ValueIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractMap_ValueIterator_InstanceOf(x any) bool { _, ok := x.(*AbstractMap_ValueIterator); return ok }

func AbstractMap_ValueIterator_Cast(x any) *AbstractMap_ValueIterator { if x == nil { return nil }; v, ok := x.(*AbstractMap_ValueIterator); if !ok { panic(ClassCast(x, AbstractMap_ValueIterator_class)) }; return v }



type AbstractMap_ViewCollection struct{ Object }

type AbstractMap_ViewCollection_I interface{ Object_I; Collection; Iterable; Self_AbstractMap_ViewCollection() *AbstractMap_ViewCollection; Uoe__UnsupportedOperationException() UnsupportedOperationException_I; View__Collection() Collection; Add_O__Z(p0 any) bool; AddAll_Collection__Z(p0 Collection) bool; Clear__V(); Contains_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; ForEach_Consumer__V(p0 Consumer); IsEmpty__Z() bool; Iterator__Iterator() Iterator; ParallelStream__Stream() Stream; Remove_O__Z(p0 any) bool; RemoveAll_Collection__Z(p0 Collection) bool; RemoveIf_Predicate__Z(p0 Predicate) bool; RetainAll_Collection__Z(p0 Collection) bool; Size__I() int32; Spliterator__Spliterator() Spliterator; Stream__Stream() Stream; ToArray__O1() *RefArray; ToArray_IntFunction__O1(p0 IntFunction) *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray }

func (t *AbstractMap_ViewCollection) Self_AbstractMap_ViewCollection() *AbstractMap_ViewCollection { return t }

func (t *AbstractMap_ViewCollection) Is_Collection() {}

func (t *AbstractMap_ViewCollection) Is_Iterable() {}

func (t *AbstractMap_ViewCollection) Ctor(this AbstractMap_ViewCollection_I) {}

func AbstractMap_ViewCollection_InstanceOf(x any) bool { _, ok := x.(AbstractMap_ViewCollection_I); return ok }

func AbstractMap_ViewCollection_Cast(x any) AbstractMap_ViewCollection_I { if x == nil { return nil }; v, ok := x.(AbstractMap_ViewCollection_I); if !ok { panic(ClassCast(x, AbstractMap_ViewCollection_class)) }; return v }
