//line java_lang_ProcessHandle.ae:1
package jrt













func ProcessHandle_Of_J__Optional(pid int64) *Optional {
	return ProcessHandleImpl_Get_J__Optional(pid)
}
func ProcessHandle_Current__ProcessHandle() ProcessHandle { return Up_ProcessHandleImpl_ProcessHandle(ProcessHandleImpl_Current__ProcessHandleImpl()) }







func ProcessHandle_AllProcesses__Stream() Stream {
	return ProcessHandleImpl_Children_J__Stream(0)
}


type ProcessHandle interface{ Object_I; Comparable; Is_ProcessHandle(); Pid__J() int64; Parent__Optional() *Optional; Children__Stream() Stream; Descendants__Stream() Stream; Info__ProcessHandle_Info() ProcessHandle_Info; OnExit__CompletableFuture() CompletableFuture_I; SupportsNormalTermination__Z() bool; Destroy__Z() bool; DestroyForcibly__Z() bool; IsAlive__Z() bool; CompareTo_ProcessHandle__I(p0 ProcessHandle) int32; CompareTo_O__I(p0 any) int32 }

func ProcessHandle_CompareTo_O__I(this ProcessHandle, p0 any) int32 { return this.CompareTo_ProcessHandle__I(ProcessHandle_Cast(p0)) }

func ProcessHandle_InstanceOf(x any) bool { _, ok := x.(ProcessHandle); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ProcessHandle_class) } }; return ok }

func ProcessHandle_Cast(x any) ProcessHandle { if x == nil { return nil }; v, ok := x.(ProcessHandle); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ProcessHandle_class) } }; if !ok { panic(ClassCast(x, ProcessHandle_class)) }; return v }



type ProcessHandle_Info interface{ Object_I; Is_ProcessHandle_Info(); Command__Optional() *Optional; CommandLine__Optional() *Optional; Arguments__Optional() *Optional; StartInstant__Optional() *Optional; TotalCpuDuration__Optional() *Optional; User__Optional() *Optional }

func ProcessHandle_Info_InstanceOf(x any) bool { _, ok := x.(ProcessHandle_Info); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ProcessHandle_Info_class) } }; return ok }

func ProcessHandle_Info_Cast(x any) ProcessHandle_Info { if x == nil { return nil }; v, ok := x.(ProcessHandle_Info); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ProcessHandle_Info_class) } }; if !ok { panic(ClassCast(x, ProcessHandle_Info_class)) }; return v }
