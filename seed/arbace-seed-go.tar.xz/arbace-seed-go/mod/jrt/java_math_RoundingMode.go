//line java_math_RoundingMode.ae:1
package jrt
















func RoundingMode_New_String_I_I(p0 *String, p1, p2 int32) *RoundingMode { RoundingMode_Init(); t := &RoundingMode{}; t.Ctor_String_I_I(p0, p1, p2); return t }
//line :18:1
func (t *RoundingMode) Ctor_String_I_I(enumName *String, enumOrdinal, oldMode int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)
	t.F_oldMode = oldMode
}
func RoundingMode_ValueOf_I__RoundingMode(rm int32) *RoundingMode { RoundingMode_Init()
	switch rm { case 0: return RoundingMode_UP; case 1: return RoundingMode_DOWN; case 2: return RoundingMode_CEILING; case 3: return RoundingMode_FLOOR; case 4: return RoundingMode_HALF_UP; case 5: return RoundingMode_HALF_DOWN; case 6: return RoundingMode_HALF_EVEN; case 7: return RoundingMode_UNNECESSARY; default:








		panic(Thrown(IllegalArgumentException_New_String(Lit_1299)))}; panic("a2g: unreachable")
}


type RoundingMode struct{ Enum; F_oldMode int32 }

func (t *RoundingMode) Is_Constable() {}

var RoundingMode_UP *RoundingMode

var RoundingMode_DOWN *RoundingMode

var RoundingMode_CEILING *RoundingMode

var RoundingMode_FLOOR *RoundingMode

var RoundingMode_HALF_UP *RoundingMode

var RoundingMode_HALF_DOWN *RoundingMode

var RoundingMode_HALF_EVEN *RoundingMode

var RoundingMode_UNNECESSARY *RoundingMode

var RoundingMode__VALUES *RefArray

var RoundingMode_init ClassInit

func RoundingMode_Init() { if !RoundingMode_init.Done() { RoundingMode_init.Run(RoundingMode_clinit) } }

func RoundingMode_clinit() { RoundingMode_UP = RoundingMode_New_String_I_I(Lit_1291, 0, 0); RoundingMode_DOWN = RoundingMode_New_String_I_I(Lit_1292, 1, 1); RoundingMode_CEILING = RoundingMode_New_String_I_I(Lit_1293, 2, 2); RoundingMode_FLOOR = RoundingMode_New_String_I_I(Lit_1294, 3, 3); RoundingMode_HALF_UP = RoundingMode_New_String_I_I(Lit_1295, 4, 4); RoundingMode_HALF_DOWN = RoundingMode_New_String_I_I(Lit_1296, 5, 5); RoundingMode_HALF_EVEN = RoundingMode_New_String_I_I(Lit_1297, 6, 6); RoundingMode_UNNECESSARY = RoundingMode_New_String_I_I(Lit_1298, 7, 7); RoundingMode__VALUES = RoundingMode_X_values__RoundingMode1() }

func RoundingMode_Values__RoundingMode1() *RefArray { RoundingMode_Init(); return RoundingMode__VALUES.Copy() }

func RoundingMode_ValueOf_String__RoundingMode(p0 *String) *RoundingMode { RoundingMode_Init(); return RoundingMode_Cast(Enum_ValueOf_Class_String__Enum(RoundingMode_class, p0)) }

func RoundingMode_X_values__RoundingMode1() *RefArray { RoundingMode_Init(); return RefArrayOf(RoundingMode_class, RoundingMode_UP, RoundingMode_DOWN, RoundingMode_CEILING, RoundingMode_FLOOR, RoundingMode_HALF_UP, RoundingMode_HALF_DOWN, RoundingMode_HALF_EVEN, RoundingMode_UNNECESSARY) }

func (t *RoundingMode) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *RoundingMode) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *RoundingMode) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *RoundingMode) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.math.RoundingMode.describeConstable()Ljava/util/Optional;")) }

func (t *RoundingMode) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *RoundingMode) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *RoundingMode) Ref() any { if t == nil { return nil }; return t }

func (t *RoundingMode) GetClass__Class() *Class { return RoundingMode_class }

func (t *RoundingMode) CloneShallow() any { panic(CloneNotSupported(t)) }

func RoundingMode_InstanceOf(x any) bool { _, ok := x.(*RoundingMode); return ok }

func RoundingMode_Cast(x any) *RoundingMode { if x == nil { return nil }; v, ok := x.(*RoundingMode); if !ok { panic(ClassCast(x, RoundingMode_class)) }; return v }
