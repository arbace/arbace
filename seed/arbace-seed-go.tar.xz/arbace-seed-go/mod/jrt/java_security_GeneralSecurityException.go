//line java_security_GeneralSecurityException.ae:1
package jrt








func GeneralSecurityException_New() *GeneralSecurityException { t := &GeneralSecurityException{}; t.Ctor(t); return t }
//line :10:1
func (t *GeneralSecurityException) Ctor(this GeneralSecurityException_I) { t.Exception.Ctor(this) }

func GeneralSecurityException_New_String(p0 *String) *GeneralSecurityException { t := &GeneralSecurityException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *GeneralSecurityException) Ctor_String(this GeneralSecurityException_I, msg *String) { t.Exception.Ctor_String(this, msg) }

func GeneralSecurityException_New_String_Throwable(p0 *String, p1 Throwable_I) *GeneralSecurityException { t := &GeneralSecurityException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :14:1
func (t *GeneralSecurityException) Ctor_String_Throwable(this GeneralSecurityException_I, message *String, cause Throwable_I) { t.Exception.Ctor_String_Throwable(this, message, cause) }


func GeneralSecurityException_New_Throwable(p0 Throwable_I) *GeneralSecurityException { t := &GeneralSecurityException{}; t.Ctor_Throwable(t, p0); return t }
//line :17:1
func (t *GeneralSecurityException) Ctor_Throwable(this GeneralSecurityException_I, cause Throwable_I) { t.Exception.Ctor_Throwable(this, cause) }










type GeneralSecurityException struct{ Exception }

type GeneralSecurityException_I interface{ Exception_I; Serializable; Self_GeneralSecurityException() *GeneralSecurityException }

func (t *GeneralSecurityException) Self_GeneralSecurityException() *GeneralSecurityException { return t }

const GeneralSecurityException_serialVersionUID int64 = 894798122053539237

func (t *GeneralSecurityException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *GeneralSecurityException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *GeneralSecurityException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *GeneralSecurityException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *GeneralSecurityException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *GeneralSecurityException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *GeneralSecurityException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *GeneralSecurityException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *GeneralSecurityException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *GeneralSecurityException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *GeneralSecurityException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *GeneralSecurityException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *GeneralSecurityException) Ref() any { if t == nil { return nil }; return t }

func (t *GeneralSecurityException) GetClass__Class() *Class { return GeneralSecurityException_class }

func (t *GeneralSecurityException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *GeneralSecurityException) CloneShallow() any { panic(CloneNotSupported(t)) }

func GeneralSecurityException_InstanceOf(x any) bool { _, ok := x.(GeneralSecurityException_I); return ok }

func GeneralSecurityException_Cast(x any) GeneralSecurityException_I { if x == nil { return nil }; v, ok := x.(GeneralSecurityException_I); if !ok { panic(ClassCast(x, GeneralSecurityException_class)) }; return v }
