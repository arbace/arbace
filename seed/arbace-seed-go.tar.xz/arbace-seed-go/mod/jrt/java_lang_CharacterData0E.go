//line java_lang_CharacterData0E.ae:1
package jrt








func (t *CharacterData0E) GetProperties_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var tmp1 *IntArray = CharacterData0E_A; var tmp2 *CharArray = CharacterData0E_Y; var props int32 = tmp1.A[int32(tmp2.A[int32(CharacterData0E_X.A[int32(offset)>>5])|int32(offset)>>1&15])|int32(offset)&1]; return props
}







func (t *CharacterData0E) GetPropertiesEx_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var tmp1 *CharArray = CharacterData0E_B; var tmp2 *CharArray = CharacterData0E_Y; var props int32 = int32(tmp1.A[int32(tmp2.A[int32(CharacterData0E_X.A[int32(offset)>>5])|int32(offset)>>1&15])|int32(offset)&1]); return props
}







func (t *CharacterData0E) IsOtherAlphabetic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&4 == 0)
}
func (t *CharacterData0E) IsIdeographic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&8 == 0)
}
func (t *CharacterData0E) GetType_I__I(ch int32) int32 {
	var props int32 = t.GetProperties_I__I(ch); return props & 31
}
func (t *CharacterData0E) IsJavaIdentifierStart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 >= 20480
}
func (t *CharacterData0E) IsJavaIdentifierPart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return !(props&12288 == 0)
}
func (t *CharacterData0E) IsUnicodeIdentifierStart_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&16 == 0)
}
func (t *CharacterData0E) IsUnicodeIdentifierPart_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = !(t.GetPropertiesEx_I__I(ch)&32 == 0); if !tmp1 {
		tmp1 = t.IsIdentifierIgnorable_I__Z(ch) }
//line :49:1
	return tmp1
}

func (t *CharacterData0E) IsIdentifierIgnorable_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 4096
}
func (t *CharacterData0E) IsEmoji_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&64 == 0)
}
func (t *CharacterData0E) IsEmojiPresentation_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&128 == 0)
}
func (t *CharacterData0E) IsEmojiModifier_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&256 == 0)
}
func (t *CharacterData0E) IsEmojiModifierBase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&512 == 0)
}
func (t *CharacterData0E) IsEmojiComponent_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1024 == 0)
}
func (t *CharacterData0E) IsExtendedPictographic_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2048 == 0)
}
func (t *CharacterData0E) ToLowerCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if val&131072 == 0 { } else {
		var offset int32 = val << 5 >> 23
		mapChar = ch + offset }
//line :74:1
	return mapChar
}





func (t *CharacterData0E) ToUpperCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if val&65536 == 0 { } else {
		var offset int32 = val << 5 >> 23
		mapChar = ch - offset }
//line :82:1
	return mapChar
}





func (t *CharacterData0E) ToTitleCase_I__I(ch int32) int32 {
	var mapChar int32 = ch; var val int32 = t.GetProperties_I__I(ch)

	if !(val&32768 == 0) {
		if val&65536 == 0 {
			mapChar = ch + 1 } else {
//line :93:1
				if val&131072 == 0 {

					mapChar = ch - 1 } } } else {
						if val&65536 == 0 { } else { mapChar = t.ToUpperCase_I__I(ch) } }
//line :90:1
	return mapChar
}







func (t *CharacterData0E) Digit_I_I__I(ch, radix int32) int32 {
	var value int32 = -1; var tmp1 bool; var tmp2 bool
	tmp2 = radix >= 2; if tmp2 { tmp2 = radix <= 36 }; tmp1 = tmp2; if tmp1 {
		var val int32 = t.GetProperties_I__I(ch); var kind int32 = val & 31

		if kind == 9 {

			value = (ch + val&992>>5) & 31 } else {
//line :104:1
				if val&3072 == 3072 {







					value = (ch+val&992>>5)&31 + 10
				}
			}
	}



	if value < radix { return value } else { return -1
	} }
func (t *CharacterData0E) GetNumericValue_I__I(ch int32) int32 {
	var val int32 = t.GetProperties_I__I(ch)
	var retval int32 = -1
	switch val & 3072 { case 1024:

		retval = (ch + val&992>>5) & 31; case 2048:


		retval = -2; case 3072:

		retval = (ch+val&992>>5)&31 + 10; default:






		retval = -1}
//line :122:1
	return retval
}

















func (t *CharacterData0E) IsDigit_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch)
	return props&31 == 9
}
func (t *CharacterData0E) IsLowerCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1 == 0)
}
func (t *CharacterData0E) IsUpperCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2 == 0)
}
func (t *CharacterData0E) IsWhitespace_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 16384
}
func (t *CharacterData0E) GetDirectionality_I__B(ch int32) int8 {
	var val int32 = t.GetProperties_I__I(ch); var directionality int8 = int8(val & 2013265920 >> 27)


	if int32(directionality) == 15 { directionality = -1 }
//line :155:1
	return directionality
}




func (t *CharacterData0E) IsMirrored_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch)
	return !(props&-2147483648 == 0)
}


func CharacterData0E_New() *CharacterData0E { CharacterData0E_Init(); t := &CharacterData0E{}; t.Ctor(); return t }
//line :167:1
func (t *CharacterData0E) Ctor() { t.CharacterData.Ctor(t) }





type CharacterData0E struct{ CharacterData }

var CharacterData0E_instance CharacterData_I

var CharacterData0E_X *CharArray

var CharacterData0E_Y *CharArray

var CharacterData0E_A *IntArray

var CharacterData0E_A_DATA *String = Lit_1113

var CharacterData0E_B *CharArray

var CharacterData0E_init ClassInit

func CharacterData0E_Init() { if !CharacterData0E_init.Done() { CharacterData0E_init.Run(CharacterData0E_clinit) } }

func CharacterData0E_clinit() { CharacterData0E_instance = CharacterData0E_New(); CharacterData0E_X = Lit_1110.ToCharArray__C1(); CharacterData0E_Y = Lit_1111.ToCharArray__C1(); CharacterData0E_A = NewIntArray(8); CharacterData0E_B = Lit_1112.ToCharArray__C1()
//line :184:1
	var data *CharArray = Lit_1113.ToCharArray__C1()
	if !A2g_AssertionsDisabled && !(int32(len(data.A)) == 16) { panic(Thrown(AssertionError_New())) }
	var i int32 = 0
	var j int32 = 0
L1: for { if i < 16 {
	var entry int32; var tmp1 int32; var old_1 int32 = i
	i = i + 1; tmp1 = old_1
//line :189:1
	entry = int32(data.A[tmp1]) << 16


	var tmp2 *IntArray = CharacterData0E_A; tmp2.A[j] = entry | int32(data.A[i])
	j = j + 1
	i = i + 1
//line :188:1
	continue L1 }; break L1
}
}


func (t *CharacterData0E) ToUpperCaseCharArray_I__C1(p0 int32) *CharArray { return t.Impl_ToUpperCaseCharArray_I__C1(t, p0) }

func (t *CharacterData0E) ToUpperCaseEx_I__I(p0 int32) int32 { return t.Impl_ToUpperCaseEx_I__I(t, p0) }

func (t *CharacterData0E) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterData0E) GetClass__Class() *Class { return CharacterData0E_class }

func (t *CharacterData0E) ToString__String() *String { return Object_toString(t) }

func (t *CharacterData0E) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterData0E) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterData0E_InstanceOf(x any) bool { _, ok := x.(*CharacterData0E); return ok }

func CharacterData0E_Cast(x any) *CharacterData0E { if x == nil { return nil }; v, ok := x.(*CharacterData0E); if !ok { panic(ClassCast(x, CharacterData0E_class)) }; return v }
