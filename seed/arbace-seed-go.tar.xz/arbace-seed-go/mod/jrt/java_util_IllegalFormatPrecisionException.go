//line java_util_IllegalFormatPrecisionException.ae:1
package jrt










func IllegalFormatPrecisionException_New_I(p0 int32) *IllegalFormatPrecisionException { t := &IllegalFormatPrecisionException{}; t.Ctor_I(p0); return t }
//line :12:1
func (t *IllegalFormatPrecisionException) Ctor_I(p int32) { t.IllegalFormatException.Ctor(t); t.F_p = p }

func (t *IllegalFormatPrecisionException) GetPrecision__I() int32 { return t.F_p }

func (t *IllegalFormatPrecisionException) GetMessage__String() *String { return Integer_ToString_I__String(t.F_p) }





type IllegalFormatPrecisionException struct{ IllegalFormatException; F_p int32 }

const IllegalFormatPrecisionException_serialVersionUID int64 = 18711008

func (t *IllegalFormatPrecisionException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalFormatPrecisionException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalFormatPrecisionException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalFormatPrecisionException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalFormatPrecisionException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalFormatPrecisionException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalFormatPrecisionException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalFormatPrecisionException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalFormatPrecisionException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalFormatPrecisionException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalFormatPrecisionException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalFormatPrecisionException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalFormatPrecisionException) GetClass__Class() *Class { return IllegalFormatPrecisionException_class }

func (t *IllegalFormatPrecisionException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalFormatPrecisionException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalFormatPrecisionException_InstanceOf(x any) bool { _, ok := x.(*IllegalFormatPrecisionException); return ok }

func IllegalFormatPrecisionException_Cast(x any) *IllegalFormatPrecisionException { if x == nil { return nil }; v, ok := x.(*IllegalFormatPrecisionException); if !ok { panic(ClassCast(x, IllegalFormatPrecisionException_class)) }; return v }
