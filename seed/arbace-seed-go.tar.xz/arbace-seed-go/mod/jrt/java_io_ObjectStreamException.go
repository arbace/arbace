//line java_io_ObjectStreamException.ae:1
package jrt








func (t *ObjectStreamException) Ctor_String(this ObjectStreamException_I, message *String) { t.IOException.Ctor_String(this, message) }

func (t *ObjectStreamException) Ctor_String_Throwable(this ObjectStreamException_I, message *String, cause Throwable_I) { t.IOException.Ctor_String_Throwable(this, message, cause) }


func (t *ObjectStreamException) Ctor(this ObjectStreamException_I) { t.IOException.Ctor(this) }

func (t *ObjectStreamException) Ctor_Throwable(this ObjectStreamException_I, cause Throwable_I) { panic(A2g_NotTranslated("java.io.ObjectStreamException.<init>(Ljava/lang/Throwable;)V")) }



type ObjectStreamException struct{ IOException }

type ObjectStreamException_I interface{ IOException_I; Serializable; Self_ObjectStreamException() *ObjectStreamException }

func (t *ObjectStreamException) Self_ObjectStreamException() *ObjectStreamException { return t }

const ObjectStreamException_serialVersionUID int64 = 7260898174833392607

func ObjectStreamException_InstanceOf(x any) bool { _, ok := x.(ObjectStreamException_I); return ok }

func ObjectStreamException_Cast(x any) ObjectStreamException_I { if x == nil { return nil }; v, ok := x.(ObjectStreamException_I); if !ok { panic(ClassCast(x, ObjectStreamException_class)) }; return v }
