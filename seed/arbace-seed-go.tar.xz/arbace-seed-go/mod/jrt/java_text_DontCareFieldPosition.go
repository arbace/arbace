//line java_text_DontCareFieldPosition.ae:1
package jrt










func (t *DontCareFieldPosition_1) Formatted_Format_Field_O_I_I_Format_StringBuf__V(p0 Format_Field_I, p1 any, p2, p3 int32, p4 Format_StringBuf) {}


func (t *DontCareFieldPosition_1) Formatted_I_Format_Field_O_I_I_Format_StringBuf__V(p0 int32, p1 Format_Field_I, p2 any, p3, p4 int32, p5 Format_StringBuf) {}


func DontCareFieldPosition_New() *DontCareFieldPosition { DontCareFieldPosition_Init(); t := &DontCareFieldPosition{}; t.Ctor(); return t }
//line :18:1
func (t *DontCareFieldPosition) Ctor() { t.FieldPosition.Ctor_I(t, 0); t.F_noDelegate = DontCareFieldPosition_1_New_DontCareFieldPosition(t) }

func (t *DontCareFieldPosition) GetFieldDelegate__Format_FieldDelegate() Format_FieldDelegate { return t.F_noDelegate }





type DontCareFieldPosition struct{ FieldPosition; F_noDelegate Format_FieldDelegate }

var DontCareFieldPosition_INSTANCE FieldPosition_I

var DontCareFieldPosition_init ClassInit

func DontCareFieldPosition_Init() { if !DontCareFieldPosition_init.Done() { DontCareFieldPosition_init.Run(DontCareFieldPosition_clinit) } }

func DontCareFieldPosition_clinit() { DontCareFieldPosition_INSTANCE = DontCareFieldPosition_New() }

func (t *DontCareFieldPosition) GetFieldAttribute__Format_Field() Format_Field_I { return t.Impl_GetFieldAttribute__Format_Field(t) }

func (t *DontCareFieldPosition) GetField__I() int32 { return t.Impl_GetField__I(t) }

func (t *DontCareFieldPosition) GetBeginIndex__I() int32 { return t.Impl_GetBeginIndex__I(t) }

func (t *DontCareFieldPosition) GetEndIndex__I() int32 { return t.Impl_GetEndIndex__I(t) }

func (t *DontCareFieldPosition) SetBeginIndex_I__V(p0 int32) { t.Impl_SetBeginIndex_I__V(t, p0) }

func (t *DontCareFieldPosition) SetEndIndex_I__V(p0 int32) { t.Impl_SetEndIndex_I__V(t, p0) }

func (t *DontCareFieldPosition) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *DontCareFieldPosition) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *DontCareFieldPosition) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DontCareFieldPosition) Ref() any { if t == nil { return nil }; return t }

func (t *DontCareFieldPosition) GetClass__Class() *Class { return DontCareFieldPosition_class }

func (t *DontCareFieldPosition) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DontCareFieldPosition) CloneShallow() any { panic(CloneNotSupported(t)) }

func DontCareFieldPosition_InstanceOf(x any) bool { _, ok := x.(*DontCareFieldPosition); return ok }

func DontCareFieldPosition_Cast(x any) *DontCareFieldPosition { if x == nil { return nil }; v, ok := x.(*DontCareFieldPosition); if !ok { panic(ClassCast(x, DontCareFieldPosition_class)) }; return v }



type DontCareFieldPosition_1 struct{ Object; F_this_0 *DontCareFieldPosition }

func (t *DontCareFieldPosition_1) Is_Format_FieldDelegate() {}

func DontCareFieldPosition_1_New_DontCareFieldPosition(p0 *DontCareFieldPosition) *DontCareFieldPosition_1 { t := &DontCareFieldPosition_1{}; t.Ctor_DontCareFieldPosition(p0); return t }

func (t *DontCareFieldPosition_1) Ctor_DontCareFieldPosition(this_0 *DontCareFieldPosition) { NN(this_0); t.F_this_0 = this_0 }

func (t *DontCareFieldPosition_1) Ref() any { if t == nil { return nil }; return t }

func (t *DontCareFieldPosition_1) GetClass__Class() *Class { return DontCareFieldPosition_1_class }

func (t *DontCareFieldPosition_1) ToString__String() *String { return Object_toString(t) }

func (t *DontCareFieldPosition_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DontCareFieldPosition_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func DontCareFieldPosition_1_InstanceOf(x any) bool { _, ok := x.(*DontCareFieldPosition_1); return ok }

func DontCareFieldPosition_1_Cast(x any) *DontCareFieldPosition_1 { if x == nil { return nil }; v, ok := x.(*DontCareFieldPosition_1); if !ok { panic(ClassCast(x, DontCareFieldPosition_1_class)) }; return v }
