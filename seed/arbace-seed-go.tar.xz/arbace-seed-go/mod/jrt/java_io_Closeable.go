//line java_io_Closeable.ae:1
package jrt






type Closeable interface{ Object_I; AutoCloseable; Is_Closeable(); Close__V() }

func Closeable_InstanceOf(x any) bool { _, ok := x.(Closeable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Closeable_class) } }; return ok }

func Closeable_Cast(x any) Closeable { if x == nil { return nil }; v, ok := x.(Closeable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Closeable_class) } }; if !ok { panic(ClassCast(x, Closeable_class)) }; return v }
