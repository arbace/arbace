//line hostbox_tamago.ae:1
//go:build tamago

package jrt

import (
	"errors"
	"io"
	"io/fs"
	"os"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"runtime/goos"

	"arbace/box/abi"
	"arbace/box/board"
)
// boxMemoryHeadroom is what the box's default memory limit leaves of the guest's RAM (goos.RamSize):
// the image, its bss and the first stack are in the RAM too, and the limit is the collector's
// goal, which a large allocation may pass for a while (doc/go/BOX-NOTES.md, S2).
//line :18:1
const boxMemoryHeadroom uint =




	1 << 30
// boxYield: the evaluator yields every yieldEvery calls and recurs (Compiler$CodeRun.tick): TamaGo's
// runtime has no preemption.
//line :25:1
const boxYield bool = true
// init makes the command line and the environment the monitor wrote at the entry the program's
// (os.Args, os.Getenv: TamaGo's runtime gives it neither), before jrt's other inits (tuning.go's
// reads the environment), and applies GOGC and GOMEMLIMIT, which TamaGo's runtime read before
// they were set; seeds the in-memory file system from the snapshot ARBACE_BOX_FS names (seedFS);
// names the event area to the monitor and starts the event goroutine (boxEventLoop: the guest
// waits for its host without polling); and makes a nil dereference the run-time panic it is on Linux (board.NilPanics:
// jrt's implicit NullPointerException, A2G-SPEC §7.9.5). Without GOMEMLIMIT the memory limit is the
// guest's RAM less boxMemoryHeadroom: the RAM is fixed and the host has no swap for it, and with
// GOGC's goal alone (DefaultGOGC: three times the live heap) a guest holding a third of its RAM
// would run out of memory (doc/go/BOX-NOTES.md, S2).
//line :29:1
func init() {











	board.NilPanics()
	if board.EventArea(&boxEventArea) {
		boxEventsOn = true
		setEventHook(boxEventsPending)
		go boxEventLoop() }
	os.Args = board.Args()
	for _, kv := range board.Env() {
		k, v, ok := strings.Cut(kv, "=")
		if ok {
			syscall.Setenv(k, v)
		}
	}

	propMu.Lock()
	props = nil
	propMu.Unlock()
	{ g := os.Getenv("GOGC")
		if g == "off" {
			debug.SetGCPercent(-1) } else {
				n, err := strconv.Atoi(g)
				if err == nil {
					debug.SetGCPercent(n) } } }
	n, ok := parseByteCount(os.Getenv("GOMEMLIMIT"))
	if ok {
		debug.SetMemoryLimit(n)
	} else if goos.RamSize > boxMemoryHeadroom {
		debug.SetMemoryLimit(int64(goos.RamSize - boxMemoryHeadroom)) }
	seedFS() }
// ProgramHost is the program's host (the main package's): the box's, with the program's embedded
// resources, and with a network when the monitor gives one (boxNetHost, netbox_tamago.ae).
//line :70:1
func ProgramHost(resources fs.FS) Host {



	h := boxHost{files: OSHost{Resources: resources}, in: &boxConsole{}}
	if boxNetwork() {
		return boxNetHost{boxHost: h} }; return h }
// boxHost is the box's Host: the monitor's calls, and files in TamaGo's in-memory file system
// through OSHost's.
type boxHost /*line :82:1*/ struct{ files OSHost; in *boxConsole }

func (h boxHost) Stdin() io.Reader { return h.in }
func (h boxHost) Stdout() io.Writer { return boxOut{} }
func (h boxHost) Stderr() io.Writer { return boxOut{err: true} }
func (h boxHost) Open(name string, flag int, perm uint32) (HostFile, error) {
	return h.files.Open(name, flag, perm) }
func (h boxHost) Stat(name string) (HostFileInfo, error) { return h.files.Stat(name) }
func (h boxHost) ReadDir(name string) ([]string, error) { return h.files.ReadDir(name) }
func (h boxHost) Remove(name string) error { return h.files.Remove(name) }
func (h boxHost) Mkdir(name string, perm uint32) error { return h.files.Mkdir(name, perm) }
func (h boxHost) Rename(from, to string) error { return h.files.Rename(from, to) }
func (h boxHost) Getwd() (string, error) { return h.files.Getwd() }
// Now is the board's clock, the host's wall clock at the entry onward (D10).
//line :95:1
func (h boxHost) Now() time.Time {

	return time.Now() }
func (h boxHost) Nanotime() int64 { return h.files.Nanotime() }
func (h boxHost) Getenv(name string) (string, bool) { return os.LookupEnv(name) }
func (h boxHost) Environ() []string { return os.Environ() }
func (h boxHost) Args() []string { return os.Args }
// NumCPU is the guest's vCPUs (the board's GOMAXPROCS).
//line :102:1
func (h boxHost) NumCPU() int {
	return runtime.GOMAXPROCS(0) }
// RandomBytes is the host's entropy (abi.Random).
//line :104:1
func (h boxHost) RandomBytes(b []byte) {
	if len(b) > 0 {
		board.Call(abi.Random, board.Addr(b), int64(len(b)), 0, 0, 0) } }
func (h boxHost) Resource(name string) ([]byte, bool) { return h.files.Resource(name) }
// Exit ends the guest (abi.Exit, the console flushed).
//line :108:1
func (h boxHost) Exit(code int) {
	StopProfile()
	board.Exit(int32(code)) }
// boxOut is the guest's standard output (abi.Write) or error (abi.Message to the error stream).
type boxOut /*line :114:1*/ struct{ err bool }

func (o boxOut) Write(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil }
	if o.err {
		board.Call(abi.Message, board.Addr(p), int64(len(p)), 1, 0, 0)
		return len(p), nil }
	n := board.Call(abi.Write, board.Addr(p), int64(len(p)), 0, 0, 0).Ret
	if n < 0 {
		return 0, io.ErrClosedPipe }
	return int(n), nil }
// consoleFirstWait is the first wait between two polls of the monitor, without an event area.
const consoleFirstWait time.Duration = time.Millisecond


// consoleMaxWait is the longest wait between two polls, without an event area.
const consoleMaxWait time.Duration =

	10 * time.Millisecond






// boxEventArea is the guest's event area (abi.EventArea): [0] the events the monitor posted,
// [1] those the guest took.
var boxEventArea [2]uint64



// boxEventsOn: the monitor took the event area; without it the waiters poll.
var boxEventsOn bool
// boxEventsPending says whether the monitor posted an event the guest has not taken: the runtime's
// event hook, asked at the scheduler's every look for work.
//
//go:nosplit
//line :149:1
func boxEventsPending() bool {



	return atomic.LoadUint64(&boxEventArea[0]) != atomic.LoadUint64(&boxEventArea[1]) }
// boxEventLoop is the goroutine the monitor's events wake: parked in the runtime (eventPark) until
// findRunnable sees an event posted (boxEventsPending), it takes the events and wakes the
// waiters, which ask the monitor again.
//line :155:1
func boxEventLoop() {




	for {
		eventPark()
		atomic.StoreUint64(&boxEventArea[1], atomic.LoadUint64(&boxEventArea[0]))
		(&boxEvents).wake() } }
// boxWaiters are the goroutines waiting for the host: the console's reader, the network's
// operations. Each takes ch (arm), asks the monitor, and when it has nothing yet waits for ch,
// which is closed, and replaced, at the next event (boxEventLoop) -- or, when the monitor took no
// event area, at the next poll (poll: every consoleFirstWait to consoleMaxWait while some wait).
//line :165:1
type boxWaiters /*line :170:1*/ struct{ mu sync.Mutex; ch chan struct{}; waiters int; polling bool }

var boxEvents boxWaiters = boxWaiters{ch: make(chan struct{})}
// arm counts a waiter and is the channel its wait ends on.
func (w /*line :175:1*/*boxWaiters) arm() chan struct{} {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.waiters++
	if !boxEventsOn && !w.polling {
		w.polling = true
		go w.poll() }
	return w.ch }
// disarm uncounts a waiter.
func (w *boxWaiters) disarm() {
	w.mu.Lock()
	w.waiters--
	w.mu.Unlock() }
// wake ends the waits: ch closed, and replaced.
func (w *boxWaiters) wake() {
	w.mu.Lock()
	close(w.ch)
	w.ch = make(chan struct{})
	w.mu.Unlock() }
// poll wakes the waiters while there are any, from consoleFirstWait to consoleMaxWait apart:
// without an event area they ask the monitor again so.
//line :195:1
func (w /*line :198:1*/*boxWaiters) poll() {
	wait := consoleFirstWait
	for {
		time.Sleep(wait)
		wait = min(wait*2, consoleMaxWait)
		w.mu.Lock()
		if w.waiters == 0 {
			w.polling = false
			w.mu.Unlock()
			return }
		close(w.ch)
		w.ch = make(chan struct{})
		w.mu.Unlock() } }
// boxConsole is the guest's standard input: abi.WaitRead into a buffer of the guest's. The read
// does not stop the guest (BOX-SURVEY R3): the monitor is asked without a wait, and while there is
// no input the reading goroutine waits for the host's next event (boxEvents: the monitor posts one
// when input comes), so that other goroutines run, the collector stops the world and other vCPUs'
// output goes; an idle guest parks in the monitor meanwhile (the board's Idle) until the input.
//line :212:1
type boxConsole /*line :218:1*/ struct{ buf [4096]byte; n, at int; eof bool }

func (c *boxConsole) Read(p []byte) (int, error) {
	if c.at == c.n {
		if c.eof {
			return 0, io.EOF }
		for {
			ch := (&boxEvents).arm()
			b := board.Call(abi.WaitRead, 0, board.Addr(c.buf[:]), int64(len(c.buf)), 0, 0)
			if b.Ret != 0 {
				m := int(b.A[0])
				if m == 0 {
					(&boxEvents).disarm()
					c.eof = true
					return 0, io.EOF }
				if m > 0 {
					(&boxEvents).disarm()
					c.n = m
					c.at = 0
					break } }
			<-ch
			(&boxEvents).disarm() } }
	k := copy(p, c.buf[c.at:c.n])
	c.at += k
	return k, nil
}




var boxStoreOnce sync.Once
var boxHasStore bool
// Store is the monitor's store, or nil when it has none (its calls answer abi.StoreNone; asked
// once).
//line :251:1
func (h boxHost) Store() Store {



	boxStoreOnce.Do(
		func() {
			args := boxStoreArgs()
			boxHasStore = board.Call(abi.BlobSize, board.Addr(args[0:32]), 0, 0, 0, 0).Ret != abi.StoreNone })
	if !boxHasStore {
		return nil }
	return boxStore{} }
// boxStoreArgBytes is the size of a store call's argument buffer: two hashes and a name. A
// variable, so that make allocates the buffer on the heap: the monitor reads it by address, and a
// goroutine's stack moves.
//line :263:1
var boxStoreArgBytes int = 128




// boxStoreArgs is a new argument buffer: the hash at 0, the old hash at 32, the name at 64.
func boxStoreArgs(

) []byte {
	return make([]byte, boxStoreArgBytes) }
// boxStore is the monitor's store through the board's calls (abi.BlobPut ... RefSet). The data a
// guest puts or gets is its caller's, read or written by the monitor in place.
//line :274:1
type boxStore /*line :277:1*/ struct{}

func (s boxStore) Put(data []byte) ([32]byte, error) {
	args := boxStoreArgs()
	var h [32]byte
	r := board.Call(abi.BlobPut, board.Addr(data), int64(len(data)), board.Addr(args[0:32]), 0, 0).Ret
	switch r {
	case 0:
		copy(h[:], args[0:32])
		return h, nil
	case abi.StoreTooLarge: return h, ErrStoreTooLarge}
	return h, boxStoreError(r)
}
func (s boxStore) Size(h [32]byte) (int64, bool) {
	args := boxStoreArgs()
	copy(args, h[:])
	n := board.Call(abi.BlobSize, board.Addr(args[0:32]), 0, 0, 0, 0).Ret
	return n, n >= 0
}
func (s boxStore) Get(h [32]byte, off int64, p []byte) (int, bool) {
	args := boxStoreArgs()
	copy(args, h[:])
	n := board.Call(abi.BlobGet, board.Addr(args[0:32]), board.Addr(p), int64(len(p)), off, 0).Ret
	return int(n), n >= 0
}
func (s boxStore) Ref(name string) ([32]byte, bool) {
	var h [32]byte
	if !StoreName(name) {
		return h, false }
	args := boxStoreArgs()
	k := copy(args[64:], name)
	r := board.Call(abi.RefGet, board.Addr(args[64:]), int64(k), board.Addr(args[0:32]), 0, 0).Ret
	if r != 0 {
		return h, false }
	copy(h[:], args[0:32])
	return h, true
}
func (s boxStore) SetRef(name string, h [32]byte, old *[32]byte) error {
	if !StoreName(name) {
		return ErrStoreName }
	args := boxStoreArgs()
	var o int64 = 0
	copy(args, h[:])
	if old != nil {
		copy(args[32:64], (*old)[:])
		o = board.Addr(args[32:64]) }
	k := copy(args[64:], name)
	r := board.Call(abi.RefSet, board.Addr(args[64:]), int64(k), board.Addr(args[0:32]), o, 0).Ret
	if r == 0 {
		return nil }
	return boxStoreError(r) }
// boxStoreError is the error of a store call's negative answer r.
func boxStoreError(r int64) error {


	switch r {
	case abi.StoreConflict: return ErrStoreConflict
	case abi.StoreTooLarge: return ErrStoreTooLarge
	case abi.StoreBadName: return ErrStoreName
	case abi.StoreNone: return errors.New("no store")}
	return errors.New("the store refused (" + strconv.FormatInt(r, 10) + ")") }
// seedFS restores the snapshot ref ARBACE_BOX_FS names (a tar, arbace.box/save-fs!) into the
// in-memory file system at the guest's start (RestoreTar into /); when it cannot, the guest ends
// with status 1 and the reason on its error stream.
//line :339:1
func seedFS() {




	ref := os.Getenv("ARBACE_BOX_FS")
	if ref == "" {
		return }
	if err := seedFrom(ref); err != nil {
		boxOut{err: true}.Write([]byte("arbace: ARBACE_BOX_FS=" + ref + ": " + err.Error() + "\n"))
		board.Exit(1) } }
// seedFrom restores the snapshot ref names into /.
func seedFrom(ref string) error {
	st := CurrentStore()
	if st == nil {
		return errors.New("no store (ARBACE_BOX_STORE, or the launcher's --store)") }
	if !StoreName(ref) {
		return errors.New("not a name the store takes") }
	h, ok := st.Ref(ref)
	if !ok {
		return errors.New("no such ref") }
	b, ok := ReadBlob(st, h)
	if !ok {
		return errors.New("its blob cannot be read") }
	return RestoreTar(b, "/")
}
