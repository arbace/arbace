//line java_lang_CharacterDataLatin1.ae:1
package jrt








func (t *CharacterDataLatin1) GetProperties_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var props int32 = CharacterDataLatin1_A.A[int32(offset)]; return props
}
func (t *CharacterDataLatin1) GetPropertiesEx_I__I(ch int32) int32 {
	var offset uint16 = uint16(ch); var props int32 = int32(CharacterDataLatin1_B.A[int32(offset)]); return props
}
func (t *CharacterDataLatin1) IsDigit_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = 48 <= ch; if tmp1 { tmp1 = ch <= 57 }; return tmp1
}
func (t *CharacterDataLatin1) IsLowerCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1 == 0)
}
func (t *CharacterDataLatin1) IsUpperCase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2 == 0)
}
func (t *CharacterDataLatin1) IsOtherAlphabetic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&4 == 0)
}
func (t *CharacterDataLatin1) IsIdeographic_I__Z(ch int32) bool {
	var props int32 = t.GetPropertiesEx_I__I(ch); return !(props&8 == 0)
}
func (t *CharacterDataLatin1) GetType_I__I(ch int32) int32 {
	var props int32 = t.GetProperties_I__I(ch); return props & 31
}
func (t *CharacterDataLatin1) IsJavaIdentifierStart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 >= 20480
}
func (t *CharacterDataLatin1) IsJavaIdentifierPart_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return !(props&12288 == 0)
}
func (t *CharacterDataLatin1) IsUnicodeIdentifierStart_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&16 == 0)
}
func (t *CharacterDataLatin1) IsUnicodeIdentifierPart_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = !(t.GetPropertiesEx_I__I(ch)&32 == 0); if !tmp1 {
		tmp1 = t.IsIdentifierIgnorable_I__Z(ch) }
//line :44:1
	return tmp1
}

func (t *CharacterDataLatin1) IsIdentifierIgnorable_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 4096
}
func (t *CharacterDataLatin1) IsEmoji_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&64 == 0)
}
func (t *CharacterDataLatin1) IsEmojiPresentation_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&128 == 0)
}
func (t *CharacterDataLatin1) IsEmojiModifier_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&256 == 0)
}
func (t *CharacterDataLatin1) IsEmojiModifierBase_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&512 == 0)
}
func (t *CharacterDataLatin1) IsEmojiComponent_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&1024 == 0)
}
func (t *CharacterDataLatin1) IsExtendedPictographic_I__Z(ch int32) bool {
	return !(t.GetPropertiesEx_I__I(ch)&2048 == 0)
}
func (t *CharacterDataLatin1) ToLowerCase_I__I(ch int32) int32 {
	if ch < 65 { return ch } else {

		var lower int32 = ch | 32; var tmp1 bool; var tmp2 bool
		tmp2 = lower <= 122; if !tmp2 { var tmp3 bool; var tmp4 bool; tmp4 = lower >= 224; if tmp4 { tmp4 = lower <= 254 }; tmp3 = tmp4; if tmp3 { tmp3 = !(lower == 247) }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 { return lower } else { return ch
		}
	}
}
func (t *CharacterDataLatin1) ToUpperCase_I__I(ch int32) int32 {
	if ch < 97 { return ch } else {

		var upper int32 = ch & 223; var tmp1 bool; var tmp2 bool

		tmp2 = upper <= 90; if !tmp2 { var tmp3 bool; var tmp4 bool; tmp4 = upper >= 192; if tmp4 { tmp4 = upper <= 222 }; tmp3 = tmp4; if tmp3 { tmp3 = !(upper == 215) }; tmp2 = tmp3 }; tmp1 = tmp2
//line :80:1
		if tmp1 { return upper } else { if ch == 255 { return 376 } else { if ch == 181 { return 924 } else { return ch
		}
		}
		}
	}
}

func CharacterDataLatin1_EqualsIgnoreCase_B_B__Z(p0, p1 int8) bool { CharacterDataLatin1_Init(); panic(A2g_NotTranslated("java.lang.CharacterDataLatin1.equalsIgnoreCase(BB)Z")) }









func (t *CharacterDataLatin1) ToTitleCase_I__I(ch int32) int32 { return t.ToUpperCase_I__I(ch) }













func (t *CharacterDataLatin1) Digit_I_I__I(ch, radix int32) int32 {
	var value int32 = int32(CharacterDataLatin1_DIGITS.A[ch]); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool
	tmp4 = value >= 0; if tmp4 { tmp4 = value < radix }; tmp3 = tmp4; if tmp3 { tmp3 = radix >= 2 }; tmp2 = tmp3; if tmp2 {
		tmp2 = radix <= 36 }
//line :113:1
	tmp1 = tmp2; if tmp1 { return value } else { return -1
	}
}


func (t *CharacterDataLatin1) GetNumericValue_I__I(ch int32) int32 {
	var val int32 = t.GetProperties_I__I(ch)
	var retval int32 = -1
	switch val & 3072 { case 1024:

		retval = (ch + val&992>>5) & 31; case 2048:


		retval = -2; case 3072:

		retval = (ch+val&992>>5)&31 + 10; default:






		retval = -1}
//line :119:1
	return retval
}

















func (t *CharacterDataLatin1) IsWhitespace_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch); return props&28672 == 16384
}
func (t *CharacterDataLatin1) GetDirectionality_I__B(ch int32) int8 {
	var val int32 = t.GetProperties_I__I(ch); var directionality int8 = int8(val & 2013265920 >> 27)


	if int32(directionality) == 15 { directionality = -1 }
//line :142:1
	return directionality
}




func (t *CharacterDataLatin1) IsMirrored_I__Z(ch int32) bool {
	var props int32 = t.GetProperties_I__I(ch)
	return !(props&-2147483648 == 0)
}
func (t *CharacterDataLatin1) ToUpperCaseEx_I__I(p0 int32) int32 { panic(A2g_NotTranslated("java.lang.CharacterDataLatin1.toUpperCaseEx(I)I")) }











func (t *CharacterDataLatin1) ToUpperCaseCharArray_I__C1(p0 int32) *CharArray { panic(A2g_NotTranslated("java.lang.CharacterDataLatin1.toUpperCaseCharArray(I)[C")) }






func CharacterDataLatin1_New() *CharacterDataLatin1 { CharacterDataLatin1_Init(); t := &CharacterDataLatin1{}; t.Ctor(); return t }
//line :171:1
func (t *CharacterDataLatin1) Ctor() { t.CharacterData.Ctor(t) }





type CharacterDataLatin1 struct{ CharacterData }

var CharacterDataLatin1_DIGITS *ByteArray

var CharacterDataLatin1_sharpsMap *CharArray

var CharacterDataLatin1_instance *CharacterDataLatin1

var CharacterDataLatin1_A *IntArray

var CharacterDataLatin1_B *CharArray

var CharacterDataLatin1_init ClassInit

func CharacterDataLatin1_Init() { if !CharacterDataLatin1_init.Done() { CharacterDataLatin1_init.Run(CharacterDataLatin1_clinit) } }

func CharacterDataLatin1_clinit() { CharacterDataLatin1_DIGITS = ByteArrayOf(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1); CharacterDataLatin1_sharpsMap = CharArrayOf(83, 83); CharacterDataLatin1_instance = CharacterDataLatin1_New(); CharacterDataLatin1_A = IntArrayOf(1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1476411407, 1342193679, 1476411407, 1610629135, 1342193679, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1342193679, 1342193679, 1342193679, 1476411407, 1610629132, 1744830488, 1744830488, 671088664, 671113242, 671088664, 1744830488, 1744830488, -402653163, -402653162, 1744830488, 536870937, 939524120, 536870932, 939524120, 939524120, 402667017, 402667017, 402667017, 402667017, 402667017, 402667017, 402667017, 402667017, 402667017, 402667017, 939524120, 1744830488, -402653159, 1744830489, -402653159, 1744830488, 1744830488, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, 8552417, -402653163, 1744830488, -402653162, 1744830491, 1744850967, 1744830491, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, 8486882, -402653163, 1744830489, -402653162, 1744830489, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1342181391, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 1207963663, 939524108, 1744830488, 671113242, 671113242, 671113242, 671113242, 1744830492, 1744830488, 1744830491, 1744830492, 28677, -402653155, 1744830489, 1207963664, 1744830492, 1744830491, 671088668, 671088665, 402654731, 402654731, 1744830491, 134049794, 1744830488, 1744830488, 1744830491, 402654475, 28677, -402653154, 1744832523, 1744832523, 1744832523, 1744830488, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 1744830489, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 8548353, 134049794, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 1744830489, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 8482818, 102592514); CharacterDataLatin1_B = CharArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1088, 0, 0, 0, 0, 0, 0, 1088, 0, 0, 0, 0, 0, 1120, 1120, 1120, 1120, 1120, 1120, 1120, 1120, 1120, 1120, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 32, 0, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2112, 49, 0, 0, 0, 2112, 0, 0, 0, 0, 0, 0, 49, 0, 32, 0, 0, 49, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 0, 50, 50, 50, 50, 50, 50, 50, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 0, 49, 49, 49, 49, 49, 49, 49, 49) }

func (t *CharacterDataLatin1) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterDataLatin1) GetClass__Class() *Class { return CharacterDataLatin1_class }

func (t *CharacterDataLatin1) ToString__String() *String { return Object_toString(t) }

func (t *CharacterDataLatin1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterDataLatin1) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterDataLatin1_InstanceOf(x any) bool { _, ok := x.(*CharacterDataLatin1); return ok }

func CharacterDataLatin1_Cast(x any) *CharacterDataLatin1 { if x == nil { return nil }; v, ok := x.(*CharacterDataLatin1); if !ok { panic(ClassCast(x, CharacterDataLatin1_class)) }; return v }
