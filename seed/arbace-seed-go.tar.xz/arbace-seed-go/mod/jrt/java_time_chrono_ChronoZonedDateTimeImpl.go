//line java_time_chrono_ChronoZonedDateTimeImpl.ae:1
package jrt

























func ChronoZonedDateTimeImpl_OfBest_ChronoLocalDateTimeImpl_ZoneId_ZoneOffset__ChronoZonedDateTime(localDateTime *ChronoLocalDateTimeImpl, zone ZoneId_I, preferredOffset *ZoneOffset) ChronoZonedDateTime {


	Objects_RequireNonNull_O_String__O(localDateTime.Ref(), Lit_2167)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	if ZoneOffset_InstanceOf(zone) {
		return ChronoZonedDateTimeImpl_New_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(localDateTime, ZoneOffset_Cast(zone), zone) } else {
			var rules *ZoneRules = zone.GetRules__ZoneRules(); var isoLDT *LocalDateTime = LocalDateTime_From_TemporalAccessor__LocalDateTime(Up_ChronoLocalDateTimeImpl_TemporalAccessor(localDateTime)); var validOffsets List = NN(rules).GetValidOffsets_LocalDateTime__List(isoLDT); var offset *ZoneOffset



			if validOffsets.Size__I() == 1 {
				offset = ZoneOffset_Cast(validOffsets.Get_I__O(0)) } else {
//line :38:1
					if validOffsets.Size__I() == 0 {


						var trans *ZoneOffsetTransition = NN(rules).GetTransition_LocalDateTime__ZoneOffsetTransition(isoLDT)
						localDateTime = NN(localDateTime).PlusSeconds_J__ChronoLocalDateTimeImpl(NN(NN(trans).GetDuration__Duration()).GetSeconds__J())
						offset = NN(trans).GetOffsetAfter__ZoneOffset() } else {
//line :38:1
							var tmp1 bool; var tmp2 bool





							tmp2 = !(preferredOffset == nil); if tmp2 { tmp2 = validOffsets.Contains_O__Z(preferredOffset.Ref()) }; tmp1 = tmp2
//line :38:1
							if tmp1 {






								offset = preferredOffset } else {
									offset = ZoneOffset_Cast(validOffsets.Get_I__O(0)) } } }
			Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
			return ChronoZonedDateTimeImpl_New_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(localDateTime, offset, zone)
		} }
func ChronoZonedDateTimeImpl_OfInstant_Chronology_Instant_ZoneId__ChronoZonedDateTimeImpl(chrono Chronology, instant *Instant, zone ZoneId_I) *ChronoZonedDateTimeImpl {

	var rules *ZoneRules = zone.GetRules__ZoneRules(); var offset *ZoneOffset = NN(rules).GetOffset_Instant__ZoneOffset(instant)

	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	var ldt *LocalDateTime = LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(NN(instant).GetEpochSecond__J(), NN(instant).GetNano__I(), offset); var cldt *ChronoLocalDateTimeImpl = ChronoLocalDateTimeImpl_Cast(chrono.LocalDateTime_TemporalAccessor__ChronoLocalDateTime(Up_LocalDateTime_TemporalAccessor(ldt)))



	return ChronoZonedDateTimeImpl_New_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(cldt, offset, zone)
}
func (t *ChronoZonedDateTimeImpl) Create_Instant_ZoneId__ChronoZonedDateTimeImpl(instant *Instant, zone ZoneId_I) *ChronoZonedDateTimeImpl {
	return ChronoZonedDateTimeImpl_OfInstant_Chronology_Instant_ZoneId__ChronoZonedDateTimeImpl(t.GetChronology__Chronology(), instant, zone)
}
func ChronoZonedDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoZonedDateTimeImpl(chrono Chronology, temporal Temporal) *ChronoZonedDateTimeImpl {

	var other *ChronoZonedDateTimeImpl = ChronoZonedDateTimeImpl_Cast(temporal)
	if chrono.Equals_O__Z(NN(other).GetChronology__Chronology()) == false {
		panic(Thrown(ClassCastException_New_String(Concat(Lit_2192, chrono.GetId__String(), Lit_2189, NN(other).GetChronology__Chronology().GetId__String())))) }
//line :66:1
	return other
}







func ChronoZonedDateTimeImpl_New_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(p0 *ChronoLocalDateTimeImpl, p1 *ZoneOffset, p2 ZoneId_I) *ChronoZonedDateTimeImpl { t := &ChronoZonedDateTimeImpl{}; t.Ctor_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(p0, p1, p2); return t }
//line :75:1
func (t *ChronoZonedDateTimeImpl) Ctor_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(dateTime *ChronoLocalDateTimeImpl, offset *ZoneOffset, zone ZoneId_I) {

	t.F_dateTime = ChronoLocalDateTimeImpl_Cast(Objects_RequireNonNull_O_String__O(dateTime.Ref(), Lit_2076))

	t.F_offset = ZoneOffset_Cast(Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052))
	t.F_zone = ZoneId_Cast(Objects_RequireNonNull_O_String__O(zone, Lit_1984))
}
func (t *ChronoZonedDateTimeImpl) GetOffset__ZoneOffset() *ZoneOffset { return t.F_offset }

func (t *ChronoZonedDateTimeImpl) WithEarlierOffsetAtOverlap__ChronoZonedDateTime() ChronoZonedDateTime {
	var trans *ZoneOffsetTransition = NN(t.GetZone__ZoneId().GetRules__ZoneRules()).GetTransition_LocalDateTime__ZoneOffsetTransition(LocalDateTime_From_TemporalAccessor__LocalDateTime(t)); var tmp1 bool; var tmp2 bool
	tmp2 = !(trans == nil); if tmp2 { tmp2 = NN(trans).IsOverlap__Z() }; tmp1 = tmp2; if tmp1 {
		var earlierOffset *ZoneOffset = NN(trans).GetOffsetBefore__ZoneOffset()
		if NN(earlierOffset).Equals_O__Z(t.F_offset.Ref()) == false {
			return ChronoZonedDateTimeImpl_New_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(t.F_dateTime, earlierOffset, t.F_zone) } }
//line :85:1
	return t
}





func (t *ChronoZonedDateTimeImpl) WithLaterOffsetAtOverlap__ChronoZonedDateTime() ChronoZonedDateTime {
	var trans *ZoneOffsetTransition = NN(t.GetZone__ZoneId().GetRules__ZoneRules()).GetTransition_LocalDateTime__ZoneOffsetTransition(LocalDateTime_From_TemporalAccessor__LocalDateTime(t))
	if !(trans == nil) {
		var offset *ZoneOffset = NN(trans).GetOffsetAfter__ZoneOffset()
		if NN(offset).Equals_O__Z(t.GetOffset__ZoneOffset().Ref()) == false {
			return ChronoZonedDateTimeImpl_New_ChronoLocalDateTimeImpl_ZoneOffset_ZoneId(t.F_dateTime, offset, t.F_zone) } }
//line :93:1
	return t
}





func (t *ChronoZonedDateTimeImpl) ToLocalDateTime__ChronoLocalDateTime() ChronoLocalDateTime { return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(t.F_dateTime) }


func (t *ChronoZonedDateTimeImpl) GetZone__ZoneId() ZoneId_I { return t.F_zone }

func (t *ChronoZonedDateTimeImpl) WithZoneSameLocal_ZoneId__ChronoZonedDateTime(zone ZoneId_I) ChronoZonedDateTime {
	return ChronoZonedDateTimeImpl_OfBest_ChronoLocalDateTimeImpl_ZoneId_ZoneOffset__ChronoZonedDateTime(t.F_dateTime, zone, t.F_offset)
}
func (t *ChronoZonedDateTimeImpl) WithZoneSameInstant_ZoneId__ChronoZonedDateTime(zone ZoneId_I) ChronoZonedDateTime {
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	if t.F_zone.Equals_O__Z(zone) { return t } else {

		return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(t.Create_Instant_ZoneId__ChronoZonedDateTimeImpl(NN(t.F_dateTime).ToInstant_ZoneOffset__Instant(t.F_offset), zone))
	} }
func (t *ChronoZonedDateTimeImpl) IsSupported_TemporalField__Z(field TemporalField) bool {
	var tmp1 bool; tmp1 = ChronoField_InstanceOf(field); if !tmp1 { var tmp2 bool; tmp2 = !(field == nil); if tmp2 { tmp2 = field.IsSupportedBy_TemporalAccessor__Z(t) }; tmp1 = tmp2 }; return tmp1
}
func (t *ChronoZonedDateTimeImpl) With_TemporalField_J__ChronoZonedDateTime(field TemporalField, newValue int64) ChronoZonedDateTime {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:

			var tmp2 int64 = newValue - t.ToEpochSecond__J(); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_SECONDS; return t.Plus_J_TemporalUnit__ChronoZonedDateTime(tmp2, Up_ChronoUnit_TemporalUnit(tmp3)); case 29:

			var offset *ZoneOffset = ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(chronoField).CheckValidIntValue_J__I(newValue))
			return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(t.Create_Instant_ZoneId__ChronoZonedDateTimeImpl(NN(t.F_dateTime).ToInstant_ZoneOffset__Instant(offset), t.F_zone)); default:
			return ChronoZonedDateTimeImpl_OfBest_ChronoLocalDateTimeImpl_ZoneId_ZoneOffset__ChronoZonedDateTime(NN(t.F_dateTime).With_TemporalField_J__ChronoLocalDateTimeImpl(field, newValue), t.F_zone, t.F_offset)} } else {
				return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(ChronoZonedDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoZonedDateTimeImpl(t.GetChronology__Chronology(), field.AdjustInto_Temporal_J__Temporal(t, newValue))) } }; panic("a2g: unreachable")
}
func (t *ChronoZonedDateTimeImpl) Plus_J_TemporalUnit__ChronoZonedDateTime(amountToAdd int64, unit TemporalUnit) ChronoZonedDateTime {
	if ChronoUnit_InstanceOf(unit) {
		return t.With_TemporalAdjuster__ChronoZonedDateTime(Up_ChronoLocalDateTimeImpl_TemporalAdjuster(NN(t.F_dateTime).Plus_J_TemporalUnit__ChronoLocalDateTimeImpl(amountToAdd, unit))) } else {
			return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(ChronoZonedDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoZonedDateTimeImpl(t.GetChronology__Chronology(), unit.AddTo_Temporal_J__Temporal(t, amountToAdd)))
		} }
func (t *ChronoZonedDateTimeImpl) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	Objects_RequireNonNull_O_String__O(endExclusive, Lit_2035)
	var end ChronoZonedDateTime = t.GetChronology__Chronology().ZonedDateTime_TemporalAccessor__ChronoZonedDateTime(endExclusive)


	if ChronoUnit_InstanceOf(unit) {

		end = end.WithZoneSameInstant_ZoneId__ChronoZonedDateTime(Up_ZoneOffset_ZoneId(t.F_offset))
		var tmp1 *ChronoLocalDateTimeImpl = t.F_dateTime; return NN(tmp1).Until_Temporal_TemporalUnit__J(end.ToLocalDateTime__ChronoLocalDateTime(), unit) } else {
			Objects_RequireNonNull_O_String__O(unit, Lit_1921); return unit.Between_Temporal_Temporal__J(t, end)
		} }
func (t *ChronoZonedDateTimeImpl) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.chrono.ChronoZonedDateTimeImpl.writeReplace()Ljava/lang/Object;")) }
















func (t *ChronoZonedDateTimeImpl) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if ChronoZonedDateTime_InstanceOf(obj) {

		return t.CompareTo_ChronoZonedDateTime__I(ChronoZonedDateTime_Cast(obj)) == 0 } else {
//line :162:1
			return false
		}
	}
}

func (t *ChronoZonedDateTimeImpl) HashCode__I() int32 {
	return t.ToLocalDateTime__ChronoLocalDateTime().HashCode__I() ^ NN(t.GetOffset__ZoneOffset()).HashCode__I() ^ Integer_RotateLeft_I_I__I(t.GetZone__ZoneId().HashCode__I(), 3)
}

func (t *ChronoZonedDateTimeImpl) ToString__String() *String {
	var str *String = Concat(t.ToLocalDateTime__ChronoLocalDateTime().ToString__String(), NN(t.GetOffset__ZoneOffset()).ToString__String())
	if any(t.GetOffset__ZoneOffset().Ref()) == any(t.GetZone__ZoneId()) { } else {
		str = Concat(str, Lit_1318, t.GetZone__ZoneId().ToString__String(), Lit_1189) }
//line :172:1
	return str
}




type ChronoZonedDateTimeImpl struct{ Object; F_dateTime *ChronoLocalDateTimeImpl; F_offset *ZoneOffset; F_zone ZoneId_I }

func (t *ChronoZonedDateTimeImpl) Is_ChronoZonedDateTime() {}

func (t *ChronoZonedDateTimeImpl) Is_Serializable() {}

func (t *ChronoZonedDateTimeImpl) Is_Temporal() {}

func (t *ChronoZonedDateTimeImpl) Is_Comparable() {}

func (t *ChronoZonedDateTimeImpl) Is_TemporalAccessor() {}

const ChronoZonedDateTimeImpl_serialVersionUID int64 = -5261813987200935591

func (t *ChronoZonedDateTimeImpl) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return t.With_TemporalField_J__ChronoZonedDateTime(p0, p1) }

func (t *ChronoZonedDateTimeImpl) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return t.Plus_J_TemporalUnit__ChronoZonedDateTime(p0, p1) }

func (t *ChronoZonedDateTimeImpl) Minus_TemporalAmount__ChronoZonedDateTime(p0 TemporalAmount) ChronoZonedDateTime { return ChronoZonedDateTime_Minus_TemporalAmount__ChronoZonedDateTime(t, p0) }

func (t *ChronoZonedDateTimeImpl) IsAfter_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool { return ChronoZonedDateTime_IsAfter_ChronoZonedDateTime__Z(t, p0) }

func (t *ChronoZonedDateTimeImpl) Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange { return ChronoZonedDateTime_Range_TemporalField__ValueRange(t, p0) }

func (t *ChronoZonedDateTimeImpl) ToLocalTime__LocalTime() *LocalTime { return ChronoZonedDateTime_ToLocalTime__LocalTime(t) }

func (t *ChronoZonedDateTimeImpl) IsEqual_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool { return ChronoZonedDateTime_IsEqual_ChronoZonedDateTime__Z(t, p0) }

func (t *ChronoZonedDateTimeImpl) IsBefore_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool { return ChronoZonedDateTime_IsBefore_ChronoZonedDateTime__Z(t, p0) }

func (t *ChronoZonedDateTimeImpl) ToLocalDate__ChronoLocalDate() ChronoLocalDate { return ChronoZonedDateTime_ToLocalDate__ChronoLocalDate(t) }

func (t *ChronoZonedDateTimeImpl) With_TemporalAdjuster__ChronoZonedDateTime(p0 TemporalAdjuster) ChronoZonedDateTime { return ChronoZonedDateTime_With_TemporalAdjuster__ChronoZonedDateTime(t, p0) }

func (t *ChronoZonedDateTimeImpl) Format_DateTimeFormatter__String(p0 *DateTimeFormatter) *String { return ChronoZonedDateTime_Format_DateTimeFormatter__String(t, p0) }

func (t *ChronoZonedDateTimeImpl) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return ChronoZonedDateTime_Minus_TemporalAmount__Temporal(t, p0) }

func (t *ChronoZonedDateTimeImpl) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return ChronoZonedDateTime_Plus_TemporalAmount__Temporal(t, p0) }

func (t *ChronoZonedDateTimeImpl) Query_TemporalQuery__O(p0 TemporalQuery) any { return ChronoZonedDateTime_Query_TemporalQuery__O(t, p0) }

func (t *ChronoZonedDateTimeImpl) Minus_J_TemporalUnit__ChronoZonedDateTime(p0 int64, p1 TemporalUnit) ChronoZonedDateTime { return ChronoZonedDateTime_Minus_J_TemporalUnit__ChronoZonedDateTime(t, p0, p1) }

func (t *ChronoZonedDateTimeImpl) Plus_TemporalAmount__ChronoZonedDateTime(p0 TemporalAmount) ChronoZonedDateTime { return ChronoZonedDateTime_Plus_TemporalAmount__ChronoZonedDateTime(t, p0) }

func (t *ChronoZonedDateTimeImpl) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return ChronoZonedDateTime_Minus_J_TemporalUnit__Temporal(t, p0, p1) }

func (t *ChronoZonedDateTimeImpl) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return ChronoZonedDateTime_With_TemporalAdjuster__Temporal(t, p0) }

func (t *ChronoZonedDateTimeImpl) ToInstant__Instant() *Instant { return ChronoZonedDateTime_ToInstant__Instant(t) }

func (t *ChronoZonedDateTimeImpl) ToEpochSecond__J() int64 { return ChronoZonedDateTime_ToEpochSecond__J(t) }

func (t *ChronoZonedDateTimeImpl) CompareTo_O__I(p0 any) int32 { return ChronoZonedDateTime_CompareTo_O__I(t, p0) }

func (t *ChronoZonedDateTimeImpl) GetLong_TemporalField__J(p0 TemporalField) int64 { return ChronoZonedDateTime_GetLong_TemporalField__J(t, p0) }

func (t *ChronoZonedDateTimeImpl) Get_TemporalField__I(p0 TemporalField) int32 { return ChronoZonedDateTime_Get_TemporalField__I(t, p0) }

func (t *ChronoZonedDateTimeImpl) CompareTo_ChronoZonedDateTime__I(p0 ChronoZonedDateTime) int32 { return ChronoZonedDateTime_CompareTo_ChronoZonedDateTime__I(t, p0) }

func (t *ChronoZonedDateTimeImpl) IsSupported_TemporalUnit__Z(p0 TemporalUnit) bool { return ChronoZonedDateTime_IsSupported_TemporalUnit__Z(t, p0) }

func (t *ChronoZonedDateTimeImpl) GetChronology__Chronology() Chronology { return ChronoZonedDateTime_GetChronology__Chronology(t) }

func (t *ChronoZonedDateTimeImpl) Ref() any { if t == nil { return nil }; return t }

func (t *ChronoZonedDateTimeImpl) GetClass__Class() *Class { return ChronoZonedDateTimeImpl_class }

func (t *ChronoZonedDateTimeImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ChronoZonedDateTimeImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ChronoZonedDateTimeImpl_InstanceOf(x any) bool { _, ok := x.(*ChronoZonedDateTimeImpl); return ok }

func ChronoZonedDateTimeImpl_Cast(x any) *ChronoZonedDateTimeImpl { if x == nil { return nil }; v, ok := x.(*ChronoZonedDateTimeImpl); if !ok { panic(ClassCast(x, ChronoZonedDateTimeImpl_class)) }; return v }
