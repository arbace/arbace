//line java_time_zone_ZoneOffsetTransitionRule.ae:1
package jrt





































func ZoneOffsetTransitionRule_Of_Month_I_DayOfWeek_LocalTime_Z_ZoneOffsetTransitionRule_TimeDefinition_ZoneOffset_ZoneOffset_ZoneOffset__ZoneOffsetTransitionRule(month *Month, dayOfMonthIndicator int32, dayOfWeek *DayOfWeek, time *LocalTime, timeEndOfDay bool, timeDefinition *ZoneOffsetTransitionRule_TimeDefinition, standardOffset, offsetBefore, offsetAfter *ZoneOffset) *ZoneOffsetTransitionRule { ZoneOffsetTransitionRule_Init()






	Objects_RequireNonNull_O_String__O(month.Ref(), Lit_1781)
	Objects_RequireNonNull_O_String__O(time.Ref(), Lit_2051)
	Objects_RequireNonNull_O_String__O(timeDefinition.Ref(), Lit_2562)
	Objects_RequireNonNull_O_String__O(standardOffset.Ref(), Lit_2563)
	Objects_RequireNonNull_O_String__O(offsetBefore.Ref(), Lit_2553)
	Objects_RequireNonNull_O_String__O(offsetAfter.Ref(), Lit_2554)
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = dayOfMonthIndicator < -28; if !tmp3 { tmp3 = dayOfMonthIndicator > 31 }; tmp2 = tmp3; if !tmp2 {
		tmp2 = dayOfMonthIndicator == 0 }
//line :52:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_2564)))
	}
	var tmp4 bool; var tmp5 bool; tmp5 = timeEndOfDay; if tmp5 { var tmp6 *LocalTime; LocalTime_Init(); tmp6 = LocalTime_MIDNIGHT; tmp5 = NN(time).Equals_O__Z(tmp6.Ref()) == false }; tmp4 = tmp5; if tmp4 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2565))) }
	if NN(time).GetNano__I() == 0 { } else {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2566))) }
	return ZoneOffsetTransitionRule_New_Month_I_DayOfWeek_LocalTime_Z_ZoneOffsetTransitionRule_TimeDefinition_ZoneOffset_ZoneOffset_ZoneOffset(month, dayOfMonthIndicator, dayOfWeek, time, timeEndOfDay, timeDefinition, standardOffset, offsetBefore, offsetAfter)
}








func ZoneOffsetTransitionRule_New_Month_I_DayOfWeek_LocalTime_Z_ZoneOffsetTransitionRule_TimeDefinition_ZoneOffset_ZoneOffset_ZoneOffset(p0 *Month, p1 int32, p2 *DayOfWeek, p3 *LocalTime, p4 bool, p5 *ZoneOffsetTransitionRule_TimeDefinition, p6, p7, p8 *ZoneOffset) *ZoneOffsetTransitionRule { ZoneOffsetTransitionRule_Init(); t := &ZoneOffsetTransitionRule{}; t.Ctor_Month_I_DayOfWeek_LocalTime_Z_ZoneOffsetTransitionRule_TimeDefinition_ZoneOffset_ZoneOffset_ZoneOffset(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :70:1
func (t *ZoneOffsetTransitionRule) Ctor_Month_I_DayOfWeek_LocalTime_Z_ZoneOffsetTransitionRule_TimeDefinition_ZoneOffset_ZoneOffset_ZoneOffset(month *Month, dayOfMonthIndicator int32, dayOfWeek *DayOfWeek, time *LocalTime, timeEndOfDay bool, timeDefinition *ZoneOffsetTransitionRule_TimeDefinition, standardOffset, offsetBefore, offsetAfter *ZoneOffset) {


	if !A2g_AssertionsDisabled && !(NN(time).GetNano__I() == 0) { panic(Thrown(AssertionError_New())) }
	t.F_month = month
	t.F_dom = int8(dayOfMonthIndicator)
	t.F_dow = dayOfWeek
	t.F_time = time
	t.F_timeEndOfDay = timeEndOfDay
	t.F_timeDefinition = timeDefinition
	t.F_standardOffset = standardOffset
	t.F_offsetBefore = offsetBefore
	t.F_offsetAfter = offsetAfter
}



func (t *ZoneOffsetTransitionRule) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.zone.ZoneOffsetTransitionRule.writeReplace()Ljava/lang/Object;")) }







































func ZoneOffsetTransitionRule_ReadExternal_DataInput__ZoneOffsetTransitionRule(in DataInput) *ZoneOffsetTransitionRule { ZoneOffsetTransitionRule_Init()
	var data int32 = in.ReadInt__I(); var month *Month = Month_Of_I__Month(int32(uint32(data) >> 28)); var dom int32 = int32(uint32(data&264241152)>>22) - 32; var dowByte int32 = int32(uint32(data&3670016) >> 19); var dow *DayOfWeek





	if dowByte == 0 { dow = nil } else { dow = DayOfWeek_Of_I__DayOfWeek(dowByte) }
//line :128:1
	var timeByte int32 = int32(uint32(data&507904) >> 14); var defn *ZoneOffsetTransitionRule_TimeDefinition = As[*ZoneOffsetTransitionRule_TimeDefinition](ZoneOffsetTransitionRule_TimeDefinition_Values__ZoneOffsetTransitionRule_TimeDefinition1().A[int32(uint32(data&12288)>>12)]); var stdByte int32 = int32(uint32(data&4080) >> 4); var beforeByte int32 = int32(uint32(data&12) >> 2); var afterByte int32 = data & 3; var time *LocalTime












	if timeByte == 31 {
		time = LocalTime_OfSecondOfDay_J__LocalTime(int64(in.ReadInt__I())) } else {
			time = LocalTime_Of_I_I__LocalTime(timeByte%24, 0) }
//line :128:1
	var std *ZoneOffset















	if stdByte == 255 {
		std = ZoneOffset_OfTotalSeconds_I__ZoneOffset(in.ReadInt__I()) } else {
			std = ZoneOffset_OfTotalSeconds_I__ZoneOffset((stdByte - 128) * 900) }
//line :128:1
	var before *ZoneOffset



















	if beforeByte == 3 {
		before = ZoneOffset_OfTotalSeconds_I__ZoneOffset(in.ReadInt__I()) } else {
			before = ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(std).GetTotalSeconds__I() + beforeByte*1800) }
//line :128:1
	var after *ZoneOffset

























	if afterByte == 3 {
		after = ZoneOffset_OfTotalSeconds_I__ZoneOffset(in.ReadInt__I()) } else {
			after = ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(std).GetTotalSeconds__I() + afterByte*1800)
		}


	return ZoneOffsetTransitionRule_Of_Month_I_DayOfWeek_LocalTime_Z_ZoneOffsetTransitionRule_TimeDefinition_ZoneOffset_ZoneOffset_ZoneOffset__ZoneOffsetTransitionRule(month, dom, dow, time, timeByte == 24, defn, std, before, after)
}
func (t *ZoneOffsetTransitionRule) GetMonth__Month() *Month { return t.F_month }

func (t *ZoneOffsetTransitionRule) GetDayOfMonthIndicator__I() int32 { return int32(t.F_dom) }

func (t *ZoneOffsetTransitionRule) GetDayOfWeek__DayOfWeek() *DayOfWeek { return t.F_dow }

func (t *ZoneOffsetTransitionRule) GetLocalTime__LocalTime() *LocalTime { return t.F_time }

func (t *ZoneOffsetTransitionRule) IsMidnightEndOfDay__Z() bool { return t.F_timeEndOfDay }

func (t *ZoneOffsetTransitionRule) GetTimeDefinition__ZoneOffsetTransitionRule_TimeDefinition() *ZoneOffsetTransitionRule_TimeDefinition { return t.F_timeDefinition }


func (t *ZoneOffsetTransitionRule) GetStandardOffset__ZoneOffset() *ZoneOffset { return t.F_standardOffset }

func (t *ZoneOffsetTransitionRule) GetOffsetBefore__ZoneOffset() *ZoneOffset { return t.F_offsetBefore }

func (t *ZoneOffsetTransitionRule) GetOffsetAfter__ZoneOffset() *ZoneOffset { return t.F_offsetAfter }

func (t *ZoneOffsetTransitionRule) CreateTransition_I__ZoneOffsetTransition(year int32) *ZoneOffsetTransition {
	var date *LocalDate
	if int32(t.F_dom) < 0 {

		var tmp1 *Month = t.F_month; var tmp2 *Month = t.F_month; var tmp3 *IsoChronology; IsoChronology_Init(); tmp3 = IsoChronology_INSTANCE; date = LocalDate_Of_I_Month_I__LocalDate(year, tmp1, NN(tmp2).Length_Z__I(NN(tmp3).IsLeapYear_J__Z(int64(year)))+1+int32(t.F_dom))







		if !(t.F_dow == nil) { date = NN(date).With_TemporalAdjuster__LocalDate(TemporalAdjusters_PreviousOrSame_DayOfWeek__TemporalAdjuster(t.F_dow)) } } else {

			date = LocalDate_Of_I_Month_I__LocalDate(year, t.F_month, int32(t.F_dom))
			if !(t.F_dow == nil) { date = NN(date).With_TemporalAdjuster__LocalDate(TemporalAdjusters_NextOrSame_DayOfWeek__TemporalAdjuster(t.F_dow)) } }
	if t.F_timeEndOfDay { date = NN(date).PlusDays_J__LocalDate(1) }
	var localDT *LocalDateTime = LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(date, t.F_time); var transition *LocalDateTime = NN(t.F_timeDefinition).CreateDateTime_LocalDateTime_ZoneOffset_ZoneOffset__LocalDateTime(localDT, t.F_standardOffset, t.F_offsetBefore)

	return ZoneOffsetTransition_New_LocalDateTime_ZoneOffset_ZoneOffset(transition, t.F_offsetBefore, t.F_offsetAfter)
}
func (t *ZoneOffsetTransitionRule) Equals_O__Z(otherRule any) bool {
	if any(otherRule) == any(t) { return true } else {

		var tmp1 any = otherRule; if ZoneOffsetTransitionRule_InstanceOf(tmp1) { var other *ZoneOffsetTransitionRule = ZoneOffsetTransitionRule_Cast(tmp1); var tmp2 *Month = t.F_month
			if tmp2 == other.F_month {
				var tmp3 int32 = int32(t.F_dom); if tmp3 == int32(other.F_dom) {
					var tmp4 *DayOfWeek = t.F_dow; if tmp4 == other.F_dow {
						var tmp5 *ZoneOffsetTransitionRule_TimeDefinition = t.F_timeDefinition; if tmp5 == other.F_timeDefinition {
							var tmp6 bool = t.F_timeEndOfDay; if tmp6 == other.F_timeEndOfDay {
								var tmp7 *LocalTime = t.F_time; if NN(tmp7).Equals_O__Z(other.F_time.Ref()) {
									var tmp8 *ZoneOffset = t.F_standardOffset; if NN(tmp8).Equals_O__Z(other.F_standardOffset.Ref()) {
										var tmp9 *ZoneOffset = t.F_offsetBefore; if NN(tmp9).Equals_O__Z(other.F_offsetBefore.Ref()) {
											var tmp10 *ZoneOffset = t.F_offsetAfter; return NN(tmp10).Equals_O__Z(other.F_offsetAfter.Ref()) } else {
//line :213:1
												return false } } else {
//line :212:1
													return false
												} } else {
//line :211:1
													return false
												}
							} else {
//line :210:1
								return false
							}

						} else {
//line :209:1
							return false
						}


					} else {
//line :208:1
						return false
					}



				} else {
//line :207:1
					return false
				}




			} else {
//line :206:1
				return false
			}





		} else {
//line :205:1
			return false
		}
	}
}
















func (t *ZoneOffsetTransitionRule) HashCode__I() int32 {
	var hash int32; var tmp1 int32 = NN(t.F_time).ToSecondOfDay__I(); var tmp2 int32




	if t.F_timeEndOfDay { tmp2 = 1 } else { tmp2 = 0 }
//line :226:1
	var tmp3 int32 = (tmp1+tmp2)<<15 + NN(t.F_month).Ordinal__I()<<11 + (int32(t.F_dom)+32)<<5; var tmp4 int32








	if t.F_dow == nil { tmp4 = 7 } else { tmp4 = NN(t.F_dow).Ordinal__I() }
//line :226:1
	var tmp5 int32 = tmp3 + tmp4<<2; hash = tmp5 + NN(t.F_timeDefinition).Ordinal__I()










	return hash ^ NN(t.F_standardOffset).HashCode__I() ^ NN(t.F_offsetBefore).HashCode__I() ^ NN(t.F_offsetAfter).HashCode__I()
}


func (t *ZoneOffsetTransitionRule) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New(); var tmp1 *StringBuilder = NN(buf).Append_String__StringBuilder(Lit_2567); var tmp2 *String


	if NN(t.F_offsetBefore).CompareTo_ZoneOffset__I(t.F_offsetAfter) > 0 { tmp2 = Lit_2568 } else { tmp2 = Lit_2569 }
//line :243:1
	NN(NN(NN(NN(NN(tmp1).Append_String__StringBuilder(tmp2)).Append_O__StringBuilder(t.F_offsetBefore.Ref())).Append_String__StringBuilder(Lit_2561)).Append_O__StringBuilder(t.F_offsetAfter.Ref())).Append_String__StringBuilder(Lit_1178)








	if !(t.F_dow == nil) {
		if int32(t.F_dom) == -1 {

			NN(NN(NN(buf).Append_String__StringBuilder(NN(t.F_dow).Name__String())).Append_String__StringBuilder(Lit_2570)).Append_String__StringBuilder(NN(t.F_month).Name__String()) } else {
//line :253:1
				if int32(t.F_dom) < 0 {




					NN(NN(NN(NN(NN(buf).Append_String__StringBuilder(NN(t.F_dow).Name__String())).Append_String__StringBuilder(Lit_2571)).Append_I__StringBuilder(-int32(t.F_dom) - 1)).Append_String__StringBuilder(Lit_2572)).Append_String__StringBuilder(NN(t.F_month).Name__String()) } else {






						NN(NN(NN(NN(NN(buf).Append_String__StringBuilder(NN(t.F_dow).Name__String())).Append_String__StringBuilder(Lit_2573)).Append_String__StringBuilder(NN(t.F_month).Name__String())).Append_C__StringBuilder(32)).Append_I__StringBuilder(int32(t.F_dom)) } } } else {



							NN(NN(NN(buf).Append_String__StringBuilder(NN(t.F_month).Name__String())).Append_C__StringBuilder(32)).Append_I__StringBuilder(int32(t.F_dom)) }
	var tmp3 *StringBuilder = NN(buf).Append_String__StringBuilder(Lit_2560); var tmp4 *String


	if t.F_timeEndOfDay { tmp4 = Lit_2574 } else { tmp4 = NN(t.F_time).ToString__String() }
//line :270:1
	NN(NN(NN(NN(NN(NN(tmp3).Append_String__StringBuilder(tmp4)).Append_String__StringBuilder(Lit_115)).Append_O__StringBuilder(t.F_timeDefinition.Ref())).Append_String__StringBuilder(Lit_2575)).Append_O__StringBuilder(t.F_standardOffset.Ref())).Append_C__StringBuilder(93)








	return NN(buf).ToString__String()
}



func (t *ZoneOffsetTransitionRule_TimeDefinition) CreateDateTime_LocalDateTime_ZoneOffset_ZoneOffset__LocalDateTime(dateTime *LocalDateTime, standardOffset, wallOffset *ZoneOffset) *LocalDateTime {


	switch NN(t).F_ordinal { case 0:

		var difference int32; var tmp1 int32 = NN(wallOffset).GetTotalSeconds__I(); var tmp2 *ZoneOffset; ZoneOffset_Init(); tmp2 = ZoneOffset_UTC; difference = tmp1 - NN(tmp2).GetTotalSeconds__I()


		return NN(dateTime).PlusSeconds_J__LocalDateTime(int64(difference)); case 2:

		var difference_2 int32 = NN(wallOffset).GetTotalSeconds__I() - NN(standardOffset).GetTotalSeconds__I()


		return NN(dateTime).PlusSeconds_J__LocalDateTime(int64(difference_2)); default:
//line :287:1
		return dateTime
	}








	panic("a2g: unreachable")
}


type ZoneOffsetTransitionRule struct{ Object; F_month *Month; F_dom int8; F_dow *DayOfWeek; F_time *LocalTime; F_timeEndOfDay bool; F_timeDefinition *ZoneOffsetTransitionRule_TimeDefinition; F_standardOffset, F_offsetBefore, F_offsetAfter *ZoneOffset }

func (t *ZoneOffsetTransitionRule) Is_Serializable() {}

const ZoneOffsetTransitionRule_serialVersionUID int64 = 6889046316657758795

var ZoneOffsetTransitionRule_init ClassInit

func ZoneOffsetTransitionRule_Init() { if !ZoneOffsetTransitionRule_init.Done() { ZoneOffsetTransitionRule_init.Run(ZoneOffsetTransitionRule_clinit) } }

func ZoneOffsetTransitionRule_clinit() {}

func (t *ZoneOffsetTransitionRule) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneOffsetTransitionRule) GetClass__Class() *Class { return ZoneOffsetTransitionRule_class }

func (t *ZoneOffsetTransitionRule) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneOffsetTransitionRule) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneOffsetTransitionRule_InstanceOf(x any) bool { _, ok := x.(*ZoneOffsetTransitionRule); return ok }

func ZoneOffsetTransitionRule_Cast(x any) *ZoneOffsetTransitionRule { if x == nil { return nil }; v, ok := x.(*ZoneOffsetTransitionRule); if !ok { panic(ClassCast(x, ZoneOffsetTransitionRule_class)) }; return v }



type ZoneOffsetTransitionRule_TimeDefinition struct{ Enum }

func (t *ZoneOffsetTransitionRule_TimeDefinition) Is_Constable() {}

var ZoneOffsetTransitionRule_TimeDefinition_UTC *ZoneOffsetTransitionRule_TimeDefinition

var ZoneOffsetTransitionRule_TimeDefinition_WALL *ZoneOffsetTransitionRule_TimeDefinition

var ZoneOffsetTransitionRule_TimeDefinition_STANDARD *ZoneOffsetTransitionRule_TimeDefinition

var ZoneOffsetTransitionRule_TimeDefinition__VALUES *RefArray

var ZoneOffsetTransitionRule_TimeDefinition_init ClassInit

func ZoneOffsetTransitionRule_TimeDefinition_Init() { if !ZoneOffsetTransitionRule_TimeDefinition_init.Done() { ZoneOffsetTransitionRule_TimeDefinition_init.Run(ZoneOffsetTransitionRule_TimeDefinition_clinit) } }

func ZoneOffsetTransitionRule_TimeDefinition_clinit() { ZoneOffsetTransitionRule_TimeDefinition_UTC = ZoneOffsetTransitionRule_TimeDefinition_New_String_I(Lit_2145, 0); ZoneOffsetTransitionRule_TimeDefinition_WALL = ZoneOffsetTransitionRule_TimeDefinition_New_String_I(Lit_2576, 1); ZoneOffsetTransitionRule_TimeDefinition_STANDARD = ZoneOffsetTransitionRule_TimeDefinition_New_String_I(Lit_1880, 2); ZoneOffsetTransitionRule_TimeDefinition__VALUES = ZoneOffsetTransitionRule_TimeDefinition_X_values__ZoneOffsetTransitionRule_TimeDefinition1() }

func ZoneOffsetTransitionRule_TimeDefinition_New_String_I(p0 *String, p1 int32) *ZoneOffsetTransitionRule_TimeDefinition { ZoneOffsetTransitionRule_TimeDefinition_Init(); t := &ZoneOffsetTransitionRule_TimeDefinition{}; t.Ctor_String_I(p0, p1); return t }

func (t *ZoneOffsetTransitionRule_TimeDefinition) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func ZoneOffsetTransitionRule_TimeDefinition_Values__ZoneOffsetTransitionRule_TimeDefinition1() *RefArray { ZoneOffsetTransitionRule_TimeDefinition_Init(); return ZoneOffsetTransitionRule_TimeDefinition__VALUES.Copy() }

func ZoneOffsetTransitionRule_TimeDefinition_ValueOf_String__ZoneOffsetTransitionRule_TimeDefinition(p0 *String) *ZoneOffsetTransitionRule_TimeDefinition { ZoneOffsetTransitionRule_TimeDefinition_Init(); return ZoneOffsetTransitionRule_TimeDefinition_Cast(Enum_ValueOf_Class_String__Enum(ZoneOffsetTransitionRule_TimeDefinition_class, p0)) }

func ZoneOffsetTransitionRule_TimeDefinition_X_values__ZoneOffsetTransitionRule_TimeDefinition1() *RefArray { ZoneOffsetTransitionRule_TimeDefinition_Init(); return RefArrayOf(ZoneOffsetTransitionRule_TimeDefinition_class, ZoneOffsetTransitionRule_TimeDefinition_UTC, ZoneOffsetTransitionRule_TimeDefinition_WALL, ZoneOffsetTransitionRule_TimeDefinition_STANDARD) }

func (t *ZoneOffsetTransitionRule_TimeDefinition) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ZoneOffsetTransitionRule_TimeDefinition) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ZoneOffsetTransitionRule_TimeDefinition) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ZoneOffsetTransitionRule_TimeDefinition) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.zone.ZoneOffsetTransitionRule$TimeDefinition.describeConstable()Ljava/util/Optional;")) }

func (t *ZoneOffsetTransitionRule_TimeDefinition) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ZoneOffsetTransitionRule_TimeDefinition) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ZoneOffsetTransitionRule_TimeDefinition) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneOffsetTransitionRule_TimeDefinition) GetClass__Class() *Class { return ZoneOffsetTransitionRule_TimeDefinition_class }

func (t *ZoneOffsetTransitionRule_TimeDefinition) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneOffsetTransitionRule_TimeDefinition_InstanceOf(x any) bool { _, ok := x.(*ZoneOffsetTransitionRule_TimeDefinition); return ok }

func ZoneOffsetTransitionRule_TimeDefinition_Cast(x any) *ZoneOffsetTransitionRule_TimeDefinition { if x == nil { return nil }; v, ok := x.(*ZoneOffsetTransitionRule_TimeDefinition); if !ok { panic(ClassCast(x, ZoneOffsetTransitionRule_TimeDefinition_class)) }; return v }
