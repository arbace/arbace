//line java_util_ArrayPrefixHelpers.ae:1
package jrt










func ArrayPrefixHelpers_New() *ArrayPrefixHelpers { t := &ArrayPrefixHelpers{}; t.Ctor(); return t }
//line :12:1
func (t *ArrayPrefixHelpers) Ctor() { panic(A2g_NotTranslated("java.util.ArrayPrefixHelpers.<init>()V")) }



































func ArrayPrefixHelpers_CumulateTask_New_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I(p0 *ArrayPrefixHelpers_CumulateTask, p1 BinaryOperator, p2 *RefArray, p3, p4 int32) *ArrayPrefixHelpers_CumulateTask { ArrayPrefixHelpers_CumulateTask_Init(); t := &ArrayPrefixHelpers_CumulateTask{}; t.Ctor_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I(p0, p1, p2, p3, p4); return t }
//line :48:1
func (t *ArrayPrefixHelpers_CumulateTask) Ctor_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I(parent *ArrayPrefixHelpers_CumulateTask, function BinaryOperator, array *RefArray, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_CumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	var tmp1 int32; var tmp2 int32 = lo; t.F_origin = tmp2; tmp1 = tmp2; t.F_lo = tmp1
	var tmp3 int32; var tmp4 int32 = hi; t.F_fence = tmp4; tmp3 = tmp4; t.F_hi = tmp3
	var p int32 = 0; var tmp5 int32; var tmp6 int32

	p = (hi - lo) / (ForkJoinPool_GetCommonPoolParallelism__I() << 3); tmp6 = p; if tmp6 <= 16 { tmp5 = 16 } else { tmp5 = p }
//line :56:1
	t.F_threshold = tmp5
}







func ArrayPrefixHelpers_CumulateTask_New_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I_I_I_I(p0 *ArrayPrefixHelpers_CumulateTask, p1 BinaryOperator, p2 *RefArray, p3, p4, p5, p6, p7 int32) *ArrayPrefixHelpers_CumulateTask { ArrayPrefixHelpers_CumulateTask_Init(); t := &ArrayPrefixHelpers_CumulateTask{}; t.Ctor_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :65:1
func (t *ArrayPrefixHelpers_CumulateTask) Ctor_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I_I_I_I(parent *ArrayPrefixHelpers_CumulateTask, function BinaryOperator, array *RefArray, origin, fence, threshold, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_CumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	t.F_origin = origin
	t.F_fence = fence
	t.F_threshold = threshold
	t.F_lo = lo
	t.F_hi = hi
}
func (t *ArrayPrefixHelpers_CumulateTask) Compute__V() {
	var fn BinaryOperator; var a *RefArray; var tmp1 bool; var tmp2 bool; var tmp3 BinaryOperator

	fn = t.F_function; tmp3 = fn; tmp2 = tmp3 == nil; if !tmp2 { var tmp4 *RefArray; a = t.F_array; tmp4 = a; tmp2 = tmp4 == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NullPointerException_New())) }
	var th int32 = t.F_threshold; var org int32 = t.F_origin; var fnc int32 = t.F_fence
	var l int32 = 0
	var h int32 = 0
	var t_ /*line :81:1*/*ArrayPrefixHelpers_CumulateTask = t





L1: switch { default: L2: for { var tmp5 bool; var tmp6 bool; var tmp7 int32
	l = t_.F_lo; tmp7 = l; tmp6 = tmp7 >= 0; if tmp6 { var tmp8 int32; h = t_.F_hi; tmp8 = h; var tmp9 int32 = tmp8; tmp6 = tmp9 <= int32(len(a.A)) }; tmp5 = tmp6
//line :87:1
	if tmp5 {

		if h-l > th {
			var lt *ArrayPrefixHelpers_CumulateTask = t_.F_left; var rt *ArrayPrefixHelpers_CumulateTask = t_.F_right; var f *ArrayPrefixHelpers_CumulateTask


			if lt == nil {
				var mid int32 = int32(uint32(l+h) >> 1); var tmp10 *ArrayPrefixHelpers_CumulateTask; var tmp11 *ArrayPrefixHelpers_CumulateTask; var tmp12 *ArrayPrefixHelpers_CumulateTask = ArrayPrefixHelpers_CumulateTask_New_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I_I_I_I(t_, fn, a, org, fnc, th, mid, h)


				t_.F_right = tmp12; tmp11 = tmp12; rt = tmp11; tmp10 = rt
//line :95:1
				f = tmp10


				var tmp13 *ArrayPrefixHelpers_CumulateTask; var tmp14 *ArrayPrefixHelpers_CumulateTask; var tmp15 *ArrayPrefixHelpers_CumulateTask = ArrayPrefixHelpers_CumulateTask_New_ArrayPrefixHelpers_CumulateTask_BinaryOperator_O1_I_I_I_I_I(t_, fn, a, org, fnc, th, l, mid)
				t_.F_left = tmp15; tmp14 = tmp15; lt = tmp14; tmp13 = lt
//line :98:1
				t_ = tmp13 } else {

					var pin any = t_.F_in
					lt.F_in = pin
					var tmp16 *ArrayPrefixHelpers_CumulateTask; t_ = nil; tmp16 = t_; f = tmp16
					if !(rt == nil) {
						var lout any = lt.F_out; var tmp17 *ArrayPrefixHelpers_CumulateTask = rt; var tmp18 any
						if l == org { tmp18 = lout } else { tmp18 = fn.Apply_O_O__O(pin, lout) }; tmp17.F_in = tmp18
						var c int32 = 0
					L3: for {
						var tmp19 int32
						c = NN(rt).GetPendingCount__I(); tmp19 = c
//line :108:1
						if tmp19&1 == 0 { } else {



							break L3 }
						if NN(rt).CompareAndSetPendingCount_I_I__Z(c, c|1) {
							t_ = rt
							break L3 }
//line :107:1
						continue L3
					}
					}






					var c_2 int32 = 0
				L4: for {
					var tmp20 int32; c_2 = NN(lt).GetPendingCount__I(); tmp20 = c_2; if tmp20&1 == 0 { } else {
						break L4 }
					if NN(lt).CompareAndSetPendingCount_I_I__Z(c_2, c_2|1) {
						if !(t_ == nil) { f = t_ }
						t_ = lt
						break L4 }
//line :117:1
					continue L4
				}





					if t_ == nil { break L2 } }
			if !(f == nil) { NN(f).Fork__ForkJoinTask() } } else {
				var state int32 = 0
				var b int32 = 0
			L5: for {
				var tmp21 int32; b = NN(t_).GetPendingCount__I(); tmp21 = b; if tmp21&4 == 0 { } else {
					break L1 }
				var tmp22 int32
				if !(b&1 == 0) { tmp22 = 4 } else { if l > org { tmp22 = 2 } else {


					tmp22 = 6 } }
//line :131:1
				state = tmp22




				if NN(t_).CompareAndSetPendingCount_I_I__Z(b, b|state) { break L5 }
//line :128:1
				continue L5
			}







				var sum any
				if !(state == 2) {

					var first int32 = 0
					if l == org {
						sum = a.A[org]; first = org + 1 } else {
							sum = t_.F_in; first = l }
					var i int32 = first; L6: for {
						if i < h {
							var tmp23 *RefArray = a; var tmp24 any; sum = fn.Apply_O_O__O(sum, a.A[i]); tmp24 = sum; tmp23.Store(i, tmp24)
							i = i + 1; continue L6 }
//line :144:1
						break L6 } } else {
//line :138:1
							if h < fnc {











								sum = a.A[l]
								var i_2 int32 = l + 1; L7: for {
									if i_2 < h {
										sum = fn.Apply_O_O__O(sum, a.A[i_2])
										i_2 = i_2 + 1; continue L7 }
//line :151:1
									break L7 } } else {



										sum = t_.F_in } }
				t_.F_out = sum
				var par *ArrayPrefixHelpers_CumulateTask
			L8: for {
				var partmp *ArrayPrefixHelpers_CumulateTask = ArrayPrefixHelpers_CumulateTask_Cast(NN(t_).GetCompleter__CountedCompleter()); var tmp25 *ArrayPrefixHelpers_CumulateTask


				par = partmp; tmp25 = par; if tmp25 == nil {
					if state&4 == 0 { } else { NN(t_).QuietlyComplete__V() }
					break L1 }
				var b_2 int32 = NN(par).GetPendingCount__I()
				if !(b_2&state&4 == 0) {

					t_ = par } else {
//line :166:1
						if !(b_2&state&2 == 0) {



							var nextState int32 = 0; var lt_2 *ArrayPrefixHelpers_CumulateTask; var rt_2 *ArrayPrefixHelpers_CumulateTask; var tmp26 bool; var tmp27 bool; var tmp28 *ArrayPrefixHelpers_CumulateTask


							lt_2 = par.F_left; tmp28 = lt_2; tmp27 = !(tmp28 == nil); if tmp27 {
								var tmp29 *ArrayPrefixHelpers_CumulateTask; rt_2 = par.F_right; tmp29 = rt_2; tmp27 = !(tmp29 == nil) }
//line :173:1
							tmp26 = tmp27; if tmp26 {

								var lout_2 any = lt_2.F_out; var tmp30 *ArrayPrefixHelpers_CumulateTask = par; var tmp31 any

								if rt_2.F_hi == fnc { tmp31 = lout_2 } else {

									tmp31 = fn.Apply_O_O__O(lout_2, rt_2.F_out) }
//line :176:1
								tmp30.F_out = tmp31
							}


							var refork int32; var tmp32 bool; var tmp33 bool
							tmp33 = b_2&1 == 0
//line :180:1
							if tmp33 {

								tmp33 = par.F_lo == org }
//line :180:1
							tmp32 = tmp33; if tmp32 { refork = 1 } else { refork = 0
							}



							var tmp34 bool; var tmp35 bool; var tmp36 int32
							nextState = b_2 | state | refork; tmp36 = nextState
//line :185:1
							tmp35 = tmp36 == b_2; if !tmp35 {




								tmp35 = NN(par).CompareAndSetPendingCount_I_I__Z(b_2, nextState) }
//line :185:1
							tmp34 = tmp35; if tmp34 {





								state = 2
								t_ = par
								if refork == 0 { } else { NN(par).Fork__ForkJoinTask() } } } else {
//line :166:1
									if NN(par).CompareAndSetPendingCount_I_I__Z(b_2, b_2|state) {




























										break L1 } } }
//line :158:1
				continue L8 } }
//line :87:1
		continue L2 }; break L2
}
}
}





































































































































func ArrayPrefixHelpers_LongCumulateTask_New_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I(p0 *ArrayPrefixHelpers_LongCumulateTask, p1 LongBinaryOperator, p2 *LongArray, p3, p4 int32) *ArrayPrefixHelpers_LongCumulateTask { ArrayPrefixHelpers_LongCumulateTask_Init(); t := &ArrayPrefixHelpers_LongCumulateTask{}; t.Ctor_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I(p0, p1, p2, p3, p4); return t }
//line :224:1
func (t *ArrayPrefixHelpers_LongCumulateTask) Ctor_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I(parent *ArrayPrefixHelpers_LongCumulateTask, function LongBinaryOperator, array *LongArray, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_LongCumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	var tmp1 int32; var tmp2 int32 = lo; t.F_origin = tmp2; tmp1 = tmp2; t.F_lo = tmp1
	var tmp3 int32; var tmp4 int32 = hi; t.F_fence = tmp4; tmp3 = tmp4; t.F_hi = tmp3
	var p int32 = 0; var tmp5 int32; var tmp6 int32

	p = (hi - lo) / (ForkJoinPool_GetCommonPoolParallelism__I() << 3); tmp6 = p; if tmp6 <= 16 { tmp5 = 16 } else { tmp5 = p }
//line :232:1
	t.F_threshold = tmp5
}







func ArrayPrefixHelpers_LongCumulateTask_New_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I_I_I_I(p0 *ArrayPrefixHelpers_LongCumulateTask, p1 LongBinaryOperator, p2 *LongArray, p3, p4, p5, p6, p7 int32) *ArrayPrefixHelpers_LongCumulateTask { ArrayPrefixHelpers_LongCumulateTask_Init(); t := &ArrayPrefixHelpers_LongCumulateTask{}; t.Ctor_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :241:1
func (t *ArrayPrefixHelpers_LongCumulateTask) Ctor_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I_I_I_I(parent *ArrayPrefixHelpers_LongCumulateTask, function LongBinaryOperator, array *LongArray, origin, fence, threshold, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_LongCumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	t.F_origin = origin
	t.F_fence = fence
	t.F_threshold = threshold
	t.F_lo = lo
	t.F_hi = hi
}
func (t *ArrayPrefixHelpers_LongCumulateTask) Compute__V() {
	var fn LongBinaryOperator; var a *LongArray; var tmp1 bool; var tmp2 bool; var tmp3 LongBinaryOperator

	fn = t.F_function; tmp3 = fn; tmp2 = tmp3 == nil; if !tmp2 { var tmp4 *LongArray; a = t.F_array; tmp4 = a; tmp2 = tmp4 == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NullPointerException_New())) }
	var th int32 = t.F_threshold; var org int32 = t.F_origin; var fnc int32 = t.F_fence
	var l int32 = 0
	var h int32 = 0
	var t_ /*line :257:1*/*ArrayPrefixHelpers_LongCumulateTask = t





L1: switch { default: L2: for { var tmp5 bool; var tmp6 bool; var tmp7 int32
	l = t_.F_lo; tmp7 = l; tmp6 = tmp7 >= 0; if tmp6 { var tmp8 int32; h = t_.F_hi; tmp8 = h; var tmp9 int32 = tmp8; tmp6 = tmp9 <= int32(len(a.A)) }; tmp5 = tmp6
//line :263:1
	if tmp5 {

		if h-l > th {
			var lt *ArrayPrefixHelpers_LongCumulateTask = t_.F_left; var rt *ArrayPrefixHelpers_LongCumulateTask = t_.F_right; var f *ArrayPrefixHelpers_LongCumulateTask


			if lt == nil {
				var mid int32 = int32(uint32(l+h) >> 1); var tmp10 *ArrayPrefixHelpers_LongCumulateTask; var tmp11 *ArrayPrefixHelpers_LongCumulateTask; var tmp12 *ArrayPrefixHelpers_LongCumulateTask = ArrayPrefixHelpers_LongCumulateTask_New_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I_I_I_I(t_, fn, a, org, fnc, th, mid, h)



				t_.F_right = tmp12; tmp11 = tmp12
//line :272:1
				rt = tmp11; tmp10 = rt
//line :271:1
				f = tmp10



				var tmp13 *ArrayPrefixHelpers_LongCumulateTask; var tmp14 *ArrayPrefixHelpers_LongCumulateTask; var tmp15 *ArrayPrefixHelpers_LongCumulateTask = ArrayPrefixHelpers_LongCumulateTask_New_ArrayPrefixHelpers_LongCumulateTask_LongBinaryOperator_J1_I_I_I_I_I(t_, fn, a, org, fnc, th, l, mid)

				t_.F_left = tmp15; tmp14 = tmp15; lt = tmp14; tmp13 = lt
//line :275:1
				t_ = tmp13 } else {


					var pin int64 = t_.F_in
					lt.F_in = pin
					var tmp16 *ArrayPrefixHelpers_LongCumulateTask; t_ = nil; tmp16 = t_; f = tmp16
					if !(rt == nil) {
						var lout int64 = lt.F_out; var tmp17 *ArrayPrefixHelpers_LongCumulateTask = rt; var tmp18 int64
						if l == org { tmp18 = lout } else { tmp18 = fn.ApplyAsLong_J_J__J(pin, lout) }; tmp17.F_in = tmp18
						var c int32 = 0
					L3: for {
						var tmp19 int32
						c = NN(rt).GetPendingCount__I(); tmp19 = c
//line :286:1
						if tmp19&1 == 0 { } else {



							break L3 }
						if NN(rt).CompareAndSetPendingCount_I_I__Z(c, c|1) {
							t_ = rt
							break L3 }
//line :285:1
						continue L3
					}
					}






					var c_2 int32 = 0
				L4: for {
					var tmp20 int32; c_2 = NN(lt).GetPendingCount__I(); tmp20 = c_2; if tmp20&1 == 0 { } else {
						break L4 }
					if NN(lt).CompareAndSetPendingCount_I_I__Z(c_2, c_2|1) {
						if !(t_ == nil) { f = t_ }
						t_ = lt
						break L4 }
//line :295:1
					continue L4
				}





					if t_ == nil { break L2 } }
			if !(f == nil) { NN(f).Fork__ForkJoinTask() } } else {
				var state int32 = 0
				var b int32 = 0
			L5: for {
				var tmp21 int32; b = NN(t_).GetPendingCount__I(); tmp21 = b; if tmp21&4 == 0 { } else {
					break L1 }
				var tmp22 int32
				if !(b&1 == 0) { tmp22 = 4 } else { if l > org { tmp22 = 2 } else {


					tmp22 = 6 } }
//line :309:1
				state = tmp22




				if NN(t_).CompareAndSetPendingCount_I_I__Z(b, b|state) { break L5 }
//line :306:1
				continue L5
			}







				var sum int64 = 0
				if !(state == 2) {

					var first int32 = 0
					if l == org {
						sum = a.A[org]; first = org + 1 } else {
							sum = t_.F_in; first = l }
					var i int32 = first; L6: for {
						if i < h {
							var tmp23 *LongArray = a; var tmp24 int64; sum = fn.ApplyAsLong_J_J__J(sum, a.A[i]); tmp24 = sum; tmp23.A[i] = tmp24
							i = i + 1; continue L6 }
//line :322:1
						break L6 } } else {
//line :316:1
							if h < fnc {











								sum = a.A[l]
								var i_2 int32 = l + 1; L7: for {
									if i_2 < h {
										sum = fn.ApplyAsLong_J_J__J(sum, a.A[i_2])
										i_2 = i_2 + 1; continue L7 }
//line :329:1
									break L7 } } else {



										sum = t_.F_in } }
				t_.F_out = sum
				var par *ArrayPrefixHelpers_LongCumulateTask
			L8: for {
				var tmp25 *ArrayPrefixHelpers_LongCumulateTask; par = ArrayPrefixHelpers_LongCumulateTask_Cast(NN(t_).GetCompleter__CountedCompleter()); tmp25 = par; if tmp25 == nil {
					if state&4 == 0 { } else { NN(t_).QuietlyComplete__V() }
					break L1 }
				var b_2 int32 = NN(par).GetPendingCount__I()
				if !(b_2&state&4 == 0) {
					t_ = par } else {
//line :341:1
						if !(b_2&state&2 == 0) {


							var nextState int32 = 0; var lt_2 *ArrayPrefixHelpers_LongCumulateTask; var rt_2 *ArrayPrefixHelpers_LongCumulateTask; var tmp26 bool; var tmp27 bool; var tmp28 *ArrayPrefixHelpers_LongCumulateTask


							lt_2 = par.F_left; tmp28 = lt_2; tmp27 = !(tmp28 == nil); if tmp27 {
								var tmp29 *ArrayPrefixHelpers_LongCumulateTask; rt_2 = par.F_right; tmp29 = rt_2; tmp27 = !(tmp29 == nil) }
//line :347:1
							tmp26 = tmp27; if tmp26 {

								var lout_2 int64 = lt_2.F_out; var tmp30 *ArrayPrefixHelpers_LongCumulateTask = par; var tmp31 int64

								if rt_2.F_hi == fnc { tmp31 = lout_2 } else {

									tmp31 = fn.ApplyAsLong_J_J__J(lout_2, rt_2.F_out) }
//line :350:1
								tmp30.F_out = tmp31
							}


							var refork int32; var tmp32 bool; var tmp33 bool
							tmp33 = b_2&1 == 0
//line :354:1
							if tmp33 {

								tmp33 = par.F_lo == org }
//line :354:1
							tmp32 = tmp33; if tmp32 { refork = 1 } else { refork = 0
							}



							var tmp34 bool; var tmp35 bool; var tmp36 int32
							nextState = b_2 | state | refork; tmp36 = nextState
//line :359:1
							tmp35 = tmp36 == b_2; if !tmp35 {




								tmp35 = NN(par).CompareAndSetPendingCount_I_I__Z(b_2, nextState) }
//line :359:1
							tmp34 = tmp35; if tmp34 {





								state = 2
								t_ = par
								if refork == 0 { } else { NN(par).Fork__ForkJoinTask() } } } else {
//line :341:1
									if NN(par).CompareAndSetPendingCount_I_I__Z(b_2, b_2|state) {


























										break L1 } } }
//line :336:1
				continue L8 } }
//line :263:1
		continue L2 }; break L2
}
}
}


































































































































func ArrayPrefixHelpers_DoubleCumulateTask_New_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I(p0 *ArrayPrefixHelpers_DoubleCumulateTask, p1 DoubleBinaryOperator, p2 *DoubleArray, p3, p4 int32) *ArrayPrefixHelpers_DoubleCumulateTask { ArrayPrefixHelpers_DoubleCumulateTask_Init(); t := &ArrayPrefixHelpers_DoubleCumulateTask{}; t.Ctor_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I(p0, p1, p2, p3, p4); return t }
//line :397:1
func (t *ArrayPrefixHelpers_DoubleCumulateTask) Ctor_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I(parent *ArrayPrefixHelpers_DoubleCumulateTask, function DoubleBinaryOperator, array *DoubleArray, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_DoubleCumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	var tmp1 int32; var tmp2 int32 = lo; t.F_origin = tmp2; tmp1 = tmp2; t.F_lo = tmp1
	var tmp3 int32; var tmp4 int32 = hi; t.F_fence = tmp4; tmp3 = tmp4; t.F_hi = tmp3
	var p int32 = 0; var tmp5 int32; var tmp6 int32

	p = (hi - lo) / (ForkJoinPool_GetCommonPoolParallelism__I() << 3); tmp6 = p; if tmp6 <= 16 { tmp5 = 16 } else { tmp5 = p }
//line :405:1
	t.F_threshold = tmp5
}







func ArrayPrefixHelpers_DoubleCumulateTask_New_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I_I_I_I(p0 *ArrayPrefixHelpers_DoubleCumulateTask, p1 DoubleBinaryOperator, p2 *DoubleArray, p3, p4, p5, p6, p7 int32) *ArrayPrefixHelpers_DoubleCumulateTask { ArrayPrefixHelpers_DoubleCumulateTask_Init(); t := &ArrayPrefixHelpers_DoubleCumulateTask{}; t.Ctor_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :414:1
func (t *ArrayPrefixHelpers_DoubleCumulateTask) Ctor_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I_I_I_I(parent *ArrayPrefixHelpers_DoubleCumulateTask, function DoubleBinaryOperator, array *DoubleArray, origin, fence, threshold, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_DoubleCumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	t.F_origin = origin
	t.F_fence = fence
	t.F_threshold = threshold
	t.F_lo = lo
	t.F_hi = hi
}
func (t *ArrayPrefixHelpers_DoubleCumulateTask) Compute__V() {
	var fn DoubleBinaryOperator; var a *DoubleArray; var tmp1 bool; var tmp2 bool; var tmp3 DoubleBinaryOperator

	fn = t.F_function; tmp3 = fn; tmp2 = tmp3 == nil; if !tmp2 { var tmp4 *DoubleArray; a = t.F_array; tmp4 = a; tmp2 = tmp4 == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NullPointerException_New())) }
	var th int32 = t.F_threshold; var org int32 = t.F_origin; var fnc int32 = t.F_fence
	var l int32 = 0
	var h int32 = 0
	var t_ /*line :430:1*/*ArrayPrefixHelpers_DoubleCumulateTask = t





L1: switch { default: L2: for { var tmp5 bool; var tmp6 bool; var tmp7 int32
	l = t_.F_lo; tmp7 = l; tmp6 = tmp7 >= 0; if tmp6 { var tmp8 int32; h = t_.F_hi; tmp8 = h; var tmp9 int32 = tmp8; tmp6 = tmp9 <= int32(len(a.A)) }; tmp5 = tmp6
//line :436:1
	if tmp5 {

		if h-l > th {
			var lt *ArrayPrefixHelpers_DoubleCumulateTask = t_.F_left; var rt *ArrayPrefixHelpers_DoubleCumulateTask = t_.F_right; var f *ArrayPrefixHelpers_DoubleCumulateTask


			if lt == nil {
				var mid int32 = int32(uint32(l+h) >> 1); var tmp10 *ArrayPrefixHelpers_DoubleCumulateTask; var tmp11 *ArrayPrefixHelpers_DoubleCumulateTask; var tmp12 *ArrayPrefixHelpers_DoubleCumulateTask = ArrayPrefixHelpers_DoubleCumulateTask_New_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I_I_I_I(t_, fn, a, org, fnc, th, mid, h)


				t_.F_right = tmp12; tmp11 = tmp12
//line :445:1
				rt = tmp11; tmp10 = rt
//line :444:1
				f = tmp10



				var tmp13 *ArrayPrefixHelpers_DoubleCumulateTask; var tmp14 *ArrayPrefixHelpers_DoubleCumulateTask; var tmp15 *ArrayPrefixHelpers_DoubleCumulateTask = ArrayPrefixHelpers_DoubleCumulateTask_New_ArrayPrefixHelpers_DoubleCumulateTask_DoubleBinaryOperator_D1_I_I_I_I_I(t_, fn, a, org, fnc, th, l, mid)

				t_.F_left = tmp15; tmp14 = tmp15
//line :449:1
				lt = tmp14; tmp13 = lt
//line :448:1
				t_ = tmp13 } else {



					var pin float64 = t_.F_in
					lt.F_in = pin
					var tmp16 *ArrayPrefixHelpers_DoubleCumulateTask; t_ = nil; tmp16 = t_; f = tmp16
					if !(rt == nil) {
						var lout float64 = lt.F_out; var tmp17 *ArrayPrefixHelpers_DoubleCumulateTask = rt; var tmp18 float64
						if l == org { tmp18 = lout } else { tmp18 = fn.ApplyAsDouble_D_D__D(pin, lout) }; tmp17.F_in = tmp18
						var c int32 = 0
					L3: for {
						var tmp19 int32
						c = NN(rt).GetPendingCount__I(); tmp19 = c
//line :460:1
						if tmp19&1 == 0 { } else {



							break L3 }
						if NN(rt).CompareAndSetPendingCount_I_I__Z(c, c|1) {
							t_ = rt
							break L3 }
//line :459:1
						continue L3
					}
					}






					var c_2 int32 = 0
				L4: for {
					var tmp20 int32; c_2 = NN(lt).GetPendingCount__I(); tmp20 = c_2; if tmp20&1 == 0 { } else {
						break L4 }
					if NN(lt).CompareAndSetPendingCount_I_I__Z(c_2, c_2|1) {
						if !(t_ == nil) { f = t_ }
						t_ = lt
						break L4 }
//line :469:1
					continue L4
				}





					if t_ == nil { break L2 } }
			if !(f == nil) { NN(f).Fork__ForkJoinTask() } } else {
				var state int32 = 0
				var b int32 = 0
			L5: for {
				var tmp21 int32; b = NN(t_).GetPendingCount__I(); tmp21 = b; if tmp21&4 == 0 { } else {
					break L1 }
				var tmp22 int32
				if !(b&1 == 0) { tmp22 = 4 } else { if l > org { tmp22 = 2 } else {


					tmp22 = 6 } }
//line :483:1
				state = tmp22




				if NN(t_).CompareAndSetPendingCount_I_I__Z(b, b|state) { break L5 }
//line :480:1
				continue L5
			}







				var sum float64 = 0.0
				if !(state == 2) {

					var first int32 = 0
					if l == org {
						sum = a.A[org]; first = org + 1 } else {
							sum = t_.F_in; first = l }
					var i int32 = first; L6: for {
						if i < h {
							var tmp23 *DoubleArray = a; var tmp24 float64; sum = fn.ApplyAsDouble_D_D__D(sum, a.A[i]); tmp24 = sum; tmp23.A[i] = tmp24
							i = i + 1; continue L6 }
//line :496:1
						break L6 } } else {
//line :490:1
							if h < fnc {











								sum = a.A[l]
								var i_2 int32 = l + 1; L7: for {
									if i_2 < h {
										sum = fn.ApplyAsDouble_D_D__D(sum, a.A[i_2])
										i_2 = i_2 + 1; continue L7 }
//line :503:1
									break L7 } } else {



										sum = t_.F_in } }
				t_.F_out = sum
				var par *ArrayPrefixHelpers_DoubleCumulateTask
			L8: for {
				var tmp25 *ArrayPrefixHelpers_DoubleCumulateTask; par = ArrayPrefixHelpers_DoubleCumulateTask_Cast(NN(t_).GetCompleter__CountedCompleter()); tmp25 = par; if tmp25 == nil {
					if state&4 == 0 { } else { NN(t_).QuietlyComplete__V() }
					break L1 }
				var b_2 int32 = NN(par).GetPendingCount__I()
				if !(b_2&state&4 == 0) {
					t_ = par } else {
//line :515:1
						if !(b_2&state&2 == 0) {


							var nextState int32 = 0; var lt_2 *ArrayPrefixHelpers_DoubleCumulateTask; var rt_2 *ArrayPrefixHelpers_DoubleCumulateTask; var tmp26 bool; var tmp27 bool; var tmp28 *ArrayPrefixHelpers_DoubleCumulateTask


							lt_2 = par.F_left; tmp28 = lt_2; tmp27 = !(tmp28 == nil); if tmp27 {
								var tmp29 *ArrayPrefixHelpers_DoubleCumulateTask; rt_2 = par.F_right; tmp29 = rt_2; tmp27 = !(tmp29 == nil) }
//line :521:1
							tmp26 = tmp27; if tmp26 {

								var lout_2 float64 = lt_2.F_out; var tmp30 *ArrayPrefixHelpers_DoubleCumulateTask = par; var tmp31 float64

								if rt_2.F_hi == fnc { tmp31 = lout_2 } else {

									tmp31 = fn.ApplyAsDouble_D_D__D(lout_2, rt_2.F_out) }
//line :524:1
								tmp30.F_out = tmp31
							}


							var refork int32; var tmp32 bool; var tmp33 bool
							tmp33 = b_2&1 == 0
//line :528:1
							if tmp33 {

								tmp33 = par.F_lo == org }
//line :528:1
							tmp32 = tmp33; if tmp32 { refork = 1 } else { refork = 0
							}



							var tmp34 bool; var tmp35 bool; var tmp36 int32
							nextState = b_2 | state | refork; tmp36 = nextState
//line :533:1
							tmp35 = tmp36 == b_2; if !tmp35 {




								tmp35 = NN(par).CompareAndSetPendingCount_I_I__Z(b_2, nextState) }
//line :533:1
							tmp34 = tmp35; if tmp34 {





								state = 2
								t_ = par
								if refork == 0 { } else { NN(par).Fork__ForkJoinTask() } } } else {
//line :515:1
									if NN(par).CompareAndSetPendingCount_I_I__Z(b_2, b_2|state) {


























										break L1 } } }
//line :510:1
				continue L8 } }
//line :436:1
		continue L2 }; break L2
}
}
}



































































































































func ArrayPrefixHelpers_IntCumulateTask_New_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I(p0 *ArrayPrefixHelpers_IntCumulateTask, p1 IntBinaryOperator, p2 *IntArray, p3, p4 int32) *ArrayPrefixHelpers_IntCumulateTask { ArrayPrefixHelpers_IntCumulateTask_Init(); t := &ArrayPrefixHelpers_IntCumulateTask{}; t.Ctor_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I(p0, p1, p2, p3, p4); return t }
//line :571:1
func (t *ArrayPrefixHelpers_IntCumulateTask) Ctor_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I(parent *ArrayPrefixHelpers_IntCumulateTask, function IntBinaryOperator, array *IntArray, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_IntCumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	var tmp1 int32; var tmp2 int32 = lo; t.F_origin = tmp2; tmp1 = tmp2; t.F_lo = tmp1
	var tmp3 int32; var tmp4 int32 = hi; t.F_fence = tmp4; tmp3 = tmp4; t.F_hi = tmp3
	var p int32 = 0; var tmp5 int32; var tmp6 int32

	p = (hi - lo) / (ForkJoinPool_GetCommonPoolParallelism__I() << 3); tmp6 = p; if tmp6 <= 16 { tmp5 = 16 } else { tmp5 = p }
//line :579:1
	t.F_threshold = tmp5
}







func ArrayPrefixHelpers_IntCumulateTask_New_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I_I_I_I(p0 *ArrayPrefixHelpers_IntCumulateTask, p1 IntBinaryOperator, p2 *IntArray, p3, p4, p5, p6, p7 int32) *ArrayPrefixHelpers_IntCumulateTask { ArrayPrefixHelpers_IntCumulateTask_Init(); t := &ArrayPrefixHelpers_IntCumulateTask{}; t.Ctor_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I_I_I_I(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :588:1
func (t *ArrayPrefixHelpers_IntCumulateTask) Ctor_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I_I_I_I(parent *ArrayPrefixHelpers_IntCumulateTask, function IntBinaryOperator, array *IntArray, origin, fence, threshold, lo, hi int32) { t.CountedCompleter.Ctor_CountedCompleter(t, Up_ArrayPrefixHelpers_IntCumulateTask_CountedCompleter(parent))


	t.F_function = function
	t.F_array = array
	t.F_origin = origin
	t.F_fence = fence
	t.F_threshold = threshold
	t.F_lo = lo
	t.F_hi = hi
}
func (t *ArrayPrefixHelpers_IntCumulateTask) Compute__V() {
	var fn IntBinaryOperator; var a *IntArray; var tmp1 bool; var tmp2 bool; var tmp3 IntBinaryOperator

	fn = t.F_function; tmp3 = fn; tmp2 = tmp3 == nil; if !tmp2 { var tmp4 *IntArray; a = t.F_array; tmp4 = a; tmp2 = tmp4 == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NullPointerException_New())) }
	var th int32 = t.F_threshold; var org int32 = t.F_origin; var fnc int32 = t.F_fence
	var l int32 = 0
	var h int32 = 0
	var t_ /*line :604:1*/*ArrayPrefixHelpers_IntCumulateTask = t





L1: switch { default: L2: for { var tmp5 bool; var tmp6 bool; var tmp7 int32
	l = t_.F_lo; tmp7 = l; tmp6 = tmp7 >= 0; if tmp6 { var tmp8 int32; h = t_.F_hi; tmp8 = h; var tmp9 int32 = tmp8; tmp6 = tmp9 <= int32(len(a.A)) }; tmp5 = tmp6
//line :610:1
	if tmp5 {

		if h-l > th {
			var lt *ArrayPrefixHelpers_IntCumulateTask = t_.F_left; var rt *ArrayPrefixHelpers_IntCumulateTask = t_.F_right; var f *ArrayPrefixHelpers_IntCumulateTask


			if lt == nil {
				var mid int32 = int32(uint32(l+h) >> 1); var tmp10 *ArrayPrefixHelpers_IntCumulateTask; var tmp11 *ArrayPrefixHelpers_IntCumulateTask; var tmp12 *ArrayPrefixHelpers_IntCumulateTask = ArrayPrefixHelpers_IntCumulateTask_New_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I_I_I_I(t_, fn, a, org, fnc, th, mid, h)


				t_.F_right = tmp12; tmp11 = tmp12; rt = tmp11; tmp10 = rt
//line :618:1
				f = tmp10


				var tmp13 *ArrayPrefixHelpers_IntCumulateTask; var tmp14 *ArrayPrefixHelpers_IntCumulateTask; var tmp15 *ArrayPrefixHelpers_IntCumulateTask = ArrayPrefixHelpers_IntCumulateTask_New_ArrayPrefixHelpers_IntCumulateTask_IntBinaryOperator_I1_I_I_I_I_I(t_, fn, a, org, fnc, th, l, mid)

				t_.F_left = tmp15; tmp14 = tmp15
//line :622:1
				lt = tmp14; tmp13 = lt
//line :621:1
				t_ = tmp13 } else {


					var pin int32 = t_.F_in
					lt.F_in = pin
					var tmp16 *ArrayPrefixHelpers_IntCumulateTask; t_ = nil; tmp16 = t_; f = tmp16
					if !(rt == nil) {
						var lout int32 = lt.F_out; var tmp17 *ArrayPrefixHelpers_IntCumulateTask = rt; var tmp18 int32
						if l == org { tmp18 = lout } else { tmp18 = fn.ApplyAsInt_I_I__I(pin, lout) }; tmp17.F_in = tmp18
						var c int32 = 0
					L3: for {
						var tmp19 int32
						c = NN(rt).GetPendingCount__I(); tmp19 = c
//line :632:1
						if tmp19&1 == 0 { } else {



							break L3 }
						if NN(rt).CompareAndSetPendingCount_I_I__Z(c, c|1) {
							t_ = rt
							break L3 }
//line :631:1
						continue L3
					}
					}






					var c_2 int32 = 0
				L4: for {
					var tmp20 int32; c_2 = NN(lt).GetPendingCount__I(); tmp20 = c_2; if tmp20&1 == 0 { } else {
						break L4 }
					if NN(lt).CompareAndSetPendingCount_I_I__Z(c_2, c_2|1) {
						if !(t_ == nil) { f = t_ }
						t_ = lt
						break L4 }
//line :641:1
					continue L4
				}





					if t_ == nil { break L2 } }
			if !(f == nil) { NN(f).Fork__ForkJoinTask() } } else {
				var state int32 = 0
				var b int32 = 0
			L5: for {
				var tmp21 int32; b = NN(t_).GetPendingCount__I(); tmp21 = b; if tmp21&4 == 0 { } else {
					break L1 }
				var tmp22 int32
				if !(b&1 == 0) { tmp22 = 4 } else { if l > org { tmp22 = 2 } else {


					tmp22 = 6 } }
//line :655:1
				state = tmp22




				if NN(t_).CompareAndSetPendingCount_I_I__Z(b, b|state) { break L5 }
//line :652:1
				continue L5
			}







				var sum int32 = 0
				if !(state == 2) {

					var first int32 = 0
					if l == org {
						sum = a.A[org]; first = org + 1 } else {
							sum = t_.F_in; first = l }
					var i int32 = first; L6: for {
						if i < h {
							var tmp23 *IntArray = a; var tmp24 int32; sum = fn.ApplyAsInt_I_I__I(sum, a.A[i]); tmp24 = sum; tmp23.A[i] = tmp24
							i = i + 1; continue L6 }
//line :668:1
						break L6 } } else {
//line :662:1
							if h < fnc {











								sum = a.A[l]
								var i_2 int32 = l + 1; L7: for {
									if i_2 < h {
										sum = fn.ApplyAsInt_I_I__I(sum, a.A[i_2])
										i_2 = i_2 + 1; continue L7 }
//line :675:1
									break L7 } } else {



										sum = t_.F_in } }
				t_.F_out = sum
				var par *ArrayPrefixHelpers_IntCumulateTask
			L8: for {
				var tmp25 *ArrayPrefixHelpers_IntCumulateTask; par = ArrayPrefixHelpers_IntCumulateTask_Cast(NN(t_).GetCompleter__CountedCompleter()); tmp25 = par; if tmp25 == nil {
					if state&4 == 0 { } else { NN(t_).QuietlyComplete__V() }
					break L1 }
				var b_2 int32 = NN(par).GetPendingCount__I()
				if !(b_2&state&4 == 0) {
					t_ = par } else {
//line :687:1
						if !(b_2&state&2 == 0) {


							var nextState int32 = 0; var lt_2 *ArrayPrefixHelpers_IntCumulateTask; var rt_2 *ArrayPrefixHelpers_IntCumulateTask; var tmp26 bool; var tmp27 bool; var tmp28 *ArrayPrefixHelpers_IntCumulateTask


							lt_2 = par.F_left; tmp28 = lt_2; tmp27 = !(tmp28 == nil); if tmp27 {
								var tmp29 *ArrayPrefixHelpers_IntCumulateTask; rt_2 = par.F_right; tmp29 = rt_2; tmp27 = !(tmp29 == nil) }
//line :693:1
							tmp26 = tmp27; if tmp26 {

								var lout_2 int32 = lt_2.F_out; var tmp30 *ArrayPrefixHelpers_IntCumulateTask = par; var tmp31 int32

								if rt_2.F_hi == fnc { tmp31 = lout_2 } else {

									tmp31 = fn.ApplyAsInt_I_I__I(lout_2, rt_2.F_out) }
//line :696:1
								tmp30.F_out = tmp31
							}


							var refork int32; var tmp32 bool; var tmp33 bool
							tmp33 = b_2&1 == 0
//line :700:1
							if tmp33 {

								tmp33 = par.F_lo == org }
//line :700:1
							tmp32 = tmp33; if tmp32 { refork = 1 } else { refork = 0
							}



							var tmp34 bool; var tmp35 bool; var tmp36 int32
							nextState = b_2 | state | refork; tmp36 = nextState
//line :705:1
							tmp35 = tmp36 == b_2; if !tmp35 {




								tmp35 = NN(par).CompareAndSetPendingCount_I_I__Z(b_2, nextState) }
//line :705:1
							tmp34 = tmp35; if tmp34 {





								state = 2
								t_ = par
								if refork == 0 { } else { NN(par).Fork__ForkJoinTask() } } } else {
//line :687:1
									if NN(par).CompareAndSetPendingCount_I_I__Z(b_2, b_2|state) {


























										break L1 } } }
//line :682:1
				continue L8 } }
//line :610:1
		continue L2 }; break L2
}
}
}

type ArrayPrefixHelpers struct{ Object }

const ArrayPrefixHelpers_CUMULATE int32 = 1

const ArrayPrefixHelpers_SUMMED int32 = 2

const ArrayPrefixHelpers_FINISHED int32 = 4

const ArrayPrefixHelpers_MIN_PARTITION int32 = 16

func (t *ArrayPrefixHelpers) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayPrefixHelpers) GetClass__Class() *Class { return ArrayPrefixHelpers_class }

func (t *ArrayPrefixHelpers) ToString__String() *String { return Object_toString(t) }

func (t *ArrayPrefixHelpers) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayPrefixHelpers) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayPrefixHelpers_InstanceOf(x any) bool { _, ok := x.(*ArrayPrefixHelpers); return ok }

func ArrayPrefixHelpers_Cast(x any) *ArrayPrefixHelpers { if x == nil { return nil }; v, ok := x.(*ArrayPrefixHelpers); if !ok { panic(ClassCast(x, ArrayPrefixHelpers_class)) }; return v }



type ArrayPrefixHelpers_CumulateTask struct{ CountedCompleter; F_array *RefArray; F_function BinaryOperator; F_left, F_right *ArrayPrefixHelpers_CumulateTask; F_in, F_out any; F_lo, F_hi, F_origin, F_fence, F_threshold int32 }

const ArrayPrefixHelpers_CumulateTask_serialVersionUID int64 = 5293554502939613543

var ArrayPrefixHelpers_CumulateTask_init ClassInit

func ArrayPrefixHelpers_CumulateTask_Init() { if !ArrayPrefixHelpers_CumulateTask_init.Done() { ArrayPrefixHelpers_CumulateTask_init.Run(ArrayPrefixHelpers_CumulateTask_clinit) } }

func ArrayPrefixHelpers_CumulateTask_clinit() { CountedCompleter_Init() }

func (t *ArrayPrefixHelpers_CumulateTask) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_CumulateTask) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArrayPrefixHelpers_CumulateTask) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArrayPrefixHelpers_CumulateTask) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_CumulateTask) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_CumulateTask) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArrayPrefixHelpers_CumulateTask) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArrayPrefixHelpers_CumulateTask) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArrayPrefixHelpers_CumulateTask) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArrayPrefixHelpers_CumulateTask) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArrayPrefixHelpers_CumulateTask) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArrayPrefixHelpers_CumulateTask) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArrayPrefixHelpers_CumulateTask) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArrayPrefixHelpers_CumulateTask) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArrayPrefixHelpers_CumulateTask) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArrayPrefixHelpers_CumulateTask) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArrayPrefixHelpers_CumulateTask) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArrayPrefixHelpers_CumulateTask) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_CumulateTask) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArrayPrefixHelpers_CumulateTask) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArrayPrefixHelpers_CumulateTask) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArrayPrefixHelpers_CumulateTask) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArrayPrefixHelpers_CumulateTask) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArrayPrefixHelpers_CumulateTask) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_CumulateTask) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArrayPrefixHelpers_CumulateTask) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArrayPrefixHelpers_CumulateTask) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArrayPrefixHelpers_CumulateTask) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_CumulateTask) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_CumulateTask) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *ArrayPrefixHelpers_CumulateTask) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArrayPrefixHelpers_CumulateTask) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayPrefixHelpers_CumulateTask) GetClass__Class() *Class { return ArrayPrefixHelpers_CumulateTask_class }

func (t *ArrayPrefixHelpers_CumulateTask) ToString__String() *String { return Object_toString(t) }

func (t *ArrayPrefixHelpers_CumulateTask) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayPrefixHelpers_CumulateTask) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayPrefixHelpers_CumulateTask_InstanceOf(x any) bool { _, ok := x.(*ArrayPrefixHelpers_CumulateTask); return ok }

func ArrayPrefixHelpers_CumulateTask_Cast(x any) *ArrayPrefixHelpers_CumulateTask { if x == nil { return nil }; v, ok := x.(*ArrayPrefixHelpers_CumulateTask); if !ok { panic(ClassCast(x, ArrayPrefixHelpers_CumulateTask_class)) }; return v }



type ArrayPrefixHelpers_DoubleCumulateTask struct{ CountedCompleter; F_array *DoubleArray; F_function DoubleBinaryOperator; F_left, F_right *ArrayPrefixHelpers_DoubleCumulateTask; F_in, F_out float64; F_lo, F_hi, F_origin, F_fence, F_threshold int32 }

const ArrayPrefixHelpers_DoubleCumulateTask_serialVersionUID int64 = -586947823794232033

var ArrayPrefixHelpers_DoubleCumulateTask_init ClassInit

func ArrayPrefixHelpers_DoubleCumulateTask_Init() { if !ArrayPrefixHelpers_DoubleCumulateTask_init.Done() { ArrayPrefixHelpers_DoubleCumulateTask_init.Run(ArrayPrefixHelpers_DoubleCumulateTask_clinit) } }

func ArrayPrefixHelpers_DoubleCumulateTask_clinit() { CountedCompleter_Init() }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) GetClass__Class() *Class { return ArrayPrefixHelpers_DoubleCumulateTask_class }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) ToString__String() *String { return Object_toString(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayPrefixHelpers_DoubleCumulateTask) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayPrefixHelpers_DoubleCumulateTask_InstanceOf(x any) bool { _, ok := x.(*ArrayPrefixHelpers_DoubleCumulateTask); return ok }

func ArrayPrefixHelpers_DoubleCumulateTask_Cast(x any) *ArrayPrefixHelpers_DoubleCumulateTask { if x == nil { return nil }; v, ok := x.(*ArrayPrefixHelpers_DoubleCumulateTask); if !ok { panic(ClassCast(x, ArrayPrefixHelpers_DoubleCumulateTask_class)) }; return v }



type ArrayPrefixHelpers_IntCumulateTask struct{ CountedCompleter; F_array *IntArray; F_function IntBinaryOperator; F_left, F_right *ArrayPrefixHelpers_IntCumulateTask; F_in, F_out, F_lo, F_hi, F_origin, F_fence, F_threshold int32 }

const ArrayPrefixHelpers_IntCumulateTask_serialVersionUID int64 = 3731755594596840961

var ArrayPrefixHelpers_IntCumulateTask_init ClassInit

func ArrayPrefixHelpers_IntCumulateTask_Init() { if !ArrayPrefixHelpers_IntCumulateTask_init.Done() { ArrayPrefixHelpers_IntCumulateTask_init.Run(ArrayPrefixHelpers_IntCumulateTask_clinit) } }

func ArrayPrefixHelpers_IntCumulateTask_clinit() { CountedCompleter_Init() }

func (t *ArrayPrefixHelpers_IntCumulateTask) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_IntCumulateTask) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_IntCumulateTask) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayPrefixHelpers_IntCumulateTask) GetClass__Class() *Class { return ArrayPrefixHelpers_IntCumulateTask_class }

func (t *ArrayPrefixHelpers_IntCumulateTask) ToString__String() *String { return Object_toString(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayPrefixHelpers_IntCumulateTask) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayPrefixHelpers_IntCumulateTask_InstanceOf(x any) bool { _, ok := x.(*ArrayPrefixHelpers_IntCumulateTask); return ok }

func ArrayPrefixHelpers_IntCumulateTask_Cast(x any) *ArrayPrefixHelpers_IntCumulateTask { if x == nil { return nil }; v, ok := x.(*ArrayPrefixHelpers_IntCumulateTask); if !ok { panic(ClassCast(x, ArrayPrefixHelpers_IntCumulateTask_class)) }; return v }



type ArrayPrefixHelpers_LongCumulateTask struct{ CountedCompleter; F_array *LongArray; F_function LongBinaryOperator; F_left, F_right *ArrayPrefixHelpers_LongCumulateTask; F_in, F_out int64; F_lo, F_hi, F_origin, F_fence, F_threshold int32 }

const ArrayPrefixHelpers_LongCumulateTask_serialVersionUID int64 = -5074099945909284273

var ArrayPrefixHelpers_LongCumulateTask_init ClassInit

func ArrayPrefixHelpers_LongCumulateTask_Init() { if !ArrayPrefixHelpers_LongCumulateTask_init.Done() { ArrayPrefixHelpers_LongCumulateTask_init.Run(ArrayPrefixHelpers_LongCumulateTask_clinit) } }

func ArrayPrefixHelpers_LongCumulateTask_clinit() { CountedCompleter_Init() }

func (t *ArrayPrefixHelpers_LongCumulateTask) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_LongCumulateTask) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArrayPrefixHelpers_LongCumulateTask) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayPrefixHelpers_LongCumulateTask) GetClass__Class() *Class { return ArrayPrefixHelpers_LongCumulateTask_class }

func (t *ArrayPrefixHelpers_LongCumulateTask) ToString__String() *String { return Object_toString(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayPrefixHelpers_LongCumulateTask) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayPrefixHelpers_LongCumulateTask_InstanceOf(x any) bool { _, ok := x.(*ArrayPrefixHelpers_LongCumulateTask); return ok }

func ArrayPrefixHelpers_LongCumulateTask_Cast(x any) *ArrayPrefixHelpers_LongCumulateTask { if x == nil { return nil }; v, ok := x.(*ArrayPrefixHelpers_LongCumulateTask); if !ok { panic(ClassCast(x, ArrayPrefixHelpers_LongCumulateTask_class)) }; return v }
