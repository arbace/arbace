//line java_time_zone_ZoneRules.ae:1
package jrt















































func ZoneRules_Of_ZoneOffset_ZoneOffset_List_List_List__ZoneRules(baseStandardOffset, baseWallOffset *ZoneOffset, standardOffsetTransitionList, transitionList, lastRules List) *ZoneRules {



	Objects_RequireNonNull_O_String__O(baseStandardOffset.Ref(), Lit_2578)
	Objects_RequireNonNull_O_String__O(baseWallOffset.Ref(), Lit_2579)
	Objects_RequireNonNull_O_String__O(standardOffsetTransitionList, Lit_2580)
	Objects_RequireNonNull_O_String__O(transitionList, Lit_2581)
	Objects_RequireNonNull_O_String__O(lastRules, Lit_2582)
	return ZoneRules_New_ZoneOffset_ZoneOffset_List_List_List(baseStandardOffset, baseWallOffset, standardOffsetTransitionList, transitionList, lastRules)
}




func ZoneRules_Of_ZoneOffset__ZoneRules(offset *ZoneOffset) *ZoneRules {
	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	return ZoneRules_New_ZoneOffset(offset)
}
func ZoneRules_New_ZoneOffset_ZoneOffset_List_List_List(p0, p1 *ZoneOffset, p2, p3, p4 List) *ZoneRules { ZoneRules_Init(); t := &ZoneRules{}; t.Ctor_ZoneOffset_ZoneOffset_List_List_List(p0, p1, p2, p3, p4); return t }
//line :68:1
func (t *ZoneRules) Ctor_ZoneOffset_ZoneOffset_List_List_List(baseStandardOffset, baseWallOffset *ZoneOffset, standardOffsetTransitionList, transitionList, lastRules List) {




	t.F_standardTransitions = NewLongArray(standardOffsetTransitionList.Size__I())
	t.F_standardOffsets = NewRefArray(ZoneOffset_class, standardOffsetTransitionList.Size__I()+1)

	t.F_standardOffsets.Store(0, baseStandardOffset.Ref())
	var i int32 = 0; L1: for {
		if i < standardOffsetTransitionList.Size__I() {
			var tmp1 *LongArray = t.F_standardTransitions; tmp1.A[i] = NN(ZoneOffsetTransition_Cast(standardOffsetTransitionList.Get_I__O(i))).ToEpochSecond__J()


			var tmp2 *RefArray = t.F_standardOffsets; tmp2.Store(i+1, NN(ZoneOffsetTransition_Cast(standardOffsetTransitionList.Get_I__O(i))).GetOffsetAfter__ZoneOffset().Ref())


			i = i + 1; continue L1 }
//line :77:1
		break L1
	}







	var localTransitionList List = ArrayList_New(); var localTransitionOffsetList List = ArrayList_New()

	localTransitionOffsetList.Add_O__Z(baseWallOffset.Ref())
	var i_101695 Iterator = transitionList.Iterator__Iterator(); for i_101695.HasNext__Z() { var trans *ZoneOffsetTransition = ZoneOffsetTransition_Cast(i_101695.Next__O())
		if NN(trans).IsGap__Z() {

			localTransitionList.Add_O__Z(NN(trans).GetDateTimeBefore__LocalDateTime().Ref())
			localTransitionList.Add_O__Z(NN(trans).GetDateTimeAfter__LocalDateTime().Ref()) } else {

				localTransitionList.Add_O__Z(NN(trans).GetDateTimeAfter__LocalDateTime().Ref())
				localTransitionList.Add_O__Z(NN(trans).GetDateTimeBefore__LocalDateTime().Ref()) }
		localTransitionOffsetList.Add_O__Z(NN(trans).GetOffsetAfter__ZoneOffset().Ref()) }
	t.F_savingsLocalTransitions = A2g_CastArray[*RefArray](localTransitionList.ToArray_O1__O1(NewRefArray(LocalDateTime_class, localTransitionList.Size__I())).Ref(), LocalDateTime_class.ArrayClass())


	t.F_wallOffsets = A2g_CastArray[*RefArray](localTransitionOffsetList.ToArray_O1__O1(NewRefArray(ZoneOffset_class, localTransitionOffsetList.Size__I())).Ref(), ZoneOffset_class.ArrayClass())



	t.F_savingsInstantTransitions = NewLongArray(transitionList.Size__I())
	var i_2 int32 = 0; L3: for {
		if i_2 < transitionList.Size__I() {
			var tmp3 *LongArray = t.F_savingsInstantTransitions; tmp3.A[i_2] = NN(ZoneOffsetTransition_Cast(transitionList.Get_I__O(i_2))).ToEpochSecond__J()


			i_2 = i_2 + 1; continue L3 }
//line :106:1
		break L3
	}




	if lastRules.Size__I() > 0 {
		var temp *RefArray = lastRules.ToArray__O1(); var rulesArray *RefArray = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I_Class__O1(temp, int32(len(temp.A)), ZoneOffsetTransitionRule_class.ArrayClass()).Ref(), ZoneOffsetTransitionRule_class.ArrayClass())


		if int32(len(rulesArray.A)) > 16 {
			panic(Thrown(IllegalArgumentException_New_String(Lit_2577))) }
		t.F_lastRules = rulesArray
		t.F_lastRulesCache = ConcurrentHashMap_New() } else {
			t.F_lastRules = ZoneRules_EMPTY_LASTRULES; t.F_lastRulesCache = nil
		} }
func ZoneRules_New_J1_ZoneOffset1_J1_ZoneOffset1_ZoneOffsetTransitionRule1(p0 *LongArray, p1 *RefArray, p2 *LongArray, p3, p4 *RefArray) *ZoneRules { ZoneRules_Init(); t := &ZoneRules{}; t.Ctor_J1_ZoneOffset1_J1_ZoneOffset1_ZoneOffsetTransitionRule1(p0, p1, p2, p3, p4); return t }
//line :122:1
func (t *ZoneRules) Ctor_J1_ZoneOffset1_J1_ZoneOffset1_ZoneOffsetTransitionRule1(standardTransitions *LongArray, standardOffsets *RefArray, savingsInstantTransitions *LongArray, wallOffsets, lastRules *RefArray) {



	t.F_standardTransitions = standardTransitions
	t.F_standardOffsets = standardOffsets
	t.F_savingsInstantTransitions = savingsInstantTransitions
	t.F_wallOffsets = wallOffsets
	t.F_lastRules = lastRules
	var tmp1 ConcurrentMap
	if int32(len(lastRules.A)) > 0 { tmp1 = ConcurrentHashMap_New() } else { tmp1 = nil }
//line :131:1
	t.F_lastRulesCache = tmp1

	if int32(len(savingsInstantTransitions.A)) == 0 {
		t.F_savingsLocalTransitions = ZoneRules_EMPTY_LDT_ARRAY } else {
			var localTransitionList List = ArrayList_New(); var i int32 = 0
		L1: for {
			if i < int32(len(savingsInstantTransitions.A)) {
				var before *ZoneOffset = As[*ZoneOffset](wallOffsets.A[i]); var after *ZoneOffset = As[*ZoneOffset](wallOffsets.A[i+1]); var trans *ZoneOffsetTransition = ZoneOffsetTransition_New_J_ZoneOffset_ZoneOffset(savingsInstantTransitions.A[i], before, after)


				if NN(trans).IsGap__Z() {

					localTransitionList.Add_O__Z(NN(trans).GetDateTimeBefore__LocalDateTime().Ref())
					localTransitionList.Add_O__Z(NN(trans).GetDateTimeAfter__LocalDateTime().Ref())
					i = i + 1; continue L1 } else {

						localTransitionList.Add_O__Z(NN(trans).GetDateTimeAfter__LocalDateTime().Ref())
						localTransitionList.Add_O__Z(NN(trans).GetDateTimeBefore__LocalDateTime().Ref())
						i = i + 1; continue L1 } }
//line :136:1
			break L1
		}












			t.F_savingsLocalTransitions = A2g_CastArray[*RefArray](localTransitionList.ToArray_O1__O1(NewRefArray(LocalDateTime_class, localTransitionList.Size__I())).Ref(), LocalDateTime_class.ArrayClass())
		}
}


func ZoneRules_New_ZoneOffset(p0 *ZoneOffset) *ZoneRules { ZoneRules_Init(); t := &ZoneRules{}; t.Ctor_ZoneOffset(p0); return t }
//line :155:1
func (t *ZoneRules) Ctor_ZoneOffset(offset *ZoneOffset) {
	t.F_standardOffsets = NewRefArray(ZoneOffset_class, 1)
	t.F_standardOffsets.Store(0, offset.Ref())
	t.F_standardTransitions = ZoneRules_EMPTY_LONG_ARRAY
	t.F_savingsInstantTransitions = ZoneRules_EMPTY_LONG_ARRAY
	t.F_savingsLocalTransitions = ZoneRules_EMPTY_LDT_ARRAY
	t.F_wallOffsets = t.F_standardOffsets
	t.F_lastRules = ZoneRules_EMPTY_LASTRULES
	t.F_lastRulesCache = nil
}



func (t *ZoneRules) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.zone.ZoneRules.writeReplace()Ljava/lang/Object;")) }











func ZoneRules_ReadExternal_DataInput__ZoneRules(in DataInput) *ZoneRules { ZoneRules_Init()
	var stdSize int32 = in.ReadInt__I()
	if stdSize > 1024 { panic(Thrown(InvalidObjectException_New_String(Lit_2583))) }
	var stdTrans *LongArray; if stdSize == 0 { stdTrans = ZoneRules_EMPTY_LONG_ARRAY } else { stdTrans = NewLongArray(stdSize) }
	var i int32 = 0; L1: for {
		if i < stdSize { stdTrans.A[i] = Ser_ReadEpochSec_DataInput__J(in); i = i + 1; continue L1 }
//line :184:1
		break L1
	}
	var stdOffsets *RefArray = NewRefArray(ZoneOffset_class, stdSize+1); var i_2 int32 = 0
L2: for {
	if i_2 < int32(len(stdOffsets.A)) {
		stdOffsets.Store(i_2, Ser_ReadOffset_DataInput__ZoneOffset(in).Ref())
		i_2 = i_2 + 1; continue L2 }
//line :187:1
	break L2
}


	var savSize int32 = in.ReadInt__I()
	if savSize > 1024 { panic(Thrown(InvalidObjectException_New_String(Lit_2584))) }
	var savTrans *LongArray; if savSize == 0 { savTrans = ZoneRules_EMPTY_LONG_ARRAY } else { savTrans = NewLongArray(savSize) }
	var i_3 int32 = 0; L3: for {
		if i_3 < savSize {
			savTrans.A[i_3] = Ser_ReadEpochSec_DataInput__J(in)
			i_3 = i_3 + 1; continue L3 }
//line :194:1
		break L3
	}


	var savOffsets *RefArray = NewRefArray(ZoneOffset_class, savSize+1); var i_4 int32 = 0
L4: for {
	if i_4 < int32(len(savOffsets.A)) {
		savOffsets.Store(i_4, Ser_ReadOffset_DataInput__ZoneOffset(in).Ref())
		i_4 = i_4 + 1; continue L4 }
//line :199:1
	break L4
}


	var ruleSize int32 = int32(in.ReadByte__B())
	if ruleSize > 16 {
		panic(Thrown(InvalidObjectException_New_String(Lit_2577))) }
	var rules *RefArray; if ruleSize == 0 { rules = ZoneRules_EMPTY_LASTRULES } else {

		rules = NewRefArray(ZoneOffsetTransitionRule_class, ruleSize)
	}

	var i_5 int32 = 0; L5: for {
		if i_5 < ruleSize {
			rules.Store(i_5, ZoneOffsetTransitionRule_ReadExternal_DataInput__ZoneOffsetTransitionRule(in).Ref())
			i_5 = i_5 + 1; continue L5 }
//line :211:1
		break L5
	}


	return ZoneRules_New_J1_ZoneOffset1_J1_ZoneOffset1_ZoneOffsetTransitionRule1(stdTrans, stdOffsets, savTrans, savOffsets, rules)
}
func (t *ZoneRules) IsFixedOffset__Z() bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 *ZoneOffset = As[*ZoneOffset](t.F_standardOffsets.A[0]); tmp3 = NN(tmp4).Equals_O__Z(As[*ZoneOffset](t.F_wallOffsets.A[0]).Ref()); if tmp3 {
		tmp3 = int32(len(t.F_standardTransitions.A)) == 0 }
//line :218:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = int32(len(t.F_savingsInstantTransitions.A)) == 0 }
//line :218:1
	tmp1 = tmp2; if tmp1 {


		tmp1 = int32(len(t.F_lastRules.A)) == 0 }
//line :218:1
	return tmp1
}



func (t *ZoneRules) GetOffset_Instant__ZoneOffset(instant *Instant) *ZoneOffset {
	if int32(len(t.F_savingsInstantTransitions.A)) == 0 {
		return As[*ZoneOffset](t.F_wallOffsets.A[0]) } else {
			var epochSec int64 = NN(instant).GetEpochSecond__J(); var tmp1 bool; var tmp2 bool
			tmp2 = int32(len(t.F_lastRules.A)) > 0; if tmp2 {
				var tmp3 *LongArray = t.F_savingsInstantTransitions; tmp2 = epochSec > tmp3.A[int32(len(t.F_savingsInstantTransitions.A))-1] }
//line :227:1
			tmp1 = tmp2; if tmp1 {



				var tmp4 *RefArray = t.F_wallOffsets; var year int32 = t.FindYear_J_ZoneOffset__I(epochSec, As[*ZoneOffset](tmp4.A[int32(len(t.F_wallOffsets.A))-1])); var transArray *RefArray = t.FindTransitionArray_I__ZoneOffsetTransition1(year); var trans *ZoneOffsetTransition
				var i int32 = 0




			L1: for {
				if i < int32(len(transArray.A)) {
					trans = As[*ZoneOffsetTransition](transArray.A[i])
					if epochSec < NN(trans).ToEpochSecond__J() {
						return NN(trans).GetOffsetBefore__ZoneOffset() } else {
							i = i + 1; continue L1 } }
//line :237:1
				break L1
			}




				return NN(trans).GetOffsetAfter__ZoneOffset() } else {
					var index int32 = Arrays_BinarySearch_J1_J__I(t.F_savingsInstantTransitions, epochSec)
					if index < 0 {
						index = -index - 2 }
					return As[*ZoneOffset](t.F_wallOffsets.A[index+1])
				} } }
func (t *ZoneRules) GetOffset_LocalDateTime__ZoneOffset(localDateTime *LocalDateTime) *ZoneOffset {
	var info any = t.GetOffsetInfo_LocalDateTime__O(localDateTime)
	if ZoneOffsetTransition_InstanceOf(info) {
		return NN(ZoneOffsetTransition_Cast(info)).GetOffsetBefore__ZoneOffset() } else {
			return ZoneOffset_Cast(info)
		} }
func (t *ZoneRules) GetValidOffsets_LocalDateTime__List(localDateTime *LocalDateTime) List {
	var info any = t.GetOffsetInfo_LocalDateTime__O(localDateTime)
	if ZoneOffsetTransition_InstanceOf(info) {
		return NN(ZoneOffsetTransition_Cast(info)).GetValidOffsets__List() } else {
			return Collections_SingletonList_O__List(ZoneOffset_Cast(info).Ref())
		} }
func (t *ZoneRules) GetTransition_LocalDateTime__ZoneOffsetTransition(localDateTime *LocalDateTime) *ZoneOffsetTransition {
	var info any = t.GetOffsetInfo_LocalDateTime__O(localDateTime)
	if ZoneOffsetTransition_InstanceOf(info) { return ZoneOffsetTransition_Cast(info) } else { return nil
	} }
func (t *ZoneRules) GetOffsetInfo_LocalDateTime__O(dt *LocalDateTime) any {
	if int32(len(t.F_savingsLocalTransitions.A)) == 0 {
		return As[*ZoneOffset](t.F_wallOffsets.A[0]).Ref() } else {
//line :266:1
			var tmp1 bool; var tmp2 bool

			tmp2 = int32(len(t.F_lastRules.A)) > 0; if tmp2 {
				var tmp3 *RefArray = t.F_savingsLocalTransitions; tmp2 = NN(dt).IsAfter_ChronoLocalDateTime__Z(Up_LocalDateTime_ChronoLocalDateTime(As[*LocalDateTime](tmp3.A[int32(len(t.F_savingsLocalTransitions.A))-1]))) }
//line :268:1
			tmp1 = tmp2
//line :266:1
			if tmp1 {





				var transArray *RefArray = t.FindTransitionArray_I__ZoneOffsetTransition1(NN(dt).GetYear__I()); var info any; var arr_101711 *RefArray = transArray; var len_101712 int32 = int32(len(arr_101711.A)); var i_101713 int32 = 0; for ; i_101713 < len_101712; i_101713++ {

					var trans *ZoneOffsetTransition = As[*ZoneOffsetTransition](arr_101711.A[i_101713])
					info = t.FindOffsetInfo_LocalDateTime_ZoneOffsetTransition__O(dt, trans)
					var tmp4 bool; var tmp5 bool; tmp5 = ZoneOffsetTransition_InstanceOf(info); if !tmp5 { tmp5 = Equals(info, NN(trans).GetOffsetBefore__ZoneOffset().Ref()) }; tmp4 = tmp5; if tmp4 {
						return info } }
//line :272:1
				return info } else {







					var index int32 = Arrays_BinarySearch_O1_O__I(t.F_savingsLocalTransitions, dt.Ref())
					if index == -1 {
						return As[*ZoneOffset](t.F_wallOffsets.A[0]).Ref() } else {

							if index < 0 {
								index = -index - 2 } else {
//line :284:1
									var tmp6 bool; var tmp7 bool

									tmp7 = index < int32(len(t.F_savingsLocalTransitions.A))-1; if tmp7 {
										var tmp8 *LocalDateTime = As[*LocalDateTime](t.F_savingsLocalTransitions.A[index]); tmp7 = NN(tmp8).Equals_O__Z(As[*LocalDateTime](t.F_savingsLocalTransitions.A[index+1]).Ref()) }
//line :286:1
									tmp6 = tmp7
//line :284:1
									if tmp6 {




										index = index + 1 } }
							if index&1 == 0 {
								var dtBefore *LocalDateTime = As[*LocalDateTime](t.F_savingsLocalTransitions.A[index]); var dtAfter *LocalDateTime = As[*LocalDateTime](t.F_savingsLocalTransitions.A[index+1]); var tmp9 *RefArray = t.F_wallOffsets; var offsetBefore *ZoneOffset = As[*ZoneOffset](tmp9.A[index/2]); var tmp10 *RefArray = t.F_wallOffsets; var offsetAfter *ZoneOffset = As[*ZoneOffset](tmp10.A[index/2+1])




								if NN(offsetAfter).GetTotalSeconds__I() > NN(offsetBefore).GetTotalSeconds__I() {
									return ZoneOffsetTransition_New_LocalDateTime_ZoneOffset_ZoneOffset(dtBefore, offsetBefore, offsetAfter) } else {
										return ZoneOffsetTransition_New_LocalDateTime_ZoneOffset_ZoneOffset(dtAfter, offsetBefore, offsetAfter) } } else {
											var tmp11 *RefArray = t.F_wallOffsets; return As[*ZoneOffset](tmp11.A[index/2+1]).Ref()
										} } } } }
func (t *ZoneRules) FindOffsetInfo_LocalDateTime_ZoneOffsetTransition__O(dt *LocalDateTime, trans *ZoneOffsetTransition) any {
	var localTransition *LocalDateTime = NN(trans).GetDateTimeBefore__LocalDateTime()
	if NN(trans).IsGap__Z() {

		if NN(dt).IsBefore_ChronoLocalDateTime__Z(Up_LocalDateTime_ChronoLocalDateTime(localTransition)) {
			return NN(trans).GetOffsetBefore__ZoneOffset().Ref() } else {
//line :305:1
				if NN(dt).IsBefore_ChronoLocalDateTime__Z(Up_LocalDateTime_ChronoLocalDateTime(NN(trans).GetDateTimeAfter__LocalDateTime())) { return trans.Ref() } else {


					return NN(trans).GetOffsetAfter__ZoneOffset().Ref() } } } else {
//line :303:1
						if NN(dt).IsBefore_ChronoLocalDateTime__Z(Up_LocalDateTime_ChronoLocalDateTime(localTransition)) == false {





							return NN(trans).GetOffsetAfter__ZoneOffset().Ref() } else {
//line :303:1
								if NN(dt).IsBefore_ChronoLocalDateTime__Z(Up_LocalDateTime_ChronoLocalDateTime(NN(trans).GetDateTimeAfter__LocalDateTime())) {






									return NN(trans).GetOffsetBefore__ZoneOffset().Ref() } else {
//line :303:1
										return trans.Ref()
									}
							}
					}
}





func (t *ZoneRules) FindTransitionArray_I__ZoneOffsetTransition1(year int32) *RefArray {
	var yearObj *Integer = Integer_ValueOf_I__Integer(year); var transArray *RefArray = A2g_CastArray[*RefArray](t.F_lastRulesCache.Get_O__O(yearObj.Ref()), ZoneOffsetTransition_class.ArrayClass())

	if !(transArray == nil) { return transArray } else {

		var ruleArray *RefArray = t.F_lastRules
		transArray = NewRefArray(ZoneOffsetTransition_class, int32(len(ruleArray.A)))
		var i int32 = 0; L1: for {
			if i < int32(len(ruleArray.A)) {
				transArray.Store(i, NN(As[*ZoneOffsetTransitionRule](ruleArray.A[i])).CreateTransition_I__ZoneOffsetTransition(year).Ref())
				i = i + 1; continue L1 }
//line :320:1
			break L1
		}


		if year < 2100 { t.F_lastRulesCache.PutIfAbsent_O_O__O(yearObj.Ref(), transArray.Ref()) }
//line :318:1
		return transArray
	}
}






func (t *ZoneRules) GetStandardOffset_Instant__ZoneOffset(instant *Instant) *ZoneOffset {
	if int32(len(t.F_standardTransitions.A)) == 0 {
		return As[*ZoneOffset](t.F_standardOffsets.A[0]) } else {
			var epochSec int64 = NN(instant).GetEpochSecond__J(); var index int32 = Arrays_BinarySearch_J1_J__I(t.F_standardTransitions, epochSec)

			if index < 0 { index = -index - 2 }
			return As[*ZoneOffset](t.F_standardOffsets.A[index+1])
		} }
func (t *ZoneRules) GetDaylightSavings_Instant__Duration(instant *Instant) *Duration {
	if t.IsFixedOffset__Z() { Duration_Init(); return Duration_ZERO } else {

		var standardOffset *ZoneOffset = t.GetStandardOffset_Instant__ZoneOffset(instant); var actualOffset *ZoneOffset = t.GetOffset_Instant__ZoneOffset(instant)

		return Duration_OfSeconds_J__Duration(int64(NN(actualOffset).GetTotalSeconds__I() - NN(standardOffset).GetTotalSeconds__I()))
	}
}

func (t *ZoneRules) IsDaylightSavings_Instant__Z(instant *Instant) bool {
	return NN(t.GetStandardOffset_Instant__ZoneOffset(instant)).Equals_O__Z(t.GetOffset_Instant__ZoneOffset(instant).Ref()) == false
}
func (t *ZoneRules) IsValidOffset_LocalDateTime_ZoneOffset__Z(localDateTime *LocalDateTime, offset *ZoneOffset) bool {
	return t.GetValidOffsets_LocalDateTime__List(localDateTime).Contains_O__Z(offset.Ref())
}
func (t *ZoneRules) NextTransition_Instant__ZoneOffsetTransition(instant *Instant) *ZoneOffsetTransition {
	if int32(len(t.F_savingsInstantTransitions.A)) == 0 { return nil } else {
		var epochSec int64 = NN(instant).GetEpochSecond__J(); var tmp1 *LongArray = t.F_savingsInstantTransitions
		if epochSec >= tmp1.A[int32(len(t.F_savingsInstantTransitions.A))-1] {


			if int32(len(t.F_lastRules.A)) == 0 { return nil } else {
				var tmp2 *RefArray = t.F_wallOffsets; var year int32 = t.FindYear_J_ZoneOffset__I(epochSec, As[*ZoneOffset](tmp2.A[int32(len(t.F_wallOffsets.A))-1])); var transArray *RefArray = t.FindTransitionArray_I__ZoneOffsetTransition1(year); var arr_101714 *RefArray = transArray; var len_101715 int32 = int32(len(arr_101714.A)); var i_101716 int32 = 0; for ; i_101716 < len_101715; i_101716++ {




					var trans *ZoneOffsetTransition = As[*ZoneOffsetTransition](arr_101714.A[i_101716])
					if epochSec < NN(trans).ToEpochSecond__J() { return trans } }
				if year < 999999999 {
					transArray = t.FindTransitionArray_I__ZoneOffsetTransition1(year + 1)
					return As[*ZoneOffsetTransition](transArray.A[0]) } else {
//line :364:1
						return nil
					} } } else {

						var index int32 = Arrays_BinarySearch_J1_J__I(t.F_savingsInstantTransitions, epochSec)
						if index < 0 {
							index = -index - 1 } else {
								index = index + 1 }
						var tmp3 int64 = t.F_savingsInstantTransitions.A[index]; var tmp4 *ZoneOffset = As[*ZoneOffset](t.F_wallOffsets.A[index]); return ZoneOffsetTransition_New_J_ZoneOffset_ZoneOffset(tmp3, tmp4, As[*ZoneOffset](t.F_wallOffsets.A[index+1]))
					}
	}
}
func (t *ZoneRules) PreviousTransition_Instant__ZoneOffsetTransition(instant *Instant) *ZoneOffsetTransition {
	if int32(len(t.F_savingsInstantTransitions.A)) == 0 { return nil } else {
		var epochSec int64 = NN(instant).GetEpochSecond__J(); var tmp1 bool; var tmp2 bool
		tmp2 = NN(instant).GetNano__I() > 0; if tmp2 { tmp2 = epochSec < 9223372036854775807 }; tmp1 = tmp2; if tmp1 {
			epochSec = epochSec + 1 }
		var tmp3 *LongArray = t.F_savingsInstantTransitions; var lastHistoric int64 = tmp3.A[int32(len(t.F_savingsInstantTransitions.A))-1]; var tmp4 bool; var tmp5 bool

		tmp5 = int32(len(t.F_lastRules.A)) > 0; if tmp5 { tmp5 = epochSec > lastHistoric }; tmp4 = tmp5; if tmp4 {
			var tmp6 *RefArray = t.F_wallOffsets; var lastHistoricOffset *ZoneOffset = As[*ZoneOffset](tmp6.A[int32(len(t.F_wallOffsets.A))-1]); var year int32 = t.FindYear_J_ZoneOffset__I(epochSec, lastHistoricOffset); var transArray *RefArray = t.FindTransitionArray_I__ZoneOffsetTransition1(year); var i int32 = int32(len(transArray.A)) - 1



		L1: for {
			if i >= 0 {
				if epochSec > NN(As[*ZoneOffsetTransition](transArray.A[i])).ToEpochSecond__J() {
					return As[*ZoneOffsetTransition](transArray.A[i]) } else {
						i = i - 1; continue L1 } }
//line :387:1
			break L1
		}




			var lastHistoricYear int32 = t.FindYear_J_ZoneOffset__I(lastHistoric, lastHistoricOffset); var tmp7 int32
			year = year - 1; tmp7 = year; if tmp7 > lastHistoricYear {
				transArray = t.FindTransitionArray_I__ZoneOffsetTransition1(year)
				return As[*ZoneOffsetTransition](transArray.A[int32(len(transArray.A))-1]) } }
		var index int32 = Arrays_BinarySearch_J1_J__I(t.F_savingsInstantTransitions, epochSec)
		if index < 0 { index = -index - 1 }
		if index <= 0 { return nil } else {
			var tmp8 int64 = t.F_savingsInstantTransitions.A[index-1]; var tmp9 *ZoneOffset = As[*ZoneOffset](t.F_wallOffsets.A[index-1]); return ZoneOffsetTransition_New_J_ZoneOffset_ZoneOffset(tmp8, tmp9, As[*ZoneOffset](t.F_wallOffsets.A[index]))
		}
	}
}

func (t *ZoneRules) FindYear_J_ZoneOffset__I(epochSecond int64, offset *ZoneOffset) int32 {
	var localSecond int64 = epochSecond + int64(NN(offset).GetTotalSeconds__I()); var zeroDay int64 = Math_FloorDiv_J_I__J(localSecond, 86400) + 719528


	zeroDay = zeroDay - 60
	var adjust int64 = 0
	if zeroDay < 0 {
		var adjustCycles int64 = (zeroDay+1)/146097 - 1


		adjust = adjustCycles * 400
		zeroDay = zeroDay + -adjustCycles*146097
	}


	var yearEst int64 = (400*zeroDay + 591) / 146097; var tmp1 int64 = 365*yearEst + yearEst/4; var tmp2 int64 = tmp1 - yearEst/100; var doyEst int64 = zeroDay - (tmp2 + yearEst/400)











	if doyEst < 0 {
		yearEst = yearEst - 1
		var tmp3 int64 = 365*yearEst + yearEst/4; var tmp4 int64 = tmp3 - yearEst/100; doyEst = zeroDay - (tmp4 + yearEst/400)
	}







	yearEst = yearEst + adjust
	if doyEst >= 306 { yearEst = yearEst + 1 }
	return int32(Math_Min_J_J__J(yearEst, 999999999))
}
func (t *ZoneRules) GetTransitions__List() List {
	var list List = ArrayList_New(); var i int32 = 0
L1: for {
	if i < int32(len(t.F_savingsInstantTransitions.A)) {
		var tmp1 int64 = t.F_savingsInstantTransitions.A[i]; var tmp2 *ZoneOffset = As[*ZoneOffset](t.F_wallOffsets.A[i]); list.Add_O__Z(ZoneOffsetTransition_New_J_ZoneOffset_ZoneOffset(tmp1, tmp2, As[*ZoneOffset](t.F_wallOffsets.A[i+1])))



		i = i + 1; continue L1 }
//line :449:1
	break L1
}





	return Collections_UnmodifiableList_List__List(list)
}
func (t *ZoneRules) GetTransitionRules__List() List {
	return List_Of_O1__List(t.F_lastRules)
}
func (t *ZoneRules) Equals_O__Z(otherRules any) bool {
	if any(t) == any(otherRules) { return true } else {

		var tmp1 any = otherRules; if ZoneRules_InstanceOf(tmp1) { var other *ZoneRules = ZoneRules_Cast(tmp1); var tmp2 *LongArray = t.F_standardTransitions
			if Arrays_Equals_J1_J1__Z(tmp2, other.F_standardTransitions) {
				var tmp3 *RefArray = t.F_standardOffsets; if Arrays_Equals_O1_O1__Z(tmp3, other.F_standardOffsets) {
					var tmp4 *LongArray = t.F_savingsInstantTransitions; if Arrays_Equals_J1_J1__Z(tmp4, other.F_savingsInstantTransitions) {
						var tmp5 *RefArray = t.F_wallOffsets; if Arrays_Equals_O1_O1__Z(tmp5, other.F_wallOffsets) {
							var tmp6 *RefArray = t.F_lastRules; return Arrays_Equals_O1_O1__Z(tmp6, other.F_lastRules) } else {
//line :468:1
								return false } } else {
//line :467:1
									return false
								} } else {
//line :466:1
									return false
								}
			} else {
//line :465:1
				return false
			}

		} else {
//line :464:1
			return false
		}
	}
}








func (t *ZoneRules) HashCode__I() int32 {
	return Arrays_HashCode_J1__I(t.F_standardTransitions) ^ Arrays_HashCode_O1__I(t.F_standardOffsets) ^ Arrays_HashCode_J1__I(t.F_savingsInstantTransitions) ^ Arrays_HashCode_O1__I(t.F_wallOffsets) ^ Arrays_HashCode_O1__I(t.F_lastRules)
}





func (t *ZoneRules) ToString__String() *String {
	var tmp1 *RefArray = t.F_standardOffsets; return Concat(Lit_2585, StrOfObj(As[*ZoneOffset](tmp1.A[int32(len(t.F_standardOffsets.A))-1]).Ref()), Lit_1189)
}


type ZoneRules struct{ Object; F_standardTransitions *LongArray; F_standardOffsets *RefArray; F_savingsInstantTransitions *LongArray; F_savingsLocalTransitions, F_wallOffsets, F_lastRules *RefArray; F_lastRulesCache ConcurrentMap }

func (t *ZoneRules) Is_Serializable() {}

const ZoneRules_serialVersionUID int64 = 3044319355680032515

const ZoneRules_LAST_CACHED_YEAR int32 = 2100

var ZoneRules_EMPTY_LONG_ARRAY *LongArray

var ZoneRules_EMPTY_LASTRULES *RefArray

var ZoneRules_EMPTY_LDT_ARRAY *RefArray

const ZoneRules_DAYS_PER_CYCLE int32 = 146097

const ZoneRules_DAYS_0000_TO_1970 int64 = 719528

var ZoneRules_init ClassInit

func ZoneRules_Init() { if !ZoneRules_init.Done() { ZoneRules_init.Run(ZoneRules_clinit) } }

func ZoneRules_clinit() { ZoneRules_EMPTY_LONG_ARRAY = NewLongArray(0); ZoneRules_EMPTY_LASTRULES = NewRefArray(ZoneOffsetTransitionRule_class, 0); ZoneRules_EMPTY_LDT_ARRAY = NewRefArray(LocalDateTime_class, 0) }

func (t *ZoneRules) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneRules) GetClass__Class() *Class { return ZoneRules_class }

func (t *ZoneRules) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneRules) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneRules_InstanceOf(x any) bool { _, ok := x.(*ZoneRules); return ok }

func ZoneRules_Cast(x any) *ZoneRules { if x == nil { return nil }; v, ok := x.(*ZoneRules); if !ok { panic(ClassCast(x, ZoneRules_class)) }; return v }
