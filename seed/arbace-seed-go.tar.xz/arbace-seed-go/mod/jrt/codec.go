//line codec.ae:1
package jrt


// DecodeUTF8 is Java's UTF-8 decoding with replacement (String.decodeUTF8_UTF16): malformed
// input becomes U+FFFD as Java's decoder replaces it (one for each maximal ill-formed
// subsequence, as JDK 26 consumes them), surrogates encoded in 3 bytes too.
func DecodeUTF8(src /*line :11:1*/[]int8) []uint16 {
	sp := 0
	sl := len(src)
	dst := make([]uint16, 0, sl)
	var repl uint16 = 65533
	for sp < sl {
		b1 := int32(src[sp])
		sp++
		if
			b1 >= 0 {
				dst = append(dst, uint16(b1))

			} else if b1>>5 == -2 && b1&30 != 0 {

				if sp < sl {
					b2 := int32(src[sp])
					sp++
					if notContinuation(b2) {
						dst = append(dst, repl); sp-- } else {
							dst = append(dst, uint16(b1<<6^b2^(-64<<6^-128))) }
					continue }
				dst = append(dst, repl)
				break

			} else if b1>>4 == -2 {

				if sp+1 < sl {
					b2 := int32(src[sp])
					b3 := int32(src[sp+1])
					sp = sp + 2
					if b1 == -32 && b2&224 == 128 || notContinuation(b2) || notContinuation(b3) {

						dst = append(dst, repl)
						sp = sp - 3

						if b1 == -32 && b2&224 == 128 || notContinuation(b2) {
							sp = sp + 1 } else {
								sp = sp + 2 } } else {
									c := uint16(b1<<12 ^ b2<<6 ^ (b3 ^ (-32<<12 ^ -128<<6 ^ -128)))
									if isSurrogate(c) {
										dst = append(dst, repl) } else {
											dst = append(dst, c) } }
					continue }
				if sp < sl && (b1 == -32 && int32(src[sp])&224 == 128 ||
					notContinuation(int32(src[sp]))) {
						dst = append(dst, repl)
						continue }
				dst = append(dst, repl)
				break

			} else if b1>>3 == -2 {

				if sp+2 < sl {
					b2 := int32(src[sp])
					b3 := int32(src[sp+1])
					b4 := int32(src[sp+2])
					uc := b1<<18 ^ b2<<12 ^ b3<<6 ^ (b4 ^ (-16<<18 ^ -128<<12 ^ -128<<6 ^ -128))
					sp = sp + 3
					if notContinuation(b2) || notContinuation(b3) || notContinuation(b4) ||
						uc < 65536 || uc > 1114111 {

							dst = append(dst, repl)
							sp = sp - 4
							sp = sp + malformed4(src, sp) } else {
								dst = appendCodePoint(dst, uc) }
					continue }
				b1 = b1 & 255
				if b1 > 244 || sp < sl && malformed4_2(b1, int32(src[sp])&255) {
					dst = append(dst, repl)
					continue }
				sp++
				dst = append(dst, repl)
				if sp < sl && notContinuation(int32(src[sp])) {
					continue }
				break

			} else {
				dst = append(dst, repl)
			}
	}; return dst }
func notContinuation(b int32) bool { return b&192 != 128 }

func malformed4_2(b1, b2 int32) bool {
	return b1 == 240 && (b2 < 144 || b2 > 191) ||
		b1 == 244 && b2&240 != 128 ||
		notContinuation(b2)
}
func malformed4(src []int8, sp int) int {
	b1 := int32(src[sp]) & 255
	b2 := int32(src[sp+1]) & 255
	if b1 > 244 || malformed4_2(b1, b2) {
		return 1 }
	if notContinuation(int32(src[sp+2])) {
		return 2
	}; return 3 }
// EncodeUTF8 is Java's UTF-8 encoding with replacement: an unpaired surrogate becomes '?'.
func EncodeUTF8(v /*line :109:1*/[]uint16) []int8 {
	dst := make([]int8, 0, len(v))
	for i := 0; i < len(v); i++ {
		c := rune(v[i])
		if
			c < 128 { dst = append(dst, int8(c))
			} else if c < 2048 { dst = append(dst, int8(192|c>>6), int8(128|c&63))
			} else if isSurrogate(uint16(c)) {
				if isHighSurrogate(uint16(c)) && i+1 < len(v) && isLowSurrogate(v[i+1]) {
					uc := toCodePoint(uint16(c), v[i+1])
					i++
					dst = append(dst, int8(240|uc>>18),
						int8(128|uc>>12&63),
						int8(128|uc>>6&63),
						int8(128|uc&63)) } else {
							dst = append(dst, '?') } } else {
								dst = append(dst, int8(224|c>>12),
									int8(128|c>>6&63),
									int8(128|c&63),
								)
							} }; return dst }
const (
	csUnknown int = iota
	csUTF8
	csLatin1
	csASCII
	csUTF16
	csUTF16BE
	csUTF16LE)
// charsetOf: jrt's charsets by Java's names and aliases (case-insensitive; charset.ae).
func charsetOf(name /*line :140:1*/*String) int {
	cs := lookupCharset(name.String())
	if cs == nil {
		return csUnknown }
	return cs.Self_Charset().kind }
// DecodeBytes decodes with the named charset (UTF-8, ISO-8859-1, US-ASCII: bytes above 0x7F
// become U+FFFD; UTF-16, UTF-16BE, UTF-16LE); UnsupportedEncodingException for others.
//line :146:1
func DecodeBytes(b /*line :149:1*/[]int8, name *String) []uint16 {
	switch charsetOf(name) {
	case csUTF8: return DecodeUTF8(b)
	case csLatin1:
		v := make([]uint16, len(b))
		for i, c := range b { v[i] = uint16(uint8(c)) }
		return v
	case csASCII:
		v := make([]uint16, len(b))
		for i, c := range b {
			if c < 0 {
				v[i] = 65533 } else {
					v[i] = uint16(c) } }
		return v
	case csUTF16: return decodeUTF16(b, 0)
	case csUTF16BE: return decodeUTF16(b, 1)
	case csUTF16LE: return decodeUTF16(b, 2)}
	panic(UnsupportedEncodingException_New_String(name)) }
// decodeUTF16 is jdk26u's sun.nio.cs.UnicodeDecoder with String's REPLACE: order 0 (UTF-16)
// reads a byte-order mark at the start (big-endian without one), 1 big-endian, 2 little-endian;
// an unpaired low surrogate is malformed (2 bytes), a high one not followed by a low (4 bytes),
// the bytes left at the end (fewer than 2, or a high surrogate's 2 or 3) one malformed input:
// each becomes U+FFFD.
//line :168:1
func decodeUTF16(b /*line :174:1*/[]int8, order int) []uint16 {
	v := make([]uint16, 0, len(b)/2)
	i := 0
	n := len(b)
	get := func(j int) uint16 {
		b1 := uint16(uint8(b[j]))
		b2 := uint16(uint8(b[j+1]))
		if order == 2 {
			return b2<<8 | b1 }
		return b1<<8 | b2 }
	if order == 0 && n >= 2 {
		c := uint16(uint8(b[0]))<<8 | uint16(uint8(b[1]))
		if
			c == 65279 { order = 1; i = 2
			} else if c == 65534 { order = 2; i = 2 } else {
				order = 1 } }
	for n-i > 1 {
		c := get(i)
		if
			isHighSurrogate(c) {

				if n-i < 4 {
					break }
				{ c2 := get(i + 2)
					if isLowSurrogate(c2) {
						v = append(v, c, c2) } else {
							v = append(v, 65533) } }
				i = i + 4
			} else if isLowSurrogate(c) {
				v = append(v, 65533); i = i + 2
			} else {
				v = append(v, c); i = i + 2 } }
	if i < n {
		v = append(v, 65533) }; return v }
// encodeUTF16 is jdk26u's sun.nio.cs.UnicodeEncoder with String's REPLACE: order 0 (UTF-16)
// writes a byte-order mark first (big-endian; none for an empty string), 1 big-endian, 2
// little-endian; an unpaired surrogate becomes the replacement U+FFFD.
//line :210:1
func encodeUTF16(v /*line :214:1*/[]uint16, order int) []int8 {
	dst := make([]int8, 0, 2*len(v)+2)
	put := func(c uint16) {
		if order == 2 {
			dst = append(dst, int8(uint8(c)), int8(uint8(c>>8))) } else {
				dst = append(dst, int8(uint8(c>>8)), int8(uint8(c))) } }
	if len(v) == 0 {
		return dst }
	if order == 0 {
		put(65279)
		order = 1 }
	for i := 0; i < len(v); i++ {
		c := v[i]
		if
			isHighSurrogate(c) && i+1 < len(v) && isLowSurrogate(v[i+1]) {
				put(c); put(v[i+1]); i++
			} else if isSurrogate(c) { put(65533) } else {
				put(c) } }; return dst }
// EncodeBytes encodes with the named charset; unmappable characters become '?' (a surrogate
// pair one '?').
func EncodeBytes(v /*line :237:1*/[]uint16, name *String) []int8 {
	cs := charsetOf(name)
	limit := rune(255)
	switch cs {
	case csUTF8: return EncodeUTF8(v)
	case csUTF16: return encodeUTF16(v, 0)
	case csUTF16BE: return encodeUTF16(v, 1)
	case csUTF16LE: return encodeUTF16(v, 2)
	case csASCII: limit = 127
	case csLatin1:
	default: panic(UnsupportedEncodingException_New_String(name))}
	dst := make([]int8, 0, len(v))
	for i := 0; i < len(v); i++ {
		c := rune(v[i])
		if
			c <= limit { dst = append(dst, int8(c))
			} else if isHighSurrogate(uint16(c)) && i+1 < len(v) && isLowSurrogate(v[i+1]) {
				dst = append(dst, '?'); i++ } else {
					dst = append(dst, '?')
				}
	}
	return dst
}
