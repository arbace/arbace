//line java_nio_charset_IllegalCharsetNameException.ae:1
package jrt










func IllegalCharsetNameException_New_String(p0 *String) *IllegalCharsetNameException { t := &IllegalCharsetNameException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *IllegalCharsetNameException) Ctor_String(charsetName *String) { t.IllegalArgumentException.Ctor_String(t, String_ValueOf_O__String(charsetName.Ref()))

	t.F_charsetName = charsetName
}
func (t *IllegalCharsetNameException) GetCharsetName__String() *String { return t.F_charsetName }



type IllegalCharsetNameException struct{ IllegalArgumentException; F_charsetName *String }

const IllegalCharsetNameException_serialVersionUID int64 = 1457525358470002989

func (t *IllegalCharsetNameException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalCharsetNameException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalCharsetNameException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalCharsetNameException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalCharsetNameException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalCharsetNameException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalCharsetNameException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalCharsetNameException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalCharsetNameException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalCharsetNameException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalCharsetNameException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalCharsetNameException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalCharsetNameException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalCharsetNameException) GetClass__Class() *Class { return IllegalCharsetNameException_class }

func (t *IllegalCharsetNameException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalCharsetNameException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalCharsetNameException_InstanceOf(x any) bool { _, ok := x.(*IllegalCharsetNameException); return ok }

func IllegalCharsetNameException_Cast(x any) *IllegalCharsetNameException { if x == nil { return nil }; v, ok := x.(*IllegalCharsetNameException); if !ok { panic(ClassCast(x, IllegalCharsetNameException_class)) }; return v }
