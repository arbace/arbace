//line java_io_FileFilter.ae:1
package jrt






type FileFilter interface{ Object_I; Is_FileFilter(); Accept_File__Z(p0 *File) bool }

func FileFilter_InstanceOf(x any) bool { _, ok := x.(FileFilter); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FileFilter_class) } }; return ok }

func FileFilter_Cast(x any) FileFilter { if x == nil { return nil }; v, ok := x.(FileFilter); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FileFilter_class) } }; if !ok { panic(ClassCast(x, FileFilter_class)) }; return v }
