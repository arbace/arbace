//line java_lang_NoClassDefFoundError.ae:1
package jrt








func NoClassDefFoundError_New() *NoClassDefFoundError { t := &NoClassDefFoundError{}; t.Ctor(); return t }
//line :10:1
func (t *NoClassDefFoundError) Ctor() { t.LinkageError.Ctor(t) }

func NoClassDefFoundError_New_String(p0 *String) *NoClassDefFoundError { t := &NoClassDefFoundError{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NoClassDefFoundError) Ctor_String(s *String) { t.LinkageError.Ctor_String(t, s) }







type NoClassDefFoundError struct{ LinkageError }

const NoClassDefFoundError_serialVersionUID int64 = 9095859863287012458

func (t *NoClassDefFoundError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoClassDefFoundError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoClassDefFoundError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoClassDefFoundError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoClassDefFoundError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoClassDefFoundError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoClassDefFoundError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoClassDefFoundError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoClassDefFoundError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoClassDefFoundError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoClassDefFoundError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoClassDefFoundError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoClassDefFoundError) Ref() any { if t == nil { return nil }; return t }

func (t *NoClassDefFoundError) GetClass__Class() *Class { return NoClassDefFoundError_class }

func (t *NoClassDefFoundError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoClassDefFoundError) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoClassDefFoundError_InstanceOf(x any) bool { _, ok := x.(*NoClassDefFoundError); return ok }

func NoClassDefFoundError_Cast(x any) *NoClassDefFoundError { if x == nil { return nil }; v, ok := x.(*NoClassDefFoundError); if !ok { panic(ClassCast(x, NoClassDefFoundError_class)) }; return v }
