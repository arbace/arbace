//line java_util_Queue.ae:1
package jrt






type Queue interface{ Object_I; Collection; Iterable; Is_Queue(); Add_O__Z(p0 any) bool; Offer_O__Z(p0 any) bool; Remove__O() any; Poll__O() any; Element__O() any; Peek__O() any }

func Queue_InstanceOf(x any) bool { _, ok := x.(Queue); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Queue_class) } }; return ok }

func Queue_Cast(x any) Queue { if x == nil { return nil }; v, ok := x.(Queue); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Queue_class) } }; if !ok { panic(ClassCast(x, Queue_class)) }; return v }
