//line java_lang_InterruptedException.ae:1
package jrt








func InterruptedException_New() *InterruptedException { t := &InterruptedException{}; t.Ctor(); return t }
//line :10:1
func (t *InterruptedException) Ctor() { t.Exception.Ctor(t) }

func InterruptedException_New_String(p0 *String) *InterruptedException { t := &InterruptedException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *InterruptedException) Ctor_String(s *String) { t.Exception.Ctor_String(t, s) }







type InterruptedException struct{ Exception }

const InterruptedException_serialVersionUID int64 = 6700697376100628473

func (t *InterruptedException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InterruptedException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InterruptedException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InterruptedException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InterruptedException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InterruptedException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InterruptedException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InterruptedException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InterruptedException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InterruptedException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InterruptedException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InterruptedException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InterruptedException) Ref() any { if t == nil { return nil }; return t }

func (t *InterruptedException) GetClass__Class() *Class { return InterruptedException_class }

func (t *InterruptedException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InterruptedException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InterruptedException_InstanceOf(x any) bool { _, ok := x.(*InterruptedException); return ok }

func InterruptedException_Cast(x any) *InterruptedException { if x == nil { return nil }; v, ok := x.(*InterruptedException); if !ok { panic(ClassCast(x, InterruptedException_class)) }; return v }
