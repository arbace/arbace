//line com_sun_crypto_provider_HmacCore.ae:1
package jrt































func (t *HmacCore) Ctor_String_I(this HmacCore_I, digestAlgo *String, bl int32) { t.MacSpi.Ctor(this)
	var md MessageDigest_I = MessageDigest_GetInstance_String__MessageDigest(digestAlgo)
	if Cloneable_InstanceOf(md) { } else {
		var sun Provider_I = Security_GetProvider_String__Provider(Lit_0)
		if !(sun == nil) {
			md = MessageDigest_GetInstance_String_Provider__MessageDigest(digestAlgo, sun) } else {
				var noCloneProv *String = md.GetProvider__Provider().GetName__String()
				md = nil
				var provs *RefArray = Security_GetProviders__Provider1(); var arr_100984 *RefArray = provs; var len_100985 int32 = int32(len(arr_100984.A)); var i_100986 int32 = 0
			L1: for ; i_100986 < len_100985; i_100986++ { var p Provider_I = As[Provider_I](arr_100984.A[i_100986]); tmp1, tmp2, tmp3 := func() (ctl int32, rv bool, exc Throwable_I) { defer Catch(&exc)

				if NN(p.GetName__String()).Equals_O__Z(noCloneProv.Ref()) { } else {
					var md2 MessageDigest_I = MessageDigest_GetInstance_String_Provider__MessageDigest(digestAlgo, p)
					if Cloneable_InstanceOf(md2) { md = md2; return 2, false, nil } }; return 0, false, nil }(); _ = tmp2
//line :43:1
				if tmp3 != nil { if NoSuchAlgorithmException_InstanceOf(tmp3) { var ignored *NoSuchAlgorithmException = NoSuchAlgorithmException_Cast(tmp3); _ = ignored } else { panic(tmp3) } }; switch tmp1 { case 2: { break L1
				}
				}
			}

				if md == nil {
					panic(Thrown(NoSuchAlgorithmException_New_String(Concat(Lit_1, digestAlgo))))
				} } }
	t.F_md = md
	t.F_blockLen = bl
	t.F_k_ipad = NewByteArray(t.F_blockLen)
	t.F_k_opad = NewByteArray(t.F_blockLen)
	t.F_first = true
}
func (t *HmacCore) Impl_EngineGetMacLength__I(this HmacCore_I) int32 {
	return t.F_md.GetDigestLength__I()
}
func (t *HmacCore) Impl_EngineInit_Key_AlgorithmParameterSpec__V(this HmacCore_I, key Key, params AlgorithmParameterSpec) {


	if !(params == nil) {
		panic(Thrown(InvalidAlgorithmParameterException_New_String(Lit_2))) }
	if SecretKey_InstanceOf(key) { } else { panic(Thrown(InvalidKeyException_New_String(Lit_3))) }
	var secret *ByteArray = key.GetEncoded__B1()
	if secret == nil { panic(Thrown(InvalidKeyException_New_String(Lit_4))) }
	if int32(len(secret.A)) > t.F_blockLen {
		var tmp *ByteArray = t.F_md.Digest_B1__B1(secret); Arrays_Fill_B1_B__V(secret, 0); secret = tmp }
	var i int32 = 0; L1: for {
		if i < t.F_blockLen {
			var si int32; if i < int32(len(secret.A)) { si = int32(secret.A[i]) } else { si = 0 }
			t.F_k_ipad.A[i] = int8(si ^ 54)
			t.F_k_opad.A[i] = int8(si ^ 92)
			i = i + 1; continue L1 }
//line :70:1
		break L1
	}




	Arrays_Fill_B1_B__V(secret, 0)
	secret = nil
	this.EngineReset__V()
}
func (t *HmacCore) Impl_EngineUpdate_B__V(this HmacCore_I, input int8) {
	if t.F_first { t.F_md.Update_B1__V(t.F_k_ipad); t.F_first = false }
	t.F_md.Update_B__V(input)
}
func (t *HmacCore) Impl_EngineUpdate_B1_I_I__V(this HmacCore_I, input *ByteArray, offset, len_ int32) {
	if t.F_first { t.F_md.Update_B1__V(t.F_k_ipad); t.F_first = false }
	t.F_md.Update_B1_I_I__V(input, offset, len_)
}
func (t *HmacCore) Impl_EngineUpdate_ByteBuffer__V(this HmacCore_I, input ByteBuffer_I) {
	if t.F_first { t.F_md.Update_B1__V(t.F_k_ipad); t.F_first = false }
	t.F_md.Update_ByteBuffer__V(input)
}
func (t *HmacCore) Impl_EngineDoFinal__B1(this HmacCore_I) *ByteArray {
	if t.F_first { t.F_md.Update_B1__V(t.F_k_ipad) } else { t.F_first = true }
	var tmp1 *ByteArray; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var tmp *ByteArray = t.F_md.Digest__B1()
			t.F_md.Update_B1__V(t.F_k_opad)
			t.F_md.Update_B1__V(tmp)
			var tmp2 MessageDigest_I = t.F_md; tmp2.Digest_B1_I_I__I(tmp, 0, int32(len(tmp.A)))
			t.F_md.Reset__V()
//line :95:1
			tmp1 = tmp
		}


		return nil }()
//line :94:1
	if tmp3 != nil { if DigestException_InstanceOf(tmp3) { var e *DigestException = DigestException_Cast(tmp3)






		panic(Thrown(ProviderException_New_Throwable(Up_DigestException_Throwable(e)))) } else {
//line :94:1
			panic(tmp3) } }; return tmp1
}







func (t *HmacCore) Impl_EngineReset__V(this HmacCore_I) {
	if t.F_first { } else { t.F_md.Reset__V(); t.F_first = true
	} }
func (t *HmacCore) Impl_Clone__O(this HmacCore_I) any {
	var copy_ HmacCore_I = HmacCore_Cast(t.MacSpi.Impl_Clone__O(this))
	copy_.Self_HmacCore().F_md = MessageDigest_Cast(t.F_md.Clone__O())
	copy_.Self_HmacCore().F_k_ipad = NN(t.F_k_ipad).Copy()
	copy_.Self_HmacCore().F_k_opad = NN(t.F_k_opad).Copy()
//line :107:1
	return copy_
}







func HmacCore_HmacSHA224_New() *HmacCore_HmacSHA224 { t := &HmacCore_HmacSHA224{}; t.Ctor(); return t }
//line :116:1
func (t *HmacCore_HmacSHA224) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_5, 64) }





func HmacCore_HmacSHA256_New() *HmacCore_HmacSHA256 { t := &HmacCore_HmacSHA256{}; t.Ctor(); return t }
//line :122:1
func (t *HmacCore_HmacSHA256) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_6, 64) }





func HmacCore_HmacSHA384_New() *HmacCore_HmacSHA384 { t := &HmacCore_HmacSHA384{}; t.Ctor(); return t }
//line :128:1
func (t *HmacCore_HmacSHA384) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_7, 128) }





func HmacCore_HmacSHA512_New() *HmacCore_HmacSHA512 { t := &HmacCore_HmacSHA512{}; t.Ctor(); return t }
//line :134:1
func (t *HmacCore_HmacSHA512) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_12, 128) }





func HmacCore_HmacSHA512_224_New() *HmacCore_HmacSHA512_224 { t := &HmacCore_HmacSHA512_224{}; t.Ctor(); return t }
//line :140:1
func (t *HmacCore_HmacSHA512_224) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_13, 128) }





func HmacCore_HmacSHA512_256_New() *HmacCore_HmacSHA512_256 { t := &HmacCore_HmacSHA512_256{}; t.Ctor(); return t }
//line :146:1
func (t *HmacCore_HmacSHA512_256) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_14, 128) }





func HmacCore_HmacSHA3_224_New() *HmacCore_HmacSHA3_224 { t := &HmacCore_HmacSHA3_224{}; t.Ctor(); return t }
//line :152:1
func (t *HmacCore_HmacSHA3_224) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_8, 144) }





func HmacCore_HmacSHA3_256_New() *HmacCore_HmacSHA3_256 { t := &HmacCore_HmacSHA3_256{}; t.Ctor(); return t }
//line :158:1
func (t *HmacCore_HmacSHA3_256) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_9, 136) }





func HmacCore_HmacSHA3_384_New() *HmacCore_HmacSHA3_384 { t := &HmacCore_HmacSHA3_384{}; t.Ctor(); return t }
//line :164:1
func (t *HmacCore_HmacSHA3_384) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_10, 104) }





func HmacCore_HmacSHA3_512_New() *HmacCore_HmacSHA3_512 { t := &HmacCore_HmacSHA3_512{}; t.Ctor(); return t }
//line :170:1
func (t *HmacCore_HmacSHA3_512) Ctor() { t.HmacCore.Ctor_String_I(t, Lit_11, 72) }





type HmacCore struct{ MacSpi; F_md MessageDigest_I; F_k_ipad, F_k_opad *ByteArray; F_first bool; F_blockLen int32 }

type HmacCore_I interface{ MacSpi_I; Cloneable; Self_HmacCore() *HmacCore; EngineGetMacLength__I() int32; EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec); EngineUpdate_B__V(p0 int8); EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32); EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I); EngineDoFinal__B1() *ByteArray; EngineReset__V() }

func (t *HmacCore) Self_HmacCore() *HmacCore { return t }

func (t *HmacCore) Is_Cloneable() {}

func HmacCore_InstanceOf(x any) bool { _, ok := x.(HmacCore_I); return ok }

func HmacCore_Cast(x any) HmacCore_I { if x == nil { return nil }; v, ok := x.(HmacCore_I); if !ok { panic(ClassCast(x, HmacCore_class)) }; return v }



type HmacCore_HmacSHA224 struct{ HmacCore }

func (t *HmacCore_HmacSHA224) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA224) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA224) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA224) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA224) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA224) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA224) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA224) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA224) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA224) GetClass__Class() *Class { return HmacCore_HmacSHA224_class }

func (t *HmacCore_HmacSHA224) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA224) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA224_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA224); return ok }

func HmacCore_HmacSHA224_Cast(x any) *HmacCore_HmacSHA224 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA224); if !ok { panic(ClassCast(x, HmacCore_HmacSHA224_class)) }; return v }



type HmacCore_HmacSHA256 struct{ HmacCore }

func (t *HmacCore_HmacSHA256) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA256) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA256) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA256) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA256) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA256) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA256) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA256) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA256) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA256) GetClass__Class() *Class { return HmacCore_HmacSHA256_class }

func (t *HmacCore_HmacSHA256) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA256) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA256_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA256); return ok }

func HmacCore_HmacSHA256_Cast(x any) *HmacCore_HmacSHA256 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA256); if !ok { panic(ClassCast(x, HmacCore_HmacSHA256_class)) }; return v }



type HmacCore_HmacSHA384 struct{ HmacCore }

func (t *HmacCore_HmacSHA384) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA384) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA384) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA384) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA384) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA384) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA384) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA384) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA384) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA384) GetClass__Class() *Class { return HmacCore_HmacSHA384_class }

func (t *HmacCore_HmacSHA384) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA384) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA384_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA384); return ok }

func HmacCore_HmacSHA384_Cast(x any) *HmacCore_HmacSHA384 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA384); if !ok { panic(ClassCast(x, HmacCore_HmacSHA384_class)) }; return v }



type HmacCore_HmacSHA3_224 struct{ HmacCore }

func (t *HmacCore_HmacSHA3_224) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA3_224) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA3_224) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA3_224) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA3_224) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA3_224) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA3_224) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA3_224) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA3_224) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA3_224) GetClass__Class() *Class { return HmacCore_HmacSHA3_224_class }

func (t *HmacCore_HmacSHA3_224) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA3_224) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA3_224_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA3_224); return ok }

func HmacCore_HmacSHA3_224_Cast(x any) *HmacCore_HmacSHA3_224 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA3_224); if !ok { panic(ClassCast(x, HmacCore_HmacSHA3_224_class)) }; return v }



type HmacCore_HmacSHA3_256 struct{ HmacCore }

func (t *HmacCore_HmacSHA3_256) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA3_256) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA3_256) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA3_256) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA3_256) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA3_256) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA3_256) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA3_256) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA3_256) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA3_256) GetClass__Class() *Class { return HmacCore_HmacSHA3_256_class }

func (t *HmacCore_HmacSHA3_256) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA3_256) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA3_256_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA3_256); return ok }

func HmacCore_HmacSHA3_256_Cast(x any) *HmacCore_HmacSHA3_256 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA3_256); if !ok { panic(ClassCast(x, HmacCore_HmacSHA3_256_class)) }; return v }



type HmacCore_HmacSHA3_384 struct{ HmacCore }

func (t *HmacCore_HmacSHA3_384) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA3_384) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA3_384) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA3_384) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA3_384) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA3_384) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA3_384) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA3_384) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA3_384) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA3_384) GetClass__Class() *Class { return HmacCore_HmacSHA3_384_class }

func (t *HmacCore_HmacSHA3_384) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA3_384) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA3_384_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA3_384); return ok }

func HmacCore_HmacSHA3_384_Cast(x any) *HmacCore_HmacSHA3_384 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA3_384); if !ok { panic(ClassCast(x, HmacCore_HmacSHA3_384_class)) }; return v }



type HmacCore_HmacSHA3_512 struct{ HmacCore }

func (t *HmacCore_HmacSHA3_512) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA3_512) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA3_512) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA3_512) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA3_512) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA3_512) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA3_512) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA3_512) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA3_512) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA3_512) GetClass__Class() *Class { return HmacCore_HmacSHA3_512_class }

func (t *HmacCore_HmacSHA3_512) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA3_512) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA3_512_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA3_512); return ok }

func HmacCore_HmacSHA3_512_Cast(x any) *HmacCore_HmacSHA3_512 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA3_512); if !ok { panic(ClassCast(x, HmacCore_HmacSHA3_512_class)) }; return v }



type HmacCore_HmacSHA512 struct{ HmacCore }

func (t *HmacCore_HmacSHA512) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA512) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA512) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA512) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA512) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA512) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA512) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA512) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA512) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA512) GetClass__Class() *Class { return HmacCore_HmacSHA512_class }

func (t *HmacCore_HmacSHA512) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA512) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA512_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA512); return ok }

func HmacCore_HmacSHA512_Cast(x any) *HmacCore_HmacSHA512 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA512); if !ok { panic(ClassCast(x, HmacCore_HmacSHA512_class)) }; return v }



type HmacCore_HmacSHA512_224 struct{ HmacCore }

func (t *HmacCore_HmacSHA512_224) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA512_224) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA512_224) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA512_224) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA512_224) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA512_224) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA512_224) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA512_224) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA512_224) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA512_224) GetClass__Class() *Class { return HmacCore_HmacSHA512_224_class }

func (t *HmacCore_HmacSHA512_224) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA512_224) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA512_224_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA512_224); return ok }

func HmacCore_HmacSHA512_224_Cast(x any) *HmacCore_HmacSHA512_224 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA512_224); if !ok { panic(ClassCast(x, HmacCore_HmacSHA512_224_class)) }; return v }



type HmacCore_HmacSHA512_256 struct{ HmacCore }

func (t *HmacCore_HmacSHA512_256) Clone__O() any { return t.HmacCore.Impl_Clone__O(t) }

func (t *HmacCore_HmacSHA512_256) EngineGetMacLength__I() int32 { return t.Impl_EngineGetMacLength__I(t) }

func (t *HmacCore_HmacSHA512_256) EngineInit_Key_AlgorithmParameterSpec__V(p0 Key, p1 AlgorithmParameterSpec) { t.Impl_EngineInit_Key_AlgorithmParameterSpec__V(t, p0, p1) }

func (t *HmacCore_HmacSHA512_256) EngineUpdate_B__V(p0 int8) { t.Impl_EngineUpdate_B__V(t, p0) }

func (t *HmacCore_HmacSHA512_256) EngineUpdate_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_EngineUpdate_B1_I_I__V(t, p0, p1, p2) }

func (t *HmacCore_HmacSHA512_256) EngineUpdate_ByteBuffer__V(p0 ByteBuffer_I) { t.Impl_EngineUpdate_ByteBuffer__V(t, p0) }

func (t *HmacCore_HmacSHA512_256) EngineDoFinal__B1() *ByteArray { return t.Impl_EngineDoFinal__B1(t) }

func (t *HmacCore_HmacSHA512_256) EngineReset__V() { t.Impl_EngineReset__V(t) }

func (t *HmacCore_HmacSHA512_256) Ref() any { if t == nil { return nil }; return t }

func (t *HmacCore_HmacSHA512_256) GetClass__Class() *Class { return HmacCore_HmacSHA512_256_class }

func (t *HmacCore_HmacSHA512_256) ToString__String() *String { return Object_toString(t) }

func (t *HmacCore_HmacSHA512_256) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HmacCore_HmacSHA512_256_InstanceOf(x any) bool { _, ok := x.(*HmacCore_HmacSHA512_256); return ok }

func HmacCore_HmacSHA512_256_Cast(x any) *HmacCore_HmacSHA512_256 { if x == nil { return nil }; v, ok := x.(*HmacCore_HmacSHA512_256); if !ok { panic(ClassCast(x, HmacCore_HmacSHA512_256_class)) }; return v }
