//line java_nio_file_CopyOption.ae:1
package jrt






type CopyOption interface{ Object_I; Is_CopyOption() }

func CopyOption_InstanceOf(x any) bool { _, ok := x.(CopyOption); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CopyOption_class) } }; return ok }

func CopyOption_Cast(x any) CopyOption { if x == nil { return nil }; v, ok := x.(CopyOption); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(CopyOption_class) } }; if !ok { panic(ClassCast(x, CopyOption_class)) }; return v }
