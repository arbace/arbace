//line java_util_HashSet.ae:1
package jrt





















func HashSet_New() *HashSet { HashSet_Init(); t := &HashSet{}; t.Ctor(t); return t }
//line :23:1
func (t *HashSet) Ctor(this HashSet_I) { t.AbstractSet.Ctor(this); t.F_map = HashMap_New() }

func HashSet_New_Collection(p0 Collection) *HashSet { HashSet_Init(); t := &HashSet{}; t.Ctor_Collection(t, p0); return t }
//line :25:1
func (t *HashSet) Ctor_Collection(this HashSet_I, c Collection) { t.AbstractSet.Ctor(this)
	t.F_map = HashMap_NewHashMap_I__HashMap(Math_Max_I_I__I(c.Size__I(), 12))
	this.AddAll_Collection__Z(c)
}
func HashSet_New_I_F(p0 int32, p1 float32) *HashSet { HashSet_Init(); t := &HashSet{}; t.Ctor_I_F(t, p0, p1); return t }
//line :29:1
func (t *HashSet) Ctor_I_F(this HashSet_I, initialCapacity int32, loadFactor float32) { t.AbstractSet.Ctor(this)
	t.F_map = HashMap_New_I_F(initialCapacity, loadFactor)
}
func HashSet_New_I(p0 int32) *HashSet { HashSet_Init(); t := &HashSet{}; t.Ctor_I(t, p0); return t }
//line :32:1
func (t *HashSet) Ctor_I(this HashSet_I, initialCapacity int32) { t.AbstractSet.Ctor(this)
	t.F_map = HashMap_New_I(initialCapacity)
}
func HashSet_New_I_F_Z(p0 int32, p1 float32, p2 bool) *HashSet { HashSet_Init(); t := &HashSet{}; t.Ctor_I_F_Z(t, p0, p1, p2); return t }
//line :35:1
func (t *HashSet) Ctor_I_F_Z(this HashSet_I, initialCapacity int32, loadFactor float32, dummy bool) { t.AbstractSet.Ctor(this)
	t.F_map = LinkedHashMap_New_I_F(initialCapacity, loadFactor)
}
func (t *HashSet) Impl_Iterator__Iterator(this HashSet_I) Iterator {
	return t.F_map.KeySet__Set().Iterator__Iterator()
}
func (t *HashSet) Impl_Size__I(this HashSet_I) int32 { return t.F_map.Size__I() }

func (t *HashSet) Impl_IsEmpty__Z(this HashSet_I) bool { return t.F_map.IsEmpty__Z() }

func (t *HashSet) Impl_Contains_O__Z(this HashSet_I, o any) bool { return t.F_map.ContainsKey_O__Z(o) }

func (t *HashSet) Impl_Add_O__Z(this HashSet_I, e any) bool { return t.F_map.Put_O_O__O(e, HashSet_PRESENT) == nil }

func (t *HashSet) Impl_Remove_O__Z(this HashSet_I, o any) bool {
	return t.F_map.Remove_O__O(o) == HashSet_PRESENT
}
func (t *HashSet) Impl_Clear__V(this HashSet_I) { t.F_map.Clear__V() }

func (t *HashSet) Impl_Clone__O(this HashSet_I) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var newSet HashSet_I = HashSet_Cast(A2g_ObjectClone(this))
			newSet.Self_HashSet().F_map = HashMap_Cast(t.F_map.Clone__O())
//line :56:1
			tmp1 = newSet }
//line :55:1
		return nil }(); if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)



			panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :55:1
				panic(tmp2) } }; return tmp1
}











































func (t *HashSet) Impl_Spliterator__Spliterator(this HashSet_I) Spliterator {
	return HashMap_KeySpliterator_New_HashMap_I_I_I_I(t.F_map, 0, -1, 0, 0)
}
func (t *HashSet) Impl_ToArray__O1(this HashSet_I) *RefArray {
	var tmp1 HashMap_I = t.F_map; return tmp1.KeysToArray_O1__O1(NewRefArray(Object_class, t.F_map.Size__I()))
}
func (t *HashSet) Impl_ToArray_O1__O1(this HashSet_I, a *RefArray) *RefArray {
	var tmp1 HashMap_I = t.F_map; return tmp1.KeysToArray_O1__O1(t.F_map.PrepareArray_O1__O1(a))
}
func HashSet_NewHashSet_I__HashSet(numElements int32) HashSet_I {
	if numElements < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2694, StrOfInt(numElements))))) }
	return HashSet_New_I(HashMap_CalculateHashMapCapacity_I__I(numElements))
}


type HashSet struct{ AbstractSet; F_map HashMap_I }

type HashSet_I interface{ AbstractSet_I; Set; Cloneable; Serializable; Collection; Iterable; Self_HashSet() *HashSet; Iterator__Iterator() Iterator; Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; Clear__V(); Spliterator__Spliterator() Spliterator; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray }

func (t *HashSet) Self_HashSet() *HashSet { return t }

func (t *HashSet) Is_Cloneable() {}

func (t *HashSet) Is_Serializable() {}

const HashSet_serialVersionUID int64 = -5024744406713321676

var HashSet_PRESENT any

var HashSet_init ClassInit

func HashSet_Init() { if !HashSet_init.Done() { HashSet_init.Run(HashSet_clinit) } }

func HashSet_clinit() { HashSet_PRESENT = Object_New() }

func (t *HashSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *HashSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *HashSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *HashSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *HashSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *HashSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *HashSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *HashSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *HashSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *HashSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *HashSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *HashSet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *HashSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *HashSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *HashSet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *HashSet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *HashSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *HashSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *HashSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *HashSet) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *HashSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HashSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HashSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HashSet) Ref() any { if t == nil { return nil }; return t }

func (t *HashSet) GetClass__Class() *Class { return HashSet_class }

func (t *HashSet) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func HashSet_InstanceOf(x any) bool { _, ok := x.(HashSet_I); return ok }

func HashSet_Cast(x any) HashSet_I { if x == nil { return nil }; v, ok := x.(HashSet_I); if !ok { panic(ClassCast(x, HashSet_class)) }; return v }
