//line java_io_InvalidObjectException.ae:1
package jrt








func InvalidObjectException_New_String(p0 *String) *InvalidObjectException { t := &InvalidObjectException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *InvalidObjectException) Ctor_String(reason *String) { t.ObjectStreamException.Ctor_String(t, reason) }

func InvalidObjectException_New_String_Throwable(p0 *String, p1 Throwable_I) *InvalidObjectException { t := &InvalidObjectException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :12:1
func (t *InvalidObjectException) Ctor_String_Throwable(reason *String, cause Throwable_I) { t.ObjectStreamException.Ctor_String_Throwable(t, reason, cause) }







type InvalidObjectException struct{ ObjectStreamException }

const InvalidObjectException_serialVersionUID int64 = 3233174318281839583

func (t *InvalidObjectException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvalidObjectException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvalidObjectException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InvalidObjectException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvalidObjectException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvalidObjectException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InvalidObjectException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvalidObjectException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvalidObjectException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvalidObjectException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvalidObjectException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvalidObjectException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvalidObjectException) Ref() any { if t == nil { return nil }; return t }

func (t *InvalidObjectException) GetClass__Class() *Class { return InvalidObjectException_class }

func (t *InvalidObjectException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvalidObjectException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvalidObjectException_InstanceOf(x any) bool { _, ok := x.(*InvalidObjectException); return ok }

func InvalidObjectException_Cast(x any) *InvalidObjectException { if x == nil { return nil }; v, ok := x.(*InvalidObjectException); if !ok { panic(ClassCast(x, InvalidObjectException_class)) }; return v }
