//line java_util_StringTokenizer.ae:1
package jrt


























func (t *StringTokenizer) SetMaxDelimCodePoint__V() {
	if t.F_delimiters == nil {
		t.F_maxDelimCodePoint = 0 } else {
			var m int32 = 0
			var c int32 = 0
			var count int32 = 0; var i int32 = 0
		L1: for {
			if i < NN(t.F_delimiters).Length__I() {
				c = int32(NN(t.F_delimiters).CharAt_I__C(i))
				var tmp1 bool; var tmp2 bool; tmp2 = c >= 55296; if tmp2 { tmp2 = c <= 57343 }; tmp1 = tmp2; if tmp1 {
					c = NN(t.F_delimiters).CodePointAt_I__I(i)
					t.F_hasSurrogates = true }
				if m < c { m = c }
				count = count + 1
				i = i + Character_CharCount_I__I(c); continue L1 }
//line :34:1
			break L1
		}







			t.F_maxDelimCodePoint = m
			if t.F_hasSurrogates {
				t.F_delimiterCodePoints = NewIntArray(count)
				var i_2 int32 = 0; var j int32 = 0; L2: for {

					if i_2 < count {
						c = NN(t.F_delimiters).CodePointAt_I__I(j)
						t.F_delimiterCodePoints.A[i_2] = c
						i_2, j = i_2+1, j+Character_CharCount_I__I(c); continue L2 }
//line :46:1
					break L2
				}
			}
		}
}


func StringTokenizer_New_String_String_Z(p0, p1 *String, p2 bool) *StringTokenizer { t := &StringTokenizer{}; t.Ctor_String_String_Z(p0, p1, p2); return t }
//line :53:1
func (t *StringTokenizer) Ctor_String_String_Z(str, delim *String, returnDelims bool) { t.F_hasSurrogates = false
	t.F_currentPosition = 0
	t.F_newPosition = -1
	t.F_delimsChanged = false
	t.F_str = str
	t.F_maxPosition = NN(str).Length__I()
	t.F_delimiters = delim
	t.F_retDelims = returnDelims
	t.SetMaxDelimCodePoint__V()
}
func StringTokenizer_New_String_String(p0, p1 *String) *StringTokenizer { t := &StringTokenizer{}; t.Ctor_String_String(p0, p1); return t }
//line :63:1
func (t *StringTokenizer) Ctor_String_String(str, delim *String) { t.Ctor_String_String_Z(str, delim, false) }


func StringTokenizer_New_String(p0 *String) *StringTokenizer { t := &StringTokenizer{}; t.Ctor_String(p0); return t }
//line :66:1
func (t *StringTokenizer) Ctor_String(str *String) { t.Ctor_String_String_Z(str, Lit_2877, false) }

func (t *StringTokenizer) SkipDelimiters_I__I(startPos int32) int32 {
	if t.F_delimiters == nil { panic(Thrown(NullPointerException_New())) }
	var position int32 = startPos
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = !t.F_retDelims; if tmp2 { tmp2 = position < t.F_maxPosition }; tmp1 = tmp2; if tmp1 {
	if !t.F_hasSurrogates {
		var c uint16 = NN(t.F_str).CharAt_I__C(position); var tmp3 bool; var tmp4 bool
		tmp4 = int32(c) > t.F_maxDelimCodePoint; if !tmp4 { tmp4 = NN(t.F_delimiters).IndexOf_I__I(int32(c)) < 0 }; tmp3 = tmp4; if tmp3 { break L1 }
		position = position + 1 } else {
			var c_2 int32 = NN(t.F_str).CodePointAt_I__I(position); var tmp5 bool; var tmp6 bool
			tmp6 = c_2 > t.F_maxDelimCodePoint; if !tmp6 { tmp6 = !t.IsDelimiter_I__Z(c_2) }; tmp5 = tmp6; if tmp5 { break L1 }
			position = position + Character_CharCount_I__I(c_2) }
//line :71:1
	continue L1 }; break L1 }
//line :70:1
	return position
}









func (t *StringTokenizer) ScanToken_I__I(startPos int32) int32 {
	var position int32 = startPos
L1: for { if position < t.F_maxPosition {
	if !t.F_hasSurrogates {
		var c uint16 = NN(t.F_str).CharAt_I__C(position); var tmp1 bool; var tmp2 bool
		tmp2 = int32(c) <= t.F_maxDelimCodePoint; if tmp2 { tmp2 = NN(t.F_delimiters).IndexOf_I__I(int32(c)) >= 0 }; tmp1 = tmp2; if tmp1 { break L1 }
		position = position + 1 } else {
			var c_2 int32 = NN(t.F_str).CodePointAt_I__I(position); var tmp3 bool; var tmp4 bool
			tmp4 = c_2 <= t.F_maxDelimCodePoint; if tmp4 { tmp4 = t.IsDelimiter_I__Z(c_2) }; tmp3 = tmp4; if tmp3 { break L1 }
			position = position + Character_CharCount_I__I(c_2) }
//line :83:1
	continue L1 }; break L1
}






	var tmp5 bool; var tmp6 bool; tmp6 = t.F_retDelims; if tmp6 { tmp6 = startPos == position }; tmp5 = tmp6; if tmp5 {
		if !t.F_hasSurrogates {
			var c_3 uint16 = NN(t.F_str).CharAt_I__C(position); var tmp7 bool; var tmp8 bool
			tmp8 = int32(c_3) <= t.F_maxDelimCodePoint; if tmp8 { tmp8 = NN(t.F_delimiters).IndexOf_I__I(int32(c_3)) >= 0 }; tmp7 = tmp8; if tmp7 {
				position = position + 1 } } else {
					var c_4 int32 = NN(t.F_str).CodePointAt_I__I(position); var tmp9 bool; var tmp10 bool
					tmp10 = c_4 <= t.F_maxDelimCodePoint; if tmp10 { tmp10 = t.IsDelimiter_I__Z(c_4) }; tmp9 = tmp10; if tmp9 {
						position = position + Character_CharCount_I__I(c_4) } } }
//line :82:1
	return position
}

















func (t *StringTokenizer) IsDelimiter_I__Z(codePoint int32) bool {
	var arr_102030 *IntArray = t.F_delimiterCodePoints; var len_102031 int32 = int32(len(arr_102030.A)); var i_102032 int32 = 0; for ; i_102032 < len_102031; i_102032++ { var delimiterCodePoint int32 = arr_102030.A[i_102032]
		if delimiterCodePoint == codePoint { return true } }
//line :101:1
	return false
}



func (t *StringTokenizer) HasMoreTokens__Z() bool {
	t.F_newPosition = t.SkipDelimiters_I__I(t.F_currentPosition)
	return t.F_newPosition < t.F_maxPosition
}
func (t *StringTokenizer) NextToken__String() *String {
	var tmp1 int32; var tmp2 bool; var tmp3 bool
	tmp3 = t.F_newPosition >= 0; if tmp3 { tmp3 = !t.F_delimsChanged }; tmp2 = tmp3; if tmp2 { tmp1 = t.F_newPosition } else {

		tmp1 = t.SkipDelimiters_I__I(t.F_currentPosition) }
//line :111:1
	t.F_currentPosition = tmp1



	t.F_delimsChanged = false
	t.F_newPosition = -1
	if t.F_currentPosition >= t.F_maxPosition { panic(Thrown(NoSuchElementException_New())) }
	var start int32 = t.F_currentPosition
	t.F_currentPosition = t.ScanToken_I__I(t.F_currentPosition)
	return NN(t.F_str).Substring_I_I__String(start, t.F_currentPosition)
}
func (t *StringTokenizer) NextToken_String__String(delim *String) *String {
	Objects_RequireNonNull_O__O(delim.Ref())
	t.F_delimiters = delim
	t.F_delimsChanged = true
	t.SetMaxDelimCodePoint__V()
	return t.NextToken__String()
}
func (t *StringTokenizer) HasMoreElements__Z() bool { return t.HasMoreTokens__Z() }

func (t *StringTokenizer) NextElement__O() any { return t.NextToken__String().Ref() }

func (t *StringTokenizer) CountTokens__I() int32 {
	var count int32 = 0; var currpos int32 = t.F_currentPosition

L1: for { if currpos < t.F_maxPosition {
	currpos = t.SkipDelimiters_I__I(currpos)
	if currpos >= t.F_maxPosition { break L1 }
	currpos = t.ScanToken_I__I(currpos)
	count = count + 1
//line :136:1
	continue L1 }; break L1 }
//line :134:1
	return count
}








type StringTokenizer struct{ Object; F_currentPosition, F_newPosition, F_maxPosition int32; F_str, F_delimiters *String; F_retDelims, F_delimsChanged bool; F_maxDelimCodePoint int32; F_hasSurrogates bool; F_delimiterCodePoints *IntArray }

func (t *StringTokenizer) Is_Enumeration() {}

func (t *StringTokenizer) AsIterator__Iterator() Iterator { return Enumeration_AsIterator__Iterator(t) }

func (t *StringTokenizer) Ref() any { if t == nil { return nil }; return t }

func (t *StringTokenizer) GetClass__Class() *Class { return StringTokenizer_class }

func (t *StringTokenizer) ToString__String() *String { return Object_toString(t) }

func (t *StringTokenizer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringTokenizer) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringTokenizer_InstanceOf(x any) bool { _, ok := x.(*StringTokenizer); return ok }

func StringTokenizer_Cast(x any) *StringTokenizer { if x == nil { return nil }; v, ok := x.(*StringTokenizer); if !ok { panic(ClassCast(x, StringTokenizer_class)) }; return v }
