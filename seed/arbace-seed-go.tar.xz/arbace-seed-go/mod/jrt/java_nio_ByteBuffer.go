//line java_nio_ByteBuffer.ae:1
package jrt





















func (t *ByteBuffer) Ctor_I_I_I_I_B1_I_MemorySegment(this ByteBuffer_I, mark, pos, lim, cap_ int32, hb *ByteArray, offset int32, segment MemorySegment) { t.Buffer.Ctor_I_I_I_I_MemorySegment(this, mark, pos, lim, cap_, segment); t.F_bigEndian = true; var tmp1 *ByteOrder = ByteOrder_NativeOrder__ByteOrder(); var tmp2 *ByteOrder; ByteOrder_Init(); tmp2 = ByteOrder_BIG_ENDIAN; t.F_nativeByteOrder = tmp1 == tmp2;


	t.F_hb = hb;
	t.F_offset = offset }

func (t *ByteBuffer) Ctor_I_I_I_I_MemorySegment(this ByteBuffer_I, mark, pos, lim, cap_ int32, segment MemorySegment) { panic(A2g_NotTranslated("java.nio.ByteBuffer.<init>(IIIILjava/lang/foreign/MemorySegment;)V")) }


func (t *ByteBuffer) Ctor_B1_J_I_MemorySegment(this ByteBuffer_I, hb *ByteArray, addr int64, cap_ int32, segment MemorySegment) { panic(A2g_NotTranslated("java.nio.ByteBuffer.<init>([BJILjava/lang/foreign/MemorySegment;)V")) }




func (t *ByteBuffer) Impl_Base__O(this ByteBuffer_I) any { return t.F_hb.Ref() }

func ByteBuffer_AllocateDirect_I__ByteBuffer(capacity int32) ByteBuffer_I { ByteBuffer_Init()
	return A2g_Missing[ByteBuffer_I]("class java.nio.DirectByteBuffer is not in the closed world")
}
func ByteBuffer_Allocate_I__ByteBuffer(capacity int32) ByteBuffer_I { ByteBuffer_Init()
	if capacity < 0 { panic(Thrown(Buffer_CreateCapacityException_I__IllegalArgumentException(capacity))) }
	return HeapByteBuffer_New_I_I_MemorySegment(capacity, capacity, nil)
}
func ByteBuffer_Wrap_B1_I_I__ByteBuffer(array *ByteArray, offset, length int32) ByteBuffer_I { ByteBuffer_Init()
	var tmp1 ByteBuffer_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = HeapByteBuffer_New_B1_I_I_MemorySegment(array, offset, length, nil); return nil }()
//line :47:1
	if tmp2 != nil { if IllegalArgumentException_InstanceOf(tmp2) { var x IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = x

		panic(Thrown(IndexOutOfBoundsException_New())) } else {
//line :47:1
			panic(tmp2) } }; return tmp1
}


func ByteBuffer_Wrap_B1__ByteBuffer(array *ByteArray) ByteBuffer_I { ByteBuffer_Init()
	return ByteBuffer_Wrap_B1_I_I__ByteBuffer(array, 0, int32(len(array.A)))
}
















func (t *ByteBuffer) Impl_Get_B1_I_I__ByteBuffer(this ByteBuffer_I, dst *ByteArray, offset, length int32) ByteBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var pos int32 = this.Position__I()
	if length > this.Limit__I()-pos {
		panic(Thrown(BufferUnderflowException_New())) }
	this.GetArray_I_B1_I_I__ByteBuffer(pos, dst, offset, length)
	this.Position_I__ByteBuffer(pos + length)
//line :72:1
	return this
}





func (t *ByteBuffer) Impl_Get_B1__ByteBuffer(this ByteBuffer_I, dst *ByteArray) ByteBuffer_I {
	return this.Get_B1_I_I__ByteBuffer(dst, 0, int32(len(dst.A)))
}
func (t *ByteBuffer) Impl_Get_I_B1_I_I__ByteBuffer(this ByteBuffer_I, index int32, dst *ByteArray, offset, length int32) ByteBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	this.GetArray_I_B1_I_I__ByteBuffer(index, dst, offset, length)
//line :82:1
	return this
}




func (t *ByteBuffer) Impl_Get_I_B1__ByteBuffer(this ByteBuffer_I, index int32, dst *ByteArray) ByteBuffer_I {
	return this.Get_I_B1_I_I__ByteBuffer(index, dst, 0, int32(len(dst.A)))
}
func (t *ByteBuffer) Impl_GetArray_I_B1_I_I__ByteBuffer(this ByteBuffer_I, index int32, dst *ByteArray, offset, length int32) ByteBuffer_I {
	if int64(length)<<0 > 6 {
		var bufAddr int64 = t.F_address + int64(index)<<0; var dstOffset int64 = ByteBuffer_ARRAY_BASE_OFFSET + int64(offset)<<0; var len_ int64 = int64(length) << 0; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)



			{ var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp1).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(this.Session__MemorySessionImpl(), nil, this.Base__O(), bufAddr, dst.Ref(), dstOffset, len_) }; return nil
		}()






		Reference_ReachabilityFence_O__V(this)
//line :96:1
		if tmp2 != nil { panic(tmp2)
		}






	} else {

		var end int32 = offset + length; var i int32 = offset; var j int32 = index
	L1: for {

		if i < end {
			dst.A[i] = this.Get_I__B(j)
			i, j = i+1, j+1; continue L1 }
//line :107:1
		break L1 } }
//line :91:1
	return this
}





















func (t *ByteBuffer) Impl_Put_ByteBuffer__ByteBuffer(this, src ByteBuffer_I) ByteBuffer_I {
	if src == this { panic(Thrown(Buffer_CreateSameBufferException__IllegalArgumentException())) }
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	var srcPos int32 = src.Position__I(); var srcLim int32 = src.Limit__I(); var srcRem int32

	if srcPos <= srcLim { srcRem = srcLim - srcPos } else { srcRem = 0 }
//line :117:1
	var pos int32 = this.Position__I(); var lim int32 = this.Limit__I(); var rem int32




	if pos <= lim { rem = lim - pos } else { rem = 0 }
	if srcRem > rem { panic(Thrown(BufferOverflowException_New())) }
	this.PutBuffer_I_ByteBuffer_I_I__V(pos, src, srcPos, srcRem)
	this.Position_I__ByteBuffer(pos + srcRem)
	src.Position_I__ByteBuffer(srcPos + srcRem)
//line :117:1
	return this
}










func (t *ByteBuffer) Impl_Put_I_ByteBuffer_I_I__ByteBuffer(this ByteBuffer_I, index int32, src ByteBuffer_I, offset, length int32) ByteBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, src.Limit__I())
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	this.PutBuffer_I_ByteBuffer_I_I__V(index, src, offset, length)
//line :129:1
	return this
}





func (t *ByteBuffer) Impl_PutBuffer_I_ByteBuffer_I_I__V(this ByteBuffer_I, pos int32, src ByteBuffer_I, srcPos, n int32) {
	var srcBase any = src.Base__O(); var tmp1 bool; var tmp2 bool
	tmp2 = !(srcBase == nil); if !tmp2 { tmp2 = src.IsDirect__Z() }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	var base any = this.Base__O(); var tmp3 bool; var tmp4 bool
	tmp4 = !(base == nil); if !tmp4 { tmp4 = this.IsDirect__Z() }; tmp3 = tmp4; if !A2g_AssertionsDisabled && !tmp3 { panic(Thrown(AssertionError_New())) }
	var srcAddr int64 = src.Self_Buffer().F_address + int64(srcPos)<<0; var addr int64 = t.F_address + int64(pos)<<0; var len_ int64 = int64(n) << 0; tmp6 := func() (exc Throwable_I) { defer Catch(&exc)



		{ var tmp5 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp5).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(src.Session__MemorySessionImpl(), this.Session__MemorySessionImpl(), srcBase, srcAddr, base, addr, len_) }; return nil
	}()






	Reference_ReachabilityFence_O__V(src); Reference_ReachabilityFence_O__V(this)
//line :144:1
	if tmp6 != nil { panic(tmp6)
	}
}








func (t *ByteBuffer) Impl_Put_B1_I_I__ByteBuffer(this ByteBuffer_I, src *ByteArray, offset, length int32) ByteBuffer_I {
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var pos int32 = this.Position__I()
	if length > this.Limit__I()-pos {
		panic(Thrown(BufferOverflowException_New())) }
	this.PutArray_I_B1_I_I__ByteBuffer(pos, src, offset, length)
	this.Position_I__ByteBuffer(pos + length)
//line :158:1
	return this
}





func (t *ByteBuffer) Impl_Put_B1__ByteBuffer(this ByteBuffer_I, src *ByteArray) ByteBuffer_I {
	return this.Put_B1_I_I__ByteBuffer(src, 0, int32(len(src.A)))
}
func (t *ByteBuffer) Impl_Put_I_B1_I_I__ByteBuffer(this ByteBuffer_I, index int32, src *ByteArray, offset, length int32) ByteBuffer_I {
	if this.IsReadOnly__Z() { panic(Thrown(ReadOnlyBufferException_New())) }
	Objects_CheckFromIndexSize_I_I_I__I(index, length, this.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	this.PutArray_I_B1_I_I__ByteBuffer(index, src, offset, length)
//line :168:1
	return this
}





func (t *ByteBuffer) Impl_Put_I_B1__ByteBuffer(this ByteBuffer_I, index int32, src *ByteArray) ByteBuffer_I {
	return this.Put_I_B1_I_I__ByteBuffer(index, src, 0, int32(len(src.A)))
}
func (t *ByteBuffer) Impl_PutArray_I_B1_I_I__ByteBuffer(this ByteBuffer_I, index int32, src *ByteArray, offset, length int32) ByteBuffer_I {
	if int64(length)<<0 > 6 {
		var bufAddr int64 = t.F_address + int64(index)<<0; var srcOffset int64 = ByteBuffer_ARRAY_BASE_OFFSET + int64(offset)<<0; var len_ int64 = int64(length) << 0; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)



			{ var tmp1 *ScopedMemoryAccess = Buffer_SCOPED_MEMORY_ACCESS; NN(tmp1).CopyMemory_MemorySessionImpl_MemorySessionImpl_O_J_O_J_J__V(nil, this.Session__MemorySessionImpl(), src.Ref(), srcOffset, this.Base__O(), bufAddr, len_) }; return nil
		}()






		Reference_ReachabilityFence_O__V(this)
//line :183:1
		if tmp2 != nil { panic(tmp2)
		}






	} else {

		var end int32 = offset + length; var i int32 = offset; var j int32 = index
	L1: for {

		if i < end {
			this.Put_I_B__ByteBuffer(j, src.A[i])
			i, j = i+1, j+1; continue L1 }
//line :194:1
		break L1 } }
//line :178:1
	return this
}





















func (t *ByteBuffer) Impl_HasArray__Z(this ByteBuffer_I) bool {
	var tmp1 bool; tmp1 = !(t.F_hb == nil); if tmp1 { tmp1 = !t.F_isReadOnly }; return tmp1
}
func (t *ByteBuffer) Impl_Array__B1(this ByteBuffer_I) *ByteArray {
	if t.F_hb == nil { panic(Thrown(UnsupportedOperationException_New())) }
	if t.F_isReadOnly { panic(Thrown(ReadOnlyBufferException_New())) }
//line :204:1
	return t.F_hb
}



func (t *ByteBuffer) Impl_ArrayOffset__I(this ByteBuffer_I) int32 {
	if t.F_hb == nil { panic(Thrown(UnsupportedOperationException_New())) }
	if t.F_isReadOnly { panic(Thrown(ReadOnlyBufferException_New())) }
//line :209:1
	return t.F_offset
}



func (t *ByteBuffer) Impl_Position_I__ByteBuffer(this ByteBuffer_I, newPosition int32) ByteBuffer_I {
	t.Buffer.Impl_Position_I__Buffer(this, newPosition)
//line :214:1
	return this
}


func (t *ByteBuffer) Impl_Limit_I__ByteBuffer(this ByteBuffer_I, newLimit int32) ByteBuffer_I {
	t.Buffer.Impl_Limit_I__Buffer(this, newLimit)
//line :218:1
	return this
}


func (t *ByteBuffer) Impl_Mark__ByteBuffer(this ByteBuffer_I) ByteBuffer_I { t.Buffer.Impl_Mark__Buffer(this); return this }

func (t *ByteBuffer) Impl_Reset__ByteBuffer(this ByteBuffer_I) ByteBuffer_I { t.Buffer.Impl_Reset__Buffer(this); return this }

func (t *ByteBuffer) Impl_Clear__ByteBuffer(this ByteBuffer_I) ByteBuffer_I { t.Buffer.Impl_Clear__Buffer(this); return this }

func (t *ByteBuffer) Impl_Flip__ByteBuffer(this ByteBuffer_I) ByteBuffer_I { t.Buffer.Impl_Flip__Buffer(this); return this }

func (t *ByteBuffer) Impl_Rewind__ByteBuffer(this ByteBuffer_I) ByteBuffer_I { t.Buffer.Impl_Rewind__Buffer(this); return this }





func (t *ByteBuffer) Impl_ToString__String(this ByteBuffer_I) *String {
	return Concat(NN(this.GetClass__Class()).GetName__String(), Lit_1487, StrOfInt(this.Position__I()), Lit_1488, StrOfInt(this.Limit__I()), Lit_1489, StrOfInt(this.Capacity__I()), Lit_1189)
}







func (t *ByteBuffer) Impl_HashCode__I(this ByteBuffer_I) int32 {
	var h int32 = 1; var p int32 = this.Position__I(); var i int32 = this.Limit__I() - 1

L1: for {
	if i >= p {
		h = 31*h + int32(this.Get_I__B(i))
		i = i - 1; continue L1 }
//line :249:1
	break L1 }
//line :247:1
	return h
}






func (t *ByteBuffer) Impl_Equals_O__Z(this ByteBuffer_I, ob any) bool {
	if any(this) == any(ob) { return true } else { if !ByteBuffer_InstanceOf(ob) { return false } else {



		var that ByteBuffer_I = ByteBuffer_Cast(ob); var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var tmp1 bool; var tmp2 bool




		tmp2 = thisRem < 0; if !tmp2 { tmp2 = !(thisRem == thatRem) }; tmp1 = tmp2; if tmp1 { return false } else {

			return A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world") < 0
		} } } }
func (t *ByteBuffer) Impl_CompareTo_ByteBuffer__I(this, that ByteBuffer_I) int32 {
	var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var length int32 = Math_Min_I_I__I(thisRem, thatRem)




	if length < 0 { return -1 } else {

		var i int32; i = A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world")
		if i >= 0 {
			return ByteBuffer_Compare_B_B__I(this.Get_I__B(thisPos+i), that.Get_I__B(thatPos+i)) } else {

				return thisRem - thatRem
			} } }
func ByteBuffer_Compare_B_B__I(x, y int8) int32 { ByteBuffer_Init()
	return Byte_Compare_B_B__I(x, y)
}
func (t *ByteBuffer) Impl_Mismatch_ByteBuffer__I(this, that ByteBuffer_I) int32 {
	var thisPos int32 = this.Position__I(); var thisRem int32 = this.Limit__I() - thisPos; var thatPos int32 = that.Position__I(); var thatRem int32 = that.Limit__I() - thatPos; var length int32 = Math_Min_I_I__I(thisRem, thatRem)




	if length < 0 { return -1 } else {

		var r int32; r = A2g_Missing[int32]("class java.nio.BufferMismatch is not in the closed world")
		var tmp1 bool; var tmp2 bool; tmp2 = r == -1; if tmp2 { tmp2 = !(thisRem == thatRem) }; tmp1 = tmp2; if tmp1 { return length } else { return r
		}
	}
}


func (t *ByteBuffer) Impl_Order__ByteOrder(this ByteBuffer_I) *ByteOrder {
	if t.F_bigEndian { ByteOrder_Init(); return ByteOrder_BIG_ENDIAN } else { ByteOrder_Init(); return ByteOrder_LITTLE_ENDIAN
	} }
func (t *ByteBuffer) Impl_Order_ByteOrder__ByteBuffer(this ByteBuffer_I, bo *ByteOrder) ByteBuffer_I {
	var tmp1 *ByteOrder; ByteOrder_Init(); tmp1 = ByteOrder_BIG_ENDIAN; t.F_bigEndian = bo == tmp1
	var tmp2 bool = t.F_bigEndian; var tmp3 *ByteOrder = ByteOrder_NativeOrder__ByteOrder(); var tmp4 *ByteOrder; ByteOrder_Init(); tmp4 = ByteOrder_BIG_ENDIAN; t.F_nativeByteOrder = tmp2 == (tmp3 == tmp4)
//line :304:1
	return this
}



func (t *ByteBuffer) Impl_AlignmentOffset_I_I__I(this ByteBuffer_I, index, unitSize int32) int32 {
	if index < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1490, StrOfInt(index))))) }
	var tmp1 bool; var tmp2 bool; tmp2 = unitSize < 1; if !tmp2 {
		tmp2 = !(unitSize&(unitSize-1) == 0) }
//line :311:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1491, StrOfInt(unitSize))))) }
	var tmp3 bool; var tmp4 bool; tmp4 = unitSize > 1; if tmp4 { tmp4 = !this.IsDirect__Z() }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(UnsupportedOperationException_New_String(Concat(Lit_1492, StrOfInt(unitSize)))))
	}
	return int32((t.F_address + int64(index)) & int64(unitSize-1))
}

func (t *ByteBuffer) Impl_AlignedSlice_I__ByteBuffer(this ByteBuffer_I, unitSize int32) ByteBuffer_I {
	var pos int32 = this.Position__I(); var lim int32 = this.Limit__I(); var pos_mod int32 = this.AlignmentOffset_I_I__I(pos, unitSize); var lim_mod int32 = this.AlignmentOffset_I_I__I(lim, unitSize); var aligned_pos int32



	if pos_mod > 0 {
		aligned_pos = pos + (unitSize - pos_mod) } else {
//line :325:1
			aligned_pos = pos }
//line :321:1
	var aligned_lim int32 = lim - lim_mod; var tmp1 bool; var tmp2 bool









	tmp2 = aligned_pos > lim; if !tmp2 { tmp2 = aligned_lim < pos }; tmp1 = tmp2; if tmp1 { var tmp3 int32; aligned_lim = pos; tmp3 = aligned_lim; aligned_pos = tmp3 }
	return this.Slice_I_I__ByteBuffer(aligned_pos, aligned_lim-aligned_pos) }
//line :330:1
type ByteBuffer struct{ Buffer; F_hb *ByteArray; F_offset int32; F_isReadOnly, F_bigEndian, F_nativeByteOrder bool }

type ByteBuffer_I interface{ Buffer_I; Comparable; Self_ByteBuffer() *ByteBuffer; Base__O() any; Slice__ByteBuffer() ByteBuffer_I; Slice_I_I__ByteBuffer(p0, p1 int32) ByteBuffer_I; Duplicate__ByteBuffer() ByteBuffer_I; AsReadOnlyBuffer__ByteBuffer() ByteBuffer_I; Get__B() int8; Put_B__ByteBuffer(p0 int8) ByteBuffer_I; Get_I__B(p0 int32) int8; Put_I_B__ByteBuffer(p0 int32, p1 int8) ByteBuffer_I; Get_B1_I_I__ByteBuffer(p0 *ByteArray, p1, p2 int32) ByteBuffer_I; Get_B1__ByteBuffer(p0 *ByteArray) ByteBuffer_I; Get_I_B1_I_I__ByteBuffer(p0 int32, p1 *ByteArray, p2, p3 int32) ByteBuffer_I; Get_I_B1__ByteBuffer(p0 int32, p1 *ByteArray) ByteBuffer_I; GetArray_I_B1_I_I__ByteBuffer(p0 int32, p1 *ByteArray, p2, p3 int32) ByteBuffer_I; Put_ByteBuffer__ByteBuffer(p0 ByteBuffer_I) ByteBuffer_I; Put_I_ByteBuffer_I_I__ByteBuffer(p0 int32, p1 ByteBuffer_I, p2, p3 int32) ByteBuffer_I; PutBuffer_I_ByteBuffer_I_I__V(p0 int32, p1 ByteBuffer_I, p2, p3 int32); Put_B1_I_I__ByteBuffer(p0 *ByteArray, p1, p2 int32) ByteBuffer_I; Put_B1__ByteBuffer(p0 *ByteArray) ByteBuffer_I; Put_I_B1_I_I__ByteBuffer(p0 int32, p1 *ByteArray, p2, p3 int32) ByteBuffer_I; Put_I_B1__ByteBuffer(p0 int32, p1 *ByteArray) ByteBuffer_I; PutArray_I_B1_I_I__ByteBuffer(p0 int32, p1 *ByteArray, p2, p3 int32) ByteBuffer_I; HasArray__Z() bool; Array__B1() *ByteArray; ArrayOffset__I() int32; Position_I__ByteBuffer(p0 int32) ByteBuffer_I; Limit_I__ByteBuffer(p0 int32) ByteBuffer_I; Mark__ByteBuffer() ByteBuffer_I; Reset__ByteBuffer() ByteBuffer_I; Clear__ByteBuffer() ByteBuffer_I; Flip__ByteBuffer() ByteBuffer_I; Rewind__ByteBuffer() ByteBuffer_I; Compact__ByteBuffer() ByteBuffer_I; IsDirect__Z() bool; CompareTo_ByteBuffer__I(p0 ByteBuffer_I) int32; Mismatch_ByteBuffer__I(p0 ByteBuffer_I) int32; Order__ByteOrder() *ByteOrder; Order_ByteOrder__ByteBuffer(p0 *ByteOrder) ByteBuffer_I; AlignmentOffset_I_I__I(p0, p1 int32) int32; AlignedSlice_I__ByteBuffer(p0 int32) ByteBuffer_I; GetChar__C() uint16; PutChar_C__ByteBuffer(p0 uint16) ByteBuffer_I; GetChar_I__C(p0 int32) uint16; PutChar_I_C__ByteBuffer(p0 int32, p1 uint16) ByteBuffer_I; AsCharBuffer__CharBuffer() CharBuffer_I; GetShort__S() int16; PutShort_S__ByteBuffer(p0 int16) ByteBuffer_I; GetShort_I__S(p0 int32) int16; PutShort_I_S__ByteBuffer(p0 int32, p1 int16) ByteBuffer_I; GetInt__I() int32; PutInt_I__ByteBuffer(p0 int32) ByteBuffer_I; GetInt_I__I(p0 int32) int32; PutInt_I_I__ByteBuffer(p0, p1 int32) ByteBuffer_I; AsIntBuffer__IntBuffer() IntBuffer_I; GetLong__J() int64; PutLong_J__ByteBuffer(p0 int64) ByteBuffer_I; GetLong_I__J(p0 int32) int64; PutLong_I_J__ByteBuffer(p0 int32, p1 int64) ByteBuffer_I; GetFloat__F() float32; PutFloat_F__ByteBuffer(p0 float32) ByteBuffer_I; GetFloat_I__F(p0 int32) float32; PutFloat_I_F__ByteBuffer(p0 int32, p1 float32) ByteBuffer_I; GetDouble__D() float64; PutDouble_D__ByteBuffer(p0 float64) ByteBuffer_I; GetDouble_I__D(p0 int32) float64; PutDouble_I_D__ByteBuffer(p0 int32, p1 float64) ByteBuffer_I; Position_I__Buffer(p0 int32) Buffer_I; Limit_I__Buffer(p0 int32) Buffer_I; Mark__Buffer() Buffer_I; Reset__Buffer() Buffer_I; Clear__Buffer() Buffer_I; Flip__Buffer() Buffer_I; Rewind__Buffer() Buffer_I; Array__O() any; Slice__Buffer() Buffer_I; Slice_I_I__Buffer(p0, p1 int32) Buffer_I; Duplicate__Buffer() Buffer_I; CompareTo_O__I(p0 any) int32 }

func (t *ByteBuffer) Self_ByteBuffer() *ByteBuffer { return t }

func (t *ByteBuffer) Is_Comparable() {}

var ByteBuffer_ARRAY_BASE_OFFSET int64

var ByteBuffer_init ClassInit

func ByteBuffer_Init() { if !ByteBuffer_init.Done() { ByteBuffer_init.Run(ByteBuffer_clinit) } }

func ByteBuffer_clinit() { Buffer_Init(); ByteBuffer_ARRAY_BASE_OFFSET = NN(Buffer_UNSAFE).ArrayBaseOffset_Class__J(Prim_byte.ArrayClass()) }

func (t *ByteBuffer) Impl_Position_I__Buffer(this ByteBuffer_I, p0 int32) Buffer_I { return this.Position_I__ByteBuffer(p0) }

func (t *ByteBuffer) Impl_Limit_I__Buffer(this ByteBuffer_I, p0 int32) Buffer_I { return this.Limit_I__ByteBuffer(p0) }

func (t *ByteBuffer) Impl_Mark__Buffer(this ByteBuffer_I) Buffer_I { return this.Mark__ByteBuffer() }

func (t *ByteBuffer) Impl_Reset__Buffer(this ByteBuffer_I) Buffer_I { return this.Reset__ByteBuffer() }

func (t *ByteBuffer) Impl_Clear__Buffer(this ByteBuffer_I) Buffer_I { return this.Clear__ByteBuffer() }

func (t *ByteBuffer) Impl_Flip__Buffer(this ByteBuffer_I) Buffer_I { return this.Flip__ByteBuffer() }

func (t *ByteBuffer) Impl_Rewind__Buffer(this ByteBuffer_I) Buffer_I { return this.Rewind__ByteBuffer() }

func (t *ByteBuffer) Impl_Array__O(this ByteBuffer_I) any { return this.Array__B1().Ref() }

func (t *ByteBuffer) Impl_Slice__Buffer(this ByteBuffer_I) Buffer_I { return this.Slice__ByteBuffer() }

func (t *ByteBuffer) Impl_Slice_I_I__Buffer(this ByteBuffer_I, p0, p1 int32) Buffer_I { return this.Slice_I_I__ByteBuffer(p0, p1) }

func (t *ByteBuffer) Impl_Duplicate__Buffer(this ByteBuffer_I) Buffer_I { return this.Duplicate__ByteBuffer() }

func (t *ByteBuffer) Impl_CompareTo_O__I(this ByteBuffer_I, p0 any) int32 { return this.CompareTo_ByteBuffer__I(ByteBuffer_Cast(p0)) }

func ByteBuffer_InstanceOf(x any) bool { _, ok := x.(ByteBuffer_I); return ok }

func ByteBuffer_Cast(x any) ByteBuffer_I { if x == nil { return nil }; v, ok := x.(ByteBuffer_I); if !ok { panic(ClassCast(x, ByteBuffer_class)) }; return v }
