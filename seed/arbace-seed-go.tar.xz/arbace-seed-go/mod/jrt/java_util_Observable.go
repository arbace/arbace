//line java_util_Observable.ae:1
package jrt








func Observable_New() *Observable { t := &Observable{}; t.Ctor(); return t }
//line :10:1
func (t *Observable) Ctor() { t.F_changed = false; t.F_obs = Vector_New() }

func (t *Observable) AddObserver_Observer__V(o Observer) { MonitorEnter(t); defer MonitorExit(t)
	if o == nil { panic(Thrown(NullPointerException_New())) }
	if t.F_obs.Contains_O__Z(o) { } else { t.F_obs.AddElement_O__V(o)
	} }
func (t *Observable) DeleteObserver_Observer__V(o Observer) { MonitorEnter(t); defer MonitorExit(t)
	t.F_obs.RemoveElement_O__Z(o)
}
func (t *Observable) NotifyObservers__V() {
	t.NotifyObservers_O__V(nil)
}
func (t *Observable) NotifyObservers_O__V(arg any) {
	var arrLocal *RefArray; var tmp1 any = t
	MonitorEnter(tmp1); tmp2, tmp3 := func() (ctl int32, rv bool) { defer MonitorExit(tmp1); if t.F_changed { } else { return 2, false }; arrLocal = t.F_obs.ToArray__O1(); t.ClearChanged__V(); return 0, false }(); _ = tmp3; switch tmp2 { case 2: { return }}
	var i int32 = int32(len(arrLocal.A)) - 1; L1: for {
		if i >= 0 {
			Observer_Cast(arrLocal.A[i]).Update_Observable_O__V(t, arg)
			i = i - 1; continue L1 }
//line :25:1
		break L1
	}
}


func (t *Observable) DeleteObservers__V() { MonitorEnter(t); defer MonitorExit(t)
	t.F_obs.RemoveAllElements__V()
}
func (t *Observable) SetChanged__V() { panic(A2g_NotTranslated("java.util.Observable.setChanged()V")) }


func (t *Observable) ClearChanged__V() { MonitorEnter(t); defer MonitorExit(t)
	t.F_changed = false
}
func (t *Observable) HasChanged__Z() bool { MonitorEnter(t); defer MonitorExit(t); return t.F_changed }

func (t *Observable) CountObservers__I() int32 { MonitorEnter(t); defer MonitorExit(t); return t.F_obs.Size__I() }



type Observable struct{ Object; F_changed bool; F_obs Vector_I }

func (t *Observable) Ref() any { if t == nil { return nil }; return t }

func (t *Observable) GetClass__Class() *Class { return Observable_class }

func (t *Observable) ToString__String() *String { return Object_toString(t) }

func (t *Observable) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Observable) CloneShallow() any { panic(CloneNotSupported(t)) }

func Observable_InstanceOf(x any) bool { _, ok := x.(*Observable); return ok }

func Observable_Cast(x any) *Observable { if x == nil { return nil }; v, ok := x.(*Observable); if !ok { panic(ClassCast(x, Observable_class)) }; return v }
