//line java_util_DoubleSummaryStatistics.ae:1
package jrt





















func DoubleSummaryStatistics_New() *DoubleSummaryStatistics { t := &DoubleSummaryStatistics{}; t.Ctor(); return t }
//line :23:1
func (t *DoubleSummaryStatistics) Ctor() { t.F_min = PosInf64; t.F_max = NegInf64 }

func DoubleSummaryStatistics_New_J_D_D_D(p0 int64, p1, p2, p3 float64) *DoubleSummaryStatistics { t := &DoubleSummaryStatistics{}; t.Ctor_J_D_D_D(p0, p1, p2, p3); return t }
//line :25:1
func (t *DoubleSummaryStatistics) Ctor_J_D_D_D(count int64, min_, max_, sum float64) { t.F_min = PosInf64; t.F_max = NegInf64

	if count < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2661))) } else {
			if count > 0 {
				if min_ > max_ { panic(Thrown(IllegalArgumentException_New_String(Lit_2662))) }
				var ncount int64 = DoubleStream_Of_D1__DoubleStream(DoubleArrayOf(min_, max_, sum)).Filter_DoublePredicate__DoubleStream(&DoublePredicate_Fn{Fn: func(p0 float64) bool { return Double_IsNaN_D__Z(p0) }}).Count__J(); var tmp1 bool; var tmp2 bool

				tmp2 = ncount > 0; if tmp2 { tmp2 = ncount < 3 }; tmp1 = tmp2; if tmp1 {
					panic(Thrown(IllegalArgumentException_New_String(Lit_2663)))
				}
				t.F_count = count
				t.F_sum = sum
				t.F_simpleSum = sum
				t.F_sumCompensation = 0.0
				t.F_min = min_
				t.F_max = max_
			} } }
func (t *DoubleSummaryStatistics) Accept_D__V(value float64) {
	t.F_count = t.F_count + 1
	t.F_simpleSum = t.F_simpleSum + value
	t.SumWithCompensation_D__V(value)
	t.F_min = Math_Min_D_D__D(t.F_min, value)
	t.F_max = Math_Max_D_D__D(t.F_max, value)
}
func (t *DoubleSummaryStatistics) Combine_DoubleSummaryStatistics__V(other *DoubleSummaryStatistics) {
	var tmp1 int64 = t.F_count; t.F_count = tmp1 + other.F_count
	var tmp2 float64 = t.F_simpleSum; t.F_simpleSum = tmp2 + other.F_simpleSum
	t.SumWithCompensation_D__V(other.F_sum)
	t.SumWithCompensation_D__V(-other.F_sumCompensation)
	var tmp3 float64 = t.F_min; t.F_min = Math_Min_D_D__D(tmp3, other.F_min)
	var tmp4 float64 = t.F_max; t.F_max = Math_Max_D_D__D(tmp4, other.F_max)
}
func (t *DoubleSummaryStatistics) SumWithCompensation_D__V(value float64) {
	var tmp float64 = value - t.F_sumCompensation; var velvel float64 = t.F_sum + tmp

	t.F_sumCompensation = velvel - t.F_sum - tmp
	t.F_sum = velvel
}
func (t *DoubleSummaryStatistics) GetCount__J() int64 { return t.F_count }

func (t *DoubleSummaryStatistics) GetSum__D() float64 {
	var tmp float64 = t.F_sum - t.F_sumCompensation; var tmp1 bool; var tmp2 bool
	tmp2 = Double_IsNaN_D__Z(tmp); if tmp2 { tmp2 = Double_IsInfinite_D__Z(t.F_simpleSum) }; tmp1 = tmp2; if tmp1 { return t.F_simpleSum } else { return tmp
	} }
func (t *DoubleSummaryStatistics) GetMin__D() float64 { return t.F_min }

func (t *DoubleSummaryStatistics) GetMax__D() float64 { return t.F_max }

func (t *DoubleSummaryStatistics) GetAverage__D() float64 {
	if t.GetCount__J() > 0 { return t.GetSum__D() / float64(t.GetCount__J()) } else { return 0.0
	} }
func (t *DoubleSummaryStatistics) ToString__String() *String {
	return String_Format_String_O1__String(Lit_2664, RefArrayOf(Object_class, NN(t.GetClass__Class()).GetSimpleName__String().Ref(), Long_ValueOf_J__Long(t.GetCount__J()), Double_ValueOf_D__Double(t.GetSum__D()), Double_ValueOf_D__Double(t.GetMin__D()), Double_ValueOf_D__Double(t.GetAverage__D()), Double_ValueOf_D__Double(t.GetMax__D())))
}


type DoubleSummaryStatistics struct{ Object; F_count int64; F_sum, F_sumCompensation, F_simpleSum, F_min, F_max float64 }

func (t *DoubleSummaryStatistics) Is_DoubleConsumer() {}

func (t *DoubleSummaryStatistics) AndThen_DoubleConsumer__DoubleConsumer(p0 DoubleConsumer) DoubleConsumer { return DoubleConsumer_AndThen_DoubleConsumer__DoubleConsumer(t, p0) }

func (t *DoubleSummaryStatistics) Ref() any { if t == nil { return nil }; return t }

func (t *DoubleSummaryStatistics) GetClass__Class() *Class { return DoubleSummaryStatistics_class }

func (t *DoubleSummaryStatistics) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DoubleSummaryStatistics) CloneShallow() any { panic(CloneNotSupported(t)) }

func DoubleSummaryStatistics_InstanceOf(x any) bool { _, ok := x.(*DoubleSummaryStatistics); return ok }

func DoubleSummaryStatistics_Cast(x any) *DoubleSummaryStatistics { if x == nil { return nil }; v, ok := x.(*DoubleSummaryStatistics); if !ok { panic(ClassCast(x, DoubleSummaryStatistics_class)) }; return v }
