//line java_sql_Date.ae:1
package jrt








func Sql_Date_New_I_I_I(p0, p1, p2 int32) *Sql_Date { t := &Sql_Date{}; t.Ctor_I_I_I(p0, p1, p2); return t }
//line :10:1
func (t *Sql_Date) Ctor_I_I_I(year, month, day int32) { t.Date.Ctor_I_I_I(t, year, month, day) }


func Sql_Date_New_J(p0 int64) *Sql_Date { t := &Sql_Date{}; t.Ctor_J(p0); return t }
//line :13:1
func (t *Sql_Date) Ctor_J(date int64) { t.Date.Ctor_J(t, date) }

func (t *Sql_Date) SetTime_J__V(date int64) { t.Date.Impl_SetTime_J__V(t, date) }

func Sql_Date_ValueOf_String__Sql_Date(s *String) *Sql_Date {
	if s == nil { panic(Thrown(IllegalArgumentException_New())) }
	var d *Sql_Date; var firstDash int32 = NN(s).IndexOf_I__I(45); var secondDash int32 = NN(s).IndexOf_I_I__I(45, firstDash+1); var len_ int32 = NN(s).Length__I(); var tmp1 bool; var tmp2 bool; var tmp3 bool








	tmp3 = firstDash > 0; if tmp3 { tmp3 = secondDash > 0 }; tmp2 = tmp3; if tmp2 {
		tmp2 = secondDash < len_-1 }
//line :28:1
	tmp1 = tmp2; if tmp1 {

		var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = firstDash == 4; if tmp6 {
			var tmp7 bool; tmp7 = secondDash-firstDash > 1; if tmp7 {
				tmp7 = secondDash-firstDash <= 3 }
//line :31:1
			tmp6 = tmp7 }
//line :30:1
		tmp5 = tmp6; if tmp5 {



			var tmp8 bool; tmp8 = len_-secondDash > 1; if tmp8 {
				tmp8 = len_-secondDash <= 3 }
//line :34:1
			tmp5 = tmp8 }
//line :30:1
		tmp4 = tmp5; if tmp4 {






			var year int32 = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), 0, firstDash, 10); var month int32 = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), firstDash+1, secondDash, 10); var day int32 = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), secondDash+1, len_, 10); var tmp9 bool; var tmp10 bool; var tmp11 bool


			tmp11 = month >= 1; if tmp11 { tmp11 = month <= 12 }; tmp10 = tmp11; if tmp10 { var tmp12 bool; tmp12 = day >= 1; if tmp12 { tmp12 = day <= 31 }; tmp10 = tmp12 }; tmp9 = tmp10; if tmp9 {
				d = Sql_Date_New_I_I_I(year-1900, month-1, day)
			} } }
	if d == nil { panic(Thrown(IllegalArgumentException_New())) }
//line :19:1
	return d
}

























func (t *Sql_Date) ToString__String() *String {
	var year int32 = t.Date.Impl_GetYear__I(t) + 1900; var month int32 = t.Date.Impl_GetMonth__I(t) + 1; var day int32 = t.Date.Impl_GetDate__I(t); var buf *CharArray = NewCharArray(10)



	Sql_Date_FormatDecimalInt_I_C1_I_I__V(year, buf, 0, 4)
	buf.A[4] = 45
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(month, buf, 5, 2)
	buf.A[7] = 45
	Sql_Date_FormatDecimalInt_I_C1_I_I__V(day, buf, 8, 2)
	return String_New_C1(buf)
}
func Sql_Date_FormatDecimalInt_I_C1_I_I__V(val int32, buf *CharArray, offset, len_ int32) {
	var charPos int32 = offset + len_
L1: for {
	var tmp1 int32
	charPos = charPos - 1; tmp1 = charPos
//line :61:1
	buf.A[tmp1] = uint16(48 + val%10)


	val = val / 10
	if charPos > offset { continue L1 }
//line :60:1
	break L1
}
}




func (t *Sql_Date) GetHours__I() int32 {
	panic(Thrown(IllegalArgumentException_New()))
}
func (t *Sql_Date) GetMinutes__I() int32 {
	panic(Thrown(IllegalArgumentException_New()))
}
func (t *Sql_Date) GetSeconds__I() int32 {
	panic(Thrown(IllegalArgumentException_New()))
}
func (t *Sql_Date) SetHours_I__V(i int32) {
	panic(Thrown(IllegalArgumentException_New()))
}
func (t *Sql_Date) SetMinutes_I__V(i int32) {
	panic(Thrown(IllegalArgumentException_New()))
}
func (t *Sql_Date) SetSeconds_I__V(i int32) {
	panic(Thrown(IllegalArgumentException_New()))
}


func Sql_Date_ValueOf_LocalDate__Sql_Date(date *LocalDate) *Sql_Date {
	return Sql_Date_New_I_I_I(NN(date).GetYear__I()-1900, NN(date).GetMonthValue__I()-1, NN(date).GetDayOfMonth__I())
}


func (t *Sql_Date) ToLocalDate__LocalDate() *LocalDate {
	return LocalDate_Of_I_I_I__LocalDate(t.GetYear__I()+1900, t.GetMonth__I()+1, t.GetDate__I())
}


func (t *Sql_Date) ToInstant__Instant() *Instant {
	panic(Thrown(UnsupportedOperationException_New()))
}


type Sql_Date struct{ Date }

const Sql_Date_serialVersionUID int64 = 1511598038487230103

func (t *Sql_Date) GetMonth__I() int32 { return t.Impl_GetMonth__I(t) }

func (t *Sql_Date) CompareTo_Date__I(p0 Date_I) int32 { return t.Impl_CompareTo_Date__I(t, p0) }

func (t *Sql_Date) GetDay__I() int32 { return t.Impl_GetDay__I(t) }

func (t *Sql_Date) After_Date__Z(p0 Date_I) bool { return t.Impl_After_Date__Z(t, p0) }

func (t *Sql_Date) GetYear__I() int32 { return t.Impl_GetYear__I(t) }

func (t *Sql_Date) GetDate__I() int32 { return t.Impl_GetDate__I(t) }

func (t *Sql_Date) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Sql_Date) ToGMTString__String() *String { return t.Impl_ToGMTString__String(t) }

func (t *Sql_Date) GetTime__J() int64 { return t.Impl_GetTime__J(t) }

func (t *Sql_Date) Before_Date__Z(p0 Date_I) bool { return t.Impl_Before_Date__Z(t, p0) }

func (t *Sql_Date) GetTimezoneOffset__I() int32 { return t.Impl_GetTimezoneOffset__I(t) }

func (t *Sql_Date) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Sql_Date) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Sql_Date) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Sql_Date) Ref() any { if t == nil { return nil }; return t }

func (t *Sql_Date) GetClass__Class() *Class { return Sql_Date_class }

func (t *Sql_Date) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func Sql_Date_InstanceOf(x any) bool { _, ok := x.(*Sql_Date); return ok }

func Sql_Date_Cast(x any) *Sql_Date { if x == nil { return nil }; v, ok := x.(*Sql_Date); if !ok { panic(ClassCast(x, Sql_Date_class)) }; return v }
