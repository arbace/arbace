//line com_sun_crypto_provider_JceServices.ae:1
package jrt






func JceServices_New() *JceServices { t := &JceServices{}; t.Ctor(); return t }
//line :8:1
func (t *JceServices) Ctor() { panic(A2g_NotTranslated("com.sun.crypto.provider.JceServices.<init>()V")) }

func JceServices_NewInstance_String__O(className *String) any {
	{ var tmp1 *String = className; var tmp2 int32 = -1; switch NN(tmp1).HashCode__I() { case -1697389403: if tmp1.Equals_O__Z(Lit_17) { tmp2 = 6 }; case -1697389308: if tmp1.Equals_O__Z(Lit_18) { tmp2 = 7 }; case -1590406197: if tmp1.Equals_O__Z(Lit_19) { tmp2 = 1 }; case 873144398: if tmp1.Equals_O__Z(Lit_20) { tmp2 = 2 }; case 873144493: if tmp1.Equals_O__Z(Lit_21) { tmp2 = 3 }; case 873145545: if tmp1.Equals_O__Z(Lit_22) { tmp2 = 4 }; case 873147248: if tmp1.Equals_O__Z(Lit_23) { tmp2 = 5 }; case 1334163992: if tmp1.Equals_O__Z(Lit_24) { tmp2 = 0 }; case 1575407554: if tmp1.Equals_O__Z(Lit_25) { tmp2 = 8 }; case 1575407649: if tmp1.Equals_O__Z(Lit_26) { tmp2 = 9 }; case 1575408701: if tmp1.Equals_O__Z(Lit_27) { tmp2 = 10 }; case 1575410404: if tmp1.Equals_O__Z(Lit_28) { tmp2 = 11 }}; switch tmp2 { case 0:
		return HmacMD5_New()
//line :11:1
	case 1:

		return HmacSHA1_New()
//line :11:1
	case 2:


		return HmacCore_HmacSHA224_New()
//line :11:1
	case 3:



		return HmacCore_HmacSHA256_New()
//line :11:1
	case 4:




		return HmacCore_HmacSHA384_New()
//line :11:1
	case 5:





		return HmacCore_HmacSHA512_New()
//line :11:1
	case 6:






		return HmacCore_HmacSHA512_224_New()
//line :11:1
	case 7:







		return HmacCore_HmacSHA512_256_New()
//line :11:1
	case 8:








		return HmacCore_HmacSHA3_224_New()
//line :11:1
	case 9:









		return HmacCore_HmacSHA3_256_New()
//line :11:1
	case 10:










		return HmacCore_HmacSHA3_384_New()
//line :11:1
	case 11:











		return HmacCore_HmacSHA3_512_New()
//line :11:1
	default: return nil} }
//line :10:1
	panic("a2g: unreachable")
}




type JceServices struct{ Object }

func (t *JceServices) Ref() any { if t == nil { return nil }; return t }

func (t *JceServices) GetClass__Class() *Class { return JceServices_class }

func (t *JceServices) ToString__String() *String { return Object_toString(t) }

func (t *JceServices) Clone__O() any { return A2g_ObjectClone(t) }

func (t *JceServices) CloneShallow() any { panic(CloneNotSupported(t)) }

func JceServices_InstanceOf(x any) bool { _, ok := x.(*JceServices); return ok }

func JceServices_Cast(x any) *JceServices { if x == nil { return nil }; v, ok := x.(*JceServices); if !ok { panic(ClassCast(x, JceServices_class)) }; return v }
