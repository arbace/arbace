//line atomic.ae:1
package jrt

import "sync/atomic"







// CompareAndSet sets v to x when it holds expect (Java's ==: Go's == on the two values as
// any, which compares pointers for Java objects) and reports whether it did. The CAS is on the
// box pointer; a failed CAS whose value is still expect (another store of an identical
// reference) retries, so the operation is linearizable as Java's.
func (v /*line :20:1*/*Volatile[T]) CompareAndSet(expect, x T) bool {
	for {
		p := v.p.Load()
		var cur any = nil
		if p != nil {
			cur = any(*p) }
		if cur != any(expect) {
			return false }
		var np *T = nil
		if any(x) != nil {
			np = &x }
		if v.p.CompareAndSwap(p, np) {
			return true } } }
// Swap stores x and returns the previous value (getAndSet).
func (v /*line :35:1*/*Volatile[T]) Swap(x T) T {
	var np *T = nil
	if any(x) != nil {
		np = &x }
	p := v.p.Swap(np)
	if p == nil {
		var z T
		return z
	}
	return *p
}
type volatileRef /*line :47:1*/ interface {
	loadAny() any
	storeAny(x any)
	casAny(expect, x any) bool
}
func (v *Volatile[T]) loadAny() any { return any(v.Load()) }
func (v *Volatile[T]) storeAny(x any) {
	var y T
	if x != nil {
		y = x.(T) }
	v.Store(y) }
func (v *Volatile[T]) casAny(expect, x any) bool {
	var e T
	var y T
	if expect != nil {
		ev, ok := expect.(T)
		if !ok {
			return false }
		e = ev }
	if x != nil {
		y = x.(T) }
	return v.CompareAndSet(e, y)
}



type AtomicInteger struct{ Number; v atomic.Int32 }

var AtomicInteger_class =
	Define(&ClassInfo{Name: "java.util.concurrent.atomic.AtomicInteger", Kind: KindClass, Modifiers: AccPublic, Super: Number_class,

		Interfaces: []*Class{Serializable_class}, Go: "arbace/jrt.AtomicInteger",
	},
	)
func AtomicInteger_New() *AtomicInteger { return &AtomicInteger{} }
func AtomicInteger_New_I(v int32) *AtomicInteger {
	a := &AtomicInteger{}; a.v.Store(v)
	return a }
func (a *AtomicInteger) Get__I() int32 { return a.v.Load() }
func (a *AtomicInteger) Set_I__V(x int32) { a.v.Store(x) }
func (a *AtomicInteger) LazySet_I__V(x int32) { a.v.Store(x) }
func (a *AtomicInteger) GetPlain__I() int32 { return a.v.Load() }
func (a *AtomicInteger) SetPlain_I__V(x int32) { a.v.Store(x) }
func (a *AtomicInteger) GetAcquire__I() int32 { return a.v.Load() }
func (a *AtomicInteger) SetRelease_I__V(x int32) { a.v.Store(x) }
func (a *AtomicInteger) GetAndSet_I__I(x int32) int32 { return a.v.Swap(x) }
func (a *AtomicInteger) CompareAndSet_I_I__Z(e, x int32) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicInteger) WeakCompareAndSetPlain_I_I__Z(e, x int32) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicInteger) WeakCompareAndSetVolatile_I_I__Z(e, x int32) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicInteger) CompareAndExchange_I_I__I(e, x int32) int32 {
	for {
		c := a.v.Load()
		if c != e || a.v.CompareAndSwap(c, x) {
			return c } } }
func (a *AtomicInteger) GetAndIncrement__I() int32 { return a.v.Add(1) - 1 }
func (a *AtomicInteger) GetAndDecrement__I() int32 { return a.v.Add(-1) + 1 }
func (a *AtomicInteger) GetAndAdd_I__I(d int32) int32 { return a.v.Add(d) - d }
func (a *AtomicInteger) IncrementAndGet__I() int32 { return a.v.Add(1) }
func (a *AtomicInteger) DecrementAndGet__I() int32 { return a.v.Add(-1) }
func (a *AtomicInteger) AddAndGet_I__I(d int32) int32 { return a.v.Add(d) }
func (a *AtomicInteger) IntValue__I() int32 { return a.v.Load() }
func (a *AtomicInteger) LongValue__J() int64 { return int64(a.v.Load()) }
func (a *AtomicInteger) FloatValue__F() float32 { return float32(a.v.Load()) }
func (a *AtomicInteger) DoubleValue__D() float64 { return float64(a.v.Load()) }
func (a *AtomicInteger) ByteValue__B() int8 { return int8(a.v.Load()) }
func (a *AtomicInteger) ShortValue__S() int16 { return int16(a.v.Load()) }
func (a *AtomicInteger) ToString__String() *String { return StrOfInt(a.v.Load()) }
func (a *AtomicInteger) Is_Serializable() {}
func (t *AtomicInteger) Ref() any { if t == nil { return nil }; return t }
func (t *AtomicInteger) GetClass__Class() *Class { return AtomicInteger_class }
func (t *AtomicInteger) Clone__O() any { panic(CloneNotSupported(t)) }

func (a *AtomicInteger) GetOpaque__I() int32 { return a.v.Load() }
func (a *AtomicInteger) SetOpaque_I__V(x int32) { a.v.Store(x) }
func (a *AtomicInteger) WeakCompareAndSet_I_I__Z(e, x int32) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicInteger) WeakCompareAndSetAcquire_I_I__Z(e, x int32) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicInteger) WeakCompareAndSetRelease_I_I__Z(e, x int32) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicInteger) CompareAndExchangeAcquire_I_I__I(e, x int32) int32 { return a.CompareAndExchange_I_I__I(e, x) }
func (a *AtomicInteger) CompareAndExchangeRelease_I_I__I(e, x int32) int32 { return a.CompareAndExchange_I_I__I(e, x) }
func AtomicInteger_InstanceOf(x any) bool { _, ok := x.(*AtomicInteger); return ok }
func AtomicInteger_Cast(x any) *AtomicInteger {
	if x == nil { return nil }
	v, ok := x.(*AtomicInteger)
	if !ok { panic(ClassCast(x, AtomicInteger_class))
	}
	return v
}


type AtomicLong struct{ Number; v atomic.Int64 }

var AtomicLong_class =
	Define(&ClassInfo{Name: "java.util.concurrent.atomic.AtomicLong", Kind: KindClass, Modifiers: AccPublic, Super: Number_class,

		Interfaces: []*Class{Serializable_class}, Go: "arbace/jrt.AtomicLong",
	},
	)
func AtomicLong_New() *AtomicLong { return &AtomicLong{} }
func AtomicLong_New_J(v int64) *AtomicLong {
	a := &AtomicLong{}; a.v.Store(v)
	return a }
func (a *AtomicLong) Get__J() int64 { return a.v.Load() }
func (a *AtomicLong) Set_J__V(x int64) { a.v.Store(x) }
func (a *AtomicLong) LazySet_J__V(x int64) { a.v.Store(x) }
func (a *AtomicLong) GetPlain__J() int64 { return a.v.Load() }
func (a *AtomicLong) SetPlain_J__V(x int64) { a.v.Store(x) }
func (a *AtomicLong) GetAcquire__J() int64 { return a.v.Load() }
func (a *AtomicLong) SetRelease_J__V(x int64) { a.v.Store(x) }
func (a *AtomicLong) GetAndSet_J__J(x int64) int64 { return a.v.Swap(x) }
func (a *AtomicLong) CompareAndSet_J_J__Z(e, x int64) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicLong) WeakCompareAndSetPlain_J_J__Z(e, x int64) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicLong) WeakCompareAndSetVolatile_J_J__Z(e, x int64) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicLong) GetAndIncrement__J() int64 { return a.v.Add(1) - 1 }
func (a *AtomicLong) GetAndDecrement__J() int64 { return a.v.Add(-1) + 1 }
func (a *AtomicLong) GetAndAdd_J__J(d int64) int64 { return a.v.Add(d) - d }
func (a *AtomicLong) IncrementAndGet__J() int64 { return a.v.Add(1) }
func (a *AtomicLong) DecrementAndGet__J() int64 { return a.v.Add(-1) }
func (a *AtomicLong) AddAndGet_J__J(d int64) int64 { return a.v.Add(d) }
func (a *AtomicLong) IntValue__I() int32 { return int32(a.v.Load()) }
func (a *AtomicLong) LongValue__J() int64 { return a.v.Load() }
func (a *AtomicLong) FloatValue__F() float32 { return float32(a.v.Load()) }
func (a *AtomicLong) DoubleValue__D() float64 { return float64(a.v.Load()) }
func (a *AtomicLong) ByteValue__B() int8 { return int8(a.v.Load()) }
func (a *AtomicLong) ShortValue__S() int16 { return int16(a.v.Load()) }
func (a *AtomicLong) ToString__String() *String { return StrOfLong(a.v.Load()) }
func (a *AtomicLong) Is_Serializable() {}
func (t *AtomicLong) Ref() any { if t == nil { return nil }; return t }
func (t *AtomicLong) GetClass__Class() *Class { return AtomicLong_class }
func (t *AtomicLong) Clone__O() any { panic(CloneNotSupported(t)) }

func (a *AtomicLong) GetOpaque__J() int64 { return a.v.Load() }
func (a *AtomicLong) SetOpaque_J__V(x int64) { a.v.Store(x) }
func (a *AtomicLong) WeakCompareAndSet_J_J__Z(e, x int64) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicLong) WeakCompareAndSetAcquire_J_J__Z(e, x int64) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicLong) WeakCompareAndSetRelease_J_J__Z(e, x int64) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicLong) CompareAndExchangeAcquire_J_J__J(e, x int64) int64 { return a.CompareAndExchange_J_J__J(e, x) }
func (a *AtomicLong) CompareAndExchangeRelease_J_J__J(e, x int64) int64 { return a.CompareAndExchange_J_J__J(e, x) }
func (a *AtomicLong) CompareAndExchange_J_J__J(e, x int64) int64 {
	for {
		c := a.v.Load()
		if c != e || a.v.CompareAndSwap(c, x) {
			return c } } }
func AtomicLong_InstanceOf(x any) bool { _, ok := x.(*AtomicLong); return ok }
func AtomicLong_Cast(x any) *AtomicLong {
	if x == nil { return nil }
	v, ok := x.(*AtomicLong)
	if !ok { panic(ClassCast(x, AtomicLong_class))
	}
	return v
}


type AtomicBoolean struct{ Object; v atomic.Bool }

var AtomicBoolean_class =
	Define(&ClassInfo{Name: "java.util.concurrent.atomic.AtomicBoolean", Kind: KindClass, Modifiers: AccPublic, Super: Object_class,

		Interfaces: []*Class{Serializable_class}, Go: "arbace/jrt.AtomicBoolean",
	},
	)
func AtomicBoolean_New() *AtomicBoolean { return &AtomicBoolean{} }
func AtomicBoolean_New_Z(v bool) *AtomicBoolean {
	a := &AtomicBoolean{}; a.v.Store(v)
	return a }
func (a *AtomicBoolean) Get__Z() bool { return a.v.Load() }
func (a *AtomicBoolean) Set_Z__V(x bool) { a.v.Store(x) }
func (a *AtomicBoolean) LazySet_Z__V(x bool) { a.v.Store(x) }
func (a *AtomicBoolean) GetAndSet_Z__Z(x bool) bool { return a.v.Swap(x) }
func (a *AtomicBoolean) CompareAndSet_Z_Z__Z(e, x bool) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicBoolean) WeakCompareAndSetVolatile_Z_Z__Z(e, x bool) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicBoolean) ToString__String() *String { return StrOfBool(a.v.Load()) }
func (a *AtomicBoolean) Is_Serializable() {}
func (t *AtomicBoolean) Ref() any { if t == nil { return nil }; return t }
func (t *AtomicBoolean) GetClass__Class() *Class { return AtomicBoolean_class }
func (t *AtomicBoolean) Clone__O() any { panic(CloneNotSupported(t)) }

func (a *AtomicBoolean) GetPlain__Z() bool { return a.v.Load() }
func (a *AtomicBoolean) GetOpaque__Z() bool { return a.v.Load() }
func (a *AtomicBoolean) GetAcquire__Z() bool { return a.v.Load() }
func (a *AtomicBoolean) SetPlain_Z__V(x bool) { a.v.Store(x) }
func (a *AtomicBoolean) SetOpaque_Z__V(x bool) { a.v.Store(x) }
func (a *AtomicBoolean) SetRelease_Z__V(x bool) { a.v.Store(x) }
func (a *AtomicBoolean) WeakCompareAndSet_Z_Z__Z(e, x bool) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicBoolean) WeakCompareAndSetPlain_Z_Z__Z(e, x bool) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicBoolean) WeakCompareAndSetAcquire_Z_Z__Z(e, x bool) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicBoolean) WeakCompareAndSetRelease_Z_Z__Z(e, x bool) bool { return a.v.CompareAndSwap(e, x) }
func (a *AtomicBoolean) CompareAndExchange_Z_Z__Z(e, x bool) bool {
	for {
		c := a.v.Load()
		if c != e || a.v.CompareAndSwap(c, x) {
			return c } } }
func (a *AtomicBoolean) CompareAndExchangeAcquire_Z_Z__Z(e, x bool) bool { return a.CompareAndExchange_Z_Z__Z(e, x) }
func (a *AtomicBoolean) CompareAndExchangeRelease_Z_Z__Z(e, x bool) bool { return a.CompareAndExchange_Z_Z__Z(e, x) }
func AtomicBoolean_InstanceOf(x any) bool { _, ok := x.(*AtomicBoolean); return ok }




type AtomicReference struct{ Object; v Volatile[any] }

var AtomicReference_class =
	Define(&ClassInfo{Name: "java.util.concurrent.atomic.AtomicReference", Kind: KindClass, Modifiers: AccPublic, Super: Object_class,

		Interfaces: []*Class{Serializable_class}, Go: "arbace/jrt.AtomicReference",
	},
	)
func AtomicReference_New() *AtomicReference { return &AtomicReference{} }
func AtomicReference_New_O(v any) *AtomicReference {
	a := &AtomicReference{}; a.v.Store(v)
	return a }
func (a *AtomicReference) Get__O() any { return a.v.Load() }
func (a *AtomicReference) Set_O__V(x any) { a.v.Store(x) }
func (a *AtomicReference) LazySet_O__V(x any) { a.v.Store(x) }
func (a *AtomicReference) GetPlain__O() any { return a.v.Load() }
func (a *AtomicReference) SetPlain_O__V(x any) { a.v.Store(x) }
func (a *AtomicReference) GetAcquire__O() any { return a.v.Load() }
func (a *AtomicReference) SetRelease_O__V(x any) { a.v.Store(x) }
func (a *AtomicReference) GetAndSet_O__O(x any) any { return a.v.Swap(x) }
func (a *AtomicReference) CompareAndSet_O_O__Z(e, x any) bool { return a.v.CompareAndSet(e, x) }
func (a *AtomicReference) WeakCompareAndSetPlain_O_O__Z(e, x any) bool { return a.v.CompareAndSet(e, x) }
func (a *AtomicReference) WeakCompareAndSetVolatile_O_O__Z(e, x any) bool { return a.v.CompareAndSet(e, x) }
func (a *AtomicReference) ToString__String() *String { return StrOfObj(a.v.Load()) }

func (a *AtomicReference) GetOpaque__O() any { return a.v.Load() }
func (a *AtomicReference) SetOpaque_O__V(x any) { a.v.Store(x) }
func (a *AtomicReference) WeakCompareAndSet_O_O__Z(e, x any) bool { return a.v.CompareAndSet(e, x) }
func (a *AtomicReference) WeakCompareAndSetAcquire_O_O__Z(e, x any) bool { return a.v.CompareAndSet(e, x) }
func (a *AtomicReference) WeakCompareAndSetRelease_O_O__Z(e, x any) bool { return a.v.CompareAndSet(e, x) }
// CompareAndExchange_O_O__O is compareAndExchange: the witness value.
//line :275:1
func (a /*line :276:1*/*AtomicReference) CompareAndExchange_O_O__O(e, x any) any {
	for {
		c := a.v.Load()
		if c != e {
			return c }
		if a.v.CompareAndSet(e, x) {
			return e } } }
func (a *AtomicReference) CompareAndExchangeAcquire_O_O__O(e, x any) any { return a.CompareAndExchange_O_O__O(e, x) }
func (a *AtomicReference) CompareAndExchangeRelease_O_O__O(e, x any) any { return a.CompareAndExchange_O_O__O(e, x) }
func (a *AtomicReference) Is_Serializable() {}
func (t *AtomicReference) Ref() any { if t == nil { return nil }; return t }
func (t *AtomicReference) GetClass__Class() *Class { return AtomicReference_class }
func (t *AtomicReference) Clone__O() any { panic(CloneNotSupported(t)) }
func AtomicReference_InstanceOf(x any) bool { _, ok := x.(*AtomicReference); return ok }
func AtomicReference_Cast(x any) *AtomicReference {
	if x == nil { return nil }
	v, ok := x.(*AtomicReference)
	if !ok { panic(ClassCast(x, AtomicReference_class))
	}
	return v }
func init() {
	AtomicInteger_class.Info().IsInstance = AtomicInteger_InstanceOf
	AtomicLong_class.Info().IsInstance = AtomicLong_InstanceOf
	AtomicBoolean_class.Info().IsInstance = AtomicBoolean_InstanceOf
	AtomicReference_class.Info().IsInstance = AtomicReference_InstanceOf
}
