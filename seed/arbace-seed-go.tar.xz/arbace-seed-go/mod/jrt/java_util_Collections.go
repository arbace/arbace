//line java_util_Collections.ae:1
package jrt
























func Collections_New() *Collections { Collections_Init(); t := &Collections{}; t.Ctor(); return t }
//line :26:1
func (t *Collections) Ctor() { panic(A2g_NotTranslated("java.util.Collections.<init>()V")) }

















func Collections_Sort_List__V(list List) { Collections_Init()
	list.Sort_Comparator__V(nil)
}
func Collections_Sort_List_Comparator__V(list List, c Comparator) { Collections_Init()

	list.Sort_Comparator__V(c)
}
func Collections_BinarySearch_List_O__I(list List, key any) int32 { Collections_Init()

	var tmp1 bool; var tmp2 bool; tmp2 = RandomAccess_InstanceOf(list); if !tmp2 { tmp2 = list.Size__I() < 5000 }; tmp1 = tmp2; if tmp1 {
		return Collections_IndexedBinarySearch_List_O__I(list, key) } else {
			return Collections_IteratorBinarySearch_List_O__I(list, key)
		} }
func Collections_IndexedBinarySearch_List_O__I(list List, key any) int32 { Collections_Init()

	var low int32 = 0; var high int32 = list.Size__I() - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal Comparable = Comparable_Cast(list.Get_I__O(mid)); var cmp int32 = midVal.CompareTo_O__I(key)


	if cmp < 0 {
		low = mid + 1 } else {
//line :65:1
			if cmp > 0 {

				high = mid - 1 } else {
					return mid } }
//line :61:1
	continue L1 }; break L1
}






	return -(low + 1)
}
func Collections_IteratorBinarySearch_List_O__I(list List, key any) int32 { Collections_Init()

	var low int32 = 0; var high int32 = list.Size__I() - 1; var i ListIterator = list.ListIterator__ListIterator()


L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal Comparable = Comparable_Cast(Collections_Get_ListIterator_I__O(i, mid)); var cmp int32 = midVal.CompareTo_O__I(key)


	if cmp < 0 {
		low = mid + 1 } else {
//line :80:1
			if cmp > 0 {

				high = mid - 1 } else {
					return mid } }
//line :76:1
	continue L1 }; break L1
}






	return -(low + 1)
}
func Collections_Get_ListIterator_I__O(i ListIterator, index int32) any { Collections_Init()

	var obj any; var pos int32 = i.NextIndex__I()

	if pos <= index {
	L1: for {
		obj = i.Next__O()
		var tmp1 int32; var old_1 int32 = pos; pos = pos + 1; tmp1 = old_1; if tmp1 < index { continue L1 }
//line :91:1
		break L1
	} } else {

	L2: for {
		obj = i.Previous__O()
		var tmp2 int32; pos = pos - 1; tmp2 = pos; if tmp2 > index { continue L2 }
//line :94:1
		break L2 } }
//line :88:1
	return obj
}









func Collections_BinarySearch_List_O_Comparator__I(list List, key any, c Comparator) int32 { Collections_Init()


	if c == nil {
		return Collections_BinarySearch_List_O__I(list, key) } else {
//line :102:1
			var tmp1 bool; var tmp2 bool

			tmp2 = RandomAccess_InstanceOf(list); if !tmp2 { tmp2 = list.Size__I() < 5000 }; tmp1 = tmp2
//line :102:1
			if tmp1 {


				return Collections_IndexedBinarySearch_List_O_Comparator__I(list, key, c) } else {
					return Collections_IteratorBinarySearch_List_O_Comparator__I(list, key, c)
				} } }
func Collections_IndexedBinarySearch_List_O_Comparator__I(l List, key any, c Comparator) int32 { Collections_Init()


	var low int32 = 0; var high int32 = l.Size__I() - 1

L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal any = l.Get_I__O(mid); var cmp int32 = c.Compare_O_O__I(midVal, key)


	if cmp < 0 {
		low = mid + 1 } else {
//line :117:1
			if cmp > 0 {

				high = mid - 1 } else {
					return mid } }
//line :113:1
	continue L1 }; break L1
}






	return -(low + 1)
}
func Collections_IteratorBinarySearch_List_O_Comparator__I(l List, key any, c Comparator) int32 { Collections_Init()


	var low int32 = 0; var high int32 = l.Size__I() - 1; var i ListIterator = l.ListIterator__ListIterator()


L1: for { if low <= high {
	var mid int32 = int32(uint32(low+high) >> 1); var midVal any = Collections_Get_ListIterator_I__O(i, mid); var cmp int32 = c.Compare_O_O__I(midVal, key)


	if cmp < 0 {
		low = mid + 1 } else {
//line :133:1
			if cmp > 0 {

				high = mid - 1 } else {
					return mid } }
//line :129:1
	continue L1 }; break L1
}






	return -(low + 1)
}
func Collections_Reverse_List__V(list List) { Collections_Init()
	var size int32 = list.Size__I(); var tmp1 bool; var tmp2 bool
	tmp2 = size < 18; if !tmp2 { tmp2 = RandomAccess_InstanceOf(list) }; tmp1 = tmp2; if tmp1 {
		var i int32 = 0; var mid int32 = size >> 1; var j int32 = size - 1; L1: for {


			if i < mid {
				Collections_Swap_List_I_I__V(list, i, j)
				i, mid, j = i+1, mid, j-1; continue L1 }
//line :142:1
			break L1
		}


	} else {

		var fwd ListIterator = list.ListIterator__ListIterator(); var rev ListIterator = list.ListIterator_I__ListIterator(size); var i_2 int32 = 0; var mid_2 int32 = list.Size__I() >> 1

	L2: for {

		if i_2 < mid_2 {
			var tmp any = fwd.Next__O()
			fwd.Set_O__V(rev.Previous__O())
			rev.Set_O__V(tmp)
			i_2, mid_2 = i_2+1, mid_2; continue L2 }
//line :150:1
		break L2
	}
	}
}




func Collections_Shuffle_List__V(list List) { Collections_Init()
	var rnd Random_I = Collections_r
	if rnd == nil { var tmp1 Random_I; rnd = Random_New(); tmp1 = rnd; Collections_r = tmp1 }
	Collections_Shuffle_List_Random__V(list, rnd)
}


func Collections_Shuffle_List_Random__V(list List, rnd Random_I) { Collections_Init()
	Collections_Shuffle_List_RandomGenerator__V(list, rnd)
}
func Collections_Shuffle_List_RandomGenerator__V(list List, rnd RandomGenerator) { Collections_Init()
	var size int32 = list.Size__I(); var tmp1 bool; var tmp2 bool
	tmp2 = size < 5; if !tmp2 { tmp2 = RandomAccess_InstanceOf(list) }; tmp1 = tmp2; if tmp1 {
		var i int32 = size; L1: for {
			if i > 1 {
				Collections_Swap_List_I_I__V(list, i-1, rnd.NextInt_I__I(i))
				i = i - 1; continue L1 }
//line :171:1
			break L1
		}
	} else {

		var arr *RefArray = list.ToArray__O1(); var i_2 int32 = size
	L2: for {
		if i_2 > 1 {
			Collections_Swap_O1_I_I__V(arr, i_2-1, rnd.NextInt_I__I(i_2))
			i_2 = i_2 - 1; continue L2 }
//line :176:1
		break L2
	}


		var it ListIterator = list.ListIterator__ListIterator(); var arr_101763 *RefArray = arr; var len_101764 int32 = int32(len(arr_101763.A)); var i_101765 int32 = 0; for ; i_101765 < len_101764; i_101765++ { var e any = arr_101763.A[i_101765]; it.Next__O(); it.Set_O__V(e)
		} } }
func Collections_Swap_List_I_I__V(list List, i, j int32) { Collections_Init()
	var l List = list; l.Set_I_O__O(i, l.Set_I_O__O(j, l.Get_I__O(i)))
}
func Collections_Swap_O1_I_I__V(arr *RefArray, i, j int32) { Collections_Init()
	var tmp any = arr.A[i]; arr.Store(i, arr.A[j]); arr.Store(j, tmp)
}
func Collections_Fill_List_O__V(list List, obj any) { Collections_Init()
	var size int32 = list.Size__I(); var tmp1 bool; var tmp2 bool
	tmp2 = size < 25; if !tmp2 { tmp2 = RandomAccess_InstanceOf(list) }; tmp1 = tmp2; if tmp1 {
		var i int32 = 0; L1: for { if i < size { list.Set_I_O__O(i, obj); i = i + 1; continue L1 }; break L1 } } else {
			var itr ListIterator = list.ListIterator__ListIterator(); var i_2 int32 = 0
		L2: for {
			if i_2 < size { itr.Next__O(); itr.Set_O__V(obj); i_2 = i_2 + 1; continue L2 }
//line :193:1
			break L2
		}
		} }
func Collections_Copy_List_List__V(dest, src List) { Collections_Init()

	var srcSize int32 = src.Size__I()
	if srcSize > dest.Size__I() {
		panic(Thrown(IndexOutOfBoundsException_New_String(Lit_2632))) }
	var tmp1 bool; var tmp2 bool; tmp2 = srcSize < 10; if !tmp2 {
		var tmp3 bool; tmp3 = RandomAccess_InstanceOf(src); if tmp3 { tmp3 = RandomAccess_InstanceOf(dest) }; tmp2 = tmp3 }
//line :201:1
	tmp1 = tmp2; if tmp1 {

		var i int32 = 0; L1: for {
			if i < srcSize { dest.Set_I_O__O(i, src.Get_I__O(i)); i = i + 1; continue L1 }
//line :203:1
			break L1 } } else {

				var di ListIterator = dest.ListIterator__ListIterator(); var si ListIterator = src.ListIterator__ListIterator()
				var i_2 int32 = 0
			L2: for {
				if i_2 < srcSize { di.Next__O(); di.Set_O__V(si.Next__O()); i_2 = i_2 + 1; continue L2 }
//line :207:1
				break L2
			}
			} }
func Collections_Min_Collection__O(coll Collection) any { Collections_Init()
	var i Iterator = coll.Iterator__Iterator(); var candidate any = i.Next__O()

L1: for { if i.HasNext__Z() {
	var next any = i.Next__O()
	if Comparable_Cast(next).CompareTo_O__I(candidate) < 0 { candidate = next }
//line :213:1
	continue L1 }; break L1 }
//line :211:1
	return candidate
}





func Collections_Min_Collection_Comparator__O(coll Collection, comp Comparator) any { Collections_Init()

	if comp == nil {
		return Collections_Min_Collection__O(coll) } else {
			var i Iterator = coll.Iterator__Iterator(); var candidate any = i.Next__O()

		L1: for { if i.HasNext__Z() {
			var next any = i.Next__O()
			if comp.Compare_O_O__I(next, candidate) < 0 { candidate = next }
//line :224:1
			continue L1 }; break L1 }
//line :222:1
			return candidate
		}
}




func Collections_Max_Collection__O(coll Collection) any { Collections_Init()
	var i Iterator = coll.Iterator__Iterator(); var candidate any = i.Next__O()

L1: for { if i.HasNext__Z() {
	var next any = i.Next__O()
	if Comparable_Cast(next).CompareTo_O__I(candidate) > 0 { candidate = next }
//line :232:1
	continue L1 }; break L1 }
//line :230:1
	return candidate
}





func Collections_Max_Collection_Comparator__O(coll Collection, comp Comparator) any { Collections_Init()

	if comp == nil {
		return Collections_Max_Collection__O(coll) } else {
			var i Iterator = coll.Iterator__Iterator(); var candidate any = i.Next__O()

		L1: for { if i.HasNext__Z() {
			var next any = i.Next__O()
			if comp.Compare_O_O__I(next, candidate) > 0 { candidate = next }
//line :243:1
			continue L1 }; break L1 }
//line :241:1
			return candidate
		}
}




func Collections_Rotate_List_I__V(list List, distance int32) { Collections_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = RandomAccess_InstanceOf(list); if !tmp2 { tmp2 = list.Size__I() < 100 }; tmp1 = tmp2; if tmp1 {
		Collections_Rotate1_List_I__V(list, distance) } else {
			Collections_Rotate2_List_I__V(list, distance)
		} }
func Collections_Rotate1_List_I__V(list List, distance int32) { Collections_Init()

	var size int32 = list.Size__I()
	if size == 0 { } else {
		distance = distance % size
		if distance < 0 { distance = distance + size }
		if distance == 0 { } else {
			var bound int32 = size - distance
			var cycleStart int32 = 0
			var nMoved int32 = 0
		L1: for { if nMoved < size {
			var displaced any = list.Get_I__O(cycleStart)
			var i int32 = cycleStart
		L2: for {
			if i >= bound { i = i - size }
			i = i + distance
			displaced = list.Set_I_O__O(i, displaced)
			nMoved = nMoved + 1
			if i == cycleStart { } else { continue L2 }
//line :266:1
			break L2
		}




			cycleStart = cycleStart + 1
//line :263:1
			continue L1 }; break L1
		}
		}
	}
}






func Collections_Rotate2_List_I__V(list List, distance int32) { Collections_Init()
	var size int32 = list.Size__I()
	if size == 0 { } else {
		var mid int32 = -distance % size
		if mid < 0 { mid = mid + size }
		if mid == 0 { } else {
			Collections_Reverse_List__V(list.SubList_I_I__List(0, mid))
			Collections_Reverse_List__V(list.SubList_I_I__List(mid, size))
			Collections_Reverse_List__V(list)
		} } }
func Collections_ReplaceAll_List_O_O__Z(list List, oldVal, newVal any) bool { Collections_Init()

	var result bool = false; var size int32 = list.Size__I(); var tmp1 bool; var tmp2 bool

	tmp2 = size < 11; if !tmp2 { tmp2 = RandomAccess_InstanceOf(list) }; tmp1 = tmp2; if tmp1 {
		if oldVal == nil {
			var i int32 = 0; L1: for {
				if i < size {
					if list.Get_I__O(i) == nil {
						list.Set_I_O__O(i, newVal); result = true; i = i + 1; continue L1 } else {
							i = i + 1; continue L1 } }
//line :290:1
				break L1
			}

		} else {


			var i_2 int32 = 0; L2: for {
				if i_2 < size {
					if Equals(oldVal, list.Get_I__O(i_2)) {
						list.Set_I_O__O(i_2, newVal); result = true; i_2 = i_2 + 1; continue L2 } else {
							i_2 = i_2 + 1; continue L2 } }
//line :296:1
				break L2
			}
		}
	} else {


		var itr ListIterator = list.ListIterator__ListIterator()
		if oldVal == nil {
			var i_3 int32 = 0; L3: for {
				if i_3 < size {
					if itr.Next__O() == nil {
						itr.Set_O__V(newVal); result = true; i_3 = i_3 + 1; continue L3 } else {
							i_3 = i_3 + 1; continue L3 } }
//line :304:1
				break L3
			}

		} else {


			var i_4 int32 = 0; L4: for {
				if i_4 < size {
					if Equals(oldVal, itr.Next__O()) {
						itr.Set_O__V(newVal); result = true; i_4 = i_4 + 1; continue L4 } else {
							i_4 = i_4 + 1; continue L4 } }
//line :310:1
				break L4 } } }
//line :286:1
	return result
}






























func Collections_IndexOfSubList_List_List__I(source, target List) int32 { Collections_Init()
	var sourceSize int32 = source.Size__I(); var targetSize int32 = target.Size__I(); var maxCandidate int32 = sourceSize - targetSize; var tmp1 bool; var tmp2 bool


	tmp2 = sourceSize < 35; if !tmp2 {
		var tmp3 bool; tmp3 = RandomAccess_InstanceOf(source); if tmp3 { tmp3 = RandomAccess_InstanceOf(target) }; tmp2 = tmp3 }
//line :322:1
	tmp1 = tmp2; if tmp1 {

		var candidate int32 = 0; L2: for {

			if candidate <= maxCandidate {
				var i int32 = 0; var j int32 = candidate; L3: for {

					if i < targetSize {
						if !Collections_Eq_O_O__Z(target.Get_I__O(i), source.Get_I__O(j)) {
							candidate = candidate + 1; continue L2 } else {
								i, j = i+1, j+1; continue L3 } }
//line :327:1
					break L3
				}





				return candidate }
//line :324:1
			break L2 } } else {










				var si ListIterator = source.ListIterator__ListIterator()
				var candidate_2 int32 = 0; L5: for {

					if candidate_2 <= maxCandidate {
						var ti ListIterator = target.ListIterator__ListIterator(); var i_2 int32 = 0
					L6: for {
						if i_2 < targetSize {
							if !Collections_Eq_O_O__Z(ti.Next__O(), si.Next__O()) {

								var j_2 int32 = 0; L7: for {
									if j_2 < i_2 { si.Previous__O(); j_2 = j_2 + 1; continue L7 }
//line :344:1
									break L7
								}
								candidate_2 = candidate_2 + 1; continue L5 } else {
									i_2 = i_2 + 1; continue L6 } }
//line :340:1
						break L6
					}







						return candidate_2 }
//line :336:1
					break L5 } }
//line :319:1
	return -1
}































func Collections_LastIndexOfSubList_List_List__I(source, target List) int32 { Collections_Init()
	var sourceSize int32 = source.Size__I(); var targetSize int32 = target.Size__I(); var maxCandidate int32 = sourceSize - targetSize; var tmp1 bool; var tmp2 bool


	tmp2 = sourceSize < 35; if !tmp2 { tmp2 = RandomAccess_InstanceOf(source) }; tmp1 = tmp2; if tmp1 {
		var candidate int32 = maxCandidate; L2: for {

			if candidate >= 0 {
				var i int32 = 0; var j int32 = candidate; L3: for {

					if i < targetSize {
						if !Collections_Eq_O_O__Z(target.Get_I__O(i), source.Get_I__O(j)) {
							candidate = candidate - 1; continue L2 } else {
								i, j = i+1, j+1; continue L3 } }
//line :360:1
					break L3
				}





				return candidate }
//line :357:1
			break L2
		}







	} else {


		if maxCandidate < 0 { return -1 }
		var si ListIterator = source.ListIterator_I__ListIterator(maxCandidate)
		var candidate_2 int32 = maxCandidate; L5: for {

			if candidate_2 >= 0 {
				var ti ListIterator = target.ListIterator__ListIterator(); var i_2 int32 = 0
			L6: for {
				if i_2 < targetSize {
					if !Collections_Eq_O_O__Z(ti.Next__O(), si.Next__O()) {

						if candidate_2 == 0 { } else {
							var j_2 int32 = 0; L7: for {
								if j_2 <= i_2+1 {
									si.Previous__O()
									j_2 = j_2 + 1; continue L7 }
//line :380:1
								break L7
							}
						}

						candidate_2 = candidate_2 - 1; continue L5 } else {
							i_2 = i_2 + 1; continue L6 } }
//line :375:1
				break L6
			}










				return candidate_2 }
//line :371:1
			break L5 } }
//line :353:1
	return -1
}



































func Collections_UnmodifiableCollection_Collection__Collection(c Collection) Collection { Collections_Init()
	if c.GetClass__Class() == Collections_UnmodifiableCollection_class { return c } else { return Collections_UnmodifiableCollection_New_Collection(c)
	}
}







func Collections_UnmodifiableCollection_New_Collection(p0 Collection) *Collections_UnmodifiableCollection { t := &Collections_UnmodifiableCollection{}; t.Ctor_Collection(t, p0); return t }
//line :401:1
func (t *Collections_UnmodifiableCollection) Ctor_Collection(this Collections_UnmodifiableCollection_I, c Collection) {
	if c == nil { panic(Thrown(NullPointerException_New())) }
	t.F_c = c
}
func (t *Collections_UnmodifiableCollection) Impl_Size__I(this Collections_UnmodifiableCollection_I) int32 { return t.F_c.Size__I() }

func (t *Collections_UnmodifiableCollection) Impl_IsEmpty__Z(this Collections_UnmodifiableCollection_I) bool { return t.F_c.IsEmpty__Z() }

func (t *Collections_UnmodifiableCollection) Impl_Contains_O__Z(this Collections_UnmodifiableCollection_I, o any) bool { return t.F_c.Contains_O__Z(o) }

func (t *Collections_UnmodifiableCollection) Impl_ToArray__O1(this Collections_UnmodifiableCollection_I) *RefArray { return t.F_c.ToArray__O1() }

func (t *Collections_UnmodifiableCollection) Impl_ToArray_O1__O1(this Collections_UnmodifiableCollection_I, a *RefArray) *RefArray {
	return t.F_c.ToArray_O1__O1(a)
}
func (t *Collections_UnmodifiableCollection) Impl_ToArray_IntFunction__O1(this Collections_UnmodifiableCollection_I, f IntFunction) *RefArray {
	return t.F_c.ToArray_IntFunction__O1(f)
}
func (t *Collections_UnmodifiableCollection) Impl_ToString__String(this Collections_UnmodifiableCollection_I) *String { return t.F_c.ToString__String() }

func (t *Collections_UnmodifiableCollection) Impl_Iterator__Iterator(this Collections_UnmodifiableCollection_I) Iterator {
	return Collections_UnmodifiableCollection_1_New_Collections_UnmodifiableCollection(this)
}

func (t *Collections_UnmodifiableCollection_1) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *Collections_UnmodifiableCollection_1) Next__O() any { return t.F_i.Next__O() }

func (t *Collections_UnmodifiableCollection_1) Remove__V() {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection_1) ForEachRemaining_Consumer__V(action Consumer) {
	t.F_i.ForEachRemaining_Consumer__V(action)
}
func (t *Collections_UnmodifiableCollection) Impl_Add_O__Z(this Collections_UnmodifiableCollection_I, e any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection) Impl_Remove_O__Z(this Collections_UnmodifiableCollection_I, o any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection) Impl_ContainsAll_Collection__Z(this Collections_UnmodifiableCollection_I, coll Collection) bool {
	return t.F_c.ContainsAll_Collection__Z(coll)
}
func (t *Collections_UnmodifiableCollection) Impl_AddAll_Collection__Z(this Collections_UnmodifiableCollection_I, coll Collection) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection) Impl_RemoveAll_Collection__Z(this Collections_UnmodifiableCollection_I, coll Collection) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection) Impl_RetainAll_Collection__Z(this Collections_UnmodifiableCollection_I, coll Collection) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection) Impl_Clear__V(this Collections_UnmodifiableCollection_I) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection) Impl_ForEach_Consumer__V(this Collections_UnmodifiableCollection_I, action Consumer) {
	t.F_c.ForEach_Consumer__V(action)
}
func (t *Collections_UnmodifiableCollection) Impl_RemoveIf_Predicate__Z(this Collections_UnmodifiableCollection_I, filter Predicate) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableCollection) Impl_Spliterator__Spliterator(this Collections_UnmodifiableCollection_I) Spliterator {
	return t.F_c.Spliterator__Spliterator()
}
func (t *Collections_UnmodifiableCollection) Impl_Stream__Stream(this Collections_UnmodifiableCollection_I) Stream { return t.F_c.Stream__Stream() }

func (t *Collections_UnmodifiableCollection) Impl_ParallelStream__Stream(this Collections_UnmodifiableCollection_I) Stream {
	return t.F_c.ParallelStream__Stream()
}
func Collections_UnmodifiableSequencedCollection_SequencedCollection__SequencedCollection(c SequencedCollection) SequencedCollection { Collections_Init()
	if c.GetClass__Class() == Collections_UnmodifiableSequencedCollection_class { return c } else {

		return Collections_UnmodifiableSequencedCollection_New_SequencedCollection(c)
	}
}






func Collections_UnmodifiableSequencedCollection_New_SequencedCollection(p0 SequencedCollection) *Collections_UnmodifiableSequencedCollection { t := &Collections_UnmodifiableSequencedCollection{}; t.Ctor_SequencedCollection(t, p0); return t }
//line :482:1
func (t *Collections_UnmodifiableSequencedCollection) Ctor_SequencedCollection(this Collections_UnmodifiableSequencedCollection_I, c SequencedCollection) { t.Collections_UnmodifiableCollection.Ctor_Collection(this, c) }


func (t *Collections_UnmodifiableSequencedCollection) Impl_Sc__SequencedCollection(this Collections_UnmodifiableSequencedCollection_I) SequencedCollection {
	return SequencedCollection_Cast(t.F_c)
}
func (t *Collections_UnmodifiableSequencedCollection) Impl_Reversed__SequencedCollection(this Collections_UnmodifiableSequencedCollection_I) SequencedCollection {
	return Collections_UnmodifiableSequencedCollection_New_SequencedCollection(t.Impl_Sc__SequencedCollection(this).Reversed__SequencedCollection())
}
func (t *Collections_UnmodifiableSequencedCollection) Impl_AddFirst_O__V(this Collections_UnmodifiableSequencedCollection_I, e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableSequencedCollection) Impl_AddLast_O__V(this Collections_UnmodifiableSequencedCollection_I, e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableSequencedCollection) Impl_GetFirst__O(this Collections_UnmodifiableSequencedCollection_I) any { return t.Impl_Sc__SequencedCollection(this).GetFirst__O() }

func (t *Collections_UnmodifiableSequencedCollection) Impl_GetLast__O(this Collections_UnmodifiableSequencedCollection_I) any { return t.Impl_Sc__SequencedCollection(this).GetLast__O() }

func (t *Collections_UnmodifiableSequencedCollection) Impl_RemoveFirst__O(this Collections_UnmodifiableSequencedCollection_I) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableSequencedCollection) Impl_RemoveLast__O(this Collections_UnmodifiableSequencedCollection_I) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func Collections_UnmodifiableSet_Set__Set(s Set) Set { Collections_Init()
	if s.GetClass__Class() == Collections_UnmodifiableSet_class { return s } else { return Collections_UnmodifiableSet_New_Set(s)
	}
}






func Collections_UnmodifiableSet_New_Set(p0 Set) *Collections_UnmodifiableSet { t := &Collections_UnmodifiableSet{}; t.Ctor_Set(t, p0); return t }
//line :517:1
func (t *Collections_UnmodifiableSet) Ctor_Set(this Collections_UnmodifiableSet_I, s Set) { t.Collections_UnmodifiableCollection.Ctor_Collection(this, s) }

func (t *Collections_UnmodifiableSet) Impl_Equals_O__Z(this Collections_UnmodifiableSet_I, o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(this); if !tmp1 { tmp1 = t.F_c.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_UnmodifiableSet) Impl_HashCode__I(this Collections_UnmodifiableSet_I) int32 { return t.F_c.HashCode__I() }

func Collections_UnmodifiableSequencedSet_SequencedSet__SequencedSet(s SequencedSet) SequencedSet { Collections_Init()
	if s.GetClass__Class() == Collections_UnmodifiableSequencedSet_class { return s } else { return Collections_UnmodifiableSequencedSet_New_SequencedSet(s)
	}
}






func Collections_UnmodifiableSequencedSet_New_SequencedSet(p0 SequencedSet) *Collections_UnmodifiableSequencedSet { t := &Collections_UnmodifiableSequencedSet{}; t.Ctor_SequencedSet(p0); return t }
//line :534:1
func (t *Collections_UnmodifiableSequencedSet) Ctor_SequencedSet(s SequencedSet) { t.Collections_UnmodifiableSequencedCollection.Ctor_SequencedCollection(t, s) }

func (t *Collections_UnmodifiableSequencedSet) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(t); if !tmp1 { tmp1 = t.F_c.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_UnmodifiableSequencedSet) HashCode__I() int32 { return t.F_c.HashCode__I() }

func (t *Collections_UnmodifiableSequencedSet) Ss__SequencedSet() SequencedSet {
	return SequencedSet_Cast(t.F_c)
}
func (t *Collections_UnmodifiableSequencedSet) Reversed__SequencedSet() SequencedSet {
	return Collections_UnmodifiableSequencedSet_New_SequencedSet(t.Ss__SequencedSet().Reversed__SequencedSet())
}
func Collections_UnmodifiableSortedSet_SortedSet__SortedSet(s SortedSet) SortedSet { Collections_Init()
	if s.GetClass__Class() == Collections_UnmodifiableSortedSet_class { return s } else { return Collections_UnmodifiableSortedSet_New_SortedSet(s)
	}
}








func Collections_UnmodifiableSortedSet_New_SortedSet(p0 SortedSet) *Collections_UnmodifiableSortedSet { t := &Collections_UnmodifiableSortedSet{}; t.Ctor_SortedSet(t, p0); return t }
//line :559:1
func (t *Collections_UnmodifiableSortedSet) Ctor_SortedSet(this Collections_UnmodifiableSortedSet_I, s SortedSet) { t.Collections_UnmodifiableSet.Ctor_Set(this, s); t.F_ss = s }

func (t *Collections_UnmodifiableSortedSet) Impl_Comparator__Comparator(this Collections_UnmodifiableSortedSet_I) Comparator {
	return t.F_ss.Comparator__Comparator()
}
func (t *Collections_UnmodifiableSortedSet) Impl_SubSet_O_O__SortedSet(this Collections_UnmodifiableSortedSet_I, fromElement, toElement any) SortedSet {
	return Collections_UnmodifiableSortedSet_New_SortedSet(t.F_ss.SubSet_O_O__SortedSet(fromElement, toElement))
}
func (t *Collections_UnmodifiableSortedSet) Impl_HeadSet_O__SortedSet(this Collections_UnmodifiableSortedSet_I, toElement any) SortedSet {
	return Collections_UnmodifiableSortedSet_New_SortedSet(t.F_ss.HeadSet_O__SortedSet(toElement))
}
func (t *Collections_UnmodifiableSortedSet) Impl_TailSet_O__SortedSet(this Collections_UnmodifiableSortedSet_I, fromElement any) SortedSet {
	return Collections_UnmodifiableSortedSet_New_SortedSet(t.F_ss.TailSet_O__SortedSet(fromElement))
}
func (t *Collections_UnmodifiableSortedSet) Impl_First__O(this Collections_UnmodifiableSortedSet_I) any { return t.F_ss.First__O() }

func (t *Collections_UnmodifiableSortedSet) Impl_Last__O(this Collections_UnmodifiableSortedSet_I) any { return t.F_ss.Last__O() }

func Collections_UnmodifiableNavigableSet_NavigableSet__NavigableSet(s NavigableSet) NavigableSet { Collections_Init()
	if s.GetClass__Class() == Collections_UnmodifiableNavigableSet_class { return s } else { return Collections_UnmodifiableNavigableSet_New_NavigableSet(s)
	}
}













func Collections_UnmodifiableNavigableSet_EmptyNavigableSet_New() *Collections_UnmodifiableNavigableSet_EmptyNavigableSet { Collections_UnmodifiableNavigableSet_EmptyNavigableSet_Init(); t := &Collections_UnmodifiableNavigableSet_EmptyNavigableSet{}; t.Ctor(); return t }
//line :594:1
func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Ctor() { t.Collections_UnmodifiableNavigableSet.Ctor_NavigableSet(t, TreeSet_New()) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Collections$UnmodifiableNavigableSet$EmptyNavigableSet.readResolve()Ljava/lang/Object;")) }






func Collections_UnmodifiableNavigableSet_New_NavigableSet(p0 NavigableSet) *Collections_UnmodifiableNavigableSet { Collections_UnmodifiableNavigableSet_Init(); t := &Collections_UnmodifiableNavigableSet{}; t.Ctor_NavigableSet(t, p0); return t }
//line :603:1
func (t *Collections_UnmodifiableNavigableSet) Ctor_NavigableSet(this Collections_UnmodifiableNavigableSet_I, s NavigableSet) { t.Collections_UnmodifiableSortedSet.Ctor_SortedSet(this, s); t.F_ns = s }

func (t *Collections_UnmodifiableNavigableSet) Impl_Lower_O__O(this Collections_UnmodifiableNavigableSet_I, e any) any { return t.F_ns.Lower_O__O(e) }

func (t *Collections_UnmodifiableNavigableSet) Impl_Floor_O__O(this Collections_UnmodifiableNavigableSet_I, e any) any { return t.F_ns.Floor_O__O(e) }

func (t *Collections_UnmodifiableNavigableSet) Impl_Ceiling_O__O(this Collections_UnmodifiableNavigableSet_I, e any) any { return t.F_ns.Ceiling_O__O(e) }

func (t *Collections_UnmodifiableNavigableSet) Impl_Higher_O__O(this Collections_UnmodifiableNavigableSet_I, e any) any { return t.F_ns.Higher_O__O(e) }

func (t *Collections_UnmodifiableNavigableSet) Impl_PollFirst__O(this Collections_UnmodifiableNavigableSet_I) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableNavigableSet) Impl_PollLast__O(this Collections_UnmodifiableNavigableSet_I) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableNavigableSet) Impl_DescendingSet__NavigableSet(this Collections_UnmodifiableNavigableSet_I) NavigableSet {
	return Collections_UnmodifiableNavigableSet_New_NavigableSet(t.F_ns.DescendingSet__NavigableSet())
}
func (t *Collections_UnmodifiableNavigableSet) Impl_DescendingIterator__Iterator(this Collections_UnmodifiableNavigableSet_I) Iterator {
	return this.DescendingSet__NavigableSet().Iterator__Iterator()
}
func (t *Collections_UnmodifiableNavigableSet) Impl_SubSet_O_Z_O_Z__NavigableSet(this Collections_UnmodifiableNavigableSet_I, fromElement any, fromInclusive bool, toElement any, toInclusive bool) NavigableSet {

	return Collections_UnmodifiableNavigableSet_New_NavigableSet(t.F_ns.SubSet_O_Z_O_Z__NavigableSet(fromElement, fromInclusive, toElement, toInclusive))
}
func (t *Collections_UnmodifiableNavigableSet) Impl_HeadSet_O_Z__NavigableSet(this Collections_UnmodifiableNavigableSet_I, toElement any, inclusive bool) NavigableSet {
	return Collections_UnmodifiableNavigableSet_New_NavigableSet(t.F_ns.HeadSet_O_Z__NavigableSet(toElement, inclusive))
}
func (t *Collections_UnmodifiableNavigableSet) Impl_TailSet_O_Z__NavigableSet(this Collections_UnmodifiableNavigableSet_I, fromElement any, inclusive bool) NavigableSet {
	return Collections_UnmodifiableNavigableSet_New_NavigableSet(t.F_ns.TailSet_O_Z__NavigableSet(fromElement, inclusive))
}
func Collections_UnmodifiableList_List__List(list List) List { Collections_Init()
	var tmp1 bool; var tmp2 bool
	tmp2 = list.GetClass__Class() == Collections_UnmodifiableList_class; if !tmp2 {
		tmp2 = list.GetClass__Class() == Collections_UnmodifiableRandomAccessList_class }
//line :637:1
	tmp1 = tmp2
//line :636:1
	if tmp1 { return list } else { if RandomAccess_InstanceOf(list) {



		return Collections_UnmodifiableRandomAccessList_New_List(list) } else {
			return Collections_UnmodifiableList_New_List(list)
		}
	}
}







func Collections_UnmodifiableList_New_List(p0 List) *Collections_UnmodifiableList { t := &Collections_UnmodifiableList{}; t.Ctor_List(t, p0); return t }
//line :652:1
func (t *Collections_UnmodifiableList) Ctor_List(this Collections_UnmodifiableList_I, list List) { t.Collections_UnmodifiableCollection.Ctor_Collection(this, list)

	t.F_list = list
}
func (t *Collections_UnmodifiableList) Impl_Equals_O__Z(this Collections_UnmodifiableList_I, o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(this); if !tmp1 { tmp1 = t.F_list.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_UnmodifiableList) Impl_HashCode__I(this Collections_UnmodifiableList_I) int32 { return t.F_list.HashCode__I() }

func (t *Collections_UnmodifiableList) Impl_Get_I__O(this Collections_UnmodifiableList_I, index int32) any { return t.F_list.Get_I__O(index) }

func (t *Collections_UnmodifiableList) Impl_Set_I_O__O(this Collections_UnmodifiableList_I, index int32, element any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList) Impl_Add_I_O__V(this Collections_UnmodifiableList_I, index int32, element any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList) Impl_Remove_I__O(this Collections_UnmodifiableList_I, index int32) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList) Impl_IndexOf_O__I(this Collections_UnmodifiableList_I, o any) int32 { return t.F_list.IndexOf_O__I(o) }

func (t *Collections_UnmodifiableList) Impl_LastIndexOf_O__I(this Collections_UnmodifiableList_I, o any) int32 { return t.F_list.LastIndexOf_O__I(o) }

func (t *Collections_UnmodifiableList) Impl_AddAll_I_Collection__Z(this Collections_UnmodifiableList_I, index int32, c Collection) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList) Impl_ReplaceAll_UnaryOperator__V(this Collections_UnmodifiableList_I, operator UnaryOperator) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList) Impl_Sort_Comparator__V(this Collections_UnmodifiableList_I, c Comparator) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList) Impl_ListIterator__ListIterator(this Collections_UnmodifiableList_I) ListIterator {
	return this.ListIterator_I__ListIterator(0)
}
func (t *Collections_UnmodifiableList) Impl_ListIterator_I__ListIterator(this Collections_UnmodifiableList_I, index int32) ListIterator {
	return Collections_UnmodifiableList_1_New_Collections_UnmodifiableList_I(this, index)
}

func (t *Collections_UnmodifiableList_1) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *Collections_UnmodifiableList_1) Next__O() any { return t.F_i.Next__O() }

func (t *Collections_UnmodifiableList_1) HasPrevious__Z() bool { return t.F_i.HasPrevious__Z() }

func (t *Collections_UnmodifiableList_1) Previous__O() any { return t.F_i.Previous__O() }

func (t *Collections_UnmodifiableList_1) NextIndex__I() int32 { return t.F_i.NextIndex__I() }

func (t *Collections_UnmodifiableList_1) PreviousIndex__I() int32 { return t.F_i.PreviousIndex__I() }

func (t *Collections_UnmodifiableList_1) Remove__V() {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList_1) Set_O__V(e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList_1) Add_O__V(e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableList_1) ForEachRemaining_Consumer__V(action Consumer) {
	t.F_i.ForEachRemaining_Consumer__V(action)
}
func (t *Collections_UnmodifiableList) Impl_SubList_I_I__List(this Collections_UnmodifiableList_I, fromIndex, toIndex int32) List {
	return Collections_UnmodifiableList_New_List(t.F_list.SubList_I_I__List(fromIndex, toIndex))
}
func (t *Collections_UnmodifiableList) Impl_ReadResolve__O(this Collections_UnmodifiableList_I) any { panic(A2g_NotTranslated("java.util.Collections$UnmodifiableList.readResolve()Ljava/lang/Object;")) }







func Collections_UnmodifiableRandomAccessList_New_List(p0 List) *Collections_UnmodifiableRandomAccessList { t := &Collections_UnmodifiableRandomAccessList{}; t.Ctor_List(p0); return t }
//line :727:1
func (t *Collections_UnmodifiableRandomAccessList) Ctor_List(list List) { t.Collections_UnmodifiableList.Ctor_List(t, list) }

func (t *Collections_UnmodifiableRandomAccessList) SubList_I_I__List(fromIndex, toIndex int32) List {
	return Collections_UnmodifiableRandomAccessList_New_List(t.F_list.SubList_I_I__List(fromIndex, toIndex))
}


func (t *Collections_UnmodifiableRandomAccessList) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.Collections$UnmodifiableRandomAccessList.writeReplace()Ljava/lang/Object;")) }

func Collections_UnmodifiableMap_Map__Map(m Map) Map { Collections_Init()
	if m.GetClass__Class() == Collections_UnmodifiableMap_class { return m } else { return Collections_UnmodifiableMap_New_Map(m)
	}
}







func Collections_UnmodifiableMap_New_Map(p0 Map) *Collections_UnmodifiableMap { t := &Collections_UnmodifiableMap{}; t.Ctor_Map(t, p0); return t }
//line :747:1
func (t *Collections_UnmodifiableMap) Ctor_Map(this Collections_UnmodifiableMap_I, m Map) {
	if m == nil { panic(Thrown(NullPointerException_New())) }
	t.F_m = m
}
func (t *Collections_UnmodifiableMap) Impl_Size__I(this Collections_UnmodifiableMap_I) int32 { return t.F_m.Size__I() }

func (t *Collections_UnmodifiableMap) Impl_IsEmpty__Z(this Collections_UnmodifiableMap_I) bool { return t.F_m.IsEmpty__Z() }

func (t *Collections_UnmodifiableMap) Impl_ContainsKey_O__Z(this Collections_UnmodifiableMap_I, key any) bool { return t.F_m.ContainsKey_O__Z(key) }

func (t *Collections_UnmodifiableMap) Impl_ContainsValue_O__Z(this Collections_UnmodifiableMap_I, val any) bool {
	return t.F_m.ContainsValue_O__Z(val)
}
func (t *Collections_UnmodifiableMap) Impl_Get_O__O(this Collections_UnmodifiableMap_I, key any) any { return t.F_m.Get_O__O(key) }

func (t *Collections_UnmodifiableMap) Impl_Put_O_O__O(this Collections_UnmodifiableMap_I, key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_Remove_O__O(this Collections_UnmodifiableMap_I, key any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_PutAll_Map__V(this Collections_UnmodifiableMap_I, m Map) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_Clear__V(this Collections_UnmodifiableMap_I) {
	panic(Thrown(UnsupportedOperationException_New()))
}






func (t *Collections_UnmodifiableMap) Impl_KeySet__Set(this Collections_UnmodifiableMap_I) Set {
	if t.F_keySet == nil { t.F_keySet = Collections_UnmodifiableSet_Set__Set(t.F_m.KeySet__Set()) }
//line :780:1
	return t.F_keySet
}


func (t *Collections_UnmodifiableMap) Impl_EntrySet__Set(this Collections_UnmodifiableMap_I) Set {
	if t.F_entrySet == nil { t.F_entrySet = Collections_UnmodifiableMap_UnmodifiableEntrySet_New_Set(t.F_m.EntrySet__Set()) }
//line :784:1
	return t.F_entrySet
}


func (t *Collections_UnmodifiableMap) Impl_Values__Collection(this Collections_UnmodifiableMap_I) Collection {
	if t.F_values == nil { t.F_values = Collections_UnmodifiableCollection_Collection__Collection(t.F_m.Values__Collection()) }
//line :788:1
	return t.F_values
}


func (t *Collections_UnmodifiableMap) Impl_Equals_O__Z(this Collections_UnmodifiableMap_I, o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(this); if !tmp1 { tmp1 = t.F_m.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_UnmodifiableMap) Impl_HashCode__I(this Collections_UnmodifiableMap_I) int32 { return t.F_m.HashCode__I() }

func (t *Collections_UnmodifiableMap) Impl_ToString__String(this Collections_UnmodifiableMap_I) *String { return t.F_m.ToString__String() }

func (t *Collections_UnmodifiableMap) Impl_GetOrDefault_O_O__O(this Collections_UnmodifiableMap_I, k, defaultValue any) any {
	return t.F_m.GetOrDefault_O_O__O(k, defaultValue)
}
func (t *Collections_UnmodifiableMap) Impl_ForEach_BiConsumer__V(this Collections_UnmodifiableMap_I, action BiConsumer) {
	t.F_m.ForEach_BiConsumer__V(action)
}
func (t *Collections_UnmodifiableMap) Impl_ReplaceAll_BiFunction__V(this Collections_UnmodifiableMap_I, function BiFunction) {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_PutIfAbsent_O_O__O(this Collections_UnmodifiableMap_I, key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_Remove_O_O__Z(this Collections_UnmodifiableMap_I, key, value any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_Replace_O_O_O__Z(this Collections_UnmodifiableMap_I, key, oldValue, newValue any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_Replace_O_O__O(this Collections_UnmodifiableMap_I, key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_ComputeIfAbsent_O_Function__O(this Collections_UnmodifiableMap_I, key any, mappingFunction Function) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_ComputeIfPresent_O_BiFunction__O(this Collections_UnmodifiableMap_I, key any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_Compute_O_BiFunction__O(this Collections_UnmodifiableMap_I, key any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap) Impl_Merge_O_O_BiFunction__O(this Collections_UnmodifiableMap_I, key, value any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}






func Collections_UnmodifiableMap_UnmodifiableEntrySet_New_Set(p0 Set) *Collections_UnmodifiableMap_UnmodifiableEntrySet { t := &Collections_UnmodifiableMap_UnmodifiableEntrySet{}; t.Ctor_Set(p0); return t }
//line :843:1
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Ctor_Set(s Set) { t.Collections_UnmodifiableSet.Ctor_Set(t, s) }


func Collections_UnmodifiableMap_UnmodifiableEntrySet_EntryConsumer_Consumer__Consumer(action Consumer) Consumer {
	return &Consumer_Fn{Fn: func(p0 any) { var e Map_Entry = Map_Entry_Cast(p0); action.Accept_O__V(Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(e)) }}
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var tmp1 Collection = t.F_c; tmp1.ForEach_Consumer__V(Collections_UnmodifiableMap_UnmodifiableEntrySet_EntryConsumer_Consumer__Consumer(action))
}






func Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator_New_Spliterator(p0 Spliterator) *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator { t := &Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator{}; t.Ctor_Spliterator(p0); return t }
//line :859:1
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) Ctor_Spliterator(s Spliterator) {
	t.F_s = s
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {

	Objects_RequireNonNull_O__O(action)
	var tmp1 Spliterator = t.F_s; return tmp1.TryAdvance_Consumer__Z(Collections_UnmodifiableMap_UnmodifiableEntrySet_EntryConsumer_Consumer__Consumer(action))
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) ForEachRemaining_Consumer__V(action Consumer) {

	Objects_RequireNonNull_O__O(action)
	var tmp1 Spliterator = t.F_s; tmp1.ForEachRemaining_Consumer__V(Collections_UnmodifiableMap_UnmodifiableEntrySet_EntryConsumer_Consumer__Consumer(action))
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) TrySplit__Spliterator() Spliterator {
	var split Spliterator = t.F_s.TrySplit__Spliterator()
	if !(split == nil) { return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator_New_Spliterator(split) } else { return nil
	} }
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) EstimateSize__J() int64 { return t.F_s.EstimateSize__J() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) GetExactSizeIfKnown__J() int64 {
	return t.F_s.GetExactSizeIfKnown__J()
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) Characteristics__I() int32 { return t.F_s.Characteristics__I() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) HasCharacteristics_I__Z(characteristics int32) bool {
	return t.F_s.HasCharacteristics_I__Z(characteristics)
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) GetComparator__Comparator() Comparator {
	return t.F_s.GetComparator__Comparator()
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Spliterator__Spliterator() Spliterator {
	return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator_New_Spliterator(t.F_c.Spliterator__Spliterator())
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Stream__Stream() Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(t.Spliterator__Spliterator(), false)
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) ParallelStream__Stream() Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(t.Spliterator__Spliterator(), true)
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Iterator__Iterator() Iterator {
	return Collections_UnmodifiableMap_UnmodifiableEntrySet_1_New_Collections_UnmodifiableMap_UnmodifiableEntrySet(t)
}


func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) HasNext__Z() bool { return t.F_i.HasNext__Z() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) Next__Map_Entry() Map_Entry {
	return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(Map_Entry_Cast(t.F_i.Next__O()))
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) Remove__V() {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) ForEachRemaining_Consumer__V(action Consumer) {

	Objects_RequireNonNull_O__O(action)
	var tmp1 Iterator = t.F_i; tmp1.ForEachRemaining_Consumer__V(Collections_UnmodifiableMap_UnmodifiableEntrySet_EntryConsumer_Consumer__Consumer(action))
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) ToArray__O1() *RefArray {
	var a *RefArray = t.F_c.ToArray__O1(); var i int32 = 0
L1: for {
	if i < int32(len(a.A)) {
		a.Store(i, Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(Map_Entry_Cast(a.A[i])))
		i = i + 1; continue L1 }
//line :918:1
	break L1 }
//line :917:1
	return a
}





func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) ToArray_O1__O1(a *RefArray) *RefArray {
	var arr *RefArray; var tmp1 Collection = t.F_c; var tmp2 *RefArray; if int32(len(a.A)) == 0 { tmp2 = a } else { tmp2 = Arrays_CopyOf_O1_I__O1(a, 0) }; arr = tmp1.ToArray_O1__O1(tmp2)
	var i int32 = 0; L1: for {
		if i < int32(len(arr.A)) {
			arr.Store(i, Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(Map_Entry_Cast(arr.A[i])))
			i = i + 1; continue L1 }
//line :926:1
		break L1
	}


	var tmp3 int32 = int32(len(arr.A)); if tmp3 > int32(len(a.A)) { return arr } else {


		System_Arraycopy_O_I_O_I_I__V(arr.Ref(), 0, a.Ref(), 0, int32(len(arr.A)))
		var tmp4 int32 = int32(len(a.A)); if tmp4 > int32(len(arr.A)) { a.Store(int32(len(arr.A)), nil) }
//line :932:1
		return a
	}
}


func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Contains_O__Z(o any) bool {
	if !Map_Entry_InstanceOf(o) { return false } else {

		var tmp1 Collection = t.F_c; return tmp1.Contains_O__Z(Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(Map_Entry_Cast(o)))
	} }
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) ContainsAll_Collection__Z(coll Collection) bool {
	var i_101766 Iterator = coll.Iterator__Iterator(); for i_101766.HasNext__Z() { var e any = i_101766.Next__O(); if t.Contains_O__Z(e) { } else { return false } }
//line :942:1
	return true
}


func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else {

		var tmp1 any = o; if Set_InstanceOf(tmp1) { var s Set = Set_Cast(tmp1)
			if s.Size__I() == t.F_c.Size__I() { return t.ContainsAll_Collection__Z(s) } else { return false } } else {
//line :949:1
				return false
			}
	}
}






func Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(p0 Map_Entry) *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry { t := &Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry{}; t.Ctor_Map_Entry(p0); return t }
//line :959:1
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) Ctor_Map_Entry(e Map_Entry) {
	t.F_e = Map_Entry_Cast(Objects_RequireNonNull_O__O(e))
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) GetKey__O() any { return t.F_e.GetKey__O() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) GetValue__O() any { return t.F_e.GetValue__O() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) SetValue_O__O(value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) HashCode__I() int32 { return t.F_e.HashCode__I() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) Equals_O__Z(o any) bool {
	if any(t) == any(o) { return true } else {

		var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var t_ Map_Entry = Map_Entry_Cast(tmp1)
			if Collections_Eq_O_O__Z(t.F_e.GetKey__O(), t_.GetKey__O()) {
				return Collections_Eq_O_O__Z(t.F_e.GetValue__O(), t_.GetValue__O()) } else {
//line :975:1
					return false } } else {
//line :974:1
						return false
					}
	}
}


func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) ToString__String() *String { return t.F_e.ToString__String() }

func Collections_UnmodifiableSequencedMap_SequencedMap__SequencedMap(m SequencedMap) SequencedMap { Collections_Init()
	if m.GetClass__Class() == Collections_UnmodifiableSequencedMap_class { return m } else { return Collections_UnmodifiableSequencedMap_New_Map(m)
	}
}






func Collections_UnmodifiableSequencedMap_New_Map(p0 Map) *Collections_UnmodifiableSequencedMap { t := &Collections_UnmodifiableSequencedMap{}; t.Ctor_Map(p0); return t }
//line :992:1
func (t *Collections_UnmodifiableSequencedMap) Ctor_Map(m Map) { t.Collections_UnmodifiableMap.Ctor_Map(t, m) }


func (t *Collections_UnmodifiableSequencedMap) Sm__SequencedMap() SequencedMap {
	return SequencedMap_Cast(t.F_m)
}
func (t *Collections_UnmodifiableSequencedMap) Reversed__SequencedMap() SequencedMap {
	return Collections_UnmodifiableSequencedMap_New_Map(t.Sm__SequencedMap().Reversed__SequencedMap())
}
func (t *Collections_UnmodifiableSequencedMap) PollFirstEntry__Map_Entry() Map_Entry {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableSequencedMap) PollLastEntry__Map_Entry() Map_Entry {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableSequencedMap) PutFirst_O_O__O(k, v any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableSequencedMap) PutLast_O_O__O(k, v any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func Collections_UnmodifiableSortedMap_SortedMap__SortedMap(m SortedMap) SortedMap { Collections_Init()
	if m.GetClass__Class() == Collections_UnmodifiableSortedMap_class { return m } else { return Collections_UnmodifiableSortedMap_New_SortedMap(m)
	}
}








func Collections_UnmodifiableSortedMap_New_SortedMap(p0 SortedMap) *Collections_UnmodifiableSortedMap { t := &Collections_UnmodifiableSortedMap{}; t.Ctor_SortedMap(t, p0); return t }
//line :1025:1
func (t *Collections_UnmodifiableSortedMap) Ctor_SortedMap(this Collections_UnmodifiableSortedMap_I, m SortedMap) { t.Collections_UnmodifiableMap.Ctor_Map(this, m)

	t.F_sm = m
}
func (t *Collections_UnmodifiableSortedMap) Impl_Comparator__Comparator(this Collections_UnmodifiableSortedMap_I) Comparator {
	return t.F_sm.Comparator__Comparator()
}
func (t *Collections_UnmodifiableSortedMap) Impl_SubMap_O_O__SortedMap(this Collections_UnmodifiableSortedMap_I, fromKey, toKey any) SortedMap {
	return Collections_UnmodifiableSortedMap_New_SortedMap(t.F_sm.SubMap_O_O__SortedMap(fromKey, toKey))
}
func (t *Collections_UnmodifiableSortedMap) Impl_HeadMap_O__SortedMap(this Collections_UnmodifiableSortedMap_I, toKey any) SortedMap {
	return Collections_UnmodifiableSortedMap_New_SortedMap(t.F_sm.HeadMap_O__SortedMap(toKey))
}
func (t *Collections_UnmodifiableSortedMap) Impl_TailMap_O__SortedMap(this Collections_UnmodifiableSortedMap_I, fromKey any) SortedMap {
	return Collections_UnmodifiableSortedMap_New_SortedMap(t.F_sm.TailMap_O__SortedMap(fromKey))
}
func (t *Collections_UnmodifiableSortedMap) Impl_FirstKey__O(this Collections_UnmodifiableSortedMap_I) any { return t.F_sm.FirstKey__O() }

func (t *Collections_UnmodifiableSortedMap) Impl_LastKey__O(this Collections_UnmodifiableSortedMap_I) any { return t.F_sm.LastKey__O() }

func Collections_UnmodifiableNavigableMap_NavigableMap__NavigableMap(m NavigableMap) NavigableMap { Collections_Init()
	if m.GetClass__Class() == Collections_UnmodifiableNavigableMap_class { return m } else { return Collections_UnmodifiableNavigableMap_New_NavigableMap(m)
	}
}













func Collections_UnmodifiableNavigableMap_EmptyNavigableMap_New() *Collections_UnmodifiableNavigableMap_EmptyNavigableMap { Collections_UnmodifiableNavigableMap_EmptyNavigableMap_Init(); t := &Collections_UnmodifiableNavigableMap_EmptyNavigableMap{}; t.Ctor(); return t }
//line :1062:1
func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Ctor() { t.Collections_UnmodifiableNavigableMap.Ctor_NavigableMap(t, TreeMap_New()) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) NavigableKeySet__NavigableSet() NavigableSet {
	return Collections_EmptyNavigableSet__NavigableSet()
}
func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Collections$UnmodifiableNavigableMap$EmptyNavigableMap.readResolve()Ljava/lang/Object;")) }






func Collections_UnmodifiableNavigableMap_New_NavigableMap(p0 NavigableMap) *Collections_UnmodifiableNavigableMap { Collections_UnmodifiableNavigableMap_Init(); t := &Collections_UnmodifiableNavigableMap{}; t.Ctor_NavigableMap(t, p0); return t }
//line :1074:1
func (t *Collections_UnmodifiableNavigableMap) Ctor_NavigableMap(this Collections_UnmodifiableNavigableMap_I, m NavigableMap) { t.Collections_UnmodifiableSortedMap.Ctor_SortedMap(this, m)

	t.F_nm = m
}
func (t *Collections_UnmodifiableNavigableMap) Impl_LowerKey_O__O(this Collections_UnmodifiableNavigableMap_I, key any) any { return t.F_nm.LowerKey_O__O(key) }

func (t *Collections_UnmodifiableNavigableMap) Impl_FloorKey_O__O(this Collections_UnmodifiableNavigableMap_I, key any) any { return t.F_nm.FloorKey_O__O(key) }

func (t *Collections_UnmodifiableNavigableMap) Impl_CeilingKey_O__O(this Collections_UnmodifiableNavigableMap_I, key any) any { return t.F_nm.CeilingKey_O__O(key) }

func (t *Collections_UnmodifiableNavigableMap) Impl_HigherKey_O__O(this Collections_UnmodifiableNavigableMap_I, key any) any { return t.F_nm.HigherKey_O__O(key) }

func (t *Collections_UnmodifiableNavigableMap) Impl_LowerEntry_O__Map_Entry(this Collections_UnmodifiableNavigableMap_I, key any) Map_Entry {
	var lower Map_Entry = t.F_nm.LowerEntry_O__Map_Entry(key)
	if !(lower == nil) {
		return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(lower) } else {
//line :1088:1
			return nil
		}
}
func (t *Collections_UnmodifiableNavigableMap) Impl_FloorEntry_O__Map_Entry(this Collections_UnmodifiableNavigableMap_I, key any) Map_Entry {
	var floor Map_Entry = t.F_nm.FloorEntry_O__Map_Entry(key)
	if !(floor == nil) {
		return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(floor) } else {
//line :1093:1
			return nil
		}
}
func (t *Collections_UnmodifiableNavigableMap) Impl_CeilingEntry_O__Map_Entry(this Collections_UnmodifiableNavigableMap_I, key any) Map_Entry {
	var ceiling Map_Entry = t.F_nm.CeilingEntry_O__Map_Entry(key)
	if !(ceiling == nil) {
		return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(ceiling) } else {
//line :1098:1
			return nil
		}
}
func (t *Collections_UnmodifiableNavigableMap) Impl_HigherEntry_O__Map_Entry(this Collections_UnmodifiableNavigableMap_I, key any) Map_Entry {
	var higher Map_Entry = t.F_nm.HigherEntry_O__Map_Entry(key)
	if !(higher == nil) {
		return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(higher) } else {
//line :1103:1
			return nil
		}
}
func (t *Collections_UnmodifiableNavigableMap) Impl_FirstEntry__Map_Entry(this Collections_UnmodifiableNavigableMap_I) Map_Entry {
	var first Map_Entry = t.F_nm.FirstEntry__Map_Entry()
	if !(first == nil) {
		return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(first) } else {
//line :1108:1
			return nil
		}
}
func (t *Collections_UnmodifiableNavigableMap) Impl_LastEntry__Map_Entry(this Collections_UnmodifiableNavigableMap_I) Map_Entry {
	var last Map_Entry = t.F_nm.LastEntry__Map_Entry()
	if !(last == nil) {
		return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_New_Map_Entry(last) } else {
//line :1113:1
			return nil
		}
}
func (t *Collections_UnmodifiableNavigableMap) Impl_PollFirstEntry__Map_Entry(this Collections_UnmodifiableNavigableMap_I) Map_Entry {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableNavigableMap) Impl_PollLastEntry__Map_Entry(this Collections_UnmodifiableNavigableMap_I) Map_Entry {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_UnmodifiableNavigableMap) Impl_DescendingMap__NavigableMap(this Collections_UnmodifiableNavigableMap_I) NavigableMap {
	return Collections_UnmodifiableNavigableMap_NavigableMap__NavigableMap(t.F_nm.DescendingMap__NavigableMap())
}
func (t *Collections_UnmodifiableNavigableMap) Impl_NavigableKeySet__NavigableSet(this Collections_UnmodifiableNavigableMap_I) NavigableSet {
	return Collections_UnmodifiableNavigableSet_NavigableSet__NavigableSet(t.F_nm.NavigableKeySet__NavigableSet())
}
func (t *Collections_UnmodifiableNavigableMap) Impl_DescendingKeySet__NavigableSet(this Collections_UnmodifiableNavigableMap_I) NavigableSet {
	return Collections_UnmodifiableNavigableSet_NavigableSet__NavigableSet(t.F_nm.DescendingKeySet__NavigableSet())
}
func (t *Collections_UnmodifiableNavigableMap) Impl_SubMap_O_Z_O_Z__NavigableMap(this Collections_UnmodifiableNavigableMap_I, fromKey any, fromInclusive bool, toKey any, toInclusive bool) NavigableMap {

	return Collections_UnmodifiableNavigableMap_NavigableMap__NavigableMap(t.F_nm.SubMap_O_Z_O_Z__NavigableMap(fromKey, fromInclusive, toKey, toInclusive))
}
func (t *Collections_UnmodifiableNavigableMap) Impl_HeadMap_O_Z__NavigableMap(this Collections_UnmodifiableNavigableMap_I, toKey any, inclusive bool) NavigableMap {
	return Collections_UnmodifiableNavigableMap_NavigableMap__NavigableMap(t.F_nm.HeadMap_O_Z__NavigableMap(toKey, inclusive))
}
func (t *Collections_UnmodifiableNavigableMap) Impl_TailMap_O_Z__NavigableMap(this Collections_UnmodifiableNavigableMap_I, fromKey any, inclusive bool) NavigableMap {
	return Collections_UnmodifiableNavigableMap_NavigableMap__NavigableMap(t.F_nm.TailMap_O_Z__NavigableMap(fromKey, inclusive))
}
func Collections_SynchronizedCollection_Collection__Collection(c Collection) Collection { Collections_Init()
	return Collections_SynchronizedCollection_New_Collection(c)
}
func Collections_SynchronizedCollection_Collection_O__Collection(c Collection, mutex any) Collection { Collections_Init()

	return Collections_SynchronizedCollection_New_Collection_O(c, mutex)
}










func Collections_SynchronizedCollection_New_Collection(p0 Collection) *Collections_SynchronizedCollection { t := &Collections_SynchronizedCollection{}; t.Ctor_Collection(t, p0); return t }
//line :1158:1
func (t *Collections_SynchronizedCollection) Ctor_Collection(this Collections_SynchronizedCollection_I, c Collection) {
	t.F_c = Collection_Cast(Objects_RequireNonNull_O__O(c))
	t.F_mutex = this
}
func Collections_SynchronizedCollection_New_Collection_O(p0 Collection, p1 any) *Collections_SynchronizedCollection { t := &Collections_SynchronizedCollection{}; t.Ctor_Collection_O(t, p0, p1); return t }
//line :1162:1
func (t *Collections_SynchronizedCollection) Ctor_Collection_O(this Collections_SynchronizedCollection_I, c Collection, mutex any) {
	t.F_c = Collection_Cast(Objects_RequireNonNull_O__O(c))
	t.F_mutex = Objects_RequireNonNull_O__O(mutex)
}
func (t *Collections_SynchronizedCollection) Impl_Size__I(this Collections_SynchronizedCollection_I) int32 { var tmp1 int32; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.Size__I() }(); return tmp1 }

func (t *Collections_SynchronizedCollection) Impl_IsEmpty__Z(this Collections_SynchronizedCollection_I) bool { var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.IsEmpty__Z() }(); return tmp1 }

func (t *Collections_SynchronizedCollection) Impl_Contains_O__Z(this Collections_SynchronizedCollection_I, o any) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.Contains_O__Z(o) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_ToArray__O1(this Collections_SynchronizedCollection_I) *RefArray { var tmp1 *RefArray; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.ToArray__O1() }(); return tmp1 }

func (t *Collections_SynchronizedCollection) Impl_ToArray_O1__O1(this Collections_SynchronizedCollection_I, a *RefArray) *RefArray {
	var tmp1 *RefArray; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.ToArray_O1__O1(a) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_ToArray_IntFunction__O1(this Collections_SynchronizedCollection_I, f IntFunction) *RefArray {
	var tmp1 *RefArray; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.ToArray_IntFunction__O1(f) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_Iterator__Iterator(this Collections_SynchronizedCollection_I) Iterator { return t.F_c.Iterator__Iterator() }

func (t *Collections_SynchronizedCollection) Impl_Add_O__Z(this Collections_SynchronizedCollection_I, e any) bool { var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.Add_O__Z(e) }(); return tmp1 }

func (t *Collections_SynchronizedCollection) Impl_Remove_O__Z(this Collections_SynchronizedCollection_I, o any) bool { var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.Remove_O__Z(o) }(); return tmp1 }

func (t *Collections_SynchronizedCollection) Impl_ContainsAll_Collection__Z(this Collections_SynchronizedCollection_I, coll Collection) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.ContainsAll_Collection__Z(coll) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_AddAll_Collection__Z(this Collections_SynchronizedCollection_I, coll Collection) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.AddAll_Collection__Z(coll) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_RemoveAll_Collection__Z(this Collections_SynchronizedCollection_I, coll Collection) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.RemoveAll_Collection__Z(coll) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_RetainAll_Collection__Z(this Collections_SynchronizedCollection_I, coll Collection) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.RetainAll_Collection__Z(coll) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_Clear__V(this Collections_SynchronizedCollection_I) { var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_c.Clear__V() }() }

func (t *Collections_SynchronizedCollection) Impl_ToString__String(this Collections_SynchronizedCollection_I) *String { var tmp1 *String; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.ToString__String() }(); return tmp1 }

func (t *Collections_SynchronizedCollection) Impl_ForEach_Consumer__V(this Collections_SynchronizedCollection_I, consumer Consumer) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_c.ForEach_Consumer__V(consumer) }()
}
func (t *Collections_SynchronizedCollection) Impl_RemoveIf_Predicate__Z(this Collections_SynchronizedCollection_I, filter Predicate) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.RemoveIf_Predicate__Z(filter) }(); return tmp1
}
func (t *Collections_SynchronizedCollection) Impl_Spliterator__Spliterator(this Collections_SynchronizedCollection_I) Spliterator {
	return t.F_c.Spliterator__Spliterator()
}
func (t *Collections_SynchronizedCollection) Impl_Stream__Stream(this Collections_SynchronizedCollection_I) Stream { return t.F_c.Stream__Stream() }

func (t *Collections_SynchronizedCollection) Impl_ParallelStream__Stream(this Collections_SynchronizedCollection_I) Stream {
	return t.F_c.ParallelStream__Stream()
}



func Collections_SynchronizedSet_Set__Set(s Set) Set { Collections_Init()
	return Collections_SynchronizedSet_New_Set(s)
}
func Collections_SynchronizedSet_Set_O__Set(s Set, mutex any) Set { Collections_Init()
	return Collections_SynchronizedSet_New_Set_O(s, mutex)
}







func Collections_SynchronizedSet_New_Set(p0 Set) *Collections_SynchronizedSet { t := &Collections_SynchronizedSet{}; t.Ctor_Set(t, p0); return t }
//line :1233:1
func (t *Collections_SynchronizedSet) Ctor_Set(this Collections_SynchronizedSet_I, s Set) { t.Collections_SynchronizedCollection.Ctor_Collection(this, s) }

func Collections_SynchronizedSet_New_Set_O(p0 Set, p1 any) *Collections_SynchronizedSet { t := &Collections_SynchronizedSet{}; t.Ctor_Set_O(t, p0, p1); return t }
//line :1235:1
func (t *Collections_SynchronizedSet) Ctor_Set_O(this Collections_SynchronizedSet_I, s Set, mutex any) { t.Collections_SynchronizedCollection.Ctor_Collection_O(this, s, mutex) }

func (t *Collections_SynchronizedSet) Impl_Equals_O__Z(this Collections_SynchronizedSet_I, o any) bool {
	if any(this) == any(o) { return true } else { var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.Equals_O__Z(o) }(); return tmp1
	} }
func (t *Collections_SynchronizedSet) Impl_HashCode__I(this Collections_SynchronizedSet_I) int32 {
	var tmp1 int32; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_c.HashCode__I() }(); return tmp1
}
func Collections_SynchronizedSortedSet_SortedSet__SortedSet(s SortedSet) SortedSet { Collections_Init()
	return Collections_SynchronizedSortedSet_New_SortedSet(s)
}









func Collections_SynchronizedSortedSet_New_SortedSet(p0 SortedSet) *Collections_SynchronizedSortedSet { t := &Collections_SynchronizedSortedSet{}; t.Ctor_SortedSet(t, p0); return t }
//line :1255:1
func (t *Collections_SynchronizedSortedSet) Ctor_SortedSet(this Collections_SynchronizedSortedSet_I, s SortedSet) { t.Collections_SynchronizedSet.Ctor_Set(this, s); t.F_ss = s }

func Collections_SynchronizedSortedSet_New_SortedSet_O(p0 SortedSet, p1 any) *Collections_SynchronizedSortedSet { t := &Collections_SynchronizedSortedSet{}; t.Ctor_SortedSet_O(t, p0, p1); return t }
//line :1257:1
func (t *Collections_SynchronizedSortedSet) Ctor_SortedSet_O(this Collections_SynchronizedSortedSet_I, s SortedSet, mutex any) { t.Collections_SynchronizedSet.Ctor_Set_O(this, s, mutex)

	t.F_ss = s
}
func (t *Collections_SynchronizedSortedSet) Impl_Comparator__Comparator(this Collections_SynchronizedSortedSet_I) Comparator {
	var tmp1 Comparator; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ss.Comparator__Comparator() }(); return tmp1
}
func (t *Collections_SynchronizedSortedSet) Impl_SubSet_O_O__SortedSet(this Collections_SynchronizedSortedSet_I, fromElement, toElement any) SortedSet {
	var tmp1 SortedSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedSortedSet_New_SortedSet_O(t.F_ss.SubSet_O_O__SortedSet(fromElement, toElement), t.F_mutex) }()
//line :1265:1
	return tmp1
}

func (t *Collections_SynchronizedSortedSet) Impl_HeadSet_O__SortedSet(this Collections_SynchronizedSortedSet_I, toElement any) SortedSet {
	var tmp1 SortedSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedSortedSet_New_SortedSet_O(t.F_ss.HeadSet_O__SortedSet(toElement), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedSortedSet) Impl_TailSet_O__SortedSet(this Collections_SynchronizedSortedSet_I, fromElement any) SortedSet {
	var tmp1 SortedSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedSortedSet_New_SortedSet_O(t.F_ss.TailSet_O__SortedSet(fromElement), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedSortedSet) Impl_First__O(this Collections_SynchronizedSortedSet_I) any { var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ss.First__O() }(); return tmp1 }

func (t *Collections_SynchronizedSortedSet) Impl_Last__O(this Collections_SynchronizedSortedSet_I) any { var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ss.Last__O() }(); return tmp1 }

func Collections_SynchronizedNavigableSet_NavigableSet__NavigableSet(s NavigableSet) NavigableSet { Collections_Init()
	return Collections_SynchronizedNavigableSet_New_NavigableSet(s)
}









func Collections_SynchronizedNavigableSet_New_NavigableSet(p0 NavigableSet) *Collections_SynchronizedNavigableSet { t := &Collections_SynchronizedNavigableSet{}; t.Ctor_NavigableSet(p0); return t }
//line :1290:1
func (t *Collections_SynchronizedNavigableSet) Ctor_NavigableSet(s NavigableSet) { t.Collections_SynchronizedSortedSet.Ctor_SortedSet(t, s); t.F_ns = s }

func Collections_SynchronizedNavigableSet_New_NavigableSet_O(p0 NavigableSet, p1 any) *Collections_SynchronizedNavigableSet { t := &Collections_SynchronizedNavigableSet{}; t.Ctor_NavigableSet_O(p0, p1); return t }
//line :1292:1
func (t *Collections_SynchronizedNavigableSet) Ctor_NavigableSet_O(s NavigableSet, mutex any) { t.Collections_SynchronizedSortedSet.Ctor_SortedSet_O(t, s, mutex)

	t.F_ns = s
}
func (t *Collections_SynchronizedNavigableSet) Lower_O__O(e any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ns.Lower_O__O(e) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) Floor_O__O(e any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ns.Floor_O__O(e) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) Ceiling_O__O(e any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ns.Ceiling_O__O(e) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) Higher_O__O(e any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ns.Higher_O__O(e) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) PollFirst__O() any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ns.PollFirst__O() }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) PollLast__O() any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_ns.PollLast__O() }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) DescendingSet__NavigableSet() NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_ns.DescendingSet__NavigableSet(), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) DescendingIterator__Iterator() Iterator {
	var tmp1 Iterator; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.DescendingSet__NavigableSet().Iterator__Iterator() }(); return tmp1
}
func (t *Collections_SynchronizedNavigableSet) SubSet_O_O__NavigableSet(fromElement, toElement any) NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_ns.SubSet_O_Z_O_Z__NavigableSet(fromElement, true, toElement, false), t.F_mutex) }()
//line :1321:1
	return tmp1
}

func (t *Collections_SynchronizedNavigableSet) HeadSet_O__NavigableSet(toElement any) NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_ns.HeadSet_O_Z__NavigableSet(toElement, false), t.F_mutex) }()
//line :1325:1
	return tmp1
}

func (t *Collections_SynchronizedNavigableSet) TailSet_O__NavigableSet(fromElement any) NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_ns.TailSet_O_Z__NavigableSet(fromElement, true), t.F_mutex) }()
//line :1329:1
	return tmp1
}

func (t *Collections_SynchronizedNavigableSet) SubSet_O_Z_O_Z__NavigableSet(fromElement any, fromInclusive bool, toElement any, toInclusive bool) NavigableSet {

	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_ns.SubSet_O_Z_O_Z__NavigableSet(fromElement, fromInclusive, toElement, toInclusive), t.F_mutex) }()
//line :1334:1
	return tmp1
}


func (t *Collections_SynchronizedNavigableSet) HeadSet_O_Z__NavigableSet(toElement any, inclusive bool) NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_ns.HeadSet_O_Z__NavigableSet(toElement, inclusive), t.F_mutex) }()
//line :1339:1
	return tmp1
}

func (t *Collections_SynchronizedNavigableSet) TailSet_O_Z__NavigableSet(fromElement any, inclusive bool) NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_ns.TailSet_O_Z__NavigableSet(fromElement, inclusive), t.F_mutex) }()
//line :1343:1
	return tmp1
}

func Collections_SynchronizedList_List__List(list List) List { Collections_Init()
	if RandomAccess_InstanceOf(list) {
		return Collections_SynchronizedRandomAccessList_New_List(list) } else {
			return Collections_SynchronizedList_New_List(list)
		} }
func Collections_SynchronizedList_List_O__List(list List, mutex any) List { Collections_Init()
	if RandomAccess_InstanceOf(list) {
		return Collections_SynchronizedRandomAccessList_New_List_O(list, mutex) } else {
			return Collections_SynchronizedList_New_List_O(list, mutex)
		}
}












func Collections_SynchronizedList_New_List(p0 List) *Collections_SynchronizedList { t := &Collections_SynchronizedList{}; t.Ctor_List(t, p0); return t }
//line :1369:1
func (t *Collections_SynchronizedList) Ctor_List(this Collections_SynchronizedList_I, list List) { t.Collections_SynchronizedCollection.Ctor_Collection(this, list); t.F_reversedView = nil

	t.F_list = list
	t.F_isReversed = false
}
func Collections_SynchronizedList_New_List_O(p0 List, p1 any) *Collections_SynchronizedList { t := &Collections_SynchronizedList{}; t.Ctor_List_O(t, p0, p1); return t }
//line :1374:1
func (t *Collections_SynchronizedList) Ctor_List_O(this Collections_SynchronizedList_I, list List, mutex any) { t.Collections_SynchronizedCollection.Ctor_Collection_O(this, list, mutex); t.F_reversedView = nil

	t.F_list = list
	t.F_isReversed = false
}
func Collections_SynchronizedList_New_List_O_Collections_SynchronizedList(p0 List, p1 any, p2 Collections_SynchronizedList_I) *Collections_SynchronizedList { t := &Collections_SynchronizedList{}; t.Ctor_List_O_Collections_SynchronizedList(t, p0, p1, p2); return t }
//line :1379:1
func (t *Collections_SynchronizedList) Ctor_List_O_Collections_SynchronizedList(this Collections_SynchronizedList_I, revList List, mutex any, forward Collections_SynchronizedList_I) { t.Collections_SynchronizedCollection.Ctor_Collection_O(this, revList, mutex); t.F_reversedView = nil

	t.F_list = revList
	t.F_reversedView = forward
	t.F_isReversed = true
}
func (t *Collections_SynchronizedList) Impl_Equals_O__Z(this Collections_SynchronizedList_I, o any) bool {
	if any(this) == any(o) { return true } else { var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.Equals_O__Z(o) }(); return tmp1
	} }
func (t *Collections_SynchronizedList) Impl_HashCode__I(this Collections_SynchronizedList_I) int32 {
	var tmp1 int32; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.HashCode__I() }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_Get_I__O(this Collections_SynchronizedList_I, index int32) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.Get_I__O(index) }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_Set_I_O__O(this Collections_SynchronizedList_I, index int32, element any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.Set_I_O__O(index, element) }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_Add_I_O__V(this Collections_SynchronizedList_I, index int32, element any) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_list.Add_I_O__V(index, element) }()
}
func (t *Collections_SynchronizedList) Impl_Remove_I__O(this Collections_SynchronizedList_I, index int32) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.Remove_I__O(index) }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_IndexOf_O__I(this Collections_SynchronizedList_I, o any) int32 {
	var tmp1 int32; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.IndexOf_O__I(o) }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_LastIndexOf_O__I(this Collections_SynchronizedList_I, o any) int32 {
	var tmp1 int32; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.LastIndexOf_O__I(o) }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_AddAll_I_Collection__Z(this Collections_SynchronizedList_I, index int32, c Collection) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.AddAll_I_Collection__Z(index, c) }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_ListIterator__ListIterator(this Collections_SynchronizedList_I) ListIterator {
	return t.F_list.ListIterator__ListIterator()
}
func (t *Collections_SynchronizedList) Impl_ListIterator_I__ListIterator(this Collections_SynchronizedList_I, index int32) ListIterator {
	return t.F_list.ListIterator_I__ListIterator(index)
}
func (t *Collections_SynchronizedList) Impl_SubList_I_I__List(this Collections_SynchronizedList_I, fromIndex, toIndex int32) List {
	var tmp1 List; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedList_New_List_O(t.F_list.SubList_I_I__List(fromIndex, toIndex), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_ReplaceAll_UnaryOperator__V(this Collections_SynchronizedList_I, operator UnaryOperator) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_list.ReplaceAll_UnaryOperator__V(operator) }()
}
func (t *Collections_SynchronizedList) Impl_Sort_Comparator__V(this Collections_SynchronizedList_I, c Comparator) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_list.Sort_Comparator__V(c) }()
}
func (t *Collections_SynchronizedList) Impl_AddFirst_O__V(this Collections_SynchronizedList_I, element any) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_list.AddFirst_O__V(element) }()
}
func (t *Collections_SynchronizedList) Impl_AddLast_O__V(this Collections_SynchronizedList_I, element any) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_list.AddLast_O__V(element) }()
}
func (t *Collections_SynchronizedList) Impl_GetFirst__O(this Collections_SynchronizedList_I) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.GetFirst__O() }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_GetLast__O(this Collections_SynchronizedList_I) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.GetLast__O() }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_RemoveFirst__O(this Collections_SynchronizedList_I) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.RemoveFirst__O() }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_RemoveLast__O(this Collections_SynchronizedList_I) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_list.RemoveLast__O() }(); return tmp1
}
func (t *Collections_SynchronizedList) Impl_Reversed__List(this Collections_SynchronizedList_I) List {
	var tmp1 List; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		if t.F_reversedView == nil {
			t.F_reversedView = Collections_SynchronizedList_New_List_O_Collections_SynchronizedList(t.F_list.Reversed__List(), t.F_mutex, this) }
//line :1446:1
		tmp1 = t.F_reversedView }(); return tmp1
}







func (t *Collections_SynchronizedList) Impl_ReadResolve__O(this Collections_SynchronizedList_I) any { panic(A2g_NotTranslated("java.util.Collections$SynchronizedList.readResolve()Ljava/lang/Object;")) }







func Collections_SynchronizedRandomAccessList_New_List(p0 List) *Collections_SynchronizedRandomAccessList { t := &Collections_SynchronizedRandomAccessList{}; t.Ctor_List(p0); return t }
//line :1463:1
func (t *Collections_SynchronizedRandomAccessList) Ctor_List(list List) { t.Collections_SynchronizedList.Ctor_List(t, list) }

func Collections_SynchronizedRandomAccessList_New_List_O(p0 List, p1 any) *Collections_SynchronizedRandomAccessList { t := &Collections_SynchronizedRandomAccessList{}; t.Ctor_List_O(p0, p1); return t }
//line :1465:1
func (t *Collections_SynchronizedRandomAccessList) Ctor_List_O(list List, mutex any) { t.Collections_SynchronizedList.Ctor_List_O(t, list, mutex) }

func Collections_SynchronizedRandomAccessList_New_List_O_Collections_SynchronizedList(p0 List, p1 any, p2 Collections_SynchronizedList_I) *Collections_SynchronizedRandomAccessList { t := &Collections_SynchronizedRandomAccessList{}; t.Ctor_List_O_Collections_SynchronizedList(p0, p1, p2); return t }
//line :1467:1
func (t *Collections_SynchronizedRandomAccessList) Ctor_List_O_Collections_SynchronizedList(list List, mutex any, forward Collections_SynchronizedList_I) { t.Collections_SynchronizedList.Ctor_List_O_Collections_SynchronizedList(t, list, mutex, forward) }


func (t *Collections_SynchronizedRandomAccessList) Reversed__List() List {
	var tmp1 List; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		if t.F_reversedView == nil {
			t.F_reversedView = Collections_SynchronizedRandomAccessList_New_List_O_Collections_SynchronizedList(t.F_list.Reversed__List(), t.F_mutex, t)
		}
		tmp1 = t.F_reversedView }()
//line :1471:1
	return tmp1
}




func (t *Collections_SynchronizedRandomAccessList) SubList_I_I__List(fromIndex, toIndex int32) List {
	var tmp1 List; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedRandomAccessList_New_List_O(t.F_list.SubList_I_I__List(fromIndex, toIndex), t.F_mutex) }()
//line :1478:1
	return tmp1
}



func (t *Collections_SynchronizedRandomAccessList) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.Collections$SynchronizedRandomAccessList.writeReplace()Ljava/lang/Object;")) }

func Collections_SynchronizedMap_Map__Map(m Map) Map { Collections_Init()
	return Collections_SynchronizedMap_New_Map(m)
}










func Collections_SynchronizedMap_New_Map(p0 Map) *Collections_SynchronizedMap { t := &Collections_SynchronizedMap{}; t.Ctor_Map(t, p0); return t }
//line :1498:1
func (t *Collections_SynchronizedMap) Ctor_Map(this Collections_SynchronizedMap_I, m Map) {
	t.F_m = Map_Cast(Objects_RequireNonNull_O__O(m))
	t.F_mutex = this
}
func Collections_SynchronizedMap_New_Map_O(p0 Map, p1 any) *Collections_SynchronizedMap { t := &Collections_SynchronizedMap{}; t.Ctor_Map_O(t, p0, p1); return t }
//line :1502:1
func (t *Collections_SynchronizedMap) Ctor_Map_O(this Collections_SynchronizedMap_I, m Map, mutex any) {
	t.F_m = m
	t.F_mutex = mutex
}
func (t *Collections_SynchronizedMap) Impl_Size__I(this Collections_SynchronizedMap_I) int32 { var tmp1 int32; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Size__I() }(); return tmp1 }

func (t *Collections_SynchronizedMap) Impl_IsEmpty__Z(this Collections_SynchronizedMap_I) bool { var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.IsEmpty__Z() }(); return tmp1 }

func (t *Collections_SynchronizedMap) Impl_ContainsKey_O__Z(this Collections_SynchronizedMap_I, key any) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.ContainsKey_O__Z(key) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_ContainsValue_O__Z(this Collections_SynchronizedMap_I, value any) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.ContainsValue_O__Z(value) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_Get_O__O(this Collections_SynchronizedMap_I, key any) any { var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Get_O__O(key) }(); return tmp1 }

func (t *Collections_SynchronizedMap) Impl_Put_O_O__O(this Collections_SynchronizedMap_I, key, value any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Put_O_O__O(key, value) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_Remove_O__O(this Collections_SynchronizedMap_I, key any) any { var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Remove_O__O(key) }(); return tmp1 }

func (t *Collections_SynchronizedMap) Impl_PutAll_Map__V(this Collections_SynchronizedMap_I, map_ Map) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_m.PutAll_Map__V(map_) }()
}
func (t *Collections_SynchronizedMap) Impl_Clear__V(this Collections_SynchronizedMap_I) { var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_m.Clear__V() }() }







func (t *Collections_SynchronizedMap) Impl_KeySet__Set(this Collections_SynchronizedMap_I) Set {
	var tmp1 Set; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); if t.F_keySet == nil { t.F_keySet = Collections_SynchronizedSet_New_Set_O(t.F_m.KeySet__Set(), t.F_mutex) }; tmp1 = t.F_keySet }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_EntrySet__Set(this Collections_SynchronizedMap_I) Set {
	var tmp1 Set; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		if t.F_entrySet == nil { t.F_entrySet = Collections_SynchronizedSet_New_Set_O(t.F_m.EntrySet__Set(), t.F_mutex) }
//line :1538:1
		tmp1 = t.F_entrySet }(); return tmp1
}


func (t *Collections_SynchronizedMap) Impl_Values__Collection(this Collections_SynchronizedMap_I) Collection {
	var tmp1 Collection; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		if t.F_values == nil { t.F_values = Collections_SynchronizedCollection_New_Collection_O(t.F_m.Values__Collection(), t.F_mutex) }
//line :1543:1
		tmp1 = t.F_values }(); return tmp1
}


func (t *Collections_SynchronizedMap) Impl_Equals_O__Z(this Collections_SynchronizedMap_I, o any) bool {
	if any(this) == any(o) { return true } else { var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Equals_O__Z(o) }(); return tmp1
	} }
func (t *Collections_SynchronizedMap) Impl_HashCode__I(this Collections_SynchronizedMap_I) int32 { var tmp1 int32; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.HashCode__I() }(); return tmp1 }

func (t *Collections_SynchronizedMap) Impl_ToString__String(this Collections_SynchronizedMap_I) *String { var tmp1 *String; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.ToString__String() }(); return tmp1 }

func (t *Collections_SynchronizedMap) Impl_GetOrDefault_O_O__O(this Collections_SynchronizedMap_I, k, defaultValue any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.GetOrDefault_O_O__O(k, defaultValue) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_ForEach_BiConsumer__V(this Collections_SynchronizedMap_I, action BiConsumer) {
	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_m.ForEach_BiConsumer__V(action) }()
}
func (t *Collections_SynchronizedMap) Impl_ReplaceAll_BiFunction__V(this Collections_SynchronizedMap_I, function BiFunction) {

	var tmp1 any = t.F_mutex; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_m.ReplaceAll_BiFunction__V(function) }()
}
func (t *Collections_SynchronizedMap) Impl_PutIfAbsent_O_O__O(this Collections_SynchronizedMap_I, key, value any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.PutIfAbsent_O_O__O(key, value) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_Remove_O_O__Z(this Collections_SynchronizedMap_I, key, value any) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Remove_O_O__Z(key, value) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_Replace_O_O_O__Z(this Collections_SynchronizedMap_I, key, oldValue, newValue any) bool {
	var tmp1 bool; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Replace_O_O_O__Z(key, oldValue, newValue) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_Replace_O_O__O(this Collections_SynchronizedMap_I, key, value any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Replace_O_O__O(key, value) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_ComputeIfAbsent_O_Function__O(this Collections_SynchronizedMap_I, key any, mappingFunction Function) any {

	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.ComputeIfAbsent_O_Function__O(key, mappingFunction) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_ComputeIfPresent_O_BiFunction__O(this Collections_SynchronizedMap_I, key any, remappingFunction BiFunction) any {

	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.ComputeIfPresent_O_BiFunction__O(key, remappingFunction) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_Compute_O_BiFunction__O(this Collections_SynchronizedMap_I, key any, remappingFunction BiFunction) any {

	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Compute_O_BiFunction__O(key, remappingFunction) }(); return tmp1
}
func (t *Collections_SynchronizedMap) Impl_Merge_O_O_BiFunction__O(this Collections_SynchronizedMap_I, key, value any, remappingFunction BiFunction) any {

	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_m.Merge_O_O_BiFunction__O(key, value, remappingFunction) }(); return tmp1
}



func Collections_SynchronizedSortedMap_SortedMap__SortedMap(m SortedMap) SortedMap { Collections_Init()
	return Collections_SynchronizedSortedMap_New_SortedMap(m)
}









func Collections_SynchronizedSortedMap_New_SortedMap(p0 SortedMap) *Collections_SynchronizedSortedMap { t := &Collections_SynchronizedSortedMap{}; t.Ctor_SortedMap(t, p0); return t }
//line :1607:1
func (t *Collections_SynchronizedSortedMap) Ctor_SortedMap(this Collections_SynchronizedSortedMap_I, m SortedMap) { t.Collections_SynchronizedMap.Ctor_Map(this, m); t.F_sm = m }

func Collections_SynchronizedSortedMap_New_SortedMap_O(p0 SortedMap, p1 any) *Collections_SynchronizedSortedMap { t := &Collections_SynchronizedSortedMap{}; t.Ctor_SortedMap_O(t, p0, p1); return t }
//line :1609:1
func (t *Collections_SynchronizedSortedMap) Ctor_SortedMap_O(this Collections_SynchronizedSortedMap_I, m SortedMap, mutex any) { t.Collections_SynchronizedMap.Ctor_Map_O(this, m, mutex)

	t.F_sm = m
}
func (t *Collections_SynchronizedSortedMap) Impl_Comparator__Comparator(this Collections_SynchronizedSortedMap_I) Comparator {
	var tmp1 Comparator; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_sm.Comparator__Comparator() }(); return tmp1
}
func (t *Collections_SynchronizedSortedMap) Impl_SubMap_O_O__SortedMap(this Collections_SynchronizedSortedMap_I, fromKey, toKey any) SortedMap {
	var tmp1 SortedMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedSortedMap_New_SortedMap_O(t.F_sm.SubMap_O_O__SortedMap(fromKey, toKey), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedSortedMap) Impl_HeadMap_O__SortedMap(this Collections_SynchronizedSortedMap_I, toKey any) SortedMap {
	var tmp1 SortedMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedSortedMap_New_SortedMap_O(t.F_sm.HeadMap_O__SortedMap(toKey), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedSortedMap) Impl_TailMap_O__SortedMap(this Collections_SynchronizedSortedMap_I, fromKey any) SortedMap {
	var tmp1 SortedMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedSortedMap_New_SortedMap_O(t.F_sm.TailMap_O__SortedMap(fromKey), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedSortedMap) Impl_FirstKey__O(this Collections_SynchronizedSortedMap_I) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_sm.FirstKey__O() }(); return tmp1
}
func (t *Collections_SynchronizedSortedMap) Impl_LastKey__O(this Collections_SynchronizedSortedMap_I) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_sm.LastKey__O() }(); return tmp1
}
func Collections_SynchronizedNavigableMap_NavigableMap__NavigableMap(m NavigableMap) NavigableMap { Collections_Init()
	return Collections_SynchronizedNavigableMap_New_NavigableMap(m)
}









func Collections_SynchronizedNavigableMap_New_NavigableMap(p0 NavigableMap) *Collections_SynchronizedNavigableMap { t := &Collections_SynchronizedNavigableMap{}; t.Ctor_NavigableMap(p0); return t }
//line :1643:1
func (t *Collections_SynchronizedNavigableMap) Ctor_NavigableMap(m NavigableMap) { t.Collections_SynchronizedSortedMap.Ctor_SortedMap(t, m); t.F_nm = m }

func Collections_SynchronizedNavigableMap_New_NavigableMap_O(p0 NavigableMap, p1 any) *Collections_SynchronizedNavigableMap { t := &Collections_SynchronizedNavigableMap{}; t.Ctor_NavigableMap_O(p0, p1); return t }
//line :1645:1
func (t *Collections_SynchronizedNavigableMap) Ctor_NavigableMap_O(m NavigableMap, mutex any) { t.Collections_SynchronizedSortedMap.Ctor_SortedMap_O(t, m, mutex)

	t.F_nm = m
}
func (t *Collections_SynchronizedNavigableMap) LowerEntry_O__Map_Entry(key any) Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.LowerEntry_O__Map_Entry(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) LowerKey_O__O(key any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.LowerKey_O__O(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) FloorEntry_O__Map_Entry(key any) Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.FloorEntry_O__Map_Entry(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) FloorKey_O__O(key any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.FloorKey_O__O(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) CeilingEntry_O__Map_Entry(key any) Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.CeilingEntry_O__Map_Entry(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) CeilingKey_O__O(key any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.CeilingKey_O__O(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) HigherEntry_O__Map_Entry(key any) Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.HigherEntry_O__Map_Entry(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) HigherKey_O__O(key any) any {
	var tmp1 any; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.HigherKey_O__O(key) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) FirstEntry__Map_Entry() Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.FirstEntry__Map_Entry() }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) LastEntry__Map_Entry() Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.LastEntry__Map_Entry() }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) PollFirstEntry__Map_Entry() Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.PollFirstEntry__Map_Entry() }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) PollLastEntry__Map_Entry() Map_Entry {
	var tmp1 Map_Entry; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = t.F_nm.PollLastEntry__Map_Entry() }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) DescendingMap__NavigableMap() NavigableMap {
	var tmp1 NavigableMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedNavigableMap_New_NavigableMap_O(t.F_nm.DescendingMap__NavigableMap(), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) KeySet__NavigableSet() NavigableSet {
	return t.NavigableKeySet__NavigableSet()
}
func (t *Collections_SynchronizedNavigableMap) NavigableKeySet__NavigableSet() NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_nm.NavigableKeySet__NavigableSet(), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) DescendingKeySet__NavigableSet() NavigableSet {
	var tmp1 NavigableSet; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedNavigableSet_New_NavigableSet_O(t.F_nm.DescendingKeySet__NavigableSet(), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) SubMap_O_O__SortedMap(fromKey, toKey any) SortedMap {
	var tmp1 SortedMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableMap_New_NavigableMap_O(t.F_nm.SubMap_O_Z_O_Z__NavigableMap(fromKey, true, toKey, false), t.F_mutex) }()
//line :1698:1
	return tmp1
}

func (t *Collections_SynchronizedNavigableMap) HeadMap_O__SortedMap(toKey any) SortedMap {
	var tmp1 SortedMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedNavigableMap_New_NavigableMap_O(t.F_nm.HeadMap_O_Z__NavigableMap(toKey, false), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) TailMap_O__SortedMap(fromKey any) SortedMap {
	var tmp1 SortedMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); tmp1 = Collections_SynchronizedNavigableMap_New_NavigableMap_O(t.F_nm.TailMap_O_Z__NavigableMap(fromKey, true), t.F_mutex) }(); return tmp1
}
func (t *Collections_SynchronizedNavigableMap) SubMap_O_Z_O_Z__NavigableMap(fromKey any, fromInclusive bool, toKey any, toInclusive bool) NavigableMap {

	var tmp1 NavigableMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableMap_New_NavigableMap_O(t.F_nm.SubMap_O_Z_O_Z__NavigableMap(fromKey, fromInclusive, toKey, toInclusive), t.F_mutex) }()
//line :1709:1
	return tmp1
}


func (t *Collections_SynchronizedNavigableMap) HeadMap_O_Z__NavigableMap(toKey any, inclusive bool) NavigableMap {
	var tmp1 NavigableMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableMap_New_NavigableMap_O(t.F_nm.HeadMap_O_Z__NavigableMap(toKey, inclusive), t.F_mutex) }()
//line :1714:1
	return tmp1
}

func (t *Collections_SynchronizedNavigableMap) TailMap_O_Z__NavigableMap(fromKey any, inclusive bool) NavigableMap {
	var tmp1 NavigableMap; var tmp2 any = t.F_mutex; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		tmp1 = Collections_SynchronizedNavigableMap_New_NavigableMap_O(t.F_nm.TailMap_O_Z__NavigableMap(fromKey, inclusive), t.F_mutex) }()
//line :1718:1
	return tmp1
}

func Collections_CheckedCollection_Collection_Class__Collection(c Collection, type_ *Class) Collection { Collections_Init()

	return Collections_CheckedCollection_New_Collection_Class(c, type_)
}
func Collections_ZeroLengthArray_Class__O1(type_ *Class) *RefArray { Collections_Init()
	return A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(type_, 0), Object_class.ArrayClass())
}










func (t *Collections_CheckedCollection) Impl_TypeCheck_O__O(this Collections_CheckedCollection_I, o any) any {
	var tmp1 bool; var tmp2 bool; tmp2 = !(o == nil); if tmp2 { tmp2 = !NN(t.F_type).IsInstance_O__Z(o) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(ClassCastException_New_String(t.Impl_BadElementMsg_O__String(this, o)))) }
//line :1738:1
	return o
}



func (t *Collections_CheckedCollection) Impl_BadElementMsg_O__String(this Collections_CheckedCollection_I, o any) *String {
	return Concat(Lit_2636, StrOfObj(GetClass(o).Ref()), Lit_2637, StrOfObj(t.F_type.Ref()))
}



func Collections_CheckedCollection_New_Collection_Class(p0 Collection, p1 *Class) *Collections_CheckedCollection { t := &Collections_CheckedCollection{}; t.Ctor_Collection_Class(t, p0, p1); return t }
//line :1749:1
func (t *Collections_CheckedCollection) Ctor_Collection_Class(this Collections_CheckedCollection_I, c Collection, type_ *Class) {
	t.F_c = Collection_Cast(Objects_RequireNonNull_O_String__O(c, Lit_2635))
	t.F_type = Class_Cast(Objects_RequireNonNull_O_String__O(type_.Ref(), Lit_2307))
}
func (t *Collections_CheckedCollection) Impl_Size__I(this Collections_CheckedCollection_I) int32 { return t.F_c.Size__I() }

func (t *Collections_CheckedCollection) Impl_IsEmpty__Z(this Collections_CheckedCollection_I) bool { return t.F_c.IsEmpty__Z() }

func (t *Collections_CheckedCollection) Impl_Contains_O__Z(this Collections_CheckedCollection_I, o any) bool { return t.F_c.Contains_O__Z(o) }

func (t *Collections_CheckedCollection) Impl_ToArray__O1(this Collections_CheckedCollection_I) *RefArray { return t.F_c.ToArray__O1() }

func (t *Collections_CheckedCollection) Impl_ToArray_O1__O1(this Collections_CheckedCollection_I, a *RefArray) *RefArray {
	return t.F_c.ToArray_O1__O1(a)
}
func (t *Collections_CheckedCollection) Impl_ToArray_IntFunction__O1(this Collections_CheckedCollection_I, f IntFunction) *RefArray {
	return t.F_c.ToArray_IntFunction__O1(f)
}
func (t *Collections_CheckedCollection) Impl_ToString__String(this Collections_CheckedCollection_I) *String { return t.F_c.ToString__String() }

func (t *Collections_CheckedCollection) Impl_Remove_O__Z(this Collections_CheckedCollection_I, o any) bool { return t.F_c.Remove_O__Z(o) }

func (t *Collections_CheckedCollection) Impl_Clear__V(this Collections_CheckedCollection_I) { t.F_c.Clear__V() }

func (t *Collections_CheckedCollection) Impl_ContainsAll_Collection__Z(this Collections_CheckedCollection_I, coll Collection) bool {
	return t.F_c.ContainsAll_Collection__Z(coll)
}
func (t *Collections_CheckedCollection) Impl_RemoveAll_Collection__Z(this Collections_CheckedCollection_I, coll Collection) bool {
	return t.F_c.RemoveAll_Collection__Z(coll)
}
func (t *Collections_CheckedCollection) Impl_RetainAll_Collection__Z(this Collections_CheckedCollection_I, coll Collection) bool {
	return t.F_c.RetainAll_Collection__Z(coll)
}
func (t *Collections_CheckedCollection) Impl_Iterator__Iterator(this Collections_CheckedCollection_I) Iterator {
	var it Iterator = t.F_c.Iterator__Iterator()
	return Collections_CheckedCollection_1_New_Collections_CheckedCollection_Iterator(this, it) }
func (t *Collections_CheckedCollection_1) HasNext__Z() bool { return t.F_val_it.HasNext__Z() }

func (t *Collections_CheckedCollection_1) Next__O() any { return t.F_val_it.Next__O() }

func (t *Collections_CheckedCollection_1) Remove__V() { t.F_val_it.Remove__V() }

func (t *Collections_CheckedCollection_1) ForEachRemaining_Consumer__V(action Consumer) {
	t.F_val_it.ForEachRemaining_Consumer__V(action)
}
func (t *Collections_CheckedCollection) Impl_Add_O__Z(this Collections_CheckedCollection_I, e any) bool { var tmp1 Collection = t.F_c; return tmp1.Add_O__Z(this.TypeCheck_O__O(e)) }



func (t *Collections_CheckedCollection) Impl_ZeroLengthElementArray__O1(this Collections_CheckedCollection_I) *RefArray {
	if !(t.F_zeroLengthElementArray == nil) { return t.F_zeroLengthElementArray } else {

		var tmp1 *RefArray = Collections_ZeroLengthArray_Class__O1(t.F_type); t.F_zeroLengthElementArray = tmp1; return tmp1
	} }
func (t *Collections_CheckedCollection) Impl_CheckedCopyOf_Collection__Collection(this Collections_CheckedCollection_I, coll Collection) Collection {
	var a *RefArray; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var z *RefArray = t.Impl_ZeroLengthElementArray__O1(this)
			a = coll.ToArray_O1__O1(z)
			if GetClass(a.Ref()) == GetClass(z.Ref()) { } else {
				var tmp1 *RefArray = a; var tmp2 int32 = int32(len(a.A)); a = Arrays_CopyOf_O1_I_Class__O1(tmp1, tmp2, GetClass(z.Ref())) } }; return nil }()
//line :1805:1
	if tmp3 != nil { if ArrayStoreException_InstanceOf(tmp3) { var ignore *ArrayStoreException = ArrayStoreException_Cast(tmp3); _ = ignore





		a = NN(coll.ToArray__O1()).Copy()
		var arr_101769 *RefArray = a; var len_101770 int32 = int32(len(arr_101769.A)); var i_101771 int32 = 0; for ; i_101771 < len_101770; i_101771++ { var o any = arr_101769.A[i_101771]; this.TypeCheck_O__O(o) } } else {
//line :1805:1
			panic(tmp3)
		}
	}





	return Arrays_AsList_O1__List(a)
}
func (t *Collections_CheckedCollection) Impl_AddAll_Collection__Z(this Collections_CheckedCollection_I, coll Collection) bool {
	var tmp1 Collection = t.F_c; return tmp1.AddAll_Collection__Z(this.CheckedCopyOf_Collection__Collection(coll))
}
func (t *Collections_CheckedCollection) Impl_ForEach_Consumer__V(this Collections_CheckedCollection_I, action Consumer) {
	t.F_c.ForEach_Consumer__V(action)
}
func (t *Collections_CheckedCollection) Impl_RemoveIf_Predicate__Z(this Collections_CheckedCollection_I, filter Predicate) bool {
	return t.F_c.RemoveIf_Predicate__Z(filter)
}
func (t *Collections_CheckedCollection) Impl_Spliterator__Spliterator(this Collections_CheckedCollection_I) Spliterator {
	return t.F_c.Spliterator__Spliterator()
}
func (t *Collections_CheckedCollection) Impl_Stream__Stream(this Collections_CheckedCollection_I) Stream { return t.F_c.Stream__Stream() }

func (t *Collections_CheckedCollection) Impl_ParallelStream__Stream(this Collections_CheckedCollection_I) Stream {
	return t.F_c.ParallelStream__Stream()
}
func Collections_CheckedQueue_Queue_Class__Queue(queue Queue, type_ *Class) Queue { Collections_Init()

	return Collections_CheckedQueue_New_Queue_Class(queue, type_)
}









func Collections_CheckedQueue_New_Queue_Class(p0 Queue, p1 *Class) *Collections_CheckedQueue { t := &Collections_CheckedQueue{}; t.Ctor_Queue_Class(p0, p1); return t }
//line :1845:1
func (t *Collections_CheckedQueue) Ctor_Queue_Class(queue Queue, elementType *Class) { t.Collections_CheckedCollection.Ctor_Collection_Class(t, queue, elementType)

	t.F_queue = queue
}
func (t *Collections_CheckedQueue) Element__O() any { return t.F_queue.Element__O() }

func (t *Collections_CheckedQueue) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(t); if !tmp1 { tmp1 = t.F_c.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_CheckedQueue) HashCode__I() int32 { return t.F_c.HashCode__I() }

func (t *Collections_CheckedQueue) Peek__O() any { return t.F_queue.Peek__O() }

func (t *Collections_CheckedQueue) Poll__O() any { return t.F_queue.Poll__O() }

func (t *Collections_CheckedQueue) Remove__O() any { return t.F_queue.Remove__O() }

func (t *Collections_CheckedQueue) Offer_O__Z(e any) bool {
	var tmp1 Queue = t.F_queue; return tmp1.Offer_O__Z(t.TypeCheck_O__O(e))
}
func Collections_CheckedSet_Set_Class__Set(s Set, type_ *Class) Set { Collections_Init()

	return Collections_CheckedSet_New_Set_Class(s, type_)
}







func Collections_CheckedSet_New_Set_Class(p0 Set, p1 *Class) *Collections_CheckedSet { t := &Collections_CheckedSet{}; t.Ctor_Set_Class(t, p0, p1); return t }
//line :1876:1
func (t *Collections_CheckedSet) Ctor_Set_Class(this Collections_CheckedSet_I, s Set, elementType *Class) { t.Collections_CheckedCollection.Ctor_Collection_Class(this, s, elementType) }


func (t *Collections_CheckedSet) Impl_Equals_O__Z(this Collections_CheckedSet_I, o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(this); if !tmp1 { tmp1 = t.F_c.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_CheckedSet) Impl_HashCode__I(this Collections_CheckedSet_I) int32 { return t.F_c.HashCode__I() }

func Collections_CheckedSortedSet_SortedSet_Class__SortedSet(s SortedSet, type_ *Class) SortedSet { Collections_Init()

	return Collections_CheckedSortedSet_New_SortedSet_Class(s, type_)
}









func Collections_CheckedSortedSet_New_SortedSet_Class(p0 SortedSet, p1 *Class) *Collections_CheckedSortedSet { t := &Collections_CheckedSortedSet{}; t.Ctor_SortedSet_Class(t, p0, p1); return t }
//line :1897:1
func (t *Collections_CheckedSortedSet) Ctor_SortedSet_Class(this Collections_CheckedSortedSet_I, s SortedSet, type_ *Class) { t.Collections_CheckedSet.Ctor_Set_Class(this, s, type_)

	t.F_ss = s
}
func (t *Collections_CheckedSortedSet) Impl_Comparator__Comparator(this Collections_CheckedSortedSet_I) Comparator {
	return t.F_ss.Comparator__Comparator()
}
func (t *Collections_CheckedSortedSet) Impl_First__O(this Collections_CheckedSortedSet_I) any { return t.F_ss.First__O() }

func (t *Collections_CheckedSortedSet) Impl_Last__O(this Collections_CheckedSortedSet_I) any { return t.F_ss.Last__O() }

func (t *Collections_CheckedSortedSet) Impl_SubSet_O_O__SortedSet(this Collections_CheckedSortedSet_I, fromElement, toElement any) SortedSet {
	return Collections_CheckedSortedSet_SortedSet_Class__SortedSet(t.F_ss.SubSet_O_O__SortedSet(fromElement, toElement), t.F_type)
}
func (t *Collections_CheckedSortedSet) Impl_HeadSet_O__SortedSet(this Collections_CheckedSortedSet_I, toElement any) SortedSet {
	return Collections_CheckedSortedSet_SortedSet_Class__SortedSet(t.F_ss.HeadSet_O__SortedSet(toElement), t.F_type)
}
func (t *Collections_CheckedSortedSet) Impl_TailSet_O__SortedSet(this Collections_CheckedSortedSet_I, fromElement any) SortedSet {
	return Collections_CheckedSortedSet_SortedSet_Class__SortedSet(t.F_ss.TailSet_O__SortedSet(fromElement), t.F_type)
}
func Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(s NavigableSet, type_ *Class) NavigableSet { Collections_Init()

	return Collections_CheckedNavigableSet_New_NavigableSet_Class(s, type_)
}









func Collections_CheckedNavigableSet_New_NavigableSet_Class(p0 NavigableSet, p1 *Class) *Collections_CheckedNavigableSet { t := &Collections_CheckedNavigableSet{}; t.Ctor_NavigableSet_Class(p0, p1); return t }
//line :1930:1
func (t *Collections_CheckedNavigableSet) Ctor_NavigableSet_Class(s NavigableSet, type_ *Class) { t.Collections_CheckedSortedSet.Ctor_SortedSet_Class(t, s, type_)

	t.F_ns = s
}
func (t *Collections_CheckedNavigableSet) Lower_O__O(e any) any { return t.F_ns.Lower_O__O(e) }

func (t *Collections_CheckedNavigableSet) Floor_O__O(e any) any { return t.F_ns.Floor_O__O(e) }

func (t *Collections_CheckedNavigableSet) Ceiling_O__O(e any) any { return t.F_ns.Ceiling_O__O(e) }

func (t *Collections_CheckedNavigableSet) Higher_O__O(e any) any { return t.F_ns.Higher_O__O(e) }

func (t *Collections_CheckedNavigableSet) PollFirst__O() any { return t.F_ns.PollFirst__O() }

func (t *Collections_CheckedNavigableSet) PollLast__O() any { return t.F_ns.PollLast__O() }

func (t *Collections_CheckedNavigableSet) DescendingSet__NavigableSet() NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.DescendingSet__NavigableSet(), t.F_type)
}
func (t *Collections_CheckedNavigableSet) DescendingIterator__Iterator() Iterator {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.DescendingSet__NavigableSet(), t.F_type).Iterator__Iterator()
}
func (t *Collections_CheckedNavigableSet) SubSet_O_O__NavigableSet(fromElement, toElement any) NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.SubSet_O_Z_O_Z__NavigableSet(fromElement, true, toElement, false), t.F_type)
}
func (t *Collections_CheckedNavigableSet) HeadSet_O__NavigableSet(toElement any) NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.HeadSet_O_Z__NavigableSet(toElement, false), t.F_type)
}
func (t *Collections_CheckedNavigableSet) TailSet_O__NavigableSet(fromElement any) NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.TailSet_O_Z__NavigableSet(fromElement, true), t.F_type)
}
func (t *Collections_CheckedNavigableSet) SubSet_O_Z_O_Z__NavigableSet(fromElement any, fromInclusive bool, toElement any, toInclusive bool) NavigableSet {

	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.SubSet_O_Z_O_Z__NavigableSet(fromElement, fromInclusive, toElement, toInclusive), t.F_type)
}

func (t *Collections_CheckedNavigableSet) HeadSet_O_Z__NavigableSet(toElement any, inclusive bool) NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.HeadSet_O_Z__NavigableSet(toElement, inclusive), t.F_type)
}
func (t *Collections_CheckedNavigableSet) TailSet_O_Z__NavigableSet(fromElement any, inclusive bool) NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_ns.TailSet_O_Z__NavigableSet(fromElement, inclusive), t.F_type)
}
func Collections_CheckedList_List_Class__List(list List, type_ *Class) List { Collections_Init()

	if RandomAccess_InstanceOf(list) {
		return Collections_CheckedRandomAccessList_New_List_Class(list, type_) } else {
			return Collections_CheckedList_New_List_Class(list, type_)
		}
}








func Collections_CheckedList_New_List_Class(p0 List, p1 *Class) *Collections_CheckedList { t := &Collections_CheckedList{}; t.Ctor_List_Class(t, p0, p1); return t }
//line :1987:1
func (t *Collections_CheckedList) Ctor_List_Class(this Collections_CheckedList_I, list List, type_ *Class) { t.Collections_CheckedCollection.Ctor_Collection_Class(this, list, type_)

	t.F_list = list
}
func (t *Collections_CheckedList) Impl_Equals_O__Z(this Collections_CheckedList_I, o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(this); if !tmp1 { tmp1 = t.F_list.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_CheckedList) Impl_HashCode__I(this Collections_CheckedList_I) int32 { return t.F_list.HashCode__I() }

func (t *Collections_CheckedList) Impl_Get_I__O(this Collections_CheckedList_I, index int32) any { return t.F_list.Get_I__O(index) }

func (t *Collections_CheckedList) Impl_Remove_I__O(this Collections_CheckedList_I, index int32) any { return t.F_list.Remove_I__O(index) }

func (t *Collections_CheckedList) Impl_IndexOf_O__I(this Collections_CheckedList_I, o any) int32 { return t.F_list.IndexOf_O__I(o) }

func (t *Collections_CheckedList) Impl_LastIndexOf_O__I(this Collections_CheckedList_I, o any) int32 { return t.F_list.LastIndexOf_O__I(o) }

func (t *Collections_CheckedList) Impl_Set_I_O__O(this Collections_CheckedList_I, index int32, element any) any {
	var tmp1 List = t.F_list; return tmp1.Set_I_O__O(index, this.TypeCheck_O__O(element))
}
func (t *Collections_CheckedList) Impl_Add_I_O__V(this Collections_CheckedList_I, index int32, element any) {
	var tmp1 List = t.F_list; tmp1.Add_I_O__V(index, this.TypeCheck_O__O(element))
}
func (t *Collections_CheckedList) Impl_AddAll_I_Collection__Z(this Collections_CheckedList_I, index int32, c Collection) bool {
	var tmp1 List = t.F_list; return tmp1.AddAll_I_Collection__Z(index, this.CheckedCopyOf_Collection__Collection(c))
}
func (t *Collections_CheckedList) Impl_ListIterator__ListIterator(this Collections_CheckedList_I) ListIterator {
	return this.ListIterator_I__ListIterator(0)
}
func (t *Collections_CheckedList) Impl_ListIterator_I__ListIterator(this Collections_CheckedList_I, index int32) ListIterator {
	var i ListIterator = t.F_list.ListIterator_I__ListIterator(index)
	return Collections_CheckedList_1_New_Collections_CheckedList_ListIterator(this, i) }
func (t *Collections_CheckedList_1) HasNext__Z() bool { return t.F_val_i.HasNext__Z() }

func (t *Collections_CheckedList_1) Next__O() any { return t.F_val_i.Next__O() }

func (t *Collections_CheckedList_1) HasPrevious__Z() bool { return t.F_val_i.HasPrevious__Z() }

func (t *Collections_CheckedList_1) Previous__O() any { return t.F_val_i.Previous__O() }

func (t *Collections_CheckedList_1) NextIndex__I() int32 { return t.F_val_i.NextIndex__I() }

func (t *Collections_CheckedList_1) PreviousIndex__I() int32 { return t.F_val_i.PreviousIndex__I() }

func (t *Collections_CheckedList_1) Remove__V() { t.F_val_i.Remove__V() }

func (t *Collections_CheckedList_1) Set_O__V(e any) {
	t.F_val_i.Set_O__V(t.F_this_0.TypeCheck_O__O(e))
}
func (t *Collections_CheckedList_1) Add_O__V(e any) {
	t.F_val_i.Add_O__V(t.F_this_0.TypeCheck_O__O(e))
}
func (t *Collections_CheckedList_1) ForEachRemaining_Consumer__V(action Consumer) {
	t.F_val_i.ForEachRemaining_Consumer__V(action)
}
func (t *Collections_CheckedList) Impl_SubList_I_I__List(this Collections_CheckedList_I, fromIndex, toIndex int32) List {
	return Collections_CheckedList_New_List_Class(t.F_list.SubList_I_I__List(fromIndex, toIndex), t.F_type)
}
func (t *Collections_CheckedList) Impl_ReplaceAll_UnaryOperator__V(this Collections_CheckedList_I, operator UnaryOperator) {
	Objects_RequireNonNull_O__O(operator)
	var tmp1 List = t.F_list; tmp1.ReplaceAll_UnaryOperator__V(&UnaryOperator_Fn{Fn: func(p0 any) any { var e any = p0; return this.TypeCheck_O__O(operator.Apply_O__O(e)) }})
}
func (t *Collections_CheckedList) Impl_Sort_Comparator__V(this Collections_CheckedList_I, c Comparator) {
	t.F_list.Sort_Comparator__V(c)
}







func Collections_CheckedRandomAccessList_New_List_Class(p0 List, p1 *Class) *Collections_CheckedRandomAccessList { t := &Collections_CheckedRandomAccessList{}; t.Ctor_List_Class(p0, p1); return t }
//line :2059:1
func (t *Collections_CheckedRandomAccessList) Ctor_List_Class(list List, type_ *Class) { t.Collections_CheckedList.Ctor_List_Class(t, list, type_) }


func (t *Collections_CheckedRandomAccessList) SubList_I_I__List(fromIndex, toIndex int32) List {
	return Collections_CheckedRandomAccessList_New_List_Class(t.F_list.SubList_I_I__List(fromIndex, toIndex), t.F_type)
}
func Collections_CheckedMap_Map_Class_Class__Map(m Map, keyType, valueType *Class) Map { Collections_Init()


	return Collections_CheckedMap_New_Map_Class_Class(m, keyType, valueType)
}












func (t *Collections_CheckedMap) Impl_TypeCheck_O_O__V(this Collections_CheckedMap_I, key, value any) {
	var tmp1 bool; var tmp2 bool; tmp2 = !(key == nil); if tmp2 { tmp2 = !NN(t.F_keyType).IsInstance_O__Z(key) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(ClassCastException_New_String(t.Impl_BadKeyMsg_O__String(this, key)))) }
	var tmp3 bool; var tmp4 bool; tmp4 = !(value == nil); if tmp4 { tmp4 = !NN(t.F_valueType).IsInstance_O__Z(value) }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(ClassCastException_New_String(t.Impl_BadValueMsg_O__String(this, value))))
	} }
func (t *Collections_CheckedMap) Impl_TypeCheck_BiFunction__BiFunction(this Collections_CheckedMap_I, func_ BiFunction) BiFunction {

	Objects_RequireNonNull_O__O(func_)
	return &BiFunction_Fn{Fn: func(p0, p1 any) any { var k any = p0; var v any = p1; var tmp1 any; var newValue any = func_.Apply_O_O__O(k, v);
		t.Impl_TypeCheck_O_O__V(this, k, newValue); tmp1 = newValue; return tmp1 },
	} }
func (t *Collections_CheckedMap) Impl_BadKeyMsg_O__String(this Collections_CheckedMap_I, key any) *String {
	return Concat(Lit_2636, StrOfObj(GetClass(key).Ref()), Lit_2638, StrOfObj(t.F_keyType.Ref()))
}
func (t *Collections_CheckedMap) Impl_BadValueMsg_O__String(this Collections_CheckedMap_I, value any) *String {
	return Concat(Lit_2636, StrOfObj(GetClass(value).Ref()), Lit_2639, StrOfObj(t.F_valueType.Ref()))
}
func Collections_CheckedMap_New_Map_Class_Class(p0 Map, p1, p2 *Class) *Collections_CheckedMap { t := &Collections_CheckedMap{}; t.Ctor_Map_Class_Class(t, p0, p1, p2); return t }
//line :2100:1
func (t *Collections_CheckedMap) Ctor_Map_Class_Class(this Collections_CheckedMap_I, m Map, keyType, valueType *Class) {
	t.F_m = Map_Cast(Objects_RequireNonNull_O__O(m))
	t.F_keyType = Class_Cast(Objects_RequireNonNull_O__O(keyType.Ref()))
	t.F_valueType = Class_Cast(Objects_RequireNonNull_O__O(valueType.Ref()))
}
func (t *Collections_CheckedMap) Impl_Size__I(this Collections_CheckedMap_I) int32 { return t.F_m.Size__I() }

func (t *Collections_CheckedMap) Impl_IsEmpty__Z(this Collections_CheckedMap_I) bool { return t.F_m.IsEmpty__Z() }

func (t *Collections_CheckedMap) Impl_ContainsKey_O__Z(this Collections_CheckedMap_I, key any) bool { return t.F_m.ContainsKey_O__Z(key) }

func (t *Collections_CheckedMap) Impl_ContainsValue_O__Z(this Collections_CheckedMap_I, v any) bool { return t.F_m.ContainsValue_O__Z(v) }

func (t *Collections_CheckedMap) Impl_Get_O__O(this Collections_CheckedMap_I, key any) any { return t.F_m.Get_O__O(key) }

func (t *Collections_CheckedMap) Impl_Remove_O__O(this Collections_CheckedMap_I, key any) any { return t.F_m.Remove_O__O(key) }

func (t *Collections_CheckedMap) Impl_Clear__V(this Collections_CheckedMap_I) { t.F_m.Clear__V() }

func (t *Collections_CheckedMap) Impl_KeySet__Set(this Collections_CheckedMap_I) Set { return t.F_m.KeySet__Set() }

func (t *Collections_CheckedMap) Impl_Values__Collection(this Collections_CheckedMap_I) Collection { return t.F_m.Values__Collection() }

func (t *Collections_CheckedMap) Impl_Equals_O__Z(this Collections_CheckedMap_I, o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(this); if !tmp1 { tmp1 = t.F_m.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_CheckedMap) Impl_HashCode__I(this Collections_CheckedMap_I) int32 { return t.F_m.HashCode__I() }

func (t *Collections_CheckedMap) Impl_ToString__String(this Collections_CheckedMap_I) *String { return t.F_m.ToString__String() }

func (t *Collections_CheckedMap) Impl_Put_O_O__O(this Collections_CheckedMap_I, key, value any) any {
	t.Impl_TypeCheck_O_O__V(this, key, value)
	return t.F_m.Put_O_O__O(key, value)
}
func (t *Collections_CheckedMap) Impl_PutAll_Map__V(this Collections_CheckedMap_I, t_ Map) {
	var entries *RefArray = t_.EntrySet__Set().ToArray__O1(); var checked List = ArrayList_New_I(int32(len(entries.A))); var arr_101772 *RefArray = entries; var len_101773 int32 = int32(len(arr_101772.A)); var i_101774 int32 = 0; for ; i_101774 < len_101773; i_101774++ {

		var o any = arr_101772.A[i_101774]; var e Map_Entry = Map_Entry_Cast(o); var k any = e.GetKey__O(); var v any = e.GetValue__O()



		t.Impl_TypeCheck_O_O__V(this, k, v)
		checked.Add_O__Z(AbstractMap_SimpleImmutableEntry_New_O_O(k, v)) }
	var i_101775 Iterator = checked.Iterator__Iterator(); for i_101775.HasNext__Z() { var e_2 Map_Entry = Map_Entry_Cast(i_101775.Next__O()); var tmp1 Map = t.F_m; tmp1.Put_O_O__O(e_2.GetKey__O(), e_2.GetValue__O())
	}
}

func (t *Collections_CheckedMap) Impl_EntrySet__Set(this Collections_CheckedMap_I) Set {
	if t.F_entrySet == nil { t.F_entrySet = Collections_CheckedMap_CheckedEntrySet_New_Set_Class(t.F_m.EntrySet__Set(), t.F_valueType) }
//line :2147:1
	return t.F_entrySet
}


func (t *Collections_CheckedMap) Impl_ForEach_BiConsumer__V(this Collections_CheckedMap_I, action BiConsumer) {
	t.F_m.ForEach_BiConsumer__V(action)
}
func (t *Collections_CheckedMap) Impl_ReplaceAll_BiFunction__V(this Collections_CheckedMap_I, function BiFunction) {

	var tmp1 Map = t.F_m; tmp1.ReplaceAll_BiFunction__V(t.Impl_TypeCheck_BiFunction__BiFunction(this, function))
}
func (t *Collections_CheckedMap) Impl_PutIfAbsent_O_O__O(this Collections_CheckedMap_I, key, value any) any {
	t.Impl_TypeCheck_O_O__V(this, key, value)
	return t.F_m.PutIfAbsent_O_O__O(key, value)
}
func (t *Collections_CheckedMap) Impl_Remove_O_O__Z(this Collections_CheckedMap_I, key, value any) bool { return t.F_m.Remove_O_O__Z(key, value) }

func (t *Collections_CheckedMap) Impl_Replace_O_O_O__Z(this Collections_CheckedMap_I, key, oldValue, newValue any) bool {
	t.Impl_TypeCheck_O_O__V(this, key, newValue)
	return t.F_m.Replace_O_O_O__Z(key, oldValue, newValue)
}
func (t *Collections_CheckedMap) Impl_Replace_O_O__O(this Collections_CheckedMap_I, key, value any) any {
	t.Impl_TypeCheck_O_O__V(this, key, value)
	return t.F_m.Replace_O_O__O(key, value)
}
func (t *Collections_CheckedMap) Impl_ComputeIfAbsent_O_Function__O(this Collections_CheckedMap_I, key any, mappingFunction Function) any {

	Objects_RequireNonNull_O__O(mappingFunction)
	var tmp1 Map = t.F_m; return tmp1.ComputeIfAbsent_O_Function__O(key, &Function_Fn{Fn: func(p0 any) any { var k any = p0; var tmp2 any; var value any = mappingFunction.Apply_O__O(k);



		t.Impl_TypeCheck_O_O__V(this, k, value); tmp2 = value; return tmp2 },
	},
	) }
func (t *Collections_CheckedMap) Impl_ComputeIfPresent_O_BiFunction__O(this Collections_CheckedMap_I, key any, remappingFunction BiFunction) any {

	var tmp1 Map = t.F_m; return tmp1.ComputeIfPresent_O_BiFunction__O(key, t.Impl_TypeCheck_BiFunction__BiFunction(this, remappingFunction))
}
func (t *Collections_CheckedMap) Impl_Compute_O_BiFunction__O(this Collections_CheckedMap_I, key any, remappingFunction BiFunction) any {

	var tmp1 Map = t.F_m; return tmp1.Compute_O_BiFunction__O(key, t.Impl_TypeCheck_BiFunction__BiFunction(this, remappingFunction))
}
func (t *Collections_CheckedMap) Impl_Merge_O_O_BiFunction__O(this Collections_CheckedMap_I, key, value any, remappingFunction BiFunction) any {

	Objects_RequireNonNull_O__O(remappingFunction)
	t.Impl_TypeCheck_O_O__V(this, key, value)
	var tmp1 Map = t.F_m; return tmp1.Merge_O_O_BiFunction__O(key, value, &BiFunction_Fn{Fn: func(p0, p1 any) any { var v1 any = p0; var v2 any = p1; var tmp2 any; var newValue any = remappingFunction.Apply_O_O__O(v1, v2);




		t.Impl_TypeCheck_O_O__V(this, nil, newValue); tmp2 = newValue; return tmp2 },
	},
	)
}







func Collections_CheckedMap_CheckedEntrySet_New_Set_Class(p0 Set, p1 *Class) *Collections_CheckedMap_CheckedEntrySet { t := &Collections_CheckedMap_CheckedEntrySet{}; t.Ctor_Set_Class(p0, p1); return t }
//line :2210:1
func (t *Collections_CheckedMap_CheckedEntrySet) Ctor_Set_Class(s Set, valueType *Class) {
	t.F_s = s
	t.F_valueType = valueType
}
func (t *Collections_CheckedMap_CheckedEntrySet) Size__I() int32 { return t.F_s.Size__I() }

func (t *Collections_CheckedMap_CheckedEntrySet) IsEmpty__Z() bool { return t.F_s.IsEmpty__Z() }

func (t *Collections_CheckedMap_CheckedEntrySet) ToString__String() *String { return t.F_s.ToString__String() }

func (t *Collections_CheckedMap_CheckedEntrySet) HashCode__I() int32 { return t.F_s.HashCode__I() }

func (t *Collections_CheckedMap_CheckedEntrySet) Clear__V() { t.F_s.Clear__V() }

func (t *Collections_CheckedMap_CheckedEntrySet) Add_Map_Entry__Z(e Map_Entry) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_CheckedMap_CheckedEntrySet) AddAll_Collection__Z(coll Collection) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_CheckedMap_CheckedEntrySet) Iterator__Iterator() Iterator {
	var i Iterator = t.F_s.Iterator__Iterator()
	return Collections_CheckedMap_CheckedEntrySet_1_New_Collections_CheckedMap_CheckedEntrySet_Iterator(t, i) }
func (t *Collections_CheckedMap_CheckedEntrySet_1) HasNext__Z() bool { return t.F_val_i.HasNext__Z() }

func (t *Collections_CheckedMap_CheckedEntrySet_1) Remove__V() { t.F_val_i.Remove__V() }

func (t *Collections_CheckedMap_CheckedEntrySet_1) Next__Map_Entry() Map_Entry {
	return Up_Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry(Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry_Class__Collections_CheckedMap_CheckedEntrySet_CheckedEntry(Map_Entry_Cast(t.F_val_i.Next__O()), t.F_this_0.F_valueType))
}
func (t *Collections_CheckedMap_CheckedEntrySet_1) ForEachRemaining_Consumer__V(action Consumer) {

	Objects_RequireNonNull_O__O(action)
	t.F_val_i.ForEachRemaining_Consumer__V(&Consumer_Fn{Fn: func(p0 any) { var e Map_Entry = Map_Entry_Cast(p0);

		action.Accept_O__V(Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry_Class__Collections_CheckedMap_CheckedEntrySet_CheckedEntry(e, t.F_this_0.F_valueType).Ref()) },
	}) }
func (t *Collections_CheckedMap_CheckedEntrySet) ToArray__O1() *RefArray {
	var source *RefArray = t.F_s.ToArray__O1(); var dest *RefArray
	if GetClass(source.Ref()) == Object_class.ArrayClass() { dest = source } else {

		dest = NewRefArray(Object_class, int32(len(source.A))) }
	var i int32 = 0; L1: for {
		if i < int32(len(source.A)) {
			dest.Store(i, Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry_Class__Collections_CheckedMap_CheckedEntrySet_CheckedEntry(Map_Entry_Cast(source.A[i]), t.F_valueType).Ref())


			i = i + 1; continue L1 }
//line :2252:1
		break L1 }
//line :2248:1
	return dest
}










func (t *Collections_CheckedMap_CheckedEntrySet) ToArray_O1__O1(a *RefArray) *RefArray {
	var arr *RefArray; var tmp1 Set = t.F_s; var tmp2 *RefArray; if int32(len(a.A)) == 0 { tmp2 = a } else { tmp2 = Arrays_CopyOf_O1_I__O1(a, 0) }; arr = tmp1.ToArray_O1__O1(tmp2)
	var i int32 = 0; L1: for {
		if i < int32(len(arr.A)) {
			arr.Store(i, Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry_Class__Collections_CheckedMap_CheckedEntrySet_CheckedEntry(Map_Entry_Cast(arr.A[i]), t.F_valueType).Ref())


			i = i + 1; continue L1 }
//line :2262:1
		break L1
	}




	var tmp3 int32 = int32(len(arr.A)); if tmp3 > int32(len(a.A)) { return arr } else {


		System_Arraycopy_O_I_O_I_I__V(arr.Ref(), 0, a.Ref(), 0, int32(len(arr.A)))
		var tmp4 int32 = int32(len(a.A)); if tmp4 > int32(len(arr.A)) { a.Store(int32(len(arr.A)), nil) }
//line :2270:1
		return a
	}
}


func (t *Collections_CheckedMap_CheckedEntrySet) Contains_O__Z(o any) bool {
	var tmp1 any = o; if Map_Entry_InstanceOf(tmp1) { var e Map_Entry = Map_Entry_Cast(tmp1); var tmp2 Set = t.F_s; var tmp3 any

		if Collections_CheckedMap_CheckedEntrySet_CheckedEntry_InstanceOf(e) { tmp3 = e } else {

			tmp3 = Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry_Class__Collections_CheckedMap_CheckedEntrySet_CheckedEntry(e, t.F_valueType).Ref() }
//line :2277:1
		return tmp2.Contains_O__Z(tmp3)

	} else {
//line :2276:1
		return false
	}
}




func (t *Collections_CheckedMap_CheckedEntrySet) ContainsAll_Collection__Z(c Collection) bool {
	var i_101777 Iterator = c.Iterator__Iterator(); for i_101777.HasNext__Z() { var o any = i_101777.Next__O(); if t.Contains_O__Z(o) { } else { return false } }
//line :2283:1
	return true
}


func (t *Collections_CheckedMap_CheckedEntrySet) Remove_O__Z(o any) bool {
	if !Map_Entry_InstanceOf(o) { return false } else {

		var tmp1 Set = t.F_s; return tmp1.Remove_O__Z(AbstractMap_SimpleImmutableEntry_New_Map_Entry(Map_Entry_Cast(o)))
	} }
func (t *Collections_CheckedMap_CheckedEntrySet) RemoveAll_Collection__Z(c Collection) bool {
	return t.BatchRemove_Collection_Z__Z(c, false)
}
func (t *Collections_CheckedMap_CheckedEntrySet) RetainAll_Collection__Z(c Collection) bool {
	return t.BatchRemove_Collection_Z__Z(c, true)
}
func (t *Collections_CheckedMap_CheckedEntrySet) BatchRemove_Collection_Z__Z(c Collection, complement bool) bool {
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var it Iterator = t.Iterator__Iterator()

L1: for { if it.HasNext__Z() {
	if c.Contains_O__Z(it.Next__O()) == complement { } else { it.Remove__V(); modified = true }
//line :2302:1
	continue L1 }; break L1 }
//line :2300:1
	return modified
}




func (t *Collections_CheckedMap_CheckedEntrySet) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else {

		var tmp1 any = o; if Set_InstanceOf(tmp1) { var that Set = Set_Cast(tmp1)
			if that.Size__I() == t.F_s.Size__I() { return t.ContainsAll_Collection__Z(that) } else { return false } } else {
//line :2309:1
				return false
			}
	}
}
func Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Map_Entry_Class__Collections_CheckedMap_CheckedEntrySet_CheckedEntry(e Map_Entry, valueType *Class) *Collections_CheckedMap_CheckedEntrySet_CheckedEntry {

	return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(e, valueType)
}








func Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(p0 Map_Entry, p1 *Class) *Collections_CheckedMap_CheckedEntrySet_CheckedEntry { t := &Collections_CheckedMap_CheckedEntrySet_CheckedEntry{}; t.Ctor_Map_Entry_Class(p0, p1); return t }
//line :2325:1
func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) Ctor_Map_Entry_Class(e Map_Entry, valueType *Class) {
	t.F_e = Map_Entry_Cast(Objects_RequireNonNull_O__O(e))
	t.F_valueType = Class_Cast(Objects_RequireNonNull_O__O(valueType.Ref()))
}
func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) GetKey__O() any { return t.F_e.GetKey__O() }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) GetValue__O() any { return t.F_e.GetValue__O() }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) HashCode__I() int32 { return t.F_e.HashCode__I() }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) ToString__String() *String { return t.F_e.ToString__String() }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) SetValue_O__O(value any) any {
	var tmp1 bool; var tmp2 bool; tmp2 = !(value == nil); if tmp2 { tmp2 = !NN(t.F_valueType).IsInstance_O__Z(value) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(ClassCastException_New_String(t.BadValueMsg_O__String(value)))) }
	return t.F_e.SetValue_O__O(value)
}
func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) BadValueMsg_O__String(value any) *String {
	return Concat(Lit_2636, StrOfObj(GetClass(value).Ref()), Lit_2639, StrOfObj(t.F_valueType.Ref()))
}



func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else { if !Map_Entry_InstanceOf(o) { return false } else {


		var tmp1 Map_Entry = t.F_e; return tmp1.Equals_O__Z(AbstractMap_SimpleImmutableEntry_New_Map_Entry(Map_Entry_Cast(o)))
	} } }
func Collections_CheckedSortedMap_SortedMap_Class_Class__SortedMap(m SortedMap, keyType, valueType *Class) SortedMap { Collections_Init()


	return Collections_CheckedSortedMap_New_SortedMap_Class_Class(m, keyType, valueType)
}









func Collections_CheckedSortedMap_New_SortedMap_Class_Class(p0 SortedMap, p1, p2 *Class) *Collections_CheckedSortedMap { t := &Collections_CheckedSortedMap{}; t.Ctor_SortedMap_Class_Class(t, p0, p1, p2); return t }
//line :2368:1
func (t *Collections_CheckedSortedMap) Ctor_SortedMap_Class_Class(this Collections_CheckedSortedMap_I, m SortedMap, keyType, valueType *Class) { t.Collections_CheckedMap.Ctor_Map_Class_Class(this, m, keyType, valueType)


	t.F_sm = m
}
func (t *Collections_CheckedSortedMap) Impl_Comparator__Comparator(this Collections_CheckedSortedMap_I) Comparator {
	return t.F_sm.Comparator__Comparator()
}
func (t *Collections_CheckedSortedMap) Impl_FirstKey__O(this Collections_CheckedSortedMap_I) any { return t.F_sm.FirstKey__O() }

func (t *Collections_CheckedSortedMap) Impl_LastKey__O(this Collections_CheckedSortedMap_I) any { return t.F_sm.LastKey__O() }

func (t *Collections_CheckedSortedMap) Impl_SubMap_O_O__SortedMap(this Collections_CheckedSortedMap_I, fromKey, toKey any) SortedMap {
	return Collections_CheckedSortedMap_SortedMap_Class_Class__SortedMap(t.F_sm.SubMap_O_O__SortedMap(fromKey, toKey), t.F_keyType, t.F_valueType)
}
func (t *Collections_CheckedSortedMap) Impl_HeadMap_O__SortedMap(this Collections_CheckedSortedMap_I, toKey any) SortedMap {
	return Collections_CheckedSortedMap_SortedMap_Class_Class__SortedMap(t.F_sm.HeadMap_O__SortedMap(toKey), t.F_keyType, t.F_valueType)
}
func (t *Collections_CheckedSortedMap) Impl_TailMap_O__SortedMap(this Collections_CheckedSortedMap_I, fromKey any) SortedMap {
	return Collections_CheckedSortedMap_SortedMap_Class_Class__SortedMap(t.F_sm.TailMap_O__SortedMap(fromKey), t.F_keyType, t.F_valueType)
}
func Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(m NavigableMap, keyType, valueType *Class) NavigableMap { Collections_Init()


	return Collections_CheckedNavigableMap_New_NavigableMap_Class_Class(m, keyType, valueType)
}









func Collections_CheckedNavigableMap_New_NavigableMap_Class_Class(p0 NavigableMap, p1, p2 *Class) *Collections_CheckedNavigableMap { t := &Collections_CheckedNavigableMap{}; t.Ctor_NavigableMap_Class_Class(p0, p1, p2); return t }
//line :2403:1
func (t *Collections_CheckedNavigableMap) Ctor_NavigableMap_Class_Class(m NavigableMap, keyType, valueType *Class) { t.Collections_CheckedSortedMap.Ctor_SortedMap_Class_Class(t, m, keyType, valueType)


	t.F_nm = m
}
func (t *Collections_CheckedNavigableMap) Comparator__Comparator() Comparator {
	return t.F_nm.Comparator__Comparator()
}
func (t *Collections_CheckedNavigableMap) FirstKey__O() any { return t.F_nm.FirstKey__O() }

func (t *Collections_CheckedNavigableMap) LastKey__O() any { return t.F_nm.LastKey__O() }

func (t *Collections_CheckedNavigableMap) LowerEntry_O__Map_Entry(key any) Map_Entry {
	var lower Map_Entry = t.F_nm.LowerEntry_O__Map_Entry(key)
	if !(lower == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(lower, t.F_valueType) } else {
//line :2417:1
			return nil
		}
}
func (t *Collections_CheckedNavigableMap) LowerKey_O__O(key any) any { return t.F_nm.LowerKey_O__O(key) }

func (t *Collections_CheckedNavigableMap) FloorEntry_O__Map_Entry(key any) Map_Entry {
	var floor Map_Entry = t.F_nm.FloorEntry_O__Map_Entry(key)
	if !(floor == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(floor, t.F_valueType) } else {
//line :2424:1
			return nil
		}
}
func (t *Collections_CheckedNavigableMap) FloorKey_O__O(key any) any { return t.F_nm.FloorKey_O__O(key) }

func (t *Collections_CheckedNavigableMap) CeilingEntry_O__Map_Entry(key any) Map_Entry {
	var ceiling Map_Entry = t.F_nm.CeilingEntry_O__Map_Entry(key)
	if !(ceiling == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(ceiling, t.F_valueType) } else {
//line :2431:1
			return nil
		}
}


func (t *Collections_CheckedNavigableMap) CeilingKey_O__O(key any) any { return t.F_nm.CeilingKey_O__O(key) }

func (t *Collections_CheckedNavigableMap) HigherEntry_O__Map_Entry(key any) Map_Entry {
	var higher Map_Entry = t.F_nm.HigherEntry_O__Map_Entry(key)
	if !(higher == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(higher, t.F_valueType) } else {
//line :2440:1
			return nil
		}
}


func (t *Collections_CheckedNavigableMap) HigherKey_O__O(key any) any { return t.F_nm.HigherKey_O__O(key) }

func (t *Collections_CheckedNavigableMap) FirstEntry__Map_Entry() Map_Entry {
	var first Map_Entry = t.F_nm.FirstEntry__Map_Entry()
	if !(first == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(first, t.F_valueType) } else {
//line :2449:1
			return nil
		}
}
func (t *Collections_CheckedNavigableMap) LastEntry__Map_Entry() Map_Entry {
	var last Map_Entry = t.F_nm.LastEntry__Map_Entry()
	if !(last == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(last, t.F_valueType) } else {
//line :2454:1
			return nil
		}
}
func (t *Collections_CheckedNavigableMap) PollFirstEntry__Map_Entry() Map_Entry {
	var entry Map_Entry = t.F_nm.PollFirstEntry__Map_Entry()
	if !(entry == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(entry, t.F_valueType) } else {
//line :2459:1
			return nil
		}
}
func (t *Collections_CheckedNavigableMap) PollLastEntry__Map_Entry() Map_Entry {
	var entry Map_Entry = t.F_nm.PollLastEntry__Map_Entry()
	if !(entry == nil) {
		return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_New_Map_Entry_Class(entry, t.F_valueType) } else {
//line :2464:1
			return nil
		}
}
func (t *Collections_CheckedNavigableMap) DescendingMap__NavigableMap() NavigableMap {
	return Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(t.F_nm.DescendingMap__NavigableMap(), t.F_keyType, t.F_valueType)
}
func (t *Collections_CheckedNavigableMap) KeySet__NavigableSet() NavigableSet {
	return t.NavigableKeySet__NavigableSet()
}
func (t *Collections_CheckedNavigableMap) NavigableKeySet__NavigableSet() NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_nm.NavigableKeySet__NavigableSet(), t.F_keyType)
}
func (t *Collections_CheckedNavigableMap) DescendingKeySet__NavigableSet() NavigableSet {
	return Collections_CheckedNavigableSet_NavigableSet_Class__NavigableSet(t.F_nm.DescendingKeySet__NavigableSet(), t.F_keyType)
}
func (t *Collections_CheckedNavigableMap) SubMap_O_O__NavigableMap(fromKey, toKey any) NavigableMap {
	return Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(t.F_nm.SubMap_O_Z_O_Z__NavigableMap(fromKey, true, toKey, false), t.F_keyType, t.F_valueType)
}


func (t *Collections_CheckedNavigableMap) HeadMap_O__NavigableMap(toKey any) NavigableMap {
	return Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(t.F_nm.HeadMap_O_Z__NavigableMap(toKey, false), t.F_keyType, t.F_valueType)
}


func (t *Collections_CheckedNavigableMap) TailMap_O__NavigableMap(fromKey any) NavigableMap {
	return Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(t.F_nm.TailMap_O_Z__NavigableMap(fromKey, true), t.F_keyType, t.F_valueType)
}


func (t *Collections_CheckedNavigableMap) SubMap_O_Z_O_Z__NavigableMap(fromKey any, fromInclusive bool, toKey any, toInclusive bool) NavigableMap {

	return Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(t.F_nm.SubMap_O_Z_O_Z__NavigableMap(fromKey, fromInclusive, toKey, toInclusive), t.F_keyType, t.F_valueType)
}


func (t *Collections_CheckedNavigableMap) HeadMap_O_Z__NavigableMap(toKey any, inclusive bool) NavigableMap {
	return Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(t.F_nm.HeadMap_O_Z__NavigableMap(toKey, inclusive), t.F_keyType, t.F_valueType)
}


func (t *Collections_CheckedNavigableMap) TailMap_O_Z__NavigableMap(fromKey any, inclusive bool) NavigableMap {
	return Collections_CheckedNavigableMap_NavigableMap_Class_Class__NavigableMap(t.F_nm.TailMap_O_Z__NavigableMap(fromKey, inclusive), t.F_keyType, t.F_valueType)
}


func Collections_EmptyIterator__Iterator() Iterator { Collections_Init(); Collections_EmptyIterator_Init(); return Collections_EmptyIterator_EMPTY_ITERATOR }








func (t *Collections_EmptyIterator) Impl_HasNext__Z(this Collections_EmptyIterator_I) bool { return false }

func (t *Collections_EmptyIterator) Impl_Next__O(this Collections_EmptyIterator_I) any { panic(Thrown(NoSuchElementException_New())) }

func (t *Collections_EmptyIterator) Impl_Remove__V(this Collections_EmptyIterator_I) { panic(Thrown(IllegalStateException_New())) }

func (t *Collections_EmptyIterator) Impl_ForEachRemaining_Consumer__V(this Collections_EmptyIterator_I, action Consumer) {
	Objects_RequireNonNull_O__O(action)
}
func Collections_EmptyListIterator__ListIterator() ListIterator { Collections_Init(); Collections_EmptyListIterator_Init(); return Up_Collections_EmptyListIterator_ListIterator(Collections_EmptyListIterator_EMPTY_ITERATOR) }









func (t *Collections_EmptyListIterator) HasPrevious__Z() bool { return false }

func (t *Collections_EmptyListIterator) Previous__O() any { panic(Thrown(NoSuchElementException_New())) }

func (t *Collections_EmptyListIterator) NextIndex__I() int32 { return 0 }

func (t *Collections_EmptyListIterator) PreviousIndex__I() int32 { return -1 }

func (t *Collections_EmptyListIterator) Set_O__V(e any) { panic(Thrown(IllegalStateException_New())) }

func (t *Collections_EmptyListIterator) Add_O__V(e any) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func Collections_EmptyEnumeration__Enumeration() Enumeration { Collections_Init(); Collections_EmptyEnumeration_Init(); return Up_Collections_EmptyEnumeration_Enumeration(Collections_EmptyEnumeration_EMPTY_ENUMERATION) }








func (t *Collections_EmptyEnumeration) HasMoreElements__Z() bool { return false }

func (t *Collections_EmptyEnumeration) NextElement__O() any {
	panic(Thrown(NoSuchElementException_New()))
}
func (t *Collections_EmptyEnumeration) AsIterator__Iterator() Iterator {
	return Collections_EmptyIterator__Iterator()
}


func Collections_EmptySet__Set() Set { Collections_Init(); return Collections_EMPTY_SET }









func (t *Collections_EmptySet) Iterator__Iterator() Iterator {
	return Collections_EmptyIterator__Iterator()
}
func (t *Collections_EmptySet) Size__I() int32 { return 0 }

func (t *Collections_EmptySet) IsEmpty__Z() bool { return true }

func (t *Collections_EmptySet) Clear__V() {}

func (t *Collections_EmptySet) Contains_O__Z(obj any) bool { return false }

func (t *Collections_EmptySet) ContainsAll_Collection__Z(c Collection) bool {
	return c.IsEmpty__Z()
}
func (t *Collections_EmptySet) ToArray__O1() *RefArray { return NewRefArray(Object_class, 0) }

func (t *Collections_EmptySet) ToArray_O1__O1(a *RefArray) *RefArray {
	if int32(len(a.A)) > 0 { a.Store(0, nil) }
//line :2596:1
	return a
}


func (t *Collections_EmptySet) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
}
func (t *Collections_EmptySet) RemoveIf_Predicate__Z(filter Predicate) bool {
	Objects_RequireNonNull_O__O(filter)
//line :2603:1
	return false
}


func (t *Collections_EmptySet) Spliterator__Spliterator() Spliterator {
	return Spliterators_EmptySpliterator__Spliterator()
}
func (t *Collections_EmptySet) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Collections$EmptySet.readResolve()Ljava/lang/Object;")) }

func (t *Collections_EmptySet) HashCode__I() int32 { return 0 }

func Collections_EmptySortedSet__SortedSet() SortedSet { Collections_Init(); Collections_UnmodifiableNavigableSet_Init(); return Collections_UnmodifiableNavigableSet_EMPTY_NAVIGABLE_SET }


func Collections_EmptyNavigableSet__NavigableSet() NavigableSet { Collections_Init(); Collections_UnmodifiableNavigableSet_Init(); return Collections_UnmodifiableNavigableSet_EMPTY_NAVIGABLE_SET }




func Collections_EmptyList__List() List { Collections_Init(); return Collections_EMPTY_LIST }









func (t *Collections_EmptyList) Iterator__Iterator() Iterator {
	return Collections_EmptyIterator__Iterator()
}
func (t *Collections_EmptyList) ListIterator__ListIterator() ListIterator {
	return Collections_EmptyListIterator__ListIterator()
}
func (t *Collections_EmptyList) Size__I() int32 { return 0 }

func (t *Collections_EmptyList) IsEmpty__Z() bool { return true }

func (t *Collections_EmptyList) Clear__V() {}

func (t *Collections_EmptyList) Contains_O__Z(obj any) bool { return false }

func (t *Collections_EmptyList) ContainsAll_Collection__Z(c Collection) bool {
	return c.IsEmpty__Z()
}
func (t *Collections_EmptyList) ToArray__O1() *RefArray { return NewRefArray(Object_class, 0) }

func (t *Collections_EmptyList) ToArray_O1__O1(a *RefArray) *RefArray {
	if int32(len(a.A)) > 0 { a.Store(0, nil) }
//line :2651:1
	return a
}


func (t *Collections_EmptyList) Get_I__O(index int32) any {
	panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index)))))
}
func (t *Collections_EmptyList) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = List_InstanceOf(o); if tmp1 { tmp1 = List_Cast(o).IsEmpty__Z() }; return tmp1
}
func (t *Collections_EmptyList) HashCode__I() int32 { return 1 }

func (t *Collections_EmptyList) RemoveIf_Predicate__Z(filter Predicate) bool {
	Objects_RequireNonNull_O__O(filter)
//line :2663:1
	return false
}


func (t *Collections_EmptyList) ReplaceAll_UnaryOperator__V(operator UnaryOperator) {
	Objects_RequireNonNull_O__O(operator)
}
func (t *Collections_EmptyList) Sort_Comparator__V(p0 Comparator) {}

func (t *Collections_EmptyList) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
}
func (t *Collections_EmptyList) Reversed__List() List { return t }

func (t *Collections_EmptyList) Spliterator__Spliterator() Spliterator {
	return Spliterators_EmptySpliterator__Spliterator()
}
func (t *Collections_EmptyList) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Collections$EmptyList.readResolve()Ljava/lang/Object;")) }



func Collections_EmptyMap__Map() Map { Collections_Init(); return Collections_EMPTY_MAP }


func Collections_EmptySortedMap__SortedMap() SortedMap { Collections_Init(); Collections_UnmodifiableNavigableMap_Init(); return Up_Collections_UnmodifiableNavigableMap_EmptyNavigableMap_SortedMap(Collections_UnmodifiableNavigableMap_EMPTY_NAVIGABLE_MAP) }


func Collections_EmptyNavigableMap__NavigableMap() NavigableMap { Collections_Init(); Collections_UnmodifiableNavigableMap_Init(); return Up_Collections_UnmodifiableNavigableMap_EmptyNavigableMap_NavigableMap(Collections_UnmodifiableNavigableMap_EMPTY_NAVIGABLE_MAP) }









func (t *Collections_EmptyMap) Size__I() int32 { return 0 }

func (t *Collections_EmptyMap) IsEmpty__Z() bool { return true }

func (t *Collections_EmptyMap) Clear__V() {}

func (t *Collections_EmptyMap) ContainsKey_O__Z(key any) bool { return false }

func (t *Collections_EmptyMap) ContainsValue_O__Z(value any) bool { return false }

func (t *Collections_EmptyMap) Get_O__O(key any) any { return nil }

func (t *Collections_EmptyMap) KeySet__Set() Set { return Collections_EmptySet__Set() }

func (t *Collections_EmptyMap) Values__Collection() Collection {
	return Collections_EmptySet__Set()
}
func (t *Collections_EmptyMap) EntrySet__Set() Set {
	return Collections_EmptySet__Set()
}
func (t *Collections_EmptyMap) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = Map_InstanceOf(o); if tmp1 { tmp1 = Map_Cast(o).IsEmpty__Z() }; return tmp1
}
func (t *Collections_EmptyMap) HashCode__I() int32 { return 0 }

func (t *Collections_EmptyMap) GetOrDefault_O_O__O(k, defaultValue any) any { return defaultValue }

func (t *Collections_EmptyMap) ForEach_BiConsumer__V(action BiConsumer) {
	Objects_RequireNonNull_O__O(action)
}
func (t *Collections_EmptyMap) ReplaceAll_BiFunction__V(function BiFunction) {

	Objects_RequireNonNull_O__O(function)
}
func (t *Collections_EmptyMap) PutIfAbsent_O_O__O(key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) Remove_O_O__Z(key, value any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) Replace_O_O_O__Z(key, oldValue, newValue any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) Replace_O_O__O(key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) ComputeIfAbsent_O_Function__O(key any, mappingFunction Function) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) ComputeIfPresent_O_BiFunction__O(key any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) Compute_O_BiFunction__O(key any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) Merge_O_O_BiFunction__O(key, value any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_EmptyMap) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Collections$EmptyMap.readResolve()Ljava/lang/Object;")) }

func Collections_Singleton_O__Set(o any) Set { Collections_Init()
	return Collections_SingletonSet_New_O(o)
}
func Collections_SingletonIterator_O__Iterator(e any) Iterator { Collections_Init()
	return Collections_1_New_O(e)
}

func (t *Collections_1) HasNext__Z() bool { return t.F_hasNext }

func (t *Collections_1) Next__O() any {
	if t.F_hasNext { t.F_hasNext = false; return t.F_val_e } else { panic(Thrown(NoSuchElementException_New()))
	} }
func (t *Collections_1) Remove__V() {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_1) ForEachRemaining_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	if t.F_hasNext { t.F_hasNext = false; action.Accept_O__V(t.F_val_e)
	} }
func Collections_SingletonSpliterator_O__Spliterator(element any) Spliterator { Collections_Init()
	return Collections_2_New_O(element)
}

func (t *Collections_2) TrySplit__Spliterator() Spliterator { return nil }

func (t *Collections_2) TryAdvance_Consumer__Z(consumer Consumer) bool {
	Objects_RequireNonNull_O__O(consumer)
	if t.F_est > 0 { t.F_est = t.F_est - 1; consumer.Accept_O__V(t.F_val_element); return true } else { return false
	} }
func (t *Collections_2) ForEachRemaining_Consumer__V(consumer Consumer) {
	t.TryAdvance_Consumer__Z(consumer)
}
func (t *Collections_2) EstimateSize__J() int64 { return t.F_est }

func (t *Collections_2) Characteristics__I() int32 {
	var value int32; if !(t.F_val_element == nil) { value = 256 } else { value = 0 }
	return value | 64 | 16384 | 1024 | 1 | 16
}














func Collections_SingletonSet_New_O(p0 any) *Collections_SingletonSet { t := &Collections_SingletonSet{}; t.Ctor_O(p0); return t }
//line :2816:1
func (t *Collections_SingletonSet) Ctor_O(e any) { t.AbstractSet.Ctor(t); t.F_element = e }

func (t *Collections_SingletonSet) Iterator__Iterator() Iterator {
	return Collections_SingletonIterator_O__Iterator(t.F_element)
}
func (t *Collections_SingletonSet) Size__I() int32 { return 1 }

func (t *Collections_SingletonSet) Contains_O__Z(o any) bool { return Collections_Eq_O_O__Z(o, t.F_element) }

func (t *Collections_SingletonSet) ForEach_Consumer__V(action Consumer) {
	action.Accept_O__V(t.F_element)
}
func (t *Collections_SingletonSet) Spliterator__Spliterator() Spliterator {
	return Collections_SingletonSpliterator_O__Spliterator(t.F_element)
}
func (t *Collections_SingletonSet) RemoveIf_Predicate__Z(filter Predicate) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonSet) HashCode__I() int32 { return Objects_HashCode_O__I(t.F_element) }

func (t *Collections_SingletonSet) ToArray__O1() *RefArray { return RefArrayOf(Object_class, t.F_element) }

func (t *Collections_SingletonSet) ToArray_O1__O1(a *RefArray) *RefArray {
	if int32(len(a.A)) < 1 {
		a = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), 1), Object_class.ArrayClass()) }
	a.Store(0, t.F_element)
	if int32(len(a.A)) > 1 { a.Store(1, nil) }
//line :2838:1
	return a
}





func Collections_SingletonList_O__List(o any) List { Collections_Init()
	return Collections_SingletonList_New_O(o)
}









func Collections_SingletonList_New_O(p0 any) *Collections_SingletonList { t := &Collections_SingletonList{}; t.Ctor_O(p0); return t }
//line :2857:1
func (t *Collections_SingletonList) Ctor_O(obj any) { t.AbstractList.Ctor(t); t.F_element = obj }

func (t *Collections_SingletonList) Iterator__Iterator() Iterator {
	return Collections_SingletonIterator_O__Iterator(t.F_element)
}
func (t *Collections_SingletonList) Size__I() int32 { return 1 }

func (t *Collections_SingletonList) Contains_O__Z(obj any) bool {
	return Collections_Eq_O_O__Z(obj, t.F_element)
}
func (t *Collections_SingletonList) Get_I__O(index int32) any {
	if index == 0 { } else {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index), Lit_2640)))) }
//line :2867:1
	return t.F_element
}



func (t *Collections_SingletonList) ForEach_Consumer__V(action Consumer) {
	action.Accept_O__V(t.F_element)
}
func (t *Collections_SingletonList) RemoveIf_Predicate__Z(filter Predicate) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonList) ReplaceAll_UnaryOperator__V(operator UnaryOperator) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonList) Sort_Comparator__V(p0 Comparator) {}

func (t *Collections_SingletonList) Reversed__List() List { return t }

func (t *Collections_SingletonList) GetFirst__O() any { return t.F_element }

func (t *Collections_SingletonList) GetLast__O() any { return t.F_element }

func (t *Collections_SingletonList) Spliterator__Spliterator() Spliterator {
	return Collections_SingletonSpliterator_O__Spliterator(t.F_element)
}
func (t *Collections_SingletonList) HashCode__I() int32 {
	return 31 + Objects_HashCode_O__I(t.F_element)
}
func Collections_SingletonMap_O_O__Map(key, value any) Map { Collections_Init()
	return Collections_SingletonMap_New_O_O(key, value)
}











func Collections_SingletonMap_New_O_O(p0, p1 any) *Collections_SingletonMap { t := &Collections_SingletonMap{}; t.Ctor_O_O(p0, p1); return t }
//line :2909:1
func (t *Collections_SingletonMap) Ctor_O_O(key, value any) { t.AbstractMap.Ctor(t); t.F_k = key; t.F_v = value }

func (t *Collections_SingletonMap) Size__I() int32 { return 1 }

func (t *Collections_SingletonMap) IsEmpty__Z() bool { return false }

func (t *Collections_SingletonMap) ContainsKey_O__Z(key any) bool { return Collections_Eq_O_O__Z(key, t.F_k) }

func (t *Collections_SingletonMap) ContainsValue_O__Z(value any) bool {
	return Collections_Eq_O_O__Z(value, t.F_v)
}
func (t *Collections_SingletonMap) Get_O__O(key any) any { if Collections_Eq_O_O__Z(key, t.F_k) { return t.F_v } else { return nil } }







func (t *Collections_SingletonMap) KeySet__Set() Set {
	if t.F_keySet == nil { t.F_keySet = Collections_Singleton_O__Set(t.F_k) }
//line :2928:1
	return t.F_keySet
}


func (t *Collections_SingletonMap) EntrySet__Set() Set {
	if t.F_entrySet == nil {
		t.F_entrySet = Collections_Singleton_O__Set(AbstractMap_SimpleImmutableEntry_New_O_O(t.F_k, t.F_v)) }
//line :2932:1
	return t.F_entrySet
}



func (t *Collections_SingletonMap) Values__Collection() Collection {
	if t.F_values == nil { t.F_values = Collections_Singleton_O__Set(t.F_v) }
//line :2937:1
	return t.F_values
}


func (t *Collections_SingletonMap) GetOrDefault_O_O__O(key, defaultValue any) any {
	if Collections_Eq_O_O__Z(key, t.F_k) { return t.F_v } else { return defaultValue
	} }
func (t *Collections_SingletonMap) ForEach_BiConsumer__V(action BiConsumer) {
	action.Accept_O_O__V(t.F_k, t.F_v)
}
func (t *Collections_SingletonMap) ReplaceAll_BiFunction__V(function BiFunction) {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) PutIfAbsent_O_O__O(key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) Remove_O_O__Z(key, value any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) Replace_O_O_O__Z(key, oldValue, newValue any) bool {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) Replace_O_O__O(key, value any) any {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) ComputeIfAbsent_O_Function__O(key any, mappingFunction Function) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) ComputeIfPresent_O_BiFunction__O(key any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) Compute_O_BiFunction__O(key any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) Merge_O_O_BiFunction__O(key, value any, remappingFunction BiFunction) any {

	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *Collections_SingletonMap) HashCode__I() int32 {
	return Objects_HashCode_O__I(t.F_k) ^ Objects_HashCode_O__I(t.F_v)
}
func Collections_NCopies_I_O__List(n int32, o any) List { Collections_Init()
	if n < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2633, StrOfInt(n))))) }
	return Collections_CopiesList_New_I_O(n, o)
}











func Collections_CopiesList_New_I_O(p0 int32, p1 any) *Collections_CopiesList { Collections_CopiesList_Init(); t := &Collections_CopiesList{}; t.Ctor_I_O(p0, p1); return t }
//line :2997:1
func (t *Collections_CopiesList) Ctor_I_O(n int32, e any) { t.AbstractList.Ctor(t)
	if !A2g_AssertionsDisabled && !(n >= 0) { panic(Thrown(AssertionError_New())) }
	t.F_n = n
	t.F_element = e
}
func (t *Collections_CopiesList) Size__I() int32 { return t.F_n }

func (t *Collections_CopiesList) Contains_O__Z(obj any) bool {
	var tmp1 bool; tmp1 = !(t.F_n == 0); if tmp1 { tmp1 = Collections_Eq_O_O__Z(obj, t.F_element) }; return tmp1
}
func (t *Collections_CopiesList) IndexOf_O__I(o any) int32 { if t.Contains_O__Z(o) { return 0 } else { return -1 } }

func (t *Collections_CopiesList) LastIndexOf_O__I(o any) int32 {
	if t.Contains_O__Z(o) { return t.F_n - 1 } else { return -1
	} }
func (t *Collections_CopiesList) Get_I__O(index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_n)
//line :3012:1
	return t.F_element
}


func (t *Collections_CopiesList) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var n int32 = t.F_n; var element any = t.F_element
	var i int32 = 0
L1: for { if i < n { action.Accept_O__V(element); i = i + 1; continue L1 }; break L1
} }
func (t *Collections_CopiesList) ToArray__O1() *RefArray {
	var a *RefArray = NewRefArray(Object_class, t.F_n); if !(t.F_element == nil) { Arrays_Fill_O1_I_I_O__V(a, 0, t.F_n, t.F_element) }; return a
}
func (t *Collections_CopiesList) ToArray_O1__O1(a *RefArray) *RefArray {
	var n int32 = t.F_n
	if int32(len(a.A)) < n {

		a = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), n), Object_class.ArrayClass())
		if !(t.F_element == nil) { Arrays_Fill_O1_I_I_O__V(a, 0, n, t.F_element) } } else {
			Arrays_Fill_O1_I_I_O__V(a, 0, n, t.F_element); if int32(len(a.A)) > n { a.Store(n, nil) } }
//line :3026:1
	return a
}






func (t *Collections_CopiesList) Reversed__List() List { return t }

func (t *Collections_CopiesList) SubList_I_I__List(fromIndex, toIndex int32) List {
	if fromIndex < 0 {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2591, StrOfInt(fromIndex))))) }
	if toIndex > t.F_n { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2592, StrOfInt(toIndex))))) }
	if fromIndex > toIndex {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2593, StrOfInt(fromIndex), Lit_2594, StrOfInt(toIndex), Lit_1176))))
	}
	return Collections_CopiesList_New_I_O(toIndex-fromIndex, t.F_element)
}
func (t *Collections_CopiesList) HashCode__I() int32 {
	if t.F_n == 0 { return 1 } else {

		var pow int32 = 31; var sum int32 = 1; var i int32 = Integer_NumberOfLeadingZeros_I__I(t.F_n) + 1

	L1: for {
		if i < 32 {
			sum = sum * (pow + 1)
			pow = pow * pow
			if t.F_n<<(i&31) < 0 {

				pow = pow * 31
				sum = sum*31 + 1
				i = i + 1; continue L1 } else {
					i = i + 1; continue L1 } }
//line :3050:1
		break L1
	}








		var tmp1 int32 = pow; var tmp2 int32 = sum; var tmp3 int32


		if t.F_element == nil { tmp3 = 0 } else { tmp3 = HashCode(t.F_element) }
//line :3060:1
		return tmp1 + tmp2*tmp3
	}
}


func (t *Collections_CopiesList) Equals_O__Z(o any) bool {
	if any(o) == any(t) { return true } else {

		var tmp1 any = o; if Collections_CopiesList_InstanceOf(tmp1) { var other *Collections_CopiesList = Collections_CopiesList_Cast(tmp1); var tmp2 bool; var tmp3 int32 = t.F_n
			tmp2 = tmp3 == other.F_n; if tmp2 { var tmp4 bool; tmp4 = t.F_n == 0; if !tmp4 { var tmp5 any = t.F_element; tmp4 = Collections_Eq_O_O__Z(tmp5, other.F_element) }; tmp2 = tmp4 }; return tmp2 } else {
				if !List_InstanceOf(o) { return false } else {

					var remaining int32 = t.F_n; var e any = t.F_element; var itr Iterator = List_Cast(o).Iterator__Iterator()


					if e == nil {
					L1: for { var tmp6 bool; var tmp7 bool; tmp7 = itr.HasNext__Z(); if tmp7 {
						var tmp8 int32; var old_2 int32 = remaining
						remaining = remaining - 1
//line :3077:1
						tmp8 = old_2; tmp7 = tmp8 > 0 }
//line :3076:1
						tmp6 = tmp7; if tmp6 {




							if !(itr.Next__O() == nil) { return false }
//line :3076:1
							continue L1 }; break L1
					} } else {




					L2: for { var tmp9 bool; var tmp10 bool; tmp10 = itr.HasNext__Z(); if tmp10 {
						var tmp11 int32; var old_3 int32 = remaining
						remaining = remaining - 1
//line :3083:1
						tmp11 = old_3; tmp10 = tmp11 > 0 }
//line :3082:1
						tmp9 = tmp10; if tmp9 {




							if Equals(e, itr.Next__O()) { } else { return false }
//line :3082:1
							continue L2 }; break L2
					}
					}



					var tmp12 bool; tmp12 = remaining == 0; if tmp12 { tmp12 = !itr.HasNext__Z() }; return tmp12
				} } } }
func (t *Collections_CopiesList) Stream__Stream() Stream {
	return IntStream_Range_I_I__IntStream(0, t.F_n).MapToObj_IntFunction__Stream(&IntFunction_Fn{Fn: func(p0 int32) any { var i int32 = p0; _ = i; return t.F_element }})
}
func (t *Collections_CopiesList) ParallelStream__Stream() Stream {
	return IntStream_Range_I_I__IntStream(0, t.F_n).Parallel__IntStream().MapToObj_IntFunction__Stream(&IntFunction_Fn{Fn: func(p0 int32) any { var i int32 = p0; _ = i; return t.F_element }})
}
func (t *Collections_CopiesList) Spliterator__Spliterator() Spliterator {
	return t.Stream__Stream().Spliterator__Spliterator()
}





func Collections_ReverseOrder__Comparator() Comparator { Collections_Init(); Collections_ReverseComparator_Init(); return Up_Collections_ReverseComparator_Comparator(Collections_ReverseComparator_REVERSE_ORDER) }









func (t *Collections_ReverseComparator) Compare_Comparable_Comparable__I(c1, c2 Comparable) int32 {

	return c2.CompareTo_O__I(c1)
}
func (t *Collections_ReverseComparator) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Collections$ReverseComparator.readResolve()Ljava/lang/Object;")) }

func (t *Collections_ReverseComparator) Reversed__Comparator() Comparator {
	return Comparator_NaturalOrder__Comparator()
}
func Collections_ReverseOrder_Comparator__Comparator(cmp Comparator) Comparator { Collections_Init()
	if cmp == nil { Collections_ReverseComparator_Init(); return Up_Collections_ReverseComparator_Comparator(Collections_ReverseComparator_REVERSE_ORDER) } else { var tmp1 *Collections_ReverseComparator; Collections_ReverseComparator_Init(); tmp1 = Collections_ReverseComparator_REVERSE_ORDER; if any(cmp) == any(tmp1.Ref()) { Comparators_NaturalOrderComparator_Init(); return Up_Comparators_NaturalOrderComparator_Comparator(Comparators_NaturalOrderComparator_INSTANCE) } else { var tmp2 *Comparators_NaturalOrderComparator; Comparators_NaturalOrderComparator_Init(); tmp2 = Comparators_NaturalOrderComparator_INSTANCE; if any(cmp) == any(tmp2.Ref()) { Collections_ReverseComparator_Init(); return Up_Collections_ReverseComparator_Comparator(Collections_ReverseComparator_REVERSE_ORDER) } else { if Collections_ReverseComparator2_InstanceOf(cmp) {



		return Collections_ReverseComparator2_Cast(cmp).F_cmp } else {
			return Collections_ReverseComparator2_New_Comparator(cmp)
		}
	}
	}
	}
}




func Collections_ReverseComparator2_New_Comparator(p0 Comparator) *Collections_ReverseComparator2 { Collections_ReverseComparator2_Init(); t := &Collections_ReverseComparator2{}; t.Ctor_Comparator(p0); return t }
//line :3139:1
func (t *Collections_ReverseComparator2) Ctor_Comparator(cmp Comparator) {
	if !A2g_AssertionsDisabled && !!(cmp == nil) { panic(Thrown(AssertionError_New())) }
	t.F_cmp = cmp
}
func (t *Collections_ReverseComparator2) Compare_O_O__I(t1, t2 any) int32 { return t.F_cmp.Compare_O_O__I(t2, t1) }

func (t *Collections_ReverseComparator2) Equals_O__Z(o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(t); if !tmp1 {
		var tmp2 any = o; if Collections_ReverseComparator2_InstanceOf(tmp2) { var that *Collections_ReverseComparator2 = Collections_ReverseComparator2_Cast(tmp2); var tmp3 Comparator = t.F_cmp; tmp1 = tmp3.Equals_O__Z(that.F_cmp) } else { tmp1 = false } }
//line :3146:1
	return tmp1
}

func (t *Collections_ReverseComparator2) HashCode__I() int32 {
	return t.F_cmp.HashCode__I() ^ -2147483648
}
func (t *Collections_ReverseComparator2) Reversed__Comparator() Comparator { return t.F_cmp }

func Collections_Enumeration_Collection__Enumeration(c Collection) Enumeration { Collections_Init()
	return Collections_3_New_Collection(c)
}

func (t *Collections_3) HasMoreElements__Z() bool { return t.F_i.HasNext__Z() }

func (t *Collections_3) NextElement__O() any { return t.F_i.Next__O() }

func Collections_List_Enumeration__ArrayList(e Enumeration) *ArrayList { Collections_Init()
	var l *ArrayList = ArrayList_New()
L1: for { if e.HasMoreElements__Z() { NN(l).Add_O__Z(e.NextElement__O()); continue L1 }; break L1 }
//line :3163:1
	return l
}


func Collections_Eq_O_O__Z(o1, o2 any) bool { Collections_Init()
	if o1 == nil { return o2 == nil } else { return Equals(o1, o2)
	} }
func Collections_Frequency_Collection_O__I(c Collection, o any) int32 { Collections_Init()
	var result int32 = 0
	if o == nil {
		var i_101781 Iterator = c.Iterator__Iterator(); for i_101781.HasNext__Z() { var e any = i_101781.Next__O(); if e == nil { result = result + 1 } } } else {
			var i_101782 Iterator = c.Iterator__Iterator(); for i_101782.HasNext__Z() { var e_2 any = i_101782.Next__O(); if Equals(o, e_2) { result = result + 1 } } }
//line :3171:1
	return result
}




func Collections_Disjoint_Collection_Collection__Z(c1, c2 Collection) bool { Collections_Init()
	var contains Collection = c2
	var iterate Collection = c1
	if Set_InstanceOf(c1) {
		iterate = c2; contains = c1 } else {
			if Set_InstanceOf(c2) { } else {
				var c1size int32 = c1.Size__I(); var c2size int32 = c2.Size__I(); var tmp1 bool; var tmp2 bool

				tmp2 = c1size == 0; if !tmp2 { tmp2 = c2size == 0 }; tmp1 = tmp2; if tmp1 { return true }
				if c1size > c2size { iterate = c2; contains = c1 } } }
	var i_101783 Iterator = iterate.Iterator__Iterator(); for i_101783.HasNext__Z() { var e any = i_101783.Next__O(); if contains.Contains_O__Z(e) { return false } }
//line :3178:1
	return true
}










func Collections_AddAll_Collection_O1__Z(c Collection, elements *RefArray) bool { Collections_Init()

	var result bool = false; var arr_101784 *RefArray = elements; var len_101785 int32 = int32(len(arr_101784.A)); var i_101786 int32 = 0; for ; i_101786 < len_101785; i_101786++ {
		var element any = arr_101784.A[i_101786]; var tmp1 bool; var a_4 bool = result; var b_5 bool = c.Add_O__Z(element); var tmp2 bool
		tmp2 = a_4; if !tmp2 { tmp2 = b_5 }; tmp1 = tmp2; result = tmp1 }
//line :3192:1
	return result
}



func Collections_NewSetFromMap_Map__Set(map_ Map) Set { Collections_Init()
	if map_.IsEmpty__Z() { } else { panic(Thrown(IllegalArgumentException_New_String(Lit_2634))) }
	return Collections_SetFromMap_New_Map(map_)
}









func Collections_SetFromMap_New_Map(p0 Map) *Collections_SetFromMap { t := &Collections_SetFromMap{}; t.Ctor_Map(t, p0); return t }
//line :3210:1
func (t *Collections_SetFromMap) Ctor_Map(this Collections_SetFromMap_I, map_ Map) { t.AbstractSet.Ctor(this)
	t.F_m = map_
	t.F_s = map_.KeySet__Set()
}
func (t *Collections_SetFromMap) Impl_Clear__V(this Collections_SetFromMap_I) { t.F_m.Clear__V() }

func (t *Collections_SetFromMap) Impl_Size__I(this Collections_SetFromMap_I) int32 { return t.F_m.Size__I() }

func (t *Collections_SetFromMap) Impl_IsEmpty__Z(this Collections_SetFromMap_I) bool { return t.F_m.IsEmpty__Z() }

func (t *Collections_SetFromMap) Impl_Contains_O__Z(this Collections_SetFromMap_I, o any) bool { return t.F_m.ContainsKey_O__Z(o) }

func (t *Collections_SetFromMap) Impl_Remove_O__Z(this Collections_SetFromMap_I, o any) bool { return !(t.F_m.Remove_O__O(o) == nil) }

func (t *Collections_SetFromMap) Impl_Add_O__Z(this Collections_SetFromMap_I, e any) bool {
	var tmp1 Map = t.F_m; var tmp2 *Boolean; Boolean_Init(); tmp2 = Boolean_TRUE; return tmp1.Put_O_O__O(e, tmp2.Ref()) == nil
}
func (t *Collections_SetFromMap) Impl_Iterator__Iterator(this Collections_SetFromMap_I) Iterator { return t.F_s.Iterator__Iterator() }

func (t *Collections_SetFromMap) Impl_ToArray__O1(this Collections_SetFromMap_I) *RefArray { return t.F_s.ToArray__O1() }

func (t *Collections_SetFromMap) Impl_ToArray_O1__O1(this Collections_SetFromMap_I, a *RefArray) *RefArray {
	return t.F_s.ToArray_O1__O1(a)
}
func (t *Collections_SetFromMap) Impl_ToString__String(this Collections_SetFromMap_I) *String { return t.F_s.ToString__String() }

func (t *Collections_SetFromMap) Impl_HashCode__I(this Collections_SetFromMap_I) int32 { return t.F_s.HashCode__I() }

func (t *Collections_SetFromMap) Impl_Equals_O__Z(this Collections_SetFromMap_I, o any) bool {
	var tmp1 bool; tmp1 = any(o) == any(this); if !tmp1 { tmp1 = t.F_s.Equals_O__Z(o) }; return tmp1
}
func (t *Collections_SetFromMap) Impl_ContainsAll_Collection__Z(this Collections_SetFromMap_I, c Collection) bool {
	return t.F_s.ContainsAll_Collection__Z(c)
}
func (t *Collections_SetFromMap) Impl_RemoveAll_Collection__Z(this Collections_SetFromMap_I, c Collection) bool {
	return t.F_s.RemoveAll_Collection__Z(c)
}
func (t *Collections_SetFromMap) Impl_RetainAll_Collection__Z(this Collections_SetFromMap_I, c Collection) bool {
	return t.F_s.RetainAll_Collection__Z(c)
}
func (t *Collections_SetFromMap) Impl_ForEach_Consumer__V(this Collections_SetFromMap_I, action Consumer) {
	t.F_s.ForEach_Consumer__V(action)
}
func (t *Collections_SetFromMap) Impl_RemoveIf_Predicate__Z(this Collections_SetFromMap_I, filter Predicate) bool {
	return t.F_s.RemoveIf_Predicate__Z(filter)
}
func (t *Collections_SetFromMap) Impl_Spliterator__Spliterator(this Collections_SetFromMap_I) Spliterator {
	return t.F_s.Spliterator__Spliterator()
}
func (t *Collections_SetFromMap) Impl_Stream__Stream(this Collections_SetFromMap_I) Stream { return t.F_s.Stream__Stream() }

func (t *Collections_SetFromMap) Impl_ParallelStream__Stream(this Collections_SetFromMap_I) Stream {
	return t.F_s.ParallelStream__Stream()
}







func (t *Collections_SetFromMap) Impl_ReadObjectNoData__V(this Collections_SetFromMap_I) { panic(A2g_NotTranslated("java.util.Collections$SetFromMap.readObjectNoData()V")) }


func Collections_NewSequencedSetFromMap_SequencedMap__SequencedSet(map_ SequencedMap) SequencedSet { Collections_Init()
	if map_.IsEmpty__Z() { } else { panic(Thrown(IllegalArgumentException_New_String(Lit_2634))) }
	return Collections_SequencedSetFromMap_New_SequencedMap(map_)
}





func (t *Collections_SequencedSetFromMap) Nsee_Map_Entry__O(e Map_Entry) any {
	if e == nil { panic(Thrown(NoSuchElementException_New())) } else { return e.GetKey__O()
	} }
func (t *Collections_SequencedSetFromMap) Map__SequencedMap() SequencedMap {
	return SequencedMap_Cast(t.F_m)
}
func Collections_SequencedSetFromMap_New_SequencedMap(p0 SequencedMap) *Collections_SequencedSetFromMap { t := &Collections_SequencedSetFromMap{}; t.Ctor_SequencedMap(p0); return t }
//line :3289:1
func (t *Collections_SequencedSetFromMap) Ctor_SequencedMap(map_ SequencedMap) { t.Collections_SetFromMap.Ctor_Map(t, map_) }

func (t *Collections_SequencedSetFromMap) Reversed__SequencedSet() SequencedSet {
	return Collections_SequencedSetFromMap_New_SequencedMap(t.Map__SequencedMap().Reversed__SequencedMap())
}
func (t *Collections_SequencedSetFromMap) AddFirst_O__V(e any) {
	var tmp1 SequencedMap = t.Map__SequencedMap(); var tmp2 *Boolean; Boolean_Init(); tmp2 = Boolean_TRUE; tmp1.PutFirst_O_O__O(e, tmp2.Ref())
}
func (t *Collections_SequencedSetFromMap) AddLast_O__V(e any) {
	var tmp1 SequencedMap = t.Map__SequencedMap(); var tmp2 *Boolean; Boolean_Init(); tmp2 = Boolean_TRUE; tmp1.PutLast_O_O__O(e, tmp2.Ref())
}
func (t *Collections_SequencedSetFromMap) GetFirst__O() any {
	return t.Nsee_Map_Entry__O(t.Map__SequencedMap().FirstEntry__Map_Entry())
}
func (t *Collections_SequencedSetFromMap) GetLast__O() any {
	return t.Nsee_Map_Entry__O(t.Map__SequencedMap().LastEntry__Map_Entry())
}
func (t *Collections_SequencedSetFromMap) RemoveFirst__O() any {
	return t.Nsee_Map_Entry__O(t.Map__SequencedMap().PollFirstEntry__Map_Entry())
}
func (t *Collections_SequencedSetFromMap) RemoveLast__O() any {
	return t.Nsee_Map_Entry__O(t.Map__SequencedMap().PollLastEntry__Map_Entry())
}


func Collections_AsLifoQueue_Deque__Queue(deque Deque) Queue { Collections_Init()
	return Collections_AsLIFOQueue_New_Deque(Deque_Cast(Objects_RequireNonNull_O__O(deque)))
}









func Collections_AsLIFOQueue_New_Deque(p0 Deque) *Collections_AsLIFOQueue { t := &Collections_AsLIFOQueue{}; t.Ctor_Deque(p0); return t }
//line :3326:1
func (t *Collections_AsLIFOQueue) Ctor_Deque(q Deque) { t.AbstractQueue.Ctor(t); t.F_q = q }

func (t *Collections_AsLIFOQueue) Add_O__Z(e any) bool { t.F_q.AddFirst_O__V(e); return true }

func (t *Collections_AsLIFOQueue) Offer_O__Z(e any) bool { return t.F_q.OfferFirst_O__Z(e) }

func (t *Collections_AsLIFOQueue) Poll__O() any { return t.F_q.PollFirst__O() }

func (t *Collections_AsLIFOQueue) Remove__O() any { return t.F_q.RemoveFirst__O() }

func (t *Collections_AsLIFOQueue) Peek__O() any { return t.F_q.PeekFirst__O() }

func (t *Collections_AsLIFOQueue) Element__O() any { return t.F_q.GetFirst__O() }

func (t *Collections_AsLIFOQueue) Clear__V() { t.F_q.Clear__V() }

func (t *Collections_AsLIFOQueue) Size__I() int32 { return t.F_q.Size__I() }

func (t *Collections_AsLIFOQueue) IsEmpty__Z() bool { return t.F_q.IsEmpty__Z() }

func (t *Collections_AsLIFOQueue) Contains_O__Z(o any) bool { return t.F_q.Contains_O__Z(o) }

func (t *Collections_AsLIFOQueue) Remove_O__Z(o any) bool { return t.F_q.Remove_O__Z(o) }

func (t *Collections_AsLIFOQueue) Iterator__Iterator() Iterator { return t.F_q.Iterator__Iterator() }

func (t *Collections_AsLIFOQueue) ToArray__O1() *RefArray { return t.F_q.ToArray__O1() }

func (t *Collections_AsLIFOQueue) ToArray_O1__O1(a *RefArray) *RefArray {
	return t.F_q.ToArray_O1__O1(a)
}
func (t *Collections_AsLIFOQueue) ToArray_IntFunction__O1(f IntFunction) *RefArray {
	return t.F_q.ToArray_IntFunction__O1(f)
}
func (t *Collections_AsLIFOQueue) ToString__String() *String { return t.F_q.ToString__String() }

func (t *Collections_AsLIFOQueue) ContainsAll_Collection__Z(c Collection) bool {
	return t.F_q.ContainsAll_Collection__Z(c)
}
func (t *Collections_AsLIFOQueue) RemoveAll_Collection__Z(c Collection) bool {
	return t.F_q.RemoveAll_Collection__Z(c)
}
func (t *Collections_AsLIFOQueue) RetainAll_Collection__Z(c Collection) bool {
	return t.F_q.RetainAll_Collection__Z(c)
}
func (t *Collections_AsLIFOQueue) ForEach_Consumer__V(action Consumer) {
	t.F_q.ForEach_Consumer__V(action)
}
func (t *Collections_AsLIFOQueue) RemoveIf_Predicate__Z(filter Predicate) bool {
	return t.F_q.RemoveIf_Predicate__Z(filter)
}
func (t *Collections_AsLIFOQueue) Spliterator__Spliterator() Spliterator {
	return t.F_q.Spliterator__Spliterator()
}
func (t *Collections_AsLIFOQueue) Stream__Stream() Stream { return t.F_q.Stream__Stream() }

func (t *Collections_AsLIFOQueue) ParallelStream__Stream() Stream {
	return t.F_q.ParallelStream__Stream()
}


type Collections struct{ Object }

const Collections_BINARYSEARCH_THRESHOLD int32 = 5000

const Collections_REVERSE_THRESHOLD int32 = 18

const Collections_SHUFFLE_THRESHOLD int32 = 5

const Collections_FILL_THRESHOLD int32 = 25

const Collections_ROTATE_THRESHOLD int32 = 100

const Collections_COPY_THRESHOLD int32 = 10

const Collections_REPLACEALL_THRESHOLD int32 = 11

const Collections_INDEXOFSUBLIST_THRESHOLD int32 = 35

var Collections_r Random_I

var Collections_EMPTY_SET Set

var Collections_EMPTY_LIST List

var Collections_EMPTY_MAP Map

var Collections_init ClassInit

func Collections_Init() { if !Collections_init.Done() { Collections_init.Run(Collections_clinit) } }

func Collections_clinit() { Collections_EMPTY_SET = Collections_EmptySet_New(); Collections_EMPTY_LIST = Collections_EmptyList_New(); Collections_EMPTY_MAP = Collections_EmptyMap_New() }

func (t *Collections) Ref() any { if t == nil { return nil }; return t }

func (t *Collections) GetClass__Class() *Class { return Collections_class }

func (t *Collections) ToString__String() *String { return Object_toString(t) }

func (t *Collections) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_InstanceOf(x any) bool { _, ok := x.(*Collections); return ok }

func Collections_Cast(x any) *Collections { if x == nil { return nil }; v, ok := x.(*Collections); if !ok { panic(ClassCast(x, Collections_class)) }; return v }



type Collections_1 struct{ Object; F_hasNext bool; F_val_e any }

func (t *Collections_1) Is_Iterator() {}

func Collections_1_New_O(p0 any) *Collections_1 { t := &Collections_1{}; t.Ctor_O(p0); return t }

func (t *Collections_1) Ctor_O(val_e any) { t.F_val_e = val_e; t.F_hasNext = true }

func (t *Collections_1) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_1) GetClass__Class() *Class { return Collections_1_class }

func (t *Collections_1) ToString__String() *String { return Object_toString(t) }

func (t *Collections_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_1_InstanceOf(x any) bool { _, ok := x.(*Collections_1); return ok }

func Collections_1_Cast(x any) *Collections_1 { if x == nil { return nil }; v, ok := x.(*Collections_1); if !ok { panic(ClassCast(x, Collections_1_class)) }; return v }



type Collections_2 struct{ Object; F_est int64; F_val_element any }

func (t *Collections_2) Is_Spliterator() {}

func Collections_2_New_O(p0 any) *Collections_2 { t := &Collections_2{}; t.Ctor_O(p0); return t }

func (t *Collections_2) Ctor_O(val_element any) { t.F_val_element = val_element; t.F_est = 1 }

func (t *Collections_2) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *Collections_2) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *Collections_2) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *Collections_2) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_2) GetClass__Class() *Class { return Collections_2_class }

func (t *Collections_2) ToString__String() *String { return Object_toString(t) }

func (t *Collections_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_2_InstanceOf(x any) bool { _, ok := x.(*Collections_2); return ok }

func Collections_2_Cast(x any) *Collections_2 { if x == nil { return nil }; v, ok := x.(*Collections_2); if !ok { panic(ClassCast(x, Collections_2_class)) }; return v }



type Collections_3 struct{ Object; F_i Iterator; F_val_c Collection }

func (t *Collections_3) Is_Enumeration() {}

func Collections_3_New_Collection(p0 Collection) *Collections_3 { t := &Collections_3{}; t.Ctor_Collection(p0); return t }

func (t *Collections_3) Ctor_Collection(val_c Collection) { t.F_val_c = val_c; t.F_i = t.F_val_c.Iterator__Iterator() }

func (t *Collections_3) AsIterator__Iterator() Iterator { return Enumeration_AsIterator__Iterator(t) }

func (t *Collections_3) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_3) GetClass__Class() *Class { return Collections_3_class }

func (t *Collections_3) ToString__String() *String { return Object_toString(t) }

func (t *Collections_3) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_3_InstanceOf(x any) bool { _, ok := x.(*Collections_3); return ok }

func Collections_3_Cast(x any) *Collections_3 { if x == nil { return nil }; v, ok := x.(*Collections_3); if !ok { panic(ClassCast(x, Collections_3_class)) }; return v }



type Collections_AsLIFOQueue struct{ AbstractQueue; F_q Deque }

func (t *Collections_AsLIFOQueue) Is_Serializable() {}

const Collections_AsLIFOQueue_serialVersionUID int64 = 1802017725587941708

func (t *Collections_AsLIFOQueue) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_AsLIFOQueue) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_AsLIFOQueue) GetClass__Class() *Class { return Collections_AsLIFOQueue_class }

func (t *Collections_AsLIFOQueue) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_AsLIFOQueue) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_AsLIFOQueue_InstanceOf(x any) bool { _, ok := x.(*Collections_AsLIFOQueue); return ok }

func Collections_AsLIFOQueue_Cast(x any) *Collections_AsLIFOQueue { if x == nil { return nil }; v, ok := x.(*Collections_AsLIFOQueue); if !ok { panic(ClassCast(x, Collections_AsLIFOQueue_class)) }; return v }



type Collections_CheckedCollection struct{ Object; F_c Collection; F_type *Class; F_zeroLengthElementArray *RefArray }

type Collections_CheckedCollection_I interface{ Object_I; Collection; Serializable; Iterable; Self_Collections_CheckedCollection() *Collections_CheckedCollection; TypeCheck_O__O(p0 any) any; Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; ToArray_IntFunction__O1(p0 IntFunction) *RefArray; Remove_O__Z(p0 any) bool; Clear__V(); ContainsAll_Collection__Z(p0 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; Iterator__Iterator() Iterator; Add_O__Z(p0 any) bool; CheckedCopyOf_Collection__Collection(p0 Collection) Collection; AddAll_Collection__Z(p0 Collection) bool; ForEach_Consumer__V(p0 Consumer); RemoveIf_Predicate__Z(p0 Predicate) bool; Spliterator__Spliterator() Spliterator; Stream__Stream() Stream; ParallelStream__Stream() Stream }

func (t *Collections_CheckedCollection) Self_Collections_CheckedCollection() *Collections_CheckedCollection { return t }

func (t *Collections_CheckedCollection) Is_Collection() {}

func (t *Collections_CheckedCollection) Is_Serializable() {}

func (t *Collections_CheckedCollection) Is_Iterable() {}

const Collections_CheckedCollection_serialVersionUID int64 = 1578914078182001775

func (t *Collections_CheckedCollection) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_CheckedCollection) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedCollection) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedCollection) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedCollection) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_CheckedCollection) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CheckedCollection) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedCollection) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CheckedCollection) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CheckedCollection) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_CheckedCollection) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CheckedCollection) CheckedCopyOf_Collection__Collection(p0 Collection) Collection { return t.Impl_CheckedCopyOf_Collection__Collection(t, p0) }

func (t *Collections_CheckedCollection) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_CheckedCollection) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CheckedCollection) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedCollection) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_CheckedCollection) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedCollection) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_CheckedCollection) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CheckedCollection) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CheckedCollection) TypeCheck_O__O(p0 any) any { return t.Impl_TypeCheck_O__O(t, p0) }

func (t *Collections_CheckedCollection) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedCollection) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedCollection) GetClass__Class() *Class { return Collections_CheckedCollection_class }

func (t *Collections_CheckedCollection) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedCollection) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedCollection_InstanceOf(x any) bool { _, ok := x.(Collections_CheckedCollection_I); return ok }

func Collections_CheckedCollection_Cast(x any) Collections_CheckedCollection_I { if x == nil { return nil }; v, ok := x.(Collections_CheckedCollection_I); if !ok { panic(ClassCast(x, Collections_CheckedCollection_class)) }; return v }



type Collections_CheckedCollection_1 struct{ Object; F_this_0 Collections_CheckedCollection_I; F_val_it Iterator }

func (t *Collections_CheckedCollection_1) Is_Iterator() {}

func Collections_CheckedCollection_1_New_Collections_CheckedCollection_Iterator(p0 Collections_CheckedCollection_I, p1 Iterator) *Collections_CheckedCollection_1 { t := &Collections_CheckedCollection_1{}; t.Ctor_Collections_CheckedCollection_Iterator(p0, p1); return t }

func (t *Collections_CheckedCollection_1) Ctor_Collections_CheckedCollection_Iterator(this_0 Collections_CheckedCollection_I, val_it Iterator) { t.F_val_it = val_it; A2g_NotNull[Collections_CheckedCollection_I](this_0); t.F_this_0 = this_0 }

func (t *Collections_CheckedCollection_1) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedCollection_1) GetClass__Class() *Class { return Collections_CheckedCollection_1_class }

func (t *Collections_CheckedCollection_1) ToString__String() *String { return Object_toString(t) }

func (t *Collections_CheckedCollection_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedCollection_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedCollection_1_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedCollection_1); return ok }

func Collections_CheckedCollection_1_Cast(x any) *Collections_CheckedCollection_1 { if x == nil { return nil }; v, ok := x.(*Collections_CheckedCollection_1); if !ok { panic(ClassCast(x, Collections_CheckedCollection_1_class)) }; return v }



type Collections_CheckedList struct{ Collections_CheckedCollection; F_list List }

type Collections_CheckedList_I interface{ Collections_CheckedCollection_I; List; Collection; Serializable; SequencedCollection; Iterable; Self_Collections_CheckedList() *Collections_CheckedList; Get_I__O(p0 int32) any; Remove_I__O(p0 int32) any; IndexOf_O__I(p0 any) int32; LastIndexOf_O__I(p0 any) int32; Set_I_O__O(p0 int32, p1 any) any; Add_I_O__V(p0 int32, p1 any); AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; ListIterator__ListIterator() ListIterator; ListIterator_I__ListIterator(p0 int32) ListIterator; SubList_I_I__List(p0, p1 int32) List; ReplaceAll_UnaryOperator__V(p0 UnaryOperator); Sort_Comparator__V(p0 Comparator) }

func (t *Collections_CheckedList) Self_Collections_CheckedList() *Collections_CheckedList { return t }

func (t *Collections_CheckedList) Is_List() {}

func (t *Collections_CheckedList) Is_SequencedCollection() {}

const Collections_CheckedList_serialVersionUID int64 = 65247728283967356

func (t *Collections_CheckedList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_CheckedList) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_CheckedList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *Collections_CheckedList) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_CheckedList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Collections_CheckedList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *Collections_CheckedList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CheckedList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_CheckedList) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *Collections_CheckedList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *Collections_CheckedList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_CheckedList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Collections_CheckedList) Reversed__List() List { return List_Reversed__List(t) }

func (t *Collections_CheckedList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Collections_CheckedList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_CheckedList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CheckedList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CheckedList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_CheckedList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CheckedList) CheckedCopyOf_Collection__Collection(p0 Collection) Collection { return t.Impl_CheckedCopyOf_Collection__Collection(t, p0) }

func (t *Collections_CheckedList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_CheckedList) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_CheckedList) GetLast__O() any { return List_GetLast__O(t) }

func (t *Collections_CheckedList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Collections_CheckedList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CheckedList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Collections_CheckedList) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_CheckedList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_CheckedList) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Collections_CheckedList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_CheckedList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CheckedList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CheckedList) TypeCheck_O__O(p0 any) any { return t.Impl_TypeCheck_O__O(t, p0) }

func (t *Collections_CheckedList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_CheckedList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_CheckedList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedList) GetClass__Class() *Class { return Collections_CheckedList_class }

func (t *Collections_CheckedList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedList_InstanceOf(x any) bool { _, ok := x.(Collections_CheckedList_I); return ok }

func Collections_CheckedList_Cast(x any) Collections_CheckedList_I { if x == nil { return nil }; v, ok := x.(Collections_CheckedList_I); if !ok { panic(ClassCast(x, Collections_CheckedList_class)) }; return v }



type Collections_CheckedList_1 struct{ Object; F_this_0 Collections_CheckedList_I; F_val_i ListIterator }

func (t *Collections_CheckedList_1) Is_ListIterator() {}

func (t *Collections_CheckedList_1) Is_Iterator() {}

func Collections_CheckedList_1_New_Collections_CheckedList_ListIterator(p0 Collections_CheckedList_I, p1 ListIterator) *Collections_CheckedList_1 { t := &Collections_CheckedList_1{}; t.Ctor_Collections_CheckedList_ListIterator(p0, p1); return t }

func (t *Collections_CheckedList_1) Ctor_Collections_CheckedList_ListIterator(this_0 Collections_CheckedList_I, val_i ListIterator) { t.F_val_i = val_i; A2g_NotNull[Collections_CheckedList_I](this_0); t.F_this_0 = this_0 }

func (t *Collections_CheckedList_1) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedList_1) GetClass__Class() *Class { return Collections_CheckedList_1_class }

func (t *Collections_CheckedList_1) ToString__String() *String { return Object_toString(t) }

func (t *Collections_CheckedList_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedList_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedList_1_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedList_1); return ok }

func Collections_CheckedList_1_Cast(x any) *Collections_CheckedList_1 { if x == nil { return nil }; v, ok := x.(*Collections_CheckedList_1); if !ok { panic(ClassCast(x, Collections_CheckedList_1_class)) }; return v }



type Collections_CheckedMap struct{ Object; F_m Map; F_keyType, F_valueType *Class; F_entrySet Set }

type Collections_CheckedMap_I interface{ Object_I; Map; Serializable; Self_Collections_CheckedMap() *Collections_CheckedMap; Size__I() int32; IsEmpty__Z() bool; ContainsKey_O__Z(p0 any) bool; ContainsValue_O__Z(p0 any) bool; Get_O__O(p0 any) any; Remove_O__O(p0 any) any; Clear__V(); KeySet__Set() Set; Values__Collection() Collection; Put_O_O__O(p0, p1 any) any; PutAll_Map__V(p0 Map); EntrySet__Set() Set; ForEach_BiConsumer__V(p0 BiConsumer); ReplaceAll_BiFunction__V(p0 BiFunction); PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any }

func (t *Collections_CheckedMap) Self_Collections_CheckedMap() *Collections_CheckedMap { return t }

func (t *Collections_CheckedMap) Is_Map() {}

func (t *Collections_CheckedMap) Is_Serializable() {}

const Collections_CheckedMap_serialVersionUID int64 = 5742860141034234728

func (t *Collections_CheckedMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_CheckedMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_CheckedMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_CheckedMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_CheckedMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_CheckedMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_CheckedMap) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_CheckedMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_CheckedMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_CheckedMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_CheckedMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_CheckedMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_CheckedMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_CheckedMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_CheckedMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_CheckedMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_CheckedMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_CheckedMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_CheckedMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_CheckedMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_CheckedMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedMap) GetClass__Class() *Class { return Collections_CheckedMap_class }

func (t *Collections_CheckedMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedMap_InstanceOf(x any) bool { _, ok := x.(Collections_CheckedMap_I); return ok }

func Collections_CheckedMap_Cast(x any) Collections_CheckedMap_I { if x == nil { return nil }; v, ok := x.(Collections_CheckedMap_I); if !ok { panic(ClassCast(x, Collections_CheckedMap_class)) }; return v }



type Collections_CheckedMap_CheckedEntrySet struct{ Object; F_s Set; F_valueType *Class }

func (t *Collections_CheckedMap_CheckedEntrySet) Is_Set() {}

func (t *Collections_CheckedMap_CheckedEntrySet) Is_Collection() {}

func (t *Collections_CheckedMap_CheckedEntrySet) Is_Iterable() {}

func (t *Collections_CheckedMap_CheckedEntrySet) Add_O__Z(p0 any) bool { return t.Add_Map_Entry__Z(Map_Entry_Cast(p0)) }

func (t *Collections_CheckedMap_CheckedEntrySet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *Collections_CheckedMap_CheckedEntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedMap_CheckedEntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedMap_CheckedEntrySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Collections_CheckedMap_CheckedEntrySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Collections_CheckedMap_CheckedEntrySet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedMap_CheckedEntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedMap_CheckedEntrySet) GetClass__Class() *Class { return Collections_CheckedMap_CheckedEntrySet_class }

func (t *Collections_CheckedMap_CheckedEntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedMap_CheckedEntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedMap_CheckedEntrySet_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedMap_CheckedEntrySet); return ok }

func Collections_CheckedMap_CheckedEntrySet_Cast(x any) *Collections_CheckedMap_CheckedEntrySet { if x == nil { return nil }; v, ok := x.(*Collections_CheckedMap_CheckedEntrySet); if !ok { panic(ClassCast(x, Collections_CheckedMap_CheckedEntrySet_class)) }; return v }



type Collections_CheckedMap_CheckedEntrySet_1 struct{ Object; F_this_0 *Collections_CheckedMap_CheckedEntrySet; F_val_i Iterator }

func (t *Collections_CheckedMap_CheckedEntrySet_1) Is_Iterator() {}

func Collections_CheckedMap_CheckedEntrySet_1_New_Collections_CheckedMap_CheckedEntrySet_Iterator(p0 *Collections_CheckedMap_CheckedEntrySet, p1 Iterator) *Collections_CheckedMap_CheckedEntrySet_1 { t := &Collections_CheckedMap_CheckedEntrySet_1{}; t.Ctor_Collections_CheckedMap_CheckedEntrySet_Iterator(p0, p1); return t }

func (t *Collections_CheckedMap_CheckedEntrySet_1) Ctor_Collections_CheckedMap_CheckedEntrySet_Iterator(this_0 *Collections_CheckedMap_CheckedEntrySet, val_i Iterator) { t.F_val_i = val_i; NN(this_0); t.F_this_0 = this_0 }

func (t *Collections_CheckedMap_CheckedEntrySet_1) Next__O() any { return t.Next__Map_Entry() }

func (t *Collections_CheckedMap_CheckedEntrySet_1) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedMap_CheckedEntrySet_1) GetClass__Class() *Class { return Collections_CheckedMap_CheckedEntrySet_1_class }

func (t *Collections_CheckedMap_CheckedEntrySet_1) ToString__String() *String { return Object_toString(t) }

func (t *Collections_CheckedMap_CheckedEntrySet_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedMap_CheckedEntrySet_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedMap_CheckedEntrySet_1_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedMap_CheckedEntrySet_1); return ok }

func Collections_CheckedMap_CheckedEntrySet_1_Cast(x any) *Collections_CheckedMap_CheckedEntrySet_1 { if x == nil { return nil }; v, ok := x.(*Collections_CheckedMap_CheckedEntrySet_1); if !ok { panic(ClassCast(x, Collections_CheckedMap_CheckedEntrySet_1_class)) }; return v }



type Collections_CheckedMap_CheckedEntrySet_CheckedEntry struct{ Object; F_e Map_Entry; F_valueType *Class }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) Is_Map_Entry() {}

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) GetClass__Class() *Class { return Collections_CheckedMap_CheckedEntrySet_CheckedEntry_class }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedMap_CheckedEntrySet_CheckedEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedMap_CheckedEntrySet_CheckedEntry_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedMap_CheckedEntrySet_CheckedEntry); return ok }

func Collections_CheckedMap_CheckedEntrySet_CheckedEntry_Cast(x any) *Collections_CheckedMap_CheckedEntrySet_CheckedEntry { if x == nil { return nil }; v, ok := x.(*Collections_CheckedMap_CheckedEntrySet_CheckedEntry); if !ok { panic(ClassCast(x, Collections_CheckedMap_CheckedEntrySet_CheckedEntry_class)) }; return v }



type Collections_CheckedNavigableMap struct{ Collections_CheckedSortedMap; F_nm NavigableMap }

func (t *Collections_CheckedNavigableMap) Is_NavigableMap() {}

const Collections_CheckedNavigableMap_serialVersionUID int64 = -4852462692372534096

func (t *Collections_CheckedNavigableMap) SubMap_O_O__SortedMap(p0, p1 any) SortedMap { return t.SubMap_O_O__NavigableMap(p0, p1) }

func (t *Collections_CheckedNavigableMap) HeadMap_O__SortedMap(p0 any) SortedMap { return t.HeadMap_O__NavigableMap(p0) }

func (t *Collections_CheckedNavigableMap) TailMap_O__SortedMap(p0 any) SortedMap { return t.TailMap_O__NavigableMap(p0) }

func (t *Collections_CheckedNavigableMap) KeySet__Set() Set { return t.KeySet__NavigableSet() }

func (t *Collections_CheckedNavigableMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_CheckedNavigableMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedNavigableMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedNavigableMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_CheckedNavigableMap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_CheckedNavigableMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) Reversed__SortedMap() SortedMap { return NavigableMap_Reversed__SortedMap(t) }

func (t *Collections_CheckedNavigableMap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_CheckedNavigableMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_CheckedNavigableMap) Reversed__SequencedMap() SequencedMap { return NavigableMap_Reversed__SequencedMap(t) }

func (t *Collections_CheckedNavigableMap) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_CheckedNavigableMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_CheckedNavigableMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_CheckedNavigableMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_CheckedNavigableMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedNavigableMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_CheckedNavigableMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_CheckedNavigableMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_CheckedNavigableMap) Reversed__NavigableMap() NavigableMap { return NavigableMap_Reversed__NavigableMap(t) }

func (t *Collections_CheckedNavigableMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_CheckedNavigableMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_CheckedNavigableMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_CheckedNavigableMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedNavigableMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedNavigableMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedNavigableMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedNavigableMap) GetClass__Class() *Class { return Collections_CheckedNavigableMap_class }

func (t *Collections_CheckedNavigableMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedNavigableMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedNavigableMap_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedNavigableMap); return ok }

func Collections_CheckedNavigableMap_Cast(x any) *Collections_CheckedNavigableMap { if x == nil { return nil }; v, ok := x.(*Collections_CheckedNavigableMap); if !ok { panic(ClassCast(x, Collections_CheckedNavigableMap_class)) }; return v }



type Collections_CheckedNavigableSet struct{ Collections_CheckedSortedSet; F_ns NavigableSet }

func (t *Collections_CheckedNavigableSet) Is_NavigableSet() {}

const Collections_CheckedNavigableSet_serialVersionUID int64 = -5429120189805438922

func (t *Collections_CheckedNavigableSet) SubSet_O_O__SortedSet(p0, p1 any) SortedSet { return t.SubSet_O_O__NavigableSet(p0, p1) }

func (t *Collections_CheckedNavigableSet) HeadSet_O__SortedSet(p0 any) SortedSet { return t.HeadSet_O__NavigableSet(p0) }

func (t *Collections_CheckedNavigableSet) TailSet_O__SortedSet(p0 any) SortedSet { return t.TailSet_O__NavigableSet(p0) }

func (t *Collections_CheckedNavigableSet) Reversed__SequencedSet() SequencedSet { return NavigableSet_Reversed__SequencedSet(t) }

func (t *Collections_CheckedNavigableSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_CheckedNavigableSet) Reversed__NavigableSet() NavigableSet { return NavigableSet_Reversed__NavigableSet(t) }

func (t *Collections_CheckedNavigableSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedNavigableSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedNavigableSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_CheckedNavigableSet) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *Collections_CheckedNavigableSet) Reversed__SequencedCollection() SequencedCollection { return NavigableSet_Reversed__SequencedCollection(t) }

func (t *Collections_CheckedNavigableSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_CheckedNavigableSet) Reversed__SortedSet() SortedSet { return NavigableSet_Reversed__SortedSet(t) }

func (t *Collections_CheckedNavigableSet) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *Collections_CheckedNavigableSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedNavigableSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_CheckedNavigableSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CheckedNavigableSet) CheckedCopyOf_Collection__Collection(p0 Collection) Collection { return t.Impl_CheckedCopyOf_Collection__Collection(t, p0) }

func (t *Collections_CheckedNavigableSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_CheckedNavigableSet) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *Collections_CheckedNavigableSet) RemoveLast__O() any { return NavigableSet_RemoveLast__O(t) }

func (t *Collections_CheckedNavigableSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedNavigableSet) First__O() any { return t.Impl_First__O(t) }

func (t *Collections_CheckedNavigableSet) RemoveFirst__O() any { return NavigableSet_RemoveFirst__O(t) }

func (t *Collections_CheckedNavigableSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_CheckedNavigableSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedNavigableSet) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *Collections_CheckedNavigableSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) TypeCheck_O__O(p0 any) any { return t.Impl_TypeCheck_O__O(t, p0) }

func (t *Collections_CheckedNavigableSet) Last__O() any { return t.Impl_Last__O(t) }

func (t *Collections_CheckedNavigableSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedNavigableSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedNavigableSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedNavigableSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedNavigableSet) GetClass__Class() *Class { return Collections_CheckedNavigableSet_class }

func (t *Collections_CheckedNavigableSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedNavigableSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedNavigableSet_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedNavigableSet); return ok }

func Collections_CheckedNavigableSet_Cast(x any) *Collections_CheckedNavigableSet { if x == nil { return nil }; v, ok := x.(*Collections_CheckedNavigableSet); if !ok { panic(ClassCast(x, Collections_CheckedNavigableSet_class)) }; return v }



type Collections_CheckedQueue struct{ Collections_CheckedCollection; F_queue Queue }

func (t *Collections_CheckedQueue) Is_Queue() {}

const Collections_CheckedQueue_serialVersionUID int64 = 1433151992604707767

func (t *Collections_CheckedQueue) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_CheckedQueue) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedQueue) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedQueue) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedQueue) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_CheckedQueue) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CheckedQueue) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedQueue) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CheckedQueue) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CheckedQueue) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_CheckedQueue) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CheckedQueue) CheckedCopyOf_Collection__Collection(p0 Collection) Collection { return t.Impl_CheckedCopyOf_Collection__Collection(t, p0) }

func (t *Collections_CheckedQueue) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_CheckedQueue) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CheckedQueue) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedQueue) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_CheckedQueue) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedQueue) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_CheckedQueue) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CheckedQueue) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CheckedQueue) TypeCheck_O__O(p0 any) any { return t.Impl_TypeCheck_O__O(t, p0) }

func (t *Collections_CheckedQueue) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedQueue) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedQueue) GetClass__Class() *Class { return Collections_CheckedQueue_class }

func (t *Collections_CheckedQueue) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedQueue) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedQueue_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedQueue); return ok }

func Collections_CheckedQueue_Cast(x any) *Collections_CheckedQueue { if x == nil { return nil }; v, ok := x.(*Collections_CheckedQueue); if !ok { panic(ClassCast(x, Collections_CheckedQueue_class)) }; return v }



type Collections_CheckedRandomAccessList struct{ Collections_CheckedList }

func (t *Collections_CheckedRandomAccessList) Is_RandomAccess() {}

const Collections_CheckedRandomAccessList_serialVersionUID int64 = 1638200125423088369

func (t *Collections_CheckedRandomAccessList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_CheckedRandomAccessList) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_CheckedRandomAccessList) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedRandomAccessList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedRandomAccessList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_CheckedRandomAccessList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Collections_CheckedRandomAccessList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *Collections_CheckedRandomAccessList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_CheckedRandomAccessList) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *Collections_CheckedRandomAccessList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *Collections_CheckedRandomAccessList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_CheckedRandomAccessList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Collections_CheckedRandomAccessList) Reversed__List() List { return List_Reversed__List(t) }

func (t *Collections_CheckedRandomAccessList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Collections_CheckedRandomAccessList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_CheckedRandomAccessList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedRandomAccessList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_CheckedRandomAccessList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CheckedRandomAccessList) CheckedCopyOf_Collection__Collection(p0 Collection) Collection { return t.Impl_CheckedCopyOf_Collection__Collection(t, p0) }

func (t *Collections_CheckedRandomAccessList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_CheckedRandomAccessList) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_CheckedRandomAccessList) GetLast__O() any { return List_GetLast__O(t) }

func (t *Collections_CheckedRandomAccessList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Collections_CheckedRandomAccessList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedRandomAccessList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Collections_CheckedRandomAccessList) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_CheckedRandomAccessList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_CheckedRandomAccessList) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedRandomAccessList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Collections_CheckedRandomAccessList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) TypeCheck_O__O(p0 any) any { return t.Impl_TypeCheck_O__O(t, p0) }

func (t *Collections_CheckedRandomAccessList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_CheckedRandomAccessList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_CheckedRandomAccessList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedRandomAccessList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedRandomAccessList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedRandomAccessList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedRandomAccessList) GetClass__Class() *Class { return Collections_CheckedRandomAccessList_class }

func (t *Collections_CheckedRandomAccessList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedRandomAccessList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedRandomAccessList_InstanceOf(x any) bool { _, ok := x.(*Collections_CheckedRandomAccessList); return ok }

func Collections_CheckedRandomAccessList_Cast(x any) *Collections_CheckedRandomAccessList { if x == nil { return nil }; v, ok := x.(*Collections_CheckedRandomAccessList); if !ok { panic(ClassCast(x, Collections_CheckedRandomAccessList_class)) }; return v }



type Collections_CheckedSet struct{ Collections_CheckedCollection }

type Collections_CheckedSet_I interface{ Collections_CheckedCollection_I; Set; Serializable; Collection; Iterable; Self_Collections_CheckedSet() *Collections_CheckedSet }

func (t *Collections_CheckedSet) Self_Collections_CheckedSet() *Collections_CheckedSet { return t }

func (t *Collections_CheckedSet) Is_Set() {}

const Collections_CheckedSet_serialVersionUID int64 = 4694047833775013803

func (t *Collections_CheckedSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_CheckedSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_CheckedSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CheckedSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_CheckedSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CheckedSet) CheckedCopyOf_Collection__Collection(p0 Collection) Collection { return t.Impl_CheckedCopyOf_Collection__Collection(t, p0) }

func (t *Collections_CheckedSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_CheckedSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_CheckedSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_CheckedSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CheckedSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSet) TypeCheck_O__O(p0 any) any { return t.Impl_TypeCheck_O__O(t, p0) }

func (t *Collections_CheckedSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedSet) GetClass__Class() *Class { return Collections_CheckedSet_class }

func (t *Collections_CheckedSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedSet_InstanceOf(x any) bool { _, ok := x.(Collections_CheckedSet_I); return ok }

func Collections_CheckedSet_Cast(x any) Collections_CheckedSet_I { if x == nil { return nil }; v, ok := x.(Collections_CheckedSet_I); if !ok { panic(ClassCast(x, Collections_CheckedSet_class)) }; return v }



type Collections_CheckedSortedMap struct{ Collections_CheckedMap; F_sm SortedMap }

type Collections_CheckedSortedMap_I interface{ Collections_CheckedMap_I; SortedMap; Serializable; Map; SequencedMap; Self_Collections_CheckedSortedMap() *Collections_CheckedSortedMap; Comparator__Comparator() Comparator; FirstKey__O() any; LastKey__O() any; SubMap_O_O__SortedMap(p0, p1 any) SortedMap; HeadMap_O__SortedMap(p0 any) SortedMap; TailMap_O__SortedMap(p0 any) SortedMap }

func (t *Collections_CheckedSortedMap) Self_Collections_CheckedSortedMap() *Collections_CheckedSortedMap { return t }

func (t *Collections_CheckedSortedMap) Is_SortedMap() {}

func (t *Collections_CheckedSortedMap) Is_SequencedMap() {}

const Collections_CheckedSortedMap_serialVersionUID int64 = 1599671320688067438

func (t *Collections_CheckedSortedMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_CheckedSortedMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedSortedMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedSortedMap) SubMap_O_O__SortedMap(p0, p1 any) SortedMap { return t.Impl_SubMap_O_O__SortedMap(t, p0, p1) }

func (t *Collections_CheckedSortedMap) FirstKey__O() any { return t.Impl_FirstKey__O(t) }

func (t *Collections_CheckedSortedMap) PollFirstEntry__Map_Entry() Map_Entry { return SequencedMap_PollFirstEntry__Map_Entry(t) }

func (t *Collections_CheckedSortedMap) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_CheckedSortedMap) FirstEntry__Map_Entry() Map_Entry { return SequencedMap_FirstEntry__Map_Entry(t) }

func (t *Collections_CheckedSortedMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_CheckedSortedMap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_CheckedSortedMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_CheckedSortedMap) Reversed__SortedMap() SortedMap { return SortedMap_Reversed__SortedMap(t) }

func (t *Collections_CheckedSortedMap) LastEntry__Map_Entry() Map_Entry { return SequencedMap_LastEntry__Map_Entry(t) }

func (t *Collections_CheckedSortedMap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_CheckedSortedMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_CheckedSortedMap) Reversed__SequencedMap() SequencedMap { return SortedMap_Reversed__SequencedMap(t) }

func (t *Collections_CheckedSortedMap) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_CheckedSortedMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_CheckedSortedMap) HeadMap_O__SortedMap(p0 any) SortedMap { return t.Impl_HeadMap_O__SortedMap(t, p0) }

func (t *Collections_CheckedSortedMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_CheckedSortedMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_CheckedSortedMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedSortedMap) PollLastEntry__Map_Entry() Map_Entry { return SequencedMap_PollLastEntry__Map_Entry(t) }

func (t *Collections_CheckedSortedMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_CheckedSortedMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_CheckedSortedMap) TailMap_O__SortedMap(p0 any) SortedMap { return t.Impl_TailMap_O__SortedMap(t, p0) }

func (t *Collections_CheckedSortedMap) LastKey__O() any { return t.Impl_LastKey__O(t) }

func (t *Collections_CheckedSortedMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_CheckedSortedMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_CheckedSortedMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_CheckedSortedMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_CheckedSortedMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_CheckedSortedMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedSortedMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedSortedMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedSortedMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedSortedMap) GetClass__Class() *Class { return Collections_CheckedSortedMap_class }

func (t *Collections_CheckedSortedMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedSortedMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedSortedMap_InstanceOf(x any) bool { _, ok := x.(Collections_CheckedSortedMap_I); return ok }

func Collections_CheckedSortedMap_Cast(x any) Collections_CheckedSortedMap_I { if x == nil { return nil }; v, ok := x.(Collections_CheckedSortedMap_I); if !ok { panic(ClassCast(x, Collections_CheckedSortedMap_class)) }; return v }



type Collections_CheckedSortedSet struct{ Collections_CheckedSet; F_ss SortedSet }

type Collections_CheckedSortedSet_I interface{ Collections_CheckedSet_I; SortedSet; Serializable; Set; Collection; SequencedSet; Iterable; SequencedCollection; Self_Collections_CheckedSortedSet() *Collections_CheckedSortedSet; Comparator__Comparator() Comparator; First__O() any; Last__O() any; SubSet_O_O__SortedSet(p0, p1 any) SortedSet; HeadSet_O__SortedSet(p0 any) SortedSet; TailSet_O__SortedSet(p0 any) SortedSet }

func (t *Collections_CheckedSortedSet) Self_Collections_CheckedSortedSet() *Collections_CheckedSortedSet { return t }

func (t *Collections_CheckedSortedSet) Is_SortedSet() {}

func (t *Collections_CheckedSortedSet) Is_SequencedSet() {}

func (t *Collections_CheckedSortedSet) Is_SequencedCollection() {}

const Collections_CheckedSortedSet_serialVersionUID int64 = 1599911165492914959

func (t *Collections_CheckedSortedSet) Reversed__SequencedSet() SequencedSet { return SortedSet_Reversed__SequencedSet(t) }

func (t *Collections_CheckedSortedSet) TailSet_O__SortedSet(p0 any) SortedSet { return t.Impl_TailSet_O__SortedSet(t, p0) }

func (t *Collections_CheckedSortedSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_CheckedSortedSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CheckedSortedSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_CheckedSortedSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CheckedSortedSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_CheckedSortedSet) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *Collections_CheckedSortedSet) Reversed__SequencedCollection() SequencedCollection { return SortedSet_Reversed__SequencedCollection(t) }

func (t *Collections_CheckedSortedSet) HeadSet_O__SortedSet(p0 any) SortedSet { return t.Impl_HeadSet_O__SortedSet(t, p0) }

func (t *Collections_CheckedSortedSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSortedSet) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_CheckedSortedSet) Reversed__SortedSet() SortedSet { return SortedSet_Reversed__SortedSet(t) }

func (t *Collections_CheckedSortedSet) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *Collections_CheckedSortedSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CheckedSortedSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CheckedSortedSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSortedSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_CheckedSortedSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CheckedSortedSet) CheckedCopyOf_Collection__Collection(p0 Collection) Collection { return t.Impl_CheckedCopyOf_Collection__Collection(t, p0) }

func (t *Collections_CheckedSortedSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_CheckedSortedSet) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *Collections_CheckedSortedSet) SubSet_O_O__SortedSet(p0, p1 any) SortedSet { return t.Impl_SubSet_O_O__SortedSet(t, p0, p1) }

func (t *Collections_CheckedSortedSet) RemoveLast__O() any { return SortedSet_RemoveLast__O(t) }

func (t *Collections_CheckedSortedSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSortedSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CheckedSortedSet) First__O() any { return t.Impl_First__O(t) }

func (t *Collections_CheckedSortedSet) RemoveFirst__O() any { return SortedSet_RemoveFirst__O(t) }

func (t *Collections_CheckedSortedSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_CheckedSortedSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_CheckedSortedSet) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *Collections_CheckedSortedSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_CheckedSortedSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CheckedSortedSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CheckedSortedSet) TypeCheck_O__O(p0 any) any { return t.Impl_TypeCheck_O__O(t, p0) }

func (t *Collections_CheckedSortedSet) Last__O() any { return t.Impl_Last__O(t) }

func (t *Collections_CheckedSortedSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_CheckedSortedSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_CheckedSortedSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CheckedSortedSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CheckedSortedSet) GetClass__Class() *Class { return Collections_CheckedSortedSet_class }

func (t *Collections_CheckedSortedSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CheckedSortedSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CheckedSortedSet_InstanceOf(x any) bool { _, ok := x.(Collections_CheckedSortedSet_I); return ok }

func Collections_CheckedSortedSet_Cast(x any) Collections_CheckedSortedSet_I { if x == nil { return nil }; v, ok := x.(Collections_CheckedSortedSet_I); if !ok { panic(ClassCast(x, Collections_CheckedSortedSet_class)) }; return v }



type Collections_CopiesList struct{ AbstractList; F_n int32; F_element any }

func (t *Collections_CopiesList) Is_RandomAccess() {}

func (t *Collections_CopiesList) Is_Serializable() {}

const Collections_CopiesList_serialVersionUID int64 = 2739099268398711800

var Collections_CopiesList_init ClassInit

func Collections_CopiesList_Init() { if !Collections_CopiesList_init.Done() { Collections_CopiesList_init.Run(Collections_CopiesList_clinit) } }

func Collections_CopiesList_clinit() {}

func (t *Collections_CopiesList) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__List() }

func (t *Collections_CopiesList) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_CopiesList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_CopiesList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Collections_CopiesList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_CopiesList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_CopiesList) Sort_Comparator__V(p0 Comparator) { List_Sort_Comparator__V(t, p0) }

func (t *Collections_CopiesList) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *Collections_CopiesList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_CopiesList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Collections_CopiesList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { List_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Collections_CopiesList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_CopiesList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_CopiesList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_CopiesList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_CopiesList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_CopiesList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_CopiesList) GetLast__O() any { return List_GetLast__O(t) }

func (t *Collections_CopiesList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Collections_CopiesList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_CopiesList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_CopiesList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Collections_CopiesList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_CopiesList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Collections_CopiesList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_CopiesList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_CopiesList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_CopiesList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_CopiesList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_CopiesList) GetClass__Class() *Class { return Collections_CopiesList_class }

func (t *Collections_CopiesList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_CopiesList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_CopiesList_InstanceOf(x any) bool { _, ok := x.(*Collections_CopiesList); return ok }

func Collections_CopiesList_Cast(x any) *Collections_CopiesList { if x == nil { return nil }; v, ok := x.(*Collections_CopiesList); if !ok { panic(ClassCast(x, Collections_CopiesList_class)) }; return v }



type Collections_EmptyEnumeration struct{ Object }

func (t *Collections_EmptyEnumeration) Is_Enumeration() {}

var Collections_EmptyEnumeration_EMPTY_ENUMERATION *Collections_EmptyEnumeration

var Collections_EmptyEnumeration_init ClassInit

func Collections_EmptyEnumeration_Init() { if !Collections_EmptyEnumeration_init.Done() { Collections_EmptyEnumeration_init.Run(Collections_EmptyEnumeration_clinit) } }

func Collections_EmptyEnumeration_clinit() { Collections_EmptyEnumeration_EMPTY_ENUMERATION = Collections_EmptyEnumeration_New() }

func Collections_EmptyEnumeration_New() *Collections_EmptyEnumeration { Collections_EmptyEnumeration_Init(); t := &Collections_EmptyEnumeration{}; t.Ctor(); return t }

func (t *Collections_EmptyEnumeration) Ctor() {}

func (t *Collections_EmptyEnumeration) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_EmptyEnumeration) GetClass__Class() *Class { return Collections_EmptyEnumeration_class }

func (t *Collections_EmptyEnumeration) ToString__String() *String { return Object_toString(t) }

func (t *Collections_EmptyEnumeration) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_EmptyEnumeration) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_EmptyEnumeration_InstanceOf(x any) bool { _, ok := x.(*Collections_EmptyEnumeration); return ok }

func Collections_EmptyEnumeration_Cast(x any) *Collections_EmptyEnumeration { if x == nil { return nil }; v, ok := x.(*Collections_EmptyEnumeration); if !ok { panic(ClassCast(x, Collections_EmptyEnumeration_class)) }; return v }



type Collections_EmptyIterator struct{ Object }

type Collections_EmptyIterator_I interface{ Object_I; Iterator; Self_Collections_EmptyIterator() *Collections_EmptyIterator; HasNext__Z() bool; Next__O() any; Remove__V(); ForEachRemaining_Consumer__V(p0 Consumer) }

func (t *Collections_EmptyIterator) Self_Collections_EmptyIterator() *Collections_EmptyIterator { return t }

func (t *Collections_EmptyIterator) Is_Iterator() {}

var Collections_EmptyIterator_EMPTY_ITERATOR Collections_EmptyIterator_I

var Collections_EmptyIterator_init ClassInit

func Collections_EmptyIterator_Init() { if !Collections_EmptyIterator_init.Done() { Collections_EmptyIterator_init.Run(Collections_EmptyIterator_clinit) } }

func Collections_EmptyIterator_clinit() { Collections_EmptyIterator_EMPTY_ITERATOR = Collections_EmptyIterator_New() }

func Collections_EmptyIterator_New() *Collections_EmptyIterator { Collections_EmptyIterator_Init(); t := &Collections_EmptyIterator{}; t.Ctor(t); return t }

func (t *Collections_EmptyIterator) Ctor(this Collections_EmptyIterator_I) {}

func (t *Collections_EmptyIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *Collections_EmptyIterator) Next__O() any { return t.Impl_Next__O(t) }

func (t *Collections_EmptyIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *Collections_EmptyIterator) ForEachRemaining_Consumer__V(p0 Consumer) { t.Impl_ForEachRemaining_Consumer__V(t, p0) }

func (t *Collections_EmptyIterator) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_EmptyIterator) GetClass__Class() *Class { return Collections_EmptyIterator_class }

func (t *Collections_EmptyIterator) ToString__String() *String { return Object_toString(t) }

func (t *Collections_EmptyIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_EmptyIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_EmptyIterator_InstanceOf(x any) bool { _, ok := x.(Collections_EmptyIterator_I); return ok }

func Collections_EmptyIterator_Cast(x any) Collections_EmptyIterator_I { if x == nil { return nil }; v, ok := x.(Collections_EmptyIterator_I); if !ok { panic(ClassCast(x, Collections_EmptyIterator_class)) }; return v }



type Collections_EmptyList struct{ AbstractList }

func (t *Collections_EmptyList) Is_RandomAccess() {}

func (t *Collections_EmptyList) Is_Serializable() {}

const Collections_EmptyList_serialVersionUID int64 = 8842843931221139166

func Collections_EmptyList_New() *Collections_EmptyList { t := &Collections_EmptyList{}; t.Ctor(); return t }

func (t *Collections_EmptyList) Ctor() { t.AbstractList.Ctor(t) }

func (t *Collections_EmptyList) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__List() }

func (t *Collections_EmptyList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_EmptyList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *Collections_EmptyList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Collections_EmptyList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_EmptyList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_EmptyList) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *Collections_EmptyList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Collections_EmptyList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_EmptyList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_EmptyList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_EmptyList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_EmptyList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_EmptyList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Collections_EmptyList) GetLast__O() any { return List_GetLast__O(t) }

func (t *Collections_EmptyList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Collections_EmptyList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Collections_EmptyList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Collections_EmptyList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_EmptyList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Collections_EmptyList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_EmptyList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_EmptyList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_EmptyList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_EmptyList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_EmptyList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_EmptyList) GetClass__Class() *Class { return Collections_EmptyList_class }

func (t *Collections_EmptyList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_EmptyList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_EmptyList_InstanceOf(x any) bool { _, ok := x.(*Collections_EmptyList); return ok }

func Collections_EmptyList_Cast(x any) *Collections_EmptyList { if x == nil { return nil }; v, ok := x.(*Collections_EmptyList); if !ok { panic(ClassCast(x, Collections_EmptyList_class)) }; return v }



type Collections_EmptyListIterator struct{ Collections_EmptyIterator }

func (t *Collections_EmptyListIterator) Is_ListIterator() {}

var Collections_EmptyListIterator_EMPTY_ITERATOR *Collections_EmptyListIterator

var Collections_EmptyListIterator_init ClassInit

func Collections_EmptyListIterator_Init() { if !Collections_EmptyListIterator_init.Done() { Collections_EmptyListIterator_init.Run(Collections_EmptyListIterator_clinit) } }

func Collections_EmptyListIterator_clinit() { Collections_EmptyIterator_Init(); Collections_EmptyListIterator_EMPTY_ITERATOR = Collections_EmptyListIterator_New() }

func Collections_EmptyListIterator_New() *Collections_EmptyListIterator { Collections_EmptyListIterator_Init(); t := &Collections_EmptyListIterator{}; t.Ctor(); return t }

func (t *Collections_EmptyListIterator) Ctor() { t.Collections_EmptyIterator.Ctor(t) }

func (t *Collections_EmptyListIterator) Next__O() any { return t.Impl_Next__O(t) }

func (t *Collections_EmptyListIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *Collections_EmptyListIterator) ForEachRemaining_Consumer__V(p0 Consumer) { t.Impl_ForEachRemaining_Consumer__V(t, p0) }

func (t *Collections_EmptyListIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *Collections_EmptyListIterator) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_EmptyListIterator) GetClass__Class() *Class { return Collections_EmptyListIterator_class }

func (t *Collections_EmptyListIterator) ToString__String() *String { return Object_toString(t) }

func (t *Collections_EmptyListIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_EmptyListIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_EmptyListIterator_InstanceOf(x any) bool { _, ok := x.(*Collections_EmptyListIterator); return ok }

func Collections_EmptyListIterator_Cast(x any) *Collections_EmptyListIterator { if x == nil { return nil }; v, ok := x.(*Collections_EmptyListIterator); if !ok { panic(ClassCast(x, Collections_EmptyListIterator_class)) }; return v }



type Collections_EmptyMap struct{ AbstractMap }

func (t *Collections_EmptyMap) Is_Serializable() {}

const Collections_EmptyMap_serialVersionUID int64 = 6428348081105594320

func Collections_EmptyMap_New() *Collections_EmptyMap { t := &Collections_EmptyMap{}; t.Ctor(); return t }

func (t *Collections_EmptyMap) Ctor() { t.AbstractMap.Ctor(t) }

func (t *Collections_EmptyMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_EmptyMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_EmptyMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_EmptyMap) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Collections_EmptyMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_EmptyMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_EmptyMap) GetClass__Class() *Class { return Collections_EmptyMap_class }

func (t *Collections_EmptyMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_EmptyMap_InstanceOf(x any) bool { _, ok := x.(*Collections_EmptyMap); return ok }

func Collections_EmptyMap_Cast(x any) *Collections_EmptyMap { if x == nil { return nil }; v, ok := x.(*Collections_EmptyMap); if !ok { panic(ClassCast(x, Collections_EmptyMap_class)) }; return v }



type Collections_EmptySet struct{ AbstractSet }

func (t *Collections_EmptySet) Is_Serializable() {}

const Collections_EmptySet_serialVersionUID int64 = 1582296315990362920

func Collections_EmptySet_New() *Collections_EmptySet { t := &Collections_EmptySet{}; t.Ctor(); return t }

func (t *Collections_EmptySet) Ctor() { t.AbstractSet.Ctor(t) }

func (t *Collections_EmptySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_EmptySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_EmptySet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_EmptySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_EmptySet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Collections_EmptySet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Collections_EmptySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_EmptySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_EmptySet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_EmptySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_EmptySet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_EmptySet) GetClass__Class() *Class { return Collections_EmptySet_class }

func (t *Collections_EmptySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_EmptySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_EmptySet_InstanceOf(x any) bool { _, ok := x.(*Collections_EmptySet); return ok }

func Collections_EmptySet_Cast(x any) *Collections_EmptySet { if x == nil { return nil }; v, ok := x.(*Collections_EmptySet); if !ok { panic(ClassCast(x, Collections_EmptySet_class)) }; return v }



type Collections_ReverseComparator struct{ Object }

func (t *Collections_ReverseComparator) Is_Comparator() {}

func (t *Collections_ReverseComparator) Is_Serializable() {}

const Collections_ReverseComparator_serialVersionUID int64 = 7207038068494060240

var Collections_ReverseComparator_REVERSE_ORDER *Collections_ReverseComparator

var Collections_ReverseComparator_init ClassInit

func Collections_ReverseComparator_Init() { if !Collections_ReverseComparator_init.Done() { Collections_ReverseComparator_init.Run(Collections_ReverseComparator_clinit) } }

func Collections_ReverseComparator_clinit() { Collections_ReverseComparator_REVERSE_ORDER = Collections_ReverseComparator_New() }

func Collections_ReverseComparator_New() *Collections_ReverseComparator { Collections_ReverseComparator_Init(); t := &Collections_ReverseComparator{}; t.Ctor(); return t }

func (t *Collections_ReverseComparator) Ctor() {}

func (t *Collections_ReverseComparator) Compare_O_O__I(p0, p1 any) int32 { return t.Compare_Comparable_Comparable__I(Comparable_Cast(p0), Comparable_Cast(p1)) }

func (t *Collections_ReverseComparator) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *Collections_ReverseComparator) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *Collections_ReverseComparator) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *Collections_ReverseComparator) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *Collections_ReverseComparator) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *Collections_ReverseComparator) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *Collections_ReverseComparator) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *Collections_ReverseComparator) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *Collections_ReverseComparator) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_ReverseComparator) GetClass__Class() *Class { return Collections_ReverseComparator_class }

func (t *Collections_ReverseComparator) ToString__String() *String { return Object_toString(t) }

func (t *Collections_ReverseComparator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_ReverseComparator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_ReverseComparator_InstanceOf(x any) bool { _, ok := x.(*Collections_ReverseComparator); return ok }

func Collections_ReverseComparator_Cast(x any) *Collections_ReverseComparator { if x == nil { return nil }; v, ok := x.(*Collections_ReverseComparator); if !ok { panic(ClassCast(x, Collections_ReverseComparator_class)) }; return v }



type Collections_ReverseComparator2 struct{ Object; F_cmp Comparator }

func (t *Collections_ReverseComparator2) Is_Comparator() {}

func (t *Collections_ReverseComparator2) Is_Serializable() {}

const Collections_ReverseComparator2_serialVersionUID int64 = 4374092139857

var Collections_ReverseComparator2_init ClassInit

func Collections_ReverseComparator2_Init() { if !Collections_ReverseComparator2_init.Done() { Collections_ReverseComparator2_init.Run(Collections_ReverseComparator2_clinit) } }

func Collections_ReverseComparator2_clinit() {}

func (t *Collections_ReverseComparator2) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *Collections_ReverseComparator2) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *Collections_ReverseComparator2) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *Collections_ReverseComparator2) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *Collections_ReverseComparator2) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *Collections_ReverseComparator2) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *Collections_ReverseComparator2) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *Collections_ReverseComparator2) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *Collections_ReverseComparator2) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_ReverseComparator2) GetClass__Class() *Class { return Collections_ReverseComparator2_class }

func (t *Collections_ReverseComparator2) ToString__String() *String { return Object_toString(t) }

func (t *Collections_ReverseComparator2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_ReverseComparator2) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_ReverseComparator2_InstanceOf(x any) bool { _, ok := x.(*Collections_ReverseComparator2); return ok }

func Collections_ReverseComparator2_Cast(x any) *Collections_ReverseComparator2 { if x == nil { return nil }; v, ok := x.(*Collections_ReverseComparator2); if !ok { panic(ClassCast(x, Collections_ReverseComparator2_class)) }; return v }



type Collections_SequencedSetFromMap struct{ Collections_SetFromMap }

func (t *Collections_SequencedSetFromMap) Is_SequencedSet() {}

func (t *Collections_SequencedSetFromMap) Is_SequencedCollection() {}

const Collections_SequencedSetFromMap_serialVersionUID int64 = -3943479744841433802

func (t *Collections_SequencedSetFromMap) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *Collections_SequencedSetFromMap) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SequencedSetFromMap) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SequencedSetFromMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SequencedSetFromMap) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SequencedSetFromMap) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SequencedSetFromMap) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SequencedSetFromMap) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SequencedSetFromMap) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SequencedSetFromMap) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SequencedSetFromMap) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SequencedSetFromMap) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SequencedSetFromMap) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SequencedSetFromMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SequencedSetFromMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SequencedSetFromMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SequencedSetFromMap) GetClass__Class() *Class { return Collections_SequencedSetFromMap_class }

func (t *Collections_SequencedSetFromMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SequencedSetFromMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SequencedSetFromMap_InstanceOf(x any) bool { _, ok := x.(*Collections_SequencedSetFromMap); return ok }

func Collections_SequencedSetFromMap_Cast(x any) *Collections_SequencedSetFromMap { if x == nil { return nil }; v, ok := x.(*Collections_SequencedSetFromMap); if !ok { panic(ClassCast(x, Collections_SequencedSetFromMap_class)) }; return v }



type Collections_SetFromMap struct{ AbstractSet; F_m Map; F_s Set }

type Collections_SetFromMap_I interface{ AbstractSet_I; Set; Serializable; Collection; Iterable; Self_Collections_SetFromMap() *Collections_SetFromMap; Clear__V(); Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; Add_O__Z(p0 any) bool; Iterator__Iterator() Iterator; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; ContainsAll_Collection__Z(p0 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; ForEach_Consumer__V(p0 Consumer); RemoveIf_Predicate__Z(p0 Predicate) bool; Spliterator__Spliterator() Spliterator; Stream__Stream() Stream; ParallelStream__Stream() Stream }

func (t *Collections_SetFromMap) Self_Collections_SetFromMap() *Collections_SetFromMap { return t }

func (t *Collections_SetFromMap) Is_Serializable() {}

const Collections_SetFromMap_serialVersionUID int64 = 2454657854757543876

func (t *Collections_SetFromMap) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SetFromMap) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SetFromMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SetFromMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SetFromMap) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SetFromMap) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SetFromMap) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SetFromMap) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SetFromMap) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SetFromMap) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SetFromMap) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SetFromMap) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SetFromMap) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SetFromMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SetFromMap) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SetFromMap) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SetFromMap) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SetFromMap) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SetFromMap) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SetFromMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SetFromMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SetFromMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SetFromMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SetFromMap) GetClass__Class() *Class { return Collections_SetFromMap_class }

func (t *Collections_SetFromMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SetFromMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SetFromMap_InstanceOf(x any) bool { _, ok := x.(Collections_SetFromMap_I); return ok }

func Collections_SetFromMap_Cast(x any) Collections_SetFromMap_I { if x == nil { return nil }; v, ok := x.(Collections_SetFromMap_I); if !ok { panic(ClassCast(x, Collections_SetFromMap_class)) }; return v }



type Collections_SingletonList struct{ AbstractList; F_element any }

func (t *Collections_SingletonList) Is_RandomAccess() {}

func (t *Collections_SingletonList) Is_Serializable() {}

const Collections_SingletonList_serialVersionUID int64 = 3093736618740652951

func (t *Collections_SingletonList) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__List() }

func (t *Collections_SingletonList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_SingletonList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *Collections_SingletonList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SingletonList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SingletonList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SingletonList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_SingletonList) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *Collections_SingletonList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_SingletonList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Collections_SingletonList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_SingletonList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SingletonList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SingletonList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SingletonList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SingletonList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_SingletonList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Collections_SingletonList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Collections_SingletonList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SingletonList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SingletonList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Collections_SingletonList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Collections_SingletonList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_SingletonList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Collections_SingletonList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SingletonList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SingletonList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_SingletonList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_SingletonList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SingletonList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SingletonList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SingletonList) GetClass__Class() *Class { return Collections_SingletonList_class }

func (t *Collections_SingletonList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SingletonList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SingletonList_InstanceOf(x any) bool { _, ok := x.(*Collections_SingletonList); return ok }

func Collections_SingletonList_Cast(x any) *Collections_SingletonList { if x == nil { return nil }; v, ok := x.(*Collections_SingletonList); if !ok { panic(ClassCast(x, Collections_SingletonList_class)) }; return v }



type Collections_SingletonMap struct{ AbstractMap; F_k, F_v any; F_keySet, F_entrySet Set; F_values Collection }

func (t *Collections_SingletonMap) Is_Serializable() {}

const Collections_SingletonMap_serialVersionUID int64 = -6979724477215052911

func (t *Collections_SingletonMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SingletonMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_SingletonMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_SingletonMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_SingletonMap) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Collections_SingletonMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SingletonMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SingletonMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SingletonMap) GetClass__Class() *Class { return Collections_SingletonMap_class }

func (t *Collections_SingletonMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SingletonMap_InstanceOf(x any) bool { _, ok := x.(*Collections_SingletonMap); return ok }

func Collections_SingletonMap_Cast(x any) *Collections_SingletonMap { if x == nil { return nil }; v, ok := x.(*Collections_SingletonMap); if !ok { panic(ClassCast(x, Collections_SingletonMap_class)) }; return v }



type Collections_SingletonSet struct{ AbstractSet; F_element any }

func (t *Collections_SingletonSet) Is_Serializable() {}

const Collections_SingletonSet_serialVersionUID int64 = 3193687207550431679

func (t *Collections_SingletonSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SingletonSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SingletonSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SingletonSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SingletonSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SingletonSet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Collections_SingletonSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SingletonSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SingletonSet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Collections_SingletonSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SingletonSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SingletonSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SingletonSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SingletonSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SingletonSet) GetClass__Class() *Class { return Collections_SingletonSet_class }

func (t *Collections_SingletonSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SingletonSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SingletonSet_InstanceOf(x any) bool { _, ok := x.(*Collections_SingletonSet); return ok }

func Collections_SingletonSet_Cast(x any) *Collections_SingletonSet { if x == nil { return nil }; v, ok := x.(*Collections_SingletonSet); if !ok { panic(ClassCast(x, Collections_SingletonSet_class)) }; return v }



type Collections_SynchronizedCollection struct{ Object; F_c Collection; F_mutex any }

type Collections_SynchronizedCollection_I interface{ Object_I; Collection; Serializable; Iterable; Self_Collections_SynchronizedCollection() *Collections_SynchronizedCollection; Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; ToArray_IntFunction__O1(p0 IntFunction) *RefArray; Iterator__Iterator() Iterator; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; AddAll_Collection__Z(p0 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; Clear__V(); ForEach_Consumer__V(p0 Consumer); RemoveIf_Predicate__Z(p0 Predicate) bool; Spliterator__Spliterator() Spliterator; Stream__Stream() Stream; ParallelStream__Stream() Stream }

func (t *Collections_SynchronizedCollection) Self_Collections_SynchronizedCollection() *Collections_SynchronizedCollection { return t }

func (t *Collections_SynchronizedCollection) Is_Collection() {}

func (t *Collections_SynchronizedCollection) Is_Serializable() {}

func (t *Collections_SynchronizedCollection) Is_Iterable() {}

const Collections_SynchronizedCollection_serialVersionUID int64 = 3053995032091335093

func (t *Collections_SynchronizedCollection) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SynchronizedCollection) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SynchronizedCollection) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedCollection) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedCollection) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SynchronizedCollection) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedCollection) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SynchronizedCollection) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SynchronizedCollection) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedCollection) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SynchronizedCollection) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SynchronizedCollection) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SynchronizedCollection) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedCollection) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedCollection) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SynchronizedCollection) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SynchronizedCollection) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SynchronizedCollection) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SynchronizedCollection) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedCollection) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedCollection) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedCollection) GetClass__Class() *Class { return Collections_SynchronizedCollection_class }

func (t *Collections_SynchronizedCollection) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedCollection) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedCollection_InstanceOf(x any) bool { _, ok := x.(Collections_SynchronizedCollection_I); return ok }

func Collections_SynchronizedCollection_Cast(x any) Collections_SynchronizedCollection_I { if x == nil { return nil }; v, ok := x.(Collections_SynchronizedCollection_I); if !ok { panic(ClassCast(x, Collections_SynchronizedCollection_class)) }; return v }



type Collections_SynchronizedList struct{ Collections_SynchronizedCollection; F_list List; F_reversedView Collections_SynchronizedList_I; F_isReversed bool }

type Collections_SynchronizedList_I interface{ Collections_SynchronizedCollection_I; List; Collection; Serializable; SequencedCollection; Iterable; Self_Collections_SynchronizedList() *Collections_SynchronizedList; Get_I__O(p0 int32) any; Set_I_O__O(p0 int32, p1 any) any; Add_I_O__V(p0 int32, p1 any); Remove_I__O(p0 int32) any; IndexOf_O__I(p0 any) int32; LastIndexOf_O__I(p0 any) int32; AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; ListIterator__ListIterator() ListIterator; ListIterator_I__ListIterator(p0 int32) ListIterator; SubList_I_I__List(p0, p1 int32) List; ReplaceAll_UnaryOperator__V(p0 UnaryOperator); Sort_Comparator__V(p0 Comparator); AddFirst_O__V(p0 any); AddLast_O__V(p0 any); GetFirst__O() any; GetLast__O() any; RemoveFirst__O() any; RemoveLast__O() any; Reversed__List() List; Reversed__SequencedCollection() SequencedCollection }

func (t *Collections_SynchronizedList) Self_Collections_SynchronizedList() *Collections_SynchronizedList { return t }

func (t *Collections_SynchronizedList) Is_List() {}

func (t *Collections_SynchronizedList) Is_SequencedCollection() {}

const Collections_SynchronizedList_serialVersionUID int64 = -7754090372962971524

func (t *Collections_SynchronizedList) Impl_Reversed__SequencedCollection(this Collections_SynchronizedList_I) SequencedCollection { return this.Reversed__List() }

func (t *Collections_SynchronizedList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_SynchronizedList) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SynchronizedList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *Collections_SynchronizedList) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SynchronizedList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SynchronizedList) GetFirst__O() any { return t.Impl_GetFirst__O(t) }

func (t *Collections_SynchronizedList) Reversed__SequencedCollection() SequencedCollection { return t.Impl_Reversed__SequencedCollection(t) }

func (t *Collections_SynchronizedList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_SynchronizedList) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *Collections_SynchronizedList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *Collections_SynchronizedList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_SynchronizedList) AddFirst_O__V(p0 any) { t.Impl_AddFirst_O__V(t, p0) }

func (t *Collections_SynchronizedList) Reversed__List() List { return t.Impl_Reversed__List(t) }

func (t *Collections_SynchronizedList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Collections_SynchronizedList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_SynchronizedList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SynchronizedList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SynchronizedList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SynchronizedList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SynchronizedList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_SynchronizedList) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SynchronizedList) GetLast__O() any { return t.Impl_GetLast__O(t) }

func (t *Collections_SynchronizedList) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *Collections_SynchronizedList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedList) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *Collections_SynchronizedList) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SynchronizedList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_SynchronizedList) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SynchronizedList) AddLast_O__V(p0 any) { t.Impl_AddLast_O__V(t, p0) }

func (t *Collections_SynchronizedList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SynchronizedList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SynchronizedList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_SynchronizedList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_SynchronizedList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedList) GetClass__Class() *Class { return Collections_SynchronizedList_class }

func (t *Collections_SynchronizedList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedList_InstanceOf(x any) bool { _, ok := x.(Collections_SynchronizedList_I); return ok }

func Collections_SynchronizedList_Cast(x any) Collections_SynchronizedList_I { if x == nil { return nil }; v, ok := x.(Collections_SynchronizedList_I); if !ok { panic(ClassCast(x, Collections_SynchronizedList_class)) }; return v }



type Collections_SynchronizedMap struct{ Object; F_m Map; F_mutex any; F_keySet, F_entrySet Set; F_values Collection }

type Collections_SynchronizedMap_I interface{ Object_I; Map; Serializable; Self_Collections_SynchronizedMap() *Collections_SynchronizedMap; Size__I() int32; IsEmpty__Z() bool; ContainsKey_O__Z(p0 any) bool; ContainsValue_O__Z(p0 any) bool; Get_O__O(p0 any) any; Put_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; PutAll_Map__V(p0 Map); Clear__V(); KeySet__Set() Set; EntrySet__Set() Set; Values__Collection() Collection; GetOrDefault_O_O__O(p0, p1 any) any; ForEach_BiConsumer__V(p0 BiConsumer); ReplaceAll_BiFunction__V(p0 BiFunction); PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any }

func (t *Collections_SynchronizedMap) Self_Collections_SynchronizedMap() *Collections_SynchronizedMap { return t }

func (t *Collections_SynchronizedMap) Is_Map() {}

func (t *Collections_SynchronizedMap) Is_Serializable() {}

const Collections_SynchronizedMap_serialVersionUID int64 = 1978198479659022715

func (t *Collections_SynchronizedMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_SynchronizedMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_SynchronizedMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_SynchronizedMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_SynchronizedMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_SynchronizedMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_SynchronizedMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_SynchronizedMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_SynchronizedMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_SynchronizedMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_SynchronizedMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_SynchronizedMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_SynchronizedMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_SynchronizedMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_SynchronizedMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_SynchronizedMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_SynchronizedMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedMap) GetClass__Class() *Class { return Collections_SynchronizedMap_class }

func (t *Collections_SynchronizedMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedMap_InstanceOf(x any) bool { _, ok := x.(Collections_SynchronizedMap_I); return ok }

func Collections_SynchronizedMap_Cast(x any) Collections_SynchronizedMap_I { if x == nil { return nil }; v, ok := x.(Collections_SynchronizedMap_I); if !ok { panic(ClassCast(x, Collections_SynchronizedMap_class)) }; return v }



type Collections_SynchronizedNavigableMap struct{ Collections_SynchronizedSortedMap; F_nm NavigableMap }

func (t *Collections_SynchronizedNavigableMap) Is_NavigableMap() {}

const Collections_SynchronizedNavigableMap_serialVersionUID int64 = 699392247599746807

func (t *Collections_SynchronizedNavigableMap) KeySet__Set() Set { return t.KeySet__NavigableSet() }

func (t *Collections_SynchronizedNavigableMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_SynchronizedNavigableMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedNavigableMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedNavigableMap) FirstKey__O() any { return t.Impl_FirstKey__O(t) }

func (t *Collections_SynchronizedNavigableMap) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_SynchronizedNavigableMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_SynchronizedNavigableMap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_SynchronizedNavigableMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) Reversed__SortedMap() SortedMap { return NavigableMap_Reversed__SortedMap(t) }

func (t *Collections_SynchronizedNavigableMap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_SynchronizedNavigableMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_SynchronizedNavigableMap) Reversed__SequencedMap() SequencedMap { return NavigableMap_Reversed__SequencedMap(t) }

func (t *Collections_SynchronizedNavigableMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_SynchronizedNavigableMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_SynchronizedNavigableMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_SynchronizedNavigableMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_SynchronizedNavigableMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedNavigableMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_SynchronizedNavigableMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_SynchronizedNavigableMap) LastKey__O() any { return t.Impl_LastKey__O(t) }

func (t *Collections_SynchronizedNavigableMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_SynchronizedNavigableMap) Reversed__NavigableMap() NavigableMap { return NavigableMap_Reversed__NavigableMap(t) }

func (t *Collections_SynchronizedNavigableMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_SynchronizedNavigableMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_SynchronizedNavigableMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_SynchronizedNavigableMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedNavigableMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedNavigableMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedNavigableMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedNavigableMap) GetClass__Class() *Class { return Collections_SynchronizedNavigableMap_class }

func (t *Collections_SynchronizedNavigableMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedNavigableMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedNavigableMap_InstanceOf(x any) bool { _, ok := x.(*Collections_SynchronizedNavigableMap); return ok }

func Collections_SynchronizedNavigableMap_Cast(x any) *Collections_SynchronizedNavigableMap { if x == nil { return nil }; v, ok := x.(*Collections_SynchronizedNavigableMap); if !ok { panic(ClassCast(x, Collections_SynchronizedNavigableMap_class)) }; return v }



type Collections_SynchronizedNavigableSet struct{ Collections_SynchronizedSortedSet; F_ns NavigableSet }

func (t *Collections_SynchronizedNavigableSet) Is_NavigableSet() {}

const Collections_SynchronizedNavigableSet_serialVersionUID int64 = -5505529816273629798

func (t *Collections_SynchronizedNavigableSet) SubSet_O_O__SortedSet(p0, p1 any) SortedSet { return t.SubSet_O_O__NavigableSet(p0, p1) }

func (t *Collections_SynchronizedNavigableSet) HeadSet_O__SortedSet(p0 any) SortedSet { return t.HeadSet_O__NavigableSet(p0) }

func (t *Collections_SynchronizedNavigableSet) TailSet_O__SortedSet(p0 any) SortedSet { return t.TailSet_O__NavigableSet(p0) }

func (t *Collections_SynchronizedNavigableSet) Reversed__SequencedSet() SequencedSet { return NavigableSet_Reversed__SequencedSet(t) }

func (t *Collections_SynchronizedNavigableSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SynchronizedNavigableSet) Reversed__NavigableSet() NavigableSet { return NavigableSet_Reversed__NavigableSet(t) }

func (t *Collections_SynchronizedNavigableSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedNavigableSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedNavigableSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SynchronizedNavigableSet) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *Collections_SynchronizedNavigableSet) Reversed__SequencedCollection() SequencedCollection { return NavigableSet_Reversed__SequencedCollection(t) }

func (t *Collections_SynchronizedNavigableSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_SynchronizedNavigableSet) Reversed__SortedSet() SortedSet { return NavigableSet_Reversed__SortedSet(t) }

func (t *Collections_SynchronizedNavigableSet) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *Collections_SynchronizedNavigableSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SynchronizedNavigableSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SynchronizedNavigableSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SynchronizedNavigableSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SynchronizedNavigableSet) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *Collections_SynchronizedNavigableSet) RemoveLast__O() any { return NavigableSet_RemoveLast__O(t) }

func (t *Collections_SynchronizedNavigableSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedNavigableSet) First__O() any { return t.Impl_First__O(t) }

func (t *Collections_SynchronizedNavigableSet) RemoveFirst__O() any { return NavigableSet_RemoveFirst__O(t) }

func (t *Collections_SynchronizedNavigableSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SynchronizedNavigableSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SynchronizedNavigableSet) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *Collections_SynchronizedNavigableSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) Last__O() any { return t.Impl_Last__O(t) }

func (t *Collections_SynchronizedNavigableSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedNavigableSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedNavigableSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedNavigableSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedNavigableSet) GetClass__Class() *Class { return Collections_SynchronizedNavigableSet_class }

func (t *Collections_SynchronizedNavigableSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedNavigableSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedNavigableSet_InstanceOf(x any) bool { _, ok := x.(*Collections_SynchronizedNavigableSet); return ok }

func Collections_SynchronizedNavigableSet_Cast(x any) *Collections_SynchronizedNavigableSet { if x == nil { return nil }; v, ok := x.(*Collections_SynchronizedNavigableSet); if !ok { panic(ClassCast(x, Collections_SynchronizedNavigableSet_class)) }; return v }



type Collections_SynchronizedRandomAccessList struct{ Collections_SynchronizedList }

func (t *Collections_SynchronizedRandomAccessList) Is_RandomAccess() {}

const Collections_SynchronizedRandomAccessList_serialVersionUID int64 = 1530674583602358482

func (t *Collections_SynchronizedRandomAccessList) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__List() }

func (t *Collections_SynchronizedRandomAccessList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SynchronizedRandomAccessList) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedRandomAccessList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedRandomAccessList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) GetFirst__O() any { return t.Impl_GetFirst__O(t) }

func (t *Collections_SynchronizedRandomAccessList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_SynchronizedRandomAccessList) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_SynchronizedRandomAccessList) AddFirst_O__V(p0 any) { t.Impl_AddFirst_O__V(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SynchronizedRandomAccessList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SynchronizedRandomAccessList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_SynchronizedRandomAccessList) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SynchronizedRandomAccessList) GetLast__O() any { return t.Impl_GetLast__O(t) }

func (t *Collections_SynchronizedRandomAccessList) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *Collections_SynchronizedRandomAccessList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedRandomAccessList) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *Collections_SynchronizedRandomAccessList) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SynchronizedRandomAccessList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_SynchronizedRandomAccessList) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) AddLast_O__V(p0 any) { t.Impl_AddLast_O__V(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedRandomAccessList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedRandomAccessList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedRandomAccessList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedRandomAccessList) GetClass__Class() *Class { return Collections_SynchronizedRandomAccessList_class }

func (t *Collections_SynchronizedRandomAccessList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedRandomAccessList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedRandomAccessList_InstanceOf(x any) bool { _, ok := x.(*Collections_SynchronizedRandomAccessList); return ok }

func Collections_SynchronizedRandomAccessList_Cast(x any) *Collections_SynchronizedRandomAccessList { if x == nil { return nil }; v, ok := x.(*Collections_SynchronizedRandomAccessList); if !ok { panic(ClassCast(x, Collections_SynchronizedRandomAccessList_class)) }; return v }



type Collections_SynchronizedSet struct{ Collections_SynchronizedCollection }

type Collections_SynchronizedSet_I interface{ Collections_SynchronizedCollection_I; Set; Collection; Serializable; Iterable; Self_Collections_SynchronizedSet() *Collections_SynchronizedSet }

func (t *Collections_SynchronizedSet) Self_Collections_SynchronizedSet() *Collections_SynchronizedSet { return t }

func (t *Collections_SynchronizedSet) Is_Set() {}

const Collections_SynchronizedSet_serialVersionUID int64 = 487447009682186044

func (t *Collections_SynchronizedSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SynchronizedSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SynchronizedSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SynchronizedSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SynchronizedSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SynchronizedSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SynchronizedSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SynchronizedSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SynchronizedSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SynchronizedSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SynchronizedSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SynchronizedSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SynchronizedSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedSet) GetClass__Class() *Class { return Collections_SynchronizedSet_class }

func (t *Collections_SynchronizedSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedSet_InstanceOf(x any) bool { _, ok := x.(Collections_SynchronizedSet_I); return ok }

func Collections_SynchronizedSet_Cast(x any) Collections_SynchronizedSet_I { if x == nil { return nil }; v, ok := x.(Collections_SynchronizedSet_I); if !ok { panic(ClassCast(x, Collections_SynchronizedSet_class)) }; return v }



type Collections_SynchronizedSortedMap struct{ Collections_SynchronizedMap; F_sm SortedMap }

type Collections_SynchronizedSortedMap_I interface{ Collections_SynchronizedMap_I; SortedMap; Map; Serializable; SequencedMap; Self_Collections_SynchronizedSortedMap() *Collections_SynchronizedSortedMap; Comparator__Comparator() Comparator; SubMap_O_O__SortedMap(p0, p1 any) SortedMap; HeadMap_O__SortedMap(p0 any) SortedMap; TailMap_O__SortedMap(p0 any) SortedMap; FirstKey__O() any; LastKey__O() any }

func (t *Collections_SynchronizedSortedMap) Self_Collections_SynchronizedSortedMap() *Collections_SynchronizedSortedMap { return t }

func (t *Collections_SynchronizedSortedMap) Is_SortedMap() {}

func (t *Collections_SynchronizedSortedMap) Is_SequencedMap() {}

const Collections_SynchronizedSortedMap_serialVersionUID int64 = -8798146769416483793

func (t *Collections_SynchronizedSortedMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_SynchronizedSortedMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedSortedMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedSortedMap) SubMap_O_O__SortedMap(p0, p1 any) SortedMap { return t.Impl_SubMap_O_O__SortedMap(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) FirstKey__O() any { return t.Impl_FirstKey__O(t) }

func (t *Collections_SynchronizedSortedMap) PollFirstEntry__Map_Entry() Map_Entry { return SequencedMap_PollFirstEntry__Map_Entry(t) }

func (t *Collections_SynchronizedSortedMap) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_SynchronizedSortedMap) FirstEntry__Map_Entry() Map_Entry { return SequencedMap_FirstEntry__Map_Entry(t) }

func (t *Collections_SynchronizedSortedMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_SynchronizedSortedMap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_SynchronizedSortedMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) Reversed__SortedMap() SortedMap { return SortedMap_Reversed__SortedMap(t) }

func (t *Collections_SynchronizedSortedMap) LastEntry__Map_Entry() Map_Entry { return SequencedMap_LastEntry__Map_Entry(t) }

func (t *Collections_SynchronizedSortedMap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_SynchronizedSortedMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_SynchronizedSortedMap) Reversed__SequencedMap() SequencedMap { return SortedMap_Reversed__SequencedMap(t) }

func (t *Collections_SynchronizedSortedMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_SynchronizedSortedMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_SynchronizedSortedMap) HeadMap_O__SortedMap(p0 any) SortedMap { return t.Impl_HeadMap_O__SortedMap(t, p0) }

func (t *Collections_SynchronizedSortedMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_SynchronizedSortedMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_SynchronizedSortedMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedSortedMap) PollLastEntry__Map_Entry() Map_Entry { return SequencedMap_PollLastEntry__Map_Entry(t) }

func (t *Collections_SynchronizedSortedMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_SynchronizedSortedMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_SynchronizedSortedMap) TailMap_O__SortedMap(p0 any) SortedMap { return t.Impl_TailMap_O__SortedMap(t, p0) }

func (t *Collections_SynchronizedSortedMap) LastKey__O() any { return t.Impl_LastKey__O(t) }

func (t *Collections_SynchronizedSortedMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_SynchronizedSortedMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_SynchronizedSortedMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_SynchronizedSortedMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_SynchronizedSortedMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_SynchronizedSortedMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedSortedMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedSortedMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedSortedMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedSortedMap) GetClass__Class() *Class { return Collections_SynchronizedSortedMap_class }

func (t *Collections_SynchronizedSortedMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedSortedMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedSortedMap_InstanceOf(x any) bool { _, ok := x.(Collections_SynchronizedSortedMap_I); return ok }

func Collections_SynchronizedSortedMap_Cast(x any) Collections_SynchronizedSortedMap_I { if x == nil { return nil }; v, ok := x.(Collections_SynchronizedSortedMap_I); if !ok { panic(ClassCast(x, Collections_SynchronizedSortedMap_class)) }; return v }



type Collections_SynchronizedSortedSet struct{ Collections_SynchronizedSet; F_ss SortedSet }

type Collections_SynchronizedSortedSet_I interface{ Collections_SynchronizedSet_I; SortedSet; Set; Collection; Serializable; SequencedSet; Iterable; SequencedCollection; Self_Collections_SynchronizedSortedSet() *Collections_SynchronizedSortedSet; Comparator__Comparator() Comparator; SubSet_O_O__SortedSet(p0, p1 any) SortedSet; HeadSet_O__SortedSet(p0 any) SortedSet; TailSet_O__SortedSet(p0 any) SortedSet; First__O() any; Last__O() any }

func (t *Collections_SynchronizedSortedSet) Self_Collections_SynchronizedSortedSet() *Collections_SynchronizedSortedSet { return t }

func (t *Collections_SynchronizedSortedSet) Is_SortedSet() {}

func (t *Collections_SynchronizedSortedSet) Is_SequencedSet() {}

func (t *Collections_SynchronizedSortedSet) Is_SequencedCollection() {}

const Collections_SynchronizedSortedSet_serialVersionUID int64 = 8695801310862127406

func (t *Collections_SynchronizedSortedSet) Reversed__SequencedSet() SequencedSet { return SortedSet_Reversed__SequencedSet(t) }

func (t *Collections_SynchronizedSortedSet) TailSet_O__SortedSet(p0 any) SortedSet { return t.Impl_TailSet_O__SortedSet(t, p0) }

func (t *Collections_SynchronizedSortedSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_SynchronizedSortedSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_SynchronizedSortedSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_SynchronizedSortedSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_SynchronizedSortedSet) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *Collections_SynchronizedSortedSet) Reversed__SequencedCollection() SequencedCollection { return SortedSet_Reversed__SequencedCollection(t) }

func (t *Collections_SynchronizedSortedSet) HeadSet_O__SortedSet(p0 any) SortedSet { return t.Impl_HeadSet_O__SortedSet(t, p0) }

func (t *Collections_SynchronizedSortedSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_SynchronizedSortedSet) Reversed__SortedSet() SortedSet { return SortedSet_Reversed__SortedSet(t) }

func (t *Collections_SynchronizedSortedSet) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *Collections_SynchronizedSortedSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_SynchronizedSortedSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_SynchronizedSortedSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_SynchronizedSortedSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_SynchronizedSortedSet) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *Collections_SynchronizedSortedSet) SubSet_O_O__SortedSet(p0, p1 any) SortedSet { return t.Impl_SubSet_O_O__SortedSet(t, p0, p1) }

func (t *Collections_SynchronizedSortedSet) RemoveLast__O() any { return SortedSet_RemoveLast__O(t) }

func (t *Collections_SynchronizedSortedSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_SynchronizedSortedSet) First__O() any { return t.Impl_First__O(t) }

func (t *Collections_SynchronizedSortedSet) RemoveFirst__O() any { return SortedSet_RemoveFirst__O(t) }

func (t *Collections_SynchronizedSortedSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_SynchronizedSortedSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_SynchronizedSortedSet) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *Collections_SynchronizedSortedSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) Last__O() any { return t.Impl_Last__O(t) }

func (t *Collections_SynchronizedSortedSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_SynchronizedSortedSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_SynchronizedSortedSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_SynchronizedSortedSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_SynchronizedSortedSet) GetClass__Class() *Class { return Collections_SynchronizedSortedSet_class }

func (t *Collections_SynchronizedSortedSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_SynchronizedSortedSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_SynchronizedSortedSet_InstanceOf(x any) bool { _, ok := x.(Collections_SynchronizedSortedSet_I); return ok }

func Collections_SynchronizedSortedSet_Cast(x any) Collections_SynchronizedSortedSet_I { if x == nil { return nil }; v, ok := x.(Collections_SynchronizedSortedSet_I); if !ok { panic(ClassCast(x, Collections_SynchronizedSortedSet_class)) }; return v }



type Collections_UnmodifiableCollection struct{ Object; F_c Collection }

type Collections_UnmodifiableCollection_I interface{ Object_I; Collection; Serializable; Iterable; Self_Collections_UnmodifiableCollection() *Collections_UnmodifiableCollection; Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; ToArray_IntFunction__O1(p0 IntFunction) *RefArray; Iterator__Iterator() Iterator; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; AddAll_Collection__Z(p0 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; Clear__V(); ForEach_Consumer__V(p0 Consumer); RemoveIf_Predicate__Z(p0 Predicate) bool; Spliterator__Spliterator() Spliterator; Stream__Stream() Stream; ParallelStream__Stream() Stream }

func (t *Collections_UnmodifiableCollection) Self_Collections_UnmodifiableCollection() *Collections_UnmodifiableCollection { return t }

func (t *Collections_UnmodifiableCollection) Is_Collection() {}

func (t *Collections_UnmodifiableCollection) Is_Serializable() {}

func (t *Collections_UnmodifiableCollection) Is_Iterable() {}

const Collections_UnmodifiableCollection_serialVersionUID int64 = 1820017752578914078

func (t *Collections_UnmodifiableCollection) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableCollection) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableCollection) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableCollection) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableCollection) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableCollection) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableCollection) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableCollection) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableCollection) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableCollection) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableCollection) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableCollection) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableCollection) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableCollection) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableCollection) GetClass__Class() *Class { return Collections_UnmodifiableCollection_class }

func (t *Collections_UnmodifiableCollection) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableCollection) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableCollection_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableCollection_I); return ok }

func Collections_UnmodifiableCollection_Cast(x any) Collections_UnmodifiableCollection_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableCollection_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableCollection_class)) }; return v }



type Collections_UnmodifiableCollection_1 struct{ Object; F_i Iterator; F_this_0 Collections_UnmodifiableCollection_I }

func (t *Collections_UnmodifiableCollection_1) Is_Iterator() {}

func Collections_UnmodifiableCollection_1_New_Collections_UnmodifiableCollection(p0 Collections_UnmodifiableCollection_I) *Collections_UnmodifiableCollection_1 { t := &Collections_UnmodifiableCollection_1{}; t.Ctor_Collections_UnmodifiableCollection(p0); return t }

func (t *Collections_UnmodifiableCollection_1) Ctor_Collections_UnmodifiableCollection(this_0 Collections_UnmodifiableCollection_I) { A2g_NotNull[Collections_UnmodifiableCollection_I](this_0); t.F_this_0 = this_0; t.F_i = this_0.Self_Collections_UnmodifiableCollection().F_c.Iterator__Iterator() }

func (t *Collections_UnmodifiableCollection_1) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableCollection_1) GetClass__Class() *Class { return Collections_UnmodifiableCollection_1_class }

func (t *Collections_UnmodifiableCollection_1) ToString__String() *String { return Object_toString(t) }

func (t *Collections_UnmodifiableCollection_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableCollection_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableCollection_1_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableCollection_1); return ok }

func Collections_UnmodifiableCollection_1_Cast(x any) *Collections_UnmodifiableCollection_1 { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableCollection_1); if !ok { panic(ClassCast(x, Collections_UnmodifiableCollection_1_class)) }; return v }



type Collections_UnmodifiableList struct{ Collections_UnmodifiableCollection; F_list List }

type Collections_UnmodifiableList_I interface{ Collections_UnmodifiableCollection_I; List; Collection; Serializable; SequencedCollection; Iterable; Self_Collections_UnmodifiableList() *Collections_UnmodifiableList; Get_I__O(p0 int32) any; Set_I_O__O(p0 int32, p1 any) any; Add_I_O__V(p0 int32, p1 any); Remove_I__O(p0 int32) any; IndexOf_O__I(p0 any) int32; LastIndexOf_O__I(p0 any) int32; AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; ReplaceAll_UnaryOperator__V(p0 UnaryOperator); Sort_Comparator__V(p0 Comparator); ListIterator__ListIterator() ListIterator; ListIterator_I__ListIterator(p0 int32) ListIterator; SubList_I_I__List(p0, p1 int32) List }

func (t *Collections_UnmodifiableList) Self_Collections_UnmodifiableList() *Collections_UnmodifiableList { return t }

func (t *Collections_UnmodifiableList) Is_List() {}

func (t *Collections_UnmodifiableList) Is_SequencedCollection() {}

const Collections_UnmodifiableList_serialVersionUID int64 = -283967356065247728

func (t *Collections_UnmodifiableList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_UnmodifiableList) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *Collections_UnmodifiableList) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Collections_UnmodifiableList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *Collections_UnmodifiableList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableList) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *Collections_UnmodifiableList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *Collections_UnmodifiableList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_UnmodifiableList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Collections_UnmodifiableList) Reversed__List() List { return List_Reversed__List(t) }

func (t *Collections_UnmodifiableList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Collections_UnmodifiableList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_UnmodifiableList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_UnmodifiableList) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableList) GetLast__O() any { return List_GetLast__O(t) }

func (t *Collections_UnmodifiableList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Collections_UnmodifiableList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Collections_UnmodifiableList) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_UnmodifiableList) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Collections_UnmodifiableList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_UnmodifiableList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_UnmodifiableList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableList) GetClass__Class() *Class { return Collections_UnmodifiableList_class }

func (t *Collections_UnmodifiableList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableList_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableList_I); return ok }

func Collections_UnmodifiableList_Cast(x any) Collections_UnmodifiableList_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableList_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableList_class)) }; return v }



type Collections_UnmodifiableList_1 struct{ Object; F_i ListIterator; F_this_0 Collections_UnmodifiableList_I; F_val_index int32 }

func (t *Collections_UnmodifiableList_1) Is_ListIterator() {}

func (t *Collections_UnmodifiableList_1) Is_Iterator() {}

func Collections_UnmodifiableList_1_New_Collections_UnmodifiableList_I(p0 Collections_UnmodifiableList_I, p1 int32) *Collections_UnmodifiableList_1 { t := &Collections_UnmodifiableList_1{}; t.Ctor_Collections_UnmodifiableList_I(p0, p1); return t }

func (t *Collections_UnmodifiableList_1) Ctor_Collections_UnmodifiableList_I(this_0 Collections_UnmodifiableList_I, val_index int32) { t.F_val_index = val_index; A2g_NotNull[Collections_UnmodifiableList_I](this_0); t.F_this_0 = this_0; t.F_i = this_0.Self_Collections_UnmodifiableList().F_list.ListIterator_I__ListIterator(t.F_val_index) }

func (t *Collections_UnmodifiableList_1) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableList_1) GetClass__Class() *Class { return Collections_UnmodifiableList_1_class }

func (t *Collections_UnmodifiableList_1) ToString__String() *String { return Object_toString(t) }

func (t *Collections_UnmodifiableList_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableList_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableList_1_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableList_1); return ok }

func Collections_UnmodifiableList_1_Cast(x any) *Collections_UnmodifiableList_1 { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableList_1); if !ok { panic(ClassCast(x, Collections_UnmodifiableList_1_class)) }; return v }



type Collections_UnmodifiableMap struct{ Object; F_m Map; F_keySet, F_entrySet Set; F_values Collection }

type Collections_UnmodifiableMap_I interface{ Object_I; Map; Serializable; Self_Collections_UnmodifiableMap() *Collections_UnmodifiableMap; Size__I() int32; IsEmpty__Z() bool; ContainsKey_O__Z(p0 any) bool; ContainsValue_O__Z(p0 any) bool; Get_O__O(p0 any) any; Put_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; PutAll_Map__V(p0 Map); Clear__V(); KeySet__Set() Set; EntrySet__Set() Set; Values__Collection() Collection; GetOrDefault_O_O__O(p0, p1 any) any; ForEach_BiConsumer__V(p0 BiConsumer); ReplaceAll_BiFunction__V(p0 BiFunction); PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O_O__Z(p0, p1, p2 any) bool; Replace_O_O__O(p0, p1 any) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any }

func (t *Collections_UnmodifiableMap) Self_Collections_UnmodifiableMap() *Collections_UnmodifiableMap { return t }

func (t *Collections_UnmodifiableMap) Is_Map() {}

func (t *Collections_UnmodifiableMap) Is_Serializable() {}

const Collections_UnmodifiableMap_serialVersionUID int64 = -1034234728574286014

func (t *Collections_UnmodifiableMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_UnmodifiableMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_UnmodifiableMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_UnmodifiableMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_UnmodifiableMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_UnmodifiableMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_UnmodifiableMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_UnmodifiableMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_UnmodifiableMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_UnmodifiableMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_UnmodifiableMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_UnmodifiableMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_UnmodifiableMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_UnmodifiableMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_UnmodifiableMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableMap) GetClass__Class() *Class { return Collections_UnmodifiableMap_class }

func (t *Collections_UnmodifiableMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableMap_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableMap_I); return ok }

func Collections_UnmodifiableMap_Cast(x any) Collections_UnmodifiableMap_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableMap_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableMap_class)) }; return v }



type Collections_UnmodifiableMap_UnmodifiableEntrySet struct{ Collections_UnmodifiableSet }

const Collections_UnmodifiableMap_UnmodifiableEntrySet_serialVersionUID int64 = 7854390611657943733

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) GetClass__Class() *Class { return Collections_UnmodifiableMap_UnmodifiableEntrySet_class }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet); return ok }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_Cast(x any) *Collections_UnmodifiableMap_UnmodifiableEntrySet { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet); if !ok { panic(ClassCast(x, Collections_UnmodifiableMap_UnmodifiableEntrySet_class)) }; return v }



type Collections_UnmodifiableMap_UnmodifiableEntrySet_1 struct{ Object; F_i Iterator; F_this_0 *Collections_UnmodifiableMap_UnmodifiableEntrySet }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) Is_Iterator() {}

func Collections_UnmodifiableMap_UnmodifiableEntrySet_1_New_Collections_UnmodifiableMap_UnmodifiableEntrySet(p0 *Collections_UnmodifiableMap_UnmodifiableEntrySet) *Collections_UnmodifiableMap_UnmodifiableEntrySet_1 { t := &Collections_UnmodifiableMap_UnmodifiableEntrySet_1{}; t.Ctor_Collections_UnmodifiableMap_UnmodifiableEntrySet(p0); return t }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) Ctor_Collections_UnmodifiableMap_UnmodifiableEntrySet(this_0 *Collections_UnmodifiableMap_UnmodifiableEntrySet) { NN(this_0); t.F_this_0 = this_0; t.F_i = this_0.F_c.Iterator__Iterator() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) Next__O() any { return t.Next__Map_Entry() }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) GetClass__Class() *Class { return Collections_UnmodifiableMap_UnmodifiableEntrySet_1_class }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) ToString__String() *String { return Object_toString(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_1_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet_1); return ok }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_1_Cast(x any) *Collections_UnmodifiableMap_UnmodifiableEntrySet_1 { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet_1); if !ok { panic(ClassCast(x, Collections_UnmodifiableMap_UnmodifiableEntrySet_1_class)) }; return v }



type Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry struct{ Object; F_e Map_Entry }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) Is_Map_Entry() {}

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) GetClass__Class() *Class { return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_class }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry); return ok }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_Cast(x any) *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry); if !ok { panic(ClassCast(x, Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntry_class)) }; return v }



type Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator struct{ Object; F_s Spliterator }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) Is_Spliterator() {}

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) GetClass__Class() *Class { return Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator_class }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator); return ok }

func Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator_Cast(x any) *Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator); if !ok { panic(ClassCast(x, Collections_UnmodifiableMap_UnmodifiableEntrySet_UnmodifiableEntrySetSpliterator_class)) }; return v }



type Collections_UnmodifiableNavigableMap struct{ Collections_UnmodifiableSortedMap; F_nm NavigableMap }

type Collections_UnmodifiableNavigableMap_I interface{ Collections_UnmodifiableSortedMap_I; NavigableMap; Serializable; SortedMap; Map; SequencedMap; Self_Collections_UnmodifiableNavigableMap() *Collections_UnmodifiableNavigableMap; LowerKey_O__O(p0 any) any; FloorKey_O__O(p0 any) any; CeilingKey_O__O(p0 any) any; HigherKey_O__O(p0 any) any; LowerEntry_O__Map_Entry(p0 any) Map_Entry; FloorEntry_O__Map_Entry(p0 any) Map_Entry; CeilingEntry_O__Map_Entry(p0 any) Map_Entry; HigherEntry_O__Map_Entry(p0 any) Map_Entry; FirstEntry__Map_Entry() Map_Entry; LastEntry__Map_Entry() Map_Entry; PollFirstEntry__Map_Entry() Map_Entry; PollLastEntry__Map_Entry() Map_Entry; DescendingMap__NavigableMap() NavigableMap; NavigableKeySet__NavigableSet() NavigableSet; DescendingKeySet__NavigableSet() NavigableSet; SubMap_O_Z_O_Z__NavigableMap(p0 any, p1 bool, p2 any, p3 bool) NavigableMap; HeadMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap; TailMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap }

func (t *Collections_UnmodifiableNavigableMap) Self_Collections_UnmodifiableNavigableMap() *Collections_UnmodifiableNavigableMap { return t }

func (t *Collections_UnmodifiableNavigableMap) Is_NavigableMap() {}

const Collections_UnmodifiableNavigableMap_serialVersionUID int64 = -4858195264774772197

var Collections_UnmodifiableNavigableMap_EMPTY_NAVIGABLE_MAP *Collections_UnmodifiableNavigableMap_EmptyNavigableMap

var Collections_UnmodifiableNavigableMap_init ClassInit

func Collections_UnmodifiableNavigableMap_Init() { if !Collections_UnmodifiableNavigableMap_init.Done() { Collections_UnmodifiableNavigableMap_init.Run(Collections_UnmodifiableNavigableMap_clinit) } }

func Collections_UnmodifiableNavigableMap_clinit() { Collections_UnmodifiableNavigableMap_EMPTY_NAVIGABLE_MAP = Collections_UnmodifiableNavigableMap_EmptyNavigableMap_New() }

func (t *Collections_UnmodifiableNavigableMap) CeilingEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_CeilingEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) NavigableKeySet__NavigableSet() NavigableSet { return t.Impl_NavigableKeySet__NavigableSet(t) }

func (t *Collections_UnmodifiableNavigableMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableNavigableMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableNavigableMap) SubMap_O_O__SortedMap(p0, p1 any) SortedMap { return t.Impl_SubMap_O_O__SortedMap(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) FirstKey__O() any { return t.Impl_FirstKey__O(t) }

func (t *Collections_UnmodifiableNavigableMap) HigherEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_HigherEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) CeilingKey_O__O(p0 any) any { return t.Impl_CeilingKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) HigherKey_O__O(p0 any) any { return t.Impl_HigherKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) PollFirstEntry__Map_Entry() Map_Entry { return t.Impl_PollFirstEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_UnmodifiableNavigableMap) FloorEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_FloorEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) FirstEntry__Map_Entry() Map_Entry { return t.Impl_FirstEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap) SubMap_O_Z_O_Z__NavigableMap(p0 any, p1 bool, p2 any, p3 bool) NavigableMap { return t.Impl_SubMap_O_Z_O_Z__NavigableMap(t, p0, p1, p2, p3) }

func (t *Collections_UnmodifiableNavigableMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) LowerKey_O__O(p0 any) any { return t.Impl_LowerKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) LowerEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_LowerEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) DescendingMap__NavigableMap() NavigableMap { return t.Impl_DescendingMap__NavigableMap(t) }

func (t *Collections_UnmodifiableNavigableMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_UnmodifiableNavigableMap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_UnmodifiableNavigableMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) Reversed__SortedMap() SortedMap { return NavigableMap_Reversed__SortedMap(t) }

func (t *Collections_UnmodifiableNavigableMap) LastEntry__Map_Entry() Map_Entry { return t.Impl_LastEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap) HeadMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap { return t.Impl_HeadMap_O_Z__NavigableMap(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) Reversed__SequencedMap() SequencedMap { return NavigableMap_Reversed__SequencedMap(t) }

func (t *Collections_UnmodifiableNavigableMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_UnmodifiableNavigableMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_UnmodifiableNavigableMap) HeadMap_O__SortedMap(p0 any) SortedMap { return t.Impl_HeadMap_O__SortedMap(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_UnmodifiableNavigableMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableNavigableMap) PollLastEntry__Map_Entry() Map_Entry { return t.Impl_PollLastEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) TailMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap { return t.Impl_TailMap_O_Z__NavigableMap(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) DescendingKeySet__NavigableSet() NavigableSet { return t.Impl_DescendingKeySet__NavigableSet(t) }

func (t *Collections_UnmodifiableNavigableMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_UnmodifiableNavigableMap) TailMap_O__SortedMap(p0 any) SortedMap { return t.Impl_TailMap_O__SortedMap(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) LastKey__O() any { return t.Impl_LastKey__O(t) }

func (t *Collections_UnmodifiableNavigableMap) FloorKey_O__O(p0 any) any { return t.Impl_FloorKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) Reversed__NavigableMap() NavigableMap { return NavigableMap_Reversed__NavigableMap(t) }

func (t *Collections_UnmodifiableNavigableMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_UnmodifiableNavigableMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_UnmodifiableNavigableMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableNavigableMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableNavigableMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableNavigableMap) GetClass__Class() *Class { return Collections_UnmodifiableNavigableMap_class }

func (t *Collections_UnmodifiableNavigableMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableNavigableMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableNavigableMap_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableNavigableMap_I); return ok }

func Collections_UnmodifiableNavigableMap_Cast(x any) Collections_UnmodifiableNavigableMap_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableNavigableMap_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableNavigableMap_class)) }; return v }



type Collections_UnmodifiableNavigableMap_EmptyNavigableMap struct{ Collections_UnmodifiableNavigableMap }

const Collections_UnmodifiableNavigableMap_EmptyNavigableMap_serialVersionUID int64 = -2239321462712562324

var Collections_UnmodifiableNavigableMap_EmptyNavigableMap_init ClassInit

func Collections_UnmodifiableNavigableMap_EmptyNavigableMap_Init() { if !Collections_UnmodifiableNavigableMap_EmptyNavigableMap_init.Done() { Collections_UnmodifiableNavigableMap_EmptyNavigableMap_init.Run(Collections_UnmodifiableNavigableMap_EmptyNavigableMap_clinit) } }

func Collections_UnmodifiableNavigableMap_EmptyNavigableMap_clinit() { Collections_UnmodifiableNavigableMap_Init() }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) CeilingEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_CeilingEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) SubMap_O_O__SortedMap(p0, p1 any) SortedMap { return t.Impl_SubMap_O_O__SortedMap(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) FirstKey__O() any { return t.Impl_FirstKey__O(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) HigherEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_HigherEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) CeilingKey_O__O(p0 any) any { return t.Impl_CeilingKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) HigherKey_O__O(p0 any) any { return t.Impl_HigherKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) PollFirstEntry__Map_Entry() Map_Entry { return t.Impl_PollFirstEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) FloorEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_FloorEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) FirstEntry__Map_Entry() Map_Entry { return t.Impl_FirstEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) SubMap_O_Z_O_Z__NavigableMap(p0 any, p1 bool, p2 any, p3 bool) NavigableMap { return t.Impl_SubMap_O_Z_O_Z__NavigableMap(t, p0, p1, p2, p3) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) LowerKey_O__O(p0 any) any { return t.Impl_LowerKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) LowerEntry_O__Map_Entry(p0 any) Map_Entry { return t.Impl_LowerEntry_O__Map_Entry(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) DescendingMap__NavigableMap() NavigableMap { return t.Impl_DescendingMap__NavigableMap(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Reversed__SortedMap() SortedMap { return NavigableMap_Reversed__SortedMap(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) LastEntry__Map_Entry() Map_Entry { return t.Impl_LastEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) HeadMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap { return t.Impl_HeadMap_O_Z__NavigableMap(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Reversed__SequencedMap() SequencedMap { return NavigableMap_Reversed__SequencedMap(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) HeadMap_O__SortedMap(p0 any) SortedMap { return t.Impl_HeadMap_O__SortedMap(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) PollLastEntry__Map_Entry() Map_Entry { return t.Impl_PollLastEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) TailMap_O_Z__NavigableMap(p0 any, p1 bool) NavigableMap { return t.Impl_TailMap_O_Z__NavigableMap(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) DescendingKeySet__NavigableSet() NavigableSet { return t.Impl_DescendingKeySet__NavigableSet(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) TailMap_O__SortedMap(p0 any) SortedMap { return t.Impl_TailMap_O__SortedMap(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) LastKey__O() any { return t.Impl_LastKey__O(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) FloorKey_O__O(p0 any) any { return t.Impl_FloorKey_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Reversed__NavigableMap() NavigableMap { return NavigableMap_Reversed__NavigableMap(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) GetClass__Class() *Class { return Collections_UnmodifiableNavigableMap_EmptyNavigableMap_class }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableNavigableMap_EmptyNavigableMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableNavigableMap_EmptyNavigableMap_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableNavigableMap_EmptyNavigableMap); return ok }

func Collections_UnmodifiableNavigableMap_EmptyNavigableMap_Cast(x any) *Collections_UnmodifiableNavigableMap_EmptyNavigableMap { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableNavigableMap_EmptyNavigableMap); if !ok { panic(ClassCast(x, Collections_UnmodifiableNavigableMap_EmptyNavigableMap_class)) }; return v }



type Collections_UnmodifiableNavigableSet struct{ Collections_UnmodifiableSortedSet; F_ns NavigableSet }

type Collections_UnmodifiableNavigableSet_I interface{ Collections_UnmodifiableSortedSet_I; NavigableSet; Serializable; SortedSet; Set; Collection; SequencedSet; Iterable; SequencedCollection; Self_Collections_UnmodifiableNavigableSet() *Collections_UnmodifiableNavigableSet; Lower_O__O(p0 any) any; Floor_O__O(p0 any) any; Ceiling_O__O(p0 any) any; Higher_O__O(p0 any) any; PollFirst__O() any; PollLast__O() any; DescendingSet__NavigableSet() NavigableSet; DescendingIterator__Iterator() Iterator; SubSet_O_Z_O_Z__NavigableSet(p0 any, p1 bool, p2 any, p3 bool) NavigableSet; HeadSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet; TailSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet }

func (t *Collections_UnmodifiableNavigableSet) Self_Collections_UnmodifiableNavigableSet() *Collections_UnmodifiableNavigableSet { return t }

func (t *Collections_UnmodifiableNavigableSet) Is_NavigableSet() {}

const Collections_UnmodifiableNavigableSet_serialVersionUID int64 = -6027448201786391929

var Collections_UnmodifiableNavigableSet_EMPTY_NAVIGABLE_SET NavigableSet

var Collections_UnmodifiableNavigableSet_init ClassInit

func Collections_UnmodifiableNavigableSet_Init() { if !Collections_UnmodifiableNavigableSet_init.Done() { Collections_UnmodifiableNavigableSet_init.Run(Collections_UnmodifiableNavigableSet_clinit) } }

func Collections_UnmodifiableNavigableSet_clinit() { Collections_UnmodifiableNavigableSet_EMPTY_NAVIGABLE_SET = Collections_UnmodifiableNavigableSet_EmptyNavigableSet_New() }

func (t *Collections_UnmodifiableNavigableSet) Reversed__SequencedSet() SequencedSet { return NavigableSet_Reversed__SequencedSet(t) }

func (t *Collections_UnmodifiableNavigableSet) TailSet_O__SortedSet(p0 any) SortedSet { return t.Impl_TailSet_O__SortedSet(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableNavigableSet) Reversed__NavigableSet() NavigableSet { return NavigableSet_Reversed__NavigableSet(t) }

func (t *Collections_UnmodifiableNavigableSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableNavigableSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableNavigableSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) TailSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet { return t.Impl_TailSet_O_Z__NavigableSet(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableSet) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *Collections_UnmodifiableNavigableSet) Reversed__SequencedCollection() SequencedCollection { return NavigableSet_Reversed__SequencedCollection(t) }

func (t *Collections_UnmodifiableNavigableSet) HeadSet_O__SortedSet(p0 any) SortedSet { return t.Impl_HeadSet_O__SortedSet(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_UnmodifiableNavigableSet) DescendingSet__NavigableSet() NavigableSet { return t.Impl_DescendingSet__NavigableSet(t) }

func (t *Collections_UnmodifiableNavigableSet) Reversed__SortedSet() SortedSet { return NavigableSet_Reversed__SortedSet(t) }

func (t *Collections_UnmodifiableNavigableSet) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) PollLast__O() any { return t.Impl_PollLast__O(t) }

func (t *Collections_UnmodifiableNavigableSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) SubSet_O_Z_O_Z__NavigableSet(p0 any, p1 bool, p2 any, p3 bool) NavigableSet { return t.Impl_SubSet_O_Z_O_Z__NavigableSet(t, p0, p1, p2, p3) }

func (t *Collections_UnmodifiableNavigableSet) PollFirst__O() any { return t.Impl_PollFirst__O(t) }

func (t *Collections_UnmodifiableNavigableSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Lower_O__O(p0 any) any { return t.Impl_Lower_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableNavigableSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableNavigableSet) Floor_O__O(p0 any) any { return t.Impl_Floor_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableNavigableSet) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *Collections_UnmodifiableNavigableSet) SubSet_O_O__SortedSet(p0, p1 any) SortedSet { return t.Impl_SubSet_O_O__SortedSet(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableSet) RemoveLast__O() any { return NavigableSet_RemoveLast__O(t) }

func (t *Collections_UnmodifiableNavigableSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableNavigableSet) First__O() any { return t.Impl_First__O(t) }

func (t *Collections_UnmodifiableNavigableSet) RemoveFirst__O() any { return NavigableSet_RemoveFirst__O(t) }

func (t *Collections_UnmodifiableNavigableSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableNavigableSet) HeadSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet { return t.Impl_HeadSet_O_Z__NavigableSet(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableSet) Higher_O__O(p0 any) any { return t.Impl_Higher_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Ceiling_O__O(p0 any) any { return t.Impl_Ceiling_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) DescendingIterator__Iterator() Iterator { return t.Impl_DescendingIterator__Iterator(t) }

func (t *Collections_UnmodifiableNavigableSet) Last__O() any { return t.Impl_Last__O(t) }

func (t *Collections_UnmodifiableNavigableSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableNavigableSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableNavigableSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableNavigableSet) GetClass__Class() *Class { return Collections_UnmodifiableNavigableSet_class }

func (t *Collections_UnmodifiableNavigableSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableNavigableSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableNavigableSet_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableNavigableSet_I); return ok }

func Collections_UnmodifiableNavigableSet_Cast(x any) Collections_UnmodifiableNavigableSet_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableNavigableSet_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableNavigableSet_class)) }; return v }



type Collections_UnmodifiableNavigableSet_EmptyNavigableSet struct{ Collections_UnmodifiableNavigableSet }

const Collections_UnmodifiableNavigableSet_EmptyNavigableSet_serialVersionUID int64 = -6291252904449939134

var Collections_UnmodifiableNavigableSet_EmptyNavigableSet_init ClassInit

func Collections_UnmodifiableNavigableSet_EmptyNavigableSet_Init() { if !Collections_UnmodifiableNavigableSet_EmptyNavigableSet_init.Done() { Collections_UnmodifiableNavigableSet_EmptyNavigableSet_init.Run(Collections_UnmodifiableNavigableSet_EmptyNavigableSet_clinit) } }

func Collections_UnmodifiableNavigableSet_EmptyNavigableSet_clinit() { Collections_UnmodifiableNavigableSet_Init() }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Reversed__SequencedSet() SequencedSet { return NavigableSet_Reversed__SequencedSet(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) TailSet_O__SortedSet(p0 any) SortedSet { return t.Impl_TailSet_O__SortedSet(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Reversed__NavigableSet() NavigableSet { return NavigableSet_Reversed__NavigableSet(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) TailSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet { return t.Impl_TailSet_O_Z__NavigableSet(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Reversed__SequencedCollection() SequencedCollection { return NavigableSet_Reversed__SequencedCollection(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) HeadSet_O__SortedSet(p0 any) SortedSet { return t.Impl_HeadSet_O__SortedSet(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) DescendingSet__NavigableSet() NavigableSet { return t.Impl_DescendingSet__NavigableSet(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Reversed__SortedSet() SortedSet { return NavigableSet_Reversed__SortedSet(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) PollLast__O() any { return t.Impl_PollLast__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) SubSet_O_Z_O_Z__NavigableSet(p0 any, p1 bool, p2 any, p3 bool) NavigableSet { return t.Impl_SubSet_O_Z_O_Z__NavigableSet(t, p0, p1, p2, p3) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) PollFirst__O() any { return t.Impl_PollFirst__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Lower_O__O(p0 any) any { return t.Impl_Lower_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Floor_O__O(p0 any) any { return t.Impl_Floor_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) SubSet_O_O__SortedSet(p0, p1 any) SortedSet { return t.Impl_SubSet_O_O__SortedSet(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) RemoveLast__O() any { return NavigableSet_RemoveLast__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) First__O() any { return t.Impl_First__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) RemoveFirst__O() any { return NavigableSet_RemoveFirst__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) HeadSet_O_Z__NavigableSet(p0 any, p1 bool) NavigableSet { return t.Impl_HeadSet_O_Z__NavigableSet(t, p0, p1) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Higher_O__O(p0 any) any { return t.Impl_Higher_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Ceiling_O__O(p0 any) any { return t.Impl_Ceiling_O__O(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) DescendingIterator__Iterator() Iterator { return t.Impl_DescendingIterator__Iterator(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Last__O() any { return t.Impl_Last__O(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) GetClass__Class() *Class { return Collections_UnmodifiableNavigableSet_EmptyNavigableSet_class }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableNavigableSet_EmptyNavigableSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableNavigableSet_EmptyNavigableSet_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableNavigableSet_EmptyNavigableSet); return ok }

func Collections_UnmodifiableNavigableSet_EmptyNavigableSet_Cast(x any) *Collections_UnmodifiableNavigableSet_EmptyNavigableSet { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableNavigableSet_EmptyNavigableSet); if !ok { panic(ClassCast(x, Collections_UnmodifiableNavigableSet_EmptyNavigableSet_class)) }; return v }



type Collections_UnmodifiableRandomAccessList struct{ Collections_UnmodifiableList }

func (t *Collections_UnmodifiableRandomAccessList) Is_RandomAccess() {}

const Collections_UnmodifiableRandomAccessList_serialVersionUID int64 = -2542308836966382001

func (t *Collections_UnmodifiableRandomAccessList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableRandomAccessList) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableRandomAccessList) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableRandomAccessList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Collections_UnmodifiableRandomAccessList) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *Collections_UnmodifiableRandomAccessList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableRandomAccessList) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Collections_UnmodifiableRandomAccessList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Reversed__List() List { return List_Reversed__List(t) }

func (t *Collections_UnmodifiableRandomAccessList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableRandomAccessList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableRandomAccessList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Collections_UnmodifiableRandomAccessList) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableRandomAccessList) GetLast__O() any { return List_GetLast__O(t) }

func (t *Collections_UnmodifiableRandomAccessList) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Collections_UnmodifiableRandomAccessList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableRandomAccessList) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Collections_UnmodifiableRandomAccessList) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableRandomAccessList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Collections_UnmodifiableRandomAccessList) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableRandomAccessList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableRandomAccessList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableRandomAccessList) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableRandomAccessList) GetClass__Class() *Class { return Collections_UnmodifiableRandomAccessList_class }

func (t *Collections_UnmodifiableRandomAccessList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableRandomAccessList) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableRandomAccessList_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableRandomAccessList); return ok }

func Collections_UnmodifiableRandomAccessList_Cast(x any) *Collections_UnmodifiableRandomAccessList { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableRandomAccessList); if !ok { panic(ClassCast(x, Collections_UnmodifiableRandomAccessList_class)) }; return v }



type Collections_UnmodifiableSequencedCollection struct{ Collections_UnmodifiableCollection }

type Collections_UnmodifiableSequencedCollection_I interface{ Collections_UnmodifiableCollection_I; SequencedCollection; Serializable; Collection; Iterable; Self_Collections_UnmodifiableSequencedCollection() *Collections_UnmodifiableSequencedCollection; Reversed__SequencedCollection() SequencedCollection; AddFirst_O__V(p0 any); AddLast_O__V(p0 any); GetFirst__O() any; GetLast__O() any; RemoveFirst__O() any; RemoveLast__O() any }

func (t *Collections_UnmodifiableSequencedCollection) Self_Collections_UnmodifiableSequencedCollection() *Collections_UnmodifiableSequencedCollection { return t }

func (t *Collections_UnmodifiableSequencedCollection) Is_SequencedCollection() {}

const Collections_UnmodifiableSequencedCollection_serialVersionUID int64 = -6060065079711684830

func (t *Collections_UnmodifiableSequencedCollection) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableSequencedCollection) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableSequencedCollection) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableSequencedCollection) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) GetFirst__O() any { return t.Impl_GetFirst__O(t) }

func (t *Collections_UnmodifiableSequencedCollection) Reversed__SequencedCollection() SequencedCollection { return t.Impl_Reversed__SequencedCollection(t) }

func (t *Collections_UnmodifiableSequencedCollection) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) AddFirst_O__V(p0 any) { t.Impl_AddFirst_O__V(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableSequencedCollection) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableSequencedCollection) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableSequencedCollection) GetLast__O() any { return t.Impl_GetLast__O(t) }

func (t *Collections_UnmodifiableSequencedCollection) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *Collections_UnmodifiableSequencedCollection) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableSequencedCollection) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *Collections_UnmodifiableSequencedCollection) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableSequencedCollection) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) AddLast_O__V(p0 any) { t.Impl_AddLast_O__V(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedCollection) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableSequencedCollection) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableSequencedCollection) GetClass__Class() *Class { return Collections_UnmodifiableSequencedCollection_class }

func (t *Collections_UnmodifiableSequencedCollection) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableSequencedCollection) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableSequencedCollection_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableSequencedCollection_I); return ok }

func Collections_UnmodifiableSequencedCollection_Cast(x any) Collections_UnmodifiableSequencedCollection_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableSequencedCollection_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableSequencedCollection_class)) }; return v }



type Collections_UnmodifiableSequencedMap struct{ Collections_UnmodifiableMap }

func (t *Collections_UnmodifiableSequencedMap) Is_SequencedMap() {}

const Collections_UnmodifiableSequencedMap_serialVersionUID int64 = -8171676257373950636

func (t *Collections_UnmodifiableSequencedMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableSequencedMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableSequencedMap) FirstEntry__Map_Entry() Map_Entry { return SequencedMap_FirstEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableSequencedMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_UnmodifiableSequencedMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_UnmodifiableSequencedMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) LastEntry__Map_Entry() Map_Entry { return SequencedMap_LastEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableSequencedMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_UnmodifiableSequencedMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_UnmodifiableSequencedMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_UnmodifiableSequencedMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableSequencedMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_UnmodifiableSequencedMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_UnmodifiableSequencedMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_UnmodifiableSequencedMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_UnmodifiableSequencedMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableSequencedMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableSequencedMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableSequencedMap) GetClass__Class() *Class { return Collections_UnmodifiableSequencedMap_class }

func (t *Collections_UnmodifiableSequencedMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableSequencedMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableSequencedMap_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableSequencedMap); return ok }

func Collections_UnmodifiableSequencedMap_Cast(x any) *Collections_UnmodifiableSequencedMap { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableSequencedMap); if !ok { panic(ClassCast(x, Collections_UnmodifiableSequencedMap_class)) }; return v }



type Collections_UnmodifiableSequencedSet struct{ Collections_UnmodifiableSequencedCollection }

func (t *Collections_UnmodifiableSequencedSet) Is_SequencedSet() {}

func (t *Collections_UnmodifiableSequencedSet) Is_Set() {}

const Collections_UnmodifiableSequencedSet_serialVersionUID int64 = -2153469532349793522

func (t *Collections_UnmodifiableSequencedSet) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__SequencedSet() }

func (t *Collections_UnmodifiableSequencedSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableSequencedSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableSequencedSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableSequencedSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) GetFirst__O() any { return t.Impl_GetFirst__O(t) }

func (t *Collections_UnmodifiableSequencedSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) AddFirst_O__V(p0 any) { t.Impl_AddFirst_O__V(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableSequencedSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableSequencedSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableSequencedSet) GetLast__O() any { return t.Impl_GetLast__O(t) }

func (t *Collections_UnmodifiableSequencedSet) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *Collections_UnmodifiableSequencedSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableSequencedSet) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *Collections_UnmodifiableSequencedSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableSequencedSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) AddLast_O__V(p0 any) { t.Impl_AddLast_O__V(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSequencedSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableSequencedSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableSequencedSet) GetClass__Class() *Class { return Collections_UnmodifiableSequencedSet_class }

func (t *Collections_UnmodifiableSequencedSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableSequencedSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableSequencedSet_InstanceOf(x any) bool { _, ok := x.(*Collections_UnmodifiableSequencedSet); return ok }

func Collections_UnmodifiableSequencedSet_Cast(x any) *Collections_UnmodifiableSequencedSet { if x == nil { return nil }; v, ok := x.(*Collections_UnmodifiableSequencedSet); if !ok { panic(ClassCast(x, Collections_UnmodifiableSequencedSet_class)) }; return v }



type Collections_UnmodifiableSet struct{ Collections_UnmodifiableCollection }

type Collections_UnmodifiableSet_I interface{ Collections_UnmodifiableCollection_I; Set; Serializable; Collection; Iterable; Self_Collections_UnmodifiableSet() *Collections_UnmodifiableSet }

func (t *Collections_UnmodifiableSet) Self_Collections_UnmodifiableSet() *Collections_UnmodifiableSet { return t }

func (t *Collections_UnmodifiableSet) Is_Set() {}

const Collections_UnmodifiableSet_serialVersionUID int64 = -9215047833775013803

func (t *Collections_UnmodifiableSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableSet) GetClass__Class() *Class { return Collections_UnmodifiableSet_class }

func (t *Collections_UnmodifiableSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableSet_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableSet_I); return ok }

func Collections_UnmodifiableSet_Cast(x any) Collections_UnmodifiableSet_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableSet_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableSet_class)) }; return v }



type Collections_UnmodifiableSortedMap struct{ Collections_UnmodifiableMap; F_sm SortedMap }

type Collections_UnmodifiableSortedMap_I interface{ Collections_UnmodifiableMap_I; SortedMap; Serializable; Map; SequencedMap; Self_Collections_UnmodifiableSortedMap() *Collections_UnmodifiableSortedMap; Comparator__Comparator() Comparator; SubMap_O_O__SortedMap(p0, p1 any) SortedMap; HeadMap_O__SortedMap(p0 any) SortedMap; TailMap_O__SortedMap(p0 any) SortedMap; FirstKey__O() any; LastKey__O() any }

func (t *Collections_UnmodifiableSortedMap) Self_Collections_UnmodifiableSortedMap() *Collections_UnmodifiableSortedMap { return t }

func (t *Collections_UnmodifiableSortedMap) Is_SortedMap() {}

func (t *Collections_UnmodifiableSortedMap) Is_SequencedMap() {}

const Collections_UnmodifiableSortedMap_serialVersionUID int64 = -8806743815996713206

func (t *Collections_UnmodifiableSortedMap) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Collections_UnmodifiableSortedMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableSortedMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableSortedMap) SubMap_O_O__SortedMap(p0, p1 any) SortedMap { return t.Impl_SubMap_O_O__SortedMap(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) FirstKey__O() any { return t.Impl_FirstKey__O(t) }

func (t *Collections_UnmodifiableSortedMap) PollFirstEntry__Map_Entry() Map_Entry { return SequencedMap_PollFirstEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableSortedMap) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_UnmodifiableSortedMap) FirstEntry__Map_Entry() Map_Entry { return SequencedMap_FirstEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableSortedMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) SequencedValues__SequencedCollection() SequencedCollection { return SequencedMap_SequencedValues__SequencedCollection(t) }

func (t *Collections_UnmodifiableSortedMap) PutLast_O_O__O(p0, p1 any) any { return SortedMap_PutLast_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) SequencedEntrySet__SequencedSet() SequencedSet { return SequencedMap_SequencedEntrySet__SequencedSet(t) }

func (t *Collections_UnmodifiableSortedMap) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) Reversed__SortedMap() SortedMap { return SortedMap_Reversed__SortedMap(t) }

func (t *Collections_UnmodifiableSortedMap) LastEntry__Map_Entry() Map_Entry { return SequencedMap_LastEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableSortedMap) PutFirst_O_O__O(p0, p1 any) any { return SortedMap_PutFirst_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Collections_UnmodifiableSortedMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Collections_UnmodifiableSortedMap) Reversed__SequencedMap() SequencedMap { return SortedMap_Reversed__SequencedMap(t) }

func (t *Collections_UnmodifiableSortedMap) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Collections_UnmodifiableSortedMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Collections_UnmodifiableSortedMap) HeadMap_O__SortedMap(p0 any) SortedMap { return t.Impl_HeadMap_O__SortedMap(t, p0) }

func (t *Collections_UnmodifiableSortedMap) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Collections_UnmodifiableSortedMap) SequencedKeySet__SequencedSet() SequencedSet { return SequencedMap_SequencedKeySet__SequencedSet(t) }

func (t *Collections_UnmodifiableSortedMap) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableSortedMap) PollLastEntry__Map_Entry() Map_Entry { return SequencedMap_PollLastEntry__Map_Entry(t) }

func (t *Collections_UnmodifiableSortedMap) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Collections_UnmodifiableSortedMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Collections_UnmodifiableSortedMap) TailMap_O__SortedMap(p0 any) SortedMap { return t.Impl_TailMap_O__SortedMap(t, p0) }

func (t *Collections_UnmodifiableSortedMap) LastKey__O() any { return t.Impl_LastKey__O(t) }

func (t *Collections_UnmodifiableSortedMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Collections_UnmodifiableSortedMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Collections_UnmodifiableSortedMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Collections_UnmodifiableSortedMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Collections_UnmodifiableSortedMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Collections_UnmodifiableSortedMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableSortedMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableSortedMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableSortedMap) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableSortedMap) GetClass__Class() *Class { return Collections_UnmodifiableSortedMap_class }

func (t *Collections_UnmodifiableSortedMap) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableSortedMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableSortedMap_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableSortedMap_I); return ok }

func Collections_UnmodifiableSortedMap_Cast(x any) Collections_UnmodifiableSortedMap_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableSortedMap_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableSortedMap_class)) }; return v }



type Collections_UnmodifiableSortedSet struct{ Collections_UnmodifiableSet; F_ss SortedSet }

type Collections_UnmodifiableSortedSet_I interface{ Collections_UnmodifiableSet_I; SortedSet; Serializable; Set; Collection; SequencedSet; Iterable; SequencedCollection; Self_Collections_UnmodifiableSortedSet() *Collections_UnmodifiableSortedSet; Comparator__Comparator() Comparator; SubSet_O_O__SortedSet(p0, p1 any) SortedSet; HeadSet_O__SortedSet(p0 any) SortedSet; TailSet_O__SortedSet(p0 any) SortedSet; First__O() any; Last__O() any }

func (t *Collections_UnmodifiableSortedSet) Self_Collections_UnmodifiableSortedSet() *Collections_UnmodifiableSortedSet { return t }

func (t *Collections_UnmodifiableSortedSet) Is_SortedSet() {}

func (t *Collections_UnmodifiableSortedSet) Is_SequencedSet() {}

func (t *Collections_UnmodifiableSortedSet) Is_SequencedCollection() {}

const Collections_UnmodifiableSortedSet_serialVersionUID int64 = -4929149591599911165

func (t *Collections_UnmodifiableSortedSet) Reversed__SequencedSet() SequencedSet { return SortedSet_Reversed__SequencedSet(t) }

func (t *Collections_UnmodifiableSortedSet) TailSet_O__SortedSet(p0 any) SortedSet { return t.Impl_TailSet_O__SortedSet(t, p0) }

func (t *Collections_UnmodifiableSortedSet) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Collections_UnmodifiableSortedSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Collections_UnmodifiableSortedSet) Clear__V() { t.Impl_Clear__V(t) }

func (t *Collections_UnmodifiableSortedSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Collections_UnmodifiableSortedSet) GetFirst__O() any { return SortedSet_GetFirst__O(t) }

func (t *Collections_UnmodifiableSortedSet) Reversed__SequencedCollection() SequencedCollection { return SortedSet_Reversed__SequencedCollection(t) }

func (t *Collections_UnmodifiableSortedSet) HeadSet_O__SortedSet(p0 any) SortedSet { return t.Impl_HeadSet_O__SortedSet(t, p0) }

func (t *Collections_UnmodifiableSortedSet) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) Comparator__Comparator() Comparator { return t.Impl_Comparator__Comparator(t) }

func (t *Collections_UnmodifiableSortedSet) Reversed__SortedSet() SortedSet { return SortedSet_Reversed__SortedSet(t) }

func (t *Collections_UnmodifiableSortedSet) AddFirst_O__V(p0 any) { SortedSet_AddFirst_O__V(t, p0) }

func (t *Collections_UnmodifiableSortedSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *Collections_UnmodifiableSortedSet) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Collections_UnmodifiableSortedSet) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Collections_UnmodifiableSortedSet) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *Collections_UnmodifiableSortedSet) GetLast__O() any { return SortedSet_GetLast__O(t) }

func (t *Collections_UnmodifiableSortedSet) SubSet_O_O__SortedSet(p0, p1 any) SortedSet { return t.Impl_SubSet_O_O__SortedSet(t, p0, p1) }

func (t *Collections_UnmodifiableSortedSet) RemoveLast__O() any { return SortedSet_RemoveLast__O(t) }

func (t *Collections_UnmodifiableSortedSet) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Collections_UnmodifiableSortedSet) First__O() any { return t.Impl_First__O(t) }

func (t *Collections_UnmodifiableSortedSet) RemoveFirst__O() any { return SortedSet_RemoveFirst__O(t) }

func (t *Collections_UnmodifiableSortedSet) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *Collections_UnmodifiableSortedSet) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Collections_UnmodifiableSortedSet) AddLast_O__V(p0 any) { SortedSet_AddLast_O__V(t, p0) }

func (t *Collections_UnmodifiableSortedSet) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) Last__O() any { return t.Impl_Last__O(t) }

func (t *Collections_UnmodifiableSortedSet) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Collections_UnmodifiableSortedSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Collections_UnmodifiableSortedSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Collections_UnmodifiableSortedSet) Ref() any { if t == nil { return nil }; return t }

func (t *Collections_UnmodifiableSortedSet) GetClass__Class() *Class { return Collections_UnmodifiableSortedSet_class }

func (t *Collections_UnmodifiableSortedSet) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Collections_UnmodifiableSortedSet) CloneShallow() any { panic(CloneNotSupported(t)) }

func Collections_UnmodifiableSortedSet_InstanceOf(x any) bool { _, ok := x.(Collections_UnmodifiableSortedSet_I); return ok }

func Collections_UnmodifiableSortedSet_Cast(x any) Collections_UnmodifiableSortedSet_I { if x == nil { return nil }; v, ok := x.(Collections_UnmodifiableSortedSet_I); if !ok { panic(ClassCast(x, Collections_UnmodifiableSortedSet_class)) }; return v }
