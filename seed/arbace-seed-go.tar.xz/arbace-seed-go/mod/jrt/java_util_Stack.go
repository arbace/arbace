//line java_util_Stack.ae:1
package jrt







func Stack_New() *Stack { t := &Stack{}; t.Ctor(); return t }
//line :9:1
func (t *Stack) Ctor() { t.Vector.Ctor(t) }

func (t *Stack) Push_O__O(item any) any { t.AddElement_O__V(item); return item }

func (t *Stack) Pop__O() any { MonitorEnter(t); defer MonitorExit(t)
	var obj any; var len_ int32 = t.Size__I()

	obj = t.Peek__O()
	t.RemoveElementAt_I__V(len_ - 1)
//line :14:1
	return obj
}




func (t *Stack) Peek__O() any { MonitorEnter(t); defer MonitorExit(t)
	var len_ int32 = t.Size__I()
	if len_ == 0 { panic(Thrown(EmptyStackException_New())) }
	return t.ElementAt_I__O(len_ - 1)
}
func (t *Stack) Empty__Z() bool { return t.Size__I() == 0 }

func (t *Stack) Search_O__I(o any) int32 { MonitorEnter(t); defer MonitorExit(t)
	var i int32 = t.LastIndexOf_O__I(o); if i >= 0 { return t.Size__I() - i } else { return -1
	}
}

type Stack struct{ Vector }

const Stack_serialVersionUID int64 = 1224463164541339165

func (t *Stack) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *Stack) FirstElement__O() any { return t.Impl_FirstElement__O(t) }

func (t *Stack) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *Stack) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *Stack) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *Stack) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Stack) Clear__V() { t.Impl_Clear__V(t) }

func (t *Stack) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *Stack) LastElement__O() any { return t.Impl_LastElement__O(t) }

func (t *Stack) ElementData_I__O(p0 int32) any { return t.Impl_ElementData_I__O(t, p0) }

func (t *Stack) RemoveAllElements__V() { t.Impl_RemoveAllElements__V(t) }

func (t *Stack) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *Stack) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *Stack) Reversed__SequencedCollection() SequencedCollection { return List_Reversed__SequencedCollection(t) }

func (t *Stack) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *Stack) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *Stack) TrimToSize__V() { t.Impl_TrimToSize__V(t) }

func (t *Stack) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *Stack) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *Stack) CheckInvariants__V() { t.Impl_CheckInvariants__V(t) }

func (t *Stack) IndexOf_O_I__I(p0 any, p1 int32) int32 { return t.Impl_IndexOf_O_I__I(t, p0, p1) }

func (t *Stack) RemoveElement_O__Z(p0 any) bool { return t.Impl_RemoveElement_O__Z(t, p0) }

func (t *Stack) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *Stack) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *Stack) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *Stack) Reversed__List() List { return List_Reversed__List(t) }

func (t *Stack) RemoveElementAt_I__V(p0 int32) { t.Impl_RemoveElementAt_I__V(t, p0) }

func (t *Stack) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *Stack) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *Stack) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *Stack) EnsureCapacity_I__V(p0 int32) { t.Impl_EnsureCapacity_I__V(t, p0) }

func (t *Stack) SetElementAt_O_I__V(p0 any, p1 int32) { t.Impl_SetElementAt_O_I__V(t, p0, p1) }

func (t *Stack) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *Stack) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *Stack) InsertElementAt_O_I__V(p0 any, p1 int32) { t.Impl_InsertElementAt_O_I__V(t, p0, p1) }

func (t *Stack) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *Stack) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *Stack) ElementAt_I__O(p0 int32) any { return t.Impl_ElementAt_I__O(t, p0) }

func (t *Stack) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *Stack) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *Stack) LastIndexOf_O_I__I(p0 any, p1 int32) int32 { return t.Impl_LastIndexOf_O_I__I(t, p0, p1) }

func (t *Stack) GetLast__O() any { return List_GetLast__O(t) }

func (t *Stack) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *Stack) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *Stack) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Stack) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *Stack) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *Stack) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *Stack) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *Stack) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *Stack) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Stack) CopyInto_O1__V(p0 *RefArray) { t.Impl_CopyInto_O1__V(t, p0) }

func (t *Stack) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *Stack) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *Stack) Elements__Enumeration() Enumeration { return t.Impl_Elements__Enumeration(t) }

func (t *Stack) SetSize_I__V(p0 int32) { t.Impl_SetSize_I__V(t, p0) }

func (t *Stack) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *Stack) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *Stack) AddElement_O__V(p0 any) { t.Impl_AddElement_O__V(t, p0) }

func (t *Stack) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Stack) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Stack) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Stack) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Stack) Ref() any { if t == nil { return nil }; return t }

func (t *Stack) GetClass__Class() *Class { return Stack_class }

func (t *Stack) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func Stack_InstanceOf(x any) bool { _, ok := x.(*Stack); return ok }

func Stack_Cast(x any) *Stack { if x == nil { return nil }; v, ok := x.(*Stack); if !ok { panic(ClassCast(x, Stack_class)) }; return v }
