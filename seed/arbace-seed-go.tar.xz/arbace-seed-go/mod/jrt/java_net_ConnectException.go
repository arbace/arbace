//line java_net_ConnectException.ae:1
package jrt








func ConnectException_New_String(p0 *String) *ConnectException { t := &ConnectException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *ConnectException) Ctor_String(msg *String) { t.SocketException.Ctor_String(t, msg) }

func ConnectException_New() *ConnectException { t := &ConnectException{}; t.Ctor(); return t }
//line :12:1
func (t *ConnectException) Ctor() { t.SocketException.Ctor(t) }







type ConnectException struct{ SocketException }

const ConnectException_serialVersionUID int64 = 3831404271622369215

func (t *ConnectException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ConnectException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ConnectException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ConnectException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ConnectException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ConnectException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ConnectException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ConnectException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ConnectException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ConnectException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ConnectException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ConnectException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ConnectException) Ref() any { if t == nil { return nil }; return t }

func (t *ConnectException) GetClass__Class() *Class { return ConnectException_class }

func (t *ConnectException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ConnectException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ConnectException_InstanceOf(x any) bool { _, ok := x.(*ConnectException); return ok }

func ConnectException_Cast(x any) *ConnectException { if x == nil { return nil }; v, ok := x.(*ConnectException); if !ok { panic(ClassCast(x, ConnectException_class)) }; return v }
