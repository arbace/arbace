//line java_security_NoSuchProviderException.ae:1
package jrt








func NoSuchProviderException_New() *NoSuchProviderException { t := &NoSuchProviderException{}; t.Ctor(); return t }
//line :10:1
func (t *NoSuchProviderException) Ctor() { t.GeneralSecurityException.Ctor(t) }

func NoSuchProviderException_New_String(p0 *String) *NoSuchProviderException { t := &NoSuchProviderException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NoSuchProviderException) Ctor_String(msg *String) { t.GeneralSecurityException.Ctor_String(t, msg) }







type NoSuchProviderException struct{ GeneralSecurityException }

const NoSuchProviderException_serialVersionUID int64 = 8488111756688534474

func (t *NoSuchProviderException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoSuchProviderException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoSuchProviderException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoSuchProviderException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoSuchProviderException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoSuchProviderException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoSuchProviderException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoSuchProviderException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoSuchProviderException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoSuchProviderException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoSuchProviderException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoSuchProviderException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoSuchProviderException) Ref() any { if t == nil { return nil }; return t }

func (t *NoSuchProviderException) GetClass__Class() *Class { return NoSuchProviderException_class }

func (t *NoSuchProviderException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoSuchProviderException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoSuchProviderException_InstanceOf(x any) bool { _, ok := x.(*NoSuchProviderException); return ok }

func NoSuchProviderException_Cast(x any) *NoSuchProviderException { if x == nil { return nil }; v, ok := x.(*NoSuchProviderException); if !ok { panic(ClassCast(x, NoSuchProviderException_class)) }; return v }
