//line java_io_FileNotFoundException.ae:1
package jrt








func FileNotFoundException_New() *FileNotFoundException { t := &FileNotFoundException{}; t.Ctor(); return t }
//line :10:1
func (t *FileNotFoundException) Ctor() { t.IOException.Ctor(t) }

func FileNotFoundException_New_String(p0 *String) *FileNotFoundException { t := &FileNotFoundException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *FileNotFoundException) Ctor_String(s *String) { t.IOException.Ctor_String(t, s) }

func FileNotFoundException_New_String_String(p0, p1 *String) *FileNotFoundException { t := &FileNotFoundException{}; t.Ctor_String_String(p0, p1); return t }
//line :14:1
func (t *FileNotFoundException) Ctor_String_String(path, reason *String) { panic(A2g_NotTranslated("java.io.FileNotFoundException.<init>(Ljava/lang/String;Ljava/lang/String;)V")) }









type FileNotFoundException struct{ IOException }

const FileNotFoundException_serialVersionUID int64 = -897856973823710492

func (t *FileNotFoundException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *FileNotFoundException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *FileNotFoundException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *FileNotFoundException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *FileNotFoundException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *FileNotFoundException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *FileNotFoundException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *FileNotFoundException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *FileNotFoundException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *FileNotFoundException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *FileNotFoundException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *FileNotFoundException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *FileNotFoundException) Ref() any { if t == nil { return nil }; return t }

func (t *FileNotFoundException) GetClass__Class() *Class { return FileNotFoundException_class }

func (t *FileNotFoundException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileNotFoundException) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileNotFoundException_InstanceOf(x any) bool { _, ok := x.(*FileNotFoundException); return ok }

func FileNotFoundException_Cast(x any) *FileNotFoundException { if x == nil { return nil }; v, ok := x.(*FileNotFoundException); if !ok { panic(ClassCast(x, FileNotFoundException_class)) }; return v }
