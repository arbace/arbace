//line hostrand_linux.ae:1
//go:build linux

package jrt

import "crypto/rand"





func (h OSHost) RandomBytes(b []byte) { rand.Read(b) }
