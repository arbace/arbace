//line java_lang_Integer.ae:1
package jrt




























































func Integer_ToString_I_I__String(i, radix int32) *String { Integer_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = radix < 2; if !tmp2 { tmp2 = radix > 36 }; tmp1 = tmp2; if tmp1 { radix = 10 }
	if radix == 10 {
		return Integer_ToString_I__String(i) } else {
//line :64:1
			if String_COMPACT_STRINGS {


				var buf *ByteArray = NewByteArray(33); var negative bool = i < 0
				var charPos int32 = 32

				if negative { } else { i = -i }
			L1: for { if i <= -radix {
				var tmp3 *ByteArray = Integer_digits; buf.A[charPos] = tmp3.A[-(i % radix)]


				charPos = charPos - 1
				i = i / radix
//line :71:1
				continue L1 }; break L1
			}




				buf.A[charPos] = Integer_digits.A[-i]
				if negative { var tmp4 int32; charPos = charPos - 1; tmp4 = charPos; buf.A[tmp4] = 45 }
				return StringLatin1_NewString_B1_I_I__String(buf, charPos, 33-charPos) } else {
					return Integer_ToStringUTF16_I_I__String(i, radix)
				} } }
func Integer_ToStringUTF16_I_I__String(i, radix int32) *String { Integer_Init()
	var buf *ByteArray = NewByteArray(66); var negative bool = i < 0
	var charPos int32 = 32

	if negative { } else { i = -i }
L1: for { if i <= -radix {
	var tmp1 *ByteArray = Integer_digits; StringUTF16_PutChar_B1_I_I__V(buf, charPos, int32(tmp1.A[-(i%radix)]))


	charPos = charPos - 1
	i = i / radix
//line :87:1
	continue L1 }; break L1
}




	StringUTF16_PutChar_B1_I_I__V(buf, charPos, int32(Integer_digits.A[-i]))
	if negative { var tmp2 int32; charPos = charPos - 1; tmp2 = charPos; StringUTF16_PutChar_B1_I_I__V(buf, tmp2, 45) }
	return StringUTF16_NewString_B1_I_I__String(buf, charPos, 33-charPos)
}
func Integer_ToUnsignedString_I_I__String(i, radix int32) *String {
	return Long_ToUnsignedString_J_I__String(Integer_ToUnsignedLong_I__J(i), radix)
}
func Integer_ToHexString_I__String(i int32) *String {
	return Integer_ToUnsignedString0_I_I__String(i, 4)
}
func Integer_ToOctalString_I__String(i int32) *String {
	return Integer_ToUnsignedString0_I_I__String(i, 3)
}
func Integer_ToBinaryString_I__String(i int32) *String {
	return Integer_ToUnsignedString0_I_I__String(i, 1)
}
func Integer_ToUnsignedString0_I_I__String(val, shift int32) *String {
	var mag int32 = 32 - Integer_NumberOfLeadingZeros_I__I(val); var chars int32 = Math_Max_I_I__I((mag+(shift-1))/shift, 1); var buf *ByteArray = NewByteArray(chars)





	Integer_FormatUnsignedInt_I_I_B1_I__V(val, shift, buf, chars)
	return String_NewStringWithLatin1Bytes_B1__String(buf)
}
func Integer_FormatUnsignedInt_I_I_B1_I__V(val, shift int32, buf *ByteArray, len_ int32) { Integer_Init()

	var charPos int32 = len_; var radix int32 = 1 << (shift & 31); var mask int32 = radix - 1


L1: for {
	var tmp1 int32
	charPos = charPos - 1; tmp1 = charPos
//line :125:1
	buf.A[tmp1] = Integer_digits.A[val&mask]


	val = int32(uint32(val) >> (shift & 31))
	if charPos > 0 { continue L1 }
//line :124:1
	break L1
}
}




func Integer_ToString_I__String(i int32) *String {
	var size int32 = DecimalDigits_StringSize_I__I(i); var buf *ByteArray = NewByteArray(size)

	DecimalDigits_UncheckedGetCharsLatin1_I_I_B1__I(i, size, buf)
	return String_NewStringWithLatin1Bytes_B1__String(buf)
}
func Integer_ToUnsignedString_I__String(i int32) *String {
	return Long_ToString_J__String(Integer_ToUnsignedLong_I__J(i))
}
func Integer_ParseInt_String_I__I(s *String, radix int32) int32 {
	if s == nil { panic(Thrown(NumberFormatException_New_String(Lit_1123))) }
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	var len_ int32 = NN(s).Length__I()
	if len_ == 0 { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(Lit_69, radix)))) }
	var digit int32 = -256; var i int32 = 0; var firstChar uint16; var tmp1 int32
	var old_1 int32 = i
	i = i + 1; tmp1 = old_1; firstChar = NN(s).CharAt_I__C(tmp1)
	var tmp2 bool; var tmp3 bool; tmp3 = !(int32(firstChar) == 45); if tmp3 { tmp3 = !(int32(firstChar) == 43) }; tmp2 = tmp3; if tmp2 {
		digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp4 bool; var tmp5 bool; tmp5 = digit >= 0; if !tmp5 { var tmp6 bool; tmp6 = digit == -256; if tmp6 { tmp6 = len_ > 1 }; tmp5 = tmp6 }; tmp4 = tmp5; if tmp4 {
		var limit int32; if !(int32(firstChar) == 45) { limit = -2147483647 } else { limit = -2147483648 }; var multmin int32 = limit / radix; var result int32 = -(digit & 255)
		var inRange bool = true


	L1: for { var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = i < len_; if tmp9 {
		var tmp10 int32; var tmp11 int32
		var old_2 int32 = i


		i = i + 1; tmp11 = old_2
//line :161:1
		digit = Character_Digit_C_I__I(NN(s).CharAt_I__C(tmp11), radix); tmp10 = digit; tmp9 = tmp10 >= 0 }
//line :160:1
		tmp8 = tmp9; if tmp8 {







			var tmp12 bool; var tmp13 bool
			tmp13 = result > multmin; if !tmp13 {
				var tmp14 bool; tmp14 = result == multmin; if tmp14 {
					tmp14 = digit <= radix*multmin-limit }
//line :170:1
				tmp13 = tmp14 }
//line :169:1
			tmp12 = tmp13
//line :168:1
			inRange = tmp12; tmp8 = inRange }
//line :160:1
		tmp7 = tmp8; if tmp7 {














			result = radix*result - digit
//line :160:1
			continue L1 }; break L1
	}














		var tmp15 bool; var tmp16 bool; var tmp17 bool; tmp17 = inRange; if tmp17 { tmp17 = i == len_ }; tmp16 = tmp17; if tmp16 { tmp16 = digit >= 0 }; tmp15 = tmp16; if tmp15 {
			var tmp18 int32; if !(int32(firstChar) == 45) { tmp18 = -result } else { tmp18 = result }; return tmp18 } }
	panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(s, radix))))
}
func Integer_ParseInt_CharSequence_I_I_I__I(s CharSequence, beginIndex, endIndex, radix int32) int32 {


	Objects_RequireNonNull_O__O(s)
	Objects_CheckFromToIndex_I_I_I__I(beginIndex, endIndex, s.Length__I())
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if beginIndex == endIndex { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(Lit_69, radix)))) }
	var digit int32 = -256; var i int32 = beginIndex; var firstChar uint16; var tmp1 int32
	var old_3 int32 = i
	i = i + 1; tmp1 = old_3; firstChar = s.CharAt_I__C(tmp1)
	var tmp2 bool; var tmp3 bool; tmp3 = !(int32(firstChar) == 45); if tmp3 { tmp3 = !(int32(firstChar) == 43) }; tmp2 = tmp3; if tmp2 {
		digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp4 bool; var tmp5 bool; tmp5 = digit >= 0; if !tmp5 {
		var tmp6 bool; tmp6 = digit == -256; if tmp6 {
			tmp6 = endIndex-beginIndex > 1 }
//line :198:1
		tmp5 = tmp6 }
//line :197:1
	tmp4 = tmp5; if tmp4 {


		var limit int32; if !(int32(firstChar) == 45) { limit = -2147483647 } else { limit = -2147483648 }; var multmin int32 = limit / radix; var result int32 = -(digit & 255)
		var inRange bool = true


	L1: for { var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = i < endIndex; if tmp9 {
		var tmp10 int32; var tmp11 int32
		var old_4 int32 = i


		i = i + 1; tmp11 = old_4
//line :205:1
		digit = Character_Digit_C_I__I(s.CharAt_I__C(tmp11), radix); tmp10 = digit; tmp9 = tmp10 >= 0 }
//line :204:1
		tmp8 = tmp9; if tmp8 {







			var tmp12 bool; var tmp13 bool
			tmp13 = result > multmin; if !tmp13 {
				var tmp14 bool; tmp14 = result == multmin; if tmp14 {
					tmp14 = digit <= radix*multmin-limit }
//line :214:1
				tmp13 = tmp14 }
//line :213:1
			tmp12 = tmp13
//line :212:1
			inRange = tmp12; tmp8 = inRange }
//line :204:1
		tmp7 = tmp8; if tmp7 {














			result = radix*result - digit
//line :204:1
			continue L1 }; break L1
	}














		var tmp15 bool; var tmp16 bool; var tmp17 bool; tmp17 = inRange; if tmp17 { tmp17 = i == endIndex }; tmp16 = tmp17; if tmp16 { tmp16 = digit >= 0 }; tmp15 = tmp16; if tmp15 {
			var tmp18 int32; if !(int32(firstChar) == 45) { tmp18 = -result } else { tmp18 = result }; return tmp18 } }
	var tmp19 int32 = i; var tmp20 int32



	if digit < -1 { tmp20 = 0 } else { tmp20 = 1 }
//line :222:1
	panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForCharSequence_CharSequence_I_I_I__NumberFormatException(s, beginIndex, endIndex, tmp19-tmp20))))
}




func Integer_ParseInt_String__I(s *String) int32 {
	return Integer_ParseInt_String_I__I(s, 10)
}
func Integer_ParseUnsignedInt_String_I__I(s *String, radix int32) int32 {

	if s == nil { panic(Thrown(NumberFormatException_New_String(Lit_1123))) }
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	var len_ int32 = NN(s).Length__I()
	if len_ == 0 { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(s, radix)))) }
	var i int32 = 0; var firstChar uint16; var tmp1 int32; var old_5 int32 = i
	i = i + 1; tmp1 = old_5; firstChar = NN(s).CharAt_I__C(tmp1)
	if int32(firstChar) == 45 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1126, RefArrayOf(Object_class, s.Ref())))))
	}

	var digit int32 = -256
	if int32(firstChar) == 43 { } else { digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp2 bool; var tmp3 bool; tmp3 = digit >= 0; if !tmp3 { var tmp4 bool; tmp4 = digit == -256; if tmp4 { tmp4 = len_ > 1 }; tmp3 = tmp4 }; tmp2 = tmp3; if tmp2 {
		var multmax int32 = Integer_DivideUnsigned_I_I__I(-1, radix); var result int32 = digit & 255
		var inRange bool = true

	L1: for { var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = i < len_; if tmp7 {
		var tmp8 int32; var tmp9 int32
		var old_6 int32 = i


		i = i + 1; tmp9 = old_6
//line :255:1
		digit = Character_Digit_C_I__I(NN(s).CharAt_I__C(tmp9), radix); tmp8 = digit; tmp7 = tmp8 >= 0 }
//line :254:1
		tmp6 = tmp7; if tmp6 {







			var tmp10 bool; var tmp11 bool
			tmp11 = Integer_CompareUnsigned_I_I__I(result, multmax) < 0; if !tmp11 {
				var tmp12 bool; tmp12 = result == multmax; if tmp12 {
					tmp12 = digit < -radix*multmax }
//line :264:1
				tmp11 = tmp12 }
//line :263:1
			tmp10 = tmp11
//line :262:1
			inRange = tmp10; tmp6 = inRange }
//line :254:1
		tmp5 = tmp6; if tmp5 {














			result = radix*result + digit
//line :254:1
			continue L1 }; break L1
	}














		var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = inRange; if tmp15 { tmp15 = i == len_ }; tmp14 = tmp15; if tmp14 { tmp14 = digit >= 0 }; tmp13 = tmp14; if tmp13 { return result } }
	if digit < 0 { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(s, radix)))) }
	panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1127, RefArrayOf(Object_class, s.Ref())))))
}


func Integer_ParseUnsignedInt_CharSequence_I_I_I__I(s CharSequence, beginIndex, endIndex, radix int32) int32 {



	Objects_RequireNonNull_O__O(s)
	Objects_CheckFromToIndex_I_I_I__I(beginIndex, endIndex, s.Length__I())
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if beginIndex == endIndex { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(Lit_69, radix)))) }
	var i int32 = beginIndex; var firstChar uint16; var tmp1 int32; var old_7 int32 = i
	i = i + 1; tmp1 = old_7; firstChar = s.CharAt_I__C(tmp1)
	if int32(firstChar) == 45 {
		panic(Thrown(NumberFormatException_New_String(Concat(Lit_1128, StrOfObj(s), Lit_79))))
	}
	var digit int32 = -256
	if int32(firstChar) == 43 { } else { digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp2 bool; var tmp3 bool; tmp3 = digit >= 0; if !tmp3 {
		var tmp4 bool; tmp4 = digit == -256; if tmp4 {
			tmp4 = endIndex-beginIndex > 1 }
//line :297:1
		tmp3 = tmp4 }
//line :296:1
	tmp2 = tmp3; if tmp2 {


		var multmax int32 = Integer_DivideUnsigned_I_I__I(-1, radix); var result int32 = digit & 255
		var inRange bool = true

	L1: for { var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = i < endIndex; if tmp7 {
		var tmp8 int32; var tmp9 int32
		var old_8 int32 = i


		i = i + 1; tmp9 = old_8
//line :303:1
		digit = Character_Digit_C_I__I(s.CharAt_I__C(tmp9), radix); tmp8 = digit; tmp7 = tmp8 >= 0 }
//line :302:1
		tmp6 = tmp7; if tmp6 {







			var tmp10 bool; var tmp11 bool
			tmp11 = Integer_CompareUnsigned_I_I__I(result, multmax) < 0; if !tmp11 {
				var tmp12 bool; tmp12 = result == multmax; if tmp12 {
					tmp12 = digit < -radix*multmax }
//line :312:1
				tmp11 = tmp12 }
//line :311:1
			tmp10 = tmp11
//line :310:1
			inRange = tmp10; tmp6 = inRange }
//line :302:1
		tmp5 = tmp6; if tmp5 {














			result = radix*result + digit
//line :302:1
			continue L1 }; break L1
	}














		var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = inRange; if tmp15 { tmp15 = i == endIndex }; tmp14 = tmp15; if tmp14 { tmp14 = digit >= 0 }; tmp13 = tmp14; if tmp13 { return result } }
	if digit < 0 {
		var tmp16 int32 = i; var tmp17 int32



		if digit < -1 { tmp17 = 0 } else { tmp17 = 1 }
//line :320:1
		panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForCharSequence_CharSequence_I_I_I__NumberFormatException(s, beginIndex, endIndex, tmp16-tmp17))))
	}



	panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1127, RefArrayOf(Object_class, s)))))
}


func Integer_ParseUnsignedInt_String__I(s *String) int32 {
	return Integer_ParseUnsignedInt_String_I__I(s, 10)
}
func Integer_ValueOf_String_I__Integer(s *String, radix int32) *Integer {
	return Integer_ValueOf_I__Integer(Integer_ParseInt_String_I__I(s, radix))
}
func Integer_ValueOf_String__Integer(s *String) *Integer {
	return Integer_ValueOf_I__Integer(Integer_ParseInt_String_I__I(s, 10))
}










































func Integer_IntegerCache_New() *Integer_IntegerCache { Integer_IntegerCache_Init(); t := &Integer_IntegerCache{}; t.Ctor(); return t }
//line :380:1
func (t *Integer_IntegerCache) Ctor() { panic(A2g_NotTranslated("java.lang.Integer$IntegerCache.<init>()V")) }

func Integer_ValueOf_I__Integer(i int32) *Integer {
	var tmp1 bool; var tmp2 bool; tmp2 = i >= -128; if tmp2 { var tmp3 int32; Integer_IntegerCache_Init(); tmp3 = Integer_IntegerCache_high; tmp2 = i <= tmp3 }; tmp1 = tmp2; if tmp1 {
		var tmp4 *RefArray; Integer_IntegerCache_Init(); tmp4 = Integer_IntegerCache_cache; return As[*Integer](tmp4.A[i+128]) } else {
			return Integer_New_I(i)
		}
}

func Integer_New_I(p0 int32) *Integer { Integer_Init(); t := &Integer{}; t.Ctor_I(p0); return t }
//line :389:1
func (t *Integer) Ctor_I(value int32) { t.Number.Ctor(t)
	t.F_value = value
}
func Integer_New_String(p0 *String) *Integer { Integer_Init(); t := &Integer{}; t.Ctor_String(p0); return t }
//line :392:1
func (t *Integer) Ctor_String(s *String) { t.Number.Ctor(t)
	t.F_value = Integer_ParseInt_String_I__I(s, 10)
}
func (t *Integer) ByteValue__B() int8 { return int8(t.F_value) }

func (t *Integer) ShortValue__S() int16 { return int16(t.F_value) }

func (t *Integer) IntValue__I() int32 { return t.F_value }

func (t *Integer) LongValue__J() int64 { return int64(t.F_value) }

func (t *Integer) FloatValue__F() float32 { return float32(t.F_value) }

func (t *Integer) DoubleValue__D() float64 { return float64(t.F_value) }

func (t *Integer) ToString__String() *String { return Integer_ToString_I__String(t.F_value) }

func (t *Integer) HashCode__I() int32 { return Integer_HashCode_I__I(t.F_value) }

func Integer_HashCode_I__I(value int32) int32 { return value }

func (t *Integer) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1); var tmp2 int32 = t.F_value; return tmp2 == NN(i).IntValue__I() } else { return false
	} }
func Integer_GetInteger_String__Integer(nm *String) *Integer {
	return Integer_GetInteger_String_Integer__Integer(nm, nil)
}
func Integer_GetInteger_String_I__Integer(nm *String, val int32) *Integer {
	var result *Integer = Integer_GetInteger_String_Integer__Integer(nm, nil); if result == nil { return Integer_ValueOf_I__Integer(val) } else { return result
	} }
func Integer_GetInteger_String_Integer__Integer(nm *String, val *Integer) *Integer {
	var v *String; var tmp1 bool; var tmp2 bool; tmp2 = !(nm == nil); if tmp2 { tmp2 = !NN(nm).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { v = System_GetProperty_String__String(nm) } else { v = nil }
	if !(v == nil) { tmp3, tmp4, tmp5 := func() (ctl int32, rv *Integer, exc Throwable_I) { defer Catch(&exc); return 2, Integer_Decode_String__Integer(v), nil; return 0, nil, nil }(); if tmp5 != nil { if NumberFormatException_InstanceOf(tmp5) { var e *NumberFormatException = NumberFormatException_Cast(tmp5); _ = e } else { panic(tmp5) } }; switch tmp3 { case 2: { return tmp4 }} }
//line :423:1
	return val
}


func Integer_Decode_String__Integer(nm *String) *Integer { var tmp1 int32; var radix int32 = 10; var index int32 = 0; var negative bool = false; var result int32 = 0; if




	NN(nm).IsEmpty__Z() { panic(Thrown(NumberFormatException_New_String(Lit_1129))) }; var firstChar uint16 =
	NN(nm).CharAt_I__C(0); if
	int32(firstChar) == 45 {
		negative = true; index = index + 1 } else {
//line :434:1
			if int32(firstChar) == 43 {

				index = index + 1 } }; var tmp2 bool; var tmp3 bool; tmp3 =

	NN(nm).StartsWith_String_I__Z(Lit_1130, index); if !tmp3 { tmp3 = NN(nm).StartsWith_String_I__Z(Lit_1131, index) }; tmp2 = tmp3; if tmp2 {
		index = index + 2; radix = 16 } else {
//line :437:1
			if NN(nm).StartsWith_String_I__Z(Lit_1132, index) {


				index = index + 1; radix = 16 } else {

					var tmp4 bool; var tmp5 bool; tmp5 = NN(nm).StartsWith_String_I__Z(Lit_1133, index); if tmp5 { tmp5 = NN(nm).Length__I() > 1+index }; tmp4 = tmp5; if tmp4 {
						index = index + 1
						radix = 8 } } }; var tmp6 bool; var tmp7 bool; tmp7 =
	NN(nm).StartsWith_String_I__Z(Lit_1134, index); if !tmp7 { tmp7 = NN(nm).StartsWith_String_I__Z(Lit_1135, index) }; tmp6 = tmp7; if tmp6 {
		panic(Thrown(NumberFormatException_New_String(Lit_1136))) }; tmp9 := func() (exc Throwable_I) { defer Catch(&exc)

			result = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(nm), index, NN(nm).Length__I(), radix)
			{ var tmp8 int32; if negative { tmp8 = -result } else { tmp8 = result }; result = tmp8 }; return nil }(); if /*line :447:1*/ tmp9 != nil { if NumberFormatException_InstanceOf(tmp9) { var e *NumberFormatException = NumberFormatException_Cast(tmp9); var constant *String; _ = e



				if negative {
					constant = Concat(Lit_1134, NN(nm).Substring_I__String(index)) } else {
						constant = NN(nm).Substring_I__String(index) }
				result = Integer_ParseInt_String_I__I(constant, radix) } else {
//line :447:1
					panic(tmp9) } }; tmp1 = result; return /*line :427:1*/ Integer_ValueOf_I__Integer(tmp1) }





























func (t *Integer) CompareTo_Integer__I(anotherInteger *Integer) int32 {
	var tmp1 int32 = t.F_value; return Integer_Compare_I_I__I(tmp1, anotherInteger.F_value)
}
func Integer_Compare_I_I__I(x, y int32) int32 {
	if x < y { return -1 } else { if x == y { return 0 } else { return 1
	} } }
func Integer_CompareUnsigned_I_I__I(x, y int32) int32 {
	return Integer_Compare_I_I__I(x+-2147483648, y+-2147483648)
}
func Integer_ToUnsignedLong_I__J(x int32) int64 {
	return int64(x) & 4294967295
}
func Integer_DivideUnsigned_I_I__I(dividend, divisor int32) int32 {

	return int32(Integer_ToUnsignedLong_I__J(dividend) / Integer_ToUnsignedLong_I__J(divisor))
}

func Integer_RemainderUnsigned_I_I__I(dividend, divisor int32) int32 {

	return int32(Integer_ToUnsignedLong_I__J(dividend) % Integer_ToUnsignedLong_I__J(divisor))
}





func Integer_HighestOneBit_I__I(i int32) int32 {
	return i & int32(uint32(2147483648)>>(Integer_NumberOfLeadingZeros_I__I(i)&31))
}
func Integer_LowestOneBit_I__I(i int32) int32 {
	return i & -i
}
func Integer_NumberOfLeadingZeros_I__I(i int32) int32 {
	if i <= 0 {
		if i == 0 { return 32 } else { return 0 } } else {
			var n int32 = 31
			if i >= 65536 {
				n = n - 16
				i = int32(uint32(i) >> 16) }
			if i >= 256 {
				n = n - 8
				i = int32(uint32(i) >> 8) }
			if i >= 16 {
				n = n - 4
				i = int32(uint32(i) >> 4) }
			if i >= 4 {
				n = n - 2
				i = int32(uint32(i) >> 2) }
			return n - int32(uint32(i)>>1)
		} }
func Integer_NumberOfTrailingZeros_I__I(i int32) int32 {
	i = ^i & (i - 1)
	if i <= 0 {
		return i & 32 } else {
			var n int32 = 1
			if i > 65536 {
				n = n + 16
				i = int32(uint32(i) >> 16) }
			if i > 256 {
				n = n + 8
				i = int32(uint32(i) >> 8) }
			if i > 16 {
				n = n + 4
				i = int32(uint32(i) >> 4) }
			if i > 4 {
				n = n + 2
				i = int32(uint32(i) >> 2) }
			return n + int32(uint32(i)>>1)
		} }
func Integer_BitCount_I__I(i int32) int32 {
	i = i - int32(uint32(i)>>1)&1431655765
	i = i&858993459 + int32(uint32(i)>>2)&858993459


	i = (i + int32(uint32(i)>>4)) & 252645135
	i = i + int32(uint32(i)>>8)
	i = i + int32(uint32(i)>>16)
	return i & 63
}
func Integer_RotateLeft_I_I__I(i, distance int32) int32 {
	return i<<(distance&31) | int32(uint32(i)>>(-distance&31))
}

func Integer_RotateRight_I_I__I(i, distance int32) int32 {
	return int32(uint32(i)>>(distance&31)) | i<<(-distance&31)
}

func Integer_Reverse_I__I(i int32) int32 {
	i = i&1431655765<<1 | int32(uint32(i)>>1)&1431655765


	i = i&858993459<<2 | int32(uint32(i)>>2)&858993459


	i = i&252645135<<4 | int32(uint32(i)>>4)&252645135


	return Integer_ReverseBytes_I__I(i)
}
func Integer_Compress_I_I__I(i, mask int32) int32 {

	i = i & mask
	var maskCount int32 = ^mask << 1; var j int32 = 0
L1: for {
	if j < 5 {
		var maskPrefix int32 = Integer_ParallelSuffix_I__I(maskCount); var maskMove int32 = maskPrefix & mask

		mask = mask ^ maskMove | int32(uint32(maskMove)>>(1<<(j&31)&31))


		var t_ int32 = i & maskMove
		i = i ^ t_ | int32(uint32(t_)>>(1<<(j&31)&31))


		maskCount = maskCount & ^maskPrefix
		j = j + 1; continue L1 }
//line :560:1
	break L1 }
//line :559:1
	return i
}














func Integer_Expand_I_I__I(i, mask int32) int32 {

	var originalMask int32 = mask; var maskCount int32 = ^mask << 1; var maskPrefix int32 = Integer_ParallelSuffix_I__I(maskCount); var maskMove1 int32 = maskPrefix & mask



	mask = mask ^ maskMove1 | int32(uint32(maskMove1)>>1)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Integer_ParallelSuffix_I__I(maskCount)
	var maskMove2 int32 = maskPrefix & mask
	mask = mask ^ maskMove2 | int32(uint32(maskMove2)>>2)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Integer_ParallelSuffix_I__I(maskCount)
	var maskMove3 int32 = maskPrefix & mask
	mask = mask ^ maskMove3 | int32(uint32(maskMove3)>>4)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Integer_ParallelSuffix_I__I(maskCount)
	var maskMove4 int32 = maskPrefix & mask
	mask = mask ^ maskMove4 | int32(uint32(maskMove4)>>8)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Integer_ParallelSuffix_I__I(maskCount)
	var maskMove5 int32 = maskPrefix & mask; var t_ int32 = i << 16

	i = i & ^maskMove5 | t_&maskMove5

	t_ = i << 8
	i = i & ^maskMove4 | t_&maskMove4

	t_ = i << 4
	i = i & ^maskMove3 | t_&maskMove3

	t_ = i << 2
	i = i & ^maskMove2 | t_&maskMove2

	t_ = i << 1
	i = i & ^maskMove1 | t_&maskMove1

	return i & originalMask
}
func Integer_ParallelSuffix_I__I(maskCount int32) int32 {
	var maskPrefix int32 = maskCount ^ maskCount<<1
	maskPrefix = maskPrefix ^ maskPrefix<<2
	maskPrefix = maskPrefix ^ maskPrefix<<4
	maskPrefix = maskPrefix ^ maskPrefix<<8
	maskPrefix = maskPrefix ^ maskPrefix<<16
//line :623:1
	return maskPrefix
}





func Integer_Signum_I__I(i int32) int32 {
	return i>>31 | int32(uint32(-i)>>31)
}

func Integer_ReverseBytes_I__I(i int32) int32 {
	return i<<24 | i&65280<<8 | int32(uint32(i)>>8)&65280 | int32(uint32(i)>>24)
}



func Integer_Sum_I_I__I(a, b int32) int32 {
	return a + b
}
func Integer_Max_I_I__I(a, b int32) int32 { return Math_Max_I_I__I(a, b) }

func Integer_Min_I_I__I(a, b int32) int32 { return Math_Min_I_I__I(a, b) }

func (t *Integer) DescribeConstable__Optional() *Optional {
	return Optional_Of_O__Optional(t)
}


type Integer struct{ Number; F_value int32 }

func (t *Integer) Is_Comparable() {}

func (t *Integer) Is_Constable() {}

func (t *Integer) Is_ConstantDesc() {}

const Integer_MIN_VALUE int32 = -2147483648

const Integer_MAX_VALUE int32 = 2147483647

var Integer_TYPE *Class

var Integer_digits *ByteArray

const Integer_SIZE int32 = 32

const Integer_BYTES int32 = 4

const Integer_serialVersionUID int64 = 1360826667806852920

var Integer_init ClassInit

func Integer_Init() { if !Integer_init.Done() { Integer_init.Run(Integer_clinit) } }

func Integer_clinit() { Integer_TYPE = Class_GetPrimitiveClass_String__Class(Lit_1122); Integer_digits = ByteArrayOf(48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122) }

func (t *Integer) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Integer__I(Integer_Cast(p0)) }

func (t *Integer) Ref() any { if t == nil { return nil }; return t }

func (t *Integer) GetClass__Class() *Class { return Integer_class }

func (t *Integer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Integer) CloneShallow() any { panic(CloneNotSupported(t)) }

func Integer_InstanceOf(x any) bool { _, ok := x.(*Integer); return ok }

func Integer_Cast(x any) *Integer { if x == nil { return nil }; v, ok := x.(*Integer); if !ok { panic(ClassCast(x, Integer_class)) }; return v }



type Integer_IntegerCache struct{ Object }

const Integer_IntegerCache_low int32 = -128

var Integer_IntegerCache_high int32

var Integer_IntegerCache_cache *RefArray

var Integer_IntegerCache_archivedCache *RefArray

var Integer_IntegerCache_init ClassInit

func Integer_IntegerCache_Init() { if !Integer_IntegerCache_init.Done() { Integer_IntegerCache_init.Run(Integer_IntegerCache_clinit) } }

func Integer_IntegerCache_clinit() {
//line :348:1
	var h int32 = 127; var integerCacheHighPropValue *String = VM_GetSavedProperty_String__String(Lit_1137)

	if !(integerCacheHighPropValue == nil) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		h = Math_Max_I_I__I(Integer_ParseInt_String__I(integerCacheHighPropValue), 127)
		h = Math_Min_I_I__I(h, 2147483518)
//line :350:1
		return nil }()
		if tmp1 != nil { if NumberFormatException_InstanceOf(tmp1) { var nfe *NumberFormatException = NumberFormatException_Cast(tmp1); _ = nfe } else { panic(tmp1)
		}
		}
	}




	Integer_IntegerCache_high = h
	CDS_InitializeFromArchive_Class__V(Integer_IntegerCache_class)
	var size int32 = Integer_IntegerCache_high - -128 + 1; var tmp2 bool; var tmp3 bool
	tmp3 = Integer_IntegerCache_archivedCache == nil; if !tmp3 { tmp3 = size > int32(len(Integer_IntegerCache_archivedCache.A)) }; tmp2 = tmp3; if tmp2 {
		var c *RefArray = NewRefArray(Integer_class, size); var j int32 = -128; var archivedSize int32

		if Integer_IntegerCache_archivedCache == nil { archivedSize = 0 } else { archivedSize = int32(len(Integer_IntegerCache_archivedCache.A)) }
		var i int32 = 0; L1: for {
			if i < archivedSize {
				c.Store(i, As[*Integer](Integer_IntegerCache_archivedCache.A[i]).Ref())
				if !A2g_AssertionsDisabled && !(j == NN(As[*Integer](Integer_IntegerCache_archivedCache.A[i])).IntValue__I()) { panic(Thrown(AssertionError_New())) }
				j = j + 1
				i = i + 1; continue L1 }
//line :366:1
			break L1
		}




		var i_2 int32 = archivedSize; L2: for {
			if i_2 < size {
				var tmp4 int32; var old_9 int32 = j; j = j + 1; tmp4 = old_9; c.Store(i_2, Integer_New_I(tmp4))
				i_2 = i_2 + 1; continue L2 }
//line :372:1
			break L2
		}


		Integer_IntegerCache_archivedCache = c }
	Integer_IntegerCache_cache = Integer_IntegerCache_archivedCache
	if !A2g_AssertionsDisabled && !(Integer_IntegerCache_high >= 127) { panic(Thrown(AssertionError_New()))
	}
}











































































































































































































































































































































func (t *Integer_IntegerCache) Ref() any { if t == nil { return nil }; return t }

func (t *Integer_IntegerCache) GetClass__Class() *Class { return Integer_IntegerCache_class }

func (t *Integer_IntegerCache) ToString__String() *String { return Object_toString(t) }

func (t *Integer_IntegerCache) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Integer_IntegerCache) CloneShallow() any { panic(CloneNotSupported(t)) }

func Integer_IntegerCache_InstanceOf(x any) bool { _, ok := x.(*Integer_IntegerCache); return ok }

func Integer_IntegerCache_Cast(x any) *Integer_IntegerCache { if x == nil { return nil }; v, ok := x.(*Integer_IntegerCache); if !ok { panic(ClassCast(x, Integer_IntegerCache_class)) }; return v }
