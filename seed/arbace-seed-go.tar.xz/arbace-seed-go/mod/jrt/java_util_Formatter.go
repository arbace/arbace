//line java_util_Formatter.ae:1
package jrt
































func Formatter_GetDecimalFormatSymbols_Locale__DecimalFormatSymbols(locale *Locale) *DecimalFormatSymbols { Formatter_Init()
	var dfs *DecimalFormatSymbols = Formatter_DFS; var tmp1 bool; var tmp2 bool
	tmp2 = !(dfs == nil); if tmp2 { tmp2 = NN(NN(dfs).GetLocale__Locale()).Equals_O__Z(locale.Ref()) }; tmp1 = tmp2; if tmp1 { return dfs } else {

		dfs = DecimalFormatSymbols_GetInstance_Locale__DecimalFormatSymbols(locale); Formatter_DFS = dfs; return dfs
	} }
func Formatter_GetZero_Locale__C(locale *Locale) uint16 {
	if locale == nil { return 48 } else { return NN(Formatter_GetDecimalFormatSymbols_Locale__DecimalFormatSymbols(locale)).GetZeroDigit__C()
	} }
func Formatter_GetDecimalSeparator_Locale__C(locale *Locale) uint16 {
	if locale == nil { return 46 } else { return NN(Formatter_GetDecimalFormatSymbols_Locale__DecimalFormatSymbols(locale)).GetDecimalSeparator__C()
	} }
func Formatter_GetGroupingSeparator_Locale__C(locale *Locale) uint16 {
	if locale == nil { return 44 } else { return NN(Formatter_GetDecimalFormatSymbols_Locale__DecimalFormatSymbols(locale)).GetGroupingSeparator__C()
	} }
func Formatter_GetMinusSign_Locale__C(locale *Locale) uint16 {
	if locale == nil { return 45 } else { return NN(Formatter_GetDecimalFormatSymbols_Locale__DecimalFormatSymbols(locale)).GetMinusSign__C()
	}
}





func Formatter_ToCharset_String__Charset(csn *String) Charset_I {
	Objects_RequireNonNull_O_String__O(csn.Ref(), Lit_85)
	var tmp1 Charset_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = Charset_ForName_String__Charset(csn); return nil }()
//line :60:1
	if tmp2 != nil { if IllegalCharsetNameException_InstanceOf(tmp2) || UnsupportedCharsetException_InstanceOf(tmp2) { var unused IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2); _ = unused


		panic(Thrown(UnsupportedEncodingException_New_String(csn))) } else {
//line :60:1
			panic(tmp2) } }; return tmp1
}



func Formatter_NonNullAppendable_Appendable__Appendable(a Appendable) Appendable {
	if a == nil { return StringBuilder_New() } else { return a
	} }
func Formatter_New_Locale_Appendable(p0 *Locale, p1 Appendable) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_Locale_Appendable(p0, p1); return t }
//line :68:1
func (t *Formatter) Ctor_Locale_Appendable(l *Locale, a Appendable) {
	t.F_a = a
	t.F_l = l
}
func Formatter_New_Charset_Locale_File(p0 Charset_I, p1 *Locale, p2 *File) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_Charset_Locale_File(p0, p1, p2); return t }
//line :72:1
func (t *Formatter) Ctor_Charset_Locale_File(charset Charset_I, l *Locale, file *File) { t.Ctor_Locale_Appendable(l, BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_Charset(FileOutputStream_New_File(file), charset))) }


func Formatter_New() *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor(); return t }
//line :75:1
func (t *Formatter) Ctor() { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_Locale_Appendable(Locale_GetDefault_Locale_Category__Locale(tmp1), StringBuilder_New()) }


func Formatter_New_Appendable(p0 Appendable) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_Appendable(p0); return t }
//line :78:1
func (t *Formatter) Ctor_Appendable(a Appendable) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_Locale_Appendable(Locale_GetDefault_Locale_Category__Locale(tmp1), Formatter_NonNullAppendable_Appendable__Appendable(a)) }


func Formatter_New_Locale(p0 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_Locale(p0); return t }
//line :81:1
func (t *Formatter) Ctor_Locale(l *Locale) { t.Ctor_Locale_Appendable(l, StringBuilder_New()) }

func Formatter_New_Appendable_Locale(p0 Appendable, p1 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_Appendable_Locale(p0, p1); return t }
//line :83:1
func (t *Formatter) Ctor_Appendable_Locale(a Appendable, l *Locale) { t.Ctor_Locale_Appendable(l, Formatter_NonNullAppendable_Appendable__Appendable(a)) }


func Formatter_New_String(p0 *String) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_String(p0); return t }
//line :86:1
func (t *Formatter) Ctor_String(fileName *String) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_Locale_Appendable(Locale_GetDefault_Locale_Category__Locale(tmp1), BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream(FileOutputStream_New_String(fileName)))) }



func Formatter_New_String_String(p0, p1 *String) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_String_String(p0, p1); return t }
//line :90:1
func (t *Formatter) Ctor_String_String(fileName, csn *String) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_String_String_Locale(fileName, csn, Locale_GetDefault_Locale_Category__Locale(tmp1)) }




func Formatter_New_String_String_Locale(p0, p1 *String, p2 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_String_String_Locale(p0, p1, p2); return t }
//line :95:1
func (t *Formatter) Ctor_String_String_Locale(fileName, csn *String, l *Locale) { t.Ctor_Charset_Locale_File(Formatter_ToCharset_String__Charset(csn), l, File_New_String(fileName)) }





func Formatter_New_String_Charset_Locale(p0 *String, p1 Charset_I, p2 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_String_Charset_Locale(p0, p1, p2); return t }
//line :101:1
func (t *Formatter) Ctor_String_Charset_Locale(fileName *String, charset Charset_I, l *Locale) { t.Ctor_Charset_Locale_File(Charset_Cast(Objects_RequireNonNull_O_String__O(charset, Lit_86)), l, File_New_String(fileName)) }


func Formatter_New_File(p0 *File) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_File(p0); return t }
//line :104:1
func (t *Formatter) Ctor_File(file *File) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_Locale_Appendable(Locale_GetDefault_Locale_Category__Locale(tmp1), BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream(FileOutputStream_New_File(file)))) }



func Formatter_New_File_String(p0 *File, p1 *String) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_File_String(p0, p1); return t }
//line :108:1
func (t *Formatter) Ctor_File_String(file *File, csn *String) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_File_String_Locale(file, csn, Locale_GetDefault_Locale_Category__Locale(tmp1)) }




func Formatter_New_File_String_Locale(p0 *File, p1 *String, p2 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_File_String_Locale(p0, p1, p2); return t }
//line :113:1
func (t *Formatter) Ctor_File_String_Locale(file *File, csn *String, l *Locale) { t.Ctor_Charset_Locale_File(Formatter_ToCharset_String__Charset(csn), l, file) }





func Formatter_New_File_Charset_Locale(p0 *File, p1 Charset_I, p2 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_File_Charset_Locale(p0, p1, p2); return t }
//line :119:1
func (t *Formatter) Ctor_File_Charset_Locale(file *File, charset Charset_I, l *Locale) { t.Ctor_Charset_Locale_File(Charset_Cast(Objects_RequireNonNull_O_String__O(charset, Lit_86)), l, file) }


func Formatter_New_PrintStream(p0 *PrintStream) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_PrintStream(p0); return t }
//line :122:1
func (t *Formatter) Ctor_PrintStream(ps *PrintStream) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_Locale_Appendable(Locale_GetDefault_Locale_Category__Locale(tmp1), Appendable_Cast(Objects_RequireNonNull_O__O(ps.Ref()))) }


func Formatter_New_OutputStream(p0 OutputStream_I) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_OutputStream(p0); return t }
//line :125:1
func (t *Formatter) Ctor_OutputStream(os OutputStream_I) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_Locale_Appendable(Locale_GetDefault_Locale_Category__Locale(tmp1), BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream(os))) }


func Formatter_New_OutputStream_String(p0 OutputStream_I, p1 *String) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_OutputStream_String(p0, p1); return t }
//line :128:1
func (t *Formatter) Ctor_OutputStream_String(os OutputStream_I, csn *String) { var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Ctor_OutputStream_String_Locale(os, csn, Locale_GetDefault_Locale_Category__Locale(tmp1)) }


func Formatter_New_OutputStream_String_Locale(p0 OutputStream_I, p1 *String, p2 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_OutputStream_String_Locale(p0, p1, p2); return t }
//line :131:1
func (t *Formatter) Ctor_OutputStream_String_Locale(os OutputStream_I, csn *String, l *Locale) { t.Ctor_Locale_Appendable(l, BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_String(os, csn))) }



func Formatter_New_OutputStream_Charset_Locale(p0 OutputStream_I, p1 Charset_I, p2 *Locale) *Formatter { Formatter_Init(); t := &Formatter{}; t.Ctor_OutputStream_Charset_Locale(p0, p1, p2); return t }
//line :135:1
func (t *Formatter) Ctor_OutputStream_Charset_Locale(os OutputStream_I, charset Charset_I, l *Locale) { t.Ctor_Locale_Appendable(l, BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_Charset(os, charset))) }


func (t *Formatter) Locale__Locale() *Locale { t.EnsureOpen__V(); return t.F_l }

func (t *Formatter) Out__Appendable() Appendable { t.EnsureOpen__V(); return t.F_a }

func (t *Formatter) ToString__String() *String {
	t.EnsureOpen__V()
	return t.F_a.ToString__String()
}
func (t *Formatter) Flush__V() {
	t.EnsureOpen__V()
	if Flushable_InstanceOf(t.F_a) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
		Flushable_Cast(t.F_a).Flush__V(); return nil }(); if tmp1 != nil { if IOException_InstanceOf(tmp1) { var ioe IOException_I = IOException_Cast(tmp1); t.F_lastException = ioe } else { panic(tmp1)
		} } } }
func (t *Formatter) Close__V() {
	if !(t.F_a == nil) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc); { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		if Closeable_InstanceOf(t.F_a) { Closeable_Cast(t.F_a).Close__V() }; return nil }()
//line :153:1
		if tmp1 != nil { if IOException_InstanceOf(tmp1) { var ioe IOException_I = IOException_Cast(tmp1)

			t.F_lastException = ioe } else {
//line :153:1
				panic(tmp1) } } }
		return nil
	}()
		t.F_a = nil
//line :153:1
		if tmp2 != nil { panic(tmp2)
		}
	}
}

func (t *Formatter) EnsureOpen__V() {
	if t.F_a == nil { panic(Thrown(FormatterClosedException_New()))
	} }
func (t *Formatter) IoException__IOException() IOException_I { return t.F_lastException }

func (t *Formatter) Format_String_O1__Formatter(format *String, args *RefArray) *Formatter {
	return t.Format_Locale_String_O1__Formatter(t.F_l, format, args)
}
func (t *Formatter) Format_Locale_String_O1__Formatter(l *Locale, format *String, args *RefArray) *Formatter {
	t.EnsureOpen__V()
	var last int32 = -1; var lasto int32 = -1; var fsa List = Formatter_Parse_String__List(format); var i_101810 Iterator = fsa.Iterator__Iterator(); for i_101810.HasNext__Z() {


		var fs Formatter_FormatString = Formatter_FormatString_Cast(i_101810.Next__O()); var index int32 = fs.Index__I(); tmp11 := func() (exc Throwable_I) { defer Catch(&exc)


			switch index { case -2:
				fs.Print_Formatter_O_Locale__V(t, nil, l); case -1:


				var tmp4 bool; var tmp5 bool; tmp5 = last < 0; if !tmp5 {
					var tmp6 bool; tmp6 = !(args == nil); if tmp6 { tmp6 = last > int32(len(args.A))-1 }; tmp5 = tmp6 }
//line :178:1
				tmp4 = tmp5; if tmp4 {

					panic(Thrown(MissingFormatArgumentException_New_String(fs.ToString__String()))) }
				var tmp7 any; if !(args == nil) { tmp7 = args.A[last] } else { tmp7 = nil }; fs.Print_Formatter_O_Locale__V(t, tmp7, l); case 0:


				lasto = lasto + 1
				last = lasto
				var tmp8 bool; var tmp9 bool; tmp9 = !(args == nil); if tmp9 { tmp9 = lasto > int32(len(args.A))-1 }; tmp8 = tmp9; if tmp8 {
					panic(Thrown(MissingFormatArgumentException_New_String(fs.ToString__String()))) }
				var tmp10 any; if !(args == nil) { tmp10 = args.A[lasto] } else { tmp10 = nil }; fs.Print_Formatter_O_Locale__V(t, tmp10, l); default:

				last = index - 1
				var tmp1 bool; var tmp2 bool; tmp2 = !(args == nil); if tmp2 { tmp2 = last > int32(len(args.A))-1 }; tmp1 = tmp2; if tmp1 {
					panic(Thrown(MissingFormatArgumentException_New_String(fs.ToString__String()))) }
				var tmp3 any; if !(args == nil) { tmp3 = args.A[last] } else { tmp3 = nil }; fs.Print_Formatter_O_Locale__V(t, tmp3, l)}; return nil }()
//line :173:1
		if tmp11 != nil { if IOException_InstanceOf(tmp11) { var x IOException_I = IOException_Cast(tmp11)




















			t.F_lastException = x } else {
//line :173:1
				panic(tmp11) } } }
//line :168:1
	return t
}



























func Formatter_Parse_String__List(s *String) List {
	var parser *Formatter_FormatSpecifierParser; var al *ArrayList = ArrayList_New(); var i int32 = 0; var max_ int32 = NN(s).Length__I()



L1: for { if i < max_ {
	var n int32 = NN(s).IndexOf_I_I__I(37, i)
	if n < 0 { NN(al).Add_O__Z(Formatter_FixedString_New_String_I_I(s, i, max_)); break L1 }
	if i == n { } else { NN(al).Add_O__Z(Formatter_FixedString_New_String_I_I(s, i, n)) }
	i = n + 1
	if i >= max_ { panic(Thrown(UnknownFormatConversionException_New_String(Lit_1310))) }
	var c uint16 = NN(s).CharAt_I__C(i)
	if Formatter_Conversion_IsValid_C__Z(c) {
		NN(al).Add_O__Z(Formatter_FormatSpecifier_New_C(c)); i = i + 1 } else {

			if parser == nil {
				parser = Formatter_FormatSpecifierParser_New_ArrayList_C_I_String_I(al, c, i, s, max_) } else {
					NN(parser).Reset_C_I__V(c, i) }
			var off int32 = NN(parser).Parse__I()
			if off > 0 {
				i = i + off } else {
					panic(Thrown(UnknownFormatConversionException_New_String(String_ValueOf_C__String(c)))) } }
//line :202:1
	continue L1 }; break L1 }
//line :198:1
	return Up_ArrayList_List(al)
}










































func Formatter_FormatSpecifierParser_New_ArrayList_C_I_String_I(p0 *ArrayList, p1 uint16, p2 int32, p3 *String, p4 int32) *Formatter_FormatSpecifierParser { t := &Formatter_FormatSpecifierParser{}; t.Ctor_ArrayList_C_I_String_I(p0, p1, p2, p3, p4); return t }
//line :242:1
func (t *Formatter_FormatSpecifierParser) Ctor_ArrayList_C_I_String_I(al *ArrayList, first uint16, start int32, s *String, max_ int32) {
	t.F_al = al
	t.F_first = first
	t.F_c = first
	t.F_start = start
	t.F_off = start
	t.F_s = s
	t.F_max = max_
}
func (t *Formatter_FormatSpecifierParser) Reset_C_I__V(first uint16, start int32) {
	t.F_first = first
	t.F_c = first
	t.F_start = start
	t.F_off = start
	t.F_argSize = 0
	t.F_flagSize = 0
	t.F_widthSize = 0
}
func (t *Formatter_FormatSpecifierParser) Parse__I() int32 {
	var precisionSize int32 = 0
	t.ParseArgument__V()
	t.ParseFlag__V()
	t.ParseWidth__V()
	if int32(t.F_c) == 46 {
		precisionSize = t.ParsePrecision__I()
		if precisionSize == -1 { return 0 } }
	var t_ uint16 = 0; var conversion uint16 = 0; var tmp1 bool; var tmp2 bool; var tmp3 bool


	tmp3 = int32(t.F_c) == 116; if !tmp3 { tmp3 = int32(t.F_c) == 84 }; tmp2 = tmp3; if tmp2 { tmp2 = t.F_off+1 < t.F_max }; tmp1 = tmp2
//line :270:1
	if tmp1 {

		var c1 uint16 = NN(t.F_s).CharAt_I__C(t.F_off + 1)
		if Formatter_IsConversion_C__Z(c1) {
			t_ = t.F_c
			conversion = c1
			t.F_off = t.F_off + 2 } } else {
//line :270:1
				if Formatter_IsConversion_C__Z(t.F_c) {






					conversion = t.F_c; t.F_off = t.F_off + 1 } else {
						return 0 } }
	if !(t.F_argSize+t.F_flagSize+t.F_widthSize+precisionSize+int32(t_)+int32(conversion) == 0) {








		if !(t.F_al == nil) {
			var formatSpecifier *Formatter_FormatSpecifier = Formatter_FormatSpecifier_New_String_I_I_I_I_I_C_C(t.F_s, t.F_start, t.F_argSize, t.F_flagSize, t.F_widthSize, precisionSize, t_, conversion)








			NN(t.F_al).Add_O__Z(formatSpecifier.Ref()) }
		return t.F_off - t.F_start } else {
//line :279:1
			return 0
		}
}




















func (t *Formatter_FormatSpecifierParser) ParseArgument__V() {
	var i int32 = t.F_off
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = i < t.F_max; if tmp2 { var tmp3 uint16; var tmp4 uint16 = NN(t.F_s).CharAt_I__C(i); t.F_c = tmp4; tmp3 = tmp4; tmp2 = Formatter_IsDigit_C__Z(tmp3) }; tmp1 = tmp2; if tmp1 {
	i = i + 1
//line :304:1
	continue L1 }; break L1
}
	var tmp5 bool; var tmp6 bool; tmp6 = i == t.F_off; if !tmp6 { tmp6 = !(int32(t.F_c) == 36) }; tmp5 = tmp6; if tmp5 {
		t.F_c = t.F_first } else {

			i = i + 1
			if i < t.F_max { t.F_c = NN(t.F_s).CharAt_I__C(i) }
			t.F_argSize = i - t.F_off
			t.F_off = i
		} }
func (t *Formatter_FormatSpecifierParser) ParseFlag__V() {
	var i int32 = t.F_off
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = i < t.F_max; if tmp2 { var tmp3 uint16; var tmp4 uint16 = NN(t.F_s).CharAt_I__C(i); t.F_c = tmp4; tmp3 = tmp4; tmp2 = Formatter_Flags_IsFlag_C__Z(tmp3) }; tmp1 = tmp2; if tmp1 { i = i + 1; continue L1 }; break L1 }
	t.F_flagSize = i - t.F_off
	t.F_off = i
}
func (t *Formatter_FormatSpecifierParser) ParseWidth__V() {
	var i int32 = t.F_off
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = i < t.F_max; if tmp2 { var tmp3 uint16; var tmp4 uint16 = NN(t.F_s).CharAt_I__C(i); t.F_c = tmp4; tmp3 = tmp4; tmp2 = Formatter_IsDigit_C__Z(tmp3) }; tmp1 = tmp2; if tmp1 {
	i = i + 1
//line :322:1
	continue L1 }; break L1
}
	t.F_widthSize = i - t.F_off
	t.F_off = i
}
func (t *Formatter_FormatSpecifierParser) ParsePrecision__I() int32 {
	var i int32; var tmp1 int32 = t.F_off + 1; t.F_off = tmp1; i = tmp1
L1: for { var tmp2 bool; var tmp3 bool; tmp3 = i < t.F_max; if tmp3 { var tmp4 uint16; var tmp5 uint16 = NN(t.F_s).CharAt_I__C(i); t.F_c = tmp5; tmp4 = tmp5; tmp3 = Formatter_IsDigit_C__Z(tmp4) }; tmp2 = tmp3; if tmp2 {
	i = i + 1
//line :329:1
	continue L1 }; break L1
}
	if !(i == t.F_off) {
		var size int32 = i - t.F_off + 1; t.F_off = i; return size } else {
//line :331:1
			return -1
		}
}

func Formatter_IsConversion_C__Z(c uint16) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = int32(c) >= 97; if tmp3 { tmp3 = int32(c) <= 122 }; tmp2 = tmp3; if !tmp2 { var tmp4 bool; tmp4 = int32(c) >= 65; if tmp4 { tmp4 = int32(c) <= 90 }; tmp2 = tmp4 }; tmp1 = tmp2; if !tmp1 { tmp1 = int32(c) == 37 }; return tmp1
}
func Formatter_IsDigit_C__Z(c uint16) bool {
	var tmp1 bool; tmp1 = int32(c) >= 48; if tmp1 { tmp1 = int32(c) <= 57 }; return tmp1
}










func (t *Formatter_FixedString) Index__I() int32 { return -2 }

func (t *Formatter_FixedString) Print_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	fmt.F_a.Append_CharSequence_I_I__Appendable(Up_String_CharSequence(t.F_s), t.F_start, t.F_end)
}
func (t *Formatter_FixedString) ToString__String() *String { return NN(t.F_s).Substring_I_I__String(t.F_start, t.F_end) }





















func (t *Formatter_FormatSpecifier) Index_String_I_I__V(s *String, start, end int32) {
	if start >= 0 { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_index = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), start, end-1, 10)
		if t.F_index <= 0 { panic(Thrown(IllegalFormatArgumentIndexException_New_I(t.F_index))) }; return nil }()
//line :380:1
		if tmp1 != nil { if NumberFormatException_InstanceOf(tmp1) { var x *NumberFormatException = NumberFormatException_Cast(tmp1); _ = x



			panic(Thrown(IllegalFormatArgumentIndexException_New_I(-2147483648))) } else {
//line :380:1
				panic(tmp1)
			}
		}
	}
}

func (t *Formatter_FormatSpecifier) Index__I() int32 { return t.F_index }

func (t *Formatter_FormatSpecifier) Flags_String_I_I__V(s *String, start, end int32) {
	t.F_flags = Formatter_Flags_Parse_String_I_I__I(s, start, end)
	if Formatter_Flags_Contains_I_I__Z(t.F_flags, 256) { t.F_index = -1
	} }
func (t *Formatter_FormatSpecifier) Width_String_I_I__V(s *String, start, end int32) {
	if start >= 0 { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_width = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), start, end, 10)
		if t.F_width < 0 { panic(Thrown(IllegalFormatWidthException_New_I(t.F_width))) }; return nil }()
//line :394:1
		if tmp1 != nil { if NumberFormatException_InstanceOf(tmp1) { var x *NumberFormatException = NumberFormatException_Cast(tmp1); _ = x


			panic(Thrown(IllegalFormatWidthException_New_I(-2147483648))) } else {
//line :394:1
				panic(tmp1)
			}
		}
	}
}
func (t *Formatter_FormatSpecifier) Precision_String_I_I__V(s *String, start, end int32) {
	if start >= 0 { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_precision = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(s), start+1, end, 10)
		if t.F_precision < 0 { panic(Thrown(IllegalFormatPrecisionException_New_I(t.F_precision))) }; return nil }()
//line :401:1
		if tmp1 != nil { if NumberFormatException_InstanceOf(tmp1) { var x *NumberFormatException = NumberFormatException_Cast(tmp1); _ = x



			panic(Thrown(IllegalFormatPrecisionException_New_I(-2147483648))) } else {
//line :401:1
				panic(tmp1)
			}
		}
	}
}

func (t *Formatter_FormatSpecifier) Conversion_C__V(conv uint16) {
	t.F_c = conv
	if t.F_dt { } else {
		if Formatter_Conversion_IsValid_C__Z(t.F_c) { } else {
			panic(Thrown(UnknownFormatConversionException_New_String(String_ValueOf_C__String(t.F_c)))) }
		if Character_IsUpperCase_C__Z(t.F_c) {
			t.F_flags = Formatter_Flags_Add_I_I__I(t.F_flags, 2)
			t.F_c = Character_ToLowerCase_C__C(t.F_c) }
		if Formatter_Conversion_IsText_C__Z(t.F_c) { t.F_index = -2
		} } }
func Formatter_FormatSpecifier_New_C(p0 uint16) *Formatter_FormatSpecifier { Formatter_FormatSpecifier_Init(); t := &Formatter_FormatSpecifier{}; t.Ctor_C(p0); return t }
//line :417:1
func (t *Formatter_FormatSpecifier) Ctor_C(conv uint16) { t.F_index = 0; t.F_flags = 0; t.F_width = -1; t.F_precision = -1; t.F_dt = false
	t.F_c = conv
	if Character_IsUpperCase_C__Z(conv) {
		t.F_flags = 2
		t.F_c = Character_ToLowerCase_C__C(conv) }
	if Formatter_Conversion_IsText_C__Z(conv) { t.F_index = -2
	} }
func Formatter_FormatSpecifier_New_String_I_I_I_I_I_C_C(p0 *String, p1, p2, p3, p4, p5 int32, p6, p7 uint16) *Formatter_FormatSpecifier { Formatter_FormatSpecifier_Init(); t := &Formatter_FormatSpecifier{}; t.Ctor_String_I_I_I_I_I_C_C(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :424:1
func (t *Formatter_FormatSpecifier) Ctor_String_I_I_I_I_I_C_C(s *String, i, argSize, flagSize, widthSize, precisionSize int32, t_, conversion uint16) { t.F_index = 0; t.F_flags = 0; t.F_width = -1; t.F_precision = -1; t.F_dt = false

	var argEnd int32 = i + argSize; var flagEnd int32 = argEnd + flagSize; var widthEnd int32 = flagEnd + widthSize; var precisionEnd int32 = widthEnd + precisionSize



	if argSize > 0 { t.Index_String_I_I__V(s, i, argEnd) }
	if flagSize > 0 { t.Flags_String_I_I__V(s, argEnd, flagEnd) }
	if widthSize > 0 { t.Width_String_I_I__V(s, flagEnd, widthEnd) }
	if precisionSize > 0 { t.Precision_String_I_I__V(s, widthEnd, precisionEnd) }
	if int32(t_) == 0 { } else {
		t.F_dt = true
		if int32(t_) == 84 { t.F_flags = Formatter_Flags_Add_I_I__I(t.F_flags, 2) } }
	t.Conversion_C__V(conversion)
	t.Check__V()
}
func (t *Formatter_FormatSpecifier) Check__V() {
	if t.F_dt {
		t.CheckDateTime__V() } else {
//line :441:1
			if Formatter_Conversion_IsGeneral_C__Z(t.F_c) {

				t.CheckGeneral__V() } else {
//line :441:1
					if Formatter_Conversion_IsCharacter_C__Z(t.F_c) {


						t.CheckCharacter__V() } else {
//line :441:1
							if Formatter_Conversion_IsInteger_C__Z(t.F_c) {



								t.CheckInteger__V() } else {
//line :441:1
									if Formatter_Conversion_IsFloat_C__Z(t.F_c) {




										t.CheckFloat__V() } else {
//line :441:1
											if Formatter_Conversion_IsText_C__Z(t.F_c) {





												t.CheckText__V() } else {
													panic(Thrown(UnknownFormatConversionException_New_String(String_ValueOf_C__String(t.F_c))))
												} } } } } } }
func (t *Formatter_FormatSpecifier) Print_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	if t.F_dt {
		t.PrintDateTime_Formatter_O_Locale__V(fmt, arg, l) } else {
			switch int32(t.F_c) { case 100, 111, 120:

				t.PrintInteger_Formatter_O_Locale__V(fmt, arg, l); case 101, 103, 102, 97:



				t.PrintFloat_Formatter_O_Locale__V(fmt, arg, l); case 99:
				t.PrintCharacter_Formatter_O_Locale__V(fmt, arg, l); case 98:
				t.PrintBoolean_Formatter_O_Locale__V(fmt, arg, l); case 115:
				t.PrintString_Formatter_O_Locale__V(fmt, arg, l); case 104:
				t.PrintHashCode_Formatter_O_Locale__V(fmt, arg, l); case 110:
				var tmp1 Appendable = fmt.F_a; tmp1.Append_CharSequence__Appendable(Up_String_CharSequence(System_LineSeparator__String())); case 37:
				t.Print_Formatter_String_Locale__V(fmt, Lit_1310, l); default:
				if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New()))
				}} } }
func (t *Formatter_FormatSpecifier) PrintInteger_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	if arg == nil {
		t.Print_Formatter_String_Locale__V(fmt, Lit_95, l) } else {
//line :469:1
			if Byte_InstanceOf(arg) {

				t.Print_Formatter_B_Locale__V(fmt, NN(Byte_Cast(arg)).ByteValue__B(), l) } else {
//line :469:1
					if Short_InstanceOf(arg) {


						t.Print_Formatter_S_Locale__V(fmt, NN(Short_Cast(arg)).ShortValue__S(), l) } else {
//line :469:1
							if Integer_InstanceOf(arg) {



								t.Print_Formatter_I_Locale__V(fmt, NN(Integer_Cast(arg)).IntValue__I(), l) } else {
//line :469:1
									if Long_InstanceOf(arg) {




										t.Print_Formatter_J_Locale__V(fmt, NN(Long_Cast(arg)).LongValue__J(), l) } else {
//line :469:1
											if BigInteger_InstanceOf(arg) {





												t.Print_Formatter_BigInteger_Locale__V(fmt, BigInteger_Cast(arg), l) } else {
													t.FailConversion_C_O__V(t.F_c, arg)
												} } } } } } }
func (t *Formatter_FormatSpecifier) PrintFloat_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	if arg == nil {
		t.Print_Formatter_String_Locale__V(fmt, Lit_95, l) } else {
//line :479:1
			if Float_InstanceOf(arg) {

				t.Print_Formatter_F_Locale__V(fmt, NN(Float_Cast(arg)).FloatValue__F(), l) } else {
//line :479:1
					if Double_InstanceOf(arg) {


						t.Print_Formatter_D_Locale__V(fmt, NN(Double_Cast(arg)).DoubleValue__D(), l) } else {
//line :479:1
							if BigDecimal_InstanceOf(arg) {



								t.Print_Formatter_BigDecimal_Locale__V(fmt, BigDecimal_Cast(arg), l) } else {
									t.FailConversion_C_O__V(t.F_c, arg)
								} } } } }
func (t *Formatter_FormatSpecifier) PrintDateTime_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	if arg == nil {
		t.Print_Formatter_String_Locale__V(fmt, Lit_95, l) } else {
			var cal Calendar_I
			if Long_InstanceOf(arg) {


				var tmp1 *Locale; if l == nil { Locale_Init(); tmp1 = Locale_US } else { tmp1 = l }; cal = Calendar_GetInstance_Locale__Calendar(tmp1)
				cal.SetTimeInMillis_J__V(NN(Long_Cast(arg)).LongValue__J()) } else {
//line :490:1
					if Date_InstanceOf(arg) {






						var tmp2 *Locale; if l == nil { Locale_Init(); tmp2 = Locale_US } else { tmp2 = l }; cal = Calendar_GetInstance_Locale__Calendar(tmp2)
						cal.SetTime_Date__V(Date_Cast(arg)) } else {
//line :490:1
							if Calendar_InstanceOf(arg) {









								cal = Calendar_Cast(Calendar_Cast(arg).Clone__O()); cal.SetLenient_Z__V(true) } else {
//line :490:1
									if TemporalAccessor_InstanceOf(arg) {











										t.Print_Formatter_TemporalAccessor_C_Locale__V(fmt, TemporalAccessor_Cast(arg), t.F_c, l); return } else {
											t.FailConversion_C_O__V(t.F_c, arg) } } } }
			t.Print_Formatter_Calendar_C_Locale__V(fmt, cal, t.F_c, l)
		} }
func (t *Formatter_FormatSpecifier) PrintCharacter_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	if arg == nil {
		t.Print_Formatter_String_Locale__V(fmt, Lit_95, l) } else {
			var s *String
			if Character_InstanceOf(arg) {
				s = NN(Character_Cast(arg)).ToString__String() } else {
//line :510:1
					if Byte_InstanceOf(arg) {


						var i int8 = NN(Byte_Cast(arg)).ByteValue__B()
						if Character_IsValidCodePoint_I__Z(int32(i)) {
							s = String_New_C1(Character_ToChars_I__C1(int32(i))) } else {
								panic(Thrown(IllegalFormatCodePointException_New_I(int32(i)))) } } else {
//line :510:1
									if Short_InstanceOf(arg) {







										var i_2 int16 = NN(Short_Cast(arg)).ShortValue__S()
										if Character_IsValidCodePoint_I__Z(int32(i_2)) {
											s = String_New_C1(Character_ToChars_I__C1(int32(i_2))) } else {
												panic(Thrown(IllegalFormatCodePointException_New_I(int32(i_2)))) } } else {
//line :510:1
													if Integer_InstanceOf(arg) {












														var i_3 int32 = NN(Integer_Cast(arg)).IntValue__I()
														if Character_IsValidCodePoint_I__Z(i_3) {
															s = String_New_C1(Character_ToChars_I__C1(i_3)) } else {
																panic(Thrown(IllegalFormatCodePointException_New_I(i_3))) } } else {
																	t.FailConversion_C_O__V(t.F_c, arg) } } } }
			t.Print_Formatter_String_Locale__V(fmt, s, l)
		} }
func (t *Formatter_FormatSpecifier) PrintString_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {

	if Formattable_InstanceOf(arg) {

		if NN(fmt).Locale__Locale() == l { } else { fmt = Formatter_New_Appendable_Locale(NN(fmt).Out__Appendable(), l) }
		Formattable_Cast(arg).FormatTo_Formatter_I_I_I__V(fmt, t.F_flags, t.F_width, t.F_precision) } else {

			if Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) { t.FailMismatch_I_C__V(4, 115) }
			if arg == nil { t.Print_Formatter_String_Locale__V(fmt, Lit_95, l) } else { t.Print_Formatter_String_Locale__V(fmt, ToString(arg), l)
			} } }
func (t *Formatter_FormatSpecifier) PrintBoolean_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	var s *String; if !(arg == nil) {
		if Boolean_InstanceOf(arg) {
			s = NN(Boolean_Cast(arg)).ToString__String() } else {
				s = Boolean_ToString_Z__String(true) } } else {
					s = Boolean_ToString_Z__String(false) }
	t.Print_Formatter_String_Locale__V(fmt, s, l)
}
func (t *Formatter_FormatSpecifier) PrintHashCode_Formatter_O_Locale__V(fmt *Formatter, arg any, l *Locale) {
	var s *String; if arg == nil { s = Lit_95 } else { s = Integer_ToHexString_I__String(HashCode(arg)) }
	t.Print_Formatter_String_Locale__V(fmt, s, l)
}
func (t *Formatter_FormatSpecifier) Print_Formatter_String_Locale__V(fmt *Formatter, s *String, l *Locale) {

	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_precision == -1); if tmp2 { var tmp3 int32 = t.F_precision; tmp2 = tmp3 < NN(s).Length__I() }; tmp1 = tmp2; if tmp1 {
		s = NN(s).Substring_I_I__String(0, t.F_precision) }
	if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) { s = t.ToUpperCaseWithLocale_String_Locale__String(s, l) }
	t.AppendJustified_Appendable_CharSequence__V(fmt.F_a, Up_String_CharSequence(s))
}
func (t *Formatter_FormatSpecifier) ToUpperCaseWithLocale_String_Locale__String(s *String, l *Locale) *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return NN(s).ToUpperCase_Locale__String(Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), Locale_GetDefault_Locale_Category__Locale(tmp1).Ref())))
}


func (t *Formatter_FormatSpecifier) AppendJustified_Appendable_CharSequence__V(a Appendable, cs CharSequence) {

	if t.F_width == -1 {
		a.Append_CharSequence__Appendable(cs) } else {
			var padRight bool = Formatter_Flags_Contains_I_I__Z(t.F_flags, 1); var tmp1 int32 = t.F_width; var sp int32 = tmp1 - cs.Length__I()

			if padRight { a.Append_CharSequence__Appendable(cs) }
			var i int32 = 0; L1: for { if i < sp { a.Append_C__Appendable(32); i = i + 1; continue L1 }; break L1 }
			if padRight { } else { a.Append_CharSequence__Appendable(cs)
			} } }
func (t *Formatter_FormatSpecifier) ToString__String() *String {
	var sb *StringBuilder = StringBuilder_New_String(Lit_1310)
	NN(sb).Append_String__StringBuilder(Formatter_Flags_ToString_I__String(Formatter_Flags_Remove_I_I__I(t.F_flags, 2)))
	if t.F_index > 0 { NN(NN(sb).Append_I__StringBuilder(t.F_index)).Append_C__StringBuilder(36) }
	if t.F_width == -1 { } else { NN(sb).Append_I__StringBuilder(t.F_width) }
	if t.F_precision == -1 { } else { NN(NN(sb).Append_C__StringBuilder(46)).Append_I__StringBuilder(t.F_precision) }
	if t.F_dt { var tmp1 uint16; if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) { tmp1 = 84 } else { tmp1 = 116 }; NN(sb).Append_C__StringBuilder(tmp1) }
	var tmp2 uint16; if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) { tmp2 = Character_ToUpperCase_C__C(t.F_c) } else { tmp2 = t.F_c }; NN(sb).Append_C__StringBuilder(tmp2)
	return NN(sb).ToString__String()
}
func (t *Formatter_FormatSpecifier) CheckGeneral__V() {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = int32(t.F_c) == 98; if !tmp3 { tmp3 = int32(t.F_c) == 104 }; tmp2 = tmp3; if tmp2 {
		tmp2 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) }
//line :585:1
	tmp1 = tmp2; if tmp1 {

		t.FailMismatch_I_C__V(4, t.F_c) }
	var tmp4 bool; var tmp5 bool; tmp5 = t.F_width == -1; if tmp5 { tmp5 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 1) }; tmp4 = tmp5; if tmp4 {
		panic(Thrown(MissingFormatWidthException_New_String(t.ToString__String()))) }
	t.CheckBadFlags_I__V(248)
}





func (t *Formatter_FormatSpecifier) CheckDateTime__V() {
	if t.F_precision == -1 { } else { panic(Thrown(IllegalFormatPrecisionException_New_I(t.F_precision))) }
	if Formatter_DateTime_IsValid_C__Z(t.F_c) { } else { panic(Thrown(UnknownFormatConversionException_New_String(Concat(Lit_2679, StrOfChar(t.F_c))))) }
	t.CheckBadFlags_I__V(252)







	var tmp1 bool; var tmp2 bool; tmp2 = t.F_width == -1; if tmp2 { tmp2 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 1) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(MissingFormatWidthException_New_String(t.ToString__String())))
	} }
func (t *Formatter_FormatSpecifier) CheckCharacter__V() {
	if t.F_precision == -1 { } else { panic(Thrown(IllegalFormatPrecisionException_New_I(t.F_precision))) }
	t.CheckBadFlags_I__V(252)







	var tmp1 bool; var tmp2 bool; tmp2 = t.F_width == -1; if tmp2 { tmp2 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 1) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(MissingFormatWidthException_New_String(t.ToString__String())))
	} }
func (t *Formatter_FormatSpecifier) CheckInteger__V() {
	t.CheckNumeric__V()
	if t.F_precision == -1 { } else { panic(Thrown(IllegalFormatPrecisionException_New_I(t.F_precision))) }
	if int32(t.F_c) == 100 {
		t.CheckBadFlags_I__V(4) } else {
//line :627:1
			if int32(t.F_c) == 111 {

				t.CheckBadFlags_I__V(64) } else {
					t.CheckBadFlags_I__V(64)
				} } }
func (t *Formatter_FormatSpecifier) CheckBadFlags_I__V(badFlags int32) {
	if t.F_flags&badFlags == 0 { } else {
		t.FailMismatch_I_C__V(t.F_flags&badFlags, t.F_c)
	} }
func (t *Formatter_FormatSpecifier) CheckFloat__V() {
	t.CheckNumeric__V()
	if int32(t.F_c) == 102 { } else {
		if int32(t.F_c) == 97 {

			t.CheckBadFlags_I__V(192) } else {
//line :639:1
				if int32(t.F_c) == 101 {


					t.CheckBadFlags_I__V(64) } else {
//line :639:1
						if int32(t.F_c) == 103 {



							t.CheckBadFlags_I__V(4)
						} } } } }
func (t *Formatter_FormatSpecifier) CheckNumeric__V() {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_width == -1); if tmp2 { tmp2 = t.F_width < 0 }; tmp1 = tmp2; if tmp1 { panic(Thrown(IllegalFormatWidthException_New_I(t.F_width))) }
	var tmp3 bool; var tmp4 bool; tmp4 = !(t.F_precision == -1); if tmp4 { tmp4 = t.F_precision < 0 }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(IllegalFormatPrecisionException_New_I(t.F_precision))) }
	var tmp5 bool; var tmp6 bool; tmp6 = t.F_width == -1; if tmp6 {
		tmp6 = Formatter_Flags_ContainsAny_I_I__Z(t.F_flags, 33) }
//line :649:1
	tmp5 = tmp6; if tmp5 {

		panic(Thrown(MissingFormatWidthException_New_String(t.ToString__String()))) }
	var tmp7 bool; var tmp8 bool; tmp8 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 24); if !tmp8 {
		tmp8 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 33) }
//line :652:1
	tmp7 = tmp8; if tmp7 {

		panic(Thrown(IllegalFormatFlagsException_New_String(Formatter_Flags_ToString_I__String(t.F_flags))))
	} }
func (t *Formatter_FormatSpecifier) CheckText__V() {
	if t.F_precision == -1 { } else { panic(Thrown(IllegalFormatPrecisionException_New_I(t.F_precision))) }
	switch int32(t.F_c) { case 37:


		var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_flags == 1); if tmp2 { tmp2 = !(t.F_flags == 0) }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(IllegalFormatFlagsException_New_String(Formatter_Flags_ToString_I__String(t.F_flags)))) }
		var tmp3 bool; var tmp4 bool; tmp4 = t.F_width == -1; if tmp4 { tmp4 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 1) }; tmp3 = tmp4; if tmp3 {
			panic(Thrown(MissingFormatWidthException_New_String(t.ToString__String()))) }; case 110:


		if t.F_width == -1 { } else { panic(Thrown(IllegalFormatWidthException_New_I(t.F_width))) }
		if t.F_flags == 0 { } else {
			panic(Thrown(IllegalFormatFlagsException_New_String(Formatter_Flags_ToString_I__String(t.F_flags)))) }; default:
		if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New()))
		}} }
func (t *Formatter_FormatSpecifier) Print_Formatter_B_Locale__V(fmt *Formatter, value int8, l *Locale) {
	var v int64 = int64(value); var tmp1 bool; var tmp2 bool
	tmp2 = int32(value) < 0; if tmp2 {
		var tmp3 bool; tmp3 = int32(t.F_c) == 111; if !tmp3 { tmp3 = int32(t.F_c) == 120 }; tmp2 = tmp3 }
//line :674:1
	tmp1 = tmp2; if tmp1 {

		v = v + 256 }
	t.Print_Formatter_J_Locale__V(fmt, v, l)
}
func (t *Formatter_FormatSpecifier) Print_Formatter_S_Locale__V(fmt *Formatter, value int16, l *Locale) {
	var v int64 = int64(value); var tmp1 bool; var tmp2 bool
	tmp2 = int32(value) < 0; if tmp2 {
		var tmp3 bool; tmp3 = int32(t.F_c) == 111; if !tmp3 { tmp3 = int32(t.F_c) == 120 }; tmp2 = tmp3 }
//line :681:1
	tmp1 = tmp2; if tmp1 {

		v = v + 65536
		if !A2g_AssertionsDisabled && !(v >= 0) { panic(Thrown(AssertionError_New_J(v))) } }
	t.Print_Formatter_J_Locale__V(fmt, v, l)
}
func (t *Formatter_FormatSpecifier) Print_Formatter_I_Locale__V(fmt *Formatter, value int32, l *Locale) {
	var v int64 = int64(value); var tmp1 bool; var tmp2 bool
	tmp2 = value < 0; if tmp2 {
		var tmp3 bool; tmp3 = int32(t.F_c) == 111; if !tmp3 { tmp3 = int32(t.F_c) == 120 }; tmp2 = tmp3 }
//line :689:1
	tmp1 = tmp2; if tmp1 {

		v = v + 4294967296
		if !A2g_AssertionsDisabled && !(v >= 0) { panic(Thrown(AssertionError_New_J(v))) } }
	t.Print_Formatter_J_Locale__V(fmt, v, l)
}
func (t *Formatter_FormatSpecifier) Print_Formatter_J_Locale__V(fmt *Formatter, value int64, l *Locale) {
	var sb *StringBuilder = StringBuilder_New()
	if int32(t.F_c) == 100 {

		var neg bool = value < 0; var valueStr *String = Long_ToString_J_I__String(value, 10)

		t.LeadingSign_StringBuilder_Z__StringBuilder(sb, neg)
		var tmp1 int32



		if neg { tmp1 = 1 } else { tmp1 = 0 }
//line :702:1
		var tmp2 int32 = tmp1; var tmp3 int32 = t.F_flags; t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, Up_String_CharSequence(valueStr), tmp2, tmp3, t.AdjustWidth_I_I_Z__I(t.F_width, t.F_flags, neg), l)







		t.TrailingSign_StringBuilder_Z__StringBuilder(sb, neg) } else {
//line :697:1
			if int32(t.F_c) == 111 {















				t.CheckBadFlags_I__V(152)


				var s *String = Long_ToOctalString_J__String(value); var len_ int32
				if Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) {
					len_ = NN(s).Length__I() + 1 } else {
						len_ = NN(s).Length__I() }
				if Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) { NN(sb).Append_C__StringBuilder(48) }
				if Formatter_Flags_Contains_I_I__Z(t.F_flags, 32) {
					t.TrailingZeros_StringBuilder_I__V(sb, t.F_width-len_) }
				NN(sb).Append_String__StringBuilder(s) } else {

					if int32(t.F_c) == 120 {
						t.CheckBadFlags_I__V(152)


						var s_2 *String = Long_ToHexString_J__String(value); var len__2 int32
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) {
							len__2 = NN(s_2).Length__I() + 2 } else {
								len__2 = NN(s_2).Length__I() }
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) {
							var tmp4 *String; if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) { tmp4 = Lit_1131 } else { tmp4 = Lit_1130 }; NN(sb).Append_String__StringBuilder(tmp4) }
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 32) {
							t.TrailingZeros_StringBuilder_I__V(sb, t.F_width-len__2) }
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) {
							s_2 = t.ToUpperCaseWithLocale_String_Locale__String(s_2, l) }
						NN(sb).Append_String__StringBuilder(s_2) } } }
	t.AppendJustified_Appendable_CharSequence__V(fmt.F_a, Up_StringBuilder_CharSequence(sb))
}
func (t *Formatter_FormatSpecifier) LeadingSign_StringBuilder_Z__StringBuilder(sb *StringBuilder, neg bool) *StringBuilder {
	if !neg {

		if Formatter_Flags_Contains_I_I__Z(t.F_flags, 8) {
			NN(sb).Append_C__StringBuilder(43) } else {
//line :745:1
				if Formatter_Flags_Contains_I_I__Z(t.F_flags, 16) {

					NN(sb).Append_C__StringBuilder(32) } } } else {
//line :743:1
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 128) {




							NN(sb).Append_C__StringBuilder(40) } else {
								NN(sb).Append_C__StringBuilder(45) } }
//line :742:1
	return sb
}








func (t *Formatter_FormatSpecifier) TrailingSign_StringBuilder_Z__StringBuilder(sb *StringBuilder, neg bool) *StringBuilder {
	var tmp1 bool; var tmp2 bool; tmp2 = neg; if tmp2 { tmp2 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 128) }; tmp1 = tmp2; if tmp1 { NN(sb).Append_C__StringBuilder(41) }
//line :752:1
	return sb
}


func (t *Formatter_FormatSpecifier) Print_Formatter_BigInteger_Locale__V(fmt *Formatter, value *BigInteger, l *Locale) {

	var sb *StringBuilder = StringBuilder_New(); var neg bool = NN(value).Signum__I() == -1; var v *BigInteger = NN(value).Abs__BigInteger()


	t.LeadingSign_StringBuilder_Z__StringBuilder(sb, neg)
	if int32(t.F_c) == 100 {

		var tmp1 CharSequence = Up_String_CharSequence(NN(v).ToString__String()); var tmp2 int32 = t.F_flags; t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, tmp1, 0, tmp2, t.AdjustWidth_I_I_Z__I(t.F_width, t.F_flags, neg), l) } else {
//line :762:1
			if int32(t.F_c) == 111 {










				var s *String = NN(v).ToString_I__String(8); var len_ int32 = NN(s).Length__I() + NN(sb).Length__I(); var tmp3 bool; var tmp4 bool

				tmp4 = neg; if tmp4 { tmp4 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 128) }; tmp3 = tmp4; if tmp3 {
					len_ = len_ + 1 }
				if Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) {
					len_ = len_ + 1
					NN(sb).Append_C__StringBuilder(48) }
				if Formatter_Flags_Contains_I_I__Z(t.F_flags, 32) {
					t.TrailingZeros_StringBuilder_I__V(sb, t.F_width-len_) }
				NN(sb).Append_String__StringBuilder(s) } else {
//line :762:1
					if int32(t.F_c) == 120 {





















						var s_2 *String = NN(v).ToString_I__String(16); var len__2 int32 = NN(s_2).Length__I() + NN(sb).Length__I(); var tmp5 bool; var tmp6 bool

						tmp6 = neg; if tmp6 { tmp6 = Formatter_Flags_Contains_I_I__Z(t.F_flags, 128) }; tmp5 = tmp6; if tmp5 {
							len__2 = len__2 + 1 }
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 4) {
							len__2 = len__2 + 2
							var tmp7 *String; if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) { tmp7 = Lit_1131 } else { tmp7 = Lit_1130 }; NN(sb).Append_String__StringBuilder(tmp7) }
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 32) {
							t.TrailingZeros_StringBuilder_I__V(sb, t.F_width-len__2) }
						if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) {
							s_2 = t.ToUpperCaseWithLocale_String_Locale__String(s_2, l) }
						NN(sb).Append_String__StringBuilder(s_2) } } }
	t.TrailingSign_StringBuilder_Z__StringBuilder(sb, NN(value).Signum__I() == -1)
	t.AppendJustified_Appendable_CharSequence__V(fmt.F_a, Up_StringBuilder_CharSequence(sb))
}
func (t *Formatter_FormatSpecifier) Print_Formatter_F_Locale__V(fmt *Formatter, value float32, l *Locale) {
	t.Print_Formatter_D_Locale__V(fmt, float64(value), l)
}
func (t *Formatter_FormatSpecifier) Print_Formatter_D_Locale__V(fmt *Formatter, value float64, l *Locale) {
	var sb *StringBuilder = StringBuilder_New(); var neg bool = Double_Compare_D_D__I(value, 0.0) == -1

	if !Double_IsNaN_D__Z(value) {
		var v float64 = Math_Abs_D__D(value)
		t.LeadingSign_StringBuilder_Z__StringBuilder(sb, neg)
		if !Double_IsInfinite_D__Z(v) {
			t.Print_Formatter_StringBuilder_D_Locale_I_C_I_Z__V(fmt, sb, v, l, t.F_flags, t.F_c, t.F_precision, neg) } else {
				var tmp1 *String

				if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) { tmp1 = Lit_2680 } else { tmp1 = Lit_2681 }
//line :810:1
				NN(sb).Append_String__StringBuilder(tmp1)
			}

		t.TrailingSign_StringBuilder_Z__StringBuilder(sb, neg) } else {
			var tmp2 *String; if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) { tmp2 = Lit_2682 } else { tmp2 = Lit_2683 }; NN(sb).Append_String__StringBuilder(tmp2) }
	t.AppendJustified_Appendable_CharSequence__V(fmt.F_a, Up_StringBuilder_CharSequence(sb))
}
func (t *Formatter_FormatSpecifier) Print_Formatter_StringBuilder_D_Locale_I_C_I_Z__V(fmt *Formatter, sb *StringBuilder, value float64, l *Locale, flags int32, c uint16, precision int32, neg bool) {

	if int32(c) == 101 {

		var prec int32; if precision == -1 { prec = 6 } else { prec = precision }; var fd *FormattedFPDecimal = FormattedFPDecimal_ValueOf_D_I_C__FormattedFPDecimal(value, prec, 101); var mant *StringBuilder = StringBuilder_New().Append_C1__StringBuilder(NN(fd).GetMantissa__C1())


		t.AddZeros_StringBuilder_I__V(mant, prec)
		var tmp1 bool; var tmp2 bool; tmp2 = Formatter_Flags_Contains_I_I__Z(flags, 4); if tmp2 { tmp2 = prec == 0 }; tmp1 = tmp2; if tmp1 { NN(mant).Append_C__StringBuilder(46) }
		var exp *CharArray; if value == 0.0 { exp = CharArrayOf(43, 48, 48) } else { exp = NN(fd).GetExponent__C1() }; var newW int32 = t.F_width

		if t.F_width == -1 { } else {
			var tmp3 int32 = t.F_width; newW = t.AdjustWidth_I_I_Z__I(tmp3-int32(len(exp.A))-1, flags, neg)
		}





		t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, Up_StringBuilder_CharSequence(mant), 0, flags, newW, l)
		var tmp4 uint16; if Formatter_Flags_Contains_I_I__Z(flags, 2) { tmp4 = 69 } else { tmp4 = 101 }; NN(sb).Append_C__StringBuilder(tmp4)
		var sign uint16 = exp.A[0]; var tmp5 bool; var tmp6 bool
		tmp6 = int32(sign) == 43; if !tmp6 { tmp6 = int32(sign) == 45 }; tmp5 = tmp6; if !A2g_AssertionsDisabled && !tmp5 { panic(Thrown(AssertionError_New())) }
		NN(sb).Append_C__StringBuilder(sign)
		t.LocalizedMagnitudeExp_Formatter_StringBuilder_C1_I_Locale__V(fmt, sb, exp, 1, l) } else {
//line :819:1
			if int32(c) == 102 {























				var prec_2 int32; if precision == -1 { prec_2 = 6 } else { prec_2 = precision }; var fd_2 *FormattedFPDecimal = FormattedFPDecimal_ValueOf_D_I_C__FormattedFPDecimal(value, prec_2, 102); var mant_2 *StringBuilder = StringBuilder_New().Append_C1__StringBuilder(NN(fd_2).GetMantissa__C1())


				t.AddZeros_StringBuilder_I__V(mant_2, prec_2)
				var tmp7 bool; var tmp8 bool; tmp8 = Formatter_Flags_Contains_I_I__Z(flags, 4); if tmp8 { tmp8 = prec_2 == 0 }; tmp7 = tmp8; if tmp7 { NN(mant_2).Append_C__StringBuilder(46) }
				var newW_2 int32 = t.F_width
				if t.F_width == -1 { } else { newW_2 = t.AdjustWidth_I_I_Z__I(t.F_width, flags, neg) }
				t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, Up_StringBuilder_CharSequence(mant_2), 0, flags, newW_2, l) } else {
//line :819:1
					if int32(c) == 103 {
































						var prec_3 int32 = precision
						if precision == -1 { prec_3 = 6 } else { if precision == 0 { prec_3 = 1 } }
						var exp_2 *CharArray; var mant_3 *StringBuilder = StringBuilder_New()
						var expRounded int32 = 0

						if value == 0.0 {
							exp_2 = nil; NN(mant_3).Append_C__StringBuilder(48); expRounded = 0 } else {
								var fd_3 *FormattedFPDecimal = FormattedFPDecimal_ValueOf_D_I_C__FormattedFPDecimal(value, prec_3, 103)
								exp_2 = NN(fd_3).GetExponent__C1()
								NN(mant_3).Append_C1__StringBuilder(NN(fd_3).GetMantissa__C1())
								expRounded = NN(fd_3).GetExponentRounded__I() }
						if !(exp_2 == nil) {
							prec_3 = prec_3 - 1 } else {
								prec_3 = prec_3 - (expRounded + 1) }
						t.AddZeros_StringBuilder_I__V(mant_3, prec_3)
						var tmp9 bool; var tmp10 bool; tmp10 = Formatter_Flags_Contains_I_I__Z(flags, 4); if tmp10 { tmp10 = prec_3 == 0 }; tmp9 = tmp10; if tmp9 { NN(mant_3).Append_C__StringBuilder(46) }
						var newW_3 int32 = t.F_width
						if t.F_width == -1 { } else {
							if !(exp_2 == nil) {
								var tmp11 int32 = t.F_width; newW_3 = t.AdjustWidth_I_I_Z__I(tmp11-int32(len(exp_2.A))-1, flags, neg) } else {






									newW_3 = t.AdjustWidth_I_I_Z__I(t.F_width, flags, neg) } }
						t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, Up_StringBuilder_CharSequence(mant_3), 0, flags, newW_3, l)
						if !(exp_2 == nil) {
							var tmp12 uint16; if Formatter_Flags_Contains_I_I__Z(flags, 2) { tmp12 = 69 } else { tmp12 = 101 }; NN(sb).Append_C__StringBuilder(tmp12)
							var sign_2 uint16 = exp_2.A[0]; var tmp13 bool; var tmp14 bool
							tmp14 = int32(sign_2) == 43; if !tmp14 { tmp14 = int32(sign_2) == 45 }; tmp13 = tmp14; if !A2g_AssertionsDisabled && !tmp13 { panic(Thrown(AssertionError_New())) }
							NN(sb).Append_C__StringBuilder(sign_2)
							t.LocalizedMagnitudeExp_Formatter_StringBuilder_C1_I_Locale__V(fmt, sb, exp_2, 1, l) } } else {
//line :819:1
								if int32(c) == 97 {



































































									var prec_4 int32 = precision
									if precision == -1 { prec_4 = 0 } else { if precision == 0 { prec_4 = 1 } }
									var s *String = t.HexDouble_D_I__String(value, prec_4); var va *StringBuilder = StringBuilder_New(); var upper bool = Formatter_Flags_Contains_I_I__Z(flags, 2); var tmp15 *String


									if upper { tmp15 = Lit_1131 } else { tmp15 = Lit_1130 }; NN(sb).Append_String__StringBuilder(tmp15)
									if Formatter_Flags_Contains_I_I__Z(flags, 32) {
										var leadingCharacters int32 = 2; var tmp16 bool; var tmp17 bool; var tmp18 bool
										tmp18 = Formatter_Flags_Contains_I_I__Z(flags, 16); if !tmp18 {
											tmp18 = Formatter_Flags_Contains_I_I__Z(flags, 8) }
//line :895:1
										tmp17 = tmp18; if !tmp17 { tmp17 = neg }; tmp16 = tmp17; if tmp16 {


											leadingCharacters = 3 }
										var tmp19 int32 = t.F_width; t.TrailingZeros_StringBuilder_I__V(sb, tmp19-NN(s).Length__I()-leadingCharacters)
									}



									var idx int32 = NN(s).IndexOf_I__I(112)
									if upper {
										var tmp *String = NN(s).Substring_I_I__String(0, idx); var tmp20 *String = tmp; var tmp21 *Locale
										Locale_Init(); tmp21 = Locale_ROOT; tmp = NN(tmp20).ToUpperCase_Locale__String(tmp21)
										NN(va).Append_String__StringBuilder(tmp) } else {
											NN(va).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(s), 0, idx) }
									if prec_4 == 0 { } else { t.AddZeros_StringBuilder_I__V(va, prec_4) }
									NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(va))
									var tmp22 uint16; if upper { tmp22 = 80 } else { tmp22 = 112 }; NN(sb).Append_C__StringBuilder(tmp22)
									NN(sb).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(s), idx+1, NN(s).Length__I())
								} } } } }
func (t *Formatter_FormatSpecifier) AddZeros_StringBuilder_I__V(sb *StringBuilder, prec int32) {
	var len_ int32 = NN(sb).Length__I()
	var i int32 = 0
	i = 0
L1: for { if i < len_ { if int32(NN(sb).CharAt_I__C(i)) == 46 { break L1 }; i = i + 1; continue L1 }; break L1 }
	var needDot bool = false
	if i == len_ { needDot = true }
	var outPrec int32; var tmp1 int32 = len_ - i; var tmp2 int32; if needDot { tmp2 = 0 } else { tmp2 = 1 }; outPrec = tmp1 - tmp2
	if !A2g_AssertionsDisabled && !(outPrec <= prec) { panic(Thrown(AssertionError_New())) }
	if outPrec == prec { } else {
		if needDot { NN(sb).Append_C__StringBuilder(46) }
		t.TrailingZeros_StringBuilder_I__V(sb, prec-outPrec)
	} }
func (t *Formatter_FormatSpecifier) HexDouble_D_I__String(d float64, prec int32) *String {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = !Double_IsFinite_D__Z(d); if !tmp4 { tmp4 = d == 0.0 }; tmp3 = tmp4; if !tmp3 { tmp3 = prec == 0 }; tmp2 = tmp3; if !tmp2 { tmp2 = prec >= 13 }; tmp1 = tmp2; if tmp1 {
		return NN(Double_ToHexString_D__String(d)).Substring_I__String(2) } else {

			var tmp5 bool; var tmp6 bool; tmp6 = prec >= 1; if tmp6 { tmp6 = prec <= 12 }; tmp5 = tmp6; if !A2g_AssertionsDisabled && !tmp5 { panic(Thrown(AssertionError_New())) }
			var exponent int32 = Math_GetExponent_D__I(d); var subnormal bool = exponent == -1023

			if subnormal {
				d = float64(d * Formatter_FormatSpecifier_SCALEUP)
				exponent = Math_GetExponent_D__I(d)
				var tmp7 bool; var tmp8 bool; tmp8 = exponent >= -1022; if tmp8 {
					tmp8 = exponent <= 1023 }
//line :938:1
				tmp7 = tmp8; if !A2g_AssertionsDisabled && !tmp7 { panic(Thrown(AssertionError_New_I(exponent)))
				}
			}
			var precision int32 = 1 + prec*4; var shiftDistance int32 = 53 - precision; var tmp9 bool; var tmp10 bool

			tmp10 = shiftDistance >= 1; if tmp10 {
				tmp10 = shiftDistance < 53 }
//line :943:1
			tmp9 = tmp10; if !A2g_AssertionsDisabled && !tmp9 { panic(Thrown(AssertionError_New()))
			}
			var doppel int64 = Double_DoubleToLongBits_D__J(d); var newSignif int64 = doppel & 9223372036854775807 >> (shiftDistance & 63); var roundingBits int64 = doppel & ^(-1 << (shiftDistance & 63)); var leastZero bool = newSignif&1 == 0; var round bool = !(1<<((shiftDistance-1)&63)&roundingBits == 0); var sticky bool; var tmp11 bool















			tmp11 = shiftDistance > 1; if tmp11 {
				tmp11 = !(^(1<<((shiftDistance-1)&63))&roundingBits == 0) }
//line :961:1
			sticky = tmp11







			var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = leastZero; if tmp15 { tmp15 = round }; tmp14 = tmp15; if tmp14 { tmp14 = sticky }; tmp13 = tmp14; if !tmp13 { var tmp16 bool; tmp16 = !leastZero; if tmp16 { tmp16 = round }; tmp13 = tmp16 }; tmp12 = tmp13; if tmp12 {
				newSignif = newSignif + 1 }
			var signBit int64 = doppel & -9223372036854775808
			newSignif = signBit | newSignif<<(shiftDistance&63)
			var result float64 = Double_LongBitsToDouble_J__D(newSignif)
			if Double_IsInfinite_D__Z(result) { return Lit_2684 } else {

				var res *String = NN(Double_ToHexString_D__String(result)).Substring_I__String(2)
				if !subnormal { return res } else {

					var idx int32 = NN(res).IndexOf_I__I(112)
					if idx == -1 {
						if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New())) }; return nil } else {
							var exp *String = NN(res).Substring_I__String(idx + 1); var iexp int32 = Integer_ParseInt_String__I(exp) - 54

							return Concat(NN(res).Substring_I_I__String(0, idx), Lit_2685, Integer_ToString_I__String(iexp))
						}
				}
			}
		} }
func (t *Formatter_FormatSpecifier) Print_Formatter_BigDecimal_Locale__V(fmt *Formatter, value *BigDecimal, l *Locale) {

	if int32(t.F_c) == 97 { t.FailConversion_C_O__V(t.F_c, value.Ref()) }
	var sb *StringBuilder = StringBuilder_New(); var neg bool = NN(value).Signum__I() == -1; var v *BigDecimal = NN(value).Abs__BigDecimal()


	t.LeadingSign_StringBuilder_Z__StringBuilder(sb, neg)
	t.Print_Formatter_StringBuilder_BigDecimal_Locale_I_C_I_Z__V(fmt, sb, v, l, t.F_flags, t.F_c, t.F_precision, neg)
	t.TrailingSign_StringBuilder_Z__StringBuilder(sb, neg)
	t.AppendJustified_Appendable_CharSequence__V(fmt.F_a, Up_StringBuilder_CharSequence(sb))
}
func (t *Formatter_FormatSpecifier) Print_Formatter_StringBuilder_BigDecimal_Locale_I_C_I_Z__V(fmt *Formatter, sb *StringBuilder, value *BigDecimal, l *Locale, flags int32, c uint16, precision int32, neg bool) {



	if int32(c) == 101 {

		var prec int32; if precision == -1 { prec = 6 } else { prec = precision }; var scale int32 = NN(value).Scale__I(); var origPrec int32 = NN(value).Precision__I()
		var nzeros int32 = 0
		var compPrec int32 = 0


		if prec > origPrec-1 {

			compPrec = origPrec
			nzeros = prec - (origPrec - 1) } else {
				compPrec = prec + 1 }
		var mc *MathContext = MathContext_New_I(compPrec); var v *BigDecimal = BigDecimal_New_BigInteger_I_MathContext(NN(value).UnscaledValue__BigInteger(), scale, mc); var bdl *Formatter_FormatSpecifier_BigDecimalLayout; var tmp1 *BigInteger = NN(v).UnscaledValue__BigInteger(); var tmp2 int32 = NN(v).Scale__I(); var tmp3 *Formatter_BigDecimalLayoutForm

		Formatter_BigDecimalLayoutForm_Init(); tmp3 = Formatter_BigDecimalLayoutForm_SCIENTIFIC; bdl = Formatter_FormatSpecifier_BigDecimalLayout_New_Formatter_FormatSpecifier_BigInteger_I_Formatter_BigDecimalLayoutForm(t, tmp1, tmp2, tmp3)
//line :1016:1
		var mant *StringBuilder = NN(bdl).Mantissa__StringBuilder(); var tmp4 bool; var tmp5 bool; var tmp6 bool





		tmp6 = origPrec == 1; if !tmp6 { tmp6 = !NN(bdl).HasDot__Z() }; tmp5 = tmp6; if tmp5 {
			var tmp7 bool; tmp7 = nzeros > 0; if !tmp7 { tmp7 = Formatter_Flags_Contains_I_I__Z(flags, 4) }; tmp5 = tmp7 }
//line :1022:1
		tmp4 = tmp5; if tmp4 {

			NN(mant).Append_C__StringBuilder(46) }
		t.TrailingZeros_StringBuilder_I__V(mant, nzeros)
		var exp *StringBuilder = NN(bdl).Exponent__StringBuilder(); var newW int32 = t.F_width

		if t.F_width == -1 { } else {
			var tmp8 int32 = t.F_width; newW = t.AdjustWidth_I_I_Z__I(tmp8-NN(exp).Length__I()-1, flags, neg)
		}





		t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, Up_StringBuilder_CharSequence(mant), 0, flags, newW, l)
		var tmp9 uint16; if Formatter_Flags_Contains_I_I__Z(flags, 2) { tmp9 = 69 } else { tmp9 = 101 }; NN(sb).Append_C__StringBuilder(tmp9)
		var adaptedFlags int32 = Formatter_Flags_Remove_I_I__I(flags, 64); var sign uint16 = NN(exp).CharAt_I__C(0); var tmp10 bool; var tmp11 bool

		tmp11 = int32(sign) == 43; if !tmp11 { tmp11 = int32(sign) == 45 }; tmp10 = tmp11; if !A2g_AssertionsDisabled && !tmp10 { panic(Thrown(AssertionError_New())) }
		NN(sb).Append_C__StringBuilder(sign)
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, nil, Up_StringBuilder_CharSequence(exp), 1, adaptedFlags, -1, l))) } else {
//line :1004:1
			if int32(c) == 102 {







































				var prec_2 int32; if precision == -1 { prec_2 = 6 } else { prec_2 = precision }; var scale_2 int32 = NN(value).Scale__I()

				if scale_2 > prec_2 {
					var compPrec_2 int32 = NN(value).Precision__I()
					if compPrec_2 <= scale_2 {
						var tmp12 *BigDecimal = value; var tmp13 *RoundingMode; RoundingMode_Init(); tmp13 = RoundingMode_HALF_UP; value = NN(tmp12).SetScale_I_RoundingMode__BigDecimal(prec_2, tmp13) } else {

							compPrec_2 = compPrec_2 - (scale_2 - prec_2)

							value = BigDecimal_New_BigInteger_I_MathContext(NN(value).UnscaledValue__BigInteger(), scale_2, MathContext_New_I(compPrec_2))
						} }
				var bdl_2 *Formatter_FormatSpecifier_BigDecimalLayout; var tmp14 *BigInteger = NN(value).UnscaledValue__BigInteger(); var tmp15 int32 = NN(value).Scale__I(); var tmp16 *Formatter_BigDecimalLayoutForm; Formatter_BigDecimalLayoutForm_Init(); tmp16 = Formatter_BigDecimalLayoutForm_DECIMAL_FLOAT; bdl_2 = Formatter_FormatSpecifier_BigDecimalLayout_New_Formatter_FormatSpecifier_BigInteger_I_Formatter_BigDecimalLayoutForm(t, tmp14, tmp15, tmp16); var mant_2 *StringBuilder = NN(bdl_2).Mantissa__StringBuilder(); var nzeros_2 int32



				if NN(bdl_2).Scale__I() < prec_2 {
					nzeros_2 = prec_2 - NN(bdl_2).Scale__I() } else {
//line :1059:1
						nzeros_2 = 0
					}

				var tmp17 bool; var tmp18 bool; tmp18 = NN(bdl_2).Scale__I() == 0; if tmp18 {
					var tmp19 bool; tmp19 = Formatter_Flags_Contains_I_I__Z(flags, 4); if !tmp19 { tmp19 = nzeros_2 > 0 }; tmp18 = tmp19 }
//line :1062:1
				tmp17 = tmp18; if tmp17 {

					NN(mant_2).Append_C__StringBuilder(46) }
				t.TrailingZeros_StringBuilder_I__V(mant_2, nzeros_2)
				t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, Up_StringBuilder_CharSequence(mant_2), 0, flags, t.AdjustWidth_I_I_Z__I(t.F_width, flags, neg), l) } else {
//line :1004:1
					if int32(c) == 103 {































































						var prec_3 int32 = precision
						if precision == -1 { prec_3 = 6 } else { if precision == 0 { prec_3 = 1 } }
						value = NN(value).Round_MathContext__BigDecimal(MathContext_New_I(prec_3))
						var tmp20 bool; var tmp21 bool; var tmp22 *BigDecimal = value; var tmp23 *BigDecimal; BigDecimal_Init(); tmp23 = BigDecimal_ZERO; tmp21 = NN(tmp22).Equals_O__Z(tmp23.Ref()); if !tmp21 {
							var tmp24 bool; tmp24 = !(NN(value).CompareTo_BigDecimal__I(BigDecimal_ValueOf_J_I__BigDecimal(1, 4)) == -1); if tmp24 {
								tmp24 = NN(value).CompareTo_BigDecimal__I(BigDecimal_ValueOf_J_I__BigDecimal(1, -prec_3)) == -1 }
//line :1072:1
							tmp21 = tmp24 }
//line :1071:1
						tmp20 = tmp21; if tmp20 {



							var e int32 = -NN(value).Scale__I() + (NN(NN(NN(value).UnscaledValue__BigInteger()).ToString__String()).Length__I() - 1)



							prec_3 = prec_3 - e - 1
							t.Print_Formatter_StringBuilder_BigDecimal_Locale_I_C_I_Z__V(fmt, sb, value, l, flags, 102, prec_3, neg) } else {
								t.Print_Formatter_StringBuilder_BigDecimal_Locale_I_C_I_Z__V(fmt, sb, value, l, flags, 101, prec_3-1, neg) } } else {
//line :1004:1
									if int32(c) == 97 {





















































































										if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New()))
										}
									}
								}
				}
		}
}




func Formatter_FormatSpecifier_BigDecimalLayout_New_Formatter_FormatSpecifier_BigInteger_I_Formatter_BigDecimalLayoutForm(p0 *Formatter_FormatSpecifier, p1 *BigInteger, p2 int32, p3 *Formatter_BigDecimalLayoutForm) *Formatter_FormatSpecifier_BigDecimalLayout { t := &Formatter_FormatSpecifier_BigDecimalLayout{}; t.Ctor_Formatter_FormatSpecifier_BigInteger_I_Formatter_BigDecimalLayoutForm(p0, p1, p2, p3); return t }
//line :1101:1
func (t *Formatter_FormatSpecifier_BigDecimalLayout) Ctor_Formatter_FormatSpecifier_BigInteger_I_Formatter_BigDecimalLayoutForm(this_0 *Formatter_FormatSpecifier, intVal *BigInteger, scale int32, form *Formatter_BigDecimalLayoutForm) { NN(this_0); t.F_this_0 = this_0; t.F_dot = false
	t.Layout_BigInteger_I_Formatter_BigDecimalLayoutForm__V(intVal, scale, form)
}
func (t *Formatter_FormatSpecifier_BigDecimalLayout) HasDot__Z() bool { return t.F_dot }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) Scale__I() int32 { return t.F_scale }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) Mantissa__StringBuilder() *StringBuilder { return t.F_mant }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) Exponent__StringBuilder() *StringBuilder { return t.F_exp }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) Layout_BigInteger_I_Formatter_BigDecimalLayoutForm__V(intVal *BigInteger, scale int32, form *Formatter_BigDecimalLayoutForm) {
	var coeff *String = NN(intVal).ToString__String()
	t.F_scale = scale
	var len_ int32 = NN(coeff).Length__I()
	t.F_mant = StringBuilder_New_I(len_ + 14)
	if scale == 0 {

		if len_ > 1 {

			var tmp1 *StringBuilder = t.F_mant; NN(tmp1).Append_C__StringBuilder(NN(coeff).CharAt_I__C(0))
			var tmp2 *Formatter_BigDecimalLayoutForm; Formatter_BigDecimalLayoutForm_Init(); tmp2 = Formatter_BigDecimalLayoutForm_SCIENTIFIC; if form == tmp2 {

				NN(t.F_mant).Append_C__StringBuilder(46)
				t.F_dot = true
				NN(t.F_mant).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(coeff), 1, len_)
				t.F_exp = StringBuilder_New_String(Lit_1135)
				if len_ < 10 {
					NN(NN(t.F_exp).Append_C__StringBuilder(48)).Append_I__StringBuilder(len_ - 1) } else {
						NN(t.F_exp).Append_I__StringBuilder(len_ - 1) } } else {
							NN(t.F_mant).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(coeff), 1, len_) } } else {

								NN(t.F_mant).Append_String__StringBuilder(coeff)
								var tmp3 *Formatter_BigDecimalLayoutForm; Formatter_BigDecimalLayoutForm_Init(); tmp3 = Formatter_BigDecimalLayoutForm_SCIENTIFIC; if form == tmp3 {
									t.F_exp = StringBuilder_New_String(Lit_2280) } } } else {
//line :1117:1
										var tmp4 *Formatter_BigDecimalLayoutForm; Formatter_BigDecimalLayoutForm_Init(); tmp4 = Formatter_BigDecimalLayoutForm_DECIMAL_FLOAT; if form == tmp4 {



















											if scale >= len_ {


												NN(t.F_mant).Append_String__StringBuilder(Lit_1237)
												t.F_dot = true
												NN(t.F_this_0).TrailingZeros_StringBuilder_I__V(t.F_mant, scale-len_)
												NN(t.F_mant).Append_String__StringBuilder(coeff) } else {
//line :1137:1
													if scale > 0 {







														var pad int32 = len_ - scale
														NN(t.F_mant).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(coeff), 0, pad)
														NN(t.F_mant).Append_C__StringBuilder(46)
														t.F_dot = true
														NN(t.F_mant).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(coeff), pad, len_) } else {


															NN(t.F_mant).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(coeff), 0, len_)
															if NN(intVal).Signum__I() == 0 { } else {
																NN(t.F_this_0).TrailingZeros_StringBuilder_I__V(t.F_mant, -scale) }
															t.F_scale = 0 } } } else {


																var tmp5 *StringBuilder = t.F_mant; NN(tmp5).Append_C__StringBuilder(NN(coeff).CharAt_I__C(0))
																if len_ > 1 { NN(t.F_mant).Append_C__StringBuilder(46); t.F_dot = true; NN(t.F_mant).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(coeff), 1, len_) }
																t.F_exp = StringBuilder_New()
																var adjusted int64 = -int64(scale) + int64(len_-1)

																if !(adjusted == 0) {
																	var abs int64 = Math_Abs_J__J(adjusted); var tmp6 *StringBuilder = t.F_exp; var tmp7 uint16
																	if adjusted < 0 { tmp7 = 45 } else { tmp7 = 43 }; NN(tmp6).Append_C__StringBuilder(tmp7)
																	if abs < 10 { NN(t.F_exp).Append_C__StringBuilder(48) }
																	NN(t.F_exp).Append_J__StringBuilder(abs) } else {
																		NN(t.F_exp).Append_String__StringBuilder(Lit_2280)
																	} } } }
func (t *Formatter_FormatSpecifier) AdjustWidth_I_I_Z__I(width, flags int32, neg bool) int32 {
	var newW int32 = width; var tmp1 bool; var tmp2 bool; var tmp3 bool
	tmp3 = !(newW == -1); if tmp3 { tmp3 = neg }; tmp2 = tmp3; if tmp2 { tmp2 = Formatter_Flags_Contains_I_I__Z(flags, 128) }; tmp1 = tmp2; if tmp1 {
		newW = newW - 1 }
//line :1171:1
	return newW
}



func (t *Formatter_FormatSpecifier) TrailingZeros_StringBuilder_I__V(sb *StringBuilder, nzeros int32) {
	if nzeros > 0 { NN(sb).Repeat_I_I__StringBuilder(48, nzeros)
	} }
func (t *Formatter_FormatSpecifier) Print_Formatter_Calendar_C_Locale__V(fmt *Formatter, t_ Calendar_I, c uint16, l *Locale) {

	var sb *StringBuilder = StringBuilder_New()
	t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, c, l)
	if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) {
		var tmp1 Appendable = fmt.F_a; t.AppendJustified_Appendable_CharSequence__V(tmp1, Up_String_CharSequence(t.ToUpperCaseWithLocale_String_Locale__String(NN(sb).ToString__String(), l))) } else {
			t.AppendJustified_Appendable_CharSequence__V(fmt.F_a, Up_StringBuilder_CharSequence(sb))
		} }
func (t *Formatter_FormatSpecifier) Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt *Formatter, sb *StringBuilder, t_ Calendar_I, c uint16, l *Locale) Appendable {


	if sb == nil { sb = StringBuilder_New() }
	switch int32(c) { case 72, 73, 107, 108:

		var i int32 = t_.Get_I__I(11); var tmp1 bool; var tmp2 bool
		tmp2 = int32(c) == 73; if !tmp2 { tmp2 = int32(c) == 108 }; tmp1 = tmp2; if tmp1 {
			var tmp3 int32; var tmp4 bool; var tmp5 bool; tmp5 = i == 0; if !tmp5 { tmp5 = i == 12 }; tmp4 = tmp5; if tmp4 { tmp3 = 12 } else { tmp3 = i % 12 }; i = tmp3 }
		var flags int32; var tmp6 bool; var tmp7 bool; tmp7 = int32(c) == 72; if !tmp7 { tmp7 = int32(c) == 73 }; tmp6 = tmp7; if tmp6 { flags = 32 } else { flags = 0
		}

		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i), flags, 2, l))); case 77:

		var i_2 int32 = t_.Get_I__I(12)
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_2), 32, 2, l))); case 78:

		var i_3 int32 = t_.Get_I__I(14) * 1000000
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_3), 32, 9, l))); case 76:

		var i_4 int32 = t_.Get_I__I(14)
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_4), 32, 3, l))); case 81:

		var i_5 int64 = t_.GetTimeInMillis__J()
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, i_5, 0, t.F_width, l))); case 112:

		var ampm *RefArray = RefArrayOf(String_class, Lit_2686, Lit_2687); var tmp8 bool; var tmp9 bool
		tmp9 = !(l == nil); if tmp9 { var tmp10 *Locale; Locale_Init(); tmp10 = Locale_US; tmp9 = !(l == tmp10) }; tmp8 = tmp9; if tmp8 {
			var dfs *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(l); ampm = NN(dfs).GetAmPmStrings__String1() }
		var s *String = As[*String](ampm.A[t_.Get_I__I(9)]); var tmp11 *StringBuilder = sb; var tmp12 *Locale_Category
		Locale_Category_Init(); tmp12 = Locale_Category_FORMAT; NN(tmp11).Append_String__StringBuilder(NN(s).ToLowerCase_Locale__String(Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), Locale_GetDefault_Locale_Category__Locale(tmp12).Ref())))); case 115:






		var i_6 int64 = t_.GetTimeInMillis__J() / 1000
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, i_6, 0, t.F_width, l))); case 83:

		var i_7 int32 = t_.Get_I__I(13)
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_7), 32, 2, l))); case 122:

		var i_8 int32 = t_.Get_I__I(15) + t_.Get_I__I(16); var neg bool = i_8 < 0; var tmp13 *StringBuilder = sb; var tmp14 uint16


		if neg { tmp14 = 45 } else { tmp14 = 43 }; NN(tmp13).Append_C__StringBuilder(tmp14)
		if neg { i_8 = -i_8 }
		var min_ int32 = i_8 / 60000; var tmp15 int32 = min_ / 60 * 100; var offset int32 = tmp15 + min_%60



		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(offset), 32, 4, l))); case 90:

		var tz TimeZone_I = t_.GetTimeZone__TimeZone(); var tmp16 *StringBuilder = sb; var tmp17 bool = !(t_.Get_I__I(16) == 0); var tmp18 *Locale
		Locale_Init(); tmp18 = Locale_US; NN(tmp16).Append_String__StringBuilder(tz.GetDisplayName_Z_I_Locale__String(tmp17, 0, Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), tmp18.Ref())))); case 97, 65:





		var i_9 int32 = t_.Get_I__I(7); var lt *Locale; var tmp19 *Locale
		Locale_Init(); tmp19 = Locale_US; lt = Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), tmp19.Ref()))
//line :1248:1
		var dfs_2 *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(lt)


		if int32(c) == 65 {
			NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_2).GetWeekdays__String1().A[i_9])) } else {
				NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_2).GetShortWeekdays__String1().A[i_9])) }
//line :1249:1
	case 98, 104, 66:





		var i_10 int32 = t_.Get_I__I(2); var lt_2 *Locale; var tmp20 *Locale
		Locale_Init(); tmp20 = Locale_US; lt_2 = Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), tmp20.Ref()))
//line :1255:1
		var dfs_3 *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(lt_2)


		if int32(c) == 66 {
			NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_3).GetMonths__String1().A[i_10])) } else {
				NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_3).GetShortMonths__String1().A[i_10])) }
//line :1256:1
	case 67, 121, 89:





		var i_11 int32 = t_.Get_I__I(1)
		var size int32 = 2
		switch int32(c) { case 67:
			i_11 = i_11 / 100; case 121:
			i_11 = i_11 % 100; case 89:
			size = 4; default:}
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_11), 32, size, l))); case 100, 101:

		var i_12 int32 = t_.Get_I__I(5); var flags_2 int32
		if int32(c) == 100 { flags_2 = 32 } else { flags_2 = 0 }
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_12), flags_2, 2, l))); case 106:

		var i_13 int32 = t_.Get_I__I(6)
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_13), 32, 3, l))); case 109:

		var i_14 int32 = t_.Get_I__I(2) + 1
		NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_14), 32, 2, l))); case 84, 82:

		var sep uint16 = 58
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 72, l).Append_C__Appendable(sep)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 77, l)
		if int32(c) == 84 { NN(sb).Append_C__StringBuilder(sep); t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 83, l) }; case 114:

		var sep_2 uint16 = 58
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 73, l).Append_C__Appendable(sep_2)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 77, l).Append_C__Appendable(sep_2)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 83, l).Append_C__Appendable(32)
		var tsb *StringBuilder = StringBuilder_New()
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, tsb, t_, 112, l)
		NN(sb).Append_String__StringBuilder(t.ToUpperCaseWithLocale_String_Locale__String(NN(tsb).ToString__String(), l)); case 99:

		var sep_3 uint16 = 32
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 97, l).Append_C__Appendable(sep_3)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 98, l).Append_C__Appendable(sep_3)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 100, l).Append_C__Appendable(sep_3)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 84, l).Append_C__Appendable(sep_3)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 90, l).Append_C__Appendable(sep_3)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 89, l); case 68:

		var sep_4 uint16 = 47
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 109, l).Append_C__Appendable(sep_4)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 100, l).Append_C__Appendable(sep_4)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 121, l); case 70:

		var sep_5 uint16 = 45
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 89, l).Append_C__Appendable(sep_5)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 109, l).Append_C__Appendable(sep_5)
		t.Print_Formatter_StringBuilder_Calendar_C_Locale__Appendable(fmt, sb, t_, 100, l); default:
		if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New())) }}
//line :1187:1
	return Up_StringBuilder_Appendable(sb)
}




























































































































func (t *Formatter_FormatSpecifier) Print_Formatter_TemporalAccessor_C_Locale__V(fmt *Formatter, t_ TemporalAccessor, c uint16, l *Locale) {

	var sb *StringBuilder = StringBuilder_New()
	t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, c, l)
	if Formatter_Flags_Contains_I_I__Z(t.F_flags, 2) {
		var tmp1 Appendable = fmt.F_a; t.AppendJustified_Appendable_CharSequence__V(tmp1, Up_String_CharSequence(t.ToUpperCaseWithLocale_String_Locale__String(NN(sb).ToString__String(), l))) } else {
			t.AppendJustified_Appendable_CharSequence__V(fmt.F_a, Up_StringBuilder_CharSequence(sb))
		} }
func (t *Formatter_FormatSpecifier) Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt *Formatter, sb *StringBuilder, t_ TemporalAccessor, c uint16, l *Locale) Appendable {


	if sb == nil { sb = StringBuilder_New() }; tmp41 := func() (exc Throwable_I) { defer Catch(&exc)

		switch int32(c) { case 72:

			var i int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_HOUR_OF_DAY; i = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp1))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i), 32, 2, l))); case 107:

			var i_2 int32; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_HOUR_OF_DAY; i_2 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_2), 0, 2, l))); case 73:

			var i_3 int32; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_CLOCK_HOUR_OF_AMPM; i_3 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp3))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_3), 32, 2, l))); case 108:

			var i_4 int32; var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_CLOCK_HOUR_OF_AMPM; i_4 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp4))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_4), 0, 2, l))); case 77:

			var i_5 int32; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MINUTE_OF_HOUR; i_5 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_5), 32, 2, l))); case 78:

			var i_6 int32 = 0; tmp7 := func() (exc Throwable_I) { defer Catch(&exc)

				{ var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_NANO_OF_SECOND; i_6 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp6)) }; return nil }()
//line :1344:1
			if tmp7 != nil { if UnsupportedTemporalTypeException_InstanceOf(tmp7) { var u *UnsupportedTemporalTypeException = UnsupportedTemporalTypeException_Cast(tmp7); var tmp8 *ChronoField; _ = u


				ChronoField_Init(); tmp8 = ChronoField_MILLI_OF_SECOND; i_6 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp8)) * 1000000 } else {
//line :1344:1
					panic(tmp7)
				}
			}

			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_6), 32, 9, l))); case 76:

			var i_7 int32; var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_MILLI_OF_SECOND; i_7 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp9))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_7), 32, 3, l))); case 81:

			var i_8 int64; var tmp10 *ChronoField; ChronoField_Init(); tmp10 = ChronoField_INSTANT_SECONDS; var tmp11 int64 = t_.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp10)) * 1000; var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_MILLI_OF_SECOND; i_8 = tmp11 + t_.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp12))


			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, i_8, 0, t.F_width, l))); case 112:

			var ampm *RefArray = RefArrayOf(String_class, Lit_2686, Lit_2687); var tmp13 bool; var tmp14 bool
			tmp14 = !(l == nil); if tmp14 { var tmp15 *Locale; Locale_Init(); tmp15 = Locale_US; tmp14 = !(l == tmp15) }; tmp13 = tmp14; if tmp13 {
				var dfs *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(l); ampm = NN(dfs).GetAmPmStrings__String1() }
			var s *String; var tmp16 *RefArray = ampm; var tmp17 *ChronoField; ChronoField_Init(); tmp17 = ChronoField_AMPM_OF_DAY; s = As[*String](tmp16.A[t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp17))])
			var tmp18 *StringBuilder = sb; var tmp19 *Locale_Category; Locale_Category_Init(); tmp19 = Locale_Category_FORMAT; NN(tmp18).Append_String__StringBuilder(NN(s).ToLowerCase_Locale__String(Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), Locale_GetDefault_Locale_Category__Locale(tmp19).Ref())))); case 115:






			var i_9 int64; var tmp20 *ChronoField; ChronoField_Init(); tmp20 = ChronoField_INSTANT_SECONDS; i_9 = t_.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp20))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, i_9, 0, t.F_width, l))); case 83:

			var i_10 int32; var tmp21 *ChronoField; ChronoField_Init(); tmp21 = ChronoField_SECOND_OF_MINUTE; i_10 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp21))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_10), 32, 2, l))); case 122:

			var i_11 int32; var tmp22 *ChronoField; ChronoField_Init(); tmp22 = ChronoField_OFFSET_SECONDS; i_11 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp22)); var neg bool = i_11 < 0; var tmp23 *StringBuilder = sb; var tmp24 uint16

			if neg { tmp24 = 45 } else { tmp24 = 43 }; NN(tmp23).Append_C__StringBuilder(tmp24)
			if neg { i_11 = -i_11 }
			var min_ int32 = i_11 / 60; var tmp25 int32 = min_ / 60 * 100; var offset int32 = tmp25 + min_%60



			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(offset), 32, 4, l))); case 90:

			var zid ZoneId_I = ZoneId_Cast(t_.Query_TemporalQuery__O(TemporalQueries_Zone__TemporalQuery()))
			if zid == nil { panic(Thrown(IllegalFormatConversionException_New_C_Class(c, t_.GetClass__Class()))) }
			var tmp26 bool; var tmp27 bool; tmp27 = !ZoneOffset_InstanceOf(zid); if tmp27 {
				var tmp28 *ChronoField; ChronoField_Init(); tmp28 = ChronoField_INSTANT_SECONDS; tmp27 = t_.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp28)) }
//line :1387:1
			tmp26 = tmp27; if tmp26 {

				var instant *Instant = Instant_From_TemporalAccessor__Instant(t_); var tmp29 *StringBuilder = sb; var tmp30 TimeZone_I = TimeZone_GetTimeZone_String__TimeZone(zid.GetId__String()); var tmp31 bool = NN(zid.GetRules__ZoneRules()).IsDaylightSavings_Instant__Z(instant); var tmp32 *Locale
				Locale_Init(); tmp32 = Locale_US; NN(tmp29).Append_String__StringBuilder(tmp30.GetDisplayName_Z_I_Locale__String(tmp31, 0, Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), tmp32.Ref())))) } else {





					NN(sb).Append_String__StringBuilder(zid.GetId__String()) }
//line :1388:1
		case 97, 65:









			var i_12 int32; var tmp33 *ChronoField; ChronoField_Init(); tmp33 = ChronoField_DAY_OF_WEEK; i_12 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp33))%7 + 1; var lt *Locale; var tmp34 *Locale

			Locale_Init(); tmp34 = Locale_US; lt = Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), tmp34.Ref()))
//line :1398:1
			var dfs_2 *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(lt)



			if int32(c) == 65 {
				NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_2).GetWeekdays__String1().A[i_12])) } else {
					NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_2).GetShortWeekdays__String1().A[i_12])) }
//line :1400:1
		case 98, 104, 66:





			var i_13 int32; var tmp35 *ChronoField; ChronoField_Init(); tmp35 = ChronoField_MONTH_OF_YEAR; i_13 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp35)) - 1; var lt_2 *Locale; var tmp36 *Locale
			Locale_Init(); tmp36 = Locale_US; lt_2 = Locale_Cast(Objects_RequireNonNullElse_O_O__O(l.Ref(), tmp36.Ref()))
//line :1406:1
			var dfs_3 *DateFormatSymbols = DateFormatSymbols_GetInstance_Locale__DateFormatSymbols(lt_2)


			if int32(c) == 66 {
				NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_3).GetMonths__String1().A[i_13])) } else {
					NN(sb).Append_String__StringBuilder(As[*String](NN(dfs_3).GetShortMonths__String1().A[i_13])) }
//line :1407:1
		case 67, 121, 89:





			var i_14 int32; var tmp37 *ChronoField; ChronoField_Init(); tmp37 = ChronoField_YEAR_OF_ERA; i_14 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp37)); var size int32 = 2

			switch int32(c) { case 67:
				i_14 = i_14 / 100; case 121:
				i_14 = i_14 % 100; case 89:
				size = 4; default:}
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_14), 32, size, l))); case 100, 101:

			var i_15 int32; var tmp38 *ChronoField; ChronoField_Init(); tmp38 = ChronoField_DAY_OF_MONTH; i_15 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp38)); var flags int32
			if int32(c) == 100 { flags = 32 } else { flags = 0 }
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_15), flags, 2, l))); case 106:

			var i_16 int32; var tmp39 *ChronoField; ChronoField_Init(); tmp39 = ChronoField_DAY_OF_YEAR; i_16 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp39))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_16), 32, 3, l))); case 109:

			var i_17 int32; var tmp40 *ChronoField; ChronoField_Init(); tmp40 = ChronoField_MONTH_OF_YEAR; i_17 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp40))
			NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(i_17), 32, 2, l))); case 84, 82:

			var sep uint16 = 58
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 72, l).Append_C__Appendable(sep)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 77, l)
			if int32(c) == 84 { NN(sb).Append_C__StringBuilder(sep); t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 83, l) }; case 114:

			var sep_2 uint16 = 58
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 73, l).Append_C__Appendable(sep_2)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 77, l).Append_C__Appendable(sep_2)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 83, l).Append_C__Appendable(32)
			var tsb *StringBuilder = StringBuilder_New()
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, tsb, t_, 112, l)
			NN(sb).Append_String__StringBuilder(t.ToUpperCaseWithLocale_String_Locale__String(NN(tsb).ToString__String(), l)); case 99:

			var sep_3 uint16 = 32
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 97, l).Append_C__Appendable(sep_3)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 98, l).Append_C__Appendable(sep_3)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 100, l).Append_C__Appendable(sep_3)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 84, l).Append_C__Appendable(sep_3)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 90, l).Append_C__Appendable(sep_3)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 89, l); case 68:

			var sep_4 uint16 = 47
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 109, l).Append_C__Appendable(sep_4)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 100, l).Append_C__Appendable(sep_4)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 121, l); case 70:

			var sep_5 uint16 = 45; var yearField *ChronoField
			if IsoChronology_InstanceOf(t_.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery())) { ChronoField_Init(); yearField = ChronoField_YEAR } else { ChronoField_Init(); yearField = ChronoField_YEAR_OF_ERA
			}



			var year int32 = t_.Get_TemporalField__I(Up_ChronoField_TemporalField(yearField))
			if year < 0 {


				NN(sb).Append_C__StringBuilder(Formatter_GetMinusSign_Locale__C(l))
				year = -year } else {
//line :1464:1
					if year > 9999 {




						NN(sb).Append_C__StringBuilder(43) } }
			NN(NN(sb).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt, nil, int64(year), 32, 4, l)))).Append_C__StringBuilder(sep_5)

			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 109, l).Append_C__Appendable(sep_5)
			t.Print_Formatter_StringBuilder_TemporalAccessor_C_Locale__Appendable(fmt, sb, t_, 100, l); default:
			if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New())) }}; return nil }()
//line :1325:1
	if tmp41 != nil { if DateTimeException_InstanceOf(tmp41) { var x DateTimeException_I = DateTimeException_Cast(tmp41); _ = x





















































































































































		panic(Thrown(IllegalFormatConversionException_New_C_Class(c, t_.GetClass__Class()))) } else {
//line :1325:1
			panic(tmp41) } }
//line :1321:1
	return Up_StringBuilder_Appendable(sb)
}



























































































































































func (t *Formatter_FormatSpecifier) FailMismatch_I_C__V(f int32, c uint16) {
	var fs *String = Formatter_Flags_ToString_I__String(f); panic(Thrown(FormatFlagsConversionMismatchException_New_String_C(fs, c)))
}
func (t *Formatter_FormatSpecifier) FailConversion_C_O__V(c uint16, arg any) {
	panic(Thrown(IllegalFormatConversionException_New_C_Class(c, GetClass(arg))))
}
func (t *Formatter_FormatSpecifier) LocalizedMagnitude_Formatter_StringBuilder_J_I_I_Locale__StringBuilder(fmt *Formatter, sb *StringBuilder, value int64, flags, width int32, l *Locale) *StringBuilder {

	return t.LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt, sb, Up_String_CharSequence(Long_ToString_J_I__String(value, 10)), 0, flags, width, l)
}
func (t *Formatter_FormatSpecifier) LocalizedMagnitude_Formatter_StringBuilder_CharSequence_I_I_I_Locale__StringBuilder(fmt *Formatter, sb *StringBuilder, value CharSequence, offset, f, width int32, l *Locale) *StringBuilder {



	if sb == nil { sb = StringBuilder_New() }
	var begin int32 = NN(sb).Length__I(); var zero uint16 = Formatter_GetZero_Locale__C(l); var grpSep uint16 = 0; var grpSize int32 = -1; var decSep uint16 = 0; var len_ int32 = value.Length__I()
	var dot int32 = len_
	var j int32 = offset




L1: for {
	if j < len_ {
		if int32(value.CharAt_I__C(j)) == 46 { dot = j } else { j = j + 1; continue L1 } }
//line :1500:1
	break L1
}


	if dot < len_ { decSep = Formatter_GetDecimalSeparator_Locale__C(l) }
	if Formatter_Flags_Contains_I_I__Z(f, 64) {
		grpSep = Formatter_GetGroupingSeparator_Locale__C(l)
		var tmp1 bool; var tmp2 bool; tmp2 = l == nil; if !tmp2 { var tmp3 *Locale; Locale_Init(); tmp3 = Locale_US; tmp2 = NN(l).Equals_O__Z(tmp3.Ref()) }; tmp1 = tmp2; if tmp1 {
			grpSize = 3 } else {
				var df *DecimalFormat; var nf NumberFormat_I = NumberFormat_GetNumberInstance_Locale__NumberFormat(l)

				if DecimalFormat_InstanceOf(nf) {
					df = DecimalFormat_Cast(nf) } else {
						var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(NumberFormatProvider_class, l)


						if ResourceBundleBasedAdapter_InstanceOf(adapter) { } else {
							adapter = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter() }
						var all *RefArray = NN(adapter.GetLocaleResources_Locale__LocaleResources(l)).GetNumberPatterns__String1(); var tmp4 *String = As[*String](all.A[0])
						df = DecimalFormat_New_String_DecimalFormatSymbols(tmp4, Formatter_GetDecimalFormatSymbols_Locale__DecimalFormatSymbols(l))
					}
				grpSize = NN(df).GetGroupingSize__I()
				var tmp5 bool; var tmp6 bool; tmp6 = !NN(df).IsGroupingUsed__Z(); if !tmp6 { tmp6 = grpSize == 0 }; tmp5 = tmp6; if tmp5 { grpSep = 0 } } }
	var j_2 int32 = offset; L2: for {
		if j_2 < len_ {
			if j_2 == dot {
				NN(sb).Append_C__StringBuilder(decSep); grpSep = 0; j_2 = j_2 + 1; continue L2 } else {
					var c uint16 = value.CharAt_I__C(j_2)
					NN(sb).Append_C__StringBuilder(uint16(int32(c) - 48 + int32(zero)))


					var tmp7 bool; var tmp8 bool; var tmp9 bool
					tmp9 = !(int32(grpSep) == 0); if tmp9 { tmp9 = !(j_2 == dot-1) }; tmp8 = tmp9
//line :1531:1
					if tmp8 {

						tmp8 = (dot-j_2)%grpSize == 1 }
//line :1531:1
					tmp7 = tmp8; if tmp7 {


						NN(sb).Append_C__StringBuilder(grpSep); j_2 = j_2 + 1; continue L2 } else {
							j_2 = j_2 + 1; continue L2 } } }
//line :1523:1
		break L2
	}












	var tmp10 bool; var tmp11 bool; tmp11 = width > NN(sb).Length__I(); if tmp11 { tmp11 = Formatter_Flags_Contains_I_I__Z(f, 32) }; tmp10 = tmp11; if tmp10 {
		var zeros *String = NN(String_ValueOf_C__String(zero)).Repeat_I__String(width - NN(sb).Length__I())
		NN(sb).Insert_I_String__StringBuilder(begin, zeros) }
//line :1493:1
	return sb
}















































func (t *Formatter_FormatSpecifier) LocalizedMagnitudeExp_Formatter_StringBuilder_C1_I_Locale__V(fmt *Formatter, sb *StringBuilder, value *CharArray, offset int32, l *Locale) {

	var zero uint16 = Formatter_GetZero_Locale__C(l); var len_ int32 = int32(len(value.A))
	var j int32 = offset
L1: for {
	if j < len_ {
		var c uint16 = value.A[j]
		NN(sb).Append_C__StringBuilder(uint16(int32(c) - 48 + int32(zero)))
		j = j + 1; continue L1 }
//line :1546:1
	break L1
}
}
























func Formatter_Flags_Contains_I_I__Z(flags, f int32) bool {
	return flags&f == f
}
func Formatter_Flags_ContainsAny_I_I__Z(flags, f int32) bool {
	return !(flags&f == 0)
}
func Formatter_Flags_Add_I_I__I(flags, f int32) int32 {
	return flags | f
}
func Formatter_Flags_Remove_I_I__I(flags, f int32) int32 {
	return flags & ^f
}
func Formatter_Flags_Parse_String_I_I__I(s *String, start, end int32) int32 {
	var f int32 = 0; var i int32 = start
L1: for {
	if i < end {
		var c uint16 = NN(s).CharAt_I__C(i); var v int32 = Formatter_Flags_Parse_C__I(c)

		if Formatter_Flags_Contains_I_I__Z(f, v) {
			panic(Thrown(DuplicateFormatFlagsException_New_String(Formatter_Flags_ToString_I__String(v)))) }
		f = Formatter_Flags_Add_I_I__I(f, v)
		i = i + 1; continue L1 }
//line :1587:1
	break L1 }
//line :1586:1
	return f
}









func Formatter_Flags_Parse_C__I(c uint16) int32 {
	switch int32(c) { case 45: return 1; case 35: return 4; case 43: return 8; case 32: return 16; case 48: return 32; case 44: return 64; case 40: return 128; case 60: return 256; default:








		panic(Thrown(UnknownFormatFlagsException_New_String(String_ValueOf_C__String(c))))}; panic("a2g: unreachable")
}
func Formatter_Flags_IsFlag_C__Z(c uint16) bool {
	switch int32(c) { case 45, 35, 43, 32, 48, 44, 40, 60: return true; default: return false}; panic("a2g: unreachable")
}
func Formatter_Flags_ToString_I__String(f int32) *String {
	var sb *StringBuilder = StringBuilder_New()
	if Formatter_Flags_Contains_I_I__Z(f, 1) { NN(sb).Append_C__StringBuilder(45) }
	if Formatter_Flags_Contains_I_I__Z(f, 2) { NN(sb).Append_C__StringBuilder(94) }
	if Formatter_Flags_Contains_I_I__Z(f, 4) { NN(sb).Append_C__StringBuilder(35) }
	if Formatter_Flags_Contains_I_I__Z(f, 8) { NN(sb).Append_C__StringBuilder(43) }
	if Formatter_Flags_Contains_I_I__Z(f, 16) { NN(sb).Append_C__StringBuilder(32) }
	if Formatter_Flags_Contains_I_I__Z(f, 32) { NN(sb).Append_C__StringBuilder(48) }
	if Formatter_Flags_Contains_I_I__Z(f, 64) { NN(sb).Append_C__StringBuilder(44) }
	if Formatter_Flags_Contains_I_I__Z(f, 128) { NN(sb).Append_C__StringBuilder(40) }
	if Formatter_Flags_Contains_I_I__Z(f, 256) { NN(sb).Append_C__StringBuilder(60) }
	return NN(sb).ToString__String()
}















































func Formatter_Conversion_IsValid_C__Z(c uint16) bool {
	switch int32(c) { case 98, 66, 115, 83, 104, 72, 99, 67, 100, 111, 120, 88, 101, 69, 103, 71, 102, 97, 65, 110: return true; default:




















		return int32(c) == 37}; panic("a2g: unreachable")
}
func Formatter_Conversion_IsGeneral_C__Z(c uint16) bool {
	switch int32(c) { case 98, 66, 115, 83, 104, 72: return true; default: return false}; panic("a2g: unreachable")
}
func Formatter_Conversion_IsCharacter_C__Z(c uint16) bool {
	switch int32(c) { case 99, 67: return true; default: return false}; panic("a2g: unreachable")
}
func Formatter_Conversion_IsInteger_C__Z(c uint16) bool {
	switch int32(c) { case 100, 111, 120, 88: return true; default: return false}; panic("a2g: unreachable")
}


func Formatter_Conversion_IsFloat_C__Z(c uint16) bool {
	switch int32(c) { case 101, 69, 103, 71, 102, 97, 65: return true; default: return false}; panic("a2g: unreachable")
}








func Formatter_Conversion_IsText_C__Z(c uint16) bool {
	switch int32(c) { case 110, 37: return true; default: return false}; panic("a2g: unreachable")
}































































func Formatter_DateTime_IsValid_C__Z(c uint16) bool {
	switch int32(c) { case 72, 73, 107, 108, 77, 78, 76, 81, 112, 115, 83, 84, 122, 90: return true; case 97, 65, 98, 66, 67, 100, 101, 104, 106, 109, 121, 89: return true; case 114, 82, 99, 68, 70: return true; default: return false}; panic("a2g: unreachable")
}


type Formatter struct{ Object; F_a Appendable; F_l *Locale; F_lastException IOException_I }

func (t *Formatter) Is_Closeable() {}

func (t *Formatter) Is_Flushable() {}

func (t *Formatter) Is_AutoCloseable() {}

var Formatter_DFS *DecimalFormatSymbols

var Formatter_init ClassInit

func Formatter_Init() { if !Formatter_init.Done() { Formatter_init.Run(Formatter_clinit) } }

func Formatter_clinit() { Formatter_DFS = nil }

func (t *Formatter) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter) GetClass__Class() *Class { return Formatter_class }

func (t *Formatter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_InstanceOf(x any) bool { _, ok := x.(*Formatter); return ok }

func Formatter_Cast(x any) *Formatter { if x == nil { return nil }; v, ok := x.(*Formatter); if !ok { panic(ClassCast(x, Formatter_class)) }; return v }



type Formatter_BigDecimalLayoutForm struct{ Enum }

func (t *Formatter_BigDecimalLayoutForm) Is_Constable() {}

var Formatter_BigDecimalLayoutForm_SCIENTIFIC *Formatter_BigDecimalLayoutForm

var Formatter_BigDecimalLayoutForm_DECIMAL_FLOAT *Formatter_BigDecimalLayoutForm

var Formatter_BigDecimalLayoutForm__VALUES *RefArray

var Formatter_BigDecimalLayoutForm_init ClassInit

func Formatter_BigDecimalLayoutForm_Init() { if !Formatter_BigDecimalLayoutForm_init.Done() { Formatter_BigDecimalLayoutForm_init.Run(Formatter_BigDecimalLayoutForm_clinit) } }

func Formatter_BigDecimalLayoutForm_clinit() { Formatter_BigDecimalLayoutForm_SCIENTIFIC = Formatter_BigDecimalLayoutForm_New_String_I(Lit_2677, 0); Formatter_BigDecimalLayoutForm_DECIMAL_FLOAT = Formatter_BigDecimalLayoutForm_New_String_I(Lit_2678, 1); Formatter_BigDecimalLayoutForm__VALUES = Formatter_BigDecimalLayoutForm_X_values__Formatter_BigDecimalLayoutForm1() }

func Formatter_BigDecimalLayoutForm_New_String_I(p0 *String, p1 int32) *Formatter_BigDecimalLayoutForm { Formatter_BigDecimalLayoutForm_Init(); t := &Formatter_BigDecimalLayoutForm{}; t.Ctor_String_I(p0, p1); return t }

func (t *Formatter_BigDecimalLayoutForm) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Formatter_BigDecimalLayoutForm_Values__Formatter_BigDecimalLayoutForm1() *RefArray { Formatter_BigDecimalLayoutForm_Init(); return Formatter_BigDecimalLayoutForm__VALUES.Copy() }

func Formatter_BigDecimalLayoutForm_ValueOf_String__Formatter_BigDecimalLayoutForm(p0 *String) *Formatter_BigDecimalLayoutForm { Formatter_BigDecimalLayoutForm_Init(); return Formatter_BigDecimalLayoutForm_Cast(Enum_ValueOf_Class_String__Enum(Formatter_BigDecimalLayoutForm_class, p0)) }

func Formatter_BigDecimalLayoutForm_X_values__Formatter_BigDecimalLayoutForm1() *RefArray { Formatter_BigDecimalLayoutForm_Init(); return RefArrayOf(Formatter_BigDecimalLayoutForm_class, Formatter_BigDecimalLayoutForm_SCIENTIFIC, Formatter_BigDecimalLayoutForm_DECIMAL_FLOAT) }

func (t *Formatter_BigDecimalLayoutForm) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Formatter_BigDecimalLayoutForm) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Formatter_BigDecimalLayoutForm) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Formatter_BigDecimalLayoutForm) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.util.Formatter$BigDecimalLayoutForm.describeConstable()Ljava/util/Optional;")) }

func (t *Formatter_BigDecimalLayoutForm) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Formatter_BigDecimalLayoutForm) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Formatter_BigDecimalLayoutForm) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_BigDecimalLayoutForm) GetClass__Class() *Class { return Formatter_BigDecimalLayoutForm_class }

func (t *Formatter_BigDecimalLayoutForm) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_BigDecimalLayoutForm_InstanceOf(x any) bool { _, ok := x.(*Formatter_BigDecimalLayoutForm); return ok }

func Formatter_BigDecimalLayoutForm_Cast(x any) *Formatter_BigDecimalLayoutForm { if x == nil { return nil }; v, ok := x.(*Formatter_BigDecimalLayoutForm); if !ok { panic(ClassCast(x, Formatter_BigDecimalLayoutForm_class)) }; return v }



type Formatter_Conversion struct{ Object }

const Formatter_Conversion_DECIMAL_INTEGER uint16 = 100

const Formatter_Conversion_OCTAL_INTEGER uint16 = 111

const Formatter_Conversion_HEXADECIMAL_INTEGER uint16 = 120

const Formatter_Conversion_HEXADECIMAL_INTEGER_UPPER uint16 = 88

const Formatter_Conversion_SCIENTIFIC uint16 = 101

const Formatter_Conversion_SCIENTIFIC_UPPER uint16 = 69

const Formatter_Conversion_GENERAL uint16 = 103

const Formatter_Conversion_GENERAL_UPPER uint16 = 71

const Formatter_Conversion_DECIMAL_FLOAT uint16 = 102

const Formatter_Conversion_HEXADECIMAL_FLOAT uint16 = 97

const Formatter_Conversion_HEXADECIMAL_FLOAT_UPPER uint16 = 65

const Formatter_Conversion_CHARACTER uint16 = 99

const Formatter_Conversion_CHARACTER_UPPER uint16 = 67

const Formatter_Conversion_DATE_TIME uint16 = 116

const Formatter_Conversion_DATE_TIME_UPPER uint16 = 84

const Formatter_Conversion_BOOLEAN uint16 = 98

const Formatter_Conversion_BOOLEAN_UPPER uint16 = 66

const Formatter_Conversion_STRING uint16 = 115

const Formatter_Conversion_STRING_UPPER uint16 = 83

const Formatter_Conversion_HASHCODE uint16 = 104

const Formatter_Conversion_HASHCODE_UPPER uint16 = 72

const Formatter_Conversion_LINE_SEPARATOR uint16 = 110

const Formatter_Conversion_PERCENT_SIGN uint16 = 37

func Formatter_Conversion_New() *Formatter_Conversion { t := &Formatter_Conversion{}; t.Ctor(); return t }

func (t *Formatter_Conversion) Ctor() {}

func (t *Formatter_Conversion) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_Conversion) GetClass__Class() *Class { return Formatter_Conversion_class }

func (t *Formatter_Conversion) ToString__String() *String { return Object_toString(t) }

func (t *Formatter_Conversion) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter_Conversion) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_Conversion_InstanceOf(x any) bool { _, ok := x.(*Formatter_Conversion); return ok }

func Formatter_Conversion_Cast(x any) *Formatter_Conversion { if x == nil { return nil }; v, ok := x.(*Formatter_Conversion); if !ok { panic(ClassCast(x, Formatter_Conversion_class)) }; return v }



type Formatter_DateTime struct{ Object }

const Formatter_DateTime_HOUR_OF_DAY_0 uint16 = 72

const Formatter_DateTime_HOUR_0 uint16 = 73

const Formatter_DateTime_HOUR_OF_DAY uint16 = 107

const Formatter_DateTime_HOUR uint16 = 108

const Formatter_DateTime_MINUTE uint16 = 77

const Formatter_DateTime_NANOSECOND uint16 = 78

const Formatter_DateTime_MILLISECOND uint16 = 76

const Formatter_DateTime_MILLISECOND_SINCE_EPOCH uint16 = 81

const Formatter_DateTime_AM_PM uint16 = 112

const Formatter_DateTime_SECONDS_SINCE_EPOCH uint16 = 115

const Formatter_DateTime_SECOND uint16 = 83

const Formatter_DateTime_TIME uint16 = 84

const Formatter_DateTime_ZONE_NUMERIC uint16 = 122

const Formatter_DateTime_ZONE uint16 = 90

const Formatter_DateTime_NAME_OF_DAY_ABBREV uint16 = 97

const Formatter_DateTime_NAME_OF_DAY uint16 = 65

const Formatter_DateTime_NAME_OF_MONTH_ABBREV uint16 = 98

const Formatter_DateTime_NAME_OF_MONTH uint16 = 66

const Formatter_DateTime_CENTURY uint16 = 67

const Formatter_DateTime_DAY_OF_MONTH_0 uint16 = 100

const Formatter_DateTime_DAY_OF_MONTH uint16 = 101

const Formatter_DateTime_NAME_OF_MONTH_ABBREV_X uint16 = 104

const Formatter_DateTime_DAY_OF_YEAR uint16 = 106

const Formatter_DateTime_MONTH uint16 = 109

const Formatter_DateTime_YEAR_2 uint16 = 121

const Formatter_DateTime_YEAR_4 uint16 = 89

const Formatter_DateTime_TIME_12_HOUR uint16 = 114

const Formatter_DateTime_TIME_24_HOUR uint16 = 82

const Formatter_DateTime_DATE_TIME uint16 = 99

const Formatter_DateTime_DATE uint16 = 68

const Formatter_DateTime_ISO_STANDARD_DATE uint16 = 70

func Formatter_DateTime_New() *Formatter_DateTime { t := &Formatter_DateTime{}; t.Ctor(); return t }

func (t *Formatter_DateTime) Ctor() {}

func (t *Formatter_DateTime) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_DateTime) GetClass__Class() *Class { return Formatter_DateTime_class }

func (t *Formatter_DateTime) ToString__String() *String { return Object_toString(t) }

func (t *Formatter_DateTime) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter_DateTime) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_DateTime_InstanceOf(x any) bool { _, ok := x.(*Formatter_DateTime); return ok }

func Formatter_DateTime_Cast(x any) *Formatter_DateTime { if x == nil { return nil }; v, ok := x.(*Formatter_DateTime); if !ok { panic(ClassCast(x, Formatter_DateTime_class)) }; return v }



type Formatter_FixedString struct{ Record; F_s *String; F_start, F_end int32 }

func (t *Formatter_FixedString) Is_Formatter_FormatString() {}

func Formatter_FixedString_New_String_I_I(p0 *String, p1, p2 int32) *Formatter_FixedString { t := &Formatter_FixedString{}; t.Ctor_String_I_I(p0, p1, p2); return t }

func (t *Formatter_FixedString) Ctor_String_I_I(s *String, start, end int32) { t.Record.Ctor(t); t.F_s = s; t.F_start = start; t.F_end = end }

func (t *Formatter_FixedString) S__String() *String { return t.F_s }

func (t *Formatter_FixedString) Start__I() int32 { return t.F_start }

func (t *Formatter_FixedString) End__I() int32 { return t.F_end }

func (t *Formatter_FixedString) HashCode__I() int32 { return ((int32(0)*31+A2g_ObjHash(t.F_s.Ref()))*31+int32(t.F_start))*31 + int32(t.F_end) }

func (t *Formatter_FixedString) Equals_O__Z(p0 any) bool { if any(t) == p0 { return true }; if p0 == nil || GetClass(p0) != Formatter_FixedString_class { return false }; other := p0.(*Formatter_FixedString); return A2g_ObjEquals(t.F_s.Ref(), other.F_s.Ref()) && t.F_start == other.F_start && t.F_end == other.F_end }

func (t *Formatter_FixedString) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_FixedString) GetClass__Class() *Class { return Formatter_FixedString_class }

func (t *Formatter_FixedString) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter_FixedString) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_FixedString_InstanceOf(x any) bool { _, ok := x.(*Formatter_FixedString); return ok }

func Formatter_FixedString_Cast(x any) *Formatter_FixedString { if x == nil { return nil }; v, ok := x.(*Formatter_FixedString); if !ok { panic(ClassCast(x, Formatter_FixedString_class)) }; return v }



type Formatter_Flags struct{ Object }

const Formatter_Flags_NONE int32 = 0

const Formatter_Flags_LEFT_JUSTIFY int32 = 1

const Formatter_Flags_UPPERCASE int32 = 2

const Formatter_Flags_ALTERNATE int32 = 4

const Formatter_Flags_PLUS int32 = 8

const Formatter_Flags_LEADING_SPACE int32 = 16

const Formatter_Flags_ZERO_PAD int32 = 32

const Formatter_Flags_GROUP int32 = 64

const Formatter_Flags_PARENTHESES int32 = 128

const Formatter_Flags_PREVIOUS int32 = 256

func Formatter_Flags_New() *Formatter_Flags { t := &Formatter_Flags{}; t.Ctor(); return t }

func (t *Formatter_Flags) Ctor() {}

func (t *Formatter_Flags) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_Flags) GetClass__Class() *Class { return Formatter_Flags_class }

func (t *Formatter_Flags) ToString__String() *String { return Object_toString(t) }

func (t *Formatter_Flags) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter_Flags) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_Flags_InstanceOf(x any) bool { _, ok := x.(*Formatter_Flags); return ok }

func Formatter_Flags_Cast(x any) *Formatter_Flags { if x == nil { return nil }; v, ok := x.(*Formatter_Flags); if !ok { panic(ClassCast(x, Formatter_Flags_class)) }; return v }



type Formatter_FormatSpecifier struct{ Object; F_index, F_flags, F_width, F_precision int32; F_dt bool; F_c uint16 }

func (t *Formatter_FormatSpecifier) Is_Formatter_FormatString() {}

var Formatter_FormatSpecifier_SCALEUP float64

var Formatter_FormatSpecifier_init ClassInit

func Formatter_FormatSpecifier_Init() { if !Formatter_FormatSpecifier_init.Done() { Formatter_FormatSpecifier_init.Run(Formatter_FormatSpecifier_clinit) } }

func Formatter_FormatSpecifier_clinit() { Formatter_FormatSpecifier_SCALEUP = Math_Scalb_D_I__D(1.0, 54) }

func (t *Formatter_FormatSpecifier) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_FormatSpecifier) GetClass__Class() *Class { return Formatter_FormatSpecifier_class }

func (t *Formatter_FormatSpecifier) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter_FormatSpecifier) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_FormatSpecifier_InstanceOf(x any) bool { _, ok := x.(*Formatter_FormatSpecifier); return ok }

func Formatter_FormatSpecifier_Cast(x any) *Formatter_FormatSpecifier { if x == nil { return nil }; v, ok := x.(*Formatter_FormatSpecifier); if !ok { panic(ClassCast(x, Formatter_FormatSpecifier_class)) }; return v }



type Formatter_FormatSpecifier_BigDecimalLayout struct{ Object; F_mant, F_exp *StringBuilder; F_dot bool; F_scale int32; F_this_0 *Formatter_FormatSpecifier }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) GetClass__Class() *Class { return Formatter_FormatSpecifier_BigDecimalLayout_class }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) ToString__String() *String { return Object_toString(t) }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter_FormatSpecifier_BigDecimalLayout) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_FormatSpecifier_BigDecimalLayout_InstanceOf(x any) bool { _, ok := x.(*Formatter_FormatSpecifier_BigDecimalLayout); return ok }

func Formatter_FormatSpecifier_BigDecimalLayout_Cast(x any) *Formatter_FormatSpecifier_BigDecimalLayout { if x == nil { return nil }; v, ok := x.(*Formatter_FormatSpecifier_BigDecimalLayout); if !ok { panic(ClassCast(x, Formatter_FormatSpecifier_BigDecimalLayout_class)) }; return v }



type Formatter_FormatSpecifierParser struct{ Object; F_al *ArrayList; F_s *String; F_max int32; F_first uint16; F_start, F_off int32; F_c uint16; F_argSize, F_flagSize, F_widthSize int32 }

func (t *Formatter_FormatSpecifierParser) Ref() any { if t == nil { return nil }; return t }

func (t *Formatter_FormatSpecifierParser) GetClass__Class() *Class { return Formatter_FormatSpecifierParser_class }

func (t *Formatter_FormatSpecifierParser) ToString__String() *String { return Object_toString(t) }

func (t *Formatter_FormatSpecifierParser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Formatter_FormatSpecifierParser) CloneShallow() any { panic(CloneNotSupported(t)) }

func Formatter_FormatSpecifierParser_InstanceOf(x any) bool { _, ok := x.(*Formatter_FormatSpecifierParser); return ok }

func Formatter_FormatSpecifierParser_Cast(x any) *Formatter_FormatSpecifierParser { if x == nil { return nil }; v, ok := x.(*Formatter_FormatSpecifierParser); if !ok { panic(ClassCast(x, Formatter_FormatSpecifierParser_class)) }; return v }



type Formatter_FormatString interface{ Object_I; Is_Formatter_FormatString(); Index__I() int32; Print_Formatter_O_Locale__V(p0 *Formatter, p1 any, p2 *Locale) }

func Formatter_FormatString_InstanceOf(x any) bool { _, ok := x.(Formatter_FormatString); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Formatter_FormatString_class) } }; return ok }

func Formatter_FormatString_Cast(x any) Formatter_FormatString { if x == nil { return nil }; v, ok := x.(Formatter_FormatString); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Formatter_FormatString_class) } }; if !ok { panic(ClassCast(x, Formatter_FormatString_class)) }; return v }
