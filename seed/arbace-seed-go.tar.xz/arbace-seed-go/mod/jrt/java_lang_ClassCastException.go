//line java_lang_ClassCastException.ae:1
package jrt








func ClassCastException_New() *ClassCastException { t := &ClassCastException{}; t.Ctor(); return t }
//line :10:1
func (t *ClassCastException) Ctor() { t.RuntimeException.Ctor(t) }

func ClassCastException_New_String(p0 *String) *ClassCastException { t := &ClassCastException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *ClassCastException) Ctor_String(s *String) { t.RuntimeException.Ctor_String(t, s) }







type ClassCastException struct{ RuntimeException }

const ClassCastException_serialVersionUID int64 = -9223365651070458532

func (t *ClassCastException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ClassCastException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ClassCastException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ClassCastException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ClassCastException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ClassCastException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ClassCastException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ClassCastException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ClassCastException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ClassCastException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ClassCastException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ClassCastException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ClassCastException) Ref() any { if t == nil { return nil }; return t }

func (t *ClassCastException) GetClass__Class() *Class { return ClassCastException_class }

func (t *ClassCastException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ClassCastException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ClassCastException_InstanceOf(x any) bool { _, ok := x.(*ClassCastException); return ok }

func ClassCastException_Cast(x any) *ClassCastException { if x == nil { return nil }; v, ok := x.(*ClassCastException); if !ok { panic(ClassCast(x, ClassCastException_class)) }; return v }
