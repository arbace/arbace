//line java_text_NumberFormat.ae:1
package jrt

















func (t *NumberFormat) Ctor(this NumberFormat_I) { t.Format.Ctor(this); t.F_groupingUsed = true; t.F_maxIntegerDigits = 40; t.F_minIntegerDigits = 1; t.F_maxFractionDigits = 3; t.F_minFractionDigits = 0; t.F_parseIntegerOnly = false; t.F_maximumIntegerDigits = 40; t.F_minimumIntegerDigits = 1; t.F_maximumFractionDigits = 3; t.F_minimumFractionDigits = 0; t.F_serialVersionOnStream = 1 }

func (t *NumberFormat) Impl_Format_O_StringBuffer_FieldPosition__StringBuffer(this NumberFormat_I, number any, toAppendTo *StringBuffer, pos FieldPosition_I) *StringBuffer {
	var tmp1 any = number; if tmp1 == nil {








		panic(Thrown(IllegalArgumentException_New_String(Lit_1736))) }
//line :22:1
	if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)
		return this.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(l).LongValue__J(), toAppendTo, pos) }
//line :22:1
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)

		return this.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(i).LongValue__J(), toAppendTo, pos) }
//line :22:1
	if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)


		return this.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(s).LongValue__J(), toAppendTo, pos) }
//line :22:1
	if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)



		return this.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(b).LongValue__J(), toAppendTo, pos) }
//line :22:1
	if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)




		return this.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(ai).LongValue__J(), toAppendTo, pos) }
//line :22:1
	if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)





		return this.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(al).LongValue__J(), toAppendTo, pos) }
//line :22:1
	if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1); if NN(bi).BitLength__I() < 64 {






		return this.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(bi).LongValue__J(), toAppendTo, pos) } }
//line :22:1
	if Number_InstanceOf(tmp1) { var n Number_I = Number_Cast(tmp1)







		return this.Format_D_StringBuffer_FieldPosition__StringBuffer(n.DoubleValue__D(), toAppendTo, pos) }
	panic(Thrown(IllegalArgumentException_New_String(Lit_1736)))
}
func (t *NumberFormat) Impl_Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(this NumberFormat_I, number any, toAppendTo Format_StringBuf, pos FieldPosition_I) Format_StringBuf {
	var tmp1 any = number; if tmp1 == nil {








		panic(Thrown(IllegalArgumentException_New_String(Lit_1736))) }
//line :34:1
	if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)
		return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(l).LongValue__J(), toAppendTo, pos) }
//line :34:1
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)

		return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(i).LongValue__J(), toAppendTo, pos) }
//line :34:1
	if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)


		return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(s).LongValue__J(), toAppendTo, pos) }
//line :34:1
	if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)



		return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(b).LongValue__J(), toAppendTo, pos) }
//line :34:1
	if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)




		return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(ai).LongValue__J(), toAppendTo, pos) }
//line :34:1
	if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)





		return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(al).LongValue__J(), toAppendTo, pos) }
//line :34:1
	if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1); if NN(bi).BitLength__I() < 64 {






		return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(bi).LongValue__J(), toAppendTo, pos) } }
//line :34:1
	if Number_InstanceOf(tmp1) { var n Number_I = Number_Cast(tmp1)







		return this.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(n.DoubleValue__D(), toAppendTo, pos) }
	panic(Thrown(IllegalArgumentException_New_String(Lit_1736)))
}
func (t *NumberFormat) Impl_ParseObject_String_ParsePosition__O(this NumberFormat_I, source *String, pos *ParsePosition) any {
	return this.Parse_String_ParsePosition__Number(source, pos)
}
func (t *NumberFormat) Impl_Format_D__String(this NumberFormat_I, number float64) *String {
	var result *String = this.FastFormat_D__String(number)
	if !(result == nil) { return result } else { if Lit_1775.Equals_O__Z(NN(this.GetClass__Class()).GetPackageName__String().Ref()) {


		var tmp1 Format_StringBuf = StringBufFactory_Of__Format_StringBuf(); var tmp2 FieldPosition_I; DontCareFieldPosition_Init(); tmp2 = DontCareFieldPosition_INSTANCE; return this.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(number, tmp1, tmp2).ToString__String() } else {
			var tmp3 *StringBuffer = StringBuffer_New(); var tmp4 FieldPosition_I; DontCareFieldPosition_Init(); tmp4 = DontCareFieldPosition_INSTANCE; return NN(this.Format_D_StringBuffer_FieldPosition__StringBuffer(number, tmp3, tmp4)).ToString__String()
		} } }
func (t *NumberFormat) Impl_FastFormat_D__String(this NumberFormat_I, number float64) *String { return nil }

func (t *NumberFormat) Impl_Format_J__String(this NumberFormat_I, number int64) *String {
	if Lit_1775.Equals_O__Z(NN(this.GetClass__Class()).GetPackageName__String().Ref()) {
		var tmp1 Format_StringBuf = StringBufFactory_Of__Format_StringBuf(); var tmp2 FieldPosition_I; DontCareFieldPosition_Init(); tmp2 = DontCareFieldPosition_INSTANCE; return this.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(number, tmp1, tmp2).ToString__String() } else {
			var tmp3 *StringBuffer = StringBuffer_New(); var tmp4 FieldPosition_I; DontCareFieldPosition_Init(); tmp4 = DontCareFieldPosition_INSTANCE; return NN(this.Format_J_StringBuffer_FieldPosition__StringBuffer(number, tmp3, tmp4)).ToString__String()
		}
}


func (t *NumberFormat) Impl_Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(this NumberFormat_I, p0 float64, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf { panic(A2g_NotTranslated("java.text.NumberFormat.format(DLjava/text/Format$StringBuf;Ljava/text/FieldPosition;)Ljava/text/Format$StringBuf;")) }






func (t *NumberFormat) Impl_Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(this NumberFormat_I, p0 int64, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf { panic(A2g_NotTranslated("java.text.NumberFormat.format(JLjava/text/Format$StringBuf;Ljava/text/FieldPosition;)Ljava/text/Format$StringBuf;")) }





func (t *NumberFormat) Impl_Parse_String__Number(this NumberFormat_I, source *String) Number_I {
	var parsePosition *ParsePosition = ParsePosition_New_I(0); var result Number_I = this.Parse_String_ParsePosition__Number(source, parsePosition)

	if parsePosition.F_index == 0 {
		panic(Thrown(ParseException_New_String_I(Concat(Lit_1950, source, Lit_1142), parsePosition.F_errorIndex))) }
//line :80:1
	return result
}





func (t *NumberFormat) Impl_IsParseIntegerOnly__Z(this NumberFormat_I) bool { return t.F_parseIntegerOnly }

func (t *NumberFormat) Impl_SetParseIntegerOnly_Z__V(this NumberFormat_I, value bool) {
	t.F_parseIntegerOnly = value
}
func (t *NumberFormat) Impl_IsStrict__Z(this NumberFormat_I) bool {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_1951)))
}

func (t *NumberFormat) Impl_SetStrict_Z__V(this NumberFormat_I, strict bool) {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_1951)))
}

func NumberFormat_GetInstance__NumberFormat() NumberFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(Locale_GetDefault_Locale_Category__Locale(tmp1), nil, 0)
}
func NumberFormat_GetInstance_Locale__NumberFormat(inLocale *Locale) NumberFormat_I {
	return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(inLocale, nil, 0)
}
func NumberFormat_GetNumberInstance__NumberFormat() NumberFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(Locale_GetDefault_Locale_Category__Locale(tmp1), nil, 0)
}
func NumberFormat_GetNumberInstance_Locale__NumberFormat(inLocale *Locale) NumberFormat_I {
	return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(inLocale, nil, 0)
}
func NumberFormat_GetIntegerInstance__NumberFormat() NumberFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(Locale_GetDefault_Locale_Category__Locale(tmp1), nil, 4)
}
func NumberFormat_GetIntegerInstance_Locale__NumberFormat(inLocale *Locale) NumberFormat_I {
	return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(inLocale, nil, 4)
}
func NumberFormat_GetCurrencyInstance__NumberFormat() NumberFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(Locale_GetDefault_Locale_Category__Locale(tmp1), nil, 1)
}
func NumberFormat_GetCurrencyInstance_Locale__NumberFormat(inLocale *Locale) NumberFormat_I {
	return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(inLocale, nil, 1)
}
func NumberFormat_GetPercentInstance__NumberFormat() NumberFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(Locale_GetDefault_Locale_Category__Locale(tmp1), nil, 2)
}
func NumberFormat_GetPercentInstance_Locale__NumberFormat(inLocale *Locale) NumberFormat_I {
	return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(inLocale, nil, 2)
}
func NumberFormat_GetScientificInstance__NumberFormat() NumberFormat_I { panic(A2g_NotTranslated("java.text.NumberFormat.getScientificInstance()Ljava/text/NumberFormat;")) }


func NumberFormat_GetScientificInstance_Locale__NumberFormat(p0 *Locale) NumberFormat_I { panic(A2g_NotTranslated("java.text.NumberFormat.getScientificInstance(Ljava/util/Locale;)Ljava/text/NumberFormat;")) }


func NumberFormat_GetCompactNumberInstance__NumberFormat() NumberFormat_I {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; var tmp2 *Locale = Locale_GetDefault_Locale_Category__Locale(tmp1); var tmp3 *NumberFormat_Style; NumberFormat_Style_Init(); tmp3 = NumberFormat_Style_SHORT; return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(tmp2, tmp3, 5)
}
func NumberFormat_GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(locale *Locale, formatStyle *NumberFormat_Style) NumberFormat_I {

	Objects_RequireNonNull_O__O(locale.Ref())
	Objects_RequireNonNull_O__O(formatStyle.Ref())
	return NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(locale, formatStyle, 5)
}
func NumberFormat_MatchToStyle_NumberFormat_Locale__String(fmt NumberFormat_I, locale *Locale) *String {
	if fmt.Equals_O__Z(NumberFormat_GetInstance_Locale__NumberFormat(locale)) { return Lit_69 } else { if fmt.Equals_O__Z(NumberFormat_GetCurrencyInstance_Locale__NumberFormat(locale)) { return Lit_1913 } else { if fmt.Equals_O__Z(NumberFormat_GetPercentInstance_Locale__NumberFormat(locale)) { return Lit_1915 } else { if fmt.Equals_O__Z(NumberFormat_GetIntegerInstance_Locale__NumberFormat(locale)) { return Lit_1911 } else { var tmp1 *NumberFormat_Style; NumberFormat_Style_Init(); tmp1 = NumberFormat_Style_SHORT; if fmt.Equals_O__Z(NumberFormat_GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(locale, tmp1)) { return Lit_1917 } else { var tmp2 *NumberFormat_Style; NumberFormat_Style_Init(); tmp2 = NumberFormat_Style_LONG; if fmt.Equals_O__Z(NumberFormat_GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(locale, tmp2)) { return Lit_1919 } else { return nil
	}
	}
	}
	}
	}
	}
}
func NumberFormat_GetAvailableLocales__Locale1() *RefArray {
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(NumberFormatProvider_class)
	return NN(pool).GetAvailableLocales__Locale1()
}
func (t *NumberFormat) Impl_HashCode__I(this NumberFormat_I) int32 {
	return t.F_maximumIntegerDigits*37 + int32(t.F_maxFractionDigits)
}
func (t *NumberFormat) Impl_Equals_O__Z(this NumberFormat_I, obj any) bool {
	if any(this) == any(obj) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = obj == nil; if !tmp2 { tmp2 = !(this.GetClass__Class() == GetClass(obj)) }; tmp1 = tmp2
//line :162:1
		if tmp1 { return false } else {



			var other NumberFormat_I = NumberFormat_Cast(obj); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 int32 = t.F_maximumIntegerDigits
			tmp7 = tmp8 == other.Self_NumberFormat().F_maximumIntegerDigits; if tmp7 {
				var tmp9 int32 = t.F_minimumIntegerDigits; tmp7 = tmp9 == other.Self_NumberFormat().F_minimumIntegerDigits }
//line :167:1
			tmp6 = tmp7; if tmp6 {

				var tmp10 int32 = t.F_maximumFractionDigits; tmp6 = tmp10 == other.Self_NumberFormat().F_maximumFractionDigits }
//line :167:1
			tmp5 = tmp6; if tmp5 {


				var tmp11 int32 = t.F_minimumFractionDigits; tmp5 = tmp11 == other.Self_NumberFormat().F_minimumFractionDigits }
//line :167:1
			tmp4 = tmp5; if tmp4 {



				var tmp12 bool = t.F_groupingUsed; tmp4 = tmp12 == other.Self_NumberFormat().F_groupingUsed }
//line :167:1
			tmp3 = tmp4; if tmp3 {




				var tmp13 bool = t.F_parseIntegerOnly; tmp3 = tmp13 == other.Self_NumberFormat().F_parseIntegerOnly }
//line :167:1
			return tmp3
		}
	}
}



func (t *NumberFormat) Impl_Clone__O(this NumberFormat_I) any {
	var other NumberFormat_I = NumberFormat_Cast(t.Format.Impl_Clone__O(this)); return other
}
func (t *NumberFormat) Impl_IsGroupingUsed__Z(this NumberFormat_I) bool { return t.F_groupingUsed }

func (t *NumberFormat) Impl_SetGroupingUsed_Z__V(this NumberFormat_I, newValue bool) {
	t.F_groupingUsed = newValue
}
func (t *NumberFormat) Impl_GetMaximumIntegerDigits__I(this NumberFormat_I) int32 { return t.F_maximumIntegerDigits }


func (t *NumberFormat) Impl_SetMaximumIntegerDigits_I__V(this NumberFormat_I, newValue int32) {
	t.F_maximumIntegerDigits = Math_Max_I_I__I(0, newValue)
	if t.F_minimumIntegerDigits > t.F_maximumIntegerDigits {
		t.F_minimumIntegerDigits = t.F_maximumIntegerDigits
	} }
func (t *NumberFormat) Impl_GetMinimumIntegerDigits__I(this NumberFormat_I) int32 { return t.F_minimumIntegerDigits }


func (t *NumberFormat) Impl_SetMinimumIntegerDigits_I__V(this NumberFormat_I, newValue int32) {
	t.F_minimumIntegerDigits = Math_Max_I_I__I(0, newValue)
	if t.F_minimumIntegerDigits > t.F_maximumIntegerDigits {
		t.F_maximumIntegerDigits = t.F_minimumIntegerDigits
	} }
func (t *NumberFormat) Impl_GetMaximumFractionDigits__I(this NumberFormat_I) int32 { return t.F_maximumFractionDigits }


func (t *NumberFormat) Impl_SetMaximumFractionDigits_I__V(this NumberFormat_I, newValue int32) {
	t.F_maximumFractionDigits = Math_Max_I_I__I(0, newValue)
	if t.F_maximumFractionDigits < t.F_minimumFractionDigits {
		t.F_minimumFractionDigits = t.F_maximumFractionDigits
	} }
func (t *NumberFormat) Impl_GetMinimumFractionDigits__I(this NumberFormat_I) int32 { return t.F_minimumFractionDigits }


func (t *NumberFormat) Impl_SetMinimumFractionDigits_I__V(this NumberFormat_I, newValue int32) {
	t.F_minimumFractionDigits = Math_Max_I_I__I(0, newValue)
	if t.F_maximumFractionDigits < t.F_minimumFractionDigits {
		t.F_maximumFractionDigits = t.F_minimumFractionDigits
	} }
func (t *NumberFormat) Impl_GetCurrency__Currency(this NumberFormat_I) *Currency {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *NumberFormat) Impl_SetCurrency_Currency__V(this NumberFormat_I, currency *Currency) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *NumberFormat) Impl_GetRoundingMode__RoundingMode(this NumberFormat_I) *RoundingMode {
	panic(Thrown(UnsupportedOperationException_New()))
}
func (t *NumberFormat) Impl_SetRoundingMode_RoundingMode__V(this NumberFormat_I, roundingMode *RoundingMode) {
	panic(Thrown(UnsupportedOperationException_New()))
}
func NumberFormat_GetInstance_Locale_NumberFormat_Style_I__NumberFormat(desiredLocale *Locale, formatStyle *NumberFormat_Style, choice int32) NumberFormat_I {

	var adapter LocaleProviderAdapter_I
	adapter = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(NumberFormatProvider_class, desiredLocale)
	var numberFormat NumberFormat_I = NumberFormat_GetInstance_LocaleProviderAdapter_Locale_NumberFormat_Style_I__NumberFormat(adapter, desiredLocale, formatStyle, choice)




	if numberFormat == nil {
		numberFormat = NumberFormat_GetInstance_LocaleProviderAdapter_Locale_NumberFormat_Style_I__NumberFormat(LocaleProviderAdapter_ForJRE__LocaleProviderAdapter(), desiredLocale, formatStyle, choice) }
//line :230:1
	return numberFormat
}











func NumberFormat_GetInstance_LocaleProviderAdapter_Locale_NumberFormat_Style_I__NumberFormat(adapter LocaleProviderAdapter_I, locale *Locale, formatStyle *NumberFormat_Style, choice int32) NumberFormat_I {


	{ var provider NumberFormatProvider_I = adapter.GetNumberFormatProvider__NumberFormatProvider()
		switch choice { case 0:
			return provider.GetNumberInstance_Locale__NumberFormat(locale); case 2:
			return provider.GetPercentInstance_Locale__NumberFormat(locale); case 1:
			return provider.GetCurrencyInstance_Locale__NumberFormat(locale); case 4:
			return provider.GetIntegerInstance_Locale__NumberFormat(locale); case 5:
			return provider.GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(locale, formatStyle); default:
//line :247:1
			return nil
		}
	}


	panic("a2g: unreachable")
}
















































































func NumberFormat_Field_New_String(p0 *String) *NumberFormat_Field { NumberFormat_Field_Init(); t := &NumberFormat_Field{}; t.Ctor_String(p0); return t }
//line :334:1
func (t *NumberFormat_Field) Ctor_String(name *String) { t.Format_Field.Ctor_String(t, name)

	if t.GetClass__Class() == NumberFormat_Field_class { NumberFormat_Field_instanceMap.Put_O_O__O(name.Ref(), t)
	} }
func (t *NumberFormat_Field) ReadResolve__O() any { panic(A2g_NotTranslated("java.text.NumberFormat$Field.readResolve()Ljava/lang/Object;")) }



type NumberFormat struct{ Format; F_groupingUsed bool; F_maxIntegerDigits, F_minIntegerDigits, F_maxFractionDigits, F_minFractionDigits int8; F_parseIntegerOnly bool; F_maximumIntegerDigits, F_minimumIntegerDigits, F_maximumFractionDigits, F_minimumFractionDigits, F_serialVersionOnStream int32 }

type NumberFormat_I interface{ Format_I; Serializable; Cloneable; Self_NumberFormat() *NumberFormat; Format_O_StringBuffer_FieldPosition__StringBuffer(p0 any, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer; Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(p0 any, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf; ParseObject_String_ParsePosition__O(p0 *String, p1 *ParsePosition) any; Format_D__String(p0 float64) *String; FastFormat_D__String(p0 float64) *String; Format_J__String(p0 int64) *String; Format_D_StringBuffer_FieldPosition__StringBuffer(p0 float64, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer; Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(p0 float64, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf; Format_J_StringBuffer_FieldPosition__StringBuffer(p0 int64, p1 *StringBuffer, p2 FieldPosition_I) *StringBuffer; Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(p0 int64, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf; Parse_String_ParsePosition__Number(p0 *String, p1 *ParsePosition) Number_I; Parse_String__Number(p0 *String) Number_I; IsParseIntegerOnly__Z() bool; SetParseIntegerOnly_Z__V(p0 bool); IsStrict__Z() bool; SetStrict_Z__V(p0 bool); IsGroupingUsed__Z() bool; SetGroupingUsed_Z__V(p0 bool); GetMaximumIntegerDigits__I() int32; SetMaximumIntegerDigits_I__V(p0 int32); GetMinimumIntegerDigits__I() int32; SetMinimumIntegerDigits_I__V(p0 int32); GetMaximumFractionDigits__I() int32; SetMaximumFractionDigits_I__V(p0 int32); GetMinimumFractionDigits__I() int32; SetMinimumFractionDigits_I__V(p0 int32); GetCurrency__Currency() *Currency; SetCurrency_Currency__V(p0 *Currency); GetRoundingMode__RoundingMode() *RoundingMode; SetRoundingMode_RoundingMode__V(p0 *RoundingMode) }

func (t *NumberFormat) Self_NumberFormat() *NumberFormat { return t }

const NumberFormat_INTEGER_FIELD int32 = 0

const NumberFormat_FRACTION_FIELD int32 = 1

const NumberFormat_NUMBERSTYLE int32 = 0

const NumberFormat_CURRENCYSTYLE int32 = 1

const NumberFormat_PERCENTSTYLE int32 = 2

const NumberFormat_SCIENTIFICSTYLE int32 = 3

const NumberFormat_INTEGERSTYLE int32 = 4

const NumberFormat_COMPACTSTYLE int32 = 5

const NumberFormat_currentSerialVersion int32 = 1

const NumberFormat_serialVersionUID int64 = -2308460125733713944

func NumberFormat_InstanceOf(x any) bool { _, ok := x.(NumberFormat_I); return ok }

func NumberFormat_Cast(x any) NumberFormat_I { if x == nil { return nil }; v, ok := x.(NumberFormat_I); if !ok { panic(ClassCast(x, NumberFormat_class)) }; return v }



type NumberFormat_Field struct{ Format_Field }

const NumberFormat_Field_serialVersionUID int64 = 7494728892700160890

var NumberFormat_Field_instanceMap Map

var NumberFormat_Field_INTEGER *NumberFormat_Field

var NumberFormat_Field_FRACTION *NumberFormat_Field

var NumberFormat_Field_EXPONENT *NumberFormat_Field

var NumberFormat_Field_DECIMAL_SEPARATOR *NumberFormat_Field

var NumberFormat_Field_SIGN *NumberFormat_Field

var NumberFormat_Field_GROUPING_SEPARATOR *NumberFormat_Field

var NumberFormat_Field_EXPONENT_SYMBOL *NumberFormat_Field

var NumberFormat_Field_PERCENT *NumberFormat_Field

var NumberFormat_Field_PERMILLE *NumberFormat_Field

var NumberFormat_Field_CURRENCY *NumberFormat_Field

var NumberFormat_Field_EXPONENT_SIGN *NumberFormat_Field

var NumberFormat_Field_PREFIX *NumberFormat_Field

var NumberFormat_Field_SUFFIX *NumberFormat_Field

var NumberFormat_Field_init ClassInit

func NumberFormat_Field_Init() { if !NumberFormat_Field_init.Done() { NumberFormat_Field_init.Run(NumberFormat_Field_clinit) } }

func NumberFormat_Field_clinit() { Format_Field_Init(); NumberFormat_Field_instanceMap = HashMap_New_I(11); NumberFormat_Field_INTEGER = NumberFormat_Field_New_String(Lit_1911); NumberFormat_Field_FRACTION = NumberFormat_Field_New_String(Lit_1952); NumberFormat_Field_EXPONENT = NumberFormat_Field_New_String(Lit_1953); NumberFormat_Field_DECIMAL_SEPARATOR = NumberFormat_Field_New_String(Lit_1954); NumberFormat_Field_SIGN = NumberFormat_Field_New_String(Lit_1955); NumberFormat_Field_GROUPING_SEPARATOR = NumberFormat_Field_New_String(Lit_1956); NumberFormat_Field_EXPONENT_SYMBOL = NumberFormat_Field_New_String(Lit_1957); NumberFormat_Field_PERCENT = NumberFormat_Field_New_String(Lit_1915); NumberFormat_Field_PERMILLE = NumberFormat_Field_New_String(Lit_1958); NumberFormat_Field_CURRENCY = NumberFormat_Field_New_String(Lit_1913); NumberFormat_Field_EXPONENT_SIGN = NumberFormat_Field_New_String(Lit_1959); NumberFormat_Field_PREFIX = NumberFormat_Field_New_String(Lit_1960); NumberFormat_Field_SUFFIX = NumberFormat_Field_New_String(Lit_1961) }

func (t *NumberFormat_Field) GetName__String() *String { return t.Impl_GetName__String(t) }

func (t *NumberFormat_Field) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *NumberFormat_Field) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *NumberFormat_Field) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NumberFormat_Field) Ref() any { if t == nil { return nil }; return t }

func (t *NumberFormat_Field) GetClass__Class() *Class { return NumberFormat_Field_class }

func (t *NumberFormat_Field) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NumberFormat_Field) CloneShallow() any { panic(CloneNotSupported(t)) }

func NumberFormat_Field_InstanceOf(x any) bool { _, ok := x.(*NumberFormat_Field); return ok }

func NumberFormat_Field_Cast(x any) *NumberFormat_Field { if x == nil { return nil }; v, ok := x.(*NumberFormat_Field); if !ok { panic(ClassCast(x, NumberFormat_Field_class)) }; return v }



type NumberFormat_Style struct{ Enum }

func (t *NumberFormat_Style) Is_Constable() {}

var NumberFormat_Style_SHORT *NumberFormat_Style

var NumberFormat_Style_LONG *NumberFormat_Style

var NumberFormat_Style__VALUES *RefArray

var NumberFormat_Style_init ClassInit

func NumberFormat_Style_Init() { if !NumberFormat_Style_init.Done() { NumberFormat_Style_init.Run(NumberFormat_Style_clinit) } }

func NumberFormat_Style_clinit() { NumberFormat_Style_SHORT = NumberFormat_Style_New_String_I(Lit_1801, 0); NumberFormat_Style_LONG = NumberFormat_Style_New_String_I(Lit_1799, 1); NumberFormat_Style__VALUES = NumberFormat_Style_X_values__NumberFormat_Style1() }

func NumberFormat_Style_New_String_I(p0 *String, p1 int32) *NumberFormat_Style { NumberFormat_Style_Init(); t := &NumberFormat_Style{}; t.Ctor_String_I(p0, p1); return t }

func (t *NumberFormat_Style) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func NumberFormat_Style_Values__NumberFormat_Style1() *RefArray { NumberFormat_Style_Init(); return NumberFormat_Style__VALUES.Copy() }

func NumberFormat_Style_ValueOf_String__NumberFormat_Style(p0 *String) *NumberFormat_Style { NumberFormat_Style_Init(); return NumberFormat_Style_Cast(Enum_ValueOf_Class_String__Enum(NumberFormat_Style_class, p0)) }

func NumberFormat_Style_X_values__NumberFormat_Style1() *RefArray { NumberFormat_Style_Init(); return RefArrayOf(NumberFormat_Style_class, NumberFormat_Style_SHORT, NumberFormat_Style_LONG) }

func (t *NumberFormat_Style) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *NumberFormat_Style) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *NumberFormat_Style) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *NumberFormat_Style) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.text.NumberFormat$Style.describeConstable()Ljava/util/Optional;")) }

func (t *NumberFormat_Style) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *NumberFormat_Style) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NumberFormat_Style) Ref() any { if t == nil { return nil }; return t }

func (t *NumberFormat_Style) GetClass__Class() *Class { return NumberFormat_Style_class }

func (t *NumberFormat_Style) CloneShallow() any { panic(CloneNotSupported(t)) }

func NumberFormat_Style_InstanceOf(x any) bool { _, ok := x.(*NumberFormat_Style); return ok }

func NumberFormat_Style_Cast(x any) *NumberFormat_Style { if x == nil { return nil }; v, ok := x.(*NumberFormat_Style); if !ok { panic(ClassCast(x, NumberFormat_Style_class)) }; return v }
