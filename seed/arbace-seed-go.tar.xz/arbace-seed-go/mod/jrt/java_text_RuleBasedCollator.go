//line java_text_RuleBasedCollator.ae:1
package jrt






func RuleBasedCollator_New_String(p0 *String) *RuleBasedCollator { RuleBasedCollator_Init(); t := &RuleBasedCollator{}; t.Ctor_String(p0); return t }
//line :8:1
func (t *RuleBasedCollator) Ctor_String(rules *String) { t.Ctor_String_I(rules, 1) }


func RuleBasedCollator_New_String_I(p0 *String, p1 int32) *RuleBasedCollator { RuleBasedCollator_Init(); t := &RuleBasedCollator{}; t.Ctor_String_I(p0, p1); return t }
//line :11:1
func (t *RuleBasedCollator) Ctor_String_I(rules *String, decomp int32) { t.Collator.Ctor(t); t.F_tables = nil; t.F_primResult = nil; t.F_secResult = nil; t.F_terResult = nil; t.F_sourceCursor = nil; t.F_targetCursor = nil
	t.SetStrength_I__V(2)
	t.SetDecomposition_I__V(decomp)
	t.F_tables = RBCollationTables_New_String_I(rules, decomp)
}
func RuleBasedCollator_New_RuleBasedCollator(p0 *RuleBasedCollator) *RuleBasedCollator { RuleBasedCollator_Init(); t := &RuleBasedCollator{}; t.Ctor_RuleBasedCollator(p0); return t }
//line :16:1
func (t *RuleBasedCollator) Ctor_RuleBasedCollator(that *RuleBasedCollator) { t.Collator.Ctor(t); t.F_tables = nil; t.F_primResult = nil; t.F_secResult = nil; t.F_terResult = nil; t.F_sourceCursor = nil; t.F_targetCursor = nil
	t.SetStrength_I__V(NN(that).GetStrength__I())
	t.SetDecomposition_I__V(NN(that).GetDecomposition__I())
	t.F_tables = that.F_tables
}
func (t *RuleBasedCollator) GetRules__String() *String { return NN(t.F_tables).GetRules__String() }

func (t *RuleBasedCollator) GetCollationElementIterator_String__CollationElementIterator(source *String) *CollationElementIterator {
	return CollationElementIterator_New_String_RuleBasedCollator(source, t)
}
func (t *RuleBasedCollator) GetCollationElementIterator_CharacterIterator__CollationElementIterator(source CharacterIterator) *CollationElementIterator {

	return CollationElementIterator_New_CharacterIterator_RuleBasedCollator(source, t)
}
func (t *RuleBasedCollator) Compare_String_String__I(source, target *String) int32 { MonitorEnter(t); defer MonitorExit(t)
	var tmp1 bool; var tmp2 bool; tmp2 = source == nil; if !tmp2 { tmp2 = target == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	if NN(source).Equals_O__Z(target.Ref()) { return 0 } else {

		var result int32 = 0
		if t.F_sourceCursor == nil {
			t.F_sourceCursor = t.GetCollationElementIterator_String__CollationElementIterator(source) } else {
				NN(t.F_sourceCursor).SetText_String__V(source) }
		if t.F_targetCursor == nil {
			t.F_targetCursor = t.GetCollationElementIterator_String__CollationElementIterator(target) } else {
				NN(t.F_targetCursor).SetText_String__V(target) }
		var sOrder int32 = 0; var tOrder int32 = 0; var initialCheckSecTer bool = t.GetStrength__I() >= 1; var checkSecTer bool = initialCheckSecTer; var checkTertiary bool = t.GetStrength__I() >= 2
		var gets bool = true
		var gett bool = true




	L1: for {
		if gets { sOrder = NN(t.F_sourceCursor).Next__I() } else { gets = true }
		if gett { tOrder = NN(t.F_targetCursor).Next__I() } else { gett = true }
		var tmp3 bool; var tmp4 bool; tmp4 = sOrder == -1; if !tmp4 {
			tmp4 = tOrder == -1 }
//line :51:1
		tmp3 = tmp4; if tmp3 {

			break L1 }
		var pSOrder int32 = CollationElementIterator_PrimaryOrder_I__I(sOrder); var pTOrder int32 = CollationElementIterator_PrimaryOrder_I__I(tOrder)

		if sOrder == tOrder {

			var tmp5 bool; var tmp6 bool; tmp6 = NN(t.F_tables).IsFrenchSec__Z(); if tmp6 { tmp6 = !(pSOrder == 0) }; tmp5 = tmp6; if tmp5 {
				if checkSecTer { } else {
					checkSecTer = initialCheckSecTer
					checkTertiary = false } } } else {
//line :56:1
						if !(pSOrder == pTOrder) {






							if sOrder == 0 {
								gett = false } else {
//line :63:1
									if tOrder == 0 {

										gets = false } else {
//line :63:1
											if pSOrder == 0 {




												if checkSecTer { result = 1; checkSecTer = false }
												gett = false } else {
//line :63:1
													if pTOrder == 0 {








														if checkSecTer { result = -1; checkSecTer = false }
														gets = false } else {
//line :63:1
															if pSOrder < pTOrder {










																return -1 } else {
																	return 1 } } } } } } else {
//line :56:1
																		if checkSecTer {




















																			var secSOrder int16 = CollationElementIterator_SecondaryOrder_I__S(sOrder); var secTOrder int16 = CollationElementIterator_SecondaryOrder_I__S(tOrder)

																			if !(int32(secSOrder) == int32(secTOrder)) {


																				var tmp7 int32
																				if int32(secSOrder) < int32(secTOrder) { tmp7 = -1 } else { tmp7 = 1 }
//line :82:1
																				result = tmp7

																				checkSecTer = false } else {
//line :79:1
																					if checkTertiary {






																						var terSOrder int16 = CollationElementIterator_TertiaryOrder_I__S(sOrder); var terTOrder int16 = CollationElementIterator_TertiaryOrder_I__S(tOrder)

																						if int32(terSOrder) == int32(terTOrder) { } else {
																							var tmp8 int32
																							if int32(terSOrder) < int32(terTOrder) { tmp8 = -1 } else { tmp8 = 1 }
//line :89:1
																							result = tmp8

																							checkTertiary = false } } } } } }
//line :48:1
		continue L1
	}










































		if !(sOrder == -1) {
		L2: for {
			if !(CollationElementIterator_PrimaryOrder_I__I(sOrder) == 0) {
				return 1 } else {
					if int32(CollationElementIterator_SecondaryOrder_I__S(sOrder)) == 0 { } else {
						if checkSecTer { result = 1; checkSecTer = false } } }
			var tmp9 int32; sOrder = NN(t.F_sourceCursor).Next__I(); tmp9 = sOrder; if tmp9 == -1 { } else {

				continue L2 }
//line :93:1
			break L2
		}




		} else {

			if tOrder == -1 { } else {
			L3: for {
				if !(CollationElementIterator_PrimaryOrder_I__I(tOrder) == 0) {
					return -1 } else {
						if int32(CollationElementIterator_SecondaryOrder_I__S(tOrder)) == 0 { } else {
							if checkSecTer { result = -1; checkSecTer = false } } }
				var tmp10 int32; tOrder = NN(t.F_targetCursor).Next__I(); tmp10 = tOrder; if tmp10 == -1 { } else {

					continue L3 }
//line :102:1
				break L3
			}
			}
		}




		var tmp11 bool; var tmp12 bool; tmp12 = result == 0; if tmp12 { tmp12 = t.GetStrength__I() == 3 }; tmp11 = tmp12; if tmp11 {
			var mode int32 = t.GetDecomposition__I(); var form *Normalizer_Form

			if mode == 1 {

				var tmp13 *Normalizer_Form; Normalizer_Form_Init(); tmp13 = Normalizer_Form_NFD; form = tmp13 } else {
//line :113:1
					if mode == 2 {


						var tmp14 *Normalizer_Form; Normalizer_Form_Init(); tmp14 = Normalizer_Form_NFKD; form = tmp14 } else {
							return NN(source).CompareTo_String__I(target) } }
			var sourceDecomposition *String = Normalizer_Normalize_CharSequence_Normalizer_Form__String(Up_String_CharSequence(source), form); var targetDecomposition *String = Normalizer_Normalize_CharSequence_Normalizer_Form__String(Up_String_CharSequence(target), form)

			return NN(sourceDecomposition).CompareTo_String__I(targetDecomposition) } else {
//line :110:1
				return result
			}
	}
}









func (t *RuleBasedCollator) GetCollationKey_String__CollationKey(source *String) CollationKey_I { MonitorEnter(t); defer MonitorExit(t)
	if !(source == nil) {
		if t.F_primResult == nil {

			t.F_primResult = StringBuilder_New()
			t.F_secResult = StringBuilder_New()
			t.F_terResult = StringBuilder_New() } else {
				NN(t.F_primResult).SetLength_I__V(0); NN(t.F_secResult).SetLength_I__V(0); NN(t.F_terResult).SetLength_I__V(0) }
		var order int32 = 0; var compareSec bool = t.GetStrength__I() >= 1; var compareTer bool = t.GetStrength__I() >= 2
		var secOrder int32 = -1
		var terOrder int32 = -1
		var preSecIgnore int32 = 0


		if t.F_sourceCursor == nil {
			t.F_sourceCursor = t.GetCollationElementIterator_String__CollationElementIterator(source) } else {
				NN(t.F_sourceCursor).SetText_String__V(source) }
	L1: for { var tmp1 int32; order = NN(t.F_sourceCursor).Next__I(); tmp1 = order; if !(tmp1 == -1) {
		secOrder = int32(CollationElementIterator_SecondaryOrder_I__S(order))
		terOrder = int32(CollationElementIterator_TertiaryOrder_I__S(order))
		if !CollationElementIterator_IsIgnorable_I__Z(order) {

			var tmp2 *StringBuilder = t.F_primResult; NN(tmp2).Append_C__StringBuilder(uint16(CollationElementIterator_PrimaryOrder_I__I(order) + 1))



			if compareSec {
				var tmp3 bool; var tmp4 bool; tmp4 = NN(t.F_tables).IsFrenchSec__Z(); if tmp4 { tmp4 = preSecIgnore < NN(t.F_secResult).Length__I() }; tmp3 = tmp4; if tmp3 {
					var tmp5 *StringBuilder = t.F_secResult; RBCollationTables_Reverse_StringBuilder_I_I__V(tmp5, preSecIgnore, NN(t.F_secResult).Length__I()) }
				NN(t.F_secResult).Append_C__StringBuilder(uint16(secOrder + 1))

				preSecIgnore = NN(t.F_secResult).Length__I() }
			if compareTer {
				NN(t.F_terResult).Append_C__StringBuilder(uint16(terOrder + 1)) } } else {


					var tmp6 bool; var tmp7 bool; tmp7 = compareSec; if tmp7 { tmp7 = !(secOrder == 0) }; tmp6 = tmp7; if tmp6 {
						var tmp8 *StringBuilder = t.F_secResult; NN(tmp8).Append_C__StringBuilder(uint16(secOrder + int32(NN(t.F_tables).GetMaxSecOrder__S()) + 1))
					}



					var tmp9 bool; var tmp10 bool; tmp10 = compareTer; if tmp10 { tmp10 = !(terOrder == 0) }; tmp9 = tmp10; if tmp9 {
						var tmp11 *StringBuilder = t.F_terResult; NN(tmp11).Append_C__StringBuilder(uint16(terOrder + int32(NN(t.F_tables).GetMaxTerOrder__S()) + 1)) } }
//line :140:1
		continue L1 }; break L1
	}





























		if NN(t.F_tables).IsFrenchSec__Z() {
			if preSecIgnore < NN(t.F_secResult).Length__I() {
				var tmp12 *StringBuilder = t.F_secResult; RBCollationTables_Reverse_StringBuilder_I_I__V(tmp12, preSecIgnore, NN(t.F_secResult).Length__I()) }
			var tmp13 *StringBuilder = t.F_secResult; RBCollationTables_Reverse_StringBuilder_I_I__V(tmp13, 0, NN(t.F_secResult).Length__I()) }
		NN(t.F_primResult).Append_C__StringBuilder(0)
		NN(t.F_secResult).Append_C__StringBuilder(0)
		NN(t.F_secResult).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.F_terResult))
		NN(t.F_primResult).Append_CharSequence__StringBuilder(Up_StringBuilder_CharSequence(t.F_secResult))
		if t.GetStrength__I() == 3 {
			NN(t.F_primResult).Append_C__StringBuilder(0)
			var mode int32 = t.GetDecomposition__I()
			if mode == 1 {

				var tmp14 *StringBuilder = t.F_primResult; var tmp15 *Normalizer_Form; Normalizer_Form_Init(); tmp15 = Normalizer_Form_NFD; NN(tmp14).Append_String__StringBuilder(Normalizer_Normalize_CharSequence_Normalizer_Form__String(Up_String_CharSequence(source), tmp15)) } else {
//line :182:1
					if mode == 2 {



						var tmp16 *StringBuilder = t.F_primResult; var tmp17 *Normalizer_Form; Normalizer_Form_Init(); tmp17 = Normalizer_Form_NFKD; NN(tmp16).Append_String__StringBuilder(Normalizer_Normalize_CharSequence_Normalizer_Form__String(Up_String_CharSequence(source), tmp17)) } else {
							NN(t.F_primResult).Append_String__StringBuilder(source) } } }
		return RuleBasedCollationKey_New_String_String(source, NN(t.F_primResult).ToString__String()) } else {
//line :124:1
			return nil
		}
}































































func (t *RuleBasedCollator) Clone__O() any {
	if t.GetClass__Class() == RuleBasedCollator_class {
		return RuleBasedCollator_New_RuleBasedCollator(t) } else {
			var result *RuleBasedCollator = RuleBasedCollator_Cast(t.Collator.Impl_Clone__O(t))
			result.F_primResult = nil
			result.F_secResult = nil
			result.F_terResult = nil
			result.F_sourceCursor = nil
			result.F_targetCursor = nil
//line :193:1
			return result.Ref()
		}
}





func (t *RuleBasedCollator) Equals_O__Z(obj any) bool {
	if !t.Collator.Impl_Equals_O__Z(t, obj) { return false } else {

		var other *RuleBasedCollator = RuleBasedCollator_Cast(obj); return NN(t.GetRules__String()).Equals_O__Z(NN(other).GetRules__String().Ref())
	} }
func (t *RuleBasedCollator) HashCode__I() int32 { return NN(t.GetRules__String()).HashCode__I() }

func (t *RuleBasedCollator) GetTables__RBCollationTables() *RBCollationTables { return t.F_tables }



type RuleBasedCollator struct{ Collator; F_tables *RBCollationTables; F_primResult, F_secResult, F_terResult *StringBuilder; F_sourceCursor, F_targetCursor *CollationElementIterator }

const RuleBasedCollator_CHARINDEX int32 = 1879048192

const RuleBasedCollator_EXPANDCHARINDEX int32 = 2113929216

const RuleBasedCollator_CONTRACTCHARINDEX int32 = 2130706432

const RuleBasedCollator_UNMAPPED int32 = -1

const RuleBasedCollator_COLLATIONKEYOFFSET int32 = 1

var RuleBasedCollator_init ClassInit

func RuleBasedCollator_Init() { if !RuleBasedCollator_init.Done() { RuleBasedCollator_init.Run(RuleBasedCollator_clinit) } }

func RuleBasedCollator_clinit() { Collator_Init() }

func (t *RuleBasedCollator) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *RuleBasedCollator) GetStrength__I() int32 { return t.Impl_GetStrength__I(t) }

func (t *RuleBasedCollator) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *RuleBasedCollator) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *RuleBasedCollator) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *RuleBasedCollator) GetDecomposition__I() int32 { return t.Impl_GetDecomposition__I(t) }

func (t *RuleBasedCollator) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *RuleBasedCollator) SetDecomposition_I__V(p0 int32) { t.Impl_SetDecomposition_I__V(t, p0) }

func (t *RuleBasedCollator) Reversed__Comparator() Comparator { return Comparator_Reversed__Comparator(t) }

func (t *RuleBasedCollator) Equals_String_String__Z(p0, p1 *String) bool { return t.Impl_Equals_String_String__Z(t, p0, p1) }

func (t *RuleBasedCollator) SetStrength_I__V(p0 int32) { t.Impl_SetStrength_I__V(t, p0) }

func (t *RuleBasedCollator) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *RuleBasedCollator) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *RuleBasedCollator) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *RuleBasedCollator) Compare_O_O__I(p0, p1 any) int32 { return t.Impl_Compare_O_O__I(t, p0, p1) }

func (t *RuleBasedCollator) Ref() any { if t == nil { return nil }; return t }

func (t *RuleBasedCollator) GetClass__Class() *Class { return RuleBasedCollator_class }

func (t *RuleBasedCollator) ToString__String() *String { return Object_toString(t) }

func (t *RuleBasedCollator) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func RuleBasedCollator_InstanceOf(x any) bool { _, ok := x.(*RuleBasedCollator); return ok }

func RuleBasedCollator_Cast(x any) *RuleBasedCollator { if x == nil { return nil }; v, ok := x.(*RuleBasedCollator); if !ok { panic(ClassCast(x, RuleBasedCollator_class)) }; return v }
