//line java_lang_LazyConstant.ae:1
package jrt

























func LazyConstant_Of_Supplier__LazyConstant(computingFunction Supplier) LazyConstant {
	Objects_RequireNonNull_O__O(computingFunction)
	var tmp1 Supplier = computingFunction; if LazyConstant_InstanceOf(tmp1) { var lc LazyConstant = LazyConstant_Cast(tmp1); return lc } else {

		return Up_LazyConstantImpl_LazyConstant(LazyConstantImpl_OfLazy_Supplier__LazyConstantImpl(computingFunction))
	}
}

type LazyConstant interface{ Object_I; Supplier; Is_LazyConstant(); OrElse_O__O(p0 any) any; Get__O() any; IsInitialized__Z() bool }

func LazyConstant_InstanceOf(x any) bool { _, ok := x.(LazyConstant); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(LazyConstant_class) } }; return ok }

func LazyConstant_Cast(x any) LazyConstant { if x == nil { return nil }; v, ok := x.(LazyConstant); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(LazyConstant_class) } }; if !ok { panic(ClassCast(x, LazyConstant_class)) }; return v }
