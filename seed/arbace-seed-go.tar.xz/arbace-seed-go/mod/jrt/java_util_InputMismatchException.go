//line java_util_InputMismatchException.ae:1
package jrt








func InputMismatchException_New() *InputMismatchException { t := &InputMismatchException{}; t.Ctor(); return t }
//line :10:1
func (t *InputMismatchException) Ctor() { t.NoSuchElementException.Ctor(t) }

func InputMismatchException_New_String(p0 *String) *InputMismatchException { t := &InputMismatchException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *InputMismatchException) Ctor_String(s *String) { t.NoSuchElementException.Ctor_String(t, s) }







type InputMismatchException struct{ NoSuchElementException }

const InputMismatchException_serialVersionUID int64 = 8811230760997066428

func (t *InputMismatchException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InputMismatchException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InputMismatchException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InputMismatchException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InputMismatchException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InputMismatchException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InputMismatchException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InputMismatchException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InputMismatchException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InputMismatchException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InputMismatchException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InputMismatchException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InputMismatchException) Ref() any { if t == nil { return nil }; return t }

func (t *InputMismatchException) GetClass__Class() *Class { return InputMismatchException_class }

func (t *InputMismatchException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InputMismatchException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InputMismatchException_InstanceOf(x any) bool { _, ok := x.(*InputMismatchException); return ok }

func InputMismatchException_Cast(x any) *InputMismatchException { if x == nil { return nil }; v, ok := x.(*InputMismatchException); if !ok { panic(ClassCast(x, InputMismatchException_class)) }; return v }
