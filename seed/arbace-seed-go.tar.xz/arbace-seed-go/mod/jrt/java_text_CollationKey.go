//line java_text_CollationKey.ae:1
package jrt








func (t *CollationKey) Impl_GetSourceString__String(this CollationKey_I) *String { return t.F_source }



func (t *CollationKey) Ctor_String(this CollationKey_I, source *String) {
	if source == nil { panic(Thrown(NullPointerException_New())) }
	t.F_source = source
}


type CollationKey struct{ Object; F_source *String }

type CollationKey_I interface{ Object_I; Comparable; Self_CollationKey() *CollationKey; CompareTo_CollationKey__I(p0 CollationKey_I) int32; GetSourceString__String() *String; ToByteArray__B1() *ByteArray; CompareTo_O__I(p0 any) int32 }

func (t *CollationKey) Self_CollationKey() *CollationKey { return t }

func (t *CollationKey) Is_Comparable() {}

func (t *CollationKey) Impl_CompareTo_O__I(this CollationKey_I, p0 any) int32 { return this.CompareTo_CollationKey__I(CollationKey_Cast(p0)) }

func CollationKey_InstanceOf(x any) bool { _, ok := x.(CollationKey_I); return ok }

func CollationKey_Cast(x any) CollationKey_I { if x == nil { return nil }; v, ok := x.(CollationKey_I); if !ok { panic(ClassCast(x, CollationKey_class)) }; return v }
