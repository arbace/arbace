//line java_util_BitSet.ae:1
package jrt









func BitSet_ValueOf_B1__BitSet(bytes *ByteArray) *BitSet { BitSet_Init()
	var n int32 = int32(len(bytes.A))
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = n > 0; if tmp2 { tmp2 = int32(bytes.A[n-1]) == 0 }; tmp1 = tmp2; if tmp1 {
	n = n - 1
//line :13:1
	continue L1 }; break L1
}
	var words *LongArray = NewLongArray((n + 7) / 8); var j int32 = 0
L2: for {
	if j < n {
		var w int32 = int32(uint32(j) >> 3); var tmp3 int64 = words.A[w]
		words.A[w] = tmp3 | int64(bytes.A[j])&255<<(8*(j&7)&63)


		j = j + 1; continue L2 }
//line :16:1
	break L2
}





	return BitSet_New_J1(words)
}
func (t *BitSet) ToByteArray__B1() *ByteArray {
	var n int32 = t.F_wordsInUse
	if n == 0 {
		return NewByteArray(0) } else {
			var len_ int32 = 8 * (n - 1); var x int64 = t.F_words.A[n-1]
		L1: for {
			if x == 0 { } else {
				len_ = len_ + 1
				x = int64(uint64(x) >> 8); continue L1 }
//line :30:1
			break L1
		}


			var bytes *ByteArray = NewByteArray(len_); var j int32 = 0
		L2: for {
			if j < len_ {
				bytes.A[j] = int8(int64(uint64(t.F_words.A[int32(uint32(j)>>3)]) >> (8 * (j & 7) & 63)))


				j = j + 1; continue L2 }
//line :35:1
			break L2 }
//line :34:1
			return bytes } }
//line :33:1
func BitSet_WordIndex_I__I(bitIndex int32) int32 { BitSet_Init()
	return bitIndex >> 6
}
func (t *BitSet) CheckInvariants__V() {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_wordsInUse == 0; if !tmp2 {
		tmp2 = !(t.F_words.A[t.F_wordsInUse-1] == 0) }
//line :37:1
	tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New()))
	}
	var tmp3 bool; var tmp4 bool; tmp4 = t.F_wordsInUse >= 0; if tmp4 { var tmp5 int32 = t.F_wordsInUse; tmp4 = tmp5 <= int32(len(t.F_words.A)) }; tmp3 = tmp4; if !A2g_AssertionsDisabled && !tmp3 { panic(Thrown(AssertionError_New())) }
	var tmp6 bool; var tmp7 bool; var tmp8 int32 = t.F_wordsInUse; tmp7 = tmp8 == int32(len(t.F_words.A)); if !tmp7 { tmp7 = t.F_words.A[t.F_wordsInUse] == 0 }; tmp6 = tmp7; if !A2g_AssertionsDisabled && !tmp6 { panic(Thrown(AssertionError_New()))
	} }
func (t *BitSet) RecalculateWordsInUse__V() {
	var i int32 = 0
	i = t.F_wordsInUse - 1
L1: for { if i >= 0 { if t.F_words.A[i] == 0 { } else { break L1 }; i = i - 1; continue L1 }; break L1 }
	t.F_wordsInUse = i + 1
}
func BitSet_New() *BitSet { BitSet_Init(); t := &BitSet{}; t.Ctor(); return t }
//line :48:1
func (t *BitSet) Ctor() { t.F_wordsInUse = 0; t.F_sizeIsSticky = false
	t.InitWords_I__V(64)
	t.F_sizeIsSticky = false
}
func BitSet_New_I(p0 int32) *BitSet { BitSet_Init(); t := &BitSet{}; t.Ctor_I(p0); return t }
//line :52:1
func (t *BitSet) Ctor_I(nbits int32) { t.F_wordsInUse = 0; t.F_sizeIsSticky = false
	if nbits < 0 { panic(Thrown(NegativeArraySizeException_New_String(Concat(Lit_2619, StrOfInt(nbits))))) }
	t.InitWords_I__V(nbits)
	t.F_sizeIsSticky = true
}
func (t *BitSet) InitWords_I__V(nbits int32) {
	t.F_words = NewLongArray(BitSet_WordIndex_I__I(nbits-1) + 1)
}

func BitSet_New_J1(p0 *LongArray) *BitSet { BitSet_Init(); t := &BitSet{}; t.Ctor_J1(p0); return t }
//line :61:1
func (t *BitSet) Ctor_J1(words *LongArray) { t.F_wordsInUse = 0; t.F_sizeIsSticky = false
	t.F_words = words
	t.F_wordsInUse = int32(len(words.A))
	t.CheckInvariants__V()
}
func BitSet_ValueOf_J1__BitSet(longs *LongArray) *BitSet { BitSet_Init()
	var n int32 = 0
	n = int32(len(longs.A))
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = n > 0; if tmp2 { tmp2 = longs.A[n-1] == 0 }; tmp1 = tmp2; if tmp1 {
	n = n - 1
//line :69:1
	continue L1 }; break L1
}
	return BitSet_New_J1(Arrays_CopyOf_J1_I__J1(longs, n))
}











func BitSet_ValueOf_ByteBuffer__BitSet(bb ByteBuffer_I) *BitSet { BitSet_Init()
	var tmp1 ByteBuffer_I = bb.Slice__ByteBuffer(); var tmp2 *ByteOrder; ByteOrder_Init(); tmp2 = ByteOrder_LITTLE_ENDIAN; bb = tmp1.Order_ByteOrder__ByteBuffer(tmp2)
	var n int32 = 0
	n = bb.Remaining__I()
L1: for { var tmp3 bool; var tmp4 bool; tmp4 = n > 0; if tmp4 { tmp4 = int32(bb.Get_I__B(n-1)) == 0 }; tmp3 = tmp4; if tmp3 {
	n = n - 1
//line :88:1
	continue L1 }; break L1
}
	var words *LongArray = NewLongArray((n + 7) / 8)
	bb.Limit_I__ByteBuffer(n)
	var i int32 = 0
L2: for { if bb.Remaining__I() >= 8 { words.A[i] = bb.GetLong__J(); i = i + 1; continue L2 }; break L2 }
	var remaining int32 = bb.Remaining__I(); var j int32 = 0; L3: for {

		if j < remaining {
			var tmp5 int64 = words.A[i]; words.A[i] = tmp5 | int64(bb.Get__B())&255<<(8*j&63)



			remaining, j = remaining, j+1; continue L3 }
//line :94:1
		break L3
	}






	return BitSet_New_J1(words)
}





















func (t *BitSet) ToLongArray__J1() *LongArray {
	return Arrays_CopyOf_J1_I__J1(t.F_words, t.F_wordsInUse)
}
func (t *BitSet) EnsureCapacity_I__V(wordsRequired int32) {
	if int32(len(t.F_words.A)) < wordsRequired {
		var request int32 = Math_Max_I_I__I(2*int32(len(t.F_words.A)), wordsRequired)
		t.F_words = Arrays_CopyOf_J1_I__J1(t.F_words, request)
		t.F_sizeIsSticky = false
	} }
func (t *BitSet) ExpandTo_I__V(wordIndex int32) {
	var wordsRequired int32 = wordIndex + 1
	if t.F_wordsInUse < wordsRequired {
		t.EnsureCapacity_I__V(wordsRequired)
		t.F_wordsInUse = wordsRequired
	} }
func BitSet_CheckRange_I_I__V(fromIndex, toIndex int32) { BitSet_Init()
	if fromIndex < 0 {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2620, StrOfInt(fromIndex))))) }
	if toIndex < 0 { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2621, StrOfInt(toIndex))))) }
	if fromIndex > toIndex {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2622, StrOfInt(fromIndex), Lit_2623, StrOfInt(toIndex)))))
	} }
func (t *BitSet) Flip_I__V(bitIndex int32) {
	if bitIndex < 0 { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2624, StrOfInt(bitIndex))))) }
	var wordIndex int32 = BitSet_WordIndex_I__I(bitIndex)
	t.ExpandTo_I__V(wordIndex)
	var tmp1 *LongArray = t.F_words; tmp1.A[wordIndex] = t.F_words.A[wordIndex] ^ 1<<(bitIndex&63)
	t.RecalculateWordsInUse__V()
	t.CheckInvariants__V()
}
func (t *BitSet) Flip_I_I__V(fromIndex, toIndex int32) {
	BitSet_CheckRange_I_I__V(fromIndex, toIndex)
	if fromIndex == toIndex { } else {
		var startWordIndex int32 = BitSet_WordIndex_I__I(fromIndex); var endWordIndex int32 = BitSet_WordIndex_I__I(toIndex - 1)

		t.ExpandTo_I__V(endWordIndex)
		var firstWordMask int64 = -1 << (fromIndex & 63); var lastWordMask int64 = int64(uint64(18446744073709551615) >> (-toIndex & 63))

		if startWordIndex == endWordIndex {
			var tmp1 *LongArray = t.F_words; tmp1.A[startWordIndex] = t.F_words.A[startWordIndex] ^ firstWordMask&lastWordMask } else {



				var tmp2 *LongArray = t.F_words; tmp2.A[startWordIndex] = t.F_words.A[startWordIndex] ^ firstWordMask
				var i int32 = startWordIndex + 1; L1: for {
					if i < endWordIndex {
						var tmp3 *LongArray = t.F_words; tmp3.A[i] = t.F_words.A[i] ^ -1
						i = i + 1; continue L1 }
//line :169:1
					break L1
				}


				var tmp4 *LongArray = t.F_words; tmp4.A[endWordIndex] = t.F_words.A[endWordIndex] ^ lastWordMask }
		t.RecalculateWordsInUse__V()
		t.CheckInvariants__V()
	} }
func (t *BitSet) Set_I__V(bitIndex int32) {
	if bitIndex < 0 { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2624, StrOfInt(bitIndex))))) }
	var wordIndex int32 = BitSet_WordIndex_I__I(bitIndex)
	t.ExpandTo_I__V(wordIndex)
	var tmp1 *LongArray = t.F_words; tmp1.A[wordIndex] = t.F_words.A[wordIndex] | 1<<(bitIndex&63)
	t.CheckInvariants__V()
}
func (t *BitSet) Set_I_Z__V(bitIndex int32, value bool) {
	if value { t.Set_I__V(bitIndex) } else { t.Clear_I__V(bitIndex)
	} }
func (t *BitSet) Set_I_I__V(fromIndex, toIndex int32) {
	BitSet_CheckRange_I_I__V(fromIndex, toIndex)
	if fromIndex == toIndex { } else {
		var startWordIndex int32 = BitSet_WordIndex_I__I(fromIndex); var endWordIndex int32 = BitSet_WordIndex_I__I(toIndex - 1)

		t.ExpandTo_I__V(endWordIndex)
		var firstWordMask int64 = -1 << (fromIndex & 63); var lastWordMask int64 = int64(uint64(18446744073709551615) >> (-toIndex & 63))

		if startWordIndex == endWordIndex {
			var tmp1 *LongArray = t.F_words; tmp1.A[startWordIndex] = t.F_words.A[startWordIndex] | firstWordMask&lastWordMask } else {



				var tmp2 *LongArray = t.F_words; tmp2.A[startWordIndex] = t.F_words.A[startWordIndex] | firstWordMask
				var i int32 = startWordIndex + 1; L1: for {
					if i < endWordIndex { t.F_words.A[i] = -1; i = i + 1; continue L1 }
//line :201:1
					break L1
				}
				var tmp3 *LongArray = t.F_words; tmp3.A[endWordIndex] = t.F_words.A[endWordIndex] | lastWordMask }
		t.CheckInvariants__V()
	} }
func (t *BitSet) Set_I_I_Z__V(fromIndex, toIndex int32, value bool) {
	if value { t.Set_I_I__V(fromIndex, toIndex) } else { t.Clear_I_I__V(fromIndex, toIndex)
	} }
func (t *BitSet) Clear_I__V(bitIndex int32) {
	if bitIndex < 0 { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2624, StrOfInt(bitIndex))))) }
	var wordIndex int32 = BitSet_WordIndex_I__I(bitIndex)
	if wordIndex >= t.F_wordsInUse { } else {
		var tmp1 *LongArray = t.F_words; tmp1.A[wordIndex] = t.F_words.A[wordIndex] & ^(1 << (bitIndex & 63))


		t.RecalculateWordsInUse__V()
		t.CheckInvariants__V()
	} }
func (t *BitSet) Clear_I_I__V(fromIndex, toIndex int32) {
	BitSet_CheckRange_I_I__V(fromIndex, toIndex)
	if fromIndex == toIndex { } else {
		var startWordIndex int32 = BitSet_WordIndex_I__I(fromIndex)
		if startWordIndex >= t.F_wordsInUse { } else {
			var endWordIndex int32 = BitSet_WordIndex_I__I(toIndex - 1)
			if endWordIndex >= t.F_wordsInUse {
				toIndex = t.Length__I()
				endWordIndex = t.F_wordsInUse - 1 }
			var firstWordMask int64 = -1 << (fromIndex & 63); var lastWordMask int64 = int64(uint64(18446744073709551615) >> (-toIndex & 63))

			if startWordIndex == endWordIndex {
				var tmp1 *LongArray = t.F_words; tmp1.A[startWordIndex] = t.F_words.A[startWordIndex] & ^(firstWordMask & lastWordMask) } else {




					var tmp2 *LongArray = t.F_words; tmp2.A[startWordIndex] = t.F_words.A[startWordIndex] & ^firstWordMask


					var i int32 = startWordIndex + 1; L1: for {
						if i < endWordIndex { t.F_words.A[i] = 0; i = i + 1; continue L1 }
//line :239:1
						break L1
					}
					var tmp3 *LongArray = t.F_words; tmp3.A[endWordIndex] = t.F_words.A[endWordIndex] & ^lastWordMask
				}

			t.RecalculateWordsInUse__V()
			t.CheckInvariants__V()
		} } }
func (t *BitSet) Clear__V() {
L1: for { if t.F_wordsInUse > 0 { var tmp1 *LongArray = t.F_words; var tmp2 int32; var tmp3 int32 = t.F_wordsInUse - 1; t.F_wordsInUse = tmp3; tmp2 = tmp3; tmp1.A[tmp2] = 0; continue L1 }; break L1
} }
func (t *BitSet) Get_I__Z(bitIndex int32) bool {
	if bitIndex < 0 { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2624, StrOfInt(bitIndex))))) }
	t.CheckInvariants__V()
	var wordIndex int32 = BitSet_WordIndex_I__I(bitIndex); var tmp1 bool
	tmp1 = wordIndex < t.F_wordsInUse; if tmp1 {
		tmp1 = !(t.F_words.A[wordIndex]&(1<<(bitIndex&63)) == 0) }
//line :254:1
	return tmp1
}

func (t *BitSet) Get_I_I__BitSet(fromIndex, toIndex int32) *BitSet {
	BitSet_CheckRange_I_I__V(fromIndex, toIndex)
	t.CheckInvariants__V()
	var len_ int32 = t.Length__I(); var tmp1 bool; var tmp2 bool
	tmp2 = len_ <= fromIndex; if !tmp2 { tmp2 = fromIndex == toIndex }; tmp1 = tmp2; if tmp1 {
		return BitSet_New_I(0) } else {

			if toIndex > len_ { toIndex = len_ }
			var result *BitSet = BitSet_New_I(toIndex - fromIndex); var targetWords int32 = BitSet_WordIndex_I__I(toIndex-fromIndex-1) + 1; var sourceIndex int32 = BitSet_WordIndex_I__I(fromIndex); var wordAligned bool = fromIndex&63 == 0
			var i int32 = 0








		L1: for { if i < targetWords-1 {
			var tmp3 *LongArray = result.F_words; var tmp4 int32 = i; var tmp5 int64

			if wordAligned {
				tmp5 = t.F_words.A[sourceIndex] } else {
					var tmp6 int64 = int64(uint64(t.F_words.A[sourceIndex]) >> (fromIndex & 63)); tmp5 = tmp6 | t.F_words.A[sourceIndex+1]<<(-fromIndex&63) }
//line :276:1
			tmp3.A[tmp4] = tmp5







			i = i + 1
			sourceIndex = sourceIndex + 1
//line :275:1
			continue L1 }; break L1
		}









			var lastWordMask int64 = int64(uint64(18446744073709551615) >> (-toIndex & 63)); var tmp7 *LongArray = result.F_words; var tmp8 int32 = targetWords - 1; var tmp9 int64


			if (toIndex-1)&63 < fromIndex&63 {

				var tmp10 int64 = int64(uint64(t.F_words.A[sourceIndex]) >> (fromIndex & 63)); tmp9 = tmp10 | t.F_words.A[sourceIndex+1]&lastWordMask<<(-fromIndex&63) } else {




					tmp9 = int64(uint64(t.F_words.A[sourceIndex]&lastWordMask) >> (fromIndex & 63)) }
//line :287:1
			tmp7.A[tmp8] = tmp9











			result.F_wordsInUse = targetWords
			NN(result).RecalculateWordsInUse__V()
			NN(result).CheckInvariants__V()
//line :286:1
			return result
		}
}















func (t *BitSet) NextSetBit_I__I(fromIndex int32) int32 {
	if fromIndex < 0 {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2620, StrOfInt(fromIndex))))) }
	t.CheckInvariants__V()
	{ var u int32 = BitSet_WordIndex_I__I(fromIndex)
		if u >= t.F_wordsInUse { return -1 } else {

			var word int64 = t.F_words.A[u] & (-1 << (fromIndex & 63))
		L1: for {
			if word == 0 { } else {
				return u*64 + Long_NumberOfTrailingZeros_J__I(word)
			}
			var tmp1 int32; u = u + 1; tmp1 = u; if tmp1 == t.F_wordsInUse { return -1 }
			word = t.F_words.A[u]
//line :312:1
			continue L1
		}
		}
	}

	panic("a2g: unreachable")
}
func (t *BitSet) NextClearBit_I__I(fromIndex int32) int32 {
	if fromIndex < 0 {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2620, StrOfInt(fromIndex))))) }
	t.CheckInvariants__V()
	{ var u int32 = BitSet_WordIndex_I__I(fromIndex)
		if u >= t.F_wordsInUse { return fromIndex } else {

			var word int64 = ^t.F_words.A[u] & (-1 << (fromIndex & 63))

		L1: for {
			if word == 0 { } else {
				return u*64 + Long_NumberOfTrailingZeros_J__I(word)
			}
			var tmp1 int32; u = u + 1; tmp1 = u; if tmp1 == t.F_wordsInUse {
				return t.F_wordsInUse * 64 }
			word = ^t.F_words.A[u]
//line :328:1
			continue L1
		}
		}
	}


	panic("a2g: unreachable")
}
func (t *BitSet) PreviousSetBit_I__I(fromIndex int32) int32 {
	if fromIndex < 0 {
		if fromIndex == -1 { return -1 }
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2625, StrOfInt(fromIndex))))) }
	t.CheckInvariants__V()
	{ var u int32 = BitSet_WordIndex_I__I(fromIndex)
		if u >= t.F_wordsInUse {
			return t.Length__I() - 1 } else {
				var word int64 = t.F_words.A[u] & int64(uint64(18446744073709551615)>>(-(fromIndex+1)&63))



			L1: for {
				if word == 0 { } else {
					return (u+1)*64 - 1 - Long_NumberOfLeadingZeros_J__I(word)
				}



				var tmp1 int32; var old_1 int32 = u; u = u - 1; tmp1 = old_1; if tmp1 == 0 { return -1 }
				word = t.F_words.A[u]
//line :348:1
				continue L1
			}
			}
	}




	panic("a2g: unreachable")
}
func (t *BitSet) PreviousClearBit_I__I(fromIndex int32) int32 {
	if fromIndex < 0 {
		if fromIndex == -1 { return -1 }
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2625, StrOfInt(fromIndex))))) }
	t.CheckInvariants__V()
	{ var u int32 = BitSet_WordIndex_I__I(fromIndex)
		if u >= t.F_wordsInUse { return fromIndex } else {

			var word int64 = ^t.F_words.A[u] & int64(uint64(18446744073709551615)>>(-(fromIndex+1)&63))



		L1: for {
			if word == 0 { } else {
				return (u+1)*64 - 1 - Long_NumberOfLeadingZeros_J__I(word)
			}



			var tmp1 int32; var old_2 int32 = u; u = u - 1; tmp1 = old_2; if tmp1 == 0 { return -1 }
			word = ^t.F_words.A[u]
//line :370:1
			continue L1
		}
		}
	}




	panic("a2g: unreachable")
}
func (t *BitSet) Length__I() int32 {
	if t.F_wordsInUse == 0 { return 0 } else {

		var tmp1 int32 = 64 * (t.F_wordsInUse - 1); return tmp1 + (64 - Long_NumberOfLeadingZeros_J__I(t.F_words.A[t.F_wordsInUse-1]))
	}
}



func (t *BitSet) IsEmpty__Z() bool { return t.F_wordsInUse == 0 }

func (t *BitSet) Intersects_BitSet__Z(set *BitSet) bool {
	var tmp1 int32 = t.F_wordsInUse; var i int32 = Math_Min_I_I__I(tmp1, set.F_wordsInUse) - 1; L1: for {
		if i >= 0 {
			var tmp2 int64 = t.F_words.A[i]; if !(tmp2&set.F_words.A[i] == 0) {
				return true } else {
					i = i - 1; continue L1 } }
//line :392:1
		break L1 }
//line :391:1
	return false
}







func (t *BitSet) Cardinality__I() int32 {
	var sum int32 = 0; var i int32 = 0
L1: for {
	if i < t.F_wordsInUse {
		sum = sum + Long_BitCount_J__I(t.F_words.A[i])
		i = i + 1; continue L1 }
//line :402:1
	break L1 }
//line :401:1
	return sum
}





func (t *BitSet) And_BitSet__V(set *BitSet) {
	if t == set { } else {
	L1: for { var tmp1 int32 = t.F_wordsInUse; if tmp1 > set.F_wordsInUse {
		var tmp2 *LongArray = t.F_words; var tmp3 int32; var tmp4 int32 = t.F_wordsInUse - 1; t.F_wordsInUse = tmp4; tmp3 = tmp4; tmp2.A[tmp3] = 0
//line :410:1
		continue L1 }; break L1
	}
		var i int32 = 0; L2: for {
			if i < t.F_wordsInUse {
				var tmp5 *LongArray = t.F_words; var tmp6 int64 = t.F_words.A[i]; tmp5.A[i] = tmp6 & set.F_words.A[i]
				i = i + 1; continue L2 }
//line :412:1
			break L2
		}


		t.RecalculateWordsInUse__V()
		t.CheckInvariants__V()
	} }
func (t *BitSet) Or_BitSet__V(set *BitSet) {
	if t == set { } else {
		var tmp1 int32 = t.F_wordsInUse; var wordsInCommon int32 = Math_Min_I_I__I(tmp1, set.F_wordsInUse); var tmp2 int32 = t.F_wordsInUse
		if tmp2 < set.F_wordsInUse {
			t.EnsureCapacity_I__V(set.F_wordsInUse)
			t.F_wordsInUse = set.F_wordsInUse }
		var i int32 = 0; L1: for {
			if i < wordsInCommon {
				var tmp3 *LongArray = t.F_words; var tmp4 int64 = t.F_words.A[i]; tmp3.A[i] = tmp4 | set.F_words.A[i]
				i = i + 1; continue L1 }
//line :425:1
			break L1
		}


		if wordsInCommon < set.F_wordsInUse {
			System_Arraycopy_O_I_O_I_I__V(set.F_words.Ref(), wordsInCommon, t.F_words.Ref(), wordsInCommon, t.F_wordsInUse-wordsInCommon)
		}



		t.CheckInvariants__V()
	} }
func (t *BitSet) Xor_BitSet__V(set *BitSet) {
	var tmp1 int32 = t.F_wordsInUse; var wordsInCommon int32 = Math_Min_I_I__I(tmp1, set.F_wordsInUse); var tmp2 int32 = t.F_wordsInUse
	if tmp2 < set.F_wordsInUse {
		t.EnsureCapacity_I__V(set.F_wordsInUse)
		t.F_wordsInUse = set.F_wordsInUse }
	var i int32 = 0; L1: for {
		if i < wordsInCommon {
			var tmp3 *LongArray = t.F_words; var tmp4 int64 = t.F_words.A[i]; tmp3.A[i] = tmp4 ^ set.F_words.A[i]
			i = i + 1; continue L1 }
//line :442:1
		break L1
	}


	if wordsInCommon < set.F_wordsInUse {
		var tmp5 any = set.F_words.Ref(); var tmp6 any = t.F_words.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp5, wordsInCommon, tmp6, wordsInCommon, set.F_wordsInUse-wordsInCommon)
	}



	t.RecalculateWordsInUse__V()
	t.CheckInvariants__V()
}
func (t *BitSet) AndNot_BitSet__V(set *BitSet) {
	var tmp1 int32 = t.F_wordsInUse; var i int32 = Math_Min_I_I__I(tmp1, set.F_wordsInUse) - 1; L1: for {
		if i >= 0 {
			var tmp2 *LongArray = t.F_words; var tmp3 int64 = t.F_words.A[i]; tmp2.A[i] = tmp3 & ^set.F_words.A[i]
			i = i - 1; continue L1 }
//line :456:1
		break L1
	}


	t.RecalculateWordsInUse__V()
	t.CheckInvariants__V()
}
func (t *BitSet) HashCode__I() int32 {
	var h int64 = 1234; var i int32 = t.F_wordsInUse

L1: for { var tmp1 int32; i = i - 1; tmp1 = i; if tmp1 >= 0 {
	h = h ^ t.F_words.A[i]*int64(i+1)
//line :466:1
	continue L1 }; break L1
}
	return int32(h>>32 ^ h)
}
func (t *BitSet) Size__I() int32 {
	return int32(len(t.F_words.A)) * 64
}
func (t *BitSet) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if BitSet_InstanceOf(tmp1) { var set *BitSet = BitSet_Cast(tmp1)

			t.CheckInvariants__V()
			NN(set).CheckInvariants__V()
			var tmp2 int32 = t.F_wordsInUse; if !(tmp2 == set.F_wordsInUse) { return false } else {

				var tmp3 *LongArray = t.F_words; return ArraysSupport_Mismatch_J1_I_J1_I_I__I(tmp3, 0, set.F_words, 0, t.F_wordsInUse) == -1 } } else {
//line :476:1
					return false
				}
	}
}





func (t *BitSet) Clone__O() any {
	if t.F_sizeIsSticky { } else { t.TrimToSize__V() }
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var result *BitSet = BitSet_Cast(A2g_ObjectClone(t))
			result.F_words = NN(t.F_words).Copy()
			NN(result).CheckInvariants__V()
//line :488:1
			tmp1 = result.Ref()
		}
		return nil }()
//line :487:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)




		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :487:1
			panic(tmp2) } }; return tmp1
}





func (t *BitSet) TrimToSize__V() {
	var tmp1 int32 = t.F_wordsInUse; if tmp1 == int32(len(t.F_words.A)) { } else {
		t.F_words = Arrays_CopyOf_J1_I__J1(t.F_words, t.F_wordsInUse)
		t.CheckInvariants__V()
	}
}















func (t *BitSet) ToString__String() *String {
	t.CheckInvariants__V()
	var numBits int32
	if t.F_wordsInUse > 128 {
		numBits = t.Cardinality__I() } else {
			numBits = t.F_wordsInUse * 64 }
//line :517:1
	var initialCapacity int32



	if numBits <= 357913939 {



		initialCapacity = 6*numBits + 2 } else {
//line :521:1
			initialCapacity = 2147483639 }
//line :517:1
	var b *StringBuilder = StringBuilder_New_I(initialCapacity)










	NN(b).Append_C__StringBuilder(123)
	var i int32 = t.NextSetBit_I__I(0)
	if i == -1 { } else {
		NN(b).Append_I__StringBuilder(i)
	L1: for {
		var tmp1 int32; i = i + 1; tmp1 = i; if tmp1 < 0 { break L1 }
		var tmp2 int32; i = t.NextSetBit_I__I(i); tmp2 = i; if tmp2 < 0 { break L1 }
		var endOfRun int32 = t.NextClearBit_I__I(i)
	L2: for {
		NN(NN(b).Append_String__StringBuilder(Lit_1178)).Append_I__StringBuilder(i)
		var tmp3 int32; i = i + 1; tmp3 = i; if tmp3 == endOfRun { } else { continue L2 }
//line :536:1
		break L2 }
//line :532:1
		continue L1
	}
	}




	NN(b).Append_C__StringBuilder(125)
	return NN(b).ToString__String()
}
func (t *BitSet) Stream__IntStream() IntStream {












































































































	return StreamSupport_IntStream_Spliterator_OfInt_Z__IntStream(BitSet_1BitSetSpliterator_New_BitSet_I_I_I_Z(t, 0, -1, 0, true), false) }
//line :554:1
func BitSet_1BitSetSpliterator_New_BitSet_I_I_I_Z(p0 *BitSet, p1, p2, p3 int32, p4 bool) *BitSet_1BitSetSpliterator { t := &BitSet_1BitSetSpliterator{}; t.Ctor_BitSet_I_I_I_Z(p0, p1, p2, p3, p4); return t }
//line :554:1
func (t *BitSet_1BitSetSpliterator) Ctor_BitSet_I_I_I_Z(this_0 *BitSet, origin, fence, est int32, root bool) { NN(this_0); t.F_this_0 = this_0
	t.F_index = origin
	t.F_fence = fence
	t.F_est = est
	t.F_root = root
}
func (t *BitSet_1BitSetSpliterator) GetFence__I() int32 {
	var hi int32 = 0; var tmp1 int32
	hi = t.F_fence; tmp1 = hi; if tmp1 < 0 {
		var tmp2 int32; var tmp3 int32; var tmp4 int32 = t.F_this_0.F_wordsInUse

		if tmp4 >= BitSet_WordIndex_I__I(2147483647) { tmp3 = 2147483647 } else {

			tmp3 = t.F_this_0.F_wordsInUse << 6 }
//line :564:1
		var tmp5 int32 = tmp3; t.F_fence = tmp5; tmp2 = tmp5
//line :563:1
		hi = tmp2




		t.F_est = NN(t.F_this_0).Cardinality__I()
		t.F_index = NN(t.F_this_0).NextSetBit_I__I(0) }
//line :561:1
	return hi
}









func (t *BitSet_1BitSetSpliterator) TryAdvance_IntConsumer__Z(action IntConsumer) bool {
	Objects_RequireNonNull_O__O(action)
	var hi int32 = t.GetFence__I(); var i int32 = t.F_index; var tmp1 bool; var tmp2 bool

	tmp2 = i < 0; if !tmp2 { tmp2 = i >= hi }; tmp1 = tmp2; if tmp1 {
		var tmp3 bool; var tmp4 bool; tmp4 = i == 2147483647; if tmp4 { tmp4 = hi == 2147483647 }; tmp3 = tmp4; if tmp3 {
			t.F_index = -1; action.Accept_I__V(2147483647); return true } else {
//line :577:1
				return false } } else {



					t.F_index = NN(t.F_this_0).NextSetBit_I_I__I(i+1, BitSet_WordIndex_I__I(hi-1))



					action.Accept_I__V(i)
//line :580:1
					return true
				}
}





func (t *BitSet_1BitSetSpliterator) ForEachRemaining_IntConsumer__V(action IntConsumer) {
	Objects_RequireNonNull_O__O(action)
	var hi int32 = t.GetFence__I(); var i int32 = t.F_index

	t.F_index = -1
	var tmp1 bool; var tmp2 bool; tmp2 = i >= 0; if tmp2 { tmp2 = i < hi }; tmp1 = tmp2; if tmp1 {
		action.Accept_I__V(i)
		i = i + 1
		var u int32 = BitSet_WordIndex_I__I(i); var v int32 = BitSet_WordIndex_I__I(hi - 1)

	L1: switch { default: L2: for { var tmp3 bool; var tmp4 bool
		tmp4 = u <= v; if tmp4 { tmp4 = i <= hi }; tmp3 = tmp4
//line :598:1
		if tmp3 {

			var word int64 = t.F_this_0.F_words.A[u] & (-1 << (i & 63))


		L3: for { if !(word == 0) {
			i = u<<6 + Long_NumberOfTrailingZeros_J__I(word)



			if i >= hi { break L1 }
			word = word & ^(1 << (i & 63))
			action.Accept_I__V(i)
//line :603:1
			continue L3 }; break L3
		}






			u = u + 1
			i = u << 6
//line :598:1
			continue L2 }; break L2
	}
	}
	}











	var tmp5 bool; var tmp6 bool; tmp6 = i == 2147483647; if tmp6 { tmp6 = hi == 2147483647 }; tmp5 = tmp6; if tmp5 {
		action.Accept_I__V(2147483647)
	} }
func (t *BitSet_1BitSetSpliterator) TrySplit__Spliterator_OfInt() Spliterator_OfInt {
	var hi int32 = t.GetFence__I(); var lo int32 = t.F_index

	if lo < 0 { return nil } else {
		var tmp1 int32; var tmp2 int32; var tmp3 bool; var tmp4 bool

		tmp4 = hi < 2147483647; if !tmp4 {
			tmp4 = !NN(t.F_this_0).Get_I__Z(2147483647) }
//line :622:1
		tmp3 = tmp4; if tmp3 {

			tmp2 = NN(t.F_this_0).PreviousSetBit_I__I(hi-1) + 1 } else {
//line :622:1
				tmp2 = 2147483647 }
//line :621:1
		var tmp5 int32 = tmp2; t.F_fence = tmp5; tmp1 = tmp5
//line :620:1
		hi = tmp1







		var mid int32 = int32(uint32(lo+hi) >> 1)
		if lo >= mid { return nil } else {
			t.F_index = NN(t.F_this_0).NextSetBit_I_I__I(mid, BitSet_WordIndex_I__I(hi-1))



			t.F_root = false
			var tmp6 int32; var tmp7 int32 = int32(uint32(t.F_est) >> 1)

			t.F_est = tmp7; tmp6 = tmp7
//line :635:1
			return BitSet_1BitSetSpliterator_New_BitSet_I_I_I_Z(t.F_this_0, lo, mid, tmp6, false)
		}
	}
}

func (t *BitSet_1BitSetSpliterator) EstimateSize__J() int64 { var tmp1 int32; t.GetFence__I(); tmp1 = t.F_est; return int64(tmp1) }

func (t *BitSet_1BitSetSpliterator) Characteristics__I() int32 {
	var tmp1 int32
	if t.F_root { tmp1 = 64 } else { tmp1 = 0 }
//line :643:1
	return tmp1 | 16 | 1 | 4
}




func (t *BitSet_1BitSetSpliterator) GetComparator__Comparator() Comparator { return nil }



func (t *BitSet) NextSetBit_I_I__I(fromIndex, toWordIndex int32) int32 {
	{ var u int32 = BitSet_WordIndex_I__I(fromIndex)
		if u > toWordIndex { return -1 } else {

			var word int64 = t.F_words.A[u] & (-1 << (fromIndex & 63))
		L1: for {
			if word == 0 { } else {
				return u*64 + Long_NumberOfTrailingZeros_J__I(word)
			}
			var tmp1 int32; u = u + 1; tmp1 = u; if tmp1 > toWordIndex { return -1 }
			word = t.F_words.A[u]
//line :658:1
			continue L1 } } }
//line :653:1
	panic("a2g: unreachable")
}




















type BitSet struct{ Object; F_words *LongArray; F_wordsInUse int32; F_sizeIsSticky bool }

func (t *BitSet) Is_Cloneable() {}

func (t *BitSet) Is_Serializable() {}

const BitSet_ADDRESS_BITS_PER_WORD int32 = 6

const BitSet_BITS_PER_WORD int32 = 64

const BitSet_BIT_INDEX_MASK int32 = 63

const BitSet_WORD_MASK int64 = -1

const BitSet_serialVersionUID int64 = 7997698588986878753

var BitSet_init ClassInit

func BitSet_Init() { if !BitSet_init.Done() { BitSet_init.Run(BitSet_clinit) } }

func BitSet_clinit() {}

func (t *BitSet) Ref() any { if t == nil { return nil }; return t }

func (t *BitSet) GetClass__Class() *Class { return BitSet_class }

func (t *BitSet) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func BitSet_InstanceOf(x any) bool { _, ok := x.(*BitSet); return ok }

func BitSet_Cast(x any) *BitSet { if x == nil { return nil }; v, ok := x.(*BitSet); if !ok { panic(ClassCast(x, BitSet_class)) }; return v }



type BitSet_1BitSetSpliterator struct{ Object; F_index, F_fence, F_est int32; F_root bool; F_this_0 *BitSet }

func (t *BitSet_1BitSetSpliterator) Is_Spliterator_OfInt() {}

func (t *BitSet_1BitSetSpliterator) Is_Spliterator_OfPrimitive() {}

func (t *BitSet_1BitSetSpliterator) Is_Spliterator() {}

func (t *BitSet_1BitSetSpliterator) TrySplit__Spliterator_OfPrimitive() Spliterator_OfPrimitive { return t.TrySplit__Spliterator_OfInt() }

func (t *BitSet_1BitSetSpliterator) TryAdvance_O__Z(p0 any) bool { return t.TryAdvance_IntConsumer__Z(IntConsumer_Cast(p0)) }

func (t *BitSet_1BitSetSpliterator) ForEachRemaining_O__V(p0 any) { t.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func (t *BitSet_1BitSetSpliterator) TrySplit__Spliterator() Spliterator { return t.TrySplit__Spliterator_OfInt() }

func (t *BitSet_1BitSetSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *BitSet_1BitSetSpliterator) ForEachRemaining_Consumer__V(p0 Consumer) { Spliterator_OfInt_ForEachRemaining_Consumer__V(t, p0) }

func (t *BitSet_1BitSetSpliterator) TryAdvance_Consumer__Z(p0 Consumer) bool { return Spliterator_OfInt_TryAdvance_Consumer__Z(t, p0) }

func (t *BitSet_1BitSetSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *BitSet_1BitSetSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *BitSet_1BitSetSpliterator) GetClass__Class() *Class { return BitSet_1BitSetSpliterator_class }

func (t *BitSet_1BitSetSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *BitSet_1BitSetSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BitSet_1BitSetSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func BitSet_1BitSetSpliterator_InstanceOf(x any) bool { _, ok := x.(*BitSet_1BitSetSpliterator); return ok }

func BitSet_1BitSetSpliterator_Cast(x any) *BitSet_1BitSetSpliterator { if x == nil { return nil }; v, ok := x.(*BitSet_1BitSetSpliterator); if !ok { panic(ClassCast(x, BitSet_1BitSetSpliterator_class)) }; return v }
