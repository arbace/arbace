//line java_nio_file_Files.ae:1
package jrt























func Files_New() *Files { Files_Init(); t := &Files{}; t.Ctor(); return t }
//line :25:1
func (t *Files) Ctor() { panic(A2g_NotTranslated("java.nio.file.Files.<init>()V")) }



func Files_File_Path__File(path Path) *File { Files_Init()
	return Path_Cast(Objects_RequireNonNull_O__O(path)).ToFile__File()
}
func Files_Has_OpenOption1_OpenOption__Z(options *RefArray, option OpenOption) bool { Files_Init()
	var arr_101153 *RefArray = options; var len_101154 int32 = int32(len(arr_101153.A)); var i_101155 int32 = 0; for ; i_101155 < len_101154; i_101155++ { var o OpenOption = As[OpenOption](arr_101153.A[i_101155]); if o == option { return true } }
//line :32:1
	return false
}


func Files_NewInputStream_Path_OpenOption1__InputStream(path Path, options *RefArray) InputStream_I { Files_Init()

	var arr_101156 *RefArray = options; var len_101157 int32 = int32(len(arr_101156.A)); var i_101158 int32 = 0; for ; i_101158 < len_101157; i_101158++ { var o OpenOption = As[OpenOption](arr_101156.A[i_101158]); var tmp1 bool; var tmp2 bool; var tmp3 *StandardOpenOption
		StandardOpenOption_Init(); tmp3 = StandardOpenOption_APPEND; tmp2 = any(o) == any(tmp3.Ref()); if !tmp2 { var tmp4 *StandardOpenOption; StandardOpenOption_Init(); tmp4 = StandardOpenOption_WRITE; tmp2 = any(o) == any(tmp4.Ref()) }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(UnsupportedOperationException_New_String(Concat(Lit_1371, StrOfObj(o), Lit_1496)))) } }
	var f *File = Files_File_Path__File(path)
	if NN(f).Exists__Z() { } else { panic(Thrown(NoSuchFileException_New_String(path.ToString__String()))) }
	var tmp5 InputStream_I; tmp6 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp5 = FileInputStream_New_File(f); return nil }()
//line :43:1
	if tmp6 != nil { if FileNotFoundException_InstanceOf(tmp6) { var x *FileNotFoundException = FileNotFoundException_Cast(tmp6)


		panic(Thrown(FileSystemException_New_String_String_String(path.ToString__String(), nil, Files_Reason_FileNotFoundException__String(x)))) } else {
//line :43:1
			panic(tmp6) } }; return tmp5
}



func Files_NewOutputStream_Path_OpenOption1__OutputStream(path Path, options *RefArray) OutputStream_I { Files_Init()

	var f *File = Files_File_Path__File(path); var append_ bool; var tmp1 *StandardOpenOption
	StandardOpenOption_Init(); tmp1 = StandardOpenOption_APPEND; append_ = Files_Has_OpenOption1_OpenOption__Z(options, Up_StandardOpenOption_OpenOption(tmp1))
	var tmp2 bool; var tmp3 bool; tmp3 = append_; if tmp3 { var tmp4 *StandardOpenOption; StandardOpenOption_Init(); tmp4 = StandardOpenOption_TRUNCATE_EXISTING; tmp3 = Files_Has_OpenOption1_OpenOption__Z(options, Up_StandardOpenOption_OpenOption(tmp4)) }; tmp2 = tmp3; if tmp2 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1497))) }
	var tmp5 *StandardOpenOption; StandardOpenOption_Init(); tmp5 = StandardOpenOption_READ; if Files_Has_OpenOption1_OpenOption__Z(options, Up_StandardOpenOption_OpenOption(tmp5)) {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1498))) }
	var create bool; var tmp6 bool; var tmp7 bool; tmp7 = int32(len(options.A)) == 0; if !tmp7 { var tmp8 *StandardOpenOption; StandardOpenOption_Init(); tmp8 = StandardOpenOption_CREATE; tmp7 = Files_Has_OpenOption1_OpenOption__Z(options, Up_StandardOpenOption_OpenOption(tmp8)) }; tmp6 = tmp7; if !tmp6 {
		var tmp9 *StandardOpenOption; StandardOpenOption_Init(); tmp9 = StandardOpenOption_CREATE_NEW; tmp6 = Files_Has_OpenOption1_OpenOption__Z(options, Up_StandardOpenOption_OpenOption(tmp9)) }
//line :56:1
	create = tmp6

	var tmp10 bool; var tmp11 bool; var tmp12 *StandardOpenOption; StandardOpenOption_Init(); tmp12 = StandardOpenOption_CREATE_NEW; tmp11 = Files_Has_OpenOption1_OpenOption__Z(options, Up_StandardOpenOption_OpenOption(tmp12)); if tmp11 { tmp11 = NN(f).Exists__Z() }; tmp10 = tmp11; if tmp10 {
		panic(Thrown(FileAlreadyExistsException_New_String(path.ToString__String()))) }
	var tmp13 bool; var tmp14 bool; tmp14 = !create; if tmp14 { tmp14 = !NN(f).Exists__Z() }; tmp13 = tmp14; if tmp13 { panic(Thrown(NoSuchFileException_New_String(path.ToString__String()))) }
	var tmp15 OutputStream_I; tmp16 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp15 = FileOutputStream_New_File_Z(f, append_); return nil }()
//line :61:1
	if tmp16 != nil { if FileNotFoundException_InstanceOf(tmp16) { var x *FileNotFoundException = FileNotFoundException_Cast(tmp16); var parent *File = NN(NN(f).GetAbsoluteFile__File()).GetParentFile__File(); var tmp17 bool; var tmp18 bool



		tmp18 = !(parent == nil); if tmp18 { tmp18 = !NN(parent).Exists__Z() }; tmp17 = tmp18; if tmp17 {
			panic(Thrown(NoSuchFileException_New_String(path.ToString__String()))) }
		panic(Thrown(FileSystemException_New_String_String_String(path.ToString__String(), nil, Files_Reason_FileNotFoundException__String(x)))) } else {
//line :61:1
			panic(tmp16) } }; return tmp15
}






func Files_Reason_FileNotFoundException__String(x *FileNotFoundException) *String { Files_Init()
	var m *String = NN(x).GetMessage__String(); var i int32
	if m == nil { i = -1 } else { i = NN(m).LastIndexOf_String__I(Lit_1499) }
	var tmp1 bool; var tmp2 bool; tmp2 = i < 0; if !tmp2 { tmp2 = !NN(m).EndsWith_String__Z(Lit_1176) }; tmp1 = tmp2; if tmp1 { return m } else {

		return NN(m).Substring_I_I__String(i+2, NN(m).Length__I()-1)
	} }
func Files_NewBufferedReader_Path_Charset__BufferedReader(path Path, cs Charset_I) BufferedReader_I { Files_Init()

	return BufferedReader_New_Reader(InputStreamReader_New_InputStream_Charset(Files_NewInputStream_Path_OpenOption1__InputStream(path, RefArrayOf(OpenOption_class)), cs))
}
func Files_NewBufferedReader_Path__BufferedReader(path Path) BufferedReader_I { Files_Init()
	return Files_NewBufferedReader_Path_Charset__BufferedReader(path, StandardCharsets_UTF_8)
}
func Files_NewBufferedWriter_Path_Charset_OpenOption1__BufferedWriter(path Path, cs Charset_I, options *RefArray) BufferedWriter_I { Files_Init()


	return BufferedWriter_New_Writer(OutputStreamWriter_New_OutputStream_Charset(Files_NewOutputStream_Path_OpenOption1__OutputStream(path, options), cs))
}
func Files_NewBufferedWriter_Path_OpenOption1__BufferedWriter(path Path, options *RefArray) BufferedWriter_I { Files_Init()

	return Files_NewBufferedWriter_Path_Charset_OpenOption1__BufferedWriter(path, StandardCharsets_UTF_8, options)
}
func Files_ReadAllBytes_Path__B1(path Path) *ByteArray { Files_Init()
	var in InputStream_I = Files_NewInputStream_Path_OpenOption1__InputStream(path, RefArrayOf(OpenOption_class)); var tmp1 *ByteArray; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = in.ReadAllBytes__B1(); return nil }(); if tmp2 == nil { if !(in == nil) { in.Close__V() } }; if tmp2 != nil { if true { var t_101159 Throwable_I = tmp2; if !(in == nil) { tmp3 := func() (exc Throwable_I) { defer Catch(&exc); in.Close__V(); return nil }(); if tmp3 != nil { if true { var x_101160 Throwable_I = tmp3; t_101159.AddSuppressed_Throwable__V(x_101160) } } }; panic(Thrown(t_101159)) } }; return tmp1
}
func Files_ReadString_Path_Charset__String(path Path, cs Charset_I) *String { Files_Init()
	return String_New_B1_Charset(Files_ReadAllBytes_Path__B1(path), cs)
}
func Files_ReadString_Path__String(path Path) *String { Files_Init()
	return Files_ReadString_Path_Charset__String(path, StandardCharsets_UTF_8)
}
func Files_ReadAllLines_Path_Charset__List(path Path, cs Charset_I) List { Files_Init()

	var reader BufferedReader_I = Files_NewBufferedReader_Path_Charset__BufferedReader(path, cs); var tmp1 List; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var result List = ArrayList_New()
		L1: for { var line *String = reader.ReadLine__String(); if line == nil { break L1 }; result.Add_O__Z(line.Ref()); continue L1 }
//line :104:1
			tmp1 = result }
		return nil }()
//line :103:1
	if tmp2 == nil { if !(reader == nil) { reader.Close__V() } }; if tmp2 != nil { if true { var t_101161 Throwable_I = tmp2; if !(reader == nil) { tmp3 := func() (exc Throwable_I) { defer Catch(&exc); reader.Close__V(); return nil }(); if tmp3 != nil { if true { var x_101162 Throwable_I = tmp3; t_101161.AddSuppressed_Throwable__V(x_101162) } } }; panic(Thrown(t_101161)) } }; return tmp1
}



func Files_ReadAllLines_Path__List(path Path) List { Files_Init()
	return Files_ReadAllLines_Path_Charset__List(path, StandardCharsets_UTF_8)
}
func Files_Lines_Path_Charset__Stream(path Path, cs Charset_I) Stream { Files_Init()

	var br BufferedReader_I = Files_NewBufferedReader_Path_Charset__BufferedReader(path, cs)
	return Stream_Cast(br.Lines__Stream().OnClose_Runnable__BaseStream(&Runnable_Fn{Fn: func() { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)


		br.Close__V(); return nil }(); if tmp1 != nil { if IOException_InstanceOf(tmp1) { var x IOException_I = IOException_Cast(tmp1); panic(Thrown(UncheckedIOException_New_IOException(x))) } else { panic(tmp1) } } },
	})) }
func Files_Lines_Path__Stream(path Path) Stream { Files_Init()
	return Files_Lines_Path_Charset__Stream(path, StandardCharsets_UTF_8)
}
func Files_Write_Path_B1_OpenOption1__Path(path Path, bytes *ByteArray, options *RefArray) Path { Files_Init()

	Objects_RequireNonNull_O__O(bytes.Ref())
	var out OutputStream_I = Files_NewOutputStream_Path_OpenOption1__OutputStream(path, options); tmp1 := func() (exc Throwable_I) { defer Catch(&exc); out.Write_B1__V(bytes); return nil }(); if tmp1 == nil { if !(out == nil) { out.Close__V() } }; if tmp1 != nil { if true { var t_101163 Throwable_I = tmp1; if !(out == nil) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc); out.Close__V(); return nil }(); if tmp2 != nil { if true { var x_101164 Throwable_I = tmp2; t_101163.AddSuppressed_Throwable__V(x_101164) } } }; panic(Thrown(t_101163)) } }
//line :122:1
	return path
}




func Files_Write_Path_Iterable_Charset_OpenOption1__Path(path Path, lines Iterable, cs Charset_I, options *RefArray) Path { Files_Init()


	Objects_RequireNonNull_O__O(lines)
	var writer BufferedWriter_I = Files_NewBufferedWriter_Path_Charset_OpenOption1__BufferedWriter(path, cs, options); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var i_101165 Iterator = lines.Iterator__Iterator(); for i_101165.HasNext__Z() { var line CharSequence = CharSequence_Cast(i_101165.Next__O()); writer.Append_CharSequence__Writer(line); writer.NewLine__V() } }; return nil }()
//line :132:1
	if tmp1 == nil { if !(writer == nil) { writer.Close__V() } }; if tmp1 != nil { if true { var t_101166 Throwable_I = tmp1; if !(writer == nil) { tmp2 := func() (exc Throwable_I) { defer Catch(&exc); writer.Close__V(); return nil }(); if tmp2 != nil { if true { var x_101167 Throwable_I = tmp2; t_101166.AddSuppressed_Throwable__V(x_101167) } } }; panic(Thrown(t_101166)) } }
//line :128:1
	return path
}






func Files_Write_Path_Iterable_OpenOption1__Path(path Path, lines Iterable, options *RefArray) Path { Files_Init()


	return Files_Write_Path_Iterable_Charset_OpenOption1__Path(path, lines, StandardCharsets_UTF_8, options)
}
func Files_WriteString_Path_CharSequence_Charset_OpenOption1__Path(path Path, csq CharSequence, cs Charset_I, options *RefArray) Path { Files_Init()


	Objects_RequireNonNull_O__O(csq)
	return Files_Write_Path_B1_OpenOption1__Path(path, NN(String_ValueOf_O__String(csq)).GetBytes_Charset__B1(cs), options)
}
func Files_WriteString_Path_CharSequence_OpenOption1__Path(path Path, csq CharSequence, options *RefArray) Path { Files_Init()

	return Files_WriteString_Path_CharSequence_Charset_OpenOption1__Path(path, csq, StandardCharsets_UTF_8, options)
}
func Files_Exists_Path_LinkOption1__Z(path Path, options *RefArray) bool { Files_Init()
	return NN(Files_File_Path__File(path)).Exists__Z()
}
func Files_NotExists_Path_LinkOption1__Z(path Path, options *RefArray) bool { Files_Init()
	return !NN(Files_File_Path__File(path)).Exists__Z()
}
func Files_IsDirectory_Path_LinkOption1__Z(path Path, options *RefArray) bool { Files_Init()
	return NN(Files_File_Path__File(path)).IsDirectory__Z()
}
func Files_IsRegularFile_Path_LinkOption1__Z(path Path, options *RefArray) bool { Files_Init()
	return NN(Files_File_Path__File(path)).IsFile__Z()
}
func Files_IsReadable_Path__Z(path Path) bool { Files_Init()
	return NN(Files_File_Path__File(path)).CanRead__Z()
}
func Files_IsWritable_Path__Z(path Path) bool { Files_Init()
	return NN(Files_File_Path__File(path)).CanWrite__Z()
}
func Files_IsExecutable_Path__Z(path Path) bool { Files_Init()
	return NN(Files_File_Path__File(path)).CanExecute__Z()
}
func Files_IsHidden_Path__Z(path Path) bool { Files_Init()
	return NN(Files_File_Path__File(path)).IsHidden__Z()
}
func Files_IsSameFile_Path_Path__Z(path, path2 Path) bool { Files_Init()
	if path.Equals_O__Z(path2) { return true } else {


		if Files_Exists_Path_LinkOption1__Z(path, RefArrayOf(LinkOption_class)) { } else { panic(Thrown(NoSuchFileException_New_String(path.ToString__String()))) }
		if Files_Exists_Path_LinkOption1__Z(path2, RefArrayOf(LinkOption_class)) { } else { panic(Thrown(NoSuchFileException_New_String(path2.ToString__String()))) }
		return path.ToRealPath_LinkOption1__Path(RefArrayOf(LinkOption_class)).Equals_O__Z(path2.ToRealPath_LinkOption1__Path(RefArrayOf(LinkOption_class)))
	} }
func Files_Size_Path__J(path Path) int64 { Files_Init()
	var f *File = Files_File_Path__File(path)
	if NN(f).Exists__Z() { } else { panic(Thrown(NoSuchFileException_New_String(path.ToString__String()))) }
	return NN(f).Length__J()
}
func Files_CreateFile_Path_FileAttribute1__Path(path Path, attrs *RefArray) Path { Files_Init()

	var f *File = Files_File_Path__File(path); var created bool = false; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)


		created = NN(f).CreateNewFile__Z(); return nil }()
//line :192:1
	if tmp1 != nil { if IOException_InstanceOf(tmp1) { var x IOException_I = IOException_Cast(tmp1); _ = x

		panic(Thrown(NoSuchFileException_New_String(path.ToString__String()))) } else {
//line :192:1
			panic(tmp1)
		}
	}
	if created { } else { panic(Thrown(FileAlreadyExistsException_New_String(path.ToString__String()))) }
//line :190:1
	return path
}






func Files_CreateDirectory_Path_FileAttribute1__Path(dir Path, attrs *RefArray) Path { Files_Init()

	var f *File = Files_File_Path__File(dir)
	if NN(f).Mkdir__Z() { return dir } else {


		if NN(f).Exists__Z() { panic(Thrown(FileAlreadyExistsException_New_String(dir.ToString__String()))) }
		var parent *File = NN(NN(f).GetAbsoluteFile__File()).GetParentFile__File(); var tmp1 bool; var tmp2 bool
		tmp2 = !(parent == nil); if tmp2 { tmp2 = !NN(parent).Exists__Z() }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(NoSuchFileException_New_String(dir.ToString__String()))) }
		panic(Thrown(AccessDeniedException_New_String(dir.ToString__String())))
	} }
func Files_CreateDirectories_Path_FileAttribute1__Path(dir Path, attrs *RefArray) Path { Files_Init()

	var f *File = Files_File_Path__File(dir)
	if NN(f).IsDirectory__Z() { return dir } else {


		if NN(f).Exists__Z() { panic(Thrown(FileAlreadyExistsException_New_String(dir.ToString__String()))) }
		var parent Path = dir.ToAbsolutePath__Path().GetParent__Path()
		if !(parent == nil) { Files_CreateDirectories_Path_FileAttribute1__Path(parent, RefArrayOf(FileAttribute_class)) }
		var tmp1 bool; var tmp2 bool; tmp2 = !NN(f).Mkdir__Z(); if tmp2 { tmp2 = !NN(f).IsDirectory__Z() }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(AccessDeniedException_New_String(dir.ToString__String()))) }
//line :217:1
		return dir
	}
}



func Files_CreateTemp_Path_String_String_Z__Path(dir Path, prefix, suffix *String, directory bool) Path { Files_Init()



	if prefix == nil { prefix = Lit_69 }
	if suffix == nil { var tmp1 *String; if directory { tmp1 = Lit_69 } else { tmp1 = Lit_74 }; suffix = tmp1 }
	if dir == nil { dir = Path_Of_String_String1__Path(System_GetProperty_String__String(Lit_78), RefArrayOf(String_class)) }
	{ var tmp2 bool; var tmp3 bool; tmp3 = NN(prefix).IndexOf_I__I(47) >= 0; if !tmp3 { tmp3 = NN(suffix).IndexOf_I__I(47) >= 0 }; tmp2 = tmp3; if tmp2 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1500))) }
	L1: for {
		var name *String = Concat(prefix, Long_ToUnsignedString_J__String(Files_RANDOM.NextLong__J()), suffix); var p Path = dir.Resolve_String__Path(name); var f *File = p.ToFile__File()


		if directory {

			if NN(f).Mkdir__Z() { return p }
			if NN(f).Exists__Z() { } else { panic(Thrown(NoSuchFileException_New_String(dir.ToString__String()))) } } else {
				var created bool = false; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

					created = NN(f).CreateNewFile__Z(); return nil }()
//line :241:1
				if tmp4 != nil { if IOException_InstanceOf(tmp4) { var x IOException_I = IOException_Cast(tmp4); _ = x

					panic(Thrown(NoSuchFileException_New_String(dir.ToString__String()))) } else {
//line :241:1
						panic(tmp4)
					}
				}
				if created { return p } }
//line :232:1
		continue L1
	}
	}









	panic("a2g: unreachable")
}
func Files_CreateTempFile_Path_String_String_FileAttribute1__Path(dir Path, prefix, suffix *String, attrs *RefArray) Path { Files_Init()


	return Files_CreateTemp_Path_String_String_Z__Path(Path_Cast(Objects_RequireNonNull_O__O(dir)), prefix, suffix, false)
}
func Files_CreateTempFile_String_String_FileAttribute1__Path(prefix, suffix *String, attrs *RefArray) Path { Files_Init()


	return Files_CreateTemp_Path_String_String_Z__Path(nil, prefix, suffix, false)
}
func Files_CreateTempDirectory_Path_String_FileAttribute1__Path(dir Path, prefix *String, attrs *RefArray) Path { Files_Init()


	return Files_CreateTemp_Path_String_String_Z__Path(Path_Cast(Objects_RequireNonNull_O__O(dir)), prefix, nil, true)
}
func Files_CreateTempDirectory_String_FileAttribute1__Path(prefix *String, attrs *RefArray) Path { Files_Init()

	return Files_CreateTemp_Path_String_String_Z__Path(nil, prefix, nil, true)
}
func Files_Delete_Path__V(path Path) { Files_Init()
	var f *File = Files_File_Path__File(path)
	if NN(f).Delete__Z() { } else {
		if NN(f).Exists__Z() { } else { panic(Thrown(NoSuchFileException_New_String(path.ToString__String()))) }
		var names *RefArray = NN(f).List__String1(); var tmp1 bool; var tmp2 bool
		tmp2 = !(names == nil); if tmp2 { tmp2 = int32(len(names.A)) > 0 }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(DirectoryNotEmptyException_New_String(path.ToString__String()))) }
		panic(Thrown(AccessDeniedException_New_String(path.ToString__String())))
	} }
func Files_DeleteIfExists_Path__Z(path Path) bool { Files_Init()
	if !NN(Files_File_Path__File(path)).Exists__Z() { return false } else { Files_Delete_Path__V(path); return true
	} }
func Files_Copy_Path_Path_CopyOption1__Path(source, target Path, options *RefArray) Path { Files_Init()

	var from *File = Files_File_Path__File(source); var to *File = Files_File_Path__File(target)

	if NN(from).Exists__Z() { } else { panic(Thrown(NoSuchFileException_New_String(source.ToString__String()))) }
	if NN(to).Exists__Z() {
		var tmp1 *StandardCopyOption; StandardCopyOption_Init(); tmp1 = StandardCopyOption_REPLACE_EXISTING; if Files_HasCopyOption_CopyOption1_CopyOption__Z(options, Up_StandardCopyOption_CopyOption(tmp1)) { } else {
			panic(Thrown(FileAlreadyExistsException_New_String(target.ToString__String()))) }
		Files_Delete_Path__V(target) }
	if NN(from).IsDirectory__Z() {
		Files_CreateDirectory_Path_FileAttribute1__Path(target, RefArrayOf(FileAttribute_class)) } else {
			var in InputStream_I = FileInputStream_New_File(from); tmp5 := func() (exc Throwable_I) { defer Catch(&exc); { var out OutputStream_I; var tmp2 *StandardOpenOption
				StandardOpenOption_Init(); tmp2 = StandardOpenOption_CREATE_NEW; out = Files_NewOutputStream_Path_OpenOption1__OutputStream(target, RefArrayOf(OpenOption_class, tmp2.Ref())); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
					in.TransferTo_OutputStream__J(out); return nil }()
//line :288:1
				if tmp3 == nil { if !(out == nil) { out.Close__V() } }; if tmp3 != nil { if true { var t_101168 Throwable_I = tmp3; if !(out == nil) { tmp4 := func() (exc Throwable_I) { defer Catch(&exc); out.Close__V(); return nil }(); if tmp4 != nil { if true { var x_101169 Throwable_I = tmp4; t_101168.AddSuppressed_Throwable__V(x_101169) } } }; panic(Thrown(t_101168))
				} } }
				return nil }()
//line :288:1
			if tmp5 == nil { in.Close__V() }; if tmp5 != nil { if true { var t_101170 Throwable_I = tmp5; tmp6 := func() (exc Throwable_I) { defer Catch(&exc); in.Close__V(); return nil }(); if tmp6 != nil { if true { var x_101171 Throwable_I = tmp6; t_101170.AddSuppressed_Throwable__V(x_101171) } }; panic(Thrown(t_101170))
			}
			} }
	var tmp7 *StandardCopyOption; StandardCopyOption_Init(); tmp7 = StandardCopyOption_COPY_ATTRIBUTES; if Files_HasCopyOption_CopyOption1_CopyOption__Z(options, Up_StandardCopyOption_CopyOption(tmp7)) {
		NN(to).SetLastModified_J__Z(NN(from).LastModified__J()) }
//line :279:1
	return target
}














func Files_Copy_InputStream_Path_CopyOption1__J(in InputStream_I, target Path, options *RefArray) int64 { Files_Init()

	Objects_RequireNonNull_O__O(in)
	if NN(Files_File_Path__File(target)).Exists__Z() {
		var tmp1 *StandardCopyOption; StandardCopyOption_Init(); tmp1 = StandardCopyOption_REPLACE_EXISTING; if Files_HasCopyOption_CopyOption1_CopyOption__Z(options, Up_StandardCopyOption_CopyOption(tmp1)) { } else {
			panic(Thrown(FileAlreadyExistsException_New_String(target.ToString__String()))) }
		Files_Delete_Path__V(target) }
	var out OutputStream_I; var tmp2 *StandardOpenOption; StandardOpenOption_Init(); tmp2 = StandardOpenOption_CREATE_NEW; out = Files_NewOutputStream_Path_OpenOption1__OutputStream(target, RefArrayOf(OpenOption_class, tmp2.Ref())); var tmp3 int64; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp3 = in.TransferTo_OutputStream__J(out); return nil }()
//line :302:1
	if tmp4 == nil { if !(out == nil) { out.Close__V() } }; if tmp4 != nil { if true { var t_101172 Throwable_I = tmp4; if !(out == nil) { tmp5 := func() (exc Throwable_I) { defer Catch(&exc); out.Close__V(); return nil }(); if tmp5 != nil { if true { var x_101173 Throwable_I = tmp5; t_101172.AddSuppressed_Throwable__V(x_101173) } } }; panic(Thrown(t_101172)) } }; return tmp3
}

func Files_Copy_Path_OutputStream__J(source Path, out OutputStream_I) int64 { Files_Init()
	Objects_RequireNonNull_O__O(out)
	var in InputStream_I = Files_NewInputStream_Path_OpenOption1__InputStream(source, RefArrayOf(OpenOption_class)); var tmp1 int64; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = in.TransferTo_OutputStream__J(out); return nil }(); if tmp2 == nil { if !(in == nil) { in.Close__V() } }; if tmp2 != nil { if true { var t_101174 Throwable_I = tmp2; if !(in == nil) { tmp3 := func() (exc Throwable_I) { defer Catch(&exc); in.Close__V(); return nil }(); if tmp3 != nil { if true { var x_101175 Throwable_I = tmp3; t_101174.AddSuppressed_Throwable__V(x_101175) } } }; panic(Thrown(t_101174)) } }; return tmp1
}
func Files_Move_Path_Path_CopyOption1__Path(source, target Path, options *RefArray) Path { Files_Init()

	var from *File = Files_File_Path__File(source); var to *File = Files_File_Path__File(target)

	if NN(from).Exists__Z() { } else { panic(Thrown(NoSuchFileException_New_String(source.ToString__String()))) }
	var tmp1 bool; var tmp2 bool; tmp2 = NN(to).Exists__Z(); if tmp2 {
		tmp2 = !source.ToAbsolutePath__Path().Normalize__Path().Equals_O__Z(target.ToAbsolutePath__Path().Normalize__Path()) }
//line :314:1
	tmp1 = tmp2; if tmp1 {


		var tmp3 *StandardCopyOption; StandardCopyOption_Init(); tmp3 = StandardCopyOption_REPLACE_EXISTING; if Files_HasCopyOption_CopyOption1_CopyOption__Z(options, Up_StandardCopyOption_CopyOption(tmp3)) { } else {
			panic(Thrown(FileAlreadyExistsException_New_String(target.ToString__String()))) }
		Files_Delete_Path__V(target) }
	if NN(from).RenameTo_File__Z(to) { } else {
		panic(Thrown(FileSystemException_New_String_String_String(source.ToString__String(), target.ToString__String(), Lit_1501))) }
//line :311:1
	return target
}











func Files_HasCopyOption_CopyOption1_CopyOption__Z(options *RefArray, option CopyOption) bool { Files_Init()
	var arr_101176 *RefArray = options; var len_101177 int32 = int32(len(arr_101176.A)); var i_101178 int32 = 0; for ; i_101178 < len_101177; i_101178++ { var o CopyOption = As[CopyOption](arr_101176.A[i_101178]); if o == option { return true } }
//line :324:1
	return false
}


func Files_NewDirectoryStream_Path__DirectoryStream(dir Path) DirectoryStream { Files_Init()
	return Files_NewDirectoryStream_Path_DirectoryStream_Filter__DirectoryStream(dir, Files_1_New())
}
func (t *Files_1) Accept_Path__Z(entry Path) bool { return true }

func Files_NewDirectoryStream_Path_String__DirectoryStream(dir Path, glob *String) DirectoryStream { Files_Init()

	if NN(glob).Equals_O__Z(Lit_1502) {
		return Files_NewDirectoryStream_Path__DirectoryStream(dir) } else {
			var pattern *Pattern = Pattern_Compile_String__Pattern(GlobPatterns_ToUnixRegex_String__String(glob))
			return Files_NewDirectoryStream_Path_DirectoryStream_Filter__DirectoryStream(dir, Files_2_New_Pattern(pattern))
		} }
func (t *Files_2) Accept_Path__Z(entry Path) bool {
	var name Path = entry.GetFileName__Path(); var tmp1 bool
	tmp1 = !(name == nil); if tmp1 {
		tmp1 = NN(NN(t.F_val_pattern).Matcher_CharSequence__Matcher(Up_String_CharSequence(name.ToString__String()))).Matches__Z() }
//line :342:1
	return tmp1
}

func Files_NewDirectoryStream_Path_DirectoryStream_Filter__DirectoryStream(dir Path, filter DirectoryStream_Filter) DirectoryStream { Files_Init()

	Objects_RequireNonNull_O__O(filter)
	var d *File = dir.ToFile__File()
	if NN(d).Exists__Z() { } else { panic(Thrown(NoSuchFileException_New_String(dir.ToString__String()))) }
	if NN(d).IsDirectory__Z() { } else { panic(Thrown(NotDirectoryException_New_String(dir.ToString__String()))) }
	var names *RefArray = NN(d).List__String1()
	if names == nil { panic(Thrown(AccessDeniedException_New_String(dir.ToString__String()))) }
	var entries List = ArrayList_New(); var arr_101179 *RefArray = names; var len_101180 int32 = int32(len(arr_101179.A)); var i_101181 int32 = 0; for ; i_101181 < len_101180; i_101181++ {
		var n *String = As[*String](arr_101179.A[i_101181]); var entry Path = dir.Resolve_String__Path(n)
		if filter.Accept_O__Z(entry) { entries.Add_O__Z(entry) } }
	return Files_3_New_List(entries)
}



func (t *Files_3) Iterator__Iterator() Iterator {
	if t.F_closed { panic(Thrown(IllegalStateException_New_String(Lit_1503))) }
	if t.F_iterated { panic(Thrown(IllegalStateException_New_String(Lit_1504))) }
	t.F_iterated = true
	var it Iterator = t.F_val_entries.Iterator__Iterator()
	return Files_3_1_New_Files_3_Iterator(t, it) }
func (t *Files_3_1) HasNext__Z() bool {
	var tmp1 bool; tmp1 = !t.F_this_0.F_closed; if tmp1 { tmp1 = t.F_val_it.HasNext__Z() }; return tmp1
}
func (t *Files_3_1) Next__Path() Path {
	if t.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	return Path_Cast(t.F_val_it.Next__O())
}
func (t *Files_3) Close__V() { t.F_closed = true }



type Files struct{ Object }

var Files_RANDOM Random_I

var Files_init ClassInit

func Files_Init() { if !Files_init.Done() { Files_init.Run(Files_clinit) } }

func Files_clinit() { Files_RANDOM = Random_New() }

func (t *Files) Ref() any { if t == nil { return nil }; return t }

func (t *Files) GetClass__Class() *Class { return Files_class }

func (t *Files) ToString__String() *String { return Object_toString(t) }

func (t *Files) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Files) CloneShallow() any { panic(CloneNotSupported(t)) }

func Files_InstanceOf(x any) bool { _, ok := x.(*Files); return ok }

func Files_Cast(x any) *Files { if x == nil { return nil }; v, ok := x.(*Files); if !ok { panic(ClassCast(x, Files_class)) }; return v }



type Files_1 struct{ Object }

func (t *Files_1) Is_DirectoryStream_Filter() {}

func Files_1_New() *Files_1 { t := &Files_1{}; t.Ctor(); return t }

func (t *Files_1) Ctor() {}

func (t *Files_1) Accept_O__Z(p0 any) bool { return t.Accept_Path__Z(Path_Cast(p0)) }

func (t *Files_1) Ref() any { if t == nil { return nil }; return t }

func (t *Files_1) GetClass__Class() *Class { return Files_1_class }

func (t *Files_1) ToString__String() *String { return Object_toString(t) }

func (t *Files_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Files_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Files_1_InstanceOf(x any) bool { _, ok := x.(*Files_1); return ok }

func Files_1_Cast(x any) *Files_1 { if x == nil { return nil }; v, ok := x.(*Files_1); if !ok { panic(ClassCast(x, Files_1_class)) }; return v }



type Files_2 struct{ Object; F_val_pattern *Pattern }

func (t *Files_2) Is_DirectoryStream_Filter() {}

func Files_2_New_Pattern(p0 *Pattern) *Files_2 { t := &Files_2{}; t.Ctor_Pattern(p0); return t }

func (t *Files_2) Ctor_Pattern(val_pattern *Pattern) { t.F_val_pattern = val_pattern }

func (t *Files_2) Accept_O__Z(p0 any) bool { return t.Accept_Path__Z(Path_Cast(p0)) }

func (t *Files_2) Ref() any { if t == nil { return nil }; return t }

func (t *Files_2) GetClass__Class() *Class { return Files_2_class }

func (t *Files_2) ToString__String() *String { return Object_toString(t) }

func (t *Files_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Files_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func Files_2_InstanceOf(x any) bool { _, ok := x.(*Files_2); return ok }

func Files_2_Cast(x any) *Files_2 { if x == nil { return nil }; v, ok := x.(*Files_2); if !ok { panic(ClassCast(x, Files_2_class)) }; return v }



type Files_3 struct{ Object; F_iterated, F_closed bool; F_val_entries List }

func (t *Files_3) Is_DirectoryStream() {}

func (t *Files_3) Is_Closeable() {}

func (t *Files_3) Is_Iterable() {}

func (t *Files_3) Is_AutoCloseable() {}

func Files_3_New_List(p0 List) *Files_3 { t := &Files_3{}; t.Ctor_List(p0); return t }

func (t *Files_3) Ctor_List(val_entries List) { t.F_val_entries = val_entries }

func (t *Files_3) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *Files_3) Spliterator__Spliterator() Spliterator { return Iterable_Spliterator__Spliterator(t) }

func (t *Files_3) Ref() any { if t == nil { return nil }; return t }

func (t *Files_3) GetClass__Class() *Class { return Files_3_class }

func (t *Files_3) ToString__String() *String { return Object_toString(t) }

func (t *Files_3) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Files_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func Files_3_InstanceOf(x any) bool { _, ok := x.(*Files_3); return ok }

func Files_3_Cast(x any) *Files_3 { if x == nil { return nil }; v, ok := x.(*Files_3); if !ok { panic(ClassCast(x, Files_3_class)) }; return v }



type Files_3_1 struct{ Object; F_this_0 *Files_3; F_val_it Iterator }

func (t *Files_3_1) Is_Iterator() {}

func Files_3_1_New_Files_3_Iterator(p0 *Files_3, p1 Iterator) *Files_3_1 { t := &Files_3_1{}; t.Ctor_Files_3_Iterator(p0, p1); return t }

func (t *Files_3_1) Ctor_Files_3_Iterator(this_0 *Files_3, val_it Iterator) { t.F_val_it = val_it; NN(this_0); t.F_this_0 = this_0 }

func (t *Files_3_1) Next__O() any { return t.Next__Path() }

func (t *Files_3_1) Remove__V() { Iterator_Remove__V(t) }

func (t *Files_3_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *Files_3_1) Ref() any { if t == nil { return nil }; return t }

func (t *Files_3_1) GetClass__Class() *Class { return Files_3_1_class }

func (t *Files_3_1) ToString__String() *String { return Object_toString(t) }

func (t *Files_3_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Files_3_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Files_3_1_InstanceOf(x any) bool { _, ok := x.(*Files_3_1); return ok }

func Files_3_1_Cast(x any) *Files_3_1 { if x == nil { return nil }; v, ok := x.(*Files_3_1); if !ok { panic(ClassCast(x, Files_3_1_class)) }; return v }
