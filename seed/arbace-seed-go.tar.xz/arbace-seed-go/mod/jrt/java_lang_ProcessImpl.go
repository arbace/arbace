//line java_lang_ProcessImpl.ae:1
package jrt


























func ProcessImpl_Start_String1_Map_String_ProcessBuilder_Redirect1_Z__Process(cmdarray *RefArray, environment Map, dir *String, redirects *RefArray, redirectErrorStream bool) Process_I { ProcessImpl_Init()




	var args *RefArray = NewRefArray(Prim_byte.ArrayClass(), int32(len(cmdarray.A))-1); var size int32 = int32(len(args.A))
	var i int32 = 0
L1: for {
	if i < int32(len(args.A)) {
		args.Store(i, NN(As[*String](cmdarray.A[i+1])).GetBytes_Charset__B1(ProcessImpl_JNU_CHARSET).Ref())
		size = size + int32(len(As[*ByteArray](args.A[i]).A))
		i = i + 1; continue L1 }
//line :35:1
	break L1
}



	var argBlock *ByteArray = NewByteArray(size); var i_2 int32 = 0; var arr_101087 *RefArray = args; var len_101088 int32 = int32(len(arr_101087.A)); var i_101089 int32 = 0; for ; i_101089 < len_101088; i_101089++ {

		var arg *ByteArray = As[*ByteArray](arr_101087.A[i_101089])
		System_Arraycopy_O_I_O_I_I__V(arg.Ref(), 0, argBlock.Ref(), i_2, int32(len(arg.A)))
		i_2 = i_2 + (int32(len(arg.A)) + 1) }
	var envc *IntArray = NewIntArray(1); var envBlock *ByteArray = ProcessEnvironment_ToEnvironmentBlock_Map_I1__B1(environment, envc); var std_fds *IntArray; var f0 FileInputStream_I; var f1 FileOutputStream_I; var f2 FileOutputStream_I; var tmp1 Process_I; tmp23 := func() (exc Throwable_I) { defer Catch(&exc)






		{ var forceNullOutputStream bool = false
			if redirects == nil {
				std_fds = IntArrayOf(-1, -1, -1) } else {

					std_fds = NewIntArray(3)
					var tmp2 ProcessBuilder_Redirect_I = As[ProcessBuilder_Redirect_I](redirects.A[0]); var tmp3 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp3 = ProcessBuilder_Redirect_PIPE; if tmp2 == tmp3 {

						std_fds.A[0] = -1 } else {
//line :57:1
							var tmp4 ProcessBuilder_Redirect_I = As[ProcessBuilder_Redirect_I](redirects.A[0]); var tmp5 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp5 = ProcessBuilder_Redirect_INHERIT; if tmp4 == tmp5 {



								std_fds.A[0] = 0 } else {
//line :57:1
									if ProcessBuilder_RedirectPipeImpl_InstanceOf(As[ProcessBuilder_Redirect_I](redirects.A[0])) {





										std_fds.A[0] = HostFiles_Handle_FileDescriptor__I(NN(ProcessBuilder_RedirectPipeImpl_Cast(As[ProcessBuilder_Redirect_I](redirects.A[0]))).GetFd__FileDescriptor()) } else {



											f0 = FileInputStream_New_File(As[ProcessBuilder_Redirect_I](redirects.A[0]).File__File())
											std_fds.A[0] = HostFiles_Handle_FileDescriptor__I(f0.GetFD__FileDescriptor()) } } }
					var tmp6 ProcessBuilder_Redirect_I = As[ProcessBuilder_Redirect_I](redirects.A[1]); var tmp7 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp7 = ProcessBuilder_Redirect_PIPE; if tmp6 == tmp7 {

						std_fds.A[1] = -1 } else {
//line :69:1
							var tmp8 ProcessBuilder_Redirect_I = As[ProcessBuilder_Redirect_I](redirects.A[1]); var tmp9 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp9 = ProcessBuilder_Redirect_INHERIT; if tmp8 == tmp9 {



								std_fds.A[1] = 1 } else {
//line :69:1
									if ProcessBuilder_RedirectPipeImpl_InstanceOf(As[ProcessBuilder_Redirect_I](redirects.A[1])) {






										std_fds.A[1] = HostFiles_Handle_FileDescriptor__I(NN(ProcessBuilder_RedirectPipeImpl_Cast(As[ProcessBuilder_Redirect_I](redirects.A[1]))).GetFd__FileDescriptor())

										forceNullOutputStream = true } else {


											f1 = FileOutputStream_New_File_Z(As[ProcessBuilder_Redirect_I](redirects.A[1]).File__File(), As[ProcessBuilder_Redirect_I](redirects.A[1]).Append__Z())
											std_fds.A[1] = HostFiles_Handle_FileDescriptor__I(f1.GetFD__FileDescriptor()) } } }
					var tmp10 ProcessBuilder_Redirect_I = As[ProcessBuilder_Redirect_I](redirects.A[2]); var tmp11 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp11 = ProcessBuilder_Redirect_PIPE; if tmp10 == tmp11 {

						std_fds.A[2] = -1 } else {
//line :83:1
							var tmp12 ProcessBuilder_Redirect_I = As[ProcessBuilder_Redirect_I](redirects.A[2]); var tmp13 ProcessBuilder_Redirect_I; ProcessBuilder_Redirect_Init(); tmp13 = ProcessBuilder_Redirect_INHERIT; if tmp12 == tmp13 {



								std_fds.A[2] = 2 } else {
//line :83:1
									if ProcessBuilder_RedirectPipeImpl_InstanceOf(As[ProcessBuilder_Redirect_I](redirects.A[2])) {





										std_fds.A[2] = HostFiles_Handle_FileDescriptor__I(NN(ProcessBuilder_RedirectPipeImpl_Cast(As[ProcessBuilder_Redirect_I](redirects.A[2]))).GetFd__FileDescriptor()) } else {



											f2 = FileOutputStream_New_File_Z(As[ProcessBuilder_Redirect_I](redirects.A[2]).File__File(), As[ProcessBuilder_Redirect_I](redirects.A[2]).Append__Z())
											std_fds.A[2] = HostFiles_Handle_FileDescriptor__I(f2.GetFD__FileDescriptor()) } } } }
			var tmp14 *ByteArray = ProcessImpl_ToCString_String__B1(As[*String](cmdarray.A[0])); var tmp15 int32 = int32(len(args.A)); var tmp16 int32 = envc.A[0]; var p Process_I = ProcessImpl_New_B1_B1_I_B1_I_B1_I1_Z_Z(tmp14, argBlock, tmp15, envBlock, tmp16, ProcessImpl_ToCString_String__B1(dir), std_fds, forceNullOutputStream, redirectErrorStream)








			if !(redirects == nil) {
				var tmp17 bool; var tmp18 bool; tmp18 = std_fds.A[0] >= 0; if tmp18 {
					tmp18 = ProcessBuilder_RedirectPipeImpl_InstanceOf(As[ProcessBuilder_Redirect_I](redirects.A[0])) }
//line :105:1
				tmp17 = tmp18; if tmp17 {

					HostFiles_SetHandle_FileDescriptor_I__V(NN(ProcessBuilder_RedirectPipeImpl_Cast(As[ProcessBuilder_Redirect_I](redirects.A[0]))).GetFd__FileDescriptor(), std_fds.A[0])
				}
				var tmp19 bool; var tmp20 bool; tmp20 = std_fds.A[1] >= 0; if tmp20 {
					tmp20 = ProcessBuilder_RedirectPipeImpl_InstanceOf(As[ProcessBuilder_Redirect_I](redirects.A[1])) }
//line :109:1
				tmp19 = tmp20; if tmp19 {

					HostFiles_SetHandle_FileDescriptor_I__V(NN(ProcessBuilder_RedirectPipeImpl_Cast(As[ProcessBuilder_Redirect_I](redirects.A[1]))).GetFd__FileDescriptor(), std_fds.A[1])
				}
				var tmp21 bool; var tmp22 bool; tmp22 = std_fds.A[2] >= 0; if tmp22 {
					tmp22 = ProcessBuilder_RedirectPipeImpl_InstanceOf(As[ProcessBuilder_Redirect_I](redirects.A[2])) }
//line :113:1
				tmp21 = tmp22; if tmp21 {

					HostFiles_SetHandle_FileDescriptor_I__V(NN(ProcessBuilder_RedirectPipeImpl_Cast(As[ProcessBuilder_Redirect_I](redirects.A[2]))).GetFd__FileDescriptor(), std_fds.A[2]) } }
//line :95:1
			tmp1 = p
		}

















		return nil }(); tmp24 := func() (exc Throwable_I) { defer Catch(&exc)





			if !(f0 == nil) { f0.Close__V() }; return nil }(); tmp25 := func() (exc Throwable_I) { defer Catch(&exc)

				if !(f1 == nil) { f1.Close__V() }; return nil }(); if !(f2 == nil) { f2.Close__V() }; if tmp25 != nil { panic(tmp25) }
//line :119:1
	if tmp24 != nil { panic(tmp24) }
//line :51:1
	if tmp23 != nil { panic(tmp23) }; return tmp1
}




























func ProcessImpl_ToCString_String__B1(s *String) *ByteArray { ProcessImpl_Init()
	if !(s == nil) {
		var bytes *ByteArray = NN(s).GetBytes_Charset__B1(ProcessImpl_JNU_CHARSET); var result *ByteArray = NewByteArray(int32(len(bytes.A)) + 1)

		System_Arraycopy_O_I_O_I_I__V(bytes.Ref(), 0, result.Ref(), 0, int32(len(bytes.A)))
		result.A[int32(len(result.A))-1] = 0
//line :83:1
		return result } else {
//line :82:1
			return nil
		}
}







































func (t *ProcessImpl) ForkAndExec_I_B1_B1_B1_I_B1_I_B1_I1_Z__I(mode int32, helperpath, prog, argBlock *ByteArray, argc int32, envBlock *ByteArray, envc int32, dir *ByteArray, fds *IntArray, redirectErrorStream bool) int32 {





	return ProcessImpl_HostForkAndExec_B1_B1_I_B1_I_B1_I1_Z__I(prog, argBlock, argc, envBlock, envc, dir, fds, redirectErrorStream)
}
func ProcessImpl_HostForkAndExec_B1_B1_I_B1_I_B1_I1_Z__I(p0, p1 *ByteArray, p2 int32, p3 *ByteArray, p4 int32, p5 *ByteArray, p6 *IntArray, p7 bool) int32 { return ProcessImpl_HostForkAndExec_B1_B1_I_B1_I_B1_I1_Z__I_native(p0, p1, p2, p3, p4, p5, p6, p7) }





func ProcessImpl_New_B1_B1_I_B1_I_B1_I1_Z_Z(p0, p1 *ByteArray, p2 int32, p3 *ByteArray, p4 int32, p5 *ByteArray, p6 *IntArray, p7, p8 bool) *ProcessImpl { ProcessImpl_Init(); t := &ProcessImpl{}; t.Ctor_B1_B1_I_B1_I_B1_I1_Z_Z(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :138:1
func (t *ProcessImpl) Ctor_B1_B1_I_B1_I_B1_I1_Z_Z(prog, argBlock *ByteArray, argc int32, envBlock *ByteArray, envc int32, dir *ByteArray, fds *IntArray, forceNullOutputStream, redirectErrorStream bool) { t.Process.Ctor(t); t.F_lock = ReentrantLock_New(); t.F_condition = NN(t.F_lock).NewCondition__Condition()





	t.F_pid = t.ForkAndExec_I_B1_B1_B1_I_B1_I_B1_I1_Z__I(0, nil, prog, argBlock, argc, envBlock, envc, dir, fds, redirectErrorStream)
	t.F_processHandle = ProcessHandleImpl_GetInternal_J__ProcessHandleImpl(int64(t.F_pid))
	t.InitStreams_I1_Z__V(fds, forceNullOutputStream)
}
func ProcessImpl_NewFileDescriptor_I__FileDescriptor(fd int32) *FileDescriptor { ProcessImpl_Init()
	var fileDescriptor *FileDescriptor = FileDescriptor_New()
	HostFiles_SetHandle_FileDescriptor_I__V(fileDescriptor, fd)
//line :149:1
	return fileDescriptor
}


func (t *ProcessImpl) InitStreams_I1_Z__V(fds *IntArray, forceNullOutputStream bool) {
	var tmp1 OutputStream_I
	if fds.A[0] == -1 { ProcessBuilder_NullOutputStream_Init(); tmp1 = Up_ProcessBuilder_NullOutputStream_OutputStream(ProcessBuilder_NullOutputStream_INSTANCE) } else {

		tmp1 = ProcessImpl_ProcessPipeOutputStream_New_I(fds.A[0]) }
//line :154:1
	t.F_stdin = tmp1



	var tmp2 InputStream_I; var tmp3 bool; var tmp4 bool
	tmp4 = fds.A[1] == -1; if !tmp4 { tmp4 = forceNullOutputStream }; tmp3 = tmp4; if tmp3 { ProcessBuilder_NullInputStream_Init(); tmp2 = Up_ProcessBuilder_NullInputStream_InputStream(ProcessBuilder_NullInputStream_INSTANCE) } else {

		tmp2 = ProcessImpl_ProcessPipeInputStream_New_I(fds.A[1]) }
//line :158:1
	t.F_stdout = tmp2



	var tmp5 InputStream_I
	if fds.A[2] == -1 { ProcessBuilder_NullInputStream_Init(); tmp5 = Up_ProcessBuilder_NullInputStream_InputStream(ProcessBuilder_NullInputStream_INSTANCE) } else {

		tmp5 = ProcessImpl_ProcessPipeInputStream_New_I(fds.A[2]) }
//line :162:1
	t.F_stderr = tmp5



	ProcessHandleImpl_Completion_J_Z__CompletableFuture(int64(t.F_pid), true).Handle_BiFunction__CompletableFuture(&BiFunction_Fn{Fn: func(p0, p1 any) any { var exitcode *Integer = Integer_Cast(p0); var throwable Throwable_I = Throwable_Cast(p1); var tmp6 any; _ = throwable;

		NN(t.F_lock).Lock__V(); tmp8 := func() (exc Throwable_I) { defer Catch(&exc)

			{ var tmp7 int32; if exitcode == nil { tmp7 = -1 } else { tmp7 = NN(exitcode).IntValue__I() }; t.F_exitcode = tmp7
				t.F_hasExited = true
				t.F_condition.SignalAll__V() }; return nil }();
		NN(t.F_lock).Unlock__V(); if /*line :169:1*/ tmp8 != nil { panic(tmp8) }; if




		ProcessImpl_ProcessPipeInputStream_InstanceOf(t.F_stdout) {
			NN(ProcessImpl_ProcessPipeInputStream_Cast(t.F_stdout)).ProcessExited__V() }; if
		ProcessImpl_ProcessPipeInputStream_InstanceOf(t.F_stderr) {
			NN(ProcessImpl_ProcessPipeInputStream_Cast(t.F_stderr)).ProcessExited__V() }; if
		ProcessImpl_ProcessPipeOutputStream_InstanceOf(t.F_stdin) {
			NN(ProcessImpl_ProcessPipeOutputStream_Cast(t.F_stdin)).ProcessExited__V() }; tmp6 = nil; return tmp6 },
	},
	) }
func (t *ProcessImpl) Destroy_Z__V(force bool) {
	NN(t.F_lock).Lock__V(); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
		if t.F_hasExited { } else { NN(t.F_processHandle).DestroyProcess_Z__Z(force) }; return nil }(); NN(t.F_lock).Unlock__V(); if tmp1 != nil { panic(tmp1) }; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
			t.F_stdin.Close__V(); return nil }(); if tmp2 != nil { if IOException_InstanceOf(tmp2) { var ignored IOException_I = IOException_Cast(tmp2); _ = ignored } else { panic(tmp2) } }; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
				t.F_stdout.Close__V(); return nil }(); if tmp3 != nil { if IOException_InstanceOf(tmp3) { var ignored_2 IOException_I = IOException_Cast(tmp3); _ = ignored_2 } else { panic(tmp3) } }; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
					t.F_stderr.Close__V(); return nil }(); if tmp4 != nil { if IOException_InstanceOf(tmp4) { var ignored_3 IOException_I = IOException_Cast(tmp4); _ = ignored_3 } else { panic(tmp4)
					}
					}
}













































































































func (t *ProcessImpl) GetOutputStream__OutputStream() OutputStream_I { return t.F_stdin }

func (t *ProcessImpl) GetInputStream__InputStream() InputStream_I { return t.F_stdout }

func (t *ProcessImpl) GetErrorStream__InputStream() InputStream_I { return t.F_stderr }

func (t *ProcessImpl) WaitFor__I() int32 {
	NN(t.F_lock).Lock__V()
	var tmp1 int32; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); L1: for { if !t.F_hasExited { t.F_condition.Await__V(); continue L1 }; break L1 }; tmp1 = t.F_exitcode; return nil }(); NN(t.F_lock).Unlock__V(); if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *ProcessImpl) WaitFor_J_TimeUnit__Z(timeout int64, unit *TimeUnit) bool {

	NN(t.F_lock).Lock__V()
	var tmp1 bool; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var remainingNanos int64 = NN(unit).ToNanos_J__J(timeout)
		L1: for { var tmp2 bool; var tmp3 bool; tmp3 = remainingNanos > 0; if tmp3 { tmp3 = !t.F_hasExited }; tmp2 = tmp3; if tmp2 {
			remainingNanos = t.F_condition.AwaitNanos_J__J(remainingNanos)
//line :315:1
			continue L1 }; break L1 }
//line :314:1
			tmp1 = t.F_hasExited
		}
		return nil
	}()
	NN(t.F_lock).Unlock__V()
//line :313:1
	if tmp4 != nil { panic(tmp4) }; return tmp1
}





func (t *ProcessImpl) ExitValue__I() int32 {
	NN(t.F_lock).Lock__V()
	var tmp1 int32; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		if t.F_hasExited { } else { panic(Thrown(IllegalThreadStateException_New_String(Lit_1185))) }
//line :322:1
		tmp1 = t.F_exitcode
		return nil
	}()
	NN(t.F_lock).Unlock__V()
//line :322:1
	if tmp2 != nil { panic(tmp2) }; return tmp1
}














func (t *ProcessImpl) OnExit__CompletableFuture() CompletableFuture_I {
	return ProcessHandleImpl_Completion_J_Z__CompletableFuture(int64(t.F_pid), false).HandleAsync_BiFunction__CompletableFuture(&BiFunction_Fn{Fn: func(p0, p1 any) any { var unusedExitStatus *Integer = Integer_Cast(p0); var unusedThrowable Throwable_I = Throwable_Cast(p1); var tmp1 *ProcessImpl; var interrupted bool = false; _ = unusedExitStatus; _ = unusedThrowable; L1:


	for { tmp2, tmp3, tmp4 := func() (ctl int32, rv bool, exc Throwable_I) { defer Catch(&exc)

		t.WaitFor__I(); return 2, false, nil; return 0, false, nil }(); _ = tmp3
//line :343:1
		if tmp4 != nil { if InterruptedException_InstanceOf(tmp4) { var ie *InterruptedException = InterruptedException_Cast(tmp4); _ = ie


			interrupted = true } else {
//line :343:1
				panic(tmp4) } }; switch tmp2 { case 2: { break L1 }}
//line :342:1
		continue L1 }; if interrupted {




			Thread_CurrentThread__Thread().Interrupt__V() }; tmp1 = t; return /*line :339:1*/ Up_ProcessImpl_Process(tmp1) }})
}









func (t *ProcessImpl) ToHandle__ProcessHandle() ProcessHandle { return Up_ProcessHandleImpl_ProcessHandle(t.F_processHandle) }

func (t *ProcessImpl) SupportsNormalTermination__Z() bool { return true }


func (t *ProcessImpl) Destroy__V() { t.Destroy_Z__V(false) }

func (t *ProcessImpl) DestroyForcibly__Process() Process_I {
	t.Destroy_Z__V(true)
//line :357:1
	return t
}


func (t *ProcessImpl) Pid__J() int64 { return int64(t.F_pid) }

func (t *ProcessImpl) IsAlive__Z() bool {
	NN(t.F_lock).Lock__V()
	var tmp1 bool; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = !t.F_hasExited; return nil }(); NN(t.F_lock).Unlock__V(); if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *ProcessImpl) ToString__String() *String {
	var tmp1 *StringBuilder = NN(StringBuilder_New_String(Lit_1186).Append_I__StringBuilder(t.F_pid)).Append_String__StringBuilder(Lit_1187); var tmp2 any

	if t.F_hasExited { tmp2 = Integer_ValueOf_I__Integer(t.F_exitcode).Ref() } else { tmp2 = Lit_1188 }
//line :368:1
	return NN(NN(NN(tmp1).Append_O__StringBuilder(tmp2)).Append_String__StringBuilder(Lit_1189)).ToString__String()
}












func ProcessImpl_ProcessPipeInputStream_New_I(p0 int32) *ProcessImpl_ProcessPipeInputStream { ProcessImpl_ProcessPipeInputStream_Init(); t := &ProcessImpl_ProcessPipeInputStream{}; t.Ctor_I(p0); return t }
//line :382:1
func (t *ProcessImpl_ProcessPipeInputStream) Ctor_I(fd int32) { t.BufferedInputStream.Ctor_InputStream(t, Process_PipeInputStream_New_FileDescriptor(ProcessImpl_NewFileDescriptor_I__FileDescriptor(fd))); t.F_closeLock = Object_New() }


func ProcessImpl_ProcessPipeInputStream_DrainInputStream_InputStream__B1(in InputStream_I) *ByteArray { ProcessImpl_ProcessPipeInputStream_Init()
	var n int32 = 0; var j int32 = 0; var a *ByteArray


L1: for { var tmp1 int32; j = in.Available__I(); tmp1 = j; if tmp1 > 0 {
	var tmp2 *ByteArray; if a == nil { tmp2 = NewByteArray(j) } else { tmp2 = Arrays_CopyOf_B1_I__B1(a, n+j) }; a = tmp2
	n = n + in.Read_B1_I_I__I(a, n, j)
//line :389:1
	continue L1 }; break L1
}

	var tmp3 bool; var tmp4 bool; tmp4 = a == nil; if !tmp4 { tmp4 = n == int32(len(a.A)) }; tmp3 = tmp4; if tmp3 { return a } else { return Arrays_CopyOf_B1_I__B1(a, n)
	} }
func (t *ProcessImpl_ProcessPipeInputStream) ProcessExited__V() { MonitorEnter(t); defer MonitorExit(t)
	var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var in InputStream_I = t.F_in.Load()
			if !(in == nil) {
				var stragglers *ByteArray = ProcessImpl_ProcessPipeInputStream_DrainInputStream_InputStream__B1(in)
				in.Close__V()
				var tmp2 InputStream_I
				if stragglers == nil { ProcessBuilder_NullInputStream_Init(); tmp2 = Up_ProcessBuilder_NullInputStream_InputStream(ProcessBuilder_NullInputStream_INSTANCE) } else {

					tmp2 = ByteArrayInputStream_New_B1(stragglers) }
//line :401:1
				t.F_in.Store(tmp2)
			}
		}
		return nil }(); if /*line :396:1*/ tmp3 != nil { if IOException_InstanceOf(tmp3) { var ignored IOException_I = IOException_Cast(tmp3); _ = ignored } else { panic(tmp3) } } }()
}









func (t *ProcessImpl_ProcessPipeInputStream) Close__V() {
	var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.BufferedInputStream.Impl_Close__V(t) }()
}



func ProcessImpl_ProcessPipeOutputStream_New_I(p0 int32) *ProcessImpl_ProcessPipeOutputStream { t := &ProcessImpl_ProcessPipeOutputStream{}; t.Ctor_I(p0); return t }
//line :413:1
func (t *ProcessImpl_ProcessPipeOutputStream) Ctor_I(fd int32) { t.BufferedOutputStream.Ctor_OutputStream(t, Process_PipeOutputStream_New_FileDescriptor(ProcessImpl_NewFileDescriptor_I__FileDescriptor(fd))) }


func (t *ProcessImpl_ProcessPipeOutputStream) ProcessExited__V() { MonitorEnter(t); defer MonitorExit(t)
	var out OutputStream_I = t.F_out
	if !(out == nil) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
		out.Close__V(); return nil }(); if tmp1 != nil { if IOException_InstanceOf(tmp1) { var ignored IOException_I = IOException_Cast(tmp1); _ = ignored } else { panic(tmp1) } }
		var tmp2 *ProcessBuilder_NullOutputStream; ProcessBuilder_NullOutputStream_Init(); tmp2 = ProcessBuilder_NullOutputStream_INSTANCE; t.F_out = Up_ProcessBuilder_NullOutputStream_OutputStream(tmp2)
	}
}








func ProcessImpl_DeferredCloseProcessPipeInputStream_New_I(p0 int32) *ProcessImpl_DeferredCloseProcessPipeInputStream { ProcessImpl_DeferredCloseProcessPipeInputStream_Init(); t := &ProcessImpl_DeferredCloseProcessPipeInputStream{}; t.Ctor_I(p0); return t }
//line :431:1
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Ctor_I(fd int32) { panic(A2g_NotTranslated("java.lang.ProcessImpl$DeferredCloseProcessPipeInputStream.<init>(I)V")) }


func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) DrainInputStream_InputStream__InputStream(p0 InputStream_I) InputStream_I { panic(A2g_NotTranslated("java.lang.ProcessImpl$DeferredCloseProcessPipeInputStream.drainInputStream(Ljava/io/InputStream;)Ljava/io/InputStream;")) }















func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) ProcessExited__V() { panic(A2g_NotTranslated("java.lang.ProcessImpl$DeferredCloseProcessPipeInputStream.processExited()V")) }






func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Raise__V() {
	var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_useCount = t.F_useCount + 1 }()
}
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Lower__V() {
	var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.F_useCount = t.F_useCount - 1
		var tmp2 bool; var tmp3 bool; tmp3 = t.F_useCount == 0; if tmp3 { tmp3 = t.F_closePending }; tmp2 = tmp3; if tmp2 { t.F_closePending = false; t.BufferedInputStream.Impl_Close__V(t)
		} }() }
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Read__I() int32 {
	t.Raise__V()
	var tmp1 int32; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = t.BufferedInputStream.Impl_Read__I(t); return nil }(); t.Lower__V(); if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Read_B1__I(b *ByteArray) int32 {
	t.Raise__V()
	var tmp1 int32; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = t.BufferedInputStream.Impl_Read_B1__I(t, b); return nil }(); t.Lower__V(); if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	t.Raise__V()
	var tmp1 int32; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = t.BufferedInputStream.Impl_Read_B1_I_I__I(t, b, off, len_); return nil }(); t.Lower__V(); if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Skip_J__J(n int64) int64 {
	t.Raise__V()
	var tmp1 int64; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = t.BufferedInputStream.Impl_Skip_J__J(t, n); return nil }(); t.Lower__V(); if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Available__I() int32 {
	t.Raise__V()
	var tmp1 int32; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = t.BufferedInputStream.Impl_Available__I(t); return nil }(); t.Lower__V(); if tmp2 != nil { panic(tmp2) }; return tmp1
}
func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Close__V() {
	var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); if t.F_useCount == 0 { t.BufferedInputStream.Impl_Close__V(t) } else { t.F_closePending = true } }()
}


type ProcessImpl struct{ Process; F_pid int32; F_processHandle *ProcessHandleImpl; F_exitcode int32; F_hasExited bool; F_lock *ReentrantLock; F_condition Condition; F_stdin OutputStream_I; F_stdout, F_stderr InputStream_I }

const ProcessImpl_SUPPORTS_NORMAL_TERMINATION bool = true

var ProcessImpl_JNU_CHARSET Charset_I

var ProcessImpl_init ClassInit

func ProcessImpl_Init() { if !ProcessImpl_init.Done() { ProcessImpl_init.Run(ProcessImpl_clinit) } }

func ProcessImpl_clinit() { ProcessImpl_JNU_CHARSET = Charset_ForName_String__Charset(System_GetProperty_String__String(Lit_1184)) }

func (t *ProcessImpl) OutputWriter__BufferedWriter() BufferedWriter_I { return t.Impl_OutputWriter__BufferedWriter(t) }

func (t *ProcessImpl) Children__Stream() Stream { return t.Impl_Children__Stream(t) }

func (t *ProcessImpl) Close__V() { t.Impl_Close__V(t) }

func (t *ProcessImpl) WaitFor_Duration__Z(p0 *Duration) bool { return t.Impl_WaitFor_Duration__Z(t, p0) }

func (t *ProcessImpl) Info__ProcessHandle_Info() ProcessHandle_Info { return t.Impl_Info__ProcessHandle_Info(t) }

func (t *ProcessImpl) OutputWriter_Charset__BufferedWriter(p0 Charset_I) BufferedWriter_I { return t.Impl_OutputWriter_Charset__BufferedWriter(t, p0) }

func (t *ProcessImpl) InputReader_Charset__BufferedReader(p0 Charset_I) BufferedReader_I { return t.Impl_InputReader_Charset__BufferedReader(t, p0) }

func (t *ProcessImpl) ErrorReader__BufferedReader() BufferedReader_I { return t.Impl_ErrorReader__BufferedReader(t) }

func (t *ProcessImpl) InputReader__BufferedReader() BufferedReader_I { return t.Impl_InputReader__BufferedReader(t) }

func (t *ProcessImpl) Descendants__Stream() Stream { return t.Impl_Descendants__Stream(t) }

func (t *ProcessImpl) ErrorReader_Charset__BufferedReader(p0 Charset_I) BufferedReader_I { return t.Impl_ErrorReader_Charset__BufferedReader(t, p0) }

func (t *ProcessImpl) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessImpl) GetClass__Class() *Class { return ProcessImpl_class }

func (t *ProcessImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessImpl_InstanceOf(x any) bool { _, ok := x.(*ProcessImpl); return ok }

func ProcessImpl_Cast(x any) *ProcessImpl { if x == nil { return nil }; v, ok := x.(*ProcessImpl); if !ok { panic(ClassCast(x, ProcessImpl_class)) }; return v }



type ProcessImpl_DeferredCloseProcessPipeInputStream struct{ BufferedInputStream; F_closeLock any; F_useCount int32; F_closePending bool }

var ProcessImpl_DeferredCloseProcessPipeInputStream_init ClassInit

func ProcessImpl_DeferredCloseProcessPipeInputStream_Init() { if !ProcessImpl_DeferredCloseProcessPipeInputStream_init.Done() { ProcessImpl_DeferredCloseProcessPipeInputStream_init.Run(ProcessImpl_DeferredCloseProcessPipeInputStream_clinit) } }

func ProcessImpl_DeferredCloseProcessPipeInputStream_clinit() { BufferedInputStream_Init() }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) GetClass__Class() *Class { return ProcessImpl_DeferredCloseProcessPipeInputStream_class }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) ToString__String() *String { return Object_toString(t) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessImpl_DeferredCloseProcessPipeInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessImpl_DeferredCloseProcessPipeInputStream_InstanceOf(x any) bool { _, ok := x.(*ProcessImpl_DeferredCloseProcessPipeInputStream); return ok }

func ProcessImpl_DeferredCloseProcessPipeInputStream_Cast(x any) *ProcessImpl_DeferredCloseProcessPipeInputStream { if x == nil { return nil }; v, ok := x.(*ProcessImpl_DeferredCloseProcessPipeInputStream); if !ok { panic(ClassCast(x, ProcessImpl_DeferredCloseProcessPipeInputStream_class)) }; return v }



type ProcessImpl_LaunchMechanism struct{ Enum }

func (t *ProcessImpl_LaunchMechanism) Is_Constable() {}

var ProcessImpl_LaunchMechanism_FORK *ProcessImpl_LaunchMechanism

var ProcessImpl_LaunchMechanism_POSIX_SPAWN *ProcessImpl_LaunchMechanism

var ProcessImpl_LaunchMechanism_VFORK *ProcessImpl_LaunchMechanism

var ProcessImpl_LaunchMechanism__VALUES *RefArray

var ProcessImpl_LaunchMechanism_init ClassInit

func ProcessImpl_LaunchMechanism_Init() { if !ProcessImpl_LaunchMechanism_init.Done() { ProcessImpl_LaunchMechanism_init.Run(ProcessImpl_LaunchMechanism_clinit) } }

func ProcessImpl_LaunchMechanism_clinit() { ProcessImpl_LaunchMechanism_FORK = ProcessImpl_LaunchMechanism_New_String_I(Lit_1190, 0); ProcessImpl_LaunchMechanism_POSIX_SPAWN = ProcessImpl_LaunchMechanism_New_String_I(Lit_1191, 1); ProcessImpl_LaunchMechanism_VFORK = ProcessImpl_LaunchMechanism_New_String_I(Lit_1192, 2); ProcessImpl_LaunchMechanism__VALUES = ProcessImpl_LaunchMechanism_X_values__ProcessImpl_LaunchMechanism1() }

func ProcessImpl_LaunchMechanism_New_String_I(p0 *String, p1 int32) *ProcessImpl_LaunchMechanism { ProcessImpl_LaunchMechanism_Init(); t := &ProcessImpl_LaunchMechanism{}; t.Ctor_String_I(p0, p1); return t }

func (t *ProcessImpl_LaunchMechanism) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func ProcessImpl_LaunchMechanism_Values__ProcessImpl_LaunchMechanism1() *RefArray { ProcessImpl_LaunchMechanism_Init(); return ProcessImpl_LaunchMechanism__VALUES.Copy() }

func ProcessImpl_LaunchMechanism_ValueOf_String__ProcessImpl_LaunchMechanism(p0 *String) *ProcessImpl_LaunchMechanism { ProcessImpl_LaunchMechanism_Init(); return ProcessImpl_LaunchMechanism_Cast(Enum_ValueOf_Class_String__Enum(ProcessImpl_LaunchMechanism_class, p0)) }

func ProcessImpl_LaunchMechanism_X_values__ProcessImpl_LaunchMechanism1() *RefArray { ProcessImpl_LaunchMechanism_Init(); return RefArrayOf(ProcessImpl_LaunchMechanism_class, ProcessImpl_LaunchMechanism_FORK, ProcessImpl_LaunchMechanism_POSIX_SPAWN, ProcessImpl_LaunchMechanism_VFORK) }

func (t *ProcessImpl_LaunchMechanism) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ProcessImpl_LaunchMechanism) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ProcessImpl_LaunchMechanism) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ProcessImpl_LaunchMechanism) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.lang.ProcessImpl$LaunchMechanism.describeConstable()Ljava/util/Optional;")) }

func (t *ProcessImpl_LaunchMechanism) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ProcessImpl_LaunchMechanism) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProcessImpl_LaunchMechanism) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessImpl_LaunchMechanism) GetClass__Class() *Class { return ProcessImpl_LaunchMechanism_class }

func (t *ProcessImpl_LaunchMechanism) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessImpl_LaunchMechanism_InstanceOf(x any) bool { _, ok := x.(*ProcessImpl_LaunchMechanism); return ok }

func ProcessImpl_LaunchMechanism_Cast(x any) *ProcessImpl_LaunchMechanism { if x == nil { return nil }; v, ok := x.(*ProcessImpl_LaunchMechanism); if !ok { panic(ClassCast(x, ProcessImpl_LaunchMechanism_class)) }; return v }



type ProcessImpl_ProcessPipeInputStream struct{ BufferedInputStream; F_closeLock any }

var ProcessImpl_ProcessPipeInputStream_init ClassInit

func ProcessImpl_ProcessPipeInputStream_Init() { if !ProcessImpl_ProcessPipeInputStream_init.Done() { ProcessImpl_ProcessPipeInputStream_init.Run(ProcessImpl_ProcessPipeInputStream_clinit) } }

func ProcessImpl_ProcessPipeInputStream_clinit() { BufferedInputStream_Init() }

func (t *ProcessImpl_ProcessPipeInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *ProcessImpl_ProcessPipeInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *ProcessImpl_ProcessPipeInputStream) Read_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_Read_B1_I_I__I(t, p0, p1, p2) }

func (t *ProcessImpl_ProcessPipeInputStream) Read__I() int32 { return t.Impl_Read__I(t) }

func (t *ProcessImpl_ProcessPipeInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *ProcessImpl_ProcessPipeInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *ProcessImpl_ProcessPipeInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *ProcessImpl_ProcessPipeInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *ProcessImpl_ProcessPipeInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *ProcessImpl_ProcessPipeInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *ProcessImpl_ProcessPipeInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *ProcessImpl_ProcessPipeInputStream) Available__I() int32 { return t.Impl_Available__I(t) }

func (t *ProcessImpl_ProcessPipeInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *ProcessImpl_ProcessPipeInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessImpl_ProcessPipeInputStream) GetClass__Class() *Class { return ProcessImpl_ProcessPipeInputStream_class }

func (t *ProcessImpl_ProcessPipeInputStream) ToString__String() *String { return Object_toString(t) }

func (t *ProcessImpl_ProcessPipeInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessImpl_ProcessPipeInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessImpl_ProcessPipeInputStream_InstanceOf(x any) bool { _, ok := x.(*ProcessImpl_ProcessPipeInputStream); return ok }

func ProcessImpl_ProcessPipeInputStream_Cast(x any) *ProcessImpl_ProcessPipeInputStream { if x == nil { return nil }; v, ok := x.(*ProcessImpl_ProcessPipeInputStream); if !ok { panic(ClassCast(x, ProcessImpl_ProcessPipeInputStream_class)) }; return v }



type ProcessImpl_ProcessPipeOutputStream struct{ BufferedOutputStream }

func (t *ProcessImpl_ProcessPipeOutputStream) Write_I__V(p0 int32) { t.Impl_Write_I__V(t, p0) }

func (t *ProcessImpl_ProcessPipeOutputStream) Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_Write_B1_I_I__V(t, p0, p1, p2) }

func (t *ProcessImpl_ProcessPipeOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *ProcessImpl_ProcessPipeOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *ProcessImpl_ProcessPipeOutputStream) Close__V() { t.Impl_Close__V(t) }

func (t *ProcessImpl_ProcessPipeOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *ProcessImpl_ProcessPipeOutputStream) GetClass__Class() *Class { return ProcessImpl_ProcessPipeOutputStream_class }

func (t *ProcessImpl_ProcessPipeOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *ProcessImpl_ProcessPipeOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProcessImpl_ProcessPipeOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProcessImpl_ProcessPipeOutputStream_InstanceOf(x any) bool { _, ok := x.(*ProcessImpl_ProcessPipeOutputStream); return ok }

func ProcessImpl_ProcessPipeOutputStream_Cast(x any) *ProcessImpl_ProcessPipeOutputStream { if x == nil { return nil }; v, ok := x.(*ProcessImpl_ProcessPipeOutputStream); if !ok { panic(ClassCast(x, ProcessImpl_ProcessPipeOutputStream_class)) }; return v }
