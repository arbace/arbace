//line java_util_RandomAccess.ae:1
package jrt






type RandomAccess interface{ Object_I; Is_RandomAccess() }

func RandomAccess_InstanceOf(x any) bool { _, ok := x.(RandomAccess); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(RandomAccess_class) } }; return ok }

func RandomAccess_Cast(x any) RandomAccess { if x == nil { return nil }; v, ok := x.(RandomAccess); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(RandomAccess_class) } }; if !ok { panic(ClassCast(x, RandomAccess_class)) }; return v }
