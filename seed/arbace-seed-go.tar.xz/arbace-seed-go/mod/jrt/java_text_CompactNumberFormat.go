//line java_text_CompactNumberFormat.ae:1
package jrt

import "math"




























































func CompactNumberFormat_New_String_DecimalFormatSymbols_String1(p0 *String, p1 *DecimalFormatSymbols, p2 *RefArray) *CompactNumberFormat { CompactNumberFormat_Init(); t := &CompactNumberFormat{}; t.Ctor_String_DecimalFormatSymbols_String1(p0, p1, p2); return t }
//line :64:1
func (t *CompactNumberFormat) Ctor_String_DecimalFormatSymbols_String1(decimalPattern *String, symbols *DecimalFormatSymbols, compactPatterns *RefArray) { t.Ctor_String_DecimalFormatSymbols_String1_String(decimalPattern, symbols, compactPatterns, Lit_69) }



func CompactNumberFormat_New_String_DecimalFormatSymbols_String1_String(p0 *String, p1 *DecimalFormatSymbols, p2 *RefArray, p3 *String) *CompactNumberFormat { CompactNumberFormat_Init(); t := &CompactNumberFormat{}; t.Ctor_String_DecimalFormatSymbols_String1_String(p0, p1, p2, p3); return t }
//line :68:1
func (t *CompactNumberFormat) Ctor_String_DecimalFormatSymbols_String1_String(decimalPattern *String, symbols *DecimalFormatSymbols, compactPatterns *RefArray, pluralRules *String) { t.NumberFormat.Ctor(t); t.F_groupingSize = 0; t.F_parseBigDecimal = false; var tmp1 *RoundingMode; RoundingMode_Init(); tmp1 = RoundingMode_HALF_EVEN; t.F_roundingMode = tmp1; t.F_pluralRules = Lit_69; t.F_parseStrict = false; t.F_digitList = DigitList_New();

	Objects_RequireNonNull_O_String__O(decimalPattern.Ref(), Lit_1730);
	Objects_RequireNonNull_O_String__O(symbols.Ref(), Lit_1731);
	Objects_RequireNonNull_O_String__O(compactPatterns.Ref(), Lit_1732);
	Objects_RequireNonNull_O_String__O(pluralRules.Ref(), Lit_1733);
	t.F_symbols = symbols;
	t.F_decimalFormat = DecimalFormat_New_String_DecimalFormatSymbols(Lit_1133, t.F_symbols);
	t.SetMaximumIntegerDigits_I__V(NN(t.F_decimalFormat).GetMaximumIntegerDigits__I());
	t.SetMinimumIntegerDigits_I__V(NN(t.F_decimalFormat).GetMinimumIntegerDigits__I());
	t.SetMaximumFractionDigits_I__V(NN(t.F_decimalFormat).GetMaximumFractionDigits__I());
	t.SetMinimumFractionDigits_I__V(NN(t.F_decimalFormat).GetMinimumFractionDigits__I());
	t.NumberFormat.Impl_SetGroupingUsed_Z__V(t, NN(t.F_decimalFormat).IsGroupingUsed__Z());
	t.NumberFormat.Impl_SetParseIntegerOnly_Z__V(t, NN(t.F_decimalFormat).IsParseIntegerOnly__Z());
	t.F_compactPatterns = compactPatterns;
	t.F_decimalPattern = decimalPattern;
	t.F_defaultDecimalFormat = DecimalFormat_New_String_DecimalFormatSymbols(t.F_decimalPattern, t.F_symbols);
	NN(t.F_defaultDecimalFormat).SetMaximumFractionDigits_I__V(0);
	t.F_pluralRules = pluralRules;
	t.ProcessCompactPatterns__V() }

func (t *CompactNumberFormat) Format_O_StringBuffer_FieldPosition__StringBuffer(number any, toAppendTo *StringBuffer, fieldPosition FieldPosition_I) *StringBuffer {

	var tmp1 any = number; if tmp1 == nil {













		panic(Thrown(IllegalArgumentException_New_String(Lit_1735))) }
//line :91:1
	if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)
		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(l).LongValue__J(), toAppendTo, fieldPosition) }
//line :91:1
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)

		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(i).LongValue__J(), toAppendTo, fieldPosition) }
//line :91:1
	if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)


		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(s).LongValue__J(), toAppendTo, fieldPosition) }
//line :91:1
	if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)



		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(b).LongValue__J(), toAppendTo, fieldPosition) }
//line :91:1
	if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)




		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(ai).LongValue__J(), toAppendTo, fieldPosition) }
//line :91:1
	if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)





		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(al).LongValue__J(), toAppendTo, fieldPosition) }
//line :91:1
	if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1); if NN(bi).BitLength__I() < 64 {







		return t.Format_J_StringBuffer_FieldPosition__StringBuffer(NN(bi).LongValue__J(), toAppendTo, fieldPosition) } }
//line :91:1
	if BigDecimal_InstanceOf(tmp1) { var bd *BigDecimal = BigDecimal_Cast(tmp1)









		return t.Format_BigDecimal_Format_StringBuf_FieldPosition__Format_StringBuf(bd, StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo), fieldPosition).AsStringBuffer__StringBuffer() }
//line :91:1
	if BigInteger_InstanceOf(tmp1) { var bi_2 *BigInteger = BigInteger_Cast(tmp1)











		return t.Format_BigInteger_Format_StringBuf_FieldPosition__Format_StringBuf(bi_2, StringBufFactory_Of_StringBuffer__Format_StringBuf(toAppendTo), fieldPosition).AsStringBuffer__StringBuffer() }
//line :91:1
	if Number_InstanceOf(tmp1) { var n Number_I = Number_Cast(tmp1)












		return t.Format_D_StringBuffer_FieldPosition__StringBuffer(n.DoubleValue__D(), toAppendTo, fieldPosition)
	}
	panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_1734, RefArrayOf(Object_class, NN(GetClass(number)).GetName__String().Ref())))))
}


func (t *CompactNumberFormat) Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(number any, toAppendTo Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	var tmp1 any = number; if tmp1 == nil {











		panic(Thrown(IllegalArgumentException_New_String(Lit_1735))) }
//line :112:1
	if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)
		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(l).LongValue__J(), toAppendTo, fieldPosition) }
//line :112:1
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)

		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(i).LongValue__J(), toAppendTo, fieldPosition) }
//line :112:1
	if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)


		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(s).LongValue__J(), toAppendTo, fieldPosition) }
//line :112:1
	if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)



		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(b).LongValue__J(), toAppendTo, fieldPosition) }
//line :112:1
	if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)




		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(ai).LongValue__J(), toAppendTo, fieldPosition) }
//line :112:1
	if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)





		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(al).LongValue__J(), toAppendTo, fieldPosition) }
//line :112:1
	if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1); if NN(bi).BitLength__I() < 64 {







		return t.Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(NN(bi).LongValue__J(), toAppendTo, fieldPosition) } }
//line :112:1
	if BigDecimal_InstanceOf(tmp1) { var bd *BigDecimal = BigDecimal_Cast(tmp1)








		return t.Format_BigDecimal_Format_StringBuf_FieldPosition__Format_StringBuf(bd, toAppendTo, fieldPosition) }
//line :112:1
	if BigInteger_InstanceOf(tmp1) { var bi_2 *BigInteger = BigInteger_Cast(tmp1)









		return t.Format_BigInteger_Format_StringBuf_FieldPosition__Format_StringBuf(bi_2, toAppendTo, fieldPosition) }
//line :112:1
	if Number_InstanceOf(tmp1) { var n Number_I = Number_Cast(tmp1)










		return t.Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(n.DoubleValue__D(), toAppendTo, fieldPosition)
	}
	panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_1734, RefArrayOf(Object_class, NN(GetClass(number)).GetName__String().Ref())))))
}


func (t *CompactNumberFormat) Format_D_StringBuffer_FieldPosition__StringBuffer(number float64, result *StringBuffer, fieldPosition FieldPosition_I) *StringBuffer {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, StringBufFactory_Of_StringBuffer__Format_StringBuf(result), fieldPosition.GetFieldDelegate__Format_FieldDelegate()).AsStringBuffer__StringBuffer()
}

func (t *CompactNumberFormat) Format_D_Format_StringBuf_FieldPosition__Format_StringBuf(number float64, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate())
}
func (t *CompactNumberFormat) Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number float64, result Format_StringBuf, delegate Format_FieldDelegate) Format_StringBuf {

	var nanOrInfinity bool = NN(t.F_decimalFormat).HandleNaN_D_Format_StringBuf_Format_FieldDelegate__Z(number, result, delegate)
	if nanOrInfinity { return result } else {

		var isNegative bool; var tmp1 bool; tmp1 = number < 0.0; if !tmp1 {
			var tmp2 bool; tmp2 = number == 0.0; if tmp2 { tmp2 = 1.0/number < 0.0 }; tmp1 = tmp2 }
//line :147:1
		isNegative = tmp1

		nanOrInfinity = NN(t.F_decimalFormat).HandleInfinity_D_Format_StringBuf_Format_FieldDelegate_Z__Z(number, result, delegate, isNegative)
		if nanOrInfinity { return result } else {

			var dList *DigitList = DigitList_New()
			NN(dList).SetRoundingMode_RoundingMode__V(t.GetRoundingMode__RoundingMode())
			var tmp3 float64; if isNegative { tmp3 = -number } else { tmp3 = number }; number = tmp3
			NN(dList).Set_Z_D_I__V(isNegative, number, t.GetMinimumFractionDigits__I())
			var roundedNumber float64 = NN(dList).GetDouble__D(); var compactDataIndex int32 = t.SelectCompactPattern_J__I(D2L(roundedNumber))



			if !(compactDataIndex == -1) {
				var divisor int64 = NN(Long_Cast(t.F_divisors.Get_I__O(compactDataIndex))).LongValue__J(); var val float64 = t.GetNumberValue_D_D__D(number, float64(divisor))

				if t.CheckIncrement_D_I_D__Z(val, compactDataIndex, float64(divisor)) {
					var tmp4 List = t.F_divisors; var tmp5 int32


					compactDataIndex = compactDataIndex + 1; tmp5 = compactDataIndex
//line :164:1
					divisor = NN(Long_Cast(tmp4.Get_I__O(tmp5))).LongValue__J()
				}




				roundedNumber = roundedNumber / float64(divisor)
				var tmp6 *DecimalFormat = t.F_decimalFormat; NN(tmp6).SetDigitList_Number_Z_I__V(Double_ValueOf_D__Double(roundedNumber), isNegative, t.GetMaximumFractionDigits__I())



				val = NN(NN(t.F_decimalFormat).GetDigitList__DigitList()).GetDouble__D()
				var prefix *String = t.GetAffix_Z_Z_Z_I_D__String(false, true, isNegative, compactDataIndex, val); var suffix *String = t.GetAffix_Z_Z_Z_I_D__String(false, false, isNegative, compactDataIndex, val); var tmp7 bool; var tmp8 bool

				tmp8 = !NN(prefix).IsEmpty__Z(); if !tmp8 { tmp8 = !NN(suffix).IsEmpty__Z() }; tmp7 = tmp8; if tmp7 {

					t.AppendPrefix_Format_StringBuf_String_Format_FieldDelegate__V(result, prefix, delegate)
					if NN(NN(CompactNumberFormat_Patterns_Cast(t.F_placeHolderPatterns.Get_I__O(compactDataIndex))).Get_D__String(val)).IsEmpty__Z() { } else {





						var tmp9 *DecimalFormat = t.F_decimalFormat; NN(tmp9).SubformatNumber_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__V(result, delegate, isNegative, false, t.GetMaximumIntegerDigits__I(), t.GetMinimumIntegerDigits__I(), t.GetMaximumFractionDigits__I(), t.GetMinimumFractionDigits__I())









						t.AppendSuffix_Format_StringBuf_String_Format_FieldDelegate__V(result, suffix, delegate) } } else {
							NN(t.F_defaultDecimalFormat).DoubleSubformat_D_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number, result, delegate, isNegative) } } else {





								NN(t.F_defaultDecimalFormat).DoubleSubformat_D_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number, result, delegate, isNegative) }
//line :156:1
			return result
		}
	}
}















































func (t *CompactNumberFormat) Format_J_StringBuffer_FieldPosition__StringBuffer(number int64, result *StringBuffer, fieldPosition FieldPosition_I) *StringBuffer {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, StringBufFactory_Of_StringBuffer__Format_StringBuf(result), fieldPosition.GetFieldDelegate__Format_FieldDelegate()).AsStringBuffer__StringBuffer()
}

func (t *CompactNumberFormat) Format_J_Format_StringBuf_FieldPosition__Format_StringBuf(number int64, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate())
}
func (t *CompactNumberFormat) Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number int64, result Format_StringBuf, delegate Format_FieldDelegate) Format_StringBuf {

	var isNegative bool = number < 0
	if isNegative { number = -number }
	if number < 0 {
		var bigIntegerValue *BigInteger = BigInteger_ValueOf_J__BigInteger(number)
		return t.Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(bigIntegerValue, result, delegate, true) } else {
			var compactDataIndex int32 = t.SelectCompactPattern_J__I(number)
			if !(compactDataIndex == -1) {
				var divisor int64 = NN(Long_Cast(t.F_divisors.Get_I__O(compactDataIndex))).LongValue__J(); var val float64 = t.GetNumberValue_D_D__D(float64(number), float64(divisor))

				if t.CheckIncrement_D_I_D__Z(val, compactDataIndex, float64(divisor)) {
					var tmp1 List = t.F_divisors; var tmp2 int32



					compactDataIndex = compactDataIndex + 1; tmp2 = compactDataIndex
//line :232:1
					divisor = NN(Long_Cast(tmp1.Get_I__O(tmp2))).LongValue__J()
				}



				var noFraction bool = number%divisor == 0
				if noFraction {

					number = number / divisor
					NN(t.F_decimalFormat).SetDigitList_Number_Z_I__V(Long_ValueOf_J__Long(number), isNegative, 0) } else {
						var dNumber float64 = float64(number) / float64(divisor); var tmp3 *DecimalFormat = t.F_decimalFormat
						NN(tmp3).SetDigitList_Number_Z_I__V(Double_ValueOf_D__Double(dNumber), isNegative, t.GetMaximumFractionDigits__I())
					}


				val = NN(NN(t.F_decimalFormat).GetDigitList__DigitList()).GetDouble__D()
				var prefix *String = t.GetAffix_Z_Z_Z_I_D__String(false, true, isNegative, compactDataIndex, val); var suffix *String = t.GetAffix_Z_Z_Z_I_D__String(false, false, isNegative, compactDataIndex, val); var tmp4 bool; var tmp5 bool

				tmp5 = !NN(prefix).IsEmpty__Z(); if !tmp5 { tmp5 = !NN(suffix).IsEmpty__Z() }; tmp4 = tmp5; if tmp4 {

					t.AppendPrefix_Format_StringBuf_String_Format_FieldDelegate__V(result, prefix, delegate)
					if NN(NN(CompactNumberFormat_Patterns_Cast(t.F_placeHolderPatterns.Get_I__O(compactDataIndex))).Get_D__String(val)).IsEmpty__Z() { } else {




						var tmp6 *DecimalFormat = t.F_decimalFormat; NN(tmp6).SubformatNumber_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__V(result, delegate, isNegative, noFraction, t.GetMaximumIntegerDigits__I(), t.GetMinimumIntegerDigits__I(), t.GetMaximumFractionDigits__I(), t.GetMinimumFractionDigits__I())








						t.AppendSuffix_Format_StringBuf_String_Format_FieldDelegate__V(result, suffix, delegate) } } else {

							var tmp7 int64; if isNegative { tmp7 = -number } else { tmp7 = number }; number = tmp7
							NN(t.F_defaultDecimalFormat).Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, delegate) } } else {

								var tmp8 int64; if isNegative { tmp8 = -number } else { tmp8 = number }; number = tmp8
								NN(t.F_defaultDecimalFormat).Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, delegate) }
//line :227:1
			return result
		}
}














































func (t *CompactNumberFormat) Format_BigDecimal_Format_StringBuf_FieldPosition__Format_StringBuf(number *BigDecimal, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	Objects_RequireNonNull_O__O(number.Ref())
	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate())
}
func (t *CompactNumberFormat) Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number *BigDecimal, result Format_StringBuf, delegate Format_FieldDelegate) Format_StringBuf {


	var isNegative bool = NN(number).Signum__I() == -1
	if isNegative { number = NN(number).Negate__BigDecimal() }
	number = NN(number).SetScale_I_RoundingMode__BigDecimal(t.GetMinimumFractionDigits__I(), t.GetRoundingMode__RoundingMode())
	var compactDataIndex int32 = 0
	if NN(NN(number).ToBigInteger__BigInteger()).BitLength__I() < 64 {
		var longNumber int64 = NN(NN(number).ToBigInteger__BigInteger()).LongValue__J()
		compactDataIndex = t.SelectCompactPattern_J__I(longNumber) } else {
			compactDataIndex = t.SelectCompactPattern_BigInteger__I(NN(number).ToBigInteger__BigInteger()) }
	if !(compactDataIndex == -1) {
		var divisor Number_I = Number_Cast(t.F_divisors.Get_I__O(compactDataIndex)); var val float64 = t.GetNumberValue_D_D__D(NN(number).DoubleValue__D(), divisor.DoubleValue__D())

		if t.CheckIncrement_D_I_D__Z(val, compactDataIndex, divisor.DoubleValue__D()) {
			var tmp1 List = t.F_divisors; var tmp2 int32


			compactDataIndex = compactDataIndex + 1; tmp2 = compactDataIndex
//line :298:1
			divisor = Number_Cast(tmp1.Get_I__O(tmp2))
		}


		number = NN(number).Divide_BigDecimal_RoundingMode__BigDecimal(BigDecimal_New_String(divisor.ToString__String()), t.GetRoundingMode__RoundingMode())

		var tmp3 *DecimalFormat = t.F_decimalFormat; NN(tmp3).SetDigitList_Number_Z_I__V(Up_BigDecimal_Number(number), isNegative, t.GetMaximumFractionDigits__I())
		val = NN(NN(t.F_decimalFormat).GetDigitList__DigitList()).GetDouble__D()
		var prefix *String = t.GetAffix_Z_Z_Z_I_D__String(false, true, isNegative, compactDataIndex, val); var suffix *String = t.GetAffix_Z_Z_Z_I_D__String(false, false, isNegative, compactDataIndex, val); var tmp4 bool; var tmp5 bool

		tmp5 = !NN(prefix).IsEmpty__Z(); if !tmp5 { tmp5 = !NN(suffix).IsEmpty__Z() }; tmp4 = tmp5; if tmp4 {

			t.AppendPrefix_Format_StringBuf_String_Format_FieldDelegate__V(result, prefix, delegate)
			if NN(NN(CompactNumberFormat_Patterns_Cast(t.F_placeHolderPatterns.Get_I__O(compactDataIndex))).Get_D__String(val)).IsEmpty__Z() { } else {



				var tmp6 *DecimalFormat = t.F_decimalFormat; NN(tmp6).SubformatNumber_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__V(result, delegate, isNegative, false, t.GetMaximumIntegerDigits__I(), t.GetMinimumIntegerDigits__I(), t.GetMaximumFractionDigits__I(), t.GetMinimumFractionDigits__I())








				t.AppendSuffix_Format_StringBuf_String_Format_FieldDelegate__V(result, suffix, delegate) } } else {

					var tmp7 *BigDecimal; if isNegative { tmp7 = NN(number).Negate__BigDecimal() } else { tmp7 = number }; number = tmp7
					NN(t.F_defaultDecimalFormat).Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, delegate) } } else {

						var tmp8 *BigDecimal; if isNegative { tmp8 = NN(number).Negate__BigDecimal() } else { tmp8 = number }; number = tmp8
						NN(t.F_defaultDecimalFormat).Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(number, result, delegate) }
//line :289:1
	return result
}










































func (t *CompactNumberFormat) Format_BigInteger_Format_StringBuf_FieldPosition__Format_StringBuf(number *BigInteger, result Format_StringBuf, fieldPosition FieldPosition_I) Format_StringBuf {

	Objects_RequireNonNull_O__O(number.Ref())
	fieldPosition.SetBeginIndex_I__V(0)
	fieldPosition.SetEndIndex_I__V(0)
	return t.Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number, result, fieldPosition.GetFieldDelegate__Format_FieldDelegate(), false)
}
func (t *CompactNumberFormat) Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number *BigInteger, result Format_StringBuf, delegate Format_FieldDelegate, formatLong bool) Format_StringBuf {


	var isNegative bool = NN(number).Signum__I() == -1
	if isNegative { number = NN(number).Negate__BigInteger() }
	var compactDataIndex int32 = t.SelectCompactPattern_BigInteger__I(number)
	if !(compactDataIndex == -1) {
		var divisor Number_I = Number_Cast(t.F_divisors.Get_I__O(compactDataIndex)); var val float64 = t.GetNumberValue_D_D__D(NN(number).DoubleValue__D(), divisor.DoubleValue__D())

		if t.CheckIncrement_D_I_D__Z(val, compactDataIndex, divisor.DoubleValue__D()) {
			var tmp1 List = t.F_divisors; var tmp2 int32


			compactDataIndex = compactDataIndex + 1; tmp2 = compactDataIndex
//line :350:1
			divisor = Number_Cast(tmp1.Get_I__O(tmp2))
		}


		var noFraction bool; var tmp3 *BigInteger = NN(number).Mod_BigInteger__BigInteger(BigInteger_New_String(divisor.ToString__String())); var tmp4 *BigInteger; BigInteger_Init(); tmp4 = BigInteger_ZERO; noFraction = NN(tmp3).CompareTo_BigInteger__I(tmp4) == 0


		if noFraction {

			number = NN(number).Divide_BigInteger__BigInteger(BigInteger_New_String(divisor.ToString__String()))
			NN(t.F_decimalFormat).SetDigitList_Number_Z_I__V(Up_BigInteger_Number(number), isNegative, 0) } else {
				var nDecimal *BigDecimal = BigDecimal_New_BigInteger(number).Divide_BigDecimal_RoundingMode__BigDecimal(BigDecimal_New_String(divisor.ToString__String()), t.GetRoundingMode__RoundingMode()); var tmp5 *DecimalFormat = t.F_decimalFormat


				NN(tmp5).SetDigitList_Number_Z_I__V(Up_BigDecimal_Number(nDecimal), isNegative, t.GetMaximumFractionDigits__I())
			}


		val = NN(NN(t.F_decimalFormat).GetDigitList__DigitList()).GetDouble__D()
		var prefix *String = t.GetAffix_Z_Z_Z_I_D__String(false, true, isNegative, compactDataIndex, val); var suffix *String = t.GetAffix_Z_Z_Z_I_D__String(false, false, isNegative, compactDataIndex, val); var tmp6 bool; var tmp7 bool

		tmp7 = !NN(prefix).IsEmpty__Z(); if !tmp7 { tmp7 = !NN(suffix).IsEmpty__Z() }; tmp6 = tmp7; if tmp6 {

			t.AppendPrefix_Format_StringBuf_String_Format_FieldDelegate__V(result, prefix, delegate)
			if NN(NN(CompactNumberFormat_Patterns_Cast(t.F_placeHolderPatterns.Get_I__O(compactDataIndex))).Get_D__String(val)).IsEmpty__Z() { } else {




				var tmp8 *DecimalFormat = t.F_decimalFormat; NN(tmp8).SubformatNumber_Format_StringBuf_Format_FieldDelegate_Z_Z_I_I_I_I__V(result, delegate, isNegative, noFraction, t.GetMaximumIntegerDigits__I(), t.GetMinimumIntegerDigits__I(), t.GetMaximumFractionDigits__I(), t.GetMinimumFractionDigits__I())








				t.AppendSuffix_Format_StringBuf_String_Format_FieldDelegate__V(result, suffix, delegate) } } else {

					var tmp9 *BigInteger; if isNegative { tmp9 = NN(number).Negate__BigInteger() } else { tmp9 = number }; number = tmp9
					NN(t.F_defaultDecimalFormat).Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number, result, delegate, formatLong) } } else {

						var tmp10 *BigInteger; if isNegative { tmp10 = NN(number).Negate__BigInteger() } else { tmp10 = number }; number = tmp10
						NN(t.F_defaultDecimalFormat).Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(number, result, delegate, formatLong) }
//line :345:1
	return result
}


















































func (t *CompactNumberFormat) GetAffix_Z_Z_Z_I_D__String(isExpanded, isPrefix, isNegative bool, compactDataIndex int32, val float64) *String {

	var tmp1 List
	if isExpanded {

		if isPrefix {
			if isNegative { tmp1 = t.F_negativePrefixes } else { tmp1 = t.F_positivePrefixes } } else {
//line :402:1
				if isNegative { tmp1 = t.F_negativeSuffixes } else { tmp1 = t.F_positiveSuffixes } } } else {
//line :400:1
					if isPrefix {





						if isNegative { tmp1 = t.F_negativePrefixPatterns } else { tmp1 = t.F_positivePrefixPatterns } } else {
//line :400:1
							if isNegative { tmp1 = t.F_negativeSuffixPatterns } else { tmp1 = t.F_positiveSuffixPatterns } } }
//line :399:1
	return NN(CompactNumberFormat_Patterns_Cast(tmp1.Get_I__O(compactDataIndex))).Get_D__String(val)
}











func (t *CompactNumberFormat) AppendPrefix_Format_StringBuf_String_Format_FieldDelegate__V(result Format_StringBuf, prefix *String, delegate Format_FieldDelegate) {

	var tmp1 *String = t.ExpandAffix_String__String(prefix); var tmp2 *NumberFormat_Field; NumberFormat_Field_Init(); tmp2 = NumberFormat_Field_PREFIX; t.Append_Format_StringBuf_String_Format_FieldDelegate_List__V(result, tmp1, delegate, t.GetFieldPositions_String_NumberFormat_Field__List(prefix, tmp2))
}




func (t *CompactNumberFormat) AppendSuffix_Format_StringBuf_String_Format_FieldDelegate__V(result Format_StringBuf, suffix *String, delegate Format_FieldDelegate) {

	var tmp1 *String = t.ExpandAffix_String__String(suffix); var tmp2 *NumberFormat_Field; NumberFormat_Field_Init(); tmp2 = NumberFormat_Field_SUFFIX; t.Append_Format_StringBuf_String_Format_FieldDelegate_List__V(result, tmp1, delegate, t.GetFieldPositions_String_NumberFormat_Field__List(suffix, tmp2))
}




func (t *CompactNumberFormat) Append_Format_StringBuf_String_Format_FieldDelegate_List__V(result Format_StringBuf, string_ *String, delegate Format_FieldDelegate, positions List) {


	if NN(string_).IsEmpty__Z() { } else {
		var start int32 = result.Length__I()
		result.Append_String__Format_StringBuf(string_)
		var i_101285 Iterator = positions.Iterator__Iterator(); for i_101285.HasNext__Z() { var fp FieldPosition_I = FieldPosition_Cast(i_101285.Next__O()); var attribute Format_Field_I = fp.GetFieldAttribute__Format_Field()

			delegate.Formatted_Format_Field_O_I_I_Format_StringBuf__V(attribute, attribute, start+fp.GetBeginIndex__I(), start+fp.GetEndIndex__I(), result)
		}
	}
}



func (t *CompactNumberFormat) ExpandAffix_String__String(pattern *String) *String {
	if NN(pattern).IndexOf_I__I(39) < 0 { return pattern } else {

		var sb *StringBuilder = StringBuilder_New()
		var index int32 = 0
	L1: for { if index < NN(pattern).Length__I() {
		var ch uint16; var tmp1 int32
		var old_1 int32 = index
		index = index + 1
//line :450:1
		tmp1 = old_1
//line :449:1
		ch = NN(pattern).CharAt_I__C(tmp1)



		if int32(ch) == 39 {
			ch = NN(pattern).CharAt_I__C(index)
			index = index + 1
			if int32(ch) == 45 { NN(sb).Append_String__StringBuilder(NN(t.F_symbols).GetMinusSignText__String()); continue L1 } }
		NN(sb).Append_C__StringBuilder(ch)
//line :448:1
		continue L1 }; break L1
	}








		return NN(sb).ToString__String()
	} }
func (t *CompactNumberFormat) GetFieldPositions_String_NumberFormat_Field__List(pattern *String, field *NumberFormat_Field) List {

	var positions List = ArrayList_New(); var affix *StringBuilder = StringBuilder_New()
	var stringIndex int32 = 0
	var index int32 = 0

L1: for { if index < NN(pattern).Length__I() {
	var ch uint16; var tmp1 int32
	var old_2 int32 = index
	index = index + 1
//line :468:1
	tmp1 = old_2
//line :467:1
	ch = NN(pattern).CharAt_I__C(tmp1)



	if int32(ch) == 39 {
		ch = NN(pattern).CharAt_I__C(index)
		index = index + 1
		if int32(ch) == 45 {
			var minusText *String = NN(t.F_symbols).GetMinusSignText__String(); var fp FieldPosition_I; var tmp2 *NumberFormat_Field
			NumberFormat_Field_Init(); tmp2 = NumberFormat_Field_SIGN; fp = FieldPosition_New_Format_Field(Up_NumberFormat_Field_Format_Field(tmp2))
			fp.SetBeginIndex_I__V(stringIndex)
			fp.SetEndIndex_I__V(stringIndex + NN(minusText).Length__I())
			positions.Add_O__Z(fp)
			stringIndex = stringIndex + NN(minusText).Length__I()
			NN(affix).Append_String__StringBuilder(minusText)
			continue L1 } }
	stringIndex = stringIndex + 1
	NN(affix).Append_C__StringBuilder(ch)
//line :466:1
	continue L1 }; break L1
}

















	if NN(affix).Length__I() == 0 { } else {
		var fp_2 FieldPosition_I = FieldPosition_New_Format_Field(Up_NumberFormat_Field_Format_Field(field))
		fp_2.SetBeginIndex_I__V(0)
		fp_2.SetEndIndex_I__V(NN(affix).Length__I())
		positions.Add_O__Z(fp_2) }
//line :462:1
	return positions
}




























func (t *CompactNumberFormat) SelectCompactPattern_J__I(number int64) int32 {
	if int32(len(t.F_compactPatterns.A)) == 0 { return -1 } else {

		var dataIndex int32; if number <= 1 { dataIndex = 0 } else { dataIndex = D2I(Math_Log10_D__D(float64(number))) }
		dataIndex = Math_Min_I_I__I(dataIndex, int32(len(t.F_compactPatterns.A))-1)
//line :495:1
		return dataIndex
	}
}

func (t *CompactNumberFormat) SelectCompactPattern_BigInteger__I(number *BigInteger) int32 {
	var matchedIndex int32 = -1
	if int32(len(t.F_compactPatterns.A)) == 0 { return matchedIndex } else {

		var currentValue *BigInteger; BigInteger_Init(); currentValue = BigInteger_ONE
		var index int32 = 0; L1: for {
			if index < int32(len(t.F_compactPatterns.A)) {
				if NN(number).CompareTo_BigInteger__I(currentValue) > 0 {

					matchedIndex = index
					currentValue = NN(currentValue).Multiply_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(10))

					index = index + 1; continue L1 } else {
						if NN(number).CompareTo_BigInteger__I(currentValue) < 0 { } else { matchedIndex = index } } }
//line :504:1
			break L1 }
//line :503:1
		return matchedIndex
	}
}










func (t *CompactNumberFormat) FormatToCharacterIterator_O__AttributedCharacterIterator(obj any) AttributedCharacterIterator {
	var delegate *CharacterIteratorFieldDelegate = CharacterIteratorFieldDelegate_New(); var sb Format_StringBuf = StringBufFactory_Of__Format_StringBuf()
	var tmp1 any = obj
L1: switch { default: if tmp1 == nil {











	panic(Thrown(NullPointerException_New_String(Lit_1737))) }
//line :519:1
	if Double_InstanceOf(tmp1) { var d *Double = Double_Cast(tmp1)
		t.Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(d).DoubleValue__D(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
		break L1 }; if Float_InstanceOf(tmp1) { var f *Float = Float_Cast(tmp1)

			t.Format_D_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(f).DoubleValue__D(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
			break L1 }; if Long_InstanceOf(tmp1) { var l *Long = Long_Cast(tmp1)


				t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(l).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
				break L1 }; if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1)



					t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(i).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
					break L1 }; if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1)




						t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(s).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
						break L1 }; if Byte_InstanceOf(tmp1) { var b *Byte = Byte_Cast(tmp1)





							t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(b).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
							break L1 }; if AtomicInteger_InstanceOf(tmp1) { var ai *AtomicInteger = AtomicInteger_Cast(tmp1)






								t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(ai).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
								break L1 }; if AtomicLong_InstanceOf(tmp1) { var al *AtomicLong = AtomicLong_Cast(tmp1)







									t.Format_J_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(NN(al).LongValue__J(), sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
									break L1 }; if BigDecimal_InstanceOf(tmp1) { var bd *BigDecimal = BigDecimal_Cast(tmp1)








										t.Format_BigDecimal_Format_StringBuf_Format_FieldDelegate__Format_StringBuf(bd, sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate))
//line :519:1
										break L1 }; if BigInteger_InstanceOf(tmp1) { var bi *BigInteger = BigInteger_Cast(tmp1)









											t.Format_BigInteger_Format_StringBuf_Format_FieldDelegate_Z__Format_StringBuf(bi, sb, Up_CharacterIteratorFieldDelegate_Format_FieldDelegate(delegate), false)
//line :519:1
											break L1
										}











	panic(Thrown(IllegalArgumentException_New_String(Lit_1736)))}
	return NN(delegate).GetIterator_String__AttributedCharacterIterator(sb.ToString__String())
}
func (t *CompactNumberFormat) ComputeDivisor_String_I__Number(minIntDigits *String, patternIndex int32) Number_I {
	var count int32 = NN(minIntDigits).Length__I(); var matchedValue Number_I
	if patternIndex < 19 {
		matchedValue = Long_ValueOf_J__Long(D2L(Math_Pow_D_D__D(10.0, float64(patternIndex)))) } else {
			matchedValue = Up_BigInteger_Number(NN(BigInteger_ValueOf_J__BigInteger(10)).Pow_I__BigInteger(patternIndex)) }
	var divisor Number_I = matchedValue
	if count > 0 {
		var tmp1 Number_I = matchedValue; if BigInteger_InstanceOf(tmp1) { var bigValue *BigInteger = BigInteger_Cast(tmp1)

			if NN(bigValue).CompareTo_BigInteger__I(BigInteger_ValueOf_J__BigInteger(D2L(Math_Pow_D_D__D(10.0, float64(count-1))))) < 0 {





				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1738, As[*String](t.F_compactPatterns.A[patternIndex]), Lit_1739, StrOfInt(patternIndex)))))
			}




			divisor = Up_BigInteger_Number(NN(bigValue).Divide_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(D2L(Math_Pow_D_D__D(10.0, float64(count-1)))))) } else {




				var longValue int64 = NN(Long_Cast(matchedValue)).LongValue__J()
				if longValue < D2L(Math_Pow_D_D__D(10.0, float64(count-1))) {


					panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1738, As[*String](t.F_compactPatterns.A[patternIndex]), Lit_1739, StrOfInt(patternIndex)))))
				}




				divisor = Long_ValueOf_J__Long(longValue / D2L(Math_Pow_D_D__D(10.0, float64(count-1)))) } }
//line :540:1
	return divisor
}









































func (t *CompactNumberFormat) ProcessCompactPatterns__V() {
	var size int32 = int32(len(t.F_compactPatterns.A))
	t.F_positivePrefixPatterns = ArrayList_New_I(size)
	t.F_negativePrefixPatterns = ArrayList_New_I(size)
	t.F_positiveSuffixPatterns = ArrayList_New_I(size)
	t.F_negativeSuffixPatterns = ArrayList_New_I(size)
	t.F_divisors = ArrayList_New_I(size)
	t.F_placeHolderPatterns = ArrayList_New_I(size)
	var index int32 = 0; L1: for {
		if index < size {
			var text *String = As[*String](t.F_compactPatterns.A[index]); var tmp1 List = t.F_positivePrefixPatterns
			tmp1.Add_O__Z(CompactNumberFormat_Patterns_New_CompactNumberFormat(t))
			var tmp2 List = t.F_negativePrefixPatterns; tmp2.Add_O__Z(CompactNumberFormat_Patterns_New_CompactNumberFormat(t))
			var tmp3 List = t.F_positiveSuffixPatterns; tmp3.Add_O__Z(CompactNumberFormat_Patterns_New_CompactNumberFormat(t))
			var tmp4 List = t.F_negativeSuffixPatterns; tmp4.Add_O__Z(CompactNumberFormat_Patterns_New_CompactNumberFormat(t))
			var tmp5 List = t.F_placeHolderPatterns; tmp5.Add_O__Z(CompactNumberFormat_Patterns_New_CompactNumberFormat(t))
			var m *Matcher; if !(text == nil) { m = NN(CompactNumberFormat_PLURALS).Matcher_CharSequence__Matcher(Up_String_CharSequence(text)) } else { m = nil }
			var tmp6 bool; var tmp7 bool; tmp7 = !(m == nil); if tmp7 { tmp7 = NN(m).Matches__Z() }; tmp6 = tmp7; if tmp6 {
				var idx int32 = index; var plurals *String = NN(m).Group_String__String(Lit_1740)

				NN(NN(CompactNumberFormat_COUNT_PATTERN).Matcher_CharSequence__Matcher(Up_String_CharSequence(plurals))).Results__Stream().ForEach_Consumer__V(&Consumer_Fn{Fn: func(p0 any) { var mr MatchResult = MatchResult_Cast(p0);

					t.ApplyPattern_String_String_I__V(mr.Group_I__String(1), mr.Group_I__String(2), idx) }})
				index = index + 1; continue L1 } else {
					t.ApplyPattern_String_String_I__V(Lit_1741, text, index); index = index + 1; continue L1 } }
//line :591:1
		break L1
	}















	t.F_rulesMap = t.BuildPluralRulesMap__Map()
}
func (t *CompactNumberFormat) BuildPluralRulesMap__Map() Map {
	if NN(t.F_pluralRules).Length__I() > 2048 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1742))) }
	var tmp1 Map; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var tmp2 Stream = Arrays_Stream_O1__Stream(NN(t.F_pluralRules).Split_String__String1(Lit_1743)); var tmp3 Function
			var tmp4 /*line :614:1*/*CompactNumberFormat = t

			tmp3 = &Function_Fn{Fn: func(p0 any) any { return tmp4.ValidateRule_String__String(String_Cast(p0)).Ref() }}
//line :614:1
			tmp1 = Map_Cast(tmp2.Map_Function__Stream(tmp3).Collect_Collector__O(Collectors_ToMap_Function_Function__Collector(&Function_Fn{Fn: func(p0_2 any) any { var r *String = String_Cast(p0_2); return NN(r).ReplaceFirst_String_String__String(Lit_1744, Lit_69).Ref() }}, &Function_Fn{Fn: func(p0_3 any) any { var r_2 *String = String_Cast(p0_3); return NN(r_2).ReplaceFirst_String_String__String(Lit_1745, Lit_69).Ref() }})))
		}
		return nil }()
//line :613:1
	if tmp5 != nil { if IllegalStateException_InstanceOf(tmp5) { var ise IllegalStateException_I = IllegalStateException_Cast(tmp5)









		panic(Thrown(IllegalArgumentException_New_Throwable(ise))) } else {
//line :613:1
			panic(tmp5) } }; return tmp1
}
































func (t *CompactNumberFormat) ValidateRule_String__String(rule *String) *String {
	rule = NN(rule).Trim__String()
	var tmp1 bool; var tmp2 bool; tmp2 = !NN(rule).IsEmpty__Z(); if tmp2 { tmp2 = !NN(rule).Equals_O__Z(Lit_1746) }; tmp1 = tmp2; if tmp1 {
		var validator *Matcher = NN(CompactNumberFormat_PLURALRULES_PATTERN).Matcher_CharSequence__Matcher(Up_String_CharSequence(rule))
		if NN(validator).Matches__Z() { } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1747, rule)))) } }
//line :647:1
	return rule
}






func (t *CompactNumberFormat) ApplyPattern_String_String_I__V(count, pattern *String, index int32) {
	if pattern == nil {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1748, StrOfInt(index)))))
	}
	var start int32 = 0
	var gotNegative bool = false
	var positivePrefix /*line :659:1*/*String = Lit_69
	var positiveSuffix /*line :659:1*/*String = Lit_69
	var negativePrefix /*line :659:1*/*String = Lit_69
	var negativeSuffix /*line :659:1*/*String = Lit_69
	var zeros /*line :659:1*/*String = Lit_69
	var j int32 = 1





L1: for {
	var tmp1 bool; var tmp2 bool; tmp2 = j >= 0; if tmp2 { tmp2 = start < NN(pattern).Length__I() }; tmp1 = tmp2; if tmp1 {
		var prefix *StringBuilder = StringBuilder_New(); var suffix *StringBuilder = StringBuilder_New()
		var inQuote bool = false
		var phase int32 = 0
		var affix /*line :668:1*/*StringBuilder = prefix
		var pos int32 = start




	L2: for { if pos < NN(pattern).Length__I() {
		var ch uint16 = NN(pattern).CharAt_I__C(pos)
		switch phase { case 0, 2:


			if inQuote {
				if int32(ch) == 39 {
					var tmp3 bool; var tmp4 bool; tmp4 = pos+1 < NN(pattern).Length__I(); if tmp4 {
						tmp4 = int32(NN(pattern).CharAt_I__C(pos+1)) == 39 }
//line :681:1
					tmp3 = tmp4; if tmp3 {

						pos = pos + 1; NN(affix).Append_String__StringBuilder(Lit_1749) } else {
							inQuote = false }
					pos = pos + 1
					continue L2 } } else {
						switch int32(ch) { case 48:


							phase = 1
							pos = pos - 1
							pos = pos + 1
							continue L2; case 39:


							var tmp5 bool; var tmp6 bool; tmp6 = pos+1 < NN(pattern).Length__I(); if tmp6 {
								tmp6 = int32(NN(pattern).CharAt_I__C(pos+1)) == 39 }
//line :696:1
							tmp5 = tmp6; if tmp5 {

								pos = pos + 1; NN(affix).Append_String__StringBuilder(Lit_1749) } else {
									inQuote = true }
							pos = pos + 1
							continue L2; case 59:


							var tmp7 bool; var tmp8 bool; tmp8 = phase == 0; if !tmp8 { tmp8 = j == 0 }; tmp7 = tmp8; if tmp7 {
								panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1750, StrOfChar(ch), Lit_1751, pattern, Lit_1142))))
							}





							start = pos + 1
							pos = NN(pattern).Length__I()
							pos = pos + 1
							continue L2; case 45:


							NN(affix).Append_String__StringBuilder(Lit_1752)
							pos = pos + 1
							continue L2; case 46, 44, 35, 37, 8240, 164:






							panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1750, StrOfChar(ch), Lit_1751, pattern, Lit_1142)))); default:
						}
					}





			NN(affix).Append_C__StringBuilder(ch); case 1:

			if j == 0 {

			L3: for { if pos < NN(pattern).Length__I() {
				var negPatternChar uint16 = NN(pattern).CharAt_I__C(pos)
				if int32(negPatternChar) == 48 {
					pos = pos + 1 } else {

						pos = pos - 1
						phase = 2
						affix = suffix
						break L3 }
//line :739:1
				continue L3 }; break L3
			}





			} else {
//line :737:1
				if int32(ch) == 48 {










					zeros = Concat(zeros, Lit_1133) } else {

						phase = 2; affix = suffix; pos = pos - 1 } }
//line :747:1
		default:
		}


		pos = pos + 1
//line :674:1
		continue L2 }; break L2
	}












































































		if inQuote {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1753, pattern, Lit_1142))))
		}
		if j == 1 {

			positivePrefix = NN(prefix).ToString__String()
			positiveSuffix = NN(suffix).ToString__String()
			negativePrefix = positivePrefix
			negativeSuffix = positiveSuffix } else {

				negativePrefix = NN(prefix).ToString__String()
				negativeSuffix = NN(suffix).ToString__String()
				gotNegative = true }
		var tmp9 bool; var tmp10 bool; tmp10 = !gotNegative; if !tmp10 {
			var tmp11 bool; tmp11 = NN(negativePrefix).Equals_O__Z(positivePrefix.Ref()); if tmp11 {
				tmp11 = NN(negativeSuffix).Equals_O__Z(positiveSuffix.Ref()) }
//line :766:1
			tmp10 = tmp11 }
//line :765:1
		tmp9 = tmp10; if tmp9 {



			negativeSuffix = positiveSuffix
			negativePrefix = Concat(Lit_1752, positivePrefix)
			j = j - 1; continue L1 } else {
				j = j - 1; continue L1 } }
//line :666:1
	break L1
}









































































































	var tmp12 bool; var tmp13 bool; tmp13 = !NN(positivePrefix).IsEmpty__Z(); if !tmp13 { tmp13 = !NN(positiveSuffix).IsEmpty__Z() }; tmp12 = tmp13; if tmp12 {

		NN(CompactNumberFormat_Patterns_Cast(t.F_positivePrefixPatterns.Get_I__O(index))).Put_String_String__V(count, positivePrefix)
		NN(CompactNumberFormat_Patterns_Cast(t.F_negativePrefixPatterns.Get_I__O(index))).Put_String_String__V(count, negativePrefix)
		NN(CompactNumberFormat_Patterns_Cast(t.F_positiveSuffixPatterns.Get_I__O(index))).Put_String_String__V(count, positiveSuffix)
		NN(CompactNumberFormat_Patterns_Cast(t.F_negativeSuffixPatterns.Get_I__O(index))).Put_String_String__V(count, negativeSuffix)
		NN(CompactNumberFormat_Patterns_Cast(t.F_placeHolderPatterns.Get_I__O(index))).Put_String_String__V(count, zeros)
		if t.F_divisors.Size__I() <= index { var tmp14 List = t.F_divisors; tmp14.Add_O__Z(t.ComputeDivisor_String_I__Number(zeros, index)) } } else {

			NN(CompactNumberFormat_Patterns_Cast(t.F_positivePrefixPatterns.Get_I__O(index))).Put_String_String__V(count, Lit_69)
			NN(CompactNumberFormat_Patterns_Cast(t.F_negativePrefixPatterns.Get_I__O(index))).Put_String_String__V(count, Lit_69)
			NN(CompactNumberFormat_Patterns_Cast(t.F_positiveSuffixPatterns.Get_I__O(index))).Put_String_String__V(count, Lit_69)
			NN(CompactNumberFormat_Patterns_Cast(t.F_negativeSuffixPatterns.Get_I__O(index))).Put_String_String__V(count, Lit_69)
			NN(CompactNumberFormat_Patterns_Cast(t.F_placeHolderPatterns.Get_I__O(index))).Put_String_String__V(count, Lit_69)
			if t.F_divisors.Size__I() <= index { t.F_divisors.Add_O__Z(Long_ValueOf_J__Long(1))
			}
		}
}


































func (t *CompactNumberFormat) ExpandAffixPatterns__V() {
	t.F_positivePrefixes = ArrayList_New_I(int32(len(t.F_compactPatterns.A)))
	t.F_negativePrefixes = ArrayList_New_I(int32(len(t.F_compactPatterns.A)))
	t.F_positiveSuffixes = ArrayList_New_I(int32(len(t.F_compactPatterns.A)))
	t.F_negativeSuffixes = ArrayList_New_I(int32(len(t.F_compactPatterns.A)))
	var index int32 = 0; L1: for {
		if index < int32(len(t.F_compactPatterns.A)) {
			var tmp1 List = t.F_positivePrefixes; tmp1.Add_O__Z(NN(CompactNumberFormat_Patterns_Cast(t.F_positivePrefixPatterns.Get_I__O(index))).ExpandAffix__CompactNumberFormat_Patterns().Ref())
			var tmp2 List = t.F_negativePrefixes; tmp2.Add_O__Z(NN(CompactNumberFormat_Patterns_Cast(t.F_negativePrefixPatterns.Get_I__O(index))).ExpandAffix__CompactNumberFormat_Patterns().Ref())
			var tmp3 List = t.F_positiveSuffixes; tmp3.Add_O__Z(NN(CompactNumberFormat_Patterns_Cast(t.F_positiveSuffixPatterns.Get_I__O(index))).ExpandAffix__CompactNumberFormat_Patterns().Ref())
			var tmp4 List = t.F_negativeSuffixes; tmp4.Add_O__Z(NN(CompactNumberFormat_Patterns_Cast(t.F_negativeSuffixPatterns.Get_I__O(index))).ExpandAffix__CompactNumberFormat_Patterns().Ref())
			index = index + 1; continue L1 }
//line :830:1
		break L1
	}
}





func (t *CompactNumberFormat) Parse_String_ParsePosition__Number(text *String, pos *ParsePosition) Number_I {
	Objects_RequireNonNull_O__O(text.Ref())
	Objects_RequireNonNull_O__O(pos.Ref())
	if t.F_positivePrefixes == nil { t.ExpandAffixPatterns__V() }
	var cnfMultiplier Number_I = Long_ValueOf_J__Long(1); var tmp1 int32 = pos.F_index
	if NN(text).RegionMatches_I_String_I_I__Z(tmp1, NN(t.F_symbols).GetNaN__String(), 0, NN(NN(t.F_symbols).GetNaN__String()).Length__I()) {

		var tmp2 int32 = pos.F_index; pos.F_index = tmp2 + NN(NN(t.F_symbols).GetNaN__String()).Length__I()
//line :844:1
		return Double_ValueOf_D__Double(NaN64) } else {


			var position int32 = pos.F_index; var oldStart int32 = pos.F_index; var gotPositive bool = false; var gotNegative bool = false; var matchedPosIndex int32 = -1; var matchedNegIndex int32 = -1; var matchedPosPrefix *String = Lit_69; var matchedNegPrefix *String = Lit_69; var defaultPosPrefix *String = NN(t.F_defaultDecimalFormat).GetPositivePrefix__String(); var defaultNegPrefix *String = NN(t.F_defaultDecimalFormat).GetNegativePrefix__String(); var num float64 = t.ParseNumberPart_String_I__D(text, position)
			var compactIndex int32 = 0









		L1: for {
			if compactIndex < int32(len(t.F_compactPatterns.A)) {
				var positivePrefix *String = t.GetAffix_Z_Z_Z_I_D__String(true, true, false, compactIndex, num); var negativePrefix *String = t.GetAffix_Z_Z_Z_I_D__String(true, true, true, compactIndex, num); var match bool = t.MatchAffix_String_I_String_String_String__Z(text, position, positivePrefix, defaultPosPrefix, matchedPosPrefix)








				if match {
					matchedPosIndex = compactIndex
					matchedPosPrefix = positivePrefix
					gotPositive = true }
				match = t.MatchAffix_String_I_String_String_String__Z(text, position, negativePrefix, defaultNegPrefix, matchedNegPrefix)






				if match {

					matchedNegIndex = compactIndex
					matchedNegPrefix = negativePrefix
					gotNegative = true
					compactIndex = compactIndex + 1; continue L1 } else {
						compactIndex = compactIndex + 1; continue L1 } }
//line :858:1
			break L1
		}



























			var tmp3 bool; var tmp4 bool; tmp4 = !gotPositive; if tmp4 { tmp4 = !gotNegative }; tmp3 = tmp4; if tmp3 {
				if NN(t.F_decimalFormat).MatchAffix_String_I_String__Z(text, position, defaultPosPrefix) {
					matchedPosPrefix = defaultPosPrefix
					gotPositive = true }
				if NN(t.F_decimalFormat).MatchAffix_String_I_String__Z(text, position, defaultNegPrefix) {
					matchedNegPrefix = defaultNegPrefix
					gotNegative = true } }
			var tmp5 bool; var tmp6 bool; tmp6 = gotPositive; if tmp6 { tmp6 = gotNegative }; tmp5 = tmp6; if tmp5 {
				if NN(matchedPosPrefix).Length__I() > NN(matchedNegPrefix).Length__I() {
					gotNegative = false } else {
//line :895:1
						if NN(matchedPosPrefix).Length__I() < NN(matchedNegPrefix).Length__I() {

							gotPositive = false } } }
			var tmp7 bool; var tmp8 bool; tmp8 = gotPositive; if !tmp8 { tmp8 = gotNegative }; tmp7 = tmp8; if tmp7 {

				var tmp9 int32 = position; var tmp10 int32

				if gotPositive {
					tmp10 = NN(matchedPosPrefix).Length__I() } else {
						tmp10 = NN(matchedNegPrefix).Length__I() }
//line :900:1
				position = tmp9 + tmp10




				var matchedIndex int32; if gotPositive { matchedIndex = matchedPosIndex } else { matchedIndex = matchedNegIndex }
				if matchedIndex == -1 { } else {
					cnfMultiplier = Number_Cast(t.F_divisors.Get_I__O(matchedIndex))
					if NN(NN(CompactNumberFormat_Patterns_Cast(t.F_placeHolderPatterns.Get_I__O(matchedIndex))).Get_D__String(num)).IsEmpty__Z() {

						pos.F_index = position
						return cnfMultiplier } }
				var tmp11 *DigitList = t.F_digitList; NN(tmp11).SetRoundingMode_RoundingMode__V(t.GetRoundingMode__RoundingMode())
				var status *BooleanArray = NewBooleanArray(2)
				position = NN(NN(t.F_decimalFormat).SubparseNumber_String_I_DigitList_Z_Z_Z1__DecimalFormat_NumericPosition(text, position, t.F_digitList, false, false, status)).FullPos__I()








				if position == -1 {
					pos.F_index = oldStart; pos.F_errorIndex = oldStart; return nil } else {

						pos.F_index = position
						var multiplier Number_I; var tmp12 *String



						if gotPositive { tmp12 = matchedPosPrefix } else { tmp12 = matchedNegPrefix }
//line :927:1
						multiplier = t.ComputeParseMultiplier_String_ParsePosition_String_Z1_Z_Z_D__Number(text, pos, tmp12, status, gotPositive, gotNegative, num)










						if multiplier.LongValue__J() == -1 {
							if t.F_parseStrict { pos.F_index = oldStart }; return nil } else {

								if multiplier.LongValue__J() == 1 { } else {
									cnfMultiplier = multiplier }
								if status.A[0] {

									if status.A[1] { return Double_ValueOf_D__Double(PosInf64) } else { return Double_ValueOf_D__Double(NegInf64) } } else {
//line :943:1
										if t.IsParseBigDecimal__Z() {





											var bigDecimalResult *BigDecimal = NN(t.F_digitList).GetBigDecimal__BigDecimal()
											if cnfMultiplier.LongValue__J() == 1 { } else {
												bigDecimalResult = NN(bigDecimalResult).Multiply_BigDecimal__BigDecimal(BigDecimal_New_String(cnfMultiplier.ToString__String()))
											}


											if status.A[1] { } else {
												bigDecimalResult = NN(bigDecimalResult).Negate__BigDecimal() }
//line :949:1
											return Up_BigDecimal_Number(bigDecimalResult) } else {









												var cnfResult Number_I; var tmp13 *DigitList = t.F_digitList; var tmp14 bool = status.A[1]
												if NN(tmp13).FitsIntoLong_Z_Z__Z(tmp14, t.IsParseIntegerOnly__Z()) {



													var longResult int64 = NN(t.F_digitList).GetLong__J()
													cnfResult = t.GenerateParseResult_Number_Z_Z_Z1_Number__Number(Long_ValueOf_J__Long(longResult), false, longResult < 0, status, cnfMultiplier) } else {








														cnfResult = t.GenerateParseResult_Number_Z_Z_Z1_Number__Number(Double_ValueOf_D__Double(NN(t.F_digitList).GetDouble__D()), true, false, status, cnfMultiplier) }
//line :959:1
												return cnfResult } } } } } else {
























													pos.F_errorIndex = position; return nil
												} } }
func (t *CompactNumberFormat) ParseNumberPart_String_I__D(text *String, position int32) float64 {
	if t.F_numberPattern == nil {
		t.F_numberPattern = Pattern_Compile_String__Pattern(Concat(Lit_1754, StrOfChar(NN(t.F_symbols).GetDecimalSeparator__C()), Lit_1755))
	}
	if NN(text).StartsWith_String_I__Z(NN(t.F_symbols).GetInfinity__String(), position) { return PosInf64 } else {


		if NN(text).StartsWith_String_I__Z(NN(t.F_symbols).GetNaN__String(), position) { } else {
			var m *Matcher = NN(t.F_numberPattern).Matcher_CharSequence__Matcher(Up_String_CharSequence(text))
			if NN(m).Find_I__Z(position) {
				var digits *String = NN(m).Group__String()
				if Character_IsDigit_I__Z(NN(digits).CodePointAt_I__I(0)) {
					return Double_ParseDouble_String__D(String_Cast(NN(digits).CodePoints__IntStream().Filter_IntPredicate__IntStream(&IntPredicate_Fn{Fn: func(p0 int32) bool { var cp int32 = p0; return !(cp == int32(NN(t.F_symbols).GetDecimalSeparator__C())) }}).Map_IntUnaryOperator__IntStream(&IntUnaryOperator_Fn{Fn: func(p0_2 int32) int32 { return Character_GetNumericValue_I__I(p0_2) }}).MapToObj_IntFunction__Stream(&IntFunction_Fn{Fn: func(p0_3 int32) any { return Integer_ToString_I__String(p0_3).Ref() }}).Collect_Collector__O(Collectors_Joining__Collector()))) } } else {












						return 1.0 } }
//line :992:1
		return NaN64
	}
}



















func (t *CompactNumberFormat) GenerateParseResult_Number_Z_Z_Z1_Number__Number(number Number_I, gotDouble, gotLongMin bool, status *BooleanArray, cnfMultiplier Number_I) Number_I {


	if gotDouble {
		if cnfMultiplier.LongValue__J() == 1 { } else {
			var doubleResult float64 = float64(number.DoubleValue__D() * cnfMultiplier.DoubleValue__D())


			doubleResult = NN(Double_Cast(t.ConvertIfNegative_Number_Z1_Z__Number(Double_ValueOf_D__Double(doubleResult), status, gotLongMin))).DoubleValue__D()


			var longResult int64 = D2L(doubleResult); var tmp1 bool; var tmp2 bool

			tmp2 = !(doubleResult == float64(longResult)); if !tmp2 {
				var tmp3 bool; tmp3 = doubleResult == 0.0; if tmp3 { tmp3 = 1.0/doubleResult < 0.0 }; tmp2 = tmp3 }
//line :1027:1
			tmp1 = tmp2
//line :1026:1
			gotDouble = tmp1


			var tmp4 Number_I; if gotDouble {
				tmp4 = Up_Double_Number(Double_ValueOf_D__Double(doubleResult)) } else {
					tmp4 = Up_Long_Number(Long_ValueOf_J__Long(longResult)) }
//line :1029:1
			return tmp4
		} } else {

			if cnfMultiplier.LongValue__J() == 1 { } else {
				var result Number_I; var tmp5 bool; var tmp6 bool
				tmp6 = Long_InstanceOf(cnfMultiplier); if tmp6 { tmp6 = !gotLongMin }; tmp5 = tmp6; if tmp5 {
					var longMultiplier int64 = NN(Long_Cast(cnfMultiplier)).LongValue__J(); tmp7 := func() (exc Throwable_I) { defer Catch(&exc)

						result = Long_ValueOf_J__Long(Math_MultiplyExact_J_J__J(number.LongValue__J(), longMultiplier)); return nil }()
//line :1036:1
					if tmp7 != nil { if ArithmeticException_InstanceOf(tmp7) { var ex *ArithmeticException = ArithmeticException_Cast(tmp7); _ = ex


						result = Double_ValueOf_D__Double(float64(number.DoubleValue__D() * cnfMultiplier.DoubleValue__D())) } else {
//line :1036:1
							panic(tmp7) } } } else {




								result = Double_ValueOf_D__Double(float64(number.DoubleValue__D() * cnfMultiplier.DoubleValue__D()))
							}
				return t.ConvertIfNegative_Number_Z1_Z__Number(result, status, gotLongMin) } }
	return t.ConvertIfNegative_Number_Z1_Z__Number(number, status, gotLongMin)
}
func (t *CompactNumberFormat) ConvertIfNegative_Number_Z1_Z__Number(number Number_I, status *BooleanArray, gotLongMin bool) Number_I {

	var tmp1 bool; var tmp2 bool; tmp2 = !status.A[1]; if tmp2 { tmp2 = !gotLongMin }; tmp1 = tmp2; if tmp1 {
		if Long_InstanceOf(number) {
			return Long_ValueOf_J__Long(-NN(Long_Cast(number)).LongValue__J()) } else {
				return Double_ValueOf_D__Double(-NN(Double_Cast(number)).DoubleValue__D()) } } else {
//line :1048:1
					return number
				}
}



func (t *CompactNumberFormat) MatchAffix_String_I_String_String_String__Z(text *String, position int32, affix, defaultAffix, matchedAffix *String) bool {

	var tmp1 bool; var tmp2 bool; tmp2 = !NN(affix).IsEmpty__Z(); if tmp2 { tmp2 = !NN(affix).Equals_O__Z(defaultAffix.Ref()) }; tmp1 = tmp2; if tmp1 {
		if NN(matchedAffix).Length__I() < NN(affix).Length__I() {
			return NN(t.F_decimalFormat).MatchAffix_String_I_String__Z(text, position, affix) } }
//line :1054:1
	return false
}





func (t *CompactNumberFormat) MatchPrefixAndSuffix_String_I_String_String_String_String_String_String__Z(text *String, position int32, prefix, matchedPrefix, defaultPrefix, suffix, matchedSuffix, defaultSuffix *String) bool {



	var tmp1 bool; var tmp2 bool; tmp2 = NN(prefix).Equals_O__Z(matchedPrefix.Ref()); if !tmp2 { tmp2 = NN(matchedPrefix).Equals_O__Z(defaultPrefix.Ref()) }; tmp1 = tmp2; if tmp1 {
		if t.F_parseStrict {
			var tmp3 bool; tmp3 = t.MatchAffix_String_I_String_String_String__Z(text, position, suffix, defaultSuffix, matchedSuffix); if tmp3 {
				tmp3 = NN(text).Length__I() == position+NN(suffix).Length__I() }
//line :1067:1
			return tmp3 } else {

				return t.MatchAffix_String_I_String_String_String__Z(text, position, suffix, defaultSuffix, matchedSuffix) } } else {
//line :1065:1
					return false
				}
}




func (t *CompactNumberFormat) ComputeParseMultiplier_String_ParsePosition_String_Z1_Z_Z_D__Number(text *String, parsePosition *ParsePosition, matchedPrefix *String, status *BooleanArray, gotPositive, gotNegative bool, num float64) Number_I {



	var position int32 = parsePosition.F_index
	var gotPos bool = false
	var gotNeg bool = false
	var matchedPosIndex int32 = -1
	var matchedNegIndex int32 = -1
	var matchedPosSuffix /*line :1076:1*/*String = Lit_69
	var matchedNegSuffix /*line :1076:1*/*String = Lit_69
	var compactIndex int32 = 0





L1: for {
	if compactIndex < int32(len(t.F_compactPatterns.A)) {
		var positivePrefix *String = t.GetAffix_Z_Z_Z_I_D__String(true, true, false, compactIndex, num); var negativePrefix *String = t.GetAffix_Z_Z_Z_I_D__String(true, true, true, compactIndex, num); var positiveSuffix *String = t.GetAffix_Z_Z_Z_I_D__String(true, false, false, compactIndex, num); var negativeSuffix *String = t.GetAffix_Z_Z_Z_I_D__String(true, false, true, compactIndex, num); var match bool = t.MatchPrefixAndSuffix_String_I_String_String_String_String_String_String__Z(text, position, positivePrefix, matchedPrefix, NN(t.F_defaultDecimalFormat).GetPositivePrefix__String(), positiveSuffix, matchedPosSuffix, NN(t.F_defaultDecimalFormat).GetPositiveSuffix__String())













		if match {
			matchedPosIndex = compactIndex
			matchedPosSuffix = positiveSuffix
			gotPos = true
			if t.F_parseStrict { break L1 } }
		match = t.MatchPrefixAndSuffix_String_I_String_String_String_String_String_String__Z(text, position, negativePrefix, matchedPrefix, NN(t.F_defaultDecimalFormat).GetNegativePrefix__String(), negativeSuffix, matchedNegSuffix, NN(t.F_defaultDecimalFormat).GetNegativeSuffix__String())









		if match {

			matchedNegIndex = compactIndex
			matchedNegSuffix = negativeSuffix
			gotNeg = true
			if t.F_parseStrict { } else { compactIndex = compactIndex + 1; continue L1 } } else {
				compactIndex = compactIndex + 1; continue L1 } }
//line :1083:1
	break L1
}




































	var tmp1 bool; var tmp2 bool; tmp2 = !gotPos; if tmp2 { tmp2 = !gotNeg }; tmp1 = tmp2; if tmp1 {
		var positiveSuffix_2 *String = NN(t.F_defaultDecimalFormat).GetPositiveSuffix__String(); var negativeSuffix_2 *String = NN(t.F_defaultDecimalFormat).GetNegativeSuffix__String(); var containsPosSuffix bool = NN(t.F_decimalFormat).MatchAffix_String_I_String__Z(text, position, positiveSuffix_2); var endsWithPosSuffix bool; var tmp3 bool


		tmp3 = containsPosSuffix; if tmp3 {
			tmp3 = NN(text).Length__I() == position+NN(positiveSuffix_2).Length__I() }
//line :1125:1
		endsWithPosSuffix = tmp3


		var tmp4 bool; if t.F_parseStrict { tmp4 = endsWithPosSuffix } else { tmp4 = containsPosSuffix }; if tmp4 {
			matchedPosSuffix = positiveSuffix_2
			gotPos = true }
		var containsNegSuffix bool = NN(t.F_decimalFormat).MatchAffix_String_I_String__Z(text, position, negativeSuffix_2); var endsWithNegSuffix bool; var tmp5 bool
		tmp5 = containsNegSuffix; if tmp5 {
			tmp5 = NN(text).Length__I() == position+NN(negativeSuffix_2).Length__I() }
//line :1132:1
		endsWithNegSuffix = tmp5


		var tmp6 bool; if t.F_parseStrict { tmp6 = endsWithNegSuffix } else { tmp6 = containsNegSuffix }; if tmp6 {
			matchedNegSuffix = negativeSuffix_2
			gotNeg = true } }
	var tmp7 bool; var tmp8 bool; tmp8 = gotPos; if tmp8 { tmp8 = gotNeg }; tmp7 = tmp8; if tmp7 {
		if NN(matchedPosSuffix).Length__I() > NN(matchedNegSuffix).Length__I() {
			gotNeg = false } else {
//line :1139:1
				if NN(matchedPosSuffix).Length__I() < NN(matchedNegSuffix).Length__I() {

					gotPos = false } else {
						gotPos = gotPositive; gotNeg = gotNegative } } }
	if gotPos == gotNeg {
		parsePosition.F_errorIndex = position; return Long_ValueOf_J__Long(-1) } else {
			var cnfMultiplier Number_I
			if gotPos {

				parsePosition.F_index = position + NN(matchedPosSuffix).Length__I()

				var tmp9 Number_I
				if !(matchedPosIndex == -1) {
					tmp9 = Number_Cast(t.F_divisors.Get_I__O(matchedPosIndex)) } else {
						tmp9 = Up_Long_Number(Long_ValueOf_J__Long(1)) }
//line :1150:1
				cnfMultiplier = tmp9

			} else {


				parsePosition.F_index = position + NN(matchedNegSuffix).Length__I()

				var tmp10 Number_I
				if !(matchedNegIndex == -1) {
					tmp10 = Number_Cast(t.F_divisors.Get_I__O(matchedNegIndex)) } else {
						tmp10 = Up_Long_Number(Long_ValueOf_J__Long(1)) }
//line :1157:1
				cnfMultiplier = tmp10
			}


			status.A[1] = gotPos
//line :1145:1
			return cnfMultiplier
		}
}















































func (t *CompactNumberFormat) SetMaximumIntegerDigits_I__V(newValue int32) {
	var tmp1 *DecimalFormat = t.F_decimalFormat; NN(tmp1).SetMaximumIntegerDigits_I__V(Math_Min_I_I__I(newValue, 309))
	t.NumberFormat.Impl_SetMaximumIntegerDigits_I__V(t, NN(t.F_decimalFormat).GetMaximumIntegerDigits__I())
	if NN(t.F_decimalFormat).GetMinimumIntegerDigits__I() > NN(t.F_decimalFormat).GetMaximumIntegerDigits__I() {
		var tmp2 *DecimalFormat = t.F_decimalFormat; NN(tmp2).SetMinimumIntegerDigits_I__V(NN(t.F_decimalFormat).GetMaximumIntegerDigits__I())
		t.NumberFormat.Impl_SetMinimumIntegerDigits_I__V(t, NN(t.F_decimalFormat).GetMinimumIntegerDigits__I())
	} }
func (t *CompactNumberFormat) SetMinimumIntegerDigits_I__V(newValue int32) {
	var tmp1 *DecimalFormat = t.F_decimalFormat; NN(tmp1).SetMinimumIntegerDigits_I__V(Math_Min_I_I__I(newValue, 309))
	t.NumberFormat.Impl_SetMinimumIntegerDigits_I__V(t, NN(t.F_decimalFormat).GetMinimumIntegerDigits__I())
	if NN(t.F_decimalFormat).GetMinimumIntegerDigits__I() > NN(t.F_decimalFormat).GetMaximumIntegerDigits__I() {
		var tmp2 *DecimalFormat = t.F_decimalFormat; NN(tmp2).SetMaximumIntegerDigits_I__V(NN(t.F_decimalFormat).GetMinimumIntegerDigits__I())
		t.NumberFormat.Impl_SetMaximumIntegerDigits_I__V(t, NN(t.F_decimalFormat).GetMaximumIntegerDigits__I())
	} }
func (t *CompactNumberFormat) SetMinimumFractionDigits_I__V(newValue int32) {
	var tmp1 *DecimalFormat = t.F_decimalFormat; NN(tmp1).SetMinimumFractionDigits_I__V(Math_Min_I_I__I(newValue, 340))

	t.NumberFormat.Impl_SetMinimumFractionDigits_I__V(t, NN(t.F_decimalFormat).GetMinimumFractionDigits__I())
	if NN(t.F_decimalFormat).GetMinimumFractionDigits__I() > NN(t.F_decimalFormat).GetMaximumFractionDigits__I() {
		var tmp2 *DecimalFormat = t.F_decimalFormat; NN(tmp2).SetMaximumFractionDigits_I__V(NN(t.F_decimalFormat).GetMinimumFractionDigits__I())
		t.NumberFormat.Impl_SetMaximumFractionDigits_I__V(t, NN(t.F_decimalFormat).GetMaximumFractionDigits__I())
	} }
func (t *CompactNumberFormat) SetMaximumFractionDigits_I__V(newValue int32) {
	var tmp1 *DecimalFormat = t.F_decimalFormat; NN(tmp1).SetMaximumFractionDigits_I__V(Math_Min_I_I__I(newValue, 340))

	t.NumberFormat.Impl_SetMaximumFractionDigits_I__V(t, NN(t.F_decimalFormat).GetMaximumFractionDigits__I())
	if NN(t.F_decimalFormat).GetMinimumFractionDigits__I() > NN(t.F_decimalFormat).GetMaximumFractionDigits__I() {
		var tmp2 *DecimalFormat = t.F_decimalFormat; NN(tmp2).SetMinimumFractionDigits_I__V(NN(t.F_decimalFormat).GetMaximumFractionDigits__I())
		t.NumberFormat.Impl_SetMinimumFractionDigits_I__V(t, NN(t.F_decimalFormat).GetMinimumFractionDigits__I())
	} }
func (t *CompactNumberFormat) GetRoundingMode__RoundingMode() *RoundingMode { return t.F_roundingMode }

func (t *CompactNumberFormat) SetRoundingMode_RoundingMode__V(roundingMode *RoundingMode) {
	NN(t.F_decimalFormat).SetRoundingMode_RoundingMode__V(roundingMode)
	t.F_roundingMode = roundingMode
}
func (t *CompactNumberFormat) GetGroupingSize__I() int32 { return int32(t.F_groupingSize) }

func (t *CompactNumberFormat) SetGroupingSize_I__V(newValue int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = newValue < 0; if !tmp2 { tmp2 = newValue > 127 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1760))) }
	t.F_groupingSize = int8(newValue)
	NN(t.F_decimalFormat).SetGroupingSize_I__V(int32(t.F_groupingSize))
}
func (t *CompactNumberFormat) IsGroupingUsed__Z() bool { return t.NumberFormat.Impl_IsGroupingUsed__Z(t) }

func (t *CompactNumberFormat) SetGroupingUsed_Z__V(newValue bool) {
	NN(t.F_decimalFormat).SetGroupingUsed_Z__V(newValue)
	t.NumberFormat.Impl_SetGroupingUsed_Z__V(t, newValue)
}
func (t *CompactNumberFormat) IsParseIntegerOnly__Z() bool {
	return t.NumberFormat.Impl_IsParseIntegerOnly__Z(t)
}
func (t *CompactNumberFormat) SetParseIntegerOnly_Z__V(value bool) {
	NN(t.F_decimalFormat).SetParseIntegerOnly_Z__V(value)
	t.NumberFormat.Impl_SetParseIntegerOnly_Z__V(t, value)
}
func (t *CompactNumberFormat) IsStrict__Z() bool { return t.F_parseStrict }

func (t *CompactNumberFormat) SetStrict_Z__V(strict bool) {
	NN(t.F_decimalFormat).SetStrict_Z__V(strict)
	t.F_parseStrict = strict
}
func (t *CompactNumberFormat) IsParseBigDecimal__Z() bool { return t.F_parseBigDecimal }

func (t *CompactNumberFormat) SetParseBigDecimal_Z__V(newValue bool) {
	t.F_parseBigDecimal = newValue
}
func (t *CompactNumberFormat) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if !t.NumberFormat.Impl_Equals_O__Z(t, obj) { return false } else {



		var other *CompactNumberFormat = CompactNumberFormat_Cast(obj); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 *String = t.F_decimalPattern
		tmp7 = NN(tmp8).Equals_O__Z(other.F_decimalPattern.Ref()); if tmp7 {
			var tmp9 *DecimalFormatSymbols = t.F_symbols; tmp7 = NN(tmp9).Equals_O__Z(other.F_symbols.Ref()) }
//line :1269:1
		tmp6 = tmp7; if tmp6 {

			var tmp10 *RefArray = t.F_compactPatterns; tmp6 = Arrays_Equals_O1_O1__Z(tmp10, other.F_compactPatterns) }
//line :1269:1
		tmp5 = tmp6; if tmp5 {


			var tmp11 *RoundingMode = t.F_roundingMode; tmp5 = NN(tmp11).Equals_O__Z(other.F_roundingMode.Ref()) }
//line :1269:1
		tmp4 = tmp5; if tmp4 {



			var tmp12 *String = t.F_pluralRules; tmp4 = NN(tmp12).Equals_O__Z(other.F_pluralRules.Ref()) }
//line :1269:1
		tmp3 = tmp4; if tmp3 {




			var tmp13 int32 = int32(t.F_groupingSize); tmp3 = tmp13 == int32(other.F_groupingSize) }
//line :1269:1
		tmp2 = tmp3; if tmp2 {





			var tmp14 bool = t.F_parseBigDecimal; tmp2 = tmp14 == other.F_parseBigDecimal }
//line :1269:1
		tmp1 = tmp2; if tmp1 {






			var tmp15 bool = t.F_parseStrict; tmp1 = tmp15 == other.F_parseStrict }
//line :1269:1
		return tmp1
	}
	}
}





func (t *CompactNumberFormat) HashCode__I() int32 {
	var tmp1 int32 = 31*t.NumberFormat.Impl_HashCode__I(t) + Objects_Hash_O1__I(RefArrayOf(Object_class, t.F_decimalPattern.Ref(), t.F_symbols.Ref(), t.F_roundingMode.Ref(), t.F_pluralRules.Ref())) + Arrays_HashCode_O1__I(t.F_compactPatterns) + int32(t.F_groupingSize); return tmp1 + Boolean_HashCode_Z__I(t.F_parseBigDecimal)
}







func (t *CompactNumberFormat) ToString__String() *String {
	var tmp1 any = NN(NN(t.F_symbols).GetLocale__Locale()).GetDisplayName__String().Ref(); var tmp2 any = t.F_decimalPattern.Ref(); return Lit_1761.Formatted_O1__String(RefArrayOf(Object_class, tmp1, tmp2, Arrays_ToString_O1__String(t.F_compactPatterns).Ref()))
}




func (t *CompactNumberFormat) Clone__CompactNumberFormat() *CompactNumberFormat {
	var other *CompactNumberFormat = CompactNumberFormat_Cast(t.NumberFormat.Impl_Clone__O(t))
	other.F_compactPatterns = NN(t.F_compactPatterns).Copy()
	other.F_symbols = DecimalFormatSymbols_Cast(NN(t.F_symbols).Clone__O())
	other.F_decimalFormat = DecimalFormat_Cast(NN(t.F_decimalFormat).Clone__O())
	other.F_defaultDecimalFormat = DecimalFormat_Cast(NN(t.F_defaultDecimalFormat).Clone__O())
	other.F_digitList = DigitList_Cast(NN(t.F_digitList).Clone__O())
//line :1296:1
	return other
}









func (t *CompactNumberFormat_Patterns) Put_String_String__V(count, pattern *String) {
	t.F_patternsMap.Put_O_O__O(count.Ref(), pattern.Ref())
}
func (t *CompactNumberFormat_Patterns) Get_D__String(num float64) *String {
	var tmp1 Map = t.F_patternsMap; return String_Cast(tmp1.GetOrDefault_O_O__O(NN(t.F_this_0).GetPluralCategory_D__String(num).Ref(), String_Cast(t.F_patternsMap.GetOrDefault_O_O__O(Lit_1741, Lit_69)).Ref()))
}



func (t *CompactNumberFormat_Patterns) ExpandAffix__CompactNumberFormat_Patterns() *CompactNumberFormat_Patterns {
	var ret *CompactNumberFormat_Patterns = CompactNumberFormat_Patterns_New_CompactNumberFormat(t.F_this_0); var tmp1 Map = t.F_patternsMap
	tmp1.ForEach_BiConsumer__V(&BiConsumer_Fn{Fn: func(p0, p1 any) { var key *String = String_Cast(p0); var value *String = String_Cast(p1);

		NN(ret).Put_String_String__V(key, NN(t.F_this_0).ExpandAffix_String__String(value)) }})
//line :1317:1
	return ret
}




func (t *CompactNumberFormat) GetNumberValue_D_D__D(number, divisor float64) float64 {
	var num *BigDecimal = NN(BigDecimal_ValueOf_D__BigDecimal(number)).Divide_BigDecimal_RoundingMode__BigDecimal(BigDecimal_ValueOf_D__BigDecimal(divisor), t.F_roundingMode)
	if t.GetMaximumFractionDigits__I() > 0 { return NN(num).DoubleValue__D() } else { return float64(NN(num).IntValue__I())
	} }
func (t *CompactNumberFormat) CheckIncrement_D_I_D__Z(val float64, index int32, divisor float64) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = index < int32(len(t.F_compactPatterns.A))-1; if tmp2 {
		tmp2 = !Lit_69.Equals_O__Z(As[*String](t.F_compactPatterns.A[index]).Ref()) }
//line :1328:1
	tmp1 = tmp2; if tmp1 {

		var nextDiv float64 = Number_Cast(t.F_divisors.Get_I__O(index + 1)).DoubleValue__D()
		if divisor == nextDiv { } else {
			return Math_Log10_D__D(val) == Math_Log10_D__D(nextDiv)-Math_Log10_D__D(divisor) } }
//line :1327:1
	return false
}







func (t *CompactNumberFormat) GetPluralCategory_D__String(input float64) *String {
	if !(t.F_rulesMap == nil) {
		return String_Cast(NN(t.F_rulesMap.EntrySet__Set().Stream__Stream().Filter_Predicate__Stream(&Predicate_Fn{Fn: func(p0 any) bool { var e Map_Entry = Map_Entry_Cast(p0); return CompactNumberFormat_MatchPluralRule_String_D__Z(String_Cast(e.GetValue__O()), input) }}).Map_Function__Stream(&Function_Fn{Fn: func(p0_2 any) any { return Map_Entry_Cast(p0_2).GetKey__O() }}).FindFirst__Optional()).OrElse_O__O(Lit_1741)) } else {
//line :1337:1
			return Lit_1741
		}
}









func CompactNumberFormat_MatchPluralRule_String_D__Z(condition *String, input float64) bool { CompactNumberFormat_Init()
	return Arrays_Stream_O1__Stream(NN(condition).Split_String__String1(Lit_1762)).AnyMatch_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var and_condition *String = String_Cast(p0); return Arrays_Stream_O1__Stream(NN(and_condition).Split_String__String1(Lit_1763)).AllMatch_Predicate__Z(&Predicate_Fn{Fn: func(p0_2 any) bool { var r *String = String_Cast(p0_2); return CompactNumberFormat_RelationCheck_String_D__Z(r, input) }}) }})
}



















func CompactNumberFormat_ValOrRangeMatches_String_D__Z(valueOrRange *String, input float64) bool { CompactNumberFormat_Init()
	var m *Matcher = NN(CompactNumberFormat_VALUE_RANGE_PATTERN).Matcher_CharSequence__Matcher(Up_String_CharSequence(valueOrRange))
	if NN(m).Find__Z() {
		var value *String = NN(m).Group_String__String(Lit_1764)
		if !(value == nil) {
			return input == Double_ParseDouble_String__D(value) } else {
				var tmp1 bool; tmp1 = input >= Double_ParseDouble_String__D(NN(m).Group_String__String(Lit_1765)); if tmp1 {
					tmp1 = input <= Double_ParseDouble_String__D(NN(m).Group_String__String(Lit_1766)) }
//line :1377:1
				return tmp1 } } else {
//line :1373:1
					return false
				}
}





func CompactNumberFormat_RelationCheck_String_D__Z(relation *String, input float64) bool { CompactNumberFormat_Init()
	var expr *Matcher = NN(CompactNumberFormat_EXPR_PATTERN).Matcher_CharSequence__Matcher(Up_String_CharSequence(relation))
	if NN(expr).Find__Z() {
		var lop float64 = CompactNumberFormat_EvalLOperand_Matcher_D__D(expr, input); var rel *Matcher = NN(CompactNumberFormat_RELATION_PATTERN).Matcher_CharSequence__Matcher(Up_String_CharSequence(relation))

		if NN(rel).Find_I__Z(NN(expr).End__I()) {
			var conditions Stream = Arrays_Stream_O1__Stream(NN(NN(relation).Substring_I__String(NN(rel).End__I())).Split_String__String1(Lit_1532))
			if Objects_Equals_O_O__Z(NN(rel).Group_String__String(Lit_1767).Ref(), Lit_1768) {
				return conditions.NoneMatch_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var c *String = String_Cast(p0); return CompactNumberFormat_ValOrRangeMatches_String_D__Z(c, lop) }}) } else {


					return conditions.AnyMatch_Predicate__Z(&Predicate_Fn{Fn: func(p0_2 any) bool { var c_2 *String = String_Cast(p0_2); return CompactNumberFormat_ValOrRangeMatches_String_D__Z(c_2, lop) }}) } } }
//line :1382:1
	return false
}













func CompactNumberFormat_EvalLOperand_Matcher_D__D(expr *Matcher, input float64) float64 { CompactNumberFormat_Init()
	var ret float64 = 0.0
	if input == PosInf64 {
		ret = input } else {
			var op *String = NN(expr).Group_String__String(Lit_1769); var tmp1 bool; var tmp2 bool
			tmp2 = Objects_Equals_O_O__Z(op.Ref(), Lit_1770); if !tmp2 { tmp2 = Objects_Equals_O_O__Z(op.Ref(), Lit_1771) }; tmp1 = tmp2; if tmp1 { ret = input }
			var divop *String = NN(expr).Group_String__String(Lit_1772)
			if !(divop == nil) {
				var divisor *String = NN(expr).Group_String__String(Lit_1773); var tmp3 *String = divop; var tmp4 int32 = -1
				switch NN(tmp3).HashCode__I() { case 37: if tmp3.Equals_O__Z(Lit_1310) { tmp4 = 0 }; case 47: if tmp3.Equals_O__Z(Lit_68) { tmp4 = 1 }}; switch tmp4 { case 0:
					ret = math.Mod(ret, Double_ParseDouble_String__D(divisor)); case 1:
					ret = ret / Double_ParseDouble_String__D(divisor); default:} } }
//line :1398:1
	return ret
}












type CompactNumberFormat struct{ NumberFormat; F_compactPatterns *RefArray; F_positivePrefixPatterns, F_negativePrefixPatterns, F_positiveSuffixPatterns, F_negativeSuffixPatterns, F_divisors, F_placeHolderPatterns List; F_symbols *DecimalFormatSymbols; F_decimalPattern *String; F_decimalFormat, F_defaultDecimalFormat *DecimalFormat; F_groupingSize int8; F_parseBigDecimal bool; F_roundingMode *RoundingMode; F_pluralRules *String; F_parseStrict bool; F_rulesMap Map; F_numberPattern *Pattern; F_digitList *DigitList; F_positivePrefixes, F_negativePrefixes, F_positiveSuffixes, F_negativeSuffixes List }

const CompactNumberFormat_serialVersionUID int64 = 7128367218649234678

var CompactNumberFormat_SPECIAL_PATTERN *String = Lit_1133

const CompactNumberFormat_RANGE_MULTIPLIER int32 = 10

var CompactNumberFormat_PLURALS *Pattern

var CompactNumberFormat_COUNT_PATTERN *Pattern

var CompactNumberFormat_EXPR *String = Lit_1756

var CompactNumberFormat_RELATION *String = Lit_1757

var CompactNumberFormat_VALUE_RANGE *String = Lit_1758

var CompactNumberFormat_CONDITION *String = Lit_1759

var CompactNumberFormat_PLURALRULES_PATTERN *Pattern

const CompactNumberFormat_STATUS_INFINITE int32 = 0

const CompactNumberFormat_STATUS_POSITIVE int32 = 1

const CompactNumberFormat_STATUS_LENGTH int32 = 2

const CompactNumberFormat_ZERO_DIGIT uint16 = 48

const CompactNumberFormat_DIGIT uint16 = 35

const CompactNumberFormat_DECIMAL_SEPARATOR uint16 = 46

const CompactNumberFormat_GROUPING_SEPARATOR uint16 = 44

const CompactNumberFormat_MINUS_SIGN uint16 = 45

const CompactNumberFormat_PERCENT uint16 = 37

const CompactNumberFormat_PER_MILLE uint16 = 8240

const CompactNumberFormat_SEPARATOR uint16 = 59

const CompactNumberFormat_CURRENCY_SIGN uint16 = 164

const CompactNumberFormat_QUOTE uint16 = 39

var CompactNumberFormat_NAMED_EXPR *String = Lit_1727

var CompactNumberFormat_NAMED_RELATION *String = Lit_1728

var CompactNumberFormat_NAMED_VALUE_RANGE *String = Lit_1729

var CompactNumberFormat_EXPR_PATTERN *Pattern

var CompactNumberFormat_RELATION_PATTERN *Pattern

var CompactNumberFormat_VALUE_RANGE_PATTERN *Pattern

var CompactNumberFormat_init ClassInit

func CompactNumberFormat_Init() { if !CompactNumberFormat_init.Done() { CompactNumberFormat_init.Run(CompactNumberFormat_clinit) } }

func CompactNumberFormat_clinit() { CompactNumberFormat_PLURALS = Pattern_Compile_String__Pattern(Lit_1724); CompactNumberFormat_COUNT_PATTERN = Pattern_Compile_String__Pattern(Lit_1725); CompactNumberFormat_PLURALRULES_PATTERN = Pattern_Compile_String__Pattern(Lit_1726); CompactNumberFormat_EXPR_PATTERN = Pattern_Compile_String__Pattern(Lit_1727); CompactNumberFormat_RELATION_PATTERN = Pattern_Compile_String__Pattern(Lit_1728); CompactNumberFormat_VALUE_RANGE_PATTERN = Pattern_Compile_String__Pattern(Lit_1729) }

func (t *CompactNumberFormat) Clone__O() any { return t.Clone__CompactNumberFormat().Ref() }

func (t *CompactNumberFormat) Format_O__String(p0 any) *String { return t.Impl_Format_O__String(t, p0) }

func (t *CompactNumberFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(t, p0) }

func (t *CompactNumberFormat) GetMaximumFractionDigits__I() int32 { return t.Impl_GetMaximumFractionDigits__I(t) }

func (t *CompactNumberFormat) GetMaximumIntegerDigits__I() int32 { return t.Impl_GetMaximumIntegerDigits__I(t) }

func (t *CompactNumberFormat) Format_D__String(p0 float64) *String { return t.Impl_Format_D__String(t, p0) }

func (t *CompactNumberFormat) ParseObject_String__O(p0 *String) any { return t.Impl_ParseObject_String__O(t, p0) }

func (t *CompactNumberFormat) GetCurrency__Currency() *Currency { return t.Impl_GetCurrency__Currency(t) }

func (t *CompactNumberFormat) GetMinimumIntegerDigits__I() int32 { return t.Impl_GetMinimumIntegerDigits__I(t) }

func (t *CompactNumberFormat) FastFormat_D__String(p0 float64) *String { return t.Impl_FastFormat_D__String(t, p0) }

func (t *CompactNumberFormat) SetCurrency_Currency__V(p0 *Currency) { t.Impl_SetCurrency_Currency__V(t, p0) }

func (t *CompactNumberFormat) ParseObject_String_ParsePosition__O(p0 *String, p1 *ParsePosition) any { return t.Impl_ParseObject_String_ParsePosition__O(t, p0, p1) }

func (t *CompactNumberFormat) Parse_String__Number(p0 *String) Number_I { return t.Impl_Parse_String__Number(t, p0) }

func (t *CompactNumberFormat) Format_J__String(p0 int64) *String { return t.Impl_Format_J__String(t, p0) }

func (t *CompactNumberFormat) CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *CompactNumberFormat) CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(t, p0) }

func (t *CompactNumberFormat) GetMinimumFractionDigits__I() int32 { return t.Impl_GetMinimumFractionDigits__I(t) }

func (t *CompactNumberFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *CompactNumberFormat) Ref() any { if t == nil { return nil }; return t }

func (t *CompactNumberFormat) GetClass__Class() *Class { return CompactNumberFormat_class }

func (t *CompactNumberFormat) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func CompactNumberFormat_InstanceOf(x any) bool { _, ok := x.(*CompactNumberFormat); return ok }

func CompactNumberFormat_Cast(x any) *CompactNumberFormat { if x == nil { return nil }; v, ok := x.(*CompactNumberFormat); if !ok { panic(ClassCast(x, CompactNumberFormat_class)) }; return v }



type CompactNumberFormat_Patterns struct{ Object; F_patternsMap Map; F_this_0 *CompactNumberFormat }

func CompactNumberFormat_Patterns_New_CompactNumberFormat(p0 *CompactNumberFormat) *CompactNumberFormat_Patterns { t := &CompactNumberFormat_Patterns{}; t.Ctor_CompactNumberFormat(p0); return t }

func (t *CompactNumberFormat_Patterns) Ctor_CompactNumberFormat(this_0 *CompactNumberFormat) { NN(this_0); t.F_this_0 = this_0; t.F_patternsMap = HashMap_New() }

func (t *CompactNumberFormat_Patterns) Ref() any { if t == nil { return nil }; return t }

func (t *CompactNumberFormat_Patterns) GetClass__Class() *Class { return CompactNumberFormat_Patterns_class }

func (t *CompactNumberFormat_Patterns) ToString__String() *String { return Object_toString(t) }

func (t *CompactNumberFormat_Patterns) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CompactNumberFormat_Patterns) CloneShallow() any { panic(CloneNotSupported(t)) }

func CompactNumberFormat_Patterns_InstanceOf(x any) bool { _, ok := x.(*CompactNumberFormat_Patterns); return ok }

func CompactNumberFormat_Patterns_Cast(x any) *CompactNumberFormat_Patterns { if x == nil { return nil }; v, ok := x.(*CompactNumberFormat_Patterns); if !ok { panic(ClassCast(x, CompactNumberFormat_Patterns_class)) }; return v }
