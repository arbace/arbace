//line java_time_chrono_ChronoZonedDateTime.ae:1
package jrt
























func ChronoZonedDateTime_TimeLineOrder__Comparator() Comparator {
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var dateTime1 ChronoZonedDateTime = ChronoZonedDateTime_Cast(p0); var dateTime2 ChronoZonedDateTime = ChronoZonedDateTime_Cast(p1); var tmp1 int32; var cmp int32 = Long_Compare_J_J__I(dateTime1.ToEpochSecond__J(), dateTime2.ToEpochSecond__J()); if






		cmp == 0 {
			cmp = Long_Compare_J_J__I(int64(NN(dateTime1.ToLocalTime__LocalTime()).GetNano__I()), int64(NN(dateTime2.ToLocalTime__LocalTime()).GetNano__I())) }; tmp1 = cmp; return tmp1 },
	},
	),
	)
}
func ChronoZonedDateTime_From_TemporalAccessor__ChronoZonedDateTime(temporal TemporalAccessor) ChronoZonedDateTime {
	if ChronoZonedDateTime_InstanceOf(temporal) {
		return ChronoZonedDateTime_Cast(temporal) } else {

			Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
			var chrono Chronology = Chronology_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery()))
			if chrono == nil {
				panic(Thrown(DateTimeException_New_String(Concat(Lit_2199, StrOfObj(temporal.GetClass__Class().Ref())))))
			}

			return chrono.ZonedDateTime_TemporalAccessor__ChronoZonedDateTime(temporal)
		} }
func ChronoZonedDateTime_Range_TemporalField__ValueRange(this ChronoZonedDateTime, field TemporalField) *ValueRange {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; var tmp2 bool; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_INSTANT_SECONDS; tmp2 = any(field) == any(tmp3.Ref()); if !tmp2 {
			var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_OFFSET_SECONDS; tmp2 = any(field) == any(tmp4.Ref()) }
//line :54:1
		tmp1 = tmp2; if tmp1 {

			return field.Range__ValueRange() } else {
				return this.ToLocalDateTime__ChronoLocalDateTime().Range_TemporalField__ValueRange(field) } } else {
					return field.RangeRefinedBy_TemporalAccessor__ValueRange(this)
				} }
func ChronoZonedDateTime_Get_TemporalField__I(this ChronoZonedDateTime, field TemporalField) int32 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:

			panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2078))); case 29:

			return NN(this.GetOffset__ZoneOffset()).GetTotalSeconds__I(); default:
			return this.ToLocalDateTime__ChronoLocalDateTime().Get_TemporalField__I(field)} } else {
				return TemporalAccessor_Get_TemporalField__I(this, field) } }; panic("a2g: unreachable")
}
func ChronoZonedDateTime_GetLong_TemporalField__J(this ChronoZonedDateTime, field TemporalField) int64 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:
			return this.ToEpochSecond__J(); case 29:
			return int64(NN(this.GetOffset__ZoneOffset()).GetTotalSeconds__I()); default:
			return this.ToLocalDateTime__ChronoLocalDateTime().GetLong_TemporalField__J(field)} } else {
				return field.GetFrom_TemporalAccessor__J(this) } }; panic("a2g: unreachable")
}
func ChronoZonedDateTime_ToLocalDate__ChronoLocalDate(this ChronoZonedDateTime) ChronoLocalDate {
	return this.ToLocalDateTime__ChronoLocalDateTime().ToLocalDate__ChronoLocalDate()
}
func ChronoZonedDateTime_ToLocalTime__LocalTime(this ChronoZonedDateTime) *LocalTime {
	return this.ToLocalDateTime__ChronoLocalDateTime().ToLocalTime__LocalTime()
}


func ChronoZonedDateTime_GetChronology__Chronology(this ChronoZonedDateTime) Chronology {
	return this.ToLocalDate__ChronoLocalDate().GetChronology__Chronology()
}














func ChronoZonedDateTime_IsSupported_TemporalUnit__Z(this ChronoZonedDateTime, unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_FOREVER; return !(any(unit) == any(tmp1.Ref())) } else {
			var tmp2 bool; tmp2 = !(unit == nil); if tmp2 { tmp2 = unit.IsSupportedBy_Temporal__Z(this) }; return tmp2
		} }
func ChronoZonedDateTime_With_TemporalAdjuster__ChronoZonedDateTime(this ChronoZonedDateTime, adjuster TemporalAdjuster) ChronoZonedDateTime {
	return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(ChronoZonedDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoZonedDateTimeImpl(this.GetChronology__Chronology(), Temporal_With_TemporalAdjuster__Temporal(this, adjuster)))
}


func ChronoZonedDateTime_Plus_TemporalAmount__ChronoZonedDateTime(this ChronoZonedDateTime, amount TemporalAmount) ChronoZonedDateTime {
	return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(ChronoZonedDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoZonedDateTimeImpl(this.GetChronology__Chronology(), Temporal_Plus_TemporalAmount__Temporal(this, amount)))
}


func ChronoZonedDateTime_Minus_TemporalAmount__ChronoZonedDateTime(this ChronoZonedDateTime, amount TemporalAmount) ChronoZonedDateTime {
	return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(ChronoZonedDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoZonedDateTimeImpl(this.GetChronology__Chronology(), Temporal_Minus_TemporalAmount__Temporal(this, amount)))
}
func ChronoZonedDateTime_Minus_J_TemporalUnit__ChronoZonedDateTime(this ChronoZonedDateTime, amountToSubtract int64, unit TemporalUnit) ChronoZonedDateTime {

	return Up_ChronoZonedDateTimeImpl_ChronoZonedDateTime(ChronoZonedDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoZonedDateTimeImpl(this.GetChronology__Chronology(), Temporal_Minus_J_TemporalUnit__Temporal(this, amountToSubtract, unit)))
}

func ChronoZonedDateTime_Query_TemporalQuery__O(this ChronoZonedDateTime, query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool
	tmp2 = query == TemporalQueries_Zone__TemporalQuery(); if !tmp2 { tmp2 = query == TemporalQueries_ZoneId__TemporalQuery() }; tmp1 = tmp2
//line :127:1
	if tmp1 {

		return this.GetZone__ZoneId() } else {
//line :127:1
			if query == TemporalQueries_Offset__TemporalQuery() {


				return this.GetOffset__ZoneOffset().Ref() } else {
//line :127:1
					if query == TemporalQueries_LocalTime__TemporalQuery() {



						return this.ToLocalTime__LocalTime().Ref() } else {
//line :127:1
							if query == TemporalQueries_Chronology__TemporalQuery() {




								return this.GetChronology__Chronology() } else {
//line :127:1
									if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_NANOS.Ref() } else {






										return query.QueryFrom_TemporalAccessor__O(this)
									} } } } } }
func ChronoZonedDateTime_Format_DateTimeFormatter__String(this ChronoZonedDateTime, formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(this)
}
func ChronoZonedDateTime_ToInstant__Instant(this ChronoZonedDateTime) *Instant {
	return Instant_OfEpochSecond_J_J__Instant(this.ToEpochSecond__J(), int64(NN(this.ToLocalTime__LocalTime()).GetNano__I()))
}
func ChronoZonedDateTime_ToEpochSecond__J(this ChronoZonedDateTime) int64 {
	var epochDay int64 = this.ToLocalDate__ChronoLocalDate().ToEpochDay__J(); var secs int64 = epochDay*86400 + int64(NN(this.ToLocalTime__LocalTime()).ToSecondOfDay__I())


	secs = secs - int64(NN(this.GetOffset__ZoneOffset()).GetTotalSeconds__I())
//line :144:1
	return secs
}




func ChronoZonedDateTime_CompareTo_ChronoZonedDateTime__I(this, other ChronoZonedDateTime) int32 {
	var cmp int32 = Long_Compare_J_J__I(this.ToEpochSecond__J(), other.ToEpochSecond__J())
	if cmp == 0 {
		cmp = NN(this.ToLocalTime__LocalTime()).GetNano__I() - NN(other.ToLocalTime__LocalTime()).GetNano__I()


		if cmp == 0 {
			cmp = this.ToLocalDateTime__ChronoLocalDateTime().CompareTo_ChronoLocalDateTime__I(other.ToLocalDateTime__ChronoLocalDateTime())
			if cmp == 0 {
				cmp = NN(this.GetZone__ZoneId().GetId__String()).CompareTo_String__I(other.GetZone__ZoneId().GetId__String())
				if cmp == 0 { cmp = this.GetChronology__Chronology().CompareTo_Chronology__I(other.GetChronology__Chronology()) } } } }
//line :151:1
	return cmp
}










func ChronoZonedDateTime_IsBefore_ChronoZonedDateTime__Z(this, other ChronoZonedDateTime) bool {
	var thisEpochSec int64 = this.ToEpochSecond__J(); var otherEpochSec int64 = other.ToEpochSecond__J(); var tmp1 bool

	tmp1 = thisEpochSec < otherEpochSec; if !tmp1 {
		var tmp2 bool; tmp2 = thisEpochSec == otherEpochSec; if tmp2 {
			tmp2 = NN(this.ToLocalTime__LocalTime()).GetNano__I() < NN(other.ToLocalTime__LocalTime()).GetNano__I() }
//line :167:1
		tmp1 = tmp2 }
//line :166:1
	return tmp1
}


func ChronoZonedDateTime_IsAfter_ChronoZonedDateTime__Z(this, other ChronoZonedDateTime) bool {
	var thisEpochSec int64 = this.ToEpochSecond__J(); var otherEpochSec int64 = other.ToEpochSecond__J(); var tmp1 bool

	tmp1 = thisEpochSec > otherEpochSec; if !tmp1 {
		var tmp2 bool; tmp2 = thisEpochSec == otherEpochSec; if tmp2 {
			tmp2 = NN(this.ToLocalTime__LocalTime()).GetNano__I() > NN(other.ToLocalTime__LocalTime()).GetNano__I() }
//line :174:1
		tmp1 = tmp2 }
//line :173:1
	return tmp1
}


func ChronoZonedDateTime_IsEqual_ChronoZonedDateTime__Z(this, other ChronoZonedDateTime) bool {
	var tmp1 bool; tmp1 = this.ToEpochSecond__J() == other.ToEpochSecond__J(); if tmp1 {
		tmp1 = NN(this.ToLocalTime__LocalTime()).GetNano__I() == NN(other.ToLocalTime__LocalTime()).GetNano__I() }
//line :178:1
	return tmp1
}



type ChronoZonedDateTime interface{ Object_I; Temporal; Comparable; TemporalAccessor; Is_ChronoZonedDateTime(); Range_TemporalField__ValueRange(p0 TemporalField) *ValueRange; Get_TemporalField__I(p0 TemporalField) int32; GetLong_TemporalField__J(p0 TemporalField) int64; ToLocalDate__ChronoLocalDate() ChronoLocalDate; ToLocalTime__LocalTime() *LocalTime; ToLocalDateTime__ChronoLocalDateTime() ChronoLocalDateTime; GetChronology__Chronology() Chronology; GetOffset__ZoneOffset() *ZoneOffset; GetZone__ZoneId() ZoneId_I; WithEarlierOffsetAtOverlap__ChronoZonedDateTime() ChronoZonedDateTime; WithLaterOffsetAtOverlap__ChronoZonedDateTime() ChronoZonedDateTime; WithZoneSameLocal_ZoneId__ChronoZonedDateTime(p0 ZoneId_I) ChronoZonedDateTime; WithZoneSameInstant_ZoneId__ChronoZonedDateTime(p0 ZoneId_I) ChronoZonedDateTime; IsSupported_TemporalField__Z(p0 TemporalField) bool; IsSupported_TemporalUnit__Z(p0 TemporalUnit) bool; With_TemporalAdjuster__ChronoZonedDateTime(p0 TemporalAdjuster) ChronoZonedDateTime; With_TemporalField_J__ChronoZonedDateTime(p0 TemporalField, p1 int64) ChronoZonedDateTime; Plus_TemporalAmount__ChronoZonedDateTime(p0 TemporalAmount) ChronoZonedDateTime; Plus_J_TemporalUnit__ChronoZonedDateTime(p0 int64, p1 TemporalUnit) ChronoZonedDateTime; Minus_TemporalAmount__ChronoZonedDateTime(p0 TemporalAmount) ChronoZonedDateTime; Minus_J_TemporalUnit__ChronoZonedDateTime(p0 int64, p1 TemporalUnit) ChronoZonedDateTime; Query_TemporalQuery__O(p0 TemporalQuery) any; Format_DateTimeFormatter__String(p0 *DateTimeFormatter) *String; ToInstant__Instant() *Instant; ToEpochSecond__J() int64; CompareTo_ChronoZonedDateTime__I(p0 ChronoZonedDateTime) int32; IsBefore_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool; IsAfter_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool; IsEqual_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool; With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal; With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal; Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; CompareTo_O__I(p0 any) int32 }

func ChronoZonedDateTime_With_TemporalAdjuster__Temporal(this ChronoZonedDateTime, p0 TemporalAdjuster) Temporal { return this.With_TemporalAdjuster__ChronoZonedDateTime(p0) }

func ChronoZonedDateTime_With_TemporalField_J__Temporal(this ChronoZonedDateTime, p0 TemporalField, p1 int64) Temporal { return this.With_TemporalField_J__ChronoZonedDateTime(p0, p1) }

func ChronoZonedDateTime_Plus_TemporalAmount__Temporal(this ChronoZonedDateTime, p0 TemporalAmount) Temporal { return this.Plus_TemporalAmount__ChronoZonedDateTime(p0) }

func ChronoZonedDateTime_Plus_J_TemporalUnit__Temporal(this ChronoZonedDateTime, p0 int64, p1 TemporalUnit) Temporal { return this.Plus_J_TemporalUnit__ChronoZonedDateTime(p0, p1) }

func ChronoZonedDateTime_Minus_TemporalAmount__Temporal(this ChronoZonedDateTime, p0 TemporalAmount) Temporal { return this.Minus_TemporalAmount__ChronoZonedDateTime(p0) }

func ChronoZonedDateTime_Minus_J_TemporalUnit__Temporal(this ChronoZonedDateTime, p0 int64, p1 TemporalUnit) Temporal { return this.Minus_J_TemporalUnit__ChronoZonedDateTime(p0, p1) }

func ChronoZonedDateTime_CompareTo_O__I(this ChronoZonedDateTime, p0 any) int32 { return this.CompareTo_ChronoZonedDateTime__I(ChronoZonedDateTime_Cast(p0)) }

func ChronoZonedDateTime_InstanceOf(x any) bool { _, ok := x.(ChronoZonedDateTime); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoZonedDateTime_class) } }; return ok }

func ChronoZonedDateTime_Cast(x any) ChronoZonedDateTime { if x == nil { return nil }; v, ok := x.(ChronoZonedDateTime); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoZonedDateTime_class) } }; if !ok { panic(ClassCast(x, ChronoZonedDateTime_class)) }; return v }
