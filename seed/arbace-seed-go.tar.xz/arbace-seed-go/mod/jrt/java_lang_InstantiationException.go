//line java_lang_InstantiationException.ae:1
package jrt








func InstantiationException_New() *InstantiationException { t := &InstantiationException{}; t.Ctor(); return t }
//line :10:1
func (t *InstantiationException) Ctor() { t.ReflectiveOperationException.Ctor(t) }

func InstantiationException_New_String(p0 *String) *InstantiationException { t := &InstantiationException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *InstantiationException) Ctor_String(s *String) { t.ReflectiveOperationException.Ctor_String(t, s) }







type InstantiationException struct{ ReflectiveOperationException }

const InstantiationException_serialVersionUID int64 = -8441929162975509110

func (t *InstantiationException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InstantiationException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InstantiationException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InstantiationException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InstantiationException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InstantiationException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InstantiationException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InstantiationException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InstantiationException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InstantiationException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InstantiationException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InstantiationException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InstantiationException) Ref() any { if t == nil { return nil }; return t }

func (t *InstantiationException) GetClass__Class() *Class { return InstantiationException_class }

func (t *InstantiationException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InstantiationException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InstantiationException_InstanceOf(x any) bool { _, ok := x.(*InstantiationException); return ok }

func InstantiationException_Cast(x any) *InstantiationException { if x == nil { return nil }; v, ok := x.(*InstantiationException); if !ok { panic(ClassCast(x, InstantiationException_class)) }; return v }
