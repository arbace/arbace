//line java_lang_Short.ae:1
package jrt



















func Short_ToString_S__String(s int16) *String {
	return Integer_ToString_I__String(int32(s))
}
func Short_ParseShort_String_I__S(s *String, radix int32) int16 {
	var i int32 = Integer_ParseInt_String_I__I(s, radix); var tmp1 bool; var tmp2 bool
	tmp2 = i < -32768; if !tmp2 { tmp2 = i > 32767 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NumberFormatException_New_String(Concat(Lit_109, s, Lit_110, StrOfInt(radix)))))
	}
	return int16(i)
}
func Short_ParseShort_String__S(s *String) int16 {
	return Short_ParseShort_String_I__S(s, 10)
}
func Short_ValueOf_String_I__Short(s *String, radix int32) *Short {
	return Short_ValueOf_S__Short(Short_ParseShort_String_I__S(s, radix))
}
func Short_ValueOf_String__Short(s *String) *Short {
	return Short_ValueOf_String_I__Short(s, 10)
}
func (t *Short) DescribeConstable__Optional() *Optional {
	return Optional_Of_O__Optional(A2g_Missing[any]("class java.lang.constant.DynamicConstantDesc is not in the closed world"))
}




func Short_ShortCache_New() *Short_ShortCache { Short_ShortCache_Init(); t := &Short_ShortCache{}; t.Ctor(); return t }
//line :47:1
func (t *Short_ShortCache) Ctor() { panic(A2g_NotTranslated("java.lang.Short$ShortCache.<init>()V")) }























func Short_ValueOf_S__Short(s int16) *Short {
	var sAsInt int32 = int32(s); var tmp1 bool; var tmp2 bool

	tmp2 = sAsInt >= -128; if tmp2 { tmp2 = sAsInt <= 127 }; tmp1 = tmp2; if tmp1 {
		var tmp3 *RefArray; Short_ShortCache_Init(); tmp3 = Short_ShortCache_cache; return As[*Short](tmp3.A[sAsInt+128]) } else {
			return Short_New_S(s)
		} }
func Short_Decode_String__Short(nm *String) *Short {
	var i int32 = NN(Integer_Decode_String__Integer(nm)).IntValue__I(); var tmp1 bool; var tmp2 bool
	tmp2 = i < -32768; if !tmp2 { tmp2 = i > 32767 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NumberFormatException_New_String(Concat(Lit_111, StrOfInt(i), Lit_112, nm)))) }
	return Short_ValueOf_S__Short(int16(i))
}


func Short_New_S(p0 int16) *Short { Short_Init(); t := &Short{}; t.Ctor_S(p0); return t }
//line :86:1
func (t *Short) Ctor_S(value int16) { t.Number.Ctor(t)
	t.F_value = value
}
func Short_New_String(p0 *String) *Short { Short_Init(); t := &Short{}; t.Ctor_String(p0); return t }
//line :89:1
func (t *Short) Ctor_String(s *String) { t.Number.Ctor(t)
	t.F_value = Short_ParseShort_String_I__S(s, 10)
}
func (t *Short) ByteValue__B() int8 { return int8(t.F_value) }

func (t *Short) ShortValue__S() int16 { return t.F_value }


func (t *Short) IntValue__I() int32 { return int32(t.F_value) }

func (t *Short) LongValue__J() int64 { return int64(t.F_value) }

func (t *Short) FloatValue__F() float32 { return float32(t.F_value) }

func (t *Short) DoubleValue__D() float64 { return float64(t.F_value) }

func (t *Short) ToString__String() *String { return Integer_ToString_I__String(int32(t.F_value)) }

func (t *Short) HashCode__I() int32 { return Short_HashCode_S__I(t.F_value) }

func Short_HashCode_S__I(value int16) int32 { return int32(value) }

func (t *Short) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Short_InstanceOf(tmp1) { var s *Short = Short_Cast(tmp1); var tmp2 int32 = int32(t.F_value); return tmp2 == int32(NN(s).ShortValue__S()) } else { return false
	} }
func (t *Short) CompareTo_Short__I(anotherShort *Short) int32 {
	var tmp1 int16 = t.F_value; return Short_Compare_S_S__I(tmp1, anotherShort.F_value)
}
func Short_Compare_S_S__I(x, y int16) int32 {
	return int32(x) - int32(y)
}
func Short_CompareUnsigned_S_S__I(x, y int16) int32 {
	return Short_ToUnsignedInt_S__I(x) - Short_ToUnsignedInt_S__I(y)
}




func Short_ReverseBytes_S__S(i int16) int16 {
	return int16(int32(i)&65280>>8 | int32(i)<<8)
}

func Short_ToUnsignedInt_S__I(x int16) int32 {
	return int32(x) & 65535
}
func Short_ToUnsignedLong_S__J(x int16) int64 {
	return int64(x) & 65535
}


type Short struct{ Number; F_value int16 }

func (t *Short) Is_Comparable() {}

func (t *Short) Is_Constable() {}

const Short_MIN_VALUE int16 = -32768

const Short_MAX_VALUE int16 = 32767

var Short_TYPE *Class

const Short_SIZE int32 = 16

const Short_BYTES int32 = 2

const Short_serialVersionUID int64 = 7515723908773894738

var Short_init ClassInit

func Short_Init() { if !Short_init.Done() { Short_init.Run(Short_clinit) } }

func Short_clinit() { Short_TYPE = Class_GetPrimitiveClass_String__Class(Lit_1193) }

func (t *Short) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Short__I(Short_Cast(p0)) }

func (t *Short) Ref() any { if t == nil { return nil }; return t }

func (t *Short) GetClass__Class() *Class { return Short_class }

func (t *Short) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Short) CloneShallow() any { panic(CloneNotSupported(t)) }

func Short_InstanceOf(x any) bool { _, ok := x.(*Short); return ok }

func Short_Cast(x any) *Short { if x == nil { return nil }; v, ok := x.(*Short); if !ok { panic(ClassCast(x, Short_class)) }; return v }



type Short_ShortCache struct{ Object }

var Short_ShortCache_cache *RefArray

var Short_ShortCache_archivedCache *RefArray

var Short_ShortCache_init ClassInit

func Short_ShortCache_Init() { if !Short_ShortCache_init.Done() { Short_ShortCache_init.Run(Short_ShortCache_clinit) } }

func Short_ShortCache_clinit() {
//line :54:1
	var size int32 = 256
	CDS_InitializeFromArchive_Class__V(Short_ShortCache_class)
	if Short_ShortCache_archivedCache == nil {
		var c *RefArray = NewRefArray(Short_class, size)
		var value int16 = -128; var i int32 = 0
	L1: for {
		if i < size {
			var tmp1 int16
			var old_1 int16 = value

			value = int16(int32(value) + 1)
//line :63:1
			tmp1 = old_1
//line :61:1
			c.Store(i, Short_New_S(tmp1))




			i = i + 1; continue L1 }
//line :59:1
		break L1
	}






		Short_ShortCache_archivedCache = c }
	Short_ShortCache_cache = Short_ShortCache_archivedCache
	if !A2g_AssertionsDisabled && !(int32(len(Short_ShortCache_cache.A)) == size) { panic(Thrown(AssertionError_New()))
	}
}























































































































func (t *Short_ShortCache) Ref() any { if t == nil { return nil }; return t }

func (t *Short_ShortCache) GetClass__Class() *Class { return Short_ShortCache_class }

func (t *Short_ShortCache) ToString__String() *String { return Object_toString(t) }

func (t *Short_ShortCache) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Short_ShortCache) CloneShallow() any { panic(CloneNotSupported(t)) }

func Short_ShortCache_InstanceOf(x any) bool { _, ok := x.(*Short_ShortCache); return ok }

func Short_ShortCache_Cast(x any) *Short_ShortCache { if x == nil { return nil }; v, ok := x.(*Short_ShortCache); if !ok { panic(ClassCast(x, Short_ShortCache_class)) }; return v }
