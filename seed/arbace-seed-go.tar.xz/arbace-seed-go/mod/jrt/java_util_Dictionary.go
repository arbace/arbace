//line java_util_Dictionary.ae:1
package jrt






func (t *Dictionary) Ctor(this Dictionary_I) {}



type Dictionary struct{ Object }

type Dictionary_I interface{ Object_I; Self_Dictionary() *Dictionary; Size__I() int32; IsEmpty__Z() bool; Keys__Enumeration() Enumeration; Elements__Enumeration() Enumeration; Get_O__O(p0 any) any; Put_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any }

func (t *Dictionary) Self_Dictionary() *Dictionary { return t }

func Dictionary_InstanceOf(x any) bool { _, ok := x.(Dictionary_I); return ok }

func Dictionary_Cast(x any) Dictionary_I { if x == nil { return nil }; v, ok := x.(Dictionary_I); if !ok { panic(ClassCast(x, Dictionary_class)) }; return v }
