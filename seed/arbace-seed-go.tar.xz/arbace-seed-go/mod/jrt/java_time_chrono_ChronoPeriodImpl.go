//line java_time_chrono_ChronoPeriodImpl.ae:1
package jrt





































func ChronoPeriodImpl_New_Chronology_I_I_I(p0 Chronology, p1, p2, p3 int32) *ChronoPeriodImpl { ChronoPeriodImpl_Init(); t := &ChronoPeriodImpl{}; t.Ctor_Chronology_I_I_I(p0, p1, p2, p3); return t }
//line :39:1
func (t *ChronoPeriodImpl) Ctor_Chronology_I_I_I(chrono Chronology, years, months, days int32) {
	Objects_RequireNonNull_O_String__O(chrono, Lit_2196)
	t.F_chrono = chrono
	t.F_years = years
	t.F_months = months
	t.F_days = days
}
func (t *ChronoPeriodImpl) Get_TemporalUnit__J(unit TemporalUnit) int64 {
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_YEARS; if any(unit) == any(tmp1.Ref()) { return int64(t.F_years) } else { var tmp2 *ChronoUnit; ChronoUnit_Init(); tmp2 = ChronoUnit_MONTHS; if any(unit) == any(tmp2.Ref()) { return int64(t.F_months) } else { var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_DAYS; if any(unit) == any(tmp3.Ref()) { return int64(t.F_days) } else {



		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))
	} } } }
func (t *ChronoPeriodImpl) GetUnits__List() List { return ChronoPeriodImpl_SUPPORTED_UNITS }


func (t *ChronoPeriodImpl) GetChronology__Chronology() Chronology { return t.F_chrono }

func (t *ChronoPeriodImpl) IsZero__Z() bool {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_years == 0; if tmp2 { tmp2 = t.F_months == 0 }; tmp1 = tmp2; if tmp1 { tmp1 = t.F_days == 0 }; return tmp1
}
func (t *ChronoPeriodImpl) IsNegative__Z() bool {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_years < 0; if !tmp2 { tmp2 = t.F_months < 0 }; tmp1 = tmp2; if !tmp1 { tmp1 = t.F_days < 0 }; return tmp1
}
func (t *ChronoPeriodImpl) Plus_TemporalAmount__ChronoPeriod(amountToAdd TemporalAmount) ChronoPeriod {
	var amount *ChronoPeriodImpl = t.ValidateAmount_TemporalAmount__ChronoPeriodImpl(amountToAdd); var tmp1 Chronology = t.F_chrono; var tmp2 int32 = t.F_years; var tmp3 int32 = t.F_months; var tmp4 int32 = t.F_days
	return ChronoPeriodImpl_New_Chronology_I_I_I(tmp1, Math_AddExact_I_I__I(tmp2, amount.F_years), Math_AddExact_I_I__I(tmp3, amount.F_months), Math_AddExact_I_I__I(tmp4, amount.F_days))
}



func (t *ChronoPeriodImpl) Minus_TemporalAmount__ChronoPeriod(amountToSubtract TemporalAmount) ChronoPeriod {
	var amount *ChronoPeriodImpl = t.ValidateAmount_TemporalAmount__ChronoPeriodImpl(amountToSubtract); var tmp1 Chronology = t.F_chrono; var tmp2 int32 = t.F_years; var tmp3 int32 = t.F_months; var tmp4 int32 = t.F_days
	return ChronoPeriodImpl_New_Chronology_I_I_I(tmp1, Math_SubtractExact_I_I__I(tmp2, amount.F_years), Math_SubtractExact_I_I__I(tmp3, amount.F_months), Math_SubtractExact_I_I__I(tmp4, amount.F_days))
}



func (t *ChronoPeriodImpl) ValidateAmount_TemporalAmount__ChronoPeriodImpl(amount TemporalAmount) *ChronoPeriodImpl {
	Objects_RequireNonNull_O_String__O(amount, Lit_2010)
	var tmp1 TemporalAmount = amount; if ChronoPeriodImpl_InstanceOf(tmp1) { var period *ChronoPeriodImpl = ChronoPeriodImpl_Cast(tmp1); var tmp2 Chronology = t.F_chrono

		if tmp2.Equals_O__Z(NN(period).GetChronology__Chronology()) { } else {
			panic(Thrown(ClassCastException_New_String(Concat(Lit_2188, t.F_chrono.GetId__String(), Lit_2189, NN(period).GetChronology__Chronology().GetId__String())))) }
//line :81:1
		return period
	} else {






		panic(Thrown(DateTimeException_New_String(Concat(Lit_2197, StrOfObj(amount.GetClass__Class().Ref())))))
	}
}
func (t *ChronoPeriodImpl) MultipliedBy_I__ChronoPeriod(scalar int32) ChronoPeriod {
	var tmp1 bool; var tmp2 bool; tmp2 = t.IsZero__Z(); if !tmp2 { tmp2 = scalar == 1 }; tmp1 = tmp2; if tmp1 { return t } else {

		var tmp3 Chronology = t.F_chrono; return ChronoPeriodImpl_New_Chronology_I_I_I(tmp3, Math_MultiplyExact_I_I__I(t.F_years, scalar), Math_MultiplyExact_I_I__I(t.F_months, scalar), Math_MultiplyExact_I_I__I(t.F_days, scalar))
	}
}


func (t *ChronoPeriodImpl) Normalized__ChronoPeriod() ChronoPeriod {
	var monthRange int64 = t.MonthRange__J()
	if monthRange > 0 {
		var totalMonths int64 = int64(t.F_years)*monthRange + int64(t.F_months); var splitYears int64 = totalMonths / monthRange; var splitMonths int32 = int32(totalMonths % monthRange); var tmp1 bool; var tmp2 bool


		tmp2 = splitYears == int64(t.F_years); if tmp2 { tmp2 = splitMonths == t.F_months }; tmp1 = tmp2; if tmp1 { return t } else {

			var tmp3 Chronology = t.F_chrono; return ChronoPeriodImpl_New_Chronology_I_I_I(tmp3, Math_ToIntExact_J__I(splitYears), splitMonths, t.F_days) } } else {
//line :102:1
				return t
			}
}






func (t *ChronoPeriodImpl) MonthRange__J() int64 {
	var startRange *ValueRange; var tmp1 Chronology = t.F_chrono; var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; startRange = tmp1.Range_ChronoField__ValueRange(tmp2)
	var tmp3 bool; var tmp4 bool; tmp4 = NN(startRange).IsFixed__Z(); if tmp4 { tmp4 = NN(startRange).IsIntValue__Z() }; tmp3 = tmp4; if tmp3 {
		return NN(startRange).GetMaximum__J() - NN(startRange).GetMinimum__J() + 1 } else {
//line :113:1
			return -1
		}
}

func (t *ChronoPeriodImpl) AddTo_Temporal__Temporal(temporal Temporal) Temporal {
	t.ValidateChrono_TemporalAccessor__V(temporal)
	if t.F_months == 0 {
		if t.F_years == 0 { } else { var tmp1 Temporal = temporal; var tmp2 int64 = int64(t.F_years); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_YEARS; temporal = tmp1.Plus_J_TemporalUnit__Temporal(tmp2, Up_ChronoUnit_TemporalUnit(tmp3)) } } else {
			var monthRange int64 = t.MonthRange__J()
			if monthRange > 0 {
				var tmp4 Temporal = temporal; var tmp5 int64 = int64(t.F_years)*monthRange + int64(t.F_months); var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_MONTHS; temporal = tmp4.Plus_J_TemporalUnit__Temporal(tmp5, Up_ChronoUnit_TemporalUnit(tmp6)) } else {




					if t.F_years == 0 { } else { var tmp7 Temporal = temporal; var tmp8 int64 = int64(t.F_years); var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_YEARS; temporal = tmp7.Plus_J_TemporalUnit__Temporal(tmp8, Up_ChronoUnit_TemporalUnit(tmp9)) }
					var tmp10 Temporal = temporal; var tmp11 int64 = int64(t.F_months); var tmp12 *ChronoUnit; ChronoUnit_Init(); tmp12 = ChronoUnit_MONTHS; temporal = tmp10.Plus_J_TemporalUnit__Temporal(tmp11, Up_ChronoUnit_TemporalUnit(tmp12)) } }
	if t.F_days == 0 { } else { var tmp13 Temporal = temporal; var tmp14 int64 = int64(t.F_days); var tmp15 *ChronoUnit; ChronoUnit_Init(); tmp15 = ChronoUnit_DAYS; temporal = tmp13.Plus_J_TemporalUnit__Temporal(tmp14, Up_ChronoUnit_TemporalUnit(tmp15)) }
//line :117:1
	return temporal
}














func (t *ChronoPeriodImpl) SubtractFrom_Temporal__Temporal(temporal Temporal) Temporal {
	t.ValidateChrono_TemporalAccessor__V(temporal)
	if t.F_months == 0 {
		if t.F_years == 0 { } else { var tmp1 Temporal = temporal; var tmp2 int64 = int64(t.F_years); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_YEARS; temporal = tmp1.Minus_J_TemporalUnit__Temporal(tmp2, Up_ChronoUnit_TemporalUnit(tmp3)) } } else {
			var monthRange int64 = t.MonthRange__J()
			if monthRange > 0 {
				var tmp4 Temporal = temporal; var tmp5 int64 = int64(t.F_years)*monthRange + int64(t.F_months); var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_MONTHS; temporal = tmp4.Minus_J_TemporalUnit__Temporal(tmp5, Up_ChronoUnit_TemporalUnit(tmp6)) } else {




					if t.F_years == 0 { } else { var tmp7 Temporal = temporal; var tmp8 int64 = int64(t.F_years); var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_YEARS; temporal = tmp7.Minus_J_TemporalUnit__Temporal(tmp8, Up_ChronoUnit_TemporalUnit(tmp9)) }
					var tmp10 Temporal = temporal; var tmp11 int64 = int64(t.F_months); var tmp12 *ChronoUnit; ChronoUnit_Init(); tmp12 = ChronoUnit_MONTHS; temporal = tmp10.Minus_J_TemporalUnit__Temporal(tmp11, Up_ChronoUnit_TemporalUnit(tmp12)) } }
	if t.F_days == 0 { } else { var tmp13 Temporal = temporal; var tmp14 int64 = int64(t.F_days); var tmp15 *ChronoUnit; ChronoUnit_Init(); tmp15 = ChronoUnit_DAYS; temporal = tmp13.Minus_J_TemporalUnit__Temporal(tmp14, Up_ChronoUnit_TemporalUnit(tmp15)) }
//line :133:1
	return temporal
}














func (t *ChronoPeriodImpl) ValidateChrono_TemporalAccessor__V(temporal TemporalAccessor) {
	Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
	var temporalChrono Chronology = Chronology_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery())); var tmp1 bool; var tmp2 bool
	tmp2 = !(temporalChrono == nil); if tmp2 { tmp2 = t.F_chrono.Equals_O__Z(temporalChrono) == false }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2188, t.F_chrono.GetId__String(), Lit_2189, temporalChrono.GetId__String()))))
	}
}



func (t *ChronoPeriodImpl) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if ChronoPeriodImpl_InstanceOf(tmp1) { var other *ChronoPeriodImpl = ChronoPeriodImpl_Cast(tmp1); var tmp2 int32 = t.F_years
			if tmp2 == other.F_years {
				var tmp3 int32 = t.F_months; if tmp3 == other.F_months {
					var tmp4 int32 = t.F_days; if tmp4 == other.F_days { var tmp5 Chronology = t.F_chrono; return tmp5.Equals_O__Z(other.F_chrono) } else { return false } } else {
//line :164:1
						return false } } else {
//line :163:1
							return false
						} } else {
//line :162:1
							return false
						}
	}
}




func (t *ChronoPeriodImpl) HashCode__I() int32 {
	var tmp1 int32 = t.F_years; var tmp2 int32 = tmp1 + Integer_RotateLeft_I_I__I(t.F_months, 8); var tmp3 int32 = tmp2 + Integer_RotateLeft_I_I__I(t.F_days, 16); return tmp3 ^ t.F_chrono.HashCode__I()
}


func (t *ChronoPeriodImpl) ToString__String() *String {
	if t.IsZero__Z() {
		return Concat(t.GetChronology__Chronology().ToString__String(), Lit_2198) } else {
			var buf *StringBuilder = StringBuilder_New()
			NN(NN(NN(buf).Append_String__StringBuilder(t.GetChronology__Chronology().ToString__String())).Append_C__StringBuilder(32)).Append_C__StringBuilder(80)
			if t.F_years == 0 { } else { NN(NN(buf).Append_I__StringBuilder(t.F_years)).Append_C__StringBuilder(89) }
			if t.F_months == 0 { } else { NN(NN(buf).Append_I__StringBuilder(t.F_months)).Append_C__StringBuilder(77) }
			if t.F_days == 0 { } else { NN(NN(buf).Append_I__StringBuilder(t.F_days)).Append_C__StringBuilder(68) }
			return NN(buf).ToString__String()
		} }
func (t *ChronoPeriodImpl) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.chrono.ChronoPeriodImpl.writeReplace()Ljava/lang/Object;")) }











func ChronoPeriodImpl_ReadExternal_DataInput__ChronoPeriodImpl(p0 DataInput) *ChronoPeriodImpl { ChronoPeriodImpl_Init(); panic(A2g_NotTranslated("java.time.chrono.ChronoPeriodImpl.readExternal(Ljava/io/DataInput;)Ljava/time/chrono/ChronoPeriodImpl;")) }



type ChronoPeriodImpl struct{ Object; F_chrono Chronology; F_years, F_months, F_days int32 }

func (t *ChronoPeriodImpl) Is_ChronoPeriod() {}

func (t *ChronoPeriodImpl) Is_Serializable() {}

func (t *ChronoPeriodImpl) Is_TemporalAmount() {}

const ChronoPeriodImpl_serialVersionUID int64 = 57387258289

var ChronoPeriodImpl_SUPPORTED_UNITS List

var ChronoPeriodImpl_init ClassInit

func ChronoPeriodImpl_Init() { if !ChronoPeriodImpl_init.Done() { ChronoPeriodImpl_init.Run(ChronoPeriodImpl_clinit) } }

func ChronoPeriodImpl_clinit() { var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_YEARS; var tmp2 any = tmp1.Ref(); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_MONTHS; var tmp4 any = tmp3.Ref(); var tmp5 *ChronoUnit; ChronoUnit_Init(); tmp5 = ChronoUnit_DAYS; ChronoPeriodImpl_SUPPORTED_UNITS = List_Of_O_O_O__List(tmp2, tmp4, tmp5.Ref()) }

func (t *ChronoPeriodImpl) Negated__ChronoPeriod() ChronoPeriod { return ChronoPeriod_Negated__ChronoPeriod(t) }

func (t *ChronoPeriodImpl) Ref() any { if t == nil { return nil }; return t }

func (t *ChronoPeriodImpl) GetClass__Class() *Class { return ChronoPeriodImpl_class }

func (t *ChronoPeriodImpl) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ChronoPeriodImpl) CloneShallow() any { panic(CloneNotSupported(t)) }

func ChronoPeriodImpl_InstanceOf(x any) bool { _, ok := x.(*ChronoPeriodImpl); return ok }

func ChronoPeriodImpl_Cast(x any) *ChronoPeriodImpl { if x == nil { return nil }; v, ok := x.(*ChronoPeriodImpl); if !ok { panic(ClassCast(x, ChronoPeriodImpl_class)) }; return v }
