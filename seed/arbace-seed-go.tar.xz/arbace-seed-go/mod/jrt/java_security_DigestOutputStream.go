//line java_security_DigestOutputStream.ae:1
package jrt












func DigestOutputStream_New_OutputStream_MessageDigest(p0 OutputStream_I, p1 MessageDigest_I) *DigestOutputStream { t := &DigestOutputStream{}; t.Ctor_OutputStream_MessageDigest(p0, p1); return t }
//line :14:1
func (t *DigestOutputStream) Ctor_OutputStream_MessageDigest(stream OutputStream_I, digest MessageDigest_I) { t.FilterOutputStream.Ctor_OutputStream(t, stream); t.F_on = true

	t.SetMessageDigest_MessageDigest__V(digest)
}
func (t *DigestOutputStream) GetMessageDigest__MessageDigest() MessageDigest_I { return t.F_digest }

func (t *DigestOutputStream) SetMessageDigest_MessageDigest__V(digest MessageDigest_I) {
	t.F_digest = digest
}
func (t *DigestOutputStream) Write_I__V(b int32) {
	t.F_out.Write_I__V(b)
	if t.F_on { t.F_digest.Update_B__V(int8(b))
	} }
func (t *DigestOutputStream) Write_B1_I_I__V(b *ByteArray, off, len_ int32) {
	t.F_out.Write_B1_I_I__V(b, off, len_)
	if t.F_on { t.F_digest.Update_B1_I_I__V(b, off, len_)
	} }
func (t *DigestOutputStream) On_Z__V(on bool) { t.F_on = on }

func (t *DigestOutputStream) ToString__String() *String {
	return Concat(Lit_1527, t.F_digest.ToString__String())
}


type DigestOutputStream struct{ FilterOutputStream; F_on bool; F_digest MessageDigest_I }

func (t *DigestOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *DigestOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *DigestOutputStream) Close__V() { t.Impl_Close__V(t) }

func (t *DigestOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *DigestOutputStream) GetClass__Class() *Class { return DigestOutputStream_class }

func (t *DigestOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DigestOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func DigestOutputStream_InstanceOf(x any) bool { _, ok := x.(*DigestOutputStream); return ok }

func DigestOutputStream_Cast(x any) *DigestOutputStream { if x == nil { return nil }; v, ok := x.(*DigestOutputStream); if !ok { panic(ClassCast(x, DigestOutputStream_class)) }; return v }
