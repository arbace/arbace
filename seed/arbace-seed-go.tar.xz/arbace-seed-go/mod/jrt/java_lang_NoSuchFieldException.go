//line java_lang_NoSuchFieldException.ae:1
package jrt








func NoSuchFieldException_New() *NoSuchFieldException { t := &NoSuchFieldException{}; t.Ctor(); return t }
//line :10:1
func (t *NoSuchFieldException) Ctor() { t.ReflectiveOperationException.Ctor(t) }

func NoSuchFieldException_New_String(p0 *String) *NoSuchFieldException { t := &NoSuchFieldException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *NoSuchFieldException) Ctor_String(s *String) { t.ReflectiveOperationException.Ctor_String(t, s) }







type NoSuchFieldException struct{ ReflectiveOperationException }

const NoSuchFieldException_serialVersionUID int64 = -6143714805279938260

func (t *NoSuchFieldException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NoSuchFieldException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NoSuchFieldException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NoSuchFieldException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NoSuchFieldException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NoSuchFieldException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NoSuchFieldException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NoSuchFieldException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NoSuchFieldException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NoSuchFieldException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NoSuchFieldException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NoSuchFieldException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NoSuchFieldException) Ref() any { if t == nil { return nil }; return t }

func (t *NoSuchFieldException) GetClass__Class() *Class { return NoSuchFieldException_class }

func (t *NoSuchFieldException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NoSuchFieldException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NoSuchFieldException_InstanceOf(x any) bool { _, ok := x.(*NoSuchFieldException); return ok }

func NoSuchFieldException_Cast(x any) *NoSuchFieldException { if x == nil { return nil }; v, ok := x.(*NoSuchFieldException); if !ok { panic(ClassCast(x, NoSuchFieldException_class)) }; return v }
