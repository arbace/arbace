//line java_lang_ReflectiveOperationException.ae:1
package jrt








func ReflectiveOperationException_New() *ReflectiveOperationException { t := &ReflectiveOperationException{}; t.Ctor(t); return t }
//line :10:1
func (t *ReflectiveOperationException) Ctor(this ReflectiveOperationException_I) { t.Exception.Ctor(this) }

func ReflectiveOperationException_New_String(p0 *String) *ReflectiveOperationException { t := &ReflectiveOperationException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *ReflectiveOperationException) Ctor_String(this ReflectiveOperationException_I, message *String) { t.Exception.Ctor_String(this, message) }

func ReflectiveOperationException_New_String_Throwable(p0 *String, p1 Throwable_I) *ReflectiveOperationException { t := &ReflectiveOperationException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :14:1
func (t *ReflectiveOperationException) Ctor_String_Throwable(this ReflectiveOperationException_I, message *String, cause Throwable_I) { t.Exception.Ctor_String_Throwable(this, message, cause) }


func ReflectiveOperationException_New_Throwable(p0 Throwable_I) *ReflectiveOperationException { t := &ReflectiveOperationException{}; t.Ctor_Throwable(t, p0); return t }
//line :17:1
func (t *ReflectiveOperationException) Ctor_Throwable(this ReflectiveOperationException_I, cause Throwable_I) { t.Exception.Ctor_Throwable(this, cause) }










type ReflectiveOperationException struct{ Exception }

type ReflectiveOperationException_I interface{ Exception_I; Serializable; Self_ReflectiveOperationException() *ReflectiveOperationException }

func (t *ReflectiveOperationException) Self_ReflectiveOperationException() *ReflectiveOperationException { return t }

const ReflectiveOperationException_serialVersionUID int64 = 123456789

func (t *ReflectiveOperationException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ReflectiveOperationException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ReflectiveOperationException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ReflectiveOperationException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ReflectiveOperationException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ReflectiveOperationException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ReflectiveOperationException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ReflectiveOperationException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ReflectiveOperationException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ReflectiveOperationException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ReflectiveOperationException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ReflectiveOperationException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReflectiveOperationException) Ref() any { if t == nil { return nil }; return t }

func (t *ReflectiveOperationException) GetClass__Class() *Class { return ReflectiveOperationException_class }

func (t *ReflectiveOperationException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReflectiveOperationException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReflectiveOperationException_InstanceOf(x any) bool { _, ok := x.(ReflectiveOperationException_I); return ok }

func ReflectiveOperationException_Cast(x any) ReflectiveOperationException_I { if x == nil { return nil }; v, ok := x.(ReflectiveOperationException_I); if !ok { panic(ClassCast(x, ReflectiveOperationException_class)) }; return v }
