//line java_lang_Character.ae:1
package jrt























































































































































func (t *Character) DescribeConstable__Optional() *Optional {
	return Optional_Of_O__Optional(A2g_Missing[any]("class java.lang.constant.DynamicConstantDesc is not in the closed world"))
}






func Character_Subset_New_String(p0 *String) *Character_Subset { t := &Character_Subset{}; t.Ctor_String(t, p0); return t }
//line :162:1
func (t *Character_Subset) Ctor_String(this Character_Subset_I, name *String) {
	if name == nil { panic(Thrown(NullPointerException_New_String(Lit_117))) }
	t.F_name = name
}
func (t *Character_Subset) Impl_Equals_O__Z(this Character_Subset_I, obj any) bool {
	return any(this) == any(obj)
}
func (t *Character_Subset) Impl_HashCode__I(this Character_Subset_I) int32 { return IdentityHash(this) }

func (t *Character_Subset) Impl_ToString__String(this Character_Subset_I) *String { return t.F_name }









func Character_UnicodeBlock_New_String(p0 *String) *Character_UnicodeBlock { Character_UnicodeBlock_Init(); t := &Character_UnicodeBlock{}; t.Ctor_String(p0); return t }
//line :181:1
func (t *Character_UnicodeBlock) Ctor_String(idName *String) { t.Character_Subset.Ctor_String(t, idName)

	Character_UnicodeBlock_map.Put_O_O__O(idName.Ref(), t)
}
func Character_UnicodeBlock_New_String_String(p0, p1 *String) *Character_UnicodeBlock { Character_UnicodeBlock_Init(); t := &Character_UnicodeBlock{}; t.Ctor_String_String(p0, p1); return t }
//line :185:1
func (t *Character_UnicodeBlock) Ctor_String_String(idName, alias *String) { t.Ctor_String(idName)

	Character_UnicodeBlock_map.Put_O_O__O(alias.Ref(), t)
}
func Character_UnicodeBlock_New_String_String1(p0 *String, p1 *RefArray) *Character_UnicodeBlock { Character_UnicodeBlock_Init(); t := &Character_UnicodeBlock{}; t.Ctor_String_String1(p0, p1); return t }
//line :189:1
func (t *Character_UnicodeBlock) Ctor_String_String1(idName *String, aliases *RefArray) { t.Ctor_String(idName)

	var arr_101024 *RefArray = aliases; var len_101025 int32 = int32(len(arr_101024.A)); var i_101026 int32 = 0; for ; i_101026 < len_101025; i_101026++ { var alias *String = As[*String](arr_101024.A[i_101026]); Character_UnicodeBlock_map.Put_O_O__O(alias.Ref(), t)
	}
}










































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func Character_UnicodeBlock_Of_C__Character_UnicodeBlock(c uint16) *Character_UnicodeBlock { Character_UnicodeBlock_Init()
	return Character_UnicodeBlock_Of_I__Character_UnicodeBlock(int32(c))
}
func Character_UnicodeBlock_Of_I__Character_UnicodeBlock(codePoint int32) *Character_UnicodeBlock { Character_UnicodeBlock_Init()
	if Character_IsValidCodePoint_I__Z(codePoint) { } else {
		panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_114, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(codePoint))))))
	}
	var top int32 = 0
	var bottom int32 = 0
	var current int32 = 0
	bottom = 0
	top = int32(len(Character_UnicodeBlock_blockStarts.A))
	current = top / 2
L1: for { if top-bottom > 1 {
	if codePoint >= Character_UnicodeBlock_blockStarts.A[current] { bottom = current } else { top = current }
	current = (top + bottom) / 2
//line :1785:1
	continue L1 }; break L1
}

	return As[*Character_UnicodeBlock](Character_UnicodeBlock_blocks.A[current])
}
func Character_UnicodeBlock_ForName_String__Character_UnicodeBlock(blockName *String) *Character_UnicodeBlock { Character_UnicodeBlock_Init()
	var block *Character_UnicodeBlock; var tmp1 Map = Character_UnicodeBlock_map; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_US; block = Character_UnicodeBlock_Cast(tmp1.Get_O__O(NN(blockName).ToUpperCase_Locale__String(tmp2).Ref()))
	if block == nil {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_914, blockName)))) }
//line :1791:1
	return block
}










































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func Character_UnicodeScript_Of_I__Character_UnicodeScript(codePoint int32) *Character_UnicodeScript { Character_UnicodeScript_Init()
	if Character_IsValidCodePoint_I__Z(codePoint) { } else {
		panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_114, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(codePoint))))))
	}
	var type_ int32 = Character_GetType_I__I(codePoint)
	if type_ == 0 { return Character_UnicodeScript_UNKNOWN } else {

		var index int32 = Arrays_BinarySearch_I1_I__I(Character_UnicodeScript_scriptStarts, codePoint)
		if index < 0 {
			index = -index - 2 }
		return As[*Character_UnicodeScript](Character_UnicodeScript_scripts.A[index])
	} }
func Character_UnicodeScript_ForName_String__Character_UnicodeScript(scriptName *String) *Character_UnicodeScript { Character_UnicodeScript_Init()
	var tmp1 *String = scriptName; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ENGLISH; scriptName = NN(tmp1).ToUpperCase_Locale__String(tmp2)
	var sc *Character_UnicodeScript = Character_UnicodeScript_Cast(Character_UnicodeScript_aliases.Get_O__O(scriptName.Ref()))
	if !(sc == nil) { return sc } else { return Character_UnicodeScript_ValueOf_String__Character_UnicodeScript(scriptName)
	}
}



func Character_New_C(p0 uint16) *Character { Character_Init(); t := &Character{}; t.Ctor_C(p0); return t }
//line :4064:1
func (t *Character) Ctor_C(value uint16) {
	t.F_value = value
}

func Character_CharacterCache_New() *Character_CharacterCache { Character_CharacterCache_Init(); t := &Character_CharacterCache{}; t.Ctor(); return t }
//line :4068:1
func (t *Character_CharacterCache) Ctor() { panic(A2g_NotTranslated("java.lang.Character$CharacterCache.<init>()V")) }


















func Character_ValueOf_C__Character(c uint16) *Character { Character_Init()
	if int32(c) <= 127 { var tmp1 *RefArray; Character_CharacterCache_Init(); tmp1 = Character_CharacterCache_cache; return As[*Character](tmp1.A[int32(c)]) } else { return Character_New_C(c)
	} }
func (t *Character) CharValue__C() uint16 { return t.F_value }


func (t *Character) HashCode__I() int32 { return Character_HashCode_C__I(t.F_value) }

func Character_HashCode_C__I(value uint16) int32 { Character_Init(); return int32(value) }

func (t *Character) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Character_InstanceOf(tmp1) { var c *Character = Character_Cast(tmp1); var tmp2 int32 = int32(t.F_value); return tmp2 == int32(NN(c).CharValue__C()) } else { return false
	} }
func (t *Character) ToString__String() *String { return String_ValueOf_C__String(t.F_value) }

func Character_ToString_C__String(c uint16) *String { Character_Init(); return String_ValueOf_C__String(c) }

func Character_ToString_I__String(codePoint int32) *String { Character_Init()
	return String_ValueOfCodePoint_I__String(codePoint)
}
func Character_IsValidCodePoint_I__Z(codePoint int32) bool { Character_Init()
	var plane int32 = int32(uint32(codePoint) >> 16)
	return plane < 17
}
func Character_IsBmpCodePoint_I__Z(codePoint int32) bool { Character_Init()
	return int32(uint32(codePoint)>>16) == 0
}
func Character_IsSupplementaryCodePoint_I__Z(codePoint int32) bool { Character_Init()
	var tmp1 bool; tmp1 = codePoint >= 65536; if tmp1 {
		tmp1 = codePoint < 1114112 }
//line :4115:1
	return tmp1
}

func Character_IsHighSurrogate_C__Z(ch uint16) bool { Character_Init()
	var tmp1 bool; tmp1 = int32(ch) >= 55296; if tmp1 { tmp1 = int32(ch) < 56320 }; return tmp1
}
func Character_IsLowSurrogate_C__Z(ch uint16) bool { Character_Init()
	var tmp1 bool; tmp1 = int32(ch) >= 56320; if tmp1 { tmp1 = int32(ch) < 57344 }; return tmp1
}
func Character_IsSurrogate_C__Z(ch uint16) bool { Character_Init()
	var tmp1 bool; tmp1 = int32(ch) >= 55296; if tmp1 { tmp1 = int32(ch) < 57344 }; return tmp1
}
func Character_IsSurrogatePair_C_C__Z(high, low uint16) bool { Character_Init()
	var tmp1 bool; tmp1 = Character_IsHighSurrogate_C__Z(high); if tmp1 { tmp1 = Character_IsLowSurrogate_C__Z(low) }; return tmp1
}
func Character_CharCount_I__I(codePoint int32) int32 { Character_Init()
	if codePoint >= 65536 { return 2 } else { return 1
	} }
func Character_ToCodePoint_C_C__I(high, low uint16) int32 { Character_Init()
	return int32(high)<<10 + int32(low) + -56613888
}





func Character_CodePointAt_CharSequence_I__I(seq CharSequence, index int32) int32 { Character_Init(); var tmp1 uint16; var c1 uint16 = seq.CharAt_I__C(index); var tmp2 bool; var tmp3 bool; tmp3 =

	Character_IsHighSurrogate_C__Z(c1); if tmp3 {
		var tmp4 int32; index = index + 1; tmp4 = index; tmp3 = tmp4 < seq.Length__I() }; tmp2 = tmp3; if tmp2 {
			var c2 uint16 = seq.CharAt_I__C(index)
			if Character_IsLowSurrogate_C__Z(c2) { return Character_ToCodePoint_C_C__I(c1, c2) } }; tmp1 = c1; return /*line :4141:1*/ int32(tmp1) }







func Character_CodePointAt_C1_I__I(a *CharArray, index int32) int32 { Character_Init()
	return Character_CodePointAtImpl_C1_I_I__I(a, index, int32(len(a.A)))
}
func Character_CodePointAt_C1_I_I__I(a *CharArray, index, limit int32) int32 { Character_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = index >= limit; if !tmp3 { tmp3 = index < 0 }; tmp2 = tmp3; if !tmp2 { tmp2 = limit > int32(len(a.A)) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IndexOutOfBoundsException_New())) }
	return Character_CodePointAtImpl_C1_I_I__I(a, index, limit)
}
func Character_CodePointAtImpl_C1_I_I__I(a *CharArray, index, limit int32) int32 { Character_Init(); var tmp1 uint16; var c1 uint16 = a.A[index]; var tmp2 bool; var tmp3 bool; tmp3 =

	Character_IsHighSurrogate_C__Z(c1); if tmp3 { var tmp4 int32; index = index + 1; tmp4 = index; tmp3 = tmp4 < limit }; tmp2 = tmp3; if tmp2 {
		var c2 uint16 = a.A[index]
		if Character_IsLowSurrogate_C__Z(c2) { return Character_ToCodePoint_C_C__I(c1, c2) } }; tmp1 = c1; return /*line :4157:1*/ int32(tmp1) }






func Character_CodePointBefore_CharSequence_I__I(seq CharSequence, index int32) int32 { Character_Init(); var tmp1 uint16; var c2 uint16; var tmp2 int32; index =
											index - 1; tmp2 = index; c2 = seq.CharAt_I__C(tmp2); var tmp3 bool; var tmp4 bool; tmp4 =
											Character_IsLowSurrogate_C__Z(c2); if tmp4 { tmp4 = index > 0 }; tmp3 = tmp4; if tmp3 {
												var c1 uint16; var tmp5 int32; index = index - 1; tmp5 = index; c1 = seq.CharAt_I__C(tmp5)
												if Character_IsHighSurrogate_C__Z(c1) { return Character_ToCodePoint_C_C__I(c1, c2) } }; tmp1 = c2; return /*line :4164:1*/ int32(tmp1) }






func Character_CodePointBefore_C1_I__I(a *CharArray, index int32) int32 { Character_Init()
	return Character_CodePointBeforeImpl_C1_I_I__I(a, index, 0)
}
func Character_CodePointBefore_C1_I_I__I(a *CharArray, index, start int32) int32 { Character_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = index <= start; if !tmp3 { tmp3 = start < 0 }; tmp2 = tmp3; if !tmp2 { tmp2 = index > int32(len(a.A)) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IndexOutOfBoundsException_New())) }
	return Character_CodePointBeforeImpl_C1_I_I__I(a, index, start)
}
func Character_CodePointBeforeImpl_C1_I_I__I(a *CharArray, index, start int32) int32 { Character_Init(); var tmp1 uint16; var c2 uint16; var tmp2 int32; index =
											index - 1; tmp2 = index; c2 = a.A[tmp2]; var tmp3 bool; var tmp4 bool; tmp4 =
											Character_IsLowSurrogate_C__Z(c2); if tmp4 { tmp4 = index > start }; tmp3 = tmp4; if tmp3 {
												var c1 uint16; var tmp5 int32; index = index - 1; tmp5 = index; c1 = a.A[tmp5]
												if Character_IsHighSurrogate_C__Z(c1) { return Character_ToCodePoint_C_C__I(c1, c2) } }; tmp1 = c2; return /*line :4179:1*/ int32(tmp1) }






func Character_HighSurrogate_I__C(codePoint int32) uint16 { Character_Init()
	return uint16(int32(uint32(codePoint)>>10) + 55232)
}




func Character_LowSurrogate_I__C(codePoint int32) uint16 { Character_Init()
	return uint16(codePoint&1023 + 56320)
}
func Character_ToChars_I_C1_I__I(codePoint int32, dst *CharArray, dstIndex int32) int32 { Character_Init()
	if Character_IsBmpCodePoint_I__Z(codePoint) {
		dst.A[dstIndex] = uint16(codePoint); return 1 } else {
//line :4197:1
			if Character_IsValidCodePoint_I__Z(codePoint) {

				Character_ToSurrogates_I_C1_I__V(codePoint, dst, dstIndex); return 2 } else {

					panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_114, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(codePoint))))))
				}
		} }
func Character_ToChars_I__C1(codePoint int32) *CharArray { Character_Init()
	if Character_IsBmpCodePoint_I__Z(codePoint) {
		return CharArrayOf(uint16(codePoint)) } else {
//line :4205:1
			if Character_IsValidCodePoint_I__Z(codePoint) {


				var result *CharArray = NewCharArray(2); Character_ToSurrogates_I_C1_I__V(codePoint, result, 0); return result } else {

					panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_114, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(codePoint))))))
				}
		} }
func Character_ToSurrogates_I_C1_I__V(codePoint int32, dst *CharArray, index int32) { Character_Init()
	dst.A[index+1] = Character_LowSurrogate_I__C(codePoint)
	dst.A[index] = Character_HighSurrogate_I__C(codePoint)
}
func Character_CodePointCount_CharSequence_I_I__I(seq CharSequence, beginIndex, endIndex int32) int32 { Character_Init()
	Objects_CheckFromToIndex_I_I_I__I(beginIndex, endIndex, seq.Length__I())
	var n int32 = endIndex - beginIndex
	var i int32 = beginIndex
L1: for { if i < endIndex {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 int32; var old_1 int32 = i
	i = i + 1; tmp4 = old_1
//line :4222:1
	tmp3 = Character_IsHighSurrogate_C__Z(seq.CharAt_I__C(tmp4)); if tmp3 {

		tmp3 = i < endIndex }
//line :4222:1
	tmp2 = tmp3; if tmp2 {


		tmp2 = Character_IsLowSurrogate_C__Z(seq.CharAt_I__C(i)) }
//line :4222:1
	tmp1 = tmp2; if tmp1 {



		n = n - 1
		i = i + 1 }
//line :4221:1
	continue L1 }; break L1 }
//line :4219:1
	return n
}









func Character_CodePointCount_C1_I_I__I(a *CharArray, offset, count int32) int32 { Character_Init()
	Objects_CheckFromIndexSize_I_I_I__I(offset, count, int32(len(a.A)))
	return Character_CodePointCountImpl_C1_I_I__I(a, offset, count)
}
func Character_CodePointCountImpl_C1_I_I__I(a *CharArray, offset, count int32) int32 { Character_Init()
	var endIndex int32 = offset + count
	var n int32 = count
	var i int32 = offset
L1: for { if i < endIndex {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 int32; var old_2 int32 = i
	i = i + 1; tmp4 = old_2
//line :4239:1
	tmp3 = Character_IsHighSurrogate_C__Z(a.A[tmp4]); if tmp3 {

		tmp3 = i < endIndex }
//line :4239:1
	tmp2 = tmp3; if tmp2 {


		tmp2 = Character_IsLowSurrogate_C__Z(a.A[i]) }
//line :4239:1
	tmp1 = tmp2; if tmp1 {



		n = n - 1
		i = i + 1 }
//line :4238:1
	continue L1 }; break L1 }
//line :4235:1
	return n
}










func Character_OffsetByCodePoints_CharSequence_I_I__I(seq CharSequence, index, codePointOffset int32) int32 { Character_Init()

	var length int32 = seq.Length__I(); var tmp1 bool; var tmp2 bool
	tmp2 = index < 0; if !tmp2 { tmp2 = index > length }; tmp1 = tmp2; if tmp1 { panic(Thrown(IndexOutOfBoundsException_New())) }
	var x int32 = index
	if codePointOffset >= 0 {
		var i int32 = 0
		i = 0
	L1: for { var tmp3 bool; var tmp4 bool; tmp4 = x < length; if tmp4 { tmp4 = i < codePointOffset }; tmp3 = tmp4; if tmp3 {
		var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 int32
		var old_3 int32 = x
		x = x + 1; tmp8 = old_3
//line :4257:1
		tmp7 = Character_IsHighSurrogate_C__Z(seq.CharAt_I__C(tmp8))
//line :4256:1
		if tmp7 {


			tmp7 = x < length }
//line :4256:1
		tmp6 = tmp7; if tmp6 {



			tmp6 = Character_IsLowSurrogate_C__Z(seq.CharAt_I__C(x)) }
//line :4256:1
		tmp5 = tmp6; if tmp5 {




			x = x + 1 }
		i = i + 1
//line :4255:1
		continue L1 }; break L1
	}






		if i < codePointOffset { panic(Thrown(IndexOutOfBoundsException_New())) } } else {
			var i_2 int32 = 0
			i_2 = codePointOffset
		L2: for { var tmp9 bool; var tmp10 bool; tmp10 = x > 0; if tmp10 { tmp10 = i_2 < 0 }; tmp9 = tmp10; if tmp9 {
			var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 int32
			x = x - 1; tmp14 = x
//line :4267:1
			tmp13 = Character_IsLowSurrogate_C__Z(seq.CharAt_I__C(tmp14)); if tmp13 {

				tmp13 = x > 0 }
//line :4267:1
			tmp12 = tmp13; if tmp12 {


				tmp12 = Character_IsHighSurrogate_C__Z(seq.CharAt_I__C(x - 1)) }
//line :4267:1
			tmp11 = tmp12; if tmp11 {



				x = x - 1 }
			i_2 = i_2 + 1
//line :4266:1
			continue L2 }; break L2
		}





			if i_2 < 0 { panic(Thrown(IndexOutOfBoundsException_New())) } }
//line :4251:1
	return x
}























func Character_OffsetByCodePoints_C1_I_I_I_I__I(a *CharArray, start, count, index, codePointOffset int32) int32 { Character_Init()

	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = count > int32(len(a.A))-start; if !tmp5 { tmp5 = start < 0 }; tmp4 = tmp5; if !tmp4 {
		tmp4 = count < 0 }
//line :4278:1
	tmp3 = tmp4; if !tmp3 {

		tmp3 = index < start }
//line :4278:1
	tmp2 = tmp3; if !tmp2 {


		tmp2 = index > start+count }
//line :4278:1
	tmp1 = tmp2; if tmp1 {



		panic(Thrown(IndexOutOfBoundsException_New())) }
	return Character_OffsetByCodePointsImpl_C1_I_I_I_I__I(a, start, count, index, codePointOffset)
}
func Character_OffsetByCodePointsImpl_C1_I_I_I_I__I(a *CharArray, start, count, index, codePointOffset int32) int32 { Character_Init()

	var x int32 = index
	if codePointOffset >= 0 {
		var limit int32 = start + count
		var i int32 = 0
		i = 0
	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = x < limit; if tmp2 { tmp2 = i < codePointOffset }; tmp1 = tmp2; if tmp1 {
		var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 int32; var old_4 int32 = x
		x = x + 1; tmp6 = old_4
//line :4293:1
		tmp5 = Character_IsHighSurrogate_C__Z(a.A[tmp6]); if tmp5 {

			tmp5 = x < limit }
//line :4293:1
		tmp4 = tmp5; if tmp4 {


			tmp4 = Character_IsLowSurrogate_C__Z(a.A[x]) }
//line :4293:1
		tmp3 = tmp4; if tmp3 {



			x = x + 1 }
		i = i + 1
//line :4292:1
		continue L1 }; break L1
	}





		if i < codePointOffset { panic(Thrown(IndexOutOfBoundsException_New())) } } else {
			var i_2 int32 = 0
			i_2 = codePointOffset
		L2: for { var tmp7 bool; var tmp8 bool; tmp8 = x > start; if tmp8 { tmp8 = i_2 < 0 }; tmp7 = tmp8; if tmp7 {
			var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 int32; x = x - 1; tmp12 = x; tmp11 = Character_IsLowSurrogate_C__Z(a.A[tmp12]); if tmp11 {
				tmp11 = x > start }
//line :4303:1
			tmp10 = tmp11; if tmp10 {

				tmp10 = Character_IsHighSurrogate_C__Z(a.A[x-1]) }
//line :4303:1
			tmp9 = tmp10; if tmp9 {


				x = x - 1 }
			i_2 = i_2 + 1
//line :4302:1
			continue L2 }; break L2
		}




			if i_2 < 0 { panic(Thrown(IndexOutOfBoundsException_New())) } }
//line :4287:1
	return x
}






















func Character_IsLowerCase_C__Z(ch uint16) bool { Character_Init()
	return Character_IsLowerCase_I__Z(int32(ch))
}
func Character_IsLowerCase_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsLowerCase_I__Z(codePoint)
}
func Character_IsUpperCase_C__Z(ch uint16) bool { Character_Init()
	return Character_IsUpperCase_I__Z(int32(ch))
}
func Character_IsUpperCase_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsUpperCase_I__Z(codePoint)
}
func Character_IsTitleCase_C__Z(ch uint16) bool { Character_Init()
	return Character_IsTitleCase_I__Z(int32(ch))
}
func Character_IsTitleCase_I__Z(codePoint int32) bool { Character_Init()
	return Character_GetType_I__I(codePoint) == 3
}
func Character_IsDigit_C__Z(ch uint16) bool { Character_Init()
	return Character_IsDigit_I__Z(int32(ch))
}
func Character_IsDigit_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsDigit_I__Z(codePoint)
}
func Character_IsDefined_C__Z(ch uint16) bool { Character_Init()
	return Character_IsDefined_I__Z(int32(ch))
}
func Character_IsDefined_I__Z(codePoint int32) bool { Character_Init()
	return !(Character_GetType_I__I(codePoint) == 0)
}
func Character_IsLetter_C__Z(ch uint16) bool { Character_Init()
	return Character_IsLetter_I__Z(int32(ch))
}
func Character_IsLetter_I__Z(codePoint int32) bool { Character_Init()
	return !(62>>(Character_GetType_I__I(codePoint)&31)&1 == 0)
}











func Character_IsLetterOrDigit_C__Z(ch uint16) bool { Character_Init()
	return Character_IsLetterOrDigit_I__Z(int32(ch))
}
func Character_IsLetterOrDigit_I__Z(codePoint int32) bool { Character_Init()
	return !(574>>(Character_GetType_I__I(codePoint)&31)&1 == 0)
}













func Character_IsJavaLetter_C__Z(ch uint16) bool { Character_Init()
	return Character_IsJavaIdentifierStart_C__Z(ch)
}
func Character_IsJavaLetterOrDigit_C__Z(ch uint16) bool { Character_Init()
	return Character_IsJavaIdentifierPart_C__Z(ch)
}
func Character_IsAlphabetic_I__Z(codePoint int32) bool { Character_Init()
	var tmp1 bool; tmp1 = !(1086>>(Character_GetType_I__I(codePoint)&31)&1 == 0); if !tmp1 {

















		tmp1 = CharacterData_Of_I__CharacterData(codePoint).IsOtherAlphabetic_I__Z(codePoint) }
//line :4384:1
	return tmp1
}


















func Character_IsIdeographic_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsIdeographic_I__Z(codePoint)
}
func Character_IsJavaIdentifierStart_C__Z(ch uint16) bool { Character_Init()
	return Character_IsJavaIdentifierStart_I__Z(int32(ch))
}
func Character_IsJavaIdentifierStart_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsJavaIdentifierStart_I__Z(codePoint)
}
func Character_IsJavaIdentifierPart_C__Z(ch uint16) bool { Character_Init()
	return Character_IsJavaIdentifierPart_I__Z(int32(ch))
}
func Character_IsJavaIdentifierPart_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsJavaIdentifierPart_I__Z(codePoint)
}
func Character_IsUnicodeIdentifierStart_C__Z(ch uint16) bool { Character_Init()
	return Character_IsUnicodeIdentifierStart_I__Z(int32(ch))
}
func Character_IsUnicodeIdentifierStart_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsUnicodeIdentifierStart_I__Z(codePoint)
}
func Character_IsUnicodeIdentifierPart_C__Z(ch uint16) bool { Character_Init()
	return Character_IsUnicodeIdentifierPart_I__Z(int32(ch))
}
func Character_IsUnicodeIdentifierPart_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsUnicodeIdentifierPart_I__Z(codePoint)
}
func Character_IsIdentifierIgnorable_C__Z(ch uint16) bool { Character_Init()
	return Character_IsIdentifierIgnorable_I__Z(int32(ch))
}
func Character_IsIdentifierIgnorable_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsIdentifierIgnorable_I__Z(codePoint)
}
func Character_IsEmoji_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsEmoji_I__Z(codePoint)
}
func Character_IsEmojiPresentation_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsEmojiPresentation_I__Z(codePoint)
}
func Character_IsEmojiModifier_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsEmojiModifier_I__Z(codePoint)
}
func Character_IsEmojiModifierBase_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsEmojiModifierBase_I__Z(codePoint)
}
func Character_IsEmojiComponent_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsEmojiComponent_I__Z(codePoint)
}
func Character_IsExtendedPictographic_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsExtendedPictographic_I__Z(codePoint)
}
func Character_ToLowerCase_C__C(ch uint16) uint16 { Character_Init()
	return uint16(Character_ToLowerCase_I__I(int32(ch)))
}
func Character_ToLowerCase_I__I(codePoint int32) int32 { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).ToLowerCase_I__I(codePoint)
}
func Character_ToUpperCase_C__C(ch uint16) uint16 { Character_Init()
	return uint16(Character_ToUpperCase_I__I(int32(ch)))
}
func Character_ToUpperCase_I__I(codePoint int32) int32 { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).ToUpperCase_I__I(codePoint)
}
func Character_ToTitleCase_C__C(ch uint16) uint16 { Character_Init()
	return uint16(Character_ToTitleCase_I__I(int32(ch)))
}
func Character_ToTitleCase_I__I(codePoint int32) int32 { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).ToTitleCase_I__I(codePoint)
}
func Character_Digit_C_I__I(ch uint16, radix int32) int32 { Character_Init()
	return Character_Digit_I_I__I(int32(ch), radix)
}
func Character_Digit_I_I__I(codePoint, radix int32) int32 { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).Digit_I_I__I(codePoint, radix)
}
func Character_GetNumericValue_C__I(ch uint16) int32 { Character_Init()
	return Character_GetNumericValue_I__I(int32(ch))
}
func Character_GetNumericValue_I__I(codePoint int32) int32 { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).GetNumericValue_I__I(codePoint)
}
func Character_IsSpace_C__Z(ch uint16) bool { Character_Init()
	var tmp1 bool; tmp1 = int32(ch) <= 32; if tmp1 {
		tmp1 = !(4294981120>>(int32(ch)&63)&1 == 0) }
//line :4486:1
	return tmp1
}











func Character_IsSpaceChar_C__Z(ch uint16) bool { Character_Init()
	return Character_IsSpaceChar_I__Z(int32(ch))
}
func Character_IsSpaceChar_I__Z(codePoint int32) bool { Character_Init()
	return !(28672>>(Character_GetType_I__I(codePoint)&31)&1 == 0)
}







func Character_IsWhitespace_C__Z(ch uint16) bool { Character_Init()
	return Character_IsWhitespace_I__Z(int32(ch))
}
func Character_IsWhitespace_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsWhitespace_I__Z(codePoint)
}
func Character_IsISOControl_C__Z(ch uint16) bool { Character_Init()
	return Character_IsISOControl_I__Z(int32(ch))
}
func Character_IsISOControl_I__Z(codePoint int32) bool { Character_Init()
	var tmp1 bool; tmp1 = codePoint <= 159; if tmp1 {
		var tmp2 bool; tmp2 = codePoint >= 127; if !tmp2 { tmp2 = int32(uint32(codePoint)>>5) == 0 }; tmp1 = tmp2 }
//line :4522:1
	return tmp1
}

func Character_GetType_C__I(ch uint16) int32 { Character_Init()
	return Character_GetType_I__I(int32(ch))
}
func Character_GetType_I__I(codePoint int32) int32 { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).GetType_I__I(codePoint)
}
func Character_ForDigit_I_I__C(digit, radix int32) uint16 { Character_Init()
	var tmp1 bool; var tmp2 bool
	tmp2 = digit >= radix; if !tmp2 { tmp2 = digit < 0 }; tmp1 = tmp2
//line :4532:1
	if tmp1 { return 0 } else { var tmp3 bool; var tmp4 bool

		tmp4 = radix < 2; if !tmp4 { tmp4 = radix > 36 }; tmp3 = tmp4
//line :4532:1
		if tmp3 { return 0 } else { if digit < 10 {


			return uint16(48 + digit) } else {
				return uint16(87 + digit)
			} } } }
func Character_GetDirectionality_C__B(ch uint16) int8 { Character_Init()
	return Character_GetDirectionality_I__B(int32(ch))
}
func Character_GetDirectionality_I__B(codePoint int32) int8 { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).GetDirectionality_I__B(codePoint)
}
func Character_IsMirrored_C__Z(ch uint16) bool { Character_Init()
	return Character_IsMirrored_I__Z(int32(ch))
}
func Character_IsMirrored_I__Z(codePoint int32) bool { Character_Init()
	return CharacterData_Of_I__CharacterData(codePoint).IsMirrored_I__Z(codePoint)
}
func (t *Character) CompareTo_Character__I(anotherCharacter *Character) int32 {
	var tmp1 uint16 = t.F_value; return Character_Compare_C_C__I(tmp1, anotherCharacter.F_value)
}
func Character_Compare_C_C__I(x, y uint16) int32 { Character_Init()
	return int32(x) - int32(y)
}
func Character_ToUpperCaseEx_I__I(p0 int32) int32 { Character_Init(); panic(A2g_NotTranslated("java.lang.Character.toUpperCaseEx(I)I")) }



func Character_ToUpperCaseCharArray_I__C1(p0 int32) *CharArray { Character_Init(); panic(A2g_NotTranslated("java.lang.Character.toUpperCaseCharArray(I)[C")) }







func Character_ReverseBytes_C__C(ch uint16) uint16 { Character_Init()
	return uint16(int32(ch)&65280>>8 | int32(ch)<<8)
}

func Character_GetName_I__String(codePoint int32) *String { Character_Init()
	if Character_IsValidCodePoint_I__Z(codePoint) { } else {
		panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_114, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(codePoint))))))
	}
	var name *String = NN(CharacterName_GetInstance__CharacterName()).GetName_I__String(codePoint)
	if !(name == nil) { return name } else {

		if Character_GetType_I__I(codePoint) == 0 { return nil } else {
			var block *Character_UnicodeBlock = Character_UnicodeBlock_Of_I__Character_UnicodeBlock(codePoint)
			if !(block == nil) {
				var tmp1 *String = NN(NN(block).ToString__String()).Replace_C_C__String(95, 32); var tmp2 *String = Integer_ToHexString_I__String(codePoint); var tmp3 *Locale; Locale_Init(); tmp3 = Locale_ROOT; return Concat(tmp1, Lit_115, NN(tmp2).ToUpperCase_Locale__String(tmp3)) } else {


					var tmp4 *String = Integer_ToHexString_I__String(codePoint); var tmp5 *Locale; Locale_Init(); tmp5 = Locale_ROOT; return NN(tmp4).ToUpperCase_Locale__String(tmp5)
				} } } }
func Character_CodePointOf_String__I(name *String) int32 { Character_Init()
	var tmp1 *String = NN(name).Trim__String(); var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; name = NN(tmp1).ToUpperCase_Locale__String(tmp2)
	var cp int32 = NN(CharacterName_GetInstance__CharacterName()).GetCodePoint_String__I(name)
	if !(cp == -1) { return cp } else { tmp5, tmp6, tmp7 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc)



		{ var off int32 = NN(name).LastIndexOf_I__I(32)
			if off == -1 { } else {
				cp = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(name), off+1, NN(name).Length__I(), 16)
				var tmp3 bool; var tmp4 bool; tmp4 = Character_IsValidCodePoint_I__Z(cp); if tmp4 { tmp4 = NN(name).Equals_O__Z(Character_GetName_I__String(cp).Ref()) }; tmp3 = tmp4; if tmp3 { return 2, cp, nil } } }; return 0, 0, nil }()
//line :4593:1
		if tmp7 != nil { if Exception_InstanceOf(tmp7) { var x Exception_I = Exception_Cast(tmp7); _ = x } else { panic(tmp7) } }; switch tmp5 { case 2: { return tmp6
		}
		}




		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_116, name))))
	}
}

type Character struct{ Object; F_value uint16 }

func (t *Character) Is_Serializable() {}

func (t *Character) Is_Comparable() {}

func (t *Character) Is_Constable() {}

const Character_MIN_RADIX int32 = 2

const Character_MAX_RADIX int32 = 36

const Character_MIN_VALUE uint16 = 0

const Character_MAX_VALUE uint16 = 65535

var Character_TYPE *Class

const Character_UNASSIGNED int8 = 0

const Character_UPPERCASE_LETTER int8 = 1

const Character_LOWERCASE_LETTER int8 = 2

const Character_TITLECASE_LETTER int8 = 3

const Character_MODIFIER_LETTER int8 = 4

const Character_OTHER_LETTER int8 = 5

const Character_NON_SPACING_MARK int8 = 6

const Character_ENCLOSING_MARK int8 = 7

const Character_COMBINING_SPACING_MARK int8 = 8

const Character_DECIMAL_DIGIT_NUMBER int8 = 9

const Character_LETTER_NUMBER int8 = 10

const Character_OTHER_NUMBER int8 = 11

const Character_SPACE_SEPARATOR int8 = 12

const Character_LINE_SEPARATOR int8 = 13

const Character_PARAGRAPH_SEPARATOR int8 = 14

const Character_CONTROL int8 = 15

const Character_FORMAT int8 = 16

const Character_PRIVATE_USE int8 = 18

const Character_SURROGATE int8 = 19

const Character_DASH_PUNCTUATION int8 = 20

const Character_START_PUNCTUATION int8 = 21

const Character_END_PUNCTUATION int8 = 22

const Character_CONNECTOR_PUNCTUATION int8 = 23

const Character_OTHER_PUNCTUATION int8 = 24

const Character_MATH_SYMBOL int8 = 25

const Character_CURRENCY_SYMBOL int8 = 26

const Character_MODIFIER_SYMBOL int8 = 27

const Character_OTHER_SYMBOL int8 = 28

const Character_INITIAL_QUOTE_PUNCTUATION int8 = 29

const Character_FINAL_QUOTE_PUNCTUATION int8 = 30

const Character_ERROR int32 = -1

const Character_DIRECTIONALITY_UNDEFINED int8 = -1

const Character_DIRECTIONALITY_LEFT_TO_RIGHT int8 = 0

const Character_DIRECTIONALITY_RIGHT_TO_LEFT int8 = 1

const Character_DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC int8 = 2

const Character_DIRECTIONALITY_EUROPEAN_NUMBER int8 = 3

const Character_DIRECTIONALITY_EUROPEAN_NUMBER_SEPARATOR int8 = 4

const Character_DIRECTIONALITY_EUROPEAN_NUMBER_TERMINATOR int8 = 5

const Character_DIRECTIONALITY_ARABIC_NUMBER int8 = 6

const Character_DIRECTIONALITY_COMMON_NUMBER_SEPARATOR int8 = 7

const Character_DIRECTIONALITY_NONSPACING_MARK int8 = 8

const Character_DIRECTIONALITY_BOUNDARY_NEUTRAL int8 = 9

const Character_DIRECTIONALITY_PARAGRAPH_SEPARATOR int8 = 10

const Character_DIRECTIONALITY_SEGMENT_SEPARATOR int8 = 11

const Character_DIRECTIONALITY_WHITESPACE int8 = 12

const Character_DIRECTIONALITY_OTHER_NEUTRALS int8 = 13

const Character_DIRECTIONALITY_LEFT_TO_RIGHT_EMBEDDING int8 = 14

const Character_DIRECTIONALITY_LEFT_TO_RIGHT_OVERRIDE int8 = 15

const Character_DIRECTIONALITY_RIGHT_TO_LEFT_EMBEDDING int8 = 16

const Character_DIRECTIONALITY_RIGHT_TO_LEFT_OVERRIDE int8 = 17

const Character_DIRECTIONALITY_POP_DIRECTIONAL_FORMAT int8 = 18

const Character_DIRECTIONALITY_LEFT_TO_RIGHT_ISOLATE int8 = 19

const Character_DIRECTIONALITY_RIGHT_TO_LEFT_ISOLATE int8 = 20

const Character_DIRECTIONALITY_FIRST_STRONG_ISOLATE int8 = 21

const Character_DIRECTIONALITY_POP_DIRECTIONAL_ISOLATE int8 = 22

const Character_MIN_HIGH_SURROGATE uint16 = 55296

const Character_MAX_HIGH_SURROGATE uint16 = 56319

const Character_MIN_LOW_SURROGATE uint16 = 56320

const Character_MAX_LOW_SURROGATE uint16 = 57343

const Character_MIN_SURROGATE uint16 = 55296

const Character_MAX_SURROGATE uint16 = 57343

const Character_MIN_SUPPLEMENTARY_CODE_POINT int32 = 65536

const Character_MIN_CODE_POINT int32 = 0

const Character_MAX_CODE_POINT int32 = 1114111

const Character_serialVersionUID int64 = 3786198910865385080

const Character_SIZE int32 = 16

const Character_BYTES int32 = 2

var Character_init ClassInit

func Character_Init() { if !Character_init.Done() { Character_init.Run(Character_clinit) } }

func Character_clinit() { Character_TYPE = Class_GetPrimitiveClass_String__Class(Lit_113) }

func (t *Character) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Character__I(Character_Cast(p0)) }

func (t *Character) Ref() any { if t == nil { return nil }; return t }

func (t *Character) GetClass__Class() *Class { return Character_class }

func (t *Character) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Character) CloneShallow() any { panic(CloneNotSupported(t)) }

func Character_InstanceOf(x any) bool { _, ok := x.(*Character); return ok }

func Character_Cast(x any) *Character { if x == nil { return nil }; v, ok := x.(*Character); if !ok { panic(ClassCast(x, Character_class)) }; return v }



type Character_CharacterCache struct{ Object }

var Character_CharacterCache_cache *RefArray

var Character_CharacterCache_archivedCache *RefArray

var Character_CharacterCache_init ClassInit

func Character_CharacterCache_Init() { if !Character_CharacterCache_init.Done() { Character_CharacterCache_init.Run(Character_CharacterCache_clinit) } }

func Character_CharacterCache_clinit() {
//line :4075:1
	var size int32 = 128
	CDS_InitializeFromArchive_Class__V(Character_CharacterCache_class)
	if Character_CharacterCache_archivedCache == nil {
		var c *RefArray = NewRefArray(Character_class, size); var i int32 = 0
	L1: for {
		if i < size {
			c.Store(i, Character_New_C(uint16(i)))
			i = i + 1; continue L1 }
//line :4079:1
		break L1
	}


		Character_CharacterCache_archivedCache = c }
	Character_CharacterCache_cache = Character_CharacterCache_archivedCache
	if !A2g_AssertionsDisabled && !(int32(len(Character_CharacterCache_cache.A)) == size) { panic(Thrown(AssertionError_New()))
	}
}






























































































































































































































































































































































































































































































































































































































































































































func (t *Character_CharacterCache) Ref() any { if t == nil { return nil }; return t }

func (t *Character_CharacterCache) GetClass__Class() *Class { return Character_CharacterCache_class }

func (t *Character_CharacterCache) ToString__String() *String { return Object_toString(t) }

func (t *Character_CharacterCache) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Character_CharacterCache) CloneShallow() any { panic(CloneNotSupported(t)) }

func Character_CharacterCache_InstanceOf(x any) bool { _, ok := x.(*Character_CharacterCache); return ok }

func Character_CharacterCache_Cast(x any) *Character_CharacterCache { if x == nil { return nil }; v, ok := x.(*Character_CharacterCache); if !ok { panic(ClassCast(x, Character_CharacterCache_class)) }; return v }



type Character_Subset struct{ Object; F_name *String }

type Character_Subset_I interface{ Object_I; Self_Character_Subset() *Character_Subset }

func (t *Character_Subset) Self_Character_Subset() *Character_Subset { return t }

func (t *Character_Subset) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Character_Subset) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Character_Subset) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Character_Subset) Ref() any { if t == nil { return nil }; return t }

func (t *Character_Subset) GetClass__Class() *Class { return Character_Subset_class }

func (t *Character_Subset) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Character_Subset) CloneShallow() any { panic(CloneNotSupported(t)) }

func Character_Subset_InstanceOf(x any) bool { _, ok := x.(Character_Subset_I); return ok }

func Character_Subset_Cast(x any) Character_Subset_I { if x == nil { return nil }; v, ok := x.(Character_Subset_I); if !ok { panic(ClassCast(x, Character_Subset_class)) }; return v }



type Character_UnicodeBlock struct{ Character_Subset }

const Character_UnicodeBlock_NUM_ENTITIES int32 = 804

var Character_UnicodeBlock_map Map

var Character_UnicodeBlock_BASIC_LATIN *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_1_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_B *Character_UnicodeBlock

var Character_UnicodeBlock_IPA_EXTENSIONS *Character_UnicodeBlock

var Character_UnicodeBlock_SPACING_MODIFIER_LETTERS *Character_UnicodeBlock

var Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS *Character_UnicodeBlock

var Character_UnicodeBlock_GREEK *Character_UnicodeBlock

var Character_UnicodeBlock_CYRILLIC *Character_UnicodeBlock

var Character_UnicodeBlock_ARMENIAN *Character_UnicodeBlock

var Character_UnicodeBlock_HEBREW *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC *Character_UnicodeBlock

var Character_UnicodeBlock_DEVANAGARI *Character_UnicodeBlock

var Character_UnicodeBlock_BENGALI *Character_UnicodeBlock

var Character_UnicodeBlock_GURMUKHI *Character_UnicodeBlock

var Character_UnicodeBlock_GUJARATI *Character_UnicodeBlock

var Character_UnicodeBlock_ORIYA *Character_UnicodeBlock

var Character_UnicodeBlock_TAMIL *Character_UnicodeBlock

var Character_UnicodeBlock_TELUGU *Character_UnicodeBlock

var Character_UnicodeBlock_KANNADA *Character_UnicodeBlock

var Character_UnicodeBlock_MALAYALAM *Character_UnicodeBlock

var Character_UnicodeBlock_THAI *Character_UnicodeBlock

var Character_UnicodeBlock_LAO *Character_UnicodeBlock

var Character_UnicodeBlock_TIBETAN *Character_UnicodeBlock

var Character_UnicodeBlock_GEORGIAN *Character_UnicodeBlock

var Character_UnicodeBlock_HANGUL_JAMO *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_ADDITIONAL *Character_UnicodeBlock

var Character_UnicodeBlock_GREEK_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_GENERAL_PUNCTUATION *Character_UnicodeBlock

var Character_UnicodeBlock_SUPERSCRIPTS_AND_SUBSCRIPTS *Character_UnicodeBlock

var Character_UnicodeBlock_CURRENCY_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_COMBINING_MARKS_FOR_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_LETTERLIKE_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_NUMBER_FORMS *Character_UnicodeBlock

var Character_UnicodeBlock_ARROWS *Character_UnicodeBlock

var Character_UnicodeBlock_MATHEMATICAL_OPERATORS *Character_UnicodeBlock

var Character_UnicodeBlock_MISCELLANEOUS_TECHNICAL *Character_UnicodeBlock

var Character_UnicodeBlock_CONTROL_PICTURES *Character_UnicodeBlock

var Character_UnicodeBlock_OPTICAL_CHARACTER_RECOGNITION *Character_UnicodeBlock

var Character_UnicodeBlock_ENCLOSED_ALPHANUMERICS *Character_UnicodeBlock

var Character_UnicodeBlock_BOX_DRAWING *Character_UnicodeBlock

var Character_UnicodeBlock_BLOCK_ELEMENTS *Character_UnicodeBlock

var Character_UnicodeBlock_GEOMETRIC_SHAPES *Character_UnicodeBlock

var Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_DINGBATS *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_SYMBOLS_AND_PUNCTUATION *Character_UnicodeBlock

var Character_UnicodeBlock_HIRAGANA *Character_UnicodeBlock

var Character_UnicodeBlock_KATAKANA *Character_UnicodeBlock

var Character_UnicodeBlock_BOPOMOFO *Character_UnicodeBlock

var Character_UnicodeBlock_HANGUL_COMPATIBILITY_JAMO *Character_UnicodeBlock

var Character_UnicodeBlock_KANBUN *Character_UnicodeBlock

var Character_UnicodeBlock_ENCLOSED_CJK_LETTERS_AND_MONTHS *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_COMPATIBILITY *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS *Character_UnicodeBlock

var Character_UnicodeBlock_HANGUL_SYLLABLES *Character_UnicodeBlock

var Character_UnicodeBlock_PRIVATE_USE_AREA *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_COMPATIBILITY_IDEOGRAPHS *Character_UnicodeBlock

var Character_UnicodeBlock_ALPHABETIC_PRESENTATION_FORMS *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC_PRESENTATION_FORMS_A *Character_UnicodeBlock

var Character_UnicodeBlock_COMBINING_HALF_MARKS *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_COMPATIBILITY_FORMS *Character_UnicodeBlock

var Character_UnicodeBlock_SMALL_FORM_VARIANTS *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC_PRESENTATION_FORMS_B *Character_UnicodeBlock

var Character_UnicodeBlock_HALFWIDTH_AND_FULLWIDTH_FORMS *Character_UnicodeBlock

var Character_UnicodeBlock_SPECIALS *Character_UnicodeBlock

var Character_UnicodeBlock_SURROGATES_AREA *Character_UnicodeBlock

var Character_UnicodeBlock_SYRIAC *Character_UnicodeBlock

var Character_UnicodeBlock_THAANA *Character_UnicodeBlock

var Character_UnicodeBlock_SINHALA *Character_UnicodeBlock

var Character_UnicodeBlock_MYANMAR *Character_UnicodeBlock

var Character_UnicodeBlock_ETHIOPIC *Character_UnicodeBlock

var Character_UnicodeBlock_CHEROKEE *Character_UnicodeBlock

var Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS *Character_UnicodeBlock

var Character_UnicodeBlock_OGHAM *Character_UnicodeBlock

var Character_UnicodeBlock_RUNIC *Character_UnicodeBlock

var Character_UnicodeBlock_KHMER *Character_UnicodeBlock

var Character_UnicodeBlock_MONGOLIAN *Character_UnicodeBlock

var Character_UnicodeBlock_BRAILLE_PATTERNS *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_RADICALS_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_KANGXI_RADICALS *Character_UnicodeBlock

var Character_UnicodeBlock_IDEOGRAPHIC_DESCRIPTION_CHARACTERS *Character_UnicodeBlock

var Character_UnicodeBlock_BOPOMOFO_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A *Character_UnicodeBlock

var Character_UnicodeBlock_YI_SYLLABLES *Character_UnicodeBlock

var Character_UnicodeBlock_YI_RADICALS *Character_UnicodeBlock

var Character_UnicodeBlock_CYRILLIC_SUPPLEMENTARY *Character_UnicodeBlock

var Character_UnicodeBlock_TAGALOG *Character_UnicodeBlock

var Character_UnicodeBlock_HANUNOO *Character_UnicodeBlock

var Character_UnicodeBlock_BUHID *Character_UnicodeBlock

var Character_UnicodeBlock_TAGBANWA *Character_UnicodeBlock

var Character_UnicodeBlock_LIMBU *Character_UnicodeBlock

var Character_UnicodeBlock_TAI_LE *Character_UnicodeBlock

var Character_UnicodeBlock_KHMER_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_PHONETIC_EXTENSIONS *Character_UnicodeBlock

var Character_UnicodeBlock_MISCELLANEOUS_MATHEMATICAL_SYMBOLS_A *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_A *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_B *Character_UnicodeBlock

var Character_UnicodeBlock_MISCELLANEOUS_MATHEMATICAL_SYMBOLS_B *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTAL_MATHEMATICAL_OPERATORS *Character_UnicodeBlock

var Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_AND_ARROWS *Character_UnicodeBlock

var Character_UnicodeBlock_KATAKANA_PHONETIC_EXTENSIONS *Character_UnicodeBlock

var Character_UnicodeBlock_YIJING_HEXAGRAM_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_VARIATION_SELECTORS *Character_UnicodeBlock

var Character_UnicodeBlock_LINEAR_B_SYLLABARY *Character_UnicodeBlock

var Character_UnicodeBlock_LINEAR_B_IDEOGRAMS *Character_UnicodeBlock

var Character_UnicodeBlock_AEGEAN_NUMBERS *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_ITALIC *Character_UnicodeBlock

var Character_UnicodeBlock_GOTHIC *Character_UnicodeBlock

var Character_UnicodeBlock_UGARITIC *Character_UnicodeBlock

var Character_UnicodeBlock_DESERET *Character_UnicodeBlock

var Character_UnicodeBlock_SHAVIAN *Character_UnicodeBlock

var Character_UnicodeBlock_OSMANYA *Character_UnicodeBlock

var Character_UnicodeBlock_CYPRIOT_SYLLABARY *Character_UnicodeBlock

var Character_UnicodeBlock_BYZANTINE_MUSICAL_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_MUSICAL_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_TAI_XUAN_JING_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_MATHEMATICAL_ALPHANUMERIC_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_TAGS *Character_UnicodeBlock

var Character_UnicodeBlock_VARIATION_SELECTORS_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTARY_PRIVATE_USE_AREA_A *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTARY_PRIVATE_USE_AREA_B *Character_UnicodeBlock

var Character_UnicodeBlock_HIGH_SURROGATES *Character_UnicodeBlock

var Character_UnicodeBlock_HIGH_PRIVATE_USE_SURROGATES *Character_UnicodeBlock

var Character_UnicodeBlock_LOW_SURROGATES *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_NKO *Character_UnicodeBlock

var Character_UnicodeBlock_SAMARITAN *Character_UnicodeBlock

var Character_UnicodeBlock_MANDAIC *Character_UnicodeBlock

var Character_UnicodeBlock_ETHIOPIC_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_NEW_TAI_LUE *Character_UnicodeBlock

var Character_UnicodeBlock_BUGINESE *Character_UnicodeBlock

var Character_UnicodeBlock_TAI_THAM *Character_UnicodeBlock

var Character_UnicodeBlock_BALINESE *Character_UnicodeBlock

var Character_UnicodeBlock_SUNDANESE *Character_UnicodeBlock

var Character_UnicodeBlock_BATAK *Character_UnicodeBlock

var Character_UnicodeBlock_LEPCHA *Character_UnicodeBlock

var Character_UnicodeBlock_OL_CHIKI *Character_UnicodeBlock

var Character_UnicodeBlock_VEDIC_EXTENSIONS *Character_UnicodeBlock

var Character_UnicodeBlock_PHONETIC_EXTENSIONS_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_GLAGOLITIC *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_C *Character_UnicodeBlock

var Character_UnicodeBlock_COPTIC *Character_UnicodeBlock

var Character_UnicodeBlock_GEORGIAN_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_TIFINAGH *Character_UnicodeBlock

var Character_UnicodeBlock_ETHIOPIC_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_CYRILLIC_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTAL_PUNCTUATION *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_STROKES *Character_UnicodeBlock

var Character_UnicodeBlock_LISU *Character_UnicodeBlock

var Character_UnicodeBlock_VAI *Character_UnicodeBlock

var Character_UnicodeBlock_CYRILLIC_EXTENDED_B *Character_UnicodeBlock

var Character_UnicodeBlock_BAMUM *Character_UnicodeBlock

var Character_UnicodeBlock_MODIFIER_TONE_LETTERS *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_D *Character_UnicodeBlock

var Character_UnicodeBlock_SYLOTI_NAGRI *Character_UnicodeBlock

var Character_UnicodeBlock_COMMON_INDIC_NUMBER_FORMS *Character_UnicodeBlock

var Character_UnicodeBlock_PHAGS_PA *Character_UnicodeBlock

var Character_UnicodeBlock_SAURASHTRA *Character_UnicodeBlock

var Character_UnicodeBlock_DEVANAGARI_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_KAYAH_LI *Character_UnicodeBlock

var Character_UnicodeBlock_REJANG *Character_UnicodeBlock

var Character_UnicodeBlock_HANGUL_JAMO_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_JAVANESE *Character_UnicodeBlock

var Character_UnicodeBlock_CHAM *Character_UnicodeBlock

var Character_UnicodeBlock_MYANMAR_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_TAI_VIET *Character_UnicodeBlock

var Character_UnicodeBlock_ETHIOPIC_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_MEETEI_MAYEK *Character_UnicodeBlock

var Character_UnicodeBlock_HANGUL_JAMO_EXTENDED_B *Character_UnicodeBlock

var Character_UnicodeBlock_VERTICAL_FORMS *Character_UnicodeBlock

var Character_UnicodeBlock_ANCIENT_GREEK_NUMBERS *Character_UnicodeBlock

var Character_UnicodeBlock_ANCIENT_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_PHAISTOS_DISC *Character_UnicodeBlock

var Character_UnicodeBlock_LYCIAN *Character_UnicodeBlock

var Character_UnicodeBlock_CARIAN *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_PERSIAN *Character_UnicodeBlock

var Character_UnicodeBlock_IMPERIAL_ARAMAIC *Character_UnicodeBlock

var Character_UnicodeBlock_PHOENICIAN *Character_UnicodeBlock

var Character_UnicodeBlock_LYDIAN *Character_UnicodeBlock

var Character_UnicodeBlock_KHAROSHTHI *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_SOUTH_ARABIAN *Character_UnicodeBlock

var Character_UnicodeBlock_AVESTAN *Character_UnicodeBlock

var Character_UnicodeBlock_INSCRIPTIONAL_PARTHIAN *Character_UnicodeBlock

var Character_UnicodeBlock_INSCRIPTIONAL_PAHLAVI *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_TURKIC *Character_UnicodeBlock

var Character_UnicodeBlock_RUMI_NUMERAL_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_BRAHMI *Character_UnicodeBlock

var Character_UnicodeBlock_KAITHI *Character_UnicodeBlock

var Character_UnicodeBlock_CUNEIFORM *Character_UnicodeBlock

var Character_UnicodeBlock_CUNEIFORM_NUMBERS_AND_PUNCTUATION *Character_UnicodeBlock

var Character_UnicodeBlock_EGYPTIAN_HIEROGLYPHS *Character_UnicodeBlock

var Character_UnicodeBlock_BAMUM_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_KANA_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_ANCIENT_GREEK_MUSICAL_NOTATION *Character_UnicodeBlock

var Character_UnicodeBlock_COUNTING_ROD_NUMERALS *Character_UnicodeBlock

var Character_UnicodeBlock_MAHJONG_TILES *Character_UnicodeBlock

var Character_UnicodeBlock_DOMINO_TILES *Character_UnicodeBlock

var Character_UnicodeBlock_PLAYING_CARDS *Character_UnicodeBlock

var Character_UnicodeBlock_ENCLOSED_ALPHANUMERIC_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_ENCLOSED_IDEOGRAPHIC_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_AND_PICTOGRAPHS *Character_UnicodeBlock

var Character_UnicodeBlock_EMOTICONS *Character_UnicodeBlock

var Character_UnicodeBlock_TRANSPORT_AND_MAP_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_ALCHEMICAL_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_C *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_D *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_SUNDANESE_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_MEETEI_MAYEK_EXTENSIONS *Character_UnicodeBlock

var Character_UnicodeBlock_MEROITIC_HIEROGLYPHS *Character_UnicodeBlock

var Character_UnicodeBlock_MEROITIC_CURSIVE *Character_UnicodeBlock

var Character_UnicodeBlock_SORA_SOMPENG *Character_UnicodeBlock

var Character_UnicodeBlock_CHAKMA *Character_UnicodeBlock

var Character_UnicodeBlock_SHARADA *Character_UnicodeBlock

var Character_UnicodeBlock_TAKRI *Character_UnicodeBlock

var Character_UnicodeBlock_MIAO *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC_MATHEMATICAL_ALPHABETIC_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_MYANMAR_EXTENDED_B *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_E *Character_UnicodeBlock

var Character_UnicodeBlock_COPTIC_EPACT_NUMBERS *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_PERMIC *Character_UnicodeBlock

var Character_UnicodeBlock_ELBASAN *Character_UnicodeBlock

var Character_UnicodeBlock_CAUCASIAN_ALBANIAN *Character_UnicodeBlock

var Character_UnicodeBlock_LINEAR_A *Character_UnicodeBlock

var Character_UnicodeBlock_PALMYRENE *Character_UnicodeBlock

var Character_UnicodeBlock_NABATAEAN *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_NORTH_ARABIAN *Character_UnicodeBlock

var Character_UnicodeBlock_MANICHAEAN *Character_UnicodeBlock

var Character_UnicodeBlock_PSALTER_PAHLAVI *Character_UnicodeBlock

var Character_UnicodeBlock_MAHAJANI *Character_UnicodeBlock

var Character_UnicodeBlock_SINHALA_ARCHAIC_NUMBERS *Character_UnicodeBlock

var Character_UnicodeBlock_KHOJKI *Character_UnicodeBlock

var Character_UnicodeBlock_KHUDAWADI *Character_UnicodeBlock

var Character_UnicodeBlock_GRANTHA *Character_UnicodeBlock

var Character_UnicodeBlock_TIRHUTA *Character_UnicodeBlock

var Character_UnicodeBlock_SIDDHAM *Character_UnicodeBlock

var Character_UnicodeBlock_MODI *Character_UnicodeBlock

var Character_UnicodeBlock_WARANG_CITI *Character_UnicodeBlock

var Character_UnicodeBlock_PAU_CIN_HAU *Character_UnicodeBlock

var Character_UnicodeBlock_MRO *Character_UnicodeBlock

var Character_UnicodeBlock_BASSA_VAH *Character_UnicodeBlock

var Character_UnicodeBlock_PAHAWH_HMONG *Character_UnicodeBlock

var Character_UnicodeBlock_DUPLOYAN *Character_UnicodeBlock

var Character_UnicodeBlock_SHORTHAND_FORMAT_CONTROLS *Character_UnicodeBlock

var Character_UnicodeBlock_MENDE_KIKAKUI *Character_UnicodeBlock

var Character_UnicodeBlock_ORNAMENTAL_DINGBATS *Character_UnicodeBlock

var Character_UnicodeBlock_GEOMETRIC_SHAPES_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_C *Character_UnicodeBlock

var Character_UnicodeBlock_CHEROKEE_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_HATRAN *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_HUNGARIAN *Character_UnicodeBlock

var Character_UnicodeBlock_MULTANI *Character_UnicodeBlock

var Character_UnicodeBlock_AHOM *Character_UnicodeBlock

var Character_UnicodeBlock_EARLY_DYNASTIC_CUNEIFORM *Character_UnicodeBlock

var Character_UnicodeBlock_ANATOLIAN_HIEROGLYPHS *Character_UnicodeBlock

var Character_UnicodeBlock_SUTTON_SIGNWRITING *Character_UnicodeBlock

var Character_UnicodeBlock_SUPPLEMENTAL_SYMBOLS_AND_PICTOGRAPHS *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_E *Character_UnicodeBlock

var Character_UnicodeBlock_SYRIAC_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_CYRILLIC_EXTENDED_C *Character_UnicodeBlock

var Character_UnicodeBlock_OSAGE *Character_UnicodeBlock

var Character_UnicodeBlock_NEWA *Character_UnicodeBlock

var Character_UnicodeBlock_MONGOLIAN_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_MARCHEN *Character_UnicodeBlock

var Character_UnicodeBlock_IDEOGRAPHIC_SYMBOLS_AND_PUNCTUATION *Character_UnicodeBlock

var Character_UnicodeBlock_TANGUT *Character_UnicodeBlock

var Character_UnicodeBlock_TANGUT_COMPONENTS *Character_UnicodeBlock

var Character_UnicodeBlock_KANA_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_GLAGOLITIC_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_ADLAM *Character_UnicodeBlock

var Character_UnicodeBlock_MASARAM_GONDI *Character_UnicodeBlock

var Character_UnicodeBlock_ZANABAZAR_SQUARE *Character_UnicodeBlock

var Character_UnicodeBlock_NUSHU *Character_UnicodeBlock

var Character_UnicodeBlock_SOYOMBO *Character_UnicodeBlock

var Character_UnicodeBlock_BHAIKSUKI *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_F *Character_UnicodeBlock

var Character_UnicodeBlock_GEORGIAN_EXTENDED *Character_UnicodeBlock

var Character_UnicodeBlock_HANIFI_ROHINGYA *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_SOGDIAN *Character_UnicodeBlock

var Character_UnicodeBlock_SOGDIAN *Character_UnicodeBlock

var Character_UnicodeBlock_DOGRA *Character_UnicodeBlock

var Character_UnicodeBlock_GUNJALA_GONDI *Character_UnicodeBlock

var Character_UnicodeBlock_MAKASAR *Character_UnicodeBlock

var Character_UnicodeBlock_MEDEFAIDRIN *Character_UnicodeBlock

var Character_UnicodeBlock_MAYAN_NUMERALS *Character_UnicodeBlock

var Character_UnicodeBlock_INDIC_SIYAQ_NUMBERS *Character_UnicodeBlock

var Character_UnicodeBlock_CHESS_SYMBOLS *Character_UnicodeBlock

var Character_UnicodeBlock_ELYMAIC *Character_UnicodeBlock

var Character_UnicodeBlock_NANDINAGARI *Character_UnicodeBlock

var Character_UnicodeBlock_TAMIL_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_EGYPTIAN_HIEROGLYPH_FORMAT_CONTROLS *Character_UnicodeBlock

var Character_UnicodeBlock_SMALL_KANA_EXTENSION *Character_UnicodeBlock

var Character_UnicodeBlock_NYIAKENG_PUACHUE_HMONG *Character_UnicodeBlock

var Character_UnicodeBlock_WANCHO *Character_UnicodeBlock

var Character_UnicodeBlock_OTTOMAN_SIYAQ_NUMBERS *Character_UnicodeBlock

var Character_UnicodeBlock_SYMBOLS_AND_PICTOGRAPHS_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_YEZIDI *Character_UnicodeBlock

var Character_UnicodeBlock_CHORASMIAN *Character_UnicodeBlock

var Character_UnicodeBlock_DIVES_AKURU *Character_UnicodeBlock

var Character_UnicodeBlock_LISU_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_KHITAN_SMALL_SCRIPT *Character_UnicodeBlock

var Character_UnicodeBlock_TANGUT_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_SYMBOLS_FOR_LEGACY_COMPUTING *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_G *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC_EXTENDED_B *Character_UnicodeBlock

var Character_UnicodeBlock_VITHKUQI *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_F *Character_UnicodeBlock

var Character_UnicodeBlock_OLD_UYGHUR *Character_UnicodeBlock

var Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_CYPRO_MINOAN *Character_UnicodeBlock

var Character_UnicodeBlock_TANGSA *Character_UnicodeBlock

var Character_UnicodeBlock_KANA_EXTENDED_B *Character_UnicodeBlock

var Character_UnicodeBlock_ZNAMENNY_MUSICAL_NOTATION *Character_UnicodeBlock

var Character_UnicodeBlock_LATIN_EXTENDED_G *Character_UnicodeBlock

var Character_UnicodeBlock_TOTO *Character_UnicodeBlock

var Character_UnicodeBlock_ETHIOPIC_EXTENDED_B *Character_UnicodeBlock

var Character_UnicodeBlock_ARABIC_EXTENDED_C *Character_UnicodeBlock

var Character_UnicodeBlock_DEVANAGARI_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_KAWI *Character_UnicodeBlock

var Character_UnicodeBlock_KAKTOVIK_NUMERALS *Character_UnicodeBlock

var Character_UnicodeBlock_CYRILLIC_EXTENDED_D *Character_UnicodeBlock

var Character_UnicodeBlock_NAG_MUNDARI *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_H *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_I *Character_UnicodeBlock

var Character_UnicodeBlock_TODHRI *Character_UnicodeBlock

var Character_UnicodeBlock_GARAY *Character_UnicodeBlock

var Character_UnicodeBlock_TULU_TIGALARI *Character_UnicodeBlock

var Character_UnicodeBlock_MYANMAR_EXTENDED_C *Character_UnicodeBlock

var Character_UnicodeBlock_SUNUWAR *Character_UnicodeBlock

var Character_UnicodeBlock_EGYPTIAN_HIEROGLYPHS_EXTENDED_A *Character_UnicodeBlock

var Character_UnicodeBlock_GURUNG_KHEMA *Character_UnicodeBlock

var Character_UnicodeBlock_KIRAT_RAI *Character_UnicodeBlock

var Character_UnicodeBlock_SYMBOLS_FOR_LEGACY_COMPUTING_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_OL_ONAL *Character_UnicodeBlock

var Character_UnicodeBlock_SIDETIC *Character_UnicodeBlock

var Character_UnicodeBlock_SHARADA_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_TOLONG_SIKI *Character_UnicodeBlock

var Character_UnicodeBlock_BERIA_ERFE *Character_UnicodeBlock

var Character_UnicodeBlock_TANGUT_COMPONENTS_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_SUPPLEMENT *Character_UnicodeBlock

var Character_UnicodeBlock_TAI_YO *Character_UnicodeBlock

var Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_J *Character_UnicodeBlock

var Character_UnicodeBlock_blockStarts *IntArray

var Character_UnicodeBlock_blocks *RefArray

var Character_UnicodeBlock_init ClassInit

func Character_UnicodeBlock_Init() { if !Character_UnicodeBlock_init.Done() { Character_UnicodeBlock_init.Run(Character_UnicodeBlock_clinit) } }

func Character_UnicodeBlock_clinit() { Character_UnicodeBlock_map = HashMap_NewHashMap_I__HashMap(804); Character_UnicodeBlock_BASIC_LATIN = Character_UnicodeBlock_New_String_String1(Lit_118, RefArrayOf(String_class, Lit_119, Lit_120)); Character_UnicodeBlock_LATIN_1_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_121, RefArrayOf(String_class, Lit_122, Lit_123)); Character_UnicodeBlock_LATIN_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_124, RefArrayOf(String_class, Lit_125, Lit_126)); Character_UnicodeBlock_LATIN_EXTENDED_B = Character_UnicodeBlock_New_String_String1(Lit_127, RefArrayOf(String_class, Lit_128, Lit_129)); Character_UnicodeBlock_IPA_EXTENSIONS = Character_UnicodeBlock_New_String_String1(Lit_130, RefArrayOf(String_class, Lit_131, Lit_132)); Character_UnicodeBlock_SPACING_MODIFIER_LETTERS = Character_UnicodeBlock_New_String_String1(Lit_133, RefArrayOf(String_class, Lit_134, Lit_135)); Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS = Character_UnicodeBlock_New_String_String1(Lit_136, RefArrayOf(String_class, Lit_137, Lit_138)); Character_UnicodeBlock_GREEK = Character_UnicodeBlock_New_String_String1(Lit_139, RefArrayOf(String_class, Lit_140, Lit_141)); Character_UnicodeBlock_CYRILLIC = Character_UnicodeBlock_New_String(Lit_142); Character_UnicodeBlock_ARMENIAN = Character_UnicodeBlock_New_String(Lit_143); Character_UnicodeBlock_HEBREW = Character_UnicodeBlock_New_String(Lit_144); Character_UnicodeBlock_ARABIC = Character_UnicodeBlock_New_String(Lit_145); Character_UnicodeBlock_DEVANAGARI = Character_UnicodeBlock_New_String(Lit_146); Character_UnicodeBlock_BENGALI = Character_UnicodeBlock_New_String(Lit_147); Character_UnicodeBlock_GURMUKHI = Character_UnicodeBlock_New_String(Lit_148); Character_UnicodeBlock_GUJARATI = Character_UnicodeBlock_New_String(Lit_149); Character_UnicodeBlock_ORIYA = Character_UnicodeBlock_New_String(Lit_150); Character_UnicodeBlock_TAMIL = Character_UnicodeBlock_New_String(Lit_151); Character_UnicodeBlock_TELUGU = Character_UnicodeBlock_New_String(Lit_152); Character_UnicodeBlock_KANNADA = Character_UnicodeBlock_New_String(Lit_153); Character_UnicodeBlock_MALAYALAM = Character_UnicodeBlock_New_String(Lit_154); Character_UnicodeBlock_THAI = Character_UnicodeBlock_New_String(Lit_155); Character_UnicodeBlock_LAO = Character_UnicodeBlock_New_String(Lit_156); Character_UnicodeBlock_TIBETAN = Character_UnicodeBlock_New_String(Lit_157); Character_UnicodeBlock_GEORGIAN = Character_UnicodeBlock_New_String(Lit_158); Character_UnicodeBlock_HANGUL_JAMO = Character_UnicodeBlock_New_String_String1(Lit_159, RefArrayOf(String_class, Lit_160, Lit_161)); Character_UnicodeBlock_LATIN_EXTENDED_ADDITIONAL = Character_UnicodeBlock_New_String_String1(Lit_162, RefArrayOf(String_class, Lit_163, Lit_164)); Character_UnicodeBlock_GREEK_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_165, RefArrayOf(String_class, Lit_166, Lit_167)); Character_UnicodeBlock_GENERAL_PUNCTUATION = Character_UnicodeBlock_New_String_String1(Lit_168, RefArrayOf(String_class, Lit_169, Lit_170)); Character_UnicodeBlock_SUPERSCRIPTS_AND_SUBSCRIPTS = Character_UnicodeBlock_New_String_String1(Lit_171, RefArrayOf(String_class, Lit_172, Lit_173)); Character_UnicodeBlock_CURRENCY_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_174, RefArrayOf(String_class, Lit_175, Lit_176)); Character_UnicodeBlock_COMBINING_MARKS_FOR_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_177, ConstRefArray("[0,4,s39:COMBINING DIACRITICAL MARKS FOR SYMBOLSs35:COMBININGDIACRITICALMARKSFORSYMBOLSs27:COMBINING MARKS FOR SYMBOLSs24:COMBININGMARKSFORSYMBOLS", []*Class{String_class})); Character_UnicodeBlock_LETTERLIKE_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_178, RefArrayOf(String_class, Lit_179, Lit_180)); Character_UnicodeBlock_NUMBER_FORMS = Character_UnicodeBlock_New_String_String1(Lit_181, RefArrayOf(String_class, Lit_182, Lit_183)); Character_UnicodeBlock_ARROWS = Character_UnicodeBlock_New_String(Lit_184); Character_UnicodeBlock_MATHEMATICAL_OPERATORS = Character_UnicodeBlock_New_String_String1(Lit_185, RefArrayOf(String_class, Lit_186, Lit_187)); Character_UnicodeBlock_MISCELLANEOUS_TECHNICAL = Character_UnicodeBlock_New_String_String1(Lit_188, RefArrayOf(String_class, Lit_189, Lit_190)); Character_UnicodeBlock_CONTROL_PICTURES = Character_UnicodeBlock_New_String_String1(Lit_191, RefArrayOf(String_class, Lit_192, Lit_193)); Character_UnicodeBlock_OPTICAL_CHARACTER_RECOGNITION = Character_UnicodeBlock_New_String_String1(Lit_194, RefArrayOf(String_class, Lit_195, Lit_196)); Character_UnicodeBlock_ENCLOSED_ALPHANUMERICS = Character_UnicodeBlock_New_String_String1(Lit_197, RefArrayOf(String_class, Lit_198, Lit_199)); Character_UnicodeBlock_BOX_DRAWING = Character_UnicodeBlock_New_String_String1(Lit_200, RefArrayOf(String_class, Lit_201, Lit_202)); Character_UnicodeBlock_BLOCK_ELEMENTS = Character_UnicodeBlock_New_String_String1(Lit_203, RefArrayOf(String_class, Lit_204, Lit_205)); Character_UnicodeBlock_GEOMETRIC_SHAPES = Character_UnicodeBlock_New_String_String1(Lit_206, RefArrayOf(String_class, Lit_207, Lit_208)); Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_209, RefArrayOf(String_class, Lit_210, Lit_211)); Character_UnicodeBlock_DINGBATS = Character_UnicodeBlock_New_String(Lit_212); Character_UnicodeBlock_CJK_SYMBOLS_AND_PUNCTUATION = Character_UnicodeBlock_New_String_String1(Lit_213, RefArrayOf(String_class, Lit_214, Lit_215)); Character_UnicodeBlock_HIRAGANA = Character_UnicodeBlock_New_String(Lit_216); Character_UnicodeBlock_KATAKANA = Character_UnicodeBlock_New_String(Lit_217); Character_UnicodeBlock_BOPOMOFO = Character_UnicodeBlock_New_String(Lit_218); Character_UnicodeBlock_HANGUL_COMPATIBILITY_JAMO = Character_UnicodeBlock_New_String_String1(Lit_219, RefArrayOf(String_class, Lit_220, Lit_221)); Character_UnicodeBlock_KANBUN = Character_UnicodeBlock_New_String(Lit_222); Character_UnicodeBlock_ENCLOSED_CJK_LETTERS_AND_MONTHS = Character_UnicodeBlock_New_String_String1(Lit_223, RefArrayOf(String_class, Lit_224, Lit_225)); Character_UnicodeBlock_CJK_COMPATIBILITY = Character_UnicodeBlock_New_String_String1(Lit_226, RefArrayOf(String_class, Lit_227, Lit_228)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS = Character_UnicodeBlock_New_String_String1(Lit_229, RefArrayOf(String_class, Lit_230, Lit_231)); Character_UnicodeBlock_HANGUL_SYLLABLES = Character_UnicodeBlock_New_String_String1(Lit_232, RefArrayOf(String_class, Lit_233, Lit_234)); Character_UnicodeBlock_PRIVATE_USE_AREA = Character_UnicodeBlock_New_String_String1(Lit_235, RefArrayOf(String_class, Lit_236, Lit_237)); Character_UnicodeBlock_CJK_COMPATIBILITY_IDEOGRAPHS = Character_UnicodeBlock_New_String_String1(Lit_238, RefArrayOf(String_class, Lit_239, Lit_240)); Character_UnicodeBlock_ALPHABETIC_PRESENTATION_FORMS = Character_UnicodeBlock_New_String_String1(Lit_241, RefArrayOf(String_class, Lit_242, Lit_243)); Character_UnicodeBlock_ARABIC_PRESENTATION_FORMS_A = Character_UnicodeBlock_New_String_String1(Lit_244, RefArrayOf(String_class, Lit_245, Lit_246)); Character_UnicodeBlock_COMBINING_HALF_MARKS = Character_UnicodeBlock_New_String_String1(Lit_247, RefArrayOf(String_class, Lit_248, Lit_249)); Character_UnicodeBlock_CJK_COMPATIBILITY_FORMS = Character_UnicodeBlock_New_String_String1(Lit_250, RefArrayOf(String_class, Lit_251, Lit_252)); Character_UnicodeBlock_SMALL_FORM_VARIANTS = Character_UnicodeBlock_New_String_String1(Lit_253, RefArrayOf(String_class, Lit_254, Lit_255)); Character_UnicodeBlock_ARABIC_PRESENTATION_FORMS_B = Character_UnicodeBlock_New_String_String1(Lit_256, RefArrayOf(String_class, Lit_257, Lit_258)); Character_UnicodeBlock_HALFWIDTH_AND_FULLWIDTH_FORMS = Character_UnicodeBlock_New_String_String1(Lit_259, RefArrayOf(String_class, Lit_260, Lit_261)); Character_UnicodeBlock_SPECIALS = Character_UnicodeBlock_New_String(Lit_262); Character_UnicodeBlock_SURROGATES_AREA = Character_UnicodeBlock_New_String(Lit_263); Character_UnicodeBlock_SYRIAC = Character_UnicodeBlock_New_String(Lit_264); Character_UnicodeBlock_THAANA = Character_UnicodeBlock_New_String(Lit_265); Character_UnicodeBlock_SINHALA = Character_UnicodeBlock_New_String(Lit_266); Character_UnicodeBlock_MYANMAR = Character_UnicodeBlock_New_String(Lit_267); Character_UnicodeBlock_ETHIOPIC = Character_UnicodeBlock_New_String(Lit_268); Character_UnicodeBlock_CHEROKEE = Character_UnicodeBlock_New_String(Lit_269); Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS = Character_UnicodeBlock_New_String_String1(Lit_270, RefArrayOf(String_class, Lit_271, Lit_272)); Character_UnicodeBlock_OGHAM = Character_UnicodeBlock_New_String(Lit_273); Character_UnicodeBlock_RUNIC = Character_UnicodeBlock_New_String(Lit_274); Character_UnicodeBlock_KHMER = Character_UnicodeBlock_New_String(Lit_275); Character_UnicodeBlock_MONGOLIAN = Character_UnicodeBlock_New_String(Lit_276); Character_UnicodeBlock_BRAILLE_PATTERNS = Character_UnicodeBlock_New_String_String1(Lit_277, RefArrayOf(String_class, Lit_278, Lit_279)); Character_UnicodeBlock_CJK_RADICALS_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_280, RefArrayOf(String_class, Lit_281, Lit_282)); Character_UnicodeBlock_KANGXI_RADICALS = Character_UnicodeBlock_New_String_String1(Lit_283, RefArrayOf(String_class, Lit_284, Lit_285)); Character_UnicodeBlock_IDEOGRAPHIC_DESCRIPTION_CHARACTERS = Character_UnicodeBlock_New_String_String1(Lit_286, RefArrayOf(String_class, Lit_287, Lit_288)); Character_UnicodeBlock_BOPOMOFO_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_289, RefArrayOf(String_class, Lit_290, Lit_291)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A = Character_UnicodeBlock_New_String_String1(Lit_292, RefArrayOf(String_class, Lit_293, Lit_294)); Character_UnicodeBlock_YI_SYLLABLES = Character_UnicodeBlock_New_String_String1(Lit_295, RefArrayOf(String_class, Lit_296, Lit_297)); Character_UnicodeBlock_YI_RADICALS = Character_UnicodeBlock_New_String_String1(Lit_298, RefArrayOf(String_class, Lit_299, Lit_300)); Character_UnicodeBlock_CYRILLIC_SUPPLEMENTARY = Character_UnicodeBlock_New_String_String1(Lit_301, ConstRefArray("[0,4,s22:CYRILLIC SUPPLEMENTARYs21:CYRILLICSUPPLEMENTARYs19:CYRILLIC SUPPLEMENTs18:CYRILLICSUPPLEMENT", []*Class{String_class})); Character_UnicodeBlock_TAGALOG = Character_UnicodeBlock_New_String(Lit_302); Character_UnicodeBlock_HANUNOO = Character_UnicodeBlock_New_String(Lit_303); Character_UnicodeBlock_BUHID = Character_UnicodeBlock_New_String(Lit_304); Character_UnicodeBlock_TAGBANWA = Character_UnicodeBlock_New_String(Lit_305); Character_UnicodeBlock_LIMBU = Character_UnicodeBlock_New_String(Lit_306); Character_UnicodeBlock_TAI_LE = Character_UnicodeBlock_New_String_String1(Lit_307, RefArrayOf(String_class, Lit_308, Lit_309)); Character_UnicodeBlock_KHMER_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_310, RefArrayOf(String_class, Lit_311, Lit_312)); Character_UnicodeBlock_PHONETIC_EXTENSIONS = Character_UnicodeBlock_New_String_String1(Lit_313, RefArrayOf(String_class, Lit_314, Lit_315)); Character_UnicodeBlock_MISCELLANEOUS_MATHEMATICAL_SYMBOLS_A = Character_UnicodeBlock_New_String_String1(Lit_316, RefArrayOf(String_class, Lit_317, Lit_318)); Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_A = Character_UnicodeBlock_New_String_String1(Lit_319, RefArrayOf(String_class, Lit_320, Lit_321)); Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_B = Character_UnicodeBlock_New_String_String1(Lit_322, RefArrayOf(String_class, Lit_323, Lit_324)); Character_UnicodeBlock_MISCELLANEOUS_MATHEMATICAL_SYMBOLS_B = Character_UnicodeBlock_New_String_String1(Lit_325, RefArrayOf(String_class, Lit_326, Lit_327)); Character_UnicodeBlock_SUPPLEMENTAL_MATHEMATICAL_OPERATORS = Character_UnicodeBlock_New_String_String1(Lit_328, RefArrayOf(String_class, Lit_329, Lit_330)); Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_AND_ARROWS = Character_UnicodeBlock_New_String_String1(Lit_331, RefArrayOf(String_class, Lit_332, Lit_333)); Character_UnicodeBlock_KATAKANA_PHONETIC_EXTENSIONS = Character_UnicodeBlock_New_String_String1(Lit_334, RefArrayOf(String_class, Lit_335, Lit_336)); Character_UnicodeBlock_YIJING_HEXAGRAM_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_337, RefArrayOf(String_class, Lit_338, Lit_339)); Character_UnicodeBlock_VARIATION_SELECTORS = Character_UnicodeBlock_New_String_String1(Lit_340, RefArrayOf(String_class, Lit_341, Lit_342)); Character_UnicodeBlock_LINEAR_B_SYLLABARY = Character_UnicodeBlock_New_String_String1(Lit_343, RefArrayOf(String_class, Lit_344, Lit_345)); Character_UnicodeBlock_LINEAR_B_IDEOGRAMS = Character_UnicodeBlock_New_String_String1(Lit_346, RefArrayOf(String_class, Lit_347, Lit_348)); Character_UnicodeBlock_AEGEAN_NUMBERS = Character_UnicodeBlock_New_String_String1(Lit_349, RefArrayOf(String_class, Lit_350, Lit_351)); Character_UnicodeBlock_OLD_ITALIC = Character_UnicodeBlock_New_String_String1(Lit_352, RefArrayOf(String_class, Lit_353, Lit_354)); Character_UnicodeBlock_GOTHIC = Character_UnicodeBlock_New_String(Lit_355); Character_UnicodeBlock_UGARITIC = Character_UnicodeBlock_New_String(Lit_356); Character_UnicodeBlock_DESERET = Character_UnicodeBlock_New_String(Lit_357); Character_UnicodeBlock_SHAVIAN = Character_UnicodeBlock_New_String(Lit_358); Character_UnicodeBlock_OSMANYA = Character_UnicodeBlock_New_String(Lit_359); Character_UnicodeBlock_CYPRIOT_SYLLABARY = Character_UnicodeBlock_New_String_String1(Lit_360, RefArrayOf(String_class, Lit_361, Lit_362)); Character_UnicodeBlock_BYZANTINE_MUSICAL_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_363, RefArrayOf(String_class, Lit_364, Lit_365)); Character_UnicodeBlock_MUSICAL_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_366, RefArrayOf(String_class, Lit_367, Lit_368)); Character_UnicodeBlock_TAI_XUAN_JING_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_369, RefArrayOf(String_class, Lit_370, Lit_371)); Character_UnicodeBlock_MATHEMATICAL_ALPHANUMERIC_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_372, RefArrayOf(String_class, Lit_373, Lit_374)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B = Character_UnicodeBlock_New_String_String1(Lit_375, RefArrayOf(String_class, Lit_376, Lit_377)); Character_UnicodeBlock_CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_378, RefArrayOf(String_class, Lit_379, Lit_380)); Character_UnicodeBlock_TAGS = Character_UnicodeBlock_New_String(Lit_381); Character_UnicodeBlock_VARIATION_SELECTORS_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_382, RefArrayOf(String_class, Lit_383, Lit_384)); Character_UnicodeBlock_SUPPLEMENTARY_PRIVATE_USE_AREA_A = Character_UnicodeBlock_New_String_String1(Lit_385, RefArrayOf(String_class, Lit_386, Lit_387)); Character_UnicodeBlock_SUPPLEMENTARY_PRIVATE_USE_AREA_B = Character_UnicodeBlock_New_String_String1(Lit_388, RefArrayOf(String_class, Lit_389, Lit_390)); Character_UnicodeBlock_HIGH_SURROGATES = Character_UnicodeBlock_New_String_String1(Lit_391, RefArrayOf(String_class, Lit_392, Lit_393)); Character_UnicodeBlock_HIGH_PRIVATE_USE_SURROGATES = Character_UnicodeBlock_New_String_String1(Lit_394, RefArrayOf(String_class, Lit_395, Lit_396)); Character_UnicodeBlock_LOW_SURROGATES = Character_UnicodeBlock_New_String_String1(Lit_397, RefArrayOf(String_class, Lit_398, Lit_399)); Character_UnicodeBlock_ARABIC_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_400, RefArrayOf(String_class, Lit_401, Lit_402)); Character_UnicodeBlock_NKO = Character_UnicodeBlock_New_String(Lit_403); Character_UnicodeBlock_SAMARITAN = Character_UnicodeBlock_New_String(Lit_404); Character_UnicodeBlock_MANDAIC = Character_UnicodeBlock_New_String(Lit_405); Character_UnicodeBlock_ETHIOPIC_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_406, RefArrayOf(String_class, Lit_407, Lit_408)); Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_409, RefArrayOf(String_class, Lit_410, Lit_411)); Character_UnicodeBlock_NEW_TAI_LUE = Character_UnicodeBlock_New_String_String1(Lit_412, RefArrayOf(String_class, Lit_413, Lit_414)); Character_UnicodeBlock_BUGINESE = Character_UnicodeBlock_New_String(Lit_415); Character_UnicodeBlock_TAI_THAM = Character_UnicodeBlock_New_String_String1(Lit_416, RefArrayOf(String_class, Lit_417, Lit_418)); Character_UnicodeBlock_BALINESE = Character_UnicodeBlock_New_String(Lit_419); Character_UnicodeBlock_SUNDANESE = Character_UnicodeBlock_New_String(Lit_420); Character_UnicodeBlock_BATAK = Character_UnicodeBlock_New_String(Lit_421); Character_UnicodeBlock_LEPCHA = Character_UnicodeBlock_New_String(Lit_422); Character_UnicodeBlock_OL_CHIKI = Character_UnicodeBlock_New_String_String1(Lit_423, RefArrayOf(String_class, Lit_424, Lit_425)); Character_UnicodeBlock_VEDIC_EXTENSIONS = Character_UnicodeBlock_New_String_String1(Lit_426, RefArrayOf(String_class, Lit_427, Lit_428)); Character_UnicodeBlock_PHONETIC_EXTENSIONS_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_429, RefArrayOf(String_class, Lit_430, Lit_431)); Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_432, RefArrayOf(String_class, Lit_433, Lit_434)); Character_UnicodeBlock_GLAGOLITIC = Character_UnicodeBlock_New_String(Lit_435); Character_UnicodeBlock_LATIN_EXTENDED_C = Character_UnicodeBlock_New_String_String1(Lit_436, RefArrayOf(String_class, Lit_437, Lit_438)); Character_UnicodeBlock_COPTIC = Character_UnicodeBlock_New_String(Lit_439); Character_UnicodeBlock_GEORGIAN_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_440, RefArrayOf(String_class, Lit_441, Lit_442)); Character_UnicodeBlock_TIFINAGH = Character_UnicodeBlock_New_String(Lit_443); Character_UnicodeBlock_ETHIOPIC_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_444, RefArrayOf(String_class, Lit_445, Lit_446)); Character_UnicodeBlock_CYRILLIC_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_447, RefArrayOf(String_class, Lit_448, Lit_449)); Character_UnicodeBlock_SUPPLEMENTAL_PUNCTUATION = Character_UnicodeBlock_New_String_String1(Lit_450, RefArrayOf(String_class, Lit_451, Lit_452)); Character_UnicodeBlock_CJK_STROKES = Character_UnicodeBlock_New_String_String1(Lit_453, RefArrayOf(String_class, Lit_454, Lit_455)); Character_UnicodeBlock_LISU = Character_UnicodeBlock_New_String(Lit_456); Character_UnicodeBlock_VAI = Character_UnicodeBlock_New_String(Lit_457); Character_UnicodeBlock_CYRILLIC_EXTENDED_B = Character_UnicodeBlock_New_String_String1(Lit_458, RefArrayOf(String_class, Lit_459, Lit_460)); Character_UnicodeBlock_BAMUM = Character_UnicodeBlock_New_String(Lit_461); Character_UnicodeBlock_MODIFIER_TONE_LETTERS = Character_UnicodeBlock_New_String_String1(Lit_462, RefArrayOf(String_class, Lit_463, Lit_464)); Character_UnicodeBlock_LATIN_EXTENDED_D = Character_UnicodeBlock_New_String_String1(Lit_465, RefArrayOf(String_class, Lit_466, Lit_467)); Character_UnicodeBlock_SYLOTI_NAGRI = Character_UnicodeBlock_New_String_String1(Lit_468, RefArrayOf(String_class, Lit_469, Lit_470)); Character_UnicodeBlock_COMMON_INDIC_NUMBER_FORMS = Character_UnicodeBlock_New_String_String1(Lit_471, RefArrayOf(String_class, Lit_472, Lit_473)); Character_UnicodeBlock_PHAGS_PA = Character_UnicodeBlock_New_String_String(Lit_474, Lit_475); Character_UnicodeBlock_SAURASHTRA = Character_UnicodeBlock_New_String(Lit_476); Character_UnicodeBlock_DEVANAGARI_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_477, RefArrayOf(String_class, Lit_478, Lit_479)); Character_UnicodeBlock_KAYAH_LI = Character_UnicodeBlock_New_String_String1(Lit_480, RefArrayOf(String_class, Lit_481, Lit_482)); Character_UnicodeBlock_REJANG = Character_UnicodeBlock_New_String(Lit_483); Character_UnicodeBlock_HANGUL_JAMO_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_484, RefArrayOf(String_class, Lit_485, Lit_486)); Character_UnicodeBlock_JAVANESE = Character_UnicodeBlock_New_String(Lit_487); Character_UnicodeBlock_CHAM = Character_UnicodeBlock_New_String(Lit_488); Character_UnicodeBlock_MYANMAR_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_489, RefArrayOf(String_class, Lit_490, Lit_491)); Character_UnicodeBlock_TAI_VIET = Character_UnicodeBlock_New_String_String1(Lit_492, RefArrayOf(String_class, Lit_493, Lit_494)); Character_UnicodeBlock_ETHIOPIC_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_495, RefArrayOf(String_class, Lit_496, Lit_497)); Character_UnicodeBlock_MEETEI_MAYEK = Character_UnicodeBlock_New_String_String1(Lit_498, RefArrayOf(String_class, Lit_499, Lit_500)); Character_UnicodeBlock_HANGUL_JAMO_EXTENDED_B = Character_UnicodeBlock_New_String_String1(Lit_501, RefArrayOf(String_class, Lit_502, Lit_503)); Character_UnicodeBlock_VERTICAL_FORMS = Character_UnicodeBlock_New_String_String1(Lit_504, RefArrayOf(String_class, Lit_505, Lit_506)); Character_UnicodeBlock_ANCIENT_GREEK_NUMBERS = Character_UnicodeBlock_New_String_String1(Lit_507, RefArrayOf(String_class, Lit_508, Lit_509)); Character_UnicodeBlock_ANCIENT_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_510, RefArrayOf(String_class, Lit_511, Lit_512)); Character_UnicodeBlock_PHAISTOS_DISC = Character_UnicodeBlock_New_String_String1(Lit_513, RefArrayOf(String_class, Lit_514, Lit_515)); Character_UnicodeBlock_LYCIAN = Character_UnicodeBlock_New_String(Lit_516); Character_UnicodeBlock_CARIAN = Character_UnicodeBlock_New_String(Lit_517); Character_UnicodeBlock_OLD_PERSIAN = Character_UnicodeBlock_New_String_String1(Lit_518, RefArrayOf(String_class, Lit_519, Lit_520)); Character_UnicodeBlock_IMPERIAL_ARAMAIC = Character_UnicodeBlock_New_String_String1(Lit_521, RefArrayOf(String_class, Lit_522, Lit_523)); Character_UnicodeBlock_PHOENICIAN = Character_UnicodeBlock_New_String(Lit_524); Character_UnicodeBlock_LYDIAN = Character_UnicodeBlock_New_String(Lit_525); Character_UnicodeBlock_KHAROSHTHI = Character_UnicodeBlock_New_String(Lit_526); Character_UnicodeBlock_OLD_SOUTH_ARABIAN = Character_UnicodeBlock_New_String_String1(Lit_527, RefArrayOf(String_class, Lit_528, Lit_529)); Character_UnicodeBlock_AVESTAN = Character_UnicodeBlock_New_String(Lit_530); Character_UnicodeBlock_INSCRIPTIONAL_PARTHIAN = Character_UnicodeBlock_New_String_String1(Lit_531, RefArrayOf(String_class, Lit_532, Lit_533)); Character_UnicodeBlock_INSCRIPTIONAL_PAHLAVI = Character_UnicodeBlock_New_String_String1(Lit_534, RefArrayOf(String_class, Lit_535, Lit_536)); Character_UnicodeBlock_OLD_TURKIC = Character_UnicodeBlock_New_String_String1(Lit_537, RefArrayOf(String_class, Lit_538, Lit_539)); Character_UnicodeBlock_RUMI_NUMERAL_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_540, RefArrayOf(String_class, Lit_541, Lit_542)); Character_UnicodeBlock_BRAHMI = Character_UnicodeBlock_New_String(Lit_543); Character_UnicodeBlock_KAITHI = Character_UnicodeBlock_New_String(Lit_544); Character_UnicodeBlock_CUNEIFORM = Character_UnicodeBlock_New_String(Lit_545); Character_UnicodeBlock_CUNEIFORM_NUMBERS_AND_PUNCTUATION = Character_UnicodeBlock_New_String_String1(Lit_546, RefArrayOf(String_class, Lit_547, Lit_548)); Character_UnicodeBlock_EGYPTIAN_HIEROGLYPHS = Character_UnicodeBlock_New_String_String1(Lit_549, RefArrayOf(String_class, Lit_550, Lit_551)); Character_UnicodeBlock_BAMUM_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_552, RefArrayOf(String_class, Lit_553, Lit_554)); Character_UnicodeBlock_KANA_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_555, RefArrayOf(String_class, Lit_556, Lit_557)); Character_UnicodeBlock_ANCIENT_GREEK_MUSICAL_NOTATION = Character_UnicodeBlock_New_String_String1(Lit_558, RefArrayOf(String_class, Lit_559, Lit_560)); Character_UnicodeBlock_COUNTING_ROD_NUMERALS = Character_UnicodeBlock_New_String_String1(Lit_561, RefArrayOf(String_class, Lit_562, Lit_563)); Character_UnicodeBlock_MAHJONG_TILES = Character_UnicodeBlock_New_String_String1(Lit_564, RefArrayOf(String_class, Lit_565, Lit_566)); Character_UnicodeBlock_DOMINO_TILES = Character_UnicodeBlock_New_String_String1(Lit_567, RefArrayOf(String_class, Lit_568, Lit_569)); Character_UnicodeBlock_PLAYING_CARDS = Character_UnicodeBlock_New_String_String1(Lit_570, RefArrayOf(String_class, Lit_571, Lit_572)); Character_UnicodeBlock_ENCLOSED_ALPHANUMERIC_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_573, RefArrayOf(String_class, Lit_574, Lit_575)); Character_UnicodeBlock_ENCLOSED_IDEOGRAPHIC_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_576, RefArrayOf(String_class, Lit_577, Lit_578)); Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_AND_PICTOGRAPHS = Character_UnicodeBlock_New_String_String1(Lit_579, RefArrayOf(String_class, Lit_580, Lit_581)); Character_UnicodeBlock_EMOTICONS = Character_UnicodeBlock_New_String(Lit_582); Character_UnicodeBlock_TRANSPORT_AND_MAP_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_583, RefArrayOf(String_class, Lit_584, Lit_585)); Character_UnicodeBlock_ALCHEMICAL_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_586, RefArrayOf(String_class, Lit_587, Lit_588)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_C = Character_UnicodeBlock_New_String_String1(Lit_589, RefArrayOf(String_class, Lit_590, Lit_591)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_D = Character_UnicodeBlock_New_String_String1(Lit_592, RefArrayOf(String_class, Lit_593, Lit_594)); Character_UnicodeBlock_ARABIC_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_595, RefArrayOf(String_class, Lit_596, Lit_597)); Character_UnicodeBlock_SUNDANESE_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_598, RefArrayOf(String_class, Lit_599, Lit_600)); Character_UnicodeBlock_MEETEI_MAYEK_EXTENSIONS = Character_UnicodeBlock_New_String_String1(Lit_601, RefArrayOf(String_class, Lit_602, Lit_603)); Character_UnicodeBlock_MEROITIC_HIEROGLYPHS = Character_UnicodeBlock_New_String_String1(Lit_604, RefArrayOf(String_class, Lit_605, Lit_606)); Character_UnicodeBlock_MEROITIC_CURSIVE = Character_UnicodeBlock_New_String_String1(Lit_607, RefArrayOf(String_class, Lit_608, Lit_609)); Character_UnicodeBlock_SORA_SOMPENG = Character_UnicodeBlock_New_String_String1(Lit_610, RefArrayOf(String_class, Lit_611, Lit_612)); Character_UnicodeBlock_CHAKMA = Character_UnicodeBlock_New_String(Lit_613); Character_UnicodeBlock_SHARADA = Character_UnicodeBlock_New_String(Lit_614); Character_UnicodeBlock_TAKRI = Character_UnicodeBlock_New_String(Lit_615); Character_UnicodeBlock_MIAO = Character_UnicodeBlock_New_String(Lit_616); Character_UnicodeBlock_ARABIC_MATHEMATICAL_ALPHABETIC_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_617, RefArrayOf(String_class, Lit_618, Lit_619)); Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_620, RefArrayOf(String_class, Lit_621, Lit_622)); Character_UnicodeBlock_MYANMAR_EXTENDED_B = Character_UnicodeBlock_New_String_String1(Lit_623, RefArrayOf(String_class, Lit_624, Lit_625)); Character_UnicodeBlock_LATIN_EXTENDED_E = Character_UnicodeBlock_New_String_String1(Lit_626, RefArrayOf(String_class, Lit_627, Lit_628)); Character_UnicodeBlock_COPTIC_EPACT_NUMBERS = Character_UnicodeBlock_New_String_String1(Lit_629, RefArrayOf(String_class, Lit_630, Lit_631)); Character_UnicodeBlock_OLD_PERMIC = Character_UnicodeBlock_New_String_String1(Lit_632, RefArrayOf(String_class, Lit_633, Lit_634)); Character_UnicodeBlock_ELBASAN = Character_UnicodeBlock_New_String(Lit_635); Character_UnicodeBlock_CAUCASIAN_ALBANIAN = Character_UnicodeBlock_New_String_String1(Lit_636, RefArrayOf(String_class, Lit_637, Lit_638)); Character_UnicodeBlock_LINEAR_A = Character_UnicodeBlock_New_String_String1(Lit_639, RefArrayOf(String_class, Lit_640, Lit_641)); Character_UnicodeBlock_PALMYRENE = Character_UnicodeBlock_New_String(Lit_642); Character_UnicodeBlock_NABATAEAN = Character_UnicodeBlock_New_String(Lit_643); Character_UnicodeBlock_OLD_NORTH_ARABIAN = Character_UnicodeBlock_New_String_String1(Lit_644, RefArrayOf(String_class, Lit_645, Lit_646)); Character_UnicodeBlock_MANICHAEAN = Character_UnicodeBlock_New_String(Lit_647); Character_UnicodeBlock_PSALTER_PAHLAVI = Character_UnicodeBlock_New_String_String1(Lit_648, RefArrayOf(String_class, Lit_649, Lit_650)); Character_UnicodeBlock_MAHAJANI = Character_UnicodeBlock_New_String(Lit_651); Character_UnicodeBlock_SINHALA_ARCHAIC_NUMBERS = Character_UnicodeBlock_New_String_String1(Lit_652, RefArrayOf(String_class, Lit_653, Lit_654)); Character_UnicodeBlock_KHOJKI = Character_UnicodeBlock_New_String(Lit_655); Character_UnicodeBlock_KHUDAWADI = Character_UnicodeBlock_New_String(Lit_656); Character_UnicodeBlock_GRANTHA = Character_UnicodeBlock_New_String(Lit_657); Character_UnicodeBlock_TIRHUTA = Character_UnicodeBlock_New_String(Lit_658); Character_UnicodeBlock_SIDDHAM = Character_UnicodeBlock_New_String(Lit_659); Character_UnicodeBlock_MODI = Character_UnicodeBlock_New_String(Lit_660); Character_UnicodeBlock_WARANG_CITI = Character_UnicodeBlock_New_String_String1(Lit_661, RefArrayOf(String_class, Lit_662, Lit_663)); Character_UnicodeBlock_PAU_CIN_HAU = Character_UnicodeBlock_New_String_String1(Lit_664, RefArrayOf(String_class, Lit_665, Lit_666)); Character_UnicodeBlock_MRO = Character_UnicodeBlock_New_String(Lit_667); Character_UnicodeBlock_BASSA_VAH = Character_UnicodeBlock_New_String_String1(Lit_668, RefArrayOf(String_class, Lit_669, Lit_670)); Character_UnicodeBlock_PAHAWH_HMONG = Character_UnicodeBlock_New_String_String1(Lit_671, RefArrayOf(String_class, Lit_672, Lit_673)); Character_UnicodeBlock_DUPLOYAN = Character_UnicodeBlock_New_String(Lit_674); Character_UnicodeBlock_SHORTHAND_FORMAT_CONTROLS = Character_UnicodeBlock_New_String_String1(Lit_675, RefArrayOf(String_class, Lit_676, Lit_677)); Character_UnicodeBlock_MENDE_KIKAKUI = Character_UnicodeBlock_New_String_String1(Lit_678, RefArrayOf(String_class, Lit_679, Lit_680)); Character_UnicodeBlock_ORNAMENTAL_DINGBATS = Character_UnicodeBlock_New_String_String1(Lit_681, RefArrayOf(String_class, Lit_682, Lit_683)); Character_UnicodeBlock_GEOMETRIC_SHAPES_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_684, RefArrayOf(String_class, Lit_685, Lit_686)); Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_C = Character_UnicodeBlock_New_String_String1(Lit_687, RefArrayOf(String_class, Lit_688, Lit_689)); Character_UnicodeBlock_CHEROKEE_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_690, RefArrayOf(String_class, Lit_691, Lit_692)); Character_UnicodeBlock_HATRAN = Character_UnicodeBlock_New_String(Lit_693); Character_UnicodeBlock_OLD_HUNGARIAN = Character_UnicodeBlock_New_String_String1(Lit_694, RefArrayOf(String_class, Lit_695, Lit_696)); Character_UnicodeBlock_MULTANI = Character_UnicodeBlock_New_String(Lit_697); Character_UnicodeBlock_AHOM = Character_UnicodeBlock_New_String(Lit_698); Character_UnicodeBlock_EARLY_DYNASTIC_CUNEIFORM = Character_UnicodeBlock_New_String_String1(Lit_699, RefArrayOf(String_class, Lit_700, Lit_701)); Character_UnicodeBlock_ANATOLIAN_HIEROGLYPHS = Character_UnicodeBlock_New_String_String1(Lit_702, RefArrayOf(String_class, Lit_703, Lit_704)); Character_UnicodeBlock_SUTTON_SIGNWRITING = Character_UnicodeBlock_New_String_String1(Lit_705, RefArrayOf(String_class, Lit_706, Lit_707)); Character_UnicodeBlock_SUPPLEMENTAL_SYMBOLS_AND_PICTOGRAPHS = Character_UnicodeBlock_New_String_String1(Lit_708, RefArrayOf(String_class, Lit_709, Lit_710)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_E = Character_UnicodeBlock_New_String_String1(Lit_711, RefArrayOf(String_class, Lit_712, Lit_713)); Character_UnicodeBlock_SYRIAC_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_714, RefArrayOf(String_class, Lit_715, Lit_716)); Character_UnicodeBlock_CYRILLIC_EXTENDED_C = Character_UnicodeBlock_New_String_String1(Lit_717, RefArrayOf(String_class, Lit_718, Lit_719)); Character_UnicodeBlock_OSAGE = Character_UnicodeBlock_New_String(Lit_720); Character_UnicodeBlock_NEWA = Character_UnicodeBlock_New_String(Lit_721); Character_UnicodeBlock_MONGOLIAN_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_722, RefArrayOf(String_class, Lit_723, Lit_724)); Character_UnicodeBlock_MARCHEN = Character_UnicodeBlock_New_String(Lit_725); Character_UnicodeBlock_IDEOGRAPHIC_SYMBOLS_AND_PUNCTUATION = Character_UnicodeBlock_New_String_String1(Lit_726, RefArrayOf(String_class, Lit_727, Lit_728)); Character_UnicodeBlock_TANGUT = Character_UnicodeBlock_New_String(Lit_729); Character_UnicodeBlock_TANGUT_COMPONENTS = Character_UnicodeBlock_New_String_String1(Lit_730, RefArrayOf(String_class, Lit_731, Lit_732)); Character_UnicodeBlock_KANA_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_733, RefArrayOf(String_class, Lit_734, Lit_735)); Character_UnicodeBlock_GLAGOLITIC_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_736, RefArrayOf(String_class, Lit_737, Lit_738)); Character_UnicodeBlock_ADLAM = Character_UnicodeBlock_New_String(Lit_739); Character_UnicodeBlock_MASARAM_GONDI = Character_UnicodeBlock_New_String_String1(Lit_740, RefArrayOf(String_class, Lit_741, Lit_742)); Character_UnicodeBlock_ZANABAZAR_SQUARE = Character_UnicodeBlock_New_String_String1(Lit_743, RefArrayOf(String_class, Lit_744, Lit_745)); Character_UnicodeBlock_NUSHU = Character_UnicodeBlock_New_String(Lit_746); Character_UnicodeBlock_SOYOMBO = Character_UnicodeBlock_New_String(Lit_747); Character_UnicodeBlock_BHAIKSUKI = Character_UnicodeBlock_New_String(Lit_748); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_F = Character_UnicodeBlock_New_String_String1(Lit_749, RefArrayOf(String_class, Lit_750, Lit_751)); Character_UnicodeBlock_GEORGIAN_EXTENDED = Character_UnicodeBlock_New_String_String1(Lit_752, RefArrayOf(String_class, Lit_753, Lit_754)); Character_UnicodeBlock_HANIFI_ROHINGYA = Character_UnicodeBlock_New_String_String1(Lit_755, RefArrayOf(String_class, Lit_756, Lit_757)); Character_UnicodeBlock_OLD_SOGDIAN = Character_UnicodeBlock_New_String_String1(Lit_758, RefArrayOf(String_class, Lit_759, Lit_760)); Character_UnicodeBlock_SOGDIAN = Character_UnicodeBlock_New_String(Lit_761); Character_UnicodeBlock_DOGRA = Character_UnicodeBlock_New_String(Lit_762); Character_UnicodeBlock_GUNJALA_GONDI = Character_UnicodeBlock_New_String_String1(Lit_763, RefArrayOf(String_class, Lit_764, Lit_765)); Character_UnicodeBlock_MAKASAR = Character_UnicodeBlock_New_String(Lit_766); Character_UnicodeBlock_MEDEFAIDRIN = Character_UnicodeBlock_New_String(Lit_767); Character_UnicodeBlock_MAYAN_NUMERALS = Character_UnicodeBlock_New_String_String1(Lit_768, RefArrayOf(String_class, Lit_769, Lit_770)); Character_UnicodeBlock_INDIC_SIYAQ_NUMBERS = Character_UnicodeBlock_New_String_String1(Lit_771, RefArrayOf(String_class, Lit_772, Lit_773)); Character_UnicodeBlock_CHESS_SYMBOLS = Character_UnicodeBlock_New_String_String1(Lit_774, RefArrayOf(String_class, Lit_775, Lit_776)); Character_UnicodeBlock_ELYMAIC = Character_UnicodeBlock_New_String(Lit_777); Character_UnicodeBlock_NANDINAGARI = Character_UnicodeBlock_New_String(Lit_778); Character_UnicodeBlock_TAMIL_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_779, RefArrayOf(String_class, Lit_780, Lit_781)); Character_UnicodeBlock_EGYPTIAN_HIEROGLYPH_FORMAT_CONTROLS = Character_UnicodeBlock_New_String_String1(Lit_782, RefArrayOf(String_class, Lit_783, Lit_784)); Character_UnicodeBlock_SMALL_KANA_EXTENSION = Character_UnicodeBlock_New_String_String1(Lit_785, RefArrayOf(String_class, Lit_786, Lit_787)); Character_UnicodeBlock_NYIAKENG_PUACHUE_HMONG = Character_UnicodeBlock_New_String_String1(Lit_788, RefArrayOf(String_class, Lit_789, Lit_790)); Character_UnicodeBlock_WANCHO = Character_UnicodeBlock_New_String(Lit_791); Character_UnicodeBlock_OTTOMAN_SIYAQ_NUMBERS = Character_UnicodeBlock_New_String_String1(Lit_792, RefArrayOf(String_class, Lit_793, Lit_794)); Character_UnicodeBlock_SYMBOLS_AND_PICTOGRAPHS_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_795, RefArrayOf(String_class, Lit_796, Lit_797)); Character_UnicodeBlock_YEZIDI = Character_UnicodeBlock_New_String(Lit_798); Character_UnicodeBlock_CHORASMIAN = Character_UnicodeBlock_New_String(Lit_799); Character_UnicodeBlock_DIVES_AKURU = Character_UnicodeBlock_New_String_String1(Lit_800, RefArrayOf(String_class, Lit_801, Lit_802)); Character_UnicodeBlock_LISU_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_803, RefArrayOf(String_class, Lit_804, Lit_805)); Character_UnicodeBlock_KHITAN_SMALL_SCRIPT = Character_UnicodeBlock_New_String_String1(Lit_806, RefArrayOf(String_class, Lit_807, Lit_808)); Character_UnicodeBlock_TANGUT_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_809, RefArrayOf(String_class, Lit_810, Lit_811)); Character_UnicodeBlock_SYMBOLS_FOR_LEGACY_COMPUTING = Character_UnicodeBlock_New_String_String1(Lit_812, RefArrayOf(String_class, Lit_813, Lit_814)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_G = Character_UnicodeBlock_New_String_String1(Lit_815, RefArrayOf(String_class, Lit_816, Lit_817)); Character_UnicodeBlock_ARABIC_EXTENDED_B = Character_UnicodeBlock_New_String_String1(Lit_818, RefArrayOf(String_class, Lit_819, Lit_820)); Character_UnicodeBlock_VITHKUQI = Character_UnicodeBlock_New_String(Lit_821); Character_UnicodeBlock_LATIN_EXTENDED_F = Character_UnicodeBlock_New_String_String1(Lit_822, RefArrayOf(String_class, Lit_823, Lit_824)); Character_UnicodeBlock_OLD_UYGHUR = Character_UnicodeBlock_New_String_String1(Lit_825, RefArrayOf(String_class, Lit_826, Lit_827)); Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_828, RefArrayOf(String_class, Lit_829, Lit_830)); Character_UnicodeBlock_CYPRO_MINOAN = Character_UnicodeBlock_New_String_String1(Lit_831, RefArrayOf(String_class, Lit_832, Lit_832)); Character_UnicodeBlock_TANGSA = Character_UnicodeBlock_New_String(Lit_833); Character_UnicodeBlock_KANA_EXTENDED_B = Character_UnicodeBlock_New_String_String1(Lit_834, RefArrayOf(String_class, Lit_835, Lit_836)); Character_UnicodeBlock_ZNAMENNY_MUSICAL_NOTATION = Character_UnicodeBlock_New_String_String1(Lit_837, RefArrayOf(String_class, Lit_838, Lit_839)); Character_UnicodeBlock_LATIN_EXTENDED_G = Character_UnicodeBlock_New_String_String1(Lit_840, RefArrayOf(String_class, Lit_841, Lit_842)); Character_UnicodeBlock_TOTO = Character_UnicodeBlock_New_String(Lit_843); Character_UnicodeBlock_ETHIOPIC_EXTENDED_B = Character_UnicodeBlock_New_String_String1(Lit_844, RefArrayOf(String_class, Lit_845, Lit_846)); Character_UnicodeBlock_ARABIC_EXTENDED_C = Character_UnicodeBlock_New_String_String1(Lit_847, RefArrayOf(String_class, Lit_848, Lit_849)); Character_UnicodeBlock_DEVANAGARI_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_850, RefArrayOf(String_class, Lit_851, Lit_852)); Character_UnicodeBlock_KAWI = Character_UnicodeBlock_New_String(Lit_853); Character_UnicodeBlock_KAKTOVIK_NUMERALS = Character_UnicodeBlock_New_String_String1(Lit_854, RefArrayOf(String_class, Lit_855, Lit_856)); Character_UnicodeBlock_CYRILLIC_EXTENDED_D = Character_UnicodeBlock_New_String_String1(Lit_857, RefArrayOf(String_class, Lit_858, Lit_859)); Character_UnicodeBlock_NAG_MUNDARI = Character_UnicodeBlock_New_String_String1(Lit_860, RefArrayOf(String_class, Lit_861, Lit_862)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_H = Character_UnicodeBlock_New_String_String1(Lit_863, RefArrayOf(String_class, Lit_864, Lit_865)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_I = Character_UnicodeBlock_New_String_String1(Lit_866, RefArrayOf(String_class, Lit_867, Lit_868)); Character_UnicodeBlock_TODHRI = Character_UnicodeBlock_New_String(Lit_869); Character_UnicodeBlock_GARAY = Character_UnicodeBlock_New_String(Lit_870); Character_UnicodeBlock_TULU_TIGALARI = Character_UnicodeBlock_New_String_String(Lit_871, Lit_872); Character_UnicodeBlock_MYANMAR_EXTENDED_C = Character_UnicodeBlock_New_String_String1(Lit_873, RefArrayOf(String_class, Lit_874, Lit_875)); Character_UnicodeBlock_SUNUWAR = Character_UnicodeBlock_New_String(Lit_876); Character_UnicodeBlock_EGYPTIAN_HIEROGLYPHS_EXTENDED_A = Character_UnicodeBlock_New_String_String1(Lit_877, RefArrayOf(String_class, Lit_878, Lit_879)); Character_UnicodeBlock_GURUNG_KHEMA = Character_UnicodeBlock_New_String_String1(Lit_880, RefArrayOf(String_class, Lit_881, Lit_882)); Character_UnicodeBlock_KIRAT_RAI = Character_UnicodeBlock_New_String_String1(Lit_883, RefArrayOf(String_class, Lit_884, Lit_885)); Character_UnicodeBlock_SYMBOLS_FOR_LEGACY_COMPUTING_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_886, RefArrayOf(String_class, Lit_887, Lit_888)); Character_UnicodeBlock_OL_ONAL = Character_UnicodeBlock_New_String_String1(Lit_889, RefArrayOf(String_class, Lit_890, Lit_891)); Character_UnicodeBlock_SIDETIC = Character_UnicodeBlock_New_String(Lit_892); Character_UnicodeBlock_SHARADA_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_893, RefArrayOf(String_class, Lit_894, Lit_895)); Character_UnicodeBlock_TOLONG_SIKI = Character_UnicodeBlock_New_String_String1(Lit_896, RefArrayOf(String_class, Lit_897, Lit_898)); Character_UnicodeBlock_BERIA_ERFE = Character_UnicodeBlock_New_String_String1(Lit_899, RefArrayOf(String_class, Lit_900, Lit_901)); Character_UnicodeBlock_TANGUT_COMPONENTS_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_902, RefArrayOf(String_class, Lit_903, Lit_904)); Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_SUPPLEMENT = Character_UnicodeBlock_New_String_String1(Lit_905, RefArrayOf(String_class, Lit_906, Lit_907)); Character_UnicodeBlock_TAI_YO = Character_UnicodeBlock_New_String_String1(Lit_908, RefArrayOf(String_class, Lit_909, Lit_910)); Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_J = Character_UnicodeBlock_New_String_String1(Lit_911, RefArrayOf(String_class, Lit_912, Lit_913)); Character_UnicodeBlock_blockStarts = IntArrayOf(0, 128, 256, 384, 592, 688, 768, 880, 1024, 1280, 1328, 1424, 1536, 1792, 1872, 1920, 1984, 2048, 2112, 2144, 2160, 2208, 2304, 2432, 2560, 2688, 2816, 2944, 3072, 3200, 3328, 3456, 3584, 3712, 3840, 4096, 4256, 4352, 4608, 4992, 5024, 5120, 5760, 5792, 5888, 5920, 5952, 5984, 6016, 6144, 6320, 6400, 6480, 6528, 6624, 6656, 6688, 6832, 6912, 7040, 7104, 7168, 7248, 7296, 7312, 7360, 7376, 7424, 7552, 7616, 7680, 7936, 8192, 8304, 8352, 8400, 8448, 8528, 8592, 8704, 8960, 9216, 9280, 9312, 9472, 9600, 9632, 9728, 9984, 10176, 10224, 10240, 10496, 10624, 10752, 11008, 11264, 11360, 11392, 11520, 11568, 11648, 11744, 11776, 11904, 12032, 12256, 12272, 12288, 12352, 12448, 12544, 12592, 12688, 12704, 12736, 12784, 12800, 13056, 13312, 19904, 19968, 40960, 42128, 42192, 42240, 42560, 42656, 42752, 42784, 43008, 43056, 43072, 43136, 43232, 43264, 43312, 43360, 43392, 43488, 43520, 43616, 43648, 43744, 43776, 43824, 43888, 43968, 44032, 55216, 55296, 56192, 56320, 57344, 63744, 64256, 64336, 65024, 65040, 65056, 65072, 65104, 65136, 65280, 65520, 65536, 65664, 65792, 65856, 65936, 66000, 66048, 66176, 66208, 66272, 66304, 66352, 66384, 66432, 66464, 66528, 66560, 66640, 66688, 66736, 66816, 66864, 66928, 67008, 67072, 67456, 67520, 67584, 67648, 67680, 67712, 67760, 67808, 67840, 67872, 67904, 67936, 67968, 68000, 68096, 68192, 68224, 68256, 68288, 68352, 68416, 68448, 68480, 68528, 68608, 68688, 68736, 68864, 68928, 69008, 69216, 69248, 69312, 69376, 69424, 69488, 69552, 69600, 69632, 69760, 69840, 69888, 69968, 70016, 70112, 70144, 70224, 70272, 70320, 70400, 70528, 70656, 70784, 70880, 71040, 71168, 71264, 71296, 71376, 71424, 71504, 71680, 71760, 71840, 71936, 72032, 72096, 72192, 72272, 72368, 72384, 72448, 72544, 72576, 72640, 72704, 72816, 72896, 72960, 73056, 73136, 73200, 73440, 73472, 73568, 73648, 73664, 73728, 74752, 74880, 75088, 77712, 77824, 78896, 78944, 82944, 83584, 90368, 90432, 92160, 92736, 92784, 92880, 92928, 93072, 93504, 93568, 93760, 93856, 93920, 93952, 94112, 94176, 94208, 100352, 101120, 101632, 101760, 101888, 110576, 110592, 110848, 110896, 110960, 111360, 113664, 113824, 113840, 117760, 118464, 118528, 118736, 118784, 119040, 119296, 119376, 119488, 119520, 119552, 119648, 119680, 119808, 120832, 121520, 122624, 122880, 122928, 123024, 123136, 123216, 123536, 123584, 123648, 124112, 124160, 124368, 124416, 124608, 124672, 124896, 124928, 125152, 125184, 125280, 126064, 126144, 126208, 126288, 126464, 126720, 126976, 127024, 127136, 127232, 127488, 127744, 128512, 128592, 128640, 128768, 128896, 129024, 129280, 129536, 129648, 129792, 130048, 131072, 173792, 173824, 177984, 178208, 183984, 191472, 192096, 194560, 195104, 196608, 201552, 205744, 210048, 917504, 917632, 917760, 918000, 983040, 1048576); Character_UnicodeBlock_blocks = RefArrayOf(Character_UnicodeBlock_class, Character_UnicodeBlock_BASIC_LATIN.Ref(), Character_UnicodeBlock_LATIN_1_SUPPLEMENT.Ref(), Character_UnicodeBlock_LATIN_EXTENDED_A.Ref(), Character_UnicodeBlock_LATIN_EXTENDED_B.Ref(), Character_UnicodeBlock_IPA_EXTENSIONS.Ref(), Character_UnicodeBlock_SPACING_MODIFIER_LETTERS.Ref(), Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS.Ref(), Character_UnicodeBlock_GREEK.Ref(), Character_UnicodeBlock_CYRILLIC.Ref(), Character_UnicodeBlock_CYRILLIC_SUPPLEMENTARY.Ref(), Character_UnicodeBlock_ARMENIAN.Ref(), Character_UnicodeBlock_HEBREW.Ref(), Character_UnicodeBlock_ARABIC.Ref(), Character_UnicodeBlock_SYRIAC.Ref(), Character_UnicodeBlock_ARABIC_SUPPLEMENT.Ref(), Character_UnicodeBlock_THAANA.Ref(), Character_UnicodeBlock_NKO.Ref(), Character_UnicodeBlock_SAMARITAN.Ref(), Character_UnicodeBlock_MANDAIC.Ref(), Character_UnicodeBlock_SYRIAC_SUPPLEMENT.Ref(), Character_UnicodeBlock_ARABIC_EXTENDED_B.Ref(), Character_UnicodeBlock_ARABIC_EXTENDED_A.Ref(), Character_UnicodeBlock_DEVANAGARI.Ref(), Character_UnicodeBlock_BENGALI.Ref(), Character_UnicodeBlock_GURMUKHI.Ref(), Character_UnicodeBlock_GUJARATI.Ref(), Character_UnicodeBlock_ORIYA.Ref(), Character_UnicodeBlock_TAMIL.Ref(), Character_UnicodeBlock_TELUGU.Ref(), Character_UnicodeBlock_KANNADA.Ref(), Character_UnicodeBlock_MALAYALAM.Ref(), Character_UnicodeBlock_SINHALA.Ref(), Character_UnicodeBlock_THAI.Ref(), Character_UnicodeBlock_LAO.Ref(), Character_UnicodeBlock_TIBETAN.Ref(), Character_UnicodeBlock_MYANMAR.Ref(), Character_UnicodeBlock_GEORGIAN.Ref(), Character_UnicodeBlock_HANGUL_JAMO.Ref(), Character_UnicodeBlock_ETHIOPIC.Ref(), Character_UnicodeBlock_ETHIOPIC_SUPPLEMENT.Ref(), Character_UnicodeBlock_CHEROKEE.Ref(), Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS.Ref(), Character_UnicodeBlock_OGHAM.Ref(), Character_UnicodeBlock_RUNIC.Ref(), Character_UnicodeBlock_TAGALOG.Ref(), Character_UnicodeBlock_HANUNOO.Ref(), Character_UnicodeBlock_BUHID.Ref(), Character_UnicodeBlock_TAGBANWA.Ref(), Character_UnicodeBlock_KHMER.Ref(), Character_UnicodeBlock_MONGOLIAN.Ref(), Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED.Ref(), Character_UnicodeBlock_LIMBU.Ref(), Character_UnicodeBlock_TAI_LE.Ref(), Character_UnicodeBlock_NEW_TAI_LUE.Ref(), Character_UnicodeBlock_KHMER_SYMBOLS.Ref(), Character_UnicodeBlock_BUGINESE.Ref(), Character_UnicodeBlock_TAI_THAM.Ref(), Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS_EXTENDED.Ref(), Character_UnicodeBlock_BALINESE.Ref(), Character_UnicodeBlock_SUNDANESE.Ref(), Character_UnicodeBlock_BATAK.Ref(), Character_UnicodeBlock_LEPCHA.Ref(), Character_UnicodeBlock_OL_CHIKI.Ref(), Character_UnicodeBlock_CYRILLIC_EXTENDED_C.Ref(), Character_UnicodeBlock_GEORGIAN_EXTENDED.Ref(), Character_UnicodeBlock_SUNDANESE_SUPPLEMENT.Ref(), Character_UnicodeBlock_VEDIC_EXTENSIONS.Ref(), Character_UnicodeBlock_PHONETIC_EXTENSIONS.Ref(), Character_UnicodeBlock_PHONETIC_EXTENSIONS_SUPPLEMENT.Ref(), Character_UnicodeBlock_COMBINING_DIACRITICAL_MARKS_SUPPLEMENT.Ref(), Character_UnicodeBlock_LATIN_EXTENDED_ADDITIONAL.Ref(), Character_UnicodeBlock_GREEK_EXTENDED.Ref(), Character_UnicodeBlock_GENERAL_PUNCTUATION.Ref(), Character_UnicodeBlock_SUPERSCRIPTS_AND_SUBSCRIPTS.Ref(), Character_UnicodeBlock_CURRENCY_SYMBOLS.Ref(), Character_UnicodeBlock_COMBINING_MARKS_FOR_SYMBOLS.Ref(), Character_UnicodeBlock_LETTERLIKE_SYMBOLS.Ref(), Character_UnicodeBlock_NUMBER_FORMS.Ref(), Character_UnicodeBlock_ARROWS.Ref(), Character_UnicodeBlock_MATHEMATICAL_OPERATORS.Ref(), Character_UnicodeBlock_MISCELLANEOUS_TECHNICAL.Ref(), Character_UnicodeBlock_CONTROL_PICTURES.Ref(), Character_UnicodeBlock_OPTICAL_CHARACTER_RECOGNITION.Ref(), Character_UnicodeBlock_ENCLOSED_ALPHANUMERICS.Ref(), Character_UnicodeBlock_BOX_DRAWING.Ref(), Character_UnicodeBlock_BLOCK_ELEMENTS.Ref(), Character_UnicodeBlock_GEOMETRIC_SHAPES.Ref(), Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS.Ref(), Character_UnicodeBlock_DINGBATS.Ref(), Character_UnicodeBlock_MISCELLANEOUS_MATHEMATICAL_SYMBOLS_A.Ref(), Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_A.Ref(), Character_UnicodeBlock_BRAILLE_PATTERNS.Ref(), Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_B.Ref(), Character_UnicodeBlock_MISCELLANEOUS_MATHEMATICAL_SYMBOLS_B.Ref(), Character_UnicodeBlock_SUPPLEMENTAL_MATHEMATICAL_OPERATORS.Ref(), Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_AND_ARROWS.Ref(), Character_UnicodeBlock_GLAGOLITIC.Ref(), Character_UnicodeBlock_LATIN_EXTENDED_C.Ref(), Character_UnicodeBlock_COPTIC.Ref(), Character_UnicodeBlock_GEORGIAN_SUPPLEMENT.Ref(), Character_UnicodeBlock_TIFINAGH.Ref(), Character_UnicodeBlock_ETHIOPIC_EXTENDED.Ref(), Character_UnicodeBlock_CYRILLIC_EXTENDED_A.Ref(), Character_UnicodeBlock_SUPPLEMENTAL_PUNCTUATION.Ref(), Character_UnicodeBlock_CJK_RADICALS_SUPPLEMENT.Ref(), Character_UnicodeBlock_KANGXI_RADICALS.Ref(), nil, Character_UnicodeBlock_IDEOGRAPHIC_DESCRIPTION_CHARACTERS.Ref(), Character_UnicodeBlock_CJK_SYMBOLS_AND_PUNCTUATION.Ref(), Character_UnicodeBlock_HIRAGANA.Ref(), Character_UnicodeBlock_KATAKANA.Ref(), Character_UnicodeBlock_BOPOMOFO.Ref(), Character_UnicodeBlock_HANGUL_COMPATIBILITY_JAMO.Ref(), Character_UnicodeBlock_KANBUN.Ref(), Character_UnicodeBlock_BOPOMOFO_EXTENDED.Ref(), Character_UnicodeBlock_CJK_STROKES.Ref(), Character_UnicodeBlock_KATAKANA_PHONETIC_EXTENSIONS.Ref(), Character_UnicodeBlock_ENCLOSED_CJK_LETTERS_AND_MONTHS.Ref(), Character_UnicodeBlock_CJK_COMPATIBILITY.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A.Ref(), Character_UnicodeBlock_YIJING_HEXAGRAM_SYMBOLS.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS.Ref(), Character_UnicodeBlock_YI_SYLLABLES.Ref(), Character_UnicodeBlock_YI_RADICALS.Ref(), Character_UnicodeBlock_LISU.Ref(), Character_UnicodeBlock_VAI.Ref(), Character_UnicodeBlock_CYRILLIC_EXTENDED_B.Ref(), Character_UnicodeBlock_BAMUM.Ref(), Character_UnicodeBlock_MODIFIER_TONE_LETTERS.Ref(), Character_UnicodeBlock_LATIN_EXTENDED_D.Ref(), Character_UnicodeBlock_SYLOTI_NAGRI.Ref(), Character_UnicodeBlock_COMMON_INDIC_NUMBER_FORMS.Ref(), Character_UnicodeBlock_PHAGS_PA.Ref(), Character_UnicodeBlock_SAURASHTRA.Ref(), Character_UnicodeBlock_DEVANAGARI_EXTENDED.Ref(), Character_UnicodeBlock_KAYAH_LI.Ref(), Character_UnicodeBlock_REJANG.Ref(), Character_UnicodeBlock_HANGUL_JAMO_EXTENDED_A.Ref(), Character_UnicodeBlock_JAVANESE.Ref(), Character_UnicodeBlock_MYANMAR_EXTENDED_B.Ref(), Character_UnicodeBlock_CHAM.Ref(), Character_UnicodeBlock_MYANMAR_EXTENDED_A.Ref(), Character_UnicodeBlock_TAI_VIET.Ref(), Character_UnicodeBlock_MEETEI_MAYEK_EXTENSIONS.Ref(), Character_UnicodeBlock_ETHIOPIC_EXTENDED_A.Ref(), Character_UnicodeBlock_LATIN_EXTENDED_E.Ref(), Character_UnicodeBlock_CHEROKEE_SUPPLEMENT.Ref(), Character_UnicodeBlock_MEETEI_MAYEK.Ref(), Character_UnicodeBlock_HANGUL_SYLLABLES.Ref(), Character_UnicodeBlock_HANGUL_JAMO_EXTENDED_B.Ref(), Character_UnicodeBlock_HIGH_SURROGATES.Ref(), Character_UnicodeBlock_HIGH_PRIVATE_USE_SURROGATES.Ref(), Character_UnicodeBlock_LOW_SURROGATES.Ref(), Character_UnicodeBlock_PRIVATE_USE_AREA.Ref(), Character_UnicodeBlock_CJK_COMPATIBILITY_IDEOGRAPHS.Ref(), Character_UnicodeBlock_ALPHABETIC_PRESENTATION_FORMS.Ref(), Character_UnicodeBlock_ARABIC_PRESENTATION_FORMS_A.Ref(), Character_UnicodeBlock_VARIATION_SELECTORS.Ref(), Character_UnicodeBlock_VERTICAL_FORMS.Ref(), Character_UnicodeBlock_COMBINING_HALF_MARKS.Ref(), Character_UnicodeBlock_CJK_COMPATIBILITY_FORMS.Ref(), Character_UnicodeBlock_SMALL_FORM_VARIANTS.Ref(), Character_UnicodeBlock_ARABIC_PRESENTATION_FORMS_B.Ref(), Character_UnicodeBlock_HALFWIDTH_AND_FULLWIDTH_FORMS.Ref(), Character_UnicodeBlock_SPECIALS.Ref(), Character_UnicodeBlock_LINEAR_B_SYLLABARY.Ref(), Character_UnicodeBlock_LINEAR_B_IDEOGRAMS.Ref(), Character_UnicodeBlock_AEGEAN_NUMBERS.Ref(), Character_UnicodeBlock_ANCIENT_GREEK_NUMBERS.Ref(), Character_UnicodeBlock_ANCIENT_SYMBOLS.Ref(), Character_UnicodeBlock_PHAISTOS_DISC.Ref(), nil, Character_UnicodeBlock_LYCIAN.Ref(), Character_UnicodeBlock_CARIAN.Ref(), Character_UnicodeBlock_COPTIC_EPACT_NUMBERS.Ref(), Character_UnicodeBlock_OLD_ITALIC.Ref(), Character_UnicodeBlock_GOTHIC.Ref(), Character_UnicodeBlock_OLD_PERMIC.Ref(), Character_UnicodeBlock_UGARITIC.Ref(), Character_UnicodeBlock_OLD_PERSIAN.Ref(), nil, Character_UnicodeBlock_DESERET.Ref(), Character_UnicodeBlock_SHAVIAN.Ref(), Character_UnicodeBlock_OSMANYA.Ref(), Character_UnicodeBlock_OSAGE.Ref(), Character_UnicodeBlock_ELBASAN.Ref(), Character_UnicodeBlock_CAUCASIAN_ALBANIAN.Ref(), Character_UnicodeBlock_VITHKUQI.Ref(), Character_UnicodeBlock_TODHRI.Ref(), Character_UnicodeBlock_LINEAR_A.Ref(), Character_UnicodeBlock_LATIN_EXTENDED_F.Ref(), nil, Character_UnicodeBlock_CYPRIOT_SYLLABARY.Ref(), Character_UnicodeBlock_IMPERIAL_ARAMAIC.Ref(), Character_UnicodeBlock_PALMYRENE.Ref(), Character_UnicodeBlock_NABATAEAN.Ref(), nil, Character_UnicodeBlock_HATRAN.Ref(), Character_UnicodeBlock_PHOENICIAN.Ref(), Character_UnicodeBlock_LYDIAN.Ref(), Character_UnicodeBlock_SIDETIC.Ref(), nil, Character_UnicodeBlock_MEROITIC_HIEROGLYPHS.Ref(), Character_UnicodeBlock_MEROITIC_CURSIVE.Ref(), Character_UnicodeBlock_KHAROSHTHI.Ref(), Character_UnicodeBlock_OLD_SOUTH_ARABIAN.Ref(), Character_UnicodeBlock_OLD_NORTH_ARABIAN.Ref(), nil, Character_UnicodeBlock_MANICHAEAN.Ref(), Character_UnicodeBlock_AVESTAN.Ref(), Character_UnicodeBlock_INSCRIPTIONAL_PARTHIAN.Ref(), Character_UnicodeBlock_INSCRIPTIONAL_PAHLAVI.Ref(), Character_UnicodeBlock_PSALTER_PAHLAVI.Ref(), nil, Character_UnicodeBlock_OLD_TURKIC.Ref(), nil, Character_UnicodeBlock_OLD_HUNGARIAN.Ref(), Character_UnicodeBlock_HANIFI_ROHINGYA.Ref(), Character_UnicodeBlock_GARAY.Ref(), nil, Character_UnicodeBlock_RUMI_NUMERAL_SYMBOLS.Ref(), Character_UnicodeBlock_YEZIDI.Ref(), Character_UnicodeBlock_ARABIC_EXTENDED_C.Ref(), Character_UnicodeBlock_OLD_SOGDIAN.Ref(), Character_UnicodeBlock_SOGDIAN.Ref(), Character_UnicodeBlock_OLD_UYGHUR.Ref(), Character_UnicodeBlock_CHORASMIAN.Ref(), Character_UnicodeBlock_ELYMAIC.Ref(), Character_UnicodeBlock_BRAHMI.Ref(), Character_UnicodeBlock_KAITHI.Ref(), Character_UnicodeBlock_SORA_SOMPENG.Ref(), Character_UnicodeBlock_CHAKMA.Ref(), Character_UnicodeBlock_MAHAJANI.Ref(), Character_UnicodeBlock_SHARADA.Ref(), Character_UnicodeBlock_SINHALA_ARCHAIC_NUMBERS.Ref(), Character_UnicodeBlock_KHOJKI.Ref(), nil, Character_UnicodeBlock_MULTANI.Ref(), Character_UnicodeBlock_KHUDAWADI.Ref(), Character_UnicodeBlock_GRANTHA.Ref(), Character_UnicodeBlock_TULU_TIGALARI.Ref(), Character_UnicodeBlock_NEWA.Ref(), Character_UnicodeBlock_TIRHUTA.Ref(), nil, Character_UnicodeBlock_SIDDHAM.Ref(), Character_UnicodeBlock_MODI.Ref(), Character_UnicodeBlock_MONGOLIAN_SUPPLEMENT.Ref(), Character_UnicodeBlock_TAKRI.Ref(), Character_UnicodeBlock_MYANMAR_EXTENDED_C.Ref(), Character_UnicodeBlock_AHOM.Ref(), nil, Character_UnicodeBlock_DOGRA.Ref(), nil, Character_UnicodeBlock_WARANG_CITI.Ref(), Character_UnicodeBlock_DIVES_AKURU.Ref(), nil, Character_UnicodeBlock_NANDINAGARI.Ref(), Character_UnicodeBlock_ZANABAZAR_SQUARE.Ref(), Character_UnicodeBlock_SOYOMBO.Ref(), Character_UnicodeBlock_UNIFIED_CANADIAN_ABORIGINAL_SYLLABICS_EXTENDED_A.Ref(), Character_UnicodeBlock_PAU_CIN_HAU.Ref(), Character_UnicodeBlock_DEVANAGARI_EXTENDED_A.Ref(), Character_UnicodeBlock_SHARADA_SUPPLEMENT.Ref(), nil, Character_UnicodeBlock_SUNUWAR.Ref(), Character_UnicodeBlock_BHAIKSUKI.Ref(), Character_UnicodeBlock_MARCHEN.Ref(), nil, Character_UnicodeBlock_MASARAM_GONDI.Ref(), Character_UnicodeBlock_GUNJALA_GONDI.Ref(), Character_UnicodeBlock_TOLONG_SIKI.Ref(), nil, Character_UnicodeBlock_MAKASAR.Ref(), Character_UnicodeBlock_KAWI.Ref(), nil, Character_UnicodeBlock_LISU_SUPPLEMENT.Ref(), Character_UnicodeBlock_TAMIL_SUPPLEMENT.Ref(), Character_UnicodeBlock_CUNEIFORM.Ref(), Character_UnicodeBlock_CUNEIFORM_NUMBERS_AND_PUNCTUATION.Ref(), Character_UnicodeBlock_EARLY_DYNASTIC_CUNEIFORM.Ref(), nil, Character_UnicodeBlock_CYPRO_MINOAN.Ref(), Character_UnicodeBlock_EGYPTIAN_HIEROGLYPHS.Ref(), Character_UnicodeBlock_EGYPTIAN_HIEROGLYPH_FORMAT_CONTROLS.Ref(), Character_UnicodeBlock_EGYPTIAN_HIEROGLYPHS_EXTENDED_A.Ref(), Character_UnicodeBlock_ANATOLIAN_HIEROGLYPHS.Ref(), nil, Character_UnicodeBlock_GURUNG_KHEMA.Ref(), nil, Character_UnicodeBlock_BAMUM_SUPPLEMENT.Ref(), Character_UnicodeBlock_MRO.Ref(), Character_UnicodeBlock_TANGSA.Ref(), Character_UnicodeBlock_BASSA_VAH.Ref(), Character_UnicodeBlock_PAHAWH_HMONG.Ref(), nil, Character_UnicodeBlock_KIRAT_RAI.Ref(), nil, Character_UnicodeBlock_MEDEFAIDRIN.Ref(), Character_UnicodeBlock_BERIA_ERFE.Ref(), nil, Character_UnicodeBlock_MIAO.Ref(), nil, Character_UnicodeBlock_IDEOGRAPHIC_SYMBOLS_AND_PUNCTUATION.Ref(), Character_UnicodeBlock_TANGUT.Ref(), Character_UnicodeBlock_TANGUT_COMPONENTS.Ref(), Character_UnicodeBlock_KHITAN_SMALL_SCRIPT.Ref(), Character_UnicodeBlock_TANGUT_SUPPLEMENT.Ref(), Character_UnicodeBlock_TANGUT_COMPONENTS_SUPPLEMENT.Ref(), nil, Character_UnicodeBlock_KANA_EXTENDED_B.Ref(), Character_UnicodeBlock_KANA_SUPPLEMENT.Ref(), Character_UnicodeBlock_KANA_EXTENDED_A.Ref(), Character_UnicodeBlock_SMALL_KANA_EXTENSION.Ref(), Character_UnicodeBlock_NUSHU.Ref(), nil, Character_UnicodeBlock_DUPLOYAN.Ref(), Character_UnicodeBlock_SHORTHAND_FORMAT_CONTROLS.Ref(), nil, Character_UnicodeBlock_SYMBOLS_FOR_LEGACY_COMPUTING_SUPPLEMENT.Ref(), Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_SUPPLEMENT.Ref(), Character_UnicodeBlock_ZNAMENNY_MUSICAL_NOTATION.Ref(), nil, Character_UnicodeBlock_BYZANTINE_MUSICAL_SYMBOLS.Ref(), Character_UnicodeBlock_MUSICAL_SYMBOLS.Ref(), Character_UnicodeBlock_ANCIENT_GREEK_MUSICAL_NOTATION.Ref(), nil, Character_UnicodeBlock_KAKTOVIK_NUMERALS.Ref(), Character_UnicodeBlock_MAYAN_NUMERALS.Ref(), Character_UnicodeBlock_TAI_XUAN_JING_SYMBOLS.Ref(), Character_UnicodeBlock_COUNTING_ROD_NUMERALS.Ref(), nil, Character_UnicodeBlock_MATHEMATICAL_ALPHANUMERIC_SYMBOLS.Ref(), Character_UnicodeBlock_SUTTON_SIGNWRITING.Ref(), nil, Character_UnicodeBlock_LATIN_EXTENDED_G.Ref(), Character_UnicodeBlock_GLAGOLITIC_SUPPLEMENT.Ref(), Character_UnicodeBlock_CYRILLIC_EXTENDED_D.Ref(), nil, Character_UnicodeBlock_NYIAKENG_PUACHUE_HMONG.Ref(), nil, Character_UnicodeBlock_TOTO.Ref(), Character_UnicodeBlock_WANCHO.Ref(), nil, Character_UnicodeBlock_NAG_MUNDARI.Ref(), nil, Character_UnicodeBlock_OL_ONAL.Ref(), nil, Character_UnicodeBlock_TAI_YO.Ref(), nil, Character_UnicodeBlock_ETHIOPIC_EXTENDED_B.Ref(), Character_UnicodeBlock_MENDE_KIKAKUI.Ref(), nil, Character_UnicodeBlock_ADLAM.Ref(), nil, Character_UnicodeBlock_INDIC_SIYAQ_NUMBERS.Ref(), nil, Character_UnicodeBlock_OTTOMAN_SIYAQ_NUMBERS.Ref(), nil, Character_UnicodeBlock_ARABIC_MATHEMATICAL_ALPHABETIC_SYMBOLS.Ref(), nil, Character_UnicodeBlock_MAHJONG_TILES.Ref(), Character_UnicodeBlock_DOMINO_TILES.Ref(), Character_UnicodeBlock_PLAYING_CARDS.Ref(), Character_UnicodeBlock_ENCLOSED_ALPHANUMERIC_SUPPLEMENT.Ref(), Character_UnicodeBlock_ENCLOSED_IDEOGRAPHIC_SUPPLEMENT.Ref(), Character_UnicodeBlock_MISCELLANEOUS_SYMBOLS_AND_PICTOGRAPHS.Ref(), Character_UnicodeBlock_EMOTICONS.Ref(), Character_UnicodeBlock_ORNAMENTAL_DINGBATS.Ref(), Character_UnicodeBlock_TRANSPORT_AND_MAP_SYMBOLS.Ref(), Character_UnicodeBlock_ALCHEMICAL_SYMBOLS.Ref(), Character_UnicodeBlock_GEOMETRIC_SHAPES_EXTENDED.Ref(), Character_UnicodeBlock_SUPPLEMENTAL_ARROWS_C.Ref(), Character_UnicodeBlock_SUPPLEMENTAL_SYMBOLS_AND_PICTOGRAPHS.Ref(), Character_UnicodeBlock_CHESS_SYMBOLS.Ref(), Character_UnicodeBlock_SYMBOLS_AND_PICTOGRAPHS_EXTENDED_A.Ref(), Character_UnicodeBlock_SYMBOLS_FOR_LEGACY_COMPUTING.Ref(), nil, Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B.Ref(), nil, Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_C.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_D.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_E.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_F.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_I.Ref(), nil, Character_UnicodeBlock_CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT.Ref(), nil, Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_G.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_H.Ref(), Character_UnicodeBlock_CJK_UNIFIED_IDEOGRAPHS_EXTENSION_J.Ref(), nil, Character_UnicodeBlock_TAGS.Ref(), nil, Character_UnicodeBlock_VARIATION_SELECTORS_SUPPLEMENT.Ref(), nil, Character_UnicodeBlock_SUPPLEMENTARY_PRIVATE_USE_AREA_A.Ref(), Character_UnicodeBlock_SUPPLEMENTARY_PRIVATE_USE_AREA_B.Ref()) }

func (t *Character_UnicodeBlock) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Character_UnicodeBlock) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Character_UnicodeBlock) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Character_UnicodeBlock) Ref() any { if t == nil { return nil }; return t }

func (t *Character_UnicodeBlock) GetClass__Class() *Class { return Character_UnicodeBlock_class }

func (t *Character_UnicodeBlock) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Character_UnicodeBlock) CloneShallow() any { panic(CloneNotSupported(t)) }

func Character_UnicodeBlock_InstanceOf(x any) bool { _, ok := x.(*Character_UnicodeBlock); return ok }

func Character_UnicodeBlock_Cast(x any) *Character_UnicodeBlock { if x == nil { return nil }; v, ok := x.(*Character_UnicodeBlock); if !ok { panic(ClassCast(x, Character_UnicodeBlock_class)) }; return v }



type Character_UnicodeScript struct{ Enum }

func (t *Character_UnicodeScript) Is_Constable() {}

var Character_UnicodeScript_COMMON *Character_UnicodeScript

var Character_UnicodeScript_LATIN *Character_UnicodeScript

var Character_UnicodeScript_GREEK *Character_UnicodeScript

var Character_UnicodeScript_CYRILLIC *Character_UnicodeScript

var Character_UnicodeScript_ARMENIAN *Character_UnicodeScript

var Character_UnicodeScript_HEBREW *Character_UnicodeScript

var Character_UnicodeScript_ARABIC *Character_UnicodeScript

var Character_UnicodeScript_SYRIAC *Character_UnicodeScript

var Character_UnicodeScript_THAANA *Character_UnicodeScript

var Character_UnicodeScript_DEVANAGARI *Character_UnicodeScript

var Character_UnicodeScript_BENGALI *Character_UnicodeScript

var Character_UnicodeScript_GURMUKHI *Character_UnicodeScript

var Character_UnicodeScript_GUJARATI *Character_UnicodeScript

var Character_UnicodeScript_ORIYA *Character_UnicodeScript

var Character_UnicodeScript_TAMIL *Character_UnicodeScript

var Character_UnicodeScript_TELUGU *Character_UnicodeScript

var Character_UnicodeScript_KANNADA *Character_UnicodeScript

var Character_UnicodeScript_MALAYALAM *Character_UnicodeScript

var Character_UnicodeScript_SINHALA *Character_UnicodeScript

var Character_UnicodeScript_THAI *Character_UnicodeScript

var Character_UnicodeScript_LAO *Character_UnicodeScript

var Character_UnicodeScript_TIBETAN *Character_UnicodeScript

var Character_UnicodeScript_MYANMAR *Character_UnicodeScript

var Character_UnicodeScript_GEORGIAN *Character_UnicodeScript

var Character_UnicodeScript_HANGUL *Character_UnicodeScript

var Character_UnicodeScript_ETHIOPIC *Character_UnicodeScript

var Character_UnicodeScript_CHEROKEE *Character_UnicodeScript

var Character_UnicodeScript_CANADIAN_ABORIGINAL *Character_UnicodeScript

var Character_UnicodeScript_OGHAM *Character_UnicodeScript

var Character_UnicodeScript_RUNIC *Character_UnicodeScript

var Character_UnicodeScript_KHMER *Character_UnicodeScript

var Character_UnicodeScript_MONGOLIAN *Character_UnicodeScript

var Character_UnicodeScript_HIRAGANA *Character_UnicodeScript

var Character_UnicodeScript_KATAKANA *Character_UnicodeScript

var Character_UnicodeScript_BOPOMOFO *Character_UnicodeScript

var Character_UnicodeScript_HAN *Character_UnicodeScript

var Character_UnicodeScript_YI *Character_UnicodeScript

var Character_UnicodeScript_OLD_ITALIC *Character_UnicodeScript

var Character_UnicodeScript_GOTHIC *Character_UnicodeScript

var Character_UnicodeScript_DESERET *Character_UnicodeScript

var Character_UnicodeScript_INHERITED *Character_UnicodeScript

var Character_UnicodeScript_TAGALOG *Character_UnicodeScript

var Character_UnicodeScript_HANUNOO *Character_UnicodeScript

var Character_UnicodeScript_BUHID *Character_UnicodeScript

var Character_UnicodeScript_TAGBANWA *Character_UnicodeScript

var Character_UnicodeScript_LIMBU *Character_UnicodeScript

var Character_UnicodeScript_TAI_LE *Character_UnicodeScript

var Character_UnicodeScript_LINEAR_B *Character_UnicodeScript

var Character_UnicodeScript_UGARITIC *Character_UnicodeScript

var Character_UnicodeScript_SHAVIAN *Character_UnicodeScript

var Character_UnicodeScript_OSMANYA *Character_UnicodeScript

var Character_UnicodeScript_CYPRIOT *Character_UnicodeScript

var Character_UnicodeScript_BRAILLE *Character_UnicodeScript

var Character_UnicodeScript_BUGINESE *Character_UnicodeScript

var Character_UnicodeScript_COPTIC *Character_UnicodeScript

var Character_UnicodeScript_NEW_TAI_LUE *Character_UnicodeScript

var Character_UnicodeScript_GLAGOLITIC *Character_UnicodeScript

var Character_UnicodeScript_TIFINAGH *Character_UnicodeScript

var Character_UnicodeScript_SYLOTI_NAGRI *Character_UnicodeScript

var Character_UnicodeScript_OLD_PERSIAN *Character_UnicodeScript

var Character_UnicodeScript_KHAROSHTHI *Character_UnicodeScript

var Character_UnicodeScript_BALINESE *Character_UnicodeScript

var Character_UnicodeScript_CUNEIFORM *Character_UnicodeScript

var Character_UnicodeScript_PHOENICIAN *Character_UnicodeScript

var Character_UnicodeScript_PHAGS_PA *Character_UnicodeScript

var Character_UnicodeScript_NKO *Character_UnicodeScript

var Character_UnicodeScript_SUNDANESE *Character_UnicodeScript

var Character_UnicodeScript_BATAK *Character_UnicodeScript

var Character_UnicodeScript_LEPCHA *Character_UnicodeScript

var Character_UnicodeScript_OL_CHIKI *Character_UnicodeScript

var Character_UnicodeScript_VAI *Character_UnicodeScript

var Character_UnicodeScript_SAURASHTRA *Character_UnicodeScript

var Character_UnicodeScript_KAYAH_LI *Character_UnicodeScript

var Character_UnicodeScript_REJANG *Character_UnicodeScript

var Character_UnicodeScript_LYCIAN *Character_UnicodeScript

var Character_UnicodeScript_CARIAN *Character_UnicodeScript

var Character_UnicodeScript_LYDIAN *Character_UnicodeScript

var Character_UnicodeScript_CHAM *Character_UnicodeScript

var Character_UnicodeScript_TAI_THAM *Character_UnicodeScript

var Character_UnicodeScript_TAI_VIET *Character_UnicodeScript

var Character_UnicodeScript_AVESTAN *Character_UnicodeScript

var Character_UnicodeScript_EGYPTIAN_HIEROGLYPHS *Character_UnicodeScript

var Character_UnicodeScript_SAMARITAN *Character_UnicodeScript

var Character_UnicodeScript_MANDAIC *Character_UnicodeScript

var Character_UnicodeScript_LISU *Character_UnicodeScript

var Character_UnicodeScript_BAMUM *Character_UnicodeScript

var Character_UnicodeScript_JAVANESE *Character_UnicodeScript

var Character_UnicodeScript_MEETEI_MAYEK *Character_UnicodeScript

var Character_UnicodeScript_IMPERIAL_ARAMAIC *Character_UnicodeScript

var Character_UnicodeScript_OLD_SOUTH_ARABIAN *Character_UnicodeScript

var Character_UnicodeScript_INSCRIPTIONAL_PARTHIAN *Character_UnicodeScript

var Character_UnicodeScript_INSCRIPTIONAL_PAHLAVI *Character_UnicodeScript

var Character_UnicodeScript_OLD_TURKIC *Character_UnicodeScript

var Character_UnicodeScript_BRAHMI *Character_UnicodeScript

var Character_UnicodeScript_KAITHI *Character_UnicodeScript

var Character_UnicodeScript_MEROITIC_HIEROGLYPHS *Character_UnicodeScript

var Character_UnicodeScript_MEROITIC_CURSIVE *Character_UnicodeScript

var Character_UnicodeScript_SORA_SOMPENG *Character_UnicodeScript

var Character_UnicodeScript_CHAKMA *Character_UnicodeScript

var Character_UnicodeScript_SHARADA *Character_UnicodeScript

var Character_UnicodeScript_TAKRI *Character_UnicodeScript

var Character_UnicodeScript_MIAO *Character_UnicodeScript

var Character_UnicodeScript_CAUCASIAN_ALBANIAN *Character_UnicodeScript

var Character_UnicodeScript_BASSA_VAH *Character_UnicodeScript

var Character_UnicodeScript_DUPLOYAN *Character_UnicodeScript

var Character_UnicodeScript_ELBASAN *Character_UnicodeScript

var Character_UnicodeScript_GRANTHA *Character_UnicodeScript

var Character_UnicodeScript_PAHAWH_HMONG *Character_UnicodeScript

var Character_UnicodeScript_KHOJKI *Character_UnicodeScript

var Character_UnicodeScript_LINEAR_A *Character_UnicodeScript

var Character_UnicodeScript_MAHAJANI *Character_UnicodeScript

var Character_UnicodeScript_MANICHAEAN *Character_UnicodeScript

var Character_UnicodeScript_MENDE_KIKAKUI *Character_UnicodeScript

var Character_UnicodeScript_MODI *Character_UnicodeScript

var Character_UnicodeScript_MRO *Character_UnicodeScript

var Character_UnicodeScript_OLD_NORTH_ARABIAN *Character_UnicodeScript

var Character_UnicodeScript_NABATAEAN *Character_UnicodeScript

var Character_UnicodeScript_PALMYRENE *Character_UnicodeScript

var Character_UnicodeScript_PAU_CIN_HAU *Character_UnicodeScript

var Character_UnicodeScript_OLD_PERMIC *Character_UnicodeScript

var Character_UnicodeScript_PSALTER_PAHLAVI *Character_UnicodeScript

var Character_UnicodeScript_SIDDHAM *Character_UnicodeScript

var Character_UnicodeScript_KHUDAWADI *Character_UnicodeScript

var Character_UnicodeScript_TIRHUTA *Character_UnicodeScript

var Character_UnicodeScript_WARANG_CITI *Character_UnicodeScript

var Character_UnicodeScript_AHOM *Character_UnicodeScript

var Character_UnicodeScript_ANATOLIAN_HIEROGLYPHS *Character_UnicodeScript

var Character_UnicodeScript_HATRAN *Character_UnicodeScript

var Character_UnicodeScript_MULTANI *Character_UnicodeScript

var Character_UnicodeScript_OLD_HUNGARIAN *Character_UnicodeScript

var Character_UnicodeScript_SIGNWRITING *Character_UnicodeScript

var Character_UnicodeScript_ADLAM *Character_UnicodeScript

var Character_UnicodeScript_BHAIKSUKI *Character_UnicodeScript

var Character_UnicodeScript_MARCHEN *Character_UnicodeScript

var Character_UnicodeScript_NEWA *Character_UnicodeScript

var Character_UnicodeScript_OSAGE *Character_UnicodeScript

var Character_UnicodeScript_TANGUT *Character_UnicodeScript

var Character_UnicodeScript_MASARAM_GONDI *Character_UnicodeScript

var Character_UnicodeScript_NUSHU *Character_UnicodeScript

var Character_UnicodeScript_SOYOMBO *Character_UnicodeScript

var Character_UnicodeScript_ZANABAZAR_SQUARE *Character_UnicodeScript

var Character_UnicodeScript_HANIFI_ROHINGYA *Character_UnicodeScript

var Character_UnicodeScript_OLD_SOGDIAN *Character_UnicodeScript

var Character_UnicodeScript_SOGDIAN *Character_UnicodeScript

var Character_UnicodeScript_DOGRA *Character_UnicodeScript

var Character_UnicodeScript_GUNJALA_GONDI *Character_UnicodeScript

var Character_UnicodeScript_MAKASAR *Character_UnicodeScript

var Character_UnicodeScript_MEDEFAIDRIN *Character_UnicodeScript

var Character_UnicodeScript_ELYMAIC *Character_UnicodeScript

var Character_UnicodeScript_NANDINAGARI *Character_UnicodeScript

var Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG *Character_UnicodeScript

var Character_UnicodeScript_WANCHO *Character_UnicodeScript

var Character_UnicodeScript_YEZIDI *Character_UnicodeScript

var Character_UnicodeScript_CHORASMIAN *Character_UnicodeScript

var Character_UnicodeScript_DIVES_AKURU *Character_UnicodeScript

var Character_UnicodeScript_KHITAN_SMALL_SCRIPT *Character_UnicodeScript

var Character_UnicodeScript_VITHKUQI *Character_UnicodeScript

var Character_UnicodeScript_OLD_UYGHUR *Character_UnicodeScript

var Character_UnicodeScript_CYPRO_MINOAN *Character_UnicodeScript

var Character_UnicodeScript_TANGSA *Character_UnicodeScript

var Character_UnicodeScript_TOTO *Character_UnicodeScript

var Character_UnicodeScript_KAWI *Character_UnicodeScript

var Character_UnicodeScript_NAG_MUNDARI *Character_UnicodeScript

var Character_UnicodeScript_TODHRI *Character_UnicodeScript

var Character_UnicodeScript_GARAY *Character_UnicodeScript

var Character_UnicodeScript_TULU_TIGALARI *Character_UnicodeScript

var Character_UnicodeScript_SUNUWAR *Character_UnicodeScript

var Character_UnicodeScript_GURUNG_KHEMA *Character_UnicodeScript

var Character_UnicodeScript_KIRAT_RAI *Character_UnicodeScript

var Character_UnicodeScript_OL_ONAL *Character_UnicodeScript

var Character_UnicodeScript_SIDETIC *Character_UnicodeScript

var Character_UnicodeScript_TOLONG_SIKI *Character_UnicodeScript

var Character_UnicodeScript_BERIA_ERFE *Character_UnicodeScript

var Character_UnicodeScript_TAI_YO *Character_UnicodeScript

var Character_UnicodeScript_UNKNOWN *Character_UnicodeScript

var Character_UnicodeScript__VALUES *RefArray

var Character_UnicodeScript_scriptStarts *IntArray

var Character_UnicodeScript_scripts *RefArray

var Character_UnicodeScript_aliases HashMap_I

var Character_UnicodeScript_init ClassInit

func Character_UnicodeScript_Init() { if !Character_UnicodeScript_init.Done() { Character_UnicodeScript_init.Run(Character_UnicodeScript_clinit) } }

func Character_UnicodeScript_clinit() { Character_UnicodeScript_COMMON = Character_UnicodeScript_New_String_I(Lit_915, 0); Character_UnicodeScript_LATIN = Character_UnicodeScript_New_String_I(Lit_916, 1); Character_UnicodeScript_GREEK = Character_UnicodeScript_New_String_I(Lit_139, 2); Character_UnicodeScript_CYRILLIC = Character_UnicodeScript_New_String_I(Lit_142, 3); Character_UnicodeScript_ARMENIAN = Character_UnicodeScript_New_String_I(Lit_143, 4); Character_UnicodeScript_HEBREW = Character_UnicodeScript_New_String_I(Lit_144, 5); Character_UnicodeScript_ARABIC = Character_UnicodeScript_New_String_I(Lit_145, 6); Character_UnicodeScript_SYRIAC = Character_UnicodeScript_New_String_I(Lit_264, 7); Character_UnicodeScript_THAANA = Character_UnicodeScript_New_String_I(Lit_265, 8); Character_UnicodeScript_DEVANAGARI = Character_UnicodeScript_New_String_I(Lit_146, 9); Character_UnicodeScript_BENGALI = Character_UnicodeScript_New_String_I(Lit_147, 10); Character_UnicodeScript_GURMUKHI = Character_UnicodeScript_New_String_I(Lit_148, 11); Character_UnicodeScript_GUJARATI = Character_UnicodeScript_New_String_I(Lit_149, 12); Character_UnicodeScript_ORIYA = Character_UnicodeScript_New_String_I(Lit_150, 13); Character_UnicodeScript_TAMIL = Character_UnicodeScript_New_String_I(Lit_151, 14); Character_UnicodeScript_TELUGU = Character_UnicodeScript_New_String_I(Lit_152, 15); Character_UnicodeScript_KANNADA = Character_UnicodeScript_New_String_I(Lit_153, 16); Character_UnicodeScript_MALAYALAM = Character_UnicodeScript_New_String_I(Lit_154, 17); Character_UnicodeScript_SINHALA = Character_UnicodeScript_New_String_I(Lit_266, 18); Character_UnicodeScript_THAI = Character_UnicodeScript_New_String_I(Lit_155, 19); Character_UnicodeScript_LAO = Character_UnicodeScript_New_String_I(Lit_156, 20); Character_UnicodeScript_TIBETAN = Character_UnicodeScript_New_String_I(Lit_157, 21); Character_UnicodeScript_MYANMAR = Character_UnicodeScript_New_String_I(Lit_267, 22); Character_UnicodeScript_GEORGIAN = Character_UnicodeScript_New_String_I(Lit_158, 23); Character_UnicodeScript_HANGUL = Character_UnicodeScript_New_String_I(Lit_917, 24); Character_UnicodeScript_ETHIOPIC = Character_UnicodeScript_New_String_I(Lit_268, 25); Character_UnicodeScript_CHEROKEE = Character_UnicodeScript_New_String_I(Lit_269, 26); Character_UnicodeScript_CANADIAN_ABORIGINAL = Character_UnicodeScript_New_String_I(Lit_918, 27); Character_UnicodeScript_OGHAM = Character_UnicodeScript_New_String_I(Lit_273, 28); Character_UnicodeScript_RUNIC = Character_UnicodeScript_New_String_I(Lit_274, 29); Character_UnicodeScript_KHMER = Character_UnicodeScript_New_String_I(Lit_275, 30); Character_UnicodeScript_MONGOLIAN = Character_UnicodeScript_New_String_I(Lit_276, 31); Character_UnicodeScript_HIRAGANA = Character_UnicodeScript_New_String_I(Lit_216, 32); Character_UnicodeScript_KATAKANA = Character_UnicodeScript_New_String_I(Lit_217, 33); Character_UnicodeScript_BOPOMOFO = Character_UnicodeScript_New_String_I(Lit_218, 34); Character_UnicodeScript_HAN = Character_UnicodeScript_New_String_I(Lit_919, 35); Character_UnicodeScript_YI = Character_UnicodeScript_New_String_I(Lit_920, 36); Character_UnicodeScript_OLD_ITALIC = Character_UnicodeScript_New_String_I(Lit_352, 37); Character_UnicodeScript_GOTHIC = Character_UnicodeScript_New_String_I(Lit_355, 38); Character_UnicodeScript_DESERET = Character_UnicodeScript_New_String_I(Lit_357, 39); Character_UnicodeScript_INHERITED = Character_UnicodeScript_New_String_I(Lit_921, 40); Character_UnicodeScript_TAGALOG = Character_UnicodeScript_New_String_I(Lit_302, 41); Character_UnicodeScript_HANUNOO = Character_UnicodeScript_New_String_I(Lit_303, 42); Character_UnicodeScript_BUHID = Character_UnicodeScript_New_String_I(Lit_304, 43); Character_UnicodeScript_TAGBANWA = Character_UnicodeScript_New_String_I(Lit_305, 44); Character_UnicodeScript_LIMBU = Character_UnicodeScript_New_String_I(Lit_306, 45); Character_UnicodeScript_TAI_LE = Character_UnicodeScript_New_String_I(Lit_307, 46); Character_UnicodeScript_LINEAR_B = Character_UnicodeScript_New_String_I(Lit_922, 47); Character_UnicodeScript_UGARITIC = Character_UnicodeScript_New_String_I(Lit_356, 48); Character_UnicodeScript_SHAVIAN = Character_UnicodeScript_New_String_I(Lit_358, 49); Character_UnicodeScript_OSMANYA = Character_UnicodeScript_New_String_I(Lit_359, 50); Character_UnicodeScript_CYPRIOT = Character_UnicodeScript_New_String_I(Lit_923, 51); Character_UnicodeScript_BRAILLE = Character_UnicodeScript_New_String_I(Lit_924, 52); Character_UnicodeScript_BUGINESE = Character_UnicodeScript_New_String_I(Lit_415, 53); Character_UnicodeScript_COPTIC = Character_UnicodeScript_New_String_I(Lit_439, 54); Character_UnicodeScript_NEW_TAI_LUE = Character_UnicodeScript_New_String_I(Lit_412, 55); Character_UnicodeScript_GLAGOLITIC = Character_UnicodeScript_New_String_I(Lit_435, 56); Character_UnicodeScript_TIFINAGH = Character_UnicodeScript_New_String_I(Lit_443, 57); Character_UnicodeScript_SYLOTI_NAGRI = Character_UnicodeScript_New_String_I(Lit_468, 58); Character_UnicodeScript_OLD_PERSIAN = Character_UnicodeScript_New_String_I(Lit_518, 59); Character_UnicodeScript_KHAROSHTHI = Character_UnicodeScript_New_String_I(Lit_526, 60); Character_UnicodeScript_BALINESE = Character_UnicodeScript_New_String_I(Lit_419, 61); Character_UnicodeScript_CUNEIFORM = Character_UnicodeScript_New_String_I(Lit_545, 62); Character_UnicodeScript_PHOENICIAN = Character_UnicodeScript_New_String_I(Lit_524, 63); Character_UnicodeScript_PHAGS_PA = Character_UnicodeScript_New_String_I(Lit_474, 64); Character_UnicodeScript_NKO = Character_UnicodeScript_New_String_I(Lit_403, 65); Character_UnicodeScript_SUNDANESE = Character_UnicodeScript_New_String_I(Lit_420, 66); Character_UnicodeScript_BATAK = Character_UnicodeScript_New_String_I(Lit_421, 67); Character_UnicodeScript_LEPCHA = Character_UnicodeScript_New_String_I(Lit_422, 68); Character_UnicodeScript_OL_CHIKI = Character_UnicodeScript_New_String_I(Lit_423, 69); Character_UnicodeScript_VAI = Character_UnicodeScript_New_String_I(Lit_457, 70); Character_UnicodeScript_SAURASHTRA = Character_UnicodeScript_New_String_I(Lit_476, 71); Character_UnicodeScript_KAYAH_LI = Character_UnicodeScript_New_String_I(Lit_480, 72); Character_UnicodeScript_REJANG = Character_UnicodeScript_New_String_I(Lit_483, 73); Character_UnicodeScript_LYCIAN = Character_UnicodeScript_New_String_I(Lit_516, 74); Character_UnicodeScript_CARIAN = Character_UnicodeScript_New_String_I(Lit_517, 75); Character_UnicodeScript_LYDIAN = Character_UnicodeScript_New_String_I(Lit_525, 76); Character_UnicodeScript_CHAM = Character_UnicodeScript_New_String_I(Lit_488, 77); Character_UnicodeScript_TAI_THAM = Character_UnicodeScript_New_String_I(Lit_416, 78); Character_UnicodeScript_TAI_VIET = Character_UnicodeScript_New_String_I(Lit_492, 79); Character_UnicodeScript_AVESTAN = Character_UnicodeScript_New_String_I(Lit_530, 80); Character_UnicodeScript_EGYPTIAN_HIEROGLYPHS = Character_UnicodeScript_New_String_I(Lit_549, 81); Character_UnicodeScript_SAMARITAN = Character_UnicodeScript_New_String_I(Lit_404, 82); Character_UnicodeScript_MANDAIC = Character_UnicodeScript_New_String_I(Lit_405, 83); Character_UnicodeScript_LISU = Character_UnicodeScript_New_String_I(Lit_456, 84); Character_UnicodeScript_BAMUM = Character_UnicodeScript_New_String_I(Lit_461, 85); Character_UnicodeScript_JAVANESE = Character_UnicodeScript_New_String_I(Lit_487, 86); Character_UnicodeScript_MEETEI_MAYEK = Character_UnicodeScript_New_String_I(Lit_498, 87); Character_UnicodeScript_IMPERIAL_ARAMAIC = Character_UnicodeScript_New_String_I(Lit_521, 88); Character_UnicodeScript_OLD_SOUTH_ARABIAN = Character_UnicodeScript_New_String_I(Lit_527, 89); Character_UnicodeScript_INSCRIPTIONAL_PARTHIAN = Character_UnicodeScript_New_String_I(Lit_531, 90); Character_UnicodeScript_INSCRIPTIONAL_PAHLAVI = Character_UnicodeScript_New_String_I(Lit_534, 91); Character_UnicodeScript_OLD_TURKIC = Character_UnicodeScript_New_String_I(Lit_537, 92); Character_UnicodeScript_BRAHMI = Character_UnicodeScript_New_String_I(Lit_543, 93); Character_UnicodeScript_KAITHI = Character_UnicodeScript_New_String_I(Lit_544, 94); Character_UnicodeScript_MEROITIC_HIEROGLYPHS = Character_UnicodeScript_New_String_I(Lit_604, 95); Character_UnicodeScript_MEROITIC_CURSIVE = Character_UnicodeScript_New_String_I(Lit_607, 96); Character_UnicodeScript_SORA_SOMPENG = Character_UnicodeScript_New_String_I(Lit_610, 97); Character_UnicodeScript_CHAKMA = Character_UnicodeScript_New_String_I(Lit_613, 98); Character_UnicodeScript_SHARADA = Character_UnicodeScript_New_String_I(Lit_614, 99); Character_UnicodeScript_TAKRI = Character_UnicodeScript_New_String_I(Lit_615, 100); Character_UnicodeScript_MIAO = Character_UnicodeScript_New_String_I(Lit_616, 101); Character_UnicodeScript_CAUCASIAN_ALBANIAN = Character_UnicodeScript_New_String_I(Lit_636, 102); Character_UnicodeScript_BASSA_VAH = Character_UnicodeScript_New_String_I(Lit_668, 103); Character_UnicodeScript_DUPLOYAN = Character_UnicodeScript_New_String_I(Lit_674, 104); Character_UnicodeScript_ELBASAN = Character_UnicodeScript_New_String_I(Lit_635, 105); Character_UnicodeScript_GRANTHA = Character_UnicodeScript_New_String_I(Lit_657, 106); Character_UnicodeScript_PAHAWH_HMONG = Character_UnicodeScript_New_String_I(Lit_671, 107); Character_UnicodeScript_KHOJKI = Character_UnicodeScript_New_String_I(Lit_655, 108); Character_UnicodeScript_LINEAR_A = Character_UnicodeScript_New_String_I(Lit_639, 109); Character_UnicodeScript_MAHAJANI = Character_UnicodeScript_New_String_I(Lit_651, 110); Character_UnicodeScript_MANICHAEAN = Character_UnicodeScript_New_String_I(Lit_647, 111); Character_UnicodeScript_MENDE_KIKAKUI = Character_UnicodeScript_New_String_I(Lit_678, 112); Character_UnicodeScript_MODI = Character_UnicodeScript_New_String_I(Lit_660, 113); Character_UnicodeScript_MRO = Character_UnicodeScript_New_String_I(Lit_667, 114); Character_UnicodeScript_OLD_NORTH_ARABIAN = Character_UnicodeScript_New_String_I(Lit_644, 115); Character_UnicodeScript_NABATAEAN = Character_UnicodeScript_New_String_I(Lit_643, 116); Character_UnicodeScript_PALMYRENE = Character_UnicodeScript_New_String_I(Lit_642, 117); Character_UnicodeScript_PAU_CIN_HAU = Character_UnicodeScript_New_String_I(Lit_664, 118); Character_UnicodeScript_OLD_PERMIC = Character_UnicodeScript_New_String_I(Lit_632, 119); Character_UnicodeScript_PSALTER_PAHLAVI = Character_UnicodeScript_New_String_I(Lit_648, 120); Character_UnicodeScript_SIDDHAM = Character_UnicodeScript_New_String_I(Lit_659, 121); Character_UnicodeScript_KHUDAWADI = Character_UnicodeScript_New_String_I(Lit_656, 122); Character_UnicodeScript_TIRHUTA = Character_UnicodeScript_New_String_I(Lit_658, 123); Character_UnicodeScript_WARANG_CITI = Character_UnicodeScript_New_String_I(Lit_661, 124); Character_UnicodeScript_AHOM = Character_UnicodeScript_New_String_I(Lit_698, 125); Character_UnicodeScript_ANATOLIAN_HIEROGLYPHS = Character_UnicodeScript_New_String_I(Lit_702, 126); Character_UnicodeScript_HATRAN = Character_UnicodeScript_New_String_I(Lit_693, 127); Character_UnicodeScript_MULTANI = Character_UnicodeScript_New_String_I(Lit_697, 128); Character_UnicodeScript_OLD_HUNGARIAN = Character_UnicodeScript_New_String_I(Lit_694, 129); Character_UnicodeScript_SIGNWRITING = Character_UnicodeScript_New_String_I(Lit_925, 130); Character_UnicodeScript_ADLAM = Character_UnicodeScript_New_String_I(Lit_739, 131); Character_UnicodeScript_BHAIKSUKI = Character_UnicodeScript_New_String_I(Lit_748, 132); Character_UnicodeScript_MARCHEN = Character_UnicodeScript_New_String_I(Lit_725, 133); Character_UnicodeScript_NEWA = Character_UnicodeScript_New_String_I(Lit_721, 134); Character_UnicodeScript_OSAGE = Character_UnicodeScript_New_String_I(Lit_720, 135); Character_UnicodeScript_TANGUT = Character_UnicodeScript_New_String_I(Lit_729, 136); Character_UnicodeScript_MASARAM_GONDI = Character_UnicodeScript_New_String_I(Lit_740, 137); Character_UnicodeScript_NUSHU = Character_UnicodeScript_New_String_I(Lit_746, 138); Character_UnicodeScript_SOYOMBO = Character_UnicodeScript_New_String_I(Lit_747, 139); Character_UnicodeScript_ZANABAZAR_SQUARE = Character_UnicodeScript_New_String_I(Lit_743, 140); Character_UnicodeScript_HANIFI_ROHINGYA = Character_UnicodeScript_New_String_I(Lit_755, 141); Character_UnicodeScript_OLD_SOGDIAN = Character_UnicodeScript_New_String_I(Lit_758, 142); Character_UnicodeScript_SOGDIAN = Character_UnicodeScript_New_String_I(Lit_761, 143); Character_UnicodeScript_DOGRA = Character_UnicodeScript_New_String_I(Lit_762, 144); Character_UnicodeScript_GUNJALA_GONDI = Character_UnicodeScript_New_String_I(Lit_763, 145); Character_UnicodeScript_MAKASAR = Character_UnicodeScript_New_String_I(Lit_766, 146); Character_UnicodeScript_MEDEFAIDRIN = Character_UnicodeScript_New_String_I(Lit_767, 147); Character_UnicodeScript_ELYMAIC = Character_UnicodeScript_New_String_I(Lit_777, 148); Character_UnicodeScript_NANDINAGARI = Character_UnicodeScript_New_String_I(Lit_778, 149); Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG = Character_UnicodeScript_New_String_I(Lit_788, 150); Character_UnicodeScript_WANCHO = Character_UnicodeScript_New_String_I(Lit_791, 151); Character_UnicodeScript_YEZIDI = Character_UnicodeScript_New_String_I(Lit_798, 152); Character_UnicodeScript_CHORASMIAN = Character_UnicodeScript_New_String_I(Lit_799, 153); Character_UnicodeScript_DIVES_AKURU = Character_UnicodeScript_New_String_I(Lit_800, 154); Character_UnicodeScript_KHITAN_SMALL_SCRIPT = Character_UnicodeScript_New_String_I(Lit_806, 155); Character_UnicodeScript_VITHKUQI = Character_UnicodeScript_New_String_I(Lit_821, 156); Character_UnicodeScript_OLD_UYGHUR = Character_UnicodeScript_New_String_I(Lit_825, 157); Character_UnicodeScript_CYPRO_MINOAN = Character_UnicodeScript_New_String_I(Lit_831, 158); Character_UnicodeScript_TANGSA = Character_UnicodeScript_New_String_I(Lit_833, 159); Character_UnicodeScript_TOTO = Character_UnicodeScript_New_String_I(Lit_843, 160); Character_UnicodeScript_KAWI = Character_UnicodeScript_New_String_I(Lit_853, 161); Character_UnicodeScript_NAG_MUNDARI = Character_UnicodeScript_New_String_I(Lit_860, 162); Character_UnicodeScript_TODHRI = Character_UnicodeScript_New_String_I(Lit_869, 163); Character_UnicodeScript_GARAY = Character_UnicodeScript_New_String_I(Lit_870, 164); Character_UnicodeScript_TULU_TIGALARI = Character_UnicodeScript_New_String_I(Lit_871, 165); Character_UnicodeScript_SUNUWAR = Character_UnicodeScript_New_String_I(Lit_876, 166); Character_UnicodeScript_GURUNG_KHEMA = Character_UnicodeScript_New_String_I(Lit_880, 167); Character_UnicodeScript_KIRAT_RAI = Character_UnicodeScript_New_String_I(Lit_883, 168); Character_UnicodeScript_OL_ONAL = Character_UnicodeScript_New_String_I(Lit_889, 169); Character_UnicodeScript_SIDETIC = Character_UnicodeScript_New_String_I(Lit_892, 170); Character_UnicodeScript_TOLONG_SIKI = Character_UnicodeScript_New_String_I(Lit_896, 171); Character_UnicodeScript_BERIA_ERFE = Character_UnicodeScript_New_String_I(Lit_899, 172); Character_UnicodeScript_TAI_YO = Character_UnicodeScript_New_String_I(Lit_908, 173); Character_UnicodeScript_UNKNOWN = Character_UnicodeScript_New_String_I(Lit_926, 174); Character_UnicodeScript__VALUES = Character_UnicodeScript_X_values__Character_UnicodeScript1(); Character_UnicodeScript_scriptStarts = IntArrayOf(0, 65, 91, 97, 123, 170, 171, 186, 187, 192, 215, 216, 247, 248, 697, 736, 741, 746, 748, 768, 880, 884, 885, 888, 890, 894, 895, 896, 900, 901, 902, 903, 904, 907, 908, 909, 910, 930, 931, 994, 1008, 1024, 1157, 1159, 1328, 1329, 1367, 1369, 1419, 1421, 1424, 1425, 1480, 1488, 1515, 1519, 1525, 1536, 1541, 1542, 1548, 1549, 1563, 1564, 1567, 1568, 1600, 1601, 1611, 1622, 1648, 1649, 1757, 1758, 1792, 1806, 1807, 1867, 1869, 1872, 1920, 1970, 1984, 2043, 2045, 2048, 2094, 2096, 2111, 2112, 2140, 2142, 2143, 2144, 2155, 2160, 2194, 2199, 2274, 2275, 2304, 2385, 2389, 2404, 2406, 2432, 2436, 2437, 2445, 2447, 2449, 2451, 2473, 2474, 2481, 2482, 2483, 2486, 2490, 2492, 2501, 2503, 2505, 2507, 2511, 2519, 2520, 2524, 2526, 2527, 2532, 2534, 2559, 2561, 2564, 2565, 2571, 2575, 2577, 2579, 2601, 2602, 2609, 2610, 2612, 2613, 2615, 2616, 2618, 2620, 2621, 2622, 2627, 2631, 2633, 2635, 2638, 2641, 2642, 2649, 2653, 2654, 2655, 2662, 2679, 2689, 2692, 2693, 2702, 2703, 2706, 2707, 2729, 2730, 2737, 2738, 2740, 2741, 2746, 2748, 2758, 2759, 2762, 2763, 2766, 2768, 2769, 2784, 2788, 2790, 2802, 2809, 2816, 2817, 2820, 2821, 2829, 2831, 2833, 2835, 2857, 2858, 2865, 2866, 2868, 2869, 2874, 2876, 2885, 2887, 2889, 2891, 2894, 2901, 2904, 2908, 2910, 2911, 2916, 2918, 2936, 2946, 2948, 2949, 2955, 2958, 2961, 2962, 2966, 2969, 2971, 2972, 2973, 2974, 2976, 2979, 2981, 2984, 2987, 2990, 3002, 3006, 3011, 3014, 3017, 3018, 3022, 3024, 3025, 3031, 3032, 3046, 3067, 3072, 3085, 3086, 3089, 3090, 3113, 3114, 3130, 3132, 3141, 3142, 3145, 3146, 3150, 3157, 3159, 3160, 3163, 3164, 3166, 3168, 3172, 3174, 3184, 3191, 3200, 3213, 3214, 3217, 3218, 3241, 3242, 3252, 3253, 3258, 3260, 3269, 3270, 3273, 3274, 3278, 3285, 3287, 3292, 3295, 3296, 3300, 3302, 3312, 3313, 3316, 3328, 3341, 3342, 3345, 3346, 3397, 3398, 3401, 3402, 3408, 3412, 3428, 3430, 3456, 3457, 3460, 3461, 3479, 3482, 3506, 3507, 3516, 3517, 3518, 3520, 3527, 3530, 3531, 3535, 3541, 3542, 3543, 3544, 3552, 3558, 3568, 3570, 3573, 3585, 3643, 3647, 3648, 3676, 3713, 3715, 3716, 3717, 3718, 3723, 3724, 3748, 3749, 3750, 3751, 3774, 3776, 3781, 3782, 3783, 3784, 3791, 3792, 3802, 3804, 3808, 3840, 3912, 3913, 3949, 3953, 3992, 3993, 4029, 4030, 4045, 4046, 4053, 4057, 4059, 4096, 4256, 4294, 4295, 4296, 4301, 4302, 4304, 4347, 4348, 4352, 4608, 4681, 4682, 4686, 4688, 4695, 4696, 4697, 4698, 4702, 4704, 4745, 4746, 4750, 4752, 4785, 4786, 4790, 4792, 4799, 4800, 4801, 4802, 4806, 4808, 4823, 4824, 4881, 4882, 4886, 4888, 4955, 4957, 4989, 4992, 5018, 5024, 5110, 5112, 5118, 5120, 5760, 5789, 5792, 5867, 5870, 5881, 5888, 5910, 5919, 5920, 5941, 5943, 5952, 5972, 5984, 5997, 5998, 6001, 6002, 6004, 6016, 6110, 6112, 6122, 6128, 6138, 6144, 6146, 6148, 6149, 6150, 6170, 6176, 6265, 6272, 6315, 6320, 6390, 6400, 6431, 6432, 6444, 6448, 6460, 6464, 6465, 6468, 6480, 6510, 6512, 6517, 6528, 6572, 6576, 6602, 6608, 6619, 6622, 6624, 6656, 6684, 6686, 6688, 6751, 6752, 6781, 6783, 6794, 6800, 6810, 6816, 6830, 6832, 6878, 6880, 6892, 6912, 6989, 6990, 7040, 7104, 7156, 7164, 7168, 7224, 7227, 7242, 7245, 7248, 7296, 7307, 7312, 7355, 7357, 7360, 7368, 7376, 7379, 7380, 7393, 7394, 7401, 7405, 7406, 7412, 7413, 7416, 7418, 7419, 7424, 7462, 7467, 7468, 7517, 7522, 7526, 7531, 7544, 7545, 7615, 7616, 7680, 7936, 7958, 7960, 7966, 7968, 8006, 8008, 8014, 8016, 8024, 8025, 8026, 8027, 8028, 8029, 8030, 8031, 8062, 8064, 8117, 8118, 8133, 8134, 8148, 8150, 8156, 8157, 8176, 8178, 8181, 8182, 8191, 8192, 8204, 8206, 8293, 8294, 8305, 8306, 8308, 8319, 8320, 8335, 8336, 8349, 8352, 8386, 8400, 8433, 8448, 8486, 8487, 8490, 8492, 8498, 8499, 8526, 8527, 8544, 8585, 8588, 8592, 9258, 9280, 9291, 9312, 10240, 10496, 11124, 11126, 11264, 11360, 11392, 11508, 11513, 11520, 11558, 11559, 11560, 11565, 11566, 11568, 11624, 11631, 11633, 11647, 11648, 11671, 11680, 11687, 11688, 11695, 11696, 11703, 11704, 11711, 11712, 11719, 11720, 11727, 11728, 11735, 11736, 11743, 11744, 11776, 11870, 11904, 11930, 11931, 12020, 12032, 12246, 12272, 12293, 12294, 12295, 12296, 12321, 12330, 12334, 12336, 12344, 12348, 12352, 12353, 12439, 12441, 12443, 12445, 12448, 12449, 12539, 12541, 12544, 12549, 12592, 12593, 12687, 12688, 12704, 12736, 12774, 12783, 12784, 12800, 12831, 12832, 12896, 12927, 13008, 13055, 13056, 13144, 13312, 19904, 19968, 40960, 42125, 42128, 42183, 42192, 42240, 42540, 42560, 42656, 42744, 42752, 42786, 42888, 42891, 42973, 42993, 43008, 43053, 43056, 43066, 43072, 43128, 43136, 43206, 43214, 43226, 43232, 43264, 43310, 43311, 43312, 43348, 43359, 43360, 43389, 43392, 43470, 43471, 43472, 43482, 43486, 43488, 43519, 43520, 43575, 43584, 43598, 43600, 43610, 43612, 43616, 43648, 43715, 43739, 43744, 43767, 43777, 43783, 43785, 43791, 43793, 43799, 43808, 43815, 43816, 43823, 43824, 43867, 43868, 43877, 43878, 43882, 43884, 43888, 43968, 44014, 44016, 44026, 44032, 55204, 55216, 55239, 55243, 55292, 63744, 64110, 64112, 64218, 64256, 64263, 64275, 64280, 64285, 64311, 64312, 64317, 64318, 64319, 64320, 64322, 64323, 64325, 64326, 64336, 64830, 64832, 64976, 65008, 65024, 65040, 65050, 65056, 65070, 65072, 65107, 65108, 65127, 65128, 65132, 65136, 65141, 65142, 65277, 65279, 65280, 65281, 65313, 65339, 65345, 65371, 65382, 65392, 65393, 65438, 65440, 65471, 65474, 65480, 65482, 65488, 65490, 65496, 65498, 65501, 65504, 65511, 65512, 65519, 65529, 65534, 65536, 65548, 65549, 65575, 65576, 65595, 65596, 65598, 65599, 65614, 65616, 65630, 65664, 65787, 65792, 65795, 65799, 65844, 65847, 65856, 65935, 65936, 65949, 65952, 65953, 66000, 66045, 66046, 66176, 66205, 66208, 66257, 66272, 66273, 66300, 66304, 66340, 66349, 66352, 66379, 66384, 66427, 66432, 66462, 66463, 66464, 66500, 66504, 66518, 66560, 66640, 66688, 66718, 66720, 66730, 66736, 66772, 66776, 66812, 66816, 66856, 66864, 66916, 66927, 66928, 66939, 66940, 66955, 66956, 66963, 66964, 66966, 66967, 66978, 66979, 66994, 66995, 67002, 67003, 67005, 67008, 67060, 67072, 67383, 67392, 67414, 67424, 67432, 67456, 67462, 67463, 67505, 67506, 67515, 67584, 67590, 67592, 67593, 67594, 67638, 67639, 67641, 67644, 67645, 67647, 67648, 67670, 67671, 67680, 67712, 67743, 67751, 67760, 67808, 67827, 67828, 67830, 67835, 67840, 67868, 67871, 67872, 67898, 67903, 67904, 67930, 67968, 68000, 68024, 68028, 68048, 68050, 68096, 68100, 68101, 68103, 68108, 68116, 68117, 68120, 68121, 68150, 68152, 68155, 68159, 68169, 68176, 68185, 68192, 68224, 68256, 68288, 68327, 68331, 68343, 68352, 68406, 68409, 68416, 68438, 68440, 68448, 68467, 68472, 68480, 68498, 68505, 68509, 68521, 68528, 68608, 68681, 68736, 68787, 68800, 68851, 68858, 68864, 68904, 68912, 68922, 68928, 68966, 68969, 68998, 69006, 69008, 69216, 69247, 69248, 69290, 69291, 69294, 69296, 69298, 69314, 69320, 69328, 69337, 69370, 69376, 69416, 69424, 69466, 69488, 69514, 69552, 69580, 69600, 69623, 69632, 69710, 69714, 69750, 69759, 69760, 69827, 69837, 69838, 69840, 69865, 69872, 69882, 69888, 69941, 69942, 69960, 69968, 70007, 70016, 70112, 70113, 70133, 70144, 70162, 70163, 70210, 70272, 70279, 70280, 70281, 70282, 70286, 70287, 70302, 70303, 70314, 70320, 70379, 70384, 70394, 70400, 70404, 70405, 70413, 70415, 70417, 70419, 70441, 70442, 70449, 70450, 70452, 70453, 70458, 70459, 70460, 70469, 70471, 70473, 70475, 70478, 70480, 70481, 70487, 70488, 70493, 70500, 70502, 70509, 70512, 70517, 70528, 70538, 70539, 70540, 70542, 70543, 70544, 70582, 70583, 70593, 70594, 70595, 70597, 70598, 70599, 70603, 70604, 70614, 70615, 70617, 70625, 70627, 70656, 70748, 70749, 70754, 70784, 70856, 70864, 70874, 71040, 71094, 71096, 71134, 71168, 71237, 71248, 71258, 71264, 71277, 71296, 71354, 71360, 71370, 71376, 71396, 71424, 71451, 71453, 71468, 71472, 71495, 71680, 71740, 71840, 71923, 71935, 71936, 71943, 71945, 71946, 71948, 71956, 71957, 71959, 71960, 71990, 71991, 71993, 71995, 72007, 72016, 72026, 72096, 72104, 72106, 72152, 72154, 72165, 72192, 72264, 72272, 72355, 72368, 72384, 72441, 72448, 72458, 72544, 72552, 72640, 72674, 72688, 72698, 72704, 72713, 72714, 72759, 72760, 72774, 72784, 72813, 72816, 72848, 72850, 72872, 72873, 72887, 72960, 72967, 72968, 72970, 72971, 73015, 73018, 73019, 73020, 73022, 73023, 73032, 73040, 73050, 73056, 73062, 73063, 73065, 73066, 73103, 73104, 73106, 73107, 73113, 73120, 73130, 73136, 73180, 73184, 73194, 73440, 73465, 73472, 73489, 73490, 73531, 73534, 73563, 73648, 73649, 73664, 73714, 73727, 73728, 74650, 74752, 74863, 74864, 74869, 74880, 75076, 77712, 77811, 77824, 78934, 78944, 82939, 82944, 83527, 90368, 90426, 92160, 92729, 92736, 92767, 92768, 92778, 92782, 92784, 92863, 92864, 92874, 92880, 92910, 92912, 92918, 92928, 92998, 93008, 93018, 93019, 93026, 93027, 93048, 93053, 93072, 93504, 93562, 93760, 93851, 93856, 93881, 93883, 93908, 93952, 94027, 94031, 94088, 94095, 94112, 94176, 94177, 94178, 94180, 94181, 94192, 94199, 94208, 101120, 101590, 101631, 101632, 101663, 101760, 101875, 110576, 110580, 110581, 110588, 110589, 110591, 110592, 110593, 110880, 110883, 110898, 110899, 110928, 110931, 110933, 110934, 110948, 110952, 110960, 111356, 113664, 113771, 113776, 113789, 113792, 113801, 113808, 113818, 113820, 113824, 113828, 117760, 118013, 118016, 118452, 118458, 118481, 118496, 118513, 118528, 118574, 118576, 118599, 118608, 118724, 118784, 119030, 119040, 119079, 119081, 119143, 119146, 119163, 119171, 119173, 119180, 119210, 119214, 119275, 119296, 119366, 119488, 119508, 119520, 119540, 119552, 119639, 119648, 119673, 119808, 119893, 119894, 119965, 119966, 119968, 119970, 119971, 119973, 119975, 119977, 119981, 119982, 119994, 119995, 119996, 119997, 120004, 120005, 120070, 120071, 120075, 120077, 120085, 120086, 120093, 120094, 120122, 120123, 120127, 120128, 120133, 120134, 120135, 120138, 120145, 120146, 120486, 120488, 120780, 120782, 120832, 121484, 121499, 121504, 121505, 121520, 122624, 122655, 122661, 122667, 122880, 122887, 122888, 122905, 122907, 122914, 122915, 122917, 122918, 122923, 122928, 122990, 123023, 123024, 123136, 123181, 123184, 123198, 123200, 123210, 123214, 123216, 123536, 123567, 123584, 123642, 123647, 123648, 124112, 124154, 124368, 124411, 124415, 124416, 124608, 124639, 124640, 124662, 124670, 124672, 124896, 124903, 124904, 124908, 124909, 124911, 124912, 124927, 124928, 125125, 125127, 125143, 125184, 125260, 125264, 125274, 125278, 125280, 126065, 126133, 126209, 126270, 126464, 126468, 126469, 126496, 126497, 126499, 126500, 126501, 126503, 126504, 126505, 126515, 126516, 126520, 126521, 126522, 126523, 126524, 126530, 126531, 126535, 126536, 126537, 126538, 126539, 126540, 126541, 126544, 126545, 126547, 126548, 126549, 126551, 126552, 126553, 126554, 126555, 126556, 126557, 126558, 126559, 126560, 126561, 126563, 126564, 126565, 126567, 126571, 126572, 126579, 126580, 126584, 126585, 126589, 126590, 126591, 126592, 126602, 126603, 126620, 126625, 126628, 126629, 126634, 126635, 126652, 126704, 126706, 126976, 127020, 127024, 127124, 127136, 127151, 127153, 127168, 127169, 127184, 127185, 127222, 127232, 127406, 127462, 127488, 127489, 127491, 127504, 127548, 127552, 127561, 127568, 127570, 127584, 127590, 127744, 128729, 128732, 128749, 128752, 128765, 128768, 128986, 128992, 129004, 129008, 129009, 129024, 129036, 129040, 129096, 129104, 129114, 129120, 129160, 129168, 129198, 129200, 129212, 129216, 129218, 129232, 129241, 129280, 129624, 129632, 129646, 129648, 129661, 129664, 129675, 129678, 129735, 129736, 129737, 129741, 129757, 129759, 129771, 129775, 129785, 129792, 129939, 129940, 130043, 131072, 173792, 173824, 178206, 178208, 183982, 183984, 191457, 191472, 192094, 194560, 195102, 196608, 201547, 201552, 210042, 917505, 917506, 917536, 917632, 917760, 918000); Character_UnicodeScript_scripts = RefArrayOf(Character_UnicodeScript_class, Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_BOPOMOFO.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_COPTIC.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARMENIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARMENIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARMENIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_SYRIAC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SYRIAC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SYRIAC.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_THAANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NKO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NKO.Ref(), Character_UnicodeScript_SAMARITAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SAMARITAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MANDAIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MANDAIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SYRIAC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_DEVANAGARI.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_DEVANAGARI.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_DEVANAGARI.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BENGALI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURMUKHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUJARATI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ORIYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TELUGU.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KANNADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MALAYALAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MALAYALAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MALAYALAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MALAYALAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MALAYALAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MALAYALAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MALAYALAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_THAI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_THAI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIBETAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIBETAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIBETAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIBETAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIBETAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIBETAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_TIBETAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MYANMAR.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHEROKEE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHEROKEE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CANADIAN_ABORIGINAL.Ref(), Character_UnicodeScript_OGHAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_RUNIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_RUNIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAGALOG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAGALOG.Ref(), Character_UnicodeScript_HANUNOO.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BUHID.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAGBANWA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAGBANWA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAGBANWA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHMER.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHMER.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHMER.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MONGOLIAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_MONGOLIAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_MONGOLIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MONGOLIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MONGOLIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CANADIAN_ABORIGINAL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LIMBU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LIMBU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LIMBU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LIMBU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LIMBU.Ref(), Character_UnicodeScript_TAI_LE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_LE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NEW_TAI_LUE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NEW_TAI_LUE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NEW_TAI_LUE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NEW_TAI_LUE.Ref(), Character_UnicodeScript_KHMER.Ref(), Character_UnicodeScript_BUGINESE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BUGINESE.Ref(), Character_UnicodeScript_TAI_THAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_THAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_THAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_THAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_THAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BALINESE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BALINESE.Ref(), Character_UnicodeScript_SUNDANESE.Ref(), Character_UnicodeScript_BATAK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BATAK.Ref(), Character_UnicodeScript_LEPCHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LEPCHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LEPCHA.Ref(), Character_UnicodeScript_OL_CHIKI.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_SUNDANESE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_BRAILLE.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GLAGOLITIC.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COPTIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COPTIC.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GEORGIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIFINAGH.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIFINAGH.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIFINAGH.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HIRAGANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HIRAGANA.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BOPOMOFO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_BOPOMOFO.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_YI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_YI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LISU.Ref(), Character_UnicodeScript_VAI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_BAMUM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_SYLOTI_NAGRI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PHAGS_PA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SAURASHTRA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SAURASHTRA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DEVANAGARI.Ref(), Character_UnicodeScript_KAYAH_LI.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KAYAH_LI.Ref(), Character_UnicodeScript_REJANG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_REJANG.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_JAVANESE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_JAVANESE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_JAVANESE.Ref(), Character_UnicodeScript_MYANMAR.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHAM.Ref(), Character_UnicodeScript_MYANMAR.Ref(), Character_UnicodeScript_TAI_VIET.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_VIET.Ref(), Character_UnicodeScript_MEETEI_MAYEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHEROKEE.Ref(), Character_UnicodeScript_MEETEI_MAYEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MEETEI_MAYEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARMENIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HEBREW.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANGUL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_B.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_B.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_B.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_B.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_B.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_B.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_B.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LYCIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CARIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_ITALIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_ITALIC.Ref(), Character_UnicodeScript_GOTHIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_PERMIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_UGARITIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_UGARITIC.Ref(), Character_UnicodeScript_OLD_PERSIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_PERSIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DESERET.Ref(), Character_UnicodeScript_SHAVIAN.Ref(), Character_UnicodeScript_OSMANYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OSMANYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OSAGE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OSAGE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ELBASAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CAUCASIAN_ALBANIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CAUCASIAN_ALBANIAN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_VITHKUQI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TODHRI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_A.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_A.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LINEAR_A.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYPRIOT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYPRIOT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYPRIOT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYPRIOT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYPRIOT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYPRIOT.Ref(), Character_UnicodeScript_IMPERIAL_ARAMAIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_IMPERIAL_ARAMAIC.Ref(), Character_UnicodeScript_PALMYRENE.Ref(), Character_UnicodeScript_NABATAEAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NABATAEAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HATRAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HATRAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HATRAN.Ref(), Character_UnicodeScript_PHOENICIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PHOENICIAN.Ref(), Character_UnicodeScript_LYDIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LYDIAN.Ref(), Character_UnicodeScript_SIDETIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MEROITIC_HIEROGLYPHS.Ref(), Character_UnicodeScript_MEROITIC_CURSIVE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MEROITIC_CURSIVE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MEROITIC_CURSIVE.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHAROSHTHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_SOUTH_ARABIAN.Ref(), Character_UnicodeScript_OLD_NORTH_ARABIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MANICHAEAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MANICHAEAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_AVESTAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_AVESTAN.Ref(), Character_UnicodeScript_INSCRIPTIONAL_PARTHIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INSCRIPTIONAL_PARTHIAN.Ref(), Character_UnicodeScript_INSCRIPTIONAL_PAHLAVI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INSCRIPTIONAL_PAHLAVI.Ref(), Character_UnicodeScript_PSALTER_PAHLAVI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PSALTER_PAHLAVI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PSALTER_PAHLAVI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_TURKIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_HUNGARIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_HUNGARIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_HUNGARIAN.Ref(), Character_UnicodeScript_HANIFI_ROHINGYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HANIFI_ROHINGYA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GARAY.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GARAY.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GARAY.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_YEZIDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_YEZIDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_YEZIDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_OLD_SOGDIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SOGDIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OLD_UYGHUR.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHORASMIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ELYMAIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BRAHMI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BRAHMI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BRAHMI.Ref(), Character_UnicodeScript_KAITHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KAITHI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SORA_SOMPENG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SORA_SOMPENG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHAKMA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CHAKMA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MAHAJANI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SHARADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SINHALA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHOJKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHOJKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MULTANI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MULTANI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MULTANI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MULTANI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MULTANI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHUDAWADI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHUDAWADI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GRANTHA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TULU_TIGALARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NEWA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NEWA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIRHUTA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TIRHUTA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SIDDHAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SIDDHAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MODI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MODI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MONGOLIAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAKRI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAKRI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MYANMAR.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_AHOM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_AHOM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_AHOM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DOGRA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_WARANG_CITI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_WARANG_CITI.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DIVES_AKURU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NANDINAGARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NANDINAGARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NANDINAGARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ZANABAZAR_SQUARE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SOYOMBO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CANADIAN_ABORIGINAL.Ref(), Character_UnicodeScript_PAU_CIN_HAU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DEVANAGARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SHARADA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SUNUWAR.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SUNUWAR.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BHAIKSUKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BHAIKSUKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BHAIKSUKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BHAIKSUKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MARCHEN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MARCHEN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MARCHEN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MASARAM_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MASARAM_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MASARAM_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MASARAM_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MASARAM_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MASARAM_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MASARAM_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUNJALA_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUNJALA_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUNJALA_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUNJALA_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUNJALA_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GUNJALA_GONDI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TOLONG_SIKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TOLONG_SIKI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MAKASAR.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KAWI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KAWI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KAWI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LISU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAMIL.Ref(), Character_UnicodeScript_CUNEIFORM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CUNEIFORM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CUNEIFORM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CUNEIFORM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYPRO_MINOAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_EGYPTIAN_HIEROGLYPHS.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_EGYPTIAN_HIEROGLYPHS.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ANATOLIAN_HIEROGLYPHS.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GURUNG_KHEMA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BAMUM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MRO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MRO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MRO.Ref(), Character_UnicodeScript_TANGSA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TANGSA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BASSA_VAH.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BASSA_VAH.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PAHAWH_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PAHAWH_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PAHAWH_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PAHAWH_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_PAHAWH_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KIRAT_RAI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MEDEFAIDRIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BERIA_ERFE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_BERIA_ERFE.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MIAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MIAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MIAO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TANGUT.Ref(), Character_UnicodeScript_NUSHU.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_KHITAN_SMALL_SCRIPT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TANGUT.Ref(), Character_UnicodeScript_KHITAN_SMALL_SCRIPT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KHITAN_SMALL_SCRIPT.Ref(), Character_UnicodeScript_TANGUT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TANGUT.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_HIRAGANA.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HIRAGANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HIRAGANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_KATAKANA.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NUSHU.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DUPLOYAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DUPLOYAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DUPLOYAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DUPLOYAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_DUPLOYAN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GREEK.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_SIGNWRITING.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SIGNWRITING.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_SIGNWRITING.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_LATIN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GLAGOLITIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GLAGOLITIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GLAGOLITIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GLAGOLITIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_GLAGOLITIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_CYRILLIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TOTO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_WANCHO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_WANCHO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_NAG_MUNDARI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OL_ONAL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_OL_ONAL.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_YO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_YO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_TAI_YO.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ETHIOPIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MENDE_KIKAKUI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_MENDE_KIKAKUI.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ADLAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ADLAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ADLAM.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_ARABIC.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_HIRAGANA.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_HAN.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_COMMON.Ref(), Character_UnicodeScript_UNKNOWN.Ref(), Character_UnicodeScript_INHERITED.Ref(), Character_UnicodeScript_UNKNOWN.Ref())
//line :3866:1
	Character_UnicodeScript_aliases = HashMap_NewHashMap_I__HashMap(NN(Character_UnicodeScript_UNKNOWN).Ordinal__I() + 1)
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_927, Character_UnicodeScript_ADLAM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_928, Character_UnicodeScript_CAUCASIAN_ALBANIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_698, Character_UnicodeScript_AHOM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_929, Character_UnicodeScript_ARABIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_930, Character_UnicodeScript_IMPERIAL_ARAMAIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_931, Character_UnicodeScript_ARMENIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_932, Character_UnicodeScript_AVESTAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_933, Character_UnicodeScript_BALINESE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_934, Character_UnicodeScript_BAMUM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_935, Character_UnicodeScript_BASSA_VAH.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_936, Character_UnicodeScript_BATAK.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_937, Character_UnicodeScript_BENGALI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_938, Character_UnicodeScript_BERIA_ERFE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_939, Character_UnicodeScript_BHAIKSUKI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_940, Character_UnicodeScript_BOPOMOFO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_941, Character_UnicodeScript_BRAHMI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_942, Character_UnicodeScript_BRAILLE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_943, Character_UnicodeScript_BUGINESE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_944, Character_UnicodeScript_BUHID.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_945, Character_UnicodeScript_CHAKMA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_946, Character_UnicodeScript_CANADIAN_ABORIGINAL.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_947, Character_UnicodeScript_CARIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_488, Character_UnicodeScript_CHAM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_948, Character_UnicodeScript_CHEROKEE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_949, Character_UnicodeScript_CHORASMIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_950, Character_UnicodeScript_COPTIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_951, Character_UnicodeScript_CYPRO_MINOAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_952, Character_UnicodeScript_CYPRIOT.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_953, Character_UnicodeScript_CYRILLIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_954, Character_UnicodeScript_DEVANAGARI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_955, Character_UnicodeScript_DIVES_AKURU.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_956, Character_UnicodeScript_DOGRA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_957, Character_UnicodeScript_DESERET.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_958, Character_UnicodeScript_DUPLOYAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_959, Character_UnicodeScript_EGYPTIAN_HIEROGLYPHS.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_960, Character_UnicodeScript_ELBASAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_961, Character_UnicodeScript_ELYMAIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_962, Character_UnicodeScript_ETHIOPIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_963, Character_UnicodeScript_GARAY.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_964, Character_UnicodeScript_GEORGIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_965, Character_UnicodeScript_GLAGOLITIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_966, Character_UnicodeScript_GUNJALA_GONDI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_967, Character_UnicodeScript_MASARAM_GONDI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_968, Character_UnicodeScript_GOTHIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_969, Character_UnicodeScript_GRANTHA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_970, Character_UnicodeScript_GREEK.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_971, Character_UnicodeScript_GUJARATI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_972, Character_UnicodeScript_GURUNG_KHEMA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_973, Character_UnicodeScript_GURMUKHI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_974, Character_UnicodeScript_HANGUL.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_975, Character_UnicodeScript_HAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_976, Character_UnicodeScript_HANUNOO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_977, Character_UnicodeScript_HATRAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_978, Character_UnicodeScript_HEBREW.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_979, Character_UnicodeScript_HIRAGANA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_980, Character_UnicodeScript_ANATOLIAN_HIEROGLYPHS.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_981, Character_UnicodeScript_PAHAWH_HMONG.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_982, Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_983, Character_UnicodeScript_OLD_HUNGARIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_984, Character_UnicodeScript_OLD_ITALIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_985, Character_UnicodeScript_JAVANESE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_986, Character_UnicodeScript_KAYAH_LI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_987, Character_UnicodeScript_KATAKANA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_853, Character_UnicodeScript_KAWI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_988, Character_UnicodeScript_KHAROSHTHI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_989, Character_UnicodeScript_KHMER.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_990, Character_UnicodeScript_KHOJKI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_991, Character_UnicodeScript_KHITAN_SMALL_SCRIPT.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_992, Character_UnicodeScript_KANNADA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_993, Character_UnicodeScript_KIRAT_RAI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_994, Character_UnicodeScript_KAITHI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_995, Character_UnicodeScript_TAI_THAM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_996, Character_UnicodeScript_LAO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_997, Character_UnicodeScript_LATIN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_998, Character_UnicodeScript_LEPCHA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_999, Character_UnicodeScript_LIMBU.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1000, Character_UnicodeScript_LINEAR_A.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1001, Character_UnicodeScript_LINEAR_B.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_456, Character_UnicodeScript_LISU.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1002, Character_UnicodeScript_LYCIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1003, Character_UnicodeScript_LYDIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1004, Character_UnicodeScript_MAHAJANI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1005, Character_UnicodeScript_MAKASAR.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1006, Character_UnicodeScript_MANDAIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1007, Character_UnicodeScript_MANICHAEAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1008, Character_UnicodeScript_MARCHEN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1009, Character_UnicodeScript_MEDEFAIDRIN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1010, Character_UnicodeScript_MENDE_KIKAKUI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1011, Character_UnicodeScript_MEROITIC_CURSIVE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1012, Character_UnicodeScript_MEROITIC_HIEROGLYPHS.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1013, Character_UnicodeScript_MALAYALAM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_660, Character_UnicodeScript_MODI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1014, Character_UnicodeScript_MONGOLIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1015, Character_UnicodeScript_MRO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1016, Character_UnicodeScript_MEETEI_MAYEK.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1017, Character_UnicodeScript_MULTANI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1018, Character_UnicodeScript_MYANMAR.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1019, Character_UnicodeScript_NAG_MUNDARI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1020, Character_UnicodeScript_NANDINAGARI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1021, Character_UnicodeScript_OLD_NORTH_ARABIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1022, Character_UnicodeScript_NABATAEAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_721, Character_UnicodeScript_NEWA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1023, Character_UnicodeScript_NKO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1024, Character_UnicodeScript_NUSHU.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1025, Character_UnicodeScript_OGHAM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1026, Character_UnicodeScript_OL_CHIKI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1027, Character_UnicodeScript_OL_ONAL.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1028, Character_UnicodeScript_OLD_TURKIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1029, Character_UnicodeScript_ORIYA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1030, Character_UnicodeScript_OSAGE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1031, Character_UnicodeScript_OSMANYA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1032, Character_UnicodeScript_OLD_UYGHUR.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1033, Character_UnicodeScript_PALMYRENE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1034, Character_UnicodeScript_PAU_CIN_HAU.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1035, Character_UnicodeScript_OLD_PERMIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1036, Character_UnicodeScript_PHAGS_PA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1037, Character_UnicodeScript_INSCRIPTIONAL_PAHLAVI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1038, Character_UnicodeScript_PSALTER_PAHLAVI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1039, Character_UnicodeScript_PHOENICIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1040, Character_UnicodeScript_MIAO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1041, Character_UnicodeScript_INSCRIPTIONAL_PARTHIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1042, Character_UnicodeScript_REJANG.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1043, Character_UnicodeScript_HANIFI_ROHINGYA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1044, Character_UnicodeScript_RUNIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1045, Character_UnicodeScript_SAMARITAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1046, Character_UnicodeScript_OLD_SOUTH_ARABIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1047, Character_UnicodeScript_SAURASHTRA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1048, Character_UnicodeScript_SIGNWRITING.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1049, Character_UnicodeScript_SHAVIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1050, Character_UnicodeScript_SHARADA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1051, Character_UnicodeScript_SIDDHAM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1052, Character_UnicodeScript_SIDETIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1053, Character_UnicodeScript_KHUDAWADI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1054, Character_UnicodeScript_SINHALA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1055, Character_UnicodeScript_SOGDIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1056, Character_UnicodeScript_OLD_SOGDIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1057, Character_UnicodeScript_SORA_SOMPENG.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1058, Character_UnicodeScript_SOYOMBO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1059, Character_UnicodeScript_SUNDANESE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1060, Character_UnicodeScript_SUNUWAR.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1061, Character_UnicodeScript_SYLOTI_NAGRI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1062, Character_UnicodeScript_SYRIAC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1063, Character_UnicodeScript_TAGBANWA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1064, Character_UnicodeScript_TAKRI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1065, Character_UnicodeScript_TAI_LE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1066, Character_UnicodeScript_NEW_TAI_LUE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1067, Character_UnicodeScript_TAMIL.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1068, Character_UnicodeScript_TANGUT.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1069, Character_UnicodeScript_TAI_VIET.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1070, Character_UnicodeScript_TAI_YO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1071, Character_UnicodeScript_TELUGU.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1072, Character_UnicodeScript_TIFINAGH.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1073, Character_UnicodeScript_TAGALOG.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1074, Character_UnicodeScript_THAANA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_155, Character_UnicodeScript_THAI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1075, Character_UnicodeScript_TIBETAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1076, Character_UnicodeScript_TIRHUTA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1077, Character_UnicodeScript_TANGSA.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1078, Character_UnicodeScript_TODHRI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1079, Character_UnicodeScript_TOLONG_SIKI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_843, Character_UnicodeScript_TOTO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1080, Character_UnicodeScript_TULU_TIGALARI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1081, Character_UnicodeScript_UGARITIC.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1082, Character_UnicodeScript_VAI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1083, Character_UnicodeScript_VITHKUQI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1084, Character_UnicodeScript_WARANG_CITI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1085, Character_UnicodeScript_WANCHO.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1086, Character_UnicodeScript_OLD_PERSIAN.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1087, Character_UnicodeScript_CUNEIFORM.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1088, Character_UnicodeScript_YEZIDI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1089, Character_UnicodeScript_YI.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1090, Character_UnicodeScript_ZANABAZAR_SQUARE.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1091, Character_UnicodeScript_INHERITED.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1092, Character_UnicodeScript_COMMON.Ref())
	Character_UnicodeScript_aliases.Put_O_O__O(Lit_1093, Character_UnicodeScript_UNKNOWN.Ref())
}































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func Character_UnicodeScript_New_String_I(p0 *String, p1 int32) *Character_UnicodeScript { Character_UnicodeScript_Init(); t := &Character_UnicodeScript{}; t.Ctor_String_I(p0, p1); return t }

func (t *Character_UnicodeScript) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Character_UnicodeScript_Values__Character_UnicodeScript1() *RefArray { Character_UnicodeScript_Init(); return Character_UnicodeScript__VALUES.Copy() }

func Character_UnicodeScript_ValueOf_String__Character_UnicodeScript(p0 *String) *Character_UnicodeScript { Character_UnicodeScript_Init(); return Character_UnicodeScript_Cast(Enum_ValueOf_Class_String__Enum(Character_UnicodeScript_class, p0)) }

func Character_UnicodeScript_X_values__Character_UnicodeScript1() *RefArray { Character_UnicodeScript_Init(); return RefArrayOf(Character_UnicodeScript_class, Character_UnicodeScript_COMMON, Character_UnicodeScript_LATIN, Character_UnicodeScript_GREEK, Character_UnicodeScript_CYRILLIC, Character_UnicodeScript_ARMENIAN, Character_UnicodeScript_HEBREW, Character_UnicodeScript_ARABIC, Character_UnicodeScript_SYRIAC, Character_UnicodeScript_THAANA, Character_UnicodeScript_DEVANAGARI, Character_UnicodeScript_BENGALI, Character_UnicodeScript_GURMUKHI, Character_UnicodeScript_GUJARATI, Character_UnicodeScript_ORIYA, Character_UnicodeScript_TAMIL, Character_UnicodeScript_TELUGU, Character_UnicodeScript_KANNADA, Character_UnicodeScript_MALAYALAM, Character_UnicodeScript_SINHALA, Character_UnicodeScript_THAI, Character_UnicodeScript_LAO, Character_UnicodeScript_TIBETAN, Character_UnicodeScript_MYANMAR, Character_UnicodeScript_GEORGIAN, Character_UnicodeScript_HANGUL, Character_UnicodeScript_ETHIOPIC, Character_UnicodeScript_CHEROKEE, Character_UnicodeScript_CANADIAN_ABORIGINAL, Character_UnicodeScript_OGHAM, Character_UnicodeScript_RUNIC, Character_UnicodeScript_KHMER, Character_UnicodeScript_MONGOLIAN, Character_UnicodeScript_HIRAGANA, Character_UnicodeScript_KATAKANA, Character_UnicodeScript_BOPOMOFO, Character_UnicodeScript_HAN, Character_UnicodeScript_YI, Character_UnicodeScript_OLD_ITALIC, Character_UnicodeScript_GOTHIC, Character_UnicodeScript_DESERET, Character_UnicodeScript_INHERITED, Character_UnicodeScript_TAGALOG, Character_UnicodeScript_HANUNOO, Character_UnicodeScript_BUHID, Character_UnicodeScript_TAGBANWA, Character_UnicodeScript_LIMBU, Character_UnicodeScript_TAI_LE, Character_UnicodeScript_LINEAR_B, Character_UnicodeScript_UGARITIC, Character_UnicodeScript_SHAVIAN, Character_UnicodeScript_OSMANYA, Character_UnicodeScript_CYPRIOT, Character_UnicodeScript_BRAILLE, Character_UnicodeScript_BUGINESE, Character_UnicodeScript_COPTIC, Character_UnicodeScript_NEW_TAI_LUE, Character_UnicodeScript_GLAGOLITIC, Character_UnicodeScript_TIFINAGH, Character_UnicodeScript_SYLOTI_NAGRI, Character_UnicodeScript_OLD_PERSIAN, Character_UnicodeScript_KHAROSHTHI, Character_UnicodeScript_BALINESE, Character_UnicodeScript_CUNEIFORM, Character_UnicodeScript_PHOENICIAN, Character_UnicodeScript_PHAGS_PA, Character_UnicodeScript_NKO, Character_UnicodeScript_SUNDANESE, Character_UnicodeScript_BATAK, Character_UnicodeScript_LEPCHA, Character_UnicodeScript_OL_CHIKI, Character_UnicodeScript_VAI, Character_UnicodeScript_SAURASHTRA, Character_UnicodeScript_KAYAH_LI, Character_UnicodeScript_REJANG, Character_UnicodeScript_LYCIAN, Character_UnicodeScript_CARIAN, Character_UnicodeScript_LYDIAN, Character_UnicodeScript_CHAM, Character_UnicodeScript_TAI_THAM, Character_UnicodeScript_TAI_VIET, Character_UnicodeScript_AVESTAN, Character_UnicodeScript_EGYPTIAN_HIEROGLYPHS, Character_UnicodeScript_SAMARITAN, Character_UnicodeScript_MANDAIC, Character_UnicodeScript_LISU, Character_UnicodeScript_BAMUM, Character_UnicodeScript_JAVANESE, Character_UnicodeScript_MEETEI_MAYEK, Character_UnicodeScript_IMPERIAL_ARAMAIC, Character_UnicodeScript_OLD_SOUTH_ARABIAN, Character_UnicodeScript_INSCRIPTIONAL_PARTHIAN, Character_UnicodeScript_INSCRIPTIONAL_PAHLAVI, Character_UnicodeScript_OLD_TURKIC, Character_UnicodeScript_BRAHMI, Character_UnicodeScript_KAITHI, Character_UnicodeScript_MEROITIC_HIEROGLYPHS, Character_UnicodeScript_MEROITIC_CURSIVE, Character_UnicodeScript_SORA_SOMPENG, Character_UnicodeScript_CHAKMA, Character_UnicodeScript_SHARADA, Character_UnicodeScript_TAKRI, Character_UnicodeScript_MIAO, Character_UnicodeScript_CAUCASIAN_ALBANIAN, Character_UnicodeScript_BASSA_VAH, Character_UnicodeScript_DUPLOYAN, Character_UnicodeScript_ELBASAN, Character_UnicodeScript_GRANTHA, Character_UnicodeScript_PAHAWH_HMONG, Character_UnicodeScript_KHOJKI, Character_UnicodeScript_LINEAR_A, Character_UnicodeScript_MAHAJANI, Character_UnicodeScript_MANICHAEAN, Character_UnicodeScript_MENDE_KIKAKUI, Character_UnicodeScript_MODI, Character_UnicodeScript_MRO, Character_UnicodeScript_OLD_NORTH_ARABIAN, Character_UnicodeScript_NABATAEAN, Character_UnicodeScript_PALMYRENE, Character_UnicodeScript_PAU_CIN_HAU, Character_UnicodeScript_OLD_PERMIC, Character_UnicodeScript_PSALTER_PAHLAVI, Character_UnicodeScript_SIDDHAM, Character_UnicodeScript_KHUDAWADI, Character_UnicodeScript_TIRHUTA, Character_UnicodeScript_WARANG_CITI, Character_UnicodeScript_AHOM, Character_UnicodeScript_ANATOLIAN_HIEROGLYPHS, Character_UnicodeScript_HATRAN, Character_UnicodeScript_MULTANI, Character_UnicodeScript_OLD_HUNGARIAN, Character_UnicodeScript_SIGNWRITING, Character_UnicodeScript_ADLAM, Character_UnicodeScript_BHAIKSUKI, Character_UnicodeScript_MARCHEN, Character_UnicodeScript_NEWA, Character_UnicodeScript_OSAGE, Character_UnicodeScript_TANGUT, Character_UnicodeScript_MASARAM_GONDI, Character_UnicodeScript_NUSHU, Character_UnicodeScript_SOYOMBO, Character_UnicodeScript_ZANABAZAR_SQUARE, Character_UnicodeScript_HANIFI_ROHINGYA, Character_UnicodeScript_OLD_SOGDIAN, Character_UnicodeScript_SOGDIAN, Character_UnicodeScript_DOGRA, Character_UnicodeScript_GUNJALA_GONDI, Character_UnicodeScript_MAKASAR, Character_UnicodeScript_MEDEFAIDRIN, Character_UnicodeScript_ELYMAIC, Character_UnicodeScript_NANDINAGARI, Character_UnicodeScript_NYIAKENG_PUACHUE_HMONG, Character_UnicodeScript_WANCHO, Character_UnicodeScript_YEZIDI, Character_UnicodeScript_CHORASMIAN, Character_UnicodeScript_DIVES_AKURU, Character_UnicodeScript_KHITAN_SMALL_SCRIPT, Character_UnicodeScript_VITHKUQI, Character_UnicodeScript_OLD_UYGHUR, Character_UnicodeScript_CYPRO_MINOAN, Character_UnicodeScript_TANGSA, Character_UnicodeScript_TOTO, Character_UnicodeScript_KAWI, Character_UnicodeScript_NAG_MUNDARI, Character_UnicodeScript_TODHRI, Character_UnicodeScript_GARAY, Character_UnicodeScript_TULU_TIGALARI, Character_UnicodeScript_SUNUWAR, Character_UnicodeScript_GURUNG_KHEMA, Character_UnicodeScript_KIRAT_RAI, Character_UnicodeScript_OL_ONAL, Character_UnicodeScript_SIDETIC, Character_UnicodeScript_TOLONG_SIKI, Character_UnicodeScript_BERIA_ERFE, Character_UnicodeScript_TAI_YO, Character_UnicodeScript_UNKNOWN) }

func (t *Character_UnicodeScript) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Character_UnicodeScript) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Character_UnicodeScript) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Character_UnicodeScript) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.lang.Character$UnicodeScript.describeConstable()Ljava/util/Optional;")) }

func (t *Character_UnicodeScript) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Character_UnicodeScript) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Character_UnicodeScript) Ref() any { if t == nil { return nil }; return t }

func (t *Character_UnicodeScript) GetClass__Class() *Class { return Character_UnicodeScript_class }

func (t *Character_UnicodeScript) CloneShallow() any { panic(CloneNotSupported(t)) }

func Character_UnicodeScript_InstanceOf(x any) bool { _, ok := x.(*Character_UnicodeScript); return ok }

func Character_UnicodeScript_Cast(x any) *Character_UnicodeScript { if x == nil { return nil }; v, ok := x.(*Character_UnicodeScript); if !ok { panic(ClassCast(x, Character_UnicodeScript_class)) }; return v }
