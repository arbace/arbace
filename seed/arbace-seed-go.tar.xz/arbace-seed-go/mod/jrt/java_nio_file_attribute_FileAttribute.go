//line java_nio_file_attribute_FileAttribute.ae:1
package jrt






type FileAttribute interface{ Object_I; Is_FileAttribute(); Name__String() *String; Value__O() any }

func FileAttribute_InstanceOf(x any) bool { _, ok := x.(FileAttribute); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FileAttribute_class) } }; return ok }

func FileAttribute_Cast(x any) FileAttribute { if x == nil { return nil }; v, ok := x.(FileAttribute); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(FileAttribute_class) } }; if !ok { panic(ClassCast(x, FileAttribute_class)) }; return v }
