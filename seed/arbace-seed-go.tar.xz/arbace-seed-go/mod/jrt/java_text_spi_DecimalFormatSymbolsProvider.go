//line java_text_spi_DecimalFormatSymbolsProvider.ae:1
package jrt










func (t *DecimalFormatSymbolsProvider) Ctor(this DecimalFormatSymbolsProvider_I) { t.LocaleServiceProvider.Ctor(this) }



type DecimalFormatSymbolsProvider struct{ LocaleServiceProvider }

type DecimalFormatSymbolsProvider_I interface{ LocaleServiceProvider_I; Self_DecimalFormatSymbolsProvider() *DecimalFormatSymbolsProvider; GetInstance_Locale__DecimalFormatSymbols(p0 *Locale) *DecimalFormatSymbols }

func (t *DecimalFormatSymbolsProvider) Self_DecimalFormatSymbolsProvider() *DecimalFormatSymbolsProvider { return t }

func DecimalFormatSymbolsProvider_InstanceOf(x any) bool { _, ok := x.(DecimalFormatSymbolsProvider_I); return ok }

func DecimalFormatSymbolsProvider_Cast(x any) DecimalFormatSymbolsProvider_I { if x == nil { return nil }; v, ok := x.(DecimalFormatSymbolsProvider_I); if !ok { panic(ClassCast(x, DecimalFormatSymbolsProvider_class)) }; return v }
