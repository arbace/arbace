//line java_time_LocalTime.ae:1
package jrt






























































































func LocalTime_Now__LocalTime() *LocalTime { LocalTime_Init()
	return LocalTime_Now_Clock__LocalTime(Clock_SystemDefaultZone__Clock())
}
func LocalTime_Now_ZoneId__LocalTime(zone ZoneId_I) *LocalTime { LocalTime_Init()
	return LocalTime_Now_Clock__LocalTime(Clock_System_ZoneId__Clock(zone))
}
func LocalTime_Now_Clock__LocalTime(clock Clock_I) *LocalTime { LocalTime_Init()
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	var now *Instant = clock.Instant__Instant(); return LocalTime_OfInstant_Instant_ZoneId__LocalTime(now, clock.GetZone__ZoneId())
}
func LocalTime_Of_I_I__LocalTime(hour, minute int32) *LocalTime { LocalTime_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_HOUR_OF_DAY; NN(tmp1).CheckValidValue_J__J(int64(hour))
	if minute == 0 {
		return As[*LocalTime](LocalTime_HOURS.A[hour]) } else {
			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MINUTE_OF_HOUR; NN(tmp2).CheckValidValue_J__J(int64(minute)); return LocalTime_New_I_I_I_I(hour, minute, 0, 0)
		} }
func LocalTime_Of_I_I_I__LocalTime(hour, minute, second int32) *LocalTime { LocalTime_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_HOUR_OF_DAY; NN(tmp1).CheckValidValue_J__J(int64(hour))
	if minute|second == 0 {
		return As[*LocalTime](LocalTime_HOURS.A[hour]) } else {

			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MINUTE_OF_HOUR; NN(tmp2).CheckValidValue_J__J(int64(minute))
			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_SECOND_OF_MINUTE; NN(tmp3).CheckValidValue_J__J(int64(second))
			return LocalTime_New_I_I_I_I(hour, minute, second, 0)
		} }
func LocalTime_Of_I_I_I_I__LocalTime(hour, minute, second, nanoOfSecond int32) *LocalTime { LocalTime_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_HOUR_OF_DAY; NN(tmp1).CheckValidValue_J__J(int64(hour))
	var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MINUTE_OF_HOUR; NN(tmp2).CheckValidValue_J__J(int64(minute))
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_SECOND_OF_MINUTE; NN(tmp3).CheckValidValue_J__J(int64(second))
	var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_NANO_OF_SECOND; NN(tmp4).CheckValidValue_J__J(int64(nanoOfSecond))
	return LocalTime_Create_I_I_I_I__LocalTime(hour, minute, second, nanoOfSecond)
}
func LocalTime_OfInstant_Instant_ZoneId__LocalTime(instant *Instant, zone ZoneId_I) *LocalTime { LocalTime_Init()
	Objects_RequireNonNull_O_String__O(instant.Ref(), Lit_2039)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var offset *ZoneOffset = NN(zone.GetRules__ZoneRules()).GetOffset_Instant__ZoneOffset(instant); var localSecond int64 = NN(instant).GetEpochSecond__J() + int64(NN(offset).GetTotalSeconds__I()); var secsOfDay int32 = Math_FloorMod_J_I__I(localSecond, 86400)


	return LocalTime_OfNanoOfDay_J__LocalTime(int64(secsOfDay)*1000000000 + int64(NN(instant).GetNano__I()))
}

func LocalTime_OfSecondOfDay_J__LocalTime(secondOfDay int64) *LocalTime { LocalTime_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_SECOND_OF_DAY; NN(tmp1).CheckValidValue_J__J(secondOfDay)
	var hours int32 = int32(secondOfDay / 3600)
	secondOfDay = secondOfDay - int64(hours*3600)

	var minutes int32 = int32(secondOfDay / 60)
	secondOfDay = secondOfDay - int64(minutes*60)

	return LocalTime_Create_I_I_I_I__LocalTime(hours, minutes, int32(secondOfDay), 0)
}
func LocalTime_OfNanoOfDay_J__LocalTime(nanoOfDay int64) *LocalTime { LocalTime_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_DAY; NN(tmp1).CheckValidValue_J__J(nanoOfDay)
	var hours int32 = int32(nanoOfDay / 3600000000000)
	nanoOfDay = nanoOfDay - int64(hours)*3600000000000
	var minutes int32 = int32(nanoOfDay / 60000000000)
	nanoOfDay = nanoOfDay - int64(minutes)*60000000000

	var seconds int32 = int32(nanoOfDay / 1000000000)
	nanoOfDay = nanoOfDay - int64(seconds)*1000000000

	return LocalTime_Create_I_I_I_I__LocalTime(hours, minutes, seconds, int32(nanoOfDay))
}
func LocalTime_From_TemporalAccessor__LocalTime(temporal TemporalAccessor) *LocalTime { LocalTime_Init()
	Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
	var time *LocalTime = LocalTime_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_LocalTime__TemporalQuery()))
	if time == nil {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2054, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String())))) }
//line :161:1
	return time
}







func LocalTime_Parse_CharSequence__LocalTime(text CharSequence) *LocalTime { LocalTime_Init()
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_LOCAL_TIME; return LocalTime_Parse_CharSequence_DateTimeFormatter__LocalTime(text, tmp1)
}
func LocalTime_Parse_CharSequence_DateTimeFormatter__LocalTime(text CharSequence, formatter *DateTimeFormatter) *LocalTime { LocalTime_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return LocalTime_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return LocalTime_From_TemporalAccessor__LocalTime(p0).Ref() }}))
}



func LocalTime_Create_I_I_I_I__LocalTime(hour, minute, second, nanoOfSecond int32) *LocalTime { LocalTime_Init()
	if minute|second|nanoOfSecond == 0 {
		return As[*LocalTime](LocalTime_HOURS.A[hour]) } else {
			return LocalTime_New_I_I_I_I(hour, minute, second, nanoOfSecond)
		} }
func LocalTime_New_I_I_I_I(p0, p1, p2, p3 int32) *LocalTime { LocalTime_Init(); t := &LocalTime{}; t.Ctor_I_I_I_I(p0, p1, p2, p3); return t }
//line :185:1
func (t *LocalTime) Ctor_I_I_I_I(hour, minute, second, nanoOfSecond int32) {
	t.F_hour = int8(hour)
	t.F_minute = int8(minute)
	t.F_second = int8(second)
	t.F_nano = nanoOfSecond
}
func (t *LocalTime) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		return field.IsTimeBased__Z() } else {
			var tmp1 bool; tmp1 = !(field == nil); if tmp1 { tmp1 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp1
		} }
func (t *LocalTime) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		return unit.IsTimeBased__Z() } else {
			var tmp1 bool; tmp1 = !(unit == nil); if tmp1 { tmp1 = unit.IsSupportedBy_Temporal__Z(t) }; return tmp1
		} }
func (t *LocalTime) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
}
func (t *LocalTime) Get_TemporalField__I(field TemporalField) int32 {
	if ChronoField_InstanceOf(field) { return t.Get0_TemporalField__I(field) } else { return TemporalAccessor_Get_TemporalField__I(t, field)
	} }
func (t *LocalTime) GetLong_TemporalField__J(field TemporalField) int64 {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_DAY; if any(field) == any(tmp1.Ref()) {
			return t.ToNanoOfDay__J() } else {
//line :209:1
				var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MICRO_OF_DAY; if any(field) == any(tmp2.Ref()) {

					return t.ToNanoOfDay__J() / 1000 } else {
//line :209:1
						return int64(t.Get0_TemporalField__I(field)) } } } else {



							return field.GetFrom_TemporalAccessor__J(t)
						} }
func (t *LocalTime) Get0_TemporalField__I(field TemporalField) int32 {
	switch NN(ChronoField_Cast(field)).F_ordinal { case 0: return t.F_nano; case 1:


		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2055))); case 2:

		return t.F_nano / 1000; case 3:

		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2056))); case 4:

		return t.F_nano / 1000000; case 5:
		return int32(t.ToNanoOfDay__J() / 1000000); case 6:
		return int32(t.F_second); case 7:
		return t.ToSecondOfDay__I(); case 8:
		return int32(t.F_minute); case 9:
		return int32(t.F_hour)*60 + int32(t.F_minute); case 10:
		return int32(t.F_hour) % 12; case 11:

		var ham int32 = int32(t.F_hour) % 12
		if ham%12 == 0 { return 12 } else { return ham }; case 12:
		return int32(t.F_hour); case 13:
		var tmp1 int8; if int32(t.F_hour) == 0 { tmp1 = 24 } else { tmp1 = t.F_hour }; return int32(tmp1); case 14:
		return int32(t.F_hour) / 12; default:
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))}; panic("a2g: unreachable")
}
func (t *LocalTime) GetHour__I() int32 { return int32(t.F_hour) }

func (t *LocalTime) GetMinute__I() int32 { return int32(t.F_minute) }

func (t *LocalTime) GetSecond__I() int32 { return int32(t.F_second) }

func (t *LocalTime) GetNano__I() int32 { return t.F_nano }

func (t *LocalTime) With_TemporalAdjuster__LocalTime(adjuster TemporalAdjuster) *LocalTime {
	if LocalTime_InstanceOf(adjuster) {
		return LocalTime_Cast(adjuster) } else {
			return LocalTime_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
		} }
func (t *LocalTime) With_TemporalField_J__LocalTime(field TemporalField, newValue int64) *LocalTime {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)

		NN(chronoField).CheckValidValue_J__J(newValue)
		switch NN(chronoField).F_ordinal { case 0:
			return t.WithNano_I__LocalTime(int32(newValue)); case 1:
			return LocalTime_OfNanoOfDay_J__LocalTime(newValue); case 2:
			return t.WithNano_I__LocalTime(int32(newValue) * 1000); case 3:
			return LocalTime_OfNanoOfDay_J__LocalTime(newValue * 1000); case 4:
			return t.WithNano_I__LocalTime(int32(newValue) * 1000000); case 5:
			return LocalTime_OfNanoOfDay_J__LocalTime(newValue * 1000000); case 6:
			return t.WithSecond_I__LocalTime(int32(newValue)); case 7:
			return t.PlusSeconds_J__LocalTime(newValue - int64(t.ToSecondOfDay__I())); case 8:
			return t.WithMinute_I__LocalTime(int32(newValue)); case 9:

			return t.PlusMinutes_J__LocalTime(newValue - int64(int32(t.F_hour)*60+int32(t.F_minute))); case 10:





			return t.PlusHours_J__LocalTime(newValue - int64(int32(t.F_hour)%12)); case 11:

			var tmp2 int64
			if newValue == 12 { tmp2 = 0 } else { tmp2 = newValue }
//line :276:1
			return t.PlusHours_J__LocalTime(tmp2 - int64(int32(t.F_hour)%12))
		case 12:

			return t.WithHour_I__LocalTime(int32(newValue)); case 13:
			var tmp3 int64; if newValue == 24 { tmp3 = 0 } else { tmp3 = newValue }; return t.WithHour_I__LocalTime(int32(tmp3)); case 14:

			return t.PlusHours_J__LocalTime((newValue - int64(int32(t.F_hour)/12)) * 12); default:



			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return LocalTime_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue)) } }; panic("a2g: unreachable")
}
func (t *LocalTime) WithHour_I__LocalTime(hour int32) *LocalTime {
	if int32(t.F_hour) == hour { return t } else {


		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_HOUR_OF_DAY; NN(tmp1).CheckValidValue_J__J(int64(hour))
		return LocalTime_Create_I_I_I_I__LocalTime(hour, int32(t.F_minute), int32(t.F_second), t.F_nano)
	} }
func (t *LocalTime) WithMinute_I__LocalTime(minute int32) *LocalTime {
	if int32(t.F_minute) == minute { return t } else {


		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MINUTE_OF_HOUR; NN(tmp1).CheckValidValue_J__J(int64(minute))
		return LocalTime_Create_I_I_I_I__LocalTime(int32(t.F_hour), minute, int32(t.F_second), t.F_nano)
	} }
func (t *LocalTime) WithSecond_I__LocalTime(second int32) *LocalTime {
	if int32(t.F_second) == second { return t } else {


		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_SECOND_OF_MINUTE; NN(tmp1).CheckValidValue_J__J(int64(second))
		return LocalTime_Create_I_I_I_I__LocalTime(int32(t.F_hour), int32(t.F_minute), second, t.F_nano)
	} }
func (t *LocalTime) WithNano_I__LocalTime(nanoOfSecond int32) *LocalTime {
	if t.F_nano == nanoOfSecond { return t } else {


		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_SECOND; NN(tmp1).CheckValidValue_J__J(int64(nanoOfSecond))
		return LocalTime_Create_I_I_I_I__LocalTime(int32(t.F_hour), int32(t.F_minute), int32(t.F_second), nanoOfSecond)
	} }
func (t *LocalTime) TruncatedTo_TemporalUnit__LocalTime(unit TemporalUnit) *LocalTime {
	var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_NANOS; if any(unit) == any(tmp1.Ref()) { return t } else {

		var unitDur *Duration = unit.GetDuration__Duration()
		if NN(unitDur).GetSeconds__J() > 86400 {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2025)))
		}
		var dur int64 = NN(unitDur).ToNanos__J()
		if 86400000000000%dur == 0 { } else {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2026)))
		}
		var nod int64 = t.ToNanoOfDay__J()
		return LocalTime_OfNanoOfDay_J__LocalTime(nod / dur * dur)
	} }
func (t *LocalTime) Plus_TemporalAmount__LocalTime(amountToAdd TemporalAmount) *LocalTime {
	return LocalTime_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
}
func (t *LocalTime) Plus_J_TemporalUnit__LocalTime(amountToAdd int64, unit TemporalUnit) *LocalTime {
	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 0:
			return t.PlusNanos_J__LocalTime(amountToAdd); case 1:

			return t.PlusNanos_J__LocalTime(amountToAdd % 86400000000 * 1000); case 2:


			return t.PlusNanos_J__LocalTime(amountToAdd % 86400000 * 1000000); case 3:

			return t.PlusSeconds_J__LocalTime(amountToAdd); case 4:
			return t.PlusMinutes_J__LocalTime(amountToAdd); case 5:
			return t.PlusHours_J__LocalTime(amountToAdd); case 6:
			return t.PlusHours_J__LocalTime(amountToAdd % 2 * 12); default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
				return LocalTime_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd)) } }; panic("a2g: unreachable")
}
func (t *LocalTime) PlusHours_J__LocalTime(hoursToAdd int64) *LocalTime {
	if hoursToAdd == 0 { return t } else {

		var newHour int32 = (int32(hoursToAdd%24) + int32(t.F_hour) + 24) % 24






		return LocalTime_Create_I_I_I_I__LocalTime(newHour, int32(t.F_minute), int32(t.F_second), t.F_nano)
	} }
func (t *LocalTime) PlusMinutes_J__LocalTime(minutesToAdd int64) *LocalTime {
	if minutesToAdd == 0 { return t } else {

		var mofd int32 = int32(t.F_hour)*60 + int32(t.F_minute); var newMofd int32 = (int32(minutesToAdd%1440) + mofd + 1440) % 1440







		if mofd == newMofd { return t } else {

			var newHour int32 = newMofd / 60; var newMinute int32 = newMofd % 60

			return LocalTime_Create_I_I_I_I__LocalTime(newHour, newMinute, int32(t.F_second), t.F_nano)
		} } }
func (t *LocalTime) PlusSeconds_J__LocalTime(secondstoAdd int64) *LocalTime {
	if secondstoAdd == 0 { return t } else {

		var sofd int32 = int32(t.F_hour)*3600 + int32(t.F_minute)*60 + int32(t.F_second); var newSofd int32 = (int32(secondstoAdd%86400) + sofd + 86400) % 86400










		if sofd == newSofd { return t } else {

			var newHour int32 = newSofd / 3600; var newMinute int32 = newSofd / 60 % 60; var newSecond int32 = newSofd % 60




			return LocalTime_Create_I_I_I_I__LocalTime(newHour, newMinute, newSecond, t.F_nano)
		} } }
func (t *LocalTime) PlusNanos_J__LocalTime(nanosToAdd int64) *LocalTime {
	if nanosToAdd == 0 { return t } else {

		var nofd int64 = t.ToNanoOfDay__J(); var newNofd int64 = (nanosToAdd%86400000000000 + nofd + 86400000000000) % 86400000000000





		if nofd == newNofd { return t } else {

			var newHour int32 = int32(newNofd / 3600000000000); var newMinute int32 = int32(newNofd / 60000000000 % 60); var newSecond int32 = int32(newNofd / 1000000000 % 60); var newNano int32 = int32(newNofd % 1000000000)









			return LocalTime_Create_I_I_I_I__LocalTime(newHour, newMinute, newSecond, newNano)
		} } }
func (t *LocalTime) Minus_TemporalAmount__LocalTime(amountToSubtract TemporalAmount) *LocalTime {
	return LocalTime_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
}
func (t *LocalTime) Minus_J_TemporalUnit__LocalTime(amountToSubtract int64, unit TemporalUnit) *LocalTime {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__LocalTime(9223372036854775807, unit)).Plus_J_TemporalUnit__LocalTime(1, unit) } else {
			return t.Plus_J_TemporalUnit__LocalTime(-amountToSubtract, unit)
		} }
func (t *LocalTime) MinusHours_J__LocalTime(hoursToSubtract int64) *LocalTime {
	return t.PlusHours_J__LocalTime(-(hoursToSubtract % 24))
}
func (t *LocalTime) MinusMinutes_J__LocalTime(minutesToSubtract int64) *LocalTime {
	return t.PlusMinutes_J__LocalTime(-(minutesToSubtract % 1440))
}
func (t *LocalTime) MinusSeconds_J__LocalTime(secondsToSubtract int64) *LocalTime {
	return t.PlusSeconds_J__LocalTime(-(secondsToSubtract % 86400))
}
func (t *LocalTime) MinusNanos_J__LocalTime(nanosToSubtract int64) *LocalTime {
	return t.PlusNanos_J__LocalTime(-(nanosToSubtract % 86400000000000))
}
func (t *LocalTime) Query_TemporalQuery__O(query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = query == TemporalQueries_Chronology__TemporalQuery(); if !tmp4 {
		tmp4 = query == TemporalQueries_ZoneId__TemporalQuery() }
//line :447:1
	tmp3 = tmp4; if !tmp3 {

		tmp3 = query == TemporalQueries_Zone__TemporalQuery() }
//line :447:1
	tmp2 = tmp3; if !tmp2 {


		tmp2 = query == TemporalQueries_Offset__TemporalQuery() }
//line :447:1
	tmp1 = tmp2; if tmp1 { return nil } else {



		if query == TemporalQueries_LocalTime__TemporalQuery() { return t } else {

			if query == TemporalQueries_LocalDate__TemporalQuery() { return nil } else {
				if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_NANOS.Ref() } else {

					return query.QueryFrom_TemporalAccessor__O(t)
				} } } } }
func (t *LocalTime) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_DAY; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); return temporal.With_TemporalField_J__Temporal(tmp2, t.ToNanoOfDay__J())
}
func (t *LocalTime) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	{ var end *LocalTime = LocalTime_From_TemporalAccessor__LocalTime(endExclusive); var tmp1 TemporalUnit = unit
		if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1); var nanosUntil int64 = NN(end).ToNanoOfDay__J() - t.ToNanoOfDay__J()

			switch NN(chronoUnit).F_ordinal { case 0: return nanosUntil; case 1:

				return nanosUntil / 1000; case 2:
				return nanosUntil / 1000000; case 3:
				return nanosUntil / 1000000000; case 4:
				return nanosUntil / 60000000000; case 5:
				return nanosUntil / 3600000000000; case 6:
				return nanosUntil / 43200000000000; default:
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
					return unit.Between_Temporal_Temporal__J(t, Up_LocalTime_Temporal(end)) } }; panic("a2g: unreachable")
}
func (t *LocalTime) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *LocalTime) AtDate_LocalDate__LocalDateTime(date *LocalDate) *LocalDateTime {
	return LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(date, t)
}
func (t *LocalTime) AtOffset_ZoneOffset__OffsetTime(offset *ZoneOffset) *OffsetTime {
	return OffsetTime_Of_LocalTime_ZoneOffset__OffsetTime(t, offset)
}
func (t *LocalTime) ToSecondOfDay__I() int32 {
	var total int32 = int32(t.F_hour) * 3600
	total = total + int32(t.F_minute)*60
	total = total + int32(t.F_second)
//line :487:1
	return total
}



func (t *LocalTime) ToNanoOfDay__J() int64 {
	var total int64 = int64(t.F_hour) * 3600000000000
	total = total + int64(t.F_minute)*60000000000
	total = total + int64(t.F_second)*1000000000
	total = total + int64(t.F_nano)
//line :493:1
	return total
}




func (t *LocalTime) ToEpochSecond_LocalDate_ZoneOffset__J(date *LocalDate, offset *ZoneOffset) int64 {
	Objects_RequireNonNull_O_String__O(date.Ref(), Lit_1440)
	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	var epochDay int64 = NN(date).ToEpochDay__J(); var secs int64 = epochDay*86400 + int64(t.ToSecondOfDay__I())

	secs = secs - int64(NN(offset).GetTotalSeconds__I())
//line :502:1
	return secs
}



func (t *LocalTime) CompareTo_LocalTime__I(other *LocalTime) int32 {
	var tmp1 int32 = int32(t.F_hour); var cmp int32 = Integer_Compare_I_I__I(tmp1, int32(other.F_hour))
	if cmp == 0 {
		var tmp2 int32 = int32(t.F_minute); cmp = Integer_Compare_I_I__I(tmp2, int32(other.F_minute))
		if cmp == 0 {
			var tmp3 int32 = int32(t.F_second); cmp = Integer_Compare_I_I__I(tmp3, int32(other.F_second))
			if cmp == 0 { var tmp4 int32 = t.F_nano; cmp = Integer_Compare_I_I__I(tmp4, other.F_nano) } } }
//line :508:1
	return cmp
}






func (t *LocalTime) IsAfter_LocalTime__Z(other *LocalTime) bool {
	return t.CompareTo_LocalTime__I(other) > 0
}
func (t *LocalTime) IsBefore_LocalTime__Z(other *LocalTime) bool {
	return t.CompareTo_LocalTime__I(other) < 0
}
func (t *LocalTime) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if LocalTime_InstanceOf(tmp1) { var other *LocalTime = LocalTime_Cast(tmp1); var tmp2 int32 = int32(t.F_hour)
			if tmp2 == int32(other.F_hour) {
				var tmp3 int32 = int32(t.F_minute); if tmp3 == int32(other.F_minute) {
					var tmp4 int32 = int32(t.F_second); if tmp4 == int32(other.F_second) { var tmp5 int32 = t.F_nano; return tmp5 == other.F_nano } else { return false } } else {
//line :527:1
						return false } } else {
//line :526:1
							return false
						} } else {
//line :525:1
							return false
						}
	}
}




func (t *LocalTime) HashCode__I() int32 {
	return Long_HashCode_J__I(t.ToNanoOfDay__J())
}
func (t *LocalTime) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New_I(18); DateTimeHelper_FormatTo_StringBuilder_LocalTime__V(buf, t); return NN(buf).ToString__String()
}
func (t *LocalTime) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.LocalTime.writeReplace()Ljava/lang/Object;")) }

















func LocalTime_ReadExternal_DataInput__LocalTime(p0 DataInput) *LocalTime { LocalTime_Init(); panic(A2g_NotTranslated("java.time.LocalTime.readExternal(Ljava/io/DataInput;)Ljava/time/LocalTime;")) }



type LocalTime struct{ Object; F_hour, F_minute, F_second int8; F_nano int32 }

func (t *LocalTime) Is_Temporal() {}

func (t *LocalTime) Is_TemporalAdjuster() {}

func (t *LocalTime) Is_Comparable() {}

func (t *LocalTime) Is_Serializable() {}

func (t *LocalTime) Is_TemporalAccessor() {}

var LocalTime_MIN *LocalTime

var LocalTime_MAX *LocalTime

var LocalTime_MIDNIGHT *LocalTime

var LocalTime_NOON *LocalTime

var LocalTime_HOURS *RefArray

const LocalTime_HOURS_PER_DAY int32 = 24

const LocalTime_MINUTES_PER_HOUR int32 = 60

const LocalTime_MINUTES_PER_DAY int32 = 1440

const LocalTime_SECONDS_PER_MINUTE int32 = 60

const LocalTime_SECONDS_PER_HOUR int32 = 3600

const LocalTime_SECONDS_PER_DAY int32 = 86400

const LocalTime_MILLIS_PER_SECOND int64 = 1000

const LocalTime_MILLIS_PER_DAY int64 = 86400000

const LocalTime_MICROS_PER_SECOND int64 = 1000000

const LocalTime_MICROS_PER_DAY int64 = 86400000000

const LocalTime_NANOS_PER_MILLI int64 = 1000000

const LocalTime_NANOS_PER_SECOND int64 = 1000000000

const LocalTime_NANOS_PER_MINUTE int64 = 60000000000

const LocalTime_NANOS_PER_HOUR int64 = 3600000000000

const LocalTime_NANOS_PER_DAY int64 = 86400000000000

const LocalTime_serialVersionUID int64 = 6414437269572265201

var LocalTime_init ClassInit

func LocalTime_Init() { if !LocalTime_init.Done() { LocalTime_init.Run(LocalTime_clinit) } }

func LocalTime_clinit() { LocalTime_HOURS = NewRefArray(LocalTime_class, 24)
//line :42:1
	var i int32 = 0; L1: for {
		if i < int32(len(LocalTime_HOURS.A)) { var tmp1 *RefArray = LocalTime_HOURS; tmp1.Store(i, LocalTime_New_I_I_I_I(i, 0, 0, 0)); i = i + 1; continue L1 }
//line :42:1
		break L1
	}
	LocalTime_MIDNIGHT = As[*LocalTime](LocalTime_HOURS.A[0])
	LocalTime_NOON = As[*LocalTime](LocalTime_HOURS.A[12])
	LocalTime_MIN = As[*LocalTime](LocalTime_HOURS.A[0])
	LocalTime_MAX = LocalTime_New_I_I_I_I(23, 59, 59, 999999999)
}




























































































































































































































































































































































































































































































































































































func (t *LocalTime) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_LocalTime_Temporal(t.With_TemporalAdjuster__LocalTime(p0)) }

func (t *LocalTime) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_LocalTime_Temporal(t.With_TemporalField_J__LocalTime(p0, p1)) }

func (t *LocalTime) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_LocalTime_Temporal(t.Plus_TemporalAmount__LocalTime(p0)) }

func (t *LocalTime) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_LocalTime_Temporal(t.Plus_J_TemporalUnit__LocalTime(p0, p1)) }

func (t *LocalTime) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_LocalTime_Temporal(t.Minus_TemporalAmount__LocalTime(p0)) }

func (t *LocalTime) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_LocalTime_Temporal(t.Minus_J_TemporalUnit__LocalTime(p0, p1)) }

func (t *LocalTime) CompareTo_O__I(p0 any) int32 { return t.CompareTo_LocalTime__I(LocalTime_Cast(p0)) }

func (t *LocalTime) Ref() any { if t == nil { return nil }; return t }

func (t *LocalTime) GetClass__Class() *Class { return LocalTime_class }

func (t *LocalTime) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocalTime) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocalTime_InstanceOf(x any) bool { _, ok := x.(*LocalTime); return ok }

func LocalTime_Cast(x any) *LocalTime { if x == nil { return nil }; v, ok := x.(*LocalTime); if !ok { panic(ClassCast(x, LocalTime_class)) }; return v }
