//line java_util_ArraysParallelSortHelpers.ae:1
package jrt











func ArraysParallelSortHelpers_EmptyCompleter_New_CountedCompleter(p0 CountedCompleter_I) *ArraysParallelSortHelpers_EmptyCompleter { ArraysParallelSortHelpers_EmptyCompleter_Init(); t := &ArraysParallelSortHelpers_EmptyCompleter{}; t.Ctor_CountedCompleter(p0); return t }
//line :13:1
func (t *ArraysParallelSortHelpers_EmptyCompleter) Ctor_CountedCompleter(p CountedCompleter_I) { t.CountedCompleter.Ctor_CountedCompleter(t, p) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Compute__V() {}








func ArraysParallelSortHelpers_Relay_New_CountedCompleter(p0 CountedCompleter_I) *ArraysParallelSortHelpers_Relay { ArraysParallelSortHelpers_Relay_Init(); t := &ArraysParallelSortHelpers_Relay{}; t.Ctor_CountedCompleter(p0); return t }
//line :24:1
func (t *ArraysParallelSortHelpers_Relay) Ctor_CountedCompleter(task CountedCompleter_I) { t.CountedCompleter.Ctor_CountedCompleter_I(t, nil, 1)

	t.F_task = task
}
func (t *ArraysParallelSortHelpers_Relay) Compute__V() {}

func (t *ArraysParallelSortHelpers_Relay) OnCompletion_CountedCompleter__V(t_ CountedCompleter_I) {
	t.F_task.Compute__V()
}





















func ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(p0 CountedCompleter_I, p1, p2 *RefArray, p3, p4, p5, p6 int32, p7 Comparator) *ArraysParallelSortHelpers_FJObject_Sorter { ArraysParallelSortHelpers_FJObject_Sorter_Init(); t := &ArraysParallelSortHelpers_FJObject_Sorter{}; t.Ctor_CountedCompleter_O1_O1_I_I_I_I_Comparator(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :54:1
func (t *ArraysParallelSortHelpers_FJObject_Sorter) Ctor_CountedCompleter_O1_O1_I_I_I_I_Comparator(par CountedCompleter_I, a, w *RefArray, base, size, wbase, gran int32, comparator Comparator) { t.CountedCompleter.Ctor_CountedCompleter(t, par)


	t.F_a = a
	t.F_w = w
	t.F_base = base
	t.F_size = size
	t.F_wbase = wbase
	t.F_gran = gran
	t.F_comparator = comparator
}
func (t *ArraysParallelSortHelpers_FJObject_Sorter) Compute__V() {
	var s CountedCompleter_I = t; var c Comparator = t.F_comparator; var a *RefArray = t.F_a; var w *RefArray = t.F_w; var b int32 = t.F_base; var n int32 = t.F_size; var wb int32 = t.F_wbase; var g int32 = t.F_gran







L1: for { if n > g {
	var h int32 = int32(uint32(n) >> 1); var q int32 = int32(uint32(h) >> 1); var u int32 = h + q; var fc *ArraysParallelSortHelpers_Relay = ArraysParallelSortHelpers_Relay_New_CountedCompleter(ArraysParallelSortHelpers_FJObject_Merger_New_CountedCompleter_O1_O1_I_I_I_I_I_I_Comparator(s, w, a, wb, h, wb+h, n-h, b, g, c)); var rc *ArraysParallelSortHelpers_Relay = ArraysParallelSortHelpers_Relay_New_CountedCompleter(ArraysParallelSortHelpers_FJObject_Merger_New_CountedCompleter_O1_O1_I_I_I_I_I_I_Comparator(Up_ArraysParallelSortHelpers_Relay_CountedCompleter(fc), a, w, b+h, q, b+u, n-u, wb+h, g, c))






















	ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(Up_ArraysParallelSortHelpers_Relay_CountedCompleter(rc), a, w, b+u, n-u, wb+u, g, c).Fork__ForkJoinTask()







	ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(Up_ArraysParallelSortHelpers_Relay_CountedCompleter(rc), a, w, b+h, q, wb+h, g, c).Fork__ForkJoinTask()
	var bc *ArraysParallelSortHelpers_Relay = ArraysParallelSortHelpers_Relay_New_CountedCompleter(ArraysParallelSortHelpers_FJObject_Merger_New_CountedCompleter_O1_O1_I_I_I_I_I_I_Comparator(Up_ArraysParallelSortHelpers_Relay_CountedCompleter(fc), a, w, b, q, b+q, h-q, wb, g, c))









	ArraysParallelSortHelpers_FJObject_Sorter_New_CountedCompleter_O1_O1_I_I_I_I_Comparator(Up_ArraysParallelSortHelpers_Relay_CountedCompleter(bc), a, w, b+q, h-q, wb+q, g, c).Fork__ForkJoinTask()







	s = ArraysParallelSortHelpers_EmptyCompleter_New_CountedCompleter(Up_ArraysParallelSortHelpers_Relay_CountedCompleter(bc))
	n = q
//line :74:1
	continue L1 }; break L1
}



















































	TimSort_Sort_O1_I_I_Comparator_O1_I_I__V(a, b, b+n, c, w, wb, n)
	s.TryComplete__V()
}
























func ArraysParallelSortHelpers_FJObject_Merger_New_CountedCompleter_O1_O1_I_I_I_I_I_I_Comparator(p0 CountedCompleter_I, p1, p2 *RefArray, p3, p4, p5, p6, p7, p8 int32, p9 Comparator) *ArraysParallelSortHelpers_FJObject_Merger { ArraysParallelSortHelpers_FJObject_Merger_Init(); t := &ArraysParallelSortHelpers_FJObject_Merger{}; t.Ctor_CountedCompleter_O1_O1_I_I_I_I_I_I_Comparator(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :154:1
func (t *ArraysParallelSortHelpers_FJObject_Merger) Ctor_CountedCompleter_O1_O1_I_I_I_I_I_I_Comparator(par CountedCompleter_I, a, w *RefArray, lbase, lsize, rbase, rsize, wbase, gran int32, comparator Comparator) { t.CountedCompleter.Ctor_CountedCompleter(t, par)



	t.F_a = a
	t.F_w = w
	t.F_lbase = lbase
	t.F_lsize = lsize
	t.F_rbase = rbase
	t.F_rsize = rsize
	t.F_wbase = wbase
	t.F_gran = gran
	t.F_comparator = comparator
}
func (t *ArraysParallelSortHelpers_FJObject_Merger) Compute__V() {
	var c Comparator = t.F_comparator; var a *RefArray = t.F_a; var w *RefArray = t.F_w; var lb int32 = t.F_lbase; var ln int32 = t.F_lsize; var rb int32 = t.F_rbase; var rn int32 = t.F_rsize; var k int32 = t.F_wbase; var g int32 = t.F_gran; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool








	tmp6 = a == nil; if !tmp6 { tmp6 = w == nil }; tmp5 = tmp6; if !tmp5 { tmp5 = lb < 0 }; tmp4 = tmp5; if !tmp4 { tmp4 = rb < 0 }; tmp3 = tmp4; if !tmp3 { tmp3 = k < 0 }; tmp2 = tmp3; if !tmp2 { tmp2 = c == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalStateException_New())) }
	var lh int32 = 0
	var rh int32 = 0
L1: for {
	if ln >= rn {

		if ln <= g { break L1 }
		rh = rn
		var split any; var tmp7 int32

		lh = int32(uint32(ln) >> 1); tmp7 = lh
//line :187:1
		split = a.A[tmp7+lb]; var lo int32 = 0




	L2: for { if lo < rh {
		var rm int32 = int32(uint32(lo+rh) >> 1)
		if c.Compare_O_O__I(split, a.A[rm+rb]) <= 0 {
			rh = rm } else {
				lo = rm + 1 }
//line :192:1
		continue L2 }; break L2 } } else {





			if rn <= g { break L1 }
			lh = ln
			var split_2 any; var tmp8 int32

			rh = int32(uint32(rn) >> 1); tmp8 = rh
//line :200:1
			split_2 = a.A[tmp8+rb]; var lo_2 int32 = 0




		L3: for { if lo_2 < lh {
			var lm int32 = int32(uint32(lo_2+lh) >> 1)
			if c.Compare_O_O__I(split_2, a.A[lm+lb]) <= 0 {
				lh = lm } else {
					lo_2 = lm + 1 }
//line :205:1
			continue L3 }; break L3
		}
		}


	var m *ArraysParallelSortHelpers_FJObject_Merger = ArraysParallelSortHelpers_FJObject_Merger_New_CountedCompleter_O1_O1_I_I_I_I_I_I_Comparator(t, a, w, lb+lh, ln-lh, rb+rh, rn-rh, k+lh+rh, g, c)










	rn = rh
	ln = lh
	t.AddToPendingCount_I__V(1)
	NN(m).Fork__ForkJoinTask()
//line :182:1
	continue L1
}









































	var lf int32 = lb + ln; var rf int32 = rb + rn

L4: for { var tmp9 bool; var tmp10 bool; tmp10 = lb < lf; if tmp10 { tmp10 = rb < rf }; tmp9 = tmp10; if tmp9 {
	var t_ any; var al any; var ar any; var tmp11 any


	al = a.A[lb]; tmp11 = al; var tmp12 any = tmp11; var tmp13 any; ar = a.A[rb]; tmp13 = ar; if c.Compare_O_O__I(tmp12, tmp13) <= 0 {
		lb = lb + 1; t_ = al } else {
			rb = rb + 1; t_ = ar }
	w.Store(k, t_)
	k = k + 1
//line :227:1
	continue L4 }; break L4
}







	if rb < rf {
		System_Arraycopy_O_I_O_I_I__V(a.Ref(), rb, w.Ref(), k, rf-rb) } else {
//line :236:1
			if lb < lf {

				System_Arraycopy_O_I_O_I_I__V(a.Ref(), lb, w.Ref(), k, lf-lb) } }
	t.TryComplete__V()
}


type ArraysParallelSortHelpers struct{ Object }

func ArraysParallelSortHelpers_New() *ArraysParallelSortHelpers { t := &ArraysParallelSortHelpers{}; t.Ctor(); return t }

func (t *ArraysParallelSortHelpers) Ctor() {}

func (t *ArraysParallelSortHelpers) Ref() any { if t == nil { return nil }; return t }

func (t *ArraysParallelSortHelpers) GetClass__Class() *Class { return ArraysParallelSortHelpers_class }

func (t *ArraysParallelSortHelpers) ToString__String() *String { return Object_toString(t) }

func (t *ArraysParallelSortHelpers) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArraysParallelSortHelpers) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArraysParallelSortHelpers_InstanceOf(x any) bool { _, ok := x.(*ArraysParallelSortHelpers); return ok }

func ArraysParallelSortHelpers_Cast(x any) *ArraysParallelSortHelpers { if x == nil { return nil }; v, ok := x.(*ArraysParallelSortHelpers); if !ok { panic(ClassCast(x, ArraysParallelSortHelpers_class)) }; return v }



type ArraysParallelSortHelpers_EmptyCompleter struct{ CountedCompleter }

const ArraysParallelSortHelpers_EmptyCompleter_serialVersionUID int64 = 2446542900576103244

var ArraysParallelSortHelpers_EmptyCompleter_init ClassInit

func ArraysParallelSortHelpers_EmptyCompleter_Init() { if !ArraysParallelSortHelpers_EmptyCompleter_init.Done() { ArraysParallelSortHelpers_EmptyCompleter_init.Run(ArraysParallelSortHelpers_EmptyCompleter_clinit) } }

func ArraysParallelSortHelpers_EmptyCompleter_clinit() { CountedCompleter_Init() }

func (t *ArraysParallelSortHelpers_EmptyCompleter) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Ref() any { if t == nil { return nil }; return t }

func (t *ArraysParallelSortHelpers_EmptyCompleter) GetClass__Class() *Class { return ArraysParallelSortHelpers_EmptyCompleter_class }

func (t *ArraysParallelSortHelpers_EmptyCompleter) ToString__String() *String { return Object_toString(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArraysParallelSortHelpers_EmptyCompleter) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArraysParallelSortHelpers_EmptyCompleter_InstanceOf(x any) bool { _, ok := x.(*ArraysParallelSortHelpers_EmptyCompleter); return ok }

func ArraysParallelSortHelpers_EmptyCompleter_Cast(x any) *ArraysParallelSortHelpers_EmptyCompleter { if x == nil { return nil }; v, ok := x.(*ArraysParallelSortHelpers_EmptyCompleter); if !ok { panic(ClassCast(x, ArraysParallelSortHelpers_EmptyCompleter_class)) }; return v }



type ArraysParallelSortHelpers_FJObject struct{ Object }

func ArraysParallelSortHelpers_FJObject_New() *ArraysParallelSortHelpers_FJObject { t := &ArraysParallelSortHelpers_FJObject{}; t.Ctor(); return t }

func (t *ArraysParallelSortHelpers_FJObject) Ctor() {}

func (t *ArraysParallelSortHelpers_FJObject) Ref() any { if t == nil { return nil }; return t }

func (t *ArraysParallelSortHelpers_FJObject) GetClass__Class() *Class { return ArraysParallelSortHelpers_FJObject_class }

func (t *ArraysParallelSortHelpers_FJObject) ToString__String() *String { return Object_toString(t) }

func (t *ArraysParallelSortHelpers_FJObject) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArraysParallelSortHelpers_FJObject) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArraysParallelSortHelpers_FJObject_InstanceOf(x any) bool { _, ok := x.(*ArraysParallelSortHelpers_FJObject); return ok }

func ArraysParallelSortHelpers_FJObject_Cast(x any) *ArraysParallelSortHelpers_FJObject { if x == nil { return nil }; v, ok := x.(*ArraysParallelSortHelpers_FJObject); if !ok { panic(ClassCast(x, ArraysParallelSortHelpers_FJObject_class)) }; return v }



type ArraysParallelSortHelpers_FJObject_Merger struct{ CountedCompleter; F_a, F_w *RefArray; F_lbase, F_lsize, F_rbase, F_rsize, F_wbase, F_gran int32; F_comparator Comparator }

const ArraysParallelSortHelpers_FJObject_Merger_serialVersionUID int64 = 2446542900576103244

var ArraysParallelSortHelpers_FJObject_Merger_init ClassInit

func ArraysParallelSortHelpers_FJObject_Merger_Init() { if !ArraysParallelSortHelpers_FJObject_Merger_init.Done() { ArraysParallelSortHelpers_FJObject_Merger_init.Run(ArraysParallelSortHelpers_FJObject_Merger_clinit) } }

func ArraysParallelSortHelpers_FJObject_Merger_clinit() { CountedCompleter_Init() }

func (t *ArraysParallelSortHelpers_FJObject_Merger) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Ref() any { if t == nil { return nil }; return t }

func (t *ArraysParallelSortHelpers_FJObject_Merger) GetClass__Class() *Class { return ArraysParallelSortHelpers_FJObject_Merger_class }

func (t *ArraysParallelSortHelpers_FJObject_Merger) ToString__String() *String { return Object_toString(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArraysParallelSortHelpers_FJObject_Merger) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArraysParallelSortHelpers_FJObject_Merger_InstanceOf(x any) bool { _, ok := x.(*ArraysParallelSortHelpers_FJObject_Merger); return ok }

func ArraysParallelSortHelpers_FJObject_Merger_Cast(x any) *ArraysParallelSortHelpers_FJObject_Merger { if x == nil { return nil }; v, ok := x.(*ArraysParallelSortHelpers_FJObject_Merger); if !ok { panic(ClassCast(x, ArraysParallelSortHelpers_FJObject_Merger_class)) }; return v }



type ArraysParallelSortHelpers_FJObject_Sorter struct{ CountedCompleter; F_a, F_w *RefArray; F_base, F_size, F_wbase, F_gran int32; F_comparator Comparator }

const ArraysParallelSortHelpers_FJObject_Sorter_serialVersionUID int64 = 2446542900576103244

var ArraysParallelSortHelpers_FJObject_Sorter_init ClassInit

func ArraysParallelSortHelpers_FJObject_Sorter_Init() { if !ArraysParallelSortHelpers_FJObject_Sorter_init.Done() { ArraysParallelSortHelpers_FJObject_Sorter_init.Run(ArraysParallelSortHelpers_FJObject_Sorter_clinit) } }

func ArraysParallelSortHelpers_FJObject_Sorter_clinit() { CountedCompleter_Init() }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) OnCompletion_CountedCompleter__V(p0 CountedCompleter_I) { t.Impl_OnCompletion_CountedCompleter__V(t, p0) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Ref() any { if t == nil { return nil }; return t }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) GetClass__Class() *Class { return ArraysParallelSortHelpers_FJObject_Sorter_class }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) ToString__String() *String { return Object_toString(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArraysParallelSortHelpers_FJObject_Sorter) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArraysParallelSortHelpers_FJObject_Sorter_InstanceOf(x any) bool { _, ok := x.(*ArraysParallelSortHelpers_FJObject_Sorter); return ok }

func ArraysParallelSortHelpers_FJObject_Sorter_Cast(x any) *ArraysParallelSortHelpers_FJObject_Sorter { if x == nil { return nil }; v, ok := x.(*ArraysParallelSortHelpers_FJObject_Sorter); if !ok { panic(ClassCast(x, ArraysParallelSortHelpers_FJObject_Sorter_class)) }; return v }



type ArraysParallelSortHelpers_Relay struct{ CountedCompleter; F_task CountedCompleter_I }

const ArraysParallelSortHelpers_Relay_serialVersionUID int64 = 2446542900576103244

var ArraysParallelSortHelpers_Relay_init ClassInit

func ArraysParallelSortHelpers_Relay_Init() { if !ArraysParallelSortHelpers_Relay_init.Done() { ArraysParallelSortHelpers_Relay_init.Run(ArraysParallelSortHelpers_Relay_clinit) } }

func ArraysParallelSortHelpers_Relay_clinit() { CountedCompleter_Init() }

func (t *ArraysParallelSortHelpers_Relay) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) InitPending_I__V(p0 int32) { t.Impl_InitPending_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) FirstComplete__CountedCompleter() CountedCompleter_I { return t.Impl_FirstComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_Relay) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *ArraysParallelSortHelpers_Relay) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *ArraysParallelSortHelpers_Relay) GetCompleter__CountedCompleter() CountedCompleter_I { return t.Impl_GetCompleter__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_Relay) NextComplete__CountedCompleter() CountedCompleter_I { return t.Impl_NextComplete__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_Relay) PropagateCompletion__V() { t.Impl_PropagateCompletion__V(t) }

func (t *ArraysParallelSortHelpers_Relay) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *ArraysParallelSortHelpers_Relay) TryComplete__V() { t.Impl_TryComplete__V(t) }

func (t *ArraysParallelSortHelpers_Relay) Get__O() any { return t.Impl_Get__O(t) }

func (t *ArraysParallelSortHelpers_Relay) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *ArraysParallelSortHelpers_Relay) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) OnAuxExceptionSet_Throwable__V(p0 Throwable_I) { t.Impl_OnAuxExceptionSet_Throwable__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *ArraysParallelSortHelpers_Relay) DecrementPendingCountUnlessZero__I() int32 { return t.Impl_DecrementPendingCountUnlessZero__I(t) }

func (t *ArraysParallelSortHelpers_Relay) QuietlyCompleteRoot__V() { t.Impl_QuietlyCompleteRoot__V(t) }

func (t *ArraysParallelSortHelpers_Relay) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *ArraysParallelSortHelpers_Relay) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *ArraysParallelSortHelpers_Relay) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *ArraysParallelSortHelpers_Relay) HelpComplete_I__V(p0 int32) { t.Impl_HelpComplete_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *ArraysParallelSortHelpers_Relay) WeakCompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_WeakCompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_Relay) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *ArraysParallelSortHelpers_Relay) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *ArraysParallelSortHelpers_Relay) Join__O() any { return t.Impl_Join__O(t) }

func (t *ArraysParallelSortHelpers_Relay) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *ArraysParallelSortHelpers_Relay) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *ArraysParallelSortHelpers_Relay) CompareAndSetPendingCount_I_I__Z(p0, p1 int32) bool { return t.Impl_CompareAndSetPendingCount_I_I__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_Relay) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *ArraysParallelSortHelpers_Relay) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) SetPendingCount_I__V(p0 int32) { t.Impl_SetPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) AddToPendingCount_I__V(p0 int32) { t.Impl_AddToPendingCount_I__V(t, p0) }

func (t *ArraysParallelSortHelpers_Relay) GetPendingCount__I() int32 { return t.Impl_GetPendingCount__I(t) }

func (t *ArraysParallelSortHelpers_Relay) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *ArraysParallelSortHelpers_Relay) OnExceptionalCompletion_Throwable_CountedCompleter__Z(p0 Throwable_I, p1 CountedCompleter_I) bool { return t.Impl_OnExceptionalCompletion_Throwable_CountedCompleter__Z(t, p0, p1) }

func (t *ArraysParallelSortHelpers_Relay) GetRoot__CountedCompleter() CountedCompleter_I { return t.Impl_GetRoot__CountedCompleter(t) }

func (t *ArraysParallelSortHelpers_Relay) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *ArraysParallelSortHelpers_Relay) Ref() any { if t == nil { return nil }; return t }

func (t *ArraysParallelSortHelpers_Relay) GetClass__Class() *Class { return ArraysParallelSortHelpers_Relay_class }

func (t *ArraysParallelSortHelpers_Relay) ToString__String() *String { return Object_toString(t) }

func (t *ArraysParallelSortHelpers_Relay) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArraysParallelSortHelpers_Relay) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArraysParallelSortHelpers_Relay_InstanceOf(x any) bool { _, ok := x.(*ArraysParallelSortHelpers_Relay); return ok }

func ArraysParallelSortHelpers_Relay_Cast(x any) *ArraysParallelSortHelpers_Relay { if x == nil { return nil }; v, ok := x.(*ArraysParallelSortHelpers_Relay); if !ok { panic(ClassCast(x, ArraysParallelSortHelpers_Relay_class)) }; return v }
