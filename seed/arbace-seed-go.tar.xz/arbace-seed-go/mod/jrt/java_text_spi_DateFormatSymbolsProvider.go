//line java_text_spi_DateFormatSymbolsProvider.ae:1
package jrt










func (t *DateFormatSymbolsProvider) Ctor(this DateFormatSymbolsProvider_I) { t.LocaleServiceProvider.Ctor(this) }



type DateFormatSymbolsProvider struct{ LocaleServiceProvider }

type DateFormatSymbolsProvider_I interface{ LocaleServiceProvider_I; Self_DateFormatSymbolsProvider() *DateFormatSymbolsProvider; GetInstance_Locale__DateFormatSymbols(p0 *Locale) *DateFormatSymbols }

func (t *DateFormatSymbolsProvider) Self_DateFormatSymbolsProvider() *DateFormatSymbolsProvider { return t }

func DateFormatSymbolsProvider_InstanceOf(x any) bool { _, ok := x.(DateFormatSymbolsProvider_I); return ok }

func DateFormatSymbolsProvider_Cast(x any) DateFormatSymbolsProvider_I { if x == nil { return nil }; v, ok := x.(DateFormatSymbolsProvider_I); if !ok { panic(ClassCast(x, DateFormatSymbolsProvider_class)) }; return v }
