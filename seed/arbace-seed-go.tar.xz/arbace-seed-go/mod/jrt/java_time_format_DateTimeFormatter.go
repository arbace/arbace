//line java_time_format_DateTimeFormatter.ae:1
package jrt



























func DateTimeFormatter_OfPattern_String__DateTimeFormatter(pattern *String) *DateTimeFormatter { DateTimeFormatter_Init()
	return NN(DateTimeFormatterBuilder_New().AppendPattern_String__DateTimeFormatterBuilder(pattern)).ToFormatter__DateTimeFormatter()
}
func DateTimeFormatter_OfPattern_String_Locale__DateTimeFormatter(pattern *String, locale *Locale) *DateTimeFormatter { DateTimeFormatter_Init()
	return NN(DateTimeFormatterBuilder_New().AppendPattern_String__DateTimeFormatterBuilder(pattern)).ToFormatter_Locale__DateTimeFormatter(locale)
}
func DateTimeFormatter_OfLocalizedDate_FormatStyle__DateTimeFormatter(dateStyle *FormatStyle) *DateTimeFormatter { DateTimeFormatter_Init()
	Objects_RequireNonNull_O_String__O(dateStyle.Ref(), Lit_2231)
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().AppendLocalized_FormatStyle_FormatStyle__DateTimeFormatterBuilder(dateStyle, nil); var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_SMART; var tmp3 *ResolverStyle = tmp2; var tmp4 *IsoChronology; IsoChronology_Init(); tmp4 = IsoChronology_INSTANCE; return NN(tmp1).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp3, Up_IsoChronology_Chronology(tmp4))
}


func DateTimeFormatter_OfLocalizedTime_FormatStyle__DateTimeFormatter(timeStyle *FormatStyle) *DateTimeFormatter { DateTimeFormatter_Init()
	Objects_RequireNonNull_O_String__O(timeStyle.Ref(), Lit_2232)
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().AppendLocalized_FormatStyle_FormatStyle__DateTimeFormatterBuilder(nil, timeStyle); var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_SMART; var tmp3 *ResolverStyle = tmp2; var tmp4 *IsoChronology; IsoChronology_Init(); tmp4 = IsoChronology_INSTANCE; return NN(tmp1).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp3, Up_IsoChronology_Chronology(tmp4))
}


func DateTimeFormatter_OfLocalizedDateTime_FormatStyle__DateTimeFormatter(dateTimeStyle *FormatStyle) *DateTimeFormatter { DateTimeFormatter_Init()
	Objects_RequireNonNull_O_String__O(dateTimeStyle.Ref(), Lit_2233)
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().AppendLocalized_FormatStyle_FormatStyle__DateTimeFormatterBuilder(dateTimeStyle, dateTimeStyle); var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_SMART; var tmp3 *ResolverStyle = tmp2; var tmp4 *IsoChronology; IsoChronology_Init(); tmp4 = IsoChronology_INSTANCE; return NN(tmp1).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp3, Up_IsoChronology_Chronology(tmp4))
}


func DateTimeFormatter_OfLocalizedDateTime_FormatStyle_FormatStyle__DateTimeFormatter(dateStyle, timeStyle *FormatStyle) *DateTimeFormatter { DateTimeFormatter_Init()

	Objects_RequireNonNull_O_String__O(dateStyle.Ref(), Lit_2231)
	Objects_RequireNonNull_O_String__O(timeStyle.Ref(), Lit_2232)
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().AppendLocalized_FormatStyle_FormatStyle__DateTimeFormatterBuilder(dateStyle, timeStyle); var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_SMART; var tmp3 *ResolverStyle = tmp2; var tmp4 *IsoChronology; IsoChronology_Init(); tmp4 = IsoChronology_INSTANCE; return NN(tmp1).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp3, Up_IsoChronology_Chronology(tmp4))
}


func DateTimeFormatter_OfLocalizedPattern_String__DateTimeFormatter(requestedTemplate *String) *DateTimeFormatter { DateTimeFormatter_Init()
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().AppendLocalized_String__DateTimeFormatterBuilder(requestedTemplate); var tmp2 *ResolverStyle; ResolverStyle_Init(); tmp2 = ResolverStyle_SMART; var tmp3 *ResolverStyle = tmp2; var tmp4 *IsoChronology; IsoChronology_Init(); tmp4 = IsoChronology_INSTANCE; return NN(tmp1).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp3, Up_IsoChronology_Chronology(tmp4))
}











































































































































































































































































































func DateTimeFormatter_ParsedExcessDays__TemporalQuery() TemporalQuery { DateTimeFormatter_Init(); return DateTimeFormatter_PARSED_EXCESS_DAYS }






func DateTimeFormatter_ParsedLeapSecond__TemporalQuery() TemporalQuery { DateTimeFormatter_Init(); return DateTimeFormatter_PARSED_LEAP_SECOND }






func DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(p0 *DateTimeFormatterBuilder_CompositePrinterParser, p1 *Locale, p2 *DecimalStyle, p3 *ResolverStyle, p4 Set, p5 Chronology, p6 ZoneId_I) *DateTimeFormatter { DateTimeFormatter_Init(); t := &DateTimeFormatter{}; t.Ctor_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(p0, p1, p2, p3, p4, p5, p6); return t }
//line :377:1
func (t *DateTimeFormatter) Ctor_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(printerParser *DateTimeFormatterBuilder_CompositePrinterParser, locale *Locale, decimalStyle *DecimalStyle, resolverStyle *ResolverStyle, resolverFields Set, chrono Chronology, zone ZoneId_I) {


	t.F_printerParser = DateTimeFormatterBuilder_CompositePrinterParser_Cast(Objects_RequireNonNull_O_String__O(printerParser.Ref(), Lit_2228))


	t.F_resolverFields = resolverFields
	t.F_locale = Locale_Cast(Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_2176))
	t.F_decimalStyle = DecimalStyle_Cast(Objects_RequireNonNull_O_String__O(decimalStyle.Ref(), Lit_2229))

	t.F_resolverStyle = ResolverStyle_Cast(Objects_RequireNonNull_O_String__O(resolverStyle.Ref(), Lit_2230))

	t.F_chrono = chrono
	t.F_zone = zone
}
func (t *DateTimeFormatter) GetLocale__Locale() *Locale { return t.F_locale }

func (t *DateTimeFormatter) WithLocale_Locale__DateTimeFormatter(locale *Locale) *DateTimeFormatter {
	if NN(t.F_locale).Equals_O__Z(locale.Ref()) { return t } else {

		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, locale, t.F_decimalStyle, t.F_resolverStyle, t.F_resolverFields, t.F_chrono, t.F_zone)
	}
}





func (t *DateTimeFormatter) LocalizedBy_Locale__DateTimeFormatter(locale *Locale) *DateTimeFormatter {
	var tzType *String = NN(locale).GetUnicodeLocaleType_String__String(Lit_2234); var z ZoneId_I
	if !(tzType == nil) {
		z = ZoneId_Cast(NN(NN(TimeZoneNameUtility_ConvertLDMLShortID_String__Optional(tzType)).Map_Function__Optional(&Function_Fn{Fn: func(p0 any) any { return ZoneId_Of_String__ZoneId(String_Cast(p0)) }})).OrElse_O__O(t.F_zone)) } else {
//line :407:1
			z = t.F_zone }
//line :406:1
	var c Chronology = Chronology_OfLocale_Locale__Chronology(locale); var ds *DecimalStyle = DecimalStyle_Of_Locale__DecimalStyle(locale); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool








	tmp4 = NN(t.F_locale).Equals_O__Z(locale.Ref()); if tmp4 { tmp4 = c.Equals_O__Z(t.F_chrono) }; tmp3 = tmp4; if tmp3 {
		tmp3 = NN(ds).Equals_O__Z(t.F_decimalStyle.Ref()) }
//line :415:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = Objects_Equals_O_O__Z(z, t.F_zone) }
//line :415:1
	tmp1 = tmp2; if tmp1 { return t } else {



		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, locale, ds, t.F_resolverStyle, t.F_resolverFields, c, z)
	} }
func (t *DateTimeFormatter) GetDecimalStyle__DecimalStyle() *DecimalStyle { return t.F_decimalStyle }

func (t *DateTimeFormatter) WithDecimalStyle_DecimalStyle__DateTimeFormatter(decimalStyle *DecimalStyle) *DateTimeFormatter {
	if NN(t.F_decimalStyle).Equals_O__Z(decimalStyle.Ref()) { return t } else {

		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, t.F_locale, decimalStyle, t.F_resolverStyle, t.F_resolverFields, t.F_chrono, t.F_zone)
	}
}





func (t *DateTimeFormatter) GetChronology__Chronology() Chronology { return t.F_chrono }

func (t *DateTimeFormatter) WithChronology_Chronology__DateTimeFormatter(chrono Chronology) *DateTimeFormatter {
	if Objects_Equals_O_O__Z(t.F_chrono, chrono) { return t } else {

		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, t.F_locale, t.F_decimalStyle, t.F_resolverStyle, t.F_resolverFields, chrono, t.F_zone)
	}
}





func (t *DateTimeFormatter) GetZone__ZoneId() ZoneId_I { return t.F_zone }

func (t *DateTimeFormatter) WithZone_ZoneId__DateTimeFormatter(zone ZoneId_I) *DateTimeFormatter {
	if Objects_Equals_O_O__Z(t.F_zone, zone) { return t } else {

		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, t.F_locale, t.F_decimalStyle, t.F_resolverStyle, t.F_resolverFields, t.F_chrono, zone)
	}
}





func (t *DateTimeFormatter) GetResolverStyle__ResolverStyle() *ResolverStyle { return t.F_resolverStyle }

func (t *DateTimeFormatter) WithResolverStyle_ResolverStyle__DateTimeFormatter(resolverStyle *ResolverStyle) *DateTimeFormatter {
	Objects_RequireNonNull_O_String__O(resolverStyle.Ref(), Lit_2230)
	if Objects_Equals_O_O__Z(t.F_resolverStyle.Ref(), resolverStyle.Ref()) { return t } else {

		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, t.F_locale, t.F_decimalStyle, resolverStyle, t.F_resolverFields, t.F_chrono, t.F_zone)
	}
}





func (t *DateTimeFormatter) GetResolverFields__Set() Set { return t.F_resolverFields }


func (t *DateTimeFormatter) WithResolverFields_TemporalField1__DateTimeFormatter(resolverFields *RefArray) *DateTimeFormatter {
	var fields Set
	if !(resolverFields == nil) {
		fields = Collections_UnmodifiableSet_Set__Set(HashSet_New_Collection(Arrays_AsList_O1__List(resolverFields))) }
	if Objects_Equals_O_O__Z(t.F_resolverFields, fields) { return t } else {

		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, t.F_locale, t.F_decimalStyle, t.F_resolverStyle, fields, t.F_chrono, t.F_zone)
	} }
func (t *DateTimeFormatter) WithResolverFields_Set__DateTimeFormatter(resolverFields Set) *DateTimeFormatter {

	if Objects_Equals_O_O__Z(t.F_resolverFields, resolverFields) { return t } else {


		if !(resolverFields == nil) {
			resolverFields = Collections_UnmodifiableSet_Set__Set(HashSet_New_Collection(resolverFields)) }
		return DateTimeFormatter_New_DateTimeFormatterBuilder_CompositePrinterParser_Locale_DecimalStyle_ResolverStyle_Set_Chronology_ZoneId(t.F_printerParser, t.F_locale, t.F_decimalStyle, t.F_resolverStyle, resolverFields, t.F_chrono, t.F_zone)
	}
}





func (t *DateTimeFormatter) Format_TemporalAccessor__String(temporal TemporalAccessor) *String {
	var buf *StringBuilder = StringBuilder_New_I(32); t.FormatTo_TemporalAccessor_Appendable__V(temporal, Up_StringBuilder_Appendable(buf)); return NN(buf).ToString__String()
}
func (t *DateTimeFormatter) FormatTo_TemporalAccessor_Appendable__V(temporal TemporalAccessor, appendable Appendable) {
	Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
	Objects_RequireNonNull_O_String__O(appendable, Lit_2235); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var context *DateTimePrintContext = DateTimePrintContext_New_TemporalAccessor_DateTimeFormatter(temporal, t)
			if StringBuilder_InstanceOf(appendable) {
				var tmp1 *DateTimeFormatterBuilder_CompositePrinterParser = t.F_printerParser; NN(tmp1).Format_DateTimePrintContext_StringBuilder_Z__Z(context, StringBuilder_Cast(appendable), false) } else {
					var buf *StringBuilder = StringBuilder_New_I(32)
					NN(t.F_printerParser).Format_DateTimePrintContext_StringBuilder_Z__Z(context, buf, false)
					appendable.Append_CharSequence__Appendable(Up_StringBuilder_CharSequence(buf)) } }; return nil }()
//line :506:1
	if tmp2 != nil { if IOException_InstanceOf(tmp2) { var ex IOException_I = IOException_Cast(tmp2)






		panic(Thrown(DateTimeException_New_String_Throwable(ex.GetMessage__String(), ex))) } else {
//line :506:1
			panic(tmp2)
		}
	}
}





func (t *DateTimeFormatter) Parse_CharSequence__TemporalAccessor(text CharSequence) TemporalAccessor {
	Objects_RequireNonNull_O_String__O(text, Lit_2011)
	var tmp1 TemporalAccessor; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = t.ParseResolved0_CharSequence_ParsePosition__TemporalAccessor(text, nil); return nil }()
//line :517:1
	if tmp2 != nil { if DateTimeParseException_InstanceOf(tmp2) { var ex *DateTimeParseException = DateTimeParseException_Cast(tmp2)

		panic(Thrown(Up_DateTimeParseException_Throwable(ex))) } else if /*line :517:1*/ RuntimeException_InstanceOf(tmp2) { var ex_2 RuntimeException_I = RuntimeException_Cast(tmp2)


			panic(Thrown(Up_DateTimeParseException_Throwable(t.CreateError_CharSequence_RuntimeException__DateTimeParseException(text, ex_2)))) } else {
//line :517:1
				panic(tmp2) } }; return tmp1
}



func (t *DateTimeFormatter) Parse_CharSequence_ParsePosition__TemporalAccessor(text CharSequence, position *ParsePosition) TemporalAccessor {
	Objects_RequireNonNull_O_String__O(text, Lit_2011)
	Objects_RequireNonNull_O_String__O(position.Ref(), Lit_2236)
	var tmp1 TemporalAccessor; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = t.ParseResolved0_CharSequence_ParsePosition__TemporalAccessor(text, position); return nil }()
//line :525:1
	if tmp2 != nil { if DateTimeParseException_InstanceOf(tmp2) || IndexOutOfBoundsException_InstanceOf(tmp2) { var ex RuntimeException_I = RuntimeException_Cast(tmp2)

		panic(Thrown(ex)) } else if /*line :525:1*/ RuntimeException_InstanceOf(tmp2) { var ex_2 RuntimeException_I = RuntimeException_Cast(tmp2)


			panic(Thrown(Up_DateTimeParseException_Throwable(t.CreateError_CharSequence_RuntimeException__DateTimeParseException(text, ex_2)))) } else {
//line :525:1
				panic(tmp2) } }; return tmp1
}



func (t *DateTimeFormatter) Parse_CharSequence_TemporalQuery__O(text CharSequence, query TemporalQuery) any {

	Objects_RequireNonNull_O_String__O(text, Lit_2011)
	Objects_RequireNonNull_O_String__O(query, Lit_1398)
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = t.ParseResolved0_CharSequence_ParsePosition__TemporalAccessor(text, nil).Query_TemporalQuery__O(query); return nil }()
//line :534:1
	if tmp2 != nil { if DateTimeParseException_InstanceOf(tmp2) { var ex *DateTimeParseException = DateTimeParseException_Cast(tmp2)

		panic(Thrown(Up_DateTimeParseException_Throwable(ex))) } else if /*line :534:1*/ RuntimeException_InstanceOf(tmp2) { var ex_2 RuntimeException_I = RuntimeException_Cast(tmp2)


			panic(Thrown(Up_DateTimeParseException_Throwable(t.CreateError_CharSequence_RuntimeException__DateTimeParseException(text, ex_2)))) } else {
//line :534:1
				panic(tmp2) } }; return tmp1
}



func (t *DateTimeFormatter) ParseBest_CharSequence_TemporalQuery1__TemporalAccessor(text CharSequence, queries *RefArray) TemporalAccessor {

	Objects_RequireNonNull_O_String__O(text, Lit_2011)
	Objects_RequireNonNull_O_String__O(queries.Ref(), Lit_2237)
	if int32(len(queries.A)) < 2 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2238))) }
	var tmp1 TemporalAccessor; tmp5, tmp6, tmp7 := func() (ctl int32, rv TemporalAccessor, exc Throwable_I) { defer Catch(&exc)
		{ var resolved TemporalAccessor = t.ParseResolved0_CharSequence_ParsePosition__TemporalAccessor(text, nil); var arr_101576 *RefArray = queries; var len_101577 int32 = int32(len(arr_101576.A)); var i_101578 int32 = 0; for ; i_101578 < len_101577; i_101578++ {
			var query TemporalQuery = As[TemporalQuery](arr_101576.A[i_101578]); tmp2, tmp3, tmp4 := func() (ctl int32, rv TemporalAccessor, exc Throwable_I) { defer Catch(&exc); return 2, TemporalAccessor_Cast(resolved.Query_TemporalQuery__O(query)), nil; return 0, nil, nil }()
			if tmp4 != nil { if RuntimeException_InstanceOf(tmp4) { var ex RuntimeException_I = RuntimeException_Cast(tmp4); _ = ex } else { panic(tmp4) } }; switch tmp2 { case 2: { return 2, tmp3, nil }} }
			panic(Thrown(DateTimeException_New_String(Lit_2239))) }; return 0, nil, nil }()
//line :545:1
	if tmp7 != nil { if DateTimeParseException_InstanceOf(tmp7) { var ex_2 *DateTimeParseException = DateTimeParseException_Cast(tmp7)





		panic(Thrown(Up_DateTimeParseException_Throwable(ex_2))) } else if /*line :545:1*/ RuntimeException_InstanceOf(tmp7) { var ex_3 RuntimeException_I = RuntimeException_Cast(tmp7)






			panic(Thrown(Up_DateTimeParseException_Throwable(t.CreateError_CharSequence_RuntimeException__DateTimeParseException(text, ex_3)))) } else {
//line :545:1
				panic(tmp7) } }; switch tmp5 { case 2: { return tmp6 }}; return tmp1
}







func (t *DateTimeFormatter) CreateError_CharSequence_RuntimeException__DateTimeParseException(text CharSequence, ex RuntimeException_I) *DateTimeParseException {

	var abbr *String; if text.Length__I() > 64 {
		abbr = Concat(text.SubSequence_I_I__CharSequence(0, 64).ToString__String(), Lit_2240) } else {
			abbr = text.ToString__String() }
	return DateTimeParseException_New_String_CharSequence_I_Throwable(Concat(Lit_2241, abbr, Lit_2242, ex.GetMessage__String()), text, 0, ex)
}



func (t *DateTimeFormatter) ParseResolved0_CharSequence_ParsePosition__TemporalAccessor(text CharSequence, position *ParsePosition) TemporalAccessor {

	var pos *ParsePosition; if !(position == nil) { pos = position } else { pos = ParsePosition_New_I(0) }; var context *DateTimeParseContext = t.ParseUnresolved0_CharSequence_ParsePosition__DateTimeParseContext(text, pos); var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = context == nil; if !tmp3 { tmp3 = NN(pos).GetErrorIndex__I() >= 0 }; tmp2 = tmp3; if !tmp2 {
		var tmp4 bool; tmp4 = position == nil; if tmp4 { tmp4 = NN(pos).GetIndex__I() < text.Length__I() }; tmp2 = tmp4 }
//line :568:1
	tmp1 = tmp2; if tmp1 {

		var abbr *String; if text.Length__I() > 64 {
			abbr = Concat(text.SubSequence_I_I__CharSequence(0, 64).ToString__String(), Lit_2240) } else {
				abbr = text.ToString__String() }
		if NN(pos).GetErrorIndex__I() >= 0 {
			panic(Thrown(DateTimeParseException_New_String_CharSequence_I(Concat(Lit_2241, abbr, Lit_2243, StrOfInt(NN(pos).GetErrorIndex__I())), text, NN(pos).GetErrorIndex__I()))) } else {






				panic(Thrown(DateTimeParseException_New_String_CharSequence_I(Concat(Lit_2241, abbr, Lit_2244, StrOfInt(NN(pos).GetIndex__I())), text, NN(pos).GetIndex__I())))
			}
	}




	return NN(context).ToResolved_ResolverStyle_Set__TemporalAccessor(t.F_resolverStyle, t.F_resolverFields)
}
func (t *DateTimeFormatter) ParseUnresolved_CharSequence_ParsePosition__TemporalAccessor(text CharSequence, position *ParsePosition) TemporalAccessor {

	var context *DateTimeParseContext = t.ParseUnresolved0_CharSequence_ParsePosition__DateTimeParseContext(text, position)
	if !(context == nil) { return Up_Parsed_TemporalAccessor(NN(context).ToUnresolved__Parsed()) } else { return nil
	} }
func (t *DateTimeFormatter) ParseUnresolved0_CharSequence_ParsePosition__DateTimeParseContext(text CharSequence, position *ParsePosition) *DateTimeParseContext {

	Objects_RequireNonNull_O_String__O(text, Lit_2011)
	Objects_RequireNonNull_O_String__O(position.Ref(), Lit_2236)
	var context *DateTimeParseContext = DateTimeParseContext_New_DateTimeFormatter(t); var pos int32 = NN(position).GetIndex__I()

	pos = NN(t.F_printerParser).Parse_DateTimeParseContext_CharSequence_I__I(context, text, pos)
	if pos < 0 {
		NN(position).SetErrorIndex_I__V(^pos); return nil } else {
			NN(position).SetIndex_I__V(pos); return context
		} }
func (t *DateTimeFormatter) ToPrinterParser_Z__DateTimeFormatterBuilder_CompositePrinterParser(optional bool) *DateTimeFormatterBuilder_CompositePrinterParser {
	return NN(t.F_printerParser).WithOptional_Z__DateTimeFormatterBuilder_CompositePrinterParser(optional)
}
func (t *DateTimeFormatter) ToFormat__Format() Format_I { return DateTimeFormatter_ClassicFormat_New_DateTimeFormatter_TemporalQuery(t, nil) }

func (t *DateTimeFormatter) ToFormat_TemporalQuery__Format(parseQuery TemporalQuery) Format_I {
	Objects_RequireNonNull_O_String__O(parseQuery, Lit_2245)
	return DateTimeFormatter_ClassicFormat_New_DateTimeFormatter_TemporalQuery(t, parseQuery)
}
func (t *DateTimeFormatter) ToString__String() *String {
	var pattern *String = NN(t.F_printerParser).ToString__String(); var tmp1 *String

	if NN(pattern).StartsWith_String__Z(Lit_1318) { tmp1 = pattern } else {

		tmp1 = NN(pattern).Substring_I_I__String(1, NN(pattern).Length__I()-1) }
//line :617:1
	pattern = tmp1
//line :616:1
	return pattern
}












func DateTimeFormatter_ClassicFormat_New_DateTimeFormatter_TemporalQuery(p0 *DateTimeFormatter, p1 TemporalQuery) *DateTimeFormatter_ClassicFormat { t := &DateTimeFormatter_ClassicFormat{}; t.Ctor_DateTimeFormatter_TemporalQuery(p0, p1); return t }
//line :630:1
func (t *DateTimeFormatter_ClassicFormat) Ctor_DateTimeFormatter_TemporalQuery(formatter *DateTimeFormatter, parseType TemporalQuery) { t.Format.Ctor(t)
	t.F_formatter = formatter
	t.F_parseType = parseType
}
func (t *DateTimeFormatter_ClassicFormat) Format_O_StringBuffer_FieldPosition__StringBuffer(obj any, toAppendTo *StringBuffer, pos FieldPosition_I) *StringBuffer {
	Objects_RequireNonNull_O_String__O(obj, Lit_2246)
	Objects_RequireNonNull_O_String__O(toAppendTo.Ref(), Lit_2247)
	Objects_RequireNonNull_O_String__O(pos, Lit_2248)
	if TemporalAccessor_InstanceOf(obj) { } else {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2249))) }
	pos.SetBeginIndex_I__V(0)
	pos.SetEndIndex_I__V(0); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var tmp1 *DateTimeFormatter = t.F_formatter; NN(tmp1).FormatTo_TemporalAccessor_Appendable__V(TemporalAccessor_Cast(obj), Up_StringBuffer_Appendable(toAppendTo)) }; return nil }()
//line :642:1
	if tmp2 != nil { if RuntimeException_InstanceOf(tmp2) { var ex RuntimeException_I = RuntimeException_Cast(tmp2)

		panic(Thrown(IllegalArgumentException_New_String_Throwable(ex.GetMessage__String(), ex))) } else {
//line :642:1
			panic(tmp2) } }
//line :634:1
	return toAppendTo
}











func (t *DateTimeFormatter_ClassicFormat) ParseObject_String__O(text *String) any {
	Objects_RequireNonNull_O_String__O(text.Ref(), Lit_2011)
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		if t.F_parseType == nil { tmp1 = NN(t.F_formatter).ParseResolved0_CharSequence_ParsePosition__TemporalAccessor(Up_String_CharSequence(text), nil) } else { tmp1 = NN(t.F_formatter).Parse_CharSequence_TemporalQuery__O(Up_String_CharSequence(text), t.F_parseType) }; return nil }()
//line :649:1
	if tmp2 != nil { if DateTimeParseException_InstanceOf(tmp2) { var ex *DateTimeParseException = DateTimeParseException_Cast(tmp2)


		panic(Thrown(ParseException_New_String_I(NN(ex).GetMessage__String(), NN(ex).GetErrorIndex__I()))) } else if /*line :649:1*/ RuntimeException_InstanceOf(tmp2) { var ex_2 RuntimeException_I = RuntimeException_Cast(tmp2)




			panic(Thrown(Up_ParseException_Throwable(ParseException_Cast(ParseException_New_String_I(ex_2.GetMessage__String(), 0).InitCause_Throwable__Throwable(ex_2))))) } else {
//line :649:1
				panic(tmp2) } }; return tmp1
}





func (t *DateTimeFormatter_ClassicFormat) ParseObject_String_ParsePosition__O(text *String, pos *ParsePosition) any {
	Objects_RequireNonNull_O_String__O(text.Ref(), Lit_2011)
	var context *DateTimeParseContext; var tmp1 any; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

		context = NN(t.F_formatter).ParseUnresolved0_CharSequence_ParsePosition__DateTimeParseContext(Up_String_CharSequence(text), pos)
		if context == nil {
			if NN(pos).GetErrorIndex__I() < 0 { NN(pos).SetErrorIndex_I__V(0) }; tmp1 = nil } else {
				var tmp2 *DateTimeParseContext = context; var tmp3 *ResolverStyle = t.F_formatter.F_resolverStyle; var resolved TemporalAccessor = NN(tmp2).ToResolved_ResolverStyle_Set__TemporalAccessor(tmp3, t.F_formatter.F_resolverFields)


				if t.F_parseType == nil { tmp1 = resolved } else { tmp1 = resolved.Query_TemporalQuery__O(t.F_parseType) } }; return nil }()
//line :659:1
	if tmp4 != nil { if RuntimeException_InstanceOf(tmp4) { var ex RuntimeException_I = RuntimeException_Cast(tmp4); _ = ex







		if NN(pos).GetErrorIndex__I() < 0 { NN(pos).SetErrorIndex_I__V(0) }
//line :659:1
		tmp1 = nil } else { panic(tmp4) } }; return tmp1
}









type DateTimeFormatter struct{ Object; F_printerParser *DateTimeFormatterBuilder_CompositePrinterParser; F_locale *Locale; F_decimalStyle *DecimalStyle; F_resolverStyle *ResolverStyle; F_resolverFields Set; F_chrono Chronology; F_zone ZoneId_I }

var DateTimeFormatter_ISO_LOCAL_DATE *DateTimeFormatter

var DateTimeFormatter_ISO_OFFSET_DATE *DateTimeFormatter

var DateTimeFormatter_ISO_DATE *DateTimeFormatter

var DateTimeFormatter_ISO_LOCAL_TIME *DateTimeFormatter

var DateTimeFormatter_ISO_OFFSET_TIME *DateTimeFormatter

var DateTimeFormatter_ISO_TIME *DateTimeFormatter

var DateTimeFormatter_ISO_LOCAL_DATE_TIME *DateTimeFormatter

var DateTimeFormatter_ISO_OFFSET_DATE_TIME *DateTimeFormatter

var DateTimeFormatter_ISO_ZONED_DATE_TIME *DateTimeFormatter

var DateTimeFormatter_ISO_DATE_TIME *DateTimeFormatter

var DateTimeFormatter_ISO_ORDINAL_DATE *DateTimeFormatter

var DateTimeFormatter_ISO_WEEK_DATE *DateTimeFormatter

var DateTimeFormatter_ISO_INSTANT *DateTimeFormatter

var DateTimeFormatter_BASIC_ISO_DATE *DateTimeFormatter

var DateTimeFormatter_RFC_1123_DATE_TIME *DateTimeFormatter

var DateTimeFormatter_PARSED_EXCESS_DAYS TemporalQuery

var DateTimeFormatter_PARSED_LEAP_SECOND TemporalQuery

var DateTimeFormatter_init ClassInit

func DateTimeFormatter_Init() { if !DateTimeFormatter_init.Done() { DateTimeFormatter_init.Run(DateTimeFormatter_clinit) } }

func DateTimeFormatter_clinit() {
//line :69:1
	var tmp1 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_YEAR; var tmp3 TemporalField = Up_ChronoField_TemporalField(tmp2); var tmp4 *SignStyle; SignStyle_Init(); tmp4 = SignStyle_EXCEEDS_PAD; var tmp5 *DateTimeFormatterBuilder = NN(tmp1.AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(tmp3, 4, 10, tmp4)).AppendLiteral_C__DateTimeFormatterBuilder(45); var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_MONTH_OF_YEAR; var tmp7 *DateTimeFormatterBuilder = NN(NN(tmp5).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp6), 2)).AppendLiteral_C__DateTimeFormatterBuilder(45); var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_DAY_OF_MONTH; var tmp9 *DateTimeFormatterBuilder = NN(tmp7).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp8), 2); var tmp10 *ResolverStyle; ResolverStyle_Init(); tmp10 = ResolverStyle_STRICT; var tmp11 *ResolverStyle = tmp10; var tmp12 *IsoChronology; IsoChronology_Init(); tmp12 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_LOCAL_DATE = NN(tmp9).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp11, Up_IsoChronology_Chronology(tmp12))





















	var tmp13 *DateTimeFormatterBuilder = NN(NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_DATE)).AppendOffsetId__DateTimeFormatterBuilder(); var tmp14 *ResolverStyle; ResolverStyle_Init(); tmp14 = ResolverStyle_STRICT; var tmp15 *ResolverStyle = tmp14; var tmp16 *IsoChronology; IsoChronology_Init(); tmp16 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_OFFSET_DATE = NN(tmp13).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp15, Up_IsoChronology_Chronology(tmp16))









	var tmp17 *DateTimeFormatterBuilder = NN(NN(NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_DATE)).OptionalStart__DateTimeFormatterBuilder()).AppendOffsetId__DateTimeFormatterBuilder(); var tmp18 *ResolverStyle; ResolverStyle_Init(); tmp18 = ResolverStyle_STRICT; var tmp19 *ResolverStyle = tmp18; var tmp20 *IsoChronology; IsoChronology_Init(); tmp20 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_DATE = NN(tmp17).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp19, Up_IsoChronology_Chronology(tmp20))










	var tmp21 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New(); var tmp22 *ChronoField; ChronoField_Init(); tmp22 = ChronoField_HOUR_OF_DAY; var tmp23 *DateTimeFormatterBuilder = NN(tmp21.AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp22), 2)).AppendLiteral_C__DateTimeFormatterBuilder(58); var tmp24 *ChronoField; ChronoField_Init(); tmp24 = ChronoField_MINUTE_OF_HOUR; var tmp25 *DateTimeFormatterBuilder = NN(NN(NN(tmp23).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp24), 2)).OptionalStart__DateTimeFormatterBuilder()).AppendLiteral_C__DateTimeFormatterBuilder(58); var tmp26 *ChronoField; ChronoField_Init(); tmp26 = ChronoField_SECOND_OF_MINUTE; var tmp27 *DateTimeFormatterBuilder = NN(NN(tmp25).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp26), 2)).OptionalStart__DateTimeFormatterBuilder(); var tmp28 *ChronoField; ChronoField_Init(); tmp28 = ChronoField_NANO_OF_SECOND; var tmp29 *DateTimeFormatterBuilder = NN(tmp27).AppendFraction_TemporalField_I_I_Z__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp28), 0, 9, true); var tmp30 *ResolverStyle; ResolverStyle_Init(); tmp30 = ResolverStyle_STRICT; DateTimeFormatter_ISO_LOCAL_TIME = NN(tmp29).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp30, nil)


























	var tmp31 *DateTimeFormatterBuilder = NN(NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_TIME)).AppendOffsetId__DateTimeFormatterBuilder(); var tmp32 *ResolverStyle; ResolverStyle_Init(); tmp32 = ResolverStyle_STRICT; DateTimeFormatter_ISO_OFFSET_TIME = NN(tmp31).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp32, nil)









	var tmp33 *DateTimeFormatterBuilder = NN(NN(NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_TIME)).OptionalStart__DateTimeFormatterBuilder()).AppendOffsetId__DateTimeFormatterBuilder(); var tmp34 *ResolverStyle; ResolverStyle_Init(); tmp34 = ResolverStyle_STRICT; DateTimeFormatter_ISO_TIME = NN(tmp33).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp34, nil)










	var tmp35 *DateTimeFormatterBuilder = NN(NN(NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_DATE)).AppendLiteral_C__DateTimeFormatterBuilder(84)).Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_TIME); var tmp36 *ResolverStyle; ResolverStyle_Init(); tmp36 = ResolverStyle_STRICT; var tmp37 *ResolverStyle = tmp36; var tmp38 *IsoChronology; IsoChronology_Init(); tmp38 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_LOCAL_DATE_TIME = NN(tmp35).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp37, Up_IsoChronology_Chronology(tmp38))











	var tmp39 *DateTimeFormatterBuilder = NN(NN(NN(NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_DATE_TIME)).ParseLenient__DateTimeFormatterBuilder()).AppendOffsetId__DateTimeFormatterBuilder()).ParseStrict__DateTimeFormatterBuilder(); var tmp40 *ResolverStyle; ResolverStyle_Init(); tmp40 = ResolverStyle_STRICT; var tmp41 *ResolverStyle = tmp40; var tmp42 *IsoChronology; IsoChronology_Init(); tmp42 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_OFFSET_DATE_TIME = NN(tmp39).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp41, Up_IsoChronology_Chronology(tmp42))











	var tmp43 *DateTimeFormatterBuilder = NN(NN(NN(NN(NN(DateTimeFormatterBuilder_New().Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_OFFSET_DATE_TIME)).OptionalStart__DateTimeFormatterBuilder()).AppendLiteral_C__DateTimeFormatterBuilder(91)).ParseCaseSensitive__DateTimeFormatterBuilder()).AppendZoneRegionId__DateTimeFormatterBuilder()).AppendLiteral_C__DateTimeFormatterBuilder(93); var tmp44 *ResolverStyle; ResolverStyle_Init(); tmp44 = ResolverStyle_STRICT; var tmp45 *ResolverStyle = tmp44; var tmp46 *IsoChronology; IsoChronology_Init(); tmp46 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_ZONED_DATE_TIME = NN(tmp43).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp45, Up_IsoChronology_Chronology(tmp46))














	var tmp47 *DateTimeFormatterBuilder = NN(NN(NN(NN(NN(NN(NN(DateTimeFormatterBuilder_New().Append_DateTimeFormatter__DateTimeFormatterBuilder(DateTimeFormatter_ISO_LOCAL_DATE_TIME)).OptionalStart__DateTimeFormatterBuilder()).AppendOffsetId__DateTimeFormatterBuilder()).OptionalStart__DateTimeFormatterBuilder()).AppendLiteral_C__DateTimeFormatterBuilder(91)).ParseCaseSensitive__DateTimeFormatterBuilder()).AppendZoneRegionId__DateTimeFormatterBuilder()).AppendLiteral_C__DateTimeFormatterBuilder(93); var tmp48 *ResolverStyle; ResolverStyle_Init(); tmp48 = ResolverStyle_STRICT; var tmp49 *ResolverStyle = tmp48; var tmp50 *IsoChronology; IsoChronology_Init(); tmp50 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_DATE_TIME = NN(tmp47).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp49, Up_IsoChronology_Chronology(tmp50))
















	var tmp51 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder(); var tmp52 *ChronoField; ChronoField_Init(); tmp52 = ChronoField_YEAR; var tmp53 TemporalField = Up_ChronoField_TemporalField(tmp52); var tmp54 *SignStyle; SignStyle_Init(); tmp54 = SignStyle_EXCEEDS_PAD; var tmp55 *DateTimeFormatterBuilder = NN(NN(tmp51).AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(tmp53, 4, 10, tmp54)).AppendLiteral_C__DateTimeFormatterBuilder(45); var tmp56 *ChronoField; ChronoField_Init(); tmp56 = ChronoField_DAY_OF_YEAR; var tmp57 *DateTimeFormatterBuilder = NN(NN(NN(tmp55).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp56), 3)).OptionalStart__DateTimeFormatterBuilder()).AppendOffsetId__DateTimeFormatterBuilder(); var tmp58 *ResolverStyle; ResolverStyle_Init(); tmp58 = ResolverStyle_STRICT; var tmp59 *ResolverStyle = tmp58; var tmp60 *IsoChronology; IsoChronology_Init(); tmp60 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_ORDINAL_DATE = NN(tmp57).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp59, Up_IsoChronology_Chronology(tmp60))


















	var tmp61 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder(); var tmp62 TemporalField; IsoFields_Init(); tmp62 = IsoFields_WEEK_BASED_YEAR; var tmp63 TemporalField = tmp62; var tmp64 *SignStyle; SignStyle_Init(); tmp64 = SignStyle_EXCEEDS_PAD; var tmp65 *DateTimeFormatterBuilder = NN(NN(tmp61).AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(tmp63, 4, 10, tmp64)).AppendLiteral_String__DateTimeFormatterBuilder(Lit_2206); var tmp66 TemporalField; IsoFields_Init(); tmp66 = IsoFields_WEEK_OF_WEEK_BASED_YEAR; var tmp67 *DateTimeFormatterBuilder = NN(NN(tmp65).AppendValue_TemporalField_I__DateTimeFormatterBuilder(tmp66, 2)).AppendLiteral_C__DateTimeFormatterBuilder(45); var tmp68 *ChronoField; ChronoField_Init(); tmp68 = ChronoField_DAY_OF_WEEK; var tmp69 *DateTimeFormatterBuilder = NN(NN(NN(tmp67).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp68), 1)).OptionalStart__DateTimeFormatterBuilder()).AppendOffsetId__DateTimeFormatterBuilder(); var tmp70 *ResolverStyle; ResolverStyle_Init(); tmp70 = ResolverStyle_STRICT; var tmp71 *ResolverStyle = tmp70; var tmp72 *IsoChronology; IsoChronology_Init(); tmp72 = IsoChronology_INSTANCE; DateTimeFormatter_ISO_WEEK_DATE = NN(tmp69).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp71, Up_IsoChronology_Chronology(tmp72))
























	var tmp73 *DateTimeFormatterBuilder = NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).AppendInstant__DateTimeFormatterBuilder(); var tmp74 *ResolverStyle; ResolverStyle_Init(); tmp74 = ResolverStyle_STRICT; DateTimeFormatter_ISO_INSTANT = NN(tmp73).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp74, nil)







	var tmp75 *DateTimeFormatterBuilder = DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder(); var tmp76 *ChronoField; ChronoField_Init(); tmp76 = ChronoField_YEAR; var tmp77 *DateTimeFormatterBuilder = NN(tmp75).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp76), 4); var tmp78 *ChronoField; ChronoField_Init(); tmp78 = ChronoField_MONTH_OF_YEAR; var tmp79 *DateTimeFormatterBuilder = NN(tmp77).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp78), 2); var tmp80 *ChronoField; ChronoField_Init(); tmp80 = ChronoField_DAY_OF_MONTH; var tmp81 *DateTimeFormatterBuilder = NN(NN(NN(NN(NN(tmp79).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp80), 2)).OptionalStart__DateTimeFormatterBuilder()).ParseLenient__DateTimeFormatterBuilder()).AppendOffset_String_String__DateTimeFormatterBuilder(Lit_2207, Lit_2165)).ParseStrict__DateTimeFormatterBuilder(); var tmp82 *ResolverStyle; ResolverStyle_Init(); tmp82 = ResolverStyle_STRICT; var tmp83 *ResolverStyle = tmp82; var tmp84 *IsoChronology; IsoChronology_Init(); tmp84 = IsoChronology_INSTANCE; DateTimeFormatter_BASIC_ISO_DATE = NN(tmp81).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp83, Up_IsoChronology_Chronology(tmp84))






















	var dow Map = HashMap_New()
	dow.Put_O_O__O(Long_ValueOf_J__Long(1), Lit_2208)
	dow.Put_O_O__O(Long_ValueOf_J__Long(2), Lit_2209)
	dow.Put_O_O__O(Long_ValueOf_J__Long(3), Lit_2210)
	dow.Put_O_O__O(Long_ValueOf_J__Long(4), Lit_2211)
	dow.Put_O_O__O(Long_ValueOf_J__Long(5), Lit_2212)
	dow.Put_O_O__O(Long_ValueOf_J__Long(6), Lit_2213)
	dow.Put_O_O__O(Long_ValueOf_J__Long(7), Lit_2214)
	var moy Map = HashMap_New()
	moy.Put_O_O__O(Long_ValueOf_J__Long(1), Lit_2215)
	moy.Put_O_O__O(Long_ValueOf_J__Long(2), Lit_2216)
	moy.Put_O_O__O(Long_ValueOf_J__Long(3), Lit_2217)
	moy.Put_O_O__O(Long_ValueOf_J__Long(4), Lit_2218)
	moy.Put_O_O__O(Long_ValueOf_J__Long(5), Lit_2219)
	moy.Put_O_O__O(Long_ValueOf_J__Long(6), Lit_2220)
	moy.Put_O_O__O(Long_ValueOf_J__Long(7), Lit_2221)
	moy.Put_O_O__O(Long_ValueOf_J__Long(8), Lit_2222)
	moy.Put_O_O__O(Long_ValueOf_J__Long(9), Lit_2223)
	moy.Put_O_O__O(Long_ValueOf_J__Long(10), Lit_2224)
	moy.Put_O_O__O(Long_ValueOf_J__Long(11), Lit_2225)
	moy.Put_O_O__O(Long_ValueOf_J__Long(12), Lit_2226)
	var tmp85 *DateTimeFormatterBuilder = NN(NN(DateTimeFormatterBuilder_New().ParseCaseInsensitive__DateTimeFormatterBuilder()).ParseLenient__DateTimeFormatterBuilder()).OptionalStart__DateTimeFormatterBuilder(); var tmp86 *ChronoField; ChronoField_Init(); tmp86 = ChronoField_DAY_OF_WEEK; var tmp87 *DateTimeFormatterBuilder = NN(NN(NN(tmp85).AppendText_TemporalField_Map__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp86), dow)).AppendLiteral_String__DateTimeFormatterBuilder(Lit_1178)).OptionalEnd__DateTimeFormatterBuilder(); var tmp88 *ChronoField; ChronoField_Init(); tmp88 = ChronoField_DAY_OF_MONTH; var tmp89 TemporalField = Up_ChronoField_TemporalField(tmp88); var tmp90 *SignStyle; SignStyle_Init(); tmp90 = SignStyle_NOT_NEGATIVE; var tmp91 *DateTimeFormatterBuilder = NN(NN(tmp87).AppendValue_TemporalField_I_I_SignStyle__DateTimeFormatterBuilder(tmp89, 1, 2, tmp90)).AppendLiteral_C__DateTimeFormatterBuilder(32); var tmp92 *ChronoField; ChronoField_Init(); tmp92 = ChronoField_MONTH_OF_YEAR; var tmp93 *DateTimeFormatterBuilder = NN(NN(tmp91).AppendText_TemporalField_Map__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp92), moy)).AppendLiteral_C__DateTimeFormatterBuilder(32); var tmp94 *ChronoField; ChronoField_Init(); tmp94 = ChronoField_YEAR; var tmp95 *DateTimeFormatterBuilder = NN(NN(tmp93).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp94), 4)).AppendLiteral_C__DateTimeFormatterBuilder(32); var tmp96 *ChronoField; ChronoField_Init(); tmp96 = ChronoField_HOUR_OF_DAY; var tmp97 *DateTimeFormatterBuilder = NN(NN(tmp95).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp96), 2)).AppendLiteral_C__DateTimeFormatterBuilder(58); var tmp98 *ChronoField; ChronoField_Init(); tmp98 = ChronoField_MINUTE_OF_HOUR; var tmp99 *DateTimeFormatterBuilder = NN(NN(NN(tmp97).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp98), 2)).OptionalStart__DateTimeFormatterBuilder()).AppendLiteral_C__DateTimeFormatterBuilder(58); var tmp100 *ChronoField; ChronoField_Init(); tmp100 = ChronoField_SECOND_OF_MINUTE; var tmp101 *DateTimeFormatterBuilder = NN(NN(NN(NN(tmp99).AppendValue_TemporalField_I__DateTimeFormatterBuilder(Up_ChronoField_TemporalField(tmp100), 2)).OptionalEnd__DateTimeFormatterBuilder()).AppendLiteral_C__DateTimeFormatterBuilder(32)).AppendOffset_String_String__DateTimeFormatterBuilder(Lit_2227, Lit_1972); var tmp102 *ResolverStyle; ResolverStyle_Init(); tmp102 = ResolverStyle_SMART; var tmp103 *ResolverStyle = tmp102; var tmp104 *IsoChronology; IsoChronology_Init(); tmp104 = IsoChronology_INSTANCE; DateTimeFormatter_RFC_1123_DATE_TIME = NN(tmp101).ToFormatter_ResolverStyle_Chronology__DateTimeFormatter(tmp103, Up_IsoChronology_Chronology(tmp104)); DateTimeFormatter_PARSED_EXCESS_DAYS = &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { var t_ TemporalAccessor = p0; var tmp105 *Period; if























































		Parsed_InstanceOf(t_) { tmp105 = Parsed_Cast(t_).F_excessDays } else { Period_Init(); tmp105 = Period_ZERO }; return /*line :312:1*/ tmp105.Ref() }}; DateTimeFormatter_PARSED_LEAP_SECOND = &TemporalQuery_Fn{Fn: func(p0_2 TemporalAccessor) any { var t__2 TemporalAccessor = p0_2; var tmp106 *Boolean; if






























































			Parsed_InstanceOf(t__2) { tmp106 = Boolean_ValueOf_Z__Boolean(Parsed_Cast(t__2).F_leapSecond) } else { Boolean_Init(); tmp106 = Boolean_FALSE }; return /*line :312:1*/ tmp106.Ref() }}
}














































































































































































































































































































































































































func (t *DateTimeFormatter) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatter) GetClass__Class() *Class { return DateTimeFormatter_class }

func (t *DateTimeFormatter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeFormatter) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeFormatter_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatter); return ok }

func DateTimeFormatter_Cast(x any) *DateTimeFormatter { if x == nil { return nil }; v, ok := x.(*DateTimeFormatter); if !ok { panic(ClassCast(x, DateTimeFormatter_class)) }; return v }



type DateTimeFormatter_ClassicFormat struct{ Format; F_formatter *DateTimeFormatter; F_parseType TemporalQuery }

func (t *DateTimeFormatter_ClassicFormat) Format_O__String(p0 any) *String { return t.Impl_Format_O__String(t, p0) }

func (t *DateTimeFormatter_ClassicFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(t, p0) }

func (t *DateTimeFormatter_ClassicFormat) Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(p0 any, p1 Format_StringBuf, p2 FieldPosition_I) Format_StringBuf { return t.Impl_Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(t, p0, p1, p2) }

func (t *DateTimeFormatter_ClassicFormat) CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *DateTimeFormatter_ClassicFormat) CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(t, p0) }

func (t *DateTimeFormatter_ClassicFormat) FormatToCharacterIterator_O__AttributedCharacterIterator(p0 any) AttributedCharacterIterator { return t.Impl_FormatToCharacterIterator_O__AttributedCharacterIterator(t, p0) }

func (t *DateTimeFormatter_ClassicFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *DateTimeFormatter_ClassicFormat) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *DateTimeFormatter_ClassicFormat) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeFormatter_ClassicFormat) GetClass__Class() *Class { return DateTimeFormatter_ClassicFormat_class }

func (t *DateTimeFormatter_ClassicFormat) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeFormatter_ClassicFormat) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func DateTimeFormatter_ClassicFormat_InstanceOf(x any) bool { _, ok := x.(*DateTimeFormatter_ClassicFormat); return ok }

func DateTimeFormatter_ClassicFormat_Cast(x any) *DateTimeFormatter_ClassicFormat { if x == nil { return nil }; v, ok := x.(*DateTimeFormatter_ClassicFormat); if !ok { panic(ClassCast(x, DateTimeFormatter_ClassicFormat_class)) }; return v }
