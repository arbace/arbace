//line java_text_RBCollationTables.ae:1
package jrt







func RBCollationTables_New_String_I(p0 *String, p1 int32) *RBCollationTables { t := &RBCollationTables{}; t.Ctor_String_I(p0, p1); return t }
//line :9:1
func (t *RBCollationTables) Ctor_String_I(rules *String, decmp int32) { t.F_rules = nil; t.F_frenchSec = false; t.F_seAsianSwapping = false; t.F_mapping = nil; t.F_contractTable = nil; t.F_expandTable = nil; t.F_contractFlags = nil; t.F_maxSecOrder = 0; t.F_maxTerOrder = 0
	t.F_rules = rules
	var builder *RBTableBuilder = RBTableBuilder_New_RBCollationTables_BuildAPI(RBCollationTables_BuildAPI_New_RBCollationTables(t)); NN(builder).Build_String_I__V(rules, decmp)
}

func RBCollationTables_BuildAPI_New_RBCollationTables(p0 *RBCollationTables) *RBCollationTables_BuildAPI { t := &RBCollationTables_BuildAPI{}; t.Ctor_RBCollationTables(p0); return t }
//line :14:1
func (t *RBCollationTables_BuildAPI) Ctor_RBCollationTables(this_0 *RBCollationTables) { NN(this_0); t.F_this_0 = this_0 }

func (t *RBCollationTables_BuildAPI) FillInTables_Z_Z_UCompactIntArray_Vector_Vector_IntHashtable_S_S__V(f2ary, swap bool, map_ *UCompactIntArray, cTbl, eTbl Vector_I, cFlgs *IntHashtable, mso, mto int16) {


	t.F_this_0.F_frenchSec = f2ary
	t.F_this_0.F_seAsianSwapping = swap
	t.F_this_0.F_mapping = map_
	t.F_this_0.F_contractTable = cTbl
	t.F_this_0.F_expandTable = eTbl
	t.F_this_0.F_contractFlags = cFlgs
	t.F_this_0.F_maxSecOrder = mso
	t.F_this_0.F_maxTerOrder = mto
}
func (t *RBCollationTables) GetRules__String() *String { return t.F_rules }

func (t *RBCollationTables) IsFrenchSec__Z() bool { return t.F_frenchSec }

func (t *RBCollationTables) IsSEAsianSwapping__Z() bool { return t.F_seAsianSwapping }

func (t *RBCollationTables) GetContractValues_I__Vector(ch int32) Vector_I {
	var index int32 = NN(t.F_mapping).ElementAt_I__I(ch)
	return t.GetContractValuesImpl_I__Vector(index - 2130706432)
}
func (t *RBCollationTables) GetContractValuesImpl_I__Vector(index int32) Vector_I {
	if index >= 0 { return Vector_Cast(t.F_contractTable.ElementAt_I__O(index)) } else { return nil
	} }
func (t *RBCollationTables) UsedInContractSeq_I__Z(c int32) bool {
	return NN(t.F_contractFlags).Get_I__I(c) == 1
}
func (t *RBCollationTables) GetMaxExpansion_I__I(order int32) int32 {
	var result int32 = 1
	if !(t.F_expandTable == nil) {
		var i int32 = 0; L1: for {
			if i < t.F_expandTable.Size__I() {
				var valueList *IntArray = A2g_CastArray[*IntArray](t.F_expandTable.ElementAt_I__O(i), Prim_int.ArrayClass()); var length int32 = int32(len(valueList.A)); var tmp1 bool; var tmp2 bool

				tmp2 = length > result; if tmp2 {
					tmp2 = valueList.A[length-1] == order }
//line :51:1
				tmp1 = tmp2; if tmp1 {

					result = length; i = i + 1; continue L1 } else {
						i = i + 1; continue L1 } }
//line :47:1
			break L1 } }
//line :45:1
	return result
}










func (t *RBCollationTables) GetExpandValueList_I__I1(idx int32) *IntArray {
	return A2g_CastArray[*IntArray](t.F_expandTable.ElementAt_I__O(idx-2113929216), Prim_int.ArrayClass())
}
func (t *RBCollationTables) GetUnicodeOrder_I__I(ch int32) int32 { return NN(t.F_mapping).ElementAt_I__I(ch) }

func (t *RBCollationTables) GetMaxSecOrder__S() int16 { return t.F_maxSecOrder }

func (t *RBCollationTables) GetMaxTerOrder__S() int16 { return t.F_maxTerOrder }

func RBCollationTables_Reverse_StringBuilder_I_I__V(result *StringBuilder, from, to int32) {
	var i int32 = from; var swap uint16 = 0; var j int32 = to - 1


L1: for { if i < j {
	swap = NN(result).CharAt_I__C(i)
	NN(result).SetCharAt_I_C__V(i, NN(result).CharAt_I__C(j))
	NN(result).SetCharAt_I_C__V(j, swap)
	i = i + 1
	j = j - 1
//line :70:1
	continue L1 }; break L1
}
}




func RBCollationTables_GetEntry_Vector_String_Z__I(list Vector_I, name *String, fwd bool) int32 {
	var i int32 = 0; L1: for {
		if i < list.Size__I() {
			var pair *EntryPair = EntryPair_Cast(list.ElementAt_I__O(i)); var tmp1 bool; var tmp2 bool
			tmp2 = pair.F_fwd == fwd; if tmp2 { tmp2 = NN(pair.F_entryName).Equals_O__Z(name.Ref()) }; tmp1 = tmp2; if tmp1 {
				return i } else {
					i = i + 1; continue L1 } }
//line :78:1
		break L1 }
//line :77:1
	return -1
}








type RBCollationTables struct{ Object; F_rules *String; F_frenchSec, F_seAsianSwapping bool; F_mapping *UCompactIntArray; F_contractTable, F_expandTable Vector_I; F_contractFlags *IntHashtable; F_maxSecOrder, F_maxTerOrder int16 }

const RBCollationTables_EXPANDCHARINDEX int32 = 2113929216

const RBCollationTables_CONTRACTCHARINDEX int32 = 2130706432

const RBCollationTables_UNMAPPED int32 = -1

const RBCollationTables_PRIMARYORDERMASK int32 = -65536

const RBCollationTables_SECONDARYORDERMASK int32 = 65280

const RBCollationTables_TERTIARYORDERMASK int32 = 255

const RBCollationTables_PRIMARYDIFFERENCEONLY int32 = -65536

const RBCollationTables_SECONDARYDIFFERENCEONLY int32 = -256

const RBCollationTables_PRIMARYORDERSHIFT int32 = 16

const RBCollationTables_SECONDARYORDERSHIFT int32 = 8

func (t *RBCollationTables) Ref() any { if t == nil { return nil }; return t }

func (t *RBCollationTables) GetClass__Class() *Class { return RBCollationTables_class }

func (t *RBCollationTables) ToString__String() *String { return Object_toString(t) }

func (t *RBCollationTables) Clone__O() any { return A2g_ObjectClone(t) }

func (t *RBCollationTables) CloneShallow() any { panic(CloneNotSupported(t)) }

func RBCollationTables_InstanceOf(x any) bool { _, ok := x.(*RBCollationTables); return ok }

func RBCollationTables_Cast(x any) *RBCollationTables { if x == nil { return nil }; v, ok := x.(*RBCollationTables); if !ok { panic(ClassCast(x, RBCollationTables_class)) }; return v }



type RBCollationTables_BuildAPI struct{ Object; F_this_0 *RBCollationTables }

func (t *RBCollationTables_BuildAPI) Ref() any { if t == nil { return nil }; return t }

func (t *RBCollationTables_BuildAPI) GetClass__Class() *Class { return RBCollationTables_BuildAPI_class }

func (t *RBCollationTables_BuildAPI) ToString__String() *String { return Object_toString(t) }

func (t *RBCollationTables_BuildAPI) Clone__O() any { return A2g_ObjectClone(t) }

func (t *RBCollationTables_BuildAPI) CloneShallow() any { panic(CloneNotSupported(t)) }

func RBCollationTables_BuildAPI_InstanceOf(x any) bool { _, ok := x.(*RBCollationTables_BuildAPI); return ok }

func RBCollationTables_BuildAPI_Cast(x any) *RBCollationTables_BuildAPI { if x == nil { return nil }; v, ok := x.(*RBCollationTables_BuildAPI); if !ok { panic(ClassCast(x, RBCollationTables_BuildAPI_class)) }; return v }
