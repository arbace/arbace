//line java_time_format_SignStyle.ae:1
package jrt






func (t *SignStyle) Parse_Z_Z_Z__Z(positive, strict, fixedWidth bool) bool {
	switch t.Ordinal__I() { case 0:
		var tmp2 bool; tmp2 = !positive; if !tmp2 { tmp2 = !strict }; return tmp2; case 1, 4:
//line :9:1
		return true
	default:

		var tmp1 bool; tmp1 = !strict; if tmp1 { tmp1 = !fixedWidth }; return tmp1}; panic("a2g: unreachable")
}


type SignStyle struct{ Enum }

func (t *SignStyle) Is_Constable() {}

var SignStyle_NORMAL *SignStyle

var SignStyle_ALWAYS *SignStyle

var SignStyle_NEVER *SignStyle

var SignStyle_NOT_NEGATIVE *SignStyle

var SignStyle_EXCEEDS_PAD *SignStyle

var SignStyle__VALUES *RefArray

var SignStyle_init ClassInit

func SignStyle_Init() { if !SignStyle_init.Done() { SignStyle_init.Run(SignStyle_clinit) } }

func SignStyle_clinit() { SignStyle_NORMAL = SignStyle_New_String_I(Lit_2388, 0); SignStyle_ALWAYS = SignStyle_New_String_I(Lit_2389, 1); SignStyle_NEVER = SignStyle_New_String_I(Lit_2390, 2); SignStyle_NOT_NEGATIVE = SignStyle_New_String_I(Lit_2391, 3); SignStyle_EXCEEDS_PAD = SignStyle_New_String_I(Lit_2392, 4); SignStyle__VALUES = SignStyle_X_values__SignStyle1() }

func SignStyle_New_String_I(p0 *String, p1 int32) *SignStyle { SignStyle_Init(); t := &SignStyle{}; t.Ctor_String_I(p0, p1); return t }

func (t *SignStyle) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func SignStyle_Values__SignStyle1() *RefArray { SignStyle_Init(); return SignStyle__VALUES.Copy() }

func SignStyle_ValueOf_String__SignStyle(p0 *String) *SignStyle { SignStyle_Init(); return SignStyle_Cast(Enum_ValueOf_Class_String__Enum(SignStyle_class, p0)) }

func SignStyle_X_values__SignStyle1() *RefArray { SignStyle_Init(); return RefArrayOf(SignStyle_class, SignStyle_NORMAL, SignStyle_ALWAYS, SignStyle_NEVER, SignStyle_NOT_NEGATIVE, SignStyle_EXCEEDS_PAD) }

func (t *SignStyle) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *SignStyle) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *SignStyle) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *SignStyle) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.format.SignStyle.describeConstable()Ljava/util/Optional;")) }

func (t *SignStyle) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *SignStyle) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *SignStyle) Ref() any { if t == nil { return nil }; return t }

func (t *SignStyle) GetClass__Class() *Class { return SignStyle_class }

func (t *SignStyle) CloneShallow() any { panic(CloneNotSupported(t)) }

func SignStyle_InstanceOf(x any) bool { _, ok := x.(*SignStyle); return ok }

func SignStyle_Cast(x any) *SignStyle { if x == nil { return nil }; v, ok := x.(*SignStyle); if !ok { panic(ClassCast(x, SignStyle_class)) }; return v }
