//line java_net_URLStreamHandler.ae:1
package jrt









func (t *URLStreamHandler) Ctor(this URLStreamHandler_I) {}








func (t *URLStreamHandler) Impl_ParseURL_URL_String_I_I__V(this URLStreamHandler_I, u *URL, spec *String, start, limit int32) {

	var protocol *String = NN(u).GetProtocol__String(); var authority *String = NN(u).GetAuthority__String(); var userInfo *String = NN(u).GetUserInfo__String(); var host *String = NN(u).GetHost__String(); var port int32 = NN(u).GetPort__I(); var path *String = NN(u).GetPath__String(); var query *String = NN(u).GetQuery__String(); var ref *String = NN(u).GetRef__String()
	var isRelPath bool = false
	var queryOnly bool = false







	if start < limit {
		var queryStart int32 = NN(spec).IndexOf_I__I(63)
		queryOnly = queryStart == start
		var tmp1 bool; var tmp2 bool; tmp2 = !(queryStart == -1); if tmp2 { tmp2 = queryStart < limit }; tmp1 = tmp2; if tmp1 {
			query = NN(spec).Substring_I_I__String(queryStart+1, limit)
			limit = queryStart
			spec = NN(spec).Substring_I_I__String(0, queryStart) } }
	var i int32 = 0; var isUNCName bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool
	tmp6 = start <= limit-4; if tmp6 {
		tmp6 = int32(NN(spec).CharAt_I__C(start)) == 47 }
//line :40:1
	tmp5 = tmp6; if tmp5 {

		tmp5 = int32(NN(spec).CharAt_I__C(start+1)) == 47 }
//line :40:1
	tmp4 = tmp5; if tmp4 {


		tmp4 = int32(NN(spec).CharAt_I__C(start+2)) == 47 }
//line :40:1
	tmp3 = tmp4; if tmp3 {



		tmp3 = int32(NN(spec).CharAt_I__C(start+3)) == 47 }
//line :40:1
	isUNCName = tmp3




	var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = !isUNCName; if tmp10 { tmp10 = start <= limit-2 }; tmp9 = tmp10; if tmp9 {
		tmp9 = int32(NN(spec).CharAt_I__C(start)) == 47 }
//line :45:1
	tmp8 = tmp9; if tmp8 {

		tmp8 = int32(NN(spec).CharAt_I__C(start+1)) == 47 }
//line :45:1
	tmp7 = tmp8; if tmp7 {


		start = start + 2
		i = NN(spec).IndexOf_I_I__I(47, start)
		var tmp11 bool; var tmp12 bool; tmp12 = i < 0; if !tmp12 { tmp12 = i > limit }; tmp11 = tmp12; if tmp11 {
			i = NN(spec).IndexOf_I_I__I(63, start)
			var tmp13 bool; var tmp14 bool; tmp14 = i < 0; if !tmp14 { tmp14 = i > limit }; tmp13 = tmp14; if tmp13 { i = limit } }
		var tmp15 *String; authority = NN(spec).Substring_I_I__String(start, i); tmp15 = authority; host = tmp15
		var ind int32 = NN(authority).IndexOf_I__I(64)
		if !(ind == -1) {
			if !(ind == NN(authority).LastIndexOf_I__I(64)) {
				userInfo = nil; host = nil } else {

					userInfo = NN(authority).Substring_I_I__String(0, ind)
					host = NN(authority).Substring_I__String(ind + 1) } } else {
						userInfo = nil }
		if !(host == nil) {
			var tmp16 bool; var tmp17 bool; tmp17 = NN(host).Length__I() > 0; if tmp17 { tmp17 = int32(NN(host).CharAt_I__C(0)) == 91 }; tmp16 = tmp17; if tmp16 {
				var tmp18 int32; ind = NN(host).IndexOf_I__I(93); tmp18 = ind; if tmp18 > 2 {
					var nhost *String = host
					host = NN(nhost).Substring_I_I__String(0, ind+1)
					if IPAddressUtil_IsIPv6LiteralAddress_String__Z(NN(host).Substring_I_I__String(1, ind)) { } else {
						panic(Thrown(IllegalArgumentException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1466, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(host).PrefixWith_String__Exceptions_SensitiveInfo(Lit_1157))))))
					}





					port = -1
					if NN(nhost).Length__I() > ind+1 {
						if int32(NN(nhost).CharAt_I__C(ind+1)) == 58 {

							ind = ind + 1
							if NN(nhost).Length__I() > ind+1 {
								port = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(nhost), ind+1, NN(nhost).Length__I(), 10) } } else {





									panic(Thrown(IllegalArgumentException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1467, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(authority).PrefixWith_String__Exceptions_SensitiveInfo(Lit_1157)))))) } } } else {






										panic(Thrown(IllegalArgumentException_New_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1467, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(authority).PrefixWith_String__Exceptions_SensitiveInfo(Lit_1157)))))) } } else {







											ind = NN(host).IndexOf_I__I(58)
											port = -1
											if ind >= 0 {
												if NN(host).Length__I() > ind+1 {
													port = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(host), ind+1, NN(host).Length__I(), 10)
												}
												host = NN(host).Substring_I_I__String(0, ind) } } } else {
													host = Lit_69 }
		if port < -1 {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1419, StrOfInt(port))))) }
		start = i
		if NN(authority).IsEmpty__Z() { } else { path = Lit_69 } }
	if host == nil { host = Lit_69 }
	if start < limit {

		var specStr *String = NN(spec).Substring_I_I__String(start, limit)
		if int32(NN(spec).CharAt_I__C(start)) == 47 {
			path = specStr } else {
//line :118:1
				var tmp19 bool; var tmp20 bool

				tmp20 = !(path == nil); if tmp20 { tmp20 = !NN(path).IsEmpty__Z() }; tmp19 = tmp20
//line :118:1
				if tmp19 {



					isRelPath = true
					var ind_2 int32 = NN(path).LastIndexOf_I__I(47); var tmp21 bool; var tmp22 bool
					tmp22 = ind_2 == -1; if tmp22 { tmp22 = !(authority == nil) }; tmp21 = tmp22; if tmp21 {
						path = Lit_68.Concat_String__String(specStr) } else {
							path = NN(NN(path).Substring_I_I__String(0, ind_2+1)).Concat_String__String(specStr) } } else {

								var tmp23 *String; if !(authority == nil) { tmp23 = Lit_68.Concat_String__String(specStr) } else { tmp23 = specStr }; path = tmp23 } } } else {
//line :115:1
									var tmp24 bool; var tmp25 bool













									tmp25 = queryOnly; if tmp25 { tmp25 = !(path == nil) }; tmp24 = tmp25
//line :115:1
									if tmp24 {














										var ind_3 int32 = NN(path).LastIndexOf_I__I(47)
										if ind_3 < 0 {
											path = Lit_68 } else {
												path = NN(path).Substring_I_I__String(0, ind_3+1) } } }
	if path == nil { path = Lit_69 }
	if isRelPath {
	L1: for { var tmp26 int32; i = NN(path).IndexOf_String__I(Lit_1468); tmp26 = i; if tmp26 >= 0 {
		path = Concat(NN(path).Substring_I_I__String(0, i), NN(path).Substring_I__String(i+2))
//line :136:1
		continue L1 }; break L1
	}
		i = 0
	L2: for { var tmp27 int32; i = NN(path).IndexOf_String_I__I(Lit_1469, i); tmp27 = i; if tmp27 >= 0 {
		var tmp28 bool; var tmp29 bool; var tmp30 bool; tmp30 = i > 0; if tmp30 {
			var tmp31 int32; limit = NN(path).LastIndexOf_I_I__I(47, i-1); tmp31 = limit; tmp30 = tmp31 >= 0 }
//line :140:1
		tmp29 = tmp30; if tmp29 {

			tmp29 = !(NN(path).IndexOf_String_I__I(Lit_1469, limit) == 0) }
//line :140:1
		tmp28 = tmp29; if tmp28 {



			path = NN(NN(path).Substring_I_I__String(0, limit)).Concat_String__String(NN(path).Substring_I__String(i + 3))


			i = 0 } else {
				i = i + 3 }
//line :139:1
		continue L2 }; break L2
	}








	L3: for { if NN(path).EndsWith_String__Z(Lit_1470) {
		i = NN(path).IndexOf_String__I(Lit_1470)
		var tmp32 int32; limit = NN(path).LastIndexOf_I_I__I(47, i-1); tmp32 = limit; if tmp32 >= 0 {
			path = NN(path).Substring_I_I__String(0, limit+1) } else {
				break L3 }
//line :149:1
		continue L3 }; break L3
	}



		var tmp33 bool; var tmp34 bool; tmp34 = NN(path).StartsWith_String__Z(Lit_1471); if tmp34 { tmp34 = NN(path).Length__I() > 2 }; tmp33 = tmp34; if tmp33 { path = NN(path).Substring_I__String(2) }
		if NN(path).EndsWith_String__Z(Lit_1472) {
			path = NN(path).Substring_I_I__String(0, NN(path).Length__I()-1) } }
	this.SetURL_URL_String_String_I_String_String_String_String_String__V(u, protocol, host, port, authority, userInfo, path, query, ref)
}
func (t *URLStreamHandler) Impl_GetDefaultPort__I(this URLStreamHandler_I) int32 { return -1 }

func (t *URLStreamHandler) Impl_Equals_URL_URL__Z(this URLStreamHandler_I, u1, u2 *URL) bool {
	var tmp1 bool; tmp1 = Objects_Equals_O_O__Z(NN(u1).GetRef__String().Ref(), NN(u2).GetRef__String().Ref()); if tmp1 { tmp1 = this.SameFile_URL_URL__Z(u1, u2) }; return tmp1
}
func (t *URLStreamHandler) Impl_HashCode_URL__I(this URLStreamHandler_I, u *URL) int32 {
	var h int32 = 0; var protocol *String = NN(u).GetProtocol__String()

	if !(protocol == nil) { h = h + NN(protocol).HashCode__I() }
	var addr InetAddress_I = this.GetHostAddress_URL__InetAddress(u)
	if !(addr == nil) {
		h = h + addr.HashCode__I() } else {
			var host *String = NN(u).GetHost__String()
			if !(host == nil) {
				var tmp1 int32 = h; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; h = tmp1 + NN(NN(host).ToLowerCase_Locale__String(tmp2)).HashCode__I() } }
	var file *String = NN(u).GetFile__String()
	if !(file == nil) { h = h + NN(file).HashCode__I() }
	if NN(u).GetPort__I() == -1 {
		h = h + this.GetDefaultPort__I() } else {
			h = h + NN(u).GetPort__I() }
	var ref *String = NN(u).GetRef__String()
	if !(ref == nil) { h = h + NN(ref).HashCode__I() }
//line :179:1
	return h
}


func (t *URLStreamHandler) Impl_SameFile_URL_URL__Z(this URLStreamHandler_I, u1, u2 *URL) bool {
	var tmp1 bool; var tmp2 bool
	tmp2 = NN(u1).GetProtocol__String() == NN(u2).GetProtocol__String(); if !tmp2 {
		var tmp3 bool; tmp3 = !(NN(u1).GetProtocol__String() == nil); if tmp3 {
			tmp3 = NN(NN(u1).GetProtocol__String()).EqualsIgnoreCase_String__Z(NN(u2).GetProtocol__String()) }
//line :186:1
		tmp2 = tmp3 }
//line :185:1
	tmp1 = tmp2
//line :184:1
	if !tmp1 { return false } else { var tmp4 bool; var tmp5 bool




		tmp5 = NN(u1).GetFile__String() == NN(u2).GetFile__String(); if !tmp5 {
			var tmp6 bool; tmp6 = !(NN(u1).GetFile__String() == nil); if tmp6 { tmp6 = NN(NN(u1).GetFile__String()).Equals_O__Z(NN(u2).GetFile__String().Ref()) }; tmp5 = tmp6 }
//line :189:1
		tmp4 = tmp5
//line :184:1
		if !tmp4 { return false } else {








			var port1 int32 = 0; var port2 int32 = 0; var tmp7 int32


			if !(NN(u1).GetPort__I() == -1) { tmp7 = NN(u1).GetPort__I() } else { tmp7 = u1.F_handler.GetDefaultPort__I() }
//line :195:1
			port1 = tmp7

			var tmp8 int32
			if !(NN(u2).GetPort__I() == -1) { tmp8 = NN(u2).GetPort__I() } else { tmp8 = u2.F_handler.GetDefaultPort__I() }
//line :197:1
			port2 = tmp8

			if !(port1 == port2) { return false } else { if !this.HostsEqual_URL_URL__Z(u1, u2) { return false } else { return true
			} } } } }
func (t *URLStreamHandler) Impl_GetHostAddress_URL__InetAddress(this URLStreamHandler_I, u *URL) InetAddress_I {
	return NN(u).GetHostAddress__InetAddress()
}
func (t *URLStreamHandler) Impl_HostsEqual_URL_URL__Z(this URLStreamHandler_I, u1, u2 *URL) bool {
	var a1 InetAddress_I = this.GetHostAddress_URL__InetAddress(u1); var a2 InetAddress_I = this.GetHostAddress_URL__InetAddress(u2); var tmp1 bool; var tmp2 bool


	tmp2 = !(a1 == nil); if tmp2 { tmp2 = !(a2 == nil) }; tmp1 = tmp2
//line :207:1
	if tmp1 {
		return a1.Equals_O__Z(a2) } else {
//line :207:1
			var tmp3 bool; var tmp4 bool

			tmp4 = !(NN(u1).GetHost__String() == nil); if tmp4 { tmp4 = !(NN(u2).GetHost__String() == nil) }; tmp3 = tmp4
//line :207:1
			if tmp3 {


				return NN(NN(u1).GetHost__String()).EqualsIgnoreCase_String__Z(NN(u2).GetHost__String()) } else {
					var tmp5 bool; tmp5 = NN(u1).GetHost__String() == nil; if tmp5 { tmp5 = NN(u2).GetHost__String() == nil }; return tmp5
				} } }
func (t *URLStreamHandler) Impl_ToExternalForm_URL__String(this URLStreamHandler_I, u *URL) *String {
	var s *String; var tmp1 *String = NN(u).GetProtocol__String(); var tmp2 *String; var tmp3 bool; var tmp4 bool; var tmp5 *String


	s = NN(u).GetAuthority__String(); tmp5 = s; tmp4 = !(tmp5 == nil); if tmp4 { tmp4 = !NN(s).IsEmpty__Z() }; tmp3 = tmp4; if tmp3 {
		tmp2 = Concat(Lit_70, s) } else {
//line :217:1
			tmp2 = Lit_69 }
//line :215:1
	var tmp6 *String = tmp2; var tmp7 *String; var tmp8 *String




	s = NN(u).GetPath__String(); tmp8 = s; if !(tmp8 == nil) { tmp7 = s } else { tmp7 = Lit_69 }
//line :215:1
	var tmp9 *String = tmp7; var tmp10 *String; var tmp11 *String





	s = NN(u).GetQuery__String(); tmp11 = s; if !(tmp11 == nil) { tmp10 = Concat(Lit_1420, s) } else { tmp10 = Lit_69 }
//line :215:1
	var tmp12 *String = tmp10; var tmp13 *String; var tmp14 *String






	s = NN(u).GetRef__String(); tmp14 = s; if !(tmp14 == nil) { tmp13 = Concat(Lit_1132, s) } else { tmp13 = Lit_69 }
//line :215:1
	return Concat(tmp1, Lit_1309, tmp6, tmp9, tmp12, tmp13)
}







func (t *URLStreamHandler) Impl_SetURL_URL_String_String_I_String_String_String_String_String__V(this URLStreamHandler_I, u *URL, protocol, host *String, port int32, authority, userInfo, path, query, ref *String) {


	if this == u.F_handler { } else {
		panic(Thrown(A2g_Missing[Throwable_I]("class java.lang.SecurityException is not in the closed world"))) }
	var earlyURLParsing bool = IPAddressUtil_EarlyURLParsing__Z(); var isBuiltInHandler bool = NN(u).IsBuiltinStreamHandler_URLStreamHandler__Z(this); var tmp1 bool; var tmp2 bool

	tmp2 = !(host == nil); if tmp2 { tmp2 = isBuiltInHandler }; tmp1 = tmp2; if tmp1 {
		var errMsg *String = IPAddressUtil_CheckHostString_String__String(host)
		if !(errMsg == nil) { panic(Thrown(IllegalArgumentException_New_String(errMsg))) } }
	var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = !(userInfo == nil); if tmp5 { tmp5 = isBuiltInHandler }; tmp4 = tmp5; if tmp4 { tmp4 = earlyURLParsing }; tmp3 = tmp4; if tmp3 {
		var errMsg_2 *String = IPAddressUtil_CheckUserInfo_String__String(userInfo)
		if !(errMsg_2 == nil) { panic(Thrown(IllegalArgumentException_New_String(errMsg_2))) } }
	var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = !(authority == nil); if tmp8 { tmp8 = isBuiltInHandler }; tmp7 = tmp8; if tmp7 { tmp7 = earlyURLParsing }; tmp6 = tmp7; if tmp6 {
		var errMsg_3 *String = IPAddressUtil_CheckAuth_String__String(authority)
		if !(errMsg_3 == nil) { panic(Thrown(IllegalArgumentException_New_String(errMsg_3))) } }
	NN(u).Set_String_String_I_String_String_String_String_String__V(NN(u).GetProtocol__String(), host, port, authority, userInfo, path, query, ref)
}
func (t *URLStreamHandler) Impl_SetURL_URL_String_String_I_String_String__V(this URLStreamHandler_I, u *URL, protocol, host *String, port int32, file, ref *String) {


	var authority *String; var userInfo *String; var tmp1 bool; var tmp2 bool

	tmp2 = !(host == nil); if tmp2 { tmp2 = !NN(host).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		var tmp3 *String; if port == -1 { tmp3 = host } else { tmp3 = Concat(host, Lit_1309, StrOfInt(port)) }; authority = tmp3
		var at int32 = NN(host).LastIndexOf_I__I(64)
		if at == -1 { } else {
			userInfo = NN(host).Substring_I_I__String(0, at)
			host = NN(host).Substring_I__String(at + 1) } }
	var path *String; var query *String

	if !(file == nil) {
		var q int32 = NN(file).LastIndexOf_I__I(63)
		if !(q == -1) {

			query = NN(file).Substring_I__String(q + 1)
			path = NN(file).Substring_I_I__String(0, q) } else {
				path = file } }
	this.SetURL_URL_String_String_I_String_String_String_String_String__V(u, protocol, host, port, authority, userInfo, path, query, ref)
}


type URLStreamHandler struct{ Object }

type URLStreamHandler_I interface{ Object_I; Self_URLStreamHandler() *URLStreamHandler; OpenConnection_URL__URLConnection(p0 *URL) URLConnection_I; ParseURL_URL_String_I_I__V(p0 *URL, p1 *String, p2, p3 int32); GetDefaultPort__I() int32; Equals_URL_URL__Z(p0, p1 *URL) bool; HashCode_URL__I(p0 *URL) int32; SameFile_URL_URL__Z(p0, p1 *URL) bool; GetHostAddress_URL__InetAddress(p0 *URL) InetAddress_I; HostsEqual_URL_URL__Z(p0, p1 *URL) bool; ToExternalForm_URL__String(p0 *URL) *String; SetURL_URL_String_String_I_String_String_String_String_String__V(p0 *URL, p1, p2 *String, p3 int32, p4, p5, p6, p7, p8 *String); SetURL_URL_String_String_I_String_String__V(p0 *URL, p1, p2 *String, p3 int32, p4, p5 *String) }

func (t *URLStreamHandler) Self_URLStreamHandler() *URLStreamHandler { return t }

func URLStreamHandler_InstanceOf(x any) bool { _, ok := x.(URLStreamHandler_I); return ok }

func URLStreamHandler_Cast(x any) URLStreamHandler_I { if x == nil { return nil }; v, ok := x.(URLStreamHandler_I); if !ok { panic(ClassCast(x, URLStreamHandler_class)) }; return v }
