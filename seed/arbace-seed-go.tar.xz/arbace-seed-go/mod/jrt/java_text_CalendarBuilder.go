//line java_text_CalendarBuilder.ae:1
package jrt

























func CalendarBuilder_New() *CalendarBuilder { t := &CalendarBuilder{}; t.Ctor(); return t }
//line :27:1
func (t *CalendarBuilder) Ctor() {
	t.F_field = NewIntArray(36)
	t.F_nextStamp = 2
	t.F_maxFieldIndex = -1
}
func (t *CalendarBuilder) Set_I_I__CalendarBuilder(index, value int32) *CalendarBuilder {
	if index == 1000 {
		index = 7
		value = CalendarBuilder_ToCalendarDayOfWeek_I__I(value) }
	var tmp1 *IntArray = t.F_field; var tmp2 int32 = index; var tmp3 int32; var old_1 int32 = t.F_nextStamp; t.F_nextStamp = t.F_nextStamp + 1; tmp3 = old_1; tmp1.A[tmp2] = tmp3
	t.F_field.A[18+index] = value
	var tmp4 bool; var tmp5 bool; tmp5 = index > t.F_maxFieldIndex; if tmp5 { tmp5 = index < 17 }; tmp4 = tmp5; if tmp4 {
		t.F_maxFieldIndex = index }
//line :32:1
	return t
}








func (t *CalendarBuilder) AddYear_I__CalendarBuilder(value int32) *CalendarBuilder {
	var i_2 int32 = 19; var tmp1 *IntArray = t.F_field
	tmp1.A[i_2] = t.F_field.A[i_2] + value
	var i_3 int32 = 35; var tmp2 *IntArray = t.F_field
	tmp2.A[i_3] = t.F_field.A[i_3] + value
//line :42:1
	return t
}





func (t *CalendarBuilder) IsSet_I__Z(index int32) bool {
	if index == 1000 { index = 7 }
	return t.F_field.A[index] > 0
}
func (t *CalendarBuilder) Clear_I__CalendarBuilder(index int32) *CalendarBuilder {
	if index == 1000 { index = 7 }
	t.F_field.A[index] = 0
	t.F_field.A[18+index] = 0
//line :53:1
	return t
}




func (t *CalendarBuilder) Establish_Calendar__Calendar(cal Calendar_I) Calendar_I {
	var weekDate bool; var tmp1 bool; tmp1 = t.IsSet_I__Z(17); if tmp1 {
		var tmp2 int32 = t.F_field.A[17]; tmp1 = tmp2 > t.F_field.A[1] }
//line :60:1
	weekDate = tmp1

	var tmp3 bool; var tmp4 bool; tmp4 = weekDate; if tmp4 { tmp4 = !cal.IsWeekDateSupported__Z() }; tmp3 = tmp4; if tmp3 {
		if t.IsSet_I__Z(1) { } else {
			t.Set_I_I__CalendarBuilder(1, t.F_field.A[35]) }
		weekDate = false }
	cal.Clear__V()
	var stamp int32 = 2; L1: for {
		if stamp < t.F_nextStamp {
			var index int32 = 0; L2: for {
				if index <= t.F_maxFieldIndex {
					if t.F_field.A[index] == stamp {
						cal.Set_I_I__V(index, t.F_field.A[18+index]) } else {
							index = index + 1; continue L2 } }
//line :69:1
				break L2
			}




			stamp = stamp + 1; continue L1 }
//line :67:1
		break L1
	}







	if weekDate {
		var weekOfYear int32; if t.IsSet_I__Z(3) {
			weekOfYear = t.F_field.A[21] } else {
//line :77:1
				weekOfYear = 1 }; var dayOfWeek int32






		if t.IsSet_I__Z(7) {
			dayOfWeek = t.F_field.A[25] } else {




				dayOfWeek = cal.GetFirstDayOfWeek__I() }
		var tmp5 bool; var tmp6 bool; tmp6 = !CalendarBuilder_IsValidDayOfWeek_I__Z(dayOfWeek); if tmp6 { tmp6 = cal.IsLenient__Z() }; tmp5 = tmp6; if tmp5 {
			if dayOfWeek >= 8 {

				dayOfWeek = dayOfWeek - 1
				weekOfYear = weekOfYear + dayOfWeek/7

				dayOfWeek = dayOfWeek%7 + 1 } else {
				L3: for { if dayOfWeek <= 0 {
					dayOfWeek = dayOfWeek + 7
					weekOfYear = weekOfYear - 1
//line :98:1
					continue L3 }; break L3
				}
				}
			dayOfWeek = CalendarBuilder_ToCalendarDayOfWeek_I__I(dayOfWeek) }
		cal.SetWeekDate_I_I_I__V(t.F_field.A[35], weekOfYear, dayOfWeek) }
//line :60:1
	return cal
}














































func (t *CalendarBuilder) ToString__String() *String {
	var sj *StringJoiner = StringJoiner_New_CharSequence_CharSequence_CharSequence(Lit_1532, Lit_1707, Lit_1189); var i int32 = 0
L1: for {
	if i < 18 {
		if t.IsSet_I__Z(i) {

			var tmp1 int32 = t.F_field.A[i]; NN(sj).Add_CharSequence__StringJoiner(Concat(StrOfInt(i), Lit_1171, StrOfInt(tmp1), Lit_1309, StrOfInt(t.F_field.A[18+i])))





			i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :110:1
	break L1
}











	return NN(sj).ToString__String()
}
func CalendarBuilder_ToISODayOfWeek_I__I(calendarDayOfWeek int32) int32 {
	if calendarDayOfWeek == 1 { return 7 } else {

		return calendarDayOfWeek - 1
	} }
func CalendarBuilder_ToCalendarDayOfWeek_I__I(isoDayOfWeek int32) int32 {
	if !CalendarBuilder_IsValidDayOfWeek_I__Z(isoDayOfWeek) { return isoDayOfWeek } else { if isoDayOfWeek == 7 { return 1 } else {


		return isoDayOfWeek + 1
	} } }
func CalendarBuilder_IsValidDayOfWeek_I__Z(dayOfWeek int32) bool {
	var tmp1 bool; tmp1 = dayOfWeek > 0; if tmp1 { tmp1 = dayOfWeek <= 7 }; return tmp1
}


type CalendarBuilder struct{ Object; F_field *IntArray; F_nextStamp, F_maxFieldIndex int32 }

const CalendarBuilder_UNSET int32 = 0

const CalendarBuilder_COMPUTED int32 = 1

const CalendarBuilder_MINIMUM_USER_STAMP int32 = 2

const CalendarBuilder_MAX_FIELD int32 = 18

const CalendarBuilder_WEEK_YEAR int32 = 17

const CalendarBuilder_ISO_DAY_OF_WEEK int32 = 1000

func (t *CalendarBuilder) Ref() any { if t == nil { return nil }; return t }

func (t *CalendarBuilder) GetClass__Class() *Class { return CalendarBuilder_class }

func (t *CalendarBuilder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CalendarBuilder) CloneShallow() any { panic(CloneNotSupported(t)) }

func CalendarBuilder_InstanceOf(x any) bool { _, ok := x.(*CalendarBuilder); return ok }

func CalendarBuilder_Cast(x any) *CalendarBuilder { if x == nil { return nil }; v, ok := x.(*CalendarBuilder); if !ok { panic(ClassCast(x, CalendarBuilder_class)) }; return v }
