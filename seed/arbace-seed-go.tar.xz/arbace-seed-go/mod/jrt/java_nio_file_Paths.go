//line java_nio_file_Paths.ae:1
package jrt






func Paths_New() *Paths { t := &Paths{}; t.Ctor(); return t }
//line :8:1
func (t *Paths) Ctor() { panic(A2g_NotTranslated("java.nio.file.Paths.<init>()V")) }

func Paths_Get_String_String1__Path(first *String, more *RefArray) Path {
	return Path_Of_String_String1__Path(first, more)
}
func Paths_Get_URI__Path(uri *URI) Path { return Path_Of_URI__Path(uri) }



type Paths struct{ Object }

func (t *Paths) Ref() any { if t == nil { return nil }; return t }

func (t *Paths) GetClass__Class() *Class { return Paths_class }

func (t *Paths) ToString__String() *String { return Object_toString(t) }

func (t *Paths) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Paths) CloneShallow() any { panic(CloneNotSupported(t)) }

func Paths_InstanceOf(x any) bool { _, ok := x.(*Paths); return ok }

func Paths_Cast(x any) *Paths { if x == nil { return nil }; v, ok := x.(*Paths); if !ok { panic(ClassCast(x, Paths_class)) }; return v }
