//line java_io_FilterReader.ae:1
package jrt








func (t *FilterReader) Ctor_Reader(this FilterReader_I, in Reader_I) { t.Reader.Ctor_O(this, in)

	t.F_in = in
}
func (t *FilterReader) Impl_Read__I(this FilterReader_I) int32 { return t.F_in.Read__I() }

func (t *FilterReader) Impl_Read_C1_I_I__I(this FilterReader_I, cbuf *CharArray, off, len_ int32) int32 {
	return t.F_in.Read_C1_I_I__I(cbuf, off, len_)
}
func (t *FilterReader) Impl_Skip_J__J(this FilterReader_I, n int64) int64 {
	return t.F_in.Skip_J__J(n)
}
func (t *FilterReader) Impl_Ready__Z(this FilterReader_I) bool {
	return t.F_in.Ready__Z()
}
func (t *FilterReader) Impl_MarkSupported__Z(this FilterReader_I) bool { return t.F_in.MarkSupported__Z() }

func (t *FilterReader) Impl_Mark_I__V(this FilterReader_I, readAheadLimit int32) {
	t.F_in.Mark_I__V(readAheadLimit)
}
func (t *FilterReader) Impl_Reset__V(this FilterReader_I) { t.F_in.Reset__V() }

func (t *FilterReader) Impl_Close__V(this FilterReader_I) { t.F_in.Close__V() }



type FilterReader struct{ Reader; F_in Reader_I }

type FilterReader_I interface{ Reader_I; Closeable; AutoCloseable; Self_FilterReader() *FilterReader; Read__I() int32; Read_C1_I_I__I(p0 *CharArray, p1, p2 int32) int32; Skip_J__J(p0 int64) int64; Ready__Z() bool; MarkSupported__Z() bool; Mark_I__V(p0 int32); Reset__V(); Close__V() }

func (t *FilterReader) Self_FilterReader() *FilterReader { return t }

func FilterReader_InstanceOf(x any) bool { _, ok := x.(FilterReader_I); return ok }

func FilterReader_Cast(x any) FilterReader_I { if x == nil { return nil }; v, ok := x.(FilterReader_I); if !ok { panic(ClassCast(x, FilterReader_class)) }; return v }
