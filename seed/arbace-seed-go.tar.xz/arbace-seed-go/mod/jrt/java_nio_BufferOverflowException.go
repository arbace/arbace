//line java_nio_BufferOverflowException.ae:1
package jrt








func BufferOverflowException_New() *BufferOverflowException { t := &BufferOverflowException{}; t.Ctor(); return t }
//line :10:1
func (t *BufferOverflowException) Ctor() { t.RuntimeException.Ctor(t) }





type BufferOverflowException struct{ RuntimeException }

const BufferOverflowException_serialVersionUID int64 = -5484897634319144535

func (t *BufferOverflowException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *BufferOverflowException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *BufferOverflowException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *BufferOverflowException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *BufferOverflowException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *BufferOverflowException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *BufferOverflowException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *BufferOverflowException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *BufferOverflowException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *BufferOverflowException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *BufferOverflowException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *BufferOverflowException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *BufferOverflowException) Ref() any { if t == nil { return nil }; return t }

func (t *BufferOverflowException) GetClass__Class() *Class { return BufferOverflowException_class }

func (t *BufferOverflowException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BufferOverflowException) CloneShallow() any { panic(CloneNotSupported(t)) }

func BufferOverflowException_InstanceOf(x any) bool { _, ok := x.(*BufferOverflowException); return ok }

func BufferOverflowException_Cast(x any) *BufferOverflowException { if x == nil { return nil }; v, ok := x.(*BufferOverflowException); if !ok { panic(ClassCast(x, BufferOverflowException_class)) }; return v }
