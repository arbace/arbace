//line java_math_BitSieve.ae:1
package jrt












func BitSieve_New() *BitSieve { BitSieve_Init(); t := &BitSieve{}; t.Ctor(); return t }
//line :14:1
func (t *BitSieve) Ctor() {
	t.F_length = 9600
	t.F_bits = NewLongArray(BitSieve_UnitIndex_I__I(t.F_length-1) + 1)

	t.Set_I__V(0)
	var nextIndex int32 = 1
	var nextPrime int32 = 3
L1: for {
	t.SieveSingle_I_I_I__V(t.F_length, nextIndex+nextPrime, nextPrime)
	nextIndex = t.SieveSearch_I_I__I(t.F_length, nextIndex+1)
	nextPrime = 2*nextIndex + 1
	var tmp1 bool; var tmp2 bool; tmp2 = nextIndex > 0; if tmp2 { tmp2 = nextPrime < t.F_length }; tmp1 = tmp2; if tmp1 { continue L1 }
//line :21:1
	break L1
}
}



func BitSieve_New_BigInteger_I(p0 *BigInteger, p1 int32) *BitSieve { BitSieve_Init(); t := &BitSieve{}; t.Ctor_BigInteger_I(p0, p1); return t }
//line :27:1
func (t *BitSieve) Ctor_BigInteger_I(base *BigInteger, searchLen int32) {
	t.F_bits = NewLongArray(BitSieve_UnitIndex_I__I(searchLen-1) + 1)


	t.F_length = searchLen
	var start int32 = 0; var tmp1 *BitSieve = BitSieve_smallSieve; var step int32 = NN(tmp1).SieveSearch_I_I__I(BitSieve_smallSieve.F_length, start); var convertedStep int32 = step*2 + 1; var b MutableBigInteger_I = MutableBigInteger_New_BigInteger(base); var q MutableBigInteger_I = MutableBigInteger_New()




L1: for {
	start = b.DivideOneWord_I_MutableBigInteger__I(convertedStep, q)
	start = convertedStep - start
	if start%2 == 0 {
		start = start + convertedStep }
	t.SieveSingle_I_I_I__V(searchLen, (start-1)/2, convertedStep)



	var tmp2 *BitSieve = BitSieve_smallSieve; step = NN(tmp2).SieveSearch_I_I__I(BitSieve_smallSieve.F_length, step+1)
	convertedStep = step*2 + 1
	if step > 0 { continue L1 }
//line :37:1
	break L1
}
}










func BitSieve_UnitIndex_I__I(bitIndex int32) int32 { BitSieve_Init()
	return int32(uint32(bitIndex) >> 6)
}
func BitSieve_Bit_I__J(bitIndex int32) int64 { BitSieve_Init()
	return 1 << (bitIndex & 63 & 63)
}
func (t *BitSieve) Get_I__Z(bitIndex int32) bool {
	var unitIndex int32 = BitSieve_UnitIndex_I__I(bitIndex); var tmp1 int64 = t.F_bits.A[unitIndex]
	return !(tmp1&BitSieve_Bit_I__J(bitIndex) == 0)
}
func (t *BitSieve) Set_I__V(bitIndex int32) {
	var unitIndex int32 = BitSieve_UnitIndex_I__I(bitIndex); var tmp1 *LongArray = t.F_bits; var tmp2 int64 = t.F_bits.A[unitIndex]
	tmp1.A[unitIndex] = tmp2 | BitSieve_Bit_I__J(bitIndex)
}
func (t *BitSieve) SieveSearch_I_I__I(limit, start int32) int32 {
	if start >= limit { return -1 } else {

		var index int32 = start
	L1: for {
		if t.Get_I__Z(index) { } else { return index }
		index = index + 1
		if index < limit-1 { continue L1 }
//line :68:1
		break L1 }
//line :67:1
		return -1
	}
}




func (t *BitSieve) SieveSingle_I_I_I__V(limit, start, step int32) {
L1: for { if start < limit { t.Set_I__V(start); start = start + step; continue L1 }; break L1
} }
func (t *BitSieve) Retrieve_BigInteger_I_Random__BigInteger(initValue *BigInteger, certainty int32, random Random_I) *BigInteger {
	var offset int32 = 1; var i int32 = 0
L1: for {
	if i < int32(len(t.F_bits.A)) {
		var nextLong int64 = ^t.F_bits.A[i]; var j int32 = 0
	L2: for {
		if j < 64 {
			if nextLong&1 == 1 {
				var candidate *BigInteger = NN(initValue).Add_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(int64(offset)))
				if NN(candidate).PrimeToCertainty_I_Random__Z(certainty, random) { return candidate } }
			nextLong = int64(uint64(nextLong) >> 1)
			offset = offset + 2
			j = j + 1; continue L2 }
//line :82:1
		break L2
	}






		i = i + 1; continue L1 }
//line :79:1
	break L1 }
//line :78:1
	return nil
}














type BitSieve struct{ Object; F_bits *LongArray; F_length int32 }

var BitSieve_smallSieve *BitSieve

var BitSieve_init ClassInit

func BitSieve_Init() { if !BitSieve_init.Done() { BitSieve_init.Run(BitSieve_clinit) } }

func BitSieve_clinit() { BitSieve_smallSieve = BitSieve_New() }

func (t *BitSieve) Ref() any { if t == nil { return nil }; return t }

func (t *BitSieve) GetClass__Class() *Class { return BitSieve_class }

func (t *BitSieve) ToString__String() *String { return Object_toString(t) }

func (t *BitSieve) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BitSieve) CloneShallow() any { panic(CloneNotSupported(t)) }

func BitSieve_InstanceOf(x any) bool { _, ok := x.(*BitSieve); return ok }

func BitSieve_Cast(x any) *BitSieve { if x == nil { return nil }; v, ok := x.(*BitSieve); if !ok { panic(ClassCast(x, BitSieve_class)) }; return v }
