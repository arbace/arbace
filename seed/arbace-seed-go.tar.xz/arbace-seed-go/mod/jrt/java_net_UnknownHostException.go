//line java_net_UnknownHostException.ae:1
package jrt










func UnknownHostException_New_String(p0 *String) *UnknownHostException { t := &UnknownHostException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *UnknownHostException) Ctor_String(message *String) { t.IOException.Ctor_String(t, message) }

func UnknownHostException_New() *UnknownHostException { t := &UnknownHostException{}; t.Ctor(); return t }
//line :14:1
func (t *UnknownHostException) Ctor() { t.IOException.Ctor(t) }







type UnknownHostException struct{ IOException }

const UnknownHostException_serialVersionUID int64 = -4639126076052875403

func (t *UnknownHostException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *UnknownHostException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *UnknownHostException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *UnknownHostException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *UnknownHostException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *UnknownHostException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *UnknownHostException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *UnknownHostException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *UnknownHostException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *UnknownHostException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *UnknownHostException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *UnknownHostException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *UnknownHostException) Ref() any { if t == nil { return nil }; return t }

func (t *UnknownHostException) GetClass__Class() *Class { return UnknownHostException_class }

func (t *UnknownHostException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UnknownHostException) CloneShallow() any { panic(CloneNotSupported(t)) }

func UnknownHostException_InstanceOf(x any) bool { _, ok := x.(*UnknownHostException); return ok }

func UnknownHostException_Cast(x any) *UnknownHostException { if x == nil { return nil }; v, ok := x.(*UnknownHostException); if !ok { panic(ClassCast(x, UnknownHostException_class)) }; return v }
