//line java_io_NotSerializableException.ae:1
package jrt








func NotSerializableException_New_String(p0 *String) *NotSerializableException { t := &NotSerializableException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *NotSerializableException) Ctor_String(classname *String) { t.ObjectStreamException.Ctor_String(t, classname) }

func NotSerializableException_New() *NotSerializableException { t := &NotSerializableException{}; t.Ctor(); return t }
//line :12:1
func (t *NotSerializableException) Ctor() { t.ObjectStreamException.Ctor(t) }







type NotSerializableException struct{ ObjectStreamException }

const NotSerializableException_serialVersionUID int64 = 2906642554793891381

func (t *NotSerializableException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *NotSerializableException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *NotSerializableException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *NotSerializableException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *NotSerializableException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *NotSerializableException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *NotSerializableException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *NotSerializableException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *NotSerializableException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *NotSerializableException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *NotSerializableException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *NotSerializableException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *NotSerializableException) Ref() any { if t == nil { return nil }; return t }

func (t *NotSerializableException) GetClass__Class() *Class { return NotSerializableException_class }

func (t *NotSerializableException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *NotSerializableException) CloneShallow() any { panic(CloneNotSupported(t)) }

func NotSerializableException_InstanceOf(x any) bool { _, ok := x.(*NotSerializableException); return ok }

func NotSerializableException_Cast(x any) *NotSerializableException { if x == nil { return nil }; v, ok := x.(*NotSerializableException); if !ok { panic(ClassCast(x, NotSerializableException_class)) }; return v }
