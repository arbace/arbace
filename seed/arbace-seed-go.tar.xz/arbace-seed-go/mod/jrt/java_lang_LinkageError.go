//line java_lang_LinkageError.ae:1
package jrt








func LinkageError_New() *LinkageError { t := &LinkageError{}; t.Ctor(t); return t }
//line :10:1
func (t *LinkageError) Ctor(this LinkageError_I) { t.Error.Ctor(this) }

func LinkageError_New_String(p0 *String) *LinkageError { t := &LinkageError{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *LinkageError) Ctor_String(this LinkageError_I, s *String) { t.Error.Ctor_String(this, s) }

func LinkageError_New_String_Throwable(p0 *String, p1 Throwable_I) *LinkageError { t := &LinkageError{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :14:1
func (t *LinkageError) Ctor_String_Throwable(this LinkageError_I, s *String, cause Throwable_I) { t.Error.Ctor_String_Throwable(this, s, cause) }









type LinkageError struct{ Error }

type LinkageError_I interface{ Error_I; Serializable; Self_LinkageError() *LinkageError }

func (t *LinkageError) Self_LinkageError() *LinkageError { return t }

const LinkageError_serialVersionUID int64 = 3579600108157160122

func (t *LinkageError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *LinkageError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *LinkageError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *LinkageError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *LinkageError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *LinkageError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *LinkageError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *LinkageError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *LinkageError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *LinkageError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *LinkageError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *LinkageError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkageError) Ref() any { if t == nil { return nil }; return t }

func (t *LinkageError) GetClass__Class() *Class { return LinkageError_class }

func (t *LinkageError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkageError) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkageError_InstanceOf(x any) bool { _, ok := x.(LinkageError_I); return ok }

func LinkageError_Cast(x any) LinkageError_I { if x == nil { return nil }; v, ok := x.(LinkageError_I); if !ok { panic(ClassCast(x, LinkageError_class)) }; return v }
