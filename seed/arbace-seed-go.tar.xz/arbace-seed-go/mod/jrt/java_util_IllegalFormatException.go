//line java_util_IllegalFormatException.ae:1
package jrt




















func IllegalFormatException_New() *IllegalFormatException { t := &IllegalFormatException{}; t.Ctor(t); return t }
//line :22:1
func (t *IllegalFormatException) Ctor(this IllegalFormatException_I) { t.IllegalArgumentException.Ctor(this) }





type IllegalFormatException struct{ IllegalArgumentException }

type IllegalFormatException_I interface{ IllegalArgumentException_I; Serializable; Self_IllegalFormatException() *IllegalFormatException }

func (t *IllegalFormatException) Self_IllegalFormatException() *IllegalFormatException { return t }

const IllegalFormatException_serialVersionUID int64 = 18830826

func (t *IllegalFormatException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalFormatException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalFormatException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalFormatException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalFormatException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalFormatException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalFormatException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalFormatException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalFormatException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalFormatException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalFormatException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalFormatException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalFormatException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalFormatException) GetClass__Class() *Class { return IllegalFormatException_class }

func (t *IllegalFormatException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalFormatException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalFormatException_InstanceOf(x any) bool { _, ok := x.(IllegalFormatException_I); return ok }

func IllegalFormatException_Cast(x any) IllegalFormatException_I { if x == nil { return nil }; v, ok := x.(IllegalFormatException_I); if !ok { panic(ClassCast(x, IllegalFormatException_class)) }; return v }
