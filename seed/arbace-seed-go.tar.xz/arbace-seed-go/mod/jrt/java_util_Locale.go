//line java_util_Locale.ae:1
package jrt

import "sync/atomic"

































































































func Locale_CreateConstant_B__Locale(baseType int8) *Locale { Locale_Init()
	var base *BaseLocale; var tmp1 *RefArray; BaseLocale_Init(); tmp1 = BaseLocale_constantBaseLocales; base = As[*BaseLocale](tmp1.A[int32(baseType)]); var locale *Locale = Locale_New_BaseLocale_LocaleExtensions(base, nil)

	Locale_CONSTANT_LOCALES.Put_O_O__O(base.Ref(), locale.Ref())
//line :102:1
	return locale
}
























func Locale_New_BaseLocale_LocaleExtensions(p0 *BaseLocale, p1 *LocaleExtensions) *Locale { Locale_Init(); t := &Locale{}; t.Ctor_BaseLocale_LocaleExtensions(p0, p1); return t }
//line :128:1
func (t *Locale) Ctor_BaseLocale_LocaleExtensions(baseLocale *BaseLocale, extensions *LocaleExtensions) { t.F_languageTag = LazyConstant_Of_Supplier__LazyConstant(Locale_3_New_Locale(t))
	t.F_baseLocale = baseLocale
	t.F_localeExtensions = extensions
}
func Locale_New_String_String_String(p0, p1, p2 *String) *Locale { Locale_Init(); t := &Locale{}; t.Ctor_String_String_String(p0, p1, p2); return t }
//line :132:1
func (t *Locale) Ctor_String_String_String(language, country, variant *String) { t.F_languageTag = LazyConstant_Of_Supplier__LazyConstant(Locale_3_New_Locale(t))

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = language == nil; if !tmp3 { tmp3 = country == nil }; tmp2 = tmp3; if !tmp2 { tmp2 = variant == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	t.F_baseLocale = BaseLocale_GetInstance_String_String_String_String__BaseLocale(Locale_ConvertOldISOCodes_String__String(language), Lit_69, country, variant)

	t.F_localeExtensions = Locale_GetCompatibilityExtensions_String_String_String_String__LocaleExtensions(language, Lit_69, country, variant)
}
func Locale_New_String_String(p0, p1 *String) *Locale { Locale_Init(); t := &Locale{}; t.Ctor_String_String(p0, p1); return t }
//line :139:1
func (t *Locale) Ctor_String_String(language, country *String) { t.Ctor_String_String_String(language, country, Lit_69) }


func Locale_New_String(p0 *String) *Locale { Locale_Init(); t := &Locale{}; t.Ctor_String(p0); return t }
//line :142:1
func (t *Locale) Ctor_String(language *String) { t.Ctor_String_String_String(language, Lit_69, Lit_69) }


func Locale_Of_String_String_String__Locale(language, country, variant *String) *Locale { Locale_Init()
	return Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, Lit_69, country, variant, nil)
}
func Locale_Of_String_String__Locale(language, country *String) *Locale { Locale_Init()
	return Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, Lit_69, country, Lit_69, nil)
}
func Locale_Of_String__Locale(language *String) *Locale { Locale_Init()
	return Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, Lit_69, Lit_69, Lit_69, nil)
}
func Locale_GetInstance_String_String_String__Locale(language, country, variant *String) *Locale { Locale_Init()
	return Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, Lit_69, country, variant, nil)
}
func Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(language, script, country, variant *String, extensions *LocaleExtensions) *Locale { Locale_Init()

	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = language == nil; if !tmp4 { tmp4 = script == nil }; tmp3 = tmp4; if !tmp3 { tmp3 = country == nil }; tmp2 = tmp3; if !tmp2 { tmp2 = variant == nil }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NullPointerException_New())) }
	if extensions == nil {
		extensions = Locale_GetCompatibilityExtensions_String_String_String_String__LocaleExtensions(language, script, country, variant) }
	var baseloc *BaseLocale = BaseLocale_GetInstance_String_String_String_String__BaseLocale(Locale_ConvertOldISOCodes_String__String(language), script, country, variant)



	return Locale_GetInstance_BaseLocale_LocaleExtensions__Locale(baseloc, extensions)
}
func Locale_GetInstance_BaseLocale_LocaleExtensions__Locale(baseloc *BaseLocale, extensions *LocaleExtensions) *Locale { Locale_Init()
	if extensions == nil {
		var locale *Locale = Locale_Cast(Locale_CONSTANT_LOCALES.Get_O__O(baseloc.Ref()))
		if !(locale == nil) { return locale } else {

			return Locale_Cast(NN(ReferencedKeyMap_Cast(Locale_LOCALE_CACHE.Get__O())).ComputeIfAbsent_O_Function__O(baseloc.Ref(), Locale_LOCALE_CREATOR)) } } else {



				var key *Locale_LocaleKey = Locale_LocaleKey_New_BaseLocale_LocaleExtensions(baseloc, extensions)
				return Locale_Cast(NN(ReferencedKeyMap_Cast(Locale_LOCALE_CACHE.Get__O())).ComputeIfAbsent_O_Function__O(key.Ref(), Locale_LOCALE_CREATOR))
			}
}



func (t *Locale_1) Get__ReferencedKeyMap() *ReferencedKeyMap {
	return ReferencedKeyMap_Create_Z_Supplier__ReferencedKeyMap(true, ReferencedKeyMap_ConcurrentHashMapSupplier__Supplier())
}


func (t *Locale_2) Apply_O__Locale(key any) *Locale {
	var tmp1 any = key; if BaseLocale_InstanceOf(tmp1) { var base *BaseLocale = BaseLocale_Cast(tmp1)
		return Locale_New_BaseLocale_LocaleExtensions(base, nil) } else {
			var lk *Locale_LocaleKey = Locale_LocaleKey_Cast(key); var tmp2 *BaseLocale = lk.F_base; return Locale_New_BaseLocale_LocaleExtensions(tmp2, lk.F_exts)
		}
}






func Locale_LocaleKey_New_BaseLocale_LocaleExtensions(p0 *BaseLocale, p1 *LocaleExtensions) *Locale_LocaleKey { t := &Locale_LocaleKey{}; t.Ctor_BaseLocale_LocaleExtensions(p0, p1); return t }
//line :202:1
func (t *Locale_LocaleKey) Ctor_BaseLocale_LocaleExtensions(baseLocale *BaseLocale, extensions *LocaleExtensions) {
	t.F_base = baseLocale
	t.F_exts = extensions
	var h int32 = NN(t.F_base).HashCode__I()
	if !(t.F_exts == nil) { h = h ^ NN(t.F_exts).HashCode__I() }
	t.F_hash = h
}
func (t *Locale_LocaleKey) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if Locale_LocaleKey_InstanceOf(tmp1) { var other *Locale_LocaleKey = Locale_LocaleKey_Cast(tmp1); var tmp2 bool; var tmp3 bool; var tmp4 int32 = t.F_hash

			tmp3 = !(tmp4 == other.F_hash); if !tmp3 { var tmp5 *BaseLocale = t.F_base; tmp3 = !NN(tmp5).Equals_O__Z(other.F_base.Ref()) }; tmp2 = tmp3
//line :213:1
			if tmp2 { return false } else { if t.F_exts == nil {

				return other.F_exts == nil } else {
					var tmp6 *LocaleExtensions = t.F_exts; return NN(tmp6).Equals_O__Z(other.F_exts.Ref()) } } } else {
//line :212:1
						return false
					}
	}
}



func (t *Locale_LocaleKey) HashCode__I() int32 { return t.F_hash }

func Locale_GetDefault__Locale() *Locale { Locale_Init(); return Locale_defaultLocale.Load() }

func Locale_GetDefault_Locale_Category__Locale(category *Locale_Category) *Locale { Locale_Init()
	Objects_RequireNonNull_O__O(category.Ref())
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; if category == tmp1 {
		var loc *Locale = Locale_defaultDisplayLocale.Load()
		if loc == nil { loc = Locale_GetDisplayLocale__Locale() }
//line :226:1
		return loc } else {



			var tmp2 *Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_FORMAT; if !A2g_AssertionsDisabled && !(category == tmp2) { panic(Thrown(AssertionError_New_O(Lit_2739))) }
			var loc_2 *Locale = Locale_defaultFormatLocale.Load()
			if loc_2 == nil { loc_2 = Locale_GetFormatLocale__Locale() }
//line :231:1
			return loc_2
		}
}

func Locale_GetDisplayLocale__Locale() *Locale { Locale_Init(); MonitorEnter(Locale_class); defer MonitorExit(Locale_class)
	var loc *Locale = Locale_defaultDisplayLocale.Load()
	if loc == nil { var tmp1 *Locale; var tmp2 *Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_DISPLAY; var tmp3 *Locale = Locale_InitDefault_Locale_Category__Locale(tmp2); Locale_defaultDisplayLocale.Store(tmp3); tmp1 = tmp3; loc = tmp1 }
//line :236:1
	return loc
}


func Locale_GetFormatLocale__Locale() *Locale { Locale_Init(); MonitorEnter(Locale_class); defer MonitorExit(Locale_class)
	var loc *Locale = Locale_defaultFormatLocale.Load()
	if loc == nil { var tmp1 *Locale; var tmp2 *Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_FORMAT; var tmp3 *Locale = Locale_InitDefault_Locale_Category__Locale(tmp2); Locale_defaultFormatLocale.Store(tmp3); tmp1 = tmp3; loc = tmp1 }
//line :241:1
	return loc
}


func Locale_InitDefault__Locale() *Locale { Locale_Init()
	var tmp1 *String; StaticProperty_Init(); tmp1 = StaticProperty_USER_LANGUAGE; var tmp2 *String = tmp1; var tmp3 *String; StaticProperty_Init(); tmp3 = StaticProperty_USER_SCRIPT; var tmp4 *String = tmp3; var tmp5 *String; StaticProperty_Init(); tmp5 = StaticProperty_USER_COUNTRY; var tmp6 *String = tmp5; var tmp7 *String; StaticProperty_Init(); tmp7 = StaticProperty_USER_VARIANT; var tmp8 *String = tmp7; var tmp9 *String; StaticProperty_Init(); tmp9 = StaticProperty_USER_EXTENSIONS; return Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(tmp2, tmp4, tmp6, tmp8, LocaleExtensions_Cast(NN(Locale_GetDefaultExtensions_String__Optional(tmp9)).OrElse_O__O(nil)))
}






func Locale_InitDefault_Locale_Category__Locale(category *Locale_Category) *Locale { Locale_Init()
	var locale *Locale = Locale_defaultLocale.Load(); var tmp1 *String; var tmp2 *Locale_Category

	Locale_Category_Init(); tmp2 = Locale_Category_DISPLAY; if category == tmp2 { StaticProperty_Init(); tmp1 = StaticProperty_USER_LANGUAGE_DISPLAY } else { StaticProperty_Init(); tmp1 = StaticProperty_USER_LANGUAGE_FORMAT }
//line :256:1
	var tmp3 *String = tmp1; var tmp4 *String; var tmp5 *Locale_Category



	Locale_Category_Init(); tmp5 = Locale_Category_DISPLAY; if category == tmp5 { StaticProperty_Init(); tmp4 = StaticProperty_USER_SCRIPT_DISPLAY } else { StaticProperty_Init(); tmp4 = StaticProperty_USER_SCRIPT_FORMAT }
//line :256:1
	var tmp6 *String = tmp4; var tmp7 *String; var tmp8 *Locale_Category






	Locale_Category_Init(); tmp8 = Locale_Category_DISPLAY; if category == tmp8 { StaticProperty_Init(); tmp7 = StaticProperty_USER_COUNTRY_DISPLAY } else { StaticProperty_Init(); tmp7 = StaticProperty_USER_COUNTRY_FORMAT }
//line :256:1
	var tmp9 *String = tmp7; var tmp10 *String; var tmp11 *Locale_Category









	Locale_Category_Init(); tmp11 = Locale_Category_DISPLAY; if category == tmp11 { StaticProperty_Init(); tmp10 = StaticProperty_USER_VARIANT_DISPLAY } else { StaticProperty_Init(); tmp10 = StaticProperty_USER_VARIANT_FORMAT }
//line :256:1
	var tmp12 *String = tmp10; var tmp13 *String; var tmp14 *Locale_Category














	Locale_Category_Init(); tmp14 = Locale_Category_DISPLAY; if category == tmp14 { StaticProperty_Init(); tmp13 = StaticProperty_USER_EXTENSIONS_DISPLAY } else { StaticProperty_Init(); tmp13 = StaticProperty_USER_EXTENSIONS_FORMAT }
//line :256:1
	return Locale_GetInstance_String_String_String_String_LocaleExtensions__Locale(tmp3, tmp6, tmp9, tmp12, LocaleExtensions_Cast(NN(Locale_GetDefaultExtensions_String__Optional(tmp13)).OrElse_O__O(NN(locale).GetLocaleExtensions__LocaleExtensions().Ref())))
}


















func Locale_GetDefaultExtensions_String__Optional(extensionsProp *String) *Optional { Locale_Init()
	if LocaleUtils_IsEmpty_String__Z(extensionsProp) {
		return Optional_Empty__Optional() } else {
			var exts *LocaleExtensions; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

				exts = NN(InternalLocaleBuilder_New().SetExtensions_String__InternalLocaleBuilder(extensionsProp)).GetLocaleExtensions__LocaleExtensions(); return nil }()
//line :280:1
			if tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1); _ = e } else { panic(tmp1)
			}
			}

			return Optional_OfNullable_O__Optional(exts.Ref())
		} }
func Locale_SetDefault_Locale__V(newLocale *Locale) { Locale_Init(); MonitorEnter(Locale_class); defer MonitorExit(Locale_class)
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; Locale_SetDefault_Locale_Category_Locale__V(tmp1, newLocale)
	var tmp2 *Locale_Category; Locale_Category_Init(); tmp2 = Locale_Category_FORMAT; Locale_SetDefault_Locale_Category_Locale__V(tmp2, newLocale)
	Locale_defaultLocale.Store(newLocale)
}
func Locale_SetDefault_Locale_Category_Locale__V(category *Locale_Category, newLocale *Locale) { Locale_Init(); MonitorEnter(Locale_class); defer MonitorExit(Locale_class)
	if category == nil { panic(Thrown(NullPointerException_New_String(Lit_2740))) }
	if newLocale == nil { panic(Thrown(NullPointerException_New_String(Lit_2741))) }
	switch NN(category).F_ordinal { case 0:
		Locale_defaultDisplayLocale.Store(newLocale); case 1:
		Locale_defaultFormatLocale.Store(newLocale); default:
		if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New_O(Lit_2742)))
		}} }
func Locale_GetAvailableLocales__Locale1() *RefArray { Locale_Init()
	return LocaleServiceProviderPool_GetAllAvailableLocales__Locale1()
}
func Locale_AvailableLocales__Stream() Stream { Locale_Init()
	return LocaleServiceProviderPool_StreamAllAvailableLocales__Stream()
}
func Locale_GetISOCountries__String1() *RefArray { Locale_Init()
	var countries *RefArray; var tmp1 LazyConstant; LocaleISOData_Init(); tmp1 = LocaleISOData_ISO_3166_1_ALPHA2; countries = A2g_CastArray[*RefArray](tmp1.Get__O(), String_class.ArrayClass())
	return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(countries, int32(len(countries.A))).Ref(), String_class.ArrayClass())
}
func Locale_GetISOCountries_Locale_IsoCountryCode__Set(type_ *Locale_IsoCountryCode) Set { Locale_Init()
	Objects_RequireNonNull_O__O(type_.Ref())
	switch NN(type_).F_ordinal { case 0:
		var tmp1 LazyConstant; LocaleISOData_Init(); tmp1 = LocaleISOData_ISO_3166_1_ALPHA2; return Set_Of_O1__Set(A2g_CastArray[*RefArray](tmp1.Get__O(), String_class.ArrayClass())); case 1:
		var tmp2 LazyConstant; LocaleISOData_Init(); tmp2 = LocaleISOData_ISO_3166_1_ALPHA3; return Set_Cast(tmp2.Get__O()); case 2:
		var tmp3 LazyConstant; LocaleISOData_Init(); tmp3 = LocaleISOData_ISO_3166_3; return Set_Cast(tmp3.Get__O()); default:
		panic(Thrown(MatchException_New_String_Throwable(nil, nil)))}; panic("a2g: unreachable")
}
func Locale_GetISOLanguages__String1() *RefArray { Locale_Init()
	var languages *RefArray; var tmp1 LazyConstant; LocaleISOData_Init(); tmp1 = LocaleISOData_ISO_639; languages = A2g_CastArray[*RefArray](tmp1.Get__O(), String_class.ArrayClass())
	return A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(languages, int32(len(languages.A))).Ref(), String_class.ArrayClass())
}
func (t *Locale) GetLanguage__String() *String { return NN(t.F_baseLocale).GetLanguage__String() }

func (t *Locale) GetScript__String() *String { return NN(t.F_baseLocale).GetScript__String() }

func (t *Locale) GetCountry__String() *String { return NN(t.F_baseLocale).GetRegion__String() }

func (t *Locale) GetVariant__String() *String { return NN(t.F_baseLocale).GetVariant__String() }

func (t *Locale) HasExtensions__Z() bool { return !(t.F_localeExtensions == nil) }

func (t *Locale) StripExtensions__Locale() *Locale {
	if t.HasExtensions__Z() { return Locale_GetInstance_BaseLocale_LocaleExtensions__Locale(t.F_baseLocale, nil) } else { return t
	} }
func (t *Locale) GetExtension_C__String(key uint16) *String {
	if LocaleExtensions_IsValidKey_C__Z(key) { } else {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2743, StrOfChar(key))))) }
	if t.HasExtensions__Z() { return NN(t.F_localeExtensions).GetExtensionValue_Character__String(Character_ValueOf_C__Character(key)) } else { return nil
	} }
func (t *Locale) GetExtensionKeys__Set() Set {
	if !t.HasExtensions__Z() { return Collections_EmptySet__Set() } else { return NN(t.F_localeExtensions).GetKeys__Set()
	} }
func (t *Locale) GetUnicodeLocaleAttributes__Set() Set {
	if !t.HasExtensions__Z() {
		return Collections_EmptySet__Set() } else {
			return NN(t.F_localeExtensions).GetUnicodeLocaleAttributes__Set()
		} }
func (t *Locale) GetUnicodeLocaleType_String__String(key *String) *String {
	if Locale_IsUnicodeExtensionKey_String__Z(key) { } else {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2744, key)))) }
	if t.HasExtensions__Z() { return NN(t.F_localeExtensions).GetUnicodeLocaleType_String__String(key) } else { return nil
	} }
func (t *Locale) GetUnicodeLocaleKeys__Set() Set {
	if t.F_localeExtensions == nil { return Collections_EmptySet__Set() } else { return NN(t.F_localeExtensions).GetUnicodeLocaleKeys__Set()
	} }
func (t *Locale) GetBaseLocale__BaseLocale() *BaseLocale { return t.F_baseLocale }

func (t *Locale) GetLocaleExtensions__LocaleExtensions() *LocaleExtensions { return t.F_localeExtensions }

func (t *Locale) ToString__String() *String {
	var l bool = !NN(NN(t.F_baseLocale).GetLanguage__String()).IsEmpty__Z(); var s bool = !NN(NN(t.F_baseLocale).GetScript__String()).IsEmpty__Z(); var r bool = !NN(NN(t.F_baseLocale).GetRegion__String()).IsEmpty__Z(); var v bool = !NN(NN(t.F_baseLocale).GetVariant__String()).IsEmpty__Z(); var e bool; var tmp1 bool



	tmp1 = !(t.F_localeExtensions == nil); if tmp1 { tmp1 = !NN(NN(t.F_localeExtensions).GetID__String()).IsEmpty__Z() }; e = tmp1
//line :360:1
	var result *StringBuilder = StringBuilder_New_String(NN(t.F_baseLocale).GetLanguage__String()); var tmp2 bool; var tmp3 bool





	tmp3 = r; if !tmp3 { var tmp4 bool; tmp4 = l; if tmp4 { var tmp5 bool; var tmp6 bool; tmp6 = v; if !tmp6 { tmp6 = s }; tmp5 = tmp6; if !tmp5 { tmp5 = e }; tmp4 = tmp5 }; tmp3 = tmp4 }; tmp2 = tmp3; if tmp2 { NN(NN(result).Append_C__StringBuilder(95)).Append_String__StringBuilder(NN(t.F_baseLocale).GetRegion__String()) }
	var tmp7 bool; var tmp8 bool; tmp8 = v; if tmp8 { var tmp9 bool; tmp9 = l; if !tmp9 { tmp9 = r }; tmp8 = tmp9 }; tmp7 = tmp8; if tmp7 { NN(NN(result).Append_C__StringBuilder(95)).Append_String__StringBuilder(NN(t.F_baseLocale).GetVariant__String()) }
	var tmp10 bool; var tmp11 bool; tmp11 = s; if tmp11 { var tmp12 bool; tmp12 = l; if !tmp12 { tmp12 = r }; tmp11 = tmp12 }; tmp10 = tmp11; if tmp10 { NN(NN(result).Append_String__StringBuilder(Lit_2745)).Append_String__StringBuilder(NN(t.F_baseLocale).GetScript__String()) }
	var tmp13 bool; var tmp14 bool; tmp14 = e; if tmp14 { var tmp15 bool; tmp15 = l; if !tmp15 { tmp15 = r }; tmp14 = tmp15 }; tmp13 = tmp14; if tmp13 {
		NN(result).Append_C__StringBuilder(95)
		if s { } else { NN(result).Append_C__StringBuilder(35) }
		NN(result).Append_String__StringBuilder(NN(t.F_localeExtensions).GetID__String()) }
	return NN(result).ToString__String()
}
func (t *Locale) ToLanguageTag__String() *String {
	return String_Cast(t.F_languageTag.Get__O())
}
func (t *Locale) ComputeLanguageTag__String() *String {
	var tag *LanguageTag = LanguageTag_ParseLocale_BaseLocale_LocaleExtensions__LanguageTag(t.F_baseLocale, t.F_localeExtensions); var bldr *StringBuilder = StringBuilder_New(); var subtag *String = NN(tag).Language__String()


	if NN(subtag).IsEmpty__Z() { } else { NN(bldr).Append_String__StringBuilder(LanguageTag_CanonicalizeLanguage_String__String(subtag)) }
	subtag = NN(tag).Script__String()
	if NN(subtag).IsEmpty__Z() { } else {
		NN(bldr).Append_String__StringBuilder(Lit_1134)
		NN(bldr).Append_String__StringBuilder(LanguageTag_CanonicalizeScript_String__String(subtag)) }
	subtag = NN(tag).Region__String()
	if NN(subtag).IsEmpty__Z() { } else {
		NN(bldr).Append_String__StringBuilder(Lit_1134)
		NN(bldr).Append_String__StringBuilder(LanguageTag_CanonicalizeRegion_String__String(subtag)) }
	var subtags List = NN(tag).Variants__List(); var i_101955 Iterator = subtags.Iterator__Iterator(); for i_101955.HasNext__Z() {
		var s *String = String_Cast(i_101955.Next__O()); NN(bldr).Append_String__StringBuilder(Lit_1134); NN(bldr).Append_String__StringBuilder(s) }
	subtags = NN(tag).Extensions__List()
	var i_101956 Iterator = subtags.Iterator__Iterator(); for i_101956.HasNext__Z() { var s_2 *String = String_Cast(i_101956.Next__O())
		NN(bldr).Append_String__StringBuilder(Lit_1134)
		NN(bldr).Append_String__StringBuilder(LanguageTag_CanonicalizeExtension_String__String(s_2)) }
	subtag = NN(tag).Privateuse__String()
	if NN(subtag).IsEmpty__Z() { } else {
		if NN(bldr).Length__I() > 0 { NN(bldr).Append_String__StringBuilder(Lit_1134) }
		NN(NN(bldr).Append_String__StringBuilder(Lit_2746)).Append_String__StringBuilder(Lit_1134)
		NN(bldr).Append_String__StringBuilder(subtag) }
	return NN(bldr).ToString__String()
}
func Locale_CaseFoldLanguageTag_String__String(languageTag *String) *String { Locale_Init()
	return LanguageTag_CaseFoldTag_String__String(languageTag)
}
func Locale_ForLanguageTag_String__Locale(languageTag *String) *Locale { Locale_Init()
	var tag *LanguageTag = LanguageTag_Parse_String_ParsePosition_Z__LanguageTag(languageTag, ParsePosition_New_I(0), true); var bldr *InternalLocaleBuilder = InternalLocaleBuilder_New()

	NN(bldr).SetLanguageTag_LanguageTag__InternalLocaleBuilder(tag)
	var base *BaseLocale = NN(bldr).GetBaseLocale__BaseLocale(); var exts *LocaleExtensions = NN(bldr).GetLocaleExtensions__LocaleExtensions(); var tmp1 bool; var tmp2 bool

	tmp2 = exts == nil; if tmp2 { tmp2 = !NN(NN(base).GetVariant__String()).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		exts = Locale_GetCompatibilityExtensions_String_String_String_String__LocaleExtensions(NN(base).GetLanguage__String(), NN(base).GetScript__String(), NN(base).GetRegion__String(), NN(base).GetVariant__String())
	}




	return Locale_GetInstance_BaseLocale_LocaleExtensions__Locale(base, exts)
}
func (t *Locale) GetISO3Language__String() *String {
	var lang_ *String = NN(t.F_baseLocale).GetLanguage__String()
	if NN(lang_).Length__I() == 3 { return lang_ } else {

		var language3 *String = LocaleISOData_GetISO3LangCode_String__String(lang_)
		if language3 == nil {
			panic(Thrown(MissingResourceException_New_String_String_String(Concat(Lit_2747, lang_), Concat(Lit_2748, t.ToString__String()), Lit_2749))) }
//line :426:1
		return language3
	}
}





func (t *Locale) GetISO3Country__String() *String {
	var country3 *String = LocaleISOData_GetISO3CtryCode_String__String(NN(t.F_baseLocale).GetRegion__String())
	if country3 == nil {
		panic(Thrown(MissingResourceException_New_String_String_String(Concat(Lit_2750, NN(t.F_baseLocale).GetRegion__String()), Concat(Lit_2748, t.ToString__String()), Lit_2751))) }
//line :435:1
	return country3
}






func (t *Locale) GetDisplayLanguage__String() *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return t.GetDisplayLanguage_Locale__String(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *Locale) GetDisplayLanguage_Locale__String(inLocale *Locale) *String {
	return t.GetDisplayString_String_String_Locale_I__String(NN(t.F_baseLocale).GetLanguage__String(), nil, inLocale, 0)
}
func (t *Locale) GetDisplayScript__String() *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return t.GetDisplayScript_Locale__String(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *Locale) GetDisplayScript_Locale__String(inLocale *Locale) *String {
	return t.GetDisplayString_String_String_Locale_I__String(NN(t.F_baseLocale).GetScript__String(), nil, inLocale, 3)
}
func (t *Locale) GetDisplayCountry__String() *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return t.GetDisplayCountry_Locale__String(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *Locale) GetDisplayCountry_Locale__String(inLocale *Locale) *String {
	return t.GetDisplayString_String_String_Locale_I__String(NN(t.F_baseLocale).GetRegion__String(), nil, inLocale, 1)
}
func (t *Locale) GetDisplayString_String_String_Locale_I__String(code, cat *String, inLocale *Locale, type_ int32) *String {

	Objects_RequireNonNull_O__O(inLocale.Ref())
	Objects_RequireNonNull_O__O(code.Ref())
	if NN(code).IsEmpty__Z() { return Lit_69 } else {

		var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(LocaleNameProvider_class); var rbKey *String
		if type_ == 2 { rbKey = Concat(Lit_2752, code) } else { rbKey = code }
//line :467:1
		var result *String; var tmp1 *Locale_LocaleNameGetter

		Locale_LocaleNameGetter_Init(); tmp1 = Locale_LocaleNameGetter_INSTANCE; var tmp2 LocaleServiceProviderPool_LocalizedObjectGetter = Up_Locale_LocaleNameGetter_LocaleServiceProviderPool_LocalizedObjectGetter(tmp1); result = String_Cast(NN(pool).GetLocalizedObject_LocaleServiceProviderPool_LocalizedObjectGetter_Locale_String_O1__O(tmp2, inLocale, rbKey, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(type_), code.Ref(), cat.Ref())))





		if !(result == nil) { return result } else { return code
		} } }
func (t *Locale) GetDisplayVariant__String() *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return t.GetDisplayVariant_Locale__String(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *Locale) GetDisplayVariant_Locale__String(inLocale *Locale) *String {
	if NN(NN(t.F_baseLocale).GetVariant__String()).IsEmpty__Z() { return Lit_69 } else {

		var lr *LocaleResources = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(inLocale); var names *RefArray = t.GetDisplayVariantArray_Locale__String1(inLocale)

		return Locale_FormatList_String1_String__String(names, NN(lr).GetLocaleName_String__String(Lit_2753))
	} }
func (t *Locale) GetDisplayName__String() *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return t.GetDisplayName_Locale__String(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *Locale) GetDisplayName_Locale__String(inLocale *Locale) *String {
	var lr *LocaleResources = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(inLocale); var languageName *String = t.GetDisplayLanguage_Locale__String(inLocale); var scriptName *String = t.GetDisplayScript_Locale__String(inLocale); var countryName *String = t.GetDisplayCountry_Locale__String(inLocale); var variantNames *RefArray = t.GetDisplayVariantArray_Locale__String1(inLocale); var displayNamePattern *String = NN(lr).GetLocaleName_String__String(Lit_2754); var listCompositionPattern *String = NN(lr).GetLocaleName_String__String(Lit_2753); var mainName *String; var qualifierNames *RefArray; var tmp1 bool; var tmp2 bool; var tmp3 bool








	tmp3 = NN(languageName).IsEmpty__Z(); if tmp3 { tmp3 = NN(scriptName).IsEmpty__Z() }; tmp2 = tmp3; if tmp2 { tmp2 = NN(countryName).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		if int32(len(variantNames.A)) == 0 { return Lit_69 } else {

			return Locale_FormatList_String1_String__String(variantNames, listCompositionPattern) } } else {
				var names *ArrayList = ArrayList_New_I(4)
				if NN(languageName).IsEmpty__Z() { } else { NN(names).Add_O__Z(languageName.Ref()) }
				if NN(scriptName).IsEmpty__Z() { } else { NN(names).Add_O__Z(scriptName.Ref()) }
				if NN(countryName).IsEmpty__Z() { } else { NN(names).Add_O__Z(countryName.Ref()) }
				if int32(len(variantNames.A)) == 0 { } else { NN(names).AddAll_Collection__Z(Arrays_AsList_O1__List(variantNames)) }
				if !(t.F_localeExtensions == nil) {
					var tmp4 Stream = NN(t.F_localeExtensions).GetUnicodeLocaleAttributes__Set().Stream__Stream().Map_Function__Stream(&Function_Fn{Fn: func(p0 any) any { var key *String = String_Cast(p0); return t.GetDisplayString_String_String_Locale_I__String(key, nil, inLocale, 4).Ref() }}); var tmp5 Consumer; var tmp6 *ArrayList = NN(names)


					tmp5 = &Consumer_Fn{Fn: func(p0_2 any) { tmp6.Add_O__Z(p0_2) }}
//line :510:1
					tmp4.ForEach_Consumer__V(tmp5)



					var tmp7 Stream = NN(t.F_localeExtensions).GetUnicodeLocaleKeys__Set().Stream__Stream().Map_Function__Stream(&Function_Fn{Fn: func(p0_3 any) any { var key_2 *String = String_Cast(p0_3); return t.GetDisplayKeyTypeExtensionString_String_LocaleResources_Locale__String(key_2, lr, inLocale).Ref() }}); var tmp8 Consumer; var tmp9 *ArrayList = NN(names)


					tmp8 = &Consumer_Fn{Fn: func(p0_4 any) { tmp9.Add_O__Z(p0_4) }}
//line :514:1
					tmp7.ForEach_Consumer__V(tmp8)
				}


				mainName = String_Cast(NN(names).Get_I__O(0))
				var numNames int32 = NN(names).Size__I(); var tmp10 *RefArray

				if numNames > 1 {
					tmp10 = A2g_CastArray[*RefArray](NN(names).SubList_I_I__List(1, numNames).ToArray_O1__O1(NewRefArray(String_class, numNames-1)).Ref(), String_class.ArrayClass()) } else {


						tmp10 = NewRefArray(String_class, 0) }
//line :520:1
				qualifierNames = tmp10





				var displayNames *RefArray; var tmp11 int32

				if !(int32(len(qualifierNames.A)) == 0) { tmp11 = 2 } else { tmp11 = 1 }
//line :526:1
				var tmp12 any = Integer_ValueOf_I__Integer(tmp11).Ref(); var tmp13 any = mainName.Ref(); var tmp14 any



				if int32(len(qualifierNames.A)) == 0 { tmp14 = nil } else {
					tmp14 = Locale_FormatList_String1_String__String(qualifierNames, listCompositionPattern).Ref() }
//line :526:1
				displayNames = RefArrayOf(Object_class, tmp12, tmp13, tmp14)







				if !(displayNamePattern == nil) {
					return MessageFormat_New_String(displayNamePattern).Format_O__String(displayNames.Ref()) } else {
						var result *StringBuilder = StringBuilder_New_String(String_Cast(displayNames.A[1]))
						if !(displayNames.A[2] == nil) {
							NN(NN(NN(result).Append_String__StringBuilder(Lit_1499)).Append_String__StringBuilder(String_Cast(displayNames.A[2]))).Append_C__StringBuilder(41)
						}
						return NN(result).ToString__String()
					} } }
func (t *Locale) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var that *Locale = Locale_Cast(A2g_ObjectClone(t)); tmp1 = that.Ref() }; return nil }()
//line :543:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :543:1
			panic(tmp2) } }; return tmp1
}


func (t *Locale) HashCode__I() int32 {
	var hc int32 = t.F_hashCodeValue
	if hc == 0 {
		hc = NN(t.F_baseLocale).HashCode__I()
		if !(t.F_localeExtensions == nil) { hc = hc ^ NN(t.F_localeExtensions).HashCode__I() }
		t.F_hashCodeValue = hc }
//line :548:1
	return hc
}





func (t *Locale) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if !Locale_InstanceOf(obj) { return false } else {



		var otherBase *BaseLocale = Locale_Cast(obj).F_baseLocale
		if !NN(t.F_baseLocale).Equals_O__Z(otherBase.Ref()) { return false } else { if t.F_localeExtensions == nil {

			return Locale_Cast(obj).F_localeExtensions == nil } else {
				var tmp1 *LocaleExtensions = t.F_localeExtensions; return NN(tmp1).Equals_O__Z(Locale_Cast(obj).F_localeExtensions.Ref())
			}
		}
	}
	}
}











func (t *Locale_3) Get__String() *String { return NN(t.F_this_0).ComputeLanguageTag__String() }

func (t *Locale) GetDisplayVariantArray_Locale__String1(inLocale *Locale) *RefArray {
	var tokenizer *StringTokenizer = StringTokenizer_New_String_String(NN(t.F_baseLocale).GetVariant__String(), Lit_2755); var names *RefArray = NewRefArray(String_class, NN(tokenizer).CountTokens__I())
	var i int32 = 0
L1: for {
	if i < int32(len(names.A)) {
		names.Store(i, t.GetDisplayString_String_String_Locale_I__String(NN(tokenizer).NextToken__String(), nil, inLocale, 2).Ref())


		i = i + 1; continue L1 }
//line :586:1
	break L1 }
//line :584:1
	return names
}








func (t *Locale) GetDisplayKeyTypeExtensionString_String_LocaleResources_Locale__String(key *String, lr *LocaleResources, inLocale *Locale) *String {

	var type_ *String = NN(t.F_localeExtensions).GetUnicodeLocaleType_String__String(key); var ret *String = t.GetDisplayString_String_String_Locale_I__String(type_, key, inLocale, 5); var tmp1 bool; var tmp2 bool

	tmp2 = ret == nil; if !tmp2 { tmp2 = NN(ret).Equals_O__Z(type_.Ref()) }; tmp1 = tmp2; if tmp1 {
		var tmp3 *String = NN(lr).GetLocaleName_String__String(Lit_2756); var tmp4 any = t.GetDisplayString_String_String_Locale_I__String(key, nil, inLocale, 4).Ref(); var tmp5 any
		var tmp6 /*line :599:1*/*String = key
		var tmp7 int32 = -1


		switch NN(tmp6).HashCode__I() { case 3186: if tmp6.Equals_O__Z(Lit_2654) { tmp7 = 0 }; case 3637: if tmp6.Equals_O__Z(Lit_2757) { tmp7 = 1 }; case 3718: if tmp6.Equals_O__Z(Lit_2234) { tmp7 = 2 }}; switch tmp7 { case 0:

			var cname *String = NN(lr).GetCurrencyName_String__String(NN(type_).ToLowerCase_Locale__String(Locale_ROOT))


			if !(cname == nil) { tmp5 = cname.Ref() } else { tmp5 = type_.Ref() }; case 1:

			var tmp8 bool; var tmp9 bool
			tmp9 = !(type_ == nil)
//line :610:1
			if tmp9 {

				tmp9 = NN(type_).Matches_String__Z(Lit_2758) }
//line :610:1
			tmp8 = tmp9; if tmp8 {


				tmp5 = NN(lr).GetLocaleName_String__String(NN(NN(type_).Substring_I_I__String(0, 2)).ToUpperCase_Locale__String(Locale_ROOT)).Ref() } else {
//line :610:1
					tmp5 = type_.Ref() }
		case 2:








			tmp5 = NN(NN(TimeZoneNameUtility_ConvertLDMLShortID_String__Optional(type_)).Map_Function__Optional(&Function_Fn{Fn: func(p0 any) any { var id *String = String_Cast(p0); return TimeZoneNameUtility_RetrieveGenericDisplayName_String_I_Locale__String(id, 1, inLocale).Ref() }})).OrElse_O__O(type_.Ref()); default:
//line :603:1
			tmp5 = type_.Ref()}
//line :599:1
		ret = MessageFormat_Format_String_O1__String(tmp3, RefArrayOf(Object_class, tmp4, tmp5)) }
//line :596:1
	return ret
}


































func Locale_FormatList_String1_String__String(stringList *RefArray, pattern *String) *String { Locale_Init()
	if pattern == nil {
		return String_Join_CharSequence_CharSequence1__String(Lit_1532, stringList) } else {
			switch int32(len(stringList.A)) { case 0: return Lit_69; case 1:

				return As[*String](stringList.A[0]); default:
				return String_Cast(Arrays_Stream_O1__Stream(stringList).Reduce_O_BinaryOperator__O(Lit_69, &BinaryOperator_Fn{Fn: func(p0, p1 any) any { var s1 *String = String_Cast(p0); var s2 *String = String_Cast(p1); var tmp1 *String; if



					NN(s1).IsEmpty__Z() { tmp1 = s2 } else { if NN(s2).IsEmpty__Z() { tmp1 = s1 } else {


						tmp1 = MessageFormat_Format_String_O1__String(pattern, RefArrayOf(Object_class, s1.Ref(), s2.Ref())) } }; return /*line :638:1*/ tmp1.Ref() }}))
			}
		}




	panic("a2g: unreachable")
}
func Locale_IsUnicodeExtensionKey_String__Z(s *String) bool { Locale_Init()
	var tmp1 bool; tmp1 = NN(s).Length__I() == 2; if tmp1 { tmp1 = LocaleUtils_IsAlphaNumericString_String__Z(s) }; return tmp1
}





































func (t *Locale) ReadResolve__O() any { panic(A2g_NotTranslated("java.util.Locale.readResolve()Ljava/lang/Object;")) }






func Locale_ConvertOldISOCodes_String__String(language *String) *String { Locale_Init()
	return BaseLocale_ConvertOldISOCodes_String__String(NN(LocaleUtils_ToLowerString_String__String(language)).Intern__String())
}
func Locale_GetCompatibilityExtensions_String_String_String_String__LocaleExtensions(language, script, country, variant *String) *LocaleExtensions { Locale_Init()



	var extensions *LocaleExtensions; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool

	tmp4 = LocaleUtils_CaseIgnoreMatch_String_String__Z(language, Lit_2759); if tmp4 { tmp4 = NN(script).IsEmpty__Z() }; tmp3 = tmp4; if tmp3 {
		tmp3 = LocaleUtils_CaseIgnoreMatch_String_String__Z(country, Lit_2760) }
//line :703:1
	tmp2 = tmp3; if tmp2 {

		tmp2 = Lit_2761.Equals_O__Z(variant.Ref()) }
//line :703:1
	tmp1 = tmp2
//line :702:1
	if tmp1 {



		var tmp5 *LocaleExtensions; LocaleExtensions_Init(); tmp5 = LocaleExtensions_CALENDAR_JAPANESE; extensions = tmp5 } else {
//line :702:1
			var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool




			tmp9 = LocaleUtils_CaseIgnoreMatch_String_String__Z(language, Lit_2762); if tmp9 { tmp9 = NN(script).IsEmpty__Z() }; tmp8 = tmp9; if tmp8 {
				tmp8 = LocaleUtils_CaseIgnoreMatch_String_String__Z(country, Lit_2762) }
//line :707:1
			tmp7 = tmp8; if tmp7 {

				tmp7 = Lit_2763.Equals_O__Z(variant.Ref()) }
//line :707:1
			tmp6 = tmp7
//line :702:1
			if tmp6 {







				var tmp10 *LocaleExtensions; LocaleExtensions_Init(); tmp10 = LocaleExtensions_NUMBER_THAI; extensions = tmp10 } }
//line :701:1
	return extensions
}















func (t *Locale_LocaleNameGetter) GetObject_LocaleNameProvider_Locale_String_O1__String(localeNameProvider LocaleNameProvider_I, locale *Locale, key *String, params *RefArray) *String {

	if !A2g_AssertionsDisabled && !(int32(len(params.A)) == 3) { panic(Thrown(AssertionError_New())) }
	var type_ int32 = NN(Integer_Cast(params.A[0])).IntValue__I(); var code *String = String_Cast(params.A[1]); var cat *String = String_Cast(params.A[2])


	switch type_ { case 0:
		return localeNameProvider.GetDisplayLanguage_String_Locale__String(code, locale); case 1:
		return localeNameProvider.GetDisplayCountry_String_Locale__String(code, locale); case 2:
		return localeNameProvider.GetDisplayVariant_String_Locale__String(code, locale); case 3:
		return localeNameProvider.GetDisplayScript_String_Locale__String(code, locale); case 4:
		return localeNameProvider.GetDisplayUnicodeExtensionKey_String_Locale__String(code, locale); case 5:

		return localeNameProvider.GetDisplayUnicodeExtensionType_String_String_Locale__String(code, cat, locale); default:
		if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New())) }}
//line :721:1
	return nil
}



















func Locale_Category_New_String_I_String_String_String_String_String(p0 *String, p1 int32, p2, p3, p4, p5, p6 *String) *Locale_Category { Locale_Category_Init(); t := &Locale_Category{}; t.Ctor_String_I_String_String_String_String_String(p0, p1, p2, p3, p4, p5, p6); return t }
//line :742:1
func (t *Locale_Category) Ctor_String_I_String_String_String_String_String(enumName *String, enumOrdinal int32, languageKey, scriptKey, countryKey, variantKey, extensionsKey *String) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)

	t.F_languageKey = languageKey
	t.F_scriptKey = scriptKey
	t.F_countryKey = countryKey
	t.F_variantKey = variantKey
	t.F_extensionsKey = extensionsKey
}













func Locale_Builder_New() *Locale_Builder { t := &Locale_Builder{}; t.Ctor(); return t }
//line :763:1
func (t *Locale_Builder) Ctor() {
	t.F_localeBuilder = InternalLocaleBuilder_New()
}
func (t *Locale_Builder) SetLocale_Locale__Locale_Builder(locale *Locale) *Locale_Builder { tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var tmp1 *InternalLocaleBuilder = t.F_localeBuilder; var tmp2 *BaseLocale = locale.F_baseLocale; NN(tmp1).SetLocale_BaseLocale_LocaleExtensions__InternalLocaleBuilder(tmp2, locale.F_localeExtensions) }; return nil }(); if /*line :767:1*/ tmp3 != nil { if LocaleSyntaxException_InstanceOf(tmp3) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp3)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :767:1
			panic(tmp3) } }; return t }





func (t *Locale_Builder) SetLanguageTag_String__Locale_Builder(languageTag *String) *Locale_Builder {
	if LocaleUtils_IsEmpty_String__Z(languageTag) {
		NN(t.F_localeBuilder).Clear__InternalLocaleBuilder() } else {
			var tag *LanguageTag = LanguageTag_Parse_String_ParsePosition_Z__LanguageTag(languageTag, ParsePosition_New_I(0), false)
			NN(t.F_localeBuilder).SetLanguageTag_LanguageTag__InternalLocaleBuilder(tag) }
//line :773:1
	return t
}





func (t *Locale_Builder) SetLanguage_String__Locale_Builder(language *String) *Locale_Builder { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	NN(t.F_localeBuilder).SetLanguage_String__InternalLocaleBuilder(language); return nil }(); if /*line :781:1*/ tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :781:1
			panic(tmp1) } }; return t }





func (t *Locale_Builder) SetScript_String__Locale_Builder(script *String) *Locale_Builder { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	NN(t.F_localeBuilder).SetScript_String__InternalLocaleBuilder(script); return nil }(); if /*line :788:1*/ tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :788:1
			panic(tmp1) } }; return t }





func (t *Locale_Builder) SetRegion_String__Locale_Builder(region *String) *Locale_Builder { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	NN(t.F_localeBuilder).SetRegion_String__InternalLocaleBuilder(region); return nil }(); if /*line :795:1*/ tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :795:1
			panic(tmp1) } }; return t }





func (t *Locale_Builder) SetVariant_String__Locale_Builder(variant *String) *Locale_Builder { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	NN(t.F_localeBuilder).SetVariant_String__InternalLocaleBuilder(variant); return nil }(); if /*line :802:1*/ tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :802:1
			panic(tmp1) } }; return t }





func (t *Locale_Builder) SetExtension_C_String__Locale_Builder(key uint16, value *String) *Locale_Builder { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	NN(t.F_localeBuilder).SetExtension_C_String__InternalLocaleBuilder(key, value); return nil }(); if /*line :809:1*/ tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :809:1
			panic(tmp1) } }; return t }





func (t *Locale_Builder) SetUnicodeLocaleKeyword_String_String__Locale_Builder(key, type_ *String) *Locale_Builder { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	NN(t.F_localeBuilder).SetUnicodeLocaleKeyword_String_String__InternalLocaleBuilder(key, type_); return nil }(); if /*line :816:1*/ tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :816:1
			panic(tmp1) } }; return t }





func (t *Locale_Builder) AddUnicodeLocaleAttribute_String__Locale_Builder(attribute *String) *Locale_Builder { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	NN(t.F_localeBuilder).AddUnicodeLocaleAttribute_String__InternalLocaleBuilder(attribute); return nil }(); if /*line :823:1*/ tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :823:1
			panic(tmp1) } }; return t }





func (t *Locale_Builder) RemoveUnicodeLocaleAttribute_String__Locale_Builder(attribute *String) *Locale_Builder {
	Objects_RequireNonNull_O__O(attribute.Ref()); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		NN(t.F_localeBuilder).RemoveUnicodeLocaleAttribute_String__InternalLocaleBuilder(attribute); return nil }()
//line :831:1
	if tmp1 != nil { if LocaleSyntaxException_InstanceOf(tmp1) { var e *LocaleSyntaxException = LocaleSyntaxException_Cast(tmp1)


		panic(Thrown(IllformedLocaleException_New_String_I(NN(e).GetMessage__String(), NN(e).GetErrorIndex__I()))) } else {
//line :831:1
			panic(tmp1) } }
//line :829:1
	return t
}






func (t *Locale_Builder) Clear__Locale_Builder() *Locale_Builder { NN(t.F_localeBuilder).Clear__InternalLocaleBuilder(); return t }

func (t *Locale_Builder) ClearExtensions__Locale_Builder() *Locale_Builder {
	NN(t.F_localeBuilder).ClearExtensions__InternalLocaleBuilder()
//line :839:1
	return t
}


func (t *Locale_Builder) Build__Locale() *Locale {
	var baseloc *BaseLocale = NN(t.F_localeBuilder).GetBaseLocale__BaseLocale(); var extensions *LocaleExtensions = NN(t.F_localeBuilder).GetLocaleExtensions__LocaleExtensions(); var tmp1 bool; var tmp2 bool

	tmp2 = extensions == nil; if tmp2 { tmp2 = !NN(NN(baseloc).GetVariant__String()).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		extensions = Locale_GetCompatibilityExtensions_String_String_String_String__LocaleExtensions(NN(baseloc).GetLanguage__String(), NN(baseloc).GetScript__String(), NN(baseloc).GetRegion__String(), NN(baseloc).GetVariant__String())
	}




	return Locale_GetInstance_BaseLocale_LocaleExtensions__Locale(baseloc, extensions)
}



















func Locale_LanguageRange_New_String(p0 *String) *Locale_LanguageRange { t := &Locale_LanguageRange{}; t.Ctor_String(p0); return t }
//line :874:1
func (t *Locale_LanguageRange) Ctor_String(range_ *String) { t.Ctor_String_D(range_, 1.0) }

func Locale_LanguageRange_New_String_D(p0 *String, p1 float64) *Locale_LanguageRange { t := &Locale_LanguageRange{}; t.Ctor_String_D(p0, p1); return t }
//line :876:1
func (t *Locale_LanguageRange) Ctor_String_D(range_ *String, weight float64) {
	Objects_RequireNonNull_O__O(range_.Ref())
	var tmp1 bool; var tmp2 bool; tmp2 = weight < 0.0; if !tmp2 { tmp2 = weight > 1.0 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2784, StrOfDouble(weight))))) }
	var tmp3 *String = range_; var tmp4 *Locale; Locale_Init(); tmp4 = Locale_ROOT; range_ = NN(tmp3).ToLowerCase_Locale__String(tmp4)
	var isIllFormed bool = false; var subtags *RefArray = NN(range_).Split_String__String1(Lit_1134); var tmp5 bool; var tmp6 bool

	tmp6 = NN(range_).EndsWith_String__Z(Lit_1134); if !tmp6 { tmp6 = Locale_LanguageRange_IsSubtagIllFormed_String_Z__Z(As[*String](subtags.A[0]), true) }; tmp5 = tmp6; if tmp5 {
		isIllFormed = true } else {
			var i int32 = 1; L1: for {
				if i < int32(len(subtags.A)) {
					if Locale_LanguageRange_IsSubtagIllFormed_String_Z__Z(As[*String](subtags.A[i]), false) {
						isIllFormed = true } else {
							i = i + 1; continue L1 } }
//line :885:1
				break L1
			}
		}



	if isIllFormed { panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2785, range_)))) }
	t.F_range = range_
	t.F_weight = weight
}
func Locale_LanguageRange_IsSubtagIllFormed_String_Z__Z(subtag *String, isFirstSubtag bool) bool {
	var tmp1 bool; var tmp2 bool
	tmp2 = NN(subtag).IsEmpty__Z(); if !tmp2 { tmp2 = NN(subtag).Length__I() > 8 }; tmp1 = tmp2
//line :896:1
	if tmp1 { return true } else { if NN(subtag).Equals_O__Z(Lit_1502) { return false } else {



		var charArray *CharArray = NN(subtag).ToCharArray__C1()
		if isFirstSubtag {
			var arr_101963 *CharArray = charArray; var len_101964 int32 = int32(len(arr_101963.A)); var i_101965 int32 = 0; for ; i_101965 < len_101964; i_101965++ { var c uint16 = arr_101963.A[i_101965]; var tmp3 bool; var tmp4 bool; tmp4 = int32(c) < 97; if !tmp4 { tmp4 = int32(c) > 122 }; tmp3 = tmp4; if tmp3 { return true } } } else {
				var arr_101966 *CharArray = charArray; var len_101967 int32 = int32(len(arr_101966.A)); var i_101968 int32 = 0; for ; i_101968 < len_101967; i_101968++ { var c_2 uint16 = arr_101966.A[i_101968]; var tmp5 bool; var tmp6 bool; var tmp7 bool
					tmp7 = int32(c_2) < 48; if !tmp7 { var tmp8 bool; tmp8 = int32(c_2) > 57; if tmp8 { tmp8 = int32(c_2) < 97 }; tmp7 = tmp8 }; tmp6 = tmp7; if !tmp6 { tmp6 = int32(c_2) > 122 }; tmp5 = tmp6; if tmp5 { return true } } }
//line :900:1
		return false
	}
	}
}



func (t *Locale_LanguageRange) GetRange__String() *String { return t.F_range }

func (t *Locale_LanguageRange) GetWeight__D() float64 { return t.F_weight }

func Locale_LanguageRange_Parse_String__List(ranges *String) List {
	return LocaleMatcher_Parse_String__List(ranges)
}
func Locale_LanguageRange_Parse_String_Map__List(ranges *String, map_ Map) List {

	return Locale_LanguageRange_MapEquivalents_List_Map__List(Locale_LanguageRange_Parse_String__List(ranges), map_)
}
func Locale_LanguageRange_MapEquivalents_List_Map__List(priorityList List, map_ Map) List {

	return LocaleMatcher_MapEquivalents_List_Map__List(priorityList, map_)
}
func (t *Locale_LanguageRange) HashCode__I() int32 {
	var h int32 = t.F_hash
	if h == 0 {
		h = 17
		h = 37*h + NN(t.F_range).HashCode__I()
		h = 37*h + Double_HashCode_D__I(t.F_weight)
		if h == 0 { } else { t.F_hash = h } }
//line :923:1
	return h
}






func (t *Locale_LanguageRange) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if Locale_LanguageRange_InstanceOf(tmp1) { var other *Locale_LanguageRange = Locale_LanguageRange_Cast(tmp1); var tmp2 *String = t.F_range
			if NN(tmp2).Equals_O__Z(other.F_range.Ref()) { var tmp3 float64 = t.F_weight; return tmp3 == other.F_weight } else { return false } } else {
//line :934:1
				return false
			}
	}
}
func (t *Locale_LanguageRange) ToString__String() *String {
	if t.F_weight == 1.0 { return t.F_range } else { return Concat(t.F_range, Lit_2786, StrOfDouble(t.F_weight))
	} }
func Locale_Filter_List_Collection_Locale_FilteringMode__List(priorityList List, locales Collection, mode *Locale_FilteringMode) List { Locale_Init()


	return LocaleMatcher_Filter_List_Collection_Locale_FilteringMode__List(priorityList, locales, mode)
}
func Locale_Filter_List_Collection__List(priorityList List, locales Collection) List { Locale_Init()

	var tmp1 *Locale_FilteringMode; Locale_FilteringMode_Init(); tmp1 = Locale_FilteringMode_AUTOSELECT_FILTERING; return Locale_Filter_List_Collection_Locale_FilteringMode__List(priorityList, locales, tmp1)
}
func Locale_FilterTags_List_Collection_Locale_FilteringMode__List(priorityList List, tags Collection, mode *Locale_FilteringMode) List { Locale_Init()


	return LocaleMatcher_FilterTags_List_Collection_Locale_FilteringMode__List(priorityList, tags, mode)
}
func Locale_FilterTags_List_Collection__List(priorityList List, tags Collection) List { Locale_Init()

	var tmp1 *Locale_FilteringMode; Locale_FilteringMode_Init(); tmp1 = Locale_FilteringMode_AUTOSELECT_FILTERING; return Locale_FilterTags_List_Collection_Locale_FilteringMode__List(priorityList, tags, tmp1)
}
func Locale_Lookup_List_Collection__Locale(priorityList List, locales Collection) *Locale { Locale_Init()

	return LocaleMatcher_Lookup_List_Collection__Locale(priorityList, locales)
}
func Locale_LookupTag_List_Collection__String(priorityList List, tags Collection) *String { Locale_Init()

	return LocaleMatcher_LookupTag_List_Collection__String(priorityList, tags)
}


type Locale struct{ Object; F_baseLocale *BaseLocale; F_localeExtensions *LocaleExtensions; F_hashCodeValue int32; F_languageTag LazyConstant }

func (t *Locale) Is_Cloneable() {}

func (t *Locale) Is_Serializable() {}

var Locale_ENGLISH *Locale

var Locale_FRENCH *Locale

var Locale_GERMAN *Locale

var Locale_ITALIAN *Locale

var Locale_JAPANESE *Locale

var Locale_KOREAN *Locale

var Locale_CHINESE *Locale

var Locale_SIMPLIFIED_CHINESE *Locale

var Locale_TRADITIONAL_CHINESE *Locale

var Locale_FRANCE *Locale

var Locale_GERMANY *Locale

var Locale_ITALY *Locale

var Locale_JAPAN *Locale

var Locale_KOREA *Locale

var Locale_UK *Locale

var Locale_US *Locale

var Locale_CANADA *Locale

var Locale_CANADA_FRENCH *Locale

var Locale_ROOT *Locale

var Locale_CONSTANT_LOCALES Map

var Locale_CHINA *Locale

var Locale_PRC *Locale

var Locale_TAIWAN *Locale

const Locale_PRIVATE_USE_EXTENSION uint16 = 120

const Locale_UNICODE_LOCALE_EXTENSION uint16 = 117

const Locale_serialVersionUID int64 = 9149081749638150636

const Locale_DISPLAY_LANGUAGE int32 = 0

const Locale_DISPLAY_COUNTRY int32 = 1

const Locale_DISPLAY_VARIANT int32 = 2

const Locale_DISPLAY_SCRIPT int32 = 3

const Locale_DISPLAY_UEXT_KEY int32 = 4

const Locale_DISPLAY_UEXT_TYPE int32 = 5

var Locale_LOCALE_CACHE LazyConstant

var Locale_LOCALE_CREATOR Function

var Locale_defaultLocale atomic.Pointer[Locale]

var Locale_defaultDisplayLocale atomic.Pointer[Locale]

var Locale_defaultFormatLocale atomic.Pointer[Locale]

var Locale_init ClassInit

func Locale_Init() { if !Locale_init.Done() { Locale_init.Run(Locale_clinit) } }

func Locale_clinit() { Locale_CONSTANT_LOCALES = HashMap_New()
//line :75:1
	Locale_ENGLISH = Locale_CreateConstant_B__Locale(1)
	Locale_FRENCH = Locale_CreateConstant_B__Locale(3)
	Locale_GERMAN = Locale_CreateConstant_B__Locale(4)
	Locale_ITALIAN = Locale_CreateConstant_B__Locale(5)
	Locale_JAPANESE = Locale_CreateConstant_B__Locale(6)
	Locale_KOREAN = Locale_CreateConstant_B__Locale(7)
	Locale_CHINESE = Locale_CreateConstant_B__Locale(8)
	Locale_SIMPLIFIED_CHINESE = Locale_CreateConstant_B__Locale(9)
	Locale_TRADITIONAL_CHINESE = Locale_CreateConstant_B__Locale(10)
	Locale_FRANCE = Locale_CreateConstant_B__Locale(11)
	Locale_GERMANY = Locale_CreateConstant_B__Locale(12)
	Locale_ITALY = Locale_CreateConstant_B__Locale(13)
	Locale_JAPAN = Locale_CreateConstant_B__Locale(14)
	Locale_KOREA = Locale_CreateConstant_B__Locale(15)
	Locale_UK = Locale_CreateConstant_B__Locale(16)
	Locale_US = Locale_CreateConstant_B__Locale(2)
	Locale_CANADA = Locale_CreateConstant_B__Locale(17)
	Locale_CANADA_FRENCH = Locale_CreateConstant_B__Locale(18)
	Locale_ROOT = Locale_CreateConstant_B__Locale(0)































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































	Locale_CHINA = Locale_SIMPLIFIED_CHINESE; Locale_PRC = Locale_SIMPLIFIED_CHINESE; Locale_TAIWAN = Locale_TRADITIONAL_CHINESE; Locale_LOCALE_CACHE = LazyConstant_Of_Supplier__LazyConstant(Locale_1_New()); Locale_LOCALE_CREATOR = Locale_2_New(); Locale_defaultLocale.Store(Locale_InitDefault__Locale())
}
func (t *Locale) Ref() any { if t == nil { return nil }; return t }

func (t *Locale) GetClass__Class() *Class { return Locale_class }

func (t *Locale) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func Locale_InstanceOf(x any) bool { _, ok := x.(*Locale); return ok }

func Locale_Cast(x any) *Locale { if x == nil { return nil }; v, ok := x.(*Locale); if !ok { panic(ClassCast(x, Locale_class)) }; return v }



type Locale_1 struct{ Object }

func (t *Locale_1) Is_Supplier() {}

func Locale_1_New() *Locale_1 { t := &Locale_1{}; t.Ctor(); return t }

func (t *Locale_1) Ctor() {}

func (t *Locale_1) Get__O() any { return t.Get__ReferencedKeyMap().Ref() }

func (t *Locale_1) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_1) GetClass__Class() *Class { return Locale_1_class }

func (t *Locale_1) ToString__String() *String { return Object_toString(t) }

func (t *Locale_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Locale_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_1_InstanceOf(x any) bool { _, ok := x.(*Locale_1); return ok }

func Locale_1_Cast(x any) *Locale_1 { if x == nil { return nil }; v, ok := x.(*Locale_1); if !ok { panic(ClassCast(x, Locale_1_class)) }; return v }



type Locale_2 struct{ Object }

func (t *Locale_2) Is_Function() {}

func Locale_2_New() *Locale_2 { t := &Locale_2{}; t.Ctor(); return t }

func (t *Locale_2) Ctor() {}

func (t *Locale_2) Apply_O__O(p0 any) any { return t.Apply_O__Locale(p0).Ref() }

func (t *Locale_2) Compose_Function__Function(p0 Function) Function { return Function_Compose_Function__Function(t, p0) }

func (t *Locale_2) AndThen_Function__Function(p0 Function) Function { return Function_AndThen_Function__Function(t, p0) }

func (t *Locale_2) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_2) GetClass__Class() *Class { return Locale_2_class }

func (t *Locale_2) ToString__String() *String { return Object_toString(t) }

func (t *Locale_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Locale_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_2_InstanceOf(x any) bool { _, ok := x.(*Locale_2); return ok }

func Locale_2_Cast(x any) *Locale_2 { if x == nil { return nil }; v, ok := x.(*Locale_2); if !ok { panic(ClassCast(x, Locale_2_class)) }; return v }



type Locale_3 struct{ Object; F_this_0 *Locale }

func (t *Locale_3) Is_Supplier() {}

func Locale_3_New_Locale(p0 *Locale) *Locale_3 { t := &Locale_3{}; t.Ctor_Locale(p0); return t }

func (t *Locale_3) Ctor_Locale(this_0 *Locale) { NN(this_0); t.F_this_0 = this_0 }

func (t *Locale_3) Get__O() any { return t.Get__String().Ref() }

func (t *Locale_3) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_3) GetClass__Class() *Class { return Locale_3_class }

func (t *Locale_3) ToString__String() *String { return Object_toString(t) }

func (t *Locale_3) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Locale_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_3_InstanceOf(x any) bool { _, ok := x.(*Locale_3); return ok }

func Locale_3_Cast(x any) *Locale_3 { if x == nil { return nil }; v, ok := x.(*Locale_3); if !ok { panic(ClassCast(x, Locale_3_class)) }; return v }



type Locale_Builder struct{ Object; F_localeBuilder *InternalLocaleBuilder }

func (t *Locale_Builder) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_Builder) GetClass__Class() *Class { return Locale_Builder_class }

func (t *Locale_Builder) ToString__String() *String { return Object_toString(t) }

func (t *Locale_Builder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Locale_Builder) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_Builder_InstanceOf(x any) bool { _, ok := x.(*Locale_Builder); return ok }

func Locale_Builder_Cast(x any) *Locale_Builder { if x == nil { return nil }; v, ok := x.(*Locale_Builder); if !ok { panic(ClassCast(x, Locale_Builder_class)) }; return v }



type Locale_Category struct{ Enum; F_languageKey, F_scriptKey, F_countryKey, F_variantKey, F_extensionsKey *String }

func (t *Locale_Category) Is_Constable() {}

var Locale_Category_DISPLAY *Locale_Category

var Locale_Category_FORMAT *Locale_Category

var Locale_Category__VALUES *RefArray

var Locale_Category_init ClassInit

func Locale_Category_Init() { if !Locale_Category_init.Done() { Locale_Category_init.Run(Locale_Category_clinit) } }

func Locale_Category_clinit() { Locale_Category_DISPLAY = Locale_Category_New_String_I_String_String_String_String_String(Lit_2769, 0, Lit_2764, Lit_2765, Lit_2766, Lit_2767, Lit_2768); Locale_Category_FORMAT = Locale_Category_New_String_I_String_String_String_String_String(Lit_2775, 1, Lit_2770, Lit_2771, Lit_2772, Lit_2773, Lit_2774); Locale_Category__VALUES = Locale_Category_X_values__Locale_Category1() }

func Locale_Category_Values__Locale_Category1() *RefArray { Locale_Category_Init(); return Locale_Category__VALUES.Copy() }

func Locale_Category_ValueOf_String__Locale_Category(p0 *String) *Locale_Category { Locale_Category_Init(); return Locale_Category_Cast(Enum_ValueOf_Class_String__Enum(Locale_Category_class, p0)) }

func Locale_Category_X_values__Locale_Category1() *RefArray { Locale_Category_Init(); return RefArrayOf(Locale_Category_class, Locale_Category_DISPLAY, Locale_Category_FORMAT) }

func (t *Locale_Category) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Locale_Category) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Locale_Category) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Locale_Category) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.util.Locale$Category.describeConstable()Ljava/util/Optional;")) }

func (t *Locale_Category) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Locale_Category) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Locale_Category) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_Category) GetClass__Class() *Class { return Locale_Category_class }

func (t *Locale_Category) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_Category_InstanceOf(x any) bool { _, ok := x.(*Locale_Category); return ok }

func Locale_Category_Cast(x any) *Locale_Category { if x == nil { return nil }; v, ok := x.(*Locale_Category); if !ok { panic(ClassCast(x, Locale_Category_class)) }; return v }



type Locale_FilteringMode struct{ Enum }

func (t *Locale_FilteringMode) Is_Constable() {}

var Locale_FilteringMode_AUTOSELECT_FILTERING *Locale_FilteringMode

var Locale_FilteringMode_EXTENDED_FILTERING *Locale_FilteringMode

var Locale_FilteringMode_IGNORE_EXTENDED_RANGES *Locale_FilteringMode

var Locale_FilteringMode_MAP_EXTENDED_RANGES *Locale_FilteringMode

var Locale_FilteringMode_REJECT_EXTENDED_RANGES *Locale_FilteringMode

var Locale_FilteringMode__VALUES *RefArray

var Locale_FilteringMode_init ClassInit

func Locale_FilteringMode_Init() { if !Locale_FilteringMode_init.Done() { Locale_FilteringMode_init.Run(Locale_FilteringMode_clinit) } }

func Locale_FilteringMode_clinit() { Locale_FilteringMode_AUTOSELECT_FILTERING = Locale_FilteringMode_New_String_I(Lit_2776, 0); Locale_FilteringMode_EXTENDED_FILTERING = Locale_FilteringMode_New_String_I(Lit_2777, 1); Locale_FilteringMode_IGNORE_EXTENDED_RANGES = Locale_FilteringMode_New_String_I(Lit_2778, 2); Locale_FilteringMode_MAP_EXTENDED_RANGES = Locale_FilteringMode_New_String_I(Lit_2779, 3); Locale_FilteringMode_REJECT_EXTENDED_RANGES = Locale_FilteringMode_New_String_I(Lit_2780, 4); Locale_FilteringMode__VALUES = Locale_FilteringMode_X_values__Locale_FilteringMode1() }

func Locale_FilteringMode_New_String_I(p0 *String, p1 int32) *Locale_FilteringMode { Locale_FilteringMode_Init(); t := &Locale_FilteringMode{}; t.Ctor_String_I(p0, p1); return t }

func (t *Locale_FilteringMode) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Locale_FilteringMode_Values__Locale_FilteringMode1() *RefArray { Locale_FilteringMode_Init(); return Locale_FilteringMode__VALUES.Copy() }

func Locale_FilteringMode_ValueOf_String__Locale_FilteringMode(p0 *String) *Locale_FilteringMode { Locale_FilteringMode_Init(); return Locale_FilteringMode_Cast(Enum_ValueOf_Class_String__Enum(Locale_FilteringMode_class, p0)) }

func Locale_FilteringMode_X_values__Locale_FilteringMode1() *RefArray { Locale_FilteringMode_Init(); return RefArrayOf(Locale_FilteringMode_class, Locale_FilteringMode_AUTOSELECT_FILTERING, Locale_FilteringMode_EXTENDED_FILTERING, Locale_FilteringMode_IGNORE_EXTENDED_RANGES, Locale_FilteringMode_MAP_EXTENDED_RANGES, Locale_FilteringMode_REJECT_EXTENDED_RANGES) }

func (t *Locale_FilteringMode) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Locale_FilteringMode) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Locale_FilteringMode) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Locale_FilteringMode) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.util.Locale$FilteringMode.describeConstable()Ljava/util/Optional;")) }

func (t *Locale_FilteringMode) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Locale_FilteringMode) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Locale_FilteringMode) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_FilteringMode) GetClass__Class() *Class { return Locale_FilteringMode_class }

func (t *Locale_FilteringMode) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_FilteringMode_InstanceOf(x any) bool { _, ok := x.(*Locale_FilteringMode); return ok }

func Locale_FilteringMode_Cast(x any) *Locale_FilteringMode { if x == nil { return nil }; v, ok := x.(*Locale_FilteringMode); if !ok { panic(ClassCast(x, Locale_FilteringMode_class)) }; return v }



type Locale_IsoCountryCode struct{ Enum }

func (t *Locale_IsoCountryCode) Is_Constable() {}

var Locale_IsoCountryCode_PART1_ALPHA2 *Locale_IsoCountryCode

var Locale_IsoCountryCode_PART1_ALPHA3 *Locale_IsoCountryCode

var Locale_IsoCountryCode_PART3 *Locale_IsoCountryCode

var Locale_IsoCountryCode__VALUES *RefArray

var Locale_IsoCountryCode_init ClassInit

func Locale_IsoCountryCode_Init() { if !Locale_IsoCountryCode_init.Done() { Locale_IsoCountryCode_init.Run(Locale_IsoCountryCode_clinit) } }

func Locale_IsoCountryCode_clinit() { Locale_IsoCountryCode_PART1_ALPHA2 = Locale_IsoCountryCode_New_String_I(Lit_2781, 0); Locale_IsoCountryCode_PART1_ALPHA3 = Locale_IsoCountryCode_New_String_I(Lit_2782, 1); Locale_IsoCountryCode_PART3 = Locale_IsoCountryCode_New_String_I(Lit_2783, 2); Locale_IsoCountryCode__VALUES = Locale_IsoCountryCode_X_values__Locale_IsoCountryCode1() }

func Locale_IsoCountryCode_New_String_I(p0 *String, p1 int32) *Locale_IsoCountryCode { Locale_IsoCountryCode_Init(); t := &Locale_IsoCountryCode{}; t.Ctor_String_I(p0, p1); return t }

func (t *Locale_IsoCountryCode) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Locale_IsoCountryCode_Values__Locale_IsoCountryCode1() *RefArray { Locale_IsoCountryCode_Init(); return Locale_IsoCountryCode__VALUES.Copy() }

func Locale_IsoCountryCode_ValueOf_String__Locale_IsoCountryCode(p0 *String) *Locale_IsoCountryCode { Locale_IsoCountryCode_Init(); return Locale_IsoCountryCode_Cast(Enum_ValueOf_Class_String__Enum(Locale_IsoCountryCode_class, p0)) }

func Locale_IsoCountryCode_X_values__Locale_IsoCountryCode1() *RefArray { Locale_IsoCountryCode_Init(); return RefArrayOf(Locale_IsoCountryCode_class, Locale_IsoCountryCode_PART1_ALPHA2, Locale_IsoCountryCode_PART1_ALPHA3, Locale_IsoCountryCode_PART3) }

func (t *Locale_IsoCountryCode) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Locale_IsoCountryCode) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Locale_IsoCountryCode) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Locale_IsoCountryCode) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.util.Locale$IsoCountryCode.describeConstable()Ljava/util/Optional;")) }

func (t *Locale_IsoCountryCode) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Locale_IsoCountryCode) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Locale_IsoCountryCode) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_IsoCountryCode) GetClass__Class() *Class { return Locale_IsoCountryCode_class }

func (t *Locale_IsoCountryCode) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_IsoCountryCode_InstanceOf(x any) bool { _, ok := x.(*Locale_IsoCountryCode); return ok }

func Locale_IsoCountryCode_Cast(x any) *Locale_IsoCountryCode { if x == nil { return nil }; v, ok := x.(*Locale_IsoCountryCode); if !ok { panic(ClassCast(x, Locale_IsoCountryCode_class)) }; return v }



type Locale_LanguageRange struct{ Object; F_range *String; F_weight float64; F_hash int32 }

const Locale_LanguageRange_MAX_WEIGHT float64 = 1.0

const Locale_LanguageRange_MIN_WEIGHT float64 = 0.0

func (t *Locale_LanguageRange) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_LanguageRange) GetClass__Class() *Class { return Locale_LanguageRange_class }

func (t *Locale_LanguageRange) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Locale_LanguageRange) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_LanguageRange_InstanceOf(x any) bool { _, ok := x.(*Locale_LanguageRange); return ok }

func Locale_LanguageRange_Cast(x any) *Locale_LanguageRange { if x == nil { return nil }; v, ok := x.(*Locale_LanguageRange); if !ok { panic(ClassCast(x, Locale_LanguageRange_class)) }; return v }



type Locale_LocaleKey struct{ Object; F_base *BaseLocale; F_exts *LocaleExtensions; F_hash int32 }

func (t *Locale_LocaleKey) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_LocaleKey) GetClass__Class() *Class { return Locale_LocaleKey_class }

func (t *Locale_LocaleKey) ToString__String() *String { return Object_toString(t) }

func (t *Locale_LocaleKey) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Locale_LocaleKey) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_LocaleKey_InstanceOf(x any) bool { _, ok := x.(*Locale_LocaleKey); return ok }

func Locale_LocaleKey_Cast(x any) *Locale_LocaleKey { if x == nil { return nil }; v, ok := x.(*Locale_LocaleKey); if !ok { panic(ClassCast(x, Locale_LocaleKey_class)) }; return v }



type Locale_LocaleNameGetter struct{ Object }

func (t *Locale_LocaleNameGetter) Is_LocaleServiceProviderPool_LocalizedObjectGetter() {}

var Locale_LocaleNameGetter_INSTANCE *Locale_LocaleNameGetter

var Locale_LocaleNameGetter_init ClassInit

func Locale_LocaleNameGetter_Init() { if !Locale_LocaleNameGetter_init.Done() { Locale_LocaleNameGetter_init.Run(Locale_LocaleNameGetter_clinit) } }

func Locale_LocaleNameGetter_clinit() { Locale_LocaleNameGetter_INSTANCE = Locale_LocaleNameGetter_New() }

func Locale_LocaleNameGetter_New() *Locale_LocaleNameGetter { Locale_LocaleNameGetter_Init(); t := &Locale_LocaleNameGetter{}; t.Ctor(); return t }

func (t *Locale_LocaleNameGetter) Ctor() {}

func (t *Locale_LocaleNameGetter) GetObject_LocaleServiceProvider_Locale_String_O1__O(p0 LocaleServiceProvider_I, p1 *Locale, p2 *String, p3 *RefArray) any { return t.GetObject_LocaleNameProvider_Locale_String_O1__String(LocaleNameProvider_Cast(p0), p1, p2, p3).Ref() }

func (t *Locale_LocaleNameGetter) Ref() any { if t == nil { return nil }; return t }

func (t *Locale_LocaleNameGetter) GetClass__Class() *Class { return Locale_LocaleNameGetter_class }

func (t *Locale_LocaleNameGetter) ToString__String() *String { return Object_toString(t) }

func (t *Locale_LocaleNameGetter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Locale_LocaleNameGetter) CloneShallow() any { panic(CloneNotSupported(t)) }

func Locale_LocaleNameGetter_InstanceOf(x any) bool { _, ok := x.(*Locale_LocaleNameGetter); return ok }

func Locale_LocaleNameGetter_Cast(x any) *Locale_LocaleNameGetter { if x == nil { return nil }; v, ok := x.(*Locale_LocaleNameGetter); if !ok { panic(ClassCast(x, Locale_LocaleNameGetter_class)) }; return v }
