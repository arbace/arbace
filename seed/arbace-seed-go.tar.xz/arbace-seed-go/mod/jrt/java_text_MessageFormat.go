//line java_text_MessageFormat.ae:1
package jrt
















func MessageFormat_New_String(p0 *String) *MessageFormat { t := &MessageFormat{}; t.Ctor_String(p0); return t }
//line :18:1
func (t *MessageFormat) Ctor_String(pattern *String) { t.Format.Ctor(t); t.F_pattern = Lit_69; t.F_formats = NewRefArray(Format_class, 10); t.F_offsets = NewIntArray(10); t.F_argumentNumbers = NewIntArray(10); t.F_maxOffset = -1
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.F_locale = Locale_GetDefault_Locale_Category__Locale(tmp1)
	t.ApplyPatternImpl_String__V(pattern)
}
func MessageFormat_New_String_Locale(p0 *String, p1 *Locale) *MessageFormat { t := &MessageFormat{}; t.Ctor_String_Locale(p0, p1); return t }
//line :22:1
func (t *MessageFormat) Ctor_String_Locale(pattern *String, locale *Locale) { t.Format.Ctor(t); t.F_pattern = Lit_69; t.F_formats = NewRefArray(Format_class, 10); t.F_offsets = NewIntArray(10); t.F_argumentNumbers = NewIntArray(10); t.F_maxOffset = -1
	t.F_locale = locale
	t.ApplyPatternImpl_String__V(pattern)
}
func (t *MessageFormat) SetLocale_Locale__V(locale *Locale) {
	t.F_locale = locale
}
func (t *MessageFormat) GetLocale__Locale() *Locale { return t.F_locale }

func (t *MessageFormat) ApplyPattern_String__V(pattern *String) {
	t.ApplyPatternImpl_String__V(pattern)
}
func (t *MessageFormat) ApplyPatternImpl_String__V(pattern *String) {
	var segments *RefArray = NewRefArray(StringBuilder_class, 4)
	segments.Store(0, StringBuilder_New())
	var part int32 = 0
	var formatNumber int32 = 0
	var inQuote bool = false
	var braceStack int32 = 0
	t.F_maxOffset = -1
	var i int32 = 0
L1: for { if i < NN(pattern).Length__I() {
	var ch uint16 = NN(pattern).CharAt_I__C(i)
	if part == 0 {

		if int32(ch) == 39 {

			var tmp1 bool; var tmp2 bool; tmp2 = i+1 < NN(pattern).Length__I(); if tmp2 {
				tmp2 = int32(NN(pattern).CharAt_I__C(i+1)) == 39 }
//line :49:1
			tmp1 = tmp2; if tmp1 {

				NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch); i = i + 1 } else {
					inQuote = !inQuote } } else {
//line :47:1
						var tmp3 bool; var tmp4 bool





						tmp4 = int32(ch) == 123; if tmp4 { tmp4 = !inQuote }; tmp3 = tmp4
//line :47:1
						if tmp3 {







							part = 1
							if As[*StringBuilder](segments.A[1]) == nil {
								segments.Store(1, StringBuilder_New()) } } else {
									NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch) } } } else {
//line :45:1
										if inQuote {














											NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch); if int32(ch) == 39 { inQuote = false } } else {

												switch int32(ch) { case 44:

													if part < 3 {
														var tmp5 int32; part = part + 1; tmp5 = part; if As[*StringBuilder](segments.A[tmp5]) == nil {
															segments.Store(part, StringBuilder_New()) } } else {
																NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch) }
//line :62:1
												case 123:







													braceStack = braceStack + 1
													NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch)
//line :62:1
												case 125:










													if braceStack == 0 {

														part = 0
														t.SetFormatFromPattern_I_I_StringBuilder1__V(i, formatNumber, segments)
														formatNumber = formatNumber + 1
														segments.Store(1, nil)
														segments.Store(2, nil)
														segments.Store(3, nil) } else {

															braceStack = braceStack - 1
															NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch) }
//line :62:1
												case 32:






















													var tmp6 bool; var tmp7 bool; tmp7 = !(part == 2); if !tmp7 { tmp7 = NN(As[*StringBuilder](segments.A[2])).Length__I() > 0 }; tmp6 = tmp7; if tmp6 {
														NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch) }
//line :62:1
												case 39:
























													inQuote = true; NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch)
//line :62:1
												default:

























													NN(As[*StringBuilder](segments.A[part])).Append_C__StringBuilder(ch)} } }
	i = i + 1
//line :43:1
	continue L1 }; break L1
}













































	var tmp8 bool; var tmp9 bool; tmp9 = braceStack == 0; if tmp9 { tmp9 = !(part == 0) }; tmp8 = tmp9; if tmp8 {
		t.F_maxOffset = -1
		panic(Thrown(IllegalArgumentException_New_String(Lit_1888))) }
	t.F_pattern = NN(As[*StringBuilder](segments.A[0])).ToString__String()
}
func (t *MessageFormat) ToPattern__String() *String {
	var lastOffset int32 = 0; var result *StringBuilder = StringBuilder_New()
	var i int32 = 0
L1: for {
	if i <= t.F_maxOffset {
		var tmp1 *String = t.F_pattern; MessageFormat_CopyAndFixQuotes_String_I_I_StringBuilder__V(tmp1, lastOffset, t.F_offsets.A[i], result)
		lastOffset = t.F_offsets.A[i]
		NN(NN(NN(NN(result).Append_C__StringBuilder(123)).Append_I__StringBuilder(t.F_argumentNumbers.A[i])).Append_String__StringBuilder(t.PatternFromFormat_Format__String(As[Format_I](t.F_formats.A[i])))).Append_C__StringBuilder(125)


		i = i + 1; continue L1 }
//line :98:1
	break L1
}






	var tmp2 *String = t.F_pattern; MessageFormat_CopyAndFixQuotes_String_I_I_StringBuilder__V(tmp2, lastOffset, NN(t.F_pattern).Length__I(), result)
	return NN(result).ToString__String()
}
func (t *MessageFormat) PatternFromFormat_Format__String(fmt Format_I) *String {
	var tmp1 Format_I = fmt; if NumberFormat_InstanceOf(tmp1) { var nFmt NumberFormat_I = NumberFormat_Cast(tmp1); var nStyle *String = NumberFormat_MatchToStyle_NumberFormat_Locale__String(nFmt, t.F_locale)

		if !(nStyle == nil) {
			var tmp2 *String; if NN(nStyle).IsEmpty__Z() { tmp2 = nStyle } else { tmp2 = Concat(Lit_1532, nStyle) }; return Concat(Lit_1889, tmp2) }
		var tmp3 Format_I = fmt; if DecimalFormat_InstanceOf(tmp3) { var dFmt *DecimalFormat = DecimalFormat_Cast(tmp3)
			return Concat(Lit_1890, MessageFormat_CopyAndQuoteBraces_String__String(NN(dFmt).ToPattern__String())) } else {
				var tmp4 Format_I = fmt; if ChoiceFormat_InstanceOf(tmp4) { var cFmt *ChoiceFormat = ChoiceFormat_Cast(tmp4)
					return Concat(Lit_1891, MessageFormat_CopyAndQuoteBraces_String__String(NN(cFmt).ToPattern__String())) } else { } } } else {
						if DateFormat_InstanceOf(fmt) {


							var arr_101334 *RefArray = DateFormat_Style_Values__DateFormat_Style1(); var len_101335 int32 = int32(len(arr_101334.A)); var i_101336 int32 = 0; for ; i_101336 < len_101335; i_101336++ { var style *DateFormat_Style = As[*DateFormat_Style](arr_101334.A[i_101336])
								if fmt.Equals_O__Z(DateFormat_GetDateInstance_I_Locale__DateFormat(NN(style).GetValue__I(), t.F_locale)) {
									var tmp5 *String
									if !(NN(style).GetValue__I() == 2) {
										var tmp6 *String = NN(style).Name__String(); var tmp7 *Locale; Locale_Init(); tmp7 = Locale_ROOT; tmp5 = Concat(Lit_1532, NN(tmp6).ToLowerCase_Locale__String(tmp7)) } else {
//line :124:1
											tmp5 = Lit_69 }
//line :123:1
									return Concat(Lit_1892, tmp5)
								}


								if fmt.Equals_O__Z(DateFormat_GetTimeInstance_I_Locale__DateFormat(NN(style).GetValue__I(), t.F_locale)) {
									var tmp8 *String
									if !(NN(style).GetValue__I() == 2) {
										var tmp9 *String = NN(style).Name__String(); var tmp10 *Locale; Locale_Init(); tmp10 = Locale_ROOT; tmp8 = Concat(Lit_1532, NN(tmp9).ToLowerCase_Locale__String(tmp10)) } else {
//line :129:1
											tmp8 = Lit_69 }
//line :128:1
									return Concat(Lit_1893, tmp8)
								}
							}

							var tmp11 Format_I = fmt; if SimpleDateFormat_InstanceOf(tmp11) { var sdFmt *SimpleDateFormat = SimpleDateFormat_Cast(tmp11)
								return Concat(Lit_1894, MessageFormat_CopyAndQuoteBraces_String__String(NN(sdFmt).ToPattern__String())) } else { } } else {
//line :118:1
									if ListFormat_InstanceOf(fmt) {
















										var arr_101338 *RefArray = ListFormat_Type_Values__ListFormat_Type1(); var len_101339 int32 = int32(len(arr_101338.A)); var i_101340 int32 = 0; for ; i_101340 < len_101339; i_101340++ { var type_ *ListFormat_Type = As[*ListFormat_Type](arr_101338.A[i_101340]); var tmp12 *Locale = t.F_locale; var tmp13 *ListFormat_Style
											ListFormat_Style_Init(); tmp13 = ListFormat_Style_FULL; if fmt.Equals_O__Z(ListFormat_GetInstance_Locale_ListFormat_Type_ListFormat_Style__ListFormat(tmp12, type_, tmp13).Ref()) {
												var tmp14 *String; var tmp15 *ListFormat_Type
												ListFormat_Type_Init(); tmp15 = ListFormat_Type_STANDARD; if !(type_ == tmp15) {
													var tmp16 *String = NN(type_).Name__String(); var tmp17 *Locale; Locale_Init(); tmp17 = Locale_ROOT; tmp14 = Concat(Lit_1532, NN(tmp16).ToLowerCase_Locale__String(tmp17)) } else {
//line :138:1
														tmp14 = Lit_69 }
//line :137:1
												return Concat(Lit_1895, tmp14) } } } } }
//line :109:1
	return Lit_69
}
































func (t *MessageFormat) SetFormatsByArgumentIndex_Format1__V(newFormats *RefArray) {
	var i int32 = 0; L1: for {
		if i <= t.F_maxOffset {
			var j int32 = t.F_argumentNumbers.A[i]
			if j < int32(len(newFormats.A)) {
				var tmp1 *RefArray = t.F_formats; tmp1.Store(i, As[Format_I](newFormats.A[j])); i = i + 1; continue L1 } else {
					i = i + 1; continue L1 } }
//line :144:1
		break L1
	}
}




func (t *MessageFormat) SetFormats_Format1__V(newFormats *RefArray) {
	var runsToCopy int32 = int32(len(newFormats.A))
	if runsToCopy > t.F_maxOffset+1 {
		runsToCopy = t.F_maxOffset + 1 }
	if runsToCopy >= 0 { System_Arraycopy_O_I_O_I_I__V(newFormats.Ref(), 0, t.F_formats.Ref(), 0, runsToCopy)
	} }
func (t *MessageFormat) SetFormatByArgumentIndex_I_Format__V(argumentIndex int32, newFormat Format_I) {
	var j int32 = 0; L1: for {
		if j <= t.F_maxOffset {
			if t.F_argumentNumbers.A[j] == argumentIndex {
				t.F_formats.Store(j, newFormat); j = j + 1; continue L1 } else {
					j = j + 1; continue L1 } }
//line :158:1
		break L1
	}
}




func (t *MessageFormat) SetFormat_I_Format__V(formatElementIndex int32, newFormat Format_I) {
	if formatElementIndex > t.F_maxOffset {
		panic(Thrown(ArrayIndexOutOfBoundsException_New_I(formatElementIndex))) }
	t.F_formats.Store(formatElementIndex, newFormat)
}
func (t *MessageFormat) GetFormatsByArgumentIndex__Format1() *RefArray {
	var maximumArgumentNumber int32 = -1; var i int32 = 0
L1: for {
	if i <= t.F_maxOffset {
		if t.F_argumentNumbers.A[i] > maximumArgumentNumber {

			maximumArgumentNumber = t.F_argumentNumbers.A[i]
			i = i + 1; continue L1 } else {
				i = i + 1; continue L1 } }
//line :172:1
	break L1
}






	var resultArray *RefArray = NewRefArray(Format_class, maximumArgumentNumber+1); var i_2 int32 = 0
L2: for {
	if i_2 <= t.F_maxOffset {
		var tmp1 int32 = t.F_argumentNumbers.A[i_2]; resultArray.Store(tmp1, As[Format_I](t.F_formats.A[i_2]))
		i_2 = i_2 + 1; continue L2 }
//line :181:1
	break L2 }
//line :180:1
	return resultArray
}





func (t *MessageFormat) GetFormats__Format1() *RefArray {
	var resultArray *RefArray = NewRefArray(Format_class, t.F_maxOffset+1)
	System_Arraycopy_O_I_O_I_I__V(t.F_formats.Ref(), 0, resultArray.Ref(), 0, t.F_maxOffset+1)
//line :188:1
	return resultArray
}


func (t *MessageFormat) Format_O1_StringBuffer_FieldPosition__StringBuffer(arguments *RefArray, result *StringBuffer, pos FieldPosition_I) *StringBuffer {

	return t.Subformat_O1_Format_StringBuf_FieldPosition_List__Format_StringBuf(arguments, StringBufFactory_Of_StringBuffer__Format_StringBuf(result), pos, nil).AsStringBuffer__StringBuffer()
}
func MessageFormat_Format_String_O1__String(pattern *String, arguments *RefArray) *String {
	var temp *MessageFormat = MessageFormat_New_String(pattern); return NN(temp).Format_O__String(arguments.Ref())
}
func (t *MessageFormat) Format_O_StringBuffer_FieldPosition__StringBuffer(arguments any, result *StringBuffer, pos FieldPosition_I) *StringBuffer {

	return t.Subformat_O1_Format_StringBuf_FieldPosition_List__Format_StringBuf(A2g_CastArray[*RefArray](arguments, Object_class.ArrayClass()), StringBufFactory_Of_StringBuffer__Format_StringBuf(result), pos, nil).AsStringBuffer__StringBuffer()
}

func (t *MessageFormat) Format_O_Format_StringBuf_FieldPosition__Format_StringBuf(arguments any, result Format_StringBuf, pos FieldPosition_I) Format_StringBuf {

	return t.Subformat_O1_Format_StringBuf_FieldPosition_List__Format_StringBuf(A2g_CastArray[*RefArray](arguments, Object_class.ArrayClass()), result, pos, nil)
}
func (t *MessageFormat) FormatToCharacterIterator_O__AttributedCharacterIterator(arguments any) AttributedCharacterIterator {
	Objects_RequireNonNull_O_String__O(arguments, Lit_1896)
	var result Format_StringBuf = StringBufFactory_Of__Format_StringBuf(); var iterators *ArrayList = ArrayList_New()

	t.Subformat_O1_Format_StringBuf_FieldPosition_List__Format_StringBuf(A2g_CastArray[*RefArray](arguments, Object_class.ArrayClass()), result, nil, Up_ArrayList_List(iterators))
	if NN(iterators).Size__I() == 0 {
		return t.CreateAttributedCharacterIterator_String__AttributedCharacterIterator(Lit_69) } else {
			return t.CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(A2g_CastArray[*RefArray](NN(iterators).ToArray_O1__O1(NewRefArray(AttributedCharacterIterator_class, 0)).Ref(), AttributedCharacterIterator_class.ArrayClass()))
		}
}




func (t *MessageFormat) Parse_String_ParsePosition__O1(source *String, pos *ParsePosition) *RefArray {
	if source == nil {
		var empty *RefArray = RefArrayOf(Object_class); return empty } else {
			var maximumArgumentNumber int32 = -1; var i int32 = 0
		L1: for {
			if i <= t.F_maxOffset {
				if t.F_argumentNumbers.A[i] > maximumArgumentNumber {

					maximumArgumentNumber = t.F_argumentNumbers.A[i]
					i = i + 1; continue L1 } else {
						i = i + 1; continue L1 } }
//line :226:1
			break L1
		}






			var resultArray *RefArray = NewRefArray(Object_class, maximumArgumentNumber+1); var patternOffset int32 = 0; var sourceOffset int32 = pos.F_index; var tempStatus *ParsePosition = ParsePosition_New_I(0)
			var i_2 int32 = 0


		L2: for {
			if i_2 <= t.F_maxOffset {
				var len_ int32 = t.F_offsets.A[i_2] - patternOffset; var tmp1 bool; var tmp2 bool
				tmp2 = len_ == 0; if !tmp2 { tmp2 = NN(t.F_pattern).RegionMatches_I_String_I_I__Z(patternOffset, source, sourceOffset, len_) }; tmp1 = tmp2; if tmp1 {

					sourceOffset = sourceOffset + len_
					patternOffset = patternOffset + len_ } else {
						pos.F_errorIndex = sourceOffset; return nil }
				if As[Format_I](t.F_formats.A[i_2]) == nil {
					var tempLength int32; if !(i_2 == t.F_maxOffset) {
						tempLength = t.F_offsets.A[i_2+1] } else {
							tempLength = NN(t.F_pattern).Length__I() }
//line :247:1
					var next int32


					if patternOffset >= tempLength {
						next = NN(source).Length__I() } else {
							next = NN(source).IndexOf_String_I__I(NN(t.F_pattern).Substring_I_I__String(patternOffset, tempLength), sourceOffset)
						}


					if next < 0 {
						pos.F_errorIndex = sourceOffset; return nil } else {
							var strValue *String = NN(source).Substring_I_I__String(sourceOffset, next)
							if NN(strValue).Equals_O__Z(Concat(Lit_1873, StrOfInt(t.F_argumentNumbers.A[i_2]), Lit_1874)) { } else {


								var tmp3 int32 = t.F_argumentNumbers.A[i_2]; resultArray.Store(tmp3, NN(source).Substring_I_I__String(sourceOffset, next).Ref())
							}

							sourceOffset = next
							i_2 = i_2 + 1; continue L2 } } else {

								tempStatus.F_index = sourceOffset
								var tmp4 int32 = t.F_argumentNumbers.A[i_2]; resultArray.Store(tmp4, As[Format_I](t.F_formats.A[i_2]).ParseObject_String_ParsePosition__O(source, tempStatus))


								if tempStatus.F_index == sourceOffset {
									pos.F_errorIndex = sourceOffset
									return nil }
								sourceOffset = tempStatus.F_index
								i_2 = i_2 + 1; continue L2 } }
//line :238:1
			break L2
		}





































			var len__2 int32 = NN(t.F_pattern).Length__I() - patternOffset; var tmp5 bool; var tmp6 bool
			tmp6 = len__2 == 0; if !tmp6 { tmp6 = NN(t.F_pattern).RegionMatches_I_String_I_I__Z(patternOffset, source, sourceOffset, len__2) }; tmp5 = tmp6; if tmp5 {
				pos.F_index = sourceOffset + len__2; return resultArray } else {
					pos.F_errorIndex = sourceOffset; return nil
				} } }
func (t *MessageFormat) Parse_String__O1(source *String) *RefArray {
	var pos *ParsePosition = ParsePosition_New_I(0); var result *RefArray = t.Parse_String_ParsePosition__O1(source, pos)

	if pos.F_index == 0 {
		panic(Thrown(ParseException_New_String_I(Lit_1897, pos.F_errorIndex))) }
//line :283:1
	return result
}




func (t *MessageFormat) ParseObject_String_ParsePosition__O(source *String, pos *ParsePosition) any {
	return t.Parse_String_ParsePosition__O1(source, pos).Ref()
}
func (t *MessageFormat) Clone__O() any {
	var other *MessageFormat = MessageFormat_Cast(t.Format.Impl_Clone__O(t))
	other.F_formats = NN(t.F_formats).Copy()
	var i int32 = 0; L1: for {
		if i < int32(len(t.F_formats.A)) {
			if !(As[Format_I](t.F_formats.A[i]) == nil) {

				var tmp1 *RefArray = other.F_formats; tmp1.Store(i, Format_Cast(As[Format_I](t.F_formats.A[i]).Clone__O()))
				i = i + 1; continue L1 } else {
					i = i + 1; continue L1 } }
//line :295:1
		break L1
	}






	other.F_offsets = NN(t.F_offsets).Copy()
	other.F_argumentNumbers = NN(t.F_argumentNumbers).Copy()
//line :293:1
	return other.Ref()
}












func (t *MessageFormat) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = obj == nil; if !tmp2 { tmp2 = !(t.GetClass__Class() == GetClass(obj)) }; tmp1 = tmp2
//line :308:1
		if tmp1 { return false } else {



			var other *MessageFormat = MessageFormat_Cast(obj); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 int32 = t.F_maxOffset
			tmp7 = tmp8 == other.F_maxOffset; if tmp7 {
				var tmp9 *String = t.F_pattern; tmp7 = NN(tmp9).Equals_O__Z(other.F_pattern.Ref()) }
//line :313:1
			tmp6 = tmp7; if tmp6 {

				var tmp10 any = t.F_locale.Ref(); tmp6 = Objects_Equals_O_O__Z(tmp10, other.F_locale.Ref()) }
//line :313:1
			tmp5 = tmp6; if tmp5 {


				var tmp11 *IntArray = t.F_offsets; tmp5 = Arrays_Equals_I1_I1__Z(tmp11, other.F_offsets) }
//line :313:1
			tmp4 = tmp5; if tmp4 {



				var tmp12 *IntArray = t.F_argumentNumbers; tmp4 = Arrays_Equals_I1_I1__Z(tmp12, other.F_argumentNumbers) }
//line :313:1
			tmp3 = tmp4; if tmp3 {




				var tmp13 *RefArray = t.F_formats; tmp3 = Arrays_Equals_O1_O1__Z(tmp13, other.F_formats) }
//line :313:1
			return tmp3
		}
	}
}



func (t *MessageFormat) HashCode__I() int32 { return NN(t.F_pattern).HashCode__I() }

func (t *MessageFormat) ToString__String() *String {
	var tmp1 any
	if !(t.F_locale == nil) { tmp1 = Concat(Lit_1142, NN(t.F_locale).GetDisplayName__String(), Lit_1142) } else { tmp1 = nil }
//line :323:1
	return Lit_1898.Formatted_O1__String(RefArrayOf(Object_class, tmp1, t.ToPattern__String().Ref()))
}







func MessageFormat_Field_New_String(p0 *String) *MessageFormat_Field { MessageFormat_Field_Init(); t := &MessageFormat_Field{}; t.Ctor_String(p0); return t }
//line :332:1
func (t *MessageFormat_Field) Ctor_String(name *String) { t.Format_Field.Ctor_String(t, name) }

func (t *MessageFormat_Field) ReadResolve__O() any { panic(A2g_NotTranslated("java.text.MessageFormat$Field.readResolve()Ljava/lang/Object;")) }






















func (t *MessageFormat) Subformat_O1_Format_StringBuf_FieldPosition_List__Format_StringBuf(arguments *RefArray, result Format_StringBuf, fp FieldPosition_I, characterIterators List) Format_StringBuf {


	var lastOffset int32 = 0; var last int32 = result.Length__I()
	var i int32 = 0
L1: for {
	if i <= t.F_maxOffset {
		var tmp1 CharSequence = Up_String_CharSequence(t.F_pattern); result.Append_CharSequence_I_I__Format_StringBuf(tmp1, lastOffset, t.F_offsets.A[i])
		lastOffset = t.F_offsets.A[i]
		var argumentNumber int32 = t.F_argumentNumbers.A[i]; var tmp2 bool; var tmp3 bool

		tmp3 = arguments == nil; if !tmp3 { tmp3 = argumentNumber >= int32(len(arguments.A)) }; tmp2 = tmp3
//line :367:1
		if tmp2 {


			result.Append_C__Format_StringBuf(123).Append_I__Format_StringBuf(argumentNumber).Append_C__Format_StringBuf(125)
			i = i + 1; continue L1 } else {


				var obj any = arguments.A[argumentNumber]; var arg *String; var subFormatter Format_I


				if obj == nil {
					arg = Lit_95 } else {
//line :377:1
						if !(As[Format_I](t.F_formats.A[i]) == nil) {



							subFormatter = As[Format_I](t.F_formats.A[i])
							if ChoiceFormat_InstanceOf(subFormatter) {
								arg = As[Format_I](t.F_formats.A[i]).Format_O__String(obj)
								if NN(arg).IndexOf_I__I(123) >= 0 {
									subFormatter = MessageFormat_New_String_Locale(arg, t.F_locale)
									obj = arguments.Ref()
									arg = nil } } } else {
//line :377:1
										if Number_InstanceOf(obj) {










											subFormatter = NumberFormat_GetInstance_Locale__NumberFormat(t.F_locale) } else {
//line :377:1
												if Date_InstanceOf(obj) {












													subFormatter = DateFormat_GetDateTimeInstance_I_I_Locale__DateFormat(3, 3, t.F_locale) } else {
//line :377:1
														if String_InstanceOf(obj) {

















															arg = String_Cast(obj) } else {
																arg = ToString(obj); if arg == nil { arg = Lit_95 } } } } } }
				if !(characterIterators == nil) {

					if last == result.Length__I() { } else {
						characterIterators.Add_O__Z(t.CreateAttributedCharacterIterator_String__AttributedCharacterIterator(result.Substring_I__String(last)))

						last = result.Length__I() }
					if !(subFormatter == nil) {
						var subIterator AttributedCharacterIterator = subFormatter.FormatToCharacterIterator_O__AttributedCharacterIterator(obj)
						t.Append_Format_StringBuf_CharacterIterator__V(result, subIterator)
						if last == result.Length__I() { } else {
							var tmp4 *MessageFormat_Field; MessageFormat_Field_Init(); tmp4 = MessageFormat_Field_ARGUMENT; var tmp5 AttributedCharacterIterator_Attribute_I = Up_MessageFormat_Field_AttributedCharacterIterator_Attribute(tmp4); characterIterators.Add_O__Z(t.CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(subIterator, tmp5, Integer_ValueOf_I__Integer(argumentNumber).Ref()))





							last = result.Length__I() }
						arg = nil }
					var tmp6 bool; var tmp7 bool; tmp7 = !(arg == nil); if tmp7 { tmp7 = !NN(arg).IsEmpty__Z() }; tmp6 = tmp7; if tmp6 {

						result.Append_String__Format_StringBuf(arg)
						var tmp8 *String = arg; var tmp9 *MessageFormat_Field; MessageFormat_Field_Init(); tmp9 = MessageFormat_Field_ARGUMENT; var tmp10 AttributedCharacterIterator_Attribute_I = Up_MessageFormat_Field_AttributedCharacterIterator_Attribute(tmp9); characterIterators.Add_O__Z(t.CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(tmp8, tmp10, Integer_ValueOf_I__Integer(argumentNumber).Ref()))





						last = result.Length__I()
						i = i + 1; continue L1 } else {
							i = i + 1; continue L1 } } else {

								if !(subFormatter == nil) { arg = subFormatter.Format_O__String(obj) }
								last = result.Length__I()
								result.Append_String__Format_StringBuf(arg)
								var tmp11 bool; var tmp12 bool; var tmp13 bool; tmp13 = i == 0; if tmp13 { tmp13 = !(fp == nil) }; tmp12 = tmp13; if tmp12 {
									var tmp14 *MessageFormat_Field; MessageFormat_Field_Init(); tmp14 = MessageFormat_Field_ARGUMENT; var tmp15 *MessageFormat_Field = tmp14; tmp12 = NN(tmp15).Equals_O__Z(fp.GetFieldAttribute__Format_Field()) }
//line :431:1
								tmp11 = tmp12; if tmp11 {

									fp.SetBeginIndex_I__V(last)
									fp.SetEndIndex_I__V(result.Length__I()) }
								last = result.Length__I()
								i = i + 1; continue L1 } } }
//line :362:1
	break L1
}









































































	var tmp16 CharSequence = Up_String_CharSequence(t.F_pattern); result.Append_CharSequence_I_I__Format_StringBuf(tmp16, lastOffset, NN(t.F_pattern).Length__I())
	var tmp17 bool; var tmp18 bool; tmp18 = !(characterIterators == nil); if tmp18 { tmp18 = !(last == result.Length__I()) }; tmp17 = tmp18; if tmp17 {
		characterIterators.Add_O__Z(t.CreateAttributedCharacterIterator_String__AttributedCharacterIterator(result.Substring_I__String(last))) }
//line :360:1
	return result
}
















































































func (t *MessageFormat) Append_Format_StringBuf_CharacterIterator__V(result Format_StringBuf, iterator CharacterIterator) {
	if int32(iterator.First__C()) == 65535 { } else {
		var aChar uint16 = 0
		result.Append_C__Format_StringBuf(iterator.First__C())
	L1: for { var tmp1 uint16; aChar = iterator.Next__C(); tmp1 = aChar; if !(int32(tmp1) == 65535) {
		result.Append_C__Format_StringBuf(aChar)
//line :446:1
		continue L1 }; break L1
	}
	}
}







func (t *MessageFormat) SetFormatFromPattern_I_I_StringBuilder1__V(position, offsetNumber int32, textSegments *RefArray) {

	var segments *RefArray = NewRefArray(String_class, int32(len(textSegments.A))); var i int32 = 0
L1: for {
	if i < int32(len(textSegments.A)) {
		var oneseg *StringBuilder = As[*StringBuilder](textSegments.A[i]); var tmp1 *String
		if !(oneseg == nil) { tmp1 = NN(oneseg).ToString__String() } else { tmp1 = Lit_69 }; segments.Store(i, tmp1.Ref())
		i = i + 1; continue L1 }
//line :460:1
	break L1
}



	var argumentNumber int32 = 0; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

		argumentNumber = Integer_ParseInt_String__I(As[*String](segments.A[1])); return nil }()
//line :466:1
	if tmp2 != nil { if NumberFormatException_InstanceOf(tmp2) { var e *NumberFormatException = NumberFormatException_Cast(tmp2)


		panic(Thrown(IllegalArgumentException_New_String_Throwable(Concat(Lit_1899, As[*String](segments.A[1])), Up_NumberFormatException_Throwable(e)))) } else {
//line :466:1
			panic(tmp2)
		}
	}



	if argumentNumber < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1900, StrOfInt(argumentNumber))))) }
	if argumentNumber >= 10000 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfInt(argumentNumber), Lit_1901))))
	}
	if offsetNumber >= int32(len(t.F_formats.A)) {
		var newLength int32 = int32(len(t.F_formats.A)) * 2; var newFormats *RefArray = NewRefArray(Format_class, newLength); var newOffsets *IntArray = NewIntArray(newLength); var newArgumentNumbers *IntArray = NewIntArray(newLength)



		System_Arraycopy_O_I_O_I_I__V(t.F_formats.Ref(), 0, newFormats.Ref(), 0, t.F_maxOffset+1)
		System_Arraycopy_O_I_O_I_I__V(t.F_offsets.Ref(), 0, newOffsets.Ref(), 0, t.F_maxOffset+1)
		System_Arraycopy_O_I_O_I_I__V(t.F_argumentNumbers.Ref(), 0, newArgumentNumbers.Ref(), 0, t.F_maxOffset+1)




		t.F_formats = newFormats
		t.F_offsets = newOffsets
		t.F_argumentNumbers = newArgumentNumbers }
	var oldMaxOffset int32 = t.F_maxOffset
	t.F_maxOffset = offsetNumber
	var tmp3 *IntArray = t.F_offsets; tmp3.A[offsetNumber] = NN(As[*String](segments.A[0])).Length__I()
	t.F_argumentNumbers.A[offsetNumber] = argumentNumber
	if !NN(As[*String](segments.A[2])).IsEmpty__Z() { tmp6 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var tmp4 *RefArray = t.F_formats; var tmp5 *String = As[*String](segments.A[2]); tmp4.Store(offsetNumber, t.FormatFromPattern_String_String__Format(tmp5, As[*String](segments.A[3]))) }; return nil }()
//line :497:1
		if tmp6 != nil { if Exception_InstanceOf(tmp6) { var e_2 Exception_I = Exception_Cast(tmp6)





			t.F_maxOffset = oldMaxOffset; panic(Thrown(e_2)) } else {
//line :497:1
				panic(tmp6) } } } else {






					t.F_formats.Store(offsetNumber, nil)
				} }
func (t *MessageFormat) FormatFromPattern_String_String__Format(type_, style *String) Format_I {
	{ var fType *MessageFormat_FormatType; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var tmp1 *String = NN(type_).Trim__String(); var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; fType = MessageFormat_FormatType_ValueOf_String__MessageFormat_FormatType(NN(tmp1).ToUpperCase_Locale__String(tmp2)) }; return nil }()
//line :508:1
		if tmp3 != nil { if IllegalArgumentException_InstanceOf(tmp3) { var iae IllegalArgumentException_I = IllegalArgumentException_Cast(tmp3); _ = iae


			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1902, type_)))) } else {
//line :508:1
				panic(tmp3)
			}
		}

		var fStyle *MessageFormat_FormatStyle; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

			fStyle = MessageFormat_FormatStyle_FromString_String__MessageFormat_FormatStyle(style); return nil }()
//line :513:1
		if tmp4 != nil { if IllegalArgumentException_InstanceOf(tmp4) { var iae_2 IllegalArgumentException_I = IllegalArgumentException_Cast(tmp4); var tmp5 *MessageFormat_FormatStyle; _ = iae_2

			MessageFormat_FormatStyle_Init(); tmp5 = MessageFormat_FormatStyle_SUBFORMATPATTERN; fStyle = tmp5 } else {
//line :513:1
				panic(tmp4)
			}
		}
		switch NN(fType).F_ordinal { case 0:

			switch NN(fStyle).F_ordinal { case 0:
				return NumberFormat_GetInstance_Locale__NumberFormat(t.F_locale); case 6:
				return NumberFormat_GetCurrencyInstance_Locale__NumberFormat(t.F_locale); case 7:
				return NumberFormat_GetPercentInstance_Locale__NumberFormat(t.F_locale); case 5:
				return NumberFormat_GetIntegerInstance_Locale__NumberFormat(t.F_locale); case 8:
				var tmp6 *Locale = t.F_locale; var tmp7 *NumberFormat_Style; NumberFormat_Style_Init(); tmp7 = NumberFormat_Style_SHORT; return NumberFormat_GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(tmp6, tmp7); case 9:
				var tmp8 *Locale = t.F_locale; var tmp9 *NumberFormat_Style; NumberFormat_Style_Init(); tmp9 = NumberFormat_Style_LONG; return NumberFormat_GetCompactNumberInstance_Locale_NumberFormat_Style__NumberFormat(tmp8, tmp9); default:
				return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style)}; case 1:

			switch NN(fStyle).F_ordinal { case 0:
				return DateFormat_GetDateInstance_I_Locale__DateFormat(2, t.F_locale); case 1:
				return DateFormat_GetDateInstance_I_Locale__DateFormat(3, t.F_locale); case 2:
				return DateFormat_GetDateInstance_I_Locale__DateFormat(2, t.F_locale); case 3:
				return DateFormat_GetDateInstance_I_Locale__DateFormat(1, t.F_locale); case 4:
				return DateFormat_GetDateInstance_I_Locale__DateFormat(0, t.F_locale); default:
				return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style)}; case 2:

			switch NN(fStyle).F_ordinal { case 0:
				return DateFormat_GetTimeInstance_I_Locale__DateFormat(2, t.F_locale); case 1:
				return DateFormat_GetTimeInstance_I_Locale__DateFormat(3, t.F_locale); case 2:
				return DateFormat_GetTimeInstance_I_Locale__DateFormat(2, t.F_locale); case 3:
				return DateFormat_GetTimeInstance_I_Locale__DateFormat(1, t.F_locale); case 4:
				return DateFormat_GetTimeInstance_I_Locale__DateFormat(0, t.F_locale); default:
				return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style)}; case 3:

			switch NN(fStyle).F_ordinal { case 0, 2:

				var tmp10 *FormatStyle; FormatStyle_Init(); tmp10 = FormatStyle_MEDIUM; return NN(NN(DateTimeFormatter_OfLocalizedDate_FormatStyle__DateTimeFormatter(tmp10)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 1:



				var tmp11 *FormatStyle; FormatStyle_Init(); tmp11 = FormatStyle_SHORT; return NN(NN(DateTimeFormatter_OfLocalizedDate_FormatStyle__DateTimeFormatter(tmp11)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 3:



				var tmp12 *FormatStyle; FormatStyle_Init(); tmp12 = FormatStyle_LONG; return NN(NN(DateTimeFormatter_OfLocalizedDate_FormatStyle__DateTimeFormatter(tmp12)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 4:



				var tmp13 *FormatStyle; FormatStyle_Init(); tmp13 = FormatStyle_FULL; return NN(NN(DateTimeFormatter_OfLocalizedDate_FormatStyle__DateTimeFormatter(tmp13)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); default:


				return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style)}; case 4:

			switch NN(fStyle).F_ordinal { case 0, 2:

				var tmp14 *FormatStyle; FormatStyle_Init(); tmp14 = FormatStyle_MEDIUM; return NN(NN(DateTimeFormatter_OfLocalizedTime_FormatStyle__DateTimeFormatter(tmp14)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 1:



				var tmp15 *FormatStyle; FormatStyle_Init(); tmp15 = FormatStyle_SHORT; return NN(NN(DateTimeFormatter_OfLocalizedTime_FormatStyle__DateTimeFormatter(tmp15)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 3:



				var tmp16 *FormatStyle; FormatStyle_Init(); tmp16 = FormatStyle_LONG; return NN(NN(DateTimeFormatter_OfLocalizedTime_FormatStyle__DateTimeFormatter(tmp16)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 4:



				var tmp17 *FormatStyle; FormatStyle_Init(); tmp17 = FormatStyle_FULL; return NN(NN(DateTimeFormatter_OfLocalizedTime_FormatStyle__DateTimeFormatter(tmp17)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); default:


				return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style)}; case 5:

			switch NN(fStyle).F_ordinal { case 0, 2:

				var tmp18 *FormatStyle; FormatStyle_Init(); tmp18 = FormatStyle_MEDIUM; return NN(NN(DateTimeFormatter_OfLocalizedDateTime_FormatStyle__DateTimeFormatter(tmp18)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 1:



				var tmp19 *FormatStyle; FormatStyle_Init(); tmp19 = FormatStyle_SHORT; return NN(NN(DateTimeFormatter_OfLocalizedDateTime_FormatStyle__DateTimeFormatter(tmp19)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 3:



				var tmp20 *FormatStyle; FormatStyle_Init(); tmp20 = FormatStyle_LONG; return NN(NN(DateTimeFormatter_OfLocalizedDateTime_FormatStyle__DateTimeFormatter(tmp20)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); case 4:



				var tmp21 *FormatStyle; FormatStyle_Init(); tmp21 = FormatStyle_FULL; return NN(NN(DateTimeFormatter_OfLocalizedDateTime_FormatStyle__DateTimeFormatter(tmp21)).WithLocale_Locale__DateTimeFormatter(t.F_locale)).ToFormat__Format(); default:


				return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style)}; case 6:
			return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style); case 7:

			switch NN(fStyle).F_ordinal { case 0:
				var tmp22 *Locale = t.F_locale; var tmp23 *ListFormat_Type; ListFormat_Type_Init(); tmp23 = ListFormat_Type_STANDARD; var tmp24 *ListFormat_Type = tmp23; var tmp25 *ListFormat_Style; ListFormat_Style_Init(); tmp25 = ListFormat_Style_FULL; return Up_ListFormat_Format(ListFormat_GetInstance_Locale_ListFormat_Type_ListFormat_Style__ListFormat(tmp22, tmp24, tmp25)); case 10:
				var tmp26 *Locale = t.F_locale; var tmp27 *ListFormat_Type; ListFormat_Type_Init(); tmp27 = ListFormat_Type_OR; var tmp28 *ListFormat_Type = tmp27; var tmp29 *ListFormat_Style; ListFormat_Style_Init(); tmp29 = ListFormat_Style_FULL; return Up_ListFormat_Format(ListFormat_GetInstance_Locale_ListFormat_Type_ListFormat_Style__ListFormat(tmp26, tmp28, tmp29)); case 11:
				var tmp30 *Locale = t.F_locale; var tmp31 *ListFormat_Type; ListFormat_Type_Init(); tmp31 = ListFormat_Type_UNIT; var tmp32 *ListFormat_Type = tmp31; var tmp33 *ListFormat_Style; ListFormat_Style_Init(); tmp33 = ListFormat_Style_FULL; return Up_ListFormat_Format(ListFormat_GetInstance_Locale_ListFormat_Type_ListFormat_Style__ListFormat(tmp30, tmp32, tmp33)); default:
				return t.FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType, style)}; case 8:
			var tmp34 *DateTimeFormatter; DateTimeFormatter_Init(); tmp34 = DateTimeFormatter_BASIC_ISO_DATE; return NN(tmp34).ToFormat__Format(); case 9:
			var tmp35 *DateTimeFormatter; DateTimeFormatter_Init(); tmp35 = DateTimeFormatter_ISO_LOCAL_DATE; return NN(tmp35).ToFormat__Format(); case 10:
			var tmp36 *DateTimeFormatter; DateTimeFormatter_Init(); tmp36 = DateTimeFormatter_ISO_OFFSET_DATE; return NN(tmp36).ToFormat__Format(); case 11:
			var tmp37 *DateTimeFormatter; DateTimeFormatter_Init(); tmp37 = DateTimeFormatter_ISO_DATE; return NN(tmp37).ToFormat__Format(); case 12:
			var tmp38 *DateTimeFormatter; DateTimeFormatter_Init(); tmp38 = DateTimeFormatter_ISO_LOCAL_TIME; return NN(tmp38).ToFormat__Format(); case 13:
			var tmp39 *DateTimeFormatter; DateTimeFormatter_Init(); tmp39 = DateTimeFormatter_ISO_OFFSET_TIME; return NN(tmp39).ToFormat__Format(); case 14:
			var tmp40 *DateTimeFormatter; DateTimeFormatter_Init(); tmp40 = DateTimeFormatter_ISO_TIME; return NN(tmp40).ToFormat__Format(); case 15:
			var tmp41 *DateTimeFormatter; DateTimeFormatter_Init(); tmp41 = DateTimeFormatter_ISO_LOCAL_DATE_TIME; return NN(tmp41).ToFormat__Format(); case 16:
			var tmp42 *DateTimeFormatter; DateTimeFormatter_Init(); tmp42 = DateTimeFormatter_ISO_OFFSET_DATE_TIME; return NN(tmp42).ToFormat__Format(); case 17:
			var tmp43 *DateTimeFormatter; DateTimeFormatter_Init(); tmp43 = DateTimeFormatter_ISO_ZONED_DATE_TIME; return NN(tmp43).ToFormat__Format(); case 18:
			var tmp44 *DateTimeFormatter; DateTimeFormatter_Init(); tmp44 = DateTimeFormatter_ISO_DATE_TIME; return NN(tmp44).ToFormat__Format(); case 19:
			var tmp45 *DateTimeFormatter; DateTimeFormatter_Init(); tmp45 = DateTimeFormatter_ISO_ORDINAL_DATE; return NN(tmp45).ToFormat__Format(); case 20:
			var tmp46 *DateTimeFormatter; DateTimeFormatter_Init(); tmp46 = DateTimeFormatter_ISO_WEEK_DATE; return NN(tmp46).ToFormat__Format(); case 21:
			var tmp47 *DateTimeFormatter; DateTimeFormatter_Init(); tmp47 = DateTimeFormatter_ISO_INSTANT; return NN(tmp47).ToFormat__Format(); case 22:
			var tmp48 *DateTimeFormatter; DateTimeFormatter_Init(); tmp48 = DateTimeFormatter_RFC_1123_DATE_TIME; return NN(tmp48).ToFormat__Format(); default:
			panic(Thrown(MatchException_New_String_Throwable(nil, nil)))} }; panic("a2g: unreachable")
}
func (t *MessageFormat) FormatFromSubformatPattern_MessageFormat_FormatType_String__Format(fType *MessageFormat_FormatType, pattern *String) Format_I {
	var type_ *String; var tmp1 uint16 = NN(NN(fType).Name__String()).CharAt_I__C(0); var tmp2 *String = NN(NN(fType).Name__String()).Substring_I__String(1); var tmp3 *Locale; Locale_Init(); tmp3 = Locale_ROOT; type_ = Concat(StrOfChar(tmp1), NN(tmp2).ToLowerCase_Locale__String(tmp3))

	var tmp4 Format_I; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)
		switch NN(fType).F_ordinal { case 0:
			tmp4 = DecimalFormat_New_String_DecimalFormatSymbols(pattern, DecimalFormatSymbols_GetInstance_Locale__DecimalFormatSymbols(t.F_locale)); case 1, 2:
			tmp4 = SimpleDateFormat_New_String_Locale(pattern, t.F_locale); case 3, 4, 5:
			tmp4 = NN(DateTimeFormatter_OfPattern_String__DateTimeFormatter(pattern)).ToFormat__Format(); case 6:
			tmp4 = ChoiceFormat_New_String(pattern); default:
			panic(Thrown(IllegalArgumentException_New_String(String_Format_String_O1__String(Lit_1903, RefArrayOf(Object_class, type_.Ref(), pattern.Ref())))))}; return nil }()
//line :626:1
	if tmp5 != nil { if Exception_InstanceOf(tmp5) { var e Exception_I = Exception_Cast(tmp5); var tmp6 bool; var tmp7 bool








		tmp7 = e.GetClass__Class() == IllegalArgumentException_class; if !tmp7 {
			tmp7 = e.GetClass__Class() == NullPointerException_class }
//line :635:1
		tmp6 = tmp7; if tmp6 {

			panic(Thrown(e)) } else {
				panic(Thrown(IllegalArgumentException_New_String_Throwable(String_Format_String_O1__String(Lit_1904, RefArrayOf(Object_class, type_.Ref(), pattern.Ref())), e))) } } else {
//line :626:1
					panic(tmp5) } }; return tmp4
}














func MessageFormat_CopyAndFixQuotes_String_I_I_StringBuilder__V(source *String, start, end int32, target *StringBuilder) {

	var quoted bool = false; var i int32 = start
L1: for {
	if i < end {
		var ch uint16 = NN(source).CharAt_I__C(i)
		if int32(ch) == 123 {


			if quoted { } else { NN(target).Append_C__StringBuilder(39); quoted = true }
			NN(target).Append_C__StringBuilder(ch)
			i = i + 1; continue L1 } else {
//line :648:1
				if int32(ch) == 39 {





					NN(target).Append_String__StringBuilder(Lit_1749); i = i + 1; continue L1 } else {


						if quoted { NN(target).Append_C__StringBuilder(39); quoted = false }
						NN(target).Append_C__StringBuilder(ch)
						i = i + 1; continue L1 } } }
//line :645:1
	break L1
}













	if quoted { NN(target).Append_C__StringBuilder(39)
	} }
func MessageFormat_CopyAndQuoteBraces_String__String(source *String) *String {

	var qchars *ArrayList = ArrayList_New(); var quoted bool = false; var anyChangeNeeded bool = false; var quotedSource *StringBuilder = StringBuilder_New()
	var i int32 = 0



L1: for { if i < NN(source).Length__I() {
	var ch uint16 = NN(source).CharAt_I__C(i)
	if int32(ch) == 39 {
		var tmp1 bool; var tmp2 bool; tmp2 = i+1 < NN(source).Length__I(); if tmp2 {
			tmp2 = int32(NN(source).CharAt_I__C(i+1)) == 39 }
//line :672:1
		tmp1 = tmp2; if tmp1 {

			NN(qchars).Add_O__Z(MessageFormat_1Qchar_New_C_Z(39, quoted)); i = i + 1 } else {
				quoted = !quoted } } else {
					var quotable bool; var tmp3 bool; tmp3 = int32(ch) == 123; if !tmp3 { tmp3 = int32(ch) == 125 }; quotable = tmp3
					var tmp4 bool; var a_1 bool = anyChangeNeeded; var b_2 bool; var tmp5 bool
					tmp5 = quotable; if tmp5 { tmp5 = !quoted }; b_2 = tmp5; var tmp6 bool; tmp6 = a_1; if !tmp6 { tmp6 = b_2 }; tmp4 = tmp6
//line :677:1
					anyChangeNeeded = tmp4

					var tmp7 bool; var tmp8 bool; tmp8 = quoted; if !tmp8 { tmp8 = quotable }; tmp7 = tmp8; NN(qchars).Add_O__Z(MessageFormat_1Qchar_New_C_Z(ch, tmp7)) }
	i = i + 1
//line :669:1
	continue L1 }; break L1
}










	if !anyChangeNeeded { return source } else {


		quoted = false
		var i_101359 Iterator = NN(qchars).Iterator__Iterator(); for i_101359.HasNext__Z() { var qchar *MessageFormat_1Qchar = MessageFormat_1Qchar_Cast(i_101359.Next__O()); var ch_2 uint16 = qchar.F_ch

			if int32(ch_2) == 39 {
				NN(quotedSource).Append_C__StringBuilder(ch_2) } else {
					if NN(qchar).Quoted__Z() == quoted { } else {
						NN(quotedSource).Append_C__StringBuilder(39)
						quoted = NN(qchar).Quoted__Z() } }
			NN(quotedSource).Append_C__StringBuilder(ch_2) }
		if quoted { NN(quotedSource).Append_C__StringBuilder(39) }
		return NN(quotedSource).ToString__String()
	}
}











































func MessageFormat_FormatStyle_New_String_I_String(p0 *String, p1 int32, p2 *String) *MessageFormat_FormatStyle { MessageFormat_FormatStyle_Init(); t := &MessageFormat_FormatStyle{}; t.Ctor_String_I_String(p0, p1, p2); return t }
//line :740:1
func (t *MessageFormat_FormatStyle) Ctor_String_I_String(enumName *String, enumOrdinal int32, text *String) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal); t.F_text = text }

func MessageFormat_FormatStyle_FromString_String__MessageFormat_FormatStyle(text *String) *MessageFormat_FormatStyle { MessageFormat_FormatStyle_Init()
	var arr_101360 *RefArray = MessageFormat_FormatStyle_Values__MessageFormat_FormatStyle1(); var len_101361 int32 = int32(len(arr_101360.A)); var i_101362 int32 = 0; for ; i_101362 < len_101361; i_101362++ { var style *MessageFormat_FormatStyle = As[*MessageFormat_FormatStyle](arr_101360.A[i_101362]); var tmp1 bool; var tmp2 bool
		tmp2 = !(style == MessageFormat_FormatStyle_SUBFORMATPATTERN); if tmp2 {
			tmp2 = NN(NN(text).Trim__String()).CompareToIgnoreCase_String__I(style.F_text) == 0 }
//line :744:1
		tmp1 = tmp2; if tmp1 {

			return style } }
	panic(Thrown(IllegalArgumentException_New()))
}



































func (t *MessageFormat) ReadObjectNoData__V() { panic(A2g_NotTranslated("java.text.MessageFormat.readObjectNoData()V")) }



type MessageFormat struct{ Format; F_locale *Locale; F_pattern *String; F_formats *RefArray; F_offsets, F_argumentNumbers *IntArray; F_maxOffset int32 }

const MessageFormat_serialVersionUID int64 = 6479157306784022952

const MessageFormat_INITIAL_FORMATS int32 = 10

const MessageFormat_MAX_ARGUMENT_INDEX int32 = 10000

const MessageFormat_SEG_RAW int32 = 0

const MessageFormat_SEG_INDEX int32 = 1

const MessageFormat_SEG_TYPE int32 = 2

const MessageFormat_SEG_MODIFIER int32 = 3

func (t *MessageFormat) Format_O__String(p0 any) *String { return t.Impl_Format_O__String(t, p0) }

func (t *MessageFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(p0 *RefArray) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator1__AttributedCharacterIterator(t, p0) }

func (t *MessageFormat) ParseObject_String__O(p0 *String) any { return t.Impl_ParseObject_String__O(t, p0) }

func (t *MessageFormat) CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 *String, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *MessageFormat) CreateAttributedCharacterIterator_String__AttributedCharacterIterator(p0 *String) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_String__AttributedCharacterIterator(t, p0) }

func (t *MessageFormat) CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(p0 AttributedCharacterIterator, p1 AttributedCharacterIterator_Attribute_I, p2 any) AttributedCharacterIterator { return t.Impl_CreateAttributedCharacterIterator_AttributedCharacterIterator_AttributedCharacterIterator_Attribute_O__AttributedCharacterIterator(t, p0, p1, p2) }

func (t *MessageFormat) Ref() any { if t == nil { return nil }; return t }

func (t *MessageFormat) GetClass__Class() *Class { return MessageFormat_class }

func (t *MessageFormat) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func MessageFormat_InstanceOf(x any) bool { _, ok := x.(*MessageFormat); return ok }

func MessageFormat_Cast(x any) *MessageFormat { if x == nil { return nil }; v, ok := x.(*MessageFormat); if !ok { panic(ClassCast(x, MessageFormat_class)) }; return v }



type MessageFormat_1Qchar struct{ Record; F_ch uint16; F_quoted bool }

func MessageFormat_1Qchar_New_C_Z(p0 uint16, p1 bool) *MessageFormat_1Qchar { t := &MessageFormat_1Qchar{}; t.Ctor_C_Z(p0, p1); return t }

func (t *MessageFormat_1Qchar) Ctor_C_Z(ch uint16, quoted bool) { t.Record.Ctor(t); t.F_ch = ch; t.F_quoted = quoted }

func (t *MessageFormat_1Qchar) Ch__C() uint16 { return t.F_ch }

func (t *MessageFormat_1Qchar) Quoted__Z() bool { return t.F_quoted }

func (t *MessageFormat_1Qchar) ToString__String() *String { return Concat(Lit_1905, Lit_1906, StrOfChar(t.F_ch), Lit_1907, StrOfBool(t.F_quoted), Lit_1189) }

func (t *MessageFormat_1Qchar) HashCode__I() int32 { return (int32(0)*31+int32(t.F_ch))*31 + A2g_BoolHash(t.F_quoted) }

func (t *MessageFormat_1Qchar) Equals_O__Z(p0 any) bool { if any(t) == p0 { return true }; if p0 == nil || GetClass(p0) != MessageFormat_1Qchar_class { return false }; other := p0.(*MessageFormat_1Qchar); return t.F_ch == other.F_ch && t.F_quoted == other.F_quoted }

func (t *MessageFormat_1Qchar) Ref() any { if t == nil { return nil }; return t }

func (t *MessageFormat_1Qchar) GetClass__Class() *Class { return MessageFormat_1Qchar_class }

func (t *MessageFormat_1Qchar) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MessageFormat_1Qchar) CloneShallow() any { panic(CloneNotSupported(t)) }

func MessageFormat_1Qchar_InstanceOf(x any) bool { _, ok := x.(*MessageFormat_1Qchar); return ok }

func MessageFormat_1Qchar_Cast(x any) *MessageFormat_1Qchar { if x == nil { return nil }; v, ok := x.(*MessageFormat_1Qchar); if !ok { panic(ClassCast(x, MessageFormat_1Qchar_class)) }; return v }



type MessageFormat_Field struct{ Format_Field }

const MessageFormat_Field_serialVersionUID int64 = 7899943957617360810

var MessageFormat_Field_ARGUMENT *MessageFormat_Field

var MessageFormat_Field_init ClassInit

func MessageFormat_Field_Init() { if !MessageFormat_Field_init.Done() { MessageFormat_Field_init.Run(MessageFormat_Field_clinit) } }

func MessageFormat_Field_clinit() { Format_Field_Init(); MessageFormat_Field_ARGUMENT = MessageFormat_Field_New_String(Lit_1908) }

func (t *MessageFormat_Field) GetName__String() *String { return t.Impl_GetName__String(t) }

func (t *MessageFormat_Field) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *MessageFormat_Field) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *MessageFormat_Field) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MessageFormat_Field) Ref() any { if t == nil { return nil }; return t }

func (t *MessageFormat_Field) GetClass__Class() *Class { return MessageFormat_Field_class }

func (t *MessageFormat_Field) Clone__O() any { return A2g_ObjectClone(t) }

func (t *MessageFormat_Field) CloneShallow() any { panic(CloneNotSupported(t)) }

func MessageFormat_Field_InstanceOf(x any) bool { _, ok := x.(*MessageFormat_Field); return ok }

func MessageFormat_Field_Cast(x any) *MessageFormat_Field { if x == nil { return nil }; v, ok := x.(*MessageFormat_Field); if !ok { panic(ClassCast(x, MessageFormat_Field_class)) }; return v }



type MessageFormat_FormatStyle struct{ Enum; F_text *String }

func (t *MessageFormat_FormatStyle) Is_Constable() {}

var MessageFormat_FormatStyle_DEFAULT *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_SHORT *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_MEDIUM *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_LONG *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_FULL *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_INTEGER *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_CURRENCY *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_PERCENT *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_COMPACT_SHORT *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_COMPACT_LONG *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_OR *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_UNIT *MessageFormat_FormatStyle

var MessageFormat_FormatStyle_SUBFORMATPATTERN *MessageFormat_FormatStyle

var MessageFormat_FormatStyle__VALUES *RefArray

var MessageFormat_FormatStyle_init ClassInit

func MessageFormat_FormatStyle_Init() { if !MessageFormat_FormatStyle_init.Done() { MessageFormat_FormatStyle_init.Run(MessageFormat_FormatStyle_clinit) } }

func MessageFormat_FormatStyle_clinit() { MessageFormat_FormatStyle_DEFAULT = MessageFormat_FormatStyle_New_String_I_String(Lit_1802, 0, Lit_69); MessageFormat_FormatStyle_SHORT = MessageFormat_FormatStyle_New_String_I_String(Lit_1801, 1, Lit_1193); MessageFormat_FormatStyle_MEDIUM = MessageFormat_FormatStyle_New_String_I_String(Lit_1800, 2, Lit_1909); MessageFormat_FormatStyle_LONG = MessageFormat_FormatStyle_New_String_I_String(Lit_1799, 3, Lit_1138); MessageFormat_FormatStyle_FULL = MessageFormat_FormatStyle_New_String_I_String(Lit_1798, 4, Lit_1910); MessageFormat_FormatStyle_INTEGER = MessageFormat_FormatStyle_New_String_I_String(Lit_1912, 5, Lit_1911); MessageFormat_FormatStyle_CURRENCY = MessageFormat_FormatStyle_New_String_I_String(Lit_1914, 6, Lit_1913); MessageFormat_FormatStyle_PERCENT = MessageFormat_FormatStyle_New_String_I_String(Lit_1916, 7, Lit_1915); MessageFormat_FormatStyle_COMPACT_SHORT = MessageFormat_FormatStyle_New_String_I_String(Lit_1918, 8, Lit_1917); MessageFormat_FormatStyle_COMPACT_LONG = MessageFormat_FormatStyle_New_String_I_String(Lit_1920, 9, Lit_1919); MessageFormat_FormatStyle_OR = MessageFormat_FormatStyle_New_String_I_String(Lit_1881, 10, Lit_1762); MessageFormat_FormatStyle_UNIT = MessageFormat_FormatStyle_New_String_I_String(Lit_1882, 11, Lit_1921); MessageFormat_FormatStyle_SUBFORMATPATTERN = MessageFormat_FormatStyle_New_String_I_String(Lit_1922, 12, nil); MessageFormat_FormatStyle__VALUES = MessageFormat_FormatStyle_X_values__MessageFormat_FormatStyle1() }

func MessageFormat_FormatStyle_Values__MessageFormat_FormatStyle1() *RefArray { MessageFormat_FormatStyle_Init(); return MessageFormat_FormatStyle__VALUES.Copy() }

func MessageFormat_FormatStyle_ValueOf_String__MessageFormat_FormatStyle(p0 *String) *MessageFormat_FormatStyle { MessageFormat_FormatStyle_Init(); return MessageFormat_FormatStyle_Cast(Enum_ValueOf_Class_String__Enum(MessageFormat_FormatStyle_class, p0)) }

func MessageFormat_FormatStyle_X_values__MessageFormat_FormatStyle1() *RefArray { MessageFormat_FormatStyle_Init(); return RefArrayOf(MessageFormat_FormatStyle_class, MessageFormat_FormatStyle_DEFAULT, MessageFormat_FormatStyle_SHORT, MessageFormat_FormatStyle_MEDIUM, MessageFormat_FormatStyle_LONG, MessageFormat_FormatStyle_FULL, MessageFormat_FormatStyle_INTEGER, MessageFormat_FormatStyle_CURRENCY, MessageFormat_FormatStyle_PERCENT, MessageFormat_FormatStyle_COMPACT_SHORT, MessageFormat_FormatStyle_COMPACT_LONG, MessageFormat_FormatStyle_OR, MessageFormat_FormatStyle_UNIT, MessageFormat_FormatStyle_SUBFORMATPATTERN) }

func (t *MessageFormat_FormatStyle) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *MessageFormat_FormatStyle) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *MessageFormat_FormatStyle) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *MessageFormat_FormatStyle) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.text.MessageFormat$FormatStyle.describeConstable()Ljava/util/Optional;")) }

func (t *MessageFormat_FormatStyle) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *MessageFormat_FormatStyle) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MessageFormat_FormatStyle) Ref() any { if t == nil { return nil }; return t }

func (t *MessageFormat_FormatStyle) GetClass__Class() *Class { return MessageFormat_FormatStyle_class }

func (t *MessageFormat_FormatStyle) CloneShallow() any { panic(CloneNotSupported(t)) }

func MessageFormat_FormatStyle_InstanceOf(x any) bool { _, ok := x.(*MessageFormat_FormatStyle); return ok }

func MessageFormat_FormatStyle_Cast(x any) *MessageFormat_FormatStyle { if x == nil { return nil }; v, ok := x.(*MessageFormat_FormatStyle); if !ok { panic(ClassCast(x, MessageFormat_FormatStyle_class)) }; return v }



type MessageFormat_FormatType struct{ Enum }

func (t *MessageFormat_FormatType) Is_Constable() {}

var MessageFormat_FormatType_NUMBER *MessageFormat_FormatType

var MessageFormat_FormatType_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_DTF_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_DTF_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_DTF_DATETIME *MessageFormat_FormatType

var MessageFormat_FormatType_CHOICE *MessageFormat_FormatType

var MessageFormat_FormatType_LIST *MessageFormat_FormatType

var MessageFormat_FormatType_BASIC_ISO_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_LOCAL_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_OFFSET_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_LOCAL_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_OFFSET_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_LOCAL_DATE_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_OFFSET_DATE_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_ZONED_DATE_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_DATE_TIME *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_ORDINAL_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_WEEK_DATE *MessageFormat_FormatType

var MessageFormat_FormatType_ISO_INSTANT *MessageFormat_FormatType

var MessageFormat_FormatType_RFC_1123_DATE_TIME *MessageFormat_FormatType

var MessageFormat_FormatType__VALUES *RefArray

var MessageFormat_FormatType_init ClassInit

func MessageFormat_FormatType_Init() { if !MessageFormat_FormatType_init.Done() { MessageFormat_FormatType_init.Run(MessageFormat_FormatType_clinit) } }

func MessageFormat_FormatType_clinit() { MessageFormat_FormatType_NUMBER = MessageFormat_FormatType_New_String_I(Lit_1923, 0); MessageFormat_FormatType_DATE = MessageFormat_FormatType_New_String_I(Lit_1924, 1); MessageFormat_FormatType_TIME = MessageFormat_FormatType_New_String_I(Lit_1925, 2); MessageFormat_FormatType_DTF_DATE = MessageFormat_FormatType_New_String_I(Lit_1926, 3); MessageFormat_FormatType_DTF_TIME = MessageFormat_FormatType_New_String_I(Lit_1927, 4); MessageFormat_FormatType_DTF_DATETIME = MessageFormat_FormatType_New_String_I(Lit_1928, 5); MessageFormat_FormatType_CHOICE = MessageFormat_FormatType_New_String_I(Lit_1929, 6); MessageFormat_FormatType_LIST = MessageFormat_FormatType_New_String_I(Lit_1930, 7); MessageFormat_FormatType_BASIC_ISO_DATE = MessageFormat_FormatType_New_String_I(Lit_1931, 8); MessageFormat_FormatType_ISO_LOCAL_DATE = MessageFormat_FormatType_New_String_I(Lit_1932, 9); MessageFormat_FormatType_ISO_OFFSET_DATE = MessageFormat_FormatType_New_String_I(Lit_1933, 10); MessageFormat_FormatType_ISO_DATE = MessageFormat_FormatType_New_String_I(Lit_1934, 11); MessageFormat_FormatType_ISO_LOCAL_TIME = MessageFormat_FormatType_New_String_I(Lit_1935, 12); MessageFormat_FormatType_ISO_OFFSET_TIME = MessageFormat_FormatType_New_String_I(Lit_1936, 13); MessageFormat_FormatType_ISO_TIME = MessageFormat_FormatType_New_String_I(Lit_1937, 14); MessageFormat_FormatType_ISO_LOCAL_DATE_TIME = MessageFormat_FormatType_New_String_I(Lit_1938, 15); MessageFormat_FormatType_ISO_OFFSET_DATE_TIME = MessageFormat_FormatType_New_String_I(Lit_1939, 16); MessageFormat_FormatType_ISO_ZONED_DATE_TIME = MessageFormat_FormatType_New_String_I(Lit_1940, 17); MessageFormat_FormatType_ISO_DATE_TIME = MessageFormat_FormatType_New_String_I(Lit_1941, 18); MessageFormat_FormatType_ISO_ORDINAL_DATE = MessageFormat_FormatType_New_String_I(Lit_1942, 19); MessageFormat_FormatType_ISO_WEEK_DATE = MessageFormat_FormatType_New_String_I(Lit_1943, 20); MessageFormat_FormatType_ISO_INSTANT = MessageFormat_FormatType_New_String_I(Lit_1944, 21); MessageFormat_FormatType_RFC_1123_DATE_TIME = MessageFormat_FormatType_New_String_I(Lit_1945, 22); MessageFormat_FormatType__VALUES = MessageFormat_FormatType_X_values__MessageFormat_FormatType1() }

func MessageFormat_FormatType_New_String_I(p0 *String, p1 int32) *MessageFormat_FormatType { MessageFormat_FormatType_Init(); t := &MessageFormat_FormatType{}; t.Ctor_String_I(p0, p1); return t }

func (t *MessageFormat_FormatType) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func MessageFormat_FormatType_Values__MessageFormat_FormatType1() *RefArray { MessageFormat_FormatType_Init(); return MessageFormat_FormatType__VALUES.Copy() }

func MessageFormat_FormatType_ValueOf_String__MessageFormat_FormatType(p0 *String) *MessageFormat_FormatType { MessageFormat_FormatType_Init(); return MessageFormat_FormatType_Cast(Enum_ValueOf_Class_String__Enum(MessageFormat_FormatType_class, p0)) }

func MessageFormat_FormatType_X_values__MessageFormat_FormatType1() *RefArray { MessageFormat_FormatType_Init(); return RefArrayOf(MessageFormat_FormatType_class, MessageFormat_FormatType_NUMBER, MessageFormat_FormatType_DATE, MessageFormat_FormatType_TIME, MessageFormat_FormatType_DTF_DATE, MessageFormat_FormatType_DTF_TIME, MessageFormat_FormatType_DTF_DATETIME, MessageFormat_FormatType_CHOICE, MessageFormat_FormatType_LIST, MessageFormat_FormatType_BASIC_ISO_DATE, MessageFormat_FormatType_ISO_LOCAL_DATE, MessageFormat_FormatType_ISO_OFFSET_DATE, MessageFormat_FormatType_ISO_DATE, MessageFormat_FormatType_ISO_LOCAL_TIME, MessageFormat_FormatType_ISO_OFFSET_TIME, MessageFormat_FormatType_ISO_TIME, MessageFormat_FormatType_ISO_LOCAL_DATE_TIME, MessageFormat_FormatType_ISO_OFFSET_DATE_TIME, MessageFormat_FormatType_ISO_ZONED_DATE_TIME, MessageFormat_FormatType_ISO_DATE_TIME, MessageFormat_FormatType_ISO_ORDINAL_DATE, MessageFormat_FormatType_ISO_WEEK_DATE, MessageFormat_FormatType_ISO_INSTANT, MessageFormat_FormatType_RFC_1123_DATE_TIME) }

func (t *MessageFormat_FormatType) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *MessageFormat_FormatType) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *MessageFormat_FormatType) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *MessageFormat_FormatType) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.text.MessageFormat$FormatType.describeConstable()Ljava/util/Optional;")) }

func (t *MessageFormat_FormatType) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *MessageFormat_FormatType) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *MessageFormat_FormatType) Ref() any { if t == nil { return nil }; return t }

func (t *MessageFormat_FormatType) GetClass__Class() *Class { return MessageFormat_FormatType_class }

func (t *MessageFormat_FormatType) CloneShallow() any { panic(CloneNotSupported(t)) }

func MessageFormat_FormatType_InstanceOf(x any) bool { _, ok := x.(*MessageFormat_FormatType); return ok }

func MessageFormat_FormatType_Cast(x any) *MessageFormat_FormatType { if x == nil { return nil }; v, ok := x.(*MessageFormat_FormatType); if !ok { panic(ClassCast(x, MessageFormat_FormatType_class)) }; return v }
