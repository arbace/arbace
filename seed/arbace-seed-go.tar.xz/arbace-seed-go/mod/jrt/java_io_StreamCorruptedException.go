//line java_io_StreamCorruptedException.ae:1
package jrt








func StreamCorruptedException_New_String(p0 *String) *StreamCorruptedException { t := &StreamCorruptedException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *StreamCorruptedException) Ctor_String(reason *String) { t.ObjectStreamException.Ctor_String(t, reason) }

func StreamCorruptedException_New() *StreamCorruptedException { t := &StreamCorruptedException{}; t.Ctor(); return t }
//line :12:1
func (t *StreamCorruptedException) Ctor() { t.ObjectStreamException.Ctor(t) }







type StreamCorruptedException struct{ ObjectStreamException }

const StreamCorruptedException_serialVersionUID int64 = 8983558202217591746

func (t *StreamCorruptedException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *StreamCorruptedException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *StreamCorruptedException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *StreamCorruptedException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *StreamCorruptedException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *StreamCorruptedException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *StreamCorruptedException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *StreamCorruptedException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *StreamCorruptedException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *StreamCorruptedException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *StreamCorruptedException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *StreamCorruptedException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *StreamCorruptedException) Ref() any { if t == nil { return nil }; return t }

func (t *StreamCorruptedException) GetClass__Class() *Class { return StreamCorruptedException_class }

func (t *StreamCorruptedException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StreamCorruptedException) CloneShallow() any { panic(CloneNotSupported(t)) }

func StreamCorruptedException_InstanceOf(x any) bool { _, ok := x.(*StreamCorruptedException); return ok }

func StreamCorruptedException_Cast(x any) *StreamCorruptedException { if x == nil { return nil }; v, ok := x.(*StreamCorruptedException); if !ok { panic(ClassCast(x, StreamCorruptedException_class)) }; return v }
