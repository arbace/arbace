//line java_net_URLConnection.ae:1
package jrt

import "sync/atomic"







func URLConnection_GetFileNameMap__FileNameMap() FileNameMap { URLConnection_Init()
	var map_ FileNameMap = URLConnection_fileNameMap.Load()
	if map_ == nil {
		var tmp1 FileNameMap
		map_ = URLConnection_1_New(); tmp1 = map_
//line :14:1
		URLConnection_fileNameMap.Store(tmp1) }
//line :12:1
	return map_
}



func (t *URLConnection_1) GetContentTypeFor_String__String(fileName *String) *String { return nil }













































func URLConnection_SetFileNameMap_FileNameMap__V(map_ FileNameMap) { URLConnection_Init()
	URLConnection_fileNameMap.Store(map_)
}


func (t *URLConnection) Impl_SetConnectTimeout_I__V(this URLConnection_I, timeout int32) {
	if timeout < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1435))) }
	t.F_connectTimeout = timeout
}
func (t *URLConnection) Impl_GetConnectTimeout__I(this URLConnection_I) int32 { return t.F_connectTimeout }

func (t *URLConnection) Impl_SetReadTimeout_I__V(this URLConnection_I, timeout int32) {
	if timeout < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1435))) }
	t.F_readTimeout = timeout
}
func (t *URLConnection) Impl_GetReadTimeout__I(this URLConnection_I) int32 { return t.F_readTimeout }

func (t *URLConnection) Ctor_URL(this URLConnection_I, url *URL) { t.F_doInput = true; t.F_doOutput = false; t.F_allowUserInteraction = URLConnection_defaultAllowUserInteraction; t.F_ifModifiedSince = 0; t.F_connected = false
	t.F_url = url
	if url == nil {
		t.F_useCaches = URLConnection_defaultUseCaches.Load() } else {
			t.F_useCaches = URLConnection_GetDefaultUseCaches_String__Z(NN(url).GetProtocol__String())
		} }
func (t *URLConnection) Impl_GetURL__URL(this URLConnection_I) *URL { return t.F_url }

func (t *URLConnection) Impl_GetContentLength__I(this URLConnection_I) int32 {
	var l int64 = this.GetContentLengthLong__J(); if l > 2147483647 { return -1 } else { return int32(l)
	} }
func (t *URLConnection) Impl_GetContentLengthLong__J(this URLConnection_I) int64 {
	return this.GetHeaderFieldLong_String_J__J(Lit_1436, -1)
}
func (t *URLConnection) Impl_GetContentType__String(this URLConnection_I) *String {
	return this.GetHeaderField_String__String(Lit_1437)
}
func (t *URLConnection) Impl_GetContentEncoding__String(this URLConnection_I) *String {
	return this.GetHeaderField_String__String(Lit_1438)
}
func (t *URLConnection) Impl_GetExpiration__J(this URLConnection_I) int64 {
	return this.GetHeaderFieldDate_String_J__J(Lit_1439, 0)
}
func (t *URLConnection) Impl_GetDate__J(this URLConnection_I) int64 {
	return this.GetHeaderFieldDate_String_J__J(Lit_1440, 0)
}
func (t *URLConnection) Impl_GetLastModified__J(this URLConnection_I) int64 {
	return this.GetHeaderFieldDate_String_J__J(Lit_1441, 0)
}
func (t *URLConnection) Impl_GetHeaderField_String__String(this URLConnection_I, name *String) *String { return nil }

func (t *URLConnection) Impl_GetHeaderFields__Map(this URLConnection_I) Map {
	return Collections_EmptyMap__Map()
}
func (t *URLConnection) Impl_GetHeaderFieldInt_String_I__I(this URLConnection_I, name *String, defaultValue int32) int32 {
	var value *String = this.GetHeaderField_String__String(name)
	if !(value == nil) { tmp1, tmp2, tmp3 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc); return 2, Integer_ParseInt_String__I(value), nil; return 0, 0, nil }(); if tmp3 != nil { if NumberFormatException_InstanceOf(tmp3) { var e *NumberFormatException = NumberFormatException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }} }
//line :115:1
	return defaultValue
}


func (t *URLConnection) Impl_GetHeaderFieldLong_String_J__J(this URLConnection_I, name *String, defaultValue int64) int64 {
	var value *String = this.GetHeaderField_String__String(name)
	if !(value == nil) { tmp1, tmp2, tmp3 := func() (ctl int32, rv int64, exc Throwable_I) { defer Catch(&exc); return 2, Long_ParseLong_String__J(value), nil; return 0, 0, nil }(); if tmp3 != nil { if NumberFormatException_InstanceOf(tmp3) { var e *NumberFormatException = NumberFormatException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }} }
//line :120:1
	return defaultValue
}


func (t *URLConnection) Impl_GetHeaderFieldDate_String_J__J(this URLConnection_I, name *String, defaultValue int64) int64 {
	var value *String = this.GetHeaderField_String__String(name)
	if !(value == nil) { tmp1, tmp2, tmp3 := func() (ctl int32, rv int64, exc Throwable_I) { defer Catch(&exc); return 2, A2g_Missing[int64]("jrt lacks java.util.Date.parse(Ljava/lang/String;)J"), nil; return 0, 0, nil }(); if tmp3 != nil { if Exception_InstanceOf(tmp3) { var e Exception_I = Exception_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }} }
//line :125:1
	return defaultValue
}


func (t *URLConnection) Impl_GetHeaderFieldKey_I__String(this URLConnection_I, n int32) *String { return nil }

func (t *URLConnection) Impl_GetHeaderField_I__String(this URLConnection_I, n int32) *String { return nil }

func (t *URLConnection) Impl_GetContent__O(this URLConnection_I) any {
	this.GetInputStream__InputStream()
	return t.Impl_GetContentHandler__ContentHandler(this).GetContent_URLConnection__O(this)
}
func (t *URLConnection) Impl_GetContent_Class1__O(this URLConnection_I, classes *RefArray) any {
	this.GetInputStream__InputStream()
	return t.Impl_GetContentHandler__ContentHandler(this).GetContent_URLConnection_Class1__O(this, classes)
}



func (t *URLConnection) Impl_GetInputStream__InputStream(this URLConnection_I) InputStream_I {
	panic(Thrown(UnknownServiceException_New_String(Lit_1442)))
}
func (t *URLConnection) Impl_GetOutputStream__OutputStream(this URLConnection_I) OutputStream_I {
	panic(Thrown(UnknownServiceException_New_String(Lit_1443)))
}
func (t *URLConnection) Impl_ToString__String(this URLConnection_I) *String {
	return Concat(NN(this.GetClass__Class()).GetName__String(), Lit_1309, StrOfObj(t.F_url.Ref()))
}
func (t *URLConnection) Impl_SetDoInput_Z__V(this URLConnection_I, doinput bool) {
	t.Impl_CheckConnected__V(this)
	t.F_doInput = doinput
}
func (t *URLConnection) Impl_GetDoInput__Z(this URLConnection_I) bool { return t.F_doInput }

func (t *URLConnection) Impl_SetDoOutput_Z__V(this URLConnection_I, dooutput bool) {
	t.Impl_CheckConnected__V(this)
	t.F_doOutput = dooutput
}
func (t *URLConnection) Impl_GetDoOutput__Z(this URLConnection_I) bool { return t.F_doOutput }

func (t *URLConnection) Impl_SetAllowUserInteraction_Z__V(this URLConnection_I, allowuserinteraction bool) {
	t.Impl_CheckConnected__V(this)
	t.F_allowUserInteraction = allowuserinteraction
}
func (t *URLConnection) Impl_GetAllowUserInteraction__Z(this URLConnection_I) bool { return t.F_allowUserInteraction }


func URLConnection_SetDefaultAllowUserInteraction_Z__V(defaultallowuserinteraction bool) { URLConnection_Init()
	URLConnection_defaultAllowUserInteraction = defaultallowuserinteraction
}
func URLConnection_GetDefaultAllowUserInteraction__Z() bool { URLConnection_Init(); return URLConnection_defaultAllowUserInteraction }


func (t *URLConnection) Impl_SetUseCaches_Z__V(this URLConnection_I, usecaches bool) {
	t.Impl_CheckConnected__V(this)
	t.F_useCaches = usecaches
}
func (t *URLConnection) Impl_GetUseCaches__Z(this URLConnection_I) bool { return t.F_useCaches }

func (t *URLConnection) Impl_SetIfModifiedSince_J__V(this URLConnection_I, ifmodifiedsince int64) {
	t.Impl_CheckConnected__V(this)
	t.F_ifModifiedSince = ifmodifiedsince
}
func (t *URLConnection) Impl_GetIfModifiedSince__J(this URLConnection_I) int64 { return t.F_ifModifiedSince }

func (t *URLConnection) Impl_GetDefaultUseCaches__Z(this URLConnection_I) bool { return URLConnection_defaultUseCaches.Load() }

func (t *URLConnection) Impl_SetDefaultUseCaches_Z__V(this URLConnection_I, defaultusecaches bool) {
	URLConnection_defaultUseCaches.Store(defaultusecaches)
}
func URLConnection_SetDefaultUseCaches_String_Z__V(protocol *String, defaultVal bool) { URLConnection_Init()

	protocol = URL_LowerCaseProtocol_String__String(protocol)
	NN(URLConnection_defaultCaching).Put_O_O__O(protocol.Ref(), Boolean_ValueOf_Z__Boolean(defaultVal))
}
func URLConnection_GetDefaultUseCaches_String__Z(protocol *String) bool { URLConnection_Init()
	var tmp1 *ConcurrentHashMap = URLConnection_defaultCaching; var protoDefault *Boolean = Boolean_Cast(NN(tmp1).Get_O__O(URL_LowerCaseProtocol_String__String(protocol).Ref()))
	if !(protoDefault == nil) { return NN(protoDefault).BooleanValue__Z() } else { return URLConnection_defaultUseCaches.Load()
	} }
func (t *URLConnection) Impl_SetRequestProperty_String_String__V(this URLConnection_I, key, value *String) {
	t.Impl_CheckConnected__V(this)
	if key == nil { panic(Thrown(NullPointerException_New_String(Lit_1446))) }
	if t.F_requests == nil { t.F_requests = MessageHeader_New() }
	NN(t.F_requests).Set_String_String__V(key, value)
}
func (t *URLConnection) Impl_AddRequestProperty_String_String__V(this URLConnection_I, key, value *String) {
	t.Impl_CheckConnected__V(this)
	if key == nil { panic(Thrown(NullPointerException_New_String(Lit_1446))) }
	if t.F_requests == nil { t.F_requests = MessageHeader_New() }
	NN(t.F_requests).Add_String_String__V(key, value)
}
func (t *URLConnection) Impl_GetRequestProperty_String__String(this URLConnection_I, key *String) *String {
	t.Impl_CheckConnected__V(this)
	if !(t.F_requests == nil) { return NN(t.F_requests).FindValue_String__String(key) } else { return nil
	} }
func (t *URLConnection) Impl_GetRequestProperties__Map(this URLConnection_I) Map {
	t.Impl_CheckConnected__V(this)
	if t.F_requests == nil { return Collections_EmptyMap__Map() } else { return NN(t.F_requests).GetHeaders_String1__Map(nil)
	} }
func URLConnection_SetDefaultRequestProperty_String_String__V(p0, p1 *String) { URLConnection_Init() }


func URLConnection_GetDefaultRequestProperty_String__String(key *String) *String { URLConnection_Init(); return nil }










func (t *URLConnection) Impl_GetContentHandler__ContentHandler(this URLConnection_I) ContentHandler_I {
	var contentType *String = t.Impl_StripOffParameters_String__String(this, this.GetContentType__String())
	if contentType == nil { panic(Thrown(UnknownServiceException_New_String(Lit_1447))) }
	var handler ContentHandler_I = ContentHandler_Cast(URLConnection_handlers.Get_O__O(contentType.Ref()))
	if !(handler == nil) { return handler } else {


		if !(A2g_Missing[any]("class java.net.ContentHandlerFactory is not in the closed world") == nil) {
			handler = A2g_Missing[ContentHandler_I]("class java.net.ContentHandlerFactory is not in the closed world")
			if !(handler == nil) { return handler } }
		handler = t.Impl_LookupContentHandlerViaProvider_String__ContentHandler(this, contentType)
		if !(handler == nil) {
			var h ContentHandler_I = ContentHandler_Cast(URLConnection_handlers.PutIfAbsent_O_O__O(contentType.Ref(), handler))
			return ContentHandler_Cast(Objects_RequireNonNullElse_O_O__O(h, handler)) } else { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)


				handler = t.Impl_LookupContentHandlerClassFor_String__ContentHandler(this, contentType); return nil }()
//line :253:1
				if tmp1 != nil { if Exception_InstanceOf(tmp1) { var e Exception_I = Exception_Cast(tmp1)


					e.PrintStackTrace__V()
					var tmp2 ContentHandler_I; UnknownContentHandler_Init(); tmp2 = UnknownContentHandler_INSTANCE; handler = tmp2 } else {
//line :253:1
						panic(tmp1)
					}
				}


				if !A2g_AssertionsDisabled && !!(handler == nil) { panic(Thrown(AssertionError_New())) }
				var h_2 ContentHandler_I = ContentHandler_Cast(URLConnection_handlers.PutIfAbsent_O_O__O(contentType.Ref(), handler))
				return ContentHandler_Cast(Objects_RequireNonNullElse_O_O__O(h_2, handler))
			} } }
func (t *URLConnection) Impl_StripOffParameters_String__String(this URLConnection_I, contentType *String) *String {
	if !(contentType == nil) {
		var index int32 = NN(contentType).IndexOf_I__I(59)
		if index > 0 { return NN(contentType).Substring_I_I__String(0, index) } else { return contentType } } else {
//line :263:1
			return nil
		}
}





func (t *URLConnection) Impl_LookupContentHandlerClassFor_String__ContentHandler(this URLConnection_I, contentType *String) ContentHandler_I {
	var contentHandlerClassName *String = t.Impl_TypeToPackageName_String__String(this, contentType); var contentHandlerPkgPrefixes *String = t.Impl_GetContentHandlerPkgPrefixes__String(this); var packagePrefixIter *StringTokenizer = StringTokenizer_New_String_String(contentHandlerPkgPrefixes, Lit_1448)


L1: for { if NN(packagePrefixIter).HasMoreTokens__Z() {
	var packagePrefix *String = NN(NN(packagePrefixIter).NextToken__String()).Trim__String(); tmp2, tmp3, tmp4 := func() (ctl int32, rv ContentHandler_I, exc Throwable_I) { defer Catch(&exc)

		{ var clsName *String = Concat(packagePrefix, Lit_79, contentHandlerClassName); var cls *Class; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)


			cls = Class_ForName_String__Class(clsName); return nil }()
//line :280:1
			if tmp1 != nil { if ClassNotFoundException_InstanceOf(tmp1) { var e *ClassNotFoundException = ClassNotFoundException_Cast(tmp1); var cl ClassLoader_I = ClassLoader_GetSystemClassLoader__ClassLoader(); _ = e



				if !(cl == nil) { cls = cl.LoadClass_String__Class(clsName) } } else {
//line :280:1
					panic(tmp1)
				}
			}


			if !(cls == nil) { var tmp any = NN(cls).NewInstance__O(); return 2, ContentHandler_Cast(tmp), nil } }; return 0, nil, nil }()
//line :277:1
	if tmp4 != nil { if Exception_InstanceOf(tmp4) { var ignored Exception_I = Exception_Cast(tmp4); _ = ignored } else { panic(tmp4) } }; switch tmp2 { case 2: { return tmp3 }}
//line :275:1
	continue L1 }; break L1 }
//line :272:1
	UnknownContentHandler_Init(); return UnknownContentHandler_INSTANCE
}















func (t *URLConnection) Impl_LookupContentHandlerViaProvider_String__ContentHandler(this URLConnection_I, contentType *String) ContentHandler_I {
	var cl ClassLoader_I = ClassLoader_GetSystemClassLoader__ClassLoader(); var sl any; _ = cl; _ = sl
	sl = A2g_Missing[any]("class java.util.ServiceLoader is not in the closed world")
//line :290:1
	var iterator Iterator



	iterator = A2g_Missing[Iterator]("class java.util.ServiceLoader is not in the closed world")
//line :290:1
	var handler ContentHandler_I





L1: for { if iterator.HasNext__Z() {
	var f any; _ = f; f = A2g_Missing[any]("class java.net.ContentHandlerFactory is not in the closed world")
	handler = A2g_Missing[ContentHandler_I]("class java.net.ContentHandlerFactory is not in the closed world")
	if !(handler == nil) { break L1 }
//line :296:1
	continue L1 }; break L1 }
//line :290:1
	return handler
}










func (t *URLConnection) Impl_TypeToPackageName_String__String(this URLConnection_I, contentType *String) *String {
	var tmp1 *String = contentType; var tmp2 *Locale; Locale_Init(); tmp2 = Locale_ROOT; contentType = NN(tmp1).ToLowerCase_Locale__String(tmp2)
	var len_ int32 = NN(contentType).Length__I(); var nm *CharArray = NewCharArray(len_)

	NN(contentType).GetChars_I_I_C1_I__V(0, len_, nm, 0)
	var i int32 = 0; L1: for {
		if i < len_ {
			var c uint16 = nm.A[i]
			if int32(c) == 47 {
				nm.A[i] = 46; i = i + 1; continue L1 } else {
//line :310:1
					var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool

					tmp6 = 65 <= int32(c); if tmp6 { tmp6 = int32(c) <= 90 }; tmp5 = tmp6; if !tmp5 { var tmp7 bool; tmp7 = 97 <= int32(c); if tmp7 { tmp7 = int32(c) <= 122 }; tmp5 = tmp7 }; tmp4 = tmp5; if !tmp4 {
						var tmp8 bool; tmp8 = 48 <= int32(c); if tmp8 { tmp8 = int32(c) <= 57 }; tmp4 = tmp8 }
//line :312:1
					tmp3 = tmp4
//line :310:1
					if !tmp3 {



						nm.A[i] = 95; i = i + 1; continue L1 } else {
							i = i + 1; continue L1 } } }
//line :307:1
		break L1
	}







	return String_New_C1(nm)
}
func (t *URLConnection) Impl_GetContentHandlerPkgPrefixes__String(this URLConnection_I) *String {
	var packagePrefixList *String = System_GetProperty_String_String__String(Lit_1445, Lit_69)
	if packagePrefixList == Lit_69 { } else {
		packagePrefixList = Concat(packagePrefixList, Lit_1448) }
	return Concat(packagePrefixList, Lit_1444)
}
func URLConnection_GuessContentTypeFromName_String__String(fname *String) *String { URLConnection_Init()
	return URLConnection_GetFileNameMap__FileNameMap().GetContentTypeFor_String__String(fname)
}
func URLConnection_GuessContentTypeFromStream_InputStream__String(is InputStream_I) *String { URLConnection_Init()
	if !is.MarkSupported__Z() { return nil } else {
		is.Mark_I__V(16)
		var c1 int32 = is.Read__I(); var c2 int32 = is.Read__I(); var c3 int32 = is.Read__I(); var c4 int32 = is.Read__I(); var c5 int32 = is.Read__I(); var c6 int32 = is.Read__I(); var c7 int32 = is.Read__I(); var c8 int32 = is.Read__I(); var c9 int32 = is.Read__I(); var c10 int32 = is.Read__I(); var c11 int32 = is.Read__I(); var c12 int32 = is.Read__I(); var c13 int32 = is.Read__I(); var c14 int32 = is.Read__I(); var c15 int32 = is.Read__I(); var c16 int32 = is.Read__I()















		is.Reset__V()
		var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool
		tmp4 = c1 == 202; if tmp4 { tmp4 = c2 == 254 }; tmp3 = tmp4; if tmp3 { tmp3 = c3 == 186 }; tmp2 = tmp3; if tmp2 { tmp2 = c4 == 190 }; tmp1 = tmp2
//line :347:1
		if tmp1 { return Lit_1449 } else { var tmp5 bool; var tmp6 bool


			tmp6 = c1 == 172; if tmp6 { tmp6 = c2 == 237 }; tmp5 = tmp6
//line :347:1
			if tmp5 { return Lit_1450 } else {





				if c1 == 60 {
					var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = c2 == 33; if !tmp9 {
						var tmp10 bool; var tmp11 bool; tmp11 = c2 == 104; if tmp11 {
							var tmp12 bool; var tmp13 bool; var tmp14 bool; tmp14 = c3 == 116; if tmp14 { tmp14 = c4 == 109 }; tmp13 = tmp14; if tmp13 { tmp13 = c5 == 108 }; tmp12 = tmp13; if !tmp12 {
								var tmp15 bool; var tmp16 bool; tmp16 = c3 == 101; if tmp16 { tmp16 = c4 == 97 }; tmp15 = tmp16; if tmp15 { tmp15 = c5 == 100 }; tmp12 = tmp15 }
//line :356:1
							tmp11 = tmp12 }
//line :355:1
						tmp10 = tmp11; if !tmp10 {


							var tmp17 bool; var tmp18 bool; var tmp19 bool; tmp19 = c2 == 98; if tmp19 { tmp19 = c3 == 111 }; tmp18 = tmp19; if tmp18 { tmp18 = c4 == 100 }; tmp17 = tmp18; if tmp17 { tmp17 = c5 == 121 }; tmp10 = tmp17 }
//line :355:1
						tmp9 = tmp10 }
//line :354:1
					tmp8 = tmp9; if !tmp8 {




						var tmp20 bool; var tmp21 bool; tmp21 = c2 == 72; if tmp21 {
							var tmp22 bool; var tmp23 bool; var tmp24 bool; tmp24 = c3 == 84; if tmp24 { tmp24 = c4 == 77 }; tmp23 = tmp24; if tmp23 { tmp23 = c5 == 76 }; tmp22 = tmp23; if !tmp22 {
								var tmp25 bool; var tmp26 bool; tmp26 = c3 == 69; if tmp26 { tmp26 = c4 == 65 }; tmp25 = tmp26; if tmp25 { tmp25 = c5 == 68 }; tmp22 = tmp25 }
//line :360:1
							tmp21 = tmp22 }
//line :359:1
						tmp20 = tmp21; if !tmp20 {


							var tmp27 bool; var tmp28 bool; var tmp29 bool; tmp29 = c2 == 66; if tmp29 { tmp29 = c3 == 79 }; tmp28 = tmp29; if tmp28 { tmp28 = c4 == 68 }; tmp27 = tmp28; if tmp27 { tmp27 = c5 == 89 }; tmp20 = tmp27 }
//line :359:1
						tmp8 = tmp20 }
//line :354:1
					tmp7 = tmp8; if tmp7 {








						return Lit_1451 }
					var tmp30 bool; var tmp31 bool; var tmp32 bool; var tmp33 bool; var tmp34 bool; tmp34 = c2 == 63; if tmp34 { tmp34 = c3 == 120 }; tmp33 = tmp34; if tmp33 { tmp33 = c4 == 109 }; tmp32 = tmp33; if tmp32 { tmp32 = c5 == 108 }; tmp31 = tmp32; if tmp31 {
						tmp31 = c6 == 32 }
//line :364:1
					tmp30 = tmp31; if tmp30 {

						return Lit_1452 } }
				var tmp35 bool; var tmp36 bool; var tmp37 bool; tmp37 = c1 == 239; if tmp37 { tmp37 = c2 == 187 }; tmp36 = tmp37; if tmp36 { tmp36 = c3 == 191 }; tmp35 = tmp36; if tmp35 {
					var tmp38 bool; var tmp39 bool; var tmp40 bool; tmp40 = c4 == 60; if tmp40 { tmp40 = c5 == 63 }; tmp39 = tmp40; if tmp39 { tmp39 = c6 == 120 }; tmp38 = tmp39; if tmp38 { return Lit_1452 } }
				var tmp41 bool; var tmp42 bool; tmp42 = c1 == 254; if tmp42 { tmp42 = c2 == 255 }; tmp41 = tmp42; if tmp41 {
					var tmp43 bool; var tmp44 bool; var tmp45 bool; var tmp46 bool; var tmp47 bool; var tmp48 bool; tmp48 = c3 == 0; if tmp48 { tmp48 = c4 == 60 }; tmp47 = tmp48; if tmp47 { tmp47 = c5 == 0 }; tmp46 = tmp47; if tmp46 { tmp46 = c6 == 63 }; tmp45 = tmp46; if tmp45 {
						tmp45 = c7 == 0 }
//line :370:1
					tmp44 = tmp45; if tmp44 {

						tmp44 = c8 == 120 }
//line :370:1
					tmp43 = tmp44; if tmp43 {


						return Lit_1452 } }
				var tmp49 bool; var tmp50 bool; tmp50 = c1 == 255; if tmp50 { tmp50 = c2 == 254 }; tmp49 = tmp50; if tmp49 {
					var tmp51 bool; var tmp52 bool; var tmp53 bool; var tmp54 bool; var tmp55 bool; var tmp56 bool; tmp56 = c3 == 60; if tmp56 { tmp56 = c4 == 0 }; tmp55 = tmp56; if tmp55 { tmp55 = c5 == 63 }; tmp54 = tmp55; if tmp54 { tmp54 = c6 == 0 }; tmp53 = tmp54; if tmp53 {
						tmp53 = c7 == 120 }
//line :375:1
					tmp52 = tmp53; if tmp52 {

						tmp52 = c8 == 0 }
//line :375:1
					tmp51 = tmp52; if tmp51 {


						return Lit_1452 } }
				var tmp57 bool; var tmp58 bool; var tmp59 bool; var tmp60 bool; tmp60 = c1 == 0; if tmp60 { tmp60 = c2 == 0 }; tmp59 = tmp60; if tmp59 { tmp59 = c3 == 254 }; tmp58 = tmp59; if tmp58 { tmp58 = c4 == 255 }; tmp57 = tmp58; if tmp57 {
					var tmp61 bool; var tmp62 bool; var tmp63 bool; var tmp64 bool; var tmp65 bool; var tmp66 bool; var tmp67 bool; var tmp68 bool; var tmp69 bool; var tmp70 bool; var tmp71 bool; var tmp72 bool



					tmp72 = c5 == 0; if tmp72 { tmp72 = c6 == 0 }; tmp71 = tmp72; if tmp71 { tmp71 = c7 == 0 }; tmp70 = tmp71
//line :383:1
					if tmp70 {

						tmp70 = c8 == 60 }
//line :383:1
					tmp69 = tmp70
//line :382:1
					if tmp69 {



						tmp69 = c9 == 0 }
//line :382:1
					tmp68 = tmp69
//line :381:1
					if tmp68 {





						tmp68 = c10 == 0 }
//line :381:1
					tmp67 = tmp68
//line :380:1
					if tmp67 {







						tmp67 = c11 == 0 }
//line :380:1
					tmp66 = tmp67; if tmp66 {








						tmp66 = c12 == 63 }
//line :380:1
					tmp65 = tmp66; if tmp65 {









						tmp65 = c13 == 0 }
//line :380:1
					tmp64 = tmp65; if tmp64 {










						tmp64 = c14 == 0 }
//line :380:1
					tmp63 = tmp64; if tmp63 {











						tmp63 = c15 == 0 }
//line :380:1
					tmp62 = tmp63; if tmp62 {












						tmp62 = c16 == 120 }
//line :380:1
					tmp61 = tmp62; if tmp61 {













						return Lit_1452 } }
				var tmp73 bool; var tmp74 bool; var tmp75 bool; var tmp76 bool; tmp76 = c1 == 255; if tmp76 { tmp76 = c2 == 254 }; tmp75 = tmp76; if tmp75 { tmp75 = c3 == 0 }; tmp74 = tmp75; if tmp74 { tmp74 = c4 == 0 }; tmp73 = tmp74; if tmp73 {
					var tmp77 bool; var tmp78 bool; var tmp79 bool; var tmp80 bool; var tmp81 bool; var tmp82 bool; var tmp83 bool; var tmp84 bool; var tmp85 bool; var tmp86 bool; var tmp87 bool; var tmp88 bool



					tmp88 = c5 == 60; if tmp88 { tmp88 = c6 == 0 }; tmp87 = tmp88; if tmp87 { tmp87 = c7 == 0 }; tmp86 = tmp87
//line :399:1
					if tmp86 {

						tmp86 = c8 == 0 }
//line :399:1
					tmp85 = tmp86
//line :398:1
					if tmp85 {



						tmp85 = c9 == 63 }
//line :398:1
					tmp84 = tmp85
//line :397:1
					if tmp84 {





						tmp84 = c10 == 0 }
//line :397:1
					tmp83 = tmp84
//line :396:1
					if tmp83 {







						tmp83 = c11 == 0 }
//line :396:1
					tmp82 = tmp83; if tmp82 {








						tmp82 = c12 == 0 }
//line :396:1
					tmp81 = tmp82; if tmp81 {









						tmp81 = c13 == 120 }
//line :396:1
					tmp80 = tmp81; if tmp80 {










						tmp80 = c14 == 0 }
//line :396:1
					tmp79 = tmp80; if tmp79 {











						tmp79 = c15 == 0 }
//line :396:1
					tmp78 = tmp79; if tmp78 {












						tmp78 = c16 == 0 }
//line :396:1
					tmp77 = tmp78; if tmp77 {













						return Lit_1452 } }
				var tmp89 bool; var tmp90 bool; var tmp91 bool; var tmp92 bool
				tmp92 = c1 == 71; if tmp92 { tmp92 = c2 == 73 }; tmp91 = tmp92; if tmp91 { tmp91 = c3 == 70 }; tmp90 = tmp91; if tmp90 { tmp90 = c4 == 56 }; tmp89 = tmp90
//line :411:1
				if tmp89 { return Lit_1453 } else { var tmp93 bool; var tmp94 bool; var tmp95 bool; var tmp96 bool

					tmp96 = c1 == 35; if tmp96 { tmp96 = c2 == 100 }; tmp95 = tmp96; if tmp95 { tmp95 = c3 == 101 }; tmp94 = tmp95; if tmp94 { tmp94 = c4 == 102 }; tmp93 = tmp94
//line :411:1
					if tmp93 { return Lit_1454 } else { var tmp97 bool; var tmp98 bool; var tmp99 bool; var tmp100 bool; var tmp101 bool; var tmp102 bool


						tmp102 = c1 == 33; if tmp102 { tmp102 = c2 == 32 }; tmp101 = tmp102; if tmp101 { tmp101 = c3 == 88 }; tmp100 = tmp101; if tmp100 { tmp100 = c4 == 80 }; tmp99 = tmp100; if tmp99 {
							tmp99 = c5 == 77 }
//line :414:1
						tmp98 = tmp99; if tmp98 {

							tmp98 = c6 == 50 }
//line :414:1
						tmp97 = tmp98
//line :411:1
						if tmp97 { return Lit_1455 } else { var tmp103 bool; var tmp104 bool; var tmp105 bool; var tmp106 bool; var tmp107 bool; var tmp108 bool; var tmp109 bool; var tmp110 bool






							tmp110 = c1 == 137; if tmp110 { tmp110 = c2 == 80 }; tmp109 = tmp110; if tmp109 { tmp109 = c3 == 78 }; tmp108 = tmp109; if tmp108 { tmp108 = c4 == 71 }; tmp107 = tmp108; if tmp107 {
								tmp107 = c5 == 13 }
//line :418:1
							tmp106 = tmp107; if tmp106 {

								tmp106 = c6 == 10 }
//line :418:1
							tmp105 = tmp106; if tmp105 {


								tmp105 = c7 == 26 }
//line :418:1
							tmp104 = tmp105; if tmp104 {



								tmp104 = c8 == 10 }
//line :418:1
							tmp103 = tmp104
//line :411:1
							if tmp103 { return Lit_1456 } else {














								var tmp111 bool; var tmp112 bool; var tmp113 bool; tmp113 = c1 == 255; if tmp113 { tmp113 = c2 == 216 }; tmp112 = tmp113; if tmp112 { tmp112 = c3 == 255 }; tmp111 = tmp112; if tmp111 {
									var tmp114 bool; var tmp115 bool; tmp115 = c4 == 224; if !tmp115 { tmp115 = c4 == 238 }; tmp114 = tmp115; if tmp114 { return Lit_1457 }
									var tmp116 bool; var tmp117 bool; tmp117 = c4 == 225; if tmp117 {
										var tmp118 bool; var tmp119 bool; var tmp120 bool; var tmp121 bool; tmp121 = c7 == 69; if tmp121 { tmp121 = c8 == 120 }; tmp120 = tmp121; if tmp120 { tmp120 = c9 == 105 }; tmp119 = tmp120; if tmp119 { tmp119 = c10 == 102 }; tmp118 = tmp119; if tmp118 {
											tmp118 = c11 == 0 }
//line :429:1
										tmp117 = tmp118 }
//line :428:1
									tmp116 = tmp117; if tmp116 {


										return Lit_1457 } }
								var tmp122 bool; var tmp123 bool; var tmp124 bool; var tmp125 bool; var tmp126 bool; tmp126 = c1 == 73; if tmp126 { tmp126 = c2 == 73 }; tmp125 = tmp126; if tmp125 { tmp125 = c3 == 42 }; tmp124 = tmp125; if tmp124 { tmp124 = c4 == 0 }; tmp123 = tmp124; if !tmp123 {
									var tmp127 bool; var tmp128 bool; var tmp129 bool; tmp129 = c1 == 77; if tmp129 { tmp129 = c2 == 77 }; tmp128 = tmp129; if tmp128 { tmp128 = c3 == 0 }; tmp127 = tmp128; if tmp127 { tmp127 = c4 == 42 }; tmp123 = tmp127 }
//line :432:1
								tmp122 = tmp123; if tmp122 { return Lit_1458 } else {



									var tmp130 bool; var tmp131 bool; var tmp132 bool; var tmp133 bool; var tmp134 bool; var tmp135 bool; var tmp136 bool; var tmp137 bool


									tmp137 = c1 == 208; if tmp137 { tmp137 = c2 == 207 }; tmp136 = tmp137
//line :438:1
									if tmp136 {

										tmp136 = c3 == 17 }
//line :438:1
									tmp135 = tmp136
//line :437:1
									if tmp135 {



										tmp135 = c4 == 224 }
//line :437:1
									tmp134 = tmp135
//line :436:1
									if tmp134 {





										tmp134 = c5 == 161 }
//line :436:1
									tmp133 = tmp134; if tmp133 {






										tmp133 = c6 == 177 }
//line :436:1
									tmp132 = tmp133; if tmp132 {







										tmp132 = c7 == 26 }
//line :436:1
									tmp131 = tmp132; if tmp131 {








										tmp131 = c8 == 225 }
//line :436:1
									tmp130 = tmp131; if tmp130 {









										if URLConnection_Checkfpx_InputStream__Z(is) { return Lit_1459 } }
									var tmp138 bool; var tmp139 bool; var tmp140 bool; var tmp141 bool
									tmp141 = c1 == 46; if tmp141 { tmp141 = c2 == 115 }; tmp140 = tmp141; if tmp140 { tmp140 = c3 == 110 }; tmp139 = tmp140; if tmp139 { tmp139 = c4 == 100 }; tmp138 = tmp139
//line :447:1
									if tmp138 { return Lit_1460 } else { var tmp142 bool; var tmp143 bool; var tmp144 bool; var tmp145 bool


										tmp145 = c1 == 100; if tmp145 { tmp145 = c2 == 110 }; tmp144 = tmp145; if tmp144 { tmp144 = c3 == 115 }; tmp143 = tmp144; if tmp143 { tmp143 = c4 == 46 }; tmp142 = tmp143
//line :447:1
										if tmp142 { return Lit_1460 } else { var tmp146 bool; var tmp147 bool; var tmp148 bool; var tmp149 bool




											tmp149 = c1 == 82; if tmp149 { tmp149 = c2 == 73 }; tmp148 = tmp149; if tmp148 { tmp148 = c3 == 70 }; tmp147 = tmp148; if tmp147 { tmp147 = c4 == 70 }; tmp146 = tmp147
//line :447:1
											if tmp146 { return Lit_1461 } else { return nil
											}
										}
									}
								}
							}
						}
					} } } } } }
func URLConnection_Checkfpx_InputStream__Z(is InputStream_I) bool { URLConnection_Init()
	is.Mark_I__V(256)
	var toSkip int64 = 28; var posn int64 = 0; var tmp1 int64

	posn = URLConnection_SkipForward_InputStream_J__J(is, toSkip); tmp1 = posn; if tmp1 < toSkip {
		is.Reset__V(); return false } else {
			var c *IntArray = NewIntArray(16)
			if URLConnection_ReadBytes_I1_I_InputStream__I(c, 2, is) < 0 {
				is.Reset__V(); return false } else {
					var byteOrder int32 = c.A[0]
					posn = posn + 2
					var uSectorShift int32 = 0
					if URLConnection_ReadBytes_I1_I_InputStream__I(c, 2, is) < 0 {
						is.Reset__V(); return false } else {

							if byteOrder == 254 {

								uSectorShift = c.A[0]
								uSectorShift = uSectorShift + c.A[1]<<8 } else {




									uSectorShift = c.A[0] << 8
									uSectorShift = uSectorShift + c.A[1] }
							posn = posn + 2
							toSkip = 48 - posn
							var skipped int64 = 0; var tmp2 int64
							skipped = URLConnection_SkipForward_InputStream_J__J(is, toSkip); tmp2 = skipped; if tmp2 < toSkip {
								is.Reset__V(); return false } else {

									posn = posn + skipped
									if URLConnection_ReadBytes_I1_I_InputStream__I(c, 4, is) < 0 {
										is.Reset__V(); return false } else {
											var sectDirStart int32 = 0
											if byteOrder == 254 {

												sectDirStart = c.A[0]
												sectDirStart = sectDirStart + c.A[1]<<8




												sectDirStart = sectDirStart + c.A[2]<<16




												sectDirStart = sectDirStart + c.A[3]<<24 } else {





													sectDirStart = c.A[0] << 24
													sectDirStart = sectDirStart + c.A[1]<<16




													sectDirStart = sectDirStart + c.A[2]<<8




													sectDirStart = sectDirStart + c.A[3]
												}

											posn = posn + 4
											is.Reset__V()
											toSkip = 512 + int64(1<<(uSectorShift&31))*int64(sectDirStart) + 80







											if toSkip < 0 { return false } else {


												is.Mark_I__V(int32(toSkip) + 48)


												if URLConnection_SkipForward_InputStream_J__J(is, toSkip) < toSkip {

													is.Reset__V(); return false } else {
//line :539:1
														if URLConnection_ReadBytes_I1_I_InputStream__I(c, 16, is) < 0 {



															is.Reset__V(); return false } else {
//line :539:1
																var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 bool



















																tmp18 = byteOrder == 254
//line :558:1
																if tmp18 {

																	tmp18 = c.A[0] == 0 }
//line :558:1
																tmp17 = tmp18
//line :557:1
																if tmp17 {



																	tmp17 = c.A[2] == 97 }
//line :557:1
																tmp16 = tmp17
//line :556:1
																if tmp16 {





																	tmp16 = c.A[3] == 86 }
//line :556:1
																tmp15 = tmp16
//line :555:1
																if tmp15 {







																	tmp15 = c.A[4] == 84 }
//line :555:1
																tmp14 = tmp15
//line :554:1
																if tmp14 {









																	tmp14 = c.A[5] == 193 }
//line :554:1
																tmp13 = tmp14
//line :553:1
																if tmp13 {











																	tmp13 = c.A[6] == 206 }
//line :553:1
																tmp12 = tmp13
//line :552:1
																if tmp12 {













																	tmp12 = c.A[7] == 17 }
//line :552:1
																tmp11 = tmp12
//line :551:1
																if tmp11 {















																	tmp11 = c.A[8] == 133 }
//line :551:1
																tmp10 = tmp11
//line :550:1
																if tmp10 {

















																	tmp10 = c.A[9] == 83 }
//line :550:1
																tmp9 = tmp10
//line :549:1
																if tmp9 {



















																	tmp9 = c.A[10] == 0 }
//line :549:1
																tmp8 = tmp9
//line :548:1
																if tmp8 {





















																	tmp8 = c.A[11] == 170 }
//line :548:1
																tmp7 = tmp8
//line :547:1
																if tmp7 {























																	tmp7 = c.A[12] == 0 }
//line :547:1
																tmp6 = tmp7
//line :546:1
																if tmp6 {

























																	tmp6 = c.A[13] == 161 }
//line :546:1
																tmp5 = tmp6
//line :545:1
																if tmp5 {



























																	tmp5 = c.A[14] == 249 }
//line :545:1
																tmp4 = tmp5
//line :544:1
																if tmp4 {





























																	tmp4 = c.A[15] == 91 }
//line :544:1
																tmp3 = tmp4
//line :539:1
																if tmp3 {



































																	is.Reset__V(); return true } else {
//line :539:1
																		var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; var tmp23 bool; var tmp24 bool; var tmp25 bool; var tmp26 bool; var tmp27 bool; var tmp28 bool; var tmp29 bool; var tmp30 bool; var tmp31 bool; var tmp32 bool; var tmp33 bool


















































																		tmp33 = c.A[3] == 0
//line :589:1
																		if tmp33 {

																			tmp33 = c.A[1] == 97 }
//line :589:1
																		tmp32 = tmp33
//line :588:1
																		if tmp32 {



																			tmp32 = c.A[0] == 86 }
//line :588:1
																		tmp31 = tmp32
//line :587:1
																		if tmp31 {





																			tmp31 = c.A[5] == 84 }
//line :587:1
																		tmp30 = tmp31
//line :586:1
																		if tmp30 {







																			tmp30 = c.A[4] == 193 }
//line :586:1
																		tmp29 = tmp30
//line :585:1
																		if tmp29 {









																			tmp29 = c.A[7] == 206 }
//line :585:1
																		tmp28 = tmp29
//line :584:1
																		if tmp28 {











																			tmp28 = c.A[6] == 17 }
//line :584:1
																		tmp27 = tmp28
//line :583:1
																		if tmp27 {













																			tmp27 = c.A[8] == 133 }
//line :583:1
																		tmp26 = tmp27
//line :582:1
																		if tmp26 {















																			tmp26 = c.A[9] == 83 }
//line :582:1
																		tmp25 = tmp26
//line :581:1
																		if tmp25 {

















																			tmp25 = c.A[10] == 0 }
//line :581:1
																		tmp24 = tmp25
//line :580:1
																		if tmp24 {



















																			tmp24 = c.A[11] == 170 }
//line :580:1
																		tmp23 = tmp24
//line :579:1
																		if tmp23 {





















																			tmp23 = c.A[12] == 0 }
//line :579:1
																		tmp22 = tmp23
//line :578:1
																		if tmp22 {























																			tmp22 = c.A[13] == 161 }
//line :578:1
																		tmp21 = tmp22
//line :577:1
																		if tmp21 {

























																			tmp21 = c.A[14] == 249 }
//line :577:1
																		tmp20 = tmp21
//line :576:1
																		if tmp20 {



























																			tmp20 = c.A[15] == 91 }
//line :576:1
																		tmp19 = tmp20
//line :539:1
																		if tmp19 {

































































																			is.Reset__V(); return true } else {
																				is.Reset__V(); return false
																			} } } } } } } } } } }
func URLConnection_ReadBytes_I1_I_InputStream__I(c *IntArray, len_ int32, is InputStream_I) int32 { URLConnection_Init()
	var buf *ByteArray = NewByteArray(len_)
	if is.Read_B1_I_I__I(buf, 0, len_) < len_ { return -1 } else {


		var i int32 = 0; L1: for {
			if i < len_ {
				c.A[i] = int32(buf.A[i]) & 255
				i = i + 1; continue L1 }
//line :613:1
			break L1 }
//line :612:1
		return 0
	}
}




func URLConnection_SkipForward_InputStream_J__J(is InputStream_I, toSkip int64) int64 { URLConnection_Init()
	var eachSkip int64 = 0
	var skipped int64 = 0
L1: for { if !(skipped == toSkip) {
	eachSkip = is.Skip_J__J(toSkip - skipped)
	if eachSkip <= 0 {
		if is.Read__I() == -1 { return skipped } else { skipped = skipped + 1 } }
	skipped = skipped + eachSkip
//line :622:1
	continue L1 }; break L1 }
//line :620:1
	return skipped
}







func (t *URLConnection) Impl_CheckConnected__V(this URLConnection_I) {
	if t.F_connected { panic(Thrown(IllegalStateException_New_String(Lit_1352)))
	}
}

type URLConnection struct{ Object; F_url *URL; F_doInput, F_doOutput, F_allowUserInteraction, F_useCaches bool; F_ifModifiedSince int64; F_connected bool; F_connectTimeout, F_readTimeout int32; F_requests *MessageHeader }

type URLConnection_I interface{ Object_I; Self_URLConnection() *URLConnection; Connect__V(); SetConnectTimeout_I__V(p0 int32); GetConnectTimeout__I() int32; SetReadTimeout_I__V(p0 int32); GetReadTimeout__I() int32; GetURL__URL() *URL; GetContentLength__I() int32; GetContentLengthLong__J() int64; GetContentType__String() *String; GetContentEncoding__String() *String; GetExpiration__J() int64; GetDate__J() int64; GetLastModified__J() int64; GetHeaderField_String__String(p0 *String) *String; GetHeaderFields__Map() Map; GetHeaderFieldInt_String_I__I(p0 *String, p1 int32) int32; GetHeaderFieldLong_String_J__J(p0 *String, p1 int64) int64; GetHeaderFieldDate_String_J__J(p0 *String, p1 int64) int64; GetHeaderFieldKey_I__String(p0 int32) *String; GetHeaderField_I__String(p0 int32) *String; GetContent__O() any; GetContent_Class1__O(p0 *RefArray) any; GetInputStream__InputStream() InputStream_I; GetOutputStream__OutputStream() OutputStream_I; SetDoInput_Z__V(p0 bool); GetDoInput__Z() bool; SetDoOutput_Z__V(p0 bool); GetDoOutput__Z() bool; SetAllowUserInteraction_Z__V(p0 bool); GetAllowUserInteraction__Z() bool; SetUseCaches_Z__V(p0 bool); GetUseCaches__Z() bool; SetIfModifiedSince_J__V(p0 int64); GetIfModifiedSince__J() int64; GetDefaultUseCaches__Z() bool; SetDefaultUseCaches_Z__V(p0 bool); SetRequestProperty_String_String__V(p0, p1 *String); AddRequestProperty_String_String__V(p0, p1 *String); GetRequestProperty_String__String(p0 *String) *String; GetRequestProperties__Map() Map }

func (t *URLConnection) Self_URLConnection() *URLConnection { return t }

var URLConnection_defaultAllowUserInteraction bool

var URLConnection_defaultUseCaches atomic.Bool

var URLConnection_defaultCaching *ConcurrentHashMap

var URLConnection_fileNameMap Volatile[FileNameMap]

var URLConnection_handlers Hashtable_I

var URLConnection_contentClassPrefix *String = Lit_1444

var URLConnection_contentPathProp *String = Lit_1445

var URLConnection_init ClassInit

func URLConnection_Init() { if !URLConnection_init.Done() { URLConnection_init.Run(URLConnection_clinit) } }

func URLConnection_clinit() { URLConnection_defaultAllowUserInteraction = false; URLConnection_defaultUseCaches.Store(true); URLConnection_defaultCaching = ConcurrentHashMap_New(); URLConnection_handlers = Hashtable_New() }

func URLConnection_InstanceOf(x any) bool { _, ok := x.(URLConnection_I); return ok }

func URLConnection_Cast(x any) URLConnection_I { if x == nil { return nil }; v, ok := x.(URLConnection_I); if !ok { panic(ClassCast(x, URLConnection_class)) }; return v }



type URLConnection_1 struct{ Object }

func (t *URLConnection_1) Is_FileNameMap() {}

func URLConnection_1_New() *URLConnection_1 { t := &URLConnection_1{}; t.Ctor(); return t }

func (t *URLConnection_1) Ctor() {}

func (t *URLConnection_1) Ref() any { if t == nil { return nil }; return t }

func (t *URLConnection_1) GetClass__Class() *Class { return URLConnection_1_class }

func (t *URLConnection_1) ToString__String() *String { return Object_toString(t) }

func (t *URLConnection_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URLConnection_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func URLConnection_1_InstanceOf(x any) bool { _, ok := x.(*URLConnection_1); return ok }

func URLConnection_1_Cast(x any) *URLConnection_1 { if x == nil { return nil }; v, ok := x.(*URLConnection_1); if !ok { panic(ClassCast(x, URLConnection_1_class)) }; return v }
