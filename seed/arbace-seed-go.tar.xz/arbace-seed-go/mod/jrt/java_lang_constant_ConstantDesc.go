//line java_lang_constant_ConstantDesc.ae:1
package jrt






type ConstantDesc interface{ Object_I; Is_ConstantDesc() }

func ConstantDesc_InstanceOf(x any) bool { _, ok := x.(ConstantDesc); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ConstantDesc_class) } }; return ok }

func ConstantDesc_Cast(x any) ConstantDesc { if x == nil { return nil }; v, ok := x.(ConstantDesc); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ConstantDesc_class) } }; if !ok { panic(ClassCast(x, ConstantDesc_class)) }; return v }
