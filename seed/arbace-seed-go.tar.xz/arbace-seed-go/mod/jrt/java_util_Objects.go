//line java_util_Objects.ae:1
package jrt








func Objects_New() *Objects { t := &Objects{}; t.Ctor(); return t }
//line :10:1
func (t *Objects) Ctor() { panic(A2g_NotTranslated("java.util.Objects.<init>()V")) }


func Objects_Equals_O_O__Z(a, b any) bool {
	var tmp1 bool; tmp1 = a == b; if !tmp1 { var tmp2 bool; tmp2 = !(a == nil); if tmp2 { tmp2 = Equals(a, b) }; tmp1 = tmp2 }; return tmp1
}
func Objects_DeepEquals_O_O__Z(a, b any) bool {
	if a == b { return true } else { var tmp1 bool; var tmp2 bool; tmp2 = a == nil; if !tmp2 { tmp2 = b == nil }; tmp1 = tmp2; if tmp1 { return false } else { return Arrays_DeepEquals0_O_O__Z(a, b)
	} } }
func Objects_HashCode_O__I(o any) int32 {
	if !(o == nil) { return HashCode(o) } else { return 0
	} }
func Objects_Hash_O1__I(values *RefArray) int32 {
	return Arrays_HashCode_O1__I(values)
}
func Objects_ToString_O__String(o any) *String { return String_ValueOf_O__String(o) }

func Objects_ToString_O_String__String(o any, nullDefault *String) *String {
	if !(o == nil) { return ToString(o) } else { return nullDefault
	} }
func Objects_ToIdentityString_O__String(o any) *String {
	Objects_RequireNonNull_O__O(o)
	return Concat(NN(GetClass(o)).GetName__String(), Lit_1401, Integer_ToHexString_I__String(System_IdentityHashCode_O__I(o)))
}
func Objects_Compare_O_O_Comparator__I(a, b any, c Comparator) int32 {

	if a == b { return 0 } else { return c.Compare_O_O__I(a, b)
	} }
func Objects_RequireNonNull_O__O(obj any) any {
	if obj == nil { panic(Thrown(NullPointerException_New())) }
//line :38:1
	return obj
}


func Objects_RequireNonNull_O_String__O(obj any, message *String) any {

	if obj == nil { panic(Thrown(NullPointerException_New_String(message))) }
//line :42:1
	return obj
}



func Objects_IsNull_O__Z(obj any) bool { return obj == nil }

func Objects_NonNull_O__Z(obj any) bool { return !(obj == nil) }

func Objects_RequireNonNullElse_O_O__O(obj, defaultObj any) any {
	if !(obj == nil) { return obj } else { return Objects_RequireNonNull_O_String__O(defaultObj, Lit_2790)
	} }
func Objects_RequireNonNullElseGet_O_Supplier__O(obj any, supplier Supplier) any {

	if !(obj == nil) { return obj } else {

		return Objects_RequireNonNull_O_String__O(Supplier_Cast(Objects_RequireNonNull_O_String__O(supplier, Lit_2791)).Get__O(), Lit_2792)
	}
}
func Objects_RequireNonNull_O_Supplier__O(obj any, messageSupplier Supplier) any {

	if obj == nil {
		var tmp1 *String
		if !(messageSupplier == nil) { tmp1 = String_Cast(messageSupplier.Get__O()) } else { tmp1 = nil }
//line :64:1
		panic(Thrown(NullPointerException_New_String(tmp1))) }
//line :61:1
	return obj
}





func Objects_CheckIndex_I_I__I(index, length int32) int32 {
	return Preconditions_CheckIndex_I_I_BiFunction__I(index, length, nil)
}
func Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, length int32) int32 {
	return Preconditions_CheckFromToIndex_I_I_I_BiFunction__I(fromIndex, toIndex, length, nil)
}
func Objects_CheckFromIndexSize_I_I_I__I(fromIndex, size, length int32) int32 {
	return Preconditions_CheckFromIndexSize_I_I_I_BiFunction__I(fromIndex, size, length, nil)
}
func Objects_CheckIndex_J_J__J(index, length int64) int64 {
	return Preconditions_CheckIndex_J_J_BiFunction__J(index, length, nil)
}
func Objects_CheckFromToIndex_J_J_J__J(fromIndex, toIndex, length int64) int64 {
	return Preconditions_CheckFromToIndex_J_J_J_BiFunction__J(fromIndex, toIndex, length, nil)
}
func Objects_CheckFromIndexSize_J_J_J__J(fromIndex, size, length int64) int64 {
	return Preconditions_CheckFromIndexSize_J_J_J_BiFunction__J(fromIndex, size, length, nil)
}


type Objects struct{ Object }

func (t *Objects) Ref() any { if t == nil { return nil }; return t }

func (t *Objects) GetClass__Class() *Class { return Objects_class }

func (t *Objects) ToString__String() *String { return Object_toString(t) }

func (t *Objects) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Objects) CloneShallow() any { panic(CloneNotSupported(t)) }

func Objects_InstanceOf(x any) bool { _, ok := x.(*Objects); return ok }

func Objects_Cast(x any) *Objects { if x == nil { return nil }; v, ok := x.(*Objects); if !ok { panic(ClassCast(x, Objects_class)) }; return v }
