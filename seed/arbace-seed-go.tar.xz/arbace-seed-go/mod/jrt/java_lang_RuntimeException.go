//line java_lang_RuntimeException.ae:1
package jrt








func RuntimeException_New() *RuntimeException { t := &RuntimeException{}; t.Ctor(t); return t }
//line :10:1
func (t *RuntimeException) Ctor(this RuntimeException_I) { t.Exception.Ctor(this) }

func RuntimeException_New_String(p0 *String) *RuntimeException { t := &RuntimeException{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *RuntimeException) Ctor_String(this RuntimeException_I, message *String) { t.Exception.Ctor_String(this, message) }

func RuntimeException_New_String_Throwable(p0 *String, p1 Throwable_I) *RuntimeException { t := &RuntimeException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :14:1
func (t *RuntimeException) Ctor_String_Throwable(this RuntimeException_I, message *String, cause Throwable_I) { t.Exception.Ctor_String_Throwable(this, message, cause) }


func RuntimeException_New_Throwable(p0 Throwable_I) *RuntimeException { t := &RuntimeException{}; t.Ctor_Throwable(t, p0); return t }
//line :17:1
func (t *RuntimeException) Ctor_Throwable(this RuntimeException_I, cause Throwable_I) { t.Exception.Ctor_Throwable(this, cause) }

func RuntimeException_New_String_Throwable_Z_Z(p0 *String, p1 Throwable_I, p2, p3 bool) *RuntimeException { t := &RuntimeException{}; t.Ctor_String_Throwable_Z_Z(t, p0, p1, p2, p3); return t }
//line :19:1
func (t *RuntimeException) Ctor_String_Throwable_Z_Z(this RuntimeException_I, message *String, cause Throwable_I, enableSuppression, writableStackTrace bool) { t.Exception.Ctor_String_Throwable_Z_Z(this, message, cause, enableSuppression, writableStackTrace) }












type RuntimeException struct{ Exception }

type RuntimeException_I interface{ Exception_I; Serializable; Self_RuntimeException() *RuntimeException }

func (t *RuntimeException) Self_RuntimeException() *RuntimeException { return t }

const RuntimeException_serialVersionUID int64 = -7034897190745766939

func (t *RuntimeException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *RuntimeException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *RuntimeException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *RuntimeException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *RuntimeException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *RuntimeException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *RuntimeException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *RuntimeException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *RuntimeException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *RuntimeException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *RuntimeException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *RuntimeException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *RuntimeException) Ref() any { if t == nil { return nil }; return t }

func (t *RuntimeException) GetClass__Class() *Class { return RuntimeException_class }

func (t *RuntimeException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *RuntimeException) CloneShallow() any { panic(CloneNotSupported(t)) }

func RuntimeException_InstanceOf(x any) bool { _, ok := x.(RuntimeException_I); return ok }

func RuntimeException_Cast(x any) RuntimeException_I { if x == nil { return nil }; v, ok := x.(RuntimeException_I); if !ok { panic(ClassCast(x, RuntimeException_class)) }; return v }
