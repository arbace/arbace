//line java_time_format_DateTimeTextProvider.ae:1
package jrt
























func (t *DateTimeTextProvider_1) Compare_Map_Entry_Map_Entry__I(obj1, obj2 Map_Entry) int32 {

	return NN(String_Cast(obj2.GetKey__O())).Length__I() - NN(String_Cast(obj1.GetKey__O())).Length__I()
}



func DateTimeTextProvider_New() *DateTimeTextProvider { DateTimeTextProvider_Init(); t := &DateTimeTextProvider{}; t.Ctor(t); return t }
//line :33:1
func (t *DateTimeTextProvider) Ctor(this DateTimeTextProvider_I) {}

func DateTimeTextProvider_GetInstance__DateTimeTextProvider() DateTimeTextProvider_I { DateTimeTextProvider_Init(); return DateTimeTextProvider_INSTANCE }

func (t *DateTimeTextProvider) Impl_GetText_TemporalField_J_TextStyle_Locale__String(this DateTimeTextProvider_I, field TemporalField, value int64, style *TextStyle, locale *Locale) *String {

	var store any = t.Impl_FindStore_TemporalField_Locale__O(this, field, locale)
	if DateTimeTextProvider_LocaleStore_InstanceOf(store) { return NN(DateTimeTextProvider_LocaleStore_Cast(store)).GetText_J_TextStyle__String(value, style) } else { return nil
	} }
func (t *DateTimeTextProvider) Impl_GetText_Chronology_TemporalField_J_TextStyle_Locale__String(this DateTimeTextProvider_I, chrono Chronology, field TemporalField, value int64, style *TextStyle, locale *Locale) *String {

	var tmp1 bool; var tmp2 bool; var tmp3 *IsoChronology; IsoChronology_Init(); tmp3 = IsoChronology_INSTANCE; tmp2 = any(chrono) == any(tmp3.Ref()); if !tmp2 { tmp2 = !ChronoField_InstanceOf(field) }; tmp1 = tmp2; if tmp1 {
		return this.GetText_TemporalField_J_TextStyle_Locale__String(field, value, style, locale) } else {
			var fieldIndex int32 = 0; var fieldValue int32 = 0; var tmp4 *ChronoField

			ChronoField_Init(); tmp4 = ChronoField_ERA; if any(field) == any(tmp4.Ref()) {


				fieldIndex = 0
				if any(chrono) == any(A2g_Missing[any]("class java.time.chrono.JapaneseChronology is not in the closed world")) {
					if value == -999 {
						fieldValue = 0 } else {
							fieldValue = int32(value) + 2 } } else {
								fieldValue = int32(value) } } else {
//line :48:1
									var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_MONTH_OF_YEAR; if any(field) == any(tmp5.Ref()) {










										fieldIndex = 2
										fieldValue = int32(value) - 1 } else {
//line :48:1
											var tmp6 *ChronoField; ChronoField_Init(); tmp6 = ChronoField_DAY_OF_WEEK; if any(field) == any(tmp6.Ref()) {














												fieldIndex = 7
												fieldValue = int32(value) + 1
												if fieldValue > 7 { fieldValue = 1 } } else {
//line :48:1
													var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_AMPM_OF_DAY; if any(field) == any(tmp7.Ref()) {


















														fieldIndex = 9; fieldValue = int32(value) } else {
															return nil } } } }
			return CalendarDataUtility_RetrieveJavaTimeFieldValueName_String_I_I_I_Locale__String(chrono.GetCalendarType__String(), fieldIndex, fieldValue, NN(style).ToCalendarStyle__I(), locale)
		}
}




func (t *DateTimeTextProvider) Impl_GetTextIterator_TemporalField_TextStyle_Locale__Iterator(this DateTimeTextProvider_I, field TemporalField, style *TextStyle, locale *Locale) Iterator {



	var store any = t.Impl_FindStore_TemporalField_Locale__O(this, field, locale)
	if DateTimeTextProvider_LocaleStore_InstanceOf(store) { return NN(DateTimeTextProvider_LocaleStore_Cast(store)).GetTextIterator_TextStyle__Iterator(style) } else { return nil
	} }
func (t *DateTimeTextProvider) Impl_GetTextIterator_Chronology_TemporalField_TextStyle_Locale__Iterator(this DateTimeTextProvider_I, chrono Chronology, field TemporalField, style *TextStyle, locale *Locale) Iterator {




	var tmp1 bool; var tmp2 bool; var tmp3 *IsoChronology; IsoChronology_Init(); tmp3 = IsoChronology_INSTANCE; tmp2 = any(chrono) == any(tmp3.Ref()); if !tmp2 { tmp2 = !ChronoField_InstanceOf(field) }; tmp1 = tmp2; if tmp1 {
		return this.GetTextIterator_TemporalField_TextStyle_Locale__Iterator(field, style, locale) } else {
			var fieldIndex int32 = 0
			switch NN(ChronoField_Cast(field)).F_ordinal { case 27:
				fieldIndex = 0; case 23:
				fieldIndex = 2; case 15:
				fieldIndex = 7; case 14:
				fieldIndex = 9; default:
				return nil}
			var calendarStyle int32; if style == nil { calendarStyle = 0 } else { calendarStyle = NN(style).ToCalendarStyle__I() }; var map_ Map = CalendarDataUtility_RetrieveJavaTimeFieldValueNames_String_I_I_Locale__Map(chrono.GetCalendarType__String(), fieldIndex, calendarStyle, locale)






			if !(map_ == nil) {
				var list List = ArrayList_New_I(map_.Size__I())
				switch fieldIndex { case 0:

					var i_101648 Iterator = map_.EntrySet__Set().Iterator__Iterator(); for i_101648.HasNext__Z() { var entry_2 Map_Entry = Map_Entry_Cast(i_101648.Next__O()); var era int32 = NN(Integer_Cast(entry_2.GetValue__O())).IntValue__I()

						if any(chrono) == any(A2g_Missing[any]("class java.time.chrono.JapaneseChronology is not in the closed world")) {
							if era == 0 { era = -999 } else { era = era - 2 } }
						list.Add_O__Z(DateTimeTextProvider_CreateEntry_O_O__Map_Entry(String_Cast(entry_2.GetKey__O()).Ref(), Long_ValueOf_J__Long(int64(era)))) }; case 2:




					var i_101649 Iterator = map_.EntrySet__Set().Iterator__Iterator(); for i_101649.HasNext__Z() { var entry_3 Map_Entry = Map_Entry_Cast(i_101649.Next__O())
						list.Add_O__Z(DateTimeTextProvider_CreateEntry_O_O__Map_Entry(String_Cast(entry_3.GetKey__O()).Ref(), Long_ValueOf_J__Long(int64(NN(Integer_Cast(entry_3.GetValue__O())).IntValue__I()+1)))) }; case 7:






					var i_101650 Iterator = map_.EntrySet__Set().Iterator__Iterator(); for i_101650.HasNext__Z() { var entry_4 Map_Entry = Map_Entry_Cast(i_101650.Next__O())
						list.Add_O__Z(DateTimeTextProvider_CreateEntry_O_O__Map_Entry(String_Cast(entry_4.GetKey__O()).Ref(), Long_ValueOf_J__Long(int64(DateTimeTextProvider_ToWeekDay_I__I(NN(Integer_Cast(entry_4.GetValue__O())).IntValue__I()))))) }; default:




					var i_101651 Iterator = map_.EntrySet__Set().Iterator__Iterator(); for i_101651.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101651.Next__O())
						list.Add_O__Z(DateTimeTextProvider_CreateEntry_O_O__Map_Entry(String_Cast(entry.GetKey__O()).Ref(), Long_ValueOf_J__Long(int64(NN(Integer_Cast(entry.GetValue__O())).IntValue__I()))))
					}
				}

				return list.Iterator__Iterator() } else {
//line :104:1
					return nil
				}
		}
}






























func (t *DateTimeTextProvider) Impl_FindStore_TemporalField_Locale__O(this DateTimeTextProvider_I, field TemporalField, locale *Locale) any {
	var key Map_Entry = DateTimeTextProvider_CreateEntry_O_O__Map_Entry(field, locale.Ref()); var store any = DateTimeTextProvider_CACHE.Get_O__O(key)



	if store == nil {
		store = t.Impl_CreateStore_TemporalField_Locale__O(this, field, locale)
		var existing any = DateTimeTextProvider_CACHE.PutIfAbsent_O_O__O(key, store)
		if !(existing == nil) { store = existing } }
//line :139:1
	return store
}








func DateTimeTextProvider_ToWeekDay_I__I(calWeekDay int32) int32 { DateTimeTextProvider_Init()
	if calWeekDay == 1 { return 7 } else { return calWeekDay - 1
	} }
func (t *DateTimeTextProvider) Impl_CreateStore_TemporalField_Locale__O(this DateTimeTextProvider_I, field TemporalField, locale *Locale) any {
	var styleMap Map = HashMap_New(); var tmp1 *ChronoField
	ChronoField_Init(); tmp1 = ChronoField_ERA; if any(field) == any(tmp1.Ref()) {


		var arr_101654 *RefArray = TextStyle_Values__TextStyle1(); var len_101655 int32 = int32(len(arr_101654.A)); var i_101656 int32 = 0; for ; i_101656 < len_101655; i_101656++ { var textStyle *TextStyle = As[*TextStyle](arr_101654.A[i_101656])
			if NN(textStyle).IsStandalone__Z() { } else {
				var displayNames Map = CalendarDataUtility_RetrieveJavaTimeFieldValueNames_String_I_I_Locale__Map(Lit_2313, 0, NN(textStyle).ToCalendarStyle__I(), locale)





				if !(displayNames == nil) {
					var map_ Map = HashMap_New(); var i_101657 Iterator = displayNames.EntrySet__Set().Iterator__Iterator(); for i_101657.HasNext__Z() {
						var entry Map_Entry = Map_Entry_Cast(i_101657.Next__O())
						map_.Put_O_O__O(Long_ValueOf_J__Long(int64(NN(Integer_Cast(entry.GetValue__O())).IntValue__I())), String_Cast(entry.GetKey__O()).Ref())
					}

					if map_.IsEmpty__Z() { } else { styleMap.Put_O_O__O(textStyle.Ref(), map_) } } } }
		return DateTimeTextProvider_LocaleStore_New_Map(styleMap) } else {
//line :154:1
			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; if any(field) == any(tmp2.Ref()) {




















				var arr_101658 *RefArray = TextStyle_Values__TextStyle1(); var len_101659 int32 = int32(len(arr_101658.A)); var i_101660 int32 = 0; for ; i_101660 < len_101659; i_101660++ { var textStyle_2 *TextStyle = As[*TextStyle](arr_101658.A[i_101660]); var map__2 Map = HashMap_New(); var tmp3 bool; var tmp4 bool; var tmp5 *TextStyle

					TextStyle_Init(); tmp5 = TextStyle_NARROW; tmp4 = NN(textStyle_2).Equals_O__Z(tmp5.Ref()); if !tmp4 {
						var tmp6 *TextStyle; TextStyle_Init(); tmp6 = TextStyle_NARROW_STANDALONE; tmp4 = NN(textStyle_2).Equals_O__Z(tmp6.Ref()) }
//line :177:1
					tmp3 = tmp4; if tmp3 {

						var month int32 = 0; L4: for {
							if month <= 11 {
								var name *String
								name = CalendarDataUtility_RetrieveJavaTimeFieldValueName_String_I_I_I_Locale__String(Lit_2313, 2, month, NN(textStyle_2).ToCalendarStyle__I(), locale)






								if !(name == nil) {
									map__2.Put_O_O__O(Long_ValueOf_J__Long(int64(month)+1), name.Ref())
									month = month + 1; continue L4 } }
//line :179:1
							break L4 } } else {












								var displayNames_2 Map = CalendarDataUtility_RetrieveJavaTimeFieldValueNames_String_I_I_Locale__Map(Lit_2313, 2, NN(textStyle_2).ToCalendarStyle__I(), locale)





								if !(displayNames_2 == nil) {
									var i_101661 Iterator = displayNames_2.EntrySet__Set().Iterator__Iterator(); for i_101661.HasNext__Z() { var entry_2 Map_Entry = Map_Entry_Cast(i_101661.Next__O())

										map__2.Put_O_O__O(Long_ValueOf_J__Long(int64(NN(Integer_Cast(entry_2.GetValue__O())).IntValue__I()+1)), String_Cast(entry_2.GetKey__O()).Ref()) } } else {




											var month_2 int32 = 0; L6: for {
												if month_2 <= 11 {
													var name_2 *String
													name_2 = CalendarDataUtility_RetrieveJavaTimeFieldValueName_String_I_I_I_Locale__String(Lit_2313, 2, month_2, NN(textStyle_2).ToCalendarStyle__I(), locale)






													if !(name_2 == nil) {
														map__2.Put_O_O__O(Long_ValueOf_J__Long(int64(month_2)+1), name_2.Ref())
														month_2 = month_2 + 1; continue L6 } }
//line :206:1
												break L6
											}
										}
							}









					if map__2.IsEmpty__Z() { } else { styleMap.Put_O_O__O(textStyle_2.Ref(), map__2) } }
				return DateTimeTextProvider_LocaleStore_New_Map(styleMap) } else {
//line :154:1
					var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_DAY_OF_WEEK; if any(field) == any(tmp7.Ref()) {




































































						var arr_101662 *RefArray = TextStyle_Values__TextStyle1(); var len_101663 int32 = int32(len(arr_101662.A)); var i_101664 int32 = 0; for ; i_101664 < len_101663; i_101664++ { var textStyle_3 *TextStyle = As[*TextStyle](arr_101662.A[i_101664]); var map__3 Map = HashMap_New(); var tmp8 bool; var tmp9 bool; var tmp10 *TextStyle

							TextStyle_Init(); tmp10 = TextStyle_NARROW; tmp9 = NN(textStyle_3).Equals_O__Z(tmp10.Ref()); if !tmp9 {
								var tmp11 *TextStyle; TextStyle_Init(); tmp11 = TextStyle_NARROW_STANDALONE; tmp9 = NN(textStyle_3).Equals_O__Z(tmp11.Ref()) }
//line :225:1
							tmp8 = tmp9; if tmp8 {

								var wday int32 = 1; L8: for {
									if wday <= 7 {
										var name_3 *String
										name_3 = CalendarDataUtility_RetrieveJavaTimeFieldValueName_String_I_I_I_Locale__String(Lit_2313, 7, wday, NN(textStyle_3).ToCalendarStyle__I(), locale)






										if !(name_3 == nil) {
											map__3.Put_O_O__O(Long_ValueOf_J__Long(int64(DateTimeTextProvider_ToWeekDay_I__I(wday))), name_3.Ref())
											wday = wday + 1; continue L8 } }
//line :227:1
									break L8 } } else {












										var displayNames_3 Map = CalendarDataUtility_RetrieveJavaTimeFieldValueNames_String_I_I_Locale__Map(Lit_2313, 7, NN(textStyle_3).ToCalendarStyle__I(), locale)





										if !(displayNames_3 == nil) {
											var i_101665 Iterator = displayNames_3.EntrySet__Set().Iterator__Iterator(); for i_101665.HasNext__Z() { var entry_3 Map_Entry = Map_Entry_Cast(i_101665.Next__O())

												map__3.Put_O_O__O(Long_ValueOf_J__Long(int64(DateTimeTextProvider_ToWeekDay_I__I(NN(Integer_Cast(entry_3.GetValue__O())).IntValue__I()))), String_Cast(entry_3.GetKey__O()).Ref()) } } else {



													var wday_2 int32 = 1; L10: for {
														if wday_2 <= 7 {
															var name_4 *String
															name_4 = CalendarDataUtility_RetrieveJavaTimeFieldValueName_String_I_I_I_Locale__String(Lit_2313, 7, wday_2, NN(textStyle_3).ToCalendarStyle__I(), locale)






															if !(name_4 == nil) {
																map__3.Put_O_O__O(Long_ValueOf_J__Long(int64(DateTimeTextProvider_ToWeekDay_I__I(wday_2))), name_4.Ref())
																wday_2 = wday_2 + 1; continue L10 } }
//line :253:1
														break L10
													}
												}
									}









							if map__3.IsEmpty__Z() { } else { styleMap.Put_O_O__O(textStyle_3.Ref(), map__3) } }
						return DateTimeTextProvider_LocaleStore_New_Map(styleMap) } else {
//line :154:1
							var tmp12 *ChronoField; ChronoField_Init(); tmp12 = ChronoField_AMPM_OF_DAY; if any(field) == any(tmp12.Ref()) {



















































































































								var arr_101666 *RefArray = TextStyle_Values__TextStyle1(); var len_101667 int32 = int32(len(arr_101666.A)); var i_101668 int32 = 0; for ; i_101668 < len_101667; i_101668++ { var textStyle_4 *TextStyle = As[*TextStyle](arr_101666.A[i_101668])
									if NN(textStyle_4).IsStandalone__Z() { } else {
										var displayNames_4 Map = CalendarDataUtility_RetrieveJavaTimeFieldValueNames_String_I_I_Locale__Map(Lit_2313, 9, NN(textStyle_4).ToCalendarStyle__I(), locale)





										if !(displayNames_4 == nil) {
											var map__4 Map = HashMap_New(); var i_101669 Iterator = displayNames_4.EntrySet__Set().Iterator__Iterator(); for i_101669.HasNext__Z() {
												var entry_4 Map_Entry = Map_Entry_Cast(i_101669.Next__O())
												map__4.Put_O_O__O(Long_ValueOf_J__Long(int64(NN(Integer_Cast(entry_4.GetValue__O())).IntValue__I())), String_Cast(entry_4.GetKey__O()).Ref())
											}

											if map__4.IsEmpty__Z() { } else { styleMap.Put_O_O__O(textStyle_4.Ref(), map__4) } } } }
								return DateTimeTextProvider_LocaleStore_New_Map(styleMap) } else {
//line :154:1
									var tmp13 TemporalField; IsoFields_Init(); tmp13 = IsoFields_QUARTER_OF_YEAR; if field == tmp13 {




































































































































										var keys *RefArray = ConstRefArray("[0,6,s12:QuarterNamess23:standalone.QuarterNamess20:QuarterAbbreviationss31:standalone.QuarterAbbreviationss14:QuarterNarrowss25:standalone.QuarterNarrows", []*Class{String_class})
										var i int32 = 0


									L13: for {
										if i < int32(len(keys.A)) {
											var names *RefArray = A2g_CastArray[*RefArray](DateTimeTextProvider_GetLocalizedResource_String_Locale__O(As[*String](keys.A[i]), locale), String_class.ArrayClass())

											if !(names == nil) {
												var map__5 Map = HashMap_New(); var q int32 = 0
											L14: for {
												if q < int32(len(names.A)) {
													map__5.Put_O_O__O(Long_ValueOf_J__Long(int64(q+1)), As[*String](names.A[q]).Ref())
													q = q + 1; continue L14 }
//line :297:1
												break L14
											}


												styleMap.Put_O_O__O(As[*TextStyle](TextStyle_Values__TextStyle1().A[i]).Ref(), map__5)
												i = i + 1; continue L13 } else {
													i = i + 1; continue L13 } }
//line :291:1
										break L13
									}











										return DateTimeTextProvider_LocaleStore_New_Map(styleMap) } else {
//line :154:1
											return Lit_69
										}
								}
						}
				}
		}
}


















































































































































func DateTimeTextProvider_CreateEntry_O_O__Map_Entry(text, field any) Map_Entry { DateTimeTextProvider_Init()

	return AbstractMap_SimpleImmutableEntry_New_O_O(text, field)
}
func DateTimeTextProvider_GetLocalizedResource_String_Locale__O(key *String, locale *Locale) any { DateTimeTextProvider_Init()
	var lr *LocaleResources = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter().GetLocaleResources_Locale__LocaleResources(CalendarDataUtility_FindRegionOverride_Locale__Locale(locale)); var rb ResourceBundle_I = NN(lr).GetJavaTimeFormatData__ResourceBundle()


	if rb.ContainsKey_String__Z(key) { return rb.GetObject_String__O(key) } else { return nil
	}
}




func DateTimeTextProvider_LocaleStore_New_Map(p0 Map) *DateTimeTextProvider_LocaleStore { t := &DateTimeTextProvider_LocaleStore{}; t.Ctor_Map(p0); return t }
//line :322:1
func (t *DateTimeTextProvider_LocaleStore) Ctor_Map(valueTextMap Map) {
	t.F_valueTextMap = valueTextMap
	var map_ Map = HashMap_New(); var allList List = ArrayList_New(); var i_101670 Iterator = valueTextMap.EntrySet__Set().Iterator__Iterator(); for i_101670.HasNext__Z() {

		var vtmEntry Map_Entry = Map_Entry_Cast(i_101670.Next__O()); var reverse Map = HashMap_New(); var i_101671 Iterator = Map_Cast(vtmEntry.GetValue__O()).EntrySet__Set().Iterator__Iterator(); for i_101671.HasNext__Z() {

			var entry Map_Entry = Map_Entry_Cast(i_101671.Next__O())

			if !(reverse.Put_O_O__O(String_Cast(entry.GetValue__O()).Ref(), DateTimeTextProvider_CreateEntry_O_O__Map_Entry(String_Cast(entry.GetValue__O()).Ref(), Long_Cast(entry.GetKey__O()).Ref())) == nil) {
			}
		}



		var list List = ArrayList_New_Collection(reverse.Values__Collection()); var tmp1 Comparator
		DateTimeTextProvider_Init(); tmp1 = DateTimeTextProvider_COMPARATOR; list.Sort_Comparator__V(tmp1)
		map_.Put_O_O__O(TextStyle_Cast(vtmEntry.GetKey__O()).Ref(), list)
		allList.AddAll_Collection__Z(list)
		map_.Put_O_O__O(nil, allList) }
	var tmp2 Comparator; DateTimeTextProvider_Init(); tmp2 = DateTimeTextProvider_COMPARATOR; allList.Sort_Comparator__V(tmp2)
	t.F_parsable = map_
}
func (t *DateTimeTextProvider_LocaleStore) GetText_J_TextStyle__String(value int64, style *TextStyle) *String {
	var map_ Map = Map_Cast(t.F_valueTextMap.Get_O__O(style.Ref()))
	if !(map_ == nil) { return String_Cast(map_.Get_O__O(Long_ValueOf_J__Long(value))) } else { return nil
	} }
func (t *DateTimeTextProvider_LocaleStore) GetTextIterator_TextStyle__Iterator(style *TextStyle) Iterator {
	var list List = List_Cast(t.F_parsable.Get_O__O(style.Ref()))
	if !(list == nil) { return list.Iterator__Iterator() } else { return nil
	}
}

type DateTimeTextProvider struct{ Object }

type DateTimeTextProvider_I interface{ Object_I; Self_DateTimeTextProvider() *DateTimeTextProvider; GetText_TemporalField_J_TextStyle_Locale__String(p0 TemporalField, p1 int64, p2 *TextStyle, p3 *Locale) *String; GetText_Chronology_TemporalField_J_TextStyle_Locale__String(p0 Chronology, p1 TemporalField, p2 int64, p3 *TextStyle, p4 *Locale) *String; GetTextIterator_TemporalField_TextStyle_Locale__Iterator(p0 TemporalField, p1 *TextStyle, p2 *Locale) Iterator; GetTextIterator_Chronology_TemporalField_TextStyle_Locale__Iterator(p0 Chronology, p1 TemporalField, p2 *TextStyle, p3 *Locale) Iterator }

func (t *DateTimeTextProvider) Self_DateTimeTextProvider() *DateTimeTextProvider { return t }

var DateTimeTextProvider_CACHE ConcurrentMap

var DateTimeTextProvider_COMPARATOR Comparator

var DateTimeTextProvider_INSTANCE DateTimeTextProvider_I

var DateTimeTextProvider_init ClassInit

func DateTimeTextProvider_Init() { if !DateTimeTextProvider_init.Done() { DateTimeTextProvider_init.Run(DateTimeTextProvider_clinit) } }

func DateTimeTextProvider_clinit() { DateTimeTextProvider_CACHE = ConcurrentHashMap_New_I_F_I(16, 0.75, 2); DateTimeTextProvider_COMPARATOR = DateTimeTextProvider_1_New(); DateTimeTextProvider_INSTANCE = DateTimeTextProvider_New() }

func (t *DateTimeTextProvider) GetText_TemporalField_J_TextStyle_Locale__String(p0 TemporalField, p1 int64, p2 *TextStyle, p3 *Locale) *String { return t.Impl_GetText_TemporalField_J_TextStyle_Locale__String(t, p0, p1, p2, p3) }

func (t *DateTimeTextProvider) GetText_Chronology_TemporalField_J_TextStyle_Locale__String(p0 Chronology, p1 TemporalField, p2 int64, p3 *TextStyle, p4 *Locale) *String { return t.Impl_GetText_Chronology_TemporalField_J_TextStyle_Locale__String(t, p0, p1, p2, p3, p4) }

func (t *DateTimeTextProvider) GetTextIterator_TemporalField_TextStyle_Locale__Iterator(p0 TemporalField, p1 *TextStyle, p2 *Locale) Iterator { return t.Impl_GetTextIterator_TemporalField_TextStyle_Locale__Iterator(t, p0, p1, p2) }

func (t *DateTimeTextProvider) GetTextIterator_Chronology_TemporalField_TextStyle_Locale__Iterator(p0 Chronology, p1 TemporalField, p2 *TextStyle, p3 *Locale) Iterator { return t.Impl_GetTextIterator_Chronology_TemporalField_TextStyle_Locale__Iterator(t, p0, p1, p2, p3) }

func (t *DateTimeTextProvider) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeTextProvider) GetClass__Class() *Class { return DateTimeTextProvider_class }

func (t *DateTimeTextProvider) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeTextProvider) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeTextProvider) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeTextProvider_InstanceOf(x any) bool { _, ok := x.(DateTimeTextProvider_I); return ok }

func DateTimeTextProvider_Cast(x any) DateTimeTextProvider_I { if x == nil { return nil }; v, ok := x.(DateTimeTextProvider_I); if !ok { panic(ClassCast(x, DateTimeTextProvider_class)) }; return v }



type DateTimeTextProvider_1 struct{ Object }

func (t *DateTimeTextProvider_1) Is_Comparator() {}

func DateTimeTextProvider_1_New() *DateTimeTextProvider_1 { t := &DateTimeTextProvider_1{}; t.Ctor(); return t }

func (t *DateTimeTextProvider_1) Ctor() {}

func (t *DateTimeTextProvider_1) Compare_O_O__I(p0, p1 any) int32 { return t.Compare_Map_Entry_Map_Entry__I(Map_Entry_Cast(p0), Map_Entry_Cast(p1)) }

func (t *DateTimeTextProvider_1) ThenComparing_Function__Comparator(p0 Function) Comparator { return Comparator_ThenComparing_Function__Comparator(t, p0) }

func (t *DateTimeTextProvider_1) ThenComparingInt_ToIntFunction__Comparator(p0 ToIntFunction) Comparator { return Comparator_ThenComparingInt_ToIntFunction__Comparator(t, p0) }

func (t *DateTimeTextProvider_1) ThenComparingLong_ToLongFunction__Comparator(p0 ToLongFunction) Comparator { return Comparator_ThenComparingLong_ToLongFunction__Comparator(t, p0) }

func (t *DateTimeTextProvider_1) Min_O_O__O(p0, p1 any) any { return Comparator_Min_O_O__O(t, p0, p1) }

func (t *DateTimeTextProvider_1) ThenComparingDouble_ToDoubleFunction__Comparator(p0 ToDoubleFunction) Comparator { return Comparator_ThenComparingDouble_ToDoubleFunction__Comparator(t, p0) }

func (t *DateTimeTextProvider_1) Reversed__Comparator() Comparator { return Comparator_Reversed__Comparator(t) }

func (t *DateTimeTextProvider_1) Max_O_O__O(p0, p1 any) any { return Comparator_Max_O_O__O(t, p0, p1) }

func (t *DateTimeTextProvider_1) ThenComparing_Comparator__Comparator(p0 Comparator) Comparator { return Comparator_ThenComparing_Comparator__Comparator(t, p0) }

func (t *DateTimeTextProvider_1) ThenComparing_Function_Comparator__Comparator(p0 Function, p1 Comparator) Comparator { return Comparator_ThenComparing_Function_Comparator__Comparator(t, p0, p1) }

func (t *DateTimeTextProvider_1) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeTextProvider_1) GetClass__Class() *Class { return DateTimeTextProvider_1_class }

func (t *DateTimeTextProvider_1) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeTextProvider_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeTextProvider_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeTextProvider_1_InstanceOf(x any) bool { _, ok := x.(*DateTimeTextProvider_1); return ok }

func DateTimeTextProvider_1_Cast(x any) *DateTimeTextProvider_1 { if x == nil { return nil }; v, ok := x.(*DateTimeTextProvider_1); if !ok { panic(ClassCast(x, DateTimeTextProvider_1_class)) }; return v }



type DateTimeTextProvider_LocaleStore struct{ Object; F_valueTextMap, F_parsable Map }

func (t *DateTimeTextProvider_LocaleStore) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeTextProvider_LocaleStore) GetClass__Class() *Class { return DateTimeTextProvider_LocaleStore_class }

func (t *DateTimeTextProvider_LocaleStore) ToString__String() *String { return Object_toString(t) }

func (t *DateTimeTextProvider_LocaleStore) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeTextProvider_LocaleStore) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeTextProvider_LocaleStore_InstanceOf(x any) bool { _, ok := x.(*DateTimeTextProvider_LocaleStore); return ok }

func DateTimeTextProvider_LocaleStore_Cast(x any) *DateTimeTextProvider_LocaleStore { if x == nil { return nil }; v, ok := x.(*DateTimeTextProvider_LocaleStore); if !ok { panic(ClassCast(x, DateTimeTextProvider_LocaleStore_class)) }; return v }
