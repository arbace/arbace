//line java_util_Base64.ae:1
package jrt










func Base64_New() *Base64 { t := &Base64{}; t.Ctor(); return t }
//line :12:1
func (t *Base64) Ctor() { panic(A2g_NotTranslated("java.util.Base64.<init>()V")) }

func Base64_GetEncoder__Base64_Encoder() *Base64_Encoder { Base64_Encoder_Init(); return Base64_Encoder_RFC4648 }

func Base64_GetUrlEncoder__Base64_Encoder() *Base64_Encoder { Base64_Encoder_Init(); return Base64_Encoder_RFC4648_URLSAFE }


func Base64_GetMimeEncoder__Base64_Encoder() *Base64_Encoder { Base64_Encoder_Init(); return Base64_Encoder_RFC2045 }

func Base64_GetMimeEncoder_I_B1__Base64_Encoder(lineLength int32, lineSeparator *ByteArray) *Base64_Encoder {
	Objects_RequireNonNull_O__O(lineSeparator.Ref())
	var base64 *IntArray; Base64_Decoder_Init(); base64 = Base64_Decoder_fromBase64
	var arr_101751 *ByteArray = lineSeparator; var len_101752 int32 = int32(len(arr_101751.A)); var i_101753 int32 = 0; for ; i_101753 < len_101752; i_101753++ { var b int8 = arr_101751.A[i_101753]
		if base64.A[int32(b)&255] == -1 { } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2606, Integer_ToString_I_I__String(int32(b), 16)))))
		} }
	lineLength = lineLength & -4
	if lineLength <= 0 { Base64_Encoder_Init(); return Base64_Encoder_RFC4648 } else { return Base64_Encoder_New_Z_B1_I_Z(false, lineSeparator, lineLength, true)
	} }
func Base64_GetDecoder__Base64_Decoder() *Base64_Decoder { Base64_Decoder_Init(); return Base64_Decoder_RFC4648 }

func Base64_GetUrlDecoder__Base64_Decoder() *Base64_Decoder { Base64_Decoder_Init(); return Base64_Decoder_RFC4648_URLSAFE }


func Base64_GetMimeDecoder__Base64_Decoder() *Base64_Decoder { Base64_Decoder_Init(); return Base64_Decoder_RFC2045 }










func Base64_Encoder_New_Z_B1_I_Z(p0 bool, p1 *ByteArray, p2 int32, p3 bool) *Base64_Encoder { Base64_Encoder_Init(); t := &Base64_Encoder{}; t.Ctor_Z_B1_I_Z(p0, p1, p2, p3); return t }
//line :47:1
func (t *Base64_Encoder) Ctor_Z_B1_I_Z(isURL bool, newline *ByteArray, linemax int32, doPadding bool) {
	t.F_isURL = isURL
	t.F_newline = newline
	t.F_linemax = linemax
	t.F_doPadding = doPadding
}























func (t *Base64_Encoder) EncodedOutLength_I_Z__I(srclen int32, throwOOME bool) int32 {
	var len_ int32 = 0; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

		if t.F_doPadding {
			len_ = Math_MultiplyExact_I_I__I(4, Math_AddExact_I_I__I(srclen, 2)/3) } else {



				var n int32 = srclen % 3; var tmp1 int32 = Math_MultiplyExact_I_I__I(4, srclen/3); var tmp2 int32



				if n == 0 { tmp2 = 0 } else { tmp2 = n + 1 }
//line :85:1
				len_ = Math_AddExact_I_I__I(tmp1, tmp2)
			}


		if t.F_linemax > 0 {
			var tmp3 int32 = (len_ - 1) / t.F_linemax; len_ = Math_AddExact_I_I__I(len_, tmp3*int32(len(t.F_newline.A))) }; return nil }()
//line :78:1
	if tmp4 != nil { if ArithmeticException_InstanceOf(tmp4) { var ex *ArithmeticException = ArithmeticException_Cast(tmp4); _ = ex

















		if throwOOME { panic(Thrown(OutOfMemoryError_New_String(Lit_2617))) } else { len_ = -1 } } else {
//line :78:1
			panic(tmp4) } }
//line :77:1
	return len_
}




















func (t *Base64_Encoder) Encode_B1__B1(src *ByteArray) *ByteArray {
	var len_ int32 = t.EncodedOutLength_I_Z__I(int32(len(src.A)), true); var dst *ByteArray = NewByteArray(len_); var ret int32 = t.Encode0_B1_I_I_B1__I(src, 0, int32(len(src.A)), dst)


	if !(ret == int32(len(dst.A))) { return Arrays_CopyOf_B1_I__B1(dst, ret) } else { return dst
	} }
func (t *Base64_Encoder) Encode_B1_B1__I(src, dst *ByteArray) int32 {
	var len_ int32 = t.EncodedOutLength_I_Z__I(int32(len(src.A)), false); var tmp1 bool; var tmp2 bool
	tmp2 = int32(len(dst.A)) < len_; if !tmp2 { tmp2 = len_ == -1 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2618)))
	}
	return t.Encode0_B1_I_I_B1__I(src, 0, int32(len(src.A)), dst)
}
func (t *Base64_Encoder) EncodeToString_B1__String(src *ByteArray) *String {
	var encoded *ByteArray = t.Encode_B1__B1(src); return String_New_B1_I_I_I(encoded, 0, 0, int32(len(encoded.A)))
}
func (t *Base64_Encoder) Encode_ByteBuffer__ByteBuffer(buffer ByteBuffer_I) ByteBuffer_I {
	var len_ int32 = t.EncodedOutLength_I_Z__I(buffer.Remaining__I(), true); var dst *ByteArray = NewByteArray(len_)
	var ret int32 = 0

	if buffer.HasArray__Z() {

		ret = t.Encode0_B1_I_I_B1__I(buffer.Array__B1(), buffer.ArrayOffset__I()+buffer.Position__I(), buffer.ArrayOffset__I()+buffer.Limit__I(), dst)





		buffer.Position_I__ByteBuffer(buffer.Limit__I()) } else {
			var src *ByteArray = NewByteArray(buffer.Remaining__I())
			buffer.Get_B1__ByteBuffer(src)
			ret = t.Encode0_B1_I_I_B1__I(src, 0, int32(len(src.A)), dst) }
	if ret == int32(len(dst.A)) { } else { dst = Arrays_CopyOf_B1_I__B1(dst, ret) }
	return ByteBuffer_Wrap_B1__ByteBuffer(dst)
}
func (t *Base64_Encoder) Wrap_OutputStream__OutputStream(os OutputStream_I) OutputStream_I {
	Objects_RequireNonNull_O__O(os)
	var tmp1 *CharArray; if t.F_isURL { tmp1 = Base64_Encoder_toBase64URL } else { tmp1 = Base64_Encoder_toBase64 }; return Base64_EncOutputStream_New_OutputStream_C1_B1_I_Z(os, tmp1, t.F_newline, t.F_linemax, t.F_doPadding)
}
func (t *Base64_Encoder) WithoutPadding__Base64_Encoder() *Base64_Encoder {
	if !t.F_doPadding { return t } else { return Base64_Encoder_New_Z_B1_I_Z(t.F_isURL, t.F_newline, t.F_linemax, false)
	} }
func (t *Base64_Encoder) EncodeBlock_B1_I_I_B1_I_Z__V(src *ByteArray, sp, sl int32, dst *ByteArray, dp int32, isURL bool) {


	var base64 *CharArray; if isURL { base64 = Base64_Encoder_toBase64URL } else { base64 = Base64_Encoder_toBase64 }; var sp0 int32 = sp
	var dp0 int32 = dp

L1: for { if sp0 < sl {
	var bits int32; var tmp1 int32
	var old_1 int32 = sp0



	sp0 = sp0 + 1
//line :152:1
	tmp1 = old_1
//line :148:1
	var tmp2 int32 = int32(src.A[tmp1]) & 255 << 16; var tmp3 int32
	var old_2 int32 = sp0












	sp0 = sp0 + 1
//line :161:1
	tmp3 = old_2
//line :148:1
	var tmp4 int32 = tmp2 | int32(src.A[tmp3])&255<<8; var tmp5 int32
	var old_3 int32 = sp0



















	sp0 = sp0 + 1
//line :168:1
	tmp5 = old_3
//line :148:1
	bits = tmp4 | int32(src.A[tmp5])&255























	dst.A[dp0] = int8(base64.A[int32(uint32(bits)>>18)&63])



	dp0 = dp0 + 1
	dst.A[dp0] = int8(base64.A[int32(uint32(bits)>>12)&63])



	dp0 = dp0 + 1
	dst.A[dp0] = int8(base64.A[int32(uint32(bits)>>6)&63])



	dp0 = dp0 + 1
	dst.A[dp0] = int8(base64.A[bits&63])
	dp0 = dp0 + 1
//line :147:1
	continue L1 }; break L1
}
}








































func (t *Base64_Encoder) Encode0_B1_I_I_B1__I(src *ByteArray, off, end int32, dst *ByteArray) int32 {
	var base64 *CharArray; if t.F_isURL { base64 = Base64_Encoder_toBase64URL } else { base64 = Base64_Encoder_toBase64 }; var sp int32 = off; var slen int32 = (end - off) / 3 * 3; var sl int32 = off + slen; var tmp1 bool; var tmp2 bool





	tmp2 = t.F_linemax > 0; if tmp2 {
		tmp2 = slen > t.F_linemax/4*3 }
//line :197:1
	tmp1 = tmp2; if tmp1 {

		slen = t.F_linemax / 4 * 3 }
	var dp int32 = 0
L1: for { if sp < sl {
	var sl0 int32 = Math_Min_I_I__I(sp+slen, sl)
	t.EncodeBlock_B1_I_I_B1_I_Z__V(src, sp, sl0, dst, dp, t.F_isURL)
	var dlen int32 = (sl0 - sp) / 3 * 4


	dp = dp + dlen
	sp = sl0
	var tmp3 bool; var tmp4 bool; tmp4 = dlen == t.F_linemax; if tmp4 { tmp4 = sp < end }; tmp3 = tmp4; if tmp3 {
		var arr_101754 *ByteArray = t.F_newline; var len_101755 int32 = int32(len(arr_101754.A)); var i_101756 int32 = 0; for ; i_101756 < len_101755; i_101756++ { var b int8 = arr_101754.A[i_101756]; dst.A[dp] = b; dp = dp + 1 } }
//line :201:1
	continue L1 }; break L1
}








	if sp < end {
		var b0 int32; var tmp5 int32; var old_4 int32 = sp; sp = sp + 1; tmp5 = old_4; b0 = int32(src.A[tmp5]) & 255

		dst.A[dp] = int8(base64.A[b0>>2])
		dp = dp + 1
		if sp == end {

			dst.A[dp] = int8(base64.A[b0<<4&63])



			dp = dp + 1
			if t.F_doPadding {
				dst.A[dp] = 61
				dp = dp + 1
				dst.A[dp] = 61
				dp = dp + 1 } } else {
					var b1 int32; var tmp6 int32
					var old_5 int32 = sp
					sp = sp + 1
//line :229:1
					tmp6 = old_5
//line :228:1
					b1 = int32(src.A[tmp6]) & 255




					dst.A[dp] = int8(base64.A[b0<<4&63|b1>>4])





					dp = dp + 1
					dst.A[dp] = int8(base64.A[b1<<2&63])



					dp = dp + 1
					if t.F_doPadding {
						dst.A[dp] = 61
						dp = dp + 1 } } }
//line :200:1
	return dp
}





















































func Base64_Decoder_New_Z_Z(p0, p1 bool) *Base64_Decoder { Base64_Decoder_Init(); t := &Base64_Decoder{}; t.Ctor_Z_Z(p0, p1); return t }
//line :255:1
func (t *Base64_Decoder) Ctor_Z_Z(isURL, isMIME bool) {
	t.F_isURL = isURL
	t.F_isMIME = isMIME
}


























func (t *Base64_Decoder) Decode_B1__B1(src *ByteArray) *ByteArray {
	var dst *ByteArray = NewByteArray(t.DecodedOutLength_B1_I_I__I(src, 0, int32(len(src.A)))); var ret int32 = t.Decode0_B1_I_I_B1__I(src, 0, int32(len(src.A)), dst)

	if ret == int32(len(dst.A)) { } else { dst = Arrays_CopyOf_B1_I__B1(dst, ret) }
//line :286:1
	return dst
}



func (t *Base64_Decoder) Decode_String__B1(src *String) *ByteArray {
	return t.Decode_B1__B1(NN(src).GetBytes_Charset__B1(Up_ISO_8859_1_Charset(ISO_8859_1_INSTANCE)))
}
func (t *Base64_Decoder) Decode_B1_B1__I(src, dst *ByteArray) int32 {
	var len_ int32 = t.DecodedOutLength_B1_I_I__I(src, 0, int32(len(src.A))); var tmp1 bool; var tmp2 bool
	tmp2 = int32(len(dst.A)) < len_; if !tmp2 { tmp2 = len_ == -1 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2611)))
	}
	return t.Decode0_B1_I_I_B1__I(src, 0, int32(len(src.A)), dst)
}
func (t *Base64_Decoder) Decode_ByteBuffer__ByteBuffer(buffer ByteBuffer_I) ByteBuffer_I {
	var pos0 int32 = buffer.Position__I(); var tmp1 ByteBuffer_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var src *ByteArray
			var sp int32 = 0
			var sl int32 = 0
			if buffer.HasArray__Z() {

				src = buffer.Array__B1()
				sp = buffer.ArrayOffset__I() + buffer.Position__I()
				sl = buffer.ArrayOffset__I() + buffer.Limit__I()
				buffer.Position_I__ByteBuffer(buffer.Limit__I()) } else {

					src = NewByteArray(buffer.Remaining__I())
					buffer.Get_B1__ByteBuffer(src)
					sp = 0
					sl = int32(len(src.A)) }
			var dst *ByteArray = NewByteArray(t.DecodedOutLength_B1_I_I__I(src, sp, sl))
			tmp1 = ByteBuffer_Wrap_B1_I_I__ByteBuffer(dst, 0, t.Decode0_B1_I_I_B1__I(src, sp, sl, dst)) }; return nil }()
//line :303:1
	if tmp2 != nil { if IllegalArgumentException_InstanceOf(tmp2) { var iae IllegalArgumentException_I = IllegalArgumentException_Cast(tmp2)
















		buffer.Position_I__ByteBuffer(pos0); panic(Thrown(iae)) } else {
//line :303:1
			panic(tmp2) } }; return tmp1
}

















func (t *Base64_Decoder) Wrap_InputStream__InputStream(is InputStream_I) InputStream_I {
	Objects_RequireNonNull_O__O(is)
	var tmp1 *IntArray; if t.F_isURL { tmp1 = Base64_Decoder_fromBase64URL } else { tmp1 = Base64_Decoder_fromBase64 }; return Base64_DecInputStream_New_InputStream_I1_Z(is, tmp1, t.F_isMIME)
}
func (t *Base64_Decoder) DecodedOutLength_B1_I_I__I(src *ByteArray, sp, sl int32) int32 {
	var base64 *IntArray; if t.F_isURL { base64 = Base64_Decoder_fromBase64URL } else { base64 = Base64_Decoder_fromBase64 }; var paddings int32 = 0; var len_ int32 = sl - sp


	if len_ == 0 { return 0 } else {


		if len_ < 2 {
			var tmp1 bool; var tmp2 bool; tmp2 = t.F_isMIME; if tmp2 { tmp2 = base64.A[0] == -1 }; tmp1 = tmp2; if tmp1 { return 0 }
			panic(Thrown(IllegalArgumentException_New_String(Lit_2612)))
		}
		if t.F_isMIME {
			var n int32 = 0
		L1: for { if sp < sl {
			var b int32; var tmp3 int32
			var old_6 int32 = sp

			sp = sp + 1
//line :342:1
			tmp3 = old_6
//line :340:1
			b = int32(src.A[tmp3]) & 255





			if b == 61 {
				len_ = len_ - (sl - sp + 1)



				break L1 }
			var tmp4 int32; b = base64.A[b]; tmp4 = b; if tmp4 == -1 { n = n + 1 }
//line :339:1
			continue L1 }; break L1
		}












			len_ = len_ - n } else {
				if int32(src.A[sl-1]) == 61 {
					paddings = paddings + 1
					if int32(src.A[sl-2]) == 61 {
						paddings = paddings + 1 } } }
		var tmp5 bool; var tmp6 bool; tmp6 = paddings == 0; if tmp6 { tmp6 = !(len_&3 == 0) }; tmp5 = tmp6; if tmp5 {
			paddings = 4 - len_&3 }
		return 3*int32((int64(len_)+3)/4) - paddings
	}
}


func (t *Base64_Decoder) DecodeBlock_B1_I_I_B1_I_Z_Z__I(src *ByteArray, sp, sl int32, dst *ByteArray, dp int32, isURL, isMIME bool) int32 {



	var base64 *IntArray; if isURL { base64 = Base64_Decoder_fromBase64URL } else { base64 = Base64_Decoder_fromBase64 }; var sl0 int32 = sp + (sl-sp)&-4
	var new_dp int32 = dp


L1: for { if sp < sl0 {
	var b1 int32; var tmp1 int32
	var old_7 int32 = sp
	sp = sp + 1; tmp1 = old_7
//line :374:1
	b1 = base64.A[int32(src.A[tmp1])&255]; var b2 int32; var tmp2 int32
	var old_8 int32 = sp




	sp = sp + 1; tmp2 = old_8
//line :378:1
	b2 = base64.A[int32(src.A[tmp2])&255]
//line :374:1
	var b3 int32; var tmp3 int32
	var old_9 int32 = sp








	sp = sp + 1; tmp3 = old_9
//line :382:1
	b3 = base64.A[int32(src.A[tmp3])&255]
//line :374:1
	var b4 int32; var tmp4 int32
	var old_10 int32 = sp













	sp = sp + 1
//line :388:1
	tmp4 = old_10
//line :386:1
	b4 = base64.A[int32(src.A[tmp4])&255]





	if b1|b2|b3|b4 < 0 {
		return new_dp - dp }
	var bits0 int32 = b1<<18 | b2<<12 | b3<<6 | b4




	dst.A[new_dp] = int8(bits0 >> 16)
	new_dp = new_dp + 1
	dst.A[new_dp] = int8(bits0 >> 8)
	new_dp = new_dp + 1
	dst.A[new_dp] = int8(bits0)
	new_dp = new_dp + 1
//line :373:1
	continue L1 }; break L1
}






























	return new_dp - dp
}
func (t *Base64_Decoder) Decode0_B1_I_I_B1__I(src *ByteArray, sp, sl int32, dst *ByteArray) int32 {
	var base64 *IntArray; if t.F_isURL { base64 = Base64_Decoder_fromBase64URL } else { base64 = Base64_Decoder_fromBase64 }; var dp int32 = 0
	var bits int32 = 0
	var shiftto int32 = 18

L1: for { if sp < sl {
	var tmp1 bool; var tmp2 bool; tmp2 = shiftto == 18; if tmp2 { tmp2 = sp < sl-4 }; tmp1 = tmp2; if tmp1 {
		var dl int32 = t.DecodeBlock_B1_I_I_B1_I_Z_Z__I(src, sp, sl, dst, dp, t.F_isURL, t.F_isMIME); var chars_decoded int32 = (dl + 2) / 3 * 4



		sp = sp + chars_decoded
		dp = dp + dl }
	if sp >= sl { break L1 }
	var b int32; var tmp3 int32
	var old_11 int32 = sp
	sp = sp + 1
//line :422:1
	tmp3 = old_11
//line :421:1
	b = int32(src.A[tmp3]) & 255




	var tmp4 int32; b = base64.A[b]; tmp4 = b; if tmp4 < 0 {

		if b == -2 {
			var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = shiftto == 6; if tmp7 {
				var tmp8 bool; tmp8 = sp == sl; if !tmp8 {
					var tmp9 int32
					var old_12 int32 = sp

					sp = sp + 1
//line :433:1
					tmp9 = old_12
//line :431:1
					tmp8 = !(int32(src.A[tmp9]) == 61) }
//line :430:1
				tmp7 = tmp8 }
//line :429:1
			tmp6 = tmp7; if !tmp6 {







				tmp6 = shiftto == 18 }
//line :429:1
			tmp5 = tmp6; if tmp5 {








				panic(Thrown(IllegalArgumentException_New_String(Lit_2613)))
			}
			break L1 }
		if t.F_isMIME { } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2614, Integer_ToString_I_I__String(int32(src.A[sp-1]), 16))))) } } else {





				bits = bits | b<<(shiftto&31)
				shiftto = shiftto - 6
				if shiftto < 0 {
					dst.A[dp] = int8(bits >> 16)
					dp = dp + 1
					dst.A[dp] = int8(bits >> 8)
					dp = dp + 1
					dst.A[dp] = int8(bits)
					dp = dp + 1
					shiftto = 18
					bits = 0 } }
//line :412:1
	continue L1 }; break L1
}













































	if shiftto == 6 {


		dst.A[dp] = int8(bits >> 16)
		dp = dp + 1 } else {
//line :459:1
			if shiftto == 0 {






				dst.A[dp] = int8(bits >> 16)
				dp = dp + 1
				dst.A[dp] = int8(bits >> 8)
				dp = dp + 1 } else {
//line :459:1
					if shiftto == 12 {











						panic(Thrown(IllegalArgumentException_New_String(Lit_2615))) } } }
L2: for { if sp < sl {
	var tmp10 bool; var tmp11 bool; tmp11 = t.F_isMIME; if tmp11 {
		var tmp12 int32
		var old_13 int32 = sp


		sp = sp + 1
//line :477:1
		tmp12 = old_13
//line :474:1
		tmp11 = base64.A[int32(src.A[tmp12])&255] < 0 }
//line :473:1
	tmp10 = tmp11; if tmp10 { } else {








		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2616, StrOfInt(sp))))) }
//line :472:1
	continue L2 }; break L2 }
//line :408:1
	return dp
}





































































































func Base64_EncOutputStream_New_OutputStream_C1_B1_I_Z(p0 OutputStream_I, p1 *CharArray, p2 *ByteArray, p3 int32, p4 bool) *Base64_EncOutputStream { t := &Base64_EncOutputStream{}; t.Ctor_OutputStream_C1_B1_I_Z(p0, p1, p2, p3, p4); return t }
//line :511:1
func (t *Base64_EncOutputStream) Ctor_OutputStream_C1_B1_I_Z(os OutputStream_I, base64 *CharArray, newline *ByteArray, linemax int32, doPadding bool) { t.FilterOutputStream.Ctor_OutputStream(t, os); t.F_leftover = 0; t.F_closed = false; t.F_linepos = 0


	t.F_base64 = base64
	t.F_newline = newline
	t.F_linemax = linemax
	t.F_doPadding = doPadding
	var tmp1 int32; if linemax <= 0 { tmp1 = 8124 } else { tmp1 = linemax }; t.F_buf = NewByteArray(tmp1)
}
func (t *Base64_EncOutputStream) Write_I__V(b int32) {
	var buf *ByteArray = NewByteArray(1)
	buf.A[0] = int8(b & 255)
	t.Write_B1_I_I__V(buf, 0, 1)
}
func (t *Base64_EncOutputStream) CheckNewline__V() {
	if t.F_linepos == t.F_linemax { t.F_out.Write_B1__V(t.F_newline); t.F_linepos = 0
	} }
func (t *Base64_EncOutputStream) Writeb4_C_C_C_C__V(b1, b2, b3, b4 uint16) {
	t.F_buf.A[0] = int8(b1)
	t.F_buf.A[1] = int8(b2)
	t.F_buf.A[2] = int8(b3)
	t.F_buf.A[3] = int8(b4)
	t.F_out.Write_B1_I_I__V(t.F_buf, 0, 4)
}
func (t *Base64_EncOutputStream) Write_B1_I_I__V(b *ByteArray, off, len_ int32) {

	if t.F_closed { panic(Thrown(IOException_New_String(Lit_2609))) }
	var tmp1 int32 = off; var tmp2 int32 = len_; var tmp3 int32 = int32(len(b.A)); var tmp4 BiFunction; Preconditions_Init(); tmp4 = Preconditions_AIOOBE_FORMATTER; Preconditions_CheckFromIndexSize_I_I_I_BiFunction__I(tmp1, tmp2, tmp3, tmp4)
	if len_ == 0 { } else {
		if t.F_leftover == 0 { } else {
			if t.F_leftover == 1 {
				t.F_b1 = int32(b.A[off]) & 255
				off = off + 1
				len_ = len_ - 1
				if len_ == 0 { t.F_leftover = t.F_leftover + 1; return } }
			t.F_b2 = int32(b.A[off]) & 255
			off = off + 1
			len_ = len_ - 1
			t.CheckNewline__V()
			var tmp5 uint16 = t.F_base64.A[t.F_b0>>2]; var tmp6 uint16 = t.F_base64.A[t.F_b0<<4&63|t.F_b1>>4]; var tmp7 uint16 = t.F_base64.A[t.F_b1<<2&63|t.F_b2>>6]; t.Writeb4_C_C_C_C__V(tmp5, tmp6, tmp7, t.F_base64.A[t.F_b2&63])








			t.F_linepos = t.F_linepos + 4 }
		var nBits24 int32 = len_ / 3
		t.F_leftover = len_ - nBits24*3
	L1: for { if nBits24 > 0 {
		t.CheckNewline__V()
		var dl int32; if t.F_linemax <= 0 {
			dl = int32(len(t.F_buf.A)) } else {
				dl = int32(len(t.F_buf.A)) - t.F_linepos }
//line :564:1
		var sl int32 = off + Math_Min_I_I__I(nBits24, dl/4)*3
		var dp int32 = 0
		var sp int32 = off






	L2: for { if sp < sl {
		var bits int32; var tmp8 int32
		var old_14 int32 = sp




		sp = sp + 1
//line :579:1
		tmp8 = old_14
//line :574:1
		var tmp9 int32 = int32(b.A[tmp8]) & 255 << 16; var tmp10 int32
		var old_15 int32 = sp













		sp = sp + 1
//line :588:1
		tmp10 = old_15
//line :574:1
		var tmp11 int32 = tmp9 | int32(b.A[tmp10])&255<<8; var tmp12 int32
		var old_16 int32 = sp





















		sp = sp + 1
//line :596:1
		tmp12 = old_16
//line :574:1
		bits = tmp11 | int32(b.A[tmp12])&255

























		var tmp13 *ByteArray = t.F_buf; tmp13.A[dp] = int8(t.F_base64.A[int32(uint32(bits)>>18)&63])




		dp = dp + 1
		var tmp14 *ByteArray = t.F_buf; tmp14.A[dp] = int8(t.F_base64.A[int32(uint32(bits)>>12)&63])




		dp = dp + 1
		var tmp15 *ByteArray = t.F_buf; tmp15.A[dp] = int8(t.F_base64.A[int32(uint32(bits)>>6)&63])



		dp = dp + 1
		var tmp16 *ByteArray = t.F_buf; tmp16.A[dp] = int8(t.F_base64.A[bits&63])
		dp = dp + 1
//line :573:1
		continue L2 }; break L2
	}












































		t.F_out.Write_B1_I_I__V(t.F_buf, 0, dp)
		off = sl
		t.F_linepos = t.F_linepos + dp
		nBits24 = nBits24 - dp/4
//line :562:1
		continue L1 }; break L1
	}



























































		if t.F_leftover == 1 {
			t.F_b0 = int32(b.A[off]) & 255; off = off + 1 } else {
				if t.F_leftover == 2 {
					t.F_b0 = int32(b.A[off]) & 255
					off = off + 1
					t.F_b1 = int32(b.A[off]) & 255
					off = off + 1
				} } } }
func (t *Base64_EncOutputStream) Close__V() {
	if t.F_closed { } else {
		t.F_closed = true
		if t.F_leftover == 1 {

			t.CheckNewline__V()
			var tmp1 OutputStream_I = t.F_out; tmp1.Write_I__V(int32(t.F_base64.A[t.F_b0>>2]))
			var tmp2 OutputStream_I = t.F_out; tmp2.Write_I__V(int32(t.F_base64.A[t.F_b0<<4&63]))
			if t.F_doPadding { t.F_out.Write_I__V(61); t.F_out.Write_I__V(61) } } else {
				if t.F_leftover == 2 {
					t.CheckNewline__V()
					var tmp3 OutputStream_I = t.F_out; tmp3.Write_I__V(int32(t.F_base64.A[t.F_b0>>2]))
					var tmp4 OutputStream_I = t.F_out; tmp4.Write_I__V(int32(t.F_base64.A[t.F_b0<<4&63|t.F_b1>>4]))



					var tmp5 OutputStream_I = t.F_out; tmp5.Write_I__V(int32(t.F_base64.A[t.F_b1<<2&63]))
					if t.F_doPadding { t.F_out.Write_I__V(61) } } }
		t.F_leftover = 0
		t.F_out.Close__V()
	}
}


















func Base64_DecInputStream_New_InputStream_I1_Z(p0 InputStream_I, p1 *IntArray, p2 bool) *Base64_DecInputStream { t := &Base64_DecInputStream{}; t.Ctor_InputStream_I1_Z(p0, p1, p2); return t }
//line :671:1
func (t *Base64_DecInputStream) Ctor_InputStream_I1_Z(is InputStream_I, base64 *IntArray, isMIME bool) { t.InputStream.Ctor(t); t.F_bits = 0; t.F_wpos = 0; t.F_rpos = 0; t.F_eof = false; t.F_closed = false; t.F_sbBuf = NewByteArray(1)
	t.F_is = is
	t.F_base64 = base64
	t.F_isMIME = isMIME
}


func (t *Base64_DecInputStream) Read__I() int32 {
	if t.Read_B1_I_I__I(t.F_sbBuf, 0, 1) == -1 { return -1 } else { return int32(t.F_sbBuf.A[0]) & 255
	} }
func (t *Base64_DecInputStream) Leftovers_B1_I_I_I__I(b *ByteArray, off, pos, limit int32) int32 {
	t.F_eof = true
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = t.F_rpos-8 >= t.F_wpos; if tmp2 { tmp2 = !(pos == limit) }; tmp1 = tmp2; if tmp1 {
	t.F_rpos = t.F_rpos - 8
	b.A[pos] = int8(t.F_bits >> (t.F_rpos & 31))
	pos = pos + 1
//line :683:1
	continue L1 }; break L1
}


	var tmp3 bool; var tmp4 bool; tmp4 = !(pos-off == 0); if !tmp4 {
		tmp4 = t.F_rpos-8 >= t.F_wpos }
//line :687:1
	tmp3 = tmp4; if tmp3 {

		return pos - off } else {
//line :687:1
			return -1
		}
}


func (t *Base64_DecInputStream) Eof_B1_I_I_I__I(b *ByteArray, off, pos, limit int32) int32 {
	if t.F_wpos == 18 { panic(Thrown(IOException_New_String(Lit_2607))) }
	t.F_rpos = 24
	return t.Leftovers_B1_I_I_I__I(b, off, pos, limit)
}
func (t *Base64_DecInputStream) Padding_B1_I_I_I__I(b *ByteArray, off, pos, limit int32) int32 {

	var tmp1 bool; var tmp2 bool; tmp2 = t.F_wpos >= 18; if !tmp2 { var tmp3 bool; tmp3 = t.F_wpos == 12; if tmp3 { tmp3 = !(t.F_is.Read__I() == 61) }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IOException_New_String(Concat(Lit_2608, StrOfInt(t.F_wpos))))) }
	t.F_rpos = 24
	return t.Leftovers_B1_I_I_I__I(b, off, pos, limit)
}
func (t *Base64_DecInputStream) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	if t.F_closed { panic(Thrown(IOException_New_String(Lit_2609))) }
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	if len_ == 0 { return 0 } else {

		var pos int32 = off; var limit int32 = off + len_

		if t.F_eof {
			return t.Leftovers_B1_I_I_I__I(b, off, pos, limit) } else {

				if t.F_rpos == 16 {
					b.A[pos] = int8(t.F_bits >> 8)
					pos = pos + 1
					t.F_rpos = 8
					if pos == limit { return len_ } }
				if t.F_rpos == 8 {
					b.A[pos] = int8(t.F_bits)
					pos = pos + 1
					t.F_rpos = 0
					if pos == limit { return len_ } }
				t.F_bits = 0
				t.F_wpos = 24
			L1: for {
				var i int32 = t.F_is.Read__I()
				if i < 0 { return t.Eof_B1_I_I_I__I(b, off, pos, limit) }
				var v int32 = t.F_base64.A[i]
				if v < 0 {
					if v == -1 {
						if t.F_isMIME { continue L1 }
						panic(Thrown(IOException_New_String(Concat(Lit_2610, Integer_ToHexString_I__String(i)))))
					}

					return t.Padding_B1_I_I_I__I(b, off, pos, limit) }
				t.F_wpos = t.F_wpos - 6
				t.F_bits = t.F_bits | v<<(t.F_wpos&31)
				if !(t.F_wpos == 0) { } else {
					if limit-pos >= 3 {

						b.A[pos] = int8(t.F_bits >> 16)
						pos = pos + 1
						b.A[pos] = int8(t.F_bits >> 8)
						pos = pos + 1
						b.A[pos] = int8(t.F_bits)
						pos = pos + 1
						t.F_bits = 0
						t.F_wpos = 24
						if pos == limit { return len_ } } else {

							b.A[pos] = int8(t.F_bits >> 16)
							pos = pos + 1
							if pos == limit { t.F_rpos = 16; return len_ }
							b.A[pos] = int8(t.F_bits >> 8)
							pos = pos + 1
							t.F_rpos = 8
							return len_ } }
//line :726:1
				continue L1
			}
			}
	}




























	panic("a2g: unreachable")
}
func (t *Base64_DecInputStream) Available__I() int32 {
	if t.F_closed { panic(Thrown(IOException_New_String(Lit_2609))) }
	return t.F_is.Available__I()
}
func (t *Base64_DecInputStream) Close__V() {
	if t.F_closed { } else { t.F_closed = true; t.F_is.Close__V()
	}
}

type Base64 struct{ Object }

func (t *Base64) Ref() any { if t == nil { return nil }; return t }

func (t *Base64) GetClass__Class() *Class { return Base64_class }

func (t *Base64) ToString__String() *String { return Object_toString(t) }

func (t *Base64) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Base64) CloneShallow() any { panic(CloneNotSupported(t)) }

func Base64_InstanceOf(x any) bool { _, ok := x.(*Base64); return ok }

func Base64_Cast(x any) *Base64 { if x == nil { return nil }; v, ok := x.(*Base64); if !ok { panic(ClassCast(x, Base64_class)) }; return v }



type Base64_DecInputStream struct{ InputStream; F_is InputStream_I; F_isMIME bool; F_base64 *IntArray; F_bits, F_wpos, F_rpos int32; F_eof, F_closed bool; F_sbBuf *ByteArray }

func (t *Base64_DecInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *Base64_DecInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *Base64_DecInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *Base64_DecInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *Base64_DecInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *Base64_DecInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *Base64_DecInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *Base64_DecInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *Base64_DecInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *Base64_DecInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *Base64_DecInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *Base64_DecInputStream) GetClass__Class() *Class { return Base64_DecInputStream_class }

func (t *Base64_DecInputStream) ToString__String() *String { return Object_toString(t) }

func (t *Base64_DecInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Base64_DecInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func Base64_DecInputStream_InstanceOf(x any) bool { _, ok := x.(*Base64_DecInputStream); return ok }

func Base64_DecInputStream_Cast(x any) *Base64_DecInputStream { if x == nil { return nil }; v, ok := x.(*Base64_DecInputStream); if !ok { panic(ClassCast(x, Base64_DecInputStream_class)) }; return v }



type Base64_Decoder struct{ Object; F_isURL, F_isMIME bool }

var Base64_Decoder_fromBase64 *IntArray

var Base64_Decoder_fromBase64URL *IntArray

var Base64_Decoder_RFC4648 *Base64_Decoder

var Base64_Decoder_RFC4648_URLSAFE *Base64_Decoder

var Base64_Decoder_RFC2045 *Base64_Decoder

var Base64_Decoder_init ClassInit

func Base64_Decoder_Init() { if !Base64_Decoder_init.Done() { Base64_Decoder_init.Run(Base64_Decoder_clinit) } }

func Base64_Decoder_clinit() { Base64_Decoder_fromBase64 = NewIntArray(256)
//line :262:1
	Arrays_Fill_I1_I__V(Base64_Decoder_fromBase64, -1)
	var i int32 = 0; L1: for {
		var tmp1 *CharArray; Base64_Encoder_Init(); tmp1 = Base64_Encoder_toBase64; if i < int32(len(tmp1.A)) {
			var tmp2 *IntArray = Base64_Decoder_fromBase64; var tmp3 *CharArray; Base64_Encoder_Init(); tmp3 = Base64_Encoder_toBase64; tmp2.A[int32(tmp3.A[i])] = i
			i = i + 1; continue L1 }
//line :263:1
		break L1
	}


	Base64_Decoder_fromBase64.A[61] = -2
//line :263:1
	Base64_Decoder_fromBase64URL = NewIntArray(256)








	Arrays_Fill_I1_I__V(Base64_Decoder_fromBase64URL, -1)
	var i_2 int32 = 0; L2: for {
		var tmp4 *CharArray; Base64_Encoder_Init(); tmp4 = Base64_Encoder_toBase64URL; if i_2 < int32(len(tmp4.A)) {
			var tmp5 *IntArray = Base64_Decoder_fromBase64URL; var tmp6 *CharArray; Base64_Encoder_Init(); tmp6 = Base64_Encoder_toBase64URL; tmp5.A[int32(tmp6.A[i_2])] = i_2
			i_2 = i_2 + 1; continue L2 }
//line :273:1
		break L2
	}


	Base64_Decoder_fromBase64URL.A[61] = -2
//line :273:1
	Base64_Decoder_RFC4648 = Base64_Decoder_New_Z_Z(false, false); Base64_Decoder_RFC4648_URLSAFE = Base64_Decoder_New_Z_Z(true, false); Base64_Decoder_RFC2045 = Base64_Decoder_New_Z_Z(false, true)
}
























































































































































































































































































































































































































































































































































































func (t *Base64_Decoder) Ref() any { if t == nil { return nil }; return t }

func (t *Base64_Decoder) GetClass__Class() *Class { return Base64_Decoder_class }

func (t *Base64_Decoder) ToString__String() *String { return Object_toString(t) }

func (t *Base64_Decoder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Base64_Decoder) CloneShallow() any { panic(CloneNotSupported(t)) }

func Base64_Decoder_InstanceOf(x any) bool { _, ok := x.(*Base64_Decoder); return ok }

func Base64_Decoder_Cast(x any) *Base64_Decoder { if x == nil { return nil }; v, ok := x.(*Base64_Decoder); if !ok { panic(ClassCast(x, Base64_Decoder_class)) }; return v }



type Base64_EncOutputStream struct{ FilterOutputStream; F_leftover, F_b0, F_b1, F_b2 int32; F_closed bool; F_base64 *CharArray; F_newline *ByteArray; F_linemax int32; F_doPadding bool; F_linepos int32; F_buf *ByteArray }

func (t *Base64_EncOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *Base64_EncOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *Base64_EncOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *Base64_EncOutputStream) GetClass__Class() *Class { return Base64_EncOutputStream_class }

func (t *Base64_EncOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *Base64_EncOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Base64_EncOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func Base64_EncOutputStream_InstanceOf(x any) bool { _, ok := x.(*Base64_EncOutputStream); return ok }

func Base64_EncOutputStream_Cast(x any) *Base64_EncOutputStream { if x == nil { return nil }; v, ok := x.(*Base64_EncOutputStream); if !ok { panic(ClassCast(x, Base64_EncOutputStream_class)) }; return v }



type Base64_Encoder struct{ Object; F_newline *ByteArray; F_linemax int32; F_isURL, F_doPadding bool }

var Base64_Encoder_toBase64 *CharArray

var Base64_Encoder_toBase64URL *CharArray

const Base64_Encoder_MIMELINEMAX int32 = 76

var Base64_Encoder_CRLF *ByteArray

var Base64_Encoder_RFC4648 *Base64_Encoder

var Base64_Encoder_RFC4648_URLSAFE *Base64_Encoder

var Base64_Encoder_RFC2045 *Base64_Encoder

var Base64_Encoder_init ClassInit

func Base64_Encoder_Init() { if !Base64_Encoder_init.Done() { Base64_Encoder_init.Run(Base64_Encoder_clinit) } }

func Base64_Encoder_clinit() { Base64_Encoder_toBase64 = CharArrayOf(65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47); Base64_Encoder_toBase64URL = CharArrayOf(65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95); Base64_Encoder_CRLF = ByteArrayOf(13, 10); Base64_Encoder_RFC4648 = Base64_Encoder_New_Z_B1_I_Z(false, nil, -1, true); Base64_Encoder_RFC4648_URLSAFE = Base64_Encoder_New_Z_B1_I_Z(true, nil, -1, true); Base64_Encoder_RFC2045 = Base64_Encoder_New_Z_B1_I_Z(false, Base64_Encoder_CRLF, 76, true) }

func (t *Base64_Encoder) Ref() any { if t == nil { return nil }; return t }

func (t *Base64_Encoder) GetClass__Class() *Class { return Base64_Encoder_class }

func (t *Base64_Encoder) ToString__String() *String { return Object_toString(t) }

func (t *Base64_Encoder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Base64_Encoder) CloneShallow() any { panic(CloneNotSupported(t)) }

func Base64_Encoder_InstanceOf(x any) bool { _, ok := x.(*Base64_Encoder); return ok }

func Base64_Encoder_Cast(x any) *Base64_Encoder { if x == nil { return nil }; v, ok := x.(*Base64_Encoder); if !ok { panic(ClassCast(x, Base64_Encoder_class)) }; return v }
