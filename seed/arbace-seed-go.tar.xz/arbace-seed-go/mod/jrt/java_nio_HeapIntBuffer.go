//line java_nio_HeapIntBuffer.ae:1
package jrt
















func HeapIntBuffer_New_I_I_MemorySegment(p0, p1 int32, p2 MemorySegment) *HeapIntBuffer { HeapIntBuffer_Init(); t := &HeapIntBuffer{}; t.Ctor_I_I_MemorySegment(p0, p1, p2); return t }
//line :18:1
func (t *HeapIntBuffer) Ctor_I_I_MemorySegment(cap_, lim int32, segment MemorySegment) { t.IntBuffer.Ctor_I_I_I_I_I1_I_MemorySegment(t, -1, 0, lim, cap_, NewIntArray(cap_), 0, segment)

	t.F_address = HeapIntBuffer_ARRAY_BASE_OFFSET
}
func HeapIntBuffer_New_I1_I_I_MemorySegment(p0 *IntArray, p1, p2 int32, p3 MemorySegment) *HeapIntBuffer { HeapIntBuffer_Init(); t := &HeapIntBuffer{}; t.Ctor_I1_I_I_MemorySegment(p0, p1, p2, p3); return t }
//line :22:1
func (t *HeapIntBuffer) Ctor_I1_I_I_MemorySegment(buf *IntArray, off, len_ int32, segment MemorySegment) { t.IntBuffer.Ctor_I_I_I_I_I1_I_MemorySegment(t, -1, off, off+len_, int32(len(buf.A)), buf, 0, segment)

	t.F_address = HeapIntBuffer_ARRAY_BASE_OFFSET
}
func HeapIntBuffer_New_I1_I_I_I_I_I_MemorySegment(p0 *IntArray, p1, p2, p3, p4, p5 int32, p6 MemorySegment) *HeapIntBuffer { HeapIntBuffer_Init(); t := &HeapIntBuffer{}; t.Ctor_I1_I_I_I_I_I_MemorySegment(p0, p1, p2, p3, p4, p5, p6); return t }
//line :26:1
func (t *HeapIntBuffer) Ctor_I1_I_I_I_I_I_MemorySegment(buf *IntArray, mark, pos, lim, cap_, off int32, segment MemorySegment) { t.IntBuffer.Ctor_I_I_I_I_I1_I_MemorySegment(t, mark, pos, lim, cap_, buf, off, segment)


	t.F_address = HeapIntBuffer_ARRAY_BASE_OFFSET + int64(off)*HeapIntBuffer_ARRAY_INDEX_SCALE
}

func (t *HeapIntBuffer) Slice__IntBuffer() IntBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I(); var rem int32

	if pos <= lim { rem = lim - pos } else { rem = 0 }
	return HeapIntBuffer_New_I1_I_I_I_I_I_MemorySegment(t.F_hb, -1, 0, rem, rem, pos+t.F_offset, t.F_segment)
}






func (t *HeapIntBuffer) Slice_I_I__IntBuffer(index, length int32) IntBuffer_I {
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	return HeapIntBuffer_New_I1_I_I_I_I_I_MemorySegment(t.F_hb, -1, 0, length, length, index+t.F_offset, t.F_segment)
}






func (t *HeapIntBuffer) Duplicate__IntBuffer() IntBuffer_I {
	var tmp1 *IntArray = t.F_hb; return HeapIntBuffer_New_I1_I_I_I_I_I_MemorySegment(tmp1, t.MarkValue__I(), t.Position__I(), t.Limit__I(), t.Capacity__I(), t.F_offset, t.F_segment)
}






func (t *HeapIntBuffer) AsReadOnlyBuffer__IntBuffer() IntBuffer_I {
	return A2g_Missing[IntBuffer_I]("class java.nio.HeapIntBufferR is not in the closed world")
}






func (t *HeapIntBuffer) Ix_I__I(i int32) int32 {
	return i + t.F_offset
}
func (t *HeapIntBuffer) Get__I() int32 {
	var tmp1 *IntArray = t.F_hb; return tmp1.A[t.Ix_I__I(t.NextGetIndex__I())]
}
func (t *HeapIntBuffer) Get_I__I(i int32) int32 {
	var tmp1 *IntArray = t.F_hb; return tmp1.A[t.Ix_I__I(t.CheckIndex_I__I(i))]
}
func (t *HeapIntBuffer) Get_I1_I_I__IntBuffer(dst *IntArray, offset, length int32) IntBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var pos int32 = t.Position__I()
	if length > t.Limit__I()-pos {
		panic(Thrown(BufferUnderflowException_New())) }
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, t.Ix_I__I(pos), dst.Ref(), offset, length)
	t.Position_I__IntBuffer(pos + length)
//line :84:1
	return t
}





func (t *HeapIntBuffer) Get_I_I1_I_I__IntBuffer(index int32, dst *IntArray, offset, length int32) IntBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(dst.A)))
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, t.Ix_I__I(index), dst.Ref(), offset, length)
//line :91:1
	return t
}





func (t *HeapIntBuffer) IsDirect__Z() bool { return false }

func (t *HeapIntBuffer) IsReadOnly__Z() bool { return false }

func (t *HeapIntBuffer) Put_I__IntBuffer(x int32) IntBuffer_I {
	var tmp1 *IntArray = t.F_hb; tmp1.A[t.Ix_I__I(t.NextPutIndex__I())] = x
//line :102:1
	return t
}


func (t *HeapIntBuffer) Put_I_I__IntBuffer(i, x int32) IntBuffer_I {
	var tmp1 *IntArray = t.F_hb; tmp1.A[t.Ix_I__I(t.CheckIndex_I__I(i))] = x
//line :106:1
	return t
}


func (t *HeapIntBuffer) Put_I1_I_I__IntBuffer(src *IntArray, offset, length int32) IntBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var pos int32 = t.Position__I()
	if length > t.Limit__I()-pos {
		panic(Thrown(BufferOverflowException_New())) }
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(src.Ref(), offset, tmp1, t.Ix_I__I(pos), length)
	t.Position_I__IntBuffer(pos + length)
//line :113:1
	return t
}





func (t *HeapIntBuffer) Put_IntBuffer__IntBuffer(src IntBuffer_I) IntBuffer_I {
	t.CheckSession__V()
	t.IntBuffer.Impl_Put_IntBuffer__IntBuffer(t, src)
//line :120:1
	return t
}



func (t *HeapIntBuffer) Put_I_IntBuffer_I_I__IntBuffer(index int32, src IntBuffer_I, offset, length int32) IntBuffer_I {
	t.CheckSession__V()
	t.IntBuffer.Impl_Put_I_IntBuffer_I_I__IntBuffer(t, index, src, offset, length)
//line :125:1
	return t
}



func (t *HeapIntBuffer) Put_I_I1_I_I__IntBuffer(index int32, src *IntArray, offset, length int32) IntBuffer_I {
	t.CheckSession__V()
	Objects_CheckFromIndexSize_I_I_I__I(index, length, t.Limit__I())
	Objects_CheckFromIndexSize_I_I_I__I(offset, length, int32(len(src.A)))
	var tmp1 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(src.Ref(), offset, tmp1, t.Ix_I__I(index), length)
//line :130:1
	return t
}





func (t *HeapIntBuffer) Compact__IntBuffer() IntBuffer_I {
	var pos int32 = t.Position__I(); var lim int32 = t.Limit__I()

	if !A2g_AssertionsDisabled && !(pos <= lim) { panic(Thrown(AssertionError_New())) }
	var rem int32; if pos <= lim { rem = lim - pos } else { rem = 0 }
	var tmp1 any = t.F_hb.Ref(); var tmp2 int32 = t.Ix_I__I(pos); var tmp3 any = t.F_hb.Ref(); System_Arraycopy_O_I_O_I_I__V(tmp1, tmp2, tmp3, t.Ix_I__I(0), rem)
	t.Position_I__IntBuffer(rem)
	t.Limit_I__IntBuffer(t.Capacity__I())
	t.DiscardMark__V()
//line :141:1
	return t
}





func (t *HeapIntBuffer) Order__ByteOrder() *ByteOrder { return ByteOrder_NativeOrder__ByteOrder() }



type HeapIntBuffer struct{ IntBuffer }

var HeapIntBuffer_ARRAY_BASE_OFFSET int64

var HeapIntBuffer_ARRAY_INDEX_SCALE int64

var HeapIntBuffer_init ClassInit

func HeapIntBuffer_Init() { if !HeapIntBuffer_init.Done() { HeapIntBuffer_init.Run(HeapIntBuffer_clinit) } }

func HeapIntBuffer_clinit() { IntBuffer_Init(); HeapIntBuffer_ARRAY_BASE_OFFSET = NN(Buffer_UNSAFE).ArrayBaseOffset_Class__J(Prim_int.ArrayClass()); HeapIntBuffer_ARRAY_INDEX_SCALE = int64(NN(Buffer_UNSAFE).ArrayIndexScale_Class__I(Prim_int.ArrayClass())) }

func (t *HeapIntBuffer) Slice__Buffer() Buffer_I { return t.Slice__IntBuffer() }

func (t *HeapIntBuffer) Slice_I_I__Buffer(p0, p1 int32) Buffer_I { return t.Slice_I_I__IntBuffer(p0, p1) }

func (t *HeapIntBuffer) Duplicate__Buffer() Buffer_I { return t.Duplicate__IntBuffer() }

func (t *HeapIntBuffer) ScaleShifts__I() int32 { return t.Impl_ScaleShifts__I(t) }

func (t *HeapIntBuffer) Mark__IntBuffer() IntBuffer_I { return t.Impl_Mark__IntBuffer(t) }

func (t *HeapIntBuffer) Array__O() any { return t.Impl_Array__O(t) }

func (t *HeapIntBuffer) PutBuffer_I_IntBuffer_I_I__V(p0 int32, p1 IntBuffer_I, p2, p3 int32) { t.Impl_PutBuffer_I_IntBuffer_I_I__V(t, p0, p1, p2, p3) }

func (t *HeapIntBuffer) Capacity__I() int32 { return t.Impl_Capacity__I(t) }

func (t *HeapIntBuffer) NextGetIndex__I() int32 { return t.Impl_NextGetIndex__I(t) }

func (t *HeapIntBuffer) Limit_I__IntBuffer(p0 int32) IntBuffer_I { return t.Impl_Limit_I__IntBuffer(t, p0) }

func (t *HeapIntBuffer) Clear__Buffer() Buffer_I { return t.Impl_Clear__Buffer(t) }

func (t *HeapIntBuffer) Mismatch_IntBuffer__I(p0 IntBuffer_I) int32 { return t.Impl_Mismatch_IntBuffer__I(t, p0) }

func (t *HeapIntBuffer) Position_I__IntBuffer(p0 int32) IntBuffer_I { return t.Impl_Position_I__IntBuffer(t, p0) }

func (t *HeapIntBuffer) CompareTo_IntBuffer__I(p0 IntBuffer_I) int32 { return t.Impl_CompareTo_IntBuffer__I(t, p0) }

func (t *HeapIntBuffer) Session__MemorySessionImpl() MemorySessionImpl_I { return t.Impl_Session__MemorySessionImpl(t) }

func (t *HeapIntBuffer) Put_I_I1__IntBuffer(p0 int32, p1 *IntArray) IntBuffer_I { return t.Impl_Put_I_I1__IntBuffer(t, p0, p1) }

func (t *HeapIntBuffer) Limit__I() int32 { return t.Impl_Limit__I(t) }

func (t *HeapIntBuffer) Base__O() any { return t.Impl_Base__O(t) }

func (t *HeapIntBuffer) Array__I1() *IntArray { return t.Impl_Array__I1(t) }

func (t *HeapIntBuffer) Remaining__I() int32 { return t.Impl_Remaining__I(t) }

func (t *HeapIntBuffer) NextGetIndex_I__I(p0 int32) int32 { return t.Impl_NextGetIndex_I__I(t, p0) }

func (t *HeapIntBuffer) Clear__IntBuffer() IntBuffer_I { return t.Impl_Clear__IntBuffer(t) }

func (t *HeapIntBuffer) Flip__IntBuffer() IntBuffer_I { return t.Impl_Flip__IntBuffer(t) }

func (t *HeapIntBuffer) NextPutIndex__I() int32 { return t.Impl_NextPutIndex__I(t) }

func (t *HeapIntBuffer) DiscardMark__V() { t.Impl_DiscardMark__V(t) }

func (t *HeapIntBuffer) Flip__Buffer() Buffer_I { return t.Impl_Flip__Buffer(t) }

func (t *HeapIntBuffer) ArrayOffset__I() int32 { return t.Impl_ArrayOffset__I(t) }

func (t *HeapIntBuffer) MarkValue__I() int32 { return t.Impl_MarkValue__I(t) }

func (t *HeapIntBuffer) Rewind__Buffer() Buffer_I { return t.Impl_Rewind__Buffer(t) }

func (t *HeapIntBuffer) HasArray__Z() bool { return t.Impl_HasArray__Z(t) }

func (t *HeapIntBuffer) Get_I1__IntBuffer(p0 *IntArray) IntBuffer_I { return t.Impl_Get_I1__IntBuffer(t, p0) }

func (t *HeapIntBuffer) PutArray_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I { return t.Impl_PutArray_I_I1_I_I__IntBuffer(t, p0, p1, p2, p3) }

func (t *HeapIntBuffer) Reset__IntBuffer() IntBuffer_I { return t.Impl_Reset__IntBuffer(t) }

func (t *HeapIntBuffer) Position__I() int32 { return t.Impl_Position__I(t) }

func (t *HeapIntBuffer) Reset__Buffer() Buffer_I { return t.Impl_Reset__Buffer(t) }

func (t *HeapIntBuffer) Put_I1__IntBuffer(p0 *IntArray) IntBuffer_I { return t.Impl_Put_I1__IntBuffer(t, p0) }

func (t *HeapIntBuffer) CheckIndex_I_I__I(p0, p1 int32) int32 { return t.Impl_CheckIndex_I_I__I(t, p0, p1) }

func (t *HeapIntBuffer) CheckSession__V() { t.Impl_CheckSession__V(t) }

func (t *HeapIntBuffer) CheckIndex_I__I(p0 int32) int32 { return t.Impl_CheckIndex_I__I(t, p0) }

func (t *HeapIntBuffer) Position_I__Buffer(p0 int32) Buffer_I { return t.Impl_Position_I__Buffer(t, p0) }

func (t *HeapIntBuffer) Rewind__IntBuffer() IntBuffer_I { return t.Impl_Rewind__IntBuffer(t) }

func (t *HeapIntBuffer) Get_I_I1__IntBuffer(p0 int32, p1 *IntArray) IntBuffer_I { return t.Impl_Get_I_I1__IntBuffer(t, p0, p1) }

func (t *HeapIntBuffer) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *HeapIntBuffer) Mark__Buffer() Buffer_I { return t.Impl_Mark__Buffer(t) }

func (t *HeapIntBuffer) HasRemaining__Z() bool { return t.Impl_HasRemaining__Z(t) }

func (t *HeapIntBuffer) NextPutIndex_I__I(p0 int32) int32 { return t.Impl_NextPutIndex_I__I(t, p0) }

func (t *HeapIntBuffer) Limit_I__Buffer(p0 int32) Buffer_I { return t.Impl_Limit_I__Buffer(t, p0) }

func (t *HeapIntBuffer) GetArray_I_I1_I_I__IntBuffer(p0 int32, p1 *IntArray, p2, p3 int32) IntBuffer_I { return t.Impl_GetArray_I_I1_I_I__IntBuffer(t, p0, p1, p2, p3) }

func (t *HeapIntBuffer) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *HeapIntBuffer) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *HeapIntBuffer) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *HeapIntBuffer) Ref() any { if t == nil { return nil }; return t }

func (t *HeapIntBuffer) GetClass__Class() *Class { return HeapIntBuffer_class }

func (t *HeapIntBuffer) Clone__O() any { return A2g_ObjectClone(t) }

func (t *HeapIntBuffer) CloneShallow() any { panic(CloneNotSupported(t)) }

func HeapIntBuffer_InstanceOf(x any) bool { _, ok := x.(*HeapIntBuffer); return ok }

func HeapIntBuffer_Cast(x any) *HeapIntBuffer { if x == nil { return nil }; v, ok := x.(*HeapIntBuffer); if !ok { panic(ClassCast(x, HeapIntBuffer_class)) }; return v }
