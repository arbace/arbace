//line java_time_format_DateTimeParseContext.ae:1
package jrt




















func DateTimeParseContext_New_DateTimeFormatter(p0 *DateTimeFormatter) *DateTimeParseContext { t := &DateTimeParseContext{}; t.Ctor_DateTimeFormatter(p0); return t }
//line :22:1
func (t *DateTimeParseContext) Ctor_DateTimeFormatter(formatter *DateTimeFormatter) { t.F_caseSensitive = true; t.F_strict = true; t.F_parsed = ArrayList_New(); t.F_chronoListeners = nil

	t.F_formatter = formatter
	var tmp1 *ArrayList = t.F_parsed; NN(tmp1).Add_O__Z(Parsed_New())
}
func (t *DateTimeParseContext) Copy__DateTimeParseContext() *DateTimeParseContext {
	var newContext *DateTimeParseContext = DateTimeParseContext_New_DateTimeFormatter(t.F_formatter)
	newContext.F_caseSensitive = t.F_caseSensitive
	newContext.F_strict = t.F_strict
//line :28:1
	return newContext
}



func (t *DateTimeParseContext) GetLocale__Locale() *Locale { return NN(t.F_formatter).GetLocale__Locale() }

func (t *DateTimeParseContext) GetDecimalStyle__DecimalStyle() *DecimalStyle {
	return NN(t.F_formatter).GetDecimalStyle__DecimalStyle()
}
func (t *DateTimeParseContext) GetEffectiveChronology__Chronology() Chronology {
	var chrono Chronology = t.CurrentParsed__Parsed().F_chrono
	if chrono == nil {
		chrono = NN(t.F_formatter).GetChronology__Chronology()
		if chrono == nil { var tmp1 *IsoChronology; IsoChronology_Init(); tmp1 = IsoChronology_INSTANCE; chrono = Up_IsoChronology_Chronology(tmp1) } }
//line :39:1
	return chrono
}




func (t *DateTimeParseContext) IsCaseSensitive__Z() bool { return t.F_caseSensitive }

func (t *DateTimeParseContext) SetCaseSensitive_Z__V(caseSensitive bool) {
	t.F_caseSensitive = caseSensitive
}
func (t *DateTimeParseContext) SubSequenceEquals_CharSequence_I_CharSequence_I_I__Z(cs1 CharSequence, offset1 int32, cs2 CharSequence, offset2, length int32) bool {

	var tmp1 bool; var tmp2 bool; tmp2 = offset1+length > cs1.Length__I(); if !tmp2 {
		tmp2 = offset2+length > cs2.Length__I() }
//line :52:1
	tmp1 = tmp2; if tmp1 { return false } else {



		if t.IsCaseSensitive__Z() {
			var i int32 = 0; L1: for {
				if i < length {
					var ch1 uint16 = cs1.CharAt_I__C(offset1 + i); var ch2 uint16 = cs2.CharAt_I__C(offset2 + i)

					if !(int32(ch1) == int32(ch2)) { return false } else { i = i + 1; continue L1 } }
//line :57:1
				break L1 } } else {




					var i_2 int32 = 0; L2: for {
						if i_2 < length {
							var ch1_2 uint16 = cs1.CharAt_I__C(offset1 + i_2); var ch2_2 uint16 = cs2.CharAt_I__C(offset2 + i_2); var tmp3 bool; var tmp4 bool; var tmp5 bool


							tmp5 = !(int32(ch1_2) == int32(ch2_2))
//line :66:1
							if tmp5 {

								tmp5 = !(int32(Character_ToUpperCase_C__C(ch1_2)) == int32(Character_ToUpperCase_C__C(ch2_2))) }
//line :66:1
							tmp4 = tmp5; if tmp4 {


								tmp4 = !(int32(Character_ToLowerCase_C__C(ch1_2)) == int32(Character_ToLowerCase_C__C(ch2_2))) }
//line :66:1
							tmp3 = tmp4; if tmp3 {



								return false } else {
									i_2 = i_2 + 1; continue L2 } }
//line :62:1
						break L2 } }
//line :55:1
		return true
	}
}
















func (t *DateTimeParseContext) CharEquals_C_C__Z(ch1, ch2 uint16) bool {
	if t.IsCaseSensitive__Z() { return int32(ch1) == int32(ch2) } else { return DateTimeParseContext_CharEqualsIgnoreCase_C_C__Z(ch1, ch2)
	} }
func DateTimeParseContext_CharEqualsIgnoreCase_C_C__Z(c1, c2 uint16) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = int32(c1) == int32(c2); if !tmp2 { tmp2 = int32(Character_ToUpperCase_C__C(c1)) == int32(Character_ToUpperCase_C__C(c2)) }; tmp1 = tmp2; if !tmp1 {
		tmp1 = int32(Character_ToLowerCase_C__C(c1)) == int32(Character_ToLowerCase_C__C(c2)) }
//line :78:1
	return tmp1
}

func (t *DateTimeParseContext) IsStrict__Z() bool { return t.F_strict }

func (t *DateTimeParseContext) SetStrict_Z__V(strict bool) {
	t.F_strict = strict
}
func (t *DateTimeParseContext) StartOptional__V() {
	var tmp1 *ArrayList = t.F_parsed; NN(tmp1).Add_O__Z(NN(t.CurrentParsed__Parsed()).Copy__Parsed().Ref())
}
func (t *DateTimeParseContext) EndOptional_Z__V(successful bool) {
	if successful {
		var tmp1 *ArrayList = t.F_parsed; NN(tmp1).Remove_I__O(NN(t.F_parsed).Size__I() - 2) } else {
			var tmp2 *ArrayList = t.F_parsed; NN(tmp2).Remove_I__O(NN(t.F_parsed).Size__I() - 1)
		} }
func (t *DateTimeParseContext) CurrentParsed__Parsed() *Parsed {
	var tmp1 *ArrayList = t.F_parsed; return Parsed_Cast(NN(tmp1).Get_I__O(NN(t.F_parsed).Size__I() - 1))
}
func (t *DateTimeParseContext) ToUnresolved__Parsed() *Parsed { return t.CurrentParsed__Parsed() }

func (t *DateTimeParseContext) ToResolved_ResolverStyle_Set__TemporalAccessor(resolverStyle *ResolverStyle, resolverFields Set) TemporalAccessor {

	var parsed *Parsed = t.CurrentParsed__Parsed()
	parsed.F_chrono = t.GetEffectiveChronology__Chronology()
	var tmp1 ZoneId_I; if !(parsed.F_zone == nil) { tmp1 = parsed.F_zone } else { tmp1 = NN(t.F_formatter).GetZone__ZoneId() }; parsed.F_zone = tmp1
	return NN(parsed).Resolve_ResolverStyle_Set__TemporalAccessor(resolverStyle, resolverFields)
}
func (t *DateTimeParseContext) GetParsed_TemporalField__Long(field TemporalField) *Long {
	return Long_Cast(t.CurrentParsed__Parsed().F_fieldValues.Get_O__O(field))
}
func (t *DateTimeParseContext) SetParsedField_TemporalField_J_I_I__I(field TemporalField, value int64, errorPos, successPos int32) int32 {
	Objects_RequireNonNull_O_String__O(field, Lit_2253)
	var old *Long = Long_Cast(t.CurrentParsed__Parsed().F_fieldValues.Put_O_O__O(field, Long_ValueOf_J__Long(value))); var tmp1 bool; var tmp2 bool
	tmp2 = !(old == nil); if tmp2 { tmp2 = !(NN(old).LongValue__J() == value) }; tmp1 = tmp2; if tmp1 { return ^errorPos } else { return successPos
	} }
func (t *DateTimeParseContext) SetParsed_Chronology__V(chrono Chronology) {
	Objects_RequireNonNull_O_String__O(chrono, Lit_2196)
	t.CurrentParsed__Parsed().F_chrono = chrono
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_chronoListeners == nil); if tmp2 { tmp2 = !NN(t.F_chronoListeners).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		var tmp *RefArray = NewRefArray(Consumer_class, 1); var listeners *RefArray = A2g_CastArray[*RefArray](NN(t.F_chronoListeners).ToArray_O1__O1(tmp).Ref(), Consumer_class.ArrayClass())



		NN(t.F_chronoListeners).Clear__V()
		var arr_101640 *RefArray = listeners; var len_101641 int32 = int32(len(arr_101640.A)); var i_101642 int32 = 0; for ; i_101642 < len_101641; i_101642++ { var l Consumer = As[Consumer](arr_101640.A[i_101642]); l.Accept_O__V(chrono)
		} } }
func (t *DateTimeParseContext) AddChronoChangedListener_Consumer__V(listener Consumer) {
	if t.F_chronoListeners == nil { t.F_chronoListeners = ArrayList_New() }
	NN(t.F_chronoListeners).Add_O__Z(listener)
}
func (t *DateTimeParseContext) SetParsed_ZoneId__V(zone ZoneId_I) {
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	t.CurrentParsed__Parsed().F_zone = zone
}
func (t *DateTimeParseContext) SetParsedZoneNameType_I__V(type_ int32) {
	t.CurrentParsed__Parsed().F_zoneNameType = type_
}
func (t *DateTimeParseContext) SetParsedLeapSecond__V() {
	t.CurrentParsed__Parsed().F_leapSecond = true
}
func (t *DateTimeParseContext) SetParsedDayPeriod_DateTimeFormatterBuilder_DayPeriod__V(dayPeriod *DateTimeFormatterBuilder_DayPeriod) {
	t.CurrentParsed__Parsed().F_dayPeriod = dayPeriod
}
func (t *DateTimeParseContext) ToString__String() *String {
	return NN(t.CurrentParsed__Parsed()).ToString__String()
}


type DateTimeParseContext struct{ Object; F_formatter *DateTimeFormatter; F_caseSensitive, F_strict bool; F_parsed, F_chronoListeners *ArrayList }

func (t *DateTimeParseContext) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimeParseContext) GetClass__Class() *Class { return DateTimeParseContext_class }

func (t *DateTimeParseContext) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimeParseContext) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimeParseContext_InstanceOf(x any) bool { _, ok := x.(*DateTimeParseContext); return ok }

func DateTimeParseContext_Cast(x any) *DateTimeParseContext { if x == nil { return nil }; v, ok := x.(*DateTimeParseContext); if !ok { panic(ClassCast(x, DateTimeParseContext_class)) }; return v }
