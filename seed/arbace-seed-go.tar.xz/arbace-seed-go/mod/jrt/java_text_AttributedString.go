//line java_text_AttributedString.ae:1
package jrt


















func AttributedString_New_AttributedCharacterIterator1(p0 *RefArray) *AttributedString { t := &AttributedString{}; t.Ctor_AttributedCharacterIterator1(p0); return t }
//line :20:1
func (t *AttributedString) Ctor_AttributedCharacterIterator1(iterators *RefArray) {
	if iterators == nil { panic(Thrown(NullPointerException_New_String(Lit_1696))) }
	if int32(len(iterators.A)) == 0 {
		t.F_text = Lit_69 } else {
			var buffer *StringBuilder = StringBuilder_New(); var counter int32 = 0
		L1: for {
			if counter < int32(len(iterators.A)) {
				t.AppendContents_StringBuilder_CharacterIterator__V(buffer, As[AttributedCharacterIterator](iterators.A[counter]))
				counter = counter + 1; continue L1 }
//line :25:1
			break L1
		}


			t.F_text = NN(buffer).ToString__String()
			if NN(t.F_text).IsEmpty__Z() { } else {
				var offset int32 = 0; var last Map
				var counter_2 int32 = 0
			L2: for {
				if counter_2 < int32(len(iterators.A)) {
					var iterator AttributedCharacterIterator = As[AttributedCharacterIterator](iterators.A[counter_2]); var start int32 = iterator.GetBeginIndex__I(); var end int32 = iterator.GetEndIndex__I()
					var index int32 = start


				L3: for { if index < end {
					iterator.SetIndex_I__C(index)
					var attrs Map = iterator.GetAttributes__Map()

					if AttributedString_MapsDiffer_Map_Map__Z(last, attrs) {
						t.SetAttributes_Map_I__V(attrs, index-start+offset)
					}



					last = attrs
					index = iterator.GetRunLimit__I()
//line :39:1
					continue L3 }; break L3
				}










					offset = offset + (end - start)
					counter_2 = counter_2 + 1; continue L2 }
//line :33:1
				break L2
			}
			}
		}
}
















func AttributedString_New_String(p0 *String) *AttributedString { t := &AttributedString{}; t.Ctor_String(p0); return t }
//line :54:1
func (t *AttributedString) Ctor_String(text *String) {
	if text == nil { panic(Thrown(NullPointerException_New())) }
	t.F_text = text
}
func AttributedString_New_String_Map(p0 *String, p1 Map) *AttributedString { t := &AttributedString{}; t.Ctor_String_Map(p0, p1); return t }
//line :58:1
func (t *AttributedString) Ctor_String_Map(text *String, attributes Map) {

	var tmp1 bool; var tmp2 bool; tmp2 = text == nil; if !tmp2 { tmp2 = attributes == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	t.F_text = text
	if NN(text).IsEmpty__Z() {
		if attributes.IsEmpty__Z() { return }
		panic(Thrown(IllegalArgumentException_New_String(Lit_1697))) }
	var attributeCount int32 = attributes.Size__I()
	if attributeCount > 0 {
		t.CreateRunAttributeDataVectors__V()
		var newRunAttributes Vector_I = Vector_New_I(attributeCount); var newRunAttributeValues Vector_I = Vector_New_I(attributeCount)


		t.F_runAttributes.Store(0, newRunAttributes)
		t.F_runAttributeValues.Store(0, newRunAttributeValues)
		var i_101264 Iterator = attributes.EntrySet__Set().Iterator__Iterator(); for i_101264.HasNext__Z() { var entry Map_Entry = Map_Entry_Cast(i_101264.Next__O())

			newRunAttributes.AddElement_O__V(AttributedCharacterIterator_Attribute_Cast(entry.GetKey__O()))

			newRunAttributeValues.AddElement_O__V(entry.GetValue__O())
		} } }
func AttributedString_New_AttributedCharacterIterator(p0 AttributedCharacterIterator) *AttributedString { t := &AttributedString{}; t.Ctor_AttributedCharacterIterator(p0); return t }
//line :79:1
func (t *AttributedString) Ctor_AttributedCharacterIterator(text AttributedCharacterIterator) { t.Ctor_AttributedCharacterIterator_I_I_AttributedCharacterIterator_Attribute1(text, text.GetBeginIndex__I(), text.GetEndIndex__I(), nil) }


func AttributedString_New_AttributedCharacterIterator_I_I(p0 AttributedCharacterIterator, p1, p2 int32) *AttributedString { t := &AttributedString{}; t.Ctor_AttributedCharacterIterator_I_I(p0, p1, p2); return t }
//line :82:1
func (t *AttributedString) Ctor_AttributedCharacterIterator_I_I(text AttributedCharacterIterator, beginIndex, endIndex int32) { t.Ctor_AttributedCharacterIterator_I_I_AttributedCharacterIterator_Attribute1(text, beginIndex, endIndex, nil) }


func AttributedString_New_AttributedCharacterIterator_I_I_AttributedCharacterIterator_Attribute1(p0 AttributedCharacterIterator, p1, p2 int32, p3 *RefArray) *AttributedString { t := &AttributedString{}; t.Ctor_AttributedCharacterIterator_I_I_AttributedCharacterIterator_Attribute1(p0, p1, p2, p3); return t }
//line :85:1
func (t *AttributedString) Ctor_AttributedCharacterIterator_I_I_AttributedCharacterIterator_Attribute1(text AttributedCharacterIterator, beginIndex, endIndex int32, attributes *RefArray) {

	if text == nil { panic(Thrown(NullPointerException_New())) }
	var textBeginIndex int32 = text.GetBeginIndex__I(); var textEndIndex int32 = text.GetEndIndex__I(); var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = beginIndex < textBeginIndex; if !tmp3 { tmp3 = endIndex > textEndIndex }; tmp2 = tmp3; if !tmp2 {
		tmp2 = beginIndex > endIndex }
//line :90:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1698))) }
	var textBuilder *StringBuilder = StringBuilder_New()
	text.SetIndex_I__C(beginIndex)
	var c uint16 = text.Current__C(); L1: for {
		if text.GetIndex__I() < endIndex { NN(textBuilder).Append_C__StringBuilder(c); c = text.Next__C(); continue L1 }
//line :95:1
		break L1
	}
	t.F_text = NN(textBuilder).ToString__String()
	if beginIndex == endIndex { } else {
		var keys HashSet_I = HashSet_New()
		if attributes == nil {
			keys.AddAll_Collection__Z(text.GetAllAttributeKeys__Set()) } else {

				var i int32 = 0; L2: for {
					if i < int32(len(attributes.A)) {
						keys.Add_O__Z(As[AttributedCharacterIterator_Attribute_I](attributes.A[i]))
						i = i + 1; continue L2 }
//line :103:1
					break L2
				}


				keys.RetainAll_Collection__Z(text.GetAllAttributeKeys__Set()) }
		if keys.IsEmpty__Z() { } else {
			var i_101265 Iterator = keys.Iterator__Iterator(); for i_101265.HasNext__Z() { var attributeKey AttributedCharacterIterator_Attribute_I = AttributedCharacterIterator_Attribute_Cast(i_101265.Next__O())
				text.SetIndex_I__C(textBeginIndex)
			L4: for { if text.GetIndex__I() < endIndex {
				var start int32 = text.GetRunStart_AttributedCharacterIterator_Attribute__I(attributeKey); var limit int32 = text.GetRunLimit_AttributedCharacterIterator_Attribute__I(attributeKey); var value any = text.GetAttribute_AttributedCharacterIterator_Attribute__O(attributeKey)


				if !(value == nil) {
					if Text_Annotation_InstanceOf(value) {
						var tmp4 bool; var tmp5 bool
						tmp5 = start >= beginIndex; if tmp5 { tmp5 = limit <= endIndex }; tmp4 = tmp5
//line :117:1
						if tmp4 {

							t.AddAttribute_AttributedCharacterIterator_Attribute_O_I_I__V(attributeKey, value, start-beginIndex, limit-beginIndex) } else {
//line :117:1
								if limit > endIndex {






									break L4 } } } else {

										if start >= endIndex { break L4 }
										if limit > beginIndex {
											if start < beginIndex { start = beginIndex }
											if limit > endIndex { limit = endIndex }
											if start == limit { } else {
												t.AddAttribute_AttributedCharacterIterator_Attribute_O_I_I__V(attributeKey, value, start-beginIndex, limit-beginIndex)
											}
										}
									}
				}
				text.SetIndex_I__C(limit)
//line :111:1
				continue L4 }; break L4
			}
			}
		}
	}
}





















func (t *AttributedString) AddAttribute_AttributedCharacterIterator_Attribute_O__V(attribute AttributedCharacterIterator_Attribute_I, value any) {
	if attribute == nil { panic(Thrown(NullPointerException_New())) }
	var len_ int32 = t.Length__I()
	if len_ == 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1697))) }
	t.AddAttributeImpl_AttributedCharacterIterator_Attribute_O_I_I__V(attribute, value, 0, len_)
}
func (t *AttributedString) AddAttribute_AttributedCharacterIterator_Attribute_O_I_I__V(attribute AttributedCharacterIterator_Attribute_I, value any, beginIndex, endIndex int32) {

	if attribute == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = beginIndex < 0; if !tmp3 { tmp3 = endIndex > t.Length__I() }; tmp2 = tmp3; if !tmp2 { tmp2 = beginIndex >= endIndex }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1698))) }
	t.AddAttributeImpl_AttributedCharacterIterator_Attribute_O_I_I__V(attribute, value, beginIndex, endIndex)
}
func (t *AttributedString) AddAttributes_Map_I_I__V(attributes Map, beginIndex, endIndex int32) {


	if attributes == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = beginIndex < 0; if !tmp3 { tmp3 = endIndex > t.Length__I() }; tmp2 = tmp3; if !tmp2 { tmp2 = beginIndex > endIndex }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1698))) }
	if beginIndex == endIndex {
		if attributes.IsEmpty__Z() { return }
		panic(Thrown(IllegalArgumentException_New_String(Lit_1697))) }
	if t.F_runCount == 0 { t.CreateRunAttributeDataVectors__V() }
	var beginRunIndex int32 = t.EnsureRunBreak_I__I(beginIndex); var endRunIndex int32 = t.EnsureRunBreak_I__I(endIndex); var i_101266 Iterator = attributes.EntrySet__Set().Iterator__Iterator(); for i_101266.HasNext__Z() {

		var entry Map_Entry = Map_Entry_Cast(i_101266.Next__O())

		t.AddAttributeRunData_AttributedCharacterIterator_Attribute_O_I_I__V(AttributedCharacterIterator_Attribute_Cast(entry.GetKey__O()), entry.GetValue__O(), beginRunIndex, endRunIndex)
	}
}



func (t *AttributedString) AddAttributeImpl_AttributedCharacterIterator_Attribute_O_I_I__V(attribute AttributedCharacterIterator_Attribute_I, value any, beginIndex, endIndex int32) { MonitorEnter(t); defer MonitorExit(t)


	if t.F_runCount == 0 { t.CreateRunAttributeDataVectors__V() }
	var beginRunIndex int32 = t.EnsureRunBreak_I__I(beginIndex); var endRunIndex int32 = t.EnsureRunBreak_I__I(endIndex)

	t.AddAttributeRunData_AttributedCharacterIterator_Attribute_O_I_I__V(attribute, value, beginRunIndex, endRunIndex)
}
func (t *AttributedString) CreateRunAttributeDataVectors__V() {
	var newRunStarts *IntArray = NewIntArray(10); var newRunAttributes *RefArray = NewRefArray(Vector_class, 10); var newRunAttributeValues *RefArray = NewRefArray(Vector_class, 10)




	t.F_runStarts = newRunStarts
	t.F_runAttributes = newRunAttributes
	t.F_runAttributeValues = newRunAttributeValues
	t.F_runCount = 1
}
func (t *AttributedString) EnsureRunBreak_I__I(offset int32) int32 {
	return t.EnsureRunBreak_I_Z__I(offset, true)
}
func (t *AttributedString) EnsureRunBreak_I_Z__I(offset int32, copyAttrs bool) int32 {
	if offset == t.Length__I() { return t.F_runCount } else {

		var runIndex int32 = 0
	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = runIndex < t.F_runCount; if tmp2 { tmp2 = t.F_runStarts.A[runIndex] < offset }; tmp1 = tmp2; if tmp1 {
		runIndex = runIndex + 1
//line :197:1
		continue L1 }; break L1
	}
		var tmp3 bool; var tmp4 bool; tmp4 = runIndex < t.F_runCount; if tmp4 { tmp4 = t.F_runStarts.A[runIndex] == offset }; tmp3 = tmp4; if tmp3 { return runIndex } else {

			var currentCapacity int32 = int32(len(t.F_runStarts.A))
			if t.F_runCount == currentCapacity {
				var newCapacity int32 = currentCapacity + currentCapacity>>2; var newRunStarts *IntArray = Arrays_CopyOf_I1_I__I1(t.F_runStarts, newCapacity); var newRunAttributes *RefArray = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(t.F_runAttributes, newCapacity).Ref(), Vector_class.ArrayClass()); var newRunAttributeValues *RefArray = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(t.F_runAttributeValues, newCapacity).Ref(), Vector_class.ArrayClass())










				t.F_runStarts = newRunStarts
				t.F_runAttributes = newRunAttributes
				t.F_runAttributeValues = newRunAttributeValues }
			var newRunAttributes_2 Vector_I; var newRunAttributeValues_2 Vector_I


			if copyAttrs {
				var oldRunAttributes Vector_I = As[Vector_I](t.F_runAttributes.A[runIndex-1]); var oldRunAttributeValues Vector_I = As[Vector_I](t.F_runAttributeValues.A[runIndex-1])






				if !(oldRunAttributes == nil) {
					newRunAttributes_2 = Vector_New_Collection(oldRunAttributes) }
				if !(oldRunAttributeValues == nil) {
					newRunAttributeValues_2 = Vector_New_Collection(oldRunAttributeValues) } }
			t.F_runCount = t.F_runCount + 1
			var i int32 = t.F_runCount - 1; L2: for {
				if i > runIndex {
					var tmp5 *IntArray = t.F_runStarts; tmp5.A[i] = t.F_runStarts.A[i-1]
					var tmp6 *RefArray = t.F_runAttributes; tmp6.Store(i, As[Vector_I](t.F_runAttributes.A[i-1]))
					var tmp7 *RefArray = t.F_runAttributeValues; tmp7.Store(i, As[Vector_I](t.F_runAttributeValues.A[i-1]))


					i = i - 1; continue L2 }
//line :233:1
				break L2
			}






			t.F_runStarts.A[runIndex] = offset
			t.F_runAttributes.Store(runIndex, newRunAttributes_2)
			t.F_runAttributeValues.Store(runIndex, newRunAttributeValues_2)
//line :217:1
			return runIndex
		}
	}
}

























func (t *AttributedString) AddAttributeRunData_AttributedCharacterIterator_Attribute_O_I_I__V(attribute AttributedCharacterIterator_Attribute_I, value any, beginRunIndex, endRunIndex int32) {

	var i int32 = beginRunIndex; L1: for {
		if i < endRunIndex {
			var keyValueIndex int32 = -1
			if As[Vector_I](t.F_runAttributes.A[i]) == nil {
				var newRunAttributes Vector_I = Vector_New(); var newRunAttributeValues Vector_I = Vector_New()


				t.F_runAttributes.Store(i, newRunAttributes)
				t.F_runAttributeValues.Store(i, newRunAttributeValues) } else {
					keyValueIndex = As[Vector_I](t.F_runAttributes.A[i]).IndexOf_O__I(attribute) }
			if keyValueIndex == -1 {
				var oldSize int32 = As[Vector_I](t.F_runAttributes.A[i]).Size__I()
				As[Vector_I](t.F_runAttributes.A[i]).AddElement_O__V(attribute); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

					As[Vector_I](t.F_runAttributeValues.A[i]).AddElement_O__V(value); return nil }()
//line :261:1
				if tmp1 != nil { if Exception_InstanceOf(tmp1) { var e Exception_I = Exception_Cast(tmp1); _ = e


					As[Vector_I](t.F_runAttributes.A[i]).SetSize_I__V(oldSize)
					As[Vector_I](t.F_runAttributeValues.A[i]).SetSize_I__V(oldSize) } else {
//line :261:1
						panic(tmp1)
					}
				}


				i = i + 1; continue L1 } else {

					As[Vector_I](t.F_runAttributeValues.A[i]).Set_I_O__O(keyValueIndex, value)
					i = i + 1; continue L1 } }
//line :248:1
		break L1
	}
}




















func (t *AttributedString) GetIterator__AttributedCharacterIterator() AttributedCharacterIterator {
	return t.GetIterator_AttributedCharacterIterator_Attribute1_I_I__AttributedCharacterIterator(nil, 0, t.Length__I())
}
func (t *AttributedString) GetIterator_AttributedCharacterIterator_Attribute1__AttributedCharacterIterator(attributes *RefArray) AttributedCharacterIterator {

	return t.GetIterator_AttributedCharacterIterator_Attribute1_I_I__AttributedCharacterIterator(attributes, 0, t.Length__I())
}
func (t *AttributedString) GetIterator_AttributedCharacterIterator_Attribute1_I_I__AttributedCharacterIterator(attributes *RefArray, beginIndex, endIndex int32) AttributedCharacterIterator {


	return AttributedString_AttributedStringIterator_New_AttributedString_AttributedCharacterIterator_Attribute1_I_I(t, attributes, beginIndex, endIndex)
}
func (t *AttributedString) Length__I() int32 { return NN(t.F_text).Length__I() }

func (t *AttributedString) CharAt_I__C(index int32) uint16 { return NN(t.F_text).CharAt_I__C(index) }

func (t *AttributedString) GetAttribute_AttributedCharacterIterator_Attribute_I__O(attribute AttributedCharacterIterator_Attribute_I, runIndex int32) any { MonitorEnter(t); defer MonitorExit(t)


	var currentRunAttributes Vector_I = As[Vector_I](t.F_runAttributes.A[runIndex]); var currentRunAttributeValues Vector_I = As[Vector_I](t.F_runAttributeValues.A[runIndex])



	if !(currentRunAttributes == nil) {
		var attributeIndex int32 = currentRunAttributes.IndexOf_O__I(attribute)
		if attributeIndex == -1 { return nil } else { return currentRunAttributeValues.ElementAt_I__O(attributeIndex) } } else {
//line :294:1
			return nil
		}
}

func (t *AttributedString) GetAttributeCheckRange_AttributedCharacterIterator_Attribute_I_I_I__O(attribute AttributedCharacterIterator_Attribute_I, runIndex, beginIndex, endIndex int32) any {

	var value any = t.GetAttribute_AttributedCharacterIterator_Attribute_I__O(attribute, runIndex)
	if Text_Annotation_InstanceOf(value) {
		if beginIndex > 0 {
			var currIndex int32 = runIndex; var runStart int32 = t.F_runStarts.A[currIndex]

		L1: for { var tmp1 bool; var tmp2 bool; tmp2 = runStart >= beginIndex; if tmp2 {
			tmp2 = Objects_Equals_O_O__Z(value, t.GetAttribute_AttributedCharacterIterator_Attribute_I__O(attribute, currIndex-1)) }
//line :305:1
			tmp1 = tmp2; if tmp1 {





				currIndex = currIndex - 1
				runStart = t.F_runStarts.A[currIndex]
//line :305:1
				continue L1 }; break L1
		}






			if runStart < beginIndex { return nil } }
		var textLength int32 = t.Length__I()
		if endIndex < textLength {
			var currIndex_2 int32 = runIndex; var runLimit int32
			if currIndex_2 < t.F_runCount-1 {
				runLimit = t.F_runStarts.A[currIndex_2+1] } else {
//line :317:1
					runLimit = textLength
				}

		L2: for { var tmp3 bool; var tmp4 bool; tmp4 = runLimit <= endIndex; if tmp4 {
			tmp4 = Objects_Equals_O_O__Z(value, t.GetAttribute_AttributedCharacterIterator_Attribute_I__O(attribute, currIndex_2+1)) }
//line :320:1
			tmp3 = tmp4; if tmp3 {





				currIndex_2 = currIndex_2 + 1
				var tmp5 int32
				if currIndex_2 < t.F_runCount-1 {
					tmp5 = t.F_runStarts.A[currIndex_2+1] } else {
//line :328:1
						tmp5 = textLength }
//line :327:1
				runLimit = tmp5
//line :320:1
				continue L2 }; break L2
		}









			if runLimit > endIndex { return nil } } }
//line :300:1
	return value
}
































func (t *AttributedString) AttributeValuesMatch_Set_I_I__Z(attributes Set, runIndex1, runIndex2 int32) bool {


	var i_101267 Iterator = attributes.Iterator__Iterator(); for i_101267.HasNext__Z() { var key AttributedCharacterIterator_Attribute_I = AttributedCharacterIterator_Attribute_Cast(i_101267.Next__O())
		if Objects_Equals_O_O__Z(t.GetAttribute_AttributedCharacterIterator_Attribute_I__O(key, runIndex1), t.GetAttribute_AttributedCharacterIterator_Attribute_I__O(key, runIndex2)) { } else {

			return false } }
//line :334:1
	return true
}







func (t *AttributedString) AppendContents_StringBuilder_CharacterIterator__V(buf *StringBuilder, iterator CharacterIterator) {

	var index int32 = iterator.GetBeginIndex__I(); var end int32 = iterator.GetEndIndex__I()

L1: for { if index < end {
	iterator.SetIndex_I__C(index)
	index = index + 1
	NN(buf).Append_C__StringBuilder(iterator.Current__C())
//line :347:1
	continue L1 }; break L1
}
}


func (t *AttributedString) SetAttributes_Map_I__V(attrs Map, offset int32) {


	if t.F_runCount == 0 { t.CreateRunAttributeDataVectors__V() }
	var index int32 = t.EnsureRunBreak_I_Z__I(offset, false); var size int32 = 0; var tmp1 bool; var tmp2 bool

	tmp2 = !(attrs == nil); if tmp2 { var tmp3 int32; size = attrs.Size__I(); tmp3 = size; tmp2 = tmp3 > 0 }; tmp1 = tmp2; if tmp1 {
		var runAttrs Vector_I = Vector_New_I(size); var runValues Vector_I = Vector_New_I(size); var i_101268 Iterator = attrs.EntrySet__Set().Iterator__Iterator(); for i_101268.HasNext__Z() {

			var entry Map_Entry = Map_Entry_Cast(i_101268.Next__O())

			runAttrs.Add_O__Z(AttributedCharacterIterator_Attribute_Cast(entry.GetKey__O()))
			runValues.Add_O__Z(entry.GetValue__O()) }
		t.F_runAttributes.Store(index, runAttrs)
		t.F_runAttributeValues.Store(index, runValues)
	} }
func AttributedString_MapsDiffer_Map_Map__Z(last, attrs Map) bool {

	if last == nil { var tmp1 bool; tmp1 = !(attrs == nil); if tmp1 { tmp1 = attrs.Size__I() > 0 }; return tmp1 } else { return !last.Equals_O__Z(attrs)
	}
}
















func AttributedString_AttributedStringIterator_New_AttributedString_AttributedCharacterIterator_Attribute1_I_I(p0 *AttributedString, p1 *RefArray, p2, p3 int32) *AttributedString_AttributedStringIterator { t := &AttributedString_AttributedStringIterator{}; t.Ctor_AttributedString_AttributedCharacterIterator_Attribute1_I_I(p0, p1, p2, p3); return t }
//line :389:1
func (t *AttributedString_AttributedStringIterator) Ctor_AttributedString_AttributedCharacterIterator_Attribute1_I_I(this_0 *AttributedString, attributes *RefArray, beginIndex, endIndex int32) { NN(this_0); t.F_this_0 = this_0

	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = beginIndex < 0; if !tmp3 { tmp3 = beginIndex > endIndex }; tmp2 = tmp3; if !tmp2 {
		tmp2 = endIndex > NN(this_0).Length__I() }
//line :391:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Lit_1698))) }
	t.F_beginIndex = beginIndex
	t.F_endIndex = endIndex
	t.F_currentIndex = beginIndex
	t.UpdateRunInfo__V()
	if !(attributes == nil) { t.F_relevantAttributes = NN(attributes).Copy()
	} }
func (t *AttributedString_AttributedStringIterator) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if AttributedString_AttributedStringIterator_InstanceOf(tmp1) { var that *AttributedString_AttributedStringIterator = AttributedString_AttributedStringIterator_Cast(tmp1)
			if !(t.F_this_0 == NN(that).GetString__AttributedString()) { return false } else { var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 int32 = t.F_currentIndex

				tmp4 = !(tmp5 == that.F_currentIndex); if !tmp4 {
					var tmp6 int32 = t.F_beginIndex; tmp4 = !(tmp6 == that.F_beginIndex) }
//line :406:1
				tmp3 = tmp4; if !tmp3 {

					var tmp7 int32 = t.F_endIndex; tmp3 = !(tmp7 == that.F_endIndex) }
//line :406:1
				tmp2 = tmp3
//line :404:1
				if tmp2 { return false } else { return true
				}
			} } else {
//line :403:1
				return false
			}
	}
}






func (t *AttributedString_AttributedStringIterator) HashCode__I() int32 {
	return NN(t.F_this_0.F_text).HashCode__I() ^ t.F_currentIndex ^ t.F_beginIndex ^ t.F_endIndex
}
func (t *AttributedString_AttributedStringIterator) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var other *AttributedString_AttributedStringIterator = AttributedString_AttributedStringIterator_Cast(A2g_ObjectClone(t)); tmp1 = other.Ref() }; return nil }()
//line :417:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :417:1
			panic(tmp2) } }; return tmp1
}


func (t *AttributedString_AttributedStringIterator) First__C() uint16 { return t.InternalSetIndex_I__C(t.F_beginIndex) }

func (t *AttributedString_AttributedStringIterator) Last__C() uint16 {
	if t.F_endIndex == t.F_beginIndex {
		return t.InternalSetIndex_I__C(t.F_endIndex) } else {
			return t.InternalSetIndex_I__C(t.F_endIndex - 1)
		} }
func (t *AttributedString_AttributedStringIterator) Current__C() uint16 {
	if t.F_currentIndex == t.F_endIndex { return 65535 } else {

		return NN(t.F_this_0).CharAt_I__C(t.F_currentIndex)
	} }
func (t *AttributedString_AttributedStringIterator) Next__C() uint16 {
	if t.F_currentIndex < t.F_endIndex {
		return t.InternalSetIndex_I__C(t.F_currentIndex + 1) } else {
//line :434:1
			return 65535
		}
}

func (t *AttributedString_AttributedStringIterator) Previous__C() uint16 {
	if t.F_currentIndex > t.F_beginIndex {
		return t.InternalSetIndex_I__C(t.F_currentIndex - 1) } else {
//line :439:1
			return 65535
		}
}

func (t *AttributedString_AttributedStringIterator) SetIndex_I__C(position int32) uint16 {
	var tmp1 bool; var tmp2 bool; tmp2 = position < t.F_beginIndex; if !tmp2 { tmp2 = position > t.F_endIndex }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1699))) }
	return t.InternalSetIndex_I__C(position)
}
func (t *AttributedString_AttributedStringIterator) GetBeginIndex__I() int32 { return t.F_beginIndex }

func (t *AttributedString_AttributedStringIterator) GetEndIndex__I() int32 { return t.F_endIndex }

func (t *AttributedString_AttributedStringIterator) GetIndex__I() int32 { return t.F_currentIndex }

func (t *AttributedString_AttributedStringIterator) GetRunStart__I() int32 { return t.F_currentRunStart }

func (t *AttributedString_AttributedStringIterator) GetRunStart_AttributedCharacterIterator_Attribute__I(attribute AttributedCharacterIterator_Attribute_I) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_currentRunStart == t.F_beginIndex; if !tmp2 { tmp2 = t.F_currentRunIndex == -1 }; tmp1 = tmp2; if tmp1 { return t.F_currentRunStart } else {

		var value any = t.GetAttribute_AttributedCharacterIterator_Attribute__O(attribute); var runStart int32 = t.F_currentRunStart; var runIndex int32 = t.F_currentRunIndex


	L1: for { var tmp3 bool; var tmp4 bool; tmp4 = runStart > t.F_beginIndex; if tmp4 {
		tmp4 = Objects_Equals_O_O__Z(value, NN(t.F_this_0).GetAttribute_AttributedCharacterIterator_Attribute_I__O(attribute, runIndex-1)) }
//line :462:1
		tmp3 = tmp4; if tmp3 {





			runIndex = runIndex - 1
			runStart = t.F_this_0.F_runStarts.A[runIndex]
//line :462:1
			continue L1 }; break L1
	}






		if runStart < t.F_beginIndex { runStart = t.F_beginIndex }
//line :459:1
		return runStart
	}
}











func (t *AttributedString_AttributedStringIterator) GetRunStart_Set__I(attributes Set) int32 {

	var tmp1 bool; var tmp2 bool; tmp2 = t.F_currentRunStart == t.F_beginIndex; if !tmp2 { tmp2 = t.F_currentRunIndex == -1 }; tmp1 = tmp2; if tmp1 { return t.F_currentRunStart } else {

		var runStart int32 = t.F_currentRunStart; var runIndex int32 = t.F_currentRunIndex

	L1: for { var tmp3 bool; var tmp4 bool; tmp4 = runStart > t.F_beginIndex; if tmp4 {
		tmp4 = NN(t.F_this_0).AttributeValuesMatch_Set_I_I__Z(attributes, t.F_currentRunIndex, runIndex-1) }
//line :479:1
		tmp3 = tmp4; if tmp3 {




			runIndex = runIndex - 1
			runStart = t.F_this_0.F_runStarts.A[runIndex]
//line :479:1
			continue L1 }; break L1
	}





		if runStart < t.F_beginIndex { runStart = t.F_beginIndex }
//line :477:1
		return runStart
	}
}









func (t *AttributedString_AttributedStringIterator) GetRunLimit__I() int32 { return t.F_currentRunLimit }

func (t *AttributedString_AttributedStringIterator) GetRunLimit_AttributedCharacterIterator_Attribute__I(attribute AttributedCharacterIterator_Attribute_I) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_currentRunLimit == t.F_endIndex; if !tmp2 { tmp2 = t.F_currentRunIndex == -1 }; tmp1 = tmp2; if tmp1 { return t.F_currentRunLimit } else {

		var value any = t.GetAttribute_AttributedCharacterIterator_Attribute__O(attribute); var runLimit int32 = t.F_currentRunLimit; var runIndex int32 = t.F_currentRunIndex


	L1: for { var tmp3 bool; var tmp4 bool; tmp4 = runLimit < t.F_endIndex; if tmp4 {
		tmp4 = Objects_Equals_O_O__Z(value, NN(t.F_this_0).GetAttribute_AttributedCharacterIterator_Attribute_I__O(attribute, runIndex+1)) }
//line :497:1
		tmp3 = tmp4; if tmp3 {





			runIndex = runIndex + 1
			var tmp5 int32
			if runIndex < t.F_this_0.F_runCount-1 {
				tmp5 = t.F_this_0.F_runStarts.A[runIndex+1] } else {
//line :505:1
					tmp5 = t.F_endIndex }
//line :504:1
			runLimit = tmp5
//line :497:1
			continue L1 }; break L1
	}









		if runLimit > t.F_endIndex { runLimit = t.F_endIndex }
//line :494:1
		return runLimit
	}
}














func (t *AttributedString_AttributedStringIterator) GetRunLimit_Set__I(attributes Set) int32 {

	var tmp1 bool; var tmp2 bool; tmp2 = t.F_currentRunLimit == t.F_endIndex; if !tmp2 { tmp2 = t.F_currentRunIndex == -1 }; tmp1 = tmp2; if tmp1 { return t.F_currentRunLimit } else {

		var runLimit int32 = t.F_currentRunLimit; var runIndex int32 = t.F_currentRunIndex

	L1: for { var tmp3 bool; var tmp4 bool; tmp4 = runLimit < t.F_endIndex; if tmp4 {
		tmp4 = NN(t.F_this_0).AttributeValuesMatch_Set_I_I__Z(attributes, t.F_currentRunIndex, runIndex+1) }
//line :517:1
		tmp3 = tmp4; if tmp3 {




			runIndex = runIndex + 1
			var tmp5 int32
			if runIndex < t.F_this_0.F_runCount-1 {
				tmp5 = t.F_this_0.F_runStarts.A[runIndex+1] } else {
//line :524:1
					tmp5 = t.F_endIndex }
//line :523:1
			runLimit = tmp5
//line :517:1
			continue L1 }; break L1
	}








		if runLimit > t.F_endIndex { runLimit = t.F_endIndex }
//line :515:1
		return runLimit
	}
}












func (t *AttributedString_AttributedStringIterator) GetAttributes__Map() Map {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = t.F_this_0.F_runAttributes == nil; if !tmp3 { tmp3 = t.F_currentRunIndex == -1 }; tmp2 = tmp3; if !tmp2 {
		tmp2 = As[Vector_I](t.F_this_0.F_runAttributes.A[t.F_currentRunIndex]) == nil }
//line :531:1
	tmp1 = tmp2; if tmp1 {

		return Hashtable_New() } else {
			return AttributedString_AttributeMap_New_AttributedString_I_I_I(t.F_this_0, t.F_currentRunIndex, t.F_beginIndex, t.F_endIndex)
		} }
func (t *AttributedString_AttributedStringIterator) GetAllAttributeKeys__Set() Set {
	if t.F_this_0.F_runAttributes == nil {
		return HashSet_New() } else {
			var tmp1 Set; var tmp2 any = t.F_this_0.Ref(); MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
				var keys Set = HashSet_New()
				var i int32 = 0
			L1: for { if i < t.F_this_0.F_runCount {
				var tmp3 bool; var tmp4 bool; tmp4 = t.F_this_0.F_runStarts.A[i] < t.F_endIndex; if tmp4 {
					var tmp5 bool; tmp5 = i == t.F_this_0.F_runCount-1; if !tmp5 {
						tmp5 = t.F_this_0.F_runStarts.A[i+1] > t.F_beginIndex }
//line :544:1
					tmp4 = tmp5 }
//line :543:1
				tmp3 = tmp4; if tmp3 {


					var currentRunAttributes Vector_I = As[Vector_I](t.F_this_0.F_runAttributes.A[i])

					if !(currentRunAttributes == nil) {
						var j int32 = currentRunAttributes.Size__I()
					L2: for { var tmp6 int32; var old_1 int32 = j; j = j - 1; tmp6 = old_1; if tmp6 > 0 {
						keys.Add_O__Z(AttributedCharacterIterator_Attribute_Cast(currentRunAttributes.Get_I__O(j)))
//line :550:1
						continue L2 }; break L2
					}
					}
				}
				i = i + 1
//line :542:1
				continue L1 }; break L1 }
//line :540:1
				tmp1 = keys }()
//line :539:1
			return tmp1
		}
}















func (t *AttributedString_AttributedStringIterator) GetAttribute_AttributedCharacterIterator_Attribute__O(attribute AttributedCharacterIterator_Attribute_I) any {
	var runIndex int32 = t.F_currentRunIndex
	if runIndex < 0 { return nil } else {
		return NN(t.F_this_0).GetAttributeCheckRange_AttributedCharacterIterator_Attribute_I_I_I__O(attribute, runIndex, t.F_beginIndex, t.F_endIndex)
	} }
func (t *AttributedString_AttributedStringIterator) GetString__AttributedString() *AttributedString { return t.F_this_0 }


func (t *AttributedString_AttributedStringIterator) InternalSetIndex_I__C(position int32) uint16 {
	t.F_currentIndex = position
	var tmp1 bool; var tmp2 bool; tmp2 = position < t.F_currentRunStart; if !tmp2 { tmp2 = position >= t.F_currentRunLimit }; tmp1 = tmp2; if tmp1 { t.UpdateRunInfo__V() }
	if t.F_currentIndex == t.F_endIndex { return 65535 } else {

		return NN(t.F_this_0).CharAt_I__C(position)
	} }
func (t *AttributedString_AttributedStringIterator) UpdateRunInfo__V() {
	if t.F_currentIndex == t.F_endIndex {
		var tmp1 int32; var tmp2 int32 = t.F_endIndex; t.F_currentRunLimit = tmp2; tmp1 = tmp2; t.F_currentRunStart = tmp1; t.F_currentRunIndex = -1 } else {
			var tmp3 any = t.F_this_0.Ref(); MonitorEnter(tmp3); func() { defer MonitorExit(tmp3)
				var runIndex int32 = -1
			L1: for { var tmp4 bool; var tmp5 bool; tmp5 = runIndex < t.F_this_0.F_runCount-1; if tmp5 {
				tmp5 = t.F_this_0.F_runStarts.A[runIndex+1] <= t.F_currentIndex }
//line :577:1
				tmp4 = tmp5; if tmp4 {

					runIndex = runIndex + 1
//line :577:1
					continue L1 }; break L1
			}

				t.F_currentRunIndex = runIndex
				if runIndex >= 0 {

					t.F_currentRunStart = t.F_this_0.F_runStarts.A[runIndex]
					if t.F_currentRunStart < t.F_beginIndex { t.F_currentRunStart = t.F_beginIndex } } else {
						t.F_currentRunStart = t.F_beginIndex }
				if runIndex < t.F_this_0.F_runCount-1 {

					t.F_currentRunLimit = t.F_this_0.F_runStarts.A[runIndex+1]
					if t.F_currentRunLimit > t.F_endIndex { t.F_currentRunLimit = t.F_endIndex } } else {
						t.F_currentRunLimit = t.F_endIndex
					}
			}()
		}
}






func AttributedString_AttributeMap_New_AttributedString_I_I_I(p0 *AttributedString, p1, p2, p3 int32) *AttributedString_AttributeMap { t := &AttributedString_AttributeMap{}; t.Ctor_AttributedString_I_I_I(p0, p1, p2, p3); return t }
//line :601:1
func (t *AttributedString_AttributeMap) Ctor_AttributedString_I_I_I(this_0 *AttributedString, runIndex, beginIndex, endIndex int32) { NN(this_0); t.F_this_0 = this_0; t.AbstractMap.Ctor(t)
	t.F_runIndex = runIndex
	t.F_beginIndex = beginIndex
	t.F_endIndex = endIndex
}
func (t *AttributedString_AttributeMap) EntrySet__Set() Set {
	var set HashSet_I = HashSet_New(); var tmp1 any = t.F_this_0.Ref()

	MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		var size int32 = As[Vector_I](t.F_this_0.F_runAttributes.A[t.F_runIndex]).Size__I(); var i int32 = 0
	L1: for {
		if i < size {
			var key AttributedCharacterIterator_Attribute_I = AttributedCharacterIterator_Attribute_Cast(As[Vector_I](t.F_this_0.F_runAttributes.A[t.F_runIndex]).Get_I__O(i)); var value any = As[Vector_I](t.F_this_0.F_runAttributeValues.A[t.F_runIndex]).Get_I__O(i)


			if Text_Annotation_InstanceOf(value) {
				value = NN(t.F_this_0).GetAttributeCheckRange_AttributedCharacterIterator_Attribute_I_I_I__O(key, t.F_runIndex, t.F_beginIndex, t.F_endIndex)






				if value == nil { i = i + 1; continue L1 } }
			var entry Map_Entry = AttributeEntry_New_AttributedCharacterIterator_Attribute_O(key, value)

			set.Add_O__Z(entry)
			i = i + 1; continue L1 }
//line :611:1
		break L1 } }()
//line :607:1
	return set
}






















func (t *AttributedString_AttributeMap) Get_O__O(key any) any {
	return NN(t.F_this_0).GetAttributeCheckRange_AttributedCharacterIterator_Attribute_I_I_I__O(AttributedCharacterIterator_Attribute_Cast(key), t.F_runIndex, t.F_beginIndex, t.F_endIndex)
}


type AttributedString struct{ Object; F_text *String; F_runCount int32; F_runStarts *IntArray; F_runAttributes, F_runAttributeValues *RefArray }

const AttributedString_INITIAL_CAPACITY int32 = 10

func (t *AttributedString) Ref() any { if t == nil { return nil }; return t }

func (t *AttributedString) GetClass__Class() *Class { return AttributedString_class }

func (t *AttributedString) ToString__String() *String { return Object_toString(t) }

func (t *AttributedString) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AttributedString) CloneShallow() any { panic(CloneNotSupported(t)) }

func AttributedString_InstanceOf(x any) bool { _, ok := x.(*AttributedString); return ok }

func AttributedString_Cast(x any) *AttributedString { if x == nil { return nil }; v, ok := x.(*AttributedString); if !ok { panic(ClassCast(x, AttributedString_class)) }; return v }



type AttributedString_AttributeMap struct{ AbstractMap; F_runIndex, F_beginIndex, F_endIndex int32; F_this_0 *AttributedString }

func (t *AttributedString_AttributeMap) Replace_O_O__O(p0, p1 any) any { return Map_Replace_O_O__O(t, p0, p1) }

func (t *AttributedString_AttributeMap) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *AttributedString_AttributeMap) Clear__V() { t.Impl_Clear__V(t) }

func (t *AttributedString_AttributeMap) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *AttributedString_AttributeMap) Remove_O_O__Z(p0, p1 any) bool { return Map_Remove_O_O__Z(t, p0, p1) }

func (t *AttributedString_AttributeMap) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *AttributedString_AttributeMap) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *AttributedString_AttributeMap) GetOrDefault_O_O__O(p0, p1 any) any { return Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *AttributedString_AttributeMap) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *AttributedString_AttributeMap) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *AttributedString_AttributeMap) ReplaceAll_BiFunction__V(p0 BiFunction) { Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *AttributedString_AttributeMap) PutIfAbsent_O_O__O(p0, p1 any) any { return Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *AttributedString_AttributeMap) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *AttributedString_AttributeMap) ForEach_BiConsumer__V(p0 BiConsumer) { Map_ForEach_BiConsumer__V(t, p0) }

func (t *AttributedString_AttributeMap) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *AttributedString_AttributeMap) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *AttributedString_AttributeMap) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *AttributedString_AttributeMap) Replace_O_O_O__Z(p0, p1, p2 any) bool { return Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *AttributedString_AttributeMap) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *AttributedString_AttributeMap) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *AttributedString_AttributeMap) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *AttributedString_AttributeMap) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *AttributedString_AttributeMap) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *AttributedString_AttributeMap) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *AttributedString_AttributeMap) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AttributedString_AttributeMap) Ref() any { if t == nil { return nil }; return t }

func (t *AttributedString_AttributeMap) GetClass__Class() *Class { return AttributedString_AttributeMap_class }

func (t *AttributedString_AttributeMap) CloneShallow() any { panic(CloneNotSupported(t)) }

func AttributedString_AttributeMap_InstanceOf(x any) bool { _, ok := x.(*AttributedString_AttributeMap); return ok }

func AttributedString_AttributeMap_Cast(x any) *AttributedString_AttributeMap { if x == nil { return nil }; v, ok := x.(*AttributedString_AttributeMap); if !ok { panic(ClassCast(x, AttributedString_AttributeMap_class)) }; return v }



type AttributedString_AttributedStringIterator struct{ Object; F_beginIndex, F_endIndex int32; F_relevantAttributes *RefArray; F_currentIndex, F_currentRunIndex, F_currentRunStart, F_currentRunLimit int32; F_this_0 *AttributedString }

func (t *AttributedString_AttributedStringIterator) Is_AttributedCharacterIterator() {}

func (t *AttributedString_AttributedStringIterator) Is_CharacterIterator() {}

func (t *AttributedString_AttributedStringIterator) Is_Cloneable() {}

func (t *AttributedString_AttributedStringIterator) Ref() any { if t == nil { return nil }; return t }

func (t *AttributedString_AttributedStringIterator) GetClass__Class() *Class { return AttributedString_AttributedStringIterator_class }

func (t *AttributedString_AttributedStringIterator) ToString__String() *String { return Object_toString(t) }

func (t *AttributedString_AttributedStringIterator) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func AttributedString_AttributedStringIterator_InstanceOf(x any) bool { _, ok := x.(*AttributedString_AttributedStringIterator); return ok }

func AttributedString_AttributedStringIterator_Cast(x any) *AttributedString_AttributedStringIterator { if x == nil { return nil }; v, ok := x.(*AttributedString_AttributedStringIterator); if !ok { panic(ClassCast(x, AttributedString_AttributedStringIterator_class)) }; return v }
