//line java_util_Iterator.ae:1
package jrt












func Iterator_Remove__V(this Iterator) {
	panic(Thrown(UnsupportedOperationException_New_String(Lit_2736)))
}
func Iterator_ForEachRemaining_Consumer__V(this Iterator, action Consumer) {
	Objects_RequireNonNull_O__O(action)
L1: for { if this.HasNext__Z() { action.Accept_O__V(this.Next__O()); continue L1 }; break L1
}
}

type Iterator interface{ Object_I; Is_Iterator(); HasNext__Z() bool; Next__O() any; Remove__V(); ForEachRemaining_Consumer__V(p0 Consumer) }

func Iterator_InstanceOf(x any) bool { _, ok := x.(Iterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Iterator_class) } }; return ok }

func Iterator_Cast(x any) Iterator { if x == nil { return nil }; v, ok := x.(Iterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Iterator_class) } }; if !ok { panic(ClassCast(x, Iterator_class)) }; return v }
