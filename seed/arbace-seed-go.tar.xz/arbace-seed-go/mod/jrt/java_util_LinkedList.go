//line java_util_LinkedList.ae:1
package jrt


























func LinkedList_New() *LinkedList { t := &LinkedList{}; t.Ctor(t); return t }
//line :28:1
func (t *LinkedList) Ctor(this LinkedList_I) { t.AbstractSequentialList.Ctor(this); t.F_size = 0 }

func LinkedList_New_Collection(p0 Collection) *LinkedList { t := &LinkedList{}; t.Ctor_Collection(t, p0); return t }
//line :30:1
func (t *LinkedList) Ctor_Collection(this LinkedList_I, c Collection) { t.Ctor(this)

	this.AddAll_Collection__Z(c)
}
func (t *LinkedList) Impl_LinkFirst_O__V(this LinkedList_I, e any) {
	var f *LinkedList_Node = t.F_first; var newNode *LinkedList_Node = LinkedList_Node_New_LinkedList_Node_O_LinkedList_Node(nil, e, f)

	t.F_first = newNode
	if f == nil { t.F_last = newNode } else { f.F_prev = newNode }
	t.F_size = t.F_size + 1
	t.F_modCount = t.F_modCount + 1
}
func (t *LinkedList) Impl_LinkLast_O__V(this LinkedList_I, e any) {
	var l *LinkedList_Node = t.F_last; var newNode *LinkedList_Node = LinkedList_Node_New_LinkedList_Node_O_LinkedList_Node(l, e, nil)

	t.F_last = newNode
	if l == nil { t.F_first = newNode } else { l.F_next = newNode }
	t.F_size = t.F_size + 1
	t.F_modCount = t.F_modCount + 1
}
func (t *LinkedList) Impl_LinkBefore_O_LinkedList_Node__V(this LinkedList_I, e any, succ *LinkedList_Node) {
	var pred *LinkedList_Node = succ.F_prev; var newNode *LinkedList_Node = LinkedList_Node_New_LinkedList_Node_O_LinkedList_Node(pred, e, succ)

	succ.F_prev = newNode
	if pred == nil { t.F_first = newNode } else { pred.F_next = newNode }
	t.F_size = t.F_size + 1
	t.F_modCount = t.F_modCount + 1
}
func (t *LinkedList) Impl_UnlinkFirst_LinkedList_Node__O(this LinkedList_I, f *LinkedList_Node) any {
	var element any = f.F_item; var next *LinkedList_Node = f.F_next

	f.F_item = nil
	f.F_next = nil
	t.F_first = next
	if next == nil { t.F_last = nil } else { next.F_prev = nil }
	t.F_size = t.F_size - 1
	t.F_modCount = t.F_modCount + 1
//line :59:1
	return element
}








func (t *LinkedList) Impl_UnlinkLast_LinkedList_Node__O(this LinkedList_I, l *LinkedList_Node) any {
	var element any = l.F_item; var prev *LinkedList_Node = l.F_prev

	l.F_item = nil
	l.F_prev = nil
	t.F_last = prev
	if prev == nil { t.F_first = nil } else { prev.F_next = nil }
	t.F_size = t.F_size - 1
	t.F_modCount = t.F_modCount + 1
//line :70:1
	return element
}








func (t *LinkedList) Impl_Unlink_LinkedList_Node__O(this LinkedList_I, x *LinkedList_Node) any {
	var element any = x.F_item; var next *LinkedList_Node = x.F_next; var prev *LinkedList_Node = x.F_prev


	if prev == nil { t.F_first = next } else { prev.F_next = next; x.F_prev = nil }
	if next == nil { t.F_last = prev } else { next.F_prev = prev; x.F_next = nil }
	x.F_item = nil
	t.F_size = t.F_size - 1
	t.F_modCount = t.F_modCount + 1
//line :81:1
	return element
}








func (t *LinkedList) Impl_GetFirst__O(this LinkedList_I) any {
	var f *LinkedList_Node = t.F_first; if f == nil { panic(Thrown(NoSuchElementException_New())) }; return f.F_item
}
func (t *LinkedList) Impl_GetLast__O(this LinkedList_I) any {
	var l *LinkedList_Node = t.F_last; if l == nil { panic(Thrown(NoSuchElementException_New())) }; return l.F_item
}
func (t *LinkedList) Impl_RemoveFirst__O(this LinkedList_I) any {
	var f *LinkedList_Node = t.F_first
	if f == nil { panic(Thrown(NoSuchElementException_New())) }
	return t.Impl_UnlinkFirst_LinkedList_Node__O(this, f)
}
func (t *LinkedList) Impl_RemoveLast__O(this LinkedList_I) any {
	var l *LinkedList_Node = t.F_last
	if l == nil { panic(Thrown(NoSuchElementException_New())) }
	return t.Impl_UnlinkLast_LinkedList_Node__O(this, l)
}
func (t *LinkedList) Impl_AddFirst_O__V(this LinkedList_I, e any) { t.Impl_LinkFirst_O__V(this, e) }

func (t *LinkedList) Impl_AddLast_O__V(this LinkedList_I, e any) { this.LinkLast_O__V(e) }

func (t *LinkedList) Impl_Contains_O__Z(this LinkedList_I, o any) bool { return this.IndexOf_O__I(o) >= 0 }

func (t *LinkedList) Impl_Size__I(this LinkedList_I) int32 { return t.F_size }

func (t *LinkedList) Impl_Add_O__Z(this LinkedList_I, e any) bool { this.LinkLast_O__V(e); return true }

func (t *LinkedList) Impl_Remove_O__Z(this LinkedList_I, o any) bool {
	if o == nil {
		var x *LinkedList_Node = t.F_first; L1: for {
			if !(x == nil) {
				if x.F_item == nil { this.Unlink_LinkedList_Node__O(x); return true } else { x = x.F_next; continue L1 } }
//line :119:1
			break L1
		} } else {


			var x_2 *LinkedList_Node = t.F_first; L2: for {
				if !(x_2 == nil) {
					if Equals(o, x_2.F_item) { this.Unlink_LinkedList_Node__O(x_2); return true } else { x_2 = x_2.F_next; continue L2 } }
//line :123:1
				break L2 } }
//line :117:1
	return false
}










func (t *LinkedList) Impl_AddAll_Collection__Z(this LinkedList_I, c Collection) bool {
	return this.AddAll_I_Collection__Z(t.F_size, c)
}
func (t *LinkedList) Impl_AddAll_I_Collection__Z(this LinkedList_I, index int32, c Collection) bool {
	t.Impl_CheckPositionIndex_I__V(this, index)
	var a *RefArray = c.ToArray__O1(); var numNew int32 = int32(len(a.A))

	if numNew == 0 { return false } else {

		var pred *LinkedList_Node; var succ *LinkedList_Node

		if index == t.F_size {
			succ = nil; pred = t.F_last } else {
				succ = this.Node_I__LinkedList_Node(index); pred = succ.F_prev }
		var arr_101938 *RefArray = a; var len_101939 int32 = int32(len(arr_101938.A)); var i_101940 int32 = 0; for ; i_101940 < len_101939; i_101940++ { var o any = arr_101938.A[i_101940]; var e any = o; var newNode *LinkedList_Node = LinkedList_Node_New_LinkedList_Node_O_LinkedList_Node(pred, e, nil)


			if pred == nil { t.F_first = newNode } else { pred.F_next = newNode }
			pred = newNode }
		if succ == nil {
			t.F_last = pred } else {
				pred.F_next = succ; succ.F_prev = pred }
		t.F_size = t.F_size + numNew
		t.F_modCount = t.F_modCount + 1
//line :138:1
		return true
	}
}














func (t *LinkedList) Impl_Clear__V(this LinkedList_I) {
	var x *LinkedList_Node = t.F_first
L1: for { if !(x == nil) {
	var next *LinkedList_Node = x.F_next
	x.F_item = nil
	x.F_next = nil
	x.F_prev = nil
	x = next
//line :157:1
	continue L1 }; break L1
}




	var tmp1 *LinkedList_Node; var tmp2 *LinkedList_Node; t.F_last = tmp2; tmp1 = tmp2; t.F_first = tmp1
	t.F_size = 0
	t.F_modCount = t.F_modCount + 1
}
func (t *LinkedList) Impl_Get_I__O(this LinkedList_I, index int32) any {
	t.Impl_CheckElementIndex_I__V(this, index)
	return this.Node_I__LinkedList_Node(index).F_item
}
func (t *LinkedList) Impl_Set_I_O__O(this LinkedList_I, index int32, element any) any {
	t.Impl_CheckElementIndex_I__V(this, index)
	var x *LinkedList_Node = this.Node_I__LinkedList_Node(index); var oldVal any = x.F_item

	x.F_item = element
//line :173:1
	return oldVal
}



func (t *LinkedList) Impl_Add_I_O__V(this LinkedList_I, index int32, element any) {
	t.Impl_CheckPositionIndex_I__V(this, index)
	if index == t.F_size { this.LinkLast_O__V(element) } else { this.LinkBefore_O_LinkedList_Node__V(element, this.Node_I__LinkedList_Node(index))
	} }
func (t *LinkedList) Impl_Remove_I__O(this LinkedList_I, index int32) any {
	t.Impl_CheckElementIndex_I__V(this, index)
	return this.Unlink_LinkedList_Node__O(this.Node_I__LinkedList_Node(index))
}
func (t *LinkedList) Impl_IsElementIndex_I__Z(this LinkedList_I, index int32) bool {
	var tmp1 bool; tmp1 = index >= 0; if tmp1 { tmp1 = index < t.F_size }; return tmp1
}
func (t *LinkedList) Impl_IsPositionIndex_I__Z(this LinkedList_I, index int32) bool {
	var tmp1 bool; tmp1 = index >= 0; if tmp1 { tmp1 = index <= t.F_size }; return tmp1
}
func (t *LinkedList) Impl_OutOfBoundsMsg_I__String(this LinkedList_I, index int32) *String {
	return Concat(Lit_2595, StrOfInt(index), Lit_2596, StrOfInt(t.F_size))
}
func (t *LinkedList) Impl_CheckElementIndex_I__V(this LinkedList_I, index int32) {
	if t.Impl_IsElementIndex_I__Z(this, index) { } else {
		panic(Thrown(IndexOutOfBoundsException_New_String(t.Impl_OutOfBoundsMsg_I__String(this, index))))
	} }
func (t *LinkedList) Impl_CheckPositionIndex_I__V(this LinkedList_I, index int32) {
	if t.Impl_IsPositionIndex_I__Z(this, index) { } else {
		panic(Thrown(IndexOutOfBoundsException_New_String(t.Impl_OutOfBoundsMsg_I__String(this, index))))
	} }
func (t *LinkedList) Impl_Node_I__LinkedList_Node(this LinkedList_I, index int32) *LinkedList_Node {
	if index < t.F_size>>1 {
		var x *LinkedList_Node = t.F_first; var i int32 = 0
	L1: for { if i < index { x = x.F_next; i = i + 1; continue L1 }; break L1 }
//line :205:1
		return x } else {


			var x_2 *LinkedList_Node = t.F_last; var i_2 int32 = t.F_size - 1
		L2: for {
			if i_2 > index { x_2 = x_2.F_prev; i_2 = i_2 - 1; continue L2 }
//line :209:1
			break L2 }
//line :208:1
			return x_2
		}
}


func (t *LinkedList) Impl_IndexOf_O__I(this LinkedList_I, o any) int32 {
	var index int32 = 0
	if o == nil {
		var x *LinkedList_Node = t.F_first; L1: for {
			if !(x == nil) {
				if x.F_item == nil { return index }
				index = index + 1
				x = x.F_next; continue L1 }
//line :216:1
			break L1
		}

	} else {

		var x_2 *LinkedList_Node = t.F_first; L2: for {
			if !(x_2 == nil) {
				if Equals(o, x_2.F_item) { return index }
				index = index + 1
				x_2 = x_2.F_next; continue L2 }
//line :221:1
			break L2 } }
//line :214:1
	return -1
}












func (t *LinkedList) Impl_LastIndexOf_O__I(this LinkedList_I, o any) int32 {
	var index int32 = t.F_size
	if o == nil {
		var x *LinkedList_Node = t.F_last; L1: for {
			if !(x == nil) {
				index = index - 1
				if x.F_item == nil { return index } else { x = x.F_prev; continue L1 } }
//line :231:1
			break L1
		}
	} else {

		var x_2 *LinkedList_Node = t.F_last; L2: for {
			if !(x_2 == nil) {
				index = index - 1
				if Equals(o, x_2.F_item) { return index } else { x_2 = x_2.F_prev; continue L2 } }
//line :235:1
			break L2 } }
//line :229:1
	return -1
}










func (t *LinkedList) Impl_Peek__O(this LinkedList_I) any {
	var f *LinkedList_Node = t.F_first; if !(f == nil) { return f.F_item } else { return nil
	} }
func (t *LinkedList) Impl_Element__O(this LinkedList_I) any { return this.GetFirst__O() }

func (t *LinkedList) Impl_Poll__O(this LinkedList_I) any {
	var f *LinkedList_Node = t.F_first; if !(f == nil) { return t.Impl_UnlinkFirst_LinkedList_Node__O(this, f) } else { return nil
	} }
func (t *LinkedList) Impl_Remove__O(this LinkedList_I) any { return this.RemoveFirst__O() }

func (t *LinkedList) Impl_Offer_O__Z(this LinkedList_I, e any) bool { return this.Add_O__Z(e) }

func (t *LinkedList) Impl_OfferFirst_O__Z(this LinkedList_I, e any) bool {
	this.AddFirst_O__V(e)
//line :253:1
	return true
}


func (t *LinkedList) Impl_OfferLast_O__Z(this LinkedList_I, e any) bool { this.AddLast_O__V(e); return true }

func (t *LinkedList) Impl_PeekFirst__O(this LinkedList_I) any {
	var f *LinkedList_Node = t.F_first; if !(f == nil) { return f.F_item } else { return nil
	} }
func (t *LinkedList) Impl_PeekLast__O(this LinkedList_I) any {
	var l *LinkedList_Node = t.F_last; if !(l == nil) { return l.F_item } else { return nil
	} }
func (t *LinkedList) Impl_PollFirst__O(this LinkedList_I) any {
	var f *LinkedList_Node = t.F_first; if !(f == nil) { return t.Impl_UnlinkFirst_LinkedList_Node__O(this, f) } else { return nil
	} }
func (t *LinkedList) Impl_PollLast__O(this LinkedList_I) any {
	var l *LinkedList_Node = t.F_last; if !(l == nil) { return t.Impl_UnlinkLast_LinkedList_Node__O(this, l) } else { return nil
	} }
func (t *LinkedList) Impl_Push_O__V(this LinkedList_I, e any) { this.AddFirst_O__V(e) }

func (t *LinkedList) Impl_Pop__O(this LinkedList_I) any { return this.RemoveFirst__O() }

func (t *LinkedList) Impl_RemoveFirstOccurrence_O__Z(this LinkedList_I, o any) bool {
	return this.Remove_O__Z(o)
}
func (t *LinkedList) Impl_RemoveLastOccurrence_O__Z(this LinkedList_I, o any) bool {
	if o == nil {
		var x *LinkedList_Node = t.F_last; L1: for {
			if !(x == nil) {
				if x.F_item == nil { this.Unlink_LinkedList_Node__O(x); return true } else { x = x.F_prev; continue L1 } }
//line :280:1
			break L1
		} } else {


			var x_2 *LinkedList_Node = t.F_last; L2: for {
				if !(x_2 == nil) {
					if Equals(o, x_2.F_item) { this.Unlink_LinkedList_Node__O(x_2); return true } else { x_2 = x_2.F_prev; continue L2 } }
//line :284:1
				break L2 } }
//line :278:1
	return false
}










func (t *LinkedList) Impl_ListIterator_I__ListIterator(this LinkedList_I, index int32) ListIterator {
	t.Impl_CheckPositionIndex_I__V(this, index)
	return LinkedList_ListItr_New_LinkedList_I(this, index)
}











func LinkedList_ListItr_New_LinkedList_I(p0 LinkedList_I, p1 int32) *LinkedList_ListItr { t := &LinkedList_ListItr{}; t.Ctor_LinkedList_I(p0, p1); return t }
//line :305:1
func (t *LinkedList_ListItr) Ctor_LinkedList_I(this_0 LinkedList_I, index int32) { A2g_NotNull[LinkedList_I](this_0); t.F_this_0 = this_0; t.F_expectedModCount = this_0.Self_AbstractList().F_modCount
	var tmp1 *LinkedList_Node; if index == this_0.Self_LinkedList().F_size { tmp1 = nil } else { tmp1 = this_0.Node_I__LinkedList_Node(index) }; t.F_next = tmp1
	t.F_nextIndex = index
}
func (t *LinkedList_ListItr) HasNext__Z() bool { return t.F_nextIndex < t.F_this_0.Self_LinkedList().F_size }

func (t *LinkedList_ListItr) Next__O() any {
	t.CheckForComodification__V()
	if t.HasNext__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	t.F_lastReturned = t.F_next
	t.F_next = t.F_next.F_next
	t.F_nextIndex = t.F_nextIndex + 1
	return t.F_lastReturned.F_item
}
func (t *LinkedList_ListItr) HasPrevious__Z() bool { return t.F_nextIndex > 0 }

func (t *LinkedList_ListItr) Previous__O() any {
	t.CheckForComodification__V()
	if t.HasPrevious__Z() { } else { panic(Thrown(NoSuchElementException_New())) }
	var tmp1 *LinkedList_Node; var tmp2 *LinkedList_Node; if t.F_next == nil { tmp2 = t.F_this_0.Self_LinkedList().F_last } else { tmp2 = t.F_next.F_prev }; var tmp3 *LinkedList_Node = tmp2; t.F_next = tmp3; tmp1 = tmp3; t.F_lastReturned = tmp1
	t.F_nextIndex = t.F_nextIndex - 1
	return t.F_lastReturned.F_item
}
func (t *LinkedList_ListItr) NextIndex__I() int32 { return t.F_nextIndex }

func (t *LinkedList_ListItr) PreviousIndex__I() int32 {
	return t.F_nextIndex - 1
}
func (t *LinkedList_ListItr) Remove__V() {
	t.CheckForComodification__V()
	if t.F_lastReturned == nil { panic(Thrown(IllegalStateException_New())) }
	var lastNext *LinkedList_Node = t.F_lastReturned.F_next
	t.F_this_0.Unlink_LinkedList_Node__O(t.F_lastReturned)
	if t.F_next == t.F_lastReturned {
		t.F_next = lastNext } else {
			t.F_nextIndex = t.F_nextIndex - 1 }
	t.F_lastReturned = nil
	t.F_expectedModCount = t.F_expectedModCount + 1
}
func (t *LinkedList_ListItr) Set_O__V(e any) {
	if t.F_lastReturned == nil { panic(Thrown(IllegalStateException_New())) }
	t.CheckForComodification__V()
	t.F_lastReturned.F_item = e
}
func (t *LinkedList_ListItr) Add_O__V(e any) {
	t.CheckForComodification__V()
	t.F_lastReturned = nil
	if t.F_next == nil { t.F_this_0.LinkLast_O__V(e) } else { t.F_this_0.LinkBefore_O_LinkedList_Node__V(e, t.F_next) }
	t.F_nextIndex = t.F_nextIndex + 1
	t.F_expectedModCount = t.F_expectedModCount + 1
}
func (t *LinkedList_ListItr) ForEachRemaining_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = t.F_this_0.Self_AbstractList().F_modCount == t.F_expectedModCount; if tmp2 { tmp2 = t.F_nextIndex < t.F_this_0.Self_LinkedList().F_size }; tmp1 = tmp2; if tmp1 {
	action.Accept_O__V(t.F_next.F_item)
	t.F_lastReturned = t.F_next
	t.F_next = t.F_next.F_next
	t.F_nextIndex = t.F_nextIndex + 1
//line :358:1
	continue L1 }; break L1
}



	t.CheckForComodification__V()
}
func (t *LinkedList_ListItr) CheckForComodification__V() {
	if t.F_this_0.Self_AbstractList().F_modCount == t.F_expectedModCount { } else {
		panic(Thrown(ConcurrentModificationException_New()))
	}
}








func LinkedList_Node_New_LinkedList_Node_O_LinkedList_Node(p0 *LinkedList_Node, p1 any, p2 *LinkedList_Node) *LinkedList_Node { t := &LinkedList_Node{}; t.Ctor_LinkedList_Node_O_LinkedList_Node(p0, p1, p2); return t }
//line :378:1
func (t *LinkedList_Node) Ctor_LinkedList_Node_O_LinkedList_Node(prev *LinkedList_Node, element any, next *LinkedList_Node) {
	t.F_item = element
	t.F_next = next
	t.F_prev = prev
}
func (t *LinkedList) Impl_DescendingIterator__Iterator(this LinkedList_I) Iterator {
	return LinkedList_DescendingIterator_New_LinkedList(this)
}





func (t *LinkedList_DescendingIterator) HasNext__Z() bool { return NN(t.F_itr).HasPrevious__Z() }

func (t *LinkedList_DescendingIterator) Next__O() any { return NN(t.F_itr).Previous__O() }

func (t *LinkedList_DescendingIterator) Remove__V() { NN(t.F_itr).Remove__V() }

func (t *LinkedList) Impl_SuperClone__LinkedList(this LinkedList_I) LinkedList_I {
	var tmp1 LinkedList_I; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = LinkedList_Cast(A2g_ObjectClone(this)); return nil }()
//line :398:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :398:1
			panic(tmp2) } }; return tmp1
}


func (t *LinkedList) Impl_Clone__O(this LinkedList_I) any {
	var clone LinkedList_I = t.Impl_SuperClone__LinkedList(this); var tmp1 *LinkedList_Node; var tmp2 *LinkedList_Node
	clone.Self_LinkedList().F_last = tmp2; tmp1 = tmp2; clone.Self_LinkedList().F_first = tmp1
	clone.Self_LinkedList().F_size = 0
	clone.Self_AbstractList().F_modCount = 0
	var x *LinkedList_Node = t.F_first; L1: for { if !(x == nil) { clone.Add_O__Z(x.F_item); x = x.F_next; continue L1 }; break L1 }
//line :403:1
	return clone
}





func (t *LinkedList) Impl_ToArray__O1(this LinkedList_I) *RefArray {
	var result *RefArray = NewRefArray(Object_class, t.F_size); var i int32 = 0; var x *LinkedList_Node = t.F_first

L1: for {
	if !(x == nil) {
		result.Store(i, x.F_item)
		i = i + 1
		x = x.F_next; continue L1 }
//line :413:1
	break L1 }
//line :411:1
	return result
}







func (t *LinkedList) Impl_ToArray_O1__O1(this LinkedList_I, a *RefArray) *RefArray {
	if int32(len(a.A)) < t.F_size {
		a = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), t.F_size), Object_class.ArrayClass()) }
	var i int32 = 0; var result *RefArray = a; var x *LinkedList_Node = t.F_first

L1: for {
	if !(x == nil) {
		result.Store(i, x.F_item)
		i = i + 1
		x = x.F_next; continue L1 }
//line :425:1
	break L1
}



	if int32(len(a.A)) > t.F_size { a.Store(t.F_size, nil) }
//line :423:1
	return a
}























func (t *LinkedList) Impl_Spliterator__Spliterator(this LinkedList_I) Spliterator {
	return LinkedList_LLSpliterator_New_LinkedList_I_I(this, -1, 0)
}


















func LinkedList_LLSpliterator_New_LinkedList_I_I(p0 LinkedList_I, p1, p2 int32) *LinkedList_LLSpliterator { t := &LinkedList_LLSpliterator{}; t.Ctor_LinkedList_I_I(p0, p1, p2); return t }
//line :469:1
func (t *LinkedList_LLSpliterator) Ctor_LinkedList_I_I(list LinkedList_I, est, expectedModCount int32) {
	t.F_list = list
	t.F_est = est
	t.F_expectedModCount = expectedModCount
}
func (t *LinkedList_LLSpliterator) GetEst__I() int32 {
	var s int32 = 0; var lst LinkedList_I; var tmp1 int32

	s = t.F_est; tmp1 = s; if tmp1 < 0 {
		var tmp2 LinkedList_I; lst = t.F_list; tmp2 = lst; if tmp2 == nil {
			var tmp3 int32; var tmp4 int32 = 0; t.F_est = tmp4; tmp3 = tmp4; s = tmp3 } else {

				t.F_expectedModCount = lst.Self_AbstractList().F_modCount
				t.F_current = lst.Self_LinkedList().F_first
				var tmp5 int32; var tmp6 int32 = lst.Self_LinkedList().F_size; t.F_est = tmp6; tmp5 = tmp6; s = tmp5 } }
//line :475:1
	return s
}









func (t *LinkedList_LLSpliterator) EstimateSize__J() int64 { return int64(t.GetEst__I()) }

func (t *LinkedList_LLSpliterator) TrySplit__Spliterator() Spliterator {
	var p *LinkedList_Node; var s int32 = t.GetEst__I(); var tmp1 bool; var tmp2 bool

	tmp2 = s > 1; if tmp2 { var tmp3 *LinkedList_Node; p = t.F_current; tmp3 = p; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {
		var n int32 = t.F_batch + 1024
		if n > s { n = s }
		if n > 33554432 { n = 33554432 }
		var a *RefArray = NewRefArray(Object_class, n)
		var j int32 = 0
	L1: for {
		a.Store(j, p.F_item)
		j = j + 1
		var tmp4 bool; var tmp5 bool; var tmp6 *LinkedList_Node; p = p.F_next; tmp6 = p; tmp5 = !(tmp6 == nil); if tmp5 { tmp5 = j < n }; tmp4 = tmp5; if tmp4 { continue L1 }
//line :497:1
		break L1
	}


		t.F_current = p
		t.F_batch = j
		t.F_est = s - j
		return Spliterators_Spliterator_O1_I_I_I__Spliterator(a, 0, j, 16) } else {
//line :491:1
			return nil
		}
}












func (t *LinkedList_LLSpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	var p *LinkedList_Node
	var n int32 = 0
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; var tmp3 int32; n = t.GetEst__I(); tmp3 = n; tmp2 = tmp3 > 0; if tmp2 { var tmp4 *LinkedList_Node; p = t.F_current; tmp4 = p; tmp2 = !(tmp4 == nil) }; tmp1 = tmp2; if tmp1 {
		t.F_current = nil
		t.F_est = 0
	L1: for {
		var e any = p.F_item; p = p.F_next; action.Accept_O__V(e)
		var tmp5 bool; var tmp6 bool; tmp6 = !(p == nil); if tmp6 { var tmp7 int32; n = n - 1; tmp7 = n; tmp6 = tmp7 > 0 }; tmp5 = tmp6; if tmp5 { continue L1 }
//line :513:1
		break L1
	}
	}
	if t.F_list.Self_AbstractList().F_modCount == t.F_expectedModCount { } else {
		panic(Thrown(ConcurrentModificationException_New()))
	} }
func (t *LinkedList_LLSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	var p *LinkedList_Node
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var tmp1 bool; var tmp2 bool; tmp2 = t.GetEst__I() > 0; if tmp2 { var tmp3 *LinkedList_Node; p = t.F_current; tmp3 = p; tmp2 = !(tmp3 == nil) }; tmp1 = tmp2; if tmp1 {

		t.F_est = t.F_est - 1
		var e any = p.F_item
		t.F_current = p.F_next
		action.Accept_O__V(e)
		if t.F_list.Self_AbstractList().F_modCount == t.F_expectedModCount { } else {
			panic(Thrown(ConcurrentModificationException_New())) }
//line :525:1
		return true


	} else {
//line :522:1
		return false
	}
}








func (t *LinkedList_LLSpliterator) Characteristics__I() int32 {
	return 16464
}
func (t *LinkedList) Impl_Reversed__LinkedList(this LinkedList_I) LinkedList_I {
	return LinkedList_ReverseOrderLinkedListView_New_LinkedList_List_Deque(this, List_Reversed__List(this), Deque_Reversed__Deque(this))
}











func LinkedList_ReverseOrderLinkedListView_New_LinkedList_List_Deque(p0 LinkedList_I, p1 List, p2 Deque) *LinkedList_ReverseOrderLinkedListView { t := &LinkedList_ReverseOrderLinkedListView{}; t.Ctor_LinkedList_List_Deque(p0, p1, p2); return t }
//line :550:1
func (t *LinkedList_ReverseOrderLinkedListView) Ctor_LinkedList_List_Deque(list LinkedList_I, rlist List, rdeque Deque) { t.LinkedList.Ctor(t)
	t.F_list = list
	t.F_rlist = rlist
	t.F_rdeque = rdeque
}
func (t *LinkedList_ReverseOrderLinkedListView) ToString__String() *String { return t.F_rlist.ToString__String() }

func (t *LinkedList_ReverseOrderLinkedListView) RetainAll_Collection__Z(c Collection) bool {
	return t.F_rlist.RetainAll_Collection__Z(c)
}
func (t *LinkedList_ReverseOrderLinkedListView) RemoveAll_Collection__Z(c Collection) bool {
	return t.F_rlist.RemoveAll_Collection__Z(c)
}
func (t *LinkedList_ReverseOrderLinkedListView) ContainsAll_Collection__Z(c Collection) bool {
	return t.F_rlist.ContainsAll_Collection__Z(c)
}
func (t *LinkedList_ReverseOrderLinkedListView) IsEmpty__Z() bool { return t.F_rlist.IsEmpty__Z() }

func (t *LinkedList_ReverseOrderLinkedListView) ParallelStream__Stream() Stream {
	return t.F_rlist.ParallelStream__Stream()
}
func (t *LinkedList_ReverseOrderLinkedListView) Stream__Stream() Stream { return t.F_rlist.Stream__Stream() }

func (t *LinkedList_ReverseOrderLinkedListView) RemoveIf_Predicate__Z(filter Predicate) bool {
	return t.F_rlist.RemoveIf_Predicate__Z(filter)
}
func (t *LinkedList_ReverseOrderLinkedListView) ToArray_IntFunction__O1(generator IntFunction) *RefArray {
	return t.F_rlist.ToArray_IntFunction__O1(generator)
}
func (t *LinkedList_ReverseOrderLinkedListView) ForEach_Consumer__V(action Consumer) {
	t.F_rlist.ForEach_Consumer__V(action)
}
func (t *LinkedList_ReverseOrderLinkedListView) Iterator__Iterator() Iterator { return t.F_rlist.Iterator__Iterator() }

func (t *LinkedList_ReverseOrderLinkedListView) HashCode__I() int32 { return t.F_rlist.HashCode__I() }

func (t *LinkedList_ReverseOrderLinkedListView) Equals_O__Z(o any) bool { return t.F_rlist.Equals_O__Z(o) }

func (t *LinkedList_ReverseOrderLinkedListView) SubList_I_I__List(fromIndex, toIndex int32) List {
	return t.F_rlist.SubList_I_I__List(fromIndex, toIndex)
}
func (t *LinkedList_ReverseOrderLinkedListView) ListIterator__ListIterator() ListIterator {
	return t.F_rlist.ListIterator__ListIterator()
}
func (t *LinkedList_ReverseOrderLinkedListView) Sort_Comparator__V(c Comparator) {
	t.F_rlist.Sort_Comparator__V(c)
}
func (t *LinkedList_ReverseOrderLinkedListView) ReplaceAll_UnaryOperator__V(operator UnaryOperator) {
	t.F_rlist.ReplaceAll_UnaryOperator__V(operator)
}
func (t *LinkedList_ReverseOrderLinkedListView) Reversed__LinkedList() LinkedList_I { return t.F_list }

func (t *LinkedList_ReverseOrderLinkedListView) Spliterator__Spliterator() Spliterator {
	return t.F_rlist.Spliterator__Spliterator()
}
func (t *LinkedList_ReverseOrderLinkedListView) ToArray_O1__O1(a *RefArray) *RefArray {
	return t.F_rlist.ToArray_O1__O1(a)
}
func (t *LinkedList_ReverseOrderLinkedListView) ToArray__O1() *RefArray { return t.F_rlist.ToArray__O1() }

func (t *LinkedList_ReverseOrderLinkedListView) DescendingIterator__Iterator() Iterator {
	return t.F_rdeque.DescendingIterator__Iterator()
}
func (t *LinkedList_ReverseOrderLinkedListView) ListIterator_I__ListIterator(index int32) ListIterator {
	return t.F_rlist.ListIterator_I__ListIterator(index)
}
func (t *LinkedList_ReverseOrderLinkedListView) RemoveLastOccurrence_O__Z(o any) bool {
	return t.F_rdeque.RemoveLastOccurrence_O__Z(o)
}
func (t *LinkedList_ReverseOrderLinkedListView) RemoveFirstOccurrence_O__Z(o any) bool {
	return t.F_rdeque.RemoveFirstOccurrence_O__Z(o)
}
func (t *LinkedList_ReverseOrderLinkedListView) Pop__O() any { return t.F_rdeque.Pop__O() }

func (t *LinkedList_ReverseOrderLinkedListView) Push_O__V(e any) { t.F_rdeque.Push_O__V(e) }

func (t *LinkedList_ReverseOrderLinkedListView) PollLast__O() any { return t.F_rdeque.PollLast__O() }

func (t *LinkedList_ReverseOrderLinkedListView) PollFirst__O() any { return t.F_rdeque.PollFirst__O() }

func (t *LinkedList_ReverseOrderLinkedListView) PeekLast__O() any { return t.F_rdeque.PeekLast__O() }

func (t *LinkedList_ReverseOrderLinkedListView) PeekFirst__O() any { return t.F_rdeque.PeekFirst__O() }

func (t *LinkedList_ReverseOrderLinkedListView) OfferLast_O__Z(e any) bool { return t.F_rdeque.OfferLast_O__Z(e) }

func (t *LinkedList_ReverseOrderLinkedListView) OfferFirst_O__Z(e any) bool { return t.F_rdeque.OfferFirst_O__Z(e) }

func (t *LinkedList_ReverseOrderLinkedListView) Offer_O__Z(e any) bool { return t.F_rdeque.Offer_O__Z(e) }

func (t *LinkedList_ReverseOrderLinkedListView) Remove__O() any { return t.F_rdeque.Remove__O() }

func (t *LinkedList_ReverseOrderLinkedListView) Poll__O() any { return t.F_rdeque.Poll__O() }

func (t *LinkedList_ReverseOrderLinkedListView) Element__O() any { return t.F_rdeque.Element__O() }

func (t *LinkedList_ReverseOrderLinkedListView) Peek__O() any { return t.F_rdeque.Peek__O() }

func (t *LinkedList_ReverseOrderLinkedListView) LastIndexOf_O__I(o any) int32 { return t.F_rlist.LastIndexOf_O__I(o) }

func (t *LinkedList_ReverseOrderLinkedListView) IndexOf_O__I(o any) int32 { return t.F_rlist.IndexOf_O__I(o) }

func (t *LinkedList_ReverseOrderLinkedListView) Remove_I__O(index int32) any { return t.F_rlist.Remove_I__O(index) }

func (t *LinkedList_ReverseOrderLinkedListView) Add_I_O__V(index int32, element any) {
	t.F_rlist.Add_I_O__V(index, element)
}
func (t *LinkedList_ReverseOrderLinkedListView) Set_I_O__O(index int32, element any) any {
	return t.F_rlist.Set_I_O__O(index, element)
}
func (t *LinkedList_ReverseOrderLinkedListView) Get_I__O(index int32) any { return t.F_rlist.Get_I__O(index) }

func (t *LinkedList_ReverseOrderLinkedListView) Clear__V() { t.F_rlist.Clear__V() }

func (t *LinkedList_ReverseOrderLinkedListView) AddAll_I_Collection__Z(index int32, c Collection) bool {
	return t.F_rlist.AddAll_I_Collection__Z(index, c)
}
func (t *LinkedList_ReverseOrderLinkedListView) AddAll_Collection__Z(c Collection) bool {
	return t.F_rlist.AddAll_Collection__Z(c)
}
func (t *LinkedList_ReverseOrderLinkedListView) Remove_O__Z(o any) bool { return t.F_rlist.Remove_O__Z(o) }

func (t *LinkedList_ReverseOrderLinkedListView) Add_O__Z(e any) bool { return t.F_rlist.Add_O__Z(e) }

func (t *LinkedList_ReverseOrderLinkedListView) Size__I() int32 { return t.F_rlist.Size__I() }

func (t *LinkedList_ReverseOrderLinkedListView) Contains_O__Z(o any) bool { return t.F_rlist.Contains_O__Z(o) }

func (t *LinkedList_ReverseOrderLinkedListView) AddLast_O__V(e any) { t.F_rdeque.AddLast_O__V(e) }

func (t *LinkedList_ReverseOrderLinkedListView) AddFirst_O__V(e any) { t.F_rdeque.AddFirst_O__V(e) }

func (t *LinkedList_ReverseOrderLinkedListView) RemoveLast__O() any { return t.F_rdeque.RemoveLast__O() }

func (t *LinkedList_ReverseOrderLinkedListView) RemoveFirst__O() any { return t.F_rdeque.RemoveFirst__O() }

func (t *LinkedList_ReverseOrderLinkedListView) GetLast__O() any { return t.F_rdeque.GetLast__O() }

func (t *LinkedList_ReverseOrderLinkedListView) GetFirst__O() any { return t.F_rdeque.GetFirst__O() }



type LinkedList struct{ AbstractSequentialList; F_size int32; F_first, F_last *LinkedList_Node }

type LinkedList_I interface{ AbstractSequentialList_I; List; Deque; Cloneable; Serializable; Collection; SequencedCollection; Queue; Iterable; Self_LinkedList() *LinkedList; LinkLast_O__V(p0 any); LinkBefore_O_LinkedList_Node__V(p0 any, p1 *LinkedList_Node); Unlink_LinkedList_Node__O(p0 *LinkedList_Node) any; GetFirst__O() any; GetLast__O() any; RemoveFirst__O() any; RemoveLast__O() any; AddFirst_O__V(p0 any); AddLast_O__V(p0 any); Contains_O__Z(p0 any) bool; Size__I() int32; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; AddAll_Collection__Z(p0 Collection) bool; AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; Clear__V(); Get_I__O(p0 int32) any; Set_I_O__O(p0 int32, p1 any) any; Add_I_O__V(p0 int32, p1 any); Remove_I__O(p0 int32) any; Node_I__LinkedList_Node(p0 int32) *LinkedList_Node; IndexOf_O__I(p0 any) int32; LastIndexOf_O__I(p0 any) int32; Peek__O() any; Element__O() any; Poll__O() any; Remove__O() any; Offer_O__Z(p0 any) bool; OfferFirst_O__Z(p0 any) bool; OfferLast_O__Z(p0 any) bool; PeekFirst__O() any; PeekLast__O() any; PollFirst__O() any; PollLast__O() any; Push_O__V(p0 any); Pop__O() any; RemoveFirstOccurrence_O__Z(p0 any) bool; RemoveLastOccurrence_O__Z(p0 any) bool; ListIterator_I__ListIterator(p0 int32) ListIterator; DescendingIterator__Iterator() Iterator; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; Spliterator__Spliterator() Spliterator; Reversed__LinkedList() LinkedList_I; Reversed__Deque() Deque; Reversed__SequencedCollection() SequencedCollection; Reversed__List() List }

func (t *LinkedList) Self_LinkedList() *LinkedList { return t }

func (t *LinkedList) Is_Deque() {}

func (t *LinkedList) Is_Cloneable() {}

func (t *LinkedList) Is_Serializable() {}

func (t *LinkedList) Is_Queue() {}

const LinkedList_serialVersionUID int64 = 876323262645176354

func (t *LinkedList) Impl_Reversed__Deque(this LinkedList_I) Deque { return this.Reversed__LinkedList() }

func (t *LinkedList) Impl_Reversed__SequencedCollection(this LinkedList_I) SequencedCollection { return this.Reversed__LinkedList() }

func (t *LinkedList) Impl_Reversed__List(this LinkedList_I) List { return this.Reversed__LinkedList() }

func (t *LinkedList) LinkLast_O__V(p0 any) { t.Impl_LinkLast_O__V(t, p0) }

func (t *LinkedList) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *LinkedList) LinkBefore_O_LinkedList_Node__V(p0 any, p1 *LinkedList_Node) { t.Impl_LinkBefore_O_LinkedList_Node__V(t, p0, p1) }

func (t *LinkedList) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *LinkedList) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *LinkedList) PeekLast__O() any { return t.Impl_PeekLast__O(t) }

func (t *LinkedList) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *LinkedList) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *LinkedList) Clear__V() { t.Impl_Clear__V(t) }

func (t *LinkedList) Peek__O() any { return t.Impl_Peek__O(t) }

func (t *LinkedList) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *LinkedList) GetFirst__O() any { return t.Impl_GetFirst__O(t) }

func (t *LinkedList) Reversed__SequencedCollection() SequencedCollection { return t.Impl_Reversed__SequencedCollection(t) }

func (t *LinkedList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *LinkedList) RemoveLastOccurrence_O__Z(p0 any) bool { return t.Impl_RemoveLastOccurrence_O__Z(t, p0) }

func (t *LinkedList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *LinkedList) Sort_Comparator__V(p0 Comparator) { List_Sort_Comparator__V(t, p0) }

func (t *LinkedList) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *LinkedList) OfferLast_O__Z(p0 any) bool { return t.Impl_OfferLast_O__Z(t, p0) }

func (t *LinkedList) Poll__O() any { return t.Impl_Poll__O(t) }

func (t *LinkedList) Element__O() any { return t.Impl_Element__O(t) }

func (t *LinkedList) Unlink_LinkedList_Node__O(p0 *LinkedList_Node) any { return t.Impl_Unlink_LinkedList_Node__O(t, p0) }

func (t *LinkedList) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *LinkedList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *LinkedList) AddFirst_O__V(p0 any) { t.Impl_AddFirst_O__V(t, p0) }

func (t *LinkedList) Reversed__List() List { return t.Impl_Reversed__List(t) }

func (t *LinkedList) PollLast__O() any { return t.Impl_PollLast__O(t) }

func (t *LinkedList) Node_I__LinkedList_Node(p0 int32) *LinkedList_Node { return t.Impl_Node_I__LinkedList_Node(t, p0) }

func (t *LinkedList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { List_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *LinkedList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *LinkedList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *LinkedList) PollFirst__O() any { return t.Impl_PollFirst__O(t) }

func (t *LinkedList) Push_O__V(p0 any) { t.Impl_Push_O__V(t, p0) }

func (t *LinkedList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *LinkedList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *LinkedList) Reversed__Deque() Deque { return t.Impl_Reversed__Deque(t) }

func (t *LinkedList) Pop__O() any { return t.Impl_Pop__O(t) }

func (t *LinkedList) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *LinkedList) Offer_O__Z(p0 any) bool { return t.Impl_Offer_O__Z(t, p0) }

func (t *LinkedList) OfferFirst_O__Z(p0 any) bool { return t.Impl_OfferFirst_O__Z(t, p0) }

func (t *LinkedList) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *LinkedList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *LinkedList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *LinkedList) GetLast__O() any { return t.Impl_GetLast__O(t) }

func (t *LinkedList) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *LinkedList) PeekFirst__O() any { return t.Impl_PeekFirst__O(t) }

func (t *LinkedList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *LinkedList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *LinkedList) Remove__O() any { return t.Impl_Remove__O(t) }

func (t *LinkedList) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *LinkedList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *LinkedList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *LinkedList) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *LinkedList) Reversed__LinkedList() LinkedList_I { return t.Impl_Reversed__LinkedList(t) }

func (t *LinkedList) AddLast_O__V(p0 any) { t.Impl_AddLast_O__V(t, p0) }

func (t *LinkedList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *LinkedList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *LinkedList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *LinkedList) RemoveFirstOccurrence_O__Z(p0 any) bool { return t.Impl_RemoveFirstOccurrence_O__Z(t, p0) }

func (t *LinkedList) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *LinkedList) DescendingIterator__Iterator() Iterator { return t.Impl_DescendingIterator__Iterator(t) }

func (t *LinkedList) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *LinkedList) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *LinkedList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *LinkedList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *LinkedList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *LinkedList) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedList) GetClass__Class() *Class { return LinkedList_class }

func (t *LinkedList) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func LinkedList_InstanceOf(x any) bool { _, ok := x.(LinkedList_I); return ok }

func LinkedList_Cast(x any) LinkedList_I { if x == nil { return nil }; v, ok := x.(LinkedList_I); if !ok { panic(ClassCast(x, LinkedList_class)) }; return v }



type LinkedList_DescendingIterator struct{ Object; F_itr *LinkedList_ListItr; F_this_0 LinkedList_I }

func (t *LinkedList_DescendingIterator) Is_Iterator() {}

func LinkedList_DescendingIterator_New_LinkedList(p0 LinkedList_I) *LinkedList_DescendingIterator { t := &LinkedList_DescendingIterator{}; t.Ctor_LinkedList(p0); return t }

func (t *LinkedList_DescendingIterator) Ctor_LinkedList(this_0 LinkedList_I) { A2g_NotNull[LinkedList_I](this_0); t.F_this_0 = this_0; t.F_itr = LinkedList_ListItr_New_LinkedList_I(this_0, this_0.Size__I()) }

func (t *LinkedList_DescendingIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *LinkedList_DescendingIterator) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedList_DescendingIterator) GetClass__Class() *Class { return LinkedList_DescendingIterator_class }

func (t *LinkedList_DescendingIterator) ToString__String() *String { return Object_toString(t) }

func (t *LinkedList_DescendingIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedList_DescendingIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedList_DescendingIterator_InstanceOf(x any) bool { _, ok := x.(*LinkedList_DescendingIterator); return ok }

func LinkedList_DescendingIterator_Cast(x any) *LinkedList_DescendingIterator { if x == nil { return nil }; v, ok := x.(*LinkedList_DescendingIterator); if !ok { panic(ClassCast(x, LinkedList_DescendingIterator_class)) }; return v }



type LinkedList_LLSpliterator struct{ Object; F_list LinkedList_I; F_current *LinkedList_Node; F_est, F_expectedModCount, F_batch int32 }

func (t *LinkedList_LLSpliterator) Is_Spliterator() {}

const LinkedList_LLSpliterator_BATCH_UNIT int32 = 1024

const LinkedList_LLSpliterator_MAX_BATCH int32 = 33554432

func (t *LinkedList_LLSpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *LinkedList_LLSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *LinkedList_LLSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *LinkedList_LLSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedList_LLSpliterator) GetClass__Class() *Class { return LinkedList_LLSpliterator_class }

func (t *LinkedList_LLSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *LinkedList_LLSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedList_LLSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedList_LLSpliterator_InstanceOf(x any) bool { _, ok := x.(*LinkedList_LLSpliterator); return ok }

func LinkedList_LLSpliterator_Cast(x any) *LinkedList_LLSpliterator { if x == nil { return nil }; v, ok := x.(*LinkedList_LLSpliterator); if !ok { panic(ClassCast(x, LinkedList_LLSpliterator_class)) }; return v }



type LinkedList_ListItr struct{ Object; F_lastReturned, F_next *LinkedList_Node; F_nextIndex, F_expectedModCount int32; F_this_0 LinkedList_I }

func (t *LinkedList_ListItr) Is_ListIterator() {}

func (t *LinkedList_ListItr) Is_Iterator() {}

func (t *LinkedList_ListItr) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedList_ListItr) GetClass__Class() *Class { return LinkedList_ListItr_class }

func (t *LinkedList_ListItr) ToString__String() *String { return Object_toString(t) }

func (t *LinkedList_ListItr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedList_ListItr) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedList_ListItr_InstanceOf(x any) bool { _, ok := x.(*LinkedList_ListItr); return ok }

func LinkedList_ListItr_Cast(x any) *LinkedList_ListItr { if x == nil { return nil }; v, ok := x.(*LinkedList_ListItr); if !ok { panic(ClassCast(x, LinkedList_ListItr_class)) }; return v }



type LinkedList_Node struct{ Object; F_item any; F_next, F_prev *LinkedList_Node }

func (t *LinkedList_Node) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedList_Node) GetClass__Class() *Class { return LinkedList_Node_class }

func (t *LinkedList_Node) ToString__String() *String { return Object_toString(t) }

func (t *LinkedList_Node) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LinkedList_Node) CloneShallow() any { panic(CloneNotSupported(t)) }

func LinkedList_Node_InstanceOf(x any) bool { _, ok := x.(*LinkedList_Node); return ok }

func LinkedList_Node_Cast(x any) *LinkedList_Node { if x == nil { return nil }; v, ok := x.(*LinkedList_Node); if !ok { panic(ClassCast(x, LinkedList_Node_class)) }; return v }



type LinkedList_ReverseOrderLinkedListView struct{ LinkedList; F_list LinkedList_I; F_rlist List; F_rdeque Deque }

func (t *LinkedList_ReverseOrderLinkedListView) Reversed__Deque() Deque { return t.Reversed__LinkedList() }

func (t *LinkedList_ReverseOrderLinkedListView) Reversed__SequencedCollection() SequencedCollection { return t.Reversed__LinkedList() }

func (t *LinkedList_ReverseOrderLinkedListView) Reversed__List() List { return t.Reversed__LinkedList() }

func (t *LinkedList_ReverseOrderLinkedListView) LinkLast_O__V(p0 any) { t.Impl_LinkLast_O__V(t, p0) }

func (t *LinkedList_ReverseOrderLinkedListView) LinkBefore_O_LinkedList_Node__V(p0 any, p1 *LinkedList_Node) { t.Impl_LinkBefore_O_LinkedList_Node__V(t, p0, p1) }

func (t *LinkedList_ReverseOrderLinkedListView) Unlink_LinkedList_Node__O(p0 *LinkedList_Node) any { return t.Impl_Unlink_LinkedList_Node__O(t, p0) }

func (t *LinkedList_ReverseOrderLinkedListView) RemoveRange_I_I__V(p0, p1 int32) { t.Impl_RemoveRange_I_I__V(t, p0, p1) }

func (t *LinkedList_ReverseOrderLinkedListView) Node_I__LinkedList_Node(p0 int32) *LinkedList_Node { return t.Impl_Node_I__LinkedList_Node(t, p0) }

func (t *LinkedList_ReverseOrderLinkedListView) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *LinkedList_ReverseOrderLinkedListView) Ref() any { if t == nil { return nil }; return t }

func (t *LinkedList_ReverseOrderLinkedListView) GetClass__Class() *Class { return LinkedList_ReverseOrderLinkedListView_class }

func (t *LinkedList_ReverseOrderLinkedListView) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func LinkedList_ReverseOrderLinkedListView_InstanceOf(x any) bool { _, ok := x.(*LinkedList_ReverseOrderLinkedListView); return ok }

func LinkedList_ReverseOrderLinkedListView_Cast(x any) *LinkedList_ReverseOrderLinkedListView { if x == nil { return nil }; v, ok := x.(*LinkedList_ReverseOrderLinkedListView); if !ok { panic(ClassCast(x, LinkedList_ReverseOrderLinkedListView_class)) }; return v }
