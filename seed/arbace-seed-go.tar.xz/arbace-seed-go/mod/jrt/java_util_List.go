//line java_util_List.ae:1
package jrt





































func List_ReplaceAll_UnaryOperator__V(this List, operator UnaryOperator) {
	Objects_RequireNonNull_O__O(operator)
	var li ListIterator = this.ListIterator__ListIterator()
L1: for { if li.HasNext__Z() { li.Set_O__V(operator.Apply_O__O(li.Next__O())); continue L1 }; break L1
} }
func List_Sort_Comparator__V(this List, c Comparator) {
	var a *RefArray = this.ToArray__O1()
	Arrays_Sort_O1_Comparator__V(a, c)
	var i ListIterator = this.ListIterator__ListIterator(); var arr_101941 *RefArray = a; var len_101942 int32 = int32(len(arr_101941.A)); var i_101943 int32 = 0; for ; i_101943 < len_101942; i_101943++ { var e any = arr_101941.A[i_101943]; i.Next__O(); i.Set_O__V(e)
	}
}























func List_Spliterator__Spliterator(this List) Spliterator {
	if RandomAccess_InstanceOf(this) {
		return AbstractList_RandomAccessSpliterator_New_List(this) } else {
			return Spliterators_Spliterator_Collection_I__Spliterator(this, 16)
		} }
func List_AddFirst_O__V(this List, e any) { this.Add_I_O__V(0, e) }

func List_AddLast_O__V(this List, e any) { this.Add_O__Z(e) }

func List_GetFirst__O(this List) any {
	if this.IsEmpty__Z() { panic(Thrown(NoSuchElementException_New())) } else { return this.Get_I__O(0)
	} }
func List_GetLast__O(this List) any {
	if this.IsEmpty__Z() {
		panic(Thrown(NoSuchElementException_New())) } else {
			return this.Get_I__O(this.Size__I() - 1)
		} }
func List_RemoveFirst__O(this List) any {
	if this.IsEmpty__Z() { panic(Thrown(NoSuchElementException_New())) } else { return this.Remove_I__O(0)
	} }
func List_RemoveLast__O(this List) any {
	if this.IsEmpty__Z() {
		panic(Thrown(NoSuchElementException_New())) } else {
			return this.Remove_I__O(this.Size__I() - 1)
		} }
func List_Reversed__List(this List) List {
	return ReverseOrderListView_Of_List_Z__List(this, true)
}
func List_Of__List() List { ImmutableCollections_Init(); return Up_ImmutableCollections_ListN_List(ImmutableCollections_EMPTY_LIST) }


func List_Of_O__List(e1 any) List {
	return ImmutableCollections_List12_New_O(e1)
}
func List_Of_O_O__List(e1, e2 any) List {
	return ImmutableCollections_List12_New_O_O(e1, e2)
}
func List_Of_O_O_O__List(e1, e2, e3 any) List {
	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3))
}
func List_Of_O_O_O_O__List(e1, e2, e3, e4 any) List {
	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3, e4))
}
func List_Of_O_O_O_O_O__List(e1, e2, e3, e4, e5 any) List {
	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3, e4, e5))
}
func List_Of_O_O_O_O_O_O__List(e1, e2, e3, e4, e5, e6 any) List {
	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6))
}
func List_Of_O_O_O_O_O_O_O__List(e1, e2, e3, e4, e5, e6, e7 any) List {
	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7))
}
func List_Of_O_O_O_O_O_O_O_O__List(e1, e2, e3, e4, e5, e6, e7, e8 any) List {

	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7, e8))
}
func List_Of_O_O_O_O_O_O_O_O_O__List(e1, e2, e3, e4, e5, e6, e7, e8, e9 any) List {

	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7, e8, e9))
}
func List_Of_O_O_O_O_O_O_O_O_O_O__List(e1, e2, e3, e4, e5, e6, e7, e8, e9, e10 any) List {

	return ImmutableCollections_ListFromTrustedArray_O1__List(RefArrayOf(Object_class, e1, e2, e3, e4, e5, e6, e7, e8, e9, e10))
}
func List_Of_O1__List(elements *RefArray) List {
	switch int32(len(elements.A)) { case 0:
		var list *ImmutableCollections_ListN; ImmutableCollections_Init(); list = ImmutableCollections_EMPTY_LIST; return Up_ImmutableCollections_ListN_List(list); case 1:
		return ImmutableCollections_List12_New_O(elements.A[0]); case 2:
		var tmp1 any = elements.A[0]; return ImmutableCollections_List12_New_O_O(tmp1, elements.A[1]); default:
		return ImmutableCollections_ListFromArray_O1__List(elements)}; panic("a2g: unreachable")
}
func List_CopyOf_Collection__List(coll Collection) List {
	return ImmutableCollections_ListCopy_Collection__List(coll)
}
func List_OfLazy_I_IntFunction__List(size int32, computingFunction IntFunction) List {

	Utils_CheckNonNegativeArgument_J_String__V(int64(size), Lit_2738)
	Objects_RequireNonNull_O__O(computingFunction)
	return A2g_Missing[List]("class java.util.LazyCollections is not in the closed world")
}


type List interface{ Object_I; SequencedCollection; Collection; Iterable; Is_List(); Size__I() int32; IsEmpty__Z() bool; Contains_O__Z(p0 any) bool; Iterator__Iterator() Iterator; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; Add_O__Z(p0 any) bool; Remove_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; AddAll_Collection__Z(p0 Collection) bool; AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; RemoveAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; ReplaceAll_UnaryOperator__V(p0 UnaryOperator); Sort_Comparator__V(p0 Comparator); Clear__V(); Get_I__O(p0 int32) any; Set_I_O__O(p0 int32, p1 any) any; Add_I_O__V(p0 int32, p1 any); Remove_I__O(p0 int32) any; IndexOf_O__I(p0 any) int32; LastIndexOf_O__I(p0 any) int32; ListIterator__ListIterator() ListIterator; ListIterator_I__ListIterator(p0 int32) ListIterator; SubList_I_I__List(p0, p1 int32) List; Spliterator__Spliterator() Spliterator; AddFirst_O__V(p0 any); AddLast_O__V(p0 any); GetFirst__O() any; GetLast__O() any; RemoveFirst__O() any; RemoveLast__O() any; Reversed__List() List; Reversed__SequencedCollection() SequencedCollection }

func List_Reversed__SequencedCollection(this List) SequencedCollection { return this.Reversed__List() }

func List_InstanceOf(x any) bool { _, ok := x.(List); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(List_class) } }; return ok }

func List_Cast(x any) List { if x == nil { return nil }; v, ok := x.(List); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(List_class) } }; if !ok { panic(ClassCast(x, List_class)) }; return v }
