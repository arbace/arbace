//line java_time_temporal_UnsupportedTemporalTypeException.ae:1
package jrt










func UnsupportedTemporalTypeException_New_String(p0 *String) *UnsupportedTemporalTypeException { t := &UnsupportedTemporalTypeException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *UnsupportedTemporalTypeException) Ctor_String(message *String) { t.DateTimeException.Ctor_String(t, message) }

func UnsupportedTemporalTypeException_New_String_Throwable(p0 *String, p1 Throwable_I) *UnsupportedTemporalTypeException { t := &UnsupportedTemporalTypeException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *UnsupportedTemporalTypeException) Ctor_String_Throwable(message *String, cause Throwable_I) { t.DateTimeException.Ctor_String_Throwable(t, message, cause) }







type UnsupportedTemporalTypeException struct{ DateTimeException }

const UnsupportedTemporalTypeException_serialVersionUID int64 = -6158898438688206006

func (t *UnsupportedTemporalTypeException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *UnsupportedTemporalTypeException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *UnsupportedTemporalTypeException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *UnsupportedTemporalTypeException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *UnsupportedTemporalTypeException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *UnsupportedTemporalTypeException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *UnsupportedTemporalTypeException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *UnsupportedTemporalTypeException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *UnsupportedTemporalTypeException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *UnsupportedTemporalTypeException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *UnsupportedTemporalTypeException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *UnsupportedTemporalTypeException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *UnsupportedTemporalTypeException) Ref() any { if t == nil { return nil }; return t }

func (t *UnsupportedTemporalTypeException) GetClass__Class() *Class { return UnsupportedTemporalTypeException_class }

func (t *UnsupportedTemporalTypeException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UnsupportedTemporalTypeException) CloneShallow() any { panic(CloneNotSupported(t)) }

func UnsupportedTemporalTypeException_InstanceOf(x any) bool { _, ok := x.(*UnsupportedTemporalTypeException); return ok }

func UnsupportedTemporalTypeException_Cast(x any) *UnsupportedTemporalTypeException { if x == nil { return nil }; v, ok := x.(*UnsupportedTemporalTypeException); if !ok { panic(ClassCast(x, UnsupportedTemporalTypeException_class)) }; return v }
