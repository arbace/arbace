//line java_util_LocaleISOData.ae:1
package jrt









func (t *LocaleISOData_1) Get__String1() *RefArray {
	return LocaleISOData_GetISO2Table_String__String1(Lit_2787)
}



func (t *LocaleISOData_2) Get__String1() *RefArray {
	return LocaleISOData_GetISO2Table_String__String1(Lit_2788)
}



func (t *LocaleISOData_3) Get__Set() Set {
	return LocaleISOData_ComputeISO3166_1Alpha3Countries__Set()
}



func (t *LocaleISOData_4) Get__Set() Set { var tmp1 *RefArray; LocaleISOData_Init(); tmp1 = LocaleISOData_ISO3166_3; return Set_Of_O1__Set(tmp1) }













func LocaleISOData_GetISO3LangCode_String__String(language *String) *String { LocaleISOData_Init()
	return LocaleISOData_GetISO3Code_String_String__String(language, Lit_2787)
}
func LocaleISOData_GetISO3CtryCode_String__String(country *String) *String { LocaleISOData_Init()
	return LocaleISOData_GetISO3Code_String_String__String(country, Lit_2788)
}
func LocaleISOData_GetISO3Code_String_String__String(iso2Code, table *String) *String { LocaleISOData_Init()
	var codeLength int32 = NN(iso2Code).Length__I()
	if codeLength == 0 { return Lit_69 } else {

		var tableLength int32 = NN(table).Length__I()
		var index int32 = tableLength
		if codeLength == 2 {
			var c1 uint16 = NN(iso2Code).CharAt_I__C(0); var c2 uint16 = NN(iso2Code).CharAt_I__C(1)

			index = 0
		L1: for { if index < tableLength {
			var tmp1 bool; var tmp2 bool; tmp2 = int32(NN(table).CharAt_I__C(index)) == int32(c1); if tmp2 {
				tmp2 = int32(NN(table).CharAt_I__C(index+1)) == int32(c2) }
//line :60:1
			tmp1 = tmp2; if tmp1 {

				break L1 }
			index = index + 5
//line :59:1
			continue L1 }; break L1
		}
		}


		if index < tableLength {
			return NN(table).Substring_I_I__String(index+2, index+5) } else {
//line :64:1
				return nil
			}
	} }
func LocaleISOData_GetISO2Table_String__String1(table *String) *RefArray { LocaleISOData_Init()
	var len_ int32 = NN(table).Length__I() / 5; var isoTable *RefArray = NewRefArray(String_class, len_)
	var i int32 = 0; var j int32 = 0
L1: for {

	if i < len_ {
		isoTable.Store(i, NN(table).Substring_I_I__String(j, j+2).Ref())
		i, j = i+1, j+5; continue L1 }
//line :70:1
	break L1 }
//line :68:1
	return isoTable
}







func LocaleISOData_ComputeISO3166_1Alpha3Countries__Set() Set { LocaleISOData_Init()
	var tableLength int32 = Lit_2788.Length__I(); var isoTable *RefArray = NewRefArray(String_class, tableLength/5)
	var i int32 = 0; var index int32 = 0
L1: for {

	if index < tableLength {
		isoTable.Store(i, Lit_2788.Substring_I_I__String(index+2, index+5).Ref())



		i, index = i+1, index+5; continue L1 }
//line :80:1
	break L1
}






	return Set_Of_O1__Set(isoTable)
}
func LocaleISOData_New() *LocaleISOData { LocaleISOData_Init(); t := &LocaleISOData{}; t.Ctor(); return t }
//line :90:1
func (t *LocaleISOData) Ctor() { panic(A2g_NotTranslated("java.util.LocaleISOData.<init>()V")) }





type LocaleISOData struct{ Object }

var LocaleISOData_ISO_639 LazyConstant

var LocaleISOData_ISO_3166_1_ALPHA2 LazyConstant

var LocaleISOData_ISO_3166_1_ALPHA3 LazyConstant

var LocaleISOData_ISO_3166_3 LazyConstant

var LocaleISOData_isoLanguageTable *String = Lit_2787

var LocaleISOData_isoCountryTable *String = Lit_2788

var LocaleISOData_ISO3166_3 *RefArray

var LocaleISOData_init ClassInit

func LocaleISOData_Init() { if !LocaleISOData_init.Done() { LocaleISOData_init.Run(LocaleISOData_clinit) } }

func LocaleISOData_clinit() { LocaleISOData_ISO_639 = LazyConstant_Of_Supplier__LazyConstant(LocaleISOData_1_New()); LocaleISOData_ISO_3166_1_ALPHA2 = LazyConstant_Of_Supplier__LazyConstant(LocaleISOData_2_New()); LocaleISOData_ISO_3166_1_ALPHA3 = LazyConstant_Of_Supplier__LazyConstant(LocaleISOData_3_New()); LocaleISOData_ISO_3166_3 = LazyConstant_Of_Supplier__LazyConstant(LocaleISOData_4_New()); LocaleISOData_ISO3166_3 = ConstRefArray("[0,31,s4:AIDJs4:ANHHs4:BQAQs4:BUMMs4:BYAAs4:CSHHs4:CSXXs4:CTKIs4:DDDEs4:DYBJs4:FQHHs4:FXFRs4:GEHHs4:HVBFs4:JTUMs4:MIUMs4:NHVUs4:NQAQs4:NTHHs4:PCHHs4:PUUMs4:PZPAs4:RHZWs4:SKINs4:SUHHs4:TPTLs4:VDVNs4:WKUMs4:YDYEs4:YUCSs4:ZRCD", []*Class{String_class}) }

func (t *LocaleISOData) Ref() any { if t == nil { return nil }; return t }

func (t *LocaleISOData) GetClass__Class() *Class { return LocaleISOData_class }

func (t *LocaleISOData) ToString__String() *String { return Object_toString(t) }

func (t *LocaleISOData) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocaleISOData) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocaleISOData_InstanceOf(x any) bool { _, ok := x.(*LocaleISOData); return ok }

func LocaleISOData_Cast(x any) *LocaleISOData { if x == nil { return nil }; v, ok := x.(*LocaleISOData); if !ok { panic(ClassCast(x, LocaleISOData_class)) }; return v }



type LocaleISOData_1 struct{ Object }

func (t *LocaleISOData_1) Is_Supplier() {}

func LocaleISOData_1_New() *LocaleISOData_1 { t := &LocaleISOData_1{}; t.Ctor(); return t }

func (t *LocaleISOData_1) Ctor() {}

func (t *LocaleISOData_1) Get__O() any { return t.Get__String1().Ref() }

func (t *LocaleISOData_1) Ref() any { if t == nil { return nil }; return t }

func (t *LocaleISOData_1) GetClass__Class() *Class { return LocaleISOData_1_class }

func (t *LocaleISOData_1) ToString__String() *String { return Object_toString(t) }

func (t *LocaleISOData_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocaleISOData_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocaleISOData_1_InstanceOf(x any) bool { _, ok := x.(*LocaleISOData_1); return ok }

func LocaleISOData_1_Cast(x any) *LocaleISOData_1 { if x == nil { return nil }; v, ok := x.(*LocaleISOData_1); if !ok { panic(ClassCast(x, LocaleISOData_1_class)) }; return v }



type LocaleISOData_2 struct{ Object }

func (t *LocaleISOData_2) Is_Supplier() {}

func LocaleISOData_2_New() *LocaleISOData_2 { t := &LocaleISOData_2{}; t.Ctor(); return t }

func (t *LocaleISOData_2) Ctor() {}

func (t *LocaleISOData_2) Get__O() any { return t.Get__String1().Ref() }

func (t *LocaleISOData_2) Ref() any { if t == nil { return nil }; return t }

func (t *LocaleISOData_2) GetClass__Class() *Class { return LocaleISOData_2_class }

func (t *LocaleISOData_2) ToString__String() *String { return Object_toString(t) }

func (t *LocaleISOData_2) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocaleISOData_2) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocaleISOData_2_InstanceOf(x any) bool { _, ok := x.(*LocaleISOData_2); return ok }

func LocaleISOData_2_Cast(x any) *LocaleISOData_2 { if x == nil { return nil }; v, ok := x.(*LocaleISOData_2); if !ok { panic(ClassCast(x, LocaleISOData_2_class)) }; return v }



type LocaleISOData_3 struct{ Object }

func (t *LocaleISOData_3) Is_Supplier() {}

func LocaleISOData_3_New() *LocaleISOData_3 { t := &LocaleISOData_3{}; t.Ctor(); return t }

func (t *LocaleISOData_3) Ctor() {}

func (t *LocaleISOData_3) Get__O() any { return t.Get__Set() }

func (t *LocaleISOData_3) Ref() any { if t == nil { return nil }; return t }

func (t *LocaleISOData_3) GetClass__Class() *Class { return LocaleISOData_3_class }

func (t *LocaleISOData_3) ToString__String() *String { return Object_toString(t) }

func (t *LocaleISOData_3) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocaleISOData_3) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocaleISOData_3_InstanceOf(x any) bool { _, ok := x.(*LocaleISOData_3); return ok }

func LocaleISOData_3_Cast(x any) *LocaleISOData_3 { if x == nil { return nil }; v, ok := x.(*LocaleISOData_3); if !ok { panic(ClassCast(x, LocaleISOData_3_class)) }; return v }



type LocaleISOData_4 struct{ Object }

func (t *LocaleISOData_4) Is_Supplier() {}

func LocaleISOData_4_New() *LocaleISOData_4 { t := &LocaleISOData_4{}; t.Ctor(); return t }

func (t *LocaleISOData_4) Ctor() {}

func (t *LocaleISOData_4) Get__O() any { return t.Get__Set() }

func (t *LocaleISOData_4) Ref() any { if t == nil { return nil }; return t }

func (t *LocaleISOData_4) GetClass__Class() *Class { return LocaleISOData_4_class }

func (t *LocaleISOData_4) ToString__String() *String { return Object_toString(t) }

func (t *LocaleISOData_4) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocaleISOData_4) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocaleISOData_4_InstanceOf(x any) bool { _, ok := x.(*LocaleISOData_4); return ok }

func LocaleISOData_4_Cast(x any) *LocaleISOData_4 { if x == nil { return nil }; v, ok := x.(*LocaleISOData_4); if !ok { panic(ClassCast(x, LocaleISOData_4_class)) }; return v }
