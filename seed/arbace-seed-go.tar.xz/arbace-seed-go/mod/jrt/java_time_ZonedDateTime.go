//line java_time_ZonedDateTime.ae:1
package jrt






































func ZonedDateTime_Now__ZonedDateTime() *ZonedDateTime {
	return ZonedDateTime_Now_Clock__ZonedDateTime(Clock_SystemDefaultZone__Clock())
}
func ZonedDateTime_Now_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_Now_Clock__ZonedDateTime(Clock_System_ZoneId__Clock(zone))
}
func ZonedDateTime_Now_Clock__ZonedDateTime(clock Clock_I) *ZonedDateTime {
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	var now *Instant = clock.Instant__Instant(); return ZonedDateTime_OfInstant_Instant_ZoneId__ZonedDateTime(now, clock.GetZone__ZoneId())
}
func ZonedDateTime_Of_LocalDate_LocalTime_ZoneId__ZonedDateTime(date *LocalDate, time *LocalTime, zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_Of_LocalDateTime_ZoneId__ZonedDateTime(LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(date, time), zone)
}
func ZonedDateTime_Of_LocalDateTime_ZoneId__ZonedDateTime(localDateTime *LocalDateTime, zone ZoneId_I) *ZonedDateTime {
	return ZonedDateTime_OfLocal_LocalDateTime_ZoneId_ZoneOffset__ZonedDateTime(localDateTime, zone, nil)
}
func ZonedDateTime_Of_I_I_I_I_I_I_I_ZoneId__ZonedDateTime(year, month, dayOfMonth, hour, minute, second, nanoOfSecond int32, zone ZoneId_I) *ZonedDateTime {


	var dt *LocalDateTime = LocalDateTime_Of_I_I_I_I_I_I_I__LocalDateTime(year, month, dayOfMonth, hour, minute, second, nanoOfSecond)
	return ZonedDateTime_OfLocal_LocalDateTime_ZoneId_ZoneOffset__ZonedDateTime(dt, zone, nil)
}
func ZonedDateTime_OfLocal_LocalDateTime_ZoneId_ZoneOffset__ZonedDateTime(localDateTime *LocalDateTime, zone ZoneId_I, preferredOffset *ZoneOffset) *ZonedDateTime {

	Objects_RequireNonNull_O_String__O(localDateTime.Ref(), Lit_2167)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	if ZoneOffset_InstanceOf(zone) {
		return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(localDateTime, ZoneOffset_Cast(zone), zone) } else {
			var rules *ZoneRules = zone.GetRules__ZoneRules(); var validOffsets List = NN(rules).GetValidOffsets_LocalDateTime__List(localDateTime); var offset *ZoneOffset


			if validOffsets.Size__I() == 1 {
				offset = ZoneOffset_Cast(validOffsets.Get_I__O(0)) } else {
//line :71:1
					if validOffsets.Size__I() == 0 {


						var trans *ZoneOffsetTransition = NN(rules).GetTransition_LocalDateTime__ZoneOffsetTransition(localDateTime)
						localDateTime = NN(localDateTime).PlusSeconds_J__LocalDateTime(NN(NN(trans).GetDuration__Duration()).GetSeconds__J())
						offset = NN(trans).GetOffsetAfter__ZoneOffset() } else {
//line :71:1
							var tmp1 bool; var tmp2 bool





							tmp2 = !(preferredOffset == nil); if tmp2 { tmp2 = validOffsets.Contains_O__Z(preferredOffset.Ref()) }; tmp1 = tmp2
//line :71:1
							if tmp1 {






								offset = preferredOffset } else {

									offset = ZoneOffset_Cast(Objects_RequireNonNull_O_String__O(ZoneOffset_Cast(validOffsets.Get_I__O(0)).Ref(), Lit_2052))
								}
						}
				}
			return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(localDateTime, offset, zone)
		} }
func ZonedDateTime_OfInstant_Instant_ZoneId__ZonedDateTime(instant *Instant, zone ZoneId_I) *ZonedDateTime {
	Objects_RequireNonNull_O_String__O(instant.Ref(), Lit_2039)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	return ZonedDateTime_Create_J_I_ZoneId__ZonedDateTime(NN(instant).GetEpochSecond__J(), NN(instant).GetNano__I(), zone)
}
func ZonedDateTime_OfInstant_LocalDateTime_ZoneOffset_ZoneId__ZonedDateTime(localDateTime *LocalDateTime, offset *ZoneOffset, zone ZoneId_I) *ZonedDateTime {

	Objects_RequireNonNull_O_String__O(localDateTime.Ref(), Lit_2167)
	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	if NN(zone.GetRules__ZoneRules()).IsValidOffset_LocalDateTime_ZoneOffset__Z(localDateTime, offset) {
		return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(localDateTime, offset, zone) } else {
			return ZonedDateTime_Create_J_I_ZoneId__ZonedDateTime(NN(localDateTime).ToEpochSecond_ZoneOffset__J(offset), NN(localDateTime).GetNano__I(), zone)
		} }
func ZonedDateTime_Create_J_I_ZoneId__ZonedDateTime(epochSecond int64, nanoOfSecond int32, zone ZoneId_I) *ZonedDateTime {
	var offset *ZoneOffset = zone.GetOffset_J__ZoneOffset(epochSecond); var ldt *LocalDateTime = LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(epochSecond, nanoOfSecond, offset)

	return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(ldt, offset, zone)
}
func ZonedDateTime_OfStrict_LocalDateTime_ZoneOffset_ZoneId__ZonedDateTime(localDateTime *LocalDateTime, offset *ZoneOffset, zone ZoneId_I) *ZonedDateTime {

	Objects_RequireNonNull_O_String__O(localDateTime.Ref(), Lit_2167)
	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var rules *ZoneRules = zone.GetRules__ZoneRules()
	if NN(rules).IsValidOffset_LocalDateTime_ZoneOffset__Z(localDateTime, offset) == false {
		var trans *ZoneOffsetTransition = NN(rules).GetTransition_LocalDateTime__ZoneOffsetTransition(localDateTime); var tmp1 bool; var tmp2 bool
		tmp2 = !(trans == nil); if tmp2 { tmp2 = NN(trans).IsGap__Z() }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(DateTimeException_New_String(Concat(Lit_2168, StrOfObj(localDateTime.Ref()), Lit_2169, StrOfObj(zone), Lit_2170))))
		}






		panic(Thrown(DateTimeException_New_String(Concat(Lit_2171, StrOfObj(offset.Ref()), Lit_2172, StrOfObj(localDateTime.Ref()), Lit_2173, StrOfObj(zone), Lit_1371))))
	}






	return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(localDateTime, offset, zone)
}
func ZonedDateTime_OfLenient_LocalDateTime_ZoneOffset_ZoneId__ZonedDateTime(p0 *LocalDateTime, p1 *ZoneOffset, p2 ZoneId_I) *ZonedDateTime { panic(A2g_NotTranslated("java.time.ZonedDateTime.ofLenient(Ljava/time/LocalDateTime;Ljava/time/ZoneOffset;Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;")) }








func ZonedDateTime_From_TemporalAccessor__ZonedDateTime(temporal TemporalAccessor) *ZonedDateTime {
	if ZonedDateTime_InstanceOf(temporal) {
		return ZonedDateTime_Cast(temporal) } else {
			var tmp1 *ZonedDateTime; tmp5 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var zone ZoneId_I = ZoneId_From_TemporalAccessor__ZoneId(temporal); var tmp2 *ChronoField
					ChronoField_Init(); tmp2 = ChronoField_INSTANT_SECONDS; if temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp2)) {
						var epochSecond int64; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_INSTANT_SECONDS; epochSecond = temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3)); var nanoOfSecond int32; var tmp4 *ChronoField
						ChronoField_Init(); tmp4 = ChronoField_NANO_OF_SECOND; nanoOfSecond = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp4))
						tmp1 = ZonedDateTime_Create_J_I_ZoneId__ZonedDateTime(epochSecond, nanoOfSecond, zone) } else {
							var date *LocalDate = LocalDate_From_TemporalAccessor__LocalDate(temporal); var time *LocalTime = LocalTime_From_TemporalAccessor__LocalTime(temporal)

							tmp1 = ZonedDateTime_Of_LocalDate_LocalTime_ZoneId__ZonedDateTime(date, time, zone) } }; return nil }()
//line :144:1
			if tmp5 != nil { if DateTimeException_InstanceOf(tmp5) { var ex DateTimeException_I = DateTimeException_Cast(tmp5)









				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2174, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :144:1
					panic(tmp5) } }; return tmp1
		}
}














func ZonedDateTime_Parse_CharSequence__ZonedDateTime(text CharSequence) *ZonedDateTime {
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_ZONED_DATE_TIME; return ZonedDateTime_Parse_CharSequence_DateTimeFormatter__ZonedDateTime(text, tmp1)
}
func ZonedDateTime_Parse_CharSequence_DateTimeFormatter__ZonedDateTime(text CharSequence, formatter *DateTimeFormatter) *ZonedDateTime {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return ZonedDateTime_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return ZonedDateTime_From_TemporalAccessor__ZonedDateTime(p0).Ref() }}))
}



func ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(p0 *LocalDateTime, p1 *ZoneOffset, p2 ZoneId_I) *ZonedDateTime { t := &ZonedDateTime{}; t.Ctor_LocalDateTime_ZoneOffset_ZoneId(p0, p1, p2); return t }
//line :171:1
func (t *ZonedDateTime) Ctor_LocalDateTime_ZoneOffset_ZoneId(dateTime *LocalDateTime, offset *ZoneOffset, zone ZoneId_I) {
	t.F_dateTime = dateTime
	t.F_offset = offset
	t.F_zone = zone
}
func (t *ZonedDateTime) ResolveLocal_LocalDateTime__ZonedDateTime(newDateTime *LocalDateTime) *ZonedDateTime {
	return ZonedDateTime_OfLocal_LocalDateTime_ZoneId_ZoneOffset__ZonedDateTime(newDateTime, t.F_zone, t.F_offset)
}
func (t *ZonedDateTime) ResolveInstant_LocalDateTime__ZonedDateTime(newDateTime *LocalDateTime) *ZonedDateTime {
	return ZonedDateTime_OfInstant_LocalDateTime_ZoneOffset_ZoneId__ZonedDateTime(newDateTime, t.F_offset, t.F_zone)
}
func (t *ZonedDateTime) ResolveOffset_ZoneOffset__ZonedDateTime(offset *ZoneOffset) *ZonedDateTime {
	var tmp1 bool; var tmp2 bool; tmp2 = NN(offset).Equals_O__Z(t.F_offset.Ref()) == false; if tmp2 {
		tmp2 = NN(t.F_zone.GetRules__ZoneRules()).IsValidOffset_LocalDateTime_ZoneOffset__Z(t.F_dateTime, offset) }
//line :183:1
	tmp1 = tmp2; if tmp1 {

		return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(t.F_dateTime, offset, t.F_zone) } else {
//line :183:1
			return t
		}
}


func (t *ZonedDateTime) IsSupported_TemporalField__Z(field TemporalField) bool {
	var tmp1 bool; tmp1 = ChronoField_InstanceOf(field); if !tmp1 { var tmp2 bool; tmp2 = !(field == nil); if tmp2 { tmp2 = field.IsSupportedBy_TemporalAccessor__Z(t) }; tmp1 = tmp2 }; return tmp1
}
func (t *ZonedDateTime) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	return ChronoZonedDateTime_IsSupported_TemporalUnit__Z(t, unit)
}
func (t *ZonedDateTime) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; var tmp2 bool; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_INSTANT_SECONDS; tmp2 = any(field) == any(tmp3.Ref()); if !tmp2 {
			var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_OFFSET_SECONDS; tmp2 = any(field) == any(tmp4.Ref()) }
//line :196:1
		tmp1 = tmp2; if tmp1 {

			return field.Range__ValueRange() } else {
				return NN(t.F_dateTime).Range_TemporalField__ValueRange(field) } } else {
					return field.RangeRefinedBy_TemporalAccessor__ValueRange(t)
				} }
func (t *ZonedDateTime) Get_TemporalField__I(field TemporalField) int32 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:

			panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2078))); case 29:

			return NN(t.GetOffset__ZoneOffset()).GetTotalSeconds__I(); default:
			return NN(t.F_dateTime).Get_TemporalField__I(field)} } else {
				return ChronoZonedDateTime_Get_TemporalField__I(t, field) } }; panic("a2g: unreachable")
}
func (t *ZonedDateTime) GetLong_TemporalField__J(field TemporalField) int64 {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:
			return t.ToEpochSecond__J(); case 29:
			return int64(NN(t.GetOffset__ZoneOffset()).GetTotalSeconds__I()); default:
			return NN(t.F_dateTime).GetLong_TemporalField__J(field)} } else {
				return field.GetFrom_TemporalAccessor__J(t) } }; panic("a2g: unreachable")
}
func (t *ZonedDateTime) GetOffset__ZoneOffset() *ZoneOffset { return t.F_offset }

func (t *ZonedDateTime) WithEarlierOffsetAtOverlap__ZonedDateTime() *ZonedDateTime {
	var trans *ZoneOffsetTransition = NN(t.GetZone__ZoneId().GetRules__ZoneRules()).GetTransition_LocalDateTime__ZoneOffsetTransition(t.F_dateTime); var tmp1 bool; var tmp2 bool
	tmp2 = !(trans == nil); if tmp2 { tmp2 = NN(trans).IsOverlap__Z() }; tmp1 = tmp2; if tmp1 {
		var earlierOffset *ZoneOffset = NN(trans).GetOffsetBefore__ZoneOffset()
		if NN(earlierOffset).Equals_O__Z(t.F_offset.Ref()) == false {
			return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(t.F_dateTime, earlierOffset, t.F_zone) } }
//line :223:1
	return t
}





func (t *ZonedDateTime) WithLaterOffsetAtOverlap__ZonedDateTime() *ZonedDateTime {
	var trans *ZoneOffsetTransition = NN(t.GetZone__ZoneId().GetRules__ZoneRules()).GetTransition_LocalDateTime__ZoneOffsetTransition(t.ToLocalDateTime__LocalDateTime())
	if !(trans == nil) {
		var laterOffset *ZoneOffset = NN(trans).GetOffsetAfter__ZoneOffset()
		if NN(laterOffset).Equals_O__Z(t.F_offset.Ref()) == false {
			return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(t.F_dateTime, laterOffset, t.F_zone) } }
//line :231:1
	return t
}





func (t *ZonedDateTime) GetZone__ZoneId() ZoneId_I { return t.F_zone }

func (t *ZonedDateTime) WithZoneSameLocal_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	if t.F_zone.Equals_O__Z(zone) { return t } else { return ZonedDateTime_OfLocal_LocalDateTime_ZoneId_ZoneOffset__ZonedDateTime(t.F_dateTime, zone, t.F_offset)
	} }
func (t *ZonedDateTime) WithZoneSameInstant_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	if t.F_zone.Equals_O__Z(zone) { return t } else {

		return ZonedDateTime_Create_J_I_ZoneId__ZonedDateTime(NN(t.F_dateTime).ToEpochSecond_ZoneOffset__J(t.F_offset), NN(t.F_dateTime).GetNano__I(), zone)
	} }
func (t *ZonedDateTime) WithFixedOffsetZone__ZonedDateTime() *ZonedDateTime {
	if t.F_zone.Equals_O__Z(t.F_offset.Ref()) { return t } else { return ZonedDateTime_New_LocalDateTime_ZoneOffset_ZoneId(t.F_dateTime, t.F_offset, Up_ZoneOffset_ZoneId(t.F_offset))
	} }
func (t *ZonedDateTime) ToLocalDateTime__LocalDateTime() *LocalDateTime { return t.F_dateTime }

func (t *ZonedDateTime) ToLocalDate__LocalDate() *LocalDate { return NN(t.F_dateTime).ToLocalDate__LocalDate() }

func (t *ZonedDateTime) GetYear__I() int32 { return NN(t.F_dateTime).GetYear__I() }

func (t *ZonedDateTime) GetMonthValue__I() int32 { return NN(t.F_dateTime).GetMonthValue__I() }

func (t *ZonedDateTime) GetMonth__Month() *Month { return NN(t.F_dateTime).GetMonth__Month() }

func (t *ZonedDateTime) GetDayOfMonth__I() int32 { return NN(t.F_dateTime).GetDayOfMonth__I() }

func (t *ZonedDateTime) GetDayOfYear__I() int32 { return NN(t.F_dateTime).GetDayOfYear__I() }

func (t *ZonedDateTime) GetDayOfWeek__DayOfWeek() *DayOfWeek {
	return NN(t.F_dateTime).GetDayOfWeek__DayOfWeek()
}
func (t *ZonedDateTime) ToLocalTime__LocalTime() *LocalTime { return NN(t.F_dateTime).ToLocalTime__LocalTime() }

func (t *ZonedDateTime) GetHour__I() int32 { return NN(t.F_dateTime).GetHour__I() }

func (t *ZonedDateTime) GetMinute__I() int32 { return NN(t.F_dateTime).GetMinute__I() }

func (t *ZonedDateTime) GetSecond__I() int32 { return NN(t.F_dateTime).GetSecond__I() }

func (t *ZonedDateTime) GetNano__I() int32 { return NN(t.F_dateTime).GetNano__I() }

func (t *ZonedDateTime) With_TemporalAdjuster__ZonedDateTime(adjuster TemporalAdjuster) *ZonedDateTime {
	if LocalDate_InstanceOf(adjuster) {

		return t.ResolveLocal_LocalDateTime__ZonedDateTime(LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(LocalDate_Cast(adjuster), NN(t.F_dateTime).ToLocalTime__LocalTime())) } else {
//line :281:1
			if LocalTime_InstanceOf(adjuster) {



				return t.ResolveLocal_LocalDateTime__ZonedDateTime(LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(NN(t.F_dateTime).ToLocalDate__LocalDate(), LocalTime_Cast(adjuster))) } else {
//line :281:1
					if LocalDateTime_InstanceOf(adjuster) {




						return t.ResolveLocal_LocalDateTime__ZonedDateTime(LocalDateTime_Cast(adjuster)) } else {

							var tmp1 TemporalAdjuster = adjuster; if OffsetDateTime_InstanceOf(tmp1) { var odt *OffsetDateTime = OffsetDateTime_Cast(tmp1); var tmp2 *LocalDateTime = NN(odt).ToLocalDateTime__LocalDateTime(); var tmp3 ZoneId_I = t.F_zone
								return ZonedDateTime_OfLocal_LocalDateTime_ZoneId_ZoneOffset__ZonedDateTime(tmp2, tmp3, NN(odt).GetOffset__ZoneOffset()) } else {
									var tmp4 TemporalAdjuster = adjuster; if Instant_InstanceOf(tmp4) { var instant *Instant = Instant_Cast(tmp4)
										return ZonedDateTime_Create_J_I_ZoneId__ZonedDateTime(NN(instant).GetEpochSecond__J(), NN(instant).GetNano__I(), t.F_zone) } else {
											if ZoneOffset_InstanceOf(adjuster) {
												return t.ResolveOffset_ZoneOffset__ZonedDateTime(ZoneOffset_Cast(adjuster)) } else {
													return ZonedDateTime_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
												} } } } } } }
func (t *ZonedDateTime) With_TemporalField_J__ZonedDateTime(field TemporalField, newValue int64) *ZonedDateTime {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		switch NN(chronoField).F_ordinal { case 28:
			return ZonedDateTime_Create_J_I_ZoneId__ZonedDateTime(newValue, t.GetNano__I(), t.F_zone); case 29:

			var offset *ZoneOffset = ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(chronoField).CheckValidIntValue_J__I(newValue))
			return t.ResolveOffset_ZoneOffset__ZonedDateTime(offset); default:
			return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).With_TemporalField_J__LocalDateTime(field, newValue))} } else {
				return ZonedDateTime_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue)) } }; panic("a2g: unreachable")
}
func (t *ZonedDateTime) WithYear_I__ZonedDateTime(year int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithYear_I__LocalDateTime(year))
}
func (t *ZonedDateTime) WithMonth_I__ZonedDateTime(month int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithMonth_I__LocalDateTime(month))
}
func (t *ZonedDateTime) WithDayOfMonth_I__ZonedDateTime(dayOfMonth int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithDayOfMonth_I__LocalDateTime(dayOfMonth))
}
func (t *ZonedDateTime) WithDayOfYear_I__ZonedDateTime(dayOfYear int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithDayOfYear_I__LocalDateTime(dayOfYear))
}
func (t *ZonedDateTime) WithHour_I__ZonedDateTime(hour int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithHour_I__LocalDateTime(hour))
}
func (t *ZonedDateTime) WithMinute_I__ZonedDateTime(minute int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithMinute_I__LocalDateTime(minute))
}
func (t *ZonedDateTime) WithSecond_I__ZonedDateTime(second int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithSecond_I__LocalDateTime(second))
}
func (t *ZonedDateTime) WithNano_I__ZonedDateTime(nanoOfSecond int32) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).WithNano_I__LocalDateTime(nanoOfSecond))
}
func (t *ZonedDateTime) TruncatedTo_TemporalUnit__ZonedDateTime(unit TemporalUnit) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).TruncatedTo_TemporalUnit__LocalDateTime(unit))
}
func (t *ZonedDateTime) Plus_TemporalAmount__ZonedDateTime(amountToAdd TemporalAmount) *ZonedDateTime {
	var tmp1 TemporalAmount = amountToAdd; if Period_InstanceOf(tmp1) { var periodToAdd *Period = Period_Cast(tmp1)
		return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).Plus_TemporalAmount__LocalDateTime(Up_Period_TemporalAmount(periodToAdd))) } else {

			Objects_RequireNonNull_O_String__O(amountToAdd, Lit_2046)
			return ZonedDateTime_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
		} }
func (t *ZonedDateTime) Plus_J_TemporalUnit__ZonedDateTime(amountToAdd int64, unit TemporalUnit) *ZonedDateTime {
	if ChronoUnit_InstanceOf(unit) {
		if unit.IsDateBased__Z() {
			return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).Plus_J_TemporalUnit__LocalDateTime(amountToAdd, unit)) } else {
				return t.ResolveInstant_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).Plus_J_TemporalUnit__LocalDateTime(amountToAdd, unit)) } } else {
					return ZonedDateTime_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd))
				} }
func (t *ZonedDateTime) PlusYears_J__ZonedDateTime(years int64) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusYears_J__LocalDateTime(years))
}
func (t *ZonedDateTime) PlusMonths_J__ZonedDateTime(months int64) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusMonths_J__LocalDateTime(months))
}
func (t *ZonedDateTime) PlusWeeks_J__ZonedDateTime(weeks int64) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusWeeks_J__LocalDateTime(weeks))
}
func (t *ZonedDateTime) PlusDays_J__ZonedDateTime(days int64) *ZonedDateTime {
	return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusDays_J__LocalDateTime(days))
}
func (t *ZonedDateTime) PlusHours_J__ZonedDateTime(hours int64) *ZonedDateTime {
	return t.ResolveInstant_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusHours_J__LocalDateTime(hours))
}
func (t *ZonedDateTime) PlusMinutes_J__ZonedDateTime(minutes int64) *ZonedDateTime {
	return t.ResolveInstant_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusMinutes_J__LocalDateTime(minutes))
}
func (t *ZonedDateTime) PlusSeconds_J__ZonedDateTime(seconds int64) *ZonedDateTime {
	return t.ResolveInstant_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusSeconds_J__LocalDateTime(seconds))
}
func (t *ZonedDateTime) PlusNanos_J__ZonedDateTime(nanos int64) *ZonedDateTime {
	return t.ResolveInstant_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).PlusNanos_J__LocalDateTime(nanos))
}
func (t *ZonedDateTime) Minus_TemporalAmount__ZonedDateTime(amountToSubtract TemporalAmount) *ZonedDateTime {
	var tmp1 TemporalAmount = amountToSubtract; if Period_InstanceOf(tmp1) { var periodToSubtract *Period = Period_Cast(tmp1)
		return t.ResolveLocal_LocalDateTime__ZonedDateTime(NN(t.F_dateTime).Minus_TemporalAmount__LocalDateTime(Up_Period_TemporalAmount(periodToSubtract))) } else {

			Objects_RequireNonNull_O_String__O(amountToSubtract, Lit_2047)
			return ZonedDateTime_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
		} }
func (t *ZonedDateTime) Minus_J_TemporalUnit__ZonedDateTime(amountToSubtract int64, unit TemporalUnit) *ZonedDateTime {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__ZonedDateTime(9223372036854775807, unit)).Plus_J_TemporalUnit__ZonedDateTime(1, unit) } else {
			return t.Plus_J_TemporalUnit__ZonedDateTime(-amountToSubtract, unit)
		} }
func (t *ZonedDateTime) MinusYears_J__ZonedDateTime(years int64) *ZonedDateTime {
	if years == -9223372036854775808 {
		return NN(t.PlusYears_J__ZonedDateTime(9223372036854775807)).PlusYears_J__ZonedDateTime(1) } else {
			return t.PlusYears_J__ZonedDateTime(-years)
		} }
func (t *ZonedDateTime) MinusMonths_J__ZonedDateTime(months int64) *ZonedDateTime {
	if months == -9223372036854775808 {
		return NN(t.PlusMonths_J__ZonedDateTime(9223372036854775807)).PlusMonths_J__ZonedDateTime(1) } else {
			return t.PlusMonths_J__ZonedDateTime(-months)
		} }
func (t *ZonedDateTime) MinusWeeks_J__ZonedDateTime(weeks int64) *ZonedDateTime {
	if weeks == -9223372036854775808 {
		return NN(t.PlusWeeks_J__ZonedDateTime(9223372036854775807)).PlusWeeks_J__ZonedDateTime(1) } else {
			return t.PlusWeeks_J__ZonedDateTime(-weeks)
		} }
func (t *ZonedDateTime) MinusDays_J__ZonedDateTime(days int64) *ZonedDateTime {
	if days == -9223372036854775808 {
		return NN(t.PlusDays_J__ZonedDateTime(9223372036854775807)).PlusDays_J__ZonedDateTime(1) } else {
			return t.PlusDays_J__ZonedDateTime(-days)
		} }
func (t *ZonedDateTime) MinusHours_J__ZonedDateTime(hours int64) *ZonedDateTime {
	if hours == -9223372036854775808 {
		return NN(t.PlusHours_J__ZonedDateTime(9223372036854775807)).PlusHours_J__ZonedDateTime(1) } else {
			return t.PlusHours_J__ZonedDateTime(-hours)
		} }
func (t *ZonedDateTime) MinusMinutes_J__ZonedDateTime(minutes int64) *ZonedDateTime {
	if minutes == -9223372036854775808 {
		return NN(t.PlusMinutes_J__ZonedDateTime(9223372036854775807)).PlusMinutes_J__ZonedDateTime(1) } else {
			return t.PlusMinutes_J__ZonedDateTime(-minutes)
		} }
func (t *ZonedDateTime) MinusSeconds_J__ZonedDateTime(seconds int64) *ZonedDateTime {
	if seconds == -9223372036854775808 {
		return NN(t.PlusSeconds_J__ZonedDateTime(9223372036854775807)).PlusSeconds_J__ZonedDateTime(1) } else {
			return t.PlusSeconds_J__ZonedDateTime(-seconds)
		} }
func (t *ZonedDateTime) MinusNanos_J__ZonedDateTime(nanos int64) *ZonedDateTime {
	if nanos == -9223372036854775808 {
		return NN(t.PlusNanos_J__ZonedDateTime(9223372036854775807)).PlusNanos_J__ZonedDateTime(1) } else {
			return t.PlusNanos_J__ZonedDateTime(-nanos)
		} }
func (t *ZonedDateTime) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_LocalDate__TemporalQuery() {
		return t.ToLocalDate__LocalDate().Ref() } else {
			return ChronoZonedDateTime_Query_TemporalQuery__O(t, query)
		} }
func (t *ZonedDateTime) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	var end *ZonedDateTime = ZonedDateTime_From_TemporalAccessor__ZonedDateTime(endExclusive)
	if ChronoUnit_InstanceOf(unit) {
		var start *ZonedDateTime = t; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

			end = NN(end).WithZoneSameInstant_ZoneId__ZonedDateTime(t.F_zone); return nil }()
//line :432:1
		if tmp1 != nil { if DateTimeException_InstanceOf(tmp1) { var ex DateTimeException_I = DateTimeException_Cast(tmp1); _ = ex

			start = t.WithZoneSameInstant_ZoneId__ZonedDateTime(end.F_zone) } else {
//line :432:1
				panic(tmp1)
			}
		}
		if unit.IsDateBased__Z() {
			var tmp2 *LocalDateTime = start.F_dateTime; return NN(tmp2).Until_Temporal_TemporalUnit__J(Up_LocalDateTime_Temporal(end.F_dateTime), unit) } else {
				return NN(NN(start).ToOffsetDateTime__OffsetDateTime()).Until_Temporal_TemporalUnit__J(Up_OffsetDateTime_Temporal(NN(end).ToOffsetDateTime__OffsetDateTime()), unit) } } else {
					return unit.Between_Temporal_Temporal__J(t, Up_ZonedDateTime_Temporal(end))
				} }
func (t *ZonedDateTime) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *ZonedDateTime) ToOffsetDateTime__OffsetDateTime() *OffsetDateTime {
	return OffsetDateTime_Of_LocalDateTime_ZoneOffset__OffsetDateTime(t.F_dateTime, t.F_offset)
}
func (t *ZonedDateTime) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if ZonedDateTime_InstanceOf(tmp1) { var other *ZonedDateTime = ZonedDateTime_Cast(tmp1); var tmp2 *LocalDateTime = t.F_dateTime
			if NN(tmp2).Equals_O__Z(other.F_dateTime.Ref()) {
				var tmp3 *ZoneOffset = t.F_offset; if NN(tmp3).Equals_O__Z(other.F_offset.Ref()) { var tmp4 ZoneId_I = t.F_zone; return tmp4.Equals_O__Z(other.F_zone) } else { return false } } else {
//line :451:1
					return false } } else {
//line :450:1
						return false
					}
	}
}


func (t *ZonedDateTime) HashCode__I() int32 {
	return NN(t.F_dateTime).HashCode__I() ^ NN(t.F_offset).HashCode__I() ^ Integer_RotateLeft_I_I__I(t.F_zone.HashCode__I(), 3)
}

func (t *ZonedDateTime) ToString__String() *String {
	var offsetStr *String = NN(t.F_offset).ToString__String(); var zoneStr *String; var length int32 = 29 + NN(offsetStr).Length__I()


	if any(t.F_offset.Ref()) == any(t.F_zone) { } else {
		zoneStr = t.F_zone.ToString__String()
		length = length + (NN(zoneStr).Length__I() + 2) }
	var buf *StringBuilder = StringBuilder_New_I(length)
	DateTimeHelper_FormatTo_StringBuilder_LocalDateTime__V(buf, t.F_dateTime)
	NN(buf).Append_String__StringBuilder(offsetStr)
	if !(zoneStr == nil) { NN(NN(NN(buf).Append_C__StringBuilder(91)).Append_String__StringBuilder(zoneStr)).Append_C__StringBuilder(93) }
	return NN(buf).ToString__String()
}
func (t *ZonedDateTime) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.ZonedDateTime.writeReplace()Ljava/lang/Object;")) }



type ZonedDateTime struct{ Object; F_dateTime *LocalDateTime; F_offset *ZoneOffset; F_zone ZoneId_I }

func (t *ZonedDateTime) Is_Temporal() {}

func (t *ZonedDateTime) Is_ChronoZonedDateTime() {}

func (t *ZonedDateTime) Is_Serializable() {}

func (t *ZonedDateTime) Is_TemporalAccessor() {}

func (t *ZonedDateTime) Is_Comparable() {}

const ZonedDateTime_serialVersionUID int64 = -6260982410461394882

func (t *ZonedDateTime) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_ZonedDateTime_Temporal(t.With_TemporalAdjuster__ZonedDateTime(p0)) }

func (t *ZonedDateTime) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_ZonedDateTime_Temporal(t.With_TemporalField_J__ZonedDateTime(p0, p1)) }

func (t *ZonedDateTime) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_ZonedDateTime_Temporal(t.Plus_TemporalAmount__ZonedDateTime(p0)) }

func (t *ZonedDateTime) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_ZonedDateTime_Temporal(t.Plus_J_TemporalUnit__ZonedDateTime(p0, p1)) }

func (t *ZonedDateTime) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_ZonedDateTime_Temporal(t.Minus_TemporalAmount__ZonedDateTime(p0)) }

func (t *ZonedDateTime) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_ZonedDateTime_Temporal(t.Minus_J_TemporalUnit__ZonedDateTime(p0, p1)) }

func (t *ZonedDateTime) ToLocalDate__ChronoLocalDate() ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.ToLocalDate__LocalDate()) }

func (t *ZonedDateTime) ToLocalDateTime__ChronoLocalDateTime() ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.ToLocalDateTime__LocalDateTime()) }

func (t *ZonedDateTime) WithEarlierOffsetAtOverlap__ChronoZonedDateTime() ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.WithEarlierOffsetAtOverlap__ZonedDateTime()) }

func (t *ZonedDateTime) WithLaterOffsetAtOverlap__ChronoZonedDateTime() ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.WithLaterOffsetAtOverlap__ZonedDateTime()) }

func (t *ZonedDateTime) WithZoneSameLocal_ZoneId__ChronoZonedDateTime(p0 ZoneId_I) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.WithZoneSameLocal_ZoneId__ZonedDateTime(p0)) }

func (t *ZonedDateTime) WithZoneSameInstant_ZoneId__ChronoZonedDateTime(p0 ZoneId_I) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.WithZoneSameInstant_ZoneId__ZonedDateTime(p0)) }

func (t *ZonedDateTime) With_TemporalAdjuster__ChronoZonedDateTime(p0 TemporalAdjuster) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.With_TemporalAdjuster__ZonedDateTime(p0)) }

func (t *ZonedDateTime) With_TemporalField_J__ChronoZonedDateTime(p0 TemporalField, p1 int64) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.With_TemporalField_J__ZonedDateTime(p0, p1)) }

func (t *ZonedDateTime) Plus_TemporalAmount__ChronoZonedDateTime(p0 TemporalAmount) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.Plus_TemporalAmount__ZonedDateTime(p0)) }

func (t *ZonedDateTime) Plus_J_TemporalUnit__ChronoZonedDateTime(p0 int64, p1 TemporalUnit) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.Plus_J_TemporalUnit__ZonedDateTime(p0, p1)) }

func (t *ZonedDateTime) Minus_TemporalAmount__ChronoZonedDateTime(p0 TemporalAmount) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.Minus_TemporalAmount__ZonedDateTime(p0)) }

func (t *ZonedDateTime) Minus_J_TemporalUnit__ChronoZonedDateTime(p0 int64, p1 TemporalUnit) ChronoZonedDateTime { return Up_ZonedDateTime_ChronoZonedDateTime(t.Minus_J_TemporalUnit__ZonedDateTime(p0, p1)) }

func (t *ZonedDateTime) IsAfter_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool { return ChronoZonedDateTime_IsAfter_ChronoZonedDateTime__Z(t, p0) }

func (t *ZonedDateTime) IsEqual_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool { return ChronoZonedDateTime_IsEqual_ChronoZonedDateTime__Z(t, p0) }

func (t *ZonedDateTime) IsBefore_ChronoZonedDateTime__Z(p0 ChronoZonedDateTime) bool { return ChronoZonedDateTime_IsBefore_ChronoZonedDateTime__Z(t, p0) }

func (t *ZonedDateTime) ToInstant__Instant() *Instant { return ChronoZonedDateTime_ToInstant__Instant(t) }

func (t *ZonedDateTime) ToEpochSecond__J() int64 { return ChronoZonedDateTime_ToEpochSecond__J(t) }

func (t *ZonedDateTime) CompareTo_O__I(p0 any) int32 { return ChronoZonedDateTime_CompareTo_O__I(t, p0) }

func (t *ZonedDateTime) CompareTo_ChronoZonedDateTime__I(p0 ChronoZonedDateTime) int32 { return ChronoZonedDateTime_CompareTo_ChronoZonedDateTime__I(t, p0) }

func (t *ZonedDateTime) GetChronology__Chronology() Chronology { return ChronoZonedDateTime_GetChronology__Chronology(t) }

func (t *ZonedDateTime) Ref() any { if t == nil { return nil }; return t }

func (t *ZonedDateTime) GetClass__Class() *Class { return ZonedDateTime_class }

func (t *ZonedDateTime) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZonedDateTime) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZonedDateTime_InstanceOf(x any) bool { _, ok := x.(*ZonedDateTime); return ok }

func ZonedDateTime_Cast(x any) *ZonedDateTime { if x == nil { return nil }; v, ok := x.(*ZonedDateTime); if !ok { panic(ClassCast(x, ZonedDateTime_class)) }; return v }
