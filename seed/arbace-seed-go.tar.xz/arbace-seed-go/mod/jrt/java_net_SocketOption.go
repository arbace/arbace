//line java_net_SocketOption.ae:1
package jrt






type SocketOption interface{ Object_I; Is_SocketOption(); Name__String() *String; Type__Class() *Class }

func SocketOption_InstanceOf(x any) bool { _, ok := x.(SocketOption); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SocketOption_class) } }; return ok }

func SocketOption_Cast(x any) SocketOption { if x == nil { return nil }; v, ok := x.(SocketOption); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(SocketOption_class) } }; if !ok { panic(ClassCast(x, SocketOption_class)) }; return v }
