//line java_text_DigitList.ae:1
package jrt

























func (t *DigitList) IsZero__Z() bool { return !t.NonZeroAfterIndex_I__Z(0) }

func (t *DigitList) NonZeroAfterIndex_I__Z(index int32) bool {
	var i int32 = index; L1: for {
		if i < t.F_count {
			if !(int32(t.F_digits.A[i]) == 48) { return true } else { i = i + 1; continue L1 } }
//line :30:1
		break L1 }
//line :29:1
	return false
}





func (t *DigitList) SetRoundingMode_RoundingMode__V(r *RoundingMode) {
	t.F_roundingMode = r
}
func (t *DigitList) Clear__V() { t.F_decimalAt = 0; t.F_count = 0 }

func (t *DigitList) Append_C__V(digit uint16) {
	var tmp1 int32 = t.F_count; if tmp1 == int32(len(t.F_digits.A)) {
		var data *ByteArray = NewByteArray(ArraysSupport_NewLength_I_I_I__I(t.F_count, 1, t.F_count))
		System_Arraycopy_O_I_O_I_I__V(t.F_digits.Ref(), 0, data.Ref(), 0, t.F_count)
		t.F_digits = data }
	var tmp2 *ByteArray = t.F_digits; var tmp3 int32; var old_1 int32 = t.F_count
	t.F_count = t.F_count + 1; tmp3 = old_1
//line :46:1
	tmp2.A[tmp3] = int8(digit)
}


func (t *DigitList) GetDouble__D() float64 {
	if t.F_count == 0 { return 0.0 } else { return FloatingDecimal_ParseDoubleSignlessDigits_I_B1_I__D(t.F_decimalAt, t.F_digits, t.F_count)
	} }
func (t *DigitList) GetLong__J() int64 {
	if t.F_count == 0 { return 0 } else {

		var v int64 = Long_ParseUnsignedLong_String__J(String_New_B1_I_I_Charset(t.F_digits, 0, t.F_count, StandardCharsets_ISO_8859_1))
		if v < 0 {
			if v == -9223372036854775808 { return -9223372036854775808 }
			panic(Thrown(NumberFormatException_New_String(Lit_1842))) }
		var tmp1 int64; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
			{ var pow10 int64 = Math_PowExact_J_I__J(10, Math_Max_I_I__I(0, t.F_decimalAt-t.F_count))



				tmp1 = Math_MultiplyExact_J_J__J(v, pow10) }; return nil }()
//line :60:1
		if tmp2 != nil { if ArithmeticException_InstanceOf(tmp2) { var e *ArithmeticException = ArithmeticException_Cast(tmp2); _ = e






			panic(Thrown(NumberFormatException_New_String(Lit_1843))) } else {
//line :60:1
				panic(tmp2) } }; return tmp1
	}
}






func (t *DigitList) GetBigDecimal__BigDecimal() *BigDecimal {
	var count int32 = t.F_count
	if count == 0 {
		return BigDecimal_ValueOf_J_I__BigDecimal(0, -t.F_decimalAt) } else {
			var chars *CharArray = NewCharArray(count)
			SharedSecrets_GetJavaLangAccess__JavaLangAccess().InflateBytesToChars_B1_I_C1_I_I__V(t.F_digits, 0, chars, 0, count)
			var value *BigDecimal = BigDecimal_New_C1_I_I(chars, 0, count)
			if t.F_decimalAt == count { return value } else {

				return NN(value).ScaleByPowerOfTen_I__BigDecimal(t.F_decimalAt - count)
			} } }
func (t *DigitList) FitsIntoLong_Z_Z__Z(isPositive, ignoreNegativeZero bool) bool {
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = t.F_count > 0; if tmp2 { tmp2 = int32(t.F_digits.A[t.F_count-1]) == 48 }; tmp1 = tmp2; if tmp1 {
	t.F_count = t.F_count - 1
//line :81:1
	continue L1 }; break L1
}
	if t.F_count == 0 {
		var tmp3 bool; tmp3 = isPositive; if !tmp3 { tmp3 = ignoreNegativeZero }; return tmp3 } else {
//line :83:1
			var tmp4 bool; var tmp5 bool

			tmp5 = t.F_decimalAt < t.F_count; if !tmp5 { tmp5 = t.F_decimalAt > 19 }; tmp4 = tmp5
//line :83:1
			if tmp4 { return false } else { if t.F_decimalAt < 19 { return true } else {





				var i int32 = 0; L2: for {
					if i < t.F_count {
						var dig int8 = t.F_digits.A[i]; var max_ int8 = DigitList_LONG_MIN_REP.A[i]

						if int32(dig) > int32(max_) { return false }
						if int32(dig) < int32(max_) { return true } else { i = i + 1; continue L2 } }
//line :89:1
					break L2
				}




				if t.F_count < t.F_decimalAt { return true } else { return !isPositive
				} } } } }
func (t *DigitList) Set_Z_D_I__V(isNegative bool, source float64, maximumFractionDigits int32) {
	t.Set_Z_D_I_Z__V(isNegative, source, maximumFractionDigits, true)
}


func (t *DigitList) Set_Z_D_I_Z__V(isNegative bool, source float64, maximumDigits int32, fixedPoint bool) {
	if !A2g_AssertionsDisabled && !Double_IsFinite_D__Z(source) { panic(Thrown(AssertionError_New())) }
	var fdConverter *FloatingDecimal_BinaryToASCIIBuffer = FloatingDecimal_GetBinaryToASCIIConverter_D_Z__FloatingDecimal_BinaryToASCIIBuffer(source, DigitList_COMPAT); var hasBeenRoundedUp bool = NN(fdConverter).DigitsRoundedUp__Z(); var valueExactAsDecimal bool = NN(fdConverter).DecimalDigitsExact__Z()


	t.F_count = NN(fdConverter).GetDigits_B1__I(t.F_digits)
	var exp int32 = NN(fdConverter).GetDecimalExponent__I() - t.F_count
	t.Set_Z_I_Z_Z_I_Z__V(isNegative, exp, hasBeenRoundedUp, valueExactAsDecimal, maximumDigits, fixedPoint)
}
func (t *DigitList) Set_Z_I_Z_Z_I_Z__V(isNegative bool, exp int32, roundedUp, valueExactAsDecimal bool, maximumDigits int32, fixedPoint bool) {

	t.F_isNegative = isNegative
	if !t.NonZeroAfterIndex_I__Z(0) {
		t.F_count = 0; t.F_decimalAt = 0 } else {

			t.F_decimalAt = t.F_count + exp
		L1: for { var tmp1 bool; var tmp2 bool; tmp2 = t.F_count > 1; if tmp2 { tmp2 = int32(t.F_digits.A[t.F_count-1]) == 48 }; tmp1 = tmp2; if tmp1 {
			t.F_count = t.F_count - 1
//line :118:1
			continue L1 }; break L1
		}
			if fixedPoint {
				if -t.F_decimalAt > maximumDigits {
					t.F_count = 0; return } else {
						if -t.F_decimalAt == maximumDigits {
							if t.ShouldRoundUp_I_Z_Z__Z(0, roundedUp, valueExactAsDecimal) {

								t.F_count = 1
								t.F_decimalAt = t.F_decimalAt + 1
								t.F_digits.A[0] = 49 } else {
									t.F_count = 0 }
							return } } }
			var tmp3 int32
			if fixedPoint { tmp3 = maximumDigits + t.F_decimalAt } else { tmp3 = maximumDigits }
//line :131:1
			t.Round_I_Z_Z__V(tmp3, roundedUp, valueExactAsDecimal)
		}
}


func (t *DigitList) RoundInt_I__V(maximumDigits int32) {
	t.Round_I_Z_Z__V(maximumDigits, false, true)
}
func (t *DigitList) Round_I_Z_Z__V(maximumDigits int32, alreadyRounded, valueExactAsDecimal bool) {

	var tmp1 bool; var tmp2 bool; tmp2 = maximumDigits >= 0; if tmp2 { tmp2 = maximumDigits < t.F_count }; tmp1 = tmp2; if tmp1 {
		if t.ShouldRoundUp_I_Z_Z__Z(maximumDigits, alreadyRounded, valueExactAsDecimal) {
			maximumDigits = t.RoundUp_I__I(maximumDigits) }
		t.F_count = maximumDigits
	L1: for { var tmp3 bool; var tmp4 bool; tmp4 = t.F_count > 1; if tmp4 { tmp4 = int32(t.F_digits.A[t.F_count-1]) == 48 }; tmp3 = tmp4; if tmp3 {
		t.F_count = t.F_count - 1
//line :145:1
		continue L1 }; break L1
	}
	} }
func (t *DigitList) ShouldRoundUp_I_Z_Z__Z(maximumDigits int32, alreadyRounded, valueExactAsDecimal bool) bool {

	if maximumDigits < t.F_count {
		switch NN(t.F_roundingMode).F_ordinal { case 0:
			return t.NonZeroAfterIndex_I__Z(maximumDigits); case 1:; case 2:

			var tmp1 bool; var tmp2 bool; tmp2 = t.NonZeroAfterIndex_I__Z(maximumDigits); if tmp2 { tmp2 = !t.F_isNegative }; tmp1 = tmp2; return tmp1; case 3:
			var tmp3 bool; var tmp4 bool; tmp4 = t.NonZeroAfterIndex_I__Z(maximumDigits); if tmp4 { tmp4 = t.F_isNegative }; tmp3 = tmp4; return tmp3; case 4, 5, 6:

			if int32(t.F_digits.A[maximumDigits]) > 53 {
				return true } else {
//line :157:1
					if int32(t.F_digits.A[maximumDigits]) == 53 {


						if maximumDigits == t.F_count-1 {
							if valueExactAsDecimal {
								var tmp5 bool; var tmp6 bool; var tmp7 *RoundingMode = t.F_roundingMode; var tmp8 *RoundingMode; RoundingMode_Init(); tmp8 = RoundingMode_HALF_UP; tmp6 = tmp7 == tmp8; if !tmp6 {
									var tmp9 bool; var tmp10 bool; var tmp11 *RoundingMode = t.F_roundingMode; var tmp12 *RoundingMode; RoundingMode_Init(); tmp12 = RoundingMode_HALF_EVEN; tmp10 = tmp11 == tmp12; if tmp10 {
										tmp10 = maximumDigits > 0 }
//line :163:1
									tmp9 = tmp10; if tmp9 {

										tmp9 = !(int32(t.F_digits.A[maximumDigits-1])%2 == 0) }
//line :163:1
									tmp6 = tmp9 }
//line :162:1
								tmp5 = tmp6; return tmp5 } else {








									return !alreadyRounded } } else {
										return t.NonZeroAfterIndex_I__Z(maximumDigits + 1) } } }
//line :158:1
		case 7:















			if t.NonZeroAfterIndex_I__Z(maximumDigits) {
				panic(Thrown(ArithmeticException_New_String(Lit_1844))) }; default:


			if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New())) }} }
//line :148:1
	return false
}































func (t *DigitList) RoundUp_I__I(maximumDigits int32) int32 {
L1: for {
	maximumDigits = maximumDigits - 1
	if maximumDigits < 0 {
		t.F_digits.A[0] = 49
		t.F_decimalAt = t.F_decimalAt + 1
		maximumDigits = 0
		break L1 }
	var tmp1 *ByteArray = t.F_digits; tmp1.A[maximumDigits] = int8(int32(t.F_digits.A[maximumDigits]) + 1)
	if int32(t.F_digits.A[maximumDigits]) > 57 { continue L1 }
//line :182:1
	break L1
}







	maximumDigits = maximumDigits + 1; return maximumDigits
}
func (t *DigitList) Set_Z_J__V(isNegative bool, source int64) {
	t.Set_Z_J_I__V(isNegative, source, 0)
}
func (t *DigitList) Set_Z_J_I__V(isNegative bool, source int64, maximumDigits int32) {
	t.F_isNegative = isNegative
	if source <= 0 {
		if source == -9223372036854775808 {

			var tmp1 int32; var tmp2 int32 = 19; t.F_count = tmp2; tmp1 = tmp2; t.F_decimalAt = tmp1
			System_Arraycopy_O_I_O_I_I__V(DigitList_LONG_MIN_REP.Ref(), 0, t.F_digits.Ref(), 0, t.F_count) } else {
				var tmp3 int32; var tmp4 int32 = 0; t.F_count = tmp4; tmp3 = tmp4; t.F_decimalAt = tmp3 } } else {
					var left int32 = 19
					var right int32 = 0
				L1: for { if source > 0 {
					var tmp5 *ByteArray = t.F_digits; var tmp6 int32
					left = left - 1; tmp6 = left
//line :207:1
					tmp5.A[tmp6] = int8(48 + source%10)


					source = source / 10
//line :206:1
					continue L1 }; break L1
				}



					t.F_decimalAt = 19 - left
					right = 18
				L2: for { if int32(t.F_digits.A[right]) == 48 { right = right - 1; continue L2 }; break L2 }
					t.F_count = right - left + 1
					System_Arraycopy_O_I_O_I_I__V(t.F_digits.Ref(), left, t.F_digits.Ref(), 0, t.F_count) }
	if maximumDigits > 0 { t.RoundInt_I__V(maximumDigits)
	} }
func (t *DigitList) Set_Z_BigDecimal_I_Z__V(isNegative bool, source *BigDecimal, maximumDigits int32, fixedPoint bool) {

	var s *String = NN(NN(source).UnscaledValue__BigInteger()).ToString__String(); var len_ int32 = NN(s).Length__I()

	t.ExtendDigits_I__V(len_)
	NN(s).GetBytes_I_I_B1_I__V(0, len_, t.F_digits, 0)
	t.F_count = len_
	t.Set_Z_I_Z_Z_I_Z__V(isNegative, -NN(source).Scale__I(), false, true, maximumDigits, fixedPoint)
}






func (t *DigitList) Set_Z_BigInteger_I__V(isNegative bool, source *BigInteger, maximumDigits int32) {
	t.F_isNegative = isNegative
	var s *String = NN(source).ToString__String(); var len_ int32 = NN(s).Length__I()

	t.ExtendDigits_I__V(len_)
	NN(s).GetBytes_I_I_B1_I__V(0, len_, t.F_digits, 0)
	t.F_decimalAt = len_
	var right int32 = len_ - 1
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = right >= 0; if tmp2 { tmp2 = int32(t.F_digits.A[right]) == 48 }; tmp1 = tmp2; if tmp1 {
	right = right - 1
//line :241:1
	continue L1 }; break L1
}
	t.F_count = right + 1
	if maximumDigits > 0 { t.RoundInt_I__V(maximumDigits)
	} }
func (t *DigitList) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if DigitList_InstanceOf(tmp1) { var other *DigitList = DigitList_Cast(tmp1); var tmp2 bool; var tmp3 bool; var tmp4 int32 = t.F_count
			tmp3 = !(tmp4 == other.F_count); if !tmp3 { var tmp5 int32 = t.F_decimalAt; tmp3 = !(tmp5 == other.F_decimalAt) }; tmp2 = tmp3; if tmp2 { return false } else {


				var i int32 = 0; L1: for {
					if i < t.F_count {
						var tmp6 int32 = int32(t.F_digits.A[i]); if !(tmp6 == int32(other.F_digits.A[i])) {
							return false } else {
								i = i + 1; continue L1 } }
//line :253:1
					break L1 }
//line :252:1
				return true
			}


		} else {
//line :249:1
			return false
		}
	}
}









func (t *DigitList) HashCode__I() int32 {
	var hashcode int32 = t.F_decimalAt; var i int32 = 0
L1: for {
	if i < t.F_count {
		hashcode = hashcode*37 + int32(t.F_digits.A[i])
		i = i + 1; continue L1 }
//line :264:1
	break L1 }
//line :263:1
	return hashcode
}





func (t *DigitList) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var other *DigitList = DigitList_Cast(A2g_ObjectClone(t)); other.F_digits = NN(t.F_digits).Copy(); tmp1 = other.Ref() }; return nil }()
//line :271:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :271:1
			panic(tmp2) } }; return tmp1
}





func (t *DigitList) ToString__String() *String {
	if t.IsZero__Z() { return Lit_1133 } else {

		return Concat(Lit_1237, String_New_B1_I_I_Charset(t.F_digits, 0, t.F_count, StandardCharsets_ISO_8859_1), Lit_1845, StrOfInt(t.F_decimalAt))
	} }
func (t *DigitList) ExtendDigits_I__V(len_ int32) {
	if len_ > int32(len(t.F_digits.A)) { t.F_digits = NewByteArray(len_)
	}
}

type DigitList struct{ Object; F_decimalAt, F_count int32; F_digits *ByteArray; F_roundingMode *RoundingMode; F_isNegative bool }

func (t *DigitList) Is_Cloneable() {}

const DigitList_MAX_COUNT int32 = 19

var DigitList_COMPAT bool

var DigitList_LONG_MIN_REP *ByteArray

var DigitList_init ClassInit

func DigitList_Init() { if !DigitList_init.Done() { DigitList_init.Run(DigitList_clinit) } }

func DigitList_clinit() { DigitList_COMPAT = Boolean_GetBoolean_String__Z(Lit_1840); DigitList_LONG_MIN_REP = Lit_1841.GetBytes_Charset__B1(StandardCharsets_ISO_8859_1) }

func DigitList_New() *DigitList { DigitList_Init(); t := &DigitList{}; t.Ctor(); return t }

func (t *DigitList) Ctor() { t.F_decimalAt = 0; t.F_count = 0; t.F_digits = NewByteArray(19); var tmp1 *RoundingMode; RoundingMode_Init(); tmp1 = RoundingMode_HALF_EVEN; t.F_roundingMode = tmp1; t.F_isNegative = false }

func (t *DigitList) Ref() any { if t == nil { return nil }; return t }

func (t *DigitList) GetClass__Class() *Class { return DigitList_class }

func (t *DigitList) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func DigitList_InstanceOf(x any) bool { _, ok := x.(*DigitList); return ok }

func DigitList_Cast(x any) *DigitList { if x == nil { return nil }; v, ok := x.(*DigitList); if !ok { panic(ClassCast(x, DigitList_class)) }; return v }
