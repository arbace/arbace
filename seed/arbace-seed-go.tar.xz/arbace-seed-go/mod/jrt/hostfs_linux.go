//line hostfs_linux.ae:1
//go:build linux

package jrt

import (
	"errors"
	"io/fs"
	"os"
	"path/filepath"
	"syscall"
	"time"
)
//line :11:1
func (h OSHost) Access(name string, mode uint32) error {
	return syscall.Access(name, mode)
}
func (h OSHost) Chmod(name string, mode uint32) error {
	return syscall.Chmod(name, mode)
}
func (h OSHost) Chtimes(name string, mtimeMillis int64) error {

	return os.Chtimes(name, time.Time{}, time.UnixMilli(mtimeMillis))
}
func (h OSHost) Realpath(name string) (string, error) {
	abs, err := filepath.Abs(name)
	if err != nil {
		return "", err }
	r, err2 := filepath.EvalSymlinks(abs)
	if err2 != nil {
		if errors.Is(err2, syscall.ENOTDIR) || errors.Is(err2, syscall.ENOENT) {
			return "", fs.ErrNotExist }
		if errors.Is(err2, syscall.EACCES) {
			return "", fs.ErrPermission }
		return "", err2 }
	return r, nil
}
func (h OSHost) Statfs(name string) (HostFSInfo, error) {
	var st syscall.Statfs_t = syscall.Statfs_t{}
	err := syscall.Statfs(name, &st)
	if err != nil {
		return HostFSInfo{}, err }
	bs := int64(st.Frsize)
	if bs == 0 {
					bs = int64(st.Bsize) }
	return HostFSInfo{Total: bs * int64(st.Blocks),
					Free:    bs * int64(st.Bfree),
					Usable:  bs * int64(st.Bavail),
					NameMax: int64(st.Namelen),
	}, nil
}
