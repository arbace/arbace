//line java_text_RuleBasedCollationKey.ae:1
package jrt






func (t *RuleBasedCollationKey) CompareTo_CollationKey__I(target CollationKey_I) int32 {
	var tmp1 *String = t.F_key; var result int32 = NN(tmp1).CompareTo_String__I(RuleBasedCollationKey_Cast(target).F_key)
	if result <= -1 { return -1 } else { if result >= 1 { return 1 } else { return 0
	}
	}
}

func (t *RuleBasedCollationKey) Equals_O__Z(target any) bool {
	if any(t) == any(target) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = target == nil; if !tmp2 { tmp2 = !NN(t.GetClass__Class()).Equals_O__Z(GetClass(target).Ref()) }; tmp1 = tmp2
//line :16:1
		if tmp1 { return false } else {


			var other *RuleBasedCollationKey = RuleBasedCollationKey_Cast(target); var tmp3 *String = t.F_key; return NN(tmp3).Equals_O__Z(other.F_key.Ref())
		} } }
func (t *RuleBasedCollationKey) HashCode__I() int32 { return NN(t.F_key).HashCode__I() }

func (t *RuleBasedCollationKey) ToByteArray__B1() *ByteArray {
	var src *CharArray = NN(t.F_key).ToCharArray__C1(); var dest *ByteArray = NewByteArray(2 * int32(len(src.A)))
	var j int32 = 0
	var i int32 = 0
L1: for {
	if i < int32(len(src.A)) {
		dest.A[j] = int8(int32(uint32(int32(src.A[i])) >> 8))
		j = j + 1
		dest.A[j] = int8(int32(src.A[i]) & 255)
		j = j + 1
		i = i + 1; continue L1 }
//line :27:1
	break L1 }
//line :24:1
	return dest
}










func RuleBasedCollationKey_New_String_String(p0, p1 *String) *RuleBasedCollationKey { t := &RuleBasedCollationKey{}; t.Ctor_String_String(p0, p1); return t }
//line :36:1
func (t *RuleBasedCollationKey) Ctor_String_String(source, key *String) { t.CollationKey.Ctor_String(t, source); t.F_key = nil

	t.F_key = key
}


type RuleBasedCollationKey struct{ CollationKey; F_key *String }

func (t *RuleBasedCollationKey) CompareTo_O__I(p0 any) int32 { return t.CompareTo_CollationKey__I(CollationKey_Cast(p0)) }

func (t *RuleBasedCollationKey) GetSourceString__String() *String { return t.Impl_GetSourceString__String(t) }

func (t *RuleBasedCollationKey) Ref() any { if t == nil { return nil }; return t }

func (t *RuleBasedCollationKey) GetClass__Class() *Class { return RuleBasedCollationKey_class }

func (t *RuleBasedCollationKey) ToString__String() *String { return Object_toString(t) }

func (t *RuleBasedCollationKey) Clone__O() any { return A2g_ObjectClone(t) }

func (t *RuleBasedCollationKey) CloneShallow() any { panic(CloneNotSupported(t)) }

func RuleBasedCollationKey_InstanceOf(x any) bool { _, ok := x.(*RuleBasedCollationKey); return ok }

func RuleBasedCollationKey_Cast(x any) *RuleBasedCollationKey { if x == nil { return nil }; v, ok := x.(*RuleBasedCollationKey); if !ok { panic(ClassCast(x, RuleBasedCollationKey_class)) }; return v }
