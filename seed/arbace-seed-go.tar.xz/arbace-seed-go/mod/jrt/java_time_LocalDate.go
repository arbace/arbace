//line java_time_LocalDate.ae:1
package jrt



























































func LocalDate_Now__LocalDate() *LocalDate { LocalDate_Init()
	return LocalDate_Now_Clock__LocalDate(Clock_SystemDefaultZone__Clock())
}
func LocalDate_Now_ZoneId__LocalDate(zone ZoneId_I) *LocalDate { LocalDate_Init()
	return LocalDate_Now_Clock__LocalDate(Clock_System_ZoneId__Clock(zone))
}
func LocalDate_Now_Clock__LocalDate(clock Clock_I) *LocalDate { LocalDate_Init()
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	var now *Instant = clock.Instant__Instant(); return LocalDate_OfInstant_Instant_ZoneId__LocalDate(now, clock.GetZone__ZoneId())
}
func LocalDate_Of_I_Month_I__LocalDate(year int32, month *Month, dayOfMonth int32) *LocalDate { LocalDate_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(year))
	Objects_RequireNonNull_O_String__O(month.Ref(), Lit_1781)
	var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_DAY_OF_MONTH; NN(tmp2).CheckValidValue_J__J(int64(dayOfMonth))
	return LocalDate_Create_I_I_I__LocalDate(year, NN(month).GetValue__I(), dayOfMonth)
}
func LocalDate_Of_I_I_I__LocalDate(year, month, dayOfMonth int32) *LocalDate { LocalDate_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(year))
	var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; NN(tmp2).CheckValidValue_J__J(int64(month))
	var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_DAY_OF_MONTH; NN(tmp3).CheckValidValue_J__J(int64(dayOfMonth))
	return LocalDate_Create_I_I_I__LocalDate(year, month, dayOfMonth)
}
func LocalDate_OfYearDay_I_I__LocalDate(year, dayOfYear int32) *LocalDate { LocalDate_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(year))
	var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_DAY_OF_YEAR; NN(tmp2).CheckValidValue_J__J(int64(dayOfYear))
	var leap bool; var tmp3 *IsoChronology; IsoChronology_Init(); tmp3 = IsoChronology_INSTANCE; leap = NN(tmp3).IsLeapYear_J__Z(int64(year))
	var tmp4 bool; var tmp5 bool; tmp5 = dayOfYear == 366; if tmp5 { tmp5 = leap == false }; tmp4 = tmp5; if tmp4 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2037, StrOfInt(year), Lit_2038))))
	}
	var moy *Month = Month_Of_I__Month((dayOfYear-1)/31 + 1); var monthEnd int32 = NN(moy).FirstDayOfYear_Z__I(leap) + NN(moy).Length_Z__I(leap) - 1





	if dayOfYear > monthEnd { moy = NN(moy).Plus_J__Month(1) }
	var dom int32 = dayOfYear - NN(moy).FirstDayOfYear_Z__I(leap) + 1

	return LocalDate_New_I_I_I(year, NN(moy).GetValue__I(), dom)
}
func LocalDate_OfInstant_Instant_ZoneId__LocalDate(instant *Instant, zone ZoneId_I) *LocalDate { LocalDate_Init()
	Objects_RequireNonNull_O_String__O(instant.Ref(), Lit_2039)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var rules *ZoneRules = zone.GetRules__ZoneRules(); var offset *ZoneOffset = NN(rules).GetOffset_Instant__ZoneOffset(instant); var localSecond int64 = NN(instant).GetEpochSecond__J() + int64(NN(offset).GetTotalSeconds__I()); var localEpochDay int64 = Math_FloorDiv_J_I__J(localSecond, 86400)



	return LocalDate_OfEpochDay_J__LocalDate(localEpochDay)
}
func LocalDate_OfEpochDay_J__LocalDate(epochDay int64) *LocalDate { LocalDate_Init()
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; NN(tmp1).CheckValidValue_J__J(epochDay)
	var zeroDay int64 = epochDay + 719528
	zeroDay = zeroDay - 60
	var adjust int64 = 0
	if zeroDay < 0 {
		var adjustCycles int64 = (zeroDay+1)/146097 - 1


		adjust = adjustCycles * 400
		zeroDay = zeroDay + -adjustCycles*146097
	}


	var yearEst int64 = (400*zeroDay + 591) / 146097; var tmp2 int64 = 365*yearEst + yearEst/4; var tmp3 int64 = tmp2 - yearEst/100; var doyEst int64 = zeroDay - (tmp3 + yearEst/400)











	if doyEst < 0 {
		yearEst = yearEst - 1
		var tmp4 int64 = 365*yearEst + yearEst/4; var tmp5 int64 = tmp4 - yearEst/100; doyEst = zeroDay - (tmp5 + yearEst/400)
	}







	yearEst = yearEst + adjust
	var marchDoy0 int32 = int32(doyEst); var marchMonth0 int32 = (marchDoy0*5 + 2) / 153; var month int32 = marchMonth0 + 3




	if month > 12 { month = month - 12 }
	var dom int32 = marchDoy0 - (marchMonth0*306+5)/10 + 1







	if marchDoy0 >= 306 { yearEst = yearEst + 1 }
	return LocalDate_New_I_I_I(int32(yearEst), month, dom)
}
func LocalDate_From_TemporalAccessor__LocalDate(temporal TemporalAccessor) *LocalDate { LocalDate_Init()
	Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
	var date *LocalDate = LocalDate_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_LocalDate__TemporalQuery()))
	if date == nil {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2040, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String())))) }
//line :167:1
	return date
}







func LocalDate_Parse_CharSequence__LocalDate(text CharSequence) *LocalDate { LocalDate_Init()
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_LOCAL_DATE; return LocalDate_Parse_CharSequence_DateTimeFormatter__LocalDate(text, tmp1)
}
func LocalDate_Parse_CharSequence_DateTimeFormatter__LocalDate(text CharSequence, formatter *DateTimeFormatter) *LocalDate { LocalDate_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return LocalDate_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return LocalDate_From_TemporalAccessor__LocalDate(p0).Ref() }}))
}



func LocalDate_Create_I_I_I__LocalDate(year, month, dayOfMonth int32) *LocalDate { LocalDate_Init()
	if dayOfMonth > 28 {
		var dom int32; switch month { case 2:
			var tmp1 *IsoChronology; IsoChronology_Init(); tmp1 = IsoChronology_INSTANCE; if NN(tmp1).IsLeapYear_J__Z(int64(year)) { dom = 29 } else { dom = 28 }; case 4, 6, 9, 11:
//line :188:1
			dom = 30
		default:
//line :188:1
			dom = 31
		}


		if dayOfMonth > dom {
			if dayOfMonth == 29 {
				panic(Thrown(DateTimeException_New_String(Concat(Lit_2042, StrOfInt(year), Lit_2038)))) } else {

					panic(Thrown(DateTimeException_New_String(Concat(Lit_2043, NN(Month_Of_I__Month(month)).Name__String(), Lit_115, StrOfInt(dayOfMonth), Lit_1371))))
				} } }
	return LocalDate_New_I_I_I(year, month, dayOfMonth)
}
func LocalDate_ResolvePreviousValid_I_I_I__LocalDate(year, month, day int32) *LocalDate { LocalDate_Init()

	switch month { case 2:
		var tmp1 int32 = day; var tmp2 int32; var tmp3 *IsoChronology; IsoChronology_Init(); tmp3 = IsoChronology_INSTANCE; if NN(tmp3).IsLeapYear_J__Z(int64(year)) { tmp2 = 29 } else { tmp2 = 28 }; day = Math_Min_I_I__I(tmp1, tmp2); case 4, 6, 9, 11:
		day = Math_Min_I_I__I(day, 30); default:}
	return LocalDate_New_I_I_I(year, month, day)
}
func LocalDate_New_I_I_I(p0, p1, p2 int32) *LocalDate { LocalDate_Init(); t := &LocalDate{}; t.Ctor_I_I_I(p0, p1, p2); return t }
//line :207:1
func (t *LocalDate) Ctor_I_I_I(year, month, dayOfMonth int32) {
	t.F_year = year
	t.F_month = int8(month)
	t.F_day = int8(dayOfMonth)
}
func (t *LocalDate) IsSupported_TemporalField__Z(field TemporalField) bool {
	return ChronoLocalDate_IsSupported_TemporalField__Z(t, field)
}
func (t *LocalDate) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	return ChronoLocalDate_IsSupported_TemporalUnit__Z(t, unit)
}
func (t *LocalDate) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)
		if NN(chronoField).IsDateBased__Z() {
			var tmp2 *ValueRange; switch NN(chronoField).F_ordinal { case 18:
				tmp2 = ValueRange_Of_J_J__ValueRange(1, int64(t.LengthOfMonth__I())); case 19:
				tmp2 = ValueRange_Of_J_J__ValueRange(1, int64(t.LengthOfYear__I())); case 21:

				var tmp3 int64; var tmp4 bool; var tmp5 bool; var tmp6 *Month = t.GetMonth__Month(); var tmp7 *Month
				Month_Init(); tmp7 = Month_FEBRUARY; tmp5 = tmp6 == tmp7; if tmp5 {
					tmp5 = !t.IsLeapYear__Z() }
//line :226:1
				tmp4 = tmp5; if tmp4 { tmp3 = 4 } else { tmp3 = 5 }
//line :225:1
				tmp2 = ValueRange_Of_J_J__ValueRange(1, tmp3)

			case 25:



				if t.GetYear__I() <= 0 {
					tmp2 = ValueRange_Of_J_J__ValueRange(1, 1000000000) } else {
						tmp2 = ValueRange_Of_J_J__ValueRange(1, 999999999) }; default:
				tmp2 = field.Range__ValueRange()}
//line :221:1
			return tmp2
		}












		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) } else { }
	return field.RangeRefinedBy_TemporalAccessor__ValueRange(t)
}
func (t *LocalDate) Get_TemporalField__I(field TemporalField) int32 {
	if ChronoField_InstanceOf(field) { return t.Get0_TemporalField__I(field) } else { return TemporalAccessor_Get_TemporalField__I(t, field)
	} }
func (t *LocalDate) GetLong_TemporalField__J(field TemporalField) int64 {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; if any(field) == any(tmp1.Ref()) {
			return t.ToEpochDay__J() } else {
//line :243:1
				var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_PROLEPTIC_MONTH; if any(field) == any(tmp2.Ref()) {

					return t.GetProlepticMonth__J() } else {
//line :243:1
						return int64(t.Get0_TemporalField__I(field)) } } } else {



							return field.GetFrom_TemporalAccessor__J(t)
						} }
func (t *LocalDate) Get0_TemporalField__I(field TemporalField) int32 {
	switch NN(ChronoField_Cast(field)).F_ordinal { case 15:
		return NN(t.GetDayOfWeek__DayOfWeek()).GetValue__I(); case 16:

		return (int32(t.F_day)-1)%7 + 1; case 17:

		return (t.GetDayOfYear__I()-1)%7 + 1; case 18:


		return int32(t.F_day); case 19:
		return t.GetDayOfYear__I(); case 20:

		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2044))); case 21:


		return (int32(t.F_day)-1)/7 + 1; case 22:

		return (t.GetDayOfYear__I()-1)/7 + 1; case 23:

		return int32(t.F_month); case 24:

		panic(Thrown(UnsupportedTemporalTypeException_New_String(Lit_2045))); case 25:

		if t.F_year >= 1 { return t.F_year } else { return 1 - t.F_year }; case 26:
//line :250:1
		return t.F_year





















	case 27:

		if t.F_year >= 1 { return 1 } else { return 0 }; default:
		panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))}; panic("a2g: unreachable")
}
func (t *LocalDate) GetProlepticMonth__J() int64 {
	return int64(t.F_year)*12 + int64(t.F_month) - 1
}
func (t *LocalDate) GetChronology__IsoChronology() *IsoChronology { IsoChronology_Init(); return IsoChronology_INSTANCE }


func (t *LocalDate) GetEra__IsoEra() *IsoEra {
	if t.GetYear__I() >= 1 { IsoEra_Init(); return IsoEra_CE } else { IsoEra_Init(); return IsoEra_BCE
	} }
func (t *LocalDate) GetYear__I() int32 { return t.F_year }

func (t *LocalDate) GetMonthValue__I() int32 { return int32(t.F_month) }

func (t *LocalDate) GetMonth__Month() *Month { return Month_Of_I__Month(int32(t.F_month)) }

func (t *LocalDate) GetDayOfMonth__I() int32 { return int32(t.F_day) }

func (t *LocalDate) GetDayOfYear__I() int32 {
	return NN(t.GetMonth__Month()).FirstDayOfYear_Z__I(t.IsLeapYear__Z()) + int32(t.F_day) - 1
}


func (t *LocalDate) GetDayOfWeek__DayOfWeek() *DayOfWeek {
	var dow0 int32 = Math_FloorMod_J_I__I(t.ToEpochDay__J()+3, 7)
	return DayOfWeek_Of_I__DayOfWeek(dow0 + 1)
}
func (t *LocalDate) IsLeapYear__Z() bool {
	var tmp1 *IsoChronology; IsoChronology_Init(); tmp1 = IsoChronology_INSTANCE; return NN(tmp1).IsLeapYear_J__Z(int64(t.F_year))
}
func (t *LocalDate) LengthOfMonth__I() int32 {
	switch int32(t.F_month) { case 2: if t.IsLeapYear__Z() { return 29 } else { return 28 }; case 4, 6, 9, 11: return 30; default: return 31}; panic("a2g: unreachable")
}
func (t *LocalDate) LengthOfYear__I() int32 {
	if t.IsLeapYear__Z() { return 366 } else { return 365
	} }
func (t *LocalDate) With_TemporalAdjuster__LocalDate(adjuster TemporalAdjuster) *LocalDate {
	if LocalDate_InstanceOf(adjuster) {
		return LocalDate_Cast(adjuster) } else {
			return LocalDate_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
		} }
func (t *LocalDate) With_TemporalField_J__LocalDate(field TemporalField, newValue int64) *LocalDate {
	{ var tmp1 TemporalField = field; if ChronoField_InstanceOf(tmp1) { var chronoField *ChronoField = ChronoField_Cast(tmp1)

		NN(chronoField).CheckValidValue_J__J(newValue)
		switch NN(chronoField).F_ordinal { case 15:

			return t.PlusDays_J__LocalDate(newValue - int64(NN(t.GetDayOfWeek__DayOfWeek()).GetValue__I())); case 16:

			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_MONTH; return t.PlusDays_J__LocalDate(newValue - t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2))); case 17:



			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_ALIGNED_DAY_OF_WEEK_IN_YEAR; return t.PlusDays_J__LocalDate(newValue - t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3))); case 18:


			return t.WithDayOfMonth_I__LocalDate(int32(newValue)); case 19:
			return t.WithDayOfYear_I__LocalDate(int32(newValue)); case 20:
			return LocalDate_OfEpochDay_J__LocalDate(newValue); case 21:

			var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ALIGNED_WEEK_OF_MONTH; return t.PlusWeeks_J__LocalDate(newValue - t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4))); case 22:



			var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_ALIGNED_WEEK_OF_YEAR; return t.PlusWeeks_J__LocalDate(newValue - t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp5))); case 23:


			return t.WithMonth_I__LocalDate(int32(newValue)); case 24:
			return t.PlusMonths_J__LocalDate(newValue - t.GetProlepticMonth__J()); case 25:

			var tmp6 int64
			if t.F_year >= 1 { tmp6 = newValue } else { tmp6 = 1 - newValue }
//line :346:1
			return t.WithYear_I__LocalDate(int32(tmp6))
		case 26:
			return t.WithYear_I__LocalDate(int32(newValue)); case 27:

			var tmp7 *ChronoField; ChronoField_Init(); tmp7 = ChronoField_ERA; if t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp7)) == newValue { return t } else {

				return t.WithYear_I__LocalDate(1 - t.F_year) }; default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field)))))} } else {
				return LocalDate_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue)) } }; panic("a2g: unreachable")
}
func (t *LocalDate) WithYear_I__LocalDate(year int32) *LocalDate {
	if t.F_year == year { return t } else {


		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(year))
		return LocalDate_ResolvePreviousValid_I_I_I__LocalDate(year, int32(t.F_month), int32(t.F_day))
	} }
func (t *LocalDate) WithMonth_I__LocalDate(month int32) *LocalDate {
	if int32(t.F_month) == month { return t } else {


		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_MONTH_OF_YEAR; NN(tmp1).CheckValidValue_J__J(int64(month))
		return LocalDate_ResolvePreviousValid_I_I_I__LocalDate(t.F_year, month, int32(t.F_day))
	} }
func (t *LocalDate) WithDayOfMonth_I__LocalDate(dayOfMonth int32) *LocalDate {
	if int32(t.F_day) == dayOfMonth { return t } else { return LocalDate_Of_I_I_I__LocalDate(t.F_year, int32(t.F_month), dayOfMonth)
	} }
func (t *LocalDate) WithDayOfYear_I__LocalDate(dayOfYear int32) *LocalDate {
	if t.GetDayOfYear__I() == dayOfYear { return t } else { return LocalDate_OfYearDay_I_I__LocalDate(t.F_year, dayOfYear)
	} }
func (t *LocalDate) Plus_TemporalAmount__LocalDate(amountToAdd TemporalAmount) *LocalDate {
	var tmp1 TemporalAmount = amountToAdd; if Period_InstanceOf(tmp1) { var periodToAdd *Period = Period_Cast(tmp1)
		return NN(t.PlusMonths_J__LocalDate(NN(periodToAdd).ToTotalMonths__J())).PlusDays_J__LocalDate(int64(NN(periodToAdd).GetDays__I())) } else {

			Objects_RequireNonNull_O_String__O(amountToAdd, Lit_2046)
			return LocalDate_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
		} }
func (t *LocalDate) Plus_J_TemporalUnit__LocalDate(amountToAdd int64, unit TemporalUnit) *LocalDate {
	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 7:
			return t.PlusDays_J__LocalDate(amountToAdd); case 8:
			return t.PlusWeeks_J__LocalDate(amountToAdd); case 9:
			return t.PlusMonths_J__LocalDate(amountToAdd); case 10:
			return t.PlusYears_J__LocalDate(amountToAdd); case 11:
			return t.PlusYears_J__LocalDate(Math_MultiplyExact_J_I__J(amountToAdd, 10)); case 12:
			return t.PlusYears_J__LocalDate(Math_MultiplyExact_J_I__J(amountToAdd, 100)); case 13:
			return t.PlusYears_J__LocalDate(Math_MultiplyExact_J_I__J(amountToAdd, 1000)); case 14:

			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 TemporalField = Up_ChronoField_TemporalField(tmp2); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return t.With_TemporalField_J__LocalDate(tmp3, Math_AddExact_J_J__J(t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)), amountToAdd)); default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
				return LocalDate_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd)) } }; panic("a2g: unreachable")
}
func (t *LocalDate) PlusYears_J__LocalDate(yearsToAdd int64) *LocalDate {
	if yearsToAdd == 0 { return t } else {

		var newYear int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; newYear = NN(tmp1).CheckValidIntValue_J__I(int64(t.F_year) + yearsToAdd)
		return LocalDate_ResolvePreviousValid_I_I_I__LocalDate(newYear, int32(t.F_month), int32(t.F_day))
	} }
func (t *LocalDate) PlusMonths_J__LocalDate(monthsToAdd int64) *LocalDate {
	if monthsToAdd == 0 { return t } else {

		var monthCount int64 = int64(t.F_year)*12 + int64(int32(t.F_month)-1); var calcMonths int64 = monthCount + monthsToAdd; var newYear int32; var tmp1 *ChronoField


		ChronoField_Init(); tmp1 = ChronoField_YEAR; var tmp2 *ChronoField = tmp1; newYear = NN(tmp2).CheckValidIntValue_J__I(Math_FloorDiv_J_I__J(calcMonths, 12))
//line :407:1
		var newMonth int32 = Math_FloorMod_J_I__I(calcMonths, 12) + 1





		return LocalDate_ResolvePreviousValid_I_I_I__LocalDate(newYear, newMonth, int32(t.F_day))
	} }
func (t *LocalDate) PlusWeeks_J__LocalDate(weeksToAdd int64) *LocalDate {
	return t.PlusDays_J__LocalDate(Math_MultiplyExact_J_I__J(weeksToAdd, 7))
}
func (t *LocalDate) PlusDays_J__LocalDate(daysToAdd int64) *LocalDate {
	if daysToAdd == 0 { return t } else {

		var dom int64 = int64(t.F_day) + daysToAdd
		if dom > 0 {
			if dom <= 28 {
				return LocalDate_New_I_I_I(t.F_year, int32(t.F_month), int32(dom)) } else {
//line :423:1
					if dom <= 59 {


						var monthLen int64 = int64(t.LengthOfMonth__I())
						if dom <= monthLen {
							return LocalDate_New_I_I_I(t.F_year, int32(t.F_month), int32(dom)) } else {
//line :427:1
								if int32(t.F_month) < 12 {


									return LocalDate_New_I_I_I(t.F_year, int32(t.F_month)+1, int32(dom-monthLen)) } else {




										var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR; NN(tmp1).CheckValidValue_J__J(int64(t.F_year + 1))
										return LocalDate_New_I_I_I(t.F_year+1, 1, int32(dom-monthLen))
									}
							} } } }
		var mjDay int64 = Math_AddExact_J_J__J(t.ToEpochDay__J(), daysToAdd); return LocalDate_OfEpochDay_J__LocalDate(mjDay)
	} }
func (t *LocalDate) Minus_TemporalAmount__LocalDate(amountToSubtract TemporalAmount) *LocalDate {
	var tmp1 TemporalAmount = amountToSubtract; if Period_InstanceOf(tmp1) { var periodToSubtract *Period = Period_Cast(tmp1)
		return NN(t.MinusMonths_J__LocalDate(NN(periodToSubtract).ToTotalMonths__J())).MinusDays_J__LocalDate(int64(NN(periodToSubtract).GetDays__I())) } else {

			Objects_RequireNonNull_O_String__O(amountToSubtract, Lit_2047)
			return LocalDate_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
		} }
func (t *LocalDate) Minus_J_TemporalUnit__LocalDate(amountToSubtract int64, unit TemporalUnit) *LocalDate {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__LocalDate(9223372036854775807, unit)).Plus_J_TemporalUnit__LocalDate(1, unit) } else {
			return t.Plus_J_TemporalUnit__LocalDate(-amountToSubtract, unit)
		} }
func (t *LocalDate) MinusYears_J__LocalDate(yearsToSubtract int64) *LocalDate {
	if yearsToSubtract == -9223372036854775808 {
		return NN(t.PlusYears_J__LocalDate(9223372036854775807)).PlusYears_J__LocalDate(1) } else {
			return t.PlusYears_J__LocalDate(-yearsToSubtract)
		} }
func (t *LocalDate) MinusMonths_J__LocalDate(monthsToSubtract int64) *LocalDate {
	if monthsToSubtract == -9223372036854775808 {
		return NN(t.PlusMonths_J__LocalDate(9223372036854775807)).PlusMonths_J__LocalDate(1) } else {
			return t.PlusMonths_J__LocalDate(-monthsToSubtract)
		} }
func (t *LocalDate) MinusWeeks_J__LocalDate(weeksToSubtract int64) *LocalDate {
	if weeksToSubtract == -9223372036854775808 {
		return NN(t.PlusWeeks_J__LocalDate(9223372036854775807)).PlusWeeks_J__LocalDate(1) } else {
			return t.PlusWeeks_J__LocalDate(-weeksToSubtract)
		} }
func (t *LocalDate) MinusDays_J__LocalDate(daysToSubtract int64) *LocalDate {
	if daysToSubtract == -9223372036854775808 {
		return NN(t.PlusDays_J__LocalDate(9223372036854775807)).PlusDays_J__LocalDate(1) } else {
			return t.PlusDays_J__LocalDate(-daysToSubtract)
		} }
func (t *LocalDate) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_LocalDate__TemporalQuery() { return t } else {

		return ChronoLocalDate_Query_TemporalQuery__O(t, query)
	} }
func (t *LocalDate) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	return ChronoLocalDate_AdjustInto_Temporal__Temporal(t, temporal)
}
func (t *LocalDate) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	{ var end *LocalDate = LocalDate_From_TemporalAccessor__LocalDate(endExclusive); var tmp1 TemporalUnit = unit
		if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
			switch NN(chronoUnit).F_ordinal { case 7:
				return t.DaysUntil_LocalDate__J(end); case 8:
				return t.DaysUntil_LocalDate__J(end) / 7; case 9:
				return t.MonthsUntil_LocalDate__J(end); case 10:
				return t.MonthsUntil_LocalDate__J(end) / 12; case 11:
				return t.MonthsUntil_LocalDate__J(end) / 120; case 12:
				return t.MonthsUntil_LocalDate__J(end) / 1200; case 13:
				return t.MonthsUntil_LocalDate__J(end) / 12000; case 14:
				var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 int64 = NN(end).GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2)); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return tmp3 - t.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)); default:
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
					return unit.Between_Temporal_Temporal__J(t, Up_LocalDate_Temporal(end)) } }; panic("a2g: unreachable")
}
func (t *LocalDate) DaysUntil_LocalDate__J(end *LocalDate) int64 {
	return NN(end).ToEpochDay__J() - t.ToEpochDay__J()
}
func (t *LocalDate) MonthsUntil_LocalDate__J(end *LocalDate) int64 {
	var packed1 int64 = t.GetProlepticMonth__J()*32 + int64(t.GetDayOfMonth__I()); var packed2 int64 = NN(end).GetProlepticMonth__J()*32 + int64(NN(end).GetDayOfMonth__I())



	return (packed2 - packed1) / 32
}
func (t *LocalDate) Until_ChronoLocalDate__Period(endDateExclusive ChronoLocalDate) *Period {
	var end *LocalDate = LocalDate_From_TemporalAccessor__LocalDate(endDateExclusive); var totalMonths int64 = NN(end).GetProlepticMonth__J() - t.GetProlepticMonth__J(); var days int32 = int32(end.F_day) - int32(t.F_day); var tmp1 bool; var tmp2 bool




	tmp2 = totalMonths > 0; if tmp2 { tmp2 = days < 0 }; tmp1 = tmp2; if tmp1 {

		totalMonths = totalMonths - 1
		var calcDate *LocalDate = t.PlusMonths_J__LocalDate(totalMonths)
		days = int32(NN(end).ToEpochDay__J() - NN(calcDate).ToEpochDay__J()) } else {

			var tmp3 bool; var tmp4 bool; tmp4 = totalMonths < 0; if tmp4 { tmp4 = days > 0 }; tmp3 = tmp4; if tmp3 {
				totalMonths = totalMonths + 1
				days = days - NN(end).LengthOfMonth__I() } }
	var years int64 = totalMonths / 12; var months int32 = int32(totalMonths % 12)

	return Period_Of_I_I_I__Period(Math_ToIntExact_J__I(years), months, days)
}
func (t *LocalDate) DatesUntil_LocalDate__Stream(endExclusive *LocalDate) Stream {
	var end int64 = NN(endExclusive).ToEpochDay__J(); var start int64 = t.ToEpochDay__J()

	if end < start { panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfObj(endExclusive.Ref()), Lit_2048, StrOfObj(t))))) }
	return LongStream_Range_J_J__LongStream(start, end).MapToObj_LongFunction__Stream(&LongFunction_Fn{Fn: func(p0 int64) any { return LocalDate_OfEpochDay_J__LocalDate(p0).Ref() }})
}

func (t *LocalDate) DatesUntil_LocalDate_Period__Stream(endExclusive *LocalDate, step *Period) Stream {
	if NN(step).IsZero__Z() { panic(Thrown(IllegalArgumentException_New_String(Lit_2049))) }
	var end int64 = NN(endExclusive).ToEpochDay__J(); var start int64 = t.ToEpochDay__J(); var until int64 = end - start; var months int64 = NN(step).ToTotalMonths__J(); var days int64 = int64(NN(step).GetDays__I()); var tmp1 bool; var tmp2 bool; var tmp3 bool




	tmp3 = months < 0; if tmp3 { tmp3 = days > 0 }; tmp2 = tmp3; if !tmp2 { var tmp4 bool; tmp4 = months > 0; if tmp4 { tmp4 = days < 0 }; tmp2 = tmp4 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2050))) }
	if until == 0 {
		return Stream_Empty__Stream() } else {
			var sign int32; var tmp5 bool; var tmp6 bool; tmp6 = months > 0; if !tmp6 { tmp6 = days > 0 }; tmp5 = tmp6; if tmp5 { sign = 1 } else { sign = -1 }
			if sign < 0 == (until < 0) { } else {
				var tmp7 *String
				if sign < 0 { tmp7 = Lit_1260 } else { tmp7 = Lit_2048 }
//line :545:1
				panic(Thrown(IllegalArgumentException_New_String(Concat(StrOfObj(endExclusive.Ref()), tmp7, StrOfObj(t)))))
			}
			if months == 0 {
				var steps int64 = (until - int64(sign)) / days
				return LongStream_RangeClosed_J_J__LongStream(0, steps).MapToObj_LongFunction__Stream(&LongFunction_Fn{Fn: func(p0 int64) any { var n int64 = p0; return LocalDate_OfEpochDay_J__LocalDate(start + n*days).Ref() }}) } else {



					var steps_2 int64 = until*1600/(months*48699+days*1600) + 1; var addMonths int64 = months * steps_2; var addDays int64 = days * steps_2; var maxAddMonths int64








					if months > 0 {
						maxAddMonths = NN(LocalDate_MAX).GetProlepticMonth__J() - t.GetProlepticMonth__J() } else {


							maxAddMonths = t.GetProlepticMonth__J() - NN(LocalDate_MIN).GetProlepticMonth__J()
						}

					var tmp8 bool; var tmp9 bool; tmp9 = addMonths*int64(sign) > maxAddMonths; if !tmp9 {
						tmp9 = (NN(t.PlusMonths_J__LocalDate(addMonths)).ToEpochDay__J()+addDays)*int64(sign) >= end*int64(sign) }
//line :569:1
					tmp8 = tmp9; if tmp8 {




						steps_2 = steps_2 - 1
						addMonths = addMonths - months
						addDays = addDays - days
						var tmp10 bool; var tmp11 bool; tmp11 = addMonths*int64(sign) > maxAddMonths; if !tmp11 {
							tmp11 = (NN(t.PlusMonths_J__LocalDate(addMonths)).ToEpochDay__J()+addDays)*int64(sign) >= end*int64(sign) }
//line :577:1
						tmp10 = tmp11; if tmp10 {






							steps_2 = steps_2 - 1 } }
					return LongStream_RangeClosed_J_J__LongStream(0, steps_2).MapToObj_LongFunction__Stream(&LongFunction_Fn{Fn: func(p0_2 int64) any { var n_2 int64 = p0_2; return NN(t.PlusMonths_J__LocalDate(months * n_2)).PlusDays_J__LocalDate(days * n_2).Ref() }})
				}
		}
}

func (t *LocalDate) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *LocalDate) AtTime_LocalTime__LocalDateTime(time *LocalTime) *LocalDateTime {
	return LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(t, time)
}
func (t *LocalDate) AtTime_I_I__LocalDateTime(hour, minute int32) *LocalDateTime {
	return t.AtTime_LocalTime__LocalDateTime(LocalTime_Of_I_I__LocalTime(hour, minute))
}
func (t *LocalDate) AtTime_I_I_I__LocalDateTime(hour, minute, second int32) *LocalDateTime {
	return t.AtTime_LocalTime__LocalDateTime(LocalTime_Of_I_I_I__LocalTime(hour, minute, second))
}
func (t *LocalDate) AtTime_I_I_I_I__LocalDateTime(hour, minute, second, nanoOfSecond int32) *LocalDateTime {
	return t.AtTime_LocalTime__LocalDateTime(LocalTime_Of_I_I_I_I__LocalTime(hour, minute, second, nanoOfSecond))
}
func (t *LocalDate) AtTime_OffsetTime__OffsetDateTime(time *OffsetTime) *OffsetDateTime {
	return OffsetDateTime_Of_LocalDateTime_ZoneOffset__OffsetDateTime(LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(t, NN(time).ToLocalTime__LocalTime()), NN(time).GetOffset__ZoneOffset())
}
func (t *LocalDate) AtStartOfDay__LocalDateTime() *LocalDateTime {
	var tmp1 *LocalTime; LocalTime_Init(); tmp1 = LocalTime_MIDNIGHT; return LocalDateTime_Of_LocalDate_LocalTime__LocalDateTime(t, tmp1)
}
func (t *LocalDate) AtStartOfDay_ZoneId__ZonedDateTime(zone ZoneId_I) *ZonedDateTime {
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var ldt *LocalDateTime; var tmp1 *LocalTime; LocalTime_Init(); tmp1 = LocalTime_MIDNIGHT; ldt = t.AtTime_LocalTime__LocalDateTime(tmp1)
	if ZoneOffset_InstanceOf(zone) { } else {
		var rules *ZoneRules = zone.GetRules__ZoneRules(); var trans *ZoneOffsetTransition = NN(rules).GetTransition_LocalDateTime__ZoneOffsetTransition(ldt); var tmp2 bool; var tmp3 bool

		tmp3 = !(trans == nil); if tmp3 { tmp3 = NN(trans).IsGap__Z() }; tmp2 = tmp3; if tmp2 { ldt = NN(trans).GetDateTimeAfter__LocalDateTime() } }
	return ZonedDateTime_Of_LocalDateTime_ZoneId__ZonedDateTime(ldt, zone)
}
func (t *LocalDate) ToEpochDay__J() int64 {
	var y int64 = int64(t.F_year); var m int64 = int64(t.F_month)
	var total int64 = 0

	total = total + 365*y
	if y >= 0 {
		var tmp1 int64 = (y + 3) / 4; var tmp2 int64 = tmp1 - (y+99)/100; total = total + (tmp2 + (y+399)/400) } else {






			var tmp3 int64 = y / -4; var tmp4 int64 = tmp3 - y/-100; total = total - (tmp4 + y/-400)
		}





	total = total + (367*m-362)/12



	total = total + int64(int32(t.F_day)-1)
	if m > 2 {
		total = total - 1
		if t.IsLeapYear__Z() == false { total = total - 1 } }
	return total - 719528
}
func (t *LocalDate) ToEpochSecond_LocalTime_ZoneOffset__J(time *LocalTime, offset *ZoneOffset) int64 {
	Objects_RequireNonNull_O_String__O(time.Ref(), Lit_2051)
	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	var secs int64 = t.ToEpochDay__J()*86400 + int64(NN(time).ToSecondOfDay__I())


	secs = secs - int64(NN(offset).GetTotalSeconds__I())
//line :654:1
	return secs
}




func (t *LocalDate) CompareTo_ChronoLocalDate__I(other ChronoLocalDate) int32 {
	if LocalDate_InstanceOf(other) {
		return t.CompareTo0_LocalDate__I(LocalDate_Cast(other)) } else {
			return ChronoLocalDate_CompareTo_ChronoLocalDate__I(t, other)
		} }
func (t *LocalDate) CompareTo0_LocalDate__I(otherDate *LocalDate) int32 {
	var tmp1 int32 = t.F_year; var cmp int32 = tmp1 - otherDate.F_year
	if cmp == 0 {
		var tmp2 int32 = int32(t.F_month); cmp = tmp2 - int32(otherDate.F_month)
		if cmp == 0 { var tmp3 int32 = int32(t.F_day); cmp = tmp3 - int32(otherDate.F_day) } }
//line :666:1
	return cmp
}




func (t *LocalDate) IsAfter_ChronoLocalDate__Z(other ChronoLocalDate) bool {
	if LocalDate_InstanceOf(other) {
		return t.CompareTo0_LocalDate__I(LocalDate_Cast(other)) > 0 } else {
			return ChronoLocalDate_IsAfter_ChronoLocalDate__Z(t, other)
		} }
func (t *LocalDate) IsBefore_ChronoLocalDate__Z(other ChronoLocalDate) bool {
	if LocalDate_InstanceOf(other) {
		return t.CompareTo0_LocalDate__I(LocalDate_Cast(other)) < 0 } else {
			return ChronoLocalDate_IsBefore_ChronoLocalDate__Z(t, other)
		} }
func (t *LocalDate) IsEqual_ChronoLocalDate__Z(other ChronoLocalDate) bool {
	if LocalDate_InstanceOf(other) {
		return t.CompareTo0_LocalDate__I(LocalDate_Cast(other)) == 0 } else {
			return ChronoLocalDate_IsEqual_ChronoLocalDate__Z(t, other)
		} }
func (t *LocalDate) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if LocalDate_InstanceOf(obj) {

		return t.CompareTo0_LocalDate__I(LocalDate_Cast(obj)) == 0 } else {
//line :688:1
			return false
		}
	}
}

func (t *LocalDate) HashCode__I() int32 {
	return t.F_year&-2048 ^ (t.F_year<<11 + int32(t.F_month)<<6 + int32(t.F_day))
}



func (t *LocalDate) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New_I(10); DateTimeHelper_FormatTo_StringBuilder_LocalDate__V(buf, t); return NN(buf).ToString__String()
}
func (t *LocalDate) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.LocalDate.writeReplace()Ljava/lang/Object;")) }









func LocalDate_ReadExternal_DataInput__LocalDate(p0 DataInput) *LocalDate { LocalDate_Init(); panic(A2g_NotTranslated("java.time.LocalDate.readExternal(Ljava/io/DataInput;)Ljava/time/LocalDate;")) }



type LocalDate struct{ Object; F_year int32; F_month, F_day int8 }

func (t *LocalDate) Is_Temporal() {}

func (t *LocalDate) Is_TemporalAdjuster() {}

func (t *LocalDate) Is_ChronoLocalDate() {}

func (t *LocalDate) Is_Serializable() {}

func (t *LocalDate) Is_TemporalAccessor() {}

func (t *LocalDate) Is_Comparable() {}

var LocalDate_MIN *LocalDate

var LocalDate_MAX *LocalDate

var LocalDate_EPOCH *LocalDate

const LocalDate_serialVersionUID int64 = 2942565459149668126

const LocalDate_DAYS_PER_CYCLE int32 = 146097

const LocalDate_DAYS_0000_TO_1970 int64 = 719528

var LocalDate_init ClassInit

func LocalDate_Init() { if !LocalDate_init.Done() { LocalDate_init.Run(LocalDate_clinit) } }

func LocalDate_clinit() { LocalDate_MIN = LocalDate_Of_I_I_I__LocalDate(-999999999, 1, 1); LocalDate_MAX = LocalDate_Of_I_I_I__LocalDate(999999999, 12, 31); LocalDate_EPOCH = LocalDate_Of_I_I_I__LocalDate(1970, 1, 1) }

func (t *LocalDate) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_LocalDate_Temporal(t.With_TemporalAdjuster__LocalDate(p0)) }

func (t *LocalDate) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_LocalDate_Temporal(t.With_TemporalField_J__LocalDate(p0, p1)) }

func (t *LocalDate) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_LocalDate_Temporal(t.Plus_TemporalAmount__LocalDate(p0)) }

func (t *LocalDate) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_LocalDate_Temporal(t.Plus_J_TemporalUnit__LocalDate(p0, p1)) }

func (t *LocalDate) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_LocalDate_Temporal(t.Minus_TemporalAmount__LocalDate(p0)) }

func (t *LocalDate) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_LocalDate_Temporal(t.Minus_J_TemporalUnit__LocalDate(p0, p1)) }

func (t *LocalDate) GetChronology__Chronology() Chronology { return Up_IsoChronology_Chronology(t.GetChronology__IsoChronology()) }

func (t *LocalDate) GetEra__Era() Era { return Up_IsoEra_Era(t.GetEra__IsoEra()) }

func (t *LocalDate) With_TemporalAdjuster__ChronoLocalDate(p0 TemporalAdjuster) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.With_TemporalAdjuster__LocalDate(p0)) }

func (t *LocalDate) With_TemporalField_J__ChronoLocalDate(p0 TemporalField, p1 int64) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.With_TemporalField_J__LocalDate(p0, p1)) }

func (t *LocalDate) Plus_TemporalAmount__ChronoLocalDate(p0 TemporalAmount) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.Plus_TemporalAmount__LocalDate(p0)) }

func (t *LocalDate) Plus_J_TemporalUnit__ChronoLocalDate(p0 int64, p1 TemporalUnit) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.Plus_J_TemporalUnit__LocalDate(p0, p1)) }

func (t *LocalDate) Minus_TemporalAmount__ChronoLocalDate(p0 TemporalAmount) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.Minus_TemporalAmount__LocalDate(p0)) }

func (t *LocalDate) Minus_J_TemporalUnit__ChronoLocalDate(p0 int64, p1 TemporalUnit) ChronoLocalDate { return Up_LocalDate_ChronoLocalDate(t.Minus_J_TemporalUnit__LocalDate(p0, p1)) }

func (t *LocalDate) Until_ChronoLocalDate__ChronoPeriod(p0 ChronoLocalDate) ChronoPeriod { return Up_Period_ChronoPeriod(t.Until_ChronoLocalDate__Period(p0)) }

func (t *LocalDate) AtTime_LocalTime__ChronoLocalDateTime(p0 *LocalTime) ChronoLocalDateTime { return Up_LocalDateTime_ChronoLocalDateTime(t.AtTime_LocalTime__LocalDateTime(p0)) }

func (t *LocalDate) CompareTo_O__I(p0 any) int32 { return t.CompareTo_ChronoLocalDate__I(ChronoLocalDate_Cast(p0)) }

func (t *LocalDate) Ref() any { if t == nil { return nil }; return t }

func (t *LocalDate) GetClass__Class() *Class { return LocalDate_class }

func (t *LocalDate) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LocalDate) CloneShallow() any { panic(CloneNotSupported(t)) }

func LocalDate_InstanceOf(x any) bool { _, ok := x.(*LocalDate); return ok }

func LocalDate_Cast(x any) *LocalDate { if x == nil { return nil }; v, ok := x.(*LocalDate); if !ok { panic(ClassCast(x, LocalDate_class)) }; return v }
