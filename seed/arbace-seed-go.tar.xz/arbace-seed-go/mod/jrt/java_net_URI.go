//line java_net_URI.ae:1
package jrt

import "sync/atomic"











func URI_Decode_String_Z__String(s *String, ignorePercentInBrackets bool) *String { URI_Init()
	if s == nil { return s } else {

		var n int32 = NN(s).Length__I()
		if n == 0 { return s } else { if NN(s).IndexOf_I__I(37) < 0 { return s } else {



			var sb *StringBuilder = StringBuilder_New_I(n); var bb *ByteArrayOutputStream = ByteArrayOutputStream_New_I(n); var c uint16 = NN(s).CharAt_I__C(0)
			var betweenBrackets bool = false
			var i int32 = 0


		L1: for { if i < n {
			if int32(c) == 91 {
				betweenBrackets = true } else {
//line :29:1
					var tmp1 bool; var tmp2 bool

					tmp2 = betweenBrackets; if tmp2 { tmp2 = int32(c) == 93 }; tmp1 = tmp2
//line :29:1
					if tmp1 {

						betweenBrackets = false } }
			var tmp3 bool; var tmp4 bool; tmp4 = !(int32(c) == 37); if !tmp4 { var tmp5 bool; tmp5 = betweenBrackets; if tmp5 { tmp5 = ignorePercentInBrackets }; tmp4 = tmp5 }; tmp3 = tmp4; if tmp3 {

				NN(sb).Append_C__StringBuilder(c)
				var tmp6 int32; i = i + 1; tmp6 = i; if tmp6 >= n { break L1 }
				c = NN(s).CharAt_I__C(i) } else {

					NN(bb).Reset__V()
				L2: for {
					var tmp7 int32; i = i + 1; tmp7 = i; var tmp8 uint16 = NN(s).CharAt_I__C(tmp7); var tmp9 int32
					i = i + 1; tmp9 = i
//line :40:1
					NN(bb).Write_I__V(int32(URI_Decode_C_C__B(tmp8, NN(s).CharAt_I__C(tmp9))))

					var tmp10 int32; i = i + 1; tmp10 = i; if tmp10 >= n { break L2 }
					c = NN(s).CharAt_I__C(i)
					if int32(c) == 37 { } else { break L2 }
//line :39:1
					continue L2
				}




					NN(sb).Append_String__StringBuilder(String_New_B1_Charset(NN(bb).ToByteArray__B1(), StandardCharsets_UTF_8)) }
//line :28:1
			continue L1 }; break L1
		}
















			return NN(sb).ToString__String()
		}
		}
	}
}






func URI_New() *URI { URI_Init(); t := &URI{}; t.Ctor(); return t }
//line :57:1
func (t *URI) Ctor() { t.F_port = -1 }

func URI_New_String(p0 *String) *URI { URI_Init(); t := &URI{}; t.Ctor_String(p0); return t }
//line :59:1
func (t *URI) Ctor_String(str *String) { t.F_port = -1
	URI_Parser_New_URI_String(t, str).Parse_Z__V(false)
}
func URI_New_String_String_String_I_String_String_String(p0, p1, p2 *String, p3 int32, p4, p5, p6 *String) *URI { URI_Init(); t := &URI{}; t.Ctor_String_String_String_I_String_String_String(p0, p1, p2, p3, p4, p5, p6); return t }
//line :62:1
func (t *URI) Ctor_String_String_String_I_String_String_String(scheme, userInfo, host *String, port int32, path, query, fragment *String) { t.F_port = -1


	var s *String = t.ToString_String_String_String_String_String_I_String_String_String__String(scheme, nil, nil, userInfo, host, port, path, query, fragment)
	URI_CheckPath_String_String_String__V(s, scheme, path)
	URI_Parser_New_URI_String(t, s).Parse_Z__V(true)
}
func URI_New_String_String_String_String_String(p0, p1, p2, p3, p4 *String) *URI { URI_Init(); t := &URI{}; t.Ctor_String_String_String_String_String(p0, p1, p2, p3, p4); return t }
//line :69:1
func (t *URI) Ctor_String_String_String_String_String(scheme, authority, path, query, fragment *String) { t.F_port = -1

	var s *String = t.ToString_String_String_String_String_String_I_String_String_String__String(scheme, nil, authority, nil, nil, -1, path, query, fragment)
	URI_CheckPath_String_String_String__V(s, scheme, path)
	URI_Parser_New_URI_String(t, s).Parse_Z__V(false)
}
func URI_New_String_String_String_String(p0, p1, p2, p3 *String) *URI { URI_Init(); t := &URI{}; t.Ctor_String_String_String_String(p0, p1, p2, p3); return t }
//line :75:1
func (t *URI) Ctor_String_String_String_String(scheme, host, path, fragment *String) { t.Ctor_String_String_String_I_String_String_String(scheme, nil, host, -1, path, nil, fragment) }



func URI_New_String_String_String(p0, p1, p2 *String) *URI { URI_Init(); t := &URI{}; t.Ctor_String_String_String(p0, p1, p2); return t }
//line :79:1
func (t *URI) Ctor_String_String_String(scheme, ssp, fragment *String) { t.F_port = -1

	URI_Parser_New_URI_String(t, t.ToString_String_String_String_String_String_I_String_String_String__String(scheme, ssp, nil, nil, nil, -1, nil, nil, fragment)).Parse_Z__V(false)
}
func URI_New_String_String(p0, p1 *String) *URI { URI_Init(); t := &URI{}; t.Ctor_String_String(p0, p1); return t }
//line :83:1
func (t *URI) Ctor_String_String(scheme, path *String) { panic(A2g_NotTranslated("java.net.URI.<init>(Ljava/lang/String;Ljava/lang/String;)V")) }




func URI_ValidSchemeAndPath_String_String__Z(p0, p1 *String) bool { URI_Init(); panic(A2g_NotTranslated("java.net.URI.validSchemeAndPath(Ljava/lang/String;Ljava/lang/String;)Z")) }





func URI_Create_String__URI(str *String) *URI { URI_Init()
	var tmp1 *URI; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = URI_New_String(str); return nil }()
//line :95:1
	if tmp2 != nil { if URISyntaxException_InstanceOf(tmp2) { var x *URISyntaxException = URISyntaxException_Cast(tmp2)

		panic(Thrown(IllegalArgumentException_New_String_Throwable(NN(x).GetMessage__String(), Up_URISyntaxException_Throwable(x)))) } else {
//line :95:1
			panic(tmp2) } }; return tmp1
}


func (t *URI) ParseServerAuthority__URI() *URI {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_host == nil); if !tmp2 { tmp2 = t.F_authority == nil }; tmp1 = tmp2; if tmp1 { return t } else { URI_Parser_New_URI_String(t, t.ToString__String()).Parse_Z__V(true); return t
	} }
func (t *URI) Normalize__URI() *URI { return URI_Normalize_URI__URI(t) }

func (t *URI) Resolve_URI__URI(uri *URI) *URI { return URI_Resolve_URI_URI__URI(t, uri) }

func (t *URI) Resolve_String__URI(str *String) *URI {
	return t.Resolve_URI__URI(URI_Create_String__URI(str))
}
func (t *URI) Relativize_URI__URI(uri *URI) *URI {
	return URI_Relativize_URI_URI__URI(t, uri)
}
func (t *URI) ToURL__URL() *URL {
	return URL_Of_URI_URLStreamHandler__URL(t, nil)
}
func (t *URI) GetScheme__String() *String { return t.F_scheme }

func (t *URI) IsAbsolute__Z() bool { return !(t.F_scheme == nil) }

func (t *URI) IsOpaque__Z() bool { return t.F_path == nil }

func (t *URI) GetRawSchemeSpecificPart__String() *String {
	var part *String = t.F_schemeSpecificPart
	if !(part == nil) { return part } else {

		var s *String = t.F_string.Load()
		if !(s == nil) {
			var start int32 = 0; var end int32 = NN(s).Length__I()

			if !(t.F_scheme == nil) { start = NN(t.F_scheme).Length__I() + 1 }
			if !(t.F_fragment == nil) {
				end = end - (NN(t.F_fragment).Length__I() + 1) }
			var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_path == nil); if tmp2 { tmp2 = NN(t.F_path).Length__I() == end-start }; tmp1 = tmp2; if tmp1 {
				part = t.F_path } else {
					part = NN(s).Substring_I_I__String(start, end) } } else {
						var sb *StringBuilder = StringBuilder_New(); var tmp3 *String = t.GetAuthority__String(); var tmp4 *String = t.GetUserInfo__String(); var tmp5 *String = t.F_host; var tmp6 int32 = t.F_port
						t.AppendSchemeSpecificPart_StringBuilder_String_String_String_String_I_String_String__V(sb, nil, tmp3, tmp4, tmp5, tmp6, t.GetPath__String(), t.GetQuery__String())








						part = NN(sb).ToString__String() }
		var tmp7 *String = part; t.F_schemeSpecificPart = tmp7; return tmp7
	} }
func (t *URI) GetSchemeSpecificPart__String() *String {
	var part *String = t.F_decodedSchemeSpecificPart
	if part == nil {
		var tmp1 *String; part = URI_Decode_String__String(t.GetRawSchemeSpecificPart__String()); tmp1 = part; t.F_decodedSchemeSpecificPart = tmp1 }
//line :149:1
	return part
}



func (t *URI) GetRawAuthority__String() *String { return t.F_authority }

func (t *URI) GetAuthority__String() *String {
	var auth *String = t.F_decodedAuthority; var tmp1 bool; var tmp2 bool
	tmp2 = auth == nil; if tmp2 { tmp2 = !(t.F_authority == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp3 *String; auth = URI_Decode_String__String(t.F_authority); tmp3 = auth; t.F_decodedAuthority = tmp3 }
//line :157:1
	return auth
}



func (t *URI) GetRawUserInfo__String() *String { return t.F_userInfo }

func (t *URI) GetUserInfo__String() *String {
	var user *String = t.F_decodedUserInfo; var tmp1 bool; var tmp2 bool
	tmp2 = user == nil; if tmp2 { tmp2 = !(t.F_userInfo == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp3 *String; user = URI_Decode_String__String(t.F_userInfo); tmp3 = user; t.F_decodedUserInfo = tmp3 }
//line :165:1
	return user
}



func (t *URI) GetHost__String() *String { return t.F_host }

func (t *URI) GetPort__I() int32 { return t.F_port }

func (t *URI) GetRawPath__String() *String { return t.F_path }

func (t *URI) GetPath__String() *String {
	var decoded *String = t.F_decodedPath; var tmp1 bool; var tmp2 bool
	tmp2 = decoded == nil; if tmp2 { tmp2 = !(t.F_path == nil) }; tmp1 = tmp2; if tmp1 { var tmp3 *String; decoded = URI_Decode_String__String(t.F_path); tmp3 = decoded; t.F_decodedPath = tmp3 }
//line :177:1
	return decoded
}


func (t *URI) GetRawQuery__String() *String { return t.F_query }

func (t *URI) GetQuery__String() *String {
	var decoded *String = t.F_decodedQuery; var tmp1 bool; var tmp2 bool
	tmp2 = decoded == nil; if tmp2 { tmp2 = !(t.F_query == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp3 *String; decoded = URI_Decode_String_Z__String(t.F_query, false); tmp3 = decoded; t.F_decodedQuery = tmp3 }
//line :184:1
	return decoded
}



func (t *URI) GetRawFragment__String() *String { return t.F_fragment }

func (t *URI) GetFragment__String() *String {
	var decoded *String = t.F_decodedFragment; var tmp1 bool; var tmp2 bool
	tmp2 = decoded == nil; if tmp2 { tmp2 = !(t.F_fragment == nil) }; tmp1 = tmp2; if tmp1 {
		var tmp3 *String; decoded = URI_Decode_String_Z__String(t.F_fragment, false); tmp3 = decoded; t.F_decodedFragment = tmp3 }
//line :192:1
	return decoded
}



func (t *URI) Equals_O__Z(ob any) bool {
	if any(ob) == any(t) { return true } else {

		var tmp1 any = ob; if URI_InstanceOf(tmp1) { var that *URI = URI_Cast(tmp1)
			if !(t.IsOpaque__Z() == NN(that).IsOpaque__Z()) { return false } else { var tmp2 *String = t.F_scheme; if !URI_EqualIgnoringCase_String_String__Z(tmp2, that.F_scheme) { return false } else { var tmp3 *String = t.F_fragment; if !URI_Equal_String_String__Z(tmp3, that.F_fragment) { return false } else { if t.IsOpaque__Z() {



				var tmp4 *String = t.F_schemeSpecificPart; return URI_Equal_String_String__Z(tmp4, that.F_schemeSpecificPart) } else {
//line :201:1
					var tmp5 *String = t.F_path; if !URI_Equal_String_String__Z(tmp5, that.F_path) { return false } else { var tmp6 *String = t.F_query; if !URI_Equal_String_String__Z(tmp6, that.F_query) { return false } else { var tmp7 *String = t.F_authority; if tmp7 == that.F_authority { return true } else {









						if !(t.F_host == nil) {


							var tmp8 *String = t.F_userInfo; if URI_Equal_String_String__Z(tmp8, that.F_userInfo) { } else { return false }
							var tmp9 *String = t.F_host; if URI_EqualIgnoringCase_String_String__Z(tmp9, that.F_host) { } else { return false }
							var tmp10 int32 = t.F_port; if tmp10 == that.F_port { } else { return false } } else {
//line :211:1
								if !(t.F_authority == nil) {






									var tmp11 *String = t.F_authority; if URI_Equal_String_String__Z(tmp11, that.F_authority) { } else { return false } } else {
										var tmp12 *String = t.F_authority; if tmp12 == that.F_authority { } else { return false } } }
//line :210:1
						return true } } } } } } } } else {
//line :200:1
							return false
						}
	}
}



















func (t *URI) HashCode__I() int32 {
	var h int32 = t.F_hash
	if h == 0 {
		h = URI_HashIgnoringCase_I_String__I(0, t.F_scheme)
		h = URI_Hash_I_String__I(h, t.F_fragment)
		if t.IsOpaque__Z() {
			h = URI_Hash_I_String__I(h, t.F_schemeSpecificPart) } else {

				h = URI_Hash_I_String__I(h, t.F_path)
				h = URI_Hash_I_String__I(h, t.F_query)
				if !(t.F_host == nil) {

					h = URI_Hash_I_String__I(h, t.F_userInfo)
					h = URI_HashIgnoringCase_I_String__I(h, t.F_host)
					h = h + 1949*t.F_port } else {
						h = URI_Hash_I_String__I(h, t.F_authority) } }
		if h == 0 { } else { t.F_hash = h } }
//line :224:1
	return h
}
















func (t *URI) CompareTo_URI__I(that *URI) int32 {
	var c int32 = 0; var tmp1 int32; var tmp2 *String = t.F_scheme

	c = URI_CompareIgnoringCase_String_String__I(tmp2, that.F_scheme); tmp1 = c
//line :244:1
	if !(tmp1 == 0) { return c } else { if t.IsOpaque__Z() {


		if NN(that).IsOpaque__Z() {
			var tmp3 int32; var tmp4 *String = t.F_schemeSpecificPart; c = URI_Compare_String_String__I(tmp4, that.F_schemeSpecificPart); tmp3 = c; if !(tmp3 == 0) { return c } else {




				var tmp5 *String = t.F_fragment; return URI_Compare_String_String__I(tmp5, that.F_fragment) } } else {
//line :247:1
					return 1 } } else {
//line :244:1
						if NN(that).IsOpaque__Z() { return -1 } else {













							var tmp6 bool; var tmp7 bool; tmp7 = !(t.F_host == nil); if tmp7 { tmp7 = !(that.F_host == nil) }; tmp6 = tmp7; if tmp6 {

								var tmp8 int32; var tmp9 *String = t.F_userInfo; c = URI_Compare_String_String__I(tmp9, that.F_userInfo); tmp8 = c; if tmp8 == 0 { } else {
									return c }
								var tmp10 int32; var tmp11 *String = t.F_host; c = URI_CompareIgnoringCase_String_String__I(tmp11, that.F_host); tmp10 = c; if tmp10 == 0 { } else {
									return c }
								var tmp12 int32; var tmp13 int32 = t.F_port; c = tmp13 - that.F_port; tmp12 = c; if tmp12 == 0 { } else {
									return c } } else {
										var tmp14 int32; var tmp15 *String = t.F_authority; c = URI_Compare_String_String__I(tmp15, that.F_authority); tmp14 = c; if tmp14 == 0 { } else {
											return c } }
							var tmp16 int32; var tmp17 *String = t.F_path
							c = URI_Compare_String_String__I(tmp17, that.F_path); tmp16 = c
//line :268:1
							if !(tmp16 == 0) { return c } else { var tmp18 int32; var tmp19 *String = t.F_query

								c = URI_Compare_String_String__I(tmp19, that.F_query); tmp18 = c
//line :268:1
								if !(tmp18 == 0) { return c } else {


									var tmp20 *String = t.F_fragment; return URI_Compare_String_String__I(tmp20, that.F_fragment)
								} } } } } }
func (t *URI) ToString__String() *String {
	var s *String = t.F_string.Load(); if s == nil { s = t.DefineString__String() }; return s
}
func (t *URI) DefineString__String() *String {
	var s *String = t.F_string.Load()
	if !(s == nil) { return s } else {

		var sb *StringBuilder = StringBuilder_New()
		if !(t.F_scheme == nil) { NN(sb).Append_String__StringBuilder(t.F_scheme); NN(sb).Append_C__StringBuilder(58) }
		if t.IsOpaque__Z() {
			NN(sb).Append_String__StringBuilder(t.F_schemeSpecificPart) } else {

				if !(t.F_host == nil) {

					NN(sb).Append_String__StringBuilder(Lit_70)
					if !(t.F_userInfo == nil) { NN(sb).Append_String__StringBuilder(t.F_userInfo); NN(sb).Append_C__StringBuilder(64) }
					var needBrackets bool; var tmp1 bool; var tmp2 bool
					tmp2 = NN(t.F_host).IndexOf_I__I(58) >= 0
//line :289:1
					if tmp2 {

						tmp2 = !NN(t.F_host).StartsWith_String__Z(Lit_1318) }
//line :289:1
					tmp1 = tmp2; if tmp1 {


						tmp1 = !NN(t.F_host).EndsWith_String__Z(Lit_1189) }
//line :289:1
					needBrackets = tmp1



					if needBrackets { NN(sb).Append_C__StringBuilder(91) }
					NN(sb).Append_String__StringBuilder(t.F_host)
					if needBrackets { NN(sb).Append_C__StringBuilder(93) }
					if t.F_port == -1 { } else { NN(sb).Append_C__StringBuilder(58); NN(sb).Append_I__StringBuilder(t.F_port) } } else {
						if !(t.F_authority == nil) { NN(sb).Append_String__StringBuilder(Lit_70); NN(sb).Append_String__StringBuilder(t.F_authority) } }
				if !(t.F_path == nil) { NN(sb).Append_String__StringBuilder(t.F_path) }
				if !(t.F_query == nil) { NN(sb).Append_C__StringBuilder(63); NN(sb).Append_String__StringBuilder(t.F_query) } }
		if !(t.F_fragment == nil) { NN(sb).Append_C__StringBuilder(35); NN(sb).Append_String__StringBuilder(t.F_fragment) }
		var tmp3 *String = NN(sb).ToString__String(); t.F_string.Store(tmp3); return tmp3
	} }
func (t *URI) ToASCIIString__String() *String {
	return URI_Encode_String__String(t.ToString__String())
}













func URI_ToLower_C__I(c uint16) int32 { URI_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = int32(c) >= 65; if tmp2 { tmp2 = int32(c) <= 90 }; tmp1 = tmp2; if tmp1 { return int32(c) + 32 } else { return int32(c)
	} }
func URI_ToUpper_C__I(c uint16) int32 { URI_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = int32(c) >= 97; if tmp2 { tmp2 = int32(c) <= 122 }; tmp1 = tmp2; if tmp1 { return int32(c) - 32 } else { return int32(c)
	} }
func URI_Equal_String_String__Z(s, t_ *String) bool { URI_Init()
	var testForEquality bool = true; var result int32 = URI_PercentNormalizedComparison_String_String_Z__I(s, t_, testForEquality)

	return result == 0
}
func URI_EqualIgnoringCase_String_String__Z(s, t_ *String) bool { URI_Init()
	if s == t_ { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = !(s == nil); if tmp2 { tmp2 = !(t_ == nil) }; tmp1 = tmp2
//line :331:1
		if tmp1 {


			var n int32 = NN(s).Length__I()
			if !(NN(t_).Length__I() == n) { return false } else {


				var i int32 = 0; L1: for {
					if i < n {
						if !(URI_ToLower_C__I(NN(s).CharAt_I__C(i)) == URI_ToLower_C__I(NN(t_).CharAt_I__C(i))) {
							return false } else {
								i = i + 1; continue L1 } }
//line :338:1
					break L1 }
//line :337:1
				return true } } else {
//line :331:1
					return false
				}
	}
}












func URI_Hash_I_String__I(hash int32, s *String) int32 { URI_Init()
	if s == nil { return hash } else { if NN(s).IndexOf_I__I(37) < 0 {

		return hash*127 + NN(s).HashCode__I() } else {
			return URI_NormalizedHash_I_String__I(hash, s)
		} } }
func URI_NormalizedHash_I_String__I(hash int32, s *String) int32 { URI_Init()
	var h int32 = 0
	var index int32 = 0
L1: for { if index < NN(s).Length__I() {
	var ch uint16 = NN(s).CharAt_I__C(index)
	h = 31*h + int32(ch)
	if int32(ch) == 37 {
		var i int32 = index + 1; L2: for {
			if i < index+3 {
				h = 31*h + URI_ToUpper_C__I(NN(s).CharAt_I__C(i))


				i = i + 1; continue L2 }
//line :360:1
			break L2
		}




		index = index + 2 }
	index = index + 1
//line :356:1
	continue L1 }; break L1
}










	return hash*127 + h
}
func URI_HashIgnoringCase_I_String__I(hash int32, s *String) int32 { URI_Init()
	if s == nil { return hash } else {

		var h int32 = hash; var n int32 = NN(s).Length__I()
		var i int32 = 0
	L1: for {
		if i < n {
			h = 31*h + URI_ToLower_C__I(NN(s).CharAt_I__C(i))
			i = i + 1; continue L1 }
//line :375:1
		break L1 }
//line :373:1
		return h
	}
}





func URI_Compare_String_String__I(s, t_ *String) int32 { URI_Init()
	var testForEquality bool = false; var result int32 = URI_PercentNormalizedComparison_String_String_Z__I(s, t_, testForEquality); return result
}


func URI_PercentNormalizedComparison_String_String_Z__I(s, t_ *String, testForEquality bool) int32 { URI_Init()

	if s == t_ { return 0 } else { if !(s == nil) {


		if !(t_ == nil) {
			if NN(s).IndexOf_I__I(37) < 0 {
				return NN(s).CompareTo_String__I(t_) } else {
					var sn int32 = NN(s).Length__I(); var tn int32 = NN(t_).Length__I(); var tmp1 bool; var tmp2 bool

					tmp2 = !(sn == tn); if tmp2 { tmp2 = testForEquality }; tmp1 = tmp2; if tmp1 {
						return sn - tn } else {
							var val int32 = 0; var n int32 = Math_Min_I_I__I(sn, tn)
							var i int32 = 0

						L1: for { if i < n {
							var c uint16 = NN(s).CharAt_I__C(i); var d uint16 = NN(t_).CharAt_I__C(i)

							val = int32(c) - int32(d)
							if !(int32(c) == 37) {

								if val == 0 { } else { return val }
								i = i + 1 } else {

									if int32(d) == 37 { } else { if val == 0 { } else { return val } }
									i = i + 1
									val = URI_ToLower_C__I(NN(s).CharAt_I__C(i)) - URI_ToLower_C__I(NN(t_).CharAt_I__C(i))



									if val == 0 { } else { return val }
									i = i + 1
									val = URI_ToLower_C__I(NN(s).CharAt_I__C(i)) - URI_ToLower_C__I(NN(t_).CharAt_I__C(i))



									if val == 0 { } else { return val }
									i = i + 1 }
//line :401:1
							continue L1 }; break L1
						}





















							return sn - tn } } } else {
//line :391:1
								return 1
							}






























	} else {
//line :388:1
		return -1
	}
	}
}




































func URI_CompareIgnoringCase_String_String__I(s, t_ *String) int32 { URI_Init()
	if s == t_ { return 0 } else { if !(s == nil) {


		if !(t_ == nil) {
			var sn int32 = NN(s).Length__I(); var tn int32 = NN(t_).Length__I(); var n int32

			if sn < tn { n = sn } else { n = tn }
			var i int32 = 0; L1: for {
				if i < n {
					var c int32 = URI_ToLower_C__I(NN(s).CharAt_I__C(i)) - URI_ToLower_C__I(NN(t_).CharAt_I__C(i))


					if !(c == 0) { return c } else { i = i + 1; continue L1 } }
//line :436:1
				break L1
			}




			return sn - tn } else {
//line :432:1
				return 1
			}







	} else {
//line :429:1
		return -1
	}
	}
}













func URI_CheckPath_String_String_String__V(s, scheme, path *String) { URI_Init()

	if !(scheme == nil) {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = !(path == nil); if tmp3 { tmp3 = !NN(path).IsEmpty__Z() }; tmp2 = tmp3; if tmp2 { tmp2 = !(int32(NN(path).CharAt_I__C(0)) == 47) }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(URISyntaxException_New_String_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(s))), Lit_1385)))
		}
	}
}


func (t *URI) AppendAuthority_StringBuilder_String_String_String_I__V(sb *StringBuilder, authority, userInfo, host *String, port int32) {

	if !(host == nil) {

		NN(sb).Append_String__StringBuilder(Lit_70)
		if !(userInfo == nil) {
			NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(userInfo, 3458623578763689985, 5188146764422578174))
			NN(sb).Append_C__StringBuilder(64) }
		var needBrackets bool; var tmp1 bool; var tmp2 bool; tmp2 = NN(host).IndexOf_I__I(58) >= 0; if tmp2 { tmp2 = !NN(host).StartsWith_String__Z(Lit_1318) }; tmp1 = tmp2; if tmp1 {
			tmp1 = !NN(host).EndsWith_String__Z(Lit_1189) }
//line :464:1
		needBrackets = tmp1

		if needBrackets { NN(sb).Append_C__StringBuilder(91) }
		NN(sb).Append_String__StringBuilder(host)
		if needBrackets { NN(sb).Append_C__StringBuilder(93) }
		if port == -1 { } else { NN(sb).Append_C__StringBuilder(58); NN(sb).Append_I__StringBuilder(port) } } else {
			if !(authority == nil) {
				NN(sb).Append_String__StringBuilder(Lit_70)
				if NN(authority).StartsWith_String__Z(Lit_1318) {
					var end int32 = NN(authority).IndexOf_I__I(93); var doquote *String = authority; var tmp3 bool; var tmp4 bool

					tmp4 = !(end == -1); if tmp4 { tmp4 = !(NN(authority).IndexOf_I__I(58) == -1) }; tmp3 = tmp4; if tmp3 {
						NN(sb).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(authority), 0, end+1)
						doquote = NN(authority).Substring_I__String(end + 1) }
					NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(doquote, 3458623578763689985, 5188146765093666815)) } else {



						NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(authority, 3458623578763689985, 5188146765093666815))
					}
			}
		}
}
func (t *URI) AppendSchemeSpecificPart_StringBuilder_String_String_String_String_I_String_String__V(sb *StringBuilder, opaquePart, authority, userInfo, host *String, port int32, path, query *String) {


	if !(opaquePart == nil) {
		if NN(opaquePart).StartsWith_String__Z(Lit_1386) {
			var end int32 = NN(opaquePart).IndexOf_I__I(93); var tmp1 bool; var tmp2 bool
			tmp2 = !(end == -1); if tmp2 { tmp2 = !(NN(opaquePart).IndexOf_I__I(58) == -1) }; tmp1 = tmp2; if tmp1 {
				var doquote *String = NN(opaquePart).Substring_I__String(end + 1)
				NN(sb).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(opaquePart), 0, end+1)
				NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(doquote, -5764607720602730495, 5188146765093666815)) } } else {
					NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(opaquePart, -5764607720602730495, 5188146765093666815)) } } else {

						t.AppendAuthority_StringBuilder_String_String_String_I__V(sb, authority, userInfo, host, port)
						if !(path == nil) { NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(path, 3458764316252045313, 5188146764422578175)) }
						if !(query == nil) { NN(sb).Append_C__StringBuilder(63); NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(query, -5764607720602730495, 5188146765093666815))
						} } }
func (t *URI) AppendFragment_StringBuilder_String__V(sb *StringBuilder, fragment *String) {
	if !(fragment == nil) { NN(sb).Append_C__StringBuilder(35); NN(sb).Append_String__StringBuilder(URI_Quote_String_J_J__String(fragment, -5764607720602730495, 5188146765093666815))
	} }
func (t *URI) ToString_String_String_String_String_String_I_String_String_String__String(scheme, opaquePart, authority, userInfo, host *String, port int32, path, query, fragment *String) *String {


	var sb *StringBuilder = StringBuilder_New()
	if !(scheme == nil) { NN(sb).Append_String__StringBuilder(scheme); NN(sb).Append_C__StringBuilder(58) }
	t.AppendSchemeSpecificPart_StringBuilder_String_String_String_String_I_String_String__V(sb, opaquePart, authority, userInfo, host, port, path, query)
	t.AppendFragment_StringBuilder_String__V(sb, fragment)
	return NN(sb).ToString__String()
}
func URI_ResolvePath_String_String_Z__String(base, child *String, absolute bool) *String { URI_Init()
	var i int32 = NN(base).LastIndexOf_I__I(47); var cn int32 = NN(child).Length__I()
	var path /*line :516:1*/*String = Lit_69


	if cn == 0 {
		if i >= 0 { path = NN(base).Substring_I_I__String(0, i+1) } } else {
//line :519:1
			var tmp1 bool; var tmp2 bool

			tmp2 = i >= 0; if !tmp2 { tmp2 = !absolute }; tmp1 = tmp2
//line :519:1
			if tmp1 {


				path = NN(NN(base).Substring_I_I__String(0, i+1)).Concat_String__String(child) } else {
					path = Lit_68.Concat_String__String(child) } }
	var np *String = URI_Normalize_String__String(path); return np
}
func URI_Resolve_URI_URI__URI(base, child *URI) *URI { URI_Init()
	var tmp1 bool; var tmp2 bool
	tmp2 = NN(child).IsOpaque__Z(); if !tmp2 { tmp2 = NN(base).IsOpaque__Z() }; tmp1 = tmp2
//line :527:1
	if tmp1 { return child } else { var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool

		tmp7 = child.F_scheme == nil; if tmp7 { tmp7 = child.F_authority == nil }; tmp6 = tmp7; if tmp6 {
			tmp6 = NN(child.F_path).IsEmpty__Z() }
//line :529:1
		tmp5 = tmp6; if tmp5 {

			tmp5 = !(child.F_fragment == nil) }
//line :529:1
		tmp4 = tmp5; if tmp4 {


			tmp4 = child.F_query == nil }
//line :529:1
		tmp3 = tmp4
//line :527:1
		if tmp3 {





			var tmp8 bool; var tmp9 bool; tmp9 = !(base.F_fragment == nil); if tmp9 { var tmp10 *String = child.F_fragment; tmp9 = NN(tmp10).Equals_O__Z(base.F_fragment.Ref()) }; tmp8 = tmp9; if tmp8 { return base } else {

				var ru *URI = URI_New()
				ru.F_scheme = base.F_scheme
				ru.F_authority = base.F_authority
				ru.F_userInfo = base.F_userInfo
				ru.F_host = base.F_host
				ru.F_port = base.F_port
				ru.F_path = base.F_path
				ru.F_fragment = child.F_fragment
				ru.F_query = base.F_query
//line :535:1
				return ru } } else {
//line :527:1
					if !(child.F_scheme == nil) { return child } else {



















						var ru_2 *URI = URI_New()
						ru_2.F_scheme = base.F_scheme
						ru_2.F_query = child.F_query
						ru_2.F_fragment = child.F_fragment
						if child.F_authority == nil {

							ru_2.F_authority = base.F_authority
							ru_2.F_host = base.F_host
							ru_2.F_userInfo = base.F_userInfo
							ru_2.F_port = base.F_port
							var cp *String = child.F_path; var tmp11 bool; var tmp12 bool
							tmp12 = !NN(cp).IsEmpty__Z(); if tmp12 { tmp12 = int32(NN(cp).CharAt_I__C(0)) == 47 }; tmp11 = tmp12; if tmp11 {
								ru_2.F_path = child.F_path } else {
									var tmp13 *String = base.F_path; ru_2.F_path = URI_ResolvePath_String_String_Z__String(tmp13, cp, NN(base).IsAbsolute__Z()) } } else {

										ru_2.F_authority = child.F_authority
										ru_2.F_host = child.F_host
										ru_2.F_userInfo = child.F_userInfo
										ru_2.F_port = child.F_port
										ru_2.F_path = child.F_path }
//line :547:1
						return ru_2
					}
				}
	}
}

















func URI_Normalize_URI__URI(u *URI) *URI { URI_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = NN(u).IsOpaque__Z(); if !tmp3 { tmp3 = u.F_path == nil }; tmp2 = tmp3; if !tmp2 { tmp2 = NN(u.F_path).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { return u } else {

		var np *String = URI_Normalize_String__String(u.F_path)
		if np == u.F_path { return u } else {

			var v *URI = URI_New()
			v.F_scheme = u.F_scheme
			v.F_fragment = u.F_fragment
			v.F_authority = u.F_authority
			v.F_userInfo = u.F_userInfo
			v.F_host = u.F_host
			v.F_port = u.F_port
			v.F_path = np
			v.F_query = u.F_query
//line :575:1
			return v
		}
	}
}







func URI_Relativize_URI_URI__URI(base, child *URI) *URI { URI_Init()
	var tmp1 bool; var tmp2 bool
	tmp2 = NN(child).IsOpaque__Z(); if !tmp2 { tmp2 = NN(base).IsOpaque__Z() }; tmp1 = tmp2
//line :587:1
	if tmp1 { return child } else { var tmp3 bool; var tmp4 bool; var tmp5 *String = base.F_scheme

		tmp4 = !URI_EqualIgnoringCase_String_String__Z(tmp5, child.F_scheme); if !tmp4 {
			var tmp6 *String = base.F_authority; tmp4 = !URI_Equal_String_String__Z(tmp6, child.F_authority) }
//line :589:1
		tmp3 = tmp4
//line :587:1
		if tmp3 { return child } else {





			var bp *String = URI_Normalize_String__String(base.F_path); var cp *String = URI_Normalize_String__String(child.F_path)

			if NN(bp).Equals_O__Z(cp.Ref()) { } else {
				if NN(bp).EndsWith_String__Z(Lit_68) { } else { bp = Concat(bp, Lit_68) }
				if NN(cp).StartsWith_String__Z(bp) { } else { return child } }
			var v *URI = URI_New()
			v.F_path = NN(cp).Substring_I__String(NN(bp).Length__I())
			v.F_query = child.F_query
			v.F_fragment = child.F_fragment
//line :598:1
			return v
		}
	}
}


func URI_NeedsNormalization_String__I(path *String) int32 { URI_Init()
	var normal bool = true; var ns int32 = 0; var end int32 = NN(path).Length__I() - 1
	var p int32 = 0


L1: for { if p <= end { if int32(NN(path).CharAt_I__C(p)) == 47 { } else { break L1 }; p = p + 1; continue L1 }; break L1 }
	if p > 1 { normal = false }
L2: for { if p <= end {
	var tmp1 bool; var tmp2 bool; tmp2 = int32(NN(path).CharAt_I__C(p)) == 46; if tmp2 {
		var tmp3 bool; tmp3 = p == end; if !tmp3 {
			var tmp4 bool; tmp4 = int32(NN(path).CharAt_I__C(p+1)) == 47; if !tmp4 {
				var tmp5 bool; tmp5 = int32(NN(path).CharAt_I__C(p+1)) == 46; if tmp5 {
					var tmp6 bool; tmp6 = p+1 == end; if !tmp6 {
						tmp6 = int32(NN(path).CharAt_I__C(p+2)) == 47 }
//line :616:1
					tmp5 = tmp6 }
//line :615:1
				tmp4 = tmp5 }
//line :614:1
			tmp3 = tmp4 }
//line :613:1
		tmp2 = tmp3 }
//line :612:1
	tmp1 = tmp2; if tmp1 {





		normal = false }
	ns = ns + 1
L3: for { if p <= end {
	var tmp7 int32; var old_1 int32 = p
	p = p + 1; tmp7 = old_1
//line :621:1
	if !(int32(NN(path).CharAt_I__C(tmp7)) == 47) { } else {

	L4: for { if p <= end {
		if int32(NN(path).CharAt_I__C(p)) == 47 { } else { break L4 }
		normal = false
		p = p + 1
//line :623:1
		continue L4 }; break L4
	}


		break L3 }
//line :620:1
	continue L3 }; break L3 }
//line :611:1
	continue L2 }; break L2
}















	if normal { return -1 } else { return ns
	} }
func URI_Split_C1_I1__V(path *CharArray, segs *IntArray) { URI_Init()
	var end int32 = int32(len(path.A)) - 1
	var p int32 = 0
	var i int32 = 0
L1: for { if p <= end {
	if int32(path.A[p]) == 47 { } else { break L1 }
	path.A[p] = 0
	p = p + 1
//line :634:1
	continue L1 }; break L1
}


L2: for { if p <= end {
	segs.A[i] = p
	i = i + 1
	p = p + 1
L3: for { if p <= end {
	var tmp1 int32; var old_2 int32 = p; p = p + 1; tmp1 = old_2; if !(int32(path.A[tmp1]) == 47) { } else {
		path.A[p-1] = 0
	L4: for { if p <= end {
		if int32(path.A[p]) == 47 { } else { break L4 }
		path.A[p] = 0
		p = p + 1
//line :645:1
		continue L4 }; break L4
	}


		break L3 }
//line :642:1
	continue L3 }; break L3 }
//line :638:1
	continue L2 }; break L2
}










	if i == int32(len(segs.A)) { } else { panic(Thrown(InternalError_New()))
	} }
func URI_Join_C1_I1__I(path *CharArray, segs *IntArray) int32 { URI_Init()
	var ns int32 = int32(len(segs.A)); var end int32 = int32(len(path.A)) - 1
	var p int32 = 0

	if int32(path.A[p]) == 0 { path.A[p] = 47; p = p + 1 }
	var i int32 = 0; L1: for {
		if i < ns {
			var q int32 = segs.A[i]
			if q == -1 {
				i = i + 1; continue L1 } else {
//line :660:1
					if p == q {



					L2: for { var tmp1 bool; var tmp2 bool; tmp2 = p <= end; if tmp2 { tmp2 = !(int32(path.A[p]) == 0) }; tmp1 = tmp2; if tmp1 {
						p = p + 1
//line :664:1
						continue L2 }; break L2
					}
						if p <= end {

							path.A[p] = 47
							p = p + 1
							i = i + 1; continue L1 } else {
								i = i + 1; continue L1 } } else {
//line :660:1
									if p < q {













									L3: for { var tmp3 bool; var tmp4 bool; tmp4 = q <= end; if tmp4 { tmp4 = !(int32(path.A[q]) == 0) }; tmp3 = tmp4; if tmp3 {
										path.A[p] = path.A[q]
										p = p + 1
										q = q + 1
//line :674:1
										continue L3 }; break L3
									}


										if q <= end {

											path.A[p] = 47
											p = p + 1
											i = i + 1; continue L1 } else {
												i = i + 1; continue L1 } } else {
													panic(Thrown(InternalError_New())) } } } }
//line :657:1
		break L1 }
//line :653:1
	return p
}
































func URI_RemoveDots_C1_I1__V(path *CharArray, segs *IntArray) { URI_Init()
	var ns int32 = int32(len(segs.A)); var end int32 = int32(len(path.A)) - 1
	var i int32 = 0

L1: for { if i < ns {
	var dots int32 = 0
L2: for {
	var p int32 = segs.A[i]
	if int32(path.A[p]) == 46 {
		if p == end {
			dots = 1; break L2 } else {
//line :696:1
				if int32(path.A[p+1]) == 0 {

					dots = 1; break L2 } else {

						var tmp1 bool; var tmp2 bool; tmp2 = int32(path.A[p+1]) == 46; if tmp2 {
							var tmp3 bool; tmp3 = p+1 == end; if !tmp3 {
								tmp3 = int32(path.A[p+2]) == 0 }
//line :701:1
							tmp2 = tmp3 }
//line :700:1
						tmp1 = tmp2; if tmp1 {


							dots = 2
							break L2 } } } }
	i = i + 1
	if i < ns { continue L2 }
//line :693:1
	break L2
}












	var tmp4 bool; var tmp5 bool; tmp5 = i > ns; if !tmp5 { tmp5 = dots == 0 }; tmp4 = tmp5; if tmp4 { break L1 }
	if dots == 1 {
		segs.A[i] = -1 } else {
			var j int32 = 0
			j = i - 1
		L3: for { if j >= 0 {
			if segs.A[j] == -1 { } else { break L3 }
			j = j - 1
//line :712:1
			continue L3 }; break L3
		}

			if j >= 0 {
				var q int32 = segs.A[j]; var tmp6 bool; var tmp7 bool; var tmp8 bool
				tmp8 = int32(path.A[q]) == 46; if tmp8 {
					tmp8 = int32(path.A[q+1]) == 46 }
//line :717:1
				tmp7 = tmp8; if tmp7 {

					tmp7 = int32(path.A[q+2]) == 0 }
//line :717:1
				tmp6 = tmp7; if tmp6 { } else {


					segs.A[i] = -1
					segs.A[j] = -1 } } }
	i = i + 1
//line :691:1
	continue L1 }; break L1
}
}






























func URI_MaybeAddLeadingDot_C1_I1__V(path *CharArray, segs *IntArray) { URI_Init()
	if int32(path.A[0]) == 0 { } else {
		var ns int32 = int32(len(segs.A))
		var f int32 = 0
	L1: for { if f < ns { if segs.A[f] >= 0 { break L1 }; f = f + 1; continue L1 }; break L1 }
		var tmp1 bool; var tmp2 bool; tmp2 = f >= ns; if !tmp2 { tmp2 = f == 0 }; tmp1 = tmp2; if tmp1 { } else {
			var p int32 = segs.A[f]
		L2: for { var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = p < int32(len(path.A)); if tmp5 { tmp5 = !(int32(path.A[p]) == 58) }; tmp4 = tmp5; if tmp4 {
			tmp4 = !(int32(path.A[p]) == 0) }
//line :731:1
			tmp3 = tmp4; if tmp3 {

				p = p + 1
//line :731:1
				continue L2 }; break L2
		}

			var tmp6 bool; var tmp7 bool; tmp7 = p >= int32(len(path.A)); if !tmp7 { tmp7 = int32(path.A[p]) == 0 }; tmp6 = tmp7; if tmp6 { } else {
				path.A[0] = 46
				path.A[1] = 0
				segs.A[0] = 0
			} } } }
func URI_Normalize_String__String(ps *String) *String { URI_Init()
	var ns int32 = URI_NeedsNormalization_String__I(ps)
	if ns < 0 { return ps } else {

		var path *CharArray = NN(ps).ToCharArray__C1(); var segs *IntArray = NewIntArray(ns)

		URI_Split_C1_I1__V(path, segs)
		URI_RemoveDots_C1_I1__V(path, segs)
		URI_MaybeAddLeadingDot_C1_I1__V(path, segs)
		var s *String = String_New_C1_I_I(path, 0, URI_Join_C1_I1__I(path, segs)); if NN(s).Equals_O__Z(ps.Ref()) { return ps } else { return s
		} } }
func URI_Match_C_J_J__Z(c uint16, lowMask, highMask int64) bool { URI_Init()
	if int32(c) == 0 { return false } else { if int32(c) < 64 {

		return !(1<<(int32(c)&63)&lowMask == 0) } else {
//line :751:1
			if int32(c) < 128 {


				return !(1<<((int32(c)-64)&63)&highMask == 0) } else {
//line :751:1
					return false
				}
		}
	}
}































































































func URI_AppendEscape_StringBuilder_B__V(sb *StringBuilder, b int8) { URI_Init()
	NN(sb).Append_C__StringBuilder(37)
	NN(sb).Append_C__StringBuilder(URI_hexDigits.A[int32(b)>>4&15])
	NN(sb).Append_C__StringBuilder(URI_hexDigits.A[int32(b)>>0&15])
}









func URI_Quote_String_J_J__String(s *String, lowMask, highMask int64) *String { URI_Init()
	var sb *StringBuilder; var encoder any; var allowNonASCII bool = !(lowMask&1 == 0)
	var i int32 = 0

L1: for {
	if i < NN(s).Length__I() {
		var c uint16 = NN(s).CharAt_I__C(i)
		if int32(c) < 128 {

			if !URI_Match_C_J_J__Z(c, lowMask, highMask) {


				if sb == nil { sb = StringBuilder_New(); NN(sb).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(s), 0, i) }
				URI_AppendEscape_StringBuilder_B__V(sb, int8(c))
				i = i + 1; continue L1 } else {
//line :874:1
					if !(sb == nil) {





						NN(sb).Append_C__StringBuilder(c); i = i + 1; continue L1 } else {
							i = i + 1; continue L1 } } } else {
//line :872:1
								var tmp1 bool; var tmp2 bool









								tmp2 = allowNonASCII; if tmp2 { var tmp3 bool; tmp3 = Character_IsSpaceChar_C__Z(c); if !tmp3 { tmp3 = Character_IsISOControl_C__Z(c) }; tmp2 = tmp3 }; tmp1 = tmp2
//line :872:1
								if tmp1 {











									if encoder == nil { encoder = A2g_Missing[any]("class java.nio.charset.CharsetEncoder is not in the closed world") }
									if sb == nil { sb = StringBuilder_New(); NN(sb).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(s), 0, i) }
									A2g_Missing[bool]("class java.nio.charset.CharsetEncoder is not in the closed world")
									i = i + 1; continue L1 } else {
//line :872:1
										if !(sb == nil) {















											NN(sb).Append_C__StringBuilder(c); i = i + 1; continue L1 } else {
												i = i + 1; continue L1 } } } }
//line :869:1
	break L1
}



















	if sb == nil { return s } else { return NN(sb).ToString__String()
	} }
func URI_Encode_String__String(s *String) *String { URI_Init()
	var n int32 = NN(s).Length__I()
	if n == 0 { return s } else {


		var i int32 = 0
	L1: for {
		if int32(NN(s).CharAt_I__C(i)) >= 128 { break L1 }
		var tmp1 int32; i = i + 1; tmp1 = i; if tmp1 >= n { return s }
//line :898:1
		continue L1
	}

		var ns *String; var tmp2 *Normalizer_Form; _ = ns; Normalizer_Form_Init(); tmp2 = Normalizer_Form_NFC; ns = Normalizer_Normalize_CharSequence_Normalizer_Form__String(Up_String_CharSequence(s), tmp2); var bb ByteBuffer_I


		bb = A2g_Missing[ByteBuffer_I]("class java.nio.charset.CharsetEncoder is not in the closed world")

		var sb *StringBuilder = StringBuilder_New()
	L2: for { if bb.HasRemaining__Z() {
		var b int32 = int32(bb.Get__B()) & 255
		if b >= 128 {
			URI_AppendEscape_StringBuilder_B__V(sb, int8(b)) } else {
				NN(sb).Append_C__StringBuilder(uint16(b)) }
//line :907:1
		continue L2 }; break L2
	}



		return NN(sb).ToString__String()
	} }
func URI_Decode_C__I(c uint16) int32 { URI_Init()
	var tmp1 bool; var tmp2 bool
	tmp2 = int32(c) >= 48; if tmp2 { tmp2 = int32(c) <= 57 }; tmp1 = tmp2
//line :915:1
	if tmp1 {
		return int32(c) - 48 } else {
//line :915:1
			var tmp3 bool; var tmp4 bool

			tmp4 = int32(c) >= 97; if tmp4 { tmp4 = int32(c) <= 102 }; tmp3 = tmp4
//line :915:1
			if tmp3 {

				return int32(c) - 97 + 10 } else {
//line :915:1
					var tmp5 bool; var tmp6 bool


					tmp6 = int32(c) >= 65; if tmp6 { tmp6 = int32(c) <= 70 }; tmp5 = tmp6
//line :915:1
					if tmp5 {


						return int32(c) - 65 + 10 } else {
							if !A2g_AssertionsDisabled && !false { panic(Thrown(AssertionError_New())) }; return -1
						} } } }
func URI_Decode_C_C__B(c1, c2 uint16) int8 { URI_Init()
	return int8(URI_Decode_C__I(c1)&15<<4 | URI_Decode_C__I(c2)&15<<0)
}


func URI_Decode_String__String(s *String) *String { URI_Init()
	return URI_Decode_String_Z__String(s, true)
}




















































func URI_Parser_New_URI_String(p0 *URI, p1 *String) *URI_Parser { t := &URI_Parser{}; t.Ctor_URI_String(p0, p1); return t }
//line :981:1
func (t *URI_Parser) Ctor_URI_String(this_0 *URI, s *String) { NN(this_0); t.F_this_0 = this_0; t.F_requireServerAuthority = false; t.F_ipv6byteCount = 0; t.F_input = s; this_0.F_string.Store(s) }

func (t *URI_Parser) Fail_String__V(reason *String) {
	panic(Thrown(URISyntaxException_New_String_String(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_input))), reason)))
}




func (t *URI_Parser) Fail_String_I__V(reason *String, p int32) {
	if Exceptions_EnhancedNonSocketExceptions__Z() { } else { p = -1 }
	panic(Thrown(URISyntaxException_New_String_String_I(Exceptions_FormatMsg_String_Exceptions_SensitiveInfo1__String(Lit_1300, RefArrayOf(Exceptions_SensitiveInfo_class, Exceptions_FilterNonSocketInfo_String__Exceptions_SensitiveInfo(t.F_input))), reason, p)))
}





func (t *URI_Parser) FailExpecting_String_I__V(expected *String, p int32) {
	t.Fail_String_I__V(Concat(Lit_1387, expected), p)
}
func (t *URI_Parser) At_I_I_C__Z(start, end int32, c uint16) bool {
	var tmp1 bool; tmp1 = start < end; if tmp1 { tmp1 = int32(NN(t.F_input).CharAt_I__C(start)) == int32(c) }; return tmp1
}
func (t *URI_Parser) At_I_I_String__Z(start, end int32, s *String) bool {
	var p int32 = start; var sn int32 = NN(s).Length__I()

	if sn > end-p { return false } else {

		var i int32 = 0
	L1: for { if i < sn {
		var tmp1 *String = t.F_input; var tmp2 int32; var old_3 int32 = p; p = p + 1; tmp2 = old_3; if int32(NN(tmp1).CharAt_I__C(tmp2)) == int32(NN(s).CharAt_I__C(i)) { } else {

			break L1 }
		i = i + 1
//line :1011:1
		continue L1 }; break L1
	}



		return i == sn
	} }
func (t *URI_Parser) Scan_I_I_C__I(start, end int32, c uint16) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = start < end; if tmp2 { tmp2 = int32(NN(t.F_input).CharAt_I__C(start)) == int32(c) }; tmp1 = tmp2; if tmp1 { return start + 1 } else { return start
	} }
func (t *URI_Parser) Scan_I_I_String_String__I(start, end int32, err, stop *String) int32 {
	var p int32 = start
L1: for { if p < end {
	var c uint16 = NN(t.F_input).CharAt_I__C(p)
	if NN(err).IndexOf_I__I(int32(c)) >= 0 { return -1 }
	if NN(stop).IndexOf_I__I(int32(c)) >= 0 { break L1 }
	p = p + 1
//line :1023:1
	continue L1 }; break L1 }
//line :1022:1
	return p
}






func (t *URI_Parser) Scan_I_I_String__I(start, end int32, stop *String) int32 {
	var p int32 = start
L1: for { if p < end {
	var c uint16 = NN(t.F_input).CharAt_I__C(p)
	if NN(stop).IndexOf_I__I(int32(c)) >= 0 { break L1 }
	p = p + 1
//line :1032:1
	continue L1 }; break L1 }
//line :1031:1
	return p
}





func (t *URI_Parser) ScanEscape_I_I_C__I(start, n int32, first uint16) int32 {

	var p int32 = start
	var c uint16 = first
	if int32(c) == 37 {


		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = p+3 <= n; if tmp3 {
			tmp3 = URI_Match_C_J_J__Z(NN(t.F_input).CharAt_I__C(p+1), 287948901175001088, 541165879422) }
//line :1045:1
		tmp2 = tmp3; if tmp2 {

			tmp2 = URI_Match_C_J_J__Z(NN(t.F_input).CharAt_I__C(p+2), 287948901175001088, 541165879422) }
//line :1045:1
		tmp1 = tmp2; if tmp1 {


			return p + 3 }
		t.Fail_String_I__V(Lit_1388, p) } else {
//line :1042:1
			var tmp4 bool; var tmp5 bool; var tmp6 bool







			tmp6 = int32(c) > 128; if tmp6 { tmp6 = !Character_IsSpaceChar_C__Z(c) }; tmp5 = tmp6; if tmp5 { tmp5 = !Character_IsISOControl_C__Z(c) }; tmp4 = tmp5
//line :1042:1
			if tmp4 {








				return p + 1 } }
//line :1040:1
	return p
}












func (t *URI_Parser) Scan_I_I_J_J__I(start, n int32, lowMask, highMask int64) int32 {

	var p int32 = start
L1: for { if p < n {
	var c uint16 = NN(t.F_input).CharAt_I__C(p)
	if URI_Match_C_J_J__Z(c, lowMask, highMask) {
		p = p + 1 } else {

			if lowMask&1 == 0 { } else {
				var q int32 = t.ScanEscape_I_I_C__I(p, n, c); if q > p { p = q; continue L1 } }
			break L1 }
//line :1057:1
	continue L1 }; break L1 }
//line :1056:1
	return p
}









func (t *URI_Parser) CheckChars_I_I_J_J_String__V(start, end int32, lowMask, highMask int64, what *String) {


	var p int32 = t.Scan_I_I_J_J__I(start, end, lowMask, highMask)
	if p < end { t.Fail_String_I__V(Concat(Lit_1389, what), p)
	} }
func (t *URI_Parser) CheckChar_I_J_J_String__V(p int32, lowMask, highMask int64, what *String) {

	t.CheckChars_I_I_J_J_String__V(p, p+1, lowMask, highMask, what)
}
func (t *URI_Parser) Parse_Z__V(rsa bool) {
	t.F_requireServerAuthority = rsa
	var n int32 = NN(t.F_input).Length__I(); var p int32 = t.Scan_I_I_String_String__I(0, n, Lit_1390, Lit_1309); var tmp1 bool; var tmp2 bool

	tmp2 = p >= 0; if tmp2 { tmp2 = t.At_I_I_C__Z(p, n, 58) }; tmp1 = tmp2; if tmp1 {

		if p == 0 { t.FailExpecting_String_I__V(Lit_1391, 0) }
		t.CheckChar_I_J_J_String__V(0, 0, 576460743847706622, Lit_1391)
		t.CheckChars_I_I_J_J_String__V(1, p, 288063250384289792, 576460743847706622, Lit_1391)
		t.F_this_0.F_scheme = NN(t.F_input).Substring_I_I__String(0, p)
		p = p + 1
		if t.At_I_I_C__Z(p, n, 47) {
			p = t.ParseHierarchical_I_I__I(p, n) } else {
				var q int32 = t.Scan_I_I_String__I(p, n, Lit_1132)
				if q <= p { t.FailExpecting_String_I__V(Lit_1392, p) }
				t.CheckChars_I_I_J_J_String__V(p, q, -5764607720602730495, 5188146765093666815, Lit_1393)
				t.F_this_0.F_schemeSpecificPart = NN(t.F_input).Substring_I_I__String(p, q)
				p = q } } else {
					p = t.ParseHierarchical_I_I__I(0, n) }
	if t.At_I_I_C__Z(p, n, 35) {
		t.CheckChars_I_I_J_J_String__V(p+1, n, -5764607720602730495, 5188146765093666815, Lit_1394)
		t.F_this_0.F_fragment = NN(t.F_input).Substring_I_I__String(p+1, n)
		p = n }
	if p < n { t.Fail_String_I__V(Lit_1395, p)
	} }
func (t *URI_Parser) ParseHierarchical_I_I__I(start, n int32) int32 {
	var p int32 = start; var tmp1 bool; var tmp2 bool
	tmp2 = t.At_I_I_C__Z(p, n, 47); if tmp2 { tmp2 = t.At_I_I_C__Z(p+1, n, 47) }; tmp1 = tmp2; if tmp1 {
		p = p + 2
		var q int32 = t.Scan_I_I_String__I(p, n, Lit_1390)
		if q > p {
			p = t.ParseAuthority_I_I__I(p, q) } else {
				if q < n { } else { t.FailExpecting_String_I__V(Lit_1396, p) } } }
	var q_2 int32 = t.Scan_I_I_String__I(p, n, Lit_1397)
	t.CheckChars_I_I_J_J_String__V(p, q_2, 3458764316252045313, 5188146764422578175, Lit_57)
	t.F_this_0.F_path = NN(t.F_input).Substring_I_I__String(p, q_2)
	p = q_2
	if t.At_I_I_C__Z(p, n, 63) {
		p = p + 1
		q_2 = t.Scan_I_I_String__I(p, n, Lit_1132)
		t.CheckChars_I_I_J_J_String__V(p, q_2, -5764607720602730495, 5188146765093666815, Lit_1398)
		t.F_this_0.F_query = NN(t.F_input).Substring_I_I__String(p, q_2)
		p = q_2 }
//line :1110:1
	return p
}










func (t *URI_Parser) ParseAuthority_I_I__I(start, n int32) int32 {
	var p int32 = start; var q int32 = p; var qreg int32 = p; var ex *URISyntaxException
	var serverChars bool = false
	var regChars bool = false
	var skipParseException bool = false



	if t.Scan_I_I_String__I(p, n, Lit_1189) > p {
		serverChars = t.Scan_I_I_J_J__I(p, n, 3458623716202643457, 5188146765093666815) == n } else {
			serverChars = t.Scan_I_I_J_J__I(p, n, 3458623578763689985, 5188146765093666815) == n }
	var tmp1 int32; qreg = t.Scan_I_I_J_J__I(p, n, 3458623578763689985, 5188146764422578175); tmp1 = qreg; regChars = tmp1 == n
	var tmp2 bool; var tmp3 bool; tmp3 = regChars; if tmp3 { tmp3 = !serverChars }; tmp2 = tmp3; if tmp2 {
		t.F_this_0.F_authority = NN(t.F_input).Substring_I_I__String(p, n); return n } else {

			var tmp4 bool; var tmp5 bool; tmp5 = !t.F_requireServerAuthority; if tmp5 { tmp5 = regChars }; tmp4 = tmp5; skipParseException = tmp4
			if serverChars { tmp6 := func() (exc Throwable_I) { defer Catch(&exc)

				q = t.ParseServer_I_I_Z__I(p, n, skipParseException)
				if q < n {
					if skipParseException {
						t.F_this_0.F_userInfo = nil; t.F_this_0.F_host = nil; t.F_this_0.F_port = -1; q = p } else {
							t.FailExpecting_String_I__V(Lit_1399, q) } } else {
								t.F_this_0.F_authority = NN(t.F_input).Substring_I_I__String(p, n) }; return nil }()
//line :1139:1
				if tmp6 != nil { if URISyntaxException_InstanceOf(tmp6) { var x *URISyntaxException = URISyntaxException_Cast(tmp6)







					t.F_this_0.F_userInfo = nil
					t.F_this_0.F_host = nil
					t.F_this_0.F_port = -1
					if t.F_requireServerAuthority { panic(Thrown(Up_URISyntaxException_Throwable(x))) } else { ex = x; q = p } } else {
//line :1139:1
						panic(tmp6)
					}
				}
			}








			if q < n {
				if regChars {
					t.F_this_0.F_authority = NN(t.F_input).Substring_I_I__String(p, n) } else {
//line :1152:1
						if !(ex == nil) {

							panic(Thrown(Up_URISyntaxException_Throwable(ex))) } else {
								var tmp7 int32; if serverChars { tmp7 = q } else { tmp7 = qreg }; t.Fail_String_I__V(Lit_1400, tmp7) } } }
//line :1136:1
			return n
		}
}



















func (t *URI_Parser) ParseServer_I_I_Z__I(start, n int32, skipParseException bool) int32 {

	var p int32 = start
	var q int32 = 0
	q = t.Scan_I_I_String_String__I(p, n, Lit_1390, Lit_1401)
	var tmp1 bool; var tmp2 bool; tmp2 = q >= p; if tmp2 { tmp2 = t.At_I_I_C__Z(q, n, 64) }; tmp1 = tmp2; if tmp1 {
		t.CheckChars_I_I_J_J_String__V(p, q, 3458623578763689985, 5188146764422578174, Lit_1402)
		t.F_this_0.F_userInfo = NN(t.F_input).Substring_I_I__String(p, q)
		p = q + 1 }
	if t.At_I_I_C__Z(p, n, 91) {

		p = p + 1
		q = t.Scan_I_I_String_String__I(p, n, Lit_1390, Lit_1189)
		var tmp3 bool; var tmp4 bool; tmp4 = q > p; if tmp4 { tmp4 = t.At_I_I_C__Z(q, n, 93) }; tmp3 = tmp4; if tmp3 {
			var r int32 = t.Scan_I_I_String__I(p, q, Lit_1310)
			if r > p {

				t.ParseIPv6Reference_I_I__I(p, r)
				if r+1 == q { t.Fail_String__V(Lit_1403) }
				t.CheckChars_I_I_J_J_String__V(r+1, q, 288019269919178752, 576460745995190270, Lit_1404) } else {





					t.ParseIPv6Reference_I_I__I(p, q) }
			t.F_this_0.F_host = NN(t.F_input).Substring_I_I__String(p-1, q+1)

			p = q + 1 } else {
				t.FailExpecting_String_I__V(Lit_1405, q) } } else {

					q = t.ParseIPv4Address_I_I__I(p, n)
					if q <= p { q = t.ParseHostname_I_I_Z__I(p, n, skipParseException) }
					p = q }
	if t.At_I_I_C__Z(p, n, 58) {


		p = p + 1
		q = t.Scan_I_I_String__I(p, n, Lit_68)
		if q > p {
			t.CheckChars_I_I_J_J_String__V(p, q, 287948901175001088, 0, Lit_1406); tmp5 := func() (exc Throwable_I) { defer Catch(&exc)

				t.F_this_0.F_port = Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(t.F_input), p, q, 10); return nil }()
//line :1199:1
			if tmp5 != nil { if NumberFormatException_InstanceOf(tmp5) { var x *NumberFormatException = NumberFormatException_Cast(tmp5); _ = x

				t.Fail_String_I__V(Lit_1407, p) } else {
//line :1199:1
					panic(tmp5)
				}
			}
			p = q } } else {
//line :1192:1
				var tmp6 bool; var tmp7 bool










				tmp7 = p < n; if tmp7 { tmp7 = skipParseException }; tmp6 = tmp7
//line :1192:1
				if tmp6 {










					return p } }
	if p < n { t.FailExpecting_String_I__V(Lit_1406, p) }
//line :1160:1
	return p
}













































func (t *URI_Parser) ScanByte_I_I__I(start, n int32) int32 {
	var p int32 = start; var q int32 = t.Scan_I_I_J_J__I(p, n, 287948901175001088, 0)

	if q <= p { return q } else {

		var i int32 = p
		var j int32 = 0
	L1: for { var tmp1 int32; j = t.Scan_I_I_C__I(i, q, 48); tmp1 = j; if tmp1 > i { i = j; continue L1 }; break L1 }
		var significantDigitsNum int32 = q - i
		if significantDigitsNum < 3 { return q } else { if significantDigitsNum > 3 { return p } else { if Integer_ParseInt_CharSequence_I_I_I__I(Up_String_CharSequence(t.F_input), p, q, 10) > 255 { return p } else { return q
		}
		}
		}
	}
}
func (t *URI_Parser) ScanIPv4Address_I_I_Z__I(start, n int32, strict bool) int32 {

	var p int32 = start; var q int32 = 0; var m int32 = t.Scan_I_I_J_J__I(p, n, 288019269919178752, 0); var tmp1 bool; var tmp2 bool


	tmp2 = m <= p; if !tmp2 { var tmp3 bool; tmp3 = strict; if tmp3 { tmp3 = !(m == n) }; tmp2 = tmp3 }; tmp1 = tmp2; if tmp1 { return -1 } else {


	L1: for {
		var tmp4 int32; q = t.ScanByte_I_I__I(p, m); tmp4 = q; if tmp4 <= p { break L1 }
		p = q
		var tmp5 int32; q = t.Scan_I_I_C__I(p, m, 46); tmp5 = q; if tmp5 <= p { break L1 }
		p = q
		var tmp6 int32; q = t.ScanByte_I_I__I(p, m); tmp6 = q; if tmp6 <= p { break L1 }
		p = q
		var tmp7 int32; q = t.Scan_I_I_C__I(p, m, 46); tmp7 = q; if tmp7 <= p { break L1 }
		p = q
		var tmp8 int32; q = t.ScanByte_I_I__I(p, m); tmp8 = q; if tmp8 <= p { break L1 }
		p = q
		var tmp9 int32; q = t.Scan_I_I_C__I(p, m, 46); tmp9 = q; if tmp9 <= p { break L1 }
		p = q
		var tmp10 int32; q = t.ScanByte_I_I__I(p, m); tmp10 = q; if tmp10 <= p { break L1 }
		p = q
		if q < m { break L1 }
		return q
//line :1230:1
		continue L1
	}















		if strict { t.Fail_String_I__V(Lit_1408, q) }
//line :1229:1
		return -1
	}
}


















func (t *URI_Parser) TakeIPv4Address_I_I_String__I(start, n int32, expected *String) int32 {

	var p int32 = t.ScanIPv4Address_I_I_Z__I(start, n, true)
	if p <= start { t.FailExpecting_String_I__V(expected, start) }
//line :1252:1
	return p
}


func (t *URI_Parser) ParseIPv4Address_I_I__I(start, n int32) int32 {
	var p int32 = 0; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		p = t.ScanIPv4Address_I_I_Z__I(start, n, false); return nil }()
//line :1258:1
	if tmp1 != nil { if URISyntaxException_InstanceOf(tmp1) || NumberFormatException_InstanceOf(tmp1) { var x Exception_I = Exception_Cast(tmp1); _ = x

		return -1 } else {
//line :1258:1
			panic(tmp1)
		}
	}
	if p == -1 { return p } else {


		var tmp2 bool; var tmp3 bool; tmp3 = p > start; if tmp3 { tmp3 = p < n }; tmp2 = tmp3; if tmp2 { if int32(NN(t.F_input).CharAt_I__C(p)) == 58 { } else { return -1 } }
		if p > start { t.F_this_0.F_host = NN(t.F_input).Substring_I_I__String(start, p) }
//line :1263:1
		return p
	}
}


func (t *URI_Parser) ParseHostname_I_I_Z__I(start, n int32, skipParseException bool) int32 {

	var p int32 = start
	var q int32 = 0
	var l int32 = -1
L1: for {
	q = t.Scan_I_I_J_J__I(p, n, 287948901175001088, 576460743847706622)
	if q <= p { break L1 }
	l = p
	p = q
	q = t.Scan_I_I_J_J__I(p, n, 287984085547089920, 576460743847706622)
	if q > p {
		if int32(NN(t.F_input).CharAt_I__C(q-1)) == 45 {
			t.Fail_String_I__V(Lit_1409, q-1) }
		p = q }
	q = t.Scan_I_I_C__I(p, n, 46)
	if q <= p { break L1 }
	p = q
	if p < n { continue L1 }
//line :1273:1
	break L1
}












	var tmp1 bool; var tmp2 bool; tmp2 = p < n; if tmp2 { tmp2 = !t.At_I_I_C__Z(p, n, 58) }; tmp1 = tmp2; if tmp1 {
		if skipParseException { return p }
		t.Fail_String_I__V(Lit_1409, p) }
	if l < 0 { t.FailExpecting_String_I__V(Lit_1410, start) }
	var tmp3 bool; var tmp4 bool; tmp4 = l > start; if tmp4 { tmp4 = !URI_Match_C_J_J__Z(NN(t.F_input).CharAt_I__C(l), 0, 576460743847706622) }; tmp3 = tmp4; if tmp3 {
		t.Fail_String_I__V(Lit_1409, l) }
	t.F_this_0.F_host = NN(t.F_input).Substring_I_I__String(start, p)
//line :1270:1
	return p
}


























func (t *URI_Parser) ParseIPv6Reference_I_I__I(start, n int32) int32 {
	var p int32 = start
	var q int32 = 0
	var compressedZeros bool = false
	q = t.ScanHexSeq_I_I__I(p, n)
	if q > p {

		p = q
		if t.At_I_I_String__Z(p, n, Lit_1311) {

			compressedZeros = true
			p = t.ScanHexPost_I_I__I(p+2, n) } else {
				if t.At_I_I_C__Z(p, n, 58) {
					p = t.TakeIPv4Address_I_I_String__I(p+1, n, Lit_1411)
					t.F_ipv6byteCount = t.F_ipv6byteCount + 4 } } } else {
						if t.At_I_I_String__Z(p, n, Lit_1311) {
							compressedZeros = true
							p = t.ScanHexPost_I_I__I(p+2, n) } }
	if p < n { t.Fail_String_I__V(Lit_1412, start) }
	if t.F_ipv6byteCount > 16 { t.Fail_String_I__V(Lit_1413, start) }
	var tmp1 bool; var tmp2 bool; tmp2 = !compressedZeros; if tmp2 { tmp2 = t.F_ipv6byteCount < 16 }; tmp1 = tmp2; if tmp1 {
		t.Fail_String_I__V(Lit_1414, start) }
	var tmp3 bool; var tmp4 bool; tmp4 = compressedZeros; if tmp4 { tmp4 = t.F_ipv6byteCount == 16 }; tmp3 = tmp4; if tmp3 {
		t.Fail_String_I__V(Lit_1412, start) }
//line :1299:1
	return p
}























func (t *URI_Parser) ScanHexPost_I_I__I(start, n int32) int32 {
	var p int32 = start
	var q int32 = 0
	if p == n { return p } else {


		q = t.ScanHexSeq_I_I__I(p, n)
		if q > p {

			p = q
			if t.At_I_I_C__Z(p, n, 58) {
				p = p + 1
				p = t.TakeIPv4Address_I_I_String__I(p, n, Lit_1415)
				t.F_ipv6byteCount = t.F_ipv6byteCount + 4 } } else {

					p = t.TakeIPv4Address_I_I_String__I(p, n, Lit_1415)
					t.F_ipv6byteCount = t.F_ipv6byteCount + 4 }
//line :1329:1
		return p
	}
}











func (t *URI_Parser) ScanHexSeq_I_I__I(start, n int32) int32 {
	var p int32 = start
	var q int32 = 0
	q = t.Scan_I_I_J_J__I(p, n, 287948901175001088, 541165879422)
	if q <= p { return -1 } else { if t.At_I_I_C__Z(q, n, 46) { return -1 } else {




		if q > p+4 {
			t.Fail_String_I__V(Lit_1416, p) }
		t.F_ipv6byteCount = t.F_ipv6byteCount + 2
		p = q
	L1: for { if p < n {
		if t.At_I_I_C__Z(p, n, 58) { } else { break L1 }
		if t.At_I_I_C__Z(p+1, n, 58) { break L1 }
		p = p + 1
		q = t.Scan_I_I_J_J__I(p, n, 287948901175001088, 541165879422)
		if q <= p { t.FailExpecting_String_I__V(Lit_1417, p) }
		if t.At_I_I_C__Z(q, n, 46) { p = p - 1; break L1 }
		if q > p+4 {
			t.Fail_String_I__V(Lit_1416, p) }
		t.F_ipv6byteCount = t.F_ipv6byteCount + 2
		p = q
//line :1356:1
		continue L1 }; break L1 }
//line :1351:1
		return p
	}
	}
}















type URI struct{ Object; F_scheme, F_fragment, F_authority, F_userInfo, F_host *String; F_port int32; F_path, F_query, F_schemeSpecificPart *String; F_hash int32; F_decodedUserInfo, F_decodedAuthority, F_decodedPath, F_decodedQuery, F_decodedFragment, F_decodedSchemeSpecificPart *String; F_string atomic.Pointer[String] }

func (t *URI) Is_Comparable() {}

func (t *URI) Is_Serializable() {}

const URI_serialVersionUID int64 = -6052424284110960213

const URI_L_DIGIT int64 = 287948901175001088

const URI_H_DIGIT int64 = 0

const URI_L_UPALPHA int64 = 0

const URI_H_UPALPHA int64 = 134217726

const URI_L_LOWALPHA int64 = 0

const URI_H_LOWALPHA int64 = 576460743713488896

const URI_L_ALPHA int64 = 0

const URI_H_ALPHA int64 = 576460743847706622

const URI_L_ALPHANUM int64 = 287948901175001088

const URI_H_ALPHANUM int64 = 576460743847706622

const URI_L_HEX int64 = 287948901175001088

const URI_H_HEX int64 = 541165879422

const URI_L_MARK int64 = 113808043409408

const URI_H_MARK int64 = 4611686020574871552

const URI_L_UNRESERVED int64 = 288062709218410496

const URI_H_UNRESERVED int64 = 5188146764422578174

const URI_L_RESERVED int64 = -6052670429821140992

const URI_H_RESERVED int64 = 671088641

const URI_L_ESCAPED int64 = 1

const URI_H_ESCAPED int64 = 0

const URI_L_URIC int64 = -5764607720602730495

const URI_H_URIC int64 = 5188146765093666815

const URI_L_PCHAR int64 = 2882162826460266497

const URI_H_PCHAR int64 = 5188146764422578175

const URI_L_PATH int64 = 3458764316252045313

const URI_H_PATH int64 = 5188146764422578175

const URI_L_DASH int64 = 35184372088832

const URI_H_DASH int64 = 0

const URI_L_DOT int64 = 70368744177664

const URI_H_DOT int64 = 0

const URI_L_USERINFO int64 = 3458623578763689985

const URI_H_USERINFO int64 = 5188146764422578174

const URI_L_REG_NAME int64 = 3458623578763689985

const URI_H_REG_NAME int64 = 5188146764422578175

const URI_L_SERVER int64 = 3458623578763689985

const URI_H_SERVER int64 = 5188146765093666815

const URI_L_SERVER_PERCENT int64 = 3458623716202643457

const URI_H_SERVER_PERCENT int64 = 5188146765093666815

const URI_L_SCHEME int64 = 288063250384289792

const URI_H_SCHEME int64 = 576460743847706622

const URI_L_SCOPE_ID int64 = 288019269919178752

const URI_H_SCOPE_ID int64 = 576460745995190270

var URI_hexDigits *CharArray

var URI_init ClassInit

func URI_Init() { if !URI_init.Done() { URI_init.Run(URI_clinit) } }

func URI_clinit() { URI_hexDigits = CharArrayOf(48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70) }

func (t *URI) CompareTo_O__I(p0 any) int32 { return t.CompareTo_URI__I(URI_Cast(p0)) }

func (t *URI) Ref() any { if t == nil { return nil }; return t }

func (t *URI) GetClass__Class() *Class { return URI_class }

func (t *URI) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URI) CloneShallow() any { panic(CloneNotSupported(t)) }

func URI_InstanceOf(x any) bool { _, ok := x.(*URI); return ok }

func URI_Cast(x any) *URI { if x == nil { return nil }; v, ok := x.(*URI); if !ok { panic(ClassCast(x, URI_class)) }; return v }



type URI_Parser struct{ Object; F_input *String; F_requireServerAuthority bool; F_ipv6byteCount int32; F_this_0 *URI }

func (t *URI_Parser) Ref() any { if t == nil { return nil }; return t }

func (t *URI_Parser) GetClass__Class() *Class { return URI_Parser_class }

func (t *URI_Parser) ToString__String() *String { return Object_toString(t) }

func (t *URI_Parser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *URI_Parser) CloneShallow() any { panic(CloneNotSupported(t)) }

func URI_Parser_InstanceOf(x any) bool { _, ok := x.(*URI_Parser); return ok }

func URI_Parser_Cast(x any) *URI_Parser { if x == nil { return nil }; v, ok := x.(*URI_Parser); if !ok { panic(ClassCast(x, URI_Parser_class)) }; return v }
