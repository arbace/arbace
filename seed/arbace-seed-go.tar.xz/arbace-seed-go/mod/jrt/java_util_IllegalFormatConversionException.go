//line java_util_IllegalFormatConversionException.ae:1
package jrt












func IllegalFormatConversionException_New_C_Class(p0 uint16, p1 *Class) *IllegalFormatConversionException { t := &IllegalFormatConversionException{}; t.Ctor_C_Class(p0, p1); return t }
//line :14:1
func (t *IllegalFormatConversionException) Ctor_C_Class(c uint16, arg *Class) { t.IllegalFormatException.Ctor(t)
	if arg == nil { panic(Thrown(NullPointerException_New())) }
	t.F_c = c
	t.F_arg = arg
}
func (t *IllegalFormatConversionException) GetConversion__C() uint16 { return t.F_c }

func (t *IllegalFormatConversionException) GetArgumentClass__Class() *Class { return t.F_arg }

func (t *IllegalFormatConversionException) GetMessage__String() *String {
	var tmp1 any = Character_ValueOf_C__Character(t.F_c); return String_Format_String_O1__String(Lit_2728, RefArrayOf(Object_class, tmp1, NN(t.F_arg).GetName__String().Ref()))
}


type IllegalFormatConversionException struct{ IllegalFormatException; F_c uint16; F_arg *Class }

const IllegalFormatConversionException_serialVersionUID int64 = 17000126

func (t *IllegalFormatConversionException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalFormatConversionException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalFormatConversionException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalFormatConversionException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalFormatConversionException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalFormatConversionException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalFormatConversionException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalFormatConversionException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalFormatConversionException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalFormatConversionException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalFormatConversionException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalFormatConversionException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalFormatConversionException) GetClass__Class() *Class { return IllegalFormatConversionException_class }

func (t *IllegalFormatConversionException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalFormatConversionException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalFormatConversionException_InstanceOf(x any) bool { _, ok := x.(*IllegalFormatConversionException); return ok }

func IllegalFormatConversionException_Cast(x any) *IllegalFormatConversionException { if x == nil { return nil }; v, ok := x.(*IllegalFormatConversionException); if !ok { panic(ClassCast(x, IllegalFormatConversionException_class)) }; return v }
