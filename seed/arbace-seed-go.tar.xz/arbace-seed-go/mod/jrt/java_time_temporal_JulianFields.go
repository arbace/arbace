//line java_time_temporal_JulianFields.ae:1
package jrt

















func JulianFields_New() *JulianFields { JulianFields_Init(); t := &JulianFields{}; t.Ctor(); return t }
//line :19:1
func (t *JulianFields) Ctor() { panic(A2g_NotTranslated("java.time.temporal.JulianFields.<init>()V")) }




















func JulianFields_Field_New_String_I_String_TemporalUnit_TemporalUnit_J(p0 *String, p1 int32, p2 *String, p3, p4 TemporalUnit, p5 int64) *JulianFields_Field { JulianFields_Field_Init(); t := &JulianFields_Field{}; t.Ctor_String_I_String_TemporalUnit_TemporalUnit_J(p0, p1, p2, p3, p4, p5); return t }
//line :40:1
func (t *JulianFields_Field) Ctor_String_I_String_TemporalUnit_TemporalUnit_J(enumName *String, enumOrdinal int32, name *String, baseUnit, rangeUnit TemporalUnit, offset int64) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)

	t.F_name = name
	t.F_baseUnit = baseUnit
	t.F_rangeUnit = rangeUnit
	t.F_range = ValueRange_Of_J_J__ValueRange(-365243219162+offset, 365241780471+offset)


	t.F_offset = offset
}
func (t *JulianFields_Field) GetBaseUnit__TemporalUnit() TemporalUnit { return t.F_baseUnit }

func (t *JulianFields_Field) GetRangeUnit__TemporalUnit() TemporalUnit { return t.F_rangeUnit }

func (t *JulianFields_Field) IsDateBased__Z() bool { return true }

func (t *JulianFields_Field) IsTimeBased__Z() bool { return false }

func (t *JulianFields_Field) Range__ValueRange() *ValueRange { return t.F_range }

func (t *JulianFields_Field) IsSupportedBy_TemporalAccessor__Z(temporal TemporalAccessor) bool {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; return temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp1))
}
func (t *JulianFields_Field) RangeRefinedBy_TemporalAccessor__ValueRange(temporal TemporalAccessor) *ValueRange {
	if t.IsSupportedBy_TemporalAccessor__Z(temporal) == false {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2009, StrOfObj(t))))) }
	return t.Range__ValueRange()
}
func (t *JulianFields_Field) GetFrom_TemporalAccessor__J(temporal TemporalAccessor) int64 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; return temporal.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp1)) + t.F_offset
}
func (t *JulianFields_Field) AdjustInto_Temporal_J__Temporal(temporal Temporal, newValue int64) Temporal {

	if NN(t.Range__ValueRange()).IsValidValue_J__Z(newValue) == false {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2512, t.F_name, Lit_115, StrOfLong(newValue))))) }
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); return temporal.With_TemporalField_J__Temporal(tmp2, Math_SubtractExact_J_J__J(newValue, t.F_offset))
}
func (t *JulianFields_Field) Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(fieldValues Map, partialTemporal TemporalAccessor, resolverStyle *ResolverStyle) ChronoLocalDate {


	var value int64 = NN(Long_Cast(fieldValues.Remove_O__O(t))).LongValue__J(); var chrono Chronology = Chronology_From_TemporalAccessor__Chronology(partialTemporal); var tmp1 *ResolverStyle

	ResolverStyle_Init(); tmp1 = ResolverStyle_LENIENT; if resolverStyle == tmp1 {
		return chrono.DateEpochDay_J__ChronoLocalDate(Math_SubtractExact_J_J__J(value, t.F_offset)) } else {

			NN(t.Range__ValueRange()).CheckValidValue_J_TemporalField__J(value, t)
			return chrono.DateEpochDay_J__ChronoLocalDate(value - t.F_offset)
		} }
func (t *JulianFields_Field) ToString__String() *String { return t.F_name }



type JulianFields struct{ Object }

const JulianFields_JULIAN_DAY_OFFSET int64 = 2440588

var JulianFields_JULIAN_DAY TemporalField

var JulianFields_MODIFIED_JULIAN_DAY TemporalField

var JulianFields_RATA_DIE TemporalField

var JulianFields_init ClassInit

func JulianFields_Init() { if !JulianFields_init.Done() { JulianFields_init.Run(JulianFields_clinit) } }

func JulianFields_clinit() { var tmp1 *JulianFields_Field; JulianFields_Field_Init(); tmp1 = JulianFields_Field_JULIAN_DAY; JulianFields_JULIAN_DAY = Up_JulianFields_Field_TemporalField(tmp1); var tmp2 *JulianFields_Field; JulianFields_Field_Init(); tmp2 = JulianFields_Field_MODIFIED_JULIAN_DAY; JulianFields_MODIFIED_JULIAN_DAY = Up_JulianFields_Field_TemporalField(tmp2); var tmp3 *JulianFields_Field; JulianFields_Field_Init(); tmp3 = JulianFields_Field_RATA_DIE; JulianFields_RATA_DIE = Up_JulianFields_Field_TemporalField(tmp3) }

func (t *JulianFields) Ref() any { if t == nil { return nil }; return t }

func (t *JulianFields) GetClass__Class() *Class { return JulianFields_class }

func (t *JulianFields) ToString__String() *String { return Object_toString(t) }

func (t *JulianFields) Clone__O() any { return A2g_ObjectClone(t) }

func (t *JulianFields) CloneShallow() any { panic(CloneNotSupported(t)) }

func JulianFields_InstanceOf(x any) bool { _, ok := x.(*JulianFields); return ok }

func JulianFields_Cast(x any) *JulianFields { if x == nil { return nil }; v, ok := x.(*JulianFields); if !ok { panic(ClassCast(x, JulianFields_class)) }; return v }



type JulianFields_Field struct{ Enum; F_name *String; F_baseUnit, F_rangeUnit TemporalUnit; F_range *ValueRange; F_offset int64 }

func (t *JulianFields_Field) Is_TemporalField() {}

func (t *JulianFields_Field) Is_Constable() {}

var JulianFields_Field_JULIAN_DAY *JulianFields_Field

var JulianFields_Field_MODIFIED_JULIAN_DAY *JulianFields_Field

var JulianFields_Field_RATA_DIE *JulianFields_Field

var JulianFields_Field__VALUES *RefArray

var JulianFields_Field_init ClassInit

func JulianFields_Field_Init() { if !JulianFields_Field_init.Done() { JulianFields_Field_init.Run(JulianFields_Field_clinit) } }

func JulianFields_Field_clinit() { var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_DAYS; var tmp2 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp1); var tmp3 *ChronoUnit; ChronoUnit_Init(); tmp3 = ChronoUnit_FOREVER; JulianFields_Field_JULIAN_DAY = JulianFields_Field_New_String_I_String_TemporalUnit_TemporalUnit_J(Lit_2507, 0, Lit_2506, tmp2, Up_ChronoUnit_TemporalUnit(tmp3), 2440588); var tmp4 *ChronoUnit; ChronoUnit_Init(); tmp4 = ChronoUnit_DAYS; var tmp5 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp4); var tmp6 *ChronoUnit; ChronoUnit_Init(); tmp6 = ChronoUnit_FOREVER; JulianFields_Field_MODIFIED_JULIAN_DAY = JulianFields_Field_New_String_I_String_TemporalUnit_TemporalUnit_J(Lit_2509, 1, Lit_2508, tmp5, Up_ChronoUnit_TemporalUnit(tmp6), 40587); var tmp7 *ChronoUnit; ChronoUnit_Init(); tmp7 = ChronoUnit_DAYS; var tmp8 TemporalUnit = Up_ChronoUnit_TemporalUnit(tmp7); var tmp9 *ChronoUnit; ChronoUnit_Init(); tmp9 = ChronoUnit_FOREVER; JulianFields_Field_RATA_DIE = JulianFields_Field_New_String_I_String_TemporalUnit_TemporalUnit_J(Lit_2511, 2, Lit_2510, tmp8, Up_ChronoUnit_TemporalUnit(tmp9), 719163); JulianFields_Field__VALUES = JulianFields_Field_X_values__JulianFields_Field1() }

func JulianFields_Field_Values__JulianFields_Field1() *RefArray { JulianFields_Field_Init(); return JulianFields_Field__VALUES.Copy() }

func JulianFields_Field_ValueOf_String__JulianFields_Field(p0 *String) *JulianFields_Field { JulianFields_Field_Init(); return JulianFields_Field_Cast(Enum_ValueOf_Class_String__Enum(JulianFields_Field_class, p0)) }

func JulianFields_Field_X_values__JulianFields_Field1() *RefArray { JulianFields_Field_Init(); return RefArrayOf(JulianFields_Field_class, JulianFields_Field_JULIAN_DAY, JulianFields_Field_MODIFIED_JULIAN_DAY, JulianFields_Field_RATA_DIE) }

func (t *JulianFields_Field) Resolve_Map_TemporalAccessor_ResolverStyle__TemporalAccessor(p0 Map, p1 TemporalAccessor, p2 *ResolverStyle) TemporalAccessor { return t.Resolve_Map_TemporalAccessor_ResolverStyle__ChronoLocalDate(p0, p1, p2) }

func (t *JulianFields_Field) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.JulianFields$Field.describeConstable()Ljava/util/Optional;")) }

func (t *JulianFields_Field) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *JulianFields_Field) GetDisplayName_Locale__String(p0 *Locale) *String { return TemporalField_GetDisplayName_Locale__String(t, p0) }

func (t *JulianFields_Field) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *JulianFields_Field) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *JulianFields_Field) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *JulianFields_Field) Ref() any { if t == nil { return nil }; return t }

func (t *JulianFields_Field) GetClass__Class() *Class { return JulianFields_Field_class }

func (t *JulianFields_Field) CloneShallow() any { panic(CloneNotSupported(t)) }

func JulianFields_Field_InstanceOf(x any) bool { _, ok := x.(*JulianFields_Field); return ok }

func JulianFields_Field_Cast(x any) *JulianFields_Field { if x == nil { return nil }; v, ok := x.(*JulianFields_Field); if !ok { panic(ClassCast(x, JulianFields_Field_class)) }; return v }
