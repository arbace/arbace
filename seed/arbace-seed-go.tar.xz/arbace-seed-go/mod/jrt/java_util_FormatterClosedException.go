//line java_util_FormatterClosedException.ae:1
package jrt








func FormatterClosedException_New() *FormatterClosedException { t := &FormatterClosedException{}; t.Ctor(); return t }
//line :10:1
func (t *FormatterClosedException) Ctor() { t.IllegalStateException.Ctor(t) }





type FormatterClosedException struct{ IllegalStateException }

const FormatterClosedException_serialVersionUID int64 = 18111216

func (t *FormatterClosedException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *FormatterClosedException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *FormatterClosedException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *FormatterClosedException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *FormatterClosedException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *FormatterClosedException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *FormatterClosedException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *FormatterClosedException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *FormatterClosedException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *FormatterClosedException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *FormatterClosedException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *FormatterClosedException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *FormatterClosedException) Ref() any { if t == nil { return nil }; return t }

func (t *FormatterClosedException) GetClass__Class() *Class { return FormatterClosedException_class }

func (t *FormatterClosedException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FormatterClosedException) CloneShallow() any { panic(CloneNotSupported(t)) }

func FormatterClosedException_InstanceOf(x any) bool { _, ok := x.(*FormatterClosedException); return ok }

func FormatterClosedException_Cast(x any) *FormatterClosedException { if x == nil { return nil }; v, ok := x.(*FormatterClosedException); if !ok { panic(ClassCast(x, FormatterClosedException_class)) }; return v }
