//line java_text_CollationElementIterator.ae:1
package jrt










func CollationElementIterator_New_String_RuleBasedCollator(p0 *String, p1 *RuleBasedCollator) *CollationElementIterator { t := &CollationElementIterator{}; t.Ctor_String_RuleBasedCollator(p0, p1); return t }
//line :12:1
func (t *CollationElementIterator) Ctor_String_RuleBasedCollator(sourceText *String, owner *RuleBasedCollator) { t.F_text = nil; t.F_buffer = nil; t.F_expIndex = 0; t.F_key = StringBuilder_New_I(5); t.F_swapOrder = 0
	t.F_owner = owner
	t.F_ordering = NN(owner).GetTables__RBCollationTables()
	if NN(sourceText).IsEmpty__Z() { } else {
		var mode NormalizerBase_Mode_I = CollatorUtilities_ToNormalizerMode_I__NormalizerBase_Mode(NN(owner).GetDecomposition__I())
		t.F_text = NormalizerBase_New_String_NormalizerBase_Mode(sourceText, mode)
	} }
func CollationElementIterator_New_CharacterIterator_RuleBasedCollator(p0 CharacterIterator, p1 *RuleBasedCollator) *CollationElementIterator { t := &CollationElementIterator{}; t.Ctor_CharacterIterator_RuleBasedCollator(p0, p1); return t }
//line :19:1
func (t *CollationElementIterator) Ctor_CharacterIterator_RuleBasedCollator(sourceText CharacterIterator, owner *RuleBasedCollator) { t.F_text = nil; t.F_buffer = nil; t.F_expIndex = 0; t.F_key = StringBuilder_New_I(5); t.F_swapOrder = 0
	t.F_owner = owner
	t.F_ordering = NN(owner).GetTables__RBCollationTables()
	var mode NormalizerBase_Mode_I = CollatorUtilities_ToNormalizerMode_I__NormalizerBase_Mode(NN(owner).GetDecomposition__I())
	t.F_text = NormalizerBase_New_CharacterIterator_NormalizerBase_Mode(sourceText, mode)
}
func (t *CollationElementIterator) Reset__V() {
	if !(t.F_text == nil) {
		NN(t.F_text).Reset__V()
		var mode NormalizerBase_Mode_I = CollatorUtilities_ToNormalizerMode_I__NormalizerBase_Mode(NN(t.F_owner).GetDecomposition__I())
		NN(t.F_text).SetMode_NormalizerBase_Mode__V(mode) }
	t.F_buffer = nil
	t.F_expIndex = 0
	t.F_swapOrder = 0
}
func (t *CollationElementIterator) Next__I() int32 {
	if t.F_text == nil { return -1 } else {

		var textMode NormalizerBase_Mode_I = NN(t.F_text).GetMode__NormalizerBase_Mode(); var ownerMode NormalizerBase_Mode_I = CollatorUtilities_ToNormalizerMode_I__NormalizerBase_Mode(NN(t.F_owner).GetDecomposition__I())

		if textMode == ownerMode { } else { NN(t.F_text).SetMode_NormalizerBase_Mode__V(ownerMode) }
		if !(t.F_buffer == nil) {
			var tmp1 int32 = t.F_expIndex; if tmp1 < int32(len(t.F_buffer.A)) {
				var tmp2 *IntArray = t.F_buffer; var tmp3 int32; var old_1 int32 = t.F_expIndex


				t.F_expIndex = t.F_expIndex + 1
//line :44:1
				tmp3 = old_1
//line :42:1
				return t.StrengthOrder_I__I(tmp2.A[tmp3])

			} else {


				t.F_buffer = nil; t.F_expIndex = 0 } } else {
					if t.F_swapOrder == 0 { } else {
						if Character_IsSupplementaryCodePoint_I__Z(t.F_swapOrder) {
							var chars *CharArray = Character_ToChars_I__C1(t.F_swapOrder)
							t.F_swapOrder = int32(chars.A[1])
							return int32(chars.A[0]) << 16 }
						var order int32 = t.F_swapOrder << 16; t.F_swapOrder = 0; return order } }
		var ch int32 = NN(t.F_text).Next__I()
		if ch == -1 { return -1 } else {

			var value int32 = NN(t.F_ordering).GetUnicodeOrder_I__I(ch)
			if value == -1 {
				t.F_swapOrder = ch; return 2147418112 } else {

					if value >= 2130706432 {
						value = t.NextContractChar_I__I(ch) }
					if value >= 2113929216 {
						t.F_buffer = NN(t.F_ordering).GetExpandValueList_I__I1(value)
						t.F_expIndex = 0
						var tmp4 *IntArray = t.F_buffer; var tmp5 int32; var old_2 int32 = t.F_expIndex


						t.F_expIndex = t.F_expIndex + 1
//line :68:1
						tmp5 = old_2
//line :66:1
						value = tmp4.A[tmp5]
					}



					if NN(t.F_ordering).IsSEAsianSwapping__Z() {
						var consonant int32 = 0
						if CollationElementIterator_IsThaiPreVowel_I__Z(ch) {
							consonant = NN(t.F_text).Next__I()
							if CollationElementIterator_IsThaiBaseConsonant_I__Z(consonant) {

								t.F_buffer = t.MakeReorderedBuffer_I_I_I1_Z__I1(consonant, value, t.F_buffer, true)

								value = t.F_buffer.A[0]
								t.F_expIndex = 1 } else {
									if consonant == -1 { } else { NN(t.F_text).Previous__I() } } }
						if CollationElementIterator_IsLaoPreVowel_I__Z(ch) {
							consonant = NN(t.F_text).Next__I()
							if CollationElementIterator_IsLaoBaseConsonant_I__Z(consonant) {

								t.F_buffer = t.MakeReorderedBuffer_I_I_I1_Z__I1(consonant, value, t.F_buffer, true)

								value = t.F_buffer.A[0]
								t.F_expIndex = 1 } else {
									if consonant == -1 { } else { NN(t.F_text).Previous__I() } } } }
					return t.StrengthOrder_I__I(value)
				} } } }
func (t *CollationElementIterator) Previous__I() int32 {
	if t.F_text == nil { return -1 } else {

		var textMode NormalizerBase_Mode_I = NN(t.F_text).GetMode__NormalizerBase_Mode(); var ownerMode NormalizerBase_Mode_I = CollatorUtilities_ToNormalizerMode_I__NormalizerBase_Mode(NN(t.F_owner).GetDecomposition__I())

		if textMode == ownerMode { } else { NN(t.F_text).SetMode_NormalizerBase_Mode__V(ownerMode) }
		if !(t.F_buffer == nil) {
			if t.F_expIndex > 0 {
				var tmp1 *IntArray = t.F_buffer; var tmp2 int32; var tmp3 int32 = t.F_expIndex - 1

				t.F_expIndex = tmp3; tmp2 = tmp3
//line :101:1
				return t.StrengthOrder_I__I(tmp1.A[tmp2])
			} else {

				t.F_buffer = nil; t.F_expIndex = 0 } } else {
					if t.F_swapOrder == 0 { } else {
						if Character_IsSupplementaryCodePoint_I__Z(t.F_swapOrder) {
							var chars *CharArray = Character_ToChars_I__C1(t.F_swapOrder)
							t.F_swapOrder = int32(chars.A[1])
							return int32(chars.A[0]) << 16 }
						var order int32 = t.F_swapOrder << 16; t.F_swapOrder = 0; return order } }
		var ch int32 = NN(t.F_text).Previous__I()
		if ch == -1 { return -1 } else {

			var value int32 = NN(t.F_ordering).GetUnicodeOrder_I__I(ch)
			if value == -1 {
				t.F_swapOrder = 2147418112; return ch } else {

					if value >= 2130706432 {
						value = t.PrevContractChar_I__I(ch) }
					if value >= 2113929216 {
						t.F_buffer = NN(t.F_ordering).GetExpandValueList_I__I1(value)
						t.F_expIndex = int32(len(t.F_buffer.A))
						var tmp4 *IntArray = t.F_buffer; var tmp5 int32; var tmp6 int32 = t.F_expIndex - 1; t.F_expIndex = tmp6; tmp5 = tmp6; value = tmp4.A[tmp5] }
					if NN(t.F_ordering).IsSEAsianSwapping__Z() {
						var vowel int32 = 0
						if CollationElementIterator_IsThaiBaseConsonant_I__Z(ch) {
							vowel = NN(t.F_text).Previous__I()
							if CollationElementIterator_IsThaiPreVowel_I__Z(vowel) {

								t.F_buffer = t.MakeReorderedBuffer_I_I_I1_Z__I1(vowel, value, t.F_buffer, false)

								t.F_expIndex = int32(len(t.F_buffer.A)) - 1
								value = t.F_buffer.A[t.F_expIndex] } else {
									NN(t.F_text).Next__I() } }
						if CollationElementIterator_IsLaoBaseConsonant_I__Z(ch) {
							vowel = NN(t.F_text).Previous__I()
							if CollationElementIterator_IsLaoPreVowel_I__Z(vowel) {

								t.F_buffer = t.MakeReorderedBuffer_I_I_I1_Z__I1(vowel, value, t.F_buffer, false)

								t.F_expIndex = int32(len(t.F_buffer.A)) - 1
								value = t.F_buffer.A[t.F_expIndex] } else {
									NN(t.F_text).Next__I() } } }
					return t.StrengthOrder_I__I(value)
				} } } }
func CollationElementIterator_PrimaryOrder_I__I(order int32) int32 {
	order = order & -65536
	return int32(uint32(order) >> 16)
}
func CollationElementIterator_SecondaryOrder_I__S(order int32) int16 {
	order = order & 65280
	return int16(order >> 8)
}
func CollationElementIterator_TertiaryOrder_I__S(order int32) int16 {
	var tmp1 int32; order = order & 255; tmp1 = order; return int16(tmp1)
}
func (t *CollationElementIterator) StrengthOrder_I__I(order int32) int32 {
	var s int32 = NN(t.F_owner).GetStrength__I()
	if s == 0 {

		order = order & -65536 } else {
//line :159:1
			if s == 1 {



				order = order & -256 } }
//line :158:1
	return order
}






func (t *CollationElementIterator) SetOffset_I__V(newOffset int32) {
	if !(t.F_text == nil) {
		var tmp1 bool; var tmp2 bool; tmp2 = newOffset < NN(t.F_text).GetBeginIndex__I(); if !tmp2 { tmp2 = newOffset >= NN(t.F_text).GetEndIndex__I() }; tmp1 = tmp2; if tmp1 {
			NN(t.F_text).SetIndexOnly_I__V(newOffset) } else {
				var c int32 = NN(t.F_text).SetIndex_I__I(newOffset)
				if NN(t.F_ordering).UsedInContractSeq_I__Z(c) {
				L1: for { if NN(t.F_ordering).UsedInContractSeq_I__Z(c) { c = NN(t.F_text).Previous__I(); continue L1 }; break L1 }
					var last int32 = NN(t.F_text).GetIndex__I()
				L2: for { if NN(t.F_text).GetIndex__I() <= newOffset { last = NN(t.F_text).GetIndex__I(); t.Next__I(); continue L2 }; break L2 }
					NN(t.F_text).SetIndexOnly_I__V(last) } } }
	t.F_buffer = nil
	t.F_expIndex = 0
	t.F_swapOrder = 0
}
func (t *CollationElementIterator) GetOffset__I() int32 {
	if !(t.F_text == nil) { return NN(t.F_text).GetIndex__I() } else { return 0
	} }
func (t *CollationElementIterator) GetMaxExpansion_I__I(order int32) int32 {
	return NN(t.F_ordering).GetMaxExpansion_I__I(order)
}
func (t *CollationElementIterator) SetText_String__V(source *String) {
	t.F_buffer = nil
	t.F_swapOrder = 0
	t.F_expIndex = 0
	var mode NormalizerBase_Mode_I = CollatorUtilities_ToNormalizerMode_I__NormalizerBase_Mode(NN(t.F_owner).GetDecomposition__I())
	if t.F_text == nil {
		t.F_text = NormalizerBase_New_String_NormalizerBase_Mode(source, mode) } else {
			NN(t.F_text).SetMode_NormalizerBase_Mode__V(mode); NN(t.F_text).SetText_String__V(source)
		} }
func (t *CollationElementIterator) SetText_CharacterIterator__V(source CharacterIterator) {
	t.F_buffer = nil
	t.F_swapOrder = 0
	t.F_expIndex = 0
	var mode NormalizerBase_Mode_I = CollatorUtilities_ToNormalizerMode_I__NormalizerBase_Mode(NN(t.F_owner).GetDecomposition__I())
	if t.F_text == nil {
		t.F_text = NormalizerBase_New_CharacterIterator_NormalizerBase_Mode(source, mode) } else {
			NN(t.F_text).SetMode_NormalizerBase_Mode__V(mode); NN(t.F_text).SetText_CharacterIterator__V(source)
		} }
func CollationElementIterator_IsThaiPreVowel_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = ch >= 3648; if tmp1 { tmp1 = ch <= 3652 }; return tmp1
}
func CollationElementIterator_IsThaiBaseConsonant_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = ch >= 3585; if tmp1 { tmp1 = ch <= 3630 }; return tmp1
}
func CollationElementIterator_IsLaoPreVowel_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = ch >= 3776; if tmp1 { tmp1 = ch <= 3780 }; return tmp1
}
func CollationElementIterator_IsLaoBaseConsonant_I__Z(ch int32) bool {
	var tmp1 bool; tmp1 = ch >= 3713; if tmp1 { tmp1 = ch <= 3758 }; return tmp1
}
func (t *CollationElementIterator) MakeReorderedBuffer_I_I_I1_Z__I1(colFirst, lastValue int32, lastExpansion *IntArray, forward bool) *IntArray {

	var result *IntArray; var firstValue int32 = NN(t.F_ordering).GetUnicodeOrder_I__I(colFirst)

	if firstValue >= 2130706432 {
		var tmp1 int32
		if forward { tmp1 = t.NextContractChar_I__I(colFirst) } else { tmp1 = t.PrevContractChar_I__I(colFirst) }
//line :221:1
		firstValue = tmp1
	}
	var firstExpansion *IntArray
	if firstValue >= 2113929216 {
		firstExpansion = NN(t.F_ordering).GetExpandValueList_I__I1(firstValue) }
	if forward { } else {
		var temp1 int32 = firstValue
		firstValue = lastValue
		lastValue = temp1
		var temp2 *IntArray = firstExpansion
		firstExpansion = lastExpansion
		lastExpansion = temp2 }
	var tmp2 bool; var tmp3 bool; tmp3 = firstExpansion == nil; if tmp3 { tmp3 = lastExpansion == nil }; tmp2 = tmp3; if tmp2 {
		result = NewIntArray(2); result.A[0] = firstValue; result.A[1] = lastValue } else {
			var firstLength int32; if firstExpansion == nil { firstLength = 1 } else { firstLength = int32(len(firstExpansion.A)) }; var lastLength int32
			if lastExpansion == nil { lastLength = 1 } else { lastLength = int32(len(lastExpansion.A)) }
			result = NewIntArray(firstLength + lastLength)
			if firstExpansion == nil {
				result.A[0] = firstValue } else {
					System_Arraycopy_O_I_O_I_I__V(firstExpansion.Ref(), 0, result.Ref(), 0, firstLength) }
			if lastExpansion == nil {
				result.A[firstLength] = lastValue } else {
					System_Arraycopy_O_I_O_I_I__V(lastExpansion.Ref(), 0, result.Ref(), firstLength, lastLength) } }
//line :223:1
	return result
}





















func CollationElementIterator_IsIgnorable_I__Z(order int32) bool {
	if CollationElementIterator_PrimaryOrder_I__I(order) == 0 { return true } else { return false
	} }
func (t *CollationElementIterator) NextContractChar_I__I(ch int32) int32 {
	var list Vector_I = NN(t.F_ordering).GetContractValues_I__Vector(ch); var pair *EntryPair = EntryPair_Cast(list.FirstElement__O()); var order int32 = pair.F_value


	pair = EntryPair_Cast(list.LastElement__O())
	var maxLength int32 = NN(pair.F_entryName).Length__I(); var tempText *NormalizerBase = NN(t.F_text).Clone__NormalizerBase()

	NN(tempText).Previous__I()
	NN(t.F_key).SetLength_I__V(0)
	var c int32 = NN(tempText).Next__I()
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = maxLength > 0; if tmp2 { tmp2 = !(c == -1) }; tmp1 = tmp2; if tmp1 {
	if Character_IsSupplementaryCodePoint_I__Z(c) {

		var tmp3 *StringBuilder = t.F_key; NN(tmp3).Append_C1__StringBuilder(Character_ToChars_I__C1(c))
		maxLength = maxLength - 2 } else {
			NN(t.F_key).Append_C__StringBuilder(uint16(c)); maxLength = maxLength - 1 }
	c = NN(tempText).Next__I()
//line :259:1
	continue L1 }; break L1
}





	var fragment *String = NN(t.F_key).ToString__String()
	maxLength = 1
	var i int32 = list.Size__I() - 1; L2: for {
		if i > 0 {
			pair = EntryPair_Cast(list.ElementAt_I__O(i))
			if !pair.F_fwd {
				i = i - 1; continue L2 } else {
//line :271:1
					var tmp4 bool; var tmp5 bool

					tmp5 = NN(fragment).StartsWith_String__Z(pair.F_entryName); if tmp5 {
						tmp5 = NN(pair.F_entryName).Length__I() > maxLength }
//line :273:1
					tmp4 = tmp5
//line :271:1
					if tmp4 {




						maxLength = NN(pair.F_entryName).Length__I()
						order = pair.F_value
						i = i - 1; continue L2 } else {
							i = i - 1; continue L2 } } }
//line :268:1
		break L2
	}










L3: for { if maxLength > 1 {
	c = NN(t.F_text).Next__I()
	maxLength = maxLength - Character_CharCount_I__I(c)
//line :280:1
	continue L3 }; break L3 }
//line :266:1
	return order
}

















func (t *CollationElementIterator) PrevContractChar_I__I(ch int32) int32 {
	var list Vector_I = NN(t.F_ordering).GetContractValues_I__Vector(ch); var pair *EntryPair = EntryPair_Cast(list.FirstElement__O()); var order int32 = pair.F_value


	pair = EntryPair_Cast(list.LastElement__O())
	var maxLength int32 = NN(pair.F_entryName).Length__I(); var tempText *NormalizerBase = NN(t.F_text).Clone__NormalizerBase()

	NN(tempText).Next__I()
	NN(t.F_key).SetLength_I__V(0)
	var c int32 = NN(tempText).Previous__I()
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = maxLength > 0; if tmp2 { tmp2 = !(c == -1) }; tmp1 = tmp2; if tmp1 {
	if Character_IsSupplementaryCodePoint_I__Z(c) {

		var tmp3 *StringBuilder = t.F_key; NN(tmp3).Append_C1__StringBuilder(Character_ToChars_I__C1(c))
		maxLength = maxLength - 2 } else {
			NN(t.F_key).Append_C__StringBuilder(uint16(c)); maxLength = maxLength - 1 }
	c = NN(tempText).Previous__I()
//line :295:1
	continue L1 }; break L1
}





	var fragment *String = NN(t.F_key).ToString__String()
	maxLength = 1
	var i int32 = list.Size__I() - 1; L2: for {
		if i > 0 {
			pair = EntryPair_Cast(list.ElementAt_I__O(i))
			if pair.F_fwd {
				i = i - 1; continue L2 } else {
//line :307:1
					var tmp4 bool; var tmp5 bool

					tmp5 = NN(fragment).StartsWith_String__Z(pair.F_entryName); if tmp5 {
						tmp5 = NN(pair.F_entryName).Length__I() > maxLength }
//line :309:1
					tmp4 = tmp5
//line :307:1
					if tmp4 {




						maxLength = NN(pair.F_entryName).Length__I()
						order = pair.F_value
						i = i - 1; continue L2 } else {
							i = i - 1; continue L2 } } }
//line :304:1
		break L2
	}










L3: for { if maxLength > 1 {
	c = NN(t.F_text).Previous__I()
	maxLength = maxLength - Character_CharCount_I__I(c)
//line :316:1
	continue L3 }; break L3 }
//line :302:1
	return order
}


















type CollationElementIterator struct{ Object; F_text *NormalizerBase; F_buffer *IntArray; F_expIndex int32; F_key *StringBuilder; F_swapOrder int32; F_ordering *RBCollationTables; F_owner *RuleBasedCollator }

const CollationElementIterator_NULLORDER int32 = -1

const CollationElementIterator_UNMAPPEDCHARVALUE int32 = 2147418112

func (t *CollationElementIterator) Ref() any { if t == nil { return nil }; return t }

func (t *CollationElementIterator) GetClass__Class() *Class { return CollationElementIterator_class }

func (t *CollationElementIterator) ToString__String() *String { return Object_toString(t) }

func (t *CollationElementIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CollationElementIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func CollationElementIterator_InstanceOf(x any) bool { _, ok := x.(*CollationElementIterator); return ok }

func CollationElementIterator_Cast(x any) *CollationElementIterator { if x == nil { return nil }; v, ok := x.(*CollationElementIterator); if !ok { panic(ClassCast(x, CollationElementIterator_class)) }; return v }
