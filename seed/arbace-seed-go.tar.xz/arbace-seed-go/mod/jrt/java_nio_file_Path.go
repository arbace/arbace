//line java_nio_file_Path.ae:1
package jrt











func Path_Of_String_String1__Path(first *String, more *RefArray) Path {
	return HostPath_Of_String_String1__Path(first, more)
}
func Path_Of_URI__Path(uri *URI) Path { return HostPath_Of_URI__Path(uri) }

















func Path_StartsWith_String__Z(this Path, other *String) bool {
	return this.StartsWith_Path__Z(Path_Of_String_String1__Path(other, RefArrayOf(String_class)))
}


func Path_EndsWith_String__Z(this Path, other *String) bool {
	return this.EndsWith_Path__Z(Path_Of_String_String1__Path(other, RefArrayOf(String_class)))
}




func Path_Resolve_String__Path(this Path, other *String) Path {
	return this.Resolve_Path__Path(Path_Of_String_String1__Path(other, RefArrayOf(String_class)))
}
func Path_Resolve_Path_Path1__Path(this, first Path, more *RefArray) Path {
	var result Path = this.Resolve_Path__Path(first); var arr_101182 *RefArray = more; var len_101183 int32 = int32(len(arr_101182.A)); var i_101184 int32 = 0; for ; i_101184 < len_101183; i_101184++ {
		var p Path = As[Path](arr_101182.A[i_101184]); result = result.Resolve_Path__Path(p) }
//line :50:1
	return result
}


func Path_Resolve_String_String1__Path(this Path, first *String, more *RefArray) Path {
	var result Path = this.Resolve_String__Path(first); var arr_101185 *RefArray = more; var len_101186 int32 = int32(len(arr_101185.A)); var i_101187 int32 = 0; for ; i_101187 < len_101186; i_101187++ {
		var s *String = As[*String](arr_101185.A[i_101187]); result = result.Resolve_String__Path(s) }
//line :55:1
	return result
}


func Path_ResolveSibling_Path__Path(this, other Path) Path {
	if other == nil { panic(Thrown(NullPointerException_New())) }
	var parent Path = this.GetParent__Path(); if parent == nil { return other } else { return parent.Resolve_Path__Path(other)
	} }
func Path_ResolveSibling_String__Path(this Path, other *String) Path {
	return this.ResolveSibling_Path__Path(Path_Of_String_String1__Path(other, RefArrayOf(String_class)))
}








func Path_ToFile__File(this Path) *File { return File_New_String(this.ToString__String()) }

func Path_Iterator__Iterator(this Path) Iterator {
	return Path_1_New_Path(this)
}

func (t *Path_1) HasNext__Z() bool {
	var tmp1 int32 = t.F_i; return tmp1 < t.F_this_0.GetNameCount__I()
}
func (t *Path_1) Next__Path() Path {
	var tmp1 int32 = t.F_i; if tmp1 < t.F_this_0.GetNameCount__I() {
		var result Path = t.F_this_0.GetName_I__Path(t.F_i); t.F_i = t.F_i + 1; return result } else {
			panic(Thrown(NoSuchElementException_New()))
		}
}

type Path interface{ Object_I; Comparable; Iterable; Is_Path(); IsAbsolute__Z() bool; GetRoot__Path() Path; GetFileName__Path() Path; GetParent__Path() Path; GetNameCount__I() int32; GetName_I__Path(p0 int32) Path; Subpath_I_I__Path(p0, p1 int32) Path; StartsWith_Path__Z(p0 Path) bool; StartsWith_String__Z(p0 *String) bool; EndsWith_Path__Z(p0 Path) bool; EndsWith_String__Z(p0 *String) bool; Normalize__Path() Path; Resolve_Path__Path(p0 Path) Path; Resolve_String__Path(p0 *String) Path; Resolve_Path_Path1__Path(p0 Path, p1 *RefArray) Path; Resolve_String_String1__Path(p0 *String, p1 *RefArray) Path; ResolveSibling_Path__Path(p0 Path) Path; ResolveSibling_String__Path(p0 *String) Path; Relativize_Path__Path(p0 Path) Path; ToUri__URI() *URI; ToAbsolutePath__Path() Path; ToRealPath_LinkOption1__Path(p0 *RefArray) Path; ToFile__File() *File; Iterator__Iterator() Iterator; CompareTo_Path__I(p0 Path) int32; CompareTo_O__I(p0 any) int32 }

func Path_CompareTo_O__I(this Path, p0 any) int32 { return this.CompareTo_Path__I(Path_Cast(p0)) }

func Path_InstanceOf(x any) bool { _, ok := x.(Path); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Path_class) } }; return ok }

func Path_Cast(x any) Path { if x == nil { return nil }; v, ok := x.(Path); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Path_class) } }; if !ok { panic(ClassCast(x, Path_class)) }; return v }



type Path_1 struct{ Object; F_i int32; F_this_0 Path }

func (t *Path_1) Is_Iterator() {}

func Path_1_New_Path(p0 Path) *Path_1 { t := &Path_1{}; t.Ctor_Path(p0); return t }

func (t *Path_1) Ctor_Path(this_0 Path) { A2g_NotNull[Path](this_0); t.F_this_0 = this_0; t.F_i = 0 }

func (t *Path_1) Next__O() any { return t.Next__Path() }

func (t *Path_1) Remove__V() { Iterator_Remove__V(t) }

func (t *Path_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *Path_1) Ref() any { if t == nil { return nil }; return t }

func (t *Path_1) GetClass__Class() *Class { return Path_1_class }

func (t *Path_1) ToString__String() *String { return Object_toString(t) }

func (t *Path_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Path_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Path_1_InstanceOf(x any) bool { _, ok := x.(*Path_1); return ok }

func Path_1_Cast(x any) *Path_1 { if x == nil { return nil }; v, ok := x.(*Path_1); if !ok { panic(ClassCast(x, Path_1_class)) }; return v }
