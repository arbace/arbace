//line java_io_FileOutputStream.ae:1
package jrt

import "sync/atomic"















func FileOutputStream_New_String(p0 *String) *FileOutputStream { t := &FileOutputStream{}; t.Ctor_String(t, p0); return t }
//line :19:1
func (t *FileOutputStream) Ctor_String(this FileOutputStream_I, name *String) { t.Ctor_String_Z(this, name, false) }


func FileOutputStream_New_String_Z(p0 *String, p1 bool) *FileOutputStream { t := &FileOutputStream{}; t.Ctor_String_Z(t, p0, p1); return t }
//line :22:1
func (t *FileOutputStream) Ctor_String_Z(this FileOutputStream_I, name *String, append_ bool) { t.OutputStream.Ctor(this); t.F_closeLock = Object_New()
	if name == nil { panic(Thrown(NullPointerException_New())) }
	t.F_fd = FileDescriptor_New()
	var tmp1 *FileDescriptor = t.F_fd; var tmp2 int32; if append_ { tmp2 = 2 } else { tmp2 = 1 }; NN(tmp1).Set_I__V(HostFiles_Open_String_I__I(name, tmp2))
	t.F_path = name
}
func FileOutputStream_New_File(p0 *File) *FileOutputStream { t := &FileOutputStream{}; t.Ctor_File(t, p0); return t }
//line :28:1
func (t *FileOutputStream) Ctor_File(this FileOutputStream_I, file *File) { t.Ctor_File_Z(this, file, false) }


func FileOutputStream_New_File_Z(p0 *File, p1 bool) *FileOutputStream { t := &FileOutputStream{}; t.Ctor_File_Z(t, p0, p1); return t }
//line :31:1
func (t *FileOutputStream) Ctor_File_Z(this FileOutputStream_I, file *File, append_ bool) { var tmp1 *String; if
												!(file == nil) { tmp1 = NN(file).GetPath__String() } else { tmp1 = nil }; /*line :31:1*/t.Ctor_String_Z(this, tmp1, append_) }


func FileOutputStream_New_FileDescriptor(p0 *FileDescriptor) *FileOutputStream { t := &FileOutputStream{}; t.Ctor_FileDescriptor(t, p0); return t }
//line :34:1
func (t *FileOutputStream) Ctor_FileDescriptor(this FileOutputStream_I, fdObj *FileDescriptor) { t.OutputStream.Ctor(this); t.F_closeLock = Object_New()
	if fdObj == nil { panic(Thrown(NullPointerException_New())) }
	t.F_fd = fdObj
	t.F_path = nil
}
func (t *FileOutputStream) Impl_Write_I__V(this FileOutputStream_I, b int32) {
	var one *ByteArray = ByteArrayOf(int8(b)); HostFiles_Write_I_B1_I_I__V(HostFiles_Handle_FileDescriptor__I(t.F_fd), one, 0, 1)
}
func (t *FileOutputStream) Impl_Write_B1__V(this FileOutputStream_I, b *ByteArray) {
	HostFiles_Write_I_B1_I_I__V(HostFiles_Handle_FileDescriptor__I(t.F_fd), b, 0, int32(len(b.A)))
}
func (t *FileOutputStream) Impl_Write_B1_I_I__V(this FileOutputStream_I, b *ByteArray, off, len_ int32) {
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	if len_ > 0 { HostFiles_Write_I_B1_I_I__V(HostFiles_Handle_FileDescriptor__I(t.F_fd), b, off, len_)
	} }
func (t *FileOutputStream) Impl_Close__V(this FileOutputStream_I) {
	var tmp1 any = t.F_closeLock; MonitorEnter(tmp1); tmp2, tmp3 := func() (ctl int32, rv bool) { defer MonitorExit(tmp1); if t.F_closed.Load() { return 2, false }; t.F_closed.Store(true); return 0, false }(); _ = tmp3; switch tmp2 { case 2: { return }}
	NN(t.F_fd).Close__V()
}
func (t *FileOutputStream) Impl_GetFD__FileDescriptor(this FileOutputStream_I) *FileDescriptor { return t.F_fd }



type FileOutputStream struct{ OutputStream; F_fd *FileDescriptor; F_path *String; F_closeLock any; F_closed atomic.Bool }

type FileOutputStream_I interface{ OutputStream_I; Closeable; Flushable; AutoCloseable; Self_FileOutputStream() *FileOutputStream; Write_I__V(p0 int32); Write_B1__V(p0 *ByteArray); Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32); Close__V(); GetFD__FileDescriptor() *FileDescriptor }

func (t *FileOutputStream) Self_FileOutputStream() *FileOutputStream { return t }

func (t *FileOutputStream) Write_I__V(p0 int32) { t.Impl_Write_I__V(t, p0) }

func (t *FileOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *FileOutputStream) Write_B1_I_I__V(p0 *ByteArray, p1, p2 int32) { t.Impl_Write_B1_I_I__V(t, p0, p1, p2) }

func (t *FileOutputStream) Close__V() { t.Impl_Close__V(t) }

func (t *FileOutputStream) GetFD__FileDescriptor() *FileDescriptor { return t.Impl_GetFD__FileDescriptor(t) }

func (t *FileOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *FileOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *FileOutputStream) GetClass__Class() *Class { return FileOutputStream_class }

func (t *FileOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *FileOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileOutputStream_InstanceOf(x any) bool { _, ok := x.(FileOutputStream_I); return ok }

func FileOutputStream_Cast(x any) FileOutputStream_I { if x == nil { return nil }; v, ok := x.(FileOutputStream_I); if !ok { panic(ClassCast(x, FileOutputStream_class)) }; return v }
