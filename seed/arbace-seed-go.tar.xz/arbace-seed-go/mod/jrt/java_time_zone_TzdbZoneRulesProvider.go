//line java_time_zone_TzdbZoneRulesProvider.ae:1
package jrt









func TzdbZoneRulesProvider_New() *TzdbZoneRulesProvider { TzdbZoneRulesProvider_Init(); t := &TzdbZoneRulesProvider{}; t.Ctor(); return t }
//line :11:1
func (t *TzdbZoneRulesProvider) Ctor() { t.ZoneRulesProvider.Ctor(t); t.F_regionToRules = ConcurrentHashMap_New(); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

	{ var in InputStream_I = TzdbZoneRulesProvider_class.GetResourceAsStream_String__InputStream(Lit_2543)
		if in == nil {
			panic(Thrown(FileNotFoundException_New_String(Lit_2544))) }
		var dis *DataInputStream = DataInputStream_New_InputStream(BufferedInputStream_New_InputStream(in)); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
			t.Load_DataInputStream__V(dis)
//line :16:1
			return nil }(); if tmp1 == nil { NN(dis).Close__V() }; if tmp1 != nil { if true { var t_101688 Throwable_I = tmp1; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); NN(dis).Close__V(); return nil }(); if tmp2 != nil { if true { var x_101689 Throwable_I = tmp2; t_101688.AddSuppressed_Throwable__V(x_101689) } }; panic(Thrown(t_101688)) } } }
//line :11:1
	return nil }(); if
	tmp3 != nil { if Exception_InstanceOf(tmp3) { var ex Exception_I = Exception_Cast(tmp3)






		panic(Thrown(ZoneRulesException_New_String_Throwable(Lit_2545, ex))) } else {
//line :12:1
			panic(tmp3) } } }



















func (t *TzdbZoneRulesProvider) ProvideZoneIds__Set() Set {
	return HashSet_New_Collection(t.F_regionIds)
}
func (t *TzdbZoneRulesProvider) ProvideRules_String_Z__ZoneRules(zoneId *String, forCaching bool) *ZoneRules {
	var obj any = t.F_regionToRules.Get_O__O(zoneId.Ref())
	if obj == nil { panic(Thrown(ZoneRulesException_New_String(Concat(Lit_2546, zoneId)))) }
	var tmp1 *ZoneRules; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var tmp2 any = obj; if Prim_byte.ArrayClass().IsInstance_O__Z(tmp2) { var bytes *ByteArray = A2g_CastArray[*ByteArray](tmp2, Prim_byte.ArrayClass()); var dis *DataInputStream = DataInputStream_New_InputStream(ByteArrayInputStream_New_B1(bytes))

			obj = Ser_Read_DataInput__Serializable(Up_DataInputStream_DataInput(dis))
			t.F_regionToRules.Put_O_O__O(zoneId.Ref(), obj) } else { }
			tmp1 = ZoneRules_Cast(obj) }; return nil }()
//line :38:1
	if tmp3 != nil { if Exception_InstanceOf(tmp3) { var ex Exception_I = Exception_Cast(tmp3)






		panic(Thrown(ZoneRulesException_New_String_Throwable(Concat(Lit_2547, zoneId, Lit_2548, t.F_versionId), ex))) } else {
//line :38:1
			panic(tmp3) } }; return tmp1
}









func (t *TzdbZoneRulesProvider) ProvideVersions_String__NavigableMap(zoneId *String) NavigableMap {
	var map_ *TreeMap = TreeMap_New(); var rules *ZoneRules = ZoneRulesProvider_GetRules_String_Z__ZoneRules(zoneId, false)

	if !(rules == nil) { NN(map_).Put_O_O__O(t.F_versionId.Ref(), rules.Ref()) }
//line :50:1
	return Up_TreeMap_NavigableMap(map_)
}



func (t *TzdbZoneRulesProvider) Load_DataInputStream__V(dis *DataInputStream) {
	if int32(NN(dis).ReadByte__B()) == 1 { } else {
		panic(Thrown(StreamCorruptedException_New_String(Lit_2549))) }
	var groupId *String = NN(dis).ReadUTF__String()
	if Lit_2550.Equals_O__Z(groupId.Ref()) == false {
		panic(Thrown(StreamCorruptedException_New_String(Lit_2549))) }
	var versionCount int32 = int32(NN(dis).ReadShort__S()); var i int32 = 0
L1: for {
	if i < versionCount { t.F_versionId = NN(dis).ReadUTF__String(); i = i + 1; continue L1 }
//line :62:1
	break L1
}
	var regionCount int32 = int32(NN(dis).ReadShort__S()); var regionArray *RefArray = NewRefArray(String_class, regionCount)
	var i_2 int32 = 0
L2: for {
	if i_2 < regionCount {
		regionArray.Store(i_2, NN(dis).ReadUTF__String().Ref())
		i_2 = i_2 + 1; continue L2 }
//line :66:1
	break L2
}


	t.F_regionIds = Arrays_AsList_O1__List(regionArray)
	var ruleCount int32 = int32(NN(dis).ReadShort__S()); var ruleArray *RefArray = NewRefArray(Object_class, ruleCount)
	var i_3 int32 = 0
L3: for {
	if i_3 < ruleCount {
		var bytes *ByteArray = NewByteArray(int32(NN(dis).ReadShort__S()))
		NN(dis).ReadFully_B1__V(bytes)
		ruleArray.Store(i_3, bytes.Ref())
		i_3 = i_3 + 1; continue L3 }
//line :73:1
	break L3
}




	var i_4 int32 = 0; L4: for {
		if i_4 < versionCount {
			var versionRegionCount int32 = int32(NN(dis).ReadShort__S())
			t.F_regionToRules.Clear__V()
			var j int32 = 0; L5: for {
				if j < versionRegionCount {
					var region *String = As[*String](regionArray.A[int32(NN(dis).ReadShort__S())]); var rule any = ruleArray.A[int32(NN(dis).ReadShort__S())&65535]

					t.F_regionToRules.Put_O_O__O(region.Ref(), rule)
					j = j + 1; continue L5 }
//line :83:1
				break L5
			}




			i_4 = i_4 + 1; continue L4 }
//line :79:1
		break L4
	}
}









func (t *TzdbZoneRulesProvider) ToString__String() *String {
	return Concat(Lit_2551, t.F_versionId, Lit_1189)
}


type TzdbZoneRulesProvider struct{ ZoneRulesProvider; F_regionIds List; F_versionId *String; F_regionToRules Map }

var TzdbZoneRulesProvider_init ClassInit

func TzdbZoneRulesProvider_Init() { if !TzdbZoneRulesProvider_init.Done() { TzdbZoneRulesProvider_init.Run(TzdbZoneRulesProvider_clinit) } }

func TzdbZoneRulesProvider_clinit() { ZoneRulesProvider_Init() }

func (t *TzdbZoneRulesProvider) ProvideRefresh__Z() bool { return t.Impl_ProvideRefresh__Z(t) }

func (t *TzdbZoneRulesProvider) Ref() any { if t == nil { return nil }; return t }

func (t *TzdbZoneRulesProvider) GetClass__Class() *Class { return TzdbZoneRulesProvider_class }

func (t *TzdbZoneRulesProvider) Clone__O() any { return A2g_ObjectClone(t) }

func (t *TzdbZoneRulesProvider) CloneShallow() any { panic(CloneNotSupported(t)) }

func TzdbZoneRulesProvider_InstanceOf(x any) bool { _, ok := x.(*TzdbZoneRulesProvider); return ok }

func TzdbZoneRulesProvider_Cast(x any) *TzdbZoneRulesProvider { if x == nil { return nil }; v, ok := x.(*TzdbZoneRulesProvider); if !ok { panic(ClassCast(x, TzdbZoneRulesProvider_class)) }; return v }
