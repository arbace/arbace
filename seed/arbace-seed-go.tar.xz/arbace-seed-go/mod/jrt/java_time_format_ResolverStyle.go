//line java_time_format_ResolverStyle.ae:1
package jrt






type ResolverStyle struct{ Enum }

func (t *ResolverStyle) Is_Constable() {}

var ResolverStyle_STRICT *ResolverStyle

var ResolverStyle_SMART *ResolverStyle

var ResolverStyle_LENIENT *ResolverStyle

var ResolverStyle__VALUES *RefArray

var ResolverStyle_init ClassInit

func ResolverStyle_Init() { if !ResolverStyle_init.Done() { ResolverStyle_init.Run(ResolverStyle_clinit) } }

func ResolverStyle_clinit() { ResolverStyle_STRICT = ResolverStyle_New_String_I(Lit_2346, 0); ResolverStyle_SMART = ResolverStyle_New_String_I(Lit_2387, 1); ResolverStyle_LENIENT = ResolverStyle_New_String_I(Lit_2347, 2); ResolverStyle__VALUES = ResolverStyle_X_values__ResolverStyle1() }

func ResolverStyle_New_String_I(p0 *String, p1 int32) *ResolverStyle { ResolverStyle_Init(); t := &ResolverStyle{}; t.Ctor_String_I(p0, p1); return t }

func (t *ResolverStyle) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func ResolverStyle_Values__ResolverStyle1() *RefArray { ResolverStyle_Init(); return ResolverStyle__VALUES.Copy() }

func ResolverStyle_ValueOf_String__ResolverStyle(p0 *String) *ResolverStyle { ResolverStyle_Init(); return ResolverStyle_Cast(Enum_ValueOf_Class_String__Enum(ResolverStyle_class, p0)) }

func ResolverStyle_X_values__ResolverStyle1() *RefArray { ResolverStyle_Init(); return RefArrayOf(ResolverStyle_class, ResolverStyle_STRICT, ResolverStyle_SMART, ResolverStyle_LENIENT) }

func (t *ResolverStyle) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ResolverStyle) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ResolverStyle) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ResolverStyle) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.format.ResolverStyle.describeConstable()Ljava/util/Optional;")) }

func (t *ResolverStyle) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ResolverStyle) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ResolverStyle) Ref() any { if t == nil { return nil }; return t }

func (t *ResolverStyle) GetClass__Class() *Class { return ResolverStyle_class }

func (t *ResolverStyle) CloneShallow() any { panic(CloneNotSupported(t)) }

func ResolverStyle_InstanceOf(x any) bool { _, ok := x.(*ResolverStyle); return ok }

func ResolverStyle_Cast(x any) *ResolverStyle { if x == nil { return nil }; v, ok := x.(*ResolverStyle); if !ok { panic(ClassCast(x, ResolverStyle_class)) }; return v }
