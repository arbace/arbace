//line java_time_ZoneOffset.ae:1
package jrt










func ZoneOffset_OfTotalSeconds_I__ZoneOffset(totalSeconds int32) *ZoneOffset { ZoneOffset_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = totalSeconds < -64800; if !tmp2 { tmp2 = totalSeconds > 64800 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Lit_2164))) }
	var quarters int32 = totalSeconds / 900
	if quarters*900 == totalSeconds {
		var key *Integer = Integer_ValueOf_I__Integer(quarters); var result *ZoneOffset = ZoneOffset_Cast(ZoneOffset_QUARTER_CACHE.Get_O__O(key.Ref()))

		if result == nil {
			result = ZoneOffset_New_I(totalSeconds)
			var existing *ZoneOffset = ZoneOffset_Cast(ZoneOffset_QUARTER_CACHE.PutIfAbsent_O_O__O(key.Ref(), result.Ref()))
			if !(existing == nil) {
				result = existing }
			var tmp3 ConcurrentMap = ZoneOffset_ID_CACHE; tmp3.PutIfAbsent_O_O__O(NN(result).GetId__String().Ref(), result.Ref()) }
//line :17:1
		return result





	} else {


		return ZoneOffset_New_I(totalSeconds)
	}
}






























func ZoneOffset_Of_String__ZoneOffset(offsetId *String) *ZoneOffset { ZoneOffset_Init()
	Objects_RequireNonNull_O_String__O(offsetId.Ref(), Lit_2150)
	var offset *ZoneOffset = ZoneOffset_Cast(ZoneOffset_ID_CACHE.Get_O__O(offsetId.Ref()))
	if !(offset == nil) { return offset } else {

		var hours int32 = 0
		var minutes int32 = 0
		var seconds int32 = 0
		switch NN(offsetId).Length__I() { case 2:


			offsetId = Concat(StrOfChar(NN(offsetId).CharAt_I__C(0)), Lit_1133, StrOfChar(NN(offsetId).CharAt_I__C(1)))
			hours = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 1, false)
			minutes = 0
			seconds = 0; case 3:


			hours = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 1, false)
			minutes = 0
			seconds = 0; case 5:


			hours = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 1, false)
			minutes = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 3, false)
			seconds = 0; case 6:


			hours = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 1, false)
			minutes = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 4, true)
			seconds = 0; case 7:


			hours = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 1, false)
			minutes = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 3, false)
			seconds = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 5, false); case 9:


			hours = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 1, false)
			minutes = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 4, true)
			seconds = ZoneOffset_ParseNumber_CharSequence_I_Z__I(Up_String_CharSequence(offsetId), 7, true); default:
			panic(Thrown(DateTimeException_New_String(Concat(Lit_2151, offsetId))))
		}
		var first uint16 = NN(offsetId).CharAt_I__C(0); var tmp1 bool; var tmp2 bool
		tmp2 = !(int32(first) == 43); if tmp2 { tmp2 = !(int32(first) == 45) }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(DateTimeException_New_String(Concat(Lit_2152, offsetId))))
		}

		if int32(first) == 45 {
			return ZoneOffset_OfHoursMinutesSeconds_I_I_I__ZoneOffset(-hours, -minutes, -seconds) } else {



				return ZoneOffset_OfHoursMinutesSeconds_I_I_I__ZoneOffset(hours, minutes, seconds)
			} } }
func ZoneOffset_ParseNumber_CharSequence_I_Z__I(offsetId CharSequence, pos int32, precededByColon bool) int32 { ZoneOffset_Init()

	var tmp1 bool; var tmp2 bool; tmp2 = precededByColon; if tmp2 { tmp2 = !(int32(offsetId.CharAt_I__C(pos-1)) == 58) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2153, StrOfObj(offsetId)))))
	}
	var ch1 uint16 = offsetId.CharAt_I__C(pos); var ch2 uint16 = offsetId.CharAt_I__C(pos + 1); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool

	tmp6 = int32(ch1) < 48; if !tmp6 { tmp6 = int32(ch1) > 57 }; tmp5 = tmp6; if !tmp5 { tmp5 = int32(ch2) < 48 }; tmp4 = tmp5; if !tmp4 { tmp4 = int32(ch2) > 57 }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2154, StrOfObj(offsetId)))))
	}
	return (int32(ch1)-48)*10 + (int32(ch2) - 48)
}

func ZoneOffset_OfHours_I__ZoneOffset(hours int32) *ZoneOffset { ZoneOffset_Init()
	return ZoneOffset_OfHoursMinutesSeconds_I_I_I__ZoneOffset(hours, 0, 0)
}
func ZoneOffset_OfHoursMinutes_I_I__ZoneOffset(hours, minutes int32) *ZoneOffset { ZoneOffset_Init()
	return ZoneOffset_OfHoursMinutesSeconds_I_I_I__ZoneOffset(hours, minutes, 0)
}
func ZoneOffset_OfHoursMinutesSeconds_I_I_I__ZoneOffset(hours, minutes, seconds int32) *ZoneOffset { ZoneOffset_Init()
	ZoneOffset_Validate_I_I_I__V(hours, minutes, seconds)
	var totalSeconds int32 = ZoneOffset_TotalSeconds_I_I_I__I(hours, minutes, seconds)
	return ZoneOffset_OfTotalSeconds_I__ZoneOffset(totalSeconds)
}
func ZoneOffset_From_TemporalAccessor__ZoneOffset(temporal TemporalAccessor) *ZoneOffset { ZoneOffset_Init()
	Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
	var offset *ZoneOffset = ZoneOffset_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Offset__TemporalQuery()))
	if offset == nil {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2155, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String())))) }
//line :139:1
	return offset
}







func ZoneOffset_Validate_I_I_I__V(hours, minutes, seconds int32) { ZoneOffset_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = hours < -18; if !tmp2 { tmp2 = hours > 18 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2156, StrOfInt(hours), Lit_2157))))
	}


	if hours > 0 {

		var tmp3 bool; var tmp4 bool; tmp4 = minutes < 0; if !tmp4 { tmp4 = seconds < 0 }; tmp3 = tmp4; if tmp3 {
			panic(Thrown(DateTimeException_New_String(Lit_2158))) } } else {
//line :154:1
				if hours < 0 {





					var tmp5 bool; var tmp6 bool; tmp6 = minutes > 0; if !tmp6 { tmp6 = seconds > 0 }; tmp5 = tmp6; if tmp5 {
						panic(Thrown(DateTimeException_New_String(Lit_2159))) } } else {
//line :154:1
							var tmp7 bool; var tmp8 bool; var tmp9 bool








							tmp9 = minutes > 0; if tmp9 { tmp9 = seconds < 0 }; tmp8 = tmp9; if !tmp8 { var tmp10 bool; tmp10 = minutes < 0; if tmp10 { tmp10 = seconds > 0 }; tmp8 = tmp10 }; tmp7 = tmp8
//line :154:1
							if tmp7 {









								panic(Thrown(DateTimeException_New_String(Lit_2160))) } } }
	var tmp11 bool; var tmp12 bool; tmp12 = minutes < -59; if !tmp12 { tmp12 = minutes > 59 }; tmp11 = tmp12; if tmp11 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2161, StrOfInt(minutes), Lit_2162))))
	}


	var tmp13 bool; var tmp14 bool; tmp14 = seconds < -59; if !tmp14 { tmp14 = seconds > 59 }; tmp13 = tmp14; if tmp13 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2163, StrOfInt(seconds), Lit_2162))))
	}


	var tmp15 bool; var tmp16 bool; tmp16 = Math_Abs_I__I(hours) == 18; if tmp16 { tmp16 = !(minutes|seconds == 0) }; tmp15 = tmp16; if tmp15 {
		panic(Thrown(DateTimeException_New_String(Lit_2164)))
	} }
func ZoneOffset_TotalSeconds_I_I_I__I(hours, minutes, seconds int32) int32 { ZoneOffset_Init()
	return hours*3600 + minutes*60 + seconds
}




















func ZoneOffset_New_I(p0 int32) *ZoneOffset { ZoneOffset_Init(); t := &ZoneOffset{}; t.Ctor_I(p0); return t }
//line :201:1
func (t *ZoneOffset) Ctor_I(totalSeconds int32) { t.ZoneId.Ctor(t)
	t.F_totalSeconds = totalSeconds
	t.F_id = ZoneOffset_BuildId_I__String(totalSeconds)
}
func ZoneOffset_BuildId_I__String(totalSeconds int32) *String { ZoneOffset_Init()
	if totalSeconds == 0 { return Lit_2165 } else {

		var absTotalSeconds int32 = Math_Abs_I__I(totalSeconds); var buf *StringBuilder = StringBuilder_New(); var absHours int32 = absTotalSeconds / 3600; var absMinutes int32 = absTotalSeconds / 60 % 60; var tmp1 uint16





		if totalSeconds < 0 { tmp1 = 45 } else { tmp1 = 43 }; NN(buf).Append_C__StringBuilder(tmp1)
		DecimalDigits_AppendPair_StringBuilder_I__V(buf, absHours)
		NN(buf).Append_C__StringBuilder(58)
		DecimalDigits_AppendPair_StringBuilder_I__V(buf, absMinutes)
		var absSeconds int32 = absTotalSeconds % 60
		if absSeconds == 0 { } else { NN(buf).Append_C__StringBuilder(58); DecimalDigits_AppendPair_StringBuilder_I__V(buf, absSeconds) }
		return NN(buf).ToString__String()
	} }
func (t *ZoneOffset) GetTotalSeconds__I() int32 { return t.F_totalSeconds }

func (t *ZoneOffset) GetId__String() *String { return t.F_id }

func (t *ZoneOffset) GetRules__ZoneRules() *ZoneRules {
	var rules *ZoneRules = t.F_rules
	if rules == nil { var tmp1 *ZoneRules; var tmp2 *ZoneRules = ZoneRules_Of_ZoneOffset__ZoneRules(t); t.F_rules = tmp2; tmp1 = tmp2; rules = tmp1 }
//line :227:1
	return rules
}


func (t *ZoneOffset) Normalized__ZoneId() ZoneId_I { return t }

func (t *ZoneOffset) GetOffset_J__ZoneOffset(epochSecond int64) *ZoneOffset { return t }

func (t *ZoneOffset) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; return any(field) == any(tmp1.Ref()) } else {
			var tmp2 bool; tmp2 = !(field == nil); if tmp2 { tmp2 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp2
		} }
func (t *ZoneOffset) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	return TemporalAccessor_Range_TemporalField__ValueRange(t, field)
}
func (t *ZoneOffset) Get_TemporalField__I(field TemporalField) int32 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; if any(field) == any(tmp1.Ref()) { return t.F_totalSeconds } else {


		if ChronoField_InstanceOf(field) {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
		return NN(t.Range_TemporalField__ValueRange(field)).CheckValidIntValue_J_TemporalField__I(t.GetLong_TemporalField__J(field), field)
	} }
func (t *ZoneOffset) GetLong_TemporalField__J(field TemporalField) int64 {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; if any(field) == any(tmp1.Ref()) { return int64(t.F_totalSeconds) } else {


		if ChronoField_InstanceOf(field) {
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2009, StrOfObj(field))))) }
		return field.GetFrom_TemporalAccessor__J(t)
	} }
func (t *ZoneOffset) Query_TemporalQuery__O(query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool; tmp2 = query == TemporalQueries_Offset__TemporalQuery(); if !tmp2 { tmp2 = query == TemporalQueries_Zone__TemporalQuery() }; tmp1 = tmp2; if tmp1 { return t } else {

		return TemporalAccessor_Query_TemporalQuery__O(t, query)
	} }
func (t *ZoneOffset) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; return temporal.With_TemporalField_J__Temporal(Up_ChronoField_TemporalField(tmp1), int64(t.F_totalSeconds))
}
func (t *ZoneOffset) CompareTo_ZoneOffset__I(other *ZoneOffset) int32 {
	return other.F_totalSeconds - t.F_totalSeconds
}
func (t *ZoneOffset) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { if ZoneOffset_InstanceOf(obj) {

		var tmp1 int32 = t.F_totalSeconds; return tmp1 == ZoneOffset_Cast(obj).F_totalSeconds } else {
//line :271:1
			return false
		}
	}
}

func (t *ZoneOffset) HashCode__I() int32 { return t.F_totalSeconds }

func (t *ZoneOffset) ToString__String() *String { return t.F_id }

func (t *ZoneOffset) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.ZoneOffset.writeReplace()Ljava/lang/Object;")) }
















func ZoneOffset_ReadExternal_DataInput__ZoneOffset(p0 DataInput) *ZoneOffset { ZoneOffset_Init(); panic(A2g_NotTranslated("java.time.ZoneOffset.readExternal(Ljava/io/DataInput;)Ljava/time/ZoneOffset;")) }



type ZoneOffset struct{ ZoneId; F_totalSeconds int32; F_id *String; F_rules *ZoneRules }

func (t *ZoneOffset) Is_TemporalAccessor() {}

func (t *ZoneOffset) Is_TemporalAdjuster() {}

func (t *ZoneOffset) Is_Comparable() {}

const ZoneOffset_SECONDS_PER_QUARTER int32 = 900

var ZoneOffset_QUARTER_CACHE ConcurrentMap

var ZoneOffset_ID_CACHE ConcurrentMap

const ZoneOffset_MAX_SECONDS int32 = 64800

const ZoneOffset_serialVersionUID int64 = 2357656521762053153

var ZoneOffset_UTC *ZoneOffset

var ZoneOffset_MIN *ZoneOffset

var ZoneOffset_MAX *ZoneOffset

var ZoneOffset_init ClassInit

func ZoneOffset_Init() { if !ZoneOffset_init.Done() { ZoneOffset_init.Run(ZoneOffset_clinit) } }

func ZoneOffset_clinit() { ZoneId_Init(); ZoneOffset_QUARTER_CACHE = ConcurrentHashMap_New_I_F_I(16, 0.75, 4); ZoneOffset_ID_CACHE = ConcurrentHashMap_New_I_F_I(16, 0.75, 4); ZoneOffset_UTC = ZoneOffset_OfTotalSeconds_I__ZoneOffset(0); ZoneOffset_MIN = ZoneOffset_OfTotalSeconds_I__ZoneOffset(-64800); ZoneOffset_MAX = ZoneOffset_OfTotalSeconds_I__ZoneOffset(64800) }

func (t *ZoneOffset) CompareTo_O__I(p0 any) int32 { return t.CompareTo_ZoneOffset__I(ZoneOffset_Cast(p0)) }

func (t *ZoneOffset) GetDisplayName_TextStyle_Locale__String(p0 *TextStyle, p1 *Locale) *String { return t.Impl_GetDisplayName_TextStyle_Locale__String(t, p0, p1) }

func (t *ZoneOffset) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneOffset) GetClass__Class() *Class { return ZoneOffset_class }

func (t *ZoneOffset) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneOffset) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneOffset_InstanceOf(x any) bool { _, ok := x.(*ZoneOffset); return ok }

func ZoneOffset_Cast(x any) *ZoneOffset { if x == nil { return nil }; v, ok := x.(*ZoneOffset); if !ok { panic(ClassCast(x, ZoneOffset_class)) }; return v }
