//line java_text_BreakIterator.ae:1
package jrt











func (t *BreakIterator) Ctor(this BreakIterator_I) {}

func (t *BreakIterator) Impl_Clone__O(this BreakIterator_I) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = A2g_ObjectClone(this); return nil }(); if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2); panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else { panic(tmp2) } }; return tmp1
}














func (t *BreakIterator) Impl_Preceding_I__I(this BreakIterator_I, offset int32) int32 {
	var pos int32 = this.Following_I__I(offset)
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = pos >= offset; if tmp2 { tmp2 = !(pos == -1) }; tmp1 = tmp2; if tmp1 { pos = this.Previous__I(); continue L1 }; break L1 }
//line :33:1
	return pos
}


func (t *BreakIterator) Impl_IsBoundary_I__Z(this BreakIterator_I, offset int32) bool {
	if offset == 0 { return true } else {

		var boundary int32 = this.Following_I__I(offset - 1)
		if boundary == -1 { panic(Thrown(IllegalArgumentException_New())) }
		return boundary == offset
	}
}



func (t *BreakIterator) Impl_SetText_String__V(this BreakIterator_I, newText *String) {
	this.SetText_CharacterIterator__V(StringCharacterIterator_New_String(newText))
}













func BreakIterator_GetWordInstance__BreakIterator() BreakIterator_I {
	return BreakIterator_GetWordInstance_Locale__BreakIterator(Locale_GetDefault__Locale())
}
func BreakIterator_GetWordInstance_Locale__BreakIterator(locale *Locale) BreakIterator_I {
	return BreakIterator_GetBreakInstance_Locale_I__BreakIterator(locale, 1)
}
func BreakIterator_GetLineInstance__BreakIterator() BreakIterator_I {
	return BreakIterator_GetLineInstance_Locale__BreakIterator(Locale_GetDefault__Locale())
}
func BreakIterator_GetLineInstance_Locale__BreakIterator(locale *Locale) BreakIterator_I {
	return BreakIterator_GetBreakInstance_Locale_I__BreakIterator(locale, 2)
}
func BreakIterator_GetCharacterInstance__BreakIterator() BreakIterator_I {
	return BreakIterator_GetCharacterInstance_Locale__BreakIterator(Locale_GetDefault__Locale())
}
func BreakIterator_GetCharacterInstance_Locale__BreakIterator(locale *Locale) BreakIterator_I {
	return BreakIterator_GetBreakInstance_Locale_I__BreakIterator(locale, 0)
}
func BreakIterator_GetSentenceInstance__BreakIterator() BreakIterator_I {
	return BreakIterator_GetSentenceInstance_Locale__BreakIterator(Locale_GetDefault__Locale())
}
func BreakIterator_GetSentenceInstance_Locale__BreakIterator(locale *Locale) BreakIterator_I {
	return BreakIterator_GetBreakInstance_Locale_I__BreakIterator(locale, 3)
}
func BreakIterator_GetBreakInstance_Locale_I__BreakIterator(locale *Locale, type_ int32) BreakIterator_I { BreakIterator_Init()
	if !(As[*SoftReference](BreakIterator_iterCache.A[type_]) == nil) {
		var cache *BreakIterator_BreakIteratorCache = BreakIterator_BreakIteratorCache_Cast(NN(As[*SoftReference](BreakIterator_iterCache.A[type_])).Get__O())
		if !(cache == nil) {
			if NN(NN(cache).GetLocale__Locale()).Equals_O__Z(locale.Ref()) { return NN(cache).CreateBreakInstance__BreakIterator() } } }
	var result BreakIterator_I = BreakIterator_CreateBreakInstance_Locale_I__BreakIterator(locale, type_); var cache_2 *BreakIterator_BreakIteratorCache = BreakIterator_BreakIteratorCache_New_Locale_BreakIterator(locale, result)
	var tmp1 /*line :93:1*/*RefArray = BreakIterator_iterCache

	tmp1.Store(type_, SoftReference_New_O(cache_2.Ref()))
//line :93:1
	return result
}



func BreakIterator_CreateBreakInstance_Locale_I__BreakIterator(locale *Locale, type_ int32) BreakIterator_I {
	var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(BreakIteratorProvider_class, locale); var iterator BreakIterator_I = BreakIterator_CreateBreakInstance_LocaleProviderAdapter_Locale_I__BreakIterator(adapter, locale, type_)

	if iterator == nil {
		iterator = BreakIterator_CreateBreakInstance_LocaleProviderAdapter_Locale_I__BreakIterator(LocaleProviderAdapter_ForJRE__LocaleProviderAdapter(), locale, type_) }
//line :99:1
	return iterator
}





func BreakIterator_CreateBreakInstance_LocaleProviderAdapter_Locale_I__BreakIterator(adapter LocaleProviderAdapter_I, locale *Locale, type_ int32) BreakIterator_I {

	{ var breakIteratorProvider BreakIteratorProvider_I = adapter.GetBreakIteratorProvider__BreakIteratorProvider()
		switch type_ { case 0:
			return breakIteratorProvider.GetCharacterInstance_Locale__BreakIterator(locale); case 1:
			return breakIteratorProvider.GetWordInstance_Locale__BreakIterator(locale); case 2:
			return breakIteratorProvider.GetLineInstance_Locale__BreakIterator(locale); case 3:
			return breakIteratorProvider.GetSentenceInstance_Locale__BreakIterator(locale); default:
//line :109:1
			return nil
		}
	}

	panic("a2g: unreachable")
}

func BreakIterator_GetAvailableLocales__Locale1() *RefArray { MonitorEnter(BreakIterator_class); defer MonitorExit(BreakIterator_class)
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(BreakIteratorProvider_class)
	return NN(pool).GetAvailableLocales__Locale1()
}





func BreakIterator_BreakIteratorCache_New_Locale_BreakIterator(p0 *Locale, p1 BreakIterator_I) *BreakIterator_BreakIteratorCache { t := &BreakIterator_BreakIteratorCache{}; t.Ctor_Locale_BreakIterator(p0, p1); return t }
//line :125:1
func (t *BreakIterator_BreakIteratorCache) Ctor_Locale_BreakIterator(locale *Locale, iter BreakIterator_I) {
	t.F_locale = locale
	t.F_iter = BreakIterator_Cast(iter.Clone__O())
}
func (t *BreakIterator_BreakIteratorCache) GetLocale__Locale() *Locale { return t.F_locale }

func (t *BreakIterator_BreakIteratorCache) CreateBreakInstance__BreakIterator() BreakIterator_I {
	return BreakIterator_Cast(t.F_iter.Clone__O())
}


type BreakIterator struct{ Object }

type BreakIterator_I interface{ Object_I; Cloneable; Self_BreakIterator() *BreakIterator; First__I() int32; Last__I() int32; Next_I__I(p0 int32) int32; Next__I() int32; Previous__I() int32; Following_I__I(p0 int32) int32; Preceding_I__I(p0 int32) int32; IsBoundary_I__Z(p0 int32) bool; Current__I() int32; GetText__CharacterIterator() CharacterIterator; SetText_String__V(p0 *String); SetText_CharacterIterator__V(p0 CharacterIterator) }

func (t *BreakIterator) Self_BreakIterator() *BreakIterator { return t }

func (t *BreakIterator) Is_Cloneable() {}

const BreakIterator_DONE int32 = -1

const BreakIterator_CHARACTER_INDEX int32 = 0

const BreakIterator_WORD_INDEX int32 = 1

const BreakIterator_LINE_INDEX int32 = 2

const BreakIterator_SENTENCE_INDEX int32 = 3

var BreakIterator_iterCache *RefArray

var BreakIterator_init ClassInit

func BreakIterator_Init() { if !BreakIterator_init.Done() { BreakIterator_init.Run(BreakIterator_clinit) } }

func BreakIterator_clinit() { BreakIterator_iterCache = NewRefArray(SoftReference_class, 4) }

func BreakIterator_InstanceOf(x any) bool { _, ok := x.(BreakIterator_I); return ok }

func BreakIterator_Cast(x any) BreakIterator_I { if x == nil { return nil }; v, ok := x.(BreakIterator_I); if !ok { panic(ClassCast(x, BreakIterator_class)) }; return v }



type BreakIterator_BreakIteratorCache struct{ Object; F_iter BreakIterator_I; F_locale *Locale }

func (t *BreakIterator_BreakIteratorCache) Ref() any { if t == nil { return nil }; return t }

func (t *BreakIterator_BreakIteratorCache) GetClass__Class() *Class { return BreakIterator_BreakIteratorCache_class }

func (t *BreakIterator_BreakIteratorCache) ToString__String() *String { return Object_toString(t) }

func (t *BreakIterator_BreakIteratorCache) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BreakIterator_BreakIteratorCache) CloneShallow() any { panic(CloneNotSupported(t)) }

func BreakIterator_BreakIteratorCache_InstanceOf(x any) bool { _, ok := x.(*BreakIterator_BreakIteratorCache); return ok }

func BreakIterator_BreakIteratorCache_Cast(x any) *BreakIterator_BreakIteratorCache { if x == nil { return nil }; v, ok := x.(*BreakIterator_BreakIteratorCache); if !ok { panic(ClassCast(x, BreakIterator_BreakIteratorCache_class)) }; return v }
