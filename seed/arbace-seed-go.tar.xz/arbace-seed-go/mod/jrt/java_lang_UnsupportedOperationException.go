//line java_lang_UnsupportedOperationException.ae:1
package jrt






func UnsupportedOperationException_New() *UnsupportedOperationException { t := &UnsupportedOperationException{}; t.Ctor(t); return t }
//line :8:1
func (t *UnsupportedOperationException) Ctor(this UnsupportedOperationException_I) { t.RuntimeException.Ctor(this) }

func UnsupportedOperationException_New_String(p0 *String) *UnsupportedOperationException { t := &UnsupportedOperationException{}; t.Ctor_String(t, p0); return t }
//line :10:1
func (t *UnsupportedOperationException) Ctor_String(this UnsupportedOperationException_I, message *String) { t.RuntimeException.Ctor_String(this, message) }

func UnsupportedOperationException_New_String_Throwable(p0 *String, p1 Throwable_I) *UnsupportedOperationException { t := &UnsupportedOperationException{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :12:1
func (t *UnsupportedOperationException) Ctor_String_Throwable(this UnsupportedOperationException_I, message *String, cause Throwable_I) { t.RuntimeException.Ctor_String_Throwable(this, message, cause) }


func UnsupportedOperationException_New_Throwable(p0 Throwable_I) *UnsupportedOperationException { t := &UnsupportedOperationException{}; t.Ctor_Throwable(t, p0); return t }
//line :15:1
func (t *UnsupportedOperationException) Ctor_Throwable(this UnsupportedOperationException_I, cause Throwable_I) { t.RuntimeException.Ctor_Throwable(this, cause) }










type UnsupportedOperationException struct{ RuntimeException }

type UnsupportedOperationException_I interface{ RuntimeException_I; Serializable; Self_UnsupportedOperationException() *UnsupportedOperationException }

func (t *UnsupportedOperationException) Self_UnsupportedOperationException() *UnsupportedOperationException { return t }

const UnsupportedOperationException_serialVersionUID int64 = -1242599979055084673

func (t *UnsupportedOperationException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *UnsupportedOperationException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *UnsupportedOperationException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *UnsupportedOperationException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *UnsupportedOperationException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *UnsupportedOperationException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *UnsupportedOperationException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *UnsupportedOperationException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *UnsupportedOperationException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *UnsupportedOperationException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *UnsupportedOperationException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *UnsupportedOperationException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *UnsupportedOperationException) Ref() any { if t == nil { return nil }; return t }

func (t *UnsupportedOperationException) GetClass__Class() *Class { return UnsupportedOperationException_class }

func (t *UnsupportedOperationException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *UnsupportedOperationException) CloneShallow() any { panic(CloneNotSupported(t)) }

func UnsupportedOperationException_InstanceOf(x any) bool { _, ok := x.(UnsupportedOperationException_I); return ok }

func UnsupportedOperationException_Cast(x any) UnsupportedOperationException_I { if x == nil { return nil }; v, ok := x.(UnsupportedOperationException_I); if !ok { panic(ClassCast(x, UnsupportedOperationException_class)) }; return v }
