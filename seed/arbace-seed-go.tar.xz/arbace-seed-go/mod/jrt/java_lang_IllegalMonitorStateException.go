//line java_lang_IllegalMonitorStateException.ae:1
package jrt








func IllegalMonitorStateException_New() *IllegalMonitorStateException { t := &IllegalMonitorStateException{}; t.Ctor(); return t }
//line :10:1
func (t *IllegalMonitorStateException) Ctor() { t.RuntimeException.Ctor(t) }

func IllegalMonitorStateException_New_String(p0 *String) *IllegalMonitorStateException { t := &IllegalMonitorStateException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *IllegalMonitorStateException) Ctor_String(s *String) { t.RuntimeException.Ctor_String(t, s) }







type IllegalMonitorStateException struct{ RuntimeException }

const IllegalMonitorStateException_serialVersionUID int64 = 3713306369498869069

func (t *IllegalMonitorStateException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalMonitorStateException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalMonitorStateException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalMonitorStateException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalMonitorStateException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalMonitorStateException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalMonitorStateException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalMonitorStateException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalMonitorStateException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalMonitorStateException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalMonitorStateException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalMonitorStateException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalMonitorStateException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalMonitorStateException) GetClass__Class() *Class { return IllegalMonitorStateException_class }

func (t *IllegalMonitorStateException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalMonitorStateException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalMonitorStateException_InstanceOf(x any) bool { _, ok := x.(*IllegalMonitorStateException); return ok }

func IllegalMonitorStateException_Cast(x any) *IllegalMonitorStateException { if x == nil { return nil }; v, ok := x.(*IllegalMonitorStateException); if !ok { panic(ClassCast(x, IllegalMonitorStateException_class)) }; return v }
