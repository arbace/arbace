//line java_lang_foreign_MemorySegment.ae:1
package jrt




































































































func MemorySegment_OfBuffer_Buffer__MemorySegment(buffer Buffer_I) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.AbstractMemorySegmentImpl is not in the closed world")
}
func MemorySegment_OfArray_B1__MemorySegment(byteArray *ByteArray) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}
func MemorySegment_OfArray_C1__MemorySegment(charArray *CharArray) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}
func MemorySegment_OfArray_S1__MemorySegment(shortArray *ShortArray) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}
func MemorySegment_OfArray_I1__MemorySegment(intArray *IntArray) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}
func MemorySegment_OfArray_F1__MemorySegment(floatArray *FloatArray) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}
func MemorySegment_OfArray_J1__MemorySegment(longArray *LongArray) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}
func MemorySegment_OfArray_D1__MemorySegment(doubleArray *DoubleArray) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}


func MemorySegment_OfAddress_J__MemorySegment(address int64) MemorySegment { MemorySegment_Init()
	return A2g_Missing[MemorySegment]("class jdk.internal.foreign.SegmentFactories is not in the closed world")
}
func MemorySegment_Copy_MemorySegment_J_MemorySegment_J_J__V(srcSegment MemorySegment, srcOffset int64, dstSegment MemorySegment, dstOffset, bytes int64) { MemorySegment_Init()


	A2g_Missing[bool]("class jdk.internal.foreign.SegmentBulkOperations is not in the closed world")
}

















































































































func MemorySegment_Mismatch_MemorySegment_J_J_MemorySegment_J_J__J(srcSegment MemorySegment, srcFromOffset, srcToOffset int64, dstSegment MemorySegment, dstFromOffset, dstToOffset int64) int64 { MemorySegment_Init()

	return A2g_Missing[int64]("class jdk.internal.foreign.SegmentBulkOperations is not in the closed world")
}


type MemorySegment interface{ Object_I; Is_MemorySegment(); Address__J() int64; HeapBase__Optional() *Optional; Scope__MemorySegment_Scope() MemorySegment_Scope; IsAccessibleBy_Thread__Z(p0 Thread_I) bool; ByteSize__J() int64; MaxByteAlignment__J() int64; AsSlice_J_J__MemorySegment(p0, p1 int64) MemorySegment; AsSlice_J_J_J__MemorySegment(p0, p1, p2 int64) MemorySegment; AsSlice_J__MemorySegment(p0 int64) MemorySegment; Reinterpret_J__MemorySegment(p0 int64) MemorySegment; IsReadOnly__Z() bool; AsReadOnly__MemorySegment() MemorySegment; IsNative__Z() bool; IsMapped__Z() bool; AsOverlappingSlice_MemorySegment__Optional(p0 MemorySegment) *Optional; Fill_B__MemorySegment(p0 int8) MemorySegment; CopyFrom_MemorySegment__MemorySegment(p0 MemorySegment) MemorySegment; Mismatch_MemorySegment__J(p0 MemorySegment) int64; IsLoaded__Z() bool; Load__V(); Unload__V(); Force__V(); AsByteBuffer__ByteBuffer() ByteBuffer_I; GetString_J__String(p0 int64) *String; GetString_J_Charset__String(p0 int64, p1 Charset_I) *String; SetString_J_String__V(p0 int64, p1 *String); SetString_J_String_Charset__V(p0 int64, p1 *String, p2 Charset_I) }

var MemorySegment_NULL MemorySegment

var MemorySegment_init ClassInit

func MemorySegment_Init() { if !MemorySegment_init.Done() { MemorySegment_init.Run(MemorySegment_clinit) } }

func MemorySegment_clinit() { MemorySegment_NULL = MemorySegment_OfAddress_J__MemorySegment(0) }

func MemorySegment_InstanceOf(x any) bool { _, ok := x.(MemorySegment); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(MemorySegment_class) } }; return ok }

func MemorySegment_Cast(x any) MemorySegment { if x == nil { return nil }; v, ok := x.(MemorySegment); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(MemorySegment_class) } }; if !ok { panic(ClassCast(x, MemorySegment_class)) }; return v }



type MemorySegment_Scope interface{ Object_I; Is_MemorySegment_Scope(); IsAlive__Z() bool }

func MemorySegment_Scope_InstanceOf(x any) bool { _, ok := x.(MemorySegment_Scope); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(MemorySegment_Scope_class) } }; return ok }

func MemorySegment_Scope_Cast(x any) MemorySegment_Scope { if x == nil { return nil }; v, ok := x.(MemorySegment_Scope); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(MemorySegment_Scope_class) } }; if !ok { panic(ClassCast(x, MemorySegment_Scope_class)) }; return v }
