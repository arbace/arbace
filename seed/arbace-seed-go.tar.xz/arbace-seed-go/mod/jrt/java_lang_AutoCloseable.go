//line java_lang_AutoCloseable.ae:1
package jrt






type AutoCloseable interface{ Object_I; Is_AutoCloseable(); Close__V() }

func AutoCloseable_InstanceOf(x any) bool { _, ok := x.(AutoCloseable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AutoCloseable_class) } }; return ok }

func AutoCloseable_Cast(x any) AutoCloseable { if x == nil { return nil }; v, ok := x.(AutoCloseable); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(AutoCloseable_class) } }; if !ok { panic(ClassCast(x, AutoCloseable_class)) }; return v }
