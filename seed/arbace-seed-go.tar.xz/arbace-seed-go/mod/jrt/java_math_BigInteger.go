//line java_math_BigInteger.ae:1
package jrt

import "sync/atomic"


























































func BigInteger_New_B1_I_I(p0 *ByteArray, p1, p2 int32) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_B1_I_I(p0, p1, p2); return t }
//line :62:1
func (t *BigInteger) Ctor_B1_I_I(val *ByteArray, off, len_ int32) { t.Number.Ctor(t)
	if int32(len(val.A)) == 0 { panic(Thrown(NumberFormatException_New_String(Lit_1247))) }
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(val.A)))
	if len_ == 0 {
		t.F_mag = BigInteger_ZERO.F_mag; t.F_signum = BigInteger_ZERO.F_signum } else {
			var b int32 = int32(val.A[off])
			if b < 0 {
				t.F_mag = BigInteger_MakePositive_I_B1_I_I__I1(b, val, off, len_); t.F_signum = -1 } else {

					t.F_mag = BigInteger_StripLeadingZeroBytes_I_B1_I_I__I1(b, val, off, len_)
					var tmp1 int32; if int32(len(t.F_mag.A)) == 0 { tmp1 = 0 } else { tmp1 = 1 }; t.F_signum = tmp1 }
			if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V()
			} } }
func BigInteger_New_B1(p0 *ByteArray) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_B1(p0); return t }
//line :75:1
func (t *BigInteger) Ctor_B1(val *ByteArray) { t.Ctor_B1_I_I(val, 0, int32(len(val.A))) }

func BigInteger_New_I1(p0 *IntArray) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_I1(p0); return t }
//line :77:1
func (t *BigInteger) Ctor_I1(val *IntArray) { t.Number.Ctor(t)
	if int32(len(val.A)) == 0 { panic(Thrown(NumberFormatException_New_String(Lit_1247))) }
	if val.A[0] < 0 {
		t.F_mag = BigInteger_MakePositive_I1__I1(val); t.F_signum = -1 } else {

			t.F_mag = BigInteger_TrustedStripLeadingZeroInts_I1__I1(val)
			var tmp1 int32; if int32(len(t.F_mag.A)) == 0 { tmp1 = 0 } else { tmp1 = 1 }; t.F_signum = tmp1 }
	if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V()
	} }
func BigInteger_New_I_B1_I_I(p0 int32, p1 *ByteArray, p2, p3 int32) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_I_B1_I_I(p0, p1, p2, p3); return t }
//line :86:1
func (t *BigInteger) Ctor_I_B1_I_I(signum int32, magnitude *ByteArray, off, len_ int32) { t.Number.Ctor(t)
	var tmp1 bool; var tmp2 bool; tmp2 = signum < -1; if !tmp2 { tmp2 = signum > 1 }; tmp1 = tmp2; if tmp1 { panic(Thrown(NumberFormatException_New_String(Lit_1248))) }
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(magnitude.A)))
	t.F_mag = BigInteger_StripLeadingZeroBytes_B1_I_I__I1(magnitude, off, len_)
	if int32(len(t.F_mag.A)) == 0 {
		t.F_signum = 0 } else {

			if signum == 0 { panic(Thrown(NumberFormatException_New_String(Lit_1249))) }
			t.F_signum = signum }
	if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V()
	} }
func BigInteger_New_I_B1(p0 int32, p1 *ByteArray) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_I_B1(p0, p1); return t }
//line :97:1
func (t *BigInteger) Ctor_I_B1(signum int32, magnitude *ByteArray) { t.Ctor_I_B1_I_I(signum, magnitude, 0, int32(len(magnitude.A))) }


func BigInteger_New_I_I1(p0 int32, p1 *IntArray) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_I_I1(p0, p1); return t }
//line :100:1
func (t *BigInteger) Ctor_I_I1(signum int32, magnitude *IntArray) { t.Number.Ctor(t)
	t.F_mag = BigInteger_StripLeadingZeroInts_I1_Z__I1(magnitude, false)
	var tmp1 bool; var tmp2 bool; tmp2 = signum < -1; if !tmp2 { tmp2 = signum > 1 }; tmp1 = tmp2; if tmp1 { panic(Thrown(NumberFormatException_New_String(Lit_1248))) }
	if int32(len(t.F_mag.A)) == 0 {
		t.F_signum = 0 } else {

			if signum == 0 { panic(Thrown(NumberFormatException_New_String(Lit_1249))) }
			t.F_signum = signum }
	if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V()
	} }
func BigInteger_New_String_I(p0 *String, p1 int32) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_String_I(p0, p1); return t }
//line :110:1
func (t *BigInteger) Ctor_String_I(val *String, radix int32) { t.Number.Ctor(t)
	var cursor int32 = 0; var numDigits int32 = 0; var len_ int32 = NN(val).Length__I(); var tmp1 bool; var tmp2 bool


	tmp2 = radix < 2; if !tmp2 { tmp2 = radix > 36 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(NumberFormatException_New_String(Lit_1250))) }
	if len_ == 0 { panic(Thrown(NumberFormatException_New_String(Lit_1247))) }
	var sign int32 = 1; var index1 int32 = NN(val).LastIndexOf_I__I(45); var index2 int32 = NN(val).LastIndexOf_I__I(43)


	if index1 >= 0 {

		var tmp3 bool; var tmp4 bool; tmp4 = !(index1 == 0); if !tmp4 { tmp4 = index2 >= 0 }; tmp3 = tmp4; if tmp3 {
			panic(Thrown(NumberFormatException_New_String(Lit_1251))) }
		sign = -1
		cursor = 1 } else {
			if index2 >= 0 {
				if index2 == 0 { } else {
					panic(Thrown(NumberFormatException_New_String(Lit_1251))) }
				cursor = 1 } }
	if cursor == len_ { panic(Thrown(NumberFormatException_New_String(Lit_1247))) }
L1: for { var tmp5 bool; var tmp6 bool; tmp6 = cursor < len_; if tmp6 { tmp6 = Character_Digit_C_I__I(NN(val).CharAt_I__C(cursor), radix) == 0 }; tmp5 = tmp6; if tmp5 {
	cursor = cursor + 1
//line :131:1
	continue L1 }; break L1
}
	if cursor == len_ {
		t.F_signum = 0; t.F_mag = BigInteger_ZERO.F_mag } else {

			numDigits = len_ - cursor
			t.F_signum = sign
			var numBits int64 = int64(uint64(int64(numDigits)*BigInteger_bitsPerDigit.A[radix])>>10) + 1




			if numBits+31 >= 4294967296 {
				BigInteger_ReportOverflow__V() }
			var numWords int32 = int32(uint32(int32(numBits+31)) >> 5); var magnitude *IntArray = NewIntArray(numWords); var firstGroupLen int32 = numDigits % BigInteger_digitsPerInt.A[radix]






			if firstGroupLen == 0 { firstGroupLen = BigInteger_digitsPerInt.A[radix] }
			var group *String; var tmp7 int32 = cursor; var tmp8 int32


			cursor = cursor + firstGroupLen; tmp8 = cursor
//line :153:1
			group = NN(val).Substring_I_I__String(tmp7, tmp8)



			magnitude.A[numWords-1] = Integer_ParseInt_String_I__I(group, radix)


			if magnitude.A[numWords-1] < 0 {
				panic(Thrown(NumberFormatException_New_String(Lit_1252))) }
			var superRadix int32 = BigInteger_intRadix.A[radix]
			var groupVal int32 = 0
		L2: for { if cursor < len_ {
			var tmp9 int32 = cursor; var tmp10 int32


			cursor = cursor + BigInteger_digitsPerInt.A[radix]; tmp10 = cursor
//line :165:1
			group = NN(val).Substring_I_I__String(tmp9, tmp10)





			groupVal = Integer_ParseInt_String_I__I(group, radix)
			if groupVal < 0 { panic(Thrown(NumberFormatException_New_String(Lit_1252))) }
			BigInteger_DestructiveMulAdd_I1_I_I__V(magnitude, superRadix, groupVal)
//line :164:1
			continue L2 }; break L2
		}








			t.F_mag = BigInteger_TrustedStripLeadingZeroInts_I1__I1(magnitude)
			if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V()
			} } }
func BigInteger_New_C1_I_I(p0 *CharArray, p1, p2 int32) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_C1_I_I(p0, p1, p2); return t }
//line :177:1
func (t *BigInteger) Ctor_C1_I_I(val *CharArray, sign, len_ int32) { t.Number.Ctor(t)
	var cursor int32 = 0
	var numDigits int32 = 0
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = cursor < len_; if tmp2 { tmp2 = Character_Digit_C_I__I(val.A[cursor], 10) == 0 }; tmp1 = tmp2; if tmp1 {
	cursor = cursor + 1
//line :180:1
	continue L1 }; break L1
}
	if cursor == len_ {
		t.F_signum = 0; t.F_mag = BigInteger_ZERO.F_mag } else {

			numDigits = len_ - cursor
			t.F_signum = sign
			var numWords int32 = 0
			if len_ < 10 {
				numWords = 1 } else {
					var numBits int64 = int64(uint64(int64(numDigits)*BigInteger_bitsPerDigit.A[10])>>10) + 1




					if numBits+31 >= 4294967296 {
						BigInteger_ReportOverflow__V() }
					numWords = int32(uint32(int32(numBits+31)) >> 5)
				}


			var magnitude *IntArray = NewIntArray(numWords); var firstGroupLen int32 = numDigits % BigInteger_digitsPerInt.A[10]



			if firstGroupLen == 0 { firstGroupLen = BigInteger_digitsPerInt.A[10] }
			var tmp3 int32 = numWords - 1; var tmp4 int32 = cursor; var tmp5 int32




			cursor = cursor + firstGroupLen; tmp5 = cursor
//line :206:1
			magnitude.A[tmp3] = t.ParseInt_C1_I_I__I(val, tmp4, tmp5)





		L2: for { if cursor < len_ {
			var groupVal int32; var tmp6 int32 = cursor; var tmp7 int32


			cursor = cursor + BigInteger_digitsPerInt.A[10]; tmp7 = cursor
//line :213:1
			groupVal = t.ParseInt_C1_I_I__I(val, tmp6, tmp7)





			BigInteger_DestructiveMulAdd_I1_I_I__V(magnitude, BigInteger_intRadix.A[10], groupVal)
//line :212:1
			continue L2 }; break L2
		}






			t.F_mag = BigInteger_TrustedStripLeadingZeroInts_I1__I1(magnitude)
			if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V()
			} } }
func (t *BigInteger) ParseInt_C1_I_I__I(source *CharArray, start, end int32) int32 {
	var result int32; var tmp1 int32
	var old_1 int32 = start
	start = start + 1; tmp1 = old_1
//line :224:1
	result = Character_Digit_C_I__I(source.A[tmp1], 10)



	if result == -1 { panic(Thrown(NumberFormatException_New_String(String_New_C1(source)))) }
	var index int32 = start; L1: for {
		if index < end {
			var nextVal int32 = Character_Digit_C_I__I(source.A[index], 10)
			if nextVal == -1 { panic(Thrown(NumberFormatException_New_String(String_New_C1(source)))) }
			result = 10*result + nextVal
			index = index + 1; continue L1 }
//line :229:1
		break L1 }
//line :224:1
	return result
}

















func BigInteger_DestructiveMulAdd_I1_I_I__V(x *IntArray, y, z int32) { BigInteger_Init()
	var ylong int64 = int64(y) & 4294967295; var zlong int64 = int64(z) & 4294967295; var len_ int32 = int32(len(x.A)); var product int64 = 0; var carry int64 = 0; var i int32 = len_ - 1




L1: for {
	if i >= 0 {
		product = ylong*(int64(x.A[i])&4294967295) + carry

		x.A[i] = int32(product)
		carry = int64(uint64(product) >> 32)
		i = i - 1; continue L1 }
//line :249:1
	break L1
}





	var sum int64 = int64(x.A[len_-1])&4294967295 + zlong

	x.A[len_-1] = int32(sum)
	carry = int64(uint64(sum) >> 32)
	var i_2 int32 = len_ - 2; L2: for {
		if i_2 >= 0 {
			sum = int64(x.A[i_2])&4294967295 + carry
			x.A[i_2] = int32(sum)
			carry = int64(uint64(sum) >> 32)
			i_2 = i_2 - 1; continue L2 }
//line :260:1
		break L2
	}
}




func BigInteger_New_String(p0 *String) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_String(p0); return t }
//line :267:1
func (t *BigInteger) Ctor_String(val *String) { t.Ctor_String_I(val, 10) }

func BigInteger_New_I_Random(p0 int32, p1 Random_I) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_I_Random(p0, p1); return t }
//line :269:1
func (t *BigInteger) Ctor_I_Random(numBits int32, rnd Random_I) { t.Number.Ctor(t)
	var magnitude *ByteArray = BigInteger_RandomBits_I_Random__B1(numBits, rnd); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_mag = BigInteger_StripLeadingZeroBytes_B1_I_I__I1(magnitude, 0, int32(len(magnitude.A)))
		if int32(len(t.F_mag.A)) == 0 { t.F_signum = 0 } else { t.F_signum = 1 }
		if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V() }
//line :270:1
		return nil
	}()



	Arrays_Fill_B1_B__V(magnitude, 0)
//line :271:1
	if tmp1 != nil { panic(tmp1)
	}
}



func BigInteger_RandomBits_I_Random__B1(numBits int32, rnd Random_I) *ByteArray { BigInteger_Init()
	if numBits < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1253))) }
	var numBytes int32 = int32((int64(numBits) + 7) / 8); var randomBits *ByteArray = NewByteArray(numBytes)

	if numBytes > 0 {
		rnd.NextBytes_B1__V(randomBits)
		var excessBits int32 = 8*numBytes - numBits
		randomBits.A[0] = int8(int32(randomBits.A[0]) & int32(int8(1<<((8-excessBits)&31)-1))) }
//line :279:1
	return randomBits
}













func BigInteger_New_I_I_Random(p0, p1 int32, p2 Random_I) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_I_I_Random(p0, p1, p2); return t }
//line :294:1
func (t *BigInteger) Ctor_I_I_Random(bitLength, certainty int32, rnd Random_I) { t.Number.Ctor(t)
	var prime *BigInteger
	if bitLength < 2 { panic(Thrown(ArithmeticException_New_String(Lit_1254))) }
	var tmp1 *BigInteger
	if bitLength < 95 {
		tmp1 = BigInteger_SmallPrime_I_I_Random__BigInteger(bitLength, certainty, rnd) } else {
			tmp1 = BigInteger_LargePrime_I_I_Random__BigInteger(bitLength, certainty, rnd) }
//line :297:1
	prime = tmp1



	t.F_signum = 1
	t.F_mag = prime.F_mag
}




func BigInteger_ProbablePrime_I_Random__BigInteger(bitLength int32, rnd Random_I) *BigInteger { BigInteger_Init()
	if bitLength < 2 { panic(Thrown(ArithmeticException_New_String(Lit_1254))) }
	if bitLength < 95 {
		return BigInteger_SmallPrime_I_I_Random__BigInteger(bitLength, 100, rnd) } else {
			return BigInteger_LargePrime_I_I_Random__BigInteger(bitLength, 100, rnd)
		} }
func BigInteger_SmallPrime_I_I_Random__BigInteger(bitLength, certainty int32, rnd Random_I) *BigInteger { BigInteger_Init()
	{ var magLen int32 = int32(uint32(bitLength+31) >> 5); var temp *IntArray = NewIntArray(magLen); var highBit int32 = 1 << ((bitLength - 1) & 31); var highMask int32 = highBit<<1 - 1



	L1: for {
		var i int32 = 0; L2: for {
			if i < magLen { temp.A[i] = rnd.NextInt__I(); i = i + 1; continue L2 }
//line :320:1
			break L2
		}
		temp.A[0] = temp.A[0]&highMask | highBit
		if bitLength > 2 {
			var i_2 int32 = magLen - 1
			temp.A[i_2] = temp.A[i_2] | 1 }
		var p *BigInteger = BigInteger_New_I1_I(temp, 1)
		if bitLength > 6 {
			var r int64 = NN(NN(p).Remainder_BigInteger__BigInteger(BigInteger_SMALL_PRIME_PRODUCT)).LongValue__J(); var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool




			tmp12 = r%3 == 0
//line :332:1
			if !tmp12 {

				tmp12 = r%5 == 0 }
//line :332:1
			tmp11 = tmp12
//line :331:1
			if !tmp11 {



				tmp11 = r%7 == 0 }
//line :331:1
			tmp10 = tmp11
//line :330:1
			if !tmp10 {





				tmp10 = r%11 == 0 }
//line :330:1
			tmp9 = tmp10
//line :329:1
			if !tmp9 {







				tmp9 = r%13 == 0 }
//line :329:1
			tmp8 = tmp9; if !tmp8 {








				tmp8 = r%17 == 0 }
//line :329:1
			tmp7 = tmp8; if !tmp7 {









				tmp7 = r%19 == 0 }
//line :329:1
			tmp6 = tmp7; if !tmp6 {










				tmp6 = r%23 == 0 }
//line :329:1
			tmp5 = tmp6; if !tmp5 {











				tmp5 = r%29 == 0 }
//line :329:1
			tmp4 = tmp5; if !tmp4 {












				tmp4 = r%31 == 0 }
//line :329:1
			tmp3 = tmp4; if !tmp3 {













				tmp3 = r%37 == 0 }
//line :329:1
			tmp2 = tmp3; if !tmp2 {














				tmp2 = r%41 == 0 }
//line :329:1
			tmp1 = tmp2; if tmp1 {















				continue L1 } }
		if bitLength < 4 { return p }
		if NN(p).PrimeToCertainty_I_Random__Z(certainty, rnd) { return p }
//line :319:1
		continue L1
	}
	}

























	panic("a2g: unreachable")
}




















func BigInteger_LargePrime_I_I_Random__BigInteger(bitLength, certainty int32, rnd Random_I) *BigInteger { BigInteger_Init()
	var p *BigInteger
	p = BigInteger_New_I_Random(bitLength, rnd).SetBit_I__BigInteger(bitLength - 1)
	var arr_3 *IntArray = p.F_mag; var i_4 int32 = int32(len(p.F_mag.A)) - 1

	arr_3.A[i_4] = arr_3.A[i_4] & -2
	var searchLen int32 = BigInteger_GetPrimeSearchLen_I__I(bitLength); var searchSieve *BitSieve = BitSieve_New_BigInteger_I(p, searchLen); var candidate *BigInteger = NN(searchSieve).Retrieve_BigInteger_I_Random__BigInteger(p, certainty, rnd)


L1: for { var tmp1 bool; var tmp2 bool; tmp2 = candidate == nil; if !tmp2 { tmp2 = !(NN(candidate).BitLength__I() == bitLength) }; tmp1 = tmp2; if tmp1 {
	p = NN(p).Add_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(int64(2 * searchLen)))
	if NN(p).BitLength__I() == bitLength { } else {
		p = BigInteger_New_I_Random(bitLength, rnd).SetBit_I__BigInteger(bitLength - 1) }
	var arr_5 *IntArray = p.F_mag; var i_6 int32 = int32(len(p.F_mag.A)) - 1

	arr_5.A[i_6] = arr_5.A[i_6] & -2
	searchSieve = BitSieve_New_BigInteger_I(p, searchLen)
	candidate = NN(searchSieve).Retrieve_BigInteger_I_Random__BigInteger(p, certainty, rnd)
//line :378:1
	continue L1 }; break L1 }
//line :375:1
	return candidate
}












func (t *BigInteger) NextProbablePrime__BigInteger() *BigInteger {
	if t.F_signum < 0 { panic(Thrown(ArithmeticException_New_String(Concat(Lit_1255, StrOfObj(t))))) }
	{ var tmp1 bool; var tmp2 bool; tmp2 = t.F_signum == 0; if !tmp2 { tmp2 = t.Equals_O__Z(BigInteger_ONE.Ref()) }; tmp1 = tmp2; if tmp1 { return BigInteger_TWO } else {

		var result *BigInteger = t.Add_BigInteger__BigInteger(BigInteger_ONE)
		if NN(result).BitLength__I() < 95 {
			if NN(result).TestBit_I__Z(0) { } else { result = NN(result).Add_BigInteger__BigInteger(BigInteger_ONE) }
		L1: for {
			if NN(result).BitLength__I() > 6 {
				var r int64 = NN(NN(result).Remainder_BigInteger__BigInteger(BigInteger_SMALL_PRIME_PRODUCT)).LongValue__J(); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool





				tmp14 = r%3 == 0
//line :403:1
				if !tmp14 {

					tmp14 = r%5 == 0 }
//line :403:1
				tmp13 = tmp14
//line :402:1
				if !tmp13 {



					tmp13 = r%7 == 0 }
//line :402:1
				tmp12 = tmp13
//line :401:1
				if !tmp12 {





					tmp12 = r%11 == 0 }
//line :401:1
				tmp11 = tmp12
//line :400:1
				if !tmp11 {







					tmp11 = r%13 == 0 }
//line :400:1
				tmp10 = tmp11
//line :399:1
				if !tmp10 {









					tmp10 = r%17 == 0 }
//line :399:1
				tmp9 = tmp10; if !tmp9 {










					tmp9 = r%19 == 0 }
//line :399:1
				tmp8 = tmp9; if !tmp8 {











					tmp8 = r%23 == 0 }
//line :399:1
				tmp7 = tmp8; if !tmp7 {












					tmp7 = r%29 == 0 }
//line :399:1
				tmp6 = tmp7; if !tmp6 {













					tmp6 = r%31 == 0 }
//line :399:1
				tmp5 = tmp6; if !tmp5 {














					tmp5 = r%37 == 0 }
//line :399:1
				tmp4 = tmp5; if !tmp4 {















					tmp4 = r%41 == 0 }
//line :399:1
				tmp3 = tmp4; if tmp3 {
















					result = NN(result).Add_BigInteger__BigInteger(BigInteger_TWO)
					continue L1 } }
			if NN(result).BitLength__I() < 4 { return result }
			if NN(result).PrimeToCertainty_I_Random__Z(100, nil) { return result }
			result = NN(result).Add_BigInteger__BigInteger(BigInteger_TWO)
//line :396:1
			continue L1
		}
		}






















		if NN(result).TestBit_I__Z(0) { result = NN(result).Subtract_BigInteger__BigInteger(BigInteger_ONE) }
		var searchLen int32 = BigInteger_GetPrimeSearchLen_I__I(NN(result).BitLength__I())
	L2: for {
		var searchSieve *BitSieve = BitSieve_New_BigInteger_I(result, searchLen); var candidate *BigInteger = NN(searchSieve).Retrieve_BigInteger_I_Random__BigInteger(result, 100, nil)

		if !(candidate == nil) { return candidate }
		result = NN(result).Add_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(int64(2 * searchLen)))
//line :423:1
		continue L2
	}
	}
	}
	panic("a2g: unreachable")
}

func BigInteger_GetPrimeSearchLen_I__I(bitLength int32) int32 { BigInteger_Init()
	if bitLength > 500000001 {
		panic(Thrown(ArithmeticException_New_String(Lit_1256))) }
	return bitLength / 20 * 64
}
func (t *BigInteger) PrimeToCertainty_I_Random__Z(certainty int32, random Random_I) bool {
	var rounds int32 = 0; var n int32 = (Math_Min_I_I__I(certainty, 2147483646) + 1) / 2; var sizeInBits int32 = t.BitLength__I()





	if sizeInBits < 100 {

		rounds = 50
		var tmp1 int32; if n < rounds { tmp1 = n } else { tmp1 = rounds }; rounds = tmp1
		return t.PassesMillerRabin_I_Random__Z(rounds, random) } else {

			if sizeInBits < 256 {
				rounds = 27 } else {
//line :448:1
					if sizeInBits < 512 {

						rounds = 15 } else {
//line :448:1
							if sizeInBits < 768 {


								rounds = 8 } else {
//line :448:1
									if sizeInBits < 1024 {



										rounds = 4 } else {
											rounds = 2 } } } }
			var tmp2 int32; if n < rounds { tmp2 = n } else { tmp2 = rounds }; rounds = tmp2
			var tmp3 bool; tmp3 = t.PassesMillerRabin_I_Random__Z(rounds, random); if tmp3 { tmp3 = t.PassesLucasLehmer__Z() }; return tmp3
		} }
func (t *BigInteger) PassesLucasLehmer__Z() bool {
	var thisPlusOne *BigInteger = t.Add_BigInteger__BigInteger(BigInteger_ONE)
	var d int32 = 5
L1: for { if !(BigInteger_JacobiSymbol_I_BigInteger__I(d, t) == -1) {
	var tmp1 int32
	if d < 0 {
		tmp1 = Math_Abs_I__I(d) + 2 } else {
			tmp1 = -(d + 2) }
//line :461:1
	d = tmp1
//line :460:1
	continue L1 }; break L1
}



	var u *BigInteger = BigInteger_LucasLehmerSequence_I_BigInteger_BigInteger__BigInteger(d, thisPlusOne, t); return NN(NN(u).Mod_BigInteger__BigInteger(t)).Equals_O__Z(BigInteger_ZERO.Ref())
}
func BigInteger_JacobiSymbol_I_BigInteger__I(p int32, n *BigInteger) int32 { BigInteger_Init()
	if p == 0 { return 0 } else {

		var j int32 = 1; var tmp1 *IntArray = n.F_mag; var u int32 = tmp1.A[int32(len(n.F_mag.A))-1]

		if p < 0 {
			p = -p
			var n8 int32 = u & 7; var tmp2 bool; var tmp3 bool
			tmp3 = n8 == 3; if !tmp3 { tmp3 = n8 == 7 }; tmp2 = tmp3; if tmp2 { j = -j } }
	L1: for { if p&3 == 0 { p = p >> 2; continue L1 }; break L1 }
		if p&1 == 0 {
			p = p >> 1
			if (u^u>>1)&2 == 0 { } else {
				j = -j } }
		if p == 1 { return j } else {


			if p&u&2 == 0 { } else {
				j = -j }
			u = NN(NN(n).Mod_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(int64(p)))).IntValue__I()
		L2: for { if !(u == 0) {
		L3: for { if u&3 == 0 { u = u >> 2; continue L3 }; break L3 }
			if u&1 == 0 {
				u = u >> 1
				if (p^p>>1)&2 == 0 { } else {
					j = -j } }
			if u == 1 { return j }
			if !A2g_AssertionsDisabled && !(u < p) { panic(Thrown(AssertionError_New())) }
			var t_ int32 = u
			u = p
			p = t_
			if u&p&2 == 0 { } else {
				j = -j }
			u = u % p
//line :487:1
			continue L2 }; break L2 }
//line :483:1
			return 0
		}
	}
}
















func BigInteger_LucasLehmerSequence_I_BigInteger_BigInteger__BigInteger(z int32, k, n *BigInteger) *BigInteger { BigInteger_Init()
	var d *BigInteger = BigInteger_ValueOf_J__BigInteger(int64(z)); var u *BigInteger = BigInteger_ONE; var u2 *BigInteger; var v *BigInteger = BigInteger_ONE; var v2 *BigInteger; var i int32 = NN(k).BitLength__I() - 2




L1: for {
	if i >= 0 {
		u2 = NN(NN(u).Multiply_BigInteger__BigInteger(v)).Mod_BigInteger__BigInteger(n)
		v2 = NN(NN(NN(v).Square__BigInteger()).Add_BigInteger__BigInteger(NN(d).Multiply_BigInteger__BigInteger(NN(u).Square__BigInteger()))).Mod_BigInteger__BigInteger(n)
		if NN(v2).TestBit_I__Z(0) { v2 = NN(v2).Subtract_BigInteger__BigInteger(n) }
		v2 = NN(v2).ShiftRight_I__BigInteger(1)
		u = u2
		v = v2
		if NN(k).TestBit_I__Z(i) {

			u2 = NN(NN(u).Add_BigInteger__BigInteger(v)).Mod_BigInteger__BigInteger(n)
			if NN(u2).TestBit_I__Z(0) { u2 = NN(u2).Subtract_BigInteger__BigInteger(n) }
			u2 = NN(u2).ShiftRight_I__BigInteger(1)
			v2 = NN(NN(v).Add_BigInteger__BigInteger(NN(d).Multiply_BigInteger__BigInteger(u))).Mod_BigInteger__BigInteger(n)
			if NN(v2).TestBit_I__Z(0) { v2 = NN(v2).Subtract_BigInteger__BigInteger(n) }
			v2 = NN(v2).ShiftRight_I__BigInteger(1)
			u = u2
			v = v2
			i = i - 1; continue L1 } else {
				i = i - 1; continue L1 } }
//line :509:1
	break L1 }
//line :504:1
	return u
}

























func (t *BigInteger) PassesMillerRabin_I_Random__Z(iterations int32, rnd Random_I) bool {
	var thisMinusOne *BigInteger = t.Subtract_BigInteger__BigInteger(BigInteger_ONE); var m *BigInteger = thisMinusOne; var a int32 = NN(m).GetLowestSetBit__I()


	m = NN(m).ShiftRight_I__BigInteger(a)
	if rnd == nil { rnd = Up_ThreadLocalRandom_Random(ThreadLocalRandom_Current__ThreadLocalRandom()) }
	var i int32 = 0; L1: for {
		if i < iterations {
			var b *BigInteger
		L2: for {
			b = BigInteger_New_I_Random(t.BitLength__I(), rnd)
			var tmp1 bool; var tmp2 bool; tmp2 = NN(b).CompareTo_BigInteger__I(BigInteger_ONE) <= 0; if !tmp2 { tmp2 = NN(b).CompareTo_BigInteger__I(t) >= 0 }; tmp1 = tmp2; if tmp1 { continue L2 }
//line :540:1
			break L2
		}

			var j int32 = 0; var z *BigInteger = NN(b).ModPow_BigInteger_BigInteger__BigInteger(m, t)

		L3: for { var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = j == 0; if tmp5 { tmp5 = NN(z).Equals_O__Z(BigInteger_ONE.Ref()) }; tmp4 = tmp5; if !tmp4 { tmp4 = NN(z).Equals_O__Z(thisMinusOne.Ref()) }; tmp3 = tmp4; if !tmp3 {
			var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = j > 0; if tmp8 { tmp8 = NN(z).Equals_O__Z(BigInteger_ONE.Ref()) }; tmp7 = tmp8; if !tmp7 { var tmp9 int32; j = j + 1; tmp9 = j; tmp7 = tmp9 == a }; tmp6 = tmp7; if tmp6 {
				return false }
			z = NN(z).ModPow_BigInteger_BigInteger__BigInteger(BigInteger_TWO, t)
//line :545:1
			continue L3 }; break L3
		}


			i = i + 1; continue L1 }
//line :537:1
		break L1 }
//line :532:1
	return true
}


















func BigInteger_New_I1_I(p0 *IntArray, p1 int32) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_I1_I(p0, p1); return t }
//line :552:1
func (t *BigInteger) Ctor_I1_I(magnitude *IntArray, signum int32) { t.Number.Ctor(t)
	var tmp1 int32; if int32(len(magnitude.A)) == 0 { tmp1 = 0 } else { tmp1 = signum }; t.F_signum = tmp1
	t.F_mag = magnitude
	if int32(len(t.F_mag.A)) >= 67108864 { t.CheckRange__V()
	} }
func BigInteger_New_B1_I(p0 *ByteArray, p1 int32) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_B1_I(p0, p1); return t }
//line :557:1
func (t *BigInteger) Ctor_B1_I(magnitude *ByteArray, signum int32) { panic(A2g_NotTranslated("java.math.BigInteger.<init>([BI)V")) }




func (t *BigInteger) CheckRange__V() {
	var tmp1 bool; var tmp2 bool; tmp2 = int32(len(t.F_mag.A)) > 67108864; if !tmp2 {
		var tmp3 bool; tmp3 = int32(len(t.F_mag.A)) == 67108864; if tmp3 { tmp3 = t.F_mag.A[0] < 0 }; tmp2 = tmp3 }
//line :563:1
	tmp1 = tmp2; if tmp1 {

		BigInteger_ReportOverflow__V()
	} }
func BigInteger_ReportOverflow__V() { BigInteger_Init()
	panic(Thrown(ArithmeticException_New_String(Lit_1257)))
}
func BigInteger_ValueOf_J__BigInteger(val int64) *BigInteger { BigInteger_Init()
	if val == 0 { return BigInteger_ZERO } else { var tmp1 bool; var tmp2 bool

		tmp2 = val > 0; if tmp2 { tmp2 = val <= 16 }; tmp1 = tmp2
//line :571:1
		if tmp1 {

			return As[*BigInteger](BigInteger_posConst.A[int32(val)]) } else {
//line :571:1
				var tmp3 bool; var tmp4 bool


				tmp4 = val < 0; if tmp4 { tmp4 = val >= -16 }; tmp3 = tmp4
//line :571:1
				if tmp3 {



					return As[*BigInteger](BigInteger_negConst.A[int32(-val)]) } else {
						return BigInteger_New_J(val)
					} } } }
func BigInteger_New_J_I(p0 int64, p1 int32) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_J_I(p0, p1); return t }
//line :578:1
func (t *BigInteger) Ctor_J_I(mag int64, signum int32) { t.Number.Ctor(t)
	var tmp1 bool; var tmp2 bool; tmp2 = !(mag == 0); if tmp2 { tmp2 = !(signum == 0) }; tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New())) }
	t.F_signum = signum
	t.F_mag = BigInteger_ToMagArray_J__I1(mag)
}
func BigInteger_New_J(p0 int64) *BigInteger { BigInteger_Init(); t := &BigInteger{}; t.Ctor_J(p0); return t }
//line :583:1
func (t *BigInteger) Ctor_J(val int64) { t.Number.Ctor(t)
	if val < 0 { val = -val; t.F_signum = -1 } else { t.F_signum = 1 }
	t.F_mag = BigInteger_ToMagArray_J__I1(val)
}
func BigInteger_ToMagArray_J__I1(mag int64) *IntArray { BigInteger_Init()
	var highWord int32 = int32(int64(uint64(mag) >> 32))
	if highWord == 0 {
		return IntArrayOf(int32(mag)) } else {
			return IntArrayOf(highWord, int32(mag))
		} }
func BigInteger_ValueOf_I1__BigInteger(val *IntArray) *BigInteger { BigInteger_Init()
	if val.A[0] > 0 { return BigInteger_New_I1_I(val, 1) } else { return BigInteger_New_I1(val)
	}
}















































func (t *BigInteger) Add_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	if val.F_signum == 0 { return t } else { if t.F_signum == 0 { return val } else { if val.F_signum == t.F_signum {


		var tmp1 *IntArray = t.F_mag; return BigInteger_New_I1_I(BigInteger_Add_I1_I1__I1(tmp1, val.F_mag), t.F_signum) } else {

			var cmp int32 = t.CompareMagnitude_BigInteger__I(val)
			if cmp == 0 { return BigInteger_ZERO } else {

				var resultMag *IntArray; if cmp > 0 {
					var tmp2 *IntArray = t.F_mag; resultMag = BigInteger_Subtract_I1_I1__I1(tmp2, val.F_mag) } else {
						resultMag = BigInteger_Subtract_I1_I1__I1(val.F_mag, t.F_mag) }
				resultMag = BigInteger_TrustedStripLeadingZeroInts_I1__I1(resultMag)
				var tmp3 *IntArray = resultMag; var tmp4 int32; if cmp == t.F_signum { tmp4 = 1 } else { tmp4 = -1 }; return BigInteger_New_I1_I(tmp3, tmp4)
			} } } } }
func (t *BigInteger) Add_J__BigInteger(val int64) *BigInteger {
	if val == 0 { return t } else { if t.F_signum == 0 {

		return BigInteger_ValueOf_J__BigInteger(val) } else {
//line :660:1
			if Long_Signum_J__I(val) == t.F_signum {


				var tmp1 *IntArray = t.F_mag; return BigInteger_New_I1_I(BigInteger_Add_I1_J__I1(tmp1, Math_Abs_J__J(val)), t.F_signum) } else {

					var cmp int32 = t.CompareMagnitude_J__I(val)
					if cmp == 0 { return BigInteger_ZERO } else {

						var resultMag *IntArray; if cmp > 0 {
							var tmp2 *IntArray = t.F_mag; resultMag = BigInteger_Subtract_I1_J__I1(tmp2, Math_Abs_J__J(val)) } else {
								resultMag = BigInteger_Subtract_J_I1__I1(Math_Abs_J__J(val), t.F_mag) }
						resultMag = BigInteger_TrustedStripLeadingZeroInts_I1__I1(resultMag)
						var tmp3 *IntArray = resultMag; var tmp4 int32; if cmp == t.F_signum { tmp4 = 1 } else { tmp4 = -1 }; return BigInteger_New_I1_I(tmp3, tmp4)
					} } } } }
func BigInteger_Add_I1_J__I1(x *IntArray, val int64) *IntArray { BigInteger_Init()
	var y *IntArray; var sum int64 = 0; var xIndex int32 = int32(len(x.A)); var result *IntArray; var highWord int32 = int32(int64(uint64(val) >> 32)); _ = y




	if highWord == 0 {


		result = NewIntArray(xIndex)
		var tmp1 int32

		xIndex = xIndex - 1; tmp1 = xIndex
//line :684:1
		sum = int64(x.A[tmp1])&4294967295 + val



		result.A[xIndex] = int32(sum) } else {
//line :680:1
			if xIndex == 1 {










				result = NewIntArray(2)
				sum = val + int64(x.A[0])&4294967295
				result.A[1] = int32(sum)
				result.A[0] = int32(int64(uint64(sum) >> 32))
				return result } else {


					result = NewIntArray(xIndex)
					var tmp2 int32

					xIndex = xIndex - 1; tmp2 = xIndex
//line :699:1
					sum = int64(x.A[tmp2])&4294967295 + val&4294967295



					result.A[xIndex] = int32(sum)
					var tmp3 int32


					xIndex = xIndex - 1; tmp3 = xIndex
//line :704:1
					sum = int64(x.A[tmp3])&4294967295 + int64(highWord)&4294967295 + int64(uint64(sum)>>32)





					result.A[xIndex] = int32(sum) } }
	var carry bool = !(int64(uint64(sum)>>32) == 0)
L1: for { var tmp4 bool; var tmp5 bool; tmp5 = xIndex > 0; if tmp5 { tmp5 = carry }; tmp4 = tmp5; if tmp4 {
	var tmp6 int32; var tmp7 *IntArray = result; var tmp8 int32

	xIndex = xIndex - 1; tmp8 = xIndex
//line :714:1
	var tmp9 int32 = x.A[xIndex] + 1; tmp7.A[tmp8] = tmp9; tmp6 = tmp9
//line :713:1
	carry = tmp6 == 0
//line :712:1
	continue L1 }; break L1
}




L2: for { if xIndex > 0 { var tmp10 *IntArray = result; var tmp11 int32; xIndex = xIndex - 1; tmp11 = xIndex; tmp10.A[tmp11] = x.A[xIndex]; continue L2 }; break L2 }
	if carry {
		var bigger *IntArray = NewIntArray(int32(len(result.A)) + 1)
		System_Arraycopy_O_I_O_I_I__V(result.Ref(), 0, bigger.Ref(), 1, int32(len(result.A)))
		bigger.A[0] = 1
//line :720:1
		return bigger
	} else {
//line :719:1
		return result
	}
}




func BigInteger_Add_I1_I1__I1(x, y *IntArray) *IntArray { BigInteger_Init()
	var tmp1 int32 = int32(len(x.A)); if tmp1 < int32(len(y.A)) { var tmp *IntArray = x; x = y; y = tmp }
	var xIndex int32 = int32(len(x.A)); var yIndex int32 = int32(len(y.A)); var result *IntArray = NewIntArray(xIndex)
	var sum int64 = 0


	if yIndex == 1 {

		var tmp2 *IntArray = x; var tmp3 int32

		xIndex = xIndex - 1; tmp3 = xIndex
//line :734:1
		var tmp4 int64 = int64(tmp2.A[tmp3]) & 4294967295; sum = tmp4 + int64(y.A[0])&4294967295



		result.A[xIndex] = int32(sum) } else {
		L1: for { if yIndex > 0 {
			var tmp5 *IntArray = x; var tmp6 int32


			xIndex = xIndex - 1; tmp6 = xIndex
//line :740:1
			var tmp7 int64 = int64(tmp5.A[tmp6]) & 4294967295; var tmp8 *IntArray = y; var tmp9 int32



			yIndex = yIndex - 1; tmp9 = yIndex
//line :740:1
			sum = tmp7 + int64(tmp8.A[tmp9])&4294967295 + int64(uint64(sum)>>32)





			result.A[xIndex] = int32(sum)
//line :739:1
			continue L1 }; break L1
		}
		}





	var carry bool = !(int64(uint64(sum)>>32) == 0)
L2: for { var tmp10 bool; var tmp11 bool; tmp11 = xIndex > 0; if tmp11 { tmp11 = carry }; tmp10 = tmp11; if tmp10 {
	var tmp12 int32; var tmp13 int32

	xIndex = xIndex - 1; tmp13 = xIndex
//line :750:1
	var tmp14 int32 = x.A[xIndex] + 1; result.A[tmp13] = tmp14; tmp12 = tmp14
//line :749:1
	carry = tmp12 == 0
//line :748:1
	continue L2 }; break L2
}




L3: for { if xIndex > 0 { var tmp15 int32; xIndex = xIndex - 1; tmp15 = xIndex; result.A[tmp15] = x.A[xIndex]; continue L3 }; break L3 }
	if carry {
		var bigger *IntArray = NewIntArray(int32(len(result.A)) + 1)
		System_Arraycopy_O_I_O_I_I__V(result.Ref(), 0, bigger.Ref(), 1, int32(len(result.A)))
		bigger.A[0] = 1
//line :756:1
		return bigger
	} else {
//line :755:1
		return result
	}
}




func BigInteger_Subtract_J_I1__I1(val int64, little *IntArray) *IntArray { BigInteger_Init()
	var highWord int32 = int32(int64(uint64(val) >> 32))
	if highWord == 0 {
		var result *IntArray = NewIntArray(1)
		result.A[0] = int32(val - int64(little.A[0])&4294967295)
//line :765:1
		return result } else {




			var result_2 *IntArray = NewIntArray(2)
			if int32(len(little.A)) == 1 {
				var difference int64 = int64(int32(val))&4294967295 - int64(little.A[0])&4294967295


				result_2.A[1] = int32(difference)
				var borrow bool = !(difference>>32 == 0)
				if borrow {
					result_2.A[0] = highWord - 1 } else {
						result_2.A[0] = highWord }
//line :776:1
				return result_2

			} else {


				var difference_2 int64 = int64(int32(val))&4294967295 - int64(little.A[1])&4294967295


				result_2.A[1] = int32(difference_2)
				difference_2 = int64(highWord)&4294967295 - int64(little.A[0])&4294967295 + difference_2>>32




				result_2.A[0] = int32(difference_2)
//line :781:1
				return result_2
			}
		}
}








func BigInteger_Subtract_I1_J__I1(big *IntArray, val int64) *IntArray { BigInteger_Init()
	var highWord int32 = int32(int64(uint64(val) >> 32)); var bigIndex int32 = int32(len(big.A)); var result *IntArray = NewIntArray(bigIndex)
	var difference int64 = 0


	if highWord == 0 {

		var tmp1 int32

		bigIndex = bigIndex - 1; tmp1 = bigIndex
//line :800:1
		difference = int64(big.A[tmp1])&4294967295 - val



		result.A[bigIndex] = int32(difference) } else {

			var tmp2 int32

			bigIndex = bigIndex - 1; tmp2 = bigIndex
//line :806:1
			difference = int64(big.A[tmp2])&4294967295 - val&4294967295



			result.A[bigIndex] = int32(difference)
			var tmp3 int32


			bigIndex = bigIndex - 1; tmp3 = bigIndex
//line :811:1
			difference = int64(big.A[tmp3])&4294967295 - int64(highWord)&4294967295 + difference>>32





			result.A[bigIndex] = int32(difference) }
	var borrow bool = !(difference>>32 == 0)
L1: for { var tmp4 bool; var tmp5 bool; tmp5 = bigIndex > 0; if tmp5 { tmp5 = borrow }; tmp4 = tmp5; if tmp4 {
	var tmp6 int32; var tmp7 int32

	bigIndex = bigIndex - 1; tmp7 = bigIndex
//line :821:1
	var tmp8 int32 = big.A[bigIndex] - 1; result.A[tmp7] = tmp8; tmp6 = tmp8
//line :820:1
	borrow = tmp6 == -1
//line :819:1
	continue L1 }; break L1
}




L2: for { if bigIndex > 0 {
	var tmp9 int32; bigIndex = bigIndex - 1; tmp9 = bigIndex; result.A[tmp9] = big.A[bigIndex]
//line :825:1
	continue L2 }; break L2 }
//line :818:1
	return result
}









func (t *BigInteger) Subtract_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	if val.F_signum == 0 { return t } else { if t.F_signum == 0 {

		return NN(val).Negate__BigInteger() } else {
//line :830:1
			if !(val.F_signum == t.F_signum) {


				var tmp1 *IntArray = t.F_mag; return BigInteger_New_I1_I(BigInteger_Add_I1_I1__I1(tmp1, val.F_mag), t.F_signum) } else {

					var cmp int32 = t.CompareMagnitude_BigInteger__I(val)
					if cmp == 0 { return BigInteger_ZERO } else {

						var resultMag *IntArray; if cmp > 0 {
							var tmp2 *IntArray = t.F_mag; resultMag = BigInteger_Subtract_I1_I1__I1(tmp2, val.F_mag) } else {
								resultMag = BigInteger_Subtract_I1_I1__I1(val.F_mag, t.F_mag) }
						resultMag = BigInteger_TrustedStripLeadingZeroInts_I1__I1(resultMag)
						var tmp3 *IntArray = resultMag; var tmp4 int32; if cmp == t.F_signum { tmp4 = 1 } else { tmp4 = -1 }; return BigInteger_New_I1_I(tmp3, tmp4)
					} } } } }
func BigInteger_Subtract_I1_I1__I1(big, little *IntArray) *IntArray { BigInteger_Init()
	var bigIndex int32 = int32(len(big.A)); var result *IntArray = NewIntArray(bigIndex); var littleIndex int32 = int32(len(little.A))
	var difference int64 = 0


L1: for { if littleIndex > 0 {
	var tmp1 int32


	bigIndex = bigIndex - 1; tmp1 = bigIndex
//line :850:1
	var tmp2 int64 = int64(big.A[tmp1]) & 4294967295; var tmp3 int32



	littleIndex = littleIndex - 1; tmp3 = littleIndex
//line :850:1
	difference = tmp2 - int64(little.A[tmp3])&4294967295 + difference>>32






	result.A[bigIndex] = int32(difference)
//line :849:1
	continue L1 }; break L1
}







	var borrow bool = !(difference>>32 == 0)
L2: for { var tmp4 bool; var tmp5 bool; tmp5 = bigIndex > 0; if tmp5 { tmp5 = borrow }; tmp4 = tmp5; if tmp4 {
	var tmp6 int32; var tmp7 int32

	bigIndex = bigIndex - 1; tmp7 = bigIndex
//line :861:1
	var tmp8 int32 = big.A[bigIndex] - 1; result.A[tmp7] = tmp8; tmp6 = tmp8
//line :860:1
	borrow = tmp6 == -1
//line :859:1
	continue L2 }; break L2
}




L3: for { if bigIndex > 0 {
	var tmp9 int32; bigIndex = bigIndex - 1; tmp9 = bigIndex; result.A[tmp9] = big.A[bigIndex]
//line :865:1
	continue L3 }; break L3 }
//line :858:1
	return result
}









func (t *BigInteger) Multiply_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	return t.Multiply_BigInteger_Z_Z_I__BigInteger(val, false, false, 0)
}
func (t *BigInteger) ParallelMultiply_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	return t.Multiply_BigInteger_Z_Z_I__BigInteger(val, false, true, 0)
}
func (t *BigInteger) Multiply_BigInteger_Z_Z_I__BigInteger(val *BigInteger, isRecursion, parallel bool, depth int32) *BigInteger {

	var tmp1 bool; var tmp2 bool; tmp2 = val.F_signum == 0; if !tmp2 { tmp2 = t.F_signum == 0 }; tmp1 = tmp2; if tmp1 { return BigInteger_ZERO } else {

		var xlen int32 = int32(len(t.F_mag.A)); var tmp3 bool; var tmp4 bool
		tmp4 = val == t; if tmp4 { tmp4 = xlen > 20 }; tmp3 = tmp4; if tmp3 {
			return t.Square_Z_Z_I__BigInteger(true, parallel, depth) } else {
				var ylen int32 = int32(len(val.F_mag.A)); var tmp5 bool; var tmp6 bool

				tmp6 = xlen < 80; if !tmp6 { tmp6 = ylen < 80 }; tmp5 = tmp6
//line :883:1
				if tmp5 {

					var resultSign int32; var tmp7 int32 = t.F_signum; if tmp7 == val.F_signum { resultSign = 1 } else { resultSign = -1 }
					if int32(len(val.F_mag.A)) == 1 {

						var tmp8 *IntArray = t.F_mag; return BigInteger_MultiplyByInt_I1_I_I__BigInteger(tmp8, val.F_mag.A[0], resultSign) } else {
//line :886:1
							if int32(len(t.F_mag.A)) == 1 {



								var tmp9 *IntArray = val.F_mag; return BigInteger_MultiplyByInt_I1_I_I__BigInteger(tmp9, t.F_mag.A[0], resultSign) } else {

									var tmp10 *IntArray = t.F_mag; var result *IntArray = BigInteger_MultiplyToLen_I1_I_I1_I_I1__I1(tmp10, xlen, val.F_mag, ylen, nil)





									result = BigInteger_TrustedStripLeadingZeroInts_I1__I1(result)
									return BigInteger_New_I1_I(result, resultSign) } } } else {
//line :883:1
										var tmp11 bool; var tmp12 bool
















										tmp12 = xlen < 240; if tmp12 { tmp12 = ylen < 240 }; tmp11 = tmp12
//line :883:1
										if tmp11 {

















											return BigInteger_MultiplyKaratsuba_BigInteger_BigInteger__BigInteger(t, val) } else {


												if isRecursion { } else {
													if int64(t.MagBitLength__I())+int64(NN(val).MagBitLength__I()) > 2147483648 {

														BigInteger_ReportOverflow__V() } }
												return BigInteger_MultiplyToomCook3_BigInteger_BigInteger_Z_I__BigInteger(t, val, parallel, depth)
											} } } } }
func BigInteger_MultiplyByInt_I1_I_I__BigInteger(x *IntArray, y, sign int32) *BigInteger { BigInteger_Init()
	if Integer_LowestOneBit_I__I(y) == y {
		return BigInteger_New_I1_I(BigInteger_ShiftLeft_I1_I__I1(x, Integer_NumberOfTrailingZeros_I__I(y)), sign) } else {
			var xlen int32 = int32(len(x.A)); var rmag *IntArray = NewIntArray(xlen + 1); var carry int64 = 0; var yl int64 = int64(y) & 4294967295; var rstart int32 = int32(len(rmag.A)) - 1; var i int32 = xlen - 1




		L1: for {
			if i >= 0 {
				var product int64 = int64(x.A[i])&4294967295*yl + carry

				rmag.A[rstart] = int32(product)
				rstart = rstart - 1
				carry = int64(uint64(product) >> 32)
				i = i - 1; continue L1 }
//line :918:1
			break L1
		}






			if carry == 0 {
				rmag = Arrays_CopyOfRange_I1_I_I__I1(rmag, 1, int32(len(rmag.A))) } else {
					rmag.A[rstart] = int32(carry) }
			return BigInteger_New_I1_I(rmag, sign)
		} }
func (t *BigInteger) Multiply_J__BigInteger(v int64) *BigInteger {
	var tmp1 bool; var tmp2 bool
	tmp2 = v == 0; if !tmp2 { tmp2 = t.F_signum == 0 }; tmp1 = tmp2
//line :932:1
	if tmp1 { return BigInteger_ZERO } else { if v == -9223372036854775808 {

		return t.Multiply_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(v)) } else {

			var rsign int32; if v > 0 { rsign = t.F_signum } else { rsign = -t.F_signum }
			if v < 0 { v = -v }
			var dh int64 = int64(uint64(v) >> 32); var dl int64 = v & 4294967295; var xlen int32 = int32(len(t.F_mag.A)); var value *IntArray = t.F_mag; var rmag *IntArray



			if dh == 0 {
				rmag = NewIntArray(xlen + 1) } else {
					rmag = NewIntArray(xlen + 2) }
//line :938:1
			var carry int64 = 0; var rstart int32 = int32(len(rmag.A)) - 1; var i int32 = xlen - 1








		L1: for {
			if i >= 0 {
				var product int64 = int64(value.A[i])&4294967295*dl + carry


				rmag.A[rstart] = int32(product)
				rstart = rstart - 1
				carry = int64(uint64(product) >> 32)
				i = i - 1; continue L1 }
//line :947:1
			break L1
		}







			rmag.A[rstart] = int32(carry)
			if dh == 0 { } else {
				carry = 0
				rstart = int32(len(rmag.A)) - 2
				var i_2 int32 = xlen - 1; L2: for {
					if i_2 >= 0 {
						var tmp3 int64 = int64(value.A[i_2]) & 4294967295 * dh; var product_2 int64 = tmp3 + int64(rmag.A[rstart])&4294967295 + carry




						rmag.A[rstart] = int32(product_2)
						rstart = rstart - 1
						carry = int64(uint64(product_2) >> 32)
						i_2 = i_2 - 1; continue L2 }
//line :960:1
					break L2
				}









				rmag.A[0] = int32(carry) }
			if carry == 0 { rmag = Arrays_CopyOfRange_I1_I_I__I1(rmag, 1, int32(len(rmag.A))) }
			return BigInteger_New_I1_I(rmag, rsign)
		} } }
func BigInteger_MultiplyToLen_I1_I_I1_I_I1__I1(x *IntArray, xlen int32, y *IntArray, ylen int32, z *IntArray) *IntArray { BigInteger_Init()

	BigInteger_MultiplyToLenCheck_I1_I__V(x, xlen)
	BigInteger_MultiplyToLenCheck_I1_I__V(y, ylen)
	var tmp1 bool; var tmp2 bool; tmp2 = z == nil; if !tmp2 { tmp2 = int32(len(z.A)) < xlen+ylen }; tmp1 = tmp2; if tmp1 {
		z = NewIntArray(xlen + ylen) }
	return BigInteger_ImplMultiplyToLen_I1_I_I1_I_I1__I1(x, xlen, y, ylen, z)
}
func BigInteger_ImplMultiplyToLen_I1_I_I1_I_I1__I1(x *IntArray, xlen int32, y *IntArray, ylen int32, z *IntArray) *IntArray { BigInteger_Init()


	var xstart int32 = xlen - 1; var ystart int32 = ylen - 1; var carry int64 = 0; var j int32 = ystart; var k int32 = ystart + 1 + xstart


L1: for {

	if j >= 0 {
		var tmp1 int64 = int64(y.A[j]) & 4294967295; var product int64 = tmp1*(int64(x.A[xstart])&4294967295) + carry



		z.A[k] = int32(product)
		carry = int64(uint64(product) >> 32)
		j, k = j-1, k-1; continue L1 }
//line :989:1
	break L1
}








	z.A[xstart] = int32(carry)
	var i int32 = xstart - 1; L2: for {
		if i >= 0 {
			carry = 0
			var j_2 int32 = ystart; var k_2 int32 = ystart + 1 + i; L3: for {

				if j_2 >= 0 {
					var tmp2 int64 = int64(y.A[j_2]) & 4294967295; var tmp3 int64 = tmp2 * (int64(x.A[i]) & 4294967295); var product_2 int64 = tmp3 + int64(z.A[k_2])&4294967295 + carry






					z.A[k_2] = int32(product_2)
					carry = int64(uint64(product_2) >> 32)
					j_2, k_2 = j_2-1, k_2-1; continue L3 }
//line :1003:1
				break L3
			}











			z.A[i] = int32(carry)
			i = i - 1; continue L2 }
//line :1000:1
		break L2 }
//line :986:1
	return z
}
































func BigInteger_MultiplyToLenCheck_I1_I__V(array *IntArray, length int32) { BigInteger_Init()
	if length <= 0 { } else {
		Objects_RequireNonNull_O__O(array.Ref())
		if length > int32(len(array.A)) {
			panic(Thrown(ArrayIndexOutOfBoundsException_New_I(length - 1)))
		} } }
func BigInteger_MultiplyKaratsuba_BigInteger_BigInteger__BigInteger(x, y *BigInteger) *BigInteger { BigInteger_Init()
	var xlen int32 = int32(len(x.F_mag.A)); var ylen int32 = int32(len(y.F_mag.A)); var half int32 = (Math_Max_I_I__I(xlen, ylen) + 1) / 2; var xl *BigInteger = NN(x).GetLower_I__BigInteger(half); var xh *BigInteger = NN(x).GetUpper_I__BigInteger(half); var yl *BigInteger = NN(y).GetLower_I__BigInteger(half); var yh *BigInteger = NN(y).GetUpper_I__BigInteger(half); var p1 *BigInteger = NN(xh).Multiply_BigInteger__BigInteger(yh); var p2 *BigInteger = NN(xl).Multiply_BigInteger__BigInteger(yl); var p3 *BigInteger = NN(NN(xh).Add_BigInteger__BigInteger(xl)).Multiply_BigInteger__BigInteger(NN(yh).Add_BigInteger__BigInteger(yl)); var result *BigInteger = NN(NN(NN(NN(p1).ShiftLeft_I__BigInteger(32 * half)).Add_BigInteger__BigInteger(NN(NN(p3).Subtract_BigInteger__BigInteger(p1)).Subtract_BigInteger__BigInteger(p2))).ShiftLeft_I__BigInteger(32 * half)).Add_BigInteger__BigInteger(p2); var tmp1 int32 = x.F_signum













	if !(tmp1 == y.F_signum) { return NN(result).Negate__BigInteger() } else { return result
	}
}





func BigInteger_RecursiveOp_CalculateMaximumDepth_I__I(parallelism int32) int32 { BigInteger_RecursiveOp_Init()
	return 32 - Integer_NumberOfLeadingZeros_I__I(parallelism)
}




func (t *BigInteger_RecursiveOp) Ctor_Z_I(this BigInteger_RecursiveOp_I, parallel bool, depth int32) { t.RecursiveTask.Ctor(this)
	t.F_parallel = parallel
	t.F_depth = int8(depth)
}
func BigInteger_RecursiveOp_GetParallelForkDepthThreshold__I() int32 { BigInteger_RecursiveOp_Init()
	var tmp1 Thread_I = Thread_CurrentThread__Thread(); if ForkJoinWorkerThread_InstanceOf(tmp1) { var fjwt ForkJoinWorkerThread_I = ForkJoinWorkerThread_Cast(tmp1)
		return BigInteger_RecursiveOp_CalculateMaximumDepth_I__I(NN(fjwt.GetPool__ForkJoinPool()).GetParallelism__I()) } else {
//line :1061:1
			return BigInteger_RecursiveOp_PARALLEL_FORK_DEPTH_THRESHOLD
		}
}

func (t *BigInteger_RecursiveOp) Impl_ForkOrInvoke__RecursiveTask(this BigInteger_RecursiveOp_I) RecursiveTask_I {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_parallel; if tmp2 { var tmp3 int32 = int32(t.F_depth); tmp2 = tmp3 <= BigInteger_RecursiveOp_GetParallelForkDepthThreshold__I() }; tmp1 = tmp2; if tmp1 {
		this.Fork__ForkJoinTask() } else {
			this.Invoke__O() }
//line :1065:1
	return this
}











func BigInteger_RecursiveOp_RecursiveMultiply_New_BigInteger_BigInteger_Z_I(p0, p1 *BigInteger, p2 bool, p3 int32) *BigInteger_RecursiveOp_RecursiveMultiply { BigInteger_RecursiveOp_RecursiveMultiply_Init(); t := &BigInteger_RecursiveOp_RecursiveMultiply{}; t.Ctor_BigInteger_BigInteger_Z_I(p0, p1, p2, p3); return t }
//line :1078:1
func (t *BigInteger_RecursiveOp_RecursiveMultiply) Ctor_BigInteger_BigInteger_Z_I(a, b *BigInteger, parallel bool, depth int32) { t.BigInteger_RecursiveOp.Ctor_Z_I(t, parallel, depth)

	t.F_a = a
	t.F_b = b
}
func (t *BigInteger_RecursiveOp_RecursiveMultiply) Compute__BigInteger() *BigInteger {
	return NN(t.F_a).Multiply_BigInteger_Z_Z_I__BigInteger(t.F_b, true, t.F_parallel, int32(t.F_depth))
}





func BigInteger_RecursiveOp_RecursiveSquare_New_BigInteger_Z_I(p0 *BigInteger, p1 bool, p2 int32) *BigInteger_RecursiveOp_RecursiveSquare { BigInteger_RecursiveOp_RecursiveSquare_Init(); t := &BigInteger_RecursiveOp_RecursiveSquare{}; t.Ctor_BigInteger_Z_I(p0, p1, p2); return t }
//line :1091:1
func (t *BigInteger_RecursiveOp_RecursiveSquare) Ctor_BigInteger_Z_I(a *BigInteger, parallel bool, depth int32) { t.BigInteger_RecursiveOp.Ctor_Z_I(t, parallel, depth)

	t.F_a = a
}
func (t *BigInteger_RecursiveOp_RecursiveSquare) Compute__BigInteger() *BigInteger {
	return NN(t.F_a).Square_Z_Z_I__BigInteger(true, t.F_parallel, int32(t.F_depth))
}
func BigInteger_RecursiveOp_Multiply_BigInteger_BigInteger_Z_I__RecursiveTask(a, b *BigInteger, parallel bool, depth int32) RecursiveTask_I { BigInteger_RecursiveOp_Init()



	return BigInteger_RecursiveOp_RecursiveMultiply_New_BigInteger_BigInteger_Z_I(a, b, parallel, depth).ForkOrInvoke__RecursiveTask()
}
func BigInteger_RecursiveOp_Square_BigInteger_Z_I__RecursiveTask(a *BigInteger, parallel bool, depth int32) RecursiveTask_I { BigInteger_RecursiveOp_Init()


	return BigInteger_RecursiveOp_RecursiveSquare_New_BigInteger_Z_I(a, parallel, depth).ForkOrInvoke__RecursiveTask()
}
func BigInteger_MultiplyToomCook3_BigInteger_BigInteger_Z_I__BigInteger(a, b *BigInteger, parallel bool, depth int32) *BigInteger { BigInteger_Init()

	var alen int32 = int32(len(a.F_mag.A)); var blen int32 = int32(len(b.F_mag.A)); var largest int32 = Math_Max_I_I__I(alen, blen); var k int32 = (largest + 2) / 3; var r int32 = largest - 2*k; var a0 *BigInteger; var a1 *BigInteger; var a2 *BigInteger; var b0 *BigInteger; var b1 *BigInteger; var b2 *BigInteger










	a2 = NN(a).GetToomSlice_I_I_I_I__BigInteger(k, r, 0, largest)
	a1 = NN(a).GetToomSlice_I_I_I_I__BigInteger(k, r, 1, largest)
	a0 = NN(a).GetToomSlice_I_I_I_I__BigInteger(k, r, 2, largest)
	b2 = NN(b).GetToomSlice_I_I_I_I__BigInteger(k, r, 0, largest)
	b1 = NN(b).GetToomSlice_I_I_I_I__BigInteger(k, r, 1, largest)
	b0 = NN(b).GetToomSlice_I_I_I_I__BigInteger(k, r, 2, largest)
	var v0 *BigInteger; var v1 *BigInteger; var v2 *BigInteger; var vm1 *BigInteger; var vinf *BigInteger; var t1 *BigInteger; var t2 *BigInteger; var tm1 *BigInteger; var da1 *BigInteger; var db1 *BigInteger









	depth = depth + 1
	var v0_task RecursiveTask_I = BigInteger_RecursiveOp_Multiply_BigInteger_BigInteger_Z_I__RecursiveTask(a0, b0, parallel, depth)
	da1 = NN(a2).Add_BigInteger__BigInteger(a0)
	db1 = NN(b2).Add_BigInteger__BigInteger(b0)
	var vm1_task RecursiveTask_I = BigInteger_RecursiveOp_Multiply_BigInteger_BigInteger_Z_I__RecursiveTask(NN(da1).Subtract_BigInteger__BigInteger(a1), NN(db1).Subtract_BigInteger__BigInteger(b1), parallel, depth)
	da1 = NN(da1).Add_BigInteger__BigInteger(a1)
	db1 = NN(db1).Add_BigInteger__BigInteger(b1)
	var v1_task RecursiveTask_I = BigInteger_RecursiveOp_Multiply_BigInteger_BigInteger_Z_I__RecursiveTask(da1, db1, parallel, depth)
	v2 = NN(NN(NN(NN(da1).Add_BigInteger__BigInteger(a2)).ShiftLeft_I__BigInteger(1)).Subtract_BigInteger__BigInteger(a0)).Multiply_BigInteger_Z_Z_I__BigInteger(NN(NN(NN(db1).Add_BigInteger__BigInteger(b2)).ShiftLeft_I__BigInteger(1)).Subtract_BigInteger__BigInteger(b0), true, parallel, depth)





	vinf = NN(a2).Multiply_BigInteger_Z_Z_I__BigInteger(b2, true, parallel, depth)
	v0 = BigInteger_Cast(v0_task.Join__O())
	vm1 = BigInteger_Cast(vm1_task.Join__O())
	v1 = BigInteger_Cast(v1_task.Join__O())
	t2 = NN(NN(v2).Subtract_BigInteger__BigInteger(vm1)).ExactDivideBy3__BigInteger()
	tm1 = NN(NN(v1).Subtract_BigInteger__BigInteger(vm1)).ShiftRight_I__BigInteger(1)
	t1 = NN(v1).Subtract_BigInteger__BigInteger(v0)
	t2 = NN(NN(t2).Subtract_BigInteger__BigInteger(t1)).ShiftRight_I__BigInteger(1)
	t1 = NN(NN(t1).Subtract_BigInteger__BigInteger(tm1)).Subtract_BigInteger__BigInteger(vinf)
	t2 = NN(t2).Subtract_BigInteger__BigInteger(NN(vinf).ShiftLeft_I__BigInteger(1))
	tm1 = NN(tm1).Subtract_BigInteger__BigInteger(t2)
	var ss int32 = k * 32; var result *BigInteger = NN(NN(NN(NN(NN(NN(NN(NN(vinf).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(t2)).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(t1)).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(tm1)).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(v0); var tmp1 int32 = a.F_signum









	if !(tmp1 == b.F_signum) { return NN(result).Negate__BigInteger() } else { return result
	} }
func (t *BigInteger) GetToomSlice_I_I_I_I__BigInteger(lowerSize, upperSize, slice, fullsize int32) *BigInteger {

	var start int32 = 0
	var end int32 = 0
	var sliceSize int32 = 0
	var len_ int32 = 0
	var offset int32 = 0
	len_ = int32(len(t.F_mag.A))
	offset = fullsize - len_
	if slice == 0 {

		start = 0 - offset
		end = upperSize - 1 - offset } else {

			start = upperSize + (slice-1)*lowerSize - offset






			end = start + lowerSize - 1 }
	if start < 0 { start = 0 }
	if end < 0 { return BigInteger_ZERO } else {


		sliceSize = end - start + 1
		if sliceSize <= 0 { return BigInteger_ZERO } else { var tmp1 bool; var tmp2 bool

			tmp2 = start == 0; if tmp2 { tmp2 = sliceSize >= len_ }; tmp1 = tmp2
//line :1202:1
			if tmp1 {

				return t.Abs__BigInteger() } else {

					var intSlice *IntArray = NewIntArray(sliceSize)
					System_Arraycopy_O_I_O_I_I__V(t.F_mag.Ref(), start, intSlice.Ref(), 0, sliceSize)
					return BigInteger_New_I1_I(BigInteger_TrustedStripLeadingZeroInts_I1__I1(intSlice), 1)
				} } } }
func (t *BigInteger) ExactDivideBy3__BigInteger() *BigInteger {
	var len_ int32 = int32(len(t.F_mag.A)); var result *IntArray = NewIntArray(len_)
	var x int64 = 0
	var w int64 = 0
	var q int64 = 0
	var borrow int64 = 0

	borrow = 0
	var i int32 = len_ - 1; L1: for {
		if i >= 0 {
			x = int64(t.F_mag.A[i]) & 4294967295
			w = x - borrow
			if borrow > x { borrow = 1 } else { borrow = 0 }
			q = w * 2863311531 & 4294967295
			result.A[i] = int32(q)
			if q >= 1431655766 {

				borrow = borrow + 1
				if q >= 2863311531 {
					borrow = borrow + 1; i = i - 1; continue L1 } else {
						i = i - 1; continue L1 } } else {
							i = i - 1; continue L1 } }
//line :1218:1
		break L1
	}












	result = BigInteger_TrustedStripLeadingZeroInts_I1__I1(result)
	return BigInteger_New_I1_I(result, t.F_signum)
}
func (t *BigInteger) GetLower_I__BigInteger(n int32) *BigInteger {
	var len_ int32 = int32(len(t.F_mag.A))
	if len_ <= n {
		return t.Abs__BigInteger() } else {
			var lowerInts *IntArray = NewIntArray(n)
			System_Arraycopy_O_I_O_I_I__V(t.F_mag.Ref(), len_-n, lowerInts.Ref(), 0, n)
			return BigInteger_New_I1_I(BigInteger_TrustedStripLeadingZeroInts_I1__I1(lowerInts), 1)
		} }
func (t *BigInteger) GetUpper_I__BigInteger(n int32) *BigInteger {
	var len_ int32 = int32(len(t.F_mag.A))
	if len_ <= n { return BigInteger_ZERO } else {

		var upperLen int32 = len_ - n; var upperInts *IntArray = NewIntArray(upperLen)

		System_Arraycopy_O_I_O_I_I__V(t.F_mag.Ref(), 0, upperInts.Ref(), 0, upperLen)
		return BigInteger_New_I1_I(BigInteger_TrustedStripLeadingZeroInts_I1__I1(upperInts), 1)
	} }
func (t *BigInteger) Square__BigInteger() *BigInteger {
	return t.Square_Z_Z_I__BigInteger(false, false, 0)
}
func (t *BigInteger) Square_Z_Z_I__BigInteger(isRecursion, parallel bool, depth int32) *BigInteger {
	if t.F_signum == 0 { return BigInteger_ZERO } else {

		var len_ int32 = int32(len(t.F_mag.A))
		if len_ < 128 {

			var z *IntArray = BigInteger_SquareToLen_I1_I_I1__I1(t.F_mag, len_, nil)
			return BigInteger_New_I1_I(BigInteger_TrustedStripLeadingZeroInts_I1__I1(z), 1) } else {
//line :1259:1
				if len_ < 216 {



					return t.SquareKaratsuba__BigInteger() } else {


						if isRecursion { } else {
							if t.MagBitLength__I() > 1073741824 {



								BigInteger_ReportOverflow__V() } }
						return t.SquareToomCook3_Z_I__BigInteger(parallel, depth)
					} } } }
func BigInteger_SquareToLen_I1_I_I1__I1(x *IntArray, len_ int32, z *IntArray) *IntArray { BigInteger_Init()
	var zlen int32 = len_ << 1; var tmp1 bool; var tmp2 bool
	tmp2 = z == nil; if !tmp2 { tmp2 = int32(len(z.A)) < zlen }; tmp1 = tmp2; if tmp1 { z = NewIntArray(zlen) }
	BigInteger_ImplSquareToLenChecks_I1_I_I1_I__V(x, len_, z, zlen)
	return BigInteger_ImplSquareToLen_I1_I_I1_I__I1(x, len_, z, zlen)
}
func BigInteger_ImplSquareToLenChecks_I1_I_I1_I__V(x *IntArray, len_ int32, z *IntArray, zlen int32) { BigInteger_Init()



	if len_ < 1 { panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1258, StrOfInt(len_))))) }
	if len_ > int32(len(x.A)) {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1259, StrOfInt(len_), Lit_1260, StrOfInt(int32(len(x.A)))))))
	}
	if len_*2 > int32(len(z.A)) {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1259, StrOfInt(len_*2), Lit_1260, StrOfInt(int32(len(z.A)))))))
	}



	if zlen < 1 { panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1258, StrOfInt(zlen))))) }
	if zlen > int32(len(z.A)) {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1259, StrOfInt(len_), Lit_1260, StrOfInt(int32(len(z.A)))))))
	}
}
func BigInteger_ImplSquareToLen_I1_I_I1_I__I1(x *IntArray, len_ int32, z *IntArray, zlen int32) *IntArray { BigInteger_Init()



	var lastProductLowWord int32 = 0
	var j int32 = 0
	var i int32 = 0
L1: for { if j < len_ {
	var piece int64 = int64(x.A[j]) & 4294967295; var product int64 = piece * piece

	z.A[i] = lastProductLowWord<<31 | int32(int64(uint64(product)>>33))



	i = i + 1
	z.A[i] = int32(int64(uint64(product) >> 1))
	i = i + 1
	lastProductLowWord = int32(product)
	j = j + 1
//line :1306:1
	continue L1 }; break L1
}










	var i_2 int32 = len_; var offset int32 = 1; L2: for {

		if i_2 > 0 {
			var t_ int32 = x.A[i_2-1]
			t_ = BigInteger_MulAdd_I1_I1_I_I_I__I(z, x, offset, i_2-1, t_)
			BigInteger_AddOne_I1_I_I_I__I(z, offset-1, i_2, t_)
			i_2, offset = i_2-1, offset+2; continue L2 }
//line :1318:1
		break L2
	}





	BigInteger_PrimitiveLeftShift_I1_I_I__V(z, zlen, 1)
	var i_7 int32 = zlen - 1; var tmp1 int32 = z.A[i_7]
	z.A[i_7] = tmp1 | x.A[len_-1]&1
//line :1303:1
	return z
}



























func (t *BigInteger) SquareKaratsuba__BigInteger() *BigInteger {
	var half int32 = (int32(len(t.F_mag.A)) + 1) / 2; var xl *BigInteger = t.GetLower_I__BigInteger(half); var xh *BigInteger = t.GetUpper_I__BigInteger(half); var xhs *BigInteger = NN(xh).Square__BigInteger(); var xls *BigInteger = NN(xl).Square__BigInteger()




	return NN(NN(NN(NN(xhs).ShiftLeft_I__BigInteger(half * 32)).Add_BigInteger__BigInteger(NN(NN(NN(xl).Add_BigInteger__BigInteger(xh)).Square__BigInteger()).Subtract_BigInteger__BigInteger(NN(xhs).Add_BigInteger__BigInteger(xls)))).ShiftLeft_I__BigInteger(half * 32)).Add_BigInteger__BigInteger(xls)
}



func (t *BigInteger) SquareToomCook3_Z_I__BigInteger(parallel bool, depth int32) *BigInteger {
	var len_ int32 = int32(len(t.F_mag.A)); var k int32 = (len_ + 2) / 3; var r int32 = len_ - 2*k; var a0 *BigInteger; var a1 *BigInteger; var a2 *BigInteger





	a2 = t.GetToomSlice_I_I_I_I__BigInteger(k, r, 0, len_)
	a1 = t.GetToomSlice_I_I_I_I__BigInteger(k, r, 1, len_)
	a0 = t.GetToomSlice_I_I_I_I__BigInteger(k, r, 2, len_)
	var v0 *BigInteger; var v1 *BigInteger; var v2 *BigInteger; var vm1 *BigInteger; var vinf *BigInteger; var t1 *BigInteger; var t2 *BigInteger; var tm1 *BigInteger; var da1 *BigInteger








	depth = depth + 1
	var v0_fork RecursiveTask_I = BigInteger_RecursiveOp_Square_BigInteger_Z_I__RecursiveTask(a0, parallel, depth)
	da1 = NN(a2).Add_BigInteger__BigInteger(a0)
	var vm1_fork RecursiveTask_I = BigInteger_RecursiveOp_Square_BigInteger_Z_I__RecursiveTask(NN(da1).Subtract_BigInteger__BigInteger(a1), parallel, depth)
	da1 = NN(da1).Add_BigInteger__BigInteger(a1)
	var v1_fork RecursiveTask_I = BigInteger_RecursiveOp_Square_BigInteger_Z_I__RecursiveTask(da1, parallel, depth)
	vinf = NN(a2).Square_Z_Z_I__BigInteger(true, parallel, depth)
	v2 = NN(NN(NN(NN(da1).Add_BigInteger__BigInteger(a2)).ShiftLeft_I__BigInteger(1)).Subtract_BigInteger__BigInteger(a0)).Square_Z_Z_I__BigInteger(true, parallel, depth)
	v0 = BigInteger_Cast(v0_fork.Join__O())
	vm1 = BigInteger_Cast(vm1_fork.Join__O())
	v1 = BigInteger_Cast(v1_fork.Join__O())
	t2 = NN(NN(v2).Subtract_BigInteger__BigInteger(vm1)).ExactDivideBy3__BigInteger()
	tm1 = NN(NN(v1).Subtract_BigInteger__BigInteger(vm1)).ShiftRight_I__BigInteger(1)
	t1 = NN(v1).Subtract_BigInteger__BigInteger(v0)
	t2 = NN(NN(t2).Subtract_BigInteger__BigInteger(t1)).ShiftRight_I__BigInteger(1)
	t1 = NN(NN(t1).Subtract_BigInteger__BigInteger(tm1)).Subtract_BigInteger__BigInteger(vinf)
	t2 = NN(t2).Subtract_BigInteger__BigInteger(NN(vinf).ShiftLeft_I__BigInteger(1))
	tm1 = NN(tm1).Subtract_BigInteger__BigInteger(t2)
	var ss int32 = k * 32
	return NN(NN(NN(NN(NN(NN(NN(NN(vinf).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(t2)).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(t1)).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(tm1)).ShiftLeft_I__BigInteger(ss)).Add_BigInteger__BigInteger(v0)
}





func (t *BigInteger) Divide_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var tmp1 bool; var tmp2 bool
	tmp2 = int32(len(val.F_mag.A)) < 80
//line :1389:1
	if !tmp2 {

		var tmp3 int32 = int32(len(t.F_mag.A)); tmp2 = tmp3-int32(len(val.F_mag.A)) < 40 }
//line :1389:1
	tmp1 = tmp2; if tmp1 {


		return t.DivideKnuth_BigInteger__BigInteger(val) } else {
			return t.DivideBurnikelZiegler_BigInteger__BigInteger(val)
		} }
func (t *BigInteger) DivideKnuth_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var q MutableBigInteger_I = MutableBigInteger_New(); var a MutableBigInteger_I = MutableBigInteger_New_I1(t.F_mag); var b MutableBigInteger_I = MutableBigInteger_New_I1(val.F_mag)


	a.DivideKnuth_MutableBigInteger_MutableBigInteger_Z__MutableBigInteger(b, q, false)
	var tmp1 int32 = t.F_signum; return q.ToBigInteger_I__BigInteger(tmp1 * val.F_signum)
}
func (t *BigInteger) DivideAndRemainder_BigInteger__BigInteger1(val *BigInteger) *RefArray {
	var tmp1 bool; var tmp2 bool
	tmp2 = int32(len(val.F_mag.A)) < 80
//line :1403:1
	if !tmp2 {

		var tmp3 int32 = int32(len(t.F_mag.A)); tmp2 = tmp3-int32(len(val.F_mag.A)) < 40 }
//line :1403:1
	tmp1 = tmp2; if tmp1 {


		return t.DivideAndRemainderKnuth_BigInteger__BigInteger1(val) } else {
			return t.DivideAndRemainderBurnikelZiegler_BigInteger__BigInteger1(val)
		} }
func (t *BigInteger) DivideAndRemainderKnuth_BigInteger__BigInteger1(val *BigInteger) *RefArray {
	var result *RefArray = NewRefArray(BigInteger_class, 2); var q MutableBigInteger_I = MutableBigInteger_New(); var a MutableBigInteger_I = MutableBigInteger_New_I1(t.F_mag); var b MutableBigInteger_I = MutableBigInteger_New_I1(val.F_mag); var r MutableBigInteger_I = a.DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, q); var tmp1 int32; var tmp2 int32 = t.F_signum




	if tmp2 == val.F_signum { tmp1 = 1 } else { tmp1 = -1 }; result.Store(0, q.ToBigInteger_I__BigInteger(tmp1).Ref())
	result.Store(1, r.ToBigInteger_I__BigInteger(t.F_signum).Ref())
//line :1410:1
	return result
}







func (t *BigInteger) Remainder_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var tmp1 bool; var tmp2 bool
	tmp2 = int32(len(val.F_mag.A)) < 80
//line :1420:1
	if !tmp2 {

		var tmp3 int32 = int32(len(t.F_mag.A)); tmp2 = tmp3-int32(len(val.F_mag.A)) < 40 }
//line :1420:1
	tmp1 = tmp2; if tmp1 {


		return t.RemainderKnuth_BigInteger__BigInteger(val) } else {
			return t.RemainderBurnikelZiegler_BigInteger__BigInteger(val)
		} }
func (t *BigInteger) RemainderKnuth_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var q MutableBigInteger_I = MutableBigInteger_New(); var a MutableBigInteger_I = MutableBigInteger_New_I1(t.F_mag); var b MutableBigInteger_I = MutableBigInteger_New_I1(val.F_mag)


	return a.DivideKnuth_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, q).ToBigInteger_I__BigInteger(t.F_signum)
}
func (t *BigInteger) DivideBurnikelZiegler_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	return As[*BigInteger](t.DivideAndRemainderBurnikelZiegler_BigInteger__BigInteger1(val).A[0])
}
func (t *BigInteger) RemainderBurnikelZiegler_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	return As[*BigInteger](t.DivideAndRemainderBurnikelZiegler_BigInteger__BigInteger1(val).A[1])
}
func (t *BigInteger) DivideAndRemainderBurnikelZiegler_BigInteger__BigInteger1(val *BigInteger) *RefArray {
	var q MutableBigInteger_I = MutableBigInteger_New(); var r MutableBigInteger_I = MutableBigInteger_New_BigInteger(t).DivideAndRemainderBurnikelZiegler_MutableBigInteger_MutableBigInteger__MutableBigInteger(MutableBigInteger_New_BigInteger(val), q); var qBigInt *BigInteger



	if q.IsZero__Z() { qBigInt = BigInteger_ZERO } else {

		var tmp1 int32 = t.F_signum; qBigInt = q.ToBigInteger_I__BigInteger(tmp1 * val.F_signum) }
//line :1439:1
	var rBigInt *BigInteger






	if r.IsZero__Z() { rBigInt = BigInteger_ZERO } else { rBigInt = r.ToBigInteger_I__BigInteger(t.F_signum) }
	return RefArrayOf(BigInteger_class, qBigInt.Ref(), rBigInt.Ref())
}
func (t *BigInteger) Pow_I__BigInteger(exponent int32) *BigInteger {
	if exponent < 0 { panic(Thrown(ArithmeticException_New_String(Lit_1261))) }
	var tmp1 bool; var tmp2 bool
	tmp2 = exponent == 0; if !tmp2 { tmp2 = t.Equals_O__Z(BigInteger_ONE.Ref()) }; tmp1 = tmp2
//line :1451:1
	if tmp1 { return BigInteger_ONE } else { var tmp3 bool; var tmp4 bool

		tmp4 = t.F_signum == 0; if !tmp4 { tmp4 = exponent == 1 }; tmp3 = tmp4
//line :1451:1
		if tmp3 { return t } else {



			var base *BigInteger = t.Abs__BigInteger(); var negative bool; var tmp5 bool
			tmp5 = t.F_signum < 0; if tmp5 { tmp5 = exponent&1 == 1 }; negative = tmp5
//line :1455:1
			var powersOfTwo int32 = NN(base).GetLowestSetBit__I(); var bitsToShiftLong int64 = int64(powersOfTwo) * int64(exponent); var bitsToShift int32 = int32(bitsToShiftLong)




			if int64(bitsToShift) == bitsToShiftLong { } else { BigInteger_ReportOverflow__V() }
			base = NN(base).ShiftRight_I__BigInteger(powersOfTwo)
			var remainingBits int32 = NN(base).BitLength__I()
			if remainingBits == 1 {
				var tmp6 *BigInteger; if negative { tmp6 = BigInteger_NEGATIVE_ONE } else { tmp6 = BigInteger_ONE }; return NN(tmp6).ShiftLeft_I__BigInteger(bitsToShift) } else {
					var scaleFactor int64 = int64(remainingBits) * int64(exponent)
					if scaleFactor <= 64 {
						var newSign int32; if negative { newSign = -1 } else { newSign = 1 }; var result int64 = BigInteger_UnsignedLongPow_J_I__J(int64(base.F_mag.A[0])&4294967295, exponent)



						if int64(bitsToShift)+scaleFactor <= 64 {
							return BigInteger_New_J_I(result<<(bitsToShift&63), newSign) } else {
								return BigInteger_New_J_I(result, newSign).ShiftLeft_I__BigInteger(bitsToShift) } } else {

									if scaleFactor+int64(bitsToShift)-int64(exponent) >= 2147483647 {



										BigInteger_ReportOverflow__V() }
									var answer *BigInteger = BigInteger_ONE; var expZeros int32 = Integer_NumberOfLeadingZeros_I__I(exponent); var workingExp int32 = exponent << (expZeros & 31); var expLen int32 = 32 - expZeros


								L1: for {
									if expLen > 0 {
										answer = NN(answer).Multiply_BigInteger__BigInteger(answer)
										if workingExp < 0 { answer = NN(answer).Multiply_BigInteger__BigInteger(base) }
										workingExp = workingExp << 1
										expLen = expLen - 1; continue L1 }
//line :1483:1
									break L1
								}




									answer = NN(answer).ShiftLeft_I__BigInteger(bitsToShift)
									if negative { return NN(answer).Negate__BigInteger() } else { return answer
									} } } } } }
func BigInteger_UnsignedLongPow_J_I__J(x int64, n int32) int64 { BigInteger_Init()
	var tmp1 bool; var tmp2 bool
	tmp2 = x == 1; if !tmp2 { tmp2 = n == 0 }; tmp1 = tmp2
//line :1493:1
	if tmp1 { return 1 } else { if x == 2 {

		return 1 << (n & 63) } else {

			var pow int64 = 1
		L1: for { if !(n == 1) {
			if n&1 == 0 { } else { pow = pow * x }
			x = x * x
			n = int32(uint32(n) >> 1)
//line :1498:1
			continue L1 }; break L1
		}


			return pow * x
		} } }
func (t *BigInteger) Sqrt__BigInteger() *BigInteger {
	if t.F_signum < 0 { panic(Thrown(ArithmeticException_New_String(Lit_1262))) }
	return As[MutableBigInteger_I](MutableBigInteger_New_I1(t.F_mag).SqrtRem_Z__MutableBigInteger1(false).A[0]).ToBigInteger__BigInteger()
}
func (t *BigInteger) SqrtAndRemainder__BigInteger1() *RefArray {
	if t.F_signum < 0 { panic(Thrown(ArithmeticException_New_String(Lit_1262))) }
	var sqrtRem *RefArray = MutableBigInteger_New_I1(t.F_mag).SqrtRem_Z__MutableBigInteger1(true)
	return RefArrayOf(BigInteger_class, As[MutableBigInteger_I](sqrtRem.A[0]).ToBigInteger__BigInteger().Ref(), As[MutableBigInteger_I](sqrtRem.A[1]).ToBigInteger__BigInteger().Ref())
}
func (t *BigInteger) Rootn_I__BigInteger(n int32) *BigInteger {
	if n == 1 { return t } else { if n == 2 {

		return t.Sqrt__BigInteger() } else {


			t.CheckRootDegree_I__V(n)
			return As[MutableBigInteger_I](MutableBigInteger_New_I1(t.F_mag).RootnRem_I__MutableBigInteger1(n).A[0]).ToBigInteger_I__BigInteger(t.F_signum)
		} } }
func (t *BigInteger) RootnAndRemainder_I__BigInteger1(n int32) *RefArray {
	if n == 1 {
		return RefArrayOf(BigInteger_class, t, BigInteger_ZERO.Ref()) } else {
//line :1523:1
			if n == 2 {

				return t.SqrtAndRemainder__BigInteger1() } else {


					t.CheckRootDegree_I__V(n)
					var rootRem *RefArray = MutableBigInteger_New_I1(t.F_mag).RootnRem_I__MutableBigInteger1(n)
					return RefArrayOf(BigInteger_class, As[MutableBigInteger_I](rootRem.A[0]).ToBigInteger_I__BigInteger(t.F_signum).Ref(), As[MutableBigInteger_I](rootRem.A[1]).ToBigInteger_I__BigInteger(t.F_signum).Ref())
				}
		} }
func (t *BigInteger) CheckRootDegree_I__V(n int32) {
	if n <= 0 { panic(Thrown(ArithmeticException_New_String(Lit_1263))) }
	var tmp1 bool; var tmp2 bool; tmp2 = n&1 == 0; if tmp2 { tmp2 = t.F_signum < 0 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(ArithmeticException_New_String(Lit_1264)))
	} }
func (t *BigInteger) Gcd_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	if val.F_signum == 0 {
		return t.Abs__BigInteger() } else {
//line :1539:1
			if t.F_signum == 0 {

				return NN(val).Abs__BigInteger() } else {

					var a MutableBigInteger_I = MutableBigInteger_New_BigInteger(t); var b MutableBigInteger_I = MutableBigInteger_New_BigInteger(val); var result MutableBigInteger_I = a.HybridGCD_MutableBigInteger__MutableBigInteger(b)


					return result.ToBigInteger_I__BigInteger(1)
				} } }
func BigInteger_BitLengthForInt_I__I(n int32) int32 { BigInteger_Init()
	return 32 - Integer_NumberOfLeadingZeros_I__I(n)
}
func BigInteger_BitLengthForLong_J__I(n int64) int32 { BigInteger_Init()
	return 64 - Long_NumberOfLeadingZeros_J__I(n)
}
func BigInteger_LeftShift_I1_I_I__I1(a *IntArray, len_, n int32) *IntArray { BigInteger_Init()
	var nInts int32 = int32(uint32(n) >> 5); var nBits int32 = n & 31; var bitsInHighWord int32 = BigInteger_BitLengthForInt_I__I(a.A[0])


	if n <= 32-bitsInHighWord {

		BigInteger_PrimitiveLeftShift_I1_I_I__V(a, len_, nBits); return a } else {
//line :1558:1
			if nBits <= 32-bitsInHighWord {



				var result *IntArray = NewIntArray(nInts + len_)
				System_Arraycopy_O_I_O_I_I__V(a.Ref(), 0, result.Ref(), 0, len_)
				BigInteger_PrimitiveLeftShift_I1_I_I__V(result, int32(len(result.A)), nBits)
//line :1562:1
				return result } else {




					var result_2 *IntArray = NewIntArray(nInts + len_ + 1)
					System_Arraycopy_O_I_O_I_I__V(a.Ref(), 0, result_2.Ref(), 0, len_)
					BigInteger_PrimitiveRightShift_I1_I_I__V(result_2, int32(len(result_2.A)), 32-nBits)
//line :1567:1
					return result_2
				}
		}
}



func BigInteger_PrimitiveRightShift_I1_I_I__V(a *IntArray, len_, n int32) { BigInteger_Init()
	Objects_CheckFromToIndex_I_I_I__I(0, len_, int32(len(a.A)))
	BigInteger_ShiftRightImplWorker_I1_I1_I_I_I__V(a, a, 1, n, len_-1)
	a.A[0] = int32(uint32(a.A[0]) >> (n & 31))
}
func BigInteger_PrimitiveLeftShift_I1_I_I__V(a *IntArray, len_, n int32) { BigInteger_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = len_ == 0; if !tmp2 { tmp2 = n == 0 }; tmp1 = tmp2; if tmp1 { } else {
		Objects_CheckFromToIndex_I_I_I__I(0, len_, int32(len(a.A)))
		BigInteger_ShiftLeftImplWorker_I1_I1_I_I_I__V(a, a, 0, n, len_-1)
		var i_8 int32 = len_ - 1; a.A[i_8] = a.A[i_8] << (n & 31)
	} }
func (t *BigInteger) MagBitLength__I() int32 {
	var n int32 = t.F_magBitLengthPlusOne - 1
	if n == -1 {
		var tmp1 int32
		if int32(len(t.F_mag.A)) == 0 { tmp1 = 0 } else {

			var tmp2 int32 = int32(len(t.F_mag.A)) * 32; tmp1 = tmp2 - Integer_NumberOfLeadingZeros_I__I(t.F_mag.A[0]) }
//line :1588:1
		n = tmp1




		t.F_magBitLengthPlusOne = n + 1 }
//line :1586:1
	return n
}








func (t *BigInteger) Abs__BigInteger() *BigInteger {
	if t.F_signum >= 0 { return t } else { return t.Negate__BigInteger()
	} }
func (t *BigInteger) Negate__BigInteger() *BigInteger {
	return BigInteger_New_I1_I(t.F_mag, -t.F_signum)
}
func (t *BigInteger) Signum__I() int32 { return t.F_signum }

func (t *BigInteger) Mod_BigInteger__BigInteger(m *BigInteger) *BigInteger {
	if m.F_signum <= 0 { panic(Thrown(ArithmeticException_New_String(Lit_1265))) }
	var result *BigInteger = t.Remainder_BigInteger__BigInteger(m); if result.F_signum >= 0 { return result } else { return NN(result).Add_BigInteger__BigInteger(m)
	} }
func (t *BigInteger) ModPow_BigInteger_BigInteger__BigInteger(exponent, m *BigInteger) *BigInteger {
	if m.F_signum <= 0 { panic(Thrown(ArithmeticException_New_String(Lit_1265))) }
	if exponent.F_signum == 0 {
		if NN(m).Equals_O__Z(BigInteger_ONE.Ref()) { return BigInteger_ZERO } else { return BigInteger_ONE } } else {
//line :1610:1
			if t.Equals_O__Z(BigInteger_ONE.Ref()) {

				if NN(m).Equals_O__Z(BigInteger_ONE.Ref()) { return BigInteger_ZERO } else { return BigInteger_ONE } } else {
//line :1610:1
					var tmp1 bool; var tmp2 bool


					tmp2 = t.Equals_O__Z(BigInteger_ZERO.Ref()); if tmp2 { tmp2 = exponent.F_signum >= 0 }; tmp1 = tmp2
//line :1610:1
					if tmp1 { return BigInteger_ZERO } else { var tmp3 bool; var tmp4 bool



						tmp4 = t.Equals_O__Z(As[*BigInteger](BigInteger_negConst.A[1]).Ref()); if tmp4 { tmp4 = !NN(exponent).TestBit_I__Z(0) }; tmp3 = tmp4
//line :1610:1
						if tmp3 {




							if NN(m).Equals_O__Z(BigInteger_ONE.Ref()) { return BigInteger_ZERO } else { return BigInteger_ONE } } else {

								var invertResult bool = false; var tmp5 bool
								invertResult = exponent.F_signum < 0; tmp5 = invertResult; if tmp5 { exponent = NN(exponent).Negate__BigInteger() }
								var base *BigInteger; var tmp6 bool; var tmp7 bool; tmp7 = t.F_signum < 0; if !tmp7 { tmp7 = t.CompareTo_BigInteger__I(m) >= 0 }; tmp6 = tmp7; if tmp6 {
									base = t.Mod_BigInteger__BigInteger(m) } else {
//line :1619:1
										base = t }; var result *BigInteger



								if NN(m).TestBit_I__Z(0) {
									result = NN(base).OddModPow_BigInteger_BigInteger__BigInteger(exponent, m) } else {
										var p int32 = NN(m).GetLowestSetBit__I(); var m1 *BigInteger = NN(m).ShiftRight_I__BigInteger(p); var m2 *BigInteger = NN(BigInteger_ONE).ShiftLeft_I__BigInteger(p); var base2 *BigInteger; var tmp8 bool; var tmp9 bool


										tmp9 = t.F_signum < 0; if !tmp9 { tmp9 = t.CompareTo_BigInteger__I(m1) >= 0 }; tmp8 = tmp9; if tmp8 {
											base2 = t.Mod_BigInteger__BigInteger(m1) } else {
//line :1628:1
												base2 = t }
//line :1625:1
										var a1 *BigInteger





										if NN(m1).Equals_O__Z(BigInteger_ONE.Ref()) { a1 = BigInteger_ZERO } else { a1 = NN(base2).OddModPow_BigInteger_BigInteger__BigInteger(exponent, m1) }
//line :1625:1
										var a2 *BigInteger = NN(base).ModPow2_BigInteger_I__BigInteger(exponent, p); var y1 *BigInteger = NN(m2).ModInverse_BigInteger__BigInteger(m1); var y2 *BigInteger = NN(m1).ModInverse_BigInteger__BigInteger(m2)









										if int32(len(m.F_mag.A)) < 33554432 {
											result = NN(NN(NN(NN(a1).Multiply_BigInteger__BigInteger(m2)).Multiply_BigInteger__BigInteger(y1)).Add_BigInteger__BigInteger(NN(NN(a2).Multiply_BigInteger__BigInteger(m1)).Multiply_BigInteger__BigInteger(y2))).Mod_BigInteger__BigInteger(m) } else {



												var t1 MutableBigInteger_I = MutableBigInteger_New()
												MutableBigInteger_New_BigInteger(NN(a1).Multiply_BigInteger__BigInteger(m2)).Multiply_MutableBigInteger_MutableBigInteger__V(MutableBigInteger_New_BigInteger(y1), t1)


												var t2 MutableBigInteger_I = MutableBigInteger_New()
												MutableBigInteger_New_BigInteger(NN(a2).Multiply_BigInteger__BigInteger(m1)).Multiply_MutableBigInteger_MutableBigInteger__V(MutableBigInteger_New_BigInteger(y2), t2)


												t1.Add_MutableBigInteger__V(t2)
												var q MutableBigInteger_I = MutableBigInteger_New()
												result = t1.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(MutableBigInteger_New_BigInteger(m), q).ToBigInteger__BigInteger() } }
								if invertResult { return NN(result).ModInverse_BigInteger__BigInteger(m) } else { return result
								} } } } } }
func BigInteger_MontgomeryMultiply_I1_I1_I1_I_J_I1__I1(a, b, n *IntArray, len_ int32, inv int64, product *IntArray) *IntArray { BigInteger_Init()

	BigInteger_ImplMontgomeryMultiplyChecks_I1_I1_I1_I_I1__V(a, b, n, len_, product)
	if len_ > 512 {

		product = BigInteger_MultiplyToLen_I1_I_I1_I_I1__I1(a, len_, b, len_, product)
		return BigInteger_MontReduce_I1_I1_I_I__I1(product, n, len_, int32(inv)) } else {
			return BigInteger_ImplMontgomeryMultiply_I1_I1_I1_I_J_I1__I1(a, b, n, len_, inv, BigInteger_Materialize_I1_I__I1(product, len_))
		} }
func BigInteger_MontgomerySquare_I1_I1_I_J_I1__I1(a, n *IntArray, len_ int32, inv int64, product *IntArray) *IntArray { BigInteger_Init()

	BigInteger_ImplMontgomeryMultiplyChecks_I1_I1_I1_I_I1__V(a, a, n, len_, product)
	if len_ > 512 {

		product = BigInteger_SquareToLen_I1_I_I1__I1(a, len_, product)
		return BigInteger_MontReduce_I1_I1_I_I__I1(product, n, len_, int32(inv)) } else {
			return BigInteger_ImplMontgomerySquare_I1_I1_I_J_I1__I1(a, n, len_, inv, BigInteger_Materialize_I1_I__I1(product, len_))
		} }
func BigInteger_ImplMontgomeryMultiplyChecks_I1_I1_I1_I_I1__V(a, b, n *IntArray, len_ int32, product *IntArray) { BigInteger_Init()




	if len_%2 == 0 { } else {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1266, StrOfInt(len_))))) }
	if len_ < 1 { panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1258, StrOfInt(len_))))) }
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = len_ > int32(len(a.A)); if !tmp4 { tmp4 = len_ > int32(len(b.A)) }; tmp3 = tmp4; if !tmp3 { tmp3 = len_ > int32(len(n.A)) }; tmp2 = tmp3; if !tmp2 {
		var tmp5 bool; tmp5 = !(product == nil); if tmp5 { tmp5 = len_ > int32(len(product.A)) }; tmp2 = tmp5 }
//line :1679:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1267, StrOfInt(len_)))))
	} }
func BigInteger_Materialize_I1_I__I1(z *IntArray, len_ int32) *IntArray { BigInteger_Init()
	var tmp1 bool; var tmp2 bool; tmp2 = z == nil; if !tmp2 { tmp2 = int32(len(z.A)) < len_ }; tmp1 = tmp2; if tmp1 { z = NewIntArray(len_) }
//line :1683:1
	return z
}


func BigInteger_ImplMontgomeryMultiply_I1_I1_I1_I_J_I1__I1(a, b, n *IntArray, len_ int32, inv int64, product *IntArray) *IntArray { BigInteger_Init()





	product = BigInteger_MultiplyToLen_I1_I_I1_I_I1__I1(a, len_, b, len_, product)
	return BigInteger_MontReduce_I1_I1_I_I__I1(product, n, len_, int32(inv))
}
func BigInteger_ImplMontgomerySquare_I1_I1_I_J_I1__I1(a, n *IntArray, len_ int32, inv int64, product *IntArray) *IntArray { BigInteger_Init()




	product = BigInteger_SquareToLen_I1_I_I1__I1(a, len_, product)
	return BigInteger_MontReduce_I1_I1_I_I__I1(product, n, len_, int32(inv))
}


func (t *BigInteger) OddModPow_BigInteger_BigInteger__BigInteger(y, z *BigInteger) *BigInteger {
	if NN(y).Equals_O__Z(BigInteger_ONE.Ref()) { return t } else { if t.F_signum == 0 { return BigInteger_ZERO } else {



		var base *IntArray = NN(t.F_mag).Copy(); var exp *IntArray = y.F_mag; var mod *IntArray = z.F_mag; var modLen int32 = int32(len(mod.A))



		if modLen&1 == 0 { } else {
			var x *IntArray = NewIntArray(modLen + 1)
			System_Arraycopy_O_I_O_I_I__V(mod.Ref(), 0, x.Ref(), 1, modLen)
			mod = x
			modLen = modLen + 1 }
		var wbits int32 = 0; var ebits int32 = NN(y).MagBitLength__I(); var tmp1 bool; var tmp2 bool

		tmp2 = !(ebits == 17); if !tmp2 { tmp2 = !(exp.A[0] == 65537) }; tmp1 = tmp2; if tmp1 {
		L1: for { if ebits > BigInteger_bnExpModThreshTable.A[wbits] {
			wbits = wbits + 1
//line :1723:1
			continue L1 }; break L1
		} }
		var tblmask int32 = 1 << (wbits & 31); var table *RefArray = NewRefArray(Prim_int.ArrayClass(), tblmask)
		var i int32 = 0
	L2: for {
		if i < tblmask { table.Store(i, NewIntArray(modLen)); i = i + 1; continue L2 }
//line :1727:1
		break L2
	}
		var tmp3 int64 = int64(mod.A[modLen-1]) & 4294967295; var n0 int64 = tmp3 + int64(mod.A[modLen-2])&4294967295<<32; var inv int64 = -MutableBigInteger_InverseMod64_J__J(n0); var a *IntArray = BigInteger_LeftShift_I1_I_I__I1(base, int32(len(base.A)), modLen<<5); var q MutableBigInteger_I = MutableBigInteger_New(); var a2 MutableBigInteger_I = MutableBigInteger_New_I1(a); var b2 MutableBigInteger_I = MutableBigInteger_New_I1(mod)












		b2.Normalize__V()
		var r MutableBigInteger_I = a2.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(b2, q)
		table.Store(0, r.ToIntArray__I1().Ref())
		if int32(len(As[*IntArray](table.A[0]).A)) < modLen {
			var offset int32 = modLen - int32(len(As[*IntArray](table.A[0]).A)); var t2 *IntArray = NewIntArray(modLen); var tmp4 any = As[*IntArray](table.A[0]).Ref()

			System_Arraycopy_O_I_O_I_I__V(tmp4, 0, t2.Ref(), offset, int32(len(As[*IntArray](table.A[0]).A)))
			table.Store(0, t2.Ref()) }
		var b *IntArray = BigInteger_MontgomerySquare_I1_I1_I_J_I1__I1(As[*IntArray](table.A[0]), mod, modLen, inv, nil); var t_ *IntArray = Arrays_CopyOf_I1_I__I1(b, modLen)
		var i_2 int32 = 1
	L3: for {
		if i_2 < tblmask {
			table.Store(i_2, BigInteger_MontgomeryMultiply_I1_I1_I1_I_J_I1__I1(t_, As[*IntArray](table.A[i_2-1]), mod, modLen, inv, nil).Ref())








			i_2 = i_2 + 1; continue L3 }
//line :1752:1
		break L3
	}










		var bitpos int32 = 1 << ((ebits - 1) & 31 & 31); var buf int32 = 0; var elen int32 = int32(len(exp.A))
		var eIndex int32 = 0
		var i_3 int32 = 0



	L4: for {
		if i_3 <= wbits {
			var tmp5 int32 = buf << 1; var tmp6 int32

			if !(exp.A[eIndex]&bitpos == 0) { tmp6 = 1 } else { tmp6 = 0 }
//line :1772:1
			buf = tmp5 | tmp6




			bitpos = int32(uint32(bitpos) >> 1)
			if bitpos == 0 {

				eIndex = eIndex + 1
				bitpos = -2147483648
				elen = elen - 1
				i_3 = i_3 + 1; continue L4 } else {
					i_3 = i_3 + 1; continue L4 } }
//line :1770:1
		break L4
	}













		var multpos int32 = ebits
		ebits = ebits - 1
		var isone bool = true
		multpos = ebits - wbits
	L5: for { if buf&1 == 0 {
		buf = int32(uint32(buf) >> 1)
		multpos = multpos + 1
//line :1789:1
		continue L5 }; break L5
	}

		var mult *IntArray = As[*IntArray](table.A[int32(uint32(buf)>>1)])
		buf = 0
		if multpos == ebits { isone = false }
	L6: for {
		ebits = ebits - 1
		buf = buf << 1
		if elen == 0 { } else {
			var tmp7 int32 = buf; var tmp8 int32


			if !(exp.A[eIndex]&bitpos == 0) { tmp8 = 1 } else { tmp8 = 0 }
//line :1799:1
			buf = tmp7 | tmp8






			bitpos = int32(uint32(bitpos) >> 1)
			if bitpos == 0 {
				eIndex = eIndex + 1
				bitpos = -2147483648
				elen = elen - 1 } }
		if buf&tblmask == 0 { } else {
			multpos = ebits - wbits
		L7: for { if buf&1 == 0 {
			buf = int32(uint32(buf) >> 1)
			multpos = multpos + 1
//line :1813:1
			continue L7 }; break L7
		}

			mult = As[*IntArray](table.A[int32(uint32(buf)>>1)])
			buf = 0 }
		if ebits == multpos {
			if isone {
				b = NN(mult).Copy(); isone = false } else {

					t_ = b
					a = BigInteger_MontgomeryMultiply_I1_I1_I1_I_J_I1__I1(t_, mult, mod, modLen, inv, a)

					t_ = a
					a = b
					b = t_ } }
		if ebits == 0 { break L6 }
		if isone { } else {
			t_ = b
			a = BigInteger_MontgomerySquare_I1_I1_I_J_I1__I1(t_, mod, modLen, inv, a)
			t_ = a
			a = b
			b = t_ }
//line :1795:1
		continue L6
	}






































		var t2_2 *IntArray = NewIntArray(2 * modLen)
		System_Arraycopy_O_I_O_I_I__V(b.Ref(), 0, t2_2.Ref(), modLen, modLen)
		b = BigInteger_MontReduce_I1_I1_I_I__I1(t2_2, mod, modLen, int32(inv))
		t2_2 = Arrays_CopyOf_I1_I__I1(b, modLen)
		return BigInteger_New_I_I1(1, t2_2)
	} } }
func BigInteger_MontReduce_I1_I1_I_I__I1(n, mod *IntArray, mlen, inv int32) *IntArray { BigInteger_Init()
	var c int32 = 0
	var len_ int32 = mlen
	var offset int32 = 0
L1: for {
	var nEnd int32 = n.A[int32(len(n.A))-1-offset]; var carry int32 = BigInteger_MulAdd_I1_I1_I_I_I__I(n, mod, offset, mlen, inv*nEnd)

	c = c + BigInteger_AddOne_I1_I_I_I__I(n, offset, mlen, carry)
	offset = offset + 1
	var tmp1 int32; len_ = len_ - 1; tmp1 = len_; if tmp1 > 0 { continue L1 }
//line :1845:1
	break L1
}




L2: for { if c > 0 { c = c + BigInteger_SubN_I1_I1_I__I(n, mod, mlen); continue L2 }; break L2 }
L3: for { if BigInteger_IntArrayCmpToLen_I1_I1_I__I(n, mod, mlen) >= 0 { BigInteger_SubN_I1_I1_I__I(n, mod, mlen); continue L3 }; break L3 }
//line :1842:1
	return n
}











func BigInteger_IntArrayCmpToLen_I1_I1_I__I(arg1, arg2 *IntArray, len_ int32) int32 { BigInteger_Init()
	var i int32 = 0; L1: for {
		if i < len_ {
			var b1 int64 = int64(arg1.A[i]) & 4294967295; var b2 int64 = int64(arg2.A[i]) & 4294967295

			if b1 < b2 { return -1 }
			if b1 > b2 { return 1 } else { i = i + 1; continue L1 } }
//line :1856:1
		break L1 }
//line :1855:1
	return 0
}







func BigInteger_SubN_I1_I1_I__I(a, b *IntArray, len_ int32) int32 { BigInteger_Init()
	var sum int64 = 0
L1: for { var tmp1 int32; len_ = len_ - 1; tmp1 = len_; if tmp1 >= 0 {
	var tmp2 int64 = int64(a.A[len_]) & 4294967295; sum = tmp2 - int64(b.A[len_])&4294967295 + sum>>32




	a.A[len_] = int32(sum)
//line :1866:1
	continue L1 }; break L1
}





	return int32(sum >> 32)
}
func BigInteger_MulAdd_I1_I1_I_I_I__I(out, in *IntArray, offset, len_, k int32) int32 { BigInteger_Init()
	BigInteger_ImplMulAddCheck_I1_I1_I_I_I__V(out, in, offset, len_, k)
	return BigInteger_ImplMulAdd_I1_I1_I_I_I__I(out, in, offset, len_, k)
}
func BigInteger_ImplMulAddCheck_I1_I1_I_I_I__V(out, in *IntArray, offset, len_, k int32) { BigInteger_Init()
	if len_ > int32(len(in.A)) {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1268, StrOfInt(len_), Lit_1260, StrOfInt(int32(len(in.A)))))))
	}
	if offset < 0 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1269, StrOfInt(offset))))) }
	if offset > int32(len(out.A))-1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1270, StrOfInt(offset), Lit_1260, StrOfInt(int32(len(out.A))-1)))))
	}



	if len_ > int32(len(out.A))-offset {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1271, StrOfInt(len_), Lit_1260, StrOfInt(int32(len(out.A))-offset)))))
	}
}



func BigInteger_ImplMulAdd_I1_I1_I_I_I__I(out, in *IntArray, offset, len_, k int32) int32 { BigInteger_Init()


	var kLong int64 = int64(k) & 4294967295
	var carry int64 = 0
	offset = int32(len(out.A)) - offset - 1
	var j int32 = len_ - 1; L1: for {
		if j >= 0 {
			var tmp1 int64 = int64(in.A[j]) & 4294967295 * kLong; var product int64 = tmp1 + int64(out.A[offset])&4294967295 + carry



			out.A[offset] = int32(product)
			offset = offset - 1
			carry = int64(uint64(product) >> 32)
			j = j - 1; continue L1 }
//line :1904:1
		break L1
	}








	return int32(carry)
}
func BigInteger_AddOne_I1_I_I_I__I(a *IntArray, offset, mlen, carry int32) int32 { BigInteger_Init()
	offset = int32(len(a.A)) - 1 - mlen - offset



	var t_ int64 = int64(a.A[offset])&4294967295 + int64(carry)&4294967295
	a.A[offset] = int32(t_)
	if int64(uint64(t_)>>32) == 0 { return 0 } else {


	L1: for { var tmp1 int32; mlen = mlen - 1; tmp1 = mlen; if tmp1 >= 0 {
		var tmp2 int32; offset = offset - 1; tmp2 = offset; if tmp2 < 0 {
			return 1 } else {

				a.A[offset] = a.A[offset] + 1
				if a.A[offset] == 0 { } else { return 0 } }
//line :1926:1
		continue L1 }; break L1 }
//line :1925:1
		return 1
	}
}






func (t *BigInteger) ModPow2_BigInteger_I__BigInteger(exponent *BigInteger, p int32) *BigInteger {
	var result *BigInteger = BigInteger_ONE; var baseToPow2 *BigInteger = t.Mod2_I__BigInteger(p); var expOffset int32 = 0; var limit int32 = NN(exponent).BitLength__I()



	if t.TestBit_I__Z(0) {
		var tmp1 int32; if p-1 < limit { tmp1 = p - 1 } else { tmp1 = limit }; limit = tmp1 }
L1: for { if expOffset < limit {
	if NN(exponent).TestBit_I__Z(expOffset) { result = NN(NN(result).Multiply_BigInteger__BigInteger(baseToPow2)).Mod2_I__BigInteger(p) }
	expOffset = expOffset + 1
	if expOffset < limit { baseToPow2 = NN(NN(baseToPow2).Square__BigInteger()).Mod2_I__BigInteger(p) }
//line :1941:1
	continue L1 }; break L1 }
//line :1935:1
	return result
}










func (t *BigInteger) Mod2_I__BigInteger(p int32) *BigInteger {
	if t.BitLength__I() <= p { return t } else {

		var numInts int32 = int32(uint32(p+31) >> 5); var mag *IntArray = NewIntArray(numInts); var tmp1 any = t.F_mag.Ref()

		System_Arraycopy_O_I_O_I_I__V(tmp1, int32(len(t.F_mag.A))-numInts, mag.Ref(), 0, numInts)




		var excessBits int32 = numInts<<5 - p
		mag.A[0] = mag.A[0] & int32(1<<((32-excessBits)&63)-1)






		if mag.A[0] == 0 { return BigInteger_New_I_I1(1, mag) } else { return BigInteger_New_I1_I(mag, 1)
		} } }
func (t *BigInteger) ModInverse_BigInteger__BigInteger(m *BigInteger) *BigInteger {
	if m.F_signum == 1 { } else { panic(Thrown(ArithmeticException_New_String(Lit_1265))) }
	if NN(m).Equals_O__Z(BigInteger_ONE.Ref()) { return BigInteger_ZERO } else {

		var modVal *BigInteger = t; var tmp1 bool; var tmp2 bool
		tmp2 = t.F_signum < 0; if !tmp2 { tmp2 = t.CompareMagnitude_BigInteger__I(m) >= 0 }; tmp1 = tmp2; if tmp1 { modVal = t.Mod_BigInteger__BigInteger(m) }
		if NN(modVal).Equals_O__Z(BigInteger_ONE.Ref()) { return BigInteger_ONE } else {

			var a MutableBigInteger_I = MutableBigInteger_New_BigInteger(modVal); var b MutableBigInteger_I = MutableBigInteger_New_BigInteger(m); var result MutableBigInteger_I = a.MutableModInverse_MutableBigInteger__MutableBigInteger(b)


			return result.ToBigInteger_I__BigInteger(1)
		} } }
func (t *BigInteger) ShiftLeft_I__BigInteger(n int32) *BigInteger {
	if t.F_signum == 0 { return BigInteger_ZERO } else { if n > 0 {

		return BigInteger_New_I1_I(BigInteger_ShiftLeft_I1_I__I1(t.F_mag, n), t.F_signum) } else {
//line :1981:1
			if n == 0 { return t } else {



				return t.ShiftRightImpl_I__BigInteger(-n)
			} } } }
func BigInteger_ShiftLeft_I1_I__I1(mag *IntArray, n int32) *IntArray { BigInteger_Init()
	var nInts int32 = int32(uint32(n) >> 5); var nBits int32 = n & 31; var magLen int32 = int32(len(mag.A)); var newMag *IntArray



	if nBits == 0 {

		newMag = NewIntArray(magLen + nInts)
		System_Arraycopy_O_I_O_I_I__V(mag.Ref(), 0, newMag.Ref(), 0, magLen) } else {
			var i int32 = 0; var nBits2 int32 = 32 - nBits; var highBits int32 = int32(uint32(mag.A[0]) >> (nBits2 & 31))


			if !(highBits == 0) {

				newMag = NewIntArray(magLen + nInts + 1)
				newMag.A[i] = highBits
				i = i + 1 } else {
					newMag = NewIntArray(magLen + nInts) }
			var numIter int32 = magLen - 1
			Objects_CheckFromToIndex_I_I_I__I(0, numIter+1, int32(len(mag.A)))



			Objects_CheckFromToIndex_I_I_I__I(i, numIter+i+1, int32(len(newMag.A)))


			BigInteger_ShiftLeftImplWorker_I1_I1_I_I_I__V(newMag, mag, i, nBits, numIter)
			newMag.A[numIter+i] = mag.A[numIter] << (nBits & 31) }
//line :1988:1
	return newMag
}





























func BigInteger_ShiftLeftImplWorker_I1_I1_I_I_I__V(newArr, oldArr *IntArray, newIdx, shiftCount, numIter int32) { BigInteger_Init()




	var shiftCountRight int32 = 32 - shiftCount
	var oldIdx int32 = 0
L1: for { if oldIdx < numIter {
	var tmp1 int32 = newIdx; var tmp2 int32
	var old_9 int32 = oldIdx



	oldIdx = oldIdx + 1
//line :2031:1
	tmp2 = old_9
//line :2027:1
	var tmp3 int32 = oldArr.A[tmp2] << (shiftCount & 31); newArr.A[tmp1] = tmp3 | int32(uint32(oldArr.A[oldIdx])>>(shiftCountRight&31))








	newIdx = newIdx + 1
//line :2026:1
	continue L1 }; break L1
}
}









func (t *BigInteger) ShiftRight_I__BigInteger(n int32) *BigInteger {
	if t.F_signum == 0 { return BigInteger_ZERO } else { if n > 0 {

		return t.ShiftRightImpl_I__BigInteger(n) } else {
//line :2039:1
			if n == 0 { return t } else {



				return BigInteger_New_I1_I(BigInteger_ShiftLeft_I1_I__I1(t.F_mag, -n), t.F_signum)
			} } } }
func (t *BigInteger) ShiftRightImpl_I__BigInteger(n int32) *BigInteger {
	var nInts int32 = int32(uint32(n) >> 5); var nBits int32 = n & 31; var magLen int32 = int32(len(t.F_mag.A)); var newMag *IntArray



	if nInts >= magLen {
		if t.F_signum >= 0 { return BigInteger_ZERO } else { return As[*BigInteger](BigInteger_negConst.A[1]) } } else {

			if nBits == 0 {
				var newMagLen int32 = magLen - nInts
				newMag = Arrays_CopyOf_I1_I__I1(t.F_mag, newMagLen) } else {
					var i int32 = 0; var highBits int32 = int32(uint32(t.F_mag.A[0]) >> (nBits & 31))

					if !(highBits == 0) {

						newMag = NewIntArray(magLen - nInts)
						newMag.A[i] = highBits
						i = i + 1 } else {
							newMag = NewIntArray(magLen - nInts - 1)
						}

					var numIter int32 = magLen - nInts - 1
					Objects_CheckFromToIndex_I_I_I__I(0, numIter+1, int32(len(t.F_mag.A)))



					Objects_CheckFromToIndex_I_I_I__I(i, numIter+i, int32(len(newMag.A)))
					BigInteger_ShiftRightImplWorker_I1_I1_I_I_I__V(newMag, t.F_mag, i, nBits, numIter) }
			if t.F_signum < 0 {
				var nzInts int32 = t.NumberOfTrailingZeroInts__I(); var tmp1 bool; var tmp2 bool
				tmp2 = nInts > nzInts; if !tmp2 {
					var tmp3 bool; tmp3 = nInts == nzInts; if tmp3 {
						tmp3 = !(t.F_mag.A[magLen-nzInts-1]&(1<<(nBits&31)-1) == 0) }
//line :2076:1
					tmp2 = tmp3 }
//line :2075:1
				tmp1 = tmp2; if tmp1 {








					newMag = BigInteger_JavaIncrement_I1__I1(newMag) } }
			return BigInteger_New_I1_I(newMag, t.F_signum)
		} }
func BigInteger_ShiftRightImplWorker_I1_I1_I_I_I__V(newArr, oldArr *IntArray, newIdx, shiftCount, numIter int32) { BigInteger_Init()




	var shiftCountLeft int32 = 32 - shiftCount; var idx int32 = numIter; var nidx int32

	if newIdx == 0 { nidx = numIter - 1 } else { nidx = numIter }
L1: for { if nidx >= newIdx {
	var tmp1 int32 = nidx; var tmp2 int32
	var old_10 int32 = idx


	idx = idx - 1; tmp2 = old_10
//line :2096:1
	var tmp3 int32 = int32(uint32(oldArr.A[tmp2]) >> (shiftCount & 31)); newArr.A[tmp1] = tmp3 | oldArr.A[idx]<<(shiftCountLeft&31)






	nidx = nidx - 1
//line :2095:1
	continue L1 }; break L1
}
}







func BigInteger_JavaIncrement_I1__I1(val *IntArray) *IntArray { BigInteger_Init()
	var lastSum int32 = 0; var i int32 = int32(len(val.A)) - 1
L1: for {
	var tmp1 bool; var tmp2 bool; tmp2 = i >= 0; if tmp2 { tmp2 = lastSum == 0 }; tmp1 = tmp2; if tmp1 {
		var tmp3 int32; var tmp4 int32 = val.A[i] + 1; val.A[i] = tmp4; tmp3 = tmp4; lastSum = tmp3
		i = i - 1; continue L1 }
//line :2107:1
	break L1
}


	if lastSum == 0 {
		val = NewIntArray(int32(len(val.A)) + 1)
		val.A[0] = 1 }
//line :2106:1
	return val
}








func (t *BigInteger) And_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var result *IntArray = NewIntArray(Math_Max_I_I__I(t.IntLength__I(), NN(val).IntLength__I())); var i int32 = 0
L1: for {
	if i < int32(len(result.A)) {
		result.A[i] = t.GetInt_I__I(int32(len(result.A))-i-1) & NN(val).GetInt_I__I(int32(len(result.A))-i-1)









		i = i + 1; continue L1 }
//line :2118:1
	break L1
}











	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) Or_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var result *IntArray = NewIntArray(Math_Max_I_I__I(t.IntLength__I(), NN(val).IntLength__I())); var i int32 = 0
L1: for {
	if i < int32(len(result.A)) {
		result.A[i] = t.GetInt_I__I(int32(len(result.A))-i-1) | NN(val).GetInt_I__I(int32(len(result.A))-i-1)









		i = i + 1; continue L1 }
//line :2135:1
	break L1
}











	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) Xor_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var result *IntArray = NewIntArray(Math_Max_I_I__I(t.IntLength__I(), NN(val).IntLength__I())); var i int32 = 0
L1: for {
	if i < int32(len(result.A)) {
		result.A[i] = t.GetInt_I__I(int32(len(result.A))-i-1) ^ NN(val).GetInt_I__I(int32(len(result.A))-i-1)









		i = i + 1; continue L1 }
//line :2152:1
	break L1
}











	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) Not__BigInteger() *BigInteger {
	var result *IntArray = NewIntArray(t.IntLength__I()); var i int32 = 0
L1: for {
	if i < int32(len(result.A)) {
		result.A[i] = ^t.GetInt_I__I(int32(len(result.A)) - i - 1)





		i = i + 1; continue L1 }
//line :2169:1
	break L1
}







	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) AndNot_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	var result *IntArray = NewIntArray(Math_Max_I_I__I(t.IntLength__I(), NN(val).IntLength__I())); var i int32 = 0
L1: for {
	if i < int32(len(result.A)) {
		result.A[i] = t.GetInt_I__I(int32(len(result.A))-i-1) & ^NN(val).GetInt_I__I(int32(len(result.A))-i-1)










		i = i + 1; continue L1 }
//line :2182:1
	break L1
}












	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) TestBit_I__Z(n int32) bool {
	if n < 0 { panic(Thrown(ArithmeticException_New_String(Lit_1272))) }
	return !(t.GetInt_I__I(int32(uint32(n)>>5))&(1<<(n&31&31)) == 0)
}


func (t *BigInteger) SetBit_I__BigInteger(n int32) *BigInteger {
	if n < 0 { panic(Thrown(ArithmeticException_New_String(Lit_1272))) }
	var intNum int32 = int32(uint32(n) >> 5); var result *IntArray = NewIntArray(Math_Max_I_I__I(t.IntLength__I(), intNum+2))
	var i int32 = 0
L1: for {
	if i < int32(len(result.A)) {
		var tmp1 int32 = int32(len(result.A)) - i - 1; result.A[tmp1] = t.GetInt_I__I(i)


		i = i + 1; continue L1 }
//line :2208:1
	break L1
}




	var i_11 int32 = int32(len(result.A)) - intNum - 1
	result.A[i_11] = result.A[i_11] | 1<<(n&31&31)


	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) ClearBit_I__BigInteger(n int32) *BigInteger {
	if n < 0 { panic(Thrown(ArithmeticException_New_String(Lit_1272))) }
	var intNum int32 = int32(uint32(n) >> 5); var result *IntArray = NewIntArray(Math_Max_I_I__I(t.IntLength__I(), int32(uint32(n+1)>>5)+1))
	var i int32 = 0




L1: for {
	if i < int32(len(result.A)) {
		var tmp1 int32 = int32(len(result.A)) - i - 1; result.A[tmp1] = t.GetInt_I__I(i)


		i = i + 1; continue L1 }
//line :2228:1
	break L1
}




	var i_12 int32 = int32(len(result.A)) - intNum - 1
	result.A[i_12] = result.A[i_12] & ^(1 << (n & 31 & 31))



	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) FlipBit_I__BigInteger(n int32) *BigInteger {
	if n < 0 { panic(Thrown(ArithmeticException_New_String(Lit_1272))) }
	var intNum int32 = int32(uint32(n) >> 5); var result *IntArray = NewIntArray(Math_Max_I_I__I(t.IntLength__I(), intNum+2))
	var i int32 = 0
L1: for {
	if i < int32(len(result.A)) {
		var tmp1 int32 = int32(len(result.A)) - i - 1; result.A[tmp1] = t.GetInt_I__I(i)


		i = i + 1; continue L1 }
//line :2245:1
	break L1
}




	var i_13 int32 = int32(len(result.A)) - intNum - 1
	result.A[i_13] = result.A[i_13] ^ 1<<(n&31&31)


	return BigInteger_ValueOf_I1__BigInteger(result)
}
func (t *BigInteger) GetLowestSetBit__I() int32 {
	var lsb int32 = t.F_lowestSetBitPlusTwo - 2
	if lsb == -2 {
		if t.F_signum == 0 {
			lsb = -1 } else {
				var tz int32 = t.NumberOfTrailingZeroInts__I(); var tmp1 *IntArray = t.F_mag
				lsb = tz*32 + Integer_NumberOfTrailingZeros_I__I(tmp1.A[int32(len(t.F_mag.A))-1-tz])
			}





		t.F_lowestSetBitPlusTwo = lsb + 2 }
//line :2258:1
	return lsb
}













func (t *BigInteger) BitLength__I() int32 {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = t.F_signum < 0; if tmp3 { tmp3 = Integer_LowestOneBit_I__I(t.F_mag.A[0]) == t.F_mag.A[0] }; tmp2 = tmp3; if tmp2 {
		tmp2 = t.NumberOfTrailingZeroInts__I() == int32(len(t.F_mag.A))-1 }
//line :2274:1
	tmp1 = tmp2; if tmp1 {

		return t.MagBitLength__I() - 1 } else {
			return t.MagBitLength__I()
		} }
func (t *BigInteger) BitCount__I() int32 {
	var bc int32 = t.F_bitCountPlusOne - 1
	if bc == -1 {
		bc = 0
		var tmp1 int32 = int32(len(t.F_mag.A)); var firstZeroInt int32 = tmp1 - t.NumberOfTrailingZeroInts__I(); var i int32 = 0
	L1: for {
		if i < firstZeroInt {
			bc = bc + Integer_BitCount_I__I(t.F_mag.A[i])
			i = i + 1; continue L1 }
//line :2284:1
		break L1
	}


		if t.F_signum < 0 {
			bc = bc + (t.GetLowestSetBit__I() - 1) }
		t.F_bitCountPlusOne = bc + 1 }
//line :2280:1
	return bc
}











func (t *BigInteger) IsProbablePrime_I__Z(certainty int32) bool {
	if certainty <= 0 { return true } else {

		var w *BigInteger = t.Abs__BigInteger()
		if NN(w).Equals_O__Z(BigInteger_TWO.Ref()) { return true } else { var tmp1 bool; var tmp2 bool

			tmp2 = !NN(w).TestBit_I__Z(0); if !tmp2 { tmp2 = NN(w).Equals_O__Z(BigInteger_ONE.Ref()) }; tmp1 = tmp2
//line :2297:1
			if tmp1 { return false } else {




				if NN(w).BitLength__I() > 500000001 {
					panic(Thrown(ArithmeticException_New_String(Lit_1273)))
				}
				return NN(w).PrimeToCertainty_I_Random__Z(certainty, nil)
			} } } }
func (t *BigInteger) CompareTo_BigInteger__I(val *BigInteger) int32 {
	{ var tmp1 int32 = t.F_signum; if tmp1 == val.F_signum {

		switch t.F_signum { case 1: return t.CompareMagnitude_BigInteger__I(val); case -1: return NN(val).CompareMagnitude_BigInteger__I(t); default: return 0} } else {
//line :2308:1
			var tmp2 int32 = t.F_signum; if tmp2 > val.F_signum { return 1 } else { return -1
			} } }
	panic("a2g: unreachable")
}


func (t *BigInteger) CompareMagnitude_BigInteger__I(val *BigInteger) int32 {
	var m1 *IntArray = t.F_mag; var len1 int32 = int32(len(m1.A)); var m2 *IntArray = val.F_mag; var len2 int32 = int32(len(m2.A))



	if len1 < len2 { return -1 } else { if len1 > len2 { return 1 } else {



		var i int32 = ArraysSupport_Mismatch_I1_I1_I__I(m1, m2, len1)
		if !(i == -1) { var tmp1 int32 = m1.A[i]; if Integer_CompareUnsigned_I_I__I(tmp1, m2.A[i]) < 0 { return -1 } else { return 1 } } else { return 0
		} } } }
func (t *BigInteger) CompareMagnitude_J__I(val int64) int32 {
	if !A2g_AssertionsDisabled && !!(val == -9223372036854775808) { panic(Thrown(AssertionError_New())) }
	var m1 *IntArray = t.F_mag; var len_ int32 = int32(len(m1.A))

	if len_ > 2 { return 1 } else {


		if val < 0 { val = -val }
		var highWord int32 = int32(int64(uint64(val) >> 32))
		if highWord == 0 {

			if len_ < 1 { return -1 } else { if len_ > 1 { return 1 } else {



				var a int32 = m1.A[0]; var b int32 = int32(val)

				if !(a == b) { if Integer_CompareUnsigned_I_I__I(a, b) < 0 { return -1 } else { return 1 } } else { return 0 } } } } else {
//line :2335:1
					if len_ < 2 { return -1 } else {










						var a_2 int32 = m1.A[0]
						var b_2 int32 = highWord
						if !(a_2 == b_2) {
							if Integer_CompareUnsigned_I_I__I(a_2, b_2) < 0 { return -1 } else { return 1 } } else {

								a_2 = m1.A[1]
								b_2 = int32(val)
								if !(a_2 == b_2) { if Integer_CompareUnsigned_I_I__I(a_2, b_2) < 0 { return -1 } else { return 1 } } else { return 0
								} } } } } }
func (t *BigInteger) Equals_O__Z(x any) bool {
	if any(x) == any(t) { return true } else {

		var tmp1 any = x; if BigInteger_InstanceOf(tmp1) { var xInt *BigInteger = BigInteger_Cast(tmp1)
			if !(xInt.F_signum == t.F_signum) { return false } else { var tmp2 int32 = int32(len(t.F_mag.A)); if !(tmp2 == int32(len(xInt.F_mag.A))) { return false } else {


				var tmp3 *IntArray = t.F_mag; var tmp4 *IntArray = xInt.F_mag; return ArraysSupport_Mismatch_I1_I1_I__I(tmp3, tmp4, int32(len(t.F_mag.A))) == -1 } } } else {
//line :2358:1
					return false
				}
	}
}



func (t *BigInteger) Min_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	if t.CompareTo_BigInteger__I(val) < 0 { return t } else { return val
	} }
func (t *BigInteger) Max_BigInteger__BigInteger(val *BigInteger) *BigInteger {
	if t.CompareTo_BigInteger__I(val) > 0 { return t } else { return val
	} }
func (t *BigInteger) HashCode__I() int32 {
	var tmp1 *IntArray = t.F_mag; return ArraysSupport_HashCode_I1_I_I_I__I(tmp1, 0, int32(len(t.F_mag.A)), 0) * t.F_signum
}
func (t *BigInteger) ToString_I__String(radix int32) *String {
	if t.F_signum == 0 { return Lit_1133 } else {


		var tmp1 bool; var tmp2 bool; tmp2 = radix < 2; if !tmp2 { tmp2 = radix > 36 }; tmp1 = tmp2; if tmp1 { radix = 10 }
		if t.FitsIntoLong__Z() {
			return Long_ToString_J_I__String(t.LongValue__J(), radix) } else {
				var abs *BigInteger = t.Abs__BigInteger(); var b int32 = NN(abs).BitLength__I(); var numChars int32; var tmp3 float64 = float64(float64(b) * BigInteger_LOG_TWO); var tmp4 int32 = D2I(Math_Floor_D__D(tmp3/BigInteger_logCache.A[radix]) + 1.0); var tmp5 int32








				if t.F_signum < 0 { tmp5 = 1 } else { tmp5 = 0 }
//line :2383:1
				numChars = tmp4 + tmp5
//line :2381:1
				var sb *StringBuilder = StringBuilder_New_I(numChars)










				if t.F_signum < 0 { NN(sb).Append_C__StringBuilder(45) }
				BigInteger_ToString_BigInteger_StringBuilder_I_I__V(abs, sb, radix, 0)
				return NN(sb).ToString__String()
			} } }
func BigInteger_PadWithZeros_StringBuilder_I__V(buf *StringBuilder, numZeros int32) { BigInteger_Init()
L1: for { if numZeros >= BigInteger_NUM_ZEROS {
	NN(buf).Append_String__StringBuilder(BigInteger_ZEROS)
	numZeros = numZeros - BigInteger_NUM_ZEROS
//line :2397:1
	continue L1 }; break L1
}

	if numZeros > 0 { NN(buf).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(BigInteger_ZEROS), 0, numZeros)
	} }
func (t *BigInteger) SmallToString_I_StringBuilder_I__V(radix int32, buf *StringBuilder, digits int32) {
	if !A2g_AssertionsDisabled && !(t.F_signum >= 0) { panic(Thrown(AssertionError_New())) }
	if t.F_signum == 0 {
		BigInteger_PadWithZeros_StringBuilder_I__V(buf, digits) } else {
			var maxNumDigitGroups int32 = (4*int32(len(t.F_mag.A)) + 6) / 7; var digitGroups *LongArray = NewLongArray(maxNumDigitGroups)
			var tmp /*line :2406:1*/*BigInteger = t
			var numGroups int32 = 0




		L1: for { if !(tmp.F_signum == 0) {
			var d *BigInteger = As[*BigInteger](BigInteger_longRadix.A[radix]); var q MutableBigInteger_I = MutableBigInteger_New(); var a MutableBigInteger_I = MutableBigInteger_New_I1(tmp.F_mag); var b MutableBigInteger_I = MutableBigInteger_New_I1(d.F_mag); var r MutableBigInteger_I = a.Divide_MutableBigInteger_MutableBigInteger__MutableBigInteger(b, q); var tmp1 int32 = tmp.F_signum; var q2 *BigInteger = q.ToBigInteger_I__BigInteger(tmp1 * d.F_signum); var tmp2 int32 = tmp.F_signum; var r2 *BigInteger = r.ToBigInteger_I__BigInteger(tmp2 * d.F_signum)






			digitGroups.A[numGroups] = NN(r2).LongValue__J()
			numGroups = numGroups + 1
			tmp = q2
//line :2412:1
			continue L1 }; break L1
		}









			var s *String = Long_ToString_J_I__String(digitGroups.A[numGroups-1], radix)

			BigInteger_PadWithZeros_StringBuilder_I__V(buf, digits-(NN(s).Length__I()+(numGroups-1)*BigInteger_digitsPerLong.A[radix]))







			NN(buf).Append_String__StringBuilder(s)
			var i int32 = numGroups - 2; L2: for {
				if i >= 0 {
					s = Long_ToString_J_I__String(digitGroups.A[i], radix)
					var tmp3 int32 = BigInteger_digitsPerLong.A[radix]; var numLeadingZeros int32 = tmp3 - NN(s).Length__I()


					if numLeadingZeros == 0 { } else { NN(buf).Append_CharSequence_I_I__StringBuilder(Up_String_CharSequence(BigInteger_ZEROS), 0, numLeadingZeros) }
					NN(buf).Append_String__StringBuilder(s)
					i = i - 1; continue L2 }
//line :2434:1
				break L2
			}
		}
}






func BigInteger_ToString_BigInteger_StringBuilder_I_I__V(u *BigInteger, sb *StringBuilder, radix, digits int32) { BigInteger_Init()
	if !A2g_AssertionsDisabled && !(NN(u).Signum__I() >= 0) { panic(Thrown(AssertionError_New())) }
	if int32(len(u.F_mag.A)) <= 20 {
		NN(u).SmallToString_I_StringBuilder_I__V(radix, sb, digits) } else {
			var b int32 = NN(u).BitLength__I(); var tmp1 float64 = float64(float64(b) * BigInteger_LOG_TWO); var n int32 = int32(Math_Round_D__J(Math_Log_D__D(tmp1/BigInteger_logCache.A[radix])/BigInteger_LOG_TWO - 1.0)); var v *BigInteger = BigInteger_GetRadixConversionCache_I_I__BigInteger(radix, n); var results *RefArray










			results = NN(u).DivideAndRemainder_BigInteger__BigInteger1(v)
			var expectedDigits int32 = 1 << (n & 31)
			BigInteger_ToString_BigInteger_StringBuilder_I_I__V(As[*BigInteger](results.A[0]), sb, radix, digits-expectedDigits)



			BigInteger_ToString_BigInteger_StringBuilder_I_I__V(As[*BigInteger](results.A[1]), sb, radix, expectedDigits)
		} }
func BigInteger_GetRadixConversionCache_I_I__BigInteger(radix, exponent int32) *BigInteger { BigInteger_Init()
	var cacheLine *RefArray = As[*RefArray](BigInteger_powerCache.Load().A[radix])
	if exponent < int32(len(cacheLine.A)) {
		return As[*BigInteger](cacheLine.A[exponent]) } else {
			var oldLength int32 = int32(len(cacheLine.A))
			cacheLine = A2g_CastArray[*RefArray](Arrays_CopyOf_O1_I__O1(cacheLine, exponent+1).Ref(), BigInteger_class.ArrayClass())

			var i int32 = oldLength; L1: for {
				if i <= exponent {
					cacheLine.Store(i, NN(As[*BigInteger](cacheLine.A[i-1])).Pow_I__BigInteger(2).Ref())
					i = i + 1; continue L1 }
//line :2474:1
				break L1
			}


			var pc *RefArray = BigInteger_powerCache.Load()
			if exponent >= int32(len(As[*RefArray](pc.A[radix]).A)) {
				pc = NN(pc).Copy()
				pc.Store(radix, cacheLine.Ref())
				BigInteger_powerCache.Store(pc) }
			return As[*BigInteger](cacheLine.A[exponent])
		}
}



func (t *BigInteger) ToString__String() *String { return t.ToString_I__String(10) }

func (t *BigInteger) ToByteArray__B1() *ByteArray {
	var byteArray *ByteArray = NewByteArray(int32(uint32(t.BitLength__I())>>3) + 1); var i int32 = int32(len(byteArray.A)) - 1
	var bytesCopied int32 = 4
	var nextInt int32 = 0
	var intIndex int32 = 0


L1: for { if i >= 0 {
	if bytesCopied == 4 {

		nextInt = t.GetInt_I__I(intIndex)
		intIndex = intIndex + 1
		bytesCopied = 1 } else {

			nextInt = int32(uint32(nextInt) >> 8)
			bytesCopied = bytesCopied + 1 }
	byteArray.A[i] = int8(nextInt)
	i = i - 1
//line :2498:1
	continue L1 }; break L1 }
//line :2492:1
	return byteArray
}

















func (t *BigInteger) IntValue__I() int32 { return t.GetInt_I__I(0) }

func (t *BigInteger) LongValue__J() int64 {
	return int64(t.GetInt_I__I(1))<<32 | int64(t.GetInt_I__I(0))&4294967295
}

func (t *BigInteger) FloatValue__F() float32 {
	if t.F_signum == 0 {
		return 0.0 } else {
			var exponent int32 = t.MagBitLength__I() - 1
			if exponent < 63 { return float32(t.LongValue__J()) } else { if exponent > 127 {


				if t.F_signum > 0 { return PosInf32 } else { return NegInf32 } } else {

					var shift int32 = exponent - 24; var twiceSignifFloor int32 = 0; var nBits int32 = shift & 31; var nBits2 int32 = 32 - nBits



					if nBits == 0 {
						twiceSignifFloor = t.F_mag.A[0] } else {

							twiceSignifFloor = int32(uint32(t.F_mag.A[0]) >> (nBits & 31))
							if twiceSignifFloor == 0 {
								var tmp1 int32 = t.F_mag.A[0] << (nBits2 & 31); twiceSignifFloor = tmp1 | int32(uint32(t.F_mag.A[1])>>(nBits&31))
							}
						}
					var signifFloor int32 = twiceSignifFloor >> 1
					signifFloor = signifFloor & 8388607
					var increment bool; var tmp2 bool; tmp2 = !(twiceSignifFloor&1 == 0); if tmp2 {
						var tmp3 bool; tmp3 = !(signifFloor&1 == 0); if !tmp3 {
							tmp3 = NN(t.Abs__BigInteger()).GetLowestSetBit__I() < shift }
//line :2541:1
						tmp2 = tmp3 }
//line :2540:1
					increment = tmp2; var signifRounded int32


					if increment {
						signifRounded = signifFloor + 1 } else {
//line :2543:1
							signifRounded = signifFloor }
//line :2540:1
					var bits int32 = (exponent + 127) << 23








					bits = bits + signifRounded
					bits = bits | t.F_signum&-2147483648
					return Float_IntBitsToFloat_I__F(bits)
				} } } }
func (t *BigInteger) DoubleValue__D() float64 {
	if t.F_signum == 0 { return 0.0 } else {

		var exponent int32 = t.MagBitLength__I() - 1
		if exponent < 63 { return float64(t.LongValue__J()) } else { if exponent > 1023 {


			if t.F_signum > 0 { return PosInf64 } else { return NegInf64 } } else {

				var shift int32 = exponent - 53; var twiceSignifFloor int64 = 0; var nBits int32 = shift & 31; var nBits2 int32 = 32 - nBits
				var highBits int32 = 0
				var lowBits int32 = 0



				if nBits == 0 {
					highBits = t.F_mag.A[0]; lowBits = t.F_mag.A[1] } else {

						highBits = int32(uint32(t.F_mag.A[0]) >> (nBits & 31))
						var tmp1 int32 = t.F_mag.A[0] << (nBits2 & 31); lowBits = tmp1 | int32(uint32(t.F_mag.A[1])>>(nBits&31))


						if highBits == 0 {
							highBits = lowBits
							var tmp2 int32 = t.F_mag.A[1] << (nBits2 & 31); lowBits = tmp2 | int32(uint32(t.F_mag.A[2])>>(nBits&31))
						}
					}
				twiceSignifFloor = int64(highBits)&4294967295<<32 | int64(lowBits)&4294967295


				var signifFloor int64 = twiceSignifFloor >> 1
				signifFloor = signifFloor & 4503599627370495
				var increment bool; var tmp3 bool; tmp3 = !(twiceSignifFloor&1 == 0); if tmp3 {
					var tmp4 bool; tmp4 = !(signifFloor&1 == 0); if !tmp4 {
						tmp4 = NN(t.Abs__BigInteger()).GetLowestSetBit__I() < shift }
//line :2586:1
					tmp3 = tmp4 }
//line :2585:1
				increment = tmp3; var signifRounded int64


				if increment { signifRounded = signifFloor + 1 } else { signifRounded = signifFloor }
//line :2585:1
				var bits int64 = int64(exponent+1023) << 52






				bits = bits + signifRounded
				bits = bits | int64(t.F_signum)&-9223372036854775808
				return Double_LongBitsToDouble_J__D(bits)
			} } } }
func BigInteger_StripLeadingZeroInts_I1_Z__I1(val *IntArray, trusted bool) *IntArray { BigInteger_Init()
	var keep int32 = 0
	keep = 0
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = keep < int32(len(val.A)); if tmp2 { tmp2 = val.A[keep] == 0 }; tmp1 = tmp2; if tmp1 {
	keep = keep + 1
//line :2599:1
	continue L1 }; break L1
}
	var tmp3 bool; var tmp4 bool; tmp4 = trusted; if tmp4 { tmp4 = keep == 0 }; tmp3 = tmp4; if tmp3 { return val } else { return Arrays_CopyOfRange_I1_I_I__I1(val, keep, int32(len(val.A)))
	} }
func BigInteger_TrustedStripLeadingZeroInts_I1__I1(val *IntArray) *IntArray { BigInteger_Init()
	return BigInteger_StripLeadingZeroInts_I1_Z__I1(val, true)
}
func BigInteger_StripLeadingZeroBytes_B1_I_I__I1(a *ByteArray, from, len_ int32) *IntArray { BigInteger_Init()
	return BigInteger_StripLeadingZeroBytes_I_B1_I_I__I1(-2147483648, a, from, len_)
}
func BigInteger_StripLeadingZeroBytes_I_B1_I_I__I1(b int32, a *ByteArray, from, len_ int32) *IntArray { BigInteger_Init()

	if len_ == 0 {
		return BigInteger_ZERO.F_mag } else {
			var to int32 = from + len_
			if b < -128 { b = int32(a.A[from]) }
			from = from + 1
		L1: for { var tmp1 bool; var tmp2 bool; tmp2 = b == 0; if tmp2 { tmp2 = from < to }; tmp1 = tmp2; if tmp1 {
			var tmp3 int32; var old_14 int32 = from; from = from + 1; tmp3 = old_14; b = int32(a.A[tmp3])
//line :2616:1
			continue L1 }; break L1
		}
			if b == 0 {
				return BigInteger_ZERO.F_mag } else {
					var res *IntArray = NewIntArray((to-from)>>2 + 1); var d0 int32 = b & 255




				L2: for { if !((to-from)&3 == 0) {
					d0 = d0<<8 | int32(a.A[from])&255
					from = from + 1
//line :2625:1
					continue L2 }; break L2
				}

					res.A[0] = d0
					var i int32 = 1
				L3: for { if from < to {
					var tmp4 int32 = i; var tmp5 int32
					var old_15 int32 = from






					from = from + 1
//line :2638:1
					tmp5 = old_15
//line :2631:1
					var tmp6 int32 = int32(a.A[tmp5]) << 24; var tmp7 int32
					var old_16 int32 = from














					from = from + 1
//line :2646:1
					tmp7 = old_16
//line :2631:1
					var tmp8 int32 = tmp6 | int32(a.A[tmp7])&255<<16; var tmp9 int32
					var old_17 int32 = from























					from = from + 1
//line :2655:1
					tmp9 = old_17
//line :2631:1
					var tmp10 int32 = tmp8 | int32(a.A[tmp9])&255<<8; var tmp11 int32
					var old_18 int32 = from






























					from = from + 1
//line :2662:1
					tmp11 = old_18
//line :2631:1
					res.A[tmp4] = tmp10 | int32(a.A[tmp11])&255


































					i = i + 1
//line :2630:1
					continue L3 }; break L3 }
//line :2629:1
					return res
				}
		}
}




































func BigInteger_MakePositive_I_B1_I_I__I1(b int32, a *ByteArray, from, len_ int32) *IntArray { BigInteger_Init()

	var to int32 = from + len_
	from = from + 1
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = b == -1; if tmp2 { tmp2 = from < to }; tmp1 = tmp2; if tmp1 {
	var tmp3 int32; var old_19 int32 = from; from = from + 1; tmp3 = old_19; b = int32(a.A[tmp3])
//line :2673:1
	continue L1 }; break L1
}
	var d0 int32 = -256 | b&255
L2: for { if !((to-from)&3 == 0) {
	var tmp4 int32 = d0 << 8; var tmp5 int32; b = int32(a.A[from]); tmp5 = b; d0 = tmp4 | tmp5&255
	from = from + 1
//line :2676:1
	continue L2 }; break L2
}

	var f int32 = from
L3: for { var tmp6 bool; var tmp7 bool; tmp7 = b == 0; if tmp7 { tmp7 = from < to }; tmp6 = tmp7; if tmp6 {
	var tmp8 int32; var old_20 int32 = from; from = from + 1; tmp8 = old_20; b = int32(a.A[tmp8])
//line :2680:1
	continue L3 }; break L3
}
	var d int32 = b & 255
L4: for { if !((to-from)&3 == 0) {
	d = d<<8 | int32(a.A[from])&255
	from = from + 1
//line :2683:1
	continue L4 }; break L4
}

	var c int32; if to-from|d0|d == 0 { c = 1 } else { c = 0 }; var res *IntArray = NewIntArray(c + 1 + (to-f)>>2); var tmp9 int32






	if c == 0 { tmp9 = d0 } else { tmp9 = -1 }; res.A[0] = tmp9
	var i int32 = int32(len(res.A)) - (to-from)>>2


	if i > 1 { res.A[i-1] = d }
L5: for { if from < to {
	var tmp10 int32 = i; var tmp11 int32
	var old_21 int32 = from





	from = from + 1
//line :2705:1
	tmp11 = old_21
//line :2699:1
	var tmp12 int32 = int32(a.A[tmp11]) << 24; var tmp13 int32
	var old_22 int32 = from













	from = from + 1
//line :2713:1
	tmp13 = old_22
//line :2699:1
	var tmp14 int32 = tmp12 | int32(a.A[tmp13])&255<<16; var tmp15 int32
	var old_23 int32 = from






















	from = from + 1
//line :2722:1
	tmp15 = old_23
//line :2699:1
	var tmp16 int32 = tmp14 | int32(a.A[tmp15])&255<<8; var tmp17 int32
	var old_24 int32 = from





























	from = from + 1
//line :2729:1
	tmp17 = old_24
//line :2699:1
	res.A[tmp10] = tmp16 | int32(a.A[tmp17])&255

































	i = i + 1
//line :2698:1
	continue L5 }; break L5
}


































L6: for { var tmp18 bool; var tmp19 bool; var tmp20 int32; i = i - 1; tmp20 = i; tmp19 = tmp20 >= 0; if tmp19 { tmp19 = res.A[i] == 0 }; tmp18 = tmp19; if tmp18 { continue L6 }; break L6 }
	res.A[i] = -res.A[i]
L7: for { var tmp21 int32; i = i - 1; tmp21 = i; if tmp21 >= 0 {
	res.A[i] = ^res.A[i]
//line :2736:1
	continue L7 }; break L7 }
//line :2694:1
	return res
}












































func BigInteger_MakePositive_I1__I1(a *IntArray) *IntArray { BigInteger_Init()
	var keep int32 = 0
	var i int32 = 0
	keep = 0
L1: for { var tmp1 bool; var tmp2 bool; tmp2 = keep < int32(len(a.A)); if tmp2 { tmp2 = a.A[keep] == -1 }; tmp1 = tmp2; if tmp1 { keep = keep + 1; continue L1 }; break L1 }
	i = int32(len(a.A)) - 1
L2: for { if a.A[i] == 0 { i = i - 1; continue L2 }; break L2 }
	var result *IntArray
	if i < keep {

		result = NewIntArray(int32(len(a.A)) - keep + 1)

		result.A[0] = 1 } else {

			result = NewIntArray(int32(len(a.A)) - keep)
			result.A[i-keep] = -a.A[i]
			i = i - 1
		L3: for { if i >= keep {
			result.A[i-keep] = ^a.A[i]
			i = i - 1
//line :2757:1
			continue L3 }; break L3 } }
//line :2747:1
	return result
}





































































































func (t *BigInteger) IntLength__I() int32 {
	return int32(uint32(t.BitLength__I())>>5) + 1
}
func (t *BigInteger) SignBit__I() int32 { panic(A2g_NotTranslated("java.math.BigInteger.signBit()I")) }

func (t *BigInteger) SignInt__I() int32 { if t.F_signum < 0 { return -1 } else { return 0 } }

func (t *BigInteger) GetInt_I__I(n int32) int32 {
	if n < 0 { return 0 } else { if n >= int32(len(t.F_mag.A)) {

		return t.SignInt__I() } else {

			var tmp1 *IntArray = t.F_mag; var magInt int32 = tmp1.A[int32(len(t.F_mag.A))-n-1]
			if t.F_signum >= 0 { return magInt } else { if n <= t.NumberOfTrailingZeroInts__I() {

				return -magInt } else {
					return ^magInt
				} } } } }
func (t *BigInteger) NumberOfTrailingZeroInts__I() int32 {
	var nz int32 = t.F_numberOfTrailingZeroIntsPlusTwo - 2
	if nz == -2 {
		var i int32 = 0; var lowest int32 = int32(len(t.F_mag.A)) - 1

		i = lowest
	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = i >= 0; if tmp2 { tmp2 = t.F_mag.A[i] == 0 }; tmp1 = tmp2; if tmp1 { i = i - 1; continue L1 }; break L1 }
		nz = lowest - i
		t.F_numberOfTrailingZeroIntsPlusTwo = nz + 2 }
//line :2869:1
	return nz
}









































func (t *BigInteger) ReadObjectNoData__V() { panic(A2g_NotTranslated("java.math.BigInteger.readObjectNoData()V")) }










func BigInteger_UnsafeHolder_PutSignAndMag_BigInteger_I_I1__V(p0 *BigInteger, p1 int32, p2 *IntArray) { BigInteger_UnsafeHolder_Init(); panic(A2g_NotTranslated("java.math.BigInteger$UnsafeHolder.putSignAndMag(Ljava/math/BigInteger;I[I)V")) }













func (t *BigInteger) MagSerializedForm__B1() *ByteArray { panic(A2g_NotTranslated("java.math.BigInteger.magSerializedForm()[B")) }



















func (t *BigInteger) LongValueExact__J() int64 {
	if t.FitsIntoLong__Z() {
		return t.LongValue__J() } else {
			panic(Thrown(ArithmeticException_New_String(Lit_1274)))
		} }
func (t *BigInteger) FitsIntoLong__Z() bool {
	var tmp1 bool; tmp1 = int32(len(t.F_mag.A)) <= 2; if tmp1 { tmp1 = t.BitLength__I() < 64 }; return tmp1
}
func (t *BigInteger) IntValueExact__I() int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = int32(len(t.F_mag.A)) <= 1; if tmp2 { tmp2 = t.BitLength__I() < 32 }; tmp1 = tmp2; if tmp1 {
		return t.IntValue__I() } else {
			panic(Thrown(ArithmeticException_New_String(Lit_1275)))
		} }
func (t *BigInteger) ShortValueExact__S() int16 {
	var tmp1 bool; var tmp2 bool; tmp2 = int32(len(t.F_mag.A)) <= 1; if tmp2 { tmp2 = t.BitLength__I() < 16 }; tmp1 = tmp2; if tmp1 {
		return t.ShortValue__S() } else {
			panic(Thrown(ArithmeticException_New_String(Lit_1276)))
		} }
func (t *BigInteger) ByteValueExact__B() int8 {
	var tmp1 bool; var tmp2 bool; tmp2 = int32(len(t.F_mag.A)) <= 1; if tmp2 { tmp2 = t.BitLength__I() < 8 }; tmp1 = tmp2; if tmp1 {
		return t.ByteValue__B() } else {
			panic(Thrown(ArithmeticException_New_String(Lit_1277)))
		}
}

type BigInteger struct{ Number; F_signum int32; F_mag *IntArray; F_bitCountPlusOne, F_magBitLengthPlusOne, F_lowestSetBitPlusTwo, F_numberOfTrailingZeroIntsPlusTwo int32 }

func (t *BigInteger) Is_Comparable() {}

const BigInteger_LONG_MASK int64 = 4294967295

const BigInteger_MAX_MAG_LENGTH int32 = 67108864

const BigInteger_PRIME_SEARCH_BIT_LENGTH_LIMIT int32 = 500000000

const BigInteger_KARATSUBA_THRESHOLD int32 = 80

const BigInteger_TOOM_COOK_THRESHOLD int32 = 240

const BigInteger_KARATSUBA_SQUARE_THRESHOLD int32 = 128

const BigInteger_TOOM_COOK_SQUARE_THRESHOLD int32 = 216

const BigInteger_BURNIKEL_ZIEGLER_THRESHOLD int32 = 80

const BigInteger_BURNIKEL_ZIEGLER_OFFSET int32 = 40

const BigInteger_SCHOENHAGE_BASE_CONVERSION_THRESHOLD int32 = 20

const BigInteger_MULTIPLY_SQUARE_THRESHOLD int32 = 20

const BigInteger_MONTGOMERY_INTRINSIC_THRESHOLD int32 = 512

var BigInteger_bitsPerDigit *LongArray

const BigInteger_SMALL_PRIME_THRESHOLD int32 = 95

const BigInteger_DEFAULT_PRIME_CERTAINTY int32 = 100

var BigInteger_SMALL_PRIME_PRODUCT *BigInteger

const BigInteger_MAX_CONSTANT int32 = 16

var BigInteger_posConst *RefArray

var BigInteger_negConst *RefArray

var BigInteger_powerCache atomic.Pointer[RefArray]

var BigInteger_logCache *DoubleArray

var BigInteger_LOG_TWO float64

var BigInteger_ZERO *BigInteger

var BigInteger_ONE *BigInteger

var BigInteger_TWO *BigInteger

var BigInteger_NEGATIVE_ONE *BigInteger

var BigInteger_TEN *BigInteger

var BigInteger_bnExpModThreshTable *IntArray

var BigInteger_NUM_ZEROS int32

var BigInteger_ZEROS *String

var BigInteger_digitsPerLong *IntArray

var BigInteger_longRadix *RefArray

var BigInteger_digitsPerInt *IntArray

var BigInteger_intRadix *IntArray

const BigInteger_serialVersionUID int64 = -8287574255936472291

var BigInteger_init ClassInit

func BigInteger_Init() { if !BigInteger_init.Done() { BigInteger_init.Run(BigInteger_clinit) } }

func BigInteger_clinit() { BigInteger_bitsPerDigit = LongArrayOf(0, 0, 1024, 1624, 2048, 2378, 2648, 2875, 3072, 3247, 3402, 3543, 3672, 3790, 3899, 4001, 4096, 4186, 4271, 4350, 4426, 4498, 4567, 4633, 4696, 4756, 4814, 4870, 4923, 4975, 5025, 5074, 5120, 5166, 5210, 5253, 5295); BigInteger_SMALL_PRIME_PRODUCT = BigInteger_ValueOf_J__BigInteger(152125131763605); BigInteger_posConst = NewRefArray(BigInteger_class, 17); BigInteger_negConst = NewRefArray(BigInteger_class, 17); BigInteger_LOG_TWO = Math_Log_D__D(2.0)
//line :618:1
	var i int32 = 1; L1: for {
		if i <= 16 {
			var magnitude *IntArray = NewIntArray(1)
			magnitude.A[0] = i
			var tmp1 *RefArray = BigInteger_posConst; tmp1.Store(i, BigInteger_New_I1_I(magnitude, 1))
			var tmp2 *RefArray = BigInteger_negConst; tmp2.Store(i, BigInteger_New_I1_I(magnitude, -1))
			i = i + 1; continue L1 }
//line :618:1
		break L1
	}





	var cache *RefArray = NewRefArray(BigInteger_class.ArrayClass(), 37)
	BigInteger_logCache = NewDoubleArray(37)
	var i_2 int32 = 2; L2: for {
		if i_2 <= 36 {
			cache.Store(i_2, RefArrayOf(BigInteger_class, BigInteger_ValueOf_J__BigInteger(int64(i_2)).Ref()))
			var tmp3 *DoubleArray = BigInteger_logCache; tmp3.A[i_2] = Math_Log_D__D(float64(i_2))
			i_2 = i_2 + 1; continue L2 }
//line :627:1
		break L2
	}



	BigInteger_powerCache.Store(cache)
//line :627:1
	BigInteger_ZERO = BigInteger_New_I1_I(NewIntArray(0), 0); BigInteger_ONE = BigInteger_ValueOf_J__BigInteger(1); BigInteger_TWO = BigInteger_ValueOf_J__BigInteger(2); BigInteger_NEGATIVE_ONE = BigInteger_ValueOf_J__BigInteger(-1); BigInteger_TEN = BigInteger_ValueOf_J__BigInteger(10); BigInteger_bnExpModThreshTable = IntArrayOf(7, 25, 81, 241, 673, 1793, 2147483647); BigInteger_NUM_ZEROS = 63; BigInteger_ZEROS = Lit_1133.Repeat_I__String(BigInteger_NUM_ZEROS); BigInteger_digitsPerLong = IntArrayOf(0, 0, 62, 39, 31, 27, 24, 22, 20, 19, 18, 18, 17, 17, 16, 16, 15, 15, 15, 14, 14, 14, 14, 13, 13, 13, 13, 13, 13, 12, 12, 12, 12, 12, 12, 12, 12); BigInteger_longRadix = RefArrayOf(BigInteger_class, nil, nil, BigInteger_ValueOf_J__BigInteger(4611686018427387904).Ref(), BigInteger_ValueOf_J__BigInteger(4052555153018976267).Ref(), BigInteger_ValueOf_J__BigInteger(4611686018427387904).Ref(), BigInteger_ValueOf_J__BigInteger(7450580596923828125).Ref(), BigInteger_ValueOf_J__BigInteger(4738381338321616896).Ref(), BigInteger_ValueOf_J__BigInteger(3909821048582988049).Ref(), BigInteger_ValueOf_J__BigInteger(1152921504606846976).Ref(), BigInteger_ValueOf_J__BigInteger(1350851717672992089).Ref(), BigInteger_ValueOf_J__BigInteger(1000000000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(5559917313492231481).Ref(), BigInteger_ValueOf_J__BigInteger(2218611106740436992).Ref(), BigInteger_ValueOf_J__BigInteger(8650415919381337933).Ref(), BigInteger_ValueOf_J__BigInteger(2177953337809371136).Ref(), BigInteger_ValueOf_J__BigInteger(6568408355712890625).Ref(), BigInteger_ValueOf_J__BigInteger(1152921504606846976).Ref(), BigInteger_ValueOf_J__BigInteger(2862423051509815793).Ref(), BigInteger_ValueOf_J__BigInteger(6746640616477458432).Ref(), BigInteger_ValueOf_J__BigInteger(799006685782884121).Ref(), BigInteger_ValueOf_J__BigInteger(1638400000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(3243919932521508681).Ref(), BigInteger_ValueOf_J__BigInteger(6221821273427820544).Ref(), BigInteger_ValueOf_J__BigInteger(504036361936467383).Ref(), BigInteger_ValueOf_J__BigInteger(876488338465357824).Ref(), BigInteger_ValueOf_J__BigInteger(1490116119384765625).Ref(), BigInteger_ValueOf_J__BigInteger(2481152873203736576).Ref(), BigInteger_ValueOf_J__BigInteger(4052555153018976267).Ref(), BigInteger_ValueOf_J__BigInteger(6502111422497947648).Ref(), BigInteger_ValueOf_J__BigInteger(353814783205469041).Ref(), BigInteger_ValueOf_J__BigInteger(531441000000000000).Ref(), BigInteger_ValueOf_J__BigInteger(787662783788549761).Ref(), BigInteger_ValueOf_J__BigInteger(1152921504606846976).Ref(), BigInteger_ValueOf_J__BigInteger(1667889514952984961).Ref(), BigInteger_ValueOf_J__BigInteger(2386420683693101056).Ref(), BigInteger_ValueOf_J__BigInteger(3379220508056640625).Ref(), BigInteger_ValueOf_J__BigInteger(4738381338321616896).Ref()); BigInteger_digitsPerInt = IntArrayOf(0, 0, 30, 19, 15, 13, 11, 11, 10, 9, 9, 8, 8, 8, 8, 7, 7, 7, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 5); BigInteger_intRadix = IntArrayOf(0, 0, 1073741824, 1162261467, 1073741824, 1220703125, 362797056, 1977326743, 1073741824, 387420489, 1000000000, 214358881, 429981696, 815730721, 1475789056, 170859375, 268435456, 410338673, 612220032, 893871739, 1280000000, 1801088541, 113379904, 148035889, 191102976, 244140625, 308915776, 387420489, 481890304, 594823321, 729000000, 887503681, 1073741824, 1291467969, 1544804416, 1838265625, 60466176)
}

































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func (t *BigInteger) CompareTo_O__I(p0 any) int32 { return t.CompareTo_BigInteger__I(BigInteger_Cast(p0)) }

func (t *BigInteger) ByteValue__B() int8 { return t.Impl_ByteValue__B(t) }

func (t *BigInteger) ShortValue__S() int16 { return t.Impl_ShortValue__S(t) }

func (t *BigInteger) Ref() any { if t == nil { return nil }; return t }

func (t *BigInteger) GetClass__Class() *Class { return BigInteger_class }

func (t *BigInteger) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BigInteger) CloneShallow() any { panic(CloneNotSupported(t)) }

func BigInteger_InstanceOf(x any) bool { _, ok := x.(*BigInteger); return ok }

func BigInteger_Cast(x any) *BigInteger { if x == nil { return nil }; v, ok := x.(*BigInteger); if !ok { panic(ClassCast(x, BigInteger_class)) }; return v }



type BigInteger_RecursiveOp struct{ RecursiveTask; F_parallel bool; F_depth int8 }

type BigInteger_RecursiveOp_I interface{ RecursiveTask_I; Future; Serializable; Self_BigInteger_RecursiveOp() *BigInteger_RecursiveOp; ForkOrInvoke__RecursiveTask() RecursiveTask_I }

func (t *BigInteger_RecursiveOp) Self_BigInteger_RecursiveOp() *BigInteger_RecursiveOp { return t }

var BigInteger_RecursiveOp_PARALLEL_FORK_DEPTH_THRESHOLD int32

var BigInteger_RecursiveOp_init ClassInit

func BigInteger_RecursiveOp_Init() { if !BigInteger_RecursiveOp_init.Done() { BigInteger_RecursiveOp_init.Run(BigInteger_RecursiveOp_clinit) } }

func BigInteger_RecursiveOp_clinit() { BigInteger_RecursiveOp_PARALLEL_FORK_DEPTH_THRESHOLD = BigInteger_RecursiveOp_CalculateMaximumDepth_I__I(ForkJoinPool_GetCommonPoolParallelism__I()) }

func BigInteger_RecursiveOp_InstanceOf(x any) bool { _, ok := x.(BigInteger_RecursiveOp_I); return ok }

func BigInteger_RecursiveOp_Cast(x any) BigInteger_RecursiveOp_I { if x == nil { return nil }; v, ok := x.(BigInteger_RecursiveOp_I); if !ok { panic(ClassCast(x, BigInteger_RecursiveOp_class)) }; return v }



type BigInteger_RecursiveOp_RecursiveMultiply struct{ BigInteger_RecursiveOp; F_a, F_b *BigInteger }

var BigInteger_RecursiveOp_RecursiveMultiply_init ClassInit

func BigInteger_RecursiveOp_RecursiveMultiply_Init() { if !BigInteger_RecursiveOp_RecursiveMultiply_init.Done() { BigInteger_RecursiveOp_RecursiveMultiply_init.Run(BigInteger_RecursiveOp_RecursiveMultiply_clinit) } }

func BigInteger_RecursiveOp_RecursiveMultiply_clinit() { BigInteger_RecursiveOp_Init() }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Compute__O() any { return t.Compute__BigInteger().Ref() }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Get__O() any { return t.Impl_Get__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Join__O() any { return t.Impl_Join__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) ForkOrInvoke__RecursiveTask() RecursiveTask_I { return t.Impl_ForkOrInvoke__RecursiveTask(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Ref() any { if t == nil { return nil }; return t }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) GetClass__Class() *Class { return BigInteger_RecursiveOp_RecursiveMultiply_class }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) ToString__String() *String { return Object_toString(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BigInteger_RecursiveOp_RecursiveMultiply) CloneShallow() any { panic(CloneNotSupported(t)) }

func BigInteger_RecursiveOp_RecursiveMultiply_InstanceOf(x any) bool { _, ok := x.(*BigInteger_RecursiveOp_RecursiveMultiply); return ok }

func BigInteger_RecursiveOp_RecursiveMultiply_Cast(x any) *BigInteger_RecursiveOp_RecursiveMultiply { if x == nil { return nil }; v, ok := x.(*BigInteger_RecursiveOp_RecursiveMultiply); if !ok { panic(ClassCast(x, BigInteger_RecursiveOp_RecursiveMultiply_class)) }; return v }



type BigInteger_RecursiveOp_RecursiveSquare struct{ BigInteger_RecursiveOp; F_a *BigInteger }

var BigInteger_RecursiveOp_RecursiveSquare_init ClassInit

func BigInteger_RecursiveOp_RecursiveSquare_Init() { if !BigInteger_RecursiveOp_RecursiveSquare_init.Done() { BigInteger_RecursiveOp_RecursiveSquare_init.Run(BigInteger_RecursiveOp_RecursiveSquare_clinit) } }

func BigInteger_RecursiveOp_RecursiveSquare_clinit() { BigInteger_RecursiveOp_Init() }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Compute__O() any { return t.Compute__BigInteger().Ref() }

func (t *BigInteger_RecursiveOp_RecursiveSquare) CompleteExceptionally_Throwable__V(p0 Throwable_I) { t.Impl_CompleteExceptionally_Throwable__V(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) QuietlyJoin__V() { t.Impl_QuietlyJoin__V(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) GetException__Throwable() Throwable_I { return t.Impl_GetException__Throwable(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) State__Future_State() *Future_State { return t.Impl_State__Future_State(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Get__O() any { return t.Impl_Get__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) IsCompletedNormally__Z() bool { return t.Impl_IsCompletedNormally__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Complete_O__V(p0 any) { t.Impl_Complete_O__V(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) IsDone__Z() bool { return t.Impl_IsDone__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) QuietlyInvoke__V() { t.Impl_QuietlyInvoke__V(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) ExceptionNow__Throwable() Throwable_I { return t.Impl_ExceptionNow__Throwable(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) IsCompletedAbnormally__Z() bool { return t.Impl_IsCompletedAbnormally__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Fork__ForkJoinTask() ForkJoinTask_I { return t.Impl_Fork__ForkJoinTask(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Invoke__O() any { return t.Impl_Invoke__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Exec__Z() bool { return t.Impl_Exec__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Join__O() any { return t.Impl_Join__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) SetRawResult_O__V(p0 any) { t.Impl_SetRawResult_O__V(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) GetRawResult__O() any { return t.Impl_GetRawResult__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) IsCancelled__Z() bool { return t.Impl_IsCancelled__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) TryUnfork__Z() bool { return t.Impl_TryUnfork__Z(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Cancel_Z__Z(p0 bool) bool { return t.Impl_Cancel_Z__Z(t, p0) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) ResultNow__O() any { return t.Impl_ResultNow__O(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) ForkOrInvoke__RecursiveTask() RecursiveTask_I { return t.Impl_ForkOrInvoke__RecursiveTask(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Get_J_TimeUnit__O(p0 int64, p1 *TimeUnit) any { return t.Impl_Get_J_TimeUnit__O(t, p0, p1) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Ref() any { if t == nil { return nil }; return t }

func (t *BigInteger_RecursiveOp_RecursiveSquare) GetClass__Class() *Class { return BigInteger_RecursiveOp_RecursiveSquare_class }

func (t *BigInteger_RecursiveOp_RecursiveSquare) ToString__String() *String { return Object_toString(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BigInteger_RecursiveOp_RecursiveSquare) CloneShallow() any { panic(CloneNotSupported(t)) }

func BigInteger_RecursiveOp_RecursiveSquare_InstanceOf(x any) bool { _, ok := x.(*BigInteger_RecursiveOp_RecursiveSquare); return ok }

func BigInteger_RecursiveOp_RecursiveSquare_Cast(x any) *BigInteger_RecursiveOp_RecursiveSquare { if x == nil { return nil }; v, ok := x.(*BigInteger_RecursiveOp_RecursiveSquare); if !ok { panic(ClassCast(x, BigInteger_RecursiveOp_RecursiveSquare_class)) }; return v }



type BigInteger_UnsafeHolder struct{ Object }

var BigInteger_UnsafeHolder_unsafe *Unsafe

var BigInteger_UnsafeHolder_signumOffset int64

var BigInteger_UnsafeHolder_magOffset int64

var BigInteger_UnsafeHolder_init ClassInit

func BigInteger_UnsafeHolder_Init() { if !BigInteger_UnsafeHolder_init.Done() { BigInteger_UnsafeHolder_init.Run(BigInteger_UnsafeHolder_clinit) } }

func BigInteger_UnsafeHolder_clinit() { BigInteger_UnsafeHolder_unsafe = Unsafe_GetUnsafe__Unsafe(); BigInteger_UnsafeHolder_signumOffset = NN(BigInteger_UnsafeHolder_unsafe).ObjectFieldOffset_Class_String__J(BigInteger_class, Lit_1278); BigInteger_UnsafeHolder_magOffset = NN(BigInteger_UnsafeHolder_unsafe).ObjectFieldOffset_Class_String__J(BigInteger_class, Lit_1279) }

func BigInteger_UnsafeHolder_New() *BigInteger_UnsafeHolder { BigInteger_UnsafeHolder_Init(); t := &BigInteger_UnsafeHolder{}; t.Ctor(); return t }

func (t *BigInteger_UnsafeHolder) Ctor() {}

func (t *BigInteger_UnsafeHolder) Ref() any { if t == nil { return nil }; return t }

func (t *BigInteger_UnsafeHolder) GetClass__Class() *Class { return BigInteger_UnsafeHolder_class }

func (t *BigInteger_UnsafeHolder) ToString__String() *String { return Object_toString(t) }

func (t *BigInteger_UnsafeHolder) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BigInteger_UnsafeHolder) CloneShallow() any { panic(CloneNotSupported(t)) }

func BigInteger_UnsafeHolder_InstanceOf(x any) bool { _, ok := x.(*BigInteger_UnsafeHolder); return ok }

func BigInteger_UnsafeHolder_Cast(x any) *BigInteger_UnsafeHolder { if x == nil { return nil }; v, ok := x.(*BigInteger_UnsafeHolder); if !ok { panic(ClassCast(x, BigInteger_UnsafeHolder_class)) }; return v }
