//line java_time_chrono_ChronoLocalDateTime.ae:1
package jrt






















func ChronoLocalDateTime_TimeLineOrder__Comparator() Comparator {
	return Comparator_Cast(Serializable_Cast(&Comparator_Fn_Serializable{Fn: func(p0, p1 any) int32 { var dateTime1 ChronoLocalDateTime = ChronoLocalDateTime_Cast(p0); var dateTime2 ChronoLocalDateTime = ChronoLocalDateTime_Cast(p1); var tmp1 int32; var cmp int32 = Long_Compare_J_J__I(dateTime1.ToLocalDate__ChronoLocalDate().ToEpochDay__J(), dateTime2.ToLocalDate__ChronoLocalDate().ToEpochDay__J()); if






		cmp == 0 {
			cmp = Long_Compare_J_J__I(NN(dateTime1.ToLocalTime__LocalTime()).ToNanoOfDay__J(), NN(dateTime2.ToLocalTime__LocalTime()).ToNanoOfDay__J()) }; tmp1 = cmp; return tmp1 },
	},
	),
	)
}
func ChronoLocalDateTime_From_TemporalAccessor__ChronoLocalDateTime(temporal TemporalAccessor) ChronoLocalDateTime {
	if ChronoLocalDateTime_InstanceOf(temporal) {
		return ChronoLocalDateTime_Cast(temporal) } else {

			Objects_RequireNonNull_O_String__O(temporal, Lit_2032)
			var chrono Chronology = Chronology_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery()))
			if chrono == nil {
				panic(Thrown(DateTimeException_New_String(Concat(Lit_2191, StrOfObj(temporal.GetClass__Class().Ref())))))
			}

			return chrono.LocalDateTime_TemporalAccessor__ChronoLocalDateTime(temporal)
		} }
func ChronoLocalDateTime_GetChronology__Chronology(this ChronoLocalDateTime) Chronology {
	return this.ToLocalDate__ChronoLocalDate().GetChronology__Chronology()
}






func ChronoLocalDateTime_IsSupported_TemporalUnit__Z(this ChronoLocalDateTime, unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		var tmp1 *ChronoUnit; ChronoUnit_Init(); tmp1 = ChronoUnit_FOREVER; return !(any(unit) == any(tmp1.Ref())) } else {
			var tmp2 bool; tmp2 = !(unit == nil); if tmp2 { tmp2 = unit.IsSupportedBy_Temporal__Z(this) }; return tmp2
		} }
func ChronoLocalDateTime_With_TemporalAdjuster__ChronoLocalDateTime(this ChronoLocalDateTime, adjuster TemporalAdjuster) ChronoLocalDateTime {
	return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(this.GetChronology__Chronology(), Temporal_With_TemporalAdjuster__Temporal(this, adjuster)))
}


func ChronoLocalDateTime_Plus_TemporalAmount__ChronoLocalDateTime(this ChronoLocalDateTime, amount TemporalAmount) ChronoLocalDateTime {
	return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(this.GetChronology__Chronology(), Temporal_Plus_TemporalAmount__Temporal(this, amount)))
}


func ChronoLocalDateTime_Minus_TemporalAmount__ChronoLocalDateTime(this ChronoLocalDateTime, amount TemporalAmount) ChronoLocalDateTime {
	return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(this.GetChronology__Chronology(), Temporal_Minus_TemporalAmount__Temporal(this, amount)))
}
func ChronoLocalDateTime_Minus_J_TemporalUnit__ChronoLocalDateTime(this ChronoLocalDateTime, amountToSubtract int64, unit TemporalUnit) ChronoLocalDateTime {

	return Up_ChronoLocalDateTimeImpl_ChronoLocalDateTime(ChronoLocalDateTimeImpl_EnsureValid_Chronology_Temporal__ChronoLocalDateTimeImpl(this.GetChronology__Chronology(), Temporal_Minus_J_TemporalUnit__Temporal(this, amountToSubtract, unit)))
}

func ChronoLocalDateTime_Query_TemporalQuery__O(this ChronoLocalDateTime, query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = query == TemporalQueries_ZoneId__TemporalQuery(); if !tmp3 {
		tmp3 = query == TemporalQueries_Zone__TemporalQuery() }
//line :83:1
	tmp2 = tmp3; if !tmp2 {

		tmp2 = query == TemporalQueries_Offset__TemporalQuery() }
//line :83:1
	tmp1 = tmp2; if tmp1 { return nil } else {


		if query == TemporalQueries_LocalTime__TemporalQuery() {
			return this.ToLocalTime__LocalTime().Ref() } else {
//line :86:1
				if query == TemporalQueries_Chronology__TemporalQuery() {

					return this.GetChronology__Chronology() } else {
//line :86:1
						if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_NANOS.Ref() } else {



							return query.QueryFrom_TemporalAccessor__O(this)
						} } } } }
func ChronoLocalDateTime_AdjustInto_Temporal__Temporal(this ChronoLocalDateTime, temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_EPOCH_DAY; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 Temporal = temporal.With_TemporalField_J__Temporal(tmp2, this.ToLocalDate__ChronoLocalDate().ToEpochDay__J()); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_NANO_OF_DAY; var tmp5 TemporalField = Up_ChronoField_TemporalField(tmp4); return tmp3.With_TemporalField_J__Temporal(tmp5, NN(this.ToLocalTime__LocalTime()).ToNanoOfDay__J())
}


func ChronoLocalDateTime_Format_DateTimeFormatter__String(this ChronoLocalDateTime, formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(this)
}


func ChronoLocalDateTime_ToInstant_ZoneOffset__Instant(this ChronoLocalDateTime, offset *ZoneOffset) *Instant {
	return Instant_OfEpochSecond_J_J__Instant(this.ToEpochSecond_ZoneOffset__J(offset), int64(NN(this.ToLocalTime__LocalTime()).GetNano__I()))
}
func ChronoLocalDateTime_ToEpochSecond_ZoneOffset__J(this ChronoLocalDateTime, offset *ZoneOffset) int64 {
	Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052)
	var epochDay int64 = this.ToLocalDate__ChronoLocalDate().ToEpochDay__J(); var secs int64 = epochDay*86400 + int64(NN(this.ToLocalTime__LocalTime()).ToSecondOfDay__I())


	secs = secs - int64(NN(offset).GetTotalSeconds__I())
//line :108:1
	return secs
}




func ChronoLocalDateTime_CompareTo_ChronoLocalDateTime__I(this, other ChronoLocalDateTime) int32 {
	var cmp int32 = this.ToLocalDate__ChronoLocalDate().CompareTo_ChronoLocalDate__I(other.ToLocalDate__ChronoLocalDate())
	if cmp == 0 {
		cmp = NN(this.ToLocalTime__LocalTime()).CompareTo_LocalTime__I(other.ToLocalTime__LocalTime())
		if cmp == 0 { cmp = this.GetChronology__Chronology().CompareTo_Chronology__I(other.GetChronology__Chronology()) } }
//line :115:1
	return cmp
}




func ChronoLocalDateTime_IsAfter_ChronoLocalDateTime__Z(this, other ChronoLocalDateTime) bool {
	var thisEpDay int64 = this.ToLocalDate__ChronoLocalDate().ToEpochDay__J(); var otherEpDay int64 = other.ToLocalDate__ChronoLocalDate().ToEpochDay__J(); var tmp1 bool

	tmp1 = thisEpDay > otherEpDay; if !tmp1 {
		var tmp2 bool; tmp2 = thisEpDay == otherEpDay; if tmp2 {
			tmp2 = NN(this.ToLocalTime__LocalTime()).ToNanoOfDay__J() > NN(other.ToLocalTime__LocalTime()).ToNanoOfDay__J() }
//line :125:1
		tmp1 = tmp2 }
//line :124:1
	return tmp1
}


func ChronoLocalDateTime_IsBefore_ChronoLocalDateTime__Z(this, other ChronoLocalDateTime) bool {
	var thisEpDay int64 = this.ToLocalDate__ChronoLocalDate().ToEpochDay__J(); var otherEpDay int64 = other.ToLocalDate__ChronoLocalDate().ToEpochDay__J(); var tmp1 bool

	tmp1 = thisEpDay < otherEpDay; if !tmp1 {
		var tmp2 bool; tmp2 = thisEpDay == otherEpDay; if tmp2 {
			tmp2 = NN(this.ToLocalTime__LocalTime()).ToNanoOfDay__J() < NN(other.ToLocalTime__LocalTime()).ToNanoOfDay__J() }
//line :132:1
		tmp1 = tmp2 }
//line :131:1
	return tmp1
}


func ChronoLocalDateTime_IsEqual_ChronoLocalDateTime__Z(this, other ChronoLocalDateTime) bool {
	var tmp1 bool; tmp1 = NN(this.ToLocalTime__LocalTime()).ToNanoOfDay__J() == NN(other.ToLocalTime__LocalTime()).ToNanoOfDay__J(); if tmp1 {
		tmp1 = this.ToLocalDate__ChronoLocalDate().ToEpochDay__J() == other.ToLocalDate__ChronoLocalDate().ToEpochDay__J() }
//line :136:1
	return tmp1
}



type ChronoLocalDateTime interface{ Object_I; Temporal; TemporalAdjuster; Comparable; TemporalAccessor; Is_ChronoLocalDateTime(); GetChronology__Chronology() Chronology; ToLocalDate__ChronoLocalDate() ChronoLocalDate; ToLocalTime__LocalTime() *LocalTime; IsSupported_TemporalField__Z(p0 TemporalField) bool; IsSupported_TemporalUnit__Z(p0 TemporalUnit) bool; With_TemporalAdjuster__ChronoLocalDateTime(p0 TemporalAdjuster) ChronoLocalDateTime; With_TemporalField_J__ChronoLocalDateTime(p0 TemporalField, p1 int64) ChronoLocalDateTime; Plus_TemporalAmount__ChronoLocalDateTime(p0 TemporalAmount) ChronoLocalDateTime; Plus_J_TemporalUnit__ChronoLocalDateTime(p0 int64, p1 TemporalUnit) ChronoLocalDateTime; Minus_TemporalAmount__ChronoLocalDateTime(p0 TemporalAmount) ChronoLocalDateTime; Minus_J_TemporalUnit__ChronoLocalDateTime(p0 int64, p1 TemporalUnit) ChronoLocalDateTime; Query_TemporalQuery__O(p0 TemporalQuery) any; AdjustInto_Temporal__Temporal(p0 Temporal) Temporal; Format_DateTimeFormatter__String(p0 *DateTimeFormatter) *String; AtZone_ZoneId__ChronoZonedDateTime(p0 ZoneId_I) ChronoZonedDateTime; ToInstant_ZoneOffset__Instant(p0 *ZoneOffset) *Instant; ToEpochSecond_ZoneOffset__J(p0 *ZoneOffset) int64; CompareTo_ChronoLocalDateTime__I(p0 ChronoLocalDateTime) int32; IsAfter_ChronoLocalDateTime__Z(p0 ChronoLocalDateTime) bool; IsBefore_ChronoLocalDateTime__Z(p0 ChronoLocalDateTime) bool; IsEqual_ChronoLocalDateTime__Z(p0 ChronoLocalDateTime) bool; With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal; With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal; Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; CompareTo_O__I(p0 any) int32 }

func ChronoLocalDateTime_With_TemporalAdjuster__Temporal(this ChronoLocalDateTime, p0 TemporalAdjuster) Temporal { return this.With_TemporalAdjuster__ChronoLocalDateTime(p0) }

func ChronoLocalDateTime_With_TemporalField_J__Temporal(this ChronoLocalDateTime, p0 TemporalField, p1 int64) Temporal { return this.With_TemporalField_J__ChronoLocalDateTime(p0, p1) }

func ChronoLocalDateTime_Plus_TemporalAmount__Temporal(this ChronoLocalDateTime, p0 TemporalAmount) Temporal { return this.Plus_TemporalAmount__ChronoLocalDateTime(p0) }

func ChronoLocalDateTime_Plus_J_TemporalUnit__Temporal(this ChronoLocalDateTime, p0 int64, p1 TemporalUnit) Temporal { return this.Plus_J_TemporalUnit__ChronoLocalDateTime(p0, p1) }

func ChronoLocalDateTime_Minus_TemporalAmount__Temporal(this ChronoLocalDateTime, p0 TemporalAmount) Temporal { return this.Minus_TemporalAmount__ChronoLocalDateTime(p0) }

func ChronoLocalDateTime_Minus_J_TemporalUnit__Temporal(this ChronoLocalDateTime, p0 int64, p1 TemporalUnit) Temporal { return this.Minus_J_TemporalUnit__ChronoLocalDateTime(p0, p1) }

func ChronoLocalDateTime_CompareTo_O__I(this ChronoLocalDateTime, p0 any) int32 { return this.CompareTo_ChronoLocalDateTime__I(ChronoLocalDateTime_Cast(p0)) }

func ChronoLocalDateTime_InstanceOf(x any) bool { _, ok := x.(ChronoLocalDateTime); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoLocalDateTime_class) } }; return ok }

func ChronoLocalDateTime_Cast(x any) ChronoLocalDateTime { if x == nil { return nil }; v, ok := x.(ChronoLocalDateTime); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(ChronoLocalDateTime_class) } }; if !ok { panic(ClassCast(x, ChronoLocalDateTime_class)) }; return v }
