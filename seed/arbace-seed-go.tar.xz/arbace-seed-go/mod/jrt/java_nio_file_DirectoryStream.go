//line java_nio_file_DirectoryStream.ae:1
package jrt






type DirectoryStream interface{ Object_I; Closeable; Iterable; AutoCloseable; Is_DirectoryStream(); Iterator__Iterator() Iterator }

func DirectoryStream_InstanceOf(x any) bool { _, ok := x.(DirectoryStream); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DirectoryStream_class) } }; return ok }

func DirectoryStream_Cast(x any) DirectoryStream { if x == nil { return nil }; v, ok := x.(DirectoryStream); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DirectoryStream_class) } }; if !ok { panic(ClassCast(x, DirectoryStream_class)) }; return v }



type DirectoryStream_Filter interface{ Object_I; Is_DirectoryStream_Filter(); Accept_O__Z(p0 any) bool }

func DirectoryStream_Filter_InstanceOf(x any) bool { _, ok := x.(DirectoryStream_Filter); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DirectoryStream_Filter_class) } }; return ok }

func DirectoryStream_Filter_Cast(x any) DirectoryStream_Filter { if x == nil { return nil }; v, ok := x.(DirectoryStream_Filter); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(DirectoryStream_Filter_class) } }; if !ok { panic(ClassCast(x, DirectoryStream_Filter_class)) }; return v }
