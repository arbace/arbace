//line java_util_RegularEnumSet.ae:1
package jrt











func RegularEnumSet_New_Class_Enum1(p0 *Class, p1 *RefArray) *RegularEnumSet { t := &RegularEnumSet{}; t.Ctor_Class_Enum1(p0, p1); return t }
//line :13:1
func (t *RegularEnumSet) Ctor_Class_Enum1(elementType *Class, universe *RefArray) { t.EnumSet.Ctor_Class_Enum1(t, elementType, universe); t.F_elements = 0 }


func (t *RegularEnumSet) AddRange_Enum_Enum__V(from, to Enum_I) {
	t.F_elements = int64(uint64(18446744073709551615)>>((from.Ordinal__I()-to.Ordinal__I()-1)&63)) << (from.Ordinal__I() & 63)
}






func (t *RegularEnumSet) AddAll__V() {
	if int32(len(t.F_universe.A)) == 0 { } else {
		t.F_elements = int64(uint64(18446744073709551615) >> (-int32(len(t.F_universe.A)) & 63))
	}
}
func (t *RegularEnumSet) Complement__V() {
	if int32(len(t.F_universe.A)) == 0 { } else {
		t.F_elements = ^t.F_elements
		var tmp1 int64 = t.F_elements; t.F_elements = tmp1 & int64(uint64(18446744073709551615)>>(-int32(len(t.F_universe.A))&63))
	}
}


func (t *RegularEnumSet) Iterator__Iterator() Iterator {
	return RegularEnumSet_EnumSetIterator_New_RegularEnumSet(t)
}








func RegularEnumSet_EnumSetIterator_New_RegularEnumSet(p0 *RegularEnumSet) *RegularEnumSet_EnumSetIterator { t := &RegularEnumSet_EnumSetIterator{}; t.Ctor_RegularEnumSet(p0); return t }
//line :49:1
func (t *RegularEnumSet_EnumSetIterator) Ctor_RegularEnumSet(this_0 *RegularEnumSet) { NN(this_0); t.F_this_0 = this_0; t.F_lastReturned = 0; t.F_unseen = this_0.F_elements }

func (t *RegularEnumSet_EnumSetIterator) HasNext__Z() bool { return !(t.F_unseen == 0) }

func (t *RegularEnumSet_EnumSetIterator) Next__Enum() Enum_I {
	if t.F_unseen == 0 { panic(Thrown(NoSuchElementException_New())) }
	t.F_lastReturned = t.F_unseen & -t.F_unseen
	t.F_unseen = t.F_unseen - t.F_lastReturned
	var tmp1 *RefArray = t.F_this_0.F_universe; return As[Enum_I](tmp1.A[Long_NumberOfTrailingZeros_J__I(t.F_lastReturned)])
}
func (t *RegularEnumSet_EnumSetIterator) Remove__V() {
	if t.F_lastReturned == 0 { panic(Thrown(IllegalStateException_New())) }
	t.F_this_0.F_elements = t.F_this_0.F_elements & ^t.F_lastReturned
	t.F_lastReturned = 0
}
func (t *RegularEnumSet) Size__I() int32 { return Long_BitCount_J__I(t.F_elements) }

func (t *RegularEnumSet) IsEmpty__Z() bool { return t.F_elements == 0 }

func (t *RegularEnumSet) Contains_O__Z(e any) bool {
	if e == nil { return false } else {

		var eClass *Class = GetClass(e); var tmp1 bool; var tmp2 bool
		tmp2 = !(eClass == t.F_elementType); if tmp2 {
			tmp2 = !(NN(eClass).GetSuperclass__Class() == t.F_elementType) }
//line :72:1
		tmp1 = tmp2; if tmp1 { return false } else {


			var tmp3 int64 = t.F_elements; return !(tmp3&(1<<(Enum_Cast(e).Ordinal__I()&63)) == 0)
		} } }
func (t *RegularEnumSet) Add_Enum__Z(e Enum_I) bool {
	t.TypeCheck_Enum__V(e)
	var oldElements int64 = t.F_elements; var tmp1 int64 = t.F_elements
	t.F_elements = tmp1 | 1<<(e.Ordinal__I()&63)
	return !(t.F_elements == oldElements)
}
func (t *RegularEnumSet) Remove_O__Z(e any) bool {
	if e == nil { return false } else {

		var eClass *Class = GetClass(e); var tmp1 bool; var tmp2 bool
		tmp2 = !(eClass == t.F_elementType); if tmp2 {
			tmp2 = !(NN(eClass).GetSuperclass__Class() == t.F_elementType) }
//line :87:1
		tmp1 = tmp2; if tmp1 { return false } else {


			var oldElements int64 = t.F_elements; var tmp3 int64 = t.F_elements
			t.F_elements = tmp3 & ^(1 << (Enum_Cast(e).Ordinal__I() & 63))

			return !(t.F_elements == oldElements)
		} } }
func (t *RegularEnumSet) ContainsAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if RegularEnumSet_InstanceOf(tmp1) { var es *RegularEnumSet = RegularEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			return NN(es).IsEmpty__Z() } else {
				return es.F_elements & ^t.F_elements == 0 } } else {
					return t.EnumSet.Impl_ContainsAll_Collection__Z(t, c)
				} }
func (t *RegularEnumSet) AddAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if RegularEnumSet_InstanceOf(tmp1) { var es *RegularEnumSet = RegularEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			if NN(es).IsEmpty__Z() { return false } else {

				panic(Thrown(ClassCastException_New_String(Concat(StrOfObj(es.F_elementType.Ref()), Lit_2668, StrOfObj(t.F_elementType.Ref()))))) } } else {

					var oldElements int64 = t.F_elements; var tmp2 int64 = t.F_elements
					t.F_elements = tmp2 | es.F_elements
					return !(t.F_elements == oldElements) } } else {
						return t.EnumSet.Impl_AddAll_Collection__Z(t, c)
					} }
func (t *RegularEnumSet) RemoveAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if RegularEnumSet_InstanceOf(tmp1) { var es *RegularEnumSet = RegularEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) { return false } else {

			var oldElements int64 = t.F_elements; var tmp2 int64 = t.F_elements
			t.F_elements = tmp2 & ^es.F_elements
			return !(t.F_elements == oldElements) } } else {
				return t.EnumSet.Impl_RemoveAll_Collection__Z(t, c)
			} }
func (t *RegularEnumSet) RetainAll_Collection__Z(c Collection) bool {
	var tmp1 Collection = c; if RegularEnumSet_InstanceOf(tmp1) { var es *RegularEnumSet = RegularEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			var changed bool = !(t.F_elements == 0); t.F_elements = 0; return changed } else {
				var oldElements int64 = t.F_elements; var tmp2 int64 = t.F_elements
				t.F_elements = tmp2 & es.F_elements
				return !(t.F_elements == oldElements) } } else {
					return t.EnumSet.Impl_RetainAll_Collection__Z(t, c)
				} }
func (t *RegularEnumSet) Clear__V() { t.F_elements = 0 }

func (t *RegularEnumSet) Equals_O__Z(o any) bool {
	var tmp1 any = o; if RegularEnumSet_InstanceOf(tmp1) { var es *RegularEnumSet = RegularEnumSet_Cast(tmp1)
		if !(es.F_elementType == t.F_elementType) {
			var tmp2 bool; tmp2 = t.F_elements == 0; if tmp2 { tmp2 = es.F_elements == 0 }; return tmp2 } else {
				return es.F_elements == t.F_elements } } else {
					return t.EnumSet.Impl_Equals_O__Z(t, o)
				}
}

type RegularEnumSet struct{ EnumSet; F_elements int64 }

const RegularEnumSet_serialVersionUID int64 = 3411599620347842686

func (t *RegularEnumSet) Add_O__Z(p0 any) bool { return t.Add_Enum__Z(Enum_Cast(p0)) }

func (t *RegularEnumSet) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *RegularEnumSet) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *RegularEnumSet) Clone__EnumSet() EnumSet_I { return t.Impl_Clone__EnumSet(t) }

func (t *RegularEnumSet) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *RegularEnumSet) TypeCheck_Enum__V(p0 Enum_I) { t.Impl_TypeCheck_Enum__V(t, p0) }

func (t *RegularEnumSet) WriteReplace__O() any { return t.Impl_WriteReplace__O(t) }

func (t *RegularEnumSet) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *RegularEnumSet) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *RegularEnumSet) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *RegularEnumSet) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *RegularEnumSet) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *RegularEnumSet) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *RegularEnumSet) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *RegularEnumSet) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *RegularEnumSet) Ref() any { if t == nil { return nil }; return t }

func (t *RegularEnumSet) GetClass__Class() *Class { return RegularEnumSet_class }

func (t *RegularEnumSet) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func RegularEnumSet_InstanceOf(x any) bool { _, ok := x.(*RegularEnumSet); return ok }

func RegularEnumSet_Cast(x any) *RegularEnumSet { if x == nil { return nil }; v, ok := x.(*RegularEnumSet); if !ok { panic(ClassCast(x, RegularEnumSet_class)) }; return v }



type RegularEnumSet_EnumSetIterator struct{ Object; F_unseen, F_lastReturned int64; F_this_0 *RegularEnumSet }

func (t *RegularEnumSet_EnumSetIterator) Is_Iterator() {}

func (t *RegularEnumSet_EnumSetIterator) Next__O() any { return t.Next__Enum() }

func (t *RegularEnumSet_EnumSetIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *RegularEnumSet_EnumSetIterator) Ref() any { if t == nil { return nil }; return t }

func (t *RegularEnumSet_EnumSetIterator) GetClass__Class() *Class { return RegularEnumSet_EnumSetIterator_class }

func (t *RegularEnumSet_EnumSetIterator) ToString__String() *String { return Object_toString(t) }

func (t *RegularEnumSet_EnumSetIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *RegularEnumSet_EnumSetIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func RegularEnumSet_EnumSetIterator_InstanceOf(x any) bool { _, ok := x.(*RegularEnumSet_EnumSetIterator); return ok }

func RegularEnumSet_EnumSetIterator_Cast(x any) *RegularEnumSet_EnumSetIterator { if x == nil { return nil }; v, ok := x.(*RegularEnumSet_EnumSetIterator); if !ok { panic(ClassCast(x, RegularEnumSet_EnumSetIterator_class)) }; return v }
