//line java_net_Inet4Address.ae:1
package jrt
















func Inet4Address_New() *Inet4Address { Inet4Address_Init(); t := &Inet4Address{}; t.Ctor(); return t }
//line :18:1
func (t *Inet4Address) Ctor() { t.InetAddress.Ctor(t)

	t.Holder__InetAddress_InetAddressHolder().F_hostName = nil
	t.Holder__InetAddress_InetAddressHolder().F_address = 0
	t.Holder__InetAddress_InetAddressHolder().F_family = 1
}
func Inet4Address_New_String_B1(p0 *String, p1 *ByteArray) *Inet4Address { Inet4Address_Init(); t := &Inet4Address{}; t.Ctor_String_B1(p0, p1); return t }
//line :24:1
func (t *Inet4Address) Ctor_String_B1(hostName *String, addr *ByteArray) { t.InetAddress.Ctor(t)
	t.Holder__InetAddress_InetAddressHolder().F_hostName = hostName
	t.Holder__InetAddress_InetAddressHolder().F_family = 1
	if !(addr == nil) {
		if int32(len(addr.A)) == 4 {
			var address int32 = int32(addr.A[3]) & 255
			address = address | int32(addr.A[2])<<8&65280

			address = address | int32(addr.A[1])<<16&16711680

			address = address | int32(addr.A[0])<<24&-16777216



			t.Holder__InetAddress_InetAddressHolder().F_address = address } }
	t.Holder__InetAddress_InetAddressHolder().F_originalHostName = hostName
}
func Inet4Address_New_String_I(p0 *String, p1 int32) *Inet4Address { Inet4Address_Init(); t := &Inet4Address{}; t.Ctor_String_I(p0, p1); return t }
//line :41:1
func (t *Inet4Address) Ctor_String_I(hostName *String, address int32) { panic(A2g_NotTranslated("java.net.Inet4Address.<init>(Ljava/lang/String;I)V")) }





func Inet4Address_OfLiteral_String__Inet4Address(ipv4AddressLiteral *String) *Inet4Address { Inet4Address_Init()
	Objects_RequireNonNull_O__O(ipv4AddressLiteral.Ref())
	return Inet4Address_ParseAddressString_String_Z__Inet4Address(ipv4AddressLiteral, true)
}
func Inet4Address_OfPosixLiteral_String__Inet4Address(posixIPAddressLiteral *String) *Inet4Address { Inet4Address_Init()
	Objects_RequireNonNull_O__O(posixIPAddressLiteral.Ref())
	return Inet4Address_ParseAddressStringPosix_String__Inet4Address(posixIPAddressLiteral)
}
func Inet4Address_ParseAddressString_String_Z__Inet4Address(addressLiteral *String, throwIAE bool) *Inet4Address { Inet4Address_Init()
	var addrBytes *ByteArray = IPAddressUtil_ValidateNumericFormatV4_String_Z__B1(addressLiteral, throwIAE)
	if !(addrBytes == nil) { return Inet4Address_New_String_B1(nil, addrBytes) } else { return nil
	} }
func Inet4Address_ParseAddressStringPosix_String__Inet4Address(addressLiteral *String) *Inet4Address { Inet4Address_Init()
	var parsedBytes *ByteArray = IPAddressUtil_ParseBsdLiteralV4_String__B1(addressLiteral)
	if parsedBytes == nil { panic(Thrown(IPAddressUtil_InvalidIpAddressLiteral_String__IllegalArgumentException(addressLiteral))) }
	return Inet4Address_New_String_B1(nil, parsedBytes)
}
func (t *Inet4Address) WriteReplace__O() any { panic(A2g_NotTranslated("java.net.Inet4Address.writeReplace()Ljava/lang/Object;")) }






func (t *Inet4Address) IsMulticastAddress__Z() bool {
	return NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I()&-268435456 == -536870912
}

func (t *Inet4Address) IsAnyLocalAddress__Z() bool {
	return NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I() == 0
}
func (t *Inet4Address) IsLoopbackAddress__Z() bool {
	var byteAddr *ByteArray = t.GetAddress__B1(); return int32(byteAddr.A[0]) == 127
}
func (t *Inet4Address) IsLinkLocalAddress__Z() bool {
	var address int32 = NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I(); var tmp1 bool
	tmp1 = int32(uint32(address)>>24)&255 == 169; if tmp1 {
		tmp1 = int32(uint32(address)>>16)&255 == 254 }
//line :83:1
	return tmp1
}

func (t *Inet4Address) IsSiteLocalAddress__Z() bool {
	var address int32 = NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I(); var tmp1 bool; var tmp2 bool
	tmp2 = int32(uint32(address)>>24)&255 == 10; if !tmp2 {
		var tmp3 bool; tmp3 = int32(uint32(address)>>24)&255 == 172; if tmp3 {
			tmp3 = int32(uint32(address)>>16)&240 == 16 }
//line :89:1
		tmp2 = tmp3 }
//line :88:1
	tmp1 = tmp2; if !tmp1 {


		var tmp4 bool; tmp4 = int32(uint32(address)>>24)&255 == 192; if tmp4 {
			tmp4 = int32(uint32(address)>>16)&255 == 168 }
//line :91:1
		tmp1 = tmp4 }
//line :88:1
	return tmp1
}




func (t *Inet4Address) IsMCGlobal__Z() bool {
	var byteAddr *ByteArray = t.GetAddress__B1(); var tmp1 bool; var tmp2 bool
	tmp2 = int32(byteAddr.A[0])&255 >= 224; if tmp2 {
		tmp2 = int32(byteAddr.A[0])&255 <= 238 }
//line :96:1
	tmp1 = tmp2; if tmp1 {

		var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = int32(byteAddr.A[0])&255 == 224; if tmp5 { tmp5 = int32(byteAddr.A[1]) == 0 }; tmp4 = tmp5; if tmp4 {
			tmp4 = int32(byteAddr.A[2]) == 0 }
//line :98:1
		tmp3 = tmp4; tmp1 = !tmp3 }
//line :96:1
	return tmp1
}



func (t *Inet4Address) IsMCNodeLocal__Z() bool { return false }

func (t *Inet4Address) IsMCLinkLocal__Z() bool {
	var address int32 = NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I(); var tmp1 bool; var tmp2 bool
	tmp2 = int32(uint32(address)>>24)&255 == 224; if tmp2 {
		tmp2 = int32(uint32(address)>>16)&255 == 0 }
//line :105:1
	tmp1 = tmp2; if tmp1 {

		tmp1 = int32(uint32(address)>>8)&255 == 0 }
//line :105:1
	return tmp1
}


func (t *Inet4Address) IsMCSiteLocal__Z() bool {
	var address int32 = NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I(); var tmp1 bool
	tmp1 = int32(uint32(address)>>24)&255 == 239; if tmp1 {
		tmp1 = int32(uint32(address)>>16)&255 == 255 }
//line :111:1
	return tmp1
}

func (t *Inet4Address) IsMCOrgLocal__Z() bool {
	var address int32 = NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I(); var tmp1 bool; var tmp2 bool
	tmp2 = int32(uint32(address)>>24)&255 == 239; if tmp2 {
		tmp2 = int32(uint32(address)>>16)&255 >= 192 }
//line :116:1
	tmp1 = tmp2; if tmp1 {

		tmp1 = int32(uint32(address)>>16)&255 <= 195 }
//line :116:1
	return tmp1
}


func (t *Inet4Address) GetAddress__B1() *ByteArray {
	var address int32 = NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I(); var addr *ByteArray = NewByteArray(4)

	addr.A[0] = int8(int32(uint32(address)>>24) & 255)
	addr.A[1] = int8(int32(uint32(address)>>16) & 255)
	addr.A[2] = int8(int32(uint32(address)>>8) & 255)
	addr.A[3] = int8(address & 255)
//line :121:1
	return addr
}






func (t *Inet4Address) AddressValue__I() int32 { panic(A2g_NotTranslated("java.net.Inet4Address.addressValue()I")) }

func (t *Inet4Address) GetHostAddress__String() *String {
	return Inet4Address_NumericToTextFormat_B1__String(t.GetAddress__B1())
}
func (t *Inet4Address) HashCode__I() int32 { return NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I() }

func (t *Inet4Address) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Inet4Address_InstanceOf(tmp1) { var inet4Address *Inet4Address = Inet4Address_Cast(tmp1)
		return NN(NN(inet4Address).Holder__InetAddress_InetAddressHolder()).GetAddress__I() == NN(t.Holder__InetAddress_InetAddressHolder()).GetAddress__I() } else {
//line :137:1
			return false
		}
}

func Inet4Address_NumericToTextFormat_B1__String(src *ByteArray) *String { Inet4Address_Init()
	var tmp1 int32 = int32(src.A[0]) & 255; var tmp2 int32 = int32(src.A[1]) & 255; var tmp3 int32 = int32(src.A[2]) & 255; return Concat(StrOfInt(tmp1), Lit_79, StrOfInt(tmp2), Lit_79, StrOfInt(tmp3), Lit_79, StrOfInt(int32(src.A[3])&255))
}


type Inet4Address struct{ InetAddress }

const Inet4Address_INADDRSZ int32 = 4

const Inet4Address_serialVersionUID int64 = 3286316764910316507

var Inet4Address_init ClassInit

func Inet4Address_Init() { if !Inet4Address_init.Done() { Inet4Address_init.Run(Inet4Address_clinit) } }

func Inet4Address_clinit() { InetAddress_Init() }

func (t *Inet4Address) Holder__InetAddress_InetAddressHolder() *InetAddress_InetAddressHolder { return t.Impl_Holder__InetAddress_InetAddressHolder(t) }

func (t *Inet4Address) IsReachable_I__Z(p0 int32) bool { return t.Impl_IsReachable_I__Z(t, p0) }

func (t *Inet4Address) GetHostName__String() *String { return t.Impl_GetHostName__String(t) }

func (t *Inet4Address) GetCanonicalHostName__String() *String { return t.Impl_GetCanonicalHostName__String(t) }

func (t *Inet4Address) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Inet4Address) Ref() any { if t == nil { return nil }; return t }

func (t *Inet4Address) GetClass__Class() *Class { return Inet4Address_class }

func (t *Inet4Address) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Inet4Address) CloneShallow() any { panic(CloneNotSupported(t)) }

func Inet4Address_InstanceOf(x any) bool { _, ok := x.(*Inet4Address); return ok }

func Inet4Address_Cast(x any) *Inet4Address { if x == nil { return nil }; v, ok := x.(*Inet4Address); if !ok { panic(ClassCast(x, Inet4Address_class)) }; return v }
