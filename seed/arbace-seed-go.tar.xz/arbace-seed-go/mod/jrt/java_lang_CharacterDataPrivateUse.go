//line java_lang_CharacterDataPrivateUse.ae:1
package jrt






func (t *CharacterDataPrivateUse) GetProperties_I__I(p0 int32) int32 { panic(A2g_NotTranslated("java.lang.CharacterDataPrivateUse.getProperties(I)I")) }

func (t *CharacterDataPrivateUse) GetType_I__I(ch int32) int32 {
	if ch&65534 == 65534 { return 0 } else { return 18
	} }
func (t *CharacterDataPrivateUse) IsJavaIdentifierStart_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsJavaIdentifierPart_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsUnicodeIdentifierStart_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsUnicodeIdentifierPart_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsIdentifierIgnorable_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsEmoji_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsEmojiPresentation_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsEmojiModifier_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsEmojiModifierBase_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsEmojiComponent_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsExtendedPictographic_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) ToLowerCase_I__I(ch int32) int32 { return ch }

func (t *CharacterDataPrivateUse) ToUpperCase_I__I(ch int32) int32 { return ch }

func (t *CharacterDataPrivateUse) ToTitleCase_I__I(ch int32) int32 { return ch }

func (t *CharacterDataPrivateUse) Digit_I_I__I(ch, radix int32) int32 { return -1 }

func (t *CharacterDataPrivateUse) GetNumericValue_I__I(ch int32) int32 { return -1 }

func (t *CharacterDataPrivateUse) IsDigit_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsLowerCase_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsUpperCase_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) IsWhitespace_I__Z(ch int32) bool { return false }

func (t *CharacterDataPrivateUse) GetDirectionality_I__B(ch int32) int8 {
	if ch&65534 == 65534 { return -1 } else { return 0
	}
}

func (t *CharacterDataPrivateUse) IsMirrored_I__Z(ch int32) bool { return false }



func CharacterDataPrivateUse_New() *CharacterDataPrivateUse { CharacterDataPrivateUse_Init(); t := &CharacterDataPrivateUse{}; t.Ctor(); return t }
//line :62:1
func (t *CharacterDataPrivateUse) Ctor() { t.CharacterData.Ctor(t) }





type CharacterDataPrivateUse struct{ CharacterData }

var CharacterDataPrivateUse_instance CharacterData_I

var CharacterDataPrivateUse_init ClassInit

func CharacterDataPrivateUse_Init() { if !CharacterDataPrivateUse_init.Done() { CharacterDataPrivateUse_init.Run(CharacterDataPrivateUse_clinit) } }

func CharacterDataPrivateUse_clinit() { CharacterDataPrivateUse_instance = CharacterDataPrivateUse_New() }

func (t *CharacterDataPrivateUse) IsOtherAlphabetic_I__Z(p0 int32) bool { return t.Impl_IsOtherAlphabetic_I__Z(t, p0) }

func (t *CharacterDataPrivateUse) IsIdeographic_I__Z(p0 int32) bool { return t.Impl_IsIdeographic_I__Z(t, p0) }

func (t *CharacterDataPrivateUse) ToUpperCaseCharArray_I__C1(p0 int32) *CharArray { return t.Impl_ToUpperCaseCharArray_I__C1(t, p0) }

func (t *CharacterDataPrivateUse) ToUpperCaseEx_I__I(p0 int32) int32 { return t.Impl_ToUpperCaseEx_I__I(t, p0) }

func (t *CharacterDataPrivateUse) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterDataPrivateUse) GetClass__Class() *Class { return CharacterDataPrivateUse_class }

func (t *CharacterDataPrivateUse) ToString__String() *String { return Object_toString(t) }

func (t *CharacterDataPrivateUse) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterDataPrivateUse) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterDataPrivateUse_InstanceOf(x any) bool { _, ok := x.(*CharacterDataPrivateUse); return ok }

func CharacterDataPrivateUse_Cast(x any) *CharacterDataPrivateUse { if x == nil { return nil }; v, ok := x.(*CharacterDataPrivateUse); if !ok { panic(ClassCast(x, CharacterDataPrivateUse_class)) }; return v }
