//line java_io_CharArrayReader.ae:1
package jrt

















func CharArrayReader_New_C1(p0 *CharArray) *CharArrayReader { t := &CharArrayReader{}; t.Ctor_C1(p0); return t }
//line :19:1
func (t *CharArrayReader) Ctor_C1(buf *CharArray) { t.Reader.Ctor(t); t.F_markedPos = 0
	t.F_buf = buf
	t.F_pos = 0
	t.F_count = int32(len(buf.A))
}
func CharArrayReader_New_C1_I_I(p0 *CharArray, p1, p2 int32) *CharArrayReader { t := &CharArrayReader{}; t.Ctor_C1_I_I(p0, p1, p2); return t }
//line :24:1
func (t *CharArrayReader) Ctor_C1_I_I(buf *CharArray, offset, length int32) { t.Reader.Ctor(t); t.F_markedPos = 0
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = offset < 0; if !tmp4 { tmp4 = offset > int32(len(buf.A)) }; tmp3 = tmp4; if !tmp3 { tmp3 = length < 0 }; tmp2 = tmp3; if !tmp2 {
		tmp2 = offset+length < 0 }
//line :25:1
	tmp1 = tmp2; if tmp1 {

		panic(Thrown(IllegalArgumentException_New())) }
	t.F_buf = buf
	t.F_pos = offset
	t.F_count = Math_Min_I_I__I(offset+length, int32(len(buf.A)))
	t.F_markedPos = offset
}
func (t *CharArrayReader) EnsureOpen__V() {
	if t.F_buf == nil { panic(Thrown(IOException_New_String(Lit_48)))
	} }
func (t *CharArrayReader) Read__I() int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.EnsureOpen__V()
		if t.F_pos >= t.F_count { tmp1 = -1 } else { var pos_1 int32 = t.F_pos; t.F_pos = t.F_pos + 1; tmp1 = int32(t.F_buf.A[pos_1]) } }()
//line :37:1
	return tmp1
}


func (t *CharArrayReader) Read_C1_I_I__I(cbuf *CharArray, off, len_ int32) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.EnsureOpen__V()
		Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(cbuf.A)))
		if len_ == 0 { tmp1 = 0 } else { if t.F_pos >= t.F_count { tmp1 = -1 } else {



			var avail int32 = t.F_count - t.F_pos
			if len_ > avail { len_ = avail }
			if len_ <= 0 { tmp1 = 0 } else {


				System_Arraycopy_O_I_O_I_I__V(t.F_buf.Ref(), t.F_pos, cbuf.Ref(), off, len_)
				t.F_pos = t.F_pos + len_
//line :53:1
				tmp1 = len_ } } } }()
//line :42:1
	return tmp1
}














func (t *CharArrayReader) Read_CharBuffer__I(target CharBuffer_I) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.EnsureOpen__V()
		if t.F_pos >= t.F_count { tmp1 = -1 } else {

			var avail int32 = t.F_count - t.F_pos; var len_ int32 = Math_Min_I_I__I(avail, target.Remaining__I())

			target.Put_C1_I_I__CharBuffer(t.F_buf, t.F_pos, len_)
			t.F_pos = t.F_pos + len_
//line :63:1
			tmp1 = len_ } }()
//line :59:1
	return tmp1
}








func (t *CharArrayReader) Skip_J__J(n int64) int64 {
	var tmp1 int64; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		t.EnsureOpen__V()
		var avail int64 = int64(t.F_count - t.F_pos)
		if n > avail { n = avail }
		if n < 0 { tmp1 = 0 } else { t.F_pos = t.F_pos + int32(n); tmp1 = n } }()
//line :70:1
	return tmp1
}




func (t *CharArrayReader) Ready__Z() bool {
	var tmp1 bool; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2); t.EnsureOpen__V(); tmp1 = t.F_count-t.F_pos > 0 }(); return tmp1
}
func (t *CharArrayReader) MarkSupported__Z() bool { return true }

func (t *CharArrayReader) Mark_I__V(readAheadLimit int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.EnsureOpen__V(); t.F_markedPos = t.F_pos }()
}
func (t *CharArrayReader) Reset__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.EnsureOpen__V(); t.F_pos = t.F_markedPos }()
}
func (t *CharArrayReader) Close__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1); t.F_buf = nil }()
}


type CharArrayReader struct{ Reader; F_buf *CharArray; F_pos, F_markedPos, F_count int32 }

func (t *CharArrayReader) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *CharArrayReader) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *CharArrayReader) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *CharArrayReader) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *CharArrayReader) Ref() any { if t == nil { return nil }; return t }

func (t *CharArrayReader) GetClass__Class() *Class { return CharArrayReader_class }

func (t *CharArrayReader) ToString__String() *String { return Object_toString(t) }

func (t *CharArrayReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharArrayReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharArrayReader_InstanceOf(x any) bool { _, ok := x.(*CharArrayReader); return ok }

func CharArrayReader_Cast(x any) *CharArrayReader { if x == nil { return nil }; v, ok := x.(*CharArrayReader); if !ok { panic(ClassCast(x, CharArrayReader_class)) }; return v }
