//line java_lang_Long.ae:1
package jrt





















func Long_ToString_J_I__String(i int64, radix int32) *String {
	var tmp1 bool; var tmp2 bool; tmp2 = radix < 2; if !tmp2 { tmp2 = radix > 36 }; tmp1 = tmp2; if tmp1 { radix = 10 }
	if radix == 10 {
		return Long_ToString_J__String(i) } else {
//line :25:1
			if String_COMPACT_STRINGS {


				var buf *ByteArray = NewByteArray(65); var charPos int32 = 64; var negative bool = i < 0


				if negative { } else { i = -i }
			L1: for { if i <= int64(-radix) {
				var tmp3 int32 = charPos; var tmp4 *ByteArray; Integer_Init(); tmp4 = Integer_digits; var tmp5 *ByteArray = tmp4; buf.A[tmp3] = tmp5.A[int32(-(i % int64(radix)))]



				charPos = charPos - 1
				i = i / int64(radix)
//line :32:1
				continue L1 }; break L1
			}





				var tmp6 int32 = charPos; var tmp7 *ByteArray; Integer_Init(); tmp7 = Integer_digits; buf.A[tmp6] = tmp7.A[int32(-i)]
				if negative { var tmp8 int32; charPos = charPos - 1; tmp8 = charPos; buf.A[tmp8] = 45 }
				return StringLatin1_NewString_B1_I_I__String(buf, charPos, 65-charPos) } else {
					return Long_ToStringUTF16_J_I__String(i, radix)
				} } }
func Long_ToStringUTF16_J_I__String(i int64, radix int32) *String {
	var buf *ByteArray = NewByteArray(130); var charPos int32 = 64; var negative bool = i < 0


	if negative { } else { i = -i }
L1: for { if i <= int64(-radix) {
	var tmp1 int32 = charPos; var tmp2 *ByteArray; Integer_Init(); tmp2 = Integer_digits; var tmp3 *ByteArray = tmp2; StringUTF16_PutChar_B1_I_I__V(buf, tmp1, int32(tmp3.A[int32(-(i%int64(radix)))]))



	charPos = charPos - 1
	i = i / int64(radix)
//line :49:1
	continue L1 }; break L1
}





	var tmp4 int32 = charPos; var tmp5 *ByteArray; Integer_Init(); tmp5 = Integer_digits; StringUTF16_PutChar_B1_I_I__V(buf, tmp4, int32(tmp5.A[int32(-i)]))
	if negative { var tmp6 int32; charPos = charPos - 1; tmp6 = charPos; StringUTF16_PutChar_B1_I_I__V(buf, tmp6, 45) }
	return StringUTF16_NewString_B1_I_I__String(buf, charPos, 65-charPos)
}
func Long_ToUnsignedString_J_I__String(i int64, radix int32) *String {
	if i >= 0 {
		return Long_ToString_J_I__String(i, radix) } else {
			switch radix { case 2:
				return Long_ToBinaryString_J__String(i); case 4:
				return Long_ToUnsignedString0_J_I__String(i, 2); case 8:
				return Long_ToOctalString_J__String(i); case 10:

				var quot int64 = int64(uint64(i)>>1) / 5; var rem int64 = i - quot*10

				return Concat(Long_ToString_J__String(quot), StrOfLong(rem)); case 16:
				return Long_ToHexString_J__String(i); case 32:
				return Long_ToUnsignedString0_J_I__String(i, 5); default:
				return NN(Long_ToUnsignedBigInteger_J__BigInteger(i)).ToString_I__String(radix)} }; panic("a2g: unreachable")
}
func Long_ToUnsignedBigInteger_J__BigInteger(i int64) *BigInteger {
	if i >= 0 {
		return BigInteger_ValueOf_J__BigInteger(i) } else {
			var upper int32 = int32(int64(uint64(i) >> 32)); var lower int32 = int32(i)

			return NN(NN(BigInteger_ValueOf_J__BigInteger(Integer_ToUnsignedLong_I__J(upper))).ShiftLeft_I__BigInteger(32)).Add_BigInteger__BigInteger(BigInteger_ValueOf_J__BigInteger(Integer_ToUnsignedLong_I__J(lower)))
		}
}
func Long_ToHexString_J__String(i int64) *String {
	return Long_ToUnsignedString0_J_I__String(i, 4)
}
func Long_ToOctalString_J__String(i int64) *String {
	return Long_ToUnsignedString0_J_I__String(i, 3)
}
func Long_ToBinaryString_J__String(i int64) *String {
	return Long_ToUnsignedString0_J_I__String(i, 1)
}
func Long_ToUnsignedString0_J_I__String(val int64, shift int32) *String {
	var mag int32 = 64 - Long_NumberOfLeadingZeros_J__I(val); var chars int32 = Math_Max_I_I__I((mag+(shift-1))/shift, 1); var buf *ByteArray = NewByteArray(chars)





	Long_FormatUnsignedLong0_J_I_B1_I_I__V(val, shift, buf, 0, chars)
	return String_NewStringWithLatin1Bytes_B1__String(buf)
}
func Long_FormatUnsignedLong0_J_I_B1_I_I__V(val int64, shift int32, buf *ByteArray, offset, len_ int32) {

	var charPos int32 = offset + len_; var radix int32 = 1 << (shift & 31); var mask int32 = radix - 1


L1: for {
	var tmp1 int32
	charPos = charPos - 1; tmp1 = charPos
//line :108:1
	var tmp2 int32 = tmp1; var tmp3 *ByteArray; Integer_Init(); tmp3 = Integer_digits; buf.A[tmp2] = tmp3.A[int32(val)&mask]


	val = int64(uint64(val) >> (shift & 63))
	if charPos > offset { continue L1 }
//line :107:1
	break L1
}
}




func Long_ToString_J__String(i int64) *String {
	var size int32 = DecimalDigits_StringSize_J__I(i); var buf *ByteArray = NewByteArray(size)

	DecimalDigits_UncheckedGetCharsLatin1_J_I_B1__I(i, size, buf)
	return String_NewStringWithLatin1Bytes_B1__String(buf)
}
func Long_ToUnsignedString_J__String(i int64) *String {
	return Long_ToUnsignedString_J_I__String(i, 10)
}
func Long_ParseLong_String_I__J(s *String, radix int32) int64 {
	if s == nil { panic(Thrown(NumberFormatException_New_String(Lit_1123))) }
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	var len_ int32 = NN(s).Length__I()
	if len_ == 0 { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(Lit_69, radix)))) }
	var digit int32 = -256; var i int32 = 0; var firstChar uint16; var tmp1 int32
	var old_1 int32 = i
	i = i + 1; tmp1 = old_1; firstChar = NN(s).CharAt_I__C(tmp1)
	var tmp2 bool; var tmp3 bool; tmp3 = !(int32(firstChar) == 45); if tmp3 { tmp3 = !(int32(firstChar) == 43) }; tmp2 = tmp3; if tmp2 {
		digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp4 bool; var tmp5 bool; tmp5 = digit >= 0; if !tmp5 { var tmp6 bool; tmp6 = digit == -256; if tmp6 { tmp6 = len_ > 1 }; tmp5 = tmp6 }; tmp4 = tmp5; if tmp4 {
		var limit int64; if !(int32(firstChar) == 45) { limit = -9223372036854775807 } else { limit = -9223372036854775808 }; var multmin int64 = limit / int64(radix); var result int64 = int64(-(digit & 255))
		var inRange bool = true


	L1: for { var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = i < len_; if tmp9 {
		var tmp10 int32; var tmp11 int32
		var old_2 int32 = i


		i = i + 1; tmp11 = old_2
//line :144:1
		digit = Character_Digit_C_I__I(NN(s).CharAt_I__C(tmp11), radix); tmp10 = digit; tmp9 = tmp10 >= 0 }
//line :143:1
		tmp8 = tmp9; if tmp8 {







			var tmp12 bool; var tmp13 bool
			tmp13 = result > multmin; if !tmp13 {
				var tmp14 bool; tmp14 = result == multmin; if tmp14 {
					tmp14 = digit <= int32(int64(radix)*multmin-limit) }
//line :153:1
				tmp13 = tmp14 }
//line :152:1
			tmp12 = tmp13
//line :151:1
			inRange = tmp12; tmp8 = inRange }
//line :143:1
		tmp7 = tmp8; if tmp7 {















			result = int64(radix)*result - int64(digit)
//line :143:1
			continue L1 }; break L1
	}















		var tmp15 bool; var tmp16 bool; var tmp17 bool; tmp17 = inRange; if tmp17 { tmp17 = i == len_ }; tmp16 = tmp17; if tmp16 { tmp16 = digit >= 0 }; tmp15 = tmp16; if tmp15 {
			var tmp18 int64; if !(int32(firstChar) == 45) { tmp18 = -result } else { tmp18 = result }; return tmp18 } }
	panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(s, radix))))
}
func Long_ParseLong_CharSequence_I_I_I__J(s CharSequence, beginIndex, endIndex, radix int32) int64 {



	Objects_RequireNonNull_O__O(s)
	Objects_CheckFromToIndex_I_I_I__I(beginIndex, endIndex, s.Length__I())
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if beginIndex == endIndex { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(Lit_69, radix)))) }
	var digit int32 = -256; var i int32 = beginIndex; var firstChar uint16; var tmp1 int32
	var old_3 int32 = i
	i = i + 1; tmp1 = old_3; firstChar = s.CharAt_I__C(tmp1)
	var tmp2 bool; var tmp3 bool; tmp3 = !(int32(firstChar) == 45); if tmp3 { tmp3 = !(int32(firstChar) == 43) }; tmp2 = tmp3; if tmp2 {
		digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp4 bool; var tmp5 bool; tmp5 = digit >= 0; if !tmp5 {
		var tmp6 bool; tmp6 = digit == -256; if tmp6 {
			tmp6 = endIndex-beginIndex > 1 }
//line :183:1
		tmp5 = tmp6 }
//line :182:1
	tmp4 = tmp5; if tmp4 {


		var limit int64; if !(int32(firstChar) == 45) { limit = -9223372036854775807 } else { limit = -9223372036854775808 }; var multmin int64 = limit / int64(radix); var result int64 = int64(-(digit & 255))
		var inRange bool = true


	L1: for { var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = i < endIndex; if tmp9 {
		var tmp10 int32; var tmp11 int32
		var old_4 int32 = i


		i = i + 1; tmp11 = old_4
//line :190:1
		digit = Character_Digit_C_I__I(s.CharAt_I__C(tmp11), radix); tmp10 = digit; tmp9 = tmp10 >= 0 }
//line :189:1
		tmp8 = tmp9; if tmp8 {







			var tmp12 bool; var tmp13 bool
			tmp13 = result > multmin; if !tmp13 {
				var tmp14 bool; tmp14 = result == multmin; if tmp14 {
					tmp14 = digit <= int32(int64(radix)*multmin-limit) }
//line :199:1
				tmp13 = tmp14 }
//line :198:1
			tmp12 = tmp13
//line :197:1
			inRange = tmp12; tmp8 = inRange }
//line :189:1
		tmp7 = tmp8; if tmp7 {















			result = int64(radix)*result - int64(digit)
//line :189:1
			continue L1 }; break L1
	}















		var tmp15 bool; var tmp16 bool; var tmp17 bool; tmp17 = inRange; if tmp17 { tmp17 = i == endIndex }; tmp16 = tmp17; if tmp16 { tmp16 = digit >= 0 }; tmp15 = tmp16; if tmp15 {
			var tmp18 int64; if !(int32(firstChar) == 45) { tmp18 = -result } else { tmp18 = result }; return tmp18 } }
	var tmp19 int32 = i; var tmp20 int32



	if digit < -1 { tmp20 = 0 } else { tmp20 = 1 }
//line :208:1
	panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForCharSequence_CharSequence_I_I_I__NumberFormatException(s, beginIndex, endIndex, tmp19-tmp20))))
}




func Long_ParseLong_String__J(s *String) int64 {
	return Long_ParseLong_String_I__J(s, 10)
}
func Long_ParseUnsignedLong_String_I__J(s *String, radix int32) int64 {

	if s == nil { panic(Thrown(NumberFormatException_New_String(Lit_1123))) }
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	var len_ int32 = NN(s).Length__I()
	if len_ == 0 { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(s, radix)))) }
	var i int32 = 0; var firstChar uint16; var tmp1 int32; var old_5 int32 = i
	i = i + 1; tmp1 = old_5; firstChar = NN(s).CharAt_I__C(tmp1)
	if int32(firstChar) == 45 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1126, RefArrayOf(Object_class, s.Ref())))))
	}

	var digit int32 = -256
	if int32(firstChar) == 43 { } else { digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp2 bool; var tmp3 bool; tmp3 = digit >= 0; if !tmp3 { var tmp4 bool; tmp4 = digit == -256; if tmp4 { tmp4 = len_ > 1 }; tmp3 = tmp4 }; tmp2 = tmp3; if tmp2 {
		var multmax int64 = Long_DivideUnsigned_J_J__J(-1, int64(radix)); var result int64 = int64(digit & 255)
		var inRange bool = true

	L1: for { var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = i < len_; if tmp7 {
		var tmp8 int32; var tmp9 int32
		var old_6 int32 = i


		i = i + 1; tmp9 = old_6
//line :241:1
		digit = Character_Digit_C_I__I(NN(s).CharAt_I__C(tmp9), radix); tmp8 = digit; tmp7 = tmp8 >= 0 }
//line :240:1
		tmp6 = tmp7; if tmp6 {







			var tmp10 bool; var tmp11 bool
			tmp11 = Long_CompareUnsigned_J_J__I(result, multmax) < 0; if !tmp11 {
				var tmp12 bool; tmp12 = result == multmax; if tmp12 {
					tmp12 = digit < int32(int64(-radix)*multmax) }
//line :250:1
				tmp11 = tmp12 }
//line :249:1
			tmp10 = tmp11
//line :248:1
			inRange = tmp10; tmp6 = inRange }
//line :240:1
		tmp5 = tmp6; if tmp5 {















			result = int64(radix)*result + int64(digit)
//line :240:1
			continue L1 }; break L1
	}















		var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = inRange; if tmp15 { tmp15 = i == len_ }; tmp14 = tmp15; if tmp14 { tmp14 = digit >= 0 }; tmp13 = tmp14; if tmp13 { return result } }
	if digit < 0 { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(s, radix)))) }
	panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1139, RefArrayOf(Object_class, s.Ref())))))
}


func Long_ParseUnsignedLong_CharSequence_I_I_I__J(s CharSequence, beginIndex, endIndex, radix int32) int64 {



	Objects_RequireNonNull_O__O(s)
	Objects_CheckFromToIndex_I_I_I__I(beginIndex, endIndex, s.Length__I())
	if radix < 2 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1124, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if radix > 36 {
		panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1125, RefArrayOf(Object_class, Integer_ValueOf_I__Integer(radix))))))
	}
	if beginIndex == endIndex { panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForInputString_String_I__NumberFormatException(Lit_69, radix)))) }
	var i int32 = beginIndex; var firstChar uint16; var tmp1 int32; var old_7 int32 = i
	i = i + 1; tmp1 = old_7; firstChar = s.CharAt_I__C(tmp1)
	if int32(firstChar) == 45 {
		panic(Thrown(NumberFormatException_New_String(Concat(Lit_1128, StrOfObj(s), Lit_79))))
	}
	var digit int32 = -256
	if int32(firstChar) == 43 { } else { digit = Character_Digit_C_I__I(firstChar, radix) }
	var tmp2 bool; var tmp3 bool; tmp3 = digit >= 0; if !tmp3 {
		var tmp4 bool; tmp4 = digit == -256; if tmp4 {
			tmp4 = endIndex-beginIndex > 1 }
//line :284:1
		tmp3 = tmp4 }
//line :283:1
	tmp2 = tmp3; if tmp2 {


		var multmax int64 = Long_DivideUnsigned_J_J__J(-1, int64(radix)); var result int64 = int64(digit & 255)
		var inRange bool = true

	L1: for { var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = i < endIndex; if tmp7 {
		var tmp8 int32; var tmp9 int32
		var old_8 int32 = i


		i = i + 1; tmp9 = old_8
//line :290:1
		digit = Character_Digit_C_I__I(s.CharAt_I__C(tmp9), radix); tmp8 = digit; tmp7 = tmp8 >= 0 }
//line :289:1
		tmp6 = tmp7; if tmp6 {







			var tmp10 bool; var tmp11 bool
			tmp11 = Long_CompareUnsigned_J_J__I(result, multmax) < 0; if !tmp11 {
				var tmp12 bool; tmp12 = result == multmax; if tmp12 {
					tmp12 = digit < int32(int64(-radix)*multmax) }
//line :299:1
				tmp11 = tmp12 }
//line :298:1
			tmp10 = tmp11
//line :297:1
			inRange = tmp10; tmp6 = inRange }
//line :289:1
		tmp5 = tmp6; if tmp5 {















			result = int64(radix)*result + int64(digit)
//line :289:1
			continue L1 }; break L1
	}















		var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = inRange; if tmp15 { tmp15 = i == endIndex }; tmp14 = tmp15; if tmp14 { tmp14 = digit >= 0 }; tmp13 = tmp14; if tmp13 { return result } }
	if digit < 0 {
		var tmp16 int32 = i; var tmp17 int32



		if digit < -1 { tmp17 = 0 } else { tmp17 = 1 }
//line :308:1
		panic(Thrown(Up_NumberFormatException_Throwable(NumberFormatException_ForCharSequence_CharSequence_I_I_I__NumberFormatException(s, beginIndex, endIndex, tmp16-tmp17))))
	}



	panic(Thrown(NumberFormatException_New_String(String_Format_String_O1__String(Lit_1139, RefArrayOf(Object_class, s)))))
}


func Long_ParseUnsignedLong_String__J(s *String) int64 {
	return Long_ParseUnsignedLong_String_I__J(s, 10)
}
func Long_ValueOf_String_I__Long(s *String, radix int32) *Long {
	return Long_ValueOf_J__Long(Long_ParseLong_String_I__J(s, radix))
}
func Long_ValueOf_String__Long(s *String) *Long {
	return Long_ValueOf_J__Long(Long_ParseLong_String_I__J(s, 10))
}

func Long_LongCache_New() *Long_LongCache { Long_LongCache_Init(); t := &Long_LongCache{}; t.Ctor(); return t }
//line :327:1
func (t *Long_LongCache) Ctor() { panic(A2g_NotTranslated("java.lang.Long$LongCache.<init>()V")) }



















func Long_ValueOf_J__Long(l int64) *Long {

	var tmp1 bool; var tmp2 bool; tmp2 = l >= -128; if tmp2 { tmp2 = l <= 127 }; tmp1 = tmp2; if tmp1 {
		var tmp3 *RefArray; Long_LongCache_Init(); tmp3 = Long_LongCache_cache; return As[*Long](tmp3.A[int32(l)+128]) } else {
			return Long_New_J(l)
		} }
func Long_Decode_String__Long(nm *String) *Long { var tmp1 int64; var radix int32 = 10; var index int32 = 0; var negative bool = false; var result int64 = 0; if




	NN(nm).IsEmpty__Z() { panic(Thrown(NumberFormatException_New_String(Lit_1129))) }; var firstChar uint16 =
	NN(nm).CharAt_I__C(0); if
	int32(firstChar) == 45 {
		negative = true; index = index + 1 } else {
//line :360:1
			if int32(firstChar) == 43 {

				index = index + 1 } }; var tmp2 bool; var tmp3 bool; tmp3 =

	NN(nm).StartsWith_String_I__Z(Lit_1130, index); if !tmp3 { tmp3 = NN(nm).StartsWith_String_I__Z(Lit_1131, index) }; tmp2 = tmp3; if tmp2 {
		index = index + 2; radix = 16 } else {
//line :363:1
			if NN(nm).StartsWith_String_I__Z(Lit_1132, index) {


				index = index + 1; radix = 16 } else {

					var tmp4 bool; var tmp5 bool; tmp5 = NN(nm).StartsWith_String_I__Z(Lit_1133, index); if tmp5 { tmp5 = NN(nm).Length__I() > 1+index }; tmp4 = tmp5; if tmp4 {
						index = index + 1
						radix = 8 } } }; var tmp6 bool; var tmp7 bool; tmp7 =
	NN(nm).StartsWith_String_I__Z(Lit_1134, index); if !tmp7 { tmp7 = NN(nm).StartsWith_String_I__Z(Lit_1135, index) }; tmp6 = tmp7; if tmp6 {
		panic(Thrown(NumberFormatException_New_String(Lit_1136))) }; tmp9 := func() (exc Throwable_I) { defer Catch(&exc)

			result = Long_ParseLong_CharSequence_I_I_I__J(Up_String_CharSequence(nm), index, NN(nm).Length__I(), radix)
			{ var tmp8 int64; if negative { tmp8 = -result } else { tmp8 = result }; result = tmp8 }; return nil }(); if /*line :373:1*/ tmp9 != nil { if NumberFormatException_InstanceOf(tmp9) { var e *NumberFormatException = NumberFormatException_Cast(tmp9); var constant *String; _ = e



				if negative {
					constant = Concat(Lit_1134, NN(nm).Substring_I__String(index)) } else {
						constant = NN(nm).Substring_I__String(index) }
				result = Long_ParseLong_String_I__J(constant, radix) } else {
//line :373:1
					panic(tmp9) } }; tmp1 = result; return /*line :353:1*/ Long_ValueOf_J__Long(tmp1) }































func Long_New_J(p0 int64) *Long { Long_Init(); t := &Long{}; t.Ctor_J(p0); return t }
//line :385:1
func (t *Long) Ctor_J(value int64) { t.Number.Ctor(t)
	t.F_value = value
}
func Long_New_String(p0 *String) *Long { Long_Init(); t := &Long{}; t.Ctor_String(p0); return t }
//line :388:1
func (t *Long) Ctor_String(s *String) { t.Number.Ctor(t)
	t.F_value = Long_ParseLong_String_I__J(s, 10)
}
func (t *Long) ByteValue__B() int8 { return int8(t.F_value) }

func (t *Long) ShortValue__S() int16 { return int16(t.F_value) }

func (t *Long) IntValue__I() int32 { return int32(t.F_value) }

func (t *Long) LongValue__J() int64 { return t.F_value }


func (t *Long) FloatValue__F() float32 { return float32(t.F_value) }

func (t *Long) DoubleValue__D() float64 { return float64(t.F_value) }

func (t *Long) ToString__String() *String { return Long_ToString_J__String(t.F_value) }

func (t *Long) HashCode__I() int32 { return Long_HashCode_J__I(t.F_value) }

func Long_HashCode_J__I(value int64) int32 {
	return int32(value ^ int64(uint64(value)>>32))
}
func (t *Long) Equals_O__Z(obj any) bool {
	var tmp1 any = obj; if Long_InstanceOf(tmp1) { var ell *Long = Long_Cast(tmp1); var tmp2 int64 = t.F_value; return tmp2 == NN(ell).LongValue__J() } else { return false
	} }
func Long_GetLong_String__Long(nm *String) *Long {
	return Long_GetLong_String_Long__Long(nm, nil)
}
func Long_GetLong_String_J__Long(nm *String, val int64) *Long {
	var result *Long = Long_GetLong_String_Long__Long(nm, nil); if result == nil { return Long_ValueOf_J__Long(val) } else { return result
	} }
func Long_GetLong_String_Long__Long(nm *String, val *Long) *Long {
	var v *String; var tmp1 bool; var tmp2 bool; tmp2 = !(nm == nil); if tmp2 { tmp2 = !NN(nm).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 { v = System_GetProperty_String__String(nm) } else { v = nil }
	if !(v == nil) { tmp3, tmp4, tmp5 := func() (ctl int32, rv *Long, exc Throwable_I) { defer Catch(&exc); return 2, Long_Decode_String__Long(v), nil; return 0, nil, nil }(); if tmp5 != nil { if NumberFormatException_InstanceOf(tmp5) { var e *NumberFormatException = NumberFormatException_Cast(tmp5); _ = e } else { panic(tmp5) } }; switch tmp3 { case 2: { return tmp4 }} }
//line :421:1
	return val
}


func (t *Long) CompareTo_Long__I(anotherLong *Long) int32 {
	var tmp1 int64 = t.F_value; return Long_Compare_J_J__I(tmp1, anotherLong.F_value)
}
func Long_Compare_J_J__I(x, y int64) int32 {
	if x < y { return -1 } else { if x == y { return 0 } else { return 1
	} } }
func Long_CompareUnsigned_J_J__I(x, y int64) int32 {
	return Long_Compare_J_J__I(x+-9223372036854775808, y+-9223372036854775808)
}
func Long_DivideUnsigned_J_J__J(dividend, divisor int64) int64 {

	if divisor >= 0 {
		var q int64 = int64(uint64(dividend)>>1) / divisor << 1; var r int64 = dividend - q*divisor

		return q + int64(uint64(r|^(r-divisor))>>63) } else {



			return int64(uint64(dividend & ^(dividend-divisor)) >> 63)
		}
}
func Long_RemainderUnsigned_J_J__J(dividend, divisor int64) int64 {

	if divisor >= 0 {
		var q int64 = int64(uint64(dividend)>>1) / divisor << 1; var r int64 = dividend - q*divisor

		return r - ^(r-divisor)>>63&divisor } else {




			return dividend - dividend & ^(dividend-divisor) >> 63 & divisor
		}
}








func Long_HighestOneBit_J__J(i int64) int64 {
	return i & int64(uint64(9223372036854775808)>>(Long_NumberOfLeadingZeros_J__I(i)&63))
}
func Long_LowestOneBit_J__J(i int64) int64 {
	return i & -i
}
func Long_NumberOfLeadingZeros_J__I(i int64) int32 {
	var x int32 = int32(int64(uint64(i) >> 32))
	if x == 0 {
		return 32 + Integer_NumberOfLeadingZeros_I__I(int32(i)) } else {
			return Integer_NumberOfLeadingZeros_I__I(x)
		} }
func Long_NumberOfTrailingZeros_J__I(i int64) int32 {
	var x int32 = int32(i)
	if x == 0 {
		return 32 + Integer_NumberOfTrailingZeros_I__I(int32(int64(uint64(i)>>32))) } else {


			return Integer_NumberOfTrailingZeros_I__I(x)
		} }
func Long_BitCount_J__I(i int64) int32 {
	i = i - int64(uint64(i)>>1)&6148914691236517205
	i = i&3689348814741910323 + int64(uint64(i)>>2)&3689348814741910323


	i = (i + int64(uint64(i)>>4)) & 1085102592571150095
	i = i + int64(uint64(i)>>8)
	i = i + int64(uint64(i)>>16)
	i = i + int64(uint64(i)>>32)
	return int32(i) & 127
}
func Long_RotateLeft_J_I__J(i int64, distance int32) int64 {
	return i<<(distance&63) | int64(uint64(i)>>(-distance&63))
}

func Long_RotateRight_J_I__J(i int64, distance int32) int64 {
	return int64(uint64(i)>>(distance&63)) | i<<(-distance&63)
}

func Long_Reverse_J__J(i int64) int64 {
	i = i&6148914691236517205<<1 | int64(uint64(i)>>1)&6148914691236517205


	i = i&3689348814741910323<<2 | int64(uint64(i)>>2)&3689348814741910323


	i = i&1085102592571150095<<4 | int64(uint64(i)>>4)&1085102592571150095


	return Long_ReverseBytes_J__J(i)
}
func Long_Compress_J_J__J(i, mask int64) int64 {

	i = i & mask
	var maskCount int64 = ^mask << 1; var j int32 = 0
L1: for {
	if j < 6 {
		var maskPrefix int64 = Long_ParallelSuffix_J__J(maskCount); var maskMove int64 = maskPrefix & mask

		mask = mask ^ maskMove | int64(uint64(maskMove)>>(1<<(j&31)&63))


		var t_ int64 = i & maskMove
		i = i ^ t_ | int64(uint64(t_)>>(1<<(j&31)&63))
		maskCount = maskCount & ^maskPrefix
		j = j + 1; continue L1 }
//line :522:1
	break L1 }
//line :521:1
	return i
}












func Long_Expand_J_J__J(i, mask int64) int64 {

	var originalMask int64 = mask; var maskCount int64 = ^mask << 1; var maskPrefix int64 = Long_ParallelSuffix_J__J(maskCount); var maskMove1 int64 = maskPrefix & mask



	mask = mask ^ maskMove1 | int64(uint64(maskMove1)>>1)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Long_ParallelSuffix_J__J(maskCount)
	var maskMove2 int64 = maskPrefix & mask
	mask = mask ^ maskMove2 | int64(uint64(maskMove2)>>2)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Long_ParallelSuffix_J__J(maskCount)
	var maskMove3 int64 = maskPrefix & mask
	mask = mask ^ maskMove3 | int64(uint64(maskMove3)>>4)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Long_ParallelSuffix_J__J(maskCount)
	var maskMove4 int64 = maskPrefix & mask
	mask = mask ^ maskMove4 | int64(uint64(maskMove4)>>8)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Long_ParallelSuffix_J__J(maskCount)
	var maskMove5 int64 = maskPrefix & mask
	mask = mask ^ maskMove5 | int64(uint64(maskMove5)>>16)


	maskCount = maskCount & ^maskPrefix
	maskPrefix = Long_ParallelSuffix_J__J(maskCount)
	var maskMove6 int64 = maskPrefix & mask; var t_ int64 = i << 32

	i = i & ^maskMove6 | t_&maskMove6
	t_ = i << 16
	i = i & ^maskMove5 | t_&maskMove5
	t_ = i << 8
	i = i & ^maskMove4 | t_&maskMove4
	t_ = i << 4
	i = i & ^maskMove3 | t_&maskMove3
	t_ = i << 2
	i = i & ^maskMove2 | t_&maskMove2
	t_ = i << 1
	i = i & ^maskMove1 | t_&maskMove1
	return i & originalMask
}
func Long_ParallelSuffix_J__J(maskCount int64) int64 {
	var maskPrefix int64 = maskCount ^ maskCount<<1
	maskPrefix = maskPrefix ^ maskPrefix<<2
	maskPrefix = maskPrefix ^ maskPrefix<<4
	maskPrefix = maskPrefix ^ maskPrefix<<8
	maskPrefix = maskPrefix ^ maskPrefix<<16
	maskPrefix = maskPrefix ^ maskPrefix<<32
//line :586:1
	return maskPrefix
}






func Long_Signum_J__I(i int64) int32 {
	return int32(i>>63 | int64(uint64(-i)>>63))
}

func Long_ReverseBytes_J__J(i int64) int64 {
	i = i&71777214294589695<<8 | int64(uint64(i)>>8)&71777214294589695


	return i<<48 | i&4294901760<<16 | int64(uint64(i)>>16)&4294901760 | int64(uint64(i)>>48)
}


func Long_Sum_J_J__J(a, b int64) int64 {
	return a + b
}
func Long_Max_J_J__J(a, b int64) int64 { return Math_Max_J_J__J(a, b) }

func Long_Min_J_J__J(a, b int64) int64 { return Math_Min_J_J__J(a, b) }

func (t *Long) DescribeConstable__Optional() *Optional {
	return Optional_Of_O__Optional(t)
}


type Long struct{ Number; F_value int64 }

func (t *Long) Is_Comparable() {}

func (t *Long) Is_Constable() {}

func (t *Long) Is_ConstantDesc() {}

const Long_MIN_VALUE int64 = -9223372036854775808

const Long_MAX_VALUE int64 = 9223372036854775807

var Long_TYPE *Class

const Long_SIZE int32 = 64

const Long_BYTES int32 = 8

const Long_serialVersionUID int64 = 4290774380558885855

var Long_init ClassInit

func Long_Init() { if !Long_init.Done() { Long_init.Run(Long_clinit) } }

func Long_clinit() { Long_TYPE = Class_GetPrimitiveClass_String__Class(Lit_1138) }

func (t *Long) CompareTo_O__I(p0 any) int32 { return t.CompareTo_Long__I(Long_Cast(p0)) }

func (t *Long) Ref() any { if t == nil { return nil }; return t }

func (t *Long) GetClass__Class() *Class { return Long_class }

func (t *Long) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Long) CloneShallow() any { panic(CloneNotSupported(t)) }

func Long_InstanceOf(x any) bool { _, ok := x.(*Long); return ok }

func Long_Cast(x any) *Long { if x == nil { return nil }; v, ok := x.(*Long); if !ok { panic(ClassCast(x, Long_class)) }; return v }



type Long_LongCache struct{ Object }

var Long_LongCache_cache *RefArray

var Long_LongCache_archivedCache *RefArray

var Long_LongCache_init ClassInit

func Long_LongCache_Init() { if !Long_LongCache_init.Done() { Long_LongCache_init.Run(Long_LongCache_clinit) } }

func Long_LongCache_clinit() {
//line :334:1
	var size int32 = 256
	CDS_InitializeFromArchive_Class__V(Long_LongCache_class)
	if Long_LongCache_archivedCache == nil {
		var c *RefArray = NewRefArray(Long_class, size)
		var value int64 = -128; var i int32 = 0
	L1: for {
		if i < size {
			var tmp1 int64; var old_9 int64 = value; value = value + 1; tmp1 = old_9; c.Store(i, Long_New_J(tmp1))
			i = i + 1; continue L1 }
//line :339:1
		break L1
	}


		Long_LongCache_archivedCache = c }
	Long_LongCache_cache = Long_LongCache_archivedCache
	if !A2g_AssertionsDisabled && !(int32(len(Long_LongCache_cache.A)) == size) { panic(Thrown(AssertionError_New()))
	}
}




































































































































































































































































































































func (t *Long_LongCache) Ref() any { if t == nil { return nil }; return t }

func (t *Long_LongCache) GetClass__Class() *Class { return Long_LongCache_class }

func (t *Long_LongCache) ToString__String() *String { return Object_toString(t) }

func (t *Long_LongCache) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Long_LongCache) CloneShallow() any { panic(CloneNotSupported(t)) }

func Long_LongCache_InstanceOf(x any) bool { _, ok := x.(*Long_LongCache); return ok }

func Long_LongCache_Cast(x any) *Long_LongCache { if x == nil { return nil }; v, ok := x.(*Long_LongCache); if !ok { panic(ClassCast(x, Long_LongCache_class)) }; return v }
