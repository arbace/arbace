//line java_time_zone_ZoneOffsetTransition.ae:1
package jrt

























func ZoneOffsetTransition_Of_LocalDateTime_ZoneOffset_ZoneOffset__ZoneOffsetTransition(transition *LocalDateTime, offsetBefore, offsetAfter *ZoneOffset) *ZoneOffsetTransition { ZoneOffsetTransition_Init()


	Objects_RequireNonNull_O_String__O(transition.Ref(), Lit_2552)
	Objects_RequireNonNull_O_String__O(offsetBefore.Ref(), Lit_2553)
	Objects_RequireNonNull_O_String__O(offsetAfter.Ref(), Lit_2554)
	if NN(offsetBefore).Equals_O__Z(offsetAfter.Ref()) {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2555))) }
	if NN(transition).GetNano__I() == 0 { } else {
		panic(Thrown(IllegalArgumentException_New_String(Lit_2556))) }
	return ZoneOffsetTransition_New_LocalDateTime_ZoneOffset_ZoneOffset(transition, offsetBefore, offsetAfter)
}
func ZoneOffsetTransition_New_LocalDateTime_ZoneOffset_ZoneOffset(p0 *LocalDateTime, p1, p2 *ZoneOffset) *ZoneOffsetTransition { ZoneOffsetTransition_Init(); t := &ZoneOffsetTransition{}; t.Ctor_LocalDateTime_ZoneOffset_ZoneOffset(p0, p1, p2); return t }
//line :39:1
func (t *ZoneOffsetTransition) Ctor_LocalDateTime_ZoneOffset_ZoneOffset(transition *LocalDateTime, offsetBefore, offsetAfter *ZoneOffset) {
	if !A2g_AssertionsDisabled && !(NN(transition).GetNano__I() == 0) { panic(Thrown(AssertionError_New())) }
	t.F_epochSecond = NN(transition).ToEpochSecond_ZoneOffset__J(offsetBefore)
	t.F_transition = transition
	t.F_offsetBefore = offsetBefore
	t.F_offsetAfter = offsetAfter
}
func ZoneOffsetTransition_New_J_ZoneOffset_ZoneOffset(p0 int64, p1, p2 *ZoneOffset) *ZoneOffsetTransition { ZoneOffsetTransition_Init(); t := &ZoneOffsetTransition{}; t.Ctor_J_ZoneOffset_ZoneOffset(p0, p1, p2); return t }
//line :46:1
func (t *ZoneOffsetTransition) Ctor_J_ZoneOffset_ZoneOffset(epochSecond int64, offsetBefore, offsetAfter *ZoneOffset) {
	t.F_epochSecond = epochSecond
	t.F_transition = LocalDateTime_OfEpochSecond_J_I_ZoneOffset__LocalDateTime(epochSecond, 0, offsetBefore)
	t.F_offsetBefore = offsetBefore
	t.F_offsetAfter = offsetAfter
}



func (t *ZoneOffsetTransition) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.zone.ZoneOffsetTransition.writeReplace()Ljava/lang/Object;")) }






func ZoneOffsetTransition_ReadExternal_DataInput__ZoneOffsetTransition(in DataInput) *ZoneOffsetTransition { ZoneOffsetTransition_Init()
	var epochSecond int64 = Ser_ReadEpochSec_DataInput__J(in); var before *ZoneOffset = Ser_ReadOffset_DataInput__ZoneOffset(in); var after *ZoneOffset = Ser_ReadOffset_DataInput__ZoneOffset(in)


	if NN(before).Equals_O__Z(after.Ref()) { panic(Thrown(IllegalArgumentException_New_String(Lit_2555))) }
	return ZoneOffsetTransition_New_J_ZoneOffset_ZoneOffset(epochSecond, before, after)
}
func (t *ZoneOffsetTransition) GetInstant__Instant() *Instant {
	return Instant_OfEpochSecond_J__Instant(t.F_epochSecond)
}
func (t *ZoneOffsetTransition) ToEpochSecond__J() int64 { return t.F_epochSecond }

func (t *ZoneOffsetTransition) GetDateTimeBefore__LocalDateTime() *LocalDateTime { return t.F_transition }

func (t *ZoneOffsetTransition) GetDateTimeAfter__LocalDateTime() *LocalDateTime {
	var tmp1 *LocalDateTime = t.F_transition; return NN(tmp1).PlusSeconds_J__LocalDateTime(int64(t.GetDurationSeconds__I()))
}
func (t *ZoneOffsetTransition) GetOffsetBefore__ZoneOffset() *ZoneOffset { return t.F_offsetBefore }

func (t *ZoneOffsetTransition) GetOffsetAfter__ZoneOffset() *ZoneOffset { return t.F_offsetAfter }

func (t *ZoneOffsetTransition) GetDuration__Duration() *Duration {
	return Duration_OfSeconds_J__Duration(int64(t.GetDurationSeconds__I()))
}
func (t *ZoneOffsetTransition) GetDurationSeconds__I() int32 {
	return NN(t.GetOffsetAfter__ZoneOffset()).GetTotalSeconds__I() - NN(t.GetOffsetBefore__ZoneOffset()).GetTotalSeconds__I()
}

func (t *ZoneOffsetTransition) IsGap__Z() bool {
	return NN(t.GetOffsetAfter__ZoneOffset()).GetTotalSeconds__I() > NN(t.GetOffsetBefore__ZoneOffset()).GetTotalSeconds__I()
}
func (t *ZoneOffsetTransition) IsOverlap__Z() bool {
	return NN(t.GetOffsetAfter__ZoneOffset()).GetTotalSeconds__I() < NN(t.GetOffsetBefore__ZoneOffset()).GetTotalSeconds__I()
}
func (t *ZoneOffsetTransition) IsValidOffset_ZoneOffset__Z(offset *ZoneOffset) bool {
	if t.IsGap__Z() { return false } else {

		var tmp1 bool; tmp1 = NN(t.GetOffsetBefore__ZoneOffset()).Equals_O__Z(offset.Ref()); if !tmp1 { tmp1 = NN(t.GetOffsetAfter__ZoneOffset()).Equals_O__Z(offset.Ref()) }; return tmp1
	} }
func (t *ZoneOffsetTransition) GetValidOffsets__List() List {
	if t.IsGap__Z() { return List_Of__List() } else { return List_Of_O_O__List(t.GetOffsetBefore__ZoneOffset().Ref(), t.GetOffsetAfter__ZoneOffset().Ref())
	} }
func (t *ZoneOffsetTransition) CompareTo_ZoneOffsetTransition__I(otherTransition *ZoneOffsetTransition) int32 {
	var tmp1 int64 = t.F_epochSecond; return Long_Compare_J_J__I(tmp1, otherTransition.F_epochSecond)
}
func (t *ZoneOffsetTransition) Equals_O__Z(other any) bool {
	if any(other) == any(t) { return true } else {

		var tmp1 any = other; if ZoneOffsetTransition_InstanceOf(tmp1) { var d *ZoneOffsetTransition = ZoneOffsetTransition_Cast(tmp1); var tmp2 int64 = t.F_epochSecond
			if tmp2 == d.F_epochSecond {
				var tmp3 *ZoneOffset = t.F_offsetBefore; if NN(tmp3).Equals_O__Z(d.F_offsetBefore.Ref()) {
					var tmp4 *ZoneOffset = t.F_offsetAfter; return NN(tmp4).Equals_O__Z(d.F_offsetAfter.Ref()) } else {
//line :112:1
						return false } } else {
//line :111:1
							return false
						} } else {
//line :110:1
							return false
						}
	}
}




func (t *ZoneOffsetTransition) HashCode__I() int32 {
	return NN(t.F_transition).HashCode__I() ^ NN(t.F_offsetBefore).HashCode__I() ^ Integer_RotateLeft_I_I__I(NN(t.F_offsetAfter).HashCode__I(), 16)
}

func (t *ZoneOffsetTransition) ToString__String() *String {
	var buf *StringBuilder = StringBuilder_New(); var tmp1 *StringBuilder = NN(buf).Append_String__StringBuilder(Lit_2557); var tmp2 *String




	if t.IsGap__Z() { tmp2 = Lit_2558 } else { tmp2 = Lit_2559 }
//line :124:1
	NN(NN(NN(NN(NN(NN(NN(tmp1).Append_String__StringBuilder(tmp2)).Append_String__StringBuilder(Lit_2560)).Append_O__StringBuilder(t.F_transition.Ref())).Append_O__StringBuilder(t.F_offsetBefore.Ref())).Append_String__StringBuilder(Lit_2561)).Append_O__StringBuilder(t.F_offsetAfter.Ref())).Append_C__StringBuilder(93)










	return NN(buf).ToString__String()
}


type ZoneOffsetTransition struct{ Object; F_epochSecond int64; F_transition *LocalDateTime; F_offsetBefore, F_offsetAfter *ZoneOffset }

func (t *ZoneOffsetTransition) Is_Comparable() {}

func (t *ZoneOffsetTransition) Is_Serializable() {}

const ZoneOffsetTransition_serialVersionUID int64 = -6946044323557704546

var ZoneOffsetTransition_init ClassInit

func ZoneOffsetTransition_Init() { if !ZoneOffsetTransition_init.Done() { ZoneOffsetTransition_init.Run(ZoneOffsetTransition_clinit) } }

func ZoneOffsetTransition_clinit() {}

func (t *ZoneOffsetTransition) CompareTo_O__I(p0 any) int32 { return t.CompareTo_ZoneOffsetTransition__I(ZoneOffsetTransition_Cast(p0)) }

func (t *ZoneOffsetTransition) Ref() any { if t == nil { return nil }; return t }

func (t *ZoneOffsetTransition) GetClass__Class() *Class { return ZoneOffsetTransition_class }

func (t *ZoneOffsetTransition) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ZoneOffsetTransition) CloneShallow() any { panic(CloneNotSupported(t)) }

func ZoneOffsetTransition_InstanceOf(x any) bool { _, ok := x.(*ZoneOffsetTransition); return ok }

func ZoneOffsetTransition_Cast(x any) *ZoneOffsetTransition { if x == nil { return nil }; v, ok := x.(*ZoneOffsetTransition); if !ok { panic(ClassCast(x, ZoneOffsetTransition_class)) }; return v }
