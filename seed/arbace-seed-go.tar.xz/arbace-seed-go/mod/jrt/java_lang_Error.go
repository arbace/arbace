//line java_lang_Error.ae:1
package jrt










func Error_New() *Error { t := &Error{}; t.Ctor(t); return t }
//line :12:1
func (t *Error) Ctor(this Error_I) { t.Throwable.Ctor(this)

	if Throwable_jfrTracing { ThrowableTracer_TraceError_Class_String__V(this.GetClass__Class(), nil)
	} }
func Error_New_String(p0 *String) *Error { t := &Error{}; t.Ctor_String(t, p0); return t }
//line :16:1
func (t *Error) Ctor_String(this Error_I, message *String) { t.Throwable.Ctor_String(this, message)

	if Throwable_jfrTracing { ThrowableTracer_TraceError_Class_String__V(this.GetClass__Class(), message)
	} }
func Error_New_String_Throwable(p0 *String, p1 Throwable_I) *Error { t := &Error{}; t.Ctor_String_Throwable(t, p0, p1); return t }
//line :20:1
func (t *Error) Ctor_String_Throwable(this Error_I, message *String, cause Throwable_I) { t.Throwable.Ctor_String_Throwable(this, message, cause)

	if Throwable_jfrTracing { ThrowableTracer_TraceError_Class_String__V(this.GetClass__Class(), message)
	} }
func Error_New_Throwable(p0 Throwable_I) *Error { t := &Error{}; t.Ctor_Throwable(t, p0); return t }
//line :24:1
func (t *Error) Ctor_Throwable(this Error_I, cause Throwable_I) { t.Throwable.Ctor_Throwable(this, cause)

	if Throwable_jfrTracing { ThrowableTracer_TraceError_Class_String__V(this.GetClass__Class(), nil)
	} }
func Error_New_String_Throwable_Z_Z(p0 *String, p1 Throwable_I, p2, p3 bool) *Error { t := &Error{}; t.Ctor_String_Throwable_Z_Z(t, p0, p1, p2, p3); return t }
//line :28:1
func (t *Error) Ctor_String_Throwable_Z_Z(this Error_I, message *String, cause Throwable_I, enableSuppression, writableStackTrace bool) { t.Throwable.Ctor_String_Throwable_Z_Z(this, message, cause, enableSuppression, writableStackTrace)


	if Throwable_jfrTracing { ThrowableTracer_TraceError_Class_String__V(this.GetClass__Class(), message)
	}
}
type Error struct{ Throwable }

type Error_I interface{ Throwable_I; Serializable; Self_Error() *Error }

func (t *Error) Self_Error() *Error { return t }

const Error_serialVersionUID int64 = 4980196508277280342

func (t *Error) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *Error) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *Error) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *Error) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *Error) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *Error) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *Error) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *Error) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *Error) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *Error) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *Error) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *Error) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Error) Ref() any { if t == nil { return nil }; return t }

func (t *Error) GetClass__Class() *Class { return Error_class }

func (t *Error) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Error) CloneShallow() any { panic(CloneNotSupported(t)) }

func Error_InstanceOf(x any) bool { _, ok := x.(Error_I); return ok }

func Error_Cast(x any) Error_I { if x == nil { return nil }; v, ok := x.(Error_I); if !ok { panic(ClassCast(x, Error_class)) }; return v }
