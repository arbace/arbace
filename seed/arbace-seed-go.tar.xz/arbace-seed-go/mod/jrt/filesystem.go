//line filesystem.ae:1
package jrt

import (
	"errors"
	"io/fs"
	"os"
	"strings"
)




const (
	baExists    int32 = 1
	baRegular   int32 = 2
	baDirectory int32 = 4
	spaceTotal  int32 = 0
	spaceFree   int32 = 1
	spaceUsable int32 = 2)
// unixPerm is the Unix permission bits (07777) of a HostFileInfo's Mode (an fs.FileMode).
func unixPerm(mode uint32) uint32 {


	m := fs.FileMode(mode)
	p := uint32(m & fs.ModePerm)
	if m&fs.ModeSetuid != 0 { p = p | 2048 }
	if m&fs.ModeSetgid != 0 { p = p | 1024 }
	if m&fs.ModeSticky != 0 { p = p | 512
	}; return p }
// hostChmod is chmod(2) through the host's HostFS (false without one).
func hostChmod(name string, mode uint32) bool {

	hfs := CurrentHostFS()
	return hfs != nil && hfs.Chmod(name, mode) == nil
}

// collapsePath is path_util.c's collapse: the names . removed, and each .. with the name
// before it (a leading .. of an absolute path removed, of a relative one kept).
func collapsePath(path string) string {



	abs := strings.HasPrefix(path, "/")
	names := path
	if abs {
		names = path[1:] }
	if names == "" {
		return path }
	ix := strings.Split(names, "/")
	dots := false
	for _, n := range ix {
		if n == "." || n == ".." {
			dots = true } }
	if !dots || len(ix) < 2 {
		return path }
	keep := make([]bool, len(ix))
	for i, _ := range ix {
		keep[i] = true }
	for i, n := range ix {
		if
			n == "." { keep[i] = false
			} else if n == ".." {
				j := i - 1
				for j >= 0 && !keep[j] {
					j-- }
				if j < 0 {
					if abs {
						keep[i] = false } } else {
							keep[j] = false
							keep[i] = false } } }
	out := make([]string, 0, len(ix))
	for i, n := range ix {
		if keep[i] {
			out = append(out, n) } }
	r := strings.Join(out, "/")
	if abs {
		return "/" + r }; return r }
// skippable tells a realpath error that canonicalize_md.c passes over (ENOENT, ENOTDIR,
// EACCES: HostFS.Realpath's fs.ErrNotExist and fs.ErrPermission).
func skippable(err error) bool {



	return errors.Is(err, fs.ErrNotExist) || errors.Is(err, fs.ErrPermission) }
// canonicalizePath is JDK_Canonicalize: realpath of the whole path, else of its longest
// prefix that resolves, the rest appended; . and .. collapsed. Without a HostFS, the path
// collapsed.
//line :86:1
func canonicalizePath(orig string) (string, error) {




	hfs := CurrentHostFS()
	if hfs == nil {
		return collapsePath(orig), nil }
	r, err := hfs.Realpath(orig)
	if err == nil {
		return collapsePath(r), nil }
	p := len(orig)
	for p > 0 {

		p--
		for p > 0 && orig[p] != '/' {
			p-- }
		if p == 0 {
			break }
		r2, err2 := hfs.Realpath(orig[0:p])
		if err2 == nil {
			rest := orig[p:]
			if strings.HasSuffix(r2, "/") && strings.HasPrefix(rest, "/") {
				rest = rest[1:] }
			return collapsePath(r2 + rest), nil }
		if !skippable(err2) {
			return "", err2 } }
	return collapsePath(orig), nil
}

// UnixFileSystem_HostCanonicalize_String__String_native is canonicalize0: the canonical form
// of path, or an IOException (the system's reason, else "Bad pathname").
func UnixFileSystem_HostCanonicalize_String__String_native(path /*line :121:1*/*String) *String {
	r, err := canonicalizePath(NN(path).String())
	if err != nil {
		msg := fileErrorText(err)
		if msg == "" {
			msg = "Bad pathname" }
		panic(IOException_New_String(Str(msg))) }
	return Str(r) }
// UnixFileSystem_HostBooleanAttributes_String__I_native is getBooleanAttributes0: exists,
// regular, directory (stat(2), following links).
//line :130:1
func UnixFileSystem_HostBooleanAttributes_String__I_native(path /*line :133:1*/*String) int32 {
	fi, err := CurrentHost().Stat(NN(path).String())
	if err != nil {
		return 0 }
	var rv int32 = baExists
	if fi.IsDir { rv = rv | baDirectory
	} else if fs.FileMode(fi.Mode)&fs.ModeType == 0 { rv = rv | baRegular }; return rv }
// UnixFileSystem_HostCheckAccess_String_I__Z_native is checkAccess0: access(2) with
// FileSystem's ACCESS_READ (4), ACCESS_WRITE (2) or ACCESS_EXECUTE (1), which are R_OK, W_OK and
// X_OK. Without a HostFS, whether the file exists.
//line :142:1
func UnixFileSystem_HostCheckAccess_String_I__Z_native(path /*line :146:1*/*String, access int32) bool {
	name := NN(path).String()
	hfs := CurrentHostFS()
	if hfs == nil {
		_, err := CurrentHost().Stat(name)
		return err == nil }
	return hfs.Access(name, uint32(access)) == nil }
// UnixFileSystem_HostLastModifiedTime_String__J_native is getLastModifiedTime0: milliseconds
// since the epoch, 0 when the file cannot be read.
//line :154:1
func UnixFileSystem_HostLastModifiedTime_String__J_native(path /*line :157:1*/*String) int64 {
	fi, err := CurrentHost().Stat(NN(path).String())
	if err != nil {
		return 0 }
	return fi.ModTimeMillis }
// UnixFileSystem_HostLength_String__J_native is getLength0: the size, 0 when the file cannot
// be read.
//line :163:1
func UnixFileSystem_HostLength_String__J_native(path /*line :166:1*/*String) int64 {
	fi, err := CurrentHost().Stat(NN(path).String())
	if err != nil {
		return 0 }
	return fi.Size }
// UnixFileSystem_HostSetPermission_String_I_Z_Z__Z_native is setPermission0: the owner's
// bit of access, or everyone's, set or cleared with chmod(2).
//line :172:1
func UnixFileSystem_HostSetPermission_String_I_Z_Z__Z_native(path /*line :175:1*/*String, access int32, enable, owneronly bool) bool {
	name := NN(path).String()

	var amode uint32 = uint32(access) << 6
	if !owneronly {
		amode = amode | amode>>3 | amode>>6 }
	fi, err := CurrentHost().Stat(name)
	if err != nil {
		return false }
	mode := unixPerm(fi.Mode)
	if enable {
		mode = mode | amode } else {
			mode = mode &^ amode }
	return hostChmod(name, mode) }
// UnixFileSystem_HostCreateFileExclusively_String__Z_native is createFileExclusively0: the
// file created (O_CREAT|O_EXCL, 0666), false when it exists, an IOException otherwise.
//line :190:1
func UnixFileSystem_HostCreateFileExclusively_String__Z_native(path /*line :193:1*/*String) bool {
	name := NN(path).String()

	if name == "/" {
		return false }
	f, err := CurrentHost().Open(name, os.O_RDWR|os.O_CREATE|os.O_EXCL, 438)
	if err != nil {
		if errors.Is(err, fs.ErrExist) {
			return false }
		panic(IOException_New_String(Str(fileErrorText(err)))) }
	{ cerr := f.Close()
		if cerr != nil {
			panic(IOException_New_String(Str(fileErrorText(cerr)))) } }; return true }
// UnixFileSystem_HostDelete_String__Z_native is delete0: remove(3), a file or an empty
// directory.
func UnixFileSystem_HostDelete_String__Z_native(path /*line :211:1*/*String) bool {
	return CurrentHost().Remove(NN(path).String()) == nil }
// UnixFileSystem_HostList_String__String1_native is list0: the names of the directory's
// entries but . and .. (sorted: the host's ReadDir), null when it cannot be read.
//line :214:1
func UnixFileSystem_HostList_String__String1_native(path /*line :217:1*/*String) *RefArray {
	names, err := CurrentHost().ReadDir(NN(path).String())
	if err != nil {
		return nil }
	a := NewRefArray(String_class, int32(len(names)))
	for i, n := range names {
		a.A[i] = Str(n)
	}; return a }
// UnixFileSystem_HostCreateDirectory_String__Z_native is createDirectory0: mkdir(2), 0777.
func UnixFileSystem_HostCreateDirectory_String__Z_native(path /*line :228:1*/*String) bool {
	return CurrentHost().Mkdir(NN(path).String(), 511) == nil }
// UnixFileSystem_HostRename_String_String__Z_native is rename0: rename(2).
func UnixFileSystem_HostRename_String_String__Z_native(from, to /*line :233:1*/*String) bool {
	return CurrentHost().Rename(NN(from).String(), NN(to).String()) == nil }
// UnixFileSystem_HostSetLastModifiedTime_String_J__Z_native is setLastModifiedTime0: the
// modification time set, the access time kept.
//line :236:1
func UnixFileSystem_HostSetLastModifiedTime_String_J__Z_native(path /*line :239:1*/*String, time int64) bool {
	name := NN(path).String()
	_, err := CurrentHost().Stat(name)
	hfs := CurrentHostFS()
	return err == nil && hfs != nil && hfs.Chtimes(name, time) == nil }
// UnixFileSystem_HostSetReadOnly_String__Z_native is setReadOnly0: the write bits cleared.
func UnixFileSystem_HostSetReadOnly_String__Z_native(path /*line :247:1*/*String) bool {
	name := NN(path).String()
	fi, err := CurrentHost().Stat(name)
	if err != nil {
		return false }
	return hostChmod(name, unixPerm(fi.Mode)&^146) }
// UnixFileSystem_HostSpace_String_I__J_native is getSpace0: statvfs(3)'s total, free or
// usable bytes (SPACE_TOTAL, SPACE_FREE, SPACE_USABLE), 0 when it fails.
//line :254:1
func UnixFileSystem_HostSpace_String_I__J_native(path /*line :257:1*/*String, t int32) int64 {
	name := NN(path).String()
	hfs := CurrentHostFS()
	if hfs == nil {
		return 0 }
	st, err := hfs.Statfs(name)
	if err != nil {
		return 0 }
	switch t {
	case spaceTotal: return st.Total
	case spaceFree: return st.Free
	case spaceUsable: return st.Usable}; return 0 }
// UnixFileSystem_HostNameMax_String__J_native is getNameMax0: pathconf(3)'s _PC_NAME_MAX,
// else NAME_MAX (255).
func UnixFileSystem_HostNameMax_String__J_native(path /*line :274:1*/*String) int64 {
	hfs := CurrentHostFS()
	if hfs != nil {
		st, err := hfs.Statfs(NN(path).String())
		if err == nil && st.NameMax > 0 {
			return st.NameMax
		}
	}
	return 255
}
