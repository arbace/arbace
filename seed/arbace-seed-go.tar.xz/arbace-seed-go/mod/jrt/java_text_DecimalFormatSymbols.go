//line java_text_DecimalFormatSymbols.ae:1
package jrt

import "sync/atomic"












func DecimalFormatSymbols_New() *DecimalFormatSymbols { t := &DecimalFormatSymbols{}; t.Ctor(); return t }
//line :16:1
func (t *DecimalFormatSymbols) Ctor() { t.F_serialVersionOnStream = 5
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; t.Initialize_Locale__V(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DecimalFormatSymbols_New_Locale(p0 *Locale) *DecimalFormatSymbols { t := &DecimalFormatSymbols{}; t.Ctor_Locale(p0); return t }
//line :19:1
func (t *DecimalFormatSymbols) Ctor_Locale(locale *Locale) { t.F_serialVersionOnStream = 5
	t.Initialize_Locale__V(Locale_Cast(Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_1803)))
}
func DecimalFormatSymbols_GetAvailableLocales__Locale1() *RefArray {
	var pool *LocaleServiceProviderPool = LocaleServiceProviderPool_GetPool_Class__LocaleServiceProviderPool(DecimalFormatSymbolsProvider_class)
	return NN(pool).GetAvailableLocales__Locale1()
}
func DecimalFormatSymbols_GetInstance__DecimalFormatSymbols() *DecimalFormatSymbols {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_FORMAT; return DecimalFormatSymbols_GetInstance_Locale__DecimalFormatSymbols(Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func DecimalFormatSymbols_GetInstance_Locale__DecimalFormatSymbols(locale *Locale) *DecimalFormatSymbols {
	Objects_RequireNonNull_O_String__O(locale.Ref(), Lit_1803)
	var adapter LocaleProviderAdapter_I
	adapter = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(DecimalFormatSymbolsProvider_class, locale)
	var provider DecimalFormatSymbolsProvider_I = adapter.GetDecimalFormatSymbolsProvider__DecimalFormatSymbolsProvider(); var dfsyms *DecimalFormatSymbols = provider.GetInstance_Locale__DecimalFormatSymbols(locale)

	if dfsyms == nil {
		provider = LocaleProviderAdapter_ForJRE__LocaleProviderAdapter().GetDecimalFormatSymbolsProvider__DecimalFormatSymbolsProvider()
		dfsyms = provider.GetInstance_Locale__DecimalFormatSymbols(locale) }
//line :33:1
	return dfsyms
}





func (t *DecimalFormatSymbols) GetLocale__Locale() *Locale { return t.F_locale }

func (t *DecimalFormatSymbols) GetZeroDigit__C() uint16 { return t.F_zeroDigit }

func (t *DecimalFormatSymbols) SetZeroDigit_C__V(zeroDigit uint16) {
	t.F_hashCode.Store(0)
	t.F_zeroDigit = zeroDigit
}
func (t *DecimalFormatSymbols) GetGroupingSeparator__C() uint16 { return t.F_groupingSeparator }

func (t *DecimalFormatSymbols) SetGroupingSeparator_C__V(groupingSeparator uint16) {
	t.F_hashCode.Store(0)
	t.F_groupingSeparator = groupingSeparator
}
func (t *DecimalFormatSymbols) GetDecimalSeparator__C() uint16 { return t.F_decimalSeparator }

func (t *DecimalFormatSymbols) SetDecimalSeparator_C__V(decimalSeparator uint16) {
	t.F_hashCode.Store(0)
	t.F_decimalSeparator = decimalSeparator
}
func (t *DecimalFormatSymbols) GetPerMill__C() uint16 { return t.F_perMill }

func (t *DecimalFormatSymbols) SetPerMill_C__V(perMill uint16) {
	t.F_hashCode.Store(0)
	t.F_perMill = perMill
	t.F_perMillText = Character_ToString_C__String(perMill)
}
func (t *DecimalFormatSymbols) GetPercent__C() uint16 { return t.F_percent }

func (t *DecimalFormatSymbols) SetPercent_C__V(percent uint16) {
	t.F_hashCode.Store(0)
	t.F_percent = percent
	t.F_percentText = Character_ToString_C__String(percent)
}
func (t *DecimalFormatSymbols) GetDigit__C() uint16 { return t.F_digit }

func (t *DecimalFormatSymbols) SetDigit_C__V(digit uint16) {
	t.F_hashCode.Store(0)
	t.F_digit = digit
}
func (t *DecimalFormatSymbols) GetPatternSeparator__C() uint16 { return t.F_patternSeparator }

func (t *DecimalFormatSymbols) SetPatternSeparator_C__V(patternSeparator uint16) {
	t.F_hashCode.Store(0)
	t.F_patternSeparator = patternSeparator
}
func (t *DecimalFormatSymbols) GetInfinity__String() *String { return t.F_infinity }

func (t *DecimalFormatSymbols) SetInfinity_String__V(infinity *String) {
	t.F_infinity = String_Cast(Objects_RequireNonNull_O__O(infinity.Ref()))
	t.F_hashCode.Store(0)
}
func (t *DecimalFormatSymbols) GetNaN__String() *String { return t.F_NaN }

func (t *DecimalFormatSymbols) SetNaN_String__V(NaN_ *String) {
	t.F_NaN = String_Cast(Objects_RequireNonNull_O__O(NaN_.Ref()))
	t.F_hashCode.Store(0)
}
func (t *DecimalFormatSymbols) GetMinusSign__C() uint16 { return t.F_minusSign }

func (t *DecimalFormatSymbols) SetMinusSign_C__V(minusSign uint16) {
	t.F_hashCode.Store(0)
	t.F_minusSign = minusSign
	t.F_minusSignText = Character_ToString_C__String(minusSign)
}
func (t *DecimalFormatSymbols) GetCurrencySymbol__String() *String {
	t.InitializeCurrency_Locale__V(t.F_locale)
//line :105:1
	return t.F_currencySymbol
}


func (t *DecimalFormatSymbols) SetCurrencySymbol_String__V(currency *String) {
	Objects_RequireNonNull_O__O(currency.Ref())
	t.InitializeCurrency_Locale__V(t.F_locale)
	t.F_hashCode.Store(0)
	t.F_currencySymbol = currency
}
func (t *DecimalFormatSymbols) GetInternationalCurrencySymbol__String() *String {
	t.InitializeCurrency_Locale__V(t.F_locale)
//line :115:1
	return t.F_intlCurrencySymbol
}


func (t *DecimalFormatSymbols) SetInternationalCurrencySymbol_String__V(currencyCode *String) {
	Objects_RequireNonNull_O__O(currencyCode.Ref())
	t.InitializeCurrency_Locale__V(t.F_locale)
	t.F_hashCode.Store(0)
	t.F_intlCurrencySymbol = currencyCode; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		t.F_currency = Currency_GetInstance_String__Currency(currencyCode)
		t.F_currencySymbol = NN(t.F_currency).GetSymbol_Locale__String(t.F_locale); return nil }()
//line :124:1
	if tmp1 != nil { if IllegalArgumentException_InstanceOf(tmp1) { var __ IllegalArgumentException_I = IllegalArgumentException_Cast(tmp1); _ = __ } else { panic(tmp1)
	}
	}
}

func (t *DecimalFormatSymbols) GetCurrency__Currency() *Currency {
	t.InitializeCurrency_Locale__V(t.F_locale)
//line :129:1
	return t.F_currency
}


func (t *DecimalFormatSymbols) SetCurrency_Currency__V(currency *Currency) {
	Objects_RequireNonNull_O__O(currency.Ref())
	t.InitializeCurrency_Locale__V(t.F_locale)
	t.F_hashCode.Store(0)
	t.F_currency = currency
	t.F_intlCurrencySymbol = NN(currency).GetCurrencyCode__String()
	t.F_currencySymbol = NN(currency).GetSymbol_Locale__String(t.F_locale)
}
func (t *DecimalFormatSymbols) GetMonetaryDecimalSeparator__C() uint16 { return t.F_monetarySeparator }


func (t *DecimalFormatSymbols) SetMonetaryDecimalSeparator_C__V(sep uint16) {
	t.F_hashCode.Store(0)
	t.F_monetarySeparator = sep
}
func (t *DecimalFormatSymbols) GetExponentSeparator__String() *String { return t.F_exponentialSeparator }


func (t *DecimalFormatSymbols) SetExponentSeparator_String__V(exp *String) {
	Objects_RequireNonNull_O__O(exp.Ref())
	t.F_hashCode.Store(0)
	t.F_exponentialSeparator = exp
}
func (t *DecimalFormatSymbols) GetMonetaryGroupingSeparator__C() uint16 { return t.F_monetaryGroupingSeparator }


func (t *DecimalFormatSymbols) SetMonetaryGroupingSeparator_C__V(monetaryGroupingSeparator uint16) {
	t.F_hashCode.Store(0)
	t.F_monetaryGroupingSeparator = monetaryGroupingSeparator
}
func (t *DecimalFormatSymbols) GetExponentialSymbol__C() uint16 { panic(A2g_NotTranslated("java.text.DecimalFormatSymbols.getExponentialSymbol()C")) }

func (t *DecimalFormatSymbols) SetExponentialSymbol_C__V(p0 uint16) { panic(A2g_NotTranslated("java.text.DecimalFormatSymbols.setExponentialSymbol(C)V")) }


func (t *DecimalFormatSymbols) GetPerMillText__String() *String { return t.F_perMillText }

func (t *DecimalFormatSymbols) SetPerMillText_String__V(p0 *String) { panic(A2g_NotTranslated("java.text.DecimalFormatSymbols.setPerMillText(Ljava/lang/String;)V")) }






func (t *DecimalFormatSymbols) GetPercentText__String() *String { return t.F_percentText }

func (t *DecimalFormatSymbols) SetPercentText_String__V(p0 *String) { panic(A2g_NotTranslated("java.text.DecimalFormatSymbols.setPercentText(Ljava/lang/String;)V")) }






func (t *DecimalFormatSymbols) GetMinusSignText__String() *String { return t.F_minusSignText }

func (t *DecimalFormatSymbols) SetMinusSignText_String__V(p0 *String) { panic(A2g_NotTranslated("java.text.DecimalFormatSymbols.setMinusSignText(Ljava/lang/String;)V")) }






func (t *DecimalFormatSymbols) GetLenientMinusSigns__String() *String { return t.F_lenientMinusSigns }

func (t *DecimalFormatSymbols) Clone__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = DecimalFormatSymbols_Cast(A2g_ObjectClone(t)).Ref(); return nil }()
//line :198:1
	if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2)

		panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else {
//line :198:1
			panic(tmp2) } }; return tmp1
}


func (t *DecimalFormatSymbols) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else { var tmp1 bool; var tmp2 bool

		tmp2 = obj == nil; if !tmp2 { tmp2 = !(t.GetClass__Class() == GetClass(obj)) }; tmp1 = tmp2
//line :203:1
		if tmp1 { return false } else {



			var other *DecimalFormatSymbols = DecimalFormatSymbols_Cast(obj); var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 int32 = int32(t.F_zeroDigit)













			tmp21 = tmp22 == int32(other.F_zeroDigit)
//line :220:1
			if tmp21 {

				var tmp23 int32 = int32(t.F_groupingSeparator); tmp21 = tmp23 == int32(other.F_groupingSeparator) }
//line :220:1
			tmp20 = tmp21
//line :219:1
			if tmp20 {





				var tmp24 int32 = int32(t.F_decimalSeparator); tmp20 = tmp24 == int32(other.F_decimalSeparator) }
//line :219:1
			tmp19 = tmp20
//line :218:1
			if tmp19 {









				var tmp25 int32 = int32(t.F_percent); tmp19 = tmp25 == int32(other.F_percent) }
//line :218:1
			tmp18 = tmp19
//line :217:1
			if tmp18 {











				var tmp26 *String = t.F_percentText; tmp18 = NN(tmp26).Equals_O__Z(other.F_percentText.Ref()) }
//line :217:1
			tmp17 = tmp18
//line :216:1
			if tmp17 {















				var tmp27 int32 = int32(t.F_perMill); tmp17 = tmp27 == int32(other.F_perMill) }
//line :216:1
			tmp16 = tmp17
//line :215:1
			if tmp16 {

















				var tmp28 *String = t.F_perMillText; tmp16 = NN(tmp28).Equals_O__Z(other.F_perMillText.Ref()) }
//line :215:1
			tmp15 = tmp16
//line :214:1
			if tmp15 {



















				var tmp29 int32 = int32(t.F_digit); tmp15 = tmp29 == int32(other.F_digit) }
//line :214:1
			tmp14 = tmp15
//line :213:1
			if tmp14 {





















				var tmp30 int32 = int32(t.F_minusSign); tmp14 = tmp30 == int32(other.F_minusSign) }
//line :213:1
			tmp13 = tmp14
//line :212:1
			if tmp13 {























				var tmp31 *String = t.F_minusSignText; tmp13 = NN(tmp31).Equals_O__Z(other.F_minusSignText.Ref()) }
//line :212:1
			tmp12 = tmp13
//line :211:1
			if tmp12 {

























				var tmp32 int32 = int32(t.F_patternSeparator); tmp12 = tmp32 == int32(other.F_patternSeparator) }
//line :211:1
			tmp11 = tmp12
//line :210:1
			if tmp11 {



























				var tmp33 *String = t.F_infinity; tmp11 = NN(tmp33).Equals_O__Z(other.F_infinity.Ref()) }
//line :210:1
			tmp10 = tmp11
//line :209:1
			if tmp10 {





























				var tmp34 *String = t.F_NaN; tmp10 = NN(tmp34).Equals_O__Z(other.F_NaN.Ref()) }
//line :209:1
			tmp9 = tmp10
//line :208:1
			if tmp9 {































				tmp9 = NN(t.GetCurrencySymbol__String()).Equals_O__Z(NN(other).GetCurrencySymbol__String().Ref()) }
//line :208:1
			tmp8 = tmp9; if tmp8 {


































				var tmp35 *String = t.F_intlCurrencySymbol; tmp8 = NN(tmp35).Equals_O__Z(other.F_intlCurrencySymbol.Ref()) }
//line :208:1
			tmp7 = tmp8; if tmp7 {



































				var tmp36 *Currency = t.F_currency; tmp7 = tmp36 == other.F_currency }
//line :208:1
			tmp6 = tmp7; if tmp6 {




































				var tmp37 int32 = int32(t.F_monetarySeparator); tmp6 = tmp37 == int32(other.F_monetarySeparator) }
//line :208:1
			tmp5 = tmp6; if tmp5 {





































				var tmp38 int32 = int32(t.F_monetaryGroupingSeparator); tmp5 = tmp38 == int32(other.F_monetaryGroupingSeparator) }
//line :208:1
			tmp4 = tmp5; if tmp4 {






































				var tmp39 *String = t.F_exponentialSeparator; tmp4 = NN(tmp39).Equals_O__Z(other.F_exponentialSeparator.Ref()) }
//line :208:1
			tmp3 = tmp4; if tmp3 {







































				var tmp40 *Locale = t.F_locale; tmp3 = NN(tmp40).Equals_O__Z(other.F_locale.Ref()) }
//line :208:1
			return tmp3
		}
	}
}






































func (t *DecimalFormatSymbols) HashCode__I() int32 {
	if t.F_hashCode.Load() == 0 {
		var tmp1 any = Character_ValueOf_C__Character(t.F_zeroDigit); var tmp2 any = Character_ValueOf_C__Character(t.F_groupingSeparator); var tmp3 any = Character_ValueOf_C__Character(t.F_decimalSeparator); var tmp4 any = Character_ValueOf_C__Character(t.F_percent); var tmp5 any = t.F_percentText.Ref(); var tmp6 any = Character_ValueOf_C__Character(t.F_perMill); var tmp7 any = t.F_perMillText.Ref(); var tmp8 any = Character_ValueOf_C__Character(t.F_digit); var tmp9 any = Character_ValueOf_C__Character(t.F_minusSign); var tmp10 any = t.F_minusSignText.Ref(); var tmp11 any = Character_ValueOf_C__Character(t.F_patternSeparator); var tmp12 any = t.F_infinity.Ref(); var tmp13 any = t.F_NaN.Ref(); t.F_hashCode.Store(Objects_Hash_O1__I(RefArrayOf(Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, t.GetCurrencySymbol__String().Ref(), t.F_intlCurrencySymbol.Ref(), t.F_currency.Ref(), Character_ValueOf_C__Character(t.F_monetarySeparator), Character_ValueOf_C__Character(t.F_monetaryGroupingSeparator), t.F_exponentialSeparator.Ref(), t.F_locale.Ref()))) }
//line :250:1
	return t.F_hashCode.Load()
}























func (t *DecimalFormatSymbols) Initialize_Locale__V(locale *Locale) {
	t.F_locale = locale
	var data *RefArray = t.LoadNumberData_Locale__O1(locale); var numberElements *RefArray = A2g_CastArray[*RefArray](data.A[0], String_class.ArrayClass())

	t.F_decimalSeparator = NN(As[*String](numberElements.A[0])).CharAt_I__C(0)
	t.F_groupingSeparator = NN(As[*String](numberElements.A[1])).CharAt_I__C(0)
	t.F_patternSeparator = NN(As[*String](numberElements.A[2])).CharAt_I__C(0)
	t.F_percentText = As[*String](numberElements.A[3])
	t.F_percent = t.FindNonFormatChar_String_C__C(t.F_percentText, 37)
	t.F_zeroDigit = NN(As[*String](numberElements.A[4])).CharAt_I__C(0)
	t.F_digit = NN(As[*String](numberElements.A[5])).CharAt_I__C(0)
	t.F_minusSignText = As[*String](numberElements.A[6])
	t.F_minusSign = t.FindNonFormatChar_String_C__C(t.F_minusSignText, 45)
	t.F_exponential = NN(As[*String](numberElements.A[7])).CharAt_I__C(0)
	t.F_exponentialSeparator = As[*String](numberElements.A[7])
	t.F_perMillText = As[*String](numberElements.A[8])
	t.F_perMill = t.FindNonFormatChar_String_C__C(t.F_perMillText, 8240)
	t.F_infinity = As[*String](numberElements.A[9])
	t.F_NaN = As[*String](numberElements.A[10])
	var tmp1 uint16; var tmp2 bool; var tmp3 bool
	tmp3 = int32(len(numberElements.A)) < 12; if !tmp3 { tmp3 = NN(As[*String](numberElements.A[11])).IsEmpty__Z() }; tmp2 = tmp3; if tmp2 { tmp1 = t.F_decimalSeparator } else {

		tmp1 = NN(As[*String](numberElements.A[11])).CharAt_I__C(0) }
//line :294:1
	t.F_monetarySeparator = tmp1



	var tmp4 uint16; var tmp5 bool; var tmp6 bool
	tmp6 = int32(len(numberElements.A)) < 13; if !tmp6 { tmp6 = NN(As[*String](numberElements.A[12])).IsEmpty__Z() }; tmp5 = tmp6; if tmp5 { tmp4 = t.F_groupingSeparator } else {

		tmp4 = NN(As[*String](numberElements.A[12])).CharAt_I__C(0) }
//line :298:1
	t.F_monetaryGroupingSeparator = tmp4



	var tmp7 *String
	if int32(len(numberElements.A)) < 14 { tmp7 = t.F_minusSignText } else { tmp7 = As[*String](numberElements.A[13]) }
//line :302:1
	t.F_lenientMinusSigns = tmp7

	t.F_intlCurrencySymbol = String_Cast(data.A[1])
	t.F_currencySymbol = String_Cast(data.A[2])
}
func (t *DecimalFormatSymbols) LoadNumberData_Locale__O1(locale *Locale) *RefArray {
	var override *Locale; if NN(locale).GetUnicodeLocaleType_String__String(Lit_1837) == nil {
		override = CalendarDataUtility_FindRegionOverride_Locale__Locale(locale) } else {
//line :308:1
			override = locale }; var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(DecimalFormatSymbolsProvider_class, override)



	if ResourceBundleBasedAdapter_InstanceOf(adapter) { } else {
		adapter = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter() }
	return NN(adapter.GetLocaleResources_Locale__LocaleResources(override)).GetDecimalFormatSymbolsData__O1()
}
func (t *DecimalFormatSymbols) FindNonFormatChar_String_C__C(src *String, defChar uint16) uint16 {
	var i int32 = 0; L1: for {
		if i < NN(src).Length__I() {
			var c uint16 = NN(src).CharAt_I__C(i)
			if !(Character_GetType_C__I(c) == 16) {
				return c } else {
					i = i + 1; continue L1 } }
//line :317:1
		break L1 }
//line :316:1
	return defChar
}







func (t *DecimalFormatSymbols) InitializeCurrency_Locale__V(locale *Locale) {
	if t.F_currencyInitialized.Load() { } else {
		if NN(NN(locale).GetCountry__String()).IsEmpty__Z() { } else { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
			t.F_currency = Currency_GetInstance_Locale__Currency(locale); return nil }(); if tmp1 != nil { if IllegalArgumentException_InstanceOf(tmp1) { var e IllegalArgumentException_I = IllegalArgumentException_Cast(tmp1); _ = e } else { panic(tmp1) } } }
		if !(t.F_currency == nil) {
			var adapter LocaleProviderAdapter_I = LocaleProviderAdapter_GetAdapter_Class_Locale__LocaleProviderAdapter(DecimalFormatSymbolsProvider_class, locale)


			if ResourceBundleBasedAdapter_InstanceOf(adapter) { } else {
				adapter = LocaleProviderAdapter_GetResourceBundleBased__LocaleProviderAdapter() }
			var data *RefArray = NN(adapter.GetLocaleResources_Locale__LocaleResources(locale)).GetDecimalFormatSymbolsData__O1()
			t.F_intlCurrencySymbol = NN(t.F_currency).GetCurrencyCode__String()
			var tmp2 bool; var tmp3 bool; tmp3 = !(data.A[1] == nil); if tmp3 { tmp3 = any(data.A[1]) == any(t.F_intlCurrencySymbol.Ref()) }; tmp2 = tmp3; if tmp2 {
				t.F_currencySymbol = String_Cast(data.A[2]) } else {

					t.F_currencySymbol = NN(t.F_currency).GetSymbol_Locale__String(locale)
					data.Store(1, t.F_intlCurrencySymbol.Ref())
					data.Store(2, t.F_currencySymbol.Ref()) } } else {

						t.F_intlCurrencySymbol = Lit_1838; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)

							t.F_currency = Currency_GetInstance_String__Currency(t.F_intlCurrencySymbol); return nil }()
//line :345:1
						if tmp4 != nil { if IllegalArgumentException_InstanceOf(tmp4) { var e_2 IllegalArgumentException_I = IllegalArgumentException_Cast(tmp4); _ = e_2 } else { panic(tmp4)
						}
						}
						t.F_currencySymbol = Lit_1839 }
		t.F_currencyInitialized.Store(true)
	}
}

type DecimalFormatSymbols struct{ Object; F_zeroDigit, F_groupingSeparator, F_decimalSeparator, F_perMill, F_percent, F_digit, F_patternSeparator uint16; F_infinity, F_NaN *String; F_minusSign uint16; F_currencySymbol, F_intlCurrencySymbol *String; F_monetarySeparator, F_exponential uint16; F_exponentialSeparator *String; F_locale *Locale; F_perMillText, F_percentText, F_minusSignText *String; F_monetaryGroupingSeparator uint16; F_currency *Currency; F_currencyInitialized atomic.Bool; F_lenientMinusSigns *String; F_hashCode atomic.Int32; F_serialVersionOnStream int32 }

func (t *DecimalFormatSymbols) Is_Cloneable() {}

func (t *DecimalFormatSymbols) Is_Serializable() {}

const DecimalFormatSymbols_serialVersionUID int64 = 5772796243397350300

const DecimalFormatSymbols_currentSerialVersion int32 = 5

func (t *DecimalFormatSymbols) Ref() any { if t == nil { return nil }; return t }

func (t *DecimalFormatSymbols) GetClass__Class() *Class { return DecimalFormatSymbols_class }

func (t *DecimalFormatSymbols) ToString__String() *String { return Object_toString(t) }

func (t *DecimalFormatSymbols) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func DecimalFormatSymbols_InstanceOf(x any) bool { _, ok := x.(*DecimalFormatSymbols); return ok }

func DecimalFormatSymbols_Cast(x any) *DecimalFormatSymbols { if x == nil { return nil }; v, ok := x.(*DecimalFormatSymbols); if !ok { panic(ClassCast(x, DecimalFormatSymbols_class)) }; return v }
