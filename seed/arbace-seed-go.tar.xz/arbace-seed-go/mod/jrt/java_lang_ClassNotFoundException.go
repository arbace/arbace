//line java_lang_ClassNotFoundException.ae:1
package jrt










func ClassNotFoundException_New() *ClassNotFoundException { ClassNotFoundException_Init(); t := &ClassNotFoundException{}; t.Ctor(); return t }
//line :12:1
func (t *ClassNotFoundException) Ctor() { t.ReflectiveOperationException.Ctor_Throwable(t, nil) }

func ClassNotFoundException_New_String(p0 *String) *ClassNotFoundException { ClassNotFoundException_Init(); t := &ClassNotFoundException{}; t.Ctor_String(p0); return t }
//line :14:1
func (t *ClassNotFoundException) Ctor_String(s *String) { t.ReflectiveOperationException.Ctor_String_Throwable(t, s, nil) }

func ClassNotFoundException_New_String_Throwable(p0 *String, p1 Throwable_I) *ClassNotFoundException { ClassNotFoundException_Init(); t := &ClassNotFoundException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :16:1
func (t *ClassNotFoundException) Ctor_String_Throwable(s *String, ex Throwable_I) { t.ReflectiveOperationException.Ctor_String_Throwable(t, s, ex) }

func (t *ClassNotFoundException) GetException__Throwable() Throwable_I { return t.ReflectiveOperationException.Impl_GetCause__Throwable(t) }









type ClassNotFoundException struct{ ReflectiveOperationException }

const ClassNotFoundException_serialVersionUID int64 = 9176873029745254542

var ClassNotFoundException_init ClassInit

func ClassNotFoundException_Init() { if !ClassNotFoundException_init.Done() { ClassNotFoundException_init.Run(ClassNotFoundException_clinit) } }

func ClassNotFoundException_clinit() {}

func (t *ClassNotFoundException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ClassNotFoundException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ClassNotFoundException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ClassNotFoundException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ClassNotFoundException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ClassNotFoundException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ClassNotFoundException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ClassNotFoundException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ClassNotFoundException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ClassNotFoundException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ClassNotFoundException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ClassNotFoundException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ClassNotFoundException) Ref() any { if t == nil { return nil }; return t }

func (t *ClassNotFoundException) GetClass__Class() *Class { return ClassNotFoundException_class }

func (t *ClassNotFoundException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ClassNotFoundException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ClassNotFoundException_InstanceOf(x any) bool { _, ok := x.(*ClassNotFoundException); return ok }

func ClassNotFoundException_Cast(x any) *ClassNotFoundException { if x == nil { return nil }; v, ok := x.(*ClassNotFoundException); if !ok { panic(ClassCast(x, ClassNotFoundException_class)) }; return v }
