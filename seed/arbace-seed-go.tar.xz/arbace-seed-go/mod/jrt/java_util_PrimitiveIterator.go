//line java_util_PrimitiveIterator.ae:1
package jrt
















func PrimitiveIterator_OfInt_ForEachRemaining_IntConsumer__V(this PrimitiveIterator_OfInt, action IntConsumer) {
	Objects_RequireNonNull_O__O(action)
L1: for { if this.HasNext__Z() { action.Accept_I__V(this.NextInt__I()); continue L1 }; break L1
} }
func PrimitiveIterator_OfInt_Next__Integer(this PrimitiveIterator_OfInt) *Integer { var tmp1 int32; var tmp2 bool;
											Tripwire_Init(); tmp2 = Tripwire_ENABLED; if tmp2 {
												Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2804) }; tmp1 =
											this.NextInt__I(); return /*line :22:1*/ Integer_ValueOf_I__Integer(tmp1) }




func PrimitiveIterator_OfInt_ForEachRemaining_Consumer__V(this PrimitiveIterator_OfInt, action Consumer) {
	if IntConsumer_InstanceOf(action) {
		this.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(action)) } else {

			Objects_RequireNonNull_O__O(action)
			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2805)
			}

			var tmp2 IntConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &IntConsumer_Fn{Fn: func(p0 int32) { tmp3.Accept_O__V(Integer_ValueOf_I__Integer(p0)) }}; this.ForEachRemaining_IntConsumer__V(tmp2)
		}
}




func PrimitiveIterator_OfLong_ForEachRemaining_LongConsumer__V(this PrimitiveIterator_OfLong, action LongConsumer) {
	Objects_RequireNonNull_O__O(action)
L1: for { if this.HasNext__Z() { action.Accept_J__V(this.NextLong__J()); continue L1 }; break L1
} }
func PrimitiveIterator_OfLong_Next__Long(this PrimitiveIterator_OfLong) *Long { var tmp1 int64; var tmp2 bool;
										Tripwire_Init(); tmp2 = Tripwire_ENABLED; if tmp2 {
											Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2806) }; tmp1 =
										this.NextLong__J(); return /*line :47:1*/ Long_ValueOf_J__Long(tmp1) }




func PrimitiveIterator_OfLong_ForEachRemaining_Consumer__V(this PrimitiveIterator_OfLong, action Consumer) {
	if LongConsumer_InstanceOf(action) {
		this.ForEachRemaining_LongConsumer__V(LongConsumer_Cast(action)) } else {

			Objects_RequireNonNull_O__O(action)
			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2807)
			}

			var tmp2 LongConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &LongConsumer_Fn{Fn: func(p0 int64) { tmp3.Accept_O__V(Long_ValueOf_J__Long(p0)) }}; this.ForEachRemaining_LongConsumer__V(tmp2)
		}
}




func PrimitiveIterator_OfDouble_ForEachRemaining_DoubleConsumer__V(this PrimitiveIterator_OfDouble, action DoubleConsumer) {
	Objects_RequireNonNull_O__O(action)
L1: for { if this.HasNext__Z() { action.Accept_D__V(this.NextDouble__D()); continue L1 }; break L1
} }
func PrimitiveIterator_OfDouble_Next__Double(this PrimitiveIterator_OfDouble) *Double { var tmp1 float64; var tmp2 bool;
											Tripwire_Init(); tmp2 = Tripwire_ENABLED; if tmp2 {
												Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2802) }; tmp1 =
											this.NextDouble__D(); return /*line :72:1*/ Double_ValueOf_D__Double(tmp1) }




func PrimitiveIterator_OfDouble_ForEachRemaining_Consumer__V(this PrimitiveIterator_OfDouble, action Consumer) {
	if DoubleConsumer_InstanceOf(action) {
		this.ForEachRemaining_DoubleConsumer__V(DoubleConsumer_Cast(action)) } else {

			Objects_RequireNonNull_O__O(action)
			var tmp1 bool; Tripwire_Init(); tmp1 = Tripwire_ENABLED; if tmp1 {
				Tripwire_Trip_Class_String__V(this.GetClass__Class(), Lit_2803)
			}

			var tmp2 DoubleConsumer; var tmp3 Consumer = A2g_NotNull[Consumer](action); tmp2 = &DoubleConsumer_Fn{Fn: func(p0 float64) { tmp3.Accept_O__V(Double_ValueOf_D__Double(p0)) }}; this.ForEachRemaining_DoubleConsumer__V(tmp2)
		}
}

type PrimitiveIterator interface{ Object_I; Iterator; Is_PrimitiveIterator(); ForEachRemaining_O__V(p0 any) }

func PrimitiveIterator_InstanceOf(x any) bool { _, ok := x.(PrimitiveIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_class) } }; return ok }

func PrimitiveIterator_Cast(x any) PrimitiveIterator { if x == nil { return nil }; v, ok := x.(PrimitiveIterator); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_class) } }; if !ok { panic(ClassCast(x, PrimitiveIterator_class)) }; return v }



type PrimitiveIterator_OfDouble interface{ Object_I; PrimitiveIterator; Iterator; Is_PrimitiveIterator_OfDouble(); NextDouble__D() float64; ForEachRemaining_DoubleConsumer__V(p0 DoubleConsumer); Next__Double() *Double; ForEachRemaining_Consumer__V(p0 Consumer); ForEachRemaining_O__V(p0 any); Next__O() any }

func PrimitiveIterator_OfDouble_ForEachRemaining_O__V(this PrimitiveIterator_OfDouble, p0 any) { this.ForEachRemaining_DoubleConsumer__V(DoubleConsumer_Cast(p0)) }

func PrimitiveIterator_OfDouble_Next__O(this PrimitiveIterator_OfDouble) any { return this.Next__Double().Ref() }

func PrimitiveIterator_OfDouble_InstanceOf(x any) bool { _, ok := x.(PrimitiveIterator_OfDouble); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_OfDouble_class) } }; return ok }

func PrimitiveIterator_OfDouble_Cast(x any) PrimitiveIterator_OfDouble { if x == nil { return nil }; v, ok := x.(PrimitiveIterator_OfDouble); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_OfDouble_class) } }; if !ok { panic(ClassCast(x, PrimitiveIterator_OfDouble_class)) }; return v }



type PrimitiveIterator_OfInt interface{ Object_I; PrimitiveIterator; Iterator; Is_PrimitiveIterator_OfInt(); NextInt__I() int32; ForEachRemaining_IntConsumer__V(p0 IntConsumer); Next__Integer() *Integer; ForEachRemaining_Consumer__V(p0 Consumer); ForEachRemaining_O__V(p0 any); Next__O() any }

func PrimitiveIterator_OfInt_ForEachRemaining_O__V(this PrimitiveIterator_OfInt, p0 any) { this.ForEachRemaining_IntConsumer__V(IntConsumer_Cast(p0)) }

func PrimitiveIterator_OfInt_Next__O(this PrimitiveIterator_OfInt) any { return this.Next__Integer().Ref() }

func PrimitiveIterator_OfInt_InstanceOf(x any) bool { _, ok := x.(PrimitiveIterator_OfInt); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_OfInt_class) } }; return ok }

func PrimitiveIterator_OfInt_Cast(x any) PrimitiveIterator_OfInt { if x == nil { return nil }; v, ok := x.(PrimitiveIterator_OfInt); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_OfInt_class) } }; if !ok { panic(ClassCast(x, PrimitiveIterator_OfInt_class)) }; return v }



type PrimitiveIterator_OfLong interface{ Object_I; PrimitiveIterator; Iterator; Is_PrimitiveIterator_OfLong(); NextLong__J() int64; ForEachRemaining_LongConsumer__V(p0 LongConsumer); Next__Long() *Long; ForEachRemaining_Consumer__V(p0 Consumer); ForEachRemaining_O__V(p0 any); Next__O() any }

func PrimitiveIterator_OfLong_ForEachRemaining_O__V(this PrimitiveIterator_OfLong, p0 any) { this.ForEachRemaining_LongConsumer__V(LongConsumer_Cast(p0)) }

func PrimitiveIterator_OfLong_Next__O(this PrimitiveIterator_OfLong) any { return this.Next__Long().Ref() }

func PrimitiveIterator_OfLong_InstanceOf(x any) bool { _, ok := x.(PrimitiveIterator_OfLong); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_OfLong_class) } }; return ok }

func PrimitiveIterator_OfLong_Cast(x any) PrimitiveIterator_OfLong { if x == nil { return nil }; v, ok := x.(PrimitiveIterator_OfLong); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(PrimitiveIterator_OfLong_class) } }; if !ok { panic(ClassCast(x, PrimitiveIterator_OfLong_class)) }; return v }
