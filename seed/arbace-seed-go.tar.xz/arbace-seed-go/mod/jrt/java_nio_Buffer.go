//line java_nio_Buffer.ae:1
package jrt





































func (t *Buffer) Ctor_J_I_MemorySegment(this Buffer_I, addr int64, cap_ int32, segment MemorySegment) { panic(A2g_NotTranslated("java.nio.Buffer.<init>(JILjava/lang/foreign/MemorySegment;)V")) }




func (t *Buffer) Ctor_I_I_I_I_MemorySegment(this Buffer_I, mark, pos, lim, cap_ int32, segment MemorySegment) { t.F_mark = -1; t.F_position = 0
	if cap_ < 0 { panic(Thrown(Buffer_CreateCapacityException_I__IllegalArgumentException(cap_))) }
	t.F_capacity = cap_
	t.F_segment = segment
	this.Limit_I__Buffer(lim)
	this.Position_I__Buffer(pos)
	if mark >= 0 {
		if mark > pos {
			panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1476, StrOfInt(mark), Lit_1260, StrOfInt(pos), Lit_1176)))) }
		t.F_mark = mark
	} }
func Buffer_CreateSameBufferException__IllegalArgumentException() IllegalArgumentException_I { Buffer_Init()
	return IllegalArgumentException_New_String(Lit_1477)
}
func Buffer_CreateCapacityException_I__IllegalArgumentException(capacity int32) IllegalArgumentException_I { Buffer_Init()
	if !A2g_AssertionsDisabled && !(capacity < 0) { panic(Thrown(AssertionError_New_O(Lit_1478))) }
	return IllegalArgumentException_New_String(Concat(Lit_1479, StrOfInt(capacity), Lit_1480))
}
func (t *Buffer) Impl_Capacity__I(this Buffer_I) int32 { return t.F_capacity }

func (t *Buffer) Impl_Position__I(this Buffer_I) int32 { return t.F_position }

func (t *Buffer) Impl_Position_I__Buffer(this Buffer_I, newPosition int32) Buffer_I {
	var tmp1 bool; var a_1 bool = newPosition > t.F_limit; var b_2 bool = newPosition < 0; var tmp2 bool; tmp2 = a_1; if !tmp2 { tmp2 = b_2 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(t.Impl_CreatePositionException_I__IllegalArgumentException(this, newPosition))) }
	if t.F_mark > newPosition { t.F_mark = -1 }
	t.F_position = newPosition
//line :66:1
	return this
}





func (t *Buffer) Impl_CreatePositionException_I__IllegalArgumentException(this Buffer_I, newPosition int32) IllegalArgumentException_I {
	var msg *String
	if newPosition > t.F_limit {
		msg = Concat(Lit_1481, StrOfInt(newPosition), Lit_1260, StrOfInt(t.F_limit), Lit_1176) } else {

			if !A2g_AssertionsDisabled && !(newPosition < 0) { panic(Thrown(AssertionError_New_O(Lit_1482))) }
			msg = Concat(Lit_1483, StrOfInt(newPosition), Lit_1480) }
	return IllegalArgumentException_New_String(msg)
}
func (t *Buffer) Impl_Limit__I(this Buffer_I) int32 { return t.F_limit }

func (t *Buffer) Impl_Limit_I__Buffer(this Buffer_I, newLimit int32) Buffer_I {
	var tmp1 bool; var a_3 bool = newLimit > t.F_capacity; var b_4 bool = newLimit < 0; var tmp2 bool; tmp2 = a_3; if !tmp2 { tmp2 = b_4 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(t.Impl_CreateLimitException_I__IllegalArgumentException(this, newLimit))) }
	t.F_limit = newLimit
	if t.F_position > newLimit { t.F_position = newLimit }
	if t.F_mark > newLimit { t.F_mark = -1 }
//line :84:1
	return this
}






func (t *Buffer) Impl_CreateLimitException_I__IllegalArgumentException(this Buffer_I, newLimit int32) IllegalArgumentException_I {
	var msg *String
	if newLimit > t.F_capacity {
		msg = Concat(Lit_1484, StrOfInt(newLimit), Lit_1260, StrOfInt(t.F_capacity), Lit_1176) } else {

			if !A2g_AssertionsDisabled && !(newLimit < 0) { panic(Thrown(AssertionError_New_O(Lit_1485))) }
			msg = Concat(Lit_1486, StrOfInt(newLimit), Lit_1480) }
	return IllegalArgumentException_New_String(msg)
}
func (t *Buffer) Impl_Mark__Buffer(this Buffer_I) Buffer_I { t.F_mark = t.F_position; return this }

func (t *Buffer) Impl_Reset__Buffer(this Buffer_I) Buffer_I {
	var m int32 = t.F_mark; if m < 0 { panic(Thrown(InvalidMarkException_New())) }; t.F_position = m; return this
}
func (t *Buffer) Impl_Clear__Buffer(this Buffer_I) Buffer_I {
	t.F_position = 0
	t.F_limit = t.F_capacity
	t.F_mark = -1
//line :106:1
	return this
}




func (t *Buffer) Impl_Flip__Buffer(this Buffer_I) Buffer_I {
	t.F_limit = t.F_position
	t.F_position = 0
	t.F_mark = -1
//line :112:1
	return this
}




func (t *Buffer) Impl_Rewind__Buffer(this Buffer_I) Buffer_I {
	t.F_position = 0
	t.F_mark = -1
//line :118:1
	return this
}



func (t *Buffer) Impl_Remaining__I(this Buffer_I) int32 {
	var rem int32 = t.F_limit - t.F_position; if rem > 0 { return rem } else { return 0
	} }
func (t *Buffer) Impl_HasRemaining__Z(this Buffer_I) bool {
	return t.F_position < t.F_limit
}


















func (t *Buffer) Impl_NextGetIndex__I(this Buffer_I) int32 {
	var p int32 = t.F_position
	if p >= t.F_limit { panic(Thrown(BufferUnderflowException_New())) }
	t.F_position = p + 1
//line :148:1
	return p
}



func (t *Buffer) Impl_NextGetIndex_I__I(this Buffer_I, nb int32) int32 {
	var p int32 = t.F_position
	if t.F_limit-p < nb { panic(Thrown(BufferUnderflowException_New())) }
	t.F_position = p + nb
//line :154:1
	return p
}



func (t *Buffer) Impl_NextPutIndex__I(this Buffer_I) int32 {
	var p int32 = t.F_position
	if p >= t.F_limit { panic(Thrown(BufferOverflowException_New())) }
	t.F_position = p + 1
//line :160:1
	return p
}



func (t *Buffer) Impl_NextPutIndex_I__I(this Buffer_I, nb int32) int32 {
	var p int32 = t.F_position
	if t.F_limit-p < nb { panic(Thrown(BufferOverflowException_New())) }
	t.F_position = p + nb
//line :166:1
	return p
}






func (t *Buffer_1) Apply_String__IndexOutOfBoundsException(s *String) IndexOutOfBoundsException_I {
	return IndexOutOfBoundsException_New()
}
func (t *Buffer) Impl_CheckIndex_I__I(this Buffer_I, i int32) int32 {
	return Preconditions_CheckIndex_I_I_BiFunction__I(i, t.F_limit, Buffer_IOOBE_FORMATTER)
}
func (t *Buffer) Impl_CheckIndex_I_I__I(this Buffer_I, i, nb int32) int32 {
	return Preconditions_CheckIndex_I_I_BiFunction__I(i, t.F_limit-nb+1, Buffer_IOOBE_FORMATTER)
}








func (t *Buffer) Impl_MarkValue__I(this Buffer_I) int32 { return t.F_mark }

func (t *Buffer) Impl_DiscardMark__V(this Buffer_I) { t.F_mark = -1 }

func (t *Buffer) Impl_Session__MemorySessionImpl(this Buffer_I) MemorySessionImpl_I {
	if !(t.F_segment == nil) { return A2g_Missing[MemorySessionImpl_I]("class jdk.internal.foreign.AbstractMemorySegmentImpl is not in the closed world") } else { return nil
	} }
func (t *Buffer) Impl_CheckSession__V(this Buffer_I) {
	var session MemorySessionImpl_I = this.Session__MemorySessionImpl(); if !(session == nil) { session.CheckValidState__V()
	}
}

type Buffer struct{ Object; F_mark, F_position, F_limit, F_capacity int32; F_address int64; F_segment MemorySegment }

type Buffer_I interface{ Object_I; Self_Buffer() *Buffer; Capacity__I() int32; Position__I() int32; Position_I__Buffer(p0 int32) Buffer_I; Limit__I() int32; Limit_I__Buffer(p0 int32) Buffer_I; Mark__Buffer() Buffer_I; Reset__Buffer() Buffer_I; Clear__Buffer() Buffer_I; Flip__Buffer() Buffer_I; Rewind__Buffer() Buffer_I; Remaining__I() int32; HasRemaining__Z() bool; IsReadOnly__Z() bool; HasArray__Z() bool; Array__O() any; ArrayOffset__I() int32; IsDirect__Z() bool; Slice__Buffer() Buffer_I; Slice_I_I__Buffer(p0, p1 int32) Buffer_I; Duplicate__Buffer() Buffer_I; Base__O() any; NextGetIndex__I() int32; NextGetIndex_I__I(p0 int32) int32; NextPutIndex__I() int32; NextPutIndex_I__I(p0 int32) int32; CheckIndex_I__I(p0 int32) int32; CheckIndex_I_I__I(p0, p1 int32) int32; ScaleShifts__I() int32; MarkValue__I() int32; DiscardMark__V(); Session__MemorySessionImpl() MemorySessionImpl_I; CheckSession__V() }

func (t *Buffer) Self_Buffer() *Buffer { return t }

var Buffer_UNSAFE *Unsafe

var Buffer_SCOPED_MEMORY_ACCESS *ScopedMemoryAccess

const Buffer_SPLITERATOR_CHARACTERISTICS int32 = 16464

var Buffer_IOOBE_FORMATTER BiFunction

var Buffer_init ClassInit

func Buffer_Init() { if !Buffer_init.Done() { Buffer_init.Run(Buffer_clinit) } }

func Buffer_clinit() { Buffer_UNSAFE = Unsafe_GetUnsafe__Unsafe(); Buffer_SCOPED_MEMORY_ACCESS = ScopedMemoryAccess_GetScopedMemoryAccess__ScopedMemoryAccess(); Buffer_IOOBE_FORMATTER = Preconditions_OutOfBoundsExceptionFormatter_Function__BiFunction(Buffer_1_New()) }

func Buffer_InstanceOf(x any) bool { _, ok := x.(Buffer_I); return ok }

func Buffer_Cast(x any) Buffer_I { if x == nil { return nil }; v, ok := x.(Buffer_I); if !ok { panic(ClassCast(x, Buffer_class)) }; return v }



type Buffer_1 struct{ Object }

func (t *Buffer_1) Is_Function() {}

func Buffer_1_New() *Buffer_1 { t := &Buffer_1{}; t.Ctor(); return t }

func (t *Buffer_1) Ctor() {}

func (t *Buffer_1) Apply_O__O(p0 any) any { return t.Apply_String__IndexOutOfBoundsException(String_Cast(p0)) }

func (t *Buffer_1) Compose_Function__Function(p0 Function) Function { return Function_Compose_Function__Function(t, p0) }

func (t *Buffer_1) AndThen_Function__Function(p0 Function) Function { return Function_AndThen_Function__Function(t, p0) }

func (t *Buffer_1) Ref() any { if t == nil { return nil }; return t }

func (t *Buffer_1) GetClass__Class() *Class { return Buffer_1_class }

func (t *Buffer_1) ToString__String() *String { return Object_toString(t) }

func (t *Buffer_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Buffer_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func Buffer_1_InstanceOf(x any) bool { _, ok := x.(*Buffer_1); return ok }

func Buffer_1_Cast(x any) *Buffer_1 { if x == nil { return nil }; v, ok := x.(*Buffer_1); if !ok { panic(ClassCast(x, Buffer_1_class)) }; return v }
