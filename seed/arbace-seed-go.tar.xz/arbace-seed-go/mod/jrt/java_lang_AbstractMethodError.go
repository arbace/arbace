//line java_lang_AbstractMethodError.ae:1
package jrt








func AbstractMethodError_New() *AbstractMethodError { t := &AbstractMethodError{}; t.Ctor(); return t }
//line :10:1
func (t *AbstractMethodError) Ctor() { t.IncompatibleClassChangeError.Ctor(t) }

func AbstractMethodError_New_String(p0 *String) *AbstractMethodError { t := &AbstractMethodError{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *AbstractMethodError) Ctor_String(s *String) { t.IncompatibleClassChangeError.Ctor_String(t, s) }







type AbstractMethodError struct{ IncompatibleClassChangeError }

const AbstractMethodError_serialVersionUID int64 = -1654391082989018462

func (t *AbstractMethodError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *AbstractMethodError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *AbstractMethodError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *AbstractMethodError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *AbstractMethodError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *AbstractMethodError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *AbstractMethodError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *AbstractMethodError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *AbstractMethodError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *AbstractMethodError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *AbstractMethodError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *AbstractMethodError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *AbstractMethodError) Ref() any { if t == nil { return nil }; return t }

func (t *AbstractMethodError) GetClass__Class() *Class { return AbstractMethodError_class }

func (t *AbstractMethodError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *AbstractMethodError) CloneShallow() any { panic(CloneNotSupported(t)) }

func AbstractMethodError_InstanceOf(x any) bool { _, ok := x.(*AbstractMethodError); return ok }

func AbstractMethodError_Cast(x any) *AbstractMethodError { if x == nil { return nil }; v, ok := x.(*AbstractMethodError); if !ok { panic(ClassCast(x, AbstractMethodError_class)) }; return v }
