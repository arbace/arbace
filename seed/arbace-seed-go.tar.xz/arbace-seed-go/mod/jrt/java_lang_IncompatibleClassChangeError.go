//line java_lang_IncompatibleClassChangeError.ae:1
package jrt








func IncompatibleClassChangeError_New() *IncompatibleClassChangeError { t := &IncompatibleClassChangeError{}; t.Ctor(t); return t }
//line :10:1
func (t *IncompatibleClassChangeError) Ctor(this IncompatibleClassChangeError_I) { t.LinkageError.Ctor(this) }

func IncompatibleClassChangeError_New_String(p0 *String) *IncompatibleClassChangeError { t := &IncompatibleClassChangeError{}; t.Ctor_String(t, p0); return t }
//line :12:1
func (t *IncompatibleClassChangeError) Ctor_String(this IncompatibleClassChangeError_I, s *String) { t.LinkageError.Ctor_String(this, s) }







type IncompatibleClassChangeError struct{ LinkageError }

type IncompatibleClassChangeError_I interface{ LinkageError_I; Serializable; Self_IncompatibleClassChangeError() *IncompatibleClassChangeError }

func (t *IncompatibleClassChangeError) Self_IncompatibleClassChangeError() *IncompatibleClassChangeError { return t }

const IncompatibleClassChangeError_serialVersionUID int64 = -4914975503642802119

func (t *IncompatibleClassChangeError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IncompatibleClassChangeError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IncompatibleClassChangeError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IncompatibleClassChangeError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IncompatibleClassChangeError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IncompatibleClassChangeError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IncompatibleClassChangeError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IncompatibleClassChangeError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IncompatibleClassChangeError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IncompatibleClassChangeError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IncompatibleClassChangeError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IncompatibleClassChangeError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IncompatibleClassChangeError) Ref() any { if t == nil { return nil }; return t }

func (t *IncompatibleClassChangeError) GetClass__Class() *Class { return IncompatibleClassChangeError_class }

func (t *IncompatibleClassChangeError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IncompatibleClassChangeError) CloneShallow() any { panic(CloneNotSupported(t)) }

func IncompatibleClassChangeError_InstanceOf(x any) bool { _, ok := x.(IncompatibleClassChangeError_I); return ok }

func IncompatibleClassChangeError_Cast(x any) IncompatibleClassChangeError_I { if x == nil { return nil }; v, ok := x.(IncompatibleClassChangeError_I); if !ok { panic(ClassCast(x, IncompatibleClassChangeError_class)) }; return v }
