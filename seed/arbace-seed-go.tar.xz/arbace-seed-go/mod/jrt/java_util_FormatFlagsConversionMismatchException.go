//line java_util_FormatFlagsConversionMismatchException.ae:1
package jrt












func FormatFlagsConversionMismatchException_New_String_C(p0 *String, p1 uint16) *FormatFlagsConversionMismatchException { t := &FormatFlagsConversionMismatchException{}; t.Ctor_String_C(p0, p1); return t }
//line :14:1
func (t *FormatFlagsConversionMismatchException) Ctor_String_C(f *String, c uint16) { t.IllegalFormatException.Ctor(t)
	if f == nil { panic(Thrown(NullPointerException_New())) }
	t.F_f = f
	t.F_c = c
}
func (t *FormatFlagsConversionMismatchException) GetFlags__String() *String { return t.F_f }

func (t *FormatFlagsConversionMismatchException) GetConversion__C() uint16 { return t.F_c }

func (t *FormatFlagsConversionMismatchException) GetMessage__String() *String {
	return Concat(Lit_2675, StrOfChar(t.F_c), Lit_2676, t.F_f)
}


type FormatFlagsConversionMismatchException struct{ IllegalFormatException; F_f *String; F_c uint16 }

const FormatFlagsConversionMismatchException_serialVersionUID int64 = 19120414

func (t *FormatFlagsConversionMismatchException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *FormatFlagsConversionMismatchException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *FormatFlagsConversionMismatchException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *FormatFlagsConversionMismatchException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *FormatFlagsConversionMismatchException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *FormatFlagsConversionMismatchException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *FormatFlagsConversionMismatchException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *FormatFlagsConversionMismatchException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *FormatFlagsConversionMismatchException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *FormatFlagsConversionMismatchException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *FormatFlagsConversionMismatchException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *FormatFlagsConversionMismatchException) Ref() any { if t == nil { return nil }; return t }

func (t *FormatFlagsConversionMismatchException) GetClass__Class() *Class { return FormatFlagsConversionMismatchException_class }

func (t *FormatFlagsConversionMismatchException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FormatFlagsConversionMismatchException) CloneShallow() any { panic(CloneNotSupported(t)) }

func FormatFlagsConversionMismatchException_InstanceOf(x any) bool { _, ok := x.(*FormatFlagsConversionMismatchException); return ok }

func FormatFlagsConversionMismatchException_Cast(x any) *FormatFlagsConversionMismatchException { if x == nil { return nil }; v, ok := x.(*FormatFlagsConversionMismatchException); if !ok { panic(ClassCast(x, FormatFlagsConversionMismatchException_class)) }; return v }
