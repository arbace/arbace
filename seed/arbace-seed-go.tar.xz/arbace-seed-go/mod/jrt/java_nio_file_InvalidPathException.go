//line java_nio_file_InvalidPathException.ae:1
package jrt












func InvalidPathException_New_String_String_I(p0, p1 *String, p2 int32) *InvalidPathException { t := &InvalidPathException{}; t.Ctor_String_String_I(p0, p1, p2); return t }
//line :14:1
func (t *InvalidPathException) Ctor_String_String_I(input, reason *String, index int32) { t.IllegalArgumentException.Ctor_String(t, reason)

	var tmp1 bool; var tmp2 bool; tmp2 = input == nil; if !tmp2 { tmp2 = reason == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	if index < -1 { panic(Thrown(IllegalArgumentException_New())) }
	t.F_input = input
	t.F_index = index
}
func InvalidPathException_New_String_String(p0, p1 *String) *InvalidPathException { t := &InvalidPathException{}; t.Ctor_String_String(p0, p1); return t }
//line :21:1
func (t *InvalidPathException) Ctor_String_String(input, reason *String) { t.Ctor_String_String_I(input, reason, -1) }


func (t *InvalidPathException) GetInput__String() *String { return t.F_input }

func (t *InvalidPathException) GetReason__String() *String { return t.IllegalArgumentException.Impl_GetMessage__String(t) }

func (t *InvalidPathException) GetIndex__I() int32 { return t.F_index }

func (t *InvalidPathException) GetMessage__String() *String {
	var sb *StringBuilder = StringBuilder_New()
	NN(sb).Append_String__StringBuilder(t.GetReason__String())
	if t.F_index > -1 { NN(sb).Append_String__StringBuilder(Lit_1418); NN(sb).Append_I__StringBuilder(t.F_index) }
	NN(sb).Append_String__StringBuilder(Lit_1157)
	NN(sb).Append_String__StringBuilder(t.F_input)
	return NN(sb).ToString__String()
}


type InvalidPathException struct{ IllegalArgumentException; F_input *String; F_index int32 }

const InvalidPathException_serialVersionUID int64 = 4355821422286746137

func (t *InvalidPathException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvalidPathException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvalidPathException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvalidPathException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvalidPathException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InvalidPathException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvalidPathException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvalidPathException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvalidPathException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvalidPathException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvalidPathException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvalidPathException) Ref() any { if t == nil { return nil }; return t }

func (t *InvalidPathException) GetClass__Class() *Class { return InvalidPathException_class }

func (t *InvalidPathException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvalidPathException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvalidPathException_InstanceOf(x any) bool { _, ok := x.(*InvalidPathException); return ok }

func InvalidPathException_Cast(x any) *InvalidPathException { if x == nil { return nil }; v, ok := x.(*InvalidPathException); if !ok { panic(ClassCast(x, InvalidPathException_class)) }; return v }
