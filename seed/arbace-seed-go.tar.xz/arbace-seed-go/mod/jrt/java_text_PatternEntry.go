//line java_text_PatternEntry.ae:1
package jrt




func (t *PatternEntry) AppendQuotedExtension_StringBuilder__V(toAddTo *StringBuilder) {
	PatternEntry_AppendQuoted_String_StringBuilder__V(t.F_extension, toAddTo)
}
func (t *PatternEntry) AppendQuotedChars_StringBuilder__V(toAddTo *StringBuilder) {
	PatternEntry_AppendQuoted_String_StringBuilder__V(t.F_chars, toAddTo)
}
func (t *PatternEntry) Equals_O__Z(obj any) bool {
	if obj == nil { return false } else {

		var other *PatternEntry = PatternEntry_Cast(obj); var tmp1 *String = t.F_chars; var result bool = NN(tmp1).Equals_O__Z(other.F_chars.Ref()); return result
	} }
func (t *PatternEntry) HashCode__I() int32 { return NN(t.F_chars).HashCode__I() }

func (t *PatternEntry) ToString__String() *String {
	var result *StringBuilder = StringBuilder_New(); t.AddToBuilder_StringBuilder_Z_Z_PatternEntry__V(result, true, false, nil); return NN(result).ToString__String()
}
func (t *PatternEntry) GetStrength__I() int32 { return t.F_strength }

func (t *PatternEntry) GetExtension__String() *String { return t.F_extension }

func (t *PatternEntry) GetChars__String() *String { return t.F_chars }

func (t *PatternEntry) AddToBuilder_StringBuilder_Z_Z_PatternEntry__V(toAddTo *StringBuilder, showExtension, showWhiteSpace bool, lastEntry *PatternEntry) {

	var tmp1 bool; var tmp2 bool; tmp2 = showWhiteSpace; if tmp2 { tmp2 = NN(toAddTo).Length__I() > 0 }; tmp1 = tmp2; if tmp1 {
		var tmp3 bool; var tmp4 bool; tmp4 = t.F_strength == 0; if !tmp4 { tmp4 = !(lastEntry == nil) }; tmp3 = tmp4; if tmp3 {
			NN(toAddTo).Append_C__StringBuilder(10) } else {
				NN(toAddTo).Append_C__StringBuilder(32) } }
	if !(lastEntry == nil) {
		NN(toAddTo).Append_C__StringBuilder(38)
		if showWhiteSpace { NN(toAddTo).Append_C__StringBuilder(32) }
		NN(lastEntry).AppendQuotedChars_StringBuilder__V(toAddTo)
		t.AppendQuotedExtension_StringBuilder__V(toAddTo)
		if showWhiteSpace { NN(toAddTo).Append_C__StringBuilder(32) } }
	var c uint16; switch t.F_strength { case 3: c = 61; case 2: c = 44; case 1: c = 59; case 0: c = 60; case -2: c = 38; case -1: c = 63; default:






		panic(Thrown(IllegalStateException_New_String(Concat(Lit_1964, StrOfInt(t.F_strength)))))}
	NN(toAddTo).Append_C__StringBuilder(c)
	if showWhiteSpace { NN(toAddTo).Append_C__StringBuilder(32) }
	PatternEntry_AppendQuoted_String_StringBuilder__V(t.F_chars, toAddTo)
	var tmp5 bool; var tmp6 bool; tmp6 = showExtension; if tmp6 { tmp6 = !NN(t.F_extension).IsEmpty__Z() }; tmp5 = tmp6; if tmp5 {
		NN(toAddTo).Append_C__StringBuilder(47)
		PatternEntry_AppendQuoted_String_StringBuilder__V(t.F_extension, toAddTo)
	} }
func PatternEntry_AppendQuoted_String_StringBuilder__V(chars *String, toAddTo *StringBuilder) {
	var inQuote bool = false; var ch uint16 = NN(chars).CharAt_I__C(0)

	if Character_IsSpaceChar_C__Z(ch) {
		inQuote = true; NN(toAddTo).Append_C__StringBuilder(39) } else {
//line :58:1
			if PatternEntry_IsSpecialChar_C__Z(ch) {

				inQuote = true; NN(toAddTo).Append_C__StringBuilder(39) } else {

					switch int32(ch) { case 16, 12, 13, 9, 10, 64:

						inQuote = true; NN(toAddTo).Append_C__StringBuilder(39)
//line :62:1
					case 39:


						inQuote = true; NN(toAddTo).Append_C__StringBuilder(39)
//line :62:1
					default:



						if inQuote { inQuote = false; NN(toAddTo).Append_C__StringBuilder(39) }} } }
	NN(toAddTo).Append_String__StringBuilder(chars)
	if inQuote { NN(toAddTo).Append_C__StringBuilder(39)
	} }
func PatternEntry_New_I_StringBuilder_StringBuilder(p0 int32, p1, p2 *StringBuilder) *PatternEntry { t := &PatternEntry{}; t.Ctor_I_StringBuilder_StringBuilder(p0, p1, p2); return t }
//line :70:1
func (t *PatternEntry) Ctor_I_StringBuilder_StringBuilder(strength int32, chars, extension *StringBuilder) { t.F_strength = -1; t.F_chars = Lit_69; t.F_extension = Lit_69
	t.F_strength = strength
	t.F_chars = NN(chars).ToString__String()
	var tmp1 *String; if NN(extension).Length__I() > 0 { tmp1 = NN(extension).ToString__String() } else { tmp1 = Lit_69 }; t.F_extension = tmp1
}





func PatternEntry_Parser_New_String(p0 *String) *PatternEntry_Parser { t := &PatternEntry_Parser{}; t.Ctor_String(p0); return t }
//line :80:1
func (t *PatternEntry_Parser) Ctor_String(pattern *String) { t.F_newChars = StringBuilder_New(); t.F_newExtension = StringBuilder_New()
	t.F_pattern = pattern
	t.F_i = 0
}
func (t *PatternEntry_Parser) Next__PatternEntry() *PatternEntry {
	var newStrength int32 = -1
	NN(t.F_newChars).SetLength_I__V(0)
	NN(t.F_newExtension).SetLength_I__V(0)
	var inChars bool = true
	var inQuote bool = false
L1: for { var tmp1 int32 = t.F_i; if tmp1 < NN(t.F_pattern).Length__I() {
	var ch uint16 = NN(t.F_pattern).CharAt_I__C(t.F_i)
	if inQuote {
		if int32(ch) == 39 {
			inQuote = false } else {
//line :93:1
				if NN(t.F_newChars).Length__I() == 0 {

					NN(t.F_newChars).Append_C__StringBuilder(ch) } else {
//line :93:1
						if inChars {


							NN(t.F_newChars).Append_C__StringBuilder(ch) } else {
								NN(t.F_newExtension).Append_C__StringBuilder(ch) } } } } else {
									switch int32(ch) { case 61:


										if newStrength == -1 { } else { break L1 }
										newStrength = 3; case 44:


										if newStrength == -1 { } else { break L1 }
										newStrength = 2; case 59:


										if newStrength == -1 { } else { break L1 }
										newStrength = 1; case 60:


										if newStrength == -1 { } else { break L1 }
										newStrength = 0; case 38:
										if newStrength == -1 { } else { break L1 }; newStrength = -2; case 9, 10, 12, 13, 32:; case 47:

										inChars = false; case 39:


										inQuote = true
										var tmp8 *String = t.F_pattern; var tmp9 int32; var tmp10 int32 = t.F_i + 1; t.F_i = tmp10; tmp9 = tmp10; ch = NN(tmp8).CharAt_I__C(tmp9)
										if NN(t.F_newChars).Length__I() == 0 {
											NN(t.F_newChars).Append_C__StringBuilder(ch) } else {
//line :122:1
												if inChars {

													NN(t.F_newChars).Append_C__StringBuilder(ch) } else {
														NN(t.F_newExtension).Append_C__StringBuilder(ch) } }
//line :123:1
									default:



										if newStrength == -1 {
											var tmp2 *String = t.F_pattern; var tmp3 int32 = t.F_i; var tmp4 int32; var tmp5 int32 = t.F_i + 10




											if tmp5 < NN(t.F_pattern).Length__I() {
												tmp4 = t.F_i + 10 } else {
													tmp4 = NN(t.F_pattern).Length__I() }
//line :128:1
											panic(Thrown(ParseException_New_String_I(Concat(Lit_1965, NN(tmp2).Substring_I_I__String(tmp3, tmp4)), t.F_i)))
										}







										var tmp6 bool; var tmp7 bool; tmp7 = PatternEntry_IsSpecialChar_C__Z(ch); if tmp7 { tmp7 = inQuote == false }; tmp6 = tmp7; if tmp6 {
											panic(Thrown(ParseException_New_String_I(Concat(Lit_1966, Integer_ToString_I_I__String(int32(ch), 16)), t.F_i)))
										}


										if inChars { NN(t.F_newChars).Append_C__StringBuilder(ch) } else { NN(t.F_newExtension).Append_C__StringBuilder(ch) }} }
	t.F_i = t.F_i + 1
//line :90:1
	continue L1 }; break L1
}




















































	if newStrength == -1 { return nil } else {
		if NN(t.F_newChars).Length__I() == 0 {
			var tmp11 *String = t.F_pattern; var tmp12 int32 = t.F_i; var tmp13 int32; var tmp14 int32 = t.F_i + 10



			if tmp14 < NN(t.F_pattern).Length__I() {
				tmp13 = t.F_i + 10 } else {
					tmp13 = NN(t.F_pattern).Length__I() }
//line :146:1
			panic(Thrown(ParseException_New_String_I(Concat(Lit_1967, NN(tmp11).Substring_I_I__String(tmp12, tmp13)), t.F_i)))
		}






		return PatternEntry_New_I_StringBuilder_StringBuilder(newStrength, t.F_newChars, t.F_newExtension)
	}
}



func PatternEntry_IsSpecialChar_C__Z(ch uint16) bool {
	var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = int32(ch) == 32; if !tmp4 { var tmp5 bool; tmp5 = int32(ch) <= 47; if tmp5 { tmp5 = int32(ch) >= 34 }; tmp4 = tmp5 }; tmp3 = tmp4; if !tmp3 { var tmp6 bool; tmp6 = int32(ch) <= 63; if tmp6 { tmp6 = int32(ch) >= 58 }; tmp3 = tmp6 }; tmp2 = tmp3; if !tmp2 {
		var tmp7 bool; tmp7 = int32(ch) <= 96; if tmp7 { tmp7 = int32(ch) >= 91 }; tmp2 = tmp7 }
//line :161:1
	tmp1 = tmp2; if !tmp1 {

		var tmp8 bool; tmp8 = int32(ch) <= 126; if tmp8 { tmp8 = int32(ch) >= 123 }; tmp1 = tmp8 }
//line :161:1
	return tmp1
}



type PatternEntry struct{ Object; F_strength int32; F_chars, F_extension *String }

const PatternEntry_RESET int32 = -2

const PatternEntry_UNSET int32 = -1

func (t *PatternEntry) Ref() any { if t == nil { return nil }; return t }

func (t *PatternEntry) GetClass__Class() *Class { return PatternEntry_class }

func (t *PatternEntry) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PatternEntry) CloneShallow() any { panic(CloneNotSupported(t)) }

func PatternEntry_InstanceOf(x any) bool { _, ok := x.(*PatternEntry); return ok }

func PatternEntry_Cast(x any) *PatternEntry { if x == nil { return nil }; v, ok := x.(*PatternEntry); if !ok { panic(ClassCast(x, PatternEntry_class)) }; return v }



type PatternEntry_Parser struct{ Object; F_pattern *String; F_i int32; F_newChars, F_newExtension *StringBuilder }

func (t *PatternEntry_Parser) Ref() any { if t == nil { return nil }; return t }

func (t *PatternEntry_Parser) GetClass__Class() *Class { return PatternEntry_Parser_class }

func (t *PatternEntry_Parser) ToString__String() *String { return Object_toString(t) }

func (t *PatternEntry_Parser) Clone__O() any { return A2g_ObjectClone(t) }

func (t *PatternEntry_Parser) CloneShallow() any { panic(CloneNotSupported(t)) }

func PatternEntry_Parser_InstanceOf(x any) bool { _, ok := x.(*PatternEntry_Parser); return ok }

func PatternEntry_Parser_Cast(x any) *PatternEntry_Parser { if x == nil { return nil }; v, ok := x.(*PatternEntry_Parser); if !ok { panic(ClassCast(x, PatternEntry_Parser_class)) }; return v }
