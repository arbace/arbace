//line java_util_IllegalFormatFlagsException.ae:1
package jrt










func IllegalFormatFlagsException_New_String(p0 *String) *IllegalFormatFlagsException { t := &IllegalFormatFlagsException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *IllegalFormatFlagsException) Ctor_String(f *String) { t.IllegalFormatException.Ctor(t)
	if f == nil { panic(Thrown(NullPointerException_New())) }
	t.F_flags = f
}
func (t *IllegalFormatFlagsException) GetFlags__String() *String { return t.F_flags }

func (t *IllegalFormatFlagsException) GetMessage__String() *String {
	return Concat(Lit_2729, t.F_flags, Lit_1371)
}


type IllegalFormatFlagsException struct{ IllegalFormatException; F_flags *String }

const IllegalFormatFlagsException_serialVersionUID int64 = 790824

func (t *IllegalFormatFlagsException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalFormatFlagsException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalFormatFlagsException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalFormatFlagsException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalFormatFlagsException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalFormatFlagsException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalFormatFlagsException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalFormatFlagsException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalFormatFlagsException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalFormatFlagsException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalFormatFlagsException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalFormatFlagsException) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalFormatFlagsException) GetClass__Class() *Class { return IllegalFormatFlagsException_class }

func (t *IllegalFormatFlagsException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalFormatFlagsException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalFormatFlagsException_InstanceOf(x any) bool { _, ok := x.(*IllegalFormatFlagsException); return ok }

func IllegalFormatFlagsException_Cast(x any) *IllegalFormatFlagsException { if x == nil { return nil }; v, ok := x.(*IllegalFormatFlagsException); if !ok { panic(ClassCast(x, IllegalFormatFlagsException_class)) }; return v }
