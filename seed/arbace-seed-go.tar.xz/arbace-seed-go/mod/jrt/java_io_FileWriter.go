//line java_io_FileWriter.ae:1
package jrt








func FileWriter_New_String(p0 *String) *FileWriter { t := &FileWriter{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *FileWriter) Ctor_String(fileName *String) { t.OutputStreamWriter.Ctor_OutputStream(t, FileOutputStream_New_String(fileName)) }


func FileWriter_New_String_Z(p0 *String, p1 bool) *FileWriter { t := &FileWriter{}; t.Ctor_String_Z(p0, p1); return t }
//line :13:1
func (t *FileWriter) Ctor_String_Z(fileName *String, append_ bool) { t.OutputStreamWriter.Ctor_OutputStream(t, FileOutputStream_New_String_Z(fileName, append_)) }


func FileWriter_New_File(p0 *File) *FileWriter { t := &FileWriter{}; t.Ctor_File(p0); return t }
//line :16:1
func (t *FileWriter) Ctor_File(file *File) { t.OutputStreamWriter.Ctor_OutputStream(t, FileOutputStream_New_File(file)) }


func FileWriter_New_File_Z(p0 *File, p1 bool) *FileWriter { t := &FileWriter{}; t.Ctor_File_Z(p0, p1); return t }
//line :19:1
func (t *FileWriter) Ctor_File_Z(file *File, append_ bool) { t.OutputStreamWriter.Ctor_OutputStream(t, FileOutputStream_New_File_Z(file, append_)) }


func FileWriter_New_FileDescriptor(p0 *FileDescriptor) *FileWriter { t := &FileWriter{}; t.Ctor_FileDescriptor(p0); return t }
//line :22:1
func (t *FileWriter) Ctor_FileDescriptor(fd *FileDescriptor) { t.OutputStreamWriter.Ctor_OutputStream(t, FileOutputStream_New_FileDescriptor(fd)) }


func FileWriter_New_String_Charset(p0 *String, p1 Charset_I) *FileWriter { t := &FileWriter{}; t.Ctor_String_Charset(p0, p1); return t }
//line :25:1
func (t *FileWriter) Ctor_String_Charset(fileName *String, charset Charset_I) { t.OutputStreamWriter.Ctor_OutputStream_Charset(t, FileOutputStream_New_String(fileName), charset) }


func FileWriter_New_String_Charset_Z(p0 *String, p1 Charset_I, p2 bool) *FileWriter { t := &FileWriter{}; t.Ctor_String_Charset_Z(p0, p1, p2); return t }
//line :28:1
func (t *FileWriter) Ctor_String_Charset_Z(fileName *String, charset Charset_I, append_ bool) { t.OutputStreamWriter.Ctor_OutputStream_Charset(t, FileOutputStream_New_String_Z(fileName, append_), charset) }



func FileWriter_New_File_Charset(p0 *File, p1 Charset_I) *FileWriter { t := &FileWriter{}; t.Ctor_File_Charset(p0, p1); return t }
//line :32:1
func (t *FileWriter) Ctor_File_Charset(file *File, charset Charset_I) { t.OutputStreamWriter.Ctor_OutputStream_Charset(t, FileOutputStream_New_File(file), charset) }


func FileWriter_New_File_Charset_Z(p0 *File, p1 Charset_I, p2 bool) *FileWriter { t := &FileWriter{}; t.Ctor_File_Charset_Z(p0, p1, p2); return t }
//line :35:1
func (t *FileWriter) Ctor_File_Charset_Z(file *File, charset Charset_I, append_ bool) { t.OutputStreamWriter.Ctor_OutputStream_Charset(t, FileOutputStream_New_File_Z(file, append_), charset) }





type FileWriter struct{ OutputStreamWriter }

func (t *FileWriter) Write_C1__V(p0 *CharArray) { t.Impl_Write_C1__V(t, p0) }

func (t *FileWriter) Append_CharSequence_I_I__Appendable(p0 CharSequence, p1, p2 int32) Appendable { return t.Impl_Append_CharSequence_I_I__Appendable(t, p0, p1, p2) }

func (t *FileWriter) Append_CharSequence_I_I__Writer(p0 CharSequence, p1, p2 int32) Writer_I { return t.Impl_Append_CharSequence_I_I__Writer(t, p0, p1, p2) }

func (t *FileWriter) Flush__V() { t.Impl_Flush__V(t) }

func (t *FileWriter) Append_C__Writer(p0 uint16) Writer_I { return t.Impl_Append_C__Writer(t, p0) }

func (t *FileWriter) Close__V() { t.Impl_Close__V(t) }

func (t *FileWriter) Write_String__V(p0 *String) { t.Impl_Write_String__V(t, p0) }

func (t *FileWriter) Write_C1_I_I__V(p0 *CharArray, p1, p2 int32) { t.Impl_Write_C1_I_I__V(t, p0, p1, p2) }

func (t *FileWriter) Append_CharSequence__Appendable(p0 CharSequence) Appendable { return t.Impl_Append_CharSequence__Appendable(t, p0) }

func (t *FileWriter) FlushBuffer__V() { t.Impl_FlushBuffer__V(t) }

func (t *FileWriter) Append_C__Appendable(p0 uint16) Appendable { return t.Impl_Append_C__Appendable(t, p0) }

func (t *FileWriter) Append_CharSequence__Writer(p0 CharSequence) Writer_I { return t.Impl_Append_CharSequence__Writer(t, p0) }

func (t *FileWriter) Write_I__V(p0 int32) { t.Impl_Write_I__V(t, p0) }

func (t *FileWriter) GetEncoding__String() *String { return t.Impl_GetEncoding__String(t) }

func (t *FileWriter) Write_String_I_I__V(p0 *String, p1, p2 int32) { t.Impl_Write_String_I_I__V(t, p0, p1, p2) }

func (t *FileWriter) Ref() any { if t == nil { return nil }; return t }

func (t *FileWriter) GetClass__Class() *Class { return FileWriter_class }

func (t *FileWriter) ToString__String() *String { return Object_toString(t) }

func (t *FileWriter) Clone__O() any { return A2g_ObjectClone(t) }

func (t *FileWriter) CloneShallow() any { panic(CloneNotSupported(t)) }

func FileWriter_InstanceOf(x any) bool { _, ok := x.(*FileWriter); return ok }

func FileWriter_Cast(x any) *FileWriter { if x == nil { return nil }; v, ok := x.(*FileWriter); if !ok { panic(ClassCast(x, FileWriter_class)) }; return v }
