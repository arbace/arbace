//line java_lang_Void.ae:1
package jrt






func Void_New() *Void { Void_Init(); t := &Void{}; t.Ctor(); return t }
//line :8:1
func (t *Void) Ctor() { panic(A2g_NotTranslated("java.lang.Void.<init>()V")) }





type Void struct{ Object }

var Void_TYPE *Class

var Void_init ClassInit

func Void_Init() { if !Void_init.Done() { Void_init.Run(Void_clinit) } }

func Void_clinit() { Void_TYPE = Class_GetPrimitiveClass_String__Class(Lit_1195) }

func (t *Void) Ref() any { if t == nil { return nil }; return t }

func (t *Void) GetClass__Class() *Class { return Void_class }

func (t *Void) ToString__String() *String { return Object_toString(t) }

func (t *Void) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Void) CloneShallow() any { panic(CloneNotSupported(t)) }

func Void_InstanceOf(x any) bool { _, ok := x.(*Void); return ok }

func Void_Cast(x any) *Void { if x == nil { return nil }; v, ok := x.(*Void); if !ok { panic(ClassCast(x, Void_class)) }; return v }
