//line java_time_chrono_ChronoLocalDateImpl.ae:1
package jrt





















func ChronoLocalDateImpl_EnsureValid_Chronology_Temporal__ChronoLocalDate(chrono Chronology, temporal Temporal) ChronoLocalDate {

	var other ChronoLocalDate = ChronoLocalDate_Cast(temporal)
	if chrono.Equals_O__Z(other.GetChronology__Chronology()) == false {
		panic(Thrown(ClassCastException_New_String(Concat(Lit_2188, chrono.GetId__String(), Lit_2189, other.GetChronology__Chronology().GetId__String())))) }
//line :25:1
	return other
}







func (t *ChronoLocalDateImpl) Ctor(this ChronoLocalDateImpl_I) { panic(A2g_NotTranslated("java.time.chrono.ChronoLocalDateImpl.<init>()V")) }

func (t *ChronoLocalDateImpl) Impl_With_TemporalAdjuster__ChronoLocalDate(this ChronoLocalDateImpl_I, adjuster TemporalAdjuster) ChronoLocalDate {
	return ChronoLocalDate_With_TemporalAdjuster__ChronoLocalDate(this, adjuster)
}
func (t *ChronoLocalDateImpl) Impl_With_TemporalField_J__ChronoLocalDate(this ChronoLocalDateImpl_I, field TemporalField, value int64) ChronoLocalDate {
	return ChronoLocalDate_With_TemporalField_J__ChronoLocalDate(this, field, value)
}
func (t *ChronoLocalDateImpl) Impl_Plus_TemporalAmount__ChronoLocalDate(this ChronoLocalDateImpl_I, amount TemporalAmount) ChronoLocalDate {
	return ChronoLocalDate_Plus_TemporalAmount__ChronoLocalDate(this, amount)
}
func (t *ChronoLocalDateImpl) Impl_Plus_J_TemporalUnit__ChronoLocalDate(this ChronoLocalDateImpl_I, amountToAdd int64, unit TemporalUnit) ChronoLocalDate {
	{ var tmp1 TemporalUnit = unit; if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
		switch NN(chronoUnit).F_ordinal { case 7:
			return this.PlusDays_J__ChronoLocalDate(amountToAdd); case 8:
			return this.PlusDays_J__ChronoLocalDate(Math_MultiplyExact_J_I__J(amountToAdd, 7)); case 9:
			return this.PlusMonths_J__ChronoLocalDate(amountToAdd); case 10:
			return this.PlusYears_J__ChronoLocalDate(amountToAdd); case 11:
			return this.PlusYears_J__ChronoLocalDate(Math_MultiplyExact_J_I__J(amountToAdd, 10)); case 12:
			return this.PlusYears_J__ChronoLocalDate(Math_MultiplyExact_J_I__J(amountToAdd, 100)); case 13:
			return this.PlusYears_J__ChronoLocalDate(Math_MultiplyExact_J_I__J(amountToAdd, 1000)); case 14:

			var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 TemporalField = Up_ChronoField_TemporalField(tmp2); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return this.With_TemporalField_J__ChronoLocalDate(tmp3, Math_AddExact_J_J__J(this.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)), amountToAdd)); default:
			panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
				return ChronoLocalDate_Plus_J_TemporalUnit__ChronoLocalDate(this, amountToAdd, unit) } }; panic("a2g: unreachable")
}
func (t *ChronoLocalDateImpl) Impl_Minus_TemporalAmount__ChronoLocalDate(this ChronoLocalDateImpl_I, amount TemporalAmount) ChronoLocalDate {
	return ChronoLocalDate_Minus_TemporalAmount__ChronoLocalDate(this, amount)
}
func (t *ChronoLocalDateImpl) Impl_Minus_J_TemporalUnit__ChronoLocalDate(this ChronoLocalDateImpl_I, amountToSubtract int64, unit TemporalUnit) ChronoLocalDate {
	return ChronoLocalDate_Minus_J_TemporalUnit__ChronoLocalDate(this, amountToSubtract, unit)
}




func (t *ChronoLocalDateImpl) Impl_PlusWeeks_J__ChronoLocalDate(this ChronoLocalDateImpl_I, p0 int64) ChronoLocalDate { panic(A2g_NotTranslated("java.time.chrono.ChronoLocalDateImpl.plusWeeks(J)Ljava/time/chrono/ChronoLocalDate;")) }




func (t *ChronoLocalDateImpl) Impl_MinusYears_J__ChronoLocalDate(this ChronoLocalDateImpl_I, p0 int64) ChronoLocalDate { panic(A2g_NotTranslated("java.time.chrono.ChronoLocalDateImpl.minusYears(J)Ljava/time/chrono/ChronoLocalDate;")) }




func (t *ChronoLocalDateImpl) Impl_MinusMonths_J__ChronoLocalDate(this ChronoLocalDateImpl_I, p0 int64) ChronoLocalDate { panic(A2g_NotTranslated("java.time.chrono.ChronoLocalDateImpl.minusMonths(J)Ljava/time/chrono/ChronoLocalDate;")) }




func (t *ChronoLocalDateImpl) Impl_MinusWeeks_J__ChronoLocalDate(this ChronoLocalDateImpl_I, p0 int64) ChronoLocalDate { panic(A2g_NotTranslated("java.time.chrono.ChronoLocalDateImpl.minusWeeks(J)Ljava/time/chrono/ChronoLocalDate;")) }




func (t *ChronoLocalDateImpl) Impl_MinusDays_J__ChronoLocalDate(this ChronoLocalDateImpl_I, p0 int64) ChronoLocalDate { panic(A2g_NotTranslated("java.time.chrono.ChronoLocalDateImpl.minusDays(J)Ljava/time/chrono/ChronoLocalDate;")) }




func (t *ChronoLocalDateImpl) Impl_Until_Temporal_TemporalUnit__J(this ChronoLocalDateImpl_I, endExclusive Temporal, unit TemporalUnit) int64 {
	Objects_RequireNonNull_O_String__O(endExclusive, Lit_2035)
	{ var end ChronoLocalDate = this.GetChronology__Chronology().Date_TemporalAccessor__ChronoLocalDate(endExclusive); var tmp1 TemporalUnit = unit
		if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1)
			switch NN(chronoUnit).F_ordinal { case 7:
				return t.Impl_DaysUntil_ChronoLocalDate__J(this, end); case 8:
				return t.Impl_DaysUntil_ChronoLocalDate__J(this, end) / 7; case 9:
				return t.Impl_MonthsUntil_ChronoLocalDate__J(this, end); case 10:
				return t.Impl_MonthsUntil_ChronoLocalDate__J(this, end) / 12; case 11:
				return t.Impl_MonthsUntil_ChronoLocalDate__J(this, end) / 120; case 12:
				return t.Impl_MonthsUntil_ChronoLocalDate__J(this, end) / 1200; case 13:
				return t.Impl_MonthsUntil_ChronoLocalDate__J(this, end) / 12000; case 14:
				var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_ERA; var tmp3 int64 = end.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp2)); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_ERA; return tmp3 - this.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp4)); default:
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
					Objects_RequireNonNull_O_String__O(unit, Lit_1921); return unit.Between_Temporal_Temporal__J(this, end) } }; panic("a2g: unreachable")
}
func (t *ChronoLocalDateImpl) Impl_DaysUntil_ChronoLocalDate__J(this ChronoLocalDateImpl_I, end ChronoLocalDate) int64 {
	return end.ToEpochDay__J() - this.ToEpochDay__J()
}
func (t *ChronoLocalDateImpl) Impl_MonthsUntil_ChronoLocalDate__J(this ChronoLocalDateImpl_I, end ChronoLocalDate) int64 {
	var range_ *ValueRange; var tmp1 Chronology = this.GetChronology__Chronology(); var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; range_ = tmp1.Range_ChronoField__ValueRange(tmp2)
	if NN(range_).GetMaximum__J() == 12 { } else {
		panic(Thrown(IllegalStateException_New_String(Lit_2190)))
	}
	var packed1 int64; var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_PROLEPTIC_MONTH; var tmp4 int64 = this.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp3)) * 32; var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_DAY_OF_MONTH; packed1 = tmp4 + int64(this.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5))); var packed2 int64; var tmp6 *ChronoField


	ChronoField_Init(); tmp6 = ChronoField_PROLEPTIC_MONTH; var tmp7 int64 = end.GetLong_TemporalField__J(Up_ChronoField_TemporalField(tmp6)) * 32; var tmp8 *ChronoField; ChronoField_Init(); tmp8 = ChronoField_DAY_OF_MONTH; packed2 = tmp7 + int64(end.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp8)))


	return (packed2 - packed1) / 32
}
func (t *ChronoLocalDateImpl) Impl_Equals_O__Z(this ChronoLocalDateImpl_I, obj any) bool {
	if any(this) == any(obj) { return true } else { if ChronoLocalDate_InstanceOf(obj) {

		return this.CompareTo_ChronoLocalDate__I(ChronoLocalDate_Cast(obj)) == 0 } else {
//line :128:1
			return false
		}
	}
}

func (t *ChronoLocalDateImpl) Impl_HashCode__I(this ChronoLocalDateImpl_I) int32 {
	var epDay int64 = this.ToEpochDay__J()
	return this.GetChronology__Chronology().HashCode__I() ^ Long_HashCode_J__I(epDay)
}
func (t *ChronoLocalDateImpl) Impl_ToString__String(this ChronoLocalDateImpl_I) *String {
	var yoe int32; var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_YEAR_OF_ERA; yoe = this.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp1)); var moy int32; var tmp2 *ChronoField
	ChronoField_Init(); tmp2 = ChronoField_MONTH_OF_YEAR; moy = this.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp2))
//line :138:1
	var dom int32; var tmp3 *ChronoField

	ChronoField_Init(); tmp3 = ChronoField_DAY_OF_MONTH; dom = this.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp3))
//line :138:1
	var buf *StringBuilder = StringBuilder_New_I(30)



	NN(NN(NN(NN(NN(NN(buf).Append_String__StringBuilder(this.GetChronology__Chronology().ToString__String())).Append_String__StringBuilder(Lit_115)).Append_O__StringBuilder(this.GetEra__Era())).Append_String__StringBuilder(Lit_115)).Append_I__StringBuilder(yoe)).Append_C__StringBuilder(45)






	DecimalDigits_AppendPair_StringBuilder_I__V(buf, moy)
	NN(buf).Append_C__StringBuilder(45)
	DecimalDigits_AppendPair_StringBuilder_I__V(buf, dom)
	return NN(buf).ToString__String() }
//line :143:1
type ChronoLocalDateImpl struct{ Object }

type ChronoLocalDateImpl_I interface{ Object_I; ChronoLocalDate; Temporal; TemporalAdjuster; Serializable; Comparable; TemporalAccessor; Self_ChronoLocalDateImpl() *ChronoLocalDateImpl; With_TemporalAdjuster__ChronoLocalDate(p0 TemporalAdjuster) ChronoLocalDate; With_TemporalField_J__ChronoLocalDate(p0 TemporalField, p1 int64) ChronoLocalDate; Plus_TemporalAmount__ChronoLocalDate(p0 TemporalAmount) ChronoLocalDate; Plus_J_TemporalUnit__ChronoLocalDate(p0 int64, p1 TemporalUnit) ChronoLocalDate; Minus_TemporalAmount__ChronoLocalDate(p0 TemporalAmount) ChronoLocalDate; Minus_J_TemporalUnit__ChronoLocalDate(p0 int64, p1 TemporalUnit) ChronoLocalDate; PlusYears_J__ChronoLocalDate(p0 int64) ChronoLocalDate; PlusMonths_J__ChronoLocalDate(p0 int64) ChronoLocalDate; PlusWeeks_J__ChronoLocalDate(p0 int64) ChronoLocalDate; PlusDays_J__ChronoLocalDate(p0 int64) ChronoLocalDate; MinusYears_J__ChronoLocalDate(p0 int64) ChronoLocalDate; MinusMonths_J__ChronoLocalDate(p0 int64) ChronoLocalDate; MinusWeeks_J__ChronoLocalDate(p0 int64) ChronoLocalDate; MinusDays_J__ChronoLocalDate(p0 int64) ChronoLocalDate; Until_Temporal_TemporalUnit__J(p0 Temporal, p1 TemporalUnit) int64; With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal; With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal; Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal; Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal; Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal }

func (t *ChronoLocalDateImpl) Self_ChronoLocalDateImpl() *ChronoLocalDateImpl { return t }

func (t *ChronoLocalDateImpl) Is_ChronoLocalDate() {}

func (t *ChronoLocalDateImpl) Is_Temporal() {}

func (t *ChronoLocalDateImpl) Is_TemporalAdjuster() {}

func (t *ChronoLocalDateImpl) Is_Serializable() {}

func (t *ChronoLocalDateImpl) Is_Comparable() {}

func (t *ChronoLocalDateImpl) Is_TemporalAccessor() {}

const ChronoLocalDateImpl_serialVersionUID int64 = 6282433883239719096

func (t *ChronoLocalDateImpl) Impl_With_TemporalAdjuster__Temporal(this ChronoLocalDateImpl_I, p0 TemporalAdjuster) Temporal { return this.With_TemporalAdjuster__ChronoLocalDate(p0) }

func (t *ChronoLocalDateImpl) Impl_With_TemporalField_J__Temporal(this ChronoLocalDateImpl_I, p0 TemporalField, p1 int64) Temporal { return this.With_TemporalField_J__ChronoLocalDate(p0, p1) }

func (t *ChronoLocalDateImpl) Impl_Plus_TemporalAmount__Temporal(this ChronoLocalDateImpl_I, p0 TemporalAmount) Temporal { return this.Plus_TemporalAmount__ChronoLocalDate(p0) }

func (t *ChronoLocalDateImpl) Impl_Plus_J_TemporalUnit__Temporal(this ChronoLocalDateImpl_I, p0 int64, p1 TemporalUnit) Temporal { return this.Plus_J_TemporalUnit__ChronoLocalDate(p0, p1) }

func (t *ChronoLocalDateImpl) Impl_Minus_TemporalAmount__Temporal(this ChronoLocalDateImpl_I, p0 TemporalAmount) Temporal { return this.Minus_TemporalAmount__ChronoLocalDate(p0) }

func (t *ChronoLocalDateImpl) Impl_Minus_J_TemporalUnit__Temporal(this ChronoLocalDateImpl_I, p0 int64, p1 TemporalUnit) Temporal { return this.Minus_J_TemporalUnit__ChronoLocalDate(p0, p1) }

func ChronoLocalDateImpl_InstanceOf(x any) bool { _, ok := x.(ChronoLocalDateImpl_I); return ok }

func ChronoLocalDateImpl_Cast(x any) ChronoLocalDateImpl_I { if x == nil { return nil }; v, ok := x.(ChronoLocalDateImpl_I); if !ok { panic(ClassCast(x, ChronoLocalDateImpl_class)) }; return v }
