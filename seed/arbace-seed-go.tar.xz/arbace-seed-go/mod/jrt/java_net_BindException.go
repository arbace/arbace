//line java_net_BindException.ae:1
package jrt








func BindException_New_String(p0 *String) *BindException { t := &BindException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *BindException) Ctor_String(msg *String) { t.SocketException.Ctor_String(t, msg) }

func BindException_New() *BindException { t := &BindException{}; t.Ctor(); return t }
//line :12:1
func (t *BindException) Ctor() { t.SocketException.Ctor(t) }







type BindException struct{ SocketException }

const BindException_serialVersionUID int64 = -5945005768251722951

func (t *BindException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *BindException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *BindException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *BindException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *BindException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *BindException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *BindException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *BindException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *BindException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *BindException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *BindException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *BindException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *BindException) Ref() any { if t == nil { return nil }; return t }

func (t *BindException) GetClass__Class() *Class { return BindException_class }

func (t *BindException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *BindException) CloneShallow() any { panic(CloneNotSupported(t)) }

func BindException_InstanceOf(x any) bool { _, ok := x.(*BindException); return ok }

func BindException_Cast(x any) *BindException { if x == nil { return nil }; v, ok := x.(*BindException); if !ok { panic(ClassCast(x, BindException_class)) }; return v }
