//line java_net_StandardSocketOptions.ae:1
package jrt




func StandardSocketOptions_New() *StandardSocketOptions { StandardSocketOptions_Init(); t := &StandardSocketOptions{}; t.Ctor(); return t }
//line :6:1
func (t *StandardSocketOptions) Ctor() { panic(A2g_NotTranslated("java.net.StandardSocketOptions.<init>()V")) }













































func StandardSocketOptions_StdSocketOption_New_String_Class(p0 *String, p1 *Class) *StandardSocketOptions_StdSocketOption { t := &StandardSocketOptions_StdSocketOption{}; t.Ctor_String_Class(p0, p1); return t }
//line :52:1
func (t *StandardSocketOptions_StdSocketOption) Ctor_String_Class(name *String, type_ *Class) {
	t.F_name = name
	t.F_type = type_
}
func (t *StandardSocketOptions_StdSocketOption) Name__String() *String { return t.F_name }

func (t *StandardSocketOptions_StdSocketOption) Type__Class() *Class { return t.F_type }

func (t *StandardSocketOptions_StdSocketOption) ToString__String() *String { return t.F_name }



type StandardSocketOptions struct{ Object }

var StandardSocketOptions_SO_BROADCAST SocketOption

var StandardSocketOptions_SO_KEEPALIVE SocketOption

var StandardSocketOptions_SO_SNDBUF SocketOption

var StandardSocketOptions_SO_RCVBUF SocketOption

var StandardSocketOptions_SO_REUSEADDR SocketOption

var StandardSocketOptions_SO_REUSEPORT SocketOption

var StandardSocketOptions_SO_LINGER SocketOption

var StandardSocketOptions_IP_TOS SocketOption

var StandardSocketOptions_IP_MULTICAST_IF SocketOption

var StandardSocketOptions_IP_MULTICAST_TTL SocketOption

var StandardSocketOptions_IP_MULTICAST_LOOP SocketOption

var StandardSocketOptions_TCP_NODELAY SocketOption

var StandardSocketOptions_init ClassInit

func StandardSocketOptions_Init() { if !StandardSocketOptions_init.Done() { StandardSocketOptions_init.Run(StandardSocketOptions_clinit) } }

func StandardSocketOptions_clinit() { StandardSocketOptions_SO_BROADCAST = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1373, Boolean_class); StandardSocketOptions_SO_KEEPALIVE = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1374, Boolean_class); StandardSocketOptions_SO_SNDBUF = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1375, Integer_class); StandardSocketOptions_SO_RCVBUF = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1376, Integer_class); StandardSocketOptions_SO_REUSEADDR = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1377, Boolean_class); StandardSocketOptions_SO_REUSEPORT = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1378, Boolean_class); StandardSocketOptions_SO_LINGER = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1379, Integer_class); StandardSocketOptions_IP_TOS = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1380, Integer_class); StandardSocketOptions_IP_MULTICAST_IF = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1381, NetworkInterface_class); StandardSocketOptions_IP_MULTICAST_TTL = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1382, Integer_class); StandardSocketOptions_IP_MULTICAST_LOOP = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1383, Boolean_class); StandardSocketOptions_TCP_NODELAY = StandardSocketOptions_StdSocketOption_New_String_Class(Lit_1384, Boolean_class) }

func (t *StandardSocketOptions) Ref() any { if t == nil { return nil }; return t }

func (t *StandardSocketOptions) GetClass__Class() *Class { return StandardSocketOptions_class }

func (t *StandardSocketOptions) ToString__String() *String { return Object_toString(t) }

func (t *StandardSocketOptions) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StandardSocketOptions) CloneShallow() any { panic(CloneNotSupported(t)) }

func StandardSocketOptions_InstanceOf(x any) bool { _, ok := x.(*StandardSocketOptions); return ok }

func StandardSocketOptions_Cast(x any) *StandardSocketOptions { if x == nil { return nil }; v, ok := x.(*StandardSocketOptions); if !ok { panic(ClassCast(x, StandardSocketOptions_class)) }; return v }



type StandardSocketOptions_StdSocketOption struct{ Object; F_name *String; F_type *Class }

func (t *StandardSocketOptions_StdSocketOption) Is_SocketOption() {}

func (t *StandardSocketOptions_StdSocketOption) Ref() any { if t == nil { return nil }; return t }

func (t *StandardSocketOptions_StdSocketOption) GetClass__Class() *Class { return StandardSocketOptions_StdSocketOption_class }

func (t *StandardSocketOptions_StdSocketOption) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StandardSocketOptions_StdSocketOption) CloneShallow() any { panic(CloneNotSupported(t)) }

func StandardSocketOptions_StdSocketOption_InstanceOf(x any) bool { _, ok := x.(*StandardSocketOptions_StdSocketOption); return ok }

func StandardSocketOptions_StdSocketOption_Cast(x any) *StandardSocketOptions_StdSocketOption { if x == nil { return nil }; v, ok := x.(*StandardSocketOptions_StdSocketOption); if !ok { panic(ClassCast(x, StandardSocketOptions_StdSocketOption_class)) }; return v }
