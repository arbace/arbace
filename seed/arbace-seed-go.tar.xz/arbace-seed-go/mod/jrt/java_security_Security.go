//line java_security_Security.ae:1
package jrt




















func Security_SetProperty_String_String__V(key, datum *String) { Security_Init()
	Security_SecPropLoader_CheckReservedKey_String__V(key)
	Security_props.Put_O_O__O(key.Ref(), datum.Ref())
	var spe *SecurityPropertyModificationEvent = SecurityPropertyModificationEvent_New()
	spe.F_key = key
	spe.F_value = datum
	NN(spe).Commit__V()
}

func Security_SecPropLoader_LoadMaster__V() { Security_SecPropLoader_Init()
	var is InputStream_I = Security_class.GetResourceAsStream_String__InputStream(Lit_1666)
	if is == nil {
		panic(Thrown(InternalError_New_String_Throwable(Lit_1667, FileNotFoundException_New_String(Lit_1668)))) }; tmp4 := func() (exc Throwable_I) { defer Catch(&exc)


			{ var in InputStream_I = is; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
				Security_SecPropLoader_DebugLoad_Z_O__V(true, Lit_1668)
				{ var tmp1 Properties_I; Security_Init(); tmp1 = Security_props; tmp1.Load_InputStream__V(in)
					Security_SecPropLoader_DebugLoad_Z_O__V(false, Lit_1668) }; return nil }()
//line :37:1
				if tmp2 == nil { if !(in == nil) { in.Close__V() } }; if tmp2 != nil { if true { var t_101252 Throwable_I = tmp2; if !(in == nil) { tmp3 := func() (exc Throwable_I) { defer Catch(&exc); in.Close__V(); return nil }(); if tmp3 != nil { if true { var x_101253 Throwable_I = tmp3; t_101252.AddSuppressed_Throwable__V(x_101253) } } }; panic(Thrown(t_101252))
				}
				} }
			return nil }()
//line :36:1
	if tmp4 != nil { if IOException_InstanceOf(tmp4) { var e IOException_I = IOException_Cast(tmp4)





		panic(Thrown(InternalError_New_String_Throwable(Lit_1667, e))) } else {
//line :36:1
			panic(tmp4) } } }
//line :34:1
func (t *Security_1) Put_O_O__O(key, val any) any { MonitorEnter(t); defer MonitorExit(t)
	var tmp1 any = key; if String_InstanceOf(tmp1) { var strKey *String = String_Cast(tmp1); var tmp2 any = val
		if String_InstanceOf(tmp2) { var strVal *String = String_Cast(tmp2)
			if Security_SecPropLoader_IsInclude_String__Z(strKey) { Security_SecPropLoader_LoadInclude_String__V(strVal); return nil } } else { } } else { }
	return t.Properties.Impl_Put_O_O__O(t, key, val)
}



















func Security_SecPropLoader_LoadAll__V() { Security_SecPropLoader_Init()
	Security_SecPropLoader_LoadMaster__V()
	Security_SecPropLoader_LoadExtra__V()
}
func Security_SecPropLoader_IsInclude_String__Z(key *String) bool { Security_SecPropLoader_Init()
	return Lit_1663.Equals_O__Z(key.Ref())
}
func Security_SecPropLoader_CheckReservedKey_String__V(key *String) { Security_SecPropLoader_Init()
	if Security_SecPropLoader_IsInclude_String__Z(key) {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_1664, key, Lit_1665))))
	}
}









func Security_SecPropLoader_LoadExtra__V() { Security_SecPropLoader_Init()
	var tmp1 Properties_I; Security_Init(); tmp1 = Security_props; if Lit_107.EqualsIgnoreCase_String__Z(tmp1.GetProperty_String__String(Lit_1669)) {
		var propFile *String = System_GetProperty_String__String(Lit_1670)
		if !(propFile == nil) {
			var mode *Security_SecPropLoader_LoadingMode; Security_SecPropLoader_LoadingMode_Init(); mode = Security_SecPropLoader_LoadingMode_APPEND
			if NN(propFile).StartsWith_String__Z(Lit_1171) {
				var tmp2 *Security_SecPropLoader_LoadingMode; Security_SecPropLoader_LoadingMode_Init(); tmp2 = Security_SecPropLoader_LoadingMode_OVERRIDE; mode = tmp2
				propFile = NN(propFile).Substring_I__String(1) }; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

					Security_SecPropLoader_LoadExtraHelper_String_Security_SecPropLoader_LoadingMode__V(propFile, mode); return nil }()
//line :88:1
			if tmp3 != nil { if Exception_InstanceOf(tmp3) { var e Exception_I = Exception_Cast(tmp3); var tmp4 *Debug


				Security_Init(); tmp4 = Security_sdebug; if !(tmp4 == nil) {
					var tmp5 *Debug; Security_Init(); tmp5 = Security_sdebug; var tmp6 *Debug = tmp5; NN(tmp6).Println_String__V(Concat(Lit_1671, propFile))
					e.PrintStackTrace__V() } } else {
//line :88:1
						panic(tmp3)
					}
			}
		}
	}
}

func Security_SecPropLoader_LoadExtraHelper_String_Security_SecPropLoader_LoadingMode__V(propFile *String, mode *Security_SecPropLoader_LoadingMode) { Security_SecPropLoader_Init()

	propFile = PropertyExpander_Expand_String__String(propFile)
	if NN(propFile).IsEmpty__Z() { panic(Thrown(IOException_New_String(Lit_1672))) }
	var error_ Exception_I; var tmp1 Exception_I
	error_ = Security_SecPropLoader_LoadExtraFromPath_String_Security_SecPropLoader_LoadingMode__Exception(propFile, mode); tmp1 = error_; if !(tmp1 == nil) {
		var uri *URI; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
			uri = URI_New_String(propFile); return nil }(); if tmp2 != nil { if Exception_InstanceOf(tmp2) { var ignore Exception_I = Exception_Cast(tmp2); _ = ignore } else { panic(tmp2) } }
		var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = !(uri == nil); if tmp5 { tmp5 = Lit_61.EqualsIgnoreCase_String__Z(NN(uri).GetScheme__String()) }; tmp4 = tmp5; if tmp4 {
			var tmp6 Exception_I; error_ = Security_SecPropLoader_LoadExtraFromFileUrl_URI_Security_SecPropLoader_LoadingMode__Exception(uri, mode); tmp6 = error_; tmp4 = tmp6 == nil }
//line :103:1
		tmp3 = tmp4; if tmp3 { } else {

			var url *URL; tmp7 := func() (exc Throwable_I) { defer Catch(&exc)

				url = Security_NewURL_String__URL(propFile)
//line :105:1
				return nil }()
			if tmp7 != nil { if MalformedURLException_InstanceOf(tmp7) { var ignore_2 *MalformedURLException = MalformedURLException_Cast(tmp7); _ = ignore_2

				panic(Thrown(error_)) } else {
//line :106:1
					panic(tmp7)
				}
			}
			Security_SecPropLoader_LoadFromUrl_URL_Security_SecPropLoader_LoadingMode__V(url, mode)
		} } }
func Security_SecPropLoader_LoadExtraFromPath_String_Security_SecPropLoader_LoadingMode__Exception(propFile *String, mode *Security_SecPropLoader_LoadingMode) Exception_I { Security_SecPropLoader_Init()

	var path Path; tmp1, tmp2, tmp3 := func() (ctl int32, rv Exception_I, exc Throwable_I) { defer Catch(&exc)

		path = Path_Of_String_String1__Path(propFile, RefArrayOf(String_class))
		if Files_Exists_Path_LinkOption1__Z(path, RefArrayOf(LinkOption_class)) { } else { return 2, FileNotFoundException_New_String(propFile), nil }; return 0, nil, nil }()
//line :114:1
	if tmp3 != nil { if InvalidPathException_InstanceOf(tmp3) { var e *InvalidPathException = InvalidPathException_Cast(tmp3)


		return Up_InvalidPathException_Exception(e) } else {
//line :114:1
			panic(tmp3) } }; switch tmp1 { case 2: { return tmp2
			}
			}

	Security_SecPropLoader_LoadFromPath_Path_Security_SecPropLoader_LoadingMode__V(path, mode)
//line :113:1
	return nil
}






func Security_SecPropLoader_LoadExtraFromFileUrl_URI_Security_SecPropLoader_LoadingMode__Exception(uri *URI, mode *Security_SecPropLoader_LoadingMode) Exception_I { Security_SecPropLoader_Init()

	var path Path; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
		path = Path_Of_URI__Path(uri); return nil }(); if tmp1 != nil { if Exception_InstanceOf(tmp1) { var e Exception_I = Exception_Cast(tmp1); return e } else { panic(tmp1) } }
	Security_SecPropLoader_LoadFromPath_Path_Security_SecPropLoader_LoadingMode__V(path, mode)
//line :123:1
	return nil
}



func Security_SecPropLoader_Reset_Security_SecPropLoader_LoadingMode__V(mode *Security_SecPropLoader_LoadingMode) { Security_SecPropLoader_Init()
	var tmp1 *Security_SecPropLoader_LoadingMode; Security_SecPropLoader_LoadingMode_Init(); tmp1 = Security_SecPropLoader_LoadingMode_OVERRIDE; if mode == tmp1 {
		var tmp2 *Debug; Security_Init(); tmp2 = Security_sdebug; if !(tmp2 == nil) { var tmp3 *Debug; Security_Init(); tmp3 = Security_sdebug; NN(tmp3).Println_String__V(Lit_1673) }
		var tmp4 Properties_I; Security_Init(); tmp4 = Security_props; tmp4.Clear__V()
	} }
func Security_SecPropLoader_LoadInclude_String__V(propFile *String) { Security_SecPropLoader_Init()
	var expPropFile *String = PropertyExpander_ExpandNonStrict_String__String(propFile); var tmp1 *Debug
	Security_Init(); tmp1 = Security_sdebug; if !(tmp1 == nil) {
		var tmp2 *Debug; Security_Init(); tmp2 = Security_sdebug; var tmp3 *Debug = tmp2; var tmp4 *String



		if NN(propFile).Equals_O__Z(expPropFile.Ref()) { tmp4 = Lit_69 } else {

			tmp4 = Concat(Lit_1674, expPropFile, Lit_1675) }
//line :136:1
		NN(tmp3).Println_String__V(Concat(Lit_1676, propFile, Lit_1371, tmp4))
	}




	tmp7 := func() (exc Throwable_I) { defer Catch(&exc)

		{ var path Path = Path_Of_String_String1__Path(expPropFile, RefArrayOf(String_class))
			if path.IsAbsolute__Z() { } else {
				if Security_SecPropLoader_currentPath == nil {
					panic(Thrown(InternalError_New_String(Concat(Lit_1677, expPropFile, Lit_1678))))
				}




				path = Security_SecPropLoader_currentPath.ResolveSibling_Path__Path(path) }
			var tmp5 Path = path; var tmp6 *Security_SecPropLoader_LoadingMode; Security_SecPropLoader_LoadingMode_Init(); tmp6 = Security_SecPropLoader_LoadingMode_APPEND; Security_SecPropLoader_LoadFromPath_Path_Security_SecPropLoader_LoadingMode__V(tmp5, tmp6) }; return nil }()
//line :143:1
	if tmp7 != nil { if IOException_InstanceOf(tmp7) || InvalidPathException_InstanceOf(tmp7) { var e Exception_I = Exception_Cast(tmp7)












		panic(Thrown(InternalError_New_String_Throwable(Concat(Lit_1679, expPropFile, Lit_1371), e))) } else {
//line :143:1
			panic(tmp7)
		}
	}
}











func Security_SecPropLoader_CheckCyclicInclude_Path__V(path Path) { Security_SecPropLoader_Init()
	var i_101254 Iterator = Security_SecPropLoader_activePaths.Iterator__Iterator(); for i_101254.HasNext__Z() { var activePath Path = Path_Cast(i_101254.Next__O()); tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

		if Files_IsSameFile_Path_Path__Z(path, activePath) {
			panic(Thrown(InternalError_New_String(Concat(Lit_1680, StrOfObj(path), Lit_1371)))) }; return nil }()
//line :160:1
		if tmp1 != nil { if IOException_InstanceOf(tmp1) { var e IOException_I = IOException_Cast(tmp1); var tmp2 *Debug



			Security_Init(); tmp2 = Security_sdebug; if !(tmp2 == nil) {
				var tmp3 *Debug; Security_Init(); tmp3 = Security_sdebug; var tmp4 *Debug = tmp3; NN(tmp4).Println_String__V(Concat(Lit_1681, StrOfObj(path), Lit_1309))



				e.PrintStackTrace__V() } } else {
//line :160:1
					panic(tmp1)
				}
		}
	}
}






func Security_SecPropLoader_LoadFromPath_Path_Security_SecPropLoader_LoadingMode__V(path Path, mode *Security_SecPropLoader_LoadingMode) { Security_SecPropLoader_Init()

	if Files_IsDirectory_Path_LinkOption1__Z(path, RefArrayOf(LinkOption_class)) { panic(Thrown(IOException_New_String(Lit_1682))) }
	var is InputStream_I = Files_NewInputStream_Path_OpenOption1__InputStream(path, RefArrayOf(OpenOption_class)); tmp4 := func() (exc Throwable_I) { defer Catch(&exc)
		Security_SecPropLoader_CheckCyclicInclude_Path__V(path)
		Security_SecPropLoader_Reset_Security_SecPropLoader_LoadingMode__V(mode)
		{ var previousPath Path = Security_SecPropLoader_currentPath; var tmp1 Path
			if Files_IsRegularFile_Path_LinkOption1__Z(path, RefArrayOf(LinkOption_class)) { tmp1 = path } else { tmp1 = nil }; Security_SecPropLoader_currentPath = tmp1
			Security_SecPropLoader_activePaths.Add_O__Z(path); tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

				Security_SecPropLoader_DebugLoad_Z_O__V(true, path)
				{ var tmp2 Properties_I; Security_Init(); tmp2 = Security_props; tmp2.Load_InputStream__V(is)
					Security_SecPropLoader_DebugLoad_Z_O__V(false, path) }; return nil }()
			Security_SecPropLoader_activePaths.RemoveLast__O(); Security_SecPropLoader_currentPath = previousPath
//line :180:1
			if tmp3 != nil { panic(tmp3)
			}
		}

		return nil }()
//line :174:1
	if tmp4 == nil { if !(is == nil) { is.Close__V() } }; if tmp4 != nil { if true { var t_101255 Throwable_I = tmp4; if !(is == nil) { tmp5 := func() (exc Throwable_I) { defer Catch(&exc); is.Close__V(); return nil }(); if tmp5 != nil { if true { var x_101256 Throwable_I = tmp5; t_101255.AddSuppressed_Throwable__V(x_101256) } } }; panic(Thrown(t_101255))
	}
	}
}








func Security_SecPropLoader_LoadFromUrl_URL_Security_SecPropLoader_LoadingMode__V(url *URL, mode *Security_SecPropLoader_LoadingMode) { Security_SecPropLoader_Init()
	var is InputStream_I = NN(url).OpenStream__InputStream(); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		Security_SecPropLoader_Reset_Security_SecPropLoader_LoadingMode__V(mode)
		Security_SecPropLoader_DebugLoad_Z_O__V(true, url.Ref())
		{ var tmp1 Properties_I; Security_Init(); tmp1 = Security_props; tmp1.Load_InputStream__V(is)
			Security_SecPropLoader_DebugLoad_Z_O__V(false, url.Ref()) }; return nil }()
//line :187:1
	if tmp2 == nil { if !(is == nil) { is.Close__V() } }; if tmp2 != nil { if true { var t_101257 Throwable_I = tmp2; if !(is == nil) { tmp3 := func() (exc Throwable_I) { defer Catch(&exc); is.Close__V(); return nil }(); if tmp3 != nil { if true { var x_101258 Throwable_I = tmp3; t_101257.AddSuppressed_Throwable__V(x_101258) } } }; panic(Thrown(t_101257))
	}
	}
}


func Security_SecPropLoader_DebugLoad_Z_O__V(start bool, source any) { Security_SecPropLoader_Init()
	var tmp1 *Debug; Security_Init(); tmp1 = Security_sdebug; if !(tmp1 == nil) {
		var level int32; if Security_SecPropLoader_activePaths.IsEmpty__Z() { level = 1 } else { level = Security_SecPropLoader_activePaths.Size__I() }
		var tmp2 *Debug; Security_Init(); tmp2 = Security_sdebug; var tmp3 *Debug = tmp2; var tmp4 *String
		if start {
			tmp4 = Concat(Lit_1683.Repeat_I__String(level), Lit_1684) } else {
				tmp4 = Concat(Lit_1685.Repeat_I__String(level), Lit_1686) }
//line :196:1
		NN(tmp3).Println_String__V(Concat(tmp4, StrOfObj(source)))
	}
}










func Security_Initialize__V() { Security_Init()
	Security_SecPropLoader_LoadAll__V()
	Security_initialSecurityProperties = Properties_Cast(Security_props.Clone__O())
	if !(Security_sdebug == nil) {
		var i_101259 Iterator = Security_props.StringPropertyNames__Set().Iterator__Iterator(); for i_101259.HasNext__Z() { var key *String = String_Cast(i_101259.Next__O()); var tmp1 *Debug = Security_sdebug
			NN(tmp1).Println_String__V(Concat(Lit_1650, key, Lit_1171, Security_props.GetProperty_String__String(key)))
		} } }
func Security_New() *Security { Security_Init(); t := &Security{}; t.Ctor(); return t }
//line :216:1
func (t *Security) Ctor() { panic(A2g_NotTranslated("java.security.Security.<init>()V")) }

func Security_GetProviderProperty_String__Security_ProviderProperty(key *String) *Security_ProviderProperty { Security_Init()
	var providers List = NN(Providers_GetProviderList__ProviderList()).Providers__List(); var i int32 = 0
L1: for {
	if i < providers.Size__I() {
		var matchKey *String; var prov Provider_I = Provider_Cast(providers.Get_I__O(i)); var prop *String = prov.GetProperty_String__String(key)


		if prop == nil {
			var e Enumeration = prov.Keys__Enumeration(); L2: for {
				if e.HasMoreElements__Z() {
					matchKey = String_Cast(e.NextElement__O())
					if NN(key).EqualsIgnoreCase_String__Z(matchKey) {
						prop = prov.GetProperty_String__String(matchKey) } else {
							e = e; continue L2 } }
//line :226:1
				break L2
			}
		}



		if !(prop == nil) {
			var newEntry *Security_ProviderProperty = Security_ProviderProperty_New()
			newEntry.F_className = prop
			newEntry.F_provider = prov
			return newEntry } else {
				i = i + 1; continue L1 } }
//line :220:1
	break L1 }
//line :219:1
	return nil
}



















func Security_GetProviderProperty_String_Provider__String(key *String, provider Provider_I) *String { Security_Init()
	var prop *String = provider.GetProperty_String__String(key)
	if prop == nil {
		var e Enumeration = provider.Keys__Enumeration(); L1: for {
			if e.HasMoreElements__Z() {
				var matchKey *String = String_Cast(e.NextElement__O())
				if NN(key).EqualsIgnoreCase_String__Z(matchKey) {
					prop = provider.GetProperty_String__String(matchKey) } else {
						e = e; continue L1 } }
//line :243:1
			break L1 } }
//line :241:1
	return prop
}








func Security_GetAlgorithmProperty_String_String__String(algName, propName *String) *String { Security_Init()

	var entry *Security_ProviderProperty = Security_GetProviderProperty_String__Security_ProviderProperty(Concat(Lit_1651, propName, Lit_79, algName))
	if !(entry == nil) { return entry.F_className } else { return nil
	} }
func Security_InsertProviderAt_Provider_I__I(provider Provider_I, position int32) int32 { Security_Init(); MonitorEnter(Security_class); defer MonitorExit(Security_class)
	var list *ProviderList = Providers_GetFullProviderList__ProviderList(); var newList *ProviderList = ProviderList_InsertAt_ProviderList_Provider_I__ProviderList(list, provider, position-1)

	if list == newList { return -1 } else {


		Providers_SetProviderList_ProviderList__V(newList)
		return NN(newList).GetIndex_String__I(provider.GetName__String()) + 1
	} }
func Security_AddProvider_Provider__I(provider Provider_I) int32 { Security_Init()
	return Security_InsertProviderAt_Provider_I__I(provider, 0)
}
func Security_RemoveProvider_String__V(name *String) { Security_Init(); MonitorEnter(Security_class); defer MonitorExit(Security_class)
	var list *ProviderList = Providers_GetFullProviderList__ProviderList(); var newList *ProviderList = ProviderList_Remove_ProviderList_String__ProviderList(list, name)

	Providers_SetProviderList_ProviderList__V(newList)
}
func Security_GetProviders__Provider1() *RefArray { Security_Init()
	return NN(Providers_GetFullProviderList__ProviderList()).ToArray__Provider1()
}
func Security_GetProvider_String__Provider(name *String) Provider_I { Security_Init()
	return NN(Providers_GetProviderList__ProviderList()).GetProvider_String__Provider(name)
}
func Security_GetProviders_String__Provider1(filter *String) *RefArray { Security_Init()
	var key *String; var value *String; var index int32 = NN(filter).IndexOf_I__I(58)


	if index == -1 {
		key = NN(filter).Trim__String(); value = Lit_69 } else {

			key = NN(NN(filter).Substring_I_I__String(0, index)).Trim__String()
			value = NN(NN(filter).Substring_I__String(index + 1)).Trim__String()
			if NN(value).IsEmpty__Z() { panic(Thrown(InvalidParameterException_New_String(Lit_1652))) } }
	var hashtableFilter Hashtable_I = Hashtable_New_I(1)
	hashtableFilter.Put_O_O__O(key.Ref(), value.Ref())
	return Security_GetProviders_Map__Provider1(hashtableFilter)
}
func Security_GetProviders_Map__Provider1(filter Map) *RefArray { Security_Init()
	var allProviders *RefArray = Security_GetProviders__Provider1(); var entries Set = filter.EntrySet__Set(); var tmp1 bool; var tmp2 bool

	tmp2 = allProviders == nil; if !tmp2 { tmp2 = int32(len(allProviders.A)) == 0 }; tmp1 = tmp2; if tmp1 { return nil } else {
		if entries == nil { return allProviders } else {

			if entries.IsEmpty__Z() { return nil } else {
				var candidates LinkedList_I = LinkedList_New_Collection(Arrays_AsList_O1__List(allProviders)); var i_101260 Iterator = entries.Iterator__Iterator(); for i_101260.HasNext__Z() {

					var e Map_Entry = Map_Entry_Cast(i_101260.Next__O()); var cr *Security_Criteria = Security_Criteria_New_String_String(String_Cast(e.GetKey__O()), String_Cast(e.GetValue__O()))

					candidates.RemoveIf_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var p Provider_I = Provider_Cast(p0); return !NN(cr).IsCriterionSatisfied_Provider__Z(p) }})


					if candidates.IsEmpty__Z() { return nil } }
				return A2g_CastArray[*RefArray](candidates.ToArray_O1__O1(NewRefArray(Provider_class, 0)).Ref(), Provider_class.ArrayClass())
			}
		}
	} }
func Security_GetSpiClass_String__Class(type_ *String) *Class { Security_Init()
	var clazz *Class = Class_Cast(Security_spiMap.Get_O__O(type_.Ref()))
	if !(clazz == nil) { return clazz } else {

		var tmp1 *Class; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
			clazz = Class_ForName_String__Class(Concat(Lit_1653, type_, Lit_1654))
			Security_spiMap.Put_O_O__O(type_.Ref(), clazz.Ref())
//line :316:1
			tmp1 = clazz

			return nil }()
//line :316:1
		if tmp2 != nil { if ClassNotFoundException_InstanceOf(tmp2) { var e *ClassNotFoundException = ClassNotFoundException_Cast(tmp2)



			panic(Thrown(AssertionError_New_String_Throwable(Lit_1655, Up_ClassNotFoundException_Throwable(e)))) } else {
//line :316:1
				panic(tmp2) } }; return tmp1
	}
}



func Security_GetImpl_String_String_String__O1(p0, p1, p2 *String) *RefArray { Security_Init(); panic(A2g_NotTranslated("java.security.Security.getImpl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/Object;")) }






func Security_GetImpl_String_String_String_O__O1(p0, p1, p2 *String, p3 any) *RefArray { Security_Init(); panic(A2g_NotTranslated("java.security.Security.getImpl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)[Ljava/lang/Object;")) }













func Security_GetImpl_String_String_Provider__O1(algorithm, type_ *String, provider Provider_I) *RefArray { Security_Init()


	return NN(GetInstance_GetInstance_String_Class_String_Provider__GetInstance_Instance(type_, Security_GetSpiClass_String__Class(type_), algorithm, provider)).ToArray__O1()
}
func Security_GetImpl_String_String_Provider_O__O1(p0, p1 *String, p2 Provider_I, p3 any) *RefArray { Security_Init(); panic(A2g_NotTranslated("java.security.Security.getImpl(Ljava/lang/String;Ljava/lang/String;Ljava/security/Provider;Ljava/lang/Object;)[Ljava/lang/Object;")) }





func Security_GetProperty_String__String(key *String) *String { Security_Init()
	Security_SecPropLoader_CheckReservedKey_String__V(key)
	var name *String = Security_props.GetProperty_String__String(key)
	if !(name == nil) { name = NN(name).Trim__String() }
//line :356:1
	return name
}




















func Security_Criteria_New_String_String(p0, p1 *String) *Security_Criteria { t := &Security_Criteria{}; t.Ctor_String_String(p0, p1); return t }
//line :378:1
func (t *Security_Criteria) Ctor_String_String(key, value *String) {
	var snEndIndex int32 = NN(key).IndexOf_I__I(46)
	if snEndIndex <= 0 { panic(Thrown(InvalidParameterException_New_String(Lit_1652))) }
	t.F_serviceName = NN(key).Substring_I_I__String(0, snEndIndex)
	t.F_attrValue = value
	if NN(value).IsEmpty__Z() {

		t.F_algName = NN(key).Substring_I__String(snEndIndex + 1)
		t.F_attrName = nil } else {
			var algEndIndex int32 = NN(key).IndexOf_I_I__I(32, snEndIndex)
			if algEndIndex == -1 {
				panic(Thrown(InvalidParameterException_New_String(Lit_1656))) }
			t.F_algName = NN(key).Substring_I_I__String(snEndIndex+1, algEndIndex)
			t.F_attrName = NN(NN(key).Substring_I__String(algEndIndex + 1)).Trim__String()
			if NN(t.F_attrName).IsEmpty__Z() {

				panic(Thrown(InvalidParameterException_New_String(Lit_1657))) } else {
//line :392:1
					var tmp1 bool; var tmp2 bool


					tmp2 = t.IsCompositeValue__Z(); if tmp2 { tmp2 = !(NN(t.F_attrValue).IndexOf_I__I(124) == -1) }; tmp1 = tmp2
//line :392:1
					if tmp1 {



						panic(Thrown(InvalidParameterException_New_String(Lit_1658)))
					} } }
	var tmp3 bool; var tmp4 bool; tmp4 = NN(t.F_serviceName).IsEmpty__Z(); if !tmp4 { tmp4 = NN(t.F_algName).IsEmpty__Z() }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(InvalidParameterException_New_String(Lit_1659)))
	} }
func (t *Security_Criteria) IsCompositeValue__Z() bool {
	var tmp1 bool; tmp1 = !(t.F_attrName == nil); if tmp1 {
		var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = NN(t.F_attrName).EqualsIgnoreCase_String__Z(Lit_1634); if !tmp4 {
			tmp4 = NN(t.F_attrName).EqualsIgnoreCase_String__Z(Lit_1660) }
//line :403:1
		tmp3 = tmp4; if !tmp3 {

			tmp3 = NN(t.F_attrName).EqualsIgnoreCase_String__Z(Lit_1661) }
//line :403:1
		tmp2 = tmp3; if !tmp2 {


			tmp2 = NN(t.F_attrName).EqualsIgnoreCase_String__Z(Lit_31) }
//line :403:1
		tmp1 = tmp2 }
//line :402:1
	return tmp1
}




func (t *Security_Criteria) IsCriterionSatisfied_Provider__Z(prov Provider_I) bool {
	var key *String; var tmp1 *String = t.F_serviceName; var tmp2 *String = t.F_algName; var tmp3 *String


	if !(t.F_attrName == nil) { tmp3 = Concat(Lit_115, t.F_attrName) } else { tmp3 = Lit_69 }
//line :409:1
	key = Concat(tmp1, Lit_79, tmp2, tmp3); var propValue *String = Security_GetProviderProperty_String_Provider__String(key, prov)




	if propValue == nil {
		var standardName *String = Security_GetProviderProperty_String_Provider__String(Concat(Lit_1556, t.F_serviceName, Lit_79, t.F_algName), prov)


		if !(standardName == nil) {
			var tmp4 *String = t.F_serviceName; var tmp5 *String



			if !(t.F_attrName == nil) { tmp5 = Concat(Lit_115, t.F_attrName) } else { tmp5 = Lit_69 }
//line :419:1
			key = Concat(tmp4, Lit_79, standardName, tmp5)




			propValue = Security_GetProviderProperty_String_Provider__String(key, prov) }
		if propValue == nil { return false } }
	if t.F_attrName == nil { return true } else { if NN(t.F_attrName).EqualsIgnoreCase_String__Z(Lit_1662) {


		var requestedSize int32 = Integer_ParseInt_String__I(t.F_attrValue); var maxSize int32 = Integer_ParseInt_String__I(propValue)

		return requestedSize <= maxSize } else {
//line :426:1
			if t.IsCompositeValue__Z() {






				var attrValue2 *String; var tmp6 *String = t.F_attrValue; var tmp7 *Locale; Locale_Init(); tmp7 = Locale_ENGLISH; attrValue2 = NN(tmp6).ToUpperCase_Locale__String(tmp7)
				var tmp8 *String = propValue; var tmp9 *Locale; Locale_Init(); tmp9 = Locale_ENGLISH; propValue = NN(tmp8).ToUpperCase_Locale__String(tmp9)
				var propComponents *RefArray = NN(propValue).Split_String__String1(Lit_1429); var arr_101261 *RefArray = propComponents; var len_101262 int32 = int32(len(arr_101261.A)); var i_101263 int32 = 0; for ; i_101263 < len_101262; i_101263++ {
					var pc *String = As[*String](arr_101261.A[i_101263]); if NN(attrValue2).Equals_O__Z(pc.Ref()) { return true } }
//line :435:1
				return false } else {


					return NN(t.F_attrValue).EqualsIgnoreCase_String__Z(propValue)
				} } } }
func Security_GetAlgorithms_String__Set(serviceName *String) Set { Security_Init()
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = serviceName == nil; if !tmp3 { tmp3 = NN(serviceName).IsEmpty__Z() }; tmp2 = tmp3; if !tmp2 { tmp2 = NN(serviceName).EndsWith_String__Z(Lit_79) }; tmp1 = tmp2; if tmp1 {
		return Collections_EmptySet__Set() } else {
			var result HashSet_I = HashSet_New(); var providers *RefArray = Security_GetProviders__Provider1()
			var i int32 = 0
		L1: for {
			if i < int32(len(providers.A)) {
				var e Enumeration = As[Provider_I](providers.A[i]).Keys__Enumeration(); L2: for {
					if e.HasMoreElements__Z() {
						var currentKey *String; var tmp4 *String = String_Cast(e.NextElement__O()); var tmp5 *Locale; Locale_Init(); tmp5 = Locale_ENGLISH; currentKey = NN(tmp4).ToUpperCase_Locale__String(tmp5)
						var tmp6 *Locale; Locale_Init(); tmp6 = Locale_ENGLISH; if NN(currentKey).StartsWith_String__Z(NN(serviceName).ToUpperCase_Locale__String(tmp6)) {
							if NN(currentKey).IndexOf_I__I(32) < 0 {

								result.Add_O__Z(NN(currentKey).Substring_I__String(NN(serviceName).Length__I() + 1).Ref())


								e = e; continue L2 } else {
									e = e; continue L2 } } else {
										e = e; continue L2 } }
//line :447:1
					break L2
				}










				i = i + 1; continue L1 }
//line :445:1
			break L1
		}













			return Collections_UnmodifiableSet_Set__Set(result)
		} }
func Security_NewURL_String__URL(spec *String) *URL { Security_Init()
	return URL_New_String(spec)
}


type Security struct{ Object }

var Security_sdebug *Debug

var Security_props Properties_I

var Security_initialSecurityProperties Properties_I

var Security_spiMap Map

var Security_init ClassInit

func Security_Init() { if !Security_init.Done() { Security_init.Run(Security_clinit) } }

func Security_clinit() { Security_sdebug = Debug_GetInstance_String__Debug(Lit_1649); Security_props = Security_1_New()
//line :20:1
	Security_Initialize__V()












































































































































































































































































































































































































































































	Security_spiMap = ConcurrentHashMap_New()
}
func (t *Security) Ref() any { if t == nil { return nil }; return t }

func (t *Security) GetClass__Class() *Class { return Security_class }

func (t *Security) ToString__String() *String { return Object_toString(t) }

func (t *Security) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Security) CloneShallow() any { panic(CloneNotSupported(t)) }

func Security_InstanceOf(x any) bool { _, ok := x.(*Security); return ok }

func Security_Cast(x any) *Security { if x == nil { return nil }; v, ok := x.(*Security); if !ok { panic(ClassCast(x, Security_class)) }; return v }



type Security_1 struct{ Properties }

var Security_1_init ClassInit

func Security_1_Init() { if !Security_1_init.Done() { Security_1_init.Run(Security_1_clinit) } }

func Security_1_clinit() { Properties_Init() }

func Security_1_New() *Security_1 { Security_1_Init(); t := &Security_1{}; t.Ctor(); return t }

func (t *Security_1) Ctor() { t.Properties.Ctor(t) }

func (t *Security_1) LoadFromXML_InputStream__V(p0 InputStream_I) { t.Impl_LoadFromXML_InputStream__V(t, p0) }

func (t *Security_1) PropertyNames__Enumeration() Enumeration { return t.Impl_PropertyNames__Enumeration(t) }

func (t *Security_1) Rehash__V() { t.Impl_Rehash__V(t) }

func (t *Security_1) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *Security_1) Get_O__O(p0 any) any { return t.Impl_Get_O__O(t, p0) }

func (t *Security_1) CloneHashtable__Hashtable() Hashtable_I { return t.Impl_CloneHashtable__Hashtable(t) }

func (t *Security_1) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *Security_1) Clear__V() { t.Impl_Clear__V(t) }

func (t *Security_1) Load_InputStream__V(p0 InputStream_I) { t.Impl_Load_InputStream__V(t, p0) }

func (t *Security_1) SetProperty_String_String__O(p0, p1 *String) any { return t.Impl_SetProperty_String_String__O(t, p0, p1) }

func (t *Security_1) StoreToXML_OutputStream_String_Charset__V(p0 OutputStream_I, p1 *String, p2 Charset_I) { t.Impl_StoreToXML_OutputStream_String_Charset__V(t, p0, p1, p2) }

func (t *Security_1) Keys__Enumeration() Enumeration { return t.Impl_Keys__Enumeration(t) }

func (t *Security_1) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *Security_1) StoreToXML_OutputStream_String_String__V(p0 OutputStream_I, p1, p2 *String) { t.Impl_StoreToXML_OutputStream_String_String__V(t, p0, p1, p2) }

func (t *Security_1) GetProperty_String__String(p0 *String) *String { return t.Impl_GetProperty_String__String(t, p0) }

func (t *Security_1) StringPropertyNames__Set() Set { return t.Impl_StringPropertyNames__Set(t) }

func (t *Security_1) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *Security_1) Save_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_Save_OutputStream_String__V(t, p0, p1) }

func (t *Security_1) StoreToXML_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_StoreToXML_OutputStream_String__V(t, p0, p1) }

func (t *Security_1) ContainsValue_O__Z(p0 any) bool { return t.Impl_ContainsValue_O__Z(t, p0) }

func (t *Security_1) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *Security_1) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *Security_1) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *Security_1) Store_OutputStream_String__V(p0 OutputStream_I, p1 *String) { t.Impl_Store_OutputStream_String__V(t, p0, p1) }

func (t *Security_1) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *Security_1) GetProperty_String_String__String(p0, p1 *String) *String { return t.Impl_GetProperty_String_String__String(t, p0, p1) }

func (t *Security_1) EntrySet__Set() Set { return t.Impl_EntrySet__Set(t) }

func (t *Security_1) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *Security_1) Load_Reader__V(p0 Reader_I) { t.Impl_Load_Reader__V(t, p0) }

func (t *Security_1) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *Security_1) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *Security_1) ForEach_BiConsumer__V(p0 BiConsumer) { t.Impl_ForEach_BiConsumer__V(t, p0) }

func (t *Security_1) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *Security_1) List_PrintStream__V(p0 *PrintStream) { t.Impl_List_PrintStream__V(t, p0) }

func (t *Security_1) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *Security_1) Store_Writer_String__V(p0 Writer_I, p1 *String) { t.Impl_Store_Writer_String__V(t, p0, p1) }

func (t *Security_1) ContainsKey_O__Z(p0 any) bool { return t.Impl_ContainsKey_O__Z(t, p0) }

func (t *Security_1) List_PrintWriter__V(p0 *PrintWriter) { t.Impl_List_PrintWriter__V(t, p0) }

func (t *Security_1) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *Security_1) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *Security_1) Elements__Enumeration() Enumeration { return t.Impl_Elements__Enumeration(t) }

func (t *Security_1) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *Security_1) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *Security_1) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Security_1) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *Security_1) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *Security_1) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Security_1) Ref() any { if t == nil { return nil }; return t }

func (t *Security_1) GetClass__Class() *Class { return Security_1_class }

func (t *Security_1) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func Security_1_InstanceOf(x any) bool { _, ok := x.(*Security_1); return ok }

func Security_1_Cast(x any) *Security_1 { if x == nil { return nil }; v, ok := x.(*Security_1); if !ok { panic(ClassCast(x, Security_1_class)) }; return v }



type Security_Criteria struct{ Object; F_serviceName, F_algName, F_attrName, F_attrValue *String }

func (t *Security_Criteria) Ref() any { if t == nil { return nil }; return t }

func (t *Security_Criteria) GetClass__Class() *Class { return Security_Criteria_class }

func (t *Security_Criteria) ToString__String() *String { return Object_toString(t) }

func (t *Security_Criteria) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Security_Criteria) CloneShallow() any { panic(CloneNotSupported(t)) }

func Security_Criteria_InstanceOf(x any) bool { _, ok := x.(*Security_Criteria); return ok }

func Security_Criteria_Cast(x any) *Security_Criteria { if x == nil { return nil }; v, ok := x.(*Security_Criteria); if !ok { panic(ClassCast(x, Security_Criteria_class)) }; return v }



type Security_ProviderProperty struct{ Object; F_className *String; F_provider Provider_I }

func Security_ProviderProperty_New() *Security_ProviderProperty { t := &Security_ProviderProperty{}; t.Ctor(); return t }

func (t *Security_ProviderProperty) Ctor() {}

func (t *Security_ProviderProperty) Ref() any { if t == nil { return nil }; return t }

func (t *Security_ProviderProperty) GetClass__Class() *Class { return Security_ProviderProperty_class }

func (t *Security_ProviderProperty) ToString__String() *String { return Object_toString(t) }

func (t *Security_ProviderProperty) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Security_ProviderProperty) CloneShallow() any { panic(CloneNotSupported(t)) }

func Security_ProviderProperty_InstanceOf(x any) bool { _, ok := x.(*Security_ProviderProperty); return ok }

func Security_ProviderProperty_Cast(x any) *Security_ProviderProperty { if x == nil { return nil }; v, ok := x.(*Security_ProviderProperty); if !ok { panic(ClassCast(x, Security_ProviderProperty_class)) }; return v }



type Security_SecPropLoader struct{ Object }

var Security_SecPropLoader_OVERRIDE_SEC_PROP *String = Lit_1669

var Security_SecPropLoader_EXTRA_SYS_PROP *String = Lit_1670

var Security_SecPropLoader_currentPath Path

var Security_SecPropLoader_activePaths List

var Security_SecPropLoader_init ClassInit

func Security_SecPropLoader_Init() { if !Security_SecPropLoader_init.Done() { Security_SecPropLoader_init.Run(Security_SecPropLoader_clinit) } }

func Security_SecPropLoader_clinit() { Security_SecPropLoader_activePaths = ArrayList_New() }

func Security_SecPropLoader_New() *Security_SecPropLoader { Security_SecPropLoader_Init(); t := &Security_SecPropLoader{}; t.Ctor(); return t }

func (t *Security_SecPropLoader) Ctor() {}

func (t *Security_SecPropLoader) Ref() any { if t == nil { return nil }; return t }

func (t *Security_SecPropLoader) GetClass__Class() *Class { return Security_SecPropLoader_class }

func (t *Security_SecPropLoader) ToString__String() *String { return Object_toString(t) }

func (t *Security_SecPropLoader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Security_SecPropLoader) CloneShallow() any { panic(CloneNotSupported(t)) }

func Security_SecPropLoader_InstanceOf(x any) bool { _, ok := x.(*Security_SecPropLoader); return ok }

func Security_SecPropLoader_Cast(x any) *Security_SecPropLoader { if x == nil { return nil }; v, ok := x.(*Security_SecPropLoader); if !ok { panic(ClassCast(x, Security_SecPropLoader_class)) }; return v }



type Security_SecPropLoader_LoadingMode struct{ Enum }

func (t *Security_SecPropLoader_LoadingMode) Is_Constable() {}

var Security_SecPropLoader_LoadingMode_OVERRIDE *Security_SecPropLoader_LoadingMode

var Security_SecPropLoader_LoadingMode_APPEND *Security_SecPropLoader_LoadingMode

var Security_SecPropLoader_LoadingMode__VALUES *RefArray

var Security_SecPropLoader_LoadingMode_init ClassInit

func Security_SecPropLoader_LoadingMode_Init() { if !Security_SecPropLoader_LoadingMode_init.Done() { Security_SecPropLoader_LoadingMode_init.Run(Security_SecPropLoader_LoadingMode_clinit) } }

func Security_SecPropLoader_LoadingMode_clinit() { Security_SecPropLoader_LoadingMode_OVERRIDE = Security_SecPropLoader_LoadingMode_New_String_I(Lit_1687, 0); Security_SecPropLoader_LoadingMode_APPEND = Security_SecPropLoader_LoadingMode_New_String_I(Lit_1168, 1); Security_SecPropLoader_LoadingMode__VALUES = Security_SecPropLoader_LoadingMode_X_values__Security_SecPropLoader_LoadingMode1() }

func Security_SecPropLoader_LoadingMode_New_String_I(p0 *String, p1 int32) *Security_SecPropLoader_LoadingMode { Security_SecPropLoader_LoadingMode_Init(); t := &Security_SecPropLoader_LoadingMode{}; t.Ctor_String_I(p0, p1); return t }

func (t *Security_SecPropLoader_LoadingMode) Ctor_String_I(enumName *String, enumOrdinal int32) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal) }

func Security_SecPropLoader_LoadingMode_Values__Security_SecPropLoader_LoadingMode1() *RefArray { Security_SecPropLoader_LoadingMode_Init(); return Security_SecPropLoader_LoadingMode__VALUES.Copy() }

func Security_SecPropLoader_LoadingMode_ValueOf_String__Security_SecPropLoader_LoadingMode(p0 *String) *Security_SecPropLoader_LoadingMode { Security_SecPropLoader_LoadingMode_Init(); return Security_SecPropLoader_LoadingMode_Cast(Enum_ValueOf_Class_String__Enum(Security_SecPropLoader_LoadingMode_class, p0)) }

func Security_SecPropLoader_LoadingMode_X_values__Security_SecPropLoader_LoadingMode1() *RefArray { Security_SecPropLoader_LoadingMode_Init(); return RefArrayOf(Security_SecPropLoader_LoadingMode_class, Security_SecPropLoader_LoadingMode_OVERRIDE, Security_SecPropLoader_LoadingMode_APPEND) }

func (t *Security_SecPropLoader_LoadingMode) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *Security_SecPropLoader_LoadingMode) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *Security_SecPropLoader_LoadingMode) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *Security_SecPropLoader_LoadingMode) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.security.Security$SecPropLoader$LoadingMode.describeConstable()Ljava/util/Optional;")) }

func (t *Security_SecPropLoader_LoadingMode) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *Security_SecPropLoader_LoadingMode) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Security_SecPropLoader_LoadingMode) Ref() any { if t == nil { return nil }; return t }

func (t *Security_SecPropLoader_LoadingMode) GetClass__Class() *Class { return Security_SecPropLoader_LoadingMode_class }

func (t *Security_SecPropLoader_LoadingMode) CloneShallow() any { panic(CloneNotSupported(t)) }

func Security_SecPropLoader_LoadingMode_InstanceOf(x any) bool { _, ok := x.(*Security_SecPropLoader_LoadingMode); return ok }

func Security_SecPropLoader_LoadingMode_Cast(x any) *Security_SecPropLoader_LoadingMode { if x == nil { return nil }; v, ok := x.(*Security_SecPropLoader_LoadingMode); if !ok { panic(ClassCast(x, Security_SecPropLoader_LoadingMode_class)) }; return v }
