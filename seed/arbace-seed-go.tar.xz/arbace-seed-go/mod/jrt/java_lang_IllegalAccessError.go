//line java_lang_IllegalAccessError.ae:1
package jrt








func IllegalAccessError_New() *IllegalAccessError { t := &IllegalAccessError{}; t.Ctor(); return t }
//line :10:1
func (t *IllegalAccessError) Ctor() { t.IncompatibleClassChangeError.Ctor(t) }

func IllegalAccessError_New_String(p0 *String) *IllegalAccessError { t := &IllegalAccessError{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *IllegalAccessError) Ctor_String(s *String) { t.IncompatibleClassChangeError.Ctor_String(t, s) }







type IllegalAccessError struct{ IncompatibleClassChangeError }

const IllegalAccessError_serialVersionUID int64 = -8988904074992417891

func (t *IllegalAccessError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllegalAccessError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllegalAccessError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllegalAccessError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllegalAccessError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllegalAccessError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllegalAccessError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllegalAccessError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllegalAccessError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllegalAccessError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllegalAccessError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllegalAccessError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllegalAccessError) Ref() any { if t == nil { return nil }; return t }

func (t *IllegalAccessError) GetClass__Class() *Class { return IllegalAccessError_class }

func (t *IllegalAccessError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllegalAccessError) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllegalAccessError_InstanceOf(x any) bool { _, ok := x.(*IllegalAccessError); return ok }

func IllegalAccessError_Cast(x any) *IllegalAccessError { if x == nil { return nil }; v, ok := x.(*IllegalAccessError); if !ok { panic(ClassCast(x, IllegalAccessError_class)) }; return v }
