//line java_net_Socket.ae:1
package jrt

import "sync/atomic"



















func (t *Socket) Impl_GetAndBitwiseOrState_I__I(this Socket_I, mask int32) int32 {
L1: for {
	var s int32 = t.F_state.Load()
	if NN(Socket_U).CompareAndSetInt_O_J_I_I__Z(this, Socket_STATE_OFFSET, s, s|mask) { return s } else {

		continue L1 } }; panic("a2g: unreachable")
}
func Socket_CreateImpl__SocketImpl() SocketImpl_I { Socket_Init()
	var factory SocketImplFactory = Socket_factory.Load()
	if !(factory == nil) {
		return factory.CreateSocketImpl__SocketImpl() } else {
			return SocketImpl_CreatePlatformSocketImpl_Z__SocketImpl(false)
		} }
func (t *Socket) Impl_GetInputStream__InputStream(this Socket_I) InputStream_I {
	var s int32 = t.F_state.Load()
	if Socket_IsClosed_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if Socket_IsConnected_I__Z(s) { } else { panic(Thrown(SocketException_New_String(Lit_1356))) }
	if Socket_IsInputShutdown_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1357))) }
	var in InputStream_I = t.F_in.Load()
	if in == nil {
		in = Socket_SocketInputStream_New_Socket_InputStream(this, t.F_impl.Load().GetInputStream__InputStream())
		if NN(Socket_U).CompareAndSetReference_O_J_O_O__Z(this, Socket_IN_OFFSET, nil, in) { } else {
			in = t.F_in.Load() } }
//line :41:1
	return in
}





func (t *Socket) Impl_GetOutputStream__OutputStream(this Socket_I) OutputStream_I {
	var s int32 = t.F_state.Load()
	if Socket_IsClosed_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if Socket_IsConnected_I__Z(s) { } else { panic(Thrown(SocketException_New_String(Lit_1356))) }
	if Socket_IsOutputShutdown_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1358))) }
	var out OutputStream_I = t.F_out.Load()
	if out == nil {
		out = Socket_SocketOutputStream_New_Socket_OutputStream(this, t.F_impl.Load().GetOutputStream__OutputStream())
		if NN(Socket_U).CompareAndSetReference_O_J_O_O__Z(this, Socket_OUT_OFFSET, nil, out) { } else {
			out = t.F_out.Load() } }
//line :53:1
	return out }
//line :53:1
func Socket_IsBound_I__Z(s int32) bool { Socket_Init()
	return !(s&2 == 0)
}
func Socket_IsConnected_I__Z(s int32) bool { Socket_Init()
	return !(s&4 == 0)
}
func Socket_IsClosed_I__Z(s int32) bool { Socket_Init()
	return !(s&8 == 0) }
func (t *Socket_SocketInputStream) Read_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	return t.ImplRead_B1_I_I__I(b, off, len_) }
//line :62:1
func Socket_IsInputShutdown_I__Z(s int32) bool { Socket_Init()
	return !(s&512 == 0)
}
func Socket_IsOutputShutdown_I__Z(s int32) bool { Socket_Init()
	return !(s&1024 == 0) }
//line :65:1
func (t *Socket_SocketOutputStream) Write_B1_I_I__V(b *ByteArray, off, len_ int32) {
	t.ImplWrite_B1_I_I__V(b, off, len_)
}
func Socket_New() *Socket { Socket_Init(); t := &Socket{}; t.Ctor(t); return t }
//line :68:1
func (t *Socket) Ctor(this Socket_I) { t.F_socketLock = Object_New(); t.F_impl.Store(Socket_CreateImpl__SocketImpl()) }























func Socket_New_SocketImpl(p0 SocketImpl_I) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_SocketImpl(t, p0); return t }
//line :92:1
func (t *Socket) Ctor_SocketImpl(this Socket_I, impl SocketImpl_I) { t.F_socketLock = Object_New()
	if !(impl == nil) { t.F_impl.Store(impl)
	} }
func Socket_New_String_I(p0 *String, p1 int32) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_String_I(t, p0, p1); return t }
//line :95:1
func (t *Socket) Ctor_String_I(this Socket_I, host *String, port int32) { var tmp1 SocketAddress_I; if
									!(host == nil) {
										tmp1 = InetSocketAddress_New_String_I(host, port) } else {
											tmp1 = InetSocketAddress_New_InetAddress_I(InetAddress_GetByName_String__InetAddress(nil), port) }; /*line :95:1*/t.Ctor_SocketAddress_SocketAddress_Z(this, tmp1, nil, true) }






func Socket_New_InetAddress_I(p0 InetAddress_I, p1 int32) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_InetAddress_I(t, p0, p1); return t }
//line :102:1
func (t *Socket) Ctor_InetAddress_I(this Socket_I, address InetAddress_I, port int32) { var tmp1 SocketAddress_I; if
											!(address == nil) { tmp1 = InetSocketAddress_New_InetAddress_I(address, port) } else { tmp1 = nil }; /*line :102:1*/t.Ctor_SocketAddress_SocketAddress_Z(this, tmp1, nil, true) }




func Socket_New_String_I_InetAddress_I(p0 *String, p1 int32, p2 InetAddress_I, p3 int32) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_String_I_InetAddress_I(t, p0, p1, p2, p3); return t }
//line :107:1
func (t *Socket) Ctor_String_I_InetAddress_I(this Socket_I, host *String, port int32, localAddr InetAddress_I, localPort int32) { var tmp1 SocketAddress_I; if

	!(host == nil) {
		tmp1 = InetSocketAddress_New_String_I(host, port) } else {
			tmp1 = InetSocketAddress_New_InetAddress_I(InetAddress_GetByName_String__InetAddress(nil), port) }; /*line :107:1*/t.Ctor_SocketAddress_SocketAddress_Z(this, tmp1, InetSocketAddress_New_InetAddress_I(localAddr, localPort), true) }







func Socket_New_InetAddress_I_InetAddress_I(p0 InetAddress_I, p1 int32, p2 InetAddress_I, p3 int32) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_InetAddress_I_InetAddress_I(t, p0, p1, p2, p3); return t }
//line :115:1
func (t *Socket) Ctor_InetAddress_I_InetAddress_I(this Socket_I, address InetAddress_I, port int32, localAddr InetAddress_I, localPort int32) { var tmp1 SocketAddress_I; if

	!(address == nil) { tmp1 = InetSocketAddress_New_InetAddress_I(address, port) } else { tmp1 = nil }; /*line :115:1*/t.Ctor_SocketAddress_SocketAddress_Z(this, tmp1, InetSocketAddress_New_InetAddress_I(localAddr, localPort), true) }





func Socket_New_String_I_Z(p0 *String, p1 int32, p2 bool) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_String_I_Z(t, p0, p1, p2); return t }
//line :121:1
func (t *Socket) Ctor_String_I_Z(this Socket_I, host *String, port int32, stream bool) { var tmp1 SocketAddress_I; if



	!(host == nil) {
		tmp1 = InetSocketAddress_New_String_I(host, port) } else {
			tmp1 = InetSocketAddress_New_InetAddress_I(InetAddress_GetByName_String__InetAddress(nil), port) }; /*line :121:1*/t.Ctor_SocketAddress_SocketAddress_Z(this, tmp1, nil, stream) }









func Socket_New_InetAddress_I_Z(p0 InetAddress_I, p1 int32, p2 bool) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_InetAddress_I_Z(t, p0, p1, p2); return t }
//line :131:1
func (t *Socket) Ctor_InetAddress_I_Z(this Socket_I, host InetAddress_I, port int32, stream bool) { var tmp1 SocketAddress_I; if



	!(host == nil) { tmp1 = InetSocketAddress_New_InetAddress_I(host, port) } else { tmp1 = nil }; /*line :131:1*/t.Ctor_SocketAddress_SocketAddress_Z(this, tmp1, InetSocketAddress_New_I(0), stream) }







func Socket_New_SocketAddress_SocketAddress_Z(p0, p1 SocketAddress_I, p2 bool) *Socket { Socket_Init(); t := &Socket{}; t.Ctor_SocketAddress_SocketAddress_Z(t, p0, p1, p2); return t }
//line :139:1
func (t *Socket) Ctor_SocketAddress_SocketAddress_Z(this Socket_I, address, localAddr SocketAddress_I, stream bool) { t.F_socketLock = Object_New()

	Objects_RequireNonNull_O__O(address)
	if stream { } else {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1349)))
	}
	if !A2g_AssertionsDisabled && !InetSocketAddress_InstanceOf(address) { panic(Thrown(AssertionError_New())) }
	var impl SocketImpl_I = Socket_CreateImpl__SocketImpl()
	impl.Create_Z__V(stream)
	t.F_impl.Store(impl)
	t.F_state.Store(1)
//line :146:1
	tmp1 := func() (exc Throwable_I) { defer Catch(&exc)




		if !(localAddr == nil) { this.Bind_SocketAddress__V(localAddr) }
		this.Connect_SocketAddress__V(address)
//line :146:1
		return nil
	}()


	if tmp1 != nil { if true { var throwable Throwable_I = tmp1


		t.Impl_CloseSuppressingExceptions_Throwable__V(this, throwable); panic(Thrown(throwable))
	}
	}
}




func (t *Socket) Impl_GetImpl__SocketImpl(this Socket_I) SocketImpl_I {
	if t.F_state.Load()&1 == 0 {
		var tmp1 any = t.F_socketLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
			var s int32 = t.F_state.Load()
			if s&1 == 0 {
				if Socket_IsClosed_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1332))) }
				var impl SocketImpl_I = t.F_impl.Load()
				if impl == nil { var tmp2 SocketImpl_I; impl = Socket_CreateImpl__SocketImpl(); tmp2 = impl; t.F_impl.Store(tmp2) }; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)

					impl.Create_Z__V(true); return nil }()
//line :169:1
				if tmp3 != nil { if SocketException_InstanceOf(tmp3) { var e SocketException_I = SocketException_Cast(tmp3)

					panic(Thrown(e)) } else if /*line :169:1*/ IOException_InstanceOf(tmp3) { var e_2 IOException_I = IOException_Cast(tmp3)


						panic(Thrown(SocketException_New_String_Throwable(e_2.GetMessage__String(), e_2))) } else {
//line :169:1
							panic(tmp3)
						}
				}

				t.Impl_GetAndBitwiseOrState_I__I(this, 1) } }() }
//line :161:1
	return t.F_impl.Load()
}













func (t *Socket) Impl_Impl__SocketImpl(this Socket_I) SocketImpl_I { return t.F_impl.Load() }

func (t *Socket) Impl_SetConnectedImpl_SocketImpl__V(this Socket_I, si SocketImpl_I) {
	var tmp1 any = t.F_socketLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if t.F_state.Load()&8 == 0 { } else { panic(Thrown(SocketException_New_String(Lit_1332))) }
		var previous SocketImpl_I = t.F_impl.Load()
		t.F_impl.Store(si)
		t.F_state.Store(7)
		if !(previous == nil) { t.F_in.Store(nil); t.F_out.Store(nil); previous.CloseQuietly__V()
		} }() }
func (t *Socket) Impl_SetImpl_SocketImpl__V(this Socket_I, si SocketImpl_I) { t.F_impl.Store(si) }

func (t *Socket) Impl_SetConnected__V(this Socket_I) {
	t.Impl_GetAndBitwiseOrState_I__I(this, 7)
}
func (t *Socket) Impl_Connect_SocketAddress__V(this Socket_I, endpoint SocketAddress_I) {
	this.Connect_SocketAddress_I__V(endpoint, 0)
}
func (t *Socket) Impl_Connect_SocketAddress_I__V(this Socket_I, endpoint SocketAddress_I, timeout int32) {
	if endpoint == nil { panic(Thrown(IllegalArgumentException_New_String(Lit_1350))) }
	if timeout < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1351))) }
	var s int32 = t.F_state.Load()
	if Socket_IsClosed_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if Socket_IsConnected_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1352))) }
	var tmp1 SocketAddress_I = endpoint; if InetSocketAddress_InstanceOf(tmp1) { var epoint *InetSocketAddress = InetSocketAddress_Cast(tmp1); var addr InetAddress_I = NN(epoint).GetAddress__InetAddress()

		t.Impl_CheckAddress_InetAddress_String__V(this, addr, Lit_1353); tmp2 := func() (exc Throwable_I) { defer Catch(&exc)

			t.Impl_GetImpl__SocketImpl(this).Connect_SocketAddress_I__V(Up_InetSocketAddress_SocketAddress(epoint), timeout); return nil }()
//line :203:1
		if tmp2 != nil { if IOException_InstanceOf(tmp2) { var error_ IOException_I = IOException_Cast(tmp2)

			t.Impl_CloseSuppressingExceptions_Throwable__V(this, error_); panic(Thrown(error_)) } else {
//line :203:1
				panic(tmp2)
			}
		}
		t.Impl_GetAndBitwiseOrState_I__I(this, 6) } else {
			panic(Thrown(IllegalArgumentException_New_String(Lit_1335)))
		} }
func (t *Socket) Impl_Bind_SocketAddress__V(this Socket_I, bindpoint SocketAddress_I) {
	var s int32 = t.F_state.Load()
	if Socket_IsClosed_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if Socket_IsBound_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1333))) }
	var tmp1 bool; var tmp2 bool; tmp2 = !(bindpoint == nil); if tmp2 { tmp2 = !InetSocketAddress_InstanceOf(bindpoint) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1335))) }
	var epoint *InetSocketAddress = InetSocketAddress_Cast(bindpoint); var tmp3 bool; var tmp4 bool
	tmp4 = !(epoint == nil); if tmp4 { tmp4 = NN(epoint).IsUnresolved__Z() }; tmp3 = tmp4; if tmp3 {
		panic(Thrown(SocketException_New_String(Lit_1334))) }
	if epoint == nil { epoint = InetSocketAddress_New_I(0) }
	var addr InetAddress_I = NN(epoint).GetAddress__InetAddress(); var port int32 = NN(epoint).GetPort__I()

	t.Impl_CheckAddress_InetAddress_String__V(this, addr, Lit_1354)
	t.Impl_GetImpl__SocketImpl(this).Bind_InetAddress_I__V(addr, port)
	t.Impl_GetAndBitwiseOrState_I__I(this, 2)
}
func (t *Socket) Impl_CheckAddress_InetAddress_String__V(this Socket_I, addr InetAddress_I, op *String) {
	if !(addr == nil) {
		var tmp1 bool; var tmp2 bool; tmp2 = Inet4Address_InstanceOf(addr); if !tmp2 { tmp2 = Inet6Address_InstanceOf(addr) }; tmp1 = tmp2; if tmp1 { } else {
			panic(Thrown(IllegalArgumentException_New_String(Concat(op, Lit_1355))))
		} } }
func (t *Socket) Impl_GetInetAddress__InetAddress(this Socket_I) InetAddress_I {
	if !this.IsConnected__Z() { return nil } else { tmp1, tmp2, tmp3 := func() (ctl int32, rv InetAddress_I, exc Throwable_I) { defer Catch(&exc); return 2, t.Impl_GetImpl__SocketImpl(this).GetInetAddress__InetAddress(), nil; return 0, nil, nil }()
		if tmp3 != nil { if SocketException_InstanceOf(tmp3) { var e SocketException_I = SocketException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }}
//line :231:1
		return nil
	}
}

func (t *Socket) Impl_GetLocalAddress__InetAddress(this Socket_I) InetAddress_I {
	if !this.IsBound__Z() {
		return InetAddress_AnyLocalAddress__InetAddress() } else {
			var in InetAddress_I; tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

				in = InetAddress_Cast(t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(15))
				if in.IsAnyLocalAddress__Z() { in = InetAddress_AnyLocalAddress__InetAddress() }; return nil }()
//line :239:1
			if tmp1 != nil { if Exception_InstanceOf(tmp1) { var e Exception_I = Exception_Cast(tmp1); _ = e


				in = InetAddress_AnyLocalAddress__InetAddress() } else {
//line :239:1
					panic(tmp1) } }
//line :238:1
			return in
		}
}




func (t *Socket) Impl_GetPort__I(this Socket_I) int32 {
	if !this.IsConnected__Z() { return 0 } else { tmp1, tmp2, tmp3 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc); return 2, t.Impl_GetImpl__SocketImpl(this).GetPort__I(), nil; return 0, 0, nil }()

		if tmp3 != nil { if SocketException_InstanceOf(tmp3) { var e SocketException_I = SocketException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }}; return -1
	} }
func (t *Socket) Impl_GetLocalPort__I(this Socket_I) int32 {
	if !this.IsBound__Z() { return -1 } else { tmp1, tmp2, tmp3 := func() (ctl, rv int32, exc Throwable_I) { defer Catch(&exc); return 2, t.Impl_GetImpl__SocketImpl(this).GetLocalPort__I(), nil; return 0, 0, nil }()

		if tmp3 != nil { if SocketException_InstanceOf(tmp3) { var e SocketException_I = SocketException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }}; return -1
	} }
func (t *Socket) Impl_GetRemoteSocketAddress__SocketAddress(this Socket_I) SocketAddress_I {
	if !this.IsConnected__Z() { return nil } else { return InetSocketAddress_New_InetAddress_I(this.GetInetAddress__InetAddress(), this.GetPort__I())
	} }
func (t *Socket) Impl_GetLocalSocketAddress__SocketAddress(this Socket_I) SocketAddress_I {
	if !this.IsBound__Z() { return nil } else {
		return InetSocketAddress_New_InetAddress_I(this.GetLocalAddress__InetAddress(), this.GetLocalPort__I())
	}
}




















func Socket_SocketInputStream_New_Socket_InputStream(p0 Socket_I, p1 InputStream_I) *Socket_SocketInputStream { t := &Socket_SocketInputStream{}; t.Ctor_Socket_InputStream(p0, p1); return t }
//line :283:1
func (t *Socket_SocketInputStream) Ctor_Socket_InputStream(parent Socket_I, in InputStream_I) { t.InputStream.Ctor(t)
	t.F_parent = parent
	t.F_in = in
}
func (t *Socket_SocketInputStream) Read__I() int32 {
	var a *ByteArray = NewByteArray(1); var n int32 = t.Read_B1_I_I__I(a, 0, 1); if n > 0 { return int32(a.A[0]) & 255 } else { return -1
	}
}










func (t *Socket_SocketInputStream) ImplRead_B1_I_I__I(b *ByteArray, off, len_ int32) int32 {
	var tmp1 int32; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		tmp1 = t.F_in.Read_B1_I_I__I(b, off, len_); return nil }()
//line :302:1
	if tmp2 != nil { if SocketTimeoutException_InstanceOf(tmp2) { var e *SocketTimeoutException = SocketTimeoutException_Cast(tmp2)

		panic(Thrown(Up_SocketTimeoutException_Throwable(e))) } else if /*line :302:1*/ InterruptedIOException_InstanceOf(tmp2) { var e_2 InterruptedIOException_I = InterruptedIOException_Cast(tmp2); var thread Thread_I = Thread_CurrentThread__Thread(); var tmp3 bool; var tmp4 bool




			tmp4 = thread.IsVirtual__Z(); if tmp4 { tmp4 = thread.IsInterrupted__Z() }; tmp3 = tmp4; if tmp3 {
				t.Close__V()
				panic(Thrown(SocketException_New_String(Lit_1339))) }
			panic(Thrown(e_2)) } else {
//line :302:1
				panic(tmp2) } }; return tmp1
}








func (t *Socket_SocketInputStream) GetSoTimeout__I() int32 { panic(A2g_NotTranslated("java.net.Socket$SocketInputStream.getSoTimeout()I")) }



func (t *Socket_SocketInputStream) Available__I() int32 {
	return t.F_in.Available__I()
}
func (t *Socket_SocketInputStream) Close__V() {
	t.F_parent.Close__V()
}



















func Socket_SocketOutputStream_New_Socket_OutputStream(p0 Socket_I, p1 OutputStream_I) *Socket_SocketOutputStream { t := &Socket_SocketOutputStream{}; t.Ctor_Socket_OutputStream(p0, p1); return t }
//line :341:1
func (t *Socket_SocketOutputStream) Ctor_Socket_OutputStream(parent Socket_I, out OutputStream_I) { t.OutputStream.Ctor(t)
	t.F_parent = parent
	t.F_out = out
}
func (t *Socket_SocketOutputStream) Write_I__V(b int32) {
	var a *ByteArray = ByteArrayOf(int8(b)); t.Write_B1_I_I__V(a, 0, 1)
}







func (t *Socket_SocketOutputStream) ImplWrite_B1_I_I__V(b *ByteArray, off, len_ int32) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)

	t.F_out.Write_B1_I_I__V(b, off, len_); return nil }(); if /*line :356:1*/ tmp1 != nil { if InterruptedIOException_InstanceOf(tmp1) { var e InterruptedIOException_I = InterruptedIOException_Cast(tmp1); var thread Thread_I = Thread_CurrentThread__Thread(); var tmp2 bool; var tmp3 bool



		tmp3 = thread.IsVirtual__Z(); if tmp3 { tmp3 = thread.IsInterrupted__Z() }; tmp2 = tmp3; if tmp2 {
			t.Close__V()
			panic(Thrown(SocketException_New_String(Lit_1339))) }
		panic(Thrown(e)) } else {
//line :356:1
			panic(tmp1) } } }








func (t *Socket_SocketOutputStream) Close__V() {
	t.F_parent.Close__V()
}
func (t *Socket) Impl_SetTcpNoDelay_Z__V(this Socket_I, on bool) {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(1, Boolean_ValueOf_Z__Boolean(on).Ref())
}
func (t *Socket) Impl_GetTcpNoDelay__Z(this Socket_I) bool {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	return NN(Boolean_Cast(t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(1))).BooleanValue__Z()
}
func (t *Socket) Impl_SetSoLinger_Z_I__V(this Socket_I, on bool, linger int32) {

	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if !on {
		t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(128, Boolean_ValueOf_Z__Boolean(on)) } else {

			if linger < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1359))) }
			if linger > 65535 { linger = 65535 }
			t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(128, Integer_ValueOf_I__Integer(linger))
		} }
func (t *Socket) Impl_GetSoLinger__I(this Socket_I) int32 {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	var o any = t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(128); var tmp1 any = o
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1); return NN(i).IntValue__I() } else { return -1
	} }
func (t *Socket) Impl_SendUrgentData_I__V(this Socket_I, data int32) {
	if t.Impl_GetImpl__SocketImpl(this).SupportsUrgentData__Z() { } else {
		panic(Thrown(SocketException_New_String(Lit_1360))) }
	t.Impl_GetImpl__SocketImpl(this).SendUrgentData_I__V(data)
}
func (t *Socket) Impl_SetOOBInline_Z__V(this Socket_I, on bool) {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(4099, Boolean_ValueOf_Z__Boolean(on).Ref())
}
func (t *Socket) Impl_GetOOBInline__Z(this Socket_I) bool {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	return NN(Boolean_Cast(t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(4099))).BooleanValue__Z()
}
func (t *Socket) Impl_SetSoTimeout_I__V(this Socket_I, timeout int32) {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if timeout < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1361))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(4102, Integer_ValueOf_I__Integer(timeout))
}
func (t *Socket) Impl_GetSoTimeout__I(this Socket_I) int32 {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	var o any = t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(4102); var tmp1 any = o
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1); return NN(i).IntValue__I() } else { return 0
	} }
func (t *Socket) Impl_SetSendBufferSize_I__V(this Socket_I, size int32) {
	if size <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1362))) }
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(4097, Integer_ValueOf_I__Integer(size))
}
func (t *Socket) Impl_GetSendBufferSize__I(this Socket_I) int32 {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	var result int32 = 0; var o any = t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(4097)
	var tmp1 any = o
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1); result = NN(i).IntValue__I() } else { }
//line :421:1
	return result
}



func (t *Socket) Impl_SetReceiveBufferSize_I__V(this Socket_I, size int32) {
	if size <= 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_1363))) }
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(4098, Integer_ValueOf_I__Integer(size))
}
func (t *Socket) Impl_GetReceiveBufferSize__I(this Socket_I) int32 {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	var result int32 = 0; var o any = t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(4098)
	var tmp1 any = o
	if Integer_InstanceOf(tmp1) { var i *Integer = Integer_Cast(tmp1); result = NN(i).IntValue__I() } else { }
//line :433:1
	return result
}



func (t *Socket) Impl_SetKeepAlive_Z__V(this Socket_I, on bool) {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(8, Boolean_ValueOf_Z__Boolean(on).Ref())
}
func (t *Socket) Impl_GetKeepAlive__Z(this Socket_I) bool {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	return NN(Boolean_Cast(t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(8))).BooleanValue__Z()
}
func (t *Socket) Impl_SetTrafficClass_I__V(this Socket_I, tc int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = tc < 0; if !tmp2 { tmp2 = tc > 255 }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Lit_1364))) }
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(3, Integer_ValueOf_I__Integer(tc))
}
func (t *Socket) Impl_GetTrafficClass__I(this Socket_I) int32 {
	return NN(Integer_Cast(t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(3))).IntValue__I()
}
func (t *Socket) Impl_SetReuseAddress_Z__V(this Socket_I, on bool) {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_I_O__V(4, Boolean_ValueOf_Z__Boolean(on).Ref())
}
func (t *Socket) Impl_GetReuseAddress__Z(this Socket_I) bool {
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	return NN(Boolean_Cast(t.Impl_GetImpl__SocketImpl(this).GetOption_I__O(4))).BooleanValue__Z()
}
func (t *Socket) Impl_CloseSuppressingExceptions_Throwable__V(this Socket_I, parentException Throwable_I) { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)
														this.Close__V(); return nil }(); if tmp1 != nil { if IOException_InstanceOf(tmp1) { var exception IOException_I = IOException_Cast(tmp1); parentException.AddSuppressed_Throwable__V(exception) } else { panic(tmp1) } } }

func (t *Socket) Impl_Close__V(this Socket_I) {
	var tmp1 any = t.F_socketLock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if t.F_state.Load()&8 == 0 {
			var s int32 = t.Impl_GetAndBitwiseOrState_I__I(this, 8)
			if s&9 == 1 {
				t.F_impl.Load().Close__V()
			} } }() }
func (t *Socket) Impl_ShutdownInput__V(this Socket_I) {
	var s int32 = t.F_state.Load()
	if Socket_IsClosed_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if Socket_IsConnected_I__Z(s) { } else { panic(Thrown(SocketException_New_String(Lit_1356))) }
	if Socket_IsInputShutdown_I__Z(s) {
		panic(Thrown(SocketException_New_String(Lit_1365))) }
	t.Impl_GetImpl__SocketImpl(this).ShutdownInput__V()
	t.Impl_GetAndBitwiseOrState_I__I(this, 512)
}
func (t *Socket) Impl_ShutdownOutput__V(this Socket_I) {
	var s int32 = t.F_state.Load()
	if Socket_IsClosed_I__Z(s) { panic(Thrown(SocketException_New_String(Lit_1332))) }
	if Socket_IsConnected_I__Z(s) { } else { panic(Thrown(SocketException_New_String(Lit_1356))) }
	if Socket_IsOutputShutdown_I__Z(s) {
		panic(Thrown(SocketException_New_String(Lit_1366))) }
	t.Impl_GetImpl__SocketImpl(this).ShutdownOutput__V()
	t.Impl_GetAndBitwiseOrState_I__I(this, 1024)
}
func (t *Socket) Impl_ToString__String(this Socket_I) *String { tmp1, tmp2, tmp3 := func() (ctl int32, rv *String, exc Throwable_I) { defer Catch(&exc)

	if this.IsConnected__Z() { return 2, Concat(Lit_1367, StrOfObj(t.Impl_GetImpl__SocketImpl(this).GetInetAddress__InetAddress()), Lit_1368, StrOfInt(t.Impl_GetImpl__SocketImpl(this).GetPort__I()), Lit_1344, StrOfInt(t.Impl_GetImpl__SocketImpl(this).GetLocalPort__I()), Lit_1189), nil }; return 0, nil, nil }(); if /*line :492:1*/ tmp3 != nil { if SocketException_InstanceOf(tmp3) { var e SocketException_I = SocketException_Cast(tmp3); _ = e } else { panic(tmp3) } }; switch tmp1 { case 2: { return tmp2 }}; return Lit_1369 }











func (t *Socket) Impl_IsConnected__Z(this Socket_I) bool { return Socket_IsConnected_I__Z(t.F_state.Load()) }

func (t *Socket) Impl_IsBound__Z(this Socket_I) bool { return Socket_IsBound_I__Z(t.F_state.Load()) }

func (t *Socket) Impl_IsClosed__Z(this Socket_I) bool { return Socket_IsClosed_I__Z(t.F_state.Load()) }

func (t *Socket) Impl_IsInputShutdown__Z(this Socket_I) bool {
	return Socket_IsInputShutdown_I__Z(t.F_state.Load())
}
func (t *Socket) Impl_IsOutputShutdown__Z(this Socket_I) bool {
	return Socket_IsOutputShutdown_I__Z(t.F_state.Load())
}


func Socket_SocketImplFactory__SocketImplFactory() SocketImplFactory { Socket_Init(); return Socket_factory.Load() }

func Socket_SetSocketImplFactory_SocketImplFactory__V(fac SocketImplFactory) { Socket_Init(); MonitorEnter(Socket_class); defer MonitorExit(Socket_class)
	if !(Socket_factory.Load() == nil) { panic(Thrown(SocketException_New_String(Lit_1345))) }
	Socket_factory.Store(fac)
}
func (t *Socket) Impl_SetPerformancePreferences_I_I_I__V(this Socket_I, p0, p1, p2 int32) {}




func (t *Socket) Impl_SetOption_SocketOption_O__Socket(this Socket_I, name SocketOption, value any) Socket_I {


	Objects_RequireNonNull_O__O(name)
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	t.Impl_GetImpl__SocketImpl(this).SetOption_SocketOption_O__V(name, value)
//line :529:1
	return this
}






func (t *Socket) Impl_GetOption_SocketOption__O(this Socket_I, name SocketOption) any {

	Objects_RequireNonNull_O__O(name)
	if this.IsClosed__Z() { panic(Thrown(SocketException_New_String(Lit_1332))) }
	return t.Impl_GetImpl__SocketImpl(this).GetOption_SocketOption__O(name)
}


func (t *Socket) Impl_SupportedOptions__Set(this Socket_I) Set {
	var so Set = t.F_options.Load()
	if !(so == nil) { return so } else { tmp1 := func() (exc Throwable_I) { defer Catch(&exc)



		{ var impl SocketImpl_I = t.Impl_GetImpl__SocketImpl(this)
			t.F_options.Store(Collections_UnmodifiableSet_Set__Set(impl.SupportedOptions__Set())) }; return nil }()
//line :550:1
		if tmp1 != nil { if IOException_InstanceOf(tmp1) { var e IOException_I = IOException_Cast(tmp1); _ = e


			t.F_options.Store(Collections_EmptySet__Set()) } else {
//line :550:1
				panic(tmp1) } }
//line :549:1
		return t.F_options.Load()
	}
}




type Socket struct{ Object; F_impl Volatile[SocketImpl_I]; F_state atomic.Int32; F_socketLock any; F_in Volatile[InputStream_I]; F_out Volatile[OutputStream_I]; F_options Volatile[Set] }

type Socket_I interface{ Object_I; Closeable; AutoCloseable; Self_Socket() *Socket; Impl__SocketImpl() SocketImpl_I; SetConnectedImpl_SocketImpl__V(p0 SocketImpl_I); SetImpl_SocketImpl__V(p0 SocketImpl_I); SetConnected__V(); Connect_SocketAddress__V(p0 SocketAddress_I); Connect_SocketAddress_I__V(p0 SocketAddress_I, p1 int32); Bind_SocketAddress__V(p0 SocketAddress_I); GetInetAddress__InetAddress() InetAddress_I; GetLocalAddress__InetAddress() InetAddress_I; GetPort__I() int32; GetLocalPort__I() int32; GetRemoteSocketAddress__SocketAddress() SocketAddress_I; GetLocalSocketAddress__SocketAddress() SocketAddress_I; GetInputStream__InputStream() InputStream_I; GetOutputStream__OutputStream() OutputStream_I; SetTcpNoDelay_Z__V(p0 bool); GetTcpNoDelay__Z() bool; SetSoLinger_Z_I__V(p0 bool, p1 int32); GetSoLinger__I() int32; SendUrgentData_I__V(p0 int32); SetOOBInline_Z__V(p0 bool); GetOOBInline__Z() bool; SetSoTimeout_I__V(p0 int32); GetSoTimeout__I() int32; SetSendBufferSize_I__V(p0 int32); GetSendBufferSize__I() int32; SetReceiveBufferSize_I__V(p0 int32); GetReceiveBufferSize__I() int32; SetKeepAlive_Z__V(p0 bool); GetKeepAlive__Z() bool; SetTrafficClass_I__V(p0 int32); GetTrafficClass__I() int32; SetReuseAddress_Z__V(p0 bool); GetReuseAddress__Z() bool; Close__V(); ShutdownInput__V(); ShutdownOutput__V(); IsConnected__Z() bool; IsBound__Z() bool; IsClosed__Z() bool; IsInputShutdown__Z() bool; IsOutputShutdown__Z() bool; SetPerformancePreferences_I_I_I__V(p0, p1, p2 int32); SetOption_SocketOption_O__Socket(p0 SocketOption, p1 any) Socket_I; GetOption_SocketOption__O(p0 SocketOption) any; SupportedOptions__Set() Set }

func (t *Socket) Self_Socket() *Socket { return t }

func (t *Socket) Is_Closeable() {}

func (t *Socket) Is_AutoCloseable() {}

const Socket_SOCKET_CREATED int32 = 1

const Socket_BOUND int32 = 2

const Socket_CONNECTED int32 = 4

const Socket_CLOSED int32 = 8

const Socket_SHUT_IN int32 = 512

const Socket_SHUT_OUT int32 = 1024

var Socket_factory Volatile[SocketImplFactory]

var Socket_U *Unsafe

var Socket_STATE_OFFSET int64

var Socket_IN_OFFSET int64

var Socket_OUT_OFFSET int64

var Socket_init ClassInit

func Socket_Init() { if !Socket_init.Done() { Socket_init.Run(Socket_clinit) } }

func Socket_clinit() { Socket_U = Unsafe_GetUnsafe__Unsafe(); Socket_STATE_OFFSET = NN(Socket_U).ObjectFieldOffset_Class_String__J(Socket_class, Lit_1347); Socket_IN_OFFSET = NN(Socket_U).ObjectFieldOffset_Class_String__J(Socket_class, Lit_1348); Socket_OUT_OFFSET = NN(Socket_U).ObjectFieldOffset_Class_String__J(Socket_class, Lit_50) }

func (t *Socket) GetPort__I() int32 { return t.Impl_GetPort__I(t) }

func (t *Socket) GetReuseAddress__Z() bool { return t.Impl_GetReuseAddress__Z(t) }

func (t *Socket) GetSendBufferSize__I() int32 { return t.Impl_GetSendBufferSize__I(t) }

func (t *Socket) IsOutputShutdown__Z() bool { return t.Impl_IsOutputShutdown__Z(t) }

func (t *Socket) IsConnected__Z() bool { return t.Impl_IsConnected__Z(t) }

func (t *Socket) ShutdownOutput__V() { t.Impl_ShutdownOutput__V(t) }

func (t *Socket) SetConnectedImpl_SocketImpl__V(p0 SocketImpl_I) { t.Impl_SetConnectedImpl_SocketImpl__V(t, p0) }

func (t *Socket) SupportedOptions__Set() Set { return t.Impl_SupportedOptions__Set(t) }

func (t *Socket) SetSoLinger_Z_I__V(p0 bool, p1 int32) { t.Impl_SetSoLinger_Z_I__V(t, p0, p1) }

func (t *Socket) Connect_SocketAddress_I__V(p0 SocketAddress_I, p1 int32) { t.Impl_Connect_SocketAddress_I__V(t, p0, p1) }

func (t *Socket) GetSoLinger__I() int32 { return t.Impl_GetSoLinger__I(t) }

func (t *Socket) ShutdownInput__V() { t.Impl_ShutdownInput__V(t) }

func (t *Socket) GetOOBInline__Z() bool { return t.Impl_GetOOBInline__Z(t) }

func (t *Socket) SetTrafficClass_I__V(p0 int32) { t.Impl_SetTrafficClass_I__V(t, p0) }

func (t *Socket) GetTcpNoDelay__Z() bool { return t.Impl_GetTcpNoDelay__Z(t) }

func (t *Socket) SetSoTimeout_I__V(p0 int32) { t.Impl_SetSoTimeout_I__V(t, p0) }

func (t *Socket) Close__V() { t.Impl_Close__V(t) }

func (t *Socket) GetRemoteSocketAddress__SocketAddress() SocketAddress_I { return t.Impl_GetRemoteSocketAddress__SocketAddress(t) }

func (t *Socket) SetPerformancePreferences_I_I_I__V(p0, p1, p2 int32) { t.Impl_SetPerformancePreferences_I_I_I__V(t, p0, p1, p2) }

func (t *Socket) SetReceiveBufferSize_I__V(p0 int32) { t.Impl_SetReceiveBufferSize_I__V(t, p0) }

func (t *Socket) SetImpl_SocketImpl__V(p0 SocketImpl_I) { t.Impl_SetImpl_SocketImpl__V(t, p0) }

func (t *Socket) IsClosed__Z() bool { return t.Impl_IsClosed__Z(t) }

func (t *Socket) GetLocalPort__I() int32 { return t.Impl_GetLocalPort__I(t) }

func (t *Socket) GetReceiveBufferSize__I() int32 { return t.Impl_GetReceiveBufferSize__I(t) }

func (t *Socket) SetOption_SocketOption_O__Socket(p0 SocketOption, p1 any) Socket_I { return t.Impl_SetOption_SocketOption_O__Socket(t, p0, p1) }

func (t *Socket) SetConnected__V() { t.Impl_SetConnected__V(t) }

func (t *Socket) GetLocalAddress__InetAddress() InetAddress_I { return t.Impl_GetLocalAddress__InetAddress(t) }

func (t *Socket) GetOption_SocketOption__O(p0 SocketOption) any { return t.Impl_GetOption_SocketOption__O(t, p0) }

func (t *Socket) SetKeepAlive_Z__V(p0 bool) { t.Impl_SetKeepAlive_Z__V(t, p0) }

func (t *Socket) IsBound__Z() bool { return t.Impl_IsBound__Z(t) }

func (t *Socket) GetOutputStream__OutputStream() OutputStream_I { return t.Impl_GetOutputStream__OutputStream(t) }

func (t *Socket) GetInputStream__InputStream() InputStream_I { return t.Impl_GetInputStream__InputStream(t) }

func (t *Socket) IsInputShutdown__Z() bool { return t.Impl_IsInputShutdown__Z(t) }

func (t *Socket) GetLocalSocketAddress__SocketAddress() SocketAddress_I { return t.Impl_GetLocalSocketAddress__SocketAddress(t) }

func (t *Socket) SetSendBufferSize_I__V(p0 int32) { t.Impl_SetSendBufferSize_I__V(t, p0) }

func (t *Socket) SetOOBInline_Z__V(p0 bool) { t.Impl_SetOOBInline_Z__V(t, p0) }

func (t *Socket) GetInetAddress__InetAddress() InetAddress_I { return t.Impl_GetInetAddress__InetAddress(t) }

func (t *Socket) SendUrgentData_I__V(p0 int32) { t.Impl_SendUrgentData_I__V(t, p0) }

func (t *Socket) GetSoTimeout__I() int32 { return t.Impl_GetSoTimeout__I(t) }

func (t *Socket) GetKeepAlive__Z() bool { return t.Impl_GetKeepAlive__Z(t) }

func (t *Socket) SetReuseAddress_Z__V(p0 bool) { t.Impl_SetReuseAddress_Z__V(t, p0) }

func (t *Socket) GetTrafficClass__I() int32 { return t.Impl_GetTrafficClass__I(t) }

func (t *Socket) Impl__SocketImpl() SocketImpl_I { return t.Impl_Impl__SocketImpl(t) }

func (t *Socket) SetTcpNoDelay_Z__V(p0 bool) { t.Impl_SetTcpNoDelay_Z__V(t, p0) }

func (t *Socket) Bind_SocketAddress__V(p0 SocketAddress_I) { t.Impl_Bind_SocketAddress__V(t, p0) }

func (t *Socket) Connect_SocketAddress__V(p0 SocketAddress_I) { t.Impl_Connect_SocketAddress__V(t, p0) }

func (t *Socket) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *Socket) Ref() any { if t == nil { return nil }; return t }

func (t *Socket) GetClass__Class() *Class { return Socket_class }

func (t *Socket) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Socket) CloneShallow() any { panic(CloneNotSupported(t)) }

func Socket_InstanceOf(x any) bool { _, ok := x.(Socket_I); return ok }

func Socket_Cast(x any) Socket_I { if x == nil { return nil }; v, ok := x.(Socket_I); if !ok { panic(ClassCast(x, Socket_class)) }; return v }



type Socket_SocketInputStream struct{ InputStream; F_parent Socket_I; F_in InputStream_I }

func (t *Socket_SocketInputStream) Skip_J__J(p0 int64) int64 { return t.Impl_Skip_J__J(t, p0) }

func (t *Socket_SocketInputStream) ReadAllBytes__B1() *ByteArray { return t.Impl_ReadAllBytes__B1(t) }

func (t *Socket_SocketInputStream) TransferTo_OutputStream__J(p0 OutputStream_I) int64 { return t.Impl_TransferTo_OutputStream__J(t, p0) }

func (t *Socket_SocketInputStream) Mark_I__V(p0 int32) { t.Impl_Mark_I__V(t, p0) }

func (t *Socket_SocketInputStream) ReadNBytes_B1_I_I__I(p0 *ByteArray, p1, p2 int32) int32 { return t.Impl_ReadNBytes_B1_I_I__I(t, p0, p1, p2) }

func (t *Socket_SocketInputStream) SkipNBytes_J__V(p0 int64) { t.Impl_SkipNBytes_J__V(t, p0) }

func (t *Socket_SocketInputStream) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *Socket_SocketInputStream) Reset__V() { t.Impl_Reset__V(t) }

func (t *Socket_SocketInputStream) ReadNBytes_I__B1(p0 int32) *ByteArray { return t.Impl_ReadNBytes_I__B1(t, p0) }

func (t *Socket_SocketInputStream) Read_B1__I(p0 *ByteArray) int32 { return t.Impl_Read_B1__I(t, p0) }

func (t *Socket_SocketInputStream) Ref() any { if t == nil { return nil }; return t }

func (t *Socket_SocketInputStream) GetClass__Class() *Class { return Socket_SocketInputStream_class }

func (t *Socket_SocketInputStream) ToString__String() *String { return Object_toString(t) }

func (t *Socket_SocketInputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Socket_SocketInputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func Socket_SocketInputStream_InstanceOf(x any) bool { _, ok := x.(*Socket_SocketInputStream); return ok }

func Socket_SocketInputStream_Cast(x any) *Socket_SocketInputStream { if x == nil { return nil }; v, ok := x.(*Socket_SocketInputStream); if !ok { panic(ClassCast(x, Socket_SocketInputStream_class)) }; return v }



type Socket_SocketOutputStream struct{ OutputStream; F_parent Socket_I; F_out OutputStream_I }

func (t *Socket_SocketOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *Socket_SocketOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *Socket_SocketOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *Socket_SocketOutputStream) GetClass__Class() *Class { return Socket_SocketOutputStream_class }

func (t *Socket_SocketOutputStream) ToString__String() *String { return Object_toString(t) }

func (t *Socket_SocketOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *Socket_SocketOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func Socket_SocketOutputStream_InstanceOf(x any) bool { _, ok := x.(*Socket_SocketOutputStream); return ok }

func Socket_SocketOutputStream_Cast(x any) *Socket_SocketOutputStream { if x == nil { return nil }; v, ok := x.(*Socket_SocketOutputStream); if !ok { panic(ClassCast(x, Socket_SocketOutputStream_class)) }; return v }
