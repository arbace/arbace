//line java_util_ServiceConfigurationError.ae:1
package jrt








func ServiceConfigurationError_New_String(p0 *String) *ServiceConfigurationError { t := &ServiceConfigurationError{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *ServiceConfigurationError) Ctor_String(msg *String) { t.Error.Ctor_String(t, msg) }

func ServiceConfigurationError_New_String_Throwable(p0 *String, p1 Throwable_I) *ServiceConfigurationError { t := &ServiceConfigurationError{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :12:1
func (t *ServiceConfigurationError) Ctor_String_Throwable(msg *String, cause Throwable_I) { t.Error.Ctor_String_Throwable(t, msg, cause) }







type ServiceConfigurationError struct{ Error }

const ServiceConfigurationError_serialVersionUID int64 = 74132770414881

func (t *ServiceConfigurationError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ServiceConfigurationError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ServiceConfigurationError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ServiceConfigurationError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ServiceConfigurationError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ServiceConfigurationError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ServiceConfigurationError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ServiceConfigurationError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ServiceConfigurationError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ServiceConfigurationError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ServiceConfigurationError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ServiceConfigurationError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ServiceConfigurationError) Ref() any { if t == nil { return nil }; return t }

func (t *ServiceConfigurationError) GetClass__Class() *Class { return ServiceConfigurationError_class }

func (t *ServiceConfigurationError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ServiceConfigurationError) CloneShallow() any { panic(CloneNotSupported(t)) }

func ServiceConfigurationError_InstanceOf(x any) bool { _, ok := x.(*ServiceConfigurationError); return ok }

func ServiceConfigurationError_Cast(x any) *ServiceConfigurationError { if x == nil { return nil }; v, ok := x.(*ServiceConfigurationError); if !ok { panic(ClassCast(x, ServiceConfigurationError_class)) }; return v }
