//line enum.ae:1
package jrt







// Enum_I is java.lang.Enum's class interface.
type Enum_I /*line :12:1*/ interface { Object_I
	Self_Enum() *Enum
	Is_Comparable()
	Is_Serializable()
	Name__String() *String
	Ordinal__I() int32
	CompareTo_Enum__I(o Enum_I) int32
	CompareTo_O__I(o any) int32
	GetDeclaringClass__Class() *Class }
// Enum is java.lang.Enum's struct: the constant's name and ordinal, which a2g's enum switches
// read (F_ordinal, §7.8).
//line :22:1
type Enum /*line :25:1*/ struct{ Object; F_name *String; F_ordinal int32 }

var Enum_class =
	Define(&ClassInfo{Name: "java.lang.Enum", Kind: KindClass,
				Modifiers:              AccPublic | AccAbstract, Super:                     Object_class,
				Interfaces:             []*Class{Comparable_class, Serializable_class}, Go: "arbace/jrt.Enum",
	})
// Ctor_String_I is Enum(String name, int ordinal).
func (t /*line :34:1*/*Enum) Ctor_String_I(this Enum_I, name *String, ordinal int32) {
	t.F_name = name
	t.F_ordinal = ordinal
}
func (t *Enum) Self_Enum() *Enum { return t }
func (t *Enum) Is_Comparable() {}
func (t *Enum) Is_Serializable() {}


func (t *Enum) Name__String() *String { return t.F_name }
func (t *Enum) Ordinal__I() int32 { return t.F_ordinal }

// Impl_Clone__O is Enum.clone (final): CloneNotSupportedException.
func (t /*line :48:1*/*Enum) Impl_Clone__O(this Enum_I) any {
	panic(CloneNotSupportedException_New())
}
func (t *Enum) Impl_ToString__String(this Enum_I) *String {
	return t.F_name }
// Impl_GetDeclaringClass__Class: the enum's class, also for a
// constant with a body (an anonymous subclass).
//line :54:1
func (t /*line :56:1*/*Enum) Impl_GetDeclaringClass__Class(this Enum_I) *Class {
	c := this.GetClass__Class()
	s := c.info.Super
	if s == Enum_class {
		return c
	}
	return s }
func (t *Enum) Impl_CompareTo_Enum__I(this, o Enum_I) int32 {
	if this.GetClass__Class() != o.GetClass__Class() &&
		this.GetDeclaringClass__Class() != o.GetDeclaringClass__Class() {
			panic(ClassCastException_New()) }
	return t.F_ordinal - o.Self_Enum().F_ordinal }
// Impl_CompareTo_O__I is the bridge of Comparable.compareTo.
func (t /*line :70:1*/*Enum) Impl_CompareTo_O__I(this Enum_I, o any) int32 {
	return this.CompareTo_Enum__I(Enum_Cast(o))
}
func Enum_InstanceOf(x any) bool { _, ok := x.(Enum_I); return ok }
func Enum_Cast(x any) Enum_I {
	if x == nil { return nil }
	v, ok := x.(Enum_I)
	if !ok { panic(ClassCast(x, Enum_class)) }; return v }
// Enum_ValueOf_Class_String__Enum is Enum.valueOf(Class, String): the constant of that name,
// through the class's ClassInfo.Enum.
func Enum_ValueOf_Class_String__Enum(c /*line :83:1*/*Class, name *String) Enum_I {
	if name == nil {
		panic(NullPointerException_New_String(Str("Name is null"))) }
	if NN(c).info.Enum != nil {
		for _, x := range c.info.Enum().A {
			e := Enum_Cast(x)
			if e.Self_Enum().F_name.Equals_O__Z(name) {
				return e } } }
	if c.info.Enum == nil {
		panic(IllegalArgumentException_New_String(Str(c.info.Name + " is not an enum class"))) }
	panic(IllegalArgumentException_New_String(
		Concat(Str("No enum constant "+canonicalName(c)+"."), name))) }
// canonicalName: the binary name with $ as . (member classes).
func canonicalName(c /*line :97:1*/*Class) string {
	b := []byte(c.info.Name)
	for i, x := range b {
		if x == '$' {
			b[i] = '.' } }
	return string(b)
}


// Record_I is java.lang.Record's class interface.
type Record_I /*line :108:1*/ interface{ Object_I; Self_Record() *Record }
// Record is java.lang.Record's struct (no state).
type Record struct{ Object }

var Record_class =
	Define(&ClassInfo{Name: "java.lang.Record", Kind: KindClass,
				Modifiers:                AccPublic | AccAbstract, Super: Object_class, Go: "arbace/jrt.Record",
	})
// Ctor is Record(): nothing.
func (t *Record) Ctor(this Record_I) {}
func (t *Record) Self_Record() *Record { return t }

func Record_InstanceOf(x any) bool { _, ok := x.(Record_I); return ok }
func Record_Cast(x any) Record_I {
	if x == nil { return nil }
	v, ok := x.(Record_I)
	if !ok { panic(ClassCast(x, Record_class))
	}
	return v
}
