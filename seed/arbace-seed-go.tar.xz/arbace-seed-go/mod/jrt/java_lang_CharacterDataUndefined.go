//line java_lang_CharacterDataUndefined.ae:1
package jrt






func (t *CharacterDataUndefined) GetProperties_I__I(p0 int32) int32 { panic(A2g_NotTranslated("java.lang.CharacterDataUndefined.getProperties(I)I")) }

func (t *CharacterDataUndefined) GetType_I__I(ch int32) int32 { return 0 }

func (t *CharacterDataUndefined) IsJavaIdentifierStart_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsJavaIdentifierPart_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsUnicodeIdentifierStart_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsUnicodeIdentifierPart_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsIdentifierIgnorable_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsEmoji_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsEmojiPresentation_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsEmojiModifier_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsEmojiModifierBase_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsEmojiComponent_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsExtendedPictographic_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) ToLowerCase_I__I(ch int32) int32 { return ch }

func (t *CharacterDataUndefined) ToUpperCase_I__I(ch int32) int32 { return ch }

func (t *CharacterDataUndefined) ToTitleCase_I__I(ch int32) int32 { return ch }

func (t *CharacterDataUndefined) Digit_I_I__I(ch, radix int32) int32 { return -1 }

func (t *CharacterDataUndefined) GetNumericValue_I__I(ch int32) int32 { return -1 }

func (t *CharacterDataUndefined) IsDigit_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsLowerCase_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsUpperCase_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) IsWhitespace_I__Z(ch int32) bool { return false }

func (t *CharacterDataUndefined) GetDirectionality_I__B(ch int32) int8 { return -1 }


func (t *CharacterDataUndefined) IsMirrored_I__Z(ch int32) bool { return false }



func CharacterDataUndefined_New() *CharacterDataUndefined { CharacterDataUndefined_Init(); t := &CharacterDataUndefined{}; t.Ctor(); return t }
//line :59:1
func (t *CharacterDataUndefined) Ctor() { t.CharacterData.Ctor(t) }





type CharacterDataUndefined struct{ CharacterData }

var CharacterDataUndefined_instance CharacterData_I

var CharacterDataUndefined_init ClassInit

func CharacterDataUndefined_Init() { if !CharacterDataUndefined_init.Done() { CharacterDataUndefined_init.Run(CharacterDataUndefined_clinit) } }

func CharacterDataUndefined_clinit() { CharacterDataUndefined_instance = CharacterDataUndefined_New() }

func (t *CharacterDataUndefined) IsOtherAlphabetic_I__Z(p0 int32) bool { return t.Impl_IsOtherAlphabetic_I__Z(t, p0) }

func (t *CharacterDataUndefined) IsIdeographic_I__Z(p0 int32) bool { return t.Impl_IsIdeographic_I__Z(t, p0) }

func (t *CharacterDataUndefined) ToUpperCaseCharArray_I__C1(p0 int32) *CharArray { return t.Impl_ToUpperCaseCharArray_I__C1(t, p0) }

func (t *CharacterDataUndefined) ToUpperCaseEx_I__I(p0 int32) int32 { return t.Impl_ToUpperCaseEx_I__I(t, p0) }

func (t *CharacterDataUndefined) Ref() any { if t == nil { return nil }; return t }

func (t *CharacterDataUndefined) GetClass__Class() *Class { return CharacterDataUndefined_class }

func (t *CharacterDataUndefined) ToString__String() *String { return Object_toString(t) }

func (t *CharacterDataUndefined) Clone__O() any { return A2g_ObjectClone(t) }

func (t *CharacterDataUndefined) CloneShallow() any { panic(CloneNotSupported(t)) }

func CharacterDataUndefined_InstanceOf(x any) bool { _, ok := x.(*CharacterDataUndefined); return ok }

func CharacterDataUndefined_Cast(x any) *CharacterDataUndefined { if x == nil { return nil }; v, ok := x.(*CharacterDataUndefined); if !ok { panic(ClassCast(x, CharacterDataUndefined_class)) }; return v }
