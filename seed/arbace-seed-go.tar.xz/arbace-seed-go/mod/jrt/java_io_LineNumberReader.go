//line java_io_LineNumberReader.ae:1
package jrt
























func LineNumberReader_New_Reader(p0 Reader_I) *LineNumberReader { t := &LineNumberReader{}; t.Ctor_Reader(p0); return t }
//line :26:1
func (t *LineNumberReader) Ctor_Reader(in Reader_I) { t.BufferedReader.Ctor_Reader(t, in); t.F_prevChar = 0; t.F_lineNumber = 0; t.F_skipBuffer = nil }

func LineNumberReader_New_Reader_I(p0 Reader_I, p1 int32) *LineNumberReader { t := &LineNumberReader{}; t.Ctor_Reader_I(p0, p1); return t }
//line :28:1
func (t *LineNumberReader) Ctor_Reader_I(in Reader_I, sz int32) { t.BufferedReader.Ctor_Reader_I(t, in, sz); t.F_prevChar = 0; t.F_lineNumber = 0; t.F_skipBuffer = nil }

func (t *LineNumberReader) SetLineNumber_I__V(lineNumber int32) {
	t.F_lineNumber = lineNumber
}
func (t *LineNumberReader) GetLineNumber__I() int32 { return t.F_lineNumber }

func (t *LineNumberReader) Read__I() int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); tmp3, tmp4 := func() (ctl, rv int32) { defer MonitorExit(tmp2)
		{ var c int32 = t.BufferedReader.Impl_Read__I(t)
			if t.F_skipLF { if c == 10 { c = t.BufferedReader.Impl_Read__I(t) }; t.F_skipLF = false }
			switch c { case 13:


				t.F_skipLF = true
				t.F_lineNumber = t.F_lineNumber + 1
				t.F_prevChar = 2
//line :39:1
				return 2, 10; case 10:








				t.F_lineNumber = t.F_lineNumber + 1
				t.F_prevChar = 2
//line :39:1
				return 3, 10; case -1:













				if t.F_prevChar == 1 { t.F_lineNumber = t.F_lineNumber + 1 }
				t.F_prevChar = 3
//line :39:1
			default:















				t.F_prevChar = 1}
//line :37:1
			tmp1 = c }
//line :36:1
		return 0, 0 }(); switch tmp3 { case 2: { return tmp4 }; case 3: { return tmp4 }}; return tmp1
}




















func (t *LineNumberReader) Read_C1_I_I__I(cbuf *CharArray, off, len_ int32) int32 {
	var tmp1 int32; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var n int32 = t.BufferedReader.Impl_Read_C1_I_I__I(t, cbuf, off, len_)
		if n == -1 {

			if t.F_prevChar == 1 { t.F_lineNumber = t.F_lineNumber + 1 }
			t.F_prevChar = 3
//line :62:1
			tmp1 = -1
		} else {



			var i int32 = off; L1: for {
				if i < off+n {
					var c int32 = int32(cbuf.A[i])
					if t.F_skipLF {
						t.F_skipLF = false
						if c == 10 { i = i + 1; continue L1 } }
					switch c { case 13:


						t.F_skipLF = true
						t.F_lineNumber = t.F_lineNumber + 1
						i = i + 1; continue L1; case 10:


						t.F_lineNumber = t.F_lineNumber + 1
						i = i + 1; continue L1; default:
						i = i + 1; continue L1} }
//line :67:1
				break L1
			}















			if n > 0 {
				switch int32(cbuf.A[off+n-1]) { case 13, 10:
					t.F_prevChar = 2; default:
					t.F_prevChar = 1} }
//line :66:1
			tmp1 = n } }()
//line :59:1
	return tmp1
}





























func (t *LineNumberReader) ReadLine__String() *String {
	var tmp1 *String; var tmp2 any = t.F_lock; MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var term *BooleanArray = NewBooleanArray(1); var l *String = t.BufferedReader.Impl_ReadLine_Z_Z1__String(t, t.F_skipLF, term)

		t.F_skipLF = false
		if !(l == nil) {

			t.F_lineNumber = t.F_lineNumber + 1
			var tmp3 int32; if term.A[0] { tmp3 = 2 } else { tmp3 = 3 }; t.F_prevChar = tmp3 } else {

				if t.F_prevChar == 1 { t.F_lineNumber = t.F_lineNumber + 1 }
				t.F_prevChar = 3 }
//line :92:1
		tmp1 = l }()
//line :91:1
	return tmp1
}















func (t *LineNumberReader) Skip_J__J(n int64) int64 {
	if n < 0 { panic(Thrown(IllegalArgumentException_New_String(Lit_94))) }
	var nn int32 = int32(Math_Min_J_J__J(n, 8192)); var tmp1 int64; var tmp2 any = t.F_lock
	MonitorEnter(tmp2); func() { defer MonitorExit(tmp2)
		var tmp3 bool; var tmp4 bool; tmp4 = t.F_skipBuffer == nil; if !tmp4 { tmp4 = int32(len(t.F_skipBuffer.A)) < nn }; tmp3 = tmp4; if tmp3 { t.F_skipBuffer = NewCharArray(nn) }
		var r int64 = n
	L1: for { if r > 0 {
		var tmp5 *CharArray = t.F_skipBuffer; var nc int32 = t.Read_C1_I_I__I(tmp5, 0, int32(Math_Min_J_J__J(r, int64(nn))))
		if nc == -1 { break L1 }
		r = r - int64(nc)
//line :114:1
		continue L1 }; break L1
	}


		if n-r > 0 { t.F_prevChar = 0 }
		tmp1 = n - r }()
//line :111:1
	return tmp1
}








func (t *LineNumberReader) Mark_I__V(readAheadLimit int32) {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		if t.F_skipLF { readAheadLimit = readAheadLimit + 1 }
		t.BufferedReader.Impl_Mark_I__V(t, readAheadLimit)
		t.F_markedLineNumber = t.F_lineNumber
		t.F_markedSkipLF = t.F_skipLF
	}() }
func (t *LineNumberReader) Reset__V() {
	var tmp1 any = t.F_lock; MonitorEnter(tmp1); func() { defer MonitorExit(tmp1)
		t.BufferedReader.Impl_Reset__V(t)
		t.F_lineNumber = t.F_markedLineNumber
		t.F_skipLF = t.F_markedSkipLF
	}()
}

type LineNumberReader struct{ BufferedReader; F_prevChar, F_lineNumber, F_markedLineNumber int32; F_skipLF, F_markedSkipLF bool; F_skipBuffer *CharArray }

const LineNumberReader_NONE int32 = 0

const LineNumberReader_CHAR int32 = 1

const LineNumberReader_EOL int32 = 2

const LineNumberReader_EOF int32 = 3

const LineNumberReader_maxSkipBufferSize int32 = 8192

func (t *LineNumberReader) TransferTo_Writer__J(p0 Writer_I) int64 { return t.Impl_TransferTo_Writer__J(t, p0) }

func (t *LineNumberReader) Lines__Stream() Stream { return t.Impl_Lines__Stream(t) }

func (t *LineNumberReader) ReadLine_Z_Z1__String(p0 bool, p1 *BooleanArray) *String { return t.Impl_ReadLine_Z_Z1__String(t, p0, p1) }

func (t *LineNumberReader) Close__V() { t.Impl_Close__V(t) }

func (t *LineNumberReader) Read_C1__I(p0 *CharArray) int32 { return t.Impl_Read_C1__I(t, p0) }

func (t *LineNumberReader) MarkSupported__Z() bool { return t.Impl_MarkSupported__Z(t) }

func (t *LineNumberReader) Read_CharBuffer__I(p0 CharBuffer_I) int32 { return t.Impl_Read_CharBuffer__I(t, p0) }

func (t *LineNumberReader) Ready__Z() bool { return t.Impl_Ready__Z(t) }

func (t *LineNumberReader) ReadAllLines__List() List { return t.Impl_ReadAllLines__List(t) }

func (t *LineNumberReader) ReadAllAsString__String() *String { return t.Impl_ReadAllAsString__String(t) }

func (t *LineNumberReader) Ref() any { if t == nil { return nil }; return t }

func (t *LineNumberReader) GetClass__Class() *Class { return LineNumberReader_class }

func (t *LineNumberReader) ToString__String() *String { return Object_toString(t) }

func (t *LineNumberReader) Clone__O() any { return A2g_ObjectClone(t) }

func (t *LineNumberReader) CloneShallow() any { panic(CloneNotSupported(t)) }

func LineNumberReader_InstanceOf(x any) bool { _, ok := x.(*LineNumberReader); return ok }

func LineNumberReader_Cast(x any) *LineNumberReader { if x == nil { return nil }; v, ok := x.(*LineNumberReader); if !ok { panic(ClassCast(x, LineNumberReader_class)) }; return v }
