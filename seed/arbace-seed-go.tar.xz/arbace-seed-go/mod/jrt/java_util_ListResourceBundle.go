//line java_util_ListResourceBundle.ae:1
package jrt








func (t *ListResourceBundle) Ctor(this ListResourceBundle_I) { t.ResourceBundle.Ctor(this) }

func (t *ListResourceBundle) Impl_HandleGetObject_String__O(this ListResourceBundle_I, key *String) any {
	if t.F_lookup.Load() == nil { t.Impl_LoadLookup__V(this) }
	if key == nil { panic(Thrown(NullPointerException_New())) }
	return t.F_lookup.Load().Get_O__O(key.Ref())
}
func (t *ListResourceBundle) Impl_GetKeys__Enumeration(this ListResourceBundle_I) Enumeration {
	if t.F_lookup.Load() == nil { t.Impl_LoadLookup__V(this) }
	var parent ResourceBundle_I = t.F_parent; var tmp1 Set = t.F_lookup.Load().KeySet__Set(); var tmp2 Enumeration

	if !(parent == nil) { tmp2 = parent.GetKeys__Enumeration() } else { tmp2 = nil }
//line :20:1
	return ResourceBundleEnumeration_New_Set_Enumeration(tmp1, tmp2)
}

func (t *ListResourceBundle) Impl_HandleKeySet__Set(this ListResourceBundle_I) Set {
	if t.F_lookup.Load() == nil { t.Impl_LoadLookup__V(this) }
	return t.F_lookup.Load().KeySet__Set()
}


func (t *ListResourceBundle) Impl_LoadLookup__V(this ListResourceBundle_I) { MonitorEnter(this); defer MonitorExit(this)
	if !(t.F_lookup.Load() == nil) { } else {
		var contents *RefArray = this.GetContents__O2(); var temp HashMap_I = HashMap_NewHashMap_I__HashMap(int32(len(contents.A))); var arr_101946 *RefArray = contents; var len_101947 int32 = int32(len(arr_101946.A)); var i_101948 int32 = 0; for ; i_101948 < len_101947; i_101948++ {

			var content *RefArray = As[*RefArray](arr_101946.A[i_101948]); var key *String = String_Cast(content.A[0]); var value any = content.A[1]; var tmp1 bool; var tmp2 bool


			tmp2 = key == nil; if !tmp2 { tmp2 = value == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
			temp.Put_O_O__O(key.Ref(), value) }
		t.F_lookup.Store(temp)
	}
}

type ListResourceBundle struct{ ResourceBundle; F_lookup Volatile[Map] }

type ListResourceBundle_I interface{ ResourceBundle_I; Self_ListResourceBundle() *ListResourceBundle; HandleGetObject_String__O(p0 *String) any; GetKeys__Enumeration() Enumeration; HandleKeySet__Set() Set; GetContents__O2() *RefArray }

func (t *ListResourceBundle) Self_ListResourceBundle() *ListResourceBundle { return t }

func ListResourceBundle_InstanceOf(x any) bool { _, ok := x.(ListResourceBundle_I); return ok }

func ListResourceBundle_Cast(x any) ListResourceBundle_I { if x == nil { return nil }; v, ok := x.(ListResourceBundle_I); if !ok { panic(ClassCast(x, ListResourceBundle_class)) }; return v }
