//line java_nio_file_ProviderMismatchException.ae:1
package jrt








func ProviderMismatchException_New() *ProviderMismatchException { t := &ProviderMismatchException{}; t.Ctor(); return t }
//line :10:1
func (t *ProviderMismatchException) Ctor() { t.IllegalArgumentException.Ctor(t) }

func ProviderMismatchException_New_String(p0 *String) *ProviderMismatchException { t := &ProviderMismatchException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *ProviderMismatchException) Ctor_String(msg *String) { t.IllegalArgumentException.Ctor_String(t, msg) }







type ProviderMismatchException struct{ IllegalArgumentException }

const ProviderMismatchException_serialVersionUID int64 = 4990847485741612530

func (t *ProviderMismatchException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ProviderMismatchException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ProviderMismatchException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ProviderMismatchException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ProviderMismatchException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ProviderMismatchException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ProviderMismatchException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ProviderMismatchException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ProviderMismatchException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ProviderMismatchException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ProviderMismatchException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ProviderMismatchException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ProviderMismatchException) Ref() any { if t == nil { return nil }; return t }

func (t *ProviderMismatchException) GetClass__Class() *Class { return ProviderMismatchException_class }

func (t *ProviderMismatchException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ProviderMismatchException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ProviderMismatchException_InstanceOf(x any) bool { _, ok := x.(*ProviderMismatchException); return ok }

func ProviderMismatchException_Cast(x any) *ProviderMismatchException { if x == nil { return nil }; v, ok := x.(*ProviderMismatchException); if !ok { panic(ClassCast(x, ProviderMismatchException_class)) }; return v }
