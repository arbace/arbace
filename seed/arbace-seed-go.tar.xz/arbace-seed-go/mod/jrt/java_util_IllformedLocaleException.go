//line java_util_IllformedLocaleException.ae:1
package jrt










func IllformedLocaleException_New() *IllformedLocaleException { t := &IllformedLocaleException{}; t.Ctor(); return t }
//line :12:1
func (t *IllformedLocaleException) Ctor() { t.RuntimeException.Ctor(t); t.F__errIdx = -1 }

func IllformedLocaleException_New_String(p0 *String) *IllformedLocaleException { t := &IllformedLocaleException{}; t.Ctor_String(p0); return t }
//line :14:1
func (t *IllformedLocaleException) Ctor_String(message *String) { t.RuntimeException.Ctor_String(t, message); t.F__errIdx = -1 }

func IllformedLocaleException_New_String_I(p0 *String, p1 int32) *IllformedLocaleException { t := &IllformedLocaleException{}; t.Ctor_String_I(p0, p1); return t }
//line :16:1
func (t *IllformedLocaleException) Ctor_String_I(message *String, errorIndex int32) { var tmp1 *String; if
											errorIndex < 0 { tmp1 = Lit_69 } else { tmp1 = Concat(Lit_2730, StrOfInt(errorIndex), Lit_1189) }; /*line :16:1*/t.RuntimeException.Ctor_String(t, Concat(message, tmp1)); t.F__errIdx = -1;

	t.F__errIdx = errorIndex }

func (t *IllformedLocaleException) GetErrorIndex__I() int32 { return t.F__errIdx }







type IllformedLocaleException struct{ RuntimeException; F__errIdx int32 }

const IllformedLocaleException_serialVersionUID int64 = -5245986824925681401

func (t *IllformedLocaleException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *IllformedLocaleException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *IllformedLocaleException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *IllformedLocaleException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *IllformedLocaleException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *IllformedLocaleException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *IllformedLocaleException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *IllformedLocaleException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *IllformedLocaleException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *IllformedLocaleException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *IllformedLocaleException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *IllformedLocaleException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *IllformedLocaleException) Ref() any { if t == nil { return nil }; return t }

func (t *IllformedLocaleException) GetClass__Class() *Class { return IllformedLocaleException_class }

func (t *IllformedLocaleException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *IllformedLocaleException) CloneShallow() any { panic(CloneNotSupported(t)) }

func IllformedLocaleException_InstanceOf(x any) bool { _, ok := x.(*IllformedLocaleException); return ok }

func IllformedLocaleException_Cast(x any) *IllformedLocaleException { if x == nil { return nil }; v, ok := x.(*IllformedLocaleException); if !ok { panic(ClassCast(x, IllformedLocaleException_class)) }; return v }
