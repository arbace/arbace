//line java_util_TimeZone.ae:1
package jrt













func (t *TimeZone) Ctor(this TimeZone_I) {}




func TimeZone_SetDefaultZone__TimeZone() TimeZone_I { TimeZone_Init(); MonitorEnter(TimeZone_class); defer MonitorExit(TimeZone_class)
	var zoneID *String = System_GetProperty_String__String(Lit_2882); var tmp1 bool; var tmp2 bool
	tmp2 = zoneID == nil; if !tmp2 { tmp2 = NN(zoneID).IsEmpty__Z() }; tmp1 = tmp2; if tmp1 {
		zoneID = TimeZone_GetSystemTimeZoneID_String__String(System_GetProperty_String__String(Lit_2883))
		if zoneID == nil {
			zoneID = Lit_1972 } }
	var tz TimeZone_I = TimeZone_GetTimeZone_String_Z__TimeZone(zoneID, false)
	if tz == nil {
		var gmtOffsetID *String = TimeZone_GetSystemGMTOffsetID__String()
		if !(gmtOffsetID == nil) {
			zoneID = gmtOffsetID }
		tz = TimeZone_GetTimeZone_String_Z__TimeZone(zoneID, true) }
	System_SetProperty_String_String__String(Lit_2882, zoneID)
	TimeZone_defaultTimeZone.Store(tz)
//line :26:1
	return tz
}




func (t *TimeZone) Impl_GetOffset_J__I(this TimeZone_I, date int64) int32 {
	if this.InDaylightTime_Date__Z(Date_New_J(date)) {
		return this.GetRawOffset__I() + this.GetDSTSavings__I() } else {
			return this.GetRawOffset__I()
		}
}










func (t *TimeZone) Impl_GetID__String(this TimeZone_I) *String { return t.F_ID }

func (t *TimeZone) Impl_SetID_String__V(this TimeZone_I, ID_ *String) {
	if ID_ == nil { panic(Thrown(NullPointerException_New())) }
	t.F_ID = ID_
	t.F_zoneId = nil
}
func (t *TimeZone) Impl_GetDisplayName__String(this TimeZone_I) *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return this.GetDisplayName_Z_I_Locale__String(false, 1, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *TimeZone) Impl_GetDisplayName_Locale__String(this TimeZone_I, locale *Locale) *String {
	return this.GetDisplayName_Z_I_Locale__String(false, 1, locale)
}
func (t *TimeZone) Impl_GetDisplayName_Z_I__String(this TimeZone_I, daylight bool, style int32) *String {
	var tmp1 *Locale_Category; Locale_Category_Init(); tmp1 = Locale_Category_DISPLAY; return this.GetDisplayName_Z_I_Locale__String(daylight, style, Locale_GetDefault_Locale_Category__Locale(tmp1))
}
func (t *TimeZone) Impl_GetDisplayName_Z_I_Locale__String(this TimeZone_I, daylight bool, style int32, locale *Locale) *String {
	var tmp1 bool; var tmp2 bool; tmp2 = !(style == 0); if tmp2 { tmp2 = !(style == 1) }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2878, StrOfInt(style))))) }
	var id *String = this.GetID__String(); var name *String = TimeZoneNameUtility_RetrieveDisplayName_String_Z_I_Locale__String(id, daylight, style, locale)

	if !(name == nil) { return name } else {


		var tmp3 bool; var tmp4 bool; tmp4 = NN(id).StartsWith_String__Z(Lit_1972); if tmp4 { tmp4 = NN(id).Length__I() > 3 }; tmp3 = tmp4; if tmp3 {
			var sign uint16 = NN(id).CharAt_I__C(3); var tmp5 bool; var tmp6 bool; tmp6 = int32(sign) == 43; if !tmp6 { tmp6 = int32(sign) == 45 }; tmp5 = tmp6; if tmp5 { return id } }
		var offset int32 = this.GetRawOffset__I()
		if daylight { offset = offset + this.GetDSTSavings__I() }
		return ZoneInfoFile_ToCustomID_I__String(offset)
	} }
func TimeZone_GetDisplayNames_String_Locale__String1(p0 *String, p1 *Locale) *RefArray { TimeZone_Init(); panic(A2g_NotTranslated("java.util.TimeZone.getDisplayNames(Ljava/lang/String;Ljava/util/Locale;)[Ljava/lang/String;")) }


func (t *TimeZone) Impl_GetDSTSavings__I(this TimeZone_I) int32 {
	if this.UseDaylightTime__Z() { return 3600000 } else { return 0
	}
}

func (t *TimeZone) Impl_ObservesDaylightTime__Z(this TimeZone_I) bool {
	var tmp1 bool; tmp1 = this.UseDaylightTime__Z(); if !tmp1 { tmp1 = this.InDaylightTime_Date__Z(Date_New()) }; return tmp1
}


func TimeZone_GetTimeZone_String__TimeZone(ID_ *String) TimeZone_I { TimeZone_Init()
	return TimeZone_GetTimeZone_String_Z__TimeZone(ID_, true)
}
func TimeZone_GetTimeZone_ZoneId__TimeZone(zoneId ZoneId_I) TimeZone_I { TimeZone_Init()
	var tzid *String = zoneId.GetId__String(); var tmp1 ZoneId_I = zoneId
	if ZoneOffset_InstanceOf(tmp1) { var zo *ZoneOffset = ZoneOffset_Cast(tmp1); var totalMillis int32 = NN(zo).GetTotalSeconds__I() * 1000; var tmp2 *String

		if totalMillis == 0 { tmp2 = Lit_2145 } else { tmp2 = Concat(Lit_1972, tzid) }; return ZoneInfo_New_String_I(tmp2, totalMillis) } else {

			var tmp3 bool; var tmp4 bool; tmp4 = NN(tzid).StartsWith_String__Z(Lit_2146); if tmp4 { tmp4 = !NN(tzid).Equals_O__Z(Lit_2145) }; tmp3 = tmp4; if tmp3 {
				tzid = NN(tzid).ReplaceFirst_String_String__String(Lit_2879, Lit_2880) }
			return TimeZone_GetTimeZone_String_Z__TimeZone(tzid, true)
		} }
func (t *TimeZone) Impl_ToZoneId__ZoneId(this TimeZone_I) ZoneId_I {
	var zId ZoneId_I = t.F_zoneId; if zId == nil { var tmp1 ZoneId_I; zId = t.Impl_ToZoneId0__ZoneId(this); tmp1 = zId; t.F_zoneId = tmp1 }; return zId
}
func (t *TimeZone) Impl_ToZoneId0__ZoneId(this TimeZone_I) ZoneId_I {
	var id *String = this.GetID__String(); var defaultZone TimeZone_I = TimeZone_defaultTimeZone.Load(); var tmp1 bool; var tmp2 bool; var tmp3 bool

	tmp3 = !(defaultZone == this); if tmp3 { tmp3 = !(defaultZone == nil) }; tmp2 = tmp3; if tmp2 {
		tmp2 = NN(id).Equals_O__Z(defaultZone.GetID__String().Ref()) }
//line :110:1
	tmp1 = tmp2; if tmp1 {

		return defaultZone.ToZoneId__ZoneId() } else {
			var tmp4 Map; ZoneId_Init(); tmp4 = ZoneId_SHORT_IDS; return ZoneId_Of_String_Map__ZoneId(id, tmp4)
		} }
func TimeZone_GetTimeZone_String_Z__TimeZone(ID_ *String, fallback bool) TimeZone_I { TimeZone_Init()
	var tmp1 Map; ZoneId_Init(); tmp1 = ZoneId_SHORT_IDS; if tmp1.ContainsKey_O__Z(ID_.Ref()) {
		var tmp2 *PrintStream = System_err; NN(tmp2).Printf_String_O1__PrintStream(Lit_2881, RefArrayOf(Object_class, ID_.Ref()))
	}


	var tz TimeZone_I = ZoneInfo_GetTimeZone_String__TimeZone(ID_)
	if tz == nil {
		tz = TimeZone_ParseCustomTimeZone_String__TimeZone(ID_)
		var tmp3 bool; var tmp4 bool; tmp4 = tz == nil; if tmp4 { tmp4 = fallback }; tmp3 = tmp4; if tmp3 { tz = ZoneInfo_New_String_I(Lit_1972, 0) } }
//line :121:1
	return tz
}




func TimeZone_GetAvailableIDs_I__String1(rawOffset int32) *RefArray { TimeZone_Init()
	return ZoneInfo_GetAvailableIDs_I__String1(rawOffset)
}
func TimeZone_GetAvailableIDs__String1() *RefArray { TimeZone_Init()
	return ZoneInfo_GetAvailableIDs__String1()
}
func TimeZone_AvailableIDs_I__Stream(rawOffset int32) Stream { TimeZone_Init()
	return ZoneInfo_AvailableIDs_I__Stream(rawOffset)
}
func TimeZone_AvailableIDs__Stream() Stream { TimeZone_Init()
	return ZoneInfo_AvailableIDs__Stream()
}
func TimeZone_GetSystemTimeZoneID_String__String(p0 *String) *String { return TimeZone_GetSystemTimeZoneID_String__String_native(p0) }

func TimeZone_GetSystemGMTOffsetID__String() *String { return TimeZone_GetSystemGMTOffsetID__String_native() }

func TimeZone_GetDefault__TimeZone() TimeZone_I { TimeZone_Init()
	return TimeZone_Cast(TimeZone_GetDefaultRef__TimeZone().Clone__O())
}
func TimeZone_GetDefaultRef__TimeZone() TimeZone_I { TimeZone_Init()
	var defaultZone TimeZone_I = TimeZone_defaultTimeZone.Load()
	if defaultZone == nil {
		defaultZone = TimeZone_SetDefaultZone__TimeZone()
		if !A2g_AssertionsDisabled && !!(defaultZone == nil) { panic(Thrown(AssertionError_New())) } }
//line :147:1
	return defaultZone
}



















func TimeZone_SetDefault_TimeZone__V(zone TimeZone_I) { TimeZone_Init()
	var tmp1 TimeZone_I; if !(zone == nil) { tmp1 = TimeZone_Cast(zone.Clone__O()) } else { tmp1 = nil }; TimeZone_defaultTimeZone.Store(tmp1)
}
func (t *TimeZone) Impl_HasSameRules_TimeZone__Z(this, other TimeZone_I) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = !(other == nil); if tmp2 { tmp2 = this.GetRawOffset__I() == other.GetRawOffset__I() }; tmp1 = tmp2; if tmp1 {
		tmp1 = this.UseDaylightTime__Z() == other.UseDaylightTime__Z() }
//line :172:1
	return tmp1
}

func (t *TimeZone) Impl_Clone__O(this TimeZone_I) any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc); tmp1 = A2g_ObjectClone(this); return nil }(); if tmp2 != nil { if CloneNotSupportedException_InstanceOf(tmp2) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp2); panic(Thrown(InternalError_New_Throwable(Up_CloneNotSupportedException_Throwable(e)))) } else { panic(tmp2) } }; return tmp1
}












func TimeZone_ParseCustomTimeZone_String__TimeZone(id *String) TimeZone_I { TimeZone_Init()
	var length int32 = 0; var tmp1 bool; var tmp2 bool; var tmp3 int32
	length = NN(id).Length__I(); tmp3 = length; tmp2 = tmp3 < 5; if !tmp2 {
		tmp2 = !(NN(id).IndexOf_String__I(Lit_1972) == 0) }
//line :192:1
	tmp1 = tmp2; if tmp1 { return nil } else {

		var zi *ZoneInfo
		zi = ZoneInfoFile_GetZoneInfo_String__ZoneInfo(id)
		if !(zi == nil) { return Up_ZoneInfo_TimeZone(zi) } else {

			var index int32 = 3; var negative bool = false; var c uint16; var tmp4 int32
			var old_1 int32 = index


			index = index + 1
//line :201:1
			tmp4 = old_1
//line :200:1
			c = NN(id).CharAt_I__C(tmp4)



			if int32(c) == 45 { negative = true } else { if int32(c) == 43 { } else { return nil } }
			var hours int32 = 0
			var minutes int32 = 0
			var num int32 = 0
			var countDelim int32 = 0
			var len_ int32 = 0
		L1: for { if index < length {
			c = NN(id).CharAt_I__C(index)
			index = index + 1
			if int32(c) == 58 {

				if countDelim > 1 { return nil }
				var tmp5 bool; var tmp6 bool; tmp6 = len_ == 0; if !tmp6 { tmp6 = len_ > 2 }; tmp5 = tmp6; if tmp5 { return nil }
				if countDelim == 0 {
					hours = num } else {
//line :217:1
						if countDelim == 1 {

							minutes = num } }
				countDelim = countDelim + 1
				num = 0
				len_ = 0 } else {

					var tmp7 bool; var tmp8 bool; tmp8 = int32(c) < 48; if !tmp8 { tmp8 = int32(c) > 57 }; tmp7 = tmp8; if tmp7 { return nil }
					num = num*10 + (int32(c) - 48)



					len_ = len_ + 1 }
//line :210:1
			continue L1 }; break L1
		}


















			if !(index == length) { return nil } else {
				if countDelim == 0 {

					if len_ <= 2 {
						hours = num; minutes = 0; num = 0 } else {
//line :233:1
							if len_ <= 4 {



								hours = num / 100
								minutes = num % 100
								num = 0 } else {
									return nil } } } else {
//line :231:1
										if countDelim == 1 {










											if len_ == 2 { minutes = num; num = 0 } else { return nil } } else {
												if len_ == 2 { } else { return nil } } }
				var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = hours > 23; if !tmp11 { tmp11 = minutes > 59 }; tmp10 = tmp11; if !tmp10 { tmp10 = num > 59 }; tmp9 = tmp10; if tmp9 { return nil } else {
					var gmtOffset int32 = (hours*3600 + minutes*60 + num) * 1000






					if gmtOffset == 0 {

						zi = ZoneInfoFile_GetZoneInfo_String__ZoneInfo(Lit_1972)
						if negative { NN(zi).SetID_String__V(Lit_2884) } else { NN(zi).SetID_String__V(Lit_2885) } } else {
							var tmp12 int32


							if negative { tmp12 = -gmtOffset } else { tmp12 = gmtOffset }
//line :256:1
							zi = ZoneInfoFile_GetCustomTimeZone_String_I__ZoneInfo(id, tmp12) }
//line :245:1
					return Up_ZoneInfo_TimeZone(zi) } } } } }
//line :197:1
type TimeZone struct{ Object; F_ID *String; F_zoneId ZoneId_I }

type TimeZone_I interface{ Object_I; Serializable; Cloneable; Self_TimeZone() *TimeZone; GetOffset_I_I_I_I_I_I__I(p0, p1, p2, p3, p4, p5 int32) int32; GetOffset_J__I(p0 int64) int32; SetRawOffset_I__V(p0 int32); GetRawOffset__I() int32; GetID__String() *String; SetID_String__V(p0 *String); GetDisplayName__String() *String; GetDisplayName_Locale__String(p0 *Locale) *String; GetDisplayName_Z_I__String(p0 bool, p1 int32) *String; GetDisplayName_Z_I_Locale__String(p0 bool, p1 int32, p2 *Locale) *String; GetDSTSavings__I() int32; UseDaylightTime__Z() bool; ObservesDaylightTime__Z() bool; InDaylightTime_Date__Z(p0 Date_I) bool; ToZoneId__ZoneId() ZoneId_I; HasSameRules_TimeZone__Z(p0 TimeZone_I) bool }

func (t *TimeZone) Self_TimeZone() *TimeZone { return t }

func (t *TimeZone) Is_Serializable() {}

func (t *TimeZone) Is_Cloneable() {}

const TimeZone_SHORT int32 = 0

const TimeZone_LONG int32 = 1

const TimeZone_ONE_MINUTE int32 = 60000

const TimeZone_ONE_HOUR int32 = 3600000

const TimeZone_ONE_DAY int32 = 86400000

const TimeZone_serialVersionUID int64 = 3581463369166924961

var TimeZone_NO_TIMEZONE TimeZone_I

var TimeZone_defaultTimeZone Volatile[TimeZone_I]

var TimeZone_GMT_ID *String = Lit_1972

const TimeZone_GMT_ID_LENGTH int32 = 3

var TimeZone_init ClassInit

func TimeZone_Init() { if !TimeZone_init.Done() { TimeZone_init.Run(TimeZone_clinit) } }

func TimeZone_clinit() { TimeZone_NO_TIMEZONE = nil }

func TimeZone_InstanceOf(x any) bool { _, ok := x.(TimeZone_I); return ok }

func TimeZone_Cast(x any) TimeZone_I { if x == nil { return nil }; v, ok := x.(TimeZone_I); if !ok { panic(ClassCast(x, TimeZone_class)) }; return v }
