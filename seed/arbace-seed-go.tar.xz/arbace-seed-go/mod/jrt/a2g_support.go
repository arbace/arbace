//line a2g_support.ae:1
package jrt

import (
	"math"
	"strings"
)
// Split_String__String1 is String.split(regex).
//line :6:1
func (t *String) Split_String__String1(regex *String) *RefArray { return t.Split_String_I__String1(regex, 0) }
// Split_String_I__String1 is String.split(regex, limit).
func (t *String) Split_String_I__String1(regex *String, limit int32) *RefArray { return Pattern_Compile_String__Pattern(regex).Split_CharSequence_I__String1(t, limit) }
// ReplaceAll_String_String__String is String.replaceAll.
func (t *String) ReplaceAll_String_String__String(regex, replacement *String) *String { return Pattern_Compile_String__Pattern(regex).Matcher_CharSequence__Matcher(t).ReplaceAll_String__String(replacement) }
// ReplaceFirst_String_String__String is String.replaceFirst.
func (t *String) ReplaceFirst_String_String__String(regex, replacement *String) *String { return Pattern_Compile_String__Pattern(regex).Matcher_CharSequence__Matcher(t).ReplaceFirst_String__String(replacement) }
// Matches_String__Z is String.matches.
func (t *String) Matches_String__Z(regex *String) bool { return Pattern_Matches_String_CharSequence__Z(regex, t) }

func (t *String) CodePoints__IntStream() IntStream { return CharSequence_CodePoints__IntStream(t) }

func (t *String) Chars__IntStream() IntStream { return CharSequence_Chars__IntStream(t) }

func (t *StringBuffer) CodePoints__IntStream() IntStream { return CharSequence_CodePoints__IntStream(t) }

func (t *StringBuffer) Chars__IntStream() IntStream { return CharSequence_Chars__IntStream(t) }

func (t *StringBuilder) CodePoints__IntStream() IntStream { return CharSequence_CodePoints__IntStream(t) }

func (t *StringBuilder) Chars__IntStream() IntStream { return CharSequence_Chars__IntStream(t) }

func (t *ForkJoinPool) ShutdownNow__List() List { return ForkJoinPools_ShutdownNow_ForkJoinPool__List(t) }

func (t *ForkJoinPool) InvokeAll_Collection__List(p0 Collection) List { return ForkJoinPools_InvokeAll_ForkJoinPool_Collection__List(t, p0) }

func (t *ForkJoinPool) InvokeAll_Collection_J_TimeUnit__List(p0 Collection, p1 int64, p2 *TimeUnit) List { return ForkJoinPools_InvokeAll_ForkJoinPool_Collection_J_TimeUnit__List(t, p0, p1, p2) }

func (t *ForkJoinPool) InvokeAny_Collection__O(p0 Collection) any { return ForkJoinPools_InvokeAny_ForkJoinPool_Collection__O(t, p0) }

func (t *ForkJoinPool) InvokeAny_Collection_J_TimeUnit__O(p0 Collection, p1 int64, p2 *TimeUnit) any { return ForkJoinPools_InvokeAny_ForkJoinPool_Collection_J_TimeUnit__O(t, p0, p1, p2) }
// DescribeConstable__Optional is String.describeConstable: Optional.of(this).
func (t *String) DescribeConstable__Optional() *Optional { return Optional_Of_O__Optional(t) }
// Lines__Stream is String.lines: the lines (split at \n, \r, \r\n) as a
// sequential stream (over an ArrayList: not jdk26u's lazy spliterator).
//line :40:1
func (t *String) Lines__Stream() Stream { l := ArrayList_New(); for _, x := range splitLines(t.value) { l.Add_O__Z(NewStringUTF16(x)) }; return l.Stream__Stream() }
// GetResourceAsStream_String__InputStream is Class.getResourceAsStream: the resource name
// resolved as Class.resolveName resolves it (absolute without its /, else in the package of the
// class or of its arrays' element class), from the host's resources, as a ByteArrayInputStream; null
// when there is none.
//line :42:1
func (c *Class) GetResourceAsStream_String__InputStream(name *String) InputStream_I { n := NN(name).String(); if strings.HasPrefix(n, "/") { n = n[1:] } else { e := c; for e.IsArray__Z() { e = e.GetComponentType__Class() }; cn := e.Info().Name; i := strings.LastIndexByte(cn, '.'); if i >= 0 { n = strings.ReplaceAll(cn[:i], ".", "/") + "/" + n } }; b, ok := ResourceOrPath(n); if !ok { return nil }; a := NewByteArray(int32(len(b))); for i, x := range b { a.A[i] = int8(x) }; return ByteArrayInputStream_New_B1(a) }
// a2gSetDateZone sets jrt's DateZone hooks to DefaultZone's methods.
func a2gSetDateZone() bool { DateZoneOffset = DefaultZone_Offset_J__I; DateZoneOffsetByWall = DefaultZone_OffsetByWall_J__I; DateZoneName = func(ms int64) string { return DefaultZone_Name_J__String(ms).String() }; return true }

var a2gDateZoneSet bool = a2gSetDateZone()

var A2g_AssertionsDisabled bool = true

func A2g_NotTranslated(what string) Throwable_I { return UnsupportedOperationException_New_String(Str("a2g: not translated: " + what)) }

func A2g_Missing[T any](why string) T { panic(Thrown(UnsupportedOperationException_New_String(Str("a2g: " + why)))) }

func A2g_NotNull[T any](x T) T { if any(x) == nil { panic(NPE()) }; return x }

func A2g_Truth(x any) bool { if x == nil { return false }; Boolean_Init(); return x != any(Boolean_FALSE) }

func A2g_CastArray[T any](x any, cls *Class) T { if x == nil { var z T; return z }; if !cls.IsInstance_O__Z(x) { panic(ClassCast(x, cls)) }; return x.(T) }

func A2g_Discard(x any) bool { return false }
// A2g_RefP is a pointer as an any, nil-preserving (§5.6).
func A2g_RefP[T any](p *T) any { if p == nil { return nil }; return p }
// String_Format_String_O1__String is String.format: a new Formatter's format (a2g's, over the
// translated java.util.Formatter).
//line :64:1
func String_Format_String_O1__String(format *String, args *RefArray) *String { return Formatter_New().Format_String_O1__Formatter(format, args).ToString__String() }
// Formatted_O1__String is String.formatted: String.format(this, args).
func (t *String) Formatted_O1__String(args *RefArray) *String { return Formatter_New().Format_String_O1__Formatter(t, args).ToString__String() }
// String_Join_CharSequence_Iterable__String is String.join(CharSequence, Iterable): each
// element cast to CharSequence (the for loop's checkcast), then joined as the array overload joins.
//line :68:1
func String_Join_CharSequence_Iterable__String(sep CharSequence, elements Iterable) *String { if sep == nil { panic(NPE()) }; if elements == nil { panic(NPE()) }; var es []any = nil; it := elements.Iterator__Iterator(); for it.HasNext__Z() { es = append(es, CharSequence_Cast(it.Next__O())) }; return String_Join_CharSequence_CharSequence1__String(sep, RefArrayOf(CharSequence_class, es...)) }
// String_Format_Locale_String_O1__String is String.format(Locale, ...).
func String_Format_Locale_String_O1__String(l *Locale, format *String, args *RefArray) *String { return Formatter_New_Locale(l).Format_String_O1__Formatter(format, args).ToString__String() }
// A2g_PrintStackTraceWriter is Throwable.printStackTrace(PrintWriter): the trace's text printed.
func A2g_PrintStackTraceWriter(t Throwable_I, w *PrintWriter) { NN(w).Print_String__V(StackTraceString(t)) }
// A2g_PrintStackTraceStream is Throwable.printStackTrace(PrintStream).
func A2g_PrintStackTraceStream(t Throwable_I, s *PrintStream) { NN(s).Print_String__V(StackTraceString(t)) }
// A2g_SystemGetenv is System.getenv(): the host's environment as an unmodifiable map.
func A2g_SystemGetenv() Map { m := HashMap_New(); for _, kv := range CurrentHost().Environ() { i := strings.IndexByte(kv, '='); if i > 0 { m.Put_O_O__O(Str(kv[:i]), Str(kv[i+1:])) } }; return Collections_UnmodifiableMap_Map__Map(m) }
// A2g_SystemGetProperties is System.getProperties(): a Properties with the system properties
// (a copy: the Go build keeps them in jrt's table, System.setProperty's).
//line :78:1
func A2g_SystemGetProperties() Properties_I { p := Properties_New(); for _, k := range PropertyNames() { v := System_GetProperty_String__String(Str(k)); if v != nil { p.SetProperty_String_String__O(Str(k), v) } }; return p }
// System_GetProperties__Properties is System.getProperties() as translated code calls it
// (m/a2g-static?).
//line :80:1
func System_GetProperties__Properties() Properties_I { return A2g_SystemGetProperties() }

var ( System_in InputStream_I; System_out *PrintStream; System_err *PrintStream)
// System_SetIn_InputStream__V is System.setIn.
func System_SetIn_InputStream__V(in InputStream_I) { System_in = in }
// System_SetOut_PrintStream__V is System.setOut.
func System_SetOut_PrintStream__V(out *PrintStream) { System_out = out }
// System_SetErr_PrintStream__V is System.setErr.
func System_SetErr_PrintStream__V(err *PrintStream) { System_err = err }

var String_CASE_INSENSITIVE_ORDER Comparator

func init() { CaseInsensitiveComparator_Init(); String_CASE_INSENSITIVE_ORDER = CaseInsensitiveComparator_INSTANCE; System_in = StandardStreams_In__InputStream(); System_out = StandardStreams_Out__PrintStream(); System_err = StandardStreams_Err__PrintStream(); var host func(string) = StderrPrint; StderrPrint = func(s string) { if System_err == nil { host(s); return }; System_err.Print_String__V(Str(s)); System_err.Flush__V() } }
// A2g_ObjHash is Objects.hashCode.
func A2g_ObjHash(x any) int32 { if x == nil { return 0 }; return HashCode(x) }
// A2g_ObjEquals is Objects.equals.
func A2g_ObjEquals(a, b any) bool { if a == b { return true }; if a == nil || b == nil { return false }; return Equals(a, b) }
// A2g_DoubleBits is Double.doubleToLongBits (one NaN).
func A2g_DoubleBits(d float64) int64 { if math.IsNaN(d) { return 9221120237041090560 }; return int64(math.Float64bits(d)) }
// A2g_BoolHash is Boolean.hashCode(boolean).
func A2g_BoolHash(b bool) int32 { if b { return 1231 }; return 1237 }
// A2g_FloatBits is Float.floatToIntBits (one NaN).
func A2g_FloatBits(f float32) int32 { if f != f { return 2143289344 }; return int32(math.Float32bits(f)) }

type A2gCloner interface{ CloneShallow() any }

func A2g_ObjectClone(x any) any { return x.(A2gCloner).CloneShallow() }
