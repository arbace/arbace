//line java_security_InvalidKeyException.ae:1
package jrt








func InvalidKeyException_New() *InvalidKeyException { t := &InvalidKeyException{}; t.Ctor(); return t }
//line :10:1
func (t *InvalidKeyException) Ctor() { t.KeyException.Ctor(t) }

func InvalidKeyException_New_String(p0 *String) *InvalidKeyException { t := &InvalidKeyException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *InvalidKeyException) Ctor_String(msg *String) { t.KeyException.Ctor_String(t, msg) }

func InvalidKeyException_New_String_Throwable(p0 *String, p1 Throwable_I) *InvalidKeyException { t := &InvalidKeyException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *InvalidKeyException) Ctor_String_Throwable(message *String, cause Throwable_I) { t.KeyException.Ctor_String_Throwable(t, message, cause) }


func InvalidKeyException_New_Throwable(p0 Throwable_I) *InvalidKeyException { t := &InvalidKeyException{}; t.Ctor_Throwable(p0); return t }
//line :17:1
func (t *InvalidKeyException) Ctor_Throwable(cause Throwable_I) { t.KeyException.Ctor_Throwable(t, cause) }










type InvalidKeyException struct{ KeyException }

const InvalidKeyException_serialVersionUID int64 = 5698479920593359816

func (t *InvalidKeyException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvalidKeyException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvalidKeyException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InvalidKeyException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvalidKeyException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvalidKeyException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InvalidKeyException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvalidKeyException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvalidKeyException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvalidKeyException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvalidKeyException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvalidKeyException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvalidKeyException) Ref() any { if t == nil { return nil }; return t }

func (t *InvalidKeyException) GetClass__Class() *Class { return InvalidKeyException_class }

func (t *InvalidKeyException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvalidKeyException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvalidKeyException_InstanceOf(x any) bool { _, ok := x.(*InvalidKeyException); return ok }

func InvalidKeyException_Cast(x any) *InvalidKeyException { if x == nil { return nil }; v, ok := x.(*InvalidKeyException); if !ok { panic(ClassCast(x, InvalidKeyException_class)) }; return v }
