//line java_text_spi_DateFormatProvider.ae:1
package jrt










func (t *DateFormatProvider) Ctor(this DateFormatProvider_I) { t.LocaleServiceProvider.Ctor(this) }



type DateFormatProvider struct{ LocaleServiceProvider }

type DateFormatProvider_I interface{ LocaleServiceProvider_I; Self_DateFormatProvider() *DateFormatProvider; GetTimeInstance_I_Locale__DateFormat(p0 int32, p1 *Locale) DateFormat_I; GetDateInstance_I_Locale__DateFormat(p0 int32, p1 *Locale) DateFormat_I; GetDateTimeInstance_I_I_Locale__DateFormat(p0, p1 int32, p2 *Locale) DateFormat_I }

func (t *DateFormatProvider) Self_DateFormatProvider() *DateFormatProvider { return t }

func DateFormatProvider_InstanceOf(x any) bool { _, ok := x.(DateFormatProvider_I); return ok }

func DateFormatProvider_Cast(x any) DateFormatProvider_I { if x == nil { return nil }; v, ok := x.(DateFormatProvider_I); if !ok { panic(ClassCast(x, DateFormatProvider_class)) }; return v }
