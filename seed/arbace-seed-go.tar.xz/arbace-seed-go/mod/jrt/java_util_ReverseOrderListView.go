//line java_util_ReverseOrderListView.ae:1
package jrt
















func ReverseOrderListView_Of_List_Z__List(list List, modifiable bool) List {

	if RandomAccess_InstanceOf(list) {
		return ReverseOrderListView_Rand_New_List_Z(list, modifiable) } else {
			return ReverseOrderListView_New_List_Z(list, modifiable)
		}
}




func ReverseOrderListView_Rand_New_List_Z(p0 List, p1 bool) *ReverseOrderListView_Rand { t := &ReverseOrderListView_Rand{}; t.Ctor_List_Z(p0, p1); return t }
//line :29:1
func (t *ReverseOrderListView_Rand) Ctor_List_Z(list List, modifiable bool) { t.ReverseOrderListView.Ctor_List_Z(t, list, modifiable) }


func ReverseOrderListView_New_List_Z(p0 List, p1 bool) *ReverseOrderListView { t := &ReverseOrderListView{}; t.Ctor_List_Z(t, p0, p1); return t }
//line :32:1
func (t *ReverseOrderListView) Ctor_List_Z(this ReverseOrderListView_I, list List, modifiable bool) {
	t.F_base = list
	t.F_modifiable = modifiable
}
func (t *ReverseOrderListView) Impl_CheckModifiable__V(this ReverseOrderListView_I) {
	if t.F_modifiable { } else { panic(Thrown(UnsupportedOperationException_New()))
	}
}




func (t *ReverseOrderListView_DescendingIterator) HasNext__Z() bool { return t.F_it.HasPrevious__Z() }

func (t *ReverseOrderListView_DescendingIterator) Next__O() any { return t.F_it.Previous__O() }

func (t *ReverseOrderListView_DescendingIterator) Remove__V() {
	t.F_this_0.CheckModifiable__V()
	t.F_it.Remove__V()
}





func ReverseOrderListView_DescendingListIterator_New_ReverseOrderListView_I_I(p0 ReverseOrderListView_I, p1, p2 int32) *ReverseOrderListView_DescendingListIterator { t := &ReverseOrderListView_DescendingListIterator{}; t.Ctor_ReverseOrderListView_I_I(p0, p1, p2); return t }
//line :57:1
func (t *ReverseOrderListView_DescendingListIterator) Ctor_ReverseOrderListView_I_I(this_0 ReverseOrderListView_I, size, pos int32) { A2g_NotNull[ReverseOrderListView_I](this_0); t.F_this_0 = this_0
	var tmp1 bool; var tmp2 bool; tmp2 = pos < 0; if !tmp2 { tmp2 = pos > size }; tmp1 = tmp2; if tmp1 { panic(Thrown(IndexOutOfBoundsException_New())) }
	t.F_it = this_0.Self_ReverseOrderListView().F_base.ListIterator_I__ListIterator(size - pos)
}
func (t *ReverseOrderListView_DescendingListIterator) HasNext__Z() bool { return t.F_it.HasPrevious__Z() }

func (t *ReverseOrderListView_DescendingListIterator) Next__O() any { return t.F_it.Previous__O() }

func (t *ReverseOrderListView_DescendingListIterator) HasPrevious__Z() bool { return t.F_it.HasNext__Z() }

func (t *ReverseOrderListView_DescendingListIterator) Previous__O() any { return t.F_it.Next__O() }

func (t *ReverseOrderListView_DescendingListIterator) NextIndex__I() int32 {
	return t.F_this_0.Self_ReverseOrderListView().F_base.Size__I() - t.F_it.NextIndex__I()
}
func (t *ReverseOrderListView_DescendingListIterator) PreviousIndex__I() int32 {
	return t.NextIndex__I() - 1
}
func (t *ReverseOrderListView_DescendingListIterator) Remove__V() {
	t.F_this_0.CheckModifiable__V()
	t.F_it.Remove__V()
}
func (t *ReverseOrderListView_DescendingListIterator) Set_O__V(e any) {
	t.F_this_0.CheckModifiable__V()
	t.F_it.Set_O__V(e)
}
func (t *ReverseOrderListView_DescendingListIterator) Add_O__V(e any) {
	t.F_this_0.CheckModifiable__V()
	t.F_it.Add_O__V(e)
	t.F_it.Previous__O()
}
func (t *ReverseOrderListView) Impl_ForEach_Consumer__V(this ReverseOrderListView_I, action Consumer) {
	var i_102009 Iterator = this.Iterator__Iterator(); for i_102009.HasNext__Z() { var e any = i_102009.Next__O(); action.Accept_O__V(e)
	} }
func (t *ReverseOrderListView) Impl_Iterator__Iterator(this ReverseOrderListView_I) Iterator {
	return ReverseOrderListView_DescendingIterator_New_ReverseOrderListView(this)
}
func (t *ReverseOrderListView) Impl_Spliterator__Spliterator(this ReverseOrderListView_I) Spliterator {
	return Spliterators_Spliterator_Collection_I__Spliterator(this, 16)
}
func (t *ReverseOrderListView) Impl_Add_O__Z(this ReverseOrderListView_I, e any) bool {
	this.CheckModifiable__V()
	t.F_base.Add_I_O__V(0, e)
//line :97:1
	return true
}



func (t *ReverseOrderListView) Impl_AddAll_Collection__Z(this ReverseOrderListView_I, c Collection) bool {
	this.CheckModifiable__V()
	var adds *RefArray = c.ToArray__O1()
	if int32(len(adds.A)) == 0 { return false } else {

		var tmp1 List = t.F_base; tmp1.AddAll_I_Collection__Z(0, Arrays_AsList_O1__List(ArraysSupport_Reverse_O1__O1(adds))); return true
	} }
func (t *ReverseOrderListView) Impl_Clear__V(this ReverseOrderListView_I) {
	this.CheckModifiable__V()
	t.F_base.Clear__V()
}
func (t *ReverseOrderListView) Impl_Contains_O__Z(this ReverseOrderListView_I, o any) bool { return t.F_base.Contains_O__Z(o) }

func (t *ReverseOrderListView) Impl_ContainsAll_Collection__Z(this ReverseOrderListView_I, c Collection) bool {
	return t.F_base.ContainsAll_Collection__Z(c)
}
func (t *ReverseOrderListView) Impl_Equals_O__Z(this ReverseOrderListView_I, o any) bool {
	if any(o) == any(this) { return true } else { if !List_InstanceOf(o) { return false } else {



		var e1 ListIterator = this.ListIterator__ListIterator(); var e2 ListIterator = List_Cast(o).ListIterator__ListIterator()

	L1: for { var tmp1 bool; var tmp2 bool; tmp2 = e1.HasNext__Z(); if tmp2 { tmp2 = e2.HasNext__Z() }; tmp1 = tmp2; if tmp1 {
		var o1 any = e1.Next__O(); var o2 any = e2.Next__O(); var tmp3 bool

		if o1 == nil { tmp3 = o2 == nil } else { tmp3 = Equals(o1, o2) }; if tmp3 { } else { return false }
//line :125:1
		continue L1 }; break L1
	}


		var tmp4 bool; var tmp5 bool; tmp5 = e1.HasNext__Z(); if !tmp5 { tmp5 = e2.HasNext__Z() }; tmp4 = tmp5; return !tmp4
	} } }
func (t *ReverseOrderListView) Impl_HashCode__I(this ReverseOrderListView_I) int32 {
	var hashCode int32 = 1; var i_102010 Iterator = this.Iterator__Iterator(); for i_102010.HasNext__Z() {
		var e any = i_102010.Next__O(); var tmp1 int32 = 31 * hashCode; var tmp2 int32


		if e == nil { tmp2 = 0 } else { tmp2 = HashCode(e) }
//line :134:1
		hashCode = tmp1 + tmp2 }
//line :132:1
	return hashCode
}





func (t *ReverseOrderListView) Impl_IsEmpty__Z(this ReverseOrderListView_I) bool { return t.F_base.IsEmpty__Z() }

func (t *ReverseOrderListView) Impl_ParallelStream__Stream(this ReverseOrderListView_I) Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(this.Spliterator__Spliterator(), true)
}
func (t *ReverseOrderListView) Impl_Remove_O__Z(this ReverseOrderListView_I, o any) bool {
	this.CheckModifiable__V()
	var it Iterator = this.Iterator__Iterator()
	if o == nil {
	L1: for { if it.HasNext__Z() { if it.Next__O() == nil { it.Remove__V(); return true }; continue L1 }; break L1 } } else {
	L2: for { if it.HasNext__Z() { if Equals(o, it.Next__O()) { it.Remove__V(); return true }; continue L2 }; break L2 } }
//line :146:1
	return false
}




func (t *ReverseOrderListView) Impl_RemoveAll_Collection__Z(this ReverseOrderListView_I, c Collection) bool {
	this.CheckModifiable__V()
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var it Iterator = this.Iterator__Iterator()

L1: for { if it.HasNext__Z() { if c.Contains_O__Z(it.Next__O()) { it.Remove__V(); modified = true }; continue L1 }; break L1 }
//line :155:1
	return modified
}



func (t *ReverseOrderListView) Impl_RetainAll_Collection__Z(this ReverseOrderListView_I, c Collection) bool {
	this.CheckModifiable__V()
	Objects_RequireNonNull_O__O(c)
	var modified bool = false; var it Iterator = this.Iterator__Iterator()

L1: for { if it.HasNext__Z() { if c.Contains_O__Z(it.Next__O()) { } else { it.Remove__V(); modified = true }; continue L1 }; break L1 }
//line :163:1
	return modified
}



func (t *ReverseOrderListView) Impl_Size__I(this ReverseOrderListView_I) int32 { return t.F_base.Size__I() }

func (t *ReverseOrderListView) Impl_Stream__Stream(this ReverseOrderListView_I) Stream {
	return StreamSupport_Stream_Spliterator_Z__Stream(this.Spliterator__Spliterator(), false)
}
func (t *ReverseOrderListView) Impl_ToArray__O1(this ReverseOrderListView_I) *RefArray {
	return ArraysSupport_Reverse_O1__O1(t.F_base.ToArray__O1())
}
func (t *ReverseOrderListView) Impl_ToArray_O1__O1(this ReverseOrderListView_I, a *RefArray) *RefArray {
	return ArraysSupport_ToArrayReversed_Collection_O1__O1(t.F_base, a)
}
func (t *ReverseOrderListView) Impl_ToArray_IntFunction__O1(this ReverseOrderListView_I, generator IntFunction) *RefArray {
	return ArraysSupport_Reverse_O1__O1(t.F_base.ToArray_IntFunction__O1(generator))
}
func (t *ReverseOrderListView) Impl_ToString__String(this ReverseOrderListView_I) *String {
	{ var it Iterator = this.Iterator__Iterator()
		if !it.HasNext__Z() { return Lit_2589 } else {

			var sb *StringBuilder = StringBuilder_New()
			NN(sb).Append_C__StringBuilder(91)
		L1: for {
			var e any = it.Next__O(); var tmp1 any
			if any(e) == any(this) { tmp1 = Lit_2590 } else { tmp1 = e }; NN(sb).Append_O__StringBuilder(tmp1)
			if it.HasNext__Z() { } else { return NN(NN(sb).Append_C__StringBuilder(93)).ToString__String() }
			NN(NN(sb).Append_C__StringBuilder(44)).Append_C__StringBuilder(32)
//line :188:1
			continue L1
		}
		}
	}
	panic("a2g: unreachable")
}
func (t *ReverseOrderListView) Impl_Add_I_O__V(this ReverseOrderListView_I, index int32, element any) {
	this.CheckModifiable__V()
	var size int32 = t.F_base.Size__I()
	ReverseOrderListView_CheckClosedRange_I_I__V(index, size)
	t.F_base.Add_I_O__V(size-index, element)
}
func (t *ReverseOrderListView) Impl_AddAll_I_Collection__Z(this ReverseOrderListView_I, index int32, c Collection) bool {
	this.CheckModifiable__V()
	var size int32 = t.F_base.Size__I()
	ReverseOrderListView_CheckClosedRange_I_I__V(index, size)
	var adds *RefArray = c.ToArray__O1()
	if int32(len(adds.A)) == 0 { return false } else {


		var tmp1 List = t.F_base; tmp1.AddAll_I_Collection__Z(size-index, Arrays_AsList_O1__List(ArraysSupport_Reverse_O1__O1(adds)))
//line :207:1
		return true
	}
}



func (t *ReverseOrderListView) Impl_Get_I__O(this ReverseOrderListView_I, i int32) any {
	var size int32 = t.F_base.Size__I()
	Objects_CheckIndex_I_I__I(i, size)
	return t.F_base.Get_I__O(size - i - 1)
}
func (t *ReverseOrderListView) Impl_IndexOf_O__I(this ReverseOrderListView_I, o any) int32 {
	var i int32 = t.F_base.LastIndexOf_O__I(o)
	if i == -1 { return -1 } else { return t.F_base.Size__I() - i - 1
	} }
func (t *ReverseOrderListView) Impl_LastIndexOf_O__I(this ReverseOrderListView_I, o any) int32 {
	var i int32 = t.F_base.IndexOf_O__I(o)
	if i == -1 { return -1 } else { return t.F_base.Size__I() - i - 1
	} }
func (t *ReverseOrderListView) Impl_ListIterator__ListIterator(this ReverseOrderListView_I) ListIterator {
	return ReverseOrderListView_DescendingListIterator_New_ReverseOrderListView_I_I(this, t.F_base.Size__I(), 0)
}
func (t *ReverseOrderListView) Impl_ListIterator_I__ListIterator(this ReverseOrderListView_I, index int32) ListIterator {
	var size int32 = t.F_base.Size__I()
	ReverseOrderListView_CheckClosedRange_I_I__V(index, size)
	return ReverseOrderListView_DescendingListIterator_New_ReverseOrderListView_I_I(this, size, index)
}
func (t *ReverseOrderListView) Impl_Remove_I__O(this ReverseOrderListView_I, index int32) any {
	this.CheckModifiable__V()
	var size int32 = t.F_base.Size__I()
	Objects_CheckIndex_I_I__I(index, size)
	return t.F_base.Remove_I__O(size - index - 1)
}
func (t *ReverseOrderListView) Impl_RemoveIf_Predicate__Z(this ReverseOrderListView_I, filter Predicate) bool {
	this.CheckModifiable__V()
	return t.F_base.RemoveIf_Predicate__Z(filter)
}
func (t *ReverseOrderListView) Impl_ReplaceAll_UnaryOperator__V(this ReverseOrderListView_I, operator UnaryOperator) {
	this.CheckModifiable__V()
	t.F_base.ReplaceAll_UnaryOperator__V(operator)
}
func (t *ReverseOrderListView) Impl_Sort_Comparator__V(this ReverseOrderListView_I, c Comparator) {
	this.CheckModifiable__V()
	var tmp1 List = t.F_base; tmp1.Sort_Comparator__V(Collections_ReverseOrder_Comparator__Comparator(c))
}
func (t *ReverseOrderListView) Impl_Set_I_O__O(this ReverseOrderListView_I, index int32, element any) any {
	this.CheckModifiable__V()
	var size int32 = t.F_base.Size__I()
	Objects_CheckIndex_I_I__I(index, size)
	return t.F_base.Set_I_O__O(size-index-1, element)
}
func (t *ReverseOrderListView) Impl_SubList_I_I__List(this ReverseOrderListView_I, fromIndex, toIndex int32) List {
	var size int32 = t.F_base.Size__I()
	Objects_CheckFromToIndex_I_I_I__I(fromIndex, toIndex, size)
	return ReverseOrderListView_New_List_Z(t.F_base.SubList_I_I__List(size-toIndex, size-fromIndex), t.F_modifiable)
}




func (t *ReverseOrderListView) Impl_Reversed__List(this ReverseOrderListView_I) List { return t.F_base }

func ReverseOrderListView_CheckClosedRange_I_I__V(index, size int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = index < 0; if !tmp2 { tmp2 = index > size }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index), Lit_2596, StrOfInt(size)))))
	}
}

type ReverseOrderListView struct{ Object; F_base List; F_modifiable bool }

type ReverseOrderListView_I interface{ Object_I; List; SequencedCollection; Collection; Iterable; Self_ReverseOrderListView() *ReverseOrderListView; CheckModifiable__V(); ForEach_Consumer__V(p0 Consumer); Iterator__Iterator() Iterator; Spliterator__Spliterator() Spliterator; Add_O__Z(p0 any) bool; AddAll_Collection__Z(p0 Collection) bool; Clear__V(); Contains_O__Z(p0 any) bool; ContainsAll_Collection__Z(p0 Collection) bool; IsEmpty__Z() bool; ParallelStream__Stream() Stream; Remove_O__Z(p0 any) bool; RemoveAll_Collection__Z(p0 Collection) bool; RetainAll_Collection__Z(p0 Collection) bool; Size__I() int32; Stream__Stream() Stream; ToArray__O1() *RefArray; ToArray_O1__O1(p0 *RefArray) *RefArray; ToArray_IntFunction__O1(p0 IntFunction) *RefArray; Add_I_O__V(p0 int32, p1 any); AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; Get_I__O(p0 int32) any; IndexOf_O__I(p0 any) int32; LastIndexOf_O__I(p0 any) int32; ListIterator__ListIterator() ListIterator; ListIterator_I__ListIterator(p0 int32) ListIterator; Remove_I__O(p0 int32) any; RemoveIf_Predicate__Z(p0 Predicate) bool; ReplaceAll_UnaryOperator__V(p0 UnaryOperator); Sort_Comparator__V(p0 Comparator); Set_I_O__O(p0 int32, p1 any) any; SubList_I_I__List(p0, p1 int32) List; Reversed__List() List; Reversed__SequencedCollection() SequencedCollection }

func (t *ReverseOrderListView) Self_ReverseOrderListView() *ReverseOrderListView { return t }

func (t *ReverseOrderListView) Is_List() {}

func (t *ReverseOrderListView) Is_SequencedCollection() {}

func (t *ReverseOrderListView) Is_Collection() {}

func (t *ReverseOrderListView) Is_Iterable() {}

func (t *ReverseOrderListView) Impl_Reversed__SequencedCollection(this ReverseOrderListView_I) SequencedCollection { return this.Reversed__List() }

func (t *ReverseOrderListView) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *ReverseOrderListView) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *ReverseOrderListView) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *ReverseOrderListView) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderListView) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *ReverseOrderListView) Clear__V() { t.Impl_Clear__V(t) }

func (t *ReverseOrderListView) CheckModifiable__V() { t.Impl_CheckModifiable__V(t) }

func (t *ReverseOrderListView) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ReverseOrderListView) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *ReverseOrderListView) Reversed__SequencedCollection() SequencedCollection { return t.Impl_Reversed__SequencedCollection(t) }

func (t *ReverseOrderListView) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *ReverseOrderListView) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *ReverseOrderListView) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *ReverseOrderListView) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *ReverseOrderListView) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *ReverseOrderListView) Reversed__List() List { return t.Impl_Reversed__List(t) }

func (t *ReverseOrderListView) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *ReverseOrderListView) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *ReverseOrderListView) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *ReverseOrderListView) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ReverseOrderListView) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ReverseOrderListView) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *ReverseOrderListView) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *ReverseOrderListView) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *ReverseOrderListView) GetLast__O() any { return List_GetLast__O(t) }

func (t *ReverseOrderListView) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *ReverseOrderListView) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderListView) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *ReverseOrderListView) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *ReverseOrderListView) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *ReverseOrderListView) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *ReverseOrderListView) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *ReverseOrderListView) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ReverseOrderListView) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ReverseOrderListView) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *ReverseOrderListView) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *ReverseOrderListView) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderListView) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderListView) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReverseOrderListView) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderListView) GetClass__Class() *Class { return ReverseOrderListView_class }

func (t *ReverseOrderListView) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderListView) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderListView_InstanceOf(x any) bool { _, ok := x.(ReverseOrderListView_I); return ok }

func ReverseOrderListView_Cast(x any) ReverseOrderListView_I { if x == nil { return nil }; v, ok := x.(ReverseOrderListView_I); if !ok { panic(ClassCast(x, ReverseOrderListView_class)) }; return v }



type ReverseOrderListView_DescendingIterator struct{ Object; F_it ListIterator; F_this_0 ReverseOrderListView_I }

func (t *ReverseOrderListView_DescendingIterator) Is_Iterator() {}

func ReverseOrderListView_DescendingIterator_New_ReverseOrderListView(p0 ReverseOrderListView_I) *ReverseOrderListView_DescendingIterator { t := &ReverseOrderListView_DescendingIterator{}; t.Ctor_ReverseOrderListView(p0); return t }

func (t *ReverseOrderListView_DescendingIterator) Ctor_ReverseOrderListView(this_0 ReverseOrderListView_I) { A2g_NotNull[ReverseOrderListView_I](this_0); t.F_this_0 = this_0; var tmp1 List = this_0.Self_ReverseOrderListView().F_base; t.F_it = tmp1.ListIterator_I__ListIterator(this_0.Self_ReverseOrderListView().F_base.Size__I()) }

func (t *ReverseOrderListView_DescendingIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderListView_DescendingIterator) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderListView_DescendingIterator) GetClass__Class() *Class { return ReverseOrderListView_DescendingIterator_class }

func (t *ReverseOrderListView_DescendingIterator) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderListView_DescendingIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderListView_DescendingIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderListView_DescendingIterator_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderListView_DescendingIterator); return ok }

func ReverseOrderListView_DescendingIterator_Cast(x any) *ReverseOrderListView_DescendingIterator { if x == nil { return nil }; v, ok := x.(*ReverseOrderListView_DescendingIterator); if !ok { panic(ClassCast(x, ReverseOrderListView_DescendingIterator_class)) }; return v }



type ReverseOrderListView_DescendingListIterator struct{ Object; F_it ListIterator; F_this_0 ReverseOrderListView_I }

func (t *ReverseOrderListView_DescendingListIterator) Is_ListIterator() {}

func (t *ReverseOrderListView_DescendingListIterator) Is_Iterator() {}

func (t *ReverseOrderListView_DescendingListIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ReverseOrderListView_DescendingListIterator) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderListView_DescendingListIterator) GetClass__Class() *Class { return ReverseOrderListView_DescendingListIterator_class }

func (t *ReverseOrderListView_DescendingListIterator) ToString__String() *String { return Object_toString(t) }

func (t *ReverseOrderListView_DescendingListIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderListView_DescendingListIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderListView_DescendingListIterator_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderListView_DescendingListIterator); return ok }

func ReverseOrderListView_DescendingListIterator_Cast(x any) *ReverseOrderListView_DescendingListIterator { if x == nil { return nil }; v, ok := x.(*ReverseOrderListView_DescendingListIterator); if !ok { panic(ClassCast(x, ReverseOrderListView_DescendingListIterator_class)) }; return v }



type ReverseOrderListView_Rand struct{ ReverseOrderListView }

func (t *ReverseOrderListView_Rand) Is_RandomAccess() {}

func (t *ReverseOrderListView_Rand) Reversed__SequencedCollection() SequencedCollection { return t.ReverseOrderListView.Impl_Reversed__List(t) }

func (t *ReverseOrderListView_Rand) LastIndexOf_O__I(p0 any) int32 { return t.Impl_LastIndexOf_O__I(t, p0) }

func (t *ReverseOrderListView_Rand) Spliterator__Spliterator() Spliterator { return t.Impl_Spliterator__Spliterator(t) }

func (t *ReverseOrderListView_Rand) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *ReverseOrderListView_Rand) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *ReverseOrderListView_Rand) Size__I() int32 { return t.Impl_Size__I(t) }

func (t *ReverseOrderListView_Rand) Clear__V() { t.Impl_Clear__V(t) }

func (t *ReverseOrderListView_Rand) CheckModifiable__V() { t.Impl_CheckModifiable__V(t) }

func (t *ReverseOrderListView_Rand) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ReverseOrderListView_Rand) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *ReverseOrderListView_Rand) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView_Rand) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *ReverseOrderListView_Rand) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *ReverseOrderListView_Rand) Get_I__O(p0 int32) any { return t.Impl_Get_I__O(t, p0) }

func (t *ReverseOrderListView_Rand) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *ReverseOrderListView_Rand) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *ReverseOrderListView_Rand) Reversed__List() List { return t.Impl_Reversed__List(t) }

func (t *ReverseOrderListView_Rand) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *ReverseOrderListView_Rand) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *ReverseOrderListView_Rand) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return t.Impl_ToArray_IntFunction__O1(t, p0) }

func (t *ReverseOrderListView_Rand) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ReverseOrderListView_Rand) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView_Rand) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ReverseOrderListView_Rand) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *ReverseOrderListView_Rand) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *ReverseOrderListView_Rand) Stream__Stream() Stream { return t.Impl_Stream__Stream(t) }

func (t *ReverseOrderListView_Rand) GetLast__O() any { return List_GetLast__O(t) }

func (t *ReverseOrderListView_Rand) RemoveLast__O() any { return List_RemoveLast__O(t) }

func (t *ReverseOrderListView_Rand) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView_Rand) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ReverseOrderListView_Rand) RemoveFirst__O() any { return List_RemoveFirst__O(t) }

func (t *ReverseOrderListView_Rand) ParallelStream__Stream() Stream { return t.Impl_ParallelStream__Stream(t) }

func (t *ReverseOrderListView_Rand) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *ReverseOrderListView_Rand) ForEach_Consumer__V(p0 Consumer) { t.Impl_ForEach_Consumer__V(t, p0) }

func (t *ReverseOrderListView_Rand) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *ReverseOrderListView_Rand) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ReverseOrderListView_Rand) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ReverseOrderListView_Rand) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ReverseOrderListView_Rand) IndexOf_O__I(p0 any) int32 { return t.Impl_IndexOf_O__I(t, p0) }

func (t *ReverseOrderListView_Rand) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *ReverseOrderListView_Rand) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ReverseOrderListView_Rand) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ReverseOrderListView_Rand) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ReverseOrderListView_Rand) Ref() any { if t == nil { return nil }; return t }

func (t *ReverseOrderListView_Rand) GetClass__Class() *Class { return ReverseOrderListView_Rand_class }

func (t *ReverseOrderListView_Rand) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ReverseOrderListView_Rand) CloneShallow() any { panic(CloneNotSupported(t)) }

func ReverseOrderListView_Rand_InstanceOf(x any) bool { _, ok := x.(*ReverseOrderListView_Rand); return ok }

func ReverseOrderListView_Rand_Cast(x any) *ReverseOrderListView_Rand { if x == nil { return nil }; v, ok := x.(*ReverseOrderListView_Rand); if !ok { panic(ClassCast(x, ReverseOrderListView_Rand_class)) }; return v }
