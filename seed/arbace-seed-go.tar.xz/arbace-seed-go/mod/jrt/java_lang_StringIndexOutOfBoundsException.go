//line java_lang_StringIndexOutOfBoundsException.ae:1
package jrt








func StringIndexOutOfBoundsException_New() *StringIndexOutOfBoundsException { t := &StringIndexOutOfBoundsException{}; t.Ctor(); return t }
//line :10:1
func (t *StringIndexOutOfBoundsException) Ctor() { t.IndexOutOfBoundsException.Ctor(t) }

func StringIndexOutOfBoundsException_New_String(p0 *String) *StringIndexOutOfBoundsException { t := &StringIndexOutOfBoundsException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *StringIndexOutOfBoundsException) Ctor_String(s *String) { t.IndexOutOfBoundsException.Ctor_String(t, s) }

func StringIndexOutOfBoundsException_New_I(p0 int32) *StringIndexOutOfBoundsException { t := &StringIndexOutOfBoundsException{}; t.Ctor_I(p0); return t }
//line :14:1
func (t *StringIndexOutOfBoundsException) Ctor_I(index int32) { t.IndexOutOfBoundsException.Ctor_String(t, Concat(Lit_1194, StrOfInt(index))) }









type StringIndexOutOfBoundsException struct{ IndexOutOfBoundsException }

const StringIndexOutOfBoundsException_serialVersionUID int64 = -6762910422159637258

func (t *StringIndexOutOfBoundsException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *StringIndexOutOfBoundsException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *StringIndexOutOfBoundsException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *StringIndexOutOfBoundsException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *StringIndexOutOfBoundsException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *StringIndexOutOfBoundsException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *StringIndexOutOfBoundsException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *StringIndexOutOfBoundsException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *StringIndexOutOfBoundsException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *StringIndexOutOfBoundsException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *StringIndexOutOfBoundsException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *StringIndexOutOfBoundsException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *StringIndexOutOfBoundsException) Ref() any { if t == nil { return nil }; return t }

func (t *StringIndexOutOfBoundsException) GetClass__Class() *Class { return StringIndexOutOfBoundsException_class }

func (t *StringIndexOutOfBoundsException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *StringIndexOutOfBoundsException) CloneShallow() any { panic(CloneNotSupported(t)) }

func StringIndexOutOfBoundsException_InstanceOf(x any) bool { _, ok := x.(*StringIndexOutOfBoundsException); return ok }

func StringIndexOutOfBoundsException_Cast(x any) *StringIndexOutOfBoundsException { if x == nil { return nil }; v, ok := x.(*StringIndexOutOfBoundsException); if !ok { panic(ClassCast(x, StringIndexOutOfBoundsException_class)) }; return v }
