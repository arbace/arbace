//line java_util_ImmutableCollections.ae:1
package jrt
































































func (t *ImmutableCollections_Access_1) ListFromTrustedArray_O1__List(array *RefArray) List {

	return ImmutableCollections_ListFromTrustedArray_O1__List(array)
}
func (t *ImmutableCollections_Access_1) ListFromTrustedArrayNullsAllowed_O1__List(array *RefArray) List {

	return ImmutableCollections_ListFromTrustedArrayNullsAllowed_O1__List(array)
}
func ImmutableCollections_New() *ImmutableCollections { ImmutableCollections_Init(); t := &ImmutableCollections{}; t.Ctor(); return t }
//line :74:1
func (t *ImmutableCollections) Ctor() { panic(A2g_NotTranslated("java.util.ImmutableCollections.<init>()V")) }



func ImmutableCollections_Uoe__UnsupportedOperationException() UnsupportedOperationException_I { ImmutableCollections_Init()
	return UnsupportedOperationException_New()
}




func (t *ImmutableCollections_AbstractImmutableCollection) Impl_Add_O__Z(this ImmutableCollections_AbstractImmutableCollection_I, e any) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableCollection) Impl_AddAll_Collection__Z(this ImmutableCollections_AbstractImmutableCollection_I, c Collection) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableCollection) Impl_Clear__V(this ImmutableCollections_AbstractImmutableCollection_I) { panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException())) }

func (t *ImmutableCollections_AbstractImmutableCollection) Impl_Remove_O__Z(this ImmutableCollections_AbstractImmutableCollection_I, o any) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableCollection) Impl_RemoveAll_Collection__Z(this ImmutableCollections_AbstractImmutableCollection_I, c Collection) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableCollection) Impl_RemoveIf_Predicate__Z(this ImmutableCollections_AbstractImmutableCollection_I, filter Predicate) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableCollection) Impl_RetainAll_Collection__Z(this ImmutableCollections_AbstractImmutableCollection_I, c Collection) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func ImmutableCollections_ListCopy_Collection__List(coll Collection) List { ImmutableCollections_Init()
	if ImmutableCollections_List12_InstanceOf(coll) {
		return List_Cast(coll) } else {
			var tmp1 Collection = coll; if ImmutableCollections_ListN_InstanceOf(tmp1) { var c *ImmutableCollections_ListN = ImmutableCollections_ListN_Cast(tmp1)
				if !c.F_allowNulls {
					return List_Cast(coll) } else {
//line :109:1
						if coll.IsEmpty__Z() {

							return List_Of__List() } else {
								return List_Of_O1__List(coll.ToArray__O1()) } } } else {
									if coll.IsEmpty__Z() { return List_Of__List() } else { return List_Of_O1__List(coll.ToArray__O1())
									} } } }
func ImmutableCollections_ListFromArray_O1__List(input *RefArray) List { ImmutableCollections_Init()
	var tmp *RefArray = NewRefArray(Object_class, int32(len(input.A))); var i int32 = 0
L1: for {
	if i < int32(len(input.A)) {
		tmp.Store(i, Objects_RequireNonNull_O__O(input.A[i]))
		i = i + 1; continue L1 }
//line :117:1
	break L1
}


	return ImmutableCollections_ListN_New_O1_Z(tmp, false)
}
func ImmutableCollections_ListFromTrustedArray_O1__List(input *RefArray) List { ImmutableCollections_Init()
	if !A2g_AssertionsDisabled && !(GetClass(input.Ref()) == Object_class.ArrayClass()) { panic(Thrown(AssertionError_New())) }
	{ var arr_101912 *RefArray = input; var len_101913 int32 = int32(len(arr_101912.A)); var i_101914 int32 = 0; for ; i_101914 < len_101913; i_101914++ { var o any = arr_101912.A[i_101914]; Objects_RequireNonNull_O__O(o) }
		switch int32(len(input.A)) { case 0: return Up_ImmutableCollections_ListN_List(ImmutableCollections_EMPTY_LIST); case 1:

			return ImmutableCollections_List12_New_O(input.A[0]); case 2:
			var tmp1 any = input.A[0]; return ImmutableCollections_List12_New_O_O(tmp1, input.A[1]); default:
			return ImmutableCollections_ListN_New_O1_Z(input, false)} }; panic("a2g: unreachable")
}
func ImmutableCollections_ListFromTrustedArrayNullsAllowed_O1__List(input *RefArray) List { ImmutableCollections_Init()

	if !A2g_AssertionsDisabled && !(GetClass(input.Ref()) == Object_class.ArrayClass()) { panic(Thrown(AssertionError_New())) }
	if int32(len(input.A)) == 0 { return Up_ImmutableCollections_ListN_List(ImmutableCollections_EMPTY_LIST_NULLS) } else { return ImmutableCollections_ListN_New_O1_Z(input, true)
	}
}




func (t *ImmutableCollections_AbstractImmutableList) Impl_Add_I_O__V(this ImmutableCollections_AbstractImmutableList_I, index int32, element any) {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_AddAll_I_Collection__Z(this ImmutableCollections_AbstractImmutableList_I, index int32, c Collection) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_Remove_I__O(this ImmutableCollections_AbstractImmutableList_I, index int32) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_RemoveFirst__O(this ImmutableCollections_AbstractImmutableList_I) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_RemoveLast__O(this ImmutableCollections_AbstractImmutableList_I) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_ReplaceAll_UnaryOperator__V(this ImmutableCollections_AbstractImmutableList_I, operator UnaryOperator) {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_Set_I_O__O(this ImmutableCollections_AbstractImmutableList_I, index int32, element any) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_Sort_Comparator__V(this ImmutableCollections_AbstractImmutableList_I, c Comparator) {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_SubList_I_I__List(this ImmutableCollections_AbstractImmutableList_I, fromIndex, toIndex int32) List {
	var size int32 = this.Size__I()
	ImmutableCollections_AbstractImmutableList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, size)
	return Up_ImmutableCollections_SubList_List(ImmutableCollections_SubList_FromList_ImmutableCollections_AbstractImmutableList_I_I__ImmutableCollections_SubList(this, fromIndex, toIndex))
}
func ImmutableCollections_AbstractImmutableList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, size int32) {
	if fromIndex < 0 {
		panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2591, StrOfInt(fromIndex))))) }
	if toIndex > size { panic(Thrown(IndexOutOfBoundsException_New_String(Concat(Lit_2592, StrOfInt(toIndex))))) }
	if fromIndex > toIndex {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2593, StrOfInt(fromIndex), Lit_2594, StrOfInt(toIndex), Lit_1176))))
	}
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_Iterator__Iterator(this ImmutableCollections_AbstractImmutableList_I) Iterator {
	return ImmutableCollections_ListItr_New_List_I(this, this.Size__I())
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_ListIterator__ListIterator(this ImmutableCollections_AbstractImmutableList_I) ListIterator {
	return this.ListIterator_I__ListIterator(0)
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_ListIterator_I__ListIterator(this ImmutableCollections_AbstractImmutableList_I, index int32) ListIterator {
	var size int32 = this.Size__I(); var tmp1 bool; var tmp2 bool
	tmp2 = index < 0; if !tmp2 { tmp2 = index > size }; tmp1 = tmp2; if tmp1 { panic(Thrown(this.OutOfBounds_I__IndexOutOfBoundsException(index))) }
	return ImmutableCollections_ListItr_New_List_I_I(this, size, index)
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_Equals_O__Z(this ImmutableCollections_AbstractImmutableList_I, o any) bool {
	if any(o) == any(this) { return true } else { if !List_InstanceOf(o) { return false } else {



		var oit Iterator = List_Cast(o).Iterator__Iterator(); var i int32 = 0; var s int32 = this.Size__I()
	L1: for {

		if i < s {
			var tmp1 bool; var tmp2 bool; tmp2 = !oit.HasNext__Z(); if !tmp2 { tmp2 = !Objects_Equals_O_O__Z(this.Get_I__O(i), oit.Next__O()) }; tmp1 = tmp2; if tmp1 {
				return false } else {
					i, s = i+1, s; continue L1 } }
//line :196:1
		break L1
	}





		return !oit.HasNext__Z()
	} } }
func (t *ImmutableCollections_AbstractImmutableList) Impl_HashCode__I(this ImmutableCollections_AbstractImmutableList_I) int32 {
	var hash int32 = 1; var i int32 = 0; var s int32 = this.Size__I()
L1: for {

	if i < s {
		hash = 31*hash + Objects_HashCode_O__I(this.Get_I__O(i))


		i, s = i+1, s; continue L1 }
//line :207:1
	break L1 }
//line :206:1
	return hash
}








func (t *ImmutableCollections_AbstractImmutableList) Impl_Contains_O__Z(this ImmutableCollections_AbstractImmutableList_I, o any) bool { return this.IndexOf_O__I(o) >= 0 }

func (t *ImmutableCollections_AbstractImmutableList) Impl_Reversed__List(this ImmutableCollections_AbstractImmutableList_I) List {
	return ReverseOrderListView_Of_List_Z__List(this, false)
}
func (t *ImmutableCollections_AbstractImmutableList) Impl_OutOfBounds_I__IndexOutOfBoundsException(this ImmutableCollections_AbstractImmutableList_I, index int32) IndexOutOfBoundsException_I {
	return IndexOutOfBoundsException_New_String(Concat(Lit_2595, StrOfInt(index), Lit_2731, StrOfInt(this.Size__I())))
}












func ImmutableCollections_ListItr_New_List_I(p0 List, p1 int32) *ImmutableCollections_ListItr { t := &ImmutableCollections_ListItr{}; t.Ctor_List_I(p0, p1); return t }
//line :236:1
func (t *ImmutableCollections_ListItr) Ctor_List_I(list List, size int32) {
	t.F_list = list
	t.F_size = size
	t.F_cursor = 0
	t.F_isListIterator = false
}
func ImmutableCollections_ListItr_New_List_I_I(p0 List, p1, p2 int32) *ImmutableCollections_ListItr { t := &ImmutableCollections_ListItr{}; t.Ctor_List_I_I(p0, p1, p2); return t }
//line :242:1
func (t *ImmutableCollections_ListItr) Ctor_List_I_I(list List, size, index int32) {
	t.F_list = list
	t.F_size = size
	t.F_cursor = index
	t.F_isListIterator = true
}
func (t *ImmutableCollections_ListItr) HasNext__Z() bool { return !(t.F_cursor == t.F_size) }

func (t *ImmutableCollections_ListItr) Next__O() any {
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var i int32 = t.F_cursor; var next any = t.F_list.Get_I__O(i); t.F_cursor = i + 1; tmp1 = next }; return nil }()
//line :251:1
	if tmp2 != nil { if IndexOutOfBoundsException_InstanceOf(tmp2) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp2); _ = e

		panic(Thrown(NoSuchElementException_New())) } else {
//line :251:1
			panic(tmp2) } }; return tmp1
}


func (t *ImmutableCollections_ListItr) Remove__V() { panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException())) }

func (t *ImmutableCollections_ListItr) HasPrevious__Z() bool {
	if t.F_isListIterator { } else { panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException())) }
	return !(t.F_cursor == 0)
}
func (t *ImmutableCollections_ListItr) Previous__O() any {
	if t.F_isListIterator { } else { panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException())) }
	var tmp1 any; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var i int32 = t.F_cursor - 1; var previous any = t.F_list.Get_I__O(i)

			t.F_cursor = i
//line :264:1
			tmp1 = previous
		}
		return nil }()
//line :263:1
	if tmp2 != nil { if IndexOutOfBoundsException_InstanceOf(tmp2) { var e IndexOutOfBoundsException_I = IndexOutOfBoundsException_Cast(tmp2); _ = e




		panic(Thrown(NoSuchElementException_New())) } else {
//line :263:1
			panic(tmp2) } }; return tmp1
}





func (t *ImmutableCollections_ListItr) NextIndex__I() int32 {
	if t.F_isListIterator { } else { panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException())) }
//line :270:1
	return t.F_cursor
}


func (t *ImmutableCollections_ListItr) PreviousIndex__I() int32 {
	if t.F_isListIterator { } else { panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException())) }
	return t.F_cursor - 1
}
func (t *ImmutableCollections_ListItr) Set_O__V(e any) {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_ListItr) Add_O__V(e any) {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}











func ImmutableCollections_SubList_New_ImmutableCollections_AbstractImmutableList_I_I(p0 ImmutableCollections_AbstractImmutableList_I, p1, p2 int32) *ImmutableCollections_SubList { ImmutableCollections_SubList_Init(); t := &ImmutableCollections_SubList{}; t.Ctor_ImmutableCollections_AbstractImmutableList_I_I(p0, p1, p2); return t }
//line :295:1
func (t *ImmutableCollections_SubList) Ctor_ImmutableCollections_AbstractImmutableList_I_I(root ImmutableCollections_AbstractImmutableList_I, offset, size int32) { t.ImmutableCollections_AbstractImmutableList.Ctor(t)
	var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = ImmutableCollections_List12_InstanceOf(root); if !tmp3 { tmp3 = ImmutableCollections_ListN_InstanceOf(root) }; tmp2 = tmp3; if !tmp2 {
		tmp2 = A2g_Discard(root) }
//line :296:1
	tmp1 = tmp2; if !A2g_AssertionsDisabled && !tmp1 { panic(Thrown(AssertionError_New()))
	}
	t.F_root = root
	t.F_offset = offset
	t.F_size = size
}
func ImmutableCollections_SubList_FromSubList_ImmutableCollections_SubList_I_I__ImmutableCollections_SubList(parent *ImmutableCollections_SubList, fromIndex, toIndex int32) *ImmutableCollections_SubList { ImmutableCollections_SubList_Init()

	var tmp1 ImmutableCollections_AbstractImmutableList_I = parent.F_root; return ImmutableCollections_SubList_New_ImmutableCollections_AbstractImmutableList_I_I(tmp1, parent.F_offset+fromIndex, toIndex-fromIndex)
}


func ImmutableCollections_SubList_FromList_ImmutableCollections_AbstractImmutableList_I_I__ImmutableCollections_SubList(list ImmutableCollections_AbstractImmutableList_I, fromIndex, toIndex int32) *ImmutableCollections_SubList { ImmutableCollections_SubList_Init()

	return ImmutableCollections_SubList_New_ImmutableCollections_AbstractImmutableList_I_I(list, fromIndex, toIndex-fromIndex)
}
func (t *ImmutableCollections_SubList) Get_I__O(index int32) any {
	Objects_CheckIndex_I_I__I(index, t.F_size)
	return t.F_root.Get_I__O(t.F_offset + index)
}
func (t *ImmutableCollections_SubList) Size__I() int32 { return t.F_size }

func (t *ImmutableCollections_SubList) Iterator__Iterator() Iterator {
	return ImmutableCollections_ListItr_New_List_I(t, t.Size__I())
}
func (t *ImmutableCollections_SubList) ListIterator_I__ListIterator(index int32) ListIterator {
	t.RangeCheck_I__V(index)
	return ImmutableCollections_ListItr_New_List_I_I(t, t.Size__I(), index)
}
func (t *ImmutableCollections_SubList) SubList_I_I__List(fromIndex, toIndex int32) List {
	ImmutableCollections_AbstractImmutableList_SubListRangeCheck_I_I_I__V(fromIndex, toIndex, t.F_size)
	return Up_ImmutableCollections_SubList_List(ImmutableCollections_SubList_FromSubList_ImmutableCollections_SubList_I_I__ImmutableCollections_SubList(t, fromIndex, toIndex))
}
func (t *ImmutableCollections_SubList) RangeCheck_I__V(index int32) {
	var tmp1 bool; var tmp2 bool; tmp2 = index < 0; if !tmp2 { tmp2 = index > t.F_size }; tmp1 = tmp2; if tmp1 { panic(Thrown(t.OutOfBounds_I__IndexOutOfBoundsException(index)))
	} }
func (t *ImmutableCollections_SubList) AllowNulls__Z() bool {
	var tmp1 ImmutableCollections_AbstractImmutableList_I = t.F_root; if ImmutableCollections_ListN_InstanceOf(tmp1) { var listN *ImmutableCollections_ListN = ImmutableCollections_ListN_Cast(tmp1); return listN.F_allowNulls } else { return false
	} }
func (t *ImmutableCollections_SubList) IndexOf_O__I(o any) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.AllowNulls__Z(); if tmp2 { tmp2 = o == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	var i int32 = 0; var s int32 = t.Size__I(); L1: for {

		if i < s {
			if Objects_Equals_O_O__Z(o, t.Get_I__O(i)) { return i } else { i, s = i+1, s; continue L1 } }
//line :337:1
		break L1 }
//line :335:1
	return -1
}







func (t *ImmutableCollections_SubList) LastIndexOf_O__I(o any) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.AllowNulls__Z(); if tmp2 { tmp2 = o == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	var i int32 = t.Size__I() - 1; L1: for {
		if i >= 0 {
			if Objects_Equals_O_O__Z(o, t.Get_I__O(i)) { return i } else { i = i - 1; continue L1 } }
//line :346:1
		break L1 }
//line :344:1
	return -1
}






func (t *ImmutableCollections_SubList) ToArray__O1() *RefArray {
	var array *RefArray = NewRefArray(Object_class, t.F_size); var i int32 = 0
L1: for {
	if i < t.F_size { array.Store(i, t.Get_I__O(i)); i = i + 1; continue L1 }
//line :354:1
	break L1 }
//line :353:1
	return array
}



func (t *ImmutableCollections_SubList) ToArray_O1__O1(a *RefArray) *RefArray {
	var array *RefArray; if int32(len(a.A)) >= t.F_size { array = a } else {

		array = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), t.F_size), Object_class.ArrayClass())
	}
	var i int32 = 0; L1: for {
		if i < t.F_size { array.Store(i, t.Get_I__O(i)); i = i + 1; continue L1 }
//line :363:1
		break L1
	}
	if int32(len(array.A)) > t.F_size { array.Store(t.F_size, nil) }
//line :359:1
	return array
}
















func ImmutableCollections_List12_New_O(p0 any) *ImmutableCollections_List12 { t := &ImmutableCollections_List12{}; t.Ctor_O(p0); return t }
//line :377:1
func (t *ImmutableCollections_List12) Ctor_O(e0 any) { t.ImmutableCollections_AbstractImmutableList.Ctor(t)
	t.F_e0 = Objects_RequireNonNull_O__O(e0)
	var tmp1 any; ImmutableCollections_Init(); tmp1 = ImmutableCollections_EMPTY; t.F_e1 = tmp1
}
func ImmutableCollections_List12_New_O_O(p0, p1 any) *ImmutableCollections_List12 { t := &ImmutableCollections_List12{}; t.Ctor_O_O(p0, p1); return t }
//line :381:1
func (t *ImmutableCollections_List12) Ctor_O_O(e0, e1 any) { t.ImmutableCollections_AbstractImmutableList.Ctor(t)
	t.F_e0 = Objects_RequireNonNull_O__O(e0)
	t.F_e1 = Objects_RequireNonNull_O__O(e1)
}
func (t *ImmutableCollections_List12) Size__I() int32 { var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if !(tmp1 == tmp2) { return 2 } else { return 1 } }

func (t *ImmutableCollections_List12) IsEmpty__Z() bool { return false }

func (t *ImmutableCollections_List12) Get_I__O(index int32) any {
	if index == 0 { return t.F_e0 } else { var tmp1 bool; var tmp2 bool

		tmp2 = index == 1; if tmp2 { var tmp3 any = t.F_e1; var tmp4 any; ImmutableCollections_Init(); tmp4 = ImmutableCollections_EMPTY; tmp2 = !(tmp3 == tmp4) }; tmp1 = tmp2
//line :390:1
		if tmp1 { return t.F_e1 } else {


			panic(Thrown(t.OutOfBounds_I__IndexOutOfBoundsException(index)))
		} } }
func (t *ImmutableCollections_List12) GetFirst__O() any { return t.F_e0 }

func (t *ImmutableCollections_List12) GetLast__O() any { var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 { return t.F_e0 } else { return t.F_e1 } }

func (t *ImmutableCollections_List12) IndexOf_O__I(o any) int32 {
	Objects_RequireNonNull_O__O(o)
	if Equals(o, t.F_e0) { return 0 } else { var tmp1 bool; var tmp2 bool; var tmp3 any = t.F_e1; var tmp4 any; ImmutableCollections_Init(); tmp4 = ImmutableCollections_EMPTY; tmp2 = !(tmp3 == tmp4); if tmp2 { tmp2 = Equals(o, t.F_e1) }; tmp1 = tmp2; if tmp1 { return 1 } else { return -1
	} } }
func (t *ImmutableCollections_List12) LastIndexOf_O__I(o any) int32 {
	Objects_RequireNonNull_O__O(o)
	var tmp1 bool; var tmp2 bool; var tmp3 any = t.F_e1; var tmp4 any; ImmutableCollections_Init(); tmp4 = ImmutableCollections_EMPTY; tmp2 = !(tmp3 == tmp4); if tmp2 { tmp2 = Equals(o, t.F_e1) }; tmp1 = tmp2; if tmp1 { return 1 } else { if Equals(o, t.F_e0) { return 0 } else { return -1
	}
	}
}


func (t *ImmutableCollections_List12) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.ImmutableCollections$List12.writeReplace()Ljava/lang/Object;")) }


func (t *ImmutableCollections_List12) ToArray__O1() *RefArray {
	var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 { return RefArrayOf(Object_class, t.F_e0) } else { return RefArrayOf(Object_class, t.F_e0, t.F_e1)
	} }
func (t *ImmutableCollections_List12) ToArray_O1__O1(a *RefArray) *RefArray {
	var size int32 = t.Size__I(); var array *RefArray
	if int32(len(a.A)) >= size { array = a } else {

		array = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass())
	}
	array.Store(0, t.F_e0)
	if size == 2 { array.Store(1, t.F_e1) }
	if int32(len(array.A)) > size { array.Store(size, nil) }
//line :418:1
	return array
}








func (t *ImmutableCollections_List12) ForEach_Consumer__V(action Consumer) {
	action.Accept_O__V(t.F_e0)
	var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 { } else { action.Accept_O__V(t.F_e1)
	} }
func (t *ImmutableCollections_List12) Spliterator__Spliterator() Spliterator {
	var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 { return Collections_SingletonSpliterator_O__Spliterator(t.F_e0) } else { return List_Spliterator__Spliterator(t)
	}
}








func ImmutableCollections_ListN_New_O1_Z(p0 *RefArray, p1 bool) *ImmutableCollections_ListN { t := &ImmutableCollections_ListN{}; t.Ctor_O1_Z(p0, p1); return t }
//line :444:1
func (t *ImmutableCollections_ListN) Ctor_O1_Z(elements *RefArray, allowNulls bool) { t.ImmutableCollections_AbstractImmutableList.Ctor(t)
	t.F_elements = elements
	t.F_allowNulls = allowNulls
}
func (t *ImmutableCollections_ListN) IsEmpty__Z() bool { return int32(len(t.F_elements.A)) == 0 }

func (t *ImmutableCollections_ListN) Size__I() int32 { return int32(len(t.F_elements.A)) }

func (t *ImmutableCollections_ListN) Get_I__O(index int32) any { return t.F_elements.A[index] }





func (t *ImmutableCollections_ListN) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.ImmutableCollections$ListN.writeReplace()Ljava/lang/Object;")) }


func (t *ImmutableCollections_ListN) ToArray__O1() *RefArray {
	var tmp1 *RefArray = t.F_elements; return Arrays_CopyOf_O1_I__O1(tmp1, int32(len(t.F_elements.A)))
}
func (t *ImmutableCollections_ListN) ToArray_O1__O1(a *RefArray) *RefArray {
	var size int32 = int32(len(t.F_elements.A))
	if int32(len(a.A)) < size {
		var tmp1 *RefArray = t.F_elements; return Arrays_CopyOf_O1_I_Class__O1(tmp1, size, GetClass(a.Ref())) } else {

			System_Arraycopy_O_I_O_I_I__V(t.F_elements.Ref(), 0, a.Ref(), 0, size)
			if int32(len(a.A)) > size { a.Store(size, nil) }
//line :468:1
			return a
		}
}


func (t *ImmutableCollections_ListN) IndexOf_O__I(o any) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_allowNulls; if tmp2 { tmp2 = o == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	var es *RefArray = t.F_elements; var i int32 = 0
L1: for {
	if i < int32(len(es.A)) {
		if Objects_Equals_O_O__Z(o, es.A[i]) { return i } else { i = i + 1; continue L1 } }
//line :476:1
	break L1 }
//line :475:1
	return -1
}





func (t *ImmutableCollections_ListN) LastIndexOf_O__I(o any) int32 {
	var tmp1 bool; var tmp2 bool; tmp2 = !t.F_allowNulls; if tmp2 { tmp2 = o == nil }; tmp1 = tmp2; if tmp1 { panic(Thrown(NullPointerException_New())) }
	var es *RefArray = t.F_elements; var i int32 = int32(len(es.A)) - 1
L1: for {
	if i >= 0 {
		if Objects_Equals_O_O__Z(o, es.A[i]) { return i } else { i = i - 1; continue L1 } }
//line :485:1
	break L1 }
//line :484:1
	return -1
}










func (t *ImmutableCollections_AbstractImmutableSet) Impl_Equals_O__Z(this ImmutableCollections_AbstractImmutableSet_I, o any) bool {
	if any(o) == any(this) { return true } else { if !Set_InstanceOf(o) { return false } else {



		var c Collection = Collection_Cast(o)
		if !(c.Size__I() == this.Size__I()) { return false } else {


			var i_101918 Iterator = c.Iterator__Iterator(); for i_101918.HasNext__Z() { var e any = i_101918.Next__O(); var tmp1 bool; var tmp2 bool; tmp2 = e == nil; if !tmp2 { tmp2 = !this.Contains_O__Z(e) }; tmp1 = tmp2; if tmp1 { return false } }
//line :504:1
			return true
		}
	}
	}
}










func ImmutableCollections_Set12_New_O(p0 any) *ImmutableCollections_Set12 { t := &ImmutableCollections_Set12{}; t.Ctor_O(p0); return t }
//line :519:1
func (t *ImmutableCollections_Set12) Ctor_O(e0 any) { t.ImmutableCollections_AbstractImmutableSet.Ctor(t)
	t.F_e0 = Objects_RequireNonNull_O__O(e0)
	var tmp1 any; ImmutableCollections_Init(); tmp1 = ImmutableCollections_EMPTY; t.F_e1 = tmp1
}
func ImmutableCollections_Set12_New_O_O(p0, p1 any) *ImmutableCollections_Set12 { t := &ImmutableCollections_Set12{}; t.Ctor_O_O(p0, p1); return t }
//line :523:1
func (t *ImmutableCollections_Set12) Ctor_O_O(e0, e1 any) { t.ImmutableCollections_AbstractImmutableSet.Ctor(t)
	if Equals(e0, Objects_RequireNonNull_O__O(e1)) {
		panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2734, StrOfObj(e0))))) }
	t.F_e0 = e0
	t.F_e1 = e1
}
func (t *ImmutableCollections_Set12) Size__I() int32 { var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 { return 1 } else { return 2 } }

func (t *ImmutableCollections_Set12) IsEmpty__Z() bool { return false }

func (t *ImmutableCollections_Set12) Contains_O__Z(o any) bool {
	var tmp1 bool; tmp1 = Equals(o, t.F_e0); if !tmp1 { tmp1 = Equals(t.F_e1, o) }; return tmp1
}
func (t *ImmutableCollections_Set12) HashCode__I() int32 {
	var tmp1 int32 = HashCode(t.F_e0); var tmp2 int32; var tmp3 any = t.F_e1; var tmp4 any; ImmutableCollections_Init(); tmp4 = ImmutableCollections_EMPTY; if tmp3 == tmp4 { tmp2 = 0 } else { tmp2 = HashCode(t.F_e1) }; return tmp1 + tmp2
}
func (t *ImmutableCollections_Set12) Iterator__Iterator() Iterator {
	return ImmutableCollections_Set12_1_New_ImmutableCollections_Set12(t)
}

func (t *ImmutableCollections_Set12_1) HasNext__Z() bool { return t.F_idx > 0 }

func (t *ImmutableCollections_Set12_1) Next__O() any {
	if t.F_idx == 1 {
		t.F_idx = 0; var tmp1 bool; var tmp2 bool; ImmutableCollections_Init(); tmp2 = ImmutableCollections_REVERSE; if !tmp2 { var tmp3 any = t.F_this_0.F_e1; var tmp4 any; ImmutableCollections_Init(); tmp4 = ImmutableCollections_EMPTY; tmp2 = tmp3 == tmp4 }; tmp1 = tmp2; if tmp1 { return t.F_this_0.F_e0 } else { return t.F_this_0.F_e1 } } else {
//line :546:1
			if t.F_idx == 2 {

				t.F_idx = 1; var tmp5 bool; ImmutableCollections_Init(); tmp5 = ImmutableCollections_REVERSE; if tmp5 { return t.F_this_0.F_e1 } else { return t.F_this_0.F_e0 } } else {
					panic(Thrown(NoSuchElementException_New()))
				}
		}
}


func (t *ImmutableCollections_Set12) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.ImmutableCollections$Set12.writeReplace()Ljava/lang/Object;")) }


func (t *ImmutableCollections_Set12) ToArray__O1() *RefArray {
	var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 {
		return RefArrayOf(Object_class, t.F_e0) } else {
//line :559:1
			var tmp3 bool; ImmutableCollections_Init(); tmp3 = ImmutableCollections_REVERSE; if tmp3 {

				return RefArrayOf(Object_class, t.F_e1, t.F_e0) } else {
					return RefArrayOf(Object_class, t.F_e0, t.F_e1)
				} } }
func (t *ImmutableCollections_Set12) ToArray_O1__O1(a *RefArray) *RefArray {
	var size int32 = t.Size__I(); var array *RefArray
	if int32(len(a.A)) >= size { array = a } else {

		array = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), size), Object_class.ArrayClass())
	}
	if size == 1 {
		array.Store(0, t.F_e0) } else {
//line :570:1
			var tmp1 bool; ImmutableCollections_Init(); tmp1 = ImmutableCollections_REVERSE; if tmp1 {

				array.Store(0, t.F_e1); array.Store(1, t.F_e0) } else {
					array.Store(0, t.F_e0); array.Store(1, t.F_e1) } }
	if int32(len(array.A)) > size { array.Store(size, nil) }
//line :565:1
	return array
}










func (t *ImmutableCollections_Set12) ForEach_Consumer__V(action Consumer) {
	var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 {
		action.Accept_O__V(t.F_e0) } else {
			var tmp3 any; var tmp4 bool; ImmutableCollections_Init(); tmp4 = ImmutableCollections_REVERSE; if tmp4 { tmp3 = t.F_e1 } else { tmp3 = t.F_e0 }; action.Accept_O__V(tmp3); var tmp5 any; var tmp6 bool; ImmutableCollections_Init(); tmp6 = ImmutableCollections_REVERSE; if tmp6 { tmp5 = t.F_e0 } else { tmp5 = t.F_e1 }; action.Accept_O__V(tmp5)
		} }
func (t *ImmutableCollections_Set12) Spliterator__Spliterator() Spliterator {
	var tmp1 any = t.F_e1; var tmp2 any; ImmutableCollections_Init(); tmp2 = ImmutableCollections_EMPTY; if tmp1 == tmp2 { return Collections_SingletonSpliterator_O__Spliterator(t.F_e0) } else { return Set_Spliterator__Spliterator(t)
	}
}








func ImmutableCollections_SetN_New_O1(p0 *RefArray) *ImmutableCollections_SetN { t := &ImmutableCollections_SetN{}; t.Ctor_O1(p0); return t }
//line :594:1
func (t *ImmutableCollections_SetN) Ctor_O1(input *RefArray) { t.ImmutableCollections_AbstractImmutableSet.Ctor(t)
	t.F_size = int32(len(input.A))
	t.F_elements = NewRefArray(Object_class, 2*int32(len(input.A)))
	var i int32 = 0; L1: for {
		if i < int32(len(input.A)) {
			var e any = input.A[i]; var idx int32 = t.Probe_O__I(e)

			if idx >= 0 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2734, StrOfObj(e))))) } else {

					t.F_elements.Store(-(idx + 1), e)
					i = i + 1; continue L1 } }
//line :597:1
		break L1
	}
}







func (t *ImmutableCollections_SetN) Size__I() int32 { return t.F_size }

func (t *ImmutableCollections_SetN) IsEmpty__Z() bool { return t.F_size == 0 }

func (t *ImmutableCollections_SetN) Contains_O__Z(o any) bool {
	Objects_RequireNonNull_O__O(o)
	var tmp1 bool; tmp1 = t.F_size > 0; if tmp1 { tmp1 = t.Probe_O__I(o) >= 0 }; return tmp1
}







func ImmutableCollections_SetN_SetNIterator_New_ImmutableCollections_SetN(p0 *ImmutableCollections_SetN) *ImmutableCollections_SetN_SetNIterator { t := &ImmutableCollections_SetN_SetNIterator{}; t.Ctor_ImmutableCollections_SetN(p0); return t }
//line :622:1
func (t *ImmutableCollections_SetN_SetNIterator) Ctor_ImmutableCollections_SetN(this_0 *ImmutableCollections_SetN) { NN(this_0); t.F_this_0 = this_0
	t.F_remaining = this_0.F_size
	var tmp1 int64; ImmutableCollections_Init(); tmp1 = ImmutableCollections_SALT32L; var tmp2 int64 = tmp1; t.F_idx = int32(int64(uint64(tmp2*int64(int32(len(this_0.F_elements.A)))) >> 32))
}


func (t *ImmutableCollections_SetN_SetNIterator) HasNext__Z() bool { return t.F_remaining > 0 }

func (t *ImmutableCollections_SetN_SetNIterator) Next__O() any {
	if t.F_remaining > 0 {
		var element any; var idx int32 = t.F_idx; var len_ int32 = int32(len(t.F_this_0.F_elements.A))


	L1: for {
		var tmp1 bool; ImmutableCollections_Init(); tmp1 = ImmutableCollections_REVERSE; if tmp1 {
			var tmp2 int32; idx = idx + 1; tmp2 = idx; if tmp2 >= len_ { idx = 0 } } else {
//line :636:1
				var tmp3 int32

				idx = idx - 1; tmp3 = idx
//line :636:1
				if tmp3 < 0 {

					idx = len_ - 1 } }
		var tmp4 any; element = t.F_this_0.F_elements.A[idx]; tmp4 = element; if tmp4 == nil { continue L1 }
//line :635:1
		break L1
	}



		t.F_idx = idx
		t.F_remaining = t.F_remaining - 1
//line :632:1
		return element







	} else {


		panic(Thrown(NoSuchElementException_New()))
	} }
func (t *ImmutableCollections_SetN) Iterator__Iterator() Iterator { return ImmutableCollections_SetN_SetNIterator_New_ImmutableCollections_SetN(t) }

func (t *ImmutableCollections_SetN) HashCode__I() int32 {
	var h int32 = 0; var arr_101919 *RefArray = t.F_elements; var len_101920 int32 = int32(len(arr_101919.A)); var i_101921 int32 = 0; for ; i_101921 < len_101920; i_101921++ {
		var e any = arr_101919.A[i_101921]; if !(e == nil) { h = h + HashCode(e) } }
//line :648:1
	return h
}


func (t *ImmutableCollections_SetN) Probe_O__I(pe any) int32 {
	{ var idx int32 = Math_FloorMod_I_I__I(HashCode(pe), int32(len(t.F_elements.A)))
	L1: for {
		var ee any = t.F_elements.A[idx]
		if ee == nil {
			return -idx - 1 } else {
//line :656:1
				if Equals(pe, ee) {

					return idx } else {
//line :656:1
						var tmp1 int32


						idx = idx + 1; tmp1 = idx
//line :656:1
						if tmp1 == int32(len(t.F_elements.A)) {


							idx = 0 } } }
//line :654:1
		continue L1
	}
	}
	panic("a2g: unreachable")
}






func (t *ImmutableCollections_SetN) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.ImmutableCollections$SetN.writeReplace()Ljava/lang/Object;")) }






func (t *ImmutableCollections_SetN) ToArray__O1() *RefArray {
	var array *RefArray = NewRefArray(Object_class, t.F_size); var it Iterator = t.Iterator__Iterator()
	var i int32 = 0
L1: for { if i < t.F_size { array.Store(i, it.Next__O()); i = i + 1; continue L1 }; break L1 }
//line :673:1
	return array
}



func (t *ImmutableCollections_SetN) ToArray_O1__O1(a *RefArray) *RefArray {
	var array *RefArray; if int32(len(a.A)) >= t.F_size { array = a } else {

		array = A2g_CastArray[*RefArray](Array_NewInstance_Class_I__O(NN(GetClass(a.Ref())).GetComponentType__Class(), t.F_size), Object_class.ArrayClass()) }
//line :679:1
	var it Iterator = t.Iterator__Iterator()
	var i int32 = 0



L1: for { if i < t.F_size { array.Store(i, it.Next__O()); i = i + 1; continue L1 }; break L1 }
	if int32(len(array.A)) > t.F_size { array.Store(t.F_size, nil) }
//line :679:1
	return array
}











func (t *ImmutableCollections_AbstractImmutableMap) Impl_Clear__V(this ImmutableCollections_AbstractImmutableMap_I) { panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException())) }

func (t *ImmutableCollections_AbstractImmutableMap) Impl_Compute_O_BiFunction__O(this ImmutableCollections_AbstractImmutableMap_I, key any, rf BiFunction) any {

	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_ComputeIfAbsent_O_Function__O(this ImmutableCollections_AbstractImmutableMap_I, key any, mf Function) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_ComputeIfPresent_O_BiFunction__O(this ImmutableCollections_AbstractImmutableMap_I, key any, rf BiFunction) any {

	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_Merge_O_O_BiFunction__O(this ImmutableCollections_AbstractImmutableMap_I, key, value any, rf BiFunction) any {

	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_Put_O_O__O(this ImmutableCollections_AbstractImmutableMap_I, key, value any) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_PutAll_Map__V(this ImmutableCollections_AbstractImmutableMap_I, m Map) {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_PutIfAbsent_O_O__O(this ImmutableCollections_AbstractImmutableMap_I, key, value any) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_Remove_O__O(this ImmutableCollections_AbstractImmutableMap_I, key any) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_Remove_O_O__Z(this ImmutableCollections_AbstractImmutableMap_I, key, value any) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_Replace_O_O__O(this ImmutableCollections_AbstractImmutableMap_I, key, value any) any {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_Replace_O_O_O__Z(this ImmutableCollections_AbstractImmutableMap_I, key, oldValue, newValue any) bool {
	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_ReplaceAll_BiFunction__V(this ImmutableCollections_AbstractImmutableMap_I, f BiFunction) {

	panic(Thrown(ImmutableCollections_Uoe__UnsupportedOperationException()))
}
func (t *ImmutableCollections_AbstractImmutableMap) Impl_GetOrDefault_O_O__O(this ImmutableCollections_AbstractImmutableMap_I, key, defaultValue any) any {
	var v any; var tmp1 any; v = this.Get_O__O(key); tmp1 = v; if !(tmp1 == nil) { return v } else { return defaultValue
	}
}








func ImmutableCollections_Map1_New_O_O(p0, p1 any) *ImmutableCollections_Map1 { t := &ImmutableCollections_Map1{}; t.Ctor_O_O(p0, p1); return t }
//line :746:1
func (t *ImmutableCollections_Map1) Ctor_O_O(k0, v0 any) { t.ImmutableCollections_AbstractImmutableMap.Ctor(t)
	t.F_k0 = Objects_RequireNonNull_O__O(k0)
	t.F_v0 = Objects_RequireNonNull_O__O(v0)
}
func (t *ImmutableCollections_Map1) EntrySet__Set() Set {
	return Set_Of_O__Set(KeyValueHolder_New_O_O(t.F_k0, t.F_v0))
}
func (t *ImmutableCollections_Map1) Get_O__O(o any) any { if Equals(o, t.F_k0) { return t.F_v0 } else { return nil } }

func (t *ImmutableCollections_Map1) ContainsKey_O__Z(o any) bool { return Equals(o, t.F_k0) }

func (t *ImmutableCollections_Map1) ContainsValue_O__Z(o any) bool { return Equals(o, t.F_v0) }

func (t *ImmutableCollections_Map1) Size__I() int32 { return 1 }

func (t *ImmutableCollections_Map1) IsEmpty__Z() bool { return false }





func (t *ImmutableCollections_Map1) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.ImmutableCollections$Map1.writeReplace()Ljava/lang/Object;")) }

func (t *ImmutableCollections_Map1) HashCode__I() int32 {
	return HashCode(t.F_k0) ^ HashCode(t.F_v0)
}
func (t *ImmutableCollections_Map1) ForEach_BiConsumer__V(action BiConsumer) {
	action.Accept_O_O__V(t.F_k0, t.F_v0)
}









func ImmutableCollections_MapN_New_O1(p0 *RefArray) *ImmutableCollections_MapN { t := &ImmutableCollections_MapN{}; t.Ctor_O1(p0); return t }
//line :784:1
func (t *ImmutableCollections_MapN) Ctor_O1(input *RefArray) { t.ImmutableCollections_AbstractImmutableMap.Ctor(t)
	if int32(len(input.A))&1 == 0 { } else { panic(Thrown(InternalError_New_String(Lit_2732))) }
	t.F_size = int32(len(input.A)) >> 1
	var len_ int32 = 2 * int32(len(input.A))
	len_ = (len_ + 1) & -2
	t.F_table = NewRefArray(Object_class, len_)
	var i int32 = 0; L1: for {
		if i < int32(len(input.A)) {
			var k any = Objects_RequireNonNull_O__O(input.A[i]); var v any = Objects_RequireNonNull_O__O(input.A[i+1]); var idx int32 = t.Probe_O__I(k)


			if idx >= 0 {
				panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_2733, StrOfObj(k))))) } else {
					var dest int32 = -(idx + 1)
					t.F_table.Store(dest, k)
					t.F_table.Store(dest+1, v)
					i = i + 2; continue L1 } }
//line :790:1
		break L1
	}
}









func (t *ImmutableCollections_MapN) ContainsKey_O__Z(o any) bool {
	Objects_RequireNonNull_O__O(o)
	var tmp1 bool; tmp1 = t.F_size > 0; if tmp1 { tmp1 = t.Probe_O__I(o) >= 0 }; return tmp1
}
func (t *ImmutableCollections_MapN) ContainsValue_O__Z(o any) bool {
	Objects_RequireNonNull_O__O(o)
	var i int32 = 1; L1: for {
		if i < int32(len(t.F_table.A)) {
			var v any = t.F_table.A[i]; var tmp1 bool; var tmp2 bool
			tmp2 = !(v == nil); if tmp2 { tmp2 = Equals(o, v) }; tmp1 = tmp2; if tmp1 { return true } else { i = i + 2; continue L1 } }
//line :808:1
		break L1 }
//line :806:1
	return false
}






func (t *ImmutableCollections_MapN) HashCode__I() int32 {
	var hash int32 = 0; var i int32 = 0
L1: for {
	if i < int32(len(t.F_table.A)) {
		var k any = t.F_table.A[i]
		if !(k == nil) {

			hash = hash + (HashCode(k) ^ HashCode(t.F_table.A[i+1]))




			i = i + 2; continue L1 } else {
				i = i + 2; continue L1 } }
//line :816:1
	break L1 }
//line :815:1
	return hash
}













func (t *ImmutableCollections_MapN) Get_O__O(o any) any {
	if t.F_size == 0 {
		Objects_RequireNonNull_O__O(o); return nil } else {
			var i int32 = t.Probe_O__I(o); if i >= 0 { return t.F_table.A[i+1] } else { return nil
			} } }
func (t *ImmutableCollections_MapN) Size__I() int32 { return t.F_size }

func (t *ImmutableCollections_MapN) IsEmpty__Z() bool { return t.F_size == 0 }








func ImmutableCollections_MapN_MapNIterator_New_ImmutableCollections_MapN(p0 *ImmutableCollections_MapN) *ImmutableCollections_MapN_MapNIterator { t := &ImmutableCollections_MapN_MapNIterator{}; t.Ctor_ImmutableCollections_MapN(p0); return t }
//line :846:1
func (t *ImmutableCollections_MapN_MapNIterator) Ctor_ImmutableCollections_MapN(this_0 *ImmutableCollections_MapN) { NN(this_0); t.F_this_0 = this_0
	t.F_remaining = this_0.F_size
	var tmp1 int64; ImmutableCollections_Init(); tmp1 = ImmutableCollections_SALT32L; var tmp2 int64 = tmp1; t.F_idx = int32(int64(uint64(tmp2*int64(int32(len(this_0.F_table.A))>>1))>>32)) << 1
}






func (t *ImmutableCollections_MapN_MapNIterator) HasNext__Z() bool { return t.F_remaining > 0 }

func (t *ImmutableCollections_MapN_MapNIterator) NextIndex__I() int32 {
	var idx int32 = t.F_idx; var tmp1 bool
	ImmutableCollections_Init(); tmp1 = ImmutableCollections_REVERSE; if tmp1 {
		var tmp2 int32; idx = idx + 2; tmp2 = idx; if tmp2 >= int32(len(t.F_this_0.F_table.A)) { idx = 0 } } else {
//line :860:1
			var tmp3 int32

			idx = idx - 2; tmp3 = idx
//line :860:1
			if tmp3 < 0 {


				idx = int32(len(t.F_this_0.F_table.A)) - 2 } }
	var tmp4 int32 = idx; t.F_idx = tmp4; return tmp4
}
func (t *ImmutableCollections_MapN_MapNIterator) Next__Map_Entry() Map_Entry {
	if t.F_remaining > 0 {
		var idx int32 = 0
	L1: for { var tmp1 *RefArray = t.F_this_0.F_table; var tmp2 int32; idx = t.NextIndex__I(); tmp2 = idx; if tmp1.A[tmp2] == nil { continue L1 }; break L1 }
		var tmp3 any = t.F_this_0.F_table.A[idx]; var e Map_Entry = KeyValueHolder_New_O_O(tmp3, t.F_this_0.F_table.A[idx+1])


		t.F_remaining = t.F_remaining - 1
//line :870:1
		return e

	} else {


		panic(Thrown(NoSuchElementException_New()))
	} }
func (t *ImmutableCollections_MapN) EntrySet__Set() Set {
	return ImmutableCollections_MapN_1_New_ImmutableCollections_MapN(t) }
func (t *ImmutableCollections_MapN_1) Size__I() int32 { return t.F_this_0.F_size }

func (t *ImmutableCollections_MapN_1) Iterator__Iterator() Iterator {
	return ImmutableCollections_MapN_MapNIterator_New_ImmutableCollections_MapN(t.F_this_0)
}
func (t *ImmutableCollections_MapN) Probe_O__I(pk any) int32 {
	{ var idx int32 = Math_FloorMod_I_I__I(HashCode(pk), int32(len(t.F_table.A))>>1) << 1


	L1: for {
		var ek any = t.F_table.A[idx]
		if ek == nil {
			return -idx - 1 } else {
//line :890:1
				if Equals(pk, ek) {

					return idx } else {
//line :890:1
						var tmp1 int32


						idx = idx + 2; tmp1 = idx
//line :890:1
						if tmp1 == int32(len(t.F_table.A)) {


							idx = 0 } } }
//line :888:1
		continue L1
	}
	}
	panic("a2g: unreachable")
}






func (t *ImmutableCollections_MapN) WriteReplace__O() any { panic(A2g_NotTranslated("java.util.ImmutableCollections$MapN.writeReplace()Ljava/lang/Object;")) }



type ImmutableCollections struct{ Object }

var ImmutableCollections_SALT32L int64

var ImmutableCollections_REVERSE bool

var ImmutableCollections_archivedObjects *RefArray

var ImmutableCollections_EMPTY any

var ImmutableCollections_EMPTY_LIST *ImmutableCollections_ListN

var ImmutableCollections_EMPTY_LIST_NULLS *ImmutableCollections_ListN

var ImmutableCollections_EMPTY_SET *ImmutableCollections_SetN

var ImmutableCollections_EMPTY_MAP *ImmutableCollections_MapN

const ImmutableCollections_EXPAND_FACTOR int32 = 2

var ImmutableCollections_init ClassInit

func ImmutableCollections_Init() { if !ImmutableCollections_init.Done() { ImmutableCollections_init.Run(ImmutableCollections_clinit) } }

func ImmutableCollections_clinit() {
//line :24:1
	var color int64 = 2611923443488327891; var seed int64 = CDS_GetRandomSeedForDumping__J()

	if seed == 0 { seed = System_NanoTime__J() }
	ImmutableCollections_SALT32L = int64(int32(color*seed>>16)) & 4294967295


	ImmutableCollections_REVERSE = ImmutableCollections_SALT32L&1 == 0














	CDS_InitializeFromArchive_Class__V(ImmutableCollections_class)
	if ImmutableCollections_archivedObjects == nil {

		ImmutableCollections_EMPTY = Object_New()
		ImmutableCollections_EMPTY_LIST = ImmutableCollections_ListN_New_O1_Z(NewRefArray(Object_class, 0), false)
		ImmutableCollections_EMPTY_LIST_NULLS = ImmutableCollections_ListN_New_O1_Z(NewRefArray(Object_class, 0), true)
		ImmutableCollections_EMPTY_SET = ImmutableCollections_SetN_New_O1(RefArrayOf(Object_class))
		ImmutableCollections_EMPTY_MAP = ImmutableCollections_MapN_New_O1(RefArrayOf(Object_class))
		ImmutableCollections_archivedObjects = RefArrayOf(Object_class, ImmutableCollections_EMPTY, ImmutableCollections_EMPTY_LIST.Ref(), ImmutableCollections_EMPTY_LIST_NULLS.Ref(), ImmutableCollections_EMPTY_SET.Ref(), ImmutableCollections_EMPTY_MAP.Ref()) } else {


			ImmutableCollections_EMPTY = ImmutableCollections_archivedObjects.A[0]
			ImmutableCollections_EMPTY_LIST = ImmutableCollections_ListN_Cast(ImmutableCollections_archivedObjects.A[1])
			ImmutableCollections_EMPTY_LIST_NULLS = ImmutableCollections_ListN_Cast(ImmutableCollections_archivedObjects.A[2])
			ImmutableCollections_EMPTY_SET = ImmutableCollections_SetN_Cast(ImmutableCollections_archivedObjects.A[3])
			ImmutableCollections_EMPTY_MAP = ImmutableCollections_MapN_Cast(ImmutableCollections_archivedObjects.A[4])
		}
}


































































































































































































































































































































































































































































































































































































































































































































































































































































































func (t *ImmutableCollections) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections) GetClass__Class() *Class { return ImmutableCollections_class }

func (t *ImmutableCollections) ToString__String() *String { return Object_toString(t) }

func (t *ImmutableCollections) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections); return ok }

func ImmutableCollections_Cast(x any) *ImmutableCollections { if x == nil { return nil }; v, ok := x.(*ImmutableCollections); if !ok { panic(ClassCast(x, ImmutableCollections_class)) }; return v }



type ImmutableCollections_AbstractImmutableCollection struct{ AbstractCollection }

type ImmutableCollections_AbstractImmutableCollection_I interface{ AbstractCollection_I; Collection; Iterable; Self_ImmutableCollections_AbstractImmutableCollection() *ImmutableCollections_AbstractImmutableCollection; Add_O__Z(p0 any) bool; AddAll_Collection__Z(p0 Collection) bool; Clear__V(); Remove_O__Z(p0 any) bool; RemoveAll_Collection__Z(p0 Collection) bool; RemoveIf_Predicate__Z(p0 Predicate) bool; RetainAll_Collection__Z(p0 Collection) bool }

func (t *ImmutableCollections_AbstractImmutableCollection) Self_ImmutableCollections_AbstractImmutableCollection() *ImmutableCollections_AbstractImmutableCollection { return t }

func (t *ImmutableCollections_AbstractImmutableCollection) Ctor(this ImmutableCollections_AbstractImmutableCollection_I) { t.AbstractCollection.Ctor(this) }

func ImmutableCollections_AbstractImmutableCollection_InstanceOf(x any) bool { _, ok := x.(ImmutableCollections_AbstractImmutableCollection_I); return ok }

func ImmutableCollections_AbstractImmutableCollection_Cast(x any) ImmutableCollections_AbstractImmutableCollection_I { if x == nil { return nil }; v, ok := x.(ImmutableCollections_AbstractImmutableCollection_I); if !ok { panic(ClassCast(x, ImmutableCollections_AbstractImmutableCollection_class)) }; return v }



type ImmutableCollections_AbstractImmutableList struct{ ImmutableCollections_AbstractImmutableCollection }

type ImmutableCollections_AbstractImmutableList_I interface{ ImmutableCollections_AbstractImmutableCollection_I; List; RandomAccess; Collection; SequencedCollection; Iterable; Self_ImmutableCollections_AbstractImmutableList() *ImmutableCollections_AbstractImmutableList; Add_I_O__V(p0 int32, p1 any); AddAll_I_Collection__Z(p0 int32, p1 Collection) bool; Remove_I__O(p0 int32) any; RemoveFirst__O() any; RemoveLast__O() any; ReplaceAll_UnaryOperator__V(p0 UnaryOperator); Set_I_O__O(p0 int32, p1 any) any; Sort_Comparator__V(p0 Comparator); SubList_I_I__List(p0, p1 int32) List; Iterator__Iterator() Iterator; ListIterator__ListIterator() ListIterator; ListIterator_I__ListIterator(p0 int32) ListIterator; Contains_O__Z(p0 any) bool; Reversed__List() List; OutOfBounds_I__IndexOutOfBoundsException(p0 int32) IndexOutOfBoundsException_I; Reversed__SequencedCollection() SequencedCollection }

func (t *ImmutableCollections_AbstractImmutableList) Self_ImmutableCollections_AbstractImmutableList() *ImmutableCollections_AbstractImmutableList { return t }

func (t *ImmutableCollections_AbstractImmutableList) Is_List() {}

func (t *ImmutableCollections_AbstractImmutableList) Is_RandomAccess() {}

func (t *ImmutableCollections_AbstractImmutableList) Is_SequencedCollection() {}

func (t *ImmutableCollections_AbstractImmutableList) Ctor(this ImmutableCollections_AbstractImmutableList_I) { t.ImmutableCollections_AbstractImmutableCollection.Ctor(this) }

func (t *ImmutableCollections_AbstractImmutableList) Impl_Reversed__SequencedCollection(this ImmutableCollections_AbstractImmutableList_I) SequencedCollection { return this.Reversed__List() }

func ImmutableCollections_AbstractImmutableList_InstanceOf(x any) bool { _, ok := x.(ImmutableCollections_AbstractImmutableList_I); return ok }

func ImmutableCollections_AbstractImmutableList_Cast(x any) ImmutableCollections_AbstractImmutableList_I { if x == nil { return nil }; v, ok := x.(ImmutableCollections_AbstractImmutableList_I); if !ok { panic(ClassCast(x, ImmutableCollections_AbstractImmutableList_class)) }; return v }



type ImmutableCollections_AbstractImmutableMap struct{ AbstractMap }

type ImmutableCollections_AbstractImmutableMap_I interface{ AbstractMap_I; Map; Self_ImmutableCollections_AbstractImmutableMap() *ImmutableCollections_AbstractImmutableMap; Clear__V(); Compute_O_BiFunction__O(p0 any, p1 BiFunction) any; ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any; ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any; Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any; Put_O_O__O(p0, p1 any) any; PutAll_Map__V(p0 Map); PutIfAbsent_O_O__O(p0, p1 any) any; Remove_O__O(p0 any) any; Remove_O_O__Z(p0, p1 any) bool; Replace_O_O__O(p0, p1 any) any; Replace_O_O_O__Z(p0, p1, p2 any) bool; ReplaceAll_BiFunction__V(p0 BiFunction); GetOrDefault_O_O__O(p0, p1 any) any }

func (t *ImmutableCollections_AbstractImmutableMap) Self_ImmutableCollections_AbstractImmutableMap() *ImmutableCollections_AbstractImmutableMap { return t }

func (t *ImmutableCollections_AbstractImmutableMap) Ctor(this ImmutableCollections_AbstractImmutableMap_I) { t.AbstractMap.Ctor(this) }

func ImmutableCollections_AbstractImmutableMap_InstanceOf(x any) bool { _, ok := x.(ImmutableCollections_AbstractImmutableMap_I); return ok }

func ImmutableCollections_AbstractImmutableMap_Cast(x any) ImmutableCollections_AbstractImmutableMap_I { if x == nil { return nil }; v, ok := x.(ImmutableCollections_AbstractImmutableMap_I); if !ok { panic(ClassCast(x, ImmutableCollections_AbstractImmutableMap_class)) }; return v }



type ImmutableCollections_AbstractImmutableSet struct{ ImmutableCollections_AbstractImmutableCollection }

type ImmutableCollections_AbstractImmutableSet_I interface{ ImmutableCollections_AbstractImmutableCollection_I; Set; Collection; Iterable; Self_ImmutableCollections_AbstractImmutableSet() *ImmutableCollections_AbstractImmutableSet }

func (t *ImmutableCollections_AbstractImmutableSet) Self_ImmutableCollections_AbstractImmutableSet() *ImmutableCollections_AbstractImmutableSet { return t }

func (t *ImmutableCollections_AbstractImmutableSet) Is_Set() {}

func (t *ImmutableCollections_AbstractImmutableSet) Ctor(this ImmutableCollections_AbstractImmutableSet_I) { t.ImmutableCollections_AbstractImmutableCollection.Ctor(this) }

func ImmutableCollections_AbstractImmutableSet_InstanceOf(x any) bool { _, ok := x.(ImmutableCollections_AbstractImmutableSet_I); return ok }

func ImmutableCollections_AbstractImmutableSet_Cast(x any) ImmutableCollections_AbstractImmutableSet_I { if x == nil { return nil }; v, ok := x.(ImmutableCollections_AbstractImmutableSet_I); if !ok { panic(ClassCast(x, ImmutableCollections_AbstractImmutableSet_class)) }; return v }



type ImmutableCollections_Access struct{ Object }

var ImmutableCollections_Access_init ClassInit

func ImmutableCollections_Access_Init() { if !ImmutableCollections_Access_init.Done() { ImmutableCollections_Access_init.Run(ImmutableCollections_Access_clinit) } }

func ImmutableCollections_Access_clinit() {
//line :64:1
	A2g_Missing[bool]("class jdk.internal.access.JavaUtilCollectionAccess is not in the closed world")
}

























































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func ImmutableCollections_Access_New() *ImmutableCollections_Access { ImmutableCollections_Access_Init(); t := &ImmutableCollections_Access{}; t.Ctor(); return t }

func (t *ImmutableCollections_Access) Ctor() {}

func (t *ImmutableCollections_Access) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_Access) GetClass__Class() *Class { return ImmutableCollections_Access_class }

func (t *ImmutableCollections_Access) ToString__String() *String { return Object_toString(t) }

func (t *ImmutableCollections_Access) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_Access) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_Access_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_Access); return ok }

func ImmutableCollections_Access_Cast(x any) *ImmutableCollections_Access { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_Access); if !ok { panic(ClassCast(x, ImmutableCollections_Access_class)) }; return v }



type ImmutableCollections_Access_1 struct{ Object }

func ImmutableCollections_Access_1_New() *ImmutableCollections_Access_1 { t := &ImmutableCollections_Access_1{}; t.Ctor(); return t }

func (t *ImmutableCollections_Access_1) Ctor() {}

func (t *ImmutableCollections_Access_1) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_Access_1) GetClass__Class() *Class { return ImmutableCollections_Access_1_class }

func (t *ImmutableCollections_Access_1) ToString__String() *String { return Object_toString(t) }

func (t *ImmutableCollections_Access_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_Access_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_Access_1_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_Access_1); return ok }

func ImmutableCollections_Access_1_Cast(x any) *ImmutableCollections_Access_1 { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_Access_1); if !ok { panic(ClassCast(x, ImmutableCollections_Access_1_class)) }; return v }



type ImmutableCollections_List12 struct{ ImmutableCollections_AbstractImmutableList; F_e0, F_e1 any }

func (t *ImmutableCollections_List12) Is_Serializable() {}

func (t *ImmutableCollections_List12) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *ImmutableCollections_List12) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *ImmutableCollections_List12) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_List12) Reversed__SequencedCollection() SequencedCollection { return t.Impl_Reversed__SequencedCollection(t) }

func (t *ImmutableCollections_List12) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_List12) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *ImmutableCollections_List12) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *ImmutableCollections_List12) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *ImmutableCollections_List12) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *ImmutableCollections_List12) Reversed__List() List { return t.Impl_Reversed__List(t) }

func (t *ImmutableCollections_List12) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *ImmutableCollections_List12) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *ImmutableCollections_List12) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ImmutableCollections_List12) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ImmutableCollections_List12) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_List12) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *ImmutableCollections_List12) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *ImmutableCollections_List12) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ImmutableCollections_List12) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *ImmutableCollections_List12) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_List12) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *ImmutableCollections_List12) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ImmutableCollections_List12) OutOfBounds_I__IndexOutOfBoundsException(p0 int32) IndexOutOfBoundsException_I { return t.Impl_OutOfBounds_I__IndexOutOfBoundsException(t, p0) }

func (t *ImmutableCollections_List12) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *ImmutableCollections_List12) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *ImmutableCollections_List12) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ImmutableCollections_List12) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ImmutableCollections_List12) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_List12) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *ImmutableCollections_List12) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_List12) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ImmutableCollections_List12) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_List12) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_List12) GetClass__Class() *Class { return ImmutableCollections_List12_class }

func (t *ImmutableCollections_List12) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_List12) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_List12_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_List12); return ok }

func ImmutableCollections_List12_Cast(x any) *ImmutableCollections_List12 { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_List12); if !ok { panic(ClassCast(x, ImmutableCollections_List12_class)) }; return v }



type ImmutableCollections_ListItr struct{ Object; F_list List; F_size int32; F_isListIterator bool; F_cursor int32 }

func (t *ImmutableCollections_ListItr) Is_ListIterator() {}

func (t *ImmutableCollections_ListItr) Is_Iterator() {}

func (t *ImmutableCollections_ListItr) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ImmutableCollections_ListItr) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_ListItr) GetClass__Class() *Class { return ImmutableCollections_ListItr_class }

func (t *ImmutableCollections_ListItr) ToString__String() *String { return Object_toString(t) }

func (t *ImmutableCollections_ListItr) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_ListItr) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_ListItr_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_ListItr); return ok }

func ImmutableCollections_ListItr_Cast(x any) *ImmutableCollections_ListItr { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_ListItr); if !ok { panic(ClassCast(x, ImmutableCollections_ListItr_class)) }; return v }



type ImmutableCollections_ListN struct{ ImmutableCollections_AbstractImmutableList; F_elements *RefArray; F_allowNulls bool }

func (t *ImmutableCollections_ListN) Is_Serializable() {}

func (t *ImmutableCollections_ListN) Spliterator__Spliterator() Spliterator { return List_Spliterator__Spliterator(t) }

func (t *ImmutableCollections_ListN) SubList_I_I__List(p0, p1 int32) List { return t.Impl_SubList_I_I__List(t, p0, p1) }

func (t *ImmutableCollections_ListN) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *ImmutableCollections_ListN) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_ListN) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *ImmutableCollections_ListN) Reversed__SequencedCollection() SequencedCollection { return t.Impl_Reversed__SequencedCollection(t) }

func (t *ImmutableCollections_ListN) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_ListN) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *ImmutableCollections_ListN) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *ImmutableCollections_ListN) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *ImmutableCollections_ListN) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *ImmutableCollections_ListN) Reversed__List() List { return t.Impl_Reversed__List(t) }

func (t *ImmutableCollections_ListN) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *ImmutableCollections_ListN) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *ImmutableCollections_ListN) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ImmutableCollections_ListN) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ImmutableCollections_ListN) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_ListN) Iterator__Iterator() Iterator { return t.Impl_Iterator__Iterator(t) }

func (t *ImmutableCollections_ListN) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *ImmutableCollections_ListN) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ImmutableCollections_ListN) GetLast__O() any { return List_GetLast__O(t) }

func (t *ImmutableCollections_ListN) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *ImmutableCollections_ListN) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_ListN) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *ImmutableCollections_ListN) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ImmutableCollections_ListN) OutOfBounds_I__IndexOutOfBoundsException(p0 int32) IndexOutOfBoundsException_I { return t.Impl_OutOfBounds_I__IndexOutOfBoundsException(t, p0) }

func (t *ImmutableCollections_ListN) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *ImmutableCollections_ListN) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ImmutableCollections_ListN) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *ImmutableCollections_ListN) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ImmutableCollections_ListN) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ImmutableCollections_ListN) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_ListN) ListIterator_I__ListIterator(p0 int32) ListIterator { return t.Impl_ListIterator_I__ListIterator(t, p0) }

func (t *ImmutableCollections_ListN) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_ListN) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ImmutableCollections_ListN) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_ListN) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_ListN) GetClass__Class() *Class { return ImmutableCollections_ListN_class }

func (t *ImmutableCollections_ListN) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_ListN) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_ListN_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_ListN); return ok }

func ImmutableCollections_ListN_Cast(x any) *ImmutableCollections_ListN { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_ListN); if !ok { panic(ClassCast(x, ImmutableCollections_ListN_class)) }; return v }



type ImmutableCollections_Map1 struct{ ImmutableCollections_AbstractImmutableMap; F_k0, F_v0 any }

func (t *ImmutableCollections_Map1) Is_Serializable() {}

func (t *ImmutableCollections_Map1) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_Map1) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_Map1) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *ImmutableCollections_Map1) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *ImmutableCollections_Map1) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *ImmutableCollections_Map1) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_Map1) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *ImmutableCollections_Map1) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *ImmutableCollections_Map1) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *ImmutableCollections_Map1) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_Map1) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *ImmutableCollections_Map1) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_Map1) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *ImmutableCollections_Map1) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *ImmutableCollections_Map1) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *ImmutableCollections_Map1) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *ImmutableCollections_Map1) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ImmutableCollections_Map1) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_Map1) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_Map1) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_Map1) GetClass__Class() *Class { return ImmutableCollections_Map1_class }

func (t *ImmutableCollections_Map1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_Map1_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_Map1); return ok }

func ImmutableCollections_Map1_Cast(x any) *ImmutableCollections_Map1 { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_Map1); if !ok { panic(ClassCast(x, ImmutableCollections_Map1_class)) }; return v }



type ImmutableCollections_MapN struct{ ImmutableCollections_AbstractImmutableMap; F_table *RefArray; F_size int32 }

func (t *ImmutableCollections_MapN) Is_Serializable() {}

func (t *ImmutableCollections_MapN) Replace_O_O__O(p0, p1 any) any { return t.Impl_Replace_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_MapN) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_MapN) Compute_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_Compute_O_BiFunction__O(t, p0, p1) }

func (t *ImmutableCollections_MapN) Remove_O_O__Z(p0, p1 any) bool { return t.Impl_Remove_O_O__Z(t, p0, p1) }

func (t *ImmutableCollections_MapN) PutAll_Map__V(p0 Map) { t.Impl_PutAll_Map__V(t, p0) }

func (t *ImmutableCollections_MapN) GetOrDefault_O_O__O(p0, p1 any) any { return t.Impl_GetOrDefault_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_MapN) Merge_O_O_BiFunction__O(p0, p1 any, p2 BiFunction) any { return t.Impl_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *ImmutableCollections_MapN) ComputeIfPresent_O_BiFunction__O(p0 any, p1 BiFunction) any { return t.Impl_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *ImmutableCollections_MapN) ReplaceAll_BiFunction__V(p0 BiFunction) { t.Impl_ReplaceAll_BiFunction__V(t, p0) }

func (t *ImmutableCollections_MapN) PutIfAbsent_O_O__O(p0, p1 any) any { return t.Impl_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_MapN) ForEach_BiConsumer__V(p0 BiConsumer) { Map_ForEach_BiConsumer__V(t, p0) }

func (t *ImmutableCollections_MapN) Values__Collection() Collection { return t.Impl_Values__Collection(t) }

func (t *ImmutableCollections_MapN) Put_O_O__O(p0, p1 any) any { return t.Impl_Put_O_O__O(t, p0, p1) }

func (t *ImmutableCollections_MapN) Replace_O_O_O__Z(p0, p1, p2 any) bool { return t.Impl_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *ImmutableCollections_MapN) KeySet__Set() Set { return t.Impl_KeySet__Set(t) }

func (t *ImmutableCollections_MapN) ComputeIfAbsent_O_Function__O(p0 any, p1 Function) any { return t.Impl_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *ImmutableCollections_MapN) Remove_O__O(p0 any) any { return t.Impl_Remove_O__O(t, p0) }

func (t *ImmutableCollections_MapN) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ImmutableCollections_MapN) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_MapN) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_MapN) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_MapN) GetClass__Class() *Class { return ImmutableCollections_MapN_class }

func (t *ImmutableCollections_MapN) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_MapN_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_MapN); return ok }

func ImmutableCollections_MapN_Cast(x any) *ImmutableCollections_MapN { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_MapN); if !ok { panic(ClassCast(x, ImmutableCollections_MapN_class)) }; return v }



type ImmutableCollections_MapN_1 struct{ AbstractSet; F_this_0 *ImmutableCollections_MapN }

func ImmutableCollections_MapN_1_New_ImmutableCollections_MapN(p0 *ImmutableCollections_MapN) *ImmutableCollections_MapN_1 { t := &ImmutableCollections_MapN_1{}; t.Ctor_ImmutableCollections_MapN(p0); return t }

func (t *ImmutableCollections_MapN_1) Ctor_ImmutableCollections_MapN(this_0 *ImmutableCollections_MapN) { NN(this_0); t.F_this_0 = this_0; t.AbstractSet.Ctor(t) }

func (t *ImmutableCollections_MapN_1) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *ImmutableCollections_MapN_1) RemoveIf_Predicate__Z(p0 Predicate) bool { return Collection_RemoveIf_Predicate__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_MapN_1) ToArray_O1__O1(p0 *RefArray) *RefArray { return t.Impl_ToArray_O1__O1(t, p0) }

func (t *ImmutableCollections_MapN_1) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ImmutableCollections_MapN_1) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) ToArray__O1() *RefArray { return t.Impl_ToArray__O1(t) }

func (t *ImmutableCollections_MapN_1) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ImmutableCollections_MapN_1) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ImmutableCollections_MapN_1) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ImmutableCollections_MapN_1) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ImmutableCollections_MapN_1) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_MapN_1) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ImmutableCollections_MapN_1) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_MapN_1) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_MapN_1) GetClass__Class() *Class { return ImmutableCollections_MapN_1_class }

func (t *ImmutableCollections_MapN_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_MapN_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_MapN_1_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_MapN_1); return ok }

func ImmutableCollections_MapN_1_Cast(x any) *ImmutableCollections_MapN_1 { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_MapN_1); if !ok { panic(ClassCast(x, ImmutableCollections_MapN_1_class)) }; return v }



type ImmutableCollections_MapN_MapNIterator struct{ Object; F_remaining, F_idx int32; F_this_0 *ImmutableCollections_MapN }

func (t *ImmutableCollections_MapN_MapNIterator) Is_Iterator() {}

func (t *ImmutableCollections_MapN_MapNIterator) Next__O() any { return t.Next__Map_Entry() }

func (t *ImmutableCollections_MapN_MapNIterator) Remove__V() { Iterator_Remove__V(t) }

func (t *ImmutableCollections_MapN_MapNIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ImmutableCollections_MapN_MapNIterator) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_MapN_MapNIterator) GetClass__Class() *Class { return ImmutableCollections_MapN_MapNIterator_class }

func (t *ImmutableCollections_MapN_MapNIterator) ToString__String() *String { return Object_toString(t) }

func (t *ImmutableCollections_MapN_MapNIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_MapN_MapNIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_MapN_MapNIterator_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_MapN_MapNIterator); return ok }

func ImmutableCollections_MapN_MapNIterator_Cast(x any) *ImmutableCollections_MapN_MapNIterator { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_MapN_MapNIterator); if !ok { panic(ClassCast(x, ImmutableCollections_MapN_MapNIterator_class)) }; return v }



type ImmutableCollections_Set12 struct{ ImmutableCollections_AbstractImmutableSet; F_e0, F_e1 any }

func (t *ImmutableCollections_Set12) Is_Serializable() {}

func (t *ImmutableCollections_Set12) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *ImmutableCollections_Set12) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_Set12) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_Set12) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ImmutableCollections_Set12) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ImmutableCollections_Set12) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_Set12) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ImmutableCollections_Set12) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_Set12) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ImmutableCollections_Set12) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ImmutableCollections_Set12) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_Set12) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_Set12) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_Set12) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_Set12) GetClass__Class() *Class { return ImmutableCollections_Set12_class }

func (t *ImmutableCollections_Set12) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_Set12) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_Set12_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_Set12); return ok }

func ImmutableCollections_Set12_Cast(x any) *ImmutableCollections_Set12 { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_Set12); if !ok { panic(ClassCast(x, ImmutableCollections_Set12_class)) }; return v }



type ImmutableCollections_Set12_1 struct{ Object; F_idx int32; F_this_0 *ImmutableCollections_Set12 }

func (t *ImmutableCollections_Set12_1) Is_Iterator() {}

func ImmutableCollections_Set12_1_New_ImmutableCollections_Set12(p0 *ImmutableCollections_Set12) *ImmutableCollections_Set12_1 { t := &ImmutableCollections_Set12_1{}; t.Ctor_ImmutableCollections_Set12(p0); return t }

func (t *ImmutableCollections_Set12_1) Ctor_ImmutableCollections_Set12(this_0 *ImmutableCollections_Set12) { NN(this_0); t.F_this_0 = this_0
//line :541:1
	var tmp1 int32; var tmp2 any = this_0.F_e1; var tmp3 any; ImmutableCollections_Init(); tmp3 = ImmutableCollections_EMPTY; if tmp2 == tmp3 { tmp1 = 1 } else { tmp1 = 2 }; t.F_idx = tmp1
}


































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































func (t *ImmutableCollections_Set12_1) Remove__V() { Iterator_Remove__V(t) }

func (t *ImmutableCollections_Set12_1) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ImmutableCollections_Set12_1) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_Set12_1) GetClass__Class() *Class { return ImmutableCollections_Set12_1_class }

func (t *ImmutableCollections_Set12_1) ToString__String() *String { return Object_toString(t) }

func (t *ImmutableCollections_Set12_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_Set12_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_Set12_1_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_Set12_1); return ok }

func ImmutableCollections_Set12_1_Cast(x any) *ImmutableCollections_Set12_1 { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_Set12_1); if !ok { panic(ClassCast(x, ImmutableCollections_Set12_1_class)) }; return v }



type ImmutableCollections_SetN struct{ ImmutableCollections_AbstractImmutableSet; F_elements *RefArray; F_size int32 }

func (t *ImmutableCollections_SetN) Is_Serializable() {}

func (t *ImmutableCollections_SetN) Spliterator__Spliterator() Spliterator { return Set_Spliterator__Spliterator(t) }

func (t *ImmutableCollections_SetN) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *ImmutableCollections_SetN) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_SetN) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SetN) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ImmutableCollections_SetN) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ImmutableCollections_SetN) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SetN) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ImmutableCollections_SetN) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SetN) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ImmutableCollections_SetN) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ImmutableCollections_SetN) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ImmutableCollections_SetN) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SetN) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_SetN) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_SetN) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_SetN) GetClass__Class() *Class { return ImmutableCollections_SetN_class }

func (t *ImmutableCollections_SetN) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_SetN) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_SetN_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_SetN); return ok }

func ImmutableCollections_SetN_Cast(x any) *ImmutableCollections_SetN { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_SetN); if !ok { panic(ClassCast(x, ImmutableCollections_SetN_class)) }; return v }



type ImmutableCollections_SetN_SetNIterator struct{ Object; F_remaining, F_idx int32; F_this_0 *ImmutableCollections_SetN }

func (t *ImmutableCollections_SetN_SetNIterator) Is_Iterator() {}

func (t *ImmutableCollections_SetN_SetNIterator) Remove__V() { Iterator_Remove__V(t) }

func (t *ImmutableCollections_SetN_SetNIterator) ForEachRemaining_Consumer__V(p0 Consumer) { Iterator_ForEachRemaining_Consumer__V(t, p0) }

func (t *ImmutableCollections_SetN_SetNIterator) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_SetN_SetNIterator) GetClass__Class() *Class { return ImmutableCollections_SetN_SetNIterator_class }

func (t *ImmutableCollections_SetN_SetNIterator) ToString__String() *String { return Object_toString(t) }

func (t *ImmutableCollections_SetN_SetNIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_SetN_SetNIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_SetN_SetNIterator_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_SetN_SetNIterator); return ok }

func ImmutableCollections_SetN_SetNIterator_Cast(x any) *ImmutableCollections_SetN_SetNIterator { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_SetN_SetNIterator); if !ok { panic(ClassCast(x, ImmutableCollections_SetN_SetNIterator_class)) }; return v }



type ImmutableCollections_SubList struct{ ImmutableCollections_AbstractImmutableList; F_root ImmutableCollections_AbstractImmutableList_I; F_offset, F_size int32 }

var ImmutableCollections_SubList_init ClassInit

func ImmutableCollections_SubList_Init() { if !ImmutableCollections_SubList_init.Done() { ImmutableCollections_SubList_init.Run(ImmutableCollections_SubList_clinit) } }

func ImmutableCollections_SubList_clinit() {}

func (t *ImmutableCollections_SubList) Spliterator__Spliterator() Spliterator { return List_Spliterator__Spliterator(t) }

func (t *ImmutableCollections_SubList) RemoveIf_Predicate__Z(p0 Predicate) bool { return t.Impl_RemoveIf_Predicate__Z(t, p0) }

func (t *ImmutableCollections_SubList) Clear__V() { t.Impl_Clear__V(t) }

func (t *ImmutableCollections_SubList) GetFirst__O() any { return List_GetFirst__O(t) }

func (t *ImmutableCollections_SubList) Reversed__SequencedCollection() SequencedCollection { return t.Impl_Reversed__SequencedCollection(t) }

func (t *ImmutableCollections_SubList) RemoveAll_Collection__Z(p0 Collection) bool { return t.Impl_RemoveAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SubList) Set_I_O__O(p0 int32, p1 any) any { return t.Impl_Set_I_O__O(t, p0, p1) }

func (t *ImmutableCollections_SubList) Sort_Comparator__V(p0 Comparator) { t.Impl_Sort_Comparator__V(t, p0) }

func (t *ImmutableCollections_SubList) ListIterator__ListIterator() ListIterator { return t.Impl_ListIterator__ListIterator(t) }

func (t *ImmutableCollections_SubList) AddFirst_O__V(p0 any) { List_AddFirst_O__V(t, p0) }

func (t *ImmutableCollections_SubList) Reversed__List() List { return t.Impl_Reversed__List(t) }

func (t *ImmutableCollections_SubList) ReplaceAll_UnaryOperator__V(p0 UnaryOperator) { t.Impl_ReplaceAll_UnaryOperator__V(t, p0) }

func (t *ImmutableCollections_SubList) Remove_I__O(p0 int32) any { return t.Impl_Remove_I__O(t, p0) }

func (t *ImmutableCollections_SubList) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ImmutableCollections_SubList) Remove_O__Z(p0 any) bool { return t.Impl_Remove_O__Z(t, p0) }

func (t *ImmutableCollections_SubList) RetainAll_Collection__Z(p0 Collection) bool { return t.Impl_RetainAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SubList) AddAll_I_Collection__Z(p0 int32, p1 Collection) bool { return t.Impl_AddAll_I_Collection__Z(t, p0, p1) }

func (t *ImmutableCollections_SubList) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ImmutableCollections_SubList) GetLast__O() any { return List_GetLast__O(t) }

func (t *ImmutableCollections_SubList) RemoveLast__O() any { return t.Impl_RemoveLast__O(t) }

func (t *ImmutableCollections_SubList) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SubList) IsEmpty__Z() bool { return t.Impl_IsEmpty__Z(t) }

func (t *ImmutableCollections_SubList) RemoveFirst__O() any { return t.Impl_RemoveFirst__O(t) }

func (t *ImmutableCollections_SubList) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ImmutableCollections_SubList) OutOfBounds_I__IndexOutOfBoundsException(p0 int32) IndexOutOfBoundsException_I { return t.Impl_OutOfBounds_I__IndexOutOfBoundsException(t, p0) }

func (t *ImmutableCollections_SubList) Add_I_O__V(p0 int32, p1 any) { t.Impl_Add_I_O__V(t, p0, p1) }

func (t *ImmutableCollections_SubList) ForEach_Consumer__V(p0 Consumer) { Iterable_ForEach_Consumer__V(t, p0) }

func (t *ImmutableCollections_SubList) AddLast_O__V(p0 any) { List_AddLast_O__V(t, p0) }

func (t *ImmutableCollections_SubList) Contains_O__Z(p0 any) bool { return t.Impl_Contains_O__Z(t, p0) }

func (t *ImmutableCollections_SubList) Add_O__Z(p0 any) bool { return t.Impl_Add_O__Z(t, p0) }

func (t *ImmutableCollections_SubList) AddAll_Collection__Z(p0 Collection) bool { return t.Impl_AddAll_Collection__Z(t, p0) }

func (t *ImmutableCollections_SubList) Equals_O__Z(p0 any) bool { return t.Impl_Equals_O__Z(t, p0) }

func (t *ImmutableCollections_SubList) HashCode__I() int32 { return t.Impl_HashCode__I(t) }

func (t *ImmutableCollections_SubList) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ImmutableCollections_SubList) Ref() any { if t == nil { return nil }; return t }

func (t *ImmutableCollections_SubList) GetClass__Class() *Class { return ImmutableCollections_SubList_class }

func (t *ImmutableCollections_SubList) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ImmutableCollections_SubList) CloneShallow() any { panic(CloneNotSupported(t)) }

func ImmutableCollections_SubList_InstanceOf(x any) bool { _, ok := x.(*ImmutableCollections_SubList); return ok }

func ImmutableCollections_SubList_Cast(x any) *ImmutableCollections_SubList { if x == nil { return nil }; v, ok := x.(*ImmutableCollections_SubList); if !ok { panic(ClassCast(x, ImmutableCollections_SubList_class)) }; return v }
