//line forkjoin.ae:1
package jrt

import (
	"strconv"
	"sync"
	"sync/atomic"
	"time"
)








// ForkJoinTask_I is java.util.concurrent.ForkJoinTask's class interface.
type ForkJoinTask_I /*line :19:1*/ interface { Object_I; Future; Serializable
	Self_ForkJoinTask() *ForkJoinTask
	Exec__Z() bool
	GetRawResult__O() any
	SetRawResult_O__V(v any)
	Fork__ForkJoinTask() ForkJoinTask_I
	Join__O() any
	Invoke__O() any
	IsCompletedNormally__Z() bool
	IsCompletedAbnormally__Z() bool
	GetException__Throwable() Throwable_I
	QuietlyJoin__V()
	QuietlyInvoke__V()
	Complete_O__V(v any)
	CompleteExceptionally_Throwable__V(ex Throwable_I)
	TryUnfork__Z() bool
	QuietlyComplete__V()
	TrySetThrown_Throwable__Z(ex Throwable_I) bool
	GetForkJoinTaskTag__S() int16
	SetForkJoinTaskTag_S__S(v int16) int16
	CompareAndSetForkJoinTaskTag_S_S__Z(e, v int16) bool }
// ForkJoinTask is java.util.concurrent.ForkJoinTask's struct: the task's state (fjNew, then
// fjRunning once claimed, fjDone), the exception it completed with, whether it was cancelled,
// and the channel its waiters receive from (made by the first waiter, closed when it is done).
//line :41:1
type ForkJoinTask /*line :45:1*/ struct {
	Object
	state     atomic.Int32
	exc       Throwable_I
	cancelled bool
	mu        sync.Mutex
	doneCh    /*line :50:1*/ chan struct{}
	// the task's tag (getForkJoinTaskTag; CompletableFuture's claims)
	tag atomic.Int32 }
const (
	fjNew int32 = iota
	fjRunning
	fjDone
)
var ForkJoinTask_class =
	Define(&ClassInfo{Name: "java.util.concurrent.ForkJoinTask", Kind: KindClass,
				Modifiers:                                 AccPublic | AccAbstract, Super:                 Object_class,
				Interfaces:                                []*Class{Future_class, Serializable_class}, Go: "arbace/jrt.ForkJoinTask",
	})
// Ctor is ForkJoinTask().
func (t *ForkJoinTask) Ctor(this ForkJoinTask_I) {}
func (t *ForkJoinTask) Self_ForkJoinTask() *ForkJoinTask { return t }
func (t *ForkJoinTask) Is_Future() {}
// GetForkJoinTaskTag__S is the final getForkJoinTaskTag.
//line :67:1
func (t /*line :68:1*/*ForkJoinTask) GetForkJoinTaskTag__S() int16 {
	return int16(t.tag.Load()) }
// SetForkJoinTaskTag_S__S is setForkJoinTaskTag: the previous tag.
//line :70:1
func (t /*line :71:1*/*ForkJoinTask) SetForkJoinTaskTag_S__S(v int16) int16 {
	return int16(t.tag.Swap(int32(v))) }
// CompareAndSetForkJoinTaskTag_S_S__Z is compareAndSetForkJoinTaskTag (CompletableFuture's
// claim of a completion).
//line :73:1
func (t /*line :76:1*/*ForkJoinTask) CompareAndSetForkJoinTaskTag_S_S__Z(e, v int16) bool {
	return t.tag.CompareAndSwap(int32(e), int32(v)) }
// Impl_ResultNow__O is resultNow: Future's default (JDK 19).
//line :78:1
func (t /*line :79:1*/*ForkJoinTask) Impl_ResultNow__O(this ForkJoinTask_I) any { return Future_ResultNow__O(this) }
func (t *ForkJoinTask) Impl_ExceptionNow__Throwable(this ForkJoinTask_I) Throwable_I {
	return Future_ExceptionNow__Throwable(this) }
func (t *ForkJoinTask) Impl_State__Future_State(this ForkJoinTask_I) *Future_State {
	return Future_State__Future_State(this) }
func (t *ForkJoinTask) Is_Serializable() {}
// tryRun runs the task (exec) when no one has claimed it yet, keeping its exception, and
// reports whether it did. A task whose exec returns false (a CountedCompleter) is done only when
// completed explicitly (quietlyComplete, tryComplete).
//line :86:1
func (t /*line :90:1*/*ForkJoinTask) tryRun(this ForkJoinTask_I) bool {
	if !t.state.CompareAndSwap(fjNew, fjRunning) {
		return false }
	{ var completed bool = false
		exc := runCatching(func() { completed = this.Exec__Z() })
		if completed || exc != nil {
			t.finish(exc) } }; return true }
// runForked runs a forked task: as tryRun, and also when the task was run before without
// completing (a CountedCompleter whose exec returned false), as the JDK's doExec runs any task
// not yet done: CountedCompleters fork such a task again to continue it (ArrayPrefixHelpers'
// cumulation, amendment JB4).
//line :99:1
func (t /*line :104:1*/*ForkJoinTask) runForked(this ForkJoinTask_I) {
	if t.tryRun(this) {
		return }
	if t.state.Load() != fjRunning {
		return }
	var completed bool = false
	exc := runCatching(func() { completed = this.Exec__Z() })
	if completed || exc != nil {
		t.finish(exc) } }
// finish completes the task with exc (nil: normally) and releases its waiters;
// it reports false, doing nothing, when the task was done already.
//line :114:1
func (t /*line :116:1*/*ForkJoinTask) finish(exc Throwable_I) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.state.Load() == fjDone {
		return false }
	t.exc = exc
	t.state.Store(fjDone)
	if t.doneCh != nil {
		close(t.doneCh)
	}; return true }
// await waits until the task is done (run by another thread).
func (t /*line :128:1*/*ForkJoinTask) await() {
	if t.state.Load() == fjDone {
		return }
	t.mu.Lock()
	if t.state.Load() == fjDone {
		t.mu.Unlock()
		return }
	if t.doneCh == nil {
		t.doneCh = make(chan struct{}) }
	c := t.doneCh
	t.mu.Unlock()
	<-c }
// complete runs the task if no one has, then waits until it is done.
func (t /*line :142:1*/*ForkJoinTask) complete(this ForkJoinTask_I) {
	t.tryRun(this)
	t.await() }
// QuietlyComplete__V is quietlyComplete: the task done normally,
// without setting a result (a CountedCompleter's completion).
//line :146:1
func (t /*line :148:1*/*ForkJoinTask) QuietlyComplete__V() {
	t.state.CompareAndSwap(fjNew, fjRunning)
	t.finish(nil) }
// TrySetThrown_Throwable__Z is the package-private
// trySetThrown: the task done with ex unless it is done already.
//line :152:1
func (t /*line :154:1*/*ForkJoinTask) TrySetThrown_Throwable__Z(ex Throwable_I) bool {
	t.state.CompareAndSwap(fjNew, fjRunning)
	return t.finish(ex) }
// Impl_Fork__ForkJoinTask is fork: the task goes to the current worker's pool, or the common
// pool outside one (ForkJoinPool.spawn: a new worker, or the joiner).
//line :158:1
func (t /*line :161:1*/*ForkJoinTask) Impl_Fork__ForkJoinTask(this ForkJoinTask_I) ForkJoinTask_I {
	{ p := currentPool()
		if p == nil {
			p = ForkJoinPool_CommonPool__ForkJoinPool() }
		p.spawn(this)
	}; return this }
// Impl_Join__O is join: the task run or awaited, its exception rethrown, its result.
func (t /*line :169:1*/*ForkJoinTask) Impl_Join__O(this ForkJoinTask_I) any {
	t.complete(this)
	if t.exc != nil {
		panic(t.exc) }
	return this.GetRawResult__O() }
// Impl_Invoke__O is invoke: the task run now (unless it runs elsewhere), then join.
func (t /*line :176:1*/*ForkJoinTask) Impl_Invoke__O(this ForkJoinTask_I) any {
	return t.Impl_Join__O(this)
}
func (t *ForkJoinTask) Impl_QuietlyJoin__V(this ForkJoinTask_I) { t.complete(this) }
func (t *ForkJoinTask) Impl_QuietlyInvoke__V(this ForkJoinTask_I) { t.complete(this) }
// Impl_Get__O is get: join's result, its exception as an ExecutionException.
func (t /*line :183:1*/*ForkJoinTask) Impl_Get__O(this ForkJoinTask_I) any {
	t.complete(this)
	if t.exc != nil {
		if t.cancelled {
			panic(t.exc) }
		panic(ExecutionException_New_Throwable(t.exc)) }
	return this.GetRawResult__O()
}
func (t *ForkJoinTask) Impl_Get_J_TimeUnit__O(this ForkJoinTask_I, timeout int64, unit *TimeUnit) any {
	return t.Impl_Get__O(this) }
// Impl_Cancel_Z__Z is cancel: a task no one has claimed completes with a
// CancellationException; a running or completed one is not cancelled (false, true when it was).
//line :194:1
func (t /*line :196:1*/*ForkJoinTask) Impl_Cancel_Z__Z(this ForkJoinTask_I, may bool) bool {
	if t.state.CompareAndSwap(fjNew, fjRunning) {
		t.cancelled = true
		t.finish(CancellationException_New())
		return true }
	t.await()
	return t.cancelled
}
func (t *ForkJoinTask) Impl_IsCancelled__Z(this ForkJoinTask_I) bool {
	return t.state.Load() == fjDone && t.cancelled }
func (t *ForkJoinTask) Impl_IsDone__Z(this ForkJoinTask_I) bool { return t.state.Load() == fjDone }
func (t *ForkJoinTask) Impl_IsCompletedNormally__Z(this ForkJoinTask_I) bool {
	return t.state.Load() == fjDone && t.exc == nil }
func (t *ForkJoinTask) Impl_IsCompletedAbnormally__Z(this ForkJoinTask_I) bool {
	return t.state.Load() == fjDone && t.exc != nil }
func (t *ForkJoinTask) Impl_GetException__Throwable(this ForkJoinTask_I) Throwable_I {
	if t.state.Load() != fjDone {
		return nil }
	return t.exc }
// Impl_Complete_O__V is complete(value): the result set, the task done
// normally (one not yet run is not run).
//line :216:1
func (t /*line :218:1*/*ForkJoinTask) Impl_Complete_O__V(this ForkJoinTask_I, v any) {
	this.SetRawResult_O__V(v)
	t.state.CompareAndSwap(fjNew, fjRunning)
	t.finish(nil) }
// Impl_CompleteExceptionally_Throwable__V is completeExceptionally: the task done with ex, a
// checked exception wrapped in a RuntimeException as the JDK wraps it.
//line :223:1
func (t /*line :226:1*/*ForkJoinTask) Impl_CompleteExceptionally_Throwable__V(this ForkJoinTask_I, ex Throwable_I) {
	if ex != nil && !RuntimeException_InstanceOf(ex) && !Error_InstanceOf(ex) {
		ex = RuntimeException_New_Throwable(ex) }
	t.state.CompareAndSwap(fjNew, fjRunning)
	t.finish(ex) }
// Impl_TryUnfork__Z is tryUnfork: a forked task no one has claimed is
// taken back (it then runs when joined or invoked).
//line :232:1
func (t /*line :234:1*/*ForkJoinTask) Impl_TryUnfork__Z(this ForkJoinTask_I) bool { return false }
// ForkJoinTask_InForkJoinPool__Z is ForkJoinTask.inForkJoinPool(): whether the current thread
// is a pool's worker.
func ForkJoinTask_InForkJoinPool__Z() bool {



	return currentPool() != nil }
// ForkJoinTask_GetPool__ForkJoinPool is ForkJoinTask.getPool(): the current worker's pool, or null.
func ForkJoinTask_GetPool__ForkJoinPool(

) *ForkJoinPool {
	return currentPool() }
// ForkJoinTask_InvokeAll_ForkJoinTask_ForkJoinTask__V is invokeAll(t1, t2): t2 forked, t1
// invoked, t2 joined.
//line :248:1
func ForkJoinTask_InvokeAll_ForkJoinTask_ForkJoinTask__V(t1, t2 ForkJoinTask_I) {



	nnIface(t1)
	nnIface(t2)
	t2.Fork__ForkJoinTask()
	t1.Invoke__O()
	t2.Join__O()
}
func ForkJoinTask_InstanceOf(x any) bool { _, ok := x.(ForkJoinTask_I); return ok }
func ForkJoinTask_Cast(x any) ForkJoinTask_I {
	if x == nil { return nil }
	v, ok := x.(ForkJoinTask_I)
	if !ok { panic(ClassCast(x, ForkJoinTask_class))
	}
	return v
}

// ForkJoinTask_AdaptedCallable is java.util.concurrent.ForkJoinTask$AdaptedCallable.
type ForkJoinTask_AdaptedCallable /*line :270:1*/ struct{ ForkJoinTask; callable Callable; result any }
// ForkJoinTask_AdaptedRunnable is java.util.concurrent.ForkJoinTask$AdaptedRunnable.
//line :271:1
type ForkJoinTask_AdaptedRunnable /*line :273:1*/ struct{ ForkJoinTask; runnable Runnable; result any }
// ForkJoinTask_AdaptedRunnableAction is java.util.concurrent.ForkJoinTask$AdaptedRunnableAction.
//line :274:1
type ForkJoinTask_AdaptedRunnableAction /*line :276:1*/ struct{ ForkJoinTask; runnable Runnable }

var (

	ForkJoinTask_AdaptedCallable_class = Define(&ClassInfo{Name: "java.util.concurrent.ForkJoinTask$AdaptedCallable", Kind: KindClass,
						Modifiers:                AccStatic | AccFinal, Super:                               ForkJoinTask_class,
						Interfaces:               []*Class{Runnable_class}, Go:                              "arbace/jrt.ForkJoinTask_AdaptedCallable",
	},
	)
	ForkJoinTask_AdaptedRunnable_class = Define(&ClassInfo{Name: "java.util.concurrent.ForkJoinTask$AdaptedRunnable", Kind: KindClass,
						Modifiers:                AccStatic | AccFinal, Super:                               ForkJoinTask_class,
						Interfaces:               []*Class{Runnable_class}, Go:                              "arbace/jrt.ForkJoinTask_AdaptedRunnable",
	},
	)
	ForkJoinTask_AdaptedRunnableAction_class = Define(&ClassInfo{Name: "java.util.concurrent.ForkJoinTask$AdaptedRunnableAction", Kind: KindClass,
							Modifiers:                AccStatic | AccFinal, Super:                                     ForkJoinTask_class,
							Interfaces:               []*Class{Runnable_class}, Go:                                    "arbace/jrt.ForkJoinTask_AdaptedRunnableAction"}))
// ForkJoinTask_Adapt_Callable__ForkJoinTask is ForkJoinTask.adapt(Callable): exec calls it, a
// checked exception wrapped in a RuntimeException.
func ForkJoinTask_Adapt_Callable__ForkJoinTask(c Callable) ForkJoinTask_I {



	return &ForkJoinTask_AdaptedCallable{callable: nnIface(c)} }
// ForkJoinTask_Adapt_Runnable_O__ForkJoinTask is ForkJoinTask.adapt(Runnable, result).
//line :300:1
func ForkJoinTask_Adapt_Runnable_O__ForkJoinTask(r Runnable, result any) ForkJoinTask_I {


	return &ForkJoinTask_AdaptedRunnable{runnable: nnIface(r), result: result} }
// ForkJoinTask_Adapt_Runnable__ForkJoinTask is ForkJoinTask.adapt(Runnable).
//line :304:1
func ForkJoinTask_Adapt_Runnable__ForkJoinTask(r Runnable) ForkJoinTask_I {


	return &ForkJoinTask_AdaptedRunnableAction{runnable: nnIface(r)}
}
func (t *ForkJoinTask_AdaptedCallable) Exec__Z() bool {
	{ exc := runCatching(func() { t.result = t.callable.Call__O() })
		if exc != nil {
			if RuntimeException_InstanceOf(exc) || Error_InstanceOf(exc) {
				panic(exc) }
			panic(RuntimeException_New_Throwable(exc))
		} }; return true }
func (t *ForkJoinTask_AdaptedRunnable) Exec__Z() bool { t.runnable.Run__V(); return true }
func (t *ForkJoinTask_AdaptedRunnableAction) Exec__Z() bool { t.runnable.Run__V(); return true }
func (t *ForkJoinTask_AdaptedCallable) GetRawResult__O() any { return t.result }
func (t *ForkJoinTask_AdaptedRunnable) GetRawResult__O() any { return t.result }
func (t *ForkJoinTask_AdaptedRunnableAction) GetRawResult__O() any { return nil }
func (t *ForkJoinTask_AdaptedCallable) SetRawResult_O__V(v any) { t.result = v }
func (t *ForkJoinTask_AdaptedRunnable) SetRawResult_O__V(v any) { t.result = v }
func (t *ForkJoinTask_AdaptedRunnableAction) SetRawResult_O__V(v any) {}
func (t *ForkJoinTask_AdaptedCallable) Run__V() { t.Invoke__O() }
func (t *ForkJoinTask_AdaptedRunnable) Run__V() { t.Invoke__O() }
func (t *ForkJoinTask_AdaptedRunnableAction) Run__V() { t.Invoke__O() }
func (t *ForkJoinTask_AdaptedCallable) Is_Runnable() {}
func (t *ForkJoinTask_AdaptedRunnable) Is_Runnable() {}
func (t *ForkJoinTask_AdaptedRunnableAction) Is_Runnable() {}


func (t *ForkJoinTask_AdaptedCallable) Fork__ForkJoinTask() ForkJoinTask_I { return (&t.ForkJoinTask).Impl_Fork__ForkJoinTask(t) }
func (t *ForkJoinTask_AdaptedCallable) Join__O() any { return (&t.ForkJoinTask).Impl_Join__O(t) }
func (t *ForkJoinTask_AdaptedCallable) Invoke__O() any { return (&t.ForkJoinTask).Impl_Invoke__O(t) }
func (t *ForkJoinTask_AdaptedCallable) QuietlyJoin__V() { (&t.ForkJoinTask).Impl_QuietlyJoin__V(t) }
func (t *ForkJoinTask_AdaptedCallable) QuietlyInvoke__V() { (&t.ForkJoinTask).Impl_QuietlyInvoke__V(t) }
func (t *ForkJoinTask_AdaptedCallable) Get__O() any { return (&t.ForkJoinTask).Impl_Get__O(t) }
func (t *ForkJoinTask_AdaptedCallable) Get_J_TimeUnit__O(timeout int64, unit *TimeUnit) any { return (&t.ForkJoinTask).Impl_Get_J_TimeUnit__O(t, timeout, unit) }
func (t *ForkJoinTask_AdaptedCallable) Cancel_Z__Z(may bool) bool { return (&t.ForkJoinTask).Impl_Cancel_Z__Z(t, may) }
func (t *ForkJoinTask_AdaptedCallable) IsCancelled__Z() bool { return (&t.ForkJoinTask).Impl_IsCancelled__Z(t) }
func (t *ForkJoinTask_AdaptedCallable) IsDone__Z() bool { return (&t.ForkJoinTask).Impl_IsDone__Z(t) }
func (t *ForkJoinTask_AdaptedCallable) IsCompletedNormally__Z() bool { return (&t.ForkJoinTask).Impl_IsCompletedNormally__Z(t) }
func (t *ForkJoinTask_AdaptedCallable) IsCompletedAbnormally__Z() bool { return (&t.ForkJoinTask).Impl_IsCompletedAbnormally__Z(t) }
func (t *ForkJoinTask_AdaptedCallable) GetException__Throwable() Throwable_I { return (&t.ForkJoinTask).Impl_GetException__Throwable(t) }
func (t *ForkJoinTask_AdaptedCallable) Complete_O__V(v any) { (&t.ForkJoinTask).Impl_Complete_O__V(t, v) }
func (t *ForkJoinTask_AdaptedCallable) CompleteExceptionally_Throwable__V(ex Throwable_I) { (&t.ForkJoinTask).Impl_CompleteExceptionally_Throwable__V(t, ex) }
func (t *ForkJoinTask_AdaptedCallable) TryUnfork__Z() bool { return (&t.ForkJoinTask).Impl_TryUnfork__Z(t) }
func (t *ForkJoinTask_AdaptedCallable) ResultNow__O() any { return (&t.ForkJoinTask).Impl_ResultNow__O(t) }
func (t *ForkJoinTask_AdaptedCallable) ExceptionNow__Throwable() Throwable_I { return (&t.ForkJoinTask).Impl_ExceptionNow__Throwable(t) }
func (t *ForkJoinTask_AdaptedCallable) State__Future_State() *Future_State { return (&t.ForkJoinTask).Impl_State__Future_State(t) }
func (t *ForkJoinTask_AdaptedCallable) Ref() any { if t == nil { return nil }; return t }
func (t *ForkJoinTask_AdaptedCallable) GetClass__Class() *Class { return ForkJoinTask_AdaptedCallable_class }
func (t *ForkJoinTask_AdaptedCallable) ToString__String() *String {
	return Concat(Object_toString(t), Str("[Wrapped task = "), StrOfObj(t.callable), Str("]")) }
func (t *ForkJoinTask_AdaptedCallable) Clone__O() any { panic(CloneNotSupported(t)) }

func (t *ForkJoinTask_AdaptedRunnable) Fork__ForkJoinTask() ForkJoinTask_I { return (&t.ForkJoinTask).Impl_Fork__ForkJoinTask(t) }
func (t *ForkJoinTask_AdaptedRunnable) Join__O() any { return (&t.ForkJoinTask).Impl_Join__O(t) }
func (t *ForkJoinTask_AdaptedRunnable) Invoke__O() any { return (&t.ForkJoinTask).Impl_Invoke__O(t) }
func (t *ForkJoinTask_AdaptedRunnable) QuietlyJoin__V() { (&t.ForkJoinTask).Impl_QuietlyJoin__V(t) }
func (t *ForkJoinTask_AdaptedRunnable) QuietlyInvoke__V() { (&t.ForkJoinTask).Impl_QuietlyInvoke__V(t) }
func (t *ForkJoinTask_AdaptedRunnable) Get__O() any { return (&t.ForkJoinTask).Impl_Get__O(t) }
func (t *ForkJoinTask_AdaptedRunnable) Get_J_TimeUnit__O(timeout int64, unit *TimeUnit) any { return (&t.ForkJoinTask).Impl_Get_J_TimeUnit__O(t, timeout, unit) }
func (t *ForkJoinTask_AdaptedRunnable) Cancel_Z__Z(may bool) bool { return (&t.ForkJoinTask).Impl_Cancel_Z__Z(t, may) }
func (t *ForkJoinTask_AdaptedRunnable) IsCancelled__Z() bool { return (&t.ForkJoinTask).Impl_IsCancelled__Z(t) }
func (t *ForkJoinTask_AdaptedRunnable) IsDone__Z() bool { return (&t.ForkJoinTask).Impl_IsDone__Z(t) }
func (t *ForkJoinTask_AdaptedRunnable) IsCompletedNormally__Z() bool { return (&t.ForkJoinTask).Impl_IsCompletedNormally__Z(t) }
func (t *ForkJoinTask_AdaptedRunnable) IsCompletedAbnormally__Z() bool { return (&t.ForkJoinTask).Impl_IsCompletedAbnormally__Z(t) }
func (t *ForkJoinTask_AdaptedRunnable) GetException__Throwable() Throwable_I { return (&t.ForkJoinTask).Impl_GetException__Throwable(t) }
func (t *ForkJoinTask_AdaptedRunnable) Complete_O__V(v any) { (&t.ForkJoinTask).Impl_Complete_O__V(t, v) }
func (t *ForkJoinTask_AdaptedRunnable) CompleteExceptionally_Throwable__V(ex Throwable_I) { (&t.ForkJoinTask).Impl_CompleteExceptionally_Throwable__V(t, ex) }
func (t *ForkJoinTask_AdaptedRunnable) TryUnfork__Z() bool { return (&t.ForkJoinTask).Impl_TryUnfork__Z(t) }
func (t *ForkJoinTask_AdaptedRunnable) ResultNow__O() any { return (&t.ForkJoinTask).Impl_ResultNow__O(t) }
func (t *ForkJoinTask_AdaptedRunnable) ExceptionNow__Throwable() Throwable_I { return (&t.ForkJoinTask).Impl_ExceptionNow__Throwable(t) }
func (t *ForkJoinTask_AdaptedRunnable) State__Future_State() *Future_State { return (&t.ForkJoinTask).Impl_State__Future_State(t) }
func (t *ForkJoinTask_AdaptedRunnable) Ref() any { if t == nil { return nil }; return t }
func (t *ForkJoinTask_AdaptedRunnable) GetClass__Class() *Class { return ForkJoinTask_AdaptedRunnable_class }
func (t *ForkJoinTask_AdaptedRunnable) ToString__String() *String {
	return Concat(Object_toString(t), Str("[Wrapped task = "), StrOfObj(t.runnable), Str("]")) }
func (t *ForkJoinTask_AdaptedRunnable) Clone__O() any { panic(CloneNotSupported(t)) }

func (t *ForkJoinTask_AdaptedRunnableAction) Fork__ForkJoinTask() ForkJoinTask_I { return (&t.ForkJoinTask).Impl_Fork__ForkJoinTask(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) Join__O() any { return (&t.ForkJoinTask).Impl_Join__O(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) Invoke__O() any { return (&t.ForkJoinTask).Impl_Invoke__O(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) QuietlyJoin__V() { (&t.ForkJoinTask).Impl_QuietlyJoin__V(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) QuietlyInvoke__V() { (&t.ForkJoinTask).Impl_QuietlyInvoke__V(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) Get__O() any { return (&t.ForkJoinTask).Impl_Get__O(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) Get_J_TimeUnit__O(timeout int64, unit *TimeUnit) any { return (&t.ForkJoinTask).Impl_Get_J_TimeUnit__O(t, timeout, unit) }
func (t *ForkJoinTask_AdaptedRunnableAction) Cancel_Z__Z(may bool) bool { return (&t.ForkJoinTask).Impl_Cancel_Z__Z(t, may) }
func (t *ForkJoinTask_AdaptedRunnableAction) IsCancelled__Z() bool { return (&t.ForkJoinTask).Impl_IsCancelled__Z(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) IsDone__Z() bool { return (&t.ForkJoinTask).Impl_IsDone__Z(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) IsCompletedNormally__Z() bool { return (&t.ForkJoinTask).Impl_IsCompletedNormally__Z(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) IsCompletedAbnormally__Z() bool { return (&t.ForkJoinTask).Impl_IsCompletedAbnormally__Z(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) GetException__Throwable() Throwable_I { return (&t.ForkJoinTask).Impl_GetException__Throwable(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) Complete_O__V(v any) { (&t.ForkJoinTask).Impl_Complete_O__V(t, v) }
func (t *ForkJoinTask_AdaptedRunnableAction) CompleteExceptionally_Throwable__V(ex Throwable_I) { (&t.ForkJoinTask).Impl_CompleteExceptionally_Throwable__V(t, ex) }
func (t *ForkJoinTask_AdaptedRunnableAction) TryUnfork__Z() bool { return (&t.ForkJoinTask).Impl_TryUnfork__Z(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) ResultNow__O() any { return (&t.ForkJoinTask).Impl_ResultNow__O(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) ExceptionNow__Throwable() Throwable_I { return (&t.ForkJoinTask).Impl_ExceptionNow__Throwable(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) State__Future_State() *Future_State { return (&t.ForkJoinTask).Impl_State__Future_State(t) }
func (t *ForkJoinTask_AdaptedRunnableAction) Ref() any { if t == nil { return nil }; return t }
func (t *ForkJoinTask_AdaptedRunnableAction) GetClass__Class() *Class { return ForkJoinTask_AdaptedRunnableAction_class }
func (t *ForkJoinTask_AdaptedRunnableAction) ToString__String() *String {
	return Concat(Object_toString(t), Str("[Wrapped task = "), StrOfObj(t.runnable), Str("]")) }
func (t *ForkJoinTask_AdaptedRunnableAction) Clone__O() any { panic(CloneNotSupported(t)) }
// ForkJoinPool is java.util.concurrent.ForkJoinPool: its parallelism, the slots of the
// workers forked tasks may start (parallelism - 1: the thread that forks works too), its
// workers' name prefix and count, whether it was shut down, its running workers (for
// termination: done is closed when the pool is shut down with none running).
type ForkJoinPool /*line :415:1*/ struct{ Object; parallelism int32; slots /*line :417:1*/ chan struct{}; prefix string; workers atomic.Int64; shutdown atomic.Bool; mu sync.Mutex; running int64; done /*line :423:1*/ chan struct{}; terminated bool }


var ForkJoinPool_class =
	Define(&ClassInfo{Name: "java.util.concurrent.ForkJoinPool", Kind: KindClass, Modifiers: AccPublic, Super: Object_class,

		Interfaces: []*Class{ExecutorService_class}, Go: "arbace/jrt.ForkJoinPool",
	},
	)


// ForkJoinPool_ManagedBlocker is java.util.concurrent.ForkJoinPool$ManagedBlocker.
type ForkJoinPool_ManagedBlocker /*line :437:1*/ interface { Object_I
	Is_ForkJoinPool_ManagedBlocker()
	Block__Z() bool
	IsReleasable__Z() bool
}
var ForkJoinPool_ManagedBlocker_class =
	Define(&ClassInfo{Name: "java.util.concurrent.ForkJoinPool$ManagedBlocker", Kind: KindInterface,
				Modifiers:                                                AccPublic | AccStatic | AccInterface | AccAbstract, Declaring: ForkJoinPool_class, Simple: "ManagedBlocker", Go: "arbace/jrt.ForkJoinPool_ManagedBlocker",
	},
	)

func ForkJoinPool_ManagedBlocker_InstanceOf(x any) bool {
	_, ok := x.(ForkJoinPool_ManagedBlocker); return dynNominal(x, ForkJoinPool_ManagedBlocker_class, ok)
}
func ForkJoinPool_ManagedBlocker_Cast(x any) ForkJoinPool_ManagedBlocker {
	if x == nil { return nil }
	v, ok := x.(ForkJoinPool_ManagedBlocker)
	if !dynNominal(x, ForkJoinPool_ManagedBlocker_class, ok) { panic(ClassCast(x, ForkJoinPool_ManagedBlocker_class)) }; return v }
// ForkJoinPool_ManagedBlock_ForkJoinPool_ManagedBlocker__V is ForkJoinPool.managedBlock: the
// blocker's block until it is releasable, as the JDK does in a thread that is not a pool's
// worker. jrt's workers need no compensation: a forked task finds no free worker and runs in the
// forking thread, a task given from outside always gets a worker of its own (A2G-SPEC §8.4).
//line :457:1
func ForkJoinPool_ManagedBlock_ForkJoinPool_ManagedBlocker__V(b ForkJoinPool_ManagedBlocker) {





	if b == nil {
		panic(NPE()) }
	for !b.IsReleasable__Z() && !b.Block__Z() { } }
// poolIds numbers the pools (ForkJoinPool-N-worker-M).
var poolIds atomic.Int64

func newForkJoinPool(parallelism int32, prefix string) *ForkJoinPool {
	if parallelism <= 0 || parallelism > 32767 {
		panic(IllegalArgumentException_New()) }
	p := &ForkJoinPool{parallelism: parallelism, prefix: prefix}
	if parallelism > 1 {
		p.slots = make(chan struct{}, parallelism-1)
	}; return p }
// ForkJoinPool_New is new ForkJoinPool(): parallelism the processors.
func ForkJoinPool_New(
) *ForkJoinPool {
	return ForkJoinPool_New_I(int32(CurrentHost().NumCPU())) }
// ForkJoinPool_New_I is new ForkJoinPool(parallelism).
func ForkJoinPool_New_I(parallelism int32,
) *ForkJoinPool {
	return newForkJoinPool(parallelism, "ForkJoinPool-"+strconv.FormatInt(poolIds.Add(1), 10)+"-worker-")
}
var commonOnce sync.Once
var commonPool *ForkJoinPool
// ForkJoinPool_CommonPool__ForkJoinPool is ForkJoinPool.commonPool().
func ForkJoinPool_CommonPool__ForkJoinPool(

) *ForkJoinPool {
	commonOnce.Do(func() { commonPool = newForkJoinPool(ForkJoinPool_GetCommonPoolParallelism__I(), "ForkJoinPool.commonPool-worker-") }); return commonPool }
// ForkJoinPool_AsyncCommonPool__ForkJoinPool is the package-private asyncCommonPool
// (CompletableFuture's default executor): the common pool, whose parallelism is at least 1 and
// whose tasks given from outside each get a worker (§8.4), so asynchronous tasks never run in
// the caller.
//line :495:1
func ForkJoinPool_AsyncCommonPool__ForkJoinPool(




) *ForkJoinPool {
	return ForkJoinPool_CommonPool__ForkJoinPool() }
// ForkJoinPool_GetCommonPoolParallelism__I is getCommonPoolParallelism: the processors less
// one, at least 1, as the JVM's common pool has it.
//line :503:1
func ForkJoinPool_GetCommonPoolParallelism__I() int32 {



	n := int32(CurrentHost().NumCPU())
	if n < 2 {
		return 1 }
	return n - 1 }
// currentPool is the pool whose worker the current thread is, or nil.
func currentPool(
) *ForkJoinPool {
	return CurrentThread().Self_Thread().fjPool }
// startWorker runs the task in a new worker thread of the pool (a daemon), then calls done.
func (p /*line :518:1*/*ForkJoinPool) startWorker(task ForkJoinTask_I, done func()) {
	p.mu.Lock()
	p.running++
	p.mu.Unlock()
	name := Str(p.prefix + strconv.FormatInt(p.workers.Add(1), 10))
	t := Thread_New_Runnable_String(
		RunnableOf(func() {
			defer p.workerDone()
			defer done()
			task.Self_ForkJoinTask().runForked(task)
		}), name)
	t.fjPool = p
	t.daemon.Store(true)
	t.Start__V() }
// spawn is a forked task's start: a new worker when a slot is free, else the forking thread
// runs it at once.
//line :533:1
func (p /*line :536:1*/*ForkJoinPool) spawn(task ForkJoinTask_I) {
	if p.slots == nil {
		task.Self_ForkJoinTask().runForked(task)
		return }
	select {
	case p.slots <- struct{}{}:
		p.startWorker(task, func() { <-p.slots })
	default:


		task.Self_ForkJoinTask().runForked(task)
	} }
func (p *ForkJoinPool) checkOpen(task ForkJoinTask_I) {
	nnIface(task)
	if p.shutdown.Load() {
		panic(RejectedExecutionException_New()) } }
// Invoke_ForkJoinTask__O is invoke: in a worker the task runs at once (invoke), else in a
// worker of the pool, the caller waiting for its result.
//line :553:1
func (p /*line :556:1*/*ForkJoinPool) Invoke_ForkJoinTask__O(task ForkJoinTask_I) any {
	p.checkOpen(task)
	if currentPool() != nil {
		return task.Invoke__O() }
	p.startWorker(task, func() {})
	t := task.Self_ForkJoinTask()
	t.await()
	if t.exc != nil {
		panic(t.exc) }
	return task.GetRawResult__O() }
// Execute_ForkJoinTask__V is execute: the task in a worker of the pool.
func (p /*line :568:1*/*ForkJoinPool) Execute_ForkJoinTask__V(task ForkJoinTask_I) {
	p.checkOpen(task)
	p.startWorker(task, func() {}) }
// Submit_ForkJoinTask__ForkJoinTask is submit: execute, the task returned.
func (p /*line :573:1*/*ForkJoinPool) Submit_ForkJoinTask__ForkJoinTask(task ForkJoinTask_I) ForkJoinTask_I {
	p.Execute_ForkJoinTask__V(task)
	return task
}
func (p *ForkJoinPool) GetParallelism__I() int32 { return p.parallelism }
// Shutdown__V is shutdown: no new tasks (the common pool is never shut down).
//line :578:1
func (p /*line :579:1*/*ForkJoinPool) Shutdown__V() {
	if p != commonPool {
		p.shutdown.Store(true)
		p.mu.Lock()
		p.checkTerminated()
		p.mu.Unlock() } }
func (p *ForkJoinPool) IsShutdown__Z() bool { return p.shutdown.Load() }


// workerDone is a worker's end: the pool may terminate.
func (p *ForkJoinPool) workerDone() {
	p.mu.Lock()
	p.running--
	p.checkTerminated()
	p.mu.Unlock() }
// checkTerminated ends the pool when it is shut down with no worker running (mu held).
func (p /*line :597:1*/*ForkJoinPool) checkTerminated() {
	if p.shutdown.Load() && p.running == 0 && !p.terminated {
		p.terminated = true
		if p.done != nil {
			close(p.done) } } }
// IsTerminated__Z is isTerminated: shut down, no worker running.
func (p /*line :604:1*/*ForkJoinPool) IsTerminated__Z() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.terminated }
// IsQuiescent__Z is isQuiescent: no worker running.
func (p /*line :610:1*/*ForkJoinPool) IsQuiescent__Z() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.running == 0 }
// AwaitTermination_J_TimeUnit__Z is awaitTermination: true once the pool terminates, false
// when the time passes first; the common pool, never shut down, waits for quiescence as the
// JDK's does (awaitQuiescence) and answers false.
//line :615:1
func (p /*line :619:1*/*ForkJoinPool) AwaitTermination_J_TimeUnit__Z(timeout int64, unit *TimeUnit) bool {
	nanos := NN(unit).ToNanos_J__J(timeout)
	deadline := time.Now()
	deadline = deadline.Add(time.Duration(nanos))
	if p == commonPool {
		for !p.IsQuiescent__Z() {
			if time.Now().After(deadline) {
				return false }
			Thread_Sleep_J__V(1) }
		return false }
	p.mu.Lock()
	if p.terminated {
		p.mu.Unlock()
		return true }
	if p.done == nil {
		p.done = make(chan struct{}) }
	done := p.done
	p.mu.Unlock()
	if nanos <= 0 {
		return false }
	tm := time.NewTimer(time.Duration(nanos))
	me := CurrentThread()
	defer tm.Stop()
	select {
	case <-done: return true
	case <-me.intr: panic(InterruptedException_New())
	case <-tm.C: return false} }
// Close__V is close(): shutdown, then waiting for termination (not the common pool).
func (p /*line :648:1*/*ForkJoinPool) Close__V() {
	if p == commonPool {
		return }
	p.Shutdown__V()
	for !p.AwaitTermination_J_TimeUnit__Z(1, TimeUnit_DAYS) { } }
// Execute_Runnable__V is execute(Runnable): a ForkJoinTask as itself, another Runnable adapted
// (its exception goes to the worker's uncaught-exception handler, as the JDK's
// RunnableExecuteAction does).
//line :654:1
func (p /*line :658:1*/*ForkJoinPool) Execute_Runnable__V(r Runnable) {
	if r == nil {
		panic(NPE()) }
	{ t, ok := r.(ForkJoinTask_I)
		if ok {
			p.Execute_ForkJoinTask__V(t)
			return } }
	p.Execute_ForkJoinTask__V(ForkJoinTask_Adapt_Runnable__ForkJoinTask(
		RunnableOf(func() { exc := runCatching(func() { r.Run__V() }); if
			exc != nil {
				me := CurrentThread()
				me.dispatchUncaught(exc) } }))) }
// Submit_Callable__Future is submit(Callable): the adapted task.
func (p /*line :672:1*/*ForkJoinPool) Submit_Callable__Future(c Callable) Future {
	if c == nil { panic(NPE()) }
	t := ForkJoinTask_Adapt_Callable__ForkJoinTask(c)
	p.Execute_ForkJoinTask__V(t)
	return t }
func (p *ForkJoinPool) Submit_Runnable__Future(r Runnable) Future {
	if r == nil { panic(NPE()) }
	{ ft, ok := r.(ForkJoinTask_I)
		if ok {
			p.Execute_ForkJoinTask__V(ft)
			return ft } }
	t := ForkJoinTask_Adapt_Runnable__ForkJoinTask(r)
	p.Execute_ForkJoinTask__V(t)
	return t }
func (p *ForkJoinPool) Submit_Runnable_O__Future(r Runnable, result any) Future {
	if r == nil { panic(NPE()) }
	t := ForkJoinTask_Adapt_Runnable_O__ForkJoinTask(r, result)
	p.Execute_ForkJoinTask__V(t)
	return t }
func (p *ForkJoinPool) Is_Executor() {}
func (p *ForkJoinPool) Is_ExecutorService() {}
// Is_AutoCloseable: ExecutorService is an AutoCloseable (JDK 19).
//line :693:1
func (p *ForkJoinPool) Is_AutoCloseable() {}

func ForkJoinPool_InstanceOf(x any) bool { _, ok := x.(*ForkJoinPool); return ok }

func init() {
	ForkJoinTask_class.Info().IsInstance = ForkJoinTask_InstanceOf
	ForkJoinPool_class.Info().IsInstance = ForkJoinPool_InstanceOf
	ForkJoinPool_ManagedBlocker_class.Info().IsInstance = ForkJoinPool_ManagedBlocker_InstanceOf
}
func (t *ForkJoinPool) Ref() any { if t == nil { return nil }; return t }
func (t *ForkJoinPool) GetClass__Class() *Class { return ForkJoinPool_class }
func (t *ForkJoinPool) ToString__String() *String { return Object_toString(t) }
func (t *ForkJoinPool) Clone__O() any { panic(CloneNotSupported(t)) }
