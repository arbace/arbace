//line java_util_OptionalInt.ae:1
package jrt














func OptionalInt_New() *OptionalInt { OptionalInt_Init(); t := &OptionalInt{}; t.Ctor(); return t }
//line :16:1
func (t *OptionalInt) Ctor() {
	t.F_isPresent = false
	t.F_value = 0
}
func OptionalInt_Empty__OptionalInt() *OptionalInt { OptionalInt_Init(); return OptionalInt_EMPTY }

func OptionalInt_New_I(p0 int32) *OptionalInt { OptionalInt_Init(); t := &OptionalInt{}; t.Ctor_I(p0); return t }
//line :22:1
func (t *OptionalInt) Ctor_I(value int32) {
	t.F_isPresent = true
	t.F_value = value
}
func OptionalInt_Of_I__OptionalInt(value int32) *OptionalInt {
	return OptionalInt_New_I(value)
}
func (t *OptionalInt) GetAsInt__I() int32 {
	if t.F_isPresent { } else { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :29:1
	return t.F_value
}


func (t *OptionalInt) IsPresent__Z() bool { return t.F_isPresent }

func (t *OptionalInt) IsEmpty__Z() bool { return !t.F_isPresent }

func (t *OptionalInt) IfPresent_IntConsumer__V(action IntConsumer) {
	if t.F_isPresent { action.Accept_I__V(t.F_value)
	} }
func (t *OptionalInt) IfPresentOrElse_IntConsumer_Runnable__V(action IntConsumer, emptyAction Runnable) {
	if t.F_isPresent { action.Accept_I__V(t.F_value) } else { emptyAction.Run__V()
	} }
func (t *OptionalInt) Stream__IntStream() IntStream {
	if t.F_isPresent { return IntStream_Of_I__IntStream(t.F_value) } else { return IntStream_Empty__IntStream()
	} }
func (t *OptionalInt) OrElse_I__I(other int32) int32 {
	if t.F_isPresent { return t.F_value } else { return other
	} }
func (t *OptionalInt) OrElseGet_IntSupplier__I(supplier IntSupplier) int32 {
	if t.F_isPresent { return t.F_value } else { return supplier.GetAsInt__I()
	} }
func (t *OptionalInt) OrElseThrow__I() int32 {
	if t.F_isPresent { } else { panic(Thrown(NoSuchElementException_New_String(Lit_2793))) }
//line :52:1
	return t.F_value
}


func (t *OptionalInt) OrElseThrow_Supplier__I(exceptionSupplier Supplier) int32 {

	if t.F_isPresent { return t.F_value } else { panic(Thrown(Throwable_Cast(exceptionSupplier.Get__O())))
	} }
func (t *OptionalInt) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if OptionalInt_InstanceOf(tmp1) { var other *OptionalInt = OptionalInt_Cast(tmp1); var tmp2 bool; var tmp3 bool
			tmp3 = t.F_isPresent; if tmp3 { tmp3 = other.F_isPresent }; tmp2 = tmp3; if tmp2 {
				var tmp4 int32 = t.F_value; return tmp4 == other.F_value } else {
					var tmp5 bool = t.F_isPresent; return tmp5 == other.F_isPresent } } else {
//line :63:1
						return false
					}
	}
}


func (t *OptionalInt) HashCode__I() int32 {
	if t.F_isPresent { return Integer_HashCode_I__I(t.F_value) } else { return 0
	} }
func (t *OptionalInt) ToString__String() *String {
	if t.F_isPresent { return Concat(Lit_2798, StrOfInt(t.F_value), Lit_1189) } else { return Lit_2799
	}
}

type OptionalInt struct{ Object; F_isPresent bool; F_value int32 }

var OptionalInt_EMPTY *OptionalInt

var OptionalInt_init ClassInit

func OptionalInt_Init() { if !OptionalInt_init.Done() { OptionalInt_init.Run(OptionalInt_clinit) } }

func OptionalInt_clinit() { OptionalInt_EMPTY = OptionalInt_New() }

func (t *OptionalInt) Ref() any { if t == nil { return nil }; return t }

func (t *OptionalInt) GetClass__Class() *Class { return OptionalInt_class }

func (t *OptionalInt) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OptionalInt) CloneShallow() any { panic(CloneNotSupported(t)) }

func OptionalInt_InstanceOf(x any) bool { _, ok := x.(*OptionalInt); return ok }

func OptionalInt_Cast(x any) *OptionalInt { if x == nil { return nil }; v, ok := x.(*OptionalInt); if !ok { panic(ClassCast(x, OptionalInt_class)) }; return v }
