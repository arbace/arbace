//line java_nio_file_DirectoryNotEmptyException.ae:1
package jrt








func DirectoryNotEmptyException_New_String(p0 *String) *DirectoryNotEmptyException { t := &DirectoryNotEmptyException{}; t.Ctor_String(p0); return t }
//line :10:1
func (t *DirectoryNotEmptyException) Ctor_String(dir *String) { t.FileSystemException.Ctor_String(t, dir) }





type DirectoryNotEmptyException struct{ FileSystemException }

const DirectoryNotEmptyException_serialVersionUID int64 = 3056667871802779003

func (t *DirectoryNotEmptyException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *DirectoryNotEmptyException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *DirectoryNotEmptyException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *DirectoryNotEmptyException) GetFile__String() *String { return t.Impl_GetFile__String(t) }

func (t *DirectoryNotEmptyException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *DirectoryNotEmptyException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *DirectoryNotEmptyException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *DirectoryNotEmptyException) GetReason__String() *String { return t.Impl_GetReason__String(t) }

func (t *DirectoryNotEmptyException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *DirectoryNotEmptyException) GetOtherFile__String() *String { return t.Impl_GetOtherFile__String(t) }

func (t *DirectoryNotEmptyException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *DirectoryNotEmptyException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *DirectoryNotEmptyException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *DirectoryNotEmptyException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *DirectoryNotEmptyException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *DirectoryNotEmptyException) Ref() any { if t == nil { return nil }; return t }

func (t *DirectoryNotEmptyException) GetClass__Class() *Class { return DirectoryNotEmptyException_class }

func (t *DirectoryNotEmptyException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DirectoryNotEmptyException) CloneShallow() any { panic(CloneNotSupported(t)) }

func DirectoryNotEmptyException_InstanceOf(x any) bool { _, ok := x.(*DirectoryNotEmptyException); return ok }

func DirectoryNotEmptyException_Cast(x any) *DirectoryNotEmptyException { if x == nil { return nil }; v, ok := x.(*DirectoryNotEmptyException); if !ok { panic(ClassCast(x, DirectoryNotEmptyException_class)) }; return v }
