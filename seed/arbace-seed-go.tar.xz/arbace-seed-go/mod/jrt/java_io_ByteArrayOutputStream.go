//line java_io_ByteArrayOutputStream.ae:1
package jrt














func ByteArrayOutputStream_New() *ByteArrayOutputStream { t := &ByteArrayOutputStream{}; t.Ctor(); return t }
//line :16:1
func (t *ByteArrayOutputStream) Ctor() { t.Ctor_I(32) }

func ByteArrayOutputStream_New_I(p0 int32) *ByteArrayOutputStream { t := &ByteArrayOutputStream{}; t.Ctor_I(p0); return t }
//line :18:1
func (t *ByteArrayOutputStream) Ctor_I(size int32) { t.OutputStream.Ctor(t)
	if size < 0 { panic(Thrown(IllegalArgumentException_New_String(Concat(Lit_55, StrOfInt(size))))) }
	t.F_buf = NewByteArray(size)
}
func (t *ByteArrayOutputStream) EnsureCapacity_I__V(minCapacity int32) {
	var oldCapacity int32 = int32(len(t.F_buf.A)); var minGrowth int32 = minCapacity - oldCapacity

	if minGrowth > 0 {
		var tmp1 *ByteArray = t.F_buf; t.F_buf = Arrays_CopyOf_B1_I__B1(tmp1, ArraysSupport_NewLength_I_I_I__I(oldCapacity, minGrowth, oldCapacity))
	} }
func (t *ByteArrayOutputStream) Write_I__V(b int32) { MonitorEnter(t); defer MonitorExit(t)
	t.EnsureCapacity_I__V(t.F_count + 1)
	t.F_buf.A[t.F_count] = int8(b)
	t.F_count = t.F_count + 1
}
func (t *ByteArrayOutputStream) Write_B1_I_I__V(b *ByteArray, off, len_ int32) { MonitorEnter(t); defer MonitorExit(t)
	Objects_CheckFromIndexSize_I_I_I__I(off, len_, int32(len(b.A)))
	t.EnsureCapacity_I__V(t.F_count + len_)
	System_Arraycopy_O_I_O_I_I__V(b.Ref(), off, t.F_buf.Ref(), t.F_count, len_)
	t.F_count = t.F_count + len_
}
func (t *ByteArrayOutputStream) WriteBytes_B1__V(b *ByteArray) {
	t.Write_B1_I_I__V(b, 0, int32(len(b.A)))
}
func (t *ByteArrayOutputStream) WriteTo_OutputStream__V(out OutputStream_I) { MonitorEnter(t); defer MonitorExit(t)
	out.Write_B1_I_I__V(t.F_buf, 0, t.F_count)
}
func (t *ByteArrayOutputStream) Reset__V() { MonitorEnter(t); defer MonitorExit(t); t.F_count = 0 }

func (t *ByteArrayOutputStream) ToByteArray__B1() *ByteArray { MonitorEnter(t); defer MonitorExit(t)
	return Arrays_CopyOf_B1_I__B1(t.F_buf, t.F_count)
}
func (t *ByteArrayOutputStream) Size__I() int32 { MonitorEnter(t); defer MonitorExit(t); return t.F_count }

func (t *ByteArrayOutputStream) ToString__String() *String { MonitorEnter(t); defer MonitorExit(t)
	return String_New_B1_I_I(t.F_buf, 0, t.F_count)
}
func (t *ByteArrayOutputStream) ToString_String__String(charsetName *String) *String { MonitorEnter(t); defer MonitorExit(t)

	return String_New_B1_I_I_String(t.F_buf, 0, t.F_count, charsetName)
}
func (t *ByteArrayOutputStream) ToString_Charset__String(charset Charset_I) *String { MonitorEnter(t); defer MonitorExit(t)
	return String_New_B1_I_I_Charset(t.F_buf, 0, t.F_count, charset)
}
func (t *ByteArrayOutputStream) ToString_I__String(hibyte int32) *String { MonitorEnter(t); defer MonitorExit(t)
	return String_New_B1_I_I_I(t.F_buf, hibyte, 0, t.F_count)
}
func (t *ByteArrayOutputStream) Close__V() {}



type ByteArrayOutputStream struct{ OutputStream; F_buf *ByteArray; F_count int32 }

func (t *ByteArrayOutputStream) Flush__V() { t.Impl_Flush__V(t) }

func (t *ByteArrayOutputStream) Write_B1__V(p0 *ByteArray) { t.Impl_Write_B1__V(t, p0) }

func (t *ByteArrayOutputStream) Ref() any { if t == nil { return nil }; return t }

func (t *ByteArrayOutputStream) GetClass__Class() *Class { return ByteArrayOutputStream_class }

func (t *ByteArrayOutputStream) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ByteArrayOutputStream) CloneShallow() any { panic(CloneNotSupported(t)) }

func ByteArrayOutputStream_InstanceOf(x any) bool { _, ok := x.(*ByteArrayOutputStream); return ok }

func ByteArrayOutputStream_Cast(x any) *ByteArrayOutputStream { if x == nil { return nil }; v, ok := x.(*ByteArrayOutputStream); if !ok { panic(ClassCast(x, ByteArrayOutputStream_class)) }; return v }
