//line java_security_InvalidAlgorithmParameterException.ae:1
package jrt








func InvalidAlgorithmParameterException_New() *InvalidAlgorithmParameterException { t := &InvalidAlgorithmParameterException{}; t.Ctor(); return t }
//line :10:1
func (t *InvalidAlgorithmParameterException) Ctor() { t.GeneralSecurityException.Ctor(t) }

func InvalidAlgorithmParameterException_New_String(p0 *String) *InvalidAlgorithmParameterException { t := &InvalidAlgorithmParameterException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *InvalidAlgorithmParameterException) Ctor_String(msg *String) { t.GeneralSecurityException.Ctor_String(t, msg) }

func InvalidAlgorithmParameterException_New_String_Throwable(p0 *String, p1 Throwable_I) *InvalidAlgorithmParameterException { t := &InvalidAlgorithmParameterException{}; t.Ctor_String_Throwable(p0, p1); return t }
//line :14:1
func (t *InvalidAlgorithmParameterException) Ctor_String_Throwable(message *String, cause Throwable_I) { t.GeneralSecurityException.Ctor_String_Throwable(t, message, cause) }


func InvalidAlgorithmParameterException_New_Throwable(p0 Throwable_I) *InvalidAlgorithmParameterException { t := &InvalidAlgorithmParameterException{}; t.Ctor_Throwable(p0); return t }
//line :17:1
func (t *InvalidAlgorithmParameterException) Ctor_Throwable(cause Throwable_I) { t.GeneralSecurityException.Ctor_Throwable(t, cause) }










type InvalidAlgorithmParameterException struct{ GeneralSecurityException }

const InvalidAlgorithmParameterException_serialVersionUID int64 = 2864672297499471472

func (t *InvalidAlgorithmParameterException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *InvalidAlgorithmParameterException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *InvalidAlgorithmParameterException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *InvalidAlgorithmParameterException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *InvalidAlgorithmParameterException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *InvalidAlgorithmParameterException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *InvalidAlgorithmParameterException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *InvalidAlgorithmParameterException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *InvalidAlgorithmParameterException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *InvalidAlgorithmParameterException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *InvalidAlgorithmParameterException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *InvalidAlgorithmParameterException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *InvalidAlgorithmParameterException) Ref() any { if t == nil { return nil }; return t }

func (t *InvalidAlgorithmParameterException) GetClass__Class() *Class { return InvalidAlgorithmParameterException_class }

func (t *InvalidAlgorithmParameterException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *InvalidAlgorithmParameterException) CloneShallow() any { panic(CloneNotSupported(t)) }

func InvalidAlgorithmParameterException_InstanceOf(x any) bool { _, ok := x.(*InvalidAlgorithmParameterException); return ok }

func InvalidAlgorithmParameterException_Cast(x any) *InvalidAlgorithmParameterException { if x == nil { return nil }; v, ok := x.(*InvalidAlgorithmParameterException); if !ok { panic(ClassCast(x, InvalidAlgorithmParameterException_class)) }; return v }
