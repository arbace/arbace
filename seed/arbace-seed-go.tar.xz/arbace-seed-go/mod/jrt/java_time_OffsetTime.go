//line java_time_OffsetTime.ae:1
package jrt







































func OffsetTime_Now__OffsetTime() *OffsetTime { OffsetTime_Init()
	return OffsetTime_Now_Clock__OffsetTime(Clock_SystemDefaultZone__Clock())
}
func OffsetTime_Now_ZoneId__OffsetTime(zone ZoneId_I) *OffsetTime { OffsetTime_Init()
	return OffsetTime_Now_Clock__OffsetTime(Clock_System_ZoneId__Clock(zone))
}
func OffsetTime_Now_Clock__OffsetTime(clock Clock_I) *OffsetTime { OffsetTime_Init()
	Objects_RequireNonNull_O_String__O(clock, Lit_2031)
	var now *Instant = clock.Instant__Instant()
	return OffsetTime_OfInstant_Instant_ZoneId__OffsetTime(now, Up_ZoneOffset_ZoneId(NN(clock.GetZone__ZoneId().GetRules__ZoneRules()).GetOffset_Instant__ZoneOffset(now)))
}
func OffsetTime_Of_LocalTime_ZoneOffset__OffsetTime(time *LocalTime, offset *ZoneOffset) *OffsetTime { OffsetTime_Init()
	return OffsetTime_New_LocalTime_ZoneOffset(time, offset)
}
func OffsetTime_Of_I_I_I_I_ZoneOffset__OffsetTime(hour, minute, second, nanoOfSecond int32, offset *ZoneOffset) *OffsetTime { OffsetTime_Init()

	return OffsetTime_New_LocalTime_ZoneOffset(LocalTime_Of_I_I_I_I__LocalTime(hour, minute, second, nanoOfSecond), offset)
}
func OffsetTime_OfInstant_Instant_ZoneId__OffsetTime(instant *Instant, zone ZoneId_I) *OffsetTime { OffsetTime_Init()
	Objects_RequireNonNull_O_String__O(instant.Ref(), Lit_2039)
	Objects_RequireNonNull_O_String__O(zone, Lit_1984)
	var rules *ZoneRules = zone.GetRules__ZoneRules(); var offset *ZoneOffset = NN(rules).GetOffset_Instant__ZoneOffset(instant); var localSecond int64 = NN(instant).GetEpochSecond__J() + int64(NN(offset).GetTotalSeconds__I()); var secsOfDay int32 = Math_FloorMod_J_I__I(localSecond, 86400); var time *LocalTime = LocalTime_OfNanoOfDay_J__LocalTime(int64(secsOfDay)*1000000000 + int64(NN(instant).GetNano__I()))






	return OffsetTime_New_LocalTime_ZoneOffset(time, offset)
}
func OffsetTime_From_TemporalAccessor__OffsetTime(temporal TemporalAccessor) *OffsetTime { OffsetTime_Init()
	if OffsetTime_InstanceOf(temporal) {
		return OffsetTime_Cast(temporal) } else {
			var tmp1 *OffsetTime; tmp2 := func() (exc Throwable_I) { defer Catch(&exc)
				{ var time *LocalTime = LocalTime_From_TemporalAccessor__LocalTime(temporal); var offset *ZoneOffset = ZoneOffset_From_TemporalAccessor__ZoneOffset(temporal)

					tmp1 = OffsetTime_New_LocalTime_ZoneOffset(time, offset) }; return nil }()
//line :74:1
			if tmp2 != nil { if DateTimeException_InstanceOf(tmp2) { var ex DateTimeException_I = DateTimeException_Cast(tmp2)




				panic(Thrown(DateTimeException_New_String_Throwable(Concat(Lit_2079, StrOfObj(temporal), Lit_2008, NN(temporal.GetClass__Class()).GetName__String()), ex))) } else {
//line :74:1
					panic(tmp2) } }; return tmp1
		}
}









func OffsetTime_Parse_CharSequence__OffsetTime(text CharSequence) *OffsetTime { OffsetTime_Init()
	var tmp1 *DateTimeFormatter; DateTimeFormatter_Init(); tmp1 = DateTimeFormatter_ISO_OFFSET_TIME; return OffsetTime_Parse_CharSequence_DateTimeFormatter__OffsetTime(text, tmp1)
}
func OffsetTime_Parse_CharSequence_DateTimeFormatter__OffsetTime(text CharSequence, formatter *DateTimeFormatter) *OffsetTime { OffsetTime_Init()
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return OffsetTime_Cast(NN(formatter).Parse_CharSequence_TemporalQuery__O(text, &TemporalQuery_Fn{Fn: func(p0 TemporalAccessor) any { return OffsetTime_From_TemporalAccessor__OffsetTime(p0).Ref() }}))
}



func OffsetTime_New_LocalTime_ZoneOffset(p0 *LocalTime, p1 *ZoneOffset) *OffsetTime { OffsetTime_Init(); t := &OffsetTime{}; t.Ctor_LocalTime_ZoneOffset(p0, p1); return t }
//line :96:1
func (t *OffsetTime) Ctor_LocalTime_ZoneOffset(time *LocalTime, offset *ZoneOffset) {
	t.F_time = LocalTime_Cast(Objects_RequireNonNull_O_String__O(time.Ref(), Lit_2051))
	t.F_offset = ZoneOffset_Cast(Objects_RequireNonNull_O_String__O(offset.Ref(), Lit_2052))
}
func (t *OffsetTime) With_LocalTime_ZoneOffset__OffsetTime(time *LocalTime, offset *ZoneOffset) *OffsetTime {
	var tmp1 bool; var tmp2 bool; tmp2 = t.F_time == time; if tmp2 { tmp2 = NN(t.F_offset).Equals_O__Z(offset.Ref()) }; tmp1 = tmp2; if tmp1 { return t } else {

		return OffsetTime_New_LocalTime_ZoneOffset(time, offset)
	} }
func (t *OffsetTime) IsSupported_TemporalField__Z(field TemporalField) bool {
	if ChronoField_InstanceOf(field) {
		var tmp1 bool; tmp1 = field.IsTimeBased__Z(); if !tmp1 { var tmp2 *ChronoField; ChronoField_Init(); tmp2 = ChronoField_OFFSET_SECONDS; tmp1 = any(field) == any(tmp2.Ref()) }; return tmp1 } else {
			var tmp3 bool; tmp3 = !(field == nil); if tmp3 { tmp3 = field.IsSupportedBy_TemporalAccessor__Z(t) }; return tmp3
		} }
func (t *OffsetTime) IsSupported_TemporalUnit__Z(unit TemporalUnit) bool {
	if ChronoUnit_InstanceOf(unit) {
		return unit.IsTimeBased__Z() } else {
			var tmp1 bool; tmp1 = !(unit == nil); if tmp1 { tmp1 = unit.IsSupportedBy_Temporal__Z(t) }; return tmp1
		} }
func (t *OffsetTime) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; if any(field) == any(tmp1.Ref()) { return field.Range__ValueRange() } else { return NN(t.F_time).Range_TemporalField__ValueRange(field) } } else {
			return field.RangeRefinedBy_TemporalAccessor__ValueRange(t)
		} }
func (t *OffsetTime) Get_TemporalField__I(field TemporalField) int32 {
	return TemporalAccessor_Get_TemporalField__I(t, field)
}
func (t *OffsetTime) GetLong_TemporalField__J(field TemporalField) int64 {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; if any(field) == any(tmp1.Ref()) { return int64(NN(t.F_offset).GetTotalSeconds__I()) } else {

			return NN(t.F_time).GetLong_TemporalField__J(field) } } else {
				return field.GetFrom_TemporalAccessor__J(t)
			} }
func (t *OffsetTime) GetOffset__ZoneOffset() *ZoneOffset { return t.F_offset }

func (t *OffsetTime) WithOffsetSameLocal_ZoneOffset__OffsetTime(offset *ZoneOffset) *OffsetTime {
	var tmp1 bool; var tmp2 bool; tmp2 = !(offset == nil); if tmp2 { tmp2 = NN(offset).Equals_O__Z(t.F_offset.Ref()) }; tmp1 = tmp2; if tmp1 { return t } else { return OffsetTime_New_LocalTime_ZoneOffset(t.F_time, offset)
	} }
func (t *OffsetTime) WithOffsetSameInstant_ZoneOffset__OffsetTime(offset *ZoneOffset) *OffsetTime {
	if NN(offset).Equals_O__Z(t.F_offset.Ref()) { return t } else {

		var difference int32 = NN(offset).GetTotalSeconds__I() - NN(t.F_offset).GetTotalSeconds__I(); var adjusted *LocalTime = NN(t.F_time).PlusSeconds_J__LocalTime(int64(difference))



		return OffsetTime_New_LocalTime_ZoneOffset(adjusted, offset)
	} }
func (t *OffsetTime) ToLocalTime__LocalTime() *LocalTime { return t.F_time }

func (t *OffsetTime) GetHour__I() int32 { return NN(t.F_time).GetHour__I() }

func (t *OffsetTime) GetMinute__I() int32 { return NN(t.F_time).GetMinute__I() }

func (t *OffsetTime) GetSecond__I() int32 { return NN(t.F_time).GetSecond__I() }

func (t *OffsetTime) GetNano__I() int32 { return NN(t.F_time).GetNano__I() }

func (t *OffsetTime) With_TemporalAdjuster__OffsetTime(adjuster TemporalAdjuster) *OffsetTime {
	if LocalTime_InstanceOf(adjuster) {
		return t.With_LocalTime_ZoneOffset__OffsetTime(LocalTime_Cast(adjuster), t.F_offset) } else {
//line :155:1
			if ZoneOffset_InstanceOf(adjuster) {

				var tmp1 *LocalTime = t.F_time; return t.With_LocalTime_ZoneOffset__OffsetTime(tmp1, ZoneOffset_Cast(adjuster)) } else {
//line :155:1
					if OffsetTime_InstanceOf(adjuster) {


						return OffsetTime_Cast(adjuster) } else {
							return OffsetTime_Cast(adjuster.AdjustInto_Temporal__Temporal(t))
						} } } }
func (t *OffsetTime) With_TemporalField_J__OffsetTime(field TemporalField, newValue int64) *OffsetTime {
	if ChronoField_InstanceOf(field) {
		var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_OFFSET_SECONDS; if any(field) == any(tmp1.Ref()) {
			var f *ChronoField = ChronoField_Cast(field); var tmp2 *LocalTime = t.F_time
			return t.With_LocalTime_ZoneOffset__OffsetTime(tmp2, ZoneOffset_OfTotalSeconds_I__ZoneOffset(NN(f).CheckValidIntValue_J__I(newValue))) } else {
				return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).With_TemporalField_J__LocalTime(field, newValue), t.F_offset) } } else {
					return OffsetTime_Cast(field.AdjustInto_Temporal_J__Temporal(t, newValue))
				} }
func (t *OffsetTime) WithHour_I__OffsetTime(hour int32) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).WithHour_I__LocalTime(hour), t.F_offset)
}
func (t *OffsetTime) WithMinute_I__OffsetTime(minute int32) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).WithMinute_I__LocalTime(minute), t.F_offset)
}
func (t *OffsetTime) WithSecond_I__OffsetTime(second int32) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).WithSecond_I__LocalTime(second), t.F_offset)
}
func (t *OffsetTime) WithNano_I__OffsetTime(nanoOfSecond int32) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).WithNano_I__LocalTime(nanoOfSecond), t.F_offset)
}
func (t *OffsetTime) TruncatedTo_TemporalUnit__OffsetTime(unit TemporalUnit) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).TruncatedTo_TemporalUnit__LocalTime(unit), t.F_offset)
}
func (t *OffsetTime) Plus_TemporalAmount__OffsetTime(amountToAdd TemporalAmount) *OffsetTime {
	return OffsetTime_Cast(amountToAdd.AddTo_Temporal__Temporal(t))
}
func (t *OffsetTime) Plus_J_TemporalUnit__OffsetTime(amountToAdd int64, unit TemporalUnit) *OffsetTime {
	if ChronoUnit_InstanceOf(unit) {
		return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).Plus_J_TemporalUnit__LocalTime(amountToAdd, unit), t.F_offset) } else {
			return OffsetTime_Cast(unit.AddTo_Temporal_J__Temporal(t, amountToAdd))
		} }
func (t *OffsetTime) PlusHours_J__OffsetTime(hours int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).PlusHours_J__LocalTime(hours), t.F_offset)
}
func (t *OffsetTime) PlusMinutes_J__OffsetTime(minutes int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).PlusMinutes_J__LocalTime(minutes), t.F_offset)
}
func (t *OffsetTime) PlusSeconds_J__OffsetTime(seconds int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).PlusSeconds_J__LocalTime(seconds), t.F_offset)
}
func (t *OffsetTime) PlusNanos_J__OffsetTime(nanos int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).PlusNanos_J__LocalTime(nanos), t.F_offset)
}
func (t *OffsetTime) Minus_TemporalAmount__OffsetTime(amountToSubtract TemporalAmount) *OffsetTime {
	return OffsetTime_Cast(amountToSubtract.SubtractFrom_Temporal__Temporal(t))
}
func (t *OffsetTime) Minus_J_TemporalUnit__OffsetTime(amountToSubtract int64, unit TemporalUnit) *OffsetTime {
	if amountToSubtract == -9223372036854775808 {
		return NN(t.Plus_J_TemporalUnit__OffsetTime(9223372036854775807, unit)).Plus_J_TemporalUnit__OffsetTime(1, unit) } else {
			return t.Plus_J_TemporalUnit__OffsetTime(-amountToSubtract, unit)
		} }
func (t *OffsetTime) MinusHours_J__OffsetTime(hours int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).MinusHours_J__LocalTime(hours), t.F_offset)
}
func (t *OffsetTime) MinusMinutes_J__OffsetTime(minutes int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).MinusMinutes_J__LocalTime(minutes), t.F_offset)
}
func (t *OffsetTime) MinusSeconds_J__OffsetTime(seconds int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).MinusSeconds_J__LocalTime(seconds), t.F_offset)
}
func (t *OffsetTime) MinusNanos_J__OffsetTime(nanos int64) *OffsetTime {
	return t.With_LocalTime_ZoneOffset__OffsetTime(NN(t.F_time).MinusNanos_J__LocalTime(nanos), t.F_offset)
}
func (t *OffsetTime) Query_TemporalQuery__O(query TemporalQuery) any {
	var tmp1 bool; var tmp2 bool; tmp2 = query == TemporalQueries_Offset__TemporalQuery(); if !tmp2 { tmp2 = query == TemporalQueries_Zone__TemporalQuery() }; tmp1 = tmp2; if tmp1 { return t.F_offset.Ref() } else {

		var tmp3 bool; var tmp4 bool; var a_1 bool = query == TemporalQueries_ZoneId__TemporalQuery(); var b_2 bool = query == TemporalQueries_Chronology__TemporalQuery(); var tmp5 bool

		tmp5 = a_1; if !tmp5 { tmp5 = b_2 }; tmp4 = tmp5
//line :227:1
		if !tmp4 {


			tmp4 = query == TemporalQueries_LocalDate__TemporalQuery() }
//line :227:1
		tmp3 = tmp4; if tmp3 { return nil } else {



			if query == TemporalQueries_LocalTime__TemporalQuery() { return t.F_time.Ref() } else { if query == TemporalQueries_Precision__TemporalQuery() { ChronoUnit_Init(); return ChronoUnit_NANOS.Ref() } else {


				return query.QueryFrom_TemporalAccessor__O(t)
			} } } } }
func (t *OffsetTime) AdjustInto_Temporal__Temporal(temporal Temporal) Temporal {
	var tmp1 *ChronoField; ChronoField_Init(); tmp1 = ChronoField_NANO_OF_DAY; var tmp2 TemporalField = Up_ChronoField_TemporalField(tmp1); var tmp3 Temporal = temporal.With_TemporalField_J__Temporal(tmp2, NN(t.F_time).ToNanoOfDay__J()); var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_OFFSET_SECONDS; var tmp5 TemporalField = Up_ChronoField_TemporalField(tmp4); return tmp3.With_TemporalField_J__Temporal(tmp5, int64(NN(t.F_offset).GetTotalSeconds__I()))
}


func (t *OffsetTime) Until_Temporal_TemporalUnit__J(endExclusive Temporal, unit TemporalUnit) int64 {
	{ var end *OffsetTime = OffsetTime_From_TemporalAccessor__OffsetTime(endExclusive); var tmp1 TemporalUnit = unit
		if ChronoUnit_InstanceOf(tmp1) { var chronoUnit *ChronoUnit = ChronoUnit_Cast(tmp1); var nanosUntil int64 = NN(end).ToEpochNano__J() - t.ToEpochNano__J()

			switch NN(chronoUnit).F_ordinal { case 0: return nanosUntil; case 1:

				return nanosUntil / 1000; case 2:
				return nanosUntil / 1000000; case 3:
				return nanosUntil / 1000000000; case 4:
				return nanosUntil / 60000000000; case 5:
				return nanosUntil / 3600000000000; case 6:
				return nanosUntil / 43200000000000; default:
				panic(Thrown(UnsupportedTemporalTypeException_New_String(Concat(Lit_2020, StrOfObj(unit)))))} } else {
					return unit.Between_Temporal_Temporal__J(t, Up_OffsetTime_Temporal(end)) } }; panic("a2g: unreachable")
}
func (t *OffsetTime) Format_DateTimeFormatter__String(formatter *DateTimeFormatter) *String {
	Objects_RequireNonNull_O_String__O(formatter.Ref(), Lit_2041)
	return NN(formatter).Format_TemporalAccessor__String(t)
}
func (t *OffsetTime) AtDate_LocalDate__OffsetDateTime(date *LocalDate) *OffsetDateTime {
	return OffsetDateTime_Of_LocalDate_LocalTime_ZoneOffset__OffsetDateTime(date, t.F_time, t.F_offset)
}
func (t *OffsetTime) ToEpochNano__J() int64 {
	var nod int64 = NN(t.F_time).ToNanoOfDay__J(); var offsetNanos int64 = int64(NN(t.F_offset).GetTotalSeconds__I()) * 1000000000

	return nod - offsetNanos
}
func (t *OffsetTime) ToEpochSecond_LocalDate__J(date *LocalDate) int64 {
	Objects_RequireNonNull_O_String__O(date.Ref(), Lit_1440)
	var epochDay int64 = NN(date).ToEpochDay__J(); var secs int64 = epochDay*86400 + int64(NN(t.F_time).ToSecondOfDay__I())

	secs = secs - int64(NN(t.F_offset).GetTotalSeconds__I())
//line :270:1
	return secs
}



func (t *OffsetTime) CompareTo_OffsetTime__I(other *OffsetTime) int32 {
	var tmp1 *ZoneOffset = t.F_offset; if NN(tmp1).Equals_O__Z(other.F_offset.Ref()) {
		var tmp2 *LocalTime = t.F_time; return NN(tmp2).CompareTo_LocalTime__I(other.F_time) } else {
			var compare int32 = Long_Compare_J_J__I(t.ToEpochNano__J(), NN(other).ToEpochNano__J())
			if compare == 0 { var tmp3 *LocalTime = t.F_time; compare = NN(tmp3).CompareTo_LocalTime__I(other.F_time) }
//line :278:1
			return compare
		}
}

func (t *OffsetTime) IsAfter_OffsetTime__Z(other *OffsetTime) bool {
	return t.ToEpochNano__J() > NN(other).ToEpochNano__J()
}
func (t *OffsetTime) IsBefore_OffsetTime__Z(other *OffsetTime) bool {
	return t.ToEpochNano__J() < NN(other).ToEpochNano__J()
}
func (t *OffsetTime) IsEqual_OffsetTime__Z(other *OffsetTime) bool {
	return t.ToEpochNano__J() == NN(other).ToEpochNano__J()
}
func (t *OffsetTime) Equals_O__Z(obj any) bool {
	if any(t) == any(obj) { return true } else {

		var tmp1 any = obj; if OffsetTime_InstanceOf(tmp1) { var other *OffsetTime = OffsetTime_Cast(tmp1); var tmp2 *LocalTime = t.F_time
			if NN(tmp2).Equals_O__Z(other.F_time.Ref()) { var tmp3 *ZoneOffset = t.F_offset; return NN(tmp3).Equals_O__Z(other.F_offset.Ref()) } else { return false } } else {
//line :294:1
				return false
			}
	}
}
func (t *OffsetTime) HashCode__I() int32 {
	return NN(t.F_time).HashCode__I() ^ NN(t.F_offset).HashCode__I()
}
func (t *OffsetTime) ToString__String() *String {
	var offsetStr *String = NN(t.F_offset).ToString__String(); var buf *StringBuilder = StringBuilder_New_I(18 + NN(offsetStr).Length__I())

	DateTimeHelper_FormatTo_StringBuilder_LocalTime__V(buf, t.F_time)
	return NN(NN(buf).Append_String__StringBuilder(offsetStr)).ToString__String()
}
func (t *OffsetTime) WriteReplace__O() any { panic(A2g_NotTranslated("java.time.OffsetTime.writeReplace()Ljava/lang/Object;")) }



type OffsetTime struct{ Object; F_time *LocalTime; F_offset *ZoneOffset }

func (t *OffsetTime) Is_Temporal() {}

func (t *OffsetTime) Is_TemporalAdjuster() {}

func (t *OffsetTime) Is_Comparable() {}

func (t *OffsetTime) Is_Serializable() {}

func (t *OffsetTime) Is_TemporalAccessor() {}

var OffsetTime_MIN *OffsetTime

var OffsetTime_MAX *OffsetTime

const OffsetTime_serialVersionUID int64 = 7264499704384272492

var OffsetTime_init ClassInit

func OffsetTime_Init() { if !OffsetTime_init.Done() { OffsetTime_init.Run(OffsetTime_clinit) } }

func OffsetTime_clinit() { var tmp1 *LocalTime; LocalTime_Init(); tmp1 = LocalTime_MIN; var tmp2 *LocalTime = tmp1; var tmp3 *ZoneOffset; ZoneOffset_Init(); tmp3 = ZoneOffset_MAX; OffsetTime_MIN = NN(tmp2).AtOffset_ZoneOffset__OffsetTime(tmp3); var tmp4 *LocalTime; LocalTime_Init(); tmp4 = LocalTime_MAX; var tmp5 *LocalTime = tmp4; var tmp6 *ZoneOffset; ZoneOffset_Init(); tmp6 = ZoneOffset_MIN; OffsetTime_MAX = NN(tmp5).AtOffset_ZoneOffset__OffsetTime(tmp6) }

func (t *OffsetTime) With_TemporalAdjuster__Temporal(p0 TemporalAdjuster) Temporal { return Up_OffsetTime_Temporal(t.With_TemporalAdjuster__OffsetTime(p0)) }

func (t *OffsetTime) With_TemporalField_J__Temporal(p0 TemporalField, p1 int64) Temporal { return Up_OffsetTime_Temporal(t.With_TemporalField_J__OffsetTime(p0, p1)) }

func (t *OffsetTime) Plus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_OffsetTime_Temporal(t.Plus_TemporalAmount__OffsetTime(p0)) }

func (t *OffsetTime) Plus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_OffsetTime_Temporal(t.Plus_J_TemporalUnit__OffsetTime(p0, p1)) }

func (t *OffsetTime) Minus_TemporalAmount__Temporal(p0 TemporalAmount) Temporal { return Up_OffsetTime_Temporal(t.Minus_TemporalAmount__OffsetTime(p0)) }

func (t *OffsetTime) Minus_J_TemporalUnit__Temporal(p0 int64, p1 TemporalUnit) Temporal { return Up_OffsetTime_Temporal(t.Minus_J_TemporalUnit__OffsetTime(p0, p1)) }

func (t *OffsetTime) CompareTo_O__I(p0 any) int32 { return t.CompareTo_OffsetTime__I(OffsetTime_Cast(p0)) }

func (t *OffsetTime) Ref() any { if t == nil { return nil }; return t }

func (t *OffsetTime) GetClass__Class() *Class { return OffsetTime_class }

func (t *OffsetTime) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OffsetTime) CloneShallow() any { panic(CloneNotSupported(t)) }

func OffsetTime_InstanceOf(x any) bool { _, ok := x.(*OffsetTime); return ok }

func OffsetTime_Cast(x any) *OffsetTime { if x == nil { return nil }; v, ok := x.(*OffsetTime); if !ok { panic(ClassCast(x, OffsetTime_class)) }; return v }
