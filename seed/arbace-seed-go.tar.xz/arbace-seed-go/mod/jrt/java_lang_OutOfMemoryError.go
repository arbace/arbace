//line java_lang_OutOfMemoryError.ae:1
package jrt








func OutOfMemoryError_New() *OutOfMemoryError { t := &OutOfMemoryError{}; t.Ctor(); return t }
//line :10:1
func (t *OutOfMemoryError) Ctor() { t.VirtualMachineError.Ctor(t) }

func OutOfMemoryError_New_String(p0 *String) *OutOfMemoryError { t := &OutOfMemoryError{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *OutOfMemoryError) Ctor_String(s *String) { t.VirtualMachineError.Ctor_String(t, s) }







type OutOfMemoryError struct{ VirtualMachineError }

const OutOfMemoryError_serialVersionUID int64 = 8228564086184010517

func (t *OutOfMemoryError) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *OutOfMemoryError) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *OutOfMemoryError) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *OutOfMemoryError) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *OutOfMemoryError) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *OutOfMemoryError) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *OutOfMemoryError) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *OutOfMemoryError) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *OutOfMemoryError) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *OutOfMemoryError) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *OutOfMemoryError) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *OutOfMemoryError) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *OutOfMemoryError) Ref() any { if t == nil { return nil }; return t }

func (t *OutOfMemoryError) GetClass__Class() *Class { return OutOfMemoryError_class }

func (t *OutOfMemoryError) Clone__O() any { return A2g_ObjectClone(t) }

func (t *OutOfMemoryError) CloneShallow() any { panic(CloneNotSupported(t)) }

func OutOfMemoryError_InstanceOf(x any) bool { _, ok := x.(*OutOfMemoryError); return ok }

func OutOfMemoryError_Cast(x any) *OutOfMemoryError { if x == nil { return nil }; v, ok := x.(*OutOfMemoryError); if !ok { panic(ClassCast(x, OutOfMemoryError_class)) }; return v }
