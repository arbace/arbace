//line java_text_EntryPair.ae:1
package jrt










func EntryPair_New_String_I(p0 *String, p1 int32) *EntryPair { t := &EntryPair{}; t.Ctor_String_I(p0, p1); return t }
//line :12:1
func (t *EntryPair) Ctor_String_I(name *String, value int32) { t.Ctor_String_I_Z(name, value, true) }


func EntryPair_New_String_I_Z(p0 *String, p1 int32, p2 bool) *EntryPair { t := &EntryPair{}; t.Ctor_String_I_Z(p0, p1, p2); return t }
//line :15:1
func (t *EntryPair) Ctor_String_I_Z(name *String, value int32, fwd bool) {
	t.F_entryName = name
	t.F_value = value
	t.F_fwd = fwd
}

type EntryPair struct{ Object; F_entryName *String; F_value int32; F_fwd bool }

func (t *EntryPair) Ref() any { if t == nil { return nil }; return t }

func (t *EntryPair) GetClass__Class() *Class { return EntryPair_class }

func (t *EntryPair) ToString__String() *String { return Object_toString(t) }

func (t *EntryPair) Clone__O() any { return A2g_ObjectClone(t) }

func (t *EntryPair) CloneShallow() any { panic(CloneNotSupported(t)) }

func EntryPair_InstanceOf(x any) bool { _, ok := x.(*EntryPair); return ok }

func EntryPair_Cast(x any) *EntryPair { if x == nil { return nil }; v, ok := x.(*EntryPair); if !ok { panic(ClassCast(x, EntryPair_class)) }; return v }
