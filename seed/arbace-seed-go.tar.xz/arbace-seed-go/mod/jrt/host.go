//line host.ae:1
package jrt

import (
	"bytes"
	"compress/zlib"
	"errors"
	"io"
	"io/fs"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"
)
// Host is the operating system as jrt uses it. Translated code never reaches it except
// through jrt's classes (System, Runtime, Thread.sleep's clock, the file streams); SetHost
// replaces it before the program's first use of those.
//line :10:1
type Host /*line :14:1*/ interface {
	// the standard streams
	Stdin() io.Reader; Stdout() io.Writer
	Stderr() io.Writer
	// Open opens a file with os.O_* flags (O_RDONLY, O_WRONLY|O_CREATE|O_TRUNC ...).
	Open(name string, flag int, perm uint32) (HostFile, error)
	Stat(name string) (HostFileInfo, error)
	// ReadDir lists a directory's entries' names, sorted.
	ReadDir(name string) ([]string, error)
	Remove(name string) error
	Mkdir(name string, perm uint32) error
	Rename(from, to string) error
	Getwd() (string, error)
	// Now is the wall clock (System.currentTimeMillis, Date).
	Now() time.Time
	// Nanotime is a monotonic clock in nanoseconds (System.nanoTime).
	Nanotime() int64
//line :29:1
	Getenv(name string) (string, bool)
	Environ() []string
	// Args is the command line, the program's name first.
	Args(/*line :31:1*/) []string
	NumCPU() int
	// RandomBytes fills b with random bytes (SecureRandom's seeds).
	RandomBytes(b []byte)
	// Resource is an embedded resource by its path (RT.load, getResourceAsStream).
	Resource(name string) ([]byte, bool)
	// Exit ends the process with the status code.
	Exit(code int) }
// HostFile is an open file of the host.
//line :39:1
type HostFile /*line :41:1*/ interface { io.Reader; io.Writer; io.Closer
	Seek(offset int64, whence int) (int64, error) }
// HostFileInfo is what Stat tells of a file (java.io.File's queries).
type HostFileInfo /*line :46:1*/ struct{ Name string; Size, ModTimeMillis int64; IsDir bool; Mode uint32 }


// OSHost is B1a's host, over Go's os, time and crypto/rand; Resources (optional) holds the
// embedded resources.
type OSHost /*line :54:1*/ struct{ Resources fs.FS }

var hostStart time.Time = time.Now()

func (h OSHost) Stdin() io.Reader { return os.Stdin }
func (h OSHost) Stdout() io.Writer { return os.Stdout }
func (h OSHost) Stderr() io.Writer { return os.Stderr }
func (h OSHost) Open(name string, flag int, perm uint32) (HostFile, error) {
	f, err := os.OpenFile(name, flag, fs.FileMode(perm))
	if err != nil {
		return nil, err }
	return f, nil }
func (h OSHost) Stat(name string) (HostFileInfo, error) {
	fi, err := os.Stat(name)
	if err != nil {
					return HostFileInfo{}, err }
	return HostFileInfo{Name: fi.Name(), Size: fi.Size(), ModTimeMillis: fi.ModTime().UnixMilli(),
					IsDir:           fi.IsDir(), Mode:         uint32(fi.Mode()),
	}, nil }
func (h OSHost) ReadDir(name string) ([]string, error) {
	es, err := os.ReadDir(name)
	if err != nil {
		return nil, err }
	ns := make([]string, 0, len(es))
	for _, e := range es {
		ns = append(ns, e.Name()) }
	return ns, nil }
func (h OSHost) Remove(name string) error { return os.Remove(name) }
func (h OSHost) Mkdir(name string, perm uint32) error { return os.Mkdir(name, fs.FileMode(perm)) }
func (h OSHost) Rename(from, to string) error { return os.Rename(from, to) }
func (h OSHost) Getwd() (string, error) { return os.Getwd() }
func (h OSHost) Now() time.Time { return time.Now() }
func (h OSHost) Nanotime() int64 { return int64(time.Since(hostStart)) }
func (h OSHost) Getenv(name string) (string, bool) { return os.LookupEnv(name) }
func (h OSHost) Environ() []string { return os.Environ() }
func (h OSHost) Args() []string { return os.Args }
func (h OSHost) NumCPU() int { return runtime.NumCPU() }
// Resource is an embedded resource: the file name, else name.z inflated (a2g writes the
// resources a zlib stream makes a quarter smaller so: amendment SZ2).
//line :91:1
func (h OSHost) Resource(name string,


) ([]byte, bool) {
	if h.Resources == nil {
		return nil, false }
	{ b, err := fs.ReadFile(h.Resources, name)
		if err == nil {
			return b, true } }
	z, err := fs.ReadFile(h.Resources, name+".z")
	if err != nil {
		return nil, false }
	r, zerr := zlib.NewReader(bytes.NewReader(z))
	if zerr != nil {
		return nil, false }
	b, rerr := io.ReadAll(r)
	return b, rerr == nil }
func (h OSHost) Exit(code int) { StopProfile(); os.Exit(code) }
// ResourceOrPath is a resource as the Go build's class path has it (ClassLoader's
// getResourceAsStream; RT.load's order): the program's embedded resource, else the file name in
// one of the directories of ARBACE_PATH (separated by :), or the blob a store entry store:PREFIX
// of it finds (PathEntries, StoreResource; doc/go/BOX-NOTES.md, S3).
//line :110:1
func ResourceOrPath(name string) (b /*line :115:1*/[]byte, ok bool) {
	h := CurrentHost()
	r, found := h.Resource(name)
	if found {
		return r, true }
	{ path, set := h.Getenv("ARBACE_PATH")
		if !set {
			return nil, false }
		for _, dir := range PathEntries(path) {
			if strings.HasPrefix(dir, "store:") {
				if data, ok := StoreResource(dir[6:], name); ok {
					return data, true } } else {
						f, err := h.Open(dir+"/"+name, os.O_RDONLY, 0)
						if err == nil {
							data, rerr := io.ReadAll(f)
							f.Close()
							if rerr == nil {
								return data, true } } } } }
	return nil, false }
// theHost is the host jrt uses: the system's (ProgramHost, without resources) until SetHost.
var theHost Host =

	ProgramHost(nil)
var hostMu sync.RWMutex
// SetHost replaces the host (B1b's monitor calls; tests).
func SetHost(h Host) {
	hostMu.Lock()
	theHost = h
	hostMu.Unlock() }
// CurrentHost is the host jrt uses.
func CurrentHost() Host {
	hostMu.RLock()
	h := theHost
	hostMu.RUnlock()
	return h
}




// HostStream is one of the host's standard streams: 0 in, 1 out, 2 err.
type HostStream /*line :158:1*/ struct{ mu sync.Mutex; fd int }

var Stdin = &HostStream{fd: 0}
var Stdout = &HostStream{fd: 1}
var Stderr = &HostStream{fd: 2}

func (s *HostStream) Write(p []byte) (n int, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	h := CurrentHost()
	switch s.fd {
	case 1: return h.Stdout().Write(p)
	case 2: return h.Stderr().Write(p)}
	return 0, errors.New("stream not open for writing")
}
func (s *HostStream) WriteString(str string) (n int, err error) {
	return s.Write([]byte(str))
}
func (s *HostStream) Read(p []byte) (n int, err error) {
	if s.fd != 0 {
		return 0, errors.New("stream not open for reading") }
	s.mu.Lock()
	defer s.mu.Unlock()
	return CurrentHost().Stdin().Read(p)
}
