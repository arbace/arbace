//line java_net_SocketAddress.ae:1
package jrt










func (t *SocketAddress) Ctor(this SocketAddress_I) {}



type SocketAddress struct{ Object }

type SocketAddress_I interface{ Object_I; Serializable; Self_SocketAddress() *SocketAddress }

func (t *SocketAddress) Self_SocketAddress() *SocketAddress { return t }

func (t *SocketAddress) Is_Serializable() {}

const SocketAddress_serialVersionUID int64 = 5215720748342549866

func SocketAddress_InstanceOf(x any) bool { _, ok := x.(SocketAddress_I); return ok }

func SocketAddress_Cast(x any) SocketAddress_I { if x == nil { return nil }; v, ok := x.(SocketAddress_I); if !ok { panic(ClassCast(x, SocketAddress_class)) }; return v }
