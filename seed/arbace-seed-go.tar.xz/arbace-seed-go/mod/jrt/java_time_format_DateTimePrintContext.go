//line java_time_format_DateTimePrintContext.ae:1
package jrt


















func DateTimePrintContext_New_TemporalAccessor_DateTimeFormatter(p0 TemporalAccessor, p1 *DateTimeFormatter) *DateTimePrintContext { t := &DateTimePrintContext{}; t.Ctor_TemporalAccessor_DateTimeFormatter(p0, p1); return t }
//line :20:1
func (t *DateTimePrintContext) Ctor_TemporalAccessor_DateTimeFormatter(temporal TemporalAccessor, formatter *DateTimeFormatter) {
	t.F_temporal = DateTimePrintContext_Adjust_TemporalAccessor_DateTimeFormatter__TemporalAccessor(temporal, formatter)
	t.F_formatter = formatter
}
func DateTimePrintContext_Adjust_TemporalAccessor_DateTimeFormatter__TemporalAccessor(temporal TemporalAccessor, formatter *DateTimeFormatter) TemporalAccessor {

	var overrideChrono Chronology = NN(formatter).GetChronology__Chronology(); var overrideZone ZoneId_I = NN(formatter).GetZone__ZoneId(); var tmp1 bool; var tmp2 bool

	tmp2 = overrideChrono == nil; if tmp2 { tmp2 = overrideZone == nil }; tmp1 = tmp2; if tmp1 { return temporal } else {

		return DateTimePrintContext_AdjustWithOverride_TemporalAccessor_Chronology_ZoneId__TemporalAccessor(temporal, overrideChrono, overrideZone)
	} }
func DateTimePrintContext_AdjustWithOverride_TemporalAccessor_Chronology_ZoneId__TemporalAccessor(temporal TemporalAccessor, overrideChrono Chronology, overrideZone ZoneId_I) TemporalAccessor {


	var temporalChrono Chronology = Chronology_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_Chronology__TemporalQuery())); var temporalZone ZoneId_I = ZoneId_Cast(temporal.Query_TemporalQuery__O(TemporalQueries_ZoneId__TemporalQuery()))

	if Objects_Equals_O_O__Z(overrideChrono, temporalChrono) { overrideChrono = nil }
	if Objects_Equals_O_O__Z(overrideZone, temporalZone) { overrideZone = nil }
	var tmp1 bool; var tmp2 bool; tmp2 = overrideChrono == nil; if tmp2 { tmp2 = overrideZone == nil }; tmp1 = tmp2; if tmp1 { return temporal } else {

		var effectiveChrono Chronology; if !(overrideChrono == nil) { effectiveChrono = overrideChrono } else { effectiveChrono = temporalChrono
		}

		if !(overrideZone == nil) {
			var tmp3 *ChronoField; ChronoField_Init(); tmp3 = ChronoField_INSTANT_SECONDS; if temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp3)) {
				var chrono Chronology; var tmp4 *IsoChronology; IsoChronology_Init(); tmp4 = IsoChronology_INSTANCE; chrono = Chronology_Cast(Objects_RequireNonNullElse_O_O__O(effectiveChrono, tmp4.Ref()))



				return chrono.ZonedDateTime_Instant_ZoneId__ChronoZonedDateTime(Instant_From_TemporalAccessor__Instant(temporal), overrideZone) } }
		return DateTimePrintContext_AdjustSlow_TemporalAccessor_ZoneId_ZoneId_Chronology_Chronology_Chronology__TemporalAccessor(temporal, overrideZone, temporalZone, overrideChrono, effectiveChrono, temporalChrono)
	}
}




func DateTimePrintContext_AdjustSlow_TemporalAccessor_ZoneId_ZoneId_Chronology_Chronology_Chronology__TemporalAccessor(temporal TemporalAccessor, overrideZone, temporalZone ZoneId_I, overrideChrono, effectiveChrono, temporalChrono Chronology) TemporalAccessor {




	if !(overrideZone == nil) {
		var tmp1 bool; var tmp2 bool; var tmp3 bool; tmp3 = ZoneOffset_InstanceOf(overrideZone.Normalized__ZoneId()); if tmp3 {
			var tmp4 *ChronoField; ChronoField_Init(); tmp4 = ChronoField_OFFSET_SECONDS; tmp3 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp4)) }
//line :64:1
		tmp2 = tmp3; if tmp2 {

			var tmp5 *ChronoField; ChronoField_Init(); tmp5 = ChronoField_OFFSET_SECONDS; var tmp6 int32 = temporal.Get_TemporalField__I(Up_ChronoField_TemporalField(tmp5)); var tmp7 *ZoneRules = overrideZone.GetRules__ZoneRules(); var tmp8 *Instant; Instant_Init(); tmp8 = Instant_EPOCH; tmp2 = !(tmp6 == NN(NN(tmp7).GetOffset_Instant__ZoneOffset(tmp8)).GetTotalSeconds__I()) }
//line :64:1
		tmp1 = tmp2; if tmp1 {



			panic(Thrown(DateTimeException_New_String(Concat(Lit_2365, StrOfObj(overrideZone), Lit_2366, StrOfObj(temporal)))))
		}
	}




	var effectiveZone ZoneId_I; if !(overrideZone == nil) { effectiveZone = overrideZone } else { effectiveZone = temporalZone }; var effectiveDate ChronoLocalDate

	if !(overrideChrono == nil) {
		var tmp9 *ChronoField; ChronoField_Init(); tmp9 = ChronoField_EPOCH_DAY; if temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(tmp9)) {
			effectiveDate = effectiveChrono.Date_TemporalAccessor__ChronoLocalDate(temporal) } else {

				var tmp10 bool; var tmp11 bool; var tmp12 *IsoChronology; IsoChronology_Init(); tmp12 = IsoChronology_INSTANCE; tmp11 = any(overrideChrono) == any(tmp12.Ref()); if tmp11 {
					tmp11 = temporalChrono == nil }
//line :81:1
				tmp10 = tmp11; if tmp10 { } else {

					var arr_101643 *RefArray = ChronoField_Values__ChronoField1(); var len_101644 int32 = int32(len(arr_101643.A)); var i_101645 int32 = 0; for ; i_101645 < len_101644; i_101645++ { var f *ChronoField = As[*ChronoField](arr_101643.A[i_101645]); var tmp13 bool; var tmp14 bool
						tmp14 = NN(f).IsDateBased__Z(); if tmp14 { tmp14 = temporal.IsSupported_TemporalField__Z(Up_ChronoField_TemporalField(f)) }; tmp13 = tmp14; if tmp13 {
							panic(Thrown(DateTimeException_New_String(Concat(Lit_2367, StrOfObj(overrideChrono), Lit_2368, StrOfObj(temporal)))))
						}
					}
				}



				effectiveDate = nil } } else {
					effectiveDate = nil }
	var effectiveDate_2 ChronoLocalDate = effectiveDate
	return DateTimePrintContext_1_New_ChronoLocalDate_TemporalAccessor_Chronology_ZoneId(effectiveDate_2, temporal, effectiveChrono, effectiveZone) }
func (t *DateTimePrintContext_1) IsSupported_TemporalField__Z(field TemporalField) bool {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_val_effectiveDate == nil); if tmp2 { tmp2 = field.IsDateBased__Z() }; tmp1 = tmp2; if tmp1 {
		return t.F_val_effectiveDate.IsSupported_TemporalField__Z(field) } else {
			return t.F_val_temporal.IsSupported_TemporalField__Z(field)
		} }
func (t *DateTimePrintContext_1) Range_TemporalField__ValueRange(field TemporalField) *ValueRange {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_val_effectiveDate == nil); if tmp2 { tmp2 = field.IsDateBased__Z() }; tmp1 = tmp2; if tmp1 {
		return t.F_val_effectiveDate.Range_TemporalField__ValueRange(field) } else {
			return t.F_val_temporal.Range_TemporalField__ValueRange(field)
		} }
func (t *DateTimePrintContext_1) GetLong_TemporalField__J(field TemporalField) int64 {
	var tmp1 bool; var tmp2 bool; tmp2 = !(t.F_val_effectiveDate == nil); if tmp2 { tmp2 = field.IsDateBased__Z() }; tmp1 = tmp2; if tmp1 {
		return t.F_val_effectiveDate.GetLong_TemporalField__J(field) } else {
			return t.F_val_temporal.GetLong_TemporalField__J(field)
		} }
func (t *DateTimePrintContext_1) Query_TemporalQuery__O(query TemporalQuery) any {
	if query == TemporalQueries_Chronology__TemporalQuery() { return t.F_val_effectiveChrono } else { if query == TemporalQueries_ZoneId__TemporalQuery() { return t.F_val_effectiveZone } else { if query == TemporalQueries_Precision__TemporalQuery() {


		return t.F_val_temporal.Query_TemporalQuery__O(query) } else {
			return query.QueryFrom_TemporalAccessor__O(t)
		} } } }
func (t *DateTimePrintContext_1) ToString__String() *String {
	var tmp1 *String
	if !(t.F_val_effectiveChrono == nil) { tmp1 = Concat(Lit_2371, StrOfObj(t.F_val_effectiveChrono)) } else { tmp1 = Lit_69 }
//line :119:1
	var tmp2 *String = tmp1; var tmp3 *String

	if !(t.F_val_effectiveZone == nil) { tmp3 = Concat(Lit_2372, StrOfObj(t.F_val_effectiveZone)) } else { tmp3 = Lit_69 }
//line :119:1
	return Concat(StrOfObj(t.F_val_temporal), tmp2, tmp3)
}


func (t *DateTimePrintContext) GetTemporal__TemporalAccessor() TemporalAccessor { return t.F_temporal }

func (t *DateTimePrintContext) GetLocale__Locale() *Locale { return NN(t.F_formatter).GetLocale__Locale() }

func (t *DateTimePrintContext) GetDecimalStyle__DecimalStyle() *DecimalStyle {
	return NN(t.F_formatter).GetDecimalStyle__DecimalStyle()
}
func (t *DateTimePrintContext) GetValue_TemporalQuery_Z__O(query TemporalQuery, optional bool) any {
	var result any = t.F_temporal.Query_TemporalQuery__O(query); var tmp1 bool; var tmp2 bool
	tmp2 = result == nil; if tmp2 { tmp2 = !optional }; tmp1 = tmp2; if tmp1 {
		panic(Thrown(DateTimeException_New_String(Concat(Lit_2369, StrOfObj(query), Lit_2370, StrOfObj(t.F_temporal))))) }
//line :131:1
	return result
}




func (t *DateTimePrintContext) GetValue_TemporalField_Z__Long(field TemporalField, optional bool) *Long {
	var tmp1 bool; var tmp2 bool; tmp2 = optional; if tmp2 { tmp2 = !t.F_temporal.IsSupported_TemporalField__Z(field) }; tmp1 = tmp2; if tmp1 { return nil } else { return Long_ValueOf_J__Long(t.F_temporal.GetLong_TemporalField__J(field))
	} }
func (t *DateTimePrintContext) ToString__String() *String { return t.F_temporal.ToString__String() }



type DateTimePrintContext struct{ Object; F_temporal TemporalAccessor; F_formatter *DateTimeFormatter }

func (t *DateTimePrintContext) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimePrintContext) GetClass__Class() *Class { return DateTimePrintContext_class }

func (t *DateTimePrintContext) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimePrintContext) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimePrintContext_InstanceOf(x any) bool { _, ok := x.(*DateTimePrintContext); return ok }

func DateTimePrintContext_Cast(x any) *DateTimePrintContext { if x == nil { return nil }; v, ok := x.(*DateTimePrintContext); if !ok { panic(ClassCast(x, DateTimePrintContext_class)) }; return v }



type DateTimePrintContext_1 struct{ Object; F_val_effectiveDate ChronoLocalDate; F_val_temporal TemporalAccessor; F_val_effectiveChrono Chronology; F_val_effectiveZone ZoneId_I }

func (t *DateTimePrintContext_1) Is_TemporalAccessor() {}

func DateTimePrintContext_1_New_ChronoLocalDate_TemporalAccessor_Chronology_ZoneId(p0 ChronoLocalDate, p1 TemporalAccessor, p2 Chronology, p3 ZoneId_I) *DateTimePrintContext_1 { t := &DateTimePrintContext_1{}; t.Ctor_ChronoLocalDate_TemporalAccessor_Chronology_ZoneId(p0, p1, p2, p3); return t }

func (t *DateTimePrintContext_1) Ctor_ChronoLocalDate_TemporalAccessor_Chronology_ZoneId(val_effectiveDate ChronoLocalDate, val_temporal TemporalAccessor, val_effectiveChrono Chronology, val_effectiveZone ZoneId_I) { t.F_val_effectiveDate = val_effectiveDate; t.F_val_temporal = val_temporal; t.F_val_effectiveChrono = val_effectiveChrono; t.F_val_effectiveZone = val_effectiveZone }

func (t *DateTimePrintContext_1) Get_TemporalField__I(p0 TemporalField) int32 { return TemporalAccessor_Get_TemporalField__I(t, p0) }

func (t *DateTimePrintContext_1) Ref() any { if t == nil { return nil }; return t }

func (t *DateTimePrintContext_1) GetClass__Class() *Class { return DateTimePrintContext_1_class }

func (t *DateTimePrintContext_1) Clone__O() any { return A2g_ObjectClone(t) }

func (t *DateTimePrintContext_1) CloneShallow() any { panic(CloneNotSupported(t)) }

func DateTimePrintContext_1_InstanceOf(x any) bool { _, ok := x.(*DateTimePrintContext_1); return ok }

func DateTimePrintContext_1_Cast(x any) *DateTimePrintContext_1 { if x == nil { return nil }; v, ok := x.(*DateTimePrintContext_1); if !ok { panic(ClassCast(x, DateTimePrintContext_1_class)) }; return v }
