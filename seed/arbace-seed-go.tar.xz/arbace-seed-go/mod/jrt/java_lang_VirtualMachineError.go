//line java_lang_VirtualMachineError.ae:1
package jrt








func (t *VirtualMachineError) Ctor(this VirtualMachineError_I) { t.Error.Ctor(this) }

func (t *VirtualMachineError) Ctor_String(this VirtualMachineError_I, message *String) { t.Error.Ctor_String(this, message) }

func (t *VirtualMachineError) Ctor_String_Throwable(this VirtualMachineError_I, message *String, cause Throwable_I) { t.Error.Ctor_String_Throwable(this, message, cause) }


func (t *VirtualMachineError) Ctor_Throwable(this VirtualMachineError_I, cause Throwable_I) { t.Error.Ctor_Throwable(this, cause) }



type VirtualMachineError struct{ Error }

type VirtualMachineError_I interface{ Error_I; Serializable; Self_VirtualMachineError() *VirtualMachineError }

func (t *VirtualMachineError) Self_VirtualMachineError() *VirtualMachineError { return t }

const VirtualMachineError_serialVersionUID int64 = 4161983926571568670

func VirtualMachineError_InstanceOf(x any) bool { _, ok := x.(VirtualMachineError_I); return ok }

func VirtualMachineError_Cast(x any) VirtualMachineError_I { if x == nil { return nil }; v, ok := x.(VirtualMachineError_I); if !ok { panic(ClassCast(x, VirtualMachineError_class)) }; return v }
