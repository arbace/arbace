//line java_util_Observer.ae:1
package jrt






type Observer interface{ Object_I; Is_Observer(); Update_Observable_O__V(p0 *Observable, p1 any) }

func Observer_InstanceOf(x any) bool { _, ok := x.(Observer); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Observer_class) } }; return ok }

func Observer_Cast(x any) Observer { if x == nil { return nil }; v, ok := x.(Observer); if ok && IsDynamic(x) { d, dyn := x.(Dynamic); if dyn { ok = d.DynImplements(Observer_class) } }; if !ok { panic(ClassCast(x, Observer_class)) }; return v }
