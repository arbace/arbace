//line charset.ae:1
package jrt

import "strings"






// Charset_I is java.nio.charset.Charset's class interface.
type Charset_I /*line :13:1*/ interface { Object_I
	Self_Charset() *Charset
	Is_Comparable()
	CompareTo_O__I(o any) int32
	Name__String() *String
	DisplayName__String() *String
	DisplayName_Locale__String(l *Locale) *String
	IsRegistered__Z() bool
	CanEncode__Z() bool
	Contains_Charset__Z(cs Charset_I) bool
	CompareTo_Charset__I(cs Charset_I) int32 }
// Charset is java.nio.charset.Charset (abstract): its canonical name, its aliases (Go
// strings, as JDK 26 lists them) and the coding phase 1 implements (csUTF8, csLatin1,
// csASCII).
//line :25:1
type Charset /*line :29:1*/ struct{ Object; name *String; aliases []string; kind int }

var Charset_class =
	Define(&ClassInfo{Name: "java.nio.charset.Charset", Kind: KindClass,
				Modifiers:                        AccPublic | AccAbstract, Super: Object_class,
				Interfaces:                       []*Class{Comparable_class}, Go: "arbace/jrt.Charset",
	},
	)
func (t *Charset) Self_Charset() *Charset { return t }
func (t *Charset) Is_Comparable() {}
// Name__String is Charset.name: the canonical name.
//line :39:1
func (t /*line :40:1*/*Charset) Name__String() *String { return t.name }
func (t *Charset) DisplayName__String() *String { return t.name }
func (t *Charset) DisplayName_Locale__String(l *Locale) *String { return t.name }
func (t *Charset) IsRegistered__Z() bool { return true }
func (t *Charset) CanEncode__Z() bool { return true }
// Contains_Charset__Z is Charset.contains: the Unicode charsets (sun.nio.cs.Unicode) contain
// all of jrt's, ISO-8859-1 itself and US-ASCII, US-ASCII itself.
//line :45:1
func (t /*line :48:1*/*Charset) Contains_Charset__Z(cs Charset_I) bool {
	o := cs.Self_Charset().kind
	k := t.kind
	return k == csUTF8 || k == csUTF16 || k == csUTF16BE || k == csUTF16LE || o == csASCII || o == k }
// ToString__String is Charset.toString: the canonical name.
//line :52:1
func (t /*line :53:1*/*Charset) ToString__String() *String { return t.name }
// Equals_O__Z is Charset.equals: the same canonical name.
//line :54:1
func (t /*line :55:1*/*Charset) Equals_O__Z(o any) bool {
	c, ok := o.(Charset_I)
	return ok && t.name.Equals_O__Z(c.Self_Charset().name) }
func (t *Charset) HashCode__I() int32 { return t.name.HashCode__I() }
// CompareTo_Charset__I is Charset.compareTo: the names compared ignoring case.
//line :59:1
func (t /*line :61:1*/*Charset) CompareTo_Charset__I(cs Charset_I) int32 {
	return t.name.CompareToIgnoreCase_String__I(cs.Self_Charset().name) }
func (t *Charset) CompareTo_O__I(o any) int32 {
	return t.CompareTo_Charset__I(Charset_Cast(o)) }
// Aliases are the charset's aliases, as Go strings.
func (t /*line :67:1*/*Charset) Aliases() []string { return t.aliases }

func Charset_InstanceOf(x any) bool { _, ok := x.(Charset_I); return ok }
func Charset_Cast(x any) Charset_I {
	if x == nil { return nil }
	v, ok := x.(Charset_I)
	if !ok { panic(ClassCast(x, Charset_class))
	}
	return v
}
// Unicode is sun.nio.cs.Unicode (abstract), UTF_8's superclass.
type Unicode struct{ Charset }
type Unicode_I interface{ Charset_I; Self_Unicode() *Unicode }
func (t *Unicode) Self_Unicode() *Unicode { return t }
var Unicode_class =
	Define(&ClassInfo{Name: "sun.nio.cs.Unicode", Kind: KindClass, Modifiers: AccAbstract, Super: Charset_class, Go: "arbace/jrt.Unicode"})


// UTF_8 is sun.nio.cs.UTF_8.
type UTF_8 struct{ Unicode }
// ISO_8859_1 is sun.nio.cs.ISO_8859_1.
//line :87:1
type ISO_8859_1 struct{ Charset }
// US_ASCII is sun.nio.cs.US_ASCII.
//line :88:1
type US_ASCII struct{ Charset }
// UTF_16 is sun.nio.cs.UTF_16 (step 5 phase 2B).
//line :89:1
type UTF_16 struct{ Unicode }
// UTF_16BE is sun.nio.cs.UTF_16BE.
//line :90:1
type UTF_16BE struct{ Unicode }
// UTF_16LE is sun.nio.cs.UTF_16LE.
//line :91:1
type UTF_16LE struct{ Unicode }

var (

	UTF_8_class = Define(&ClassInfo{Name: "sun.nio.cs.UTF_8", Kind:    KindClass,
			Modifiers:                AccPublic | AccFinal, Super: Unicode_class, Go: "arbace/jrt.UTF_8",
	},
	); ISO_8859_1_class = Define(&ClassInfo{Name: "sun.nio.cs.ISO_8859_1", Kind: KindClass,
				Modifiers:                AccPublic | AccFinal, Super:   Charset_class, Go: "arbace/jrt.ISO_8859_1",
	},
	); US_ASCII_class = Define(&ClassInfo{Name: "sun.nio.cs.US_ASCII", Kind: KindClass,
				Modifiers:                AccPublic | AccFinal, Super: Charset_class, Go: "arbace/jrt.US_ASCII",
	},
	); UTF_16_class = Define(&ClassInfo{Name: "sun.nio.cs.UTF_16", Kind: KindClass, Modifiers: AccPublic, Super: Unicode_class, Go: "arbace/jrt.UTF_16"})


	UTF_16BE_class = Define(&ClassInfo{Name: "sun.nio.cs.UTF_16BE", Kind: KindClass, Modifiers: AccPublic, Super: Unicode_class, Go: "arbace/jrt.UTF_16BE"})


	UTF_16LE_class = Define(&ClassInfo{Name: "sun.nio.cs.UTF_16LE", Kind: KindClass, Modifiers: AccPublic, Super: Unicode_class, Go: "arbace/jrt.UTF_16LE"})
)

var (
	// UTF_8_INSTANCE is sun.nio.cs.UTF_8.INSTANCE.
	UTF_8_INSTANCE                                 /*line :114:1*/*UTF_8  =
	&UTF_8{Unicode: Unicode{Charset: Charset{name: Intern("UTF-8"), kind: csUTF8,
							aliases:               []string{"UTF8", "unicode-1-1-utf-8"},
	},
	},
	}
//line :118:1
	ISO_8859_1_INSTANCE                /*line :117:1*/*ISO_8859_1  =
	&ISO_8859_1{Charset: Charset{name: Intern("ISO-8859-1"), kind: csLatin1,
						aliases:                    []string{"819", "8859_1", "IBM-819", "IBM819", "ISO8859-1", "ISO8859_1", "ISO_8859-1", "ISO_8859-1:1987", "ISO_8859_1", "cp819", "csISOLatin1", "iso-ir-100", "l1", "latin1"},
	},
	}

	US_ASCII_INSTANCE                /*line :122:1*/*US_ASCII  =
	&US_ASCII{Charset: Charset{name: Intern("US-ASCII"), kind: csASCII,
						aliases:                  []string{"646", "ANSI_X3.4-1968", "ANSI_X3.4-1986", "ASCII", "IBM367", "ISO646-US", "ISO_646.irv:1991", "ascii7", "cp367", "csASCII", "iso-ir-6", "iso_646.irv:1983", "us"},
	},
	}

	UTF_16_INSTANCE                                 /*line :127:1*/*UTF_16  =
	&UTF_16{Unicode: Unicode{Charset: Charset{name: Intern("UTF-16"), kind: csUTF16,
							aliases:                []string{"UTF_16", "UnicodeBig", "unicode", "utf16"},
	},
	},
	}
//line :131:1
	UTF_16BE_INSTANCE                                 /*line :130:1*/*UTF_16BE  =
	&UTF_16BE{Unicode: Unicode{Charset: Charset{name: Intern("UTF-16BE"), kind: csUTF16BE,
								aliases:                  []string{"ISO-10646-UCS-2", "UTF_16BE", "UnicodeBigUnmarked", "X-UTF-16BE"},
	},
	},
	}
//line :134:1
	UTF_16LE_INSTANCE                                 /*line :133:1*/*UTF_16LE  =
	&UTF_16LE{Unicode: Unicode{Charset: Charset{name: Intern("UTF-16LE"), kind: csUTF16LE,
								aliases:                  []string{"UTF_16LE", "UnicodeLittleUnmarked", "X-UTF-16LE"},
	}}})
func (t *UTF_8) Ref() any { if t == nil { return nil }; return t }
func (t *UTF_8) GetClass__Class() *Class { return UTF_8_class }
func (t *UTF_8) Clone__O() any { panic(CloneNotSupported(t)) }
func (t *ISO_8859_1) Ref() any { if t == nil { return nil }; return t }
func (t *ISO_8859_1) GetClass__Class() *Class { return ISO_8859_1_class }
func (t *ISO_8859_1) Clone__O() any { panic(CloneNotSupported(t)) }
func (t *US_ASCII) Ref() any { if t == nil { return nil }; return t }
func (t *US_ASCII) GetClass__Class() *Class { return US_ASCII_class }
func (t *US_ASCII) Clone__O() any { panic(CloneNotSupported(t)) }

func (t *UTF_16) Ref() any { if t == nil { return nil }; return t }
func (t *UTF_16) GetClass__Class() *Class { return UTF_16_class }
func (t *UTF_16) Clone__O() any { panic(CloneNotSupported(t)) }
func (t *UTF_16BE) Ref() any { if t == nil { return nil }; return t }
func (t *UTF_16BE) GetClass__Class() *Class { return UTF_16BE_class }
func (t *UTF_16BE) Clone__O() any { panic(CloneNotSupported(t)) }
func (t *UTF_16LE) Ref() any { if t == nil { return nil }; return t }
func (t *UTF_16LE) GetClass__Class() *Class { return UTF_16LE_class }
func (t *UTF_16LE) Clone__O() any { panic(CloneNotSupported(t)) }

func UTF_8_InstanceOf(x any) bool { _, ok := x.(*UTF_8); return ok }
func ISO_8859_1_InstanceOf(x any) bool { _, ok := x.(*ISO_8859_1); return ok }
func US_ASCII_InstanceOf(x any) bool { _, ok := x.(*US_ASCII); return ok }

var allCharsets []Charset_I =
	[]Charset_I{UTF_8_INSTANCE, ISO_8859_1_INSTANCE, US_ASCII_INSTANCE, UTF_16_INSTANCE, UTF_16BE_INSTANCE, UTF_16LE_INSTANCE}


// legalCharsetName is Charset.checkName's rule: not empty; letters, digits and - + : _ . ,
// the first a letter or a digit.
func legalCharsetName(n string) bool {



	if len(n) == 0 {
		return false }
	for i, c := range n {
		ok := c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c >= '0' && c <= '9' ||
			i > 0 && (c == '-' || c == '+' || c == ':' || c == '_' || c == '.')
		if !ok {
			return false } }; return true }
// lookupCharset finds a charset by its canonical name or an alias, ignoring case; nil when
// jrt has no such charset.
func lookupCharset(n string) Charset_I {



	for _, cs := range allCharsets {
		c := cs.Self_Charset()
		if strings.EqualFold(c.name.String(), n) {
			return cs }
		for _, a := range c.aliases {
			if strings.EqualFold(a, n) {
				return cs } } }; return nil }
// checkedLookup is Charset.lookup with its checks: IllegalArgumentException("Null charset
// name") for null, IllegalCharsetNameException for an illegal name.
func checkedLookup(name /*line :196:1*/*String) Charset_I {
	if name == nil {
		panic(IllegalArgumentException_New_String(Str("Null charset name"))) }
	n := name.String()
	cs := lookupCharset(n)
	if cs != nil {
		return cs }
	if !legalCharsetName(n) {
		panic(IllegalCharsetNameException_New_String(name)) }; return nil }
// Charset_ForName_String__Charset is Charset.forName: UnsupportedCharsetException for a legal
// name jrt does not have (V9: UTF-8, ISO-8859-1 and US-ASCII; since step 5 phase 2B also UTF-16,
// UTF-16BE and UTF-16LE).
//line :207:1
func Charset_ForName_String__Charset(name /*line :211:1*/*String) Charset_I {
	cs := checkedLookup(name)
	if cs == nil {
		panic(UnsupportedCharsetException_New_String(name))
	}; return cs }
// Charset_ForName_String_Charset__Charset is Charset.forName(name, fallback).
func Charset_ForName_String_Charset__Charset(name /*line :219:1*/*String, fallback Charset_I) Charset_I {
	cs := checkedLookup(name)
	if cs == nil {
		return fallback
	}
	return cs }
func Charset_IsSupported_String__Z(name *String) bool {
	return checkedLookup(name) != nil }
// Charset_DefaultCharset__Charset is Charset.defaultCharset: UTF-8 (JEP 400).
func Charset_DefaultCharset__Charset() Charset_I { return UTF_8_INSTANCE }






var (

	StandardCharsets_class  /*line :236:1*/*Class                      =
	Define(&ClassInfo{Name: "java.nio.charset.StandardCharsets", Kind: KindClass,
				Modifiers:                                 AccPublic | AccFinal, Super: Object_class, Go: "arbace/jrt.StandardCharsets",
	},
	)
	// StandardCharsets_UTF_8 is StandardCharsets.UTF_8.
	StandardCharsets_UTF_8      Charset_I = UTF_8_INSTANCE
	StandardCharsets_ISO_8859_1 Charset_I = ISO_8859_1_INSTANCE
	StandardCharsets_US_ASCII   Charset_I = US_ASCII_INSTANCE
	StandardCharsets_UTF_16     Charset_I = UTF_16_INSTANCE
	StandardCharsets_UTF_16BE   Charset_I = UTF_16BE_INSTANCE; StandardCharsets_UTF_16LE Charset_I = UTF_16LE_INSTANCE)
// String_New_B1_Charset is new String(byte[], Charset): malformed input replaced as the
// charset's decoder replaces it.
func String_New_B1_Charset(b /*line :252:1*/*ByteArray, cs Charset_I) *String {
	NN(b)
	return newString(decodeWith(b.A, cs.Self_Charset())) }
// String_New_B1_I_I_Charset is new String(byte[], int offset, int length, Charset).
func String_New_B1_I_I_Charset(b /*line :258:1*/*ByteArray, offset, length int32, cs Charset_I) *String {
	if cs == nil {
		panic(NPE()) }
	checkFromSize(offset, length, len(NN(b).A))
	return newString(decodeWith(b.A[offset:offset+length], cs.Self_Charset())) }
// GetBytes_Charset__B1 is String.getBytes(Charset): unmappable characters as '?'.
func (t /*line :266:1*/*String) GetBytes_Charset__B1(cs Charset_I) *ByteArray {
	return ByteArrayOf(EncodeBytes(t.value, cs.Self_Charset().name)...)
}
func decodeWith(b []int8, c *Charset) []uint16 {
	return DecodeBytes(b, c.name)
}
