//line java_time_temporal_ChronoUnit.ae:1
package jrt






























func ChronoUnit_New_String_I_String_Duration(p0 *String, p1 int32, p2 *String, p3 *Duration) *ChronoUnit { ChronoUnit_Init(); t := &ChronoUnit{}; t.Ctor_String_I_String_Duration(p0, p1, p2, p3); return t }
//line :32:1
func (t *ChronoUnit) Ctor_String_I_String_Duration(enumName *String, enumOrdinal int32, name *String, estimatedDuration *Duration) { t.Enum.Ctor_String_I(t, enumName, enumOrdinal)
	t.F_name = name
	t.F_duration = estimatedDuration
}
func (t *ChronoUnit) GetDuration__Duration() *Duration { return t.F_duration }

func (t *ChronoUnit) IsDurationEstimated__Z() bool {
	return t.CompareTo_Enum__I(Up_ChronoUnit_Enum(ChronoUnit_DAYS)) >= 0
}
func (t *ChronoUnit) IsDateBased__Z() bool {
	var tmp1 bool; tmp1 = t.CompareTo_Enum__I(Up_ChronoUnit_Enum(ChronoUnit_DAYS)) >= 0; if tmp1 { tmp1 = !(t == ChronoUnit_FOREVER) }; return tmp1
}
func (t *ChronoUnit) IsTimeBased__Z() bool {
	return t.CompareTo_Enum__I(Up_ChronoUnit_Enum(ChronoUnit_DAYS)) < 0
}
func (t *ChronoUnit) IsSupportedBy_Temporal__Z(temporal Temporal) bool {
	return temporal.IsSupported_TemporalUnit__Z(t)
}
func (t *ChronoUnit) AddTo_Temporal_J__Temporal(temporal Temporal, amount int64) Temporal {
	return temporal.Plus_J_TemporalUnit__Temporal(amount, t)
}
func (t *ChronoUnit) Between_Temporal_Temporal__J(temporal1Inclusive, temporal2Exclusive Temporal) int64 {
	return temporal1Inclusive.Until_Temporal_TemporalUnit__J(temporal2Exclusive, t)
}
func (t *ChronoUnit) ToString__String() *String { return t.F_name }



type ChronoUnit struct{ Enum; F_name *String; F_duration *Duration }

func (t *ChronoUnit) Is_TemporalUnit() {}

func (t *ChronoUnit) Is_Constable() {}

var ChronoUnit_NANOS *ChronoUnit

var ChronoUnit_MICROS *ChronoUnit

var ChronoUnit_MILLIS *ChronoUnit

var ChronoUnit_SECONDS *ChronoUnit

var ChronoUnit_MINUTES *ChronoUnit

var ChronoUnit_HOURS *ChronoUnit

var ChronoUnit_HALF_DAYS *ChronoUnit

var ChronoUnit_DAYS *ChronoUnit

var ChronoUnit_WEEKS *ChronoUnit

var ChronoUnit_MONTHS *ChronoUnit

var ChronoUnit_YEARS *ChronoUnit

var ChronoUnit_DECADES *ChronoUnit

var ChronoUnit_CENTURIES *ChronoUnit

var ChronoUnit_MILLENNIA *ChronoUnit

var ChronoUnit_ERAS *ChronoUnit

var ChronoUnit_FOREVER *ChronoUnit

var ChronoUnit__VALUES *RefArray

var ChronoUnit_init ClassInit

func ChronoUnit_Init() { if !ChronoUnit_init.Done() { ChronoUnit_init.Run(ChronoUnit_clinit) } }

func ChronoUnit_clinit() { ChronoUnit_NANOS = ChronoUnit_New_String_I_String_Duration(Lit_2460, 0, Lit_2459, Duration_OfNanos_J__Duration(1)); ChronoUnit_MICROS = ChronoUnit_New_String_I_String_Duration(Lit_2462, 1, Lit_2461, Duration_OfNanos_J__Duration(1000)); ChronoUnit_MILLIS = ChronoUnit_New_String_I_String_Duration(Lit_2464, 2, Lit_2463, Duration_OfNanos_J__Duration(1000000)); ChronoUnit_SECONDS = ChronoUnit_New_String_I_String_Duration(Lit_2466, 3, Lit_2465, Duration_OfSeconds_J__Duration(1)); ChronoUnit_MINUTES = ChronoUnit_New_String_I_String_Duration(Lit_2468, 4, Lit_2467, Duration_OfSeconds_J__Duration(60)); ChronoUnit_HOURS = ChronoUnit_New_String_I_String_Duration(Lit_2470, 5, Lit_2469, Duration_OfSeconds_J__Duration(3600)); ChronoUnit_HALF_DAYS = ChronoUnit_New_String_I_String_Duration(Lit_2472, 6, Lit_2471, Duration_OfSeconds_J__Duration(43200)); ChronoUnit_DAYS = ChronoUnit_New_String_I_String_Duration(Lit_2474, 7, Lit_2473, Duration_OfSeconds_J__Duration(86400)); ChronoUnit_WEEKS = ChronoUnit_New_String_I_String_Duration(Lit_2476, 8, Lit_2475, Duration_OfSeconds_J__Duration(604800)); ChronoUnit_MONTHS = ChronoUnit_New_String_I_String_Duration(Lit_2478, 9, Lit_2477, Duration_OfSeconds_J__Duration(2629746)); ChronoUnit_YEARS = ChronoUnit_New_String_I_String_Duration(Lit_2480, 10, Lit_2479, Duration_OfSeconds_J__Duration(31556952)); ChronoUnit_DECADES = ChronoUnit_New_String_I_String_Duration(Lit_2482, 11, Lit_2481, Duration_OfSeconds_J__Duration(315569520)); ChronoUnit_CENTURIES = ChronoUnit_New_String_I_String_Duration(Lit_2484, 12, Lit_2483, Duration_OfSeconds_J__Duration(3155695200)); ChronoUnit_MILLENNIA = ChronoUnit_New_String_I_String_Duration(Lit_2486, 13, Lit_2485, Duration_OfSeconds_J__Duration(31556952000)); ChronoUnit_ERAS = ChronoUnit_New_String_I_String_Duration(Lit_2487, 14, Lit_1806, Duration_OfSeconds_J__Duration(31556952000000000)); var tmp1 *Duration; Duration_Init(); tmp1 = Duration_MAX; ChronoUnit_FOREVER = ChronoUnit_New_String_I_String_Duration(Lit_2489, 15, Lit_2488, tmp1); ChronoUnit__VALUES = ChronoUnit_X_values__ChronoUnit1() }

func ChronoUnit_Values__ChronoUnit1() *RefArray { ChronoUnit_Init(); return ChronoUnit__VALUES.Copy() }

func ChronoUnit_ValueOf_String__ChronoUnit(p0 *String) *ChronoUnit { ChronoUnit_Init(); return ChronoUnit_Cast(Enum_ValueOf_Class_String__Enum(ChronoUnit_class, p0)) }

func ChronoUnit_X_values__ChronoUnit1() *RefArray { ChronoUnit_Init(); return RefArrayOf(ChronoUnit_class, ChronoUnit_NANOS, ChronoUnit_MICROS, ChronoUnit_MILLIS, ChronoUnit_SECONDS, ChronoUnit_MINUTES, ChronoUnit_HOURS, ChronoUnit_HALF_DAYS, ChronoUnit_DAYS, ChronoUnit_WEEKS, ChronoUnit_MONTHS, ChronoUnit_YEARS, ChronoUnit_DECADES, ChronoUnit_CENTURIES, ChronoUnit_MILLENNIA, ChronoUnit_ERAS, ChronoUnit_FOREVER) }

func (t *ChronoUnit) DescribeConstable__Optional() *Optional { panic(A2g_NotTranslated("abstract java.time.temporal.ChronoUnit.describeConstable()Ljava/util/Optional;")) }

func (t *ChronoUnit) GetDeclaringClass__Class() *Class { return t.Impl_GetDeclaringClass__Class(t) }

func (t *ChronoUnit) CompareTo_O__I(p0 any) int32 { return t.Impl_CompareTo_O__I(t, p0) }

func (t *ChronoUnit) CompareTo_Enum__I(p0 Enum_I) int32 { return t.Impl_CompareTo_Enum__I(t, p0) }

func (t *ChronoUnit) Clone__O() any { return t.Impl_Clone__O(t) }

func (t *ChronoUnit) Ref() any { if t == nil { return nil }; return t }

func (t *ChronoUnit) GetClass__Class() *Class { return ChronoUnit_class }

func (t *ChronoUnit) CloneShallow() any { panic(CloneNotSupported(t)) }

func ChronoUnit_InstanceOf(x any) bool { _, ok := x.(*ChronoUnit); return ok }

func ChronoUnit_Cast(x any) *ChronoUnit { if x == nil { return nil }; v, ok := x.(*ChronoUnit); if !ok { panic(ClassCast(x, ChronoUnit_class)) }; return v }
