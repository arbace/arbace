//line java_util_ArrayDeque.ae:1
package jrt





















func (t *ArrayDeque) Grow_I__V(needed int32) {
	var oldCapacity int32 = int32(len(t.F_elements.A)); var newCapacity int32 = 0; var jump int32

	if oldCapacity < 64 {
		jump = oldCapacity + 2 } else {
			jump = oldCapacity >> 1 }
	var tmp1 bool; var tmp2 bool; tmp2 = jump < needed; if !tmp2 {
		var tmp3 int32; newCapacity = oldCapacity + jump; tmp3 = newCapacity; tmp2 = tmp3-2147483639 > 0 }
//line :29:1
	tmp1 = tmp2; if tmp1 {



		newCapacity = t.NewCapacity_I_I__I(needed, jump) }
	var es *RefArray; var tmp4 *RefArray = Arrays_CopyOf_O1_I__O1(t.F_elements, newCapacity); t.F_elements = tmp4; es = tmp4
	var tmp5 bool; var tmp6 bool; tmp6 = t.F_tail < t.F_head; if !tmp6 { var tmp7 bool; tmp7 = t.F_tail == t.F_head; if tmp7 { tmp7 = !(es.A[t.F_head] == nil) }; tmp6 = tmp7 }; tmp5 = tmp6; if tmp5 {
		var newSpace int32 = newCapacity - oldCapacity
		System_Arraycopy_O_I_O_I_I__V(es.Ref(), t.F_head, es.Ref(), t.F_head+newSpace, oldCapacity-t.F_head)




		var i int32 = t.F_head; var to int32; var tmp8 int32 = t.F_head + newSpace
		t.F_head = tmp8; to = tmp8
//line :42:1
	L1: for {

		if i < to { es.Store(i, nil); i, to = i+1, to; continue L1 }
//line :42:1
		break L1
	}
	}
}
func (t *ArrayDeque) NewCapacity_I_I__I(needed, jump int32) int32 {
	var oldCapacity int32 = int32(len(t.F_elements.A)); var minCapacity int32 = 0; var tmp1 int32


	minCapacity = oldCapacity + needed; tmp1 = minCapacity
//line :49:1
	if tmp1-2147483639 > 0 {




		if minCapacity < 0 { panic(Thrown(IllegalStateException_New_String(Lit_2600))) }
//line :53:1
		return 2147483647 } else {
//line :49:1
			if needed > jump { return minCapacity } else { if oldCapacity+jump-2147483639 < 0 {








				return oldCapacity + jump } else {
//line :49:1
					return 2147483639
				}
			}
		}
}







func ArrayDeque_New() *ArrayDeque { t := &ArrayDeque{}; t.Ctor(); return t }
//line :61:1
func (t *ArrayDeque) Ctor() { t.AbstractCollection.Ctor(t)
	t.F_elements = NewRefArray(Object_class, 17)
}
func ArrayDeque_New_I(p0 int32) *ArrayDeque { t := &ArrayDeque{}; t.Ctor_I(p0); return t }
//line :64:1
func (t *ArrayDeque) Ctor_I(numElements int32) { t.AbstractCollection.Ctor(t)
	var tmp1 int32

	if numElements < 1 { tmp1 = 1 } else { if numElements == 2147483647 { tmp1 = 2147483647 } else {


		tmp1 = numElements + 1 } }
//line :65:1
	t.F_elements = NewRefArray(Object_class, tmp1)
}





func ArrayDeque_New_Collection(p0 Collection) *ArrayDeque { t := &ArrayDeque{}; t.Ctor_Collection(p0); return t }
//line :72:1
func (t *ArrayDeque) Ctor_Collection(c Collection) { t.Ctor_I(c.Size__I())

	t.CopyElements_Collection__V(c)
}
func ArrayDeque_Inc_I_I__I(i, modulus int32) int32 {
	var tmp1 int32; i = i + 1; tmp1 = i; if tmp1 >= modulus { i = 0 }
//line :76:1
	return i
}


func ArrayDeque_Dec_I_I__I(i, modulus int32) int32 {
	var tmp1 int32; i = i - 1; tmp1 = i; if tmp1 < 0 { i = modulus - 1 }
//line :80:1
	return i
}


func ArrayDeque_Inc_I_I_I__I(i, distance, modulus int32) int32 {
	var tmp1 int32; i = i + distance; tmp1 = i; if tmp1-modulus >= 0 {
		i = i - modulus }
//line :84:1
	return i
}



func ArrayDeque_Sub_I_I_I__I(i, j, modulus int32) int32 {
	var tmp1 int32; i = i - j; tmp1 = i; if tmp1 < 0 { i = i + modulus }
//line :89:1
	return i
}


func ArrayDeque_ElementAt_O1_I__O(es *RefArray, i int32) any {
	return es.A[i]
}
func ArrayDeque_NonNullElementAt_O1_I__O(es *RefArray, i int32) any {
	var e any = es.A[i]; if e == nil { panic(Thrown(ConcurrentModificationException_New())) }; return e
}
func (t *ArrayDeque) AddFirst_O__V(e any) {
	if e == nil { panic(Thrown(NullPointerException_New())) }
	var es *RefArray = t.F_elements; var tmp1 int32; var tmp2 int32 = t.F_head; var tmp3 int32 = ArrayDeque_Dec_I_I__I(tmp2, int32(len(es.A)))
	t.F_head = tmp3; tmp1 = tmp3; es.Store(tmp1, e)
	if t.F_head == t.F_tail { t.Grow_I__V(1)
	} }
func (t *ArrayDeque) AddLast_O__V(e any) {
	if e == nil { panic(Thrown(NullPointerException_New())) }
	var es *RefArray = t.F_elements
	es.Store(t.F_tail, e)
	var tmp1 int32 = t.F_head; var tmp2 int32; var tmp3 int32 = t.F_tail; var tmp4 int32 = ArrayDeque_Inc_I_I__I(tmp3, int32(len(es.A))); t.F_tail = tmp4; tmp2 = tmp4; if tmp1 == tmp2 { t.Grow_I__V(1)
	} }
func (t *ArrayDeque) AddAll_Collection__Z(c Collection) bool {
	var s int32 = 0; var needed int32 = 0; var tmp1 int32; var tmp2 int32



	s = t.Size__I(); tmp2 = s
//line :114:1
	needed = tmp2 + c.Size__I() + 1 - int32(len(t.F_elements.A)); tmp1 = needed; if tmp1 > 0 {




		t.Grow_I__V(needed) }
	t.CopyElements_Collection__V(c)
	return t.Size__I() > s
}
func (t *ArrayDeque) CopyElements_Collection__V(c Collection) {
	var tmp1 Consumer; var tmp2 *ArrayDeque = t; tmp1 = &Consumer_Fn{Fn: func(p0 any) { tmp2.AddLast_O__V(p0) }}; c.ForEach_Consumer__V(tmp1)
}
func (t *ArrayDeque) OfferFirst_O__Z(e any) bool {
	t.AddFirst_O__V(e)
//line :126:1
	return true
}


func (t *ArrayDeque) OfferLast_O__Z(e any) bool { t.AddLast_O__V(e); return true }

func (t *ArrayDeque) RemoveFirst__O() any {
	var e any = t.PollFirst__O(); if e == nil { panic(Thrown(NoSuchElementException_New())) }; return e
}
func (t *ArrayDeque) RemoveLast__O() any {
	var e any = t.PollLast__O(); if e == nil { panic(Thrown(NoSuchElementException_New())) }; return e
}
func (t *ArrayDeque) PollFirst__O() any {
	var es *RefArray; var h int32 = 0; var e any; var tmp1 *RefArray

	es = t.F_elements; tmp1 = es; var tmp2 *RefArray = tmp1; var tmp3 int32; h = t.F_head; tmp3 = h; e = ArrayDeque_ElementAt_O1_I__O(tmp2, tmp3)
	if !(e == nil) { es.Store(h, nil); t.F_head = ArrayDeque_Inc_I_I__I(h, int32(len(es.A))) }
//line :139:1
	return e
}




func (t *ArrayDeque) PollLast__O() any {
	var es *RefArray; var t_ int32 = 0; var e any; var tmp1 *RefArray

	es = t.F_elements; tmp1 = es; var tmp2 *RefArray = tmp1; var tmp3 int32; var tmp4 int32 = t.F_tail; t_ = ArrayDeque_Dec_I_I__I(tmp4, int32(len(es.A))); tmp3 = t_; e = ArrayDeque_ElementAt_O1_I__O(tmp2, tmp3)
	if !(e == nil) { var tmp5 *RefArray = es; var tmp6 int32; var tmp7 int32 = t_; t.F_tail = tmp7; tmp6 = tmp7; tmp5.Store(tmp6, nil) }
//line :146:1
	return e
}




func (t *ArrayDeque) GetFirst__O() any {
	var e any = ArrayDeque_ElementAt_O1_I__O(t.F_elements, t.F_head)
	if e == nil { panic(Thrown(NoSuchElementException_New())) }
//line :153:1
	return e
}


func (t *ArrayDeque) GetLast__O() any {
	var es *RefArray = t.F_elements; var tmp1 int32 = t.F_tail; var e any = ArrayDeque_ElementAt_O1_I__O(es, ArrayDeque_Dec_I_I__I(tmp1, int32(len(es.A))))

	if e == nil { panic(Thrown(NoSuchElementException_New())) }
//line :158:1
	return e
}



func (t *ArrayDeque) PeekFirst__O() any {
	return ArrayDeque_ElementAt_O1_I__O(t.F_elements, t.F_head)
}
func (t *ArrayDeque) PeekLast__O() any {
	var es *RefArray; var tmp1 *RefArray
	es = t.F_elements; tmp1 = es; var tmp2 *RefArray = tmp1; var tmp3 int32 = t.F_tail; return ArrayDeque_ElementAt_O1_I__O(tmp2, ArrayDeque_Dec_I_I__I(tmp3, int32(len(es.A))))
}
func (t *ArrayDeque) RemoveFirstOccurrence_O__Z(o any) bool {
	if !(o == nil) {
		var es *RefArray = t.F_elements; var i int32 = t.F_head; var end int32 = t.F_tail; var to int32


		if i <= end { to = end } else { to = int32(len(es.A)) }
	L1: for {
	L2: for { if i < to {
		if Equals(o, es.A[i]) { t.Delete_I__Z(i); return true }
		i = i + 1
//line :177:1
		continue L2 }; break L2
	}

		if to == end { break L1 }
		i = 0
		to = end
//line :176:1
		continue L1 } }
//line :170:1
	return false
}













func (t *ArrayDeque) RemoveLastOccurrence_O__Z(o any) bool {
	if !(o == nil) {
		var es *RefArray = t.F_elements; var i int32 = t.F_tail; var end int32 = t.F_head; var to int32


		if i >= end { to = end } else { to = 0 }
	L1: for {
		i = i - 1
	L2: for { if i > to-1 {
		if Equals(o, es.A[i]) { t.Delete_I__Z(i); return true }
		i = i - 1
//line :193:1
		continue L2 }; break L2
	}

		if to == end { break L1 }
		i = int32(len(es.A))
		to = end
//line :191:1
		continue L1 } }
//line :185:1
	return false
}














func (t *ArrayDeque) Add_O__Z(e any) bool { t.AddLast_O__V(e); return true }

func (t *ArrayDeque) Offer_O__Z(e any) bool { return t.OfferLast_O__Z(e) }

func (t *ArrayDeque) Remove__O() any { return t.RemoveFirst__O() }

func (t *ArrayDeque) Poll__O() any { return t.PollFirst__O() }

func (t *ArrayDeque) Element__O() any { return t.GetFirst__O() }

func (t *ArrayDeque) Peek__O() any { return t.PeekFirst__O() }

func (t *ArrayDeque) Push_O__V(e any) { t.AddFirst_O__V(e) }

func (t *ArrayDeque) Pop__O() any { return t.RemoveFirst__O() }

func (t *ArrayDeque) Delete_I__Z(i int32) bool {
	var es *RefArray = t.F_elements; var capacity int32 = int32(len(es.A)); var h int32 = 0; var t_ int32 = 0; var front int32; var tmp1 int32



	h = t.F_head; tmp1 = h; front = ArrayDeque_Sub_I_I_I__I(i, tmp1, capacity)
//line :218:1
	var back int32; var tmp2 int32




	t_ = t.F_tail; tmp2 = t_; back = ArrayDeque_Sub_I_I_I__I(tmp2, i, capacity) - 1
	if front < back {

		if h <= i {
			System_Arraycopy_O_I_O_I_I__V(es.Ref(), h, es.Ref(), h+1, front) } else {

				System_Arraycopy_O_I_O_I_I__V(es.Ref(), 0, es.Ref(), 1, i)
				es.Store(0, es.A[capacity-1])
				System_Arraycopy_O_I_O_I_I__V(es.Ref(), h, es.Ref(), h+1, front-(i+1))
			}



		es.Store(h, nil)
		t.F_head = ArrayDeque_Inc_I_I__I(h, capacity)
//line :225:1
		return false } else {














			t.F_tail = ArrayDeque_Dec_I_I__I(t_, capacity)
			if i <= t.F_tail {
				System_Arraycopy_O_I_O_I_I__V(es.Ref(), i+1, es.Ref(), i, back) } else {

					System_Arraycopy_O_I_O_I_I__V(es.Ref(), i+1, es.Ref(), i, capacity-(i+1))




					es.Store(capacity-1, es.A[0])
					System_Arraycopy_O_I_O_I_I__V(es.Ref(), 1, es.Ref(), 0, t_-1) }
			es.Store(t.F_tail, nil)
//line :239:1
			return true
		}
}












func (t *ArrayDeque) Size__I() int32 {
	var tmp1 int32 = t.F_tail; var tmp2 int32 = t.F_head; return ArrayDeque_Sub_I_I_I__I(tmp1, tmp2, int32(len(t.F_elements.A)))
}
func (t *ArrayDeque) IsEmpty__Z() bool { return t.F_head == t.F_tail }

func (t *ArrayDeque) Iterator__Iterator() Iterator { return ArrayDeque_DeqIterator_New_ArrayDeque(t) }

func (t *ArrayDeque) DescendingIterator__Iterator() Iterator {
	return ArrayDeque_DescendingIterator_New_ArrayDeque(t)
}









func ArrayDeque_DeqIterator_New_ArrayDeque(p0 *ArrayDeque) *ArrayDeque_DeqIterator { t := &ArrayDeque_DeqIterator{}; t.Ctor_ArrayDeque(t, p0); return t }
//line :273:1
func (t *ArrayDeque_DeqIterator) Ctor_ArrayDeque(this ArrayDeque_DeqIterator_I, this_0 *ArrayDeque) { NN(this_0); t.F_this_0 = this_0; t.F_remaining = NN(this_0).Size__I(); t.F_lastRet = -1; t.F_cursor = this_0.F_head }

func (t *ArrayDeque_DeqIterator) Impl_HasNext__Z(this ArrayDeque_DeqIterator_I) bool { return t.F_remaining > 0 }

func (t *ArrayDeque_DeqIterator) Impl_Next__O(this ArrayDeque_DeqIterator_I) any {
	if t.F_remaining <= 0 { panic(Thrown(NoSuchElementException_New())) }
	var es *RefArray = t.F_this_0.F_elements; var e any = ArrayDeque_NonNullElementAt_O1_I__O(es, t.F_cursor); var tmp1 int32; var tmp2 int32 = t.F_cursor

	t.F_lastRet = tmp2; tmp1 = tmp2; var tmp3 int32 = tmp1; t.F_cursor = ArrayDeque_Inc_I_I__I(tmp3, int32(len(es.A)))
	t.F_remaining = t.F_remaining - 1
//line :279:1
	return e
}




func (t *ArrayDeque_DeqIterator) Impl_PostDelete_Z__V(this ArrayDeque_DeqIterator_I, leftShifted bool) {
	if leftShifted { var tmp1 int32 = t.F_cursor; t.F_cursor = ArrayDeque_Dec_I_I__I(tmp1, int32(len(t.F_this_0.F_elements.A)))
	} }
func (t *ArrayDeque_DeqIterator) Impl_Remove__V(this ArrayDeque_DeqIterator_I) {
	if t.F_lastRet < 0 { panic(Thrown(IllegalStateException_New())) }
	this.PostDelete_Z__V(NN(t.F_this_0).Delete_I__Z(t.F_lastRet))
	t.F_lastRet = -1
}
func (t *ArrayDeque_DeqIterator) Impl_ForEachRemaining_Consumer__V(this ArrayDeque_DeqIterator_I, action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var r int32 = 0; var tmp1 int32
	r = t.F_remaining; tmp1 = r; if tmp1 <= 0 { } else {
		t.F_remaining = 0
		var es *RefArray = t.F_this_0.F_elements; var tmp2 bool; var tmp3 bool
		tmp3 = es.A[t.F_cursor] == nil; if !tmp3 {
			var tmp4 int32 = t.F_this_0.F_tail; var tmp5 int32 = t.F_cursor; tmp3 = !(ArrayDeque_Sub_I_I_I__I(tmp4, tmp5, int32(len(es.A))) == r) }
//line :299:1
		tmp2 = tmp3; if tmp2 {

			panic(Thrown(ConcurrentModificationException_New())) }
		var i int32 = t.F_cursor; var end int32 = t.F_this_0.F_tail; var to int32

		if i <= end { to = end } else { to = int32(len(es.A)) }
	L1: for {
	L2: for { if i < to {
		action.Accept_O__V(ArrayDeque_ElementAt_O1_I__O(es, i))
		i = i + 1
//line :306:1
		continue L2 }; break L2
	}

		if to == end {
			if end == t.F_this_0.F_tail { } else { panic(Thrown(ConcurrentModificationException_New())) }
			t.F_lastRet = ArrayDeque_Dec_I_I__I(end, int32(len(es.A)))
			break L1 }
		i = 0
		to = end
//line :305:1
		continue L1
	}
	}
}










func ArrayDeque_DescendingIterator_New_ArrayDeque(p0 *ArrayDeque) *ArrayDeque_DescendingIterator { t := &ArrayDeque_DescendingIterator{}; t.Ctor_ArrayDeque(p0); return t }
//line :319:1
func (t *ArrayDeque_DescendingIterator) Ctor_ArrayDeque(this_0 *ArrayDeque) { NN(this_0); t.F_this_0 = this_0; t.ArrayDeque_DeqIterator.Ctor_ArrayDeque(t, this_0)
	var tmp1 int32 = this_0.F_tail; t.F_cursor = ArrayDeque_Dec_I_I__I(tmp1, int32(len(this_0.F_elements.A)))
}
func (t *ArrayDeque_DescendingIterator) Next__O() any {
	if t.F_remaining <= 0 { panic(Thrown(NoSuchElementException_New())) }
	var es *RefArray = t.F_this_0.F_elements; var e any = ArrayDeque_NonNullElementAt_O1_I__O(es, t.F_cursor); var tmp1 int32; var tmp2 int32 = t.F_cursor

	t.F_lastRet = tmp2; tmp1 = tmp2; var tmp3 int32 = tmp1; t.F_cursor = ArrayDeque_Dec_I_I__I(tmp3, int32(len(es.A)))
	t.F_remaining = t.F_remaining - 1
//line :324:1
	return e
}




func (t *ArrayDeque_DescendingIterator) PostDelete_Z__V(leftShifted bool) {
	if leftShifted { } else {
		var tmp1 int32 = t.F_cursor; t.F_cursor = ArrayDeque_Inc_I_I__I(tmp1, int32(len(t.F_this_0.F_elements.A)))
	} }
func (t *ArrayDeque_DescendingIterator) ForEachRemaining_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var r int32 = 0; var tmp1 int32
	r = t.F_remaining; tmp1 = r; if tmp1 <= 0 { } else {
		t.F_remaining = 0
		var es *RefArray = t.F_this_0.F_elements; var tmp2 bool; var tmp3 bool
		tmp3 = es.A[t.F_cursor] == nil; if !tmp3 {
			var tmp4 int32 = t.F_cursor; var tmp5 int32 = t.F_this_0.F_head; tmp3 = !(ArrayDeque_Sub_I_I_I__I(tmp4, tmp5, int32(len(es.A)))+1 == r) }
//line :340:1
		tmp2 = tmp3; if tmp2 {




			panic(Thrown(ConcurrentModificationException_New())) }
		var i int32 = t.F_cursor; var end int32 = t.F_this_0.F_head; var to int32

		if i >= end { to = end } else { to = 0 }
	L1: for {
	L2: for { if i > to-1 {
		action.Accept_O__V(ArrayDeque_ElementAt_O1_I__O(es, i))
		i = i - 1
//line :350:1
		continue L2 }; break L2
	}

		if to == end {
			if end == t.F_this_0.F_head { } else { panic(Thrown(ConcurrentModificationException_New())) }
			t.F_lastRet = end
			break L1 }
		i = int32(len(es.A)) - 1
		to = end
//line :349:1
		continue L1
	}
	}
}







func (t *ArrayDeque) Spliterator__Spliterator() Spliterator {
	return ArrayDeque_DeqSpliterator_New_ArrayDeque(t)
}







func ArrayDeque_DeqSpliterator_New_ArrayDeque(p0 *ArrayDeque) *ArrayDeque_DeqSpliterator { t := &ArrayDeque_DeqSpliterator{}; t.Ctor_ArrayDeque(p0); return t }
//line :370:1
func (t *ArrayDeque_DeqSpliterator) Ctor_ArrayDeque(this_0 *ArrayDeque) { NN(this_0); t.F_this_0 = this_0; t.F_fence = -1 }

func ArrayDeque_DeqSpliterator_New_ArrayDeque_I_I(p0 *ArrayDeque, p1, p2 int32) *ArrayDeque_DeqSpliterator { t := &ArrayDeque_DeqSpliterator{}; t.Ctor_ArrayDeque_I_I(p0, p1, p2); return t }
//line :372:1
func (t *ArrayDeque_DeqSpliterator) Ctor_ArrayDeque_I_I(this_0 *ArrayDeque, origin, fence int32) { NN(this_0); t.F_this_0 = this_0
	t.F_cursor = origin
	t.F_fence = fence
}
func (t *ArrayDeque_DeqSpliterator) GetFence__I() int32 {
	var t_ int32 = 0; var tmp1 int32
	t_ = t.F_fence; tmp1 = t_; if tmp1 < 0 { var tmp2 int32; var tmp3 int32 = t.F_this_0.F_tail; t.F_fence = tmp3; tmp2 = tmp3; t_ = tmp2; t.F_cursor = t.F_this_0.F_head }
//line :377:1
	return t_
}


func (t *ArrayDeque_DeqSpliterator) TrySplit__ArrayDeque_DeqSpliterator() *ArrayDeque_DeqSpliterator {
	var es *RefArray = t.F_this_0.F_elements; var i int32 = 0; var n int32 = 0; var tmp1 int32; var tmp2 int32 = t.GetFence__I(); var tmp3 int32




	i = t.F_cursor; tmp3 = i
//line :385:1
	var tmp4 int32 = tmp3; n = ArrayDeque_Sub_I_I_I__I(tmp2, tmp4, int32(len(es.A))) >> 1; tmp1 = n; if tmp1 <= 0 { return nil } else {




		var tmp5 int32 = i; var tmp6 int32; var tmp7 int32 = ArrayDeque_Inc_I_I_I__I(i, n, int32(len(es.A))); t.F_cursor = tmp7; tmp6 = tmp7; return ArrayDeque_DeqSpliterator_New_ArrayDeque_I_I(t.F_this_0, tmp5, tmp6)
	} }
func (t *ArrayDeque_DeqSpliterator) ForEachRemaining_Consumer__V(action Consumer) {
	if action == nil { panic(Thrown(NullPointerException_New())) }
	var end int32 = t.GetFence__I(); var cursor int32 = t.F_cursor; var es *RefArray = t.F_this_0.F_elements


	if cursor == end { } else {
		t.F_cursor = end
		var tmp1 bool; var tmp2 bool; tmp2 = es.A[cursor] == nil; if !tmp2 { tmp2 = es.A[ArrayDeque_Dec_I_I__I(end, int32(len(es.A)))] == nil }; tmp1 = tmp2; if tmp1 {
			panic(Thrown(ConcurrentModificationException_New())) }
		var i int32 = cursor; var to int32
		if i <= end { to = end } else { to = int32(len(es.A)) }
	L1: for {
	L2: for { if i < to {
		action.Accept_O__V(ArrayDeque_ElementAt_O1_I__O(es, i))
		i = i + 1
//line :404:1
		continue L2 }; break L2
	}

		if to == end { break L1 }
		i = 0
		to = end
//line :403:1
		continue L1
	}
	}
}




func (t *ArrayDeque_DeqSpliterator) TryAdvance_Consumer__Z(action Consumer) bool {
	Objects_RequireNonNull_O__O(action)
	var es *RefArray = t.F_this_0.F_elements
	if t.F_fence < 0 { t.F_fence = t.F_this_0.F_tail; t.F_cursor = t.F_this_0.F_head }
	var i int32 = 0; var tmp1 int32
	i = t.F_cursor; tmp1 = i; if tmp1 == t.F_fence { return false } else {

		var e any = ArrayDeque_NonNullElementAt_O1_I__O(es, i)
		t.F_cursor = ArrayDeque_Inc_I_I__I(i, int32(len(es.A)))
		action.Accept_O__V(e)
//line :418:1
		return true
	}
}


func (t *ArrayDeque_DeqSpliterator) EstimateSize__J() int64 { var tmp1 int32 = t.GetFence__I(); var tmp2 int32 = t.F_cursor; return int64(ArrayDeque_Sub_I_I_I__I(tmp1, tmp2, int32(len(t.F_this_0.F_elements.A)))) }


func (t *ArrayDeque_DeqSpliterator) Characteristics__I() int32 {
	return 16720
}


func (t *ArrayDeque) ForEach_Consumer__V(action Consumer) {
	Objects_RequireNonNull_O__O(action)
	var es *RefArray = t.F_elements; var i int32 = t.F_head; var end int32 = t.F_tail; var to int32


	if i <= end { to = end } else { to = int32(len(es.A)) }
L1: for {
L2: for { if i < to { action.Accept_O__V(ArrayDeque_ElementAt_O1_I__O(es, i)); i = i + 1; continue L2 }; break L2 }
	if to == end {
		if end == t.F_tail { } else { panic(Thrown(ConcurrentModificationException_New())) }
		break L1 }
	i = 0
	to = end
//line :437:1
	continue L1
}
}





func (t *ArrayDeque) RemoveIf_Predicate__Z(filter Predicate) bool {
	Objects_RequireNonNull_O__O(filter)
	return t.BulkRemove_Predicate__Z(filter)
}
func (t *ArrayDeque) RemoveAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	return t.BulkRemove_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var e any = p0; return c.Contains_O__Z(e) }})
}
func (t *ArrayDeque) RetainAll_Collection__Z(c Collection) bool {
	Objects_RequireNonNull_O__O(c)
	return t.BulkRemove_Predicate__Z(&Predicate_Fn{Fn: func(p0 any) bool { var e any = p0; return !c.Contains_O__Z(e) }})
}
func (t *ArrayDeque) BulkRemove_Predicate__Z(filter Predicate) bool {
	var es *RefArray = t.F_elements; var i int32 = t.F_head; var end int32 = t.F_tail; var to int32


	if i <= end { to = end } else { to = int32(len(es.A)) }
L1: for {
L2: for { if i < to {
	if filter.Test_O__Z(ArrayDeque_ElementAt_O1_I__O(es, i)) {
		return t.BulkRemoveModified_Predicate_I__Z(filter, i) }
	i = i + 1
//line :463:1
	continue L2 }; break L2
}


	if to == end {
		if end == t.F_tail { } else { panic(Thrown(ConcurrentModificationException_New())) }
		break L1 }
	i = 0
	to = end
//line :462:1
	continue L1 }
//line :458:1
	return false
}














func ArrayDeque_NBits_I__J1(n int32) *LongArray {
	return NewLongArray((n-1)>>6 + 1)
}
func ArrayDeque_SetBit_J1_I__V(bits *LongArray, i int32) {
	var i_1 int32 = i >> 6
	bits.A[i_1] = bits.A[i_1] | 1<<(i&63)
}
func ArrayDeque_IsClear_J1_I__Z(bits *LongArray, i int32) bool {
	return bits.A[i>>6]&(1<<(i&63)) == 0
}
func (t *ArrayDeque) BulkRemoveModified_Predicate_I__Z(filter Predicate, beg int32) bool {

	var es *RefArray = t.F_elements; var capacity int32 = int32(len(es.A)); var end int32 = t.F_tail; var deathRow *LongArray = ArrayDeque_NBits_I__J1(ArrayDeque_Sub_I_I_I__I(end, beg, capacity))



	deathRow.A[0] = 1
	var i int32 = beg + 1; var to int32
	if i <= end { to = end } else { to = int32(len(es.A)) }
//line :491:1
	var k int32 = beg


L1: for {
L2: for { if i < to {
	if filter.Test_O__Z(ArrayDeque_ElementAt_O1_I__O(es, i)) {
		ArrayDeque_SetBit_J1_I__V(deathRow, i-k) }
	i = i + 1
//line :495:1
	continue L2 }; break L2
}


	if to == end { break L1 }
	i = 0
	to = end
	k = k - capacity
//line :494:1
	continue L1
}







	var w int32 = beg; var i_2 int32 = beg + 1; var to_2 int32

	if i_2 <= end { to_2 = end } else { to_2 = int32(len(es.A)) }
//line :504:1
	var k_2 int32 = beg


L3: for {
L4: for { if i_2 < to_2 {
	if ArrayDeque_IsClear_J1_I__Z(deathRow, i_2-k_2) {
		es.Store(w, es.A[i_2])
		w = w + 1 }
	i_2 = i_2 + 1
//line :508:1
	continue L4 }; break L4
}



	if to_2 == end { break L3 }
	i_2 = 0
	to_2 = end
	k_2 = k_2 - capacity
L5: for { var tmp1 bool; var tmp2 bool; tmp2 = i_2 < to_2; if tmp2 { tmp2 = w < capacity }; tmp1 = tmp2; if tmp1 {
	if ArrayDeque_IsClear_J1_I__Z(deathRow, i_2-k_2) {
		es.Store(w, es.A[i_2])
		w = w + 1 }
	i_2 = i_2 + 1
//line :517:1
	continue L5 }; break L5
}



	if i_2 >= to_2 { if w == capacity { w = 0 }; break L3 }
	w = 0
//line :507:1
	continue L3
}















	if end == t.F_tail { } else { panic(Thrown(ConcurrentModificationException_New())) }
	var tmp3 int32; var tmp4 int32 = w; t.F_tail = tmp4; tmp3 = tmp4; ArrayDeque_CircularClear_O1_I_I__V(es, tmp3, end)
//line :503:1
	return true
}























func (t *ArrayDeque) Contains_O__Z(o any) bool {
	if !(o == nil) {
		var es *RefArray = t.F_elements; var i int32 = t.F_head; var end int32 = t.F_tail; var to int32


		if i <= end { to = end } else { to = int32(len(es.A)) }
	L1: for {
	L2: for { if i < to {
		if Equals(o, es.A[i]) { return true }
		i = i + 1
//line :535:1
		continue L2 }; break L2
	}

		if to == end { break L1 }
		i = 0
		to = end
//line :534:1
		continue L1 } }
//line :528:1
	return false
}













func (t *ArrayDeque) Remove_O__Z(o any) bool {
	return t.RemoveFirstOccurrence_O__Z(o)
}
func (t *ArrayDeque) Clear__V() {
	ArrayDeque_CircularClear_O1_I_I__V(t.F_elements, t.F_head, t.F_tail)
	var tmp1 int32; var tmp2 int32 = 0; t.F_tail = tmp2; tmp1 = tmp2; t.F_head = tmp1
}
func ArrayDeque_CircularClear_O1_I_I__V(es *RefArray, i, end int32) {
	var to int32; if i <= end { to = end } else { to = int32(len(es.A)) }
L1: for {
L2: for { if i < to { es.Store(i, nil); i = i + 1; continue L2 }; break L2 }
	if to == end { break L1 }
	i = 0
	to = end
//line :552:1
	continue L1
}
}



func (t *ArrayDeque) ToArray__O1() *RefArray { return t.ToArray_Class__O1(Object_class.ArrayClass()) }

func (t *ArrayDeque) ToArray_Class__O1(klazz *Class) *RefArray {
	var es *RefArray = t.F_elements; var a *RefArray; var head int32 = t.F_head; var tail int32 = t.F_tail; var end int32 = 0; var tmp1 int32; var tmp2 int32




	if head <= tail { tmp2 = 0 } else { tmp2 = int32(len(es.A)) }; end = tail + tmp2; tmp1 = end; if tmp1 >= 0 {
		a = Arrays_CopyOfRange_O1_I_I_Class__O1(es, head, end, klazz) } else {

			a = Arrays_CopyOfRange_O1_I_I_Class__O1(es, 0, end-head, klazz)
			System_Arraycopy_O_I_O_I_I__V(es.Ref(), head, a.Ref(), 0, int32(len(es.A))-head) }
	if end == tail { } else {
		System_Arraycopy_O_I_O_I_I__V(es.Ref(), 0, a.Ref(), int32(len(es.A))-head, tail) }
//line :561:1
	return a
}












func (t *ArrayDeque) ToArray_O1__O1(a *RefArray) *RefArray {
	var size int32 = 0; var tmp1 int32
	size = t.Size__I(); tmp1 = size; if tmp1 > int32(len(a.A)) {
		return t.ToArray_Class__O1(GetClass(a.Ref())) } else {
			var es *RefArray = t.F_elements; var i int32 = t.F_head; var j int32 = 0; var len_ int32 = Math_Min_I_I__I(size, int32(len(es.A))-i)



		L1: for {
			System_Arraycopy_O_I_O_I_I__V(es.Ref(), i, a.Ref(), j, len_)
			var tmp2 int32; j = j + len_; tmp2 = j; if tmp2 == size { break L1 }
			i = 0
			len_ = t.F_tail
//line :583:1
			continue L1
		}



			if size < int32(len(a.A)) { a.Store(size, nil) }
//line :579:1
			return a
		}
}









func (t *ArrayDeque) Clone__ArrayDeque() *ArrayDeque {
	var tmp1 *ArrayDeque; tmp3 := func() (exc Throwable_I) { defer Catch(&exc)
		{ var result *ArrayDeque = ArrayDeque_Cast(A2g_ObjectClone(t)); var tmp2 *RefArray = t.F_elements
			result.F_elements = Arrays_CopyOf_O1_I__O1(tmp2, int32(len(t.F_elements.A)))
//line :593:1
			tmp1 = result }
		return nil }()
//line :592:1
	if tmp3 != nil { if CloneNotSupportedException_InstanceOf(tmp3) { var e *CloneNotSupportedException = CloneNotSupportedException_Cast(tmp3); _ = e



		panic(Thrown(AssertionError_New())) } else {
//line :592:1
			panic(tmp3) } }; return tmp1
}
































func (t *ArrayDeque) CheckInvariants__V() { panic(A2g_NotTranslated("java.util.ArrayDeque.checkInvariants()V")) }



type ArrayDeque struct{ AbstractCollection; F_elements *RefArray; F_head, F_tail int32 }

func (t *ArrayDeque) Is_Deque() {}

func (t *ArrayDeque) Is_Cloneable() {}

func (t *ArrayDeque) Is_Serializable() {}

func (t *ArrayDeque) Is_Queue() {}

func (t *ArrayDeque) Is_SequencedCollection() {}

const ArrayDeque_MAX_ARRAY_SIZE int32 = 2147483639

const ArrayDeque_serialVersionUID int64 = 2340985798034038923

func (t *ArrayDeque) Clone__O() any { return t.Clone__ArrayDeque().Ref() }

func (t *ArrayDeque) Reversed__SequencedCollection() SequencedCollection { return Deque_Reversed__SequencedCollection(t) }

func (t *ArrayDeque) ToArray_IntFunction__O1(p0 IntFunction) *RefArray { return Collection_ToArray_IntFunction__O1(t, p0) }

func (t *ArrayDeque) Reversed__Deque() Deque { return Deque_Reversed__Deque(t) }

func (t *ArrayDeque) Stream__Stream() Stream { return Collection_Stream__Stream(t) }

func (t *ArrayDeque) ContainsAll_Collection__Z(p0 Collection) bool { return t.Impl_ContainsAll_Collection__Z(t, p0) }

func (t *ArrayDeque) ParallelStream__Stream() Stream { return Collection_ParallelStream__Stream(t) }

func (t *ArrayDeque) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ArrayDeque) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayDeque) GetClass__Class() *Class { return ArrayDeque_class }

func (t *ArrayDeque) CloneShallow() any { c := *t; (&c).ClearHeader(); return &c }

func ArrayDeque_InstanceOf(x any) bool { _, ok := x.(*ArrayDeque); return ok }

func ArrayDeque_Cast(x any) *ArrayDeque { if x == nil { return nil }; v, ok := x.(*ArrayDeque); if !ok { panic(ClassCast(x, ArrayDeque_class)) }; return v }



type ArrayDeque_DeqIterator struct{ Object; F_cursor, F_remaining, F_lastRet int32; F_this_0 *ArrayDeque }

type ArrayDeque_DeqIterator_I interface{ Object_I; Iterator; Self_ArrayDeque_DeqIterator() *ArrayDeque_DeqIterator; HasNext__Z() bool; Next__O() any; PostDelete_Z__V(p0 bool); Remove__V(); ForEachRemaining_Consumer__V(p0 Consumer) }

func (t *ArrayDeque_DeqIterator) Self_ArrayDeque_DeqIterator() *ArrayDeque_DeqIterator { return t }

func (t *ArrayDeque_DeqIterator) Is_Iterator() {}

func (t *ArrayDeque_DeqIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *ArrayDeque_DeqIterator) Next__O() any { return t.Impl_Next__O(t) }

func (t *ArrayDeque_DeqIterator) PostDelete_Z__V(p0 bool) { t.Impl_PostDelete_Z__V(t, p0) }

func (t *ArrayDeque_DeqIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *ArrayDeque_DeqIterator) ForEachRemaining_Consumer__V(p0 Consumer) { t.Impl_ForEachRemaining_Consumer__V(t, p0) }

func (t *ArrayDeque_DeqIterator) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayDeque_DeqIterator) GetClass__Class() *Class { return ArrayDeque_DeqIterator_class }

func (t *ArrayDeque_DeqIterator) ToString__String() *String { return Object_toString(t) }

func (t *ArrayDeque_DeqIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayDeque_DeqIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayDeque_DeqIterator_InstanceOf(x any) bool { _, ok := x.(ArrayDeque_DeqIterator_I); return ok }

func ArrayDeque_DeqIterator_Cast(x any) ArrayDeque_DeqIterator_I { if x == nil { return nil }; v, ok := x.(ArrayDeque_DeqIterator_I); if !ok { panic(ClassCast(x, ArrayDeque_DeqIterator_class)) }; return v }



type ArrayDeque_DeqSpliterator struct{ Object; F_fence, F_cursor int32; F_this_0 *ArrayDeque }

func (t *ArrayDeque_DeqSpliterator) Is_Spliterator() {}

func (t *ArrayDeque_DeqSpliterator) TrySplit__Spliterator() Spliterator { return Up_ArrayDeque_DeqSpliterator_Spliterator(t.TrySplit__ArrayDeque_DeqSpliterator()) }

func (t *ArrayDeque_DeqSpliterator) GetComparator__Comparator() Comparator { return Spliterator_GetComparator__Comparator(t) }

func (t *ArrayDeque_DeqSpliterator) HasCharacteristics_I__Z(p0 int32) bool { return Spliterator_HasCharacteristics_I__Z(t, p0) }

func (t *ArrayDeque_DeqSpliterator) GetExactSizeIfKnown__J() int64 { return Spliterator_GetExactSizeIfKnown__J(t) }

func (t *ArrayDeque_DeqSpliterator) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayDeque_DeqSpliterator) GetClass__Class() *Class { return ArrayDeque_DeqSpliterator_class }

func (t *ArrayDeque_DeqSpliterator) ToString__String() *String { return Object_toString(t) }

func (t *ArrayDeque_DeqSpliterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayDeque_DeqSpliterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayDeque_DeqSpliterator_InstanceOf(x any) bool { _, ok := x.(*ArrayDeque_DeqSpliterator); return ok }

func ArrayDeque_DeqSpliterator_Cast(x any) *ArrayDeque_DeqSpliterator { if x == nil { return nil }; v, ok := x.(*ArrayDeque_DeqSpliterator); if !ok { panic(ClassCast(x, ArrayDeque_DeqSpliterator_class)) }; return v }



type ArrayDeque_DescendingIterator struct{ ArrayDeque_DeqIterator; F_this_0 *ArrayDeque }

func (t *ArrayDeque_DescendingIterator) HasNext__Z() bool { return t.Impl_HasNext__Z(t) }

func (t *ArrayDeque_DescendingIterator) Remove__V() { t.Impl_Remove__V(t) }

func (t *ArrayDeque_DescendingIterator) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayDeque_DescendingIterator) GetClass__Class() *Class { return ArrayDeque_DescendingIterator_class }

func (t *ArrayDeque_DescendingIterator) ToString__String() *String { return Object_toString(t) }

func (t *ArrayDeque_DescendingIterator) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayDeque_DescendingIterator) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayDeque_DescendingIterator_InstanceOf(x any) bool { _, ok := x.(*ArrayDeque_DescendingIterator); return ok }

func ArrayDeque_DescendingIterator_Cast(x any) *ArrayDeque_DescendingIterator { if x == nil { return nil }; v, ok := x.(*ArrayDeque_DescendingIterator); if !ok { panic(ClassCast(x, ArrayDeque_DescendingIterator_class)) }; return v }
