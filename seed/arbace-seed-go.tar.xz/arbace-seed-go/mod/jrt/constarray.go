//line constarray.ae:1
package jrt











type constDecoder struct{ enc string; pos int; classes []*Class; holes []any }

func (d *constDecoder) num() int {
	n := 0
	for d.pos < len(d.enc) && d.enc[d.pos] >= '0' && d.enc[d.pos] <= '9' {
		n = n*10 + int(d.enc[d.pos]-'0')
		d.pos = d.pos + 1
	}
	d.pos = d.pos + 1
	return n
}
func (d *constDecoder) value() any {
	c := d.enc[d.pos]
	d.pos = d.pos + 1
	switch c {
	case 'n': return nil
	case 'h': return d.holes[d.num()]
	case 's': n := d.num()
		s := d.enc[d.pos : d.pos+n]
		d.pos = d.pos + n
		return Intern(s)
	case '[': cls := d.classes[d.num()]
		n := d.num()
		a := make([]any, n)
		for i := 0; i < n; i++ {
			a[i] = d.value() }
		return &RefArray{Comp: cls, A: a}}
	panic("ConstRefArray: bad encoding") }
// ConstRefArray is a constant reference array initializer, encoded (above): classes are the
// component classes its arrays name by index, holes the locals it holds.
//line :42:1
func ConstRefArray(enc string, classes /*line :45:1*/[]*Class, holes ...any) *RefArray {
	d := &constDecoder{enc: enc, classes: classes, holes: holes}
	return d.value().(*RefArray)
}
