//line java_lang_ArrayStoreException.ae:1
package jrt








func ArrayStoreException_New() *ArrayStoreException { t := &ArrayStoreException{}; t.Ctor(); return t }
//line :10:1
func (t *ArrayStoreException) Ctor() { t.RuntimeException.Ctor(t) }

func ArrayStoreException_New_String(p0 *String) *ArrayStoreException { t := &ArrayStoreException{}; t.Ctor_String(p0); return t }
//line :12:1
func (t *ArrayStoreException) Ctor_String(s *String) { t.RuntimeException.Ctor_String(t, s) }







type ArrayStoreException struct{ RuntimeException }

const ArrayStoreException_serialVersionUID int64 = -4522193890499838241

func (t *ArrayStoreException) GetStackTrace__StackTraceElement1() *RefArray { return t.Impl_GetStackTrace__StackTraceElement1(t) }

func (t *ArrayStoreException) InitCause_Throwable__Throwable(p0 Throwable_I) Throwable_I { return t.Impl_InitCause_Throwable__Throwable(t, p0) }

func (t *ArrayStoreException) GetMessage__String() *String { return t.Impl_GetMessage__String(t) }

func (t *ArrayStoreException) SetStackTrace_StackTraceElement1__V(p0 *RefArray) { t.Impl_SetStackTrace_StackTraceElement1__V(t, p0) }

func (t *ArrayStoreException) GetLocalizedMessage__String() *String { return t.Impl_GetLocalizedMessage__String(t) }

func (t *ArrayStoreException) GetCause__Throwable() Throwable_I { return t.Impl_GetCause__Throwable(t) }

func (t *ArrayStoreException) AddSuppressed_Throwable__V(p0 Throwable_I) { t.Impl_AddSuppressed_Throwable__V(t, p0) }

func (t *ArrayStoreException) PrintStackTrace__V() { t.Impl_PrintStackTrace__V(t) }

func (t *ArrayStoreException) FillInStackTrace__Throwable() Throwable_I { return t.Impl_FillInStackTrace__Throwable(t) }

func (t *ArrayStoreException) GetSuppressed__Throwable1() *RefArray { return t.Impl_GetSuppressed__Throwable1(t) }

func (t *ArrayStoreException) SetCause_Throwable__V(p0 Throwable_I) { t.Impl_SetCause_Throwable__V(t, p0) }

func (t *ArrayStoreException) ToString__String() *String { return t.Impl_ToString__String(t) }

func (t *ArrayStoreException) Ref() any { if t == nil { return nil }; return t }

func (t *ArrayStoreException) GetClass__Class() *Class { return ArrayStoreException_class }

func (t *ArrayStoreException) Clone__O() any { return A2g_ObjectClone(t) }

func (t *ArrayStoreException) CloneShallow() any { panic(CloneNotSupported(t)) }

func ArrayStoreException_InstanceOf(x any) bool { _, ok := x.(*ArrayStoreException); return ok }

func ArrayStoreException_Cast(x any) *ArrayStoreException { if x == nil { return nil }; v, ok := x.(*ArrayStoreException); if !ok { panic(ClassCast(x, ArrayStoreException_class)) }; return v }
