//line a2g_classes.ae:1
package aot_arbace_walk

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_class, Name: "arbace.walk$eval1869000004$loading__1927001464__auto____1869000005", Modifiers: 25, Simple: "loading__1927001464__auto____1869000005", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A", Source: "walk.ae", Declaring: &A_arbace_walk_eval1869000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_walk_eval1869000008_fn__1869000009_A_class, Name: "arbace.walk$eval1869000008$fn__1869000009", Modifiers: 25, Simple: "fn__1869000009", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000008_fn__1869000009_A", Source: "walk.ae", Declaring: &A_arbace_walk_eval1869000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_walk_keywordize_keys_A_class, Name: "arbace.walk$keywordize_keys", Modifiers: 25, Simple: "keywordize_keys", Go: "arbace/aot_arbace_walk.A_arbace_walk_keywordize_keys_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_keywordize_keys_fn__1869000032_A_class, Name: "arbace.walk$keywordize_keys$fn__1869000032", Modifiers: 25, Simple: "fn__1869000032", Go: "arbace/aot_arbace_walk.A_arbace_walk_keywordize_keys_fn__1869000032_A", Source: "walk.ae", Declaring: &A_arbace_walk_keywordize_keys_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_macroexpand_all_A_class, Name: "arbace.walk$macroexpand_all", Modifiers: 25, Simple: "macroexpand_all", Go: "arbace/aot_arbace_walk.A_arbace_walk_macroexpand_all_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_macroexpand_all_fn__1869000044_A_class, Name: "arbace.walk$macroexpand_all$fn__1869000044", Modifiers: 25, Simple: "fn__1869000044", Go: "arbace/aot_arbace_walk.A_arbace_walk_macroexpand_all_fn__1869000044_A", Source: "walk.ae", Declaring: &A_arbace_walk_macroexpand_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_postwalk_A_class, Name: "arbace.walk$postwalk", Modifiers: 25, Simple: "postwalk", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_walk_postwalk_demo_A_class, Name: "arbace.walk$postwalk_demo", Modifiers: 25, Simple: "postwalk_demo", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_demo_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_postwalk_demo_fn__1869000017_A_class, Name: "arbace.walk$postwalk_demo$fn__1869000017", Modifiers: 25, Simple: "fn__1869000017", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_demo_fn__1869000017_A", Source: "walk.ae", Declaring: &A_arbace_walk_postwalk_demo_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_postwalk_replace_A_class, Name: "arbace.walk$postwalk_replace", Modifiers: 25, Simple: "postwalk_replace", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_replace_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_walk_postwalk_replace_fn__1869000041_A_class, Name: "arbace.walk$postwalk_replace$fn__1869000041", Modifiers: 25, Simple: "fn__1869000041", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_replace_fn__1869000041_A", Source: "walk.ae", Declaring: &A_arbace_walk_postwalk_replace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_prewalk_A_class, Name: "arbace.walk$prewalk", Modifiers: 25, Simple: "prewalk", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_walk_prewalk_demo_A_class, Name: "arbace.walk$prewalk_demo", Modifiers: 25, Simple: "prewalk_demo", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_demo_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_prewalk_demo_fn__1869000020_A_class, Name: "arbace.walk$prewalk_demo$fn__1869000020", Modifiers: 25, Simple: "fn__1869000020", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_demo_fn__1869000020_A", Source: "walk.ae", Declaring: &A_arbace_walk_prewalk_demo_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_prewalk_replace_A_class, Name: "arbace.walk$prewalk_replace", Modifiers: 25, Simple: "prewalk_replace", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_replace_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_walk_prewalk_replace_fn__1869000038_A_class, Name: "arbace.walk$prewalk_replace$fn__1869000038", Modifiers: 25, Simple: "fn__1869000038", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_replace_fn__1869000038_A", Source: "walk.ae", Declaring: &A_arbace_walk_prewalk_replace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_stringify_keys_A_class, Name: "arbace.walk$stringify_keys", Modifiers: 25, Simple: "stringify_keys", Go: "arbace/aot_arbace_walk.A_arbace_walk_stringify_keys_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_stringify_keys_fn__1869000035_A_class, Name: "arbace.walk$stringify_keys$fn__1869000035", Modifiers: 25, Simple: "fn__1869000035", Go: "arbace/aot_arbace_walk.A_arbace_walk_stringify_keys_fn__1869000035_A", Source: "walk.ae", Declaring: &A_arbace_walk_stringify_keys_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_transform_keys_A_class, Name: "arbace.walk$transform_keys", Modifiers: 25, Simple: "transform_keys", Go: "arbace/aot_arbace_walk.A_arbace_walk_transform_keys_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_walk_transform_keys_entry_f__1869000024_A_class, Name: "arbace.walk$transform_keys$entry_f__1869000024", Modifiers: 25, Simple: "entry_f__1869000024", Go: "arbace/aot_arbace_walk.A_arbace_walk_transform_keys_entry_f__1869000024_A", Source: "walk.ae", Declaring: &A_arbace_walk_transform_keys_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_transform_keys_fn__1869000029_A_class, Name: "arbace.walk$transform_keys$fn__1869000029", Modifiers: 25, Simple: "fn__1869000029", Go: "arbace/aot_arbace_walk.A_arbace_walk_transform_keys_fn__1869000029_A", Source: "walk.ae", Declaring: &A_arbace_walk_transform_keys_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_walk_walk_A_class, Name: "arbace.walk$walk", Modifiers: 25, Simple: "walk", Go: "arbace/aot_arbace_walk.A_arbace_walk_walk_A", Source: "walk.ae", Declaring: &A_arbace_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_walk_walk_fn__1869000012_A_class, Name: "arbace.walk$walk$fn__1869000012", Modifiers: 25, Simple: "fn__1869000012", Go: "arbace/aot_arbace_walk.A_arbace_walk_walk_fn__1869000012_A", Source: "walk.ae", Declaring: &A_arbace_walk_walk_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_walk_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_A_New()}; return nil }

var A_arbace_walk_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_walk_A_new}

var A_arbace_walk_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_walk.A_arbace_walk_A"})

func init() { i := A_arbace_walk_A_class.Info(); i.IsInstance = A_arbace_walk_A_InstanceOf; i.Init = A_arbace_walk_A_Init; i.Table = A_arbace_walk_A_members }

func A_arbace_walk_eval1869000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_eval1869000004_A_New()}; return nil }

var A_arbace_walk_eval1869000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_walk_eval1869000004_A_new}

var A_arbace_walk_eval1869000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$eval1869000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_walk_A_class, Simple: "eval1869000004", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000004_A"})

func init() { i := A_arbace_walk_eval1869000004_A_class.Info(); i.IsInstance = A_arbace_walk_eval1869000004_A_InstanceOf; i.Table = A_arbace_walk_eval1869000004_A_members }

var A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_class *jrt.Class

func A_arbace_walk_eval1869000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_eval1869000008_A_New()}; return nil }

var A_arbace_walk_eval1869000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_walk_eval1869000008_A_new}

var A_arbace_walk_eval1869000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$eval1869000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_walk_A_class, Simple: "eval1869000008", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000008_A"})

func init() { i := A_arbace_walk_eval1869000008_A_class.Info(); i.IsInstance = A_arbace_walk_eval1869000008_A_InstanceOf; i.Table = A_arbace_walk_eval1869000008_A_members }

var A_arbace_walk_eval1869000008_fn__1869000009_A_class *jrt.Class

var A_arbace_walk_keywordize_keys_A_class *jrt.Class

var A_arbace_walk_keywordize_keys_fn__1869000032_A_class *jrt.Class

var A_arbace_walk_macroexpand_all_A_class *jrt.Class

var A_arbace_walk_macroexpand_all_fn__1869000044_A_class *jrt.Class

var A_arbace_walk_postwalk_A_class *jrt.Class

var A_arbace_walk_postwalk_demo_A_class *jrt.Class

var A_arbace_walk_postwalk_demo_fn__1869000017_A_class *jrt.Class

var A_arbace_walk_postwalk_replace_A_class *jrt.Class

var A_arbace_walk_postwalk_replace_fn__1869000041_A_class *jrt.Class

var A_arbace_walk_prewalk_A_class *jrt.Class

var A_arbace_walk_prewalk_demo_A_class *jrt.Class

var A_arbace_walk_prewalk_demo_fn__1869000020_A_class *jrt.Class

var A_arbace_walk_prewalk_replace_A_class *jrt.Class

var A_arbace_walk_prewalk_replace_fn__1869000038_A_class *jrt.Class

var A_arbace_walk_stringify_keys_A_class *jrt.Class

var A_arbace_walk_stringify_keys_fn__1869000035_A_class *jrt.Class

var A_arbace_walk_transform_keys_A_class *jrt.Class

var A_arbace_walk_transform_keys_entry_f__1869000024_A_class *jrt.Class

var A_arbace_walk_transform_keys_fn__1869000029_A_class *jrt.Class

var A_arbace_walk_walk_A_class *jrt.Class

var A_arbace_walk_walk_fn__1869000012_A_class *jrt.Class

func A_arbace_walk__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_walk__init_A_Load__O()}; return nil }

func A_arbace_walk__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk__init_A_New()}; return nil }

var A_arbace_walk__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_walk__init_A_invoke, New: A_arbace_walk__init_A_new}

var A_arbace_walk__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_walk.A_arbace_walk__init_A", Source: "walk.ae"})

func init() { i := A_arbace_walk__init_A_class.Info(); i.IsInstance = A_arbace_walk__init_A_InstanceOf; i.Init = A_arbace_walk__init_A_Init; i.Table = A_arbace_walk__init_A_members }
