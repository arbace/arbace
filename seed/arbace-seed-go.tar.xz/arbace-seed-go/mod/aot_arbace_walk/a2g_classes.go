//line a2g_classes.ae:1
package aot_arbace_walk

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_walk_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_A_New()}; return nil }

var A_arbace_walk_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_walk_A_new}

var A_arbace_walk_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_walk.A_arbace_walk_A"})

func init() { i := A_arbace_walk_A_class.Info(); i.IsInstance = A_arbace_walk_A_InstanceOf; i.Init = A_arbace_walk_A_Init; i.Table = A_arbace_walk_A_members; jrt.RegisterGoType(A_arbace_walk_A_class, reflect.TypeFor[A_arbace_walk_A]()) }

func A_arbace_walk_eval1869000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_eval1869000004_A_New()}; return nil }

var A_arbace_walk_eval1869000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_walk_eval1869000004_A_new}

var A_arbace_walk_eval1869000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$eval1869000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_walk_A_class, Simple: "eval1869000004", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000004_A"})

func init() { i := A_arbace_walk_eval1869000004_A_class.Info(); i.IsInstance = A_arbace_walk_eval1869000004_A_InstanceOf; i.Table = A_arbace_walk_eval1869000004_A_members; jrt.RegisterGoType(A_arbace_walk_eval1869000004_A_class, reflect.TypeFor[A_arbace_walk_eval1869000004_A]()) }

func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_New()}; return nil }

func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_fn_class)}; return nil }

var A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_invoke, New: A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_new, Get: A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_get}

var A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$eval1869000004$loading__1927001464__auto____1869000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_walk_eval1869000004_A_class, Simple: "loading__1927001464__auto____1869000005", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_class.Info(); i.IsInstance = A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_InstanceOf; i.Init = A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_Init; i.Table = A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_members; jrt.RegisterGoType(A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_class, reflect.TypeFor[A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A]()) }

func A_arbace_walk_eval1869000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_eval1869000008_A_New()}; return nil }

var A_arbace_walk_eval1869000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_walk_eval1869000008_A_new}

var A_arbace_walk_eval1869000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$eval1869000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_walk_A_class, Simple: "eval1869000008", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000008_A"})

func init() { i := A_arbace_walk_eval1869000008_A_class.Info(); i.IsInstance = A_arbace_walk_eval1869000008_A_InstanceOf; i.Table = A_arbace_walk_eval1869000008_A_members; jrt.RegisterGoType(A_arbace_walk_eval1869000008_A_class, reflect.TypeFor[A_arbace_walk_eval1869000008_A]()) }

func A_arbace_walk_eval1869000008_fn__1869000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_eval1869000008_fn__1869000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_walk_eval1869000008_fn__1869000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_eval1869000008_fn__1869000009_A_New()}; return nil }

func A_arbace_walk_eval1869000008_fn__1869000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_eval1869000008_fn__1869000009_A_fn_class)}; return nil }

var A_arbace_walk_eval1869000008_fn__1869000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_eval1869000008_fn__1869000009_A_invoke, New: A_arbace_walk_eval1869000008_fn__1869000009_A_new, Get: A_arbace_walk_eval1869000008_fn__1869000009_A_get}

var A_arbace_walk_eval1869000008_fn__1869000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$eval1869000008$fn__1869000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_walk_eval1869000008_A_class, Simple: "fn__1869000009", Go: "arbace/aot_arbace_walk.A_arbace_walk_eval1869000008_fn__1869000009_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_eval1869000008_fn__1869000009_A_class.Info(); i.IsInstance = A_arbace_walk_eval1869000008_fn__1869000009_A_InstanceOf; i.Init = A_arbace_walk_eval1869000008_fn__1869000009_A_Init; i.Table = A_arbace_walk_eval1869000008_fn__1869000009_A_members; jrt.RegisterGoType(A_arbace_walk_eval1869000008_fn__1869000009_A_class, reflect.TypeFor[A_arbace_walk_eval1869000008_fn__1869000009_A]()) }

func A_arbace_walk_keywordize_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_keywordize_keys_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_keywordize_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_keywordize_keys_A_New()}; return nil }

func A_arbace_walk_keywordize_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_keywordize_keys_A_fn_class)}; return nil }

var A_arbace_walk_keywordize_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_keywordize_keys_A_invoke, New: A_arbace_walk_keywordize_keys_A_new, Get: A_arbace_walk_keywordize_keys_A_get}

var A_arbace_walk_keywordize_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$keywordize_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_A_class, Simple: "keywordize_keys", Go: "arbace/aot_arbace_walk.A_arbace_walk_keywordize_keys_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_keywordize_keys_A_class.Info(); i.IsInstance = A_arbace_walk_keywordize_keys_A_InstanceOf; i.Init = A_arbace_walk_keywordize_keys_A_Init; i.Table = A_arbace_walk_keywordize_keys_A_members; jrt.RegisterGoType(A_arbace_walk_keywordize_keys_A_class, reflect.TypeFor[A_arbace_walk_keywordize_keys_A]()) }

func A_arbace_walk_keywordize_keys_fn__1869000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_keywordize_keys_fn__1869000032_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_keywordize_keys_fn__1869000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_keywordize_keys_fn__1869000032_A_New()}; return nil }

func A_arbace_walk_keywordize_keys_fn__1869000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class)}; return nil }

var A_arbace_walk_keywordize_keys_fn__1869000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_keywordize_keys_fn__1869000032_A_invoke, New: A_arbace_walk_keywordize_keys_fn__1869000032_A_new, Get: A_arbace_walk_keywordize_keys_fn__1869000032_A_get}

var A_arbace_walk_keywordize_keys_fn__1869000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$keywordize_keys$fn__1869000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_keywordize_keys_A_class, Simple: "fn__1869000032", Go: "arbace/aot_arbace_walk.A_arbace_walk_keywordize_keys_fn__1869000032_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_keywordize_keys_fn__1869000032_A_class.Info(); i.IsInstance = A_arbace_walk_keywordize_keys_fn__1869000032_A_InstanceOf; i.Init = A_arbace_walk_keywordize_keys_fn__1869000032_A_Init; i.Table = A_arbace_walk_keywordize_keys_fn__1869000032_A_members; jrt.RegisterGoType(A_arbace_walk_keywordize_keys_fn__1869000032_A_class, reflect.TypeFor[A_arbace_walk_keywordize_keys_fn__1869000032_A]()) }

func A_arbace_walk_macroexpand_all_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_macroexpand_all_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_macroexpand_all_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_macroexpand_all_A_New()}; return nil }

func A_arbace_walk_macroexpand_all_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_macroexpand_all_A_fn_class)}; return nil }

var A_arbace_walk_macroexpand_all_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_macroexpand_all_A_invoke, New: A_arbace_walk_macroexpand_all_A_new, Get: A_arbace_walk_macroexpand_all_A_get}

var A_arbace_walk_macroexpand_all_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$macroexpand_all", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_A_class, Simple: "macroexpand_all", Go: "arbace/aot_arbace_walk.A_arbace_walk_macroexpand_all_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_macroexpand_all_A_class.Info(); i.IsInstance = A_arbace_walk_macroexpand_all_A_InstanceOf; i.Init = A_arbace_walk_macroexpand_all_A_Init; i.Table = A_arbace_walk_macroexpand_all_A_members; jrt.RegisterGoType(A_arbace_walk_macroexpand_all_A_class, reflect.TypeFor[A_arbace_walk_macroexpand_all_A]()) }

func A_arbace_walk_macroexpand_all_fn__1869000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_macroexpand_all_fn__1869000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_macroexpand_all_fn__1869000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_macroexpand_all_fn__1869000044_A_New()}; return nil }

func A_arbace_walk_macroexpand_all_fn__1869000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class)}; return nil }

var A_arbace_walk_macroexpand_all_fn__1869000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_macroexpand_all_fn__1869000044_A_invoke, New: A_arbace_walk_macroexpand_all_fn__1869000044_A_new, Get: A_arbace_walk_macroexpand_all_fn__1869000044_A_get}

var A_arbace_walk_macroexpand_all_fn__1869000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$macroexpand_all$fn__1869000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_macroexpand_all_A_class, Simple: "fn__1869000044", Go: "arbace/aot_arbace_walk.A_arbace_walk_macroexpand_all_fn__1869000044_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_macroexpand_all_fn__1869000044_A_class.Info(); i.IsInstance = A_arbace_walk_macroexpand_all_fn__1869000044_A_InstanceOf; i.Init = A_arbace_walk_macroexpand_all_fn__1869000044_A_Init; i.Table = A_arbace_walk_macroexpand_all_fn__1869000044_A_members; jrt.RegisterGoType(A_arbace_walk_macroexpand_all_fn__1869000044_A_class, reflect.TypeFor[A_arbace_walk_macroexpand_all_fn__1869000044_A]()) }

func A_arbace_walk_postwalk_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_postwalk_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_walk_postwalk_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_postwalk_A_New()}; return nil }

func A_arbace_walk_postwalk_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_postwalk_A_fn_class)}; return nil }

var A_arbace_walk_postwalk_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_postwalk_A_invoke, New: A_arbace_walk_postwalk_A_new, Get: A_arbace_walk_postwalk_A_get}

var A_arbace_walk_postwalk_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$postwalk", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_walk_A_class, Simple: "postwalk", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_postwalk_A_class.Info(); i.IsInstance = A_arbace_walk_postwalk_A_InstanceOf; i.Init = A_arbace_walk_postwalk_A_Init; i.Table = A_arbace_walk_postwalk_A_members; jrt.RegisterGoType(A_arbace_walk_postwalk_A_class, reflect.TypeFor[A_arbace_walk_postwalk_A]()) }

func A_arbace_walk_postwalk_demo_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_postwalk_demo_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_postwalk_demo_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_postwalk_demo_A_New()}; return nil }

func A_arbace_walk_postwalk_demo_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_postwalk_demo_A_fn_class)}; return nil }

var A_arbace_walk_postwalk_demo_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_postwalk_demo_A_invoke, New: A_arbace_walk_postwalk_demo_A_new, Get: A_arbace_walk_postwalk_demo_A_get}

var A_arbace_walk_postwalk_demo_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$postwalk_demo", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_A_class, Simple: "postwalk_demo", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_demo_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_postwalk_demo_A_class.Info(); i.IsInstance = A_arbace_walk_postwalk_demo_A_InstanceOf; i.Init = A_arbace_walk_postwalk_demo_A_Init; i.Table = A_arbace_walk_postwalk_demo_A_members; jrt.RegisterGoType(A_arbace_walk_postwalk_demo_A_class, reflect.TypeFor[A_arbace_walk_postwalk_demo_A]()) }

func A_arbace_walk_postwalk_demo_fn__1869000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_postwalk_demo_fn__1869000017_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_postwalk_demo_fn__1869000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_postwalk_demo_fn__1869000017_A_New()}; return nil }

func A_arbace_walk_postwalk_demo_fn__1869000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class)}; return nil }

var A_arbace_walk_postwalk_demo_fn__1869000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_postwalk_demo_fn__1869000017_A_invoke, New: A_arbace_walk_postwalk_demo_fn__1869000017_A_new, Get: A_arbace_walk_postwalk_demo_fn__1869000017_A_get}

var A_arbace_walk_postwalk_demo_fn__1869000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$postwalk_demo$fn__1869000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_postwalk_demo_A_class, Simple: "fn__1869000017", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_demo_fn__1869000017_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_postwalk_demo_fn__1869000017_A_class.Info(); i.IsInstance = A_arbace_walk_postwalk_demo_fn__1869000017_A_InstanceOf; i.Init = A_arbace_walk_postwalk_demo_fn__1869000017_A_Init; i.Table = A_arbace_walk_postwalk_demo_fn__1869000017_A_members; jrt.RegisterGoType(A_arbace_walk_postwalk_demo_fn__1869000017_A_class, reflect.TypeFor[A_arbace_walk_postwalk_demo_fn__1869000017_A]()) }

func A_arbace_walk_postwalk_replace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_postwalk_replace_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_walk_postwalk_replace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_postwalk_replace_A_New()}; return nil }

func A_arbace_walk_postwalk_replace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_postwalk_replace_A_fn_class)}; return nil }

var A_arbace_walk_postwalk_replace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_postwalk_replace_A_invoke, New: A_arbace_walk_postwalk_replace_A_new, Get: A_arbace_walk_postwalk_replace_A_get}

var A_arbace_walk_postwalk_replace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$postwalk_replace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_walk_A_class, Simple: "postwalk_replace", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_replace_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_postwalk_replace_A_class.Info(); i.IsInstance = A_arbace_walk_postwalk_replace_A_InstanceOf; i.Init = A_arbace_walk_postwalk_replace_A_Init; i.Table = A_arbace_walk_postwalk_replace_A_members; jrt.RegisterGoType(A_arbace_walk_postwalk_replace_A_class, reflect.TypeFor[A_arbace_walk_postwalk_replace_A]()) }

func A_arbace_walk_postwalk_replace_fn__1869000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_postwalk_replace_fn__1869000041_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_postwalk_replace_fn__1869000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_postwalk_replace_fn__1869000041_A_New_O(args[0])}; return nil }

func A_arbace_walk_postwalk_replace_fn__1869000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class)}; return nil }

var A_arbace_walk_postwalk_replace_fn__1869000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_postwalk_replace_fn__1869000041_A_invoke, New: A_arbace_walk_postwalk_replace_fn__1869000041_A_new, Get: A_arbace_walk_postwalk_replace_fn__1869000041_A_get}

var A_arbace_walk_postwalk_replace_fn__1869000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$postwalk_replace$fn__1869000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_postwalk_replace_A_class, Simple: "fn__1869000041", Go: "arbace/aot_arbace_walk.A_arbace_walk_postwalk_replace_fn__1869000041_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_postwalk_replace_fn__1869000041_A_class.Info(); i.IsInstance = A_arbace_walk_postwalk_replace_fn__1869000041_A_InstanceOf; i.Init = A_arbace_walk_postwalk_replace_fn__1869000041_A_Init; i.Table = A_arbace_walk_postwalk_replace_fn__1869000041_A_members; jrt.RegisterGoType(A_arbace_walk_postwalk_replace_fn__1869000041_A_class, reflect.TypeFor[A_arbace_walk_postwalk_replace_fn__1869000041_A]()) }

func A_arbace_walk_prewalk_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_prewalk_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_walk_prewalk_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_prewalk_A_New()}; return nil }

func A_arbace_walk_prewalk_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_prewalk_A_fn_class)}; return nil }

var A_arbace_walk_prewalk_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_prewalk_A_invoke, New: A_arbace_walk_prewalk_A_new, Get: A_arbace_walk_prewalk_A_get}

var A_arbace_walk_prewalk_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$prewalk", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_walk_A_class, Simple: "prewalk", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_prewalk_A_class.Info(); i.IsInstance = A_arbace_walk_prewalk_A_InstanceOf; i.Init = A_arbace_walk_prewalk_A_Init; i.Table = A_arbace_walk_prewalk_A_members; jrt.RegisterGoType(A_arbace_walk_prewalk_A_class, reflect.TypeFor[A_arbace_walk_prewalk_A]()) }

func A_arbace_walk_prewalk_demo_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_prewalk_demo_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_prewalk_demo_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_prewalk_demo_A_New()}; return nil }

func A_arbace_walk_prewalk_demo_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_prewalk_demo_A_fn_class)}; return nil }

var A_arbace_walk_prewalk_demo_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_prewalk_demo_A_invoke, New: A_arbace_walk_prewalk_demo_A_new, Get: A_arbace_walk_prewalk_demo_A_get}

var A_arbace_walk_prewalk_demo_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$prewalk_demo", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_A_class, Simple: "prewalk_demo", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_demo_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_prewalk_demo_A_class.Info(); i.IsInstance = A_arbace_walk_prewalk_demo_A_InstanceOf; i.Init = A_arbace_walk_prewalk_demo_A_Init; i.Table = A_arbace_walk_prewalk_demo_A_members; jrt.RegisterGoType(A_arbace_walk_prewalk_demo_A_class, reflect.TypeFor[A_arbace_walk_prewalk_demo_A]()) }

func A_arbace_walk_prewalk_demo_fn__1869000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_prewalk_demo_fn__1869000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_prewalk_demo_fn__1869000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_prewalk_demo_fn__1869000020_A_New()}; return nil }

func A_arbace_walk_prewalk_demo_fn__1869000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class)}; return nil }

var A_arbace_walk_prewalk_demo_fn__1869000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_prewalk_demo_fn__1869000020_A_invoke, New: A_arbace_walk_prewalk_demo_fn__1869000020_A_new, Get: A_arbace_walk_prewalk_demo_fn__1869000020_A_get}

var A_arbace_walk_prewalk_demo_fn__1869000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$prewalk_demo$fn__1869000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_prewalk_demo_A_class, Simple: "fn__1869000020", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_demo_fn__1869000020_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_prewalk_demo_fn__1869000020_A_class.Info(); i.IsInstance = A_arbace_walk_prewalk_demo_fn__1869000020_A_InstanceOf; i.Init = A_arbace_walk_prewalk_demo_fn__1869000020_A_Init; i.Table = A_arbace_walk_prewalk_demo_fn__1869000020_A_members; jrt.RegisterGoType(A_arbace_walk_prewalk_demo_fn__1869000020_A_class, reflect.TypeFor[A_arbace_walk_prewalk_demo_fn__1869000020_A]()) }

func A_arbace_walk_prewalk_replace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_prewalk_replace_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_walk_prewalk_replace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_prewalk_replace_A_New()}; return nil }

func A_arbace_walk_prewalk_replace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_prewalk_replace_A_fn_class)}; return nil }

var A_arbace_walk_prewalk_replace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_prewalk_replace_A_invoke, New: A_arbace_walk_prewalk_replace_A_new, Get: A_arbace_walk_prewalk_replace_A_get}

var A_arbace_walk_prewalk_replace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$prewalk_replace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_walk_A_class, Simple: "prewalk_replace", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_replace_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_prewalk_replace_A_class.Info(); i.IsInstance = A_arbace_walk_prewalk_replace_A_InstanceOf; i.Init = A_arbace_walk_prewalk_replace_A_Init; i.Table = A_arbace_walk_prewalk_replace_A_members; jrt.RegisterGoType(A_arbace_walk_prewalk_replace_A_class, reflect.TypeFor[A_arbace_walk_prewalk_replace_A]()) }

func A_arbace_walk_prewalk_replace_fn__1869000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_prewalk_replace_fn__1869000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_prewalk_replace_fn__1869000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_prewalk_replace_fn__1869000038_A_New_O(args[0])}; return nil }

func A_arbace_walk_prewalk_replace_fn__1869000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class)}; return nil }

var A_arbace_walk_prewalk_replace_fn__1869000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_prewalk_replace_fn__1869000038_A_invoke, New: A_arbace_walk_prewalk_replace_fn__1869000038_A_new, Get: A_arbace_walk_prewalk_replace_fn__1869000038_A_get}

var A_arbace_walk_prewalk_replace_fn__1869000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$prewalk_replace$fn__1869000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_prewalk_replace_A_class, Simple: "fn__1869000038", Go: "arbace/aot_arbace_walk.A_arbace_walk_prewalk_replace_fn__1869000038_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_prewalk_replace_fn__1869000038_A_class.Info(); i.IsInstance = A_arbace_walk_prewalk_replace_fn__1869000038_A_InstanceOf; i.Init = A_arbace_walk_prewalk_replace_fn__1869000038_A_Init; i.Table = A_arbace_walk_prewalk_replace_fn__1869000038_A_members; jrt.RegisterGoType(A_arbace_walk_prewalk_replace_fn__1869000038_A_class, reflect.TypeFor[A_arbace_walk_prewalk_replace_fn__1869000038_A]()) }

func A_arbace_walk_stringify_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_stringify_keys_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_stringify_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_stringify_keys_A_New()}; return nil }

func A_arbace_walk_stringify_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_stringify_keys_A_fn_class)}; return nil }

var A_arbace_walk_stringify_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_stringify_keys_A_invoke, New: A_arbace_walk_stringify_keys_A_new, Get: A_arbace_walk_stringify_keys_A_get}

var A_arbace_walk_stringify_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$stringify_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_A_class, Simple: "stringify_keys", Go: "arbace/aot_arbace_walk.A_arbace_walk_stringify_keys_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_stringify_keys_A_class.Info(); i.IsInstance = A_arbace_walk_stringify_keys_A_InstanceOf; i.Init = A_arbace_walk_stringify_keys_A_Init; i.Table = A_arbace_walk_stringify_keys_A_members; jrt.RegisterGoType(A_arbace_walk_stringify_keys_A_class, reflect.TypeFor[A_arbace_walk_stringify_keys_A]()) }

func A_arbace_walk_stringify_keys_fn__1869000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_stringify_keys_fn__1869000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_stringify_keys_fn__1869000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_stringify_keys_fn__1869000035_A_New()}; return nil }

func A_arbace_walk_stringify_keys_fn__1869000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class)}; return nil }

var A_arbace_walk_stringify_keys_fn__1869000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_stringify_keys_fn__1869000035_A_invoke, New: A_arbace_walk_stringify_keys_fn__1869000035_A_new, Get: A_arbace_walk_stringify_keys_fn__1869000035_A_get}

var A_arbace_walk_stringify_keys_fn__1869000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$stringify_keys$fn__1869000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_stringify_keys_A_class, Simple: "fn__1869000035", Go: "arbace/aot_arbace_walk.A_arbace_walk_stringify_keys_fn__1869000035_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_stringify_keys_fn__1869000035_A_class.Info(); i.IsInstance = A_arbace_walk_stringify_keys_fn__1869000035_A_InstanceOf; i.Init = A_arbace_walk_stringify_keys_fn__1869000035_A_Init; i.Table = A_arbace_walk_stringify_keys_fn__1869000035_A_members; jrt.RegisterGoType(A_arbace_walk_stringify_keys_fn__1869000035_A_class, reflect.TypeFor[A_arbace_walk_stringify_keys_fn__1869000035_A]()) }

func A_arbace_walk_transform_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_transform_keys_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_walk_transform_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_transform_keys_A_New()}; return nil }

func A_arbace_walk_transform_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_transform_keys_A_fn_class)}; return nil }

var A_arbace_walk_transform_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_transform_keys_A_invoke, New: A_arbace_walk_transform_keys_A_new, Get: A_arbace_walk_transform_keys_A_get}

var A_arbace_walk_transform_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$transform_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_walk_A_class, Simple: "transform_keys", Go: "arbace/aot_arbace_walk.A_arbace_walk_transform_keys_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_transform_keys_A_class.Info(); i.IsInstance = A_arbace_walk_transform_keys_A_InstanceOf; i.Init = A_arbace_walk_transform_keys_A_Init; i.Table = A_arbace_walk_transform_keys_A_members; jrt.RegisterGoType(A_arbace_walk_transform_keys_A_class, reflect.TypeFor[A_arbace_walk_transform_keys_A]()) }

func A_arbace_walk_transform_keys_entry_f__1869000024_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_transform_keys_entry_f__1869000024_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_transform_keys_entry_f__1869000024_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_transform_keys_entry_f__1869000024_A_New_O(args[0])}; return nil }

func A_arbace_walk_transform_keys_entry_f__1869000024_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class)}; return nil }

var A_arbace_walk_transform_keys_entry_f__1869000024_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_transform_keys_entry_f__1869000024_A_invoke, New: A_arbace_walk_transform_keys_entry_f__1869000024_A_new, Get: A_arbace_walk_transform_keys_entry_f__1869000024_A_get}

var A_arbace_walk_transform_keys_entry_f__1869000024_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$transform_keys$entry_f__1869000024", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_transform_keys_A_class, Simple: "entry_f__1869000024", Go: "arbace/aot_arbace_walk.A_arbace_walk_transform_keys_entry_f__1869000024_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_transform_keys_entry_f__1869000024_A_class.Info(); i.IsInstance = A_arbace_walk_transform_keys_entry_f__1869000024_A_InstanceOf; i.Init = A_arbace_walk_transform_keys_entry_f__1869000024_A_Init; i.Table = A_arbace_walk_transform_keys_entry_f__1869000024_A_members; jrt.RegisterGoType(A_arbace_walk_transform_keys_entry_f__1869000024_A_class, reflect.TypeFor[A_arbace_walk_transform_keys_entry_f__1869000024_A]()) }

func A_arbace_walk_transform_keys_fn__1869000029_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_transform_keys_fn__1869000029_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_walk_transform_keys_fn__1869000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_transform_keys_fn__1869000029_A_New_O(args[0])}; return nil }

func A_arbace_walk_transform_keys_fn__1869000029_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_transform_keys_fn__1869000029_A_fn_class)}; return nil }

var A_arbace_walk_transform_keys_fn__1869000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_transform_keys_fn__1869000029_A_invoke, New: A_arbace_walk_transform_keys_fn__1869000029_A_new, Get: A_arbace_walk_transform_keys_fn__1869000029_A_get}

var A_arbace_walk_transform_keys_fn__1869000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$transform_keys$fn__1869000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_walk_transform_keys_A_class, Simple: "fn__1869000029", Go: "arbace/aot_arbace_walk.A_arbace_walk_transform_keys_fn__1869000029_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_transform_keys_fn__1869000029_A_class.Info(); i.IsInstance = A_arbace_walk_transform_keys_fn__1869000029_A_InstanceOf; i.Init = A_arbace_walk_transform_keys_fn__1869000029_A_Init; i.Table = A_arbace_walk_transform_keys_fn__1869000029_A_members; jrt.RegisterGoType(A_arbace_walk_transform_keys_fn__1869000029_A_class, reflect.TypeFor[A_arbace_walk_transform_keys_fn__1869000029_A]()) }

func A_arbace_walk_walk_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_walk_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_walk_walk_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_walk_A_New()}; return nil }

func A_arbace_walk_walk_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_walk_A_fn_class)}; return nil }

var A_arbace_walk_walk_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_walk_A_invoke, New: A_arbace_walk_walk_A_new, Get: A_arbace_walk_walk_A_get}

var A_arbace_walk_walk_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$walk", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_walk_A_class, Simple: "walk", Go: "arbace/aot_arbace_walk.A_arbace_walk_walk_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_walk_A_class.Info(); i.IsInstance = A_arbace_walk_walk_A_InstanceOf; i.Init = A_arbace_walk_walk_A_Init; i.Table = A_arbace_walk_walk_A_members; jrt.RegisterGoType(A_arbace_walk_walk_A_class, reflect.TypeFor[A_arbace_walk_walk_A]()) }

func A_arbace_walk_walk_fn__1869000012_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_walk_walk_fn__1869000012_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_walk_walk_fn__1869000012_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk_walk_fn__1869000012_A_New_O(args[0])}; return nil }

func A_arbace_walk_walk_fn__1869000012_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_walk_walk_fn__1869000012_A_fn_class)}; return nil }

var A_arbace_walk_walk_fn__1869000012_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_walk_walk_fn__1869000012_A_invoke, New: A_arbace_walk_walk_fn__1869000012_A_new, Get: A_arbace_walk_walk_fn__1869000012_A_get}

var A_arbace_walk_walk_fn__1869000012_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk$walk$fn__1869000012", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_walk_walk_A_class, Simple: "fn__1869000012", Go: "arbace/aot_arbace_walk.A_arbace_walk_walk_fn__1869000012_A", Source: "walk.ae"})

func init() { i := A_arbace_walk_walk_fn__1869000012_A_class.Info(); i.IsInstance = A_arbace_walk_walk_fn__1869000012_A_InstanceOf; i.Init = A_arbace_walk_walk_fn__1869000012_A_Init; i.Table = A_arbace_walk_walk_fn__1869000012_A_members; jrt.RegisterGoType(A_arbace_walk_walk_fn__1869000012_A_class, reflect.TypeFor[A_arbace_walk_walk_fn__1869000012_A]()) }

func A_arbace_walk__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_walk__init_A_Load__O(); case 1: return A_arbace_walk__init_A_Unit0__O(); case 2: return A_arbace_walk__init_A_Unit1__O(); case 3: return A_arbace_walk__init_A_Unit10__O(); case 4: return A_arbace_walk__init_A_Unit11__O(); case 5: return A_arbace_walk__init_A_Unit12__O(); case 6: return A_arbace_walk__init_A_Unit13__O(); case 7: return A_arbace_walk__init_A_Unit14__O(); case 8: return A_arbace_walk__init_A_Unit2__O(); case 9: return A_arbace_walk__init_A_Unit3__O(); case 10: return A_arbace_walk__init_A_Unit4__O(); case 11: return A_arbace_walk__init_A_Unit5__O(); case 12: return A_arbace_walk__init_A_Unit6__O(); case 13: return A_arbace_walk__init_A_Unit7__O(); case 14: return A_arbace_walk__init_A_Unit8__O(); case 15: return A_arbace_walk__init_A_Unit9__O()}; return nil }

func A_arbace_walk__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_walk__init_A_New()}; return nil }

var A_arbace_walk__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_walk__init_A_invoke, New: A_arbace_walk__init_A_new}

var A_arbace_walk__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.walk__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_walk.A_arbace_walk__init_A", Source: "walk.ae"})

func init() { i := A_arbace_walk__init_A_class.Info(); i.IsInstance = A_arbace_walk__init_A_InstanceOf; i.Init = A_arbace_walk__init_A_Init; i.Table = A_arbace_walk__init_A_members; jrt.RegisterGoType(A_arbace_walk__init_A_class, reflect.TypeFor[A_arbace_walk__init_A]()) }
