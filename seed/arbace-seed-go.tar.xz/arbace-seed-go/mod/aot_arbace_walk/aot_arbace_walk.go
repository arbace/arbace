//line aot_arbace_walk.ae:1
package aot_arbace_walk

import (
	"arbace/jrt"
	"arbace/lang"
)













func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_New() *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A { A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_Init(); t := &A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Ctor() {}
//line :20:1
func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_walk_A_Init(); tmp4 = A_arbace_walk_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_walk_A_Init(); tmp6 = A_arbace_walk_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :20:1
func A_arbace_walk_eval1869000008_fn__1869000009_A_New() *A_arbace_walk_eval1869000008_fn__1869000009_A { A_arbace_walk_eval1869000008_fn__1869000009_A_Init(); t := &A_arbace_walk_eval1869000008_fn__1869000009_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Ctor() {}
//line :20:1
func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_walk_A_Init(); tmp3 = A_arbace_walk_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_walk_A_Init(); tmp5 = A_arbace_walk_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_walk_A_Init(); tmp7 = A_arbace_walk_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_walk_A_Init(); tmp9 = A_arbace_walk_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }













func A_arbace_walk_walk_A_New() *A_arbace_walk_walk_A { A_arbace_walk_walk_A_Init(); t := &A_arbace_walk_walk_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_walk_walk_A) Ctor() {}
//line :34:1
func (t *A_arbace_walk_walk_A) Invoke_O_O_O_O__O(self, inner__0, outer__1, form__2 any) any {







	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_7; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__2)) {
		var tmp2 lang.IFn = lang.IFn_Cast(outer__1); var tmp3 *lang.Var; A_arbace_walk_A_Init(); tmp3 = A_arbace_walk_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_walk_A_Init(); tmp5 = A_arbace_walk_A_const_12; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_walk_A_Init(); tmp7 = A_arbace_walk_A_const_13; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 *lang.Var; A_arbace_walk_A_Init(); tmp9 = A_arbace_walk_A_const_14; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6.Invoke_O_O__O(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(inner__0, form__2)), lang.RT_Meta_O__IPersistentMap(form__2))) } else {
//line :42:1
			if lang.IMapEntry_InstanceOf(form__2) {


				var tmp10 lang.IFn = lang.IFn_Cast(outer__1); var tmp11 lang.IFn = lang.IFn_Cast(inner__0); var tmp12 *lang.Var; A_arbace_walk_A_Init(); tmp12 = A_arbace_walk_A_const_15; var tmp13 any = tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(form__2)); var tmp14 lang.IFn = lang.IFn_Cast(inner__0); var tmp15 *lang.Var; A_arbace_walk_A_Init(); tmp15 = A_arbace_walk_A_const_16; return tmp10.Invoke_O__O(lang.MapEntry_Create_O_O__MapEntry(tmp13, tmp14.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(form__2))).Ref()) } else {
//line :42:1
					var tmp16 *lang.Var; A_arbace_walk_A_Init(); tmp16 = A_arbace_walk_A_const_8; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(form__2)) {



						var tmp17 lang.IFn = lang.IFn_Cast(outer__1); var tmp18 *lang.Var; A_arbace_walk_A_Init(); tmp18 = A_arbace_walk_A_const_11; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_walk_A_Init(); tmp20 = A_arbace_walk_A_const_17; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_walk_A_Init(); tmp22 = A_arbace_walk_A_const_14; return tmp17.Invoke_O__O(tmp19.Invoke_O_O__O(tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O__O(inner__0, form__2)), lang.RT_Meta_O__IPersistentMap(form__2))) } else {
//line :42:1
							if lang.IRecord_InstanceOf(form__2) {





								var tmp23 lang.IFn = lang.IFn_Cast(outer__1); var tmp24 *lang.Var; A_arbace_walk_A_Init(); tmp24 = A_arbace_walk_A_const_18; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any = A_arbace_walk_walk_fn__1869000012_A_New_O(inner__0); var tmp27 *jrt.Class; A_arbace_walk_walk_fn__1869000012_A_Init(); tmp27 = A_arbace_walk_walk_fn__1869000012_A_fn_class; return tmp23.Invoke_O__O(tmp25.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil), form__2, form__2)) } else {
//line :42:1
									var tmp28 *lang.Var; A_arbace_walk_A_Init(); tmp28 = A_arbace_walk_A_const_9; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(form__2)) {






										var tmp29 lang.IFn = lang.IFn_Cast(outer__1); var tmp30 *lang.Var; A_arbace_walk_A_Init(); tmp30 = A_arbace_walk_A_const_19; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_walk_A_Init(); tmp32 = A_arbace_walk_A_const_20; var tmp33 any = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(form__2); var tmp34 *lang.Var; A_arbace_walk_A_Init(); tmp34 = A_arbace_walk_A_const_14; return tmp29.Invoke_O__O(tmp31.Invoke_O_O__O(tmp33, lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O_O__O(inner__0, form__2))) } else {
//line :42:1
											var tmp35 *lang.Keyword; A_arbace_walk_A_Init(); tmp35 = A_arbace_walk_A_const_10; if tmp35 != nil {







												return lang.IFn_Cast(outer__1).Invoke_O__O(form__2) } else {
//line :42:1
													return nil
												}
										}
								}
						}
				} } }
func A_arbace_walk_walk_fn__1869000012_A_New_O(p0 any) *A_arbace_walk_walk_fn__1869000012_A { A_arbace_walk_walk_fn__1869000012_A_Init(); t := &A_arbace_walk_walk_fn__1869000012_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_walk_walk_fn__1869000012_A) Ctor_O(c__inner any) { t.F_inner = c__inner }
//line :48:1
func (t *A_arbace_walk_walk_fn__1869000012_A) Invoke_O_O_O__O(self, r__1, x__2 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_4; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(r__1, lang.IFn_Cast(t.F_inner).Invoke_O__O(x__2)) }



func A_arbace_walk_postwalk_A_New() *A_arbace_walk_postwalk_A { A_arbace_walk_postwalk_A_Init(); t := &A_arbace_walk_postwalk_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_walk_postwalk_A) Ctor() {}
//line :52:1
func (t *A_arbace_walk_postwalk_A) Invoke_O_O_O__O(self, f__0, form__1 any) any {





	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_walk_A_Init(); tmp3 = A_arbace_walk_A_const_22; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_walk_A_Init(); tmp5 = A_arbace_walk_A_const_23; return tmp2.Invoke_O_O_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), f__0), f__0, form__1)
}
func A_arbace_walk_prewalk_A_New() *A_arbace_walk_prewalk_A { A_arbace_walk_prewalk_A_Init(); t := &A_arbace_walk_prewalk_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_walk_prewalk_A) Ctor() {}
//line :60:1
func (t *A_arbace_walk_prewalk_A) Invoke_O_O_O__O(self, f__0, form__1 any) any {



	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_walk_A_Init(); tmp3 = A_arbace_walk_A_const_22; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_walk_A_Init(); tmp5 = A_arbace_walk_A_const_25; var tmp6 any = tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), f__0); var tmp7 *lang.Var; A_arbace_walk_A_Init(); tmp7 = A_arbace_walk_A_const_24; return tmp2.Invoke_O_O_O__O(tmp6, jrt.NN(tmp7).GetRawRoot__O(), lang.IFn_Cast(f__0).Invoke_O__O(form__1))
}











func A_arbace_walk_postwalk_demo_A_New() *A_arbace_walk_postwalk_demo_A { A_arbace_walk_postwalk_demo_A_Init(); t := &A_arbace_walk_postwalk_demo_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_walk_postwalk_demo_A) Ctor() {}
//line :77:1
func (t *A_arbace_walk_postwalk_demo_A) Invoke_O_O__O(self, form__0 any) any {




	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_walk_postwalk_demo_fn__1869000017_A_New(); var tmp4 *jrt.Class; A_arbace_walk_postwalk_demo_fn__1869000017_A_Init(); tmp4 = A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), form__0) }
//line :82:1
func A_arbace_walk_postwalk_demo_fn__1869000017_A_New() *A_arbace_walk_postwalk_demo_fn__1869000017_A { A_arbace_walk_postwalk_demo_fn__1869000017_A_Init(); t := &A_arbace_walk_postwalk_demo_fn__1869000017_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Ctor() {}
//line :82:1
func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_26; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_49); var tmp2 *lang.Var; A_arbace_walk_A_Init(); tmp2 = A_arbace_walk_A_const_27; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1); return x__1 }

func A_arbace_walk_prewalk_demo_A_New() *A_arbace_walk_prewalk_demo_A { A_arbace_walk_prewalk_demo_A_Init(); t := &A_arbace_walk_prewalk_demo_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_walk_prewalk_demo_A) Ctor() {}
//line :84:1
func (t *A_arbace_walk_prewalk_demo_A) Invoke_O_O__O(self, form__0 any) any {




	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_25; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_walk_prewalk_demo_fn__1869000020_A_New(); var tmp4 *jrt.Class; A_arbace_walk_prewalk_demo_fn__1869000020_A_Init(); tmp4 = A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), form__0) }
//line :89:1
func A_arbace_walk_prewalk_demo_fn__1869000020_A_New() *A_arbace_walk_prewalk_demo_fn__1869000020_A { A_arbace_walk_prewalk_demo_fn__1869000020_A_Init(); t := &A_arbace_walk_prewalk_demo_fn__1869000020_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Ctor() {}
//line :89:1
func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_26; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_49); var tmp2 *lang.Var; A_arbace_walk_A_Init(); tmp2 = A_arbace_walk_A_const_27; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1); return x__1 }

func A_arbace_walk_transform_keys_A_New() *A_arbace_walk_transform_keys_A { A_arbace_walk_transform_keys_A_Init(); t := &A_arbace_walk_transform_keys_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_walk_transform_keys_A) Ctor() {}
//line :91:1
func (t *A_arbace_walk_transform_keys_A) Invoke_O_O_O__O(self, m__0, f__1 any) any { var entry_f__3 any; var tmp1 any = A_arbace_walk_transform_keys_entry_f__1869000024_A_New_O(f__1); var tmp2 *jrt.Class;



	A_arbace_walk_transform_keys_entry_f__1869000024_A_Init(); tmp2 = A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class; entry_f__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 /*line :97:1*/*lang.Var; A_arbace_walk_A_Init(); tmp3 = A_arbace_walk_A_const_23; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_walk_transform_keys_fn__1869000029_A_New_O(entry_f__3); var tmp6 *jrt.Class; A_arbace_walk_transform_keys_fn__1869000029_A_Init(); tmp6 = A_arbace_walk_transform_keys_fn__1869000029_A_fn_class; return tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), m__0) }
//line :95:1
func A_arbace_walk_transform_keys_entry_f__1869000024_A_New_O(p0 any) *A_arbace_walk_transform_keys_entry_f__1869000024_A { A_arbace_walk_transform_keys_entry_f__1869000024_A_Init(); t := &A_arbace_walk_transform_keys_entry_f__1869000024_A{}; t.Ctor_O(p0); return t }
//line :95:1
func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :95:1
func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Invoke_O_O__O(self, p__1869000023__1 any) any { var vec__1869000025__2 any = p__1869000023__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1869000025__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1869000025__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(t.F_f).Invoke_O__O(k__3), v__4) }

func A_arbace_walk_transform_keys_fn__1869000029_A_New_O(p0 any) *A_arbace_walk_transform_keys_fn__1869000029_A { A_arbace_walk_transform_keys_fn__1869000029_A_Init(); t := &A_arbace_walk_transform_keys_fn__1869000029_A{}; t.Ctor_O(p0); return t }
//line :97:1
func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Ctor_O(c__entry_f any) { t.F_entry_f = c__entry_f }
//line :97:1
func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__1)) { var tmp2 *lang.Var; A_arbace_walk_A_Init(); tmp2 = A_arbace_walk_A_const_19; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_walk_A_Init(); tmp6 = A_arbace_walk_A_const_14; return tmp3.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(t.F_entry_f, x__1)) } else { return x__1 } }

func A_arbace_walk_keywordize_keys_A_New() *A_arbace_walk_keywordize_keys_A { A_arbace_walk_keywordize_keys_A_Init(); t := &A_arbace_walk_keywordize_keys_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_walk_keywordize_keys_A) Ctor() {}
//line :99:1
func (t *A_arbace_walk_keywordize_keys_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_walk_keywordize_keys_fn__1869000032_A_New(); var tmp4 *jrt.Class; A_arbace_walk_keywordize_keys_fn__1869000032_A_Init(); tmp4 = A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class; return tmp2.Invoke_O_O__O(m__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :103:1
func A_arbace_walk_keywordize_keys_fn__1869000032_A_New() *A_arbace_walk_keywordize_keys_fn__1869000032_A { A_arbace_walk_keywordize_keys_fn__1869000032_A_Init(); t := &A_arbace_walk_keywordize_keys_fn__1869000032_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Ctor() {}
//line :103:1
func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(k__1)) { var tmp2 *lang.Var; A_arbace_walk_A_Init(); tmp2 = A_arbace_walk_A_const_31; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(k__1) } else { return k__1 } }

func A_arbace_walk_stringify_keys_A_New() *A_arbace_walk_stringify_keys_A { A_arbace_walk_stringify_keys_A_Init(); t := &A_arbace_walk_stringify_keys_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_walk_stringify_keys_A) Ctor() {}
//line :105:1
func (t *A_arbace_walk_stringify_keys_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_walk_stringify_keys_fn__1869000035_A_New(); var tmp4 *jrt.Class; A_arbace_walk_stringify_keys_fn__1869000035_A_Init(); tmp4 = A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class; return tmp2.Invoke_O_O__O(m__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :109:1
func A_arbace_walk_stringify_keys_fn__1869000035_A_New() *A_arbace_walk_stringify_keys_fn__1869000035_A { A_arbace_walk_stringify_keys_fn__1869000035_A_Init(); t := &A_arbace_walk_stringify_keys_fn__1869000035_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Ctor() {}
//line :109:1
func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(k__1)) { var tmp2 *lang.Var; A_arbace_walk_A_Init(); tmp2 = A_arbace_walk_A_const_33; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(k__1) } else { return k__1 } }

func A_arbace_walk_prewalk_replace_A_New() *A_arbace_walk_prewalk_replace_A { A_arbace_walk_prewalk_replace_A_Init(); t := &A_arbace_walk_prewalk_replace_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_walk_prewalk_replace_A) Ctor() {}
//line :111:1
func (t *A_arbace_walk_prewalk_replace_A) Invoke_O_O_O__O(self, smap__0, form__1 any) any {





	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_25; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_walk_prewalk_replace_fn__1869000038_A_New_O(smap__0); var tmp4 *jrt.Class; A_arbace_walk_prewalk_replace_fn__1869000038_A_Init(); tmp4 = A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), form__1) }
//line :117:1
func A_arbace_walk_prewalk_replace_fn__1869000038_A_New_O(p0 any) *A_arbace_walk_prewalk_replace_fn__1869000038_A { A_arbace_walk_prewalk_replace_fn__1869000038_A_Init(); t := &A_arbace_walk_prewalk_replace_fn__1869000038_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Ctor_O(c__smap any) { t.F_smap = c__smap }
//line :117:1
func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_34; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_smap, x__1)) { return lang.IFn_Cast(t.F_smap).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_walk_postwalk_replace_A_New() *A_arbace_walk_postwalk_replace_A { A_arbace_walk_postwalk_replace_A_Init(); t := &A_arbace_walk_postwalk_replace_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_walk_postwalk_replace_A) Ctor() {}
//line :119:1
func (t *A_arbace_walk_postwalk_replace_A) Invoke_O_O_O__O(self, smap__0, form__1 any) any {





	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_walk_postwalk_replace_fn__1869000041_A_New_O(smap__0); var tmp4 *jrt.Class; A_arbace_walk_postwalk_replace_fn__1869000041_A_Init(); tmp4 = A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), form__1) }
//line :125:1
func A_arbace_walk_postwalk_replace_fn__1869000041_A_New_O(p0 any) *A_arbace_walk_postwalk_replace_fn__1869000041_A { A_arbace_walk_postwalk_replace_fn__1869000041_A_Init(); t := &A_arbace_walk_postwalk_replace_fn__1869000041_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Ctor_O(c__smap any) { t.F_smap = c__smap }
//line :125:1
func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_34; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_smap, x__1)) { return lang.IFn_Cast(t.F_smap).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_walk_macroexpand_all_A_New() *A_arbace_walk_macroexpand_all_A { A_arbace_walk_macroexpand_all_A_Init(); t := &A_arbace_walk_macroexpand_all_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_walk_macroexpand_all_A) Ctor() {}
//line :127:1
func (t *A_arbace_walk_macroexpand_all_A) Invoke_O_O__O(self, form__0 any) any {



	var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_25; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_walk_macroexpand_all_fn__1869000044_A_New(); var tmp4 *jrt.Class; A_arbace_walk_macroexpand_all_fn__1869000044_A_Init(); tmp4 = A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), form__0) }
//line :131:1
func A_arbace_walk_macroexpand_all_fn__1869000044_A_New() *A_arbace_walk_macroexpand_all_fn__1869000044_A { A_arbace_walk_macroexpand_all_fn__1869000044_A_Init(); t := &A_arbace_walk_macroexpand_all_fn__1869000044_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Ctor() {}
//line :131:1
func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_walk_A_Init(); tmp1 = A_arbace_walk_A_const_8; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__1)) { var tmp2 *lang.Var; A_arbace_walk_A_Init(); tmp2 = A_arbace_walk_A_const_35; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1) } else { return x__1 } }
















































type A_arbace_walk_A struct{ jrt.Object }

var A_arbace_walk_A_const_0 *lang.Var

var A_arbace_walk_A_const_1 any

var A_arbace_walk_A_const_2 *lang.Var

var A_arbace_walk_A_const_3 *lang.Var

var A_arbace_walk_A_const_4 *lang.Var

var A_arbace_walk_A_const_5 any

var A_arbace_walk_A_const_6 *lang.Var

var A_arbace_walk_A_const_7 *lang.Var

var A_arbace_walk_A_const_8 *lang.Var

var A_arbace_walk_A_const_9 *lang.Var

var A_arbace_walk_A_const_10 *lang.Keyword

var A_arbace_walk_A_const_11 *lang.Var

var A_arbace_walk_A_const_12 *lang.Var

var A_arbace_walk_A_const_13 *lang.Var

var A_arbace_walk_A_const_14 *lang.Var

var A_arbace_walk_A_const_15 *lang.Var

var A_arbace_walk_A_const_16 *lang.Var

var A_arbace_walk_A_const_17 *lang.Var

var A_arbace_walk_A_const_18 *lang.Var

var A_arbace_walk_A_const_19 *lang.Var

var A_arbace_walk_A_const_20 *lang.Var

var A_arbace_walk_A_const_21 *lang.Var

var A_arbace_walk_A_const_22 *lang.Var

var A_arbace_walk_A_const_23 *lang.Var

var A_arbace_walk_A_const_24 *lang.Var

var A_arbace_walk_A_const_25 *lang.Var

var A_arbace_walk_A_const_26 *lang.Var

var A_arbace_walk_A_const_27 *lang.Var

var A_arbace_walk_A_const_28 *lang.Var

var A_arbace_walk_A_const_29 *lang.Var

var A_arbace_walk_A_const_30 *lang.Var

var A_arbace_walk_A_const_31 *lang.Var

var A_arbace_walk_A_const_32 *lang.Var

var A_arbace_walk_A_const_33 *lang.Var

var A_arbace_walk_A_const_34 *lang.Var

var A_arbace_walk_A_const_35 *lang.Var

var A_arbace_walk_A_init jrt.ClassInit

func A_arbace_walk_A_Init() { if !A_arbace_walk_A_init.Done() { A_arbace_walk_A_init.Run(A_arbace_walk_A_clinit) } }

func A_arbace_walk_A_clinit() { A_arbace_walk_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_walk_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_walk_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_walk_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_walk_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_walk_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_walk_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_walk_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_walk_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_walk_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_walk_A_const_10 = lang.RT_Keyword_String_String__Keyword(nil, Lit_14); A_arbace_walk_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_walk_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_walk_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_walk_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_walk_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_walk_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_walk_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_walk_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_walk_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_walk_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_walk_A_const_21 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); A_arbace_walk_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_walk_A_const_23 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_walk_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_walk_A_const_25 = lang.RT_Var_String_String__Var(Lit_5, Lit_29); A_arbace_walk_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_walk_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_walk_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_walk_A_const_29 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_walk_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_walk_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_walk_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_walk_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_walk_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_walk_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_39) }

func A_arbace_walk_A_New() *A_arbace_walk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_A) Ctor() {}

func (t *A_arbace_walk_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_A) GetClass__Class() *jrt.Class { return A_arbace_walk_A_class }

func (t *A_arbace_walk_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_A); return ok }

func A_arbace_walk_A_Cast(x any) *A_arbace_walk_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_A_class)) }; return v }



type A_arbace_walk_eval1869000004_A struct{ jrt.Object }

func A_arbace_walk_eval1869000004_A_New() *A_arbace_walk_eval1869000004_A { t := &A_arbace_walk_eval1869000004_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_eval1869000004_A) Ctor() {}

func (t *A_arbace_walk_eval1869000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000004_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000004_A_class }

func (t *A_arbace_walk_eval1869000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000004_A); return ok }

func A_arbace_walk_eval1869000004_A_Cast(x any) *A_arbace_walk_eval1869000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000004_A_class)) }; return v }



type A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A struct{ jrt.Object }

func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Is_Compiler_AOTF0() {}

var A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_fn_class *jrt.Class

var A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_init jrt.ClassInit

func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_Init() { if !A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_init.Done() { A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_init.Run(A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_clinit) } }

func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_clinit() { A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_40, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_class }

func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A); return ok }

func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_Cast(x any) *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_class)) }; return v }



type A_arbace_walk_eval1869000008_A struct{ jrt.Object }

func A_arbace_walk_eval1869000008_A_New() *A_arbace_walk_eval1869000008_A { t := &A_arbace_walk_eval1869000008_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_eval1869000008_A) Ctor() {}

func (t *A_arbace_walk_eval1869000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000008_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000008_A_class }

func (t *A_arbace_walk_eval1869000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000008_A); return ok }

func A_arbace_walk_eval1869000008_A_Cast(x any) *A_arbace_walk_eval1869000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000008_A_class)) }; return v }



type A_arbace_walk_eval1869000008_fn__1869000009_A struct{ jrt.Object }

func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Is_Compiler_AOTF0() {}

var A_arbace_walk_eval1869000008_fn__1869000009_A_fn_class *jrt.Class

var A_arbace_walk_eval1869000008_fn__1869000009_A_init jrt.ClassInit

func A_arbace_walk_eval1869000008_fn__1869000009_A_Init() { if !A_arbace_walk_eval1869000008_fn__1869000009_A_init.Done() { A_arbace_walk_eval1869000008_fn__1869000009_A_init.Run(A_arbace_walk_eval1869000008_fn__1869000009_A_clinit) } }

func A_arbace_walk_eval1869000008_fn__1869000009_A_clinit() { A_arbace_walk_eval1869000008_fn__1869000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_41, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000008_fn__1869000009_A_class }

func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000008_fn__1869000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000008_fn__1869000009_A); return ok }

func A_arbace_walk_eval1869000008_fn__1869000009_A_Cast(x any) *A_arbace_walk_eval1869000008_fn__1869000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000008_fn__1869000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000008_fn__1869000009_A_class)) }; return v }



type A_arbace_walk_keywordize_keys_A struct{ jrt.Object }

func (t *A_arbace_walk_keywordize_keys_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_keywordize_keys_A_fn_class *jrt.Class

var A_arbace_walk_keywordize_keys_A_init jrt.ClassInit

func A_arbace_walk_keywordize_keys_A_Init() { if !A_arbace_walk_keywordize_keys_A_init.Done() { A_arbace_walk_keywordize_keys_A_init.Run(A_arbace_walk_keywordize_keys_A_clinit) } }

func A_arbace_walk_keywordize_keys_A_clinit() { A_arbace_walk_keywordize_keys_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_42, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_keywordize_keys_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_keywordize_keys_A) GetClass__Class() *jrt.Class { return A_arbace_walk_keywordize_keys_A_class }

func (t *A_arbace_walk_keywordize_keys_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_keywordize_keys_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_keywordize_keys_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_keywordize_keys_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_keywordize_keys_A); return ok }

func A_arbace_walk_keywordize_keys_A_Cast(x any) *A_arbace_walk_keywordize_keys_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_keywordize_keys_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_keywordize_keys_A_class)) }; return v }



type A_arbace_walk_keywordize_keys_fn__1869000032_A struct{ jrt.Object }

func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class *jrt.Class

var A_arbace_walk_keywordize_keys_fn__1869000032_A_init jrt.ClassInit

func A_arbace_walk_keywordize_keys_fn__1869000032_A_Init() { if !A_arbace_walk_keywordize_keys_fn__1869000032_A_init.Done() { A_arbace_walk_keywordize_keys_fn__1869000032_A_init.Run(A_arbace_walk_keywordize_keys_fn__1869000032_A_clinit) } }

func A_arbace_walk_keywordize_keys_fn__1869000032_A_clinit() { A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_43, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) GetClass__Class() *jrt.Class { return A_arbace_walk_keywordize_keys_fn__1869000032_A_class }

func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_keywordize_keys_fn__1869000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_keywordize_keys_fn__1869000032_A); return ok }

func A_arbace_walk_keywordize_keys_fn__1869000032_A_Cast(x any) *A_arbace_walk_keywordize_keys_fn__1869000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_keywordize_keys_fn__1869000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_keywordize_keys_fn__1869000032_A_class)) }; return v }



type A_arbace_walk_macroexpand_all_A struct{ jrt.Object }

func (t *A_arbace_walk_macroexpand_all_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_macroexpand_all_A_fn_class *jrt.Class

var A_arbace_walk_macroexpand_all_A_init jrt.ClassInit

func A_arbace_walk_macroexpand_all_A_Init() { if !A_arbace_walk_macroexpand_all_A_init.Done() { A_arbace_walk_macroexpand_all_A_init.Run(A_arbace_walk_macroexpand_all_A_clinit) } }

func A_arbace_walk_macroexpand_all_A_clinit() { A_arbace_walk_macroexpand_all_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_44, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_macroexpand_all_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_macroexpand_all_A) GetClass__Class() *jrt.Class { return A_arbace_walk_macroexpand_all_A_class }

func (t *A_arbace_walk_macroexpand_all_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_macroexpand_all_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_macroexpand_all_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_macroexpand_all_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_macroexpand_all_A); return ok }

func A_arbace_walk_macroexpand_all_A_Cast(x any) *A_arbace_walk_macroexpand_all_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_macroexpand_all_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_macroexpand_all_A_class)) }; return v }



type A_arbace_walk_macroexpand_all_fn__1869000044_A struct{ jrt.Object }

func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class *jrt.Class

var A_arbace_walk_macroexpand_all_fn__1869000044_A_init jrt.ClassInit

func A_arbace_walk_macroexpand_all_fn__1869000044_A_Init() { if !A_arbace_walk_macroexpand_all_fn__1869000044_A_init.Done() { A_arbace_walk_macroexpand_all_fn__1869000044_A_init.Run(A_arbace_walk_macroexpand_all_fn__1869000044_A_clinit) } }

func A_arbace_walk_macroexpand_all_fn__1869000044_A_clinit() { A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_45, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) GetClass__Class() *jrt.Class { return A_arbace_walk_macroexpand_all_fn__1869000044_A_class }

func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_macroexpand_all_fn__1869000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_macroexpand_all_fn__1869000044_A); return ok }

func A_arbace_walk_macroexpand_all_fn__1869000044_A_Cast(x any) *A_arbace_walk_macroexpand_all_fn__1869000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_macroexpand_all_fn__1869000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_macroexpand_all_fn__1869000044_A_class)) }; return v }



type A_arbace_walk_postwalk_A struct{ jrt.Object }

func (t *A_arbace_walk_postwalk_A) Is_Compiler_AOTF2() {}

var A_arbace_walk_postwalk_A_fn_class *jrt.Class

var A_arbace_walk_postwalk_A_init jrt.ClassInit

func A_arbace_walk_postwalk_A_Init() { if !A_arbace_walk_postwalk_A_init.Done() { A_arbace_walk_postwalk_A_init.Run(A_arbace_walk_postwalk_A_clinit) } }

func A_arbace_walk_postwalk_A_clinit() { A_arbace_walk_postwalk_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_46, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_postwalk_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_postwalk_A) GetClass__Class() *jrt.Class { return A_arbace_walk_postwalk_A_class }

func (t *A_arbace_walk_postwalk_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_postwalk_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_postwalk_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_postwalk_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_postwalk_A); return ok }

func A_arbace_walk_postwalk_A_Cast(x any) *A_arbace_walk_postwalk_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_postwalk_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_postwalk_A_class)) }; return v }



type A_arbace_walk_postwalk_demo_A struct{ jrt.Object }

func (t *A_arbace_walk_postwalk_demo_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_postwalk_demo_A_fn_class *jrt.Class

var A_arbace_walk_postwalk_demo_A_init jrt.ClassInit

func A_arbace_walk_postwalk_demo_A_Init() { if !A_arbace_walk_postwalk_demo_A_init.Done() { A_arbace_walk_postwalk_demo_A_init.Run(A_arbace_walk_postwalk_demo_A_clinit) } }

func A_arbace_walk_postwalk_demo_A_clinit() { A_arbace_walk_postwalk_demo_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_postwalk_demo_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_postwalk_demo_A) GetClass__Class() *jrt.Class { return A_arbace_walk_postwalk_demo_A_class }

func (t *A_arbace_walk_postwalk_demo_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_postwalk_demo_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_postwalk_demo_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_postwalk_demo_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_postwalk_demo_A); return ok }

func A_arbace_walk_postwalk_demo_A_Cast(x any) *A_arbace_walk_postwalk_demo_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_postwalk_demo_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_postwalk_demo_A_class)) }; return v }



type A_arbace_walk_postwalk_demo_fn__1869000017_A struct{ jrt.Object }

func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class *jrt.Class

var A_arbace_walk_postwalk_demo_fn__1869000017_A_init jrt.ClassInit

func A_arbace_walk_postwalk_demo_fn__1869000017_A_Init() { if !A_arbace_walk_postwalk_demo_fn__1869000017_A_init.Done() { A_arbace_walk_postwalk_demo_fn__1869000017_A_init.Run(A_arbace_walk_postwalk_demo_fn__1869000017_A_clinit) } }

func A_arbace_walk_postwalk_demo_fn__1869000017_A_clinit() { A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) GetClass__Class() *jrt.Class { return A_arbace_walk_postwalk_demo_fn__1869000017_A_class }

func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_postwalk_demo_fn__1869000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_postwalk_demo_fn__1869000017_A); return ok }

func A_arbace_walk_postwalk_demo_fn__1869000017_A_Cast(x any) *A_arbace_walk_postwalk_demo_fn__1869000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_postwalk_demo_fn__1869000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_postwalk_demo_fn__1869000017_A_class)) }; return v }



type A_arbace_walk_postwalk_replace_A struct{ jrt.Object }

func (t *A_arbace_walk_postwalk_replace_A) Is_Compiler_AOTF2() {}

var A_arbace_walk_postwalk_replace_A_fn_class *jrt.Class

var A_arbace_walk_postwalk_replace_A_init jrt.ClassInit

func A_arbace_walk_postwalk_replace_A_Init() { if !A_arbace_walk_postwalk_replace_A_init.Done() { A_arbace_walk_postwalk_replace_A_init.Run(A_arbace_walk_postwalk_replace_A_clinit) } }

func A_arbace_walk_postwalk_replace_A_clinit() { A_arbace_walk_postwalk_replace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_50, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_postwalk_replace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_postwalk_replace_A) GetClass__Class() *jrt.Class { return A_arbace_walk_postwalk_replace_A_class }

func (t *A_arbace_walk_postwalk_replace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_postwalk_replace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_postwalk_replace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_postwalk_replace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_postwalk_replace_A); return ok }

func A_arbace_walk_postwalk_replace_A_Cast(x any) *A_arbace_walk_postwalk_replace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_postwalk_replace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_postwalk_replace_A_class)) }; return v }



type A_arbace_walk_postwalk_replace_fn__1869000041_A struct{ jrt.Object; F_smap any }

func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class *jrt.Class

var A_arbace_walk_postwalk_replace_fn__1869000041_A_init jrt.ClassInit

func A_arbace_walk_postwalk_replace_fn__1869000041_A_Init() { if !A_arbace_walk_postwalk_replace_fn__1869000041_A_init.Done() { A_arbace_walk_postwalk_replace_fn__1869000041_A_init.Run(A_arbace_walk_postwalk_replace_fn__1869000041_A_clinit) } }

func A_arbace_walk_postwalk_replace_fn__1869000041_A_clinit() { A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) GetClass__Class() *jrt.Class { return A_arbace_walk_postwalk_replace_fn__1869000041_A_class }

func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_postwalk_replace_fn__1869000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_postwalk_replace_fn__1869000041_A); return ok }

func A_arbace_walk_postwalk_replace_fn__1869000041_A_Cast(x any) *A_arbace_walk_postwalk_replace_fn__1869000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_postwalk_replace_fn__1869000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_postwalk_replace_fn__1869000041_A_class)) }; return v }



type A_arbace_walk_prewalk_A struct{ jrt.Object }

func (t *A_arbace_walk_prewalk_A) Is_Compiler_AOTF2() {}

var A_arbace_walk_prewalk_A_fn_class *jrt.Class

var A_arbace_walk_prewalk_A_init jrt.ClassInit

func A_arbace_walk_prewalk_A_Init() { if !A_arbace_walk_prewalk_A_init.Done() { A_arbace_walk_prewalk_A_init.Run(A_arbace_walk_prewalk_A_clinit) } }

func A_arbace_walk_prewalk_A_clinit() { A_arbace_walk_prewalk_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_prewalk_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_prewalk_A) GetClass__Class() *jrt.Class { return A_arbace_walk_prewalk_A_class }

func (t *A_arbace_walk_prewalk_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_prewalk_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_prewalk_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_prewalk_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_prewalk_A); return ok }

func A_arbace_walk_prewalk_A_Cast(x any) *A_arbace_walk_prewalk_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_prewalk_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_prewalk_A_class)) }; return v }



type A_arbace_walk_prewalk_demo_A struct{ jrt.Object }

func (t *A_arbace_walk_prewalk_demo_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_prewalk_demo_A_fn_class *jrt.Class

var A_arbace_walk_prewalk_demo_A_init jrt.ClassInit

func A_arbace_walk_prewalk_demo_A_Init() { if !A_arbace_walk_prewalk_demo_A_init.Done() { A_arbace_walk_prewalk_demo_A_init.Run(A_arbace_walk_prewalk_demo_A_clinit) } }

func A_arbace_walk_prewalk_demo_A_clinit() { A_arbace_walk_prewalk_demo_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_53, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_prewalk_demo_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_prewalk_demo_A) GetClass__Class() *jrt.Class { return A_arbace_walk_prewalk_demo_A_class }

func (t *A_arbace_walk_prewalk_demo_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_prewalk_demo_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_prewalk_demo_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_prewalk_demo_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_prewalk_demo_A); return ok }

func A_arbace_walk_prewalk_demo_A_Cast(x any) *A_arbace_walk_prewalk_demo_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_prewalk_demo_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_prewalk_demo_A_class)) }; return v }



type A_arbace_walk_prewalk_demo_fn__1869000020_A struct{ jrt.Object }

func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class *jrt.Class

var A_arbace_walk_prewalk_demo_fn__1869000020_A_init jrt.ClassInit

func A_arbace_walk_prewalk_demo_fn__1869000020_A_Init() { if !A_arbace_walk_prewalk_demo_fn__1869000020_A_init.Done() { A_arbace_walk_prewalk_demo_fn__1869000020_A_init.Run(A_arbace_walk_prewalk_demo_fn__1869000020_A_clinit) } }

func A_arbace_walk_prewalk_demo_fn__1869000020_A_clinit() { A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) GetClass__Class() *jrt.Class { return A_arbace_walk_prewalk_demo_fn__1869000020_A_class }

func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_prewalk_demo_fn__1869000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_prewalk_demo_fn__1869000020_A); return ok }

func A_arbace_walk_prewalk_demo_fn__1869000020_A_Cast(x any) *A_arbace_walk_prewalk_demo_fn__1869000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_prewalk_demo_fn__1869000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_prewalk_demo_fn__1869000020_A_class)) }; return v }



type A_arbace_walk_prewalk_replace_A struct{ jrt.Object }

func (t *A_arbace_walk_prewalk_replace_A) Is_Compiler_AOTF2() {}

var A_arbace_walk_prewalk_replace_A_fn_class *jrt.Class

var A_arbace_walk_prewalk_replace_A_init jrt.ClassInit

func A_arbace_walk_prewalk_replace_A_Init() { if !A_arbace_walk_prewalk_replace_A_init.Done() { A_arbace_walk_prewalk_replace_A_init.Run(A_arbace_walk_prewalk_replace_A_clinit) } }

func A_arbace_walk_prewalk_replace_A_clinit() { A_arbace_walk_prewalk_replace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_prewalk_replace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_prewalk_replace_A) GetClass__Class() *jrt.Class { return A_arbace_walk_prewalk_replace_A_class }

func (t *A_arbace_walk_prewalk_replace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_prewalk_replace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_prewalk_replace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_prewalk_replace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_prewalk_replace_A); return ok }

func A_arbace_walk_prewalk_replace_A_Cast(x any) *A_arbace_walk_prewalk_replace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_prewalk_replace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_prewalk_replace_A_class)) }; return v }



type A_arbace_walk_prewalk_replace_fn__1869000038_A struct{ jrt.Object; F_smap any }

func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class *jrt.Class

var A_arbace_walk_prewalk_replace_fn__1869000038_A_init jrt.ClassInit

func A_arbace_walk_prewalk_replace_fn__1869000038_A_Init() { if !A_arbace_walk_prewalk_replace_fn__1869000038_A_init.Done() { A_arbace_walk_prewalk_replace_fn__1869000038_A_init.Run(A_arbace_walk_prewalk_replace_fn__1869000038_A_clinit) } }

func A_arbace_walk_prewalk_replace_fn__1869000038_A_clinit() { A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) GetClass__Class() *jrt.Class { return A_arbace_walk_prewalk_replace_fn__1869000038_A_class }

func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_prewalk_replace_fn__1869000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_prewalk_replace_fn__1869000038_A); return ok }

func A_arbace_walk_prewalk_replace_fn__1869000038_A_Cast(x any) *A_arbace_walk_prewalk_replace_fn__1869000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_prewalk_replace_fn__1869000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_prewalk_replace_fn__1869000038_A_class)) }; return v }



type A_arbace_walk_stringify_keys_A struct{ jrt.Object }

func (t *A_arbace_walk_stringify_keys_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_stringify_keys_A_fn_class *jrt.Class

var A_arbace_walk_stringify_keys_A_init jrt.ClassInit

func A_arbace_walk_stringify_keys_A_Init() { if !A_arbace_walk_stringify_keys_A_init.Done() { A_arbace_walk_stringify_keys_A_init.Run(A_arbace_walk_stringify_keys_A_clinit) } }

func A_arbace_walk_stringify_keys_A_clinit() { A_arbace_walk_stringify_keys_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_57, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_stringify_keys_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_stringify_keys_A) GetClass__Class() *jrt.Class { return A_arbace_walk_stringify_keys_A_class }

func (t *A_arbace_walk_stringify_keys_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_stringify_keys_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_stringify_keys_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_stringify_keys_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_stringify_keys_A); return ok }

func A_arbace_walk_stringify_keys_A_Cast(x any) *A_arbace_walk_stringify_keys_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_stringify_keys_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_stringify_keys_A_class)) }; return v }



type A_arbace_walk_stringify_keys_fn__1869000035_A struct{ jrt.Object }

func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class *jrt.Class

var A_arbace_walk_stringify_keys_fn__1869000035_A_init jrt.ClassInit

func A_arbace_walk_stringify_keys_fn__1869000035_A_Init() { if !A_arbace_walk_stringify_keys_fn__1869000035_A_init.Done() { A_arbace_walk_stringify_keys_fn__1869000035_A_init.Run(A_arbace_walk_stringify_keys_fn__1869000035_A_clinit) } }

func A_arbace_walk_stringify_keys_fn__1869000035_A_clinit() { A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) GetClass__Class() *jrt.Class { return A_arbace_walk_stringify_keys_fn__1869000035_A_class }

func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_stringify_keys_fn__1869000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_stringify_keys_fn__1869000035_A); return ok }

func A_arbace_walk_stringify_keys_fn__1869000035_A_Cast(x any) *A_arbace_walk_stringify_keys_fn__1869000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_stringify_keys_fn__1869000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_stringify_keys_fn__1869000035_A_class)) }; return v }



type A_arbace_walk_transform_keys_A struct{ jrt.Object }

func (t *A_arbace_walk_transform_keys_A) Is_Compiler_AOTF2() {}

var A_arbace_walk_transform_keys_A_fn_class *jrt.Class

var A_arbace_walk_transform_keys_A_init jrt.ClassInit

func A_arbace_walk_transform_keys_A_Init() { if !A_arbace_walk_transform_keys_A_init.Done() { A_arbace_walk_transform_keys_A_init.Run(A_arbace_walk_transform_keys_A_clinit) } }

func A_arbace_walk_transform_keys_A_clinit() { A_arbace_walk_transform_keys_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_transform_keys_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_transform_keys_A) GetClass__Class() *jrt.Class { return A_arbace_walk_transform_keys_A_class }

func (t *A_arbace_walk_transform_keys_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_transform_keys_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_transform_keys_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_transform_keys_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_transform_keys_A); return ok }

func A_arbace_walk_transform_keys_A_Cast(x any) *A_arbace_walk_transform_keys_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_transform_keys_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_transform_keys_A_class)) }; return v }



type A_arbace_walk_transform_keys_entry_f__1869000024_A struct{ jrt.Object; F_f any }

func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class *jrt.Class

var A_arbace_walk_transform_keys_entry_f__1869000024_A_init jrt.ClassInit

func A_arbace_walk_transform_keys_entry_f__1869000024_A_Init() { if !A_arbace_walk_transform_keys_entry_f__1869000024_A_init.Done() { A_arbace_walk_transform_keys_entry_f__1869000024_A_init.Run(A_arbace_walk_transform_keys_entry_f__1869000024_A_clinit) } }

func A_arbace_walk_transform_keys_entry_f__1869000024_A_clinit() { A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) GetClass__Class() *jrt.Class { return A_arbace_walk_transform_keys_entry_f__1869000024_A_class }

func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_transform_keys_entry_f__1869000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_transform_keys_entry_f__1869000024_A); return ok }

func A_arbace_walk_transform_keys_entry_f__1869000024_A_Cast(x any) *A_arbace_walk_transform_keys_entry_f__1869000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_transform_keys_entry_f__1869000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_transform_keys_entry_f__1869000024_A_class)) }; return v }



type A_arbace_walk_transform_keys_fn__1869000029_A struct{ jrt.Object; F_entry_f any }

func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Is_Compiler_AOTF1() {}

var A_arbace_walk_transform_keys_fn__1869000029_A_fn_class *jrt.Class

var A_arbace_walk_transform_keys_fn__1869000029_A_init jrt.ClassInit

func A_arbace_walk_transform_keys_fn__1869000029_A_Init() { if !A_arbace_walk_transform_keys_fn__1869000029_A_init.Done() { A_arbace_walk_transform_keys_fn__1869000029_A_init.Run(A_arbace_walk_transform_keys_fn__1869000029_A_clinit) } }

func A_arbace_walk_transform_keys_fn__1869000029_A_clinit() { A_arbace_walk_transform_keys_fn__1869000029_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_transform_keys_fn__1869000029_A) GetClass__Class() *jrt.Class { return A_arbace_walk_transform_keys_fn__1869000029_A_class }

func (t *A_arbace_walk_transform_keys_fn__1869000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_transform_keys_fn__1869000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_transform_keys_fn__1869000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_transform_keys_fn__1869000029_A); return ok }

func A_arbace_walk_transform_keys_fn__1869000029_A_Cast(x any) *A_arbace_walk_transform_keys_fn__1869000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_transform_keys_fn__1869000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_transform_keys_fn__1869000029_A_class)) }; return v }



type A_arbace_walk_walk_A struct{ jrt.Object }

func (t *A_arbace_walk_walk_A) Is_Compiler_AOTF3() {}

var A_arbace_walk_walk_A_fn_class *jrt.Class

var A_arbace_walk_walk_A_init jrt.ClassInit

func A_arbace_walk_walk_A_Init() { if !A_arbace_walk_walk_A_init.Done() { A_arbace_walk_walk_A_init.Run(A_arbace_walk_walk_A_clinit) } }

func A_arbace_walk_walk_A_clinit() { A_arbace_walk_walk_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_walk_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_walk_A) GetClass__Class() *jrt.Class { return A_arbace_walk_walk_A_class }

func (t *A_arbace_walk_walk_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_walk_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_walk_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_walk_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_walk_A); return ok }

func A_arbace_walk_walk_A_Cast(x any) *A_arbace_walk_walk_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_walk_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_walk_A_class)) }; return v }



type A_arbace_walk_walk_fn__1869000012_A struct{ jrt.Object; F_inner any }

func (t *A_arbace_walk_walk_fn__1869000012_A) Is_Compiler_AOTF2() {}

var A_arbace_walk_walk_fn__1869000012_A_fn_class *jrt.Class

var A_arbace_walk_walk_fn__1869000012_A_init jrt.ClassInit

func A_arbace_walk_walk_fn__1869000012_A_Init() { if !A_arbace_walk_walk_fn__1869000012_A_init.Done() { A_arbace_walk_walk_fn__1869000012_A_init.Run(A_arbace_walk_walk_fn__1869000012_A_clinit) } }

func A_arbace_walk_walk_fn__1869000012_A_clinit() { A_arbace_walk_walk_fn__1869000012_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_walk_walk_fn__1869000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_walk_fn__1869000012_A) GetClass__Class() *jrt.Class { return A_arbace_walk_walk_fn__1869000012_A_class }

func (t *A_arbace_walk_walk_fn__1869000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_walk_fn__1869000012_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_walk_fn__1869000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_walk_fn__1869000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_walk_fn__1869000012_A); return ok }

func A_arbace_walk_walk_fn__1869000012_A_Cast(x any) *A_arbace_walk_walk_fn__1869000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_walk_fn__1869000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_walk_fn__1869000012_A_class)) }; return v }
