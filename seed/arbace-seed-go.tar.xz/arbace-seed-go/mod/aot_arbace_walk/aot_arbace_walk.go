//line aot_arbace_walk.ae:1
package aot_arbace_walk

import (
	"arbace/jrt"
	"arbace/lang"
)













func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_New() *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Ctor() {}
//line :20:1
func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp3 = lang.IFn_Cast(A_arbace_walk_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_walk_A_const_1); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :20:1
func A_arbace_walk_eval1869000008_fn__1869000009_A_New() *A_arbace_walk_eval1869000008_fn__1869000009_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_eval1869000008_fn__1869000009_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Ctor() {}
//line :20:1
func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_walk_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_walk_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_walk_A_const_6), A_arbace_walk_A_const_4.GetRawRoot__O(), A_arbace_walk_A_const_5) }













func A_arbace_walk_walk_A_New() *A_arbace_walk_walk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_walk_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_walk_walk_A) Ctor() {}
//line :34:1
func (t *A_arbace_walk_walk_A) Invoke_O_O_O_O__O(self, inner__0, outer__1, form__2 any) any {







	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_7.GetRawRoot__O()).Invoke_O__O(form__2)) {
		return lang.IFn_Cast(outer__1).Invoke_O__O(lang.IFn_Cast(A_arbace_walk_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_walk_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_walk_A_const_13.GetRawRoot__O(), lang.IFn_Cast(A_arbace_walk_A_const_14.GetRawRoot__O()).Invoke_O_O__O(inner__0, form__2)), lang.RT_Meta_O__IPersistentMap(form__2))) } else {
//line :42:1
			if lang.IMapEntry_InstanceOf(form__2) {


				return lang.IFn_Cast(outer__1).Invoke_O__O(lang.MapEntry_Create_O_O__MapEntry(lang.IFn_Cast(inner__0).Invoke_O__O(lang.IFn_Cast(A_arbace_walk_A_const_15.GetRawRoot__O()).Invoke_O__O(form__2)), lang.IFn_Cast(inner__0).Invoke_O__O(lang.IFn_Cast(A_arbace_walk_A_const_16.GetRawRoot__O()).Invoke_O__O(form__2))).Ref()) } else {
//line :42:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_8.GetRawRoot__O()).Invoke_O__O(form__2)) {



						return lang.IFn_Cast(outer__1).Invoke_O__O(lang.IFn_Cast(A_arbace_walk_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_walk_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_walk_A_const_14.GetRawRoot__O()).Invoke_O_O__O(inner__0, form__2)), lang.RT_Meta_O__IPersistentMap(form__2))) } else {
//line :42:1
							if lang.IRecord_InstanceOf(form__2) {





								var tmp1 lang.IFn = lang.IFn_Cast(outer__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_18.GetRawRoot__O()); var tmp3 any = A_arbace_walk_walk_fn__1869000012_A_New_O(inner__0); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_walk_walk_fn__1869000012_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_walk_walk_fn__1869000012_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), form__2, form__2)) } else {
//line :42:1
									if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_9.GetRawRoot__O()).Invoke_O__O(form__2)) {






										return lang.IFn_Cast(outer__1).Invoke_O__O(lang.IFn_Cast(A_arbace_walk_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_walk_A_const_20.GetRawRoot__O()).Invoke_O__O(form__2), lang.IFn_Cast(A_arbace_walk_A_const_14.GetRawRoot__O()).Invoke_O_O__O(inner__0, form__2))) } else {
//line :42:1
											if A_arbace_walk_A_const_10 != nil {







												return lang.IFn_Cast(outer__1).Invoke_O__O(form__2) } else {
//line :42:1
													return nil
												}
										}
								}
						}
				} } }
func A_arbace_walk_walk_fn__1869000012_A_New_O(p0 any) *A_arbace_walk_walk_fn__1869000012_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_walk_fn__1869000012_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_walk_walk_fn__1869000012_A) Ctor_O(c__inner any) { t.F_inner = c__inner }
//line :48:1
func (t *A_arbace_walk_walk_fn__1869000012_A) Invoke_O_O_O__O(self, r__1, x__2 any) any { return lang.IFn_Cast(A_arbace_walk_A_const_4.GetRawRoot__O()).Invoke_O_O__O(r__1, lang.IFn_Cast(t.F_inner).Invoke_O__O(x__2)) }



func A_arbace_walk_postwalk_A_New() *A_arbace_walk_postwalk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_walk_postwalk_A) Ctor() {}
//line :52:1
func (t *A_arbace_walk_postwalk_A) Invoke_O_O_O__O(self, f__0, form__1 any) any {





	return lang.IFn_Cast(A_arbace_walk_A_const_21.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_walk_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_walk_A_const_23.GetRawRoot__O(), f__0), f__0, form__1)
}
func A_arbace_walk_prewalk_A_New() *A_arbace_walk_prewalk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_walk_prewalk_A) Ctor() {}
//line :60:1
func (t *A_arbace_walk_prewalk_A) Invoke_O_O_O__O(self, f__0, form__1 any) any {



	return lang.IFn_Cast(A_arbace_walk_A_const_21.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_walk_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_walk_A_const_25.GetRawRoot__O(), f__0), A_arbace_walk_A_const_24.GetRawRoot__O(), lang.IFn_Cast(f__0).Invoke_O__O(form__1))
}











func A_arbace_walk_postwalk_demo_A_New() *A_arbace_walk_postwalk_demo_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_demo_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_walk_postwalk_demo_A) Ctor() {}
//line :77:1
func (t *A_arbace_walk_postwalk_demo_A) Invoke_O_O__O(self, form__0 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_walk_postwalk_demo_fn__1869000017_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), form__0) }
//line :82:1
func A_arbace_walk_postwalk_demo_fn__1869000017_A_New() *A_arbace_walk_postwalk_demo_fn__1869000017_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_demo_fn__1869000017_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Ctor() {}
//line :82:1
func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Invoke_O_O__O(self, x__1 any) any { lang.IFn_Cast(A_arbace_walk_A_const_26.GetRawRoot__O()).Invoke_O__O(Lit_4); lang.IFn_Cast(A_arbace_walk_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1); return x__1 }

func A_arbace_walk_prewalk_demo_A_New() *A_arbace_walk_prewalk_demo_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_demo_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_walk_prewalk_demo_A) Ctor() {}
//line :84:1
func (t *A_arbace_walk_prewalk_demo_A) Invoke_O_O__O(self, form__0 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_walk_prewalk_demo_fn__1869000020_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), form__0) }
//line :89:1
func A_arbace_walk_prewalk_demo_fn__1869000020_A_New() *A_arbace_walk_prewalk_demo_fn__1869000020_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_demo_fn__1869000020_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Ctor() {}
//line :89:1
func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Invoke_O_O__O(self, x__1 any) any { lang.IFn_Cast(A_arbace_walk_A_const_26.GetRawRoot__O()).Invoke_O__O(Lit_4); lang.IFn_Cast(A_arbace_walk_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1); return x__1 }

func A_arbace_walk_transform_keys_A_New() *A_arbace_walk_transform_keys_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_transform_keys_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_walk_transform_keys_A) Ctor() {}
//line :91:1
func (t *A_arbace_walk_transform_keys_A) Invoke_O_O_O__O(self, m__0, f__1 any) any { var entry_f__3 any; var tmp1 any = A_arbace_walk_transform_keys_entry_f__1869000024_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class; if



	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; entry_f__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn =

	lang.IFn_Cast(A_arbace_walk_A_const_23.GetRawRoot__O()); var tmp4 any = A_arbace_walk_transform_keys_fn__1869000029_A_New_O(entry_f__3); var tmp5 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_walk_transform_keys_fn__1869000029_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_walk_transform_keys_fn__1869000029_A_fn_class = fncls__5d; tmp5 = fncls__5d } else { tmp5 = fncls__5 }; return tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), m__0) }
//line :95:1
func A_arbace_walk_transform_keys_entry_f__1869000024_A_New_O(p0 any) *A_arbace_walk_transform_keys_entry_f__1869000024_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_transform_keys_entry_f__1869000024_A{}; t.Ctor_O(p0); return t }
//line :95:1
func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :95:1
func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Invoke_O_O__O(self, p__1869000023__1 any) any { var vec__1869000025__2 any = p__1869000023__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1869000025__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1869000025__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(t.F_f).Invoke_O__O(k__3), v__4) }

func A_arbace_walk_transform_keys_fn__1869000029_A_New_O(p0 any) *A_arbace_walk_transform_keys_fn__1869000029_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_transform_keys_fn__1869000029_A{}; t.Ctor_O(p0); return t }
//line :97:1
func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Ctor_O(c__entry_f any) { t.F_entry_f = c__entry_f }
//line :97:1
func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Invoke_O_O__O(self, x__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_28.GetRawRoot__O()).Invoke_O__O(x__1)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_19.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); return tmp1.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_walk_A_const_14.GetRawRoot__O()).Invoke_O_O__O(t.F_entry_f, x__1)) } else { return x__1 } }

func A_arbace_walk_keywordize_keys_A_New() *A_arbace_walk_keywordize_keys_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_keywordize_keys_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_walk_keywordize_keys_A) Ctor() {}
//line :99:1
func (t *A_arbace_walk_keywordize_keys_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_29.GetRawRoot__O()); var tmp2 any = A_arbace_walk_keywordize_keys_fn__1869000032_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; return tmp1.Invoke_O_O__O(m__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :103:1
func A_arbace_walk_keywordize_keys_fn__1869000032_A_New() *A_arbace_walk_keywordize_keys_fn__1869000032_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_keywordize_keys_fn__1869000032_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Ctor() {}
//line :103:1
func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Invoke_O_O__O(self, k__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_30.GetRawRoot__O()).Invoke_O__O(k__1)) { return lang.IFn_Cast(A_arbace_walk_A_const_31.GetRawRoot__O()).Invoke_O__O(k__1) } else { return k__1 } }

func A_arbace_walk_stringify_keys_A_New() *A_arbace_walk_stringify_keys_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_stringify_keys_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_walk_stringify_keys_A) Ctor() {}
//line :105:1
func (t *A_arbace_walk_stringify_keys_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_29.GetRawRoot__O()); var tmp2 any = A_arbace_walk_stringify_keys_fn__1869000035_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; return tmp1.Invoke_O_O__O(m__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :109:1
func A_arbace_walk_stringify_keys_fn__1869000035_A_New() *A_arbace_walk_stringify_keys_fn__1869000035_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_stringify_keys_fn__1869000035_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Ctor() {}
//line :109:1
func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Invoke_O_O__O(self, k__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_32.GetRawRoot__O()).Invoke_O__O(k__1)) { return lang.IFn_Cast(A_arbace_walk_A_const_33.GetRawRoot__O()).Invoke_O__O(k__1) } else { return k__1 } }

func A_arbace_walk_prewalk_replace_A_New() *A_arbace_walk_prewalk_replace_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_replace_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_walk_prewalk_replace_A) Ctor() {}
//line :111:1
func (t *A_arbace_walk_prewalk_replace_A) Invoke_O_O_O__O(self, smap__0, form__1 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_walk_prewalk_replace_fn__1869000038_A_New_O(smap__0); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), form__1) }
//line :117:1
func A_arbace_walk_prewalk_replace_fn__1869000038_A_New_O(p0 any) *A_arbace_walk_prewalk_replace_fn__1869000038_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_replace_fn__1869000038_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Ctor_O(c__smap any) { t.F_smap = c__smap }
//line :117:1
func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Invoke_O_O__O(self, x__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_34.GetRawRoot__O()).Invoke_O_O__O(t.F_smap, x__1)) { return lang.IFn_Cast(t.F_smap).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_walk_postwalk_replace_A_New() *A_arbace_walk_postwalk_replace_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_replace_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_walk_postwalk_replace_A) Ctor() {}
//line :119:1
func (t *A_arbace_walk_postwalk_replace_A) Invoke_O_O_O__O(self, smap__0, form__1 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_walk_postwalk_replace_fn__1869000041_A_New_O(smap__0); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), form__1) }
//line :125:1
func A_arbace_walk_postwalk_replace_fn__1869000041_A_New_O(p0 any) *A_arbace_walk_postwalk_replace_fn__1869000041_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_replace_fn__1869000041_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Ctor_O(c__smap any) { t.F_smap = c__smap }
//line :125:1
func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Invoke_O_O__O(self, x__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_34.GetRawRoot__O()).Invoke_O_O__O(t.F_smap, x__1)) { return lang.IFn_Cast(t.F_smap).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_walk_macroexpand_all_A_New() *A_arbace_walk_macroexpand_all_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_macroexpand_all_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_walk_macroexpand_all_A) Ctor() {}
//line :127:1
func (t *A_arbace_walk_macroexpand_all_A) Invoke_O_O__O(self, form__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_walk_macroexpand_all_fn__1869000044_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), form__0) }
//line :131:1
func A_arbace_walk_macroexpand_all_fn__1869000044_A_New() *A_arbace_walk_macroexpand_all_fn__1869000044_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_macroexpand_all_fn__1869000044_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Ctor() {}
//line :131:1
func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Invoke_O_O__O(self, x__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_walk_A_const_8.GetRawRoot__O()).Invoke_O__O(x__1)) { return lang.IFn_Cast(A_arbace_walk_A_const_35.GetRawRoot__O()).Invoke_O__O(x__1) } else { return x__1 } }
















































type A_arbace_walk_A struct{ jrt.Object }

var A_arbace_walk_A_const_pool *jrt.RefArray

var A_arbace_walk_A_const_0 *lang.Var

var A_arbace_walk_A_const_1 any

var A_arbace_walk_A_const_2 *lang.Var

var A_arbace_walk_A_const_3 *lang.Var

var A_arbace_walk_A_const_4 *lang.Var

var A_arbace_walk_A_const_5 any

var A_arbace_walk_A_const_6 *lang.Var

var A_arbace_walk_A_const_7 *lang.Var

var A_arbace_walk_A_const_8 *lang.Var

var A_arbace_walk_A_const_9 *lang.Var

var A_arbace_walk_A_const_10 *lang.Keyword

var A_arbace_walk_A_const_11 *lang.Var

var A_arbace_walk_A_const_12 *lang.Var

var A_arbace_walk_A_const_13 *lang.Var

var A_arbace_walk_A_const_14 *lang.Var

var A_arbace_walk_A_const_15 *lang.Var

var A_arbace_walk_A_const_16 *lang.Var

var A_arbace_walk_A_const_17 *lang.Var

var A_arbace_walk_A_const_18 *lang.Var

var A_arbace_walk_A_const_19 *lang.Var

var A_arbace_walk_A_const_20 *lang.Var

var A_arbace_walk_A_const_21 *lang.Var

var A_arbace_walk_A_const_22 *lang.Var

var A_arbace_walk_A_const_23 *lang.Var

var A_arbace_walk_A_const_24 *lang.Var

var A_arbace_walk_A_const_25 *lang.Var

var A_arbace_walk_A_const_26 *lang.Var

var A_arbace_walk_A_const_27 *lang.Var

var A_arbace_walk_A_const_28 *lang.Var

var A_arbace_walk_A_const_29 *lang.Var

var A_arbace_walk_A_const_30 *lang.Var

var A_arbace_walk_A_const_31 *lang.Var

var A_arbace_walk_A_const_32 *lang.Var

var A_arbace_walk_A_const_33 *lang.Var

var A_arbace_walk_A_const_34 *lang.Var

var A_arbace_walk_A_const_35 *lang.Var

var A_arbace_walk_A_init jrt.ClassInit

func A_arbace_walk_A_Init() { if !A_arbace_walk_A_init.Done() { A_arbace_walk_A_init.Run(A_arbace_walk_A_clinit) } }

func A_arbace_walk_A_clinit() { A_arbace_walk_A_clinit_p0(); A_arbace_walk_A_clinit_p1(); A_arbace_walk_A_clinit_p2() }

func A_arbace_walk_A_clinit_p0() { A_arbace_walk_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 40); A_arbace_walk_A_const_0 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[4]); A_arbace_walk_A_const_1 = A_arbace_walk_A_const_pool.A[5]; A_arbace_walk_A_const_2 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[6]); A_arbace_walk_A_const_3 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[7]); A_arbace_walk_A_const_4 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[8]); A_arbace_walk_A_const_5 = A_arbace_walk_A_const_pool.A[9]; A_arbace_walk_A_const_6 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[10]); A_arbace_walk_A_const_7 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[11]); A_arbace_walk_A_const_8 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[12]); A_arbace_walk_A_const_9 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[13]); A_arbace_walk_A_const_10 = lang.Keyword_Cast(A_arbace_walk_A_const_pool.A[14]); A_arbace_walk_A_const_11 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[15]) }

func A_arbace_walk_A_clinit_p1() { A_arbace_walk_A_const_12 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[16]); A_arbace_walk_A_const_13 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[17]); A_arbace_walk_A_const_14 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[18]); A_arbace_walk_A_const_15 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[19]); A_arbace_walk_A_const_16 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[20]); A_arbace_walk_A_const_17 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[21]); A_arbace_walk_A_const_18 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[22]); A_arbace_walk_A_const_19 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[23]); A_arbace_walk_A_const_20 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[24]); A_arbace_walk_A_const_21 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[25]); A_arbace_walk_A_const_22 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[26]); A_arbace_walk_A_const_23 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[27]) }

func A_arbace_walk_A_clinit_p2() { A_arbace_walk_A_const_24 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[28]); A_arbace_walk_A_const_25 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[29]); A_arbace_walk_A_const_26 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[30]); A_arbace_walk_A_const_27 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[31]); A_arbace_walk_A_const_28 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[32]); A_arbace_walk_A_const_29 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[33]); A_arbace_walk_A_const_30 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[34]); A_arbace_walk_A_const_31 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[35]); A_arbace_walk_A_const_32 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[36]); A_arbace_walk_A_const_33 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[37]); A_arbace_walk_A_const_34 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[38]); A_arbace_walk_A_const_35 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[39]) }

func A_arbace_walk_A_New() *A_arbace_walk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_A) Ctor() {}

func (t *A_arbace_walk_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_A) GetClass__Class() *jrt.Class { return A_arbace_walk_A_class }

func (t *A_arbace_walk_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_A); return ok }

func A_arbace_walk_A_Cast(x any) *A_arbace_walk_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_A_class)) }; return v }



type A_arbace_walk_eval1869000004_A struct{ jrt.Object }

func A_arbace_walk_eval1869000004_A_New() *A_arbace_walk_eval1869000004_A { t := &A_arbace_walk_eval1869000004_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_eval1869000004_A) Ctor() {}

func (t *A_arbace_walk_eval1869000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000004_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000004_A_class }

func (t *A_arbace_walk_eval1869000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000004_A); return ok }

func A_arbace_walk_eval1869000004_A_Cast(x any) *A_arbace_walk_eval1869000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000004_A_class)) }; return v }



type A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A struct{ a2g_header uint64 }

var A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_fn_class *jrt.Class



type A_arbace_walk_eval1869000008_A struct{ jrt.Object }

func A_arbace_walk_eval1869000008_A_New() *A_arbace_walk_eval1869000008_A { t := &A_arbace_walk_eval1869000008_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_eval1869000008_A) Ctor() {}

func (t *A_arbace_walk_eval1869000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000008_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000008_A_class }

func (t *A_arbace_walk_eval1869000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000008_A); return ok }

func A_arbace_walk_eval1869000008_A_Cast(x any) *A_arbace_walk_eval1869000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000008_A_class)) }; return v }



type A_arbace_walk_eval1869000008_fn__1869000009_A struct{ a2g_header uint64 }

var A_arbace_walk_eval1869000008_fn__1869000009_A_fn_class *jrt.Class



type A_arbace_walk_keywordize_keys_A struct{ a2g_header uint64 }

var A_arbace_walk_keywordize_keys_A_fn_class *jrt.Class



type A_arbace_walk_keywordize_keys_fn__1869000032_A struct{ a2g_header uint64 }

var A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class *jrt.Class



type A_arbace_walk_macroexpand_all_A struct{ a2g_header uint64 }

var A_arbace_walk_macroexpand_all_A_fn_class *jrt.Class



type A_arbace_walk_macroexpand_all_fn__1869000044_A struct{ a2g_header uint64 }

var A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_A struct{ a2g_header uint64 }

var A_arbace_walk_postwalk_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_demo_A struct{ a2g_header uint64 }

var A_arbace_walk_postwalk_demo_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_demo_fn__1869000017_A struct{ a2g_header uint64 }

var A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_replace_A struct{ a2g_header uint64 }

var A_arbace_walk_postwalk_replace_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_replace_fn__1869000041_A struct{ a2g_header uint64; F_smap any }

var A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_A struct{ a2g_header uint64 }

var A_arbace_walk_prewalk_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_demo_A struct{ a2g_header uint64 }

var A_arbace_walk_prewalk_demo_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_demo_fn__1869000020_A struct{ a2g_header uint64 }

var A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_replace_A struct{ a2g_header uint64 }

var A_arbace_walk_prewalk_replace_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_replace_fn__1869000038_A struct{ a2g_header uint64; F_smap any }

var A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class *jrt.Class



type A_arbace_walk_stringify_keys_A struct{ a2g_header uint64 }

var A_arbace_walk_stringify_keys_A_fn_class *jrt.Class



type A_arbace_walk_stringify_keys_fn__1869000035_A struct{ a2g_header uint64 }

var A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class *jrt.Class



type A_arbace_walk_transform_keys_A struct{ a2g_header uint64 }

var A_arbace_walk_transform_keys_A_fn_class *jrt.Class



type A_arbace_walk_transform_keys_entry_f__1869000024_A struct{ a2g_header uint64; F_f any }

var A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class *jrt.Class



type A_arbace_walk_transform_keys_fn__1869000029_A struct{ a2g_header uint64; F_entry_f any }

var A_arbace_walk_transform_keys_fn__1869000029_A_fn_class *jrt.Class



type A_arbace_walk_walk_A struct{ a2g_header uint64 }

var A_arbace_walk_walk_A_fn_class *jrt.Class



type A_arbace_walk_walk_fn__1869000012_A struct{ a2g_header uint64; F_inner any }

var A_arbace_walk_walk_fn__1869000012_A_fn_class *jrt.Class
