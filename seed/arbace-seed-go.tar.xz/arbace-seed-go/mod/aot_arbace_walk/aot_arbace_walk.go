//line aot_arbace_walk.ae:1
package aot_arbace_walk

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)












func A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_New() *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Ctor() {}
//line :20:1
func (t *A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_walk_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_walk_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :20:1
func A_arbace_walk_eval1869000008_fn__1869000009_A_New() *A_arbace_walk_eval1869000008_fn__1869000009_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_eval1869000008_fn__1869000009_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Ctor() {}
//line :20:1
func (t *A_arbace_walk_eval1869000008_fn__1869000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_walk_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_walk_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_walk_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_walk_A_const_5.GetRawRoot__O(), A_arbace_walk_A_const_6) }













func A_arbace_walk_walk_A_New() *A_arbace_walk_walk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_walk_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_walk_walk_A) Ctor() {}
//line :34:1
func (t *A_arbace_walk_walk_A) Invoke_O_O_O_O__O(self, inner__0, outer__1, form__2 any) any {







	var tmp1 any; var root_15 any = A_arbace_walk_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_list_QMARK__A_fn_class); var ifn_17 lang.IFn
	if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = form__2; if linked_16 == nil { tmp1 = ifn_17.Invoke_O__O(arg_18) } else { tmp1 = linked_16.(*aot_arbace_core.A_arbace_core_list_QMARK__A).Invoke_O_O__O(root_15, arg_18) }
//line :42:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(outer__1); var tmp3 any; var root_37 any = A_arbace_walk_A_const_11.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var root_32 any = A_arbace_walk_A_const_12.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_walk_A_const_13.GetRawRoot__O(); var arg_36 any; var root_27 any = A_arbace_walk_A_const_14.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = inner__0; var arg_31 any = form__2; if linked_28 == nil { arg_36 = ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { arg_36 = linked_28.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) }; if linked_33 == nil { arg_40 = ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { arg_40 = linked_33.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) }; var arg_41 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__2); if linked_38 == nil { tmp3 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { tmp3 = linked_38.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) }; return tmp2.Invoke_O__O(tmp3) } else {
//line :42:1
			if lang.IMapEntry_InstanceOf(form__2) {


				var tmp4 lang.IFn = lang.IFn_Cast(outer__1); var tmp5 lang.IFn = lang.IFn_Cast(inner__0); var tmp6 any; var root_42 any = A_arbace_walk_A_const_15.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_key_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = form__2; if linked_43 == nil { tmp6 = ifn_44.Invoke_O__O(arg_45) } else { tmp6 = linked_43.(*aot_arbace_core.A_arbace_core_key_A).Invoke_O_O__O(root_42, arg_45) }; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 lang.IFn = lang.IFn_Cast(inner__0); var tmp9 any; var root_46 any = A_arbace_walk_A_const_16.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = form__2; if linked_47 == nil { tmp9 = ifn_48.Invoke_O__O(arg_49) } else { tmp9 = linked_47.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_46, arg_49) }; return tmp4.Invoke_O__O(lang.MapEntry_Create_O_O__MapEntry(tmp7, tmp8.Invoke_O__O(tmp9)).Ref()) } else {
//line :42:1
					var tmp10 any; var root_19 any = A_arbace_walk_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_21 lang.IFn



					if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = form__2; if linked_20 == nil { tmp10 = ifn_21.Invoke_O__O(arg_22) } else { tmp10 = linked_20.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_19, arg_22) }
//line :42:1
					if jrt.J2g_Truth(tmp10) {



						var tmp11 lang.IFn = lang.IFn_Cast(outer__1); var tmp12 any; var root_59 any = A_arbace_walk_A_const_11.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_55 any = A_arbace_walk_A_const_17.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var root_50 any = A_arbace_walk_A_const_14.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = inner__0; var arg_54 any = form__2; if linked_51 == nil { arg_58 = ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { arg_58 = linked_51.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_50, arg_53, arg_54) }; if linked_56 == nil { arg_62 = ifn_57.Invoke_O__O(arg_58) } else { arg_62 = linked_56.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_55, arg_58) }; var arg_63 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__2); if linked_60 == nil { tmp12 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { tmp12 = linked_60.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; return tmp11.Invoke_O__O(tmp12) } else {
//line :42:1
							if lang.IRecord_InstanceOf(form__2) {





								var tmp13 lang.IFn = lang.IFn_Cast(outer__1); var tmp14 any; var root_70 any = A_arbace_walk_A_const_18.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var tmp15 any = A_arbace_walk_walk_fn__1869000012_A_New_O(inner__0); var tmp16 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_walk_walk_fn__1869000012_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_walk_walk_fn__1869000012_A_fn_class = fncls__69d; tmp16 = fncls__69d } else { tmp16 = fncls__69 }; arg_73 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_74 any = form__2; var arg_75 any = form__2; if linked_71 == nil { tmp14 = ifn_72.Invoke_O_O_O__O(arg_73, arg_74, arg_75) } else { tmp14 = linked_71.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_70, arg_73, arg_74, arg_75) }; return tmp13.Invoke_O__O(tmp14) } else {
//line :42:1
									var tmp17 any; var root_23 any = A_arbace_walk_A_const_9.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_coll_QMARK__A_fn_class); var ifn_25 lang.IFn






									if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = form__2; if linked_24 == nil { tmp17 = ifn_25.Invoke_O__O(arg_26) } else { tmp17 = linked_24.(*aot_arbace_core.A_arbace_core_coll_QMARK__A).Invoke_O_O__O(root_23, arg_26) }
//line :42:1
									if jrt.J2g_Truth(tmp17) {






										var tmp18 lang.IFn = lang.IFn_Cast(outer__1); var tmp19 any; var root_85 any = A_arbace_walk_A_const_19.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any; var root_76 any = A_arbace_walk_A_const_20.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_empty_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = form__2; if linked_77 == nil { arg_88 = ifn_78.Invoke_O__O(arg_79) } else { arg_88 = linked_77.(*aot_arbace_core.A_arbace_core_empty_A).Invoke_O_O__O(root_76, arg_79) }; var arg_89 any; var root_80 any = A_arbace_walk_A_const_14.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = inner__0; var arg_84 any = form__2; if linked_81 == nil { arg_89 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { arg_89 = linked_81.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }; if linked_86 == nil { tmp19 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { tmp19 = linked_86.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; return tmp18.Invoke_O__O(tmp19) } else {
//line :42:1
											if A_arbace_walk_A_const_10 != nil {







												return lang.IFn_Cast(outer__1).Invoke_O__O(form__2) } else {
//line :42:1
													return nil
												}
										}
								}
						}
				} } }
func A_arbace_walk_walk_fn__1869000012_A_New_O(p0 any) *A_arbace_walk_walk_fn__1869000012_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_walk_fn__1869000012_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_walk_walk_fn__1869000012_A) Ctor_O(c__inner any) { t.F_inner = c__inner }
//line :48:1
func (t *A_arbace_walk_walk_fn__1869000012_A) Invoke_O_O_O__O(self, r__1, x__2 any) any { var root_64 any = A_arbace_walk_A_const_5.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = r__1; var arg_68 any = lang.IFn_Cast(t.F_inner).Invoke_O__O(x__2); if linked_65 == nil { return ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { return linked_65.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) } }



func A_arbace_walk_postwalk_A_New() *A_arbace_walk_postwalk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_walk_postwalk_A) Ctor() {}
//line :52:1
func (t *A_arbace_walk_postwalk_A) Invoke_O_O_O__O(self, f__0, form__1 any) any {





	var root_95 any = A_arbace_walk_A_const_21.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, A_arbace_walk_walk_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_90 any = A_arbace_walk_A_const_22.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_walk_A_const_23.GetRawRoot__O(); var arg_94 any = f__0; if linked_91 == nil { arg_98 = ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { arg_98 = linked_91.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O__O(root_90, arg_93, arg_94) }; var arg_99 any = f__0; var arg_100 any = form__1; if linked_96 == nil { return ifn_97.Invoke_O_O_O__O(arg_98, arg_99, arg_100) } else { return linked_96.(*A_arbace_walk_walk_A).Invoke_O_O_O_O__O(root_95, arg_98, arg_99, arg_100)
	} }
func A_arbace_walk_prewalk_A_New() *A_arbace_walk_prewalk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_walk_prewalk_A) Ctor() {}
//line :60:1
func (t *A_arbace_walk_prewalk_A) Invoke_O_O_O__O(self, f__0, form__1 any) any {



	var root_106 any = A_arbace_walk_A_const_21.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, A_arbace_walk_walk_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var root_101 any = A_arbace_walk_A_const_22.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = A_arbace_walk_A_const_24.GetRawRoot__O(); var arg_105 any = f__0; if linked_102 == nil { arg_109 = ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { arg_109 = linked_102.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O__O(root_101, arg_104, arg_105) }; var arg_110 any = A_arbace_walk_A_const_25.GetRawRoot__O(); var arg_111 any = lang.IFn_Cast(f__0).Invoke_O__O(form__1); if linked_107 == nil { return ifn_108.Invoke_O_O_O__O(arg_109, arg_110, arg_111) } else { return linked_107.(*A_arbace_walk_walk_A).Invoke_O_O_O_O__O(root_106, arg_109, arg_110, arg_111)
	}
}










func A_arbace_walk_postwalk_demo_A_New() *A_arbace_walk_postwalk_demo_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_demo_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_walk_postwalk_demo_A) Ctor() {}
//line :77:1
func (t *A_arbace_walk_postwalk_demo_A) Invoke_O_O__O(self, form__0 any) any {




	var root_121 any = A_arbace_walk_A_const_23.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_walk_postwalk_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var tmp1 any = A_arbace_walk_postwalk_demo_fn__1869000017_A_New(); var tmp2 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class = fncls__120d; tmp2 = fncls__120d } else { tmp2 = fncls__120 }; arg_124 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_125 any = form__0; if linked_122 == nil { return ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { return linked_122.(*A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } }
//line :82:1
func A_arbace_walk_postwalk_demo_fn__1869000017_A_New() *A_arbace_walk_postwalk_demo_fn__1869000017_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_demo_fn__1869000017_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Ctor() {}
//line :82:1
func (t *A_arbace_walk_postwalk_demo_fn__1869000017_A) Invoke_O_O__O(self, x__1 any) any { lang.IFn_Cast(A_arbace_walk_A_const_26.GetRawRoot__O()).Invoke_O__O(Lit_4); lang.IFn_Cast(A_arbace_walk_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1); return x__1 }

func A_arbace_walk_prewalk_demo_A_New() *A_arbace_walk_prewalk_demo_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_demo_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_walk_prewalk_demo_A) Ctor() {}
//line :84:1
func (t *A_arbace_walk_prewalk_demo_A) Invoke_O_O__O(self, form__0 any) any {




	var root_135 any = A_arbace_walk_A_const_24.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_walk_prewalk_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any; var tmp1 any = A_arbace_walk_prewalk_demo_fn__1869000020_A_New(); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; arg_138 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_139 any = form__0; if linked_136 == nil { return ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { return linked_136.(*A_arbace_walk_prewalk_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) } }
//line :89:1
func A_arbace_walk_prewalk_demo_fn__1869000020_A_New() *A_arbace_walk_prewalk_demo_fn__1869000020_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_demo_fn__1869000020_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Ctor() {}
//line :89:1
func (t *A_arbace_walk_prewalk_demo_fn__1869000020_A) Invoke_O_O__O(self, x__1 any) any { lang.IFn_Cast(A_arbace_walk_A_const_26.GetRawRoot__O()).Invoke_O__O(Lit_4); lang.IFn_Cast(A_arbace_walk_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1); return x__1 }

func A_arbace_walk_transform_keys_A_New() *A_arbace_walk_transform_keys_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_transform_keys_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_walk_transform_keys_A) Ctor() {}
//line :91:1
func (t *A_arbace_walk_transform_keys_A) Invoke_O_O_O__O(self, m__0, f__1 any) any { var entry_f__3 any; var tmp1 any = A_arbace_walk_transform_keys_entry_f__1869000024_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class; if



	fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class = fncls__140d; tmp2 = fncls__140d } else { tmp2 = fncls__140 }; entry_f__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_156 any =

	A_arbace_walk_A_const_23.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_walk_postwalk_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any; var tmp3 any = A_arbace_walk_transform_keys_fn__1869000029_A_New_O(entry_f__3); var tmp4 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_walk_transform_keys_fn__1869000029_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_walk_transform_keys_fn__1869000029_A_fn_class = fncls__155d; tmp4 = fncls__155d } else { tmp4 = fncls__155 }; arg_159 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_160 any = m__0; if linked_157 == nil { return ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { return linked_157.(*A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) } }
//line :95:1
func A_arbace_walk_transform_keys_entry_f__1869000024_A_New_O(p0 any) *A_arbace_walk_transform_keys_entry_f__1869000024_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_transform_keys_entry_f__1869000024_A{}; t.Ctor_O(p0); return t }
//line :95:1
func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :95:1
func (t *A_arbace_walk_transform_keys_entry_f__1869000024_A) Invoke_O_O__O(self, p__1869000023__1 any) any { var vec__1869000025__2 any = p__1869000023__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1869000025__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1869000025__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(t.F_f).Invoke_O__O(k__3), v__4) }

func A_arbace_walk_transform_keys_fn__1869000029_A_New_O(p0 any) *A_arbace_walk_transform_keys_fn__1869000029_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_transform_keys_fn__1869000029_A{}; t.Ctor_O(p0); return t }
//line :97:1
func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Ctor_O(c__entry_f any) { t.F_entry_f = c__entry_f }
//line :97:1
func (t *A_arbace_walk_transform_keys_fn__1869000029_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_141 any = A_arbace_walk_A_const_28.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = x__1; if linked_142 == nil { tmp1 = ifn_143.Invoke_O__O(arg_144) } else { tmp1 = linked_142.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_141, arg_144) }; if jrt.J2g_Truth(tmp1) { var root_150 any = A_arbace_walk_A_const_19.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_154 any; var root_145 any = A_arbace_walk_A_const_14.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = t.F_entry_f; var arg_149 any = x__1; if linked_146 == nil { arg_154 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { arg_154 = linked_146.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }; if linked_151 == nil { return ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { return linked_151.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_150, arg_153, arg_154) } } else { return x__1 } }

func A_arbace_walk_keywordize_keys_A_New() *A_arbace_walk_keywordize_keys_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_keywordize_keys_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_walk_keywordize_keys_A) Ctor() {}
//line :99:1
func (t *A_arbace_walk_keywordize_keys_A) Invoke_O_O__O(self, m__0 any) any {



	var root_170 any = A_arbace_walk_A_const_29.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_walk_transform_keys_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = m__0; var arg_174 any; var tmp1 any = A_arbace_walk_keywordize_keys_fn__1869000032_A_New(); var tmp2 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class = fncls__169d; tmp2 = fncls__169d } else { tmp2 = fncls__169 }; arg_174 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_171 == nil { return ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { return linked_171.(*A_arbace_walk_transform_keys_A).Invoke_O_O_O__O(root_170, arg_173, arg_174) } }
//line :103:1
func A_arbace_walk_keywordize_keys_fn__1869000032_A_New() *A_arbace_walk_keywordize_keys_fn__1869000032_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_keywordize_keys_fn__1869000032_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Ctor() {}
//line :103:1
func (t *A_arbace_walk_keywordize_keys_fn__1869000032_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 any; var root_161 any = A_arbace_walk_A_const_30.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = k__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_161, arg_164) }; if jrt.J2g_Truth(tmp1) { var root_165 any = A_arbace_walk_A_const_31.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = k__1; if linked_166 == nil { return ifn_167.Invoke_O__O(arg_168) } else { return linked_166.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_165, arg_168) } } else { return k__1 } }

func A_arbace_walk_stringify_keys_A_New() *A_arbace_walk_stringify_keys_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_stringify_keys_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_walk_stringify_keys_A) Ctor() {}
//line :105:1
func (t *A_arbace_walk_stringify_keys_A) Invoke_O_O__O(self, m__0 any) any {



	var root_184 any = A_arbace_walk_A_const_29.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, A_arbace_walk_transform_keys_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = m__0; var arg_188 any; var tmp1 any = A_arbace_walk_stringify_keys_fn__1869000035_A_New(); var tmp2 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class; if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class = fncls__183d; tmp2 = fncls__183d } else { tmp2 = fncls__183 }; arg_188 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_185 == nil { return ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { return linked_185.(*A_arbace_walk_transform_keys_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) } }
//line :109:1
func A_arbace_walk_stringify_keys_fn__1869000035_A_New() *A_arbace_walk_stringify_keys_fn__1869000035_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_stringify_keys_fn__1869000035_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Ctor() {}
//line :109:1
func (t *A_arbace_walk_stringify_keys_fn__1869000035_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 any; var root_175 any = A_arbace_walk_A_const_32.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = k__1; if linked_176 == nil { tmp1 = ifn_177.Invoke_O__O(arg_178) } else { tmp1 = linked_176.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_175, arg_178) }; if jrt.J2g_Truth(tmp1) { var root_179 any = A_arbace_walk_A_const_33.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = k__1; if linked_180 == nil { return ifn_181.Invoke_O__O(arg_182) } else { return linked_180.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_179, arg_182) } } else { return k__1 } }

func A_arbace_walk_prewalk_replace_A_New() *A_arbace_walk_prewalk_replace_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_replace_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_walk_prewalk_replace_A) Ctor() {}
//line :111:1
func (t *A_arbace_walk_prewalk_replace_A) Invoke_O_O_O__O(self, smap__0, form__1 any) any {





	var root_195 any = A_arbace_walk_A_const_24.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, A_arbace_walk_prewalk_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var tmp1 any = A_arbace_walk_prewalk_replace_fn__1869000038_A_New_O(smap__0); var tmp2 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class = fncls__194d; tmp2 = fncls__194d } else { tmp2 = fncls__194 }; arg_198 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_199 any = form__1; if linked_196 == nil { return ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { return linked_196.(*A_arbace_walk_prewalk_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) } }
//line :117:1
func A_arbace_walk_prewalk_replace_fn__1869000038_A_New_O(p0 any) *A_arbace_walk_prewalk_replace_fn__1869000038_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_prewalk_replace_fn__1869000038_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Ctor_O(c__smap any) { t.F_smap = c__smap }
//line :117:1
func (t *A_arbace_walk_prewalk_replace_fn__1869000038_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_189 any = A_arbace_walk_A_const_34.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = t.F_smap; var arg_193 any = x__1; if linked_190 == nil { tmp1 = ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { tmp1 = linked_190.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_189, arg_192, arg_193) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(t.F_smap).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_walk_postwalk_replace_A_New() *A_arbace_walk_postwalk_replace_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_replace_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_walk_postwalk_replace_A) Ctor() {}
//line :119:1
func (t *A_arbace_walk_postwalk_replace_A) Invoke_O_O_O__O(self, smap__0, form__1 any) any {





	var root_206 any = A_arbace_walk_A_const_23.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_walk_postwalk_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var tmp1 any = A_arbace_walk_postwalk_replace_fn__1869000041_A_New_O(smap__0); var tmp2 *jrt.Class; var fncls__205 *jrt.Class = A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class; if fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class = fncls__205d; tmp2 = fncls__205d } else { tmp2 = fncls__205 }; arg_209 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_210 any = form__1; if linked_207 == nil { return ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { return linked_207.(*A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) } }
//line :125:1
func A_arbace_walk_postwalk_replace_fn__1869000041_A_New_O(p0 any) *A_arbace_walk_postwalk_replace_fn__1869000041_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_postwalk_replace_fn__1869000041_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Ctor_O(c__smap any) { t.F_smap = c__smap }
//line :125:1
func (t *A_arbace_walk_postwalk_replace_fn__1869000041_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_200 any = A_arbace_walk_A_const_34.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = t.F_smap; var arg_204 any = x__1; if linked_201 == nil { tmp1 = ifn_202.Invoke_O_O__O(arg_203, arg_204) } else { tmp1 = linked_201.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_200, arg_203, arg_204) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(t.F_smap).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_walk_macroexpand_all_A_New() *A_arbace_walk_macroexpand_all_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_macroexpand_all_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_walk_macroexpand_all_A) Ctor() {}
//line :127:1
func (t *A_arbace_walk_macroexpand_all_A) Invoke_O_O__O(self, form__0 any) any {



	var root_220 any = A_arbace_walk_A_const_24.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, A_arbace_walk_prewalk_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any; var tmp1 any = A_arbace_walk_macroexpand_all_fn__1869000044_A_New(); var tmp2 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class = fncls__219d; tmp2 = fncls__219d } else { tmp2 = fncls__219 }; arg_223 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_224 any = form__0; if linked_221 == nil { return ifn_222.Invoke_O_O__O(arg_223, arg_224) } else { return linked_221.(*A_arbace_walk_prewalk_A).Invoke_O_O_O__O(root_220, arg_223, arg_224) } }
//line :131:1
func A_arbace_walk_macroexpand_all_fn__1869000044_A_New() *A_arbace_walk_macroexpand_all_fn__1869000044_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_macroexpand_all_fn__1869000044_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Ctor() {}
//line :131:1
func (t *A_arbace_walk_macroexpand_all_fn__1869000044_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_211 any = A_arbace_walk_A_const_8.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = x__1; if linked_212 == nil { tmp1 = ifn_213.Invoke_O__O(arg_214) } else { tmp1 = linked_212.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_211, arg_214) }; if jrt.J2g_Truth(tmp1) { var root_215 any = A_arbace_walk_A_const_35.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_macroexpand_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = x__1; if linked_216 == nil { return ifn_217.Invoke_O__O(arg_218) } else { return linked_216.(*aot_arbace_core.A_arbace_core_macroexpand_A).Invoke_O_O__O(root_215, arg_218) } } else { return x__1 } }
















































type A_arbace_walk_A struct{ jrt.Object }

var A_arbace_walk_A_const_pool *jrt.RefArray

var A_arbace_walk_A_const_0 *lang.Var

var A_arbace_walk_A_const_1 any

var A_arbace_walk_A_const_2 *lang.Var

var A_arbace_walk_A_const_3 *lang.Var

var A_arbace_walk_A_const_4 *lang.Var

var A_arbace_walk_A_const_5 *lang.Var

var A_arbace_walk_A_const_6 any

var A_arbace_walk_A_const_7 *lang.Var

var A_arbace_walk_A_const_8 *lang.Var

var A_arbace_walk_A_const_9 *lang.Var

var A_arbace_walk_A_const_10 *lang.Keyword

var A_arbace_walk_A_const_11 *lang.Var

var A_arbace_walk_A_const_12 *lang.Var

var A_arbace_walk_A_const_13 *lang.Var

var A_arbace_walk_A_const_14 *lang.Var

var A_arbace_walk_A_const_15 *lang.Var

var A_arbace_walk_A_const_16 *lang.Var

var A_arbace_walk_A_const_17 *lang.Var

var A_arbace_walk_A_const_18 *lang.Var

var A_arbace_walk_A_const_19 *lang.Var

var A_arbace_walk_A_const_20 *lang.Var

var A_arbace_walk_A_const_21 *lang.Var

var A_arbace_walk_A_const_22 *lang.Var

var A_arbace_walk_A_const_23 *lang.Var

var A_arbace_walk_A_const_24 *lang.Var

var A_arbace_walk_A_const_25 *lang.Var

var A_arbace_walk_A_const_26 *lang.Var

var A_arbace_walk_A_const_27 *lang.Var

var A_arbace_walk_A_const_28 *lang.Var

var A_arbace_walk_A_const_29 *lang.Var

var A_arbace_walk_A_const_30 *lang.Var

var A_arbace_walk_A_const_31 *lang.Var

var A_arbace_walk_A_const_32 *lang.Var

var A_arbace_walk_A_const_33 *lang.Var

var A_arbace_walk_A_const_34 *lang.Var

var A_arbace_walk_A_const_35 *lang.Var

var A_arbace_walk_A_init jrt.ClassInit

func A_arbace_walk_A_Init() { if !A_arbace_walk_A_init.Done() { A_arbace_walk_A_init.Run(A_arbace_walk_A_clinit) } }

func A_arbace_walk_A_clinit() { A_arbace_walk_A_clinit_p0(); A_arbace_walk_A_clinit_p1(); A_arbace_walk_A_clinit_p2(); A_arbace_walk_A_clinit_p3() }

func A_arbace_walk_A_clinit_p0() { jrt.StartCheck(); A_arbace_walk_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 40); A_arbace_walk_A_const_0 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[4]); A_arbace_walk_A_const_1 = A_arbace_walk_A_const_pool.A[5]; A_arbace_walk_A_const_2 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[6]); A_arbace_walk_A_const_3 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[7]); A_arbace_walk_A_const_4 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[8]); A_arbace_walk_A_const_5 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[9]); A_arbace_walk_A_const_6 = A_arbace_walk_A_const_pool.A[10]; A_arbace_walk_A_const_7 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[11]); A_arbace_walk_A_const_8 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[12]); A_arbace_walk_A_const_9 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[13]); A_arbace_walk_A_const_10 = lang.Keyword_Cast(A_arbace_walk_A_const_pool.A[14]) }

func A_arbace_walk_A_clinit_p1() { A_arbace_walk_A_const_11 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[15]); A_arbace_walk_A_const_12 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[16]); A_arbace_walk_A_const_13 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[17]); A_arbace_walk_A_const_14 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[18]); A_arbace_walk_A_const_15 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[19]); A_arbace_walk_A_const_16 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[20]); A_arbace_walk_A_const_17 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[21]); A_arbace_walk_A_const_18 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[22]); A_arbace_walk_A_const_19 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[23]); A_arbace_walk_A_const_20 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[24]); A_arbace_walk_A_const_21 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[25]); A_arbace_walk_A_const_22 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[26]) }

func A_arbace_walk_A_clinit_p2() { A_arbace_walk_A_const_23 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[27]); A_arbace_walk_A_const_24 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[28]); A_arbace_walk_A_const_25 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[29]); A_arbace_walk_A_const_26 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[30]); A_arbace_walk_A_const_27 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[31]); A_arbace_walk_A_const_28 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[32]); A_arbace_walk_A_const_29 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[33]); A_arbace_walk_A_const_30 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[34]); A_arbace_walk_A_const_31 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[35]); A_arbace_walk_A_const_32 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[36]); A_arbace_walk_A_const_33 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[37]); A_arbace_walk_A_const_34 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[38]) }

func A_arbace_walk_A_clinit_p3() { A_arbace_walk_A_const_35 = lang.Var_Cast(A_arbace_walk_A_const_pool.A[39]) }

func A_arbace_walk_A_New() *A_arbace_walk_A { A_arbace_walk_A_Init(); t := &A_arbace_walk_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_A) Ctor() {}

func (t *A_arbace_walk_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_A) GetClass__Class() *jrt.Class { return A_arbace_walk_A_class }

func (t *A_arbace_walk_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_walk_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_A); return ok }

func A_arbace_walk_A_Cast(x any) *A_arbace_walk_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_A_class)) }; return v }



type A_arbace_walk_eval1869000004_A struct{ jrt.Object }

func A_arbace_walk_eval1869000004_A_New() *A_arbace_walk_eval1869000004_A { t := &A_arbace_walk_eval1869000004_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_eval1869000004_A) Ctor() {}

func (t *A_arbace_walk_eval1869000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000004_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000004_A_class }

func (t *A_arbace_walk_eval1869000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000004_A); return ok }

func A_arbace_walk_eval1869000004_A_Cast(x any) *A_arbace_walk_eval1869000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000004_A_class)) }; return v }



type A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A struct{ j2g_header uint64 }

var A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_fn_class *jrt.Class



type A_arbace_walk_eval1869000008_A struct{ jrt.Object }

func A_arbace_walk_eval1869000008_A_New() *A_arbace_walk_eval1869000008_A { t := &A_arbace_walk_eval1869000008_A{}; t.Ctor(); return t }

func (t *A_arbace_walk_eval1869000008_A) Ctor() {}

func (t *A_arbace_walk_eval1869000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk_eval1869000008_A) GetClass__Class() *jrt.Class { return A_arbace_walk_eval1869000008_A_class }

func (t *A_arbace_walk_eval1869000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk_eval1869000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_walk_eval1869000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk_eval1869000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk_eval1869000008_A); return ok }

func A_arbace_walk_eval1869000008_A_Cast(x any) *A_arbace_walk_eval1869000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk_eval1869000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk_eval1869000008_A_class)) }; return v }



type A_arbace_walk_eval1869000008_fn__1869000009_A struct{ j2g_header uint64 }

var A_arbace_walk_eval1869000008_fn__1869000009_A_fn_class *jrt.Class



type A_arbace_walk_keywordize_keys_A struct{ j2g_header uint64 }

var A_arbace_walk_keywordize_keys_A_fn_class *jrt.Class



type A_arbace_walk_keywordize_keys_fn__1869000032_A struct{ j2g_header uint64 }

var A_arbace_walk_keywordize_keys_fn__1869000032_A_fn_class *jrt.Class



type A_arbace_walk_macroexpand_all_A struct{ j2g_header uint64 }

var A_arbace_walk_macroexpand_all_A_fn_class *jrt.Class



type A_arbace_walk_macroexpand_all_fn__1869000044_A struct{ j2g_header uint64 }

var A_arbace_walk_macroexpand_all_fn__1869000044_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_A struct{ j2g_header uint64 }

var A_arbace_walk_postwalk_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_demo_A struct{ j2g_header uint64 }

var A_arbace_walk_postwalk_demo_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_demo_fn__1869000017_A struct{ j2g_header uint64 }

var A_arbace_walk_postwalk_demo_fn__1869000017_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_replace_A struct{ j2g_header uint64 }

var A_arbace_walk_postwalk_replace_A_fn_class *jrt.Class



type A_arbace_walk_postwalk_replace_fn__1869000041_A struct{ j2g_header uint64; F_smap any }

var A_arbace_walk_postwalk_replace_fn__1869000041_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_A struct{ j2g_header uint64 }

var A_arbace_walk_prewalk_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_demo_A struct{ j2g_header uint64 }

var A_arbace_walk_prewalk_demo_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_demo_fn__1869000020_A struct{ j2g_header uint64 }

var A_arbace_walk_prewalk_demo_fn__1869000020_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_replace_A struct{ j2g_header uint64 }

var A_arbace_walk_prewalk_replace_A_fn_class *jrt.Class



type A_arbace_walk_prewalk_replace_fn__1869000038_A struct{ j2g_header uint64; F_smap any }

var A_arbace_walk_prewalk_replace_fn__1869000038_A_fn_class *jrt.Class



type A_arbace_walk_stringify_keys_A struct{ j2g_header uint64 }

var A_arbace_walk_stringify_keys_A_fn_class *jrt.Class



type A_arbace_walk_stringify_keys_fn__1869000035_A struct{ j2g_header uint64 }

var A_arbace_walk_stringify_keys_fn__1869000035_A_fn_class *jrt.Class



type A_arbace_walk_transform_keys_A struct{ j2g_header uint64 }

var A_arbace_walk_transform_keys_A_fn_class *jrt.Class



type A_arbace_walk_transform_keys_entry_f__1869000024_A struct{ j2g_header uint64; F_f any }

var A_arbace_walk_transform_keys_entry_f__1869000024_A_fn_class *jrt.Class



type A_arbace_walk_transform_keys_fn__1869000029_A struct{ j2g_header uint64; F_entry_f any }

var A_arbace_walk_transform_keys_fn__1869000029_A_fn_class *jrt.Class



type A_arbace_walk_walk_A struct{ j2g_header uint64 }

var A_arbace_walk_walk_A_fn_class *jrt.Class



type A_arbace_walk_walk_fn__1869000012_A struct{ j2g_header uint64; F_inner any }

var A_arbace_walk_walk_fn__1869000012_A_fn_class *jrt.Class
