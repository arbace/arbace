//line aot_arbace_walk__init.ae:1
package aot_arbace_walk

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_walk__init_A_Load__O() any { A_arbace_walk__init_A_Init(); A_arbace_walk__init_A_Unit0__O(); A_arbace_walk__init_A_Unit1__O(); A_arbace_walk__init_A_Unit2__O(); A_arbace_walk__init_A_Unit3__O(); A_arbace_walk__init_A_Unit4__O(); A_arbace_walk__init_A_Unit5__O(); A_arbace_walk__init_A_Unit6__O(); A_arbace_walk__init_A_Unit7__O(); A_arbace_walk__init_A_Unit8__O(); A_arbace_walk__init_A_Unit9__O(); A_arbace_walk__init_A_Unit10__O(); A_arbace_walk__init_A_Unit11__O(); A_arbace_walk__init_A_Unit12__O(); A_arbace_walk__init_A_Unit13__O(); A_arbace_walk__init_A_Unit14__O(); return nil }














func A_arbace_walk__init_A_Unit0__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); return lang.IFn_Cast(jrt.NN(A_arbace_walk__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_walk__init_A_const_1) }
//line :20:1
func A_arbace_walk__init_A_Unit1__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_walk__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_2)) }
//line :20:1
func A_arbace_walk__init_A_Unit2__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 any = A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_New(); var tmp2 *jrt.Class; A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_Init(); tmp2 = A_arbace_walk_eval1869000004_loading__1927001464__auto____1869000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :20:1
func A_arbace_walk__init_A_Unit3__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_walk__init_A_const_1)).Equals_O__Z(A_arbace_walk__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_walk_eval1869000008_fn__1869000009_A_New(); var tmp2 *jrt.Class; A_arbace_walk_eval1869000008_fn__1869000009_A_Init(); tmp2 = A_arbace_walk_eval1869000008_fn__1869000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }













func A_arbace_walk__init_A_Unit4__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_4; var tmp2 any = A_arbace_walk_walk_A_New(); var tmp3 *jrt.Class; A_arbace_walk_walk_A_Init(); tmp3 = A_arbace_walk_walk_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_5)); return A_arbace_walk__init_A_const_4.Ref() }

















func A_arbace_walk__init_A_Unit5__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(52, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_6; var tmp2 any = A_arbace_walk_postwalk_A_New(); var tmp3 *jrt.Class; A_arbace_walk_postwalk_A_Init(); tmp3 = A_arbace_walk_postwalk_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_7)); return A_arbace_walk__init_A_const_6.Ref() }







func A_arbace_walk__init_A_Unit6__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_8; var tmp2 any = A_arbace_walk_prewalk_A_New(); var tmp3 *jrt.Class; A_arbace_walk_prewalk_A_Init(); tmp3 = A_arbace_walk_prewalk_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_9)); return A_arbace_walk__init_A_const_8.Ref() }
















func A_arbace_walk__init_A_Unit7__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_10; var tmp2 any = A_arbace_walk_postwalk_demo_A_New(); var tmp3 *jrt.Class; A_arbace_walk_postwalk_demo_A_Init(); tmp3 = A_arbace_walk_postwalk_demo_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_11)); return A_arbace_walk__init_A_const_10.Ref() }






func A_arbace_walk__init_A_Unit8__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(84, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_12; var tmp2 any = A_arbace_walk_prewalk_demo_A_New(); var tmp3 *jrt.Class; A_arbace_walk_prewalk_demo_A_Init(); tmp3 = A_arbace_walk_prewalk_demo_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_13)); return A_arbace_walk__init_A_const_12.Ref() }






func A_arbace_walk__init_A_Unit9__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_14; var tmp2 any = A_arbace_walk_transform_keys_A_New(); var tmp3 *jrt.Class; A_arbace_walk_transform_keys_A_Init(); tmp3 = A_arbace_walk_transform_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_15)); return A_arbace_walk__init_A_const_14.Ref() }







func A_arbace_walk__init_A_Unit10__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_16; var tmp2 any = A_arbace_walk_keywordize_keys_A_New(); var tmp3 *jrt.Class; A_arbace_walk_keywordize_keys_A_Init(); tmp3 = A_arbace_walk_keywordize_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_17)); return A_arbace_walk__init_A_const_16.Ref() }





func A_arbace_walk__init_A_Unit11__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(105, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_18; var tmp2 any = A_arbace_walk_stringify_keys_A_New(); var tmp3 *jrt.Class; A_arbace_walk_stringify_keys_A_Init(); tmp3 = A_arbace_walk_stringify_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_19)); return A_arbace_walk__init_A_const_18.Ref() }





func A_arbace_walk__init_A_Unit12__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_20; var tmp2 any = A_arbace_walk_prewalk_replace_A_New(); var tmp3 *jrt.Class; A_arbace_walk_prewalk_replace_A_Init(); tmp3 = A_arbace_walk_prewalk_replace_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_21)); return A_arbace_walk__init_A_const_20.Ref() }







func A_arbace_walk__init_A_Unit13__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(119, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_22; var tmp2 any = A_arbace_walk_postwalk_replace_A_New(); var tmp3 *jrt.Class; A_arbace_walk_postwalk_replace_A_Init(); tmp3 = A_arbace_walk_postwalk_replace_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_23)); return A_arbace_walk__init_A_const_22.Ref() }







func A_arbace_walk__init_A_Unit14__O() any { A_arbace_walk__init_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.Var = A_arbace_walk__init_A_const_24; var tmp2 any = A_arbace_walk_macroexpand_all_A_New(); var tmp3 *jrt.Class; A_arbace_walk_macroexpand_all_A_Init(); tmp3 = A_arbace_walk_macroexpand_all_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_walk__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_walk__init_A_const_25)); return A_arbace_walk__init_A_const_24.Ref() }



type A_arbace_walk__init_A struct{ jrt.Object }

var A_arbace_walk__init_A_const_0 *lang.Var

var A_arbace_walk__init_A_const_1 any

var A_arbace_walk__init_A_const_2 any

var A_arbace_walk__init_A_const_3 any

var A_arbace_walk__init_A_const_4 *lang.Var

var A_arbace_walk__init_A_const_5 any

var A_arbace_walk__init_A_const_6 *lang.Var

var A_arbace_walk__init_A_const_7 any

var A_arbace_walk__init_A_const_8 *lang.Var

var A_arbace_walk__init_A_const_9 any

var A_arbace_walk__init_A_const_10 *lang.Var

var A_arbace_walk__init_A_const_11 any

var A_arbace_walk__init_A_const_12 *lang.Var

var A_arbace_walk__init_A_const_13 any

var A_arbace_walk__init_A_const_14 *lang.Var

var A_arbace_walk__init_A_const_15 any

var A_arbace_walk__init_A_const_16 *lang.Var

var A_arbace_walk__init_A_const_17 any

var A_arbace_walk__init_A_const_18 *lang.Var

var A_arbace_walk__init_A_const_19 any

var A_arbace_walk__init_A_const_20 *lang.Var

var A_arbace_walk__init_A_const_21 any

var A_arbace_walk__init_A_const_22 *lang.Var

var A_arbace_walk__init_A_const_23 any

var A_arbace_walk__init_A_const_24 *lang.Var

var A_arbace_walk__init_A_const_25 any

var A_arbace_walk__init_A_init jrt.ClassInit

func A_arbace_walk__init_A_Init() { if !A_arbace_walk__init_A_init.Done() { A_arbace_walk__init_A_init.Run(A_arbace_walk__init_A_clinit) } }

func A_arbace_walk__init_A_clinit() { A_arbace_walk__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_walk__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_walk__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_walk__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_walk__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); A_arbace_walk__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_69, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_walk__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_77, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_5, Lit_29); A_arbace_walk__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_78, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_5, Lit_79); A_arbace_walk__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_80, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_5, Lit_81); A_arbace_walk__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_82, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(84).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_walk__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_76).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_84, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_5, Lit_86); A_arbace_walk__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_87, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_5, Lit_88); A_arbace_walk__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_89, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(105).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_5, Lit_90); A_arbace_walk__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_92, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_93); A_arbace_walk__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_94, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(119).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)); A_arbace_walk__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_5, Lit_95); A_arbace_walk__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_96, lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), jrt.Integer_ValueOf_I__Integer(127).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), Lit_75)) }

func A_arbace_walk__init_A_New() *A_arbace_walk__init_A { A_arbace_walk__init_A_Init(); t := &A_arbace_walk__init_A{}; t.Ctor(); return t }

func (t *A_arbace_walk__init_A) Ctor() {}

func (t *A_arbace_walk__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_walk__init_A) GetClass__Class() *jrt.Class { return A_arbace_walk__init_A_class }

func (t *A_arbace_walk__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_walk__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_walk__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_walk__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_walk__init_A); return ok }

func A_arbace_walk__init_A_Cast(x any) *A_arbace_walk__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_walk__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_walk__init_A_class)) }; return v }
