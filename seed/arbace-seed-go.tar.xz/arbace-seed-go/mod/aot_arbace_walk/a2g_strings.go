//line a2g_strings.ae:1
package aot_arbace_walk

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn6,authorkn3,dockn4,elsev11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn11,arbace.walkm4,R1,s13,Stuart SierraR2,s485,This file defines a generic tree walker for Clojure data\nstructures.  It takes any data structure (list, vector, map, set,\nseq), calls a function on every element, and uses the return value\nof the function in place of the original.  This makes it fairly\neasy to write recursive search-and-replace functions, as shown in\nthe examples.\n\nNote: \"walk\" supports all Clojure data structures EXCEPT maps\ncreated with sorted-map-by.  There is no (obvious) way to retrieve\nthe sorting function.v11,arbace.core13,*loaded-libs*v11,arbace.core5,list?v11,arbace.core4,seq?v11,arbace.core5,coll?R3,v11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core3,mapv11,arbace.core3,keyv11,arbace.core3,valv11,arbace.core5,doallv11,arbace.core6,reducev11,arbace.core4,intov11,arbace.core5,emptyv11,arbace.walk4,walkv11,arbace.core7,partialv11,arbace.walk8,postwalkv11,arbace.core8,identityv11,arbace.walk7,prewalkv11,arbace.core5,printv11,arbace.core3,prnv11,arbace.core4,map?v11,arbace.walk14,transform-keysv11,arbace.core7,string?v11,arbace.core7,keywordv11,arbace.core8,keyword?v11,arbace.core4,namev11,arbace.core9,contains?v11,arbace.core11,macroexpand")

var Lit_1 *jrt.String = jrt.Intern("arbace.walk$keywordize_keys$fn__1869000032")

var Lit_2 *jrt.String = jrt.Intern("arbace.walk$macroexpand_all$fn__1869000044")

var Lit_3 *jrt.String = jrt.Intern("arbace.walk$postwalk_demo$fn__1869000017")

var Lit_4 *jrt.String = jrt.Intern("Walked: ")

var Lit_5 *jrt.String = jrt.Intern("arbace.walk$postwalk_replace$fn__1869000041")

var Lit_6 *jrt.String = jrt.Intern("arbace.walk$prewalk_demo$fn__1869000020")

var Lit_7 *jrt.String = jrt.Intern("arbace.walk$prewalk_replace$fn__1869000038")

var Lit_8 *jrt.String = jrt.Intern("arbace.walk$stringify_keys$fn__1869000035")

var Lit_9 *jrt.String = jrt.Intern("arbace.walk$transform_keys$entry_f__1869000024")

var Lit_10 *jrt.String = jrt.Intern("arbace.walk$transform_keys$fn__1869000029")

var Lit_11 *jrt.String = jrt.Intern("arbace.walk$walk$fn__1869000012")

var Lit_12 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.corekn8,arglistsyn5,inneryn5,outeryn4,formkn5,addedkn4,linekn6,columnkn4,fileyn1,fyn1,myn4,smapv11,arbace.core5,in-nsMyn11,arbace.walkm4,R0,s13,Stuart SierraR1,s485,This file defines a generic tree walker for Clojure data\nstructures.  It takes any data structure (list, vector, map, set,\nseq), calls a function on every element, and uses the return value\nof the function in place of the original.  This makes it fairly\neasy to write recursive search-and-replace functions, as shown in\nthe examples.\n\nNote: \"walk\" supports all Clojure data structures EXCEPT maps\ncreated with sorted-map-by.  There is no (obvious) way to retrieve\nthe sorting function.m4,R0,s13,Stuart SierraR1,s485,This file defines a generic tree walker for Clojure data\nstructures.  It takes any data structure (list, vector, map, set,\nseq), calls a function on every element, and uses the return value\nof the function in place of the original.  This makes it fairly\neasy to write recursive search-and-replace functions, as shown in\nthe examples.\n\nNote: \"walk\" supports all Clojure data structures EXCEPT maps\ncreated with sorted-map-by.  There is no (obvious) way to retrieve\nthe sorting function.R2,v11,arbace.walk4,walkm12,R3,L1,V3,R4,R5,R6,R1,s272,Traverses form, an arbitrary data structure.  inner and outer are\n  functions.  Applies inner to each element of form, building up a\n  data structure of the same type, then applies outer to the result.\n  Recognizes all Clojure data structures. Consumes seqs as with doall.R7,s3,1.1R8,i34,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk8,postwalkm12,R3,L1,V2,R11,R6,R1,s201,Performs a depth-first, post-order traversal of form.  Calls f on\n  each sub-form, uses f's return value in place of the original.\n  Recognizes all Clojure data structures. Consumes seqs as with doall.R7,s3,1.1R8,i52,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk7,prewalkm12,R3,L1,V2,R11,R6,R1,s44,Like postwalk, but does pre-order traversal.R7,s3,1.1R8,i60,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk13,postwalk-demom12,R3,L1,V1,R6,R1,s93,Demonstrates the behavior of postwalk by printing each form as it is\n  walked.  Returns form.R7,s3,1.1R8,i77,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk12,prewalk-demom12,R3,L1,V1,R6,R1,s92,Demonstrates the behavior of prewalk by printing each form as it is\n  walked.  Returns form.R7,s3,1.1R8,i84,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk14,transform-keysm12,R3,L1,V2,R12,R11,R1,s72,Recursively transform all map keys using f as a transformation function.R7,s4,1.13R8,i91,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk15,keywordize-keysm12,R3,L1,V1,R12,R1,s61,Recursively transforms all map keys from strings to keywords.R7,s3,1.1R8,i99,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk14,stringify-keysm12,R3,L1,V1,R12,R1,s61,Recursively transforms all map keys from keywords to strings.R7,s3,1.1R8,i105,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk15,prewalk-replacem12,R3,L1,V2,R13,R6,R1,s180,Recursively transforms form by replacing keys in smap with their\n  values.  Like clojure/replace but works on any data structure.  Does\n  replacement at the root of the tree first.R7,s3,1.1R8,i111,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk16,postwalk-replacem12,R3,L1,V2,R13,R6,R1,s182,Recursively transforms form by replacing keys in smap with their\n  values.  Like clojure/replace but works on any data structure.  Does\n  replacement at the leaves of the tree first.R7,s3,1.1R8,i119,R9,i1,R10,s14,arbace/walk.aev11,arbace.walk15,macroexpand-allm12,R3,L1,V1,R6,R1,s58,Recursively performs all possible macroexpansions in form.R7,s3,1.1R8,i127,R9,i1,R10,s14,arbace/walk.ae")

var Lit_13 *jrt.String = jrt.Intern("arbace.walk$eval1869000004$loading__1927001464__auto____1869000005")

var Lit_14 *jrt.String = jrt.Intern("arbace.walk$eval1869000008$fn__1869000009")

var Lit_15 *jrt.String = jrt.Intern("arbace.walk$walk")

var Lit_16 *jrt.String = jrt.Intern("arbace.walk$postwalk")

var Lit_17 *jrt.String = jrt.Intern("arbace.walk$prewalk")

var Lit_18 *jrt.String = jrt.Intern("arbace.walk$postwalk_demo")

var Lit_19 *jrt.String = jrt.Intern("arbace.walk$prewalk_demo")

var Lit_20 *jrt.String = jrt.Intern("arbace.walk$transform_keys")

var Lit_21 *jrt.String = jrt.Intern("arbace.walk$keywordize_keys")

var Lit_22 *jrt.String = jrt.Intern("arbace.walk$stringify_keys")

var Lit_23 *jrt.String = jrt.Intern("arbace.walk$prewalk_replace")

var Lit_24 *jrt.String = jrt.Intern("arbace.walk$postwalk_replace")

var Lit_25 *jrt.String = jrt.Intern("arbace.walk$macroexpand_all")
