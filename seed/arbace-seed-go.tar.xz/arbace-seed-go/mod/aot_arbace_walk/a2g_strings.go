//line a2g_strings.ae:1
package aot_arbace_walk

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.walk")

var Lit_6 *jrt.String = jrt.Intern("author")

var Lit_7 *jrt.String = jrt.Intern("Stuart Sierra")

var Lit_8 *jrt.String = jrt.Intern("doc")

var Lit_9 *jrt.String = jrt.Intern("This file defines a generic tree walker for Clojure data\nstructures.  It takes any data structure (list, vector, map, set,\nseq), calls a function on every element, and uses the return value\nof the function in place of the original.  This makes it fairly\neasy to write recursive search-and-replace functions, as shown in\nthe examples.\n\nNote: \"walk\" supports all Clojure data structures EXCEPT maps\ncreated with sorted-map-by.  There is no (obvious) way to retrieve\nthe sorting function.")

var Lit_10 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_11 *jrt.String = jrt.Intern("list?")

var Lit_12 *jrt.String = jrt.Intern("seq?")

var Lit_13 *jrt.String = jrt.Intern("coll?")

var Lit_14 *jrt.String = jrt.Intern("else")

var Lit_15 *jrt.String = jrt.Intern("with-meta")

var Lit_16 *jrt.String = jrt.Intern("apply")

var Lit_17 *jrt.String = jrt.Intern("list")

var Lit_18 *jrt.String = jrt.Intern("map")

var Lit_19 *jrt.String = jrt.Intern("key")

var Lit_20 *jrt.String = jrt.Intern("val")

var Lit_21 *jrt.String = jrt.Intern("doall")

var Lit_22 *jrt.String = jrt.Intern("reduce")

var Lit_23 *jrt.String = jrt.Intern("into")

var Lit_24 *jrt.String = jrt.Intern("empty")

var Lit_25 *jrt.String = jrt.Intern("walk")

var Lit_26 *jrt.String = jrt.Intern("partial")

var Lit_27 *jrt.String = jrt.Intern("postwalk")

var Lit_28 *jrt.String = jrt.Intern("identity")

var Lit_29 *jrt.String = jrt.Intern("prewalk")

var Lit_30 *jrt.String = jrt.Intern("print")

var Lit_31 *jrt.String = jrt.Intern("prn")

var Lit_32 *jrt.String = jrt.Intern("map?")

var Lit_33 *jrt.String = jrt.Intern("transform-keys")

var Lit_34 *jrt.String = jrt.Intern("string?")

var Lit_35 *jrt.String = jrt.Intern("keyword")

var Lit_36 *jrt.String = jrt.Intern("keyword?")

var Lit_37 *jrt.String = jrt.Intern("name")

var Lit_38 *jrt.String = jrt.Intern("contains?")

var Lit_39 *jrt.String = jrt.Intern("macroexpand")

var Lit_40 *jrt.String = jrt.Intern("arbace.walk$eval1869000004$loading__1927001464__auto____1869000005")

var Lit_41 *jrt.String = jrt.Intern("arbace.walk$eval1869000008$fn__1869000009")

var Lit_42 *jrt.String = jrt.Intern("arbace.walk$keywordize_keys")

var Lit_43 *jrt.String = jrt.Intern("arbace.walk$keywordize_keys$fn__1869000032")

var Lit_44 *jrt.String = jrt.Intern("arbace.walk$macroexpand_all")

var Lit_45 *jrt.String = jrt.Intern("arbace.walk$macroexpand_all$fn__1869000044")

var Lit_46 *jrt.String = jrt.Intern("arbace.walk$postwalk")

var Lit_47 *jrt.String = jrt.Intern("arbace.walk$postwalk_demo")

var Lit_48 *jrt.String = jrt.Intern("arbace.walk$postwalk_demo$fn__1869000017")

var Lit_49 *jrt.String = jrt.Intern("Walked: ")

var Lit_50 *jrt.String = jrt.Intern("arbace.walk$postwalk_replace")

var Lit_51 *jrt.String = jrt.Intern("arbace.walk$postwalk_replace$fn__1869000041")

var Lit_52 *jrt.String = jrt.Intern("arbace.walk$prewalk")

var Lit_53 *jrt.String = jrt.Intern("arbace.walk$prewalk_demo")

var Lit_54 *jrt.String = jrt.Intern("arbace.walk$prewalk_demo$fn__1869000020")

var Lit_55 *jrt.String = jrt.Intern("arbace.walk$prewalk_replace")

var Lit_56 *jrt.String = jrt.Intern("arbace.walk$prewalk_replace$fn__1869000038")

var Lit_57 *jrt.String = jrt.Intern("arbace.walk$stringify_keys")

var Lit_58 *jrt.String = jrt.Intern("arbace.walk$stringify_keys$fn__1869000035")

var Lit_59 *jrt.String = jrt.Intern("arbace.walk$transform_keys")

var Lit_60 *jrt.String = jrt.Intern("arbace.walk$transform_keys$entry_f__1869000024")

var Lit_61 *jrt.String = jrt.Intern("arbace.walk$transform_keys$fn__1869000029")

var Lit_62 *jrt.String = jrt.Intern("arbace.walk$walk")

var Lit_63 *jrt.String = jrt.Intern("arbace.walk$walk$fn__1869000012")

var Lit_64 *jrt.String = jrt.Intern("in-ns")

var Lit_65 *jrt.String = jrt.Intern("arglists")

var Lit_66 *jrt.String = jrt.Intern("inner")

var Lit_67 *jrt.String = jrt.Intern("outer")

var Lit_68 *jrt.String = jrt.Intern("form")

var Lit_69 *jrt.String = jrt.Intern("Traverses form, an arbitrary data structure.  inner and outer are\n  functions.  Applies inner to each element of form, building up a\n  data structure of the same type, then applies outer to the result.\n  Recognizes all Clojure data structures. Consumes seqs as with doall.")

var Lit_70 *jrt.String = jrt.Intern("added")

var Lit_71 *jrt.String = jrt.Intern("1.1")

var Lit_72 *jrt.String = jrt.Intern("line")

var Lit_73 *jrt.String = jrt.Intern("column")

var Lit_74 *jrt.String = jrt.Intern("file")

var Lit_75 *jrt.String = jrt.Intern("arbace/walk.ae")

var Lit_76 *jrt.String = jrt.Intern("f")

var Lit_77 *jrt.String = jrt.Intern("Performs a depth-first, post-order traversal of form.  Calls f on\n  each sub-form, uses f's return value in place of the original.\n  Recognizes all Clojure data structures. Consumes seqs as with doall.")

var Lit_78 *jrt.String = jrt.Intern("Like postwalk, but does pre-order traversal.")

var Lit_79 *jrt.String = jrt.Intern("postwalk-demo")

var Lit_80 *jrt.String = jrt.Intern("Demonstrates the behavior of postwalk by printing each form as it is\n  walked.  Returns form.")

var Lit_81 *jrt.String = jrt.Intern("prewalk-demo")

var Lit_82 *jrt.String = jrt.Intern("Demonstrates the behavior of prewalk by printing each form as it is\n  walked.  Returns form.")

var Lit_83 *jrt.String = jrt.Intern("m")

var Lit_84 *jrt.String = jrt.Intern("Recursively transform all map keys using f as a transformation function.")

var Lit_85 *jrt.String = jrt.Intern("1.13")

var Lit_86 *jrt.String = jrt.Intern("keywordize-keys")

var Lit_87 *jrt.String = jrt.Intern("Recursively transforms all map keys from strings to keywords.")

var Lit_88 *jrt.String = jrt.Intern("stringify-keys")

var Lit_89 *jrt.String = jrt.Intern("Recursively transforms all map keys from keywords to strings.")

var Lit_90 *jrt.String = jrt.Intern("prewalk-replace")

var Lit_91 *jrt.String = jrt.Intern("smap")

var Lit_92 *jrt.String = jrt.Intern("Recursively transforms form by replacing keys in smap with their\n  values.  Like clojure/replace but works on any data structure.  Does\n  replacement at the root of the tree first.")

var Lit_93 *jrt.String = jrt.Intern("postwalk-replace")

var Lit_94 *jrt.String = jrt.Intern("Recursively transforms form by replacing keys in smap with their\n  values.  Like clojure/replace but works on any data structure.  Does\n  replacement at the leaves of the tree first.")

var Lit_95 *jrt.String = jrt.Intern("macroexpand-all")

var Lit_96 *jrt.String = jrt.Intern("Recursively performs all possible macroexpansions in form.")
