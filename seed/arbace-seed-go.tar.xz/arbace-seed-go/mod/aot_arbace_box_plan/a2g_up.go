//line a2g_up.ae:1
package aot_arbace_box_plan

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func Up_Keyword_IFn(p *lang.Keyword) lang.IFn { if p == nil { return nil }; return p }

func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }

func Up_Integer_Number(p *jrt.Integer) jrt.Number_I { if p == nil { return nil }; return p }
