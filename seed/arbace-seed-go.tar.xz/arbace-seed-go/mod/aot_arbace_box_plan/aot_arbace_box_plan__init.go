//line aot_arbace_box_plan__init.ae:1
package aot_arbace_box_plan

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_plan__init_A_Unit0__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return lang.IFn_Cast(jrt.NN(A_arbace_box_plan__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_box_plan__init_A_const_1) }
//line :4:1
func A_arbace_box_plan__init_A_Unit1__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_box_plan__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_2)) }
//line :4:1
func A_arbace_box_plan__init_A_Unit2__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); var tmp1 any = A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_New(); var tmp2 *jrt.Class; A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_Init(); tmp2 = A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :4:1
func A_arbace_box_plan__init_A_Unit3__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_plan__init_A_const_1)).Equals_O__Z(A_arbace_box_plan__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_plan_eval1305000008_fn__1305000009_A_New(); var tmp2 *jrt.Class; A_arbace_box_plan_eval1305000008_fn__1305000009_A_Init(); tmp2 = A_arbace_box_plan_eval1305000008_fn__1305000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
func A_arbace_box_plan__init_A_Load__O() any { A_arbace_box_plan__init_A_Init(); A_arbace_box_plan__init_A_Unit0__O(); A_arbace_box_plan__init_A_Unit1__O(); A_arbace_box_plan__init_A_Unit2__O(); A_arbace_box_plan__init_A_Unit3__O(); A_arbace_box_plan__init_A_Unit4__O(); A_arbace_box_plan__init_A_Unit5__O(); A_arbace_box_plan__init_A_Unit6__O(); A_arbace_box_plan__init_A_Unit7__O(); A_arbace_box_plan__init_A_Unit8__O(); A_arbace_box_plan__init_A_Unit9__O(); A_arbace_box_plan__init_A_Unit10__O(); A_arbace_box_plan__init_A_Unit11__O(); A_arbace_box_plan__init_A_Unit12__O(); A_arbace_box_plan__init_A_Unit13__O(); A_arbace_box_plan__init_A_Unit14__O(); A_arbace_box_plan__init_A_Unit15__O(); A_arbace_box_plan__init_A_Unit16__O(); A_arbace_box_plan__init_A_Unit17__O(); A_arbace_box_plan__init_A_Unit18__O(); A_arbace_box_plan__init_A_Unit19__O(); A_arbace_box_plan__init_A_Unit20__O(); A_arbace_box_plan__init_A_Unit21__O(); A_arbace_box_plan__init_A_Unit22__O(); A_arbace_box_plan__init_A_Unit23__O(); A_arbace_box_plan__init_A_Unit24__O(); return nil }





























func A_arbace_box_plan__init_A_Unit4__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_4; var tmp2 any = A_arbace_box_plan_fail_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_fail_A_Init(); tmp3 = A_arbace_box_plan_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_5)); return A_arbace_box_plan__init_A_const_4.Ref() }





func A_arbace_box_plan__init_A_Unit5__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); jrt.NN(A_arbace_box_plan__init_A_const_6).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_7)); return jrt.NN(A_arbace_box_plan__init_A_const_6).SetDynamic_Z__Var(true).Ref() }

func A_arbace_box_plan__init_A_Unit6__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_8; var tmp2 any = A_arbace_box_plan_entries_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_entries_A_Init(); tmp3 = A_arbace_box_plan_entries_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_9)); return A_arbace_box_plan__init_A_const_8.Ref() }







func A_arbace_box_plan__init_A_Unit7__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_10; var tmp2 any = A_arbace_box_plan_dir_at_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_dir_at_A_Init(); tmp3 = A_arbace_box_plan_dir_at_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_11)); return A_arbace_box_plan__init_A_const_10.Ref() }








func A_arbace_box_plan__init_A_Unit8__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_12; var tmp2 any = A_arbace_box_plan_text_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_text_A_Init(); tmp3 = A_arbace_box_plan_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_13)); return A_arbace_box_plan__init_A_const_12.Ref() }





func A_arbace_box_plan__init_A_Unit9__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); jrt.NN(A_arbace_box_plan__init_A_const_14).BindRoot_O__V(A_arbace_box_plan__init_A_const_15); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_14; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_16)); return A_arbace_box_plan__init_A_const_14.Ref() }



func A_arbace_box_plan__init_A_Unit10__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); jrt.NN(A_arbace_box_plan__init_A_const_17).BindRoot_O__V(A_arbace_box_plan__init_A_const_18); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_17; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_19)); return A_arbace_box_plan__init_A_const_17.Ref() }



func A_arbace_box_plan__init_A_Unit11__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); jrt.NN(A_arbace_box_plan__init_A_const_20).BindRoot_O__V(A_arbace_box_plan__init_A_const_21); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_20; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_22)); return A_arbace_box_plan__init_A_const_20.Ref() }




func A_arbace_box_plan__init_A_Unit12__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(79, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_23; var tmp2 any = A_arbace_box_plan_tag_fn_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_tag_fn_A_Init(); tmp3 = A_arbace_box_plan_tag_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_24)); return A_arbace_box_plan__init_A_const_23.Ref() }








func A_arbace_box_plan__init_A_Unit13__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(88, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_25; var tmp2 any = A_arbace_box_plan_name_ok_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_name_ok_QMARK__A_Init(); tmp3 = A_arbace_box_plan_name_ok_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_26)); return A_arbace_box_plan__init_A_const_25.Ref() }















func A_arbace_box_plan__init_A_Unit14__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(104, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_27; var tmp2 any = A_arbace_box_plan_expr_tokens_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_expr_tokens_A_Init(); tmp3 = A_arbace_box_plan_expr_tokens_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_28)); return A_arbace_box_plan__init_A_const_27.Ref() }


func A_arbace_box_plan__init_A_Unit15__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_29; var tmp2 any = A_arbace_box_plan_eval_expr_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_eval_expr_A_Init(); tmp3 = A_arbace_box_plan_eval_expr_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_30)); return A_arbace_box_plan__init_A_const_29.Ref() }
















func A_arbace_box_plan__init_A_Unit16__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_31; var tmp2 any = A_arbace_box_plan_header_build_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_header_build_A_Init(); tmp3 = A_arbace_box_plan_header_build_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_32)); return A_arbace_box_plan__init_A_const_31.Ref() }



















func A_arbace_box_plan__init_A_Unit17__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_33; var tmp2 any = A_arbace_box_plan_go_tokens_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_go_tokens_A_Init(); tmp3 = A_arbace_box_plan_go_tokens_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_33; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_34)); return A_arbace_box_plan__init_A_const_33.Ref() }





































func A_arbace_box_plan__init_A_Unit18__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_35; var tmp2 any = A_arbace_box_plan_go_info_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_go_info_A_Init(); tmp3 = A_arbace_box_plan_go_info_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_36)); return A_arbace_box_plan__init_A_const_35.Ref() }



























func A_arbace_box_plan__init_A_Unit19__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(210, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_37; var tmp2 any = A_arbace_box_plan_go_mod_lang_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_go_mod_lang_A_Init(); tmp3 = A_arbace_box_plan_go_mod_lang_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_38)); return A_arbace_box_plan__init_A_const_37.Ref() }






func A_arbace_box_plan__init_A_Unit20__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(217, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_39; var tmp2 any = A_arbace_box_plan_locate_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_locate_A_Init(); tmp3 = A_arbace_box_plan_locate_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_40)); return A_arbace_box_plan__init_A_const_39.Ref() }




















func A_arbace_box_plan__init_A_Unit21__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(238, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_41; var tmp2 any = A_arbace_box_plan_embed_files_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_embed_files_A_Init(); tmp3 = A_arbace_box_plan_embed_files_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_42)); return A_arbace_box_plan__init_A_const_41.Ref() }



















func A_arbace_box_plan__init_A_Unit22__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(258, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_43; var tmp2 any = A_arbace_box_plan_package_info_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_package_info_A_Init(); tmp3 = A_arbace_box_plan_package_info_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_44)); return A_arbace_box_plan__init_A_const_43.Ref() }





































func A_arbace_box_plan__init_A_Unit23__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(296, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_45; var tmp2 any = A_arbace_box_plan_src_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_src_tree_A_Init(); tmp3 = A_arbace_box_plan_src_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_46)); return A_arbace_box_plan__init_A_const_45.Ref() }




















func A_arbace_box_plan__init_A_Unit24__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V(317, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_47; var tmp2 any = A_arbace_box_plan_plan_A_New(); var tmp3 *jrt.Class; A_arbace_box_plan_plan_A_Init(); tmp3 = A_arbace_box_plan_plan_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_48)); return A_arbace_box_plan__init_A_const_47.Ref() }



type A_arbace_box_plan__init_A struct{ jrt.Object }

var A_arbace_box_plan__init_A_const_0 *lang.Var

var A_arbace_box_plan__init_A_const_1 any

var A_arbace_box_plan__init_A_const_2 any

var A_arbace_box_plan__init_A_const_3 any

var A_arbace_box_plan__init_A_const_4 *lang.Var

var A_arbace_box_plan__init_A_const_5 any

var A_arbace_box_plan__init_A_const_6 *lang.Var

var A_arbace_box_plan__init_A_const_7 any

var A_arbace_box_plan__init_A_const_8 *lang.Var

var A_arbace_box_plan__init_A_const_9 any

var A_arbace_box_plan__init_A_const_10 *lang.Var

var A_arbace_box_plan__init_A_const_11 any

var A_arbace_box_plan__init_A_const_12 *lang.Var

var A_arbace_box_plan__init_A_const_13 any

var A_arbace_box_plan__init_A_const_14 *lang.Var

var A_arbace_box_plan__init_A_const_15 any

var A_arbace_box_plan__init_A_const_16 any

var A_arbace_box_plan__init_A_const_17 *lang.Var

var A_arbace_box_plan__init_A_const_18 any

var A_arbace_box_plan__init_A_const_19 any

var A_arbace_box_plan__init_A_const_20 *lang.Var

var A_arbace_box_plan__init_A_const_21 any

var A_arbace_box_plan__init_A_const_22 any

var A_arbace_box_plan__init_A_const_23 *lang.Var

var A_arbace_box_plan__init_A_const_24 any

var A_arbace_box_plan__init_A_const_25 *lang.Var

var A_arbace_box_plan__init_A_const_26 any

var A_arbace_box_plan__init_A_const_27 *lang.Var

var A_arbace_box_plan__init_A_const_28 any

var A_arbace_box_plan__init_A_const_29 *lang.Var

var A_arbace_box_plan__init_A_const_30 any

var A_arbace_box_plan__init_A_const_31 *lang.Var

var A_arbace_box_plan__init_A_const_32 any

var A_arbace_box_plan__init_A_const_33 *lang.Var

var A_arbace_box_plan__init_A_const_34 any

var A_arbace_box_plan__init_A_const_35 *lang.Var

var A_arbace_box_plan__init_A_const_36 any

var A_arbace_box_plan__init_A_const_37 *lang.Var

var A_arbace_box_plan__init_A_const_38 any

var A_arbace_box_plan__init_A_const_39 *lang.Var

var A_arbace_box_plan__init_A_const_40 any

var A_arbace_box_plan__init_A_const_41 *lang.Var

var A_arbace_box_plan__init_A_const_42 any

var A_arbace_box_plan__init_A_const_43 *lang.Var

var A_arbace_box_plan__init_A_const_44 any

var A_arbace_box_plan__init_A_const_45 *lang.Var

var A_arbace_box_plan__init_A_const_46 any

var A_arbace_box_plan__init_A_const_47 *lang.Var

var A_arbace_box_plan__init_A_const_48 any

var A_arbace_box_plan__init_A_init jrt.ClassInit

func A_arbace_box_plan__init_A_Init() { if !A_arbace_box_plan__init_A_init.Done() { A_arbace_box_plan__init_A_init.Run(A_arbace_box_plan__init_A_clinit) } }

func A_arbace_box_plan__init_A_clinit() { A_arbace_box_plan__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_275); A_arbace_box_plan__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_box_plan__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_box_plan__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_plan__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_19); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_box_plan__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_278).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_279).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_284).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_box_plan__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_11, Lit_23); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_box_plan__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_285).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_286, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_96); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_box_plan__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_285).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_287)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_290, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(51).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_92); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_box_plan__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_53).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_285).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_49); A_arbace_box_plan__init_A_const_15 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,19,s2:jss7:freebsds7:openbsds4:nacls6:wasip1s5:linuxs6:tamagos6:darwins5:plan9s7:windowss3:aixs3:zoss7:solariss3:ioss4:hurds9:dragonflys7:illumoss6:netbsds7:android", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_box_plan__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_11, Lit_44); A_arbace_box_plan__init_A_const_18 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,12,s7:freebsds7:openbsds5:linuxs6:darwins3:aixs7:solariss3:ioss4:hurds9:dragonflys7:illumoss6:netbsds7:android", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_box_plan__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_11, Lit_50); A_arbace_box_plan__init_A_const_21 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,24,s7:arm64bes7:riscv64s11:mips64p32les7:ppc64les5:sparcs5:amd64s3:arms3:386s7:sparc64s4:mipss5:armbes5:s390xs9:mips64p32s5:ppc64s5:riscvs7:loong64s3:ppcs5:arm64s4:s390s4:wasms8:mips64les8:amd64p32s6:mipsles6:mips64", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_box_plan__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(74).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_11, Lit_138); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_box_plan__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_291).Ref(), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_292, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(79).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_11, Lit_111); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_box_plan__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_293).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_294)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_295, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(88).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_61); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_box_plan__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(104).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_11, Lit_119); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_box_plan__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_293).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_296, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(107).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_11, Lit_118); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_box_plan__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_297, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_11, Lit_86); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_box_plan__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_298, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(144).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_11, Lit_120); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_box_plan__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_299).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_300, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(182).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_11, Lit_99); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_box_plan__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_285).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_301, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(210).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_11, Lit_139); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_box_plan__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_287).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_303).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_304, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(217).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_11, Lit_133); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_box_plan__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_305).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_306)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_299).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_307, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(238).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_11, Lit_140); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_box_plan__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_293).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_287).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_291).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_308, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(258).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_11, Lit_153); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_276).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_box_plan__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_291).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_309, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(296).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)); A_arbace_box_plan__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_11, Lit_310); A_arbace_box_plan__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_277).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_311, lang.RT_Keyword_String_String__Keyword(nil, Lit_280).Ref(), jrt.Integer_ValueOf_I__Integer(317).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_281).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_282).Ref(), Lit_283)) }

func A_arbace_box_plan__init_A_New() *A_arbace_box_plan__init_A { A_arbace_box_plan__init_A_Init(); t := &A_arbace_box_plan__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan__init_A) Ctor() {}

func (t *A_arbace_box_plan__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan__init_A_class }

func (t *A_arbace_box_plan__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_plan__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan__init_A); return ok }

func A_arbace_box_plan__init_A_Cast(x any) *A_arbace_box_plan__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan__init_A_class)) }; return v }
