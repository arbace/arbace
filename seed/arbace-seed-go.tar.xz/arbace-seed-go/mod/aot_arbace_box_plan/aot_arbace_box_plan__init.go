//line aot_arbace_box_plan__init.ae:1
package aot_arbace_box_plan

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_plan__init_A_Load__O() any { A_arbace_box_plan__init_A_Init(); jrt.StartCheck(); A_arbace_box_plan__init_A_Unit0__O(); A_arbace_box_plan__init_A_Unit1__O(); A_arbace_box_plan__init_A_Unit2__O(); A_arbace_box_plan__init_A_Unit3__O(); A_arbace_box_plan__init_A_Unit4__O(); A_arbace_box_plan__init_A_Unit5__O(); A_arbace_box_plan__init_A_Unit6__O(); A_arbace_box_plan__init_A_Unit7__O(); A_arbace_box_plan__init_A_Unit8__O(); A_arbace_box_plan__init_A_Unit9__O(); A_arbace_box_plan__init_A_Unit10__O(); A_arbace_box_plan__init_A_Unit11__O(); A_arbace_box_plan__init_A_Unit12__O(); A_arbace_box_plan__init_A_Unit13__O(); A_arbace_box_plan__init_A_Unit14__O(); A_arbace_box_plan__init_A_Unit15__O(); A_arbace_box_plan__init_A_Unit16__O(); A_arbace_box_plan__init_A_Unit17__O(); A_arbace_box_plan__init_A_Unit18__O(); A_arbace_box_plan__init_A_Unit19__O(); A_arbace_box_plan__init_A_Unit20__O(); A_arbace_box_plan__init_A_Unit21__O(); A_arbace_box_plan__init_A_Unit22__O(); A_arbace_box_plan__init_A_Unit23__O(); A_arbace_box_plan__init_A_Unit24__O(); A_arbace_box_plan__init_A_Unit25__O(); A_arbace_box_plan__init_A_Unit26__O(); A_arbace_box_plan__init_A_Unit27__O(); A_arbace_box_plan__init_A_Unit28__O(); A_arbace_box_plan__init_A_Unit29__O(); A_arbace_box_plan__init_A_Unit30__O(); A_arbace_box_plan__init_A_Unit31__O(); A_arbace_box_plan__init_A_Unit32__O(); A_arbace_box_plan__init_A_Unit33__O(); A_arbace_box_plan__init_A_Unit34__O(); A_arbace_box_plan__init_A_Unit35__O(); A_arbace_box_plan__init_A_Unit36__O(); A_arbace_box_plan__init_A_Unit37__O(); A_arbace_box_plan__init_A_Unit38__O(); A_arbace_box_plan__init_A_Unit39__O(); A_arbace_box_plan__init_A_Unit40__O(); A_arbace_box_plan__init_A_Unit41__O(); A_arbace_box_plan__init_A_Unit42__O(); A_arbace_box_plan__init_A_Unit43__O(); A_arbace_box_plan__init_A_Unit44__O(); A_arbace_box_plan__init_A_Unit45__O(); A_arbace_box_plan__init_A_Unit46__O(); A_arbace_box_plan__init_A_Unit47__O(); A_arbace_box_plan__init_A_Unit48__O(); A_arbace_box_plan__init_A_Unit49__O(); A_arbace_box_plan__init_A_Unit50__O(); A_arbace_box_plan__init_A_Unit51__O(); A_arbace_box_plan__init_A_Unit52__O(); A_arbace_box_plan__init_A_Unit53__O(); A_arbace_box_plan__init_A_Unit54__O(); A_arbace_box_plan__init_A_Unit55__O(); A_arbace_box_plan__init_A_Unit56__O(); A_arbace_box_plan__init_A_Unit57__O(); A_arbace_box_plan__init_A_Unit58__O(); A_arbace_box_plan__init_A_Unit59__O(); A_arbace_box_plan__init_A_Unit60__O(); A_arbace_box_plan__init_A_Unit61__O(); A_arbace_box_plan__init_A_Unit62__O(); A_arbace_box_plan__init_A_Unit63__O(); A_arbace_box_plan__init_A_Unit64__O(); A_arbace_box_plan__init_A_Unit65__O(); A_arbace_box_plan__init_A_Unit66__O(); A_arbace_box_plan__init_A_Unit67__O(); A_arbace_box_plan__init_A_Unit68__O(); A_arbace_box_plan__init_A_Unit69__O(); A_arbace_box_plan__init_A_Unit70__O(); A_arbace_box_plan__init_A_Unit71__O(); A_arbace_box_plan__init_A_Unit72__O(); A_arbace_box_plan__init_A_Unit73__O(); return nil }
func A_arbace_box_plan__init_A_Unit0__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6, 1); return lang.IFn_Cast(A_arbace_box_plan__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_plan__init_A_const_1) }
//line :6:1
func A_arbace_box_plan__init_A_Unit1__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_box_plan__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_2)) }
//line :6:1
func A_arbace_box_plan__init_A_Unit2__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6, 1); var tmp1 any = A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_247, false); A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :6:1
func A_arbace_box_plan__init_A_Unit3__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(6, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_plan__init_A_const_1)).Equals_O__Z(A_arbace_box_plan__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_plan_eval1305000008_fn__1305000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_box_plan_eval1305000008_fn__1305000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_248, false); A_arbace_box_plan_eval1305000008_fn__1305000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }









































func A_arbace_box_plan__init_A_Unit4__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_4; var tmp2 any = A_arbace_box_plan_fail_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_box_plan_fail_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_249, false); A_arbace_box_plan_fail_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_5)); return A_arbace_box_plan__init_A_const_4 }





func A_arbace_box_plan__init_A_Unit5__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); A_arbace_box_plan__init_A_const_6.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_7)); return A_arbace_box_plan__init_A_const_6.SetDynamic_Z__Var(true).Ref() }

func A_arbace_box_plan__init_A_Unit6__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_8; var tmp2 any = A_arbace_box_plan_read_entries_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_box_plan_read_entries_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_250, false); A_arbace_box_plan_read_entries_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_9)); return A_arbace_box_plan__init_A_const_8 }









func A_arbace_box_plan__init_A_Unit7__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_10; var tmp2 any = A_arbace_box_plan_entries_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_box_plan_entries_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_251, false); A_arbace_box_plan_entries_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_11)); return A_arbace_box_plan__init_A_const_10 }








func A_arbace_box_plan__init_A_Unit8__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_12; var tmp2 any = A_arbace_box_plan_dir_at_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_box_plan_dir_at_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_252, false); A_arbace_box_plan_dir_at_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_13)); return A_arbace_box_plan__init_A_const_12 }








func A_arbace_box_plan__init_A_Unit9__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_14; var tmp2 any = A_arbace_box_plan_text_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_box_plan_text_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_253, false); A_arbace_box_plan_text_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_15)); return A_arbace_box_plan__init_A_const_14 }






func A_arbace_box_plan__init_A_Unit10__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_16; var tmp2 any = A_arbace_box_plan_sorted_entries_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_box_plan_sorted_entries_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_254, false); A_arbace_box_plan_sorted_entries_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_17)); return A_arbace_box_plan__init_A_const_16 }

func A_arbace_box_plan__init_A_Unit11__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); A_arbace_box_plan__init_A_const_18.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_19)); return A_arbace_box_plan__init_A_const_18.SetDynamic_Z__Var(true).Ref() }

func A_arbace_box_plan__init_A_Unit12__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_20; var tmp2 any = A_arbace_box_plan_with_trees_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_box_plan_with_trees_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_255, true); A_arbace_box_plan_with_trees_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_21)); return A_arbace_box_plan__init_A_const_20 }
//line :95:1
func A_arbace_box_plan__init_A_Unit13__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); A_arbace_box_plan__init_A_const_20.SetMacro__V(); return nil }
//line :95:1
func A_arbace_box_plan__init_A_Unit14__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); return A_arbace_box_plan__init_A_const_20 }







func A_arbace_box_plan__init_A_Unit15__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); A_arbace_box_plan__init_A_const_22.BindRoot_O__V(A_arbace_box_plan__init_A_const_23); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_24)); return A_arbace_box_plan__init_A_const_22 }



func A_arbace_box_plan__init_A_Unit16__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); A_arbace_box_plan__init_A_const_25.BindRoot_O__V(A_arbace_box_plan__init_A_const_26); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_27)); return A_arbace_box_plan__init_A_const_25 }



func A_arbace_box_plan__init_A_Unit17__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); A_arbace_box_plan__init_A_const_28.BindRoot_O__V(A_arbace_box_plan__init_A_const_29); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_30)); return A_arbace_box_plan__init_A_const_28 }




func A_arbace_box_plan__init_A_Unit18__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_31; var tmp2 any = A_arbace_box_plan_tag_fn_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_box_plan_tag_fn_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_256, false); A_arbace_box_plan_tag_fn_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_32)); return A_arbace_box_plan__init_A_const_31 }












func A_arbace_box_plan__init_A_Unit19__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_33; var tmp2 any = A_arbace_box_plan_name_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_box_plan_name_ok_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_257, false); A_arbace_box_plan_name_ok_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_34)); return A_arbace_box_plan__init_A_const_33 }















func A_arbace_box_plan__init_A_Unit20__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_35; var tmp2 any = A_arbace_box_plan_syntax_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_box_plan_syntax_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_box_plan_syntax_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_36)); return A_arbace_box_plan__init_A_const_35 }

func A_arbace_box_plan__init_A_Unit21__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_37; var tmp2 any = A_arbace_box_plan_tag_char_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_box_plan_tag_char_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_box_plan_tag_char_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_38)); return A_arbace_box_plan__init_A_const_37 }

func A_arbace_box_plan__init_A_Unit22__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_39; var tmp2 any = A_arbace_box_plan_parse_go_build_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_box_plan_parse_go_build_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_box_plan_parse_go_build_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_40)); return A_arbace_box_plan__init_A_const_39 }









































func A_arbace_box_plan__init_A_Unit23__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_41; var tmp2 any = A_arbace_box_plan_valid_tag_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_box_plan_valid_tag_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_261, false); A_arbace_box_plan_valid_tag_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_42)); return A_arbace_box_plan__init_A_const_41 }

func A_arbace_box_plan__init_A_Unit24__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(193, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_43; var tmp2 any = A_arbace_box_plan_parse_plus_build_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_box_plan_parse_plus_build_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_262, false); A_arbace_box_plan_parse_plus_build_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_44)); return A_arbace_box_plan__init_A_const_43 }














func A_arbace_box_plan__init_A_Unit25__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_45; var tmp2 any = A_arbace_box_plan_eval_constraint_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_box_plan_eval_constraint_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_263, false); A_arbace_box_plan_eval_constraint_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_46)); return A_arbace_box_plan__init_A_const_45 }








func A_arbace_box_plan__init_A_Unit26__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_47; var tmp2 any = A_arbace_box_plan_go_build_comment_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_box_plan_go_build_comment_QMARK__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_264, false); A_arbace_box_plan_go_build_comment_QMARK__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_48)); return A_arbace_box_plan__init_A_const_47 }




func A_arbace_box_plan__init_A_Unit27__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_49; var tmp2 any = A_arbace_box_plan_split_plus_build_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_box_plan_split_plus_build_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_265, false); A_arbace_box_plan_split_plus_build_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_50)); return A_arbace_box_plan__init_A_const_49 }








func A_arbace_box_plan__init_A_Unit28__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(231, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_51; var tmp2 any = A_arbace_box_plan_trim_space_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_box_plan_trim_space_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_266, false); A_arbace_box_plan_trim_space_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_52)); return A_arbace_box_plan__init_A_const_51 }




func A_arbace_box_plan__init_A_Unit29__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_53; var tmp2 any = A_arbace_box_plan_file_header_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_box_plan_file_header_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_267, false); A_arbace_box_plan_file_header_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_54)); return A_arbace_box_plan__init_A_const_53 }




























func A_arbace_box_plan__init_A_Unit30__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(265, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_55; var tmp2 any = A_arbace_box_plan_should_build_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_box_plan_should_build_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_268, false); A_arbace_box_plan_should_build_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_56)); return A_arbace_box_plan__init_A_const_55 }






















func A_arbace_box_plan__init_A_Unit31__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_57; var tmp2 any = A_arbace_box_plan_ident_char_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_box_plan_ident_char_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_269, false); A_arbace_box_plan_ident_char_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_58)); return A_arbace_box_plan__init_A_const_57 }



func A_arbace_box_plan__init_A_Unit32__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_59; var tmp2 any = A_arbace_box_plan_skip_space_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_box_plan_skip_space_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_270, false); A_arbace_box_plan_skip_space_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_60)); return A_arbace_box_plan__init_A_const_59 }

















func A_arbace_box_plan__init_A_Unit33__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(310, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_61; var tmp2 any = A_arbace_box_plan_read_ident_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_box_plan_read_ident_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_271, false); A_arbace_box_plan_read_ident_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_62)); return A_arbace_box_plan__init_A_const_61 }






func A_arbace_box_plan__init_A_Unit34__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(317, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_63; var tmp2 any = A_arbace_box_plan_read_keyword_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_box_plan_read_keyword_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_272, false); A_arbace_box_plan_read_keyword_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_64)); return A_arbace_box_plan__init_A_const_63 }





func A_arbace_box_plan__init_A_Unit35__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_65; var tmp2 any = A_arbace_box_plan_read_string_lit_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_box_plan_read_string_lit_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_273, false); A_arbace_box_plan_read_string_lit_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_66)); return A_arbace_box_plan__init_A_const_65 }

















func A_arbace_box_plan__init_A_Unit36__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(341, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_67; var tmp2 any = A_arbace_box_plan_hex_val_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_box_plan_hex_val_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_274, false); A_arbace_box_plan_hex_val_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_68)); return A_arbace_box_plan__init_A_const_67 }

func A_arbace_box_plan__init_A_Unit37__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(343, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_69; var tmp2 any = A_arbace_box_plan_unquote_go_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_box_plan_unquote_go_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_275, false); A_arbace_box_plan_unquote_go_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_70)); return A_arbace_box_plan__init_A_const_69 }













































func A_arbace_box_plan__init_A_Unit38__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_71; var tmp2 any = A_arbace_box_plan_valid_import_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_box_plan_valid_import_QMARK__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_276, false); A_arbace_box_plan_valid_import_QMARK__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_72)); return A_arbace_box_plan__init_A_const_71 }










func A_arbace_box_plan__init_A_Unit39__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(400, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_73; tmp1.BindRoot_O__V(jrt.Pattern_Compile_String__Pattern_NoInit(Lit_277).Ref()); var tmp2 *lang.Var = A_arbace_box_plan__init_A_const_73; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_74)); return A_arbace_box_plan__init_A_const_73 }

func A_arbace_box_plan__init_A_Unit40__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_75; var tmp2 any = A_arbace_box_plan_go_comments_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_box_plan_go_comments_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_278, false); A_arbace_box_plan_go_comments_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_76)); return A_arbace_box_plan__init_A_const_75 }
























func A_arbace_box_plan__init_A_Unit41__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(427, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_77; var tmp2 any = A_arbace_box_plan_directive_args_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_box_plan_directive_args_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_279, false); A_arbace_box_plan_directive_args_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_78)); return A_arbace_box_plan__init_A_const_77 }
















func A_arbace_box_plan__init_A_Unit42__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_79; var tmp2 any = A_arbace_box_plan_embed_patterns_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_box_plan_embed_patterns_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_280, false); A_arbace_box_plan_embed_patterns_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_80)); return A_arbace_box_plan__init_A_const_79 }








func A_arbace_box_plan__init_A_Unit43__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(453, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_81; var tmp2 any = A_arbace_box_plan_go_info_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_box_plan_go_info_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_281, false); A_arbace_box_plan_go_info_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_82)); return A_arbace_box_plan__init_A_const_81 }












































func A_arbace_box_plan__init_A_Unit44__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(498, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_83; var tmp2 any = A_arbace_box_plan_types_imports_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_box_plan_types_imports_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_282, false); A_arbace_box_plan_types_imports_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_84)); return A_arbace_box_plan__init_A_const_83 }








func A_arbace_box_plan__init_A_Unit45__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_85; var tmp2 any = A_arbace_box_plan_leading_comments_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_box_plan_leading_comments_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_283, false); A_arbace_box_plan_leading_comments_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_86)); return A_arbace_box_plan__init_A_const_85 }









func A_arbace_box_plan__init_A_Unit46__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(517, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_87; var tmp2 any = A_arbace_box_plan_name_ext_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_box_plan_name_ext_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_284, false); A_arbace_box_plan_name_ext_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_88)); return A_arbace_box_plan__init_A_const_87 }


func A_arbace_box_plan__init_A_Unit47__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); A_arbace_box_plan__init_A_const_89.BindRoot_O__V(A_arbace_box_plan__init_A_const_90); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_91)); return A_arbace_box_plan__init_A_const_89 }






func A_arbace_box_plan__init_A_Unit48__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(527, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_92; var tmp2 any = A_arbace_box_plan_match_file_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_box_plan_match_file_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_285, false); A_arbace_box_plan_match_file_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_93)); return A_arbace_box_plan__init_A_const_92 }


















func A_arbace_box_plan__init_A_Unit49__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(546, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_94; var tmp2 any = A_arbace_box_plan_import_dir_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_box_plan_import_dir_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_286, false); A_arbace_box_plan_import_dir_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_95)); return A_arbace_box_plan__init_A_const_94 }































































func A_arbace_box_plan__init_A_Unit50__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(610, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_96; var tmp2 any = A_arbace_box_plan_get_esc_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_box_plan_get_esc_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_287, false); A_arbace_box_plan_get_esc_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_97)); return A_arbace_box_plan__init_A_const_96 }











func A_arbace_box_plan__init_A_Unit51__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(622, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_98; var tmp2 any = A_arbace_box_plan_class_match_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_box_plan_class_match_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_288, false); A_arbace_box_plan_class_match_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_99)); return A_arbace_box_plan__init_A_const_98 }












func A_arbace_box_plan__init_A_Unit52__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(635, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_100; var tmp2 any = A_arbace_box_plan_path_match_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_box_plan_path_match_QMARK__A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_289, false); A_arbace_box_plan_path_match_QMARK__A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_101)); return A_arbace_box_plan__init_A_const_100 }
























func A_arbace_box_plan__init_A_Unit53__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(660, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_102; var tmp2 any = A_arbace_box_plan_check_pattern_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_box_plan_check_pattern_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_290, false); A_arbace_box_plan_check_pattern_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_103)); return A_arbace_box_plan__init_A_const_102 }










func A_arbace_box_plan__init_A_Unit54__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(671, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_104; var tmp2 any = A_arbace_box_plan_has_meta_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_box_plan_has_meta_QMARK__A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_291, false); A_arbace_box_plan_has_meta_QMARK__A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_105)); return A_arbace_box_plan__init_A_const_104 }

func A_arbace_box_plan__init_A_Unit55__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(673, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_106; var tmp2 any = A_arbace_box_plan_valid_embed_pattern_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_box_plan_valid_embed_pattern_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_292, false); A_arbace_box_plan_valid_embed_pattern_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_107)); return A_arbace_box_plan__init_A_const_106 }






func A_arbace_box_plan__init_A_Unit56__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(680, 1); A_arbace_box_plan__init_A_const_108.BindRoot_O__V(A_arbace_box_plan__init_A_const_109); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_110)); return A_arbace_box_plan__init_A_const_108 }



func A_arbace_box_plan__init_A_Unit57__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(684, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_111; var tmp2 any = A_arbace_box_plan_bad_embed_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_box_plan_bad_embed_name_QMARK__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_293, false); A_arbace_box_plan_bad_embed_name_QMARK__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_112)); return A_arbace_box_plan__init_A_const_111 }














func A_arbace_box_plan__init_A_Unit58__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(699, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_113; var tmp2 any = A_arbace_box_plan_file_kind_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_box_plan_file_kind_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_294, false); A_arbace_box_plan_file_kind_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_114)); return A_arbace_box_plan__init_A_const_113 }






func A_arbace_box_plan__init_A_Unit59__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(706, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_115; var tmp2 any = A_arbace_box_plan_glob_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_box_plan_glob_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_295, false); A_arbace_box_plan_glob_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_116)); return A_arbace_box_plan__init_A_const_115 }














func A_arbace_box_plan__init_A_Unit60__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(721, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_117; var tmp2 any = A_arbace_box_plan_resolve_embed_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_box_plan_resolve_embed_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_296, false); A_arbace_box_plan_resolve_embed_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_118)); return A_arbace_box_plan__init_A_const_117 }























































func A_arbace_box_plan__init_A_Unit61__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(777, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_119; var tmp2 any = A_arbace_box_plan_go_mod_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_box_plan_go_mod_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_297, false); A_arbace_box_plan_go_mod_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_120)); return A_arbace_box_plan__init_A_const_119 }




















func A_arbace_box_plan__init_A_Unit62__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(798, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_121; var tmp2 any = A_arbace_box_plan_go_mod_lang_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_box_plan_go_mod_lang_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_298, false); A_arbace_box_plan_go_mod_lang_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_122)); return A_arbace_box_plan__init_A_const_121 }






func A_arbace_box_plan__init_A_Unit63__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(805, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_123; var tmp2 any = A_arbace_box_plan_locate_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_box_plan_locate_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_299, false); A_arbace_box_plan_locate_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_124)); return A_arbace_box_plan__init_A_const_123 }



























func A_arbace_box_plan__init_A_Unit64__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(833, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_125; var tmp2 any = A_arbace_box_plan_call_with_trees_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_box_plan_call_with_trees_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_300, false); A_arbace_box_plan_call_with_trees_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_126)); return A_arbace_box_plan__init_A_const_125 }




func A_arbace_box_plan__init_A_Unit65__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(838, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_127; var tmp2 any = A_arbace_box_plan_import_dir_STAR__A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_box_plan_import_dir_STAR__A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_301, false); A_arbace_box_plan_import_dir_STAR__A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_128)); return A_arbace_box_plan__init_A_const_127 }




func A_arbace_box_plan__init_A_Unit66__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(843, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_129; var tmp2 any = A_arbace_box_plan_resolve_import_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_box_plan_resolve_import_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_302, false); A_arbace_box_plan_resolve_import_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_130)); return A_arbace_box_plan__init_A_const_129 }







func A_arbace_box_plan__init_A_Unit67__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(851, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_131; var tmp2 any = A_arbace_box_plan_load_package_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_box_plan_load_package_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_303, false); A_arbace_box_plan_load_package_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_132)); return A_arbace_box_plan__init_A_const_131 }



























func A_arbace_box_plan__init_A_Unit68__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(879, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_133; var tmp2 any = A_arbace_box_plan_walk_packages_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_box_plan_walk_packages_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_304, false); A_arbace_box_plan_walk_packages_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_134)); return A_arbace_box_plan__init_A_const_133 }





















func A_arbace_box_plan__init_A_Unit69__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(901, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_135; var tmp2 any = A_arbace_box_plan_match_pattern_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_box_plan_match_pattern_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_305, false); A_arbace_box_plan_match_pattern_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_136)); return A_arbace_box_plan__init_A_const_135 }





















func A_arbace_box_plan__init_A_Unit70__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(923, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_137; var tmp2 any = A_arbace_box_plan_list_packages_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_box_plan_list_packages_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_306, false); A_arbace_box_plan_list_packages_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_138)); return A_arbace_box_plan__init_A_const_137 }

























func A_arbace_box_plan__init_A_Unit71__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(949, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_139; var tmp2 any = A_arbace_box_plan_package_info_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_box_plan_package_info_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_307, false); A_arbace_box_plan_package_info_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_140)); return A_arbace_box_plan__init_A_const_139 }





















func A_arbace_box_plan__init_A_Unit72__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(971, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_141; var tmp2 any = A_arbace_box_plan_src_tree_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_box_plan_src_tree_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_308, false); A_arbace_box_plan_src_tree_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_142)); return A_arbace_box_plan__init_A_const_141 }




















func A_arbace_box_plan__init_A_Unit73__O() any { A_arbace_box_plan__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(992, 1); var tmp1 *lang.Var = A_arbace_box_plan__init_A_const_143; var tmp2 any = A_arbace_box_plan_plan_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_box_plan_plan_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_309, false); A_arbace_box_plan_plan_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_plan__init_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_plan__init_A_const_144)); return A_arbace_box_plan__init_A_const_143 }



type A_arbace_box_plan__init_A struct{ jrt.Object }

var A_arbace_box_plan__init_A_const_pool *jrt.RefArray

var A_arbace_box_plan__init_A_const_0 *lang.Var

var A_arbace_box_plan__init_A_const_1 any

var A_arbace_box_plan__init_A_const_2 any

var A_arbace_box_plan__init_A_const_3 any

var A_arbace_box_plan__init_A_const_4 *lang.Var

var A_arbace_box_plan__init_A_const_5 any

var A_arbace_box_plan__init_A_const_6 *lang.Var

var A_arbace_box_plan__init_A_const_7 any

var A_arbace_box_plan__init_A_const_8 *lang.Var

var A_arbace_box_plan__init_A_const_9 any

var A_arbace_box_plan__init_A_const_10 *lang.Var

var A_arbace_box_plan__init_A_const_11 any

var A_arbace_box_plan__init_A_const_12 *lang.Var

var A_arbace_box_plan__init_A_const_13 any

var A_arbace_box_plan__init_A_const_14 *lang.Var

var A_arbace_box_plan__init_A_const_15 any

var A_arbace_box_plan__init_A_const_16 *lang.Var

var A_arbace_box_plan__init_A_const_17 any

var A_arbace_box_plan__init_A_const_18 *lang.Var

var A_arbace_box_plan__init_A_const_19 any

var A_arbace_box_plan__init_A_const_20 *lang.Var

var A_arbace_box_plan__init_A_const_21 any

var A_arbace_box_plan__init_A_const_22 *lang.Var

var A_arbace_box_plan__init_A_const_23 any

var A_arbace_box_plan__init_A_const_24 any

var A_arbace_box_plan__init_A_const_25 *lang.Var

var A_arbace_box_plan__init_A_const_26 any

var A_arbace_box_plan__init_A_const_27 any

var A_arbace_box_plan__init_A_const_28 *lang.Var

var A_arbace_box_plan__init_A_const_29 any

var A_arbace_box_plan__init_A_const_30 any

var A_arbace_box_plan__init_A_const_31 *lang.Var

var A_arbace_box_plan__init_A_const_32 any

var A_arbace_box_plan__init_A_const_33 *lang.Var

var A_arbace_box_plan__init_A_const_34 any

var A_arbace_box_plan__init_A_const_35 *lang.Var

var A_arbace_box_plan__init_A_const_36 any

var A_arbace_box_plan__init_A_const_37 *lang.Var

var A_arbace_box_plan__init_A_const_38 any

var A_arbace_box_plan__init_A_const_39 *lang.Var

var A_arbace_box_plan__init_A_const_40 any

var A_arbace_box_plan__init_A_const_41 *lang.Var

var A_arbace_box_plan__init_A_const_42 any

var A_arbace_box_plan__init_A_const_43 *lang.Var

var A_arbace_box_plan__init_A_const_44 any

var A_arbace_box_plan__init_A_const_45 *lang.Var

var A_arbace_box_plan__init_A_const_46 any

var A_arbace_box_plan__init_A_const_47 *lang.Var

var A_arbace_box_plan__init_A_const_48 any

var A_arbace_box_plan__init_A_const_49 *lang.Var

var A_arbace_box_plan__init_A_const_50 any

var A_arbace_box_plan__init_A_const_51 *lang.Var

var A_arbace_box_plan__init_A_const_52 any

var A_arbace_box_plan__init_A_const_53 *lang.Var

var A_arbace_box_plan__init_A_const_54 any

var A_arbace_box_plan__init_A_const_55 *lang.Var

var A_arbace_box_plan__init_A_const_56 any

var A_arbace_box_plan__init_A_const_57 *lang.Var

var A_arbace_box_plan__init_A_const_58 any

var A_arbace_box_plan__init_A_const_59 *lang.Var

var A_arbace_box_plan__init_A_const_60 any

var A_arbace_box_plan__init_A_const_61 *lang.Var

var A_arbace_box_plan__init_A_const_62 any

var A_arbace_box_plan__init_A_const_63 *lang.Var

var A_arbace_box_plan__init_A_const_64 any

var A_arbace_box_plan__init_A_const_65 *lang.Var

var A_arbace_box_plan__init_A_const_66 any

var A_arbace_box_plan__init_A_const_67 *lang.Var

var A_arbace_box_plan__init_A_const_68 any

var A_arbace_box_plan__init_A_const_69 *lang.Var

var A_arbace_box_plan__init_A_const_70 any

var A_arbace_box_plan__init_A_const_71 *lang.Var

var A_arbace_box_plan__init_A_const_72 any

var A_arbace_box_plan__init_A_const_73 *lang.Var

var A_arbace_box_plan__init_A_const_74 any

var A_arbace_box_plan__init_A_const_75 *lang.Var

var A_arbace_box_plan__init_A_const_76 any

var A_arbace_box_plan__init_A_const_77 *lang.Var

var A_arbace_box_plan__init_A_const_78 any

var A_arbace_box_plan__init_A_const_79 *lang.Var

var A_arbace_box_plan__init_A_const_80 any

var A_arbace_box_plan__init_A_const_81 *lang.Var

var A_arbace_box_plan__init_A_const_82 any

var A_arbace_box_plan__init_A_const_83 *lang.Var

var A_arbace_box_plan__init_A_const_84 any

var A_arbace_box_plan__init_A_const_85 *lang.Var

var A_arbace_box_plan__init_A_const_86 any

var A_arbace_box_plan__init_A_const_87 *lang.Var

var A_arbace_box_plan__init_A_const_88 any

var A_arbace_box_plan__init_A_const_89 *lang.Var

var A_arbace_box_plan__init_A_const_90 any

var A_arbace_box_plan__init_A_const_91 any

var A_arbace_box_plan__init_A_const_92 *lang.Var

var A_arbace_box_plan__init_A_const_93 any

var A_arbace_box_plan__init_A_const_94 *lang.Var

var A_arbace_box_plan__init_A_const_95 any

var A_arbace_box_plan__init_A_const_96 *lang.Var

var A_arbace_box_plan__init_A_const_97 any

var A_arbace_box_plan__init_A_const_98 *lang.Var

var A_arbace_box_plan__init_A_const_99 any

var A_arbace_box_plan__init_A_const_100 *lang.Var

var A_arbace_box_plan__init_A_const_101 any

var A_arbace_box_plan__init_A_const_102 *lang.Var

var A_arbace_box_plan__init_A_const_103 any

var A_arbace_box_plan__init_A_const_104 *lang.Var

var A_arbace_box_plan__init_A_const_105 any

var A_arbace_box_plan__init_A_const_106 *lang.Var

var A_arbace_box_plan__init_A_const_107 any

var A_arbace_box_plan__init_A_const_108 *lang.Var

var A_arbace_box_plan__init_A_const_109 any

var A_arbace_box_plan__init_A_const_110 any

var A_arbace_box_plan__init_A_const_111 *lang.Var

var A_arbace_box_plan__init_A_const_112 any

var A_arbace_box_plan__init_A_const_113 *lang.Var

var A_arbace_box_plan__init_A_const_114 any

var A_arbace_box_plan__init_A_const_115 *lang.Var

var A_arbace_box_plan__init_A_const_116 any

var A_arbace_box_plan__init_A_const_117 *lang.Var

var A_arbace_box_plan__init_A_const_118 any

var A_arbace_box_plan__init_A_const_119 *lang.Var

var A_arbace_box_plan__init_A_const_120 any

var A_arbace_box_plan__init_A_const_121 *lang.Var

var A_arbace_box_plan__init_A_const_122 any

var A_arbace_box_plan__init_A_const_123 *lang.Var

var A_arbace_box_plan__init_A_const_124 any

var A_arbace_box_plan__init_A_const_125 *lang.Var

var A_arbace_box_plan__init_A_const_126 any

var A_arbace_box_plan__init_A_const_127 *lang.Var

var A_arbace_box_plan__init_A_const_128 any

var A_arbace_box_plan__init_A_const_129 *lang.Var

var A_arbace_box_plan__init_A_const_130 any

var A_arbace_box_plan__init_A_const_131 *lang.Var

var A_arbace_box_plan__init_A_const_132 any

var A_arbace_box_plan__init_A_const_133 *lang.Var

var A_arbace_box_plan__init_A_const_134 any

var A_arbace_box_plan__init_A_const_135 *lang.Var

var A_arbace_box_plan__init_A_const_136 any

var A_arbace_box_plan__init_A_const_137 *lang.Var

var A_arbace_box_plan__init_A_const_138 any

var A_arbace_box_plan__init_A_const_139 *lang.Var

var A_arbace_box_plan__init_A_const_140 any

var A_arbace_box_plan__init_A_const_141 *lang.Var

var A_arbace_box_plan__init_A_const_142 any

var A_arbace_box_plan__init_A_const_143 *lang.Var

var A_arbace_box_plan__init_A_const_144 any

var A_arbace_box_plan__init_A_init jrt.ClassInit

func A_arbace_box_plan__init_A_Init() { if !A_arbace_box_plan__init_A_init.Done() { A_arbace_box_plan__init_A_init.Run(A_arbace_box_plan__init_A_clinit) } }

func A_arbace_box_plan__init_A_clinit() { A_arbace_box_plan__init_A_clinit_p0(); A_arbace_box_plan__init_A_clinit_p1(); A_arbace_box_plan__init_A_clinit_p2(); A_arbace_box_plan__init_A_clinit_p3(); A_arbace_box_plan__init_A_clinit_p4(); A_arbace_box_plan__init_A_clinit_p5(); A_arbace_box_plan__init_A_clinit_p6(); A_arbace_box_plan__init_A_clinit_p7(); A_arbace_box_plan__init_A_clinit_p8(); A_arbace_box_plan__init_A_clinit_p9(); A_arbace_box_plan__init_A_clinit_p10() }

func A_arbace_box_plan__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_plan__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_246, 198); A_arbace_box_plan__init_A_const_0 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[53]); A_arbace_box_plan__init_A_const_1 = A_arbace_box_plan__init_A_const_pool.A[54]; A_arbace_box_plan__init_A_const_2 = A_arbace_box_plan__init_A_const_pool.A[55]; A_arbace_box_plan__init_A_const_3 = A_arbace_box_plan__init_A_const_pool.A[56]; A_arbace_box_plan__init_A_const_4 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[57]); A_arbace_box_plan__init_A_const_5 = A_arbace_box_plan__init_A_const_pool.A[58]; A_arbace_box_plan__init_A_const_6 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[59]); A_arbace_box_plan__init_A_const_7 = A_arbace_box_plan__init_A_const_pool.A[60]; A_arbace_box_plan__init_A_const_8 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[61]); A_arbace_box_plan__init_A_const_9 = A_arbace_box_plan__init_A_const_pool.A[62]; A_arbace_box_plan__init_A_const_10 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[63]); A_arbace_box_plan__init_A_const_11 = A_arbace_box_plan__init_A_const_pool.A[64]; A_arbace_box_plan__init_A_const_12 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[65]) }

func A_arbace_box_plan__init_A_clinit_p1() { A_arbace_box_plan__init_A_const_13 = A_arbace_box_plan__init_A_const_pool.A[66]; A_arbace_box_plan__init_A_const_14 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[67]); A_arbace_box_plan__init_A_const_15 = A_arbace_box_plan__init_A_const_pool.A[68]; A_arbace_box_plan__init_A_const_16 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[69]); A_arbace_box_plan__init_A_const_17 = A_arbace_box_plan__init_A_const_pool.A[70]; A_arbace_box_plan__init_A_const_18 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[71]); A_arbace_box_plan__init_A_const_19 = A_arbace_box_plan__init_A_const_pool.A[72]; A_arbace_box_plan__init_A_const_20 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[73]); A_arbace_box_plan__init_A_const_21 = A_arbace_box_plan__init_A_const_pool.A[74]; A_arbace_box_plan__init_A_const_22 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[75]); A_arbace_box_plan__init_A_const_23 = A_arbace_box_plan__init_A_const_pool.A[76]; A_arbace_box_plan__init_A_const_24 = A_arbace_box_plan__init_A_const_pool.A[77]; A_arbace_box_plan__init_A_const_25 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[78]); A_arbace_box_plan__init_A_const_26 = A_arbace_box_plan__init_A_const_pool.A[79] }

func A_arbace_box_plan__init_A_clinit_p2() { A_arbace_box_plan__init_A_const_27 = A_arbace_box_plan__init_A_const_pool.A[80]; A_arbace_box_plan__init_A_const_28 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[81]); A_arbace_box_plan__init_A_const_29 = A_arbace_box_plan__init_A_const_pool.A[82]; A_arbace_box_plan__init_A_const_30 = A_arbace_box_plan__init_A_const_pool.A[83]; A_arbace_box_plan__init_A_const_31 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[84]); A_arbace_box_plan__init_A_const_32 = A_arbace_box_plan__init_A_const_pool.A[85]; A_arbace_box_plan__init_A_const_33 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[86]); A_arbace_box_plan__init_A_const_34 = A_arbace_box_plan__init_A_const_pool.A[87]; A_arbace_box_plan__init_A_const_35 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[88]); A_arbace_box_plan__init_A_const_36 = A_arbace_box_plan__init_A_const_pool.A[89]; A_arbace_box_plan__init_A_const_37 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[90]); A_arbace_box_plan__init_A_const_38 = A_arbace_box_plan__init_A_const_pool.A[91]; A_arbace_box_plan__init_A_const_39 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[92]); A_arbace_box_plan__init_A_const_40 = A_arbace_box_plan__init_A_const_pool.A[93] }

func A_arbace_box_plan__init_A_clinit_p3() { A_arbace_box_plan__init_A_const_41 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[94]); A_arbace_box_plan__init_A_const_42 = A_arbace_box_plan__init_A_const_pool.A[95]; A_arbace_box_plan__init_A_const_43 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[96]); A_arbace_box_plan__init_A_const_44 = A_arbace_box_plan__init_A_const_pool.A[97]; A_arbace_box_plan__init_A_const_45 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[98]); A_arbace_box_plan__init_A_const_46 = A_arbace_box_plan__init_A_const_pool.A[99]; A_arbace_box_plan__init_A_const_47 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[100]); A_arbace_box_plan__init_A_const_48 = A_arbace_box_plan__init_A_const_pool.A[101]; A_arbace_box_plan__init_A_const_49 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[102]); A_arbace_box_plan__init_A_const_50 = A_arbace_box_plan__init_A_const_pool.A[103]; A_arbace_box_plan__init_A_const_51 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[104]); A_arbace_box_plan__init_A_const_52 = A_arbace_box_plan__init_A_const_pool.A[105]; A_arbace_box_plan__init_A_const_53 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[106]) }

func A_arbace_box_plan__init_A_clinit_p4() { A_arbace_box_plan__init_A_const_54 = A_arbace_box_plan__init_A_const_pool.A[107]; A_arbace_box_plan__init_A_const_55 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[108]); A_arbace_box_plan__init_A_const_56 = A_arbace_box_plan__init_A_const_pool.A[109]; A_arbace_box_plan__init_A_const_57 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[110]); A_arbace_box_plan__init_A_const_58 = A_arbace_box_plan__init_A_const_pool.A[111]; A_arbace_box_plan__init_A_const_59 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[112]); A_arbace_box_plan__init_A_const_60 = A_arbace_box_plan__init_A_const_pool.A[113]; A_arbace_box_plan__init_A_const_61 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[114]); A_arbace_box_plan__init_A_const_62 = A_arbace_box_plan__init_A_const_pool.A[115]; A_arbace_box_plan__init_A_const_63 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[116]); A_arbace_box_plan__init_A_const_64 = A_arbace_box_plan__init_A_const_pool.A[117]; A_arbace_box_plan__init_A_const_65 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[118]); A_arbace_box_plan__init_A_const_66 = A_arbace_box_plan__init_A_const_pool.A[119] }

func A_arbace_box_plan__init_A_clinit_p5() { A_arbace_box_plan__init_A_const_67 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[120]); A_arbace_box_plan__init_A_const_68 = A_arbace_box_plan__init_A_const_pool.A[121]; A_arbace_box_plan__init_A_const_69 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[122]); A_arbace_box_plan__init_A_const_70 = A_arbace_box_plan__init_A_const_pool.A[123]; A_arbace_box_plan__init_A_const_71 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[124]); A_arbace_box_plan__init_A_const_72 = A_arbace_box_plan__init_A_const_pool.A[125]; A_arbace_box_plan__init_A_const_73 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[126]); A_arbace_box_plan__init_A_const_74 = A_arbace_box_plan__init_A_const_pool.A[127]; A_arbace_box_plan__init_A_const_75 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[128]); A_arbace_box_plan__init_A_const_76 = A_arbace_box_plan__init_A_const_pool.A[129]; A_arbace_box_plan__init_A_const_77 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[130]); A_arbace_box_plan__init_A_const_78 = A_arbace_box_plan__init_A_const_pool.A[131]; A_arbace_box_plan__init_A_const_79 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[132]) }

func A_arbace_box_plan__init_A_clinit_p6() { A_arbace_box_plan__init_A_const_80 = A_arbace_box_plan__init_A_const_pool.A[133]; A_arbace_box_plan__init_A_const_81 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[134]); A_arbace_box_plan__init_A_const_82 = A_arbace_box_plan__init_A_const_pool.A[135]; A_arbace_box_plan__init_A_const_83 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[136]); A_arbace_box_plan__init_A_const_84 = A_arbace_box_plan__init_A_const_pool.A[137]; A_arbace_box_plan__init_A_const_85 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[138]); A_arbace_box_plan__init_A_const_86 = A_arbace_box_plan__init_A_const_pool.A[139]; A_arbace_box_plan__init_A_const_87 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[140]); A_arbace_box_plan__init_A_const_88 = A_arbace_box_plan__init_A_const_pool.A[141]; A_arbace_box_plan__init_A_const_89 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[142]); A_arbace_box_plan__init_A_const_90 = A_arbace_box_plan__init_A_const_pool.A[143]; A_arbace_box_plan__init_A_const_91 = A_arbace_box_plan__init_A_const_pool.A[144]; A_arbace_box_plan__init_A_const_92 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[145]); A_arbace_box_plan__init_A_const_93 = A_arbace_box_plan__init_A_const_pool.A[146] }

func A_arbace_box_plan__init_A_clinit_p7() { A_arbace_box_plan__init_A_const_94 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[147]); A_arbace_box_plan__init_A_const_95 = A_arbace_box_plan__init_A_const_pool.A[148]; A_arbace_box_plan__init_A_const_96 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[149]); A_arbace_box_plan__init_A_const_97 = A_arbace_box_plan__init_A_const_pool.A[150]; A_arbace_box_plan__init_A_const_98 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[151]); A_arbace_box_plan__init_A_const_99 = A_arbace_box_plan__init_A_const_pool.A[152]; A_arbace_box_plan__init_A_const_100 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[153]); A_arbace_box_plan__init_A_const_101 = A_arbace_box_plan__init_A_const_pool.A[154]; A_arbace_box_plan__init_A_const_102 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[155]); A_arbace_box_plan__init_A_const_103 = A_arbace_box_plan__init_A_const_pool.A[156]; A_arbace_box_plan__init_A_const_104 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[157]); A_arbace_box_plan__init_A_const_105 = A_arbace_box_plan__init_A_const_pool.A[158]; A_arbace_box_plan__init_A_const_106 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[159]) }

func A_arbace_box_plan__init_A_clinit_p8() { A_arbace_box_plan__init_A_const_107 = A_arbace_box_plan__init_A_const_pool.A[160]; A_arbace_box_plan__init_A_const_108 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[161]); A_arbace_box_plan__init_A_const_109 = A_arbace_box_plan__init_A_const_pool.A[162]; A_arbace_box_plan__init_A_const_110 = A_arbace_box_plan__init_A_const_pool.A[163]; A_arbace_box_plan__init_A_const_111 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[164]); A_arbace_box_plan__init_A_const_112 = A_arbace_box_plan__init_A_const_pool.A[165]; A_arbace_box_plan__init_A_const_113 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[166]); A_arbace_box_plan__init_A_const_114 = A_arbace_box_plan__init_A_const_pool.A[167]; A_arbace_box_plan__init_A_const_115 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[168]); A_arbace_box_plan__init_A_const_116 = A_arbace_box_plan__init_A_const_pool.A[169]; A_arbace_box_plan__init_A_const_117 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[170]); A_arbace_box_plan__init_A_const_118 = A_arbace_box_plan__init_A_const_pool.A[171]; A_arbace_box_plan__init_A_const_119 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[172]); A_arbace_box_plan__init_A_const_120 = A_arbace_box_plan__init_A_const_pool.A[173] }

func A_arbace_box_plan__init_A_clinit_p9() { A_arbace_box_plan__init_A_const_121 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[174]); A_arbace_box_plan__init_A_const_122 = A_arbace_box_plan__init_A_const_pool.A[175]; A_arbace_box_plan__init_A_const_123 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[176]); A_arbace_box_plan__init_A_const_124 = A_arbace_box_plan__init_A_const_pool.A[177]; A_arbace_box_plan__init_A_const_125 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[178]); A_arbace_box_plan__init_A_const_126 = A_arbace_box_plan__init_A_const_pool.A[179]; A_arbace_box_plan__init_A_const_127 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[180]); A_arbace_box_plan__init_A_const_128 = A_arbace_box_plan__init_A_const_pool.A[181]; A_arbace_box_plan__init_A_const_129 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[182]); A_arbace_box_plan__init_A_const_130 = A_arbace_box_plan__init_A_const_pool.A[183]; A_arbace_box_plan__init_A_const_131 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[184]); A_arbace_box_plan__init_A_const_132 = A_arbace_box_plan__init_A_const_pool.A[185]; A_arbace_box_plan__init_A_const_133 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[186]) }

func A_arbace_box_plan__init_A_clinit_p10() { A_arbace_box_plan__init_A_const_134 = A_arbace_box_plan__init_A_const_pool.A[187]; A_arbace_box_plan__init_A_const_135 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[188]); A_arbace_box_plan__init_A_const_136 = A_arbace_box_plan__init_A_const_pool.A[189]; A_arbace_box_plan__init_A_const_137 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[190]); A_arbace_box_plan__init_A_const_138 = A_arbace_box_plan__init_A_const_pool.A[191]; A_arbace_box_plan__init_A_const_139 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[192]); A_arbace_box_plan__init_A_const_140 = A_arbace_box_plan__init_A_const_pool.A[193]; A_arbace_box_plan__init_A_const_141 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[194]); A_arbace_box_plan__init_A_const_142 = A_arbace_box_plan__init_A_const_pool.A[195]; A_arbace_box_plan__init_A_const_143 = lang.Var_Cast(A_arbace_box_plan__init_A_const_pool.A[196]); A_arbace_box_plan__init_A_const_144 = A_arbace_box_plan__init_A_const_pool.A[197] }

func A_arbace_box_plan__init_A_New() *A_arbace_box_plan__init_A { A_arbace_box_plan__init_A_Init(); t := &A_arbace_box_plan__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan__init_A) Ctor() {}

func (t *A_arbace_box_plan__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan__init_A_class }

func (t *A_arbace_box_plan__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_plan__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan__init_A); return ok }

func A_arbace_box_plan__init_A_Cast(x any) *A_arbace_box_plan__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan__init_A_class)) }; return v }
