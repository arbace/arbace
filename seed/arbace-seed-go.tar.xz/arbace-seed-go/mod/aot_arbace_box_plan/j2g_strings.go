//line j2g_strings.ae:1
package aot_arbace_box_plan

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn10,arbace.boxkn2,asyn3,boxyn13,arbace.stringyn3,stryn11,arbace.corekn3,docks15,arbace.box.plan5,errorkn4,treekn3,dirkn4,blobkn4,gooskn6,goarchkn9,tool-tagskn12,release-tagskn4,tagskn4,elsekn6,stringkn5,identkn7,packagekn7,importskn6,embedskn6,gorootkn7,moduleskn7,goospkgkn3,stdkn4,langkn4,pathkn8,patternskn4,namekn8,std-langkn2,gokn1,skn11,raw-importskn5,embedkn9,importmapkn7,goamd64kn7,goarm64kn4,mainkn7,includekn8,packageskn3,srcv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,v11,arbace.core5,referR5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.box.planm2,R6,s1834,A Go program's build plan from source trees of the store (arbace.box's trees), as go list\n  -deps gives it for one GOOS and GOARCH with cgo off: the packages the main package reaches,\n  each after those it imports, each with its Go and assembly files (go/build's rules: the file\n  name's GOOS and GOARCH, //go:build lines, test files and files beginning with _ or . left\n  out, files importing \"C\" left out), its imports resolved (the standard library's vendor\n  directory, GOOSPKG's runtime/goos), its language version and its embedded files.\n\n    (plan cfg)   the plan: {:goos :goarch :goamd64 :goarm64 :main :include\n                            :packages [{:path :name :src :std :lang :go :s :imports\n                                        :importmap :embed} ...]}\n\n  cfg:\n    :goroot    the tree of GOROOT/src (std's packages at their import paths, vendor/, go.mod)\n    :modules   {module-path tree}: each module's root (its go.mod's go line is :lang)\n    :goospkg   the module whose goos/ is runtime/goos (TamaGo's GOOSPKG), when :goos is tamago\n    :main      the main package's import path\n    :goos :goarch :goamd64 :goarm64\n    :tool-tags, :release-tags   the toolchain's (go list's context.ToolTags, ReleaseTags)\n    :tags      more build tags (the program's)\n    :include   GOROOT/pkg/include's tree, passed on to the plan\n\n  A package's :src is a tree of its directory's files, the .h files of its subdirectories\n  (an assembly file includes them by a relative path) and its embedded files: what its compile\n  and asm read, so that a change elsewhere leaves its actions' keys alone. :embed is\n  {:patterns {PATTERN [FILE ...]}} (FILE relative to the package's directory) when it embeds.\n  Glob patterns in //go:embed are refused, as are packages with cgo, C or .syso files (the\n  driver builds Go and Go's assembly only).v11,arbace.core7,ex-infov11,arbace.core5,assocR7,v15,arbace.box.plan7,*trees*v10,arbace.box4,treev15,arbace.box.plan4,failR8,v11,arbace.core5,swap!v11,arbace.core6,reducev15,arbace.box.plan7,entriesR9,v11,arbace.core7,reducedv11,arbace.core6,removev11,arbace.core6,empty?v13,arbace.string5,splitp1,/v10,arbace.box3,getR10,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR11,R12,R13,R14,R15,v11,arbace.core3,setv11,arbace.core6,concatv11,arbace.core9,contains?v15,arbace.box.plan7,unix-osR16,p2,\\.l2,v11,arbace.core3,vecv11,arbace.core4,subsp1,_l-1,v11,arbace.core4,peekv11,arbace.core3,popv15,arbace.box.plan8,known-osv15,arbace.box.plan10,known-archv11,arbace.core6,re-seqp30,\\(|\\)|!|&&|\\|\\||[A-Za-z0-9_.]+v11,arbace.core4,atomv15,arbace.box.plan11,expr-tokensv11,arbace.core4,restv11,arbace.core3,notv11,arbace.core10,re-matchesp14,[A-Za-z0-9_.]+v13,arbace.string11,split-linesv13,arbace.string4,trimv13,arbace.string6,blank?v13,arbace.string12,starts-with?v11,arbace.core7,re-findp16,^//go:build[ \\t]l10,v13,arbace.string9,includes?c10,S3,s1,)R17,R18,v11,arbace.core4,consc47,c42,S3,s1,)R17,R18,c34,c92,R17,v11,arbace.core3,strc96,c95,R18,c41,l0,v11,arbace.core10,drop-whilev15,arbace.box.plan9,go-tokensV2,R18,s7,packagev11,arbace.core6,secondv11,arbace.core4,dropV2,R18,s6,importv11,arbace.core10,split-withv11,arbace.core4,not=v11,arbace.core4,intov11,arbace.core4,keepv11,arbace.core7,vector?v11,arbace.core4,someS1,s5,embedv11,arbace.core6,mapcatv11,arbace.core3,mapl1,p22,\\\"[^\\\"]*\\\"|`[^`]*`|\\S+l11,R19,R20,R21,p23,(?m)^go[ \\t]+(\\d+\\.\\d+)v15,arbace.box.plan4,textR22,R23,R24,v11,arbace.core6,filterv15,arbace.box.plan6,dir-atR25,R26,v15,arbace.box.plan11,go-mod-langR27,l4,p1,/v13,arbace.string4,joinv11,arbace.core7,butlastv11,arbace.core4,lastv11,arbace.core7,sort-byv11,arbace.core3,keyp8,[*?\\[\\\\]v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferp10,(\\.[^.]*)$S11,s2,.fs3,.gos5,.swigs5,.sysos4,.cpps2,.cs3,.ccs2,.Ss2,.ms2,.Fs2,.sv13,arbace.string10,ends-with?v15,arbace.box.plan8,name-ok?v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restS11,s2,.fs3,.gos5,.swigs5,.sysos4,.cpps2,.cs3,.ccs2,.Ss2,.ms2,.Fs2,.sv15,arbace.box.plan12,header-buildv15,arbace.box.plan9,eval-exprv15,arbace.box.plan7,go-infoS1,s1,CS1,s1,Cv11,arbace.core8,distinctv11,arbace.core4,compR28,v11,arbace.core10,sorted-mapv15,arbace.box.plan11,embed-filesR29,R30,R31,v11,arbace.core4,mapvR32,R33,v11,arbace.core4,sortS1,s6,unsafeR34,S1,s2,.sv11,arbace.core3,valv10,arbace.box8,put-treev15,arbace.box.plan6,tag-fnv15,arbace.box.plan6,locatev15,arbace.box.plan12,package-infov11,arbace.core6,dissocR35,v11,arbace.core7,reverseR36,R37,R38,R39,R40,R41,v15,arbace.box.plan8,src-treev11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-map")

var Lit_1 *jrt.String = jrt.Intern("arbace.box.plan$dir_at$fn__1305000014")

var Lit_2 *jrt.String = jrt.Intern("all:")

var Lit_3 *jrt.String = jrt.Intern("arbace.box.plan: ")

var Lit_4 *jrt.String = jrt.Intern(": //go:embed ")

var Lit_5 *jrt.String = jrt.Intern(": globs are not supported")

var Lit_6 *jrt.String = jrt.Intern("/")

var Lit_7 *jrt.String = jrt.Intern("arbace.box.plan$embed_files$walk__1305000114")

var Lit_8 *jrt.String = jrt.Intern(": no matching files")

var Lit_9 *jrt.String = jrt.Intern("arbace.box.plan$embed_files$walk__1305000114$fn__1305000116")

var Lit_10 *jrt.String = jrt.Intern(".")

var Lit_11 *jrt.String = jrt.Intern("_")

var Lit_12 *jrt.String = jrt.Intern("arbace.box.plan: no tree ")

var Lit_13 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$peek_t__1305000033")

var Lit_14 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$next_t__1305000035")

var Lit_15 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$or_e__1305000037")

var Lit_16 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$and_e__1305000039")

var Lit_17 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$not_e__1305000041")

var Lit_18 *jrt.String = jrt.Intern("arbace.box.plan: //go:build ")

var Lit_19 *jrt.String = jrt.Intern(": more after the expression")

var Lit_20 *jrt.String = jrt.Intern("&&")

var Lit_21 *jrt.String = jrt.Intern("!")

var Lit_22 *jrt.String = jrt.Intern("(")

var Lit_23 *jrt.String = jrt.Intern(")")

var Lit_24 *jrt.String = jrt.Intern("//go:build ")

var Lit_25 *jrt.String = jrt.Intern(": no )")

var Lit_26 *jrt.String = jrt.Intern(": not an expression")

var Lit_27 *jrt.String = jrt.Intern("||")

var Lit_28 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000070")

var Lit_29 *jrt.String = jrt.Intern(": no package clause")

var Lit_30 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072")

var Lit_31 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000090")

var Lit_32 *jrt.String = jrt.Intern(";")

var Lit_33 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000073")

var Lit_34 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000078")

var Lit_35 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000080")

var Lit_36 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000085")

var Lit_37 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000087")

var Lit_38 *jrt.String = jrt.Intern("//go:embed ")

var Lit_39 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000090$fn__1305000091")

var Lit_40 *jrt.String = jrt.Intern("\"")

var Lit_41 *jrt.String = jrt.Intern("go.mod")

var Lit_42 *jrt.String = jrt.Intern("go")

var Lit_43 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055")

var Lit_44 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055$fn__1305000056")

var Lit_45 *jrt.String = jrt.Intern("indexOf")

var Lit_46 *jrt.String = jrt.Intern("\n")

var Lit_47 *jrt.String = jrt.Intern("*/")

var Lit_48 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000057")

var Lit_49 *jrt.String = jrt.Intern("`")

var Lit_50 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000059")

var Lit_51 *jrt.String = jrt.Intern("//go:build")

var Lit_52 *jrt.String = jrt.Intern("//")

var Lit_53 *jrt.String = jrt.Intern("/*")

var Lit_54 *jrt.String = jrt.Intern("arbace.box.plan$locate$fn__1305000102")

var Lit_55 *jrt.String = jrt.Intern("tamago")

var Lit_56 *jrt.String = jrt.Intern("runtime/goos")

var Lit_57 *jrt.String = jrt.Intern("runtime/goos/")

var Lit_58 *jrt.String = jrt.Intern("arbace.box.plan: no module ")

var Lit_59 *jrt.String = jrt.Intern(" (GOOSPKG)")

var Lit_60 *jrt.String = jrt.Intern("goos")

var Lit_61 *jrt.String = jrt.Intern("vendor/")

var Lit_62 *jrt.String = jrt.Intern("test")

var Lit_63 *jrt.String = jrt.Intern("package ")

var Lit_64 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000130__1305000134")

var Lit_65 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000152__1305000156")

var Lit_66 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000168__1305000172")

var Lit_67 *jrt.String = jrt.Intern(": no Go files for ")

var Lit_68 *jrt.String = jrt.Intern(": packages ")

var Lit_69 *jrt.String = jrt.Intern(", ")

var Lit_70 *jrt.String = jrt.Intern("arbace.box.plan$package_info$fn__1305000184")

var Lit_71 *jrt.String = jrt.Intern(": ")

var Lit_72 *jrt.String = jrt.Intern(": cgo, C or .syso files are not built by the box's driver")

var Lit_73 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000189__1305000193")

var Lit_74 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135")

var Lit_75 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135$fn__1305000136")

var Lit_76 *jrt.String = jrt.Intern("_test.go")

var Lit_77 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157")

var Lit_78 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157$fn__1305000158")

var Lit_79 *jrt.String = jrt.Intern(".go")

var Lit_80 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173")

var Lit_81 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173$fn__1305000174")

var Lit_82 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194")

var Lit_83 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194$fn__1305000195")

var Lit_84 *jrt.String = jrt.Intern("arbace.box.plan: GOROOT/src has no go.mod")

var Lit_85 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000250")

var Lit_86 *jrt.String = jrt.Intern("v1")

var Lit_87 *jrt.String = jrt.Intern("v8.0")

var Lit_88 *jrt.String = jrt.Intern("arbace.box.plan$plan$fn__1305000260")

var Lit_89 *jrt.String = jrt.Intern("arbace.box.plan: an import cycle: ")

var Lit_90 *jrt.String = jrt.Intern(" -> ")

var Lit_91 *jrt.String = jrt.Intern("arbace.box.plan: no package ")

var Lit_92 *jrt.String = jrt.Intern(", imported by ")

var Lit_93 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000250$fn__1305000251")

var Lit_94 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000250$fn__1305000254")

var Lit_95 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203")

var Lit_96 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000227__1305000231")

var Lit_97 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232")

var Lit_98 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232$fn__1305000233")

var Lit_99 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208")

var Lit_100 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209")

var Lit_101 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209$fn__1305000210")

var Lit_102 *jrt.String = jrt.Intern(".h")

var Lit_103 *jrt.String = jrt.Intern("gc")

var Lit_104 *jrt.String = jrt.Intern("arbace.box.plan$tag_fn$fn__1305000028")

var Lit_105 *jrt.String = jrt.Intern("unix")

var Lit_106 *jrt.String = jrt.Intern("cgo")

var Lit_107 *jrt.String = jrt.Intern("arbace.box.plan: no blob ")

var Lit_108 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,msgyn4,datakn4,linekn6,columnkn4,filekn7,dynamicyn1,hkn3,tagyn6,Stringyn1,_kn4,keysyn4,goosyn6,goarchyn9,tool-tagsyn12,release-tagsyn4,tagsyn6,match?yn4,whatyn3,cfgyn1,pyn8,from-stdyn1,dyn3,diryn3,stdyn4,langyn4,pathyn5,embedv11,arbace.core5,in-nsMyn15,arbace.box.planm2,R0,s1834,A Go program's build plan from source trees of the store (arbace.box's trees), as go list\n  -deps gives it for one GOOS and GOARCH with cgo off: the packages the main package reaches,\n  each after those it imports, each with its Go and assembly files (go/build's rules: the file\n  name's GOOS and GOARCH, //go:build lines, test files and files beginning with _ or . left\n  out, files importing \"C\" left out), its imports resolved (the standard library's vendor\n  directory, GOOSPKG's runtime/goos), its language version and its embedded files.\n\n    (plan cfg)   the plan: {:goos :goarch :goamd64 :goarm64 :main :include\n                            :packages [{:path :name :src :std :lang :go :s :imports\n                                        :importmap :embed} ...]}\n\n  cfg:\n    :goroot    the tree of GOROOT/src (std's packages at their import paths, vendor/, go.mod)\n    :modules   {module-path tree}: each module's root (its go.mod's go line is :lang)\n    :goospkg   the module whose goos/ is runtime/goos (TamaGo's GOOSPKG), when :goos is tamago\n    :main      the main package's import path\n    :goos :goarch :goamd64 :goarm64\n    :tool-tags, :release-tags   the toolchain's (go list's context.ToolTags, ReleaseTags)\n    :tags      more build tags (the program's)\n    :include   GOROOT/pkg/include's tree, passed on to the plan\n\n  A package's :src is a tree of its directory's files, the .h files of its subdirectories\n  (an assembly file includes them by a relative path) and its embedded files: what its compile\n  and asm read, so that a change elsewhere leaves its actions' keys alone. :embed is\n  {:patterns {PATTERN [FILE ...]}} (FILE relative to the package's directory) when it embeds.\n  Glob patterns in //go:embed are refused, as are packages with cgo, C or .syso files (the\n  driver builds Go and Go's assembly only).m2,R0,s1834,A Go program's build plan from source trees of the store (arbace.box's trees), as go list\n  -deps gives it for one GOOS and GOARCH with cgo off: the packages the main package reaches,\n  each after those it imports, each with its Go and assembly files (go/build's rules: the file\n  name's GOOS and GOARCH, //go:build lines, test files and files beginning with _ or . left\n  out, files importing \"C\" left out), its imports resolved (the standard library's vendor\n  directory, GOOSPKG's runtime/goos), its language version and its embedded files.\n\n    (plan cfg)   the plan: {:goos :goarch :goamd64 :goarm64 :main :include\n                            :packages [{:path :name :src :std :lang :go :s :imports\n                                        :importmap :embed} ...]}\n\n  cfg:\n    :goroot    the tree of GOROOT/src (std's packages at their import paths, vendor/, go.mod)\n    :modules   {module-path tree}: each module's root (its go.mod's go line is :lang)\n    :goospkg   the module whose goos/ is runtime/goos (TamaGo's GOOSPKG), when :goos is tamago\n    :main      the main package's import path\n    :goos :goarch :goamd64 :goarm64\n    :tool-tags, :release-tags   the toolchain's (go list's context.ToolTags, ReleaseTags)\n    :tags      more build tags (the program's)\n    :include   GOROOT/pkg/include's tree, passed on to the plan\n\n  A package's :src is a tree of its directory's files, the .h files of its subdirectories\n  (an assembly file includes them by a relative path) and its embedded files: what its compile\n  and asm read, so that a change elsewhere leaves its actions' keys alone. :embed is\n  {:patterns {PATTERN [FILE ...]}} (FILE relative to the package's directory) when it embeds.\n  Glob patterns in //go:embed are refused, as are packages with cgo, C or .syso files (the\n  driver builds Go and Go's assembly only).R1,v15,arbace.box.plan4,failm10,R2,TR3,L1,V2,R4,R5,R6,i35,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,*trees*m10,R9,TR2,TR6,i41,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,entriesm12,R2,TR3,L1,V1,R10,R0,s32,Tree h's map (read once a plan).R6,i43,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,dir-atm12,R2,TR3,L1,V2,R10,Myn1,pm2,R11,R12,R0,s74,The hash of directory path p (\"a/b\") under tree h, nil when there is none.R6,i51,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan4,textm10,R2,TR3,L1,V1,V2,R13,R10,R6,i60,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,known-osS19,s2,jss7,freebsds7,openbsds4,nacls6,wasip1s5,linuxs6,tamagos6,darwins5,plan9s7,windowss3,aixs3,zoss7,solariss3,ioss4,hurds9,dragonflys7,illumoss6,netbsds7,androidm6,R6,i66,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,unix-osS12,s7,freebsds7,openbsds5,linuxs6,darwins3,aixs7,solariss3,ioss4,hurds9,dragonflys7,illumoss6,netbsds7,androidm6,R6,i70,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,known-archS24,s7,arm64bes7,riscv64s11,mips64p32les7,ppc64les5,sparcs5,amd64s3,arms3,386s7,sparc64s4,mipss5,armbes5,s390xs9,mips64p32s5,ppc64s5,riscvs7,loong64s3,ppcs5,arm64s4,s390s4,wasms8,mips64les8,amd64p32s6,mipsles6,mips64m6,R6,i74,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,tag-fnm12,R2,TR3,L1,V1,m2,R14,V5,R15,R16,R17,R18,R19,R0,s55,go/build's matchTag for cfg (cgo off, the gc compiler).R6,i79,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,name-ok?m12,R2,TR3,L1,V2,R20,Myn1,nm2,R11,R12,R0,s81,Whether file name n's GOOS and GOARCH suffixes match (go/build's goodOSArchFile).R6,i88,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,expr-tokensm10,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R6,i104,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan9,eval-exprm12,R2,TR3,L1,V2,R20,Myn1,sm2,R11,R12,R0,s73,The //go:build expression s under match?: || over && over !, parentheses.R6,i107,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan12,header-buildm12,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R0,s113,The //go:build line of source s's header (before its first line that is not a comment or\n  blank), nil when none.R6,i124,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan9,go-tokensm12,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R0,s177,The tokens of Go source s from its start: identifiers, strings (their values), and the\n  punctuation ( ) ; . -- comments skipped, newlines given as ; where Go inserts one. Lazy.R6,i144,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,go-infom12,R2,TR3,L1,V2,Myn1,sm2,R11,R12,R21,R0,s72,Go source s's {:package NAME :imports [PATH ...] :embeds [PATTERN ...]}.R6,i182,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,go-mod-langm12,R2,TR3,L1,V1,R10,R0,s69,go.mod's go line of tree h, as -lang takes it (go1.N), nil when none.R6,i210,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,locatem12,R2,TR3,L1,V3,R22,R23,R24,R0,s199,Where import path p is: {:dir TREE :std BOOL :lang L :path RESOLVED}, or nil. from-std:\n  whether the importing package is the standard library's (its imports resolve in GOROOT's\n  vendor directory).R6,i217,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,embed-filesm12,R2,TR3,L1,V3,R25,Myn7,patternm2,R11,R12,R21,R0,s180,The files pattern names in directory tree d (cmd/go's resolveEmbed, without globs): a file,\n  or a directory's files (not those beginning with . or _ unless the pattern says all:).R6,i238,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan12,package-infom12,R2,TR3,L1,V4,R22,R20,R23,m2,R14,V4,R26,R27,R28,R29,R0,s62,Package p's entry (without :imports resolved), located as loc.R6,i258,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,src-treem12,R2,TR3,L1,V1,m2,R14,V2,R26,R30,R0,s113,Package pkg's source tree: its directory's files, the .h files under its subdirectories and\n  its embedded files.R6,i296,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan4,planm10,R3,L1,V1,R22,R0,s52,The plan of cfg's program (see the namespace's doc).R6,i317,R7,i1,R8,s18,arbace/box/plan.ae")

var Lit_109 *jrt.String = jrt.Intern("arbace.box.plan$eval1305000004$loading__1927001464__auto____1305000005")

var Lit_110 *jrt.String = jrt.Intern("arbace.box.plan$eval1305000008$fn__1305000009")

var Lit_111 *jrt.String = jrt.Intern("arbace.box.plan$fail")

var Lit_112 *jrt.String = jrt.Intern("arbace.box.plan$entries")

var Lit_113 *jrt.String = jrt.Intern("arbace.box.plan$dir_at")

var Lit_114 *jrt.String = jrt.Intern("arbace.box.plan$text")

var Lit_115 *jrt.String = jrt.Intern("arbace.box.plan$tag_fn")

var Lit_116 *jrt.String = jrt.Intern("arbace.box.plan$name_ok_QMARK_")

var Lit_117 *jrt.String = jrt.Intern("arbace.box.plan$expr_tokens")

var Lit_118 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr")

var Lit_119 *jrt.String = jrt.Intern("arbace.box.plan$header_build")

var Lit_120 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens")

var Lit_121 *jrt.String = jrt.Intern("arbace.box.plan$go_info")

var Lit_122 *jrt.String = jrt.Intern("arbace.box.plan$go_mod_lang")

var Lit_123 *jrt.String = jrt.Intern("arbace.box.plan$locate")

var Lit_124 *jrt.String = jrt.Intern("arbace.box.plan$embed_files")

var Lit_125 *jrt.String = jrt.Intern("arbace.box.plan$package_info")

var Lit_126 *jrt.String = jrt.Intern("arbace.box.plan$src_tree")

var Lit_127 *jrt.String = jrt.Intern("arbace.box.plan$plan")
