//line j2g_strings.ae:1
package aot_arbace_box_plan

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn10,arbace.boxkn2,asyn3,boxyn13,arbace.stringyn3,strkn3,docks15,arbace.box.plan5,errorkn3,dirkn4,filekn4,treekn4,blobyn2,ifys15,arbace.box.plan7,*trees*yn2,doys11,arbace.core7,bindingys11,arbace.core4,atomys15,arbace.box.plan10,*imported*kn4,gooskn6,goarchkn9,tool-tagskn12,release-tagskn4,tagskn4,elseks15,arbace.box.plan6,syntaxkn2,orkn3,andkn3,notkn3,tagkn7,trimmedkn8,go-buildkn5,errorkn4,nextkn5,breakkn2,okkn7,packagekn7,importskn6,embedskn5,specskn6,headerkn11,parse-errorkn4,linkkn3,badkn16,invalid-go-fileskn4,namekn10,first-filekn16,ignored-go-fileskn15,x-test-go-fileskn14,x-test-importskn21,x-test-embed-patternskn13,test-go-fileskn12,test-importskn19,test-embed-patternskn8,go-fileskn14,embed-patternskn19,ignored-other-fileskn8,sx-fileskn8,dir-namekn4,kindkn3,msgkn5,no-gokn10,walk-orderkn5,fileskn8,patternskn6,modulekn2,gokn7,replacekn6,gorootkn7,moduleskn7,goospkgkn3,stdkn4,pathkn4,langkn11,embed-fileskn16,test-embed-fileskn18,x-test-embed-fileskn8,resolvedkn10,import-mapkn10,error-kindkn9,not-foundkn6,vendorkn4,skipkn4,depskn8,dep-onlykn8,std-langkn1,skn7,s-fileskn11,raw-importskn5,embedkn7,c-fileskn9,cxx-fileskn7,m-fileskn7,f-fileskn10,swig-fileskn14,swig-cxx-fileskn10,syso-fileskn9,importmapkn7,goamd64kn7,goarm64kn4,mainkn7,includekn8,packageskn3,srcv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.box.planm2,R6,s2454,A Go program's build plan from source trees, as go list -deps gives it for one GOOS and\n  GOARCH with cgo off: the packages the main package reaches, each after those it imports, each\n  with its Go and assembly files (go/build's rules: the file name's GOOS and GOARCH, //go:build\n  and // +build lines, test files and files beginning with _ or . left out, files importing \"C\"\n  left out), its imports resolved (the standard library's vendor directory, cmd's, GOOSPKG's\n  runtime/goos, the modules), its language version and its embedded files (cmd/go's\n  resolveEmbed, globs included).\n\n    (plan cfg)   the plan: {:goos :goarch :goamd64 :goarm64 :main :include\n                            :packages [{:path :name :src :std :lang :go :s :imports\n                                        :importmap :embed} ...]}\n    (import-dir cfg d)   go/build's Import of directory tree d: go list's file lists\n    (load-package cfg path importer)   a package as go list -e sees it, located and imported\n    (list-packages cfg patterns opts)  go list -e [-deps] PATTERN...: std, cmd, P/..., paths\n    (resolve-embed d patterns)         cmd/go's resolveEmbed: {:files [...] :patterns {P [...]}}\n    (match-file cfg d name)            go/build's MatchFile\n\n  cfg:\n    :goroot    the tree of GOROOT/src (std's packages at their import paths, vendor/, cmd/,\n               go.mod)\n    :modules   {module-path tree}: each module's root (its go.mod's go line is :lang)\n    :goospkg   the module whose goos/ is runtime/goos (TamaGo's GOOSPKG), when :goos is tamago\n    :main      the main package's import path (plan)\n    :goos :goarch :goamd64 :goarm64\n    :tool-tags, :release-tags   the toolchain's (go list's context.ToolTags, ReleaseTags)\n    :tags      more build tags (the program's)\n    :include   GOROOT/pkg/include's tree, passed on to the plan\n\n  A tree is a hash of a tree of the store (arbace.box/tree) or a java.io.File, a directory.\n\n  A package's :src (plan's, store trees only) is a tree of its directory's files, the .h files\n  of its subdirectories (an assembly file includes them by a relative path) and its embedded\n  files: what its compile and asm read, so that a change elsewhere leaves its actions' keys\n  alone. :embed is {:patterns {PATTERN [FILE ...]}} (FILE relative to the package's directory)\n  when it embeds. plan refuses packages with cgo, C, C++, Objective-C, Fortran, SWIG, .S or\n  .syso files (the driver builds Go and Go's assembly only).v11,arbace.core7,ex-infov11,arbace.core5,assocR7,v11,arbace.core4,intov11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR8,R9,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv10,arbace.box4,treev15,arbace.box.plan7,*trees*v15,arbace.box.plan12,read-entriesv15,arbace.box.plan4,failR10,v11,arbace.core5,swap!v11,arbace.core6,reducev15,arbace.box.plan7,entriesv11,arbace.core7,reducedv11,arbace.core6,removev11,arbace.core6,empty?v13,arbace.string5,splitp1,/v11,arbace.core5,slurpv10,arbace.box3,getR11,v11,arbace.core7,sort-byv11,arbace.core3,keyv11,arbace.core6,concatv11,arbace.core4,listR12,R13,R14,R15,v11,arbace.core5,applyv11,arbace.core6,vectorR13,R16,v11,arbace.core8,hash-mapR17,R16,v11,arbace.core4,nextv11,arbace.core8,to-arrayR18,R19,R20,R21,R22,v11,arbace.core3,setv11,arbace.core9,contains?v15,arbace.box.plan7,unix-osR23,p2,\\.l2,v11,arbace.core3,vecv11,arbace.core4,subsp1,_l-1,v11,arbace.core4,peekv11,arbace.core3,popv15,arbace.box.plan8,known-osv15,arbace.box.plan10,known-archm2,R24,Tc95,c46,v11,arbace.core9,volatile!l0,v11,arbace.core7,vreset!S3,c33,c40,c41,S2,c38,c124,v15,arbace.box.plan6,syntaxv15,arbace.box.plan9,tag-char?S2,c32,c9,v11,arbace.core3,strR25,R26,R27,v11,arbace.core3,notR28,v11,arbace.core6,every?v13,arbace.string4,trimp3,\\s+v13,arbace.string12,starts-with?V2,R28,s6,ignorev15,arbace.box.plan10,valid-tag?V2,R28,s6,ignorel1,V2,R28,s6,ignorep1,,v15,arbace.box.plan15,eval-constraintv11,arbace.core6,secondl10,l6,R29,R30,v15,arbace.box.plan10,trim-spacev15,arbace.box.plan17,go-build-comment?m2,R31,s28,multiple //go:build commentsV2,R32,TV2,R32,FR32,R33,v15,arbace.box.plan11,file-headerR31,R34,v15,arbace.box.plan14,parse-go-buildv13,arbace.string9,includes?v15,arbace.box.plan16,split-plus-buildv15,arbace.box.plan16,parse-plus-buildv13,arbace.string11,split-linesR24,v11,arbace.core7,ex-datav11,arbace.core2,<=c97,c122,c65,c90,c48,c57,S6,c32,c9,c10,c12,c13,c59,c47,c42,v15,arbace.box.plan11,ident-char?v15,arbace.box.plan10,skip-spacec34,c10,c92,c96,v13,arbace.string10,ends-with?v13,arbace.string7,replacev11,arbace.core4,not=m18,c97,s1,\ac34,s1,\"c98,s1,\bc102,s1,\fc110,s1,\nc114,s1,\rc116,s1,\tc118,s1,\vc92,s1,\\c120,v11,arbace.core10,re-matchesp14,[0-9A-Fa-f]{2}S2,c85,c117,c117,p12,[0-9A-Fa-f]+v15,arbace.box.plan7,hex-vall55296,l57343,c55,p8,[0-7]{3}l65533,v15,arbace.box.plan13,embed-scan-rev13,arbace.string5,trimlv15,arbace.box.plan15,read-string-litv15,arbace.box.plan10,unquote-gov11,arbace.core4,somev11,arbace.core5,rangev11,arbace.core6,mapcatv15,arbace.box.plan14,directive-argsv13,arbace.string5,trimrv15,arbace.box.plan11,go-commentsv15,arbace.box.plan12,read-keywordv15,arbace.box.plan10,read-identc105,c40,c41,v11,arbace.core4,mapvv15,arbace.box.plan13,valid-import?R35,R36,R37,R38,R39,R40,S1,s5,embedv15,arbace.box.plan14,embed-patternsv15,arbace.box.plan7,go-infov15,arbace.box.plan8,name-extv15,arbace.box.plan8,ext-listv15,arbace.box.plan8,name-ok?v15,arbace.box.plan4,textv15,arbace.box.plan16,leading-commentsv15,arbace.box.plan12,should-buildm2,R31,s16,unclosed commentv15,arbace.box.plan10,match-filev15,arbace.box.plan6,tag-fnv11,arbace.core6,updatev11,arbace.core4,fnilS2,R8,R41,R42,R43,S2,s2,.Ss3,.sxR44,R45,S1,s1,CV3,R46,nnV3,R47,R48,R49,V3,R50,R51,R52,V3,R53,R36,R54,R46,R55,R56,R57,v15,arbace.box.plan14,sorted-entriesv11,arbace.core4,sortV6,R36,R51,R48,R54,R52,R49,R53,R50,R47,v11,arbace.core6,dissocR58,R59,R60,S2,R8,R41,S2,s2,.Ss3,.sxS1,s1,CV3,R46,nnV3,R47,R48,R49,V3,R50,R51,R52,V3,R53,R36,R54,V6,R36,R51,R48,R54,R52,R49,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core4,atomv15,arbace.box.plan10,*imported*S2,c45,c93,c94,c93,v15,arbace.box.plan7,get-escc45,c63,c91,v15,arbace.box.plan11,class-matchv11,arbace.core7,re-findp8,[*?\\[\\\\]p1,/S4,s4,.svns3,.hgs4,.bzrs4,.gitv11,arbace.core6,filterS1,c46,v15,arbace.box.plan11,bad-windowsv13,arbace.string10,upper-casep2,\\.p1,/v15,arbace.box.plan6,dir-atv13,arbace.string4,joinv11,arbace.core7,butlastv11,arbace.core4,lastp1,/v15,arbace.box.plan9,has-meta?v15,arbace.box.plan11,path-match?V1,s0,R61,v15,arbace.box.plan9,file-kindv11,arbace.core10,sorted-mapl4,v15,arbace.box.plan13,check-patternv15,arbace.box.plan20,valid-embed-pattern?v15,arbace.box.plan4,globp1,/v15,arbace.box.plan15,bad-embed-name?v11,arbace.core4,takev11,arbace.core8,distinctR62,v11,arbace.core3,valR63,v15,arbace.box.plan13,resolve-embedv11,arbace.core3,mapp5,//.*$p25,module\\s+\\\"?([^\\s\\\"]+)\\\"?p10,go\\s+(\\S+)v11,arbace.core4,keepp52,(?:replace\\s+)?(\\S+)(?:\\s+\\S+)?\\s+=>\\s+(\\.{0,2}/\\S*)p12,replace\\s*\\(R64,R65,R66,v15,arbace.box.plan6,go-modp11,^(\\d+\\.\\d+)R67,R68,R69,R70,R71,R72,v15,arbace.box.plan11,go-mod-langp8,^[^/]*\\.v15,arbace.box.plan10,import-dirv15,arbace.box.plan6,locatev15,arbace.box.plan11,import-dir*v15,arbace.box.plan14,resolve-importR51,R48,v11,arbace.core7,keywordv11,arbace.core4,namev11,arbace.core8,identityR73,R54,R74,R52,R75,R49,v11,arbace.core5,mergev11,arbace.core11,select-keysV4,R8,R70,R72,R64,R76,R77,R78,R79,V4,R8,R70,R72,R64,R80,R81,v15,arbace.box.plan13,walk-packagesm4,R80,TR81,S1,s3,cmdm4,R80,TR81,S1,s3,cmdR82,v15,arbace.box.plan13,match-patternv15,arbace.box.plan12,load-packageR83,S1,s1,CS1,s1,CS1,s1,CS1,s1,Cm2,R61,TR84,R85,R86,R87,S1,s6,unsafeR88,R89,R90,R91,R92,R93,R94,R95,v10,arbace.box8,put-treev15,arbace.box.plan12,package-infoR96,v11,arbace.core7,reverseR97,R98,R99,R100,R101,R102,v15,arbace.box.plan8,src-tree")

var Lit_1 *jrt.String = jrt.Intern(".")

var Lit_2 *jrt.String = jrt.Intern("arbace.box.plan$bad_embed_name_QMARK_$fn__1305000256")

var Lit_3 *jrt.String = jrt.Intern("!#$%&()+,-.=@[]^_{}~ ")

var Lit_4 *jrt.String = jrt.Intern("bad pattern")

var Lit_5 *jrt.String = jrt.Intern("arbace.box.plan$dir_at$fn__1305000025")

var Lit_6 *jrt.String = jrt.Intern("arbace.box.plan$directive_args$fn__1305000114")

var Lit_7 *jrt.String = jrt.Intern("arbace.box.plan$directive_args$fn__1305000116")

var Lit_8 *jrt.String = jrt.Intern("arbace.box.plan$embed_patterns$fn__1305000119")

var Lit_9 *jrt.String = jrt.Intern("//go:embed")

var Lit_10 *jrt.String = jrt.Intern("arbace.box.plan: no tree ")

var Lit_11 *jrt.String = jrt.Intern("java.io.File")

var Lit_12 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_13 *jrt.String = jrt.Intern("java.util.regex.Matcher")

var Lit_14 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_15 *jrt.String = jrt.Intern("\n")

var Lit_16 *jrt.String = jrt.Intern("//")

var Lit_17 *jrt.String = jrt.Intern("arbace.box.plan$file_header$fn__1305000083")

var Lit_18 *jrt.String = jrt.Intern("*/")

var Lit_19 *jrt.String = jrt.Intern("/*")

var Lit_20 *jrt.String = jrt.Intern("/")

var Lit_21 *jrt.String = jrt.Intern("arbace.box.plan$glob$fn__1305000260")

var Lit_22 *jrt.String = jrt.Intern("arbace.box.plan$glob$fn__1305000260$fn__1305000261")

var Lit_23 *jrt.String = jrt.Intern("")

var Lit_24 *jrt.String = jrt.Intern("arbace.box.plan$glob$fn__1305000260$fn__1305000261$iter__1305000262__1305000266")

var Lit_25 *jrt.String = jrt.Intern("arbace.box.plan$glob$fn__1305000260$fn__1305000261$iter__1305000262__1305000266$fn__1305000267")

var Lit_26 *jrt.String = jrt.Intern("arbace.box.plan$glob$fn__1305000260$fn__1305000261$iter__1305000262__1305000266$fn__1305000267$fn__1305000268")

var Lit_27 *jrt.String = jrt.Intern("//go:build")

var Lit_28 *jrt.String = jrt.Intern("\r")

var Lit_29 *jrt.String = jrt.Intern("`")

var Lit_30 *jrt.String = jrt.Intern("arbace.box.plan$go_comments$fn__1305000110")

var Lit_31 *jrt.String = jrt.Intern("\ufeff")

var Lit_32 *jrt.String = jrt.Intern("package")

var Lit_33 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000126")

var Lit_34 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000145")

var Lit_35 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000150")

var Lit_36 *jrt.String = jrt.Intern("invalid import path: ")

var Lit_37 *jrt.String = jrt.Intern("import")

var Lit_38 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000126$spec__1305000127")

var Lit_39 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000126$fn__1305000135")

var Lit_40 *jrt.String = jrt.Intern("unexpected EOF")

var Lit_41 *jrt.String = jrt.Intern("go.mod")

var Lit_42 *jrt.String = jrt.Intern("arbace.box.plan$go_mod$fn__1305000393")

var Lit_43 *jrt.String = jrt.Intern("arbace.box.plan$go_mod$fn__1305000395")

var Lit_44 *jrt.String = jrt.Intern("arbace.box.plan$go_mod$fn__1305000397")

var Lit_45 *jrt.String = jrt.Intern("arbace.box.plan$go_mod$fn__1305000399")

var Lit_46 *jrt.String = jrt.Intern("arbace.box.plan$go_mod$fn__1305000408")

var Lit_47 *jrt.String = jrt.Intern(")")

var Lit_48 *jrt.String = jrt.Intern("replace ")

var Lit_49 *jrt.String = jrt.Intern("go")

var Lit_50 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$add__1305000177")

var Lit_51 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000180")

var Lit_52 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000195")

var Lit_53 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000199")

var Lit_54 *jrt.String = jrt.Intern("build constraints exclude all Go files")

var Lit_55 *jrt.String = jrt.Intern("no Go files")

var Lit_56 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$add__1305000202")

var Lit_57 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000205")

var Lit_58 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000220")

var Lit_59 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000224")

var Lit_60 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000180$bad__1305000187")

var Lit_61 *jrt.String = jrt.Intern(".go")

var Lit_62 *jrt.String = jrt.Intern("_")

var Lit_63 *jrt.String = jrt.Intern(": ")

var Lit_64 *jrt.String = jrt.Intern("documentation")

var Lit_65 *jrt.String = jrt.Intern("_test.go")

var Lit_66 *jrt.String = jrt.Intern("_test")

var Lit_67 *jrt.String = jrt.Intern("use of cgo in test ")

var Lit_68 *jrt.String = jrt.Intern(" not supported")

var Lit_69 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000195$fn__1305000196")

var Lit_70 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000205$bad__1305000212")

var Lit_71 *jrt.String = jrt.Intern("arbace.box.plan$import_dir$fn__1305000220$fn__1305000221")

var Lit_72 *jrt.String = jrt.Intern("arbace.box.plan$list_packages$fn__1305000518")

var Lit_73 *jrt.String = jrt.Intern("arbace.box.plan$list_packages$fn__1305000520")

var Lit_74 *jrt.String = jrt.Intern("arbace.box.plan$list_packages$visit__1305000522")

var Lit_75 *jrt.String = jrt.Intern("arbace.box.plan$list_packages$fn__1305000533")

var Lit_76 *jrt.String = jrt.Intern("arbace.box.plan$list_packages$fn__1305000535")

var Lit_77 *jrt.String = jrt.Intern("arbace.box.plan$list_packages$visit__1305000537")

var Lit_78 *jrt.String = jrt.Intern("arbace.box.plan$load_package$resolve__1305000437")

var Lit_79 *jrt.String = jrt.Intern("arbace.box.plan$load_package$iter__1305000439__1305000443")

var Lit_80 *jrt.String = jrt.Intern("arbace.box.plan$load_package$emb__1305000449")

var Lit_81 *jrt.String = jrt.Intern("arbace.box.plan$load_package$fn__1305000453")

var Lit_82 *jrt.String = jrt.Intern("arbace.box.plan$load_package$fn__1305000456")

var Lit_83 *jrt.String = jrt.Intern("cannot find package ")

var Lit_84 *jrt.String = jrt.Intern("arbace.box.plan$load_package$resolve__1305000461")

var Lit_85 *jrt.String = jrt.Intern("arbace.box.plan$load_package$iter__1305000463__1305000467")

var Lit_86 *jrt.String = jrt.Intern("arbace.box.plan$load_package$emb__1305000473")

var Lit_87 *jrt.String = jrt.Intern("arbace.box.plan$load_package$fn__1305000477")

var Lit_88 *jrt.String = jrt.Intern("arbace.box.plan$load_package$fn__1305000480")

var Lit_89 *jrt.String = jrt.Intern("-map")

var Lit_90 *jrt.String = jrt.Intern("arbace.box.plan$load_package$iter__1305000439__1305000443$fn__1305000444")

var Lit_91 *jrt.String = jrt.Intern("arbace.box.plan$load_package$iter__1305000439__1305000443$fn__1305000444$fn__1305000445")

var Lit_92 *jrt.String = jrt.Intern("C")

var Lit_93 *jrt.String = jrt.Intern("unsafe")

var Lit_94 *jrt.String = jrt.Intern("arbace.box.plan$load_package$iter__1305000463__1305000467$fn__1305000468")

var Lit_95 *jrt.String = jrt.Intern("arbace.box.plan$load_package$iter__1305000463__1305000467$fn__1305000468$fn__1305000469")

var Lit_96 *jrt.String = jrt.Intern("cmd/")

var Lit_97 *jrt.String = jrt.Intern("arbace.box.plan$locate$fn__1305000421")

var Lit_98 *jrt.String = jrt.Intern("arbace.box.plan$locate$fn__1305000424")

var Lit_99 *jrt.String = jrt.Intern("tamago")

var Lit_100 *jrt.String = jrt.Intern("runtime/goos")

var Lit_101 *jrt.String = jrt.Intern("runtime/goos/")

var Lit_102 *jrt.String = jrt.Intern("arbace.box.plan: no module ")

var Lit_103 *jrt.String = jrt.Intern(" (GOOSPKG)")

var Lit_104 *jrt.String = jrt.Intern("goos")

var Lit_105 *jrt.String = jrt.Intern("cmd/vendor/")

var Lit_106 *jrt.String = jrt.Intern("vendor/")

var Lit_107 *jrt.String = jrt.Intern(".syso")

var Lit_108 *jrt.String = jrt.Intern("arbace.box.plan$match_pattern$wild__1305000504")

var Lit_109 *jrt.String = jrt.Intern("std")

var Lit_110 *jrt.String = jrt.Intern("cmd")

var Lit_111 *jrt.String = jrt.Intern("/...")

var Lit_112 *jrt.String = jrt.Intern("arbace.box.plan$match_pattern$wild__1305000508")

var Lit_113 *jrt.String = jrt.Intern("arbace.box.plan$match_pattern$wild__1305000504$fn__1305000505")

var Lit_114 *jrt.String = jrt.Intern("arbace.box.plan$match_pattern$wild__1305000508$fn__1305000509")

var Lit_115 *jrt.String = jrt.Intern("indexOf")

var Lit_116 *jrt.String = jrt.Intern("test")

var Lit_117 *jrt.String = jrt.Intern("package ")

var Lit_118 *jrt.String = jrt.Intern("arbace.box.plan: ")

var Lit_119 *jrt.String = jrt.Intern(": no Go files for ")

var Lit_120 *jrt.String = jrt.Intern(": cgo, C or .syso files are not built by the box's driver")

var Lit_121 *jrt.String = jrt.Intern(": //go:embed ")

var Lit_122 *jrt.String = jrt.Intern("arbace.box.plan$parse_go_build$lex__1305000051")

var Lit_123 *jrt.String = jrt.Intern("arbace.box.plan$parse_go_build$or_STAR___1305000055")

var Lit_124 *jrt.String = jrt.Intern("arbace.box.plan$parse_go_build$and_STAR___1305000057")

var Lit_125 *jrt.String = jrt.Intern("arbace.box.plan$parse_go_build$not_STAR___1305000059")

var Lit_126 *jrt.String = jrt.Intern("arbace.box.plan$parse_go_build$atom_STAR___1305000061")

var Lit_127 *jrt.String = jrt.Intern("unexpected token ")

var Lit_128 *jrt.String = jrt.Intern("&&")

var Lit_129 *jrt.String = jrt.Intern("(")

var Lit_130 *jrt.String = jrt.Intern("missing close paren")

var Lit_131 *jrt.String = jrt.Intern("unexpected end of expression")

var Lit_132 *jrt.String = jrt.Intern("invalid syntax at ")

var Lit_133 *jrt.String = jrt.Intern("arbace.box.plan$parse_go_build$lex__1305000051$fn__1305000052")

var Lit_134 *jrt.String = jrt.Intern("build expression too large")

var Lit_135 *jrt.String = jrt.Intern("!")

var Lit_136 *jrt.String = jrt.Intern("double negation not allowed")

var Lit_137 *jrt.String = jrt.Intern("||")

var Lit_138 *jrt.String = jrt.Intern("empty +build line")

var Lit_139 *jrt.String = jrt.Intern("arbace.box.plan$parse_plus_build$fn__1305000065")

var Lit_140 *jrt.String = jrt.Intern("arbace.box.plan$parse_plus_build$fn__1305000065$fn__1305000066")

var Lit_141 *jrt.String = jrt.Intern("!!")

var Lit_142 *jrt.String = jrt.Intern("arbace.box.plan$path_match_QMARK_$m__1305000239")

var Lit_143 *jrt.String = jrt.Intern("arbace.box.plan$path_match_QMARK_$m__1305000239$fn__1305000241")

var Lit_144 *jrt.String = jrt.Intern("arbace.box.plan: GOROOT/src has no go.mod")

var Lit_145 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000603")

var Lit_146 *jrt.String = jrt.Intern("v1")

var Lit_147 *jrt.String = jrt.Intern("v8.0")

var Lit_148 *jrt.String = jrt.Intern("arbace.box.plan$plan$fn__1305000613")

var Lit_149 *jrt.String = jrt.Intern("arbace.box.plan: an import cycle: ")

var Lit_150 *jrt.String = jrt.Intern(" -> ")

var Lit_151 *jrt.String = jrt.Intern("arbace.box.plan: no package ")

var Lit_152 *jrt.String = jrt.Intern(", imported by ")

var Lit_153 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000603$fn__1305000604")

var Lit_154 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000603$fn__1305000607")

var Lit_155 *jrt.String = jrt.Intern("arbace.box.plan$read_entries$iter__1305000013__1305000017")

var Lit_156 *jrt.String = jrt.Intern("arbace.box.plan$read_entries$iter__1305000013__1305000017$fn__1305000018")

var Lit_157 *jrt.String = jrt.Intern("arbace.box.plan$read_entries$iter__1305000013__1305000017$fn__1305000018$fn__1305000019")

var Lit_158 *jrt.String = jrt.Intern("identifier expected")

var Lit_159 *jrt.String = jrt.Intern(" expected")

var Lit_160 *jrt.String = jrt.Intern("unterminated string")

var Lit_161 *jrt.String = jrt.Intern("newline in string")

var Lit_162 *jrt.String = jrt.Intern("unterminated raw string")

var Lit_163 *jrt.String = jrt.Intern("string expected")

var Lit_164 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$has_mod_QMARK___1305000284")

var Lit_165 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290")

var Lit_166 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$has_mod_QMARK___1305000336")

var Lit_167 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342")

var Lit_168 *jrt.String = jrt.Intern("/go.mod")

var Lit_169 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291")

var Lit_170 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000292")

var Lit_171 *jrt.String = jrt.Intern("all:")

var Lit_172 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000314")

var Lit_173 *jrt.String = jrt.Intern("pattern ")

var Lit_174 *jrt.String = jrt.Intern(": invalid pattern syntax")

var Lit_175 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000316")

var Lit_176 *jrt.String = jrt.Intern(": no matching files found")

var Lit_177 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000292$fn__1305000293")

var Lit_178 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000292$fn__1305000295")

var Lit_179 *jrt.String = jrt.Intern("directory")

var Lit_180 *jrt.String = jrt.Intern("file")

var Lit_181 *jrt.String = jrt.Intern("invalid name ")

var Lit_182 *jrt.String = jrt.Intern("in invalid directory ")

var Lit_183 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000292$fn__1305000295$walk__1305000301")

var Lit_184 *jrt.String = jrt.Intern(": cannot embed directory ")

var Lit_185 *jrt.String = jrt.Intern(": contains no embeddable files")

var Lit_186 *jrt.String = jrt.Intern(": cannot embed irregular file ")

var Lit_187 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000292$fn__1305000295$walk__1305000301$fn__1305000303")

var Lit_188 *jrt.String = jrt.Intern(": cannot embed file ")

var Lit_189 *jrt.String = jrt.Intern(": invalid name ")

var Lit_190 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000316$walk__1305000322")

var Lit_191 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000286__1305000290$fn__1305000291$fn__1305000316$walk__1305000322$fn__1305000324")

var Lit_192 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343")

var Lit_193 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000344")

var Lit_194 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000366")

var Lit_195 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000368")

var Lit_196 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000344$fn__1305000345")

var Lit_197 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000344$fn__1305000347")

var Lit_198 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000344$fn__1305000347$walk__1305000353")

var Lit_199 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000344$fn__1305000347$walk__1305000353$fn__1305000355")

var Lit_200 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000368$walk__1305000374")

var Lit_201 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed$iter__1305000338__1305000342$fn__1305000343$fn__1305000368$walk__1305000374$fn__1305000376")

var Lit_202 *jrt.String = jrt.Intern("parsing //go:build line: ")

var Lit_203 *jrt.String = jrt.Intern("arbace.box.plan$should_build$fn__1305000088")

var Lit_204 *jrt.String = jrt.Intern("+build")

var Lit_205 *jrt.String = jrt.Intern("arbace.box.plan$should_build$fn__1305000088$fn__1305000089")

var Lit_206 *jrt.String = jrt.Intern("unclosed comment")

var Lit_207 *jrt.String = jrt.Intern("unexpected /")

var Lit_208 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000556")

var Lit_209 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000580__1305000584")

var Lit_210 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000580__1305000584$fn__1305000585")

var Lit_211 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000580__1305000584$fn__1305000585$fn__1305000586")

var Lit_212 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000556$iter__1305000557__1305000561")

var Lit_213 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000556$iter__1305000557__1305000561$fn__1305000562")

var Lit_214 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000556$iter__1305000557__1305000561$fn__1305000562$fn__1305000563")

var Lit_215 *jrt.String = jrt.Intern(".h")

var Lit_216 *jrt.String = jrt.Intern("arbace.box.plan$tag_fn$fn__1305000045")

var Lit_217 *jrt.String = jrt.Intern("gc")

var Lit_218 *jrt.String = jrt.Intern("android")

var Lit_219 *jrt.String = jrt.Intern("linux")

var Lit_220 *jrt.String = jrt.Intern("illumos")

var Lit_221 *jrt.String = jrt.Intern("solaris")

var Lit_222 *jrt.String = jrt.Intern("ios")

var Lit_223 *jrt.String = jrt.Intern("darwin")

var Lit_224 *jrt.String = jrt.Intern("unix")

var Lit_225 *jrt.String = jrt.Intern("boringcrypto")

var Lit_226 *jrt.String = jrt.Intern("goexperiment.boringcrypto")

var Lit_227 *jrt.String = jrt.Intern("arbace.box.plan: no blob ")

var Lit_228 *jrt.String = jrt.Intern("arbace.box.plan$types_imports$iter__1305000153__1305000157")

var Lit_229 *jrt.String = jrt.Intern("arbace.box.plan$types_imports$iter__1305000153__1305000157$fn__1305000158")

var Lit_230 *jrt.String = jrt.Intern("arbace.box.plan$types_imports$iter__1305000153__1305000157$fn__1305000158$fn__1305000159")

var Lit_231 *jrt.String = jrt.Intern("init")

var Lit_232 *jrt.String = jrt.Intern("\"")

var Lit_233 *jrt.String = jrt.Intern("arbace.box.plan$unquote_go$flush_BANG___1305000100")

var Lit_234 *jrt.String = jrt.Intern("UTF-8")

var Lit_235 *jrt.String = jrt.Intern("arbace.box.plan$valid_embed_pattern_QMARK_$fn__1305000253")

var Lit_236 *jrt.String = jrt.Intern("..")

var Lit_237 *jrt.String = jrt.Intern("arbace.box.plan$valid_import_QMARK_$fn__1305000103")

var Lit_238 *jrt.String = jrt.Intern("!\"#$%&'()*,:;<=>?[\\]^{|}`")

var Lit_239 *jrt.String = jrt.Intern("arbace.box.plan$walk_packages$walk__1305000490")

var Lit_240 *jrt.String = jrt.Intern("arbace.box.plan$walk_packages$fn__1305000501")

var Lit_241 *jrt.String = jrt.Intern("builtin")

var Lit_242 *jrt.String = jrt.Intern("runtime/cgo")

var Lit_243 *jrt.String = jrt.Intern("arbace.box.plan$walk_packages$walk__1305000490$fn__1305000492")

var Lit_244 *jrt.String = jrt.Intern("testdata")

var Lit_245 *jrt.String = jrt.Intern("vendor")

var Lit_246 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,msgyn4,datakn4,linekn6,columnkn4,filekn7,dynamicyn1,hkn3,tagyn6,Stringyn1,_yn1,&yn4,bodykn4,keysyn4,goosyn6,goarchyn9,tool-tagsyn12,release-tagsyn4,tagsyn6,match?yn1,cyn1,xyn16,java.lang.Stringyn1,ikn7,f-fileskn14,swig-cxx-fileskn10,swig-fileskn10,syso-fileskn9,cxx-fileskn7,c-fileskn7,h-fileskn7,s-fileskn7,m-filesyn3,cfgyn1,dyn4,nameyn1,eyn8,patternsyn10,walk-orderyn1,pyn8,importeryn1,fyn6,vendoryn4,skipyn4,depsyn3,diryn3,stdyn4,langyn4,pathyn5,embedv11,arbace.core5,in-nsMyn15,arbace.box.planm2,R0,s2454,A Go program's build plan from source trees, as go list -deps gives it for one GOOS and\n  GOARCH with cgo off: the packages the main package reaches, each after those it imports, each\n  with its Go and assembly files (go/build's rules: the file name's GOOS and GOARCH, //go:build\n  and // +build lines, test files and files beginning with _ or . left out, files importing \"C\"\n  left out), its imports resolved (the standard library's vendor directory, cmd's, GOOSPKG's\n  runtime/goos, the modules), its language version and its embedded files (cmd/go's\n  resolveEmbed, globs included).\n\n    (plan cfg)   the plan: {:goos :goarch :goamd64 :goarm64 :main :include\n                            :packages [{:path :name :src :std :lang :go :s :imports\n                                        :importmap :embed} ...]}\n    (import-dir cfg d)   go/build's Import of directory tree d: go list's file lists\n    (load-package cfg path importer)   a package as go list -e sees it, located and imported\n    (list-packages cfg patterns opts)  go list -e [-deps] PATTERN...: std, cmd, P/..., paths\n    (resolve-embed d patterns)         cmd/go's resolveEmbed: {:files [...] :patterns {P [...]}}\n    (match-file cfg d name)            go/build's MatchFile\n\n  cfg:\n    :goroot    the tree of GOROOT/src (std's packages at their import paths, vendor/, cmd/,\n               go.mod)\n    :modules   {module-path tree}: each module's root (its go.mod's go line is :lang)\n    :goospkg   the module whose goos/ is runtime/goos (TamaGo's GOOSPKG), when :goos is tamago\n    :main      the main package's import path (plan)\n    :goos :goarch :goamd64 :goarm64\n    :tool-tags, :release-tags   the toolchain's (go list's context.ToolTags, ReleaseTags)\n    :tags      more build tags (the program's)\n    :include   GOROOT/pkg/include's tree, passed on to the plan\n\n  A tree is a hash of a tree of the store (arbace.box/tree) or a java.io.File, a directory.\n\n  A package's :src (plan's, store trees only) is a tree of its directory's files, the .h files\n  of its subdirectories (an assembly file includes them by a relative path) and its embedded\n  files: what its compile and asm read, so that a change elsewhere leaves its actions' keys\n  alone. :embed is {:patterns {PATTERN [FILE ...]}} (FILE relative to the package's directory)\n  when it embeds. plan refuses packages with cgo, C, C++, Objective-C, Fortran, SWIG, .S or\n  .syso files (the driver builds Go and Go's assembly only).m2,R0,s2454,A Go program's build plan from source trees, as go list -deps gives it for one GOOS and\n  GOARCH with cgo off: the packages the main package reaches, each after those it imports, each\n  with its Go and assembly files (go/build's rules: the file name's GOOS and GOARCH, //go:build\n  and // +build lines, test files and files beginning with _ or . left out, files importing \"C\"\n  left out), its imports resolved (the standard library's vendor directory, cmd's, GOOSPKG's\n  runtime/goos, the modules), its language version and its embedded files (cmd/go's\n  resolveEmbed, globs included).\n\n    (plan cfg)   the plan: {:goos :goarch :goamd64 :goarm64 :main :include\n                            :packages [{:path :name :src :std :lang :go :s :imports\n                                        :importmap :embed} ...]}\n    (import-dir cfg d)   go/build's Import of directory tree d: go list's file lists\n    (load-package cfg path importer)   a package as go list -e sees it, located and imported\n    (list-packages cfg patterns opts)  go list -e [-deps] PATTERN...: std, cmd, P/..., paths\n    (resolve-embed d patterns)         cmd/go's resolveEmbed: {:files [...] :patterns {P [...]}}\n    (match-file cfg d name)            go/build's MatchFile\n\n  cfg:\n    :goroot    the tree of GOROOT/src (std's packages at their import paths, vendor/, cmd/,\n               go.mod)\n    :modules   {module-path tree}: each module's root (its go.mod's go line is :lang)\n    :goospkg   the module whose goos/ is runtime/goos (TamaGo's GOOSPKG), when :goos is tamago\n    :main      the main package's import path (plan)\n    :goos :goarch :goamd64 :goarm64\n    :tool-tags, :release-tags   the toolchain's (go list's context.ToolTags, ReleaseTags)\n    :tags      more build tags (the program's)\n    :include   GOROOT/pkg/include's tree, passed on to the plan\n\n  A tree is a hash of a tree of the store (arbace.box/tree) or a java.io.File, a directory.\n\n  A package's :src (plan's, store trees only) is a tree of its directory's files, the .h files\n  of its subdirectories (an assembly file includes them by a relative path) and its embedded\n  files: what its compile and asm read, so that a change elsewhere leaves its actions' keys\n  alone. :embed is {:patterns {PATTERN [FILE ...]}} (FILE relative to the package's directory)\n  when it embeds. plan refuses packages with cgo, C, C++, Objective-C, Fortran, SWIG, .S or\n  .syso files (the driver builds Go and Go's assembly only).R1,v15,arbace.box.plan4,failm10,R2,TR3,L1,V2,R4,R5,R6,i48,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,*trees*m10,R9,TR2,TR6,i54,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan12,read-entriesm12,R2,TR3,L1,V1,R10,R0,s172,Tree h's map {name [:dir H] | [:file H ...] | [:exec H ...]}, nil when there is none. A\n  directory's entries are Files (symbolic links followed: the trees read have none).R6,i56,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,entriesm12,R2,TR3,L1,V1,R10,R0,s32,Tree h's map (read once a plan).R6,i66,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,dir-atm12,R2,TR3,L1,V2,R10,Myn1,pm2,R11,R12,R0,s74,The tree of directory path p (\"a/b\") under tree h, nil when there is none.R6,i75,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan4,textm12,R2,TR3,L1,V1,V2,R13,R10,R0,s20,A file entry's text.R6,i84,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan14,sorted-entriesm10,R2,TR3,L1,V1,R10,R6,i91,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,*imported*m10,R9,TR2,TR6,i93,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,with-treesm12,R2,TR3,L1,V2,R14,R15,R0,s61,body with the trees read, and the directories imported, once.R6,i95,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,known-osS19,s2,jss7,freebsds7,openbsds4,nacls6,wasip1s5,linuxs6,tamagos6,darwins5,plan9s7,windowss3,aixs3,zoss7,solariss3,ioss4,hurds9,dragonflys7,illumoss6,netbsds7,androidm6,R6,i103,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,unix-osS12,s7,freebsds7,openbsds5,linuxs6,darwins3,aixs7,solariss3,ioss4,hurds9,dragonflys7,illumoss6,netbsds7,androidm6,R6,i107,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,known-archS24,s7,arm64bes7,riscv64s11,mips64p32les7,ppc64les5,sparcs5,amd64s3,arms3,386s7,sparc64s4,mipss5,armbes5,s390xs9,mips64p32s5,ppc64s5,riscvs7,loong64s3,ppcs5,arm64s4,s390s4,wasms8,mips64les8,amd64p32s6,mipsles6,mips64m6,R6,i111,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,tag-fnm10,R3,L1,V1,m2,R16,V5,R17,R18,R19,R20,R21,R0,s55,go/build's matchTag for cfg (cgo off, the gc compiler).R6,i116,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,name-ok?m10,R3,L1,V2,R22,Myn1,nm2,R11,R12,R0,s81,Whether file name n's GOOS and GOARCH suffixes match (go/build's goodOSArchFile).R6,i129,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,syntaxm10,R2,TR3,L1,V1,R4,R6,i145,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan9,tag-char?m10,R2,TR3,L1,V1,R23,R6,i147,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan14,parse-go-buildm10,R3,L1,V1,Myn1,sm2,R11,R12,R0,s127,go/build/constraint's parseExpr of a //go:build expression: [:tag T] [:not X] [:and X Y]\n  [:or X Y]; throws on a syntax error.R6,i149,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,valid-tag?m10,R2,TR3,L1,V1,Myn1,wm2,R11,R12,R6,i191,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan16,parse-plus-buildm10,R3,L1,V1,Myn1,sm2,R11,R12,R0,s68,go/build/constraint's parsePlusBuildExpr of a // +build line's text.R6,i193,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan15,eval-constraintm10,R3,L1,V2,R22,R24,R0,s39,The value of constraint x under match?.R6,i208,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan17,go-build-comment?m10,R2,TR3,L1,V1,Myn4,linem2,R11,R12,R6,i217,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan16,split-plus-buildm12,R2,TR3,L1,V1,Myn4,linem2,R11,R12,R0,s88,constraint's splitPlusBuild: the expression of a // +build line, nil when it is not one.R6,i222,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,trim-spacem12,R2,TR3,L1,MV1,Myn1,sm2,R11,R12,m2,R11,R25,R0,s50,bytes.TrimSpace's ASCII part (and Unicode spaces).R6,i231,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,file-headerm10,R3,L1,V1,Myn1,sm2,R11,R12,R0,s180,go/build's parseFileHeader of source s (without its BOM): {:trimmed (the leading run of //\n  comments and blank lines where // +build lines count) :go-build LINE}, or {:error MSG}.R6,i236,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan12,should-buildm10,R3,L1,V2,R22,Myn1,sm2,R11,R12,R0,s51,go/build's shouldBuild: {:ok BOOL} or {:error MSG}.R6,i265,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,ident-char?m10,R2,TR3,L1,V1,R23,R6,i288,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,skip-spacem12,R2,TR3,L1,V2,Myn1,sm2,R11,R12,R26,R0,s162,importReader.peekByte(true): the index of the next character that is not a space, ; or in\n  a comment, from i; throws ::syntax on an unclosed comment or a lone /.R6,i292,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,read-identm12,R2,TR3,L1,V2,Myn1,sm2,R11,R12,R26,R0,s77,The end of the identifier at i (after skip-space); throws when there is none.R6,i310,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan12,read-keywordm10,R2,TR3,L1,V3,Myn1,sm2,R11,R12,R26,Myn2,kwm2,R11,R12,R6,i317,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan15,read-string-litm12,R2,TR3,L1,V2,Myn1,sm2,R11,R12,R26,R0,s64,[end raw-literal] of the string literal at i (after skip-space).R6,i323,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,hex-valm10,R2,TR3,L1,V1,Myn1,hm2,R11,R12,R6,i341,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,unquote-gom10,R3,L1,V1,Myn3,litm2,R11,R12,R0,s82,strconv.Unquote of a Go string literal (\"...\" or `...`); nil when it is not valid.R6,i343,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,valid-import?m10,R3,L1,V1,Myn1,sm2,R11,R12,R0,s94,go/build's isValidImport: not empty, graphic, no spaces and none of !\"#$%&'()*,:;<=>?[\\]^{|}`.R6,i389,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,embed-scan-rem8,R2,TR6,i400,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,go-commentsm12,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R0,s117,The // comments of Go source s, as go/scanner gives them (\\r removed), with strings, raw\n  strings and runes skipped.R6,i402,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan14,directive-argsm12,R2,TR3,L1,V1,Myn4,argsm2,R11,R12,R0,s90,go/ast's Directive.ParseArgs of a //go:embed line's arguments; nil when they do not parse.R6,i427,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan14,embed-patternsm12,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R0,s70,The patterns of source s's //go:embed lines (go/build's parseGoEmbed).R6,i444,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,go-infom10,R3,L1,V1,Myn1,sm2,R11,R12,R0,s275,go/build's readGoInfo of Go source s (its BOM removed): {:package NAME :imports [PATH ...]\n  :embeds [PATTERN ...] :header TEXT} (the header: through the imports, where //go:build lines\n  are read), :parse-error MSG when the header does not parse (the header the whole file).R6,i453,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,types-importsm10,R3,L1,V1,Myn1,sm2,R11,R12,R0,s178,The imports go/types makes a package's of Go source s's import specs (resolver.go's\n  collectObjects): the valid paths (validatedImportPath), not renamed init, \"C\" not\n  renamed.R6,i498,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan16,leading-commentsm12,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R0,s69,go/build's readComments: the leading run of spaces and comments of s.R6,i507,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,name-extm10,R2,TR3,L1,V1,Myn1,nm2,R11,R12,R6,i517,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,ext-listm38,s2,.fR27,s8,.swigcxxR28,s4,.forR27,s5,.swigR29,s5,.sysoR30,s4,.cppR31,s2,.cR32,s2,.hR33,s3,.ccR31,s4,.f90R27,s2,.SR34,s2,.mR35,s3,.hhR33,s3,.sxR34,s2,.FR27,s2,.sR34,s4,.cxxR31,s4,.hxxR33,s4,.hppR33,m8,R2,TR6,i520,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,match-filem10,R3,L2,V3,R36,R37,R38,V4,R22,R37,Myn4,namem2,R11,R12,R39,R0,s201,go/build's matchFile of file name in tree d (entry e): nil when the configuration leaves it\n  out, {:error MSG} when its constraints do not parse, else {} (.syso), {:header} or the Go\n  file's go-info.R6,i527,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan10,import-dirm10,R3,L1,V2,R36,R37,R0,s525,go/build's Import of the package in tree d for cfg (cgo off, the gc compiler): go list's\n  lists {:name :go-files :ignored-go-files :ignored-other-files :s-files :h-files ... :test-go-files\n  :x-test-go-files :imports :test-imports :x-test-imports :embed-patterns\n  :test-embed-patterns :x-test-embed-patterns}, each list in go/build's order (the\n  directory's), the imports and patterns sorted; :sx-files the .S and .sx files the\n  constraints keep (ignored without cgo); :error {:kind :no-go|:bad :msg} as go/build's error.R6,i546,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan7,get-escm12,R2,TR3,L1,V2,Myn1,pm2,R11,R12,R26,R0,s76,path.Match's getEsc: [char next-i] of the class's character at i, or throws.R6,i610,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,class-matchm12,R2,TR3,L1,V3,Myn1,pm2,R11,R12,R26,R23,R0,s142,path.Match's character class at pattern p from i (after its [), against c (nil: none, the\n  class only checked): [matched? next-i], or throws.R6,i622,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,path-match?m10,R3,L1,V2,Myn7,patternm2,R11,R12,Myn4,namem2,R11,R12,R0,s101,path.Match: whether name matches the shell pattern (* ? [...] \\); throws ::syntax on a\n  bad pattern.R6,i635,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,check-patternm12,R2,TR3,L1,V1,Myn1,pm2,R11,R12,R0,s89,Throws ::syntax when pattern is not a valid path.Match pattern (path.Match(pattern, \"\")).R6,i660,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan9,has-meta?m10,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R6,i671,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan20,valid-embed-pattern?m12,R2,TR3,L1,V1,Myn1,pm2,R11,R12,R0,s59,cmd/go's validEmbedPattern: not \".\", and io/fs's ValidPath.R6,i673,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,bad-windowsS22,s3,AUXs3,CONs4,COM9s4,COM6s3,PRNs4,COM3s4,LPT9s3,NULs4,COM1s4,LPT2s4,COM2s4,COM4s4,LPT4s4,COM8s4,LPT5s4,LPT6s4,LPT8s4,COM7s4,LPT1s4,COM5s4,LPT7s4,LPT3m8,R2,TR6,i680,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan15,bad-embed-name?m12,R2,TR3,L1,V1,Myn1,nm2,R11,R12,R0,s84,cmd/go's isBadEmbedName: module.CheckFilePath of the name fails, or a VCS directory.R6,i684,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan9,file-kindm12,R2,TR3,L1,V2,R37,Myn3,relm2,R11,R12,R0,s63,The kind of entry rel (\"a/b\") under tree d: :dir, :file or nil.R6,i699,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan4,globm12,R2,TR3,L1,V2,R37,Myn7,patternm2,R11,R12,R0,s92,filepath.Glob of pattern (relative, / separated) under tree d: the matching paths, relative.R6,i706,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,resolve-embedm10,R3,L2,V2,R37,R40,V3,R37,R40,m2,R16,V1,R41,R0,s350,cmd/go's resolveEmbed of patterns in package directory d: {:files [F ...] (sorted, all\n  patterns') :patterns {P [F ...]}} (each sorted), or {:error MSG}. With :walk-order, each\n  pattern's files in the order of the matches and of their directories' walks (the box's plan's\n  order before GP2, which gc does not depend on: it sorts the files itself).R6,i721,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,go-modm10,R3,L1,V1,R10,R0,s124,Tree h's go.mod: {:module PATH :go \"1.N[.P]\" :replace {PATH DIR}} (replacements by local\n  directories only), nil when none.R6,i777,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,go-mod-langm10,R3,L1,V1,R10,R0,s69,go.mod's go line of tree h, as -lang takes it (go1.N), nil when none.R6,i798,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan6,locatem10,R3,L1,V3,R36,R42,R43,R0,s271,Where import path p is: {:dir TREE :std BOOL :lang L :path RESOLVED}, or nil. importer: the\n  importing package {:path :std} (its imports resolve in GOROOT's vendor directory when it is\n  the standard library's, cmd/vendor when it is cmd's), nil for a pattern's packages.R6,i805,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan15,call-with-treesm10,R3,L1,V1,R44,R0,s71,(f) with the trees read, and the directories imported, once (a load's).R6,i833,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan11,import-dir*m10,R2,TR3,L1,V2,R36,R37,R6,i838,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan14,resolve-importm10,R3,L1,V3,R36,Myn1,pm2,R11,R12,R43,R0,s173,The path import p of a package located as importer (locate's) resolves to, go list's\n  ImportMap's target: nil when there is no such package or it has an error (go/build's).R6,i843,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan12,load-packagem10,R3,L1,V3,R36,Myn1,pm2,R11,R12,R43,R0,s434,Package p as go list -e sees it (importer as locate's): go/build's lists (import-dir) and\n  {:path :dir :std :lang :embed-files :test-embed-files :x-test-embed-files :import-map\n  {IMPORT RESOLVED} :resolved {IMPORT RESOLVED-or-nil}} (every import of the package's files,\n  tests' too, resolved, nil when there is no such package or it has an error), :error MSG as\n  go list's Error (the package's go/build error, an embed pattern's).R6,i851,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,walk-packagesm12,R2,TR3,L1,V3,R37,Myn6,prefixm2,R11,R12,m2,R16,V2,R45,R46,R0,s260,The import paths of the directories under tree d (prefix its import path) that may hold\n  packages: cmd/go's walk (testdata, _ and . directories left out, nested modules and, unless\n  vendor, vendor directories pruned; builtin and runtime/cgo ignored), sorted.R6,i879,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,match-patternm10,R3,L1,V2,R36,Myn7,patternm2,R11,R12,R0,s233,The packages pattern names (go list's matching): \"std\" (GOROOT/src but cmd), \"cmd\",\n  \"P/...\" (P's directory, in a module or GOROOT/src), else the path itself. Wildcards leave\n  out directories without Go files for the configuration.R6,i901,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan13,list-packagesm10,R3,L1,V3,R36,R40,m2,R16,V1,R47,R0,s216,go list -e [-deps] PATTERN...: the packages load-package gives, in go list's order (the\n  patterns' matches, sorted and distinct; with :deps each after those it imports, :dep-only on\n  the packages no pattern names).R6,i923,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan12,package-infom12,R2,TR3,L1,V3,R36,R42,m2,R16,V4,R48,R49,R50,R51,R0,s62,Package p's entry (without :imports resolved), located as loc.R6,i949,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan8,src-treem12,R2,TR3,L1,V1,m2,R16,V2,R48,R52,R0,s113,Package pkg's source tree: its directory's files, the .h files under its subdirectories and\n  its embedded files.R6,i971,R7,i1,R8,s18,arbace/box/plan.aev15,arbace.box.plan4,planm10,R3,L1,V1,R36,R0,s52,The plan of cfg's program (see the namespace's doc).R6,i992,R7,i1,R8,s18,arbace/box/plan.ae")

var Lit_247 *jrt.String = jrt.Intern("arbace.box.plan$eval1305000004$loading__1927001464__auto____1305000005")

var Lit_248 *jrt.String = jrt.Intern("arbace.box.plan$eval1305000008$fn__1305000009")

var Lit_249 *jrt.String = jrt.Intern("arbace.box.plan$fail")

var Lit_250 *jrt.String = jrt.Intern("arbace.box.plan$read_entries")

var Lit_251 *jrt.String = jrt.Intern("arbace.box.plan$entries")

var Lit_252 *jrt.String = jrt.Intern("arbace.box.plan$dir_at")

var Lit_253 *jrt.String = jrt.Intern("arbace.box.plan$text")

var Lit_254 *jrt.String = jrt.Intern("arbace.box.plan$sorted_entries")

var Lit_255 *jrt.String = jrt.Intern("arbace.box.plan$with_trees")

var Lit_256 *jrt.String = jrt.Intern("arbace.box.plan$tag_fn")

var Lit_257 *jrt.String = jrt.Intern("arbace.box.plan$name_ok_QMARK_")

var Lit_258 *jrt.String = jrt.Intern("arbace.box.plan$syntax")

var Lit_259 *jrt.String = jrt.Intern("arbace.box.plan$tag_char_QMARK_")

var Lit_260 *jrt.String = jrt.Intern("arbace.box.plan$parse_go_build")

var Lit_261 *jrt.String = jrt.Intern("arbace.box.plan$valid_tag_QMARK_")

var Lit_262 *jrt.String = jrt.Intern("arbace.box.plan$parse_plus_build")

var Lit_263 *jrt.String = jrt.Intern("arbace.box.plan$eval_constraint")

var Lit_264 *jrt.String = jrt.Intern("arbace.box.plan$go_build_comment_QMARK_")

var Lit_265 *jrt.String = jrt.Intern("arbace.box.plan$split_plus_build")

var Lit_266 *jrt.String = jrt.Intern("arbace.box.plan$trim_space")

var Lit_267 *jrt.String = jrt.Intern("arbace.box.plan$file_header")

var Lit_268 *jrt.String = jrt.Intern("arbace.box.plan$should_build")

var Lit_269 *jrt.String = jrt.Intern("arbace.box.plan$ident_char_QMARK_")

var Lit_270 *jrt.String = jrt.Intern("arbace.box.plan$skip_space")

var Lit_271 *jrt.String = jrt.Intern("arbace.box.plan$read_ident")

var Lit_272 *jrt.String = jrt.Intern("arbace.box.plan$read_keyword")

var Lit_273 *jrt.String = jrt.Intern("arbace.box.plan$read_string_lit")

var Lit_274 *jrt.String = jrt.Intern("arbace.box.plan$hex_val")

var Lit_275 *jrt.String = jrt.Intern("arbace.box.plan$unquote_go")

var Lit_276 *jrt.String = jrt.Intern("arbace.box.plan$valid_import_QMARK_")

var Lit_277 *jrt.String = jrt.Intern("[/\"'`]")

var Lit_278 *jrt.String = jrt.Intern("arbace.box.plan$go_comments")

var Lit_279 *jrt.String = jrt.Intern("arbace.box.plan$directive_args")

var Lit_280 *jrt.String = jrt.Intern("arbace.box.plan$embed_patterns")

var Lit_281 *jrt.String = jrt.Intern("arbace.box.plan$go_info")

var Lit_282 *jrt.String = jrt.Intern("arbace.box.plan$types_imports")

var Lit_283 *jrt.String = jrt.Intern("arbace.box.plan$leading_comments")

var Lit_284 *jrt.String = jrt.Intern("arbace.box.plan$name_ext")

var Lit_285 *jrt.String = jrt.Intern("arbace.box.plan$match_file")

var Lit_286 *jrt.String = jrt.Intern("arbace.box.plan$import_dir")

var Lit_287 *jrt.String = jrt.Intern("arbace.box.plan$get_esc")

var Lit_288 *jrt.String = jrt.Intern("arbace.box.plan$class_match")

var Lit_289 *jrt.String = jrt.Intern("arbace.box.plan$path_match_QMARK_")

var Lit_290 *jrt.String = jrt.Intern("arbace.box.plan$check_pattern")

var Lit_291 *jrt.String = jrt.Intern("arbace.box.plan$has_meta_QMARK_")

var Lit_292 *jrt.String = jrt.Intern("arbace.box.plan$valid_embed_pattern_QMARK_")

var Lit_293 *jrt.String = jrt.Intern("arbace.box.plan$bad_embed_name_QMARK_")

var Lit_294 *jrt.String = jrt.Intern("arbace.box.plan$file_kind")

var Lit_295 *jrt.String = jrt.Intern("arbace.box.plan$glob")

var Lit_296 *jrt.String = jrt.Intern("arbace.box.plan$resolve_embed")

var Lit_297 *jrt.String = jrt.Intern("arbace.box.plan$go_mod")

var Lit_298 *jrt.String = jrt.Intern("arbace.box.plan$go_mod_lang")

var Lit_299 *jrt.String = jrt.Intern("arbace.box.plan$locate")

var Lit_300 *jrt.String = jrt.Intern("arbace.box.plan$call_with_trees")

var Lit_301 *jrt.String = jrt.Intern("arbace.box.plan$import_dir_STAR_")

var Lit_302 *jrt.String = jrt.Intern("arbace.box.plan$resolve_import")

var Lit_303 *jrt.String = jrt.Intern("arbace.box.plan$load_package")

var Lit_304 *jrt.String = jrt.Intern("arbace.box.plan$walk_packages")

var Lit_305 *jrt.String = jrt.Intern("arbace.box.plan$match_pattern")

var Lit_306 *jrt.String = jrt.Intern("arbace.box.plan$list_packages")

var Lit_307 *jrt.String = jrt.Intern("arbace.box.plan$package_info")

var Lit_308 *jrt.String = jrt.Intern("arbace.box.plan$src_tree")

var Lit_309 *jrt.String = jrt.Intern("arbace.box.plan$plan")
