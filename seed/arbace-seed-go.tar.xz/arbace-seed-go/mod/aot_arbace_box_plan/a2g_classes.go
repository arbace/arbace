//line a2g_classes.ae:1
package aot_arbace_box_plan

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_box_plan_dir_at_A_class, Name: "arbace.box.plan$dir_at", Modifiers: 25, Simple: "dir_at", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_dir_at_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_dir_at_fn__1305000014_A_class, Name: "arbace.box.plan$dir_at$fn__1305000014", Modifiers: 25, Simple: "fn__1305000014", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_dir_at_fn__1305000014_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_dir_at_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_embed_files_A_class, Name: "arbace.box.plan$embed_files", Modifiers: 25, Simple: "embed_files", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_embed_files_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_embed_files_walk__1305000114_A_class, Name: "arbace.box.plan$embed_files$walk__1305000114", Modifiers: 25, Simple: "walk__1305000114", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_embed_files_walk__1305000114_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_embed_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_class, Name: "arbace.box.plan$embed_files$walk__1305000114$fn__1305000116", Modifiers: 25, Simple: "fn__1305000116", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_embed_files_walk__1305000114_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_entries_A_class, Name: "arbace.box.plan$entries", Modifiers: 25, Simple: "entries", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_entries_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_class, Name: "arbace.box.plan$eval1305000004$loading__1927001464__auto____1305000005", Modifiers: 25, Simple: "loading__1927001464__auto____1305000005", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_eval1305000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval1305000008_fn__1305000009_A_class, Name: "arbace.box.plan$eval1305000008$fn__1305000009", Modifiers: 25, Simple: "fn__1305000009", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000008_fn__1305000009_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_eval1305000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval_expr_A_class, Name: "arbace.box.plan$eval_expr", Modifiers: 25, Simple: "eval_expr", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval_expr_and_e__1305000039_A_class, Name: "arbace.box.plan$eval_expr$and_e__1305000039", Modifiers: 25, Simple: "and_e__1305000039", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_and_e__1305000039_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_eval_expr_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval_expr_next_t__1305000035_A_class, Name: "arbace.box.plan$eval_expr$next_t__1305000035", Modifiers: 25, Simple: "next_t__1305000035", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_next_t__1305000035_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_eval_expr_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval_expr_not_e__1305000041_A_class, Name: "arbace.box.plan$eval_expr$not_e__1305000041", Modifiers: 25, Simple: "not_e__1305000041", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_not_e__1305000041_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_eval_expr_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval_expr_or_e__1305000037_A_class, Name: "arbace.box.plan$eval_expr$or_e__1305000037", Modifiers: 25, Simple: "or_e__1305000037", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_or_e__1305000037_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_eval_expr_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_eval_expr_peek_t__1305000033_A_class, Name: "arbace.box.plan$eval_expr$peek_t__1305000033", Modifiers: 25, Simple: "peek_t__1305000033", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_peek_t__1305000033_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_eval_expr_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_expr_tokens_A_class, Name: "arbace.box.plan$expr_tokens", Modifiers: 25, Simple: "expr_tokens", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_expr_tokens_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_fail_A_class, Name: "arbace.box.plan$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_fail_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_A_class, Name: "arbace.box.plan$go_info", Modifiers: 25, Simple: "go_info", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000070_A_class, Name: "arbace.box.plan$go_info$fn__1305000070", Modifiers: 25, Simple: "fn__1305000070", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000070_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000072_A_class, Name: "arbace.box.plan$go_info$fn__1305000072", Modifiers: 25, Simple: "fn__1305000072", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_class, Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000073", Modifiers: 25, Simple: "fn__1305000073", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_fn__1305000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_class, Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000078", Modifiers: 25, Simple: "fn__1305000078", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_fn__1305000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_class, Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000080", Modifiers: 25, Simple: "fn__1305000080", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_fn__1305000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_class, Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000085", Modifiers: 25, Simple: "fn__1305000085", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_fn__1305000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_class, Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000087", Modifiers: 25, Simple: "fn__1305000087", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_fn__1305000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000090_A_class, Name: "arbace.box.plan$go_info$fn__1305000090", Modifiers: 25, Simple: "fn__1305000090", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000090_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_class, Name: "arbace.box.plan$go_info$fn__1305000090$fn__1305000091", Modifiers: 25, Simple: "fn__1305000091", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_info_fn__1305000090_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_mod_lang_A_class, Name: "arbace.box.plan$go_mod_lang", Modifiers: 25, Simple: "go_mod_lang", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_mod_lang_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_tokens_A_class, Name: "arbace.box.plan$go_tokens", Modifiers: 25, Simple: "go_tokens", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_tokens_step__1305000055_A_class, Name: "arbace.box.plan$go_tokens$step__1305000055", Modifiers: 25, Simple: "step__1305000055", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_tokens_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class, Name: "arbace.box.plan$go_tokens$step__1305000055$fn__1305000056", Modifiers: 25, Simple: "fn__1305000056", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_tokens_step__1305000055_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_class, Name: "arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000057", Modifiers: 25, Simple: "fn__1305000057", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_class, Name: "arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000059", Modifiers: 25, Simple: "fn__1305000059", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_header_build_A_class, Name: "arbace.box.plan$header_build", Modifiers: 25, Simple: "header_build", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_header_build_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_locate_A_class, Name: "arbace.box.plan$locate", Modifiers: 25, Simple: "locate", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_locate_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_locate_fn__1305000102_A_class, Name: "arbace.box.plan$locate$fn__1305000102", Modifiers: 25, Simple: "fn__1305000102", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_locate_fn__1305000102_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_locate_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_name_ok_QMARK__A_class, Name: "arbace.box.plan$name_ok_QMARK_", Modifiers: 25, Simple: "name_ok_QMARK_", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_name_ok_QMARK__A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_A_class, Name: "arbace.box.plan$package_info", Modifiers: 25, Simple: "package_info", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_fn__1305000184_A_class, Name: "arbace.box.plan$package_info$fn__1305000184", Modifiers: 25, Simple: "fn__1305000184", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_fn__1305000184_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_class, Name: "arbace.box.plan$package_info$iter__1305000130__1305000134", Modifiers: 25, Simple: "iter__1305000130__1305000134", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000130__1305000134_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_class, Name: "arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135", Modifiers: 25, Simple: "fn__1305000135", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_class, Name: "arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135$fn__1305000136", Modifiers: 25, Simple: "fn__1305000136", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_class, Name: "arbace.box.plan$package_info$iter__1305000152__1305000156", Modifiers: 25, Simple: "iter__1305000152__1305000156", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000152__1305000156_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_class, Name: "arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157", Modifiers: 25, Simple: "fn__1305000157", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_class, Name: "arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157$fn__1305000158", Modifiers: 25, Simple: "fn__1305000158", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_class, Name: "arbace.box.plan$package_info$iter__1305000168__1305000172", Modifiers: 25, Simple: "iter__1305000168__1305000172", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000168__1305000172_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_class, Name: "arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173", Modifiers: 25, Simple: "fn__1305000173", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_class, Name: "arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173$fn__1305000174", Modifiers: 25, Simple: "fn__1305000174", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_class, Name: "arbace.box.plan$package_info$iter__1305000189__1305000193", Modifiers: 25, Simple: "iter__1305000189__1305000193", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000189__1305000193_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_class, Name: "arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194", Modifiers: 25, Simple: "fn__1305000194", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_class, Name: "arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194$fn__1305000195", Modifiers: 25, Simple: "fn__1305000195", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_plan_A_class, Name: "arbace.box.plan$plan", Modifiers: 25, Simple: "plan", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_plan_fn__1305000260_A_class, Name: "arbace.box.plan$plan$fn__1305000260", Modifiers: 25, Simple: "fn__1305000260", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_fn__1305000260_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_plan_visit__1305000250_A_class, Name: "arbace.box.plan$plan$visit__1305000250", Modifiers: 25, Simple: "visit__1305000250", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_visit__1305000250_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_class, Name: "arbace.box.plan$plan$visit__1305000250$fn__1305000251", Modifiers: 25, Simple: "fn__1305000251", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_plan_visit__1305000250_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_class, Name: "arbace.box.plan$plan$visit__1305000250$fn__1305000254", Modifiers: 25, Simple: "fn__1305000254", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_plan_visit__1305000250_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_A_class, Name: "arbace.box.plan$src_tree", Modifiers: 25, Simple: "src_tree", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_class, Name: "arbace.box.plan$src_tree$iter__1305000227__1305000231", Modifiers: 25, Simple: "iter__1305000227__1305000231", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_src_tree_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_class, Name: "arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232", Modifiers: 25, Simple: "fn__1305000232", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_class, Name: "arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232$fn__1305000233", Modifiers: 25, Simple: "fn__1305000233", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_sub__1305000203_A_class, Name: "arbace.box.plan$src_tree$sub__1305000203", Modifiers: 25, Simple: "sub__1305000203", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_src_tree_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_class, Name: "arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208", Modifiers: 25, Simple: "iter__1305000204__1305000208", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_src_tree_sub__1305000203_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_class, Name: "arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209", Modifiers: 25, Simple: "fn__1305000209", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_class, Name: "arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209$fn__1305000210", Modifiers: 25, Simple: "fn__1305000210", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_tag_fn_A_class, Name: "arbace.box.plan$tag_fn", Modifiers: 25, Simple: "tag_fn", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_tag_fn_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_tag_fn_fn__1305000028_A_class, Name: "arbace.box.plan$tag_fn$fn__1305000028", Modifiers: 25, Simple: "fn__1305000028", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_tag_fn_fn__1305000028_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_tag_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_plan_text_A_class, Name: "arbace.box.plan$text", Modifiers: 25, Simple: "text", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_text_A", Source: "plan.ae", Declaring: &A_arbace_box_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_box_plan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_A_New()}; return nil }

var A_arbace_box_plan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_plan_A_new}

var A_arbace_box_plan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_A"})

func init() { i := A_arbace_box_plan_A_class.Info(); i.IsInstance = A_arbace_box_plan_A_InstanceOf; i.Init = A_arbace_box_plan_A_Init; i.Table = A_arbace_box_plan_A_members }

var A_arbace_box_plan_dir_at_A_class *jrt.Class

var A_arbace_box_plan_dir_at_fn__1305000014_A_class *jrt.Class

var A_arbace_box_plan_embed_files_A_class *jrt.Class

var A_arbace_box_plan_embed_files_walk__1305000114_A_class *jrt.Class

var A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_class *jrt.Class

var A_arbace_box_plan_entries_A_class *jrt.Class

func A_arbace_box_plan_eval1305000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval1305000004_A_New()}; return nil }

var A_arbace_box_plan_eval1305000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_plan_eval1305000004_A_new}

var A_arbace_box_plan_eval1305000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval1305000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_plan_A_class, Simple: "eval1305000004", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000004_A"})

func init() { i := A_arbace_box_plan_eval1305000004_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval1305000004_A_InstanceOf; i.Table = A_arbace_box_plan_eval1305000004_A_members }

var A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_class *jrt.Class

func A_arbace_box_plan_eval1305000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval1305000008_A_New()}; return nil }

var A_arbace_box_plan_eval1305000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_plan_eval1305000008_A_new}

var A_arbace_box_plan_eval1305000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval1305000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_plan_A_class, Simple: "eval1305000008", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000008_A"})

func init() { i := A_arbace_box_plan_eval1305000008_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval1305000008_A_InstanceOf; i.Table = A_arbace_box_plan_eval1305000008_A_members }

var A_arbace_box_plan_eval1305000008_fn__1305000009_A_class *jrt.Class

var A_arbace_box_plan_eval_expr_A_class *jrt.Class

var A_arbace_box_plan_eval_expr_and_e__1305000039_A_class *jrt.Class

var A_arbace_box_plan_eval_expr_next_t__1305000035_A_class *jrt.Class

var A_arbace_box_plan_eval_expr_not_e__1305000041_A_class *jrt.Class

var A_arbace_box_plan_eval_expr_or_e__1305000037_A_class *jrt.Class

var A_arbace_box_plan_eval_expr_peek_t__1305000033_A_class *jrt.Class

var A_arbace_box_plan_expr_tokens_A_class *jrt.Class

var A_arbace_box_plan_fail_A_class *jrt.Class

var A_arbace_box_plan_go_info_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000070_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000072_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000090_A_class *jrt.Class

var A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_class *jrt.Class

var A_arbace_box_plan_go_mod_lang_A_class *jrt.Class

var A_arbace_box_plan_go_tokens_A_class *jrt.Class

var A_arbace_box_plan_go_tokens_step__1305000055_A_class *jrt.Class

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class *jrt.Class

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_class *jrt.Class

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_class *jrt.Class

var A_arbace_box_plan_header_build_A_class *jrt.Class

var A_arbace_box_plan_locate_A_class *jrt.Class

var A_arbace_box_plan_locate_fn__1305000102_A_class *jrt.Class

var A_arbace_box_plan_name_ok_QMARK__A_class *jrt.Class

var A_arbace_box_plan_package_info_A_class *jrt.Class

var A_arbace_box_plan_package_info_fn__1305000184_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_class *jrt.Class

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_class *jrt.Class

var A_arbace_box_plan_plan_A_class *jrt.Class

var A_arbace_box_plan_plan_fn__1305000260_A_class *jrt.Class

var A_arbace_box_plan_plan_visit__1305000250_A_class *jrt.Class

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_class *jrt.Class

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_class *jrt.Class

var A_arbace_box_plan_src_tree_A_class *jrt.Class

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_class *jrt.Class

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_class *jrt.Class

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_class *jrt.Class

var A_arbace_box_plan_src_tree_sub__1305000203_A_class *jrt.Class

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_class *jrt.Class

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_class *jrt.Class

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_class *jrt.Class

var A_arbace_box_plan_tag_fn_A_class *jrt.Class

var A_arbace_box_plan_tag_fn_fn__1305000028_A_class *jrt.Class

var A_arbace_box_plan_text_A_class *jrt.Class

func A_arbace_box_plan__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_plan__init_A_Load__O()}; return nil }

func A_arbace_box_plan__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan__init_A_New()}; return nil }

var A_arbace_box_plan__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_plan__init_A_invoke, New: A_arbace_box_plan__init_A_new}

var A_arbace_box_plan__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan__init_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan__init_A_class.Info(); i.IsInstance = A_arbace_box_plan__init_A_InstanceOf; i.Init = A_arbace_box_plan__init_A_Init; i.Table = A_arbace_box_plan__init_A_members }
