//line a2g_classes.ae:1
package aot_arbace_box_plan

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_box_plan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_A_New()}; return nil }

var A_arbace_box_plan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_plan_A_new}

var A_arbace_box_plan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_A"})

func init() { i := A_arbace_box_plan_A_class.Info(); i.IsInstance = A_arbace_box_plan_A_InstanceOf; i.Init = A_arbace_box_plan_A_Init; i.Table = A_arbace_box_plan_A_members; jrt.RegisterGoType(A_arbace_box_plan_A_class, reflect.TypeFor[A_arbace_box_plan_A]()) }

func A_arbace_box_plan_dir_at_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_dir_at_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_dir_at_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_dir_at_A_New()}; return nil }

func A_arbace_box_plan_dir_at_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_dir_at_A_fn_class)}; return nil }

var A_arbace_box_plan_dir_at_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_dir_at_A_invoke, New: A_arbace_box_plan_dir_at_A_new, Get: A_arbace_box_plan_dir_at_A_get}

var A_arbace_box_plan_dir_at_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$dir_at", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_A_class, Simple: "dir_at", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_dir_at_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_dir_at_A_class.Info(); i.IsInstance = A_arbace_box_plan_dir_at_A_InstanceOf; i.Init = A_arbace_box_plan_dir_at_A_Init; i.Table = A_arbace_box_plan_dir_at_A_members; jrt.RegisterGoType(A_arbace_box_plan_dir_at_A_class, reflect.TypeFor[A_arbace_box_plan_dir_at_A]()) }

func A_arbace_box_plan_dir_at_fn__1305000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_dir_at_fn__1305000014_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_dir_at_fn__1305000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_dir_at_fn__1305000014_A_New()}; return nil }

func A_arbace_box_plan_dir_at_fn__1305000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_dir_at_fn__1305000014_A_fn_class)}; return nil }

var A_arbace_box_plan_dir_at_fn__1305000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_dir_at_fn__1305000014_A_invoke, New: A_arbace_box_plan_dir_at_fn__1305000014_A_new, Get: A_arbace_box_plan_dir_at_fn__1305000014_A_get}

var A_arbace_box_plan_dir_at_fn__1305000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$dir_at$fn__1305000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_dir_at_A_class, Simple: "fn__1305000014", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_dir_at_fn__1305000014_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_dir_at_fn__1305000014_A_class.Info(); i.IsInstance = A_arbace_box_plan_dir_at_fn__1305000014_A_InstanceOf; i.Init = A_arbace_box_plan_dir_at_fn__1305000014_A_Init; i.Table = A_arbace_box_plan_dir_at_fn__1305000014_A_members; jrt.RegisterGoType(A_arbace_box_plan_dir_at_fn__1305000014_A_class, reflect.TypeFor[A_arbace_box_plan_dir_at_fn__1305000014_A]()) }

func A_arbace_box_plan_embed_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_embed_files_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_embed_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_embed_files_A_New()}; return nil }

func A_arbace_box_plan_embed_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_embed_files_A_fn_class)}; return nil }

var A_arbace_box_plan_embed_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_embed_files_A_invoke, New: A_arbace_box_plan_embed_files_A_new, Get: A_arbace_box_plan_embed_files_A_get}

var A_arbace_box_plan_embed_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$embed_files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_plan_A_class, Simple: "embed_files", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_embed_files_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_embed_files_A_class.Info(); i.IsInstance = A_arbace_box_plan_embed_files_A_InstanceOf; i.Init = A_arbace_box_plan_embed_files_A_Init; i.Table = A_arbace_box_plan_embed_files_A_members; jrt.RegisterGoType(A_arbace_box_plan_embed_files_A_class, reflect.TypeFor[A_arbace_box_plan_embed_files_A]()) }

func A_arbace_box_plan_embed_files_walk__1305000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_embed_files_walk__1305000114_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_embed_files_walk__1305000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_embed_files_walk__1305000114_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_embed_files_walk__1305000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_embed_files_walk__1305000114_A_fn_class)}; return nil }

var A_arbace_box_plan_embed_files_walk__1305000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_embed_files_walk__1305000114_A_invoke, New: A_arbace_box_plan_embed_files_walk__1305000114_A_new, Get: A_arbace_box_plan_embed_files_walk__1305000114_A_get}

var A_arbace_box_plan_embed_files_walk__1305000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$embed_files$walk__1305000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_embed_files_A_class, Simple: "walk__1305000114", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_embed_files_walk__1305000114_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_embed_files_walk__1305000114_A_class.Info(); i.IsInstance = A_arbace_box_plan_embed_files_walk__1305000114_A_InstanceOf; i.Init = A_arbace_box_plan_embed_files_walk__1305000114_A_Init; i.Table = A_arbace_box_plan_embed_files_walk__1305000114_A_members; jrt.RegisterGoType(A_arbace_box_plan_embed_files_walk__1305000114_A_class, reflect.TypeFor[A_arbace_box_plan_embed_files_walk__1305000114_A]()) }

func A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_fn_class)}; return nil }

var A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_invoke, New: A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_new, Get: A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_get}

var A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$embed_files$walk__1305000114$fn__1305000116", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_embed_files_walk__1305000114_A_class, Simple: "fn__1305000116", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_class.Info(); i.IsInstance = A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_InstanceOf; i.Init = A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_Init; i.Table = A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_members; jrt.RegisterGoType(A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_class, reflect.TypeFor[A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A]()) }

func A_arbace_box_plan_entries_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_entries_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_entries_A_New()}; return nil }

func A_arbace_box_plan_entries_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_entries_A_fn_class)}; return nil }

var A_arbace_box_plan_entries_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_entries_A_invoke, New: A_arbace_box_plan_entries_A_new, Get: A_arbace_box_plan_entries_A_get}

var A_arbace_box_plan_entries_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$entries", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "entries", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_entries_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_entries_A_class.Info(); i.IsInstance = A_arbace_box_plan_entries_A_InstanceOf; i.Init = A_arbace_box_plan_entries_A_Init; i.Table = A_arbace_box_plan_entries_A_members; jrt.RegisterGoType(A_arbace_box_plan_entries_A_class, reflect.TypeFor[A_arbace_box_plan_entries_A]()) }

func A_arbace_box_plan_eval1305000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval1305000004_A_New()}; return nil }

var A_arbace_box_plan_eval1305000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_plan_eval1305000004_A_new}

var A_arbace_box_plan_eval1305000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval1305000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_plan_A_class, Simple: "eval1305000004", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000004_A"})

func init() { i := A_arbace_box_plan_eval1305000004_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval1305000004_A_InstanceOf; i.Table = A_arbace_box_plan_eval1305000004_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval1305000004_A_class, reflect.TypeFor[A_arbace_box_plan_eval1305000004_A]()) }

func A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_New()}; return nil }

func A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_fn_class)}; return nil }

var A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_invoke, New: A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_new, Get: A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_get}

var A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval1305000004$loading__1927001464__auto____1305000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_eval1305000004_A_class, Simple: "loading__1927001464__auto____1305000005", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_InstanceOf; i.Init = A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_Init; i.Table = A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_class, reflect.TypeFor[A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A]()) }

func A_arbace_box_plan_eval1305000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval1305000008_A_New()}; return nil }

var A_arbace_box_plan_eval1305000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_plan_eval1305000008_A_new}

var A_arbace_box_plan_eval1305000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval1305000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_plan_A_class, Simple: "eval1305000008", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000008_A"})

func init() { i := A_arbace_box_plan_eval1305000008_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval1305000008_A_InstanceOf; i.Table = A_arbace_box_plan_eval1305000008_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval1305000008_A_class, reflect.TypeFor[A_arbace_box_plan_eval1305000008_A]()) }

func A_arbace_box_plan_eval1305000008_fn__1305000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval1305000008_fn__1305000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_eval1305000008_fn__1305000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval1305000008_fn__1305000009_A_New()}; return nil }

func A_arbace_box_plan_eval1305000008_fn__1305000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval1305000008_fn__1305000009_A_fn_class)}; return nil }

var A_arbace_box_plan_eval1305000008_fn__1305000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval1305000008_fn__1305000009_A_invoke, New: A_arbace_box_plan_eval1305000008_fn__1305000009_A_new, Get: A_arbace_box_plan_eval1305000008_fn__1305000009_A_get}

var A_arbace_box_plan_eval1305000008_fn__1305000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval1305000008$fn__1305000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_eval1305000008_A_class, Simple: "fn__1305000009", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval1305000008_fn__1305000009_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval1305000008_fn__1305000009_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval1305000008_fn__1305000009_A_InstanceOf; i.Init = A_arbace_box_plan_eval1305000008_fn__1305000009_A_Init; i.Table = A_arbace_box_plan_eval1305000008_fn__1305000009_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval1305000008_fn__1305000009_A_class, reflect.TypeFor[A_arbace_box_plan_eval1305000008_fn__1305000009_A]()) }

func A_arbace_box_plan_eval_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval_expr_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_eval_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval_expr_A_New()}; return nil }

func A_arbace_box_plan_eval_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval_expr_A_fn_class)}; return nil }

var A_arbace_box_plan_eval_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval_expr_A_invoke, New: A_arbace_box_plan_eval_expr_A_new, Get: A_arbace_box_plan_eval_expr_A_get}

var A_arbace_box_plan_eval_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval_expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_A_class, Simple: "eval_expr", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval_expr_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval_expr_A_InstanceOf; i.Init = A_arbace_box_plan_eval_expr_A_Init; i.Table = A_arbace_box_plan_eval_expr_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval_expr_A_class, reflect.TypeFor[A_arbace_box_plan_eval_expr_A]()) }

func A_arbace_box_plan_eval_expr_and_e__1305000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval_expr_and_e__1305000039_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_eval_expr_and_e__1305000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval_expr_and_e__1305000039_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_eval_expr_and_e__1305000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval_expr_and_e__1305000039_A_fn_class)}; return nil }

var A_arbace_box_plan_eval_expr_and_e__1305000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval_expr_and_e__1305000039_A_invoke, New: A_arbace_box_plan_eval_expr_and_e__1305000039_A_new, Get: A_arbace_box_plan_eval_expr_and_e__1305000039_A_get}

var A_arbace_box_plan_eval_expr_and_e__1305000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval_expr$and_e__1305000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_eval_expr_A_class, Simple: "and_e__1305000039", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_and_e__1305000039_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval_expr_and_e__1305000039_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval_expr_and_e__1305000039_A_InstanceOf; i.Init = A_arbace_box_plan_eval_expr_and_e__1305000039_A_Init; i.Table = A_arbace_box_plan_eval_expr_and_e__1305000039_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval_expr_and_e__1305000039_A_class, reflect.TypeFor[A_arbace_box_plan_eval_expr_and_e__1305000039_A]()) }

func A_arbace_box_plan_eval_expr_next_t__1305000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval_expr_next_t__1305000035_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_eval_expr_next_t__1305000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval_expr_next_t__1305000035_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_eval_expr_next_t__1305000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval_expr_next_t__1305000035_A_fn_class)}; return nil }

var A_arbace_box_plan_eval_expr_next_t__1305000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval_expr_next_t__1305000035_A_invoke, New: A_arbace_box_plan_eval_expr_next_t__1305000035_A_new, Get: A_arbace_box_plan_eval_expr_next_t__1305000035_A_get}

var A_arbace_box_plan_eval_expr_next_t__1305000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval_expr$next_t__1305000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_eval_expr_A_class, Simple: "next_t__1305000035", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_next_t__1305000035_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval_expr_next_t__1305000035_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval_expr_next_t__1305000035_A_InstanceOf; i.Init = A_arbace_box_plan_eval_expr_next_t__1305000035_A_Init; i.Table = A_arbace_box_plan_eval_expr_next_t__1305000035_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval_expr_next_t__1305000035_A_class, reflect.TypeFor[A_arbace_box_plan_eval_expr_next_t__1305000035_A]()) }

func A_arbace_box_plan_eval_expr_not_e__1305000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval_expr_not_e__1305000041_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_eval_expr_not_e__1305000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval_expr_not_e__1305000041_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_eval_expr_not_e__1305000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval_expr_not_e__1305000041_A_fn_class)}; return nil }

var A_arbace_box_plan_eval_expr_not_e__1305000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval_expr_not_e__1305000041_A_invoke, New: A_arbace_box_plan_eval_expr_not_e__1305000041_A_new, Get: A_arbace_box_plan_eval_expr_not_e__1305000041_A_get}

var A_arbace_box_plan_eval_expr_not_e__1305000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval_expr$not_e__1305000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_eval_expr_A_class, Simple: "not_e__1305000041", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_not_e__1305000041_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval_expr_not_e__1305000041_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval_expr_not_e__1305000041_A_InstanceOf; i.Init = A_arbace_box_plan_eval_expr_not_e__1305000041_A_Init; i.Table = A_arbace_box_plan_eval_expr_not_e__1305000041_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval_expr_not_e__1305000041_A_class, reflect.TypeFor[A_arbace_box_plan_eval_expr_not_e__1305000041_A]()) }

func A_arbace_box_plan_eval_expr_or_e__1305000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval_expr_or_e__1305000037_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_eval_expr_or_e__1305000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval_expr_or_e__1305000037_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_eval_expr_or_e__1305000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval_expr_or_e__1305000037_A_fn_class)}; return nil }

var A_arbace_box_plan_eval_expr_or_e__1305000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval_expr_or_e__1305000037_A_invoke, New: A_arbace_box_plan_eval_expr_or_e__1305000037_A_new, Get: A_arbace_box_plan_eval_expr_or_e__1305000037_A_get}

var A_arbace_box_plan_eval_expr_or_e__1305000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval_expr$or_e__1305000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_eval_expr_A_class, Simple: "or_e__1305000037", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_or_e__1305000037_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval_expr_or_e__1305000037_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval_expr_or_e__1305000037_A_InstanceOf; i.Init = A_arbace_box_plan_eval_expr_or_e__1305000037_A_Init; i.Table = A_arbace_box_plan_eval_expr_or_e__1305000037_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval_expr_or_e__1305000037_A_class, reflect.TypeFor[A_arbace_box_plan_eval_expr_or_e__1305000037_A]()) }

func A_arbace_box_plan_eval_expr_peek_t__1305000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_eval_expr_peek_t__1305000033_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_eval_expr_peek_t__1305000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_eval_expr_peek_t__1305000033_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_eval_expr_peek_t__1305000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_eval_expr_peek_t__1305000033_A_fn_class)}; return nil }

var A_arbace_box_plan_eval_expr_peek_t__1305000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_eval_expr_peek_t__1305000033_A_invoke, New: A_arbace_box_plan_eval_expr_peek_t__1305000033_A_new, Get: A_arbace_box_plan_eval_expr_peek_t__1305000033_A_get}

var A_arbace_box_plan_eval_expr_peek_t__1305000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$eval_expr$peek_t__1305000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_eval_expr_A_class, Simple: "peek_t__1305000033", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_eval_expr_peek_t__1305000033_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_eval_expr_peek_t__1305000033_A_class.Info(); i.IsInstance = A_arbace_box_plan_eval_expr_peek_t__1305000033_A_InstanceOf; i.Init = A_arbace_box_plan_eval_expr_peek_t__1305000033_A_Init; i.Table = A_arbace_box_plan_eval_expr_peek_t__1305000033_A_members; jrt.RegisterGoType(A_arbace_box_plan_eval_expr_peek_t__1305000033_A_class, reflect.TypeFor[A_arbace_box_plan_eval_expr_peek_t__1305000033_A]()) }

func A_arbace_box_plan_expr_tokens_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_expr_tokens_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_expr_tokens_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_expr_tokens_A_New()}; return nil }

func A_arbace_box_plan_expr_tokens_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_expr_tokens_A_fn_class)}; return nil }

var A_arbace_box_plan_expr_tokens_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_expr_tokens_A_invoke, New: A_arbace_box_plan_expr_tokens_A_new, Get: A_arbace_box_plan_expr_tokens_A_get}

var A_arbace_box_plan_expr_tokens_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$expr_tokens", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "expr_tokens", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_expr_tokens_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_expr_tokens_A_class.Info(); i.IsInstance = A_arbace_box_plan_expr_tokens_A_InstanceOf; i.Init = A_arbace_box_plan_expr_tokens_A_Init; i.Table = A_arbace_box_plan_expr_tokens_A_members; jrt.RegisterGoType(A_arbace_box_plan_expr_tokens_A_class, reflect.TypeFor[A_arbace_box_plan_expr_tokens_A]()) }

func A_arbace_box_plan_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_fail_A_New()}; return nil }

func A_arbace_box_plan_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_fail_A_fn_class)}; return nil }

var A_arbace_box_plan_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_fail_A_invoke, New: A_arbace_box_plan_fail_A_new, Get: A_arbace_box_plan_fail_A_get}

var A_arbace_box_plan_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_A_class, Simple: "fail", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_fail_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_fail_A_class.Info(); i.IsInstance = A_arbace_box_plan_fail_A_InstanceOf; i.Init = A_arbace_box_plan_fail_A_Init; i.Table = A_arbace_box_plan_fail_A_members; jrt.RegisterGoType(A_arbace_box_plan_fail_A_class, reflect.TypeFor[A_arbace_box_plan_fail_A]()) }

func A_arbace_box_plan_go_info_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_go_info_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_A_New()}; return nil }

func A_arbace_box_plan_go_info_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_A_invoke, New: A_arbace_box_plan_go_info_A_new, Get: A_arbace_box_plan_go_info_A_get}

var A_arbace_box_plan_go_info_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_A_class, Simple: "go_info", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_A_Init; i.Table = A_arbace_box_plan_go_info_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_A]()) }

func A_arbace_box_plan_go_info_fn__1305000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000070_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000070_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000070_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000070_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000070_A_new, Get: A_arbace_box_plan_go_info_fn__1305000070_A_get}

var A_arbace_box_plan_go_info_fn__1305000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_A_class, Simple: "fn__1305000070", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000070_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000070_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000070_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000070_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000070_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000070_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000070_A]()) }

func A_arbace_box_plan_go_info_fn__1305000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000072_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000072_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000072_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000072_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000072_A_new, Get: A_arbace_box_plan_go_info_fn__1305000072_A_get}

var A_arbace_box_plan_go_info_fn__1305000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_go_info_A_class, Simple: "fn__1305000072", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000072_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000072_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000072_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000072_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000072_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000072_A]()) }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_new, Get: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_get}

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_fn__1305000072_A_class, Simple: "fn__1305000073", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A]()) }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_new, Get: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_get}

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_fn__1305000072_A_class, Simple: "fn__1305000078", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A]()) }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_new, Get: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_get}

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_fn__1305000072_A_class, Simple: "fn__1305000080", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A]()) }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_new, Get: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_get}

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_fn__1305000072_A_class, Simple: "fn__1305000085", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A]()) }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_new, Get: A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_get}

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000072$fn__1305000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_fn__1305000072_A_class, Simple: "fn__1305000087", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A]()) }

func A_arbace_box_plan_go_info_fn__1305000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000090_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000090_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000090_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000090_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000090_A_new, Get: A_arbace_box_plan_go_info_fn__1305000090_A_get}

var A_arbace_box_plan_go_info_fn__1305000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_A_class, Simple: "fn__1305000090", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000090_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000090_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000090_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000090_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000090_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000090_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000090_A]()) }

func A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_New()}; return nil }

func A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_fn_class)}; return nil }

var A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_invoke, New: A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_new, Get: A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_get}

var A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_info$fn__1305000090$fn__1305000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_go_info_fn__1305000090_A_class, Simple: "fn__1305000091", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_InstanceOf; i.Init = A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_Init; i.Table = A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_class, reflect.TypeFor[A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A]()) }

func A_arbace_box_plan_go_mod_lang_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_mod_lang_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_mod_lang_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_mod_lang_A_New()}; return nil }

func A_arbace_box_plan_go_mod_lang_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_mod_lang_A_fn_class)}; return nil }

var A_arbace_box_plan_go_mod_lang_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_mod_lang_A_invoke, New: A_arbace_box_plan_go_mod_lang_A_new, Get: A_arbace_box_plan_go_mod_lang_A_get}

var A_arbace_box_plan_go_mod_lang_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_mod_lang", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "go_mod_lang", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_mod_lang_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_mod_lang_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_mod_lang_A_InstanceOf; i.Init = A_arbace_box_plan_go_mod_lang_A_Init; i.Table = A_arbace_box_plan_go_mod_lang_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_mod_lang_A_class, reflect.TypeFor[A_arbace_box_plan_go_mod_lang_A]()) }

func A_arbace_box_plan_go_tokens_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_tokens_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_go_tokens_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_tokens_A_New()}; return nil }

func A_arbace_box_plan_go_tokens_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_tokens_A_fn_class)}; return nil }

var A_arbace_box_plan_go_tokens_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_tokens_A_invoke, New: A_arbace_box_plan_go_tokens_A_new, Get: A_arbace_box_plan_go_tokens_A_get}

var A_arbace_box_plan_go_tokens_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_tokens", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "go_tokens", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_tokens_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_tokens_A_InstanceOf; i.Init = A_arbace_box_plan_go_tokens_A_Init; i.Table = A_arbace_box_plan_go_tokens_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_tokens_A_class, reflect.TypeFor[A_arbace_box_plan_go_tokens_A]()) }

func A_arbace_box_plan_go_tokens_step__1305000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_tokens_step__1305000055_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_tokens_step__1305000055_A_New_I_O(args[0].(int32), args[1])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_tokens_step__1305000055_A_fn_class)}; return nil }

var A_arbace_box_plan_go_tokens_step__1305000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_tokens_step__1305000055_A_invoke, New: A_arbace_box_plan_go_tokens_step__1305000055_A_new, Get: A_arbace_box_plan_go_tokens_step__1305000055_A_get}

var A_arbace_box_plan_go_tokens_step__1305000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_tokens$step__1305000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_go_tokens_A_class, Simple: "step__1305000055", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_tokens_step__1305000055_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_tokens_step__1305000055_A_InstanceOf; i.Init = A_arbace_box_plan_go_tokens_step__1305000055_A_Init; i.Table = A_arbace_box_plan_go_tokens_step__1305000055_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_tokens_step__1305000055_A_class, reflect.TypeFor[A_arbace_box_plan_go_tokens_step__1305000055_A]()) }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_New_O_I_O_O_O(args[0], args[1].(int32), args[2], args[3], args[4])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_fn_class)}; return nil }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_invoke, New: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_new, Get: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_get}

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_tokens$step__1305000055$fn__1305000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_go_tokens_step__1305000055_A_class, Simple: "fn__1305000056", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_InstanceOf; i.Init = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_Init; i.Table = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class, reflect.TypeFor[A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A]()) }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_fn_class)}; return nil }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_invoke, New: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_new, Get: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_get}

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class, Simple: "fn__1305000057", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_InstanceOf; i.Init = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_Init; i.Table = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_class, reflect.TypeFor[A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A]()) }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_fn_class)}; return nil }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_invoke, New: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_new, Get: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_get}

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_class, Simple: "fn__1305000059", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_class.Info(); i.IsInstance = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_InstanceOf; i.Init = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_Init; i.Table = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_members; jrt.RegisterGoType(A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_class, reflect.TypeFor[A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A]()) }

func A_arbace_box_plan_header_build_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_header_build_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_header_build_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_header_build_A_New()}; return nil }

func A_arbace_box_plan_header_build_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_header_build_A_fn_class)}; return nil }

var A_arbace_box_plan_header_build_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_header_build_A_invoke, New: A_arbace_box_plan_header_build_A_new, Get: A_arbace_box_plan_header_build_A_get}

var A_arbace_box_plan_header_build_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$header_build", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "header_build", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_header_build_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_header_build_A_class.Info(); i.IsInstance = A_arbace_box_plan_header_build_A_InstanceOf; i.Init = A_arbace_box_plan_header_build_A_Init; i.Table = A_arbace_box_plan_header_build_A_members; jrt.RegisterGoType(A_arbace_box_plan_header_build_A_class, reflect.TypeFor[A_arbace_box_plan_header_build_A]()) }

func A_arbace_box_plan_locate_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_locate_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_locate_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_locate_A_New()}; return nil }

func A_arbace_box_plan_locate_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_locate_A_fn_class)}; return nil }

var A_arbace_box_plan_locate_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_locate_A_invoke, New: A_arbace_box_plan_locate_A_new, Get: A_arbace_box_plan_locate_A_get}

var A_arbace_box_plan_locate_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$locate", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_plan_A_class, Simple: "locate", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_locate_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_locate_A_class.Info(); i.IsInstance = A_arbace_box_plan_locate_A_InstanceOf; i.Init = A_arbace_box_plan_locate_A_Init; i.Table = A_arbace_box_plan_locate_A_members; jrt.RegisterGoType(A_arbace_box_plan_locate_A_class, reflect.TypeFor[A_arbace_box_plan_locate_A]()) }

func A_arbace_box_plan_locate_fn__1305000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_locate_fn__1305000102_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_locate_fn__1305000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_locate_fn__1305000102_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_locate_fn__1305000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_locate_fn__1305000102_A_fn_class)}; return nil }

var A_arbace_box_plan_locate_fn__1305000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_locate_fn__1305000102_A_invoke, New: A_arbace_box_plan_locate_fn__1305000102_A_new, Get: A_arbace_box_plan_locate_fn__1305000102_A_get}

var A_arbace_box_plan_locate_fn__1305000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$locate$fn__1305000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_locate_A_class, Simple: "fn__1305000102", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_locate_fn__1305000102_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_locate_fn__1305000102_A_class.Info(); i.IsInstance = A_arbace_box_plan_locate_fn__1305000102_A_InstanceOf; i.Init = A_arbace_box_plan_locate_fn__1305000102_A_Init; i.Table = A_arbace_box_plan_locate_fn__1305000102_A_members; jrt.RegisterGoType(A_arbace_box_plan_locate_fn__1305000102_A_class, reflect.TypeFor[A_arbace_box_plan_locate_fn__1305000102_A]()) }

func A_arbace_box_plan_name_ok_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_name_ok_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_name_ok_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_name_ok_QMARK__A_New()}; return nil }

func A_arbace_box_plan_name_ok_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_name_ok_QMARK__A_fn_class)}; return nil }

var A_arbace_box_plan_name_ok_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_name_ok_QMARK__A_invoke, New: A_arbace_box_plan_name_ok_QMARK__A_new, Get: A_arbace_box_plan_name_ok_QMARK__A_get}

var A_arbace_box_plan_name_ok_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$name_ok_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_A_class, Simple: "name_ok_QMARK_", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_name_ok_QMARK__A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_name_ok_QMARK__A_class.Info(); i.IsInstance = A_arbace_box_plan_name_ok_QMARK__A_InstanceOf; i.Init = A_arbace_box_plan_name_ok_QMARK__A_Init; i.Table = A_arbace_box_plan_name_ok_QMARK__A_members; jrt.RegisterGoType(A_arbace_box_plan_name_ok_QMARK__A_class, reflect.TypeFor[A_arbace_box_plan_name_ok_QMARK__A]()) }

func A_arbace_box_plan_package_info_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_plan_package_info_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_A_New()}; return nil }

func A_arbace_box_plan_package_info_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_A_invoke, New: A_arbace_box_plan_package_info_A_new, Get: A_arbace_box_plan_package_info_A_get}

var A_arbace_box_plan_package_info_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_box_plan_A_class, Simple: "package_info", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_A_Init; i.Table = A_arbace_box_plan_package_info_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_A]()) }

func A_arbace_box_plan_package_info_fn__1305000184_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_fn__1305000184_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_package_info_fn__1305000184_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_fn__1305000184_A_New()}; return nil }

func A_arbace_box_plan_package_info_fn__1305000184_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_fn__1305000184_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_fn__1305000184_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_fn__1305000184_A_invoke, New: A_arbace_box_plan_package_info_fn__1305000184_A_new, Get: A_arbace_box_plan_package_info_fn__1305000184_A_get}

var A_arbace_box_plan_package_info_fn__1305000184_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$fn__1305000184", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_package_info_A_class, Simple: "fn__1305000184", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_fn__1305000184_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_fn__1305000184_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_fn__1305000184_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_fn__1305000184_A_Init; i.Table = A_arbace_box_plan_package_info_fn__1305000184_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_fn__1305000184_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_fn__1305000184_A]()) }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000130__1305000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_new, Get: A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_get}

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000130__1305000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_package_info_A_class, Simple: "iter__1305000130__1305000134", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000130__1305000134_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000130__1305000134_A]()) }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_new, Get: A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_get}

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_class, Simple: "fn__1305000135", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A]()) }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_new, Get: A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_get}

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135$fn__1305000136", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_class, Simple: "fn__1305000136", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A]()) }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000152__1305000156_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_new, Get: A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_get}

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000152__1305000156", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_package_info_A_class, Simple: "iter__1305000152__1305000156", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000152__1305000156_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000152__1305000156_A]()) }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_new, Get: A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_get}

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_class, Simple: "fn__1305000157", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A]()) }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_new, Get: A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_get}

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157$fn__1305000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_class, Simple: "fn__1305000158", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A]()) }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000168__1305000172_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_new, Get: A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_get}

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000168__1305000172", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_package_info_A_class, Simple: "iter__1305000168__1305000172", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000168__1305000172_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000168__1305000172_A]()) }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_new, Get: A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_get}

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_class, Simple: "fn__1305000173", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A]()) }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_new, Get: A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_get}

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173$fn__1305000174", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_class, Simple: "fn__1305000174", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A]()) }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000189__1305000193_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_new, Get: A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_get}

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000189__1305000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_package_info_A_class, Simple: "iter__1305000189__1305000193", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000189__1305000193_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000189__1305000193_A]()) }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_new, Get: A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_get}

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_class, Simple: "fn__1305000194", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A]()) }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_New_O_O_I_O_O(args[0], args[1], args[2].(int32), args[3], args[4])}; return nil }

func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_fn_class)}; return nil }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_invoke, New: A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_new, Get: A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_get}

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194$fn__1305000195", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_class, Simple: "fn__1305000195", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_class.Info(); i.IsInstance = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_InstanceOf; i.Init = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_Init; i.Table = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_members; jrt.RegisterGoType(A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_class, reflect.TypeFor[A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A]()) }

func A_arbace_box_plan_plan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_plan_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_plan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_plan_A_New()}; return nil }

func A_arbace_box_plan_plan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_plan_A_fn_class)}; return nil }

var A_arbace_box_plan_plan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_plan_A_invoke, New: A_arbace_box_plan_plan_A_new, Get: A_arbace_box_plan_plan_A_get}

var A_arbace_box_plan_plan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$plan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "plan", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_plan_A_class.Info(); i.IsInstance = A_arbace_box_plan_plan_A_InstanceOf; i.Init = A_arbace_box_plan_plan_A_Init; i.Table = A_arbace_box_plan_plan_A_members; jrt.RegisterGoType(A_arbace_box_plan_plan_A_class, reflect.TypeFor[A_arbace_box_plan_plan_A]()) }

func A_arbace_box_plan_plan_fn__1305000260_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_plan_fn__1305000260_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_plan_fn__1305000260_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_plan_fn__1305000260_A_New()}; return nil }

func A_arbace_box_plan_plan_fn__1305000260_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_plan_fn__1305000260_A_fn_class)}; return nil }

var A_arbace_box_plan_plan_fn__1305000260_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_plan_fn__1305000260_A_invoke, New: A_arbace_box_plan_plan_fn__1305000260_A_new, Get: A_arbace_box_plan_plan_fn__1305000260_A_get}

var A_arbace_box_plan_plan_fn__1305000260_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$plan$fn__1305000260", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_plan_A_class, Simple: "fn__1305000260", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_fn__1305000260_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_plan_fn__1305000260_A_class.Info(); i.IsInstance = A_arbace_box_plan_plan_fn__1305000260_A_InstanceOf; i.Init = A_arbace_box_plan_plan_fn__1305000260_A_Init; i.Table = A_arbace_box_plan_plan_fn__1305000260_A_members; jrt.RegisterGoType(A_arbace_box_plan_plan_fn__1305000260_A_class, reflect.TypeFor[A_arbace_box_plan_plan_fn__1305000260_A]()) }

func A_arbace_box_plan_plan_visit__1305000250_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_plan_visit__1305000250_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_plan_visit__1305000250_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_plan_visit__1305000250_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_plan_visit__1305000250_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_plan_visit__1305000250_A_fn_class)}; return nil }

var A_arbace_box_plan_plan_visit__1305000250_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_plan_visit__1305000250_A_invoke, New: A_arbace_box_plan_plan_visit__1305000250_A_new, Get: A_arbace_box_plan_plan_visit__1305000250_A_get}

var A_arbace_box_plan_plan_visit__1305000250_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$plan$visit__1305000250", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_plan_plan_A_class, Simple: "visit__1305000250", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_visit__1305000250_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_plan_visit__1305000250_A_class.Info(); i.IsInstance = A_arbace_box_plan_plan_visit__1305000250_A_InstanceOf; i.Init = A_arbace_box_plan_plan_visit__1305000250_A_Init; i.Table = A_arbace_box_plan_plan_visit__1305000250_A_members; jrt.RegisterGoType(A_arbace_box_plan_plan_visit__1305000250_A_class, reflect.TypeFor[A_arbace_box_plan_plan_visit__1305000250_A]()) }

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_fn_class)}; return nil }

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_invoke, New: A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_new, Get: A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_get}

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$plan$visit__1305000250$fn__1305000251", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_plan_visit__1305000250_A_class, Simple: "fn__1305000251", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_class.Info(); i.IsInstance = A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_InstanceOf; i.Init = A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_Init; i.Table = A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_members; jrt.RegisterGoType(A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_class, reflect.TypeFor[A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A]()) }

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_New()}; return nil }

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_fn_class)}; return nil }

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_invoke, New: A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_new, Get: A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_get}

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$plan$visit__1305000250$fn__1305000254", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_plan_visit__1305000250_A_class, Simple: "fn__1305000254", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_class.Info(); i.IsInstance = A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_InstanceOf; i.Init = A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_Init; i.Table = A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_members; jrt.RegisterGoType(A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_class, reflect.TypeFor[A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A]()) }

func A_arbace_box_plan_src_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_src_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_A_New()}; return nil }

func A_arbace_box_plan_src_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_A_invoke, New: A_arbace_box_plan_src_tree_A_new, Get: A_arbace_box_plan_src_tree_A_get}

var A_arbace_box_plan_src_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "src_tree", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_A_Init; i.Table = A_arbace_box_plan_src_tree_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_A]()) }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_invoke, New: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_new, Get: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_get}

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree$iter__1305000227__1305000231", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_src_tree_A_class, Simple: "iter__1305000227__1305000231", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_Init; i.Table = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A]()) }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_invoke, New: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_new, Get: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_get}

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_class, Simple: "fn__1305000232", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_Init; i.Table = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A]()) }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_invoke, New: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_new, Get: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_get}

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232$fn__1305000233", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_class, Simple: "fn__1305000233", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_Init; i.Table = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A]()) }

func A_arbace_box_plan_src_tree_sub__1305000203_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_sub__1305000203_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_sub__1305000203_A_New_O(args[0])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_sub__1305000203_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_sub__1305000203_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_sub__1305000203_A_invoke, New: A_arbace_box_plan_src_tree_sub__1305000203_A_new, Get: A_arbace_box_plan_src_tree_sub__1305000203_A_get}

var A_arbace_box_plan_src_tree_sub__1305000203_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree$sub__1305000203", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_plan_src_tree_A_class, Simple: "sub__1305000203", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_sub__1305000203_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_sub__1305000203_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_sub__1305000203_A_Init; i.Table = A_arbace_box_plan_src_tree_sub__1305000203_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_sub__1305000203_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_sub__1305000203_A]()) }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_invoke, New: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_new, Get: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_get}

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_src_tree_sub__1305000203_A_class, Simple: "iter__1305000204__1305000208", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_Init; i.Table = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A]()) }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_invoke, New: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_new, Get: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_get}

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_class, Simple: "fn__1305000209", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_Init; i.Table = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A]()) }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_fn_class)}; return nil }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_invoke, New: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_new, Get: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_get}

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209$fn__1305000210", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_class, Simple: "fn__1305000210", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_class.Info(); i.IsInstance = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_InstanceOf; i.Init = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_Init; i.Table = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_members; jrt.RegisterGoType(A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_class, reflect.TypeFor[A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A]()) }

func A_arbace_box_plan_tag_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_tag_fn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_tag_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_tag_fn_A_New()}; return nil }

func A_arbace_box_plan_tag_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_tag_fn_A_fn_class)}; return nil }

var A_arbace_box_plan_tag_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_tag_fn_A_invoke, New: A_arbace_box_plan_tag_fn_A_new, Get: A_arbace_box_plan_tag_fn_A_get}

var A_arbace_box_plan_tag_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$tag_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "tag_fn", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_tag_fn_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_tag_fn_A_class.Info(); i.IsInstance = A_arbace_box_plan_tag_fn_A_InstanceOf; i.Init = A_arbace_box_plan_tag_fn_A_Init; i.Table = A_arbace_box_plan_tag_fn_A_members; jrt.RegisterGoType(A_arbace_box_plan_tag_fn_A_class, reflect.TypeFor[A_arbace_box_plan_tag_fn_A]()) }

func A_arbace_box_plan_tag_fn_fn__1305000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_tag_fn_fn__1305000028_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_tag_fn_fn__1305000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_tag_fn_fn__1305000028_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_plan_tag_fn_fn__1305000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_tag_fn_fn__1305000028_A_fn_class)}; return nil }

var A_arbace_box_plan_tag_fn_fn__1305000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_tag_fn_fn__1305000028_A_invoke, New: A_arbace_box_plan_tag_fn_fn__1305000028_A_new, Get: A_arbace_box_plan_tag_fn_fn__1305000028_A_get}

var A_arbace_box_plan_tag_fn_fn__1305000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$tag_fn$fn__1305000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_tag_fn_A_class, Simple: "fn__1305000028", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_tag_fn_fn__1305000028_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_tag_fn_fn__1305000028_A_class.Info(); i.IsInstance = A_arbace_box_plan_tag_fn_fn__1305000028_A_InstanceOf; i.Init = A_arbace_box_plan_tag_fn_fn__1305000028_A_Init; i.Table = A_arbace_box_plan_tag_fn_fn__1305000028_A_members; jrt.RegisterGoType(A_arbace_box_plan_tag_fn_fn__1305000028_A_class, reflect.TypeFor[A_arbace_box_plan_tag_fn_fn__1305000028_A]()) }

func A_arbace_box_plan_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_plan_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_plan_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan_text_A_New()}; return nil }

func A_arbace_box_plan_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_plan_text_A_fn_class)}; return nil }

var A_arbace_box_plan_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_plan_text_A_invoke, New: A_arbace_box_plan_text_A_new, Get: A_arbace_box_plan_text_A_get}

var A_arbace_box_plan_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan$text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_plan_A_class, Simple: "text", Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan_text_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan_text_A_class.Info(); i.IsInstance = A_arbace_box_plan_text_A_InstanceOf; i.Init = A_arbace_box_plan_text_A_Init; i.Table = A_arbace_box_plan_text_A_members; jrt.RegisterGoType(A_arbace_box_plan_text_A_class, reflect.TypeFor[A_arbace_box_plan_text_A]()) }

func A_arbace_box_plan__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_plan__init_A_Load__O(); case 1: return A_arbace_box_plan__init_A_Unit0__O(); case 2: return A_arbace_box_plan__init_A_Unit1__O(); case 3: return A_arbace_box_plan__init_A_Unit10__O(); case 4: return A_arbace_box_plan__init_A_Unit11__O(); case 5: return A_arbace_box_plan__init_A_Unit12__O(); case 6: return A_arbace_box_plan__init_A_Unit13__O(); case 7: return A_arbace_box_plan__init_A_Unit14__O(); case 8: return A_arbace_box_plan__init_A_Unit15__O(); case 9: return A_arbace_box_plan__init_A_Unit16__O(); case 10: return A_arbace_box_plan__init_A_Unit17__O(); case 11: return A_arbace_box_plan__init_A_Unit18__O(); case 12: return A_arbace_box_plan__init_A_Unit19__O(); case 13: return A_arbace_box_plan__init_A_Unit2__O(); case 14: return A_arbace_box_plan__init_A_Unit20__O(); case 15: return A_arbace_box_plan__init_A_Unit21__O(); case 16: return A_arbace_box_plan__init_A_Unit22__O(); case 17: return A_arbace_box_plan__init_A_Unit23__O(); case 18: return A_arbace_box_plan__init_A_Unit24__O(); case 19: return A_arbace_box_plan__init_A_Unit3__O(); case 20: return A_arbace_box_plan__init_A_Unit4__O(); case 21: return A_arbace_box_plan__init_A_Unit5__O(); case 22: return A_arbace_box_plan__init_A_Unit6__O(); case 23: return A_arbace_box_plan__init_A_Unit7__O(); case 24: return A_arbace_box_plan__init_A_Unit8__O(); case 25: return A_arbace_box_plan__init_A_Unit9__O()}; return nil }

func A_arbace_box_plan__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_plan__init_A_New()}; return nil }

var A_arbace_box_plan__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_plan__init_A_invoke, New: A_arbace_box_plan__init_A_new}

var A_arbace_box_plan__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.plan__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_plan.A_arbace_box_plan__init_A", Source: "plan.ae"})

func init() { i := A_arbace_box_plan__init_A_class.Info(); i.IsInstance = A_arbace_box_plan__init_A_InstanceOf; i.Init = A_arbace_box_plan__init_A_Init; i.Table = A_arbace_box_plan__init_A_members; jrt.RegisterGoType(A_arbace_box_plan__init_A_class, reflect.TypeFor[A_arbace_box_plan__init_A]()) }
