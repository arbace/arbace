//line aot_arbace_box_plan.ae:1
package aot_arbace_box_plan

import (
	"arbace/aot_arbace_box"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_New() *A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_plan_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_box_plan_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_box_plan_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_1, A_arbace_box_plan_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :4:1
func A_arbace_box_plan_eval1305000008_fn__1305000009_A_New() *A_arbace_box_plan_eval1305000008_fn__1305000009_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval1305000008_fn__1305000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_plan_eval1305000008_fn__1305000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_plan_eval1305000008_fn__1305000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_box_plan_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_box_plan_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_plan_A_const_8.GetRawRoot__O(), A_arbace_box_plan_A_const_9) }






























func A_arbace_box_plan_fail_A_New() *A_arbace_box_plan_fail_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_fail_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_box_plan_fail_A) Ctor() {}
//line :35:1
func (t *A_arbace_box_plan_fail_A) Invoke_O_O_O__O(self, msg__0, data__1 any) any { var tmp1 any; var root_20 any = A_arbace_box_plan_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_22 lang.IFn; if
											linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = msg__0; var arg_24 any; var root_25 any = A_arbace_box_plan_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = data__1; var arg_29 any = A_arbace_box_plan_A_const_12; var arg_30 any = jrt.Boolean_TRUE.Ref(); if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O_O__O(arg_28, arg_29, arg_30) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_25, arg_28, arg_29, arg_30) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; /*line :35:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }







func A_arbace_box_plan_entries_A_New() *A_arbace_box_plan_entries_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_entries_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_box_plan_entries_A) Ctor() {}
//line :43:1
func (t *A_arbace_box_plan_entries_A) Invoke_O_O__O(self, h__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_31 any = A_arbace_box_plan_A_const_6.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_33 lang.IFn; if


	linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = A_arbace_box_plan_A_const_13.Get__O(); if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_31, arg_34) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, h__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var m__3 any; var or__1927000174__auto____3 any; var root_35 any = A_arbace_box_plan_A_const_14.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_box.A_arbace_box_tree_A_fn_class); var ifn_37 lang.IFn
		if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = h__0; if linked_36 == nil { or__1927000174__auto____3 = ifn_37.Invoke_O__O(arg_38) } else { or__1927000174__auto____3 = linked_36.(*aot_arbace_box.A_arbace_box_tree_A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(or__1927000174__auto____3) { m__3 = or__1927000174__auto____3 } else { var root_39 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, A_arbace_box_plan_fail_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(); var arg_43 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_16, h__0)); if linked_40 == nil { m__3 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { m__3 = linked_40.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) } }
		var root_44 any = A_arbace_box_plan_A_const_17.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_box_plan_A_const_13.Get__O(); var arg_48 any = A_arbace_box_plan_A_const_11.GetRawRoot__O(); var arg_49 any = h__0; var arg_50 any = m__3; if linked_45 == nil { ifn_46.Invoke_O_O_O_O__O(arg_47, arg_48, arg_49, arg_50) } else { linked_45.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_44, arg_47, arg_48, arg_49, arg_50) }
//line :46:1
		return m__3 } }




func A_arbace_box_plan_dir_at_A_New() *A_arbace_box_plan_dir_at_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_dir_at_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_box_plan_dir_at_A) Ctor() {}
//line :51:1
func (t *A_arbace_box_plan_dir_at_A) Invoke_O_O_O__O(self, h__0, p__1 any) any {


	var root_51 any = A_arbace_box_plan_A_const_18.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var tmp1 any = A_arbace_box_plan_dir_at_fn__1305000014_A_New(); var tmp2 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_box_plan_dir_at_fn__1305000014_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_box_plan_dir_at_fn__1305000014_A_fn_class = fncls__65d; tmp2 = fncls__65d } else { tmp2 = fncls__65 }; arg_54 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_55 any = h__0; var arg_56 any; var root_66 any = A_arbace_box_plan_A_const_22.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_68 lang.IFn



	if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = A_arbace_box_plan_A_const_23.GetRawRoot__O(); var arg_70 any; var root_71 any = A_arbace_box_plan_A_const_24.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = p__1; var arg_75 any = A_arbace_box_plan_A_const_25; if linked_72 == nil { arg_70 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { arg_70 = linked_72.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }; if linked_67 == nil { arg_56 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { arg_56 = linked_67.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }
//line :54:1
	if linked_52 == nil { return ifn_53.Invoke_O_O_O__O(arg_54, arg_55, arg_56) } else { return linked_52.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_51, arg_54, arg_55, arg_56) } }
//line :54:1
func A_arbace_box_plan_dir_at_fn__1305000014_A_New() *A_arbace_box_plan_dir_at_fn__1305000014_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_dir_at_fn__1305000014_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_box_plan_dir_at_fn__1305000014_A) Ctor() {}
//line :54:1
func (t *A_arbace_box_plan_dir_at_fn__1305000014_A) Invoke_O_O_O__O(self, d__1, n__2 any) any { var vec__1305000015__3 any; var tmp1 any; var root_57 any = A_arbace_box_plan_A_const_19.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_box_plan_entries_A_fn_class); var ifn_59 lang.IFn; if
												linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = d__1; if linked_58 == nil { tmp1 = ifn_59.Invoke_O__O(arg_60) } else { tmp1 = linked_58.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(root_57, arg_60) }; vec__1305000015__3 = lang.RT_Get_O_O__O_NoInit(tmp1, n__2); var k__4 any = /*line :54:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1305000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000015__3, lang.RT_IntCast_J__I_NoInit(1), nil); if

	lang.Util_Equiv_O_O__Z_NoInit(k__4, A_arbace_box_plan_A_const_20) { return eh__5 } else { var root_61 any = A_arbace_box_plan_A_const_21.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; if linked_62 == nil { return ifn_63.Invoke_O__O(arg_64) } else { return linked_62.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_61, arg_64) } } }



func A_arbace_box_plan_text_A_New() *A_arbace_box_plan_text_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_text_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_box_plan_text_A) Ctor() {}
//line :60:1
func (t *A_arbace_box_plan_text_A) Invoke_O_O__O(self, p__1305000020__0 any) any { var vec__1305000021__2 any = p__1305000020__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000021__2, lang.RT_IntCast_J__I_NoInit(0), nil); var h__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000021__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 any; var root_76 any = A_arbace_box_plan_A_const_26.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_box.A_arbace_box_get_A_fn_class); var ifn_78 lang.IFn; _ = ___3; if
											linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = h__4; if linked_77 == nil { or__1927000174__auto____5 = ifn_78.Invoke_O__O(arg_79) } else { or__1927000174__auto____5 = linked_77.(*aot_arbace_box.A_arbace_box_get_A).Invoke_O_O__O(root_76, arg_79) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var root_80 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, A_arbace_box_plan_fail_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_107, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__4)).Ref(); var arg_84 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_27, h__4)); if linked_81 == nil { return ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { return linked_81.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) } } }

















func A_arbace_box_plan_tag_fn_A_New() *A_arbace_box_plan_tag_fn_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_tag_fn_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_box_plan_tag_fn_A) Ctor() {}
//line :79:1
func (t *A_arbace_box_plan_tag_fn_A) Invoke_O_O__O(self, p__1305000025__0 any) any { var map__1305000026__2 any = p__1305000025__0; var map__1305000026__3 any; if lang.ISeq_InstanceOf(map__1305000026__2) { var tmp1 any; var root_85 any = A_arbace_box_plan_A_const_28.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = map__1305000026__2; if linked_86 == nil { tmp1 = ifn_87.Invoke_O__O(arg_88) } else { tmp1 = linked_86.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_85, arg_88) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_89 any = A_arbace_box_plan_A_const_29.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = map__1305000026__2; if linked_90 == nil { tmp2 = ifn_91.Invoke_O__O(arg_92) } else { tmp2 = linked_90.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_89, arg_92) }; map__1305000026__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_93 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = map__1305000026__2; if linked_94 == nil { tmp3 = ifn_95.Invoke_O__O(arg_96) } else { tmp3 = linked_94.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_93, arg_96) }; if jrt.J2g_Truth(tmp3) { var root_97 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = map__1305000026__2; if linked_98 == nil { map__1305000026__3 = ifn_99.Invoke_O__O(arg_100) } else { map__1305000026__3 = linked_98.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_97, arg_100) } } else { map__1305000026__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000026__3 = map__1305000026__2 }; var goos__4 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_32); var goarch__5 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_33); var tool_tags__6 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_34); var release_tags__7 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_35); var tags__8 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_36); var on__9 any; var root_101 any = A_arbace_box_plan_A_const_37.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_103 lang.IFn; if


	linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = lang.IFn_Cast(A_arbace_box_plan_A_const_38.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(goos__4, goarch__5, Lit_103), tool_tags__6, release_tags__7, tags__8); if linked_102 == nil { on__9 = ifn_103.Invoke_O__O(arg_104) } else { on__9 = linked_102.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_101, arg_104) }; var tmp4 any =
	A_arbace_box_plan_tag_fn_fn__1305000028_A_New_O_O(goos__4, on__9); var tmp5 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_box_plan_tag_fn_fn__1305000028_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_box_plan_tag_fn_fn__1305000028_A_fn_class = fncls__122d; tmp5 = fncls__122d } else { tmp5 = fncls__122 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) }
//line :83:1
func A_arbace_box_plan_tag_fn_fn__1305000028_A_New_O_O(p0, p1 any) *A_arbace_box_plan_tag_fn_fn__1305000028_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_tag_fn_fn__1305000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :83:1
func (t *A_arbace_box_plan_tag_fn_fn__1305000028_A) Ctor_O_O(c__goos, c__on any) { t.F_goos = c__goos; t.F_on = c__on }
//line :83:1
func (t *A_arbace_box_plan_tag_fn_fn__1305000028_A) Invoke_O_O__O(self, t__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_105) { var root_112 any = A_arbace_box_plan_A_const_39.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_box_plan_A_const_40.GetRawRoot__O(); var arg_116 any = t.F_goos; if linked_113 == nil { return ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { return linked_113.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_112, arg_115, arg_116) } } else { if lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_106) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_box_plan_A_const_41 != nil {

		var root_117 any = A_arbace_box_plan_A_const_39.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = t.F_on; var arg_121 any = t__1; if linked_118 == nil { return ifn_119.Invoke_O_O__O(arg_120, arg_121) } else { return linked_118.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_117, arg_120, arg_121) } } else {
//line :84:1
			return nil
		}
	}
	} }
func A_arbace_box_plan_name_ok_QMARK__A_New() *A_arbace_box_plan_name_ok_QMARK__A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_name_ok_QMARK__A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_box_plan_name_ok_QMARK__A) Ctor() {}
//line :88:1
func (t *A_arbace_box_plan_name_ok_QMARK__A) Invoke_O_O_O__O(self, match_QMARK___0, n__1 any) any { var n__3 any; var root_123 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_125 lang.IFn; if


	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_127 any = A_arbace_box_plan_A_const_24.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = n__1; var arg_131 any = A_arbace_box_plan_A_const_42; var arg_132 any = A_arbace_box_plan_A_const_43; if linked_128 == nil { arg_126 = ifn_129.Invoke_O_O_O__O(arg_130, arg_131, arg_132) } else { arg_126 = linked_128.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_127, arg_130, arg_131, arg_132) }; if linked_124 == nil { n__3 = ifn_125.Invoke_O__O(arg_126) } else { n__3 = linked_124.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_123, arg_126) }; var i__4 any = /*line :88:1*/lang.Reflector_InvokeInstanceMethod_O_String_O1__O(n__3, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_11)); var tmp1 bool; var na_133 any = i__4; if




	jrt.Long_InstanceOf(na_133) { var n0_134 int64 = jrt.NN(jrt.Long_Cast(na_133)).LongValue__J(); tmp1 = n0_134 < 0 } else { if jrt.Double_InstanceOf(na_133) { var n0_134_2 float64 = jrt.NN(jrt.Double_Cast(na_133)).DoubleValue__D(); tmp1 = n0_134_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_133) } }; if tmp1 { return jrt.Boolean_TRUE.Ref() } else { var l__5 any; var root_135 any = A_arbace_box_plan_A_const_44.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_137 lang.IFn

		if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any; var root_139 any = A_arbace_box_plan_A_const_24.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any; var root_145 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = n__3; var arg_149 any = i__4; if linked_146 == nil { arg_142 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { arg_142 = linked_146.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }; var arg_143 any = A_arbace_box_plan_A_const_46; var arg_144 any = A_arbace_box_plan_A_const_47; if linked_140 == nil { arg_138 = ifn_141.Invoke_O_O_O__O(arg_142, arg_143, arg_144) } else { arg_138 = linked_140.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_139, arg_142, arg_143, arg_144) }; if linked_136 == nil { l__5 = ifn_137.Invoke_O__O(arg_138) } else { l__5 = linked_136.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_135, arg_138) }
//line :93:1
		var l__6 any; var tmp2 any; var root_150 any = A_arbace_box_plan_A_const_48.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_152 lang.IFn


		if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = l__5; if linked_151 == nil { tmp2 = ifn_152.Invoke_O__O(arg_153) } else { tmp2 = linked_151.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_150, arg_153) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_62, tmp2) { var root_154 any = A_arbace_box_plan_A_const_49.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = l__5; if linked_155 == nil { l__6 = ifn_156.Invoke_O__O(arg_157) } else { l__6 = linked_155.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_154, arg_157) } } else { l__6 = l__5 }
//line :93:1
		var c__7 int32 = lang.RT_Count_O__I_NoInit(l__6); var tmp3 any; var and__1927000168__auto____8 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(c__7), 2)




		if and__1927000168__auto____8 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 2)).Ref())); if jrt.J2g_Truth(and__1927000168__auto____9) { tmp3 = lang.IFn_Cast(A_arbace_box_plan_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp3) { var and__1927000168__auto____8_2 any = lang.IFn_Cast(match_QMARK___0).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 2)).Ref()))
			if jrt.J2g_Truth(and__1927000168__auto____8_2) { return lang.IFn_Cast(match_QMARK___0).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } else { return and__1927000168__auto____8_2 } } else {
//line :98:1
				var tmp4 any; var and__1927000168__auto____8_3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(c__7), 1)

				if and__1927000168__auto____8_3 { var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())); if jrt.J2g_Truth(or__1927000174__auto____9) { tmp4 = or__1927000174__auto____9 } else { tmp4 = lang.IFn_Cast(A_arbace_box_plan_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() }
//line :98:1
				if jrt.J2g_Truth(tmp4) {


					return lang.IFn_Cast(match_QMARK___0).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } else {
//line :98:1
						if A_arbace_box_plan_A_const_41 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } }





func A_arbace_box_plan_expr_tokens_A_New() *A_arbace_box_plan_expr_tokens_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_expr_tokens_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_box_plan_expr_tokens_A) Ctor() {}
//line :104:1
func (t *A_arbace_box_plan_expr_tokens_A) Invoke_O_O__O(self, s__0 any) any {
	var root_158 any = A_arbace_box_plan_A_const_52.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = A_arbace_box_plan_A_const_53; var arg_162 any = s__0; if linked_159 == nil { return ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { return linked_159.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_158, arg_161, arg_162)
	} }
func A_arbace_box_plan_eval_expr_A_New() *A_arbace_box_plan_eval_expr_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_box_plan_eval_expr_A) Ctor() {}
//line :107:1
func (t *A_arbace_box_plan_eval_expr_A) Invoke_O_O_O__O(self, match_QMARK___0, s__1 any) any { var toks__3 any; var root_163 any = A_arbace_box_plan_A_const_54.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_165 lang.IFn; if


	linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var root_167 any = A_arbace_box_plan_A_const_55.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, A_arbace_box_plan_expr_tokens_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = s__1; if linked_168 == nil { arg_166 = ifn_169.Invoke_O__O(arg_170) } else { arg_166 = linked_168.(*A_arbace_box_plan_expr_tokens_A).Invoke_O_O__O(root_167, arg_170) }; if linked_164 == nil { toks__3 = ifn_165.Invoke_O__O(arg_166) } else { toks__3 = linked_164.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_163, arg_166) }; var peek_t__4 any; var tmp1 any = /*line :107:1*/A_arbace_box_plan_eval_expr_peek_t__1305000033_A_New_O(toks__3); var tmp2 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_box_plan_eval_expr_peek_t__1305000033_A_fn_class; if


	fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_box_plan_eval_expr_peek_t__1305000033_A_fn_class = fncls__179d; tmp2 = fncls__179d } else { tmp2 = fncls__179 }; peek_t__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var next_t__5 any; var tmp3 any = /*line :107:1*/A_arbace_box_plan_eval_expr_next_t__1305000035_A_New_O(toks__3); var tmp4 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_box_plan_eval_expr_next_t__1305000035_A_fn_class; if


	fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_box_plan_eval_expr_next_t__1305000035_A_fn_class = fncls__193d; tmp4 = fncls__193d } else { tmp4 = fncls__193 }; next_t__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var body_or_e__6 /*line :107:1*/*A_arbace_box_plan_eval_expr_or_e__1305000037_A = A_arbace_box_plan_eval_expr_or_e__1305000037_A_New_O_O_O(next_t__5, peek_t__4, nil); var body_and_e__7 *A_arbace_box_plan_eval_expr_and_e__1305000039_A = A_arbace_box_plan_eval_expr_and_e__1305000039_A_New_O_O_O(next_t__5, peek_t__4, nil); var body_not_e__8 *A_arbace_box_plan_eval_expr_not_e__1305000041_A = A_arbace_box_plan_eval_expr_not_e__1305000041_A_New_O_O_O_O(nil, next_t__5, s__1, match_QMARK___0); var or_e__6 any; var tmp5 *jrt.Class; var fncls__213 *jrt.Class = A_arbace_box_plan_eval_expr_or_e__1305000037_A_fn_class; if fncls__213 == nil { var fncls__213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_box_plan_eval_expr_or_e__1305000037_A_fn_class = fncls__213d; tmp5 = fncls__213d } else { tmp5 = fncls__213 }; or_e__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_or_e__6), tmp5, nil); var and_e__7 any; var tmp6 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_box_plan_eval_expr_and_e__1305000039_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_box_plan_eval_expr_and_e__1305000039_A_fn_class = fncls__214d; tmp6 = fncls__214d } else { tmp6 = fncls__214 }; and_e__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_and_e__7), tmp6, nil); var not_e__8 any; var tmp7 *jrt.Class; var fncls__215 *jrt.Class = A_arbace_box_plan_eval_expr_not_e__1305000041_A_fn_class; if fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_box_plan_eval_expr_not_e__1305000041_A_fn_class = fncls__215d; tmp7 = fncls__215d } else { tmp7 = fncls__215 }; not_e__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_not_e__8), tmp7, nil); body_or_e__6.F_and_e = and_e__7; body_and_e__7.F_not_e = not_e__8; body_not_e__8.F_or_e = or_e__6; var v__9 any = lang.IFn_Cast(or_e__6).Invoke__O(); var tmp8 any; var root_216 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_218 lang.IFn; if













	linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any; var root_220 any = A_arbace_box_plan_A_const_6.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = toks__3; if linked_221 == nil { arg_219 = ifn_222.Invoke_O__O(arg_223) } else { arg_219 = linked_221.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_220, arg_223) }; if linked_217 == nil { tmp8 = ifn_218.Invoke_O__O(arg_219) } else { tmp8 = linked_217.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_216, arg_219) }; if jrt.J2g_Truth(tmp8) { var root_224 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_box_plan_fail_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, s__1, nil)).Ref(); var arg_228 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_225 == nil { ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { linked_225.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_224, arg_227, arg_228) } }; return v__9 }
//line :110:1
func A_arbace_box_plan_eval_expr_next_t__1305000035_A_New_O(p0 any) *A_arbace_box_plan_eval_expr_next_t__1305000035_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_next_t__1305000035_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_next_t__1305000035_A) Ctor_O(c__toks any) { t.F_toks = c__toks }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_next_t__1305000035_A) Invoke_O__O(self any) any { var t__1 any; var root_180 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_182 lang.IFn; if

	linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any; var root_184 any = A_arbace_box_plan_A_const_6.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = t.F_toks; if linked_185 == nil { arg_183 = ifn_186.Invoke_O__O(arg_187) } else { arg_183 = linked_185.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_184, arg_187) }; if linked_181 == nil { t__1 = ifn_182.Invoke_O__O(arg_183) } else { t__1 = linked_181.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_180, arg_183) }; var root_188 any = A_arbace_box_plan_A_const_17.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = t.F_toks; var arg_192 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); if linked_189 == nil { ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { linked_189.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; return t__1 }
//line :110:1
func A_arbace_box_plan_eval_expr_peek_t__1305000033_A_New_O(p0 any) *A_arbace_box_plan_eval_expr_peek_t__1305000033_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_peek_t__1305000033_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_peek_t__1305000033_A) Ctor_O(c__toks any) { t.F_toks = c__toks }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_peek_t__1305000033_A) Invoke_O__O(self any) any {
	var root_171 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var root_175 any = A_arbace_box_plan_A_const_6.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = t.F_toks; if linked_176 == nil { arg_174 = ifn_177.Invoke_O__O(arg_178) } else { arg_174 = linked_176.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_175, arg_178) }; if linked_172 == nil { return ifn_173.Invoke_O__O(arg_174) } else { return linked_172.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_171, arg_174)
	} }
func A_arbace_box_plan_eval_expr_and_e__1305000039_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_eval_expr_and_e__1305000039_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_and_e__1305000039_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_and_e__1305000039_A) Ctor_O_O_O(c__next_t, c__peek_t, c__not_e any) { t.F_next_t = c__next_t; t.F_peek_t = c__peek_t; t.F_not_e = c__not_e }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_and_e__1305000039_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_not_e).Invoke__O(); L1: for {
											if lang.Util_Equiv_O_O__Z_NoInit(Lit_20, lang.IFn_Cast(t.F_peek_t).Invoke__O()) { lang.IFn_Cast(t.F_next_t).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_not_e).Invoke__O(); var tmp1 any; var and__1927000168__auto____3 any = v__1; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = w__2 } else { tmp1 = and__1927000168__auto____3 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :113:1*/panic("j2g: unreachable") }
//line :113:1
func A_arbace_box_plan_eval_expr_not_e__1305000041_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_eval_expr_not_e__1305000041_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_not_e__1305000041_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_not_e__1305000041_A) Ctor_O_O_O_O(c__or_e, c__next_t, c__s, c__match_QMARK_ any) { t.F_or_e = c__or_e; t.F_next_t = c__next_t; t.F_s = c__s; t.F_match_QMARK_ = c__match_QMARK_ }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_not_e__1305000041_A) Invoke_O__O(self any) any { var t__1 any = lang.IFn_Cast(t.F_next_t).Invoke__O(); if


	lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_21) { var root_194 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = lang.IFn_Cast(self).Invoke__O(); if linked_195 == nil { return ifn_196.Invoke_O__O(arg_197) } else { return linked_195.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_194, arg_197) } } else { if lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_22) { var v__2 any = lang.IFn_Cast(t.F_or_e).Invoke__O()
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_23, lang.IFn_Cast(t.F_next_t).Invoke__O()) { } else { var root_208 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_box_plan_fail_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil, Lit_25), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s, nil)).Ref(); var arg_212 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_209 == nil { ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { linked_209.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) } }
//line :116:1
		return v__2 } else { var tmp1 any
			var and__1927000168__auto____2 any = t__1
			if jrt.J2g_Truth(and__1927000168__auto____2) { var root_198 any = A_arbace_box_plan_A_const_58.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = A_arbace_box_plan_A_const_59; var arg_202 any = t__1; if linked_199 == nil { tmp1 = ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { tmp1 = linked_199.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_198, arg_201, arg_202) } } else { tmp1 = and__1927000168__auto____2 }
//line :116:1
			if jrt.J2g_Truth(tmp1) {

				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_match_QMARK_).Invoke_O__O(t__1))).Ref() } else {
//line :116:1
					if A_arbace_box_plan_A_const_41 != nil {


						var root_203 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, A_arbace_box_plan_fail_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s, nil)).Ref(); var arg_207 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_204 == nil { return ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { return linked_204.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } } else {
//line :116:1
							return nil } } } } }
//line :113:1
func A_arbace_box_plan_eval_expr_or_e__1305000037_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_eval_expr_or_e__1305000037_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_or_e__1305000037_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_or_e__1305000037_A) Ctor_O_O_O(c__next_t, c__peek_t, c__and_e any) { t.F_next_t = c__next_t; t.F_peek_t = c__peek_t; t.F_and_e = c__and_e }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_or_e__1305000037_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_and_e).Invoke__O(); L1: for { if lang.Util_Equiv_O_O__Z_NoInit(Lit_27, lang.IFn_Cast(t.F_peek_t).Invoke__O()) { lang.IFn_Cast(t.F_next_t).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_and_e).Invoke__O(); var tmp1 any; var or__1927000174__auto____3 any = v__1; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = w__2 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; panic("j2g: unreachable") }










func A_arbace_box_plan_header_build_A_New() *A_arbace_box_plan_header_build_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_header_build_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_box_plan_header_build_A) Ctor() {}
//line :124:1
func (t *A_arbace_box_plan_header_build_A) Invoke_O_O__O(self, s__0 any) any { { var G__1305000047__2_ any; var root_229 any = A_arbace_box_plan_A_const_60.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_231 lang.IFn



	if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = s__0; if linked_230 == nil { G__1305000047__2_ = ifn_231.Invoke_O__O(arg_232) } else { G__1305000047__2_ = linked_230.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_229, arg_232) }
//line :124:1
	var vec__1305000048__3 any = G__1305000047__2_; var seq__1305000049__4 any; var root_233 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_235 lang.IFn



	if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = vec__1305000048__3; if linked_234 == nil { seq__1305000049__4 = ifn_235.Invoke_O__O(arg_236) } else { seq__1305000049__4 = linked_234.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_233, arg_236) }
//line :124:1
	var first__1305000050__5 any; var root_237 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_239 lang.IFn



	if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = seq__1305000049__4; if linked_238 == nil { first__1305000050__5 = ifn_239.Invoke_O__O(arg_240) } else { first__1305000050__5 = linked_238.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_237, arg_240) }
//line :124:1
	var seq__1305000049__6 any; var root_241 any = A_arbace_box_plan_A_const_28.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_243 lang.IFn



	if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = seq__1305000049__4; if linked_242 == nil { seq__1305000049__6 = ifn_243.Invoke_O__O(arg_244) } else { seq__1305000049__6 = linked_242.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_241, arg_244) }
//line :124:1
	var l__7 any = first__1305000050__5; var ls__8 any = seq__1305000049__6; var in_star__9 any = jrt.Boolean_FALSE.Ref(); var G__1305000047__10_ any = G__1305000047__2_; var in_star__11 any = in_star__9; _ = l__7; _ = ls__8; L1: for { var vec__1305000051__12 any = G__1305000047__10_; var seq__1305000052__13 any; var root_245 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_247 lang.IFn



		if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = vec__1305000051__12; if linked_246 == nil { seq__1305000052__13 = ifn_247.Invoke_O__O(arg_248) } else { seq__1305000052__13 = linked_246.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_245, arg_248) }
//line :124:1
		var first__1305000053__14 any; var root_249 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_251 lang.IFn



		if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = seq__1305000052__13; if linked_250 == nil { first__1305000053__14 = ifn_251.Invoke_O__O(arg_252) } else { first__1305000053__14 = linked_250.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_249, arg_252) }
//line :124:1
		var seq__1305000052__15 any; var root_253 any = A_arbace_box_plan_A_const_28.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_255 lang.IFn



		if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = seq__1305000052__13; if linked_254 == nil { seq__1305000052__15 = ifn_255.Invoke_O__O(arg_256) } else { seq__1305000052__15 = linked_254.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_253, arg_256) }
//line :124:1
		var l__16 any = first__1305000053__14
		var ls__17 any = seq__1305000052__15
		var in_star__18 any = in_star__11


		if jrt.J2g_Truth(l__16) { var t__19 any; var root_257 any = A_arbace_box_plan_A_const_61.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_259 lang.IFn
			if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = l__16; if linked_258 == nil { t__19 = ifn_259.Invoke_O__O(arg_260) } else { t__19 = linked_258.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_257, arg_260) }
			if jrt.J2g_Truth(in_star__18) {
				var tmp1 any; var root_290 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var root_294 any = A_arbace_box_plan_A_const_67.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = t__19; var arg_298 any = Lit_47; if linked_295 == nil { arg_293 = ifn_296.Invoke_O_O__O(arg_297, arg_298) } else { arg_293 = linked_295.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_294, arg_297, arg_298) }; if linked_291 == nil { tmp1 = ifn_292.Invoke_O__O(arg_293) } else { tmp1 = linked_291.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_290, arg_293) }; G__1305000047__10_, in_star__11 = ls__17, tmp1; continue L1 } else {
//line :131:1
					var tmp2 any; var root_261 any = A_arbace_box_plan_A_const_62.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_263 lang.IFn

					if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = t__19; if linked_262 == nil { tmp2 = ifn_263.Invoke_O__O(arg_264) } else { tmp2 = linked_262.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_261, arg_264) }
//line :131:1
					if jrt.J2g_Truth(tmp2) {

						G__1305000047__10_, in_star__11 = ls__17, jrt.Boolean_FALSE.Ref(); continue L1 } else {
//line :131:1
							var tmp3 any; var root_265 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_267 lang.IFn


							if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t__19; var arg_269 any = Lit_51; if linked_266 == nil { tmp3 = ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { tmp3 = linked_266.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_265, arg_268, arg_269) }
//line :131:1
							if jrt.J2g_Truth(tmp3) {


								var tmp4 any; var root_270 any = A_arbace_box_plan_A_const_64.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = A_arbace_box_plan_A_const_65; var arg_274 any = t__19; if linked_271 == nil { tmp4 = ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { tmp4 = linked_271.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) }; if jrt.J2g_Truth(tmp4) {
									var root_275 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = t__19; var arg_279 any = A_arbace_box_plan_A_const_66; if linked_276 == nil { return ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { return linked_276.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) } } else {
										G__1305000047__10_, in_star__11 = ls__17, jrt.Boolean_FALSE.Ref(); continue L1 } } else {
//line :131:1
											var tmp5 any; var root_280 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_282 lang.IFn





											if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = t__19; var arg_284 any = Lit_52; if linked_281 == nil { tmp5 = ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { tmp5 = linked_281.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }
//line :131:1
											if jrt.J2g_Truth(tmp5) {





												G__1305000047__10_, in_star__11 = ls__17, jrt.Boolean_FALSE.Ref(); continue L1 } else {
//line :131:1
													var tmp6 any; var root_285 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_287 lang.IFn






													if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = t__19; var arg_289 any = Lit_53; if linked_286 == nil { tmp6 = ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { tmp6 = linked_286.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_285, arg_288, arg_289) }
//line :131:1
													if jrt.J2g_Truth(tmp6) {






														var tmp7 any; var root_299 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any; var root_303 any = A_arbace_box_plan_A_const_67.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var root_308 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = t__19; var arg_312 any = A_arbace_box_plan_A_const_43; if linked_309 == nil { arg_306 = ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { arg_306 = linked_309.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) }; var arg_307 any = Lit_47; if linked_304 == nil { arg_302 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { arg_302 = linked_304.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_303, arg_306, arg_307) }; if linked_300 == nil { tmp7 = ifn_301.Invoke_O__O(arg_302) } else { tmp7 = linked_300.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_299, arg_302) }; G__1305000047__10_, in_star__11 = ls__17, tmp7; continue L1 } else {
//line :131:1
															if A_arbace_box_plan_A_const_41 != nil { return nil } else { return nil } } } } } } } else {
//line :129:1
																return nil } } }; /*line :124:1*/panic("j2g: unreachable") }



















func A_arbace_box_plan_go_tokens_A_New() *A_arbace_box_plan_go_tokens_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_box_plan_go_tokens_A) Ctor() {}
//line :144:1
func (t *A_arbace_box_plan_go_tokens_A) Invoke_O_O__O(self, s__0 any) any { var n__2 int32 = lang.RT_Count_O__I_NoInit(s__0); var body_step__3 *A_arbace_box_plan_go_tokens_step__1305000055_A = A_arbace_box_plan_go_tokens_step__1305000055_A_New_I_O(n__2, s__0); var step__3 any; var tmp1 *jrt.Class; var fncls__468 *jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_A_fn_class; if fncls__468 == nil { var fncls__468d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_box_plan_go_tokens_step__1305000055_A_fn_class = fncls__468d; tmp1 = fncls__468d } else { tmp1 = fncls__468 }; step__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_step__3), tmp1, nil); return /*line :180:1*/ lang.IFn_Cast(step__3).Invoke_O_O__O(A_arbace_box_plan_A_const_82, nil) }
//line :149:1
func A_arbace_box_plan_go_tokens_step__1305000055_A_New_I_O(p0 int32, p1 any) *A_arbace_box_plan_go_tokens_step__1305000055_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_A{}; t.Ctor_I_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_A) Ctor_I_O(c__n int32, c__s any) { t.F_n = c__n; t.F_s = c__s }
//line :149:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_A) Invoke_O_O_O__O(self, i__1, last__2 any) any { var tmp1 any = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_New_O_I_O_O_O(i__1, t.F_n, self, t.F_s, last__2); var tmp2 *jrt.Class; var fncls__467 *jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_fn_class; if
													fncls__467 == nil { var fncls__467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_fn_class = fncls__467d; tmp2 = fncls__467d } else { tmp2 = fncls__467 }; return /*line :149:1*/ lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_New_O_I_O_O_O(p0 any, p1 int32, p2, p3, p4 any) *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A{}; t.Ctor_O_I_O_O_O(p0, p1, p2, p3, p4); return t }
//line :150:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A) Ctor_O_I_O_O_O(c__i any, c__n int32, c__step, c__s, c__last any) { t.F_i = c__i; t.F_n = c__n; t.F_step = c__step; t.F_s = c__s; t.F_last = c__last }
//line :150:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A) Invoke_O__O(self any) any {
	var tmp1 bool; var na_313 any = t.F_i; var na_314 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_313) { var n0_315 int64 = jrt.NN(jrt.Long_Cast(na_313)).LongValue__J(); var n1_316 int64 = na_314; tmp1 = n0_315 < n1_316 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_313, na_314) }; if tmp1 { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); var c__1 uint16 = jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(t.F_i))

		if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_68)).CharValue__C()) {
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_69).Invoke_O__O(t.F_last)) {
				var root_318 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = Lit_32; var arg_322 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_step); var tmp4 jrt.Number_I; var na_323 any; var t_ any = t.F_i; t.F_i = nil; na_323 = t_; if jrt.Long_InstanceOf(na_323) { var n0_324 int64 = jrt.NN(jrt.Long_Cast(na_323)).LongValue__J(); if n0_324 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_323) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_324 + 1)) } } else { if jrt.Double_InstanceOf(na_323) { var n0_324_2 float64 = jrt.NN(jrt.Double_Cast(na_323)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_324_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_323) } }; arg_322 = tmp3.Invoke_O_O__O(tmp4, Lit_32); if linked_319 == nil { return ifn_320.Invoke_O_O__O(arg_321, arg_322) } else { return linked_319.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_318, arg_321, arg_322) } } else {
					var tmp5 lang.IFn = lang.IFn_Cast(t.F_step); var tmp6 jrt.Number_I; var na_454 any; var t__2 any = t.F_i; t.F_i = nil; na_454 = t__2; if jrt.Long_InstanceOf(na_454) { var n0_455 int64 = jrt.NN(jrt.Long_Cast(na_454)).LongValue__J(); if n0_455 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_454) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_455 + 1)) } } else { if jrt.Double_InstanceOf(na_454) { var n0_455_2 float64 = jrt.NN(jrt.Double_Cast(na_454)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_455_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_454) } }; var tmp7 any = tmp6; var tmp8 any; var t__3 any = t.F_last; t.F_last = nil; tmp8 = t__3; return tmp5.Invoke_O_O__O(tmp7, tmp8) } } else {
//line :153:1
						if jrt.Character_IsWhitespace_C__Z_NoInit(c__1) {



							var tmp9 lang.IFn = lang.IFn_Cast(t.F_step); var tmp10 jrt.Number_I; var na_456 any; var t__4 any = t.F_i; t.F_i = nil; na_456 = t__4; if jrt.Long_InstanceOf(na_456) { var n0_457 int64 = jrt.NN(jrt.Long_Cast(na_456)).LongValue__J(); if n0_457 == 9223372036854775807 { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_456) } else { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_457 + 1)) } } else { if jrt.Double_InstanceOf(na_456) { var n0_457_2 float64 = jrt.NN(jrt.Double_Cast(na_456)).DoubleValue__D(); tmp10 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_457_2 + 1.0)) } else { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_456) } }; var tmp11 any = tmp10; var tmp12 any; var t__5 any = t.F_last; t.F_last = nil; tmp12 = t__5; return tmp9.Invoke_O_O__O(tmp11, tmp12) } else {
//line :153:1
								var tmp13 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_71)).CharValue__C())




								if and__1927000168__auto____2 { var and__1927000168__auto____3 bool; var na_325 any; var na_327 any = t.F_i; if jrt.Long_InstanceOf(na_327) { var n0_328 int64 = jrt.NN(jrt.Long_Cast(na_327)).LongValue__J(); if n0_328 == 9223372036854775807 { na_325 = lang.Numbers_Inc_O__Number_NoInit(na_327) } else { na_325 = jrt.Long_ValueOf_J__Long_NoInit(n0_328 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_327) { var n0_328_2 float64 = jrt.NN(jrt.Double_Cast(na_327)).DoubleValue__D(); na_325 = jrt.Double_ValueOf_D__Double_NoInit(n0_328_2 + 1.0).Ref() } else { na_325 = lang.Numbers_Inc_O__Number_NoInit(na_327) } }; var na_326 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_325) { var n0_329 int64 = jrt.NN(jrt.Long_Cast(na_325)).LongValue__J(); var n1_330 int64 = na_326; and__1927000168__auto____3 = n0_329 < n1_330 } else { and__1927000168__auto____3 = lang.Numbers_Lt_O_J__Z_NoInit(na_325, na_326) }; if and__1927000168__auto____3 { var tmp14 uint16 = jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_71)).CharValue__C(); var tmp15 *jrt.String = jrt.String_Cast(t.F_s); var tmp16 jrt.Number_I; var na_332 any = t.F_i; if jrt.Long_InstanceOf(na_332) { var n0_333 int64 = jrt.NN(jrt.Long_Cast(na_332)).LongValue__J(); if n0_333 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_332) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_333 + 1)) } } else { if jrt.Double_InstanceOf(na_332) { var n0_333_2 float64 = jrt.NN(jrt.Double_Cast(na_332)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_333_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_332) } }; tmp13 = lang.Util_Equiv_C_C__Z_NoInit(tmp14, jrt.NN(tmp15).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp16))) } else { tmp13 = and__1927000168__auto____3 } } else { tmp13 = and__1927000168__auto____2 }
//line :153:1
								if tmp13 { var j__2 any; var tmp17 any; var t__6 any = t.F_s





									t.F_s = nil; tmp17 = t__6; var tmp18 any = tmp17; var tmp19 any; var t__7 any = t.F_i; t.F_i = nil; tmp19 = t__7; j__2 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp18, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_46, tmp19)); var tmp20 lang.IFn = lang.IFn_Cast(t.F_step); var tmp21 any; var tmp22 bool; var na_458 any = j__2; if jrt.Long_InstanceOf(na_458) { var n0_459 int64 = jrt.NN(jrt.Long_Cast(na_458)).LongValue__J(); tmp22 = n0_459 < 0 } else { if jrt.Double_InstanceOf(na_458) { var n0_459_2 float64 = jrt.NN(jrt.Double_Cast(na_458)).DoubleValue__D(); tmp22 = n0_459_2 < 0.0 } else { tmp22 = lang.Numbers_IsNeg_O__Z_NoInit(na_458) } }; if tmp22 { tmp21 = jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n).Ref() } else { tmp21 = j__2 }; var tmp23 any = tmp21; var tmp24 any; var t__8 any = t.F_last; t.F_last = nil; tmp24 = t__8; return tmp20.Invoke_O_O__O(tmp23, tmp24) } else {
//line :153:1
										var tmp25 bool; var and__1927000168__auto____2_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_71)).CharValue__C())






										if and__1927000168__auto____2_2 { var and__1927000168__auto____3_2 bool; var na_334 any; var na_336 any = t.F_i; if jrt.Long_InstanceOf(na_336) { var n0_337 int64 = jrt.NN(jrt.Long_Cast(na_336)).LongValue__J(); if n0_337 == 9223372036854775807 { na_334 = lang.Numbers_Inc_O__Number_NoInit(na_336) } else { na_334 = jrt.Long_ValueOf_J__Long_NoInit(n0_337 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_336) { var n0_337_2 float64 = jrt.NN(jrt.Double_Cast(na_336)).DoubleValue__D(); na_334 = jrt.Double_ValueOf_D__Double_NoInit(n0_337_2 + 1.0).Ref() } else { na_334 = lang.Numbers_Inc_O__Number_NoInit(na_336) } }; var na_335 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_334) { var n0_338 int64 = jrt.NN(jrt.Long_Cast(na_334)).LongValue__J(); var n1_339 int64 = na_335; and__1927000168__auto____3_2 = n0_338 < n1_339 } else { and__1927000168__auto____3_2 = lang.Numbers_Lt_O_J__Z_NoInit(na_334, na_335) }; if and__1927000168__auto____3_2 { var tmp26 uint16 = jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_72)).CharValue__C(); var tmp27 *jrt.String = jrt.String_Cast(t.F_s); var tmp28 jrt.Number_I; var na_341 any = t.F_i; if jrt.Long_InstanceOf(na_341) { var n0_342 int64 = jrt.NN(jrt.Long_Cast(na_341)).LongValue__J(); if n0_342 == 9223372036854775807 { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_341) } else { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_342 + 1)) } } else { if jrt.Double_InstanceOf(na_341) { var n0_342_2 float64 = jrt.NN(jrt.Double_Cast(na_341)).DoubleValue__D(); tmp28 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_342_2 + 1.0)) } else { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_341) } }; tmp25 = lang.Util_Equiv_C_C__Z_NoInit(tmp26, jrt.NN(tmp27).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp28))) } else { tmp25 = and__1927000168__auto____3_2 } } else { tmp25 = and__1927000168__auto____2_2 }
//line :153:1
										if tmp25 { var j__2_2 any; var tmp29 any = t.F_s; var tmp30 jrt.Number_I; var na_343 any = t.F_i
											var na_344 int64 = 2






											if jrt.Long_InstanceOf(na_343) { var n0_345 int64 = jrt.NN(jrt.Long_Cast(na_343)).LongValue__J(); var n1_346 int64 = na_344; var nr_347 int64 = n0_345 + n1_346; if (n0_345^nr_347)&(n1_346^nr_347) >= 0 { tmp30 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_347)) } else { tmp30 = lang.Numbers_Add_O_J__Number_NoInit(na_343, na_344) } } else { tmp30 = lang.Numbers_Add_O_J__Number_NoInit(na_343, na_344) }; j__2_2 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp29, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_47, tmp30))
//line :153:1
											var nl__3 any; var and__1927000168__auto____3_3 bool
											var na_348 any = j__2_2







											if jrt.Long_InstanceOf(na_348) { var n0_349 int64 = jrt.NN(jrt.Long_Cast(na_348)).LongValue__J(); and__1927000168__auto____3_3 = n0_349 > 0 } else { if jrt.Double_InstanceOf(na_348) { var n0_349_2 float64 = jrt.NN(jrt.Double_Cast(na_348)).DoubleValue__D(); and__1927000168__auto____3_3 = n0_349_2 > 0.0 } else { and__1927000168__auto____3_3 = lang.Numbers_IsPos_O__Z_NoInit(na_348) } }; if and__1927000168__auto____3_3 { var root_350 any = A_arbace_box_plan_A_const_67.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var root_355 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any; var t__9 any = t.F_s; t.F_s = nil; arg_358 = t__9; var arg_359 any; var t__10 any = t.F_i; t.F_i = nil; arg_359 = t__10; var arg_360 any = j__2_2; if linked_356 == nil { arg_353 = ifn_357.Invoke_O_O_O__O(arg_358, arg_359, arg_360) } else { arg_353 = linked_356.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_355, arg_358, arg_359, arg_360) }; var arg_354 any = Lit_46; if linked_351 == nil { nl__3 = ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { nl__3 = linked_351.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_350, arg_353, arg_354) } } else { nl__3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3_3).Ref() }
											var tmp31 any; var and__1927000168__auto____4 any = nl__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp31 = lang.IFn_Cast(A_arbace_box_plan_A_const_73).Invoke_O__O(t.F_last) } else { tmp31 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp31) {
												var root_361 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = Lit_32; var arg_365 any; var tmp32 lang.IFn = lang.IFn_Cast(t.F_step); var tmp33 jrt.Number_I; var tmp34 bool; var na_366 any = j__2_2; if jrt.Long_InstanceOf(na_366) { var n0_367 int64 = jrt.NN(jrt.Long_Cast(na_366)).LongValue__J(); tmp34 = n0_367 < 0 } else { if jrt.Double_InstanceOf(na_366) { var n0_367_2 float64 = jrt.NN(jrt.Double_Cast(na_366)).DoubleValue__D(); tmp34 = n0_367_2 < 0.0 } else { tmp34 = lang.Numbers_IsNeg_O__Z_NoInit(na_366) } }; if tmp34 { tmp33 = Up_Integer_Number(jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n)) } else { var na_368 any = j__2_2; var na_369 int64 = 2; if jrt.Long_InstanceOf(na_368) { var n0_370 int64 = jrt.NN(jrt.Long_Cast(na_368)).LongValue__J(); var n1_371 int64 = na_369; var nr_372 int64 = n0_370 + n1_371; if (n0_370^nr_372)&(n1_371^nr_372) >= 0 { tmp33 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_372)) } else { tmp33 = lang.Numbers_Add_O_J__Number_NoInit(na_368, na_369) } } else { tmp33 = lang.Numbers_Add_O_J__Number_NoInit(na_368, na_369) } }; arg_365 = tmp32.Invoke_O_O__O(tmp33, Lit_32); if linked_362 == nil { return ifn_363.Invoke_O_O__O(arg_364, arg_365) } else { return linked_362.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_361, arg_364, arg_365) } } else {
													var tmp35 lang.IFn = lang.IFn_Cast(t.F_step); var tmp36 jrt.Number_I; var tmp37 bool; var na_460 any = j__2_2; if jrt.Long_InstanceOf(na_460) { var n0_461 int64 = jrt.NN(jrt.Long_Cast(na_460)).LongValue__J(); tmp37 = n0_461 < 0 } else { if jrt.Double_InstanceOf(na_460) { var n0_461_2 float64 = jrt.NN(jrt.Double_Cast(na_460)).DoubleValue__D(); tmp37 = n0_461_2 < 0.0 } else { tmp37 = lang.Numbers_IsNeg_O__Z_NoInit(na_460) } }; if tmp37 { tmp36 = Up_Integer_Number(jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n)) } else { var na_462 any = j__2_2; var na_463 int64 = 2; if jrt.Long_InstanceOf(na_462) { var n0_464 int64 = jrt.NN(jrt.Long_Cast(na_462)).LongValue__J(); var n1_465 int64 = na_463; var nr_466 int64 = n0_464 + n1_465; if (n0_464^nr_466)&(n1_465^nr_466) >= 0 { tmp36 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_466)) } else { tmp36 = lang.Numbers_Add_O_J__Number_NoInit(na_462, na_463) } } else { tmp36 = lang.Numbers_Add_O_J__Number_NoInit(na_462, na_463) } }; var tmp38 any = tmp36; var tmp39 any; var t__11 any = t.F_last; t.F_last = nil; tmp39 = t__11; return tmp35.Invoke_O_O__O(tmp38, tmp39) } } else {
//line :153:1
														if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_74)).CharValue__C()) { var sb__2 any = jrt.StringBuilder_New(); var j__3 any; var tmp40 any = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_New_O_O_O(t.F_i, sb__2, t.F_s); var tmp41 *jrt.Class
															var fncls__386 /*line :153:1*/*jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_fn_class













															if fncls__386 == nil { var fncls__386d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_fn_class = fncls__386d; tmp41 = fncls__386d } else { tmp41 = fncls__386 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil).Invoke__O()




															var root_387 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var tmp42 any = A_arbace_box_plan_A_const_76; var tmp43 any; var root_392 any = A_arbace_box_plan_A_const_77.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = sb__2; if linked_393 == nil { tmp43 = ifn_394.Invoke_O__O(arg_395) } else { tmp43 = linked_393.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_392, arg_395) }; arg_390 = lang.Tuple_Create_O_O__IPersistentVector(tmp42, tmp43); var arg_391 any = lang.IFn_Cast(t.F_step).Invoke_O_O__O(j__3, A_arbace_box_plan_A_const_76); if linked_388 == nil { return ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { return linked_388.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) } } else {
//line :153:1
																if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_78)).CharValue__C()) { var j__2_3 any; var tmp44 any = t.F_s; var tmp45 jrt.Number_I; var na_396 any = t.F_i



















																	if jrt.Long_InstanceOf(na_396) { var n0_397 int64 = jrt.NN(jrt.Long_Cast(na_396)).LongValue__J(); if n0_397 == 9223372036854775807 { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_396) } else { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_397 + 1)) } } else { if jrt.Double_InstanceOf(na_396) { var n0_397_2 float64 = jrt.NN(jrt.Double_Cast(na_396)).DoubleValue__D(); tmp45 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_397_2 + 1.0)) } else { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_396) } }; j__2_3 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp44, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_49, tmp45))
																	var root_398 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var tmp46 any = A_arbace_box_plan_A_const_76; var tmp47 any; var root_403 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var t__12 any = t.F_s; t.F_s = nil; arg_406 = t__12; var arg_407 any; var na_409 any; var t__13 any = t.F_i; t.F_i = nil; na_409 = t__13; if jrt.Long_InstanceOf(na_409) { var n0_410 int64 = jrt.NN(jrt.Long_Cast(na_409)).LongValue__J(); if n0_410 == 9223372036854775807 { arg_407 = lang.Numbers_Inc_O__Number_NoInit(na_409) } else { arg_407 = jrt.Long_ValueOf_J__Long_NoInit(n0_410 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_409) { var n0_410_2 float64 = jrt.NN(jrt.Double_Cast(na_409)).DoubleValue__D(); arg_407 = jrt.Double_ValueOf_D__Double_NoInit(n0_410_2 + 1.0).Ref() } else { arg_407 = lang.Numbers_Inc_O__Number_NoInit(na_409) } }; var arg_408 any = j__2_3; if linked_404 == nil { tmp47 = ifn_405.Invoke_O_O_O__O(arg_406, arg_407, arg_408) } else { tmp47 = linked_404.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_403, arg_406, arg_407, arg_408) }; arg_401 = lang.Tuple_Create_O_O__IPersistentVector(tmp46, tmp47); var arg_402 any; var tmp48 lang.IFn = lang.IFn_Cast(t.F_step); var tmp49 jrt.Number_I; var na_411 any = j__2_3; if jrt.Long_InstanceOf(na_411) { var n0_412 int64 = jrt.NN(jrt.Long_Cast(na_411)).LongValue__J(); if n0_412 == 9223372036854775807 { tmp49 = lang.Numbers_Inc_O__Number_NoInit(na_411) } else { tmp49 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_412 + 1)) } } else { if jrt.Double_InstanceOf(na_411) { var n0_412_2 float64 = jrt.NN(jrt.Double_Cast(na_411)).DoubleValue__D(); tmp49 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_412_2 + 1.0)) } else { tmp49 = lang.Numbers_Inc_O__Number_NoInit(na_411) } }; arg_402 = tmp48.Invoke_O_O__O(tmp49, A_arbace_box_plan_A_const_76); if linked_399 == nil { return ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { return linked_399.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) } } else {
//line :153:1
																		var tmp50 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(c__1)





















																		if or__1927000174__auto____2 { tmp50 = or__1927000174__auto____2 } else { tmp50 = lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_79)).CharValue__C()) }
//line :153:1
																		if tmp50 { var j__2_4 any; var tmp51 any = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_New_O_I_O(t.F_i, t.F_n, t.F_s); var tmp52 *jrt.Class
																			var fncls__420 /*line :153:1*/*jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_fn_class






















																			if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_fn_class = fncls__420d; tmp52 = fncls__420d } else { tmp52 = fncls__420 }; j__2_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil).Invoke__O()
																			var root_421 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any; var tmp53 any = A_arbace_box_plan_A_const_80; var tmp54 any; var root_426 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var t__14 any = t.F_s; t.F_s = nil; arg_429 = t__14; var arg_430 any; var t__15 any = t.F_i; t.F_i = nil; arg_430 = t__15; var arg_431 any = j__2_4; if linked_427 == nil { tmp54 = ifn_428.Invoke_O_O_O__O(arg_429, arg_430, arg_431) } else { tmp54 = linked_427.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_426, arg_429, arg_430, arg_431) }; arg_424 = lang.Tuple_Create_O_O__IPersistentVector(tmp53, tmp54); var arg_425 any = lang.IFn_Cast(t.F_step).Invoke_O_O__O(j__2_4, A_arbace_box_plan_A_const_80); if linked_422 == nil { return ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { return linked_422.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } } else {
//line :153:1
																				if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_81)).CharValue__C()) {
























																					var root_432 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = Lit_23; var arg_436 any; var tmp55 lang.IFn = lang.IFn_Cast(t.F_step); var tmp56 jrt.Number_I; var na_437 any; var t__16 any = t.F_i; t.F_i = nil; na_437 = t__16; if jrt.Long_InstanceOf(na_437) { var n0_438 int64 = jrt.NN(jrt.Long_Cast(na_437)).LongValue__J(); if n0_438 == 9223372036854775807 { tmp56 = lang.Numbers_Inc_O__Number_NoInit(na_437) } else { tmp56 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_438 + 1)) } } else { if jrt.Double_InstanceOf(na_437) { var n0_438_2 float64 = jrt.NN(jrt.Double_Cast(na_437)).DoubleValue__D(); tmp56 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_438_2 + 1.0)) } else { tmp56 = lang.Numbers_Inc_O__Number_NoInit(na_437) } }; arg_436 = tmp55.Invoke_O_O__O(tmp56, Lit_23); if linked_433 == nil { return ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { return linked_433.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) } } else {
//line :153:1
																						if A_arbace_box_plan_A_const_41 != nil {

























																							var root_439 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var root_444 any = A_arbace_box_plan_A_const_77.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = jrt.Character_ValueOf_C__Character_NoInit(c__1).Ref(); if linked_445 == nil { arg_442 = ifn_446.Invoke_O__O(arg_447) } else { arg_442 = linked_445.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_444, arg_447) }; var arg_443 any; var tmp57 lang.IFn = lang.IFn_Cast(t.F_step); var tmp58 jrt.Number_I; var na_448 any; var t__17 any = t.F_i; t.F_i = nil; na_448 = t__17; if jrt.Long_InstanceOf(na_448) { var n0_449 int64 = jrt.NN(jrt.Long_Cast(na_448)).LongValue__J(); if n0_449 == 9223372036854775807 { tmp58 = lang.Numbers_Inc_O__Number_NoInit(na_448) } else { tmp58 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_449 + 1)) } } else { if jrt.Double_InstanceOf(na_448) { var n0_449_2 float64 = jrt.NN(jrt.Double_Cast(na_448)).DoubleValue__D(); tmp58 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_449_2 + 1.0)) } else { tmp58 = lang.Numbers_Inc_O__Number_NoInit(na_448) } }; var tmp59 any = tmp58; var tmp60 any; var root_450 any = A_arbace_box_plan_A_const_77.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = jrt.Character_ValueOf_C__Character_NoInit(c__1).Ref(); if linked_451 == nil { tmp60 = ifn_452.Invoke_O__O(arg_453) } else { tmp60 = linked_451.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_450, arg_453) }; arg_443 = tmp57.Invoke_O_O__O(tmp59, tmp60); if linked_440 == nil { return ifn_441.Invoke_O_O__O(arg_442, arg_443) } else { return linked_440.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_439, arg_442, arg_443) } } else {
//line :153:1
																								return nil } } } } } } } } } } else {
//line :151:1
																									return nil
																								}
}













func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :167:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A) Invoke_O__O(self any) any { { var j__1 any; var na_373 any; var t_ any = t.F_i; t.F_i = nil; na_373 = t_; if jrt.Long_InstanceOf(na_373) { var n0_374 int64 = jrt.NN(jrt.Long_Cast(na_373)).LongValue__J(); if n0_374 == 9223372036854775807 { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_373) } else { j__1 = jrt.Long_ValueOf_J__Long_NoInit(n0_374 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_373) { var n0_374_2 float64 = jrt.NN(jrt.Double_Cast(na_373)).DoubleValue__D(); j__1 = jrt.Double_ValueOf_D__Double_NoInit(n0_374_2 + 1.0).Ref() } else { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_373) } }; L1: for { var tmp1 *jrt.String = jrt.String_Cast(t.F_s); var d__2 uint16 = jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))

	if lang.Util_Equiv_C_C__Z_NoInit(d__2, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_75)).CharValue__C()) { var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp3 *jrt.String = jrt.String_Cast(t.F_s); var tmp4 jrt.Number_I; var na_377 any = j__1; if jrt.Long_InstanceOf(na_377) { var n0_378 int64 = jrt.NN(jrt.Long_Cast(na_377)).LongValue__J(); if n0_378 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_377) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_378 + 1)) } } else { if jrt.Double_InstanceOf(na_377) { var n0_378_2 float64 = jrt.NN(jrt.Double_Cast(na_377)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_378_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_377) } }; jrt.NN(tmp2).Append_C__StringBuilder(jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp4))); var tmp5 jrt.Number_I; var na_379 any = j__1; var na_380 int64 = 2; if jrt.Long_InstanceOf(na_379) { var n0_381 int64 = jrt.NN(jrt.Long_Cast(na_379)).LongValue__J(); var n1_382 int64 = na_380; var nr_383 int64 = n0_381 + n1_382; if (n0_381^nr_383)&(n1_382^nr_383) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_383)) } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_379, na_380) } } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_379, na_380) }; j__1 = tmp5; continue L1 } else { if lang.Util_Equiv_C_C__Z_NoInit(d__2, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_74)).CharValue__C()) {
		var na_375 any = j__1; if jrt.Long_InstanceOf(na_375) { var n0_376 int64 = jrt.NN(jrt.Long_Cast(na_375)).LongValue__J(); if n0_376 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_375) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_376 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_375) { var n0_376_2 float64 = jrt.NN(jrt.Double_Cast(na_375)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_376_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_375) } } } else {
//line :169:1
			if A_arbace_box_plan_A_const_41 != nil {

				jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_C__StringBuilder(d__2); var tmp6 jrt.Number_I; var na_384 any = j__1; if jrt.Long_InstanceOf(na_384) { var n0_385 int64 = jrt.NN(jrt.Long_Cast(na_384)).LongValue__J(); if n0_385 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_384) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_385 + 1)) } } else { if jrt.Double_InstanceOf(na_384) { var n0_385_2 float64 = jrt.NN(jrt.Double_Cast(na_384)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_385_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_384) } }; j__1 = tmp6; continue L1 } else {
//line :169:1
					return nil } } } } }; /*line :167:1*/panic("j2g: unreachable") }








func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A) Ctor_O_I_O(c__i any, c__n int32, c__s any) { t.F_i = c__i; t.F_n = c__n; t.F_s = c__s }
//line :176:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_413 any = j__1; var na_414 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_413) { var n0_415 int64 = jrt.NN(jrt.Long_Cast(na_413)).LongValue__J(); var n1_416 int64 = na_414; and__1927000168__auto____2 = n0_415 < n1_416 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_413, na_414) }; if and__1927000168__auto____2 { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); var d__3 uint16 = jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1)); var or__1927000174__auto____4 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(d__3); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_C_C__Z_NoInit(d__3, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_79)).CharValue__C()) } } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp3 jrt.Number_I; var na_418 any = j__1; if jrt.Long_InstanceOf(na_418) { var n0_419 int64 = jrt.NN(jrt.Long_Cast(na_418)).LongValue__J(); if n0_419 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_418) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_419 + 1)) } } else { if jrt.Double_InstanceOf(na_418) { var n0_419_2 float64 = jrt.NN(jrt.Double_Cast(na_418)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_419_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_418) } }; j__1 = tmp3; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }





func A_arbace_box_plan_go_info_A_New() *A_arbace_box_plan_go_info_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_box_plan_go_info_A) Ctor() {}
//line :182:1
func (t *A_arbace_box_plan_go_info_A) Invoke_O_O_O__O(self, s__0, what__1 any) any { var toks__3 any; var root_469 any = A_arbace_box_plan_A_const_83.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_471 lang.IFn; if


	linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var tmp1 any = A_arbace_box_plan_go_info_fn__1305000070_A_New(); var tmp2 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000070_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_box_plan_go_info_fn__1305000070_A_fn_class = fncls__474d; tmp2 = fncls__474d } else { tmp2 = fncls__474 }; arg_472 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_473 any; var root_475 any = A_arbace_box_plan_A_const_84.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_box_plan_go_tokens_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = s__0; if linked_476 == nil { arg_473 = ifn_477.Invoke_O__O(arg_478) } else { arg_473 = linked_476.(*A_arbace_box_plan_go_tokens_A).Invoke_O_O__O(root_475, arg_478) }; if linked_470 == nil { toks__3 = ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { toks__3 = linked_470.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) }; var ___4 any; var tmp3 any = A_arbace_box_plan_A_const_85; var tmp4 any; var root_479 any = /*line :182:1*/A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_481 lang.IFn; _ = ___4; if



	linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = toks__3; if linked_480 == nil { tmp4 = ifn_481.Invoke_O__O(arg_482) } else { tmp4 = linked_480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_479, arg_482) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { ___4 = nil } else {
		var root_483 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, A_arbace_box_plan_fail_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, what__1, nil)).Ref(); var arg_487 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_484 == nil { ___4 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { ___4 = linked_484.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_483, arg_486, arg_487) } }; var pkg__5 any; var root_488 any = /*line :182:1*/A_arbace_box_plan_A_const_86.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_490 lang.IFn; if





	linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any; var root_492 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = toks__3; if linked_493 == nil { arg_491 = ifn_494.Invoke_O__O(arg_495) } else { arg_491 = linked_493.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_492, arg_495) }; if linked_489 == nil { pkg__5 = ifn_490.Invoke_O__O(arg_491) } else { pkg__5 = linked_489.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_488, arg_491) }; var imports__6 any; var tmp5 any = /*line :182:1*/A_arbace_box_plan_go_info_fn__1305000072_A_New_O(toks__3); var tmp6 *jrt.Class; var fncls__591 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_A_fn_class; if






	fncls__591 == nil { var fncls__591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_box_plan_go_info_fn__1305000072_A_fn_class = fncls__591d; tmp6 = fncls__591d } else { tmp6 = fncls__591 }; imports__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var embeds__7 any; var tmp7 any; var root_592 any = /*line :182:1*/A_arbace_box_plan_A_const_94.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_594 lang.IFn; if
















	linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = A_arbace_box_plan_A_const_95; var arg_596 any = imports__6; if linked_593 == nil { tmp7 = ifn_594.Invoke_O_O__O(arg_595, arg_596) } else { tmp7 = linked_593.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_592, arg_595, arg_596) }; if jrt.J2g_Truth(tmp7) {
		var root_597 any = A_arbace_box_plan_A_const_44.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_96.GetRawRoot__O()); var tmp9 any = A_arbace_box_plan_go_info_fn__1305000090_A_New(); var tmp10 *jrt.Class; var fncls__642 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000090_A_fn_class; if fncls__642 == nil { var fncls__642d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_box_plan_go_info_fn__1305000090_A_fn_class = fncls__642d; tmp10 = fncls__642d } else { tmp10 = fncls__642 }; var tmp11 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp12 any; var root_643 any = A_arbace_box_plan_A_const_60.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_645 lang.IFn



		if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = s__0; if linked_644 == nil { tmp12 = ifn_645.Invoke_O__O(arg_646) } else { tmp12 = linked_644.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_643, arg_646) }
//line :200:1
		arg_600 = tmp8.Invoke_O_O__O(tmp11, tmp12); if linked_598 == nil { embeds__7 = ifn_599.Invoke_O__O(arg_600) } else { embeds__7 = linked_598.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_597, arg_600) } } else {
//line :199:1
			embeds__7 = nil }; return /*line :182:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_101, pkg__5, A_arbace_box_plan_A_const_102, imports__6, A_arbace_box_plan_A_const_103, embeds__7)) }


func A_arbace_box_plan_go_info_fn__1305000070_A_New() *A_arbace_box_plan_go_info_fn__1305000070_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000070_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_box_plan_go_info_fn__1305000070_A) Ctor() {}
//line :185:1
func (t *A_arbace_box_plan_go_info_fn__1305000070_A) Invoke_O_O__O(self, p1__1305000064_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_32, p1__1305000064_SHARP___1)).Ref() }



func A_arbace_box_plan_go_info_fn__1305000072_A_New_O(p0 any) *A_arbace_box_plan_go_info_fn__1305000072_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_A) Ctor_O(c__toks any) { t.F_toks = c__toks }
//line :189:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_A) Invoke_O__O(self any) any { { var ts__1 any; var root_496 any = A_arbace_box_plan_A_const_87.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_496, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_500 any; var t_ any = t.F_toks; t.F_toks = nil; arg_500 = t_; if linked_497 == nil { ts__1 = ifn_498.Invoke_O_O__O(A_arbace_box_plan_A_const_43, arg_500) } else { ts__1 = linked_497.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_496, 2, A_arbace_box_plan_A_const_43, arg_500) }; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var ts__3 any; var root_501 any = A_arbace_box_plan_A_const_83.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_503 lang.IFn
										if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any; var tmp1 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_New(); var tmp2 *jrt.Class; var fncls__506 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_fn_class; if fncls__506 == nil { var fncls__506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_fn_class = fncls__506d; tmp2 = fncls__506d } else { tmp2 = fncls__506 }; arg_504 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_505 any = ts__1; if linked_502 == nil { ts__3 = ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { ts__3 = linked_502.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) }
										var tmp3 any = A_arbace_box_plan_A_const_88; var tmp4 any; var root_507 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = ts__3; if linked_508 == nil { tmp4 = ifn_509.Invoke_O__O(arg_510) } else { tmp4 = linked_508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_507, arg_510) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { var ts__4 any; var root_511 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_513 lang.IFn
											if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = ts__3; if linked_512 == nil { ts__4 = ifn_513.Invoke_O__O(arg_514) } else { ts__4 = linked_512.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_511, arg_514) }
											var tmp5 any; var root_515 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = ts__4; if linked_516 == nil { tmp5 = ifn_517.Invoke_O__O(arg_518) } else { tmp5 = linked_516.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_515, arg_518) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_22, tmp5) { var vec__1305000075__5 any; var root_519 any = A_arbace_box_plan_A_const_89.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_521 lang.IFn
												if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var tmp6 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_New(); var tmp7 *jrt.Class; var fncls__529 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_fn_class; if fncls__529 == nil { var fncls__529d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_fn_class = fncls__529d; tmp7 = fncls__529d } else { tmp7 = fncls__529 }; arg_522 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_523 any; var root_530 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = ts__4; if linked_531 == nil { arg_523 = ifn_532.Invoke_O__O(arg_533) } else { arg_523 = linked_531.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_530, arg_533) }; if linked_520 == nil { vec__1305000075__5 = ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { vec__1305000075__5 = linked_520.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_519, arg_522, arg_523) }
//line :193:1
			var spec__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000075__5, lang.RT_IntCast_J__I_NoInit(0), nil); var more__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000075__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp8 any; var root_545 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_547 lang.IFn

			if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = more__7; if linked_546 == nil { tmp8 = ifn_547.Invoke_O__O(arg_548) } else { tmp8 = linked_546.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_545, arg_548) }; var tmp9 any = tmp8; var tmp10 any; var root_549 any = A_arbace_box_plan_A_const_91.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = acc__2; var arg_553 any; var root_554 any = A_arbace_box_plan_A_const_92.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any; var tmp11 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_New(); var tmp12 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_fn_class = fncls__567d; tmp12 = fncls__567d } else { tmp12 = fncls__567 }; arg_557 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_558 any = spec__6; if linked_555 == nil { arg_553 = ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { arg_553 = linked_555.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_554, arg_557, arg_558) }; if linked_550 == nil { tmp10 = ifn_551.Invoke_O_O__O(arg_552, arg_553) } else { tmp10 = linked_550.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_549, arg_552, arg_553) }; ts__1, acc__2 = tmp9, tmp10; continue L1 } else {
//line :193:1
				var vec__1305000082__5 any; var root_534 any = A_arbace_box_plan_A_const_89.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_536 lang.IFn


				if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any; var tmp13 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_New(); var tmp14 *jrt.Class; var fncls__544 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_fn_class; if fncls__544 == nil { var fncls__544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_fn_class = fncls__544d; tmp14 = fncls__544d } else { tmp14 = fncls__544 }; arg_537 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_538 any = ts__4; if linked_535 == nil { vec__1305000082__5 = ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { vec__1305000082__5 = linked_535.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) }
//line :193:1
				var spec__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000082__5, lang.RT_IntCast_J__I_NoInit(0), nil); var more__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000082__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 any; var root_568 any = A_arbace_box_plan_A_const_91.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_570 lang.IFn



				if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = acc__2; var arg_572 any; var root_573 any = A_arbace_box_plan_A_const_92.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var tmp16 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_New(); var tmp17 *jrt.Class; var fncls__590 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_fn_class; if fncls__590 == nil { var fncls__590d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_fn_class = fncls__590d; tmp17 = fncls__590d } else { tmp17 = fncls__590 }; arg_576 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_577 any = spec__6_2; if linked_574 == nil { arg_572 = ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { arg_572 = linked_574.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_573, arg_576, arg_577) }; if linked_569 == nil { tmp15 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { tmp15 = linked_569.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; ts__1, acc__2 = more__7_2, tmp15; continue L1 } } else {
//line :191:1
					return acc__2 } } }; /*line :189:1*/panic("j2g: unreachable") }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A) Ctor() {}
//line :190:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A) Invoke_O_O__O(self, p1__1305000065_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_32, p1__1305000065_SHARP___1)).Ref() }



func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A) Ctor() {}
//line :194:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A) Invoke_O_O__O(self, p1__1305000066_SHARP___1 any) any { var root_524 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = Lit_23; var arg_528 any = p1__1305000066_SHARP___1; if linked_525 == nil { return ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { return linked_525.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_524, arg_527, arg_528) } }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A) Ctor() {}
//line :195:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A) Invoke_O_O__O(self, p1__1305000067_SHARP___1 any) any { var tmp1 any = A_arbace_box_plan_A_const_76; var tmp2 any; var root_559 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = p1__1305000067_SHARP___1; if linked_560 == nil { tmp2 = ifn_561.Invoke_O__O(arg_562) } else { tmp2 = linked_560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_559, arg_562) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var root_563 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = p1__1305000067_SHARP___1; if linked_564 == nil { return ifn_565.Invoke_O__O(arg_566) } else { return linked_564.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_563, arg_566) } } else { return nil } }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A) Ctor() {}
//line :196:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A) Invoke_O_O__O(self, p1__1305000068_SHARP___1 any) any { var root_539 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = Lit_32; var arg_543 any = p1__1305000068_SHARP___1; if linked_540 == nil { return ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { return linked_540.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_539, arg_542, arg_543) } }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A) Ctor() {}
//line :197:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A) Invoke_O_O__O(self, p1__1305000069_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_578 any = A_arbace_box_plan_A_const_93.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = p1__1305000069_SHARP___1; if linked_579 == nil { and__1927000168__auto____2 = ifn_580.Invoke_O__O(arg_581) } else { and__1927000168__auto____2 = linked_579.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_box_plan_A_const_76; var tmp3 any; var root_582 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = p1__1305000069_SHARP___1; if linked_583 == nil { tmp3 = ifn_584.Invoke_O__O(arg_585) } else { tmp3 = linked_583.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_582, arg_585) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_586 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = p1__1305000069_SHARP___1; if linked_587 == nil { return ifn_588.Invoke_O__O(arg_589) } else { return linked_587.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_586, arg_589) } } else { return nil } }


func A_arbace_box_plan_go_info_fn__1305000090_A_New() *A_arbace_box_plan_go_info_fn__1305000090_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000090_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_A) Ctor() {}
//line :200:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_A) Invoke_O_O__O(self, l__1 any) any { var t__2 any; var root_606 any = A_arbace_box_plan_A_const_61.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = l__1; if linked_607 == nil { t__2 = ifn_608.Invoke_O__O(arg_609) } else { t__2 = linked_607.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_606, arg_609) }; var tmp1 any; var root_610 any =
											A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = t__2; var arg_614 any = Lit_38; if linked_611 == nil { tmp1 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { tmp1 = linked_611.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }; if jrt.J2g_Truth(tmp1) {
												var root_615 any = A_arbace_box_plan_A_const_97.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any; var tmp2 any = A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_New(); var tmp3 *jrt.Class; var fncls__631 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_fn_class; if fncls__631 == nil { var fncls__631d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_fn_class = fncls__631d; tmp3 = fncls__631d } else { tmp3 = fncls__631 }; arg_618 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_619 any; var root_632 any = A_arbace_box_plan_A_const_52.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_634 lang.IFn
												if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = A_arbace_box_plan_A_const_99; var arg_636 any; var root_637 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = t__2; var arg_641 any = A_arbace_box_plan_A_const_100; if linked_638 == nil { arg_636 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { arg_636 = linked_638.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }; if linked_633 == nil { arg_619 = ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { arg_619 = linked_633.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_632, arg_635, arg_636) }
//line :202:1
		if linked_616 == nil { return ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { return linked_616.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_615, arg_618, arg_619) } } else {
//line :201:1
			return nil } }
func A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_New() *A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A) Ctor() {}
//line :202:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 any; var root_620 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = p__1; var arg_624 any = Lit_40; if linked_621 == nil { tmp1 = ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { tmp1 = linked_621.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }; if jrt.J2g_Truth(tmp1) { var root_625 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = p__1; var arg_629 any = A_arbace_box_plan_A_const_98; var arg_630 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(p__1)))).Ref(); if linked_626 == nil { return ifn_627.Invoke_O_O_O__O(arg_628, arg_629, arg_630) } else { return linked_626.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_625, arg_628, arg_629, arg_630) } } else { return p__1 } }







func A_arbace_box_plan_go_mod_lang_A_New() *A_arbace_box_plan_go_mod_lang_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_mod_lang_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_box_plan_go_mod_lang_A) Ctor() {}
//line :210:1
func (t *A_arbace_box_plan_go_mod_lang_A) Invoke_O_O__O(self, h__0 any) any { var temp__1927000414__auto____2 any; var tmp1 any; var root_647 any = A_arbace_box_plan_A_const_19.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, A_arbace_box_plan_entries_A_fn_class); var ifn_649 lang.IFn; if


	linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = h__0; if linked_648 == nil { tmp1 = ifn_649.Invoke_O__O(arg_650) } else { tmp1 = linked_648.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(root_647, arg_650) }; temp__1927000414__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, Lit_41); if jrt.J2g_Truth(temp__1927000414__auto____2) { var e__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_651 any = A_arbace_box_plan_A_const_64.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_653 lang.IFn
		if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = A_arbace_box_plan_A_const_104; var arg_655 any; var root_656 any = A_arbace_box_plan_A_const_105.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_box_plan_text_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = e__3; if linked_657 == nil { arg_655 = ifn_658.Invoke_O__O(arg_659) } else { arg_655 = linked_657.(*A_arbace_box_plan_text_A).Invoke_O_O__O(root_656, arg_659) }; if linked_652 == nil { temp__1927000414__auto____4 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { temp__1927000414__auto____4 = linked_652.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_651, arg_654, arg_655) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var vec__1305000095__5 any = temp__1927000414__auto____4; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000095__5, lang.RT_IntCast_J__I_NoInit(0), nil); var v__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000095__5, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___6
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__7)).Ref() } else {
//line :214:1
				return nil } } else {
//line :213:1
					return nil } }



func A_arbace_box_plan_locate_A_New() *A_arbace_box_plan_locate_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_locate_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_box_plan_locate_A) Ctor() {}
//line :217:1
func (t *A_arbace_box_plan_locate_A) Invoke_O_O_O_O__O(self, cfg__0, p__1, from_std__2 any) any { var map__1305000099__4 any = cfg__0; var map__1305000099__5 any; if




	lang.ISeq_InstanceOf(map__1305000099__4) { var tmp1 any; var root_660 any = A_arbace_box_plan_A_const_28.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = map__1305000099__4; if linked_661 == nil { tmp1 = ifn_662.Invoke_O__O(arg_663) } else { tmp1 = linked_661.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_660, arg_663) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_664 any = A_arbace_box_plan_A_const_29.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = map__1305000099__4; if linked_665 == nil { tmp2 = ifn_666.Invoke_O__O(arg_667) } else { tmp2 = linked_665.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_664, arg_667) }; map__1305000099__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_668 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = map__1305000099__4; if linked_669 == nil { tmp3 = ifn_670.Invoke_O__O(arg_671) } else { tmp3 = linked_669.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_668, arg_671) }; if jrt.J2g_Truth(tmp3) { var root_672 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = map__1305000099__4; if linked_673 == nil { map__1305000099__5 = ifn_674.Invoke_O__O(arg_675) } else { map__1305000099__5 = linked_673.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_672, arg_675) } } else { map__1305000099__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000099__5 = map__1305000099__4 }; var goroot__6 any = /*line :217:1*/lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_106); var modules__7 any = lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_107); var goospkg__8 any = lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_108); var goos__9 any = lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_32); var mod__10 any; var root_676 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_678 lang.IFn; if





	linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any; var root_680 any = A_arbace_box_plan_A_const_109.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var tmp4 any = A_arbace_box_plan_locate_fn__1305000102_A_New_O(p__1); var tmp5 *jrt.Class; var fncls__690 *jrt.Class = A_arbace_box_plan_locate_fn__1305000102_A_fn_class; if fncls__690 == nil { var fncls__690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_box_plan_locate_fn__1305000102_A_fn_class = fncls__690d; tmp5 = fncls__690d } else { tmp5 = fncls__690 }; arg_683 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_684 any = modules__7; if linked_681 == nil { arg_679 = ifn_682.Invoke_O_O__O(arg_683, arg_684) } else { arg_679 = linked_681.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_680, arg_683, arg_684) }; if linked_677 == nil { mod__10 = ifn_678.Invoke_O__O(arg_679) } else { mod__10 = linked_677.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_676, arg_679) }; var tmp6 any; var and__1927000168__auto____11 bool =
	lang.Util_Equiv_O_O__Z_NoInit(goos__9, Lit_55); if and__1927000168__auto____11 {
		var and__1927000168__auto____12 any = goospkg__8; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, Lit_56); if or__1927000174__auto____13 { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____13).Ref() } else { var root_691 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = p__1; var arg_695 any = Lit_57; if linked_692 == nil { tmp6 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { tmp6 = linked_692.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_691, arg_694, arg_695) } } } else { tmp6 = and__1927000168__auto____12 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() }; if /*line :224:1*/ jrt.J2g_Truth(tmp6) { var mt__11 any; var or__1927000174__auto____11 any = lang.RT_Get_O_O__O_NoInit(modules__7, goospkg__8)

			if jrt.J2g_Truth(or__1927000174__auto____11) { mt__11 = or__1927000174__auto____11 } else { var root_696 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, A_arbace_box_plan_fail_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_58, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, goospkg__8, nil)).Ref(); var arg_700 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_697 == nil { mt__11 = ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { mt__11 = linked_697.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) } }
//line :224:1
			var temp__1927000414__auto____12 any; var root_701 any = A_arbace_box_plan_A_const_110.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, A_arbace_box_plan_dir_at_A_fn_class); var ifn_703 lang.IFn


			if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = mt__11; var arg_705 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_60, nil); var tmp8 any; var root_706 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = p__1; var arg_710 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(Lit_56)).Ref(); if linked_707 == nil { tmp8 = ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { tmp8 = linked_707.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) }; arg_705 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(); if linked_702 == nil { temp__1927000414__auto____12 = ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { temp__1927000414__auto____12 = linked_702.(*A_arbace_box_plan_dir_at_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var d__13 any = temp__1927000414__auto____12; var tmp9 any = A_arbace_box_plan_A_const_20; var tmp10 any = A_arbace_box_plan_A_const_111; var tmp11 any = jrt.Boolean_FALSE.Ref(); var tmp12 any = A_arbace_box_plan_A_const_112; var tmp13 any; var root_711 any = A_arbace_box_plan_A_const_113.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, A_arbace_box_plan_go_mod_lang_A_fn_class); var ifn_713 lang.IFn

				if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = mt__11; if linked_712 == nil { tmp13 = ifn_713.Invoke_O__O(arg_714) } else { tmp13 = linked_712.(*A_arbace_box_plan_go_mod_lang_A).Invoke_O_O__O(root_711, arg_714) }
//line :227:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, d__13, tmp10, tmp11, tmp12, tmp13, A_arbace_box_plan_A_const_114, p__1)) } else { return nil } } else {
//line :224:1
					if jrt.J2g_Truth(mod__10) { var vec__1305000107__11 any = mod__10; var m__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var mt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000414__auto____14 any






						if lang.Util_Equiv_O_O__Z_NoInit(p__1, m__12) { temp__1927000414__auto____14 = mt__13 } else { var root_715 any = A_arbace_box_plan_A_const_110.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, A_arbace_box_plan_dir_at_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = mt__13; var arg_719 any; var root_720 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = p__1; var arg_724 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(m__12)))).Ref(); if linked_721 == nil { arg_719 = ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { arg_719 = linked_721.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_720, arg_723, arg_724) }; if linked_716 == nil { temp__1927000414__auto____14 = ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { temp__1927000414__auto____14 = linked_716.(*A_arbace_box_plan_dir_at_A).Invoke_O_O_O__O(root_715, arg_718, arg_719) } }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var d__15 any = temp__1927000414__auto____14; var tmp14 any = A_arbace_box_plan_A_const_20; var tmp15 any = A_arbace_box_plan_A_const_111; var tmp16 any = jrt.Boolean_FALSE.Ref(); var tmp17 any = A_arbace_box_plan_A_const_112; var tmp18 any; var root_725 any = A_arbace_box_plan_A_const_113.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, A_arbace_box_plan_go_mod_lang_A_fn_class); var ifn_727 lang.IFn
							if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = mt__13; if linked_726 == nil { tmp18 = ifn_727.Invoke_O__O(arg_728) } else { tmp18 = linked_726.(*A_arbace_box_plan_go_mod_lang_A).Invoke_O_O__O(root_725, arg_728) }
//line :231:1
							return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, d__15, tmp15, tmp16, tmp17, tmp18, A_arbace_box_plan_A_const_114, p__1)) } else { return nil } } else {
//line :224:1
								if A_arbace_box_plan_A_const_41 != nil { var or__1927000174__auto____11_2 any; var temp__1927000414__auto____11 any; var root_729 any = A_arbace_box_plan_A_const_110.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, A_arbace_box_plan_dir_at_A_fn_class); var ifn_731 lang.IFn








									if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = goroot__6; var arg_733 any = p__1; if linked_730 == nil { temp__1927000414__auto____11 = ifn_731.Invoke_O_O__O(arg_732, arg_733) } else { temp__1927000414__auto____11 = linked_730.(*A_arbace_box_plan_dir_at_A).Invoke_O_O_O__O(root_729, arg_732, arg_733) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var d__12 any = temp__1927000414__auto____11; var tmp19 any = A_arbace_box_plan_A_const_20; var tmp20 any = A_arbace_box_plan_A_const_111; var tmp21 any = jrt.Boolean_TRUE.Ref(); var tmp22 any = A_arbace_box_plan_A_const_112; var tmp23 any; var root_734 any = A_arbace_box_plan_A_const_113.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, A_arbace_box_plan_go_mod_lang_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = goroot__6; if linked_735 == nil { tmp23 = ifn_736.Invoke_O__O(arg_737) } else { tmp23 = linked_735.(*A_arbace_box_plan_go_mod_lang_A).Invoke_O_O__O(root_734, arg_737) }; or__1927000174__auto____11_2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, d__12, tmp20, tmp21, tmp22, tmp23, A_arbace_box_plan_A_const_114, p__1)) } else { or__1927000174__auto____11_2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____11_2) { return or__1927000174__auto____11_2 } else {
										if jrt.J2g_Truth(from_std__2) { var temp__1927000414__auto____12_2 any; var root_738 any = A_arbace_box_plan_A_const_110.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, A_arbace_box_plan_dir_at_A_fn_class); var ifn_740 lang.IFn
											if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = goroot__6; var arg_742 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(); if linked_739 == nil { temp__1927000414__auto____12_2 = ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { temp__1927000414__auto____12_2 = linked_739.(*A_arbace_box_plan_dir_at_A).Invoke_O_O_O__O(root_738, arg_741, arg_742) }; if jrt.J2g_Truth(temp__1927000414__auto____12_2) { var d__13_2 any = temp__1927000414__auto____12_2; var tmp24 any = A_arbace_box_plan_A_const_20; var tmp25 any = A_arbace_box_plan_A_const_111; var tmp26 any = jrt.Boolean_TRUE.Ref(); var tmp27 any = A_arbace_box_plan_A_const_112; var tmp28 any; var root_743 any = A_arbace_box_plan_A_const_113.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, A_arbace_box_plan_go_mod_lang_A_fn_class); var ifn_745 lang.IFn
												if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = goroot__6; if linked_744 == nil { tmp28 = ifn_745.Invoke_O__O(arg_746) } else { tmp28 = linked_744.(*A_arbace_box_plan_go_mod_lang_A).Invoke_O_O__O(root_743, arg_746) }
//line :235:1
												var tmp29 any = tmp28; var tmp30 any = A_arbace_box_plan_A_const_114; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, d__13_2, tmp25, tmp26, tmp27, tmp29, tmp30, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref())) } else { return nil } } else {
//line :234:1
													return nil } } } else {
//line :224:1
														return nil } } } }
//line :223:1
func A_arbace_box_plan_locate_fn__1305000102_A_New_O(p0 any) *A_arbace_box_plan_locate_fn__1305000102_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_locate_fn__1305000102_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_box_plan_locate_fn__1305000102_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :223:1
func (t *A_arbace_box_plan_locate_fn__1305000102_A) Invoke_O_O__O(self, p__1305000101__1 any) any { var vec__1305000103__2 any = p__1305000101__1; var m__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000103__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000103__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_p, m__3); _ = ___4; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_685 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = t.F_p; var arg_689 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, m__3, nil)).Ref(); if linked_686 == nil { return ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { return linked_686.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_685, arg_688, arg_689) } } }














func A_arbace_box_plan_embed_files_A_New() *A_arbace_box_plan_embed_files_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_embed_files_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_box_plan_embed_files_A) Ctor() {}
//line :238:1
func (t *A_arbace_box_plan_embed_files_A) Invoke_O_O_O_O__O(self, d__0, pattern__1, what__2 any) any { var all__4 any; var root_747 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_749 lang.IFn; if



	linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = pattern__1; var arg_751 any = Lit_2; if linked_748 == nil { all__4 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { all__4 = linked_748.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; var p__5 any; if
	jrt.J2g_Truth(all__4) { var root_752 any = A_arbace_box_plan_A_const_45.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = pattern__1; var arg_756 any = A_arbace_box_plan_A_const_115; if linked_753 == nil { p__5 = ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { p__5 = linked_753.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) } } else { p__5 = pattern__1 }; var tmp1 any; var root_823 any =
	A_arbace_box_plan_A_const_64.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = A_arbace_box_plan_A_const_122; var arg_827 any = p__5; if linked_824 == nil { tmp1 = ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { tmp1 = linked_824.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_823, arg_826, arg_827) }; if jrt.J2g_Truth(tmp1) {
		var root_828 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, A_arbace_box_plan_fail_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, nil, what__2, nil, pattern__1, nil)).Ref(); var arg_832 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_829 == nil { ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { linked_829.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) } }; var segs__6 any; var root_757 any = /*line :238:1*/A_arbace_box_plan_A_const_24.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_759 lang.IFn; if







	linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = p__5; var arg_761 any = A_arbace_box_plan_A_const_116; if linked_758 == nil { segs__6 = ifn_759.Invoke_O_O__O(arg_760, arg_761) } else { segs__6 = linked_758.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_757, arg_760, arg_761) }; var parent__7 any; var root_762 any = /*line :238:1*/A_arbace_box_plan_A_const_110.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_box_plan_dir_at_A_fn_class); var ifn_764 lang.IFn; if








	linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = d__0; var arg_766 any; var root_767 any = A_arbace_box_plan_A_const_117.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = Lit_6; var arg_771 any; var root_772 any = A_arbace_box_plan_A_const_118.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = segs__6; if linked_773 == nil { arg_771 = ifn_774.Invoke_O__O(arg_775) } else { arg_771 = linked_773.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_772, arg_775) }; if linked_768 == nil { arg_766 = ifn_769.Invoke_O_O__O(arg_770, arg_771) } else { arg_766 = linked_768.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_767, arg_770, arg_771) }; if linked_763 == nil { parent__7 = ifn_764.Invoke_O_O__O(arg_765, arg_766) } else { parent__7 = linked_763.(*A_arbace_box_plan_dir_at_A).Invoke_O_O_O__O(root_762, arg_765, arg_766) }; var vec__1305000111__8 any; if
	jrt.J2g_Truth(parent__7) { var tmp2 any; var root_776 any = A_arbace_box_plan_A_const_19.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, A_arbace_box_plan_entries_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = parent__7; if linked_777 == nil { tmp2 = ifn_778.Invoke_O__O(arg_779) } else { tmp2 = linked_777.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(root_776, arg_779) }; var tmp3 any = tmp2; var tmp4 any; var root_780 any = A_arbace_box_plan_A_const_119.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = segs__6; if linked_781 == nil { tmp4 = ifn_782.Invoke_O__O(arg_783) } else { tmp4 = linked_781.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_780, arg_783) }; vec__1305000111__8 = lang.RT_Get_O_O__O_NoInit(tmp3, tmp4) } else { vec__1305000111__8 = nil }; var k__9 any = /*line :238:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1305000111__8, lang.RT_IntCast_J__I_NoInit(0), nil); var h__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000111__8, lang.RT_IntCast_J__I_NoInit(1), nil); var e__11 any = vec__1305000111__8; var walk__12 any; var tmp5 any = A_arbace_box_plan_embed_files_walk__1305000114_A_New_O(all__4); var tmp6 *jrt.Class; var fncls__813 *jrt.Class = A_arbace_box_plan_embed_files_walk__1305000114_A_fn_class; if










	fncls__813 == nil { var fncls__813d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_box_plan_embed_files_walk__1305000114_A_fn_class = fncls__813d; tmp6 = fncls__813d } else { tmp6 = fncls__813 }; walk__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if




	lang.Util_Identical_O_O__Z_NoInit(e__11, nil) { var root_814 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, A_arbace_box_plan_fail_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, what__2, nil, pattern__1, nil)).Ref(); var arg_818 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_815 == nil { return ifn_816.Invoke_O_O__O(arg_817, arg_818) } else { return linked_815.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_814, arg_817, arg_818) } } else { if lang.Util_Equiv_O_O__Z_NoInit(k__9, A_arbace_box_plan_A_const_20) {
		var root_819 any = A_arbace_box_plan_A_const_44.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = lang.IFn_Cast(walk__12).Invoke_O_O__O(h__10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, p__5, nil)).Ref()); if linked_820 == nil { return ifn_821.Invoke_O__O(arg_822) } else { return linked_820.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_819, arg_822) } } else {
//line :254:1
			if A_arbace_box_plan_A_const_41 != nil { return lang.Tuple_Create_O__IPersistentVector(p__5) } else { return nil } } } }
//line :249:1
func A_arbace_box_plan_embed_files_walk__1305000114_A_New_O(p0 any) *A_arbace_box_plan_embed_files_walk__1305000114_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_embed_files_walk__1305000114_A{}; t.Ctor_O(p0); return t }
//line :249:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_A) Ctor_O(c__all any) { t.F_all = c__all }
//line :249:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_A) Invoke_O_O_O__O(self, h__1, prefix__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_New_O_O_O(self, prefix__2, t.F_all); var tmp3 *jrt.Class; var fncls__803 *jrt.Class = A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_fn_class; if fncls__803 == nil { var fncls__803d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_fn_class = fncls__803d; tmp3 = fncls__803d } else { tmp3 = fncls__803 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any; var root_804 any = A_arbace_box_plan_A_const_120.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_806 lang.IFn


	if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = A_arbace_box_plan_A_const_121.GetRawRoot__O(); var arg_808 any; var root_809 any = A_arbace_box_plan_A_const_19.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, A_arbace_box_plan_entries_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = h__1; if linked_810 == nil { arg_808 = ifn_811.Invoke_O__O(arg_812) } else { arg_808 = linked_810.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(root_809, arg_812) }; if linked_805 == nil { tmp5 = ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { tmp5 = linked_805.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_804, arg_807, arg_808) }
//line :250:1
	return tmp1.Invoke_O_O__O(tmp4, tmp5) }
//line :250:1
func A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :250:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A) Ctor_O_O_O(c__walk, c__prefix, c__all any) { t.F_walk = c__walk; t.F_prefix = c__prefix; t.F_all = c__all }
//line :250:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A) Invoke_O_O__O(self, p__1305000115__1 any) any { var vec__1305000117__2 any = p__1305000115__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000117__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000120__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000117__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any = t.F_all; if
															jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var root_789 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var or__1927000174__auto____8 any; var root_793 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = n__3; var arg_797 any = Lit_10; if linked_794 == nil { or__1927000174__auto____8 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { or__1927000174__auto____8 = linked_794.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }; if jrt.J2g_Truth(or__1927000174__auto____8) { arg_792 = or__1927000174__auto____8 } else { var root_798 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = n__3; var arg_802 any = Lit_11; if linked_799 == nil { arg_792 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { arg_792 = linked_799.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_798, arg_801, arg_802) } }; if linked_790 == nil { tmp1 = ifn_791.Invoke_O__O(arg_792) } else { tmp1 = linked_790.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_789, arg_792) } }; if jrt.J2g_Truth(tmp1) {
																if lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_box_plan_A_const_20) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp2.Invoke_O_O__O(eh__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__3, nil)).Ref()) } else { return lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__3)).Ref()) } } else {
//line :251:1
			return nil } }






func A_arbace_box_plan_package_info_A_New() *A_arbace_box_plan_package_info_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_box_plan_package_info_A) Ctor() {}
//line :258:1
func (t *A_arbace_box_plan_package_info_A) Invoke_O_O_O_O_O__O(self, cfg__0, match_QMARK___1, p__2, p__1305000127__3 any) any { var map__1305000128__5 any = p__1305000127__3; var map__1305000128__6 any; if lang.ISeq_InstanceOf(map__1305000128__5) { var tmp1 any; var root_833 any = A_arbace_box_plan_A_const_28.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = map__1305000128__5; if linked_834 == nil { tmp1 = ifn_835.Invoke_O__O(arg_836) } else { tmp1 = linked_834.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_833, arg_836) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_837 any = A_arbace_box_plan_A_const_29.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = map__1305000128__5; if linked_838 == nil { tmp2 = ifn_839.Invoke_O__O(arg_840) } else { tmp2 = linked_838.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_837, arg_840) }; map__1305000128__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_841 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = map__1305000128__5; if linked_842 == nil { tmp3 = ifn_843.Invoke_O__O(arg_844) } else { tmp3 = linked_842.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_841, arg_844) }; if jrt.J2g_Truth(tmp3) { var root_845 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = map__1305000128__5; if linked_846 == nil { map__1305000128__6 = ifn_847.Invoke_O__O(arg_848) } else { map__1305000128__6 = linked_846.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_845, arg_848) } } else { map__1305000128__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000128__6 = map__1305000128__5 }; var dir__7 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_20); var std__8 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_111); var lang__9 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_112); var path__10 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_114); var es__11 any; var root_849 any = A_arbace_box_plan_A_const_19.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, A_arbace_box_plan_entries_A_fn_class); var ifn_851 lang.IFn; if


	linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = dir__7; if linked_850 == nil { es__11 = ifn_851.Invoke_O__O(arg_852) } else { es__11 = linked_850.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(root_849, arg_852) }; var what__12 any = /*line :258:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__10)).Ref(); var files__13 any; var iter__1927001039__auto____13 any; var tmp4 any = A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_New_O(match_QMARK___1); var tmp5 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_fn_class; if




	fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_fn_class = fncls__1011d; tmp5 = fncls__1011d } else { tmp5 = fncls__1011 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp7 any; var root_1392 any = A_arbace_box_plan_A_const_120.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = A_arbace_box_plan_A_const_121.GetRawRoot__O(); var arg_1396 any = es__11; if linked_1393 == nil { tmp7 = ifn_1394.Invoke_O_O__O(arg_1395, arg_1396) } else { tmp7 = linked_1393.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1392, arg_1395, arg_1396) }; files__13 = tmp6.Invoke_O__O(tmp7); var go__14 any; var iter__1927001039__auto____14 any; var tmp8 any = /*line :258:1*/A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_New_O_O(match_QMARK___1, path__10); var tmp9 *jrt.Class; var fncls__1136 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_fn_class; if











	fncls__1136 == nil { var fncls__1136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_fn_class = fncls__1136d; tmp9 = fncls__1136d } else { tmp9 = fncls__1136 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); go__14 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(files__13); var others__15 any; var iter__1927001039__auto____15 any; var tmp10 any = /*line :258:1*/A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_New_O(match_QMARK___1); var tmp11 *jrt.Class; var fncls__1239 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_fn_class; if


















	fncls__1239 == nil { var fncls__1239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_fn_class = fncls__1239d; tmp11 = fncls__1239d } else { tmp11 = fncls__1239 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); others__15 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__13); var names__16 any; var root_1240 any = /*line :258:1*/A_arbace_box_plan_A_const_140.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1242 lang.IFn; if






















	linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var root_1244 any = A_arbace_box_plan_A_const_97.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any; var root_1249 any = A_arbace_box_plan_A_const_141.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = A_arbace_box_plan_A_const_101; var arg_1253 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); if linked_1250 == nil { arg_1247 = ifn_1251.Invoke_O_O__O(arg_1252, arg_1253) } else { arg_1247 = linked_1250.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1249, arg_1252, arg_1253) }; var arg_1248 any = go__14; if linked_1245 == nil { arg_1243 = ifn_1246.Invoke_O_O__O(arg_1247, arg_1248) } else { arg_1243 = linked_1245.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1244, arg_1247, arg_1248) }; if linked_1241 == nil { names__16 = ifn_1242.Invoke_O__O(arg_1243) } else { names__16 = linked_1241.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1240, arg_1243) }; var tmp12 any; var root_1397 any =
	A_arbace_box_plan_A_const_23.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = go__14; if linked_1398 == nil { tmp12 = ifn_1399.Invoke_O__O(arg_1400) } else { tmp12 = linked_1398.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1397, arg_1400) }; if jrt.J2g_Truth(tmp12) {
		var root_1401 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, A_arbace_box_plan_fail_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_67, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, what__12, nil, A_arbace_box_plan_A_const_32.Invoke_O__O(cfg__0), nil, A_arbace_box_plan_A_const_33.Invoke_O__O(cfg__0))).Ref(); var arg_1405 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_114, path__10)); if linked_1402 == nil { ifn_1403.Invoke_O_O__O(arg_1404, arg_1405) } else { linked_1402.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_1401, arg_1404, arg_1405) } }; if
	lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(names__16)), 1) {
		var root_1406 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, A_arbace_box_plan_fail_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_68, nil); var tmp14 any; var root_1411 any = A_arbace_box_plan_A_const_117.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = Lit_69; var arg_1415 any = names__16; if linked_1412 == nil { tmp14 = ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { tmp14 = linked_1412.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) }; arg_1409 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, what__12, nil, tmp14)).Ref(); var arg_1410 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_114, path__10)); if linked_1407 == nil { ifn_1408.Invoke_O_O__O(arg_1409, arg_1410) } else { linked_1407.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_1406, arg_1409, arg_1410) } }; var temp__1927000414__auto____17 any; var root_1416 any = /*line :258:1*/A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1418 lang.IFn; if



























	linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any; var root_1420 any = A_arbace_box_plan_A_const_109.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any; var tmp15 any = A_arbace_box_plan_package_info_fn__1305000184_A_New(); var tmp16 *jrt.Class; var fncls__1433 *jrt.Class = A_arbace_box_plan_package_info_fn__1305000184_A_fn_class; if fncls__1433 == nil { var fncls__1433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_box_plan_package_info_fn__1305000184_A_fn_class = fncls__1433d; tmp16 = fncls__1433d } else { tmp16 = fncls__1433 }; arg_1423 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_1424 any = others__15; if linked_1421 == nil { arg_1419 = ifn_1422.Invoke_O_O__O(arg_1423, arg_1424) } else { arg_1419 = linked_1421.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1420, arg_1423, arg_1424) }; if linked_1417 == nil { temp__1927000414__auto____17 = ifn_1418.Invoke_O__O(arg_1419) } else { temp__1927000414__auto____17 = linked_1417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1416, arg_1419) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var vec__1305000186__18 any = temp__1927000414__auto____17; var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000186__18, lang.RT_IntCast_J__I_NoInit(0), nil); var root_1434 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, A_arbace_box_plan_fail_A_fn_class); var ifn_1436 lang.IFn
		if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_71, nil, Lit_72), jrt.RefArrayOf(jrt.Object_class, nil, what__12, nil, n__19, nil)).Ref(); var arg_1438 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_114, path__10)); if linked_1435 == nil { ifn_1436.Invoke_O_O__O(arg_1437, arg_1438) } else { linked_1435.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_1434, arg_1437, arg_1438) } }; var patterns__17 any; var root_1254 any = /*line :258:1*/A_arbace_box_plan_A_const_140.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1256 lang.IFn; if





























	linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_96.GetRawRoot__O()); var tmp18 any; var root_1263 any = A_arbace_box_plan_A_const_141.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = A_arbace_box_plan_A_const_103; var arg_1267 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); if linked_1264 == nil { tmp18 = ifn_1265.Invoke_O_O__O(arg_1266, arg_1267) } else { tmp18 = linked_1264.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1263, arg_1266, arg_1267) }; arg_1257 = tmp17.Invoke_O_O__O(tmp18, go__14); if linked_1255 == nil { patterns__17 = ifn_1256.Invoke_O__O(arg_1257) } else { patterns__17 = linked_1255.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1254, arg_1257) }; var embed__18 any; var tmp19 any; var root_1268 any = /*line :258:1*/A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1270 lang.IFn; if






























	linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = patterns__17; if linked_1269 == nil { tmp19 = ifn_1270.Invoke_O__O(arg_1271) } else { tmp19 = linked_1269.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1268, arg_1271) }; if jrt.J2g_Truth(tmp19) { var tmp20 any = A_arbace_box_plan_A_const_142; var tmp21 any; var root_1272 any = A_arbace_box_plan_A_const_91.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1274 lang.IFn
		if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = lang.IFn_Cast(A_arbace_box_plan_A_const_143.GetRawRoot__O()).Invoke__O(); var arg_1276 any; var iter__1927001039__auto____18 any; var tmp22 any = A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_New_O_O(dir__7, what__12); var tmp23 *jrt.Class; var fncls__1350 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_fn_class; if fncls__1350 == nil { var fncls__1350d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_fn_class = fncls__1350d; tmp23 = fncls__1350d } else { tmp23 = fncls__1350 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); arg_1276 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(patterns__17); if linked_1273 == nil { tmp21 = ifn_1274.Invoke_O_O__O(arg_1275, arg_1276) } else { tmp21 = linked_1273.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1272, arg_1275, arg_1276) }
//line :289:1
		embed__18 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21)) } else { embed__18 = nil }; var tmp24 any = A_arbace_box_plan_A_const_114; var tmp25 any = A_arbace_box_plan_A_const_145; var tmp26 any; var root_1351 any = /*line :258:1*/A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1353 lang.IFn; if
































	linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = names__16; if linked_1352 == nil { tmp26 = ifn_1353.Invoke_O__O(arg_1354) } else { tmp26 = linked_1352.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1351, arg_1354) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_box_plan_A_const_111; var tmp29 any = A_arbace_box_plan_A_const_112; var tmp30 any; var or__1927000174__auto____19 any = lang__9; if jrt.J2g_Truth(or__1927000174__auto____19) { tmp30 = or__1927000174__auto____19 } else { tmp30 = A_arbace_box_plan_A_const_146.Invoke_O__O(cfg__0) }; var tmp31 any = tmp30; var tmp32 any = A_arbace_box_plan_A_const_147; var tmp33 any; var root_1355 any = /*line :258:1*/A_arbace_box_plan_A_const_148.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1357 lang.IFn; if

































	linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var arg_1359 any = go__14; if linked_1356 == nil { tmp33 = ifn_1357.Invoke_O_O__O(arg_1358, arg_1359) } else { tmp33 = linked_1356.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1355, arg_1358, arg_1359) }; var tmp34 any = tmp33; var tmp35 any = A_arbace_box_plan_A_const_149; var tmp36 any; var root_1360 any = /*line :258:1*/A_arbace_box_plan_A_const_148.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1362 lang.IFn; if

































	linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var arg_1364 any = others__15; if linked_1361 == nil { tmp36 = ifn_1362.Invoke_O_O__O(arg_1363, arg_1364) } else { tmp36 = linked_1361.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1360, arg_1363, arg_1364) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_box_plan_A_const_150; var tmp39 any; var root_1365 any = /*line :258:1*/A_arbace_box_plan_A_const_44.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1367 lang.IFn; if


































	linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any; var root_1369 any = A_arbace_box_plan_A_const_151.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any; var root_1373 any = A_arbace_box_plan_A_const_140.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var root_1377 any = A_arbace_box_plan_A_const_22.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = A_arbace_box_plan_A_const_152; var arg_1381 any; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_96.GetRawRoot__O()); var tmp41 any; var root_1387 any = A_arbace_box_plan_A_const_141.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = A_arbace_box_plan_A_const_102; var arg_1391 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); if linked_1388 == nil { tmp41 = ifn_1389.Invoke_O_O__O(arg_1390, arg_1391) } else { tmp41 = linked_1388.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1387, arg_1390, arg_1391) }; arg_1381 = tmp40.Invoke_O_O__O(tmp41, go__14); if linked_1378 == nil { arg_1376 = ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { arg_1376 = linked_1378.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) }; if linked_1374 == nil { arg_1372 = ifn_1375.Invoke_O__O(arg_1376) } else { arg_1372 = linked_1374.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1373, arg_1376) }; if linked_1370 == nil { arg_1368 = ifn_1371.Invoke_O__O(arg_1372) } else { arg_1368 = linked_1370.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1369, arg_1372) }; if linked_1366 == nil { tmp39 = ifn_1367.Invoke_O__O(arg_1368) } else { tmp39 = linked_1366.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1365, arg_1368) }; return /*line :258:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, path__10, tmp25, tmp27, tmp28, std__8, tmp29, tmp31, tmp32, tmp34, tmp35, tmp37, tmp38, tmp39, A_arbace_box_plan_A_const_153, embed__18, A_arbace_box_plan_A_const_20, dir__7)) }




func A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_New_O(p0 any) *A_arbace_box_plan_package_info_iter__1305000130__1305000134_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000130__1305000134_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_A) Ctor_O(c__match_QMARK_ any) { t.F_match_QMARK_ = c__match_QMARK_ }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_A) Invoke_O_O__O(self, s__1305000131__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_New_O_O_O(s__1305000131__1, t.F_match_QMARK_, self); var tmp2 *jrt.Class; var fncls__1010 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_fn_class; if fncls__1010 == nil { var fncls__1010d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_fn_class = fncls__1010d; tmp2 = fncls__1010d } else { tmp2 = fncls__1010 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :263:1
func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A) Ctor_O_O_O(c__s__1305000131, c__match_QMARK_, c__iter__1305000130 any) { t.F_s__1305000131 = c__s__1305000131; t.F_match_QMARK_ = c__match_QMARK_; t.F_iter__1305000130 = c__iter__1305000130 }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A) Invoke_O__O(self any) any { { var s__1305000131__1 any; var t_ any = t.F_s__1305000131; t.F_s__1305000131 = nil; s__1305000131__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_853 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = s__1305000131__1; if linked_854 == nil { temp__1927000414__auto____2 = ifn_855.Invoke_O__O(arg_856) } else { temp__1927000414__auto____2 = linked_854.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_853, arg_856) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000131__3 any = temp__1927000414__auto____2; var tmp1 any; var root_857 any = A_arbace_box_plan_A_const_123.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = s__1305000131__3; if linked_858 == nil { tmp1 = ifn_859.Invoke_O__O(arg_860) } else { tmp1 = linked_858.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_857, arg_860) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_861 any = A_arbace_box_plan_A_const_124.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__1305000131__3; if linked_862 == nil { c__1927001037__auto____4 = ifn_863.Invoke_O__O(arg_864) } else { c__1927001037__auto____4 = linked_862.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_861, arg_864) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000133__6 any; var root_865 any = A_arbace_box_plan_A_const_125.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_866 == nil { b__1305000133__6 = ifn_867.Invoke_O__O(arg_868) } else { b__1305000133__6 = linked_866.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_865, arg_868) }; var tmp2 any = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_New_O_O_I_O(b__1305000133__6, t.F_match_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__920 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_fn_class; if fncls__920 == nil { var fncls__920d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_fn_class = fncls__920d; tmp3 = fncls__920d } else { tmp3 = fncls__920 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_921 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any; var root_926 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = b__1305000133__6; if linked_927 == nil { arg_924 = ifn_928.Invoke_O__O(arg_929) } else { arg_924 = linked_927.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_926, arg_929) }; var arg_925 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1305000130); var tmp5 any; var root_930 any = A_arbace_box_plan_A_const_133.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = s__1305000131__3; if linked_931 == nil { tmp5 = ifn_932.Invoke_O__O(arg_933) } else { tmp5 = linked_931.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_930, arg_933) }; arg_925 = tmp4.Invoke_O__O(tmp5); if linked_922 == nil { return ifn_923.Invoke_O_O__O(arg_924, arg_925) } else { return linked_922.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_921, arg_924, arg_925) } } else { var root_934 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any; var root_939 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = b__1305000133__6; if linked_940 == nil { arg_937 = ifn_941.Invoke_O__O(arg_942) } else { arg_937 = linked_940.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_939, arg_942) }; var arg_938 any; if linked_935 == nil { return ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { return linked_935.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) } } } else { var vec__1305000144__4 any; var root_943 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = s__1305000131__3; if linked_944 == nil { vec__1305000144__4 = ifn_945.Invoke_O__O(arg_946) } else { vec__1305000144__4 = linked_944.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_943, arg_946) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000144__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000147__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000144__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000147__6, lang.RT_IntCast_J__I_NoInit(0), nil); var e__8 any = vec__1305000147__6; var tmp6 any; var and__1927000168__auto____9 any; var root_947 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_949 lang.IFn
															if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = k__7; var arg_951 any = A_arbace_box_plan_A_const_20; if linked_948 == nil { and__1927000168__auto____9 = ifn_949.Invoke_O_O__O(arg_950, arg_951) } else { and__1927000168__auto____9 = linked_948.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_947, arg_950, arg_951) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_952 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any; var root_956 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = n__5; var arg_960 any = Lit_10; if linked_957 == nil { arg_955 = ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { arg_955 = linked_957.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }; if linked_953 == nil { and__1927000168__auto____10 = ifn_954.Invoke_O__O(arg_955) } else { and__1927000168__auto____10 = linked_953.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_952, arg_955) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var root_961 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any; var root_965 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = n__5; var arg_969 any = Lit_11; if linked_966 == nil { arg_964 = ifn_967.Invoke_O_O__O(arg_968, arg_969) } else { arg_964 = linked_966.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_965, arg_968, arg_969) }; if linked_962 == nil { tmp6 = ifn_963.Invoke_O__O(arg_964) } else { tmp6 = linked_962.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_961, arg_964) } } else { tmp6 = and__1927000168__auto____10 } } else { tmp6 = and__1927000168__auto____9 }
//line :263:1
	if jrt.J2g_Truth(tmp6) { var ext__9 any; var root_970 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_972 lang.IFn

		if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any; var root_974 any = A_arbace_box_plan_A_const_64.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = A_arbace_box_plan_A_const_126; var arg_978 any = n__5; if linked_975 == nil { arg_973 = ifn_976.Invoke_O_O__O(arg_977, arg_978) } else { arg_973 = linked_975.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_974, arg_977, arg_978) }; if linked_971 == nil { ext__9 = ifn_972.Invoke_O__O(arg_973) } else { ext__9 = linked_971.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_970, arg_973) }
//line :263:1
		var tmp7 any; var and__1927000168__auto____10_2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_134).Invoke_O__O(ext__9)


		if jrt.J2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11 any; var root_979 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_981 lang.IFn
			if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var root_983 any = A_arbace_box_plan_A_const_128.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = n__5; var arg_987 any = Lit_76; if linked_984 == nil { arg_982 = ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { arg_982 = linked_984.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_983, arg_986, arg_987) }; if linked_980 == nil { and__1927000168__auto____11 = ifn_981.Invoke_O__O(arg_982) } else { and__1927000168__auto____11 = linked_980.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_979, arg_982) }
//line :266:1
			if jrt.J2g_Truth(and__1927000168__auto____11) {

				var root_988 any = A_arbace_box_plan_A_const_129.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, A_arbace_box_plan_name_ok_QMARK__A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = t.F_match_QMARK_; var arg_992 any = n__5; if linked_989 == nil { tmp7 = ifn_990.Invoke_O_O__O(arg_991, arg_992) } else { tmp7 = linked_989.(*A_arbace_box_plan_name_ok_QMARK__A).Invoke_O_O_O__O(root_988, arg_991, arg_992) } } else {
//line :266:1
					tmp7 = and__1927000168__auto____11 } } else { tmp7 = and__1927000168__auto____10_2 }
//line :263:1
		if jrt.J2g_Truth(tmp7) { var root_993 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = lang.Tuple_Create_O_O_O__IPersistentVector(n__5, ext__9, e__8); var arg_997 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1305000130); var tmp9 any; var root_998 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = s__1305000131__3; if linked_999 == nil { tmp9 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp9 = linked_999.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_998, arg_1001) }; arg_997 = tmp8.Invoke_O__O(tmp9); if linked_994 == nil { return ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { return linked_994.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_993, arg_996, arg_997) } } else { var tmp10 any; var root_1002 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = s__1305000131__3; if linked_1003 == nil { tmp10 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp10 = linked_1003.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1002, arg_1005) }; s__1305000131__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1006 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = s__1305000131__3; if linked_1007 == nil { tmp11 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp11 = linked_1007.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1006, arg_1009) }; s__1305000131__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :263:1
func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A) Ctor_O_O_I_O(c__b__1305000133, c__match_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1305000133 = c__b__1305000133; t.F_match_QMARK_ = c__match_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A) Invoke_O__O(self any) any { { var i__1305000132__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000132__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000137__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000132__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000137__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000140__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000137__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000140__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = vec__1305000140__4; var tmp2 any; var and__1927000168__auto____7 any; var root_869 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_871 lang.IFn
																if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = k__5; var arg_873 any = A_arbace_box_plan_A_const_20; if linked_870 == nil { and__1927000168__auto____7 = ifn_871.Invoke_O_O__O(arg_872, arg_873) } else { and__1927000168__auto____7 = linked_870.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_869, arg_872, arg_873) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_874 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any; var root_878 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = n__3; var arg_882 any = Lit_10; if linked_879 == nil { arg_877 = ifn_880.Invoke_O_O__O(arg_881, arg_882) } else { arg_877 = linked_879.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_878, arg_881, arg_882) }; if linked_875 == nil { and__1927000168__auto____8 = ifn_876.Invoke_O__O(arg_877) } else { and__1927000168__auto____8 = linked_875.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_874, arg_877) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_883 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any; var root_887 any = A_arbace_box_plan_A_const_63.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = n__3; var arg_891 any = Lit_11; if linked_888 == nil { arg_886 = ifn_889.Invoke_O_O__O(arg_890, arg_891) } else { arg_886 = linked_888.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_887, arg_890, arg_891) }; if linked_884 == nil { tmp2 = ifn_885.Invoke_O__O(arg_886) } else { tmp2 = linked_884.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_883, arg_886) } } else { tmp2 = and__1927000168__auto____8 } } else { tmp2 = and__1927000168__auto____7 }
//line :263:1
	if jrt.J2g_Truth(tmp2) { var ext__7 any; var root_892 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_894 lang.IFn

		if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any; var root_896 any = A_arbace_box_plan_A_const_64.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = A_arbace_box_plan_A_const_126; var arg_900 any = n__3; if linked_897 == nil { arg_895 = ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { arg_895 = linked_897.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) }; if linked_893 == nil { ext__7 = ifn_894.Invoke_O__O(arg_895) } else { ext__7 = linked_893.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_892, arg_895) }
//line :263:1
		var tmp3 any; var and__1927000168__auto____8_2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_127).Invoke_O__O(ext__7)


		if jrt.J2g_Truth(and__1927000168__auto____8_2) { var and__1927000168__auto____9 any; var root_901 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_903 lang.IFn
			if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var root_905 any = A_arbace_box_plan_A_const_128.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = n__3; var arg_909 any = Lit_76; if linked_906 == nil { arg_904 = ifn_907.Invoke_O_O__O(arg_908, arg_909) } else { arg_904 = linked_906.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_905, arg_908, arg_909) }; if linked_902 == nil { and__1927000168__auto____9 = ifn_903.Invoke_O__O(arg_904) } else { and__1927000168__auto____9 = linked_902.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_901, arg_904) }
//line :266:1
			if jrt.J2g_Truth(and__1927000168__auto____9) {

				var root_910 any = A_arbace_box_plan_A_const_129.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, A_arbace_box_plan_name_ok_QMARK__A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = t.F_match_QMARK_; var arg_914 any = n__3; if linked_911 == nil { tmp3 = ifn_912.Invoke_O_O__O(arg_913, arg_914) } else { tmp3 = linked_911.(*A_arbace_box_plan_name_ok_QMARK__A).Invoke_O_O_O__O(root_910, arg_913, arg_914) } } else {
//line :266:1
					tmp3 = and__1927000168__auto____9 } } else { tmp3 = and__1927000168__auto____8_2 }
//line :263:1
		if jrt.J2g_Truth(tmp3) { var root_915 any = A_arbace_box_plan_A_const_130.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = t.F_b__1305000133; var arg_919 any = lang.Tuple_Create_O_O_O__IPersistentVector(n__3, ext__7, e__6); if linked_916 == nil { ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { linked_916.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_915, arg_918, arg_919) }; i__1305000132__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000132__1); continue L1 } else { i__1305000132__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000132__1); continue L1 } } else { i__1305000132__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000132__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_New_O_O(p0, p1 any) *A_arbace_box_plan_package_info_iter__1305000152__1305000156_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000152__1305000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_A) Ctor_O_O(c__match_QMARK_, c__path any) { t.F_match_QMARK_ = c__match_QMARK_; t.F_path = c__path }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_A) Invoke_O_O__O(self, s__1305000153__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_New_O_O_O_O(s__1305000153__1, t.F_match_QMARK_, t.F_path, self); var tmp2 *jrt.Class; var fncls__1135 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_fn_class; if fncls__1135 == nil { var fncls__1135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_fn_class = fncls__1135d; tmp2 = fncls__1135d } else { tmp2 = fncls__1135 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :270:1
func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A) Ctor_O_O_O_O(c__s__1305000153, c__match_QMARK_, c__path, c__iter__1305000152 any) { t.F_s__1305000153 = c__s__1305000153; t.F_match_QMARK_ = c__match_QMARK_; t.F_path = c__path; t.F_iter__1305000152 = c__iter__1305000152 }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A) Invoke_O__O(self any) any { { var s__1305000153__1 any; var t_ any = t.F_s__1305000153; t.F_s__1305000153 = nil; s__1305000153__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1012 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = s__1305000153__1; if linked_1013 == nil { temp__1927000414__auto____2 = ifn_1014.Invoke_O__O(arg_1015) } else { temp__1927000414__auto____2 = linked_1013.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1012, arg_1015) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000153__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1016 any = A_arbace_box_plan_A_const_123.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = s__1305000153__3; if linked_1017 == nil { tmp1 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp1 = linked_1017.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1016, arg_1019) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1020 any = A_arbace_box_plan_A_const_124.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = s__1305000153__3; if linked_1021 == nil { c__1927001037__auto____4 = ifn_1022.Invoke_O__O(arg_1023) } else { c__1927001037__auto____4 = linked_1021.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1020, arg_1023) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000155__6 any; var root_1024 any = A_arbace_box_plan_A_const_125.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1025 == nil { b__1305000155__6 = ifn_1026.Invoke_O__O(arg_1027) } else { b__1305000155__6 = linked_1025.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1024, arg_1027) }; var tmp2 any = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_New_O_O_O_I_O(b__1305000155__6, t.F_match_QMARK_, t.F_path, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1060 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_fn_class; if fncls__1060 == nil { var fncls__1060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_fn_class = fncls__1060d; tmp3 = fncls__1060d } else { tmp3 = fncls__1060 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1061 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var root_1066 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = b__1305000155__6; if linked_1067 == nil { arg_1064 = ifn_1068.Invoke_O__O(arg_1069) } else { arg_1064 = linked_1067.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1066, arg_1069) }; var arg_1065 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1305000152); var tmp5 any; var root_1070 any = A_arbace_box_plan_A_const_133.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = s__1305000153__3; if linked_1071 == nil { tmp5 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp5 = linked_1071.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1070, arg_1073) }; arg_1065 = tmp4.Invoke_O__O(tmp5); if linked_1062 == nil { return ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { return linked_1062.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) } } else { var root_1074 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any; var root_1079 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = b__1305000155__6; if linked_1080 == nil { arg_1077 = ifn_1081.Invoke_O__O(arg_1082) } else { arg_1077 = linked_1080.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1079, arg_1082) }; var arg_1078 any; if linked_1075 == nil { return ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { return linked_1075.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) } } } else { var vec__1305000163__4 any; var root_1083 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = s__1305000153__3; if linked_1084 == nil { vec__1305000163__4 = ifn_1085.Invoke_O__O(arg_1086) } else { vec__1305000163__4 = linked_1084.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1083, arg_1086) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000163__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000163__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000163__4, lang.RT_IntCast_J__I_NoInit(2), nil); if lang.Util_Equiv_O_O__Z_NoInit(ext__6, Lit_79) { var s__8 any; var root_1087 any = A_arbace_box_plan_A_const_105.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, A_arbace_box_plan_text_A_fn_class); var ifn_1089 lang.IFn
															if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = e__7; if linked_1088 == nil { s__8 = ifn_1089.Invoke_O__O(arg_1090) } else { s__8 = linked_1088.(*A_arbace_box_plan_text_A).Invoke_O_O__O(root_1087, arg_1090) }
//line :270:1
	var b__9 any; var root_1091 any = A_arbace_box_plan_A_const_135.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, A_arbace_box_plan_header_build_A_fn_class); var ifn_1093 lang.IFn

	if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = s__8; if linked_1092 == nil { b__9 = ifn_1093.Invoke_O__O(arg_1094) } else { b__9 = linked_1092.(*A_arbace_box_plan_header_build_A).Invoke_O_O__O(root_1091, arg_1094) }
//line :270:1
	var tmp6 any; var or__1927000174__auto____10 bool = lang.Util_Identical_O_O__Z_NoInit(b__9, nil)


	if or__1927000174__auto____10 { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____10).Ref() } else { var root_1095 any = A_arbace_box_plan_A_const_136.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, A_arbace_box_plan_eval_expr_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = t.F_match_QMARK_; var arg_1099 any = b__9; if linked_1096 == nil { tmp6 = ifn_1097.Invoke_O_O__O(arg_1098, arg_1099) } else { tmp6 = linked_1096.(*A_arbace_box_plan_eval_expr_A).Invoke_O_O_O__O(root_1095, arg_1098, arg_1099) } }
//line :270:1
	if jrt.J2g_Truth(tmp6) { var info__10 any; var root_1100 any = A_arbace_box_plan_A_const_137.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, A_arbace_box_plan_go_info_A_fn_class); var ifn_1102 lang.IFn



		if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = s__8; var arg_1104 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, t.F_path, nil, n__5)).Ref(); if linked_1101 == nil { info__10 = ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { info__10 = linked_1101.(*A_arbace_box_plan_go_info_A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104) }
//line :270:1
		var tmp7 any; var root_1105 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1107 lang.IFn




		if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var root_1109 any = A_arbace_box_plan_A_const_94.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = A_arbace_box_plan_A_const_139; var arg_1113 any = A_arbace_box_plan_A_const_102.Invoke_O__O(info__10); if linked_1110 == nil { arg_1108 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { arg_1108 = linked_1110.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }; if linked_1106 == nil { tmp7 = ifn_1107.Invoke_O__O(arg_1108) } else { tmp7 = linked_1106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1105, arg_1108) }
//line :270:1
		if jrt.J2g_Truth(tmp7) { var root_1114 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, info__10); var arg_1118 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1305000152); var tmp9 any; var root_1119 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = s__1305000153__3; if linked_1120 == nil { tmp9 = ifn_1121.Invoke_O__O(arg_1122) } else { tmp9 = linked_1120.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1119, arg_1122) }; arg_1118 = tmp8.Invoke_O__O(tmp9); if linked_1115 == nil { return ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { return linked_1115.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) } } else { var tmp10 any; var root_1123 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = s__1305000153__3; if linked_1124 == nil { tmp10 = ifn_1125.Invoke_O__O(arg_1126) } else { tmp10 = linked_1124.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1123, arg_1126) }; s__1305000153__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1127 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = s__1305000153__3; if linked_1128 == nil { tmp11 = ifn_1129.Invoke_O__O(arg_1130) } else { tmp11 = linked_1128.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1127, arg_1130) }; s__1305000153__1 = tmp11; continue L1 } } else { var tmp12 any; var root_1131 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = s__1305000153__3; if linked_1132 == nil { tmp12 = ifn_1133.Invoke_O__O(arg_1134) } else { tmp12 = linked_1132.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1131, arg_1134) }; s__1305000153__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :270:1
func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A) Ctor_O_O_O_I_O(c__b__1305000155, c__match_QMARK_, c__path any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1305000155 = c__b__1305000155; t.F_match_QMARK_ = c__match_QMARK_; t.F_path = c__path; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A) Invoke_O__O(self any) any { { var i__1305000154__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000159__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000154__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000159__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000159__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000159__2, lang.RT_IntCast_J__I_NoInit(2), nil); if lang.Util_Equiv_O_O__Z_NoInit(ext__4, Lit_79) { var s__6 any; var root_1028 any = A_arbace_box_plan_A_const_105.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, A_arbace_box_plan_text_A_fn_class); var ifn_1030 lang.IFn
																if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = e__5; if linked_1029 == nil { s__6 = ifn_1030.Invoke_O__O(arg_1031) } else { s__6 = linked_1029.(*A_arbace_box_plan_text_A).Invoke_O_O__O(root_1028, arg_1031) }
//line :270:1
	var b__7 any; var root_1032 any = A_arbace_box_plan_A_const_135.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, A_arbace_box_plan_header_build_A_fn_class); var ifn_1034 lang.IFn

	if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = s__6; if linked_1033 == nil { b__7 = ifn_1034.Invoke_O__O(arg_1035) } else { b__7 = linked_1033.(*A_arbace_box_plan_header_build_A).Invoke_O_O__O(root_1032, arg_1035) }
//line :270:1
	var tmp2 any; var or__1927000174__auto____8 bool = lang.Util_Identical_O_O__Z_NoInit(b__7, nil)


	if or__1927000174__auto____8 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_1036 any = A_arbace_box_plan_A_const_136.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, A_arbace_box_plan_eval_expr_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = t.F_match_QMARK_; var arg_1040 any = b__7; if linked_1037 == nil { tmp2 = ifn_1038.Invoke_O_O__O(arg_1039, arg_1040) } else { tmp2 = linked_1037.(*A_arbace_box_plan_eval_expr_A).Invoke_O_O_O__O(root_1036, arg_1039, arg_1040) } }
//line :270:1
	if jrt.J2g_Truth(tmp2) { var info__8 any; var root_1041 any = A_arbace_box_plan_A_const_137.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, A_arbace_box_plan_go_info_A_fn_class); var ifn_1043 lang.IFn



		if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = s__6; var arg_1045 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, t.F_path, nil, n__3)).Ref(); if linked_1042 == nil { info__8 = ifn_1043.Invoke_O_O__O(arg_1044, arg_1045) } else { info__8 = linked_1042.(*A_arbace_box_plan_go_info_A).Invoke_O_O_O__O(root_1041, arg_1044, arg_1045) }
//line :270:1
		var tmp3 any; var root_1046 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1048 lang.IFn




		if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any; var root_1050 any = A_arbace_box_plan_A_const_94.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = A_arbace_box_plan_A_const_138; var arg_1054 any = A_arbace_box_plan_A_const_102.Invoke_O__O(info__8); if linked_1051 == nil { arg_1049 = ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { arg_1049 = linked_1051.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) }; if linked_1047 == nil { tmp3 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp3 = linked_1047.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1046, arg_1049) }
//line :270:1
		if jrt.J2g_Truth(tmp3) { var root_1055 any = A_arbace_box_plan_A_const_130.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = t.F_b__1305000155; var arg_1059 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, info__8); if linked_1056 == nil { ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { linked_1056.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) }; i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } else { i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } } else { i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } } else { i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_New_O(p0 any) *A_arbace_box_plan_package_info_iter__1305000168__1305000172_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000168__1305000172_A{}; t.Ctor_O(p0); return t }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_A) Ctor_O(c__match_QMARK_ any) { t.F_match_QMARK_ = c__match_QMARK_ }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_A) Invoke_O_O__O(self, s__1305000169__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_New_O_O_O(self, t.F_match_QMARK_, s__1305000169__1); var tmp2 *jrt.Class; var fncls__1238 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_fn_class; if fncls__1238 == nil { var fncls__1238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_fn_class = fncls__1238d; tmp2 = fncls__1238d } else { tmp2 = fncls__1238 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :277:1
func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A) Ctor_O_O_O(c__iter__1305000168, c__match_QMARK_, c__s__1305000169 any) { t.F_iter__1305000168 = c__iter__1305000168; t.F_match_QMARK_ = c__match_QMARK_; t.F_s__1305000169 = c__s__1305000169 }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A) Invoke_O__O(self any) any { { var s__1305000169__1 any; var t_ any = t.F_s__1305000169; t.F_s__1305000169 = nil; s__1305000169__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1137 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = s__1305000169__1; if linked_1138 == nil { temp__1927000414__auto____2 = ifn_1139.Invoke_O__O(arg_1140) } else { temp__1927000414__auto____2 = linked_1138.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1137, arg_1140) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000169__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1141 any = A_arbace_box_plan_A_const_123.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1143 lang.IFn; if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = s__1305000169__3; if linked_1142 == nil { tmp1 = ifn_1143.Invoke_O__O(arg_1144) } else { tmp1 = linked_1142.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1141, arg_1144) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1145 any = A_arbace_box_plan_A_const_124.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = s__1305000169__3; if linked_1146 == nil { c__1927001037__auto____4 = ifn_1147.Invoke_O__O(arg_1148) } else { c__1927001037__auto____4 = linked_1146.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1145, arg_1148) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000171__6 any; var root_1149 any = A_arbace_box_plan_A_const_125.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1150 == nil { b__1305000171__6 = ifn_1151.Invoke_O__O(arg_1152) } else { b__1305000171__6 = linked_1150.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1149, arg_1152) }; var tmp2 any = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_New_O_I_O_O(t.F_match_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4, b__1305000171__6); var tmp3 *jrt.Class; var fncls__1176 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_fn_class; if fncls__1176 == nil { var fncls__1176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_fn_class = fncls__1176d; tmp3 = fncls__1176d } else { tmp3 = fncls__1176 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1177 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any; var root_1182 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = b__1305000171__6; if linked_1183 == nil { arg_1180 = ifn_1184.Invoke_O__O(arg_1185) } else { arg_1180 = linked_1183.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1182, arg_1185) }; var arg_1181 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1305000168); var tmp5 any; var root_1186 any = A_arbace_box_plan_A_const_133.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = s__1305000169__3; if linked_1187 == nil { tmp5 = ifn_1188.Invoke_O__O(arg_1189) } else { tmp5 = linked_1187.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1186, arg_1189) }; arg_1181 = tmp4.Invoke_O__O(tmp5); if linked_1178 == nil { return ifn_1179.Invoke_O_O__O(arg_1180, arg_1181) } else { return linked_1178.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1177, arg_1180, arg_1181) } } else { var root_1190 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any; var root_1195 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = b__1305000171__6; if linked_1196 == nil { arg_1193 = ifn_1197.Invoke_O__O(arg_1198) } else { arg_1193 = linked_1196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1195, arg_1198) }; var arg_1194 any; if linked_1191 == nil { return ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { return linked_1191.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) } } } else { var vec__1305000179__4 any; var root_1199 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = s__1305000169__3; if linked_1200 == nil { vec__1305000179__4 = ifn_1201.Invoke_O__O(arg_1202) } else { vec__1305000179__4 = linked_1200.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1199, arg_1202) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000179__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000179__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000179__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 any; var root_1203 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = ext__6; var arg_1207 any = Lit_79; if linked_1204 == nil { tmp6 = ifn_1205.Invoke_O_O__O(arg_1206, arg_1207) } else { tmp6 = linked_1204.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1203, arg_1206, arg_1207) }; if jrt.J2g_Truth(tmp6) { var b__8 any; var root_1208 any = A_arbace_box_plan_A_const_135.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, A_arbace_box_plan_header_build_A_fn_class); var ifn_1210 lang.IFn
															if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any; var root_1212 any = A_arbace_box_plan_A_const_105.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, A_arbace_box_plan_text_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = e__7; if linked_1213 == nil { arg_1211 = ifn_1214.Invoke_O__O(arg_1215) } else { arg_1211 = linked_1213.(*A_arbace_box_plan_text_A).Invoke_O_O__O(root_1212, arg_1215) }; if linked_1209 == nil { b__8 = ifn_1210.Invoke_O__O(arg_1211) } else { b__8 = linked_1209.(*A_arbace_box_plan_header_build_A).Invoke_O_O__O(root_1208, arg_1211) }
//line :277:1
	var tmp7 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(b__8, nil)

	if or__1927000174__auto____9 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1216 any = A_arbace_box_plan_A_const_136.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, A_arbace_box_plan_eval_expr_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = t.F_match_QMARK_; var arg_1220 any = b__8; if linked_1217 == nil { tmp7 = ifn_1218.Invoke_O_O__O(arg_1219, arg_1220) } else { tmp7 = linked_1217.(*A_arbace_box_plan_eval_expr_A).Invoke_O_O_O__O(root_1216, arg_1219, arg_1220) } }
//line :277:1
	if jrt.J2g_Truth(tmp7) { var root_1221 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, ext__6); var arg_1225 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1305000168); var tmp9 any; var root_1226 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = s__1305000169__3; if linked_1227 == nil { tmp9 = ifn_1228.Invoke_O__O(arg_1229) } else { tmp9 = linked_1227.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1226, arg_1229) }; arg_1225 = tmp8.Invoke_O__O(tmp9); if linked_1222 == nil { return ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { return linked_1222.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) } } else { var tmp10 any; var root_1230 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = s__1305000169__3; if linked_1231 == nil { tmp10 = ifn_1232.Invoke_O__O(arg_1233) } else { tmp10 = linked_1231.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1230, arg_1233) }; s__1305000169__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1234 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = s__1305000169__3; if linked_1235 == nil { tmp11 = ifn_1236.Invoke_O__O(arg_1237) } else { tmp11 = linked_1235.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1234, arg_1237) }; s__1305000169__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :277:1
func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A) Ctor_O_I_O_O(c__match_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1305000171 any) { t.F_match_QMARK_ = c__match_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1305000171 = c__b__1305000171 }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A) Invoke_O__O(self any) any { { var i__1305000170__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000170__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000175__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000170__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000175__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000175__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000175__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 any; var root_1153 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = ext__4; var arg_1157 any = Lit_79; if linked_1154 == nil { tmp2 = ifn_1155.Invoke_O_O__O(arg_1156, arg_1157) } else { tmp2 = linked_1154.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1153, arg_1156, arg_1157) }; if jrt.J2g_Truth(tmp2) { var b__6 any; var root_1158 any = A_arbace_box_plan_A_const_135.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, A_arbace_box_plan_header_build_A_fn_class); var ifn_1160 lang.IFn
																if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var root_1162 any = A_arbace_box_plan_A_const_105.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, A_arbace_box_plan_text_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = e__5; if linked_1163 == nil { arg_1161 = ifn_1164.Invoke_O__O(arg_1165) } else { arg_1161 = linked_1163.(*A_arbace_box_plan_text_A).Invoke_O_O__O(root_1162, arg_1165) }; if linked_1159 == nil { b__6 = ifn_1160.Invoke_O__O(arg_1161) } else { b__6 = linked_1159.(*A_arbace_box_plan_header_build_A).Invoke_O_O__O(root_1158, arg_1161) }
//line :277:1
	var tmp3 any; var or__1927000174__auto____7 bool = lang.Util_Identical_O_O__Z_NoInit(b__6, nil)

	if or__1927000174__auto____7 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var root_1166 any = A_arbace_box_plan_A_const_136.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, A_arbace_box_plan_eval_expr_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = t.F_match_QMARK_; var arg_1170 any = b__6; if linked_1167 == nil { tmp3 = ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { tmp3 = linked_1167.(*A_arbace_box_plan_eval_expr_A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) } }
//line :277:1
	if jrt.J2g_Truth(tmp3) { var root_1171 any = A_arbace_box_plan_A_const_130.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = t.F_b__1305000171; var arg_1175 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, ext__4); if linked_1172 == nil { ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { linked_1172.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }; i__1305000170__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000170__1); continue L1 } else { i__1305000170__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000170__1); continue L1 } } else { i__1305000170__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000170__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_box_plan_package_info_fn__1305000184_A_New() *A_arbace_box_plan_package_info_fn__1305000184_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_fn__1305000184_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_box_plan_package_info_fn__1305000184_A) Ctor() {}
//line :286:1
func (t *A_arbace_box_plan_package_info_fn__1305000184_A) Invoke_O_O__O(self, p1__1305000126_SHARP___1 any) any { var root_1425 any = A_arbace_box_plan_A_const_57.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_154); var tmp2 any; var root_1429 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = p1__1305000126_SHARP___1; if linked_1430 == nil { tmp2 = ifn_1431.Invoke_O__O(arg_1432) } else { tmp2 = linked_1430.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1429, arg_1432) }; arg_1428 = tmp1.Invoke_O__O(tmp2); if linked_1426 == nil { return ifn_1427.Invoke_O__O(arg_1428) } else { return linked_1426.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1425, arg_1428) } }



func A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_New_O_O(p0, p1 any) *A_arbace_box_plan_package_info_iter__1305000189__1305000193_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000189__1305000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_A) Ctor_O_O(c__dir, c__what any) { t.F_dir = c__dir; t.F_what = c__what }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_A) Invoke_O_O__O(self, s__1305000190__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_New_O_O_O_O(self, t.F_dir, s__1305000190__1, t.F_what); var tmp2 *jrt.Class; var fncls__1349 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_fn_class; if fncls__1349 == nil { var fncls__1349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_fn_class = fncls__1349d; tmp2 = fncls__1349d } else { tmp2 = fncls__1349 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :290:1
func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A) Ctor_O_O_O_O(c__iter__1305000189, c__dir, c__s__1305000190, c__what any) { t.F_iter__1305000189 = c__iter__1305000189; t.F_dir = c__dir; t.F_s__1305000190 = c__s__1305000190; t.F_what = c__what }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A) Invoke_O__O(self any) any { { var s__1305000190__1 any; var t_ any = t.F_s__1305000190; t.F_s__1305000190 = nil; s__1305000190__1 = t_; for { var temp__1927000414__auto____2 any; var root_1280 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = s__1305000190__1; if linked_1281 == nil { temp__1927000414__auto____2 = ifn_1282.Invoke_O__O(arg_1283) } else { temp__1927000414__auto____2 = linked_1281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1280, arg_1283) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000190__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1284 any = A_arbace_box_plan_A_const_123.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = s__1305000190__3; if linked_1285 == nil { tmp1 = ifn_1286.Invoke_O__O(arg_1287) } else { tmp1 = linked_1285.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1284, arg_1287) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1288 any = A_arbace_box_plan_A_const_124.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = s__1305000190__3; if linked_1289 == nil { c__1927001037__auto____4 = ifn_1290.Invoke_O__O(arg_1291) } else { c__1927001037__auto____4 = linked_1289.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1288, arg_1291) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000192__6 any; var root_1292 any = A_arbace_box_plan_A_const_125.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1293 == nil { b__1305000192__6 = ifn_1294.Invoke_O__O(arg_1295) } else { b__1305000192__6 = linked_1293.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1292, arg_1295) }; var tmp2 any = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_New_O_O_I_O_O(t.F_dir, t.F_what, size__1927001038__auto____5, b__1305000192__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1307 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_fn_class; if fncls__1307 == nil { var fncls__1307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_fn_class = fncls__1307d; tmp3 = fncls__1307d } else { tmp3 = fncls__1307 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1308 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any; var root_1313 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = b__1305000192__6; if linked_1314 == nil { arg_1311 = ifn_1315.Invoke_O__O(arg_1316) } else { arg_1311 = linked_1314.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1313, arg_1316) }; var arg_1312 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1305000189); var tmp5 any; var root_1317 any = A_arbace_box_plan_A_const_133.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = s__1305000190__3; if linked_1318 == nil { tmp5 = ifn_1319.Invoke_O__O(arg_1320) } else { tmp5 = linked_1318.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1317, arg_1320) }; arg_1312 = tmp4.Invoke_O__O(tmp5); if linked_1309 == nil { return ifn_1310.Invoke_O_O__O(arg_1311, arg_1312) } else { return linked_1309.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1308, arg_1311, arg_1312) } } else { var root_1321 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any; var root_1326 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = b__1305000192__6; if linked_1327 == nil { arg_1324 = ifn_1328.Invoke_O__O(arg_1329) } else { arg_1324 = linked_1327.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1326, arg_1329) }; var arg_1325 any; if linked_1322 == nil { return ifn_1323.Invoke_O_O__O(arg_1324, arg_1325) } else { return linked_1322.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1321, arg_1324, arg_1325) } } } else { var pt__4 any; var root_1330 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = s__1305000190__3; if linked_1331 == nil { pt__4 = ifn_1332.Invoke_O__O(arg_1333) } else { pt__4 = linked_1331.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1330, arg_1333) }; var root_1334 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any; var tmp6 any; var root_1339 any = A_arbace_box_plan_A_const_144.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, A_arbace_box_plan_embed_files_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = t.F_dir; var arg_1343 any = pt__4; var arg_1344 any = t.F_what; if linked_1340 == nil { tmp6 = ifn_1341.Invoke_O_O_O__O(arg_1342, arg_1343, arg_1344) } else { tmp6 = linked_1340.(*A_arbace_box_plan_embed_files_A).Invoke_O_O_O_O__O(root_1339, arg_1342, arg_1343, arg_1344) }; arg_1337 = lang.Tuple_Create_O_O__IPersistentVector(pt__4, tmp6); var arg_1338 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1305000189); var tmp8 any; var root_1345 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = s__1305000190__3; if linked_1346 == nil { tmp8 = ifn_1347.Invoke_O__O(arg_1348) } else { tmp8 = linked_1346.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1345, arg_1348) }; arg_1338 = tmp7.Invoke_O__O(tmp8); if linked_1335 == nil { return ifn_1336.Invoke_O_O__O(arg_1337, arg_1338) } else { return linked_1335.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1334, arg_1337, arg_1338) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :290:1
func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A) Ctor_O_O_I_O_O(c__dir, c__what any, c__size__1927001038__auto__ int32, c__b__1305000192, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_what = c__what; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1305000192 = c__b__1305000192; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A) Invoke_O__O(self any) any { { var i__1305000191__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pt__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000191__1)); var root_1296 any = A_arbace_box_plan_A_const_130.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = t.F_b__1305000192; var arg_1300 any; var tmp2 any; var root_1301 any = A_arbace_box_plan_A_const_144.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, A_arbace_box_plan_embed_files_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = t.F_dir; var arg_1305 any = pt__2; var arg_1306 any = t.F_what; if linked_1302 == nil { tmp2 = ifn_1303.Invoke_O_O_O__O(arg_1304, arg_1305, arg_1306) } else { tmp2 = linked_1302.(*A_arbace_box_plan_embed_files_A).Invoke_O_O_O_O__O(root_1301, arg_1304, arg_1305, arg_1306) }; arg_1300 = lang.Tuple_Create_O_O__IPersistentVector(pt__2, tmp2); if linked_1297 == nil { ifn_1298.Invoke_O_O__O(arg_1299, arg_1300) } else { linked_1297.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1296, arg_1299, arg_1300) }; i__1305000191__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000191__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_box_plan_src_tree_A_New() *A_arbace_box_plan_src_tree_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_box_plan_src_tree_A) Ctor() {}
//line :296:1
func (t *A_arbace_box_plan_src_tree_A) Invoke_O_O__O(self, p__1305000200__0 any) any { var map__1305000201__2 any = p__1305000200__0; var map__1305000201__3 any; if lang.ISeq_InstanceOf(map__1305000201__2) { var tmp1 any; var root_1439 any = A_arbace_box_plan_A_const_28.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = map__1305000201__2; if linked_1440 == nil { tmp1 = ifn_1441.Invoke_O__O(arg_1442) } else { tmp1 = linked_1440.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1439, arg_1442) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1443 any = A_arbace_box_plan_A_const_29.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = map__1305000201__2; if linked_1444 == nil { tmp2 = ifn_1445.Invoke_O__O(arg_1446) } else { tmp2 = linked_1444.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1443, arg_1446) }; map__1305000201__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1447 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = map__1305000201__2; if linked_1448 == nil { tmp3 = ifn_1449.Invoke_O__O(arg_1450) } else { tmp3 = linked_1448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1447, arg_1450) }; if jrt.J2g_Truth(tmp3) { var root_1451 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = map__1305000201__2; if linked_1452 == nil { map__1305000201__3 = ifn_1453.Invoke_O__O(arg_1454) } else { map__1305000201__3 = linked_1452.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1451, arg_1454) } } else { map__1305000201__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000201__3 = map__1305000201__2 }; var dir__4 any = lang.RT_Get_O_O__O_NoInit(map__1305000201__3, A_arbace_box_plan_A_const_20); var embed__5 any = lang.RT_Get_O_O__O_NoInit(map__1305000201__3, A_arbace_box_plan_A_const_153); var embedded__6 any; var root_1455 any = A_arbace_box_plan_A_const_37.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1457 lang.IFn; if



	linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = lang.IFn_Cast(A_arbace_box_plan_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_155.GetRawRoot__O(), A_arbace_box_plan_A_const_142.Invoke_O__O(embed__5)); if linked_1456 == nil { embedded__6 = ifn_1457.Invoke_O__O(arg_1458) } else { embedded__6 = linked_1456.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1455, arg_1458) }; var sub__7 any; var tmp4 any = /*line :296:1*/A_arbace_box_plan_src_tree_sub__1305000203_A_New_O(embedded__6); var tmp5 *jrt.Class; var fncls__1554 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_A_fn_class; if




	fncls__1554 == nil { var fncls__1554d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_box_plan_src_tree_sub__1305000203_A_fn_class = fncls__1554d; tmp5 = fncls__1554d } else { tmp5 = fncls__1554 }; sub__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var root_1555 any =








	A_arbace_box_plan_A_const_156.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any; var root_1559 any = A_arbace_box_plan_A_const_91.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1561 lang.IFn; if
	linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1563 any; var iter__1927001039__auto____8 any; var tmp6 any = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_New_O(sub__7); var tmp7 *jrt.Class; var fncls__1626 *jrt.Class = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_fn_class; if
	fncls__1626 == nil { var fncls__1626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_fn_class = fncls__1626d; tmp7 = fncls__1626d } else { tmp7 = fncls__1626 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp9 any; var root_1627 any = A_arbace_box_plan_A_const_19.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, A_arbace_box_plan_entries_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = dir__4; if linked_1628 == nil { tmp9 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp9 = linked_1628.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(root_1627, arg_1630) }; arg_1563 = tmp8.Invoke_O__O(tmp9); if /*line :311:1*/ linked_1560 == nil { arg_1558 = ifn_1561.Invoke_O_O__O(arg_1562, arg_1563) } else { arg_1558 = linked_1560.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1559, arg_1562, arg_1563) }; if /*line :310:1*/ linked_1556 == nil { return ifn_1557.Invoke_O__O(arg_1558) } else { return linked_1556.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1555, arg_1558) } }
//line :301:1
func A_arbace_box_plan_src_tree_sub__1305000203_A_New_O(p0 any) *A_arbace_box_plan_src_tree_sub__1305000203_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_A{}; t.Ctor_O(p0); return t }
//line :301:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_A) Ctor_O(c__embedded any) { t.F_embedded = c__embedded }
//line :301:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_A) Invoke_O_O_O__O(self, h__1, prefix__2 any) any { var m__3 any; var root_1464 any = A_arbace_box_plan_A_const_91.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1466 lang.IFn; if
													linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1468 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_New_O_O_O(self, t.F_embedded, prefix__2); var tmp2 *jrt.Class; var fncls__1541 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_fn_class; if
													fncls__1541 == nil { var fncls__1541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_fn_class = fncls__1541d; tmp2 = fncls__1541d } else { tmp2 = fncls__1541 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1542 any = A_arbace_box_plan_A_const_19.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, A_arbace_box_plan_entries_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = h__1; if linked_1543 == nil { tmp4 = ifn_1544.Invoke_O__O(arg_1545) } else { tmp4 = linked_1543.(*A_arbace_box_plan_entries_A).Invoke_O_O__O(root_1542, arg_1545) }; arg_1468 = tmp3.Invoke_O__O(tmp4); if /*line :302:1*/ linked_1465 == nil { m__3 = ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { m__3 = linked_1465.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) }; var tmp5 any; var root_1546 any =






	A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = m__3; if linked_1547 == nil { tmp5 = ifn_1548.Invoke_O__O(arg_1549) } else { tmp5 = linked_1547.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1546, arg_1549) }; if jrt.J2g_Truth(tmp5) { var root_1550 any = A_arbace_box_plan_A_const_156.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = m__3; if linked_1551 == nil { return ifn_1552.Invoke_O__O(arg_1553) } else { return linked_1551.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1550, arg_1553) } } else { return nil } }
//line :303:1
func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A) Ctor_O_O_O(c__sub, c__embedded, c__prefix any) { t.F_sub = c__sub; t.F_embedded = c__embedded; t.F_prefix = c__prefix }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A) Invoke_O_O__O(self, s__1305000205__1 any) any { var tmp1 any = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_New_O_O_O_O_O(t.F_sub, s__1305000205__1, t.F_embedded, self, t.F_prefix); var tmp2 *jrt.Class; var fncls__1540 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_fn_class; if fncls__1540 == nil { var fncls__1540d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_fn_class = fncls__1540d; tmp2 = fncls__1540d } else { tmp2 = fncls__1540 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :303:1
func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A) Ctor_O_O_O_O_O(c__sub, c__s__1305000205, c__embedded, c__iter__1305000204, c__prefix any) { t.F_sub = c__sub; t.F_s__1305000205 = c__s__1305000205; t.F_embedded = c__embedded; t.F_iter__1305000204 = c__iter__1305000204; t.F_prefix = c__prefix }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A) Invoke_O__O(self any) any { { var s__1305000205__1 any; var t_ any = t.F_s__1305000205; t.F_s__1305000205 = nil; s__1305000205__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1469 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = s__1305000205__1; if linked_1470 == nil { temp__1927000414__auto____2 = ifn_1471.Invoke_O__O(arg_1472) } else { temp__1927000414__auto____2 = linked_1470.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1469, arg_1472) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1473 any = A_arbace_box_plan_A_const_123.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = s__1305000205__3; if linked_1474 == nil { tmp1 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp1 = linked_1474.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1473, arg_1476) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1477 any = A_arbace_box_plan_A_const_124.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = s__1305000205__3; if linked_1478 == nil { c__1927001037__auto____4 = ifn_1479.Invoke_O__O(arg_1480) } else { c__1927001037__auto____4 = linked_1478.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1477, arg_1480) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000207__6 any; var root_1481 any = A_arbace_box_plan_A_const_125.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1482 == nil { b__1305000207__6 = ifn_1483.Invoke_O__O(arg_1484) } else { b__1305000207__6 = linked_1482.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1481, arg_1484) }; var tmp2 any = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_New_O_O_O_O_I_O(t.F_sub, t.F_embedded, b__1305000207__6, t.F_prefix, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1495 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_fn_class; if fncls__1495 == nil { var fncls__1495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_fn_class = fncls__1495d; tmp3 = fncls__1495d } else { tmp3 = fncls__1495 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1496 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any; var root_1501 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = b__1305000207__6; if linked_1502 == nil { arg_1499 = ifn_1503.Invoke_O__O(arg_1504) } else { arg_1499 = linked_1502.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1501, arg_1504) }; var arg_1500 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1305000204); var tmp5 any; var root_1505 any = A_arbace_box_plan_A_const_133.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = s__1305000205__3; if linked_1506 == nil { tmp5 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp5 = linked_1506.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1505, arg_1508) }; arg_1500 = tmp4.Invoke_O__O(tmp5); if linked_1497 == nil { return ifn_1498.Invoke_O_O__O(arg_1499, arg_1500) } else { return linked_1497.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1496, arg_1499, arg_1500) } } else { var root_1509 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any; var root_1514 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = b__1305000207__6; if linked_1515 == nil { arg_1512 = ifn_1516.Invoke_O__O(arg_1517) } else { arg_1512 = linked_1515.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1514, arg_1517) }; var arg_1513 any; if linked_1510 == nil { return ifn_1511.Invoke_O_O__O(arg_1512, arg_1513) } else { return linked_1510.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1509, arg_1512, arg_1513) } } } else { var vec__1305000218__4 any; var root_1518 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = s__1305000205__3; if linked_1519 == nil { vec__1305000218__4 = ifn_1520.Invoke_O__O(arg_1521) } else { vec__1305000218__4 = linked_1519.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1518, arg_1521) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000218__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000221__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000218__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000221__6, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000221__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any = vec__1305000221__6; var p__10 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__5)).Ref(); var e__11 any

	if lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_box_plan_A_const_20) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____11 any = tmp6.Invoke_O_O__O(eh__8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, p__10, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____11) { var t__12 any = temp__1927000414__auto____11; e__11 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__12) } else { e__11 = nil } } else { var tmp7 any; var or__1927000174__auto____11 any; var root_1522 any = A_arbace_box_plan_A_const_128.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1524 lang.IFn
		if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = n__5; var arg_1526 any = Lit_102; if linked_1523 == nil { or__1927000174__auto____11 = ifn_1524.Invoke_O_O__O(arg_1525, arg_1526) } else { or__1927000174__auto____11 = linked_1523.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1522, arg_1525, arg_1526) }; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp7 = or__1927000174__auto____11 } else { tmp7 = lang.IFn_Cast(t.F_embedded).Invoke_O__O(p__10) }
//line :305:1
		if jrt.J2g_Truth(tmp7) { e__11 = e__9 } else { e__11 = nil } }
//line :303:1
	if jrt.J2g_Truth(e__11) { var root_1527 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, e__11); var arg_1531 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1305000204); var tmp9 any; var root_1532 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = s__1305000205__3; if linked_1533 == nil { tmp9 = ifn_1534.Invoke_O__O(arg_1535) } else { tmp9 = linked_1533.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1532, arg_1535) }; arg_1531 = tmp8.Invoke_O__O(tmp9); if linked_1528 == nil { return ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { return linked_1528.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) } } else { var tmp10 any; var root_1536 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = s__1305000205__3; if linked_1537 == nil { tmp10 = ifn_1538.Invoke_O__O(arg_1539) } else { tmp10 = linked_1537.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1536, arg_1539) }; s__1305000205__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :303:1
func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A) Ctor_O_O_O_O_I_O(c__sub, c__embedded, c__b__1305000207, c__prefix any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_sub = c__sub; t.F_embedded = c__embedded; t.F_b__1305000207 = c__b__1305000207; t.F_prefix = c__prefix; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A) Invoke_O__O(self any) any { { var i__1305000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000211__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000206__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000211__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000214__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000211__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000214__4, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000214__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = vec__1305000214__4; var p__8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__3)).Ref(); var e__9 any

	if lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_box_plan_A_const_20) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____9 any = tmp2.Invoke_O_O__O(eh__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, p__8, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____9) { var t__10 any = temp__1927000414__auto____9; e__9 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__10) } else { e__9 = nil } } else { var tmp3 any; var or__1927000174__auto____9 any; var root_1485 any = A_arbace_box_plan_A_const_128.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1487 lang.IFn
		if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = n__3; var arg_1489 any = Lit_102; if linked_1486 == nil { or__1927000174__auto____9 = ifn_1487.Invoke_O_O__O(arg_1488, arg_1489) } else { or__1927000174__auto____9 = linked_1486.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1485, arg_1488, arg_1489) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp3 = or__1927000174__auto____9 } else { tmp3 = lang.IFn_Cast(t.F_embedded).Invoke_O__O(p__8) }
//line :305:1
		if jrt.J2g_Truth(tmp3) { e__9 = e__7 } else { e__9 = nil } }
//line :303:1
	if jrt.J2g_Truth(e__9) { var root_1490 any = A_arbace_box_plan_A_const_130.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = t.F_b__1305000207; var arg_1494 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, e__9); if linked_1491 == nil { ifn_1492.Invoke_O_O__O(arg_1493, arg_1494) } else { linked_1491.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1490, arg_1493, arg_1494) }; i__1305000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000206__1); continue L1 } else { i__1305000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000206__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_New_O(p0 any) *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A{}; t.Ctor_O(p0); return t }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A) Ctor_O(c__sub any) { t.F_sub = c__sub }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A) Invoke_O_O__O(self, s__1305000228__1 any) any { var tmp1 any = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_New_O_O_O(s__1305000228__1, self, t.F_sub); var tmp2 *jrt.Class; var fncls__1625 *jrt.Class = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_fn_class; if fncls__1625 == nil { var fncls__1625d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_fn_class = fncls__1625d; tmp2 = fncls__1625d } else { tmp2 = fncls__1625 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :312:1
func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A) Ctor_O_O_O(c__s__1305000228, c__iter__1305000227, c__sub any) { t.F_s__1305000228 = c__s__1305000228; t.F_iter__1305000227 = c__iter__1305000227; t.F_sub = c__sub }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A) Invoke_O__O(self any) any { { var s__1305000228__1 any; var t_ any = t.F_s__1305000228; t.F_s__1305000228 = nil; s__1305000228__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1564 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = s__1305000228__1; if linked_1565 == nil { temp__1927000414__auto____2 = ifn_1566.Invoke_O__O(arg_1567) } else { temp__1927000414__auto____2 = linked_1565.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1564, arg_1567) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000228__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1568 any = A_arbace_box_plan_A_const_123.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = s__1305000228__3; if linked_1569 == nil { tmp1 = ifn_1570.Invoke_O__O(arg_1571) } else { tmp1 = linked_1569.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1568, arg_1571) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1572 any = A_arbace_box_plan_A_const_124.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = s__1305000228__3; if linked_1573 == nil { c__1927001037__auto____4 = ifn_1574.Invoke_O__O(arg_1575) } else { c__1927001037__auto____4 = linked_1573.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1572, arg_1575) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000230__6 any; var root_1576 any = A_arbace_box_plan_A_const_125.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1577 == nil { b__1305000230__6 = ifn_1578.Invoke_O__O(arg_1579) } else { b__1305000230__6 = linked_1577.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1576, arg_1579) }; var tmp2 any = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_New_O_O_I_O(b__1305000230__6, t.F_sub, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1585 *jrt.Class = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_fn_class; if fncls__1585 == nil { var fncls__1585d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_fn_class = fncls__1585d; tmp3 = fncls__1585d } else { tmp3 = fncls__1585 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1586 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any; var root_1591 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = b__1305000230__6; if linked_1592 == nil { arg_1589 = ifn_1593.Invoke_O__O(arg_1594) } else { arg_1589 = linked_1592.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1591, arg_1594) }; var arg_1590 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1305000227); var tmp5 any; var root_1595 any = A_arbace_box_plan_A_const_133.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = s__1305000228__3; if linked_1596 == nil { tmp5 = ifn_1597.Invoke_O__O(arg_1598) } else { tmp5 = linked_1596.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1595, arg_1598) }; arg_1590 = tmp4.Invoke_O__O(tmp5); if linked_1587 == nil { return ifn_1588.Invoke_O_O__O(arg_1589, arg_1590) } else { return linked_1587.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1586, arg_1589, arg_1590) } } else { var root_1599 any = A_arbace_box_plan_A_const_131.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any; var root_1604 any = A_arbace_box_plan_A_const_132.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = b__1305000230__6; if linked_1605 == nil { arg_1602 = ifn_1606.Invoke_O__O(arg_1607) } else { arg_1602 = linked_1605.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1604, arg_1607) }; var arg_1603 any; if linked_1600 == nil { return ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { return linked_1600.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) } } } else { var vec__1305000241__4 any; var root_1608 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = s__1305000228__3; if linked_1609 == nil { vec__1305000241__4 = ifn_1610.Invoke_O__O(arg_1611) } else { vec__1305000241__4 = linked_1609.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1608, arg_1611) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000241__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000244__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000241__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000244__6, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000244__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any = vec__1305000244__6; var e__10 any
														if lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_box_plan_A_const_20) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____10 any = tmp6.Invoke_O_O__O(eh__8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, n__5, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____10) { var t__11 any = temp__1927000414__auto____10; e__10 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__11) } else { e__10 = nil } } else { e__10 = e__9 }
//line :312:1
	if jrt.J2g_Truth(e__10) { var root_1612 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, e__10); var arg_1616 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1305000227); var tmp8 any; var root_1617 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = s__1305000228__3; if linked_1618 == nil { tmp8 = ifn_1619.Invoke_O__O(arg_1620) } else { tmp8 = linked_1618.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1617, arg_1620) }; arg_1616 = tmp7.Invoke_O__O(tmp8); if linked_1613 == nil { return ifn_1614.Invoke_O_O__O(arg_1615, arg_1616) } else { return linked_1613.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1612, arg_1615, arg_1616) } } else { var tmp9 any; var root_1621 any = A_arbace_box_plan_A_const_56.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = s__1305000228__3; if linked_1622 == nil { tmp9 = ifn_1623.Invoke_O__O(arg_1624) } else { tmp9 = linked_1622.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1621, arg_1624) }; s__1305000228__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :312:1
func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A) Ctor_O_O_I_O(c__b__1305000230, c__sub any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1305000230 = c__b__1305000230; t.F_sub = c__sub; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A) Invoke_O__O(self any) any { { var i__1305000229__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000229__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000234__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000229__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000237__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000237__4, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000237__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = vec__1305000237__4; var e__8 any
																if lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_box_plan_A_const_20) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____8 any = tmp2.Invoke_O_O__O(eh__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, n__3, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____8) { var t__9 any = temp__1927000414__auto____8; e__8 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__9) } else { e__8 = nil } } else { e__8 = e__7 }
//line :312:1
	if jrt.J2g_Truth(e__8) { var root_1580 any = A_arbace_box_plan_A_const_130.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = t.F_b__1305000230; var arg_1584 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, e__8); if linked_1581 == nil { ifn_1582.Invoke_O_O__O(arg_1583, arg_1584) } else { linked_1581.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1580, arg_1583, arg_1584) }; i__1305000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000229__1); continue L1 } else { i__1305000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000229__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_box_plan_plan_A_New() *A_arbace_box_plan_plan_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_box_plan_plan_A) Ctor() {}
//line :317:1
func (t *A_arbace_box_plan_plan_A) Invoke_O_O__O(self, cfg__0 any) any {


	var root_1827 any = A_arbace_box_plan_A_const_171.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_172.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_A_const_13; var tmp3 any; var root_1836 any = A_arbace_box_plan_A_const_54.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1837 == nil { tmp3 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp3 = linked_1837.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1836, arg_1839) }; arg_1830 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_1828 == nil { ifn_1829.Invoke_O__O(arg_1830) } else { linked_1828.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1827, arg_1830) }
//line :317:1
	var tmp4 any; tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var match_QMARK___4 any; var root_1631 any = A_arbace_box_plan_A_const_157.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, A_arbace_box_plan_tag_fn_A_fn_class); var ifn_1633 lang.IFn



		if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = cfg__0; if linked_1632 == nil { match_QMARK___4 = ifn_1633.Invoke_O__O(arg_1634) } else { match_QMARK___4 = linked_1632.(*A_arbace_box_plan_tag_fn_A).Invoke_O_O__O(root_1631, arg_1634) }
//line :317:1
		var cfg__5 any; var root_1635 any = A_arbace_box_plan_A_const_11.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1637 lang.IFn




		if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = cfg__0; var arg_1639 any = A_arbace_box_plan_A_const_146; var arg_1640 any; var or__1927000174__auto____5 any; var root_1641 any = A_arbace_box_plan_A_const_113.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, A_arbace_box_plan_go_mod_lang_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = A_arbace_box_plan_A_const_106.Invoke_O__O(cfg__0); if linked_1642 == nil { or__1927000174__auto____5 = ifn_1643.Invoke_O__O(arg_1644) } else { or__1927000174__auto____5 = linked_1642.(*A_arbace_box_plan_go_mod_lang_A).Invoke_O_O__O(root_1641, arg_1644) }; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_1640 = or__1927000174__auto____5 } else { var root_1645 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, A_arbace_box_plan_fail_A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = Lit_84; var arg_1649 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1646 == nil { arg_1640 = ifn_1647.Invoke_O_O__O(arg_1648, arg_1649) } else { arg_1640 = linked_1646.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_1645, arg_1648, arg_1649) } }; if linked_1636 == nil { cfg__5 = ifn_1637.Invoke_O_O_O__O(arg_1638, arg_1639, arg_1640) } else { cfg__5 = linked_1636.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1635, arg_1638, arg_1639, arg_1640) }
//line :317:1
		var done__6 any; var root_1650 any = A_arbace_box_plan_A_const_54.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1652 lang.IFn





		if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1651 == nil { done__6 = ifn_1652.Invoke_O__O(arg_1653) } else { done__6 = linked_1651.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1650, arg_1653) }
//line :317:1
		var order__7 any; var root_1654 any = A_arbace_box_plan_A_const_54.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1656 lang.IFn






		if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = lang.PersistentVector_EMPTY.Ref(); if linked_1655 == nil { order__7 = ifn_1656.Invoke_O__O(arg_1657) } else { order__7 = linked_1655.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1654, arg_1657) }
//line :317:1
		var visit__8 any; var tmp5 any = A_arbace_box_plan_plan_visit__1305000250_A_New_O_O_O_O(order__7, match_QMARK___4, done__6, cfg__5); var tmp6 *jrt.Class
		var fncls__1793 /*line :317:1*/*jrt.Class = A_arbace_box_plan_plan_visit__1305000250_A_fn_class







		if fncls__1793 == nil { var fncls__1793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_box_plan_plan_visit__1305000250_A_fn_class = fncls__1793d; tmp6 = fncls__1793d } else { tmp6 = fncls__1793 }; visit__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
















		lang.IFn_Cast(visit__8).Invoke_O_O_O__O(A_arbace_box_plan_A_const_165.Invoke_O__O(cfg__5), jrt.Boolean_FALSE.Ref(), lang.PersistentList_EMPTY.Ref())
//line :317:1
		var tmp7 any = A_arbace_box_plan_A_const_32; var tmp8 any = A_arbace_box_plan_A_const_32.Invoke_O__O(cfg__5); var tmp9 any = A_arbace_box_plan_A_const_33; var tmp10 any = A_arbace_box_plan_A_const_33.Invoke_O__O(cfg__5); var tmp11 any = A_arbace_box_plan_A_const_163; var tmp12 any = A_arbace_box_plan_A_const_163.Invoke_O_O__O(cfg__5, Lit_86); var tmp13 any = A_arbace_box_plan_A_const_164; var tmp14 any = A_arbace_box_plan_A_const_164.Invoke_O_O__O(cfg__5, Lit_87); var tmp15 any = A_arbace_box_plan_A_const_165; var tmp16 any = A_arbace_box_plan_A_const_165.Invoke_O__O(cfg__5); var tmp17 any = A_arbace_box_plan_A_const_166; var tmp18 any = A_arbace_box_plan_A_const_166.Invoke_O__O(cfg__5); var tmp19 any = A_arbace_box_plan_A_const_167; var tmp20 any; var root_1794 any = A_arbace_box_plan_A_const_148.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1796 lang.IFn



























		if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any; var tmp21 any = A_arbace_box_plan_plan_fn__1305000260_A_New(); var tmp22 *jrt.Class; var fncls__1819 *jrt.Class = A_arbace_box_plan_plan_fn__1305000260_A_fn_class; if fncls__1819 == nil { var fncls__1819d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_box_plan_plan_fn__1305000260_A_fn_class = fncls__1819d; tmp22 = fncls__1819d } else { tmp22 = fncls__1819 }; arg_1797 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); var arg_1798 any; var root_1820 any = A_arbace_box_plan_A_const_6.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = order__7; if linked_1821 == nil { arg_1798 = ifn_1822.Invoke_O__O(arg_1823) } else { arg_1798 = linked_1821.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1820, arg_1823) }; if linked_1795 == nil { tmp20 = ifn_1796.Invoke_O_O__O(arg_1797, arg_1798) } else { tmp20 = linked_1795.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1794, arg_1797, arg_1798) }
//line :317:1
		tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20)) }; return nil }(); var root_1824 any = A_arbace_box_plan_A_const_170.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1826 lang.IFn


	if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; if linked_1825 == nil { ifn_1826.Invoke__O() } else { linked_1825.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1824) }
//line :317:1
	if tmp23 != nil { panic(tmp23) }; return tmp4
}






func A_arbace_box_plan_plan_visit__1305000250_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_plan_visit__1305000250_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_visit__1305000250_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :325:1
func (t *A_arbace_box_plan_plan_visit__1305000250_A) Ctor_O_O_O_O(c__order, c__match_QMARK_, c__done, c__cfg any) { t.F_order = c__order; t.F_match_QMARK_ = c__match_QMARK_; t.F_done = c__done; t.F_cfg = c__cfg }
//line :325:1
func (t *A_arbace_box_plan_plan_visit__1305000250_A) Invoke_O_O_O_O__O(self, p__1, from_std__2, stack__3 any) any {
	var tmp1 any; var root_1744 any = A_arbace_box_plan_A_const_94.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, p__1)); var arg_1748 any = stack__3; if linked_1745 == nil { tmp1 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { tmp1 = linked_1745.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; if jrt.J2g_Truth(tmp1) {
		var root_1749 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, A_arbace_box_plan_fail_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_89, nil); var tmp3 any; var root_1754 any = A_arbace_box_plan_A_const_117.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = Lit_90; var arg_1758 any; var root_1759 any = A_arbace_box_plan_A_const_162.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any; var root_1763 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = p__1; var arg_1767 any = stack__3; if linked_1764 == nil { arg_1762 = ifn_1765.Invoke_O_O__O(arg_1766, arg_1767) } else { arg_1762 = linked_1764.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1763, arg_1766, arg_1767) }; if linked_1760 == nil { arg_1758 = ifn_1761.Invoke_O__O(arg_1762) } else { arg_1758 = linked_1760.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_1759, arg_1762) }; if linked_1755 == nil { tmp3 = ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { tmp3 = linked_1755.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) }; arg_1752 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_1753 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1750 == nil { ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { linked_1750.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) } }
//line :325:1
	var or__1927000174__auto____4 any; var tmp4 any; var root_1658 any = A_arbace_box_plan_A_const_6.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1660 lang.IFn


	if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = t.F_done; if linked_1659 == nil { tmp4 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp4 = linked_1659.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1658, arg_1661) }; or__1927000174__auto____4 = lang.RT_Get_O_O__O_NoInit(tmp4, p__1); if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var loc__5 any; var or__1927000174__auto____5 any; var root_1662 any = A_arbace_box_plan_A_const_158.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, A_arbace_box_plan_locate_A_fn_class); var ifn_1664 lang.IFn
		if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = t.F_cfg; var arg_1666 any = p__1; var arg_1667 any = from_std__2; if linked_1663 == nil { or__1927000174__auto____5 = ifn_1664.Invoke_O_O_O__O(arg_1665, arg_1666, arg_1667) } else { or__1927000174__auto____5 = linked_1663.(*A_arbace_box_plan_locate_A).Invoke_O_O_O_O__O(root_1662, arg_1665, arg_1666, arg_1667) }; if jrt.J2g_Truth(or__1927000174__auto____5) { loc__5 = or__1927000174__auto____5 } else {
			var root_1668 any = A_arbace_box_plan_A_const_15.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, A_arbace_box_plan_fail_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_91, nil, nil); var tmp6 *jrt.String; var tmp7 any; var root_1673 any = A_arbace_box_plan_A_const_30.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = stack__3; if linked_1674 == nil { tmp7 = ifn_1675.Invoke_O__O(arg_1676) } else { tmp7 = linked_1674.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1673, arg_1676) }; if jrt.J2g_Truth(tmp7) { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_92, nil); var tmp9 any; var root_1677 any = A_arbace_box_plan_A_const_31.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = stack__3; if linked_1678 == nil { tmp9 = ifn_1679.Invoke_O__O(arg_1680) } else { tmp9 = linked_1678.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1677, arg_1680) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9)) } else { tmp6 = nil }; arg_1671 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, p__1, tmp6.Ref())).Ref(); var arg_1672 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_114, p__1)); if linked_1669 == nil { loc__5 = ifn_1670.Invoke_O_O__O(arg_1671, arg_1672) } else { loc__5 = linked_1669.(*A_arbace_box_plan_fail_A).Invoke_O_O_O__O(root_1668, arg_1671, arg_1672) } }
//line :328:1
		var info__6 any; var root_1681 any = A_arbace_box_plan_A_const_159.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, A_arbace_box_plan_package_info_A_fn_class); var ifn_1683 lang.IFn


		if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = t.F_cfg; var arg_1685 any = t.F_match_QMARK_; var arg_1686 any = p__1; var arg_1687 any = loc__5; if linked_1682 == nil { info__6 = ifn_1683.Invoke_O_O_O_O__O(arg_1684, arg_1685, arg_1686, arg_1687) } else { info__6 = linked_1682.(*A_arbace_box_plan_package_info_A).Invoke_O_O_O_O_O__O(root_1681, arg_1684, arg_1685, arg_1686, arg_1687) }
//line :328:1
		var resolved__7 any; var root_1688 any = A_arbace_box_plan_A_const_148.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1690 lang.IFn



		if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any; var tmp10 any = A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_New_O_O_O_O(stack__3, self, p__1, loc__5); var tmp11 *jrt.Class; var fncls__1698 *jrt.Class = A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_fn_class; if fncls__1698 == nil { var fncls__1698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_fn_class = fncls__1698d; tmp11 = fncls__1698d } else { tmp11 = fncls__1698 }; arg_1691 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1692 any = A_arbace_box_plan_A_const_150.Invoke_O__O(info__6); if linked_1689 == nil { resolved__7 = ifn_1690.Invoke_O_O__O(arg_1691, arg_1692) } else { resolved__7 = linked_1689.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1688, arg_1691, arg_1692) }
//line :328:1
		var pkg__8 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_11.GetRawRoot__O()); var tmp13 any; var root_1707 any = A_arbace_box_plan_A_const_160.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1709 lang.IFn





		if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = info__6; var arg_1711 any = A_arbace_box_plan_A_const_150; if linked_1708 == nil { tmp13 = ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { tmp13 = linked_1708.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711)
		}
		var tmp14 any = tmp13; var tmp15 any = A_arbace_box_plan_A_const_102; var tmp16 any; var root_1712 any = A_arbace_box_plan_A_const_44.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any; var root_1716 any = A_arbace_box_plan_A_const_140.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any; var root_1720 any = A_arbace_box_plan_A_const_97.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = A_arbace_box_plan_A_const_86.GetRawRoot__O(); var arg_1724 any = resolved__7; if linked_1721 == nil { arg_1719 = ifn_1722.Invoke_O_O__O(arg_1723, arg_1724) } else { arg_1719 = linked_1721.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1720, arg_1723, arg_1724) }; if linked_1717 == nil { arg_1715 = ifn_1718.Invoke_O__O(arg_1719) } else { arg_1715 = linked_1717.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1716, arg_1719) }; if linked_1713 == nil { tmp16 = ifn_1714.Invoke_O__O(arg_1715) } else { tmp16 = linked_1713.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1712, arg_1715) }; var tmp17 any = tmp16; var tmp18 any = A_arbace_box_plan_A_const_161; var tmp19 any; var root_1725 any = A_arbace_box_plan_A_const_91.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1727 lang.IFn
		if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = lang.IFn_Cast(A_arbace_box_plan_A_const_143.GetRawRoot__O()).Invoke__O(); var arg_1729 any; var root_1733 any = A_arbace_box_plan_A_const_109.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any; var tmp20 any = A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_New(); var tmp21 *jrt.Class; var fncls__1743 *jrt.Class = A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_fn_class; if fncls__1743 == nil { var fncls__1743d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_fn_class = fncls__1743d; tmp21 = fncls__1743d } else { tmp21 = fncls__1743 }; arg_1736 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var arg_1737 any = resolved__7; if linked_1734 == nil { arg_1729 = ifn_1735.Invoke_O_O__O(arg_1736, arg_1737) } else { arg_1729 = linked_1734.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1733, arg_1736, arg_1737) }; if linked_1726 == nil { tmp19 = ifn_1727.Invoke_O_O__O(arg_1728, arg_1729) } else { tmp19 = linked_1726.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1725, arg_1728, arg_1729) }
//line :336:1
		pkg__8 = tmp12.Invoke_O_O_O_O_O__O(tmp14, tmp15, tmp17, tmp18, tmp19)

		var root_1768 any = A_arbace_box_plan_A_const_17.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = t.F_done; var arg_1772 any = A_arbace_box_plan_A_const_11.GetRawRoot__O(); var arg_1773 any = p__1; var arg_1774 any = pkg__8; if linked_1769 == nil { ifn_1770.Invoke_O_O_O_O__O(arg_1771, arg_1772, arg_1773, arg_1774) } else { linked_1769.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1768, arg_1771, arg_1772, arg_1773, arg_1774) }
		var tmp22 any; var root_1775 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = p__1; var arg_1779 any = A_arbace_box_plan_A_const_114.Invoke_O__O(pkg__8); if linked_1776 == nil { tmp22 = ifn_1777.Invoke_O_O__O(arg_1778, arg_1779) } else { tmp22 = linked_1776.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1775, arg_1778, arg_1779) }; if jrt.J2g_Truth(tmp22) { var root_1780 any = A_arbace_box_plan_A_const_17.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1780, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1782 lang.IFn; if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = t.F_done; var arg_1784 any = A_arbace_box_plan_A_const_11.GetRawRoot__O(); var arg_1785 any = A_arbace_box_plan_A_const_114.Invoke_O__O(pkg__8); var arg_1786 any = pkg__8; if linked_1781 == nil { ifn_1782.Invoke_O_O_O_O__O(arg_1783, arg_1784, arg_1785, arg_1786) } else { linked_1781.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1780, arg_1783, arg_1784, arg_1785, arg_1786) } }
		var root_1787 any = A_arbace_box_plan_A_const_17.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = t.F_order; var arg_1791 any = A_arbace_box_plan_A_const_8.GetRawRoot__O(); var arg_1792 any = pkg__8; if linked_1788 == nil { ifn_1789.Invoke_O_O_O__O(arg_1790, arg_1791, arg_1792) } else { linked_1788.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1787, arg_1790, arg_1791, arg_1792) }
//line :328:1
		return pkg__8
	}
}

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :332:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A) Ctor_O_O_O_O(c__stack, c__visit, c__p, c__loc any) { t.F_stack = c__stack; t.F_visit = c__visit; t.F_p = c__p; t.F_loc = c__loc }
//line :332:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 *lang.Keyword = A_arbace_box_plan_A_const_114; var tmp2 lang.IFn = lang.IFn_Cast(t.F_visit); var tmp3 any = A_arbace_box_plan_A_const_111.Invoke_O__O(t.F_loc); var tmp4 any; var root_1693 any = A_arbace_box_plan_A_const_70.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = t.F_p; var arg_1697 any = t.F_stack; if linked_1694 == nil { tmp4 = ifn_1695.Invoke_O_O__O(arg_1696, arg_1697) } else { tmp4 = linked_1694.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1693, arg_1696, arg_1697) }; return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(i__1, tmp3, tmp4))) }




func A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_New() *A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A) Ctor() {}
//line :337:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A) Invoke_O_O__O(self, p__1305000253__1 any) any { var vec__1305000255__2 any = p__1305000253__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000255__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000255__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1738 any = A_arbace_box_plan_A_const_90.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = a__3; var arg_1742 any = b__4; if linked_1739 == nil { return ifn_1740.Invoke_O_O__O(arg_1741, arg_1742) } else { return linked_1739.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1738, arg_1741, arg_1742) } }







func A_arbace_box_plan_plan_fn__1305000260_A_New() *A_arbace_box_plan_plan_fn__1305000260_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_fn__1305000260_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_box_plan_plan_fn__1305000260_A) Ctor() {}
//line :345:1
func (t *A_arbace_box_plan_plan_fn__1305000260_A) Invoke_O_O__O(self, pkg__1 any) any { var G__1305000261__2_ any; var root_1799 any = A_arbace_box_plan_A_const_160.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any; var root_1804 any = A_arbace_box_plan_A_const_11.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any = pkg__1; var arg_1808 any = A_arbace_box_plan_A_const_168; var arg_1809 any; var root_1810 any = A_arbace_box_plan_A_const_169.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, A_arbace_box_plan_src_tree_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = pkg__1; if linked_1811 == nil { arg_1809 = ifn_1812.Invoke_O__O(arg_1813) } else { arg_1809 = linked_1811.(*A_arbace_box_plan_src_tree_A).Invoke_O_O__O(root_1810, arg_1813) }; if linked_1805 == nil { arg_1802 = ifn_1806.Invoke_O_O_O__O(arg_1807, arg_1808, arg_1809) } else { arg_1802 = linked_1805.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1804, arg_1807, arg_1808, arg_1809) }; var arg_1803 any = A_arbace_box_plan_A_const_20; if linked_1800 == nil { G__1305000261__2_ = ifn_1801.Invoke_O_O__O(arg_1802, arg_1803) } else { G__1305000261__2_ = linked_1800.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1799, arg_1802, arg_1803) }; if lang.Util_Identical_O_O__Z_NoInit(A_arbace_box_plan_A_const_153.Invoke_O__O(pkg__1), nil) { var root_1814 any = A_arbace_box_plan_A_const_160.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = G__1305000261__2_; var arg_1818 any = A_arbace_box_plan_A_const_153; if linked_1815 == nil { return ifn_1816.Invoke_O_O__O(arg_1817, arg_1818) } else { return linked_1815.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1814, arg_1817, arg_1818) } } else { return G__1305000261__2_ } }
































































































type A_arbace_box_plan_A struct{ jrt.Object }

var A_arbace_box_plan_A_const_pool *jrt.RefArray

var A_arbace_box_plan_A_const_0 *lang.Var

var A_arbace_box_plan_A_const_1 any

var A_arbace_box_plan_A_const_2 any

var A_arbace_box_plan_A_const_3 *lang.Var

var A_arbace_box_plan_A_const_4 any

var A_arbace_box_plan_A_const_5 *lang.Var

var A_arbace_box_plan_A_const_6 *lang.Var

var A_arbace_box_plan_A_const_7 *lang.Var

var A_arbace_box_plan_A_const_8 *lang.Var

var A_arbace_box_plan_A_const_9 any

var A_arbace_box_plan_A_const_10 *lang.Var

var A_arbace_box_plan_A_const_11 *lang.Var

var A_arbace_box_plan_A_const_12 *lang.Keyword

var A_arbace_box_plan_A_const_13 *lang.Var

var A_arbace_box_plan_A_const_14 *lang.Var

var A_arbace_box_plan_A_const_15 *lang.Var

var A_arbace_box_plan_A_const_16 *lang.Keyword

var A_arbace_box_plan_A_const_17 *lang.Var

var A_arbace_box_plan_A_const_18 *lang.Var

var A_arbace_box_plan_A_const_19 *lang.Var

var A_arbace_box_plan_A_const_20 *lang.Keyword

var A_arbace_box_plan_A_const_21 *lang.Var

var A_arbace_box_plan_A_const_22 *lang.Var

var A_arbace_box_plan_A_const_23 *lang.Var

var A_arbace_box_plan_A_const_24 *lang.Var

var A_arbace_box_plan_A_const_25 any

var A_arbace_box_plan_A_const_26 *lang.Var

var A_arbace_box_plan_A_const_27 *lang.Keyword

var A_arbace_box_plan_A_const_28 *lang.Var

var A_arbace_box_plan_A_const_29 *lang.Var

var A_arbace_box_plan_A_const_30 *lang.Var

var A_arbace_box_plan_A_const_31 *lang.Var

var A_arbace_box_plan_A_const_32 *lang.Keyword

var A_arbace_box_plan_A_const_33 *lang.Keyword

var A_arbace_box_plan_A_const_34 *lang.Keyword

var A_arbace_box_plan_A_const_35 *lang.Keyword

var A_arbace_box_plan_A_const_36 *lang.Keyword

var A_arbace_box_plan_A_const_37 *lang.Var

var A_arbace_box_plan_A_const_38 *lang.Var

var A_arbace_box_plan_A_const_39 *lang.Var

var A_arbace_box_plan_A_const_40 *lang.Var

var A_arbace_box_plan_A_const_41 *lang.Keyword

var A_arbace_box_plan_A_const_42 any

var A_arbace_box_plan_A_const_43 any

var A_arbace_box_plan_A_const_44 *lang.Var

var A_arbace_box_plan_A_const_45 *lang.Var

var A_arbace_box_plan_A_const_46 any

var A_arbace_box_plan_A_const_47 any

var A_arbace_box_plan_A_const_48 *lang.Var

var A_arbace_box_plan_A_const_49 *lang.Var

var A_arbace_box_plan_A_const_50 *lang.Var

var A_arbace_box_plan_A_const_51 *lang.Var

var A_arbace_box_plan_A_const_52 *lang.Var

var A_arbace_box_plan_A_const_53 any

var A_arbace_box_plan_A_const_54 *lang.Var

var A_arbace_box_plan_A_const_55 *lang.Var

var A_arbace_box_plan_A_const_56 *lang.Var

var A_arbace_box_plan_A_const_57 *lang.Var

var A_arbace_box_plan_A_const_58 *lang.Var

var A_arbace_box_plan_A_const_59 any

var A_arbace_box_plan_A_const_60 *lang.Var

var A_arbace_box_plan_A_const_61 *lang.Var

var A_arbace_box_plan_A_const_62 *lang.Var

var A_arbace_box_plan_A_const_63 *lang.Var

var A_arbace_box_plan_A_const_64 *lang.Var

var A_arbace_box_plan_A_const_65 any

var A_arbace_box_plan_A_const_66 any

var A_arbace_box_plan_A_const_67 *lang.Var

var A_arbace_box_plan_A_const_68 any

var A_arbace_box_plan_A_const_69 any

var A_arbace_box_plan_A_const_70 *lang.Var

var A_arbace_box_plan_A_const_71 any

var A_arbace_box_plan_A_const_72 any

var A_arbace_box_plan_A_const_73 any

var A_arbace_box_plan_A_const_74 any

var A_arbace_box_plan_A_const_75 any

var A_arbace_box_plan_A_const_76 *lang.Keyword

var A_arbace_box_plan_A_const_77 *lang.Var

var A_arbace_box_plan_A_const_78 any

var A_arbace_box_plan_A_const_79 any

var A_arbace_box_plan_A_const_80 *lang.Keyword

var A_arbace_box_plan_A_const_81 any

var A_arbace_box_plan_A_const_82 any

var A_arbace_box_plan_A_const_83 *lang.Var

var A_arbace_box_plan_A_const_84 *lang.Var

var A_arbace_box_plan_A_const_85 any

var A_arbace_box_plan_A_const_86 *lang.Var

var A_arbace_box_plan_A_const_87 *lang.Var

var A_arbace_box_plan_A_const_88 any

var A_arbace_box_plan_A_const_89 *lang.Var

var A_arbace_box_plan_A_const_90 *lang.Var

var A_arbace_box_plan_A_const_91 *lang.Var

var A_arbace_box_plan_A_const_92 *lang.Var

var A_arbace_box_plan_A_const_93 *lang.Var

var A_arbace_box_plan_A_const_94 *lang.Var

var A_arbace_box_plan_A_const_95 any

var A_arbace_box_plan_A_const_96 *lang.Var

var A_arbace_box_plan_A_const_97 *lang.Var

var A_arbace_box_plan_A_const_98 any

var A_arbace_box_plan_A_const_99 any

var A_arbace_box_plan_A_const_100 any

var A_arbace_box_plan_A_const_101 *lang.Keyword

var A_arbace_box_plan_A_const_102 *lang.Keyword

var A_arbace_box_plan_A_const_103 *lang.Keyword

var A_arbace_box_plan_A_const_104 any

var A_arbace_box_plan_A_const_105 *lang.Var

var A_arbace_box_plan_A_const_106 *lang.Keyword

var A_arbace_box_plan_A_const_107 *lang.Keyword

var A_arbace_box_plan_A_const_108 *lang.Keyword

var A_arbace_box_plan_A_const_109 *lang.Var

var A_arbace_box_plan_A_const_110 *lang.Var

var A_arbace_box_plan_A_const_111 *lang.Keyword

var A_arbace_box_plan_A_const_112 *lang.Keyword

var A_arbace_box_plan_A_const_113 *lang.Var

var A_arbace_box_plan_A_const_114 *lang.Keyword

var A_arbace_box_plan_A_const_115 any

var A_arbace_box_plan_A_const_116 any

var A_arbace_box_plan_A_const_117 *lang.Var

var A_arbace_box_plan_A_const_118 *lang.Var

var A_arbace_box_plan_A_const_119 *lang.Var

var A_arbace_box_plan_A_const_120 *lang.Var

var A_arbace_box_plan_A_const_121 *lang.Var

var A_arbace_box_plan_A_const_122 any

var A_arbace_box_plan_A_const_123 *lang.Var

var A_arbace_box_plan_A_const_124 *lang.Var

var A_arbace_box_plan_A_const_125 *lang.Var

var A_arbace_box_plan_A_const_126 any

var A_arbace_box_plan_A_const_127 any

var A_arbace_box_plan_A_const_128 *lang.Var

var A_arbace_box_plan_A_const_129 *lang.Var

var A_arbace_box_plan_A_const_130 *lang.Var

var A_arbace_box_plan_A_const_131 *lang.Var

var A_arbace_box_plan_A_const_132 *lang.Var

var A_arbace_box_plan_A_const_133 *lang.Var

var A_arbace_box_plan_A_const_134 any

var A_arbace_box_plan_A_const_135 *lang.Var

var A_arbace_box_plan_A_const_136 *lang.Var

var A_arbace_box_plan_A_const_137 *lang.Var

var A_arbace_box_plan_A_const_138 any

var A_arbace_box_plan_A_const_139 any

var A_arbace_box_plan_A_const_140 *lang.Var

var A_arbace_box_plan_A_const_141 *lang.Var

var A_arbace_box_plan_A_const_142 *lang.Keyword

var A_arbace_box_plan_A_const_143 *lang.Var

var A_arbace_box_plan_A_const_144 *lang.Var

var A_arbace_box_plan_A_const_145 *lang.Keyword

var A_arbace_box_plan_A_const_146 *lang.Keyword

var A_arbace_box_plan_A_const_147 *lang.Keyword

var A_arbace_box_plan_A_const_148 *lang.Var

var A_arbace_box_plan_A_const_149 *lang.Keyword

var A_arbace_box_plan_A_const_150 *lang.Keyword

var A_arbace_box_plan_A_const_151 *lang.Var

var A_arbace_box_plan_A_const_152 any

var A_arbace_box_plan_A_const_153 *lang.Keyword

var A_arbace_box_plan_A_const_154 any

var A_arbace_box_plan_A_const_155 *lang.Var

var A_arbace_box_plan_A_const_156 *lang.Var

var A_arbace_box_plan_A_const_157 *lang.Var

var A_arbace_box_plan_A_const_158 *lang.Var

var A_arbace_box_plan_A_const_159 *lang.Var

var A_arbace_box_plan_A_const_160 *lang.Var

var A_arbace_box_plan_A_const_161 *lang.Keyword

var A_arbace_box_plan_A_const_162 *lang.Var

var A_arbace_box_plan_A_const_163 *lang.Keyword

var A_arbace_box_plan_A_const_164 *lang.Keyword

var A_arbace_box_plan_A_const_165 *lang.Keyword

var A_arbace_box_plan_A_const_166 *lang.Keyword

var A_arbace_box_plan_A_const_167 *lang.Keyword

var A_arbace_box_plan_A_const_168 *lang.Keyword

var A_arbace_box_plan_A_const_169 *lang.Var

var A_arbace_box_plan_A_const_170 *lang.Var

var A_arbace_box_plan_A_const_171 *lang.Var

var A_arbace_box_plan_A_const_172 *lang.Var

var A_arbace_box_plan_A_init jrt.ClassInit

func A_arbace_box_plan_A_Init() { if !A_arbace_box_plan_A_init.Done() { A_arbace_box_plan_A_init.Run(A_arbace_box_plan_A_clinit) } }

func A_arbace_box_plan_A_clinit() { A_arbace_box_plan_A_clinit_p0(); A_arbace_box_plan_A_clinit_p1(); A_arbace_box_plan_A_clinit_p2(); A_arbace_box_plan_A_clinit_p3(); A_arbace_box_plan_A_clinit_p4(); A_arbace_box_plan_A_clinit_p5(); A_arbace_box_plan_A_clinit_p6(); A_arbace_box_plan_A_clinit_p7(); A_arbace_box_plan_A_clinit_p8(); A_arbace_box_plan_A_clinit_p9(); A_arbace_box_plan_A_clinit_p10(); A_arbace_box_plan_A_clinit_p11(); A_arbace_box_plan_A_clinit_p12(); A_arbace_box_plan_A_clinit_p13() }

func A_arbace_box_plan_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_plan_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 215); A_arbace_box_plan_A_const_0 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[42]); A_arbace_box_plan_A_const_1 = A_arbace_box_plan_A_const_pool.A[43]; A_arbace_box_plan_A_const_2 = A_arbace_box_plan_A_const_pool.A[44]; A_arbace_box_plan_A_const_3 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[45]); A_arbace_box_plan_A_const_4 = A_arbace_box_plan_A_const_pool.A[46]; A_arbace_box_plan_A_const_5 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[47]); A_arbace_box_plan_A_const_6 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[48]); A_arbace_box_plan_A_const_7 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[49]); A_arbace_box_plan_A_const_8 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[50]); A_arbace_box_plan_A_const_9 = A_arbace_box_plan_A_const_pool.A[51]; A_arbace_box_plan_A_const_10 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[52]); A_arbace_box_plan_A_const_11 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[53]) }

func A_arbace_box_plan_A_clinit_p1() { A_arbace_box_plan_A_const_12 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[54]); A_arbace_box_plan_A_const_13 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[55]); A_arbace_box_plan_A_const_14 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[56]); A_arbace_box_plan_A_const_15 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[57]); A_arbace_box_plan_A_const_16 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[58]); A_arbace_box_plan_A_const_17 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[59]); A_arbace_box_plan_A_const_18 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[60]); A_arbace_box_plan_A_const_19 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[61]); A_arbace_box_plan_A_const_20 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[62]); A_arbace_box_plan_A_const_21 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[63]); A_arbace_box_plan_A_const_22 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[64]); A_arbace_box_plan_A_const_23 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[65]) }

func A_arbace_box_plan_A_clinit_p2() { A_arbace_box_plan_A_const_24 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[66]); A_arbace_box_plan_A_const_25 = A_arbace_box_plan_A_const_pool.A[67]; A_arbace_box_plan_A_const_26 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[68]); A_arbace_box_plan_A_const_27 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[69]); A_arbace_box_plan_A_const_28 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[70]); A_arbace_box_plan_A_const_29 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[71]); A_arbace_box_plan_A_const_30 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[72]); A_arbace_box_plan_A_const_31 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[73]); A_arbace_box_plan_A_const_32 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[74]); A_arbace_box_plan_A_const_33 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[75]); A_arbace_box_plan_A_const_34 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[76]); A_arbace_box_plan_A_const_35 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[77]) }

func A_arbace_box_plan_A_clinit_p3() { A_arbace_box_plan_A_const_36 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[78]); A_arbace_box_plan_A_const_37 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[79]); A_arbace_box_plan_A_const_38 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[80]); A_arbace_box_plan_A_const_39 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[81]); A_arbace_box_plan_A_const_40 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[82]); A_arbace_box_plan_A_const_41 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[83]); A_arbace_box_plan_A_const_42 = A_arbace_box_plan_A_const_pool.A[84]; A_arbace_box_plan_A_const_43 = A_arbace_box_plan_A_const_pool.A[85]; A_arbace_box_plan_A_const_44 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[86]); A_arbace_box_plan_A_const_45 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[87]); A_arbace_box_plan_A_const_46 = A_arbace_box_plan_A_const_pool.A[88]; A_arbace_box_plan_A_const_47 = A_arbace_box_plan_A_const_pool.A[89]; A_arbace_box_plan_A_const_48 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[90]) }

func A_arbace_box_plan_A_clinit_p4() { A_arbace_box_plan_A_const_49 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[91]); A_arbace_box_plan_A_const_50 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[92]); A_arbace_box_plan_A_const_51 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[93]); A_arbace_box_plan_A_const_52 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[94]); A_arbace_box_plan_A_const_53 = A_arbace_box_plan_A_const_pool.A[95]; A_arbace_box_plan_A_const_54 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[96]); A_arbace_box_plan_A_const_55 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[97]); A_arbace_box_plan_A_const_56 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[98]); A_arbace_box_plan_A_const_57 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[99]); A_arbace_box_plan_A_const_58 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[100]); A_arbace_box_plan_A_const_59 = A_arbace_box_plan_A_const_pool.A[101]; A_arbace_box_plan_A_const_60 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[102]) }

func A_arbace_box_plan_A_clinit_p5() { A_arbace_box_plan_A_const_61 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[103]); A_arbace_box_plan_A_const_62 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[104]); A_arbace_box_plan_A_const_63 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[105]); A_arbace_box_plan_A_const_64 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[106]); A_arbace_box_plan_A_const_65 = A_arbace_box_plan_A_const_pool.A[107]; A_arbace_box_plan_A_const_66 = A_arbace_box_plan_A_const_pool.A[108]; A_arbace_box_plan_A_const_67 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[109]); A_arbace_box_plan_A_const_68 = A_arbace_box_plan_A_const_pool.A[110]; A_arbace_box_plan_A_const_69 = A_arbace_box_plan_A_const_pool.A[111]; A_arbace_box_plan_A_const_70 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[112]); A_arbace_box_plan_A_const_71 = A_arbace_box_plan_A_const_pool.A[113]; A_arbace_box_plan_A_const_72 = A_arbace_box_plan_A_const_pool.A[114]; A_arbace_box_plan_A_const_73 = A_arbace_box_plan_A_const_pool.A[115]; A_arbace_box_plan_A_const_74 = A_arbace_box_plan_A_const_pool.A[116] }

func A_arbace_box_plan_A_clinit_p6() { A_arbace_box_plan_A_const_75 = A_arbace_box_plan_A_const_pool.A[117]; A_arbace_box_plan_A_const_76 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[118]); A_arbace_box_plan_A_const_77 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[119]); A_arbace_box_plan_A_const_78 = A_arbace_box_plan_A_const_pool.A[120]; A_arbace_box_plan_A_const_79 = A_arbace_box_plan_A_const_pool.A[121]; A_arbace_box_plan_A_const_80 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[122]); A_arbace_box_plan_A_const_81 = A_arbace_box_plan_A_const_pool.A[123]; A_arbace_box_plan_A_const_82 = A_arbace_box_plan_A_const_pool.A[124]; A_arbace_box_plan_A_const_83 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[125]); A_arbace_box_plan_A_const_84 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[126]); A_arbace_box_plan_A_const_85 = A_arbace_box_plan_A_const_pool.A[127]; A_arbace_box_plan_A_const_86 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[128]); A_arbace_box_plan_A_const_87 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[129]) }

func A_arbace_box_plan_A_clinit_p7() { A_arbace_box_plan_A_const_88 = A_arbace_box_plan_A_const_pool.A[130]; A_arbace_box_plan_A_const_89 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[131]); A_arbace_box_plan_A_const_90 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[132]); A_arbace_box_plan_A_const_91 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[133]); A_arbace_box_plan_A_const_92 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[134]); A_arbace_box_plan_A_const_93 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[135]); A_arbace_box_plan_A_const_94 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[136]); A_arbace_box_plan_A_const_95 = A_arbace_box_plan_A_const_pool.A[137]; A_arbace_box_plan_A_const_96 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[138]); A_arbace_box_plan_A_const_97 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[139]); A_arbace_box_plan_A_const_98 = A_arbace_box_plan_A_const_pool.A[140]; A_arbace_box_plan_A_const_99 = A_arbace_box_plan_A_const_pool.A[141]; A_arbace_box_plan_A_const_100 = A_arbace_box_plan_A_const_pool.A[142] }

func A_arbace_box_plan_A_clinit_p8() { A_arbace_box_plan_A_const_101 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[143]); A_arbace_box_plan_A_const_102 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[144]); A_arbace_box_plan_A_const_103 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[145]); A_arbace_box_plan_A_const_104 = A_arbace_box_plan_A_const_pool.A[146]; A_arbace_box_plan_A_const_105 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[147]); A_arbace_box_plan_A_const_106 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[148]); A_arbace_box_plan_A_const_107 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[149]); A_arbace_box_plan_A_const_108 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[150]); A_arbace_box_plan_A_const_109 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[151]); A_arbace_box_plan_A_const_110 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[152]); A_arbace_box_plan_A_const_111 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[153]); A_arbace_box_plan_A_const_112 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[154]) }

func A_arbace_box_plan_A_clinit_p9() { A_arbace_box_plan_A_const_113 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[155]); A_arbace_box_plan_A_const_114 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[156]); A_arbace_box_plan_A_const_115 = A_arbace_box_plan_A_const_pool.A[157]; A_arbace_box_plan_A_const_116 = A_arbace_box_plan_A_const_pool.A[158]; A_arbace_box_plan_A_const_117 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[159]); A_arbace_box_plan_A_const_118 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[160]); A_arbace_box_plan_A_const_119 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[161]); A_arbace_box_plan_A_const_120 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[162]); A_arbace_box_plan_A_const_121 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[163]); A_arbace_box_plan_A_const_122 = A_arbace_box_plan_A_const_pool.A[164]; A_arbace_box_plan_A_const_123 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[165]); A_arbace_box_plan_A_const_124 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[166]) }

func A_arbace_box_plan_A_clinit_p10() { A_arbace_box_plan_A_const_125 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[167]); A_arbace_box_plan_A_const_126 = A_arbace_box_plan_A_const_pool.A[168]; A_arbace_box_plan_A_const_127 = A_arbace_box_plan_A_const_pool.A[169]; A_arbace_box_plan_A_const_128 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[170]); A_arbace_box_plan_A_const_129 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[171]); A_arbace_box_plan_A_const_130 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[172]); A_arbace_box_plan_A_const_131 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[173]); A_arbace_box_plan_A_const_132 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[174]); A_arbace_box_plan_A_const_133 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[175]); A_arbace_box_plan_A_const_134 = A_arbace_box_plan_A_const_pool.A[176]; A_arbace_box_plan_A_const_135 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[177]); A_arbace_box_plan_A_const_136 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[178]) }

func A_arbace_box_plan_A_clinit_p11() { A_arbace_box_plan_A_const_137 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[179]); A_arbace_box_plan_A_const_138 = A_arbace_box_plan_A_const_pool.A[180]; A_arbace_box_plan_A_const_139 = A_arbace_box_plan_A_const_pool.A[181]; A_arbace_box_plan_A_const_140 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[182]); A_arbace_box_plan_A_const_141 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[183]); A_arbace_box_plan_A_const_142 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[184]); A_arbace_box_plan_A_const_143 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[185]); A_arbace_box_plan_A_const_144 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[186]); A_arbace_box_plan_A_const_145 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[187]); A_arbace_box_plan_A_const_146 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[188]); A_arbace_box_plan_A_const_147 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[189]); A_arbace_box_plan_A_const_148 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[190]) }

func A_arbace_box_plan_A_clinit_p12() { A_arbace_box_plan_A_const_149 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[191]); A_arbace_box_plan_A_const_150 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[192]); A_arbace_box_plan_A_const_151 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[193]); A_arbace_box_plan_A_const_152 = A_arbace_box_plan_A_const_pool.A[194]; A_arbace_box_plan_A_const_153 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[195]); A_arbace_box_plan_A_const_154 = A_arbace_box_plan_A_const_pool.A[196]; A_arbace_box_plan_A_const_155 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[197]); A_arbace_box_plan_A_const_156 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[198]); A_arbace_box_plan_A_const_157 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[199]); A_arbace_box_plan_A_const_158 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[200]); A_arbace_box_plan_A_const_159 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[201]); A_arbace_box_plan_A_const_160 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[202]) }

func A_arbace_box_plan_A_clinit_p13() { A_arbace_box_plan_A_const_161 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[203]); A_arbace_box_plan_A_const_162 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[204]); A_arbace_box_plan_A_const_163 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[205]); A_arbace_box_plan_A_const_164 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[206]); A_arbace_box_plan_A_const_165 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[207]); A_arbace_box_plan_A_const_166 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[208]); A_arbace_box_plan_A_const_167 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[209]); A_arbace_box_plan_A_const_168 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[210]); A_arbace_box_plan_A_const_169 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[211]); A_arbace_box_plan_A_const_170 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[212]); A_arbace_box_plan_A_const_171 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[213]); A_arbace_box_plan_A_const_172 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[214]) }

func A_arbace_box_plan_A_New() *A_arbace_box_plan_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan_A) Ctor() {}

func (t *A_arbace_box_plan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan_A_class }

func (t *A_arbace_box_plan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_plan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan_A); return ok }

func A_arbace_box_plan_A_Cast(x any) *A_arbace_box_plan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan_A_class)) }; return v }



type A_arbace_box_plan_dir_at_A struct{ j2g_header uint64 }

var A_arbace_box_plan_dir_at_A_fn_class *jrt.Class



type A_arbace_box_plan_dir_at_fn__1305000014_A struct{ j2g_header uint64 }

var A_arbace_box_plan_dir_at_fn__1305000014_A_fn_class *jrt.Class



type A_arbace_box_plan_embed_files_A struct{ j2g_header uint64 }

var A_arbace_box_plan_embed_files_A_fn_class *jrt.Class



type A_arbace_box_plan_embed_files_walk__1305000114_A struct{ j2g_header uint64; F_all any }

var A_arbace_box_plan_embed_files_walk__1305000114_A_fn_class *jrt.Class



type A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A struct{ j2g_header uint64; F_walk, F_prefix, F_all any }

var A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_fn_class *jrt.Class



type A_arbace_box_plan_entries_A struct{ j2g_header uint64 }

var A_arbace_box_plan_entries_A_fn_class *jrt.Class



type A_arbace_box_plan_eval1305000004_A struct{ jrt.Object }

func A_arbace_box_plan_eval1305000004_A_New() *A_arbace_box_plan_eval1305000004_A { t := &A_arbace_box_plan_eval1305000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan_eval1305000004_A) Ctor() {}

func (t *A_arbace_box_plan_eval1305000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan_eval1305000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan_eval1305000004_A_class }

func (t *A_arbace_box_plan_eval1305000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan_eval1305000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_plan_eval1305000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan_eval1305000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan_eval1305000004_A); return ok }

func A_arbace_box_plan_eval1305000004_A_Cast(x any) *A_arbace_box_plan_eval1305000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan_eval1305000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan_eval1305000004_A_class)) }; return v }



type A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A struct{ j2g_header uint64 }

var A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_fn_class *jrt.Class



type A_arbace_box_plan_eval1305000008_A struct{ jrt.Object }

func A_arbace_box_plan_eval1305000008_A_New() *A_arbace_box_plan_eval1305000008_A { t := &A_arbace_box_plan_eval1305000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan_eval1305000008_A) Ctor() {}

func (t *A_arbace_box_plan_eval1305000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan_eval1305000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan_eval1305000008_A_class }

func (t *A_arbace_box_plan_eval1305000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan_eval1305000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_plan_eval1305000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan_eval1305000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan_eval1305000008_A); return ok }

func A_arbace_box_plan_eval1305000008_A_Cast(x any) *A_arbace_box_plan_eval1305000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan_eval1305000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan_eval1305000008_A_class)) }; return v }



type A_arbace_box_plan_eval1305000008_fn__1305000009_A struct{ j2g_header uint64 }

var A_arbace_box_plan_eval1305000008_fn__1305000009_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_A struct{ j2g_header uint64 }

var A_arbace_box_plan_eval_expr_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_and_e__1305000039_A struct{ j2g_header uint64; F_next_t, F_peek_t, F_not_e any }

var A_arbace_box_plan_eval_expr_and_e__1305000039_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_next_t__1305000035_A struct{ j2g_header uint64; F_toks any }

var A_arbace_box_plan_eval_expr_next_t__1305000035_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_not_e__1305000041_A struct{ j2g_header uint64; F_or_e, F_next_t, F_s, F_match_QMARK_ any }

var A_arbace_box_plan_eval_expr_not_e__1305000041_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_or_e__1305000037_A struct{ j2g_header uint64; F_next_t, F_peek_t, F_and_e any }

var A_arbace_box_plan_eval_expr_or_e__1305000037_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_peek_t__1305000033_A struct{ j2g_header uint64; F_toks any }

var A_arbace_box_plan_eval_expr_peek_t__1305000033_A_fn_class *jrt.Class



type A_arbace_box_plan_expr_tokens_A struct{ j2g_header uint64 }

var A_arbace_box_plan_expr_tokens_A_fn_class *jrt.Class



type A_arbace_box_plan_fail_A struct{ j2g_header uint64 }

var A_arbace_box_plan_fail_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000070_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000070_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_A struct{ j2g_header uint64; F_toks any }

var A_arbace_box_plan_go_info_fn__1305000072_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000090_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000090_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_fn_class *jrt.Class



type A_arbace_box_plan_go_mod_lang_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_mod_lang_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_tokens_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_A struct{ j2g_header uint64; F_n int32; F_s any }

var A_arbace_box_plan_go_tokens_step__1305000055_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A struct{ j2g_header uint64; F_i any; F_n int32; F_step, F_s, F_last any }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A struct{ j2g_header uint64; F_i, F_sb, F_s any }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A struct{ j2g_header uint64; F_i any; F_n int32; F_s any }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_fn_class *jrt.Class



type A_arbace_box_plan_header_build_A struct{ j2g_header uint64 }

var A_arbace_box_plan_header_build_A_fn_class *jrt.Class



type A_arbace_box_plan_locate_A struct{ j2g_header uint64 }

var A_arbace_box_plan_locate_A_fn_class *jrt.Class



type A_arbace_box_plan_locate_fn__1305000102_A struct{ j2g_header uint64; F_p any }

var A_arbace_box_plan_locate_fn__1305000102_A_fn_class *jrt.Class



type A_arbace_box_plan_name_ok_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_plan_name_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_A struct{ j2g_header uint64 }

var A_arbace_box_plan_package_info_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_fn__1305000184_A struct{ j2g_header uint64 }

var A_arbace_box_plan_package_info_fn__1305000184_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000130__1305000134_A struct{ j2g_header uint64; F_match_QMARK_ any }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A struct{ j2g_header uint64; F_s__1305000131, F_match_QMARK_, F_iter__1305000130 any }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A struct{ j2g_header uint64; F_b__1305000133, F_match_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000152__1305000156_A struct{ j2g_header uint64; F_match_QMARK_, F_path any }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A struct{ j2g_header uint64; F_s__1305000153, F_match_QMARK_, F_path, F_iter__1305000152 any }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A struct{ j2g_header uint64; F_b__1305000155, F_match_QMARK_, F_path any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000168__1305000172_A struct{ j2g_header uint64; F_match_QMARK_ any }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A struct{ j2g_header uint64; F_iter__1305000168, F_match_QMARK_, F_s__1305000169 any }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A struct{ j2g_header uint64; F_match_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1305000171 any }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000189__1305000193_A struct{ j2g_header uint64; F_dir, F_what any }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A struct{ j2g_header uint64; F_iter__1305000189, F_dir, F_s__1305000190, F_what any }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A struct{ j2g_header uint64; F_dir, F_what any; F_size__1927001038__auto__ int32; F_b__1305000192, F_c__1927001037__auto__ any }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_A struct{ j2g_header uint64 }

var A_arbace_box_plan_plan_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_fn__1305000260_A struct{ j2g_header uint64 }

var A_arbace_box_plan_plan_fn__1305000260_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_visit__1305000250_A struct{ j2g_header uint64; F_order, F_match_QMARK_, F_done, F_cfg any }

var A_arbace_box_plan_plan_visit__1305000250_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A struct{ j2g_header uint64; F_stack, F_visit, F_p, F_loc any }

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A struct{ j2g_header uint64 }

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_A struct{ j2g_header uint64 }

var A_arbace_box_plan_src_tree_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A struct{ j2g_header uint64; F_sub any }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A struct{ j2g_header uint64; F_s__1305000228, F_iter__1305000227, F_sub any }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A struct{ j2g_header uint64; F_b__1305000230, F_sub any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_A struct{ j2g_header uint64; F_embedded any }

var A_arbace_box_plan_src_tree_sub__1305000203_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A struct{ j2g_header uint64; F_sub, F_embedded, F_prefix any }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A struct{ j2g_header uint64; F_sub, F_s__1305000205, F_embedded, F_iter__1305000204, F_prefix any }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A struct{ j2g_header uint64; F_sub, F_embedded, F_b__1305000207, F_prefix any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_fn_class *jrt.Class



type A_arbace_box_plan_tag_fn_A struct{ j2g_header uint64 }

var A_arbace_box_plan_tag_fn_A_fn_class *jrt.Class



type A_arbace_box_plan_tag_fn_fn__1305000028_A struct{ j2g_header uint64; F_goos, F_on any }

var A_arbace_box_plan_tag_fn_fn__1305000028_A_fn_class *jrt.Class



type A_arbace_box_plan_text_A struct{ j2g_header uint64 }

var A_arbace_box_plan_text_A_fn_class *jrt.Class
