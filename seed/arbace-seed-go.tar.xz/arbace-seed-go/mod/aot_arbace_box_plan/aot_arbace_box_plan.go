//line aot_arbace_box_plan.ae:1
package aot_arbace_box_plan

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_New() *A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_plan_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_box_plan_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_box_plan_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_3, A_arbace_box_plan_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :4:1
func A_arbace_box_plan_eval1305000008_fn__1305000009_A_New() *A_arbace_box_plan_eval1305000008_fn__1305000009_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval1305000008_fn__1305000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_plan_eval1305000008_fn__1305000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_plan_eval1305000008_fn__1305000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_box_plan_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_box_plan_A_const_9), A_arbace_box_plan_A_const_7.GetRawRoot__O(), A_arbace_box_plan_A_const_8) }






























func A_arbace_box_plan_fail_A_New() *A_arbace_box_plan_fail_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_fail_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_box_plan_fail_A) Ctor() {}
//line :35:1
func (t *A_arbace_box_plan_fail_A) Invoke_O_O_O__O(self, msg__0, data__1 any) any { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_box_plan_A_const_10.GetRawRoot__O()).Invoke_O_O__O(msg__0, lang.IFn_Cast(A_arbace_box_plan_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(data__1, A_arbace_box_plan_A_const_12, jrt.Boolean_TRUE.Ref()))))) }







func A_arbace_box_plan_entries_A_New() *A_arbace_box_plan_entries_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_entries_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_box_plan_entries_A) Ctor() {}
//line :43:1
func (t *A_arbace_box_plan_entries_A) Invoke_O_O__O(self, h__0 any) any { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_box_plan_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_box_plan_A_const_15.Get__O()), h__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var m__3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_box_plan_A_const_13.GetRawRoot__O()).Invoke_O__O(h__0)
		if jrt.J2g_Truth(or__1927000174__auto____3) { m__3 = or__1927000174__auto____3 } else { m__3 = lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__0)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_16, h__0))) }
		lang.IFn_Cast(A_arbace_box_plan_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_box_plan_A_const_15.Get__O(), A_arbace_box_plan_A_const_11.GetRawRoot__O(), h__0, m__3)
//line :46:1
		return m__3 } }




func A_arbace_box_plan_dir_at_A_New() *A_arbace_box_plan_dir_at_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_dir_at_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_box_plan_dir_at_A) Ctor() {}
//line :51:1
func (t *A_arbace_box_plan_dir_at_A) Invoke_O_O_O__O(self, h__0, p__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_18.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_dir_at_fn__1305000014_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_box_plan_dir_at_fn__1305000014_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_box_plan_dir_at_fn__1305000014_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), h__0, lang.IFn_Cast(A_arbace_box_plan_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_23.GetRawRoot__O(), lang.IFn_Cast(A_arbace_box_plan_A_const_24.GetRawRoot__O()).Invoke_O_O__O(p__1, A_arbace_box_plan_A_const_25))) }
//line :54:1
func A_arbace_box_plan_dir_at_fn__1305000014_A_New() *A_arbace_box_plan_dir_at_fn__1305000014_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_dir_at_fn__1305000014_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_box_plan_dir_at_fn__1305000014_A) Ctor() {}
//line :54:1
func (t *A_arbace_box_plan_dir_at_fn__1305000014_A) Invoke_O_O_O__O(self, d__1, n__2 any) any { var vec__1305000015__3 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_box_plan_A_const_19.GetRawRoot__O()).Invoke_O__O(d__1), n__2); var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000015__3, lang.RT_IntCast_J__I_NoInit(1), nil); if

	lang.Util_Equiv_O_O__Z_NoInit(k__4, A_arbace_box_plan_A_const_20) { return eh__5 } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_21.GetRawRoot__O()).Invoke_O__O(nil) } }



func A_arbace_box_plan_text_A_New() *A_arbace_box_plan_text_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_text_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_box_plan_text_A) Ctor() {}
//line :60:1
func (t *A_arbace_box_plan_text_A) Invoke_O_O__O(self, p__1305000020__0 any) any { var vec__1305000021__2 any = p__1305000020__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000021__2, lang.RT_IntCast_J__I_NoInit(0), nil); var h__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000021__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_box_plan_A_const_26.GetRawRoot__O()).Invoke_O__O(h__4); _ = ___3; if
											jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_107, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__4)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_27, h__4))) } }

















func A_arbace_box_plan_tag_fn_A_New() *A_arbace_box_plan_tag_fn_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_tag_fn_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_box_plan_tag_fn_A) Ctor() {}
//line :79:1
func (t *A_arbace_box_plan_tag_fn_A) Invoke_O_O__O(self, p__1305000025__0 any) any { var map__1305000026__2 any = p__1305000025__0; var map__1305000026__3 any; if lang.ISeq_InstanceOf(map__1305000026__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1305000026__2)) { map__1305000026__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_plan_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1305000026__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1305000026__2)) { map__1305000026__3 = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1305000026__2) } else { map__1305000026__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000026__3 = map__1305000026__2 }; var goos__4 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_32); var goarch__5 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_33); var tool_tags__6 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_34); var release_tags__7 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_35); var tags__8 any = lang.RT_Get_O_O__O_NoInit(map__1305000026__3, A_arbace_box_plan_A_const_36); var on__9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_41.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(goos__4, goarch__5, Lit_103), tool_tags__6, release_tags__7, tags__8)); var tmp1 any = A_arbace_box_plan_tag_fn_fn__1305000028_A_New_O_O(goos__4, on__9); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_box_plan_tag_fn_fn__1305000028_A_fn_class; if



	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_box_plan_tag_fn_fn__1305000028_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :83:1
func A_arbace_box_plan_tag_fn_fn__1305000028_A_New_O_O(p0, p1 any) *A_arbace_box_plan_tag_fn_fn__1305000028_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_tag_fn_fn__1305000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :83:1
func (t *A_arbace_box_plan_tag_fn_fn__1305000028_A) Ctor_O_O(c__goos, c__on any) { t.F_goos = c__goos; t.F_on = c__on }
//line :83:1
func (t *A_arbace_box_plan_tag_fn_fn__1305000028_A) Invoke_O_O__O(self, t__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_105) { return lang.IFn_Cast(A_arbace_box_plan_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_40.GetRawRoot__O(), t.F_goos) } else { if lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_106) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_box_plan_A_const_39 != nil {

		return lang.IFn_Cast(A_arbace_box_plan_A_const_38.GetRawRoot__O()).Invoke_O_O__O(t.F_on, t__1) } else {
//line :84:1
			return nil
		}
	}
	} }
func A_arbace_box_plan_name_ok_QMARK__A_New() *A_arbace_box_plan_name_ok_QMARK__A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_name_ok_QMARK__A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_box_plan_name_ok_QMARK__A) Ctor() {}
//line :88:1
func (t *A_arbace_box_plan_name_ok_QMARK__A) Invoke_O_O_O__O(self, match_QMARK___0, n__1 any) any { var n__3 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_24.GetRawRoot__O()).Invoke_O_O_O__O(n__1, A_arbace_box_plan_A_const_47, A_arbace_box_plan_A_const_48)); var i__4 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(n__3, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_11)); var tmp1 bool; var na_3 any = i__4; if




	jrt.Long_InstanceOf(na_3) { var n0_4 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); tmp1 = n0_4 < 0 } else { if jrt.Double_InstanceOf(na_3) { var n0_4_2 float64 = jrt.NN(jrt.Double_Cast(na_3)).DoubleValue__D(); tmp1 = n0_4_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_3) } }; if tmp1 { return jrt.Boolean_TRUE.Ref() } else { var l__5 any = lang.IFn_Cast(A_arbace_box_plan_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_24.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()).Invoke_O_O__O(n__3, i__4), A_arbace_box_plan_A_const_50, A_arbace_box_plan_A_const_51)); var l__6 any


		if lang.Util_Equiv_O_O__Z_NoInit(Lit_62, lang.IFn_Cast(A_arbace_box_plan_A_const_43.GetRawRoot__O()).Invoke_O__O(l__5)) { l__6 = lang.IFn_Cast(A_arbace_box_plan_A_const_44.GetRawRoot__O()).Invoke_O__O(l__5) } else { l__6 = l__5 }
//line :93:1
		var c__7 int32 = lang.RT_Count_O__I_NoInit(l__6); var tmp2 any; var and__1927000168__auto____8 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(c__7), 2)




		if and__1927000168__auto____8 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 2)).Ref())); if jrt.J2g_Truth(and__1927000168__auto____9) { tmp2 = lang.IFn_Cast(A_arbace_box_plan_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp2) { var and__1927000168__auto____8_2 any = lang.IFn_Cast(match_QMARK___0).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 2)).Ref()))
			if jrt.J2g_Truth(and__1927000168__auto____8_2) { return lang.IFn_Cast(match_QMARK___0).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } else { return and__1927000168__auto____8_2 } } else {
//line :98:1
				var tmp3 any; var and__1927000168__auto____8_3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(c__7), 1)

				if and__1927000168__auto____8_3 { var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())); if jrt.J2g_Truth(or__1927000174__auto____9) { tmp3 = or__1927000174__auto____9 } else { tmp3 = lang.IFn_Cast(A_arbace_box_plan_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() }
//line :98:1
				if jrt.J2g_Truth(tmp3) {


					return lang.IFn_Cast(match_QMARK___0).Invoke_O__O(lang.IFn_Cast(l__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(c__7), 1)).Ref())) } else {
//line :98:1
						if A_arbace_box_plan_A_const_39 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } }





func A_arbace_box_plan_expr_tokens_A_New() *A_arbace_box_plan_expr_tokens_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_expr_tokens_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_box_plan_expr_tokens_A) Ctor() {}
//line :104:1
func (t *A_arbace_box_plan_expr_tokens_A) Invoke_O_O__O(self, s__0 any) any {
	return lang.IFn_Cast(A_arbace_box_plan_A_const_52.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_53, s__0)
}
func A_arbace_box_plan_eval_expr_A_New() *A_arbace_box_plan_eval_expr_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_box_plan_eval_expr_A) Ctor() {}
//line :107:1
func (t *A_arbace_box_plan_eval_expr_A) Invoke_O_O_O__O(self, match_QMARK___0, s__1 any) any { var toks__3 any = lang.IFn_Cast(A_arbace_box_plan_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_59.GetRawRoot__O()).Invoke_O__O(s__1)); var peek_t__4 any; var tmp1 any = A_arbace_box_plan_eval_expr_peek_t__1305000033_A_New_O(toks__3); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_box_plan_eval_expr_peek_t__1305000033_A_fn_class; if


	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_box_plan_eval_expr_peek_t__1305000033_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; peek_t__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var next_t__5 any; var tmp3 any = /*line :107:1*/A_arbace_box_plan_eval_expr_next_t__1305000035_A_New_O(toks__3); var tmp4 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_box_plan_eval_expr_next_t__1305000035_A_fn_class; if


	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_box_plan_eval_expr_next_t__1305000035_A_fn_class = fncls__6d; tmp4 = fncls__6d } else { tmp4 = fncls__6 }; next_t__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var body_or_e__6 /*line :107:1*/*A_arbace_box_plan_eval_expr_or_e__1305000037_A = A_arbace_box_plan_eval_expr_or_e__1305000037_A_New_O_O_O(next_t__5, peek_t__4, nil); var body_and_e__7 *A_arbace_box_plan_eval_expr_and_e__1305000039_A = A_arbace_box_plan_eval_expr_and_e__1305000039_A_New_O_O_O(next_t__5, peek_t__4, nil); var body_not_e__8 *A_arbace_box_plan_eval_expr_not_e__1305000041_A = A_arbace_box_plan_eval_expr_not_e__1305000041_A_New_O_O_O_O(nil, next_t__5, s__1, match_QMARK___0); var or_e__6 any; var tmp5 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_box_plan_eval_expr_or_e__1305000037_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_box_plan_eval_expr_or_e__1305000037_A_fn_class = fncls__7d; tmp5 = fncls__7d } else { tmp5 = fncls__7 }; or_e__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_or_e__6), tmp5, nil); var and_e__7 any; var tmp6 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_box_plan_eval_expr_and_e__1305000039_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_box_plan_eval_expr_and_e__1305000039_A_fn_class = fncls__8d; tmp6 = fncls__8d } else { tmp6 = fncls__8 }; and_e__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_and_e__7), tmp6, nil); var not_e__8 any; var tmp7 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_box_plan_eval_expr_not_e__1305000041_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_box_plan_eval_expr_not_e__1305000041_A_fn_class = fncls__9d; tmp7 = fncls__9d } else { tmp7 = fncls__9 }; not_e__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_not_e__8), tmp7, nil); body_or_e__6.F_and_e = and_e__7; body_and_e__7.F_not_e = not_e__8; body_not_e__8.F_or_e = or_e__6; var v__9 any = lang.IFn_Cast(or_e__6).Invoke__O(); if













	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_6.GetRawRoot__O()).Invoke_O__O(toks__3))) { lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, s__1, nil)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) }; return v__9 }
//line :110:1
func A_arbace_box_plan_eval_expr_next_t__1305000035_A_New_O(p0 any) *A_arbace_box_plan_eval_expr_next_t__1305000035_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_next_t__1305000035_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_next_t__1305000035_A) Ctor_O(c__toks any) { t.F_toks = c__toks }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_next_t__1305000035_A) Invoke_O__O(self any) any { var t__1 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_toks)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_17.GetRawRoot__O()); var tmp2 any = t.F_toks;

	tmp1.Invoke_O_O__O(tmp2, A_arbace_box_plan_A_const_55.GetRawRoot__O()); return t__1 }
//line :110:1
func A_arbace_box_plan_eval_expr_peek_t__1305000033_A_New_O(p0 any) *A_arbace_box_plan_eval_expr_peek_t__1305000033_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_peek_t__1305000033_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_peek_t__1305000033_A) Ctor_O(c__toks any) { t.F_toks = c__toks }
//line :110:1
func (t *A_arbace_box_plan_eval_expr_peek_t__1305000033_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_toks))
}
func A_arbace_box_plan_eval_expr_and_e__1305000039_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_eval_expr_and_e__1305000039_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_and_e__1305000039_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_and_e__1305000039_A) Ctor_O_O_O(c__next_t, c__peek_t, c__not_e any) { t.F_next_t = c__next_t; t.F_peek_t = c__peek_t; t.F_not_e = c__not_e }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_and_e__1305000039_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_not_e).Invoke__O(); L1: for {
											if lang.Util_Equiv_O_O__Z_NoInit(Lit_20, lang.IFn_Cast(t.F_peek_t).Invoke__O()) { lang.IFn_Cast(t.F_next_t).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_not_e).Invoke__O(); var tmp1 any; var and__1927000168__auto____3 any = v__1; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = w__2 } else { tmp1 = and__1927000168__auto____3 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :113:1*/panic("j2g: unreachable") }
//line :113:1
func A_arbace_box_plan_eval_expr_not_e__1305000041_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_eval_expr_not_e__1305000041_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_not_e__1305000041_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_not_e__1305000041_A) Ctor_O_O_O_O(c__or_e, c__next_t, c__s, c__match_QMARK_ any) { t.F_or_e = c__or_e; t.F_next_t = c__next_t; t.F_s = c__s; t.F_match_QMARK_ = c__match_QMARK_ }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_not_e__1305000041_A) Invoke_O__O(self any) any { var t__1 any = lang.IFn_Cast(t.F_next_t).Invoke__O(); if


	lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_21) { return lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(self).Invoke__O()) } else { if lang.Util_Equiv_O_O__Z_NoInit(t__1, Lit_22) { var v__2 any = lang.IFn_Cast(t.F_or_e).Invoke__O()
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_23, lang.IFn_Cast(t.F_next_t).Invoke__O()) { } else { lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil, Lit_25), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s, nil)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) }
//line :116:1
		return v__2 } else { var tmp1 any
			var and__1927000168__auto____2 any = t__1
			if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_box_plan_A_const_57.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_58, t__1) } else { tmp1 = and__1927000168__auto____2 }
//line :116:1
			if jrt.J2g_Truth(tmp1) {

				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_match_QMARK_).Invoke_O__O(t__1))).Ref() } else {
//line :116:1
					if A_arbace_box_plan_A_const_39 != nil {


						return lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s, nil)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) } else {
//line :116:1
							return nil } } } } }
//line :113:1
func A_arbace_box_plan_eval_expr_or_e__1305000037_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_eval_expr_or_e__1305000037_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_eval_expr_or_e__1305000037_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_or_e__1305000037_A) Ctor_O_O_O(c__next_t, c__peek_t, c__and_e any) { t.F_next_t = c__next_t; t.F_peek_t = c__peek_t; t.F_and_e = c__and_e }
//line :113:1
func (t *A_arbace_box_plan_eval_expr_or_e__1305000037_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_and_e).Invoke__O(); L1: for { if lang.Util_Equiv_O_O__Z_NoInit(Lit_27, lang.IFn_Cast(t.F_peek_t).Invoke__O()) { lang.IFn_Cast(t.F_next_t).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_and_e).Invoke__O(); var tmp1 any; var or__1927000174__auto____3 any = v__1; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = w__2 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; panic("j2g: unreachable") }










func A_arbace_box_plan_header_build_A_New() *A_arbace_box_plan_header_build_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_header_build_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_box_plan_header_build_A) Ctor() {}
//line :124:1
func (t *A_arbace_box_plan_header_build_A) Invoke_O_O__O(self, s__0 any) any { { var G__1305000047__2_ any = lang.IFn_Cast(A_arbace_box_plan_A_const_60.GetRawRoot__O()).Invoke_O__O(s__0); var vec__1305000048__3 any = G__1305000047__2_; var seq__1305000049__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(vec__1305000048__3); var first__1305000050__5 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1305000049__4); var seq__1305000049__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_28.GetRawRoot__O()).Invoke_O__O(seq__1305000049__4); var l__7 any = first__1305000050__5; var ls__8 any = seq__1305000049__6; var in_star__9 any = jrt.Boolean_FALSE.Ref(); var G__1305000047__10_ any = G__1305000047__2_; var in_star__11 any = in_star__9; _ = l__7; _ = ls__8; L1: for { var vec__1305000051__12 any = G__1305000047__10_; var seq__1305000052__13 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(vec__1305000051__12); var first__1305000053__14 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1305000052__13); var seq__1305000052__15 any = lang.IFn_Cast(A_arbace_box_plan_A_const_28.GetRawRoot__O()).Invoke_O__O(seq__1305000052__13)
										var l__16 any = first__1305000053__14
										var ls__17 any = seq__1305000052__15
										var in_star__18 any = in_star__11

	if jrt.J2g_Truth(l__16) { var t__19 any = lang.IFn_Cast(A_arbace_box_plan_A_const_61.GetRawRoot__O()).Invoke_O__O(l__16)

		if jrt.J2g_Truth(in_star__18) {
			G__1305000047__10_, in_star__11 = ls__17, lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t__19, Lit_47)); continue L1 } else {
//line :131:1
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_62.GetRawRoot__O()).Invoke_O__O(t__19)) {

					G__1305000047__10_, in_star__11 = ls__17, jrt.Boolean_FALSE.Ref(); continue L1 } else {
//line :131:1
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(t__19, Lit_51)) {


							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_66, t__19)) {
								return lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()).Invoke_O_O__O(t__19, A_arbace_box_plan_A_const_67) } else {
									G__1305000047__10_, in_star__11 = ls__17, jrt.Boolean_FALSE.Ref(); continue L1 } } else {
//line :131:1
										if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(t__19, Lit_52)) {





											G__1305000047__10_, in_star__11 = ls__17, jrt.Boolean_FALSE.Ref(); continue L1 } else {
//line :131:1
												if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(t__19, Lit_53)) {






													G__1305000047__10_, in_star__11 = ls__17, lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_65.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()).Invoke_O_O__O(t__19, A_arbace_box_plan_A_const_48), Lit_47)); continue L1 } else {
//line :131:1
														if A_arbace_box_plan_A_const_39 != nil { return nil } else { return nil } } } } } } } else {
//line :129:1
															return nil } } }; /*line :124:1*/panic("j2g: unreachable") }



















func A_arbace_box_plan_go_tokens_A_New() *A_arbace_box_plan_go_tokens_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_box_plan_go_tokens_A) Ctor() {}
//line :144:1
func (t *A_arbace_box_plan_go_tokens_A) Invoke_O_O__O(self, s__0 any) any { var n__2 int32 = lang.RT_Count_O__I_NoInit(s__0); var body_step__3 *A_arbace_box_plan_go_tokens_step__1305000055_A = A_arbace_box_plan_go_tokens_step__1305000055_A_New_I_O(n__2, s__0); var step__3 any; var tmp1 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_box_plan_go_tokens_step__1305000055_A_fn_class = fncls__95d; tmp1 = fncls__95d } else { tmp1 = fncls__95 }; step__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_step__3), tmp1, nil); return /*line :180:1*/ lang.IFn_Cast(step__3).Invoke_O_O__O(A_arbace_box_plan_A_const_82, nil) }
//line :149:1
func A_arbace_box_plan_go_tokens_step__1305000055_A_New_I_O(p0 int32, p1 any) *A_arbace_box_plan_go_tokens_step__1305000055_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_A{}; t.Ctor_I_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_A) Ctor_I_O(c__n int32, c__s any) { t.F_n = c__n; t.F_s = c__s }
//line :149:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_A) Invoke_O_O_O__O(self, i__1, last__2 any) any { var tmp1 any = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_New_O_I_O_O_O(i__1, t.F_n, self, t.F_s, last__2); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_fn_class; if
													fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; return /*line :149:1*/ lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_New_O_I_O_O_O(p0 any, p1 int32, p2, p3, p4 any) *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A{}; t.Ctor_O_I_O_O_O(p0, p1, p2, p3, p4); return t }
//line :150:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A) Ctor_O_I_O_O_O(c__i any, c__n int32, c__step, c__s, c__last any) { t.F_i = c__i; t.F_n = c__n; t.F_step = c__step; t.F_s = c__s; t.F_last = c__last }
//line :150:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A) Invoke_O__O(self any) any {
	var tmp1 bool; var na_10 any = t.F_i; var na_11 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_10) { var n0_12 int64 = jrt.NN(jrt.Long_Cast(na_10)).LongValue__J(); var n1_13 int64 = na_11; tmp1 = n0_12 < n1_13 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_10, na_11) }; if tmp1 { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); var c__1 uint16 = jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(t.F_i))

		if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_68)).CharValue__C()) {
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_69).Invoke_O__O(t.F_last)) {
				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(t.F_step); var tmp5 jrt.Number_I; var na_64 any; var t_ any = t.F_i; t.F_i = nil; na_64 = t_; if jrt.Long_InstanceOf(na_64) { var n0_65 int64 = jrt.NN(jrt.Long_Cast(na_64)).LongValue__J(); if n0_65 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_64) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_65 + 1)) } } else { if jrt.Double_InstanceOf(na_64) { var n0_65_2 float64 = jrt.NN(jrt.Double_Cast(na_64)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_65_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_64) } }; return tmp3.Invoke_O_O__O(Lit_32, tmp4.Invoke_O_O__O(tmp5, Lit_32)) } else {
					var tmp6 lang.IFn = lang.IFn_Cast(t.F_step); var tmp7 jrt.Number_I; var na_66 any; var t__2 any = t.F_i; t.F_i = nil; na_66 = t__2; if jrt.Long_InstanceOf(na_66) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_66)).LongValue__J(); if n0_67 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_66) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_67 + 1)) } } else { if jrt.Double_InstanceOf(na_66) { var n0_67_2 float64 = jrt.NN(jrt.Double_Cast(na_66)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_67_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_66) } }; var tmp8 any = tmp7; var tmp9 any; var t__3 any = t.F_last; t.F_last = nil; tmp9 = t__3; return tmp6.Invoke_O_O__O(tmp8, tmp9) } } else {
//line :153:1
						if jrt.Character_IsWhitespace_C__Z_NoInit(c__1) {



							var tmp10 lang.IFn = lang.IFn_Cast(t.F_step); var tmp11 jrt.Number_I; var na_68 any; var t__4 any = t.F_i; t.F_i = nil; na_68 = t__4; if jrt.Long_InstanceOf(na_68) { var n0_69 int64 = jrt.NN(jrt.Long_Cast(na_68)).LongValue__J(); if n0_69 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_68) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_69 + 1)) } } else { if jrt.Double_InstanceOf(na_68) { var n0_69_2 float64 = jrt.NN(jrt.Double_Cast(na_68)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_69_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_68) } }; var tmp12 any = tmp11; var tmp13 any; var t__5 any = t.F_last; t.F_last = nil; tmp13 = t__5; return tmp10.Invoke_O_O__O(tmp12, tmp13) } else {
//line :153:1
								var tmp14 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_71)).CharValue__C())




								if and__1927000168__auto____2 { var and__1927000168__auto____3 bool; var na_15 any; var na_17 any = t.F_i; if jrt.Long_InstanceOf(na_17) { var n0_18 int64 = jrt.NN(jrt.Long_Cast(na_17)).LongValue__J(); if n0_18 == 9223372036854775807 { na_15 = lang.Numbers_Inc_O__Number_NoInit(na_17) } else { na_15 = jrt.Long_ValueOf_J__Long_NoInit(n0_18 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_17) { var n0_18_2 float64 = jrt.NN(jrt.Double_Cast(na_17)).DoubleValue__D(); na_15 = jrt.Double_ValueOf_D__Double_NoInit(n0_18_2 + 1.0).Ref() } else { na_15 = lang.Numbers_Inc_O__Number_NoInit(na_17) } }; var na_16 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_15) { var n0_19 int64 = jrt.NN(jrt.Long_Cast(na_15)).LongValue__J(); var n1_20 int64 = na_16; and__1927000168__auto____3 = n0_19 < n1_20 } else { and__1927000168__auto____3 = lang.Numbers_Lt_O_J__Z_NoInit(na_15, na_16) }; if and__1927000168__auto____3 { var tmp15 uint16 = jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_71)).CharValue__C(); var tmp16 *jrt.String = jrt.String_Cast(t.F_s); var tmp17 jrt.Number_I; var na_22 any = t.F_i; if jrt.Long_InstanceOf(na_22) { var n0_23 int64 = jrt.NN(jrt.Long_Cast(na_22)).LongValue__J(); if n0_23 == 9223372036854775807 { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_22) } else { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_23 + 1)) } } else { if jrt.Double_InstanceOf(na_22) { var n0_23_2 float64 = jrt.NN(jrt.Double_Cast(na_22)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_23_2 + 1.0)) } else { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_22) } }; tmp14 = lang.Util_Equiv_C_C__Z_NoInit(tmp15, jrt.NN(tmp16).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp17))) } else { tmp14 = and__1927000168__auto____3 } } else { tmp14 = and__1927000168__auto____2 }
//line :153:1
								if tmp14 { var j__2 any; var tmp18 any; var t__6 any = t.F_s





									t.F_s = nil; tmp18 = t__6; var tmp19 any = tmp18; var tmp20 any; var t__7 any = t.F_i; t.F_i = nil; tmp20 = t__7; j__2 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp19, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_46, tmp20)); var tmp21 lang.IFn = lang.IFn_Cast(t.F_step); var tmp22 any; var tmp23 bool; var na_70 any = j__2; if jrt.Long_InstanceOf(na_70) { var n0_71 int64 = jrt.NN(jrt.Long_Cast(na_70)).LongValue__J(); tmp23 = n0_71 < 0 } else { if jrt.Double_InstanceOf(na_70) { var n0_71_2 float64 = jrt.NN(jrt.Double_Cast(na_70)).DoubleValue__D(); tmp23 = n0_71_2 < 0.0 } else { tmp23 = lang.Numbers_IsNeg_O__Z_NoInit(na_70) } }; if tmp23 { tmp22 = jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n).Ref() } else { tmp22 = j__2 }; var tmp24 any = tmp22; var tmp25 any; var t__8 any = t.F_last; t.F_last = nil; tmp25 = t__8; return tmp21.Invoke_O_O__O(tmp24, tmp25) } else {
//line :153:1
										var tmp26 bool; var and__1927000168__auto____2_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_71)).CharValue__C())






										if and__1927000168__auto____2_2 { var and__1927000168__auto____3_2 bool; var na_24 any; var na_26 any = t.F_i; if jrt.Long_InstanceOf(na_26) { var n0_27 int64 = jrt.NN(jrt.Long_Cast(na_26)).LongValue__J(); if n0_27 == 9223372036854775807 { na_24 = lang.Numbers_Inc_O__Number_NoInit(na_26) } else { na_24 = jrt.Long_ValueOf_J__Long_NoInit(n0_27 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_26) { var n0_27_2 float64 = jrt.NN(jrt.Double_Cast(na_26)).DoubleValue__D(); na_24 = jrt.Double_ValueOf_D__Double_NoInit(n0_27_2 + 1.0).Ref() } else { na_24 = lang.Numbers_Inc_O__Number_NoInit(na_26) } }; var na_25 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_24) { var n0_28 int64 = jrt.NN(jrt.Long_Cast(na_24)).LongValue__J(); var n1_29 int64 = na_25; and__1927000168__auto____3_2 = n0_28 < n1_29 } else { and__1927000168__auto____3_2 = lang.Numbers_Lt_O_J__Z_NoInit(na_24, na_25) }; if and__1927000168__auto____3_2 { var tmp27 uint16 = jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_72)).CharValue__C(); var tmp28 *jrt.String = jrt.String_Cast(t.F_s); var tmp29 jrt.Number_I; var na_31 any = t.F_i; if jrt.Long_InstanceOf(na_31) { var n0_32 int64 = jrt.NN(jrt.Long_Cast(na_31)).LongValue__J(); if n0_32 == 9223372036854775807 { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_31) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_32 + 1)) } } else { if jrt.Double_InstanceOf(na_31) { var n0_32_2 float64 = jrt.NN(jrt.Double_Cast(na_31)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_32_2 + 1.0)) } else { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_31) } }; tmp26 = lang.Util_Equiv_C_C__Z_NoInit(tmp27, jrt.NN(tmp28).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp29))) } else { tmp26 = and__1927000168__auto____3_2 } } else { tmp26 = and__1927000168__auto____2_2 }
//line :153:1
										if tmp26 { var j__2_2 any; var tmp30 any = t.F_s; var tmp31 jrt.Number_I; var na_33 any = t.F_i
											var na_34 int64 = 2






											if jrt.Long_InstanceOf(na_33) { var n0_35 int64 = jrt.NN(jrt.Long_Cast(na_33)).LongValue__J(); var n1_36 int64 = na_34; var nr_37 int64 = n0_35 + n1_36; if (n0_35^nr_37)&(n1_36^nr_37) >= 0 { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_37)) } else { tmp31 = lang.Numbers_Add_O_J__Number_NoInit(na_33, na_34) } } else { tmp31 = lang.Numbers_Add_O_J__Number_NoInit(na_33, na_34) }; j__2_2 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp30, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_47, tmp31))
//line :153:1
											var nl__3 any; var and__1927000168__auto____3_3 bool
											var na_38 any = j__2_2







											if jrt.Long_InstanceOf(na_38) { var n0_39 int64 = jrt.NN(jrt.Long_Cast(na_38)).LongValue__J(); and__1927000168__auto____3_3 = n0_39 > 0 } else { if jrt.Double_InstanceOf(na_38) { var n0_39_2 float64 = jrt.NN(jrt.Double_Cast(na_38)).DoubleValue__D(); and__1927000168__auto____3_3 = n0_39_2 > 0.0 } else { and__1927000168__auto____3_3 = lang.Numbers_IsPos_O__Z_NoInit(na_38) } }; if and__1927000168__auto____3_3 { var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_65.GetRawRoot__O()); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()); var tmp34 any; var t__9 any = t.F_s; t.F_s = nil; tmp34 = t__9; var tmp35 any = tmp34; var tmp36 any; var t__10 any = t.F_i; t.F_i = nil; tmp36 = t__10; nl__3 = tmp32.Invoke_O_O__O(tmp33.Invoke_O_O_O__O(tmp35, tmp36, j__2_2), Lit_46) } else { nl__3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3_3).Ref() }
											var tmp37 any; var and__1927000168__auto____4 any = nl__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp37 = lang.IFn_Cast(A_arbace_box_plan_A_const_73).Invoke_O__O(t.F_last) } else { tmp37 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp37) {
												var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(t.F_step); var tmp40 jrt.Number_I; var tmp41 bool; var na_72 any = j__2_2; if jrt.Long_InstanceOf(na_72) { var n0_73 int64 = jrt.NN(jrt.Long_Cast(na_72)).LongValue__J(); tmp41 = n0_73 < 0 } else { if jrt.Double_InstanceOf(na_72) { var n0_73_2 float64 = jrt.NN(jrt.Double_Cast(na_72)).DoubleValue__D(); tmp41 = n0_73_2 < 0.0 } else { tmp41 = lang.Numbers_IsNeg_O__Z_NoInit(na_72) } }; if tmp41 { tmp40 = Up_Integer_Number(jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n)) } else { var na_74 any = j__2_2; var na_75 int64 = 2; if jrt.Long_InstanceOf(na_74) { var n0_76 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); var n1_77 int64 = na_75; var nr_78 int64 = n0_76 + n1_77; if (n0_76^nr_78)&(n1_77^nr_78) >= 0 { tmp40 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_78)) } else { tmp40 = lang.Numbers_Add_O_J__Number_NoInit(na_74, na_75) } } else { tmp40 = lang.Numbers_Add_O_J__Number_NoInit(na_74, na_75) } }; return tmp38.Invoke_O_O__O(Lit_32, tmp39.Invoke_O_O__O(tmp40, Lit_32)) } else {
													var tmp42 lang.IFn = lang.IFn_Cast(t.F_step); var tmp43 jrt.Number_I; var tmp44 bool; var na_79 any = j__2_2; if jrt.Long_InstanceOf(na_79) { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); tmp44 = n0_80 < 0 } else { if jrt.Double_InstanceOf(na_79) { var n0_80_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); tmp44 = n0_80_2 < 0.0 } else { tmp44 = lang.Numbers_IsNeg_O__Z_NoInit(na_79) } }; if tmp44 { tmp43 = Up_Integer_Number(jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n)) } else { var na_81 any = j__2_2; var na_82 int64 = 2; if jrt.Long_InstanceOf(na_81) { var n0_83 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); var n1_84 int64 = na_82; var nr_85 int64 = n0_83 + n1_84; if (n0_83^nr_85)&(n1_84^nr_85) >= 0 { tmp43 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_85)) } else { tmp43 = lang.Numbers_Add_O_J__Number_NoInit(na_81, na_82) } } else { tmp43 = lang.Numbers_Add_O_J__Number_NoInit(na_81, na_82) } }; var tmp45 any = tmp43; var tmp46 any; var t__11 any = t.F_last; t.F_last = nil; tmp46 = t__11; return tmp42.Invoke_O_O__O(tmp45, tmp46) } } else {
//line :153:1
														if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_74)).CharValue__C()) { var sb__2 any = jrt.StringBuilder_New(); var j__3 any; var tmp47 any = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_New_O_O_O(t.F_i, sb__2, t.F_s); var tmp48 *jrt.Class
															var fncls__53 /*line :153:1*/*jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_fn_class













															if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_fn_class = fncls__53d; tmp48 = fncls__53d } else { tmp48 = fncls__53 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil).Invoke__O()




															var tmp49 any = A_arbace_box_plan_A_const_79; return lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp49, lang.IFn_Cast(A_arbace_box_plan_A_const_80.GetRawRoot__O()).Invoke_O__O(sb__2)), lang.IFn_Cast(t.F_step).Invoke_O_O__O(j__3, A_arbace_box_plan_A_const_79)) } else {
//line :153:1
																if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_76)).CharValue__C()) { var j__2_3 any; var tmp50 any = t.F_s; var tmp51 jrt.Number_I; var na_54 any = t.F_i



















																	if jrt.Long_InstanceOf(na_54) { var n0_55 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); if n0_55 == 9223372036854775807 { tmp51 = lang.Numbers_Inc_O__Number_NoInit(na_54) } else { tmp51 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_55 + 1)) } } else { if jrt.Double_InstanceOf(na_54) { var n0_55_2 float64 = jrt.NN(jrt.Double_Cast(na_54)).DoubleValue__D(); tmp51 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_55_2 + 1.0)) } else { tmp51 = lang.Numbers_Inc_O__Number_NoInit(na_54) } }; j__2_3 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp50, Lit_45, jrt.RefArrayOf(jrt.Object_class, Lit_49, tmp51))
																	var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()); var tmp53 any = A_arbace_box_plan_A_const_79; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()); var tmp55 any; var t__12 any = t.F_s; t.F_s = nil; tmp55 = t__12; var tmp56 any = tmp55; var tmp57 jrt.Number_I; var na_86 any; var t__13 any = t.F_i; t.F_i = nil; na_86 = t__13; if jrt.Long_InstanceOf(na_86) { var n0_87 int64 = jrt.NN(jrt.Long_Cast(na_86)).LongValue__J(); if n0_87 == 9223372036854775807 { tmp57 = lang.Numbers_Inc_O__Number_NoInit(na_86) } else { tmp57 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_87 + 1)) } } else { if jrt.Double_InstanceOf(na_86) { var n0_87_2 float64 = jrt.NN(jrt.Double_Cast(na_86)).DoubleValue__D(); tmp57 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_87_2 + 1.0)) } else { tmp57 = lang.Numbers_Inc_O__Number_NoInit(na_86) } }; var tmp58 any = lang.Tuple_Create_O_O__IPersistentVector(tmp53, tmp54.Invoke_O_O_O__O(tmp56, tmp57, j__2_3)); var tmp59 lang.IFn = lang.IFn_Cast(t.F_step); var tmp60 jrt.Number_I; var na_88 any = j__2_3; if jrt.Long_InstanceOf(na_88) { var n0_89 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); if n0_89 == 9223372036854775807 { tmp60 = lang.Numbers_Inc_O__Number_NoInit(na_88) } else { tmp60 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_89 + 1)) } } else { if jrt.Double_InstanceOf(na_88) { var n0_89_2 float64 = jrt.NN(jrt.Double_Cast(na_88)).DoubleValue__D(); tmp60 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_89_2 + 1.0)) } else { tmp60 = lang.Numbers_Inc_O__Number_NoInit(na_88) } }; return tmp52.Invoke_O_O__O(tmp58, tmp59.Invoke_O_O__O(tmp60, A_arbace_box_plan_A_const_79)) } else {
//line :153:1
																		var tmp61 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(c__1)





















																		if or__1927000174__auto____2 { tmp61 = or__1927000174__auto____2 } else { tmp61 = lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_77)).CharValue__C()) }
//line :153:1
																		if tmp61 { var j__2_4 any; var tmp62 any = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_New_O_I_O(t.F_i, t.F_n, t.F_s); var tmp63 *jrt.Class
																			var fncls__63 /*line :153:1*/*jrt.Class = A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_fn_class






















																			if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_fn_class = fncls__63d; tmp63 = fncls__63d } else { tmp63 = fncls__63 }; j__2_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil).Invoke__O()
																			var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()); var tmp65 any = A_arbace_box_plan_A_const_81; var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()); var tmp67 any; var t__14 any = t.F_s; t.F_s = nil; tmp67 = t__14; var tmp68 any = tmp67; var tmp69 any; var t__15 any = t.F_i; t.F_i = nil; tmp69 = t__15; return tmp64.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp65, tmp66.Invoke_O_O_O__O(tmp68, tmp69, j__2_4)), lang.IFn_Cast(t.F_step).Invoke_O_O__O(j__2_4, A_arbace_box_plan_A_const_81)) } else {
//line :153:1
																				if lang.Util_Equiv_C_C__Z_NoInit(c__1, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_78)).CharValue__C()) {
























																					var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()); var tmp71 lang.IFn = lang.IFn_Cast(t.F_step); var tmp72 jrt.Number_I; var na_90 any; var t__16 any = t.F_i; t.F_i = nil; na_90 = t__16; if jrt.Long_InstanceOf(na_90) { var n0_91 int64 = jrt.NN(jrt.Long_Cast(na_90)).LongValue__J(); if n0_91 == 9223372036854775807 { tmp72 = lang.Numbers_Inc_O__Number_NoInit(na_90) } else { tmp72 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_91 + 1)) } } else { if jrt.Double_InstanceOf(na_90) { var n0_91_2 float64 = jrt.NN(jrt.Double_Cast(na_90)).DoubleValue__D(); tmp72 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_91_2 + 1.0)) } else { tmp72 = lang.Numbers_Inc_O__Number_NoInit(na_90) } }; return tmp70.Invoke_O_O__O(Lit_23, tmp71.Invoke_O_O__O(tmp72, Lit_23)) } else {
//line :153:1
																						if A_arbace_box_plan_A_const_39 != nil {

























																							var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()); var tmp74 any = lang.IFn_Cast(A_arbace_box_plan_A_const_80.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__1).Ref()); var tmp75 lang.IFn = lang.IFn_Cast(t.F_step); var tmp76 jrt.Number_I; var na_92 any; var t__17 any = t.F_i; t.F_i = nil; na_92 = t__17; if jrt.Long_InstanceOf(na_92) { var n0_93 int64 = jrt.NN(jrt.Long_Cast(na_92)).LongValue__J(); if n0_93 == 9223372036854775807 { tmp76 = lang.Numbers_Inc_O__Number_NoInit(na_92) } else { tmp76 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_93 + 1)) } } else { if jrt.Double_InstanceOf(na_92) { var n0_93_2 float64 = jrt.NN(jrt.Double_Cast(na_92)).DoubleValue__D(); tmp76 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_93_2 + 1.0)) } else { tmp76 = lang.Numbers_Inc_O__Number_NoInit(na_92) } }; return tmp73.Invoke_O_O__O(tmp74, tmp75.Invoke_O_O__O(tmp76, lang.IFn_Cast(A_arbace_box_plan_A_const_80.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__1).Ref()))) } else {
//line :153:1
																								return nil } } } } } } } } } } else {
//line :151:1
																									return nil
																								}
}













func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :167:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A) Invoke_O__O(self any) any { { var j__1 any; var na_40 any; var t_ any = t.F_i; t.F_i = nil; na_40 = t_; if jrt.Long_InstanceOf(na_40) { var n0_41 int64 = jrt.NN(jrt.Long_Cast(na_40)).LongValue__J(); if n0_41 == 9223372036854775807 { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_40) } else { j__1 = jrt.Long_ValueOf_J__Long_NoInit(n0_41 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_40) { var n0_41_2 float64 = jrt.NN(jrt.Double_Cast(na_40)).DoubleValue__D(); j__1 = jrt.Double_ValueOf_D__Double_NoInit(n0_41_2 + 1.0).Ref() } else { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_40) } }; L1: for { var tmp1 *jrt.String = jrt.String_Cast(t.F_s); var d__2 uint16 = jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))

	if lang.Util_Equiv_C_C__Z_NoInit(d__2, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_75)).CharValue__C()) { var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp3 *jrt.String = jrt.String_Cast(t.F_s); var tmp4 jrt.Number_I; var na_44 any = j__1; if jrt.Long_InstanceOf(na_44) { var n0_45 int64 = jrt.NN(jrt.Long_Cast(na_44)).LongValue__J(); if n0_45 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_44) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_45 + 1)) } } else { if jrt.Double_InstanceOf(na_44) { var n0_45_2 float64 = jrt.NN(jrt.Double_Cast(na_44)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_45_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_44) } }; jrt.NN(tmp2).Append_C__StringBuilder(jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp4))); var tmp5 jrt.Number_I; var na_46 any = j__1; var na_47 int64 = 2; if jrt.Long_InstanceOf(na_46) { var n0_48 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_49 int64 = na_47; var nr_50 int64 = n0_48 + n1_49; if (n0_48^nr_50)&(n1_49^nr_50) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_50)) } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_46, na_47) } } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_46, na_47) }; j__1 = tmp5; continue L1 } else { if lang.Util_Equiv_C_C__Z_NoInit(d__2, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_74)).CharValue__C()) {
		var na_42 any = j__1; if jrt.Long_InstanceOf(na_42) { var n0_43 int64 = jrt.NN(jrt.Long_Cast(na_42)).LongValue__J(); if n0_43 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_42) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_43 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_42) { var n0_43_2 float64 = jrt.NN(jrt.Double_Cast(na_42)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_43_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_42) } } } else {
//line :169:1
			if A_arbace_box_plan_A_const_39 != nil {

				jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_C__StringBuilder(d__2); var tmp6 jrt.Number_I; var na_51 any = j__1; if jrt.Long_InstanceOf(na_51) { var n0_52 int64 = jrt.NN(jrt.Long_Cast(na_51)).LongValue__J(); if n0_52 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_51) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_52 + 1)) } } else { if jrt.Double_InstanceOf(na_51) { var n0_52_2 float64 = jrt.NN(jrt.Double_Cast(na_51)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_52_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_51) } }; j__1 = tmp6; continue L1 } else {
//line :169:1
					return nil } } } } }; /*line :167:1*/panic("j2g: unreachable") }








func A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A) Ctor_O_I_O(c__i any, c__n int32, c__s any) { t.F_i = c__i; t.F_n = c__n; t.F_s = c__s }
//line :176:1
func (t *A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_56 any = j__1; var na_57 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_56) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_59 int64 = na_57; and__1927000168__auto____2 = n0_58 < n1_59 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_56, na_57) }; if and__1927000168__auto____2 { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); var d__3 uint16 = jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1)); var or__1927000174__auto____4 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(d__3); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_C_C__Z_NoInit(d__3, jrt.NN(jrt.Character_Cast(A_arbace_box_plan_A_const_77)).CharValue__C()) } } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp3 jrt.Number_I; var na_61 any = j__1; if jrt.Long_InstanceOf(na_61) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_61)).LongValue__J(); if n0_62 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_61) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_62 + 1)) } } else { if jrt.Double_InstanceOf(na_61) { var n0_62_2 float64 = jrt.NN(jrt.Double_Cast(na_61)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_62_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_61) } }; j__1 = tmp3; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }





func A_arbace_box_plan_go_info_A_New() *A_arbace_box_plan_go_info_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_box_plan_go_info_A) Ctor() {}
//line :182:1
func (t *A_arbace_box_plan_go_info_A) Invoke_O_O_O__O(self, s__0, what__1 any) any { var toks__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_83.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_go_info_fn__1305000070_A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000070_A_fn_class; if


	fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_box_plan_go_info_fn__1305000070_A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; toks__3 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_box_plan_A_const_97.GetRawRoot__O()).Invoke_O__O(s__0)); var ___4 any; var tmp4 any = A_arbace_box_plan_A_const_84; _ = ___4; if
	lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(toks__3)) { ___4 = nil } else {
		___4 = lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, what__1, nil)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) }; var pkg__5 any = /*line :182:1*/lang.IFn_Cast(A_arbace_box_plan_A_const_85.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_85.GetRawRoot__O()).Invoke_O__O(toks__3)); var imports__6 any; var tmp5 any = A_arbace_box_plan_go_info_fn__1305000072_A_New_O(toks__3); var tmp6 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_A_fn_class; if






	fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_box_plan_go_info_fn__1305000072_A_fn_class = fncls__101d; tmp6 = fncls__101d } else { tmp6 = fncls__101 }; imports__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var embeds__7 any; if









	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_98, imports__6)) {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_42.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_99.GetRawRoot__O()); var tmp9 any = A_arbace_box_plan_go_info_fn__1305000090_A_New(); var tmp10 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000090_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_box_plan_go_info_fn__1305000090_A_fn_class = fncls__104d; tmp10 = fncls__104d } else { tmp10 = fncls__104 }; embeds__7 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_box_plan_A_const_60.GetRawRoot__O()).Invoke_O__O(s__0))) } else {
//line :199:1
			embeds__7 = nil }; return /*line :182:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_94, pkg__5, A_arbace_box_plan_A_const_95, imports__6, A_arbace_box_plan_A_const_96, embeds__7)) }


func A_arbace_box_plan_go_info_fn__1305000070_A_New() *A_arbace_box_plan_go_info_fn__1305000070_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000070_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_box_plan_go_info_fn__1305000070_A) Ctor() {}
//line :185:1
func (t *A_arbace_box_plan_go_info_fn__1305000070_A) Invoke_O_O__O(self, p1__1305000064_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_32, p1__1305000064_SHARP___1)).Ref() }



func A_arbace_box_plan_go_info_fn__1305000072_A_New_O(p0 any) *A_arbace_box_plan_go_info_fn__1305000072_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_A) Ctor_O(c__toks any) { t.F_toks = c__toks }
//line :189:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_A) Invoke_O__O(self any) any { { var ts__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_86.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_A_const_48; var tmp3 any; var t_ any = t.F_toks; t.F_toks = nil; tmp3 = t_; ts__1 = tmp1.Invoke_O_O__O(tmp2, tmp3); var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var ts__3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_83.GetRawRoot__O()); var tmp5 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_New(); var tmp6 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_fn_class
										if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_fn_class = fncls__96d; tmp6 = fncls__96d } else { tmp6 = fncls__96 }; ts__3 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ts__1)
										var tmp7 any = A_arbace_box_plan_A_const_87; if lang.Util_Equiv_O_O__Z_NoInit(tmp7, lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(ts__3)) { var ts__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(ts__3)

		if lang.Util_Equiv_O_O__Z_NoInit(Lit_22, lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(ts__4)) { var vec__1305000075__5 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_88.GetRawRoot__O()); var tmp9 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_New(); var tmp10 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_fn_class
			if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_fn_class = fncls__97d; tmp10 = fncls__97d } else { tmp10 = fncls__97 }; vec__1305000075__5 = tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(ts__4))
//line :193:1
			var spec__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000075__5, lang.RT_IntCast_J__I_NoInit(0), nil); var more__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000075__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 any = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(more__7); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_90.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_91.GetRawRoot__O()); var tmp14 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_New(); var tmp15 *jrt.Class
			var fncls__98 /*line :193:1*/*jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_fn_class

			if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_fn_class = fncls__98d; tmp15 = fncls__98d } else { tmp15 = fncls__98 }; ts__1, acc__2 = tmp11, tmp12.Invoke_O_O__O(acc__2, tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), spec__6)); continue L1 } else {
//line :193:1
				var vec__1305000082__5 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_88.GetRawRoot__O()); var tmp17 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_New(); var tmp18 *jrt.Class
				var fncls__99 /*line :193:1*/*jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_fn_class


				if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_fn_class = fncls__99d; tmp18 = fncls__99d } else { tmp18 = fncls__99 }; vec__1305000082__5 = tmp16.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), ts__4)
//line :193:1
				var spec__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000082__5, lang.RT_IntCast_J__I_NoInit(0), nil); var more__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000082__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_90.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_91.GetRawRoot__O()); var tmp21 any = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_New(); var tmp22 *jrt.Class
				var fncls__100 /*line :193:1*/*jrt.Class = A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_fn_class



				if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_fn_class = fncls__100d; tmp22 = fncls__100d } else { tmp22 = fncls__100 }; ts__1, acc__2 = more__7_2, tmp19.Invoke_O_O__O(acc__2, tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), spec__6_2)); continue L1 } } else {
//line :191:1
					return acc__2 } } }; /*line :189:1*/panic("j2g: unreachable") }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A) Ctor() {}
//line :190:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A) Invoke_O_O__O(self, p1__1305000065_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_32, p1__1305000065_SHARP___1)).Ref() }



func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A) Ctor() {}
//line :194:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A) Invoke_O_O__O(self, p1__1305000066_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(Lit_23, p1__1305000066_SHARP___1) }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A) Ctor() {}
//line :195:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A) Invoke_O_O__O(self, p1__1305000067_SHARP___1 any) any { var tmp1 any = A_arbace_box_plan_A_const_79; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(p1__1305000067_SHARP___1)) { return lang.IFn_Cast(A_arbace_box_plan_A_const_85.GetRawRoot__O()).Invoke_O__O(p1__1305000067_SHARP___1) } else { return nil } }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A) Ctor() {}
//line :196:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A) Invoke_O_O__O(self, p1__1305000068_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(Lit_32, p1__1305000068_SHARP___1) }
func A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_New() *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A) Ctor() {}
//line :197:1
func (t *A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A) Invoke_O_O__O(self, p1__1305000069_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_92.GetRawRoot__O()).Invoke_O__O(p1__1305000069_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_box_plan_A_const_79; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(p1__1305000069_SHARP___1))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_box_plan_A_const_85.GetRawRoot__O()).Invoke_O__O(p1__1305000069_SHARP___1) } else { return nil } }


func A_arbace_box_plan_go_info_fn__1305000090_A_New() *A_arbace_box_plan_go_info_fn__1305000090_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000090_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_A) Ctor() {}
//line :200:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_A) Invoke_O_O__O(self, l__1 any) any { var t__2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_61.GetRawRoot__O()).Invoke_O__O(l__1); if
											jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(t__2, Lit_38)) {
												var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_52.GetRawRoot__O()); var tmp5 any = A_arbace_box_plan_A_const_102; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()).Invoke_O_O__O(t__2, A_arbace_box_plan_A_const_103))) } else {
//line :201:1
			return nil } }
func A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_New() *A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A) Ctor() {}
//line :202:1
func (t *A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A) Invoke_O_O__O(self, p__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(p__1, Lit_40)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_A_const_101; return tmp1.Invoke_O_O_O__O(p__1, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(p__1)))).Ref()) } else { return p__1 } }







func A_arbace_box_plan_go_mod_lang_A_New() *A_arbace_box_plan_go_mod_lang_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_go_mod_lang_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_box_plan_go_mod_lang_A) Ctor() {}
//line :210:1
func (t *A_arbace_box_plan_go_mod_lang_A) Invoke_O_O__O(self, h__0 any) any { var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_box_plan_A_const_19.GetRawRoot__O()).Invoke_O__O(h__0), Lit_41); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var e__3 any = temp__1927000414__auto____2; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_64.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_A_const_104; var temp__1927000414__auto____4 any = tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_box_plan_A_const_105.GetRawRoot__O()).Invoke_O__O(e__3))
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var vec__1305000095__5 any = temp__1927000414__auto____4; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000095__5, lang.RT_IntCast_J__I_NoInit(0), nil); var v__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000095__5, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___6
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__7)).Ref() } else {
//line :214:1
				return nil } } else {
//line :213:1
					return nil } }



func A_arbace_box_plan_locate_A_New() *A_arbace_box_plan_locate_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_locate_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_box_plan_locate_A) Ctor() {}
//line :217:1
func (t *A_arbace_box_plan_locate_A) Invoke_O_O_O_O__O(self, cfg__0, p__1, from_std__2 any) any { var map__1305000099__4 any = cfg__0; var map__1305000099__5 any; if




	lang.ISeq_InstanceOf(map__1305000099__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1305000099__4)) { map__1305000099__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_plan_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1305000099__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1305000099__4)) { map__1305000099__5 = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1305000099__4) } else { map__1305000099__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000099__5 = map__1305000099__4 }; var goroot__6 any = /*line :217:1*/lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_106); var modules__7 any = lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_107); var goospkg__8 any = lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_108); var goos__9 any = lang.RT_Get_O_O__O_NoInit(map__1305000099__5, A_arbace_box_plan_A_const_32); var mod__10 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_114.GetRawRoot__O()); var tmp3 any = A_arbace_box_plan_locate_fn__1305000102_A_New_O(p__1); var tmp4 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_box_plan_locate_fn__1305000102_A_fn_class; if





	fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_box_plan_locate_fn__1305000102_A_fn_class = fncls__105d; tmp4 = fncls__105d } else { tmp4 = fncls__105 }; mod__10 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), modules__7)); var tmp5 any; var and__1927000168__auto____11 bool =
	lang.Util_Equiv_O_O__Z_NoInit(goos__9, Lit_55); if and__1927000168__auto____11 {
		var and__1927000168__auto____12 any = goospkg__8; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, Lit_56); if or__1927000174__auto____13 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____13).Ref() } else { tmp5 = lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(p__1, Lit_57) } } else { tmp5 = and__1927000168__auto____12 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() }; if /*line :224:1*/ jrt.J2g_Truth(tmp5) { var mt__11 any; var or__1927000174__auto____11 any = lang.RT_Get_O_O__O_NoInit(modules__7, goospkg__8)

			if jrt.J2g_Truth(or__1927000174__auto____11) { mt__11 = or__1927000174__auto____11 } else { mt__11 = lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_58, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, goospkg__8, nil)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) }
//line :224:1
			var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_box_plan_A_const_109.GetRawRoot__O()).Invoke_O_O__O(mt__11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()).Invoke_O_O__O(p__1, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(Lit_56)).Ref()))).Ref())


			if jrt.J2g_Truth(temp__1927000414__auto____12) { var d__13 any = temp__1927000414__auto____12; var tmp6 any = A_arbace_box_plan_A_const_20; var tmp7 any = A_arbace_box_plan_A_const_110; var tmp8 any = jrt.Boolean_FALSE.Ref(); var tmp9 any = A_arbace_box_plan_A_const_111; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, d__13, tmp7, tmp8, tmp9, lang.IFn_Cast(A_arbace_box_plan_A_const_112.GetRawRoot__O()).Invoke_O__O(mt__11), A_arbace_box_plan_A_const_113, p__1)) } else { return nil } } else {
//line :224:1
				if jrt.J2g_Truth(mod__10) { var vec__1305000107__11 any = mod__10; var m__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var mt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000414__auto____14 any






					if lang.Util_Equiv_O_O__Z_NoInit(p__1, m__12) { temp__1927000414__auto____14 = mt__13 } else { temp__1927000414__auto____14 = lang.IFn_Cast(A_arbace_box_plan_A_const_109.GetRawRoot__O()).Invoke_O_O__O(mt__13, lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()).Invoke_O_O__O(p__1, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(m__12)))).Ref())) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var d__15 any = temp__1927000414__auto____14; var tmp10 any = A_arbace_box_plan_A_const_20; var tmp11 any = A_arbace_box_plan_A_const_110; var tmp12 any = jrt.Boolean_FALSE.Ref(); var tmp13 any = A_arbace_box_plan_A_const_111; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, d__15, tmp11, tmp12, tmp13, lang.IFn_Cast(A_arbace_box_plan_A_const_112.GetRawRoot__O()).Invoke_O__O(mt__13), A_arbace_box_plan_A_const_113, p__1)) } else { return nil } } else {
//line :224:1
						if A_arbace_box_plan_A_const_39 != nil { var or__1927000174__auto____11_2 any; var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_box_plan_A_const_109.GetRawRoot__O()).Invoke_O_O__O(goroot__6, p__1)








							if jrt.J2g_Truth(temp__1927000414__auto____11) { var d__12 any = temp__1927000414__auto____11; var tmp14 any = A_arbace_box_plan_A_const_20; var tmp15 any = A_arbace_box_plan_A_const_110; var tmp16 any = jrt.Boolean_TRUE.Ref(); var tmp17 any = A_arbace_box_plan_A_const_111; or__1927000174__auto____11_2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, d__12, tmp15, tmp16, tmp17, lang.IFn_Cast(A_arbace_box_plan_A_const_112.GetRawRoot__O()).Invoke_O__O(goroot__6), A_arbace_box_plan_A_const_113, p__1)) } else { or__1927000174__auto____11_2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____11_2) { return or__1927000174__auto____11_2 } else {
								if jrt.J2g_Truth(from_std__2) { var temp__1927000414__auto____12_2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_109.GetRawRoot__O()).Invoke_O_O__O(goroot__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref())
									if jrt.J2g_Truth(temp__1927000414__auto____12_2) { var d__13_2 any = temp__1927000414__auto____12_2; var tmp18 any = A_arbace_box_plan_A_const_20; var tmp19 any = A_arbace_box_plan_A_const_110; var tmp20 any = jrt.Boolean_TRUE.Ref(); var tmp21 any = A_arbace_box_plan_A_const_111; var tmp22 any = lang.IFn_Cast(A_arbace_box_plan_A_const_112.GetRawRoot__O()).Invoke_O__O(goroot__6); var tmp23 any = A_arbace_box_plan_A_const_113; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, d__13_2, tmp19, tmp20, tmp21, tmp22, tmp23, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref())) } else { return nil } } else {
//line :234:1
										return nil } } } else {
//line :224:1
											return nil } } } }
//line :223:1
func A_arbace_box_plan_locate_fn__1305000102_A_New_O(p0 any) *A_arbace_box_plan_locate_fn__1305000102_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_locate_fn__1305000102_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_box_plan_locate_fn__1305000102_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :223:1
func (t *A_arbace_box_plan_locate_fn__1305000102_A) Invoke_O_O__O(self, p__1305000101__1 any) any { var vec__1305000103__2 any = p__1305000101__1; var m__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000103__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000103__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_p, m__3); _ = ___4; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()); var tmp2 any = t.F_p; return tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, m__3, nil)).Ref()) } }














func A_arbace_box_plan_embed_files_A_New() *A_arbace_box_plan_embed_files_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_embed_files_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_box_plan_embed_files_A) Ctor() {}
//line :238:1
func (t *A_arbace_box_plan_embed_files_A) Invoke_O_O_O_O__O(self, d__0, pattern__1, what__2 any) any { var all__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(pattern__1, Lit_2); var p__5 any; if




	jrt.J2g_Truth(all__4) { p__5 = lang.IFn_Cast(A_arbace_box_plan_A_const_49.GetRawRoot__O()).Invoke_O_O__O(pattern__1, A_arbace_box_plan_A_const_118) } else { p__5 = pattern__1 }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_119, p__5)) {
		lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, nil, what__2, nil, pattern__1, nil)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) }; var segs__6 any = /*line :238:1*/lang.IFn_Cast(A_arbace_box_plan_A_const_24.GetRawRoot__O()).Invoke_O_O__O(p__5, A_arbace_box_plan_A_const_120); var parent__7 any = lang.IFn_Cast(A_arbace_box_plan_A_const_109.GetRawRoot__O()).Invoke_O_O__O(d__0, lang.IFn_Cast(A_arbace_box_plan_A_const_121.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lang.IFn_Cast(A_arbace_box_plan_A_const_122.GetRawRoot__O()).Invoke_O__O(segs__6))); var vec__1305000111__8 any; if









	jrt.J2g_Truth(parent__7) { vec__1305000111__8 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_box_plan_A_const_19.GetRawRoot__O()).Invoke_O__O(parent__7), lang.IFn_Cast(A_arbace_box_plan_A_const_115.GetRawRoot__O()).Invoke_O__O(segs__6)) } else { vec__1305000111__8 = nil }; var k__9 any = /*line :238:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1305000111__8, lang.RT_IntCast_J__I_NoInit(0), nil); var h__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000111__8, lang.RT_IntCast_J__I_NoInit(1), nil); var e__11 any = vec__1305000111__8; var walk__12 any; var tmp1 any = A_arbace_box_plan_embed_files_walk__1305000114_A_New_O(all__4); var tmp2 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_box_plan_embed_files_walk__1305000114_A_fn_class; if










	fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_box_plan_embed_files_walk__1305000114_A_fn_class = fncls__107d; tmp2 = fncls__107d } else { tmp2 = fncls__107 }; walk__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if




	lang.Util_Identical_O_O__Z_NoInit(e__11, nil) { return lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, what__2, nil, pattern__1, nil)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(k__9, A_arbace_box_plan_A_const_20) {
		return lang.IFn_Cast(A_arbace_box_plan_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(walk__12).Invoke_O_O__O(h__10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, p__5, nil)).Ref())) } else {
//line :254:1
			if A_arbace_box_plan_A_const_39 != nil { return lang.Tuple_Create_O__IPersistentVector(p__5) } else { return nil } } } }
//line :249:1
func A_arbace_box_plan_embed_files_walk__1305000114_A_New_O(p0 any) *A_arbace_box_plan_embed_files_walk__1305000114_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_embed_files_walk__1305000114_A{}; t.Ctor_O(p0); return t }
//line :249:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_A) Ctor_O(c__all any) { t.F_all = c__all }
//line :249:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_A) Invoke_O_O_O__O(self, h__1, prefix__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_99.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_New_O_O_O(self, prefix__2, t.F_all); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_box_plan_A_const_116.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_117.GetRawRoot__O(), lang.IFn_Cast(A_arbace_box_plan_A_const_19.GetRawRoot__O()).Invoke_O__O(h__1))) }
//line :250:1
func A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :250:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A) Ctor_O_O_O(c__walk, c__prefix, c__all any) { t.F_walk = c__walk; t.F_prefix = c__prefix; t.F_all = c__all }
//line :250:1
func (t *A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A) Invoke_O_O__O(self, p__1305000115__1 any) any { var vec__1305000117__2 any = p__1305000115__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000117__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000120__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000117__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any = t.F_all; if
															jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_10); if jrt.J2g_Truth(or__1927000174__auto____8) { tmp3 = or__1927000174__auto____8 } else { tmp3 = lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_11) }; tmp1 = tmp2.Invoke_O__O(tmp3) }; if jrt.J2g_Truth(tmp1) {
																if lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_box_plan_A_const_20) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp4.Invoke_O_O__O(eh__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__3, nil)).Ref()) } else { return lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__3)).Ref()) } } else {
//line :251:1
			return nil } }






func A_arbace_box_plan_package_info_A_New() *A_arbace_box_plan_package_info_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_box_plan_package_info_A) Ctor() {}
//line :258:1
func (t *A_arbace_box_plan_package_info_A) Invoke_O_O_O_O_O__O(self, cfg__0, match_QMARK___1, p__2, p__1305000127__3 any) any { var map__1305000128__5 any = p__1305000127__3; var map__1305000128__6 any; if lang.ISeq_InstanceOf(map__1305000128__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1305000128__5)) { map__1305000128__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_plan_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1305000128__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1305000128__5)) { map__1305000128__6 = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1305000128__5) } else { map__1305000128__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000128__6 = map__1305000128__5 }; var dir__7 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_20); var std__8 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_110); var lang__9 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_111); var path__10 any = lang.RT_Get_O_O__O_NoInit(map__1305000128__6, A_arbace_box_plan_A_const_113); var es__11 any = lang.IFn_Cast(A_arbace_box_plan_A_const_19.GetRawRoot__O()).Invoke_O__O(dir__7); var what__12 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__10)).Ref(); var files__13 any; var iter__1927001039__auto____13 any; var tmp1 any = A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_New_O(match_QMARK___1); var tmp2 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_fn_class; if




	fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_fn_class = fncls__110d; tmp2 = fncls__110d } else { tmp2 = fncls__110 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__13 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_116.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_117.GetRawRoot__O(), es__11)); var go__14 any; var iter__1927001039__auto____14 any; var tmp3 any = /*line :258:1*/A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_New_O_O(match_QMARK___1, path__10); var tmp4 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_fn_class; if











	fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_fn_class = fncls__113d; tmp4 = fncls__113d } else { tmp4 = fncls__113 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); go__14 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(files__13); var others__15 any; var iter__1927001039__auto____15 any; var tmp5 any = /*line :258:1*/A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_New_O(match_QMARK___1); var tmp6 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_fn_class; if


















	fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_fn_class = fncls__116d; tmp6 = fncls__116d } else { tmp6 = fncls__116 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); others__15 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__13); var tmp7 lang.IFn = /*line :258:1*/lang.IFn_Cast(A_arbace_box_plan_A_const_149.GetRawRoot__O()); var tmp8 any = A_arbace_box_plan_A_const_94; var names__16 any = lang.IFn_Cast(A_arbace_box_plan_A_const_140.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_100.GetRawRoot__O()).Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, A_arbace_box_plan_A_const_85.GetRawRoot__O()), go__14)); if























	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_23.GetRawRoot__O()).Invoke_O__O(go__14)) {
		lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_67, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, what__12, nil, A_arbace_box_plan_A_const_32.Invoke_O__O(cfg__0), nil, A_arbace_box_plan_A_const_33.Invoke_O__O(cfg__0))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_113, path__10))) }; if
	lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(names__16)), 1) {
		lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, what__12, nil, lang.IFn_Cast(A_arbace_box_plan_A_const_121.GetRawRoot__O()).Invoke_O_O__O(Lit_69, names__16))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_113, path__10))) }; var temp__1927000414__auto____17 any; var tmp9 lang.IFn = /*line :258:1*/lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_114.GetRawRoot__O()); var tmp11 any = A_arbace_box_plan_package_info_fn__1305000184_A_New(); var tmp12 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_box_plan_package_info_fn__1305000184_A_fn_class; if



























	fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_box_plan_package_info_fn__1305000184_A_fn_class = fncls__117d; tmp12 = fncls__117d } else { tmp12 = fncls__117 }; temp__1927000414__auto____17 = tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), others__15)); if jrt.J2g_Truth(temp__1927000414__auto____17) { var vec__1305000186__18 any = temp__1927000414__auto____17; var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000186__18, lang.RT_IntCast_J__I_NoInit(0), nil)
		lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_71, nil, Lit_72), jrt.RefArrayOf(jrt.Object_class, nil, what__12, nil, n__19, nil)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_113, path__10))) }; var tmp13 lang.IFn = /*line :258:1*/lang.IFn_Cast(A_arbace_box_plan_A_const_149.GetRawRoot__O()); var tmp14 any = A_arbace_box_plan_A_const_96; var patterns__17 any = lang.IFn_Cast(A_arbace_box_plan_A_const_140.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_99.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O_O__O(tmp14, A_arbace_box_plan_A_const_85.GetRawRoot__O()), go__14)); var embed__18 any; if






























	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(patterns__17)) { var tmp15 any = A_arbace_box_plan_A_const_141; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_90.GetRawRoot__O()); var tmp17 any = lang.IFn_Cast(A_arbace_box_plan_A_const_151.GetRawRoot__O()).Invoke__O(); var tmp18 any; var iter__1927001039__auto____18 any; var tmp19 any = A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_New_O_O(dir__7, what__12); var tmp20 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_fn_class
		if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_fn_class = fncls__120d; tmp20 = fncls__120d } else { tmp20 = fncls__120 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); tmp18 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(patterns__17)
//line :289:1
		embed__18 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16.Invoke_O_O__O(tmp17, tmp18))) } else { embed__18 = nil }; var tmp21 any = A_arbace_box_plan_A_const_113; var tmp22 any = A_arbace_box_plan_A_const_142; var tmp23 any = /*line :258:1*/lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(names__16); var tmp24 any = A_arbace_box_plan_A_const_110; var tmp25 any = A_arbace_box_plan_A_const_111; var tmp26 any; var or__1927000174__auto____19 any = lang__9; if
































	jrt.J2g_Truth(or__1927000174__auto____19) { tmp26 = or__1927000174__auto____19 } else { tmp26 = A_arbace_box_plan_A_const_143.Invoke_O__O(cfg__0) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_box_plan_A_const_144; var tmp29 any = /*line :258:1*/lang.IFn_Cast(A_arbace_box_plan_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_31.GetRawRoot__O(), go__14); var tmp30 any = A_arbace_box_plan_A_const_146; var tmp31 any = lang.IFn_Cast(A_arbace_box_plan_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_31.GetRawRoot__O(), others__15); var tmp32 any = A_arbace_box_plan_A_const_147; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_22.GetRawRoot__O()); var tmp34 any = A_arbace_box_plan_A_const_154; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_149.GetRawRoot__O()); var tmp36 any = A_arbace_box_plan_A_const_95; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp21, path__10, tmp22, tmp23, tmp24, std__8, tmp25, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, lang.IFn_Cast(A_arbace_box_plan_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_153.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_140.GetRawRoot__O()).Invoke_O__O(tmp33.Invoke_O_O__O(tmp34, lang.IFn_Cast(A_arbace_box_plan_A_const_99.GetRawRoot__O()).Invoke_O_O__O(tmp35.Invoke_O_O__O(tmp36, A_arbace_box_plan_A_const_85.GetRawRoot__O()), go__14))))), A_arbace_box_plan_A_const_148, embed__18, A_arbace_box_plan_A_const_20, dir__7)) }




func A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_New_O(p0 any) *A_arbace_box_plan_package_info_iter__1305000130__1305000134_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000130__1305000134_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_A) Ctor_O(c__match_QMARK_ any) { t.F_match_QMARK_ = c__match_QMARK_ }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_A) Invoke_O_O__O(self, s__1305000131__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_New_O_O_O(s__1305000131__1, t.F_match_QMARK_, self); var tmp2 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_fn_class = fncls__109d; tmp2 = fncls__109d } else { tmp2 = fncls__109 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :263:1
func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A) Ctor_O_O_O(c__s__1305000131, c__match_QMARK_, c__iter__1305000130 any) { t.F_s__1305000131 = c__s__1305000131; t.F_match_QMARK_ = c__match_QMARK_; t.F_iter__1305000130 = c__iter__1305000130 }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A) Invoke_O__O(self any) any { { var s__1305000131__1 any; var t_ any = t.F_s__1305000131; t.F_s__1305000131 = nil; s__1305000131__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1305000131__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000131__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_123.GetRawRoot__O()).Invoke_O__O(s__1305000131__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_124.GetRawRoot__O()).Invoke_O__O(s__1305000131__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000133__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_125.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_New_O_O_I_O(b__1305000133__6, t.F_match_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_fn_class = fncls__108d; tmp2 = fncls__108d } else { tmp2 = fncls__108 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1305000130); return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000133__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_134.GetRawRoot__O()).Invoke_O__O(s__1305000131__3))) } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000133__6), nil) } } else { var vec__1305000144__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1305000131__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000144__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000147__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000144__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000147__6, lang.RT_IntCast_J__I_NoInit(0), nil); var e__8 any = vec__1305000147__6; var tmp4 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(k__7, A_arbace_box_plan_A_const_20)
															if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(n__5, Lit_10)); if jrt.J2g_Truth(and__1927000168__auto____10) { tmp4 = lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(n__5, Lit_11)) } else { tmp4 = and__1927000168__auto____10 } } else { tmp4 = and__1927000168__auto____9 }
//line :263:1
	if jrt.J2g_Truth(tmp4) { var ext__9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_85.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_128, n__5)); var tmp5 any; var and__1927000168__auto____10_2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_132).Invoke_O__O(ext__9)


		if jrt.J2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_129.GetRawRoot__O()).Invoke_O_O__O(n__5, Lit_76)); if jrt.J2g_Truth(and__1927000168__auto____11) {

			tmp5 = lang.IFn_Cast(A_arbace_box_plan_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_match_QMARK_, n__5) } else {
//line :266:1
				tmp5 = and__1927000168__auto____11 } } else { tmp5 = and__1927000168__auto____10_2 }
//line :263:1
		if jrt.J2g_Truth(tmp5) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1305000130); return lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(n__5, ext__9, e__8), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000131__3))) } else { s__1305000131__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000131__3); continue L1 } } else { s__1305000131__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000131__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :263:1
func A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A) Ctor_O_O_I_O(c__b__1305000133, c__match_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1305000133 = c__b__1305000133; t.F_match_QMARK_ = c__match_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :263:1
func (t *A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A) Invoke_O__O(self any) any { { var i__1305000132__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000132__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000137__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000132__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000137__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000140__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000137__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000140__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = vec__1305000140__4; var tmp2 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(k__5, A_arbace_box_plan_A_const_20)
																if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_10)); if jrt.J2g_Truth(and__1927000168__auto____8) { tmp2 = lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_63.GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_11)) } else { tmp2 = and__1927000168__auto____8 } } else { tmp2 = and__1927000168__auto____7 }
//line :263:1
	if jrt.J2g_Truth(tmp2) { var ext__7 any = lang.IFn_Cast(A_arbace_box_plan_A_const_85.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_128, n__3)); var tmp3 any; var and__1927000168__auto____8_2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_126).Invoke_O__O(ext__7)


		if jrt.J2g_Truth(and__1927000168__auto____8_2) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_129.GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_76)); if jrt.J2g_Truth(and__1927000168__auto____9) {

			tmp3 = lang.IFn_Cast(A_arbace_box_plan_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_match_QMARK_, n__3) } else {
//line :266:1
				tmp3 = and__1927000168__auto____9 } } else { tmp3 = and__1927000168__auto____8_2 }
//line :263:1
		if jrt.J2g_Truth(tmp3) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_130.GetRawRoot__O()); var tmp5 any = t.F_b__1305000133; tmp4.Invoke_O_O__O(tmp5, lang.Tuple_Create_O_O_O__IPersistentVector(n__3, ext__7, e__6)); i__1305000132__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000132__1); continue L1 } else { i__1305000132__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000132__1); continue L1 } } else { i__1305000132__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000132__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_New_O_O(p0, p1 any) *A_arbace_box_plan_package_info_iter__1305000152__1305000156_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000152__1305000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_A) Ctor_O_O(c__match_QMARK_, c__path any) { t.F_match_QMARK_ = c__match_QMARK_; t.F_path = c__path }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_A) Invoke_O_O__O(self, s__1305000153__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_New_O_O_O_O(s__1305000153__1, t.F_match_QMARK_, t.F_path, self); var tmp2 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_fn_class = fncls__112d; tmp2 = fncls__112d } else { tmp2 = fncls__112 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :270:1
func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A) Ctor_O_O_O_O(c__s__1305000153, c__match_QMARK_, c__path, c__iter__1305000152 any) { t.F_s__1305000153 = c__s__1305000153; t.F_match_QMARK_ = c__match_QMARK_; t.F_path = c__path; t.F_iter__1305000152 = c__iter__1305000152 }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A) Invoke_O__O(self any) any { { var s__1305000153__1 any; var t_ any = t.F_s__1305000153; t.F_s__1305000153 = nil; s__1305000153__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1305000153__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000153__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_123.GetRawRoot__O()).Invoke_O__O(s__1305000153__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_124.GetRawRoot__O()).Invoke_O__O(s__1305000153__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000155__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_125.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_New_O_O_O_I_O(b__1305000155__6, t.F_match_QMARK_, t.F_path, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_fn_class = fncls__111d; tmp2 = fncls__111d } else { tmp2 = fncls__111 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1305000152); return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000155__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_134.GetRawRoot__O()).Invoke_O__O(s__1305000153__3))) } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000155__6), nil) } } else { var vec__1305000163__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1305000153__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000163__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000163__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000163__4, lang.RT_IntCast_J__I_NoInit(2), nil); if lang.Util_Equiv_O_O__Z_NoInit(ext__6, Lit_79) { var s__8 any = lang.IFn_Cast(A_arbace_box_plan_A_const_105.GetRawRoot__O()).Invoke_O__O(e__7); var b__9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_135.GetRawRoot__O()).Invoke_O__O(s__8); var tmp4 any; var or__1927000174__auto____10 bool = lang.Util_Identical_O_O__Z_NoInit(b__9, nil)


	if or__1927000174__auto____10 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____10).Ref() } else { tmp4 = lang.IFn_Cast(A_arbace_box_plan_A_const_136.GetRawRoot__O()).Invoke_O_O__O(t.F_match_QMARK_, b__9) }
//line :270:1
	if jrt.J2g_Truth(tmp4) { var info__10 any = lang.IFn_Cast(A_arbace_box_plan_A_const_137.GetRawRoot__O()).Invoke_O_O__O(s__8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, t.F_path, nil, n__5)).Ref()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_93.GetRawRoot__O()); var tmp6 any = A_arbace_box_plan_A_const_139; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, A_arbace_box_plan_A_const_95.Invoke_O__O(info__10)))) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1305000152); return lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, info__10), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000153__3))) } else { s__1305000153__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000153__3); continue L1 } } else { s__1305000153__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000153__3); continue L1 } } else { s__1305000153__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000153__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :270:1
func A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A) Ctor_O_O_O_I_O(c__b__1305000155, c__match_QMARK_, c__path any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1305000155 = c__b__1305000155; t.F_match_QMARK_ = c__match_QMARK_; t.F_path = c__path; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :270:1
func (t *A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A) Invoke_O__O(self any) any { { var i__1305000154__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000159__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000154__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000159__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000159__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000159__2, lang.RT_IntCast_J__I_NoInit(2), nil); if lang.Util_Equiv_O_O__Z_NoInit(ext__4, Lit_79) { var s__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_105.GetRawRoot__O()).Invoke_O__O(e__5); var b__7 any = lang.IFn_Cast(A_arbace_box_plan_A_const_135.GetRawRoot__O()).Invoke_O__O(s__6); var tmp2 any; var or__1927000174__auto____8 bool = lang.Util_Identical_O_O__Z_NoInit(b__7, nil)


	if or__1927000174__auto____8 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { tmp2 = lang.IFn_Cast(A_arbace_box_plan_A_const_136.GetRawRoot__O()).Invoke_O_O__O(t.F_match_QMARK_, b__7) }
//line :270:1
	if jrt.J2g_Truth(tmp2) { var info__8 any = lang.IFn_Cast(A_arbace_box_plan_A_const_137.GetRawRoot__O()).Invoke_O_O__O(s__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, t.F_path, nil, n__3)).Ref()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_93.GetRawRoot__O()); var tmp4 any = A_arbace_box_plan_A_const_138; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, A_arbace_box_plan_A_const_95.Invoke_O__O(info__8)))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_130.GetRawRoot__O()); var tmp6 any = t.F_b__1305000155; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(n__3, info__8)); i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } else { i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } } else { i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } } else { i__1305000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000154__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_New_O(p0 any) *A_arbace_box_plan_package_info_iter__1305000168__1305000172_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000168__1305000172_A{}; t.Ctor_O(p0); return t }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_A) Ctor_O(c__match_QMARK_ any) { t.F_match_QMARK_ = c__match_QMARK_ }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_A) Invoke_O_O__O(self, s__1305000169__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_New_O_O_O(self, t.F_match_QMARK_, s__1305000169__1); var tmp2 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_fn_class = fncls__115d; tmp2 = fncls__115d } else { tmp2 = fncls__115 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :277:1
func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A) Ctor_O_O_O(c__iter__1305000168, c__match_QMARK_, c__s__1305000169 any) { t.F_iter__1305000168 = c__iter__1305000168; t.F_match_QMARK_ = c__match_QMARK_; t.F_s__1305000169 = c__s__1305000169 }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A) Invoke_O__O(self any) any { { var s__1305000169__1 any; var t_ any = t.F_s__1305000169; t.F_s__1305000169 = nil; s__1305000169__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1305000169__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000169__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_123.GetRawRoot__O()).Invoke_O__O(s__1305000169__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_124.GetRawRoot__O()).Invoke_O__O(s__1305000169__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000171__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_125.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_New_O_I_O_O(t.F_match_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4, b__1305000171__6); var tmp2 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_fn_class = fncls__114d; tmp2 = fncls__114d } else { tmp2 = fncls__114 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1305000168); return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000171__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_134.GetRawRoot__O()).Invoke_O__O(s__1305000169__3))) } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000171__6), nil) } } else { var vec__1305000179__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1305000169__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000179__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000179__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000179__4, lang.RT_IntCast_J__I_NoInit(2), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(ext__6, Lit_79)) { var b__8 any = lang.IFn_Cast(A_arbace_box_plan_A_const_135.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_105.GetRawRoot__O()).Invoke_O__O(e__7)); var tmp4 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(b__8, nil)

	if or__1927000174__auto____9 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { tmp4 = lang.IFn_Cast(A_arbace_box_plan_A_const_136.GetRawRoot__O()).Invoke_O_O__O(t.F_match_QMARK_, b__8) }
//line :277:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1305000168); return lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, ext__6), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000169__3))) } else { s__1305000169__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000169__3); continue L1 } } else { s__1305000169__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000169__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :277:1
func A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A) Ctor_O_I_O_O(c__match_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1305000171 any) { t.F_match_QMARK_ = c__match_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1305000171 = c__b__1305000171 }
//line :277:1
func (t *A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A) Invoke_O__O(self any) any { { var i__1305000170__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000170__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000175__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000170__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000175__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ext__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000175__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000175__2, lang.RT_IntCast_J__I_NoInit(2), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(ext__4, Lit_79)) { var b__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_135.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_105.GetRawRoot__O()).Invoke_O__O(e__5)); var tmp2 any; var or__1927000174__auto____7 bool = lang.Util_Identical_O_O__Z_NoInit(b__6, nil)

	if or__1927000174__auto____7 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { tmp2 = lang.IFn_Cast(A_arbace_box_plan_A_const_136.GetRawRoot__O()).Invoke_O_O__O(t.F_match_QMARK_, b__6) }
//line :277:1
	if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_130.GetRawRoot__O()); var tmp4 any = t.F_b__1305000171; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(n__3, ext__4)); i__1305000170__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000170__1); continue L1 } else { i__1305000170__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000170__1); continue L1 } } else { i__1305000170__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000170__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_box_plan_package_info_fn__1305000184_A_New() *A_arbace_box_plan_package_info_fn__1305000184_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_fn__1305000184_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_box_plan_package_info_fn__1305000184_A) Ctor() {}
//line :286:1
func (t *A_arbace_box_plan_package_info_fn__1305000184_A) Invoke_O_O__O(self, p1__1305000126_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_150); return lang.IFn_Cast(A_arbace_box_plan_A_const_56.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_85.GetRawRoot__O()).Invoke_O__O(p1__1305000126_SHARP___1))) }



func A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_New_O_O(p0, p1 any) *A_arbace_box_plan_package_info_iter__1305000189__1305000193_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000189__1305000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_A) Ctor_O_O(c__dir, c__what any) { t.F_dir = c__dir; t.F_what = c__what }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_A) Invoke_O_O__O(self, s__1305000190__1 any) any { var tmp1 any = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_New_O_O_O_O(self, t.F_dir, s__1305000190__1, t.F_what); var tmp2 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_fn_class = fncls__119d; tmp2 = fncls__119d } else { tmp2 = fncls__119 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :290:1
func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A) Ctor_O_O_O_O(c__iter__1305000189, c__dir, c__s__1305000190, c__what any) { t.F_iter__1305000189 = c__iter__1305000189; t.F_dir = c__dir; t.F_s__1305000190 = c__s__1305000190; t.F_what = c__what }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A) Invoke_O__O(self any) any { { var s__1305000190__1 any; var t_ any = t.F_s__1305000190; t.F_s__1305000190 = nil; s__1305000190__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1305000190__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000190__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_123.GetRawRoot__O()).Invoke_O__O(s__1305000190__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_124.GetRawRoot__O()).Invoke_O__O(s__1305000190__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000192__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_125.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_New_O_O_I_O_O(t.F_dir, t.F_what, size__1927001038__auto____5, b__1305000192__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_fn_class = fncls__118d; tmp2 = fncls__118d } else { tmp2 = fncls__118 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1305000189); return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000192__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_134.GetRawRoot__O()).Invoke_O__O(s__1305000190__3))) } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000192__6), nil) } } else { var pt__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1305000190__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1305000189); return lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(pt__4, lang.IFn_Cast(A_arbace_box_plan_A_const_152.GetRawRoot__O()).Invoke_O_O_O__O(t.F_dir, pt__4, t.F_what)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000190__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :290:1
func A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A) Ctor_O_O_I_O_O(c__dir, c__what any, c__size__1927001038__auto__ int32, c__b__1305000192, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_what = c__what; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1305000192 = c__b__1305000192; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :290:1
func (t *A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A) Invoke_O__O(self any) any { { var i__1305000191__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pt__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000191__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_130.GetRawRoot__O()); var tmp3 any = t.F_b__1305000192; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(pt__2, lang.IFn_Cast(A_arbace_box_plan_A_const_152.GetRawRoot__O()).Invoke_O_O_O__O(t.F_dir, pt__2, t.F_what))); i__1305000191__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000191__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_box_plan_src_tree_A_New() *A_arbace_box_plan_src_tree_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_box_plan_src_tree_A) Ctor() {}
//line :296:1
func (t *A_arbace_box_plan_src_tree_A) Invoke_O_O__O(self, p__1305000200__0 any) any { var map__1305000201__2 any = p__1305000200__0; var map__1305000201__3 any; if lang.ISeq_InstanceOf(map__1305000201__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1305000201__2)) { map__1305000201__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_plan_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1305000201__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1305000201__2)) { map__1305000201__3 = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1305000201__2) } else { map__1305000201__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1305000201__3 = map__1305000201__2 }; var dir__4 any = lang.RT_Get_O_O__O_NoInit(map__1305000201__3, A_arbace_box_plan_A_const_20); var embed__5 any = lang.RT_Get_O_O__O_NoInit(map__1305000201__3, A_arbace_box_plan_A_const_148); var embedded__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_156.GetRawRoot__O(), A_arbace_box_plan_A_const_141.Invoke_O__O(embed__5))); var sub__7 any; var tmp1 any = A_arbace_box_plan_src_tree_sub__1305000203_A_New_O(embedded__6); var tmp2 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_A_fn_class; if




	fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_box_plan_src_tree_sub__1305000203_A_fn_class = fncls__124d; tmp2 = fncls__124d } else { tmp2 = fncls__124 }; sub__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn =








	lang.IFn_Cast(A_arbace_box_plan_A_const_155.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_90.GetRawRoot__O()); var tmp5 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp6 any; var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_New_O(sub__7); var tmp8 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_fn_class; if

	fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_fn_class = fncls__127d; tmp8 = fncls__127d } else { tmp8 = fncls__127 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_19.GetRawRoot__O()).Invoke_O__O(dir__4)); return /*line :310:1*/ tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, tmp6)) }
//line :301:1
func A_arbace_box_plan_src_tree_sub__1305000203_A_New_O(p0 any) *A_arbace_box_plan_src_tree_sub__1305000203_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_A{}; t.Ctor_O(p0); return t }
//line :301:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_A) Ctor_O(c__embedded any) { t.F_embedded = c__embedded }
//line :301:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_A) Invoke_O_O_O__O(self, h__1, prefix__2 any) any { var m__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_90.GetRawRoot__O()); var tmp2 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp3 any; var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_New_O_O_O(self, t.F_embedded, prefix__2); var tmp5 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_fn_class; if

	fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_fn_class = fncls__123d; tmp5 = fncls__123d } else { tmp5 = fncls__123 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_19.GetRawRoot__O()).Invoke_O__O(h__1)); m__3 = /*line :302:1*/tmp1.Invoke_O_O__O(tmp2, tmp3); if






	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(m__3)) { return lang.IFn_Cast(A_arbace_box_plan_A_const_155.GetRawRoot__O()).Invoke_O__O(m__3) } else { return nil } }
//line :303:1
func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A) Ctor_O_O_O(c__sub, c__embedded, c__prefix any) { t.F_sub = c__sub; t.F_embedded = c__embedded; t.F_prefix = c__prefix }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A) Invoke_O_O__O(self, s__1305000205__1 any) any { var tmp1 any = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_New_O_O_O_O_O(t.F_sub, s__1305000205__1, t.F_embedded, self, t.F_prefix); var tmp2 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_fn_class = fncls__122d; tmp2 = fncls__122d } else { tmp2 = fncls__122 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :303:1
func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A) Ctor_O_O_O_O_O(c__sub, c__s__1305000205, c__embedded, c__iter__1305000204, c__prefix any) { t.F_sub = c__sub; t.F_s__1305000205 = c__s__1305000205; t.F_embedded = c__embedded; t.F_iter__1305000204 = c__iter__1305000204; t.F_prefix = c__prefix }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A) Invoke_O__O(self any) any { { var s__1305000205__1 any; var t_ any = t.F_s__1305000205; t.F_s__1305000205 = nil; s__1305000205__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1305000205__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000205__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_123.GetRawRoot__O()).Invoke_O__O(s__1305000205__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_124.GetRawRoot__O()).Invoke_O__O(s__1305000205__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000207__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_125.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_New_O_O_O_O_I_O(t.F_sub, t.F_embedded, b__1305000207__6, t.F_prefix, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_fn_class = fncls__121d; tmp2 = fncls__121d } else { tmp2 = fncls__121 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1305000204); return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000207__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_134.GetRawRoot__O()).Invoke_O__O(s__1305000205__3))) } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000207__6), nil) } } else { var vec__1305000218__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1305000205__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000218__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000221__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000218__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000221__6, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000221__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any = vec__1305000221__6; var p__10 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__5)).Ref(); var e__11 any

	if lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_box_plan_A_const_20) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____11 any = tmp4.Invoke_O_O__O(eh__8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, p__10, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____11) { var t__12 any = temp__1927000414__auto____11; e__11 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__12) } else { e__11 = nil } } else { var tmp5 any; var or__1927000174__auto____11 any = lang.IFn_Cast(A_arbace_box_plan_A_const_129.GetRawRoot__O()).Invoke_O_O__O(n__5, Lit_102)
		if jrt.J2g_Truth(or__1927000174__auto____11) { tmp5 = or__1927000174__auto____11 } else { tmp5 = lang.IFn_Cast(t.F_embedded).Invoke_O__O(p__10) }
//line :305:1
		if jrt.J2g_Truth(tmp5) { e__11 = e__9 } else { e__11 = nil } }
//line :303:1
	if jrt.J2g_Truth(e__11) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1305000204); return lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, e__11), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000205__3))) } else { s__1305000205__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000205__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :303:1
func A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A) Ctor_O_O_O_O_I_O(c__sub, c__embedded, c__b__1305000207, c__prefix any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_sub = c__sub; t.F_embedded = c__embedded; t.F_b__1305000207 = c__b__1305000207; t.F_prefix = c__prefix; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :303:1
func (t *A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A) Invoke_O__O(self any) any { { var i__1305000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000211__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000206__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000211__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000214__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000211__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000214__4, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000214__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = vec__1305000214__4; var p__8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, n__3)).Ref(); var e__9 any

	if lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_box_plan_A_const_20) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____9 any = tmp2.Invoke_O_O__O(eh__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, p__8, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____9) { var t__10 any = temp__1927000414__auto____9; e__9 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__10) } else { e__9 = nil } } else { var tmp3 any; var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_box_plan_A_const_129.GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_102)
		if jrt.J2g_Truth(or__1927000174__auto____9) { tmp3 = or__1927000174__auto____9 } else { tmp3 = lang.IFn_Cast(t.F_embedded).Invoke_O__O(p__8) }
//line :305:1
		if jrt.J2g_Truth(tmp3) { e__9 = e__7 } else { e__9 = nil } }
//line :303:1
	if jrt.J2g_Truth(e__9) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_130.GetRawRoot__O()); var tmp5 any = t.F_b__1305000207; tmp4.Invoke_O_O__O(tmp5, lang.Tuple_Create_O_O__IPersistentVector(n__3, e__9)); i__1305000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000206__1); continue L1 } else { i__1305000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000206__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_New_O(p0 any) *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A{}; t.Ctor_O(p0); return t }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A) Ctor_O(c__sub any) { t.F_sub = c__sub }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A) Invoke_O_O__O(self, s__1305000228__1 any) any { var tmp1 any = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_New_O_O_O(s__1305000228__1, self, t.F_sub); var tmp2 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_fn_class = fncls__126d; tmp2 = fncls__126d } else { tmp2 = fncls__126 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :312:1
func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A) Ctor_O_O_O(c__s__1305000228, c__iter__1305000227, c__sub any) { t.F_s__1305000228 = c__s__1305000228; t.F_iter__1305000227 = c__iter__1305000227; t.F_sub = c__sub }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A) Invoke_O__O(self any) any { { var s__1305000228__1 any; var t_ any = t.F_s__1305000228; t.F_s__1305000228 = nil; s__1305000228__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1305000228__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1305000228__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_123.GetRawRoot__O()).Invoke_O__O(s__1305000228__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_124.GetRawRoot__O()).Invoke_O__O(s__1305000228__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1305000230__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_125.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_New_O_O_I_O(b__1305000230__6, t.F_sub, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_fn_class = fncls__125d; tmp2 = fncls__125d } else { tmp2 = fncls__125 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1305000227); return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000230__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_134.GetRawRoot__O()).Invoke_O__O(s__1305000228__3))) } else { return lang.IFn_Cast(A_arbace_box_plan_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_133.GetRawRoot__O()).Invoke_O__O(b__1305000230__6), nil) } } else { var vec__1305000241__4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1305000228__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000241__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000244__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000241__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000244__6, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000244__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any = vec__1305000244__6; var e__10 any
														if lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_box_plan_A_const_20) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____10 any = tmp4.Invoke_O_O__O(eh__8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, n__5, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____10) { var t__11 any = temp__1927000414__auto____10; e__10 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__11) } else { e__10 = nil } } else { e__10 = e__9 }
//line :312:1
	if jrt.J2g_Truth(e__10) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1305000227); return lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, e__10), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000228__3))) } else { s__1305000228__1 = lang.IFn_Cast(A_arbace_box_plan_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1305000228__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :312:1
func A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A) Ctor_O_O_I_O(c__b__1305000230, c__sub any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1305000230 = c__b__1305000230; t.F_sub = c__sub; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :312:1
func (t *A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A) Invoke_O__O(self any) any { { var i__1305000229__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1305000229__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1305000234__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1305000229__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1305000237__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000237__4, lang.RT_IntCast_J__I_NoInit(0), nil); var eh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000237__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = vec__1305000237__4; var e__8 any
																if lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_box_plan_A_const_20) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_sub); var temp__1927000414__auto____8 any = tmp2.Invoke_O_O__O(eh__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, n__3, nil)).Ref()); if jrt.J2g_Truth(temp__1927000414__auto____8) { var t__9 any = temp__1927000414__auto____8; e__8 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_plan_A_const_20, t__9) } else { e__8 = nil } } else { e__8 = e__7 }
//line :312:1
	if jrt.J2g_Truth(e__8) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_130.GetRawRoot__O()); var tmp4 any = t.F_b__1305000230; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(n__3, e__8)); i__1305000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000229__1); continue L1 } else { i__1305000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1305000229__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_box_plan_plan_A_New() *A_arbace_box_plan_plan_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_box_plan_plan_A) Ctor() {}
//line :317:1
func (t *A_arbace_box_plan_plan_A) Invoke_O_O__O(self, cfg__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_170.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_A_const_15; lang.IFn_Cast(A_arbace_box_plan_A_const_169.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_box_plan_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref())))
//line :317:1
	var tmp3 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var match_QMARK___4 any = lang.IFn_Cast(A_arbace_box_plan_A_const_157.GetRawRoot__O()).Invoke_O__O(cfg__0); var cfg__5 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_11.GetRawRoot__O()); var tmp5 any = A_arbace_box_plan_A_const_143; var tmp6 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_box_plan_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_box_plan_A_const_106.Invoke_O__O(cfg__0))




		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp6 = or__1927000174__auto____5 } else { tmp6 = lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(Lit_84, lang.PersistentArrayMap_EMPTY.Ref()) }; cfg__5 = tmp4.Invoke_O_O_O__O(cfg__0, tmp5, tmp6)
//line :317:1
		var done__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var order__7 any = lang.IFn_Cast(A_arbace_box_plan_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); var visit__8 any; var tmp7 any = A_arbace_box_plan_plan_visit__1305000250_A_New_O_O_O_O(order__7, match_QMARK___4, done__6, cfg__5); var tmp8 *jrt.Class
		var fncls__130 /*line :317:1*/*jrt.Class = A_arbace_box_plan_plan_visit__1305000250_A_fn_class







		if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_box_plan_plan_visit__1305000250_A_fn_class = fncls__130d; tmp8 = fncls__130d } else { tmp8 = fncls__130 }; visit__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
















		lang.IFn_Cast(visit__8).Invoke_O_O_O__O(A_arbace_box_plan_A_const_165.Invoke_O__O(cfg__5), jrt.Boolean_FALSE.Ref(), lang.PersistentList_EMPTY.Ref())
//line :317:1
		var tmp9 any = A_arbace_box_plan_A_const_32; var tmp10 any = A_arbace_box_plan_A_const_32.Invoke_O__O(cfg__5); var tmp11 any = A_arbace_box_plan_A_const_33; var tmp12 any = A_arbace_box_plan_A_const_33.Invoke_O__O(cfg__5); var tmp13 any = A_arbace_box_plan_A_const_163; var tmp14 any = A_arbace_box_plan_A_const_163.Invoke_O_O__O(cfg__5, Lit_86); var tmp15 any = A_arbace_box_plan_A_const_164; var tmp16 any = A_arbace_box_plan_A_const_164.Invoke_O_O__O(cfg__5, Lit_87); var tmp17 any = A_arbace_box_plan_A_const_165; var tmp18 any = A_arbace_box_plan_A_const_165.Invoke_O__O(cfg__5); var tmp19 any = A_arbace_box_plan_A_const_166; var tmp20 any = A_arbace_box_plan_A_const_166.Invoke_O__O(cfg__5); var tmp21 any = A_arbace_box_plan_A_const_167; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_145.GetRawRoot__O()); var tmp23 any = A_arbace_box_plan_plan_fn__1305000260_A_New(); var tmp24 *jrt.Class
		var fncls__131 /*line :317:1*/*jrt.Class = A_arbace_box_plan_plan_fn__1305000260_A_fn_class



























		if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_box_plan_plan_fn__1305000260_A_fn_class = fncls__131d; tmp24 = fncls__131d } else { tmp24 = fncls__131 }
//line :317:1
		tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), lang.IFn_Cast(A_arbace_box_plan_A_const_6.GetRawRoot__O()).Invoke_O__O(order__7)))) }; return nil }()


	lang.IFn_Cast(A_arbace_box_plan_A_const_168.GetRawRoot__O()).Invoke__O()
//line :317:1
	if tmp25 != nil { panic(tmp25) }; return tmp3
}






func A_arbace_box_plan_plan_visit__1305000250_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_plan_visit__1305000250_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_visit__1305000250_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :325:1
func (t *A_arbace_box_plan_plan_visit__1305000250_A) Ctor_O_O_O_O(c__order, c__match_QMARK_, c__done, c__cfg any) { t.F_order = c__order; t.F_match_QMARK_ = c__match_QMARK_; t.F_done = c__done; t.F_cfg = c__cfg }
//line :325:1
func (t *A_arbace_box_plan_plan_visit__1305000250_A) Invoke_O_O_O_O__O(self, p__1, from_std__2, stack__3 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_93.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, p__1)), stack__3)) {
		lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_plan_A_const_121.GetRawRoot__O()).Invoke_O_O__O(Lit_90, lang.IFn_Cast(A_arbace_box_plan_A_const_160.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(p__1, stack__3))))).Ref(), lang.PersistentArrayMap_EMPTY.Ref()) }
//line :325:1
	var or__1927000174__auto____4 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_box_plan_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_done), p__1)


	if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var loc__5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_box_plan_A_const_158.GetRawRoot__O()).Invoke_O_O_O__O(t.F_cfg, p__1, from_std__2)
		if jrt.J2g_Truth(or__1927000174__auto____5) { loc__5 = or__1927000174__auto____5 } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_14.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_91, nil, nil); var tmp3 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_30.GetRawRoot__O()).Invoke_O__O(stack__3)) { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_92, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_plan_A_const_31.GetRawRoot__O()).Invoke_O__O(stack__3))) } else { tmp3 = nil }; loc__5 = tmp1.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, p__1, tmp3.Ref())).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_plan_A_const_113, p__1))) }
//line :328:1
		var info__6 any = lang.IFn_Cast(A_arbace_box_plan_A_const_159.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_cfg, t.F_match_QMARK_, p__1, loc__5); var resolved__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_145.GetRawRoot__O()); var tmp5 any = A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_New_O_O_O_O(stack__3, self, p__1, loc__5); var tmp6 *jrt.Class
		var fncls__128 /*line :328:1*/*jrt.Class = A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_fn_class



		if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_fn_class = fncls__128d; tmp6 = fncls__128d } else { tmp6 = fncls__128 }; resolved__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), A_arbace_box_plan_A_const_147.Invoke_O__O(info__6))
//line :328:1
		var pkg__8 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_11.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_box_plan_A_const_161.GetRawRoot__O()).Invoke_O_O__O(info__6, A_arbace_box_plan_A_const_147); var tmp9 any = A_arbace_box_plan_A_const_95; var tmp10 any = lang.IFn_Cast(A_arbace_box_plan_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_140.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_plan_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_plan_A_const_85.GetRawRoot__O(), resolved__7))); var tmp11 any = A_arbace_box_plan_A_const_162; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_90.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_box_plan_A_const_151.GetRawRoot__O()).Invoke__O(); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_114.GetRawRoot__O()); var tmp15 any = A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_New(); var tmp16 *jrt.Class
		var fncls__129 /*line :328:1*/*jrt.Class = A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_fn_class








		if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_fn_class = fncls__129d; tmp16 = fncls__129d } else { tmp16 = fncls__129 }
//line :336:1
		pkg__8 = tmp7.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, tmp12.Invoke_O_O__O(tmp13, tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), resolved__7)))

		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_17.GetRawRoot__O()); var tmp18 any = t.F_done; tmp17.Invoke_O_O_O_O__O(tmp18, A_arbace_box_plan_A_const_11.GetRawRoot__O(), p__1, pkg__8)
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(p__1, A_arbace_box_plan_A_const_113.Invoke_O__O(pkg__8))) { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_17.GetRawRoot__O()); var tmp20 any = t.F_done; tmp19.Invoke_O_O_O_O__O(tmp20, A_arbace_box_plan_A_const_11.GetRawRoot__O(), A_arbace_box_plan_A_const_113.Invoke_O__O(pkg__8), pkg__8) }
		var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_17.GetRawRoot__O()); var tmp22 any = t.F_order; tmp21.Invoke_O_O_O__O(tmp22, A_arbace_box_plan_A_const_7.GetRawRoot__O(), pkg__8)
//line :328:1
		return pkg__8
	}
}

func A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :332:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A) Ctor_O_O_O_O(c__stack, c__visit, c__p, c__loc any) { t.F_stack = c__stack; t.F_visit = c__visit; t.F_p = c__p; t.F_loc = c__loc }
//line :332:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 *lang.Keyword = A_arbace_box_plan_A_const_113; var tmp2 lang.IFn = lang.IFn_Cast(t.F_visit); return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(i__1, A_arbace_box_plan_A_const_110.Invoke_O__O(t.F_loc), lang.IFn_Cast(A_arbace_box_plan_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_p, t.F_stack)))) }




func A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_New() *A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A) Ctor() {}
//line :337:1
func (t *A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A) Invoke_O_O__O(self, p__1305000253__1 any) any { var vec__1305000255__2 any = p__1305000253__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000255__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1305000255__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(A_arbace_box_plan_A_const_89.GetRawRoot__O()).Invoke_O_O__O(a__3, b__4) }







func A_arbace_box_plan_plan_fn__1305000260_A_New() *A_arbace_box_plan_plan_fn__1305000260_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_plan_fn__1305000260_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_box_plan_plan_fn__1305000260_A) Ctor() {}
//line :345:1
func (t *A_arbace_box_plan_plan_fn__1305000260_A) Invoke_O_O__O(self, pkg__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_plan_A_const_11.GetRawRoot__O()); var tmp2 any = A_arbace_box_plan_A_const_171; var G__1305000261__2_ any = lang.IFn_Cast(A_arbace_box_plan_A_const_161.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O_O__O(pkg__1, tmp2, lang.IFn_Cast(A_arbace_box_plan_A_const_172.GetRawRoot__O()).Invoke_O__O(pkg__1)), A_arbace_box_plan_A_const_20); if lang.Util_Identical_O_O__Z_NoInit(A_arbace_box_plan_A_const_148.Invoke_O__O(pkg__1), nil) { return lang.IFn_Cast(A_arbace_box_plan_A_const_161.GetRawRoot__O()).Invoke_O_O__O(G__1305000261__2_, A_arbace_box_plan_A_const_148) } else { return G__1305000261__2_ } }
































































































type A_arbace_box_plan_A struct{ jrt.Object }

var A_arbace_box_plan_A_const_pool *jrt.RefArray

var A_arbace_box_plan_A_const_0 *lang.Var

var A_arbace_box_plan_A_const_1 *lang.Var

var A_arbace_box_plan_A_const_2 any

var A_arbace_box_plan_A_const_3 any

var A_arbace_box_plan_A_const_4 any

var A_arbace_box_plan_A_const_5 *lang.Var

var A_arbace_box_plan_A_const_6 *lang.Var

var A_arbace_box_plan_A_const_7 *lang.Var

var A_arbace_box_plan_A_const_8 any

var A_arbace_box_plan_A_const_9 *lang.Var

var A_arbace_box_plan_A_const_10 *lang.Var

var A_arbace_box_plan_A_const_11 *lang.Var

var A_arbace_box_plan_A_const_12 *lang.Keyword

var A_arbace_box_plan_A_const_13 *lang.Var

var A_arbace_box_plan_A_const_14 *lang.Var

var A_arbace_box_plan_A_const_15 *lang.Var

var A_arbace_box_plan_A_const_16 *lang.Keyword

var A_arbace_box_plan_A_const_17 *lang.Var

var A_arbace_box_plan_A_const_18 *lang.Var

var A_arbace_box_plan_A_const_19 *lang.Var

var A_arbace_box_plan_A_const_20 *lang.Keyword

var A_arbace_box_plan_A_const_21 *lang.Var

var A_arbace_box_plan_A_const_22 *lang.Var

var A_arbace_box_plan_A_const_23 *lang.Var

var A_arbace_box_plan_A_const_24 *lang.Var

var A_arbace_box_plan_A_const_25 any

var A_arbace_box_plan_A_const_26 *lang.Var

var A_arbace_box_plan_A_const_27 *lang.Keyword

var A_arbace_box_plan_A_const_28 *lang.Var

var A_arbace_box_plan_A_const_29 *lang.Var

var A_arbace_box_plan_A_const_30 *lang.Var

var A_arbace_box_plan_A_const_31 *lang.Var

var A_arbace_box_plan_A_const_32 *lang.Keyword

var A_arbace_box_plan_A_const_33 *lang.Keyword

var A_arbace_box_plan_A_const_34 *lang.Keyword

var A_arbace_box_plan_A_const_35 *lang.Keyword

var A_arbace_box_plan_A_const_36 *lang.Keyword

var A_arbace_box_plan_A_const_37 *lang.Var

var A_arbace_box_plan_A_const_38 *lang.Var

var A_arbace_box_plan_A_const_39 *lang.Keyword

var A_arbace_box_plan_A_const_40 *lang.Var

var A_arbace_box_plan_A_const_41 *lang.Var

var A_arbace_box_plan_A_const_42 *lang.Var

var A_arbace_box_plan_A_const_43 *lang.Var

var A_arbace_box_plan_A_const_44 *lang.Var

var A_arbace_box_plan_A_const_45 *lang.Var

var A_arbace_box_plan_A_const_46 *lang.Var

var A_arbace_box_plan_A_const_47 any

var A_arbace_box_plan_A_const_48 any

var A_arbace_box_plan_A_const_49 *lang.Var

var A_arbace_box_plan_A_const_50 any

var A_arbace_box_plan_A_const_51 any

var A_arbace_box_plan_A_const_52 *lang.Var

var A_arbace_box_plan_A_const_53 any

var A_arbace_box_plan_A_const_54 *lang.Var

var A_arbace_box_plan_A_const_55 *lang.Var

var A_arbace_box_plan_A_const_56 *lang.Var

var A_arbace_box_plan_A_const_57 *lang.Var

var A_arbace_box_plan_A_const_58 any

var A_arbace_box_plan_A_const_59 *lang.Var

var A_arbace_box_plan_A_const_60 *lang.Var

var A_arbace_box_plan_A_const_61 *lang.Var

var A_arbace_box_plan_A_const_62 *lang.Var

var A_arbace_box_plan_A_const_63 *lang.Var

var A_arbace_box_plan_A_const_64 *lang.Var

var A_arbace_box_plan_A_const_65 *lang.Var

var A_arbace_box_plan_A_const_66 any

var A_arbace_box_plan_A_const_67 any

var A_arbace_box_plan_A_const_68 any

var A_arbace_box_plan_A_const_69 any

var A_arbace_box_plan_A_const_70 *lang.Var

var A_arbace_box_plan_A_const_71 any

var A_arbace_box_plan_A_const_72 any

var A_arbace_box_plan_A_const_73 any

var A_arbace_box_plan_A_const_74 any

var A_arbace_box_plan_A_const_75 any

var A_arbace_box_plan_A_const_76 any

var A_arbace_box_plan_A_const_77 any

var A_arbace_box_plan_A_const_78 any

var A_arbace_box_plan_A_const_79 *lang.Keyword

var A_arbace_box_plan_A_const_80 *lang.Var

var A_arbace_box_plan_A_const_81 *lang.Keyword

var A_arbace_box_plan_A_const_82 any

var A_arbace_box_plan_A_const_83 *lang.Var

var A_arbace_box_plan_A_const_84 any

var A_arbace_box_plan_A_const_85 *lang.Var

var A_arbace_box_plan_A_const_86 *lang.Var

var A_arbace_box_plan_A_const_87 any

var A_arbace_box_plan_A_const_88 *lang.Var

var A_arbace_box_plan_A_const_89 *lang.Var

var A_arbace_box_plan_A_const_90 *lang.Var

var A_arbace_box_plan_A_const_91 *lang.Var

var A_arbace_box_plan_A_const_92 *lang.Var

var A_arbace_box_plan_A_const_93 *lang.Var

var A_arbace_box_plan_A_const_94 *lang.Keyword

var A_arbace_box_plan_A_const_95 *lang.Keyword

var A_arbace_box_plan_A_const_96 *lang.Keyword

var A_arbace_box_plan_A_const_97 *lang.Var

var A_arbace_box_plan_A_const_98 any

var A_arbace_box_plan_A_const_99 *lang.Var

var A_arbace_box_plan_A_const_100 *lang.Var

var A_arbace_box_plan_A_const_101 any

var A_arbace_box_plan_A_const_102 any

var A_arbace_box_plan_A_const_103 any

var A_arbace_box_plan_A_const_104 any

var A_arbace_box_plan_A_const_105 *lang.Var

var A_arbace_box_plan_A_const_106 *lang.Keyword

var A_arbace_box_plan_A_const_107 *lang.Keyword

var A_arbace_box_plan_A_const_108 *lang.Keyword

var A_arbace_box_plan_A_const_109 *lang.Var

var A_arbace_box_plan_A_const_110 *lang.Keyword

var A_arbace_box_plan_A_const_111 *lang.Keyword

var A_arbace_box_plan_A_const_112 *lang.Var

var A_arbace_box_plan_A_const_113 *lang.Keyword

var A_arbace_box_plan_A_const_114 *lang.Var

var A_arbace_box_plan_A_const_115 *lang.Var

var A_arbace_box_plan_A_const_116 *lang.Var

var A_arbace_box_plan_A_const_117 *lang.Var

var A_arbace_box_plan_A_const_118 any

var A_arbace_box_plan_A_const_119 any

var A_arbace_box_plan_A_const_120 any

var A_arbace_box_plan_A_const_121 *lang.Var

var A_arbace_box_plan_A_const_122 *lang.Var

var A_arbace_box_plan_A_const_123 *lang.Var

var A_arbace_box_plan_A_const_124 *lang.Var

var A_arbace_box_plan_A_const_125 *lang.Var

var A_arbace_box_plan_A_const_126 any

var A_arbace_box_plan_A_const_127 *lang.Var

var A_arbace_box_plan_A_const_128 any

var A_arbace_box_plan_A_const_129 *lang.Var

var A_arbace_box_plan_A_const_130 *lang.Var

var A_arbace_box_plan_A_const_131 *lang.Var

var A_arbace_box_plan_A_const_132 any

var A_arbace_box_plan_A_const_133 *lang.Var

var A_arbace_box_plan_A_const_134 *lang.Var

var A_arbace_box_plan_A_const_135 *lang.Var

var A_arbace_box_plan_A_const_136 *lang.Var

var A_arbace_box_plan_A_const_137 *lang.Var

var A_arbace_box_plan_A_const_138 any

var A_arbace_box_plan_A_const_139 any

var A_arbace_box_plan_A_const_140 *lang.Var

var A_arbace_box_plan_A_const_141 *lang.Keyword

var A_arbace_box_plan_A_const_142 *lang.Keyword

var A_arbace_box_plan_A_const_143 *lang.Keyword

var A_arbace_box_plan_A_const_144 *lang.Keyword

var A_arbace_box_plan_A_const_145 *lang.Var

var A_arbace_box_plan_A_const_146 *lang.Keyword

var A_arbace_box_plan_A_const_147 *lang.Keyword

var A_arbace_box_plan_A_const_148 *lang.Keyword

var A_arbace_box_plan_A_const_149 *lang.Var

var A_arbace_box_plan_A_const_150 any

var A_arbace_box_plan_A_const_151 *lang.Var

var A_arbace_box_plan_A_const_152 *lang.Var

var A_arbace_box_plan_A_const_153 *lang.Var

var A_arbace_box_plan_A_const_154 any

var A_arbace_box_plan_A_const_155 *lang.Var

var A_arbace_box_plan_A_const_156 *lang.Var

var A_arbace_box_plan_A_const_157 *lang.Var

var A_arbace_box_plan_A_const_158 *lang.Var

var A_arbace_box_plan_A_const_159 *lang.Var

var A_arbace_box_plan_A_const_160 *lang.Var

var A_arbace_box_plan_A_const_161 *lang.Var

var A_arbace_box_plan_A_const_162 *lang.Keyword

var A_arbace_box_plan_A_const_163 *lang.Keyword

var A_arbace_box_plan_A_const_164 *lang.Keyword

var A_arbace_box_plan_A_const_165 *lang.Keyword

var A_arbace_box_plan_A_const_166 *lang.Keyword

var A_arbace_box_plan_A_const_167 *lang.Keyword

var A_arbace_box_plan_A_const_168 *lang.Var

var A_arbace_box_plan_A_const_169 *lang.Var

var A_arbace_box_plan_A_const_170 *lang.Var

var A_arbace_box_plan_A_const_171 *lang.Keyword

var A_arbace_box_plan_A_const_172 *lang.Var

var A_arbace_box_plan_A_init jrt.ClassInit

func A_arbace_box_plan_A_Init() { if !A_arbace_box_plan_A_init.Done() { A_arbace_box_plan_A_init.Run(A_arbace_box_plan_A_clinit) } }

func A_arbace_box_plan_A_clinit() { A_arbace_box_plan_A_clinit_p0(); A_arbace_box_plan_A_clinit_p1(); A_arbace_box_plan_A_clinit_p2(); A_arbace_box_plan_A_clinit_p3(); A_arbace_box_plan_A_clinit_p4(); A_arbace_box_plan_A_clinit_p5(); A_arbace_box_plan_A_clinit_p6(); A_arbace_box_plan_A_clinit_p7(); A_arbace_box_plan_A_clinit_p8(); A_arbace_box_plan_A_clinit_p9(); A_arbace_box_plan_A_clinit_p10(); A_arbace_box_plan_A_clinit_p11(); A_arbace_box_plan_A_clinit_p12(); A_arbace_box_plan_A_clinit_p13() }

func A_arbace_box_plan_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_plan_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 215); A_arbace_box_plan_A_const_0 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[42]); A_arbace_box_plan_A_const_1 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[43]); A_arbace_box_plan_A_const_2 = A_arbace_box_plan_A_const_pool.A[44]; A_arbace_box_plan_A_const_3 = A_arbace_box_plan_A_const_pool.A[45]; A_arbace_box_plan_A_const_4 = A_arbace_box_plan_A_const_pool.A[46]; A_arbace_box_plan_A_const_5 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[47]); A_arbace_box_plan_A_const_6 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[48]); A_arbace_box_plan_A_const_7 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[49]); A_arbace_box_plan_A_const_8 = A_arbace_box_plan_A_const_pool.A[50]; A_arbace_box_plan_A_const_9 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[51]); A_arbace_box_plan_A_const_10 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[52]); A_arbace_box_plan_A_const_11 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[53]) }

func A_arbace_box_plan_A_clinit_p1() { A_arbace_box_plan_A_const_12 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[54]); A_arbace_box_plan_A_const_13 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[55]); A_arbace_box_plan_A_const_14 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[56]); A_arbace_box_plan_A_const_15 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[57]); A_arbace_box_plan_A_const_16 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[58]); A_arbace_box_plan_A_const_17 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[59]); A_arbace_box_plan_A_const_18 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[60]); A_arbace_box_plan_A_const_19 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[61]); A_arbace_box_plan_A_const_20 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[62]); A_arbace_box_plan_A_const_21 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[63]); A_arbace_box_plan_A_const_22 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[64]); A_arbace_box_plan_A_const_23 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[65]) }

func A_arbace_box_plan_A_clinit_p2() { A_arbace_box_plan_A_const_24 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[66]); A_arbace_box_plan_A_const_25 = A_arbace_box_plan_A_const_pool.A[67]; A_arbace_box_plan_A_const_26 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[68]); A_arbace_box_plan_A_const_27 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[69]); A_arbace_box_plan_A_const_28 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[70]); A_arbace_box_plan_A_const_29 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[71]); A_arbace_box_plan_A_const_30 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[72]); A_arbace_box_plan_A_const_31 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[73]); A_arbace_box_plan_A_const_32 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[74]); A_arbace_box_plan_A_const_33 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[75]); A_arbace_box_plan_A_const_34 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[76]); A_arbace_box_plan_A_const_35 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[77]) }

func A_arbace_box_plan_A_clinit_p3() { A_arbace_box_plan_A_const_36 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[78]); A_arbace_box_plan_A_const_37 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[79]); A_arbace_box_plan_A_const_38 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[80]); A_arbace_box_plan_A_const_39 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[81]); A_arbace_box_plan_A_const_40 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[82]); A_arbace_box_plan_A_const_41 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[83]); A_arbace_box_plan_A_const_42 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[84]); A_arbace_box_plan_A_const_43 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[85]); A_arbace_box_plan_A_const_44 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[86]); A_arbace_box_plan_A_const_45 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[87]); A_arbace_box_plan_A_const_46 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[88]); A_arbace_box_plan_A_const_47 = A_arbace_box_plan_A_const_pool.A[89] }

func A_arbace_box_plan_A_clinit_p4() { A_arbace_box_plan_A_const_48 = A_arbace_box_plan_A_const_pool.A[90]; A_arbace_box_plan_A_const_49 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[91]); A_arbace_box_plan_A_const_50 = A_arbace_box_plan_A_const_pool.A[92]; A_arbace_box_plan_A_const_51 = A_arbace_box_plan_A_const_pool.A[93]; A_arbace_box_plan_A_const_52 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[94]); A_arbace_box_plan_A_const_53 = A_arbace_box_plan_A_const_pool.A[95]; A_arbace_box_plan_A_const_54 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[96]); A_arbace_box_plan_A_const_55 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[97]); A_arbace_box_plan_A_const_56 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[98]); A_arbace_box_plan_A_const_57 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[99]); A_arbace_box_plan_A_const_58 = A_arbace_box_plan_A_const_pool.A[100]; A_arbace_box_plan_A_const_59 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[101]); A_arbace_box_plan_A_const_60 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[102]) }

func A_arbace_box_plan_A_clinit_p5() { A_arbace_box_plan_A_const_61 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[103]); A_arbace_box_plan_A_const_62 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[104]); A_arbace_box_plan_A_const_63 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[105]); A_arbace_box_plan_A_const_64 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[106]); A_arbace_box_plan_A_const_65 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[107]); A_arbace_box_plan_A_const_66 = A_arbace_box_plan_A_const_pool.A[108]; A_arbace_box_plan_A_const_67 = A_arbace_box_plan_A_const_pool.A[109]; A_arbace_box_plan_A_const_68 = A_arbace_box_plan_A_const_pool.A[110]; A_arbace_box_plan_A_const_69 = A_arbace_box_plan_A_const_pool.A[111]; A_arbace_box_plan_A_const_70 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[112]); A_arbace_box_plan_A_const_71 = A_arbace_box_plan_A_const_pool.A[113]; A_arbace_box_plan_A_const_72 = A_arbace_box_plan_A_const_pool.A[114]; A_arbace_box_plan_A_const_73 = A_arbace_box_plan_A_const_pool.A[115]; A_arbace_box_plan_A_const_74 = A_arbace_box_plan_A_const_pool.A[116] }

func A_arbace_box_plan_A_clinit_p6() { A_arbace_box_plan_A_const_75 = A_arbace_box_plan_A_const_pool.A[117]; A_arbace_box_plan_A_const_76 = A_arbace_box_plan_A_const_pool.A[118]; A_arbace_box_plan_A_const_77 = A_arbace_box_plan_A_const_pool.A[119]; A_arbace_box_plan_A_const_78 = A_arbace_box_plan_A_const_pool.A[120]; A_arbace_box_plan_A_const_79 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[121]); A_arbace_box_plan_A_const_80 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[122]); A_arbace_box_plan_A_const_81 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[123]); A_arbace_box_plan_A_const_82 = A_arbace_box_plan_A_const_pool.A[124]; A_arbace_box_plan_A_const_83 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[125]); A_arbace_box_plan_A_const_84 = A_arbace_box_plan_A_const_pool.A[126]; A_arbace_box_plan_A_const_85 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[127]); A_arbace_box_plan_A_const_86 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[128]); A_arbace_box_plan_A_const_87 = A_arbace_box_plan_A_const_pool.A[129] }

func A_arbace_box_plan_A_clinit_p7() { A_arbace_box_plan_A_const_88 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[130]); A_arbace_box_plan_A_const_89 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[131]); A_arbace_box_plan_A_const_90 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[132]); A_arbace_box_plan_A_const_91 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[133]); A_arbace_box_plan_A_const_92 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[134]); A_arbace_box_plan_A_const_93 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[135]); A_arbace_box_plan_A_const_94 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[136]); A_arbace_box_plan_A_const_95 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[137]); A_arbace_box_plan_A_const_96 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[138]); A_arbace_box_plan_A_const_97 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[139]); A_arbace_box_plan_A_const_98 = A_arbace_box_plan_A_const_pool.A[140]; A_arbace_box_plan_A_const_99 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[141]) }

func A_arbace_box_plan_A_clinit_p8() { A_arbace_box_plan_A_const_100 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[142]); A_arbace_box_plan_A_const_101 = A_arbace_box_plan_A_const_pool.A[143]; A_arbace_box_plan_A_const_102 = A_arbace_box_plan_A_const_pool.A[144]; A_arbace_box_plan_A_const_103 = A_arbace_box_plan_A_const_pool.A[145]; A_arbace_box_plan_A_const_104 = A_arbace_box_plan_A_const_pool.A[146]; A_arbace_box_plan_A_const_105 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[147]); A_arbace_box_plan_A_const_106 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[148]); A_arbace_box_plan_A_const_107 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[149]); A_arbace_box_plan_A_const_108 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[150]); A_arbace_box_plan_A_const_109 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[151]); A_arbace_box_plan_A_const_110 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[152]); A_arbace_box_plan_A_const_111 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[153]); A_arbace_box_plan_A_const_112 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[154]) }

func A_arbace_box_plan_A_clinit_p9() { A_arbace_box_plan_A_const_113 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[155]); A_arbace_box_plan_A_const_114 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[156]); A_arbace_box_plan_A_const_115 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[157]); A_arbace_box_plan_A_const_116 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[158]); A_arbace_box_plan_A_const_117 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[159]); A_arbace_box_plan_A_const_118 = A_arbace_box_plan_A_const_pool.A[160]; A_arbace_box_plan_A_const_119 = A_arbace_box_plan_A_const_pool.A[161]; A_arbace_box_plan_A_const_120 = A_arbace_box_plan_A_const_pool.A[162]; A_arbace_box_plan_A_const_121 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[163]); A_arbace_box_plan_A_const_122 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[164]); A_arbace_box_plan_A_const_123 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[165]); A_arbace_box_plan_A_const_124 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[166]) }

func A_arbace_box_plan_A_clinit_p10() { A_arbace_box_plan_A_const_125 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[167]); A_arbace_box_plan_A_const_126 = A_arbace_box_plan_A_const_pool.A[168]; A_arbace_box_plan_A_const_127 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[169]); A_arbace_box_plan_A_const_128 = A_arbace_box_plan_A_const_pool.A[170]; A_arbace_box_plan_A_const_129 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[171]); A_arbace_box_plan_A_const_130 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[172]); A_arbace_box_plan_A_const_131 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[173]); A_arbace_box_plan_A_const_132 = A_arbace_box_plan_A_const_pool.A[174]; A_arbace_box_plan_A_const_133 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[175]); A_arbace_box_plan_A_const_134 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[176]); A_arbace_box_plan_A_const_135 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[177]); A_arbace_box_plan_A_const_136 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[178]) }

func A_arbace_box_plan_A_clinit_p11() { A_arbace_box_plan_A_const_137 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[179]); A_arbace_box_plan_A_const_138 = A_arbace_box_plan_A_const_pool.A[180]; A_arbace_box_plan_A_const_139 = A_arbace_box_plan_A_const_pool.A[181]; A_arbace_box_plan_A_const_140 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[182]); A_arbace_box_plan_A_const_141 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[183]); A_arbace_box_plan_A_const_142 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[184]); A_arbace_box_plan_A_const_143 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[185]); A_arbace_box_plan_A_const_144 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[186]); A_arbace_box_plan_A_const_145 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[187]); A_arbace_box_plan_A_const_146 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[188]); A_arbace_box_plan_A_const_147 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[189]); A_arbace_box_plan_A_const_148 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[190]) }

func A_arbace_box_plan_A_clinit_p12() { A_arbace_box_plan_A_const_149 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[191]); A_arbace_box_plan_A_const_150 = A_arbace_box_plan_A_const_pool.A[192]; A_arbace_box_plan_A_const_151 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[193]); A_arbace_box_plan_A_const_152 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[194]); A_arbace_box_plan_A_const_153 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[195]); A_arbace_box_plan_A_const_154 = A_arbace_box_plan_A_const_pool.A[196]; A_arbace_box_plan_A_const_155 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[197]); A_arbace_box_plan_A_const_156 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[198]); A_arbace_box_plan_A_const_157 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[199]); A_arbace_box_plan_A_const_158 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[200]); A_arbace_box_plan_A_const_159 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[201]); A_arbace_box_plan_A_const_160 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[202]) }

func A_arbace_box_plan_A_clinit_p13() { A_arbace_box_plan_A_const_161 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[203]); A_arbace_box_plan_A_const_162 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[204]); A_arbace_box_plan_A_const_163 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[205]); A_arbace_box_plan_A_const_164 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[206]); A_arbace_box_plan_A_const_165 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[207]); A_arbace_box_plan_A_const_166 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[208]); A_arbace_box_plan_A_const_167 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[209]); A_arbace_box_plan_A_const_168 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[210]); A_arbace_box_plan_A_const_169 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[211]); A_arbace_box_plan_A_const_170 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[212]); A_arbace_box_plan_A_const_171 = lang.Keyword_Cast(A_arbace_box_plan_A_const_pool.A[213]); A_arbace_box_plan_A_const_172 = lang.Var_Cast(A_arbace_box_plan_A_const_pool.A[214]) }

func A_arbace_box_plan_A_New() *A_arbace_box_plan_A { A_arbace_box_plan_A_Init(); t := &A_arbace_box_plan_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan_A) Ctor() {}

func (t *A_arbace_box_plan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan_A_class }

func (t *A_arbace_box_plan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_plan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan_A); return ok }

func A_arbace_box_plan_A_Cast(x any) *A_arbace_box_plan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan_A_class)) }; return v }



type A_arbace_box_plan_dir_at_A struct{ j2g_header uint64 }

var A_arbace_box_plan_dir_at_A_fn_class *jrt.Class



type A_arbace_box_plan_dir_at_fn__1305000014_A struct{ j2g_header uint64 }

var A_arbace_box_plan_dir_at_fn__1305000014_A_fn_class *jrt.Class



type A_arbace_box_plan_embed_files_A struct{ j2g_header uint64 }

var A_arbace_box_plan_embed_files_A_fn_class *jrt.Class



type A_arbace_box_plan_embed_files_walk__1305000114_A struct{ j2g_header uint64; F_all any }

var A_arbace_box_plan_embed_files_walk__1305000114_A_fn_class *jrt.Class



type A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A struct{ j2g_header uint64; F_walk, F_prefix, F_all any }

var A_arbace_box_plan_embed_files_walk__1305000114_fn__1305000116_A_fn_class *jrt.Class



type A_arbace_box_plan_entries_A struct{ j2g_header uint64 }

var A_arbace_box_plan_entries_A_fn_class *jrt.Class



type A_arbace_box_plan_eval1305000004_A struct{ jrt.Object }

func A_arbace_box_plan_eval1305000004_A_New() *A_arbace_box_plan_eval1305000004_A { t := &A_arbace_box_plan_eval1305000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan_eval1305000004_A) Ctor() {}

func (t *A_arbace_box_plan_eval1305000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan_eval1305000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan_eval1305000004_A_class }

func (t *A_arbace_box_plan_eval1305000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan_eval1305000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_plan_eval1305000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan_eval1305000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan_eval1305000004_A); return ok }

func A_arbace_box_plan_eval1305000004_A_Cast(x any) *A_arbace_box_plan_eval1305000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan_eval1305000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan_eval1305000004_A_class)) }; return v }



type A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A struct{ j2g_header uint64 }

var A_arbace_box_plan_eval1305000004_loading__1927001464__auto____1305000005_A_fn_class *jrt.Class



type A_arbace_box_plan_eval1305000008_A struct{ jrt.Object }

func A_arbace_box_plan_eval1305000008_A_New() *A_arbace_box_plan_eval1305000008_A { t := &A_arbace_box_plan_eval1305000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_plan_eval1305000008_A) Ctor() {}

func (t *A_arbace_box_plan_eval1305000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_plan_eval1305000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_plan_eval1305000008_A_class }

func (t *A_arbace_box_plan_eval1305000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_plan_eval1305000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_plan_eval1305000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_plan_eval1305000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_plan_eval1305000008_A); return ok }

func A_arbace_box_plan_eval1305000008_A_Cast(x any) *A_arbace_box_plan_eval1305000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_plan_eval1305000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_plan_eval1305000008_A_class)) }; return v }



type A_arbace_box_plan_eval1305000008_fn__1305000009_A struct{ j2g_header uint64 }

var A_arbace_box_plan_eval1305000008_fn__1305000009_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_A struct{ j2g_header uint64 }

var A_arbace_box_plan_eval_expr_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_and_e__1305000039_A struct{ j2g_header uint64; F_next_t, F_peek_t, F_not_e any }

var A_arbace_box_plan_eval_expr_and_e__1305000039_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_next_t__1305000035_A struct{ j2g_header uint64; F_toks any }

var A_arbace_box_plan_eval_expr_next_t__1305000035_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_not_e__1305000041_A struct{ j2g_header uint64; F_or_e, F_next_t, F_s, F_match_QMARK_ any }

var A_arbace_box_plan_eval_expr_not_e__1305000041_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_or_e__1305000037_A struct{ j2g_header uint64; F_next_t, F_peek_t, F_and_e any }

var A_arbace_box_plan_eval_expr_or_e__1305000037_A_fn_class *jrt.Class



type A_arbace_box_plan_eval_expr_peek_t__1305000033_A struct{ j2g_header uint64; F_toks any }

var A_arbace_box_plan_eval_expr_peek_t__1305000033_A_fn_class *jrt.Class



type A_arbace_box_plan_expr_tokens_A struct{ j2g_header uint64 }

var A_arbace_box_plan_expr_tokens_A_fn_class *jrt.Class



type A_arbace_box_plan_fail_A struct{ j2g_header uint64 }

var A_arbace_box_plan_fail_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000070_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000070_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_A struct{ j2g_header uint64; F_toks any }

var A_arbace_box_plan_go_info_fn__1305000072_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000073_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000078_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000080_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000085_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000072_fn__1305000087_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000090_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000090_A_fn_class *jrt.Class



type A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_info_fn__1305000090_fn__1305000091_A_fn_class *jrt.Class



type A_arbace_box_plan_go_mod_lang_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_mod_lang_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_A struct{ j2g_header uint64 }

var A_arbace_box_plan_go_tokens_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_A struct{ j2g_header uint64; F_n int32; F_s any }

var A_arbace_box_plan_go_tokens_step__1305000055_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A struct{ j2g_header uint64; F_i any; F_n int32; F_step, F_s, F_last any }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A struct{ j2g_header uint64; F_i, F_sb, F_s any }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000057_A_fn_class *jrt.Class



type A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A struct{ j2g_header uint64; F_i any; F_n int32; F_s any }

var A_arbace_box_plan_go_tokens_step__1305000055_fn__1305000056_fn__1305000059_A_fn_class *jrt.Class



type A_arbace_box_plan_header_build_A struct{ j2g_header uint64 }

var A_arbace_box_plan_header_build_A_fn_class *jrt.Class



type A_arbace_box_plan_locate_A struct{ j2g_header uint64 }

var A_arbace_box_plan_locate_A_fn_class *jrt.Class



type A_arbace_box_plan_locate_fn__1305000102_A struct{ j2g_header uint64; F_p any }

var A_arbace_box_plan_locate_fn__1305000102_A_fn_class *jrt.Class



type A_arbace_box_plan_name_ok_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_plan_name_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_A struct{ j2g_header uint64 }

var A_arbace_box_plan_package_info_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_fn__1305000184_A struct{ j2g_header uint64 }

var A_arbace_box_plan_package_info_fn__1305000184_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000130__1305000134_A struct{ j2g_header uint64; F_match_QMARK_ any }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A struct{ j2g_header uint64; F_s__1305000131, F_match_QMARK_, F_iter__1305000130 any }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A struct{ j2g_header uint64; F_b__1305000133, F_match_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_package_info_iter__1305000130__1305000134_fn__1305000135_fn__1305000136_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000152__1305000156_A struct{ j2g_header uint64; F_match_QMARK_, F_path any }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A struct{ j2g_header uint64; F_s__1305000153, F_match_QMARK_, F_path, F_iter__1305000152 any }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A struct{ j2g_header uint64; F_b__1305000155, F_match_QMARK_, F_path any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_package_info_iter__1305000152__1305000156_fn__1305000157_fn__1305000158_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000168__1305000172_A struct{ j2g_header uint64; F_match_QMARK_ any }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A struct{ j2g_header uint64; F_iter__1305000168, F_match_QMARK_, F_s__1305000169 any }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A struct{ j2g_header uint64; F_match_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1305000171 any }

var A_arbace_box_plan_package_info_iter__1305000168__1305000172_fn__1305000173_fn__1305000174_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000189__1305000193_A struct{ j2g_header uint64; F_dir, F_what any }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A struct{ j2g_header uint64; F_iter__1305000189, F_dir, F_s__1305000190, F_what any }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_A_fn_class *jrt.Class



type A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A struct{ j2g_header uint64; F_dir, F_what any; F_size__1927001038__auto__ int32; F_b__1305000192, F_c__1927001037__auto__ any }

var A_arbace_box_plan_package_info_iter__1305000189__1305000193_fn__1305000194_fn__1305000195_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_A struct{ j2g_header uint64 }

var A_arbace_box_plan_plan_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_fn__1305000260_A struct{ j2g_header uint64 }

var A_arbace_box_plan_plan_fn__1305000260_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_visit__1305000250_A struct{ j2g_header uint64; F_order, F_match_QMARK_, F_done, F_cfg any }

var A_arbace_box_plan_plan_visit__1305000250_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A struct{ j2g_header uint64; F_stack, F_visit, F_p, F_loc any }

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000251_A_fn_class *jrt.Class



type A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A struct{ j2g_header uint64 }

var A_arbace_box_plan_plan_visit__1305000250_fn__1305000254_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_A struct{ j2g_header uint64 }

var A_arbace_box_plan_src_tree_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A struct{ j2g_header uint64; F_sub any }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A struct{ j2g_header uint64; F_s__1305000228, F_iter__1305000227, F_sub any }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A struct{ j2g_header uint64; F_b__1305000230, F_sub any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_src_tree_iter__1305000227__1305000231_fn__1305000232_fn__1305000233_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_A struct{ j2g_header uint64; F_embedded any }

var A_arbace_box_plan_src_tree_sub__1305000203_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A struct{ j2g_header uint64; F_sub, F_embedded, F_prefix any }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A struct{ j2g_header uint64; F_sub, F_s__1305000205, F_embedded, F_iter__1305000204, F_prefix any }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_A_fn_class *jrt.Class



type A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A struct{ j2g_header uint64; F_sub, F_embedded, F_b__1305000207, F_prefix any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_plan_src_tree_sub__1305000203_iter__1305000204__1305000208_fn__1305000209_fn__1305000210_A_fn_class *jrt.Class



type A_arbace_box_plan_tag_fn_A struct{ j2g_header uint64 }

var A_arbace_box_plan_tag_fn_A_fn_class *jrt.Class



type A_arbace_box_plan_tag_fn_fn__1305000028_A struct{ j2g_header uint64; F_goos, F_on any }

var A_arbace_box_plan_tag_fn_fn__1305000028_A_fn_class *jrt.Class



type A_arbace_box_plan_text_A struct{ j2g_header uint64 }

var A_arbace_box_plan_text_A_fn_class *jrt.Class
