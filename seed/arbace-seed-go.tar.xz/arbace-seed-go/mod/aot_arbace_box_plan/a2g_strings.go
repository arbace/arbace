//line a2g_strings.ae:1
package aot_arbace_box_plan

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.box")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("box")

var Lit_6 *jrt.String = jrt.Intern("arbace.string")

var Lit_7 *jrt.String = jrt.Intern("str")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.box.plan")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("A Go program's build plan from source trees of the store (arbace.box's trees), as go list\n  -deps gives it for one GOOS and GOARCH with cgo off: the packages the main package reaches,\n  each after those it imports, each with its Go and assembly files (go/build's rules: the file\n  name's GOOS and GOARCH, //go:build lines, test files and files beginning with _ or . left\n  out, files importing \"C\" left out), its imports resolved (the standard library's vendor\n  directory, GOOSPKG's runtime/goos), its language version and its embedded files.\n\n    (plan cfg)   the plan: {:goos :goarch :goamd64 :goarm64 :main :include\n                            :packages [{:path :name :src :std :lang :go :s :imports\n                                        :importmap :embed} ...]}\n\n  cfg:\n    :goroot    the tree of GOROOT/src (std's packages at their import paths, vendor/, go.mod)\n    :modules   {module-path tree}: each module's root (its go.mod's go line is :lang)\n    :goospkg   the module whose goos/ is runtime/goos (TamaGo's GOOSPKG), when :goos is tamago\n    :main      the main package's import path\n    :goos :goarch :goamd64 :goarm64\n    :tool-tags, :release-tags   the toolchain's (go list's context.ToolTags, ReleaseTags)\n    :tags      more build tags (the program's)\n    :include   GOROOT/pkg/include's tree, passed on to the plan\n\n  A package's :src is a tree of its directory's files, the .h files of its subdirectories\n  (an assembly file includes them by a relative path) and its embedded files: what its compile\n  and asm read, so that a change elsewhere leaves its actions' keys alone. :embed is\n  {:patterns {PATTERN [FILE ...]}} (FILE relative to the package's directory) when it embeds.\n  Glob patterns in //go:embed are refused, as are packages with cgo, C or .syso files (the\n  driver builds Go and Go's assembly only).")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("ex-info")

var Lit_16 *jrt.String = jrt.Intern("assoc")

var Lit_17 *jrt.String = jrt.Intern("error")

var Lit_18 *jrt.String = jrt.Intern("tree")

var Lit_19 *jrt.String = jrt.Intern("fail")

var Lit_20 *jrt.String = jrt.Intern("*trees*")

var Lit_21 *jrt.String = jrt.Intern("swap!")

var Lit_22 *jrt.String = jrt.Intern("reduce")

var Lit_23 *jrt.String = jrt.Intern("entries")

var Lit_24 *jrt.String = jrt.Intern("dir")

var Lit_25 *jrt.String = jrt.Intern("reduced")

var Lit_26 *jrt.String = jrt.Intern("remove")

var Lit_27 *jrt.String = jrt.Intern("empty?")

var Lit_28 *jrt.String = jrt.Intern("split")

var Lit_29 *jrt.String = jrt.Intern("/")

var Lit_30 *jrt.String = jrt.Intern("get")

var Lit_31 *jrt.String = jrt.Intern("blob")

var Lit_32 *jrt.String = jrt.Intern("next")

var Lit_33 *jrt.String = jrt.Intern("to-array")

var Lit_34 *jrt.String = jrt.Intern("seq")

var Lit_35 *jrt.String = jrt.Intern("first")

var Lit_36 *jrt.String = jrt.Intern("goos")

var Lit_37 *jrt.String = jrt.Intern("goarch")

var Lit_38 *jrt.String = jrt.Intern("tool-tags")

var Lit_39 *jrt.String = jrt.Intern("release-tags")

var Lit_40 *jrt.String = jrt.Intern("tags")

var Lit_41 *jrt.String = jrt.Intern("set")

var Lit_42 *jrt.String = jrt.Intern("contains?")

var Lit_43 *jrt.String = jrt.Intern("else")

var Lit_44 *jrt.String = jrt.Intern("unix-os")

var Lit_45 *jrt.String = jrt.Intern("concat")

var Lit_46 *jrt.String = jrt.Intern("vec")

var Lit_47 *jrt.String = jrt.Intern("peek")

var Lit_48 *jrt.String = jrt.Intern("pop")

var Lit_49 *jrt.String = jrt.Intern("known-os")

var Lit_50 *jrt.String = jrt.Intern("known-arch")

var Lit_51 *jrt.String = jrt.Intern("\\.")

var Lit_52 *jrt.String = jrt.Intern("subs")

var Lit_53 *jrt.String = jrt.Intern("_")

var Lit_54 *jrt.String = jrt.Intern("re-seq")

var Lit_55 *jrt.String = jrt.Intern("\\(|\\)|!|&&|\\|\\||[A-Za-z0-9_.]+")

var Lit_56 *jrt.String = jrt.Intern("atom")

var Lit_57 *jrt.String = jrt.Intern("rest")

var Lit_58 *jrt.String = jrt.Intern("not")

var Lit_59 *jrt.String = jrt.Intern("re-matches")

var Lit_60 *jrt.String = jrt.Intern("[A-Za-z0-9_.]+")

var Lit_61 *jrt.String = jrt.Intern("expr-tokens")

var Lit_62 *jrt.String = jrt.Intern("split-lines")

var Lit_63 *jrt.String = jrt.Intern("trim")

var Lit_64 *jrt.String = jrt.Intern("blank?")

var Lit_65 *jrt.String = jrt.Intern("starts-with?")

var Lit_66 *jrt.String = jrt.Intern("re-find")

var Lit_67 *jrt.String = jrt.Intern("includes?")

var Lit_68 *jrt.String = jrt.Intern("^//go:build[ \\t]")

var Lit_69 *jrt.String = jrt.Intern(")")

var Lit_70 *jrt.String = jrt.Intern("string")

var Lit_71 *jrt.String = jrt.Intern("ident")

var Lit_72 *jrt.String = jrt.Intern("cons")

var Lit_73 *jrt.String = jrt.Intern("drop-while")

var Lit_74 *jrt.String = jrt.Intern("package")

var Lit_75 *jrt.String = jrt.Intern("second")

var Lit_76 *jrt.String = jrt.Intern("drop")

var Lit_77 *jrt.String = jrt.Intern("import")

var Lit_78 *jrt.String = jrt.Intern("split-with")

var Lit_79 *jrt.String = jrt.Intern("not=")

var Lit_80 *jrt.String = jrt.Intern("into")

var Lit_81 *jrt.String = jrt.Intern("keep")

var Lit_82 *jrt.String = jrt.Intern("vector?")

var Lit_83 *jrt.String = jrt.Intern("some")

var Lit_84 *jrt.String = jrt.Intern("imports")

var Lit_85 *jrt.String = jrt.Intern("embeds")

var Lit_86 *jrt.String = jrt.Intern("go-tokens")

var Lit_87 *jrt.String = jrt.Intern("embed")

var Lit_88 *jrt.String = jrt.Intern("mapcat")

var Lit_89 *jrt.String = jrt.Intern("map")

var Lit_90 *jrt.String = jrt.Intern("\\\"[^\\\"]*\\\"|`[^`]*`|\\S+")

var Lit_91 *jrt.String = jrt.Intern("(?m)^go[ \\t]+(\\d+\\.\\d+)")

var Lit_92 *jrt.String = jrt.Intern("text")

var Lit_93 *jrt.String = jrt.Intern("goroot")

var Lit_94 *jrt.String = jrt.Intern("modules")

var Lit_95 *jrt.String = jrt.Intern("goospkg")

var Lit_96 *jrt.String = jrt.Intern("dir-at")

var Lit_97 *jrt.String = jrt.Intern("std")

var Lit_98 *jrt.String = jrt.Intern("lang")

var Lit_99 *jrt.String = jrt.Intern("go-mod-lang")

var Lit_100 *jrt.String = jrt.Intern("path")

var Lit_101 *jrt.String = jrt.Intern("filter")

var Lit_102 *jrt.String = jrt.Intern("last")

var Lit_103 *jrt.String = jrt.Intern("sort-by")

var Lit_104 *jrt.String = jrt.Intern("key")

var Lit_105 *jrt.String = jrt.Intern("[*?\\[\\\\]")

var Lit_106 *jrt.String = jrt.Intern("join")

var Lit_107 *jrt.String = jrt.Intern("butlast")

var Lit_108 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_109 *jrt.String = jrt.Intern("chunk-first")

var Lit_110 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_111 *jrt.String = jrt.Intern("name-ok?")

var Lit_112 *jrt.String = jrt.Intern("(\\.[^.]*)$")

var Lit_113 *jrt.String = jrt.Intern("ends-with?")

var Lit_114 *jrt.String = jrt.Intern("chunk-append")

var Lit_115 *jrt.String = jrt.Intern("chunk-cons")

var Lit_116 *jrt.String = jrt.Intern("chunk")

var Lit_117 *jrt.String = jrt.Intern("chunk-rest")

var Lit_118 *jrt.String = jrt.Intern("header-build")

var Lit_119 *jrt.String = jrt.Intern("eval-expr")

var Lit_120 *jrt.String = jrt.Intern("go-info")

var Lit_121 *jrt.String = jrt.Intern("C")

var Lit_122 *jrt.String = jrt.Intern("distinct")

var Lit_123 *jrt.String = jrt.Intern("patterns")

var Lit_124 *jrt.String = jrt.Intern("name")

var Lit_125 *jrt.String = jrt.Intern("std-lang")

var Lit_126 *jrt.String = jrt.Intern("go")

var Lit_127 *jrt.String = jrt.Intern("mapv")

var Lit_128 *jrt.String = jrt.Intern("s")

var Lit_129 *jrt.String = jrt.Intern("raw-imports")

var Lit_130 *jrt.String = jrt.Intern("comp")

var Lit_131 *jrt.String = jrt.Intern(".s")

var Lit_132 *jrt.String = jrt.Intern("sorted-map")

var Lit_133 *jrt.String = jrt.Intern("embed-files")

var Lit_134 *jrt.String = jrt.Intern("sort")

var Lit_135 *jrt.String = jrt.Intern("unsafe")

var Lit_136 *jrt.String = jrt.Intern("put-tree")

var Lit_137 *jrt.String = jrt.Intern("val")

var Lit_138 *jrt.String = jrt.Intern("tag-fn")

var Lit_139 *jrt.String = jrt.Intern("locate")

var Lit_140 *jrt.String = jrt.Intern("package-info")

var Lit_141 *jrt.String = jrt.Intern("reverse")

var Lit_142 *jrt.String = jrt.Intern("dissoc")

var Lit_143 *jrt.String = jrt.Intern("importmap")

var Lit_144 *jrt.String = jrt.Intern("goamd64")

var Lit_145 *jrt.String = jrt.Intern("goarm64")

var Lit_146 *jrt.String = jrt.Intern("main")

var Lit_147 *jrt.String = jrt.Intern("include")

var Lit_148 *jrt.String = jrt.Intern("packages")

var Lit_149 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_150 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_151 *jrt.String = jrt.Intern("hash-map")

var Lit_152 *jrt.String = jrt.Intern("src")

var Lit_153 *jrt.String = jrt.Intern("src-tree")

var Lit_154 *jrt.String = jrt.Intern("arbace.box.plan$dir_at")

var Lit_155 *jrt.String = jrt.Intern("arbace.box.plan$dir_at$fn__1305000014")

var Lit_156 *jrt.String = jrt.Intern("arbace.box.plan$embed_files")

var Lit_157 *jrt.String = jrt.Intern("all:")

var Lit_158 *jrt.String = jrt.Intern("arbace.box.plan: ")

var Lit_159 *jrt.String = jrt.Intern(": //go:embed ")

var Lit_160 *jrt.String = jrt.Intern(": globs are not supported")

var Lit_161 *jrt.String = jrt.Intern(": no matching files")

var Lit_162 *jrt.String = jrt.Intern("arbace.box.plan$embed_files$walk__1305000114")

var Lit_163 *jrt.String = jrt.Intern("arbace.box.plan$embed_files$walk__1305000114$fn__1305000116")

var Lit_164 *jrt.String = jrt.Intern(".")

var Lit_165 *jrt.String = jrt.Intern("arbace.box.plan$entries")

var Lit_166 *jrt.String = jrt.Intern("arbace.box.plan: no tree ")

var Lit_167 *jrt.String = jrt.Intern("arbace.box.plan$eval1305000004$loading__1927001464__auto____1305000005")

var Lit_168 *jrt.String = jrt.Intern("arbace.box.plan$eval1305000008$fn__1305000009")

var Lit_169 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr")

var Lit_170 *jrt.String = jrt.Intern("arbace.box.plan: //go:build ")

var Lit_171 *jrt.String = jrt.Intern(": more after the expression")

var Lit_172 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$and_e__1305000039")

var Lit_173 *jrt.String = jrt.Intern("&&")

var Lit_174 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$next_t__1305000035")

var Lit_175 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$not_e__1305000041")

var Lit_176 *jrt.String = jrt.Intern("!")

var Lit_177 *jrt.String = jrt.Intern("(")

var Lit_178 *jrt.String = jrt.Intern("//go:build ")

var Lit_179 *jrt.String = jrt.Intern(": no )")

var Lit_180 *jrt.String = jrt.Intern(": not an expression")

var Lit_181 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$or_e__1305000037")

var Lit_182 *jrt.String = jrt.Intern("||")

var Lit_183 *jrt.String = jrt.Intern("arbace.box.plan$eval_expr$peek_t__1305000033")

var Lit_184 *jrt.String = jrt.Intern("arbace.box.plan$expr_tokens")

var Lit_185 *jrt.String = jrt.Intern("arbace.box.plan$fail")

var Lit_186 *jrt.String = jrt.Intern("arbace.box.plan$go_info")

var Lit_187 *jrt.String = jrt.Intern(": no package clause")

var Lit_188 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000070")

var Lit_189 *jrt.String = jrt.Intern(";")

var Lit_190 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072")

var Lit_191 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000073")

var Lit_192 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000078")

var Lit_193 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000080")

var Lit_194 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000085")

var Lit_195 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000072$fn__1305000087")

var Lit_196 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000090")

var Lit_197 *jrt.String = jrt.Intern("//go:embed ")

var Lit_198 *jrt.String = jrt.Intern("arbace.box.plan$go_info$fn__1305000090$fn__1305000091")

var Lit_199 *jrt.String = jrt.Intern("\"")

var Lit_200 *jrt.String = jrt.Intern("arbace.box.plan$go_mod_lang")

var Lit_201 *jrt.String = jrt.Intern("go.mod")

var Lit_202 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens")

var Lit_203 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055")

var Lit_204 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055$fn__1305000056")

var Lit_205 *jrt.String = jrt.Intern("indexOf")

var Lit_206 *jrt.String = jrt.Intern("\n")

var Lit_207 *jrt.String = jrt.Intern("*/")

var Lit_208 *jrt.String = jrt.Intern("`")

var Lit_209 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000057")

var Lit_210 *jrt.String = jrt.Intern("arbace.box.plan$go_tokens$step__1305000055$fn__1305000056$fn__1305000059")

var Lit_211 *jrt.String = jrt.Intern("arbace.box.plan$header_build")

var Lit_212 *jrt.String = jrt.Intern("//go:build")

var Lit_213 *jrt.String = jrt.Intern("//")

var Lit_214 *jrt.String = jrt.Intern("/*")

var Lit_215 *jrt.String = jrt.Intern("arbace.box.plan$locate")

var Lit_216 *jrt.String = jrt.Intern("tamago")

var Lit_217 *jrt.String = jrt.Intern("runtime/goos")

var Lit_218 *jrt.String = jrt.Intern("runtime/goos/")

var Lit_219 *jrt.String = jrt.Intern("arbace.box.plan: no module ")

var Lit_220 *jrt.String = jrt.Intern(" (GOOSPKG)")

var Lit_221 *jrt.String = jrt.Intern("vendor/")

var Lit_222 *jrt.String = jrt.Intern("arbace.box.plan$locate$fn__1305000102")

var Lit_223 *jrt.String = jrt.Intern("arbace.box.plan$name_ok_QMARK_")

var Lit_224 *jrt.String = jrt.Intern("test")

var Lit_225 *jrt.String = jrt.Intern("arbace.box.plan$package_info")

var Lit_226 *jrt.String = jrt.Intern("package ")

var Lit_227 *jrt.String = jrt.Intern(": no Go files for ")

var Lit_228 *jrt.String = jrt.Intern(": packages ")

var Lit_229 *jrt.String = jrt.Intern(", ")

var Lit_230 *jrt.String = jrt.Intern(": ")

var Lit_231 *jrt.String = jrt.Intern(": cgo, C or .syso files are not built by the box's driver")

var Lit_232 *jrt.String = jrt.Intern("arbace.box.plan$package_info$fn__1305000184")

var Lit_233 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000130__1305000134")

var Lit_234 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135")

var Lit_235 *jrt.String = jrt.Intern("_test.go")

var Lit_236 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000130__1305000134$fn__1305000135$fn__1305000136")

var Lit_237 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000152__1305000156")

var Lit_238 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157")

var Lit_239 *jrt.String = jrt.Intern(".go")

var Lit_240 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000152__1305000156$fn__1305000157$fn__1305000158")

var Lit_241 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000168__1305000172")

var Lit_242 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173")

var Lit_243 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000168__1305000172$fn__1305000173$fn__1305000174")

var Lit_244 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000189__1305000193")

var Lit_245 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194")

var Lit_246 *jrt.String = jrt.Intern("arbace.box.plan$package_info$iter__1305000189__1305000193$fn__1305000194$fn__1305000195")

var Lit_247 *jrt.String = jrt.Intern("arbace.box.plan$plan")

var Lit_248 *jrt.String = jrt.Intern("arbace.box.plan: GOROOT/src has no go.mod")

var Lit_249 *jrt.String = jrt.Intern("v1")

var Lit_250 *jrt.String = jrt.Intern("v8.0")

var Lit_251 *jrt.String = jrt.Intern("arbace.box.plan$plan$fn__1305000260")

var Lit_252 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000250")

var Lit_253 *jrt.String = jrt.Intern("arbace.box.plan: an import cycle: ")

var Lit_254 *jrt.String = jrt.Intern(" -> ")

var Lit_255 *jrt.String = jrt.Intern("arbace.box.plan: no package ")

var Lit_256 *jrt.String = jrt.Intern(", imported by ")

var Lit_257 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000250$fn__1305000251")

var Lit_258 *jrt.String = jrt.Intern("arbace.box.plan$plan$visit__1305000250$fn__1305000254")

var Lit_259 *jrt.String = jrt.Intern("arbace.box.plan$src_tree")

var Lit_260 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000227__1305000231")

var Lit_261 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232")

var Lit_262 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$iter__1305000227__1305000231$fn__1305000232$fn__1305000233")

var Lit_263 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203")

var Lit_264 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208")

var Lit_265 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209")

var Lit_266 *jrt.String = jrt.Intern(".h")

var Lit_267 *jrt.String = jrt.Intern("arbace.box.plan$src_tree$sub__1305000203$iter__1305000204__1305000208$fn__1305000209$fn__1305000210")

var Lit_268 *jrt.String = jrt.Intern("arbace.box.plan$tag_fn")

var Lit_269 *jrt.String = jrt.Intern("gc")

var Lit_270 *jrt.String = jrt.Intern("arbace.box.plan$tag_fn$fn__1305000028")

var Lit_271 *jrt.String = jrt.Intern("unix")

var Lit_272 *jrt.String = jrt.Intern("cgo")

var Lit_273 *jrt.String = jrt.Intern("arbace.box.plan$text")

var Lit_274 *jrt.String = jrt.Intern("arbace.box.plan: no blob ")

var Lit_275 *jrt.String = jrt.Intern("in-ns")

var Lit_276 *jrt.String = jrt.Intern("private")

var Lit_277 *jrt.String = jrt.Intern("arglists")

var Lit_278 *jrt.String = jrt.Intern("msg")

var Lit_279 *jrt.String = jrt.Intern("data")

var Lit_280 *jrt.String = jrt.Intern("line")

var Lit_281 *jrt.String = jrt.Intern("column")

var Lit_282 *jrt.String = jrt.Intern("file")

var Lit_283 *jrt.String = jrt.Intern("arbace/box/plan.ae")

var Lit_284 *jrt.String = jrt.Intern("dynamic")

var Lit_285 *jrt.String = jrt.Intern("h")

var Lit_286 *jrt.String = jrt.Intern("Tree h's map (read once a plan).")

var Lit_287 *jrt.String = jrt.Intern("p")

var Lit_288 *jrt.String = jrt.Intern("tag")

var Lit_289 *jrt.String = jrt.Intern("String")

var Lit_290 *jrt.String = jrt.Intern("The hash of directory path p (\"a/b\") under tree h, nil when there is none.")

var Lit_291 *jrt.String = jrt.Intern("keys")

var Lit_292 *jrt.String = jrt.Intern("go/build's matchTag for cfg (cgo off, the gc compiler).")

var Lit_293 *jrt.String = jrt.Intern("match?")

var Lit_294 *jrt.String = jrt.Intern("n")

var Lit_295 *jrt.String = jrt.Intern("Whether file name n's GOOS and GOARCH suffixes match (go/build's goodOSArchFile).")

var Lit_296 *jrt.String = jrt.Intern("The //go:build expression s under match?: || over && over !, parentheses.")

var Lit_297 *jrt.String = jrt.Intern("The //go:build line of source s's header (before its first line that is not a comment or\n  blank), nil when none.")

var Lit_298 *jrt.String = jrt.Intern("The tokens of Go source s from its start: identifiers, strings (their values), and the\n  punctuation ( ) ; . -- comments skipped, newlines given as ; where Go inserts one. Lazy.")

var Lit_299 *jrt.String = jrt.Intern("what")

var Lit_300 *jrt.String = jrt.Intern("Go source s's {:package NAME :imports [PATH ...] :embeds [PATTERN ...]}.")

var Lit_301 *jrt.String = jrt.Intern("go.mod's go line of tree h, as -lang takes it (go1.N), nil when none.")

var Lit_302 *jrt.String = jrt.Intern("cfg")

var Lit_303 *jrt.String = jrt.Intern("from-std")

var Lit_304 *jrt.String = jrt.Intern("Where import path p is: {:dir TREE :std BOOL :lang L :path RESOLVED}, or nil. from-std:\n  whether the importing package is the standard library's (its imports resolve in GOROOT's\n  vendor directory).")

var Lit_305 *jrt.String = jrt.Intern("d")

var Lit_306 *jrt.String = jrt.Intern("pattern")

var Lit_307 *jrt.String = jrt.Intern("The files pattern names in directory tree d (cmd/go's resolveEmbed, without globs): a file,\n  or a directory's files (not those beginning with . or _ unless the pattern says all:).")

var Lit_308 *jrt.String = jrt.Intern("Package p's entry (without :imports resolved), located as loc.")

var Lit_309 *jrt.String = jrt.Intern("Package pkg's source tree: its directory's files, the .h files under its subdirectories and\n  its embedded files.")

var Lit_310 *jrt.String = jrt.Intern("plan")

var Lit_311 *jrt.String = jrt.Intern("The plan of cfg's program (see the namespace's doc).")
