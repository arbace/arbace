//line aot_arbace_http__init.ae:1
package aot_arbace_http

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_http__init_A_Unit0__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); return lang.IFn_Cast(jrt.NN(A_arbace_http__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_http__init_A_const_1) }
//line :3:1
func A_arbace_http__init_A_Unit1__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_http__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_2)) }
//line :3:1
func A_arbace_http__init_A_Unit2__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); var tmp1 any = A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_New(); var tmp2 *jrt.Class; A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_Init(); tmp2 = A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :3:1
func A_arbace_http__init_A_Unit3__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_http__init_A_const_1)).Equals_O__Z(A_arbace_http__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_http_eval1534000008_fn__1534000009_A_New(); var tmp2 *jrt.Class; A_arbace_http_eval1534000008_fn__1534000009_A_Init(); tmp2 = A_arbace_http_eval1534000008_fn__1534000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }

func A_arbace_http__init_A_Load__O() any { A_arbace_http__init_A_Init(); A_arbace_http__init_A_Unit0__O(); A_arbace_http__init_A_Unit1__O(); A_arbace_http__init_A_Unit2__O(); A_arbace_http__init_A_Unit3__O(); A_arbace_http__init_A_Unit4__O(); A_arbace_http__init_A_Unit5__O(); A_arbace_http__init_A_Unit6__O(); A_arbace_http__init_A_Unit7__O(); A_arbace_http__init_A_Unit8__O(); A_arbace_http__init_A_Unit9__O(); A_arbace_http__init_A_Unit10__O(); A_arbace_http__init_A_Unit11__O(); A_arbace_http__init_A_Unit12__O(); A_arbace_http__init_A_Unit13__O(); return nil }
































func A_arbace_http__init_A_Unit4__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_4; var tmp2 any = A_arbace_http_latin1_A_New(); var tmp3 *jrt.Class; A_arbace_http_latin1_A_Init(); tmp3 = A_arbace_http_latin1_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_5)); return A_arbace_http__init_A_const_4.Ref() }

func A_arbace_http__init_A_Unit5__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(40, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_6; var tmp2 any = A_arbace_http_read_line_STAR__A_New(); var tmp3 *jrt.Class; A_arbace_http_read_line_STAR__A_Init(); tmp3 = A_arbace_http_read_line_STAR__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_7)); return A_arbace_http__init_A_const_6.Ref() }











func A_arbace_http__init_A_Unit6__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(52, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_8; var tmp2 any = A_arbace_http_read_n_A_New(); var tmp3 *jrt.Class; A_arbace_http_read_n_A_Init(); tmp3 = A_arbace_http_read_n_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_9)); return A_arbace_http__init_A_const_8.Ref() }











func A_arbace_http__init_A_Unit7__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_10; var tmp2 any = A_arbace_http_read_all_A_New(); var tmp3 *jrt.Class; A_arbace_http_read_all_A_Init(); tmp3 = A_arbace_http_read_all_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_11)); return A_arbace_http__init_A_const_10.Ref() }







func A_arbace_http__init_A_Unit8__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_12; var tmp2 any = A_arbace_http_read_headers_A_New(); var tmp3 *jrt.Class; A_arbace_http_read_headers_A_Init(); tmp3 = A_arbace_http_read_headers_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_13)); return A_arbace_http__init_A_const_12.Ref() }














func A_arbace_http__init_A_Unit9__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_14; var tmp2 any = A_arbace_http_read_chunked_A_New(); var tmp3 *jrt.Class; A_arbace_http_read_chunked_A_Init(); tmp3 = A_arbace_http_read_chunked_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_15)); return A_arbace_http__init_A_const_14.Ref() }










func A_arbace_http__init_A_Unit10__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(98, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_16; var tmp2 any = A_arbace_http_default_port_A_New(); var tmp3 *jrt.Class; A_arbace_http_default_port_A_Init(); tmp3 = A_arbace_http_default_port_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_17)); return A_arbace_http__init_A_const_16.Ref() }

func A_arbace_http__init_A_Unit11__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_18; var tmp2 any = A_arbace_http_open_A_New(); var tmp3 *jrt.Class; A_arbace_http_open_A_Init(); tmp3 = A_arbace_http_open_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_19)); return A_arbace_http__init_A_const_18.Ref() }














func A_arbace_http__init_A_Unit12__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_20; var tmp2 any = A_arbace_http_request_head_A_New(); var tmp3 *jrt.Class; A_arbace_http_request_head_A_Init(); tmp3 = A_arbace_http_request_head_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_21)); return A_arbace_http__init_A_const_20.Ref() }

















func A_arbace_http__init_A_Unit13__O() any { A_arbace_http__init_A_Init(); lang.Compiler_AOT_At_I_I__V(133, 1); var tmp1 *lang.Var = A_arbace_http__init_A_const_22; var tmp2 any = A_arbace_http_request_A_New(); var tmp3 *jrt.Class; A_arbace_http_request_A_Init(); tmp3 = A_arbace_http_request_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_http__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_http__init_A_const_23)); return A_arbace_http__init_A_const_22.Ref() }



type A_arbace_http__init_A struct{ jrt.Object }

var A_arbace_http__init_A_const_0 *lang.Var

var A_arbace_http__init_A_const_1 any

var A_arbace_http__init_A_const_2 any

var A_arbace_http__init_A_const_3 any

var A_arbace_http__init_A_const_4 *lang.Var

var A_arbace_http__init_A_const_5 any

var A_arbace_http__init_A_const_6 *lang.Var

var A_arbace_http__init_A_const_7 any

var A_arbace_http__init_A_const_8 *lang.Var

var A_arbace_http__init_A_const_9 any

var A_arbace_http__init_A_const_10 *lang.Var

var A_arbace_http__init_A_const_11 any

var A_arbace_http__init_A_const_12 *lang.Var

var A_arbace_http__init_A_const_13 any

var A_arbace_http__init_A_const_14 *lang.Var

var A_arbace_http__init_A_const_15 any

var A_arbace_http__init_A_const_16 *lang.Var

var A_arbace_http__init_A_const_17 any

var A_arbace_http__init_A_const_18 *lang.Var

var A_arbace_http__init_A_const_19 any

var A_arbace_http__init_A_const_20 *lang.Var

var A_arbace_http__init_A_const_21 any

var A_arbace_http__init_A_const_22 *lang.Var

var A_arbace_http__init_A_const_23 any

var A_arbace_http__init_A_init jrt.ClassInit

func A_arbace_http__init_A_Init() { if !A_arbace_http__init_A_init.Done() { A_arbace_http__init_A_init.Run(A_arbace_http__init_A_clinit) } }

func A_arbace_http__init_A_clinit() { A_arbace_http__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_151); A_arbace_http__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_http__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_http__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_http__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_13, Lit_83); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_http__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_154)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_156).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_81).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_13, Lit_20); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_http__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_163, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_13, Lit_29); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_http__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_165).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_168, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_13, Lit_87); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_http__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_165).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_13, Lit_25); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_http__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_169, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_13, Lit_86); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_http__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_165).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_13, Lit_30); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_http__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_170).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(98).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_13, Lit_74); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_http__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_171)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_173).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_174, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_13, Lit_84); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_http__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_64).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_171)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_175).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_176, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_http__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_13, Lit_177); A_arbace_http__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_63).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_64).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref())), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_179, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(133).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)) }

func A_arbace_http__init_A_New() *A_arbace_http__init_A { A_arbace_http__init_A_Init(); t := &A_arbace_http__init_A{}; t.Ctor(); return t }

func (t *A_arbace_http__init_A) Ctor() {}

func (t *A_arbace_http__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http__init_A) GetClass__Class() *jrt.Class { return A_arbace_http__init_A_class }

func (t *A_arbace_http__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http__init_A); return ok }

func A_arbace_http__init_A_Cast(x any) *A_arbace_http__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http__init_A_class)) }; return v }
