//line a2g_strings.ae:1
package aot_arbace_http

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("exclude")

var Lit_4 *jrt.String = jrt.Intern("get")

var Lit_5 *jrt.String = jrt.Intern("arbace.string")

var Lit_6 *jrt.String = jrt.Intern("as")

var Lit_7 *jrt.String = jrt.Intern("str")

var Lit_8 *jrt.String = jrt.Intern("arbace.tls")

var Lit_9 *jrt.String = jrt.Intern("tls")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.http")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("A small HTTP/1.1 client: one request per connection, over TLS for https: URLs (arbace.tls) and\n  a plain socket for http: ones. Enough to call a JSON API, e.g. from the box:\n\n    ARBACE_BOX_NET=dial=api.anthropic.com:443 arbace-box\n    (arbace.http/request {:method :post :url \"https://api.anthropic.com/v1/messages\"\n                          :headers {\"content-type\" \"application/json\" ...}\n                          :body \"{...}\"})\n    ;=> {:status 200 :reason \"OK\" :headers {\"content-type\" \"application/json\" ...}\n    ;    :body \"{...}\"}\n\n  (request opts): opts\n    :url      http://HOST[:PORT]/PATH?QUERY or https://... (required)\n    :method   a keyword or a string (default :get)\n    :headers  a map of names to values (strings); they replace the defaults by name (any case):\n              Host, User-Agent (arbace/VERSION), Content-Length when there is a body,\n              Connection: close\n    :body     a string (sent as UTF-8) or bytes\n    :as       :string (the default: the body decoded as UTF-8) or :bytes\n    :timeout  ms for the connection, the handshake and each read (0, the default: no limit)\n    :tls      arbace.tls/connect's options (:roots, :server-name ...); :alpn defaults to\n              [\"http/1.1\"]\n  It answers {:status :reason :headers :body}, the headers' names in lower case (a repeated one's\n  values joined by \", \"), the body read by its Content-Length, as chunks (Transfer-Encoding:\n  chunked), or to the connection's end; none for HEAD, 1xx, 204 and 304. Redirects are not\n  followed. The connection's and TLS's failures throw as arbace.tls/connect's; a response that\n  is not HTTP/1.x, or ends early, throws an IOException.")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("ends-with?")

var Lit_18 *jrt.String = jrt.Intern("subs")

var Lit_19 *jrt.String = jrt.Intern("else")

var Lit_20 *jrt.String = jrt.Intern("read-line*")

var Lit_21 *jrt.String = jrt.Intern("index-of")

var Lit_22 *jrt.String = jrt.Intern("lower-case")

var Lit_23 *jrt.String = jrt.Intern("trim")

var Lit_24 *jrt.String = jrt.Intern("assoc")

var Lit_25 *jrt.String = jrt.Intern("read-headers")

var Lit_26 *jrt.String = jrt.Intern("first")

var Lit_27 *jrt.String = jrt.Intern("split")

var Lit_28 *jrt.String = jrt.Intern(";")

var Lit_29 *jrt.String = jrt.Intern("read-n")

var Lit_30 *jrt.String = jrt.Intern("default-port")

var Lit_31 *jrt.String = jrt.Intern("connect")

var Lit_32 *jrt.String = jrt.Intern("merge")

var Lit_33 *jrt.String = jrt.Intern("alpn")

var Lit_34 *jrt.String = jrt.Intern("http/1.1")

var Lit_35 *jrt.String = jrt.Intern("timeout")

var Lit_36 *jrt.String = jrt.Intern("includes?")

var Lit_37 *jrt.String = jrt.Intern("blank?")

var Lit_38 *jrt.String = jrt.Intern("into")

var Lit_39 *jrt.String = jrt.Intern("upper-case")

var Lit_40 *jrt.String = jrt.Intern("join")

var Lit_41 *jrt.String = jrt.Intern("map")

var Lit_42 *jrt.String = jrt.Intern("name")

var Lit_43 *jrt.String = jrt.Intern("connection")

var Lit_44 *jrt.String = jrt.Intern("Connection")

var Lit_45 *jrt.String = jrt.Intern("close")

var Lit_46 *jrt.String = jrt.Intern("arbace-version")

var Lit_47 *jrt.String = jrt.Intern("seq")

var Lit_48 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_49 *jrt.String = jrt.Intern("chunk-first")

var Lit_50 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_51 *jrt.String = jrt.Intern("not")

var Lit_52 *jrt.String = jrt.Intern("chunk-append")

var Lit_53 *jrt.String = jrt.Intern("chunk-cons")

var Lit_54 *jrt.String = jrt.Intern("cons")

var Lit_55 *jrt.String = jrt.Intern("chunk")

var Lit_56 *jrt.String = jrt.Intern("chunk-rest")

var Lit_57 *jrt.String = jrt.Intern("rest")

var Lit_58 *jrt.String = jrt.Intern("sort-by")

var Lit_59 *jrt.String = jrt.Intern("key")

var Lit_60 *jrt.String = jrt.Intern("string")

var Lit_61 *jrt.String = jrt.Intern("next")

var Lit_62 *jrt.String = jrt.Intern("to-array")

var Lit_63 *jrt.String = jrt.Intern("url")

var Lit_64 *jrt.String = jrt.Intern("method")

var Lit_65 *jrt.String = jrt.Intern("headers")

var Lit_66 *jrt.String = jrt.Intern("body")

var Lit_67 *jrt.String = jrt.Intern("string?")

var Lit_68 *jrt.String = jrt.Intern("bytes?")

var Lit_69 *jrt.String = jrt.Intern("class")

var Lit_70 *jrt.String = jrt.Intern("PATCH")

var Lit_71 *jrt.String = jrt.Intern("POST")

var Lit_72 *jrt.String = jrt.Intern("PUT")

var Lit_73 *jrt.String = jrt.Intern("not-any?")

var Lit_74 *jrt.String = jrt.Intern("open")

var Lit_75 *jrt.String = jrt.Intern("re-matches")

var Lit_76 *jrt.String = jrt.Intern("pr-str")

var Lit_77 *jrt.String = jrt.Intern("<=")

var Lit_78 *jrt.String = jrt.Intern("not=")

var Lit_79 *jrt.String = jrt.Intern("status")

var Lit_80 *jrt.String = jrt.Intern("reason")

var Lit_81 *jrt.String = jrt.Intern("bytes")

var Lit_82 *jrt.String = jrt.Intern("keys")

var Lit_83 *jrt.String = jrt.Intern("latin1")

var Lit_84 *jrt.String = jrt.Intern("request-head")

var Lit_85 *jrt.String = jrt.Intern("(HTTP/1\\.[01]) ([0-9]{3})(?: (.*))?")

var Lit_86 *jrt.String = jrt.Intern("read-chunked")

var Lit_87 *jrt.String = jrt.Intern("read-all")

var Lit_88 *jrt.String = jrt.Intern(",")

var Lit_89 *jrt.String = jrt.Intern("arbace.http$default_port")

var Lit_90 *jrt.String = jrt.Intern("https")

var Lit_91 *jrt.String = jrt.Intern("arbace.http$eval1534000004$loading__1927001464__auto____1534000005")

var Lit_92 *jrt.String = jrt.Intern("java.io.BufferedInputStream")

var Lit_93 *jrt.String = jrt.Intern("java.io.BufferedOutputStream")

var Lit_94 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_95 *jrt.String = jrt.Intern("java.io.IOException")

var Lit_96 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_97 *jrt.String = jrt.Intern("java.io.OutputStream")

var Lit_98 *jrt.String = jrt.Intern("java.net.InetSocketAddress")

var Lit_99 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_100 *jrt.String = jrt.Intern("java.net.URI")

var Lit_101 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_102 *jrt.String = jrt.Intern("arbace.http$eval1534000008$fn__1534000009")

var Lit_103 *jrt.String = jrt.Intern("arbace.http$latin1")

var Lit_104 *jrt.String = jrt.Intern("arbace.http$open")

var Lit_105 *jrt.String = jrt.Intern("http")

var Lit_106 *jrt.String = jrt.Intern("HTTP: not an http: or https: URL: ")

var Lit_107 *jrt.String = jrt.Intern("arbace.http$read_all")

var Lit_108 *jrt.String = jrt.Intern("arbace.http$read_chunked")

var Lit_109 *jrt.String = jrt.Intern("HTTP: the connection ended in a chunk's size")

var Lit_110 *jrt.String = jrt.Intern("arbace.http$read_headers")

var Lit_111 *jrt.String = jrt.Intern("HTTP: the connection ended in the headers")

var Lit_112 *jrt.String = jrt.Intern("")

var Lit_113 *jrt.String = jrt.Intern(":")

var Lit_114 *jrt.String = jrt.Intern(", ")

var Lit_115 *jrt.String = jrt.Intern("arbace.http$read_line_STAR_")

var Lit_116 *jrt.String = jrt.Intern("\r")

var Lit_117 *jrt.String = jrt.Intern("arbace.http$read_n")

var Lit_118 *jrt.String = jrt.Intern("HTTP: the connection ended ")

var Lit_119 *jrt.String = jrt.Intern(" bytes before the body's end")

var Lit_120 *jrt.String = jrt.Intern("arbace.http$request")

var Lit_121 *jrt.String = jrt.Intern("HTTP: a body is a string or bytes, not ")

var Lit_122 *jrt.String = jrt.Intern("Content-Length")

var Lit_123 *jrt.String = jrt.Intern("HTTP: the connection ended before the response")

var Lit_124 *jrt.String = jrt.Intern("HTTP: not an HTTP/1.x response: ")

var Lit_125 *jrt.String = jrt.Intern("transfer-encoding")

var Lit_126 *jrt.String = jrt.Intern("content-length")

var Lit_127 *jrt.String = jrt.Intern("HEAD")

var Lit_128 *jrt.String = jrt.Intern("chunked")

var Lit_129 *jrt.String = jrt.Intern("arbace.http$request$fn__1534000075")

var Lit_130 *jrt.String = jrt.Intern("arbace.http$request_head")

var Lit_131 *jrt.String = jrt.Intern("[")

var Lit_132 *jrt.String = jrt.Intern("]")

var Lit_133 *jrt.String = jrt.Intern("/")

var Lit_134 *jrt.String = jrt.Intern("?")

var Lit_135 *jrt.String = jrt.Intern("host")

var Lit_136 *jrt.String = jrt.Intern("Host")

var Lit_137 *jrt.String = jrt.Intern("user-agent")

var Lit_138 *jrt.String = jrt.Intern("User-Agent")

var Lit_139 *jrt.String = jrt.Intern("arbace/")

var Lit_140 *jrt.String = jrt.Intern(" ")

var Lit_141 *jrt.String = jrt.Intern(" HTTP/1.1\r\n")

var Lit_142 *jrt.String = jrt.Intern("\r\n")

var Lit_143 *jrt.String = jrt.Intern("arbace.http$request_head$fn__1534000022")

var Lit_144 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000027__1534000031")

var Lit_145 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032")

var Lit_146 *jrt.String = jrt.Intern(": ")

var Lit_147 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032$fn__1534000033")

var Lit_148 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000043__1534000047")

var Lit_149 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048")

var Lit_150 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048$fn__1534000049")

var Lit_151 *jrt.String = jrt.Intern("in-ns")

var Lit_152 *jrt.String = jrt.Intern("private")

var Lit_153 *jrt.String = jrt.Intern("arglists")

var Lit_154 *jrt.String = jrt.Intern("s")

var Lit_155 *jrt.String = jrt.Intern("tag")

var Lit_156 *jrt.String = jrt.Intern("String")

var Lit_157 *jrt.String = jrt.Intern("line")

var Lit_158 *jrt.String = jrt.Intern("column")

var Lit_159 *jrt.String = jrt.Intern("file")

var Lit_160 *jrt.String = jrt.Intern("arbace/http.ae")

var Lit_161 *jrt.String = jrt.Intern("in")

var Lit_162 *jrt.String = jrt.Intern("InputStream")

var Lit_163 *jrt.String = jrt.Intern("A line of in up to LF, without its CR LF, as ISO-8859-1; nil at the end before any byte.")

var Lit_164 *jrt.String = jrt.Intern("out")

var Lit_165 *jrt.String = jrt.Intern("OutputStream")

var Lit_166 *jrt.String = jrt.Intern("n")

var Lit_167 *jrt.String = jrt.Intern("long")

var Lit_168 *jrt.String = jrt.Intern("n bytes of in into out; an IOException when it ends before.")

var Lit_169 *jrt.String = jrt.Intern("The header lines up to the empty line: {lower-case-name value}.")

var Lit_170 *jrt.String = jrt.Intern("scheme")

var Lit_171 *jrt.String = jrt.Intern("uri")

var Lit_172 *jrt.String = jrt.Intern("URI")

var Lit_173 *jrt.String = jrt.Intern("tls-opts")

var Lit_174 *jrt.String = jrt.Intern("The connection for uri: TLS for https.")

var Lit_175 *jrt.String = jrt.Intern("java.lang.String")

var Lit_176 *jrt.String = jrt.Intern("The request's line and headers.")

var Lit_177 *jrt.String = jrt.Intern("request")

var Lit_178 *jrt.String = jrt.Intern("or")

var Lit_179 *jrt.String = jrt.Intern("Sends one HTTP/1.1 request and reads its response (see the namespace's doc).")
