//line a2g_strings.ae:1
package aot_arbace_http

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn3,getyn13,arbace.stringkn2,asyn3,stryn10,arbace.tlsyn3,tlskn3,dockn4,elsekn4,alpnkn7,timeoutkn3,getkn6,stringkn3,urlkn6,methodkn7,headerskn4,bodykn3,tlskn6,statuskn6,reasonkn5,bytesv11,arbace.core5,referv11,arbace.core7,requireR0,R1,V1,R2,V3,R3,R4,R5,V3,R6,R4,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn11,arbace.httpm2,R8,s1662,A small HTTP/1.1 client: one request per connection, over TLS for https: URLs (arbace.tls) and\n  a plain socket for http: ones. Enough to call a JSON API, e.g. from the box:\n\n    ARBACE_BOX_NET=dial=api.anthropic.com:443 arbace-box\n    (arbace.http/request {:method :post :url \"https://api.anthropic.com/v1/messages\"\n                          :headers {\"content-type\" \"application/json\" ...}\n                          :body \"{...}\"})\n    ;=> {:status 200 :reason \"OK\" :headers {\"content-type\" \"application/json\" ...}\n    ;    :body \"{...}\"}\n\n  (request opts): opts\n    :url      http://HOST[:PORT]/PATH?QUERY or https://... (required)\n    :method   a keyword or a string (default :get)\n    :headers  a map of names to values (strings); they replace the defaults by name (any case):\n              Host, User-Agent (arbace/VERSION), Content-Length when there is a body,\n              Connection: close\n    :body     a string (sent as UTF-8) or bytes\n    :as       :string (the default: the body decoded as UTF-8) or :bytes\n    :timeout  ms for the connection, the handshake and each read (0, the default: no limit)\n    :tls      arbace.tls/connect's options (:roots, :server-name ...); :alpn defaults to\n              [\"http/1.1\"]\n  It answers {:status :reason :headers :body}, the headers' names in lower case (a repeated one's\n  values joined by \", \"), the body read by its Content-Length, as chunks (Transfer-Encoding:\n  chunked), or to the connection's end; none for HEAD, 1xx, 204 and 304. Redirects are not\n  followed. The connection's and TLS's failures throw as arbace.tls/connect's; a response that\n  is not HTTP/1.x, or ends early, throws an IOException.v11,arbace.core13,*loaded-libs*v13,arbace.string10,ends-with?v11,arbace.core4,subsR9,l0,l65536,l65536,v11,arbace.http10,read-line*v13,arbace.string8,index-ofv13,arbace.string10,lower-casev13,arbace.string4,trimv11,arbace.core5,assocv11,arbace.http12,read-headersv11,arbace.core5,firstv13,arbace.string5,splitp1,;v11,arbace.http6,read-nl443,l80,v11,arbace.http12,default-portv10,arbace.tls7,connectv11,arbace.core5,mergeR10,V1,s8,http/1.1R11,v13,arbace.string9,includes?v13,arbace.string6,blank?v11,arbace.core4,intov13,arbace.string10,upper-casev13,arbace.string4,joinv11,arbace.core3,mapv11,arbace.core4,namev11,arbace.core3,strV3,s10,connections10,Connections5,closev11,arbace.core14,arbace-versionv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core3,notv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core7,sort-byv11,arbace.core3,keyR12,R13,v11,arbace.core4,nextv11,arbace.core8,to-arrayR14,R15,R16,R17,R4,R18,v11,arbace.core7,string?v11,arbace.core6,bytes?v11,arbace.core5,classS3,s5,PATCHs4,POSTs3,PUTv11,arbace.core8,not-any?v11,arbace.http4,openv11,arbace.core10,re-matchesv11,arbace.core6,pr-strv11,arbace.core2,<=v11,arbace.core4,not=R19,R20,R21,v11,arbace.core4,keysv11,arbace.http6,latin1v11,arbace.http12,request-headp35,(HTTP/1\\.[01]) ([0-9]{3})(?: (.*))?l100,l199,l101,v11,arbace.http12,read-chunkedv11,arbace.http8,read-alll199,p1,,")

var Lit_1 *jrt.String = jrt.Intern("https")

var Lit_2 *jrt.String = jrt.Intern("java.io.BufferedInputStream")

var Lit_3 *jrt.String = jrt.Intern("java.io.BufferedOutputStream")

var Lit_4 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_5 *jrt.String = jrt.Intern("java.io.IOException")

var Lit_6 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_7 *jrt.String = jrt.Intern("java.io.OutputStream")

var Lit_8 *jrt.String = jrt.Intern("java.net.InetSocketAddress")

var Lit_9 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_10 *jrt.String = jrt.Intern("java.net.URI")

var Lit_11 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_12 *jrt.String = jrt.Intern("http")

var Lit_13 *jrt.String = jrt.Intern("HTTP: not an http: or https: URL: ")

var Lit_14 *jrt.String = jrt.Intern("HTTP: the connection ended in a chunk's size")

var Lit_15 *jrt.String = jrt.Intern("HTTP: the connection ended in the headers")

var Lit_16 *jrt.String = jrt.Intern("")

var Lit_17 *jrt.String = jrt.Intern(":")

var Lit_18 *jrt.String = jrt.Intern(", ")

var Lit_19 *jrt.String = jrt.Intern("\r")

var Lit_20 *jrt.String = jrt.Intern("HTTP: the connection ended ")

var Lit_21 *jrt.String = jrt.Intern(" bytes before the body's end")

var Lit_22 *jrt.String = jrt.Intern("HTTP: a body is a string or bytes, not ")

var Lit_23 *jrt.String = jrt.Intern("arbace.http$request$fn__1534000075")

var Lit_24 *jrt.String = jrt.Intern("Content-Length")

var Lit_25 *jrt.String = jrt.Intern("HTTP: the connection ended before the response")

var Lit_26 *jrt.String = jrt.Intern("HTTP: not an HTTP/1.x response: ")

var Lit_27 *jrt.String = jrt.Intern("transfer-encoding")

var Lit_28 *jrt.String = jrt.Intern("content-length")

var Lit_29 *jrt.String = jrt.Intern("HEAD")

var Lit_30 *jrt.String = jrt.Intern("chunked")

var Lit_31 *jrt.String = jrt.Intern("[")

var Lit_32 *jrt.String = jrt.Intern("]")

var Lit_33 *jrt.String = jrt.Intern("/")

var Lit_34 *jrt.String = jrt.Intern("?")

var Lit_35 *jrt.String = jrt.Intern("arbace.http$request_head$fn__1534000022")

var Lit_36 *jrt.String = jrt.Intern("host")

var Lit_37 *jrt.String = jrt.Intern("Host")

var Lit_38 *jrt.String = jrt.Intern("user-agent")

var Lit_39 *jrt.String = jrt.Intern("User-Agent")

var Lit_40 *jrt.String = jrt.Intern("arbace/")

var Lit_41 *jrt.String = jrt.Intern(" ")

var Lit_42 *jrt.String = jrt.Intern(" HTTP/1.1\r\n")

var Lit_43 *jrt.String = jrt.Intern("\r\n")

var Lit_44 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000027__1534000031")

var Lit_45 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000043__1534000047")

var Lit_46 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032")

var Lit_47 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032$fn__1534000033")

var Lit_48 *jrt.String = jrt.Intern(": ")

var Lit_49 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048")

var Lit_50 *jrt.String = jrt.Intern("arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048$fn__1534000049")

var Lit_51 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringyn5,byteskn4,linekn6,columnkn4,fileyn11,InputStreamyn12,OutputStreamyn4,longyn6,schemeyn3,URIyn7,timeoutyn8,tls-optsyn15,java.net.Socketyn6,methodyn7,headersyn16,java.lang.Stringkn4,keysyn3,urlyn4,bodyyn2,asyn3,tlskn2,orkn3,getkn6,stringv11,arbace.core5,in-nsMyn11,arbace.httpm2,R0,s1662,A small HTTP/1.1 client: one request per connection, over TLS for https: URLs (arbace.tls) and\n  a plain socket for http: ones. Enough to call a JSON API, e.g. from the box:\n\n    ARBACE_BOX_NET=dial=api.anthropic.com:443 arbace-box\n    (arbace.http/request {:method :post :url \"https://api.anthropic.com/v1/messages\"\n                          :headers {\"content-type\" \"application/json\" ...}\n                          :body \"{...}\"})\n    ;=> {:status 200 :reason \"OK\" :headers {\"content-type\" \"application/json\" ...}\n    ;    :body \"{...}\"}\n\n  (request opts): opts\n    :url      http://HOST[:PORT]/PATH?QUERY or https://... (required)\n    :method   a keyword or a string (default :get)\n    :headers  a map of names to values (strings); they replace the defaults by name (any case):\n              Host, User-Agent (arbace/VERSION), Content-Length when there is a body,\n              Connection: close\n    :body     a string (sent as UTF-8) or bytes\n    :as       :string (the default: the body decoded as UTF-8) or :bytes\n    :timeout  ms for the connection, the handshake and each read (0, the default: no limit)\n    :tls      arbace.tls/connect's options (:roots, :server-name ...); :alpn defaults to\n              [\"http/1.1\"]\n  It answers {:status :reason :headers :body}, the headers' names in lower case (a repeated one's\n  values joined by \", \"), the body read by its Content-Length, as chunks (Transfer-Encoding:\n  chunked), or to the connection's end; none for HEAD, 1xx, 204 and 304. Redirects are not\n  followed. The connection's and TLS's failures throw as arbace.tls/connect's; a response that\n  is not HTTP/1.x, or ends early, throws an IOException.m2,R0,s1662,A small HTTP/1.1 client: one request per connection, over TLS for https: URLs (arbace.tls) and\n  a plain socket for http: ones. Enough to call a JSON API, e.g. from the box:\n\n    ARBACE_BOX_NET=dial=api.anthropic.com:443 arbace-box\n    (arbace.http/request {:method :post :url \"https://api.anthropic.com/v1/messages\"\n                          :headers {\"content-type\" \"application/json\" ...}\n                          :body \"{...}\"})\n    ;=> {:status 200 :reason \"OK\" :headers {\"content-type\" \"application/json\" ...}\n    ;    :body \"{...}\"}\n\n  (request opts): opts\n    :url      http://HOST[:PORT]/PATH?QUERY or https://... (required)\n    :method   a keyword or a string (default :get)\n    :headers  a map of names to values (strings); they replace the defaults by name (any case):\n              Host, User-Agent (arbace/VERSION), Content-Length when there is a body,\n              Connection: close\n    :body     a string (sent as UTF-8) or bytes\n    :as       :string (the default: the body decoded as UTF-8) or :bytes\n    :timeout  ms for the connection, the handshake and each read (0, the default: no limit)\n    :tls      arbace.tls/connect's options (:roots, :server-name ...); :alpn defaults to\n              [\"http/1.1\"]\n  It answers {:status :reason :headers :body}, the headers' names in lower case (a repeated one's\n  values joined by \", \"), the body read by its Content-Length, as chunks (Transfer-Encoding:\n  chunked), or to the connection's end; none for HEAD, 1xx, 204 and 304. Redirects are not\n  followed. The connection's and TLS's failures throw as arbace.tls/connect's; a response that\n  is not HTTP/1.x, or ends early, throws an IOException.R1,v11,arbace.http6,latin1m10,R2,TR3,L1,MV1,Myn1,sm2,R4,R5,m2,R4,R6,R7,i38,R8,i1,R9,s14,arbace/http.aev11,arbace.http10,read-line*m12,R2,TR3,L1,V1,Myn2,inm2,R4,R10,R0,s88,A line of in up to LF, without its CR LF, as ISO-8859-1; nil at the end before any byte.R7,i40,R8,i1,R9,s14,arbace/http.aev11,arbace.http6,read-nm12,R2,TR3,L1,V3,Myn2,inm2,R4,R10,Myn3,outm2,R4,R11,Myn1,nm2,R4,R12,R0,s59,n bytes of in into out; an IOException when it ends before.R7,i52,R8,i1,R9,s14,arbace/http.aev11,arbace.http8,read-allm10,R2,TR3,L1,V2,Myn2,inm2,R4,R10,Myn3,outm2,R4,R11,R7,i64,R8,i1,R9,s14,arbace/http.aev11,arbace.http12,read-headersm12,R2,TR3,L1,V1,Myn2,inm2,R4,R10,R0,s63,The header lines up to the empty line: {lower-case-name value}.R7,i72,R8,i1,R9,s14,arbace/http.aev11,arbace.http12,read-chunkedm10,R2,TR3,L1,V2,Myn2,inm2,R4,R10,Myn3,outm2,R4,R11,R7,i87,R8,i1,R9,s14,arbace/http.aev11,arbace.http12,default-portm10,R2,TR3,L1,V1,R13,R7,i98,R8,i1,R9,s14,arbace/http.aev11,arbace.http4,openm12,R2,TR3,L1,MV3,Myn3,urim2,R4,R14,R15,R16,m2,R4,R17,R0,s38,The connection for uri: TLS for https.R7,i100,R8,i1,R9,s14,arbace/http.aev11,arbace.http12,request-headm12,R2,TR3,L1,MV3,R18,Myn3,urim2,R4,R14,R19,m2,R4,R20,R0,s31,The request's line and headers.R7,i115,R8,i1,R9,s14,arbace/http.aev11,arbace.http7,requestm10,R3,L1,V1,m4,R21,V7,R22,R18,R19,R23,R24,R15,R25,R26,m6,R18,R27,R24,R28,R15,l0,R0,s76,Sends one HTTP/1.1 request and reads its response (see the namespace's doc).R7,i133,R8,i1,R9,s14,arbace/http.ae")

var Lit_52 *jrt.String = jrt.Intern("arbace.http$eval1534000004$loading__1927001464__auto____1534000005")

var Lit_53 *jrt.String = jrt.Intern("arbace.http$eval1534000008$fn__1534000009")

var Lit_54 *jrt.String = jrt.Intern("arbace.http$latin1")

var Lit_55 *jrt.String = jrt.Intern("arbace.http$read_line_STAR_")

var Lit_56 *jrt.String = jrt.Intern("arbace.http$read_n")

var Lit_57 *jrt.String = jrt.Intern("arbace.http$read_all")

var Lit_58 *jrt.String = jrt.Intern("arbace.http$read_headers")

var Lit_59 *jrt.String = jrt.Intern("arbace.http$read_chunked")

var Lit_60 *jrt.String = jrt.Intern("arbace.http$default_port")

var Lit_61 *jrt.String = jrt.Intern("arbace.http$open")

var Lit_62 *jrt.String = jrt.Intern("arbace.http$request_head")

var Lit_63 *jrt.String = jrt.Intern("arbace.http$request")
