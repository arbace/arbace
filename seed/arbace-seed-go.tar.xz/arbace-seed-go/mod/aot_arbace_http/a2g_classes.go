//line a2g_classes.ae:1
package aot_arbace_http

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_http_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_A_New()}; return nil }

var A_arbace_http_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_http_A_new}

var A_arbace_http_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_http.A_arbace_http_A"})

func init() { i := A_arbace_http_A_class.Info(); i.IsInstance = A_arbace_http_A_InstanceOf; i.Init = A_arbace_http_A_Init; i.Table = A_arbace_http_A_members; jrt.RegisterGoType(A_arbace_http_A_class, reflect.TypeFor[A_arbace_http_A]()) }

func A_arbace_http_default_port_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_default_port_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_default_port_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_default_port_A_New()}; return nil }

func A_arbace_http_default_port_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_default_port_A_fn_class)}; return nil }

var A_arbace_http_default_port_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_default_port_A_invoke, New: A_arbace_http_default_port_A_new, Get: A_arbace_http_default_port_A_get}

var A_arbace_http_default_port_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$default_port", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_A_class, Simple: "default_port", Go: "arbace/aot_arbace_http.A_arbace_http_default_port_A", Source: "http.ae"})

func init() { i := A_arbace_http_default_port_A_class.Info(); i.IsInstance = A_arbace_http_default_port_A_InstanceOf; i.Init = A_arbace_http_default_port_A_Init; i.Table = A_arbace_http_default_port_A_members; jrt.RegisterGoType(A_arbace_http_default_port_A_class, reflect.TypeFor[A_arbace_http_default_port_A]()) }

func A_arbace_http_eval1534000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_eval1534000004_A_New()}; return nil }

var A_arbace_http_eval1534000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_http_eval1534000004_A_new}

var A_arbace_http_eval1534000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$eval1534000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_http_A_class, Simple: "eval1534000004", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000004_A"})

func init() { i := A_arbace_http_eval1534000004_A_class.Info(); i.IsInstance = A_arbace_http_eval1534000004_A_InstanceOf; i.Table = A_arbace_http_eval1534000004_A_members; jrt.RegisterGoType(A_arbace_http_eval1534000004_A_class, reflect.TypeFor[A_arbace_http_eval1534000004_A]()) }

func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_New()}; return nil }

func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_fn_class)}; return nil }

var A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_invoke, New: A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_new, Get: A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_get}

var A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$eval1534000004$loading__1927001464__auto____1534000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_http_eval1534000004_A_class, Simple: "loading__1927001464__auto____1534000005", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A", Source: "http.ae"})

func init() { i := A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_class.Info(); i.IsInstance = A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_InstanceOf; i.Init = A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_Init; i.Table = A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_members; jrt.RegisterGoType(A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_class, reflect.TypeFor[A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A]()) }

func A_arbace_http_eval1534000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_eval1534000008_A_New()}; return nil }

var A_arbace_http_eval1534000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_http_eval1534000008_A_new}

var A_arbace_http_eval1534000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$eval1534000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_http_A_class, Simple: "eval1534000008", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000008_A"})

func init() { i := A_arbace_http_eval1534000008_A_class.Info(); i.IsInstance = A_arbace_http_eval1534000008_A_InstanceOf; i.Table = A_arbace_http_eval1534000008_A_members; jrt.RegisterGoType(A_arbace_http_eval1534000008_A_class, reflect.TypeFor[A_arbace_http_eval1534000008_A]()) }

func A_arbace_http_eval1534000008_fn__1534000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_eval1534000008_fn__1534000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_http_eval1534000008_fn__1534000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_eval1534000008_fn__1534000009_A_New()}; return nil }

func A_arbace_http_eval1534000008_fn__1534000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_eval1534000008_fn__1534000009_A_fn_class)}; return nil }

var A_arbace_http_eval1534000008_fn__1534000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_eval1534000008_fn__1534000009_A_invoke, New: A_arbace_http_eval1534000008_fn__1534000009_A_new, Get: A_arbace_http_eval1534000008_fn__1534000009_A_get}

var A_arbace_http_eval1534000008_fn__1534000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$eval1534000008$fn__1534000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_http_eval1534000008_A_class, Simple: "fn__1534000009", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000008_fn__1534000009_A", Source: "http.ae"})

func init() { i := A_arbace_http_eval1534000008_fn__1534000009_A_class.Info(); i.IsInstance = A_arbace_http_eval1534000008_fn__1534000009_A_InstanceOf; i.Init = A_arbace_http_eval1534000008_fn__1534000009_A_Init; i.Table = A_arbace_http_eval1534000008_fn__1534000009_A_members; jrt.RegisterGoType(A_arbace_http_eval1534000008_fn__1534000009_A_class, reflect.TypeFor[A_arbace_http_eval1534000008_fn__1534000009_A]()) }

func A_arbace_http_latin1_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_latin1_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_latin1_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_latin1_A_New()}; return nil }

func A_arbace_http_latin1_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_latin1_A_fn_class)}; return nil }

var A_arbace_http_latin1_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_latin1_A_invoke, New: A_arbace_http_latin1_A_new, Get: A_arbace_http_latin1_A_get}

var A_arbace_http_latin1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$latin1", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_A_class, Simple: "latin1", Go: "arbace/aot_arbace_http.A_arbace_http_latin1_A", Source: "http.ae"})

func init() { i := A_arbace_http_latin1_A_class.Info(); i.IsInstance = A_arbace_http_latin1_A_InstanceOf; i.Init = A_arbace_http_latin1_A_Init; i.Table = A_arbace_http_latin1_A_members; jrt.RegisterGoType(A_arbace_http_latin1_A_class, reflect.TypeFor[A_arbace_http_latin1_A]()) }

func A_arbace_http_open_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_open_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_http_open_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_open_A_New()}; return nil }

func A_arbace_http_open_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_open_A_fn_class)}; return nil }

var A_arbace_http_open_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_open_A_invoke, New: A_arbace_http_open_A_new, Get: A_arbace_http_open_A_get}

var A_arbace_http_open_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$open", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_http_A_class, Simple: "open", Go: "arbace/aot_arbace_http.A_arbace_http_open_A", Source: "http.ae"})

func init() { i := A_arbace_http_open_A_class.Info(); i.IsInstance = A_arbace_http_open_A_InstanceOf; i.Init = A_arbace_http_open_A_Init; i.Table = A_arbace_http_open_A_members; jrt.RegisterGoType(A_arbace_http_open_A_class, reflect.TypeFor[A_arbace_http_open_A]()) }

func A_arbace_http_read_all_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_read_all_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_http_read_all_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_read_all_A_New()}; return nil }

func A_arbace_http_read_all_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_read_all_A_fn_class)}; return nil }

var A_arbace_http_read_all_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_read_all_A_invoke, New: A_arbace_http_read_all_A_new, Get: A_arbace_http_read_all_A_get}

var A_arbace_http_read_all_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$read_all", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_http_A_class, Simple: "read_all", Go: "arbace/aot_arbace_http.A_arbace_http_read_all_A", Source: "http.ae"})

func init() { i := A_arbace_http_read_all_A_class.Info(); i.IsInstance = A_arbace_http_read_all_A_InstanceOf; i.Init = A_arbace_http_read_all_A_Init; i.Table = A_arbace_http_read_all_A_members; jrt.RegisterGoType(A_arbace_http_read_all_A_class, reflect.TypeFor[A_arbace_http_read_all_A]()) }

func A_arbace_http_read_chunked_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_read_chunked_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_http_read_chunked_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_read_chunked_A_New()}; return nil }

func A_arbace_http_read_chunked_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_read_chunked_A_fn_class)}; return nil }

var A_arbace_http_read_chunked_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_read_chunked_A_invoke, New: A_arbace_http_read_chunked_A_new, Get: A_arbace_http_read_chunked_A_get}

var A_arbace_http_read_chunked_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$read_chunked", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_http_A_class, Simple: "read_chunked", Go: "arbace/aot_arbace_http.A_arbace_http_read_chunked_A", Source: "http.ae"})

func init() { i := A_arbace_http_read_chunked_A_class.Info(); i.IsInstance = A_arbace_http_read_chunked_A_InstanceOf; i.Init = A_arbace_http_read_chunked_A_Init; i.Table = A_arbace_http_read_chunked_A_members; jrt.RegisterGoType(A_arbace_http_read_chunked_A_class, reflect.TypeFor[A_arbace_http_read_chunked_A]()) }

func A_arbace_http_read_headers_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_read_headers_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_read_headers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_read_headers_A_New()}; return nil }

func A_arbace_http_read_headers_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_read_headers_A_fn_class)}; return nil }

var A_arbace_http_read_headers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_read_headers_A_invoke, New: A_arbace_http_read_headers_A_new, Get: A_arbace_http_read_headers_A_get}

var A_arbace_http_read_headers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$read_headers", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_A_class, Simple: "read_headers", Go: "arbace/aot_arbace_http.A_arbace_http_read_headers_A", Source: "http.ae"})

func init() { i := A_arbace_http_read_headers_A_class.Info(); i.IsInstance = A_arbace_http_read_headers_A_InstanceOf; i.Init = A_arbace_http_read_headers_A_Init; i.Table = A_arbace_http_read_headers_A_members; jrt.RegisterGoType(A_arbace_http_read_headers_A_class, reflect.TypeFor[A_arbace_http_read_headers_A]()) }

func A_arbace_http_read_line_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_read_line_STAR__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_read_line_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_read_line_STAR__A_New()}; return nil }

func A_arbace_http_read_line_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_read_line_STAR__A_fn_class)}; return nil }

var A_arbace_http_read_line_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_read_line_STAR__A_invoke, New: A_arbace_http_read_line_STAR__A_new, Get: A_arbace_http_read_line_STAR__A_get}

var A_arbace_http_read_line_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$read_line_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_A_class, Simple: "read_line_STAR_", Go: "arbace/aot_arbace_http.A_arbace_http_read_line_STAR__A", Source: "http.ae"})

func init() { i := A_arbace_http_read_line_STAR__A_class.Info(); i.IsInstance = A_arbace_http_read_line_STAR__A_InstanceOf; i.Init = A_arbace_http_read_line_STAR__A_Init; i.Table = A_arbace_http_read_line_STAR__A_members; jrt.RegisterGoType(A_arbace_http_read_line_STAR__A_class, reflect.TypeFor[A_arbace_http_read_line_STAR__A]()) }

func A_arbace_http_read_n_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_read_n_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_http_read_n_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_read_n_A_New()}; return nil }

func A_arbace_http_read_n_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_read_n_A_fn_class)}; return nil }

var A_arbace_http_read_n_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_read_n_A_invoke, New: A_arbace_http_read_n_A_new, Get: A_arbace_http_read_n_A_get}

var A_arbace_http_read_n_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$read_n", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_http_A_class, Simple: "read_n", Go: "arbace/aot_arbace_http.A_arbace_http_read_n_A", Source: "http.ae"})

func init() { i := A_arbace_http_read_n_A_class.Info(); i.IsInstance = A_arbace_http_read_n_A_InstanceOf; i.Init = A_arbace_http_read_n_A_Init; i.Table = A_arbace_http_read_n_A_members; jrt.RegisterGoType(A_arbace_http_read_n_A_class, reflect.TypeFor[A_arbace_http_read_n_A]()) }

func A_arbace_http_request_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_request_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_A_New()}; return nil }

func A_arbace_http_request_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_A_fn_class)}; return nil }

var A_arbace_http_request_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_A_invoke, New: A_arbace_http_request_A_new, Get: A_arbace_http_request_A_get}

var A_arbace_http_request_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_A_class, Simple: "request", Go: "arbace/aot_arbace_http.A_arbace_http_request_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_A_class.Info(); i.IsInstance = A_arbace_http_request_A_InstanceOf; i.Init = A_arbace_http_request_A_Init; i.Table = A_arbace_http_request_A_members; jrt.RegisterGoType(A_arbace_http_request_A_class, reflect.TypeFor[A_arbace_http_request_A]()) }

func A_arbace_http_request_fn__1534000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_fn__1534000075_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_request_fn__1534000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_fn__1534000075_A_New()}; return nil }

func A_arbace_http_request_fn__1534000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_fn__1534000075_A_fn_class)}; return nil }

var A_arbace_http_request_fn__1534000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_fn__1534000075_A_invoke, New: A_arbace_http_request_fn__1534000075_A_new, Get: A_arbace_http_request_fn__1534000075_A_get}

var A_arbace_http_request_fn__1534000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request$fn__1534000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_request_A_class, Simple: "fn__1534000075", Go: "arbace/aot_arbace_http.A_arbace_http_request_fn__1534000075_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_fn__1534000075_A_class.Info(); i.IsInstance = A_arbace_http_request_fn__1534000075_A_InstanceOf; i.Init = A_arbace_http_request_fn__1534000075_A_Init; i.Table = A_arbace_http_request_fn__1534000075_A_members; jrt.RegisterGoType(A_arbace_http_request_fn__1534000075_A_class, reflect.TypeFor[A_arbace_http_request_fn__1534000075_A]()) }

func A_arbace_http_request_head_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_http_request_head_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_A_New()}; return nil }

func A_arbace_http_request_head_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_A_fn_class)}; return nil }

var A_arbace_http_request_head_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_A_invoke, New: A_arbace_http_request_head_A_new, Get: A_arbace_http_request_head_A_get}

var A_arbace_http_request_head_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_http_A_class, Simple: "request_head", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_A_class.Info(); i.IsInstance = A_arbace_http_request_head_A_InstanceOf; i.Init = A_arbace_http_request_head_A_Init; i.Table = A_arbace_http_request_head_A_members; jrt.RegisterGoType(A_arbace_http_request_head_A_class, reflect.TypeFor[A_arbace_http_request_head_A]()) }

func A_arbace_http_request_head_fn__1534000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_fn__1534000022_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_request_head_fn__1534000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_fn__1534000022_A_New()}; return nil }

func A_arbace_http_request_head_fn__1534000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_fn__1534000022_A_fn_class)}; return nil }

var A_arbace_http_request_head_fn__1534000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_fn__1534000022_A_invoke, New: A_arbace_http_request_head_fn__1534000022_A_new, Get: A_arbace_http_request_head_fn__1534000022_A_get}

var A_arbace_http_request_head_fn__1534000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head$fn__1534000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_request_head_A_class, Simple: "fn__1534000022", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_fn__1534000022_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_fn__1534000022_A_class.Info(); i.IsInstance = A_arbace_http_request_head_fn__1534000022_A_InstanceOf; i.Init = A_arbace_http_request_head_fn__1534000022_A_Init; i.Table = A_arbace_http_request_head_fn__1534000022_A_members; jrt.RegisterGoType(A_arbace_http_request_head_fn__1534000022_A_class, reflect.TypeFor[A_arbace_http_request_head_fn__1534000022_A]()) }

func A_arbace_http_request_head_iter__1534000027__1534000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_iter__1534000027__1534000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_request_head_iter__1534000027__1534000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_iter__1534000027__1534000031_A_New_O(args[0])}; return nil }

func A_arbace_http_request_head_iter__1534000027__1534000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class)}; return nil }

var A_arbace_http_request_head_iter__1534000027__1534000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_iter__1534000027__1534000031_A_invoke, New: A_arbace_http_request_head_iter__1534000027__1534000031_A_new, Get: A_arbace_http_request_head_iter__1534000027__1534000031_A_get}

var A_arbace_http_request_head_iter__1534000027__1534000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head$iter__1534000027__1534000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_request_head_A_class, Simple: "iter__1534000027__1534000031", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000027__1534000031_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_iter__1534000027__1534000031_A_class.Info(); i.IsInstance = A_arbace_http_request_head_iter__1534000027__1534000031_A_InstanceOf; i.Init = A_arbace_http_request_head_iter__1534000027__1534000031_A_Init; i.Table = A_arbace_http_request_head_iter__1534000027__1534000031_A_members; jrt.RegisterGoType(A_arbace_http_request_head_iter__1534000027__1534000031_A_class, reflect.TypeFor[A_arbace_http_request_head_iter__1534000027__1534000031_A]()) }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class)}; return nil }

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_invoke, New: A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_new, Get: A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_get}

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_http_request_head_iter__1534000027__1534000031_A_class, Simple: "fn__1534000032", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class.Info(); i.IsInstance = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_InstanceOf; i.Init = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_Init; i.Table = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_members; jrt.RegisterGoType(A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class, reflect.TypeFor[A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A]()) }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class)}; return nil }

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_invoke, New: A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_new, Get: A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_get}

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032$fn__1534000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class, Simple: "fn__1534000033", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_class.Info(); i.IsInstance = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_InstanceOf; i.Init = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_Init; i.Table = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_members; jrt.RegisterGoType(A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_class, reflect.TypeFor[A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A]()) }

func A_arbace_http_request_head_iter__1534000043__1534000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_iter__1534000043__1534000047_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_http_request_head_iter__1534000043__1534000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_iter__1534000043__1534000047_A_New()}; return nil }

func A_arbace_http_request_head_iter__1534000043__1534000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class)}; return nil }

var A_arbace_http_request_head_iter__1534000043__1534000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_iter__1534000043__1534000047_A_invoke, New: A_arbace_http_request_head_iter__1534000043__1534000047_A_new, Get: A_arbace_http_request_head_iter__1534000043__1534000047_A_get}

var A_arbace_http_request_head_iter__1534000043__1534000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head$iter__1534000043__1534000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_http_request_head_A_class, Simple: "iter__1534000043__1534000047", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000043__1534000047_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_iter__1534000043__1534000047_A_class.Info(); i.IsInstance = A_arbace_http_request_head_iter__1534000043__1534000047_A_InstanceOf; i.Init = A_arbace_http_request_head_iter__1534000043__1534000047_A_Init; i.Table = A_arbace_http_request_head_iter__1534000043__1534000047_A_members; jrt.RegisterGoType(A_arbace_http_request_head_iter__1534000043__1534000047_A_class, reflect.TypeFor[A_arbace_http_request_head_iter__1534000043__1534000047_A]()) }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class)}; return nil }

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_invoke, New: A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_new, Get: A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_get}

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_http_request_head_iter__1534000043__1534000047_A_class, Simple: "fn__1534000048", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class.Info(); i.IsInstance = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_InstanceOf; i.Init = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_Init; i.Table = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_members; jrt.RegisterGoType(A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class, reflect.TypeFor[A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A]()) }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class)}; return nil }

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_invoke, New: A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_new, Get: A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_get}

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048$fn__1534000049", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class, Simple: "fn__1534000049", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A", Source: "http.ae"})

func init() { i := A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_class.Info(); i.IsInstance = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_InstanceOf; i.Init = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_Init; i.Table = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_members; jrt.RegisterGoType(A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_class, reflect.TypeFor[A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A]()) }

func A_arbace_http__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_http__init_A_Load__O(); case 1: return A_arbace_http__init_A_Unit0__O(); case 2: return A_arbace_http__init_A_Unit1__O(); case 3: return A_arbace_http__init_A_Unit10__O(); case 4: return A_arbace_http__init_A_Unit11__O(); case 5: return A_arbace_http__init_A_Unit12__O(); case 6: return A_arbace_http__init_A_Unit13__O(); case 7: return A_arbace_http__init_A_Unit2__O(); case 8: return A_arbace_http__init_A_Unit3__O(); case 9: return A_arbace_http__init_A_Unit4__O(); case 10: return A_arbace_http__init_A_Unit5__O(); case 11: return A_arbace_http__init_A_Unit6__O(); case 12: return A_arbace_http__init_A_Unit7__O(); case 13: return A_arbace_http__init_A_Unit8__O(); case 14: return A_arbace_http__init_A_Unit9__O()}; return nil }

func A_arbace_http__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http__init_A_New()}; return nil }

var A_arbace_http__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_http__init_A_invoke, New: A_arbace_http__init_A_new}

var A_arbace_http__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_http.A_arbace_http__init_A", Source: "http.ae"})

func init() { i := A_arbace_http__init_A_class.Info(); i.IsInstance = A_arbace_http__init_A_InstanceOf; i.Init = A_arbace_http__init_A_Init; i.Table = A_arbace_http__init_A_members; jrt.RegisterGoType(A_arbace_http__init_A_class, reflect.TypeFor[A_arbace_http__init_A]()) }
