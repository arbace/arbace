//line j2g_classes.ae:1
package aot_arbace_http

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_http_default_port_A_class, Name: "arbace.http$default_port", Modifiers: 25, Simple: "default_port", Go: "arbace/aot_arbace_http.A_arbace_http_default_port_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_class, Name: "arbace.http$eval1534000004$loading__1927001464__auto____1534000005", Modifiers: 25, Simple: "loading__1927001464__auto____1534000005", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A", Source: "http.ae", Declaring: &A_arbace_http_eval1534000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_http_eval1534000008_fn__1534000009_A_class, Name: "arbace.http$eval1534000008$fn__1534000009", Modifiers: 25, Simple: "fn__1534000009", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000008_fn__1534000009_A", Source: "http.ae", Declaring: &A_arbace_http_eval1534000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_http_latin1_A_class, Name: "arbace.http$latin1", Modifiers: 25, Simple: "latin1", Go: "arbace/aot_arbace_http.A_arbace_http_latin1_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_open_A_class, Name: "arbace.http$open", Modifiers: 25, Simple: "open", Go: "arbace/aot_arbace_http.A_arbace_http_open_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_http_read_all_A_class, Name: "arbace.http$read_all", Modifiers: 25, Simple: "read_all", Go: "arbace/aot_arbace_http.A_arbace_http_read_all_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_http_read_chunked_A_class, Name: "arbace.http$read_chunked", Modifiers: 25, Simple: "read_chunked", Go: "arbace/aot_arbace_http.A_arbace_http_read_chunked_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_http_read_headers_A_class, Name: "arbace.http$read_headers", Modifiers: 25, Simple: "read_headers", Go: "arbace/aot_arbace_http.A_arbace_http_read_headers_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_read_line_STAR__A_class, Name: "arbace.http$read_line_STAR_", Modifiers: 25, Simple: "read_line_STAR_", Go: "arbace/aot_arbace_http.A_arbace_http_read_line_STAR__A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_read_n_A_class, Name: "arbace.http$read_n", Modifiers: 25, Simple: "read_n", Go: "arbace/aot_arbace_http.A_arbace_http_read_n_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_A_class, Name: "arbace.http$request", Modifiers: 25, Simple: "request", Go: "arbace/aot_arbace_http.A_arbace_http_request_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_fn__1534000075_A_class, Name: "arbace.http$request$fn__1534000075", Modifiers: 25, Simple: "fn__1534000075", Go: "arbace/aot_arbace_http.A_arbace_http_request_fn__1534000075_A", Source: "http.ae", Declaring: &A_arbace_http_request_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_A_class, Name: "arbace.http$request_head", Modifiers: 25, Simple: "request_head", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_A", Source: "http.ae", Declaring: &A_arbace_http_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_fn__1534000022_A_class, Name: "arbace.http$request_head$fn__1534000022", Modifiers: 25, Simple: "fn__1534000022", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_fn__1534000022_A", Source: "http.ae", Declaring: &A_arbace_http_request_head_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_iter__1534000027__1534000031_A_class, Name: "arbace.http$request_head$iter__1534000027__1534000031", Modifiers: 25, Simple: "iter__1534000027__1534000031", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000027__1534000031_A", Source: "http.ae", Declaring: &A_arbace_http_request_head_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class, Name: "arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032", Modifiers: 25, Simple: "fn__1534000032", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A", Source: "http.ae", Declaring: &A_arbace_http_request_head_iter__1534000027__1534000031_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_class, Name: "arbace.http$request_head$iter__1534000027__1534000031$fn__1534000032$fn__1534000033", Modifiers: 25, Simple: "fn__1534000033", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A", Source: "http.ae", Declaring: &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_iter__1534000043__1534000047_A_class, Name: "arbace.http$request_head$iter__1534000043__1534000047", Modifiers: 25, Simple: "iter__1534000043__1534000047", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000043__1534000047_A", Source: "http.ae", Declaring: &A_arbace_http_request_head_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class, Name: "arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048", Modifiers: 25, Simple: "fn__1534000048", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A", Source: "http.ae", Declaring: &A_arbace_http_request_head_iter__1534000043__1534000047_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_class, Name: "arbace.http$request_head$iter__1534000043__1534000047$fn__1534000048$fn__1534000049", Modifiers: 25, Simple: "fn__1534000049", Go: "arbace/aot_arbace_http.A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A", Source: "http.ae", Declaring: &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_http_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_A_New()}; return nil }

var A_arbace_http_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_http_A_new}

var A_arbace_http_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_http.A_arbace_http_A"})

func init() { i := A_arbace_http_A_class.Info(); i.IsInstance = A_arbace_http_A_InstanceOf; i.Init = A_arbace_http_A_Init; i.Table = A_arbace_http_A_members }

var A_arbace_http_default_port_A_class *jrt.Class

func A_arbace_http_eval1534000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_eval1534000004_A_New()}; return nil }

var A_arbace_http_eval1534000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_http_eval1534000004_A_new}

var A_arbace_http_eval1534000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$eval1534000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_http_A_class, Simple: "eval1534000004", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000004_A"})

func init() { i := A_arbace_http_eval1534000004_A_class.Info(); i.IsInstance = A_arbace_http_eval1534000004_A_InstanceOf; i.Table = A_arbace_http_eval1534000004_A_members }

var A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_class *jrt.Class

func A_arbace_http_eval1534000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http_eval1534000008_A_New()}; return nil }

var A_arbace_http_eval1534000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_http_eval1534000008_A_new}

var A_arbace_http_eval1534000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http$eval1534000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_http_A_class, Simple: "eval1534000008", Go: "arbace/aot_arbace_http.A_arbace_http_eval1534000008_A"})

func init() { i := A_arbace_http_eval1534000008_A_class.Info(); i.IsInstance = A_arbace_http_eval1534000008_A_InstanceOf; i.Table = A_arbace_http_eval1534000008_A_members }

var A_arbace_http_eval1534000008_fn__1534000009_A_class *jrt.Class

var A_arbace_http_latin1_A_class *jrt.Class

var A_arbace_http_open_A_class *jrt.Class

var A_arbace_http_read_all_A_class *jrt.Class

var A_arbace_http_read_chunked_A_class *jrt.Class

var A_arbace_http_read_headers_A_class *jrt.Class

var A_arbace_http_read_line_STAR__A_class *jrt.Class

var A_arbace_http_read_n_A_class *jrt.Class

var A_arbace_http_request_A_class *jrt.Class

var A_arbace_http_request_fn__1534000075_A_class *jrt.Class

var A_arbace_http_request_head_A_class *jrt.Class

var A_arbace_http_request_head_fn__1534000022_A_class *jrt.Class

var A_arbace_http_request_head_iter__1534000027__1534000031_A_class *jrt.Class

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class *jrt.Class

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_class *jrt.Class

var A_arbace_http_request_head_iter__1534000043__1534000047_A_class *jrt.Class

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class *jrt.Class

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_class *jrt.Class

func A_arbace_http__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_http__init_A_Load__O()}; return nil }

func A_arbace_http__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_http__init_A_New()}; return nil }

var A_arbace_http__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_http__init_A_invoke, New: A_arbace_http__init_A_new}

var A_arbace_http__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.http__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_http.A_arbace_http__init_A", Source: "http.ae"})

func init() { i := A_arbace_http__init_A_class.Info(); i.IsInstance = A_arbace_http__init_A_InstanceOf; i.Init = A_arbace_http__init_A_Init; i.Table = A_arbace_http__init_A_members }
