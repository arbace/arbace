//line aot_arbace_http.ae:1
package aot_arbace_http

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_New() *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A { A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_Init(); t := &A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp26 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_http_A_Init(); tmp6 = A_arbace_http_A_const_2; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_http_A_Init(); tmp8 = A_arbace_http_A_const_3; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_http_A_Init(); tmp10 = A_arbace_http_A_const_4; tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10); var tmp11 *lang.Var; A_arbace_http_A_Init(); tmp11 = A_arbace_http_A_const_1; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_http_A_Init(); tmp13 = A_arbace_http_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_http_A_Init(); tmp15 = A_arbace_http_A_const_6; tmp12.Invoke_O_O__O(tmp14, tmp15); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_92)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_93)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_94)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_95)); var tmp20 *lang.Var; lang.RT_Init(); tmp20 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp20).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_96)); var tmp21 *lang.Var; lang.RT_Init(); tmp21 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp21).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_97)); var tmp22 *lang.Var; lang.RT_Init(); tmp22 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp22).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_98)); var tmp23 *lang.Var; lang.RT_Init(); tmp23 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp23).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_99)); var tmp24 *lang.Var; lang.RT_Init(); tmp24 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp24).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_100)); var tmp25 *lang.Var; lang.RT_Init(); tmp25 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp25).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_101)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp26 != nil { panic(tmp26) }; return tmp3 }
//line :3:1
func A_arbace_http_eval1534000008_fn__1534000009_A_New() *A_arbace_http_eval1534000008_fn__1534000009_A { A_arbace_http_eval1534000008_fn__1534000009_A_Init(); t := &A_arbace_http_eval1534000008_fn__1534000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_http_A_Init(); tmp5 = A_arbace_http_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_http_A_Init(); tmp7 = A_arbace_http_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_http_A_Init(); tmp9 = A_arbace_http_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }


































func A_arbace_http_latin1_A_New() *A_arbace_http_latin1_A { A_arbace_http_latin1_A_Init(); t := &A_arbace_http_latin1_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_http_latin1_A) Ctor() {}
//line :38:1
func (t *A_arbace_http_latin1_A) Invoke_O_O__O(self, s__0 any) any { return jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_ISO_8859_1).Ref() }

func A_arbace_http_read_line_STAR__A_New() *A_arbace_http_read_line_STAR__A { A_arbace_http_read_line_STAR__A_Init(); t := &A_arbace_http_read_line_STAR__A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_http_read_line_STAR__A) Ctor() {}
//line :40:1
func (t *A_arbace_http_read_line_STAR__A) Invoke_O_O__O(self, in__0 any) any { { var b__2 any = jrt.ByteArrayOutputStream_New(); L1: for { var c__3 int32 = jrt.InputStream_Cast(in__0).Read__I()





	if lang.Numbers_Equiv_J_J__Z(int64(c__3), -1) {
		if lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).Size__I())) { return jrt.String_New_B1_Charset(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).ToByteArray__B1(), jrt.StandardCharsets_ISO_8859_1) } else { return nil } } else {
//line :46:1
			if lang.Numbers_Equiv_J_J__Z(int64(c__3), 10) { var s__4 any = jrt.String_New_B1_Charset(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).ToByteArray__B1(), jrt.StandardCharsets_ISO_8859_1); var tmp1 *lang.Var


				A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_12; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(s__4, Lit_116)) { var tmp2 *lang.Var; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_13; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_15; var tmp5 any = tmp4; return tmp3.Invoke_O_O_O__O(s__4, tmp5, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(s__4)))).Ref()) } else { return s__4 } } else {
//line :46:1
					var tmp6 *lang.Keyword; A_arbace_http_A_Init(); tmp6 = A_arbace_http_A_const_14; if tmp6 != nil {



						jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).Write_I__V(c__3); continue L1 } else {
//line :46:1
							return nil } } } } }; /*line :40:1*/panic("a2g: unreachable") }











func A_arbace_http_read_n_A_New() *A_arbace_http_read_n_A { A_arbace_http_read_n_A_Init(); t := &A_arbace_http_read_n_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_http_read_n_A) Ctor() {}
//line :52:1
func (t *A_arbace_http_read_n_A) Invoke_O_O_O_O__O(self, in__0, out__1, p_n__2 any) any { { var n__2 int64 = lang.RT_LongCast_O__J(p_n__2); var buf__4 any; var tmp1 any


	A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_16; buf__4 = lang.Numbers_Byte_array_O__B1(tmp1).Ref()
//line :52:1
	var left__5 int64 = n__2; L1: for {




		if lang.Numbers_IsPos_J__Z(left__5) { var k__6 int32 = jrt.InputStream_Cast(in__0).Read_B1_I_I__I(jrt.A2g_CastArray[*jrt.ByteArray](buf__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(lang.Numbers_Min_J_J__J(left__5, 65536)))

			if lang.Numbers_IsNeg_J__Z(int64(k__6)) { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_118, nil, Lit_119), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(left__5).Ref(), nil)))))
			}
			jrt.OutputStream_Cast(out__1).Write_B1_I_I__V(jrt.A2g_CastArray[*jrt.ByteArray](buf__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), k__6)
			left__5 = lang.Numbers_Minus_J_J__J(left__5, int64(k__6)); continue L1 } else {
//line :57:1
				return nil } } }; /*line :52:1*/panic("a2g: unreachable") }











func A_arbace_http_read_all_A_New() *A_arbace_http_read_all_A { A_arbace_http_read_all_A_Init(); t := &A_arbace_http_read_all_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_http_read_all_A) Ctor() {}
//line :64:1
func (t *A_arbace_http_read_all_A) Invoke_O_O_O__O(self, in__0, out__1 any) any { { var buf__3 any; var tmp1 any
										A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_17; buf__3 = lang.Numbers_Byte_array_O__B1(tmp1).Ref()
//line :64:1
L1: for { var k__4 int32 = jrt.InputStream_Cast(in__0).Read_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](buf__3, jrt.Prim_byte.ArrayClass()))



	if lang.Numbers_IsNeg_J__Z(int64(k__4)) { return nil } else {
		jrt.OutputStream_Cast(out__1).Write_B1_I_I__V(jrt.A2g_CastArray[*jrt.ByteArray](buf__3, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), k__4)
		continue L1 } } }; /*line :64:1*/panic("a2g: unreachable") }







func A_arbace_http_read_headers_A_New() *A_arbace_http_read_headers_A { A_arbace_http_read_headers_A_Init(); t := &A_arbace_http_read_headers_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_http_read_headers_A) Ctor() {}
//line :72:1
func (t *A_arbace_http_read_headers_A) Invoke_O_O__O(self, in__0 any) any { { var h__2 any; lang.PersistentArrayMap_Init(); h__2 = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var line__3 any; var tmp1 *lang.Var



	A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_18; line__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(in__0)
	if lang.Util_Identical_O_O__Z(line__3, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_111))) } else { if lang.Util_Equiv_O_O__Z(line__3, Lit_112) { return h__2 } else { var tmp2 *lang.Keyword; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_14; if tmp2 != nil { var i__4 any; var tmp3 *lang.Var


		A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_19; i__4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(line__3, Lit_113)
		if lang.Util_Identical_O_O__Z(i__4, nil) {
			h__2 = h__2; continue L1 } else {
//line :81:1
				var k__5 any; var tmp4 *lang.Var

				A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_20; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_http_A_Init(); tmp6 = A_arbace_http_A_const_21; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_http_A_Init(); tmp8 = A_arbace_http_A_const_13; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_http_A_Init(); tmp10 = A_arbace_http_A_const_15; k__5 = tmp5.Invoke_O__O(tmp7.Invoke_O__O(tmp9.Invoke_O_O_O__O(line__3, tmp10, i__4)))
//line :81:1
				var v__6 any; var tmp11 *lang.Var


				A_arbace_http_A_Init(); tmp11 = A_arbace_http_A_const_21; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_http_A_Init(); tmp13 = A_arbace_http_A_const_13; v__6 = tmp12.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(line__3, lang.Numbers_Inc_O__Number(i__4)))
				var tmp14 *lang.Var; A_arbace_http_A_Init(); tmp14 = A_arbace_http_A_const_22; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any; var temp__1927000408__auto____7 any = lang.IFn_Cast(h__2).Invoke_O__O(k__5); if jrt.A2g_Truth(temp__1927000408__auto____7) { var old__8 any = temp__1927000408__auto____7; tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, old__8, nil, v__6)).Ref() } else { tmp16 = v__6 }; h__2 = tmp15.Invoke_O_O_O__O(h__2, k__5, tmp16); continue L1 } } else {
//line :77:1
					return nil } } } } }; /*line :72:1*/panic("a2g: unreachable") }














func A_arbace_http_read_chunked_A_New() *A_arbace_http_read_chunked_A { A_arbace_http_read_chunked_A_Init(); t := &A_arbace_http_read_chunked_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_http_read_chunked_A) Ctor() {}
//line :87:1
func (t *A_arbace_http_read_chunked_A) Invoke_O_O_O__O(self, in__0, out__1 any) any { L1: for { var line__3 any; var tmp1 *lang.Var

	A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_18; line__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(in__0)
//line :87:1
	var ___4 any; _ = ___4


	if lang.Util_Identical_O_O__Z(line__3, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_109))) } else { ___4 = nil }
//line :87:1
	var size__5 int64; var tmp2 *lang.Var



	A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_21; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_24; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_http_A_Init(); tmp6 = A_arbace_http_A_const_25; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_http_A_Init(); tmp8 = A_arbace_http_A_const_26; size__5 = jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp3.Invoke_O__O(tmp5.Invoke_O__O(tmp7.Invoke_O_O__O(line__3, tmp8)))), lang.RT_IntCast_J__I(16))
	if lang.Numbers_IsZero_J__Z(size__5) {
		var tmp9 *lang.Var; A_arbace_http_A_Init(); tmp9 = A_arbace_http_A_const_23; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(in__0) } else {
			var tmp10 *lang.Var; A_arbace_http_A_Init(); tmp10 = A_arbace_http_A_const_27; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O_O__O(in__0, out__1, jrt.Long_ValueOf_J__Long(size__5).Ref())
			var tmp11 *lang.Var; A_arbace_http_A_Init(); tmp11 = A_arbace_http_A_const_18; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(in__0)
			continue L1 } }; /*line :87:1*/panic("a2g: unreachable") }










func A_arbace_http_default_port_A_New() *A_arbace_http_default_port_A { A_arbace_http_default_port_A_Init(); t := &A_arbace_http_default_port_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_http_default_port_A) Ctor() {}
//line :98:1
func (t *A_arbace_http_default_port_A) Invoke_O_O__O(self, scheme__0 any) any { if lang.Util_Equiv_O_O__Z(scheme__0, Lit_90) { A_arbace_http_A_Init(); return A_arbace_http_A_const_28 } else { A_arbace_http_A_Init(); return A_arbace_http_A_const_29 } }

func A_arbace_http_open_A_New() *A_arbace_http_open_A { A_arbace_http_open_A_Init(); t := &A_arbace_http_open_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_http_open_A) Ctor() {}
//line :100:1
func (t *A_arbace_http_open_A) Invoke_O_O_O_O__O(self, uri__0, timeout__1, tls_opts__2 any) any { var scheme__4 any; var tmp1 *lang.Var;


	A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_20; scheme__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.URI_Cast(uri__0)).GetScheme__String().Ref()); var host__5 any = /*line :100:1*/jrt.NN(jrt.URI_Cast(uri__0)).GetHost__String().Ref(); var port__6 any; var p__6 int32 = jrt.NN(jrt.URI_Cast(uri__0)).GetPort__I(); if




	lang.Numbers_IsNeg_J__Z(int64(p__6)) { var tmp2 *lang.Var; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_30; port__6 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(scheme__4) } else { port__6 = jrt.Integer_ValueOf_I__Integer(p__6).Ref() }; var G__1534000019__7_ any = scheme__4; switch
	lang.Util_Hash_O__I(G__1534000019__7_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z(G__1534000019__7_, Lit_105) { var s__8 any = jrt.Socket_New(); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		jrt.Socket_Cast(s__8).Connect_SocketAddress_I__V(jrt.InetSocketAddress_New_String_I(jrt.String_Cast(host__5), lang.RT_IntCast_O__I(port__6)), lang.RT_IntCast_O__I(timeout__1))
//line :106:1
		tmp3 = s__8; return nil }(); if tmp4 != nil { if true { var t__11 jrt.Throwable_I = tmp4





			jrt.Socket_Cast(s__8).Close__V()
//line :106:1
			panic(jrt.Thrown(t__11)) } }; return tmp3 }; case 1: if lang.Util_Equiv_O_O__Z(G__1534000019__7_, Lit_90) {
				var tmp5 *lang.Var; A_arbace_http_A_Init(); tmp5 = A_arbace_http_A_const_31; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_http_A_Init(); tmp7 = A_arbace_http_A_const_32; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_http_A_Init(); tmp9 = A_arbace_http_A_const_33; var tmp10 any = tmp9.Ref(); var tmp11 any; A_arbace_http_A_Init(); tmp11 = A_arbace_http_A_const_34; var tmp12 any = tmp11; var tmp13 *lang.Keyword; A_arbace_http_A_Init(); tmp13 = A_arbace_http_A_const_35; return tmp6.Invoke_O_O_O__O(host__5, port__6, tmp8.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13.Ref(), timeout__1)), tls_opts__2)) }
//line :106:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_106, nil), jrt.RefArrayOf(jrt.Object_class, nil, uri__0))))) }








func A_arbace_http_request_head_A_New() *A_arbace_http_request_head_A { A_arbace_http_request_head_A_Init(); t := &A_arbace_http_request_head_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_http_request_head_A) Ctor() {}
//line :115:1
func (t *A_arbace_http_request_head_A) Invoke_O_O_O_O__O(self, method__0, uri__1, headers__2 any) any { var scheme__4 any; var tmp1 *lang.Var;


	A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_20; scheme__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.URI_Cast(uri__1)).GetScheme__String().Ref()); var p__5 int32 = /*line :115:1*/jrt.NN(jrt.URI_Cast(uri__1)).GetPort__I(); var host__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var h__8 any = jrt.NN(jrt.URI_Cast(uri__1)).GetHost__String().Ref(); var tmp4 *lang.Var;




	A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(h__8, Lit_113)) { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_131, nil, Lit_132), jrt.RefArrayOf(jrt.Object_class, nil, h__8, nil)).Ref() } else { tmp3 = h__8 }; var tmp5 any = tmp3; var tmp6 *jrt.String; var tmp7 bool; var or__1927000174__auto____8 bool = lang.Numbers_IsNeg_J__Z(int64(p__5)); if or__1927000174__auto____8 {
		tmp7 = or__1927000174__auto____8 } else { var tmp8 int64 = int64(p__5); var tmp9 *lang.Var; A_arbace_http_A_Init(); tmp9 = A_arbace_http_A_const_30; tmp7 = lang.Util_Equiv_J_O__Z(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(scheme__4)) }; if tmp7 { tmp6 = nil } else { tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer(p__5).Ref())) }; host__6 = /*line :120:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref())).Ref(); var target__7 any; var tmp10 /*line :115:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp11 any; var path__9 any = jrt.NN(jrt.URI_Cast(uri__1)).GetRawPath__String().Ref(); var tmp12 *lang.Var;






	A_arbace_http_A_Init(); tmp12 = A_arbace_http_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(path__9)) { tmp11 = Lit_133 } else { tmp11 = path__9 }; var tmp13 any = tmp11; var tmp14 *jrt.String; var temp__1927000414__auto____9 any = jrt.NN(jrt.URI_Cast(uri__1)).GetRawQuery__String().Ref(); if
	jrt.A2g_Truth(temp__1927000414__auto____9) { var q__10 any = temp__1927000414__auto____9; tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_134, nil), jrt.RefArrayOf(jrt.Object_class, nil, q__10)) } else { tmp14 = nil }; target__7 = /*line :122:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14.Ref())).Ref(); var given__8 any; var tmp15 /*line :115:1*/*lang.Var;








	A_arbace_http_A_Init(); tmp15 = A_arbace_http_A_const_38; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp17 = lang.PersistentArrayMap_EMPTY; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_http_A_Init(); tmp19 = A_arbace_http_A_const_41; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = A_arbace_http_request_head_fn__1534000022_A_New(); var tmp22 *jrt.Class; A_arbace_http_request_head_fn__1534000022_A_Init(); tmp22 = A_arbace_http_request_head_fn__1534000022_A_fn_class; given__8 = tmp16.Invoke_O_O_O__O(tmp18, tmp20.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil)), headers__2); var defaults__9 any; var tmp23 any = /*line :115:1*/lang.Tuple_Create_O_O_O__IPersistentVector(Lit_135, Lit_136, host__6); var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_139, nil); var tmp25 *lang.Var; A_arbace_http_A_Init(); tmp25 = A_arbace_http_A_const_45; var tmp26 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_137, Lit_138, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke__O())).Ref()); var tmp27 any; A_arbace_http_A_Init(); tmp27 = A_arbace_http_A_const_44; defaults__9 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp23, tmp26, tmp27); var tmp28 /*line :128:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140, nil, Lit_141, nil, nil, Lit_142); var tmp29 *lang.Var; A_arbace_http_A_Init(); tmp29 = A_arbace_http_A_const_39; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_http_A_Init(); tmp31 = A_arbace_http_A_const_42; var tmp32 any = tmp30.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(method__0)); var tmp33 *lang.Var; A_arbace_http_A_Init(); tmp33 = A_arbace_http_A_const_40; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; var iter__1927001039__auto____17 any; var tmp36 any = A_arbace_http_request_head_iter__1534000027__1534000031_A_New_O(given__8); var tmp37 *jrt.Class;
	A_arbace_http_request_head_iter__1534000027__1534000031_A_Init(); tmp37 = A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); tmp35 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(defaults__9); var tmp38 any = /*line :128:1*/tmp34.Invoke_O__O(tmp35); var tmp39 *lang.Var; A_arbace_http_A_Init(); tmp39 = A_arbace_http_A_const_40; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; var iter__1927001039__auto____17_2 any; var tmp42 any = A_arbace_http_request_head_iter__1534000043__1534000047_A_New(); var tmp43 *jrt.Class;

	A_arbace_http_request_head_iter__1534000043__1534000047_A_Init(); tmp43 = A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class; iter__1927001039__auto____17_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil); var tmp44 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____17_2); var tmp45 *lang.Var; A_arbace_http_A_Init(); tmp45 = A_arbace_http_A_const_57; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_http_A_Init(); tmp47 = A_arbace_http_A_const_58; tmp41 = tmp44.Invoke_O__O(tmp46.Invoke_O_O__O(jrt.NN(tmp47).GetRawRoot__O(), given__8)); return /*line :128:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp28, jrt.RefArrayOf(jrt.Object_class, tmp32, nil, target__7, nil, tmp38, tmp40.Invoke_O__O(tmp41), nil)).Ref() }
//line :124:1
func A_arbace_http_request_head_fn__1534000022_A_New() *A_arbace_http_request_head_fn__1534000022_A { A_arbace_http_request_head_fn__1534000022_A_Init(); t := &A_arbace_http_request_head_fn__1534000022_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_http_request_head_fn__1534000022_A) Ctor() {}
//line :124:1
func (t *A_arbace_http_request_head_fn__1534000022_A) Invoke_O_O__O(self, p__1534000021__1 any) any { var vec__1534000023__2 any = p__1534000021__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1534000023__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1534000023__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_42; var tmp4 any = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(k__3)); var tmp5 *lang.Var; A_arbace_http_A_Init(); tmp5 = A_arbace_http_A_const_42; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(k__3); var tmp7 *lang.Var; A_arbace_http_A_Init(); tmp7 = A_arbace_http_A_const_43; return lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(v__4))) }




func A_arbace_http_request_head_iter__1534000027__1534000031_A_New_O(p0 any) *A_arbace_http_request_head_iter__1534000027__1534000031_A { A_arbace_http_request_head_iter__1534000027__1534000031_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Ctor_O(c__given any) { t.F_given = c__given }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Invoke_O_O__O(self, s__1534000028__1 any) any { var tmp1 any = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_New_O_O_O(self, t.F_given, s__1534000028__1); var tmp2 *jrt.Class; A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_Init(); tmp2 = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :129:1
func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A { A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Ctor_O_O_O(c__iter__1534000027, c__given, c__s__1534000028 any) { t.F_iter__1534000027 = c__iter__1534000027; t.F_given = c__given; t.F_s__1534000028 = c__s__1534000028 }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Invoke_O__O(self any) any { { var s__1534000028__1 any; var t_ any = t.F_s__1534000028; t.F_s__1534000028 = nil; s__1534000028__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_46; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1534000028__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1534000028__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1534000028__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1534000028__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1534000030__6 any; var tmp4 *lang.Var; A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_49; b__1534000030__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_New_O_I_O_O(t.F_given, size__1927001038__auto____5, b__1534000030__6, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_Init(); tmp6 = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_http_A_Init(); tmp7 = A_arbace_http_A_const_52; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_http_A_Init(); tmp9 = A_arbace_http_A_const_54; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1534000030__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1534000027); var tmp12 *lang.Var; A_arbace_http_A_Init(); tmp12 = A_arbace_http_A_const_55; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1534000028__3))) } else { var tmp13 *lang.Var; A_arbace_http_A_Init(); tmp13 = A_arbace_http_A_const_52; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_http_A_Init(); tmp15 = A_arbace_http_A_const_54; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1534000030__6), nil) } } else { var vec__1534000038__4 any; var tmp16 *lang.Var; A_arbace_http_A_Init(); tmp16 = A_arbace_http_A_const_24; vec__1534000038__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1534000028__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1534000038__4, lang.RT_IntCast_J__I(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O(vec__1534000038__4, lang.RT_IntCast_J__I(1), nil); var v__7 any = lang.RT_Nth_O_I_O__O(vec__1534000038__4, lang.RT_IntCast_J__I(2), nil); var tmp17 *lang.Var; A_arbace_http_A_Init(); tmp17 = A_arbace_http_A_const_50; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_given).Invoke_O__O(k__5))) { var tmp18 *lang.Var; A_arbace_http_A_Init(); tmp18 = A_arbace_http_A_const_53; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_146, nil, Lit_142), jrt.RefArrayOf(jrt.Object_class, n__6, nil, v__7, nil)).Ref(); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1534000027); var tmp22 *lang.Var; A_arbace_http_A_Init(); tmp22 = A_arbace_http_A_const_56; return tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1534000028__3))) } else { var tmp23 *lang.Var; A_arbace_http_A_Init(); tmp23 = A_arbace_http_A_const_56; s__1534000028__1 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1534000028__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :129:1
func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A { A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Ctor_O_I_O_O(c__given any, c__size__1927001038__auto__ int32, c__b__1534000030, c__c__1927001037__auto__ any) { t.F_given = c__given; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1534000030 = c__b__1534000030; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Invoke_O__O(self any) any { { var i__1534000029__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1534000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1534000034__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1534000029__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1534000034__2, lang.RT_IntCast_J__I(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O(vec__1534000034__2, lang.RT_IntCast_J__I(1), nil); var v__5 any = lang.RT_Nth_O_I_O__O(vec__1534000034__2, lang.RT_IntCast_J__I(2), nil); var tmp2 *lang.Var; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_50; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_given).Invoke_O__O(k__3))) { var tmp3 *lang.Var; A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_51; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_b__1534000030; tmp4.Invoke_O_O__O(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_146, nil, Lit_142), jrt.RefArrayOf(jrt.Object_class, n__4, nil, v__5, nil)).Ref()); i__1534000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1534000029__1); continue L1 } else { i__1534000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1534000029__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_http_request_head_iter__1534000043__1534000047_A_New() *A_arbace_http_request_head_iter__1534000043__1534000047_A { A_arbace_http_request_head_iter__1534000043__1534000047_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Ctor() {}
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Invoke_O_O__O(self, s__1534000044__1 any) any { var tmp1 any = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_New_O_O(s__1534000044__1, self); var tmp2 *jrt.Class; A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_Init(); tmp2 = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :130:1
func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_New_O_O(p0, p1 any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A { A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Ctor_O_O(c__s__1534000044, c__iter__1534000043 any) { t.F_s__1534000044 = c__s__1534000044; t.F_iter__1534000043 = c__iter__1534000043 }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Invoke_O__O(self any) any { { var s__1534000044__1 any; var t_ any = t.F_s__1534000044; t.F_s__1534000044 = nil; s__1534000044__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_46; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1534000044__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1534000044__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1534000044__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1534000044__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1534000046__6 any; var tmp4 *lang.Var; A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_49; b__1534000046__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_New_O_I_O(b__1534000046__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_Init(); tmp6 = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_http_A_Init(); tmp7 = A_arbace_http_A_const_52; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_http_A_Init(); tmp9 = A_arbace_http_A_const_54; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1534000046__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1534000043); var tmp12 *lang.Var; A_arbace_http_A_Init(); tmp12 = A_arbace_http_A_const_55; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1534000044__3))) } else { var tmp13 *lang.Var; A_arbace_http_A_Init(); tmp13 = A_arbace_http_A_const_52; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_http_A_Init(); tmp15 = A_arbace_http_A_const_54; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1534000046__6), nil) } } else { var vec__1534000057__4 any; var tmp16 *lang.Var; A_arbace_http_A_Init(); tmp16 = A_arbace_http_A_const_24; vec__1534000057__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1534000044__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1534000057__4, lang.RT_IntCast_J__I(0), nil); var vec__1534000060__6 any = lang.RT_Nth_O_I_O__O(vec__1534000057__4, lang.RT_IntCast_J__I(1), nil); var n__7 any = lang.RT_Nth_O_I_O__O(vec__1534000060__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__1534000060__6, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; _ = ___5; A_arbace_http_A_Init(); tmp17 = A_arbace_http_A_const_53; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_146, nil, Lit_142), jrt.RefArrayOf(jrt.Object_class, n__7, nil, v__8, nil)).Ref(); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__1534000043); var tmp21 *lang.Var; A_arbace_http_A_Init(); tmp21 = A_arbace_http_A_const_56; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__1534000044__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :130:1
func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A { A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Ctor_O_I_O(c__b__1534000046 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1534000046 = c__b__1534000046; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Invoke_O__O(self any) any { { var i__1534000045__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1534000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1534000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1534000045__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__1534000050__2, lang.RT_IntCast_J__I(0), nil); var vec__1534000053__4 any = lang.RT_Nth_O_I_O__O(vec__1534000050__2, lang.RT_IntCast_J__I(1), nil); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1534000053__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1534000053__4, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; _ = ___3; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_51; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1534000046; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_146, nil, Lit_142), jrt.RefArrayOf(jrt.Object_class, n__5, nil, v__6, nil)).Ref()); i__1534000045__1 = lang.Numbers_Unchecked_inc_J__J(i__1534000045__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_http_request_A_New() *A_arbace_http_request_A { A_arbace_http_request_A_Init(); t := &A_arbace_http_request_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_http_request_A) Ctor() {}
//line :133:1
func (t *A_arbace_http_request_A) Invoke_O_O__O(self, p__1534000067__0 any) any { var default__1534000070__2 any; A_arbace_http_A_Init(); default__1534000070__2 = A_arbace_http_A_const_59.Ref(); var default__1534000071__3 any; A_arbace_http_A_Init(); default__1534000071__3 = A_arbace_http_A_const_60.Ref(); var default__1534000072__4 int64 = 0; var map__1534000068__5 any = p__1534000067__0; var map__1534000068__6 any; if lang.ISeq_InstanceOf(map__1534000068__5) { var tmp1 *lang.Var; A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_61; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1534000068__5)) { var tmp2 *lang.Var; A_arbace_http_A_Init(); tmp2 = A_arbace_http_A_const_62; map__1534000068__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1534000068__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_46; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1534000068__5)) { var tmp4 *lang.Var; A_arbace_http_A_Init(); tmp4 = A_arbace_http_A_const_24; map__1534000068__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1534000068__5) } else { lang.PersistentArrayMap_Init(); map__1534000068__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1534000068__6 = map__1534000068__5 }; var url__7 any; var tmp5 *lang.Keyword; A_arbace_http_A_Init(); tmp5 = A_arbace_http_A_const_63; url__7 = lang.RT_Get_O_O__O(map__1534000068__6, tmp5.Ref()); var method__8 any; var tmp6 *lang.Keyword; A_arbace_http_A_Init(); tmp6 = A_arbace_http_A_const_64; method__8 = lang.RT_Get_O_O_O__O(map__1534000068__6, tmp6.Ref(), default__1534000070__2); var headers__9 any; var tmp7 *lang.Keyword; A_arbace_http_A_Init(); tmp7 = A_arbace_http_A_const_65; headers__9 = lang.RT_Get_O_O__O(map__1534000068__6, tmp7.Ref()); var body__10 any; var tmp8 *lang.Keyword; A_arbace_http_A_Init(); tmp8 = A_arbace_http_A_const_66; body__10 = lang.RT_Get_O_O__O(map__1534000068__6, tmp8.Ref()); var as__11 any; var tmp9 *lang.Keyword; A_arbace_http_A_Init(); tmp9 = A_arbace_http_A_const_67; as__11 = lang.RT_Get_O_O_O__O(map__1534000068__6, tmp9.Ref(), default__1534000071__3); var timeout__12 any; var tmp10 *lang.Keyword; A_arbace_http_A_Init(); tmp10 = A_arbace_http_A_const_35; var tmp11 any = tmp10.Ref(); timeout__12 = lang.RT_Get_O_O_O__O(map__1534000068__6, tmp11, jrt.Long_ValueOf_J__Long(default__1534000072__4).Ref()); var tls__13 any; var tmp12 *lang.Keyword; A_arbace_http_A_Init(); tmp12 = A_arbace_http_A_const_68; tls__13 = lang.RT_Get_O_O__O(map__1534000068__6, tmp12.Ref()); var uri__14 any = jrt.URI_New_String(jrt.String_Cast(url__7)); var body__15 any; if



	lang.Util_Identical_O_O__Z(body__10, nil) { body__15 = nil } else { var tmp13 *lang.Var; A_arbace_http_A_Init(); tmp13 = A_arbace_http_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(body__10)) {
		body__15 = jrt.NN(jrt.String_Cast(body__10)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else {
//line :137:1
			var tmp14 *lang.Var; A_arbace_http_A_Init(); tmp14 = A_arbace_http_A_const_70; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(body__10)) { body__15 = body__10 } else { var tmp15 *lang.Keyword; A_arbace_http_A_Init(); tmp15 = A_arbace_http_A_const_14; if tmp15 != nil { var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_121, nil); var tmp17 *lang.Var; A_arbace_http_A_Init(); tmp17 = A_arbace_http_A_const_71; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(body__10)))))) } else { body__15 = nil } } } }; var method_name__16 any; var tmp18 /*line :133:1*/*lang.Var;







	A_arbace_http_A_Init(); tmp18 = A_arbace_http_A_const_39; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_http_A_Init(); tmp20 = A_arbace_http_A_const_42; method_name__16 = tmp19.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(method__8)); var headers__17 any; var G__1534000074__17_ any; var or__1927000174__auto____17 any = headers__9; if
	jrt.A2g_Truth(or__1927000174__auto____17) { G__1534000074__17_ = or__1927000174__auto____17 } else { lang.PersistentArrayMap_Init(); G__1534000074__17_ = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp21 any; var and__1927000168__auto____18 any; var or__1927000174__auto____18 any = body__15; if
	jrt.A2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18 = or__1927000174__auto____18 } else { var tmp22 any; A_arbace_http_A_Init(); tmp22 = A_arbace_http_A_const_72; and__1927000168__auto____18 = lang.IFn_Cast(tmp22).Invoke_O__O(method_name__16) }; if jrt.A2g_Truth(and__1927000168__auto____18) {
		var tmp23 *lang.Var; A_arbace_http_A_Init(); tmp23 = A_arbace_http_A_const_73; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any = A_arbace_http_request_fn__1534000075_A_New(); var tmp26 *jrt.Class; A_arbace_http_request_fn__1534000075_A_Init(); tmp26 = A_arbace_http_request_fn__1534000075_A_fn_class; var tmp27 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var tmp28 *lang.Var; A_arbace_http_A_Init(); tmp28 = A_arbace_http_A_const_82; tmp21 = tmp24.Invoke_O_O__O(tmp27, lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(headers__9)) } else {
//line :143:1
			tmp21 = and__1927000168__auto____18 }; if /*line :142:1*/ jrt.A2g_Truth(tmp21) {


				var tmp29 *lang.Var; A_arbace_http_A_Init(); tmp29 = A_arbace_http_A_const_22; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_http_A_Init(); tmp31 = A_arbace_http_A_const_43; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; if jrt.A2g_Truth(body__15) { tmp33 = jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](body__15, jrt.Prim_byte.ArrayClass()))).Ref() } else { A_arbace_http_A_Init(); tmp33 = A_arbace_http_A_const_15 }; headers__17 = tmp30.Invoke_O_O_O__O(G__1534000074__17_, Lit_122, tmp32.Invoke_O__O(tmp33)) } else {
//line :142:1
					headers__17 = G__1534000074__17_ }; var s__18 any; var tmp34 /*line :133:1*/*lang.Var;












	A_arbace_http_A_Init(); tmp34 = A_arbace_http_A_const_74; s__18 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O_O_O__O(uri__14, timeout__12, tls__13); var tmp35 any; tmp94 := /*line :133:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














		jrt.Socket_Cast(s__18).SetSoTimeout_I__V(lang.RT_IntCast_O__I(timeout__12))
//line :133:1
		{ var out__21 any = jrt.BufferedOutputStream_New_OutputStream_I(jrt.Socket_Cast(s__18).GetOutputStream__OutputStream(), lang.RT_IntCast_J__I(65536)); var in__22 any = jrt.BufferedInputStream_New_InputStream_I(jrt.Socket_Cast(s__18).GetInputStream__InputStream(), lang.RT_IntCast_J__I(65536)); var tmp36 jrt.FilterOutputStream_I = jrt.FilterOutputStream_Cast(out__21); var tmp37 *lang.Var

















			A_arbace_http_A_Init(); tmp37 = A_arbace_http_A_const_83; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_http_A_Init(); tmp39 = A_arbace_http_A_const_84; tmp36.Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](tmp38.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O_O_O__O(method__8, uri__14, headers__17)), jrt.Prim_byte.ArrayClass()))
			if jrt.A2g_Truth(body__15) { jrt.FilterOutputStream_Cast(out__21).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](body__15, jrt.Prim_byte.ArrayClass())) }
			jrt.BufferedOutputStream_Cast(out__21).Flush__V()
//line :133:1
		L1: for { var status_line__23 any; var tmp40 *lang.Var





















			A_arbace_http_A_Init(); tmp40 = A_arbace_http_A_const_18; status_line__23 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(in__22)
//line :133:1
			var ___24 any; _ = ___24






















			if lang.Util_Identical_O_O__Z(status_line__23, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_123))) } else { ___24 = nil }
//line :133:1
			var vec__1534000077__25 any; var tmp41 *lang.Var
























			A_arbace_http_A_Init(); tmp41 = A_arbace_http_A_const_75; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 any; A_arbace_http_A_Init(); tmp43 = A_arbace_http_A_const_85; vec__1534000077__25 = tmp42.Invoke_O_O__O(tmp43, status_line__23)
//line :133:1
			var ___26 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(0), nil); var version__27 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(1), nil); var code__28 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(2), nil); var reason__29 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(3), nil); var ___30 any; _ = ___26; _ = ___30

























			if jrt.A2g_Truth(version__27) { ___30 = nil } else { var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_124, nil); var tmp45 *lang.Var; A_arbace_http_A_Init(); tmp45 = A_arbace_http_A_const_76; panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp44, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(status_line__23)))))) }
//line :133:1
			var code__31 int32 = jrt.Integer_ParseInt_String__I(jrt.String_Cast(code__28)); var hs__32 any; var tmp46 *lang.Var




























			A_arbace_http_A_Init(); tmp46 = A_arbace_http_A_const_23; hs__32 = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(in__22)
			var tmp47 any; var and__1927000168__auto____33 any; var tmp48 *lang.Var; A_arbace_http_A_Init(); tmp48 = A_arbace_http_A_const_77; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any; A_arbace_http_A_Init(); tmp50 = A_arbace_http_A_const_86; var tmp51 any = tmp50; var tmp52 any = jrt.Integer_ValueOf_I__Integer(code__31).Ref(); var tmp53 any; A_arbace_http_A_Init(); tmp53 = A_arbace_http_A_const_87; and__1927000168__auto____33 = tmp49.Invoke_O_O_O__O(tmp51, tmp52, tmp53); if jrt.A2g_Truth(and__1927000168__auto____33) { var tmp54 *lang.Var; A_arbace_http_A_Init(); tmp54 = A_arbace_http_A_const_78; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 any = jrt.Integer_ValueOf_I__Integer(code__31).Ref(); var tmp57 any; A_arbace_http_A_Init(); tmp57 = A_arbace_http_A_const_88; tmp47 = tmp55.Invoke_O_O__O(tmp56, tmp57) } else { tmp47 = and__1927000168__auto____33 }; if jrt.A2g_Truth(tmp47) {
				continue L1 } else {
//line :163:1
					var b__33 any = jrt.ByteArrayOutputStream_New(); var te__34 any; var tmp58 *lang.Var


					A_arbace_http_A_Init(); tmp58 = A_arbace_http_A_const_20; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any; var or__1927000174__auto____34 any = lang.IFn_Cast(hs__32).Invoke_O__O(Lit_125); if jrt.A2g_Truth(or__1927000174__auto____34) { tmp60 = or__1927000174__auto____34 } else { tmp60 = Lit_112 }; te__34 = tmp59.Invoke_O__O(tmp60)
//line :163:1
					var cl__35 any = lang.IFn_Cast(hs__32).Invoke_O__O(Lit_126); var tmp61 any; var or__1927000174__auto____36 bool = lang.Util_Equiv_O_O__Z(method_name__16, Lit_127)





					if or__1927000174__auto____36 { tmp61 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____36).Ref() } else { var or__1927000174__auto____37 any; var tmp62 *lang.Var; A_arbace_http_A_Init(); tmp62 = A_arbace_http_A_const_77; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 any; A_arbace_http_A_Init(); tmp64 = A_arbace_http_A_const_86; var tmp65 any = tmp64; var tmp66 any = jrt.Integer_ValueOf_I__Integer(code__31).Ref(); var tmp67 any; A_arbace_http_A_Init(); tmp67 = A_arbace_http_A_const_91; or__1927000174__auto____37 = tmp63.Invoke_O_O_O__O(tmp65, tmp66, tmp67); if jrt.A2g_Truth(or__1927000174__auto____37) { tmp61 = or__1927000174__auto____37 } else { var or__1927000174__auto____38 bool = lang.Util_Equiv_J_J__Z(int64(code__31), 204); if or__1927000174__auto____38 { tmp61 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____38).Ref() } else { tmp61 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(int64(code__31), 304)).Ref() } } }
//line :168:1
					if jrt.A2g_Truth(tmp61) { } else { var tmp68 *lang.Var; A_arbace_http_A_Init(); tmp68 = A_arbace_http_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O_O__O(te__34, Lit_128)) {

						var tmp69 *lang.Var; A_arbace_http_A_Init(); tmp69 = A_arbace_http_A_const_89; lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O_O__O(in__22, b__33) } else {
//line :168:1
							if jrt.A2g_Truth(cl__35) {


								var tmp70 *lang.Var; A_arbace_http_A_Init(); tmp70 = A_arbace_http_A_const_27; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Var; A_arbace_http_A_Init(); tmp72 = A_arbace_http_A_const_21; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_http_A_Init(); tmp74 = A_arbace_http_A_const_24; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 *lang.Var; A_arbace_http_A_Init(); tmp76 = A_arbace_http_A_const_25; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 any; A_arbace_http_A_Init(); tmp78 = A_arbace_http_A_const_92; tmp71.Invoke_O_O_O__O(in__22, b__33, jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(tmp73.Invoke_O__O(tmp75.Invoke_O__O(tmp77.Invoke_O_O__O(cl__35, tmp78)))))).Ref()) } else {
//line :168:1
									var tmp79 *lang.Keyword; A_arbace_http_A_Init(); tmp79 = A_arbace_http_A_const_14; if tmp79 != nil {



										var tmp80 *lang.Var; A_arbace_http_A_Init(); tmp80 = A_arbace_http_A_const_90; lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O_O__O(in__22, b__33) } } } }
//line :163:1
					var tmp81 *lang.Keyword; A_arbace_http_A_Init(); tmp81 = A_arbace_http_A_const_79; var tmp82 any = tmp81.Ref(); var tmp83 any = jrt.Integer_ValueOf_I__Integer(code__31).Ref(); var tmp84 *lang.Keyword; A_arbace_http_A_Init(); tmp84 = A_arbace_http_A_const_80; var tmp85 any = tmp84.Ref(); var tmp86 any
					var or__1927000174__auto____36_2 any = reason__29









					if jrt.A2g_Truth(or__1927000174__auto____36_2) { tmp86 = or__1927000174__auto____36_2 } else { tmp86 = Lit_112 }
//line :163:1
					var tmp87 any = tmp86; var tmp88 *lang.Keyword; A_arbace_http_A_Init(); tmp88 = A_arbace_http_A_const_65; var tmp89 any = tmp88.Ref(); var tmp90 *lang.Keyword; A_arbace_http_A_Init(); tmp90 = A_arbace_http_A_const_66; var tmp91 any = tmp90.Ref(); var tmp92 any; var tmp93 *lang.Keyword












					A_arbace_http_A_Init(); tmp93 = A_arbace_http_A_const_81; if lang.Util_Equiv_O_O__Z(as__11, tmp93.Ref()) {
						tmp92 = jrt.NN(jrt.ByteArrayOutputStream_Cast(b__33)).ToByteArray__B1().Ref() } else {
//line :176:1
							tmp92 = jrt.String_New_B1_Charset(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__33)).ToByteArray__B1(), jrt.StandardCharsets_UTF_8) }
//line :163:1
					tmp35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp82, tmp83, tmp85, tmp87, tmp89, hs__32, tmp91, tmp92)) }
//line :133:1
			break L1 } }; return nil }();














































	jrt.Socket_Cast(s__18).Close__V(); if /*line :133:1*/ tmp94 != nil { panic(tmp94) }; return tmp35 }










func A_arbace_http_request_fn__1534000075_A_New() *A_arbace_http_request_fn__1534000075_A { A_arbace_http_request_fn__1534000075_A_Init(); t := &A_arbace_http_request_fn__1534000075_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_http_request_fn__1534000075_A) Ctor() {}
//line :144:1
func (t *A_arbace_http_request_fn__1534000075_A) Invoke_O_O__O(self, p1__1534000066_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_http_A_Init(); tmp1 = A_arbace_http_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_http_A_Init(); tmp3 = A_arbace_http_A_const_42; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_126, tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__1534000066_SHARP___1)))).Ref() }


































type A_arbace_http_A struct{ jrt.Object }

var A_arbace_http_A_const_0 *lang.Var

var A_arbace_http_A_const_1 *lang.Var

var A_arbace_http_A_const_2 any

var A_arbace_http_A_const_3 *lang.Keyword

var A_arbace_http_A_const_4 any

var A_arbace_http_A_const_5 any

var A_arbace_http_A_const_6 any

var A_arbace_http_A_const_7 *lang.Var

var A_arbace_http_A_const_8 *lang.Var

var A_arbace_http_A_const_9 *lang.Var

var A_arbace_http_A_const_10 any

var A_arbace_http_A_const_11 *lang.Var

var A_arbace_http_A_const_12 *lang.Var

var A_arbace_http_A_const_13 *lang.Var

var A_arbace_http_A_const_14 *lang.Keyword

var A_arbace_http_A_const_15 any

var A_arbace_http_A_const_16 any

var A_arbace_http_A_const_17 any

var A_arbace_http_A_const_18 *lang.Var

var A_arbace_http_A_const_19 *lang.Var

var A_arbace_http_A_const_20 *lang.Var

var A_arbace_http_A_const_21 *lang.Var

var A_arbace_http_A_const_22 *lang.Var

var A_arbace_http_A_const_23 *lang.Var

var A_arbace_http_A_const_24 *lang.Var

var A_arbace_http_A_const_25 *lang.Var

var A_arbace_http_A_const_26 any

var A_arbace_http_A_const_27 *lang.Var

var A_arbace_http_A_const_28 any

var A_arbace_http_A_const_29 any

var A_arbace_http_A_const_30 *lang.Var

var A_arbace_http_A_const_31 *lang.Var

var A_arbace_http_A_const_32 *lang.Var

var A_arbace_http_A_const_33 *lang.Keyword

var A_arbace_http_A_const_34 any

var A_arbace_http_A_const_35 *lang.Keyword

var A_arbace_http_A_const_36 *lang.Var

var A_arbace_http_A_const_37 *lang.Var

var A_arbace_http_A_const_38 *lang.Var

var A_arbace_http_A_const_39 *lang.Var

var A_arbace_http_A_const_40 *lang.Var

var A_arbace_http_A_const_41 *lang.Var

var A_arbace_http_A_const_42 *lang.Var

var A_arbace_http_A_const_43 *lang.Var

var A_arbace_http_A_const_44 any

var A_arbace_http_A_const_45 *lang.Var

var A_arbace_http_A_const_46 *lang.Var

var A_arbace_http_A_const_47 *lang.Var

var A_arbace_http_A_const_48 *lang.Var

var A_arbace_http_A_const_49 *lang.Var

var A_arbace_http_A_const_50 *lang.Var

var A_arbace_http_A_const_51 *lang.Var

var A_arbace_http_A_const_52 *lang.Var

var A_arbace_http_A_const_53 *lang.Var

var A_arbace_http_A_const_54 *lang.Var

var A_arbace_http_A_const_55 *lang.Var

var A_arbace_http_A_const_56 *lang.Var

var A_arbace_http_A_const_57 *lang.Var

var A_arbace_http_A_const_58 *lang.Var

var A_arbace_http_A_const_59 *lang.Keyword

var A_arbace_http_A_const_60 *lang.Keyword

var A_arbace_http_A_const_61 *lang.Var

var A_arbace_http_A_const_62 *lang.Var

var A_arbace_http_A_const_63 *lang.Keyword

var A_arbace_http_A_const_64 *lang.Keyword

var A_arbace_http_A_const_65 *lang.Keyword

var A_arbace_http_A_const_66 *lang.Keyword

var A_arbace_http_A_const_67 *lang.Keyword

var A_arbace_http_A_const_68 *lang.Keyword

var A_arbace_http_A_const_69 *lang.Var

var A_arbace_http_A_const_70 *lang.Var

var A_arbace_http_A_const_71 *lang.Var

var A_arbace_http_A_const_72 any

var A_arbace_http_A_const_73 *lang.Var

var A_arbace_http_A_const_74 *lang.Var

var A_arbace_http_A_const_75 *lang.Var

var A_arbace_http_A_const_76 *lang.Var

var A_arbace_http_A_const_77 *lang.Var

var A_arbace_http_A_const_78 *lang.Var

var A_arbace_http_A_const_79 *lang.Keyword

var A_arbace_http_A_const_80 *lang.Keyword

var A_arbace_http_A_const_81 *lang.Keyword

var A_arbace_http_A_const_82 *lang.Var

var A_arbace_http_A_const_83 *lang.Var

var A_arbace_http_A_const_84 *lang.Var

var A_arbace_http_A_const_85 any

var A_arbace_http_A_const_86 any

var A_arbace_http_A_const_87 any

var A_arbace_http_A_const_88 any

var A_arbace_http_A_const_89 *lang.Var

var A_arbace_http_A_const_90 *lang.Var

var A_arbace_http_A_const_91 any

var A_arbace_http_A_const_92 any

var A_arbace_http_A_init jrt.ClassInit

func A_arbace_http_A_Init() { if !A_arbace_http_A_init.Done() { A_arbace_http_A_init.Run(A_arbace_http_A_clinit) } }

func A_arbace_http_A_clinit() { A_arbace_http_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_http_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_http_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_http_A_const_3 = lang.RT_Keyword_String_String__Keyword(nil, Lit_3); A_arbace_http_A_const_4 = lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref()); A_arbace_http_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_http_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_http_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_http_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_http_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_http_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_http_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_http_A_const_12 = lang.RT_Var_String_String__Var(Lit_5, Lit_17); A_arbace_http_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_http_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_http_A_const_15 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_http_A_const_16 = jrt.Long_ValueOf_J__Long(65536).Ref(); A_arbace_http_A_const_17 = jrt.Long_ValueOf_J__Long(65536).Ref(); A_arbace_http_A_const_18 = lang.RT_Var_String_String__Var(Lit_13, Lit_20); A_arbace_http_A_const_19 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); A_arbace_http_A_const_20 = lang.RT_Var_String_String__Var(Lit_5, Lit_22); A_arbace_http_A_const_21 = lang.RT_Var_String_String__Var(Lit_5, Lit_23); A_arbace_http_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_http_A_const_23 = lang.RT_Var_String_String__Var(Lit_13, Lit_25); A_arbace_http_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_http_A_const_25 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_http_A_const_26 = jrt.Pattern_Compile_String__Pattern(Lit_28).Ref(); A_arbace_http_A_const_27 = lang.RT_Var_String_String__Var(Lit_13, Lit_29); A_arbace_http_A_const_28 = jrt.Long_ValueOf_J__Long(443).Ref(); A_arbace_http_A_const_29 = jrt.Long_ValueOf_J__Long(80).Ref(); A_arbace_http_A_const_30 = lang.RT_Var_String_String__Var(Lit_13, Lit_30); A_arbace_http_A_const_31 = lang.RT_Var_String_String__Var(Lit_8, Lit_31); A_arbace_http_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_http_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_http_A_const_34 = lang.Tuple_Create_O__IPersistentVector(Lit_34); A_arbace_http_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_http_A_const_36 = lang.RT_Var_String_String__Var(Lit_5, Lit_36); A_arbace_http_A_const_37 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); A_arbace_http_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_http_A_const_39 = lang.RT_Var_String_String__Var(Lit_5, Lit_39); A_arbace_http_A_const_40 = lang.RT_Var_String_String__Var(Lit_5, Lit_40); A_arbace_http_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_http_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_http_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_http_A_const_44 = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_43, Lit_44, Lit_45); A_arbace_http_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_http_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_http_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_http_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_http_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_http_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_http_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_http_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_http_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_http_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_http_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_http_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_http_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_http_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_http_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_4); A_arbace_http_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_http_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_http_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_http_A_const_63 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_http_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_http_A_const_65 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_http_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_http_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_6); A_arbace_http_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_9); A_arbace_http_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_http_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_http_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_http_A_const_72 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_70, Lit_71, Lit_72)).Ref(); A_arbace_http_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_http_A_const_74 = lang.RT_Var_String_String__Var(Lit_13, Lit_74); A_arbace_http_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_http_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_http_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_http_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_http_A_const_79 = lang.RT_Keyword_String_String__Keyword(nil, Lit_79); A_arbace_http_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_80); A_arbace_http_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_81); A_arbace_http_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_http_A_const_83 = lang.RT_Var_String_String__Var(Lit_13, Lit_83); A_arbace_http_A_const_84 = lang.RT_Var_String_String__Var(Lit_13, Lit_84); A_arbace_http_A_const_85 = jrt.Pattern_Compile_String__Pattern(Lit_85).Ref(); A_arbace_http_A_const_86 = jrt.Long_ValueOf_J__Long(100).Ref(); A_arbace_http_A_const_87 = jrt.Long_ValueOf_J__Long(199).Ref(); A_arbace_http_A_const_88 = jrt.Long_ValueOf_J__Long(101).Ref(); A_arbace_http_A_const_89 = lang.RT_Var_String_String__Var(Lit_13, Lit_86); A_arbace_http_A_const_90 = lang.RT_Var_String_String__Var(Lit_13, Lit_87); A_arbace_http_A_const_91 = jrt.Long_ValueOf_J__Long(199).Ref(); A_arbace_http_A_const_92 = jrt.Pattern_Compile_String__Pattern(Lit_88).Ref() }

func A_arbace_http_A_New() *A_arbace_http_A { A_arbace_http_A_Init(); t := &A_arbace_http_A{}; t.Ctor(); return t }

func (t *A_arbace_http_A) Ctor() {}

func (t *A_arbace_http_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_A) GetClass__Class() *jrt.Class { return A_arbace_http_A_class }

func (t *A_arbace_http_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_A); return ok }

func A_arbace_http_A_Cast(x any) *A_arbace_http_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_A_class)) }; return v }



type A_arbace_http_default_port_A struct{ jrt.Object }

func (t *A_arbace_http_default_port_A) Is_Compiler_AOTF1() {}

var A_arbace_http_default_port_A_fn_class *jrt.Class

var A_arbace_http_default_port_A_init jrt.ClassInit

func A_arbace_http_default_port_A_Init() { if !A_arbace_http_default_port_A_init.Done() { A_arbace_http_default_port_A_init.Run(A_arbace_http_default_port_A_clinit) } }

func A_arbace_http_default_port_A_clinit() { A_arbace_http_default_port_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_default_port_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_default_port_A) GetClass__Class() *jrt.Class { return A_arbace_http_default_port_A_class }

func (t *A_arbace_http_default_port_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_default_port_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_default_port_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_default_port_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_default_port_A); return ok }

func A_arbace_http_default_port_A_Cast(x any) *A_arbace_http_default_port_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_default_port_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_default_port_A_class)) }; return v }



type A_arbace_http_eval1534000004_A struct{ jrt.Object }

func A_arbace_http_eval1534000004_A_New() *A_arbace_http_eval1534000004_A { t := &A_arbace_http_eval1534000004_A{}; t.Ctor(); return t }

func (t *A_arbace_http_eval1534000004_A) Ctor() {}

func (t *A_arbace_http_eval1534000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000004_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000004_A_class }

func (t *A_arbace_http_eval1534000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000004_A); return ok }

func A_arbace_http_eval1534000004_A_Cast(x any) *A_arbace_http_eval1534000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000004_A_class)) }; return v }



type A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A struct{ jrt.Object }

func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Is_Compiler_AOTF0() {}

var A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_fn_class *jrt.Class

var A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_init jrt.ClassInit

func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_Init() { if !A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_init.Done() { A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_init.Run(A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_clinit) } }

func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_clinit() { A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_class }

func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A); return ok }

func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_Cast(x any) *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_class)) }; return v }



type A_arbace_http_eval1534000008_A struct{ jrt.Object }

func A_arbace_http_eval1534000008_A_New() *A_arbace_http_eval1534000008_A { t := &A_arbace_http_eval1534000008_A{}; t.Ctor(); return t }

func (t *A_arbace_http_eval1534000008_A) Ctor() {}

func (t *A_arbace_http_eval1534000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000008_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000008_A_class }

func (t *A_arbace_http_eval1534000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000008_A); return ok }

func A_arbace_http_eval1534000008_A_Cast(x any) *A_arbace_http_eval1534000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000008_A_class)) }; return v }



type A_arbace_http_eval1534000008_fn__1534000009_A struct{ jrt.Object }

func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Is_Compiler_AOTF0() {}

var A_arbace_http_eval1534000008_fn__1534000009_A_fn_class *jrt.Class

var A_arbace_http_eval1534000008_fn__1534000009_A_init jrt.ClassInit

func A_arbace_http_eval1534000008_fn__1534000009_A_Init() { if !A_arbace_http_eval1534000008_fn__1534000009_A_init.Done() { A_arbace_http_eval1534000008_fn__1534000009_A_init.Run(A_arbace_http_eval1534000008_fn__1534000009_A_clinit) } }

func A_arbace_http_eval1534000008_fn__1534000009_A_clinit() { A_arbace_http_eval1534000008_fn__1534000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000008_fn__1534000009_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000008_fn__1534000009_A_class }

func (t *A_arbace_http_eval1534000008_fn__1534000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000008_fn__1534000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000008_fn__1534000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000008_fn__1534000009_A); return ok }

func A_arbace_http_eval1534000008_fn__1534000009_A_Cast(x any) *A_arbace_http_eval1534000008_fn__1534000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000008_fn__1534000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000008_fn__1534000009_A_class)) }; return v }



type A_arbace_http_latin1_A struct{ jrt.Object }

func (t *A_arbace_http_latin1_A) Is_Compiler_AOTF1() {}

var A_arbace_http_latin1_A_fn_class *jrt.Class

var A_arbace_http_latin1_A_init jrt.ClassInit

func A_arbace_http_latin1_A_Init() { if !A_arbace_http_latin1_A_init.Done() { A_arbace_http_latin1_A_init.Run(A_arbace_http_latin1_A_clinit) } }

func A_arbace_http_latin1_A_clinit() { A_arbace_http_latin1_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_latin1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_latin1_A) GetClass__Class() *jrt.Class { return A_arbace_http_latin1_A_class }

func (t *A_arbace_http_latin1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_latin1_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_latin1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_latin1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_latin1_A); return ok }

func A_arbace_http_latin1_A_Cast(x any) *A_arbace_http_latin1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_latin1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_latin1_A_class)) }; return v }



type A_arbace_http_open_A struct{ jrt.Object }

func (t *A_arbace_http_open_A) Is_Compiler_AOTF3() {}

var A_arbace_http_open_A_fn_class *jrt.Class

var A_arbace_http_open_A_init jrt.ClassInit

func A_arbace_http_open_A_Init() { if !A_arbace_http_open_A_init.Done() { A_arbace_http_open_A_init.Run(A_arbace_http_open_A_clinit) } }

func A_arbace_http_open_A_clinit() { A_arbace_http_open_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_open_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_open_A) GetClass__Class() *jrt.Class { return A_arbace_http_open_A_class }

func (t *A_arbace_http_open_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_open_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_open_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_open_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_open_A); return ok }

func A_arbace_http_open_A_Cast(x any) *A_arbace_http_open_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_open_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_open_A_class)) }; return v }



type A_arbace_http_read_all_A struct{ jrt.Object }

func (t *A_arbace_http_read_all_A) Is_Compiler_AOTF2() {}

var A_arbace_http_read_all_A_fn_class *jrt.Class

var A_arbace_http_read_all_A_init jrt.ClassInit

func A_arbace_http_read_all_A_Init() { if !A_arbace_http_read_all_A_init.Done() { A_arbace_http_read_all_A_init.Run(A_arbace_http_read_all_A_clinit) } }

func A_arbace_http_read_all_A_clinit() { A_arbace_http_read_all_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_read_all_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_read_all_A) GetClass__Class() *jrt.Class { return A_arbace_http_read_all_A_class }

func (t *A_arbace_http_read_all_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_read_all_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_read_all_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_read_all_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_read_all_A); return ok }

func A_arbace_http_read_all_A_Cast(x any) *A_arbace_http_read_all_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_read_all_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_read_all_A_class)) }; return v }



type A_arbace_http_read_chunked_A struct{ jrt.Object }

func (t *A_arbace_http_read_chunked_A) Is_Compiler_AOTF2() {}

var A_arbace_http_read_chunked_A_fn_class *jrt.Class

var A_arbace_http_read_chunked_A_init jrt.ClassInit

func A_arbace_http_read_chunked_A_Init() { if !A_arbace_http_read_chunked_A_init.Done() { A_arbace_http_read_chunked_A_init.Run(A_arbace_http_read_chunked_A_clinit) } }

func A_arbace_http_read_chunked_A_clinit() { A_arbace_http_read_chunked_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_read_chunked_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_read_chunked_A) GetClass__Class() *jrt.Class { return A_arbace_http_read_chunked_A_class }

func (t *A_arbace_http_read_chunked_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_read_chunked_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_read_chunked_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_read_chunked_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_read_chunked_A); return ok }

func A_arbace_http_read_chunked_A_Cast(x any) *A_arbace_http_read_chunked_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_read_chunked_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_read_chunked_A_class)) }; return v }



type A_arbace_http_read_headers_A struct{ jrt.Object }

func (t *A_arbace_http_read_headers_A) Is_Compiler_AOTF1() {}

var A_arbace_http_read_headers_A_fn_class *jrt.Class

var A_arbace_http_read_headers_A_init jrt.ClassInit

func A_arbace_http_read_headers_A_Init() { if !A_arbace_http_read_headers_A_init.Done() { A_arbace_http_read_headers_A_init.Run(A_arbace_http_read_headers_A_clinit) } }

func A_arbace_http_read_headers_A_clinit() { A_arbace_http_read_headers_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_read_headers_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_read_headers_A) GetClass__Class() *jrt.Class { return A_arbace_http_read_headers_A_class }

func (t *A_arbace_http_read_headers_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_read_headers_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_read_headers_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_read_headers_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_read_headers_A); return ok }

func A_arbace_http_read_headers_A_Cast(x any) *A_arbace_http_read_headers_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_read_headers_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_read_headers_A_class)) }; return v }



type A_arbace_http_read_line_STAR__A struct{ jrt.Object }

func (t *A_arbace_http_read_line_STAR__A) Is_Compiler_AOTF1() {}

var A_arbace_http_read_line_STAR__A_fn_class *jrt.Class

var A_arbace_http_read_line_STAR__A_init jrt.ClassInit

func A_arbace_http_read_line_STAR__A_Init() { if !A_arbace_http_read_line_STAR__A_init.Done() { A_arbace_http_read_line_STAR__A_init.Run(A_arbace_http_read_line_STAR__A_clinit) } }

func A_arbace_http_read_line_STAR__A_clinit() { A_arbace_http_read_line_STAR__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_read_line_STAR__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_read_line_STAR__A) GetClass__Class() *jrt.Class { return A_arbace_http_read_line_STAR__A_class }

func (t *A_arbace_http_read_line_STAR__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_read_line_STAR__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_read_line_STAR__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_read_line_STAR__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_read_line_STAR__A); return ok }

func A_arbace_http_read_line_STAR__A_Cast(x any) *A_arbace_http_read_line_STAR__A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_read_line_STAR__A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_read_line_STAR__A_class)) }; return v }



type A_arbace_http_read_n_A struct{ jrt.Object }

func (t *A_arbace_http_read_n_A) Is_Compiler_AOTF3() {}

var A_arbace_http_read_n_A_fn_class *jrt.Class

var A_arbace_http_read_n_A_init jrt.ClassInit

func A_arbace_http_read_n_A_Init() { if !A_arbace_http_read_n_A_init.Done() { A_arbace_http_read_n_A_init.Run(A_arbace_http_read_n_A_clinit) } }

func A_arbace_http_read_n_A_clinit() { A_arbace_http_read_n_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_read_n_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_read_n_A) GetClass__Class() *jrt.Class { return A_arbace_http_read_n_A_class }

func (t *A_arbace_http_read_n_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_read_n_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_read_n_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_read_n_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_read_n_A); return ok }

func A_arbace_http_read_n_A_Cast(x any) *A_arbace_http_read_n_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_read_n_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_read_n_A_class)) }; return v }



type A_arbace_http_request_A struct{ jrt.Object }

func (t *A_arbace_http_request_A) Is_Compiler_AOTF1() {}

var A_arbace_http_request_A_fn_class *jrt.Class

var A_arbace_http_request_A_init jrt.ClassInit

func A_arbace_http_request_A_Init() { if !A_arbace_http_request_A_init.Done() { A_arbace_http_request_A_init.Run(A_arbace_http_request_A_clinit) } }

func A_arbace_http_request_A_clinit() { A_arbace_http_request_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_A_class }

func (t *A_arbace_http_request_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_A); return ok }

func A_arbace_http_request_A_Cast(x any) *A_arbace_http_request_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_A_class)) }; return v }



type A_arbace_http_request_fn__1534000075_A struct{ jrt.Object }

func (t *A_arbace_http_request_fn__1534000075_A) Is_Compiler_AOTF1() {}

var A_arbace_http_request_fn__1534000075_A_fn_class *jrt.Class

var A_arbace_http_request_fn__1534000075_A_init jrt.ClassInit

func A_arbace_http_request_fn__1534000075_A_Init() { if !A_arbace_http_request_fn__1534000075_A_init.Done() { A_arbace_http_request_fn__1534000075_A_init.Run(A_arbace_http_request_fn__1534000075_A_clinit) } }

func A_arbace_http_request_fn__1534000075_A_clinit() { A_arbace_http_request_fn__1534000075_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_fn__1534000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_fn__1534000075_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_fn__1534000075_A_class }

func (t *A_arbace_http_request_fn__1534000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_fn__1534000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_fn__1534000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_fn__1534000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_fn__1534000075_A); return ok }

func A_arbace_http_request_fn__1534000075_A_Cast(x any) *A_arbace_http_request_fn__1534000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_fn__1534000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_fn__1534000075_A_class)) }; return v }



type A_arbace_http_request_head_A struct{ jrt.Object }

func (t *A_arbace_http_request_head_A) Is_Compiler_AOTF3() {}

var A_arbace_http_request_head_A_fn_class *jrt.Class

var A_arbace_http_request_head_A_init jrt.ClassInit

func A_arbace_http_request_head_A_Init() { if !A_arbace_http_request_head_A_init.Done() { A_arbace_http_request_head_A_init.Run(A_arbace_http_request_head_A_clinit) } }

func A_arbace_http_request_head_A_clinit() { A_arbace_http_request_head_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_A_class }

func (t *A_arbace_http_request_head_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_A); return ok }

func A_arbace_http_request_head_A_Cast(x any) *A_arbace_http_request_head_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_A_class)) }; return v }



type A_arbace_http_request_head_fn__1534000022_A struct{ jrt.Object }

func (t *A_arbace_http_request_head_fn__1534000022_A) Is_Compiler_AOTF1() {}

var A_arbace_http_request_head_fn__1534000022_A_fn_class *jrt.Class

var A_arbace_http_request_head_fn__1534000022_A_init jrt.ClassInit

func A_arbace_http_request_head_fn__1534000022_A_Init() { if !A_arbace_http_request_head_fn__1534000022_A_init.Done() { A_arbace_http_request_head_fn__1534000022_A_init.Run(A_arbace_http_request_head_fn__1534000022_A_clinit) } }

func A_arbace_http_request_head_fn__1534000022_A_clinit() { A_arbace_http_request_head_fn__1534000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_fn__1534000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_fn__1534000022_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_fn__1534000022_A_class }

func (t *A_arbace_http_request_head_fn__1534000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_fn__1534000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_fn__1534000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_fn__1534000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_fn__1534000022_A); return ok }

func A_arbace_http_request_head_fn__1534000022_A_Cast(x any) *A_arbace_http_request_head_fn__1534000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_fn__1534000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_fn__1534000022_A_class)) }; return v }



type A_arbace_http_request_head_iter__1534000027__1534000031_A struct{ jrt.Object; F_given any }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Is_Compiler_AOTF1() {}

var A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class *jrt.Class

var A_arbace_http_request_head_iter__1534000027__1534000031_A_init jrt.ClassInit

func A_arbace_http_request_head_iter__1534000027__1534000031_A_Init() { if !A_arbace_http_request_head_iter__1534000027__1534000031_A_init.Done() { A_arbace_http_request_head_iter__1534000027__1534000031_A_init.Run(A_arbace_http_request_head_iter__1534000027__1534000031_A_clinit) } }

func A_arbace_http_request_head_iter__1534000027__1534000031_A_clinit() { A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_iter__1534000027__1534000031_A_class }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_iter__1534000027__1534000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_iter__1534000027__1534000031_A); return ok }

func A_arbace_http_request_head_iter__1534000027__1534000031_A_Cast(x any) *A_arbace_http_request_head_iter__1534000027__1534000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_iter__1534000027__1534000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_iter__1534000027__1534000031_A_class)) }; return v }



type A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A struct{ jrt.Object; F_iter__1534000027, F_given, F_s__1534000028 any }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Is_Compiler_AOTF0() {}

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class *jrt.Class

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_init jrt.ClassInit

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_Init() { if !A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_init.Done() { A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_init.Run(A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_clinit) } }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_clinit() { A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A); return ok }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_Cast(x any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_class)) }; return v }



type A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A struct{ jrt.Object; F_given any; F_size__1927001038__auto__ int32; F_b__1534000030, F_c__1927001037__auto__ any }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Is_Compiler_AOTF0() {}

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class *jrt.Class

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_init jrt.ClassInit

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_Init() { if !A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_init.Done() { A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_init.Run(A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_clinit) } }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_clinit() { A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_class }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A); return ok }

func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_Cast(x any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_class)) }; return v }



type A_arbace_http_request_head_iter__1534000043__1534000047_A struct{ jrt.Object }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Is_Compiler_AOTF1() {}

var A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class *jrt.Class

var A_arbace_http_request_head_iter__1534000043__1534000047_A_init jrt.ClassInit

func A_arbace_http_request_head_iter__1534000043__1534000047_A_Init() { if !A_arbace_http_request_head_iter__1534000043__1534000047_A_init.Done() { A_arbace_http_request_head_iter__1534000043__1534000047_A_init.Run(A_arbace_http_request_head_iter__1534000043__1534000047_A_clinit) } }

func A_arbace_http_request_head_iter__1534000043__1534000047_A_clinit() { A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_iter__1534000043__1534000047_A_class }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_iter__1534000043__1534000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_iter__1534000043__1534000047_A); return ok }

func A_arbace_http_request_head_iter__1534000043__1534000047_A_Cast(x any) *A_arbace_http_request_head_iter__1534000043__1534000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_iter__1534000043__1534000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_iter__1534000043__1534000047_A_class)) }; return v }



type A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A struct{ jrt.Object; F_s__1534000044, F_iter__1534000043 any }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Is_Compiler_AOTF0() {}

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class *jrt.Class

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_init jrt.ClassInit

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_Init() { if !A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_init.Done() { A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_init.Run(A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_clinit) } }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_clinit() { A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A); return ok }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_Cast(x any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_class)) }; return v }



type A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A struct{ jrt.Object; F_b__1534000046 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Is_Compiler_AOTF0() {}

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class *jrt.Class

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_init jrt.ClassInit

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_Init() { if !A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_init.Done() { A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_init.Run(A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_clinit) } }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_clinit() { A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_150, lang.Compiler_AOTFn_class) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) GetClass__Class() *jrt.Class { return A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_class }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A); return ok }

func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_Cast(x any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_class)) }; return v }
