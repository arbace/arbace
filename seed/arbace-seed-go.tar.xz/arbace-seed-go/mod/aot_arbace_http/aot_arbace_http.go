//line aot_arbace_http.ae:1
package aot_arbace_http

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_New() *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A { A_arbace_http_A_Init(); t := &A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_http_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_http_A_const_2, A_arbace_http_A_const_3, A_arbace_http_A_const_4); lang.IFn_Cast(A_arbace_http_A_const_1.GetRawRoot__O()).Invoke_O_O__O(A_arbace_http_A_const_5, A_arbace_http_A_const_6); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_2)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_3)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_4)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_6)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_7)); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_8)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_9)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_10)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_11)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp14 != nil { panic(tmp14) }; return tmp3 }
//line :3:1
func A_arbace_http_eval1534000008_fn__1534000009_A_New() *A_arbace_http_eval1534000008_fn__1534000009_A { A_arbace_http_A_Init(); t := &A_arbace_http_eval1534000008_fn__1534000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_http_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_http_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_http_A_const_11), A_arbace_http_A_const_9.GetRawRoot__O(), A_arbace_http_A_const_10) }


































func A_arbace_http_latin1_A_New() *A_arbace_http_latin1_A { A_arbace_http_A_Init(); t := &A_arbace_http_latin1_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_http_latin1_A) Ctor() {}
//line :38:1
func (t *A_arbace_http_latin1_A) Invoke_O_O__O(self, s__0 any) any { return jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_ISO_8859_1).Ref() }

func A_arbace_http_read_line_STAR__A_New() *A_arbace_http_read_line_STAR__A { A_arbace_http_A_Init(); t := &A_arbace_http_read_line_STAR__A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_http_read_line_STAR__A) Ctor() {}
//line :40:1
func (t *A_arbace_http_read_line_STAR__A) Invoke_O_O__O(self, in__0 any) any { { var b__2 any = jrt.ByteArrayOutputStream_New(); L1: for { var c__3 int32 = jrt.InputStream_Cast(in__0).Read__I()





	if lang.Numbers_Equiv_J_J__Z(int64(c__3), -1) {
		if lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).Size__I())) { return jrt.String_New_B1_Charset(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).ToByteArray__B1(), jrt.StandardCharsets_ISO_8859_1) } else { return nil } } else {
//line :46:1
			if lang.Numbers_Equiv_J_J__Z(int64(c__3), 10) { var s__4 any = jrt.String_New_B1_Charset(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).ToByteArray__B1(), jrt.StandardCharsets_ISO_8859_1)


				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_12.GetRawRoot__O()).Invoke_O_O__O(s__4, Lit_19)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_http_A_const_15; return tmp1.Invoke_O_O_O__O(s__4, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(s__4)))).Ref()) } else { return s__4 } } else {
//line :46:1
					if A_arbace_http_A_const_14 != nil {



						jrt.NN(jrt.ByteArrayOutputStream_Cast(b__2)).Write_I__V(c__3); continue L1 } else {
//line :46:1
							return nil } } } } }; /*line :40:1*/panic("j2g: unreachable") }











func A_arbace_http_read_n_A_New() *A_arbace_http_read_n_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_n_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_http_read_n_A) Ctor() {}
//line :52:1
func (t *A_arbace_http_read_n_A) Invoke_O_O_O_O__O(self, in__0, out__1, p_n__2 any) any { { var n__2 int64 = lang.RT_LongCast_O__J(p_n__2); var buf__4 any = lang.Numbers_Byte_array_O__B1(A_arbace_http_A_const_16).Ref(); var left__5 int64 = n__2; L1: for {




	if lang.Numbers_IsPos_J__Z(left__5) { var k__6 int32 = jrt.InputStream_Cast(in__0).Read_B1_I_I__I(jrt.J2g_CastArray[*jrt.ByteArray](buf__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(lang.Numbers_Min_J_J__J(left__5, 65536)))

		if lang.Numbers_IsNeg_J__Z(int64(k__6)) { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_21), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(left__5).Ref(), nil)))))
		}
		jrt.OutputStream_Cast(out__1).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](buf__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), k__6)
		left__5 = lang.Numbers_Minus_J_J__J(left__5, int64(k__6)); continue L1 } else {
//line :57:1
			return nil } } }; /*line :52:1*/panic("j2g: unreachable") }











func A_arbace_http_read_all_A_New() *A_arbace_http_read_all_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_all_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_http_read_all_A) Ctor() {}
//line :64:1
func (t *A_arbace_http_read_all_A) Invoke_O_O_O__O(self, in__0, out__1 any) any { { var buf__3 any = lang.Numbers_Byte_array_O__B1(A_arbace_http_A_const_17).Ref(); L1: for { var k__4 int32 = jrt.InputStream_Cast(in__0).Read_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](buf__3, jrt.Prim_byte.ArrayClass()))



	if lang.Numbers_IsNeg_J__Z(int64(k__4)) { return nil } else {
		jrt.OutputStream_Cast(out__1).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](buf__3, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), k__4)
		continue L1 } } }; /*line :64:1*/panic("j2g: unreachable") }







func A_arbace_http_read_headers_A_New() *A_arbace_http_read_headers_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_headers_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_http_read_headers_A) Ctor() {}
//line :72:1
func (t *A_arbace_http_read_headers_A) Invoke_O_O__O(self, in__0 any) any { { var h__2 any; lang.PersistentArrayMap_Init(); h__2 = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var line__3 any = lang.IFn_Cast(A_arbace_http_A_const_18.GetRawRoot__O()).Invoke_O__O(in__0)




	if lang.Util_Identical_O_O__Z(line__3, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_15))) } else { if lang.Util_Equiv_O_O__Z(line__3, Lit_16) { return h__2 } else { if A_arbace_http_A_const_14 != nil { var i__4 any = lang.IFn_Cast(A_arbace_http_A_const_19.GetRawRoot__O()).Invoke_O_O__O(line__3, Lit_17)



		if lang.Util_Identical_O_O__Z(i__4, nil) {
			h__2 = h__2; continue L1 } else {
//line :81:1
				var k__5 any = lang.IFn_Cast(A_arbace_http_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(line__3, A_arbace_http_A_const_15, i__4))); var v__6 any = lang.IFn_Cast(A_arbace_http_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_13.GetRawRoot__O()).Invoke_O_O__O(line__3, lang.Numbers_Inc_O__Number(i__4))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_22.GetRawRoot__O()); var tmp2 any; var temp__1927000408__auto____7 any = lang.IFn_Cast(h__2).Invoke_O__O(k__5)



				if jrt.J2g_Truth(temp__1927000408__auto____7) { var old__8 any = temp__1927000408__auto____7; tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, old__8, nil, v__6)).Ref() } else { tmp2 = v__6 }; h__2 = tmp1.Invoke_O_O_O__O(h__2, k__5, tmp2); continue L1 } } else {
//line :77:1
					return nil } } } } }; /*line :72:1*/panic("j2g: unreachable") }














func A_arbace_http_read_chunked_A_New() *A_arbace_http_read_chunked_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_chunked_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_http_read_chunked_A) Ctor() {}
//line :87:1
func (t *A_arbace_http_read_chunked_A) Invoke_O_O_O__O(self, in__0, out__1 any) any { L1: for { var line__3 any = lang.IFn_Cast(A_arbace_http_A_const_18.GetRawRoot__O()).Invoke_O__O(in__0); var ___4 any; _ = ___4


	if lang.Util_Identical_O_O__Z(line__3, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_14))) } else { ___4 = nil }
//line :87:1
	var size__5 int64 = jrt.Long_ParseLong_String_I__J(jrt.String_Cast(lang.IFn_Cast(A_arbace_http_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_25.GetRawRoot__O()).Invoke_O_O__O(line__3, A_arbace_http_A_const_26)))), lang.RT_IntCast_J__I(16))




	if lang.Numbers_IsZero_J__Z(size__5) {
		return lang.IFn_Cast(A_arbace_http_A_const_23.GetRawRoot__O()).Invoke_O__O(in__0) } else {
			lang.IFn_Cast(A_arbace_http_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(in__0, out__1, jrt.Long_ValueOf_J__Long(size__5).Ref())
			lang.IFn_Cast(A_arbace_http_A_const_18.GetRawRoot__O()).Invoke_O__O(in__0)
			continue L1 } }; /*line :87:1*/panic("j2g: unreachable") }










func A_arbace_http_default_port_A_New() *A_arbace_http_default_port_A { A_arbace_http_A_Init(); t := &A_arbace_http_default_port_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_http_default_port_A) Ctor() {}
//line :98:1
func (t *A_arbace_http_default_port_A) Invoke_O_O__O(self, scheme__0 any) any { if lang.Util_Equiv_O_O__Z(scheme__0, Lit_1) { return A_arbace_http_A_const_28 } else { return A_arbace_http_A_const_29 } }

func A_arbace_http_open_A_New() *A_arbace_http_open_A { A_arbace_http_A_Init(); t := &A_arbace_http_open_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_http_open_A) Ctor() {}
//line :100:1
func (t *A_arbace_http_open_A) Invoke_O_O_O_O__O(self, uri__0, timeout__1, tls_opts__2 any) any { var scheme__4 any = lang.IFn_Cast(A_arbace_http_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.URI_Cast(uri__0)).GetScheme__String().Ref()); var host__5 any = jrt.NN(jrt.URI_Cast(uri__0)).GetHost__String().Ref(); var port__6 any; var p__6 int32 = jrt.NN(jrt.URI_Cast(uri__0)).GetPort__I(); if




	lang.Numbers_IsNeg_J__Z(int64(p__6)) { port__6 = lang.IFn_Cast(A_arbace_http_A_const_30.GetRawRoot__O()).Invoke_O__O(scheme__4) } else { port__6 = jrt.Integer_ValueOf_I__Integer(p__6).Ref() }; var G__1534000019__7_ any = scheme__4; switch
	lang.Util_Hash_O__I(G__1534000019__7_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z(G__1534000019__7_, Lit_12) { var s__8 any = jrt.Socket_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		jrt.Socket_Cast(s__8).Connect_SocketAddress_I__V(jrt.InetSocketAddress_New_String_I(jrt.String_Cast(host__5), lang.RT_IntCast_O__I(port__6)), lang.RT_IntCast_O__I(timeout__1))
//line :106:1
		tmp1 = s__8; return nil }(); if tmp2 != nil { if true { var t__11 jrt.Throwable_I = tmp2





			jrt.Socket_Cast(s__8).Close__V()
//line :106:1
			panic(jrt.Thrown(t__11)) } }; return tmp1 }; case 1: if lang.Util_Equiv_O_O__Z(G__1534000019__7_, Lit_1) {
				return lang.IFn_Cast(A_arbace_http_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(host__5, port__6, lang.IFn_Cast(A_arbace_http_A_const_32.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_http_A_const_33, A_arbace_http_A_const_34, A_arbace_http_A_const_35, timeout__1)), tls_opts__2)) }
//line :106:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, uri__0))))) }








func A_arbace_http_request_head_A_New() *A_arbace_http_request_head_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_http_request_head_A) Ctor() {}
//line :115:1
func (t *A_arbace_http_request_head_A) Invoke_O_O_O_O__O(self, method__0, uri__1, headers__2 any) any { var scheme__4 any = lang.IFn_Cast(A_arbace_http_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.URI_Cast(uri__1)).GetScheme__String().Ref()); var p__5 int32 = jrt.NN(jrt.URI_Cast(uri__1)).GetPort__I(); var host__6 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var h__8 any = jrt.NN(jrt.URI_Cast(uri__1)).GetHost__String().Ref(); if




	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_36.GetRawRoot__O()).Invoke_O_O__O(h__8, Lit_17)) { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_32), jrt.RefArrayOf(jrt.Object_class, nil, h__8, nil)).Ref() } else { tmp2 = h__8 }; var tmp3 any = tmp2; var tmp4 *jrt.String; var tmp5 bool; var or__1927000174__auto____8 bool = lang.Numbers_IsNeg_J__Z(int64(p__5)); if or__1927000174__auto____8 {
		tmp5 = or__1927000174__auto____8 } else { tmp5 = lang.Util_Equiv_J_O__Z(int64(p__5), lang.IFn_Cast(A_arbace_http_A_const_30.GetRawRoot__O()).Invoke_O__O(scheme__4)) }; if tmp5 { tmp4 = nil } else { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer(p__5).Ref())) }; host__6 = /*line :120:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref(); var target__7 any; var tmp6 /*line :115:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any; var path__9 any = jrt.NN(jrt.URI_Cast(uri__1)).GetRawPath__String().Ref(); if






	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_37.GetRawRoot__O()).Invoke_O__O(path__9)) { tmp7 = Lit_33 } else { tmp7 = path__9 }; var tmp8 any = tmp7; var tmp9 *jrt.String; var temp__1927000414__auto____9 any = jrt.NN(jrt.URI_Cast(uri__1)).GetRawQuery__String().Ref(); if
	jrt.J2g_Truth(temp__1927000414__auto____9) { var q__10 any = temp__1927000414__auto____9; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, q__10)) } else { tmp9 = nil }; target__7 = /*line :122:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9.Ref())).Ref(); var given__8 any; var tmp10 lang.IFn = /*line :115:1*/lang.IFn_Cast(A_arbace_http_A_const_38.GetRawRoot__O()); var tmp11 *lang.PersistentArrayMap;








	lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; var tmp12 any = tmp11.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_41.GetRawRoot__O()); var tmp14 any = A_arbace_http_request_head_fn__1534000022_A_New(); var tmp15 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_http_request_head_fn__1534000022_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_http_request_head_fn__1534000022_A_fn_class = fncls__2d; tmp15 = fncls__2d } else { tmp15 = fncls__2 }; given__8 = tmp10.Invoke_O_O_O__O(tmp12, tmp13.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)), headers__2); var defaults__9 any = /*line :115:1*/lang.Tuple_Create_O_O_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(Lit_36, Lit_37, host__6), lang.Tuple_Create_O_O_O__IPersistentVector(Lit_38, Lit_39, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_http_A_const_45.GetRawRoot__O()).Invoke__O())).Ref()), A_arbace_http_A_const_44); var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_41, nil, Lit_42, nil, nil, Lit_43); var tmp17 any = lang.IFn_Cast(A_arbace_http_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_42.GetRawRoot__O()).Invoke_O__O(method__0)); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_40.GetRawRoot__O()); var tmp19 any; var iter__1927001039__auto____17 any; var tmp20 any = A_arbace_http_request_head_iter__1534000027__1534000031_A_New_O(given__8); var tmp21 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class; if













	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class = fncls__5d; tmp21 = fncls__5d } else { tmp21 = fncls__5 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); tmp19 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(defaults__9); var tmp22 any = /*line :128:1*/tmp18.Invoke_O__O(tmp19); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_40.GetRawRoot__O()); var tmp24 any; var iter__1927001039__auto____17_2 any; var tmp25 any = A_arbace_http_request_head_iter__1534000043__1534000047_A_New(); var tmp26 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class; if

	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class = fncls__8d; tmp26 = fncls__8d } else { tmp26 = fncls__8 }; iter__1927001039__auto____17_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); tmp24 = lang.IFn_Cast(iter__1927001039__auto____17_2).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_57.GetRawRoot__O()).Invoke_O_O__O(A_arbace_http_A_const_58.GetRawRoot__O(), given__8)); return /*line :128:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, nil, target__7, nil, tmp22, tmp23.Invoke_O__O(tmp24), nil)).Ref() }
//line :124:1
func A_arbace_http_request_head_fn__1534000022_A_New() *A_arbace_http_request_head_fn__1534000022_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_fn__1534000022_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_http_request_head_fn__1534000022_A) Ctor() {}
//line :124:1
func (t *A_arbace_http_request_head_fn__1534000022_A) Invoke_O_O__O(self, p__1534000021__1 any) any { var vec__1534000023__2 any = p__1534000021__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1534000023__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1534000023__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_http_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_42.GetRawRoot__O()).Invoke_O__O(k__3)), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_http_A_const_42.GetRawRoot__O()).Invoke_O__O(k__3), lang.IFn_Cast(A_arbace_http_A_const_43.GetRawRoot__O()).Invoke_O__O(v__4))) }




func A_arbace_http_request_head_iter__1534000027__1534000031_A_New_O(p0 any) *A_arbace_http_request_head_iter__1534000027__1534000031_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Ctor_O(c__given any) { t.F_given = c__given }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Invoke_O_O__O(self, s__1534000028__1 any) any { var tmp1 any = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_New_O_O_O(self, t.F_given, s__1534000028__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :129:1
func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Ctor_O_O_O(c__iter__1534000027, c__given, c__s__1534000028 any) { t.F_iter__1534000027 = c__iter__1534000027; t.F_given = c__given; t.F_s__1534000028 = c__s__1534000028 }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Invoke_O__O(self any) any { { var s__1534000028__1 any; var t_ any = t.F_s__1534000028; t.F_s__1534000028 = nil; s__1534000028__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_http_A_const_46.GetRawRoot__O()).Invoke_O__O(s__1534000028__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1534000028__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1534000028__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_http_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1534000028__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1534000030__6 any = lang.IFn_Cast(A_arbace_http_A_const_49.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_New_O_I_O_O(t.F_given, size__1927001038__auto____5, b__1534000030__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1534000027); return lang.IFn_Cast(A_arbace_http_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_http_A_const_54.GetRawRoot__O()).Invoke_O__O(b__1534000030__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1534000028__3))) } else { return lang.IFn_Cast(A_arbace_http_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_http_A_const_54.GetRawRoot__O()).Invoke_O__O(b__1534000030__6), nil) } } else { var vec__1534000038__4 any = lang.IFn_Cast(A_arbace_http_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1534000028__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1534000038__4, lang.RT_IntCast_J__I(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O(vec__1534000038__4, lang.RT_IntCast_J__I(1), nil); var v__7 any = lang.RT_Nth_O_I_O__O(vec__1534000038__4, lang.RT_IntCast_J__I(2), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_given).Invoke_O__O(k__5))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1534000027); return lang.IFn_Cast(A_arbace_http_A_const_53.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__6, nil, v__7, nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_56.GetRawRoot__O()).Invoke_O__O(s__1534000028__3))) } else { s__1534000028__1 = lang.IFn_Cast(A_arbace_http_A_const_56.GetRawRoot__O()).Invoke_O__O(s__1534000028__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :129:1
func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Ctor_O_I_O_O(c__given any, c__size__1927001038__auto__ int32, c__b__1534000030, c__c__1927001037__auto__ any) { t.F_given = c__given; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1534000030 = c__b__1534000030; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Invoke_O__O(self any) any { { var i__1534000029__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1534000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1534000034__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1534000029__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1534000034__2, lang.RT_IntCast_J__I(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O(vec__1534000034__2, lang.RT_IntCast_J__I(1), nil); var v__5 any = lang.RT_Nth_O_I_O__O(vec__1534000034__2, lang.RT_IntCast_J__I(2), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_given).Invoke_O__O(k__3))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_51.GetRawRoot__O()); var tmp3 any = t.F_b__1534000030; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__4, nil, v__5, nil)).Ref()); i__1534000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1534000029__1); continue L1 } else { i__1534000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1534000029__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_http_request_head_iter__1534000043__1534000047_A_New() *A_arbace_http_request_head_iter__1534000043__1534000047_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Ctor() {}
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Invoke_O_O__O(self, s__1534000044__1 any) any { var tmp1 any = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_New_O_O(s__1534000044__1, self); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :130:1
func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_New_O_O(p0, p1 any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Ctor_O_O(c__s__1534000044, c__iter__1534000043 any) { t.F_s__1534000044 = c__s__1534000044; t.F_iter__1534000043 = c__iter__1534000043 }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Invoke_O__O(self any) any { { var s__1534000044__1 any; var t_ any = t.F_s__1534000044; t.F_s__1534000044 = nil; s__1534000044__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_http_A_const_46.GetRawRoot__O()).Invoke_O__O(s__1534000044__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1534000044__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1534000044__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_http_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1534000044__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1534000046__6 any = lang.IFn_Cast(A_arbace_http_A_const_49.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_New_O_I_O(b__1534000046__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1534000043); return lang.IFn_Cast(A_arbace_http_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_http_A_const_54.GetRawRoot__O()).Invoke_O__O(b__1534000046__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_55.GetRawRoot__O()).Invoke_O__O(s__1534000044__3))) } else { return lang.IFn_Cast(A_arbace_http_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_http_A_const_54.GetRawRoot__O()).Invoke_O__O(b__1534000046__6), nil) } } else { var vec__1534000057__4 any = lang.IFn_Cast(A_arbace_http_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1534000044__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1534000057__4, lang.RT_IntCast_J__I(0), nil); var vec__1534000060__6 any = lang.RT_Nth_O_I_O__O(vec__1534000057__4, lang.RT_IntCast_J__I(1), nil); var n__7 any = lang.RT_Nth_O_I_O__O(vec__1534000060__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__1534000060__6, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1534000043); _ = ___5; return lang.IFn_Cast(A_arbace_http_A_const_53.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__7, nil, v__8, nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_56.GetRawRoot__O()).Invoke_O__O(s__1534000044__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :130:1
func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Ctor_O_I_O(c__b__1534000046 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1534000046 = c__b__1534000046; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Invoke_O__O(self any) any { { var i__1534000045__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1534000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1534000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1534000045__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__1534000050__2, lang.RT_IntCast_J__I(0), nil); var vec__1534000053__4 any = lang.RT_Nth_O_I_O__O(vec__1534000050__2, lang.RT_IntCast_J__I(1), nil); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1534000053__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1534000053__4, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_51.GetRawRoot__O()); var tmp3 any = t.F_b__1534000046; _ = ___3; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__5, nil, v__6, nil)).Ref()); i__1534000045__1 = lang.Numbers_Unchecked_inc_J__J(i__1534000045__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_http_request_A_New() *A_arbace_http_request_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_http_request_A) Ctor() {}
//line :133:1
func (t *A_arbace_http_request_A) Invoke_O_O__O(self, p__1534000067__0 any) any { var default__1534000070__2 any = A_arbace_http_A_const_59; var default__1534000071__3 any = A_arbace_http_A_const_60; var default__1534000072__4 int64 = 0; var map__1534000068__5 any = p__1534000067__0; var map__1534000068__6 any; if lang.ISeq_InstanceOf(map__1534000068__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_61.GetRawRoot__O()).Invoke_O__O(map__1534000068__5)) { map__1534000068__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_http_A_const_62.GetRawRoot__O()).Invoke_O__O(map__1534000068__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_46.GetRawRoot__O()).Invoke_O__O(map__1534000068__5)) { map__1534000068__6 = lang.IFn_Cast(A_arbace_http_A_const_24.GetRawRoot__O()).Invoke_O__O(map__1534000068__5) } else { lang.PersistentArrayMap_Init(); map__1534000068__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1534000068__6 = map__1534000068__5 }; var url__7 any = lang.RT_Get_O_O__O(map__1534000068__6, A_arbace_http_A_const_63); var method__8 any = lang.RT_Get_O_O_O__O(map__1534000068__6, A_arbace_http_A_const_64, default__1534000070__2); var headers__9 any = lang.RT_Get_O_O__O(map__1534000068__6, A_arbace_http_A_const_65); var body__10 any = lang.RT_Get_O_O__O(map__1534000068__6, A_arbace_http_A_const_66); var as__11 any = lang.RT_Get_O_O_O__O(map__1534000068__6, A_arbace_http_A_const_67, default__1534000071__3); var tmp1 any = A_arbace_http_A_const_35; var timeout__12 any = lang.RT_Get_O_O_O__O(map__1534000068__6, tmp1, jrt.Long_ValueOf_J__Long(default__1534000072__4).Ref()); var tls__13 any = lang.RT_Get_O_O__O(map__1534000068__6, A_arbace_http_A_const_68); var uri__14 any = jrt.URI_New_String(jrt.String_Cast(url__7)); var body__15 any; if



	lang.Util_Identical_O_O__Z(body__10, nil) { body__15 = nil } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_69.GetRawRoot__O()).Invoke_O__O(body__10)) {
		body__15 = jrt.NN(jrt.String_Cast(body__10)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else {
//line :137:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_70.GetRawRoot__O()).Invoke_O__O(body__10)) { body__15 = body__10 } else { if A_arbace_http_A_const_14 != nil { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_http_A_const_71.GetRawRoot__O()).Invoke_O__O(body__10)))))) } else { body__15 = nil } } } }; var method_name__16 any = /*line :133:1*/lang.IFn_Cast(A_arbace_http_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_42.GetRawRoot__O()).Invoke_O__O(method__8)); var headers__17 any; var G__1534000074__17_ any; var or__1927000174__auto____17 any = headers__9; if








	jrt.J2g_Truth(or__1927000174__auto____17) { G__1534000074__17_ = or__1927000174__auto____17 } else { lang.PersistentArrayMap_Init(); G__1534000074__17_ = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp2 any; var and__1927000168__auto____18 any; var or__1927000174__auto____18 any = body__15; if
	jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18 = or__1927000174__auto____18 } else { and__1927000168__auto____18 = lang.IFn_Cast(A_arbace_http_A_const_72).Invoke_O__O(method_name__16) }; if jrt.J2g_Truth(and__1927000168__auto____18) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_73.GetRawRoot__O()); var tmp4 any = A_arbace_http_request_fn__1534000075_A_New(); var tmp5 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_http_request_fn__1534000075_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_http_request_fn__1534000075_A_fn_class = fncls__9d; tmp5 = fncls__9d } else { tmp5 = fncls__9 }; tmp2 = tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_http_A_const_82.GetRawRoot__O()).Invoke_O__O(headers__9)) } else {
//line :143:1
			tmp2 = and__1927000168__auto____18 }; if /*line :142:1*/ jrt.J2g_Truth(tmp2) {


				var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_22.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_43.GetRawRoot__O()); var tmp8 any; if jrt.J2g_Truth(body__15) { tmp8 = jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](body__15, jrt.Prim_byte.ArrayClass()))).Ref() } else { tmp8 = A_arbace_http_A_const_15 }; headers__17 = tmp6.Invoke_O_O_O__O(G__1534000074__17_, Lit_24, tmp7.Invoke_O__O(tmp8)) } else {
//line :142:1
					headers__17 = G__1534000074__17_ }; var s__18 any = /*line :133:1*/lang.IFn_Cast(A_arbace_http_A_const_74.GetRawRoot__O()).Invoke_O_O_O__O(uri__14, timeout__12, tls__13); var tmp9 any; tmp26 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














						jrt.Socket_Cast(s__18).SetSoTimeout_I__V(lang.RT_IntCast_O__I(timeout__12))
//line :133:1
						{ var out__21 any = jrt.BufferedOutputStream_New_OutputStream_I(jrt.Socket_Cast(s__18).GetOutputStream__OutputStream(), lang.RT_IntCast_J__I(65536)); var in__22 any = jrt.BufferedInputStream_New_InputStream_I(jrt.Socket_Cast(s__18).GetInputStream__InputStream(), lang.RT_IntCast_J__I(65536))

















							jrt.FilterOutputStream_Cast(out__21).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(A_arbace_http_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(method__8, uri__14, headers__17)), jrt.Prim_byte.ArrayClass()))
							if jrt.J2g_Truth(body__15) { jrt.FilterOutputStream_Cast(out__21).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](body__15, jrt.Prim_byte.ArrayClass())) }
							jrt.BufferedOutputStream_Cast(out__21).Flush__V()
//line :133:1
						L1: for { var status_line__23 any = lang.IFn_Cast(A_arbace_http_A_const_18.GetRawRoot__O()).Invoke_O__O(in__22); var ___24 any; _ = ___24






















							if lang.Util_Identical_O_O__Z(status_line__23, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_25))) } else { ___24 = nil }
//line :133:1
							var vec__1534000077__25 any = lang.IFn_Cast(A_arbace_http_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_http_A_const_85, status_line__23); var ___26 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(0), nil); var version__27 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(1), nil); var code__28 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(2), nil); var reason__29 any = lang.RT_Nth_O_I_O__O(vec__1534000077__25, lang.RT_IntCast_J__I(3), nil); var ___30 any; _ = ___26; _ = ___30

























							if jrt.J2g_Truth(version__27) { ___30 = nil } else { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_http_A_const_76.GetRawRoot__O()).Invoke_O__O(status_line__23)))))) }
//line :133:1
							var code__31 int32 = jrt.Integer_ParseInt_String__I(jrt.String_Cast(code__28)); var hs__32 any = lang.IFn_Cast(A_arbace_http_A_const_23.GetRawRoot__O()).Invoke_O__O(in__22); var tmp10 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_77.GetRawRoot__O()); var tmp12 any = A_arbace_http_A_const_86; var and__1927000168__auto____33 any = tmp11.Invoke_O_O_O__O(tmp12, jrt.Integer_ValueOf_I__Integer(code__31).Ref(), A_arbace_http_A_const_87)





























							if jrt.J2g_Truth(and__1927000168__auto____33) { tmp10 = lang.IFn_Cast(A_arbace_http_A_const_78.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(code__31).Ref(), A_arbace_http_A_const_88) } else { tmp10 = and__1927000168__auto____33 }; if jrt.J2g_Truth(tmp10) {
								continue L1 } else {
//line :163:1
									var b__33 any = jrt.ByteArrayOutputStream_New(); var te__34 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_20.GetRawRoot__O()); var tmp14 any; var or__1927000174__auto____34 any = lang.IFn_Cast(hs__32).Invoke_O__O(Lit_27)


									if jrt.J2g_Truth(or__1927000174__auto____34) { tmp14 = or__1927000174__auto____34 } else { tmp14 = Lit_16 }; te__34 = tmp13.Invoke_O__O(tmp14)
//line :163:1
									var cl__35 any = lang.IFn_Cast(hs__32).Invoke_O__O(Lit_28); var tmp15 any; var or__1927000174__auto____36 bool = lang.Util_Equiv_O_O__Z(method_name__16, Lit_29)





									if or__1927000174__auto____36 { tmp15 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____36).Ref() } else { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_77.GetRawRoot__O()); var tmp17 any = A_arbace_http_A_const_86; var or__1927000174__auto____37 any = tmp16.Invoke_O_O_O__O(tmp17, jrt.Integer_ValueOf_I__Integer(code__31).Ref(), A_arbace_http_A_const_91); if jrt.J2g_Truth(or__1927000174__auto____37) { tmp15 = or__1927000174__auto____37 } else { var or__1927000174__auto____38 bool = lang.Util_Equiv_J_J__Z(int64(code__31), 204); if or__1927000174__auto____38 { tmp15 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____38).Ref() } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(int64(code__31), 304)).Ref() } } }
//line :168:1
									if jrt.J2g_Truth(tmp15) { } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_http_A_const_36.GetRawRoot__O()).Invoke_O_O__O(te__34, Lit_30)) {

										lang.IFn_Cast(A_arbace_http_A_const_89.GetRawRoot__O()).Invoke_O_O__O(in__22, b__33) } else {
//line :168:1
											if jrt.J2g_Truth(cl__35) {


												lang.IFn_Cast(A_arbace_http_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(in__22, b__33, jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(lang.IFn_Cast(A_arbace_http_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_25.GetRawRoot__O()).Invoke_O_O__O(cl__35, A_arbace_http_A_const_92)))))).Ref()) } else {
//line :168:1
													if A_arbace_http_A_const_14 != nil {



														lang.IFn_Cast(A_arbace_http_A_const_90.GetRawRoot__O()).Invoke_O_O__O(in__22, b__33) } } } }
//line :163:1
									var tmp18 any = A_arbace_http_A_const_79; var tmp19 any = jrt.Integer_ValueOf_I__Integer(code__31).Ref(); var tmp20 any = A_arbace_http_A_const_80; var tmp21 any
									var or__1927000174__auto____36_2 any = reason__29









									if jrt.J2g_Truth(or__1927000174__auto____36_2) { tmp21 = or__1927000174__auto____36_2 } else { tmp21 = Lit_16 }
//line :163:1
									var tmp22 any = tmp21; var tmp23 any = A_arbace_http_A_const_65; var tmp24 any = A_arbace_http_A_const_66; var tmp25 any












									if lang.Util_Equiv_O_O__Z(as__11, A_arbace_http_A_const_81) {
										tmp25 = jrt.NN(jrt.ByteArrayOutputStream_Cast(b__33)).ToByteArray__B1().Ref() } else {
//line :176:1
											tmp25 = jrt.String_New_B1_Charset(jrt.NN(jrt.ByteArrayOutputStream_Cast(b__33)).ToByteArray__B1(), jrt.StandardCharsets_UTF_8) }
//line :163:1
									tmp9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, tmp20, tmp22, tmp23, hs__32, tmp24, tmp25)) }
//line :133:1
							break L1 } }; return nil }();














































	jrt.Socket_Cast(s__18).Close__V(); if /*line :133:1*/ tmp26 != nil { panic(tmp26) }; return tmp9 }










func A_arbace_http_request_fn__1534000075_A_New() *A_arbace_http_request_fn__1534000075_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_fn__1534000075_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_http_request_fn__1534000075_A) Ctor() {}
//line :144:1
func (t *A_arbace_http_request_fn__1534000075_A) Invoke_O_O__O(self, p1__1534000066_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_28, lang.IFn_Cast(A_arbace_http_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_http_A_const_42.GetRawRoot__O()).Invoke_O__O(p1__1534000066_SHARP___1)))).Ref() }


































type A_arbace_http_A struct{ jrt.Object }

var A_arbace_http_A_const_pool *jrt.RefArray

var A_arbace_http_A_const_0 *lang.Var

var A_arbace_http_A_const_1 *lang.Var

var A_arbace_http_A_const_2 any

var A_arbace_http_A_const_3 *lang.Keyword

var A_arbace_http_A_const_4 any

var A_arbace_http_A_const_5 any

var A_arbace_http_A_const_6 any

var A_arbace_http_A_const_7 *lang.Var

var A_arbace_http_A_const_8 *lang.Var

var A_arbace_http_A_const_9 *lang.Var

var A_arbace_http_A_const_10 any

var A_arbace_http_A_const_11 *lang.Var

var A_arbace_http_A_const_12 *lang.Var

var A_arbace_http_A_const_13 *lang.Var

var A_arbace_http_A_const_14 *lang.Keyword

var A_arbace_http_A_const_15 any

var A_arbace_http_A_const_16 any

var A_arbace_http_A_const_17 any

var A_arbace_http_A_const_18 *lang.Var

var A_arbace_http_A_const_19 *lang.Var

var A_arbace_http_A_const_20 *lang.Var

var A_arbace_http_A_const_21 *lang.Var

var A_arbace_http_A_const_22 *lang.Var

var A_arbace_http_A_const_23 *lang.Var

var A_arbace_http_A_const_24 *lang.Var

var A_arbace_http_A_const_25 *lang.Var

var A_arbace_http_A_const_26 any

var A_arbace_http_A_const_27 *lang.Var

var A_arbace_http_A_const_28 any

var A_arbace_http_A_const_29 any

var A_arbace_http_A_const_30 *lang.Var

var A_arbace_http_A_const_31 *lang.Var

var A_arbace_http_A_const_32 *lang.Var

var A_arbace_http_A_const_33 *lang.Keyword

var A_arbace_http_A_const_34 any

var A_arbace_http_A_const_35 *lang.Keyword

var A_arbace_http_A_const_36 *lang.Var

var A_arbace_http_A_const_37 *lang.Var

var A_arbace_http_A_const_38 *lang.Var

var A_arbace_http_A_const_39 *lang.Var

var A_arbace_http_A_const_40 *lang.Var

var A_arbace_http_A_const_41 *lang.Var

var A_arbace_http_A_const_42 *lang.Var

var A_arbace_http_A_const_43 *lang.Var

var A_arbace_http_A_const_44 any

var A_arbace_http_A_const_45 *lang.Var

var A_arbace_http_A_const_46 *lang.Var

var A_arbace_http_A_const_47 *lang.Var

var A_arbace_http_A_const_48 *lang.Var

var A_arbace_http_A_const_49 *lang.Var

var A_arbace_http_A_const_50 *lang.Var

var A_arbace_http_A_const_51 *lang.Var

var A_arbace_http_A_const_52 *lang.Var

var A_arbace_http_A_const_53 *lang.Var

var A_arbace_http_A_const_54 *lang.Var

var A_arbace_http_A_const_55 *lang.Var

var A_arbace_http_A_const_56 *lang.Var

var A_arbace_http_A_const_57 *lang.Var

var A_arbace_http_A_const_58 *lang.Var

var A_arbace_http_A_const_59 *lang.Keyword

var A_arbace_http_A_const_60 *lang.Keyword

var A_arbace_http_A_const_61 *lang.Var

var A_arbace_http_A_const_62 *lang.Var

var A_arbace_http_A_const_63 *lang.Keyword

var A_arbace_http_A_const_64 *lang.Keyword

var A_arbace_http_A_const_65 *lang.Keyword

var A_arbace_http_A_const_66 *lang.Keyword

var A_arbace_http_A_const_67 *lang.Keyword

var A_arbace_http_A_const_68 *lang.Keyword

var A_arbace_http_A_const_69 *lang.Var

var A_arbace_http_A_const_70 *lang.Var

var A_arbace_http_A_const_71 *lang.Var

var A_arbace_http_A_const_72 any

var A_arbace_http_A_const_73 *lang.Var

var A_arbace_http_A_const_74 *lang.Var

var A_arbace_http_A_const_75 *lang.Var

var A_arbace_http_A_const_76 *lang.Var

var A_arbace_http_A_const_77 *lang.Var

var A_arbace_http_A_const_78 *lang.Var

var A_arbace_http_A_const_79 *lang.Keyword

var A_arbace_http_A_const_80 *lang.Keyword

var A_arbace_http_A_const_81 *lang.Keyword

var A_arbace_http_A_const_82 *lang.Var

var A_arbace_http_A_const_83 *lang.Var

var A_arbace_http_A_const_84 *lang.Var

var A_arbace_http_A_const_85 any

var A_arbace_http_A_const_86 any

var A_arbace_http_A_const_87 any

var A_arbace_http_A_const_88 any

var A_arbace_http_A_const_89 *lang.Var

var A_arbace_http_A_const_90 *lang.Var

var A_arbace_http_A_const_91 any

var A_arbace_http_A_const_92 any

var A_arbace_http_A_init jrt.ClassInit

func A_arbace_http_A_Init() { if !A_arbace_http_A_init.Done() { A_arbace_http_A_init.Run(A_arbace_http_A_clinit) } }

func A_arbace_http_A_clinit() { A_arbace_http_A_clinit_p0(); A_arbace_http_A_clinit_p1(); A_arbace_http_A_clinit_p2(); A_arbace_http_A_clinit_p3(); A_arbace_http_A_clinit_p4(); A_arbace_http_A_clinit_p5(); A_arbace_http_A_clinit_p6(); A_arbace_http_A_clinit_p7() }

func A_arbace_http_A_clinit_p0() { A_arbace_http_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 115); A_arbace_http_A_const_0 = lang.Var_Cast(A_arbace_http_A_const_pool.A[22]); A_arbace_http_A_const_1 = lang.Var_Cast(A_arbace_http_A_const_pool.A[23]); A_arbace_http_A_const_2 = A_arbace_http_A_const_pool.A[24]; A_arbace_http_A_const_3 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[25]); A_arbace_http_A_const_4 = A_arbace_http_A_const_pool.A[26]; A_arbace_http_A_const_5 = A_arbace_http_A_const_pool.A[27]; A_arbace_http_A_const_6 = A_arbace_http_A_const_pool.A[28]; A_arbace_http_A_const_7 = lang.Var_Cast(A_arbace_http_A_const_pool.A[29]); A_arbace_http_A_const_8 = lang.Var_Cast(A_arbace_http_A_const_pool.A[30]); A_arbace_http_A_const_9 = lang.Var_Cast(A_arbace_http_A_const_pool.A[31]); A_arbace_http_A_const_10 = A_arbace_http_A_const_pool.A[32]; A_arbace_http_A_const_11 = lang.Var_Cast(A_arbace_http_A_const_pool.A[33]) }

func A_arbace_http_A_clinit_p1() { A_arbace_http_A_const_12 = lang.Var_Cast(A_arbace_http_A_const_pool.A[34]); A_arbace_http_A_const_13 = lang.Var_Cast(A_arbace_http_A_const_pool.A[35]); A_arbace_http_A_const_14 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[36]); A_arbace_http_A_const_15 = A_arbace_http_A_const_pool.A[37]; A_arbace_http_A_const_16 = A_arbace_http_A_const_pool.A[38]; A_arbace_http_A_const_17 = A_arbace_http_A_const_pool.A[39]; A_arbace_http_A_const_18 = lang.Var_Cast(A_arbace_http_A_const_pool.A[40]); A_arbace_http_A_const_19 = lang.Var_Cast(A_arbace_http_A_const_pool.A[41]); A_arbace_http_A_const_20 = lang.Var_Cast(A_arbace_http_A_const_pool.A[42]); A_arbace_http_A_const_21 = lang.Var_Cast(A_arbace_http_A_const_pool.A[43]); A_arbace_http_A_const_22 = lang.Var_Cast(A_arbace_http_A_const_pool.A[44]); A_arbace_http_A_const_23 = lang.Var_Cast(A_arbace_http_A_const_pool.A[45]) }

func A_arbace_http_A_clinit_p2() { A_arbace_http_A_const_24 = lang.Var_Cast(A_arbace_http_A_const_pool.A[46]); A_arbace_http_A_const_25 = lang.Var_Cast(A_arbace_http_A_const_pool.A[47]); A_arbace_http_A_const_26 = A_arbace_http_A_const_pool.A[48]; A_arbace_http_A_const_27 = lang.Var_Cast(A_arbace_http_A_const_pool.A[49]); A_arbace_http_A_const_28 = A_arbace_http_A_const_pool.A[50]; A_arbace_http_A_const_29 = A_arbace_http_A_const_pool.A[51]; A_arbace_http_A_const_30 = lang.Var_Cast(A_arbace_http_A_const_pool.A[52]); A_arbace_http_A_const_31 = lang.Var_Cast(A_arbace_http_A_const_pool.A[53]); A_arbace_http_A_const_32 = lang.Var_Cast(A_arbace_http_A_const_pool.A[54]); A_arbace_http_A_const_33 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[55]); A_arbace_http_A_const_34 = A_arbace_http_A_const_pool.A[56]; A_arbace_http_A_const_35 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[57]); A_arbace_http_A_const_36 = lang.Var_Cast(A_arbace_http_A_const_pool.A[58]) }

func A_arbace_http_A_clinit_p3() { A_arbace_http_A_const_37 = lang.Var_Cast(A_arbace_http_A_const_pool.A[59]); A_arbace_http_A_const_38 = lang.Var_Cast(A_arbace_http_A_const_pool.A[60]); A_arbace_http_A_const_39 = lang.Var_Cast(A_arbace_http_A_const_pool.A[61]); A_arbace_http_A_const_40 = lang.Var_Cast(A_arbace_http_A_const_pool.A[62]); A_arbace_http_A_const_41 = lang.Var_Cast(A_arbace_http_A_const_pool.A[63]); A_arbace_http_A_const_42 = lang.Var_Cast(A_arbace_http_A_const_pool.A[64]); A_arbace_http_A_const_43 = lang.Var_Cast(A_arbace_http_A_const_pool.A[65]); A_arbace_http_A_const_44 = A_arbace_http_A_const_pool.A[66]; A_arbace_http_A_const_45 = lang.Var_Cast(A_arbace_http_A_const_pool.A[67]); A_arbace_http_A_const_46 = lang.Var_Cast(A_arbace_http_A_const_pool.A[68]); A_arbace_http_A_const_47 = lang.Var_Cast(A_arbace_http_A_const_pool.A[69]); A_arbace_http_A_const_48 = lang.Var_Cast(A_arbace_http_A_const_pool.A[70]) }

func A_arbace_http_A_clinit_p4() { A_arbace_http_A_const_49 = lang.Var_Cast(A_arbace_http_A_const_pool.A[71]); A_arbace_http_A_const_50 = lang.Var_Cast(A_arbace_http_A_const_pool.A[72]); A_arbace_http_A_const_51 = lang.Var_Cast(A_arbace_http_A_const_pool.A[73]); A_arbace_http_A_const_52 = lang.Var_Cast(A_arbace_http_A_const_pool.A[74]); A_arbace_http_A_const_53 = lang.Var_Cast(A_arbace_http_A_const_pool.A[75]); A_arbace_http_A_const_54 = lang.Var_Cast(A_arbace_http_A_const_pool.A[76]); A_arbace_http_A_const_55 = lang.Var_Cast(A_arbace_http_A_const_pool.A[77]); A_arbace_http_A_const_56 = lang.Var_Cast(A_arbace_http_A_const_pool.A[78]); A_arbace_http_A_const_57 = lang.Var_Cast(A_arbace_http_A_const_pool.A[79]); A_arbace_http_A_const_58 = lang.Var_Cast(A_arbace_http_A_const_pool.A[80]); A_arbace_http_A_const_59 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[81]); A_arbace_http_A_const_60 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[82]) }

func A_arbace_http_A_clinit_p5() { A_arbace_http_A_const_61 = lang.Var_Cast(A_arbace_http_A_const_pool.A[83]); A_arbace_http_A_const_62 = lang.Var_Cast(A_arbace_http_A_const_pool.A[84]); A_arbace_http_A_const_63 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[85]); A_arbace_http_A_const_64 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[86]); A_arbace_http_A_const_65 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[87]); A_arbace_http_A_const_66 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[88]); A_arbace_http_A_const_67 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[89]); A_arbace_http_A_const_68 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[90]); A_arbace_http_A_const_69 = lang.Var_Cast(A_arbace_http_A_const_pool.A[91]); A_arbace_http_A_const_70 = lang.Var_Cast(A_arbace_http_A_const_pool.A[92]); A_arbace_http_A_const_71 = lang.Var_Cast(A_arbace_http_A_const_pool.A[93]); A_arbace_http_A_const_72 = A_arbace_http_A_const_pool.A[94] }

func A_arbace_http_A_clinit_p6() { A_arbace_http_A_const_73 = lang.Var_Cast(A_arbace_http_A_const_pool.A[95]); A_arbace_http_A_const_74 = lang.Var_Cast(A_arbace_http_A_const_pool.A[96]); A_arbace_http_A_const_75 = lang.Var_Cast(A_arbace_http_A_const_pool.A[97]); A_arbace_http_A_const_76 = lang.Var_Cast(A_arbace_http_A_const_pool.A[98]); A_arbace_http_A_const_77 = lang.Var_Cast(A_arbace_http_A_const_pool.A[99]); A_arbace_http_A_const_78 = lang.Var_Cast(A_arbace_http_A_const_pool.A[100]); A_arbace_http_A_const_79 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[101]); A_arbace_http_A_const_80 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[102]); A_arbace_http_A_const_81 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[103]); A_arbace_http_A_const_82 = lang.Var_Cast(A_arbace_http_A_const_pool.A[104]); A_arbace_http_A_const_83 = lang.Var_Cast(A_arbace_http_A_const_pool.A[105]); A_arbace_http_A_const_84 = lang.Var_Cast(A_arbace_http_A_const_pool.A[106]) }

func A_arbace_http_A_clinit_p7() { A_arbace_http_A_const_85 = A_arbace_http_A_const_pool.A[107]; A_arbace_http_A_const_86 = A_arbace_http_A_const_pool.A[108]; A_arbace_http_A_const_87 = A_arbace_http_A_const_pool.A[109]; A_arbace_http_A_const_88 = A_arbace_http_A_const_pool.A[110]; A_arbace_http_A_const_89 = lang.Var_Cast(A_arbace_http_A_const_pool.A[111]); A_arbace_http_A_const_90 = lang.Var_Cast(A_arbace_http_A_const_pool.A[112]); A_arbace_http_A_const_91 = A_arbace_http_A_const_pool.A[113]; A_arbace_http_A_const_92 = A_arbace_http_A_const_pool.A[114] }

func A_arbace_http_A_New() *A_arbace_http_A { A_arbace_http_A_Init(); t := &A_arbace_http_A{}; t.Ctor(); return t }

func (t *A_arbace_http_A) Ctor() {}

func (t *A_arbace_http_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_A) GetClass__Class() *jrt.Class { return A_arbace_http_A_class }

func (t *A_arbace_http_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_http_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_A); return ok }

func A_arbace_http_A_Cast(x any) *A_arbace_http_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_A_class)) }; return v }



type A_arbace_http_default_port_A struct{ j2g_header uint64 }

var A_arbace_http_default_port_A_fn_class *jrt.Class



type A_arbace_http_eval1534000004_A struct{ jrt.Object }

func A_arbace_http_eval1534000004_A_New() *A_arbace_http_eval1534000004_A { t := &A_arbace_http_eval1534000004_A{}; t.Ctor(); return t }

func (t *A_arbace_http_eval1534000004_A) Ctor() {}

func (t *A_arbace_http_eval1534000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000004_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000004_A_class }

func (t *A_arbace_http_eval1534000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000004_A); return ok }

func A_arbace_http_eval1534000004_A_Cast(x any) *A_arbace_http_eval1534000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000004_A_class)) }; return v }



type A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A struct{ j2g_header uint64 }

var A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_fn_class *jrt.Class



type A_arbace_http_eval1534000008_A struct{ jrt.Object }

func A_arbace_http_eval1534000008_A_New() *A_arbace_http_eval1534000008_A { t := &A_arbace_http_eval1534000008_A{}; t.Ctor(); return t }

func (t *A_arbace_http_eval1534000008_A) Ctor() {}

func (t *A_arbace_http_eval1534000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000008_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000008_A_class }

func (t *A_arbace_http_eval1534000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000008_A); return ok }

func A_arbace_http_eval1534000008_A_Cast(x any) *A_arbace_http_eval1534000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000008_A_class)) }; return v }



type A_arbace_http_eval1534000008_fn__1534000009_A struct{ j2g_header uint64 }

var A_arbace_http_eval1534000008_fn__1534000009_A_fn_class *jrt.Class



type A_arbace_http_latin1_A struct{ j2g_header uint64 }

var A_arbace_http_latin1_A_fn_class *jrt.Class



type A_arbace_http_open_A struct{ j2g_header uint64 }

var A_arbace_http_open_A_fn_class *jrt.Class



type A_arbace_http_read_all_A struct{ j2g_header uint64 }

var A_arbace_http_read_all_A_fn_class *jrt.Class



type A_arbace_http_read_chunked_A struct{ j2g_header uint64 }

var A_arbace_http_read_chunked_A_fn_class *jrt.Class



type A_arbace_http_read_headers_A struct{ j2g_header uint64 }

var A_arbace_http_read_headers_A_fn_class *jrt.Class



type A_arbace_http_read_line_STAR__A struct{ j2g_header uint64 }

var A_arbace_http_read_line_STAR__A_fn_class *jrt.Class



type A_arbace_http_read_n_A struct{ j2g_header uint64 }

var A_arbace_http_read_n_A_fn_class *jrt.Class



type A_arbace_http_request_A struct{ j2g_header uint64 }

var A_arbace_http_request_A_fn_class *jrt.Class



type A_arbace_http_request_fn__1534000075_A struct{ j2g_header uint64 }

var A_arbace_http_request_fn__1534000075_A_fn_class *jrt.Class



type A_arbace_http_request_head_A struct{ j2g_header uint64 }

var A_arbace_http_request_head_A_fn_class *jrt.Class



type A_arbace_http_request_head_fn__1534000022_A struct{ j2g_header uint64 }

var A_arbace_http_request_head_fn__1534000022_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000027__1534000031_A struct{ j2g_header uint64; F_given any }

var A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A struct{ j2g_header uint64; F_iter__1534000027, F_given, F_s__1534000028 any }

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A struct{ j2g_header uint64; F_given any; F_size__1927001038__auto__ int32; F_b__1534000030, F_c__1927001037__auto__ any }

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000043__1534000047_A struct{ j2g_header uint64 }

var A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A struct{ j2g_header uint64; F_s__1534000044, F_iter__1534000043 any }

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A struct{ j2g_header uint64; F_b__1534000046 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class *jrt.Class
