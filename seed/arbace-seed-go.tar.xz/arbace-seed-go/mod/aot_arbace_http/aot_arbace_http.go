//line aot_arbace_http.ae:1
package aot_arbace_http

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/aot_arbace_tls"
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_New() *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A { A_arbace_http_A_Init(); t := &A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_http_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_http_A_const_1, A_arbace_http_A_const_2, A_arbace_http_A_const_3); lang.IFn_Cast(A_arbace_http_A_const_4.GetRawRoot__O()).Invoke_O_O__O(A_arbace_http_A_const_5, A_arbace_http_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :3:1
func A_arbace_http_eval1534000008_fn__1534000009_A_New() *A_arbace_http_eval1534000008_fn__1534000009_A { A_arbace_http_A_Init(); t := &A_arbace_http_eval1534000008_fn__1534000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_http_eval1534000008_fn__1534000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_http_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_http_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_http_A_const_10.GetRawRoot__O(), A_arbace_http_A_const_11) }


































func A_arbace_http_latin1_A_New() *A_arbace_http_latin1_A { A_arbace_http_A_Init(); t := &A_arbace_http_latin1_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_http_latin1_A) Ctor() {}
//line :38:1
func (t *A_arbace_http_latin1_A) Invoke_O_O__O(self, s__0 any) any { return jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_ISO_8859_1).Ref() }

func A_arbace_http_read_line_STAR__A_New() *A_arbace_http_read_line_STAR__A { A_arbace_http_A_Init(); t := &A_arbace_http_read_line_STAR__A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_http_read_line_STAR__A) Ctor() {}
//line :40:1
func (t *A_arbace_http_read_line_STAR__A) Invoke_O_O__O(self, in__0 any) any { { var b__2 any = jrt.ByteArrayOutputStream_New(); L1: for { var c__3 int32 = jrt.InputStream_Cast(in__0).Read__I()





	if lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__3), -1) {
		if lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.ByteArrayOutputStream_Cast(b__2).Size__I())) { return jrt.String_New_B1_Charset(jrt.ByteArrayOutputStream_Cast(b__2).ToByteArray__B1(), jrt.StandardCharsets_ISO_8859_1) } else { return nil } } else {
//line :46:1
			if lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__3), 10) { var s__4 any = jrt.String_New_B1_Charset(jrt.ByteArrayOutputStream_Cast(b__2).ToByteArray__B1(), jrt.StandardCharsets_ISO_8859_1); var tmp1 any; var root_22 any = A_arbace_http_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_24 lang.IFn


				if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = s__4; var arg_26 any = Lit_19; if linked_23 == nil { tmp1 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { tmp1 = linked_23.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; if jrt.J2g_Truth(tmp1) { var root_27 any = A_arbace_http_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = s__4; var arg_31 any = A_arbace_http_A_const_14; var arg_32 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(s__4)))).Ref(); if linked_28 == nil { return ifn_29.Invoke_O_O_O__O(arg_30, arg_31, arg_32) } else { return linked_28.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_27, arg_30, arg_31, arg_32) } } else { return s__4 } } else {
//line :46:1
					if A_arbace_http_A_const_15 != nil {



						jrt.ByteArrayOutputStream_Cast(b__2).Write_I__V(c__3); continue L1 } else {
//line :46:1
							return nil } } } } }; /*line :40:1*/panic("j2g: unreachable") }











func A_arbace_http_read_n_A_New() *A_arbace_http_read_n_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_n_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_http_read_n_A) Ctor() {}
//line :52:1
func (t *A_arbace_http_read_n_A) InvokePrim_O_O_O_J__O(self, in__0, out__1 any, n__2 int64) any { { var buf__4 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_http_A_const_16).Ref(); var left__5 int64 = n__2; L1: for {




	if lang.Numbers_IsPos_J__Z_NoInit(left__5) { var k__6 int32 = jrt.InputStream_Cast(in__0).Read_B1_I_I__I(jrt.ByteArray_Cast(buf__4), lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Min_J_J__J_NoInit(left__5, 65536)))

		if lang.Numbers_IsNeg_J__Z_NoInit(int64(k__6)) { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_21), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(left__5).Ref(), nil)))))
		}
		jrt.OutputStream_Cast(out__1).Write_B1_I_I__V(jrt.ByteArray_Cast(buf__4), lang.RT_IntCast_J__I_NoInit(0), k__6)
		left__5 = lang.Numbers_Minus_J_J__J_NoInit(left__5, int64(k__6)); continue L1 } else {
//line :57:1
			return nil } } }; /*line :52:1*/panic("j2g: unreachable") }
//line :52:1
func (t *A_arbace_http_read_n_A) Invoke_O_O_O_O__O(self, in__0, out__1, p_n__2 any) any { return t.InvokePrim_O_O_O_J__O(self, in__0, out__1, lang.RT_LongCast_O__J_NoInit(p_n__2)) }











func A_arbace_http_read_all_A_New() *A_arbace_http_read_all_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_all_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_http_read_all_A) Ctor() {}
//line :64:1
func (t *A_arbace_http_read_all_A) Invoke_O_O_O__O(self, in__0, out__1 any) any { { var buf__3 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_http_A_const_17).Ref(); L1: for { var k__4 int32 = jrt.InputStream_Cast(in__0).Read_B1__I(jrt.ByteArray_Cast(buf__3))



	if lang.Numbers_IsNeg_J__Z_NoInit(int64(k__4)) { return nil } else {
		jrt.OutputStream_Cast(out__1).Write_B1_I_I__V(jrt.ByteArray_Cast(buf__3), lang.RT_IntCast_J__I_NoInit(0), k__4)
		continue L1 } } }; /*line :64:1*/panic("j2g: unreachable") }







func A_arbace_http_read_headers_A_New() *A_arbace_http_read_headers_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_headers_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_http_read_headers_A) Ctor() {}
//line :72:1
func (t *A_arbace_http_read_headers_A) Invoke_O_O__O(self, in__0 any) any { { var h__2 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var line__3 any; var root_33 any = A_arbace_http_A_const_18.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_http_read_line_STAR__A_fn_class); var ifn_35 lang.IFn



	if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = in__0; if linked_34 == nil { line__3 = ifn_35.Invoke_O__O(arg_36) } else { line__3 = linked_34.(*A_arbace_http_read_line_STAR__A).Invoke_O_O__O(root_33, arg_36) }
	if lang.Util_Identical_O_O__Z_NoInit(line__3, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_15))) } else { if lang.Util_Equiv_O_O__Z_NoInit(line__3, Lit_16) { return h__2 } else { if A_arbace_http_A_const_15 != nil { var i__4 any; var root_37 any = A_arbace_http_A_const_19.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_39 lang.IFn


		if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = line__3; var arg_41 any = Lit_17; if linked_38 == nil { i__4 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { i__4 = linked_38.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) }
		if lang.Util_Identical_O_O__Z_NoInit(i__4, nil) {
			h__2 = h__2; continue L1 } else {
//line :81:1
				var k__5 any; var root_42 any = A_arbace_http_A_const_20.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_44 lang.IFn

				if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any; var root_46 any = A_arbace_http_A_const_21.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var root_50 any = A_arbace_http_A_const_13.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = line__3; var arg_54 any = A_arbace_http_A_const_14; var arg_55 any = i__4; if linked_51 == nil { arg_49 = ifn_52.Invoke_O_O_O__O(arg_53, arg_54, arg_55) } else { arg_49 = linked_51.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_50, arg_53, arg_54, arg_55) }; if linked_47 == nil { arg_45 = ifn_48.Invoke_O__O(arg_49) } else { arg_45 = linked_47.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_46, arg_49) }; if linked_43 == nil { k__5 = ifn_44.Invoke_O__O(arg_45) } else { k__5 = linked_43.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_42, arg_45) }
//line :81:1
				var v__6 any; var root_56 any = A_arbace_http_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_58 lang.IFn


				if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any; var root_60 any = A_arbace_http_A_const_13.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = line__3; var arg_64 any; var na_65 any = i__4; if jrt.Long_InstanceOf(na_65) { var n0_66 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); if n0_66 == 9223372036854775807 { arg_64 = lang.Numbers_Inc_O__Number_NoInit(na_65) } else { arg_64 = jrt.Long_ValueOf_J__Long_NoInit(n0_66 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_65) { var n0_66_2 float64 = jrt.NN(jrt.Double_Cast(na_65)).DoubleValue__D(); arg_64 = jrt.Double_ValueOf_D__Double_NoInit(n0_66_2 + 1.0).Ref() } else { arg_64 = lang.Numbers_Inc_O__Number_NoInit(na_65) } }; if linked_61 == nil { arg_59 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { arg_59 = linked_61.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; if linked_57 == nil { v__6 = ifn_58.Invoke_O__O(arg_59) } else { v__6 = linked_57.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_56, arg_59) }
				var tmp1 any; var root_67 any = A_arbace_http_A_const_22.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = h__2; var arg_71 any = k__5; var arg_72 any; var temp__1927000408__auto____7 any = lang.IFn_Cast(h__2).Invoke_O__O(k__5); if jrt.J2g_Truth(temp__1927000408__auto____7) { var old__8 any = temp__1927000408__auto____7; arg_72 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, old__8, nil, v__6)).Ref() } else { arg_72 = v__6 }; if linked_68 == nil { tmp1 = ifn_69.Invoke_O_O_O__O(arg_70, arg_71, arg_72) } else { tmp1 = linked_68.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_67, arg_70, arg_71, arg_72) }; h__2 = tmp1; continue L1 } } else {
//line :77:1
					return nil } } } } }; /*line :72:1*/panic("j2g: unreachable") }














func A_arbace_http_read_chunked_A_New() *A_arbace_http_read_chunked_A { A_arbace_http_A_Init(); t := &A_arbace_http_read_chunked_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_http_read_chunked_A) Ctor() {}
//line :87:1
func (t *A_arbace_http_read_chunked_A) Invoke_O_O_O__O(self, in__0, out__1 any) any { L1: for { var line__3 any; var root_73 any = A_arbace_http_A_const_18.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_http_read_line_STAR__A_fn_class); var ifn_75 lang.IFn

	if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = in__0; if linked_74 == nil { line__3 = ifn_75.Invoke_O__O(arg_76) } else { line__3 = linked_74.(*A_arbace_http_read_line_STAR__A).Invoke_O_O__O(root_73, arg_76) }
//line :87:1
	var ___4 any; _ = ___4


	if lang.Util_Identical_O_O__Z_NoInit(line__3, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_14))) } else { ___4 = nil }
//line :87:1
	var size__5 int64; var tmp1 any; var root_77 any = A_arbace_http_A_const_21.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_79 lang.IFn



	if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var root_81 any = A_arbace_http_A_const_23.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var root_85 any = A_arbace_http_A_const_24.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = line__3; var arg_89 any = A_arbace_http_A_const_25; if linked_86 == nil { arg_84 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { arg_84 = linked_86.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if linked_82 == nil { arg_80 = ifn_83.Invoke_O__O(arg_84) } else { arg_80 = linked_82.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_81, arg_84) }; if linked_78 == nil { tmp1 = ifn_79.Invoke_O__O(arg_80) } else { tmp1 = linked_78.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_77, arg_80) }; size__5 = jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp1), lang.RT_IntCast_J__I_NoInit(16))
	if lang.Numbers_IsZero_J__Z_NoInit(size__5) {
		var root_90 any = A_arbace_http_A_const_26.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, A_arbace_http_read_headers_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = in__0; if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*A_arbace_http_read_headers_A).Invoke_O_O__O(root_90, arg_93) } } else {
			var root_94 any = A_arbace_http_A_const_27.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_94, A_arbace_http_read_n_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = in__0; var arg_98 any = out__1; var arg_99 int64 = size__5; if linked_95 == nil { ifn_96.Invoke_O_O_O__O(arg_97, arg_98, jrt.Long_ValueOf_J__Long_NoInit(arg_99).Ref()) } else { linked_95.(*A_arbace_http_read_n_A).InvokePrim_O_O_O_J__O(root_94, arg_97, arg_98, arg_99) }
			var root_100 any = A_arbace_http_A_const_18.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_http_read_line_STAR__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = in__0; if linked_101 == nil { ifn_102.Invoke_O__O(arg_103) } else { linked_101.(*A_arbace_http_read_line_STAR__A).Invoke_O_O__O(root_100, arg_103) }
			continue L1 } }; /*line :87:1*/panic("j2g: unreachable") }










func A_arbace_http_default_port_A_New() *A_arbace_http_default_port_A { A_arbace_http_A_Init(); t := &A_arbace_http_default_port_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_http_default_port_A) Ctor() {}
//line :98:1
func (t *A_arbace_http_default_port_A) Invoke_O_O__O(self, scheme__0 any) any { if lang.Util_Equiv_O_O__Z_NoInit(scheme__0, Lit_1) { return A_arbace_http_A_const_28 } else { return A_arbace_http_A_const_29 } }

func A_arbace_http_open_A_New() *A_arbace_http_open_A { A_arbace_http_A_Init(); t := &A_arbace_http_open_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_http_open_A) Ctor() {}
//line :100:1
func (t *A_arbace_http_open_A) Invoke_O_O_O_O__O(self, uri__0, timeout__1, tls_opts__2 any) any { var scheme__4 any; var root_104 any = A_arbace_http_A_const_20.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_106 lang.IFn; if


	linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = jrt.NN(jrt.URI_Cast(uri__0)).GetScheme__String().Ref(); if linked_105 == nil { scheme__4 = ifn_106.Invoke_O__O(arg_107) } else { scheme__4 = linked_105.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_104, arg_107) }; var host__5 any = /*line :100:1*/jrt.NN(jrt.URI_Cast(uri__0)).GetHost__String().Ref(); var port__6 any; var p__6 int32 = jrt.NN(jrt.URI_Cast(uri__0)).GetPort__I(); if




	lang.Numbers_IsNeg_J__Z_NoInit(int64(p__6)) { var root_108 any = A_arbace_http_A_const_30.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_http_default_port_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = scheme__4; if linked_109 == nil { port__6 = ifn_110.Invoke_O__O(arg_111) } else { port__6 = linked_109.(*A_arbace_http_default_port_A).Invoke_O_O__O(root_108, arg_111) } } else { port__6 = jrt.Integer_ValueOf_I__Integer_NoInit(p__6).Ref() }; var G__1534000019__7_ any = scheme__4; switch
	lang.Util_Hash_O__I_NoInit(G__1534000019__7_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1534000019__7_, Lit_12) { var s__8 any = jrt.Socket_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		jrt.Socket_Cast(s__8).Connect_SocketAddress_I__V(jrt.InetSocketAddress_New_String_I(jrt.String_Cast(host__5), lang.RT_IntCast_O__I_NoInit(port__6)), lang.RT_IntCast_O__I_NoInit(timeout__1))
//line :106:1
		tmp1 = s__8; return nil }(); if tmp2 != nil { if true { var t__11 jrt.Throwable_I = tmp2





			jrt.Socket_Cast(s__8).Close__V()
//line :106:1
			panic(jrt.Thrown(t__11)) } }; return tmp1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1534000019__7_, Lit_1) {
				var root_113 any = A_arbace_http_A_const_31.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_tls.A_arbace_tls_connect_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = host__5; var arg_117 any = port__6; var arg_118 any; var root_119 any = A_arbace_http_A_const_32.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_http_A_const_33, A_arbace_http_A_const_34, A_arbace_http_A_const_35, timeout__1)); var arg_123 any = tls_opts__2; if linked_120 == nil { arg_118 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { arg_118 = linked_120.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; if linked_114 == nil { return ifn_115.Invoke_O_O_O__O(arg_116, arg_117, arg_118) } else { return linked_114.(*aot_arbace_tls.A_arbace_tls_connect_A).Invoke_O_O_O_O__O(root_113, arg_116, arg_117, arg_118) } }
//line :106:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, uri__0))))) }








func A_arbace_http_request_head_A_New() *A_arbace_http_request_head_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_http_request_head_A) Ctor() {}
//line :115:1
func (t *A_arbace_http_request_head_A) Invoke_O_O_O_O__O(self, method__0, uri__1, headers__2 any) any { var scheme__4 any; var root_124 any = A_arbace_http_A_const_20.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_126 lang.IFn; if


	linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = jrt.NN(jrt.URI_Cast(uri__1)).GetScheme__String().Ref(); if linked_125 == nil { scheme__4 = ifn_126.Invoke_O__O(arg_127) } else { scheme__4 = linked_125.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_124, arg_127) }; var p__5 int32 = /*line :115:1*/jrt.NN(jrt.URI_Cast(uri__1)).GetPort__I(); var host__6 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var h__8 any = jrt.NN(jrt.URI_Cast(uri__1)).GetHost__String().Ref(); var tmp3 any; var root_128 any = A_arbace_http_A_const_36.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_130 lang.IFn; if




	linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = h__8; var arg_132 any = Lit_17; if linked_129 == nil { tmp3 = ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { tmp3 = linked_129.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_128, arg_131, arg_132) }; if jrt.J2g_Truth(tmp3) { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_32), jrt.RefArrayOf(jrt.Object_class, nil, h__8, nil)).Ref() } else { tmp2 = h__8 }; var tmp4 any = tmp2; var tmp5 *jrt.String; var tmp6 bool; var or__1927000174__auto____8 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(p__5)); if or__1927000174__auto____8 {
		tmp6 = or__1927000174__auto____8 } else { var tmp7 int64 = int64(p__5); var tmp8 any; var root_133 any = A_arbace_http_A_const_30.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_http_default_port_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = scheme__4; if linked_134 == nil { tmp8 = ifn_135.Invoke_O__O(arg_136) } else { tmp8 = linked_134.(*A_arbace_http_default_port_A).Invoke_O_O__O(root_133, arg_136) }; tmp6 = lang.Util_Equiv_J_O__Z_NoInit(tmp7, tmp8) }; if tmp6 { tmp5 = nil } else { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(p__5).Ref())) }; host__6 = /*line :120:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref())).Ref(); var target__7 any; var tmp9 /*line :115:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp10 any; var path__9 any = jrt.NN(jrt.URI_Cast(uri__1)).GetRawPath__String().Ref(); var tmp11 any; var root_137 any = A_arbace_http_A_const_37.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_139 lang.IFn; if






	linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = path__9; if linked_138 == nil { tmp11 = ifn_139.Invoke_O__O(arg_140) } else { tmp11 = linked_138.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(tmp11) { tmp10 = Lit_33 } else { tmp10 = path__9 }; var tmp12 any = tmp10; var tmp13 *jrt.String; var temp__1927000414__auto____9 any = jrt.NN(jrt.URI_Cast(uri__1)).GetRawQuery__String().Ref(); if
	jrt.J2g_Truth(temp__1927000414__auto____9) { var q__10 any = temp__1927000414__auto____9; tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, q__10)) } else { tmp13 = nil }; target__7 = /*line :122:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13.Ref())).Ref(); var given__8 any; var root_141 any = /*line :115:1*/A_arbace_http_A_const_38.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_143 lang.IFn; if








	linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_145 any; var root_147 any = A_arbace_http_A_const_39.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var fnbody__168 any = A_arbace_http_request_head_fn__1534000022_A_New(); var tmp14 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_http_request_head_fn__1534000022_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_http_request_head_fn__1534000022_A_fn_class = fncls__167d; tmp14 = fncls__167d } else { tmp14 = fncls__167 }; arg_150 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp14, nil); if linked_148 == nil { arg_145 = ifn_149.Invoke_O__O(arg_150) } else { arg_145 = linked_148.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_147, arg_150) }; var arg_146 any = headers__2; if linked_142 == nil { given__8 = ifn_143.Invoke_O_O_O__O(arg_144, arg_145, arg_146) } else { given__8 = linked_142.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_141, arg_144, arg_145, arg_146) }; var defaults__9 any; var tmp15 any = /*line :115:1*/lang.Tuple_Create_O_O_O__IPersistentVector(Lit_36, Lit_37, host__6); var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_40, nil); var tmp17 any; var root_326 any = A_arbace_http_A_const_58.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_arbace_version_A_fn_class); var ifn_328 lang.IFn; if










	linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; if linked_327 == nil { tmp17 = ifn_328.Invoke__O() } else { tmp17 = linked_327.(*aot_arbace_core.A_arbace_core_arbace_version_A).Invoke_O__O(root_326) }; defaults__9 = /*line :115:1*/lang.Tuple_Create_O_O_O__IPersistentVector(tmp15, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_38, Lit_39, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref()), A_arbace_http_A_const_57); var tmp18 /*line :128:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_41, nil, Lit_42, nil, nil, Lit_43); var tmp19 any; var root_169 any = A_arbace_http_A_const_42.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_string.A_arbace_string_upper_case_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any; var root_173 any = A_arbace_http_A_const_40.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = method__0; if linked_174 == nil { arg_172 = ifn_175.Invoke_O__O(arg_176) } else { arg_172 = linked_174.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_173, arg_176) }; if linked_170 == nil { tmp19 = ifn_171.Invoke_O__O(arg_172) } else { tmp19 = linked_170.(*aot_arbace_string.A_arbace_string_upper_case_A).Invoke_O_O__O(root_169, arg_172) }; var tmp20 any = tmp19; var tmp21 any; var root_177 any = A_arbace_http_A_const_43.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_179 lang.IFn; if
	linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var iter__1927001039__auto____17 any; var fnbody__254 any = A_arbace_http_request_head_iter__1534000027__1534000031_A_New_O(given__8); var tmp22 *jrt.Class; var fncls__253 *jrt.Class = A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class; if fncls__253 == nil { var fncls__253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__254); A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class = fncls__253d; tmp22 = fncls__253d } else { tmp22 = fncls__253 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__254, tmp22, nil); arg_180 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(defaults__9); if linked_178 == nil { tmp21 = ifn_179.Invoke_O__O(arg_180) } else { tmp21 = linked_178.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_177, arg_180) }; var tmp23 any = tmp21; var tmp24 any; var root_255 any = /*line :128:1*/A_arbace_http_A_const_43.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_257 lang.IFn; if

	linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any; var iter__1927001039__auto____17_2 any; var fnbody__320 any = A_arbace_http_request_head_iter__1534000043__1534000047_A_New(); var tmp25 *jrt.Class; var fncls__319 *jrt.Class = A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class; if fncls__319 == nil { var fncls__319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class = fncls__319d; tmp25 = fncls__319d } else { tmp25 = fncls__319 }; iter__1927001039__auto____17_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__320, tmp25, nil); var tmp26 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____17_2); var tmp27 any; var root_321 any = A_arbace_http_A_const_55.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = A_arbace_http_A_const_56.GetRawRoot__O(); var arg_325 any = given__8; if linked_322 == nil { tmp27 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { tmp27 = linked_322.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }; arg_258 = tmp26.Invoke_O__O(tmp27); if linked_256 == nil { tmp24 = ifn_257.Invoke_O__O(arg_258) } else { tmp24 = linked_256.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_255, arg_258) }; return /*line :128:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, tmp20, nil, target__7, nil, tmp23, tmp24, nil)).Ref() }
//line :124:1
func A_arbace_http_request_head_fn__1534000022_A_New() *A_arbace_http_request_head_fn__1534000022_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_fn__1534000022_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_http_request_head_fn__1534000022_A) Ctor() {}
//line :124:1
func (t *A_arbace_http_request_head_fn__1534000022_A) Invoke_O_O__O(self, p__1534000021__1 any) any { var vec__1534000023__2 any = p__1534000021__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000023__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000023__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_151 any = A_arbace_http_A_const_20.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var root_155 any = A_arbace_http_A_const_40.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = k__3; if linked_156 == nil { arg_154 = ifn_157.Invoke_O__O(arg_158) } else { arg_154 = linked_156.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_155, arg_158) }; if linked_152 == nil { tmp1 = ifn_153.Invoke_O__O(arg_154) } else { tmp1 = linked_152.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_151, arg_154) }; var tmp2 any = tmp1; var tmp3 any; var root_159 any = A_arbace_http_A_const_40.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = k__3; if linked_160 == nil { tmp3 = ifn_161.Invoke_O__O(arg_162) } else { tmp3 = linked_160.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_159, arg_162) }; var tmp4 any = tmp3; var tmp5 any; var root_163 any = A_arbace_http_A_const_41.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = v__4; if linked_164 == nil { tmp5 = ifn_165.Invoke_O__O(arg_166) } else { tmp5 = linked_164.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_163, arg_166) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5)) }




func A_arbace_http_request_head_iter__1534000027__1534000031_A_New_O(p0 any) *A_arbace_http_request_head_iter__1534000027__1534000031_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Ctor_O(c__given any) { t.F_given = c__given }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_A) Invoke_O_O__O(self, s__1534000028__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__252 any = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_New_O_O_O(self, t.F_given, s__1534000028__1); var tmp2 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__252); A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class = fncls__251d; tmp2 = fncls__251d } else { tmp2 = fncls__251 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :129:1
func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Ctor_O_O_O(c__iter__1534000027, c__given, c__s__1534000028 any) { t.F_iter__1534000027 = c__iter__1534000027; t.F_given = c__given; t.F_s__1534000028 = c__s__1534000028 }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A) Invoke_O__O(self any) any { { var s__1534000028__1 any; var t_ any = t.F_s__1534000028; t.F_s__1534000028 = nil; s__1534000028__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_181 any = A_arbace_http_A_const_44.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = s__1534000028__1; if linked_182 == nil { temp__1927000414__auto____2 = ifn_183.Invoke_O__O(arg_184) } else { temp__1927000414__auto____2 = linked_182.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_181, arg_184) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1534000028__3 any = temp__1927000414__auto____2; var tmp1 any; var root_185 any = A_arbace_http_A_const_45.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = s__1534000028__3; if linked_186 == nil { tmp1 = ifn_187.Invoke_O__O(arg_188) } else { tmp1 = linked_186.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_185, arg_188) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_189 any = A_arbace_http_A_const_46.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__1534000028__3; if linked_190 == nil { c__1927001037__auto____4 = ifn_191.Invoke_O__O(arg_192) } else { c__1927001037__auto____4 = linked_190.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_189, arg_192) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1534000030__6 any; var root_193 any = A_arbace_http_A_const_47.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_194 == nil { b__1534000030__6 = ifn_195.Invoke_O__O(arg_196) } else { b__1534000030__6 = linked_194.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_193, arg_196) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__207 any = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_New_O_I_O_O(t.F_given, size__1927001038__auto____5, b__1534000030__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__206 *jrt.Class = A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class; if fncls__206 == nil { var fncls__206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__207); A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class = fncls__206d; tmp3 = fncls__206d } else { tmp3 = fncls__206 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__207, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_208 any = A_arbace_http_A_const_50.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var root_213 any = A_arbace_http_A_const_51.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = b__1534000030__6; if linked_214 == nil { arg_211 = ifn_215.Invoke_O__O(arg_216) } else { arg_211 = linked_214.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_213, arg_216) }; var arg_212 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1534000027); var tmp5 any; var root_217 any = A_arbace_http_A_const_52.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = s__1534000028__3; if linked_218 == nil { tmp5 = ifn_219.Invoke_O__O(arg_220) } else { tmp5 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; arg_212 = tmp4.Invoke_O__O(tmp5); if linked_209 == nil { return ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { return linked_209.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) } } else { var root_221 any = A_arbace_http_A_const_50.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var root_226 any = A_arbace_http_A_const_51.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = b__1534000030__6; if linked_227 == nil { arg_224 = ifn_228.Invoke_O__O(arg_229) } else { arg_224 = linked_227.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_226, arg_229) }; var arg_225 any; if linked_222 == nil { return ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { return linked_222.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) } } } else { var vec__1534000038__4 any; var root_230 any = A_arbace_http_A_const_23.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = s__1534000028__3; if linked_231 == nil { vec__1534000038__4 = ifn_232.Invoke_O__O(arg_233) } else { vec__1534000038__4 = linked_231.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_230, arg_233) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000038__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000038__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000038__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 any; var root_234 any = A_arbace_http_A_const_48.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = lang.IFn_Cast(t.F_given).Invoke_O__O(k__5); if linked_235 == nil { tmp6 = ifn_236.Invoke_O__O(arg_237) } else { tmp6 = linked_235.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(tmp6) { var root_238 any = A_arbace_http_A_const_53.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__6, nil, v__7, nil)).Ref(); var arg_242 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1534000027); var tmp8 any; var root_243 any = A_arbace_http_A_const_54.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = s__1534000028__3; if linked_244 == nil { tmp8 = ifn_245.Invoke_O__O(arg_246) } else { tmp8 = linked_244.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_243, arg_246) }; arg_242 = tmp7.Invoke_O__O(tmp8); if linked_239 == nil { return ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { return linked_239.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) } } else { var tmp9 any; var root_247 any = A_arbace_http_A_const_54.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = s__1534000028__3; if linked_248 == nil { tmp9 = ifn_249.Invoke_O__O(arg_250) } else { tmp9 = linked_248.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_247, arg_250) }; s__1534000028__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :129:1
func A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Ctor_O_I_O_O(c__given any, c__size__1927001038__auto__ int32, c__b__1534000030, c__c__1927001037__auto__ any) { t.F_given = c__given; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1534000030 = c__b__1534000030; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :129:1
func (t *A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A) Invoke_O__O(self any) any { { var i__1534000029__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1534000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1534000034__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1534000029__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000034__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000034__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000034__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 any; var root_197 any = A_arbace_http_A_const_48.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = lang.IFn_Cast(t.F_given).Invoke_O__O(k__3); if linked_198 == nil { tmp2 = ifn_199.Invoke_O__O(arg_200) } else { tmp2 = linked_198.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_197, arg_200) }; if jrt.J2g_Truth(tmp2) { var root_201 any = A_arbace_http_A_const_49.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = t.F_b__1534000030; var arg_205 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__4, nil, v__5, nil)).Ref(); if linked_202 == nil { ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { linked_202.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_201, arg_204, arg_205) }; i__1534000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1534000029__1); continue L1 } else { i__1534000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1534000029__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_http_request_head_iter__1534000043__1534000047_A_New() *A_arbace_http_request_head_iter__1534000043__1534000047_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Ctor() {}
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_A) Invoke_O_O__O(self, s__1534000044__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__318 any = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_New_O_O(s__1534000044__1, self); var tmp2 *jrt.Class; var fncls__317 *jrt.Class = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class; if fncls__317 == nil { var fncls__317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__318); A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class = fncls__317d; tmp2 = fncls__317d } else { tmp2 = fncls__317 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__318, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :130:1
func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_New_O_O(p0, p1 any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Ctor_O_O(c__s__1534000044, c__iter__1534000043 any) { t.F_s__1534000044 = c__s__1534000044; t.F_iter__1534000043 = c__iter__1534000043 }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A) Invoke_O__O(self any) any { { var s__1534000044__1 any; var t_ any = t.F_s__1534000044; t.F_s__1534000044 = nil; s__1534000044__1 = t_; for { var temp__1927000414__auto____2 any; var root_259 any = A_arbace_http_A_const_44.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__1534000044__1; if linked_260 == nil { temp__1927000414__auto____2 = ifn_261.Invoke_O__O(arg_262) } else { temp__1927000414__auto____2 = linked_260.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_259, arg_262) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1534000044__3 any = temp__1927000414__auto____2; var tmp1 any; var root_263 any = A_arbace_http_A_const_45.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = s__1534000044__3; if linked_264 == nil { tmp1 = ifn_265.Invoke_O__O(arg_266) } else { tmp1 = linked_264.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_263, arg_266) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_267 any = A_arbace_http_A_const_46.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = s__1534000044__3; if linked_268 == nil { c__1927001037__auto____4 = ifn_269.Invoke_O__O(arg_270) } else { c__1927001037__auto____4 = linked_268.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_267, arg_270) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1534000046__6 any; var root_271 any = A_arbace_http_A_const_47.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_272 == nil { b__1534000046__6 = ifn_273.Invoke_O__O(arg_274) } else { b__1534000046__6 = linked_272.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_271, arg_274) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__281 any = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_New_O_I_O(b__1534000046__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class; if fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__281); A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class = fncls__280d; tmp3 = fncls__280d } else { tmp3 = fncls__280 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__281, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_282 any = A_arbace_http_A_const_50.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var root_287 any = A_arbace_http_A_const_51.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = b__1534000046__6; if linked_288 == nil { arg_285 = ifn_289.Invoke_O__O(arg_290) } else { arg_285 = linked_288.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_287, arg_290) }; var arg_286 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1534000043); var tmp5 any; var root_291 any = A_arbace_http_A_const_52.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = s__1534000044__3; if linked_292 == nil { tmp5 = ifn_293.Invoke_O__O(arg_294) } else { tmp5 = linked_292.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_291, arg_294) }; arg_286 = tmp4.Invoke_O__O(tmp5); if linked_283 == nil { return ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { return linked_283.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) } } else { var root_295 any = A_arbace_http_A_const_50.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any; var root_300 any = A_arbace_http_A_const_51.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = b__1534000046__6; if linked_301 == nil { arg_298 = ifn_302.Invoke_O__O(arg_303) } else { arg_298 = linked_301.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_300, arg_303) }; var arg_299 any; if linked_296 == nil { return ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { return linked_296.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_295, arg_298, arg_299) } } } else { var vec__1534000057__4 any; var root_304 any = A_arbace_http_A_const_23.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = s__1534000044__3; if linked_305 == nil { vec__1534000057__4 = ifn_306.Invoke_O__O(arg_307) } else { vec__1534000057__4 = linked_305.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_304, arg_307) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000057__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1534000060__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000057__4, lang.RT_IntCast_J__I_NoInit(1), nil); var n__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000060__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000060__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_308 any = A_arbace_http_A_const_53.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_310 lang.IFn; _ = ___5; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__7, nil, v__8, nil)).Ref(); var arg_312 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1534000043); var tmp7 any; var root_313 any = A_arbace_http_A_const_54.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = s__1534000044__3; if linked_314 == nil { tmp7 = ifn_315.Invoke_O__O(arg_316) } else { tmp7 = linked_314.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_313, arg_316) }; arg_312 = tmp6.Invoke_O__O(tmp7); if linked_309 == nil { return ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { return linked_309.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :130:1
func A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Ctor_O_I_O(c__b__1534000046 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1534000046 = c__b__1534000046; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :130:1
func (t *A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A) Invoke_O__O(self any) any { { var i__1534000045__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1534000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1534000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1534000045__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1534000053__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000053__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000053__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_275 any = A_arbace_http_A_const_49.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_277 lang.IFn; _ = ___3; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = t.F_b__1534000046; var arg_279 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, n__5, nil, v__6, nil)).Ref(); if linked_276 == nil { ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { linked_276.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) }; i__1534000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1534000045__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_http_request_A_New() *A_arbace_http_request_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_http_request_A) Ctor() {}
//line :133:1
func (t *A_arbace_http_request_A) Invoke_O_O__O(self, p__1534000067__0 any) any { var default__1534000070__2 any = A_arbace_http_A_const_59; var default__1534000071__3 any = A_arbace_http_A_const_60; var default__1534000072__4 int64 = 0; var map__1534000068__5 any = p__1534000067__0; var map__1534000068__6 any; if lang.ISeq_InstanceOf(map__1534000068__5) { var tmp1 any; var root_329 any = A_arbace_http_A_const_61.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = map__1534000068__5; if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_329, arg_332) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_333 any = A_arbace_http_A_const_62.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = map__1534000068__5; if linked_334 == nil { tmp2 = ifn_335.Invoke_O__O(arg_336) } else { tmp2 = linked_334.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_333, arg_336) }; map__1534000068__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_337 any = A_arbace_http_A_const_44.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = map__1534000068__5; if linked_338 == nil { tmp3 = ifn_339.Invoke_O__O(arg_340) } else { tmp3 = linked_338.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_337, arg_340) }; if jrt.J2g_Truth(tmp3) { var root_341 any = A_arbace_http_A_const_23.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = map__1534000068__5; if linked_342 == nil { map__1534000068__6 = ifn_343.Invoke_O__O(arg_344) } else { map__1534000068__6 = linked_342.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_341, arg_344) } } else { map__1534000068__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1534000068__6 = map__1534000068__5 }; var url__7 any = lang.RT_Get_O_O__O_NoInit(map__1534000068__6, A_arbace_http_A_const_63); var method__8 any = lang.RT_Get_O_O_O__O_NoInit(map__1534000068__6, A_arbace_http_A_const_64, default__1534000070__2); var headers__9 any = lang.RT_Get_O_O__O_NoInit(map__1534000068__6, A_arbace_http_A_const_65); var body__10 any = lang.RT_Get_O_O__O_NoInit(map__1534000068__6, A_arbace_http_A_const_66); var as__11 any = lang.RT_Get_O_O_O__O_NoInit(map__1534000068__6, A_arbace_http_A_const_67, default__1534000071__3); var tmp4 any = A_arbace_http_A_const_35; var timeout__12 any = lang.RT_Get_O_O_O__O_NoInit(map__1534000068__6, tmp4, jrt.Long_ValueOf_J__Long_NoInit(default__1534000072__4).Ref()); var tls__13 any = lang.RT_Get_O_O__O_NoInit(map__1534000068__6, A_arbace_http_A_const_68); var uri__14 any = jrt.URI_New_String(jrt.String_Cast(url__7)); var body__15 any; if



	lang.Util_Identical_O_O__Z_NoInit(body__10, nil) { body__15 = nil } else { var tmp5 any; var root_345 any = A_arbace_http_A_const_69.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_347 lang.IFn
		if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = body__10; if linked_346 == nil { tmp5 = ifn_347.Invoke_O__O(arg_348) } else { tmp5 = linked_346.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_345, arg_348) }
//line :137:1
		if jrt.J2g_Truth(tmp5) {
			body__15 = jrt.NN(jrt.String_Cast(body__10)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else {
//line :137:1
				var tmp6 any; var root_349 any = A_arbace_http_A_const_70.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_bytes_QMARK__A_fn_class); var ifn_351 lang.IFn

				if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = body__10; if linked_350 == nil { tmp6 = ifn_351.Invoke_O__O(arg_352) } else { tmp6 = linked_350.(*aot_arbace_core.A_arbace_core_bytes_QMARK__A).Invoke_O_O__O(root_349, arg_352) }
//line :137:1
				if jrt.J2g_Truth(tmp6) { body__15 = body__10 } else { if A_arbace_http_A_const_15 != nil { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_22, nil); var tmp8 any; var root_353 any = A_arbace_http_A_const_71.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_355 lang.IFn


					if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = body__10; if linked_354 == nil { tmp8 = ifn_355.Invoke_O__O(arg_356) } else { tmp8 = linked_354.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_353, arg_356) }
//line :137:1
					panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8))))) } else { body__15 = nil } } } }; var method_name__16 any; var root_357 any = /*line :133:1*/A_arbace_http_A_const_42.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_string.A_arbace_string_upper_case_A_fn_class); var ifn_359 lang.IFn; if







	linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any; var root_361 any = A_arbace_http_A_const_40.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = method__8; if linked_362 == nil { arg_360 = ifn_363.Invoke_O__O(arg_364) } else { arg_360 = linked_362.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_361, arg_364) }; if linked_358 == nil { method_name__16 = ifn_359.Invoke_O__O(arg_360) } else { method_name__16 = linked_358.(*aot_arbace_string.A_arbace_string_upper_case_A).Invoke_O_O__O(root_357, arg_360) }; var headers__17 any; var G__1534000074__17_ any; var or__1927000174__auto____17 any = headers__9; if
	jrt.J2g_Truth(or__1927000174__auto____17) { G__1534000074__17_ = or__1927000174__auto____17 } else { G__1534000074__17_ = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp9 any; var and__1927000168__auto____18 any; var or__1927000174__auto____18 any = body__15; if
	jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18 = or__1927000174__auto____18 } else { and__1927000168__auto____18 = lang.IFn_Cast(A_arbace_http_A_const_72).Invoke_O__O(method_name__16) }; if jrt.J2g_Truth(and__1927000168__auto____18) {
		var root_365 any = A_arbace_http_A_const_73.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any; var fnbody__379 any = A_arbace_http_request_fn__1534000075_A_New(); var tmp10 *jrt.Class; var fncls__378 *jrt.Class = A_arbace_http_request_fn__1534000075_A_fn_class; if fncls__378 == nil { var fncls__378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_http_request_fn__1534000075_A_fn_class = fncls__378d; tmp10 = fncls__378d } else { tmp10 = fncls__378 }; arg_368 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__379, tmp10, nil); var arg_369 any; var root_380 any = A_arbace_http_A_const_74.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = headers__9; if linked_381 == nil { arg_369 = ifn_382.Invoke_O__O(arg_383) } else { arg_369 = linked_381.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_380, arg_383) }; if linked_366 == nil { tmp9 = ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { tmp9 = linked_366.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) } } else {
//line :143:1
			tmp9 = and__1927000168__auto____18 }; if /*line :142:1*/ jrt.J2g_Truth(tmp9) {


				var root_384 any = A_arbace_http_A_const_22.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = G__1534000074__17_; var arg_388 any = Lit_24; var arg_389 any; var root_390 any = A_arbace_http_A_const_41.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any; if jrt.J2g_Truth(body__15) { arg_393 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(body__15))).Ref() } else { arg_393 = A_arbace_http_A_const_14 }; if linked_391 == nil { arg_389 = ifn_392.Invoke_O__O(arg_393) } else { arg_389 = linked_391.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_390, arg_393) }; if linked_385 == nil { headers__17 = ifn_386.Invoke_O_O_O__O(arg_387, arg_388, arg_389) } else { headers__17 = linked_385.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_384, arg_387, arg_388, arg_389) } } else {
//line :142:1
					headers__17 = G__1534000074__17_ }; var s__18 any; var root_394 any = /*line :133:1*/A_arbace_http_A_const_75.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, A_arbace_http_open_A_fn_class); var ifn_396 lang.IFn; if












	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = uri__14; var arg_398 any = timeout__12; var arg_399 any = tls__13; if linked_395 == nil { s__18 = ifn_396.Invoke_O_O_O__O(arg_397, arg_398, arg_399) } else { s__18 = linked_395.(*A_arbace_http_open_A).Invoke_O_O_O_O__O(root_394, arg_397, arg_398, arg_399) }; var tmp11 any; tmp30 := /*line :133:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














		jrt.Socket_Cast(s__18).SetSoTimeout_I__V(lang.RT_IntCast_O__I_NoInit(timeout__12))
//line :133:1
		{ var out__21 any = jrt.BufferedOutputStream_New_OutputStream_I(jrt.Socket_Cast(s__18).GetOutputStream__OutputStream(), lang.RT_IntCast_J__I_NoInit(65536)); var in__22 any = jrt.BufferedInputStream_New_InputStream_I(jrt.Socket_Cast(s__18).GetInputStream__InputStream(), lang.RT_IntCast_J__I_NoInit(65536)); var tmp12 jrt.FilterOutputStream_I = jrt.FilterOutputStream_Cast(out__21); var tmp13 any; var root_432 any = A_arbace_http_A_const_87.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_http_latin1_A_fn_class); var ifn_434 lang.IFn

















			if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any; var root_436 any = A_arbace_http_A_const_88.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_http_request_head_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = method__8; var arg_440 any = uri__14; var arg_441 any = headers__17; if linked_437 == nil { arg_435 = ifn_438.Invoke_O_O_O__O(arg_439, arg_440, arg_441) } else { arg_435 = linked_437.(*A_arbace_http_request_head_A).Invoke_O_O_O_O__O(root_436, arg_439, arg_440, arg_441) }; if linked_433 == nil { tmp13 = ifn_434.Invoke_O__O(arg_435) } else { tmp13 = linked_433.(*A_arbace_http_latin1_A).Invoke_O_O__O(root_432, arg_435) }; tmp12.Write_B1__V(jrt.ByteArray_Cast(tmp13))
			if jrt.J2g_Truth(body__15) { jrt.FilterOutputStream_Cast(out__21).Write_B1__V(jrt.ByteArray_Cast(body__15)) }
			jrt.BufferedOutputStream_Cast(out__21).Flush__V()
//line :133:1
		L1: for { var status_line__23 any; var root_400 any = A_arbace_http_A_const_18.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, A_arbace_http_read_line_STAR__A_fn_class); var ifn_402 lang.IFn





















			if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = in__22; if linked_401 == nil { status_line__23 = ifn_402.Invoke_O__O(arg_403) } else { status_line__23 = linked_401.(*A_arbace_http_read_line_STAR__A).Invoke_O_O__O(root_400, arg_403) }
//line :133:1
			var ___24 any; _ = ___24






















			if lang.Util_Identical_O_O__Z_NoInit(status_line__23, nil) { panic(jrt.Thrown(jrt.IOException_New_String(Lit_25))) } else { ___24 = nil }
//line :133:1
			var vec__1534000077__25 any; var root_404 any = A_arbace_http_A_const_76.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_406 lang.IFn
























			if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = A_arbace_http_A_const_77; var arg_408 any = status_line__23; if linked_405 == nil { vec__1534000077__25 = ifn_406.Invoke_O_O__O(arg_407, arg_408) } else { vec__1534000077__25 = linked_405.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_404, arg_407, arg_408) }
//line :133:1
			var ___26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000077__25, lang.RT_IntCast_J__I_NoInit(0), nil); var version__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000077__25, lang.RT_IntCast_J__I_NoInit(1), nil); var code__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000077__25, lang.RT_IntCast_J__I_NoInit(2), nil); var reason__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1534000077__25, lang.RT_IntCast_J__I_NoInit(3), nil); var ___30 any; _ = ___26; _ = ___30

























			if jrt.J2g_Truth(version__27) { ___30 = nil } else { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_http_A_const_78.GetRawRoot__O()).Invoke_O__O(status_line__23)))))) }
//line :133:1
			var code__31 int32 = jrt.Integer_ParseInt_String__I_NoInit(jrt.String_Cast(code__28)); var hs__32 any; var root_413 any = A_arbace_http_A_const_26.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, A_arbace_http_read_headers_A_fn_class); var ifn_415 lang.IFn




























			if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = in__22; if linked_414 == nil { hs__32 = ifn_415.Invoke_O__O(arg_416) } else { hs__32 = linked_414.(*A_arbace_http_read_headers_A).Invoke_O_O__O(root_413, arg_416) }
			var tmp14 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_79.GetRawRoot__O()); var tmp16 any = A_arbace_http_A_const_80; var and__1927000168__auto____33 any = tmp15.Invoke_O_O_O__O(tmp16, jrt.Integer_ValueOf_I__Integer_NoInit(code__31).Ref(), A_arbace_http_A_const_81); if jrt.J2g_Truth(and__1927000168__auto____33) { var root_423 any = A_arbace_http_A_const_82.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = jrt.Integer_ValueOf_I__Integer_NoInit(code__31).Ref(); var arg_427 any = A_arbace_http_A_const_83; if linked_424 == nil { tmp14 = ifn_425.Invoke_O_O__O(arg_426, arg_427) } else { tmp14 = linked_424.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_423, arg_426, arg_427) } } else { tmp14 = and__1927000168__auto____33 }; if jrt.J2g_Truth(tmp14) {
				continue L1 } else {
//line :163:1
					var b__33 any = jrt.ByteArrayOutputStream_New(); var te__34 any; var root_428 any = A_arbace_http_A_const_20.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_430 lang.IFn


					if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any; var or__1927000174__auto____34 any = lang.IFn_Cast(hs__32).Invoke_O__O(Lit_27); if jrt.J2g_Truth(or__1927000174__auto____34) { arg_431 = or__1927000174__auto____34 } else { arg_431 = Lit_16 }; if linked_429 == nil { te__34 = ifn_430.Invoke_O__O(arg_431) } else { te__34 = linked_429.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_428, arg_431) }
//line :163:1
					var cl__35 any = lang.IFn_Cast(hs__32).Invoke_O__O(Lit_28); var tmp17 any; var or__1927000174__auto____36 bool = lang.Util_Equiv_O_O__Z_NoInit(method_name__16, Lit_29)





					if or__1927000174__auto____36 { tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____36).Ref() } else { var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_http_A_const_79.GetRawRoot__O()); var tmp19 any = A_arbace_http_A_const_80; var or__1927000174__auto____37 any = tmp18.Invoke_O_O_O__O(tmp19, jrt.Integer_ValueOf_I__Integer_NoInit(code__31).Ref(), A_arbace_http_A_const_89); if jrt.J2g_Truth(or__1927000174__auto____37) { tmp17 = or__1927000174__auto____37 } else { var or__1927000174__auto____38 bool = lang.Util_Equiv_J_J__Z_NoInit(int64(code__31), 204); if or__1927000174__auto____38 { tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____38).Ref() } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(int64(code__31), 304)).Ref() } } }
//line :168:1
					if jrt.J2g_Truth(tmp17) { } else { var tmp20 any; var root_448 any = A_arbace_http_A_const_36.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_450 lang.IFn

						if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = te__34; var arg_452 any = Lit_30; if linked_449 == nil { tmp20 = ifn_450.Invoke_O_O__O(arg_451, arg_452) } else { tmp20 = linked_449.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_448, arg_451, arg_452) }
//line :168:1
						if jrt.J2g_Truth(tmp20) {

							var root_453 any = A_arbace_http_A_const_90.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, A_arbace_http_read_chunked_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = in__22; var arg_457 any = b__33; if linked_454 == nil { ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { linked_454.(*A_arbace_http_read_chunked_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) } } else {
//line :168:1
								if jrt.J2g_Truth(cl__35) {


									var root_458 any = A_arbace_http_A_const_27.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_458, A_arbace_http_read_n_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = in__22; var arg_462 any = b__33; var arg_463 int64; var tmp21 any; var root_464 any = A_arbace_http_A_const_21.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any; var root_468 any = A_arbace_http_A_const_23.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any; var root_472 any = A_arbace_http_A_const_24.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = cl__35; var arg_476 any = A_arbace_http_A_const_91; if linked_473 == nil { arg_471 = ifn_474.Invoke_O_O__O(arg_475, arg_476) } else { arg_471 = linked_473.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_472, arg_475, arg_476) }; if linked_469 == nil { arg_467 = ifn_470.Invoke_O__O(arg_471) } else { arg_467 = linked_469.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_468, arg_471) }; if linked_465 == nil { tmp21 = ifn_466.Invoke_O__O(arg_467) } else { tmp21 = linked_465.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_464, arg_467) }; arg_463 = jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp21)); if linked_459 == nil { ifn_460.Invoke_O_O_O__O(arg_461, arg_462, jrt.Long_ValueOf_J__Long_NoInit(arg_463).Ref()) } else { linked_459.(*A_arbace_http_read_n_A).InvokePrim_O_O_O_J__O(root_458, arg_461, arg_462, arg_463) } } else {
//line :168:1
										if A_arbace_http_A_const_15 != nil {



											var root_477 any = A_arbace_http_A_const_92.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, A_arbace_http_read_all_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = in__22; var arg_481 any = b__33; if linked_478 == nil { ifn_479.Invoke_O_O__O(arg_480, arg_481) } else { linked_478.(*A_arbace_http_read_all_A).Invoke_O_O_O__O(root_477, arg_480, arg_481) } } } } }
//line :163:1
					var tmp22 any = A_arbace_http_A_const_84; var tmp23 any = jrt.Integer_ValueOf_I__Integer_NoInit(code__31).Ref(); var tmp24 any = A_arbace_http_A_const_85; var tmp25 any
					var or__1927000174__auto____36_2 any = reason__29









					if jrt.J2g_Truth(or__1927000174__auto____36_2) { tmp25 = or__1927000174__auto____36_2 } else { tmp25 = Lit_16 }
//line :163:1
					var tmp26 any = tmp25; var tmp27 any = A_arbace_http_A_const_65; var tmp28 any = A_arbace_http_A_const_66; var tmp29 any












					if lang.Util_Equiv_O_O__Z_NoInit(as__11, A_arbace_http_A_const_86) {
						tmp29 = jrt.ByteArrayOutputStream_Cast(b__33).ToByteArray__B1().Ref() } else {
//line :176:1
							tmp29 = jrt.String_New_B1_Charset(jrt.ByteArrayOutputStream_Cast(b__33).ToByteArray__B1(), jrt.StandardCharsets_UTF_8) }
//line :163:1
					tmp11 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, tmp26, tmp27, hs__32, tmp28, tmp29)) }
//line :133:1
			break L1 } }; return nil }();














































	jrt.Socket_Cast(s__18).Close__V(); if /*line :133:1*/ tmp30 != nil { panic(tmp30) }; return tmp11 }










func A_arbace_http_request_fn__1534000075_A_New() *A_arbace_http_request_fn__1534000075_A { A_arbace_http_A_Init(); t := &A_arbace_http_request_fn__1534000075_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_http_request_fn__1534000075_A) Ctor() {}
//line :144:1
func (t *A_arbace_http_request_fn__1534000075_A) Invoke_O_O__O(self, p1__1534000066_SHARP___1 any) any { var tmp1 any; var root_370 any = A_arbace_http_A_const_20.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any; var root_374 any = A_arbace_http_A_const_40.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = p1__1534000066_SHARP___1; if linked_375 == nil { arg_373 = ifn_376.Invoke_O__O(arg_377) } else { arg_373 = linked_375.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_374, arg_377) }; if linked_371 == nil { tmp1 = ifn_372.Invoke_O__O(arg_373) } else { tmp1 = linked_371.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_370, arg_373) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_28, tmp1)).Ref() }


































type A_arbace_http_A struct{ jrt.Object }

var A_arbace_http_A_const_pool *jrt.RefArray

var A_arbace_http_A_const_0 *lang.Var

var A_arbace_http_A_const_1 any

var A_arbace_http_A_const_2 *lang.Keyword

var A_arbace_http_A_const_3 any

var A_arbace_http_A_const_4 *lang.Var

var A_arbace_http_A_const_5 any

var A_arbace_http_A_const_6 any

var A_arbace_http_A_const_7 *lang.Var

var A_arbace_http_A_const_8 *lang.Var

var A_arbace_http_A_const_9 *lang.Var

var A_arbace_http_A_const_10 *lang.Var

var A_arbace_http_A_const_11 any

var A_arbace_http_A_const_12 *lang.Var

var A_arbace_http_A_const_13 *lang.Var

var A_arbace_http_A_const_14 any

var A_arbace_http_A_const_15 *lang.Keyword

var A_arbace_http_A_const_16 any

var A_arbace_http_A_const_17 any

var A_arbace_http_A_const_18 *lang.Var

var A_arbace_http_A_const_19 *lang.Var

var A_arbace_http_A_const_20 *lang.Var

var A_arbace_http_A_const_21 *lang.Var

var A_arbace_http_A_const_22 *lang.Var

var A_arbace_http_A_const_23 *lang.Var

var A_arbace_http_A_const_24 *lang.Var

var A_arbace_http_A_const_25 any

var A_arbace_http_A_const_26 *lang.Var

var A_arbace_http_A_const_27 *lang.Var

var A_arbace_http_A_const_28 any

var A_arbace_http_A_const_29 any

var A_arbace_http_A_const_30 *lang.Var

var A_arbace_http_A_const_31 *lang.Var

var A_arbace_http_A_const_32 *lang.Var

var A_arbace_http_A_const_33 *lang.Keyword

var A_arbace_http_A_const_34 any

var A_arbace_http_A_const_35 *lang.Keyword

var A_arbace_http_A_const_36 *lang.Var

var A_arbace_http_A_const_37 *lang.Var

var A_arbace_http_A_const_38 *lang.Var

var A_arbace_http_A_const_39 *lang.Var

var A_arbace_http_A_const_40 *lang.Var

var A_arbace_http_A_const_41 *lang.Var

var A_arbace_http_A_const_42 *lang.Var

var A_arbace_http_A_const_43 *lang.Var

var A_arbace_http_A_const_44 *lang.Var

var A_arbace_http_A_const_45 *lang.Var

var A_arbace_http_A_const_46 *lang.Var

var A_arbace_http_A_const_47 *lang.Var

var A_arbace_http_A_const_48 *lang.Var

var A_arbace_http_A_const_49 *lang.Var

var A_arbace_http_A_const_50 *lang.Var

var A_arbace_http_A_const_51 *lang.Var

var A_arbace_http_A_const_52 *lang.Var

var A_arbace_http_A_const_53 *lang.Var

var A_arbace_http_A_const_54 *lang.Var

var A_arbace_http_A_const_55 *lang.Var

var A_arbace_http_A_const_56 *lang.Var

var A_arbace_http_A_const_57 any

var A_arbace_http_A_const_58 *lang.Var

var A_arbace_http_A_const_59 *lang.Keyword

var A_arbace_http_A_const_60 *lang.Keyword

var A_arbace_http_A_const_61 *lang.Var

var A_arbace_http_A_const_62 *lang.Var

var A_arbace_http_A_const_63 *lang.Keyword

var A_arbace_http_A_const_64 *lang.Keyword

var A_arbace_http_A_const_65 *lang.Keyword

var A_arbace_http_A_const_66 *lang.Keyword

var A_arbace_http_A_const_67 *lang.Keyword

var A_arbace_http_A_const_68 *lang.Keyword

var A_arbace_http_A_const_69 *lang.Var

var A_arbace_http_A_const_70 *lang.Var

var A_arbace_http_A_const_71 *lang.Var

var A_arbace_http_A_const_72 any

var A_arbace_http_A_const_73 *lang.Var

var A_arbace_http_A_const_74 *lang.Var

var A_arbace_http_A_const_75 *lang.Var

var A_arbace_http_A_const_76 *lang.Var

var A_arbace_http_A_const_77 any

var A_arbace_http_A_const_78 *lang.Var

var A_arbace_http_A_const_79 *lang.Var

var A_arbace_http_A_const_80 any

var A_arbace_http_A_const_81 any

var A_arbace_http_A_const_82 *lang.Var

var A_arbace_http_A_const_83 any

var A_arbace_http_A_const_84 *lang.Keyword

var A_arbace_http_A_const_85 *lang.Keyword

var A_arbace_http_A_const_86 *lang.Keyword

var A_arbace_http_A_const_87 *lang.Var

var A_arbace_http_A_const_88 *lang.Var

var A_arbace_http_A_const_89 any

var A_arbace_http_A_const_90 *lang.Var

var A_arbace_http_A_const_91 any

var A_arbace_http_A_const_92 *lang.Var

var A_arbace_http_A_init jrt.ClassInit

func A_arbace_http_A_Init() { if !A_arbace_http_A_init.Done() { A_arbace_http_A_init.Run(A_arbace_http_A_clinit) } }

func A_arbace_http_A_clinit() { A_arbace_http_A_clinit_p0(); A_arbace_http_A_clinit_p1(); A_arbace_http_A_clinit_p2(); A_arbace_http_A_clinit_p3(); A_arbace_http_A_clinit_p4(); A_arbace_http_A_clinit_p5(); A_arbace_http_A_clinit_p6(); A_arbace_http_A_clinit_p7() }

func A_arbace_http_A_clinit_p0() { jrt.StartCheck(); A_arbace_http_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 115); A_arbace_http_A_const_0 = lang.Var_Cast(A_arbace_http_A_const_pool.A[22]); A_arbace_http_A_const_1 = A_arbace_http_A_const_pool.A[23]; A_arbace_http_A_const_2 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[24]); A_arbace_http_A_const_3 = A_arbace_http_A_const_pool.A[25]; A_arbace_http_A_const_4 = lang.Var_Cast(A_arbace_http_A_const_pool.A[26]); A_arbace_http_A_const_5 = A_arbace_http_A_const_pool.A[27]; A_arbace_http_A_const_6 = A_arbace_http_A_const_pool.A[28]; A_arbace_http_A_const_7 = lang.Var_Cast(A_arbace_http_A_const_pool.A[29]); A_arbace_http_A_const_8 = lang.Var_Cast(A_arbace_http_A_const_pool.A[30]); A_arbace_http_A_const_9 = lang.Var_Cast(A_arbace_http_A_const_pool.A[31]); A_arbace_http_A_const_10 = lang.Var_Cast(A_arbace_http_A_const_pool.A[32]); A_arbace_http_A_const_11 = A_arbace_http_A_const_pool.A[33] }

func A_arbace_http_A_clinit_p1() { A_arbace_http_A_const_12 = lang.Var_Cast(A_arbace_http_A_const_pool.A[34]); A_arbace_http_A_const_13 = lang.Var_Cast(A_arbace_http_A_const_pool.A[35]); A_arbace_http_A_const_14 = A_arbace_http_A_const_pool.A[36]; A_arbace_http_A_const_15 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[37]); A_arbace_http_A_const_16 = A_arbace_http_A_const_pool.A[38]; A_arbace_http_A_const_17 = A_arbace_http_A_const_pool.A[39]; A_arbace_http_A_const_18 = lang.Var_Cast(A_arbace_http_A_const_pool.A[40]); A_arbace_http_A_const_19 = lang.Var_Cast(A_arbace_http_A_const_pool.A[41]); A_arbace_http_A_const_20 = lang.Var_Cast(A_arbace_http_A_const_pool.A[42]); A_arbace_http_A_const_21 = lang.Var_Cast(A_arbace_http_A_const_pool.A[43]); A_arbace_http_A_const_22 = lang.Var_Cast(A_arbace_http_A_const_pool.A[44]); A_arbace_http_A_const_23 = lang.Var_Cast(A_arbace_http_A_const_pool.A[45]) }

func A_arbace_http_A_clinit_p2() { A_arbace_http_A_const_24 = lang.Var_Cast(A_arbace_http_A_const_pool.A[46]); A_arbace_http_A_const_25 = A_arbace_http_A_const_pool.A[47]; A_arbace_http_A_const_26 = lang.Var_Cast(A_arbace_http_A_const_pool.A[48]); A_arbace_http_A_const_27 = lang.Var_Cast(A_arbace_http_A_const_pool.A[49]); A_arbace_http_A_const_28 = A_arbace_http_A_const_pool.A[50]; A_arbace_http_A_const_29 = A_arbace_http_A_const_pool.A[51]; A_arbace_http_A_const_30 = lang.Var_Cast(A_arbace_http_A_const_pool.A[52]); A_arbace_http_A_const_31 = lang.Var_Cast(A_arbace_http_A_const_pool.A[53]); A_arbace_http_A_const_32 = lang.Var_Cast(A_arbace_http_A_const_pool.A[54]); A_arbace_http_A_const_33 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[55]); A_arbace_http_A_const_34 = A_arbace_http_A_const_pool.A[56]; A_arbace_http_A_const_35 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[57]); A_arbace_http_A_const_36 = lang.Var_Cast(A_arbace_http_A_const_pool.A[58]) }

func A_arbace_http_A_clinit_p3() { A_arbace_http_A_const_37 = lang.Var_Cast(A_arbace_http_A_const_pool.A[59]); A_arbace_http_A_const_38 = lang.Var_Cast(A_arbace_http_A_const_pool.A[60]); A_arbace_http_A_const_39 = lang.Var_Cast(A_arbace_http_A_const_pool.A[61]); A_arbace_http_A_const_40 = lang.Var_Cast(A_arbace_http_A_const_pool.A[62]); A_arbace_http_A_const_41 = lang.Var_Cast(A_arbace_http_A_const_pool.A[63]); A_arbace_http_A_const_42 = lang.Var_Cast(A_arbace_http_A_const_pool.A[64]); A_arbace_http_A_const_43 = lang.Var_Cast(A_arbace_http_A_const_pool.A[65]); A_arbace_http_A_const_44 = lang.Var_Cast(A_arbace_http_A_const_pool.A[66]); A_arbace_http_A_const_45 = lang.Var_Cast(A_arbace_http_A_const_pool.A[67]); A_arbace_http_A_const_46 = lang.Var_Cast(A_arbace_http_A_const_pool.A[68]); A_arbace_http_A_const_47 = lang.Var_Cast(A_arbace_http_A_const_pool.A[69]); A_arbace_http_A_const_48 = lang.Var_Cast(A_arbace_http_A_const_pool.A[70]) }

func A_arbace_http_A_clinit_p4() { A_arbace_http_A_const_49 = lang.Var_Cast(A_arbace_http_A_const_pool.A[71]); A_arbace_http_A_const_50 = lang.Var_Cast(A_arbace_http_A_const_pool.A[72]); A_arbace_http_A_const_51 = lang.Var_Cast(A_arbace_http_A_const_pool.A[73]); A_arbace_http_A_const_52 = lang.Var_Cast(A_arbace_http_A_const_pool.A[74]); A_arbace_http_A_const_53 = lang.Var_Cast(A_arbace_http_A_const_pool.A[75]); A_arbace_http_A_const_54 = lang.Var_Cast(A_arbace_http_A_const_pool.A[76]); A_arbace_http_A_const_55 = lang.Var_Cast(A_arbace_http_A_const_pool.A[77]); A_arbace_http_A_const_56 = lang.Var_Cast(A_arbace_http_A_const_pool.A[78]); A_arbace_http_A_const_57 = A_arbace_http_A_const_pool.A[79]; A_arbace_http_A_const_58 = lang.Var_Cast(A_arbace_http_A_const_pool.A[80]); A_arbace_http_A_const_59 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[81]); A_arbace_http_A_const_60 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[82]) }

func A_arbace_http_A_clinit_p5() { A_arbace_http_A_const_61 = lang.Var_Cast(A_arbace_http_A_const_pool.A[83]); A_arbace_http_A_const_62 = lang.Var_Cast(A_arbace_http_A_const_pool.A[84]); A_arbace_http_A_const_63 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[85]); A_arbace_http_A_const_64 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[86]); A_arbace_http_A_const_65 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[87]); A_arbace_http_A_const_66 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[88]); A_arbace_http_A_const_67 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[89]); A_arbace_http_A_const_68 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[90]); A_arbace_http_A_const_69 = lang.Var_Cast(A_arbace_http_A_const_pool.A[91]); A_arbace_http_A_const_70 = lang.Var_Cast(A_arbace_http_A_const_pool.A[92]); A_arbace_http_A_const_71 = lang.Var_Cast(A_arbace_http_A_const_pool.A[93]); A_arbace_http_A_const_72 = A_arbace_http_A_const_pool.A[94] }

func A_arbace_http_A_clinit_p6() { A_arbace_http_A_const_73 = lang.Var_Cast(A_arbace_http_A_const_pool.A[95]); A_arbace_http_A_const_74 = lang.Var_Cast(A_arbace_http_A_const_pool.A[96]); A_arbace_http_A_const_75 = lang.Var_Cast(A_arbace_http_A_const_pool.A[97]); A_arbace_http_A_const_76 = lang.Var_Cast(A_arbace_http_A_const_pool.A[98]); A_arbace_http_A_const_77 = A_arbace_http_A_const_pool.A[99]; A_arbace_http_A_const_78 = lang.Var_Cast(A_arbace_http_A_const_pool.A[100]); A_arbace_http_A_const_79 = lang.Var_Cast(A_arbace_http_A_const_pool.A[101]); A_arbace_http_A_const_80 = A_arbace_http_A_const_pool.A[102]; A_arbace_http_A_const_81 = A_arbace_http_A_const_pool.A[103]; A_arbace_http_A_const_82 = lang.Var_Cast(A_arbace_http_A_const_pool.A[104]); A_arbace_http_A_const_83 = A_arbace_http_A_const_pool.A[105]; A_arbace_http_A_const_84 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[106]); A_arbace_http_A_const_85 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[107]) }

func A_arbace_http_A_clinit_p7() { A_arbace_http_A_const_86 = lang.Keyword_Cast(A_arbace_http_A_const_pool.A[108]); A_arbace_http_A_const_87 = lang.Var_Cast(A_arbace_http_A_const_pool.A[109]); A_arbace_http_A_const_88 = lang.Var_Cast(A_arbace_http_A_const_pool.A[110]); A_arbace_http_A_const_89 = A_arbace_http_A_const_pool.A[111]; A_arbace_http_A_const_90 = lang.Var_Cast(A_arbace_http_A_const_pool.A[112]); A_arbace_http_A_const_91 = A_arbace_http_A_const_pool.A[113]; A_arbace_http_A_const_92 = lang.Var_Cast(A_arbace_http_A_const_pool.A[114]) }

func A_arbace_http_A_New() *A_arbace_http_A { A_arbace_http_A_Init(); t := &A_arbace_http_A{}; t.Ctor(); return t }

func (t *A_arbace_http_A) Ctor() {}

func (t *A_arbace_http_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_A) GetClass__Class() *jrt.Class { return A_arbace_http_A_class }

func (t *A_arbace_http_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_http_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_A); return ok }

func A_arbace_http_A_Cast(x any) *A_arbace_http_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_A_class)) }; return v }



type A_arbace_http_default_port_A struct{ j2g_header uint64 }

var A_arbace_http_default_port_A_fn_class *jrt.Class



type A_arbace_http_eval1534000004_A struct{ jrt.Object }

func A_arbace_http_eval1534000004_A_New() *A_arbace_http_eval1534000004_A { t := &A_arbace_http_eval1534000004_A{}; t.Ctor(); return t }

func (t *A_arbace_http_eval1534000004_A) Ctor() {}

func (t *A_arbace_http_eval1534000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000004_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000004_A_class }

func (t *A_arbace_http_eval1534000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000004_A); return ok }

func A_arbace_http_eval1534000004_A_Cast(x any) *A_arbace_http_eval1534000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000004_A_class)) }; return v }



type A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A struct{ j2g_header uint64 }

var A_arbace_http_eval1534000004_loading__1927001464__auto____1534000005_A_fn_class *jrt.Class



type A_arbace_http_eval1534000008_A struct{ jrt.Object }

func A_arbace_http_eval1534000008_A_New() *A_arbace_http_eval1534000008_A { t := &A_arbace_http_eval1534000008_A{}; t.Ctor(); return t }

func (t *A_arbace_http_eval1534000008_A) Ctor() {}

func (t *A_arbace_http_eval1534000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_http_eval1534000008_A) GetClass__Class() *jrt.Class { return A_arbace_http_eval1534000008_A_class }

func (t *A_arbace_http_eval1534000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_http_eval1534000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_http_eval1534000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_http_eval1534000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_http_eval1534000008_A); return ok }

func A_arbace_http_eval1534000008_A_Cast(x any) *A_arbace_http_eval1534000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_http_eval1534000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_http_eval1534000008_A_class)) }; return v }



type A_arbace_http_eval1534000008_fn__1534000009_A struct{ j2g_header uint64 }

var A_arbace_http_eval1534000008_fn__1534000009_A_fn_class *jrt.Class



type A_arbace_http_latin1_A struct{ j2g_header uint64 }

var A_arbace_http_latin1_A_fn_class *jrt.Class



type A_arbace_http_open_A struct{ j2g_header uint64 }

var A_arbace_http_open_A_fn_class *jrt.Class



type A_arbace_http_read_all_A struct{ j2g_header uint64 }

var A_arbace_http_read_all_A_fn_class *jrt.Class



type A_arbace_http_read_chunked_A struct{ j2g_header uint64 }

var A_arbace_http_read_chunked_A_fn_class *jrt.Class



type A_arbace_http_read_headers_A struct{ j2g_header uint64 }

var A_arbace_http_read_headers_A_fn_class *jrt.Class



type A_arbace_http_read_line_STAR__A struct{ j2g_header uint64 }

var A_arbace_http_read_line_STAR__A_fn_class *jrt.Class



type A_arbace_http_read_n_A struct{ j2g_header uint64 }

var A_arbace_http_read_n_A_fn_class *jrt.Class



type A_arbace_http_request_A struct{ j2g_header uint64 }

var A_arbace_http_request_A_fn_class *jrt.Class



type A_arbace_http_request_fn__1534000075_A struct{ j2g_header uint64 }

var A_arbace_http_request_fn__1534000075_A_fn_class *jrt.Class



type A_arbace_http_request_head_A struct{ j2g_header uint64 }

var A_arbace_http_request_head_A_fn_class *jrt.Class



type A_arbace_http_request_head_fn__1534000022_A struct{ j2g_header uint64 }

var A_arbace_http_request_head_fn__1534000022_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000027__1534000031_A struct{ j2g_header uint64; F_given any }

var A_arbace_http_request_head_iter__1534000027__1534000031_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A struct{ j2g_header uint64; F_iter__1534000027, F_given, F_s__1534000028 any }

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A struct{ j2g_header uint64; F_given any; F_size__1927001038__auto__ int32; F_b__1534000030, F_c__1927001037__auto__ any }

var A_arbace_http_request_head_iter__1534000027__1534000031_fn__1534000032_fn__1534000033_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000043__1534000047_A struct{ j2g_header uint64 }

var A_arbace_http_request_head_iter__1534000043__1534000047_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A struct{ j2g_header uint64; F_s__1534000044, F_iter__1534000043 any }

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_A_fn_class *jrt.Class



type A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A struct{ j2g_header uint64; F_b__1534000046 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_http_request_head_iter__1534000043__1534000047_fn__1534000048_fn__1534000049_A_fn_class *jrt.Class
