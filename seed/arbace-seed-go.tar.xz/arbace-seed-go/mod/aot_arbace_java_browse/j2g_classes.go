//line j2g_classes.ae:1
package aot_arbace_java_browse

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_java_browse_browse_url_A_class, Name: "arbace.java.browse$browse_url", Modifiers: 25, Simple: "browse_url", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_browse_url_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_browse_url_fn__745000019_A_class, Name: "arbace.java.browse$browse_url$fn__745000019", Modifiers: 25, Simple: "fn__745000019", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_browse_url_fn__745000019_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_browse_url_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A_class, Name: "arbace.java.browse$eval745000004$loading__1927001464__auto____745000005", Modifiers: 25, Simple: "loading__1927001464__auto____745000005", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_eval745000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_eval745000008_fn__745000009_A_class, Name: "arbace.java.browse$eval745000008$fn__745000009", Modifiers: 25, Simple: "fn__745000009", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_eval745000008_fn__745000009_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_eval745000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_macosx_QMARK__A_class, Name: "arbace.java.browse$macosx_QMARK_", Modifiers: 25, Simple: "macosx_QMARK_", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_macosx_QMARK__A", Source: "browse.ae", Declaring: &A_arbace_java_browse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_open_url_in_browser_A_class, Name: "arbace.java.browse$open_url_in_browser", Modifiers: 25, Simple: "open_url_in_browser", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_open_url_in_browser_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_open_url_in_swing_A_class, Name: "arbace.java.browse$open_url_in_swing", Modifiers: 25, Simple: "open_url_in_swing", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_open_url_in_swing_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_open_url_script_val_A_class, Name: "arbace.java.browse$open_url_script_val", Modifiers: 25, Simple: "open_url_script_val", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_open_url_script_val_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_xdg_open_loc_A_class, Name: "arbace.java.browse$xdg_open_loc", Modifiers: 25, Simple: "xdg_open_loc", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_xdg_open_loc_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_browse_xdg_open_loc_fn__745000013_A_class, Name: "arbace.java.browse$xdg_open_loc$fn__745000013", Modifiers: 25, Simple: "fn__745000013", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_xdg_open_loc_fn__745000013_A", Source: "browse.ae", Declaring: &A_arbace_java_browse_xdg_open_loc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_java_browse_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_browse_A_New()}; return nil }

var A_arbace_java_browse_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_browse_A_new}

var A_arbace_java_browse_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.browse", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_A"})

func init() { i := A_arbace_java_browse_A_class.Info(); i.IsInstance = A_arbace_java_browse_A_InstanceOf; i.Init = A_arbace_java_browse_A_Init; i.Table = A_arbace_java_browse_A_members }

var A_arbace_java_browse_browse_url_A_class *jrt.Class

var A_arbace_java_browse_browse_url_fn__745000019_A_class *jrt.Class

func A_arbace_java_browse_eval745000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_browse_eval745000004_A_New()}; return nil }

var A_arbace_java_browse_eval745000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_browse_eval745000004_A_new}

var A_arbace_java_browse_eval745000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.browse$eval745000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_browse_A_class, Simple: "eval745000004", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_eval745000004_A"})

func init() { i := A_arbace_java_browse_eval745000004_A_class.Info(); i.IsInstance = A_arbace_java_browse_eval745000004_A_InstanceOf; i.Table = A_arbace_java_browse_eval745000004_A_members }

var A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A_class *jrt.Class

func A_arbace_java_browse_eval745000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_browse_eval745000008_A_New()}; return nil }

var A_arbace_java_browse_eval745000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_browse_eval745000008_A_new}

var A_arbace_java_browse_eval745000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.browse$eval745000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_browse_A_class, Simple: "eval745000008", Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse_eval745000008_A"})

func init() { i := A_arbace_java_browse_eval745000008_A_class.Info(); i.IsInstance = A_arbace_java_browse_eval745000008_A_InstanceOf; i.Table = A_arbace_java_browse_eval745000008_A_members }

var A_arbace_java_browse_eval745000008_fn__745000009_A_class *jrt.Class

var A_arbace_java_browse_macosx_QMARK__A_class *jrt.Class

var A_arbace_java_browse_open_url_in_browser_A_class *jrt.Class

var A_arbace_java_browse_open_url_in_swing_A_class *jrt.Class

var A_arbace_java_browse_open_url_script_val_A_class *jrt.Class

var A_arbace_java_browse_xdg_open_loc_A_class *jrt.Class

var A_arbace_java_browse_xdg_open_loc_fn__745000013_A_class *jrt.Class

func A_arbace_java_browse__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_java_browse__init_A_Load__O()}; return nil }

func A_arbace_java_browse__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_browse__init_A_New()}; return nil }

var A_arbace_java_browse__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_java_browse__init_A_invoke, New: A_arbace_java_browse__init_A_new}

var A_arbace_java_browse__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.browse__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_browse.A_arbace_java_browse__init_A", Source: "browse.ae"})

func init() { i := A_arbace_java_browse__init_A_class.Info(); i.IsInstance = A_arbace_java_browse__init_A_InstanceOf; i.Init = A_arbace_java_browse__init_A_Init; i.Table = A_arbace_java_browse__init_A_members }
