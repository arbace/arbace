//line j2g_strings.ae:1
package aot_arbace_java_browse

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn17,arbace.java.shellkn2,asyn2,shyn13,arbace.stringyn3,strkn6,authorkn3,dockn3,outys21,arbace.java.browse-ui17,open-url-in-swingyn21,arbace.java.browse-uikn13,uninitializedv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn18,arbace.java.browsem4,R6,s16,Christophe GrandR7,s32,Start a web browser from ClojureR8,v17,arbace.java.shell2,shv13,arbace.string12,trim-newlinev18,arbace.java.browse7,macosx?v18,arbace.java.browse12,xdg-open-locv11,arbace.core8,to-arrayv11,arbace.core8,find-varR9,R10,v18,arbace.java.browse17,*open-url-script*R11,v11,arbace.core6,reset!v18,arbace.java.browse19,open-url-script-valv11,arbace.core3,strv18,arbace.java.browse19,open-url-in-browserv18,arbace.java.browse17,open-url-in-swing")

var Lit_1 *jrt.String = jrt.Intern("arbace.java.browse$browse_url$fn__745000019")

var Lit_2 *jrt.String = jrt.Intern("os.name")

var Lit_3 *jrt.String = jrt.Intern("Windows")

var Lit_4 *jrt.String = jrt.Intern("NUL")

var Lit_5 *jrt.String = jrt.Intern("/dev/null")

var Lit_6 *jrt.String = jrt.Intern("java.io.File")

var Lit_7 *jrt.String = jrt.Intern("java.net.URI")

var Lit_8 *jrt.String = jrt.Intern("java.lang.ProcessBuilder")

var Lit_9 *jrt.String = jrt.Intern("java.lang.ProcessBuilder$Redirect")

var Lit_10 *jrt.String = jrt.Intern("mac os x")

var Lit_11 *jrt.String = jrt.Intern("java.awt.Desktop")

var Lit_12 *jrt.String = jrt.Intern("isDesktopSupported")

var Lit_13 *jrt.String = jrt.Intern("getDesktop")

var Lit_14 *jrt.String = jrt.Intern("browse")

var Lit_15 *jrt.String = jrt.Intern("/usr/bin/open")

var Lit_16 *jrt.String = jrt.Intern("arbace.java.browse$xdg_open_loc$fn__745000013")

var Lit_17 *jrt.String = jrt.Intern("")

var Lit_18 *jrt.String = jrt.Intern("which")

var Lit_19 *jrt.String = jrt.Intern("xdg-open")

var Lit_20 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.corekn7,privatekn8,arglistskn4,linekn6,columnkn4,filekn13,uninitializedkn7,dynamicyn3,urlkn5,addedv11,arbace.core5,in-nsMyn18,arbace.java.browsem4,R0,s16,Christophe GrandR1,s32,Start a web browser from Clojurem4,R0,s16,Christophe GrandR1,s32,Start a web browser from ClojureR2,v18,arbace.java.browse7,macosx?m10,R3,TR4,L1,V0,R5,i19,R6,i1,R7,s21,arbace/java/browse.aev18,arbace.java.browse12,xdg-open-locm10,R3,TR4,L1,V0,R5,i23,R6,i1,R7,s21,arbace/java/browse.aev18,arbace.java.browse19,open-url-script-valm10,R3,TR4,L1,V0,R5,i31,R6,i1,R7,s21,arbace/java/browse.aev18,arbace.java.browse17,*open-url-script*v11,arbace.core4,atomR8,m8,R9,TR5,i42,R6,i1,R7,s21,arbace/java/browse.aev18,arbace.java.browse19,open-url-in-browserm12,R3,TR4,L1,V1,R10,R1,s138,Opens url (a string) in the default system web browser.  May not\n  work on all platforms.  Returns url on success, nil if not\n  supported.R5,i44,R6,i1,R7,s21,arbace/java/browse.aev18,arbace.java.browse17,open-url-in-swingm12,R3,TR4,L1,V1,R10,R1,s39,Opens url (a string) in a Swing window.R5,i59,R6,i1,R7,s21,arbace/java/browse.aev18,arbace.java.browse10,browse-urlm12,R4,L1,V1,R10,R1,s21,Open url in a browserR11,s3,1.2R5,i68,R6,i1,R7,s21,arbace/java/browse.ae")

var Lit_21 *jrt.String = jrt.Intern("arbace.java.browse$eval745000004$loading__1927001464__auto____745000005")

var Lit_22 *jrt.String = jrt.Intern("arbace.java.browse$eval745000008$fn__745000009")

var Lit_23 *jrt.String = jrt.Intern("arbace.java.browse$macosx_QMARK_")

var Lit_24 *jrt.String = jrt.Intern("arbace.java.browse$xdg_open_loc")

var Lit_25 *jrt.String = jrt.Intern("arbace.java.browse$open_url_script_val")

var Lit_26 *jrt.String = jrt.Intern("arbace.java.browse$open_url_in_browser")

var Lit_27 *jrt.String = jrt.Intern("arbace.java.browse$open_url_in_swing")

var Lit_28 *jrt.String = jrt.Intern("arbace.java.browse$browse_url")
