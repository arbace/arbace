//line aot_arbace_java_browse.ae:1
package aot_arbace_java_browse

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A_New() *A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_browse_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_browse_A_const_1); lang.IFn_Cast(A_arbace_java_browse_A_const_2.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_browse_A_const_3, A_arbace_java_browse_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_java_browse_eval745000008_fn__745000009_A_New() *A_arbace_java_browse_eval745000008_fn__745000009_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_eval745000008_fn__745000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_browse_eval745000008_fn__745000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_browse_eval745000008_fn__745000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_browse_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_java_browse_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_java_browse_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_browse_A_const_8.GetRawRoot__O(), A_arbace_java_browse_A_const_9) }









func A_arbace_java_browse_macosx_QMARK__A_New() *A_arbace_java_browse_macosx_QMARK__A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_macosx_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_java_browse_macosx_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_java_browse_macosx_QMARK__A) Invoke_O__O(self any) any {

	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.System_GetProperty_String__String(Lit_2)).ToLowerCase__String()).StartsWith_String__Z(Lit_10)).Ref()
}
func A_arbace_java_browse_xdg_open_loc_A_New() *A_arbace_java_browse_xdg_open_loc_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_xdg_open_loc_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_java_browse_xdg_open_loc_A) Ctor() {}
//line :23:1
func (t *A_arbace_java_browse_xdg_open_loc_A) Invoke_O__O(self any) any { var which_out__1 any; var tmp1 any = A_arbace_java_browse_xdg_open_loc_fn__745000013_A_New(); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_java_browse_xdg_open_loc_fn__745000013_A_fn_class; if

	fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_java_browse_xdg_open_loc_fn__745000013_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; which_out__1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); if

	lang.Util_Equiv_O_O__Z_NoInit(which_out__1, Lit_17) { return nil } else {

		var root_26 any = A_arbace_java_browse_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_trim_newline_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = which_out__1; if linked_27 == nil { return ifn_28.Invoke_O__O(arg_29) } else { return linked_27.(*aot_arbace_string.A_arbace_string_trim_newline_A).Invoke_O_O__O(root_26, arg_29) } } }
//line :25:1
func A_arbace_java_browse_xdg_open_loc_fn__745000013_A_New() *A_arbace_java_browse_xdg_open_loc_fn__745000013_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_xdg_open_loc_fn__745000013_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_java_browse_xdg_open_loc_fn__745000013_A) Ctor() {}
//line :25:1
func (t *A_arbace_java_browse_xdg_open_loc_fn__745000013_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Keyword = A_arbace_java_browse_A_const_10; tmp1 = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_java_browse_A_const_11.GetRawRoot__O()).Invoke_O_O__O(Lit_18, Lit_19)) }; return nil }(); if tmp3 != nil { if jrt.Exception_InstanceOf(tmp3) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp3); _ = e__3; tmp1 = Lit_17 } else { panic(tmp3) } }; return tmp1 }





func A_arbace_java_browse_open_url_script_val_A_New() *A_arbace_java_browse_open_url_script_val_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_open_url_script_val_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_java_browse_open_url_script_val_A) Ctor() {}
//line :31:1
func (t *A_arbace_java_browse_open_url_script_val_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_30 any = A_arbace_java_browse_A_const_13.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, A_arbace_java_browse_macosx_QMARK__A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; if linked_31 == nil { tmp1 = ifn_32.Invoke__O() } else { tmp1 = linked_31.(*A_arbace_java_browse_macosx_QMARK__A).Invoke_O__O(root_30) }; if jrt.J2g_Truth(tmp1) { return Lit_15 } else {

		var root_33 any = A_arbace_java_browse_A_const_14.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_java_browse_xdg_open_loc_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; if linked_34 == nil { return ifn_35.Invoke__O() } else { return linked_34.(*A_arbace_java_browse_xdg_open_loc_A).Invoke_O__O(root_33)
		}
	}
}






func A_arbace_java_browse_open_url_in_browser_A_New() *A_arbace_java_browse_open_url_in_browser_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_open_url_in_browser_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_java_browse_open_url_in_browser_A) Ctor() {}
//line :44:1
func (t *A_arbace_java_browse_open_url_in_browser_A) Invoke_O_O__O(self, url__0 any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





	{ var tmp2 *jrt.String = Lit_11; var tmp3 *jrt.String = Lit_12; var tmp4 any; var root_36 any = A_arbace_java_browse_A_const_15.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_38 lang.IFn
		if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; if linked_37 == nil { tmp4 = ifn_38.Invoke_O__O(arg_39) } else { tmp4 = linked_37.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_36, arg_39) }
//line :50:1
		if jrt.J2g_Truth(lang.Reflector_InvokeStaticMethod_String_String_O1__O(tmp2, tmp3, jrt.ObjectArray_Cast(tmp4))) {



			var tmp5 *jrt.String = Lit_11; var tmp6 *jrt.String = Lit_13; var tmp7 any; var root_40 any = A_arbace_java_browse_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_42 lang.IFn
//line :53:1
			if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; if linked_41 == nil { tmp7 = ifn_42.Invoke_O__O(arg_43) } else { tmp7 = linked_41.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_40, arg_43) }
			lang.Reflector_InvokeInstanceMethod_O_String_O1__O(lang.Reflector_InvokeStaticMethod_String_String_O1__O(tmp5, tmp6, jrt.ObjectArray_Cast(tmp7)), Lit_14, jrt.RefArrayOf(jrt.Object_class, jrt.URI_New_String(jrt.String_Cast(url__0))))
//line :50:1
			tmp1 = url__0 } else { tmp1 = nil } }
//line :44:1
	return nil }(); if tmp8 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp8) { var e__4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp8); _ = e__4; tmp1 = nil } else { panic(tmp8) } }; return tmp1 }














func A_arbace_java_browse_open_url_in_swing_A_New() *A_arbace_java_browse_open_url_in_swing_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_open_url_in_swing_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_java_browse_open_url_in_swing_A) Ctor() {}
//line :59:1
func (t *A_arbace_java_browse_open_url_in_swing_A) Invoke_O_O__O(self, url__0 any) any {





	lang.IFn_Cast(A_arbace_java_browse_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_browse_A_const_18)
	var tmp1 any; var root_44 any = A_arbace_java_browse_A_const_16.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_find_var_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_java_browse_A_const_17; if linked_45 == nil { tmp1 = ifn_46.Invoke_O__O(arg_47) } else { tmp1 = linked_45.(*aot_arbace_core.A_arbace_core_find_var_A).Invoke_O_O__O(root_44, arg_47) }; return lang.IFn_Cast(tmp1).Invoke_O__O(url__0)
}
func A_arbace_java_browse_browse_url_A_New() *A_arbace_java_browse_browse_url_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_browse_url_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_java_browse_browse_url_A) Ctor() {}
//line :68:1
func (t *A_arbace_java_browse_browse_url_A) Invoke_O_O__O(self, url__0 any) any { var script__2 any; var root_52 any = A_arbace_java_browse_A_const_6.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_54 lang.IFn; if



	linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = A_arbace_java_browse_A_const_19.Get__O(); if linked_53 == nil { script__2 = ifn_54.Invoke_O__O(arg_55) } else { script__2 = linked_53.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_52, arg_55) }; var script__3 any; if
	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_java_browse_A_const_20, script__2) {
		var root_56 any = A_arbace_java_browse_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = A_arbace_java_browse_A_const_19.Get__O(); var arg_60 any; var root_61 any = A_arbace_java_browse_A_const_22.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, A_arbace_java_browse_open_url_script_val_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; if linked_62 == nil { arg_60 = ifn_63.Invoke__O() } else { arg_60 = linked_62.(*A_arbace_java_browse_open_url_script_val_A).Invoke_O__O(root_61) }; if linked_57 == nil { script__3 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { script__3 = linked_57.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_56, arg_59, arg_60) } } else {
//line :73:1
			script__3 = script__2 }; var or__1927000174__auto____4 any; if


	jrt.J2g_Truth(script__3) {
		var tmp1 any = A_arbace_java_browse_browse_url_fn__745000019_A_New_O_O(script__3, url__0); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_java_browse_browse_url_fn__745000019_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_java_browse_browse_url_fn__745000019_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; or__1927000174__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() } else {
//line :76:1
			or__1927000174__auto____4 = nil }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_69 any = A_arbace_java_browse_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, A_arbace_java_browse_open_url_in_browser_A_fn_class); var ifn_71 lang.IFn










				if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = url__0; if linked_70 == nil { or__1927000174__auto____5 = ifn_71.Invoke_O__O(arg_72) } else { or__1927000174__auto____5 = linked_70.(*A_arbace_java_browse_open_url_in_browser_A).Invoke_O_O__O(root_69, arg_72) }
//line :76:1
				if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {











					var root_73 any = A_arbace_java_browse_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_java_browse_open_url_in_swing_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = url__0; if linked_74 == nil { return ifn_75.Invoke_O__O(arg_76) } else { return linked_74.(*A_arbace_java_browse_open_url_in_swing_A).Invoke_O_O__O(root_73, arg_76) } } } }
//line :77:1
func A_arbace_java_browse_browse_url_fn__745000019_A_New_O_O(p0, p1 any) *A_arbace_java_browse_browse_url_fn__745000019_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_browse_url_fn__745000019_A{}; t.Ctor_O_O(p0, p1); return t }
//line :77:1
func (t *A_arbace_java_browse_browse_url_fn__745000019_A) Ctor_O_O(c__script, c__url any) { t.F_script = c__script; t.F_url = c__url }
//line :77:1
func (t *A_arbace_java_browse_browse_url_fn__745000019_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var command__3 any; var tmp2 any; var t_ any = t.F_script; t.F_script = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var root_64 any = A_arbace_java_browse_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_66 lang.IFn
											if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var t__2 any = t.F_url; t.F_url = nil; arg_67 = t__2; if linked_65 == nil { tmp4 = ifn_66.Invoke_O__O(arg_67) } else { tmp4 = linked_65.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_64, arg_67) }
//line :77:1
	command__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4); var null_file__4 any; var tmp5 *jrt.String

	if jrt.NN(jrt.System_GetProperty_String__String(Lit_2)).StartsWith_String__Z(Lit_3) { tmp5 = Lit_4 } else { tmp5 = Lit_5 }
//line :77:1
	null_file__4 = jrt.File_New_String(tmp5); var pb__5 any; var G__745000020__5_ any = jrt.ProcessBuilder_New_List(jrt.List_Cast(command__3))




	jrt.NN(jrt.ProcessBuilder_Cast(G__745000020__5_)).RedirectOutput_File__ProcessBuilder(jrt.File_Cast(null_file__4))
	jrt.NN(jrt.ProcessBuilder_Cast(G__745000020__5_)).RedirectError_File__ProcessBuilder(jrt.File_Cast(null_file__4))
//line :77:1
	pb__5 = G__745000020__5_






	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process()
//line :77:1
	tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp6 != nil { if true { var ___3 jrt.Throwable_I = tmp6; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }







type A_arbace_java_browse_A struct{ jrt.Object }

var A_arbace_java_browse_A_const_pool *jrt.RefArray

var A_arbace_java_browse_A_const_0 *lang.Var

var A_arbace_java_browse_A_const_1 any

var A_arbace_java_browse_A_const_2 *lang.Var

var A_arbace_java_browse_A_const_3 any

var A_arbace_java_browse_A_const_4 any

var A_arbace_java_browse_A_const_5 *lang.Var

var A_arbace_java_browse_A_const_6 *lang.Var

var A_arbace_java_browse_A_const_7 *lang.Var

var A_arbace_java_browse_A_const_8 *lang.Var

var A_arbace_java_browse_A_const_9 any

var A_arbace_java_browse_A_const_10 *lang.Keyword

var A_arbace_java_browse_A_const_11 *lang.Var

var A_arbace_java_browse_A_const_12 *lang.Var

var A_arbace_java_browse_A_const_13 *lang.Var

var A_arbace_java_browse_A_const_14 *lang.Var

var A_arbace_java_browse_A_const_15 *lang.Var

var A_arbace_java_browse_A_const_16 *lang.Var

var A_arbace_java_browse_A_const_17 any

var A_arbace_java_browse_A_const_18 any

var A_arbace_java_browse_A_const_19 *lang.Var

var A_arbace_java_browse_A_const_20 *lang.Keyword

var A_arbace_java_browse_A_const_21 *lang.Var

var A_arbace_java_browse_A_const_22 *lang.Var

var A_arbace_java_browse_A_const_23 *lang.Var

var A_arbace_java_browse_A_const_24 *lang.Var

var A_arbace_java_browse_A_const_25 *lang.Var

var A_arbace_java_browse_A_init jrt.ClassInit

func A_arbace_java_browse_A_Init() { if !A_arbace_java_browse_A_init.Done() { A_arbace_java_browse_A_init.Run(A_arbace_java_browse_A_clinit) } }

func A_arbace_java_browse_A_clinit() { A_arbace_java_browse_A_clinit_p0(); A_arbace_java_browse_A_clinit_p1(); A_arbace_java_browse_A_clinit_p2() }

func A_arbace_java_browse_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_browse_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 38); A_arbace_java_browse_A_const_0 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[12]); A_arbace_java_browse_A_const_1 = A_arbace_java_browse_A_const_pool.A[13]; A_arbace_java_browse_A_const_2 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[14]); A_arbace_java_browse_A_const_3 = A_arbace_java_browse_A_const_pool.A[15]; A_arbace_java_browse_A_const_4 = A_arbace_java_browse_A_const_pool.A[16]; A_arbace_java_browse_A_const_5 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[17]); A_arbace_java_browse_A_const_6 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[18]); A_arbace_java_browse_A_const_7 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[19]); A_arbace_java_browse_A_const_8 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[20]); A_arbace_java_browse_A_const_9 = A_arbace_java_browse_A_const_pool.A[21]; A_arbace_java_browse_A_const_10 = lang.Keyword_Cast(A_arbace_java_browse_A_const_pool.A[22]); A_arbace_java_browse_A_const_11 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[23]) }

func A_arbace_java_browse_A_clinit_p1() { A_arbace_java_browse_A_const_12 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[24]); A_arbace_java_browse_A_const_13 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[25]); A_arbace_java_browse_A_const_14 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[26]); A_arbace_java_browse_A_const_15 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[27]); A_arbace_java_browse_A_const_16 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[28]); A_arbace_java_browse_A_const_17 = A_arbace_java_browse_A_const_pool.A[29]; A_arbace_java_browse_A_const_18 = A_arbace_java_browse_A_const_pool.A[30]; A_arbace_java_browse_A_const_19 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[31]); A_arbace_java_browse_A_const_20 = lang.Keyword_Cast(A_arbace_java_browse_A_const_pool.A[32]); A_arbace_java_browse_A_const_21 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[33]); A_arbace_java_browse_A_const_22 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[34]); A_arbace_java_browse_A_const_23 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[35]) }

func A_arbace_java_browse_A_clinit_p2() { A_arbace_java_browse_A_const_24 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[36]); A_arbace_java_browse_A_const_25 = lang.Var_Cast(A_arbace_java_browse_A_const_pool.A[37]) }

func A_arbace_java_browse_A_New() *A_arbace_java_browse_A { A_arbace_java_browse_A_Init(); t := &A_arbace_java_browse_A{}; t.Ctor(); return t }

func (t *A_arbace_java_browse_A) Ctor() {}

func (t *A_arbace_java_browse_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_browse_A) GetClass__Class() *jrt.Class { return A_arbace_java_browse_A_class }

func (t *A_arbace_java_browse_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_browse_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_browse_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_browse_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_browse_A); return ok }

func A_arbace_java_browse_A_Cast(x any) *A_arbace_java_browse_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_browse_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_browse_A_class)) }; return v }



type A_arbace_java_browse_browse_url_A struct{ j2g_header uint64 }

var A_arbace_java_browse_browse_url_A_fn_class *jrt.Class



type A_arbace_java_browse_browse_url_fn__745000019_A struct{ j2g_header uint64; F_script, F_url any }

var A_arbace_java_browse_browse_url_fn__745000019_A_fn_class *jrt.Class



type A_arbace_java_browse_eval745000004_A struct{ jrt.Object }

func A_arbace_java_browse_eval745000004_A_New() *A_arbace_java_browse_eval745000004_A { t := &A_arbace_java_browse_eval745000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_browse_eval745000004_A) Ctor() {}

func (t *A_arbace_java_browse_eval745000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_browse_eval745000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_browse_eval745000004_A_class }

func (t *A_arbace_java_browse_eval745000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_browse_eval745000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_browse_eval745000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_browse_eval745000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_browse_eval745000004_A); return ok }

func A_arbace_java_browse_eval745000004_A_Cast(x any) *A_arbace_java_browse_eval745000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_browse_eval745000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_browse_eval745000004_A_class)) }; return v }



type A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A struct{ j2g_header uint64 }

var A_arbace_java_browse_eval745000004_loading__1927001464__auto____745000005_A_fn_class *jrt.Class



type A_arbace_java_browse_eval745000008_A struct{ jrt.Object }

func A_arbace_java_browse_eval745000008_A_New() *A_arbace_java_browse_eval745000008_A { t := &A_arbace_java_browse_eval745000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_browse_eval745000008_A) Ctor() {}

func (t *A_arbace_java_browse_eval745000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_browse_eval745000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_browse_eval745000008_A_class }

func (t *A_arbace_java_browse_eval745000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_browse_eval745000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_browse_eval745000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_browse_eval745000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_browse_eval745000008_A); return ok }

func A_arbace_java_browse_eval745000008_A_Cast(x any) *A_arbace_java_browse_eval745000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_browse_eval745000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_browse_eval745000008_A_class)) }; return v }



type A_arbace_java_browse_eval745000008_fn__745000009_A struct{ j2g_header uint64 }

var A_arbace_java_browse_eval745000008_fn__745000009_A_fn_class *jrt.Class



type A_arbace_java_browse_macosx_QMARK__A struct{ j2g_header uint64 }

var A_arbace_java_browse_macosx_QMARK__A_fn_class *jrt.Class



type A_arbace_java_browse_open_url_in_browser_A struct{ j2g_header uint64 }

var A_arbace_java_browse_open_url_in_browser_A_fn_class *jrt.Class



type A_arbace_java_browse_open_url_in_swing_A struct{ j2g_header uint64 }

var A_arbace_java_browse_open_url_in_swing_A_fn_class *jrt.Class



type A_arbace_java_browse_open_url_script_val_A struct{ j2g_header uint64 }

var A_arbace_java_browse_open_url_script_val_A_fn_class *jrt.Class



type A_arbace_java_browse_xdg_open_loc_A struct{ j2g_header uint64 }

var A_arbace_java_browse_xdg_open_loc_A_fn_class *jrt.Class



type A_arbace_java_browse_xdg_open_loc_fn__745000013_A struct{ j2g_header uint64 }

var A_arbace_java_browse_xdg_open_loc_fn__745000013_A_fn_class *jrt.Class
